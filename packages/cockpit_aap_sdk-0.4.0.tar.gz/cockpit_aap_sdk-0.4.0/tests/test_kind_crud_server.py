"""Tests for cockpit_aap.kind_crud_server — Dynamic Kind CRUD MCP server."""

from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

import pytest
import yaml

# Skip all tests if fastmcp is not installed
fastmcp = pytest.importorskip("fastmcp", reason="fastmcp not installed; install cockpit-aap-sdk[mcp]")

from cockpit_aap.kind_crud_server import (
    _discover_kind_manifests,
    _generic_health_check,
    _grade_from_percentage,
    _kind_to_snake,
    _validate_kind_manifest,
    create_kind_crud_server,
    register_kind_health_checker,
)
from cockpit_aap.manifest.kind_registry import (
    KindFieldSchema,
    KindRegistry,
    create_kind_registry,
    kind_registry,
)


# ── _kind_to_snake tests ─────────────────────────────────────────────────────


class TestKindToSnake:
    def test_simple_pascal(self):
        assert _kind_to_snake("Module") == "module"

    def test_multi_word(self):
        assert _kind_to_snake("TelemetryBlueprint") == "telemetry_blueprint"

    def test_all_caps(self):
        assert _kind_to_snake("SDLC") == "sdlc"

    def test_caps_then_pascal(self):
        assert _kind_to_snake("MCPTool") == "mcp_tool"

    def test_agent_card(self):
        assert _kind_to_snake("AgentCard") == "agent_card"

    def test_single_word(self):
        assert _kind_to_snake("Agent") == "agent"

    def test_mcp_server(self):
        assert _kind_to_snake("MCPServer") == "mcp_server"


# ── _grade_from_percentage tests ──────────────────────────────────────────────


class TestGradeFromPercentage:
    def test_a_grade(self):
        assert _grade_from_percentage(95) == "A"
        assert _grade_from_percentage(90) == "A"

    def test_b_grade(self):
        assert _grade_from_percentage(80) == "B"
        assert _grade_from_percentage(75) == "B"

    def test_c_grade(self):
        assert _grade_from_percentage(65) == "C"
        assert _grade_from_percentage(60) == "C"

    def test_d_grade(self):
        assert _grade_from_percentage(50) == "D"
        assert _grade_from_percentage(40) == "D"

    def test_f_grade(self):
        assert _grade_from_percentage(30) == "F"
        assert _grade_from_percentage(0) == "F"


# ── Validation tests ─────────────────────────────────────────────────────────


class TestValidateKindManifest:
    def test_missing_manifest_file(self, tmp_path: Path):
        reg = create_kind_registry()
        reg.register(
            "TestKind",
            description="Test kind",
            fields=[],
        )
        result = _validate_kind_manifest("TestKind", str(tmp_path), reg)
        assert result["valid"] is False
        assert any("not found" in e for e in result["errors"])

    def test_valid_manifest(self, tmp_path: Path):
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "TestKind",
            "metadata": {"name": "test"},
            "spec": {},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        reg = create_kind_registry()
        reg.register(
            "TestKind",
            description="Test kind",
            fields=[
                KindFieldSchema(path="metadata.name", type="string", required=True),
            ],
        )
        result = _validate_kind_manifest("TestKind", str(tmp_path), reg)
        assert result["valid"] is True
        assert len(result["errors"]) == 0

    def test_missing_required_field(self, tmp_path: Path):
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "TestKind",
            "metadata": {},
            "spec": {},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        reg = create_kind_registry()
        reg.register(
            "TestKind",
            description="Test kind",
            fields=[
                KindFieldSchema(path="metadata.name", type="string", required=True),
            ],
        )
        result = _validate_kind_manifest("TestKind", str(tmp_path), reg)
        assert result["valid"] is False
        assert any("metadata.name" in e for e in result["errors"])

    def test_enum_warning(self, tmp_path: Path):
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "TestKind",
            "metadata": {"name": "test"},
            "spec": {"category": "invalid_value"},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        reg = create_kind_registry()
        reg.register(
            "TestKind",
            description="Test kind",
            fields=[
                KindFieldSchema(path="metadata.name", type="string", required=True),
                KindFieldSchema(
                    path="spec.category",
                    type="string",
                    enum=["a", "b", "c"],
                ),
            ],
        )
        result = _validate_kind_manifest("TestKind", str(tmp_path), reg)
        assert result["valid"] is True  # warnings don't fail validation
        assert len(result["warnings"]) > 0
        assert "invalid_value" in result["warnings"][0]


# ── Generic Health Check tests ────────────────────────────────────────────────


class TestGenericHealthCheck:
    def test_missing_manifest_dir(self, tmp_path: Path):
        reg = create_kind_registry()
        reg.register("TestKind", description="Test", fields=[])
        result = _generic_health_check("TestKind", str(tmp_path / "nonexistent"), reg)
        assert result["grade"] == "F"
        assert result["kind"] == "TestKind"
        assert result["score"] == 0

    def test_empty_manifest(self, tmp_path: Path):
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "TestKind",
            "metadata": {"name": "test"},
            "spec": {},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        reg = create_kind_registry()
        reg.register("TestKind", description="Test", fields=[])
        result = _generic_health_check("TestKind", str(tmp_path), reg)
        assert result["kind"] == "TestKind"
        # Core should pass (4/4)
        assert result["details"]["core"]["score"] == 4

    def test_required_fields_scoring(self, tmp_path: Path):
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "TestKind",
            "metadata": {"name": "test", "version": "1.0.0"},
            "spec": {},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        reg = create_kind_registry()
        reg.register(
            "TestKind",
            description="Test",
            fields=[
                KindFieldSchema(path="metadata.name", type="string", required=True),
                KindFieldSchema(path="metadata.version", type="string", required=True),
                KindFieldSchema(
                    path="metadata.missing", type="string", required=True
                ),
            ],
        )
        result = _generic_health_check("TestKind", str(tmp_path), reg)
        req = result["details"]["required_fields"]
        # 2 found × 2pts = 4, 1 missing (capped at 6 total max)
        assert req["score"] == 4
        assert len(req["issues"]) == 1


# ── Discover Kind Manifests tests ─────────────────────────────────────────────


class TestDiscoverKindManifests:
    def test_discovers_manifests_in_aap_dir(self, tmp_path: Path):
        aap_dir = tmp_path / ".aap" / "my-module"
        aap_dir.mkdir(parents=True)
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "my-module"},
        }
        (aap_dir / "manifest.yaml").write_text(yaml.dump(manifest))

        results = _discover_kind_manifests(str(tmp_path), "Module")
        assert len(results) == 1
        assert "my-module" in results[0]

    def test_ignores_different_kind(self, tmp_path: Path):
        aap_dir = tmp_path / ".aap" / "my-agent"
        aap_dir.mkdir(parents=True)
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Agent",
            "metadata": {"name": "my-agent"},
        }
        (aap_dir / "manifest.yaml").write_text(yaml.dump(manifest))

        results = _discover_kind_manifests(str(tmp_path), "Module")
        assert len(results) == 0

    def test_discovers_governance_manifests(self, tmp_path: Path):
        gov_dir = tmp_path / "governance" / "my-policy"
        gov_dir.mkdir(parents=True)
        manifest = {
            "apiVersion": "governance.cockpit.io/v1",
            "kind": "Policy",
            "metadata": {"name": "my-policy"},
        }
        (gov_dir / "manifest.yaml").write_text(yaml.dump(manifest))

        results = _discover_kind_manifests(str(tmp_path), "Policy")
        assert len(results) == 1

    def test_empty_workspace(self, tmp_path: Path):
        results = _discover_kind_manifests(str(tmp_path), "Module")
        assert results == []


# ── FastMCP Server Integration tests ─────────────────────────────────────────


class TestCreateKindCrudServer:
    def test_creates_fastmcp_instance(self):
        from fastmcp import FastMCP

        server = create_kind_crud_server(only_kinds=["Module"])
        assert isinstance(server, FastMCP)

    @pytest.mark.asyncio
    async def test_registers_tools_for_module_kind(self):
        server = create_kind_crud_server(only_kinds=["Module"])
        tools = await server.list_tools()
        tool_names = {t.name for t in tools}

        assert "get_module_manifest" in tool_names
        assert "list_module_manifests" in tool_names
        assert "validate_module_manifest" in tool_names
        assert "check_module_health" in tool_names
        assert "list_dynamic_kind_tools" in tool_names

    @pytest.mark.asyncio
    async def test_registers_tools_for_multiple_kinds(self):
        server = create_kind_crud_server(only_kinds=["Module", "Agent"])
        tools = await server.list_tools()
        tool_names = {t.name for t in tools}

        # Module tools
        assert "get_module_manifest" in tool_names
        assert "check_module_health" in tool_names

        # Agent tools
        assert "get_agent_manifest" in tool_names
        assert "check_agent_health" in tool_names

    @pytest.mark.asyncio
    async def test_skip_kinds_excludes_specified(self):
        server = create_kind_crud_server(
            only_kinds=["Module", "Agent"],
            skip_kinds=["Agent"],
        )
        tools = await server.list_tools()
        tool_names = {t.name for t in tools}

        assert "get_module_manifest" in tool_names
        assert "get_agent_manifest" not in tool_names

    @pytest.mark.asyncio
    async def test_multi_word_kind_tool_names(self):
        # TelemetryBlueprint must be registered in the global registry
        if not kind_registry.is_registered("TelemetryBlueprint"):
            pytest.skip("TelemetryBlueprint not registered in global registry")

        server = create_kind_crud_server(only_kinds=["TelemetryBlueprint"])
        tools = await server.list_tools()
        tool_names = {t.name for t in tools}

        assert "get_telemetry_blueprint_manifest" in tool_names
        assert "list_telemetry_blueprint_manifests" in tool_names

    @pytest.mark.asyncio
    async def test_introspection_tool(self):
        from fastmcp import Client

        server = create_kind_crud_server(only_kinds=["Module"])
        async with Client(server) as client:
            result = await client.call_tool("list_dynamic_kind_tools", {})
        data = json.loads(result.data)
        assert data["totalKinds"] == 1
        assert data["totalTools"] == 4
        assert data["kinds"][0]["kind"] == "Module"

    @pytest.mark.asyncio
    async def test_introspection_tool_with_filter(self):
        from fastmcp import Client

        server = create_kind_crud_server(only_kinds=["Module", "Agent"])
        async with Client(server) as client:
            result = await client.call_tool(
                "list_dynamic_kind_tools", {"filter_text": "agent"}
            )
        data = json.loads(result.data)
        assert data["totalKinds"] == 1
        assert data["kinds"][0]["kind"] == "Agent"

    @pytest.mark.asyncio
    async def test_get_manifest_on_real_dir(self, tmp_path: Path):
        from fastmcp import Client

        # Create a Module manifest
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {
                "name": "test-crud",
                "displayName": "Test CRUD",
                "version": "1.0.0",
                "artifactPrefix": "test-crud.",
            },
            "spec": {},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        server = create_kind_crud_server(only_kinds=["Module"])
        async with Client(server) as client:
            result = await client.call_tool(
                "get_module_manifest", {"manifest_path": str(tmp_path)}
            )
        # Should parse the manifest
        data = json.loads(result.data)
        assert "test-crud" in json.dumps(data)

    @pytest.mark.asyncio
    async def test_validate_manifest_on_real_dir(self, tmp_path: Path):
        from fastmcp import Client

        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {
                "name": "test-val",
                "displayName": "Test Validate",
                "version": "1.0.0",
                "artifactPrefix": "test.",
            },
            "spec": {},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        server = create_kind_crud_server(only_kinds=["Module"])
        async with Client(server) as client:
            result = await client.call_tool(
                "validate_module_manifest", {"manifest_path": str(tmp_path)}
            )
        data = json.loads(result.data)
        assert "valid" in data

    @pytest.mark.asyncio
    async def test_check_health_on_real_dir(self, tmp_path: Path):
        from fastmcp import Client

        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {
                "name": "test-health",
                "version": "1.0.0",
                "artifactPrefix": "test.",
            },
            "spec": {
                "agents": [{"id": "a1"}],
            },
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        server = create_kind_crud_server(only_kinds=["Module"])
        async with Client(server) as client:
            result = await client.call_tool(
                "check_module_health", {"manifest_path": str(tmp_path)}
            )
        data = json.loads(result.data)
        assert "grade" in data
        assert "score" in data
        assert "details" in data
        assert data["kind"] == "Module"

    @pytest.mark.asyncio
    async def test_list_manifests_on_workspace(self, tmp_path: Path):
        from fastmcp import Client

        # Create a .aap/my-mod/manifest.yaml
        mod_dir = tmp_path / ".aap" / "my-mod"
        mod_dir.mkdir(parents=True)
        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "my-mod"},
        }
        (mod_dir / "manifest.yaml").write_text(yaml.dump(manifest))

        server = create_kind_crud_server(
            only_kinds=["Module"],
            workspace_root=str(tmp_path),
        )
        async with Client(server) as client:
            result = await client.call_tool("list_module_manifests", {})
        data = json.loads(result.data)
        assert data["kind"] == "Module"
        assert data["count"] == 1
        assert "my-mod" in data["directories"][0]

    @pytest.mark.asyncio
    async def test_get_manifest_nonexistent_dir(self):
        from fastmcp import Client

        server = create_kind_crud_server(only_kinds=["Module"])
        async with Client(server) as client:
            result = await client.call_tool(
                "get_module_manifest",
                {"manifest_path": "/nonexistent/path/nowhere"},
            )
        data = json.loads(result.data)
        assert "error" in data


# ── Custom Health Checker tests ───────────────────────────────────────────────


class TestCustomHealthChecker:
    @pytest.mark.asyncio
    async def test_custom_checker_is_used(self, tmp_path: Path):
        from fastmcp import Client

        manifest = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "custom-test"},
            "spec": {},
        }
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        def my_custom_checker(manifest_dir: str) -> dict:
            return {
                "kind": "Module",
                "grade": "S",
                "score": 999,
                "maxScore": 999,
                "percentage": 100,
                "details": {"custom": {"score": 999, "maxScore": 999, "issues": []}},
                "topIssues": [],
            }

        register_kind_health_checker("Module", my_custom_checker)
        try:
            server = create_kind_crud_server(only_kinds=["Module"])
            async with Client(server) as client:
                result = await client.call_tool(
                    "check_module_health", {"manifest_path": str(tmp_path)}
                )
            data = json.loads(result.data)
            assert data["grade"] == "S"
            assert data["score"] == 999
        finally:
            # Clean up: remove custom checker
            from cockpit_aap.kind_crud_server import _custom_health_checkers
            _custom_health_checkers.pop("Module", None)
