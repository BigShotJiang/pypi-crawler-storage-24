"""Tests for scanner registration — verifies all 35 kinds are registered correctly.

Validates:
  - All 35 kinds are present (Module + 34 scanners)
  - apiVersion for each kind matches TypeScript
  - Field counts are > 0 for every kind
  - Descriptions are non-empty
  - Samples exist for all kinds
  - to_json_list and to_markdown include all kinds
"""

from __future__ import annotations

import pytest

from cockpit_aap.manifest.kind_registry import kind_registry


# ── Expected kind catalog ──────────────────────────────────────────────────────

EXPECTED_KINDS: dict[str, str] = {
    "Module": "cockpit.io/v1",
    "Agent": "agents.md/v1",
    "AgentCard": "a2a-protocol.org/v1",
    "AuditTrail": "governance.cockpit.io/v1",
    "Blueprint": "planning.cockpit.io/v1",
    "Certificate": "governance.cockpit.io/v1",
    "CodeQuality": "governance.cockpit.io/v1",
    "Compliance": "governance.cockpit.io/v1",
    "ConformancePolicy": "governance.cockpit.io/v1",
    "DataContract": "datacontract.com/v3.0.0",
    "Experiment": "cockpit.io/v1",
    "Guardrail": "cockpit.io/v1",
    "KindDescriptor": "registry.cockpit.io/v1",
    "Lens": "cockpit.io/v1",
    "Lifecycle": "lifecycle.io/v1",
    "ManifestPolicy": "governance.cockpit.io/v1",
    "MCPServer": "modelcontextprotocol.io/v1",
    "MCPTool": "modelcontextprotocol.io/v1",
    "Memory": "mif-spec.dev/v1",
    "Metric": "observability.cockpit.io/v1",
    "ModelCard": "ml.cockpit.io/v1",
    "Package": "code.cockpit.io/v1",
    "Persona": "soulspec.org/v1",
    "Pipeline": "cockpit.io/v1",
    "Policy": "governance.cockpit.io/v1",
    "Prompt": "prompty.ai/v1",
    "RiskProfile": "governance.cockpit.io/v1",
    "SDLC": "sdlc.io/v1",
    "SecurityScan": "governance.cockpit.io/v1",
    "Skill": "agentskills.io/v1",
    "Soul": "soul.md/v1",
    "Task": "cockpit.io/v1",
    "TelemetryBlueprint": "observability.cockpit.io/v1",
    "TestReport": "governance.cockpit.io/v1",
    "ValueStream": "governance.cockpit.io/v1",
}


# ── Tests ──────────────────────────────────────────────────────────────────────


class TestScannerRegistration:
    def test_total_kind_count(self):
        assert len(kind_registry.registered_kinds()) == 36

    @pytest.mark.parametrize("kind,api_version", list(EXPECTED_KINDS.items()))
    def test_kind_registered(self, kind: str, api_version: str):
        assert kind_registry.is_registered(kind), f"{kind} not registered"

    @pytest.mark.parametrize("kind,api_version", list(EXPECTED_KINDS.items()))
    def test_api_version(self, kind: str, api_version: str):
        entry = kind_registry._entries[kind]
        assert entry.api_version == api_version, (
            f"{kind}: expected apiVersion '{api_version}', got '{entry.api_version}'"
        )

    @pytest.mark.parametrize("kind", list(EXPECTED_KINDS.keys()))
    def test_has_fields(self, kind: str):
        entry = kind_registry._entries[kind]
        assert len(entry.fields) > 0, f"{kind} has no fields"

    @pytest.mark.parametrize("kind", list(EXPECTED_KINDS.keys()))
    def test_has_description(self, kind: str):
        entry = kind_registry._entries[kind]
        assert entry.description, f"{kind} has empty description"

    @pytest.mark.parametrize("kind", list(EXPECTED_KINDS.keys()))
    def test_has_sample(self, kind: str):
        entry = kind_registry._entries[kind]
        assert entry.sample is not None, f"{kind} has no sample"

    def test_to_json_list_all_kinds(self):
        result = kind_registry.to_json_list()
        kinds_in_output = {item["kind"] for item in result}
        for kind in EXPECTED_KINDS:
            assert kind in kinds_in_output, f"{kind} missing from to_json_list()"

    def test_to_markdown_all_kinds(self):
        md = kind_registry.to_markdown()
        for kind in EXPECTED_KINDS:
            assert f"kind: {kind}" in md, f"{kind} missing from to_markdown()"

    def test_to_json_roundtrip(self):
        """JSON export should be valid JSON."""
        import json
        json_str = kind_registry.to_json()
        data = json.loads(json_str)
        assert len(data) == 36

    def test_to_yaml_roundtrip(self):
        """YAML export should be valid YAML."""
        import yaml
        yaml_str = kind_registry.to_yaml()
        data = yaml.safe_load(yaml_str)
        assert len(data) == 36

    def test_registered_kinds_sorted(self):
        kinds = kind_registry.registered_kinds()
        assert kinds == sorted(kinds)


class TestScannerFieldQuality:
    """Validate field quality across all registered kinds."""

    @pytest.mark.parametrize("kind", list(EXPECTED_KINDS.keys()))
    def test_metadata_name_required(self, kind: str):
        """Every kind should have metadata.name as required."""
        entry = kind_registry._entries[kind]
        name_field = next(
            (f for f in entry.fields if f.path == "metadata.name"),
            None,
        )
        # Package kind uses spec.path as primary id
        if kind == "Package":
            return
        assert name_field is not None, f"{kind} missing metadata.name field"
        assert name_field.required is True, f"{kind} metadata.name not required"

    @pytest.mark.parametrize("kind", list(EXPECTED_KINDS.keys()))
    def test_fields_have_type(self, kind: str):
        entry = kind_registry._entries[kind]
        for f in entry.fields:
            assert f.type, f"{kind}.{f.path} has no type"

    @pytest.mark.parametrize("kind", list(EXPECTED_KINDS.keys()))
    def test_sample_has_kind(self, kind: str):
        entry = kind_registry._entries[kind]
        if entry.sample:
            assert entry.sample.get("kind") == kind, f"{kind} sample has wrong kind"

    @pytest.mark.parametrize("kind", list(EXPECTED_KINDS.keys()))
    def test_sample_has_api_version(self, kind: str):
        entry = kind_registry._entries[kind]
        if entry.sample:
            assert entry.sample.get("apiVersion") == entry.api_version, (
                f"{kind} sample has wrong apiVersion"
            )
