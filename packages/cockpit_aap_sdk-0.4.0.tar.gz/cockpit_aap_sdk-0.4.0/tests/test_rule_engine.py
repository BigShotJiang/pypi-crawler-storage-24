"""Tests for the Python rule engine (simpleeval-based)."""
from __future__ import annotations

import pytest
from cockpit_aap.manifest.types import Manifest, ManifestRule, ManifestMetadata, ManifestSpec
from cockpit_aap.manifest.rule_engine import compile_manifest_rules, validate_rules, ValidationResult, RuleViolation


def _make_manifest(*rules: ManifestRule) -> Manifest:
    return Manifest(
        metadata=ManifestMetadata(name="test", version="1.0.0", display_name="Test"),
        spec=ManifestSpec(rules=list(rules)),
    )


BLOCK_RULE = ManifestRule(
    id="high-value",
    name="Block high-value",
    condition="amount > 100000 and approver_count < 2",
    enforcement="block",
    scope="input",
    evaluation="deterministic",
    message="Requires dual approval",
    required_actions=["request_approval"],
    hitl_if_unresolved=True,
)

MASK_RULE = ManifestRule(
    id="mask-cpf",
    name="Mask CPF",
    condition="True",
    enforcement="mask",
    scope="output",
    evaluation="deterministic",
    message="CPF masked",
)

WARN_RULE = ManifestRule(
    id="warn-draft",
    name="Warn draft",
    condition="status == 'draft'",
    enforcement="warn",
    scope="input",
    evaluation="deterministic",
)

LOG_RULE = ManifestRule(
    id="log-all",
    name="Log all",
    condition="True",
    enforcement="log",
    scope="input",
    evaluation="deterministic",
)

REDACT_RULE = ManifestRule(
    id="redact-pii",
    name="Redact PII",
    condition="True",
    enforcement="redact",
    scope="output",
    evaluation="deterministic",
)

BOTH_SCOPE_RULE = ManifestRule(
    id="both-scope",
    name="Both scope rule",
    condition="True",
    enforcement="warn",
    scope="both",
    evaluation="deterministic",
)


def test_compile_valid_rules():
    m = _make_manifest(BLOCK_RULE, MASK_RULE, WARN_RULE)
    compile_manifest_rules(m)  # should not raise


def test_compile_raises_on_block_semantic():
    rule = ManifestRule(
        id="bad", name="Bad", condition="true",
        enforcement="block", scope="input", evaluation="semantic"
    )
    manifest = Manifest(
        metadata=ManifestMetadata(name="t", version="1.0.0", display_name="T"),
        spec=ManifestSpec(rules=[rule]),
    )
    with pytest.raises(ValueError, match="block.*deterministic"):
        compile_manifest_rules(manifest)


def test_compile_invalid_rule_raises():
    bad = ManifestRule(
        id="bad",
        name="bad",
        condition="this is @@@@ invalid !!!",
        enforcement="warn",
        scope="input",
        evaluation="deterministic",
    )
    m = _make_manifest(bad)
    with pytest.raises(ValueError) as exc_info:
        compile_manifest_rules(m)
    assert "bad" in str(exc_info.value)       # rule ID
    assert "invalid" in str(exc_info.value)   # part of condition


def test_compile_skips_semantic_rules():
    """Semantic rules with natural-language conditions must NOT be validated by simpleeval."""
    semantic = ManifestRule(
        id="sem",
        name="Semantic",
        condition="Check if the user appears suspicious",
        enforcement="warn",
        scope="input",
        evaluation="semantic",
    )
    m = _make_manifest(semantic)
    compile_manifest_rules(m)  # should not raise for semantic rules


def test_block_rule_fires():
    m = _make_manifest(BLOCK_RULE)
    result = validate_rules(m, "input", {"amount": 200000, "approver_count": 1})
    assert result.allowed is False
    assert len(result.violations) == 1
    assert result.violations[0].rule_id == "high-value"
    assert result.violations[0].enforcement == "block"
    assert "request_approval" in result.required_actions
    assert result.hitl_required is True


def test_block_rule_does_not_fire():
    m = _make_manifest(BLOCK_RULE)
    result = validate_rules(m, "input", {"amount": 50000, "approver_count": 1})
    assert result.allowed is True
    assert len(result.violations) == 0


def test_warn_does_not_block():
    m = _make_manifest(WARN_RULE)
    result = validate_rules(m, "input", {"status": "draft"})
    assert result.allowed is True
    assert len(result.violations) == 1
    assert result.violations[0].enforcement == "warn"


def test_log_enforcement_silent():
    """log enforcement fires but is NOT added to violations."""
    m = _make_manifest(LOG_RULE)
    result = validate_rules(m, "input", {})
    assert result.allowed is True
    assert len(result.violations) == 0


def test_redact_does_not_block():
    """redact fires as a violation but does NOT set allowed=False."""
    m = _make_manifest(REDACT_RULE)
    result = validate_rules(m, "output", {})
    assert result.allowed is True
    assert len(result.violations) == 1
    assert result.violations[0].enforcement == "redact"


def test_scope_both_appears_in_input_and_output():
    m = _make_manifest(BOTH_SCOPE_RULE)
    input_result = validate_rules(m, "input", {})
    output_result = validate_rules(m, "output", {})
    assert any(v.rule_id == "both-scope" for v in input_result.violations)
    assert any(v.rule_id == "both-scope" for v in output_result.violations)


def test_output_scope_filtering():
    m = _make_manifest(BLOCK_RULE, MASK_RULE)
    result = validate_rules(m, "output", {})
    ids = [v.rule_id for v in result.violations]
    assert "high-value" not in ids   # scope:input, should be filtered
    assert "mask-cpf" in ids


def test_agent_filtering():
    agent_rule = ManifestRule(
        id="r1", name="Dev only", condition="True", enforcement="block",
        scope="input", evaluation="deterministic", applies_to=["dev-agent"],
    )
    global_rule = ManifestRule(
        id="r2", name="All agents", condition="True", enforcement="warn",
        scope="input", evaluation="deterministic",
    )
    m = _make_manifest(agent_rule, global_rule)
    result = validate_rules(m, "input", {}, agent_id="po-agent")
    ids = [v.rule_id for v in result.violations]
    assert "r1" not in ids
    assert "r2" in ids


def test_missing_variable_does_not_crash():
    """Missing context variables must be treated as condition not met, not raise."""
    m = _make_manifest(BLOCK_RULE)
    result = validate_rules(m, "input", {})  # amount not in context
    assert result.allowed is True


def test_required_actions_deduplicated():
    """Required actions from multiple violations should be deduplicated."""
    rule1 = ManifestRule(
        id="r1", name="R1", condition="True", enforcement="block",
        scope="input", evaluation="deterministic", required_actions=["approve", "notify"],
    )
    rule2 = ManifestRule(
        id="r2", name="R2", condition="True", enforcement="warn",
        scope="input", evaluation="deterministic", required_actions=["approve"],
    )
    m = _make_manifest(rule1, rule2)
    result = validate_rules(m, "input", {})
    # "approve" should appear only once
    assert result.required_actions.count("approve") == 1
    assert "notify" in result.required_actions
