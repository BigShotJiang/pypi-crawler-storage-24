"""Tests for cockpit_aap.manifest.registry — scan/parse/query."""

import os
import tempfile
import pytest
import yaml

from cockpit_aap.manifest.registry import (
    Registry,
    RegistryModule,
    scan_registry,
    parse_registry,
    resolve_module,
    filter_modules_by_category,
    filter_modules_by_tag,
    search_modules,
)


SAMPLE_REGISTRY_YAML = """\
$schema: "cockpit://registry/v1"
name: test-registry
version: "1.0.0"
owner: test-team
modules:
  - id: mod-alpha
    name: Module Alpha
    description: First module
    source: ./apps/alpha
    version: "1.0.0"
    category: platform
    tags: [ai, wizard]
  - id: mod-beta
    name: Module Beta
    description: Second module for admin
    source: ./apps/beta
    version: "2.0.0"
    category: admin
    tags: [admin]
  - id: mod-gamma
    name: Module Gamma
    description: Third module
    source: ./apps/gamma
    version: "1.0.0"
    category: platform
    tags: [ai]
"""


def test_parse_registry():
    reg = parse_registry(SAMPLE_REGISTRY_YAML)
    assert reg.name == "test-registry"
    assert reg.version == "1.0.0"
    assert reg.owner == "test-team"
    assert len(reg.modules) == 3


def test_parse_registry_invalid_schema():
    with pytest.raises(TypeError, match="Invalid registry schema"):
        parse_registry('$schema: "wrong"\nname: x\nmodules: []')


def test_parse_registry_missing_name():
    with pytest.raises(TypeError, match="name is required"):
        parse_registry('$schema: "cockpit://registry/v1"\nmodules: []')


def test_parse_registry_missing_modules():
    with pytest.raises(TypeError, match="modules array is required"):
        parse_registry('$schema: "cockpit://registry/v1"\nname: x')


def test_scan_registry_from_dir():
    with tempfile.TemporaryDirectory() as tmpdir:
        with open(os.path.join(tmpdir, "registry.yaml"), "w") as f:
            f.write(SAMPLE_REGISTRY_YAML)
        reg = scan_registry(tmpdir)
        assert reg is not None
        assert reg.name == "test-registry"
        assert len(reg.modules) == 3


def test_scan_registry_not_found():
    with tempfile.TemporaryDirectory() as tmpdir:
        result = scan_registry(tmpdir)
        assert result is None


def test_resolve_module():
    reg = parse_registry(SAMPLE_REGISTRY_YAML)
    mod = resolve_module(reg, "mod-beta")
    assert mod is not None
    assert mod.name == "Module Beta"
    assert mod.category == "admin"


def test_resolve_module_not_found():
    reg = parse_registry(SAMPLE_REGISTRY_YAML)
    assert resolve_module(reg, "nonexistent") is None


def test_filter_by_category():
    reg = parse_registry(SAMPLE_REGISTRY_YAML)
    platform = filter_modules_by_category(reg, "platform")
    assert len(platform) == 2
    assert all(m.category == "platform" for m in platform)


def test_filter_by_tag():
    reg = parse_registry(SAMPLE_REGISTRY_YAML)
    ai = filter_modules_by_tag(reg, "ai")
    assert len(ai) == 2
    assert all("ai" in m.tags for m in ai)


def test_search_modules():
    reg = parse_registry(SAMPLE_REGISTRY_YAML)
    results = search_modules(reg, "admin")
    assert len(results) == 1  # mod-beta matches description + tag (same module)
    assert results[0].id == "mod-beta"


def test_search_modules_by_name():
    reg = parse_registry(SAMPLE_REGISTRY_YAML)
    results = search_modules(reg, "Alpha")
    assert len(results) == 1
    assert results[0].id == "mod-alpha"
