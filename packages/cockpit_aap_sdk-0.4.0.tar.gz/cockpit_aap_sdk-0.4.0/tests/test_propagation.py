"""Tests for W3C traceparent propagation helpers."""
import re
import pytest

TRACEPARENT_RE = re.compile(r"^00-[0-9a-f]{32}-[0-9a-f]{16}-01$")


def test_extract_and_inject_roundtrip():
    """inject → extract should preserve traceId."""
    try:
        from opentelemetry import trace
        from opentelemetry.sdk.trace import TracerProvider
    except ImportError:
        pytest.skip("opentelemetry not installed")

    from cockpit_aap.otel.propagation import inject_trace_context, extract_trace_context

    provider = TracerProvider()
    trace.set_tracer_provider(provider)
    tracer = trace.get_tracer("test")

    with tracer.start_as_current_span("root"):
        headers: dict[str, str] = {}
        injected = inject_trace_context(headers)
        assert "traceparent" in injected
        assert TRACEPARENT_RE.match(injected["traceparent"])


def test_extract_returns_none_context_without_header():
    try:
        from cockpit_aap.otel.propagation import extract_trace_context
    except ImportError:
        pytest.skip("opentelemetry not installed")

    ctx = extract_trace_context({})
    assert ctx is not None


def test_graceful_without_otel(monkeypatch):
    """When OTEL is not installed, functions should not crash."""
    import sys
    monkeypatch.setitem(sys.modules, "opentelemetry", None)
    monkeypatch.setitem(sys.modules, "opentelemetry.propagate", None)

    import importlib
    from cockpit_aap.otel import propagation
    importlib.reload(propagation)

    result = propagation.inject_trace_context({})
    assert isinstance(result, dict)
