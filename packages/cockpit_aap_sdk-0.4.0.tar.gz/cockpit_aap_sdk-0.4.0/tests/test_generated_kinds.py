"""Tests for auto-generated per-kind manifest types.

Validates that all 245 per-kind classes from _generated_kinds.py
can be imported and instantiated correctly.
"""

from __future__ import annotations

import inspect

import pytest

from cockpit_aap.manifest import _generated_kinds as kinds
from cockpit_aap.manifest import kind_types


# ── Discovery ──

def _all_classes():
    """Return all dataclass/enum classes from _generated_kinds."""
    return {
        name: obj
        for name, obj in inspect.getmembers(kinds, inspect.isclass)
        if not name.startswith("_")
    }


def _all_dataclasses():
    """Return only dataclass classes (not enums)."""
    import dataclasses
    from enum import Enum
    return {
        name: obj
        for name, obj in _all_classes().items()
        if dataclasses.is_dataclass(obj) and not issubclass(obj, Enum)
    }


def _all_enums():
    """Return only enum classes."""
    from enum import Enum
    return {
        name: obj
        for name, obj in _all_classes().items()
        if issubclass(obj, Enum)
    }


# ── Module-level tests ──

class TestGeneratedKindsModule:
    """Tests for the _generated_kinds module itself."""

    def test_module_has_classes(self):
        classes = _all_classes()
        assert len(classes) >= 200, f"Expected 200+ classes, got {len(classes)}"

    def test_module_accessible_via_kind_types(self):
        """kind_types alias works from manifest __init__."""
        assert kind_types is kinds

    def test_module_has_docstring(self):
        assert kinds.__doc__ is not None
        assert "AUTO-GENERATED" in kinds.__doc__

    def test_no_duplicate_class_names(self):
        """Each class name should appear exactly once."""
        names = [
            name for name, _ in inspect.getmembers(kinds, inspect.isclass)
            if not name.startswith("_")
        ]
        assert len(names) == len(set(names))


# ── Per-kind section tests ──

# Each kind should have at minimum a *Manifest and *Spec class
KIND_MANIFEST_PAIRS = [
    ("AgentManifest", "AgentSpec"),
    ("SkillManifest", "SkillSpec"),
    ("SoulManifest", "SoulSpec"),
    ("MCPToolManifest", "MCPToolSpec"),
    ("MCPServerManifest", "MCPServerSpec"),
    ("PromptManifest", "PromptSpec"),
    ("MemoryManifest", "MemorySpec"),
    ("PersonaManifest", "PersonaSpec"),
    ("GuardrailManifest", "GuardrailSpec"),
    ("PipelineManifest", "PipelineSpec"),
    ("TaskManifest", "TaskSpec"),
    ("LensManifest", "LensSpec"),
    ("PolicyManifest", "PolicySpec"),
    ("ConformancePolicyManifest", "ConformancePolicySpec"),
    ("ManifestPolicyManifest", "ManifestPolicySpec"),
    ("RiskProfileManifest", "RiskProfileSpec"),
    ("ComplianceManifest", "ComplianceSpec"),
    ("AuditTrailManifest", "AuditTrailSpec"),
    ("CertificateManifest", "CertificateSpec"),
    ("MetricManifest", "MetricSpec"),
    ("ExperimentManifest", "ExperimentSpec"),
    ("ModelCardManifest", "ModelCardSpec"),
    ("DataContractManifest", "DataContractSpec"),
    ("ValueStreamManifest", "ValueStreamSpec"),
    ("TelemetryBlueprintManifest", "TelemetryBlueprintSpec"),
    ("BlueprintManifest", "BlueprintSpec"),
    ("PackageManifest", "PackageSpec"),
    ("SDLCManifest", "SDLCSpec"),
    ("KindDescriptorManifest", "KindDescriptorSpec"),
    ("LifecycleManifest", "LifecycleSpec"),
    ("CodeQualityManifest", "CodeQualitySpec"),
    ("SecurityScanManifest", "SecurityScanSpec"),
    ("TestReportManifest", "TestReportSpec"),
    ("AgentCardManifest", "AgentCardSpec"),
]


class TestKindManifestPairs:
    """Each registered kind should have a Manifest + Spec pair."""

    @pytest.mark.parametrize(
        "manifest_cls,spec_cls",
        KIND_MANIFEST_PAIRS,
        ids=[m for m, _ in KIND_MANIFEST_PAIRS],
    )
    def test_manifest_and_spec_exist(self, manifest_cls: str, spec_cls: str):
        assert hasattr(kinds, manifest_cls), f"{manifest_cls} not found"
        assert hasattr(kinds, spec_cls), f"{spec_cls} not found"

    @pytest.mark.parametrize(
        "manifest_cls,spec_cls",
        KIND_MANIFEST_PAIRS,
        ids=[m for m, _ in KIND_MANIFEST_PAIRS],
    )
    def test_manifest_is_dataclass_or_class(self, manifest_cls: str, spec_cls: str):
        import dataclasses
        cls = getattr(kinds, manifest_cls)
        assert dataclasses.is_dataclass(cls) or inspect.isclass(cls), f"{manifest_cls} is not a class"
        scls = getattr(kinds, spec_cls)
        assert dataclasses.is_dataclass(scls) or inspect.isclass(scls), f"{spec_cls} is not a class"

    @pytest.mark.parametrize(
        "manifest_cls,spec_cls",
        KIND_MANIFEST_PAIRS,
        ids=[m for m, _ in KIND_MANIFEST_PAIRS],
    )
    def test_manifest_has_standard_fields(self, manifest_cls: str, spec_cls: str):
        """All *Manifest classes should have api_version, kind, metadata, spec."""
        import dataclasses
        cls = getattr(kinds, manifest_cls)
        field_names = {f.name for f in dataclasses.fields(cls)}
        expected = {"api_version", "kind"}
        missing = expected - field_names
        assert not missing, f"{manifest_cls} missing standard fields: {missing}"


# ── Enum tests ──

EXPECTED_ENUMS = [
    "AgentExecutionKind",
    "ToolTransport",
    "ConnectionAuthType",
    "LensMode",
    "ConformanceSeverity",
    "ExperimentStatus",
    "ComplianceStatus",
    "CertificateStatus",
    "MetricType",
    "MetricUnit",
    "SecurityScanType",
    "TestRunStatus",
]


class TestKindEnums:
    """Enum types should have at least one member."""

    @pytest.mark.parametrize("enum_name", EXPECTED_ENUMS)
    def test_enum_exists_and_has_members(self, enum_name: str):
        from enum import Enum
        cls = getattr(kinds, enum_name, None)
        assert cls is not None, f"{enum_name} not found"
        assert issubclass(cls, Enum), f"{enum_name} is not an Enum"
        assert len(cls) > 0, f"{enum_name} has no members"


# ── Instantiation tests ──

class TestInstantiation:
    """All dataclasses should be instantiable with defaults."""

    def test_instantiate_all_dataclasses(self):
        """Every dataclass in _generated_kinds should be instantiable with defaults or None."""
        import dataclasses
        failed = []
        for name, cls in _all_dataclasses().items():
            try:
                instance = cls()
                assert instance is not None
            except TypeError:
                # Some dataclasses have required fields — try filling with None/defaults
                try:
                    kwargs = {}
                    for f in dataclasses.fields(cls):
                        if f.default is dataclasses.MISSING and f.default_factory is dataclasses.MISSING:
                            kwargs[f.name] = None
                    instance = cls(**kwargs)
                    assert instance is not None
                except Exception as e2:
                    failed.append(f"{name}: {e2}")
        if failed:
            pytest.fail(f"Failed to instantiate {len(failed)} classes:\n" + "\n".join(failed[:10]))

    def test_agent_manifest_roundtrip(self):
        """AgentManifest can be created and its fields accessed."""
        m = kinds.AgentManifest(
            api_version="agents.md/v1",
            kind="Agent",
            metadata=None,
            spec=None,
        )
        assert m.api_version == "agents.md/v1"
        assert m.kind == "Agent"

    def test_skill_manifest_roundtrip(self):
        """SkillManifest with spec."""
        spec = kinds.SkillSpec(instruction="test")
        m = kinds.SkillManifest(
            api_version="skills.cockpit.io/v1",
            kind="Skill",
            metadata=None,
            spec=spec,
        )
        assert m.kind == "Skill"
        assert m.spec is spec

    def test_policy_manifest_roundtrip(self):
        """PolicyManifest with nested spec."""
        m = kinds.PolicyManifest(
            api_version="governance.cockpit.io/v1",
            kind="Policy",
            metadata=None,
            spec=None,
        )
        assert m.api_version == "governance.cockpit.io/v1"

    def test_metric_manifest_roundtrip(self):
        """MetricManifest with enum usage."""
        m = kinds.MetricManifest(
            api_version="telemetry.cockpit.io/v1",
            kind="Metric",
            metadata=None,
            spec=None,
        )
        assert m.kind == "Metric"

    def test_data_contract_manifest(self):
        """DataContractManifest creation."""
        spec = kinds.DataContractSpec(schema=None)
        m = kinds.DataContractManifest(
            api_version="data.cockpit.io/v1",
            kind="DataContract",
            spec=spec,
            metadata=None,
        )
        assert m.spec is spec


# ── Cross-module deduplication ──

class TestDeduplication:
    """Per-kind types should NOT duplicate base types from _generated.py."""

    def test_no_manifest_class_in_kinds(self):
        """The base Manifest class should NOT be in _generated_kinds."""
        assert not hasattr(kinds, "Manifest") or "Manifest" not in _all_dataclasses()

    def test_no_manifest_metadata_in_kinds(self):
        """ManifestMetadata should only exist in _generated.py."""
        from cockpit_aap.manifest import _generated as base
        # ManifestMetadata is a base type — should be in _generated, not _generated_kinds
        assert hasattr(base, "ManifestMetadata")
        # If it exists in kinds, it means dedup failed (tolerate but warn)

    def test_kinds_module_size_reasonable(self):
        """Per-kind module should have significantly fewer classes than base + kinds combined."""
        from cockpit_aap.manifest import _generated as base
        base_count = len([n for n in dir(base) if not n.startswith("_") and inspect.isclass(getattr(base, n))])
        kinds_count = len(_all_classes())
        # kinds should have more than base (it covers 34 kinds vs 1)
        assert kinds_count > base_count * 0.5, "Per-kind module seems too small"


# ── Summary ──

class TestSummary:
    """Aggregate stats for visibility."""

    def test_print_summary(self):
        classes = _all_classes()
        dataclasses_ = _all_dataclasses()
        enums = _all_enums()
        print(f"\n=== Per-Kind Types Summary ===")
        print(f"  Total classes: {len(classes)}")
        print(f"  Dataclasses:   {len(dataclasses_)}")
        print(f"  Enums:         {len(enums)}")
        print(f"  Kind pairs:    {len(KIND_MANIFEST_PAIRS)}")
        assert True
