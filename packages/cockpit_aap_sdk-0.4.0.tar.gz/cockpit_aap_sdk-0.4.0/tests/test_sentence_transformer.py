"""Tests for sentence-transformers integration — adapter, graph semantic, query semantic.

All tests mock the ``sentence_transformers`` library so they run without
downloading any models (~80 MB).  Integration tests with real models would
require ``pip install sentence-transformers`` and are marked with
``@pytest.mark.integration``.
"""

import asyncio
import math
from unittest.mock import MagicMock, patch, AsyncMock

import pytest

from cockpit_aap.adapters.sentence_transformer_embedding import (
    SentenceTransformerEmbeddingAdapter,
    create_sentence_transformer_embedding,
    _MODEL_DIMS,
)


# ===========================================================================
# Helpers — fake numpy array
# ===========================================================================


class FakeNdarray:
    """Minimal fake numpy ndarray that supports .tolist()."""

    def __init__(self, data: list[list[float]]):
        self._data = data
        self.shape = (len(data), len(data[0]) if data else 0)

    def tolist(self) -> list[list[float]]:
        return self._data


def _fake_encode(texts, **kwargs) -> FakeNdarray:
    """Return deterministic embeddings based on text length."""
    dim = 384
    vecs: list[list[float]] = []
    for t in texts:
        # Simple deterministic embedding: each dim = hash of text char
        base = [((ord(c) * (i + 1)) % 100) / 100.0 for i, c in enumerate(t[:dim])]
        base.extend([0.0] * (dim - len(base)))
        # Normalize
        norm = math.sqrt(sum(x * x for x in base)) or 1.0
        vecs.append([x / norm for x in base])
    return FakeNdarray(vecs)


def _make_mock_st_class():
    """Create a mock SentenceTransformer class."""
    mock_model = MagicMock()
    mock_model.encode = _fake_encode
    mock_model.get_sentence_embedding_dimension.return_value = 384

    mock_class = MagicMock(return_value=mock_model)
    return mock_class, mock_model


# ===========================================================================
# SentenceTransformerEmbeddingAdapter
# ===========================================================================


class TestSentenceTransformerEmbeddingAdapter:
    """Unit tests for the adapter itself."""

    def test_factory_creates_adapter(self):
        adapter = create_sentence_transformer_embedding()
        assert isinstance(adapter, SentenceTransformerEmbeddingAdapter)
        assert adapter.model_name == "all-MiniLM-L6-v2"
        assert not adapter.is_loaded

    def test_factory_custom_model(self):
        adapter = create_sentence_transformer_embedding(
            model="paraphrase-multilingual-MiniLM-L12-v2",
            device="cpu",
            batch_size=64,
            normalize=False,
            show_progress=True,
        )
        assert adapter.model_name == "paraphrase-multilingual-MiniLM-L12-v2"

    def test_dimensions_known_model(self):
        adapter = create_sentence_transformer_embedding()
        assert adapter.dimensions == 384

    def test_dimensions_mpnet(self):
        adapter = create_sentence_transformer_embedding(model="all-mpnet-base-v2")
        assert adapter.dimensions == 768

    def test_dimensions_multilingual(self):
        adapter = create_sentence_transformer_embedding(
            model="paraphrase-multilingual-MiniLM-L12-v2"
        )
        assert adapter.dimensions == 384

    def test_dimensions_unknown_model_loads(self):
        """Unknown model should trigger model load to get dimensions."""
        mock_class, mock_model = _make_mock_st_class()
        with patch.dict("sys.modules", {"sentence_transformers": MagicMock(SentenceTransformer=mock_class)}):
            with patch(
                "cockpit_aap.adapters.sentence_transformer_embedding.SentenceTransformerEmbeddingAdapter._get_model",
                return_value=mock_model,
            ):
                adapter = create_sentence_transformer_embedding(model="custom/my-model")
                dims = adapter.dimensions
                assert dims == 384

    def test_repr_lazy(self):
        adapter = create_sentence_transformer_embedding()
        r = repr(adapter)
        assert "lazy" in r
        assert "all-MiniLM-L6-v2" in r
        assert "384" in r

    def test_import_error_without_lib(self):
        """Should raise ImportError with helpful message."""
        adapter = create_sentence_transformer_embedding()
        # Reset model
        adapter._model = None
        with patch.dict("sys.modules", {"sentence_transformers": None}):
            with pytest.raises(ImportError, match="sentence-transformers"):
                adapter._get_model()

    @pytest.mark.asyncio
    async def test_embed_empty_list(self):
        adapter = create_sentence_transformer_embedding()
        result = await adapter.embed([])
        assert result == []

    @pytest.mark.asyncio
    async def test_embed_single_text(self):
        mock_class, mock_model = _make_mock_st_class()
        adapter = create_sentence_transformer_embedding()
        adapter._model = mock_model  # inject mock

        result = await adapter.embed(["hello world"])
        assert len(result) == 1
        assert len(result[0]) == 384
        assert all(isinstance(v, float) for v in result[0])

    @pytest.mark.asyncio
    async def test_embed_multiple_texts(self):
        mock_class, mock_model = _make_mock_st_class()
        adapter = create_sentence_transformer_embedding()
        adapter._model = mock_model

        result = await adapter.embed(["hello", "world", "foo bar baz"])
        assert len(result) == 3
        for vec in result:
            assert len(vec) == 384

    @pytest.mark.asyncio
    async def test_embed_different_texts_different_vectors(self):
        mock_class, mock_model = _make_mock_st_class()
        adapter = create_sentence_transformer_embedding()
        adapter._model = mock_model

        result = await adapter.embed(["hello", "completely different sentence"])
        assert result[0] != result[1]

    @pytest.mark.asyncio
    async def test_embed_uses_thread(self):
        """Verify embed dispatches to asyncio.to_thread."""
        mock_class, mock_model = _make_mock_st_class()
        adapter = create_sentence_transformer_embedding()
        adapter._model = mock_model

        with patch("cockpit_aap.adapters.sentence_transformer_embedding.asyncio") as mock_asyncio:
            mock_asyncio.to_thread = AsyncMock(return_value=FakeNdarray([[0.1] * 384]))
            result = await adapter.embed(["test"])
            mock_asyncio.to_thread.assert_called_once()

    def test_model_dims_cache(self):
        """Dimensions should be cached in _MODEL_DIMS for known models."""
        assert "all-MiniLM-L6-v2" in _MODEL_DIMS
        assert _MODEL_DIMS["all-MiniLM-L6-v2"] == 384
        assert "all-mpnet-base-v2" in _MODEL_DIMS
        assert _MODEL_DIMS["all-mpnet-base-v2"] == 768

    def test_is_loaded_after_model_access(self):
        mock_class, mock_model = _make_mock_st_class()
        adapter = create_sentence_transformer_embedding()
        assert not adapter.is_loaded
        adapter._model = mock_model
        assert adapter.is_loaded


# ===========================================================================
# Semantic Graph (graph/semantic.py)
# ===========================================================================


class TestSemanticGraph:
    """Test the convenience wrappers in graph/semantic.py."""

    @pytest.mark.asyncio
    async def test_build_semantic_graph_with_mock(self, tmp_path):
        """Build a semantic graph with mocked sentence-transformers."""
        from cockpit_aap.graph.semantic import build_semantic_graph

        # Create two minimal manifests
        for name in ["mod-a", "mod-b"]:
            d = tmp_path / name
            d.mkdir()
            (d / "manifest.yaml").write_text(
                f"apiVersion: cockpit.io/v1\n"
                f"kind: Module\n"
                f"metadata:\n"
                f"  name: {name}\n"
                f"  displayName: Module {name.upper()}\n"
                f"  description: A test module for {name}\n"
                f"  version: '1.0.0'\n"
                f"spec:\n"
                f"  agents:\n"
                f"    - id: agent-{name}\n"
                f"      name: Agent {name}\n"
            )

        dirs = [str(tmp_path / "mod-a"), str(tmp_path / "mod-b")]

        # Mock the adapter
        mock_class, mock_model = _make_mock_st_class()
        with patch(
            "cockpit_aap.adapters.sentence_transformer_embedding.create_sentence_transformer_embedding"
        ) as mock_factory:
            mock_adapter = MagicMock()
            mock_adapter.embed = AsyncMock(
                return_value=[[0.1] * 384, [0.2] * 384]
            )
            mock_factory.return_value = mock_adapter

            graph = await build_semantic_graph(dirs)

            assert graph.has_embeddings
            assert len(graph.nodes) == 2
            mock_factory.assert_called_once()

    @pytest.mark.asyncio
    async def test_semantic_search_manifests(self, tmp_path):
        from cockpit_aap.graph.semantic import (
            build_semantic_graph,
            semantic_search_manifests,
        )
        from cockpit_aap.graph.types import ManifestGraph, ManifestNode, ManifestFeatures

        # Pre-built graph with embeddings
        graph = ManifestGraph(
            nodes=[
                ManifestNode(
                    id="feedback",
                    name="Feedback Module",
                    description="User feedback collection",
                    version="1.0.0",
                    features=ManifestFeatures(text_corpus="feedback collection user"),
                    embedding=[0.8, 0.1, 0.1],
                ),
                ManifestNode(
                    id="analytics",
                    name="Analytics Module",
                    description="Data analytics dashboard",
                    version="1.0.0",
                    features=ManifestFeatures(text_corpus="analytics data dashboard"),
                    embedding=[0.1, 0.8, 0.1],
                ),
            ],
            edges=[],
            has_embeddings=True,
        )

        # Mock adapter that returns a query embedding close to "feedback"
        mock_adapter = MagicMock()
        mock_adapter.embed = AsyncMock(return_value=[[0.7, 0.2, 0.1]])

        result = await semantic_search_manifests(
            graph, "user feedback", adapter=mock_adapter
        )
        assert result.query == "user feedback"
        assert len(result.matches) > 0
        # "feedback" should score higher than "analytics"
        if len(result.matches) >= 2:
            assert result.matches[0]["module_id"] == "feedback"


# ===========================================================================
# Import / Export checks
# ===========================================================================


class TestImports:
    def test_adapter_importable_from_adapters(self):
        from cockpit_aap.adapters import (
            SentenceTransformerEmbeddingAdapter,
            create_sentence_transformer_embedding,
        )

        assert SentenceTransformerEmbeddingAdapter is not None

    def test_adapter_importable_from_root(self):
        from cockpit_aap import (
            SentenceTransformerEmbeddingAdapter,
            create_sentence_transformer_embedding,
        )

        assert create_sentence_transformer_embedding is not None

    def test_semantic_graph_importable(self):
        from cockpit_aap.graph import build_semantic_graph, semantic_search_manifests

        assert build_semantic_graph is not None
        assert semantic_search_manifests is not None



# ===========================================================================
# Model dimension lookup
# ===========================================================================


class TestModelDimensions:
    def test_all_known_models(self):
        """All known models should have correct dimensions."""
        expected = {
            "all-MiniLM-L6-v2": 384,
            "all-MiniLM-L12-v2": 384,
            "all-mpnet-base-v2": 768,
            "all-distilroberta-v1": 768,
            "paraphrase-multilingual-MiniLM-L12-v2": 384,
            "paraphrase-multilingual-mpnet-base-v2": 768,
            "multi-qa-mpnet-base-cos-v1": 768,
            "multi-qa-MiniLM-L6-cos-v1": 384,
            "multi-qa-distilbert-cos-v1": 768,
            "msmarco-distilbert-base-v4": 768,
        }
        for model, dims in expected.items():
            adapter = create_sentence_transformer_embedding(model=model)
            assert adapter.dimensions == dims, f"{model} expected {dims}, got {adapter.dimensions}"
