"""Tests for LocalSdk — JSON-file-backed SDK for offline development."""

import os
import json
import pytest
from cockpit_aap.local_sdk import LocalSdk, create_local_sdk


@pytest.fixture
def sdk_dir(tmp_path):
    return str(tmp_path / "local-sdk")


@pytest.fixture
def sdk(sdk_dir):
    return create_local_sdk(sdk_dir)


class TestLocalSdkArtifacts:
    @pytest.mark.asyncio
    async def test_create_and_get(self, sdk):
        await sdk.artifacts.create_artifact(key="my.config", value="hello")
        result = await sdk.artifacts.get_artifact(key_pattern="^my\\.config$")
        arts = result["content"]["artifacts"]
        assert len(arts) == 1
        assert arts[0]["key"] == "my.config"
        assert arts[0]["value"] == "hello"
        assert arts[0]["id"]  # UUID assigned

    @pytest.mark.asyncio
    async def test_skip_conflict(self, sdk):
        await sdk.artifacts.create_artifact(key="k", value="v1", conflict_strategy="SKIP")
        await sdk.artifacts.create_artifact(key="k", value="v2", conflict_strategy="SKIP")
        result = await sdk.artifacts.get_artifact(key_pattern="^k$")
        assert result["content"]["artifacts"][0]["value"] == "v1"

    @pytest.mark.asyncio
    async def test_overwrite_conflict(self, sdk):
        await sdk.artifacts.create_artifact(key="k", value="v1")
        await sdk.artifacts.create_artifact(key="k", value="v2", conflict_strategy="OVERWRITE")
        result = await sdk.artifacts.get_artifact(key_pattern="^k$")
        assert result["content"]["artifacts"][0]["value"] == "v2"

    @pytest.mark.asyncio
    async def test_update(self, sdk):
        r = await sdk.artifacts.create_artifact(key="k", value="v1")
        art_id = r["content"]["id"]
        await sdk.artifacts.update_artifact(id=art_id, value="v2")
        result = await sdk.artifacts.get_artifact(key_pattern="^k$")
        assert result["content"]["artifacts"][0]["value"] == "v2"

    @pytest.mark.asyncio
    async def test_update_nonexistent(self, sdk):
        result = await sdk.artifacts.update_artifact(id="nope", value="v")
        assert result["content"]["success"] is False

    @pytest.mark.asyncio
    async def test_get_no_match(self, sdk):
        result = await sdk.artifacts.get_artifact(key_pattern="^nope$")
        assert result["content"]["artifacts"] == []

    @pytest.mark.asyncio
    async def test_regex_pattern(self, sdk):
        await sdk.artifacts.create_artifact(key="mod.config.a", value="1")
        await sdk.artifacts.create_artifact(key="mod.config.b", value="2")
        await sdk.artifacts.create_artifact(key="other.key", value="3")
        result = await sdk.artifacts.get_artifact(key_pattern="^mod\\.config\\.")
        assert len(result["content"]["artifacts"]) == 2


class TestLocalSdkAgents:
    @pytest.mark.asyncio
    async def test_create_and_search(self, sdk):
        await sdk.agents.create_utility_agent(name="TestAgent", instruction="Do stuff")
        result = await sdk.agents.search_utility_agents(name_pattern="^TestAgent$")
        agents = result["content"]["utility_agents"]
        assert len(agents) == 1
        assert agents[0]["name"] == "TestAgent"

    @pytest.mark.asyncio
    async def test_get_full_agent(self, sdk):
        await sdk.agents.create_utility_agent(name="Agent1", instruction="Hello")
        search = await sdk.agents.search_utility_agents(name_pattern="^Agent1$")
        agent_id = search["content"]["utility_agents"][0]["id"]
        full = await sdk.agents.get_full_utility_agent(utility_agent_id=agent_id)
        assert full["content"]["name"] == "Agent1"
        assert full["content"]["instruction"] == "Hello"

    @pytest.mark.asyncio
    async def test_search_no_match(self, sdk):
        result = await sdk.agents.search_utility_agents(name_pattern="^nope$")
        assert result["content"]["utility_agents"] == []

    @pytest.mark.asyncio
    async def test_list_agent_types(self, sdk):
        result = await sdk.agents.list_agent_types()
        types = result["content"]["agent_types"]
        assert len(types) == 1
        assert types[0]["name"] == "Standard Agent"

    @pytest.mark.asyncio
    async def test_get_nonexistent_agent(self, sdk):
        result = await sdk.agents.get_full_utility_agent(utility_agent_id="nope")
        assert result["content"] == {}


class TestLocalSdkCallTool:
    @pytest.mark.asyncio
    async def test_call_tool(self, sdk):
        await sdk.call_tool("artifacts", "create_artifact", {"key": "k", "value": "v"})
        result = await sdk.call_tool("artifacts", "get_artifact", {"key_pattern": "^k$"})
        assert len(result["content"]["artifacts"]) == 1

    @pytest.mark.asyncio
    async def test_call_tool_bad_namespace(self, sdk):
        with pytest.raises(AttributeError):
            await sdk.call_tool("nonexistent", "get_artifact", {})


class TestLocalSdkPersistence:
    @pytest.mark.asyncio
    async def test_persists_to_file(self, sdk, sdk_dir):
        await sdk.artifacts.create_artifact(key="persist", value="yes")
        # Read directly from file
        db_path = os.path.join(sdk_dir, "local-db.json")
        assert os.path.exists(db_path)
        with open(db_path) as f:
            data = json.load(f)
        assert "persist" in data["artifacts"]

    @pytest.mark.asyncio
    async def test_survives_new_instance(self, sdk_dir):
        sdk1 = create_local_sdk(sdk_dir)
        await sdk1.artifacts.create_artifact(key="survive", value="data")
        sdk2 = create_local_sdk(sdk_dir)
        result = await sdk2.artifacts.get_artifact(key_pattern="^survive$")
        assert result["content"]["artifacts"][0]["value"] == "data"
