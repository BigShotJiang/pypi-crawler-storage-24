"""Tests for cockpit_aap.graph — features, similarity, graph builder, utilities."""

import asyncio

import pytest

from cockpit_aap.graph.types import (
    GraphConfig,
    ManifestEdge,
    ManifestFeatures,
    ManifestGraph,
    ManifestNode,
    ScoreWeights,
    SimilarityBreakdown,
)
from cockpit_aap.graph.features import extract_features
from cockpit_aap.graph.similarity import (
    artifact_similarity,
    compute_score,
    compute_similarity,
    cosine_similarity,
    jaccard_similarity,
    resolve_weights,
)
from cockpit_aap.graph.graph import (
    build_graph_from_manifests,
    find_neighbors,
    get_graph_stats,
    serialize_graph,
    to_mermaid,
)


# =========================================================================
# Feature extraction
# =========================================================================


class TestExtractFeatures:
    def test_empty_manifest(self):
        f = extract_features({})
        assert isinstance(f, ManifestFeatures)
        assert f.text_corpus == ""
        assert f.tool_names == []

    def test_with_agents(self):
        manifest = {
            "spec": {
                "agents": [
                    {"id": "agent-a", "instruction": "Do stuff"},
                    {"id": "agent-b", "instruction": "Do other stuff"},
                ]
            }
        }
        f = extract_features(manifest)
        assert "Do stuff" in f.text_corpus
        assert "Do other stuff" in f.text_corpus

    def test_with_artifacts(self):
        manifest = {
            "spec": {
                "artifacts": [
                    {"key": "mod.config.a", "default_value": "va"},
                    {"key": "mod.config.b", "default_value": "vb"},
                ]
            }
        }
        f = extract_features(manifest)
        assert "mod.config.a" in f.artifact_keys or "mod.config.a" in f.text_corpus

    def test_with_connections(self):
        manifest = {
            "spec": {
                "connections": [
                    {"id": "conn-1", "transport": "mcp"},
                ]
            }
        }
        f = extract_features(manifest)
        assert "conn-1" in f.connection_ids

    def test_with_skills(self):
        manifest = {
            "spec": {
                "skills": [
                    {"id": "skill-a"},
                    {"id": "skill-b"},
                ]
            }
        }
        f = extract_features(manifest)
        assert "skill-a" in f.skill_ids
        assert "skill-b" in f.skill_ids

    def test_with_tags(self):
        manifest = {
            "spec": {
                "labels": {"tags": ["ai", "ml"]}
            }
        }
        f = extract_features(manifest)
        assert "ai" in f.tags
        assert "ml" in f.tags

    def test_with_locales(self):
        manifest = {
            "spec": {
                "i18n": {
                    "defaultLocale": "en",
                    "locales": {
                        "en": {},
                        "pt-BR": {},
                    },
                }
            }
        }
        f = extract_features(manifest)
        assert "en" in f.locales
        assert "pt-BR" in f.locales


# =========================================================================
# Similarity functions
# =========================================================================


class TestCosineSimilarity:
    def test_identical_vectors(self):
        v = [1.0, 2.0, 3.0]
        assert cosine_similarity(v, v) == pytest.approx(1.0, abs=1e-6)

    def test_orthogonal_vectors(self):
        a = [1.0, 0.0]
        b = [0.0, 1.0]
        assert cosine_similarity(a, b) == pytest.approx(0.0, abs=1e-6)

    def test_opposite_vectors(self):
        a = [1.0, 0.0]
        b = [-1.0, 0.0]
        # clamped to 0
        assert cosine_similarity(a, b) == pytest.approx(0.0, abs=1e-6)

    def test_zero_vector(self):
        a = [0.0, 0.0]
        b = [1.0, 2.0]
        assert cosine_similarity(a, b) == 0.0

    def test_empty_vectors(self):
        assert cosine_similarity([], []) == 0.0


class TestJaccardSimilarity:
    def test_identical_sets(self):
        s = ["a", "b", "c"]
        assert jaccard_similarity(s, s) == pytest.approx(1.0)

    def test_disjoint_sets(self):
        assert jaccard_similarity(["a"], ["b"]) == 0.0

    def test_partial_overlap(self):
        assert jaccard_similarity(["a", "b"], ["b", "c"]) == pytest.approx(1 / 3)

    def test_empty_sets(self):
        assert jaccard_similarity([], []) == 0.0


class TestArtifactSimilarity:
    def test_identical_keys(self):
        a = ["mod.config.a", "mod.config.b"]
        assert artifact_similarity(a, a) == pytest.approx(1.0)

    def test_suffix_match(self):
        a = ["foo.config.theme"]
        b = ["bar.config.theme"]
        sim = artifact_similarity(a, b)
        assert sim > 0.0  # suffix overlap contributes


class TestComputeSimilarity:
    def test_same_features(self):
        f = ManifestFeatures(
            text_corpus="hello world",
            tool_names=["tool-a"],
            connection_ids=["conn-1"],
            artifact_keys=["mod.config.a"],
            skill_ids=[],
            command_ids=[],
            hook_events=[],
            tags=["ai"],
            theme_presets=[],
            locales=["en"],
        )
        node = ManifestNode(
            id="test", name="Test", description="", version="1.0",
            manifest={}, manifest_dir="", features=f,
        )
        bd = compute_similarity(node, node)
        assert isinstance(bd, SimilarityBreakdown)
        assert bd.shared_tools > 0

    def test_disjoint_features(self):
        fa = ManifestFeatures(
            text_corpus="alpha",
            tool_names=["t1"],
            connection_ids=[],
            artifact_keys=[],
            skill_ids=[],
            command_ids=[],
            hook_events=[],
            tags=[],
            theme_presets=[],
            locales=[],
        )
        fb = ManifestFeatures(
            text_corpus="beta",
            tool_names=["t2"],
            connection_ids=[],
            artifact_keys=[],
            skill_ids=[],
            command_ids=[],
            hook_events=[],
            tags=[],
            theme_presets=[],
            locales=[],
        )
        node_a = ManifestNode(
            id="a", name="A", description="", version="1.0",
            manifest={}, manifest_dir="", features=fa,
        )
        node_b = ManifestNode(
            id="b", name="B", description="", version="1.0",
            manifest={}, manifest_dir="", features=fb,
        )
        bd = compute_similarity(node_a, node_b)
        assert bd.shared_tools == 0.0


class TestComputeScore:
    def test_perfect_score(self):
        bd = SimilarityBreakdown(
            shared_tools=1.0,
            shared_connections=1.0,
            shared_artifacts=1.0,
            shared_tags=1.0,
            locale_overlap=1.0,
            same_group=True,
            semantic=1.0,
        )
        score = compute_score(bd, resolve_weights(has_embeddings=False))
        assert 0.0 <= score <= 1.0

    def test_zero_score(self):
        bd = SimilarityBreakdown(
            shared_tools=0.0,
            shared_connections=0.0,
            shared_artifacts=0.0,
            shared_tags=0.0,
            locale_overlap=0.0,
            same_group=False,
            semantic=0.0,
        )
        score = compute_score(bd, resolve_weights(has_embeddings=False))
        assert score == pytest.approx(0.0)


class TestResolveWeights:
    def test_without_embeddings(self):
        w = resolve_weights(has_embeddings=False)
        assert w.semantic == 0.0
        assert w.shared_tools > 0

    def test_with_embeddings(self):
        w = resolve_weights(has_embeddings=True)
        assert w.semantic > 0


# =========================================================================
# Graph builder + utilities
# =========================================================================


class TestBuildGraph:
    @pytest.fixture
    def manifests(self):
        return [
            {
                "manifest": {
                    "metadata": {"name": "mod-a", "displayName": "Module A"},
                    "spec": {
                        "agents": [{"id": "a1", "instruction": "Do A"}],
                        "artifacts": [{"key": "a.config.x"}],
                    },
                },
                "manifest_dir": ".aap/mod-a",
            },
            {
                "manifest": {
                    "metadata": {"name": "mod-b", "displayName": "Module B"},
                    "spec": {
                        "agents": [{"id": "b1", "instruction": "Do B"}],
                        "artifacts": [{"key": "b.config.x"}],
                    },
                },
                "manifest_dir": ".aap/mod-b",
            },
        ]

    @pytest.mark.asyncio
    async def test_build_graph_from_manifests(self, manifests):
        config = GraphConfig(min_score=0.0)
        graph = await build_graph_from_manifests(manifests, config)
        assert isinstance(graph, ManifestGraph)
        assert len(graph.nodes) == 2
        assert graph.nodes[0].id == "mod-a"
        assert graph.nodes[1].id == "mod-b"

    @pytest.mark.asyncio
    async def test_find_neighbors(self, manifests):
        config = GraphConfig(min_score=0.0)
        graph = await build_graph_from_manifests(manifests, config)
        result = find_neighbors(graph, "mod-a", limit=5)
        assert result.module_id == "mod-a"

    @pytest.mark.asyncio
    async def test_get_graph_stats(self, manifests):
        config = GraphConfig(min_score=0.0)
        graph = await build_graph_from_manifests(manifests, config)
        stats = get_graph_stats(graph)
        assert stats.node_count == 2
        assert stats.edge_count >= 0

    @pytest.mark.asyncio
    async def test_serialize_graph(self, manifests):
        config = GraphConfig(min_score=0.0)
        graph = await build_graph_from_manifests(manifests, config)
        data = serialize_graph(graph)
        assert isinstance(data, str)
        assert "nodes" in data
        assert "edges" in data

    @pytest.mark.asyncio
    async def test_to_mermaid(self, manifests):
        config = GraphConfig(min_score=0.0)
        graph = await build_graph_from_manifests(manifests, config)
        md = to_mermaid(graph, min_score=0.0)
        assert md.startswith("graph LR")


class TestFindNeighborsEmpty:
    @pytest.mark.asyncio
    async def test_not_found(self):
        graph = ManifestGraph(nodes=[], edges=[])
        result = find_neighbors(graph, "nonexistent", limit=5)
        assert result.module_id == "nonexistent"
        assert len(result.neighbors) == 0
