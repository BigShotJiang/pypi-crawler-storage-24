from cockpit_aap.runtime.cost_callback import CostCallbackHandler


def test_cost_callback_creates_without_db():
    handler = CostCallbackHandler(agent_id="test", tenant_id="acme:t1")
    assert handler.agent_id == "test"
    assert handler.tenant_id == "acme:t1"
    assert handler.database_url is None


def test_cost_callback_on_llm_start_creates_span(monkeypatch):
    pytest = __import__("pytest")
    pytest.importorskip("opentelemetry.sdk.trace", reason="opentelemetry-sdk not installed")

    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4318")
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    trace.set_tracer_provider(TracerProvider())

    handler = CostCallbackHandler(agent_id="test-agent", tenant_id="acme:t1")
    handler.on_llm_start(serialized={}, prompts=[], invocation_params={"model_name": "gpt-5.4"})
    assert handler._current_span is not None
    handler._current_span.end()
