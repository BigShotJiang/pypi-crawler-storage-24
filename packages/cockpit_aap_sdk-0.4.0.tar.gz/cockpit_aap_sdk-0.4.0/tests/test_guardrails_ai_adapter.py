# packages/py/tests/test_guardrails_ai_adapter.py
import pytest
import importlib

has_guardrails = importlib.util.find_spec("guardrails") is not None

@pytest.mark.skipif(not has_guardrails, reason="guardrails-ai not installed")
@pytest.mark.asyncio
async def test_guardrails_ai_adapter():
    from guardrails import Guard
    from cockpit_aap.runtime.guardrails_ai_adapter import GuardrailsAIAdapter
    from cockpit_aap.ports.guardrail import GuardrailContext

    guard = Guard()  # empty guard — passes everything
    adapter = GuardrailsAIAdapter(guard)
    result = await adapter.evaluate_input(GuardrailContext(agent_id="test", input="Hello"))
    assert result.allowed
