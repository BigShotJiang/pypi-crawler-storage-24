"""Tests for bootstrap_agent — granular single-agent bootstrapper."""

import pytest
from cockpit_aap.agent_bootstrapper import (
    AgentDefinition,
    ResolvedAgentGranular,
    bootstrap_agent,
    reset_type_id_cache,
)
from cockpit_aap.local_sdk import create_local_sdk


@pytest.fixture(autouse=True)
def _reset_cache():
    """Reset type_id cache before each test."""
    reset_type_id_cache()
    yield
    reset_type_id_cache()


@pytest.fixture
def sdk(tmp_path):
    return create_local_sdk(str(tmp_path / "test-db"))


def _def(name: str = "TestAgent", instruction: str = "Do the thing", **kw) -> AgentDefinition:
    return AgentDefinition(name=name, default_instruction=instruction, **kw)


class TestBootstrapAgentCreate:
    @pytest.mark.asyncio
    async def test_create_new(self, sdk):
        result = await bootstrap_agent(sdk, "agents", _def())
        assert result.source == "created"
        assert result.name == "TestAgent"
        assert result.instruction == "Do the thing"
        assert result.id  # should have UUID

    @pytest.mark.asyncio
    async def test_existing_returns_server(self, sdk):
        await sdk.agents.create_utility_agent(name="TestAgent", instruction="Server instruction")
        result = await bootstrap_agent(sdk, "agents", _def())
        assert result.source == "server"
        assert result.instruction == "Server instruction"


class TestBootstrapAgentFallback:
    @pytest.mark.asyncio
    async def test_fallback_on_error(self):
        class _BrokenNamespace:
            async def search_utility_agents(self, **kw):
                raise RuntimeError("fail")

            async def create_utility_agent(self, **kw):
                raise RuntimeError("fail")

            async def list_agent_types(self, **kw):
                raise RuntimeError("fail")

        class _BrokenSdk:
            agents = _BrokenNamespace()

            async def call_tool(self, ns, tool, args):
                method = getattr(getattr(self, ns), tool)
                return await method(**args)

        sdk = _BrokenSdk()
        result = await bootstrap_agent(sdk, "agents", _def())
        assert result.source == "default-fallback"
        assert result.instruction == "Do the thing"
        assert result.error is not None


class TestBootstrapAgentTypeResolution:
    @pytest.mark.asyncio
    async def test_uses_standard_type(self, sdk):
        """Agent should be created with Standard Agent type."""
        result = await bootstrap_agent(sdk, "agents", _def(name="TypedAgent"))
        assert result.source == "created"
        # Verify agent was actually created on the local SDK
        search = await sdk.agents.search_utility_agents(name_pattern="^TypedAgent$")
        agents = search["content"]["utility_agents"]
        assert len(agents) == 1
