"""Tests for project helper functions and loadManifestDependencies."""

from __future__ import annotations

import os
import tempfile
from pathlib import Path

import pytest

from cockpit_aap.manifest.helpers import (
    get_project_default_module,
    get_project_enabled_modules,
    get_project_module,
    get_project_module_access,
    get_project_module_connections,
    get_project_module_i18n,
    get_project_module_theme,
)
from cockpit_aap.manifest.dependencies import (
    find_package_root,
    get_package_connections,
    load_manifest_dependencies,
)
from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAccess,
    ManifestConnection,
    ManifestI18n,
    ManifestMetadata,
    ManifestProjectResolved,
    ManifestProjectShared,
    ManifestResolvedModule,
    ManifestSpec,
    ManifestTheme,
    ManifestThemePreset,
)


# ---------------------------------------------------------------------------
# Fixtures for project helpers
# ---------------------------------------------------------------------------


def _make_manifest(
    name: str = "test-module",
    theme: ManifestTheme | None = None,
    i18n: ManifestI18n | None = None,
    access: ManifestAccess | None = None,
    connections: list[ManifestConnection] | None = None,
) -> Manifest:
    return Manifest(
        api_version="cockpit.io/v1",
        kind="Module",
        metadata=ManifestMetadata(name=name, display_name=name),
        spec=ManifestSpec(
            theme=theme,
            i18n=i18n,
            access=access,
            connections=connections,
        ),
    )


def _make_resolved_module(
    id: str,
    default: bool = False,
    enabled: bool = True,
    manifest: Manifest | None = None,
) -> ManifestResolvedModule:
    return ManifestResolvedModule(
        id=id,
        path=f".aap/{id}",
        route=f"/{id}",
        default=default,
        enabled=enabled,
        manifest=manifest,
    )


def _make_project(
    modules: list[ManifestResolvedModule] | None = None,
    shared: ManifestProjectShared | None = None,
) -> ManifestProjectResolved:
    return ManifestProjectResolved(
        modules=modules or [],
        shared=shared,
    )


# ---------------------------------------------------------------------------
# Tests — get_project_default_module
# ---------------------------------------------------------------------------


def test_get_project_default_module_found() -> None:
    project = _make_project([
        _make_resolved_module("mod-a", default=False),
        _make_resolved_module("mod-b", default=True),
        _make_resolved_module("mod-c", default=False),
    ])
    result = get_project_default_module(project)
    assert result is not None
    assert result.id == "mod-b"


def test_get_project_default_module_none() -> None:
    project = _make_project([
        _make_resolved_module("mod-a"),
        _make_resolved_module("mod-b"),
    ])
    assert get_project_default_module(project) is None


def test_get_project_default_module_empty() -> None:
    project = _make_project([])
    assert get_project_default_module(project) is None


# ---------------------------------------------------------------------------
# Tests — get_project_module
# ---------------------------------------------------------------------------


def test_get_project_module_found() -> None:
    project = _make_project([
        _make_resolved_module("mod-a"),
        _make_resolved_module("mod-b"),
    ])
    result = get_project_module(project, "mod-b")
    assert result is not None
    assert result.id == "mod-b"


def test_get_project_module_not_found() -> None:
    project = _make_project([_make_resolved_module("mod-a")])
    assert get_project_module(project, "nonexistent") is None


# ---------------------------------------------------------------------------
# Tests — get_project_enabled_modules
# ---------------------------------------------------------------------------


def test_get_project_enabled_modules() -> None:
    project = _make_project([
        _make_resolved_module("mod-a", enabled=True),
        _make_resolved_module("mod-b", enabled=False),
        _make_resolved_module("mod-c", enabled=True),
    ])
    enabled = get_project_enabled_modules(project)
    assert len(enabled) == 2
    assert [m.id for m in enabled] == ["mod-a", "mod-c"]


# ---------------------------------------------------------------------------
# Tests — get_project_module_theme (fallback to shared)
# ---------------------------------------------------------------------------


def test_get_project_module_theme_from_module() -> None:
    module_theme = ManifestTheme(
        default="dark",
        presets={"dark": ManifestThemePreset(label="Dark")},
    )
    manifest = _make_manifest("mod-a", theme=module_theme)
    project = _make_project([
        _make_resolved_module("mod-a", manifest=manifest),
    ])
    result = get_project_module_theme(project, "mod-a")
    assert result is not None
    assert result.default == "dark"


def test_get_project_module_theme_falls_back_to_shared() -> None:
    shared_theme = ManifestTheme(
        default="light",
        presets={"light": ManifestThemePreset(label="Light")},
    )
    manifest = _make_manifest("mod-a")  # no theme on module
    project = _make_project(
        [_make_resolved_module("mod-a", manifest=manifest)],
        shared=ManifestProjectShared(theme=shared_theme),
    )
    result = get_project_module_theme(project, "mod-a")
    assert result is not None
    assert result.default == "light"


def test_get_project_module_theme_none() -> None:
    project = _make_project([_make_resolved_module("mod-a", manifest=_make_manifest("mod-a"))])
    assert get_project_module_theme(project, "mod-a") is None


def test_get_project_module_theme_not_found() -> None:
    project = _make_project([])
    assert get_project_module_theme(project, "nonexistent") is None


# ---------------------------------------------------------------------------
# Tests — get_project_module_i18n (fallback to shared)
# ---------------------------------------------------------------------------


def test_get_project_module_i18n_from_module() -> None:
    module_i18n = ManifestI18n(default_locale="pt-BR", locales={})
    manifest = _make_manifest("mod-a", i18n=module_i18n)
    project = _make_project([_make_resolved_module("mod-a", manifest=manifest)])
    result = get_project_module_i18n(project, "mod-a")
    assert result is not None
    assert result.default_locale == "pt-BR"


def test_get_project_module_i18n_falls_back_to_shared() -> None:
    shared_i18n = ManifestI18n(default_locale="en", locales={})
    project = _make_project(
        [_make_resolved_module("mod-a", manifest=_make_manifest("mod-a"))],
        shared=ManifestProjectShared(i18n=shared_i18n),
    )
    result = get_project_module_i18n(project, "mod-a")
    assert result is not None
    assert result.default_locale == "en"


# ---------------------------------------------------------------------------
# Tests — get_project_module_access (fallback to shared)
# ---------------------------------------------------------------------------


def test_get_project_module_access_from_module() -> None:
    module_access = ManifestAccess(roles=["admin", "user"])
    manifest = _make_manifest("mod-a", access=module_access)
    project = _make_project([_make_resolved_module("mod-a", manifest=manifest)])
    result = get_project_module_access(project, "mod-a")
    assert result is not None
    assert result.roles == ["admin", "user"]


def test_get_project_module_access_falls_back_to_shared() -> None:
    shared_access = ManifestAccess(roles=["viewer"])
    project = _make_project(
        [_make_resolved_module("mod-a", manifest=_make_manifest("mod-a"))],
        shared=ManifestProjectShared(access=shared_access),
    )
    result = get_project_module_access(project, "mod-a")
    assert result is not None
    assert result.roles == ["viewer"]


# ---------------------------------------------------------------------------
# Tests — get_project_module_connections (fallback to shared)
# ---------------------------------------------------------------------------


def test_get_project_module_connections_from_module() -> None:
    conns = [ManifestConnection(id="conn-1", transport="http", description="DB")]
    manifest = _make_manifest("mod-a", connections=conns)
    project = _make_project([_make_resolved_module("mod-a", manifest=manifest)])
    result = get_project_module_connections(project, "mod-a")
    assert len(result) == 1
    assert result[0].id == "conn-1"


def test_get_project_module_connections_falls_back_to_shared() -> None:
    shared_conns = [ManifestConnection(id="shared-conn", transport="mcp", description="Shared")]
    project = _make_project(
        [_make_resolved_module("mod-a", manifest=_make_manifest("mod-a"))],
        shared=ManifestProjectShared(connections=shared_conns),
    )
    result = get_project_module_connections(project, "mod-a")
    assert len(result) == 1
    assert result[0].id == "shared-conn"


def test_get_project_module_connections_empty() -> None:
    project = _make_project([_make_resolved_module("mod-a", manifest=_make_manifest("mod-a"))])
    assert get_project_module_connections(project, "mod-a") == []


# ---------------------------------------------------------------------------
# Tests — get_package_connections
# ---------------------------------------------------------------------------


def test_get_package_connections_filters_local() -> None:
    manifest = _make_manifest("test", connections=[
        ManifestConnection(id="c1", transport="http", url="http://api"),
        ManifestConnection(id="c2", transport="local", package="@ruinosus/aap-bootstrap"),
        ManifestConnection(id="c3", transport="mcp", url="http://mcp"),
    ])
    result = get_package_connections(manifest)
    assert len(result) == 1
    assert result[0].transport == "local"
    assert result[0].package == "@ruinosus/aap-bootstrap"


def test_get_package_connections_empty() -> None:
    manifest = _make_manifest("test")
    assert get_package_connections(manifest) == []


# ---------------------------------------------------------------------------
# Tests — find_package_root
# ---------------------------------------------------------------------------


def test_find_package_root_found() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        # Create node_modules/pkg/package.json
        pkg_dir = Path(tmp) / "node_modules" / "my-pkg"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "package.json").write_text('{"name": "my-pkg"}')

        result = find_package_root("my-pkg", from_dir=tmp)
        assert result is not None
        assert result == str(pkg_dir)


def test_find_package_root_walks_up() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        # Create root/node_modules/pkg/package.json
        pkg_dir = Path(tmp) / "node_modules" / "my-pkg"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "package.json").write_text('{"name": "my-pkg"}')

        # Search from a nested directory
        nested = Path(tmp) / "src" / "deep"
        nested.mkdir(parents=True)

        result = find_package_root("my-pkg", from_dir=str(nested))
        assert result is not None
        assert result == str(pkg_dir)


def test_find_package_root_not_found() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        result = find_package_root("nonexistent-pkg", from_dir=tmp)
        assert result is None


# ---------------------------------------------------------------------------
# Tests — load_manifest_dependencies
# ---------------------------------------------------------------------------


def test_load_manifest_dependencies_no_local_connections() -> None:
    manifest = _make_manifest("test", connections=[
        ManifestConnection(id="c1", transport="http"),
    ])
    result = load_manifest_dependencies(manifest)
    assert result == []


def test_load_manifest_dependencies_with_manifest() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        # Create node_modules/my-dep/.aap/dep-module/manifest.yaml
        aap_dir = Path(tmp) / "node_modules" / "my-dep" / ".aap" / "dep-module"
        aap_dir.mkdir(parents=True)
        (aap_dir / "manifest.yaml").write_text(
            "apiVersion: cockpit.io/v1\n"
            "kind: Module\n"
            "metadata:\n"
            "  name: dep-module\n"
            "  displayName: Dependency Module\n"
            "spec:\n"
            "  agents:\n"
            "    - id: dep-agent\n"
            "      name: dep-agent\n"
            '      instruction: "I am a dependency agent"\n'
        )

        # Also need package.json for find_package_root
        pkg_dir = Path(tmp) / "node_modules" / "my-dep"
        (pkg_dir / "package.json").write_text('{"name": "my-dep"}')

        # Verify scan_manifest works on the dep
        from cockpit_aap.manifest.scanner import scan_manifest
        dep_manifest = scan_manifest(str(aap_dir))
        assert dep_manifest.metadata.name == "dep-module"

        # Create manifest with a local connection referencing "my-dep"
        manifest = _make_manifest("test", connections=[
            ManifestConnection(id="c1", transport="local", package="my-dep"),
        ])

        results = load_manifest_dependencies(manifest, from_dir=tmp)
        assert len(results) == 1
        assert results[0].module == "dep-module"
        assert results[0].manifest_source == "local"
        assert results[0].duration_ms == 0
        assert "dep-agent" in results[0].agents


def test_load_manifest_dependencies_missing_package(tmp_path: Path) -> None:
    """Should warn and return empty when package not found."""
    manifest = _make_manifest("test", connections=[
        ManifestConnection(id="c1", transport="local", package="nonexistent-pkg"),
    ])
    import warnings
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        results = load_manifest_dependencies(manifest, from_dir=str(tmp_path))
        assert results == []
        assert len(w) >= 1
        assert "not found" in str(w[0].message).lower()


def test_load_manifest_dependencies_no_aap_dir() -> None:
    with tempfile.TemporaryDirectory() as tmp:
        # Package exists but no .aap dir
        pkg_dir = Path(tmp) / "node_modules" / "bare-pkg"
        pkg_dir.mkdir(parents=True)
        (pkg_dir / "package.json").write_text('{"name": "bare-pkg"}')

        manifest = _make_manifest("test", connections=[
            ManifestConnection(id="c1", transport="local", package="bare-pkg"),
        ])

        import warnings
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            results = load_manifest_dependencies(manifest, from_dir=tmp)
            assert results == []
            assert len(w) >= 1
            assert ".aap" in str(w[0].message).lower()


def test_all_project_helpers_importable_from_init() -> None:
    """Verify all project helpers and dependencies are exported from the package root."""
    from cockpit_aap import (  # noqa: F401
        find_package_root,
        get_package_connections,
        get_project_default_module,
        get_project_enabled_modules,
        get_project_module,
        get_project_module_access,
        get_project_module_connections,
        get_project_module_i18n,
        get_project_module_theme,
        load_manifest_dependencies,
    )
