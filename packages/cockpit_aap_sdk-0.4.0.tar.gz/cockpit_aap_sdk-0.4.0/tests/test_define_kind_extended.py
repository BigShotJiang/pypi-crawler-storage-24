"""Extended tests for define_kind() — covers _default_scan edge cases and _default_parse naming."""
from __future__ import annotations

import pytest
import yaml

from cockpit_aap.kinds._shared.define_kind import (
    define_kind,
    infer_domain,
    _default_scan,
    _default_parse,
)


class TestDefaultScanNonMappingYAML:
    """Cover the ValueError branch when YAML content is not a mapping."""

    def test_scan_non_mapping_raises(self, tmp_path):
        (tmp_path / "manifest.yaml").write_text("- item1\n- item2\n")
        scan = _default_scan("Test", "cockpit.io/v1")
        with pytest.raises(ValueError, match="Expected YAML mapping for kind=Test"):
            scan(str(tmp_path))

    def test_scan_scalar_yaml_raises(self, tmp_path):
        (tmp_path / "manifest.yaml").write_text("just a string\n")
        scan = _default_scan("Test", "cockpit.io/v1")
        with pytest.raises(ValueError, match="Expected YAML mapping for kind=Test"):
            scan(str(tmp_path))


class TestDefaultScanFunctionNaming:
    """Verify that auto-generated scan/parse functions have descriptive names."""

    def test_scan_function_name(self):
        scan = _default_scan("Pipeline", "cockpit.io/v1")
        assert scan.__name__ == "scan_pipeline_manifest"
        assert scan.__qualname__ == "scan_pipeline_manifest"

    def test_parse_function_name(self):
        parse = _default_parse("Pipeline")
        assert parse.__name__ == "parse_pipeline_yaml"
        assert parse.__qualname__ == "parse_pipeline_yaml"


class TestDefaultScanAfterScanReturnsNone:
    """Cover after_scan branch where the hook mutates doc in place (returns None)."""

    def test_after_scan_returning_none_keeps_original_doc(self, tmp_path):
        manifest = {"apiVersion": "cockpit.io/v1", "kind": "Test", "metadata": {"name": "x"}}
        (tmp_path / "manifest.yaml").write_text(yaml.dump(manifest))

        def after_scan_mutate(doc, dir_path):
            doc["_extra"] = "injected"
            # returns None — should keep mutated doc

        kind_def = define_kind(
            kind="Test",
            api_version="cockpit.io/v1",
            description="test",
            fields=[],
            after_scan=after_scan_mutate,
        )
        result = kind_def["scan"](str(tmp_path))
        assert result["_extra"] == "injected"
        assert result["kind"] == "Test"


class TestDefineKindWithAllOptions:
    """Cover all keyword arguments simultaneously."""

    def test_all_kwargs(self):
        custom_scan = lambda d: {"custom": True}
        custom_parse = lambda y: {"parsed": True}
        sample = {"apiVersion": "cockpit.io/v1", "kind": "Full"}
        template = "{{metadata.name}}"

        kind_def = define_kind(
            kind="Full",
            api_version="governance.cockpit.io/v1",
            description="Full kind",
            fields=[
                {"path": "metadata.name", "type": "string", "required": True},
            ],
            domain="override-domain",
            scan=custom_scan,
            parse=custom_parse,
            sample=sample,
            default_template=template,
        )

        assert kind_def["kind"] == "Full"
        assert kind_def["api_version"] == "governance.cockpit.io/v1"
        assert kind_def["domain"] == "override-domain"
        assert kind_def["description"] == "Full kind"
        assert kind_def["scan"] is custom_scan
        assert kind_def["parse"] is custom_parse
        assert kind_def["sample"] is sample
        assert kind_def["default_template"] == template


class TestInferDomainEdgeCases:
    def test_single_part_domain(self):
        # e.g. "myhost/v1" has only 1 part before the slash
        assert infer_domain("myhost/v1") == "myhost"

    def test_four_part_domain(self):
        # e.g. "sub.governance.cockpit.io/v1" has 4 parts — first is returned
        assert infer_domain("sub.governance.cockpit.io/v1") == "sub"
