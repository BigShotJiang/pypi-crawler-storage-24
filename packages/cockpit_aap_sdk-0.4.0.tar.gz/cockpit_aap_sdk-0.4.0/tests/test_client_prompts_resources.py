"""Tests for AAPGatewayClient prompt/resource methods."""

from __future__ import annotations

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
from typing import Any

import pytest

from cockpit_aap.client import AAPGatewayClient
from cockpit_aap.mcp_types import PromptSchema, ResourceSchema, ResourceTemplate

SESSION_ID = "client-pr-session"


class MockClientPRHandler(BaseHTTPRequestHandler):
    """Mock MCP server exposing prompts and resources for client tests."""

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        if "id" not in body:
            self.send_response(202)
            self.send_header("Mcp-Session-Id", SESSION_ID)
            self.end_headers()
            return

        method = body.get("method", "")
        req_id = body["id"]
        params = body.get("params", {})

        if method == "initialize":
            self._ok(req_id, {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "serverInfo": {"name": "MockClientPR", "version": "1.0.0"},
            })
        elif method == "tools/list":
            self._ok(req_id, {"tools": [
                {"name": "tool1", "description": "Tool 1", "inputSchema": {}},
            ]})
        elif method == "prompts/list":
            self._ok(req_id, {"prompts": [
                {"name": "greet", "description": "Greeting", "arguments": [
                    {"name": "name", "required": True},
                ]},
            ]})
        elif method == "prompts/get":
            name = params.get("name", "")
            args = params.get("arguments", {})
            self._ok(req_id, {
                "description": f"Result for {name}",
                "messages": [
                    {"role": "assistant", "content": {"type": "text", "text": f"Hello {args.get('name', 'world')}"}},
                ],
            })
        elif method == "resources/list":
            self._ok(req_id, {"resources": [
                {"uri": "data://config", "name": "Config", "mimeType": "application/json"},
            ]})
        elif method == "resources/read":
            self._ok(req_id, {"contents": [
                {"uri": params.get("uri", ""), "mimeType": "application/json", "text": '{"key":"value"}'},
            ]})
        elif method == "resources/templates/list":
            self._ok(req_id, {"resourceTemplates": [
                {"uriTemplate": "data://{type}", "name": "data", "mimeType": "application/json"},
            ]})
        else:
            self._ok(req_id, {})

    def _ok(self, req_id: int, result: Any) -> None:
        payload = json.dumps({"jsonrpc": "2.0", "id": req_id, "result": result}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Mcp-Session-Id", SESSION_ID)
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        pass


@pytest.fixture(scope="module")
def mock_server():
    server = HTTPServer(("127.0.0.1", 0), MockClientPRHandler)
    port = server.server_address[1]
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


@pytest.mark.asyncio
async def test_client_discovers_prompts(mock_server: str) -> None:
    client = AAPGatewayClient(
        endpoint=mock_server,
        token="unused",
        transport="mcp",
        default_namespace="test",
    )
    await client.init()

    prompts = client.get_prompts("test")
    assert len(prompts) == 1
    assert isinstance(prompts[0], PromptSchema)
    assert prompts[0].name == "greet"


@pytest.mark.asyncio
async def test_client_get_prompt_schema(mock_server: str) -> None:
    client = AAPGatewayClient(
        endpoint=mock_server, token="unused", transport="mcp", default_namespace="test",
    )
    await client.init()

    schema = client.get_prompt_schema("test", "greet")
    assert schema is not None
    assert schema.name == "greet"
    assert schema.description == "Greeting"

    # Non-existent prompt
    assert client.get_prompt_schema("test", "nonexistent") is None


@pytest.mark.asyncio
async def test_client_execute_prompt(mock_server: str) -> None:
    client = AAPGatewayClient(
        endpoint=mock_server, token="unused", transport="mcp", default_namespace="test",
    )
    await client.init()

    result = await client.get_prompt("test", "greet", {"name": "Alice"})
    assert result.description == "Result for greet"
    assert len(result.messages) == 1
    assert result.messages[0].content["text"] == "Hello Alice"


@pytest.mark.asyncio
async def test_client_discovers_resources(mock_server: str) -> None:
    client = AAPGatewayClient(
        endpoint=mock_server, token="unused", transport="mcp", default_namespace="test",
    )
    await client.init()

    resources = client.get_resources("test")
    assert len(resources) == 1
    assert isinstance(resources[0], ResourceSchema)
    assert resources[0].uri == "data://config"


@pytest.mark.asyncio
async def test_client_get_resource_schema(mock_server: str) -> None:
    client = AAPGatewayClient(
        endpoint=mock_server, token="unused", transport="mcp", default_namespace="test",
    )
    await client.init()

    schema = client.get_resource_schema("test", "data://config")
    assert schema is not None
    assert schema.name == "Config"

    # Non-existent
    assert client.get_resource_schema("test", "unknown://uri") is None


@pytest.mark.asyncio
async def test_client_read_resource(mock_server: str) -> None:
    client = AAPGatewayClient(
        endpoint=mock_server, token="unused", transport="mcp", default_namespace="test",
    )
    await client.init()

    contents = await client.read_resource("test", "data://config")
    assert len(contents) == 1
    assert contents[0].text == '{"key":"value"}'


@pytest.mark.asyncio
async def test_client_discovers_resource_templates(mock_server: str) -> None:
    client = AAPGatewayClient(
        endpoint=mock_server, token="unused", transport="mcp", default_namespace="test",
    )
    await client.init()

    templates = client.get_resource_templates("test")
    assert len(templates) == 1
    assert isinstance(templates[0], ResourceTemplate)
    assert templates[0].uri_template == "data://{type}"


@pytest.mark.asyncio
async def test_client_empty_namespace_prompts(mock_server: str) -> None:
    client = AAPGatewayClient(
        endpoint=mock_server, token="unused", transport="mcp", default_namespace="test",
    )
    await client.init()

    # Non-existent namespace returns empty
    assert client.get_prompts("nonexistent") == []
    assert client.get_resources("nonexistent") == []
    assert client.get_resource_templates("nonexistent") == []
