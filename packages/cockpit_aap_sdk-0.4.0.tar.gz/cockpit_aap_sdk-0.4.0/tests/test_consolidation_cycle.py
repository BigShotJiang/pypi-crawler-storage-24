"""Tests for consolidation_cycle.py — Python parity with consolidation-cycle.test.ts."""

import asyncio
import math
import pytest

from cockpit_aap.manifest.consolidation_cycle import (
    ConsolidationResult,
    PromotionResult,
    cosine_similarity,
    deduplicate_memories,
    apply_tier_promotions,
    run_consolidation_cycle,
)
from cockpit_aap.manifest.decay_engine import EpisodeMemory


# ── Helpers ────────────────────────────────────────────────────────────────────


def make_episode(**overrides) -> EpisodeMemory:
    defaults = dict(
        session="2026-03-09T10:00:00Z",
        actions=["action-1"],
        importance=0.5,
        tier="buffer",
        decay_epoch=0,
        access_count=0,
        tags=[],
    )
    defaults.update(overrides)
    return EpisodeMemory(**defaults)


def many_synthetic(count: int, tier_pattern=("buffer",)):
    return [
        EpisodeMemory(
            session=f"session-{i}",
            actions=[f"action-{i}", f"sub-action-{i}"],
            importance=0.3 + (i / count) * 0.6,
            tier=tier_pattern[i % len(tier_pattern)],
            decay_epoch=i,
            access_count=i // 2,
            tags=[f"tag-{i % 5}"],
        )
        for i in range(count)
    ]


class MockEmbedding:
    async def embed_batch(self, texts):
        result = []
        for i, t in enumerate(texts):
            angle = (i * math.pi * 2) / max(len(texts), 1)
            result.append([math.cos(angle), math.sin(angle), i * 0.1])
        return result


class MockSimilarEmbedding:
    """Returns very similar vectors for first two, different for rest."""

    async def embed_batch(self, texts):
        vecs = [[1, 0, 0], [0.99, 0.1, 0], [0, 1, 0]]
        return vecs[: len(texts)]


class MockLLM:
    def __init__(self, promote=True):
        self._promote = promote

    async def complete(self, prompt, max_tokens=200):
        import json
        return json.dumps(
            {
                "promote": self._promote,
                "confidence": 0.9 if self._promote else 0.3,
                "reason": "test",
            }
        )


# ── cosine_similarity ──────────────────────────────────────────────────────────


class TestCosineSimilarity:
    def test_identical(self):
        assert cosine_similarity([1, 0, 0], [1, 0, 0]) == pytest.approx(1.0)

    def test_opposite(self):
        assert cosine_similarity([1, 0, 0], [-1, 0, 0]) == pytest.approx(-1.0)

    def test_orthogonal(self):
        assert cosine_similarity([1, 0, 0], [0, 1, 0]) == pytest.approx(0.0)

    def test_empty(self):
        assert cosine_similarity([], []) == 0.0

    def test_zero_vectors(self):
        assert cosine_similarity([0, 0, 0], [0, 0, 0]) == 0.0


# ── deduplicate_memories ───────────────────────────────────────────────────────


class TestDedup:
    @pytest.mark.asyncio
    async def test_dedup_similar(self):
        eps = [
            make_episode(session="s1", actions=["learn TS"], importance=0.8),
            make_episode(session="s2", actions=["learn TS basics"], importance=0.5),
            make_episode(session="s3", actions=["study Python"], importance=0.6),
        ]
        unique, removed = await deduplicate_memories(eps, MockSimilarEmbedding(), 0.5)
        assert removed == 1
        assert len(unique) == 2

    @pytest.mark.asyncio
    async def test_no_dedup_single(self):
        eps = [make_episode()]
        unique, removed = await deduplicate_memories(eps, MockEmbedding())
        assert removed == 0
        assert len(unique) == 1


# ── apply_tier_promotions ──────────────────────────────────────────────────────


class TestTierPromotions:
    @pytest.mark.asyncio
    async def test_buffer_to_working(self):
        eps = [make_episode(tier="buffer", importance=0.5, access_count=3)]
        updated, proms = await apply_tier_promotions(eps)
        assert updated[0].tier == "working"
        assert len(proms) == 1

    @pytest.mark.asyncio
    async def test_core_never_demoted(self):
        eps = [make_episode(tier="core", importance=0.01, access_count=0)]
        updated, proms = await apply_tier_promotions(eps)
        assert updated[0].tier == "core"
        assert len(proms) == 0


# ── run_consolidation_cycle ────────────────────────────────────────────────────


class TestConsolidationCycle:
    @pytest.mark.asyncio
    async def test_full_cycle_50(self):
        eps = many_synthetic(50, ("buffer", "working", "core"))
        spec = {"episodic": [vars(e) for e in eps], "meta": {"lastUpdated": "", "totalSessions": 1}}
        # Convert dataclass keys to camelCase for raw dict
        raw_eps = []
        for e in eps:
            raw_eps.append({
                "session": e.session,
                "actions": e.actions,
                "importance": e.importance,
                "tier": e.tier,
                "decayEpoch": e.decay_epoch,
                "accessCount": e.access_count,
                "tags": e.tags,
            })
        spec["episodic"] = raw_eps

        result = await run_consolidation_cycle(spec)
        assert result.total_before == 50
        assert result.total_after > 0
        assert result.total_after <= 50
        assert result.timestamp

    @pytest.mark.asyncio
    async def test_empty_episodes(self):
        spec = {"episodic": [], "meta": {"lastUpdated": "", "totalSessions": 0}}
        result = await run_consolidation_cycle(spec)
        assert result.total_before == 0
        assert result.total_after == 0

    @pytest.mark.asyncio
    async def test_meta_updated(self):
        spec = {
            "episodic": [
                {"session": "s1", "actions": ["a"], "importance": 0.5, "tier": "buffer", "decayEpoch": 0, "accessCount": 3},
                {"session": "s2", "actions": ["b"], "importance": 0.9, "tier": "core", "decayEpoch": 0, "accessCount": 10},
            ],
            "meta": {"lastUpdated": "", "totalSessions": 1},
        }
        result = await run_consolidation_cycle(spec)
        assert "lastConsolidation" in spec["meta"]
        assert "tierDistribution" in spec["meta"]
        assert spec["meta"]["totalMemories"] > 0

    @pytest.mark.asyncio
    async def test_core_never_archived(self):
        spec = {
            "episodic": [
                {"session": "s1", "actions": ["a"], "importance": 0.01, "tier": "core", "decayEpoch": 999, "accessCount": 0},
            ],
            "meta": {"lastUpdated": "", "totalSessions": 1},
        }
        result = await run_consolidation_cycle(spec)
        core_remaining = [e for e in spec["episodic"] if e["tier"] == "core"]
        assert len(core_remaining) == 1
        assert result.archived == 0

    @pytest.mark.asyncio
    async def test_dedup_with_embedding(self):
        spec = {
            "episodic": [
                {"session": "s1", "actions": ["learn TS"], "importance": 0.8, "tier": "buffer", "decayEpoch": 0, "accessCount": 0},
                {"session": "s2", "actions": ["learn TS basics"], "importance": 0.5, "tier": "buffer", "decayEpoch": 0, "accessCount": 0},
                {"session": "s3", "actions": ["study Python"], "importance": 0.6, "tier": "buffer", "decayEpoch": 0, "accessCount": 0},
            ],
            "consolidation": {"dedup": True, "dedupThreshold": 0.5},
            "meta": {"lastUpdated": "", "totalSessions": 1},
        }
        result = await run_consolidation_cycle(spec, embedding=MockSimilarEmbedding())
        assert result.deduplicated == 1
        assert result.total_after == 2

    @pytest.mark.asyncio
    async def test_performance_100_no_ports(self):
        eps = many_synthetic(100, ("buffer", "working", "core"))
        raw_eps = [
            {
                "session": e.session,
                "actions": e.actions,
                "importance": e.importance,
                "tier": e.tier,
                "decayEpoch": e.decay_epoch,
                "accessCount": e.access_count,
                "tags": e.tags,
            }
            for e in eps
        ]
        spec = {"episodic": raw_eps, "meta": {"lastUpdated": "", "totalSessions": 1}}
        result = await run_consolidation_cycle(spec)
        assert result.duration_ms < 100

    @pytest.mark.asyncio
    async def test_structural_stability(self):
        spec = {
            "episodic": [
                {"session": "s1", "actions": ["a"], "importance": 0.9, "tier": "core", "decayEpoch": 0, "accessCount": 10},
            ],
            "meta": {"lastUpdated": "", "totalSessions": 1},
        }
        r1 = await run_consolidation_cycle(spec)
        tiers1 = [e["tier"] for e in spec["episodic"]]

        r2 = await run_consolidation_cycle(spec)
        tiers2 = [e["tier"] for e in spec["episodic"]]

        assert r1.total_after == r2.total_after
        assert tiers1 == tiers2
