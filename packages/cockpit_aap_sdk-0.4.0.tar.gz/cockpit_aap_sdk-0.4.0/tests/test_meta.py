"""Tests for the meta module — checksum, drift analysis, meta manifest ops."""

from __future__ import annotations

import hashlib

import pytest

from cockpit_aap.meta import (
    BootstrapMeta,
    ConflictInfo,
    DriftInfo,
    MetaAgentEntry,
    MetaArtifactEntry,
    MetaManifest,
    checksum,
    resolve_upgrade_action,
)


# ---------------------------------------------------------------------------
# checksum
# ---------------------------------------------------------------------------


class TestChecksum:
    def test_consistent(self):
        value = "hello world"
        c1 = checksum(value)
        c2 = checksum(value)
        assert c1 == c2
        assert c1.startswith("sha256:")

    def test_matches_hashlib(self):
        value = "test-value"
        expected = "sha256:" + hashlib.sha256(value.encode()).hexdigest()
        assert checksum(value) == expected

    def test_empty_string(self):
        c = checksum("")
        assert c.startswith("sha256:")
        assert len(c) > 10


# ---------------------------------------------------------------------------
# MetaManifest / entries
# ---------------------------------------------------------------------------


class TestMetaManifest:
    def test_create_meta_manifest(self):
        meta = MetaManifest(
            module="test-module",
            code_version="1.0.0",
            bootstrapped_at="2024-01-01T00:00:00Z",
            artifacts={},
            agents={},
        )
        assert meta.module == "test-module"
        assert meta.code_version == "1.0.0"
        assert meta.artifacts == {}

    def test_artifact_entry(self):
        entry = MetaArtifactEntry(
            id="config.theme",
            source="created",
            default_checksum="sha256:abc",
            server_checksum="sha256:abc",
            drifted=False,
            artifact_category="configuration",
        )
        assert entry.id == "config.theme"
        assert entry.default_checksum == entry.server_checksum
        assert not entry.drifted

    def test_agent_entry(self):
        entry = MetaAgentEntry(
            id="dev",
            source="created",
            default_checksum="sha256:abc",
            server_checksum="sha256:abc",
            drifted=False,
        )
        assert entry.id == "dev"
        assert not entry.drifted


# ---------------------------------------------------------------------------
# DriftInfo / ConflictInfo
# ---------------------------------------------------------------------------


class TestDriftInfo:
    def test_create(self):
        info = DriftInfo(
            key="config.theme",
            default_checksum="sha256:aaa",
            server_checksum="sha256:bbb",
            drifted_at="2024-01-15T10:00:00Z",
        )
        assert info.key == "config.theme"
        assert info.default_checksum != info.server_checksum

    def test_conflict_info(self):
        info = ConflictInfo(
            key="config.theme",
            old_default_checksum="sha256:aaa",
            new_default_checksum="sha256:ccc",
            server_checksum="sha256:bbb",
            resolution="server-wins",
        )
        assert info.key == "config.theme"
        assert info.resolution == "server-wins"


class TestBootstrapMeta:
    def test_create_empty(self):
        meta = MetaManifest(
            module="test",
            code_version="1.0.0",
            bootstrapped_at="2024-01-01T00:00:00Z",
        )
        bm = BootstrapMeta(manifest=meta)
        assert bm.drifted_artifacts == {}
        assert bm.conflicts == {}
        assert bm.upgraded == []


# ---------------------------------------------------------------------------
# resolve_upgrade_action
# ---------------------------------------------------------------------------


class TestResolveUpgradeAction:
    """Tests for resolve_upgrade_action(key, new_default, server, old_manifest, strategy)."""

    def _make_manifest(self, key: str, default_cksum: str) -> MetaManifest:
        return MetaManifest(
            module="test",
            code_version="1.0.0",
            bootstrapped_at="2024-01-01T00:00:00Z",
            artifacts={
                key: MetaArtifactEntry(
                    id=key,
                    source="created",
                    default_checksum=default_cksum,
                    server_checksum=default_cksum,
                    drifted=False,
                ),
            },
        )

    def test_no_old_manifest_returns_none(self):
        result = resolve_upgrade_action(
            key="config.theme",
            new_default_checksum="sha256:new",
            current_server_checksum="sha256:srv",
            old_manifest=None,
            strategy="server-wins",
        )
        assert result is None

    def test_new_artifact_returns_none(self):
        old = self._make_manifest("config.other", "sha256:old")
        result = resolve_upgrade_action(
            key="config.theme",
            new_default_checksum="sha256:new",
            current_server_checksum="sha256:srv",
            old_manifest=old,
            strategy="server-wins",
        )
        assert result is None

    def test_no_code_change_returns_skip(self):
        old = self._make_manifest("config.theme", "sha256:same")
        result = resolve_upgrade_action(
            key="config.theme",
            new_default_checksum="sha256:same",
            current_server_checksum="sha256:same",
            old_manifest=old,
            strategy="server-wins",
        )
        assert result == "skip"

    def test_code_changed_no_drift_returns_update(self):
        old = self._make_manifest("config.theme", "sha256:old")
        result = resolve_upgrade_action(
            key="config.theme",
            new_default_checksum="sha256:new",
            current_server_checksum="sha256:old",
            old_manifest=old,
            strategy="server-wins",
        )
        assert result == "update"

    def test_code_changed_server_drifted_returns_strategy(self):
        old = self._make_manifest("config.theme", "sha256:old")
        result = resolve_upgrade_action(
            key="config.theme",
            new_default_checksum="sha256:new",
            current_server_checksum="sha256:drifted",
            old_manifest=old,
            strategy="server-wins",
        )
        assert result == "server-wins"

    def test_code_wins_strategy(self):
        old = self._make_manifest("config.theme", "sha256:old")
        result = resolve_upgrade_action(
            key="config.theme",
            new_default_checksum="sha256:new",
            current_server_checksum="sha256:drifted",
            old_manifest=old,
            strategy="code-wins",
        )
        assert result == "code-wins"

    def test_log_warning_strategy(self):
        old = self._make_manifest("config.theme", "sha256:old")
        result = resolve_upgrade_action(
            key="config.theme",
            new_default_checksum="sha256:new",
            current_server_checksum="sha256:drifted",
            old_manifest=old,
            strategy="log-warning",
        )
        assert result == "log-warning"
