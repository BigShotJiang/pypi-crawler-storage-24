"""Tests for Manifest YAML parser."""

from __future__ import annotations

import pytest

from cockpit_aap.manifest.parser import parse_manifest
from cockpit_aap.manifest.types import Manifest


# ---------------------------------------------------------------------------
# Shared YAML fixture (new format)
# ---------------------------------------------------------------------------

VALID_YAML = """\
apiVersion: cockpit.io/v1
kind: Module
metadata:
  name: test-module
  displayName: Test Module
  version: "1.0.0"
  description: A test module
spec:
  agents:
    - id: agent-1
      name: Agent One
      description: First agent
      instruction: Do something
      runtime: python
      model: openai/gpt-5.2
      tools:
        - research
        - write_file
  artifacts:
    - key: test.config.models
      defaultValue: '{"default":"gpt-5.2"}'
      category: configuration
  connections:
    - id: frontend
      url: http://localhost:3000
      transport: http
"""


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------


def test_parse_valid_yaml() -> None:
    """Parse a full YAML with agents, artifacts, connections."""
    manifest = parse_manifest(VALID_YAML)

    assert isinstance(manifest, Manifest)
    # New-format fields
    assert manifest.metadata.name == "test-module"
    assert manifest.metadata.version == "1.0.0"
    assert manifest.metadata.display_name == "Test Module"

    # Agents
    assert manifest.spec.agents is not None
    assert len(manifest.spec.agents) == 1
    agent = manifest.spec.agents[0]
    assert agent.id == "agent-1"
    assert agent.runtime == "python"
    assert agent.model == "openai/gpt-5.2"
    assert agent.tools == ["research", "write_file"]


def test_parse_missing_apiversion_raises() -> None:
    """No apiVersion field should raise ValueError."""
    yaml_content = """\
kind: Module
metadata:
  name: test-module
  version: "1.0.0"
  displayName: Test Module
  description: A test module
spec: {}
"""
    with pytest.raises(ValueError, match="apiVersion"):
        parse_manifest(yaml_content)


def test_parse_wrong_apiversion_raises() -> None:
    """Wrong apiVersion value should raise ValueError."""
    yaml_content = """\
apiVersion: v2
kind: Module
metadata:
  name: test-module
  version: "1.0.0"
  displayName: Test Module
  description: A test module
spec: {}
"""
    with pytest.raises(ValueError, match="apiVersion"):
        parse_manifest(yaml_content)


def test_parse_old_schema_format_raises() -> None:
    """Old $schema format is no longer supported."""
    yaml_content = """\
$schema: "cockpit://manifest"
module:
  id: test-module
  version: "1.0.0"
  name: Test Module
  description: A test module
"""
    with pytest.raises(ValueError, match="apiVersion"):
        parse_manifest(yaml_content)


def test_parse_missing_metadata_name_raises() -> None:
    """No metadata.name should raise ValueError."""
    yaml_content = """\
apiVersion: cockpit.io/v1
kind: Module
metadata:
  displayName: Test Module
spec: {}
"""
    with pytest.raises(ValueError, match="metadata.name"):
        parse_manifest(yaml_content)


def test_parse_connections() -> None:
    """Verify connections are parsed correctly."""
    manifest = parse_manifest(VALID_YAML)

    assert manifest.spec.connections is not None
    assert len(manifest.spec.connections) == 1
    conn = manifest.spec.connections[0]
    assert conn.id == "frontend"
    assert conn.url == "http://localhost:3000"
    assert conn.transport == "http"


def test_parse_artifacts_camel_to_snake() -> None:
    """Verify camelCase YAML keys (defaultValue) map to snake_case fields (default_value)."""
    manifest = parse_manifest(VALID_YAML)

    assert manifest.spec.artifacts is not None
    assert len(manifest.spec.artifacts) == 1
    artifact = manifest.spec.artifacts[0]
    assert artifact.key == "test.config.models"
    assert artifact.default_value == '{"default":"gpt-5.2"}'
    assert artifact.category == "configuration"


def test_parse_invalid_yaml_raises() -> None:
    """Non-dict YAML (e.g. just a string) should raise ValueError."""
    with pytest.raises(ValueError, match="mapping"):
        parse_manifest("just a string")
