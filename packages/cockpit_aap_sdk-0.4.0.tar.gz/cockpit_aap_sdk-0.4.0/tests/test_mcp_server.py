"""Tests for cockpit_aap.mcp_server — FastMCP manifest server."""

from __future__ import annotations

import pytest

# Skip all tests if fastmcp is not installed
fastmcp = pytest.importorskip("fastmcp", reason="fastmcp not installed; install cockpit-aap-sdk[mcp]")

from types import SimpleNamespace

from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAgent,
    ManifestArtifact,
    ManifestCommand,
    ManifestConnection,
    ManifestHook,
    ManifestI18n,
    ManifestLocale,
    ManifestMetadata,
    ManifestPersonaConfig,
    ManifestPersonas,
    ManifestSkill,
    ManifestSkillAutoInvoke,
    ManifestSpec,
    ManifestTheme,
    ManifestThemeColors,
    ManifestThemePreset,
)
from cockpit_aap.mcp_server import create_manifest_mcp_server


def _make_manifest() -> Manifest:
    """Minimal manifest for testing."""
    return Manifest(
        api_version="cockpit.io/v1",
        kind="Module",
        metadata=ManifestMetadata(
            name="test-module",
            display_name="Test Module",
            version="1.0.0",
            description="A test module",
            artifact_prefix="test.",
        ),
        spec=ManifestSpec(
            agents=[
                ManifestAgent(
                    id="test-agent",
                    name="Test Agent",
                    description="Does testing things",
                    instruction="You are a test agent.",
                ),
                ManifestAgent(
                    id="second-agent",
                    name="Second Agent",
                    description="Another agent",
                    instruction="",
                ),
            ],
            artifacts=[
                ManifestArtifact(
                    key="test.config.settings",
                    description="Module settings",
                    category="configuration",
                    default_value="{}",
                ),
                ManifestArtifact(
                    key="test.state.progress",
                    description="User progress state",
                    category="state",
                    default_value="{}",
                ),
            ],
            skills=[
                ManifestSkill(
                    id="test-skill",
                    name="Test Skill",
                    description="A skill for testing",
                    instruction="Skill instruction here",
                    auto_invoke=ManifestSkillAutoInvoke(triggers=["test", "skill"]),
                ),
            ],
        ),
    )


def test_create_manifest_mcp_server_returns_fastmcp():
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    from fastmcp import FastMCP
    assert isinstance(server, FastMCP)


@pytest.mark.asyncio
async def test_server_has_expected_tools():
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    tools = await server.list_tools()
    tool_names = {t.name for t in tools}
    assert "get_manifest_overview" in tool_names
    assert "get_manifest_agents" in tool_names
    assert "get_agent_instruction" in tool_names
    assert "get_manifest_artifacts" in tool_names
    assert "get_manifest_skills" in tool_names
    assert "get_manifest_connections" in tool_names


@pytest.mark.asyncio
async def test_get_manifest_overview():
    from fastmcp import Client
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_overview", {})
    text = result.data
    assert "Test Module" in text
    assert "test-module" in text
    assert "agents" in text
    assert "artifacts" in text


@pytest.mark.asyncio
async def test_get_manifest_agents_lists_all_agents():
    from fastmcp import Client
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_agents", {})
    text = result.data
    assert "test-agent" in text
    assert "Test Agent" in text
    assert "second-agent" in text


@pytest.mark.asyncio
async def test_get_manifest_agents_empty():
    from fastmcp import Client
    manifest = _make_manifest()
    manifest.spec.agents = []
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_agents", {})
    assert "No agents" in result.data


@pytest.mark.asyncio
async def test_get_agent_instruction_found():
    from fastmcp import Client
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_agent_instruction", {"agent_id": "test-agent"})
    assert "You are a test agent." in result.data


@pytest.mark.asyncio
async def test_get_agent_instruction_not_found():
    from fastmcp import Client
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_agent_instruction", {"agent_id": "nonexistent"})
    text = result.data
    assert "not found" in text.lower()
    assert "test-agent" in text


@pytest.mark.asyncio
async def test_get_manifest_artifacts_all():
    from fastmcp import Client
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_artifacts", {})
    text = result.data
    assert "test.config.settings" in text
    assert "test.state.progress" in text


@pytest.mark.asyncio
async def test_get_manifest_artifacts_filtered_by_category():
    from fastmcp import Client
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_artifacts", {"category": "state"})
    text = result.data
    assert "test.state.progress" in text
    assert "test.config.settings" not in text


@pytest.mark.asyncio
async def test_get_manifest_skills():
    from fastmcp import Client
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_skills", {})
    text = result.data
    assert "test-skill" in text
    assert "Test Skill" in text
    assert "autoInvoke" in text


@pytest.mark.asyncio
async def test_get_manifest_skills_empty():
    from fastmcp import Client
    manifest = _make_manifest()
    manifest.spec.skills = []
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_skills", {})
    assert "No skills" in result.data


@pytest.mark.asyncio
async def test_get_manifest_connections_empty():
    from fastmcp import Client
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_connections", {})
    assert "No connections" in result.data


def test_custom_server_name():
    manifest = _make_manifest()
    server = create_manifest_mcp_server(manifest, name="my-custom-server")
    assert server.name == "my-custom-server"


@pytest.mark.asyncio
async def test_get_manifest_overview_full_manifest():
    """Test get_manifest_overview with all optional spec sections populated."""
    from fastmcp import Client

    manifest = _make_manifest()
    spec = manifest.spec

    # Add optional sections to exercise all branches in get_manifest_overview
    spec.connections = [
        ManifestConnection(id="conn-api", transport="streamable-http", url="https://api.example.com"),
    ]
    spec.personas = ManifestPersonas(
        default_persona="dev",
        definitions=[
            ManifestPersonaConfig(persona_id="dev", display_name="Developer", description="Dev persona"),
        ],
    )
    spec.i18n = ManifestI18n(
        default_locale="en",
        locales={"en": ManifestLocale(), "pt-BR": ManifestLocale()},
    )
    spec.theme = ManifestTheme(
        default="light",
        presets={"light": ManifestThemePreset(label="Light")},
    )
    # recognition, guardrails, telemetry, governance, classification are not yet
    # in ManifestSpec dataclass — set them as dynamic attributes (dataclass has no __slots__)
    spec.recognition = SimpleNamespace(rewards=[SimpleNamespace(action="complete")])  # type: ignore[attr-defined]
    spec.guardrails = SimpleNamespace(rules=[])  # type: ignore[attr-defined]
    spec.telemetry = SimpleNamespace(enabled=True)  # type: ignore[attr-defined]
    spec.governance = SimpleNamespace(entities=[])  # type: ignore[attr-defined]
    spec.classification = SimpleNamespace(level="internal")  # type: ignore[attr-defined]
    spec.hooks = [ManifestHook(event="preToolCall", type="script", script="echo hook")]
    spec.commands = [ManifestCommand(id="build", name="Build", description="Build project", script="npm build")]

    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_overview", {})
    text = result.data

    assert "connections" in text
    assert "personas" in text
    assert "i18n" in text
    assert "theme" in text
    assert "recognition" in text
    assert "guardrails" in text
    assert "telemetry" in text
    assert "governance" in text
    assert "classification" in text
    assert "hooks" in text
    assert "commands" in text


@pytest.mark.asyncio
async def test_get_manifest_artifacts_empty_with_category_filter():
    """Test get_manifest_artifacts returns empty message when category filter matches nothing."""
    from fastmcp import Client

    manifest = _make_manifest()
    # The fixture only has "configuration" and "state" artifacts
    # Call with category="content" which has no matches
    manifest.spec.artifacts = [
        ManifestArtifact(key="test.config.x", default_value="{}", category="configuration"),
    ]
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_artifacts", {"category": "content"})
    text = result.data
    assert "No artifacts" in text
    assert "category='content'" in text


@pytest.mark.asyncio
async def test_get_manifest_skills_manual_trigger():
    """Test get_manifest_skills shows 'trigger: manual' for skills without auto_invoke."""
    from fastmcp import Client

    manifest = _make_manifest()
    manifest.spec.skills = [
        ManifestSkill(
            id="manual-skill",
            name="Manual Skill",
            description="A skill that must be invoked manually",
            instruction="Manual skill instruction",
            auto_invoke=None,  # no triggers
        ),
    ]
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_skills", {})
    text = result.data
    assert "manual-skill" in text
    assert "trigger: manual" in text


@pytest.mark.asyncio
async def test_get_manifest_connections_non_empty():
    """Test get_manifest_connections returns formatted list when connections exist."""
    from fastmcp import Client

    manifest = _make_manifest()
    manifest.spec.connections = [
        ManifestConnection(id="azure-devops", transport="streamable-http", url="https://devops.example.com"),
        ManifestConnection(id="github", transport="rest", url="https://api.github.com"),
    ]
    server = create_manifest_mcp_server(manifest)
    async with Client(server) as client:
        result = await client.call_tool("get_manifest_connections", {})
    text = result.data
    assert "azure-devops" in text
    assert "streamable-http" in text
    assert "https://devops.example.com" in text
    assert "github" in text
    assert "rest" in text


def test_import_error_without_fastmcp(monkeypatch):
    """Verify ImportError is raised with helpful message when fastmcp is missing.

    fastmcp is imported lazily inside create_manifest_mcp_server(), so we only
    need to hide it from sys.modules and call the function — no reload needed.
    """
    import sys

    # Temporarily hide fastmcp from imports
    original = sys.modules.get("fastmcp")
    sys.modules["fastmcp"] = None  # type: ignore[assignment]
    try:
        import cockpit_aap.mcp_server as mcp_module

        manifest = _make_manifest()
        with pytest.raises(ImportError, match="fastmcp is required"):
            mcp_module.create_manifest_mcp_server(manifest)
    finally:
        if original is not None:
            sys.modules["fastmcp"] = original
        elif "fastmcp" in sys.modules:
            del sys.modules["fastmcp"]
