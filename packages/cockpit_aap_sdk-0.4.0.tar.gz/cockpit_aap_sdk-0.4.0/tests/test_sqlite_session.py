"""Tests for cockpit_aap.adapters.sqlite_session — SQLiteSession."""

import os
import tempfile
import time
import pytest

from cockpit_aap.adapters.sqlite_session import SQLiteSession, create_sqlite_session


@pytest.fixture
def db_path():
    with tempfile.TemporaryDirectory() as tmpdir:
        yield os.path.join(tmpdir, "sessions.db")


@pytest.mark.asyncio
async def test_save_and_load(db_path):
    session = create_sqlite_session(db_path)
    await session.save("t1", {"messages": ["hello"]})
    state = await session.load("t1")
    assert state == {"messages": ["hello"]}
    session.close()


@pytest.mark.asyncio
async def test_load_missing(db_path):
    session = SQLiteSession(db_path)
    assert await session.load("nonexistent") is None
    session.close()


@pytest.mark.asyncio
async def test_update_existing(db_path):
    session = SQLiteSession(db_path)
    await session.save("t1", {"v": 1})
    await session.save("t1", {"v": 2})
    state = await session.load("t1")
    assert state == {"v": 2}
    session.close()


@pytest.mark.asyncio
async def test_delete(db_path):
    session = SQLiteSession(db_path)
    await session.save("t1", {"v": 1})
    await session.delete("t1")
    assert await session.load("t1") is None
    session.close()


@pytest.mark.asyncio
async def test_list(db_path):
    session = SQLiteSession(db_path)
    await session.save("thread/a", {"v": 1})
    await session.save("thread/b", {"v": 2})
    await session.save("other/c", {"v": 3})
    all_ids = await session.list()
    assert set(all_ids) == {"thread/a", "thread/b", "other/c"}
    session.close()


@pytest.mark.asyncio
async def test_list_with_prefix(db_path):
    session = SQLiteSession(db_path)
    await session.save("thread/a", {"v": 1})
    await session.save("thread/b", {"v": 2})
    await session.save("other/c", {"v": 3})
    filtered = await session.list("thread/")
    assert set(filtered) == {"thread/a", "thread/b"}
    session.close()


@pytest.mark.asyncio
async def test_prune(db_path):
    session = SQLiteSession(db_path)
    await session.save("old", {"v": 1})
    # Artificially age it by updating updated_at in SQLite
    session._get_db().execute("UPDATE sessions SET updated_at = 0 WHERE thread_id = 'old'")
    session._get_db().commit()
    await session.save("new", {"v": 2})

    deleted = await session.prune(ttl_ms=1_000)
    assert deleted == 1
    assert await session.load("old") is None
    assert await session.load("new") is not None
    session.close()


@pytest.mark.asyncio
async def test_complex_state(db_path):
    session = SQLiteSession(db_path)
    complex_state = {
        "messages": [
            {"role": "user", "content": "hello"},
            {"role": "assistant", "content": "hi"},
        ],
        "metadata": {"model": "gpt-4", "temperature": 0.7},
    }
    await session.save("complex", complex_state)
    loaded = await session.load("complex")
    assert loaded == complex_state
    session.close()


@pytest.mark.asyncio
async def test_db_persists(db_path):
    s1 = SQLiteSession(db_path)
    await s1.save("persist", {"v": 42})
    s1.close()

    s2 = SQLiteSession(db_path)
    state = await s2.load("persist")
    assert state == {"v": 42}
    s2.close()
