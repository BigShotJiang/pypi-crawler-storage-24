"""Tests for scripts/ci-governance-gate.py — CI governance gate Python port."""

from __future__ import annotations

import json
import os
import sys
import tempfile
from pathlib import Path

import pytest
import yaml

# Add scripts dir to path so we can import the module
SCRIPTS_DIR = Path(__file__).resolve().parent.parent.parent.parent / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

# Also ensure the packages/py dir is in path
PY_PKG = Path(__file__).resolve().parent.parent
if str(PY_PKG) not in sys.path:
    sys.path.insert(0, str(PY_PKG))

# Import the CI gate module — use importlib to avoid name conflicts
import importlib.util

_gate_path = str(SCRIPTS_DIR / "ci-governance-gate.py")
_spec = importlib.util.spec_from_file_location(
    "ci_governance_gate",
    _gate_path,
)
gate = importlib.util.module_from_spec(_spec)
# Register the module in sys.modules before exec_module to avoid dataclass issues
sys.modules["ci_governance_gate"] = gate
_spec.loader.exec_module(gate)


# ── Fixtures ─────────────────────────────────────────────────────────────────


@pytest.fixture
def workspace(tmp_path: Path) -> Path:
    """Create a minimal workspace structure with manifests and policies."""

    # .aap/test-module/manifest.yaml
    mod_dir = tmp_path / ".aap" / "test-module"
    mod_dir.mkdir(parents=True)
    (mod_dir / "manifest.yaml").write_text(
        yaml.dump(
            {
                "apiVersion": "cockpit.io/v1",
                "kind": "Module",
                "metadata": {
                    "name": "test-module",
                    "displayName": "Test Module",
                    "version": "1.0.0",
                    "description": "A test module",
                },
                "spec": {
                    "agents": [{"id": "dev", "instruction": "Help users"}],
                    "artifacts": [{"key": "cfg", "defaultValue": "{}"}],
                },
            },
            allow_unicode=True,
        ),
        encoding="utf-8",
    )

    # .aap/minimal-module/manifest.yaml (no agents, no artifacts)
    min_dir = tmp_path / ".aap" / "minimal-module"
    min_dir.mkdir(parents=True)
    (min_dir / "manifest.yaml").write_text(
        yaml.dump(
            {
                "apiVersion": "cockpit.io/v1",
                "kind": "Module",
                "metadata": {
                    "name": "minimal-module",
                    "displayName": "Minimal",
                    "version": "0.1.0",
                },
                "spec": {},
            },
            allow_unicode=True,
        ),
        encoding="utf-8",
    )

    # governance/test-audit/manifest.yaml (non-policy governance manifest)
    audit_dir = tmp_path / "governance" / "test-audit"
    audit_dir.mkdir(parents=True)
    (audit_dir / "manifest.yaml").write_text(
        yaml.dump(
            {
                "apiVersion": "governance.cockpit.io/v1",
                "kind": "AuditTrail",
                "metadata": {"name": "test-audit", "version": "1.0.0"},
                "spec": {},
            },
            allow_unicode=True,
        ),
        encoding="utf-8",
    )

    # governance/policies/test-conformance/manifest.yaml
    conf_dir = tmp_path / "governance" / "policies" / "test-conformance"
    conf_dir.mkdir(parents=True)
    (conf_dir / "manifest.yaml").write_text(
        yaml.dump(
            {
                "apiVersion": "governance.cockpit.io/v1",
                "kind": "ConformancePolicy",
                "metadata": {"name": "test-conformance"},
                "spec": {
                    "appliesTo": {"kind": "Module"},
                    "requirements": [
                        {
                            "id": "has-name",
                            "field": "metadata.name",
                            "severity": "required",
                            "message": "Module must have a name",
                        },
                        {
                            "id": "has-agents",
                            "field": "spec.agents",
                            "severity": "required",
                            "message": "Module must have agents",
                        },
                    ],
                },
            },
            allow_unicode=True,
        ),
        encoding="utf-8",
    )

    # governance/policies/test-mp/manifest.yaml
    mp_dir = tmp_path / "governance" / "policies" / "test-mp"
    mp_dir.mkdir(parents=True)
    (mp_dir / "manifest.yaml").write_text(
        yaml.dump(
            {
                "apiVersion": "governance.cockpit.io/v1",
                "kind": "ManifestPolicy",
                "metadata": {"name": "test-mp"},
                "spec": {
                    "appliesTo": {"kind": "Module"},
                    "requirements": [
                        {
                            "id": "has-description",
                            "type": "fieldExpression",
                            "expression": "metadata.description !== ''",
                            "severity": "recommended",
                            "message": "Module should have a description",
                        },
                    ],
                },
            },
            allow_unicode=True,
        ),
        encoding="utf-8",
    )

    return tmp_path


# ═══════════════════════════════════════════════════════════════════════════════
# Manifest Discovery
# ═══════════════════════════════════════════════════════════════════════════════


class TestFindAllManifestDirs:
    def test_finds_aap_modules(self, workspace: Path):
        dirs = gate.find_all_manifest_dirs(str(workspace))
        names = [os.path.basename(d) for d in dirs]
        assert "test-module" in names
        assert "minimal-module" in names

    def test_finds_governance_manifests(self, workspace: Path):
        dirs = gate.find_all_manifest_dirs(str(workspace))
        names = [os.path.basename(d) for d in dirs]
        assert "test-audit" in names

    def test_excludes_policies_dir(self, workspace: Path):
        dirs = gate.find_all_manifest_dirs(str(workspace))
        names = [os.path.basename(d) for d in dirs]
        assert "test-conformance" not in names
        assert "test-mp" not in names

    def test_finds_app_manifests(self, workspace: Path):
        # Create apps/<app>/.aap/<module>/manifest.yaml
        app_mod = workspace / "apps" / "my-app" / ".aap" / "my-app-module"
        app_mod.mkdir(parents=True)
        (app_mod / "manifest.yaml").write_text(
            yaml.dump(
                {
                    "apiVersion": "cockpit.io/v1",
                    "kind": "Module",
                    "metadata": {"name": "my-app-module", "version": "1.0.0"},
                    "spec": {},
                },
                allow_unicode=True,
            ),
            encoding="utf-8",
        )
        dirs = gate.find_all_manifest_dirs(str(workspace))
        names = [os.path.basename(d) for d in dirs]
        assert "my-app-module" in names

    def test_finds_nested_aap_dirs(self, workspace: Path):
        # .aap/use-cases/uc-1/manifest.yaml
        uc_dir = workspace / ".aap" / "use-cases" / "uc-1"
        uc_dir.mkdir(parents=True)
        (uc_dir / "manifest.yaml").write_text(
            yaml.dump(
                {
                    "apiVersion": "cockpit.io/v1",
                    "kind": "UseCase",
                    "metadata": {"name": "uc-1", "version": "1.0.0"},
                    "spec": {},
                },
                allow_unicode=True,
            ),
            encoding="utf-8",
        )
        dirs = gate.find_all_manifest_dirs(str(workspace))
        names = [os.path.basename(d) for d in dirs]
        assert "uc-1" in names

    def test_empty_workspace(self, tmp_path: Path):
        dirs = gate.find_all_manifest_dirs(str(tmp_path))
        assert dirs == []


class TestFindPolicyDirs:
    def test_finds_policies(self, workspace: Path):
        dirs = gate.find_policy_dirs(str(workspace))
        names = [os.path.basename(d) for d in dirs]
        assert "test-conformance" in names
        assert "test-mp" in names

    def test_no_policies_dir(self, tmp_path: Path):
        dirs = gate.find_policy_dirs(str(tmp_path))
        assert dirs == []


# ═══════════════════════════════════════════════════════════════════════════════
# Policy Loading
# ═══════════════════════════════════════════════════════════════════════════════


class TestLoadPolicies:
    def test_loads_conformance(self, workspace: Path):
        policies = gate.load_policies(str(workspace))
        assert len(policies.conformance) == 1
        assert policies.conformance[0]["metadata"]["name"] == "test-conformance"

    def test_loads_manifest_policy(self, workspace: Path):
        policies = gate.load_policies(str(workspace))
        assert len(policies.manifest_policy) == 1
        assert policies.manifest_policy[0]["metadata"]["name"] == "test-mp"

    def test_loads_from_empty_workspace(self, tmp_path: Path):
        policies = gate.load_policies(str(tmp_path))
        assert len(policies.conformance) == 0
        assert len(policies.manifest_policy) == 0


# ═══════════════════════════════════════════════════════════════════════════════
# Markdown Summary
# ═══════════════════════════════════════════════════════════════════════════════


class TestMarkdownSummary:
    def test_passed_summary(self):
        from cockpit_aap.conformance import HealthResult

        reports = [
            gate.ModuleReport(
                manifest_dir="/fake/dir",
                manifest_id="test",
                manifest_kind="Module",
                health=HealthResult(score=20, max_score=20, percentage=100, grade="A"),
                required_violations=0,
                recommended_violations=0,
                blocked=False,
            ),
        ]
        md = gate.generate_markdown_summary(reports, 2, None, "noop")
        assert "PASSED" in md
        assert "test" in md
        assert "Module" in md

    def test_failed_summary(self):
        from cockpit_aap.conformance import (
            ConformanceResult,
            ConformanceViolation,
            HealthResult,
        )

        reports = [
            gate.ModuleReport(
                manifest_dir="/fake/dir",
                manifest_id="broken",
                manifest_kind="Module",
                health=HealthResult(score=5, max_score=20, percentage=25, grade="F"),
                conformance=[
                    ConformanceResult(
                        policy_name="p1",
                        score=0,
                        max_score=8,
                        percentage=0,
                        grade="F",
                        violations=[
                            ConformanceViolation(
                                requirement_id="r1",
                                field="spec.agents",
                                severity="required",
                                weight=4,
                                message="agents required",
                            ),
                        ],
                    ),
                ],
                required_violations=1,
                recommended_violations=0,
                blocked=True,
            ),
        ]
        md = gate.generate_markdown_summary(reports, 2, None, "noop")
        assert "FAILED" in md
        assert "Blocking Violations" in md
        assert "broken" in md

    def test_min_grade_in_summary(self):
        from cockpit_aap.conformance import HealthResult

        reports = []
        md = gate.generate_markdown_summary(reports, 0, "B", "noop")
        assert "Minimum grade" in md
        assert "B" in md


# ═══════════════════════════════════════════════════════════════════════════════
# _manifest_to_dict
# ═══════════════════════════════════════════════════════════════════════════════


class TestManifestToDict:
    def test_dict_passthrough(self):
        d = {"kind": "Module", "metadata": {"name": "x"}, "spec": {}}
        assert gate._manifest_to_dict(d) is d

    def test_converts_object(self):
        class FakeMeta:
            name = "test"
            displayName = "Test"
            version = "1.0.0"
            description = None
            icon = None
            group = None
            route = None
            artifactPrefix = None
            annotations = None
            labels = None
            display_name = None
            artifact_prefix = None

        class FakeSpec:
            pass

        class FakeManifest:
            kind = "Module"
            api_version = "cockpit.io/v1"
            metadata = FakeMeta()
            spec = FakeSpec()

        result = gate._manifest_to_dict(FakeManifest())
        assert result["kind"] == "Module"
        assert result["apiVersion"] == "cockpit.io/v1"
        assert result["metadata"]["name"] == "test"
