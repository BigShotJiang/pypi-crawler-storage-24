# packages/py/tests/test_tenant_resolver.py
"""Tests for all TenantResolver adapters."""
from __future__ import annotations

import os

import pytest

from cockpit_aap.ports.tenant_resolver import TenantContext, TenantResolverPort
from cockpit_aap.adapters.header_tenant_resolver import HeaderTenantResolver, create_header_tenant_resolver
from cockpit_aap.adapters.env_tenant_resolver import EnvTenantResolver, create_env_tenant_resolver
from cockpit_aap.adapters.composite_tenant_resolver import (
    CompositeTenantResolver,
    NoopTenantResolver,
    create_composite_tenant_resolver,
    create_noop_tenant_resolver,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


class FakeHeaders:
    def __init__(self, data: dict[str, str]) -> None:
        self._data = data

    def get(self, name: str, default: str | None = None) -> str | None:
        return self._data.get(name, default)


class FakeRequest:
    def __init__(self, headers: dict[str, str] | None = None) -> None:
        self.headers = FakeHeaders(headers or {})


# ---------------------------------------------------------------------------
# TenantResolverPort — structural check
# ---------------------------------------------------------------------------


def test_header_resolver_satisfies_protocol() -> None:
    resolver = HeaderTenantResolver()
    assert isinstance(resolver, TenantResolverPort)


def test_env_resolver_satisfies_protocol() -> None:
    resolver = EnvTenantResolver()
    assert isinstance(resolver, TenantResolverPort)


def test_noop_resolver_satisfies_protocol() -> None:
    resolver = NoopTenantResolver()
    assert isinstance(resolver, TenantResolverPort)


def test_composite_resolver_satisfies_protocol() -> None:
    resolver = CompositeTenantResolver([NoopTenantResolver()])
    assert isinstance(resolver, TenantResolverPort)


# ---------------------------------------------------------------------------
# HeaderTenantResolver
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_header_resolver_resolves_default_headers() -> None:
    resolver = create_header_tenant_resolver()
    request = FakeRequest(
        headers={
            "x-cockpit-license-id": "lic-123",
            "x-cockpit-namespace-id": "ns-456",
            "x-cockpit-user-id": "user-789",
            "x-cockpit-roles": "admin, viewer",
        }
    )
    ctx = await resolver.resolve(request)
    assert ctx.license_id == "lic-123"
    assert ctx.namespace_id == "ns-456"
    assert ctx.user_id == "user-789"
    assert ctx.roles == ["admin", "viewer"]


@pytest.mark.asyncio
async def test_header_resolver_resolves_minimal_headers() -> None:
    resolver = create_header_tenant_resolver()
    request = FakeRequest(
        headers={
            "x-cockpit-license-id": "lic-abc",
            "x-cockpit-namespace-id": "ns-def",
        }
    )
    ctx = await resolver.resolve(request)
    assert ctx.license_id == "lic-abc"
    assert ctx.namespace_id == "ns-def"
    assert ctx.user_id is None
    assert ctx.roles == []


@pytest.mark.asyncio
async def test_header_resolver_raises_on_missing_license() -> None:
    resolver = create_header_tenant_resolver()
    request = FakeRequest(headers={"x-cockpit-namespace-id": "ns-456"})
    with pytest.raises(ValueError, match="Missing tenant header: x-cockpit-license-id"):
        await resolver.resolve(request)


@pytest.mark.asyncio
async def test_header_resolver_raises_on_missing_namespace() -> None:
    resolver = create_header_tenant_resolver()
    request = FakeRequest(headers={"x-cockpit-license-id": "lic-123"})
    with pytest.raises(ValueError, match="Missing tenant header: x-cockpit-namespace-id"):
        await resolver.resolve(request)


@pytest.mark.asyncio
async def test_header_resolver_custom_header_names() -> None:
    resolver = create_header_tenant_resolver(
        license_header="x-license",
        namespace_header="x-namespace",
    )
    request = FakeRequest(headers={"x-license": "lic-custom", "x-namespace": "ns-custom"})
    ctx = await resolver.resolve(request)
    assert ctx.license_id == "lic-custom"
    assert ctx.namespace_id == "ns-custom"


# ---------------------------------------------------------------------------
# EnvTenantResolver
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_env_resolver_resolves_env_vars() -> None:
    resolver = create_env_tenant_resolver()
    env_patch = {
        "COCKPIT_LICENSE_ID": "lic-env",
        "COCKPIT_NAMESPACE_ID": "ns-env",
        "COCKPIT_USER_ID": "user-env",
        "COCKPIT_ROLES": "developer, reviewer",
    }
    original = {k: os.environ.get(k) for k in env_patch}
    try:
        for k, v in env_patch.items():
            os.environ[k] = v
        ctx = await resolver.resolve(FakeRequest())
        assert ctx.license_id == "lic-env"
        assert ctx.namespace_id == "ns-env"
        assert ctx.user_id == "user-env"
        assert ctx.roles == ["developer", "reviewer"]
    finally:
        for k, v in original.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


@pytest.mark.asyncio
async def test_env_resolver_minimal() -> None:
    resolver = create_env_tenant_resolver()
    keys_to_clear = ["COCKPIT_LICENSE_ID", "COCKPIT_NAMESPACE_ID", "COCKPIT_USER_ID", "COCKPIT_ROLES"]
    original = {k: os.environ.get(k) for k in keys_to_clear}
    try:
        for k in keys_to_clear:
            os.environ.pop(k, None)
        os.environ["COCKPIT_LICENSE_ID"] = "lic-min"
        os.environ["COCKPIT_NAMESPACE_ID"] = "ns-min"
        ctx = await resolver.resolve(FakeRequest())
        assert ctx.license_id == "lic-min"
        assert ctx.namespace_id == "ns-min"
        assert ctx.user_id is None
        assert ctx.roles == []
    finally:
        for k, v in original.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


@pytest.mark.asyncio
async def test_env_resolver_raises_on_missing_license() -> None:
    resolver = create_env_tenant_resolver()
    original_lic = os.environ.get("COCKPIT_LICENSE_ID")
    original_ns = os.environ.get("COCKPIT_NAMESPACE_ID")
    try:
        os.environ.pop("COCKPIT_LICENSE_ID", None)
        os.environ["COCKPIT_NAMESPACE_ID"] = "ns-x"
        with pytest.raises(ValueError, match="Missing tenant env: COCKPIT_LICENSE_ID"):
            await resolver.resolve(FakeRequest())
    finally:
        if original_lic is None:
            os.environ.pop("COCKPIT_LICENSE_ID", None)
        else:
            os.environ["COCKPIT_LICENSE_ID"] = original_lic
        if original_ns is None:
            os.environ.pop("COCKPIT_NAMESPACE_ID", None)
        else:
            os.environ["COCKPIT_NAMESPACE_ID"] = original_ns


@pytest.mark.asyncio
async def test_env_resolver_raises_on_missing_namespace() -> None:
    resolver = create_env_tenant_resolver()
    original_lic = os.environ.get("COCKPIT_LICENSE_ID")
    original_ns = os.environ.get("COCKPIT_NAMESPACE_ID")
    try:
        os.environ["COCKPIT_LICENSE_ID"] = "lic-x"
        os.environ.pop("COCKPIT_NAMESPACE_ID", None)
        with pytest.raises(ValueError, match="Missing tenant env: COCKPIT_NAMESPACE_ID"):
            await resolver.resolve(FakeRequest())
    finally:
        if original_lic is None:
            os.environ.pop("COCKPIT_LICENSE_ID", None)
        else:
            os.environ["COCKPIT_LICENSE_ID"] = original_lic
        if original_ns is None:
            os.environ.pop("COCKPIT_NAMESPACE_ID", None)
        else:
            os.environ["COCKPIT_NAMESPACE_ID"] = original_ns


@pytest.mark.asyncio
async def test_env_resolver_custom_env_names() -> None:
    resolver = create_env_tenant_resolver(
        license_env="MY_LIC",
        namespace_env="MY_NS",
    )
    original_lic = os.environ.get("MY_LIC")
    original_ns = os.environ.get("MY_NS")
    try:
        os.environ["MY_LIC"] = "lic-custom-env"
        os.environ["MY_NS"] = "ns-custom-env"
        ctx = await resolver.resolve(FakeRequest())
        assert ctx.license_id == "lic-custom-env"
        assert ctx.namespace_id == "ns-custom-env"
    finally:
        if original_lic is None:
            os.environ.pop("MY_LIC", None)
        else:
            os.environ["MY_LIC"] = original_lic
        if original_ns is None:
            os.environ.pop("MY_NS", None)
        else:
            os.environ["MY_NS"] = original_ns


# ---------------------------------------------------------------------------
# NoopTenantResolver
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_noop_resolver_returns_global() -> None:
    resolver = create_noop_tenant_resolver()
    ctx = await resolver.resolve(FakeRequest())
    assert ctx.license_id == "_global"
    assert ctx.namespace_id == "_global"
    assert ctx.user_id is None
    assert ctx.roles == []


@pytest.mark.asyncio
async def test_noop_resolver_accepts_any_request() -> None:
    resolver = create_noop_tenant_resolver()
    ctx = await resolver.resolve(None)  # type: ignore[arg-type]
    assert ctx.license_id == "_global"


# ---------------------------------------------------------------------------
# CompositeTenantResolver
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_composite_returns_first_success() -> None:
    header_resolver = create_header_tenant_resolver()
    noop = create_noop_tenant_resolver()
    composite = create_composite_tenant_resolver([header_resolver, noop])

    request = FakeRequest(
        headers={
            "x-cockpit-license-id": "lic-first",
            "x-cockpit-namespace-id": "ns-first",
        }
    )
    ctx = await composite.resolve(request)
    assert ctx.license_id == "lic-first"
    assert ctx.namespace_id == "ns-first"


@pytest.mark.asyncio
async def test_composite_falls_back_to_noop() -> None:
    header_resolver = create_header_tenant_resolver()
    noop = create_noop_tenant_resolver()
    composite = create_composite_tenant_resolver([header_resolver, noop])

    # No headers — header resolver fails, falls back to noop
    ctx = await composite.resolve(FakeRequest())
    assert ctx.license_id == "_global"
    assert ctx.namespace_id == "_global"


@pytest.mark.asyncio
async def test_composite_raises_when_all_fail() -> None:
    # Both resolvers will fail (no headers, no env)
    header_resolver = create_header_tenant_resolver()
    env_resolver = create_env_tenant_resolver(
        license_env="__NONEXISTENT_LIC__",
        namespace_env="__NONEXISTENT_NS__",
    )
    composite = create_composite_tenant_resolver([header_resolver, env_resolver])

    with pytest.raises(ValueError, match="No resolver could resolve tenant"):
        await composite.resolve(FakeRequest())


def test_composite_requires_at_least_one_resolver() -> None:
    with pytest.raises(ValueError, match="at least one resolver"):
        CompositeTenantResolver([])


# ---------------------------------------------------------------------------
# TenantContext dataclass
# ---------------------------------------------------------------------------


def test_tenant_context_defaults() -> None:
    ctx = TenantContext(license_id="lic", namespace_id="ns")
    assert ctx.user_id is None
    assert ctx.roles == []


def test_tenant_context_equality() -> None:
    ctx1 = TenantContext(license_id="lic", namespace_id="ns", user_id="u", roles=["admin"])
    ctx2 = TenantContext(license_id="lic", namespace_id="ns", user_id="u", roles=["admin"])
    assert ctx1 == ctx2
