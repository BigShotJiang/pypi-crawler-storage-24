"""Tests for cockpit_aap.scribe — agents, quick_match, artifact_patterns, Scribe."""

import asyncio
import json

import pytest

from cockpit_aap.adapters.noop_adapters import create_noop_llm
from cockpit_aap.manifest.types import (
    Manifest,
    ManifestMetadata,
    ManifestSpec,
    ManifestAgent,
    ManifestArtifact,
    ManifestKnowledge,
)
from cockpit_aap.scribe.agents import (
    EnhancedResult,
    RouterDecision,
    run_completion,
    run_compose,
    run_enhanced,
    run_router,
)
from cockpit_aap.scribe.artifact_patterns import build_artifact_patterns_table
from cockpit_aap.scribe.azure_openai_llm import create_azure_openai_llm
from cockpit_aap.scribe.quick_match import quick_match
from cockpit_aap.scribe.scribe import Scribe, create_scribe
from cockpit_aap.scribe.types import ScribeCallOptions, ScribeOptions, ScribeResult


# =========================================================================
# Agents — router
# =========================================================================


class TestRunRouter:
    @pytest.mark.asyncio
    async def test_search_decision(self):
        llm = create_noop_llm("SEARCH|artifact.config.*")
        result = await run_router("decide", llm)
        assert isinstance(result, RouterDecision)
        assert result.decision == "SEARCH"
        assert result.pattern == "artifact.config.*"

    @pytest.mark.asyncio
    async def test_no_search_decision(self):
        llm = create_noop_llm("NO_SEARCH|not relevant")
        result = await run_router("decide", llm)
        assert result.decision == "NO_SEARCH"
        assert result.reason == "not relevant"

    @pytest.mark.asyncio
    async def test_malformed_response(self):
        llm = create_noop_llm("I don't understand")
        result = await run_router("decide", llm)
        assert result.decision == "NO_SEARCH"
        assert result.reason == "malformed_response"

    @pytest.mark.asyncio
    async def test_empty_response(self):
        llm = create_noop_llm("")
        result = await run_router("decide", llm)
        assert result.decision == "NO_SEARCH"


# =========================================================================
# Agents — completion
# =========================================================================


class TestRunCompletion:
    @pytest.mark.asyncio
    async def test_returns_text(self):
        llm = create_noop_llm("hello world")
        result = await run_completion("complete this", llm)
        assert result == "hello world"

    @pytest.mark.asyncio
    async def test_empty_returns_none(self):
        llm = create_noop_llm("")
        result = await run_completion("complete this", llm)
        assert result is None


# =========================================================================
# Agents — compose
# =========================================================================


class TestRunCompose:
    @pytest.mark.asyncio
    async def test_returns_text(self):
        llm = create_noop_llm("# Analysis\n\nThis is a compose.")
        result = await run_compose("compose", llm)
        assert "Analysis" in result


# =========================================================================
# Agents — enhanced
# =========================================================================


class TestRunEnhanced:
    @pytest.mark.asyncio
    async def test_valid_json(self):
        payload = json.dumps(
            {
                "rewrittenIntent": "Do X",
                "keyPoints": ["Point 1", "Point 2"],
                "suggestedFullMessage": "Full message here",
            }
        )
        llm = create_noop_llm(payload)
        result = await run_enhanced("preview", llm)
        assert isinstance(result, EnhancedResult)
        assert result.rewritten_intent == "Do X"
        assert result.key_points == ["Point 1", "Point 2"]
        assert result.suggested_full_message == "Full message here"

    @pytest.mark.asyncio
    async def test_invalid_json_fallback(self):
        llm = create_noop_llm("just raw text")
        result = await run_enhanced("preview", llm)
        assert result.rewritten_intent == "just raw text"
        assert result.suggested_full_message == "just raw text"


# =========================================================================
# Quick match
# =========================================================================


class TestQuickMatch:
    def _manifest_with_skills(self, skills: list[dict]) -> dict:
        return {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "test"},
            "spec": {
                "skills": skills,
            },
        }

    def test_no_skills_returns_none(self):
        m = {
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {"name": "t"},
            "spec": {},
        }
        assert quick_match(m, "hello", "draft") is None

    def test_no_match_returns_none(self):
        m = self._manifest_with_skills(
            [
                {
                    "id": "greet",
                    "trigger": "input_context",
                    "stage": "draft",
                    "ghostTriggers": {"hello": "world"},
                    "instruction": "Hi there!",
                }
            ]
        )
        assert quick_match(m, "goodbye", "draft") is None

    def test_ghost_trigger_match(self):
        m = self._manifest_with_skills(
            [
                {
                    "id": "greet",
                    "trigger": "input_context",
                    "stage": "draft",
                    "ghostTriggers": {"hello": " world"},
                    "instruction": "Hi there!",
                }
            ]
        )
        assert quick_match(m, "hello", "draft") == " world"


# =========================================================================
# Artifact patterns table
# =========================================================================


class TestBuildArtifactPatternsTable:
    def test_empty_manifest(self):
        m = Manifest(
            api_version="cockpit.io/v1",
            kind="Module",
            metadata=ManifestMetadata(name="t"),
            spec=ManifestSpec(),
        )
        result = build_artifact_patterns_table(m)
        assert isinstance(result, str)

    def test_with_knowledge(self):
        m = Manifest(
            api_version="cockpit.io/v1",
            kind="Module",
            metadata=ManifestMetadata(name="t"),
            spec=ManifestSpec(
                knowledge=[
                    ManifestKnowledge(kind="artifact", key_pattern="*.config.*", description="Config items")
                ]
            ),
        )
        result = build_artifact_patterns_table(m)
        assert "config" in result.lower() or "Config" in result


# =========================================================================
# Azure OpenAI factory
# =========================================================================


class TestCreateAzureOpenAILLM:
    def test_creates_adapter(self):
        adapter = create_azure_openai_llm(
            api_key="test-key",
            endpoint="https://my-resource.openai.azure.com",
            deployment="gpt-4",
        )
        assert adapter is not None
        assert adapter._default_model == "gpt-4"
        assert "my-resource" in (adapter._base_url or "")
        assert "gpt-4" in (adapter._base_url or "")


# =========================================================================
# Scribe — factory + quick_match
# =========================================================================


class TestScribe:
    def _make_manifest(self) -> Manifest:
        return Manifest(
            api_version="cockpit.io/v1",
            kind="Module",
            metadata=ManifestMetadata(
                name="test-scribe",
                display_name="Test Scribe",
                version="1.0.0",
            ),
            spec=ManifestSpec(
                agents=[
                    ManifestAgent(id="scribe-router", name="Scribe Router", instruction="Route: {{text}}"),
                    ManifestAgent(id="scribe-completion", name="Scribe Completion", instruction="Complete: {{text}}"),
                    ManifestAgent(id="scribe-compose", name="Scribe Compose", instruction="Compose: {{text}}"),
                    ManifestAgent(id="scribe-enhanced", name="Scribe Enhanced", instruction="Enhanced: {{text}}"),
                ],
            ),
        )

    def test_create_scribe(self):
        llm = create_noop_llm("ok")
        scribe = create_scribe(ScribeOptions(llm=llm))
        assert isinstance(scribe, Scribe)

    def test_create_scribe_with_manifest(self):
        llm = create_noop_llm("ok")
        m = self._make_manifest()
        scribe = create_scribe(ScribeOptions(llm=llm, manifest=m))
        assert isinstance(scribe, Scribe)

    def test_quick_match_returns_none(self):
        llm = create_noop_llm("ok")
        scribe = create_scribe(ScribeOptions(llm=llm))
        assert scribe.quick_match("hello", "draft") is None

    @pytest.mark.asyncio
    async def test_complete(self):
        llm = create_noop_llm("NO_SEARCH|no")
        m = self._make_manifest()
        scribe = create_scribe(ScribeOptions(llm=llm, manifest=m))
        result = await scribe.complete(
            "write something",
            ScribeCallOptions(stage="draft"),
        )
        assert isinstance(result, ScribeResult)
        assert result.source == "llm-direct"

    @pytest.mark.asyncio
    async def test_compose(self):
        llm = create_noop_llm("NO_SEARCH|no")
        m = self._make_manifest()
        scribe = create_scribe(ScribeOptions(llm=llm, manifest=m))
        result = await scribe.compose(
            "analyze this",
            ScribeCallOptions(stage="review"),
        )
        assert isinstance(result, ScribeResult)
        assert result.confidence == 0.75

    @pytest.mark.asyncio
    async def test_preview(self):
        # The noop LLM returns the same response for all calls.
        # For enhanced, it returns malformed JSON, so it falls back to raw text.
        llm = create_noop_llm("NO_SEARCH|no")
        m = self._make_manifest()
        scribe = create_scribe(ScribeOptions(llm=llm, manifest=m))
        result = await scribe.preview(
            "preview this",
            ScribeCallOptions(stage="draft"),
        )
        assert isinstance(result, ScribeResult)
        assert result.confidence == 0.85
