"""Extended tests for agent_runtime.py — covers helper functions and more runtime paths."""
from __future__ import annotations

import pytest

from cockpit_aap.runtime.agent_runtime import (
    create_agent_runtime,
    _get_cfg_field,
    _resolve_guardrail_rules,
    _resolve_has_telemetry,
    _resolve_has_cost,
    _record_guardrail_event,
    _end_span_and_cleanup,
    _blocked_decision,
    _resolve_tenant,
    _NoopGuardrail,
    _NoopTelemetry,
    _NoopCostTracker,
)
from cockpit_aap.runtime.types import RuntimeContext, RuntimeResult, RuntimeDecision, ToolCallInfo
from cockpit_aap.ports.agent_telemetry import SpanHandle, AgentEvent, AgentSpanResult
from cockpit_aap.ports.guardrail import GuardrailDecision, GuardrailViolation


# ── _get_cfg_field ───────────────────────────────────────────────────────────


class TestGetCfgField:
    def test_dict_access(self):
        assert _get_cfg_field({"foo": "bar"}, "foo") == "bar"

    def test_dict_missing_returns_default(self):
        assert _get_cfg_field({}, "foo", 42) == 42

    def test_object_access(self):
        class Obj:
            foo = "bar"
        assert _get_cfg_field(Obj(), "foo") == "bar"

    def test_object_missing_returns_default(self):
        class Obj:
            pass
        assert _get_cfg_field(Obj(), "foo", 99) == 99


# ── _resolve_guardrail_rules ────────────────────────────────────────────────


class TestResolveGuardrailRules:
    def test_both_present(self):
        cfg = {"input": [{"id": "pii"}], "output": [{"id": "toxicity"}]}
        has_in, has_out = _resolve_guardrail_rules(cfg)
        assert has_in is True
        assert has_out is True

    def test_empty_lists(self):
        cfg = {"input": [], "output": []}
        has_in, has_out = _resolve_guardrail_rules(cfg)
        assert has_in is False
        assert has_out is False

    def test_none_values(self):
        cfg = {"input": None, "output": None}
        has_in, has_out = _resolve_guardrail_rules(cfg)
        assert has_in is False
        assert has_out is False

    def test_missing_keys(self):
        cfg = {}
        has_in, has_out = _resolve_guardrail_rules(cfg)
        assert has_in is False
        assert has_out is False


# ── _resolve_has_telemetry ───────────────────────────────────────────────────


class TestResolveHasTelemetry:
    def test_none(self):
        assert _resolve_has_telemetry(None) is False

    def test_enabled_true(self):
        assert _resolve_has_telemetry({"enabled": True}) is True

    def test_enabled_false(self):
        assert _resolve_has_telemetry({"enabled": False}) is False

    def test_missing_enabled(self):
        assert _resolve_has_telemetry({}) is False


# ── _resolve_has_cost ────────────────────────────────────────────────────────


class TestResolveHasCost:
    def test_none(self):
        assert _resolve_has_cost(None) is False

    def test_with_budget(self):
        assert _resolve_has_cost({"budget": {"daily": 100}}) is True

    def test_without_budget(self):
        assert _resolve_has_cost({}) is False

    def test_budget_none(self):
        assert _resolve_has_cost({"budget": None}) is False


# ── _record_guardrail_event ─────────────────────────────────────────────────


class TestRecordGuardrailEvent:
    def test_records_when_span_exists(self):
        recorded = []
        class MockTelemetry:
            def record_event(self, span, event):
                recorded.append((span, event))

        spans = {"r1": SpanHandle(span_id="s1", trace_id="t1")}
        decision = GuardrailDecision(allowed=True, violations=[])
        _record_guardrail_event(MockTelemetry(), spans, "r1", "guardrail_input", decision)
        assert len(recorded) == 1
        assert recorded[0][1].name == "guardrail_input"

    def test_no_op_when_span_missing(self):
        recorded = []
        class MockTelemetry:
            def record_event(self, span, event):
                recorded.append(1)

        _record_guardrail_event(MockTelemetry(), {}, "missing", "evt", GuardrailDecision())
        assert len(recorded) == 0


# ── _end_span_and_cleanup ───────────────────────────────────────────────────


class TestEndSpanAndCleanup:
    def test_ends_and_removes_span(self):
        ended = []
        class MockTelemetry:
            def end_span(self, span, result):
                ended.append((span, result))

        spans = {"r1": SpanHandle(span_id="s1", trace_id="t1")}
        _end_span_and_cleanup(MockTelemetry(), spans, "r1", "blocked")
        assert len(ended) == 1
        assert ended[0][1].status == "blocked"
        assert "r1" not in spans

    def test_no_op_when_span_missing(self):
        ended = []
        class MockTelemetry:
            def end_span(self, span, result):
                ended.append(1)

        spans = {}
        _end_span_and_cleanup(MockTelemetry(), spans, "missing", "ok")
        assert len(ended) == 0


# ── _blocked_decision ────────────────────────────────────────────────────────


class TestBlockedDecision:
    def test_creates_blocked_decision(self):
        violation = GuardrailViolation(rule_id="pii", category="privacy", message="PII detected")
        decision = GuardrailDecision(allowed=False, action="block", violations=[violation])
        result = _blocked_decision(decision)
        assert result.allowed is False
        assert result.action == "block"
        assert len(result.violations) == 1
        assert result.violations[0].rule_id == "pii"


# ── _resolve_tenant ─────────────────────────────────────────────────────────


class TestResolveTenant:
    @pytest.mark.asyncio
    async def test_resolves_tenant_from_request(self):
        class MockTenant:
            license_id = "lic1"
            namespace_id = "ns1"
            user_id = "u1"

        class MockResolver:
            async def resolve(self, request):
                return MockTenant()

        ctx = RuntimeContext(agent_id="a", request_id="r", input="x", model="m", request="req")
        await _resolve_tenant(MockResolver(), ctx)
        assert ctx.tenant_id == "lic1:ns1"
        assert ctx.user_id == "u1"

    @pytest.mark.asyncio
    async def test_no_resolver_does_nothing(self):
        ctx = RuntimeContext(agent_id="a", request_id="r", input="x", model="m")
        await _resolve_tenant(None, ctx)
        assert ctx.tenant_id is None

    @pytest.mark.asyncio
    async def test_no_request_does_nothing(self):
        class MockResolver:
            async def resolve(self, request):
                raise RuntimeError("should not be called")

        ctx = RuntimeContext(agent_id="a", request_id="r", input="x", model="m", request=None)
        await _resolve_tenant(MockResolver(), ctx)
        assert ctx.tenant_id is None

    @pytest.mark.asyncio
    async def test_exception_is_swallowed(self):
        class MockResolver:
            async def resolve(self, request):
                raise ValueError("boom")

        ctx = RuntimeContext(agent_id="a", request_id="r", input="x", model="m", request="req")
        await _resolve_tenant(MockResolver(), ctx)
        # Should not raise, tenant_id unchanged
        assert ctx.tenant_id is None


# ── Noop adapters ────────────────────────────────────────────────────────────


class TestNoopAdapters:
    @pytest.mark.asyncio
    async def test_noop_guardrail_evaluate_input(self):
        g = _NoopGuardrail()
        result = await g.evaluate_input(None)
        assert result.allowed is True
        assert result.action == "pass"

    @pytest.mark.asyncio
    async def test_noop_guardrail_evaluate_output(self):
        g = _NoopGuardrail()
        result = await g.evaluate_output(None)
        assert result.allowed is True

    @pytest.mark.asyncio
    async def test_noop_cost_tracker_record(self):
        c = _NoopCostTracker()
        await c.record(None)  # should not raise

    @pytest.mark.asyncio
    async def test_noop_cost_tracker_query(self):
        c = _NoopCostTracker()
        result = await c.query(None)
        assert result.total_cost == 0
        assert result.total_tokens == 0

    @pytest.mark.asyncio
    async def test_noop_cost_tracker_query_timeseries(self):
        c = _NoopCostTracker()
        result = await c.query_timeseries(None)
        assert result == []

    @pytest.mark.asyncio
    async def test_noop_cost_tracker_check_budget(self):
        c = _NoopCostTracker()
        result = await c.check_budget("agent1")
        assert result.within_budget is True
        assert result.limit == float("inf")

    def test_noop_telemetry_start_span(self):
        t = _NoopTelemetry()
        span = t.start_agent_span(None)
        assert span.span_id == "noop"
        assert span.trace_id == "noop"

    def test_noop_telemetry_record_event(self):
        t = _NoopTelemetry()
        t.record_event(None, None)  # should not raise

    def test_noop_telemetry_end_span(self):
        t = _NoopTelemetry()
        t.end_span(None, None)  # should not raise


# ── create_agent_runtime with dict manifest ──────────────────────────────────


class TestCreateAgentRuntimeDictManifest:
    @pytest.mark.asyncio
    async def test_works_with_dict_spec(self):
        """When manifest has no .spec attr, the manifest itself is used as spec."""
        manifest = {
            "guardrails": {"input": [], "output": []},
            "telemetry": None,
            "cost": None,
        }
        runtime = create_agent_runtime(manifest)
        ctx = RuntimeContext(agent_id="a", request_id="r", input="hello", model="m")
        decision = await runtime.before_call(ctx)
        assert decision.allowed is True


# ── Runtime with telemetry enabled ───────────────────────────────────────────


class TestRuntimeWithTelemetry:
    def _make_manifest(self, *, guardrails=None, telemetry=None, cost=None):
        class _Spec:
            pass
        class _Manifest:
            pass
        spec = _Spec()
        spec.guardrails = guardrails
        spec.telemetry = telemetry
        spec.cost = cost
        m = _Manifest()
        m.spec = spec
        return m

    @pytest.mark.asyncio
    async def test_telemetry_span_lifecycle(self):
        """Telemetry enabled → span created in before_call, ended in after_call."""
        started = []
        ended = []

        class MockTelemetry:
            def start_agent_span(self, ctx):
                span = SpanHandle(span_id="s1", trace_id="t1")
                started.append(span)
                return span

            def record_event(self, span, event):
                pass

            def end_span(self, span, result):
                ended.append((span, result))

        manifest = self._make_manifest(telemetry={"enabled": True})
        runtime = create_agent_runtime(manifest, {"telemetry": MockTelemetry()})

        ctx = RuntimeContext(agent_id="a", request_id="r1", input="hi", model="gpt")
        await runtime.before_call(ctx)
        assert len(started) == 1

        result = RuntimeResult(output="ok", usage={"input_tokens": 10, "output_tokens": 5})
        await runtime.after_call(ctx, result)
        assert len(ended) == 1
        assert ended[0][1].status == "ok"

    @pytest.mark.asyncio
    async def test_on_tool_call_with_telemetry(self):
        events = []
        class MockTelemetry:
            def start_agent_span(self, ctx):
                return SpanHandle(span_id="s1", trace_id="t1")
            def record_event(self, span, event):
                events.append(event)
            def end_span(self, span, result):
                pass

        manifest = self._make_manifest(telemetry={"enabled": True})
        runtime = create_agent_runtime(manifest, {"telemetry": MockTelemetry()})

        ctx = RuntimeContext(agent_id="a", request_id="r1", input="hi", model="gpt")
        await runtime.before_call(ctx)  # creates span
        await runtime.on_tool_call(ctx, ToolCallInfo(name="search"))
        assert len(events) == 1
        assert events[0].name == "tool_call"
        assert events[0].attributes["tool"] == "search"

    @pytest.mark.asyncio
    async def test_on_error_with_telemetry(self):
        ended = []
        class MockTelemetry:
            def start_agent_span(self, ctx):
                return SpanHandle(span_id="s1", trace_id="t1")
            def record_event(self, span, event):
                pass
            def end_span(self, span, result):
                ended.append(result)

        manifest = self._make_manifest(telemetry={"enabled": True})
        runtime = create_agent_runtime(manifest, {"telemetry": MockTelemetry()})

        ctx = RuntimeContext(agent_id="a", request_id="r1", input="hi", model="gpt")
        await runtime.before_call(ctx)
        await runtime.on_error(ctx, ValueError("boom"))
        assert len(ended) == 1
        assert ended[0].status == "error"


# ── Runtime with output guardrails ───────────────────────────────────────────


class TestRuntimeOutputGuardrails:
    def _make_manifest(self, *, guardrails=None, telemetry=None, cost=None):
        class _Spec:
            pass
        class _Manifest:
            pass
        spec = _Spec()
        spec.guardrails = guardrails
        spec.telemetry = telemetry
        spec.cost = cost
        m = _Manifest()
        m.spec = spec
        return m

    @pytest.mark.asyncio
    async def test_after_call_blocks_output(self):
        class BlockingGuardrail:
            async def evaluate_input(self, ctx):
                return GuardrailDecision(allowed=True, action="pass", violations=[])
            async def evaluate_output(self, ctx):
                return GuardrailDecision(
                    allowed=False, action="block",
                    violations=[GuardrailViolation(rule_id="toxic", category="safety", message="Toxic output")],
                )

        manifest = self._make_manifest(guardrails={"input": [], "output": [{"id": "toxic"}]})
        runtime = create_agent_runtime(manifest, {"guardrail": BlockingGuardrail()})

        ctx = RuntimeContext(agent_id="a", request_id="r1", input="hi", model="gpt")
        decision = await runtime.after_call(ctx, RuntimeResult(output="bad content"))
        assert decision.allowed is False
        assert decision.action == "block"

    @pytest.mark.asyncio
    async def test_input_guardrail_rewrite(self):
        class RewriteGuardrail:
            async def evaluate_input(self, ctx):
                return GuardrailDecision(allowed=True, action="rewrite", violations=[], rewritten="sanitized input")
            async def evaluate_output(self, ctx):
                return GuardrailDecision(allowed=True, action="pass", violations=[])

        manifest = self._make_manifest(guardrails={"input": [{"id": "rewriter"}], "output": []})
        runtime = create_agent_runtime(manifest, {"guardrail": RewriteGuardrail()})

        ctx = RuntimeContext(agent_id="a", request_id="r1", input="original", model="gpt")
        decision = await runtime.before_call(ctx)
        assert decision.allowed is True
        assert decision.action == "rewrite"
        assert decision.rewritten == "sanitized input"
