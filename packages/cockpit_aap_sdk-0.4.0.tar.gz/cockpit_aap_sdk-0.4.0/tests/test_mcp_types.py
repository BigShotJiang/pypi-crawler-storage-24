"""Tests for MCP types (dataclasses)."""

from __future__ import annotations

from cockpit_aap.mcp_types import (
    AAPServerConfig,
    MultiAAPClientConfig,
    PromptArgument,
    PromptMessage,
    PromptResult,
    PromptSchema,
    ResourceContents,
    ResourceSchema,
    ResourceTemplate,
    ToolResult,
    ToolSchema,
)


def test_tool_schema_defaults() -> None:
    ts = ToolSchema(name="test", description="A test tool")
    assert ts.name == "test"
    assert ts.description == "A test tool"
    assert ts.input_schema == {}
    assert ts.namespace == ""


def test_tool_result_defaults() -> None:
    tr = ToolResult()
    assert tr.content is None
    assert tr.is_error is False


def test_prompt_argument() -> None:
    pa = PromptArgument(name="arg1", description="desc", required=True)
    assert pa.name == "arg1"
    assert pa.description == "desc"
    assert pa.required is True


def test_prompt_schema_defaults() -> None:
    ps = PromptSchema(name="my-prompt")
    assert ps.name == "my-prompt"
    assert ps.description is None
    assert ps.arguments == []
    assert ps.namespace == ""


def test_prompt_schema_with_arguments() -> None:
    ps = PromptSchema(
        name="prompt",
        description="A prompt",
        arguments=[
            PromptArgument(name="a", required=True),
            PromptArgument(name="b"),
        ],
        namespace="ns",
    )
    assert len(ps.arguments) == 2
    assert ps.arguments[0].required is True
    assert ps.arguments[1].required is None


def test_prompt_message() -> None:
    pm = PromptMessage(role="user", content={"type": "text", "text": "hello"})
    assert pm.role == "user"
    assert pm.content["text"] == "hello"


def test_prompt_result_defaults() -> None:
    pr = PromptResult()
    assert pr.description is None
    assert pr.messages == []


def test_resource_schema() -> None:
    rs = ResourceSchema(uri="file:///test", name="test")
    assert rs.uri == "file:///test"
    assert rs.name == "test"
    assert rs.description is None
    assert rs.mime_type is None
    assert rs.namespace == ""


def test_resource_contents() -> None:
    rc = ResourceContents(uri="file:///test", text="content", mime_type="text/plain")
    assert rc.uri == "file:///test"
    assert rc.text == "content"
    assert rc.blob is None


def test_resource_template() -> None:
    rt = ResourceTemplate(
        uri_template="file:///{path}",
        name="file",
        description="Read a file",
        mime_type="text/plain",
        namespace="ns",
    )
    assert rt.uri_template == "file:///{path}"
    assert rt.name == "file"
    assert rt.namespace == "ns"


def test_aap_server_config_defaults() -> None:
    cfg = AAPServerConfig(endpoint="http://localhost:3100/mcp")
    assert cfg.endpoint == "http://localhost:3100/mcp"
    assert cfg.headers == {}
    assert cfg.mcp_protocol_version == "2024-11-05"


def test_multi_aap_client_config() -> None:
    cfg = MultiAAPClientConfig(
        servers={
            "artifacts": AAPServerConfig(endpoint="http://localhost:3100/mcp"),
            "agents": AAPServerConfig(endpoint="http://localhost:3200/mcp"),
        },
        timeout=60.0,
    )
    assert len(cfg.servers) == 2
    assert cfg.timeout == 60.0
    assert cfg.validate_inputs is False


def test_all_types_importable_from_init() -> None:
    """Verify all MCP types are exported from the package root."""
    from cockpit_aap import (  # noqa: F401
        AAPServerConfig,
        MultiAAPClientConfig,
        PromptArgument,
        PromptMessage,
        PromptResult,
        PromptSchema,
        ResourceContents,
        ResourceSchema,
        ResourceTemplate,
        ToolResult,
        ToolSchema,
    )
