"""Comprehensive tests for manifest helper functions -- Python port of TS helpers.

Tests all 30+ helper functions with a shared fixture manifest covering every section:
module, agents, artifacts, i18n, commands, skills, hooks, connections, theme.
"""

from __future__ import annotations

import copy
import json

import pytest

from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAgent,
    ManifestArtifact,
    ManifestCommand,
    ManifestCommandArg,
    ManifestConnection,
    ManifestRecognition,
    ManifestRecognitionBadge,
    ManifestRecognitionReward,
    ManifestHook,
    ManifestI18n,
    ManifestLocale,
    ManifestMetadata,
    ManifestOnboarding,
    ManifestOnboardingStep,
    ManifestPersonas,
    ManifestPersonaConfig,
    ManifestSkill,
    ManifestSkillAutoInvoke,
    ManifestSpec,
    ManifestTheme,
    ManifestThemeColors,
    ManifestThemePreset,
)
from cockpit_aap.manifest.helpers import (
    get_manifest_agent,
    get_manifest_persona,
    get_agent_for_persona,
    get_persona_agents,
    get_manifest_agent_instruction,
    get_manifest_artifact_value,
    get_manifest_artifact_json,
    get_state_artifacts,
    get_manifest_artifacts_by_category,
    get_manifest_artifacts_by_prefix,
    get_manifest_locale,
    get_manifest_default_locale,
    get_manifest_prompt_pills,
    get_manifest_welcome,
    get_manifest_i18n_resources,
    get_manifest_localized_content,
    get_manifest_localized_collection,
    get_localized_manifest,
    get_manifest_commands,
    get_manifest_command,
    get_manifest_commands_by_persona,
    get_manifest_skills,
    get_manifest_skill,
    get_manifest_skills_by_persona,
    get_manifest_skills_by_trigger,
    get_manifest_hooks,
    get_manifest_hooks_by_event,
    get_manifest_hooks_for_tool,
    get_manifest_connections,
    get_manifest_connection,
    get_manifest_theme,
    get_manifest_default_theme,
    get_manifest_theme_preset,
    get_manifest_theme_preset_ids,
    get_manifest_theme_css_vars,
)


# ---------------------------------------------------------------------------
# Shared fixture manifest
# ---------------------------------------------------------------------------


def _build_fixture() -> Manifest:
    """Build a full fixture manifest with ALL sections populated."""
    return Manifest(
        metadata=ManifestMetadata(
            name="test-mod",
            display_name="Test Module",
            version="1.0.0",
            description="A comprehensive test module",
            artifact_prefix="test-mod.",
        ),
        spec=ManifestSpec(
            agents=[
                ManifestAgent(
                    id="agent-py",
                    name="Python Agent",
                    description="Agent running in Python",
                    instruction="You are the Python agent. Help with Python tasks.",
                    runtime="python",
                ),
                ManifestAgent(
                    id="agent-ts",
                    name="TypeScript Agent",
                    description="Agent running in TypeScript",
                    instruction="You are the TypeScript agent. Help with TS tasks.",
                    runtime="typescript",
                ),
            ],
            artifacts=[
                ManifestArtifact(
                    key="test-mod.config.models",
                    default_value='{"default":"gpt-4","fallback":"gpt-3.5"}',
                    category="configuration",
                ),
                ManifestArtifact(
                    key="test-mod.config.settings",
                    default_value='{"temperature":0.7}',
                    category="configuration",
                ),
                ManifestArtifact(
                    key="test-mod.state.prefs",
                    default_value="{}",
                    category="state",
                ),
                ManifestArtifact(
                    key="test-mod.state.filters",
                    default_value="[]",
                    category="state",
                ),
                ManifestArtifact(
                    key="test-mod.content.en.item-1",
                    default_value='{"title":"Hello","body":"World"}',
                    category="content",
                ),
                ManifestArtifact(
                    key="test-mod.content.en.item-2",
                    default_value='{"title":"Foo","body":"Bar"}',
                    category="content",
                ),
                ManifestArtifact(
                    key="test-mod.content.pt-BR.item-1",
                    default_value='{"title":"Ola","body":"Mundo"}',
                    category="content",
                ),
                ManifestArtifact(
                    key="test-mod.ui.prompt-pills",
                    default_value='[{"label":"Quick","prompt":"Do something quick"}]',
                    category="configuration",
                ),
                ManifestArtifact(
                    key="test-mod.ui.welcome-message",
                    default_value='{"greeting":"Hey there","tagline":"Welcome to the module"}',
                    category="configuration",
                ),
                # Legacy i18n artifacts
                ManifestArtifact(
                    key="test-mod.i18n.en",
                    default_value='{"app":{"title":"Legacy EN Title"}}',
                    category="content",
                ),
                ManifestArtifact(
                    key="test-mod.i18n.pt-BR",
                    default_value='{"app":{"title":"Legacy PT Title"}}',
                    category="content",
                ),
            ],
            i18n=ManifestI18n(
                default_locale="en",
                locales={
                    "en": ManifestLocale(
                        prompt_pills=[{"label": "Show all", "prompt": "List everything"}],
                        welcome={"greeting": "Welcome", "tagline": "Hello there"},
                        resources={"app": {"title": "My App"}, "nav": {"home": "Home"}},
                        content={
                            "level-1": {"title": "Hello", "body": "World"},
                            "level-2": {"title": "Foo", "body": "Bar"},
                        },
                        module=None,
                        agents=None,
                    ),
                    "pt-BR": ManifestLocale(
                        prompt_pills=[{"label": "Mostrar tudo", "prompt": "Listar tudo"}],
                        welcome={"greeting": "Bem-vindo", "tagline": "Ola"},
                        resources={"app": {"title": "Meu App"}, "nav": {"home": "Inicio"}},
                        content={
                            "level-1": {"title": "Ola", "body": "Mundo"},
                        },
                        module={"name": "Modulo Teste", "description": "Descricao em portugues"},
                        agents={
                            "agent-py": {
                                "name": "Agente Python",
                                "description": "Agente em Python",
                                "instruction": "Voce e o agente Python.",
                            },
                        },
                        personas={
                            "dev": {
                                "display_name": "Desenvolvedor",
                                "description": "Persona de dev",
                            },
                        },
                        commands={
                            "cmd-build": {
                                "name": "Compilar",
                                "description": "Compilar o projeto",
                            },
                        },
                        skills={
                            "skill-validate": {
                                "name": "Validar",
                                "description": "Validar o manifesto",
                                "instruction": "Valide o manifesto em portugues.",
                            },
                        },
                        onboarding={
                            "welcome_message": "Bem-vindo ao modulo!",
                        },
                        recognition={
                            "badges": {
                                "first-run": {
                                    "name": "Primeira Execucao",
                                    "description": "Completou a primeira execucao",
                                },
                            },
                        },
                    ),
                },
            ),
            commands=[
                ManifestCommand(
                    id="cmd-build",
                    name="Build",
                    description="Build the project",
                    script="npm run build",
                    persona="dev",
                ),
                ManifestCommand(
                    id="cmd-test",
                    name="Test",
                    description="Run all tests",
                    script="npm test",
                ),
            ],
            skills=[
                ManifestSkill(
                    id="skill-validate",
                    name="Validate",
                    description="Validate the manifest",
                    instruction="Validate the manifest against the schema.",
                    auto_invoke=ManifestSkillAutoInvoke(
                        triggers=["on-save", "on-push"],
                    ),
                    persona="dev",
                ),
                ManifestSkill(
                    id="skill-scan",
                    name="Scan",
                    description="Scan for issues",
                    instruction="Scan the codebase for common issues.",
                ),
            ],
            hooks=[
                ManifestHook(
                    event="tool:before",
                    type="script",
                    script="echo pre-hook",
                    description="Global pre-hook for all tools",
                ),
                ManifestHook(
                    event="tool:before",
                    type="script",
                    matcher=r"^cockpit_.*",
                    script="echo cockpit-only",
                    description="Pre-hook only for cockpit-prefixed tools",
                ),
                ManifestHook(
                    event="tool:after",
                    type="artifact",
                    artifact="test-mod.state.prefs",
                    description="Post-hook to save preferences",
                ),
            ],
            connections=[
                ManifestConnection(
                    id="conn-devops",
                    url="https://devops.example.com",
                    transport="http",
                    description="Azure DevOps connection",
                ),
                ManifestConnection(
                    id="conn-github",
                    url="https://api.github.com",
                    transport="http",
                    headers={"Authorization": "Bearer xxx"},
                ),
            ],
            personas=ManifestPersonas(
                default_persona="dev",
                definitions=[
                    ManifestPersonaConfig(
                        persona_id="dev",
                        display_name="Developer",
                        description="Developer persona",
                    ),
                ],
            ),
            recognition=ManifestRecognition(
                badges=[
                    ManifestRecognitionBadge(
                        id="first-run",
                        name="First Run",
                        description="Completed the first run",
                        criteria="runs >= 1",
                    ),
                ],
                rewards=[
                    ManifestRecognitionReward(id="complete-task", name="Complete Task", xp=50),
                ],
            ),
            onboarding=ManifestOnboarding(
                welcome_message="Welcome to the module!",
                steps=[
                    ManifestOnboardingStep(
                        title="Step 1",
                        description="First step",
                    ),
                ],
            ),
            theme=ManifestTheme(
                default="light",
                presets={
                    "light": ManifestThemePreset(
                        label="Light Theme",
                        colors=ManifestThemeColors(
                            primary="210 40% 98%",
                            primary_foreground="222 47% 11%",
                            background="0 0% 100%",
                        ),
                        copilot_kit={
                            "primary-color": "#3b82f6",
                            "background-color": "#ffffff",
                        },
                        fonts={
                            "sans": "Inter, sans-serif",
                            "mono": "JetBrains Mono, monospace",
                        },
                        color_scheme="light",
                    ),
                    "dark": ManifestThemePreset(
                        label="Dark Theme",
                        colors=ManifestThemeColors(
                            primary="210 40% 10%",
                            primary_foreground="210 40% 98%",
                            background="222 47% 11%",
                        ),
                        copilot_kit={
                            "primary-color": "#60a5fa",
                            "background-color": "#1e293b",
                        },
                        fonts={
                            "sans": "Inter, sans-serif",
                        },
                        color_scheme="dark",
                    ),
                },
            ),
        ),
    )


MANIFEST = _build_fixture()


# =========================================================================
# Agent helpers
# =========================================================================


class TestGetManifestAgent:
    def test_finds_agent_by_id(self) -> None:
        agent = get_manifest_agent(MANIFEST, "agent-py")
        assert agent is not None
        assert agent.name == "Python Agent"
        assert agent.runtime == "python"

    def test_returns_none_for_unknown_id(self) -> None:
        assert get_manifest_agent(MANIFEST, "nonexistent") is None

    def test_returns_none_when_no_agents(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.agents = None
        assert get_manifest_agent(bare, "agent-py") is None


class TestGetManifestAgentInstruction:
    def test_returns_instruction_text(self) -> None:
        result = get_manifest_agent_instruction(MANIFEST, "agent-ts")
        assert result == "You are the TypeScript agent. Help with TS tasks."

    def test_returns_empty_string_for_unknown_agent(self) -> None:
        assert get_manifest_agent_instruction(MANIFEST, "unknown") == ""

    def test_returns_empty_string_when_no_agents(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.agents = None
        assert get_manifest_agent_instruction(bare, "agent-py") == ""


# =========================================================================
# Artifact helpers
# =========================================================================


class TestGetManifestArtifactValue:
    def test_returns_default_value_by_key(self) -> None:
        val = get_manifest_artifact_value(MANIFEST, "test-mod.config.models")
        assert val == '{"default":"gpt-4","fallback":"gpt-3.5"}'

    def test_returns_none_for_unknown_key(self) -> None:
        assert get_manifest_artifact_value(MANIFEST, "nope") is None

    def test_returns_none_when_no_artifacts(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.artifacts = None
        assert get_manifest_artifact_value(bare, "test-mod.config.models") is None


class TestGetManifestArtifactJSON:
    def test_parses_json_artifact(self) -> None:
        result = get_manifest_artifact_json(MANIFEST, "test-mod.config.models")
        assert result == {"default": "gpt-4", "fallback": "gpt-3.5"}

    def test_returns_none_for_unknown_key(self) -> None:
        assert get_manifest_artifact_json(MANIFEST, "nope") is None

    def test_returns_none_for_non_json_value(self) -> None:
        # test-mod.state.prefs has "{}" which IS valid JSON, so use a manifest with invalid JSON
        m = copy.deepcopy(MANIFEST)
        m.spec.artifacts = [
            ManifestArtifact(key="bad-json", default_value="not json {["),
        ]
        # Should return None for unparseable JSON (silently)
        assert get_manifest_artifact_json(m, "bad-json") is None


class TestGetStateArtifacts:
    def test_returns_only_state_category(self) -> None:
        state = get_state_artifacts(MANIFEST)
        assert len(state) == 2
        keys = [a.key for a in state]
        assert "test-mod.state.prefs" in keys
        assert "test-mod.state.filters" in keys

    def test_returns_empty_when_no_artifacts(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.artifacts = None
        assert get_state_artifacts(bare) == []


class TestGetManifestArtifactsByCategory:
    def test_filters_by_content_category(self) -> None:
        content = get_manifest_artifacts_by_category(MANIFEST, "content")
        assert len(content) >= 3
        assert all(a.category == "content" for a in content)

    def test_filters_by_configuration_category(self) -> None:
        configs = get_manifest_artifacts_by_category(MANIFEST, "configuration")
        assert len(configs) >= 2

    def test_returns_empty_for_unknown_category(self) -> None:
        assert get_manifest_artifacts_by_category(MANIFEST, "nonexistent") == []

    def test_returns_empty_when_no_artifacts(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.artifacts = None
        assert get_manifest_artifacts_by_category(bare, "content") == []


class TestGetManifestArtifactsByPrefix:
    def test_matches_prefix_with_dot(self) -> None:
        items = get_manifest_artifacts_by_prefix(MANIFEST, "test-mod.content.en")
        assert len(items) == 2
        keys = [i["key"] for i in items]
        assert "test-mod.content.en.item-1" in keys
        assert "test-mod.content.en.item-2" in keys

    def test_parses_values_as_json(self) -> None:
        items = get_manifest_artifacts_by_prefix(MANIFEST, "test-mod.content.en")
        item1 = next(i for i in items if i["key"] == "test-mod.content.en.item-1")
        assert item1["value"] == {"title": "Hello", "body": "World"}

    def test_returns_empty_for_nonexistent_prefix(self) -> None:
        assert get_manifest_artifacts_by_prefix(MANIFEST, "nope") == []

    def test_no_partial_match_without_dot(self) -> None:
        # "test-mod.content.e" + "." = "test-mod.content.e." should NOT match "test-mod.content.en.item-1"
        assert get_manifest_artifacts_by_prefix(MANIFEST, "test-mod.content.e") == []

    def test_skips_non_json_values(self) -> None:
        m = copy.deepcopy(MANIFEST)
        m.spec.artifacts = [
            ManifestArtifact(key="pfx.a", default_value="not json"),
            ManifestArtifact(key="pfx.b", default_value='{"ok":true}'),
        ]
        items = get_manifest_artifacts_by_prefix(m, "pfx")
        assert len(items) == 1
        assert items[0]["key"] == "pfx.b"


# =========================================================================
# i18n helpers
# =========================================================================


class TestGetManifestLocale:
    def test_returns_default_locale_when_none_specified(self) -> None:
        loc = get_manifest_locale(MANIFEST)
        assert loc is not None
        assert loc.prompt_pills is not None
        assert loc.prompt_pills[0]["label"] == "Show all"

    def test_returns_specific_locale(self) -> None:
        loc = get_manifest_locale(MANIFEST, "pt-BR")
        assert loc is not None
        assert loc.prompt_pills is not None
        assert loc.prompt_pills[0]["label"] == "Mostrar tudo"

    def test_falls_back_to_default_for_unknown_locale(self) -> None:
        loc = get_manifest_locale(MANIFEST, "fr-FR")
        assert loc is not None
        assert loc.prompt_pills is not None
        assert loc.prompt_pills[0]["label"] == "Show all"

    def test_returns_none_when_no_i18n(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.i18n = None
        assert get_manifest_locale(bare) is None


class TestGetManifestDefaultLocale:
    def test_returns_default_locale(self) -> None:
        assert get_manifest_default_locale(MANIFEST) == "en"

    def test_returns_en_when_no_i18n(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.i18n = None
        assert get_manifest_default_locale(bare) == "en"


class TestGetManifestPromptPills:
    def test_returns_i18n_pills_for_default_locale(self) -> None:
        pills = get_manifest_prompt_pills(MANIFEST)
        assert len(pills) == 1
        assert pills[0]["label"] == "Show all"

    def test_returns_i18n_pills_for_specific_locale(self) -> None:
        pills = get_manifest_prompt_pills(MANIFEST, "pt-BR")
        assert len(pills) == 1
        assert pills[0]["label"] == "Mostrar tudo"

    def test_falls_back_to_artifact_when_no_i18n(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.i18n = None
        pills = get_manifest_prompt_pills(bare)
        assert len(pills) == 1
        assert pills[0]["label"] == "Quick"

    def test_returns_empty_when_no_i18n_and_no_artifact(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.i18n = None
        bare.spec.artifacts = []
        assert get_manifest_prompt_pills(bare) == []

    def test_falls_back_to_artifact_when_locale_has_no_pills(self) -> None:
        m = copy.deepcopy(MANIFEST)
        m.spec.i18n = ManifestI18n(
            default_locale="en",
            locales={"en": ManifestLocale()},
        )
        pills = get_manifest_prompt_pills(m)
        assert len(pills) == 1
        assert pills[0]["label"] == "Quick"


class TestGetManifestWelcome:
    def test_returns_i18n_welcome_for_default_locale(self) -> None:
        welcome = get_manifest_welcome(MANIFEST)
        assert welcome is not None
        assert welcome["greeting"] == "Welcome"

    def test_returns_i18n_welcome_for_specific_locale(self) -> None:
        welcome = get_manifest_welcome(MANIFEST, "pt-BR")
        assert welcome is not None
        assert welcome["greeting"] == "Bem-vindo"

    def test_falls_back_to_artifact_when_no_i18n(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.i18n = None
        welcome = get_manifest_welcome(bare)
        assert welcome is not None
        assert welcome["greeting"] == "Hey there"

    def test_returns_none_when_no_i18n_and_no_artifact(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.i18n = None
        bare.spec.artifacts = []
        assert get_manifest_welcome(bare) is None


class TestGetManifestI18nResources:
    def test_reads_from_locale_resources(self) -> None:
        res = get_manifest_i18n_resources(MANIFEST)
        assert "en" in res
        assert res["en"] == {"translation": {"app": {"title": "My App"}, "nav": {"home": "Home"}}}
        assert "pt-BR" in res
        assert res["pt-BR"] == {"translation": {"app": {"title": "Meu App"}, "nav": {"home": "Inicio"}}}

    def test_falls_back_to_artifact_scan(self) -> None:
        """When locale has no resources field, use artifact {prefix}i18n.{locale}."""
        m = copy.deepcopy(MANIFEST)
        m.spec.i18n = ManifestI18n(
            default_locale="en",
            locales={"en": ManifestLocale(), "pt-BR": ManifestLocale()},
        )
        res = get_manifest_i18n_resources(m)
        assert res["en"] == {"translation": {"app": {"title": "Legacy EN Title"}}}
        assert res["pt-BR"] == {"translation": {"app": {"title": "Legacy PT Title"}}}

    def test_returns_empty_dict_when_no_resources_and_no_artifacts(self) -> None:
        m = copy.deepcopy(MANIFEST)
        m.spec.i18n = ManifestI18n(
            default_locale="en",
            locales={"en": ManifestLocale()},
        )
        m.spec.artifacts = []
        res = get_manifest_i18n_resources(m)
        assert res == {}

    def test_returns_empty_dict_when_no_i18n(self) -> None:
        m = copy.deepcopy(MANIFEST)
        m.spec.i18n = None
        m.spec.artifacts = None
        res = get_manifest_i18n_resources(m)
        # With no i18n, uses ["en"] as default locales list
        assert res == {}


class TestGetManifestLocalizedContent:
    def test_reads_from_locale_content_en(self) -> None:
        item = get_manifest_localized_content(MANIFEST, "test-mod.content", "level-1", "en")
        assert item is not None
        assert item["title"] == "Hello"

    def test_reads_from_locale_content_pt_br(self) -> None:
        item = get_manifest_localized_content(MANIFEST, "test-mod.content", "level-1", "pt-BR")
        assert item is not None
        assert item["title"] == "Ola"

    def test_falls_back_to_en_when_pt_br_item_missing(self) -> None:
        item = get_manifest_localized_content(MANIFEST, "test-mod.content", "level-2", "pt-BR")
        assert item is not None
        assert item["title"] == "Foo"

    def test_returns_default_when_no_locale_param(self) -> None:
        item = get_manifest_localized_content(MANIFEST, "test-mod.content", "level-1")
        assert item is not None
        assert item["title"] == "Hello"

    def test_returns_none_for_unknown_item(self) -> None:
        assert get_manifest_localized_content(MANIFEST, "test-mod.content", "unknown") is None

    def test_artifact_fallback(self) -> None:
        """When no i18n content, fall back to artifact scan."""
        m = copy.deepcopy(MANIFEST)
        m.spec.i18n = None
        item = get_manifest_localized_content(m, "test-mod.content", "item-1", "en")
        assert item is not None
        assert item["title"] == "Hello"


class TestGetManifestLocalizedCollection:
    def test_reads_en_items(self) -> None:
        items = get_manifest_localized_collection(MANIFEST, "test-mod.content", "en")
        assert len(items) == 2

    def test_reads_pt_br_items(self) -> None:
        items = get_manifest_localized_collection(MANIFEST, "test-mod.content", "pt-BR")
        assert len(items) == 1

    def test_falls_back_to_en_for_unknown_locale(self) -> None:
        items = get_manifest_localized_collection(MANIFEST, "test-mod.content", "fr-FR")
        assert len(items) == 2

    def test_returns_default_locale_when_no_param(self) -> None:
        items = get_manifest_localized_collection(MANIFEST, "test-mod.content")
        assert len(items) == 2

    def test_artifact_fallback(self) -> None:
        """When no i18n content, fall back to artifact scan."""
        m = copy.deepcopy(MANIFEST)
        m.spec.i18n = None
        items = get_manifest_localized_collection(m, "test-mod.content", "en")
        assert len(items) == 2


class TestGetLocalizedManifest:
    def test_returns_same_object_for_default_locale(self) -> None:
        result = get_localized_manifest(MANIFEST, "en")
        assert result is MANIFEST

    def test_returns_same_object_when_no_locale_specified(self) -> None:
        result = get_localized_manifest(MANIFEST)
        assert result is MANIFEST

    def test_applies_module_overrides(self) -> None:
        result = get_localized_manifest(MANIFEST, "pt-BR")
        assert result.metadata.display_name == "Modulo Teste"
        assert result.metadata.description == "Descricao em portugues"

    def test_applies_agent_overrides(self) -> None:
        result = get_localized_manifest(MANIFEST, "pt-BR")
        agent_py = next(a for a in result.spec.agents if a.id == "agent-py")
        assert agent_py.name == "Agente Python"
        assert agent_py.description == "Agente em Python"
        assert agent_py.instruction == "Voce e o agente Python."

    def test_agent_without_override_unchanged(self) -> None:
        result = get_localized_manifest(MANIFEST, "pt-BR")
        agent_ts = next(a for a in result.spec.agents if a.id == "agent-ts")
        assert agent_ts.name == "TypeScript Agent"

    def test_applies_command_overrides(self) -> None:
        result = get_localized_manifest(MANIFEST, "pt-BR")
        cmd_build = next(c for c in result.spec.commands if c.id == "cmd-build")
        assert cmd_build.name == "Compilar"
        assert cmd_build.description == "Compilar o projeto"

    def test_applies_skill_overrides(self) -> None:
        result = get_localized_manifest(MANIFEST, "pt-BR")
        skill_val = next(s for s in result.spec.skills if s.id == "skill-validate")
        assert skill_val.name == "Validar"
        assert skill_val.description == "Validar o manifesto"
        assert skill_val.instruction == "Valide o manifesto em portugues."

    def test_applies_onboarding_override(self) -> None:
        result = get_localized_manifest(MANIFEST, "pt-BR")
        assert result.spec.onboarding.welcome_message == "Bem-vindo ao modulo!"

    def test_applies_recognition_badge_overrides(self) -> None:
        result = get_localized_manifest(MANIFEST, "pt-BR")
        badge = result.spec.recognition.badges[0]
        assert badge.name == "Primeira Execucao"
        assert badge.description == "Completou a primeira execucao"

    def test_applies_persona_overrides(self) -> None:
        result = get_localized_manifest(MANIFEST, "pt-BR")
        persona = result.spec.personas.definitions[0]
        assert persona.display_name == "Desenvolvedor"
        assert persona.description == "Persona de dev"

    def test_does_not_mutate_original(self) -> None:
        get_localized_manifest(MANIFEST, "pt-BR")
        assert MANIFEST.metadata.display_name == "Test Module"
        assert MANIFEST.spec.agents[0].name == "Python Agent"

    def test_returns_same_object_for_unknown_locale(self) -> None:
        result = get_localized_manifest(MANIFEST, "fr")
        assert result is MANIFEST

    def test_returns_same_object_when_no_i18n(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.i18n = None
        result = get_localized_manifest(bare, "pt-BR")
        assert result is bare

    def test_partial_overrides_only_replace_specified(self) -> None:
        m = copy.deepcopy(MANIFEST)
        m.spec.i18n = ManifestI18n(
            default_locale="en",
            locales={
                "en": ManifestLocale(),
                "pt-BR": ManifestLocale(
                    module={"description": "Apenas descricao"},
                ),
            },
        )
        result = get_localized_manifest(m, "pt-BR")
        assert result.metadata.display_name == "Test Module"  # unchanged
        assert result.metadata.description == "Apenas descricao"


# =========================================================================
# Command helpers
# =========================================================================


class TestGetManifestCommands:
    def test_returns_all_commands(self) -> None:
        cmds = get_manifest_commands(MANIFEST)
        assert len(cmds) == 2

    def test_returns_empty_when_no_commands(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.commands = None
        assert get_manifest_commands(bare) == []


class TestGetManifestCommand:
    def test_finds_command_by_id(self) -> None:
        cmd = get_manifest_command(MANIFEST, "cmd-build")
        assert cmd is not None
        assert cmd.name == "Build"

    def test_returns_none_for_unknown_id(self) -> None:
        assert get_manifest_command(MANIFEST, "nonexistent") is None


class TestGetManifestCommandsByPersona:
    def test_filters_by_persona(self) -> None:
        cmds = get_manifest_commands_by_persona(MANIFEST, "dev")
        assert len(cmds) == 1
        assert cmds[0].id == "cmd-build"

    def test_returns_empty_for_unknown_persona(self) -> None:
        assert get_manifest_commands_by_persona(MANIFEST, "admin") == []


# =========================================================================
# Skill helpers
# =========================================================================


class TestGetManifestSkills:
    def test_returns_all_skills(self) -> None:
        skills = get_manifest_skills(MANIFEST)
        assert len(skills) == 2

    def test_returns_empty_when_no_skills(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.skills = None
        assert get_manifest_skills(bare) == []


class TestGetManifestSkill:
    def test_finds_skill_by_id(self) -> None:
        skill = get_manifest_skill(MANIFEST, "skill-validate")
        assert skill is not None
        assert skill.name == "Validate"

    def test_returns_none_for_unknown_id(self) -> None:
        assert get_manifest_skill(MANIFEST, "nonexistent") is None


class TestGetManifestSkillsByPersona:
    def test_filters_by_persona(self) -> None:
        skills = get_manifest_skills_by_persona(MANIFEST, "dev")
        assert len(skills) == 1
        assert skills[0].id == "skill-validate"

    def test_returns_empty_for_unknown_persona(self) -> None:
        assert get_manifest_skills_by_persona(MANIFEST, "admin") == []


class TestGetManifestSkillsByTrigger:
    def test_finds_skills_by_trigger(self) -> None:
        skills = get_manifest_skills_by_trigger(MANIFEST, "on-save")
        assert len(skills) == 1
        assert skills[0].id == "skill-validate"

    def test_finds_skills_by_another_trigger(self) -> None:
        skills = get_manifest_skills_by_trigger(MANIFEST, "on-push")
        assert len(skills) == 1

    def test_returns_empty_for_unknown_trigger(self) -> None:
        assert get_manifest_skills_by_trigger(MANIFEST, "on-delete") == []

    def test_skill_without_auto_invoke_not_matched(self) -> None:
        skills = get_manifest_skills_by_trigger(MANIFEST, "on-save")
        ids = [s.id for s in skills]
        assert "skill-scan" not in ids


# =========================================================================
# Hook helpers
# =========================================================================


class TestGetManifestHooks:
    def test_returns_all_hooks(self) -> None:
        hooks = get_manifest_hooks(MANIFEST)
        assert len(hooks) == 3

    def test_returns_empty_when_no_hooks(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.hooks = None
        assert get_manifest_hooks(bare) == []


class TestGetManifestHooksByEvent:
    def test_filters_by_event(self) -> None:
        hooks = get_manifest_hooks_by_event(MANIFEST, "tool:before")
        assert len(hooks) == 2

    def test_returns_after_hooks(self) -> None:
        hooks = get_manifest_hooks_by_event(MANIFEST, "tool:after")
        assert len(hooks) == 1

    def test_returns_empty_for_unknown_event(self) -> None:
        assert get_manifest_hooks_by_event(MANIFEST, "tool:error") == []


class TestGetManifestHooksForTool:
    def test_no_matcher_matches_all_tools(self) -> None:
        hooks = get_manifest_hooks_for_tool(MANIFEST, "tool:before", "any-tool-name")
        # The global hook (no matcher) should always match
        assert any(h.matcher is None for h in hooks)

    def test_matcher_regex_matches(self) -> None:
        hooks = get_manifest_hooks_for_tool(MANIFEST, "tool:before", "cockpit_validate")
        assert len(hooks) == 2  # global + cockpit-prefixed

    def test_matcher_regex_does_not_match(self) -> None:
        hooks = get_manifest_hooks_for_tool(MANIFEST, "tool:before", "github_push")
        assert len(hooks) == 1  # only the global hook (no matcher)
        assert hooks[0].matcher is None

    def test_wrong_event_returns_empty(self) -> None:
        hooks = get_manifest_hooks_for_tool(MANIFEST, "tool:after", "cockpit_validate")
        # tool:after hook has no matcher, so it matches
        assert len(hooks) == 1


# =========================================================================
# Connection helpers
# =========================================================================


class TestGetManifestConnections:
    def test_returns_all_connections(self) -> None:
        conns = get_manifest_connections(MANIFEST)
        assert len(conns) == 2

    def test_returns_empty_when_no_connections(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.connections = None
        assert get_manifest_connections(bare) == []


class TestGetManifestConnection:
    def test_finds_connection_by_id(self) -> None:
        conn = get_manifest_connection(MANIFEST, "conn-devops")
        assert conn is not None
        assert conn.url == "https://devops.example.com"
        assert conn.description == "Azure DevOps connection"

    def test_returns_none_for_unknown_id(self) -> None:
        assert get_manifest_connection(MANIFEST, "nonexistent") is None


# =========================================================================
# Theme helpers
# =========================================================================


class TestGetManifestTheme:
    def test_returns_theme(self) -> None:
        theme = get_manifest_theme(MANIFEST)
        assert theme is not None
        assert theme.default == "light"
        assert "light" in theme.presets
        assert "dark" in theme.presets

    def test_returns_none_when_no_theme(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme = None
        assert get_manifest_theme(bare) is None


class TestGetManifestDefaultTheme:
    def test_returns_default_theme_id(self) -> None:
        assert get_manifest_default_theme(MANIFEST) == "light"

    def test_returns_none_when_no_theme(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme = None
        assert get_manifest_default_theme(bare) is None


class TestGetManifestThemePreset:
    def test_finds_preset_by_id(self) -> None:
        preset = get_manifest_theme_preset(MANIFEST, "dark")
        assert preset is not None
        assert preset.label == "Dark Theme"
        assert preset.color_scheme == "dark"

    def test_returns_none_for_unknown_preset(self) -> None:
        assert get_manifest_theme_preset(MANIFEST, "nonexistent") is None

    def test_returns_none_when_no_theme(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme = None
        assert get_manifest_theme_preset(bare, "light") is None


class TestGetManifestThemePresetIds:
    def test_returns_preset_ids(self) -> None:
        ids = get_manifest_theme_preset_ids(MANIFEST)
        assert sorted(ids) == ["dark", "light"]

    def test_returns_empty_when_no_theme(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme = None
        assert get_manifest_theme_preset_ids(bare) == []


class TestGetManifestThemeCSSVars:
    def test_maps_colors_to_css_vars(self) -> None:
        css = get_manifest_theme_css_vars(MANIFEST, "light")
        assert css is not None
        assert css["--primary"] == "210 40% 98%"
        assert css["--primary-foreground"] == "222 47% 11%"
        assert css["--background"] == "0 0% 100%"

    def test_maps_copilot_kit_to_css_vars(self) -> None:
        css = get_manifest_theme_css_vars(MANIFEST, "light")
        assert css is not None
        assert css["--copilot-kit-primary-color"] == "#3b82f6"
        assert css["--copilot-kit-background-color"] == "#ffffff"

    def test_maps_fonts_to_css_vars(self) -> None:
        css = get_manifest_theme_css_vars(MANIFEST, "light")
        assert css is not None
        assert css["--font-sans"] == "Inter, sans-serif"
        assert css["--font-mono"] == "JetBrains Mono, monospace"

    def test_returns_none_for_unknown_preset(self) -> None:
        assert get_manifest_theme_css_vars(MANIFEST, "nonexistent") is None

    def test_returns_none_when_no_theme(self) -> None:
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme = None
        assert get_manifest_theme_css_vars(bare, "light") is None


# ---------------------------------------------------------------------------
# Extra coverage tests — uncovered branches in new code
# ---------------------------------------------------------------------------


class TestArtifactPrefixFallback:
    """Tests for _get_artifact_prefix when artifact_prefix is None."""

    def test_falls_back_to_module_name_when_no_prefix(self) -> None:
        """When artifact_prefix is None, prefix defaults to '{module_id}.'."""
        m = Manifest(
            metadata=ManifestMetadata(name="my-module", artifact_prefix=None),
            spec=ManifestSpec(
                artifacts=[
                    ManifestArtifact(
                        key="my-module.ui.prompt-pills",
                        default_value='[{"label":"Hi","prompt":"Say hi"}]',
                    ),
                ],
            ),
        )
        pills = get_manifest_prompt_pills(m)
        assert pills == [{"label": "Hi", "prompt": "Say hi"}]


class TestGetManifestPersona:
    """Tests for get_manifest_persona helper."""

    def test_returns_persona_when_found(self) -> None:
        persona = get_manifest_persona(MANIFEST, "dev")
        assert persona is not None
        assert persona.persona_id == "dev"
        assert persona.display_name == "Developer"

    def test_returns_none_for_unknown_persona(self) -> None:
        assert get_manifest_persona(MANIFEST, "nonexistent") is None

    def test_returns_none_when_no_personas(self) -> None:
        bare = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(personas=None),
        )
        assert get_manifest_persona(bare, "dev") is None


class TestGetAgentForPersona:
    """Tests for get_agent_for_persona helper."""

    def test_returns_first_agent_when_persona_has_no_default_agent(self) -> None:
        # MANIFEST fixture persona "dev" has no default_agent → falls back to first agent
        agent_id = get_agent_for_persona(MANIFEST, "dev")
        assert agent_id == "agent-py"  # first agent in the fixture

    def test_returns_default_agent_when_set(self) -> None:
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(
                agents=[
                    ManifestAgent(id="a1", name="Agent 1", description="d", instruction="x"),
                    ManifestAgent(id="a2", name="Agent 2", description="d", instruction="x"),
                ],
                personas=ManifestPersonas(
                    default_persona="dev",
                    definitions=[
                        ManifestPersonaConfig(
                            persona_id="dev",
                            display_name="Dev",
                            description="Dev",
                            default_agent="a2",
                        ),
                    ],
                ),
            ),
        )
        assert get_agent_for_persona(m, "dev") == "a2"

    def test_returns_none_when_no_agents_and_no_persona(self) -> None:
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(agents=None, personas=None),
        )
        assert get_agent_for_persona(m, "dev") is None


class TestGetPersonaAgents:
    """Tests for get_persona_agents helper."""

    def test_returns_all_agents_when_no_allowed_agents(self) -> None:
        # MANIFEST fixture persona "dev" has no allowed_agents → returns all
        agents = get_persona_agents(MANIFEST, "dev")
        assert "agent-py" in agents
        assert "agent-ts" in agents

    def test_returns_allowed_agents_when_set(self) -> None:
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(
                agents=[
                    ManifestAgent(id="a1", name="Agent 1", description="d", instruction="x"),
                    ManifestAgent(id="a2", name="Agent 2", description="d", instruction="x"),
                    ManifestAgent(id="a3", name="Agent 3", description="d", instruction="x"),
                ],
                personas=ManifestPersonas(
                    default_persona="dev",
                    definitions=[
                        ManifestPersonaConfig(
                            persona_id="dev",
                            display_name="Dev",
                            description="Dev",
                            allowed_agents=["a1", "a3"],
                        ),
                    ],
                ),
            ),
        )
        agents = get_persona_agents(m, "dev")
        assert agents == ["a1", "a3"]


class TestGetManifestPromptPillsEdgeCases:
    """Additional edge case tests for get_manifest_prompt_pills."""

    def test_invalid_json_artifact_returns_empty_list(self) -> None:
        """When artifact value is invalid JSON, returns []."""
        m = Manifest(
            metadata=ManifestMetadata(name="test", artifact_prefix="test."),
            spec=ManifestSpec(
                artifacts=[
                    ManifestArtifact(
                        key="test.ui.prompt-pills",
                        default_value="NOT_VALID_JSON[[[",
                    ),
                ],
            ),
        )
        assert get_manifest_prompt_pills(m) == []


class TestGetManifestWelcomeEdgeCases:
    """Additional edge case tests for get_manifest_welcome."""

    def test_returns_welcome_from_artifact_when_no_i18n(self) -> None:
        """Artifact fallback for welcome when no i18n is defined."""
        m = Manifest(
            metadata=ManifestMetadata(name="test", artifact_prefix="test."),
            spec=ManifestSpec(
                artifacts=[
                    ManifestArtifact(
                        key="test.ui.welcome-message",
                        default_value='{"greeting":"Hello","tagline":"Welcome"}',
                    ),
                ],
            ),
        )
        welcome = get_manifest_welcome(m)
        assert welcome == {"greeting": "Hello", "tagline": "Welcome"}


class TestGetManifestLocalizedContentEdgeCases:
    """Additional edge case tests for get_manifest_localized_content."""

    def test_falls_back_to_default_locale_artifact(self) -> None:
        """When requested locale is not default and no i18n content, falls back to default locale artifact."""
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(
                i18n=ManifestI18n(
                    default_locale="en",
                    locales={
                        "en": ManifestLocale(),   # no content
                        "fr": ManifestLocale(),   # no content
                    },
                ),
                artifacts=[
                    ManifestArtifact(
                        key="content.en.my-item",
                        default_value='{"title":"English Item"}',
                    ),
                ],
            ),
        )
        # Request French, but no French content → falls back to English artifact
        result = get_manifest_localized_content(m, "content", "my-item", locale="fr")
        assert result == {"title": "English Item"}


class TestGetManifestLocalizedCollectionEdgeCases:
    """Additional edge case tests for get_manifest_localized_collection."""

    def test_falls_back_to_default_locale_artifacts(self) -> None:
        """When requested locale is not default and no i18n content, falls back to default locale artifacts."""
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(
                i18n=ManifestI18n(
                    default_locale="en",
                    locales={
                        "en": ManifestLocale(),   # no content
                        "fr": ManifestLocale(),   # no content
                    },
                ),
                artifacts=[
                    ManifestArtifact(
                        key="coll.en.item-1",
                        default_value='{"name":"Item One"}',
                    ),
                    ManifestArtifact(
                        key="coll.en.item-2",
                        default_value='{"name":"Item Two"}',
                    ),
                ],
            ),
        )
        # Request French collection → no French artifacts → falls back to English artifacts
        result = get_manifest_localized_collection(m, "coll", locale="fr")
        assert len(result) == 2
        names = [r["name"] for r in result]
        assert "Item One" in names
        assert "Item Two" in names


class TestLocaleOverrideEdgeCases:
    """Additional tests for locale override functions that were not yet covered."""

    def test_agent_objective_override(self) -> None:
        """_apply_agent_overrides covers the objective field (line 446)."""
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(
                agents=[
                    ManifestAgent(id="a1", name="Agent 1", description="d", instruction="x"),
                ],
                i18n=ManifestI18n(
                    default_locale="en",
                    locales={
                        "en": ManifestLocale(),
                        "pt-BR": ManifestLocale(
                            agents={"a1": {"name": "Agente", "objective": "Meu objetivo"}},
                        ),
                    },
                ),
            ),
        )
        result = get_localized_manifest(m, "pt-BR")
        assert result.spec.agents[0].objective == "Meu objetivo"

    def test_persona_description_override(self) -> None:
        """_apply_persona_overrides covers the description field (line 456)."""
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(
                personas=ManifestPersonas(
                    default_persona="dev",
                    definitions=[
                        ManifestPersonaConfig(
                            persona_id="dev",
                            display_name="Developer",
                            description="Original description",
                        ),
                    ],
                ),
                i18n=ManifestI18n(
                    default_locale="en",
                    locales={
                        "en": ManifestLocale(),
                        "pt-BR": ManifestLocale(
                            personas={"dev": {"display_name": "Dev", "description": "Desc em pt"}},
                        ),
                    },
                ),
            ),
        )
        result = get_localized_manifest(m, "pt-BR")
        assert result.spec.personas.definitions[0].description == "Desc em pt"

    def test_recognition_empty_badge_overrides_returns_early(self) -> None:
        """_apply_recognition_overrides: early return when badge_overrides dict is empty."""
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(
                recognition=ManifestRecognition(
                    badges=[
                        ManifestRecognitionBadge(id="b1", name="Badge", description="Desc", criteria="x >= 1"),
                    ],
                ),
                i18n=ManifestI18n(
                    default_locale="en",
                    locales={
                        "en": ManifestLocale(),
                        "pt-BR": ManifestLocale(
                            # recognition key present but "badges" sub-dict is empty
                            recognition={"description": "Recognition em pt"},
                        ),
                    },
                ),
            ),
        )
        result = get_localized_manifest(m, "pt-BR")
        # Badge name should be unchanged since badge_overrides is empty
        assert result.spec.recognition.badges[0].name == "Badge"

    def test_recognition_badge_not_in_overrides_continues(self) -> None:
        """_apply_recognition_overrides: continue when badge id not in overrides."""
        m = Manifest(
            metadata=ManifestMetadata(name="test"),
            spec=ManifestSpec(
                recognition=ManifestRecognition(
                    badges=[
                        ManifestRecognitionBadge(id="b1", name="Badge One", description="Desc", criteria="x >= 1"),
                    ],
                ),
                i18n=ManifestI18n(
                    default_locale="en",
                    locales={
                        "en": ManifestLocale(),
                        "pt-BR": ManifestLocale(
                            # "badges" dict has a different badge id that doesn't match "b1"
                            recognition={"badges": {"other-badge": {"name": "Other"}}},
                        ),
                    },
                ),
            ),
        )
        result = get_localized_manifest(m, "pt-BR")
        # b1 not in overrides → continue → name unchanged
        assert result.spec.recognition.badges[0].name == "Badge One"


class TestThemeCSSVarsEdgeCases:
    """Tests for edge cases in theme CSS var collection functions."""

    def test_colors_none_returns_empty_color_vars(self) -> None:
        """When preset.colors is None, _collect_color_css_vars returns empty dict (line 701)."""
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme.presets["no-colors"] = ManifestThemePreset(
            label="No Colors",
            colors=None,  # type: ignore[arg-type]
        )
        css = get_manifest_theme_css_vars(bare, "no-colors")
        assert css is not None
        assert "--primary" not in css
        assert "--background" not in css

    def test_extra_colors_included_in_css_vars(self) -> None:
        """When preset.colors.extra is set, extra keys are included (lines 707-708)."""
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme.presets["with-extra"] = ManifestThemePreset(
            label="With Extra",
            colors=ManifestThemeColors(
                primary="100 100% 50%",
                extra={"my-brand": "#ff0000", "my-accent": "#00ff00"},
            ),
            copilot_kit=None,
            fonts=None,
        )
        css = get_manifest_theme_css_vars(bare, "with-extra")
        assert css is not None
        assert css["--my-brand"] == "#ff0000"
        assert css["--my-accent"] == "#00ff00"

    def test_no_copilot_kit_returns_no_copilot_vars(self) -> None:
        """When preset.copilot_kit is None, no --copilot-kit-* vars are included (line 715)."""
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme.presets["no-copilot"] = ManifestThemePreset(
            label="No Copilot",
            colors=ManifestThemeColors(primary="100 100% 50%"),
            copilot_kit=None,
            fonts={"sans": "Arial"},
        )
        css = get_manifest_theme_css_vars(bare, "no-copilot")
        assert css is not None
        assert not any("copilot" in k for k in css)

    def test_no_fonts_returns_no_font_vars(self) -> None:
        """When preset.fonts is None, no --font-* vars are included (line 722)."""
        bare = copy.deepcopy(MANIFEST)
        bare.spec.theme.presets["no-fonts"] = ManifestThemePreset(
            label="No Fonts",
            colors=ManifestThemeColors(primary="100 100% 50%"),
            copilot_kit={"primary-color": "#000"},
            fonts=None,
        )
        css = get_manifest_theme_css_vars(bare, "no-fonts")
        assert css is not None
        assert not any(k.startswith("--font") for k in css)
