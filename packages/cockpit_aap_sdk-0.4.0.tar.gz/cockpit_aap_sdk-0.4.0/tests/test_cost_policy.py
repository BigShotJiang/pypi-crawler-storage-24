"""Tests for cockpit_aap.cost.policy — CostPolicyReader."""
import pytest
from cockpit_aap.cost.policy import CostPolicyReader

SAMPLE_SPEC = {
    "currency": "USD",
    "models": {
        "gpt-4o": {"inputPer1k": 0.005, "outputPer1k": 0.015},
        "gpt-4o-mini": {"inputPer1k": 0.00015, "outputPer1k": 0.0006},
    },
    "budgets": [
        {"scope": "module", "daily": 10.0, "monthly": 100.0, "onExceeded": "warn", "warnAt": 0.8},
        {"scope": "tenant", "inherit": True, "onExceeded": "block"},
        {"scope": "agent", "agentId": "my-agent", "daily": 5.0, "onExceeded": "warn"},
        {"scope": "agent", "agentId": "*", "daily": 3.0, "onExceeded": "warn"},
    ],
    "enforcement": {"preCall": True, "cacheSeconds": 30, "accumulatorSyncInterval": 60},
    "prometheus": {"endpoint": "http://prometheus:9090", "metricPrefix": "aap.llm"},
}


def test_get_model_pricing():
    reader = CostPolicyReader(SAMPLE_SPEC)
    p = reader.get_model_pricing("gpt-4o")
    assert p == {"inputPer1k": 0.005, "outputPer1k": 0.015}


def test_get_model_pricing_unknown():
    reader = CostPolicyReader(SAMPLE_SPEC)
    assert reader.get_model_pricing("unknown") is None


def test_calculate_cost():
    reader = CostPolicyReader(SAMPLE_SPEC)
    cost = reader.calculate_cost("gpt-4o", 1000, 500)
    assert abs(cost - 0.0125) < 0.0001


def test_calculate_cost_unknown_model():
    reader = CostPolicyReader(SAMPLE_SPEC)
    assert reader.calculate_cost("unknown", 1000, 500) == 0.0


def test_get_budget_module():
    reader = CostPolicyReader(SAMPLE_SPEC)
    b = reader.get_budget("module")
    assert b is not None
    assert b["daily"] == 10.0
    assert b["onExceeded"] == "warn"


def test_get_budget_tenant_inherit():
    reader = CostPolicyReader(SAMPLE_SPEC)
    b = reader.get_budget("tenant")
    assert b is not None
    assert b["inherit"] is True
    assert b["onExceeded"] == "block"


def test_get_budget_agent_exact():
    reader = CostPolicyReader(SAMPLE_SPEC)
    b = reader.get_budget("agent", agent_id="my-agent")
    assert b is not None
    assert b["daily"] == 5.0


def test_get_budget_agent_wildcard():
    reader = CostPolicyReader(SAMPLE_SPEC)
    b = reader.get_budget("agent", agent_id="other-agent")
    assert b is not None
    assert b["daily"] == 3.0


def test_properties():
    reader = CostPolicyReader(SAMPLE_SPEC)
    assert reader.prometheus_endpoint == "http://prometheus:9090"
    assert reader.metric_prefix == "aap.llm"
    assert reader.pre_call is True
    assert reader.cache_seconds == 30
    assert reader.sync_interval == 60


def test_empty_spec():
    reader = CostPolicyReader({})
    assert reader.get_model_pricing("gpt-4o") is None
    assert reader.calculate_cost("gpt-4o", 1000, 500) == 0.0
    assert reader.get_budget("module") is None
    assert reader.pre_call is False


def test_from_file(tmp_path):
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("""
apiVersion: governance.cockpit.io/v1
kind: CostPolicy
metadata:
  name: test
spec:
  models:
    gpt-4o:
      inputPer1k: 0.005
      outputPer1k: 0.015
""")
    reader = CostPolicyReader.from_file(str(tmp_path))
    assert reader.get_model_pricing("gpt-4o") is not None


def test_from_file_wrong_kind(tmp_path):
    manifest = tmp_path / "manifest.yaml"
    manifest.write_text("""
apiVersion: governance.cockpit.io/v1
kind: Module
metadata:
  name: test
spec: {}
""")
    with pytest.raises(ValueError, match="CostPolicy"):
        CostPolicyReader.from_file(str(tmp_path))
