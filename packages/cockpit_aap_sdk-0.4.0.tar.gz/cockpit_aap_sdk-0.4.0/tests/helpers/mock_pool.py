"""In-memory mock that implements AsyncConnectionLike for testing Postgres adapters.

Port of the TypeScript ``createMockPool()`` (packages/bootstrap/src/__tests__/helpers/mock-pool.ts).

Supports the SQL patterns used by our Python Postgres adapters:
  - CREATE TABLE / INDEX / SCHEMA (DDL → no-op)
  - INSERT ... ON CONFLICT (DO NOTHING / DO UPDATE) with RETURNING
  - SELECT ... WHERE key ~ $1 (regex), key = $1, ILIKE, LIKE
  - SELECT COALESCE(MAX(v), 0) (migrations)
  - UPDATE ... SET ... WHERE id = $2
  - DELETE ... WHERE thread_id = $1 / updated_at conditions

Tables are stored as ``dict[str, list[dict]]``. Schema-qualified names
are normalized (``schema.table`` → ``table``).
"""

from __future__ import annotations

import json
import re
import uuid
from datetime import datetime, timezone
from typing import Any


Row = dict[str, Any]


class _Record(dict):
    """Dict sub-class that supports both ``row["col"]`` and ``row.col``."""

    def __getattr__(self, name: str) -> Any:
        try:
            return self[name]
        except KeyError:
            raise AttributeError(name)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _normalize_table(name: str) -> str:
    """Strip schema prefix (e.g. ``test_pg.aap_sessions`` → ``aap_sessions``)."""
    return name.split(".")[-1] if "." in name else name


class MockPool:
    """Async in-memory pool matching ``AsyncConnectionLike`` protocol.

    All methods are ``async`` to mirror asyncpg's API.
    """

    def __init__(self) -> None:
        self._tables: dict[str, list[Row]] = {}

    def _get_table(self, name: str) -> list[Row]:
        key = _normalize_table(name)
        if key not in self._tables:
            self._tables[key] = []
        return self._tables[key]

    # ------------------------------------------------------------------
    # SQL engine (mini interpreter)
    # ------------------------------------------------------------------

    def _exec_single(self, sql: str, args: tuple[Any, ...]) -> tuple[list[Row], int]:
        """Execute a single SQL statement, return (rows, rowCount)."""

        # ── DDL: CREATE TABLE / INDEX / SCHEMA → no-op ──
        if re.match(r"^\s*CREATE\s+(TABLE|INDEX|SCHEMA)", sql, re.I):
            return [], 0

        # ── DDL: ALTER TABLE → no-op (mock doesn't enforce schema changes) ──
        if re.match(r"^\s*ALTER\s+TABLE", sql, re.I):
            return [], 0

        # ── INSERT → parse columns, values, ON CONFLICT, RETURNING ──
        insert_m = re.search(
            r"INSERT\s+INTO\s+(\S+)\s*\(([^)]+)\)\s*VALUES\s*\(([^)]+)\)",
            sql,
            re.I,
        )
        if insert_m:
            return self._handle_insert(sql, insert_m, args)

        # ── SELECT COALESCE(MAX(v), 0) — migration version ──
        if re.search(r"COALESCE\(MAX\(v\)", sql, re.I):
            table = self._get_table("aap_migrations")
            max_v = max((int(r.get("v", 0)) for r in table), default=0)
            return [_Record({"coalesce": str(max_v)})], 1

        # ── DELETE ... WHERE thread_id = $1 ──
        if re.match(r"\s*DELETE", sql, re.I) and re.search(r"WHERE\s+thread_id\s*=", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            table = self._get_table(table_name)
            before = len(table)
            self._tables[_normalize_table(table_name)] = [
                r for r in table if r.get("thread_id") != args[0]
            ]
            removed = before - len(self._tables[_normalize_table(table_name)])
            return [], removed

        # ── DELETE ... WHERE updated_at < ... (prune) ──
        if re.match(r"\s*DELETE", sql, re.I) and re.search(r"WHERE\s+updated_at", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            table = self._get_table(table_name)
            ttl_ms = int(args[0]) if args else 0
            cutoff = datetime.now(timezone.utc).timestamp() * 1000 - ttl_ms
            before = len(table)
            remaining = []
            for r in table:
                try:
                    ts = datetime.fromisoformat(str(r.get("updated_at", ""))).timestamp() * 1000
                except (ValueError, TypeError):
                    ts = 0
                if ts >= cutoff:
                    remaining.append(r)
            self._tables[_normalize_table(table_name)] = remaining
            removed = before - len(remaining)
            return [], removed

        # ── UPDATE ... SET value = $1 ... WHERE id = $2 ──
        if re.match(r"\s*UPDATE", sql, re.I):
            tbl_m = re.search(r"UPDATE\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            table = self._get_table(table_name)
            count = 0
            for row in table:
                if re.search(r"WHERE\s+id\s*=", sql, re.I) and row.get("id") == args[1]:
                    row["value"] = args[0]
                    row["updated_at"] = _now_iso()
                    count += 1
            return [], count

        # ── SELECT ... WHERE key ~ $1 (regex match) ──
        if re.search(r"WHERE\s+key\s+~", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            table = self._get_table(table_name)
            pattern = re.compile(str(args[0]))
            rows = [_Record(r) for r in table if pattern.search(str(r.get("key", "")))]
            return rows, len(rows)

        # ── SELECT ... WHERE key = $1 ──
        if re.search(r"WHERE\s+key\s*=", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [_Record(r) for r in self._get_table(table_name) if r.get("key") == args[0]]
            return rows, len(rows)

        # ── SELECT ... WHERE name ILIKE $1 ──
        if re.search(r"WHERE\s+name\s+ILIKE", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            pattern_str = str(args[0]).replace("%", ".*")
            pat = re.compile(pattern_str, re.I)
            rows = [_Record(r) for r in self._get_table(table_name) if pat.search(str(r.get("name", "")))]
            return rows, len(rows)

        # ── SELECT ... WHERE id=$1 AND kind=$2 AND license_id=$3 AND namespace_id=$4 ──
        if re.search(
            r"WHERE\s+id\s*=\s*\$1\s+AND\s+kind\s*=\s*\$2\s+AND\s+license_id\s*=\s*\$3\s+AND\s+namespace_id\s*=\s*\$4",
            sql, re.I,
        ):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [
                _Record(r) for r in self._get_table(table_name)
                if (
                    r.get("id") == args[0]
                    and r.get("kind") == args[1]
                    and r.get("license_id", "_global") == args[2]
                    and r.get("namespace_id", "_global") == args[3]
                )
            ]
            return rows, len(rows)

        # ── SELECT ... WHERE id = $1 AND kind = $2 ──
        if re.search(r"WHERE\s+id\s*=\s*\$1\s+AND\s+kind\s*=\s*\$2", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [
                _Record(r) for r in self._get_table(table_name)
                if r.get("id") == args[0] and r.get("kind") == args[1]
            ]
            return rows, len(rows)

        # ── SELECT ... WHERE id = $1 ──
        if re.search(r"WHERE\s+id\s*=", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [_Record(r) for r in self._get_table(table_name) if r.get("id") == args[0]]
            return rows, len(rows)

        # ── SELECT ... WHERE kind=$1 AND license_id=$2 AND namespace_id=$3 ──
        if re.search(
            r"WHERE\s+kind\s*=\s*\$1\s+AND\s+license_id\s*=\s*\$2\s+AND\s+namespace_id\s*=\s*\$3",
            sql, re.I,
        ):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [
                _Record(r) for r in self._get_table(table_name)
                if (
                    r.get("kind") == args[0]
                    and r.get("license_id", "_global") == args[1]
                    and r.get("namespace_id", "_global") == args[2]
                )
            ]
            return rows, len(rows)

        # ── SELECT ... WHERE kind = $1 ──
        if re.search(r"WHERE\s+kind\s*=", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [_Record(r) for r in self._get_table(table_name) if r.get("kind") == args[0]]
            return rows, len(rows)

        # ── SELECT ... WHERE thread_id = $1 ──
        if re.search(r"WHERE\s+thread_id\s*=", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [_Record(r) for r in self._get_table(table_name) if r.get("thread_id") == args[0]]
            return rows, len(rows)

        # ── SELECT ... WHERE thread_id LIKE $1 ──
        if re.search(r"WHERE\s+thread_id\s+LIKE", sql, re.I):
            prefix = str(args[0]).rstrip("%")
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [
                _Record(r) for r in self._get_table(table_name)
                if str(r.get("thread_id", "")).startswith(prefix)
            ]
            return rows, len(rows)

        # ── SELECT ... WHERE license_id=$1 AND namespace_id=$2 ──
        if re.search(
            r"WHERE\s+license_id\s*=\s*\$1\s+AND\s+namespace_id\s*=\s*\$2",
            sql, re.I,
        ):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [
                _Record(r) for r in self._get_table(table_name)
                if (
                    r.get("license_id", "_global") == args[0]
                    and r.get("namespace_id", "_global") == args[1]
                )
            ]
            return rows, len(rows)

        # ── SELECT (generic — all rows) ──
        if re.match(r"\s*SELECT", sql, re.I):
            tbl_m = re.search(r"FROM\s+(\S+)", sql, re.I)
            table_name = tbl_m.group(1) if tbl_m else ""
            rows = [_Record(r) for r in self._get_table(table_name)]
            return rows, len(rows)

        # Fallback
        return [], 0

    def _handle_insert(
        self,
        sql: str,
        insert_m: re.Match,
        args: tuple[Any, ...],
    ) -> tuple[list[Row], int]:
        table = self._get_table(insert_m.group(1))
        cols = [c.strip() for c in insert_m.group(2).split(",")]
        placeholders = [v.strip() for v in insert_m.group(3).split(",")]

        row: Row = {}
        for i, col in enumerate(cols):
            ph = placeholders[i]
            if ph.upper() == "NOW()":
                row[col] = _now_iso()
            elif ph.startswith("$"):
                # Strip Postgres type casts like $2::jsonb → $2
                clean_ph = re.sub(r"::\w+", "", ph)
                idx = int(clean_ph[1:]) - 1
                row[col] = args[idx] if idx < len(args) else None
            else:
                # Literal in SQL (e.g. quoted UUID in migrations)
                row[col] = ph.strip("'\"")

        has_on_conflict = bool(re.search(r"ON\s+CONFLICT", sql, re.I))
        has_do_nothing = bool(re.search(r"DO\s+NOTHING", sql, re.I))
        has_do_update = bool(re.search(r"DO\s+UPDATE", sql, re.I))
        has_returning = bool(re.search(r"RETURNING", sql, re.I))

        if has_on_conflict:
            conflict_m = re.search(r"ON\s+CONFLICT\s*\(([^)]+)\)", sql, re.I)
            conflict_cols = [c.strip() for c in conflict_m.group(1).split(",")] if conflict_m else []

            # When no explicit conflict columns are specified (e.g. ON CONFLICT DO NOTHING),
            # we cannot determine a conflict without knowing the PRIMARY KEY — just insert.
            if not conflict_cols:
                table.append(row)
                return ([_Record(row)] if has_returning else []), 1

            existing_idx = None
            for idx, existing in enumerate(table):
                if all(existing.get(c) == row.get(c) for c in conflict_cols):
                    existing_idx = idx
                    break

            if existing_idx is not None:
                if has_do_update:
                    set_m = re.search(r"DO\s+UPDATE\s+SET\s+(.+?)(?:\s+RETURNING|$)", sql, re.I | re.S)
                    if set_m:
                        clauses = set_m.group(1).split(",")
                        for clause in clauses:
                            col_part = clause.split("=")[0].strip()
                            if col_part == "updated_at":
                                table[existing_idx]["updated_at"] = _now_iso()
                            else:
                                # EXCLUDED.col → new row value
                                table[existing_idx][col_part] = row.get(col_part)
                    return ([_Record(table[existing_idx])] if has_returning else []), 1
                # DO NOTHING
                return [], 0

        # New row
        table.append(row)
        return ([_Record(row)] if has_returning else []), 1

    # ------------------------------------------------------------------
    # Public asyncpg-compatible interface (AsyncConnectionLike)
    # ------------------------------------------------------------------

    async def execute(self, query: str, *args: Any, timeout: float | None = None) -> str:
        """Execute SQL. Multi-statement strings (split by ';') are supported."""
        sql = query.strip()
        statements = [s.strip() for s in sql.split(";") if s.strip()]

        total_count = 0
        for stmt in statements:
            _, count = self._exec_single(stmt, args)
            total_count += count
        return f"DELETE {total_count}"  # asyncpg returns "DELETE N" / "INSERT 0 1" etc.

    async def fetch(self, query: str, *args: Any, timeout: float | None = None) -> list[Any]:
        """Execute SQL and return all matching rows."""
        rows, _ = self._exec_single(query.strip(), args)
        return rows

    async def fetchrow(self, query: str, *args: Any, timeout: float | None = None) -> Any | None:
        """Execute SQL and return the first row, or None."""
        rows, _ = self._exec_single(query.strip(), args)
        return rows[0] if rows else None

    async def fetchval(
        self, query: str, *args: Any, column: int = 0, timeout: float | None = None
    ) -> Any:
        """Execute SQL and return a single value from the first row."""
        rows, _ = self._exec_single(query.strip(), args)
        if not rows:
            return None
        row = rows[0]
        if isinstance(row, dict):
            vals = list(row.values())
            return vals[column] if column < len(vals) else None
        return row


def create_mock_pool() -> MockPool:
    """Create a fresh in-memory mock pool for testing."""
    return MockPool()
