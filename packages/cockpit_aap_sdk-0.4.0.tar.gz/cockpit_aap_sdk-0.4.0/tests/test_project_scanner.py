"""Tests for cockpit_aap.manifest.project_scanner — scan/is/read."""

import os
import tempfile
import pytest

from cockpit_aap.manifest.project_scanner import (
    scan_project,
    is_project_dir,
    read_project_meta,
)


def _write_project_yaml(tmpdir: str, content: str) -> None:
    with open(os.path.join(tmpdir, "project.yaml"), "w") as f:
        f.write(content)


def _make_module_dir(tmpdir: str, module_path: str, module_id: str) -> None:
    """Create a minimal .aap/<id>/manifest.yaml inside the project."""
    manifest_dir = os.path.join(tmpdir, module_path)
    os.makedirs(manifest_dir, exist_ok=True)
    with open(os.path.join(manifest_dir, "manifest.yaml"), "w") as f:
        f.write(f"""\
apiVersion: cockpit.io/v1
kind: Module
metadata:
  name: {module_id}
  displayName: {module_id.title()}
  version: "1.0.0"
spec: {{}}
""")


def test_is_project_dir_true():
    with tempfile.TemporaryDirectory() as tmpdir:
        _write_project_yaml(tmpdir, "project:\n  id: test")
        assert is_project_dir(tmpdir) is True


def test_is_project_dir_false():
    with tempfile.TemporaryDirectory() as tmpdir:
        assert is_project_dir(tmpdir) is False


def test_read_project_meta():
    with tempfile.TemporaryDirectory() as tmpdir:
        _write_project_yaml(
            tmpdir,
            """\
project:
  id: my-project
  name: My Project
modules:
  - id: mod-a
    path: .aap/mod-a
""",
        )
        meta = read_project_meta(tmpdir)
        assert meta.project.id == "my-project"
        assert len(meta.modules) == 1


def test_read_project_meta_not_found():
    with tempfile.TemporaryDirectory() as tmpdir:
        with pytest.raises(FileNotFoundError):
            read_project_meta(tmpdir)


def test_scan_project_resolves_modules():
    with tempfile.TemporaryDirectory() as tmpdir:
        _make_module_dir(tmpdir, ".aap/mod-a", "mod-a")
        _make_module_dir(tmpdir, ".aap/mod-b", "mod-b")
        _write_project_yaml(
            tmpdir,
            """\
project:
  id: demo
  name: Demo Project
modules:
  - id: mod-a
    path: .aap/mod-a
  - id: mod-b
    path: .aap/mod-b
    default: true
""",
        )
        result = scan_project(tmpdir)
        assert result.project.id == "demo"
        assert len(result.modules) == 2
        # mod-b should be the default
        default_mod = next(m for m in result.modules if m.default)
        assert default_mod.id == "mod-b"


def test_scan_project_missing_module_path():
    with tempfile.TemporaryDirectory() as tmpdir:
        _write_project_yaml(
            tmpdir,
            """\
project:
  id: broken
  name: Broken Project
modules:
  - id: missing
    path: .aap/missing
""",
        )
        with pytest.raises(FileNotFoundError, match="Module path not found"):
            scan_project(tmpdir)


def test_scan_project_no_modules():
    with tempfile.TemporaryDirectory() as tmpdir:
        _write_project_yaml(tmpdir, "project:\n  id: empty\nmodules: []")
        with pytest.raises(ValueError, match="has no modules"):
            scan_project(tmpdir)


def test_scan_project_no_project_file():
    with tempfile.TemporaryDirectory() as tmpdir:
        with pytest.raises(FileNotFoundError, match="No project manifest"):
            scan_project(tmpdir)
