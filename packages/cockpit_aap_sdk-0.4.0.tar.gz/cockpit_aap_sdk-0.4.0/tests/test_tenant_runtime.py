"""Tests for TenantAgentRuntime."""
from __future__ import annotations

import pytest

from cockpit_aap.runtime.tenant_runtime import TenantAgentRuntime
from cockpit_aap.runtime.types import RuntimeContext
from cockpit_aap.ports.tenant_resolver import TenantContext


def _make_manifest(greeting: str = "default") -> dict:
    return {
        "apiVersion": "cockpit.io/v1",
        "kind": "Module",
        "metadata": {"name": "test"},
        "spec": {"guardrails": {}, "telemetry": {}, "cost": {}},
        "_greeting": greeting,  # marker to verify which manifest was used
    }


@pytest.mark.asyncio
async def test_for_tenant_creates_runtime():
    async def loader(mid: str) -> dict:
        return _make_manifest()

    factory = TenantAgentRuntime(
        manifest_loader=loader,
        module_id="test",
        adapter_factory=lambda m: {},
    )

    tenant = TenantContext(license_id="acme", namespace_id="eng")
    runtime = await factory.for_tenant(tenant)
    assert runtime is not None


@pytest.mark.asyncio
async def test_for_tenant_caches_by_tenant():
    call_count = 0

    async def loader(mid: str) -> dict:
        nonlocal call_count
        call_count += 1
        return _make_manifest()

    factory = TenantAgentRuntime(
        manifest_loader=loader,
        module_id="test",
        adapter_factory=lambda m: {},
        cache_ttl=60,
    )

    tenant = TenantContext(license_id="acme", namespace_id="eng")
    r1 = await factory.for_tenant(tenant)
    r2 = await factory.for_tenant(tenant)
    assert r1 is r2
    assert call_count == 1


@pytest.mark.asyncio
async def test_different_tenants_get_different_runtimes():
    async def loader(mid: str) -> dict:
        return _make_manifest()

    factory = TenantAgentRuntime(
        manifest_loader=loader,
        module_id="test",
        adapter_factory=lambda m: {},
    )

    t1 = TenantContext(license_id="acme", namespace_id="eng")
    t2 = TenantContext(license_id="acme", namespace_id="sales")
    r1 = await factory.for_tenant(t1)
    r2 = await factory.for_tenant(t2)
    assert r1 is not r2


@pytest.mark.asyncio
async def test_invalidate_clears_cache():
    call_count = 0

    async def loader(mid: str) -> dict:
        nonlocal call_count
        call_count += 1
        return _make_manifest()

    factory = TenantAgentRuntime(
        manifest_loader=loader,
        module_id="test",
        adapter_factory=lambda m: {},
        cache_ttl=60,
    )

    tenant = TenantContext(license_id="acme", namespace_id="eng")
    await factory.for_tenant(tenant)
    factory.invalidate(tenant)
    await factory.for_tenant(tenant)
    assert call_count == 2


@pytest.mark.asyncio
async def test_invalidate_all_clears_entire_cache():
    call_count = 0

    async def loader(mid: str) -> dict:
        nonlocal call_count
        call_count += 1
        return _make_manifest()

    factory = TenantAgentRuntime(
        manifest_loader=loader,
        module_id="test",
        adapter_factory=lambda m: {},
        cache_ttl=60,
    )

    t1 = TenantContext(license_id="acme", namespace_id="eng")
    t2 = TenantContext(license_id="acme", namespace_id="sales")
    await factory.for_tenant(t1)
    await factory.for_tenant(t2)
    assert call_count == 2

    factory.invalidate()  # clear all
    await factory.for_tenant(t1)
    await factory.for_tenant(t2)
    assert call_count == 4


@pytest.mark.asyncio
async def test_global_tenant_key():
    async def loader(mid: str) -> dict:
        return _make_manifest()

    factory = TenantAgentRuntime(
        manifest_loader=loader,
        module_id="test",
        adapter_factory=lambda m: {},
    )

    r1 = await factory.for_tenant(None)
    r2 = await factory.for_tenant(None)
    assert r1 is r2


@pytest.mark.asyncio
async def test_before_call_convenience():
    async def loader(mid: str) -> dict:
        return _make_manifest()

    factory = TenantAgentRuntime(
        manifest_loader=loader,
        module_id="test",
        adapter_factory=lambda m: {},
    )

    ctx = RuntimeContext(agent_id="a", request_id="r", input="hello", model="test")
    tenant = TenantContext(license_id="acme", namespace_id="eng")
    decision = await factory.before_call(ctx, tenant)
    assert decision.allowed is True


@pytest.mark.asyncio
async def test_after_call_convenience():
    from cockpit_aap.runtime.types import RuntimeResult

    async def loader(mid: str) -> dict:
        return _make_manifest()

    factory = TenantAgentRuntime(
        manifest_loader=loader,
        module_id="test",
        adapter_factory=lambda m: {},
    )

    ctx = RuntimeContext(agent_id="a", request_id="r", input="hello", model="test")
    result = RuntimeResult(output="world")
    tenant = TenantContext(license_id="acme", namespace_id="eng")
    decision = await factory.after_call(ctx, result, tenant)
    assert decision.allowed is True
