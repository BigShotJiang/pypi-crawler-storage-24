"""Tests for MCP transport (JSON-RPC 2.0)."""

from __future__ import annotations

import json
from http.server import HTTPServer, BaseHTTPRequestHandler
from threading import Thread
from typing import Any

import pytest

from cockpit_aap.transport import TransportContext
from cockpit_aap.transports.mcp import McpTransport


MOCK_TOOLS = [
    {
        "name": "get_agent_card",
        "description": "Get the agent card",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "execute_agent",
        "description": "Execute an agent",
        "inputSchema": {
            "type": "object",
            "required": ["user_input"],
            "properties": {"user_input": {"type": "string"}},
        },
    },
]

SESSION_ID = "test-session-python"
request_log: list[dict[str, Any]] = []


class MockMCPHandler(BaseHTTPRequestHandler):
    """Mock JSON-RPC 2.0 MCP server."""

    def do_POST(self) -> None:
        length = int(self.headers.get("Content-Length", 0))
        body = json.loads(self.rfile.read(length)) if length else {}

        request_log.append({
            "method": body.get("method"),
            "id": body.get("id"),
            "params": body.get("params"),
        })

        # Notification (no id)
        if "id" not in body:
            self.send_response(202)
            self.send_header("Mcp-Session-Id", SESSION_ID)
            self.end_headers()
            return

        method = body.get("method", "")
        req_id = body["id"]

        if method == "initialize":
            self._json_rpc_response(req_id, {
                "protocolVersion": "2024-11-05",
                "capabilities": {"tools": {"listChanged": False}},
                "serverInfo": {"name": "Mock MCP", "version": "1.0.0"},
            })
        elif method == "tools/list":
            self._json_rpc_response(req_id, {"tools": MOCK_TOOLS})
        elif method == "tools/call":
            tool_name = body.get("params", {}).get("name", "")
            args = body.get("params", {}).get("arguments", {})
            if tool_name == "get_agent_card":
                self._json_rpc_response(req_id, {
                    "content": [{"type": "text", "text": json.dumps({"name": "Test Agent"})}],
                    "isError": False,
                })
            elif tool_name == "execute_agent":
                user_input = args.get("user_input", "")
                self._json_rpc_response(req_id, {
                    "content": [{"type": "text", "text": json.dumps({"response": f"Echo: {user_input}"})}],
                    "isError": False,
                })
            elif tool_name == "plain_text_tool":
                self._json_rpc_response(req_id, {
                    "content": [{"type": "text", "text": "Hello plain text"}],
                    "isError": False,
                })
            else:
                self._json_rpc_error(req_id, -32601, f"Unknown tool: {tool_name}")
        else:
            self._json_rpc_error(req_id, -32601, "Method not found")

    def _json_rpc_response(self, req_id: int, result: Any) -> None:
        payload = json.dumps({"jsonrpc": "2.0", "id": req_id, "result": result}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Mcp-Session-Id", SESSION_ID)
        self.end_headers()
        self.wfile.write(payload)

    def _json_rpc_error(self, req_id: int, code: int, message: str) -> None:
        payload = json.dumps({
            "jsonrpc": "2.0",
            "id": req_id,
            "error": {"code": code, "message": message},
        }).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.send_header("Mcp-Session-Id", SESSION_ID)
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        pass


@pytest.fixture(scope="module")
def mock_mcp_server():
    """Start a mock MCP JSON-RPC server."""
    server = HTTPServer(("127.0.0.1", 0), MockMCPHandler)
    port = server.server_address[1]
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


def make_ctx(endpoint: str) -> TransportContext:
    async def get_headers() -> dict[str, str]:
        return {"x-api-key": "test-key"}
    return TransportContext(endpoint=endpoint, timeout=10.0, get_headers=get_headers)


@pytest.mark.asyncio
async def test_init_discovers_tools(mock_mcp_server: str) -> None:
    transport = McpTransport(default_namespace="cockpit-agent")
    ctx = make_ctx(mock_mcp_server)
    tools = await transport.init(ctx)

    assert len(tools) == 2
    assert tools[0]["name"] == "get_agent_card"
    assert tools[0]["namespace"] == "cockpit-agent"
    assert tools[1]["name"] == "execute_agent"

    await transport.close()


@pytest.mark.asyncio
async def test_init_handshake_order(mock_mcp_server: str) -> None:
    request_log.clear()
    transport = McpTransport(default_namespace="test")
    ctx = make_ctx(mock_mcp_server)
    await transport.init(ctx)

    assert len(request_log) == 3
    assert request_log[0]["method"] == "initialize"
    assert request_log[1]["method"] == "notifications/initialized"
    assert request_log[1]["id"] is None  # notification has no id
    assert request_log[2]["method"] == "tools/list"

    await transport.close()


@pytest.mark.asyncio
async def test_session_id_captured(mock_mcp_server: str) -> None:
    transport = McpTransport(default_namespace="test")
    ctx = make_ctx(mock_mcp_server)
    await transport.init(ctx)

    assert transport.session_id == SESSION_ID

    await transport.close()


@pytest.mark.asyncio
async def test_call_tool_json_content(mock_mcp_server: str) -> None:
    transport = McpTransport(default_namespace="cockpit-agent")
    ctx = make_ctx(mock_mcp_server)
    await transport.init(ctx)

    result = await transport.call_tool(ctx, "cockpit-agent", "get_agent_card", {})
    assert result["isError"] is False
    assert result["content"] == {"name": "Test Agent"}

    await transport.close()


@pytest.mark.asyncio
async def test_call_tool_passes_args(mock_mcp_server: str) -> None:
    transport = McpTransport(default_namespace="cockpit-agent")
    ctx = make_ctx(mock_mcp_server)
    await transport.init(ctx)

    result = await transport.call_tool(
        ctx, "cockpit-agent", "execute_agent", {"user_input": "Hello from Python"}
    )
    assert result["isError"] is False
    assert result["content"] == {"response": "Echo: Hello from Python"}

    await transport.close()


@pytest.mark.asyncio
async def test_call_tool_plain_text(mock_mcp_server: str) -> None:
    transport = McpTransport(default_namespace="cockpit-agent")
    ctx = make_ctx(mock_mcp_server)
    await transport.init(ctx)

    result = await transport.call_tool(ctx, "cockpit-agent", "plain_text_tool", {})
    assert result["isError"] is False
    assert result["content"] == "Hello plain text"

    await transport.close()


@pytest.mark.asyncio
async def test_call_tool_unknown_raises(mock_mcp_server: str) -> None:
    transport = McpTransport(default_namespace="cockpit-agent")
    ctx = make_ctx(mock_mcp_server)
    await transport.init(ctx)

    with pytest.raises(RuntimeError, match="MCP JSON-RPC Error"):
        await transport.call_tool(ctx, "cockpit-agent", "nonexistent", {})

    await transport.close()
