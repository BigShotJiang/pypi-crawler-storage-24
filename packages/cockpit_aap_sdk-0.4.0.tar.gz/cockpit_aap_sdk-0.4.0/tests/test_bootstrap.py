"""Tests for bootstrap_manifest() orchestrator."""

import os
from unittest.mock import AsyncMock, MagicMock

import pytest
import pytest_asyncio

from cockpit_aap.bootstrap import (
    ManifestResult,
    ResolvedAgent,
    is_newer_version,
    bootstrap_manifest,
    _resolve_agents,
)
from cockpit_aap.manifest.scanner import scan_manifest
from cockpit_aap.manifest.types import Manifest, ManifestMetadata, ManifestAgent, ManifestSpec

FIXTURES = os.path.join(os.path.dirname(__file__), "fixtures")
MULTI_FILE_DIR = os.path.join(FIXTURES, "multi-file")


# ---------------------------------------------------------------------------
# is_newer_version
# ---------------------------------------------------------------------------


class TestIsNewerVersion:
    def test_minor_bump(self):
        """1.1.0 > 1.0.0."""
        assert is_newer_version("1.1.0", "1.0.0") is True

    def test_major_bump(self):
        """2.0.0 > 1.9.9."""
        assert is_newer_version("2.0.0", "1.9.9") is True

    def test_equal_versions(self):
        """1.0.0 == 1.0.0 should return False (not newer)."""
        assert is_newer_version("1.0.0", "1.0.0") is False

    def test_older_version(self):
        """0.9.0 < 1.0.0 should return False."""
        assert is_newer_version("0.9.0", "1.0.0") is False

    def test_patch_bump(self):
        """1.0.1 > 1.0.0."""
        assert is_newer_version("1.0.1", "1.0.0") is True

    def test_different_lengths(self):
        """1.0.0.1 > 1.0.0."""
        assert is_newer_version("1.0.0.1", "1.0.0") is True

    def test_different_lengths_equal(self):
        """1.0.0 == 1.0.0.0 should return False."""
        assert is_newer_version("1.0.0", "1.0.0.0") is False


# ---------------------------------------------------------------------------
# bootstrap_manifest -- local fallback (server unreachable)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bootstrap_local_fallback():
    """When server is unreachable, should fall back to local manifest."""
    sdk = MagicMock()
    sdk.call_tool = AsyncMock(side_effect=ConnectionError("Server unreachable"))

    result = await bootstrap_manifest(sdk, MULTI_FILE_DIR)

    assert isinstance(result, ManifestResult)
    assert result.module == "multi-file-test"
    assert result.manifest_source == "local"
    assert result.manifest.metadata.version == "1.0.0"
    assert result.duration_ms >= 0


# ---------------------------------------------------------------------------
# ManifestResult structure
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bootstrap_result_structure():
    """ManifestResult should have all required fields after bootstrap."""
    sdk = MagicMock()
    sdk.call_tool = AsyncMock(side_effect=ConnectionError("Server unreachable"))

    result = await bootstrap_manifest(sdk, MULTI_FILE_DIR)

    assert hasattr(result, "module")
    assert hasattr(result, "manifest")
    assert hasattr(result, "manifest_source")
    assert hasattr(result, "duration_ms")
    assert hasattr(result, "agents")
    assert hasattr(result, "feedback")

    assert isinstance(result.module, str)
    assert isinstance(result.manifest, Manifest)
    assert result.manifest_source in ("server", "local")
    assert isinstance(result.duration_ms, float)
    assert isinstance(result.agents, dict)


# ---------------------------------------------------------------------------
# Agent resolution
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_bootstrap_resolves_agents():
    """Bootstrap should populate agents from the manifest."""
    sdk = MagicMock()
    sdk.call_tool = AsyncMock(side_effect=ConnectionError("Server unreachable"))

    result = await bootstrap_manifest(sdk, MULTI_FILE_DIR)

    # Multi-file fixture has a "research-agent" -> name: "Research Agent"
    assert "Research Agent" in result.agents
    agent = result.agents["Research Agent"]
    assert isinstance(agent, ResolvedAgent)
    assert agent.name == "Research Agent"
    assert agent.source == "default-fallback"
    assert len(agent.instruction) > 0


def test_resolve_agents_from_manifest():
    """Direct test of _resolve_agents helper."""
    manifest = Manifest(
        metadata=ManifestMetadata(name="test", version="1.0.0", display_name="Test"),
        spec=ManifestSpec(
            agents=[
                ManifestAgent(
                    id="agent-a",
                    name="Agent A",
                    description="First agent",
                    instruction="Do agent A things",
                ),
                ManifestAgent(
                    id="agent-b",
                    name="Agent B",
                    description="Second agent",
                    instruction="Do agent B things",
                ),
            ],
        ),
    )

    agents = _resolve_agents(manifest)

    assert len(agents) == 2
    assert "Agent A" in agents
    assert "Agent B" in agents
    assert agents["Agent A"].instruction == "Do agent A things"
    assert agents["Agent B"].instruction == "Do agent B things"
    assert agents["Agent A"].source == "default-fallback"


# ---------------------------------------------------------------------------
# ManifestResult dataclass
# ---------------------------------------------------------------------------


def test_manifest_result_dataclass():
    """ManifestResult can be created directly with all fields."""
    manifest = Manifest(
        metadata=ManifestMetadata(name="test", version="1.0.0", display_name="Test"),
    )

    result = ManifestResult(
        module="test",
        manifest=manifest,
        manifest_source="local",
        duration_ms=42.0,
        agents={
            "TestAgent": ResolvedAgent(
                name="TestAgent",
                instruction="Test instruction",
                source="default-fallback",
            )
        },
        feedback=None,
    )

    assert result.module == "test"
    assert result.manifest.metadata.name == "test"
    assert result.manifest_source == "local"
    assert result.duration_ms == 42.0
    assert len(result.agents) == 1
    assert result.feedback is None


def test_manifest_result_default_agents():
    """ManifestResult should default to empty agents dict."""
    manifest = Manifest(
        metadata=ManifestMetadata(name="test", version="1.0.0", display_name="Test"),
    )

    result = ManifestResult(
        module="test",
        manifest=manifest,
        manifest_source="local",
        duration_ms=0.0,
    )

    assert result.agents == {}
    assert result.feedback is None


# ---------------------------------------------------------------------------
# ResolvedAgent dataclass
# ---------------------------------------------------------------------------


def test_resolved_agent_dataclass():
    """ResolvedAgent has name, instruction, source fields."""
    agent = ResolvedAgent(
        name="TestAgent",
        instruction="Do things",
        source="server",
    )
    assert agent.name == "TestAgent"
    assert agent.instruction == "Do things"
    assert agent.source == "server"
