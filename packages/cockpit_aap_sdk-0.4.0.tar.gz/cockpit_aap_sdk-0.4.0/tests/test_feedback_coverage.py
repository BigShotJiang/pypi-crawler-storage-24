"""Tests for feedback.py — read/write, analyze_feedback_status, serialization."""
from __future__ import annotations

import json
from unittest.mock import AsyncMock, MagicMock

import pytest

from cockpit_aap.feedback import (
    FeedbackItem,
    ModuleFeedback,
    _escape_regex,
    _extract_value,
    _module_feedback_to_dict,
    _parse_module_feedback,
    analyze_feedback_status,
    read_feedback,
    write_feedback,
)


# ---------------------------------------------------------------------------
# _escape_regex / _extract_value
# ---------------------------------------------------------------------------


def test_escape_regex():
    assert _escape_regex("a.b") == r"a\.b"


class TestExtractValue:
    def test_none(self):
        assert _extract_value(None) is None

    def test_non_dict(self):
        assert _extract_value(42) is None

    def test_empty_dict(self):
        assert _extract_value({}) is None

    def test_artifacts_list(self):
        assert _extract_value({"artifacts": [{"value": "v"}]}) == "v"

    def test_artifacts_empty(self):
        assert _extract_value({"artifacts": []}) is None

    def test_direct_value(self):
        assert _extract_value({"value": "direct"}) == "direct"

    def test_content_key(self):
        assert _extract_value({"content": "cnt"}) == "cnt"


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


class TestSerialization:
    def test_module_feedback_to_dict_full(self):
        fb = ModuleFeedback(
            module="mod",
            items=[
                FeedbackItem(
                    id="fb-1", target="config.theme", status="open",
                    comment="Fix color", created_at="2024-01-01", status_reason=None,
                ),
                FeedbackItem(
                    id="fb-2", target="config.data", status="potentially-addressed",
                    comment=None, created_at=None, status_reason="upgraded",
                ),
            ],
        )
        d = _module_feedback_to_dict(fb)
        assert d["module"] == "mod"
        assert len(d["items"]) == 2
        assert d["items"][0]["comment"] == "Fix color"
        assert d["items"][0]["createdAt"] == "2024-01-01"
        assert "statusReason" not in d["items"][0]
        assert "comment" not in d["items"][1]
        assert d["items"][1]["statusReason"] == "upgraded"

    def test_parse_module_feedback(self):
        raw = {
            "module": "parsed",
            "items": [
                {"id": "1", "target": "t1", "status": "open", "comment": "c", "createdAt": "2024", "statusReason": "r"},
                {"id": "2", "target": "t2", "status": "resolved"},
            ],
        }
        parsed = _parse_module_feedback(raw)
        assert parsed.module == "parsed"
        assert len(parsed.items) == 2
        assert parsed.items[0].comment == "c"
        assert parsed.items[0].created_at == "2024"
        assert parsed.items[0].status_reason == "r"
        assert parsed.items[1].comment is None

    def test_roundtrip(self):
        fb = ModuleFeedback(
            module="rt",
            items=[FeedbackItem(id="1", target="t", status="open", comment="x", created_at="2024", status_reason="s")],
        )
        d = _module_feedback_to_dict(fb)
        parsed = _parse_module_feedback(d)
        assert parsed.items[0].id == fb.items[0].id


# ---------------------------------------------------------------------------
# analyze_feedback_status
# ---------------------------------------------------------------------------


class TestAnalyzeFeedbackStatus:
    def test_none_feedback(self):
        result, addressed = analyze_feedback_status(None, {})
        assert result is None
        assert addressed == []

    def test_empty_items(self):
        fb = ModuleFeedback(module="m", items=[])
        result, addressed = analyze_feedback_status(fb, {})
        assert result is not None
        assert addressed == []

    def test_open_item_becomes_addressed_on_created(self):
        fb = ModuleFeedback(
            module="m",
            items=[FeedbackItem(id="fb-1", target="config.theme", status="open")],
        )
        resolved = {"config.theme": {"source": "created"}}
        result, addressed = analyze_feedback_status(fb, resolved)
        assert addressed == ["fb-1"]
        assert result.items[0].status == "potentially-addressed"
        assert "created" in result.items[0].status_reason

    def test_open_item_becomes_addressed_on_upgraded(self):
        fb = ModuleFeedback(
            module="m",
            items=[FeedbackItem(id="fb-1", target="config.data", status="open")],
        )
        resolved = {"config.data": {"source": "upgraded"}}
        result, addressed = analyze_feedback_status(fb, resolved)
        assert addressed == ["fb-1"]
        assert "upgraded" in result.items[0].status_reason

    def test_open_item_stays_open_when_not_in_resolved(self):
        fb = ModuleFeedback(
            module="m",
            items=[FeedbackItem(id="fb-1", target="config.missing", status="open")],
        )
        result, addressed = analyze_feedback_status(fb, {})
        assert addressed == []
        assert result.items[0].status == "open"

    def test_open_item_stays_open_when_source_is_found(self):
        fb = ModuleFeedback(
            module="m",
            items=[FeedbackItem(id="fb-1", target="config.x", status="open")],
        )
        resolved = {"config.x": {"source": "found"}}
        result, addressed = analyze_feedback_status(fb, resolved)
        assert addressed == []
        assert result.items[0].status == "open"

    def test_resolved_item_unchanged(self):
        fb = ModuleFeedback(
            module="m",
            items=[FeedbackItem(id="fb-1", target="t", status="resolved")],
        )
        resolved = {"t": {"source": "upgraded"}}
        result, addressed = analyze_feedback_status(fb, resolved)
        assert addressed == []
        assert result.items[0].status == "resolved"

    def test_mixed_items(self):
        fb = ModuleFeedback(
            module="m",
            items=[
                FeedbackItem(id="1", target="t1", status="open"),
                FeedbackItem(id="2", target="t2", status="resolved"),
                FeedbackItem(id="3", target="t3", status="open"),
            ],
        )
        resolved = {
            "t1": {"source": "upgraded"},
            "t3": {"source": "found"},
        }
        result, addressed = analyze_feedback_status(fb, resolved)
        assert addressed == ["1"]
        assert result.items[0].status == "potentially-addressed"
        assert result.items[1].status == "resolved"
        assert result.items[2].status == "open"

    def test_source_via_dataclass_attr(self):
        """When resolved item has .source attribute instead of dict."""

        class Resolved:
            source = "created"

        fb = ModuleFeedback(
            module="m",
            items=[FeedbackItem(id="fb-1", target="t", status="open")],
        )
        result, addressed = analyze_feedback_status(fb, {"t": Resolved()})
        assert addressed == ["fb-1"]


# ---------------------------------------------------------------------------
# read_feedback / write_feedback
# ---------------------------------------------------------------------------


class TestReadWriteFeedback:
    @pytest.mark.asyncio
    async def test_read_feedback_success(self):
        data = {
            "module": "mod",
            "items": [{"id": "1", "target": "t", "status": "open"}],
        }
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value={"value": json.dumps(data)})
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_feedback(mock_sdk, "ns", "mod")
        assert result is not None
        assert result.module == "mod"

    @pytest.mark.asyncio
    async def test_read_feedback_not_found(self):
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(side_effect=Exception("not found"))
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_feedback(mock_sdk, "ns", "missing")
        assert result is None

    @pytest.mark.asyncio
    async def test_read_feedback_with_content_attr(self):
        data = {"module": "mod", "items": []}

        class ResultObj:
            content = {"content": json.dumps(data)}

        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.get_artifact = AsyncMock(return_value=ResultObj())
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        result = await read_feedback(mock_sdk, "ns", "mod")
        assert result is not None

    @pytest.mark.asyncio
    async def test_write_feedback(self):
        fb = ModuleFeedback(module="mod", items=[])
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.update_artifact = AsyncMock()
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        await write_feedback(mock_sdk, "ns", "mod", fb)
        mock_ns.update_artifact.assert_called_once()

    @pytest.mark.asyncio
    async def test_write_feedback_error_silenced(self):
        fb = ModuleFeedback(module="mod", items=[])
        mock_sdk = MagicMock()
        mock_ns = AsyncMock()
        mock_ns.update_artifact = AsyncMock(side_effect=Exception("fail"))
        mock_sdk.__getitem__ = MagicMock(return_value=mock_ns)

        # Should not raise
        await write_feedback(mock_sdk, "ns", "mod", fb)
