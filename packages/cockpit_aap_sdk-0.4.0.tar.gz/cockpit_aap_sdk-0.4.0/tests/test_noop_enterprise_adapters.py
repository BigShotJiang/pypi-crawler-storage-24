# packages/py/tests/test_noop_enterprise_adapters.py
import pytest
from cockpit_aap.ports import GuardrailPort, CostTrackerPort, AgentTelemetryPort
from cockpit_aap.adapters.noop_guardrail import NoopGuardrailAdapter
from cockpit_aap.adapters.noop_cost_tracker import NoopCostTrackerAdapter
from cockpit_aap.adapters.noop_agent_telemetry import NoopAgentTelemetryAdapter
from cockpit_aap.ports.guardrail import GuardrailContext
from cockpit_aap.ports.cost_tracker import CostUsage
from cockpit_aap.ports.agent_telemetry import AgentSpanContext, AgentSpanResult


@pytest.mark.asyncio
async def test_noop_guardrail():
    adapter = NoopGuardrailAdapter()
    assert isinstance(adapter, GuardrailPort)
    result = await adapter.evaluate_input(GuardrailContext(agent_id="test"))
    assert result.allowed is True


@pytest.mark.asyncio
async def test_noop_cost_tracker():
    adapter = NoopCostTrackerAdapter()
    assert isinstance(adapter, CostTrackerPort)
    await adapter.record(CostUsage(agent_id="a", model="m", input_tokens=1, output_tokens=1))
    status = await adapter.check_budget("a")
    assert status.within_budget is True


def test_noop_agent_telemetry():
    adapter = NoopAgentTelemetryAdapter()
    assert isinstance(adapter, AgentTelemetryPort)
    span = adapter.start_agent_span(AgentSpanContext(agent_id="a", request_id="r", model="m"))
    assert span.span_id == "noop"
    adapter.end_span(span, AgentSpanResult())
