import os
import pytest


def test_init_exporter_returns_false_without_env(monkeypatch):
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)
    from cockpit_aap.otel.exporter import init_exporter
    assert init_exporter("test-service") is False


def test_init_exporter_returns_true_with_env(monkeypatch):
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4318")
    from cockpit_aap.otel.exporter import init_exporter
    result = init_exporter("test-service")
    # Returns True if opentelemetry-sdk is installed, False if only opentelemetry-api
    assert isinstance(result, bool)


def test_init_exporter_returns_true_when_sdk_available(monkeypatch):
    """Verifies True is returned when all OTEL SDK packages are present."""
    pytest.importorskip("opentelemetry.sdk.trace", reason="opentelemetry-sdk not installed")
    pytest.importorskip(
        "opentelemetry.exporter.otlp.proto.http.trace_exporter",
        reason="opentelemetry-exporter-otlp-proto-http not installed",
    )
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", "http://localhost:4318")
    from cockpit_aap.otel.exporter import init_exporter
    assert init_exporter("test-service") is True
