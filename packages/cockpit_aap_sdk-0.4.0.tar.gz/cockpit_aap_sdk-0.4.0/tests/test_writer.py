"""Tests for the manifest writer module.

Covers: serialize_manifest, write_manifest, _dataclass_to_dict, _to_camel_case.
"""

from __future__ import annotations

import json
import os
import tempfile

import pytest
import yaml

from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAgent,
    ManifestArtifact,
    ManifestCommand,
    ManifestI18n,
    ManifestMetadata,
    ManifestSkill,
    ManifestSpec,
)
from cockpit_aap.manifest.writer import (
    WriteManifestOptions,
    serialize_manifest,
    write_manifest,
)


def _make_manifest(**spec_kwargs) -> Manifest:
    return Manifest(
        api_version="cockpit.io/v1",
        kind="Module",
        metadata=ManifestMetadata(
            name="test-module",
            display_name="Test Module",
            version="1.0.0",
            description="A test module",
        ),
        spec=ManifestSpec(**spec_kwargs),
    )


# ---------------------------------------------------------------------------
# serialize_manifest
# ---------------------------------------------------------------------------


class TestSerializeManifest:
    def test_basic_output(self):
        m = _make_manifest()
        output = serialize_manifest(m)
        parsed = yaml.safe_load(output)
        assert parsed["apiVersion"] == "cockpit.io/v1"
        assert parsed["kind"] == "Module"
        assert parsed["metadata"]["name"] == "test-module"
        assert parsed["metadata"]["displayName"] == "Test Module"

    def test_camel_case_conversion(self):
        m = _make_manifest()
        output = serialize_manifest(m)
        assert "display_name" not in output
        assert "displayName" in output
        assert "api_version" not in output
        assert "apiVersion" in output

    def test_none_fields_omitted(self):
        m = _make_manifest()
        output = serialize_manifest(m)
        parsed = yaml.safe_load(output)
        # spec should have no keys if everything is None
        assert parsed.get("spec") is None or parsed["spec"] == {} or not parsed.get("spec")

    def test_with_agents(self):
        m = _make_manifest(agents=[
            ManifestAgent(id="agent-1", name="Agent 1", instruction="Do something"),
        ])
        output = serialize_manifest(m)
        parsed = yaml.safe_load(output)
        agents = parsed["spec"]["agents"]
        assert len(agents) == 1
        assert agents[0]["id"] == "agent-1"
        assert agents[0]["instruction"] == "Do something"

    def test_with_artifacts(self):
        m = _make_manifest(artifacts=[
            ManifestArtifact(key="config.theme", default_value="dark", category="configuration"),
        ])
        output = serialize_manifest(m)
        parsed = yaml.safe_load(output)
        artifacts = parsed["spec"]["artifacts"]
        assert len(artifacts) == 1
        assert artifacts[0]["key"] == "config.theme"
        assert artifacts[0]["defaultValue"] == "dark"


# ---------------------------------------------------------------------------
# write_manifest — single file
# ---------------------------------------------------------------------------


class TestWriteManifestSingle:
    def test_single_file(self, tmp_path):
        m = _make_manifest(agents=[
            ManifestAgent(id="agent-1", name="Agent 1", instruction="Do something"),
        ])
        files = write_manifest(
            m,
            str(tmp_path),
            WriteManifestOptions(single_file=True),
        )
        assert any("manifest.yaml" in f for f in files)
        manifest_path = tmp_path / "manifest.yaml"
        assert manifest_path.exists()
        content = yaml.safe_load(manifest_path.read_text())
        assert content["kind"] == "Module"


# ---------------------------------------------------------------------------
# write_manifest — multi-file extraction
# ---------------------------------------------------------------------------


class TestWriteManifestMulti:
    def test_extract_agent_instructions(self, tmp_path):
        multi_line = "You are a dev agent.\nFollow the rules carefully."
        m = _make_manifest(agents=[
            ManifestAgent(id="dev", name="Dev", instruction=multi_line),
        ])
        opts = WriteManifestOptions(extract_agent_instructions=True)
        files = write_manifest(m, str(tmp_path), opts)
        agent_md = tmp_path / "agents" / "dev.md"
        assert agent_md.exists()
        assert agent_md.read_text() == multi_line
        # Check manifest.yaml points to the file
        manifest_path = tmp_path / "manifest.yaml"
        parsed = yaml.safe_load(manifest_path.read_text())
        agent_in_yaml = parsed["spec"]["agents"][0]
        assert agent_in_yaml["instruction"] == "agents/dev.md"

    def test_extract_command_scripts(self, tmp_path):
        multi_line_script = "echo 'step 1'\necho 'step 2'"
        m = _make_manifest(commands=[
            ManifestCommand(id="build", name="Build", script=multi_line_script),
        ])
        opts = WriteManifestOptions(extract_command_scripts=True)
        files = write_manifest(m, str(tmp_path), opts)
        cmd_md = tmp_path / "commands" / "build.md"
        assert cmd_md.exists()
        assert cmd_md.read_text() == multi_line_script

    def test_extract_skill_instructions(self, tmp_path):
        multi_line = "Steps to validate\nRun checks on all fields."
        m = _make_manifest(skills=[
            ManifestSkill(id="validate", name="Validate", description="d", instruction=multi_line),
        ])
        opts = WriteManifestOptions(extract_skill_instructions=True)
        files = write_manifest(m, str(tmp_path), opts)
        skill_md = tmp_path / "skills" / "validate" / "SKILL.md"
        assert skill_md.exists()
        assert skill_md.read_text() == multi_line

    def test_extract_i18n_files(self, tmp_path):
        m = _make_manifest(i18n=ManifestI18n(
            default_locale="en",
            locales={
                "en": {"resources": {"greeting": "Hello"}},
                "pt-BR": {"resources": {"greeting": "Olá"}},
            },
        ))
        opts = WriteManifestOptions(extract_i18n_files=True)
        files = write_manifest(m, str(tmp_path), opts)
        en_json = tmp_path / "i18n" / "en.json"
        ptbr_json = tmp_path / "i18n" / "pt-BR.json"
        assert en_json.exists()
        assert ptbr_json.exists()
        en_data = json.loads(en_json.read_text())
        assert en_data["greeting"] == "Hello"

    def test_default_options_extract_all(self, tmp_path):
        """Default WriteManifestOptions should extract everything."""
        m = _make_manifest(
            agents=[ManifestAgent(id="a", name="A", instruction="line1\nline2")],
            skills=[ManifestSkill(id="s", name="S", description="d", instruction="line1\nline2")],
        )
        opts = WriteManifestOptions()
        files = write_manifest(m, str(tmp_path), opts)
        assert (tmp_path / "agents" / "a.md").exists()
        assert (tmp_path / "skills" / "s" / "SKILL.md").exists()
