"""Tests for bootstrap_artifact — granular single-artifact bootstrapper."""

import pytest
from cockpit_aap.artifact_bootstrapper import (
    ArtifactDefinition,
    ResolvedArtifact,
    UpgradeContext,
    bootstrap_artifact,
)
from cockpit_aap.meta import MetaManifest, MetaArtifactEntry, checksum
from cockpit_aap.local_sdk import create_local_sdk


@pytest.fixture
def sdk(tmp_path):
    return create_local_sdk(str(tmp_path / "test-db"))


def _def(key: str = "mod.config.test", value: str = "hello", **kw) -> ArtifactDefinition:
    return ArtifactDefinition(key=key, default_value=value, **kw)


class TestBootstrapArtifactCreate:
    @pytest.mark.asyncio
    async def test_create_new(self, sdk):
        result = await bootstrap_artifact(sdk, "artifacts", _def(), "my-module")
        assert result.source == "created"
        assert result.value == "hello"
        assert result.key == "mod.config.test"

    @pytest.mark.asyncio
    async def test_existing_returns_server(self, sdk):
        await sdk.artifacts.create_artifact(key="mod.config.test", value="server-val")
        result = await bootstrap_artifact(sdk, "artifacts", _def(), "my-module")
        assert result.source == "server"
        assert result.value == "server-val"

    @pytest.mark.asyncio
    async def test_state_artifact_always_server(self, sdk):
        await sdk.artifacts.create_artifact(key="state.key", value="user-data")
        d = _def(key="state.key", value="default", artifact_category="state")
        result = await bootstrap_artifact(sdk, "artifacts", d, "mod")
        assert result.source == "server"
        assert result.value == "user-data"


class TestBootstrapArtifactUpgrade:
    @pytest.mark.asyncio
    async def test_upgrade_code_changed_no_drift(self, sdk):
        # Pre-create artifact with old value
        await sdk.artifacts.create_artifact(key="k", value="old-value")

        old_manifest = MetaManifest(
            module="mod",
            code_version="1.0.0",
            bootstrapped_at="2024-01-01T00:00:00Z",
            artifacts={
                "k": MetaArtifactEntry(
                    id="art-1",
                    source="created",
                    default_checksum=checksum("old-value"),
                    server_checksum=checksum("old-value"),
                    artifact_category="configuration",
                    drifted=False,
                )
            },
        )
        upgrade = UpgradeContext(old_manifest=old_manifest, strategy="server-wins")
        d = _def(key="k", value="new-value")

        result = await bootstrap_artifact(sdk, "artifacts", d, "mod", upgrade=upgrade)
        assert result.source == "upgraded"
        assert result.value == "new-value"

    @pytest.mark.asyncio
    async def test_upgrade_server_wins(self, sdk):
        await sdk.artifacts.create_artifact(key="k", value="server-modified")

        old_manifest = MetaManifest(
            module="mod",
            code_version="1.0.0",
            bootstrapped_at="2024-01-01T00:00:00Z",
            artifacts={
                "k": MetaArtifactEntry(
                    id="art-1",
                    source="created",
                    default_checksum=checksum("old-value"),
                    server_checksum=checksum("old-value"),
                    artifact_category="configuration",
                    drifted=True,  # server drifted
                )
            },
        )
        upgrade = UpgradeContext(old_manifest=old_manifest, strategy="server-wins")
        d = _def(key="k", value="new-code-value")

        result = await bootstrap_artifact(sdk, "artifacts", d, "mod", upgrade=upgrade)
        assert result.source == "server"
        assert result.value == "server-modified"

    @pytest.mark.asyncio
    async def test_upgrade_code_unchanged_skip(self, sdk):
        await sdk.artifacts.create_artifact(key="k", value="val")

        old_manifest = MetaManifest(
            module="mod",
            code_version="1.0.0",
            bootstrapped_at="2024-01-01T00:00:00Z",
            artifacts={
                "k": MetaArtifactEntry(
                    id="art-1",
                    source="created",
                    default_checksum=checksum("hello"),  # same as new default
                    server_checksum=checksum("val"),
                    artifact_category="configuration",
                    drifted=False,
                )
            },
        )
        upgrade = UpgradeContext(old_manifest=old_manifest, strategy="server-wins")
        d = _def(key="k", value="hello")  # same default checksum

        result = await bootstrap_artifact(sdk, "artifacts", d, "mod", upgrade=upgrade)
        assert result.source == "server"

    @pytest.mark.asyncio
    async def test_upgrade_code_wins(self, sdk):
        await sdk.artifacts.create_artifact(key="k", value="server-modified")

        old_manifest = MetaManifest(
            module="mod",
            code_version="1.0.0",
            bootstrapped_at="2024-01-01T00:00:00Z",
            artifacts={
                "k": MetaArtifactEntry(
                    id="art-1",
                    source="created",
                    default_checksum=checksum("old-value"),
                    server_checksum=checksum("old-value"),
                    artifact_category="configuration",
                    drifted=True,
                )
            },
        )
        upgrade = UpgradeContext(old_manifest=old_manifest, strategy="code-wins")
        d = _def(key="k", value="new-code-value")

        result = await bootstrap_artifact(sdk, "artifacts", d, "mod", upgrade=upgrade)
        assert result.source == "upgraded"
        assert result.value == "new-code-value"


class TestBootstrapArtifactFallback:
    @pytest.mark.asyncio
    async def test_fallback_on_error(self, tmp_path):
        """When SDK completely fails, return default-fallback."""

        class _BrokenNamespace:
            async def get_artifact(self, **kw):
                raise RuntimeError("connection lost")

            async def create_artifact(self, **kw):
                raise RuntimeError("connection lost")

        class _BrokenSdk:
            artifacts = _BrokenNamespace()

            async def call_tool(self, ns, tool, args):
                method = getattr(getattr(self, ns), tool)
                return await method(**args)

        sdk = _BrokenSdk()
        result = await bootstrap_artifact(sdk, "artifacts", _def(), "mod")
        assert result.source == "default-fallback"
        assert result.value == "hello"
        assert result.error is not None
