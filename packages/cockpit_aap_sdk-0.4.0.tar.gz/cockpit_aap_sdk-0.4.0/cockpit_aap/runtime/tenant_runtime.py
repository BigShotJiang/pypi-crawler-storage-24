"""TenantAgentRuntime -- creates per-tenant runtime instances.

Instead of a single fixed runtime, this factory loads the tenant-specific
manifest on each request and creates a runtime with tenant-specific
guardrails, cost tracking, and telemetry.
"""
from __future__ import annotations

import time
from typing import Any, Callable

from cockpit_aap.ports.tenant_resolver import TenantContext

from .types import RuntimeContext, RuntimeResult, RuntimeDecision, ToolCallInfo
from .agent_runtime import create_agent_runtime


class TenantAgentRuntime:
    """Per-tenant runtime factory.

    Caches runtimes by tenant key to avoid re-creating on every request.
    When the manifest changes (via invalidation), the cache is cleared.

    Usage::

        factory = TenantAgentRuntime(
            manifest_loader=client.get_manifest,  # async (module_id) -> dict
            module_id="open-generative-ui",
            adapter_factory=lambda manifest: {
                "guardrail": create_guardrail_from_manifest(manifest),
                "telemetry": create_telemetry(manifest),
                "cost_tracker": create_cost_tracker(manifest),
            },
        )

        # Per request:
        runtime = await factory.for_tenant(tenant_context)
        decision = await runtime.before_call(ctx)
    """

    def __init__(
        self,
        manifest_loader: Callable[[str], Any],  # async fn(module_id) -> manifest dict
        module_id: str,
        adapter_factory: Callable[[Any], dict[str, Any]],  # manifest -> adapters dict
        cache_ttl: int = 30,
    ) -> None:
        self._loader = manifest_loader
        self._module_id = module_id
        self._adapter_factory = adapter_factory
        self._cache_ttl = cache_ttl
        self._cache: dict[str, tuple[Any, float]] = {}  # tenant_key -> (runtime, expires_at)

    def _tenant_key(self, tenant: TenantContext | None) -> str:
        if tenant is None:
            return "_global:_global"
        return f"{tenant.license_id}:{tenant.namespace_id}"

    async def for_tenant(self, tenant: TenantContext | None = None) -> Any:
        """Get or create a runtime for the given tenant.

        Loads tenant-specific manifest, creates runtime with tenant-specific
        adapters (guardrails, cost, telemetry). Cached by tenant key with TTL.
        """
        key = self._tenant_key(tenant)

        # Check cache
        if key in self._cache:
            runtime, expires_at = self._cache[key]
            if time.time() < expires_at:
                return runtime

        # Load tenant manifest
        manifest = await self._loader(self._module_id)

        # Create adapters from manifest (guardrails, telemetry, cost)
        adapters = self._adapter_factory(manifest)

        # Create runtime
        runtime = create_agent_runtime(manifest, adapters)

        # Cache
        self._cache[key] = (runtime, time.time() + self._cache_ttl)

        return runtime

    def invalidate(self, tenant: TenantContext | None = None) -> None:
        """Invalidate cached runtime for a tenant (or all if None)."""
        if tenant is None:
            self._cache.clear()
        else:
            self._cache.pop(self._tenant_key(tenant), None)

    async def before_call(
        self, ctx: RuntimeContext, tenant: TenantContext | None = None
    ) -> RuntimeDecision:
        """Convenience: resolve tenant runtime and call before_call."""
        runtime = await self.for_tenant(tenant)
        return await runtime.before_call(ctx)

    async def after_call(
        self, ctx: RuntimeContext, result: RuntimeResult, tenant: TenantContext | None = None
    ) -> RuntimeDecision:
        """Convenience: resolve tenant runtime and call after_call."""
        runtime = await self.for_tenant(tenant)
        return await runtime.after_call(ctx, result)
