"""AgentTelemetryPort backed by OpenTelemetry.

Requires: pip install opentelemetry-api opentelemetry-sdk
Falls back to ConsoleTelemetryAdapter if not installed.
"""
from __future__ import annotations
from cockpit_aap.ports.agent_telemetry import AgentSpanContext, SpanHandle, AgentEvent, AgentSpanResult


class OtelTelemetryAdapter:
    def __init__(self, service_name: str = "aap-agent-runtime"):
        self._spans: dict[str, any] = {}
        try:
            from opentelemetry import trace
            self._tracer = trace.get_tracer(service_name)
            self._available = True
        except ImportError:
            print("[otel-telemetry] opentelemetry not installed — falling back to console")
            self._available = False

    def start_agent_span(self, ctx: AgentSpanContext) -> SpanHandle:
        if not self._available:
            return self._console_start(ctx)
        attrs: dict[str, str] = {
            "gen_ai.agent.id": ctx.agent_id,
            "gen_ai.request.id": ctx.request_id,
            "gen_ai.request.model": ctx.model,
        }
        if ctx.user_id:
            attrs["enduser.id"] = ctx.user_id
        if ctx.tenant_id:
            attrs["aap.tenant.id"] = ctx.tenant_id
        span = self._tracer.start_span("gen_ai.agent", attributes=attrs)
        span_ctx = span.get_span_context()
        handle = SpanHandle(span_id=format(span_ctx.span_id, "016x"), trace_id=format(span_ctx.trace_id, "032x"))
        self._spans[handle.span_id] = span
        return handle

    def record_event(self, span_handle: SpanHandle, event: AgentEvent) -> None:
        if not self._available:
            return self._console_event(span_handle, event)
        parent_span = self._spans.get(span_handle.span_id)
        if parent_span:
            from opentelemetry import context, trace
            ctx = trace.set_span_in_context(parent_span)
            child = self._tracer.start_span(event.name, context=ctx, attributes=event.attributes)
            child.end()

    def end_span(self, span_handle: SpanHandle, result: AgentSpanResult) -> None:
        if not self._available:
            return self._console_end(span_handle, result)
        span = self._spans.pop(span_handle.span_id, None)
        if span:
            if result.attributes:
                span.set_attributes(result.attributes)
            span.end()

    # Console fallback methods
    def _console_start(self, ctx: AgentSpanContext) -> SpanHandle:
        import uuid
        sid = str(uuid.uuid4())[:16]
        print(f"[telemetry] START {sid} gen_ai.agent gen_ai.agent.id={ctx.agent_id} gen_ai.request.model={ctx.model}")
        return SpanHandle(span_id=sid, trace_id=f"trace-{ctx.request_id}")

    def _console_event(self, span: SpanHandle, event: AgentEvent) -> None:
        print(f"[telemetry] EVENT {span.span_id} {event.name}")

    def _console_end(self, span: SpanHandle, result: AgentSpanResult) -> None:
        attrs_str = ""
        if result.attributes:
            attrs_str = " " + " ".join(f"{k}={v}" for k, v in result.attributes.items())
        print(f"[telemetry] END {span.span_id} status={result.status}{attrs_str}")
