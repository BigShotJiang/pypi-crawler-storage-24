"""LlamaGuardAdapter — ML-based content safety classification via LlamaGuard.

Uses LlamaGuard (Meta) through any OpenAI-compatible endpoint (LiteLLM, Together,
Groq, vLLM, etc.) to classify input/output into safety categories.

LlamaGuard returns "safe" or "unsafe\nS<category>" — this adapter maps those
to GuardrailDecision with appropriate severity.

Requires: LLAMAGUARD_BASE_URL + LLAMAGUARD_API_KEY env vars, or pass config directly.
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from cockpit_aap.ports.guardrail import (
    GuardrailContext,
    GuardrailDecision,
    GuardrailViolation,
)


# LlamaGuard 3 safety taxonomy (S1–S13)
SAFETY_CATEGORIES: dict[str, str] = {
    "S1": "Violent Crimes",
    "S2": "Non-Violent Crimes",
    "S3": "Sex-Related Crimes",
    "S4": "Child Sexual Exploitation",
    "S5": "Defamation",
    "S6": "Specialized Advice",
    "S7": "Privacy",
    "S8": "Intellectual Property",
    "S9": "Indiscriminate Weapons",
    "S10": "Hate",
    "S11": "Suicide & Self-Harm",
    "S12": "Sexual Content",
    "S13": "Elections",
}


@dataclass
class LlamaGuardConfig:
    """Configuration for the LlamaGuard adapter."""
    base_url: str = ""
    api_key: str = ""
    model: str = "meta-llama/Llama-Guard-3-8B"
    timeout: float = 10.0
    # Categories that trigger a block (default: all)
    block_categories: list[str] = field(default_factory=lambda: list(SAFETY_CATEGORIES.keys()))
    # Categories that only warn (override block_categories)
    warn_categories: list[str] = field(default_factory=list)

    def __post_init__(self):
        if not self.base_url:
            self.base_url = os.environ.get("LLAMAGUARD_BASE_URL", "")
        if not self.api_key:
            self.api_key = os.environ.get("LLAMAGUARD_API_KEY", "")


class LlamaGuardAdapter:
    """GuardrailPort adapter using LlamaGuard for ML-based content classification.

    Calls LlamaGuard via OpenAI-compatible chat completions API.
    Works with any provider: LiteLLM proxy, Together AI, Groq, vLLM, Ollama.
    """

    def __init__(self, config: LlamaGuardConfig | None = None):
        self.config = config or LlamaGuardConfig()
        self._client = None

    def _get_client(self):
        """Lazy-init httpx async client."""
        if self._client is None:
            import httpx
            self._client = httpx.AsyncClient(
                base_url=self.config.base_url.rstrip("/"),
                timeout=self.config.timeout,
                headers={
                    "Authorization": f"Bearer {self.config.api_key}",
                    "Content-Type": "application/json",
                },
            )
        return self._client

    async def _classify(self, text: str, role: str = "user") -> GuardrailDecision:
        """Send text to LlamaGuard and parse the safety classification.

        Args:
            text: The content to classify.
            role: "user" for input guardrails, "assistant" for output guardrails.

        Returns:
            GuardrailDecision with violations if unsafe.
        """
        if not text or not text.strip():
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        if not self.config.base_url:
            # No endpoint configured — pass through silently
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        try:
            client = self._get_client()
            response = await client.post(
                "/v1/chat/completions",
                json={
                    "model": self.config.model,
                    "messages": [
                        {"role": role, "content": text},
                    ],
                    "max_tokens": 100,
                    "temperature": 0.0,
                },
            )
            response.raise_for_status()
            data = response.json()

            content = (
                data.get("choices", [{}])[0]
                .get("message", {})
                .get("content", "")
                .strip()
            )

            return self._parse_response(content)

        except Exception as e:
            # On error, fail open (allow) but log the issue
            from cockpit_aap.logging import emit_log
            emit_log("error", "llamaguard_error", service="guardrail", module="guardrail",
                     error=str(e), text_len=len(text))
            return GuardrailDecision(allowed=True, action="pass", violations=[])

    def _parse_category_codes(self, content: str) -> list[str]:
        """Extract category codes from the second line of an unsafe LlamaGuard response."""
        lines = content.strip().split("\n")
        category_line = lines[1].strip() if len(lines) > 1 else ""
        return [c.strip() for c in category_line.split(",") if c.strip()]

    def _build_violations(self, codes: list[str]) -> tuple[list[GuardrailViolation], bool]:
        """Build violation list from category codes. Returns (violations, has_block)."""
        violations: list[GuardrailViolation] = []
        has_block = False

        for code in codes:
            label = SAFETY_CATEGORIES.get(code, f"Unknown ({code})")
            severity = "warn" if code in self.config.warn_categories else "block"
            if severity == "block":
                has_block = True
            violations.append(GuardrailViolation(
                rule_id=f"llamaguard-{code.lower()}",
                category="content-safety",
                message=f"LlamaGuard: {label} ({code})",
                severity=severity,
            ))

        if not violations:
            has_block = True
            violations.append(GuardrailViolation(
                rule_id="llamaguard-unsafe",
                category="content-safety",
                message="LlamaGuard classified content as unsafe",
                severity="block",
            ))

        return violations, has_block

    def _parse_response(self, content: str) -> GuardrailDecision:
        """Parse LlamaGuard response into a GuardrailDecision.

        LlamaGuard returns:
        - "safe" → no violations
        - "unsafe\\nS1,S7" → unsafe with category codes
        """
        if not content:
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        lower = content.lower().strip()

        if lower.startswith("safe"):
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        if lower.startswith("unsafe"):
            codes = self._parse_category_codes(content)
            violations, has_block = self._build_violations(codes)
            action = "block" if has_block else "warn"
            return GuardrailDecision(allowed=not has_block, action=action, violations=violations)

        # Unexpected response format — pass through
        return GuardrailDecision(allowed=True, action="pass", violations=[])

    async def evaluate_input(self, context: GuardrailContext) -> GuardrailDecision:
        """Evaluate user input for safety."""
        return await self._classify(context.input or "", role="user")

    async def evaluate_output(self, context: GuardrailContext) -> GuardrailDecision:
        """Evaluate agent output for safety."""
        return await self._classify(context.input or "", role="assistant")

    async def close(self):
        """Close the HTTP client."""
        if self._client:
            await self._client.aclose()
            self._client = None
