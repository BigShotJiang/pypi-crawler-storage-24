"""Guardrail Factory — manifest-driven adapter selection.

Reads spec.guardrails from the manifest and creates the appropriate
adapter chain. Supports: regex, llamaguard, llamafirewall, guardrails-ai.

Usage:
    from cockpit_aap.runtime.guardrail_factory import create_guardrail_from_manifest

    guardrail = create_guardrail_from_manifest(manifest)
    # Returns a CompositeGuardrailAdapter or single adapter
"""
from __future__ import annotations

from cockpit_aap.ports.guardrail import GuardrailContext, GuardrailDecision
from cockpit_aap.runtime.regex_guardrail import RegexGuardrailAdapter
from cockpit_aap.runtime.composite_guardrail import CompositeGuardrailAdapter


def create_guardrail_from_manifest(manifest) -> CompositeGuardrailAdapter:
    """Create a guardrail adapter chain from manifest spec.guardrails.

    Reads spec.guardrails.input[].adapter to determine which adapters to use.
    Each unique adapter type is instantiated once and added to the composite.

    Adapter types:
        - "regex" → RegexGuardrailAdapter (built-in, zero deps)
        - "llamaguard" → LlamaGuardAdapter (requires LLAMAGUARD_BASE_URL)
        - "llamafirewall" → LlamaFirewallAdapter (requires pip install llamafirewall)
        - "guardrails-ai" → GuardrailsAIAdapter (requires pip install guardrails-ai)
        - "nemo" → NeMoGuardrailAdapter (requires pip install nemoguardrails)

    Falls back to RegexGuardrailAdapter if no guardrails configured or all fail.
    """
    adapters = []
    adapter_types_seen: set[str] = set()

    # Extract guardrail rules from manifest
    guardrails_spec = _get_guardrails_spec(manifest)
    if not guardrails_spec:
        return CompositeGuardrailAdapter([RegexGuardrailAdapter()])

    # Collect unique adapter types from input + output rules
    input_rules = guardrails_spec.get("input", []) if isinstance(guardrails_spec, dict) else getattr(guardrails_spec, "input", []) or []
    output_rules = guardrails_spec.get("output", []) if isinstance(guardrails_spec, dict) else getattr(guardrails_spec, "output", []) or []

    for rule in [*input_rules, *output_rules]:
        adapter_type = rule.get("adapter", "regex") if isinstance(rule, dict) else getattr(rule, "adapter", "regex") or "regex"
        adapter_types_seen.add(adapter_type)

    # Instantiate each adapter type (order: fast → slow)
    # Regex always runs first (cheapest), ML adapters after
    if "regex" in adapter_types_seen:
        adapters.append(RegexGuardrailAdapter())
        adapter_types_seen.discard("regex")

    for adapter_type in sorted(adapter_types_seen):
        adapter = _create_adapter(adapter_type)
        if adapter:
            adapters.append(adapter)

    # Fallback: always have at least regex
    if not adapters:
        adapters.append(RegexGuardrailAdapter())

    from cockpit_aap.logging import emit_log
    adapter_names = [type(a).__name__ for a in adapters]
    emit_log("info", "guardrail_factory_created", service="guardrail", module="guardrail",
             adapters=adapter_names, count=len(adapters))

    return CompositeGuardrailAdapter(adapters)


def _get_guardrails_spec(manifest):
    """Extract spec.guardrails from manifest (dict or object)."""
    if isinstance(manifest, dict):
        return manifest.get("spec", {}).get("guardrails")
    spec = getattr(manifest, "spec", None)
    if spec is None:
        return None
    if isinstance(spec, dict):
        return spec.get("guardrails")
    return getattr(spec, "guardrails", None)


def _create_adapter(adapter_type: str):
    """Create a single adapter by type name. Returns None if unavailable."""
    from cockpit_aap.logging import emit_log

    if adapter_type == "llamafirewall":
        try:
            from cockpit_aap.runtime.llamafirewall_adapter import LlamaFirewallAdapter
            adapter = LlamaFirewallAdapter()
            emit_log("info", "guardrail_adapter_loaded", service="guardrail", module="guardrail", adapter="LlamaFirewallAdapter")
            return adapter
        except Exception as e:
            emit_log("warn", "guardrail_adapter_unavailable", service="guardrail", module="guardrail",
                     adapter="LlamaFirewallAdapter", error=str(e))
            return None

    if adapter_type == "llamaguard":
        try:
            from cockpit_aap.runtime.llamaguard_adapter import LlamaGuardAdapter
            adapter = LlamaGuardAdapter()
            emit_log("info", "guardrail_adapter_loaded", service="guardrail", module="guardrail", adapter="LlamaGuardAdapter")
            return adapter
        except Exception as e:
            emit_log("warn", "guardrail_adapter_unavailable", service="guardrail", module="guardrail",
                     adapter="LlamaGuardAdapter", error=str(e))
            return None

    if adapter_type == "guardrails-ai":
        try:
            from guardrails import Guard
            from cockpit_aap.runtime.guardrails_ai_adapter import GuardrailsAIAdapter
            adapter = GuardrailsAIAdapter(Guard())
            emit_log("info", "guardrail_adapter_loaded", service="guardrail", module="guardrail", adapter="GuardrailsAIAdapter")
            return adapter
        except Exception as e:
            emit_log("warn", "guardrail_adapter_unavailable", service="guardrail", module="guardrail",
                     adapter="GuardrailsAIAdapter", error=str(e))
            return None

    if adapter_type == "openai-moderation":
        try:
            from cockpit_aap.runtime.openai_moderation_adapter import OpenAIModerationAdapter
            adapter = OpenAIModerationAdapter()
            emit_log("info", "guardrail_adapter_loaded", service="guardrail", module="guardrail", adapter="OpenAIModerationAdapter")
            return adapter
        except Exception as e:
            emit_log("warn", "guardrail_adapter_unavailable", service="guardrail", module="guardrail",
                     adapter="OpenAIModerationAdapter", error=str(e))
            return None

    emit_log("warn", "guardrail_adapter_unknown", service="guardrail", module="guardrail", adapter_type=adapter_type)
    return None
