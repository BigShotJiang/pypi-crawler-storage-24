# packages/py/cockpit_aap/runtime/guardrails_ai_adapter.py
"""GuardrailPort adapter wrapping guardrails-ai library.

Requires: pip install guardrails-ai
"""
from __future__ import annotations
from typing import Any
from cockpit_aap.ports.guardrail import GuardrailContext, GuardrailDecision, GuardrailViolation

class GuardrailsAIAdapter:
    """Wraps a guardrails-ai Guard as a GuardrailPort.

    Usage:
        from guardrails import Guard
        from guardrails.hub import DetectPII, ToxicLanguage

        guard = Guard().use_many(DetectPII(), ToxicLanguage())
        adapter = GuardrailsAIAdapter(guard)
        runtime = create_agent_runtime(manifest, {"guardrail": adapter})
    """

    def __init__(self, guard: Any):
        self._guard = guard

    async def evaluate_input(self, ctx: GuardrailContext) -> GuardrailDecision:
        return self._evaluate(ctx.input or "")

    async def evaluate_output(self, ctx: GuardrailContext) -> GuardrailDecision:
        return self._evaluate(ctx.input or "")

    def _evaluate(self, text: str) -> GuardrailDecision:
        try:
            result = self._guard.validate(text)
            if result.validation_passed:
                return GuardrailDecision(allowed=True, action="pass")

            violations = [
                GuardrailViolation(
                    rule_id=str(getattr(f, "id", "unknown")),
                    category=str(getattr(f, "validator_name", "guardrails-ai")),
                    message=str(f),
                    severity="block",
                )
                for f in getattr(result, "failed_validations", [])
            ]
            return GuardrailDecision(allowed=False, action="block", violations=violations)
        except Exception as e:
            return GuardrailDecision(
                allowed=True, action="warn",
                violations=[GuardrailViolation(rule_id="guardrails-ai-error", category="error", message=str(e), severity="warn")],
            )
