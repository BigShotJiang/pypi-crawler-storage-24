"""CompositeGuardrailAdapter — chains multiple guardrail adapters.

Runs all adapters in sequence. First "block" wins (short-circuits).
Violations from all adapters are collected.

Usage:
    composite = CompositeGuardrailAdapter([
        RegexGuardrailAdapter(),          # Fast: regex PII + injection
        LlamaFirewallAdapter(),           # ML: PromptGuard2 jailbreak detection
        LlamaGuardAdapter(config),        # ML: LlamaGuard content classification
    ])
"""
from __future__ import annotations

from cockpit_aap.ports.guardrail import (
    GuardrailContext,
    GuardrailDecision,
    GuardrailViolation,
)


class CompositeGuardrailAdapter:
    """Chains multiple GuardrailPort adapters. First block wins."""

    def __init__(self, adapters: list | None = None):
        self.adapters = adapters or []

    async def evaluate_input(self, context: GuardrailContext) -> GuardrailDecision:
        return await self._evaluate_all(context, "input")

    async def evaluate_output(self, context: GuardrailContext) -> GuardrailDecision:
        return await self._evaluate_all(context, "output")

    async def _evaluate_all(self, context: GuardrailContext, direction: str) -> GuardrailDecision:
        all_violations: list[GuardrailViolation] = []
        has_block = False

        for adapter in self.adapters:
            try:
                if direction == "input":
                    decision = await adapter.evaluate_input(context)
                else:
                    decision = await adapter.evaluate_output(context)

                all_violations.extend(decision.violations)

                if not decision.allowed:
                    has_block = True
                    # Short-circuit on block — no need to run remaining adapters
                    break
            except Exception as e:
                from cockpit_aap.logging import emit_log
                adapter_name = type(adapter).__name__
                emit_log("error", "composite_guardrail_adapter_error",
                         service="guardrail", module="guardrail", adapter=adapter_name, error=str(e))

        if has_block:
            return GuardrailDecision(
                allowed=False,
                action="block",
                violations=all_violations,
            )

        if all_violations:
            return GuardrailDecision(
                allowed=True,
                action="warn",
                violations=all_violations,
            )

        return GuardrailDecision(allowed=True, action="pass", violations=[])
