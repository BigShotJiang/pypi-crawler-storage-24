"""LlamaFirewallAdapter — ML-based agent security via Meta's LlamaFirewall.

Wraps the `llamafirewall` library (pip install llamafirewall) which includes:
- PromptGuard 2: Fast BERT-style jailbreak/injection detector
- AlignmentCheck: Chain-of-thought auditor for goal hijacking
- CodeShield: Static analysis for insecure code generation

See: https://github.com/meta-llama/PurpleLlama/tree/main/LlamaFirewall
"""
from __future__ import annotations

from cockpit_aap.ports.guardrail import (
    GuardrailContext,
    GuardrailDecision,
    GuardrailViolation,
)


class LlamaFirewallAdapter:
    """GuardrailPort adapter using Meta's LlamaFirewall.

    Uses PromptGuard 2 for input scanning (jailbreak/injection detection)
    and optionally AlignmentCheck for assistant output auditing.

    Requires: pip install llamafirewall
    """

    def __init__(
        self,
        input_scanners: list[str] | None = None,
        output_scanners: list[str] | None = None,
    ):
        """Initialize with scanner types.

        Args:
            input_scanners: Scanner types for user input. Default: ["PROMPT_GUARD"].
            output_scanners: Scanner types for assistant output. Default: ["PROMPT_GUARD"].
        """
        self._input_scanners = input_scanners or ["PROMPT_GUARD"]
        self._output_scanners = output_scanners or ["PROMPT_GUARD"]
        self._firewall = None
        self._initialized = False

    def _ensure_init(self):
        """Lazy-init the LlamaFirewall instance."""
        if self._initialized:
            return
        try:
            from llamafirewall import LlamaFirewall, Role, ScannerType

            # Map string scanner names to ScannerType enum
            def _resolve_scanners(names: list[str]) -> list:
                resolved = []
                for name in names:
                    scanner = getattr(ScannerType, name, None)
                    if scanner is not None:
                        resolved.append(scanner)
                return resolved

            scanners_config = {}
            input_resolved = _resolve_scanners(self._input_scanners)
            output_resolved = _resolve_scanners(self._output_scanners)

            if input_resolved:
                scanners_config[Role.USER] = input_resolved
            if output_resolved:
                scanners_config[Role.ASSISTANT] = output_resolved

            self._firewall = LlamaFirewall(scanners=scanners_config)
            self._initialized = True
        except ImportError:
            self._initialized = True  # Mark as init'd to avoid retrying
            self._firewall = None

    def _scan_result_to_decision(self, result) -> GuardrailDecision:
        """Convert a LlamaFirewall ScanResult to GuardrailDecision."""
        if result is None:
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        # ScanResult has: decision (ScanDecision), reason (str), score (float)
        decision_str = str(result.decision).lower() if hasattr(result, "decision") else "allow"
        reason = getattr(result, "reason", "") or ""
        score = getattr(result, "score", 1.0) or 1.0

        if "block" in decision_str:
            return GuardrailDecision(
                allowed=False,
                action="block",
                violations=[
                    GuardrailViolation(
                        rule_id="llamafirewall-block",
                        category="content-safety",
                        message=f"LlamaFirewall: {reason}" if reason else "LlamaFirewall blocked content",
                        severity="block",
                    )
                ],
            )

        return GuardrailDecision(allowed=True, action="pass", violations=[])

    async def evaluate_input(self, context: GuardrailContext) -> GuardrailDecision:
        """Evaluate user input using PromptGuard scanner."""
        self._ensure_init()
        if not self._firewall or not context.input:
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        try:
            from llamafirewall import UserMessage
            msg = UserMessage(content=context.input)
            result = self._firewall.scan(msg)
            return self._scan_result_to_decision(result)
        except Exception as e:
            from cockpit_aap.logging import emit_log
            emit_log("error", "llamafirewall_input_error", service="guardrail", module="guardrail", error=str(e))
            return GuardrailDecision(allowed=True, action="pass", violations=[])

    async def evaluate_output(self, context: GuardrailContext) -> GuardrailDecision:
        """Evaluate assistant output using configured scanners."""
        self._ensure_init()
        if not self._firewall or not context.input:
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        try:
            from llamafirewall import AssistantMessage
            msg = AssistantMessage(content=context.input)
            result = self._firewall.scan(msg)
            return self._scan_result_to_decision(result)
        except Exception as e:
            from cockpit_aap.logging import emit_log
            emit_log("error", "llamafirewall_output_error", service="guardrail", module="guardrail", error=str(e))
            return GuardrailDecision(allowed=True, action="pass", violations=[])
