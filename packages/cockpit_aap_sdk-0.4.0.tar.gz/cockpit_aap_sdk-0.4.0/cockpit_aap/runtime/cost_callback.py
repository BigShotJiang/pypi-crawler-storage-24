"""CostCallbackHandler — LangChain callback for FinOps cost tracking.

Two output channels (via CostEmitter):
1. OTEL metrics (counters) → Alloy → Prometheus  (primary, for dashboards)
2. Structured JSON log → stdout → Loki            (operational visibility + audit trail)

Budget enforcement (via CostEnforcer, optional):
- In-memory accumulator with periodic Prometheus sync
- Pre-call check: allow | warn | block

No Postgres writes — Prometheus is the canonical source for cost data.
"""
from __future__ import annotations

import os
from typing import Any

from cockpit_aap.logging import emit_log

try:
    from langchain_core.callbacks import BaseCallbackHandler
    from langchain_core.outputs import LLMResult
except ImportError:
    class BaseCallbackHandler:  # type: ignore
        pass
    class LLMResult:  # type: ignore
        pass


# ── Standalone rule violation recorder (no class dependency) ────────────────

_rules_violations_counter = None


def record_rule_violation(rule_id: str, enforcement: str, tenant_id: str = "", agent_id: str = ""):
    """Record a rule violation as OTEL counter. Call from any enforcement point."""
    global _rules_violations_counter
    if _rules_violations_counter is None:
        try:
            from opentelemetry import metrics
            meter = metrics.get_meter("aap-cost")
            _rules_violations_counter = meter.create_counter(
                "aap.rules.violations",
                description="Count of business rule violations",
            )
        except Exception:
            _rules_violations_counter = False  # mark as tried
    if _rules_violations_counter:
        _rules_violations_counter.add(1, {
            "aap.rule.id": rule_id,
            "aap.rule.enforcement": enforcement,
            "aap.tenant.id": tenant_id,
            "aap.agent.id": agent_id,
        })
    emit_log("warn", "rule_violation", service="agent", module="unknown",
             rule_id=rule_id, enforcement=enforcement,
             tenant_id=tenant_id, agent_id=agent_id)


# ── Budget exceeded error ───────────────────────────────────────────────────

class BudgetExceededError(Exception):
    """Raised when CostEnforcer blocks a call due to budget exceeded.

    The message comes from CostPolicy manifest (i18n-ready) — safe to surface in the chat UI.
    """

    def __init__(self, result: Any):
        self.result = result
        # EnforcementResult.message is already localized by CostEnforcer via CostPolicyReader.get_message()
        self.user_message = getattr(result, "message", "Budget limit reached.")
        super().__init__(self.user_message)


# ── Token extraction helpers ───────────────────────────────────────────────

def _extract_token_counts(llm_output: dict, response: Any) -> tuple[int, int]:
    """Extract (input_tokens, output_tokens) from LLM response, trying multiple paths."""
    token_usage = llm_output.get("token_usage", {})
    input_tokens = token_usage.get("prompt_tokens", 0)
    output_tokens = token_usage.get("completion_tokens", 0)

    if input_tokens == 0 and output_tokens == 0:
        input_tokens, output_tokens = _extract_from_generation_metadata(response)

    return input_tokens, output_tokens


def _extract_from_generation_metadata(response: Any) -> tuple[int, int]:
    """Fallback: extract tokens from generation[0][0].message.usage_metadata."""
    try:
        generations = getattr(response, "generations", None)
        if not generations or not generations[0]:
            return 0, 0
        message = getattr(generations[0][0], "message", None)
        if not message:
            return 0, 0
        usage_meta = getattr(message, "usage_metadata", None)
        if not usage_meta:
            return 0, 0
        if isinstance(usage_meta, dict):
            return usage_meta.get("input_tokens", 0), usage_meta.get("output_tokens", 0)
        return getattr(usage_meta, "input_tokens", 0), getattr(usage_meta, "output_tokens", 0)
    except (IndexError, AttributeError):
        return 0, 0


def _resolve_model_from_response(response: Any, fallback: str) -> str:
    """Try to extract model name from response.generations metadata."""
    try:
        rm = response.generations[0][0].message.response_metadata or {}
        return rm.get("model_name") or rm.get("model") or fallback
    except (IndexError, AttributeError):
        return fallback


def _set_span_attributes(
    span: Any, input_tokens: int, output_tokens: int, cost_usd: float, model: str,
) -> None:
    """Set OTEL span attributes for the LLM call."""
    if not span:
        return
    span.set_attribute("gen_ai.usage.input_tokens", input_tokens)
    span.set_attribute("gen_ai.usage.output_tokens", output_tokens)
    span.set_attribute("gen_ai.usage.cost", float(cost_usd))
    span.set_attribute("gen_ai.response.model", model)


# ── CostCallbackHandler ────────────────────────────────────────────────────

class CostCallbackHandler(BaseCallbackHandler):
    """Thin wrapper composing CostEmitter + CostEnforcer.

    Usage:
        from cockpit_aap.cost import CostEmitter, CostEnforcer, CostPolicyReader

        policy = CostPolicyReader.from_file("governance/policies/default-cost-policy")
        emitter = CostEmitter(policy=policy, module_id="my-module", agent_id="agent", tenant_id="t:n")
        enforcer = CostEnforcer(policy=policy)  # optional
        callback = CostCallbackHandler(emitter=emitter, enforcer=enforcer)

        llm = ChatOpenAI(model="gpt-4o", callbacks=[callback])
    """

    def __init__(
        self,
        emitter: Any = None,
        enforcer: Any = None,
        # Legacy kwargs for backward compat (ignored if emitter provided)
        database_url: str | None = None,
        agent_id: str = "agent",
        tenant_id: str = "_global:_global",
        cost_models: dict | None = None,
        module_id: str = "",
        model_name: str = "",
    ):
        if emitter is not None:
            self._emitter = emitter
            self._enforcer = enforcer
            self._legacy = False
        else:
            # Legacy mode — create a minimal emitter from flat args
            self._legacy = True
            self._agent_id = agent_id
            self._tenant_id = tenant_id
            self._module_id = module_id or os.environ.get("AAP_MODULE_ID", "unknown")
            self._cost_models = cost_models or {}
            self._default_model = model_name
            self._emitter = None
            self._enforcer = None

        self._current_span = None
        self._last_model = ""

    @property
    def agent_id(self) -> str:
        return self._emitter.agent_id if self._emitter else self._agent_id

    @property
    def tenant_id(self) -> str:
        return self._emitter.tenant_id if self._emitter else self._tenant_id

    @tenant_id.setter
    def tenant_id(self, value: str) -> None:
        if self._emitter:
            self._emitter.tenant_id = value
        else:
            self._tenant_id = value

    @property
    def module_id(self) -> str:
        return self._emitter.module_id if self._emitter else self._module_id

    @property
    def database_url(self) -> str | None:
        return None  # Postgres removed — Prometheus is canonical

    def _resolve_model(self, llm_output: dict, response: Any) -> str:
        """Resolve the model name from multiple sources in priority order."""
        model = (
            llm_output.get("model_name")
            or llm_output.get("model")
            or self._last_model
            or (self._emitter.policy._default_model if hasattr(self._emitter, "policy") and hasattr(self._emitter.policy, "_default_model") else "")
            or (self._default_model if self._legacy else "")
            or os.environ.get("OPENAI_MODEL", "unknown")
        )
        if model == "unknown":
            model = _resolve_model_from_response(response, model)
        return model

    def _emit_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        """Emit cost via CostEmitter (new path) or legacy inline."""
        if self._emitter:
            return self._emitter.emit(model, input_tokens, output_tokens)
        # Legacy path — inline OTEL + log
        pricing = self._cost_models.get(model, {})
        cost_usd = (input_tokens / 1000) * pricing.get("input_per_1k", 0.005) + \
                   (output_tokens / 1000) * pricing.get("output_per_1k", 0.015)
        emit_log(
            "info", "llm_complete",
            service="agent", module=self._module_id,
            tenant_id=self._tenant_id, agent_id=self._agent_id,
            model=model, token_count=input_tokens + output_tokens,
            cost_usd=float(cost_usd),
        )
        return cost_usd

    def _check_enforcer_budget(self, cost_usd: float) -> None:
        """Record spend in enforcer and emit warn if budget threshold crossed."""
        if not self._enforcer or not hasattr(self._enforcer, "record_spend"):
            return
        self._enforcer.record_spend(cost_usd, {"scope": "module"})
        post_result = self._enforcer.check_budget("module")
        if post_result.action in ("warn", "block") and self._emitter:
            self._emitter.emit_budget_event(post_result.action, post_result.spent, post_result.limit)

    def on_llm_start(self, serialized: Any, prompts: Any, **kwargs: Any) -> None:
        inv = kwargs.get("invocation_params", {})
        self._last_model = inv.get("model_name") or inv.get("model") or inv.get("model_id") or ""

        # NOTE: Pre-call budget enforcement moved to CostMiddleware (LangGraph middleware).
        # LangChain callbacks are best-effort — exceptions in on_llm_start are swallowed.
        # CostMiddleware.awrap_model_call() returns AIMessage instead of calling the model.

        try:
            from opentelemetry import trace, context
            tracer = trace.get_tracer("aap-agent")
            current_ctx = context.get_current()

            module_id = self._emitter.module_id if self._emitter else self._module_id
            agent_id = self._emitter.agent_id if self._emitter else self._agent_id
            tenant_id = self._emitter.tenant_id if self._emitter else self._tenant_id

            self._current_span = tracer.start_span(
                "gen_ai.chat",
                context=current_ctx,
                attributes={
                    "gen_ai.system": "openai",
                    "gen_ai.request.model": self._last_model or "unknown",
                    "gen_ai.agent.id": agent_id,
                    "aap.tenant.id": tenant_id,
                    "aap.module.id": module_id,
                    "aap.module.kind": "Module",
                },
            )
        except Exception:
            self._current_span = None

    def on_llm_end(self, response: LLMResult, **kwargs: Any) -> None:
        span = self._current_span

        try:
            llm_output = response.llm_output or {}
            input_tokens, output_tokens = _extract_token_counts(llm_output, response)
            if input_tokens == 0 and output_tokens == 0:
                return

            model = self._resolve_model(llm_output, response)
            cost_usd = self._emit_cost(model, input_tokens, output_tokens)
            _set_span_attributes(span, input_tokens, output_tokens, cost_usd, model)
            self._check_enforcer_budget(cost_usd)

        except Exception as e:
            module_id = self._emitter.module_id if self._emitter else getattr(self, "_module_id", "unknown")
            emit_log("error", "cost_record_failed", service="agent", module=module_id, error=str(e))
        finally:
            if span:
                span.end()
            self._current_span = None
