"""LangChain callback that wraps AAPAgentRuntime.

Usage:
    from cockpit_aap.runtime import create_agent_runtime
    from cockpit_aap.runtime.langchain_callback import AAPLangChainCallback

    runtime = create_agent_runtime(manifest, {...})
    callback = AAPLangChainCallback(runtime)

    # Use with any LangChain/LangGraph agent:
    agent.invoke(input, config={"callbacks": [callback]})
"""
from __future__ import annotations
import uuid
from typing import Any
from .types import RuntimeContext, RuntimeResult


class AAPLangChainCallback:
    """LangChain BaseCallbackHandler that delegates to AAPAgentRuntime.

    Calls beforeCall on chain start, afterCall on chain end.
    Tracks tokens via on_llm_end for cost tracking.
    """

    def __init__(self, runtime: Any, agent_id: str = "default", model: str = "unknown"):
        self._runtime = runtime
        self._agent_id = agent_id
        self._model = model
        self._active_spans: dict[str, RuntimeContext] = {}

    async def on_chain_start(self, serialized: dict, inputs: dict, *, run_id: Any, **kwargs: Any) -> None:
        request_id = str(run_id) if run_id else str(uuid.uuid4())
        input_text = str(inputs.get("input", inputs.get("messages", [{}])[-1] if isinstance(inputs.get("messages"), list) else ""))
        ctx = RuntimeContext(
            agent_id=self._agent_id,
            request_id=request_id,
            input=input_text,
            model=self._model,
        )
        self._active_spans[request_id] = ctx
        decision = await self._runtime.before_call(ctx)
        if not decision.allowed:
            raise RuntimeError(f"Blocked by AAP guardrail: {[v.message for v in decision.violations]}")

    async def on_chain_end(self, outputs: dict, *, run_id: Any, **kwargs: Any) -> None:
        request_id = str(run_id) if run_id else ""
        ctx = self._active_spans.pop(request_id, None)
        if ctx:
            output_text = str(outputs.get("output", outputs.get("text", "")))
            await self._runtime.after_call(ctx, RuntimeResult(output=output_text))

    async def on_chain_error(self, error: BaseException, *, run_id: Any, **kwargs: Any) -> None:
        request_id = str(run_id) if run_id else ""
        ctx = self._active_spans.pop(request_id, None)
        if ctx:
            await self._runtime.on_error(ctx, error if isinstance(error, Exception) else Exception(str(error)))

    async def on_tool_start(self, serialized: dict, input_str: str, *, run_id: Any, **kwargs: Any) -> None:
        pass  # Could be extended to call runtime.on_tool_call()

    async def on_llm_end(self, response: Any, *, run_id: Any, **kwargs: Any) -> None:
        pass  # Token usage tracked in on_chain_end via afterCall
