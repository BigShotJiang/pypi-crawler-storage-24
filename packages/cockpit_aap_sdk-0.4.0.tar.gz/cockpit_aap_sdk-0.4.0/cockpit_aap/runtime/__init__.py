"""AAP Agent Runtime — framework-agnostic enforcement for AI agents."""
from .types import RuntimeContext, RuntimeResult, RuntimeDecision, ToolCallInfo
from .agent_runtime import create_agent_runtime
from .regex_guardrail import RegexGuardrailAdapter
from .composite_guardrail import CompositeGuardrailAdapter
from .guardrail_factory import create_guardrail_from_manifest
from .console_telemetry import ConsoleTelemetryAdapter
from cockpit_aap.adapters.in_memory_cost_tracker import InMemoryCostTracker
from .otel_telemetry import OtelTelemetryAdapter
from .postgres_cost_tracker import PostgresCostTracker
from .langchain_callback import AAPLangChainCallback
from .agno_hook import wrap_agno_agent
from .tenant_runtime import TenantAgentRuntime
from .cost_callback import CostCallbackHandler, BudgetExceededError, record_rule_violation
from .llamaguard_adapter import LlamaGuardAdapter
from .openai_moderation_adapter import OpenAIModerationAdapter

try:
    from .guardrails_ai_adapter import GuardrailsAIAdapter
except ImportError:
    pass  # guardrails-ai not installed

try:
    from .llamafirewall_adapter import LlamaFirewallAdapter
except ImportError:
    pass  # llamafirewall not installed

__all__ = [
    "RuntimeContext",
    "RuntimeResult",
    "RuntimeDecision",
    "ToolCallInfo",
    "create_agent_runtime",
    "RegexGuardrailAdapter",
    "CompositeGuardrailAdapter",
    "LlamaGuardAdapter",
    "create_guardrail_from_manifest",
    "ConsoleTelemetryAdapter",
    "InMemoryCostTracker",
    "OtelTelemetryAdapter",
    "PostgresCostTracker",
    "AAPLangChainCallback",
    "wrap_agno_agent",
    "TenantAgentRuntime",
    "CostCallbackHandler",
    "OpenAIModerationAdapter",
]
