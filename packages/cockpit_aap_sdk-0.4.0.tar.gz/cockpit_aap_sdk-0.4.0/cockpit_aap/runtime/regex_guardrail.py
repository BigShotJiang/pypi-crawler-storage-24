"""RegexGuardrailAdapter — PII + prompt injection detection via pure regex.

Port of packages/bootstrap/src/adapters/regex-guardrail.ts.
Same patterns: email, CPF, phone (BR), credit card, prompt injection.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

from cockpit_aap.ports.guardrail import (
    GuardrailContext,
    GuardrailDecision,
    GuardrailViolation,
)


@dataclass
class _RegexRule:
    id: str
    category: str
    pattern: re.Pattern[str]
    message: str
    severity: str  # "block" | "warn" | "info"


_PII_RULES: list[_RegexRule] = [
    _RegexRule(
        id="pii-email",
        category="pii",
        pattern=re.compile(r"[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}"),
        message="Email address detected",
        severity="block",
    ),
    _RegexRule(
        id="pii-cpf",
        category="pii",
        pattern=re.compile(r"\d{3}[.\s]?\d{3}[.\s]?\d{3}[-.\s]?\d{2}"),
        message="CPF number detected",
        severity="block",
    ),
    _RegexRule(
        id="pii-phone-br",
        category="pii",
        pattern=re.compile(r"(?:\+55\s?)?(?:\(?\d{2}\)?\s?)?\d{4,5}[-.\s]?\d{4}"),
        message="Phone number detected",
        severity="block",
    ),
    _RegexRule(
        id="pii-credit-card",
        category="pii",
        pattern=re.compile(r"\b(?:\d{4}[-\s]?){3}\d{4}\b"),
        message="Credit card number detected",
        severity="block",
    ),
]

_INJECTION_RULES: list[_RegexRule] = [
    _RegexRule(
        id="injection-ignore",
        category="prompt-injection",
        pattern=re.compile(
            r"ignore\s+(?:all\s+)?(?:previous|above|prior)\s+(?:instructions|prompts|rules)",
            re.IGNORECASE,
        ),
        message="Prompt injection pattern detected",
        severity="warn",
    ),
    _RegexRule(
        id="injection-system",
        category="prompt-injection",
        pattern=re.compile(
            r"(?:you\s+are\s+now|act\s+as|pretend\s+to\s+be|new\s+instructions?)\b",
            re.IGNORECASE,
        ),
        message="Role override pattern detected",
        severity="warn",
    ),
    _RegexRule(
        id="injection-reveal",
        category="prompt-injection",
        pattern=re.compile(
            r"(?:reveal|show|display|print|output)\s+(?:your\s+)?(?:system\s+)?(?:prompt|instructions|rules)",
            re.IGNORECASE,
        ),
        message="System prompt extraction attempt",
        severity="warn",
    ),
]

_ALL_RULES = _PII_RULES + _INJECTION_RULES


def _evaluate(text: str | None, rules: list[_RegexRule]) -> GuardrailDecision:
    if not text:
        return GuardrailDecision(allowed=True, action="pass", violations=[])

    violations: list[GuardrailViolation] = []
    for rule in rules:
        if rule.pattern.search(text):
            violations.append(
                GuardrailViolation(
                    rule_id=rule.id,
                    category=rule.category,
                    message=rule.message,
                    severity=rule.severity,
                )
            )

    has_block = any(v.severity == "block" for v in violations)
    action = "block" if has_block else ("warn" if violations else "pass")
    return GuardrailDecision(
        allowed=not has_block,
        action=action,
        violations=violations,
    )


class RegexGuardrailAdapter:
    """Built-in GuardrailPort adapter using regex patterns.

    Detects PII (email, CPF, phone, credit card) and prompt injection.
    No external dependencies — pure regex.
    """

    async def evaluate_input(self, context: GuardrailContext) -> GuardrailDecision:
        return _evaluate(context.input, _ALL_RULES)

    async def evaluate_output(self, context: GuardrailContext) -> GuardrailDecision:
        return _evaluate(context.input, _ALL_RULES)
