"""Agno framework hook that wraps AAPAgentRuntime.

Usage:
    from cockpit_aap.runtime import create_agent_runtime
    from cockpit_aap.runtime.agno_hook import wrap_agno_agent

    runtime = create_agent_runtime(manifest, {...})
    wrapped_run = wrap_agno_agent(agent.run, runtime, agent_id="my-agent", model="gpt-5.4")

    # Use instead of agent.run():
    response = await wrapped_run("Hello")
"""
from __future__ import annotations
import uuid
from typing import Any, Callable, Awaitable
from .types import RuntimeContext, RuntimeResult


def wrap_agno_agent(
    run_fn: Callable[..., Awaitable[Any]],
    runtime: Any,
    agent_id: str = "default",
    model: str = "unknown",
) -> Callable[..., Awaitable[Any]]:
    """Wrap an async agent run function with AAP runtime enforcement.

    Works with Agno, or any async function that takes input and returns output.
    """

    async def wrapped(input_text: str, **kwargs: Any) -> Any:
        request_id = str(uuid.uuid4())
        ctx = RuntimeContext(
            agent_id=agent_id,
            request_id=request_id,
            input=input_text,
            model=model,
        )

        # beforeCall — guardrail input + telemetry start
        decision = await runtime.before_call(ctx)
        if not decision.allowed:
            raise RuntimeError(f"Blocked by AAP guardrail: {[v.message for v in decision.violations]}")

        try:
            # Call the actual agent
            result = await run_fn(input_text, **kwargs)

            # afterCall — guardrail output + cost + telemetry end
            output_text = str(result) if result else ""
            await runtime.after_call(ctx, RuntimeResult(output=output_text))

            return result
        except Exception as e:
            await runtime.on_error(ctx, e)
            raise

    return wrapped
