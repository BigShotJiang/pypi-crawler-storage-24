"""Runtime types — Python equivalent of packages/bootstrap/src/runtime/types.ts."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from cockpit_aap.ports.guardrail import GuardrailViolation
from cockpit_aap.ports.cost_tracker import BudgetStatus


@dataclass
class RuntimeContext:
    agent_id: str
    request_id: str
    input: str
    model: str
    user_id: str | None = None
    tenant_id: str | None = None
    request: Any = None
    metadata: dict[str, Any] | None = None


@dataclass
class RuntimeResult:
    output: str
    usage: dict[str, int] | None = None  # {"input_tokens": int, "output_tokens": int}
    tool_calls: list[dict[str, Any]] | None = None


@dataclass
class ToolCallInfo:
    name: str
    args: dict[str, Any] = field(default_factory=dict)
    result: Any = None


@dataclass
class RuntimeDecision:
    allowed: bool = True
    action: str = "pass"  # "pass" | "block" | "warn" | "rewrite"
    rewritten: str | None = None
    violations: list[GuardrailViolation] = field(default_factory=list)
    budget_status: BudgetStatus | None = None
