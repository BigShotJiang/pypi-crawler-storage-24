"""ConsoleTelemetryAdapter — structured print()-based span logging.

Port of packages/bootstrap/src/adapters/console-telemetry.ts.
"""
from __future__ import annotations

from cockpit_aap.ports.agent_telemetry import (
    AgentSpanContext,
    SpanHandle,
    AgentEvent,
    AgentSpanResult,
)

_counter = 0


class ConsoleTelemetryAdapter:
    """Built-in AgentTelemetryPort adapter using print() for structured logging."""

    def start_agent_span(self, context: AgentSpanContext) -> SpanHandle:
        global _counter
        _counter += 1
        span_id = f"span-{_counter}"
        trace_id = f"trace-{context.request_id}"
        extra = ""
        if context.user_id:
            extra += f" enduser.id={context.user_id}"
        if context.tenant_id:
            extra += f" aap.tenant.id={context.tenant_id}"
        print(
            f"[telemetry] START {span_id} gen_ai.agent "
            f"gen_ai.agent.id={context.agent_id} "
            f"gen_ai.request.model={context.model} "
            f"gen_ai.request.id={context.request_id}"
            f"{extra}"
        )
        return SpanHandle(span_id=span_id, trace_id=trace_id)

    def record_event(self, span: SpanHandle, event: AgentEvent) -> None:
        attrs = " ".join(f"{k}={v}" for k, v in event.attributes.items())
        print(f"[telemetry] EVENT {span.span_id} {event.name} {attrs}")

    def end_span(self, span: SpanHandle, result: AgentSpanResult) -> None:
        duration = f" {result.duration_ms}ms" if result.duration_ms else ""
        attrs_str = ""
        if result.attributes:
            attrs_str = " " + " ".join(f"{k}={v}" for k, v in result.attributes.items())
        print(f"[telemetry] END {span.span_id} status={result.status}{duration}{attrs_str}")
