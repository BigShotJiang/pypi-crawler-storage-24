"""CostTrackerPort backed by Postgres — persists cost data for FinOps dashboards."""
from __future__ import annotations
from cockpit_aap.ports.cost_tracker import CostUsage, CostFilter, CostSummary, BudgetStatus


class PostgresCostTracker:
    def __init__(self, pool, config: dict | None = None):
        self._pool = pool
        self._config = config or {}
        self._table = self._config.get("table_name", "aap_cost_usage")
        self._pricing = self._config.get("models", {})
        self._currency = self._config.get("currency", "USD")
        self._budget = self._config.get("budget", {})

    def _calculate_cost(self, usage: CostUsage) -> float:
        p = self._pricing.get(usage.model)
        if not p:
            return usage.cost_usd or 0
        return (usage.input_tokens / 1000) * p.get("input_per_1k", 0) + (usage.output_tokens / 1000) * p.get("output_per_1k", 0)

    async def record(self, usage: CostUsage) -> None:
        cost = usage.cost_usd if usage.cost_usd else self._calculate_cost(usage)
        await self._pool.execute(
            f"INSERT INTO {self._table} (agent_id, model, input_tokens, output_tokens, cost_usd, request_id, created_at) VALUES ($1, $2, $3, $4, $5, $6, NOW())",
            usage.agent_id, usage.model, usage.input_tokens, usage.output_tokens, cost, usage.request_id,
        )

    async def query(self, filter: CostFilter) -> CostSummary:
        where = "1=1"
        params = []
        idx = 1
        if filter.agent_id:
            where += f" AND agent_id = ${idx}"; params.append(filter.agent_id); idx += 1
        row = await self._pool.fetchrow(
            f"SELECT COALESCE(SUM(cost_usd), 0) as total_cost, COALESCE(SUM(input_tokens + output_tokens), 0) as total_tokens FROM {self._table} WHERE {where}",
            *params,
        )
        return CostSummary(total_cost=float(row["total_cost"]), total_tokens=int(row["total_tokens"]))

    async def check_budget(self, agent_id: str) -> BudgetStatus:
        limit = self._budget.get("daily", self._budget.get("monthly", float("inf")))
        period = "daily" if "daily" in self._budget else "monthly"
        interval = "1 day" if period == "daily" else "1 month"
        row = await self._pool.fetchrow(
            f"SELECT COALESCE(SUM(cost_usd), 0) as total_cost FROM {self._table} WHERE agent_id = $1 AND created_at >= NOW() - INTERVAL '{interval}'",
            agent_id,
        )
        spent = float(row["total_cost"])
        return BudgetStatus(within_budget=spent <= limit, spent=spent, limit=limit, currency=self._currency, period=period)
