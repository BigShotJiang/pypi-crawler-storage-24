"""OpenAIModerationAdapter — content safety via OpenAI's free Moderation API.

Uses the /v1/moderations endpoint which is FREE (no token cost) and included
with any OpenAI API key. Detects: violence, hate, self-harm, sexual content,
harassment, and more.

This is the easiest ML guardrail to enable — just needs OPENAI_API_KEY.

See: https://platform.openai.com/docs/guides/moderation
"""
from __future__ import annotations

import os
from dataclasses import dataclass, field

from cockpit_aap.ports.guardrail import (
    GuardrailContext,
    GuardrailDecision,
    GuardrailViolation,
)


# OpenAI moderation categories
CATEGORY_LABELS: dict[str, str] = {
    "harassment": "Harassment",
    "harassment/threatening": "Harassment / Threatening",
    "hate": "Hate Speech",
    "hate/threatening": "Hate Speech / Threatening",
    "illicit": "Illicit Activity",
    "illicit/violent": "Illicit / Violent",
    "self-harm": "Self-Harm",
    "self-harm/intent": "Self-Harm / Intent",
    "self-harm/instructions": "Self-Harm / Instructions",
    "sexual": "Sexual Content",
    "sexual/minors": "Sexual Content / Minors",
    "violence": "Violence",
    "violence/graphic": "Violence / Graphic",
}


@dataclass
class OpenAIModerationConfig:
    """Configuration for the OpenAI Moderation adapter."""
    api_key: str = ""
    model: str = "omni-moderation-latest"
    # Categories that trigger a block (default: all flagged)
    block_categories: list[str] = field(default_factory=list)
    # Categories that only warn (not block)
    warn_categories: list[str] = field(default_factory=lambda: ["harassment"])
    # Minimum score threshold to consider a category flagged (0.0–1.0)
    score_threshold: float = 0.5

    def __post_init__(self):
        if not self.api_key:
            self.api_key = os.environ.get("OPENAI_API_KEY", "")


class OpenAIModerationAdapter:
    """GuardrailPort adapter using OpenAI's free Moderation API.

    Zero extra cost — the moderation endpoint is free for all OpenAI accounts.
    Supports the latest omni-moderation model with 13+ safety categories.
    """

    def __init__(self, config: OpenAIModerationConfig | None = None):
        self.config = config or OpenAIModerationConfig()
        self._client = None

    def _get_client(self):
        """Lazy-init httpx async client."""
        if self._client is None:
            import httpx
            self._client = httpx.AsyncClient(
                base_url="https://api.openai.com",
                timeout=10.0,
                headers={
                    "Authorization": f"Bearer {self.config.api_key}",
                    "Content-Type": "application/json",
                },
            )
        return self._client

    def _parse_moderation_result(self, result: dict) -> GuardrailDecision:
        """Parse a single moderation result into a GuardrailDecision."""
        categories = result.get("categories", {})
        scores = result.get("category_scores", {})

        violations: list[GuardrailViolation] = []
        has_block = False

        for category, is_flagged in categories.items():
            if not is_flagged:
                continue

            score = scores.get(category, 0.0)
            label = CATEGORY_LABELS.get(category, category)
            severity = "warn" if category in self.config.warn_categories else "block"

            if severity == "block":
                has_block = True

            violations.append(GuardrailViolation(
                rule_id=f"openai-mod-{category.replace('/', '-')}",
                category="content-safety",
                message=f"OpenAI Moderation: {label} (score: {score:.2f})",
                severity=severity,
            ))

        if has_block:
            return GuardrailDecision(allowed=False, action="block", violations=violations)
        if violations:
            return GuardrailDecision(allowed=True, action="warn", violations=violations)
        return GuardrailDecision(allowed=True, action="pass", violations=[])

    async def _moderate(self, text: str) -> GuardrailDecision:
        """Call OpenAI Moderation API and parse the result."""
        if not text or not text.strip():
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        if not self.config.api_key:
            return GuardrailDecision(allowed=True, action="pass", violations=[])

        try:
            client = self._get_client()
            response = await client.post(
                "/v1/moderations",
                json={"model": self.config.model, "input": text},
            )
            response.raise_for_status()
            data = response.json()

            results = data.get("results", [])
            if not results:
                return GuardrailDecision(allowed=True, action="pass", violations=[])

            return self._parse_moderation_result(results[0])

        except Exception as e:
            from cockpit_aap.logging import emit_log
            emit_log("error", "openai_moderation_error", service="guardrail", module="guardrail",
                     error=str(e))
            return GuardrailDecision(allowed=True, action="pass", violations=[])

    async def evaluate_input(self, context: GuardrailContext) -> GuardrailDecision:
        return await self._moderate(context.input or "")

    async def evaluate_output(self, context: GuardrailContext) -> GuardrailDecision:
        return await self._moderate(context.input or "")

    async def close(self):
        if self._client:
            await self._client.aclose()
            self._client = None
