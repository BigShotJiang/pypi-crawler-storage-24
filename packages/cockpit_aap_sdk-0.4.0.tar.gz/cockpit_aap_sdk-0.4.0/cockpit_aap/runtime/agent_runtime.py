"""create_agent_runtime() — framework-agnostic enforcement orchestrator.

Port of packages/bootstrap/src/runtime/agent-runtime.ts.
Reads manifest spec.guardrails/telemetry/cost and wires the 3 ports.
"""
from __future__ import annotations

import time
from typing import Any, Protocol

from cockpit_aap.ports.guardrail import GuardrailContext
from cockpit_aap.ports.cost_tracker import BudgetStatus, CostUsage
from cockpit_aap.ports.agent_telemetry import AgentSpanContext, AgentEvent, AgentSpanResult, SpanHandle

from .types import RuntimeContext, RuntimeResult, RuntimeDecision, ToolCallInfo


class AAPAgentRuntime(Protocol):
    async def before_call(self, ctx: RuntimeContext) -> RuntimeDecision: ...
    async def after_call(self, ctx: RuntimeContext, result: RuntimeResult) -> RuntimeDecision: ...
    async def on_tool_call(self, ctx: RuntimeContext, tool: ToolCallInfo) -> RuntimeDecision: ...
    async def on_error(self, ctx: RuntimeContext, error: Exception) -> None: ...
    async def get_budget_status(self, agent_id: str) -> BudgetStatus: ...


# ---------------------------------------------------------------------------
# Noop adapters (inline — avoid circular deps)
# ---------------------------------------------------------------------------

class _NoopGuardrail:
    # async required: implements GuardrailPort protocol
    async def evaluate_input(self, context: Any) -> Any:
        from cockpit_aap.ports.guardrail import GuardrailDecision
        return GuardrailDecision(allowed=True, action="pass", violations=[])

    # async required: implements GuardrailPort protocol
    async def evaluate_output(self, context: Any) -> Any:
        from cockpit_aap.ports.guardrail import GuardrailDecision
        return GuardrailDecision(allowed=True, action="pass", violations=[])


class _NoopTelemetry:
    def start_agent_span(self, context: Any) -> SpanHandle:
        return SpanHandle(span_id="noop", trace_id="noop")

    def record_event(self, span: Any, event: Any) -> None:
        pass

    def end_span(self, span: Any, result: Any) -> None:
        pass


class _NoopCostTracker:
    # async required: implements CostTrackerPort protocol
    async def record(self, usage: Any) -> None:
        pass

    # async required: implements CostTrackerPort protocol
    async def query(self, filter: Any) -> Any:
        from cockpit_aap.ports.cost_tracker import CostSummary
        return CostSummary(total_cost=0, total_tokens=0, entries=[])

    # async required: implements CostTrackerPort protocol
    async def query_timeseries(self, filter: Any, granularity: str = "hour") -> list:
        return []

    # async required: implements CostTrackerPort protocol
    async def check_budget(self, agent_id: str, tenant_id: str | None = None) -> BudgetStatus:
        return BudgetStatus(within_budget=True, spent=0, limit=float("inf"), currency="USD", period="total")


# ---------------------------------------------------------------------------
# Config helpers — extract manifest configuration with dict/object duck-typing
# ---------------------------------------------------------------------------

def _get_cfg_field(cfg: Any, name: str, default: Any = None) -> Any:
    """Read a field from a config that may be a dict or an object."""
    if isinstance(cfg, dict):
        return cfg.get(name, default)
    return getattr(cfg, name, default)


def _resolve_guardrail_rules(guardrails_cfg: Any) -> tuple[bool, bool]:
    """Return (has_input_guardrails, has_output_guardrails) from the guardrails config."""
    input_rules = _get_cfg_field(guardrails_cfg, "input", []) or []
    output_rules = _get_cfg_field(guardrails_cfg, "output", []) or []
    return len(input_rules) > 0, len(output_rules) > 0


def _resolve_has_telemetry(telemetry_cfg: Any) -> bool:
    """Return whether telemetry is enabled in the config."""
    if telemetry_cfg is None:
        return False
    return _get_cfg_field(telemetry_cfg, "enabled", False) is True


def _resolve_has_cost(cost_cfg: Any) -> bool:
    """Return whether cost tracking is enabled (budget configured)."""
    if cost_cfg is None:
        return False
    return bool(_get_cfg_field(cost_cfg, "budget", None))


# ---------------------------------------------------------------------------
# Telemetry helpers — reduce nesting inside _Runtime methods
# ---------------------------------------------------------------------------

def _record_guardrail_event(
    telemetry: Any, spans: dict[str, SpanHandle], request_id: str, event_name: str, decision: Any,
) -> None:
    """Record a guardrail evaluation event on the active span."""
    span = spans.get(request_id)
    if span:
        telemetry.record_event(
            span,
            AgentEvent(
                name=event_name,
                attributes={"allowed": decision.allowed, "violations": len(decision.violations)},
            ),
        )


def _end_span_and_cleanup(
    telemetry: Any, spans: dict[str, SpanHandle], request_id: str, status: str,
) -> None:
    """End the active span for *request_id* and remove it from the map."""
    span = spans.get(request_id)
    if span:
        telemetry.end_span(span, AgentSpanResult(status=status))
        del spans[request_id]


def _blocked_decision(decision: Any) -> RuntimeDecision:
    """Create a RuntimeDecision from a blocked guardrail decision."""
    return RuntimeDecision(
        allowed=False,
        action=decision.action,
        violations=decision.violations,
    )


# ---------------------------------------------------------------------------
# Tenant resolution helper
# ---------------------------------------------------------------------------

async def _resolve_tenant(tenant_resolver: Any, ctx: RuntimeContext) -> None:
    """Best-effort tenant resolution — mutates *ctx* in place."""
    if not tenant_resolver or not ctx.request:
        return
    try:
        tenant = await tenant_resolver.resolve(ctx.request)
        ctx.tenant_id = f"{tenant.license_id}:{tenant.namespace_id}"
        ctx.user_id = ctx.user_id or tenant.user_id
    except Exception:
        pass  # best-effort


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def create_agent_runtime(manifest: Any, adapters: dict[str, Any] | None = None) -> Any:
    """Create a framework-agnostic agent runtime from a manifest.

    The dev calls before_call/after_call at the right points in their framework.
    Works with CopilotKit, LangGraph, Agno, or anything.

    Args:
        manifest: A Manifest object (or duck-type with .spec attribute).
        adapters: Optional dict with keys "guardrail", "telemetry", "cost_tracker".
    """
    adapters = adapters or {}
    guardrail = adapters.get("guardrail") or _NoopGuardrail()
    telemetry = adapters.get("telemetry") or _NoopTelemetry()
    cost_tracker = adapters.get("cost_tracker") or _NoopCostTracker()
    tenant_resolver = adapters.get("tenant_resolver")

    spec = manifest.spec if hasattr(manifest, "spec") else manifest

    # Read manifest config (supports both dataclass and dict specs)
    guardrails_cfg = _get_cfg_field(spec, "guardrails", None) or {}
    telemetry_cfg = _get_cfg_field(spec, "telemetry", None)
    cost_cfg = _get_cfg_field(spec, "cost", None)

    # Determine what's enabled
    has_input_guardrails, has_output_guardrails = _resolve_guardrail_rules(guardrails_cfg)
    has_telemetry = _resolve_has_telemetry(telemetry_cfg)
    has_cost = _resolve_has_cost(cost_cfg)

    # Active spans tracked by request_id
    spans: dict[str, SpanHandle] = {}

    class _Runtime:
        async def before_call(self, ctx: RuntimeContext) -> RuntimeDecision:
            await _resolve_tenant(tenant_resolver, ctx)

            if has_telemetry:
                span = telemetry.start_agent_span(
                    AgentSpanContext(
                        agent_id=ctx.agent_id,
                        request_id=ctx.request_id,
                        model=ctx.model,
                        user_id=ctx.user_id,
                        tenant_id=ctx.tenant_id,
                    )
                )
                spans[ctx.request_id] = span

            if has_input_guardrails:
                decision = await guardrail.evaluate_input(
                    GuardrailContext(agent_id=ctx.agent_id, input=ctx.input)
                )
                if has_telemetry:
                    _record_guardrail_event(telemetry, spans, ctx.request_id, "guardrail_input", decision)
                if not decision.allowed:
                    if has_telemetry:
                        _end_span_and_cleanup(telemetry, spans, ctx.request_id, "blocked")
                    return _blocked_decision(decision)
                if decision.action == "rewrite" and decision.rewritten:
                    return RuntimeDecision(allowed=True, action="rewrite", rewritten=decision.rewritten)

            return RuntimeDecision(allowed=True, action="pass")

        async def after_call(self, ctx: RuntimeContext, result: RuntimeResult) -> RuntimeDecision:
            if has_output_guardrails:
                decision = await guardrail.evaluate_output(
                    GuardrailContext(agent_id=ctx.agent_id, input=result.output)
                )
                if has_telemetry:
                    _record_guardrail_event(telemetry, spans, ctx.request_id, "guardrail_output", decision)
                if not decision.allowed:
                    if has_telemetry:
                        _end_span_and_cleanup(telemetry, spans, ctx.request_id, "blocked")
                    return _blocked_decision(decision)

            if has_cost and result.usage:
                await cost_tracker.record(
                    CostUsage(
                        agent_id=ctx.agent_id,
                        model=ctx.model,
                        input_tokens=result.usage.get("input_tokens", 0),
                        output_tokens=result.usage.get("output_tokens", 0),
                        timestamp=time.time() * 1000,
                        request_id=ctx.request_id,
                        tenant_id=ctx.tenant_id,
                    )
                )
                budget = await cost_tracker.check_budget(ctx.agent_id, ctx.tenant_id)
                if not budget.within_budget:
                    if has_telemetry:
                        _end_span_and_cleanup(telemetry, spans, ctx.request_id, "budget_exceeded")
                    return RuntimeDecision(allowed=True, action="warn", budget_status=budget)

            if has_telemetry:
                span = spans.get(ctx.request_id)
                if span:
                    attrs = {}
                    if result.usage:
                        attrs["gen_ai.usage.input_tokens"] = result.usage.get("input_tokens", 0)
                        attrs["gen_ai.usage.output_tokens"] = result.usage.get("output_tokens", 0)
                    telemetry.end_span(span, AgentSpanResult(status="ok", attributes=attrs))
                    del spans[ctx.request_id]

            return RuntimeDecision(allowed=True, action="pass")

        async def on_tool_call(self, ctx: RuntimeContext, tool: ToolCallInfo) -> RuntimeDecision:
            if has_telemetry:
                span = spans.get(ctx.request_id)
                if span:
                    telemetry.record_event(
                        span, AgentEvent(name="tool_call", attributes={"tool": tool.name})
                    )
            return RuntimeDecision(allowed=True, action="pass")

        async def on_error(self, ctx: RuntimeContext, error: Exception) -> None:
            if has_telemetry:
                _end_span_and_cleanup(telemetry, spans, ctx.request_id, "error")

        async def get_budget_status(self, agent_id: str) -> BudgetStatus:
            return await cost_tracker.check_budget(agent_id, None)

    return _Runtime()
