"""Testing helpers for AAP SDK apps."""
from __future__ import annotations
from cockpit_aap.manifest.scanner import scan_manifest
from cockpit_aap.runtime import create_agent_runtime, RegexGuardrailAdapter, ConsoleTelemetryAdapter, InMemoryCostTracker
from cockpit_aap.runtime.types import RuntimeContext


def create_test_runtime(manifest_path: str):
    """Create an AAPAgentRuntime with test adapters from a manifest path."""
    manifest = scan_manifest(manifest_path)
    return create_agent_runtime(manifest, {
        "guardrail": RegexGuardrailAdapter(),
        "telemetry": ConsoleTelemetryAdapter(),
        "cost_tracker": InMemoryCostTracker({}),
    })


async def assert_guardrail_blocks(runtime, input_text: str, expected_category: str) -> None:
    """Assert that input is blocked by guardrails with the expected violation category."""
    ctx = RuntimeContext(agent_id="test", request_id="test-assert", input=input_text, model="test")
    decision = await runtime.before_call(ctx)
    if decision.allowed:
        raise AssertionError(f"Expected input to be blocked but it was allowed: '{input_text}'")
    categories = [v.category for v in decision.violations]
    if expected_category not in categories:
        raise AssertionError(f"Expected violation category '{expected_category}' but got: {categories}")


async def assert_guardrail_passes(runtime, input_text: str) -> None:
    """Assert that input passes guardrails without blocking."""
    ctx = RuntimeContext(agent_id="test", request_id="test-assert", input=input_text, model="test")
    decision = await runtime.before_call(ctx)
    if not decision.allowed:
        raise AssertionError(f"Expected input to pass but it was blocked: '{input_text}'. Violations: {decision.violations}")


def mock_manifest(**overrides):
    """Create a minimal mock Manifest for testing."""
    base = {
        "apiVersion": "cockpit.io/v1",
        "kind": "Module",
        "metadata": {"name": "test-module", "displayName": "Test Module", "version": "1.0.0", "description": "Test"},
        "spec": {
            "guardrails": {"input": [{"id": "pii", "category": "pii", "action": "block"}], "output": []},
        },
    }
    base.update(overrides)
    # Return as a simple namespace that behaves like a Manifest
    return _dict_to_namespace(base)


def _dict_to_namespace(d):
    """Convert nested dict to namespace object (for manifest-like access)."""
    if isinstance(d, dict):
        ns = type("Ns", (), {})()
        for k, v in d.items():
            setattr(ns, k, _dict_to_namespace(v))
        return ns
    if isinstance(d, list):
        return [_dict_to_namespace(i) for i in d]
    return d
