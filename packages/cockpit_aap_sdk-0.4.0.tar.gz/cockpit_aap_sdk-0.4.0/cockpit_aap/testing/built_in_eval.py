"""Built-in eval adapter — runs mock mode evals using AAPAgentRuntime."""
from __future__ import annotations
import time
from cockpit_aap.runtime.types import RuntimeContext, RuntimeResult


class BuiltInEval:
    """EvalPort backed by AAPAgentRuntime for deterministic mock evals."""

    def __init__(self, runtime):
        self._runtime = runtime

    async def run(self, test_case: dict) -> dict:
        start = time.monotonic()
        tc = test_case
        tc_id = tc.get("id", "unknown")

        if tc.get("mode") in ("live", "redteam"):
            return {"id": tc_id, "passed": False, "mode": tc["mode"], "durationMs": 0,
                    "details": {"input": tc["input"]},
                    "error": f"{tc['mode']} mode requires external adapter (DeepEval/Promptfoo)"}

        try:
            ctx = RuntimeContext(
                agent_id=tc.get("agent", "default"),
                request_id=f"eval-{tc_id}",
                input=tc["input"],
                model="mock",
            )
            decision = await self._runtime.before_call(ctx)

            # Check expectedAction
            if "expectedAction" in tc:
                if decision.action != tc["expectedAction"]:
                    return self._fail(tc_id, tc["input"], start,
                                      f"Expected action '{tc['expectedAction']}', got '{decision.action}'")

            # Check expectedViolationCategory
            if "expectedViolationCategory" in tc:
                categories = [v.category for v in decision.violations]
                if tc["expectedViolationCategory"] not in categories:
                    return self._fail(tc_id, tc["input"], start,
                                      f"Expected violation category '{tc['expectedViolationCategory']}' not in {categories}")

            # Check budget
            if "simulateUsage" in tc:
                usage = tc["simulateUsage"]
                await self._runtime.after_call(ctx, RuntimeResult(
                    output="eval-test",
                    usage={"input_tokens": usage["inputTokens"], "output_tokens": usage["outputTokens"]},
                ))
                budget = await self._runtime.get_budget_status(ctx.agent_id)
                if "expectedBudgetExceeded" in tc:
                    exceeded = not budget.within_budget
                    if exceeded != tc["expectedBudgetExceeded"]:
                        return self._fail(tc_id, tc["input"], start,
                                          f"Expected budgetExceeded={tc['expectedBudgetExceeded']}, got {exceeded}")

            elapsed = (time.monotonic() - start) * 1000
            return {
                "id": tc_id, "passed": True, "mode": "mock", "durationMs": round(elapsed, 1),
                "details": {
                    "input": tc["input"],
                    "action": decision.action,
                    "violations": [{"category": v.category, "message": v.message} for v in decision.violations],
                },
            }
        except Exception as e:
            return self._fail(tc_id, tc.get("input", ""), start, str(e))

    def _fail(self, tc_id, input_text, start, error):
        elapsed = (time.monotonic() - start) * 1000
        return {"id": tc_id, "passed": False, "mode": "mock", "durationMs": round(elapsed, 1),
                "details": {"input": input_text}, "error": error}
