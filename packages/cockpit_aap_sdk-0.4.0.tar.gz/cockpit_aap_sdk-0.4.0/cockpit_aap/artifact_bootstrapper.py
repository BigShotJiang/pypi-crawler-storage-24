"""Granular single-artifact bootstrap: fetch-or-create with upgrade logic.

Port of ``packages/bootstrap/src/artifact-bootstrapper.ts``.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass
from typing import Any, Literal

from .meta import MetaManifest, UpgradeStrategy, checksum, resolve_upgrade_action

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class ArtifactDefinition:
    """Definition for an artifact to bootstrap."""

    key: str
    default_value: str
    description: str = ""
    artifact_type: str = "string"
    accessibility: str = "Namespace"
    artifact_category: str = "configuration"
    tags: list[str] | None = None


@dataclass
class ResolvedArtifact:
    """Result of bootstrapping a single artifact."""

    key: str
    value: str
    source: str  # "server" | "created" | "upgraded" | "default-fallback"
    id: str = ""
    error: str | None = None


@dataclass
class UpgradeContext:
    """Context passed during upgrade (version change detected)."""

    old_manifest: MetaManifest
    strategy: UpgradeStrategy


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _escape_regex(s: str) -> str:
    return re.escape(s)


def _has_artifact_value(content: dict[str, Any]) -> bool:
    """Check if the search result contains a valid artifact."""
    artifacts = content.get("artifacts")
    if isinstance(artifacts, list):
        return len(artifacts) > 0
    if isinstance(content, list):
        return len(content) > 0
    return (
        content.get("value") is not None
        or content.get("content") is not None
        or content.get("key") is not None
    )


def _extract_first_artifact(content: dict[str, Any]) -> dict[str, Any] | None:
    """Extract the first artifact from the search result."""
    artifacts = content.get("artifacts")
    if isinstance(artifacts, list) and len(artifacts) > 0:
        return artifacts[0]
    if isinstance(content, list) and len(content) > 0:
        return content[0]
    if content.get("value") is not None or content.get("content") is not None:
        return content
    return None


def _extract_artifact_value(content: dict[str, Any]) -> str:
    """Extract the artifact value string from the server response."""
    artifact = _extract_first_artifact(content)
    if not artifact:
        return ""
    raw = artifact.get("value") or artifact.get("content") or ""
    return raw if isinstance(raw, str) else str(raw)


async def _search_existing_artifact(
    sdk: Any,
    namespace: str,
    key: str,
    verbose: bool = False,
) -> tuple[str, str] | None:
    """Search for an existing artifact by exact key.

    Returns ``(id, server_value)`` or ``None``.
    """
    pattern = f"^{_escape_regex(key)}$"
    if verbose:
        logger.info("[bootstrap] Searching artifact: %s", key)

    result = await sdk.call_tool(namespace, "get_artifact", {"key_pattern": pattern})
    content = result.get("content", {})

    if not content or result.get("isError") or not _has_artifact_value(content):
        return None

    artifact = _extract_first_artifact(content)
    raw_id = ""
    if artifact:
        raw_id = artifact.get("id") or artifact.get("artifact_id") or ""
    artifact_id = str(raw_id) if raw_id else ""
    server_value = _extract_artifact_value(content)
    return (artifact_id, server_value)


async def _update_artifact(
    sdk: Any,
    namespace: str,
    definition: ArtifactDefinition,
    module: str,
    artifact_id: str | None = None,
) -> None:
    """Update an existing artifact on the server. Falls back to OVERWRITE create."""
    tags = ",".join(["bootstrap", module] + (definition.tags or []))

    if artifact_id:
        try:
            result = await sdk.call_tool(namespace, "update_artifact", {
                "id": artifact_id,
                "value": definition.default_value,
                "promote_to_production": True,
            })
            content = result.get("content", {})
            if isinstance(content, dict) and content.get("success") is not False:
                return
        except Exception:
            pass  # Fall through to OVERWRITE

    await sdk.call_tool(namespace, "create_artifact", {
        "key": definition.key,
        "value": definition.default_value,
        "description": definition.description,
        "artifact_type": definition.artifact_type,
        "accessibility": definition.accessibility,
        "conflict_strategy": "OVERWRITE",
        "tags": tags,
    })


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def bootstrap_artifact(
    sdk: Any,
    namespace: str,
    definition: ArtifactDefinition,
    module: str,
    *,
    verbose: bool = False,
    upgrade: UpgradeContext | None = None,
) -> ResolvedArtifact:
    """Bootstrap a single artifact: fetch from server or create with default.

    Flow:
        1. Search by exact key
        2. If found:
           - State artifacts → always use server value
           - If upgrade context → apply upgrade logic
           - Otherwise → return server value
        3. If not found → create with default value
        4. On error → return default-fallback

    Parameters
    ----------
    sdk:
        The SDK client (or LocalSdk).
    namespace:
        MCP namespace (e.g. ``"artifacts"``).
    definition:
        Artifact definition with key, default value, etc.
    module:
        Module ID for tagging.
    verbose:
        Log progress to logger.
    upgrade:
        If provided, apply upgrade logic on found artifacts.
    """
    log = verbose

    # Step 1: Search for existing
    try:
        found = await _search_existing_artifact(sdk, namespace, definition.key, log)

        if found:
            artifact_id, server_value = found

            # State artifacts always use server value
            if definition.artifact_category == "state":
                if log:
                    logger.info('[bootstrap] State artifact "%s" — using server value', definition.key)
                return ResolvedArtifact(
                    key=definition.key, value=server_value,
                    source="server", id=artifact_id,
                )

            # Apply upgrade logic if context present
            if upgrade:
                new_def_checksum = checksum(definition.default_value)
                current_server_checksum = checksum(server_value)
                action = resolve_upgrade_action(
                    definition.key,
                    new_def_checksum,
                    current_server_checksum,
                    upgrade.old_manifest,
                    upgrade.strategy,
                )

                if action in ("update", "code-wins"):
                    label = "Upgrading" if action == "update" else "Conflict → code-wins (overwriting)"
                    if log:
                        logger.info('[bootstrap] %s artifact "%s"', label, definition.key)
                    try:
                        await _update_artifact(sdk, namespace, definition, module, artifact_id or None)
                        return ResolvedArtifact(
                            key=definition.key, value=definition.default_value,
                            source="upgraded", id=artifact_id,
                        )
                    except Exception:
                        if log:
                            logger.info('[bootstrap] %s failed for "%s", keeping server value', action, definition.key)

                if action == "log-warning":
                    logger.warning(
                        '[bootstrap] CONFLICT: "%s" changed in both code and server. '
                        "Keeping server value (strategy: log-warning). "
                        "Review and resolve manually.",
                        definition.key,
                    )

                # "skip", "server-wins", "log-warning", or no action → use server
                # (fall through)

            if log:
                logger.info('[bootstrap] Found artifact "%s" on server (id: %s)', definition.key, artifact_id)
            return ResolvedArtifact(
                key=definition.key, value=server_value,
                source="server", id=artifact_id,
            )
    except Exception:
        pass  # Not found or error — proceed to create

    # Step 2: Create with default
    try:
        if log:
            logger.info("[bootstrap] Creating artifact: %s", definition.key)
        tags = ",".join(["bootstrap", module] + (definition.tags or []))

        result = await sdk.call_tool(namespace, "create_artifact", {
            "key": definition.key,
            "value": definition.default_value,
            "description": definition.description,
            "artifact_type": definition.artifact_type,
            "accessibility": definition.accessibility,
            "conflict_strategy": "SKIP",
            "tags": tags,
        })

        content = result.get("content", {})
        created = _extract_first_artifact(content) or content
        raw_id = created.get("id") or created.get("artifact_id") or "" if isinstance(created, dict) else ""
        created_id = str(raw_id) if raw_id else ""

        if log:
            logger.info('[bootstrap] Created artifact "%s" (id: %s)', definition.key, created_id)
        return ResolvedArtifact(
            key=definition.key, value=definition.default_value,
            source="created", id=created_id,
        )
    except Exception as e:
        message = str(e)
        if log:
            logger.info('[bootstrap] Fallback for artifact "%s": %s', definition.key, message)
        return ResolvedArtifact(
            key=definition.key, value=definition.default_value,
            source="default-fallback", error=message,
        )
