"""MCP protocol types — Python port of @ruinosus/aap-core types.

Typed dataclasses for MCP prompts, resources, and resource templates.
These mirror the TypeScript interfaces: PromptArgument, PromptSchema,
PromptMessage, PromptResult, ResourceSchema, ResourceContents,
ResourceTemplate, ToolSchema, ToolResult, AAPServerConfig,
MultiAAPClientConfig.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Tool types (already used as dicts — now typed)
# ---------------------------------------------------------------------------


@dataclass
class ToolSchema:
    """Schema for a discovered MCP tool."""

    name: str
    description: str
    input_schema: dict[str, Any] = field(default_factory=dict)
    namespace: str = ""


@dataclass
class ToolResult:
    """Result of an MCP tool invocation."""

    content: Any = None
    is_error: bool = False


# ---------------------------------------------------------------------------
# Prompt types
# ---------------------------------------------------------------------------


@dataclass
class PromptArgument:
    """A single argument for an MCP prompt."""

    name: str
    description: str | None = None
    required: bool | None = None


@dataclass
class PromptSchema:
    """Schema for a discovered MCP prompt."""

    name: str
    description: str | None = None
    arguments: list[PromptArgument] = field(default_factory=list)
    namespace: str = ""


@dataclass
class PromptMessage:
    """A message within a prompt result."""

    role: str  # "user" | "assistant"
    content: dict[str, Any] = field(default_factory=dict)


@dataclass
class PromptResult:
    """Result of executing an MCP prompt."""

    description: str | None = None
    messages: list[PromptMessage] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Resource types
# ---------------------------------------------------------------------------


@dataclass
class ResourceSchema:
    """Schema for a discovered MCP resource."""

    uri: str
    name: str
    description: str | None = None
    mime_type: str | None = None
    namespace: str = ""


@dataclass
class ResourceContents:
    """Contents of a read MCP resource."""

    uri: str
    mime_type: str | None = None
    text: str | None = None
    blob: str | None = None


@dataclass
class ResourceTemplate:
    """An MCP resource template."""

    uri_template: str
    name: str
    description: str | None = None
    mime_type: str | None = None
    namespace: str = ""


# ---------------------------------------------------------------------------
# Multi-client config types
# ---------------------------------------------------------------------------


@dataclass
class AAPServerConfig:
    """Configuration for a single MCP server in a multi-client setup."""

    endpoint: str
    headers: dict[str, str] = field(default_factory=dict)
    mcp_protocol_version: str = "2024-11-05"


@dataclass
class MultiAAPClientConfig:
    """Configuration for connecting to multiple MCP servers."""

    servers: dict[str, AAPServerConfig] = field(default_factory=dict)
    timeout: float = 30.0
    validate_inputs: bool = False
