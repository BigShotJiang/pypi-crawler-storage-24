"""Multi-client support — connect to multiple MCP servers simultaneously.

Python port of ``createMultiAAPClient`` from ``@ruinosus/aap-core``.

Usage::

    from cockpit_aap.multi_client import create_multi_aap_client

    config = MultiAAPClientConfig(
        servers={
            "artifacts": AAPServerConfig(endpoint="http://...:3100/mcp"),
            "agents": AAPServerConfig(endpoint="http://...:3200/mcp"),
        },
        timeout=30.0,
    )

    sdk = await create_multi_aap_client(config)
    result = await sdk.artifacts.search_artifacts(query="module.*")

Each namespace is backed by a separate ``AAPGatewayClient`` pointed at its
own MCP server.  The returned ``MultiAAPClient`` routes attribute access
to the correct underlying client.
"""

from __future__ import annotations

import asyncio
from typing import Any, Awaitable, Callable

from cockpit_aap.client import AAPGatewayClient
from cockpit_aap.mcp_types import (
    AAPServerConfig,
    MultiAAPClientConfig,
    PromptResult,
    PromptSchema,
    ResourceContents,
    ResourceSchema,
    ResourceTemplate,
)


class _MultiNamespaceProxy:
    """Attribute access on a namespace becomes a tool call on the right client."""

    def __init__(self, client: AAPGatewayClient, namespace: str) -> None:
        self._client = client
        self._ns = namespace

    def __getattr__(self, tool_name: str) -> Callable[..., Any]:
        async def call(**kwargs: Any) -> dict[str, Any]:
            return await self._client.call_tool(self._ns, tool_name, kwargs)

        return call


class MultiAAPClient:
    """Client that routes namespaces to different MCP servers.

    Mirrors the TypeScript ``DynamicSDK`` returned by ``createMultiAAPClient``.
    """

    def __init__(self, clients: dict[str, AAPGatewayClient]) -> None:
        self._clients = clients

    # ------------------------------------------------------------------
    # Introspection (mirrors TS DynamicSDK underscore-prefixed accessors)
    # ------------------------------------------------------------------

    @property
    def namespaces(self) -> list[str]:
        """All registered namespace keys."""
        return list(self._clients.keys())

    def get_client(self, namespace: str) -> AAPGatewayClient:
        """Get the underlying client for a namespace."""
        client = self._clients.get(namespace)
        if client is None:
            raise ValueError(f"Unknown namespace: {namespace}")
        return client

    def get_tools(self, namespace: str) -> list[dict[str, Any]]:
        """List tools for a namespace."""
        return self.get_client(namespace).get_tools(namespace)

    def get_prompts(self, namespace: str) -> list[PromptSchema]:
        """List prompts for a namespace."""
        return self.get_client(namespace).get_prompts(namespace)

    async def get_prompt(
        self, namespace: str, name: str, args: dict[str, str] | None = None
    ) -> PromptResult:
        """Execute a prompt on a namespace's server."""
        return await self.get_client(namespace).get_prompt(namespace, name, args)

    def get_resources(self, namespace: str) -> list[ResourceSchema]:
        """List resources for a namespace."""
        return self.get_client(namespace).get_resources(namespace)

    async def read_resource(
        self, namespace: str, uri: str
    ) -> list[ResourceContents]:
        """Read a resource from a namespace's server."""
        return await self.get_client(namespace).read_resource(namespace, uri)

    def get_resource_templates(self, namespace: str) -> list[ResourceTemplate]:
        """List resource templates for a namespace."""
        return self.get_client(namespace).get_resource_templates(namespace)

    # ------------------------------------------------------------------
    # Dynamic namespace routing via __getattr__
    # ------------------------------------------------------------------

    def __getattr__(self, ns: str) -> _MultiNamespaceProxy:
        if ns.startswith("_"):
            raise AttributeError(ns)
        client = self._clients.get(ns)
        if client is None:
            raise AttributeError(f"Unknown namespace: {ns}")
        return _MultiNamespaceProxy(client, ns)

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def close(self) -> None:
        """Close all underlying clients."""
        for client in self._clients.values():
            if hasattr(client._transport, "close"):
                await client._transport.close()  # type: ignore[attr-defined]

    async def __aenter__(self) -> MultiAAPClient:
        return self

    async def __aexit__(self, *a: Any) -> None:
        await self.close()


async def create_multi_aap_client(
    config: MultiAAPClientConfig,
) -> MultiAAPClient:
    """Create a multi-server client, initializing all servers in parallel.

    Each entry in ``config.servers`` becomes a namespace → client mapping.
    All clients connect via MCP transport.

    Args:
        config: Server map with endpoint, headers, and optional protocol version.

    Returns:
        A ``MultiAAPClient`` that routes ``sdk.namespace.tool()`` to the
        correct underlying MCP server.

    Raises:
        RuntimeError: If any server fails to initialize.
    """
    clients: dict[str, AAPGatewayClient] = {}

    async def _init_one(namespace: str, server: AAPServerConfig) -> None:
        client = AAPGatewayClient(
            endpoint=server.endpoint,
            token="unused",
            transport="mcp",
            default_namespace=namespace,
            timeout=config.timeout,
            headers=server.headers,
            mcp_protocol_version=server.mcp_protocol_version,
        )
        await client.init()
        clients[namespace] = client

    await asyncio.gather(
        *[
            _init_one(ns, srv)
            for ns, srv in config.servers.items()
        ]
    )

    return MultiAAPClient(clients)
