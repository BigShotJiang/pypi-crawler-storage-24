"""Framework-agnostic adapter for ManifestSkill trigger detection + prompt injection.

Port of ``packages/bootstrap/src/skill-adapter.ts``.
Works with any LLM orchestration layer (CopilotKit, LangGraph, plain HTTP, etc.).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

from .manifest.types import ManifestSkill


class ManifestSkillAdapter(Protocol):
    """Typed protocol for skill adapter (structural subtyping)."""

    def detect_triggers(self, conversation_text: str) -> list[ManifestSkill]: ...
    def resolve_instruction(self, skill: ManifestSkill) -> str: ...
    def build_skill_system_prompt(self, user_message: str, base_prompt: str) -> str: ...


class _SkillAdapterImpl:
    """Concrete implementation bound to a skill list."""

    __slots__ = ("_skills",)

    def __init__(self, skills: list[ManifestSkill]) -> None:
        self._skills = skills

    def detect_triggers(self, conversation_text: str) -> list[ManifestSkill]:
        """Return skills whose ``autoInvoke.triggers`` match (case-insensitive substring)."""
        lower = conversation_text.lower()
        activated: list[ManifestSkill] = []
        for s in self._skills:
            triggers: list[str] = []
            if s.auto_invoke and s.auto_invoke.triggers:
                triggers = s.auto_invoke.triggers
            elif hasattr(s, "triggers") and isinstance(getattr(s, "triggers", None), list):
                triggers = getattr(s, "triggers")
            if any(t.lower() in lower for t in triggers):
                activated.append(s)
        return activated

    def resolve_instruction(self, skill: ManifestSkill) -> str:
        """Resolve instruction string — handles plain string and inline-object shapes."""
        inst = skill.instruction
        if isinstance(inst, str):
            return inst
        if isinstance(inst, dict):
            return inst.get("inline", "")
        return ""

    def build_skill_system_prompt(self, user_message: str, base_prompt: str) -> str:
        """Append activated skill instructions to *base_prompt*. Returns unmodified if none match."""
        activated = self.detect_triggers(user_message)
        if not activated:
            return base_prompt

        parts = [
            f"## Skill: {s.name}\n{self.resolve_instruction(s)}"
            for s in activated
        ]
        injected = "\n\n".join(parts)
        return f"{base_prompt}\n\n## Active Skills\n{injected}"


def create_manifest_skill_adapter(skills: list[ManifestSkill]) -> _SkillAdapterImpl:
    """Create a :class:`ManifestSkillAdapter` bound to the provided skill list.

    Example::

        adapter = create_manifest_skill_adapter(manifest.spec.skills or [])
        system_prompt = adapter.build_skill_system_prompt(user_message, agent_base_prompt)
    """
    return _SkillAdapterImpl(skills)
