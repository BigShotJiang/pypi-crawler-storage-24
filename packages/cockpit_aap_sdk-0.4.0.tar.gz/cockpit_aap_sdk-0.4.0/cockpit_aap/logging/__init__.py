"""Structured JSON logging for AAP SDK."""
from .structured import emit_log

__all__ = ["emit_log"]
