"""Structured JSON logger — emits one JSON line per log to stdout.

OTEL trace context is auto-extracted when available (optional dependency).
Toggle format via AAP_LOG_FORMAT env var: "json" (default) or "text".
"""
import json
import os
import sys
from datetime import datetime, timezone


def _get_otel_context() -> tuple[str, str]:
    """Try to extract traceId and spanId from active OTEL span. Returns ("", "") if unavailable."""
    try:
        from opentelemetry import trace

        span = trace.get_current_span()
        ctx = span.get_span_context()
        if ctx and ctx.trace_id != 0:
            return (
                format(ctx.trace_id, "032x"),
                format(ctx.span_id, "016x"),
            )
    except Exception:
        pass
    return ("", "")


def _emit_text_log(
    level: str, service: str, message: str,
    tenant_id: str, agent_id: str, token_count: int, cost_usd: float,
) -> None:
    """Emit a human-readable text log line to stdout."""
    parts = [f"[{level}]", f"[{service}]", message]
    if tenant_id:
        parts.append(f"tenant={tenant_id}")
    if agent_id:
        parts.append(f"agent={agent_id}")
    if token_count:
        parts.append(f"tokens={token_count}")
    if cost_usd:
        parts.append(f"cost=${cost_usd:.4f}")
    print(" ".join(parts), flush=True)


# Mapping from kwarg name to JSON key for optional fields
_OPTIONAL_FIELDS: list[tuple[str, str]] = [
    ("trace_id", "traceId"),
    ("span_id", "spanId"),
    ("tenant_id", "tenantId"),
    ("agent_id", "agentId"),
    ("kind", "kind"),
    ("model", "model"),
    ("request_id", "requestId"),
    ("user_id", "userId"),
]


def _build_json_entry(
    level: str, message: str, service: str, module: str,
    trace_id: str, span_id: str, tenant_id: str, agent_id: str,
    kind: str, model: str, request_id: str, user_id: str,
    token_count: int, cost_usd: float, error: str, duration_ms: float,
    extra: dict[str, object],
) -> dict[str, object]:
    """Build the JSON log entry dict with only truthy optional fields."""
    if not trace_id:
        trace_id, span_id = _get_otel_context()

    entry: dict[str, object] = {
        "ts": datetime.now(timezone.utc).isoformat(),
        "level": level,
        "message": message,
        "service": service,
        "module": module,
    }

    # Add optional string fields via lookup table
    local_vals = {
        "trace_id": trace_id, "span_id": span_id,
        "tenant_id": tenant_id, "agent_id": agent_id,
        "kind": kind, "model": model,
        "request_id": request_id, "user_id": user_id,
    }
    for py_name, json_key in _OPTIONAL_FIELDS:
        val = local_vals[py_name]
        if val:
            entry[json_key] = val

    if token_count:
        entry["tokenCount"] = token_count
    if cost_usd is not None and cost_usd > 0:
        entry["costUsd"] = cost_usd
    if error:
        entry["error"] = error
    if duration_ms:
        entry["durationMs"] = duration_ms

    for k, v in extra.items():
        entry[k] = v

    return entry


def emit_log(
    level: str,
    message: str,
    *,
    service: str,
    module: str,
    trace_id: str = "",
    span_id: str = "",
    tenant_id: str = "",
    agent_id: str = "",
    kind: str = "",
    model: str = "",
    request_id: str = "",
    user_id: str = "",
    token_count: int = 0,
    cost_usd: float = 0.0,
    error: str = "",
    duration_ms: float = 0.0,
    **extra: object,
) -> None:
    """Emit a structured log line to stdout."""
    fmt = os.environ.get("AAP_LOG_FORMAT", "json").lower()

    if fmt == "text":
        _emit_text_log(level, service, message, tenant_id, agent_id, token_count, cost_usd)
        return

    entry = _build_json_entry(
        level, message, service, module,
        trace_id, span_id, tenant_id, agent_id,
        kind, model, request_id, user_id,
        token_count, cost_usd, error, duration_ms, extra,
    )
    print(json.dumps(entry, default=str), file=sys.stdout, flush=True)
