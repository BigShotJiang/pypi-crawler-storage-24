"""AAP Graph — Manifest linking and semantic proximity engine.

Port of ``@ruinosus/aap-graph`` (TypeScript).

Provides:
- ``build_graph`` / ``build_graph_from_manifests`` — graph construction
- ``find_neighbors`` / ``search_graph`` / ``get_graph_stats`` — queries
- ``to_mermaid`` / ``serialize_graph`` — serialization
- ``extract_features`` — manifest feature extraction
- Similarity: ``cosine_similarity``, ``jaccard_similarity``, ``artifact_similarity``
"""

from cockpit_aap.graph.types import (
    ManifestNode,
    ManifestEdge,
    ManifestFeatures,
    ManifestGraph,
    SimilarityBreakdown,
    ScoreWeights,
    GraphConfig,
    NeighborResult,
    GraphSearchResult,
    GraphStats,
)
from cockpit_aap.graph.features import extract_features
from cockpit_aap.graph.similarity import (
    cosine_similarity,
    jaccard_similarity,
    artifact_similarity,
    compute_similarity,
    compute_score,
    resolve_weights,
)
from cockpit_aap.graph.graph import (
    build_graph,
    build_graph_from_manifests,
    find_neighbors,
    search_graph,
    get_graph_stats,
    serialize_graph,
    to_mermaid,
)
from cockpit_aap.graph.semantic import (
    build_semantic_graph,
    semantic_search_manifests,
)

__all__ = [
    # Types
    "ManifestNode",
    "ManifestEdge",
    "ManifestFeatures",
    "ManifestGraph",
    "SimilarityBreakdown",
    "ScoreWeights",
    "GraphConfig",
    "NeighborResult",
    "GraphSearchResult",
    "GraphStats",
    # Features
    "extract_features",
    # Similarity
    "cosine_similarity",
    "jaccard_similarity",
    "artifact_similarity",
    "compute_similarity",
    "compute_score",
    "resolve_weights",
    # Graph
    "build_graph",
    "build_graph_from_manifests",
    "find_neighbors",
    "search_graph",
    "get_graph_stats",
    "serialize_graph",
    "to_mermaid",
    # Semantic (sentence-transformers convenience)
    "build_semantic_graph",
    "semantic_search_manifests",
]
