"""Feature extraction from manifests for graph analysis.

Port of ``packages/graph/src/features.ts``.
"""

from __future__ import annotations

from typing import Any

from cockpit_aap.graph.types import ManifestFeatures


import re as _re


def _unique(items: list[str]) -> list[str]:
    """Remove duplicates preserving order."""
    seen: set[str] = set()
    result: list[str] = []
    for item in items:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def _sc(key: str) -> str:
    """Convert camelCase to snake_case."""
    return _re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", key).lower()


def _dg(d: dict, key: str, default: Any = None) -> Any:
    """Get from dict trying both camelCase and snake_case."""
    if key in d:
        return d[key]
    alt = _sc(key)
    if alt in d:
        return d[alt]
    return default


def _safe_get(obj: Any, *keys: str, default: Any = None) -> Any:
    """Safe nested dict access."""
    current = obj
    for key in keys:
        if isinstance(current, dict):
            current = current.get(key)
        else:
            return default
        if current is None:
            return default
    return current


def extract_features(manifest: Any) -> ManifestFeatures:
    """Extract features from a Manifest for graph analysis and similarity computation.

    Works with both dict and dataclass-style manifests.
    """
    # Always deep-convert to ensure nested typed objects become dicts
    return _extract_from_dict(_manifest_to_dict(manifest))


def _manifest_to_dict(m: Any) -> dict:
    """Recursively convert manifest-like object to nested dict."""
    if isinstance(m, dict):
        return {k: _manifest_to_dict(v) for k, v in m.items()}
    if isinstance(m, (list, tuple)):
        return [_manifest_to_dict(item) for item in m]  # type: ignore[return-value]
    if hasattr(m, "__dict__") and not isinstance(m, (str, int, float, bool)):
        return {k: _manifest_to_dict(v) for k, v in vars(m).items()}
    return m


def _extract_from_dict(manifest: dict) -> ManifestFeatures:
    parts: list[str] = []
    agent_ids: list[str] = []
    tool_names: list[str] = []
    artifact_keys: list[str] = []
    connection_ids: list[str] = []
    skill_ids: list[str] = []
    command_ids: list[str] = []
    hook_events: list[str] = []

    metadata = _dg(manifest, "metadata") or {}
    spec = _dg(manifest, "spec") or {}

    # Module identity
    display_name = _dg(metadata, "displayName") or _dg(metadata, "name", "")
    description = _dg(metadata, "description", "")
    group = _dg(metadata, "group")
    parts.append(display_name)
    parts.append(description)
    if group:
        parts.append(f"group: {group}")

    # Agents
    for agent in _dg(spec, "agents") or []:
        aid = _dg(agent, "id", "")
        if aid:
            agent_ids.append(aid)
        name = _dg(agent, "name", "")
        desc = _dg(agent, "description", "")
        parts.append(f"agent {name}: {desc}")
        objective = _dg(agent, "objective")
        if objective:
            parts.append(objective)
        instruction = _dg(agent, "instruction", "")
        if instruction:
            parts.append(instruction[:500])
        for tool in _dg(agent, "tools") or []:
            tool_names.append(tool)

    # Artifacts
    for artifact in _dg(spec, "artifacts") or []:
        key = _dg(artifact, "key", "")
        if key:
            artifact_keys.append(key)
        desc = _dg(artifact, "description")
        if desc:
            parts.append(desc)

    # Connections
    for conn in _dg(spec, "connections") or []:
        cid = _dg(conn, "id", "")
        if cid:
            connection_ids.append(cid)
        desc = _dg(conn, "description")
        if desc:
            parts.append(desc)

    # Skills
    for skill in _dg(spec, "skills") or []:
        sid = _dg(skill, "id", "")
        if sid:
            skill_ids.append(sid)
        name = _dg(skill, "name", "")
        desc = _dg(skill, "description", "")
        parts.append(f"skill {name}: {desc}")

    # Commands
    for cmd in _dg(spec, "commands") or []:
        cid = _dg(cmd, "id", "")
        if cid:
            command_ids.append(cid)
        name = _dg(cmd, "name", "")
        desc = _dg(cmd, "description", "")
        parts.append(f"command {name}: {desc}")

    # Hooks
    for hook in _dg(spec, "hooks") or []:
        event = _dg(hook, "event", "")
        if event:
            hook_events.append(event)
        desc = _dg(hook, "description")
        if desc:
            parts.append(desc)

    # Tags
    labels = _dg(spec, "labels") or {}
    tags = _dg(labels, "tags") or []
    if tags:
        parts.append(f"tags: {', '.join(tags)}")

    # Theme presets
    theme = _dg(spec, "theme") or {}
    theme_presets = list((_dg(theme, "presets") or {}).keys())

    # Locales
    i18n = _dg(spec, "i18n") or {}
    default_locale = _dg(i18n, "defaultLocale")
    locales = list((_dg(i18n, "locales") or {}).keys())

    # Recognition
    recognition = _dg(spec, "recognition") or {}
    for badge in _dg(recognition, "badges") or []:
        parts.append(f"badge: {_dg(badge, 'name', '')}")

    # Personas
    personas = _dg(spec, "personas") or {}
    for p in _dg(personas, "definitions") or []:
        parts.append(f"persona {_dg(p, 'displayName', '')}: {_dg(p, 'description', '')}")

    return ManifestFeatures(
        text_corpus="\n".join(p for p in parts if p),
        agent_ids=_unique(agent_ids),
        tool_names=_unique(tool_names),
        artifact_keys=_unique(artifact_keys),
        connection_ids=_unique(connection_ids),
        skill_ids=_unique(skill_ids),
        command_ids=_unique(command_ids),
        hook_events=_unique(hook_events),
        tags=_unique(tags),
        theme_presets=theme_presets,
        default_locale=default_locale,
        locales=locales,
    )
