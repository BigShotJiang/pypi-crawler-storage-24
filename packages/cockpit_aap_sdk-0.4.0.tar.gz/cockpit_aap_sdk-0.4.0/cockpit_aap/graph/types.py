"""Graph types — nodes, edges, breakdown, configuration.

Port of ``packages/graph/src/types.ts``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class ManifestFeatures:
    """Extracted features from a manifest for similarity computation."""

    text_corpus: str = ""
    agent_ids: list[str] = field(default_factory=list)
    tool_names: list[str] = field(default_factory=list)
    artifact_keys: list[str] = field(default_factory=list)
    connection_ids: list[str] = field(default_factory=list)
    skill_ids: list[str] = field(default_factory=list)
    command_ids: list[str] = field(default_factory=list)
    hook_events: list[str] = field(default_factory=list)
    tags: list[str] = field(default_factory=list)
    theme_presets: list[str] = field(default_factory=list)
    default_locale: str | None = None
    locales: list[str] = field(default_factory=list)


@dataclass
class SimilarityBreakdown:
    """Detailed breakdown of similarity between two modules."""

    semantic: float | None = None
    shared_tools: float = 0.0
    shared_artifacts: float = 0.0
    shared_connections: float = 0.0
    shared_tags: float = 0.0
    same_group: bool = False
    locale_overlap: float = 0.0


@dataclass
class ManifestEdge:
    """An edge in the manifest graph — link between two modules."""

    source: str
    target: str
    score: float
    breakdown: SimilarityBreakdown


@dataclass
class ManifestNode:
    """A node in the manifest graph — one per module."""

    id: str
    name: str
    description: str
    version: str
    group: str | None = None
    manifest: Any = None  # Manifest dict
    manifest_dir: str = ""
    features: ManifestFeatures = field(default_factory=ManifestFeatures)
    embedding: list[float] | None = None


@dataclass
class ManifestGraph:
    """The full manifest graph with nodes and edges."""

    nodes: list[ManifestNode] = field(default_factory=list)
    edges: list[ManifestEdge] = field(default_factory=list)
    built_at: str = ""
    has_embeddings: bool = False


@dataclass
class ScoreWeights:
    """Weights for each similarity dimension."""

    semantic: float = 0.0
    shared_tools: float = 0.0
    shared_artifacts: float = 0.0
    shared_connections: float = 0.0
    shared_tags: float = 0.0
    same_group: float = 0.0
    locale_overlap: float = 0.0


@dataclass
class GraphConfig:
    """Configuration for building the manifest graph."""

    min_score: float = 0.1
    embedding_adapter: Any | None = None  # EmbeddingPort
    weights: ScoreWeights | None = None


@dataclass
class NeighborResult:
    """Result from finding neighbors of a module."""

    module_id: str
    neighbors: list[dict[str, Any]] = field(default_factory=list)
    # Each neighbor: {module_id, module_name, score, breakdown}


@dataclass
class GraphSearchResult:
    """Result from searching across the graph."""

    query: str
    matches: list[dict[str, Any]] = field(default_factory=list)
    # Each match: {module_id, module_name, score}


@dataclass
class GraphStats:
    """Graph statistics."""

    node_count: int = 0
    edge_count: int = 0
    avg_similarity: float = 0.0
    clusters: list[list[str]] = field(default_factory=list)
    hubs: list[dict[str, Any]] = field(default_factory=list)
    # Each hub: {module_id, edge_count}
