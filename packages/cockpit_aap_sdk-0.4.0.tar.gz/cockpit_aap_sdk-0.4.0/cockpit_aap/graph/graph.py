"""Graph builder — construct and query manifest graphs.

Port of ``packages/graph/src/graph.ts``.
"""

from __future__ import annotations

import json
import re
from collections import defaultdict
from datetime import datetime, timezone
from typing import Any

from cockpit_aap.graph.features import extract_features
from cockpit_aap.graph.similarity import (
    compute_similarity,
    compute_score,
    cosine_similarity,
)
from cockpit_aap.graph.types import (
    GraphConfig,
    GraphSearchResult,
    GraphStats,
    ManifestEdge,
    ManifestGraph,
    ManifestNode,
    NeighborResult,
)
from cockpit_aap.manifest.scanner import scan_manifest


def _snake(key: str) -> str:
    """Convert camelCase to snake_case (e.g. displayName → display_name)."""
    return re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", key).lower()


# ---------------------------------------------------------------------------
# Build Graph
# ---------------------------------------------------------------------------


async def build_graph(
    manifest_dirs: list[str],
    config: GraphConfig | None = None,
) -> ManifestGraph:
    """Build a manifest graph from an array of manifest directories.

    Example::

        from cockpit_aap.graph import build_graph
        graph = await build_graph([".aap/my-module", ".aap/other"])
    """
    cfg = config or GraphConfig()
    adapter = cfg.embedding_adapter
    has_embeddings = adapter is not None

    # 1. Build nodes
    nodes: list[ManifestNode] = []
    for d in manifest_dirs:
        try:
            manifest = scan_manifest(d)
            m = manifest if isinstance(manifest, dict) else vars(manifest)
            metadata = m.get("metadata") or {}
            # metadata may be a typed object (ManifestMetadata) or a dict
            _mg = (
                metadata.get
                if isinstance(metadata, dict)
                else lambda k, d=None: getattr(metadata, _snake(k), d)
            )
            features = extract_features(m)
            nodes.append(
                ManifestNode(
                    id=_mg("name", ""),
                    name=_mg("displayName", None) or _mg("display_name", None) or _mg("name", ""),
                    description=_mg("description", ""),
                    version=_mg("version", ""),
                    group=_mg("group", None),
                    manifest=m,
                    manifest_dir=d,
                    features=features,
                )
            )
        except Exception:
            pass  # skip invalid

    # 2. Compute embeddings (batch)
    if adapter and nodes:
        texts = [n.features.text_corpus for n in nodes]
        embeddings = await adapter.embed(texts)
        for i, node in enumerate(nodes):
            if i < len(embeddings):
                node.embedding = embeddings[i]

    # 3. Build edges
    return _build_edges(nodes, cfg, has_embeddings)


async def build_graph_from_manifests(
    manifests: list[dict[str, Any]],
    config: GraphConfig | None = None,
) -> ManifestGraph:
    """Build graph from pre-loaded manifests (no filesystem access).

    Each item should be ``{"manifest": dict, "manifest_dir": str}``.
    """
    cfg = config or GraphConfig()
    adapter = cfg.embedding_adapter
    has_embeddings = adapter is not None

    nodes: list[ManifestNode] = []
    for entry in manifests:
        m = entry.get("manifest", {})
        manifest_dir = entry.get("manifest_dir", "")
        if isinstance(m, dict):
            metadata = m.get("metadata") or {}
        else:
            metadata = getattr(m, "metadata", {}) or {}
            m = vars(m) if hasattr(m, "__dict__") else {}

        features = extract_features(m)
        nodes.append(
            ManifestNode(
                id=metadata.get("name", "") if isinstance(metadata, dict) else getattr(metadata, "name", ""),
                name=(metadata.get("displayName") or metadata.get("name", "")) if isinstance(metadata, dict) else (getattr(metadata, "displayName", None) or getattr(metadata, "name", "")),
                description=metadata.get("description", "") if isinstance(metadata, dict) else getattr(metadata, "description", ""),
                version=metadata.get("version", "") if isinstance(metadata, dict) else getattr(metadata, "version", ""),
                group=metadata.get("group") if isinstance(metadata, dict) else getattr(metadata, "group", None),
                manifest=m,
                manifest_dir=manifest_dir,
                features=features,
            )
        )

    if adapter and nodes:
        texts = [n.features.text_corpus for n in nodes]
        embeddings = await adapter.embed(texts)
        for i, node in enumerate(nodes):
            if i < len(embeddings):
                node.embedding = embeddings[i]

    return _build_edges(nodes, cfg, has_embeddings)


def _build_edges(
    nodes: list[ManifestNode],
    cfg: GraphConfig,
    has_embeddings: bool,
) -> ManifestGraph:
    """Compute pairwise edges and assemble the graph."""
    min_score = cfg.min_score
    edges: list[ManifestEdge] = []

    for i in range(len(nodes)):
        for j in range(i + 1, len(nodes)):
            breakdown = compute_similarity(nodes[i], nodes[j], has_embeddings)
            score = compute_score(breakdown, cfg.weights, has_embeddings)
            if score >= min_score:
                edges.append(
                    ManifestEdge(
                        source=nodes[i].id,
                        target=nodes[j].id,
                        score=score,
                        breakdown=breakdown,
                    )
                )

    edges.sort(key=lambda e: e.score, reverse=True)

    return ManifestGraph(
        nodes=nodes,
        edges=edges,
        built_at=datetime.now(timezone.utc).isoformat(),
        has_embeddings=has_embeddings,
    )


# ---------------------------------------------------------------------------
# Graph Queries
# ---------------------------------------------------------------------------


def find_neighbors(
    graph: ManifestGraph,
    module_id: str,
    limit: int = 10,
) -> NeighborResult:
    """Find the nearest neighbors of a module within the graph."""
    neighbors: list[dict[str, Any]] = []
    for edge in graph.edges:
        neighbor_id: str | None = None
        if edge.source == module_id:
            neighbor_id = edge.target
        elif edge.target == module_id:
            neighbor_id = edge.source

        if neighbor_id:
            node = next((n for n in graph.nodes if n.id == neighbor_id), None)
            if node:
                neighbors.append(
                    {
                        "module_id": neighbor_id,
                        "module_name": node.name,
                        "score": edge.score,
                        "breakdown": edge.breakdown,
                    }
                )

    return NeighborResult(
        module_id=module_id,
        neighbors=neighbors[:limit],
    )


async def search_graph(
    graph: ManifestGraph,
    query: str,
    adapter: Any | None = None,
    limit: int = 10,
) -> GraphSearchResult:
    """Search the graph using text.

    Uses semantic search if adapter is provided and graph has embeddings,
    otherwise falls back to keyword matching.
    """
    if adapter and graph.has_embeddings:
        matches = await _semantic_search(graph, query, adapter)
    else:
        matches = _keyword_search(graph, query)

    matches.sort(key=lambda m: m["score"], reverse=True)
    return GraphSearchResult(query=query, matches=matches[:limit])


async def _semantic_search(
    graph: ManifestGraph,
    query: str,
    adapter: Any,
) -> list[dict[str, Any]]:
    embeddings = await adapter.embed([query])
    if not embeddings:
        return []
    query_embedding = embeddings[0]
    matches: list[dict[str, Any]] = []
    for node in graph.nodes:
        if node.embedding:
            score = cosine_similarity(query_embedding, node.embedding)
            matches.append({"module_id": node.id, "module_name": node.name, "score": score})
    return matches


def _keyword_search(
    graph: ManifestGraph,
    query: str,
) -> list[dict[str, Any]]:
    tokens = query.lower().split()
    if not tokens:
        return []
    matches: list[dict[str, Any]] = []
    for node in graph.nodes:
        corpus = node.features.text_corpus.lower()
        hits = sum(1 for t in tokens if t in corpus)
        if hits > 0:
            matches.append(
                {"module_id": node.id, "module_name": node.name, "score": hits / len(tokens)}
            )
    return matches


def get_graph_stats(graph: ManifestGraph) -> GraphStats:
    """Compute statistics about the graph."""
    node_count = len(graph.nodes)
    edge_count = len(graph.edges)
    avg_sim = (
        sum(e.score for e in graph.edges) / edge_count if edge_count > 0 else 0.0
    )

    clusters = _find_clusters(graph, 0.3)

    # Hub detection
    edge_counts: dict[str, int] = defaultdict(int)
    for edge in graph.edges:
        edge_counts[edge.source] += 1
        edge_counts[edge.target] += 1

    hubs = sorted(edge_counts.items(), key=lambda x: x[1], reverse=True)[:5]
    hub_list = [{"module_id": mid, "edge_count": cnt} for mid, cnt in hubs]

    return GraphStats(
        node_count=node_count,
        edge_count=edge_count,
        avg_similarity=avg_sim,
        clusters=clusters,
        hubs=hub_list,
    )


def _find_clusters(graph: ManifestGraph, threshold: float) -> list[list[str]]:
    """Find connected components using union-find on edges above threshold."""
    parent: dict[str, str] = {}

    def find(x: str) -> str:
        if x not in parent:
            parent[x] = x
        while parent[x] != x:
            parent[x] = parent[parent[x]]  # path compression
            x = parent[x]
        return x

    def union(a: str, b: str) -> None:
        pa, pb = find(a), find(b)
        if pa != pb:
            parent[pa] = pb

    for node in graph.nodes:
        parent[node.id] = node.id

    for edge in graph.edges:
        if edge.score >= threshold:
            union(edge.source, edge.target)

    groups: dict[str, list[str]] = defaultdict(list)
    for node in graph.nodes:
        root = find(node.id)
        groups[root].append(node.id)

    return [cluster for cluster in groups.values() if len(cluster) > 1]


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


def serialize_graph(graph: ManifestGraph) -> str:
    """Serialize graph to JSON (strips manifests to keep output small)."""
    serializable = {
        "nodes": [
            {
                "id": n.id,
                "name": n.name,
                "description": n.description,
                "version": n.version,
                "group": n.group,
                "manifest_dir": n.manifest_dir,
                "features": {
                    "text_corpus": n.features.text_corpus[:200] + "...",
                    "agent_ids": n.features.agent_ids,
                    "tool_names": n.features.tool_names,
                    "artifact_keys": n.features.artifact_keys,
                    "tags": n.features.tags,
                },
            }
            for n in graph.nodes
        ],
        "edges": [
            {
                "source": e.source,
                "target": e.target,
                "score": round(e.score, 4),
            }
            for e in graph.edges
        ],
        "built_at": graph.built_at,
        "has_embeddings": graph.has_embeddings,
    }
    return json.dumps(serializable, indent=2, ensure_ascii=False)


def to_mermaid(graph: ManifestGraph, min_score: float = 0.2) -> str:
    """Export graph as a Mermaid diagram string."""

    def sanitize(id: str) -> str:
        return re.sub(r"[^a-zA-Z0-9_\-]", "_", id)

    lines = ["graph LR"]

    for node in graph.nodes:
        label = node.name.replace('"', "'")
        lines.append(f'  {sanitize(node.id)}["{label}"]')

    for edge in graph.edges:
        if edge.score >= min_score:
            pct = round(edge.score * 100)
            lines.append(f"  {sanitize(edge.source)} -->|{pct}%| {sanitize(edge.target)}")

    return "\n".join(lines)
