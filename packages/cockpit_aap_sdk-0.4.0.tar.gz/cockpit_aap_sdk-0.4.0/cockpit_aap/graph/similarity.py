"""Similarity engine — structural and semantic similarity between manifests.

Port of ``packages/graph/src/similarity.ts``.
"""

from __future__ import annotations

import math

from cockpit_aap.graph.types import (
    ManifestNode,
    SimilarityBreakdown,
    ScoreWeights,
)

# -- Default Weights --

_DEFAULT_WITH_SEMANTIC = ScoreWeights(
    semantic=0.40,
    shared_tools=0.20,
    shared_artifacts=0.10,
    shared_connections=0.10,
    shared_tags=0.10,
    same_group=0.05,
    locale_overlap=0.05,
)

_DEFAULT_NO_SEMANTIC = ScoreWeights(
    semantic=0.0,
    shared_tools=0.30,
    shared_artifacts=0.15,
    shared_connections=0.15,
    shared_tags=0.20,
    same_group=0.10,
    locale_overlap=0.10,
)


def resolve_weights(
    weights: ScoreWeights | None = None,
    has_embeddings: bool = False,
) -> ScoreWeights:
    """Resolve weights with defaults based on embedding availability."""
    defaults = _DEFAULT_WITH_SEMANTIC if has_embeddings else _DEFAULT_NO_SEMANTIC
    if weights is None:
        return defaults
    return ScoreWeights(
        semantic=weights.semantic if weights.semantic else defaults.semantic,
        shared_tools=weights.shared_tools if weights.shared_tools else defaults.shared_tools,
        shared_artifacts=weights.shared_artifacts if weights.shared_artifacts else defaults.shared_artifacts,
        shared_connections=weights.shared_connections if weights.shared_connections else defaults.shared_connections,
        shared_tags=weights.shared_tags if weights.shared_tags else defaults.shared_tags,
        same_group=weights.same_group if weights.same_group else defaults.same_group,
        locale_overlap=weights.locale_overlap if weights.locale_overlap else defaults.locale_overlap,
    )


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors. Returns 0–1 (clamped)."""
    if len(a) != len(b) or len(a) == 0:
        return 0.0

    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    denom = norm_a * norm_b

    if denom == 0:
        return 0.0

    return max(0.0, dot / denom)


def jaccard_similarity(a: list[str], b: list[str]) -> float:
    """Jaccard similarity: |A ∩ B| / |A ∪ B|. Returns 0–1."""
    if not a and not b:
        return 0.0

    set_a = set(a)
    set_b = set(b)
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)

    return intersection / union if union > 0 else 0.0


def artifact_similarity(a: list[str], b: list[str]) -> float:
    """Artifact key similarity — prefix-based matching.

    Combines direct Jaccard (30%) + suffix Jaccard (70%).
    """
    if not a and not b:
        return 0.0

    def extract_suffix(key: str) -> str:
        dot_idx = key.find(".")
        return key[dot_idx + 1 :] if dot_idx >= 0 else key

    suffix_a = [s for s in (extract_suffix(k) for k in a) if s]
    suffix_b = [s for s in (extract_suffix(k) for k in b) if s]

    direct = jaccard_similarity(a, b)
    suffix = jaccard_similarity(suffix_a, suffix_b)

    return direct * 0.3 + suffix * 0.7


def compute_similarity(
    a: ManifestNode,
    b: ManifestNode,
    has_embeddings: bool = False,
) -> SimilarityBreakdown:
    """Compute similarity breakdown between two manifest nodes."""
    semantic_val = None
    if has_embeddings and a.embedding and b.embedding:
        semantic_val = cosine_similarity(a.embedding, b.embedding)

    return SimilarityBreakdown(
        semantic=semantic_val,
        shared_tools=jaccard_similarity(a.features.tool_names, b.features.tool_names),
        shared_artifacts=artifact_similarity(a.features.artifact_keys, b.features.artifact_keys),
        shared_connections=jaccard_similarity(a.features.connection_ids, b.features.connection_ids),
        shared_tags=jaccard_similarity(a.features.tags, b.features.tags),
        same_group=bool(a.group and b.group and a.group == b.group),
        locale_overlap=jaccard_similarity(a.features.locales, b.features.locales),
    )


def compute_score(
    breakdown: SimilarityBreakdown,
    weights: ScoreWeights | None = None,
    has_embeddings: bool | None = None,
) -> float:
    """Compute a weighted score from a similarity breakdown."""
    if has_embeddings is None:
        has_embeddings = breakdown.semantic is not None
    w = resolve_weights(weights, has_embeddings)

    score = 0.0
    score += (breakdown.semantic or 0.0) * w.semantic
    score += breakdown.shared_tools * w.shared_tools
    score += breakdown.shared_artifacts * w.shared_artifacts
    score += breakdown.shared_connections * w.shared_connections
    score += breakdown.shared_tags * w.shared_tags
    score += (1.0 if breakdown.same_group else 0.0) * w.same_group
    score += breakdown.locale_overlap * w.locale_overlap

    return min(1.0, max(0.0, score))
