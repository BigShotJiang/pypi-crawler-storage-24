"""Semantic graph helpers — convenience wrappers using sentence-transformers.

These functions create a ``SentenceTransformerEmbeddingAdapter`` under the hood,
so the caller never needs to construct the adapter manually.

Requirements: ``pip install sentence-transformers``

Usage::

    from cockpit_aap.graph import build_semantic_graph, semantic_search_manifests

    # Build a graph with local embeddings (no API key!)
    graph = await build_semantic_graph([".aap/mod-a", ".aap/mod-b"])

    # Search with semantic understanding
    results = await semantic_search_manifests(graph, "busca semântica")
"""

from __future__ import annotations

from typing import Any

from cockpit_aap.graph.graph import build_graph, search_graph
from cockpit_aap.graph.types import (
    GraphConfig,
    GraphSearchResult,
    ManifestGraph,
    ScoreWeights,
)


# Default weights when semantic embeddings are available
_DEFAULT_SEMANTIC_WEIGHTS = ScoreWeights(
    semantic=0.40,
    shared_tools=0.20,
    shared_artifacts=0.10,
    shared_connections=0.10,
    shared_tags=0.10,
    same_group=0.05,
    locale_overlap=0.05,
)


async def build_semantic_graph(
    manifest_dirs: list[str],
    *,
    model: str = "all-MiniLM-L6-v2",
    min_score: float = 0.1,
    weights: ScoreWeights | None = None,
    device: str | None = None,
    batch_size: int = 32,
    normalize: bool = True,
) -> ManifestGraph:
    """Build a manifest graph using local sentence-transformers embeddings.

    This is a convenience wrapper around :func:`build_graph` that automatically
    creates a ``SentenceTransformerEmbeddingAdapter``.

    Parameters
    ----------
    manifest_dirs:
        Paths to ``.aap/<module>/`` directories containing ``manifest.yaml``.
    model:
        HuggingFace model name.  Default ``all-MiniLM-L6-v2`` (384-dim, EN).
        For multilingual use ``paraphrase-multilingual-MiniLM-L12-v2``.
    min_score:
        Minimum similarity score to create an edge.
    weights:
        Custom score weights.  Defaults to semantic-heavy weights (0.40 semantic).
    device:
        PyTorch device.  ``None`` → auto (cuda > mps > cpu).
    batch_size:
        Batch size for model.encode().
    normalize:
        L2-normalize embeddings.

    Returns
    -------
    ManifestGraph with ``has_embeddings=True``.
    """
    from cockpit_aap.adapters.sentence_transformer_embedding import (
        create_sentence_transformer_embedding,
    )

    adapter = create_sentence_transformer_embedding(
        model=model,
        device=device,
        batch_size=batch_size,
        normalize=normalize,
    )

    config = GraphConfig(
        min_score=min_score,
        embedding_adapter=adapter,
        weights=weights or _DEFAULT_SEMANTIC_WEIGHTS,
    )

    return await build_graph(manifest_dirs, config)


async def semantic_search_manifests(
    graph: ManifestGraph,
    query: str,
    *,
    model: str = "all-MiniLM-L6-v2",
    limit: int = 10,
    adapter: Any | None = None,
    device: str | None = None,
) -> GraphSearchResult:
    """Search manifests using semantic similarity.

    If the graph was built with embeddings, uses the same embedding space for
    the query.  Otherwise falls back to keyword search.

    Parameters
    ----------
    graph:
        A previously built ``ManifestGraph`` (ideally from :func:`build_semantic_graph`).
    query:
        Natural language query (e.g. ``"módulo de feedback"``).
    model:
        Model for encoding the query.  Should match the model used to build the graph.
    limit:
        Maximum results to return.
    adapter:
        Reuse an existing adapter.  If ``None``, one is created automatically.
    device:
        PyTorch device for the query adapter.
    """
    if adapter is None and graph.has_embeddings:
        from cockpit_aap.adapters.sentence_transformer_embedding import (
            create_sentence_transformer_embedding,
        )

        adapter = create_sentence_transformer_embedding(
            model=model,
            device=device,
        )

    return await search_graph(graph, query, adapter=adapter, limit=limit)
