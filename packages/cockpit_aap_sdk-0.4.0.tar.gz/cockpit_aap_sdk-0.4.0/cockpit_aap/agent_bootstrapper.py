"""Granular single-agent bootstrap: fetch-or-create with retry logic.

Port of ``packages/bootstrap/src/agent-bootstrapper.ts``.
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

DEFAULT_TYPE_NAME = "Standard"
DEFAULT_MODEL = "azure-gpt-4o"
# Known type UUID fallback — from cockpit-mcp-portal
KNOWN_SUPERVISOR_TYPE_ID = "a7c9d077-e2f9-5f4f-bf1e-1c7d9f8a0a5c"

# Cached type_id resolved from list_agent_types
_cached_type_id: str | None = None


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class AgentDefinition:
    """Definition for an agent to bootstrap."""

    name: str
    default_instruction: str
    description: str = ""
    objective: str = ""
    model: str = DEFAULT_MODEL
    type_id: str | None = None


@dataclass
class ResolvedAgentGranular:
    """Result of bootstrapping a single agent (granular mode).

    Named differently from ``bootstrap.ResolvedAgent`` to avoid collision.
    """

    name: str
    instruction: str
    source: str  # "server" | "created" | "default-fallback"
    id: str = ""
    description: str | None = None
    error: str | None = None


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _escape_regex(s: str) -> str:
    return re.escape(s)


def _extract_agent_list(content: Any) -> list[dict[str, Any]]:
    """Extract agent list from various response formats."""
    if isinstance(content, list):
        return content
    if isinstance(content, dict):
        for key in ("utility_agents", "agents", "results"):
            if isinstance(content.get(key), list):
                return content[key]
        if content.get("id") or content.get("utility_agent_id"):
            return [content]
    return []


def _extract_type_list(content: Any) -> list[dict[str, Any]]:
    """Extract agent type list from various response formats."""
    if isinstance(content, list):
        return content
    if isinstance(content, dict):
        for key in ("agent_types", "utility_agent_types", "types", "results"):
            if isinstance(content.get(key), list):
                return content[key]
    return []


async def _find_existing_agent(
    sdk: Any,
    namespace: str,
    definition: AgentDefinition,
    verbose: bool = False,
) -> dict[str, Any] | None:
    """Search for an existing agent and fetch full details if found.

    Returns ``{name, id, instruction, description}`` or ``None``.
    """
    if verbose:
        logger.info("[bootstrap] Searching agent: %s", definition.name)

    result = await sdk.call_tool(namespace, "search_utility_agents", {
        "name_pattern": f"^{_escape_regex(definition.name)}$",
        "search_type": "name",
    })

    agents = _extract_agent_list(result.get("content"))
    if not agents:
        return None

    agent_id = str(agents[0].get("id") or agents[0].get("utility_agent_id") or "")
    return await _fetch_full_agent(sdk, namespace, definition, agent_id, verbose)


async def _fetch_full_agent(
    sdk: Any,
    namespace: str,
    definition: AgentDefinition,
    agent_id: str,
    verbose: bool = False,
) -> dict[str, Any]:
    """Fetch full agent details; fall back to search result data on failure."""
    try:
        if verbose:
            logger.info('[bootstrap] Fetching full agent "%s" (id: %s)', definition.name, agent_id)
        result = await sdk.call_tool(namespace, "get_full_utility_agent", {
            "utility_agent_id": agent_id,
        })
        full = result.get("content", {})
        raw_instruction = full.get("instruction") or full.get("content") or definition.default_instruction
        if isinstance(raw_instruction, str):
            instruction = raw_instruction
        elif isinstance(raw_instruction, dict):
            instruction = str(raw_instruction)
        elif raw_instruction is None:
            instruction = ""
        else:
            instruction = str(raw_instruction)
        description = full.get("description") or definition.description or ""
        return {"name": definition.name, "id": agent_id, "instruction": instruction, "description": description}
    except Exception:
        return {
            "name": definition.name,
            "id": agent_id,
            "instruction": definition.default_instruction,
            "description": definition.description,
        }


async def _resolve_type_id(
    sdk: Any,
    namespace: str,
    type_name: str = DEFAULT_TYPE_NAME,
    verbose: bool = False,
) -> str:
    """Resolve type_id by calling list_agent_types. Falls back to known UUID."""
    global _cached_type_id
    if _cached_type_id:
        return _cached_type_id

    try:
        result = await sdk.call_tool(namespace, "list_agent_types", {})
        types = _extract_type_list(result.get("content"))

        # Find by name (case-insensitive)
        for t in types:
            if (t.get("name") or "").lower() == type_name.lower():
                tid = str(t.get("id") or t.get("type_id") or t.get("utility_agent_type_id") or "")
                if tid:
                    _cached_type_id = tid
                    if verbose:
                        logger.info('[bootstrap] Resolved type_id "%s" → %s', type_name, tid)
                    return tid

        # First available type as fallback
        if types:
            first = types[0]
            tid = str(first.get("id") or first.get("type_id") or first.get("utility_agent_type_id") or "")
            if tid:
                _cached_type_id = tid
                if verbose:
                    logger.info('[bootstrap] No exact type match for "%s", using first: %s', type_name, tid)
                return tid
    except Exception as e:
        if verbose:
            logger.info("[bootstrap] list_agent_types failed: %s", e)

    return KNOWN_SUPERVISOR_TYPE_ID


async def _try_create_agent(
    sdk: Any,
    namespace: str,
    definition: AgentDefinition,
    verbose: bool = False,
) -> None:
    """Try v2.0 format first, then fall back to v1.0 with type_id."""
    base_payload = {
        "name": definition.name,
        "instruction": definition.default_instruction,
        "description": definition.description,
        "objective": definition.objective,
        "model": definition.model,
    }

    # Explicit type_id → v1.0 directly
    if definition.type_id:
        await sdk.call_tool(namespace, "create_utility_agent", {
            **base_payload,
            "type_id": definition.type_id,
        })
        return

    # Try v2.0 format first
    try:
        if verbose:
            logger.info("[bootstrap] Trying v2.0 create (type: 'standard')")
        result = await sdk.call_tool(namespace, "create_utility_agent", {
            **base_payload,
            "type": "standard",
            "agent_status": "Active",
        })
        content = result.get("content", {})
        if isinstance(content, dict) and content.get("success") is False:
            msg = content.get("message", "create returned success: false")
            raise RuntimeError(msg)
        return
    except Exception as e:
        if verbose:
            logger.info("[bootstrap] v2.0 create failed: %s", e)

    # v1.0 fallback
    type_id = await _resolve_type_id(sdk, namespace, DEFAULT_TYPE_NAME, verbose)
    if verbose:
        logger.info("[bootstrap] Trying v1.0 create (type_id: %s)", type_id)
    await sdk.call_tool(namespace, "create_utility_agent", {
        **base_payload,
        "type_id": type_id,
    })


async def _search_after_create(
    sdk: Any,
    namespace: str,
    name: str,
    verbose: bool = False,
) -> dict[str, Any] | None:
    """Retry search after create with exponential backoff: 300, 600, 1200, 2400ms."""
    delays = [0.3, 0.6, 1.2, 2.4]

    for attempt, delay in enumerate(delays, 1):
        await asyncio.sleep(delay)
        try:
            result = await sdk.call_tool(namespace, "search_utility_agents", {
                "name_pattern": f"^{_escape_regex(name)}$",
                "search_type": "name",
            })
            agents = _extract_agent_list(result.get("content"))
            if agents:
                if verbose:
                    logger.info("[bootstrap] Found created agent on attempt %d", attempt)
                return agents[0]
        except Exception as e:
            if verbose:
                logger.info("[bootstrap] Search failed (attempt %d): %s", attempt, e)

        if verbose:
            logger.info("[bootstrap] Agent not found yet, retrying... (attempt %d/%d)", attempt, len(delays))

    if verbose:
        logger.info("[bootstrap] Could not find created agent after %d retries", len(delays))
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def bootstrap_agent(
    sdk: Any,
    namespace: str,
    definition: AgentDefinition,
    *,
    verbose: bool = False,
) -> ResolvedAgentGranular:
    """Bootstrap a single agent: fetch from server or create with default.

    Flow:
        1. Search by exact name
        2. If found → get_full_utility_agent → ``{source: "server"}``
        3. If not found → create (v2.0 → v1.0 fallback) → retry search → ``{source: "created"}``
        4. On error → ``{source: "default-fallback"}``

    Parameters
    ----------
    sdk:
        The SDK client (or LocalSdk).
    namespace:
        MCP namespace (e.g. ``"agents"``).
    definition:
        Agent definition with name, default instruction, etc.
    verbose:
        Log progress to logger.
    """
    # Step 1: Search for existing
    try:
        found = await _find_existing_agent(sdk, namespace, definition, verbose)
        if found:
            return ResolvedAgentGranular(
                name=found["name"],
                id=found["id"],
                instruction=found["instruction"],
                description=found.get("description"),
                source="server",
            )
    except Exception:
        pass  # Not found or error → proceed to create

    # Step 2: Create with default
    try:
        if verbose:
            logger.info("[bootstrap] Creating agent: %s", definition.name)
        await _try_create_agent(sdk, namespace, definition, verbose)

        created = await _search_after_create(sdk, namespace, definition.name, verbose)
        agent_id = ""
        if created:
            agent_id = str(created.get("id") or created.get("utility_agent_id") or "")

        if verbose:
            logger.info('[bootstrap] Created agent "%s" (id: %s)', definition.name, agent_id)
        return ResolvedAgentGranular(
            name=definition.name,
            id=agent_id,
            instruction=definition.default_instruction,
            description=definition.description,
            source="created",
        )
    except Exception as e:
        message = str(e)
        if verbose:
            logger.info('[bootstrap] Fallback for agent "%s": %s', definition.name, message)
        return ResolvedAgentGranular(
            name=definition.name,
            instruction=definition.default_instruction,
            description=definition.description,
            source="default-fallback",
            error=message,
        )


def reset_type_id_cache() -> None:
    """Reset cached type_id (for testing)."""
    global _cached_type_id
    _cached_type_id = None
