"""MCP transport — JSON-RPC 2.0 over HTTP (standard MCP protocol)."""

from __future__ import annotations

import json
from typing import Any

import httpx

from cockpit_aap.mcp_types import (
    PromptArgument,
    PromptMessage,
    PromptResult,
    PromptSchema,
    ResourceContents,
    ResourceSchema,
    ResourceTemplate,
)
from cockpit_aap.transport import Transport, TransportContext


class McpTransport(Transport):
    """JSON-RPC 2.0 transport for direct MCP server communication."""

    def __init__(
        self,
        default_namespace: str = "default",
        protocol_version: str = "2024-11-05",
    ) -> None:
        self._default_namespace = default_namespace
        self._protocol_version = protocol_version
        self._session_id: str | None = None
        self._request_id = 0
        self._http = httpx.AsyncClient()

    @property
    def session_id(self) -> str | None:
        return self._session_id

    async def init(self, ctx: TransportContext) -> list[dict[str, Any]]:
        # Step 1: initialize handshake
        await self._rpc(ctx, "initialize", {
            "protocolVersion": self._protocol_version,
            "capabilities": {},
            "clientInfo": {"name": "cockpit-aap-sdk-python", "version": "0.1.0"},
        })

        # Step 2: send initialized notification
        await self._notify(ctx, "notifications/initialized", {})

        # Step 3: discover tools
        result = await self._rpc(ctx, "tools/list", {})
        tools_raw: list[dict[str, Any]] = result.get("tools", [])  # type: ignore[union-attr]

        # Map flat tool list into schemas with default namespace
        return [
            {
                "name": t.get("name", ""),
                "description": t.get("description", ""),
                "inputSchema": t.get("inputSchema", {}),
                "namespace": self._default_namespace,
            }
            for t in tools_raw
        ]

    async def call_tool(
        self,
        ctx: TransportContext,
        namespace: str,
        tool_name: str,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        result = await self._rpc(ctx, "tools/call", {
            "name": tool_name,
            "arguments": args,
        })
        result_dict: dict[str, Any] = result  # type: ignore[assignment]
        content_blocks: list[dict[str, Any]] = result_dict.get("content", [])
        is_error: bool = result_dict.get("isError", False)

        content = self._extract_content(content_blocks)
        return {"content": content, "isError": is_error}

    async def close(self) -> None:
        await self._http.aclose()

    # ------------------------------------------------------------------
    # MCP Prompts
    # ------------------------------------------------------------------

    async def list_prompts(self, ctx: TransportContext) -> list[PromptSchema]:
        """List available prompts from the MCP server."""
        try:
            result = await self._rpc(ctx, "prompts/list", {})
            prompts_raw: list[dict[str, Any]] = result.get("prompts", [])  # type: ignore[union-attr]
            return [
                PromptSchema(
                    name=p.get("name", ""),
                    description=p.get("description"),
                    arguments=[
                        PromptArgument(
                            name=a.get("name", ""),
                            description=a.get("description"),
                            required=a.get("required"),
                        )
                        for a in p.get("arguments", [])
                    ],
                    namespace=self._default_namespace,
                )
                for p in prompts_raw
            ]
        except Exception:
            return []

    async def get_prompt(
        self,
        ctx: TransportContext,
        namespace: str,
        name: str,
        args: dict[str, str] | None = None,
    ) -> PromptResult:
        """Execute a prompt by name."""
        result = await self._rpc(ctx, "prompts/get", {
            "name": name,
            "arguments": args or {},
        })
        result_dict: dict[str, Any] = result  # type: ignore[assignment]
        messages_raw = result_dict.get("messages", [])
        return PromptResult(
            description=result_dict.get("description"),
            messages=[
                PromptMessage(
                    role=m.get("role", "user"),
                    content=m.get("content", {}),
                )
                for m in messages_raw
            ],
        )

    # ------------------------------------------------------------------
    # MCP Resources
    # ------------------------------------------------------------------

    async def list_resources(self, ctx: TransportContext) -> list[ResourceSchema]:
        """List available resources from the MCP server."""
        try:
            result = await self._rpc(ctx, "resources/list", {})
            resources_raw: list[dict[str, Any]] = result.get("resources", [])  # type: ignore[union-attr]
            return [
                ResourceSchema(
                    uri=r.get("uri", ""),
                    name=r.get("name", ""),
                    description=r.get("description"),
                    mime_type=r.get("mimeType"),
                    namespace=self._default_namespace,
                )
                for r in resources_raw
            ]
        except Exception:
            return []

    async def read_resource(
        self,
        ctx: TransportContext,
        namespace: str,
        uri: str,
    ) -> list[ResourceContents]:
        """Read the contents of an MCP resource."""
        result = await self._rpc(ctx, "resources/read", {"uri": uri})
        result_dict: dict[str, Any] = result  # type: ignore[assignment]
        contents_raw = result_dict.get("contents", [])
        return [
            ResourceContents(
                uri=c.get("uri", uri),
                mime_type=c.get("mimeType"),
                text=c.get("text"),
                blob=c.get("blob"),
            )
            for c in contents_raw
        ]

    async def list_resource_templates(
        self, ctx: TransportContext
    ) -> list[ResourceTemplate]:
        """List available resource templates from the MCP server."""
        try:
            result = await self._rpc(ctx, "resources/templates/list", {})
            templates_raw: list[dict[str, Any]] = result.get("resourceTemplates", [])  # type: ignore[union-attr]
            return [
                ResourceTemplate(
                    uri_template=t.get("uriTemplate", ""),
                    name=t.get("name", ""),
                    description=t.get("description"),
                    mime_type=t.get("mimeType"),
                    namespace=self._default_namespace,
                )
                for t in templates_raw
            ]
        except Exception:
            return []

    def _extract_content(self, blocks: list[dict[str, Any]]) -> Any:
        if not blocks:
            return None

        # Single text block: try JSON parse, fall back to raw string
        if len(blocks) == 1 and blocks[0].get("type") == "text":
            text = blocks[0].get("text", "")
            try:
                return json.loads(text)
            except (json.JSONDecodeError, TypeError):
                return text

        # Multiple blocks: extract each
        extracted = []
        for b in blocks:
            if b.get("type") == "text":
                try:
                    extracted.append(json.loads(b.get("text", "")))
                except (json.JSONDecodeError, TypeError):
                    extracted.append(b.get("text", ""))
            else:
                extracted.append(b)
        return extracted

    async def _rpc(
        self, ctx: TransportContext, method: str, params: dict[str, Any]
    ) -> Any:
        self._request_id += 1
        body = {
            "jsonrpc": "2.0",
            "id": self._request_id,
            "method": method,
            "params": params,
        }

        headers = await ctx.get_headers()
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "application/json, text/event-stream"
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id

        r = await self._http.post(
            ctx.endpoint,
            headers=headers,
            content=json.dumps(body),
            timeout=ctx.timeout,
        )

        sid = r.headers.get("mcp-session-id")
        if sid:
            self._session_id = sid

        if not r.is_success:
            raise httpx.HTTPStatusError(
                f"MCP Transport Error [{r.status_code}]: {r.text}",
                request=r.request,
                response=r,
            )

        data = r.json()
        if "error" in data:
            err = data["error"]
            raise RuntimeError(
                f"MCP JSON-RPC Error [{err['code']}]: {err['message']}"
            )

        return data.get("result")

    async def _notify(
        self, ctx: TransportContext, method: str, params: dict[str, Any]
    ) -> None:
        body = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
        }

        headers = await ctx.get_headers()
        headers["Content-Type"] = "application/json"
        headers["Accept"] = "application/json, text/event-stream"
        if self._session_id:
            headers["Mcp-Session-Id"] = self._session_id

        r = await self._http.post(
            ctx.endpoint,
            headers=headers,
            content=json.dumps(body),
            timeout=ctx.timeout,
        )

        sid = r.headers.get("mcp-session-id")
        if sid:
            self._session_id = sid

        if not r.is_success and r.status_code != 202:
            raise httpx.HTTPStatusError(
                f"MCP Transport Error [{r.status_code}]: {r.text}",
                request=r.request,
                response=r,
            )
