"""REST transport — MetaMCP OpenAPI / REST API."""

from __future__ import annotations

from typing import Any

import httpx

from cockpit_aap.transport import Transport, TransportContext


class RestTransport(Transport):
    """HTTP REST transport for MetaMCP."""

    def __init__(self) -> None:
        self._http = httpx.AsyncClient()

    async def init(self, ctx: TransportContext) -> list[dict[str, Any]]:
        headers = await ctx.get_headers()
        r = await self._http.get(
            f"{ctx.endpoint}/api/tools",
            headers=headers,
            timeout=ctx.timeout,
        )
        r.raise_for_status()
        return r.json()  # type: ignore[no-any-return]

    async def call_tool(
        self,
        ctx: TransportContext,
        namespace: str,
        tool_name: str,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        headers = await ctx.get_headers()
        r = await self._http.post(
            f"{ctx.endpoint}/api/tools/{namespace}/{tool_name}",
            headers=headers,
            json={"arguments": args},
            timeout=ctx.timeout,
        )
        r.raise_for_status()
        return r.json()  # type: ignore[no-any-return]

    async def close(self) -> None:
        await self._http.aclose()
