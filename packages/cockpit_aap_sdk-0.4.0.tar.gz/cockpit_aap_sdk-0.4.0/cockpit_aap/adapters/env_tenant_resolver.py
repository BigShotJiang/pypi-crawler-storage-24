"""EnvTenantResolver — resolve tenant from environment variables."""
from __future__ import annotations

import os
from typing import Any

from cockpit_aap.ports.tenant_resolver import TenantContext

_DEFAULT_LICENSE_ENV = "COCKPIT_LICENSE_ID"
_DEFAULT_NAMESPACE_ENV = "COCKPIT_NAMESPACE_ID"
_DEFAULT_USER_ENV = "COCKPIT_USER_ID"
_DEFAULT_ROLES_ENV = "COCKPIT_ROLES"


class EnvTenantResolver:
    """Reads tenant identity from environment variables.

    Useful for single-tenant deployments (workers, CLIs, scripts) where
    each process serves a single tenant configured via env vars.

    Raises ``ValueError`` if required env vars are missing.
    """

    def __init__(
        self,
        license_env: str = _DEFAULT_LICENSE_ENV,
        namespace_env: str = _DEFAULT_NAMESPACE_ENV,
        user_env: str = _DEFAULT_USER_ENV,
        roles_env: str = _DEFAULT_ROLES_ENV,
    ) -> None:
        self._license_env = license_env
        self._namespace_env = namespace_env
        self._user_env = user_env
        self._roles_env = roles_env

    async def resolve(self, request: Any) -> TenantContext:
        license_id = os.environ.get(self._license_env)
        if not license_id:
            raise ValueError(f"Missing tenant env: {self._license_env}")

        namespace_id = os.environ.get(self._namespace_env)
        if not namespace_id:
            raise ValueError(f"Missing tenant env: {self._namespace_env}")

        user_id = os.environ.get(self._user_env)
        roles_raw = os.environ.get(self._roles_env)
        roles: list[str] = [r.strip() for r in roles_raw.split(",") if r.strip()] if roles_raw else []

        return TenantContext(
            license_id=license_id,
            namespace_id=namespace_id,
            user_id=user_id or None,
            roles=roles,
        )


def create_env_tenant_resolver(
    license_env: str = _DEFAULT_LICENSE_ENV,
    namespace_env: str = _DEFAULT_NAMESPACE_ENV,
    user_env: str = _DEFAULT_USER_ENV,
    roles_env: str = _DEFAULT_ROLES_ENV,
) -> EnvTenantResolver:
    """Create an EnvTenantResolver with the given env var names."""
    return EnvTenantResolver(
        license_env=license_env,
        namespace_env=namespace_env,
        user_env=user_env,
        roles_env=roles_env,
    )
