"""Compile ConformancePolicy YAML to OPA Rego policy."""
from __future__ import annotations
import json
import re
from typing import Any

SEVERITY_MAP = {
    "required": "error",
    "forbidden": "error",
    "recommended": "warning",
    "info": "info",
}

INVERSE_OPS = {">=": "<", ">": "<=", "<=": ">", "<": ">=", "==": "!="}


def compile_to_rego(
    id: str,
    applies_to: str,
    requirements: list[dict[str, Any]],
) -> str:
    pkg_name = id.replace("-", "_")
    lines = [
        f"package aap.conformance.{pkg_name}",
        "",
        "import rego.v1",
        "",
    ]

    for req in requirements:
        lines.extend(_compile_requirement(req))
        lines.append("")

    return "\n".join(lines)


def _compile_requirement(req: dict[str, Any]) -> list[str]:
    severity = SEVERITY_MAP.get(req["severity"], "info")
    violation = json.dumps({
        "rule": req["id"],
        "severity": severity,
        "message": req.get("message", f"{req['field']} is {req['severity']}"),
    })

    lines = ["violations contains v if {"]

    # exemptWhen guards
    for expr in req.get("exemptWhen", []):
        lines.append(f"    {_compile_exempt_guard(expr)}")

    if req.get("exemptWhen"):
        lines.append("")

    # Field check
    if req["severity"] == "forbidden":
        lines.append(f"    input.manifest.{req['field']}")
    elif req.get("condition"):
        lines.extend(_compile_condition(req["field"], req["condition"]))
    else:
        lines.append(f"    not input.manifest.{req['field']}")

    lines.append(f"    v := {violation}")
    lines.append("}")

    return lines


def _compile_exempt_guard(expr: str) -> str:
    eq = re.match(r"^(\w[\w.]*)\s*==\s*'([^']*)'$", expr)
    if eq:
        return f'input.manifest.{eq.group(1)} != "{eq.group(2)}"'

    neq = re.match(r"^(\w[\w.]*)\s*!=\s*'([^']*)'$", expr)
    if neq:
        return f'input.manifest.{neq.group(1)} == "{neq.group(2)}"'

    return f"# unsupported exemptWhen: {expr}"


def _compile_condition(field: str, condition: str) -> list[str]:
    m = re.match(r"^length\s*(>=|>|<=|<|==)\s*(\d+)$", condition)
    if m:
        op, n = m.group(1), m.group(2)
        var_name = field.split(".")[-1]
        return [
            f"    {var_name} := input.manifest.{field}",
            f"    count({var_name}) {INVERSE_OPS[op]} {n}",
        ]
    return [f"    not input.manifest.{field}"]
