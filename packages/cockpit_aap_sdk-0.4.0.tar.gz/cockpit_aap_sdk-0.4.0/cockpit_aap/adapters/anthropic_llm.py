"""Anthropic LLMPort adapter — optional peer dep: pip install anthropic."""

from __future__ import annotations

from cockpit_aap.ports import LLMMessage, LLMOptions, LLMResponse, LLMUsage


def create_anthropic_llm(
    api_key: str,
    model: str = "claude-sonnet-4-6",
) -> "AnthropicLLMAdapter":
    return AnthropicLLMAdapter(api_key=api_key, model=model)


class AnthropicLLMAdapter:
    def __init__(self, api_key: str, model: str) -> None:
        self._api_key = api_key
        self._default_model = model

    async def complete(
        self,
        messages: list[LLMMessage],
        options: LLMOptions | None = None,
    ) -> LLMResponse:
        try:
            import anthropic  # optional peer dep
        except ImportError as exc:
            raise ImportError(
                "anthropic is required for AnthropicLLMAdapter. Run: pip install anthropic"
            ) from exc

        client = anthropic.AsyncAnthropic(api_key=self._api_key)
        model = (options.model if options else None) or self._default_model
        max_tokens = (options.max_tokens if options else None) or 4096

        system = next((m.content for m in messages if m.role == "system"), None)
        user_messages = [
            {"role": m.role, "content": m.content}
            for m in messages if m.role != "system"
        ]

        response = await client.messages.create(
            model=model,
            max_tokens=max_tokens,
            system=system,
            messages=user_messages,
        )
        content = response.content[0].text if response.content and response.content[0].type == "text" else ""
        usage = LLMUsage(
            prompt_tokens=response.usage.input_tokens,
            completion_tokens=response.usage.output_tokens,
            total_tokens=response.usage.input_tokens + response.usage.output_tokens,
        )
        return LLMResponse(content=content, model=response.model, usage=usage)
