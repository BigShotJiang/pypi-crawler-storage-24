# packages/py/cockpit_aap/adapters/pg_pool.py
"""AsyncConnectionLike — Protocol mínimo compatível com asyncpg.Pool.

O utilizador instala asyncpg; o SDK apenas exige este contrato.

Equivalente Python de PoolLike (TypeScript, packages/bootstrap/src/adapters/postgres-pool.ts).

Example:
    import asyncpg
    pool = await asyncpg.create_pool(dsn=os.environ["DATABASE_URL"])
    # asyncpg.Pool satisfaz AsyncConnectionLike automaticamente
"""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class AsyncConnectionLike(Protocol):
    """Interface mínima de um pool asyncpg (ou conexão individual)."""

    async def execute(self, query: str, *args: Any, timeout: float | None = None) -> str: ...

    async def fetch(
        self, query: str, *args: Any, timeout: float | None = None
    ) -> list[Any]: ...

    async def fetchrow(
        self, query: str, *args: Any, timeout: float | None = None
    ) -> Any | None: ...

    async def fetchval(
        self, query: str, *args: Any, column: int = 0, timeout: float | None = None
    ) -> Any: ...
