"""Policy engine factory with auto-detection and graceful fallback.

Detection order (Python defaults to CLI over WASM — opa-wasm Python is less mature
than the JS SDK):

1. If ``preferred`` is set → use that adapter directly (raises if unavailable)
2. Auto-detect: CLI first (most reliable on Python), then WASM, then Noop
"""
from __future__ import annotations

import warnings
from typing import Literal

from cockpit_aap.ports.policy_engine import PolicyEnginePort

PolicyEngineType = Literal["cli", "wasm", "noop"]


async def create_policy_engine(
    preferred: PolicyEngineType | None = None,
) -> tuple[PolicyEnginePort, PolicyEngineType]:
    """Create a policy engine with auto-detection and fallback.

    Args:
        preferred: Force a specific engine type.  One of ``"cli"``, ``"wasm"``,
                   or ``"noop"``.  When ``None`` (default) the factory probes
                   available runtimes in order: CLI → WASM → Noop.

    Returns:
        A ``(engine, type_str)`` tuple where *engine* implements
        ``PolicyEnginePort`` and *type_str* is one of ``"cli"``, ``"wasm"``,
        or ``"noop"``.

    Note:
        Python defaults to CLI over WASM because the ``opa-wasm`` Python
        package is less mature than the JS SDK.
    """
    if preferred == "cli":
        from cockpit_aap.adapters.opa_cli_policy import OpaCliPolicyAdapter
        return OpaCliPolicyAdapter(), "cli"

    if preferred == "wasm":
        from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
        return OpaWasmPolicyAdapter(), "wasm"

    if preferred == "noop":
        from cockpit_aap.adapters.noop_policy import NoopPolicyAdapter
        return NoopPolicyAdapter(), "noop"

    # Auto-detect: CLI first for Python (more reliable than WASM)
    from cockpit_aap.adapters.opa_cli_policy import is_opa_available
    if await is_opa_available():
        from cockpit_aap.adapters.opa_cli_policy import OpaCliPolicyAdapter
        return OpaCliPolicyAdapter(), "cli"

    # Try WASM as secondary option
    try:
        import opa_wasm  # type: ignore[import]  # noqa: F401
        import shutil
        if shutil.which("opa"):
            from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
            return OpaWasmPolicyAdapter(), "wasm"
    except ImportError:
        pass

    # Noop fallback — policy validation disabled
    warnings.warn(
        "[governance] OPA not available (opa CLI not found, opa-wasm not installed) "
        "— policy validation is disabled. Install OPA: https://www.openpolicyagent.org/docs/latest/#1-download-opa",
        stacklevel=2,
    )
    from cockpit_aap.adapters.noop_policy import NoopPolicyAdapter
    return NoopPolicyAdapter(), "noop"
