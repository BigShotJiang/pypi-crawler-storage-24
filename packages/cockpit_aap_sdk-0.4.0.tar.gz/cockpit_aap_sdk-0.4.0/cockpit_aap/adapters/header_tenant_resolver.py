"""HeaderTenantResolver — resolve tenant from HTTP request headers."""
from __future__ import annotations

from typing import Any

from cockpit_aap.ports.tenant_resolver import TenantContext

_DEFAULT_LICENSE_HEADER = "x-cockpit-license-id"
_DEFAULT_NAMESPACE_HEADER = "x-cockpit-namespace-id"
_DEFAULT_USER_HEADER = "x-cockpit-user-id"
_DEFAULT_ROLES_HEADER = "x-cockpit-roles"


class HeaderTenantResolver:
    """Reads tenant identity from request headers.

    Raises ``ValueError`` if required headers are missing.
    """

    def __init__(
        self,
        license_header: str = _DEFAULT_LICENSE_HEADER,
        namespace_header: str = _DEFAULT_NAMESPACE_HEADER,
        user_header: str = _DEFAULT_USER_HEADER,
        roles_header: str = _DEFAULT_ROLES_HEADER,
    ) -> None:
        self._license_header = license_header
        self._namespace_header = namespace_header
        self._user_header = user_header
        self._roles_header = roles_header

    async def resolve(self, request: Any) -> TenantContext:
        headers = request.headers

        license_id = headers.get(self._license_header)
        if not license_id:
            raise ValueError(f"Missing tenant header: {self._license_header}")

        namespace_id = headers.get(self._namespace_header)
        if not namespace_id:
            raise ValueError(f"Missing tenant header: {self._namespace_header}")

        user_id = headers.get(self._user_header)
        roles_raw = headers.get(self._roles_header)
        roles: list[str] = [r.strip() for r in roles_raw.split(",") if r.strip()] if roles_raw else []

        return TenantContext(
            license_id=license_id,
            namespace_id=namespace_id,
            user_id=user_id or None,
            roles=roles,
        )


def create_header_tenant_resolver(
    license_header: str = _DEFAULT_LICENSE_HEADER,
    namespace_header: str = _DEFAULT_NAMESPACE_HEADER,
    user_header: str = _DEFAULT_USER_HEADER,
    roles_header: str = _DEFAULT_ROLES_HEADER,
) -> HeaderTenantResolver:
    """Create a HeaderTenantResolver with the given header names."""
    return HeaderTenantResolver(
        license_header=license_header,
        namespace_header=namespace_header,
        user_header=user_header,
        roles_header=roles_header,
    )
