"""FileSystemKnowledgeAdapter — in-memory keyword search over markdown files."""
from __future__ import annotations

import re
from collections import Counter
from pathlib import Path

from cockpit_aap.ports import KnowledgeDocument, KnowledgeResult, SearchOptions


class _Chunk:
    __slots__ = ("id", "doc_id", "content", "metadata", "terms")

    def __init__(
        self,
        id: str,
        doc_id: str,
        content: str,
        metadata: dict | None,
        terms: Counter,
    ):
        self.id = id
        self.doc_id = doc_id
        self.content = content
        self.metadata = metadata
        self.terms = terms


def _tokenize(text: str) -> list[str]:
    return re.sub(r"[^a-z0-9\s]", " ", text.lower()).split()


class FileSystemKnowledgeAdapter:
    def __init__(self, chunk_size: int = 800, overlap: int = 200):
        self._chunk_size = chunk_size
        self._overlap = overlap
        self._chunks: list[_Chunk] = []

    async def ingest(self, documents: list[KnowledgeDocument]) -> list[str]:
        ids: list[str] = []
        for doc in documents:
            content = doc.content
            if doc.metadata and "path" in doc.metadata:
                try:
                    content = Path(doc.metadata["path"]).read_text(encoding="utf-8")
                except OSError:
                    pass
            if not content:
                continue
            self._chunks.extend(self._split(content, doc.id, doc.metadata))
            ids.append(doc.id)
        return ids

    async def remove(self, ids: list[str]) -> None:
        s = set(ids)
        self._chunks = [c for c in self._chunks if c.doc_id not in s]

    async def search(
        self, query: str, options: SearchOptions | None = None
    ) -> list[KnowledgeResult]:
        opts = options or SearchOptions()
        qt = _tokenize(query)
        if not qt:
            return []
        scored = []
        for c in self._chunks:
            total = sum(c.terms.values()) or 1
            score = sum(c.terms.get(t, 0) / total for t in qt)
            if score > opts.min_score:
                scored.append((c, score))
        scored.sort(key=lambda x: x[1], reverse=True)
        return [
            KnowledgeResult(id=c.id, content=c.content, score=s, metadata=c.metadata)
            for c, s in scored[: opts.top_k]
        ]

    async def count(self) -> int:
        return len(self._chunks)

    def _split(self, text: str, doc_id: str, meta: dict | None) -> list[_Chunk]:
        chunks, start, n = [], 0, 0
        while start < len(text):
            end = min(start + self._chunk_size, len(text))
            content = text[start:end]
            chunks.append(
                _Chunk(
                    f"{doc_id}#chunk-{n}",
                    doc_id,
                    content,
                    meta,
                    Counter(_tokenize(content)),
                )
            )
            n += 1
            start = end - self._overlap
            if start >= len(text) - self._overlap:
                break
        return chunks


def create_filesystem_knowledge_adapter(
    chunk_size: int = 800, overlap: int = 200
) -> FileSystemKnowledgeAdapter:
    return FileSystemKnowledgeAdapter(chunk_size, overlap)
