"""CompositeTenantResolver + NoopTenantResolver.

CompositeTenantResolver tries each resolver in order and returns the first
successful result.  If all resolvers fail, raises ``ValueError``.

NoopTenantResolver always returns a ``_global`` tenant — useful for
single-tenant development and testing.
"""
from __future__ import annotations

from typing import Any

from cockpit_aap.ports.tenant_resolver import TenantContext, TenantResolverPort


class CompositeTenantResolver:
    """Tries each resolver in sequence, returning the first success.

    Raises ``ValueError("No resolver could resolve tenant")`` if every
    resolver raises ``ValueError`` (or any other exception).
    """

    def __init__(self, resolvers: list[Any]) -> None:
        if not resolvers:
            raise ValueError("CompositeTenantResolver requires at least one resolver")
        self._resolvers = resolvers

    async def resolve(self, request: Any) -> TenantContext:
        last_error: Exception | None = None
        for resolver in self._resolvers:
            try:
                return await resolver.resolve(request)
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                continue
        raise ValueError("No resolver could resolve tenant") from last_error


class NoopTenantResolver:
    """Always returns a ``_global`` tenant — for single-tenant / dev use."""

    async def resolve(self, request: Any) -> TenantContext:
        return TenantContext(license_id="_global", namespace_id="_global")


def create_composite_tenant_resolver(resolvers: list[Any]) -> CompositeTenantResolver:
    """Create a CompositeTenantResolver from a list of resolver instances."""
    return CompositeTenantResolver(resolvers)


def create_noop_tenant_resolver() -> NoopTenantResolver:
    """Create a NoopTenantResolver that always returns the ``_global`` tenant."""
    return NoopTenantResolver()
