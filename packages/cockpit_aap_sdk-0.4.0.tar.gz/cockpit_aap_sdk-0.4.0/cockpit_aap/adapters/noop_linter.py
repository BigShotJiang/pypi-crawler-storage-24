"""Noop LinterPort adapter for testing."""
from cockpit_aap.ports.linter import LintResult


class NoopLinterAdapter:
    async def lint(self, document: dict, options: dict | None = None) -> LintResult:
        return LintResult(score=100, max_score=100, grade="A")
