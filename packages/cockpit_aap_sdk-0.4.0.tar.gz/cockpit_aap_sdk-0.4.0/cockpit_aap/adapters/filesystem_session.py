"""Filesystem-backed SessionStorePort adapter — JSON files in a directory.

Port of ``packages/bootstrap/src/adapters/filesystem-session.ts``.

Each thread is stored as ``<dir>/<base64url-encoded-id>.json``.
Uses base64url encoding (no padding) for safe filenames with 1-to-1 mapping.
"""

from __future__ import annotations

import base64
import json
import os
import time
from typing import Any


class FilesystemSession:
    """SessionStorePort backed by JSON files in a directory.

    Parameters
    ----------
    dir_path:
        Directory where session files are stored.  Created on first write.
    """

    def __init__(self, dir_path: str) -> None:
        self._dir = dir_path

    # -- Private helpers --

    def _ensure_dir(self) -> None:
        os.makedirs(self._dir, exist_ok=True)

    @staticmethod
    def _encode(thread_id: str) -> str:
        """Encode thread_id to a base64url filename (no padding)."""
        return base64.urlsafe_b64encode(thread_id.encode("utf-8")).rstrip(b"=").decode("ascii")

    @staticmethod
    def _decode(filename: str) -> str:
        """Decode a base64url filename back to thread_id."""
        # Add padding back
        padded = filename + "=" * (-len(filename) % 4)
        return base64.urlsafe_b64decode(padded.encode("ascii")).decode("utf-8")

    def _file_path(self, thread_id: str) -> str:
        return os.path.join(self._dir, self._encode(thread_id) + ".json")

    # -- Public async API (SessionStorePort) --

    async def save(self, thread_id: str, state: Any) -> None:
        """Save or overwrite session *state* (JSON-serialisable)."""
        self._ensure_dir()
        with open(self._file_path(thread_id), "w", encoding="utf-8") as fh:
            json.dump(state, fh)

    async def load(self, thread_id: str) -> Any | None:
        """Load session state for *thread_id*, or ``None`` if missing."""
        try:
            with open(self._file_path(thread_id), encoding="utf-8") as fh:
                return json.load(fh)
        except (FileNotFoundError, json.JSONDecodeError):
            return None

    async def delete(self, thread_id: str) -> None:
        """Delete session for *thread_id*."""
        try:
            os.unlink(self._file_path(thread_id))
        except FileNotFoundError:
            pass

    async def list(self, prefix: str | None = None) -> list[str]:
        """List thread IDs, optionally filtered by *prefix*."""
        self._ensure_dir()
        thread_ids: list[str] = []
        for fname in os.listdir(self._dir):
            if not fname.endswith(".json"):
                continue
            try:
                tid = self._decode(fname[:-5])  # strip .json
            except Exception:
                continue
            thread_ids.append(tid)

        if prefix:
            thread_ids = [tid for tid in thread_ids if tid.startswith(prefix)]
        return thread_ids

    async def prune(self, ttl_ms: int = 3_600_000) -> int:
        """Delete sessions older than *ttl_ms*.  Returns number removed."""
        self._ensure_dir()
        cutoff = time.time() - (ttl_ms / 1000.0)
        removed = 0
        for fname in os.listdir(self._dir):
            if not fname.endswith(".json"):
                continue
            full = os.path.join(self._dir, fname)
            try:
                if os.path.getmtime(full) < cutoff:
                    os.unlink(full)
                    removed += 1
            except OSError:
                pass
        return removed

    def close(self) -> None:
        """No-op — included for adapter consistency."""


def create_filesystem_session(dir_path: str) -> FilesystemSession:
    """Factory helper — preferred API.

    Example::

        session = create_filesystem_session(".aap/sessions")
        await session.save("thread-1", {"messages": [...]})
        state = await session.load("thread-1")
    """
    return FilesystemSession(dir_path)
