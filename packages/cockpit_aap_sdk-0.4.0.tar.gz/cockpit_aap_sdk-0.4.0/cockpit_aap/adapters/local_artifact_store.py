"""JSON-file-backed artifact store for local/offline development.

Port of ``packages/bootstrap/src/local-artifact-store.ts``.
"""

from __future__ import annotations

import json
import os
from typing import Any

STORE_FILENAME = "state.json"


class LocalArtifactStore:
    """File-backed key-value store that persists to ``state.json``.

    Useful for local development without a running MCP server.

    Parameters
    ----------
    directory:
        Directory where ``state.json`` is stored.  Created on first write.
    """

    def __init__(self, directory: str) -> None:
        self._dir = directory
        self._file_path = os.path.join(directory, STORE_FILENAME)

    # -- Private --

    def _load(self) -> dict[str, str]:
        try:
            with open(self._file_path, encoding="utf-8") as fh:
                return json.load(fh)
        except FileNotFoundError:
            return {}

    def _save(self, state: dict[str, str]) -> None:
        os.makedirs(self._dir, exist_ok=True)
        with open(self._file_path, "w", encoding="utf-8") as fh:
            json.dump(state, fh, indent=2)

    # -- Public async API (matches TS) --

    async def read(self, key: str) -> str | None:
        """Read value for *key*, or ``None`` if missing."""
        state = self._load()
        return state.get(key)

    async def write(self, key: str, value: str) -> None:
        """Write *value* under *key*."""
        state = self._load()
        state[key] = value
        self._save(state)

    async def delete(self, key: str) -> None:
        """Delete *key* if it exists."""
        state = self._load()
        if key in state:
            del state[key]
            self._save(state)

    async def list(self) -> list[str]:
        """Return all stored keys."""
        return list(self._load().keys())


def create_local_artifact_store(directory: str) -> LocalArtifactStore:
    """Factory helper — preferred API."""
    return LocalArtifactStore(directory)
