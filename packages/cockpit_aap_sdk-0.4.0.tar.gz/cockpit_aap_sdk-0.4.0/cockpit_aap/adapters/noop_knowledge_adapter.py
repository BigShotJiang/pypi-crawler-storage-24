"""NoopKnowledgeAdapter — returns empty results. For testing."""
from __future__ import annotations

from cockpit_aap.ports import KnowledgeDocument, KnowledgeResult, SearchOptions


class NoopKnowledgeAdapter:
    async def ingest(self, documents: list[KnowledgeDocument]) -> list[str]:
        return [d.id for d in documents]

    async def remove(self, ids: list[str]) -> None:
        pass

    async def search(self, query: str, options: SearchOptions | None = None) -> list[KnowledgeResult]:
        return []

    async def count(self) -> int:
        return 0


def create_noop_knowledge_adapter() -> NoopKnowledgeAdapter:
    return NoopKnowledgeAdapter()
