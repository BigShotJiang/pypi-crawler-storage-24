# packages/py/cockpit_aap/adapters/tenant_postgres_manifest_source.py
"""TenantPostgresManifestSource — tenant-aware manifest storage with 3-level fallback chain.

Adds ``license_id`` and ``namespace_id`` columns to ``aap_manifests`` (v2 migration)
and resolves manifests using a 3-level fallback:

    1. Tenant-specific: license_id = tenant.license_id AND namespace_id = tenant.namespace_id
    2. License default: license_id = tenant.license_id AND namespace_id = '_global'
    3. Global:          license_id = '_global' AND namespace_id = '_global'
"""

from __future__ import annotations

from typing import Any

import yaml

from cockpit_aap.manifest.kind_registry import KindRegistry, kind_registry
from cockpit_aap.ports import ManifestEntry
from cockpit_aap.ports.tenant_resolver import TenantContext
from .pg_pool import AsyncConnectionLike

# Sentinel used when no tenant is provided — maps to the global slot.
_GLOBAL = TenantContext(license_id="_global", namespace_id="_global")


def _get_migrations(schema: str) -> list[str]:
    s = schema
    return [
        # v1 — initial schema (same as PostgresManifestSource)
        f"""
        CREATE TABLE IF NOT EXISTS {s}.aap_migrations (
            v          INTEGER PRIMARY KEY,
            applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE TABLE IF NOT EXISTS {s}.aap_manifests (
            id           TEXT NOT NULL,
            kind         TEXT NOT NULL DEFAULT 'Module',
            yaml_content TEXT NOT NULL,
            version      TEXT,
            created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY (id, kind)
        );
        CREATE INDEX IF NOT EXISTS aap_manifests_kind_idx
            ON {s}.aap_manifests (kind);
        INSERT INTO {s}.aap_migrations (v) VALUES (1) ON CONFLICT DO NOTHING;
        """,
        # v2 — add tenant columns + migrate existing rows to _global
        f"""
        ALTER TABLE {s}.aap_manifests
            ADD COLUMN IF NOT EXISTS license_id   TEXT NOT NULL DEFAULT '_global',
            ADD COLUMN IF NOT EXISTS namespace_id TEXT NOT NULL DEFAULT '_global';
        ALTER TABLE {s}.aap_manifests DROP CONSTRAINT IF EXISTS aap_manifests_pkey;
        ALTER TABLE {s}.aap_manifests
            ADD PRIMARY KEY (id, kind, license_id, namespace_id);
        CREATE INDEX IF NOT EXISTS aap_manifests_tenant_idx
            ON {s}.aap_manifests (license_id, namespace_id);
        INSERT INTO {s}.aap_migrations (v) VALUES (2) ON CONFLICT DO NOTHING;
        """,
    ]


class TenantPostgresManifestSource:
    """ManifestSourceProtocol + MigratableProtocol with per-tenant isolation.

    Resolves manifests via 3-level fallback chain when ``fallback_chain=True``
    (the default):

        1. Exact tenant match (license_id + namespace_id)
        2. License-level default (license_id, namespace_id='_global')
        3. Global default (license_id='_global', namespace_id='_global')

    Usage::

        source = create_tenant_postgres_source(pool)
        await source.setup()

        tenant = TenantContext(license_id="acme", namespace_id="prod")
        await source.save("my-module", "Module", manifest, tenant=tenant)
        loaded = await source.load("my-module", "Module", tenant=tenant)

    Without a tenant the manifest is stored/retrieved in the global slot::

        await source.save("shared-module", "Module", manifest)
        loaded = await source.load("shared-module", "Module")
    """

    def __init__(
        self,
        pool: AsyncConnectionLike,
        schema: str = "public",
        registry: KindRegistry = kind_registry,
        fallback_chain: bool = True,
    ) -> None:
        self._pool = pool
        self._schema = schema
        self._registry = registry
        self._fallback_chain = fallback_chain

    # ------------------------------------------------------------------
    # MigratableProtocol
    # ------------------------------------------------------------------

    async def setup(self) -> None:
        s = self._schema
        await self._pool.execute(f"""
            CREATE TABLE IF NOT EXISTS {s}.aap_migrations (
                v INTEGER PRIMARY KEY,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)
        current = await self._pool.fetchval(
            f"SELECT COALESCE(MAX(v), 0) FROM {s}.aap_migrations"
        )
        migrations = _get_migrations(s)
        for i in range(int(current), len(migrations)):
            await self._pool.execute(migrations[i])

    async def schema_version(self) -> int:
        try:
            val = await self._pool.fetchval(
                f"SELECT COALESCE(MAX(v), 0) FROM {self._schema}.aap_migrations"
            )
            return int(val)
        except Exception:
            return 0

    # ------------------------------------------------------------------
    # ManifestSourceProtocol
    # ------------------------------------------------------------------

    async def load(
        self,
        id: str,  # noqa: A002
        kind: str = "Module",
        tenant: TenantContext | None = None,
    ) -> Any:
        """Load a manifest, applying the 3-level fallback chain."""
        t = tenant or _GLOBAL
        s = self._schema

        # Level 1: exact tenant match
        row = await self._pool.fetchrow(
            f"SELECT yaml_content FROM {s}.aap_manifests"
            f" WHERE id = $1 AND kind = $2 AND license_id = $3 AND namespace_id = $4",
            id, kind, t.license_id, t.namespace_id,
        )
        if row is not None:
            return self._registry.parse_yaml(row["yaml_content"], kind)

        if not self._fallback_chain:
            raise ValueError(
                f"Manifest not found: {id!r} (kind={kind}, "
                f"license={t.license_id}, namespace={t.namespace_id})"
            )

        # Level 2: license-level default (only if namespace is not already _global)
        if t.namespace_id != "_global":
            row = await self._pool.fetchrow(
                f"SELECT yaml_content FROM {s}.aap_manifests"
                f" WHERE id = $1 AND kind = $2 AND license_id = $3 AND namespace_id = $4",
                id, kind, t.license_id, "_global",
            )
            if row is not None:
                return self._registry.parse_yaml(row["yaml_content"], kind)

        # Level 3: global default
        if t.license_id != "_global" or t.namespace_id != "_global":
            row = await self._pool.fetchrow(
                f"SELECT yaml_content FROM {s}.aap_manifests"
                f" WHERE id = $1 AND kind = $2 AND license_id = $3 AND namespace_id = $4",
                id, kind, "_global", "_global",
            )
            if row is not None:
                return self._registry.parse_yaml(row["yaml_content"], kind)

        raise ValueError(
            f"Manifest not found: {id!r} (kind={kind}) — no match at any fallback level"
        )

    async def save(
        self,
        id: str,  # noqa: A002
        kind: str,
        manifest: Any,
        tenant: TenantContext | None = None,
    ) -> None:
        """Persist a manifest for the given tenant slot (defaults to global)."""
        t = tenant or _GLOBAL
        yaml_content = yaml.dump(
            manifest if isinstance(manifest, dict) else vars(manifest),
            allow_unicode=True,
        )
        version: str | None = None
        if hasattr(manifest, "metadata") and hasattr(manifest.metadata, "version"):
            version = manifest.metadata.version
        elif isinstance(manifest, dict):
            version = manifest.get("metadata", {}).get("version")

        await self._pool.execute(
            f"""
            INSERT INTO {self._schema}.aap_manifests
                (id, kind, license_id, namespace_id, yaml_content, version, updated_at)
            VALUES ($1, $2, $3, $4, $5, $6, NOW())
            ON CONFLICT (id, kind, license_id, namespace_id)
            DO UPDATE SET yaml_content = EXCLUDED.yaml_content,
                          version = EXCLUDED.version,
                          updated_at = NOW()
            """,
            id, kind, t.license_id, t.namespace_id, yaml_content, version,
        )

    async def list(  # noqa: A002
        self,
        kind: str | None = None,
        tenant: TenantContext | None = None,
    ) -> list[ManifestEntry]:
        """List manifests, optionally filtered by kind and/or tenant."""
        t = tenant or _GLOBAL
        s = self._schema
        source_tag = f"postgres:{s}/{t.license_id}/{t.namespace_id}"

        if kind is not None:
            rows = await self._pool.fetch(
                f"SELECT id, kind, version FROM {s}.aap_manifests"
                f" WHERE kind = $1 AND license_id = $2 AND namespace_id = $3"
                f" ORDER BY id",
                kind, t.license_id, t.namespace_id,
            )
        else:
            rows = await self._pool.fetch(
                f"SELECT id, kind, version FROM {s}.aap_manifests"
                f" WHERE license_id = $1 AND namespace_id = $2"
                f" ORDER BY id",
                t.license_id, t.namespace_id,
            )
        return [
            ManifestEntry(
                id=row["id"],
                kind=row["kind"],
                version=row.get("version"),
                source=source_tag,
            )
            for row in rows
        ]


def create_tenant_postgres_source(
    pool: AsyncConnectionLike,
    schema: str = "public",
    registry: KindRegistry = kind_registry,
    fallback_chain: bool = True,
) -> TenantPostgresManifestSource:
    """Create a TenantPostgresManifestSource for the given asyncpg pool."""
    return TenantPostgresManifestSource(pool, schema, registry, fallback_chain)
