# packages/py/cockpit_aap/adapters/postgres_manifest_source.py
"""PostgresManifestSource — armazena manifests de qualquer kind em Postgres."""

from __future__ import annotations

from typing import Any

import yaml

from cockpit_aap.manifest.kind_registry import KindRegistry, kind_registry
from cockpit_aap.ports import ManifestEntry
from .pg_pool import AsyncConnectionLike


def _get_migrations(schema: str) -> list[str]:
    s = schema
    return [
        # v1 — schema inicial
        f"""
        CREATE TABLE IF NOT EXISTS {s}.aap_migrations (
            v          INTEGER PRIMARY KEY,
            applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE TABLE IF NOT EXISTS {s}.aap_manifests (
            id           TEXT NOT NULL,
            kind         TEXT NOT NULL DEFAULT 'Module',
            yaml_content TEXT NOT NULL,
            version      TEXT,
            created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            PRIMARY KEY (id, kind)
        );
        CREATE INDEX IF NOT EXISTS aap_manifests_kind_idx
            ON {s}.aap_manifests (kind);
        INSERT INTO {s}.aap_migrations (v) VALUES (1) ON CONFLICT DO NOTHING;
        """,
    ]


class PostgresManifestSource:
    """ManifestSourceProtocol + MigratableProtocol backed by PostgreSQL.

    Suporta todos os kinds registados no KindRegistry. Utilizadores podem
    registar custom kinds e usá-los transparentemente:

        from cockpit_aap.manifest.kind_registry import kind_registry
        kind_registry.register("Pipeline", parse_fn=parse_pipeline_yaml)

        source = create_postgres_manifest_source(pool)
        pipeline = await source.load("my-pipeline", "Pipeline")
    """

    def __init__(
        self,
        pool: AsyncConnectionLike,
        schema: str = "public",
        registry: KindRegistry = kind_registry,
    ) -> None:
        self._pool = pool
        self._schema = schema
        self._registry = registry

    async def setup(self) -> None:
        s = self._schema
        await self._pool.execute(f"""
            CREATE TABLE IF NOT EXISTS {s}.aap_migrations (
                v INTEGER PRIMARY KEY,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)
        current = await self._pool.fetchval(
            f"SELECT COALESCE(MAX(v), 0) FROM {s}.aap_migrations"
        )
        migrations = _get_migrations(s)
        for i in range(int(current), len(migrations)):
            await self._pool.execute(migrations[i])

    async def schema_version(self) -> int:
        try:
            val = await self._pool.fetchval(
                f"SELECT COALESCE(MAX(v), 0) FROM {self._schema}.aap_migrations"
            )
            return int(val)
        except Exception:
            return 0

    async def load(self, id: str, kind: str = "Module") -> Any:  # noqa: A002
        row = await self._pool.fetchrow(
            f"SELECT yaml_content FROM {self._schema}.aap_manifests WHERE id = $1 AND kind = $2",
            id, kind,
        )
        if row is None:
            raise ValueError(f"Manifest not found: {id} (kind: {kind})")
        return self._registry.parse_yaml(row["yaml_content"], kind)

    async def save(self, id: str, kind: str, manifest: Any) -> None:  # noqa: A002
        yaml_content = yaml.dump(
            manifest if isinstance(manifest, dict) else vars(manifest),
            allow_unicode=True,
        )
        version = None
        if hasattr(manifest, "metadata") and hasattr(manifest.metadata, "version"):
            version = manifest.metadata.version
        elif isinstance(manifest, dict):
            version = manifest.get("metadata", {}).get("version")

        await self._pool.execute(
            f"""
            INSERT INTO {self._schema}.aap_manifests (id, kind, yaml_content, version, updated_at)
            VALUES ($1, $2, $3, $4, NOW())
            ON CONFLICT (id, kind)
            DO UPDATE SET yaml_content = EXCLUDED.yaml_content,
                          version = EXCLUDED.version,
                          updated_at = NOW()
            """,
            id, kind, yaml_content, version,
        )

    async def list(self, kind: str | None = None) -> list[ManifestEntry]:  # noqa: A002
        source_tag = f"postgres:{self._schema}"
        if kind is not None:
            rows = await self._pool.fetch(
                f"SELECT id, kind, version FROM {self._schema}.aap_manifests WHERE kind = $1 ORDER BY id",
                kind,
            )
        else:
            rows = await self._pool.fetch(
                f"SELECT id, kind, version FROM {self._schema}.aap_manifests ORDER BY id"
            )
        return [
            ManifestEntry(
                id=row["id"],
                kind=row["kind"],
                version=row.get("version"),
                source=source_tag,
            )
            for row in rows
        ]


def create_postgres_manifest_source(
    pool: AsyncConnectionLike,
    schema: str = "public",
    registry: KindRegistry = kind_registry,
) -> PostgresManifestSource:
    """Cria um PostgresManifestSource para o pool asyncpg dado."""
    return PostgresManifestSource(pool, schema, registry)
