"""Noop ComposerPort adapter for testing."""
from typing import Any
from cockpit_aap.ports.composer import ComposedResult, ComposerValidationResult


class NoopComposerAdapter:
    async def compose(self, files: list[str]) -> ComposedResult:
        return ComposedResult(sources=files)

    async def validate(self, data: Any, schema: str) -> ComposerValidationResult:
        return ComposerValidationResult()

    async def export(self, files: list[str], format: str) -> str:
        return "{}"
