"""Noop PolicyEnginePort adapter for testing."""
from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyInput, PolicySource


class NoopPolicyAdapter:
    async def evaluate(self, input: PolicyInput) -> PolicyDecision:
        return PolicyDecision()

    async def load_policies(self, sources: list[PolicySource]) -> None:
        pass

    def is_ready(self) -> bool:
        return True
