"""InMemory FileStoragePort — Buffer map, memory:// URLs."""

from __future__ import annotations

from cockpit_aap.ports import FileEntry, UploadOptions


class InMemoryStorage:
    def __init__(self) -> None:
        self._store: dict[str, bytes] = {}

    async def write(
        self,
        path: str,
        content: bytes | str,
        options: UploadOptions | None = None,
    ) -> str:
        self._store[path] = content.encode() if isinstance(content, str) else content
        return f"memory://{path}"

    async def read(self, path: str) -> bytes:
        if path not in self._store:
            raise FileNotFoundError(f"[InMemoryStorage] file not found: {path}")
        return self._store[path]

    async def delete(self, path: str) -> None:
        self._store.pop(path, None)

    async def exists(self, path: str) -> bool:
        return path in self._store

    async def list(self, prefix: str | None = None) -> list[FileEntry]:
        entries = []
        for path, buf in self._store.items():
            if prefix is None or path.startswith(prefix):
                entries.append(FileEntry(path=path, url=f"memory://{path}", size=len(buf)))
        return entries


def create_in_memory_storage() -> InMemoryStorage:
    return InMemoryStorage()
