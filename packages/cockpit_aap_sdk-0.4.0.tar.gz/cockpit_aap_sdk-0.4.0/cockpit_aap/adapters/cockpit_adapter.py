"""Wrap ``AAPGatewayClient`` (or any SDK) as a ``ManifestStorePort``.

Port of ``packages/bootstrap/src/adapters/cockpit-adapter.ts``.

In TypeScript this is a simple type-cast because the ES Proxy-based
``DynamicSDK`` already satisfies ``ManifestStorePort`` structurally.
In Python we achieve the same by delegating attribute access to the
underlying ``AAPGatewayClient`` which has ``__getattr__`` proxies for
namespace access.
"""

from __future__ import annotations

from typing import Any

from ..ports import ManifestStorePort


class CockpitAdapter:
    """Adapts an ``AAPGatewayClient`` to the ``ManifestStorePort`` protocol.

    Parameters
    ----------
    sdk:
        An ``AAPGatewayClient`` instance (or any object with ``.artifacts``
        and ``.agents`` namespace proxies).
    """

    def __init__(self, sdk: Any) -> None:
        self._sdk = sdk

    @property
    def artifacts(self) -> Any:
        """Delegate to ``sdk.artifacts`` namespace."""
        return self._sdk.artifacts

    @property
    def agents(self) -> Any:
        """Delegate to ``sdk.agents`` namespace."""
        return self._sdk.agents


def create_cockpit_adapter(sdk: Any) -> CockpitAdapter:
    """Factory — wraps an SDK client as :class:`ManifestStorePort`.

    Example::

        from cockpit_aap import AAPGatewayClient, create_cockpit_adapter

        async with AAPGatewayClient(endpoint=url, token=token) as client:
            await client.init()
            store: ManifestStorePort = create_cockpit_adapter(client)
    """
    return CockpitAdapter(sdk)
