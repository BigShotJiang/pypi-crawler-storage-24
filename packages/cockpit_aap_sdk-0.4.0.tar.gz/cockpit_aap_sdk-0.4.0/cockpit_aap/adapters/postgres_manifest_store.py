# packages/py/cockpit_aap/adapters/postgres_manifest_store.py
"""PostgreSQL ManifestStorePort adapter com migrations embutidas.

Example:
    import asyncpg
    from cockpit_aap.adapters.postgres_manifest_store import create_postgres_manifest_store

    pool = await asyncpg.create_pool(dsn=os.environ["DATABASE_URL"])
    store = create_postgres_manifest_store(pool)
    await store.setup()
"""

from __future__ import annotations

import uuid
from typing import Any

from .pg_pool import AsyncConnectionLike

_STANDARD_AGENT_TYPE_ID = "54f6d2dd-f745-4f75-b58e-a5eaeac32370"


def _get_migrations(schema: str) -> list[str]:
    s = schema
    return [
        # v1 — schema inicial
        f"""
        CREATE TABLE IF NOT EXISTS {s}.aap_migrations (
            v          INTEGER PRIMARY KEY,
            applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );

        CREATE TABLE IF NOT EXISTS {s}.aap_agent_types (
            id   TEXT PRIMARY KEY,
            name TEXT NOT NULL
        );
        INSERT INTO {s}.aap_agent_types (id, name)
            VALUES ('{_STANDARD_AGENT_TYPE_ID}', 'Standard Agent')
            ON CONFLICT DO NOTHING;

        CREATE TABLE IF NOT EXISTS {s}.aap_artifacts (
            id         TEXT PRIMARY KEY,
            key        TEXT NOT NULL UNIQUE,
            value      TEXT NOT NULL,
            namespace  TEXT NOT NULL DEFAULT 'default',
            created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS aap_artifacts_namespace_idx
            ON {s}.aap_artifacts (namespace);

        CREATE TABLE IF NOT EXISTS {s}.aap_agents (
            id            TEXT PRIMARY KEY,
            name          TEXT NOT NULL,
            instructions  TEXT,
            agent_type_id TEXT NOT NULL DEFAULT '{_STANDARD_AGENT_TYPE_ID}',
            namespace     TEXT NOT NULL DEFAULT 'default',
            created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS aap_agents_name_idx
            ON {s}.aap_agents (name);

        INSERT INTO {s}.aap_migrations (v) VALUES (1) ON CONFLICT DO NOTHING;
        """,
    ]


class _PgArtifacts:
    def __init__(self, pool: AsyncConnectionLike, schema: str) -> None:
        self._pool = pool
        self._schema = schema

    async def get_artifact(self, *, key_pattern: str) -> dict[str, Any]:
        rows = await self._pool.fetch(
            f"SELECT id, key, value FROM {self._schema}.aap_artifacts WHERE key ~ $1 ORDER BY created_at",
            key_pattern,
        )
        artifacts = [{"id": r["id"], "key": r["key"], "value": r["value"]} for r in rows]
        return {"content": {"artifacts": artifacts}}

    async def create_artifact(
        self,
        *,
        key: str,
        value: str,
        conflict_strategy: str = "SKIP",
        **kwargs: Any,
    ) -> dict[str, Any]:
        artifact_id = str(uuid.uuid4())
        if conflict_strategy == "SKIP":
            row = await self._pool.fetchrow(
                f"""
                INSERT INTO {self._schema}.aap_artifacts (id, key, value)
                VALUES ($1, $2, $3)
                ON CONFLICT (key) DO NOTHING
                RETURNING id, key, value
                """,
                artifact_id, key, value,
            )
            if row is not None:
                return {"content": {"id": row["id"], "key": row["key"], "value": row["value"]}}
            # Já existia — retorna o existente
            existing = await self._pool.fetchrow(
                f"SELECT id, key, value FROM {self._schema}.aap_artifacts WHERE key = $1", key
            )
            return {"content": {"id": existing["id"], "key": existing["key"], "value": existing["value"]}}
        else:
            # OVERWRITE
            row = await self._pool.fetchrow(
                f"""
                INSERT INTO {self._schema}.aap_artifacts (id, key, value, updated_at)
                VALUES ($1, $2, $3, NOW())
                ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value, updated_at = NOW()
                RETURNING id, key, value
                """,
                artifact_id, key, value,
            )
            return {"content": {"id": row["id"], "key": row["key"], "value": row["value"]}}

    async def update_artifact(
        self, *, id: str, value: str, promote_to_production: bool = True
    ) -> dict[str, Any]:
        await self._pool.execute(
            f"UPDATE {self._schema}.aap_artifacts SET value = $1, updated_at = NOW() WHERE id = $2",
            value, id,
        )
        return {"content": {"success": True}}


class _PgAgents:
    def __init__(self, pool: AsyncConnectionLike, schema: str) -> None:
        self._pool = pool
        self._schema = schema

    async def list_agent_types(self) -> dict[str, Any]:
        rows = await self._pool.fetch(
            f"SELECT id, name FROM {self._schema}.aap_agent_types"
        )
        return {"content": {"agent_types": [{"id": r["id"], "name": r["name"]} for r in rows]}}

    async def search_utility_agents(self, *, query: str) -> dict[str, Any]:
        rows = await self._pool.fetch(
            f"SELECT id, name FROM {self._schema}.aap_agents WHERE name ILIKE $1 ORDER BY name",
            f"%{query}%",
        )
        return {"content": {"utility_agents": [{"id": r["id"], "name": r["name"]} for r in rows]}}

    async def get_full_utility_agent(self, *, agent_id: str) -> dict[str, Any]:
        row = await self._pool.fetchrow(
            f"SELECT id, name, instructions, agent_type_id FROM {self._schema}.aap_agents WHERE id = $1",
            agent_id,
        )
        if row is None:
            raise ValueError(f"Agent not found: {agent_id}")
        return {"content": {
            "id": row["id"],
            "name": row["name"],
            "instructions": row["instructions"],
            "agent_type_id": row["agent_type_id"],
        }}

    async def create_utility_agent(
        self, *, name: str, instructions: str, agent_type_id: str
    ) -> dict[str, Any]:
        agent_id = str(uuid.uuid4())
        await self._pool.execute(
            f"INSERT INTO {self._schema}.aap_agents (id, name, instructions, agent_type_id) VALUES ($1, $2, $3, $4)",
            agent_id, name, instructions, agent_type_id,
        )
        return {"content": {}}


class PostgresManifestStore:
    """ManifestStorePort + MigratableProtocol backed by PostgreSQL."""

    def __init__(self, pool: AsyncConnectionLike, schema: str = "public") -> None:
        self._pool = pool
        self._schema = schema
        self.artifacts = _PgArtifacts(pool, schema)
        self.agents = _PgAgents(pool, schema)

    async def setup(self) -> None:
        s = self._schema
        await self._pool.execute(f"""
            CREATE TABLE IF NOT EXISTS {s}.aap_migrations (
                v INTEGER PRIMARY KEY,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)
        current = await self._pool.fetchval(
            f"SELECT COALESCE(MAX(v), 0) FROM {s}.aap_migrations"
        )
        migrations = _get_migrations(s)
        for i in range(int(current), len(migrations)):
            await self._pool.execute(migrations[i])

    async def schema_version(self) -> int:
        try:
            val = await self._pool.fetchval(
                f"SELECT COALESCE(MAX(v), 0) FROM {self._schema}.aap_migrations"
            )
            return int(val)
        except Exception:
            return 0


def create_postgres_manifest_store(
    pool: AsyncConnectionLike,
    schema: str = "public",
) -> PostgresManifestStore:
    """Cria um adaptador PostgreSQL para ManifestStorePort.

    Args:
        pool: asyncpg.Pool ou qualquer objecto compatível com AsyncConnectionLike.
        schema: Schema Postgres onde as tabelas serão criadas. Default: "public".

    Returns:
        PostgresManifestStore que implementa ManifestStorePort + MigratableProtocol.
    """
    return PostgresManifestStore(pool, schema)
