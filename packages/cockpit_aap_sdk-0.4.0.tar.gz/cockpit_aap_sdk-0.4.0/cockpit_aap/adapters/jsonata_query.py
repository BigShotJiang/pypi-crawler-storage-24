"""QueryPort adapter using JSONata via Node.js subprocess."""
import asyncio
import json
from typing import Any


class JsonataCliQueryAdapter:
    """Evaluates JSONata expressions via npx jsonata-cli subprocess."""

    async def evaluate(self, expression: str, data: Any) -> Any:
        proc = await asyncio.create_subprocess_exec(
            "npx", "--yes", "jsonata-cli", expression, json.dumps(data),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            return None
        # jsonata-cli prints debug info on first line(s), result on last line
        lines = stdout.decode().strip().splitlines()
        if not lines:
            return None
        result_line = lines[-1].strip()
        if not result_line:
            return None
        try:
            return json.loads(result_line)
        except json.JSONDecodeError:
            return result_line
