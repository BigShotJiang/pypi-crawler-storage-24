# packages/py/cockpit_aap/adapters/postgres_session.py
"""PostgreSQL SessionStorePort adapter com migrations embutidas.

Example:
    import asyncpg
    from cockpit_aap.adapters.postgres_session import create_postgres_session

    pool = await asyncpg.create_pool(dsn=os.environ["DATABASE_URL"])
    store = create_postgres_session(pool)
    await store.setup()  # idempotente — chamar no startup
"""

from __future__ import annotations

from typing import Any

from .pg_pool import AsyncConnectionLike


def _get_migrations(schema: str) -> list[str]:
    """Migrações sequenciais embutidas — padrão LangGraph.

    REGRA: Nunca editar uma migração existente. Apenas ADICIONAR novas no final.
    """
    s = schema
    return [
        # v1 — schema inicial
        f"""
        CREATE TABLE IF NOT EXISTS {s}.aap_migrations (
            v          INTEGER PRIMARY KEY,
            applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE TABLE IF NOT EXISTS {s}.aap_sessions (
            thread_id  TEXT PRIMARY KEY,
            state      JSONB NOT NULL,
            updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
        );
        CREATE INDEX IF NOT EXISTS aap_sessions_updated_at_idx
            ON {s}.aap_sessions (updated_at);
        INSERT INTO {s}.aap_migrations (v) VALUES (1) ON CONFLICT DO NOTHING;
        """,
    ]


class PostgresSessionStore:
    """SessionStorePort + MigratableProtocol backed by PostgreSQL."""

    def __init__(self, pool: AsyncConnectionLike, schema: str = "public") -> None:
        self._pool = pool
        self._schema = schema

    async def setup(self) -> None:
        s = self._schema
        await self._pool.execute(f"""
            CREATE TABLE IF NOT EXISTS {s}.aap_migrations (
                v INTEGER PRIMARY KEY,
                applied_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
            )
        """)
        current = await self._pool.fetchval(
            f"SELECT COALESCE(MAX(v), 0) FROM {s}.aap_migrations"
        )
        migrations = _get_migrations(s)
        for i in range(int(current), len(migrations)):
            await self._pool.execute(migrations[i])

    async def schema_version(self) -> int:
        try:
            val = await self._pool.fetchval(
                f"SELECT COALESCE(MAX(v), 0) FROM {self._schema}.aap_migrations"
            )
            return int(val)
        except Exception:
            return 0

    async def save(self, thread_id: str, state: Any) -> None:
        import json
        await self._pool.execute(
            f"""
            INSERT INTO {self._schema}.aap_sessions (thread_id, state, updated_at)
            VALUES ($1, $2::jsonb, NOW())
            ON CONFLICT (thread_id)
            DO UPDATE SET state = EXCLUDED.state, updated_at = NOW()
            """,
            thread_id,
            json.dumps(state),
        )

    async def load(self, thread_id: str) -> Any | None:
        import json
        row = await self._pool.fetchrow(
            f"SELECT state FROM {self._schema}.aap_sessions WHERE thread_id = $1",
            thread_id,
        )
        if row is None:
            return None
        raw = row["state"]
        return json.loads(raw) if isinstance(raw, str) else raw

    async def delete(self, thread_id: str) -> None:
        await self._pool.execute(
            f"DELETE FROM {self._schema}.aap_sessions WHERE thread_id = $1",
            thread_id,
        )

    async def list(self, prefix: str | None = None) -> list[str]:
        if prefix:
            rows = await self._pool.fetch(
                f"SELECT thread_id FROM {self._schema}.aap_sessions WHERE thread_id LIKE $1",
                f"{prefix}%",
            )
        else:
            rows = await self._pool.fetch(
                f"SELECT thread_id FROM {self._schema}.aap_sessions"
            )
        return [r["thread_id"] for r in rows]

    async def prune(self, ttl_ms: int = 3_600_000) -> int:
        result = await self._pool.execute(
            f"""
            DELETE FROM {self._schema}.aap_sessions
            WHERE updated_at < NOW() - ($1::bigint * interval '1 millisecond')
            """,
            ttl_ms,
        )
        try:
            return int(result.split()[-1])
        except (ValueError, IndexError, AttributeError):
            return 0


def create_postgres_session(
    pool: AsyncConnectionLike,
    schema: str = "public",
) -> PostgresSessionStore:
    """Cria um adaptador PostgreSQL para SessionStorePort."""
    return PostgresSessionStore(pool, schema)
