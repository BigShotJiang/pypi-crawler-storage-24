"""NoOp adapters — zero-dependency implementations for testing and defaults.

All adapters are silent: they do nothing, return empty/null values, and
never raise exceptions (unless explicitly documented).
"""

from __future__ import annotations

from contextlib import contextmanager
from typing import Any, Generator

from cockpit_aap.ports import (
    AuthSession,
    LLMMessage,
    LLMOptions,
    LLMResponse,
    Span,
)


# ---------------------------------------------------------------------------
# NoopAuth
# ---------------------------------------------------------------------------


class NoopAuthAdapter:
    """Always returns null session — for local/offline dev."""

    async def get_session(self) -> None:
        return None

    async def get_access_token(self) -> None:
        return None

    async def has_role(self, role: str) -> bool:
        return False


def create_noop_auth() -> NoopAuthAdapter:
    return NoopAuthAdapter()


# ---------------------------------------------------------------------------
# NoopObservability
# ---------------------------------------------------------------------------


class _NoopSpan:
    """Silent no-op span — supports context manager and all Span methods."""

    def set_status(self, status: str, message: str | None = None) -> None:
        pass

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def record_exception(self, exc: Exception) -> None:
        pass

    def __enter__(self) -> "_NoopSpan":
        return self

    def __exit__(self, *args: Any) -> None:
        pass


class NoopObservabilityAdapter:
    """Silent no-op observability — for tests and offline dev."""

    def start_span(
        self,
        name: str,
        *,
        attributes: dict[str, Any] | None = None,
    ) -> _NoopSpan:
        return _NoopSpan()

    def record_metric(
        self,
        name: str,
        value: float,
        *,
        metric_type: str = "count",
        unit: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        pass

    def log_event(self, event_name: str, payload: dict[str, Any]) -> None:
        pass


def create_noop_observability() -> NoopObservabilityAdapter:
    return NoopObservabilityAdapter()


# ---------------------------------------------------------------------------
# NoopLLM
# ---------------------------------------------------------------------------


class NoopLLMAdapter:
    """Returns a static response — for tests."""

    def __init__(self, static_response: str = "") -> None:
        self._response = static_response

    async def complete(
        self,
        messages: list[LLMMessage],
        options: LLMOptions | None = None,
    ) -> LLMResponse:
        return LLMResponse(content=self._response, model="noop")


def create_noop_llm(static_response: str = "") -> NoopLLMAdapter:
    return NoopLLMAdapter(static_response)


# ---------------------------------------------------------------------------
# NoopEmbedding
# ---------------------------------------------------------------------------


class NoopEmbeddingAdapter:
    """Returns zero vectors — for tests (disables vector similarity)."""

    @property
    def dimensions(self) -> int:
        return 1536

    async def embed(self, texts: list[str]) -> list[list[float]]:
        return [[0.0] * self.dimensions for _ in texts]


def create_noop_embedding() -> NoopEmbeddingAdapter:
    return NoopEmbeddingAdapter()
