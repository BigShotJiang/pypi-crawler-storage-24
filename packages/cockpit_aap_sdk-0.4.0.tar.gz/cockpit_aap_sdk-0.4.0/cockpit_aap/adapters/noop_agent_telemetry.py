# noop_agent_telemetry.py
from cockpit_aap.ports.agent_telemetry import AgentSpanContext, SpanHandle, AgentEvent, AgentSpanResult

class NoopAgentTelemetryAdapter:
    def start_agent_span(self, context: AgentSpanContext) -> SpanHandle:
        return SpanHandle(span_id="noop", trace_id="noop")
    def record_event(self, span: SpanHandle, event: AgentEvent) -> None:
        pass
    def end_span(self, span: SpanHandle, result: AgentSpanResult) -> None:
        pass
