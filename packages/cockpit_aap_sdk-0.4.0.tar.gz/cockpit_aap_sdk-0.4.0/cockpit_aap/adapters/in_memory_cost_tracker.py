"""InMemoryCostTracker — development cost tracker with tenant support."""
from __future__ import annotations
from datetime import datetime
from cockpit_aap.ports.cost_tracker import (
    CostUsage, CostFilter, CostSummary, BudgetStatus, TimeseriesEntry,
)


class InMemoryCostTracker:
    """In-memory cost tracker for development/testing."""

    def __init__(
        self,
        models: dict[str, dict[str, float]] | None = None,
        budget: dict[str, float] | None = None,
        currency: str = "USD",
    ):
        self._entries: list[CostUsage] = []
        self._models = models or {}
        self._budget = budget or {}
        self._currency = currency

    def _calculate_cost(self, usage: CostUsage) -> float:
        pricing = self._models.get(usage.model)
        if not pricing:
            return 0.0
        return (
            (usage.input_tokens / 1000) * pricing.get("input_per_1k", 0)
            + (usage.output_tokens / 1000) * pricing.get("output_per_1k", 0)
        )

    def _apply_filter(self, f: CostFilter) -> list[CostUsage]:
        result = self._entries
        if f.agent_id:
            result = [e for e in result if e.agent_id == f.agent_id]
        if f.model:
            result = [e for e in result if e.model == f.model]
        if f.since is not None:
            result = [e for e in result if e.timestamp >= f.since]
        if f.until is not None:
            result = [e for e in result if e.timestamp <= f.until]
        if f.tenant_id:
            result = [e for e in result if e.tenant_id == f.tenant_id]
        return result

    async def record(self, usage: CostUsage) -> None:
        cost = usage.cost_usd if usage.cost_usd is not None else self._calculate_cost(usage)
        entry = CostUsage(
            agent_id=usage.agent_id,
            model=usage.model,
            input_tokens=usage.input_tokens,
            output_tokens=usage.output_tokens,
            cost_usd=cost,
            timestamp=usage.timestamp,
            request_id=usage.request_id,
            tenant_id=usage.tenant_id,
        )
        self._entries.append(entry)

    async def query(self, filter: CostFilter) -> CostSummary:
        filtered = self._apply_filter(filter)
        total_cost = sum(e.cost_usd or 0 for e in filtered)
        total_tokens = sum(e.input_tokens + e.output_tokens for e in filtered)
        return CostSummary(total_cost=total_cost, total_tokens=total_tokens, entries=filtered)

    async def query_timeseries(self, filter: CostFilter, granularity: str = "hour") -> list[TimeseriesEntry]:
        filtered = self._apply_filter(filter)
        buckets: dict[str, dict[str, float]] = {}

        for e in filtered:
            dt = datetime.fromtimestamp(e.timestamp / 1000)
            if granularity == "hour":
                bucket = f"{dt.hour:02d}:00"
            else:
                bucket = dt.strftime("%Y-%m-%d")
            if bucket not in buckets:
                buckets[bucket] = {"cost": 0, "requests": 0}
            buckets[bucket]["cost"] += e.cost_usd or 0
            buckets[bucket]["requests"] += 1

        return [
            TimeseriesEntry(bucket=k, cost=v["cost"], requests=int(v["requests"]))
            for k, v in sorted(buckets.items())
        ]

    async def check_budget(self, agent_id: str, tenant_id: str | None = None) -> BudgetStatus:
        import time
        now = time.time() * 1000
        day_start = now - (now % 86_400_000)
        filtered = [e for e in self._entries if e.agent_id == agent_id and e.timestamp >= day_start]
        if tenant_id:
            filtered = [e for e in filtered if e.tenant_id == tenant_id]
        spent = sum(e.cost_usd or 0 for e in filtered)

        limit = self._budget.get("daily") or self._budget.get("monthly") or self._budget.get("total") or float("inf")
        period = "daily" if "daily" in self._budget else "monthly" if "monthly" in self._budget else "total"

        return BudgetStatus(within_budget=spent <= limit, spent=spent, limit=limit, currency=self._currency, period=period)


def create_in_memory_cost_tracker(
    models: dict[str, dict[str, float]] | None = None,
    budget: dict[str, float] | None = None,
    currency: str = "USD",
) -> InMemoryCostTracker:
    """Factory function for InMemoryCostTracker."""
    return InMemoryCostTracker(models=models, budget=budget, currency=currency)
