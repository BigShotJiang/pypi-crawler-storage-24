"""JwtTenantResolver — resolve tenant from a JWT Bearer token in the Authorization header.

Requires the ``PyJWT`` package (``pip install PyJWT``).  The adapter is
optional at runtime — if PyJWT is not installed a clear ImportError is raised
at instantiation time, not at import time.
"""
from __future__ import annotations

from typing import Any

from cockpit_aap.ports.tenant_resolver import TenantContext

_DEFAULT_LICENSE_CLAIM = "x-cockpit-license-id"
_DEFAULT_NAMESPACE_CLAIM = "x-cockpit-namespace-id"
_DEFAULT_USER_CLAIM = "sub"
_DEFAULT_ROLES_CLAIM = "roles"


class JwtTenantResolver:
    """Decodes a Bearer JWT and extracts tenant claims.

    Parameters
    ----------
    secret_or_public_key:
        HMAC secret or RSA/EC public key used to verify the token signature.
        Pass ``None`` only when ``algorithms=["none"]`` (development only).
    jwks_url:
        Not yet supported — reserved for future JWKS-based key resolution.
    license_claim:
        JWT claim name that holds the license ID.
    namespace_claim:
        JWT claim name that holds the namespace ID.
    user_claim:
        JWT claim name for the user identifier (default: ``"sub"``).
    roles_claim:
        JWT claim name for roles list (default: ``"roles"``).
    algorithms:
        Algorithms accepted for verification (default: ``["HS256"]``).
    options:
        Extra options forwarded to ``jwt.decode()``.
    """

    def __init__(
        self,
        secret_or_public_key: str | bytes | None = None,
        jwks_url: str | None = None,
        license_claim: str = _DEFAULT_LICENSE_CLAIM,
        namespace_claim: str = _DEFAULT_NAMESPACE_CLAIM,
        user_claim: str = _DEFAULT_USER_CLAIM,
        roles_claim: str = _DEFAULT_ROLES_CLAIM,
        algorithms: list[str] | None = None,
        options: dict[str, Any] | None = None,
    ) -> None:
        try:
            import jwt  # noqa: F401 — validate availability at construction time
        except ImportError as exc:
            raise ImportError(
                "JwtTenantResolver requires PyJWT. Install it with: pip install PyJWT"
            ) from exc

        self._key = secret_or_public_key
        self._jwks_url = jwks_url
        self._license_claim = license_claim
        self._namespace_claim = namespace_claim
        self._user_claim = user_claim
        self._roles_claim = roles_claim
        self._algorithms = algorithms or ["HS256"]
        self._options = options or {}

    async def resolve(self, request: Any) -> TenantContext:
        import jwt as pyjwt

        auth_header = request.headers.get("authorization") or request.headers.get("Authorization")
        if not auth_header:
            raise ValueError("Missing tenant header: authorization")

        parts = auth_header.split(" ", 1)
        if len(parts) != 2 or parts[0].lower() != "bearer":
            raise ValueError("Invalid Authorization header — expected 'Bearer <token>'")

        token = parts[1].strip()

        try:
            payload = pyjwt.decode(
                token,
                self._key,
                algorithms=self._algorithms,
                options=self._options,
            )
        except pyjwt.PyJWTError as exc:
            raise ValueError(f"JWT verification failed: {exc}") from exc

        license_id = payload.get(self._license_claim)
        if not license_id:
            raise ValueError(f"Missing tenant claim in JWT: {self._license_claim}")

        namespace_id = payload.get(self._namespace_claim)
        if not namespace_id:
            raise ValueError(f"Missing tenant claim in JWT: {self._namespace_claim}")

        user_id = payload.get(self._user_claim)
        roles_raw = payload.get(self._roles_claim, [])
        if isinstance(roles_raw, str):
            roles = [r.strip() for r in roles_raw.split(",") if r.strip()]
        else:
            roles = list(roles_raw)

        return TenantContext(
            license_id=str(license_id),
            namespace_id=str(namespace_id),
            user_id=str(user_id) if user_id else None,
            roles=roles,
        )


def create_jwt_tenant_resolver(
    secret_or_public_key: str | bytes | None = None,
    jwks_url: str | None = None,
    license_claim: str = _DEFAULT_LICENSE_CLAIM,
    namespace_claim: str = _DEFAULT_NAMESPACE_CLAIM,
    user_claim: str = _DEFAULT_USER_CLAIM,
    roles_claim: str = _DEFAULT_ROLES_CLAIM,
    algorithms: list[str] | None = None,
    options: dict[str, Any] | None = None,
) -> JwtTenantResolver:
    """Create a JwtTenantResolver."""
    return JwtTenantResolver(
        secret_or_public_key=secret_or_public_key,
        jwks_url=jwks_url,
        license_claim=license_claim,
        namespace_claim=namespace_claim,
        user_claim=user_claim,
        roles_claim=roles_claim,
        algorithms=algorithms,
        options=options,
    )
