"""InMemory SessionStorePort — Map-based with prune support."""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any


@dataclass
class _SessionEntry:
    state: Any
    created_at: float
    updated_at: float


class InMemorySession:
    """Thread-safe in-memory session store (single-process only)."""

    def __init__(self) -> None:
        self._store: dict[str, _SessionEntry] = {}

    async def save(self, thread_id: str, state: Any) -> None:
        now = time.time() * 1000
        existing = self._store.get(thread_id)
        self._store[thread_id] = _SessionEntry(
            state=state,
            created_at=existing.created_at if existing else now,
            updated_at=now,
        )

    async def load(self, thread_id: str) -> Any | None:
        entry = self._store.get(thread_id)
        return entry.state if entry else None

    async def delete(self, thread_id: str) -> None:
        self._store.pop(thread_id, None)

    async def list(self, prefix: str | None = None) -> list[str]:
        keys = list(self._store.keys())
        if prefix:
            keys = [k for k in keys if k.startswith(prefix)]
        return keys

    async def prune(self, ttl_ms: int = 3_600_000) -> int:
        cutoff = time.time() * 1000 - ttl_ms
        to_delete = [k for k, v in self._store.items() if v.updated_at < cutoff]
        for k in to_delete:
            del self._store[k]
        return len(to_delete)


def create_in_memory_session() -> InMemorySession:
    return InMemorySession()
