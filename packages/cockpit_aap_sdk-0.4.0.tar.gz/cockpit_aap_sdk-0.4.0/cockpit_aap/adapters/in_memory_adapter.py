"""InMemory ManifestStorePort — full in-memory implementation for tests.

Implements the same tool signatures as the Cockpit MCP server so that
bootstrap_manifest() works identically offline and in tests.
"""

from __future__ import annotations

import uuid
from dataclasses import dataclass, field
from typing import Any


@dataclass
class _ArtifactRow:
    id: str
    key: str
    value: str


@dataclass
class _AgentRow:
    id: str
    name: str
    instructions: str
    agent_type_id: str


_STANDARD_AGENT_TYPE_ID = "54f6d2dd-f745-4f75-b58e-a5eaeac32370"

import re


class _InMemoryArtifacts:
    def __init__(self, store: dict[str, _ArtifactRow]) -> None:
        self._store = store

    async def get_artifact(self, *, key_pattern: str) -> dict[str, Any]:
        pattern = re.compile(key_pattern)
        matches = [
            {"id": a.id, "key": a.key, "value": a.value}
            for a in self._store.values()
            if pattern.search(a.key)
        ]
        return {"content": {"artifacts": matches}}

    async def create_artifact(
        self,
        *,
        key: str,
        value: str,
        conflict_strategy: str = "SKIP",
        **kwargs: Any,
    ) -> dict[str, Any]:
        if key in self._store:
            if conflict_strategy == "SKIP":
                existing = self._store[key]
                return {"content": {"id": existing.id, "key": existing.key, "value": existing.value}}
        artifact_id = str(uuid.uuid4())
        self._store[key] = _ArtifactRow(id=artifact_id, key=key, value=value)
        return {"content": {"id": artifact_id, "key": key, "value": value}}

    async def update_artifact(
        self,
        *,
        id: str,
        value: str,
        promote_to_production: bool = True,
    ) -> dict[str, Any]:
        for artifact in self._store.values():
            if artifact.id == id:
                artifact.value = value
                return {"content": {"success": True}}
        return {"content": {"success": False}}


class _InMemoryAgents:
    def __init__(self, store: dict[str, _AgentRow]) -> None:
        self._store = store

    async def list_agent_types(self) -> dict[str, Any]:
        return {
            "content": {
                "agent_types": [
                    {"id": _STANDARD_AGENT_TYPE_ID, "name": "Standard Agent"}
                ]
            }
        }

    async def search_utility_agents(self, *, query: str) -> dict[str, Any]:
        pattern = re.compile(query, re.IGNORECASE)
        matches = [
            {"id": a.id, "name": a.name}
            for a in self._store.values()
            if pattern.search(a.name)
        ]
        return {"content": {"utility_agents": matches}}

    async def get_full_utility_agent(self, *, agent_id: str) -> dict[str, Any]:
        agent = self._store.get(agent_id)
        if not agent:
            return {"content": {}}
        return {
            "content": {
                "id": agent.id,
                "name": agent.name,
                "instructions": agent.instructions,
                "agent_type_id": agent.agent_type_id,
            }
        }

    async def create_utility_agent(
        self,
        *,
        name: str,
        instructions: str,
        agent_type_id: str,
    ) -> dict[str, Any]:
        agent_id = str(uuid.uuid4())
        self._store[agent_id] = _AgentRow(
            id=agent_id,
            name=name,
            instructions=instructions,
            agent_type_id=agent_type_id,
        )
        return {"content": {}}


class InMemoryManifestStore:
    """Full in-memory ManifestStorePort — satisfies the protocol structurally."""

    def __init__(self) -> None:
        self._artifacts_store: dict[str, _ArtifactRow] = {}
        self._agents_store: dict[str, _AgentRow] = {}
        self._artifacts_ns = _InMemoryArtifacts(self._artifacts_store)
        self._agents_ns = _InMemoryAgents(self._agents_store)

    @property
    def artifacts(self) -> _InMemoryArtifacts:
        return self._artifacts_ns

    @property
    def agents(self) -> _InMemoryAgents:
        return self._agents_ns


def create_in_memory_adapter() -> InMemoryManifestStore:
    """Create a fresh in-memory ManifestStorePort for tests or offline dev."""
    return InMemoryManifestStore()
