"""OPA WASM adapter implementing PolicyEnginePort protocol.

Note: The Python opa-wasm package is less mature than the JS SDK.
This adapter is optional — the policy_factory defaults to CLI if WASM loading fails.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyInput, PolicySource, PolicyViolation
from cockpit_aap.governance.scoring import score_from_violations


class OpaWasmPolicyAdapter:
    """PolicyEnginePort adapter using OPA WASM evaluation.

    Requires:
    - ``opa`` CLI on PATH (for ``opa build --target wasm``)
    - ``opa-wasm`` Python package (``pip install opa-wasm``)

    If either requirement is missing, ``load_policies`` will raise
    ``RuntimeError``.  Use :func:`policy_factory.create_policy_engine` to
    fall back to CLI or Noop automatically.
    """

    def __init__(self) -> None:
        self._policy: Any = None
        self._tmp_dir: str | None = None
        self._ready = False

    async def load_policies(self, sources: list[PolicySource]) -> None:
        """Load Rego sources, compile to WASM via ``opa build``, then load bundle."""
        if not sources:
            self._ready = True
            return

        tmp_dir = Path(tempfile.mkdtemp(prefix="opa-wasm-"))
        self._tmp_dir = str(tmp_dir)
        try:
            # Write Rego files
            for source in sources:
                safe_name = source.id.replace("/", "_").replace(".", "_").replace("-", "_")
                (tmp_dir / f"{safe_name}.rego").write_text(source.content, encoding="utf-8")

            # Compile to WASM bundle
            bundle_path = tmp_dir / "bundle.tar.gz"
            _opa_build(str(tmp_dir), str(bundle_path))

            # Try to load via opa-wasm Python package
            try:
                from opa_wasm import OpaPolicy  # type: ignore[import]
                self._policy = OpaPolicy(str(bundle_path))
                self._ready = True
            except ImportError as exc:
                raise RuntimeError(
                    "opa-wasm Python package not installed. "
                    "Install with: pip install opa-wasm"
                ) from exc

        except Exception:
            shutil.rmtree(str(tmp_dir), ignore_errors=True)
            self._tmp_dir = None
            raise

    def is_ready(self) -> bool:
        return self._ready

    async def evaluate(self, input: PolicyInput) -> PolicyDecision:
        if not self._policy:
            return PolicyDecision()

        raw = self._policy.evaluate(
            json.dumps({"manifest": input.manifest, "context": input.context or {}})
        )
        violations = _extract_violations(raw)
        return score_from_violations(violations)

    def cleanup(self) -> None:
        """Remove temporary build directory."""
        if self._tmp_dir:
            shutil.rmtree(self._tmp_dir, ignore_errors=True)
            self._tmp_dir = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _opa_build(input_dir: str, output_path: str) -> None:
    """Invoke ``opa build --target wasm`` to compile Rego sources to WASM bundle."""
    result = subprocess.run(
        ["opa", "build", "--target", "wasm", "--bundle", input_dir, "-o", output_path],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"opa build failed: {result.stderr}")


def _extract_violations(result: Any) -> list[dict]:
    """Extract violations from WASM evaluation result."""
    violations: list[dict] = []
    if not isinstance(result, list):
        return violations

    for entry in result:
        if not isinstance(entry, dict):
            continue
        for pkg, pkg_data in entry.items():
            if not isinstance(pkg_data, dict):
                continue
            # Support both `final_violations` (compiled Rego) and `violation` (set rules)
            vs = pkg_data.get("final_violations") or pkg_data.get("violation") or []
            for v in vs:
                if isinstance(v, dict):
                    violations.append({**v, "policy": pkg})
    return violations
