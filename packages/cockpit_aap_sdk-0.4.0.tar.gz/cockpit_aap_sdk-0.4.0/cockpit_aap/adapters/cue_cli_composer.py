"""ComposerPort adapter using CUE CLI subprocess."""
import asyncio
import json
import tempfile
import os
from pathlib import Path
from typing import Any

from cockpit_aap.ports.composer import ComposedResult, ComposerValidationResult
from cockpit_aap.ports.linter import Diagnostic


def _write_text(path: str, content: str) -> None:
    """Write text synchronously (minimal I/O for small temp files)."""
    Path(path).write_text(content, encoding="utf-8")


async def is_cue_available() -> bool:
    try:
        proc = await asyncio.create_subprocess_exec(
            "cue", "version", stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
        )
        await proc.wait()
        return proc.returncode == 0
    except FileNotFoundError:
        return False


class CueCliComposerAdapter:
    async def compose(self, files: list[str]) -> ComposedResult:
        if not files:
            return ComposedResult(sources=files)
        proc = await asyncio.create_subprocess_exec(
            "cue", "eval", *files, "--out", "json",
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        stdout, stderr = await proc.communicate()
        if proc.returncode != 0:
            raise RuntimeError(f"CUE eval failed: {stderr.decode()}")
        return ComposedResult(data=json.loads(stdout), sources=files)

    async def validate(self, data: Any, schema: str) -> ComposerValidationResult:
        fd, data_file = tempfile.mkstemp(suffix=".json")
        os.close(fd)
        _write_text(data_file, json.dumps(data))
        try:
            proc = await asyncio.create_subprocess_exec(
                "cue", "vet", data_file, schema,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            _, stderr = await proc.communicate()
            if proc.returncode != 0:
                return ComposerValidationResult(
                    valid=False,
                    errors=[Diagnostic(path="", message=stderr.decode(), severity="error", source="cue")],
                )
            return ComposerValidationResult()
        finally:
            os.unlink(data_file)

    async def export(self, files: list[str], format: str) -> str:
        proc = await asyncio.create_subprocess_exec(
            "cue", "export", *files, "--out", format,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
        )
        stdout, _ = await proc.communicate()
        return stdout.decode()
