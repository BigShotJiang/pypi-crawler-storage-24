"""SQLite-backed SessionStorePort adapter.

Port of ``packages/bootstrap/src/adapters/sqlite-session.ts``.
Uses Python's built-in ``sqlite3`` module (no extra dependency).
"""

from __future__ import annotations

import json
import sqlite3
import time
from typing import Any


class SQLiteSession:
    """SessionStorePort backed by a SQLite database file.

    Parameters
    ----------
    path:
        Path to the SQLite database file (e.g. ``".aap/sessions.db"``).
        Created if it doesn't exist.
    """

    def __init__(self, path: str) -> None:
        self._path = path
        self._db: sqlite3.Connection | None = None

    def _get_db(self) -> sqlite3.Connection:
        if self._db is None:
            self._db = sqlite3.connect(self._path)
            self._db.execute(
                """CREATE TABLE IF NOT EXISTS sessions (
                    thread_id  TEXT PRIMARY KEY,
                    state      TEXT NOT NULL,
                    created_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER) * 1000),
                    updated_at INTEGER NOT NULL DEFAULT (CAST(strftime('%s','now') AS INTEGER) * 1000)
                )"""
            )
            self._db.commit()
        return self._db

    async def save(self, thread_id: str, state: Any) -> None:
        """Save or update session *state* (JSON-serialisable)."""
        db = self._get_db()
        now = int(time.time() * 1000)
        db.execute(
            """INSERT INTO sessions (thread_id, state, updated_at)
               VALUES (?, ?, ?)
               ON CONFLICT(thread_id) DO UPDATE
               SET state = excluded.state, updated_at = excluded.updated_at""",
            (thread_id, json.dumps(state), now),
        )
        db.commit()

    async def load(self, thread_id: str) -> Any | None:
        """Load session state for *thread_id*, or ``None`` if missing."""
        db = self._get_db()
        row = db.execute(
            "SELECT state FROM sessions WHERE thread_id = ?", (thread_id,)
        ).fetchone()
        return json.loads(row[0]) if row else None

    async def delete(self, thread_id: str) -> None:
        """Delete session for *thread_id*."""
        db = self._get_db()
        db.execute("DELETE FROM sessions WHERE thread_id = ?", (thread_id,))
        db.commit()

    async def list(self, prefix: str | None = None) -> list[str]:
        """List thread IDs, optionally filtered by *prefix*."""
        db = self._get_db()
        if prefix:
            rows = db.execute(
                "SELECT thread_id FROM sessions WHERE thread_id LIKE ?",
                (f"{prefix}%",),
            ).fetchall()
        else:
            rows = db.execute("SELECT thread_id FROM sessions").fetchall()
        return [r[0] for r in rows]

    async def prune(self, ttl_ms: int = 3_600_000) -> int:
        """Delete sessions older than *ttl_ms*.  Returns number of deleted rows."""
        db = self._get_db()
        cutoff = int(time.time() * 1000) - ttl_ms
        cursor = db.execute(
            "DELETE FROM sessions WHERE updated_at < ?", (cutoff,)
        )
        db.commit()
        return cursor.rowcount

    def close(self) -> None:
        """Close the database connection."""
        if self._db:
            self._db.close()
            self._db = None


def create_sqlite_session(path: str) -> SQLiteSession:
    """Factory helper — preferred API.

    Parameters
    ----------
    path:
        Path to the SQLite database file (e.g. ``".aap/sessions.db"``).
    """
    return SQLiteSession(path)
