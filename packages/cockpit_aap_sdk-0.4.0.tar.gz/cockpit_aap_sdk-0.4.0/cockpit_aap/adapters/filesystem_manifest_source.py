# packages/py/cockpit_aap/adapters/filesystem_manifest_source.py
"""FileSystemManifestSource — usa KindRegistry para suportar qualquer kind."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from cockpit_aap.manifest.kind_registry import KindRegistry, kind_registry
from cockpit_aap.manifest.scanner import scan_manifest
from cockpit_aap.ports import ManifestEntry


def _peek_manifest_header(content: str) -> dict[str, str | None]:
    """Peek at first ~15 lines to extract kind and version without full YAML parse."""
    kind = "Module"
    version = None
    for line in content.split("\n")[:15]:
        m = re.match(r"^\s*kind:\s*(.+)", line)
        if m:
            kind = m.group(1).strip().strip("\"'")
        m = re.match(r'^\s*version:\s*["\']?([^"\'\s]+)', line)
        if m:
            version = m.group(1)
    return {"kind": kind, "version": version}


class FileSystemManifestSource:
    """Carrega manifests de .aap/<id>/manifest.yaml usando o KindRegistry.

    O kind é auto-detectado a partir do campo `kind` no manifest.yaml.
    O parâmetro `kind` em load() é ignorado — o ficheiro declara o seu próprio kind.
    """

    def __init__(self, base_dir: str, registry: KindRegistry = kind_registry) -> None:
        self._base_dir = Path(base_dir).resolve()
        self._registry = registry

    async def load(self, id: str, kind: str = "Module") -> Any:  # noqa: A002
        manifest_dir = str(self._base_dir / id)
        if not Path(manifest_dir).exists():
            raise ValueError(f"Manifest not found: {id} (path: {manifest_dir})")
        # scan_manifest auto-detecta o kind via campo `kind` no YAML
        return scan_manifest(manifest_dir)

    async def save(self, id: str, kind: str, manifest: Any) -> None:  # noqa: A002
        import yaml
        manifest_dir = self._base_dir / id
        manifest_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = manifest_dir / "manifest.yaml"
        data = manifest if isinstance(manifest, dict) else vars(manifest)
        manifest_path.write_text(yaml.dump(data, allow_unicode=True))

    async def list(self, kind: str | None = None) -> list[ManifestEntry]:  # noqa: A002
        source_tag = f"filesystem:{self._base_dir.name}"
        entries: list[ManifestEntry] = []
        try:
            for entry in self._base_dir.iterdir():
                if not entry.is_dir():
                    continue
                manifest_path = entry / "manifest.yaml"
                if not manifest_path.exists():
                    continue
                try:
                    header = _peek_manifest_header(manifest_path.read_text(encoding="utf-8"))
                    if kind and header["kind"] != kind:
                        continue
                    entries.append(ManifestEntry(
                        id=entry.name,
                        kind=header["kind"],
                        version=header.get("version"),
                        source=source_tag,
                    ))
                except OSError:
                    continue
        except OSError:
            pass
        return entries


def create_filesystem_manifest_source(
    base_dir: str,
    registry: KindRegistry = kind_registry,
) -> FileSystemManifestSource:
    """Cria um FileSystemManifestSource para o directório base dado."""
    return FileSystemManifestSource(base_dir, registry)
