"""Noop QueryPort adapter for testing."""
from typing import Any


class NoopQueryAdapter:
    async def evaluate(self, expression: str, data: Any) -> Any:
        return None
