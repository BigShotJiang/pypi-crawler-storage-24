"""OpenAI EmbeddingPort adapter — optional peer dep: pip install openai."""

from __future__ import annotations


def create_openai_embedding(
    api_key: str,
    model: str = "text-embedding-3-small",
    base_url: str | None = None,
) -> "OpenAIEmbeddingAdapter":
    return OpenAIEmbeddingAdapter(api_key=api_key, model=model, base_url=base_url)


class OpenAIEmbeddingAdapter:
    def __init__(self, api_key: str, model: str, base_url: str | None) -> None:
        self._api_key = api_key
        self._model = model
        self._base_url = base_url

    @property
    def dimensions(self) -> int:
        return 3072 if "3-large" in self._model else 1536

    async def embed(self, texts: list[str]) -> list[list[float]]:
        try:
            from openai import AsyncOpenAI  # optional peer dep
        except ImportError as exc:
            raise ImportError(
                "openai is required for OpenAIEmbeddingAdapter. Run: pip install openai"
            ) from exc

        client = AsyncOpenAI(api_key=self._api_key, base_url=self._base_url)
        response = await client.embeddings.create(model=self._model, input=texts)
        return [d.embedding for d in response.data]
