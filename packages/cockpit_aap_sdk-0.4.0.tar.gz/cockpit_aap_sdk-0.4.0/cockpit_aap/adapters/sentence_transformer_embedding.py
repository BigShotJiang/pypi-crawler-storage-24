"""Sentence Transformer EmbeddingPort adapter — optional peer dep: pip install sentence-transformers.

Provides **local, offline-first** semantic embeddings with no API keys required.
Models are auto-downloaded from HuggingFace Hub on first use (~80–470 MB)
and cached at ``~/.cache/huggingface/``.

Recommended models:

+----------------------------------------------+------+-------------+----------+
| Model                                        | Dims | Languages   | Size     |
+----------------------------------------------+------+-------------+----------+
| all-MiniLM-L6-v2  (default)                  |  384 | EN          |  ~80 MB  |
| all-mpnet-base-v2                            |  768 | EN          | ~420 MB  |
| paraphrase-multilingual-MiniLM-L12-v2       |  384 | 50+ (PT-BR) | ~470 MB  |
| multi-qa-mpnet-base-cos-v1                   |  768 | EN          | ~420 MB  |
+----------------------------------------------+------+-------------+----------+

Usage::

    from cockpit_aap.adapters.sentence_transformer_embedding import (
        create_sentence_transformer_embedding,
    )

    # English-only (fast, small)
    adapter = create_sentence_transformer_embedding()

    # Multilingual (PT-BR + EN)
    adapter = create_sentence_transformer_embedding(
        model="paraphrase-multilingual-MiniLM-L12-v2",
    )

    # Use with aap-graph
    from cockpit_aap.graph import build_graph, GraphConfig
    graph = await build_graph(dirs, GraphConfig(embedding_adapter=adapter))

    # Direct embed
    vectors = await adapter.embed(["hello world", "olá mundo"])
    print(len(vectors[0]))  # 384
"""

from __future__ import annotations

import asyncio
from typing import Any


# ---------------------------------------------------------------------------
# Known model → dimensions mapping (avoids loading model just to query dims)
# ---------------------------------------------------------------------------

_MODEL_DIMS: dict[str, int] = {
    "all-MiniLM-L6-v2": 384,
    "all-MiniLM-L12-v2": 384,
    "all-mpnet-base-v2": 768,
    "all-distilroberta-v1": 768,
    "paraphrase-multilingual-MiniLM-L12-v2": 384,
    "paraphrase-multilingual-mpnet-base-v2": 768,
    "multi-qa-mpnet-base-cos-v1": 768,
    "multi-qa-MiniLM-L6-cos-v1": 384,
    "multi-qa-distilbert-cos-v1": 768,
    "msmarco-distilbert-base-v4": 768,
}


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def create_sentence_transformer_embedding(
    model: str = "all-MiniLM-L6-v2",
    device: str | None = None,
    batch_size: int = 32,
    normalize: bool = True,
    show_progress: bool = False,
) -> "SentenceTransformerEmbeddingAdapter":
    """Create a local embedding adapter backed by sentence-transformers.

    Parameters
    ----------
    model:
        HuggingFace model name or local path.  Default ``all-MiniLM-L6-v2``
        (384-dim, ~80 MB, English).  For multilingual use
        ``paraphrase-multilingual-MiniLM-L12-v2``.
    device:
        PyTorch device string.  ``None`` → auto-detect (cuda > mps > cpu).
    batch_size:
        Batch size for ``model.encode()``.  Default 32.
    normalize:
        Whether to L2-normalize embeddings (recommended for cosine similarity).
    show_progress:
        Show a tqdm progress bar during encoding.
    """
    return SentenceTransformerEmbeddingAdapter(
        model_name=model,
        device=device,
        batch_size=batch_size,
        normalize=normalize,
        show_progress=show_progress,
    )


# ---------------------------------------------------------------------------
# Adapter
# ---------------------------------------------------------------------------


class SentenceTransformerEmbeddingAdapter:
    """EmbeddingPort adapter using sentence-transformers (local models).

    The underlying ``SentenceTransformer`` model is **lazily loaded** on the
    first call to :meth:`embed` so construction is instant.

    Since ``model.encode()`` is synchronous it is dispatched to a thread via
    ``asyncio.to_thread`` to keep the event loop responsive.
    """

    def __init__(
        self,
        model_name: str,
        device: str | None,
        batch_size: int,
        normalize: bool,
        show_progress: bool,
    ) -> None:
        self._model_name = model_name
        self._device = device
        self._batch_size = batch_size
        self._normalize = normalize
        self._show_progress = show_progress
        self._model: Any | None = None  # lazy

    # -- EmbeddingPort interface ---------------------------------------------

    @property
    def dimensions(self) -> int:
        """Return the embedding dimensionality.

        Uses a static lookup if the model is known, otherwise loads the model
        and queries ``get_sentence_embedding_dimension()``.
        """
        if self._model_name in _MODEL_DIMS:
            return _MODEL_DIMS[self._model_name]
        # Fallback — load model to discover dims
        model = self._get_model()
        dim = model.get_sentence_embedding_dimension()
        return int(dim) if dim else 384

    async def embed(self, texts: list[str]) -> list[list[float]]:
        """Encode texts into dense vectors.

        Runs in a thread pool (``asyncio.to_thread``) so the event loop is
        never blocked even for large batches.
        """
        if not texts:
            return []
        model = self._get_model()
        # model.encode() is synchronous — dispatch to thread
        embeddings = await asyncio.to_thread(
            model.encode,
            texts,
            batch_size=self._batch_size,
            show_progress_bar=self._show_progress,
            normalize_embeddings=self._normalize,
            convert_to_numpy=True,
        )
        # numpy ndarray → list[list[float]]
        return embeddings.tolist()

    # -- Internals -----------------------------------------------------------

    def _get_model(self) -> Any:
        """Lazy-load the SentenceTransformer model."""
        if self._model is not None:
            return self._model
        try:
            from sentence_transformers import SentenceTransformer
        except ImportError as exc:
            raise ImportError(
                "sentence-transformers is required for SentenceTransformerEmbeddingAdapter. "
                "Run: pip install sentence-transformers"
            ) from exc

        self._model = SentenceTransformer(self._model_name, device=self._device)
        # Cache dimensions for this model name for future instances
        dim = self._model.get_sentence_embedding_dimension()
        if dim and self._model_name not in _MODEL_DIMS:
            _MODEL_DIMS[self._model_name] = int(dim)
        return self._model

    # -- Convenience ---------------------------------------------------------

    @property
    def model_name(self) -> str:
        """Return the model identifier."""
        return self._model_name

    @property
    def is_loaded(self) -> bool:
        """Return whether the model has been loaded into memory."""
        return self._model is not None

    def __repr__(self) -> str:
        state = "loaded" if self._model is not None else "lazy"
        return (
            f"SentenceTransformerEmbeddingAdapter("
            f"model={self._model_name!r}, dims={self.dimensions}, {state})"
        )
