"""OpenAI LLMPort adapter — optional peer dep: pip install openai."""

from __future__ import annotations

from typing import TYPE_CHECKING

from cockpit_aap.ports import LLMMessage, LLMOptions, LLMResponse, LLMUsage


def create_openai_llm(
    api_key: str,
    model: str = "gpt-4.1",
    base_url: str | None = None,
) -> "OpenAILLMAdapter":
    return OpenAILLMAdapter(api_key=api_key, model=model, base_url=base_url)


class OpenAILLMAdapter:
    def __init__(self, api_key: str, model: str, base_url: str | None) -> None:
        self._api_key = api_key
        self._default_model = model
        self._base_url = base_url

    async def complete(
        self,
        messages: list[LLMMessage],
        options: LLMOptions | None = None,
    ) -> LLMResponse:
        try:
            from openai import AsyncOpenAI  # optional peer dep
        except ImportError as exc:
            raise ImportError(
                "openai is required for OpenAILLMAdapter. Run: pip install openai"
            ) from exc

        client = AsyncOpenAI(api_key=self._api_key, base_url=self._base_url)
        model = (options.model if options else None) or self._default_model
        max_tokens = (options.max_tokens if options else None)
        temperature = (options.temperature if options else None)

        response = await client.chat.completions.create(
            model=model,
            messages=[{"role": m.role, "content": m.content} for m in messages],
            max_tokens=max_tokens,
            temperature=temperature,
        )
        choice = response.choices[0]
        usage = None
        if response.usage:
            usage = LLMUsage(
                prompt_tokens=response.usage.prompt_tokens,
                completion_tokens=response.usage.completion_tokens,
                total_tokens=response.usage.total_tokens,
            )
        return LLMResponse(
            content=choice.message.content or "",
            model=response.model,
            usage=usage,
        )
