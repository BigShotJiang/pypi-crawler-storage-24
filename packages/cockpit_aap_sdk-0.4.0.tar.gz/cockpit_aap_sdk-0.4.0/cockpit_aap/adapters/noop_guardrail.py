# noop_guardrail.py
from cockpit_aap.ports.guardrail import GuardrailContext, GuardrailDecision

class NoopGuardrailAdapter:
    async def evaluate_input(self, context: GuardrailContext) -> GuardrailDecision:
        return GuardrailDecision()
    async def evaluate_output(self, context: GuardrailContext) -> GuardrailDecision:
        return GuardrailDecision()
