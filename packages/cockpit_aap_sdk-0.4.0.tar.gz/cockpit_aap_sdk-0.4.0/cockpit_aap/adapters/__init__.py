"""Port adapters for the AAP SDK (Python)."""

from cockpit_aap.adapters.noop_adapters import (
    NoopAuthAdapter,
    NoopObservabilityAdapter,
    NoopLLMAdapter,
    NoopEmbeddingAdapter,
    create_noop_auth,
    create_noop_observability,
    create_noop_llm,
    create_noop_embedding,
)
from cockpit_aap.adapters.in_memory_adapter import InMemoryManifestStore, create_in_memory_adapter
from cockpit_aap.adapters.in_memory_session import InMemorySession, create_in_memory_session
from cockpit_aap.adapters.in_memory_storage import InMemoryStorage, create_in_memory_storage
from cockpit_aap.adapters.pg_pool import AsyncConnectionLike
from cockpit_aap.adapters.filesystem_manifest_source import FileSystemManifestSource, create_filesystem_manifest_source
from cockpit_aap.adapters.postgres_manifest_source import PostgresManifestSource, create_postgres_manifest_source
from cockpit_aap.adapters.tenant_postgres_manifest_source import TenantPostgresManifestSource, create_tenant_postgres_source
from cockpit_aap.adapters.postgres_session import PostgresSessionStore, create_postgres_session
from cockpit_aap.adapters.postgres_manifest_store import PostgresManifestStore, create_postgres_manifest_store
from cockpit_aap.adapters.local_artifact_store import LocalArtifactStore, create_local_artifact_store
from cockpit_aap.adapters.local_fs_storage import LocalFSStorage, create_local_fs_storage
from cockpit_aap.adapters.sqlite_session import SQLiteSession, create_sqlite_session
from cockpit_aap.adapters.sentence_transformer_embedding import (
    SentenceTransformerEmbeddingAdapter,
    create_sentence_transformer_embedding,
)
from cockpit_aap.adapters.noop_query import NoopQueryAdapter
from cockpit_aap.adapters.noop_linter import NoopLinterAdapter
from cockpit_aap.adapters.noop_policy import NoopPolicyAdapter
from cockpit_aap.adapters.noop_composer import NoopComposerAdapter
from cockpit_aap.adapters.noop_guardrail import NoopGuardrailAdapter
from cockpit_aap.adapters.noop_cost_tracker import NoopCostTrackerAdapter
from cockpit_aap.adapters.in_memory_cost_tracker import InMemoryCostTracker, create_in_memory_cost_tracker
from cockpit_aap.adapters.noop_agent_telemetry import NoopAgentTelemetryAdapter
from cockpit_aap.adapters.yaml_to_rego import compile_to_rego
from cockpit_aap.adapters.jsonata_query import JsonataCliQueryAdapter
from cockpit_aap.adapters.opa_cli_policy import OpaCliPolicyAdapter, is_opa_available
from cockpit_aap.adapters.opa_wasm_policy import OpaWasmPolicyAdapter
from cockpit_aap.adapters.policy_factory import create_policy_engine
from cockpit_aap.adapters.cue_cli_composer import CueCliComposerAdapter, is_cue_available
from cockpit_aap.adapters.header_tenant_resolver import HeaderTenantResolver, create_header_tenant_resolver
from cockpit_aap.adapters.env_tenant_resolver import EnvTenantResolver, create_env_tenant_resolver
from cockpit_aap.adapters.jwt_tenant_resolver import JwtTenantResolver, create_jwt_tenant_resolver
from cockpit_aap.adapters.composite_tenant_resolver import (
    CompositeTenantResolver,
    NoopTenantResolver,
    create_composite_tenant_resolver,
    create_noop_tenant_resolver,
)

__all__ = [
    # Noop adapters (for tests)
    "NoopAuthAdapter",
    "NoopObservabilityAdapter",
    "NoopLLMAdapter",
    "NoopEmbeddingAdapter",
    "create_noop_auth",
    "create_noop_observability",
    "create_noop_llm",
    "create_noop_embedding",
    # ManifestStore adapters
    "InMemoryManifestStore",
    "create_in_memory_adapter",
    # Session adapters
    "InMemorySession",
    "create_in_memory_session",
    # File storage adapters
    "InMemoryStorage",
    "create_in_memory_storage",
    # ManifestSource adapters
    "FileSystemManifestSource",
    "create_filesystem_manifest_source",
    "PostgresManifestSource",
    "create_postgres_manifest_source",
    "TenantPostgresManifestSource",
    "create_tenant_postgres_source",
    # Postgres session/manifest-store adapters
    "AsyncConnectionLike",
    "PostgresSessionStore",
    "create_postgres_session",
    "PostgresManifestStore",
    "create_postgres_manifest_store",
    # Local adapters
    "LocalArtifactStore",
    "create_local_artifact_store",
    "LocalFSStorage",
    "create_local_fs_storage",
    "SQLiteSession",
    "create_sqlite_session",
    # Sentence Transformer (local embedding)
    "SentenceTransformerEmbeddingAdapter",
    "create_sentence_transformer_embedding",
    # New port noop adapters (QueryPort, LinterPort, PolicyEnginePort, ComposerPort)
    "NoopQueryAdapter",
    "NoopLinterAdapter",
    "NoopPolicyAdapter",
    "NoopComposerAdapter",
    # Enterprise runtime noop adapters (GuardrailPort, CostTrackerPort, AgentTelemetryPort)
    "NoopGuardrailAdapter",
    "NoopCostTrackerAdapter",
    "NoopAgentTelemetryAdapter",
    # InMemory cost tracker
    "InMemoryCostTracker",
    "create_in_memory_cost_tracker",
    # YAML-to-Rego compiler
    "compile_to_rego",
    # CLI adapters (JSONata, OPA, CUE)
    "JsonataCliQueryAdapter",
    "OpaCliPolicyAdapter",
    "is_opa_available",
    "OpaWasmPolicyAdapter",
    "create_policy_engine",
    "CueCliComposerAdapter",
    "is_cue_available",
    # Tenant resolver adapters
    "HeaderTenantResolver",
    "create_header_tenant_resolver",
    "EnvTenantResolver",
    "create_env_tenant_resolver",
    "JwtTenantResolver",
    "create_jwt_tenant_resolver",
    "CompositeTenantResolver",
    "NoopTenantResolver",
    "create_composite_tenant_resolver",
    "create_noop_tenant_resolver",
]
