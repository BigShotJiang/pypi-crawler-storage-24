"""PolicyEnginePort adapter using OPA CLI subprocess."""
import asyncio
import json
import tempfile
import os
from typing import Any

from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyInput, PolicySource, PolicyViolation
from pathlib import Path


def _write_text(path: str, content: str) -> None:
    """Write text to file synchronously (minimal I/O for small policy files)."""
    Path(path).write_text(content, encoding="utf-8")


def _grade_score(pct: float) -> str:
    if pct >= 90: return "A"
    if pct >= 75: return "B"
    if pct >= 60: return "C"
    if pct >= 40: return "D"
    return "F"


async def is_opa_available() -> bool:
    try:
        proc = await asyncio.create_subprocess_exec(
            "opa", "version", stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL
        )
        await proc.wait()
        return proc.returncode == 0
    except FileNotFoundError:
        return False


class OpaCliPolicyAdapter:
    def __init__(self) -> None:
        self._policy_dir: str | None = None
        self._ready = False

    async def load_policies(self, sources: list[PolicySource]) -> None:
        self._policy_dir = tempfile.mkdtemp(prefix="opa-policies-")
        for source in sources:
            filename = source.id.replace("-", "_") + ".rego"
            path = os.path.join(self._policy_dir, filename)
            # Write synchronously — file I/O is minimal (small policy files)
            # and tempdir is always local filesystem
            _write_text(path, source.content)
        self._ready = True

    def is_ready(self) -> bool:
        return self._ready

    async def evaluate(self, input: PolicyInput) -> PolicyDecision:
        if not self._policy_dir:
            return PolicyDecision()

        fd, input_file = tempfile.mkstemp(suffix=".json")
        os.close(fd)
        _write_text(input_file, json.dumps({"manifest": input.manifest, "context": input.context or {}}))

        try:
            proc = await asyncio.create_subprocess_exec(
                "opa", "eval", "-d", self._policy_dir, "-i", input_file,
                "--format", "json", "data.aap.conformance",
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await proc.communicate()
            return self._parse_result(stdout.decode())
        finally:
            os.unlink(input_file)

    def _parse_result(self, stdout: str) -> PolicyDecision:
        data = json.loads(stdout)
        violations: list[PolicyViolation] = []

        result = data.get("result", [{}])[0].get("expressions", [{}])[0].get("value", {})
        for pkg, val in result.items():
            for v in (val or {}).get("violations", []):
                violations.append(PolicyViolation(
                    policy=pkg,
                    rule=v.get("rule", "unknown"),
                    message=v.get("message", "Policy violation"),
                    severity=v.get("severity", "info"),
                ))

        has_errors = any(v.severity == "error" for v in violations)
        pct = 0.0 if has_errors else 100.0
        return PolicyDecision(
            passed=not has_errors,
            percentage=pct,
            grade=_grade_score(pct),
            violations=violations,
        )
