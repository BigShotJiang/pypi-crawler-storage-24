# noop_cost_tracker.py
from cockpit_aap.ports.cost_tracker import CostUsage, CostFilter, CostSummary, BudgetStatus

class NoopCostTrackerAdapter:
    async def record(self, usage: CostUsage) -> None:
        pass
    async def query(self, filter: CostFilter) -> CostSummary:
        return CostSummary()
    async def query_timeseries(self, filter: CostFilter, granularity: str = "hour") -> list:
        return []
    async def check_budget(self, agent_id: str, tenant_id: str | None = None) -> BudgetStatus:
        return BudgetStatus()
