"""Local filesystem-backed FileStoragePort adapter.

Port of ``packages/bootstrap/src/adapters/local-fs-storage.ts``.
"""

from __future__ import annotations

import os
import shutil
from dataclasses import dataclass
from typing import Any

from ..ports import FileStoragePort, FileEntry, UploadOptions


class LocalFSStorage:
    """File storage backed by the local filesystem.

    Parameters
    ----------
    base_dir:
        Root directory for all stored files.
    """

    def __init__(self, base_dir: str) -> None:
        self._base_dir = os.path.abspath(base_dir)

    async def write(
        self,
        path: str,
        content: bytes | str,
        options: UploadOptions | None = None,
    ) -> str:
        full = os.path.join(self._base_dir, path)
        os.makedirs(os.path.dirname(full), exist_ok=True)
        mode = "w" if isinstance(content, str) else "wb"
        with open(full, mode) as fh:
            fh.write(content)
        return f"file://{full}"

    async def read(self, path: str) -> bytes:
        full = os.path.join(self._base_dir, path)
        with open(full, "rb") as fh:
            return fh.read()

    async def delete(self, path: str) -> None:
        full = os.path.join(self._base_dir, path)
        try:
            os.remove(full)
        except FileNotFoundError:
            pass

    async def exists(self, path: str) -> bool:
        full = os.path.join(self._base_dir, path)
        return os.path.isfile(full)

    async def list(self, prefix: str | None = None) -> list[FileEntry]:
        target = os.path.join(self._base_dir, prefix) if prefix else self._base_dir
        entries: list[FileEntry] = []
        try:
            for name in os.listdir(target):
                full = os.path.join(target, name)
                if os.path.isfile(full):
                    info = os.stat(full)
                    entries.append(
                        FileEntry(
                            path=os.path.relpath(full, self._base_dir),
                            url=f"file://{full}",
                            size=info.st_size,
                            created_at=info.st_birthtime * 1000
                            if hasattr(info, "st_birthtime")
                            else info.st_ctime * 1000,
                        )
                    )
        except FileNotFoundError:
            pass
        return entries


def create_local_fs_storage(base_dir: str) -> LocalFSStorage:
    """Factory helper — preferred API."""
    return LocalFSStorage(base_dir)
