"""kind: CodeQuality scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


CodeQualityKind = define_kind(
    kind="CodeQuality",
    api_version="governance.cockpit.io/v1",
    domain="quality",
    description="Code quality metrics — SonarQube/SonarCloud results aggregation.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
