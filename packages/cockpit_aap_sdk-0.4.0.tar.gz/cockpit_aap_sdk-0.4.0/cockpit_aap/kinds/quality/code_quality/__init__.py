"""kind: CodeQuality scanner definition."""

from .scanner import CodeQualityKind

__all__ = ["CodeQualityKind"]
