"""Register all quality domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .code_quality import CodeQualityKind
from .security_scan import SecurityScanKind
from .test_report import TestReportKind


def register_quality_kinds(registry: KindRegistry) -> None:
    """Register all quality kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(registry, CodeQualityKind, SecurityScanKind, TestReportKind)
