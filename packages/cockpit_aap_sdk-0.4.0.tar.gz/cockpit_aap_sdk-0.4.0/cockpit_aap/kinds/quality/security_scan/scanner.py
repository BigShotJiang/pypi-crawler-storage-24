"""kind: SecurityScan scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


SecurityScanKind = define_kind(
    kind="SecurityScan",
    api_version="governance.cockpit.io/v1",
    domain="quality",
    description="Security scanning posture — SAST, DAST, SCA, pentest results.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
