"""kind: SecurityScan scanner definition."""

from .scanner import SecurityScanKind

__all__ = ["SecurityScanKind"]
