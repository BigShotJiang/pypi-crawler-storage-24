"""kind: TestReport scanner definition."""

from .scanner import TestReportKind

__all__ = ["TestReportKind"]
