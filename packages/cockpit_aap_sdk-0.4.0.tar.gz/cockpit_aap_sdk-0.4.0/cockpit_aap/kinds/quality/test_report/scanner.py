"""kind: TestReport scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


TestReportKind = define_kind(
    kind="TestReport",
    api_version="governance.cockpit.io/v1",
    domain="quality",
    description="Test execution report — unit, integration, e2e, contract test results.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
