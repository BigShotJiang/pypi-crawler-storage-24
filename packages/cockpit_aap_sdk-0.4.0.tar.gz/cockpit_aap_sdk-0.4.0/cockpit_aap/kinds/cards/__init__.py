"""Register all cards domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .agent_card import AgentCardKind


def register_cards_kinds(registry: KindRegistry) -> None:
    """Register all cards kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(registry, AgentCardKind)
