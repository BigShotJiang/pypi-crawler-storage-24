"""kind: AgentCard scanner definition."""

from .scanner import AgentCardKind

__all__ = ["AgentCardKind"]
