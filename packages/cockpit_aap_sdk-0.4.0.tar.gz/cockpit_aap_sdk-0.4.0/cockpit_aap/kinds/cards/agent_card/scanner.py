"""kind: AgentCard scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


AgentCardKind = define_kind(
    kind="AgentCard",
    api_version="a2a-protocol.org/v1",
    domain="cards",
    description="A2A Agent Card — public discovery card for agent-to-agent communication.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
