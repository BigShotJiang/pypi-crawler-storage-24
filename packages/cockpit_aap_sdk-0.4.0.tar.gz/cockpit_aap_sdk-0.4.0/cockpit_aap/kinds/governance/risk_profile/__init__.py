"""kind: RiskProfile scanner definition."""

from .scanner import RiskProfileKind

__all__ = ["RiskProfileKind"]
