"""kind: RiskProfile scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


RiskProfileKind = define_kind(
    kind="RiskProfile",
    api_version="governance.cockpit.io/v1",
    domain="governance",
    description="AI risk assessment covering EU AI Act, NIST AI RMF, and OWASP LLM Top 10.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
