"""Register all governance domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .policy import PolicyKind
from .conformance_policy import ConformancePolicyKind
from .manifest_policy import ManifestPolicyKind
from .risk_profile import RiskProfileKind
from .guardrail import GuardrailKind
from .cost_policy import CostPolicyKind


def register_governance_kinds(registry: KindRegistry) -> None:
    """Register all governance kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(
        registry,
        PolicyKind,
        ConformancePolicyKind,
        ManifestPolicyKind,
        RiskProfileKind,
        GuardrailKind,
        CostPolicyKind,
    )
