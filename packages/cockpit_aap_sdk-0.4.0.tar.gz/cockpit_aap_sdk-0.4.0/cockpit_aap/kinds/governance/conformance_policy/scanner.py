"""kind: ConformancePolicy scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


ConformancePolicyKind = define_kind(
    kind="ConformancePolicy",
    api_version="governance.cockpit.io/v1",
    domain="governance",
    description="Structural field-presence requirements per kind with severity levels.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
