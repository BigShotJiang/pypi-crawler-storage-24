"""kind: ConformancePolicy scanner definition."""

from .scanner import ConformancePolicyKind

__all__ = ["ConformancePolicyKind"]
