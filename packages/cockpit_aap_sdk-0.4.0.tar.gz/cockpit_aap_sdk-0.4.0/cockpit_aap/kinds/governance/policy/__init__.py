"""kind: Policy scanner definition."""

from .scanner import PolicyKind

__all__ = ["PolicyKind"]
