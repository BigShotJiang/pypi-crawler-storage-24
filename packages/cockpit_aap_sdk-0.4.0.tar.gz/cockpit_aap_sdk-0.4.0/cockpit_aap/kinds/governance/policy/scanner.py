"""kind: Policy scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


PolicyKind = define_kind(
    kind="Policy",
    api_version="governance.cockpit.io/v1",
    domain="governance",
    description="An AI governance policy — defines framework, category, risk tolerance, statements.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
