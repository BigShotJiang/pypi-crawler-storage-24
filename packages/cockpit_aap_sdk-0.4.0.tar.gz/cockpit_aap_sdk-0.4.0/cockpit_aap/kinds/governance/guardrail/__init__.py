"""kind: Guardrail scanner definition."""

from .scanner import GuardrailKind

__all__ = ["GuardrailKind"]
