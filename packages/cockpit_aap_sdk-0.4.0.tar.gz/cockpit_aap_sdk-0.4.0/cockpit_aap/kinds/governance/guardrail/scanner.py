"""kind: Guardrail scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


GuardrailKind = define_kind(
    kind="Guardrail",
    api_version="cockpit.io/v1",
    domain="governance",
    description="A runtime guardrail — input/output validator, content filter, PII detector.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
