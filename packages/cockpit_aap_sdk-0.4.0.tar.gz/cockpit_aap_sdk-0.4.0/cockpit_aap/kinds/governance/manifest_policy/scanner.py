"""kind: ManifestPolicy scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


ManifestPolicyKind = define_kind(
    kind="ManifestPolicy",
    api_version="governance.cockpit.io/v1",
    domain="governance",
    description="Semantic / business cross-manifest requirements and relationships.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
