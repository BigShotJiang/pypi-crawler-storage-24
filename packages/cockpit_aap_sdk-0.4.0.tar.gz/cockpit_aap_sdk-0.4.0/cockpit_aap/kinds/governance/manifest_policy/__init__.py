"""kind: ManifestPolicy scanner definition."""

from .scanner import ManifestPolicyKind

__all__ = ["ManifestPolicyKind"]
