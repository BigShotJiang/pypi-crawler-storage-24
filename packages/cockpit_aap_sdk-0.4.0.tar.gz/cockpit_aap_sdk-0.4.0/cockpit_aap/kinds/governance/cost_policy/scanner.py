"""kind: CostPolicy scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


CostPolicyKind = define_kind(
    kind="CostPolicy",
    api_version="governance.cockpit.io/v1",
    domain="governance",
    description="Cost governance policy — budget limits, alert thresholds, and enforcement rules.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
