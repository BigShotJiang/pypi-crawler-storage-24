"""kind: CostPolicy scanner definition."""

from .scanner import CostPolicyKind

__all__ = ["CostPolicyKind"]
