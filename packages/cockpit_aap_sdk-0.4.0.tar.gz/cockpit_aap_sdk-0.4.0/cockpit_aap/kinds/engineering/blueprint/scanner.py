"""kind: Blueprint scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


BlueprintKind = define_kind(
    kind="Blueprint",
    api_version="planning.cockpit.io/v1",
    domain="engineering",
    description="A multi-phase implementation plan tracking progress, phases, and deliverables.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
