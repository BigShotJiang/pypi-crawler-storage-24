"""kind: Blueprint scanner definition."""

from .scanner import BlueprintKind

__all__ = ["BlueprintKind"]
