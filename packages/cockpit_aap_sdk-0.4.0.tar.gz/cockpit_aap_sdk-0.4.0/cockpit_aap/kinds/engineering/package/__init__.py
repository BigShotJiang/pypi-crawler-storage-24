"""kind: Package scanner definition."""

from .scanner import PackageKind

__all__ = ["PackageKind"]
