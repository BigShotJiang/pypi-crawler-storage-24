"""kind: Package scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


PackageKind = define_kind(
    kind="Package",
    api_version="code.cockpit.io/v1",
    domain="engineering",
    description="A monorepo package or application — language, dependencies, test config.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
