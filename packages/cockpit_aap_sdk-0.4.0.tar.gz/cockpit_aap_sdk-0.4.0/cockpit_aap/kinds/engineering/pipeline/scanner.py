"""kind: Pipeline scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


PipelineKind = define_kind(
    kind="Pipeline",
    api_version="cockpit.io/v1",
    domain="engineering",
    description="An agentic workflow DAG — nodes connected by directed edges.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
