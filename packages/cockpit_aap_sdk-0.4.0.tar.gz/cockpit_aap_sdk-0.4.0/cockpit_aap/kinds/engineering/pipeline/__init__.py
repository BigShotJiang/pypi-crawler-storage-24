"""kind: Pipeline scanner definition."""

from .scanner import PipelineKind

__all__ = ["PipelineKind"]
