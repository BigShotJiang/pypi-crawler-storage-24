"""Register all engineering domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .blueprint import BlueprintKind
from .package import PackageKind
from .pipeline import PipelineKind
from .task import TaskKind


def register_engineering_kinds(registry: KindRegistry) -> None:
    """Register all engineering kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(registry, BlueprintKind, PackageKind, PipelineKind, TaskKind)
