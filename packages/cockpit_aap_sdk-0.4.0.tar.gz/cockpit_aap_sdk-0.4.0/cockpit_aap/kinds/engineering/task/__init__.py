"""kind: Task scanner definition."""

from .scanner import TaskKind

__all__ = ["TaskKind"]
