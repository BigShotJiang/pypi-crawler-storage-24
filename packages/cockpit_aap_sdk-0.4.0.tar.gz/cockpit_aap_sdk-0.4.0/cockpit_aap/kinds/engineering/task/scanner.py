"""kind: Task scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


TaskKind = define_kind(
    kind="Task",
    api_version="cockpit.io/v1",
    domain="engineering",
    description="A declarative task definition assigned to an agent.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
