"""Register all core domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .module import ModuleKind
from .agent import AgentKind
from .soul import SoulKind
from .persona import PersonaKind
from .skill import SkillKind


def register_core_kinds(registry: KindRegistry) -> None:
    """Register all core kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(registry, ModuleKind, AgentKind, SoulKind, PersonaKind, SkillKind)
