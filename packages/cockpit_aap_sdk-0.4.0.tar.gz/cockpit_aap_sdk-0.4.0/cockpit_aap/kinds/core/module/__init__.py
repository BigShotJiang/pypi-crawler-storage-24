"""kind: Module scanner definition."""

from .scanner import ModuleKind

__all__ = ["ModuleKind"]
