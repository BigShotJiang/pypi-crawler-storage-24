"""kind: Module scanner — wraps the existing manifest scanner."""

from cockpit_aap.kinds._shared.define_kind import define_kind
from cockpit_aap.manifest.scanner import scan_manifest


ModuleKind = define_kind(
    kind="Module",
    api_version="cockpit.io/v1",
    domain="core",
    description="A Cockpit module manifest — defines the full spec for a deployable module.",
    fields=[
        {"path": "metadata.name", "type": "string", "required": True, "description": "kebab-case module id"},
        {"path": "metadata.displayName", "type": "string", "description": "human-readable module name"},
        {"path": "metadata.version", "type": "string", "required": True, "description": "semver version"},
        {"path": "metadata.description", "type": "string", "description": "short module description"},
        {"path": "metadata.icon", "type": "string", "description": "Lucide icon name"},
        {"path": "metadata.group", "type": "string", "description": "sidebar group label"},
        {"path": "metadata.route", "type": "string", "description": "app route path"},
        {"path": "metadata.artifactPrefix", "type": "string", "required": True, "description": "prefix for all artifact keys"},
        {"path": "spec.agents[].id", "type": "string", "required": True, "description": "agent kebab-case id"},
        {"path": "spec.agents[].kind", "type": "string", "description": "agent kind"},
        {"path": "spec.agents[].instruction", "type": "string", "description": "inline instruction or file ref"},
        {"path": "spec.artifacts[].key", "type": "string", "required": True, "description": "artifact key"},
        {"path": "spec.artifacts[].defaultValue", "type": "string", "description": "default value or file ref"},
        {"path": "spec.artifacts[].category", "type": "string", "description": "artifact category"},
        {"path": "spec.i18n.defaultLocale", "type": "string", "description": "default locale code"},
        {"path": "spec.i18n.locales", "type": "object", "description": "locale overrides"},
        {"path": "spec.theme.default", "type": "string", "description": "default theme preset id"},
        {"path": "spec.theme.presets", "type": "object", "description": "theme presets record"},
        {"path": "spec.connections[].id", "type": "string", "required": True, "description": "connection id"},
        {"path": "spec.connections[].transport", "type": "string", "description": "connection transport"},
    ],
    scan=lambda dir_path: scan_manifest(dir_path),
    sample={
        "apiVersion": "cockpit.io/v1",
        "kind": "Module",
        "metadata": {
            "name": "my-module",
            "displayName": "My Module",
            "version": "1.0.0",
            "artifactPrefix": "my-module.",
        },
        "spec": {
            "agents": [{"id": "assistant", "kind": "BuiltInAgent", "instruction": "You are a helpful assistant."}],
            "artifacts": [{"key": "my-module.config.settings", "defaultValue": "{}", "category": "configuration"}],
        },
    },
)
