"""kind: Persona scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


PersonaKind = define_kind(
    kind="Persona",
    api_version="soulspec.org/v1",
    domain="core",
    description="A complete AI persona package combining role, soul, and identity.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
