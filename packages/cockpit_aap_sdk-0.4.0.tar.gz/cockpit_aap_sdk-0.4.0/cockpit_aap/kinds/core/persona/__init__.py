"""kind: Persona scanner definition."""

from .scanner import PersonaKind

__all__ = ["PersonaKind"]
