"""kind: Skill scanner definition."""

from .scanner import SkillKind

__all__ = ["SkillKind"]
