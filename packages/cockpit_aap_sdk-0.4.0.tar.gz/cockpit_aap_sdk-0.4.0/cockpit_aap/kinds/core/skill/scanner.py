"""kind: Skill scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


SkillKind = define_kind(
    kind="Skill",
    api_version="agentskills.io/v1",
    domain="core",
    description="A reusable, composable agent skill — a named instruction fragment.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
