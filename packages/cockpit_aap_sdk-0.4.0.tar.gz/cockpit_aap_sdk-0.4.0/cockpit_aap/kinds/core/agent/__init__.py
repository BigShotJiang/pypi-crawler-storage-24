"""kind: Agent scanner definition."""

from .scanner import AgentKind

__all__ = ["AgentKind"]
