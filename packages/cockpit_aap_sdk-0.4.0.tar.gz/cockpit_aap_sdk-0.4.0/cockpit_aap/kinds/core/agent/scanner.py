"""kind: Agent scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


AgentKind = define_kind(
    kind="Agent",
    api_version="agents.md/v1",
    domain="core",
    description="An AI agent with instructions, persona, tools, and optional sub-agents.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
