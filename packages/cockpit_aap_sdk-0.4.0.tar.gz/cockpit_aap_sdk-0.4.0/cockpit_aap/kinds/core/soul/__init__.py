"""kind: Soul scanner definition."""

from .scanner import SoulKind

__all__ = ["SoulKind"]
