"""kind: Soul scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


SoulKind = define_kind(
    kind="Soul",
    api_version="soul.md/v1",
    domain="core",
    description="AI identity manifest — defines who an agent chooses to be: values, traits, boundaries.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
