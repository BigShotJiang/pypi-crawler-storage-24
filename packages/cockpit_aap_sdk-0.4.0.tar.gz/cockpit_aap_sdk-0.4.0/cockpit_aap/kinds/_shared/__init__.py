"""Shared utilities for kind definitions."""

from .define_kind import define_kind, infer_domain
from .register import register_kind, register_kinds

__all__ = ["define_kind", "infer_domain", "register_kind", "register_kinds"]
