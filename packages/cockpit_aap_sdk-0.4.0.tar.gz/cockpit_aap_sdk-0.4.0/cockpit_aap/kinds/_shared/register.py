"""Shared kind registration helpers.

Eliminates the duplicated ``_register()`` function that was copy-pasted
across every domain ``__init__.py``.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry


def register_kind(registry: KindRegistry, kind_def: dict) -> None:
    """Register a single kind definition dict into the registry.

    Skips silently if the kind is already registered (idempotent).

    Args:
        registry: The :class:`KindRegistry` instance.
        kind_def: A dict produced by :func:`define_kind` with keys
            ``kind``, ``api_version``, ``description``, ``fields``,
            and optional ``scan``, ``parse``, ``sample``,
            ``default_template``.
    """
    from cockpit_aap.manifest.kind_registry import KindFieldSchema

    if registry.is_registered(kind_def["kind"]):
        return
    fields = [
        KindFieldSchema(
            path=f["path"],
            type=f["type"],
            description=f.get("description"),
            required=f.get("required", False),
            enum=f.get("enum"),
            content_type=f.get("content_type"),
            kind_ref=f.get("kind_ref"),
        )
        for f in kind_def["fields"]
    ]
    registry.register(
        kind_def["kind"],
        api_version=kind_def["api_version"],
        description=kind_def["description"],
        fields=fields,
        scan_fn=kind_def.get("scan"),
        parse_fn=kind_def.get("parse"),
        sample=kind_def.get("sample"),
        default_template=kind_def.get("default_template"),
    )


def register_kinds(registry: KindRegistry, *kind_defs: dict) -> None:
    """Register multiple kind definitions into the registry.

    Convenience wrapper that calls :func:`register_kind` for each
    definition in order.

    Args:
        registry: The :class:`KindRegistry` instance.
        *kind_defs: One or more kind definition dicts.
    """
    for kind_def in kind_defs:
        register_kind(registry, kind_def)
