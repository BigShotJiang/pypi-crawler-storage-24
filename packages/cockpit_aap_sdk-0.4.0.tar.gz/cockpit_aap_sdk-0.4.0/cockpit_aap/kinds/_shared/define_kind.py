"""Factory for defining AAP SDK kinds with minimal boilerplate.

Mirrors the TypeScript ``defineKind()`` in
``packages/bootstrap/src/kinds/_shared/define-kind.ts``.
"""

from __future__ import annotations

import os
from typing import Any, Callable, Optional

import yaml


def infer_domain(api_version: str) -> str:
    """Infer domain from apiVersion string.

    Examples::

        infer_domain("governance.cockpit.io/v1")  # → "governance"
        infer_domain("cockpit.io/v1")              # → "core"
        infer_domain("agents.md/v1")               # → "agents"
    """
    host = api_version.split("/")[0]
    parts = host.split(".")
    if len(parts) >= 3:
        return parts[0]
    if host == "cockpit.io":
        return "core"
    return parts[0]


def _default_scan(
    kind: str,
    api_version: str,
    after_scan: Callable[[dict, str], dict] | None = None,
) -> Callable[[str], dict]:
    """Create a default scan function that reads manifest.yaml, validates, and optionally transforms."""

    def scan(dir_path: str) -> dict[str, Any]:
        abs_dir = os.path.abspath(dir_path)
        manifest_file = os.path.join(abs_dir, "manifest.yaml")
        if not os.path.exists(manifest_file):
            raise FileNotFoundError(f"No manifest.yaml found in {abs_dir}")
        with open(manifest_file, "r", encoding="utf-8") as f:
            doc = yaml.safe_load(f)
        if not isinstance(doc, dict):
            raise ValueError(f"Expected YAML mapping for kind={kind}, got {type(doc).__name__}")
        if doc.get("apiVersion") != api_version:
            raise ValueError(
                f'Expected apiVersion "{api_version}", got "{doc.get("apiVersion")}"'
            )
        if doc.get("kind") != kind:
            raise ValueError(
                f'Expected kind "{kind}", got "{doc.get("kind")}"'
            )
        if after_scan:
            result = after_scan(doc, abs_dir)
            if result is not None:
                doc = result
        return doc

    scan.__name__ = f"scan_{kind.lower()}_manifest"
    scan.__qualname__ = f"scan_{kind.lower()}_manifest"
    return scan


def _default_parse(kind: str) -> Callable[[str], dict]:
    """Create a default parse function that yaml.safe_loads content."""

    def parse(yaml_content: str) -> dict[str, Any]:
        data = yaml.safe_load(yaml_content)
        if not isinstance(data, dict):
            raise ValueError(f"Expected YAML mapping for kind={kind}, got {type(data).__name__}")
        return data

    parse.__name__ = f"parse_{kind.lower()}_yaml"
    parse.__qualname__ = f"parse_{kind.lower()}_yaml"
    return parse


def define_kind(
    *,
    kind: str,
    api_version: str,
    description: str,
    fields: list[dict[str, Any]],
    domain: Optional[str] = None,
    scan: Optional[Callable] = None,
    parse: Optional[Callable] = None,
    after_scan: Optional[Callable] = None,
    sample: Optional[dict] = None,
    default_template: Optional[str] = None,
) -> dict[str, Any]:
    """Define a kind with auto-generated scan/parse functions.

    Returns a dict with all kind metadata ready for registration via
    :meth:`KindRegistry.register`.

    Args:
        kind:             Kind name (e.g. ``"Agent"``, ``"Pipeline"``).
        api_version:      Expected apiVersion (e.g. ``"cockpit.io/v1"``).
        description:      Human-readable description.
        fields:           Field schema dicts (``path``, ``type``, ``required``, etc.).
        domain:           Domain override — inferred from *api_version* if omitted.
        scan:             Custom scan function (directory → manifest dict).
        parse:            Custom parse function (YAML string → manifest dict).
        after_scan:       Post-scan hook for the auto-generated scanner.
        sample:           Example manifest dict for LLM context / docs.
        default_template: Handlebars template string for rendering this kind.

    Returns:
        Dict with keys: ``kind``, ``api_version``, ``domain``, ``description``,
        ``fields``, ``scan``, ``parse``, ``sample``, ``default_template``.
    """
    return {
        "kind": kind,
        "api_version": api_version,
        "domain": domain or infer_domain(api_version),
        "description": description,
        "fields": fields,
        "scan": scan or _default_scan(kind, api_version, after_scan),
        "parse": parse or _default_parse(kind),
        "sample": sample,
        "default_template": default_template,
    }
