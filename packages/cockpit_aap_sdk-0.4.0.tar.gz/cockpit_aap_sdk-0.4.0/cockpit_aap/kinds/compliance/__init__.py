"""Register all compliance domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .audit_trail import AuditTrailKind
from .certificate import CertificateKind
from .compliance import ComplianceKind


def register_compliance_kinds(registry: KindRegistry) -> None:
    """Register all compliance kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(registry, AuditTrailKind, CertificateKind, ComplianceKind)
