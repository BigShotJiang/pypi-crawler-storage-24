"""kind: Compliance scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


ComplianceKind = define_kind(
    kind="Compliance",
    api_version="governance.cockpit.io/v1",
    domain="compliance",
    description="Compliance posture mapping — frameworks, controls, exemptions.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
