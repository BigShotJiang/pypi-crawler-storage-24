"""kind: Compliance scanner definition."""

from .scanner import ComplianceKind

__all__ = ["ComplianceKind"]
