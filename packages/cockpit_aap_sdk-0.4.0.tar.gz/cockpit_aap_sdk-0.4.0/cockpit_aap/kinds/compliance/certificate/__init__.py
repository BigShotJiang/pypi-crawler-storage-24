"""kind: Certificate scanner definition."""

from .scanner import CertificateKind

__all__ = ["CertificateKind"]
