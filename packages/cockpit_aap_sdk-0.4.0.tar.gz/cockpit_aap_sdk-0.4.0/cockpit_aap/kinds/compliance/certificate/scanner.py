"""kind: Certificate scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


CertificateKind = define_kind(
    kind="Certificate",
    api_version="governance.cockpit.io/v1",
    domain="compliance",
    description="A compliance/governance certificate — formal attestation.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
