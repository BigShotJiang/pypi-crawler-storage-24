"""kind: AuditTrail scanner definition."""

from .scanner import AuditTrailKind

__all__ = ["AuditTrailKind"]
