"""kind: AuditTrail scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


AuditTrailKind = define_kind(
    kind="AuditTrail",
    api_version="governance.cockpit.io/v1",
    domain="compliance",
    description="Immutable audit trail — chronological governance event evidence log.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
