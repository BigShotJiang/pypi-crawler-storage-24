"""kind: MCPServer scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


MCPServerKind = define_kind(
    kind="MCPServer",
    api_version="modelcontextprotocol.io/v1",
    domain="mcp",
    description="A full MCP server hosting tools, resources, and prompts.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
