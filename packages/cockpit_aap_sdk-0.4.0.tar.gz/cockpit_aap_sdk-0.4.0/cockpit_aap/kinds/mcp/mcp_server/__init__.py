"""kind: MCPServer scanner definition."""

from .scanner import MCPServerKind

__all__ = ["MCPServerKind"]
