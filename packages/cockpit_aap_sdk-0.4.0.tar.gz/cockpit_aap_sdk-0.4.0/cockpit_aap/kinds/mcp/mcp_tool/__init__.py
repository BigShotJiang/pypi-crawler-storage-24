"""kind: MCPTool scanner definition."""

from .scanner import MCPToolKind

__all__ = ["MCPToolKind"]
