"""kind: MCPTool scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


MCPToolKind = define_kind(
    kind="MCPTool",
    api_version="modelcontextprotocol.io/v1",
    domain="mcp",
    description="A single MCP tool — a function an AI can call via MCP.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
