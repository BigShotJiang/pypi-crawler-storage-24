"""kind: Prompt scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


PromptKind = define_kind(
    kind="Prompt",
    api_version="prompty.ai/v1",
    domain="mcp",
    description="A reusable, versioned prompt template with typed inputs.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
