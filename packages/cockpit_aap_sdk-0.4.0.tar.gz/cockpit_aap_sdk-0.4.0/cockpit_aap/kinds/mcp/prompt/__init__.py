"""kind: Prompt scanner definition."""

from .scanner import PromptKind

__all__ = ["PromptKind"]
