"""Register all mcp domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .mcp_server import MCPServerKind
from .mcp_tool import MCPToolKind
from .memory import MemoryKind
from .prompt import PromptKind


def register_mcp_kinds(registry: KindRegistry) -> None:
    """Register all mcp kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(registry, MCPServerKind, MCPToolKind, MemoryKind, PromptKind)
