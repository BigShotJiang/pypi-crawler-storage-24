"""kind: Memory scanner definition."""

from .scanner import MemoryKind

__all__ = ["MemoryKind"]
