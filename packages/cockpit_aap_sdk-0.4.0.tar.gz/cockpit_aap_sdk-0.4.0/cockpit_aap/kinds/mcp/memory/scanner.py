"""kind: Memory scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


MemoryKind = define_kind(
    kind="Memory",
    api_version="mif-spec.dev/v1",
    domain="mcp",
    description="A semantic, episodic, or procedural memory unit for AI agents.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
