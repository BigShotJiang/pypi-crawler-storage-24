"""AAP SDK Kind definitions — co-located per domain.

Each domain sub-package (core, governance, mcp, ...) contains one directory
per kind with a ``scanner.py`` that calls :func:`define_kind` and exports
a ``*Kind`` dict ready for registration.

Usage::

    from cockpit_aap.kinds import register_all_kinds
    from cockpit_aap.manifest.kind_registry import kind_registry

    register_all_kinds(kind_registry)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry


def register_all_kinds(registry: KindRegistry) -> None:
    """Register every built-in kind from all domains into *registry*."""
    from .core import register_core_kinds
    from .governance import register_governance_kinds
    from .mcp import register_mcp_kinds
    from .cards import register_cards_kinds
    from .observability import register_observability_kinds
    from .engineering import register_engineering_kinds
    from .quality import register_quality_kinds
    from .compliance import register_compliance_kinds
    from .lifecycle import register_lifecycle_kinds

    register_core_kinds(registry)
    register_governance_kinds(registry)
    register_mcp_kinds(registry)
    register_cards_kinds(registry)
    register_observability_kinds(registry)
    register_engineering_kinds(registry)
    register_quality_kinds(registry)
    register_compliance_kinds(registry)
    register_lifecycle_kinds(registry)
