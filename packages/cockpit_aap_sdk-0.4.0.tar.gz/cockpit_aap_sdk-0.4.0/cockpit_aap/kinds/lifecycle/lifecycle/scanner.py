"""kind: Lifecycle scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


LifecycleKind = define_kind(
    kind="Lifecycle",
    api_version="lifecycle.io/v1",
    domain="lifecycle",
    description="A reusable lifecycle/process policy — stages and item types.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
