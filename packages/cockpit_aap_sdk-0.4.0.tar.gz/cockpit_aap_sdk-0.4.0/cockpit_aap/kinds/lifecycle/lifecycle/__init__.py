"""kind: Lifecycle scanner definition."""

from .scanner import LifecycleKind

__all__ = ["LifecycleKind"]
