"""kind: KindDescriptor scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


KindDescriptorKind = define_kind(
    kind="KindDescriptor",
    api_version="registry.cockpit.io/v1",
    domain="lifecycle",
    description="Documents a registered kind — purpose, schema, relations, examples.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
