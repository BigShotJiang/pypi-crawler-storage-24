"""kind: KindDescriptor scanner definition."""

from .scanner import KindDescriptorKind

__all__ = ["KindDescriptorKind"]
