"""kind: SDLC scanner definition."""

from .scanner import SDLCKind

__all__ = ["SDLCKind"]
