"""kind: SDLC scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


SDLCKind = define_kind(
    kind="SDLC",
    api_version="sdlc.io/v1",
    domain="lifecycle",
    description="Software Development Lifecycle policy — gated phases, artifact requirements.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
