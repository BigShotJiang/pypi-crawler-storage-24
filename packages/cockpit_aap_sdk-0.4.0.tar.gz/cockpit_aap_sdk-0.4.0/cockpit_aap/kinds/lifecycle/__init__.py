"""Register all lifecycle domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .lifecycle import LifecycleKind
from .sdlc import SDLCKind
from .kind_descriptor import KindDescriptorKind
from .lens import LensKind


def register_lifecycle_kinds(registry: KindRegistry) -> None:
    """Register all lifecycle kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(registry, LifecycleKind, SDLCKind, KindDescriptorKind, LensKind)
