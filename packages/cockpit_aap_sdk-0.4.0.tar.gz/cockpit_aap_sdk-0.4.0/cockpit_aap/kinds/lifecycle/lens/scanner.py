"""kind: Lens scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


LensKind = define_kind(
    kind="Lens",
    api_version="cockpit.io/v1",
    domain="lifecycle",
    description="A visual template that renders manifest data using Handlebars.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
