"""kind: Lens scanner definition."""

from .scanner import LensKind

__all__ = ["LensKind"]
