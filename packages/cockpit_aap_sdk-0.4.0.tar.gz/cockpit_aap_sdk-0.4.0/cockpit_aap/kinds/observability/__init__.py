"""Register all observability domain kinds."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.kind_registry import KindRegistry

from .data_contract import DataContractKind
from .experiment import ExperimentKind
from .metric import MetricKind
from .model_card import ModelCardKind
from .telemetry_blueprint import TelemetryBlueprintKind
from .value_stream import ValueStreamKind


def register_observability_kinds(registry: KindRegistry) -> None:
    """Register all observability kinds into the given registry."""
    from cockpit_aap.kinds._shared import register_kinds

    register_kinds(
        registry,
        DataContractKind,
        ExperimentKind,
        MetricKind,
        ModelCardKind,
        TelemetryBlueprintKind,
        ValueStreamKind,
    )
