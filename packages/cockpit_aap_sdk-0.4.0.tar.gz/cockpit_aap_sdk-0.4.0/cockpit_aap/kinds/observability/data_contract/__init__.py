"""kind: DataContract scanner definition."""

from .scanner import DataContractKind

__all__ = ["DataContractKind"]
