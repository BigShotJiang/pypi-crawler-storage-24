"""kind: DataContract scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


DataContractKind = define_kind(
    kind="DataContract",
    api_version="datacontract.com/v3.0.0",
    domain="observability",
    description="Data product contract — models, quality SLAs, lineage, access policies.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
