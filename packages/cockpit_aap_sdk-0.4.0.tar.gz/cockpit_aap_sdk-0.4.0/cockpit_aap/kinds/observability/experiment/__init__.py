"""kind: Experiment scanner definition."""

from .scanner import ExperimentKind

__all__ = ["ExperimentKind"]
