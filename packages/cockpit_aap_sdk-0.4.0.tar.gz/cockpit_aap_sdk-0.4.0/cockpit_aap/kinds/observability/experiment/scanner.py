"""kind: Experiment scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


ExperimentKind = define_kind(
    kind="Experiment",
    api_version="cockpit.io/v1",
    domain="observability",
    description="An AI/ML experiment with hypothesis, variants, metrics, and results.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
