"""kind: ModelCard scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


ModelCardKind = define_kind(
    kind="ModelCard",
    api_version="ml.cockpit.io/v1",
    domain="observability",
    description="ML model transparency card — model details, intended use, evaluation metrics.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
