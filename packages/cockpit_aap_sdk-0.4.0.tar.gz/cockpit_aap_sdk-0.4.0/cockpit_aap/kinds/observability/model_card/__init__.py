"""kind: ModelCard scanner definition."""

from .scanner import ModelCardKind

__all__ = ["ModelCardKind"]
