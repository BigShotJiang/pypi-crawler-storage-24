"""kind: Metric scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


MetricKind = define_kind(
    kind="Metric",
    api_version="observability.cockpit.io/v1",
    domain="observability",
    description="An observable metric definition for AI systems — quality, safety, performance.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
