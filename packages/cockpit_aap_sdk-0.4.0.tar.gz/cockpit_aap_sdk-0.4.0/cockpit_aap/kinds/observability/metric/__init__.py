"""kind: Metric scanner definition."""

from .scanner import MetricKind

__all__ = ["MetricKind"]
