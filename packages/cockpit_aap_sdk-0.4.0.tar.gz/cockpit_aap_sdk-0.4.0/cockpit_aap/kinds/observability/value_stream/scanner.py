"""kind: ValueStream scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


ValueStreamKind = define_kind(
    kind="ValueStream",
    api_version="governance.cockpit.io/v1",
    domain="observability",
    description="Business value mapping — objectives, automation levels, ROI projections.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
