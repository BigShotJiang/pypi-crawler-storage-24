"""kind: ValueStream scanner definition."""

from .scanner import ValueStreamKind

__all__ = ["ValueStreamKind"]
