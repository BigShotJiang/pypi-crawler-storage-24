"""kind: TelemetryBlueprint scanner definition."""

from .scanner import TelemetryBlueprintKind

__all__ = ["TelemetryBlueprintKind"]
