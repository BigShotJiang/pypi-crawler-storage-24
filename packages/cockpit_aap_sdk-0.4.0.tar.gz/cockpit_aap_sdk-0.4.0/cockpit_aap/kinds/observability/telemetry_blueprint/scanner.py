"""kind: TelemetryBlueprint scanner definition."""

from cockpit_aap.kinds._shared.define_kind import define_kind


TelemetryBlueprintKind = define_kind(
    kind="TelemetryBlueprint",
    api_version="observability.cockpit.io/v1",
    domain="observability",
    description="Prescriptive OTEL instrumentation blueprint for AI agent modules.",
    fields=[],  # Fields registered via _definitions.py; kept empty to avoid duplication
)
