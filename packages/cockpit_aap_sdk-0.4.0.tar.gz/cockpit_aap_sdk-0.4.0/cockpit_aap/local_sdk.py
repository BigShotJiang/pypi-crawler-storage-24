"""JSON-file-backed SDK drop-in replacement for offline development.

Port of ``packages/bootstrap/src/local-sdk.ts``.
Stores artifacts and agents in ``{dir}/local-db.json``.
Implements the same tool signatures as the real Cockpit MCP server
so it can be passed directly to ``bootstrap_manifest()``.
"""

from __future__ import annotations

import json
import os
import re
import uuid
from typing import Any


DB_FILENAME = "local-db.json"
STANDARD_AGENT_TYPE_ID = "54f6d2dd-f745-4f75-b58e-a5eaeac32370"


class _LocalDb:
    """File-backed database storing artifacts and agents as JSON."""

    def __init__(self, dir_path: str) -> None:
        self._dir = dir_path
        self._file_path = os.path.join(dir_path, DB_FILENAME)

    def _load(self) -> dict[str, Any]:
        try:
            with open(self._file_path, encoding="utf-8") as fh:
                return json.load(fh)
        except FileNotFoundError:
            return {"artifacts": {}, "agents": {}}

    def _save(self, data: dict[str, Any]) -> None:
        os.makedirs(self._dir, exist_ok=True)
        with open(self._file_path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2)

    # ── Artifact tools ──────────────────────────────────────────────────

    async def get_artifact(self, *, key_pattern: str) -> dict[str, Any]:
        data = self._load()
        pattern = re.compile(key_pattern)
        artifacts = [
            v for v in data["artifacts"].values() if pattern.search(v["key"])
        ]
        return {"content": {"artifacts": artifacts}}

    async def create_artifact(
        self,
        *,
        key: str,
        value: str,
        conflict_strategy: str = "SKIP",
        description: str = "",
        artifact_type: str = "string",
        accessibility: str = "Namespace",
        tags: str = "",
        **_extra: Any,
    ) -> dict[str, Any]:
        data = self._load()
        existing = data["artifacts"].get(key)
        if existing and conflict_strategy == "SKIP":
            return {"content": existing}

        record = {
            "id": (existing or {}).get("id", str(uuid.uuid4())),
            "key": key,
            "value": value,
        }
        data["artifacts"][key] = record
        self._save(data)
        return {"content": record}

    async def update_artifact(
        self,
        *,
        id: str,
        value: str,
        promote_to_production: bool = True,
    ) -> dict[str, Any]:
        data = self._load()
        for entry in data["artifacts"].values():
            if entry.get("id") == id:
                entry["value"] = value
                data["artifacts"][entry["key"]] = entry
                self._save(data)
                return {"content": {"success": True}}
        return {"content": {"success": False}}

    # ── Agent tools ─────────────────────────────────────────────────────

    async def list_agent_types(self, **_: Any) -> dict[str, Any]:
        return {
            "content": {
                "agent_types": [
                    {"id": STANDARD_AGENT_TYPE_ID, "name": "Standard Agent"}
                ]
            }
        }

    async def create_utility_agent(
        self,
        *,
        name: str,
        instruction: str = "",
        description: str = "",
        objective: str = "",
        model: str = "azure-gpt-4o",
        type: str | None = None,
        type_id: str | None = None,
        agent_status: str | None = None,
        **_extra: Any,
    ) -> dict[str, Any]:
        data = self._load()
        agent_id = str(uuid.uuid4())
        data["agents"][agent_id] = {
            "id": agent_id,
            "name": name,
            "instruction": instruction,
            "description": description,
            "agent_type_id": type_id or STANDARD_AGENT_TYPE_ID,
        }
        self._save(data)
        # Real Cockpit doesn't return UUID — bootstrapper re-searches
        return {"content": {}}

    async def search_utility_agents(
        self,
        *,
        name_pattern: str = "",
        query: str = "",
        search_type: str = "name",
        **_extra: Any,
    ) -> dict[str, Any]:
        data = self._load()
        pattern = re.compile(name_pattern or query)
        utility_agents = [
            {"id": a["id"], "name": a["name"]}
            for a in data["agents"].values()
            if pattern.search(a["name"])
        ]
        return {"content": {"utility_agents": utility_agents}}

    async def get_full_utility_agent(
        self,
        *,
        utility_agent_id: str = "",
        agent_id: str = "",
        **_extra: Any,
    ) -> dict[str, Any]:
        data = self._load()
        aid = utility_agent_id or agent_id
        agent = data["agents"].get(aid)
        if not agent:
            return {"content": {}}
        return {"content": agent}


class _NamespaceProxy:
    """Attribute-based proxy so ``sdk.artifacts.get_artifact(...)`` works."""

    def __init__(self, methods: dict[str, Any]) -> None:
        self._methods = methods

    def __getattr__(self, name: str) -> Any:
        try:
            return self._methods[name]
        except KeyError:
            raise AttributeError(f"No tool '{name}' in namespace") from None


class LocalSdk:
    """JSON-backed SDK for offline development.

    Implements the same tool signatures as the real Cockpit MCP server
    so it can be passed directly to :func:`bootstrap_manifest`.

    Example::

        sdk = create_local_sdk(".aap/my-module")
        result = await bootstrap_manifest(sdk, manifest_path, module="my-module")
    """

    def __init__(self, dir_path: str) -> None:
        self._db = _LocalDb(dir_path)
        self.artifacts = _NamespaceProxy({
            "get_artifact": self._db.get_artifact,
            "create_artifact": self._db.create_artifact,
            "update_artifact": self._db.update_artifact,
        })
        self.agents = _NamespaceProxy({
            "list_agent_types": self._db.list_agent_types,
            "create_utility_agent": self._db.create_utility_agent,
            "search_utility_agents": self._db.search_utility_agents,
            "get_full_utility_agent": self._db.get_full_utility_agent,
        })

    def __getattr__(self, name: str) -> Any:
        """Allow access to additional namespaces (returns empty proxy)."""
        if name.startswith("_"):
            raise AttributeError(name)
        return _NamespaceProxy({})

    async def call_tool(self, namespace: str, tool_name: str, args: dict[str, Any]) -> dict[str, Any]:
        """Low-level tool call compatible with AAPGatewayClient interface."""
        ns = getattr(self, namespace, None)
        if ns is None:
            raise AttributeError(f"No namespace '{namespace}'")
        method = getattr(ns, tool_name, None)
        if method is None:
            raise AttributeError(f"No tool '{tool_name}' in namespace '{namespace}'")
        return await method(**args)


def create_local_sdk(dir_path: str) -> LocalSdk:
    """Factory — creates a JSON-backed SDK for offline development.

    Stores artifacts and agents in ``{dir_path}/local-db.json``.

    Example::

        from cockpit_aap import create_local_sdk, bootstrap_manifest

        sdk = create_local_sdk(".aap/my-module")
        result = await bootstrap_manifest(sdk, "path/to/manifest.yaml", module="my-module")
    """
    return LocalSdk(dir_path)
