"""CostEnforcer — in-memory budget enforcement with Prometheus sync."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Literal

from .policy import CostPolicyReader


@dataclass
class EnforcementResult:
    action: Literal["allow", "warn", "block"]
    spent: float
    limit: float
    message: str = ""


class CostEnforcer:
    """In-memory accumulator with periodic Prometheus sync."""

    def __init__(self, policy: CostPolicyReader):
        self.policy = policy
        self._accumulators: dict[str, float] = {}
        self._last_sync: float = 0.0
        self._sync_interval = policy.sync_interval

    def _scope_key(self, scope: str, **kwargs: str) -> str:
        parts = [scope]
        for k in sorted(kwargs):
            if kwargs[k]:
                parts.append(f"{k}={kwargs[k]}")
        return "|".join(parts)

    def record_spend(self, cost_usd: float, scope_keys: dict) -> None:
        """Post-call: increment in-memory accumulators."""
        scope = scope_keys.get("scope", "module")
        key = self._scope_key(scope, **{k: v for k, v in scope_keys.items() if k != "scope"})
        self._accumulators[key] = self._accumulators.get(key, 0.0) + cost_usd

    def check_budget(
        self,
        scope: str,
        *,
        agent_id: str | None = None,
        tenant_id: str | None = None,
        locale: str = "en",
    ) -> EnforcementResult:
        """Pre-call check. Returns allow|warn|block."""
        budget = self.policy.get_budget(scope, agent_id=agent_id)
        if not budget:
            return EnforcementResult(action="allow", spent=0, limit=0, message="No budget defined")

        limit = budget.get("daily", 0)
        if limit <= 0:
            return EnforcementResult(action="allow", spent=0, limit=0, message="No daily limit")

        key = self._scope_key(scope, agent_id=agent_id or "", tenant_id=tenant_id or "")
        spent = self._accumulators.get(key, 0.0)

        if spent >= limit:
            on_exceeded = budget.get("onExceeded", "warn")
            action = on_exceeded if on_exceeded in ("warn", "block") else "warn"
            return EnforcementResult(
                action=action,
                spent=spent, limit=limit,
                message=self.policy.get_message(action, locale, spent=spent, limit=limit),
            )

        warn_at = budget.get("warnAt", 1.0)
        if spent >= limit * warn_at:
            return EnforcementResult(
                action="warn", spent=spent, limit=limit,
                message=self.policy.get_message("warn", locale, spent=spent, limit=limit),
            )

        return EnforcementResult(action="allow", spent=spent, limit=limit)

    async def sync_from_prometheus(self) -> None:
        """Query Prometheus for actual totals. Resets accumulators to real values."""
        now = time.time()
        if now - self._last_sync < self._sync_interval:
            return

        try:
            import httpx

            endpoint = self.policy.prometheus_endpoint
            query = "sum(increase(aap_llm_cost_usd[1d]))"
            async with httpx.AsyncClient(timeout=5) as client:
                resp = await client.get(f"{endpoint}/api/v1/query", params={"query": query})
                if resp.status_code == 200:
                    data = resp.json()
                    val = data.get("data", {}).get("result", [{}])[0].get("value", [0, "0"])[1]
                    self._accumulators["module"] = float(val)
            self._last_sync = now
        except Exception:
            pass  # keep in-memory values on failure
