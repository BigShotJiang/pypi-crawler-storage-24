"""CostPolicy reader — parses CostPolicy spec and resolves budgets."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml


class CostPolicyReader:
    """Read-only access to CostPolicy spec fields."""

    def __init__(self, spec: dict[str, Any]):
        self._spec = spec
        self._models = spec.get("models", {})
        self._budgets = spec.get("budgets", [])
        self._enforcement = spec.get("enforcement", {})
        self._prometheus = spec.get("prometheus", {})
        self._messages = spec.get("messages", {})

    @classmethod
    def from_file(cls, policy_dir: str) -> "CostPolicyReader":
        path = Path(policy_dir) / "manifest.yaml"
        if not path.exists():
            raise FileNotFoundError(f"CostPolicy not found: {path}")
        raw = yaml.safe_load(path.read_text())
        if raw.get("kind") != "CostPolicy":
            raise ValueError(f"Expected CostPolicy, got {raw.get('kind')}")
        return cls(raw.get("spec", {}))

    def get_model_pricing(self, model: str) -> dict | None:
        return self._models.get(model)

    def calculate_cost(self, model: str, input_tokens: int, output_tokens: int) -> float:
        pricing = self._models.get(model)
        if not pricing:
            return 0.0
        return (input_tokens / 1000) * pricing.get("inputPer1k", 0) + \
               (output_tokens / 1000) * pricing.get("outputPer1k", 0)

    def get_budget(self, scope: str, *, agent_id: str | None = None) -> dict | None:
        if scope == "agent" and agent_id:
            exact = next((b for b in self._budgets if b["scope"] == "agent" and b.get("agentId") == agent_id), None)
            if exact:
                return exact
            return next((b for b in self._budgets if b["scope"] == "agent" and b.get("agentId") == "*"), None)
        return next((b for b in self._budgets if b["scope"] == scope), None)

    @property
    def prometheus_endpoint(self) -> str:
        return self._prometheus.get("endpoint", "http://localhost:9090")  # noqa: S105 — internal Prometheus endpoint, HTTPS configured via policy YAML

    @property
    def metric_prefix(self) -> str:
        return self._prometheus.get("metricPrefix", "aap.llm")

    @property
    def pre_call(self) -> bool:
        return self._enforcement.get("preCall", False)

    @property
    def cache_seconds(self) -> int:
        return self._enforcement.get("cacheSeconds", 30)

    @property
    def sync_interval(self) -> int:
        return self._enforcement.get("accumulatorSyncInterval", 60)

    def get_message(self, action: str, locale: str = "en", **kwargs: float) -> str:
        """Get a localized budget message from CostPolicy spec.messages."""
        templates = self._messages.get(action, {})
        template = templates.get(locale) or templates.get("en", "")
        if not template:
            # Fallback
            if action == "block":
                template = "Daily budget limit reached (${spent} / ${limit}). Contact your administrator."
            else:
                template = "Budget warning: ${spent} of ${limit} used ({percent}%)."
        # Replace placeholders
        spent = kwargs.get("spent", 0)
        limit = kwargs.get("limit", 0)
        percent = f"{spent / limit * 100:.0f}" if limit > 0 else "0"
        return (
            template
            .replace("${spent}", f"${spent:.2f}")
            .replace("${limit}", f"${limit:.2f}")
            .replace("{percent}", percent)
        )
