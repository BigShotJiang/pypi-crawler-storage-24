"""CostEmitter — OTEL counters + structured log. No Postgres."""
from __future__ import annotations

import uuid

try:
    from opentelemetry import metrics, trace
    _OTEL_AVAILABLE = True
except ImportError:
    _OTEL_AVAILABLE = False
    metrics = None  # type: ignore[assignment]
    trace = None  # type: ignore[assignment]

from ..logging.structured import emit_log
from .policy import CostPolicyReader


class CostEmitter:
    """Emit cost data to OTEL counters and structured logs."""

    def __init__(
        self,
        policy: CostPolicyReader,
        module_id: str,
        agent_id: str,
        tenant_id: str,
    ):
        self.policy = policy
        self.module_id = module_id
        self.agent_id = agent_id
        self.tenant_id = tenant_id
        if _OTEL_AVAILABLE:
            self._meter = metrics.get_meter("aap-cost")
            self._cost_counter = self._meter.create_counter("aap.llm.cost_usd", unit="USD")
            self._input_counter = self._meter.create_counter("aap.llm.input_tokens")
            self._output_counter = self._meter.create_counter("aap.llm.output_tokens")
            self._requests_counter = self._meter.create_counter("aap.llm.requests")
            self._budget_exceeded_counter = self._meter.create_counter("aap.budget.exceeded")
        else:
            self._meter = None
            self._cost_counter = None
            self._input_counter = None
            self._output_counter = None
            self._requests_counter = None
            self._budget_exceeded_counter = None

    def _labels(self, model: str) -> dict[str, str]:
        return {
            "aap.tenant.id": self.tenant_id,
            "aap.agent.id": self.agent_id,
            "aap.module.id": self.module_id,
            "gen_ai.request.model": model,
        }

    def emit(self, model: str, input_tokens: int, output_tokens: int) -> float:
        """Emit metrics + log. Returns calculated cost USD."""
        cost_usd = self.policy.calculate_cost(model, input_tokens, output_tokens)
        labels = self._labels(model)

        # OTEL counters (skip if opentelemetry not installed)
        if self._cost_counter is not None:
            self._cost_counter.add(float(cost_usd), labels)
            self._input_counter.add(input_tokens, labels)
            self._output_counter.add(output_tokens, labels)
            self._requests_counter.add(1, labels)

        # OTEL span attributes
        span = trace.get_current_span() if _OTEL_AVAILABLE else None
        if span and span.is_recording():
            span.set_attribute("gen_ai.usage.input_tokens", input_tokens)
            span.set_attribute("gen_ai.usage.output_tokens", output_tokens)
            span.set_attribute("gen_ai.usage.cost", float(cost_usd))
            span.set_attribute("gen_ai.response.model", model)

        # Structured log → Loki (audit trail)
        emit_log(
            "info", "llm_complete",
            service="agent", module=self.module_id,
            tenant_id=self.tenant_id, agent_id=self.agent_id,
            model=model, input_tokens=input_tokens, output_tokens=output_tokens,
            costUsd=cost_usd, tokenCount=input_tokens + output_tokens,
            request_id=str(uuid.uuid4()),
        )

        return cost_usd

    def emit_budget_event(self, action: str, spent: float, limit: float) -> None:
        """Emit budget exceeded/warning OTEL counter + structured log."""
        self._budget_exceeded_counter.add(1, {
            "aap.tenant.id": self.tenant_id,
            "aap.agent.id": self.agent_id,
            "aap.module.id": self.module_id,
            "aap.budget.action": action,
        })
        emit_log(
            "warn", "budget_exceeded",
            service="agent", module=self.module_id,
            tenant_id=self.tenant_id, agent_id=self.agent_id,
            spent=spent, limit=limit, action=action,
        )
