"""AAPContext — composition root for hexagonal architecture (Python).

Configure once at app startup. Only ``store`` is required.

Example — production::

    from cockpit_aap import AAPContext
    from cockpit_aap.adapters.openai_llm import create_openai_llm

    ctx = AAPContext(
        store=sdk,  # AAPGatewayClient satisfies ManifestStorePort structurally
        llm=create_openai_llm(api_key=os.environ["OPENAI_API_KEY"]),
    )

Example — offline dev / tests::

    from cockpit_aap import AAPContext
    from cockpit_aap.adapters import create_in_memory_adapter, create_noop_llm

    ctx = AAPContext(
        store=create_in_memory_adapter(),
        llm=create_noop_llm(),
    )
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass
class AAPContext:
    """Composition root — bundles all port adapters.

    Only ``store`` is required. All others default to None (SDK will
    use NoOp fallbacks or raise descriptive errors when a port is needed).
    """

    store: Any  # ManifestStorePort — required
    auth: Any | None = None  # AuthPort
    observability: Any | None = None  # ObservabilityPort
    llm: Any | None = None  # LLMPort
    session: Any | None = None  # SessionStorePort
    files: Any | None = None  # FileStoragePort
    embeddings: Any | None = None  # EmbeddingPort


def create_aap_context(
    store: Any,
    *,
    auth: Any | None = None,
    observability: Any | None = None,
    llm: Any | None = None,
    session: Any | None = None,
    files: Any | None = None,
    embeddings: Any | None = None,
) -> AAPContext:
    """Factory function alternative to AAPContext() dataclass."""
    return AAPContext(
        store=store,
        auth=auth,
        observability=observability,
        llm=llm,
        session=session,
        files=files,
        embeddings=embeddings,
    )
