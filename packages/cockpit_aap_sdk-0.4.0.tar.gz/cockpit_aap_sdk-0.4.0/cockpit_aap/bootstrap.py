"""Bootstrap orchestrator for Manifest with server synchronization.

Provides ``bootstrap_manifest()`` -- the manifest-only bootstrap that uses the
manifest YAML as the single source of truth.  Syncs with the MCP server's
``_meta.manifest`` artifact, compares versions, and bootstraps state
artifacts (get-or-create).

This is the Python equivalent of ``bootstrapManifest()`` in the TypeScript
bootstrap package.
"""

from __future__ import annotations

import re
import time
import logging
from dataclasses import dataclass, field
from typing import Any

import yaml

from .client import AAPGatewayClient
from .manifest.types import Manifest
from .manifest.scanner import scan_manifest
from .manifest.helpers import get_state_artifacts

logger = logging.getLogger(__name__)

DEFAULT_ARTIFACTS_NS = "artifacts"
META_KEY_SUFFIX = "._meta.manifest"


# ---------------------------------------------------------------------------
# Result types
# ---------------------------------------------------------------------------


@dataclass
class ResolvedAgent:
    """An agent resolved from the manifest with its instruction source."""

    name: str
    instruction: str
    source: str  # "server" or "default-fallback"


@dataclass
class ManifestResult:
    """Result of bootstrapping a manifest."""

    module: str
    manifest: Manifest
    manifest_source: str  # "server" or "local"
    duration_ms: float
    agents: dict[str, ResolvedAgent] = field(default_factory=dict)
    feedback: dict[str, Any] | None = None


# ---------------------------------------------------------------------------
# Version comparison
# ---------------------------------------------------------------------------


def is_newer_version(local: str, server: str) -> bool:
    """Compare semver version strings.

    Returns ``True`` if *local* is strictly newer than *server*.
    Splits on ``"."`` and compares each part numerically.
    """
    local_parts = [int(p) for p in local.split(".")]
    server_parts = [int(p) for p in server.split(".")]

    for i in range(max(len(local_parts), len(server_parts))):
        l_val = local_parts[i] if i < len(local_parts) else 0
        s_val = server_parts[i] if i < len(server_parts) else 0
        if l_val > s_val:
            return True
        if l_val < s_val:
            return False
    return False  # equal


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _escape_regex(s: str) -> str:
    """Escape regex special characters in *s*."""
    return re.escape(s)


def _resolve_agents(manifest: Manifest) -> dict[str, ResolvedAgent]:
    """Build an agents dict keyed by agent name from the manifest."""
    agents: dict[str, ResolvedAgent] = {}
    for agent in manifest.spec.agents or []:
        agents[agent.name] = ResolvedAgent(
            name=agent.name,
            instruction=agent.instruction,
            source="default-fallback",
        )
    return agents


async def _read_manifest_artifact(
    sdk: Any,
    namespace: str,
    key: str,
) -> str | None:
    """Read the manifest YAML string from a server artifact.

    Returns ``None`` if the artifact is not found or if the server call fails.
    """
    try:
        result = await sdk.call_tool(namespace, "get_artifact", {
            "key_pattern": f"^{_escape_regex(key)}$",
        })

        content = result.get("content")
        if not content or result.get("isError"):
            return None

        # Extract value from various response formats
        if isinstance(content, dict):
            # Check artifacts array
            artifacts = content.get("artifacts", [])
            if artifacts and isinstance(artifacts, list) and len(artifacts) > 0:
                val = artifacts[0].get("value")
                if val:
                    return val
            # Direct value
            if content.get("value"):
                return content["value"]
            if content.get("content"):
                return content["content"]
        if isinstance(content, str):
            return content
        return None
    except Exception as e:
        logger.debug("Failed to read manifest artifact %s: %s", key, e)
        return None


async def _write_manifest_artifact(
    sdk: Any,
    namespace: str,
    key: str,
    yaml_str: str,
    module_id: str,
) -> None:
    """Write manifest YAML to the server as an artifact."""
    try:
        await sdk.call_tool(namespace, "upsert_artifact", {
            "key": key,
            "value": yaml_str,
            "description": f'Manifest V2 definition for module "{module_id}"',
            "artifactType": "YAML",
            "accessibility": "Namespace",
        })
    except Exception as e:
        logger.warning("Failed to write manifest artifact %s: %s", key, e)


async def _bootstrap_state_artifact(
    sdk: Any,
    namespace: str,
    artifact: Any,
) -> None:
    """Get-or-create a single state artifact on the server."""
    try:
        result = await sdk.call_tool(namespace, "get_artifact", {
            "key_pattern": f"^{_escape_regex(artifact.key)}$",
        })
        content = result.get("content", {})
        # If artifact exists, skip creation
        if content and not result.get("isError"):
            artifacts_list = (
                content.get("artifacts", [])
                if isinstance(content, dict)
                else []
            )
            if artifacts_list:
                return

        # Create the artifact
        await sdk.call_tool(namespace, "upsert_artifact", {
            "key": artifact.key,
            "value": artifact.default_value,
            "description": artifact.description or "",
            "artifactType": artifact.artifact_type or "string",
            "accessibility": artifact.accessibility or "Namespace",
        })
    except Exception as e:
        logger.debug("Failed to bootstrap state artifact %s: %s", artifact.key, e)


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------


def _snake_to_camel(name: str) -> str:
    """Convert a snake_case field name back to camelCase for YAML output.

    Handles special cases that don't follow the simple pattern.
    """
    if name == "prompt_pills":
        return "prompt-pills"

    components = name.split("_")
    return components[0] + "".join(x.title() for x in components[1:])


def _to_camel_case_dict(data: Any) -> Any:
    """Recursively convert dict keys from snake_case to camelCase."""
    if isinstance(data, dict):
        result = {}
        for key, value in data.items():
            camel = _snake_to_camel(key)
            result[camel] = _to_camel_case_dict(value)
        return result
    if isinstance(data, list):
        return [_to_camel_case_dict(item) for item in data]
    return data


def _manifest_to_dict(manifest: Manifest) -> dict:
    """Convert a Manifest dataclass to a plain dict for YAML serialization.

    Emits new-format YAML (apiVersion/kind/metadata/spec).
    """
    from dataclasses import asdict

    d = asdict(manifest)

    # Build clean new-format output
    result: dict = {
        "apiVersion": d.get("api_version", "cockpit.io/v1"),
        "kind": d.get("kind", "Module"),
    }

    # metadata block
    meta = d.get("metadata") or {}
    metadata_out: dict = {}
    for snake, camel in [
        ("name", "name"),
        ("display_name", "displayName"),
        ("version", "version"),
        ("description", "description"),
        ("icon", "icon"),
        ("group", "group"),
        ("route", "route"),
        ("artifact_prefix", "artifactPrefix"),
        ("annotations", "annotations"),
    ]:
        val = meta.get(snake)
        if val is not None:
            metadata_out[camel] = val
    result["metadata"] = metadata_out

    # spec block — camelCase conversion of the spec fields
    spec = d.get("spec") or {}
    # Remove null/None-only keys to keep YAML clean
    spec_out: dict = {}
    for key, value in spec.items():
        if value is not None:
            camel = _snake_to_camel(key)
            spec_out[camel] = _to_camel_case_dict(value)
    result["spec"] = spec_out

    return result


# ---------------------------------------------------------------------------
# Server sync helpers (extracted for CC reduction)
# ---------------------------------------------------------------------------


async def _push_local_manifest(
    sdk: Any,
    namespace: str,
    meta_key: str,
    manifest: Manifest,
    module_id: str,
) -> None:
    """Serialize and push local manifest YAML to the server."""
    local_yaml = yaml.dump(
        _manifest_to_dict(manifest),
        default_flow_style=False,
        allow_unicode=True,
    )
    await _write_manifest_artifact(sdk, namespace, meta_key, local_yaml, module_id)


async def _compare_and_sync_versions(
    sdk: Any,
    namespace: str,
    meta_key: str,
    local_manifest: Manifest,
    module_id: str,
    server_yaml: str,
    verbose: bool,
) -> tuple[Manifest, str]:
    """Compare local vs server manifest versions and sync accordingly.

    Returns ``(active_manifest, source)`` where *source* is ``"local"`` or
    ``"server"``.
    """
    try:
        server_raw = yaml.safe_load(server_yaml)
        # Support both new format (metadata.version) and legacy (module.version)
        if server_raw.get("apiVersion") == "cockpit.io/v1":
            server_version = server_raw.get("metadata", {}).get("version", "0.0.0")
        else:
            server_version = server_raw.get("module", {}).get("version", "0.0.0")
        local_version = local_manifest.metadata.version or "0.0.0"

        if is_newer_version(local_version, server_version):
            if verbose:
                logger.info(
                    "Local version %s > server %s, pushing to server",
                    local_version,
                    server_version,
                )
            await _push_local_manifest(
                sdk, namespace, meta_key, local_manifest, module_id
            )
            return local_manifest, "local"

        # Server wins (same version or newer)
        active = Manifest.from_dict(server_raw)
        if verbose:
            logger.info("Using server manifest (version %s)", server_version)
        return active, "server"
    except Exception as e:
        logger.warning("Failed to parse server manifest, using local: %s", e)
        return local_manifest, "local"


async def _sync_manifest_with_server(
    sdk: Any,
    namespace: str,
    meta_key: str,
    local_manifest: Manifest,
    module_id: str,
    verbose: bool,
) -> tuple[Manifest, str]:
    """Sync local manifest with the server.

    Returns ``(active_manifest, source)`` where *source* is ``"local"`` or
    ``"server"``.  Falls back to local on any server error.
    """
    try:
        server_yaml = await _read_manifest_artifact(sdk, namespace, meta_key)

        if not server_yaml:
            if verbose:
                logger.info("No manifest on server, pushing local")
            await _push_local_manifest(
                sdk, namespace, meta_key, local_manifest, module_id
            )
            return local_manifest, "local"

        return await _compare_and_sync_versions(
            sdk, namespace, meta_key, local_manifest, module_id, server_yaml, verbose
        )
    except Exception as e:
        logger.debug("Server unreachable, using local manifest: %s", e)
        return local_manifest, "local"


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------


async def bootstrap_manifest(
    sdk: Any,
    manifest_path: str,
    *,
    namespace: str = DEFAULT_ARTIFACTS_NS,
    verbose: bool = False,
    concurrency: int = 5,
    cache_ttl: int = 300_000,
) -> ManifestResult:
    """Bootstrap a module from its manifest directory.

    This is the manifest-only bootstrap -- the manifest YAML is the single
    source of truth.  No individual configuration artifacts are created.

    Flow:
        1. Scan local manifest YAML via ``scan_manifest()``
        2. Try to read ``_meta.manifest`` artifact from the server
        3. Version comparison: local wins if newer, server wins otherwise
        4. Bootstrap state artifacts (get-or-create only)
        5. Resolve agents from the manifest
        6. Return :class:`ManifestResult`

    Parameters
    ----------
    sdk:
        An ``AAPGatewayClient`` (or any object with an async ``call_tool``
        method) used for server communication.
    manifest_path:
        Path to the directory containing ``manifest.yaml`` (multi-file) or
        ``manifest.yaml`` (single-file).
    namespace:
        Artifact namespace on the server.  Default: ``"artifacts"``.
    verbose:
        Log progress to the logger at INFO level.
    concurrency:
        (Reserved) Max concurrent server calls.
    cache_ttl:
        (Reserved) Cache TTL in milliseconds.
    """
    _ = concurrency  # Reserved for future use
    _ = cache_ttl  # Reserved for future use
    start = time.monotonic()

    # Step 1: Scan local manifest
    local_manifest = scan_manifest(manifest_path)
    module_id = local_manifest.metadata.name
    meta_key = f"{module_id}{META_KEY_SUFFIX}"

    # Step 2: Sync with server
    active_manifest, manifest_source = await _sync_manifest_with_server(
        sdk, namespace, meta_key, local_manifest, module_id, verbose
    )

    # Step 3: Bootstrap state artifacts (get-or-create)
    state_artifacts = get_state_artifacts(active_manifest)
    for artifact in state_artifacts:
        await _bootstrap_state_artifact(sdk, namespace, artifact)

    # Step 4: Resolve agents
    agents = _resolve_agents(active_manifest)

    duration_ms = (time.monotonic() - start) * 1000

    return ManifestResult(
        module=module_id,
        manifest=active_manifest,
        manifest_source=manifest_source,
        duration_ms=duration_ms,
        agents=agents,
    )
