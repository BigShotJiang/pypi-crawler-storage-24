"""W3C Traceparent propagation helpers.

Uses opentelemetry.propagators.textmap when available. Gracefully
degrades to no-op when OTEL is not installed.
"""
from __future__ import annotations
from typing import Any


def extract_trace_context(headers: dict[str, str]) -> Any:
    """Extract OTEL Context from incoming HTTP headers."""
    try:
        from opentelemetry import context
        from opentelemetry.propagate import extract

        carrier = {k.lower(): v for k, v in headers.items()}
        return extract(carrier)
    except Exception:
        return None


def inject_trace_context(headers: dict[str, str]) -> dict[str, str]:
    """Inject traceparent into outbound HTTP headers."""
    try:
        from opentelemetry.propagate import inject

        result = dict(headers)
        inject(result)
        return result
    except Exception:
        return dict(headers)
