"""OTEL exporter initialization for AAP SDK apps.

Initializes both TracerProvider (traces) and MeterProvider (metrics).
Metrics are exported via OTLP HTTP to the same endpoint as traces.
"""
import os
from cockpit_aap.logging import emit_log


def init_exporter(service_name: str) -> bool:
    """Initialize OTEL TracerProvider + MeterProvider with OTLP HTTP exporters.

    Reads OTEL_EXPORTER_OTLP_ENDPOINT from env. No-op if not set.
    Call once at app startup before any tracing/metrics.
    Returns True if initialized, False if skipped.
    """
    endpoint = os.environ.get("OTEL_EXPORTER_OTLP_ENDPOINT")
    if not endpoint:
        return False

    try:
        from opentelemetry import trace, metrics
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.sdk.metrics import MeterProvider
        from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
        from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter

        resource = Resource.create({"service.name": service_name})

        # Traces
        trace_provider = TracerProvider(resource=resource)
        trace_exporter = OTLPSpanExporter(endpoint=f"{endpoint}/v1/traces")
        trace_provider.add_span_processor(BatchSpanProcessor(trace_exporter))
        trace.set_tracer_provider(trace_provider)

        # Metrics
        metric_exporter = OTLPMetricExporter(endpoint=f"{endpoint}/v1/metrics")
        metric_reader = PeriodicExportingMetricReader(metric_exporter, export_interval_millis=15000)
        meter_provider = MeterProvider(resource=resource, metric_readers=[metric_reader])
        metrics.set_meter_provider(meter_provider)

        emit_log("info", "otel_exporter_init", service=service_name, module="sdk",
                 endpoint=endpoint, features="traces+metrics")
        return True
    except Exception as e:
        emit_log("error", "otel_exporter_failed", service=service_name, module="sdk", error=str(e))
        return False
