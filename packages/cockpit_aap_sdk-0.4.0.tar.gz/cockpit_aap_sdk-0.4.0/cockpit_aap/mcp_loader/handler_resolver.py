"""
cockpit_aap.mcp_loader.handler_resolver — Code handler module resolver.

Resolves code handler declarations to actual callable Python functions.
The resolution protocol (same as TypeScript, adapted for Python):

  1. Per-language override: handler.py → exact path
  2. Explicit module ref: handler.module → resolved relative to handlers_dir
  3. Convention: tool name → handlers_dir/<snake_name>.py
"""

from __future__ import annotations

import importlib.util
import os
import re
import sys
from pathlib import Path
from typing import Any, Awaitable, Callable, Dict, Union

# A resolved handler function signature
ResolvedHandler = Callable[[Dict[str, Any]], Union[Any, Awaitable[Any]]]

PY_EXTENSIONS = [".py"]


async def resolve_code_handler(
    handler: Any,  # MCPServerCodeHandler (accepts dict or dataclass)
    tool_name: str,
    handlers_dir: str,
) -> ResolvedHandler:
    """
    Resolve a code handler declaration to a callable Python function.

    Args:
        handler: The handler declaration from the manifest (MCPServerCodeHandler or dict).
        tool_name: Tool name (used for convention-based resolution).
        handlers_dir: Base directory for handler modules (absolute).

    Returns:
        The resolved handler function.

    Raises:
        FileNotFoundError: If no module can be found.
        AttributeError: If the module has no handler export.
    """
    # Normalize handler to dict-like access
    py_path = _get_attr(handler, "py")
    module_ref = _get_attr(handler, "module")

    module_path = _find_module_path(py_path, module_ref, tool_name, handlers_dir)

    if module_path is None:
        raise FileNotFoundError(
            f'Cannot resolve code handler for tool "{tool_name}". '
            f"Tried convention ({_to_snake(tool_name)}) in {handlers_dir}. "
            + (f'Also tried explicit module "{module_ref}". ' if module_ref else "")
            + "Ensure the handler file exists."
        )

    fn = _load_handler_from_path(module_path, tool_name)
    return fn


def _get_attr(obj: Any, key: str) -> Any:
    """Get attribute from dataclass or dict."""
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)


def _find_module_path(
    py_path: str | None,
    module_ref: str | None,
    tool_name: str,
    handlers_dir: str,
) -> str | None:
    """Find the Python module path following the resolution protocol."""
    abs_dir = os.path.abspath(handlers_dir)

    # 1. Per-language override (Python)
    if py_path:
        candidate = os.path.join(abs_dir, py_path)
        found = _try_with_extensions(candidate)
        if found:
            return found

    # 2. Explicit module ref
    if module_ref:
        candidate = os.path.join(abs_dir, module_ref)
        found = _try_with_extensions(candidate)
        if found:
            return found

    # 3. Convention: tool_name → snake_case.py
    snake = _to_snake(tool_name)
    candidate = os.path.join(abs_dir, snake)
    found = _try_with_extensions(candidate)
    if found:
        return found

    # 4. Convention: tool_name → kebab-case.py
    kebab = _to_kebab(tool_name)
    candidate = os.path.join(abs_dir, kebab)
    found = _try_with_extensions(candidate)
    if found:
        return found

    return None


def _try_with_extensions(base_path: str) -> str | None:
    """Try appending Python extensions to find a file."""
    # Try exact path first
    if os.path.isfile(base_path):
        return base_path

    for ext in PY_EXTENSIONS:
        candidate = base_path + ext
        if os.path.isfile(candidate):
            return candidate

    # Try as package directory with __init__.py
    init_path = os.path.join(base_path, "__init__.py")
    if os.path.isfile(init_path):
        return init_path

    return None


def _load_handler_from_path(module_path: str, tool_name: str) -> ResolvedHandler:
    """
    Load a Python module from path and extract the handler function.

    Looks for (in order):
    1. ``handler`` named export
    2. ``default`` named export (matching TS convention)
    3. A function matching the tool name (snake_case)
    """
    module_name = f"_mcp_loader_handler_{_to_snake(tool_name)}"
    spec = importlib.util.spec_from_file_location(module_name, module_path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot create module spec from {module_path}")

    mod = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = mod
    spec.loader.exec_module(mod)  # type: ignore[union-attr]

    # 1. Named export: handler
    fn = getattr(mod, "handler", None)
    if callable(fn):
        return fn

    # 2. Named export: default (for TS-style default exports)
    fn = getattr(mod, "default", None)
    if callable(fn):
        return fn

    # 3. Function matching tool name
    snake_name = _to_snake(tool_name)
    fn = getattr(mod, snake_name, None)
    if callable(fn):
        return fn

    raise AttributeError(
        f'Module "{module_path}" for tool "{tool_name}" does not export a handler function. '
        'Expected a function named "handler", "default", or matching the tool name.'
    )


def _to_snake(name: str) -> str:
    """Convert PascalCase/kebab-case to snake_case."""
    s = re.sub(r"([a-z])([A-Z])", r"\1_\2", name)
    s = s.replace("-", "_")
    return s.lower()


def _to_kebab(name: str) -> str:
    """Convert PascalCase/snake_case to kebab-case."""
    s = re.sub(r"([a-z])([A-Z])", r"\1-\2", name)
    s = s.replace("_", "-")
    return s.lower()
