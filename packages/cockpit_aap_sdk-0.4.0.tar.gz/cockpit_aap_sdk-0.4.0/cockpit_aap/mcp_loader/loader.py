"""
cockpit_aap.mcp_loader.loader — Main entry point for manifest-driven MCP server loading.

Receives a parsed MCPServerManifest and registers its declared tools, prompts,
and resources on a FastMCP server instance.
"""

from __future__ import annotations

import os
from typing import Any, Dict, Optional, Union

from cockpit_aap.mcp_loader.types import (
    LoadOptions,
    LoadResult,
    MCPServerManifest,
)
from cockpit_aap.mcp_loader.tool_loader import load_tools
from cockpit_aap.mcp_loader.prompt_loader import load_prompts
from cockpit_aap.mcp_loader.resource_loader import load_resources
from cockpit_aap.mcp_loader.template_engine import create_template_engine


async def load_manifest_server(
    fmcp: Any,  # FastMCP instance
    manifest: Union[MCPServerManifest, Dict[str, Any]],
    options: Optional[LoadOptions] = None,
    *,
    handlers_dir: Optional[str] = None,
    template_helpers: Optional[Dict[str, Any]] = None,
    context_providers: Optional[Dict[str, Any]] = None,
    on_tool_registered: Optional[Any] = None,
    on_prompt_registered: Optional[Any] = None,
    on_resource_registered: Optional[Any] = None,
    on_error: Optional[Any] = None,
) -> LoadResult:
    """
    Load an MCP server from a parsed MCPServerManifest.

    Reads ``spec.tools[]``, ``spec.prompts[]``, ``spec.resources[]``, and
    ``spec.resourceTemplates[]`` from the manifest and registers them
    on the provided FastMCP instance.

    The manifest should come from a ManifestSourcePort adapter (e.g.,
    FileSystemManifestSource, PostgresManifestSource) — this function
    does NOT parse YAML or read files for manifest content.

    Args:
        fmcp: FastMCP server instance.
        manifest: Parsed MCPServerManifest (dataclass or raw dict).
        options: Configuration for handler resolution, templates, and callbacks.
        handlers_dir: Base directory for code handler modules (keyword shortcut).
        template_helpers: Custom template helpers (keyword shortcut).
        context_providers: Context providers injected into templates (keyword shortcut).
        on_tool_registered: Callback(name, type) after each tool registered (keyword shortcut).
        on_prompt_registered: Callback(name) after each prompt registered (keyword shortcut).
        on_resource_registered: Callback(name, uri) after each resource registered (keyword shortcut).
        on_error: Callback(name, error) when a declaration fails (keyword shortcut).

    Returns:
        LoadResult with lists of registered items and any errors.

    Example::

        from fastmcp import FastMCP
        from cockpit_aap.mcp_loader import load_manifest_server

        mcp = FastMCP("my-server")
        result = await load_manifest_server(mcp, manifest, handlers_dir="./tools")
        print(f"Loaded {len(result.tools)} tools, {len(result.prompts)} prompts")
    """
    # Merge keyword shortcuts into options
    if options is None:
        options = LoadOptions(
            handlers_dir=handlers_dir or "./tools",
            template_helpers=template_helpers,
            context_providers=context_providers,
            on_tool_registered=on_tool_registered,
            on_prompt_registered=on_prompt_registered,
            on_resource_registered=on_resource_registered,
            on_error=on_error,
        )

    # Parse manifest if it's a raw dict
    if isinstance(manifest, dict):
        manifest = MCPServerManifest.from_dict(manifest)

    spec = manifest.spec

    # Resolve handlers directory to absolute path
    resolved_handlers_dir = os.path.abspath(options.handlers_dir)

    # Create template engine
    engine = create_template_engine(
        helpers=options.template_helpers,
        context_providers=options.context_providers,
    )

    # Prepare callbacks
    tool_callbacks = {}
    if options.on_tool_registered:
        tool_callbacks["on_registered"] = options.on_tool_registered
    if options.on_error:
        tool_callbacks["on_error"] = options.on_error

    prompt_callbacks = {}
    if options.on_prompt_registered:
        prompt_callbacks["on_registered"] = options.on_prompt_registered
    if options.on_error:
        prompt_callbacks["on_error"] = options.on_error

    resource_callbacks = {}
    if options.on_resource_registered:
        resource_callbacks["on_registered"] = options.on_resource_registered
    if options.on_error:
        resource_callbacks["on_error"] = options.on_error

    # Extract declarations
    tools = spec.tools or []
    prompts_list = spec.prompts or []
    resources_list = spec.resources or []
    templates_list = spec.resource_templates or []

    # Load prompts (synchronous — no code resolution needed)
    prompt_result = load_prompts(
        fmcp, prompts_list, engine, prompt_callbacks or None
    )

    # Load resources (synchronous)
    resource_result = load_resources(
        fmcp, resources_list, templates_list, engine, resource_callbacks or None
    )

    # Load tools (async — code handlers need dynamic import)
    tool_result = await load_tools(
        fmcp, tools, resolved_handlers_dir, engine, tool_callbacks or None
    )

    return LoadResult(
        tools=tool_result.loaded,
        prompts=prompt_result.loaded,
        resources=resource_result.resources,
        resource_templates=resource_result.resource_templates,
        errors=[
            *tool_result.errors,
            *prompt_result.errors,
            *resource_result.errors,
        ],
    )
