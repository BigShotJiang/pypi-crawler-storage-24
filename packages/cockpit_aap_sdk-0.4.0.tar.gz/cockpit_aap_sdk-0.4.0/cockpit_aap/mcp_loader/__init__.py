"""
cockpit_aap.mcp_loader — Manifest-driven MCP server loader for Python.

Receives a parsed MCPServerManifest (from any ManifestSourcePort adapter:
filesystem, Postgres, etc.) and registers its declared tools, prompts, and
resources on a FastMCP server instance.

The manifest is parsed and file refs are resolved by the bootstrap scanner
BEFORE reaching this module. mcp_loader does zero YAML parsing or file I/O
for manifest content — it only resolves code handler modules at runtime.

Example::

    from fastmcp import FastMCP
    from cockpit_aap import create_filesystem_manifest_source
    from cockpit_aap.mcp_loader import load_manifest_server

    # 1. Load manifest through port/adapter (FS today, Postgres tomorrow)
    source = create_filesystem_manifest_source(".aap")
    manifest = await source.load("my-server", "MCPServer")

    # 2. Register on FastMCP
    mcp = FastMCP("my-server")
    result = await load_manifest_server(mcp, manifest, handlers_dir="./tools")

"""

from __future__ import annotations

from cockpit_aap.mcp_loader.types import (
    MCPServerManifest,
    MCPServerSpec,
    MCPServerToolDeclaration,
    MCPServerToolHandler,
    MCPServerCodeHandler,
    MCPServerTemplateHandler,
    MCPServerExpressionHandler,
    MCPServerPromptDeclaration,
    MCPServerPromptArgument,
    MCPServerResourceDeclaration,
    MCPServerResourceTemplateDeclaration,
    MCPServerJsonSchema,
    MCPServerJsonSchemaProperty,
    LoadOptions,
    LoadResult,
    LoadedToolEntry,
    LoadedPromptEntry,
    LoadedResourceEntry,
    LoadErrorEntry,
)
from cockpit_aap.mcp_loader.loader import load_manifest_server
from cockpit_aap.mcp_loader.tool_loader import load_tools
from cockpit_aap.mcp_loader.prompt_loader import load_prompts
from cockpit_aap.mcp_loader.resource_loader import load_resources
from cockpit_aap.mcp_loader.template_engine import create_template_engine
from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler

__all__ = [
    # Main entry
    "load_manifest_server",
    # Sub-loaders
    "load_tools",
    "load_prompts",
    "load_resources",
    # Template engine
    "create_template_engine",
    # Handler resolver
    "resolve_code_handler",
    # Types — manifest
    "MCPServerManifest",
    "MCPServerSpec",
    "MCPServerToolDeclaration",
    "MCPServerToolHandler",
    "MCPServerCodeHandler",
    "MCPServerTemplateHandler",
    "MCPServerExpressionHandler",
    "MCPServerPromptDeclaration",
    "MCPServerPromptArgument",
    "MCPServerResourceDeclaration",
    "MCPServerResourceTemplateDeclaration",
    "MCPServerJsonSchema",
    "MCPServerJsonSchemaProperty",
    # Types — loader
    "LoadOptions",
    "LoadResult",
    "LoadedToolEntry",
    "LoadedPromptEntry",
    "LoadedResourceEntry",
    "LoadErrorEntry",
]
