"""
cockpit_aap.mcp_loader.resource_loader — Resource registration on FastMCP.

Registers MCP resources and resource templates declared in the manifest
onto a FastMCP instance. Resources are ~95% declarative — content comes
from inline text or Jinja2 templates (already resolved by bootstrap scanner).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from cockpit_aap.mcp_loader.types import (
    LoadedResourceEntry,
    LoadErrorEntry,
    MCPServerResourceDeclaration,
    MCPServerResourceTemplateDeclaration,
)
from cockpit_aap.mcp_loader.template_engine import TemplateEngine


class ResourceLoadResult:
    """Result of loading resources."""

    __slots__ = ("resources", "resource_templates", "errors")

    def __init__(self) -> None:
        self.resources: List[LoadedResourceEntry] = []
        self.resource_templates: List[LoadedResourceEntry] = []
        self.errors: List[LoadErrorEntry] = []


def load_resources(
    fmcp: Any,  # FastMCP instance
    resources: List[MCPServerResourceDeclaration],
    resource_templates: List[MCPServerResourceTemplateDeclaration],
    engine: TemplateEngine,
    callbacks: Optional[Dict[str, Any]] = None,
) -> ResourceLoadResult:
    """
    Register all resource and resource template declarations onto FastMCP.

    Args:
        fmcp: FastMCP server instance.
        resources: Static resource declarations from parsed MCPServerManifest.
        resource_templates: Resource template declarations.
        engine: Template engine for resource template content.
        callbacks: Optional ``on_registered(name, uri)`` and ``on_error(name, error)`` callbacks.

    Returns:
        ResourceLoadResult with loaded resources, templates, and errors.
    """
    result = ResourceLoadResult()
    on_registered = callbacks.get("on_registered") if callbacks else None
    on_error = callbacks.get("on_error") if callbacks else None

    # ── Static Resources ─────────────────────────────────────────────

    for decl in resources:
        try:
            _register_static_resource(fmcp, decl)
            result.resources.append(LoadedResourceEntry(name=decl.name, uri=decl.uri))
            if on_registered:
                on_registered(decl.name, decl.uri)
        except Exception as exc:
            result.errors.append(
                LoadErrorEntry(name=decl.name, kind="resource", error=str(exc))
            )
            if on_error:
                on_error(decl.name, exc)

    # ── Resource Templates ───────────────────────────────────────────

    for decl in resource_templates:
        try:
            _register_template_resource(fmcp, decl, engine)
            result.resource_templates.append(
                LoadedResourceEntry(name=decl.name, uri=decl.uri_template)
            )
            if on_registered:
                on_registered(decl.name, decl.uri_template)
        except Exception as exc:
            result.errors.append(
                LoadErrorEntry(name=decl.name, kind="resourceTemplate", error=str(exc))
            )
            if on_error:
                on_error(decl.name, exc)

    return result


def _register_static_resource(
    fmcp: Any,
    decl: MCPServerResourceDeclaration,
) -> None:
    """Register a static resource."""
    content = decl.content or ""
    mime_type = decl.mime_type or "text/plain"

    # FastMCP resource decorator: @fmcp.resource(uri, name=, description=, mime_type=)
    async def _resource_handler() -> str:
        return content

    fmcp.resource(
        decl.uri,
        name=decl.name,
        description=decl.description or "",
        mime_type=mime_type,
    )(_resource_handler)


def _register_template_resource(
    fmcp: Any,
    decl: MCPServerResourceTemplateDeclaration,
    engine: TemplateEngine,
) -> None:
    """Register a resource template."""
    compiled = engine.compile(decl.template) if decl.template else None
    mime_type = decl.mime_type or "text/plain"

    # FastMCP resource template: use URI template string
    # The decorated function receives the URI params as keyword arguments
    async def _resource_handler(**kwargs: Any) -> str:
        if compiled:
            return compiled.render(kwargs)
        import json
        return json.dumps(kwargs, indent=2)

    fmcp.resource(
        decl.uri_template,
        name=decl.name,
        description=decl.description or "",
        mime_type=mime_type,
    )(_resource_handler)
