"""
cockpit_aap.mcp_loader.tool_loader — Tool registration on FastMCP.

Registers MCP tools declared in the manifest onto a FastMCP instance.
Supports three handler types:

  1. **code**       — imports a Python module and calls its handler function
  2. **template**   — compiles a Jinja2 template, renders with tool input
  3. **expression** — evaluates a Python expression with ``input`` in scope
"""

from __future__ import annotations

import asyncio
import inspect
from typing import Any, Callable, Dict, List, Optional, Tuple

from cockpit_aap.mcp_loader.types import (
    LoadedToolEntry,
    LoadErrorEntry,
    MCPServerToolDeclaration,
    MCPServerCodeHandler,
    MCPServerTemplateHandler,
    MCPServerExpressionHandler,
    MCPServerJsonSchema,
    MCPServerJsonSchemaProperty,
)
from cockpit_aap.mcp_loader.handler_resolver import resolve_code_handler
from cockpit_aap.mcp_loader.template_engine import TemplateEngine


class ToolLoadResult:
    """Result of loading tools."""

    __slots__ = ("loaded", "errors")

    def __init__(self) -> None:
        self.loaded: List[LoadedToolEntry] = []
        self.errors: List[LoadErrorEntry] = []


async def load_tools(
    fmcp: Any,  # FastMCP instance
    tools: List[MCPServerToolDeclaration],
    handlers_dir: str,
    engine: TemplateEngine,
    callbacks: Optional[Dict[str, Any]] = None,
) -> ToolLoadResult:
    """
    Register all tool declarations onto the FastMCP instance.

    Args:
        fmcp: FastMCP server instance.
        tools: Tool declarations from parsed MCPServerManifest.
        handlers_dir: Base directory for code handler resolution (absolute).
        engine: Template engine for template handlers.
        callbacks: Optional ``on_registered(name, type)`` and ``on_error(name, error)`` callbacks.

    Returns:
        ToolLoadResult with loaded tools and errors.
    """
    result = ToolLoadResult()
    on_registered = callbacks.get("on_registered") if callbacks else None
    on_error = callbacks.get("on_error") if callbacks else None

    for decl in tools:
        try:
            handler_type = _get_handler_type(decl.handler)

            if handler_type == "code":
                await _register_code_tool(fmcp, decl, handlers_dir)
            elif handler_type == "template":
                _register_template_tool(fmcp, decl, engine)
            elif handler_type == "expression":
                _register_expression_tool(fmcp, decl)

            result.loaded.append(LoadedToolEntry(name=decl.name, type=handler_type))
            if on_registered:
                on_registered(decl.name, handler_type)
        except Exception as exc:
            result.errors.append(
                LoadErrorEntry(name=decl.name, kind="tool", error=str(exc))
            )
            if on_error:
                on_error(decl.name, exc)

    return result


def _get_handler_type(handler: Any) -> str:
    """Extract handler type from handler object."""
    if isinstance(handler, dict):
        return handler.get("type", "code")
    return getattr(handler, "type", "code")


# ── Code Tool ────────────────────────────────────────────────────────────────


async def _register_code_tool(
    fmcp: Any,
    decl: MCPServerToolDeclaration,
    handlers_dir: str,
) -> None:
    """Resolve code handler module and register the tool."""
    handler_fn = await resolve_code_handler(decl.handler, decl.name, handlers_dir)

    # Build the wrapper that FastMCP expects
    async def _tool_handler(**kwargs: Any) -> Any:
        result = handler_fn(kwargs)
        if asyncio.iscoroutine(result) or asyncio.isfuture(result):
            result = await result
        return _to_tool_result(result)

    # Register on FastMCP using decorator-style API
    fmcp.tool(
        name=decl.name,
        description=decl.description,
    )(_tool_handler)


# ── Template Tool ────────────────────────────────────────────────────────────


def _register_template_tool(
    fmcp: Any,
    decl: MCPServerToolDeclaration,
    engine: TemplateEngine,
) -> None:
    """Register a template-based tool."""
    handler = decl.handler
    template_str = _get_attr(handler, "template")

    if not template_str:
        raise ValueError(
            f'Tool "{decl.name}" has handler.type "template" but template was not resolved. '
            f"Ensure template or templateFile is provided in the manifest and the scanner resolved it."
        )

    compiled = engine.compile(template_str)

    async def _tool_handler(**kwargs: Any) -> str:
        return compiled.render(kwargs)

    fmcp.tool(
        name=decl.name,
        description=decl.description,
    )(_tool_handler)


# ── Expression Tool ──────────────────────────────────────────────────────────


def _register_expression_tool(
    fmcp: Any,
    decl: MCPServerToolDeclaration,
) -> None:
    """Register an expression-based tool."""
    handler = decl.handler
    expr_str = _get_attr(handler, "expr")

    if not expr_str:
        raise ValueError(
            f'Tool "{decl.name}" has handler.type "expression" but no expr provided.'
        )

    # Use simpleeval for safe expression evaluation (already a project dependency)
    try:
        from simpleeval import simple_eval

        async def _tool_handler(**kwargs: Any) -> Any:
            result = simple_eval(expr_str, names={"input": kwargs, **kwargs})
            return _to_tool_result(result)
    except ImportError:
        # Fallback to Python's eval (less safe but functional)
        async def _tool_handler(**kwargs: Any) -> Any:  # type: ignore[misc]
            result = eval(expr_str, {"__builtins__": {}}, {"input": kwargs, **kwargs})
            return _to_tool_result(result)

    fmcp.tool(
        name=decl.name,
        description=decl.description,
    )(_tool_handler)


# ── Utilities ────────────────────────────────────────────────────────────────


def _get_attr(obj: Any, key: str) -> Any:
    """Get attribute from dataclass or dict."""
    if isinstance(obj, dict):
        return obj.get(key)
    return getattr(obj, key, None)


def _to_tool_result(result: Any) -> str:
    """Convert handler result to a string (FastMCP handles the MCP wrapping)."""
    if isinstance(result, str):
        return result
    import json
    return json.dumps(result, indent=2, default=str)
