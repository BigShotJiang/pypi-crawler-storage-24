"""
cockpit_aap.mcp_loader.prompt_loader — Prompt registration on FastMCP.

Registers MCP prompts declared in the manifest onto a FastMCP instance.
Prompts are 100% declarative — template + arguments, no code needed.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from cockpit_aap.mcp_loader.types import (
    LoadedPromptEntry,
    LoadErrorEntry,
    MCPServerPromptDeclaration,
)
from cockpit_aap.mcp_loader.template_engine import TemplateEngine


class PromptLoadResult:
    """Result of loading prompts."""

    __slots__ = ("loaded", "errors")

    def __init__(self) -> None:
        self.loaded: List[LoadedPromptEntry] = []
        self.errors: List[LoadErrorEntry] = []


def load_prompts(
    fmcp: Any,  # FastMCP instance
    prompts: List[MCPServerPromptDeclaration],
    engine: TemplateEngine,
    callbacks: Optional[Dict[str, Any]] = None,
) -> PromptLoadResult:
    """
    Register all prompt declarations onto the FastMCP instance.

    Args:
        fmcp: FastMCP server instance.
        prompts: Prompt declarations from parsed MCPServerManifest.
        engine: Template engine for prompt templates.
        callbacks: Optional ``on_registered(name)`` and ``on_error(name, error)`` callbacks.

    Returns:
        PromptLoadResult with loaded prompts and errors.
    """
    result = PromptLoadResult()
    on_registered = callbacks.get("on_registered") if callbacks else None
    on_error = callbacks.get("on_error") if callbacks else None

    for decl in prompts:
        try:
            _register_prompt(fmcp, decl, engine)
            result.loaded.append(LoadedPromptEntry(name=decl.name))
            if on_registered:
                on_registered(decl.name)
        except Exception as exc:
            result.errors.append(
                LoadErrorEntry(name=decl.name, kind="prompt", error=str(exc))
            )
            if on_error:
                on_error(decl.name, exc)

    return result


def _register_prompt(
    fmcp: Any,
    decl: MCPServerPromptDeclaration,
    engine: TemplateEngine,
) -> None:
    """Register a single prompt declaration."""
    # Compile template if present (already resolved from templateFile by bootstrap scanner)
    compiled = engine.compile(decl.template) if decl.template else None

    # FastMCP prompt decorator: @fmcp.prompt(name=, description=)
    # The decorated function receives keyword arguments matching prompt arguments
    async def _prompt_handler(**kwargs: Any) -> str:
        if compiled:
            return compiled.render(kwargs)

        # No template — return a basic prompt with the arguments
        parts = [f"{k}: {v}" for k, v in kwargs.items()]
        return "\n".join(parts)

    fmcp.prompt(
        name=decl.name,
        description=decl.description or "",
    )(_prompt_handler)
