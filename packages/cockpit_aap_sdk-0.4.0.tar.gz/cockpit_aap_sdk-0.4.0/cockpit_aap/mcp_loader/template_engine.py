"""
cockpit_aap.mcp_loader.template_engine — Jinja2 template engine wrapper.

Wraps Jinja2 compilation and rendering with built-in filters/globals.
Used for template-type tool handlers and prompt templates.

Python equivalent of the TypeScript Handlebars-based template engine.
Uses Jinja2 syntax: ``{{ name }}`` instead of ``{{name}}``.
"""

from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any, Callable, Dict, Optional, Protocol


class CompiledTemplate(Protocol):
    """A compiled template that can be rendered with input context."""

    def render(self, input: Dict[str, Any]) -> str:
        ...


class _Jinja2CompiledTemplate:
    """Jinja2-backed compiled template."""

    def __init__(
        self,
        template: Any,  # jinja2.Template
        context_providers: Dict[str, Callable[[Dict[str, Any]], Any]],
    ) -> None:
        self._template = template
        self._context_providers = context_providers

    def render(self, input: Dict[str, Any]) -> str:
        ctx: Dict[str, Any] = {**input}
        for key, provider in self._context_providers.items():
            ctx[key] = provider(input)
        return self._template.render(**ctx)


class _SimpleCompiledTemplate:
    """Fallback template engine using Python string formatting when Jinja2 is not available."""

    def __init__(
        self,
        template_source: str,
        context_providers: Dict[str, Callable[[Dict[str, Any]], Any]],
    ) -> None:
        self._source = template_source
        self._context_providers = context_providers

    def render(self, input: Dict[str, Any]) -> str:
        ctx: Dict[str, Any] = {**input}
        for key, provider in self._context_providers.items():
            ctx[key] = provider(input)

        # Simple {{ var }} substitution (handles both Jinja2 and Handlebars syntax)
        def _replace(match: re.Match[str]) -> str:
            key = match.group(1).strip()
            value = ctx.get(key, match.group(0))
            if isinstance(value, (dict, list)):
                return json.dumps(value, indent=2)
            return str(value)

        return re.sub(r"\{\{[\s]*([^}]+?)[\s]*\}\}", _replace, self._source)


# ── Built-in Jinja2 Filters ─────────────────────────────────────────────────

def _filter_json(value: Any) -> str:
    """Pretty-print as JSON."""
    return json.dumps(value, indent=2, default=str)


def _filter_json_compact(value: Any) -> str:
    """Single-line JSON."""
    return json.dumps(value, default=str)


def _filter_upper(value: Any) -> str:
    return str(value).upper()


def _filter_lower(value: Any) -> str:
    return str(value).lower()


def _filter_kebab_case(value: Any) -> str:
    """Convert to kebab-case."""
    s = str(value)
    s = re.sub(r"([a-z])([A-Z])", r"\1-\2", s)
    s = s.replace("_", "-")
    return s.lower()


def _filter_camel_case(value: Any) -> str:
    """Convert to camelCase."""
    s = str(value)
    s = re.sub(r"[-_]+(.)", lambda m: m.group(1).upper(), s)
    if s:
        s = s[0].lower() + s[1:]
    return s


def _filter_default(value: Any, fallback: Any = "") -> Any:
    """Return value or fallback if falsy."""
    return value if value else fallback


BUILTIN_FILTERS: Dict[str, Callable[..., Any]] = {
    "json": _filter_json,
    "json_compact": _filter_json_compact,
    "kebab_case": _filter_kebab_case,
    "camel_case": _filter_camel_case,
}

BUILTIN_GLOBALS: Dict[str, Callable[..., Any]] = {
    "now": lambda: datetime.now(timezone.utc).isoformat(),
}


# ── Template Engine Factory ──────────────────────────────────────────────────

class TemplateEngine:
    """Template engine that compiles and renders templates."""

    def __init__(
        self,
        helpers: Optional[Dict[str, Callable[..., Any]]] = None,
        context_providers: Optional[Dict[str, Callable[[Dict[str, Any]], Any]]] = None,
    ) -> None:
        self._context_providers = context_providers or {}
        self._use_jinja2 = False
        self._env: Any = None

        try:
            import jinja2

            self._use_jinja2 = True
            self._env = jinja2.Environment(
                undefined=jinja2.StrictUndefined,
                autoescape=False,
            )
            # Register built-in filters
            self._env.filters.update(BUILTIN_FILTERS)
            # Register built-in globals
            self._env.globals.update(BUILTIN_GLOBALS)
            # Register custom helpers as filters + globals
            if helpers:
                self._env.filters.update(helpers)
                self._env.globals.update(helpers)
        except ImportError:
            # Jinja2 not installed — use simple fallback
            self._use_jinja2 = False

    def compile(self, template_source: str) -> CompiledTemplate:
        """Compile a template string and return a renderable object."""
        if self._use_jinja2 and self._env is not None:
            tmpl = self._env.from_string(template_source)
            return _Jinja2CompiledTemplate(tmpl, self._context_providers)
        else:
            return _SimpleCompiledTemplate(template_source, self._context_providers)


def create_template_engine(
    helpers: Optional[Dict[str, Callable[..., Any]]] = None,
    context_providers: Optional[Dict[str, Callable[[Dict[str, Any]], Any]]] = None,
) -> TemplateEngine:
    """
    Create a template engine instance.

    Uses Jinja2 if available (``pip install jinja2``), otherwise falls back
    to simple ``{{ var }}`` substitution.

    Args:
        helpers: Custom template helpers (registered as Jinja2 filters + globals).
        context_providers: Context providers injected into every render call.

    Returns:
        A TemplateEngine with ``compile(source) -> CompiledTemplate``.
    """
    return TemplateEngine(helpers=helpers, context_providers=context_providers)
