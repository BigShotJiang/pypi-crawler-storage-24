"""
cockpit_aap.mcp_loader.types — Type definitions for MCP Loader.

Dataclass-based types mirroring the TypeScript MCPServer declaration types
from @ruinosus/aap-bootstrap. These types describe the declarative structure
of tools, prompts, and resources within an MCPServerManifest.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Union


# ── MCPServer JSON Schema Types ──────────────────────────────────────────────


@dataclass
class MCPServerJsonSchemaProperty:
    """A single property in a JSON Schema used by tool inputSchema."""

    type: str
    description: Optional[str] = None
    enum: Optional[List[str]] = None
    default: Any = None
    items: Optional[MCPServerJsonSchemaProperty] = None
    properties: Optional[Dict[str, MCPServerJsonSchemaProperty]] = None
    required: Optional[List[str]] = None
    minimum: Optional[float] = None
    maximum: Optional[float] = None
    min_length: Optional[int] = None
    max_length: Optional[int] = None
    pattern: Optional[str] = None
    format: Optional[str] = None
    optional: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerJsonSchemaProperty:
        """Parse from a raw dictionary (e.g., from YAML scan)."""
        items = None
        if "items" in data and isinstance(data["items"], dict):
            items = cls.from_dict(data["items"])

        props = None
        if "properties" in data and isinstance(data["properties"], dict):
            props = {k: cls.from_dict(v) for k, v in data["properties"].items()}

        return cls(
            type=data.get("type", "string"),
            description=data.get("description"),
            enum=data.get("enum"),
            default=data.get("default"),
            items=items,
            properties=props,
            required=data.get("required"),
            minimum=data.get("minimum"),
            maximum=data.get("maximum"),
            min_length=data.get("minLength"),
            max_length=data.get("maxLength"),
            pattern=data.get("pattern"),
            format=data.get("format"),
            optional=data.get("optional"),
        )


@dataclass
class MCPServerJsonSchema:
    """JSON Schema object type for tool inputSchema declarations."""

    type: str = "object"
    properties: Optional[Dict[str, MCPServerJsonSchemaProperty]] = None
    required: Optional[List[str]] = None
    additional_properties: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerJsonSchema:
        props = None
        if "properties" in data and isinstance(data["properties"], dict):
            props = {
                k: MCPServerJsonSchemaProperty.from_dict(v)
                for k, v in data["properties"].items()
            }
        return cls(
            type=data.get("type", "object"),
            properties=props,
            required=data.get("required"),
            additional_properties=data.get("additionalProperties"),
        )


# ── Handler Types ────────────────────────────────────────────────────────────


@dataclass
class MCPServerCodeHandler:
    """Code handler — loader resolves the Python module and calls the handler function."""

    type: str = "code"
    module: Optional[str] = None
    """Module path (relative to handlers_dir). Extension auto-resolved."""
    ts: Optional[str] = None
    py: Optional[str] = None
    cs: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerCodeHandler:
        return cls(
            type=data.get("type", "code"),
            module=data.get("module"),
            ts=data.get("ts"),
            py=data.get("py"),
            cs=data.get("cs"),
        )


@dataclass
class MCPServerTemplateHandler:
    """Template handler — renders a Jinja2 template with the tool input."""

    type: str = "template"
    template: Optional[str] = None
    """Inline template string (or resolved from templateFile by scanner)."""
    template_file: Optional[str] = None
    """Path to template file (resolved to ``template`` content by scanner)."""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerTemplateHandler:
        return cls(
            type=data.get("type", "template"),
            template=data.get("template"),
            template_file=data.get("templateFile"),
        )


@dataclass
class MCPServerExpressionHandler:
    """Expression handler — a Python expression evaluated with tool input as context."""

    type: str = "expression"
    expr: str = ""

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerExpressionHandler:
        return cls(
            type=data.get("type", "expression"),
            expr=data.get("expr", ""),
        )


# Union type for all handler types
MCPServerToolHandler = Union[
    MCPServerCodeHandler,
    MCPServerTemplateHandler,
    MCPServerExpressionHandler,
]


def _parse_handler(data: Dict[str, Any]) -> MCPServerToolHandler:
    """Parse a handler from a raw dict based on its ``type`` field."""
    handler_type = data.get("type", "code")
    if handler_type == "code":
        return MCPServerCodeHandler.from_dict(data)
    elif handler_type == "template":
        return MCPServerTemplateHandler.from_dict(data)
    elif handler_type == "expression":
        return MCPServerExpressionHandler.from_dict(data)
    else:
        raise ValueError(f"Unknown handler type: {handler_type}")


# ── Tool Declaration ─────────────────────────────────────────────────────────


@dataclass
class MCPServerToolDeclaration:
    """A tool declared in the MCPServer manifest ``spec.tools[]``."""

    name: str
    description: str
    title: Optional[str] = None
    input_schema: Optional[MCPServerJsonSchema] = None
    annotations: Optional[Dict[str, Any]] = None
    handler: MCPServerToolHandler = field(default_factory=lambda: MCPServerCodeHandler())

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerToolDeclaration:
        schema = None
        if "inputSchema" in data and isinstance(data["inputSchema"], dict):
            schema = MCPServerJsonSchema.from_dict(data["inputSchema"])

        handler_data = data.get("handler", {"type": "code"})
        handler = _parse_handler(handler_data) if isinstance(handler_data, dict) else MCPServerCodeHandler()

        return cls(
            name=data["name"],
            description=data.get("description", ""),
            title=data.get("title"),
            input_schema=schema,
            annotations=data.get("annotations"),
            handler=handler,
        )


# ── Prompt Declaration ───────────────────────────────────────────────────────


@dataclass
class MCPServerPromptArgument:
    """An argument for a declarative prompt."""

    name: str
    description: Optional[str] = None
    required: Optional[bool] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerPromptArgument:
        return cls(
            name=data["name"],
            description=data.get("description"),
            required=data.get("required"),
        )


@dataclass
class MCPServerPromptDeclaration:
    """A prompt declared in the MCPServer manifest ``spec.prompts[]``."""

    name: str
    description: Optional[str] = None
    arguments: Optional[List[MCPServerPromptArgument]] = None
    template: Optional[str] = None
    template_file: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerPromptDeclaration:
        args = None
        if "arguments" in data and isinstance(data["arguments"], list):
            args = [MCPServerPromptArgument.from_dict(a) for a in data["arguments"]]

        return cls(
            name=data["name"],
            description=data.get("description"),
            arguments=args,
            template=data.get("template"),
            template_file=data.get("templateFile"),
        )


# ── Resource Declarations ────────────────────────────────────────────────────


@dataclass
class MCPServerResourceDeclaration:
    """A static resource declared in the MCPServer manifest ``spec.resources[]``."""

    name: str
    uri: str
    description: Optional[str] = None
    mime_type: Optional[str] = None
    content: Optional[str] = None
    content_file: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerResourceDeclaration:
        return cls(
            name=data["name"],
            uri=data["uri"],
            description=data.get("description"),
            mime_type=data.get("mimeType"),
            content=data.get("content"),
            content_file=data.get("contentFile"),
        )


@dataclass
class MCPServerResourceTemplateDeclaration:
    """A resource template declared in the MCPServer manifest ``spec.resourceTemplates[]``."""

    name: str
    uri_template: str
    description: Optional[str] = None
    mime_type: Optional[str] = None
    template: Optional[str] = None
    template_file: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerResourceTemplateDeclaration:
        return cls(
            name=data["name"],
            uri_template=data.get("uriTemplate", ""),
            description=data.get("description"),
            mime_type=data.get("mimeType"),
            template=data.get("template"),
            template_file=data.get("templateFile"),
        )


# ── MCPServer Manifest Spec & Root ──────────────────────────────────────────


@dataclass
class MCPServerSpec:
    """Full spec for an MCPServer manifest, including declarative registrations."""

    transport: str = "streamable-http"
    endpoint: str = ""
    auth: str = "none"
    instruction: Optional[str] = None
    headers: Optional[Dict[str, str]] = None
    capabilities: Optional[List[str]] = None
    # Declarative registrations
    tools: Optional[List[MCPServerToolDeclaration]] = None
    prompts: Optional[List[MCPServerPromptDeclaration]] = None
    resources: Optional[List[MCPServerResourceDeclaration]] = None
    resource_templates: Optional[List[MCPServerResourceTemplateDeclaration]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerSpec:
        tools = None
        if "tools" in data and isinstance(data["tools"], list):
            tools = [MCPServerToolDeclaration.from_dict(t) for t in data["tools"]]

        prompts = None
        if "prompts" in data and isinstance(data["prompts"], list):
            prompts = [MCPServerPromptDeclaration.from_dict(p) for p in data["prompts"]]

        resources = None
        if "resources" in data and isinstance(data["resources"], list):
            resources = [MCPServerResourceDeclaration.from_dict(r) for r in data["resources"]]

        templates = None
        if "resourceTemplates" in data and isinstance(data["resourceTemplates"], list):
            templates = [MCPServerResourceTemplateDeclaration.from_dict(rt) for rt in data["resourceTemplates"]]

        return cls(
            transport=data.get("transport", "streamable-http"),
            endpoint=data.get("endpoint", ""),
            auth=data.get("auth", "none"),
            instruction=data.get("instruction"),
            headers=data.get("headers"),
            capabilities=data.get("capabilities"),
            tools=tools,
            prompts=prompts,
            resources=resources,
            resource_templates=templates,
        )


@dataclass
class MCPServerMetadata:
    """Metadata for an MCPServer manifest."""

    name: str
    display_name: Optional[str] = None
    version: Optional[str] = None
    description: Optional[str] = None
    icon: Optional[str] = None
    group: Optional[str] = None
    annotations: Optional[Dict[str, str]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerMetadata:
        return cls(
            name=data["name"],
            display_name=data.get("displayName"),
            version=data.get("version"),
            description=data.get("description"),
            icon=data.get("icon"),
            group=data.get("group"),
            annotations=data.get("annotations"),
        )


@dataclass
class MCPServerManifest:
    """Top-level MCPServer manifest (kind: MCPServer)."""

    api_version: str = "modelcontextprotocol.io/v1"
    kind: str = "MCPServer"
    metadata: MCPServerMetadata = field(default_factory=lambda: MCPServerMetadata(name=""))
    spec: MCPServerSpec = field(default_factory=MCPServerSpec)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> MCPServerManifest:
        metadata = MCPServerMetadata.from_dict(data.get("metadata", {"name": "unknown"}))
        spec = MCPServerSpec.from_dict(data.get("spec", {}))
        return cls(
            api_version=data.get("apiVersion", "modelcontextprotocol.io/v1"),
            kind=data.get("kind", "MCPServer"),
            metadata=metadata,
            spec=spec,
        )


# ── Load Options & Result ────────────────────────────────────────────────────


@dataclass
class LoadOptions:
    """Options for :func:`load_manifest_server`."""

    handlers_dir: str = "./tools"
    """Base directory for resolving code handler modules."""

    template_helpers: Optional[Dict[str, Callable[..., Any]]] = None
    """Custom Jinja2 filters to register."""

    context_providers: Optional[Dict[str, Callable[[Dict[str, Any]], Any]]] = None
    """Context providers injected into template rendering."""

    on_tool_registered: Optional[Callable[[str, str], None]] = None
    """Called after each tool is successfully registered."""

    on_prompt_registered: Optional[Callable[[str], None]] = None
    """Called after each prompt is successfully registered."""

    on_resource_registered: Optional[Callable[[str, str], None]] = None
    """Called after each resource is successfully registered."""

    on_error: Optional[Callable[[str, Exception], None]] = None
    """Called when a declaration fails to register."""


@dataclass
class LoadedToolEntry:
    """Entry in the load result for a registered tool."""

    name: str
    type: str  # "code" | "template" | "expression"


@dataclass
class LoadedPromptEntry:
    """Entry in the load result for a registered prompt."""

    name: str


@dataclass
class LoadedResourceEntry:
    """Entry in the load result for a registered resource."""

    name: str
    uri: str


@dataclass
class LoadErrorEntry:
    """Entry in the load result for an error."""

    name: str
    kind: str  # "tool" | "prompt" | "resource" | "resourceTemplate"
    error: str


@dataclass
class LoadResult:
    """Result of loading an MCPServer manifest onto a FastMCP instance."""

    tools: List[LoadedToolEntry] = field(default_factory=list)
    prompts: List[LoadedPromptEntry] = field(default_factory=list)
    resources: List[LoadedResourceEntry] = field(default_factory=list)
    resource_templates: List[LoadedResourceEntry] = field(default_factory=list)
    errors: List[LoadErrorEntry] = field(default_factory=list)
