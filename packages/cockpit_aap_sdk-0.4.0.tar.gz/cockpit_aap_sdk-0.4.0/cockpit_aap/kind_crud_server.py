"""kind_crud_server — Abstract Kind MCP: dynamic CRUD tool generation via FastMCP.

Creates a FastMCP server that auto-generates CRUD tools for every kind registered
in the Python KindRegistry. Equivalent to the TypeScript ``dynamic-kind-ops.ts``.

For each registered kind, 4 tools are generated:
  - ``get_<kind>_manifest``      — scan and return the full typed manifest
  - ``list_<kind>_manifests``    — discover all instances of this kind in a dir tree
  - ``validate_<kind>_manifest`` — check required fields and enum constraints
  - ``check_<kind>_health``      — generic health scoring (A-F grade)

Example (HTTP server)::

    from cockpit_aap.kind_crud_server import create_kind_crud_server

    mcp = create_kind_crud_server()
    app = mcp.http_app()  # Starlette ASGI app

Example (in-process testing)::

    from fastmcp import Client
    from cockpit_aap.kind_crud_server import create_kind_crud_server

    mcp = create_kind_crud_server()
    async with Client(mcp) as client:
        result = await client.call_tool("get_module_manifest", {"manifest_path": ".aap/my-module"})

Example (selective kinds)::

    mcp = create_kind_crud_server(
        only_kinds=["Module", "Agent", "Skill"],
        workspace_root="/path/to/repo",
    )

Requires: fastmcp>=2.0 (install with: pip install cockpit-aap-sdk[mcp])
"""

from __future__ import annotations

import json
import os
import re
from pathlib import Path
from typing import Any, Callable

import yaml

from cockpit_aap.manifest.kind_registry import (
    KindFieldSchema,
    KindRegistry,
    kind_registry,
)


# ── Snake Case Helper ─────────────────────────────────────────────────────────


def _kind_to_snake(kind: str) -> str:
    """Convert a PascalCase/ALLCAPS kind name to snake_case.

    Examples:
        "MCPTool"            → "mcp_tool"
        "TelemetryBlueprint" → "telemetry_blueprint"
        "SDLC"               → "sdlc"
        "AgentCard"          → "agent_card"
    """
    s = re.sub(r"([A-Z]+)([A-Z][a-z])", r"\1_\2", kind)
    s = re.sub(r"([a-z\d])([A-Z])", r"\1_\2", s)
    return s.lower()


# ── Generic Validation ────────────────────────────────────────────────────────


def _get_nested_value(obj: Any, path: str) -> Any:
    """Walk a nested dict/list using dot-notation. [] → pick first element."""
    parts = path.replace("[]", ".0").split(".")
    current = obj
    for part in parts:
        if current is None:
            return None
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, (list, tuple)):
            try:
                idx = int(part)
                current = current[idx] if idx < len(current) else None
            except (ValueError, IndexError):
                return None
        else:
            return None
    return current


def _validate_kind_manifest(
    kind: str,
    manifest_dir: str,
    registry: KindRegistry,
) -> dict[str, Any]:
    """Validate a manifest against its kind's required fields."""
    errors: list[str] = []
    warnings: list[str] = []
    info: list[str] = []

    manifest_file = os.path.join(manifest_dir, "manifest.yaml")
    if not os.path.isfile(manifest_file):
        return {
            "valid": False,
            "errors": [f"manifest.yaml not found in {manifest_dir}"],
            "warnings": warnings,
            "info": info,
        }

    try:
        manifest = registry.scan(manifest_dir)
    except Exception as e:
        return {
            "valid": False,
            "errors": [f"Failed to parse manifest: {e}"],
            "warnings": warnings,
            "info": info,
        }

    if not isinstance(manifest, dict):
        return {
            "valid": False,
            "errors": ["Manifest did not parse to a dict"],
            "warnings": warnings,
            "info": info,
        }

    # Check kind
    manifest_kind = manifest.get("kind")
    if manifest_kind != kind:
        errors.append(f'Expected kind "{kind}", got "{manifest_kind}"')

    # Check apiVersion
    if not manifest.get("apiVersion"):
        errors.append("Missing apiVersion")

    # Check required fields from registry
    entry = registry._entries.get(kind)
    fields = entry.fields if entry else []

    for field in fields:
        value = _get_nested_value(manifest, field.path)
        if field.required and (value is None or value == ""):
            errors.append(f"Required field missing: {field.path}")
        elif value is not None and field.enum:
            str_value = str(value)
            if str_value not in field.enum:
                warnings.append(
                    f'Field {field.path} value "{str_value}" not in '
                    f"allowed values: [{', '.join(field.enum)}]"
                )
        elif value is not None:
            info.append(f"✓ {field.path}")

    return {
        "valid": len(errors) == 0,
        "errors": errors,
        "warnings": warnings,
        "info": info,
    }


# ── Generic Health Check ──────────────────────────────────────────────────────


def _grade_from_percentage(pct: int) -> str:
    if pct >= 90:
        return "A"
    if pct >= 75:
        return "B"
    if pct >= 60:
        return "C"
    if pct >= 40:
        return "D"
    return "F"


def _generic_health_check(
    kind: str,
    manifest_dir: str,
    registry: KindRegistry,
) -> dict[str, Any]:
    """Generic health check that works for ANY kind based on its KindFieldSchema[]."""
    details: dict[str, dict[str, Any]] = {}
    total_score = 0
    total_max = 0

    def add(name: str, score: int, max_score: int, issues: list[str]) -> None:
        nonlocal total_score, total_max
        details[name] = {"score": score, "maxScore": max_score, "issues": issues}
        total_score += score
        total_max += max_score

    # ── Core (4 pts) ──
    manifest_file = os.path.join(manifest_dir, "manifest.yaml")
    core_score = 0
    core_issues: list[str] = []
    manifest_data: dict[str, Any] | None = None

    if os.path.isfile(manifest_file):
        core_score += 2
        try:
            with open(manifest_file, encoding="utf-8") as fh:
                manifest_data = yaml.safe_load(fh)
            if isinstance(manifest_data, dict):
                core_score += 2
            else:
                core_issues.append("manifest.yaml did not parse to a dict")
                manifest_data = None
        except Exception as e:
            core_issues.append(f"manifest.yaml parse error: {e}")
    else:
        core_issues.append("manifest.yaml not found")
    add("core", core_score, 4, core_issues)

    # Try full scan via registry
    scanned: Any = None
    try:
        scanned = registry.scan(manifest_dir)
        if isinstance(scanned, dict):
            manifest_data = scanned
    except Exception:
        pass

    # ── Required Fields (up to 10 pts) ──
    entry = registry._entries.get(kind)
    fields = entry.fields if entry else []
    required_fields = [f for f in fields if f.required]
    req_max = min(len(required_fields) * 2, 10)
    req_score = 0
    req_issues: list[str] = []

    if manifest_data and required_fields:
        for field in required_fields:
            value = _get_nested_value(manifest_data, field.path)
            if value is not None and value != "":
                req_score += 2
            else:
                req_issues.append(f"Required field missing: {field.path}")
            if req_score >= req_max:
                break
    elif not manifest_data:
        req_issues.append("Could not load manifest to check required fields")
    req_score = min(req_score, req_max)
    add("required_fields", req_score, req_max, req_issues)

    # ── Completeness (4 pts) ──
    comp_score = 0
    comp_issues: list[str] = []
    if manifest_data:
        spec = manifest_data.get("spec")
        if isinstance(spec, dict) and spec:
            spec_keys = list(spec.keys())
            non_empty = [
                k for k in spec_keys
                if spec[k] is not None and spec[k] != ""
                and not (isinstance(spec[k], list) and len(spec[k]) == 0)
            ]
            ratio = len(non_empty) / len(spec_keys) if spec_keys else 0
            if ratio >= 0.8:
                comp_score = 4
            elif ratio >= 0.5:
                comp_score = 2
            else:
                comp_issues.append(f"Only {round(ratio * 100)}% of spec fields are populated")
        else:
            comp_issues.append("No spec section found")
    add("completeness", comp_score, 4, comp_issues)

    # ── Lifecycle (4 pts) ──
    life_score = 0
    life_issues: list[str] = []
    if manifest_data:
        spec = manifest_data.get("spec", {})
        lifecycle = spec.get("lifecycle") if isinstance(spec, dict) else None
        if isinstance(lifecycle, dict):
            roadmap = lifecycle.get("roadmap")
            issues_list = lifecycle.get("issues")
            if isinstance(roadmap, list) and len(roadmap) > 0:
                life_score += 2
            else:
                life_issues.append("No lifecycle.roadmap defined")
            if isinstance(issues_list, list) and len(issues_list) > 0:
                life_score += 2
            else:
                life_issues.append("No lifecycle.issues defined")
        else:
            life_issues.append("No lifecycle section in manifest")
    add("lifecycle", life_score, 4, life_issues)

    percentage = round((total_score / total_max) * 100) if total_max > 0 else 0
    grade = _grade_from_percentage(percentage)

    top_issues = [
        issue
        for cat in details.values()
        for issue in cat["issues"]
    ][:5]

    return {
        "kind": kind,
        "grade": grade,
        "score": total_score,
        "maxScore": total_max,
        "percentage": percentage,
        "details": details,
        "topIssues": top_issues,
    }


# ── Manifest Discovery ───────────────────────────────────────────────────────


def _discover_kind_manifests(base_dir: str, kind: str) -> list[str]:
    """Discover all manifest directories of a given kind under base_dir."""
    results: list[str] = []
    base = Path(base_dir).resolve()

    # Directories to scan (glob patterns relative to base)
    scan_globs = [
        ".aap/*",
        "apps/*/.aap/*",
        "governance/*",
        "governance/policies/*",
        "apps/*/governance/*",
        "agents/*",
        "apps/*/agents/*",
        "souls/*",
        "tools/*",
        "connections/*",
        "registry/kinds/*",
        ".aap/use-cases/*",
    ]

    for glob_pattern in scan_globs:
        for candidate in base.glob(glob_pattern):
            manifest_file = candidate / "manifest.yaml"
            if not manifest_file.is_file():
                continue
            try:
                with open(manifest_file, encoding="utf-8") as fh:
                    raw = yaml.safe_load(fh)
                if isinstance(raw, dict) and raw.get("kind") == kind:
                    results.append(str(candidate))
            except Exception:
                pass

    return sorted(set(results))


# ── Custom Health Checker Registry ────────────────────────────────────────────


KindHealthChecker = Callable[[str], dict[str, Any]]

_custom_health_checkers: dict[str, KindHealthChecker] = {}


def register_kind_health_checker(kind: str, checker: KindHealthChecker) -> None:
    """Register a custom health checker for a specific kind.

    When registered, ``check_<kind>_health`` will use this instead of the generic one.
    """
    _custom_health_checkers[kind] = checker


# ── FastMCP Server Factory ────────────────────────────────────────────────────


def create_kind_crud_server(
    *,
    name: str = "aap-kind-crud",
    registry: KindRegistry | None = None,
    workspace_root: str | None = None,
    only_kinds: list[str] | None = None,
    skip_kinds: list[str] | None = None,
) -> Any:
    """Create a FastMCP server with dynamic CRUD tools for registered kinds.

    Args:
        name:           MCP server name shown to clients.
        registry:       KindRegistry to use. Defaults to the global singleton.
        workspace_root: Root dir for discover/list tools. Defaults to cwd.
        only_kinds:     If set, only register these kinds.
        skip_kinds:     If set, skip these kinds (applied after only_kinds).

    Returns:
        FastMCP instance with 4 tools per kind + 1 introspection tool.

    Raises:
        ImportError: If fastmcp is not installed.
    """
    try:
        from fastmcp import FastMCP
    except ImportError as e:
        raise ImportError(
            "fastmcp is required for create_kind_crud_server. "
            "Install it with: pip install cockpit-aap-sdk[mcp]"
        ) from e

    reg = registry or kind_registry
    root = workspace_root or os.getcwd()
    skip = set(skip_kinds or [])

    mcp = FastMCP(name)

    # Determine which kinds to register
    kinds = only_kinds or reg.registered_kinds()
    kinds = [k for k in kinds if k not in skip]

    registered_kinds: list[str] = []

    for kind in kinds:
        if not reg.is_registered(kind):
            continue

        snake = _kind_to_snake(kind)
        _register_get_tool(mcp, kind, snake, reg)
        _register_list_tool(mcp, kind, snake, reg, root)
        _register_validate_tool(mcp, kind, snake, reg)
        _register_health_tool(mcp, kind, snake, reg)
        registered_kinds.append(kind)

    # Introspection tool
    @mcp.tool()
    def list_dynamic_kind_tools(filter_text: str = "") -> str:
        """List all dynamically registered kind-specific tools.

        Shows which kinds have get/list/validate/health tools available.

        Args:
            filter_text: Optional kind name filter (case-insensitive substring match).
        """
        filtered = registered_kinds
        if filter_text:
            lower = filter_text.lower()
            filtered = [k for k in filtered if lower in k.lower()]

        tools = []
        for k in filtered:
            s = _kind_to_snake(k)
            tools.append({
                "kind": k,
                "tools": [
                    f"get_{s}_manifest",
                    f"list_{s}_manifests",
                    f"validate_{s}_manifest",
                    f"check_{s}_health",
                ],
            })
        return json.dumps({
            "totalKinds": len(filtered),
            "totalTools": len(filtered) * 4,
            "kinds": tools,
        }, indent=2)

    return mcp


# ── Tool Registration Helpers ─────────────────────────────────────────────────


def _register_get_tool(
    mcp: Any, kind: str, snake: str, registry: KindRegistry
) -> None:
    """Register get_<kind>_manifest tool."""
    tool_name = f"get_{snake}_manifest"

    @mcp.tool(name=tool_name)
    def get_manifest(manifest_path: str) -> str:
        f"""Read and return the full resolved kind:{kind} manifest from a directory.

        Resolves file references and returns typed JSON.

        Args:
            manifest_path: Absolute path to the {kind} manifest directory.
        """
        try:
            result = registry.scan(manifest_path)
            if isinstance(result, dict):
                return json.dumps(result, indent=2, ensure_ascii=False, default=str)
            return json.dumps(
                {"kind": kind, "data": str(result)}, indent=2, ensure_ascii=False
            )
        except Exception as e:
            return json.dumps({"error": f"Failed to scan {kind} manifest: {e}"})


def _register_list_tool(
    mcp: Any, kind: str, snake: str, registry: KindRegistry, default_root: str
) -> None:
    """Register list_<kind>_manifests tool."""
    tool_name = f"list_{snake}_manifests"

    @mcp.tool(name=tool_name)
    def list_manifests(base_dir: str = "") -> str:
        f"""Discover all kind:{kind} manifest directories in the workspace.

        Scans standard locations and returns a list of directories.

        Args:
            base_dir: Base directory to search (defaults to workspace root).
        """
        root = base_dir or default_root
        try:
            dirs = _discover_kind_manifests(root, kind)
            return json.dumps({
                "kind": kind,
                "count": len(dirs),
                "directories": dirs,
            }, indent=2)
        except Exception as e:
            return json.dumps({"error": f"Failed to list {kind} manifests: {e}"})


def _register_validate_tool(
    mcp: Any, kind: str, snake: str, registry: KindRegistry
) -> None:
    """Register validate_<kind>_manifest tool."""
    tool_name = f"validate_{snake}_manifest"

    @mcp.tool(name=tool_name)
    def validate_manifest(manifest_path: str) -> str:
        f"""Validate a kind:{kind} manifest against its registered schema.

        Reports required-field violations, enum mismatches, and parse errors.

        Args:
            manifest_path: Absolute path to the {kind} manifest directory.
        """
        try:
            report = _validate_kind_manifest(kind, manifest_path, registry)
            return json.dumps(report, indent=2, ensure_ascii=False)
        except Exception as e:
            return json.dumps({"error": f"Failed to validate {kind} manifest: {e}"})


def _register_health_tool(
    mcp: Any, kind: str, snake: str, registry: KindRegistry
) -> None:
    """Register check_<kind>_health tool."""
    tool_name = f"check_{snake}_health"

    @mcp.tool(name=tool_name)
    def check_health(manifest_path: str) -> str:
        f"""Score a kind:{kind} manifest directory and return an A-F grade.

        Categories: core, required_fields, completeness, lifecycle.

        Args:
            manifest_path: Absolute path to the {kind} manifest directory.
        """
        try:
            custom = _custom_health_checkers.get(kind)
            if custom:
                report = custom(manifest_path)
            else:
                report = _generic_health_check(kind, manifest_path, registry)
            return json.dumps(report, indent=2, ensure_ascii=False)
        except Exception as e:
            return json.dumps({"error": f"Failed to check {kind} health: {e}"})
