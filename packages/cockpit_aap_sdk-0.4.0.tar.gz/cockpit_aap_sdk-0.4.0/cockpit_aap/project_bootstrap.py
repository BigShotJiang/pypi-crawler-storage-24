"""Multi-module project bootstrap.

Port of ``packages/bootstrap/src/project-bootstrap.ts``.
Bootstraps all modules inside a ``project.yaml`` / ``cockpit-project.yaml``.
"""

from __future__ import annotations

import asyncio
import time
import logging
from dataclasses import dataclass, field
from typing import Any

from .bootstrap import bootstrap_manifest, ManifestResult
from .manifest.project_scanner import scan_project
from .manifest.types import ManifestProjectResolved

logger = logging.getLogger(__name__)


@dataclass
class ProjectResult:
    """Result of bootstrapping an entire project."""

    project_id: str
    project: ManifestProjectResolved
    modules: dict[str, ManifestResult] = field(default_factory=dict)
    duration_ms: float = 0.0
    errors: dict[str, Exception] = field(default_factory=dict)


async def bootstrap_project(
    sdk: Any,
    project_path: str,
    *,
    namespace: str = "artifacts",
    verbose: bool = False,
    concurrency: int = 3,
    module_ids: list[str] | None = None,
) -> ProjectResult:
    """Bootstrap all modules in a multi-module project.

    Reads ``project.yaml`` from *project_path*, scans all referenced modules,
    and bootstraps each one.

    Parameters
    ----------
    sdk:
        An ``AAPGatewayClient`` instance.
    project_path:
        Path to the project root (containing ``project.yaml``).
    namespace:
        Artifact namespace.  Default: ``"artifacts"``.
    verbose:
        Log progress.
    concurrency:
        Max concurrent module bootstraps.
    module_ids:
        Optional filter — only bootstrap these module IDs.
    """
    import os

    start = time.monotonic()
    abs_path = os.path.abspath(project_path)
    project = scan_project(abs_path)

    if verbose:
        logger.info(
            'Project "%s" — %d modules',
            project.project.id,
            len(project.modules),
        )

    # Filter to enabled modules (optionally further filtered by module_ids)
    to_bootstrap = [m for m in project.modules if m.enabled]
    if module_ids:
        wanted = set(module_ids)
        to_bootstrap = [m for m in to_bootstrap if m.id in wanted]

    if verbose:
        logger.info("Bootstrapping %d modules", len(to_bootstrap))

    results: dict[str, ManifestResult] = {}
    errors: dict[str, Exception] = {}

    # Process in chunks for concurrency control
    for i in range(0, len(to_bootstrap), concurrency):
        chunk = to_bootstrap[i : i + concurrency]

        async def _do(mod: Any) -> None:
            manifest_dir = os.path.join(abs_path, mod.path)
            try:
                if verbose:
                    logger.info("→ %s (%s)", mod.id, mod.path)
                result = await bootstrap_manifest(
                    sdk, manifest_dir, namespace=namespace, verbose=verbose
                )
                results[mod.id] = result
                if verbose:
                    logger.info("✓ %s (%.0fms)", mod.id, result.duration_ms)
            except Exception as exc:
                errors[mod.id] = exc
                if verbose:
                    logger.info("✗ %s: %s", mod.id, exc)

        await asyncio.gather(*(_do(m) for m in chunk))

    duration_ms = (time.monotonic() - start) * 1000
    if verbose:
        logger.info(
            "Done in %.0fms — %d OK, %d failed",
            duration_ms,
            len(results),
            len(errors),
        )

    return ProjectResult(
        project_id=project.project.id,
        project=project,
        modules=results,
        duration_ms=duration_ms,
        errors=errors,
    )
