"""Bootstrap-specific error types.

Port of ``packages/bootstrap/src/errors.ts``.
"""

from __future__ import annotations

from typing import Literal


class BootstrapError(Exception):
    """Raised when a bootstrap operation fails for a specific item.

    Attributes:
        item:  The artifact key or agent name that failed.
        phase: Which bootstrap phase failed (``"artifact"`` or ``"agent"``).
        cause: The underlying exception, if any.
    """

    def __init__(
        self,
        message: str,
        item: str,
        phase: Literal["artifact", "agent"],
        cause: BaseException | None = None,
    ) -> None:
        super().__init__(message)
        self.item = item
        self.phase = phase
        self.__cause__ = cause
