"""TTL cache for bootstrap results.

Port of ``packages/bootstrap/src/cache.ts``.
"""

from __future__ import annotations

import time
from typing import Any

# Default TTL: 5 minutes (same as TS)
DEFAULT_TTL_MS = 300_000


class BootstrapCache:
    """Simple in-memory TTL cache for bootstrap results.

    Parameters
    ----------
    default_ttl_ms:
        Default time-to-live in milliseconds.  Defaults to 300 000 (5 min).
    """

    def __init__(self, default_ttl_ms: int = DEFAULT_TTL_MS) -> None:
        self._store: dict[str, tuple[Any, float]] = {}
        self._default_ttl = default_ttl_ms

    def get(self, module: str) -> Any | None:
        """Return cached result for *module*, or ``None`` if missing / expired."""
        entry = self._store.get(module)
        if entry is None:
            return None
        result, expires_at = entry
        if _now_ms() > expires_at:
            del self._store[module]
            return None
        return result

    def set(self, module: str, result: Any, ttl_ms: int | None = None) -> None:
        """Cache *result* for *module* with the given TTL."""
        ttl = ttl_ms if ttl_ms is not None else self._default_ttl
        if ttl <= 0:
            return
        self._store[module] = (result, _now_ms() + ttl)

    def has(self, module: str) -> bool:
        """Return ``True`` if a non-expired entry exists for *module*."""
        return self.get(module) is not None

    def invalidate(self, module: str | None = None) -> None:
        """Invalidate a single module entry or the entire cache."""
        if module is not None:
            self._store.pop(module, None)
        else:
            self._store.clear()

    @property
    def size(self) -> int:
        """Number of non-expired entries (prunes expired on access)."""
        now = _now_ms()
        expired = [k for k, (_, exp) in self._store.items() if now > exp]
        for k in expired:
            del self._store[k]
        return len(self._store)


def _now_ms() -> float:
    return time.monotonic() * 1000


# Module-level singleton (mirrors TS ``globalCache``)
global_cache = BootstrapCache()
