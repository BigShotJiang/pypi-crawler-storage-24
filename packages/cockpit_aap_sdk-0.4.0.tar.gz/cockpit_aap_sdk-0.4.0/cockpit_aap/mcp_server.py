"""ManifestMCPServer — expose Manifest data as MCP tools via FastMCP.

Provides:
  - create_manifest_mcp_server(manifest, name) -> FastMCP
      Creates a FastMCP server with 6 manifest-reading tools.
      Use as HTTP server (mount in FastAPI) for external clients,
      or in-process via Client(server) for zero-overhead agent access.

Requires: fastmcp>=2.0 (install with: pip install cockpit-aap-sdk[mcp])

Example (HTTP, mounted in FastAPI)::

    from fastapi import FastAPI
    from cockpit_aap import scan_manifest
    from cockpit_aap.mcp_server import create_manifest_mcp_server

    manifest = scan_manifest(".aap/my-module")
    mcp = create_manifest_mcp_server(manifest)

    app = FastAPI()
    app.mount("/mcp", mcp.get_asgi_app())

Example (in-process, for LangGraph agents)::

    from fastmcp import Client
    from cockpit_aap.mcp_server import create_manifest_mcp_server

    mcp = create_manifest_mcp_server(manifest)
    async with Client(mcp) as client:   # FastMCPTransport auto-inferred
        result = await client.call_tool("get_manifest_agents", {})
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from cockpit_aap.manifest.types import Manifest


def create_manifest_mcp_server(manifest: "Manifest", name: str = "aap-manifest"):
    """Create a FastMCP server that exposes manifest data as MCP tools.

    Args:
        manifest: Resolved Manifest (from scan_manifest or bootstrap_manifest).
        name: MCP server name shown to clients. Default: "aap-manifest".

    Returns:
        FastMCP instance with 6 tools registered.

    Raises:
        ImportError: If fastmcp is not installed.
            Install with: pip install cockpit-aap-sdk[mcp]
    """
    try:
        from fastmcp import FastMCP
    except ImportError as e:
        raise ImportError(
            "fastmcp is required for create_manifest_mcp_server. "
            "Install it with: pip install cockpit-aap-sdk[mcp]"
        ) from e

    from cockpit_aap.manifest.helpers import get_manifest_agent_instruction

    mcp = FastMCP(name)

    @mcp.tool()
    def get_manifest_overview() -> str:
        """Get a summary of all sections defined in this Cockpit module manifest.

        Returns module identity (id, name, version) and a count/status for
        every spec section that has been configured (agents, artifacts, skills,
        connections, i18n, theme, guardrails, telemetry, recognition, etc.).
        Call this first when the user asks about the manifest structure.
        """
        meta = manifest.metadata
        spec = manifest.spec

        lines = [
            f"Module: **{meta.display_name}** (id: `{meta.name}`, v{meta.version})",
            f"Description: {meta.description or 'none'}",
            "",
            "## Configured sections:",
        ]

        if spec.agents:
            lines.append(f"- **agents**: {len(spec.agents)} defined")
        if spec.artifacts:
            lines.append(f"- **artifacts**: {len(spec.artifacts)} defined")
        if spec.skills:
            lines.append(f"- **skills**: {len(spec.skills)} defined")
        if spec.connections:
            lines.append(f"- **connections**: {len(spec.connections)} defined")
        if spec.personas:
            defs = getattr(spec.personas, "definitions", None) or []
            lines.append(f"- **personas**: {len(defs)} defined")
        if spec.i18n:
            locales = list((spec.i18n.locales or {}).keys())
            lines.append(f"- **i18n**: default={spec.i18n.default_locale}, locales={locales}")
        if spec.theme:
            presets = list((spec.theme.presets or {}).keys())
            lines.append(f"- **theme**: {len(presets)} presets ({', '.join(presets)})")
        recognition = getattr(spec, "recognition", None)
        if recognition:
            rewards = getattr(recognition, "rewards", None) or []
            lines.append(f"- **recognition**: {len(rewards)} rewards")
        guardrails = getattr(spec, "guardrails", None)
        if guardrails:
            lines.append("- **guardrails**: defined")
        telemetry = getattr(spec, "telemetry", None)
        if telemetry:
            lines.append("- **telemetry**: defined")
        governance = getattr(spec, "governance", None)
        if governance:
            lines.append("- **governance**: defined")
        classification = getattr(spec, "classification", None)
        if classification:
            level = getattr(classification, "level", "unknown")
            lines.append(f"- **classification**: level={level}")
        if spec.hooks:
            lines.append(f"- **hooks**: {len(spec.hooks)} defined")
        if spec.commands:
            lines.append(f"- **commands**: {len(spec.commands)} defined")

        return "\n".join(lines)

    @mcp.tool()
    def get_manifest_agents() -> str:
        """List all AI agents defined in the manifest with their IDs, names, and descriptions.

        Returns a formatted list of every agent in spec.agents, including:
        - Agent ID (used to reference the agent in code and config)
        - Display name
        - Description

        Call get_agent_instruction(agent_id) to read the full system prompt for a specific agent.
        """
        agents = manifest.spec.agents or []
        if not agents:
            return "No agents are defined in this manifest."

        lines = [f"**{len(agents)} agent(s) defined:**\n"]
        for a in agents:
            desc = a.description or "no description"
            lines.append(f"- **{a.id}** ({a.name}): {desc}")
        return "\n".join(lines)

    @mcp.tool()
    def get_agent_instruction(agent_id: str) -> str:
        """Get the full system prompt / instruction for a specific agent by ID.

        Args:
            agent_id: The agent's ID as defined in the manifest (e.g. "dev-assistant").
                      Use get_manifest_agents() to list available agent IDs.

        Returns:
            The agent's full instruction text, or an error if not found.
        """
        instruction = get_manifest_agent_instruction(manifest, agent_id)
        if not instruction:
            available = [a.id for a in (manifest.spec.agents or [])]
            return (
                f"Agent '{agent_id}' not found or has no instruction. "
                f"Available agents: {', '.join(available) or '(none)'}"
            )
        return f"## Instruction for agent `{agent_id}`\n\n{instruction}"

    @mcp.tool()
    def get_manifest_artifacts(category: str = "") -> str:
        """List artifacts defined in the manifest, optionally filtered by category.

        Artifacts are key-value configurations stored in the Cockpit platform.

        Args:
            category: Optional filter. One of: "configuration", "state", "content".
                      Leave empty to list all artifacts.

        Returns:
            Formatted list with key, category, and description for each artifact.
        """
        artifacts = manifest.spec.artifacts or []
        if category:
            artifacts = [a for a in artifacts if (a.category or "configuration") == category]

        if not artifacts:
            suffix = f" with category='{category}'" if category else ""
            return f"No artifacts{suffix} defined in this manifest."

        label = f" [category={category}]" if category else ""
        lines = [f"**{len(artifacts)} artifact(s){label}:**\n"]
        for a in artifacts:
            cat = a.category or "configuration"
            desc = a.description or "no description"
            lines.append(f"- **{a.key}** [{cat}]: {desc}")
        return "\n".join(lines)

    @mcp.tool()
    def get_manifest_skills() -> str:
        """List skills defined in the manifest with their IDs, triggers, and descriptions.

        Skills drive behavior injection:
        - autoInvoke skills: inject instructions when trigger keywords are detected
        - input_context skills: provide quick-action pills and ghost text in SmartInput

        Returns:
            Formatted list of all skills with trigger information.
        """
        skills = manifest.spec.skills or []
        if not skills:
            return "No skills are defined in this manifest."

        lines = [f"**{len(skills)} skill(s) defined:**\n"]
        for s in skills:
            if s.auto_invoke and s.auto_invoke.triggers:
                triggers_str = f"autoInvoke on: {s.auto_invoke.triggers}"
            else:
                triggers_str = "trigger: manual"
            desc = s.description or "no description"
            lines.append(f"- **{s.id}** ({s.name}) [{triggers_str}]: {desc}")
        return "\n".join(lines)

    @mcp.tool()
    def get_manifest_connections() -> str:
        """List external MCP/REST connections defined in the manifest.

        Connections represent external services the module can call
        (e.g. Azure DevOps, GitHub, Saidot MCP servers).

        Returns:
            Formatted list of connections with ID, transport type, and URL.
        """
        connections = manifest.spec.connections or []
        if not connections:
            return "No connections are defined in this manifest."

        lines = [f"**{len(connections)} connection(s) defined:**\n"]
        for c in connections:
            url = getattr(c, "url", None) or "no url"
            transport = getattr(c, "transport", "unknown")
            lines.append(f"- **{c.id}** [{transport}]: {url}")
        return "\n".join(lines)

    return mcp
