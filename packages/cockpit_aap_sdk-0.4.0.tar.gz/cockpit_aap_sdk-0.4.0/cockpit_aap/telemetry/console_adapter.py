"""Console-based ObservabilityPort adapter — logs spans/metrics to stdout.

Port of ``packages/telemetry/src/adapters/console-adapter.ts``.
"""

from __future__ import annotations

import json
import time
import uuid
from datetime import datetime, timezone
from typing import Any

from cockpit_aap.ports import Span


class _ConsoleSpan:
    """Context-manager span that logs start/end to stdout."""

    def __init__(self, name: str) -> None:
        self.span_id = str(uuid.uuid4())
        self._name = name
        self._start = time.monotonic()
        print(f"[span:start] {name} ({self.span_id})")

    # -- Span protocol --

    def set_status(self, status: str, message: str | None = None) -> None:
        suffix = f" — {message}" if message else ""
        print(f"[span:status] {self._name} {status}{suffix}")

    def set_attribute(self, key: str, value: Any) -> None:
        print(f"[span:attr]  {self._name} {key}={value}")

    def record_exception(self, exc: Exception) -> None:
        print(f"[span:error] {self._name} {type(exc).__name__}: {exc}")

    def __enter__(self) -> "_ConsoleSpan":
        return self

    def __exit__(self, *args: Any) -> None:
        elapsed = int((time.monotonic() - self._start) * 1000)
        print(f"[span:end]   {self._name} ({elapsed}ms)")


class ConsoleObservabilityAdapter:
    """Logs spans, metrics, and events to the console (stdout).

    Useful for local development and debugging.
    """

    def start_span(
        self,
        name: str,
        *,
        attributes: dict[str, Any] | None = None,
    ) -> _ConsoleSpan:
        span = _ConsoleSpan(name)
        if attributes:
            for k, v in attributes.items():
                span.set_attribute(k, v)
        return span

    def record_metric(
        self,
        name: str,
        value: float,
        *,
        metric_type: str = "count",
        unit: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        print(f"[metric:{metric_type}] {name}={value}", attributes or "")

    def log_event(self, event_name: str, payload: dict[str, Any]) -> None:
        print(
            json.dumps(
                {"ts": datetime.now(timezone.utc).isoformat(), "event": event_name, **payload}
            )
        )


def create_console_observability() -> ConsoleObservabilityAdapter:
    """Factory — create a console-based ObservabilityPort adapter."""
    return ConsoleObservabilityAdapter()
