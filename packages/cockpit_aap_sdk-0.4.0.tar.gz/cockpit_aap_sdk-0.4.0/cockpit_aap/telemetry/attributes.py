"""Standard AAP semantic attribute keys for telemetry spans and metrics.

Port of ``packages/telemetry/src/attributes.ts``.
"""


class AapAttributes:
    """Namespace of standard attribute keys used across the AAP SDK."""

    TOOL_NAMESPACE = "aap.tool.namespace"
    TOOL_NAME = "aap.tool.name"
    TRANSPORT_TYPE = "aap.transport.type"
    MCP_SESSION_ID = "aap.mcp.session_id"
    MODULE_ID = "aap.module.id"
    MODULE_VERSION = "aap.module.version"
    ARTIFACT_KEY = "aap.artifact.key"
    ARTIFACT_CATEGORY = "aap.artifact.category"
    DRIFT_DETECTED = "aap.drift.detected"
    DRIFT_ACTION = "aap.drift.action"
    BOOTSTRAP_SOURCE = "aap.bootstrap.source"
    MCP_TOOL_NAME = "aap.mcp.tool_name"
    MCP_WORKSPACE_ROOT = "aap.mcp.workspace_root"
