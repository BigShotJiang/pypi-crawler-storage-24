"""OpenTelemetry-backed ObservabilityPort adapter.

Port of ``packages/telemetry/src/adapters/otel-adapter.ts``.

Requires: ``pip install opentelemetry-api``
"""

from __future__ import annotations

import json
import uuid
from datetime import datetime, timezone
from typing import Any


class _OtelSpan:
    """Wraps an OpenTelemetry ``Span`` to satisfy the AAP ``Span`` protocol."""

    def __init__(self, inner: Any) -> None:
        self.span_id = str(uuid.uuid4())
        self._inner = inner

    def set_status(self, status: str, message: str | None = None) -> None:
        try:
            from opentelemetry.trace import StatusCode
        except ImportError:  # pragma: no cover
            return
        code = (
            StatusCode.OK
            if status == "ok"
            else StatusCode.ERROR
            if status == "error"
            else StatusCode.UNSET
        )
        self._inner.set_status(code, message)

    def set_attribute(self, key: str, value: Any) -> None:
        self._inner.set_attribute(key, value)

    def record_exception(self, exc: Exception) -> None:
        self._inner.record_exception(exc)

    def __enter__(self) -> "_OtelSpan":
        return self

    def __exit__(self, *args: Any) -> None:
        self._inner.end()


class OtelObservabilityAdapter:
    """ObservabilityPort backed by OpenTelemetry API.

    Parameters
    ----------
    tracer:
        An optional ``opentelemetry.trace.Tracer`` instance.  When omitted
        the global no-op tracer is resolved via ``trace.get_tracer(scope)``.
    scope:
        Instrumentation scope name (default ``"cockpit-aap-sdk"``).
    """

    def __init__(self, tracer: Any | None = None, scope: str = "cockpit-aap-sdk") -> None:
        if tracer is not None:
            self._tracer = tracer
        else:
            try:
                from opentelemetry import trace

                self._tracer = trace.get_tracer(scope)
            except ImportError:  # pragma: no cover
                self._tracer = None

    def start_span(
        self,
        name: str,
        *,
        attributes: dict[str, Any] | None = None,
    ) -> _OtelSpan:
        if self._tracer is None:  # pragma: no cover
            # Fallback: return a noop-like span
            from cockpit_aap.adapters.noop_adapters import _NoopSpan

            return _NoopSpan()  # type: ignore[return-value]
        inner = self._tracer.start_span(name, attributes=attributes)
        return _OtelSpan(inner)

    def record_metric(
        self,
        name: str,
        value: float,
        *,
        metric_type: str = "count",
        unit: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None:
        # OpenTelemetry metrics require the SDK to be configured.
        # Fallback: structured log like the TS implementation.
        print(
            json.dumps(
                {"metric": name, "type": metric_type, "value": value, **(attributes or {})}
            )
        )

    def log_event(self, event_name: str, payload: dict[str, Any]) -> None:
        print(
            json.dumps(
                {"ts": datetime.now(timezone.utc).isoformat(), "event": event_name, **payload}
            )
        )


def create_otel_observability(
    tracer: Any | None = None,
    scope: str = "cockpit-aap-sdk",
) -> OtelObservabilityAdapter:
    """Factory — create an OpenTelemetry-backed ObservabilityPort adapter."""
    return OtelObservabilityAdapter(tracer=tracer, scope=scope)
