"""OTEL SDK lifecycle — init and shutdown helpers.

Port of ``packages/telemetry/src/provider.ts``.

Requires: ``pip install opentelemetry-sdk opentelemetry-exporter-otlp-proto-http``
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

_sdk_instance: Any = None


@dataclass
class TelemetryConfig:
    """Configuration for the OpenTelemetry SDK."""

    service_name: str = "cockpit-aap"
    service_version: str | None = None
    otlp_endpoint: str | None = None
    enabled: bool = True


def init_telemetry(config: TelemetryConfig | None = None) -> None:
    """Initialise the OpenTelemetry SDK with OTLP HTTP exporters.

    Safe to call multiple times — subsequent calls are ignored.
    If ``opentelemetry-sdk`` is not installed this is a silent no-op.
    """
    global _sdk_instance
    if _sdk_instance is not None:
        return

    cfg = config or TelemetryConfig()
    if not cfg.enabled:
        return

    try:
        from opentelemetry.sdk.trace import TracerProvider
        from opentelemetry.sdk.trace.export import BatchSpanProcessor
        from opentelemetry.sdk.resources import Resource
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        from opentelemetry import trace
    except ImportError:
        return  # dependencies not installed — silent no-op

    resource_attrs: dict[str, str] = {"service.name": cfg.service_name}
    if cfg.service_version:
        resource_attrs["service.version"] = cfg.service_version

    resource = Resource.create(resource_attrs)
    provider = TracerProvider(resource=resource)

    exporter_kwargs: dict[str, Any] = {}
    if cfg.otlp_endpoint:
        exporter_kwargs["endpoint"] = cfg.otlp_endpoint

    exporter = OTLPSpanExporter(**exporter_kwargs)
    provider.add_span_processor(BatchSpanProcessor(exporter))
    trace.set_tracer_provider(provider)
    _sdk_instance = provider


async def shutdown_telemetry() -> None:
    """Flush and shut down the OpenTelemetry SDK.

    Safe to call even if ``init_telemetry`` was never called.
    """
    global _sdk_instance
    if _sdk_instance is None:
        return
    try:
        _sdk_instance.shutdown()
    except Exception:
        pass
    _sdk_instance = None
