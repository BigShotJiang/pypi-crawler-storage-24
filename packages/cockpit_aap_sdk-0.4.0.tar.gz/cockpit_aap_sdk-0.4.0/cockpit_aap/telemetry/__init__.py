"""AAP Telemetry — ObservabilityPort adapters and OTEL utilities.

Port of ``@ruinosus/aap-telemetry`` (TypeScript).

Provides:
- ``ConsoleObservabilityAdapter``  — logs spans/metrics to console
- ``OtelObservabilityAdapter``     — wraps OpenTelemetry API
- ``AapAttributes``                — standard attribute keys
- ``init_telemetry`` / ``shutdown_telemetry`` — OTEL SDK lifecycle
"""

from cockpit_aap.telemetry.attributes import AapAttributes
from cockpit_aap.telemetry.console_adapter import (
    ConsoleObservabilityAdapter,
    create_console_observability,
)
from cockpit_aap.telemetry.otel_adapter import (
    OtelObservabilityAdapter,
    create_otel_observability,
)
from cockpit_aap.telemetry.provider import init_telemetry, shutdown_telemetry

__all__ = [
    "AapAttributes",
    "ConsoleObservabilityAdapter",
    "create_console_observability",
    "OtelObservabilityAdapter",
    "create_otel_observability",
    "init_telemetry",
    "shutdown_telemetry",
]
