"""
YAML -> Rego compiler for AAP governance policies.

Converts ConformancePolicy and ManifestPolicy YAML specs into OPA Rego
modules.  Devs never need to learn Rego -- this runs automatically.
Power users can write .rego files directly instead.

Feature parity with packages/bootstrap/src/governance/rego-compiler.ts.
"""

from __future__ import annotations

import re
import warnings
from typing import Any, Dict, List, Optional, TypedDict

# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------

PolicyManifest = Dict[str, Any]
"""A dict with keys: kind, metadata.name, spec.appliesTo?, spec.requirements[]."""

Requirement = Dict[str, Any]
"""Requirement dict — see TypeScript Requirement interface for fields."""


class CompiledPolicy(TypedDict):
    id: str
    rego: str
    kind: str


# ---------------------------------------------------------------------------
# Severity mapping
# ---------------------------------------------------------------------------

SEVERITY_MAP: Dict[str, str] = {
    "required": "error",
    "forbidden": "error",
    "recommended": "warning",
    "info": "info",
}

DEFAULT_WEIGHT: Dict[str, int] = {
    "required": 4,
    "forbidden": 4,
    "recommended": 2,
    "info": 1,
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sanitize_id(raw_id: str) -> str:
    return re.sub(r"[^a-zA-Z0-9_]", "_", raw_id)


def _escape_rego_string(s: str) -> str:
    """Escape a message string for embedding in a Rego string literal."""
    return s.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\r", "")


def _rego_severity(severity: str) -> str:
    return SEVERITY_MAP.get(severity, "info")


# ---------------------------------------------------------------------------
# ConformancePolicy -> Rego
# ---------------------------------------------------------------------------


def _compile_field_check(field: str, req: Requirement) -> List[str]:
    lines: List[str] = []
    is_array_path = "[]" in field

    if is_array_path:
        parts = field.split("[].")
        array_path = parts[0]
        item_field = parts[1] if len(parts) > 1 else ""
        array_ref = f"input.manifest.{array_path}"

        if req.get("pattern"):
            lines.append(f"    some item in {array_ref}")
            lines.append(f'    not regex.match("{req["pattern"]}", item.{item_field})')
        else:
            lines.append(f"    some item in {array_ref}")
            lines.append(f"    not item.{item_field}")

    elif req.get("condition"):
        match = re.match(r"length\s*(>=|>|<=|<|==)\s*(\d+)", req["condition"])
        if match:
            op = match.group(1)
            n = match.group(2)
            inverse_op = {
                ">=": "<",
                ">": "<=",
                "<=": ">",
                "<": ">=",
                "==": "!=",
            }
            var_name = field.split(".")[-1]
            # Avoid Rego reserved names (input, data)
            if var_name in ("input", "data"):
                var_name = f"{var_name}_val"
            lines.append(f"    {var_name} := input.manifest.{field}")
            lines.append(f"    count({var_name}) {inverse_op[op]} {n}")

    elif req.get("pattern"):
        lines.append(f"    val := input.manifest.{field}")
        lines.append(f'    not regex.match("{req["pattern"]}", val)')

    elif req.get("severity") == "forbidden":
        lines.append(f"    input.manifest.{field}")

    else:
        lines.append(f"    not input.manifest.{field}")

    return lines


def _compile_exempt_rules(req_id: str, exempt_when: List[str]) -> List[str]:
    safe_id = _sanitize_id(req_id)
    blocks: List[str] = []

    for expr in exempt_when:
        # Pattern: field == 'value'
        eq_match = re.match(r"^([\w.]+)\s*==\s*'([^']+)'$", expr)
        if eq_match:
            field, value = eq_match.group(1), eq_match.group(2)
            blocks.append(
                f'exempt_{safe_id} if {{\n    input.manifest.{field} == "{value}"\n}}'
            )
            continue

        # Pattern: field != 'value'
        neq_match = re.match(r"^([\w.]+)\s*!=\s*'([^']+)'$", expr)
        if neq_match:
            field, value = neq_match.group(1), neq_match.group(2)
            blocks.append(
                f'exempt_{safe_id} if {{\n    input.manifest.{field} != "{value}"\n}}'
            )
            continue

        # Pattern: field == undefined
        undef_match = re.match(r"([\w.]+)\s*==\s*undefined", expr)
        if undef_match:
            field = undef_match.group(1)
            blocks.append(
                f"exempt_{safe_id} if {{\n    not input.manifest.{field}\n}}"
            )
            continue

        blocks.append(f"# TODO: complex exemption: {expr}")

    return blocks


def compile_conformance_policy(policy: PolicyManifest) -> str:
    """Compile a ConformancePolicy manifest dict into a Rego module string."""
    policy_id = _sanitize_id(policy["metadata"]["name"])
    applies_to = policy.get("spec", {}).get("appliesTo", {})
    kind = applies_to.get("kind", "Module") if applies_to else "Module"

    lines: List[str] = [
        f"package aap.conformance.{policy_id}",
        "",
        "import rego.v1",
        "",
        f"# Applies to: {kind}",
        f'target_kind := "{kind}"',
        "",
    ]

    for req in policy.get("spec", {}).get("requirements", []):
        field = req.get("field")
        if not field:
            continue

        safe_id = _sanitize_id(req["id"])
        severity = _rego_severity(req.get("severity", "info"))
        weight = req.get("weight", DEFAULT_WEIGHT.get(req.get("severity", "info"), 1))
        field_check = _compile_field_check(field, req)

        # Exempt rules (if any) -- OR semantics
        exempt_when = req.get("exemptWhen", [])
        if exempt_when:
            exempt_blocks = _compile_exempt_rules(req["id"], exempt_when)
            for block in exempt_blocks:
                lines.append(block)
                lines.append("")

        # Violation rule
        lines.append("violation contains result if {")
        if exempt_when:
            lines.append(f"    not exempt_{safe_id}")
        for line in field_check:
            lines.append(line)
        message = _escape_rego_string(req.get("message", ""))
        lines.append("    result := {")
        lines.append(f'        "id": "{req["id"]}",')
        lines.append(f'        "severity": "{severity}",')
        lines.append(f'        "weight": {weight},')
        lines.append(f'        "message": "{message}"')
        lines.append("    }")
        lines.append("}")
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# ManifestPolicy -> Rego
# ---------------------------------------------------------------------------


def _convert_field_expression(expr: str) -> List[str]:
    """Convert simple JS-like field expressions to Rego lines."""

    # Pattern: "field != null && field.length > N"
    m = re.match(r"^([\w.]+)\s*!=\s*null\s*&&\s*\1\.length\s*>\s*(\d+)$", expr)
    if m:
        field, n = m.group(1), m.group(2)
        return [
            f"val := input.manifest.{field}",
            f"count(val) <= {n}",
        ]

    # Pattern: "field != null && field2 != null"
    m = re.match(r"^([\w.]+)\s*!=\s*null\s*&&\s*([\w.]+)\s*!=\s*null$", expr)
    if m:
        return [f"not input.manifest.{m.group(1)}"]

    # Complex expressions with .every() or .some()
    if ".every(" in expr or ".some(" in expr:
        return [
            f"# Complex JS expression (requires manual Rego): {re.sub(r'\\s+', ' ', expr.replace(chr(10), ' ')).strip()}",
            "false  # TODO: implement manually",
        ]

    # Pattern: "field != null"
    m = re.match(r"^([\w.]+)\s*!=\s*null$", expr)
    if m:
        return [f"not input.manifest.{m.group(1)}"]

    # Pattern: "field > N" or "field >= N" etc.
    m = re.match(r"^([\w.]+)\s*(>|>=|<|<=|==|!=)\s*(\d+)$", expr)
    if m:
        field, op, n = m.group(1), m.group(2), m.group(3)
        inverse_op = {
            ">": "<=",
            ">=": "<",
            "<": ">=",
            "<=": ">",
            "==": "!=",
            "!=": "==",
        }
        return [f"input.manifest.{field} {inverse_op[op]} {n}"]

    # Fallback
    sanitized = re.sub(r"\s+", " ", expr.replace("\n", " ")).strip()
    return [f"# TODO: convert expression: {sanitized}", "false"]


def _make_result_block(req: Requirement) -> List[str]:
    severity = _rego_severity(req.get("severity", "info"))
    weight = req.get("weight", DEFAULT_WEIGHT.get(req.get("severity", "info"), 1))
    message = _escape_rego_string(req.get("message", ""))
    return [
        "    result := {",
        f'        "id": "{req["id"]}",',
        f'        "severity": "{severity}",',
        f'        "weight": {weight},',
        f'        "message": "{message}"',
        "    }",
    ]


def _compile_manifest_requirement(req: Requirement) -> List[str]:
    """Compile a single ManifestPolicy requirement into Rego lines."""
    result_block = _make_result_block(req)
    req_type = req.get("type", "")
    lines: List[str] = []

    if req_type == "mustHaveRef":
        target_kind = req.get("targetKind", "")
        lines.append("violation contains result if {")
        lines.append(f"    # mustHaveRef: {target_kind}")
        lines.append('    refs := object.get(input.manifest.spec, "refs", [])')
        lines.append(
            f'    count([r | some r in refs; r.kind == "{target_kind}"]) == 0'
        )
        lines.extend(result_block)
        lines.append("}")

    elif req_type == "mustHaveAnnotation":
        ann_key = req.get("annotationKey", "")
        lines.append("violation contains result if {")
        lines.append(f"    # mustHaveAnnotation: {ann_key}")
        lines.append(
            '    annotations := object.get(input.manifest.metadata, "annotations", {})'
        )
        allowed = req.get("allowedAnnotationValues", [])
        if allowed:
            allowed_str = ", ".join(f'"{v}"' for v in allowed)
            lines.append(f'    val := object.get(annotations, "{ann_key}", "")')
            lines.append(f"    not val in {{{allowed_str}}}")
        else:
            lines.append(f'    not object.get(annotations, "{ann_key}", "")')
        lines.extend(result_block)
        lines.append("}")

    elif req_type == "mustHaveAgent":
        min_count = req.get("minAgentCount", 1)
        lines.append("violation contains result if {")
        lines.append(f"    # mustHaveAgent: min {min_count}")
        lines.append('    agents := object.get(input.manifest.spec, "agents", [])')
        lines.append(f"    count(agents) < {min_count}")
        lines.extend(result_block)
        lines.append("}")

    elif req_type == "fieldExpression":
        expression = req.get("expression", "")
        rego_expr = _convert_field_expression(expression)
        lines.append("violation contains result if {")
        sanitized_expr = re.sub(r"\s+", " ", expression.replace("\n", " ")).strip()
        lines.append(f"    # fieldExpression: {sanitized_expr}")
        for expr_line in rego_expr:
            lines.append(f"    {expr_line}")
        lines.extend(result_block)
        lines.append("}")

    elif req_type == "forbidRef":
        target_kind = req.get("targetKind", "")
        lines.append("violation contains result if {")
        lines.append(f"    # forbidRef: {target_kind}")
        lines.append('    refs := object.get(input.manifest.spec, "refs", [])')
        lines.append(
            f'    count([r | some r in refs; r.kind == "{target_kind}"]) > 0'
        )
        lines.extend(result_block)
        lines.append("}")

    elif req_type == "forbidAnnotation":
        ann_key = req.get("annotationKey", "")
        lines.append("violation contains result if {")
        lines.append(f"    # forbidAnnotation: {ann_key}")
        lines.append(
            '    annotations := object.get(input.manifest.metadata, "annotations", {})'
        )
        lines.append(f'    annotations["{ann_key}"]')
        lines.extend(result_block)
        lines.append("}")

    elif req_type == "mustHaveArtifact":
        artifact_pattern = req.get("artifactPattern")
        lines.append("violation contains result if {")
        lines.append(f'    # mustHaveArtifact: {artifact_pattern or "any"}')
        lines.append(
            '    artifacts := object.get(input.manifest.spec, "artifacts", [])'
        )
        if artifact_pattern:
            lines.append(
                f'    count([a | some a in artifacts; glob.match("{artifact_pattern}", [], a.key)]) == 0'
            )
        else:
            lines.append("    count(artifacts) == 0")
        lines.extend(result_block)
        lines.append("}")

    elif req_type == "agentHasTool":
        lines.append("violation contains result if {")
        lines.append("    # agentHasTool")
        lines.append('    agents := object.get(input.manifest.spec, "agents", [])')
        lines.append("    some agent in agents")
        lines.append('    tools := object.get(agent, "tools", [])')
        lines.append("    count(tools) == 0")
        lines.extend(result_block)
        lines.append("}")

    else:
        lines.append(f"# Unsupported requirement type: {req_type}")

    # Exempt rules for ManifestPolicy requirements
    exempt_when = req.get("exemptWhen", [])
    if exempt_when:
        exempt_blocks = _compile_exempt_rules(req["id"], exempt_when)
        # Prepend exempt rules before the violation
        prepended: List[str] = []
        for block in exempt_blocks:
            prepended.append(block)
            prepended.append("")
        return prepended + lines

    return lines


def compile_manifest_policy(policy: PolicyManifest) -> str:
    """Compile a ManifestPolicy manifest dict into a Rego module string."""
    policy_id = _sanitize_id(policy["metadata"]["name"])
    applies_to = policy.get("spec", {}).get("appliesTo", {})
    kind = applies_to.get("kind", "Module") if applies_to else "Module"

    lines: List[str] = [
        f"package aap.policy.{policy_id}",
        "",
        "import rego.v1",
        "",
        f"# Applies to: {kind}",
        f'target_kind := "{kind}"',
        "",
    ]

    when_expr = (applies_to or {}).get("when")

    if when_expr:
        lines.append("default applies := false")
        lines.append("")
        lines.append("applies if {")

        # Parse the when expression (supports simple equality and OR)
        or_parts = [p.strip() for p in when_expr.split("||")]

        if len(or_parts) > 1:
            # Multiple OR conditions
            first_match = re.match(r"^([\w.]+)\s*==\s*'([^']+)'$", or_parts[0])
            if first_match:
                lines.append(
                    f'    input.manifest.{first_match.group(1)} == "{first_match.group(2)}"'
                )
            lines.append("}")

            for part in or_parts[1:]:
                m = re.match(r"^([\w.]+)\s*==\s*'([^']+)'$", part)
                if m:
                    lines.append("")
                    lines.append("applies if {")
                    lines.append(f'    input.manifest.{m.group(1)} == "{m.group(2)}"')
                    lines.append("}")
        else:
            m = re.match(r"^([\w.]+)\s*==\s*'([^']+)'$", when_expr)
            if m:
                lines.append(f'    input.manifest.{m.group(1)} == "{m.group(2)}"')
            else:
                lines.append(f"    # TODO: parse when: {when_expr}")
            lines.append("}")

        lines.append("")

        # Emit violation rules
        for req in policy.get("spec", {}).get("requirements", []):
            req_lines = _compile_manifest_requirement(req)
            lines.extend(req_lines)
            lines.append("")

        # Wrap violations in final_violations
        lines.append("# Only report violations when policy applies")
        lines.append("final_violations contains v if {")
        lines.append("    applies")
        lines.append("    some v in violation")
        lines.append("}")
    else:
        # No when filter -- violations are final
        for req in policy.get("spec", {}).get("requirements", []):
            req_lines = _compile_manifest_requirement(req)
            lines.extend(req_lines)
            lines.append("")

        lines.append("final_violations := violation")

    lines.append("")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------


def compile_policy_to_rego(policy: PolicyManifest) -> str:
    """Route a policy dict to the appropriate compiler based on ``kind``."""
    kind = policy.get("kind", "")
    if kind == "ConformancePolicy":
        return compile_conformance_policy(policy)
    if kind == "ManifestPolicy":
        return compile_manifest_policy(policy)
    raise ValueError(f"Unsupported policy kind for Rego compilation: {kind}")


# ---------------------------------------------------------------------------
# Batch compilation
# ---------------------------------------------------------------------------


def compile_all_policies(policies: List[PolicyManifest]) -> List[CompiledPolicy]:
    """Compile an array of policy manifests to Rego in batch.

    Supported kinds: ConformancePolicy, ManifestPolicy.
    Unsupported kinds (e.g. CostPolicy) are silently skipped with a warning.
    """
    results: List[CompiledPolicy] = []

    for policy in policies:
        kind = policy.get("kind", "unknown")
        policy_id = policy.get("metadata", {}).get("name", "unknown")

        if kind not in ("ConformancePolicy", "ManifestPolicy"):
            warnings.warn(
                f'[compile_all_policies] Skipping unsupported kind "{kind}" '
                f'for policy "{policy_id}"',
                stacklevel=2,
            )
            continue

        try:
            rego = compile_policy_to_rego(policy)
            results.append(CompiledPolicy(id=policy_id, rego=rego, kind=kind))
        except Exception as exc:
            warnings.warn(
                f'[compile_all_policies] Failed to compile policy "{policy_id}" '
                f"({kind}): {exc}",
                stacklevel=2,
            )

    return results
