"""Canonical scoring model for OPA governance violations.

Converts raw violations (from any PolicyEnginePort adapter) into a
PolicyDecision with weighted scores, percentage, grade, and per-policy breakdown.

Feature parity with packages/bootstrap/src/governance/scoring.ts.
"""
from __future__ import annotations

from cockpit_aap.ports.policy_engine import PolicyDecision, PolicyViolation

# ---------------------------------------------------------------------------
# Default weights per severity
# ---------------------------------------------------------------------------

DEFAULT_WEIGHT: dict[str, int] = {
    "error": 4,
    "warning": 2,
    "info": 1,
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _normalize_severity(s: str | None) -> str:
    if s in ("error", "required", "forbidden"):
        return "error"
    if s in ("warning", "recommended"):
        return "warning"
    return "info"


def _grade_score(percentage: float) -> str:
    if percentage >= 90:
        return "A"
    if percentage >= 75:
        return "B"
    if percentage >= 60:
        return "C"
    if percentage >= 40:
        return "D"
    if percentage >= 20:
        return "E"
    return "F"


# ---------------------------------------------------------------------------
# Core scoring function
# ---------------------------------------------------------------------------

def score_from_violations(
    violations: list[dict],
    policy_id: str | None = None,
) -> PolicyDecision:
    """Compute a PolicyDecision from a flat list of raw violation dicts.

    Args:
        violations: Raw violations from OPA evaluation (dicts with id/rule,
                    severity, weight, message, policy fields).
        policy_id: Optional policy ID override when all violations come from
                   a single policy.

    Returns:
        PolicyDecision with weighted scores, percentage, grade, and breakdown.
    """
    if not violations:
        return PolicyDecision(
            passed=True,
            score=0,
            max_score=0,
            percentage=100,
            grade="A",
            violations=[],
            breakdown={},
        )

    # Normalize violations to PolicyViolation format
    normalized: list[PolicyViolation] = []
    for v in violations:
        normalized.append(PolicyViolation(
            policy=v.get("policy") or policy_id or "unknown",
            rule=v.get("id") or v.get("rule") or "unknown",
            message=v.get("message") or "Policy violation",
            severity=_normalize_severity(v.get("severity")),
        ))

    # Calculate weighted scores — all weight is "lost" since all violations fired
    total_weight = sum(
        v.get("weight", DEFAULT_WEIGHT.get(_normalize_severity(v.get("severity")), 1))
        for v in violations
    )
    max_score = total_weight
    lost_weight = total_weight
    score = max(0, max_score - lost_weight)
    percentage = round((score / max_score) * 100) if max_score > 0 else 100

    # Check if any error-severity violations exist
    has_errors = any(n.severity == "error" for n in normalized)

    # Build per-policy breakdown
    breakdown: dict[str, dict] = {}
    for i, n in enumerate(normalized):
        p = n.policy
        if p not in breakdown:
            breakdown[p] = {"score": 0, "max_score": 0, "violations": []}
        raw_v = violations[i]
        w = raw_v.get("weight", DEFAULT_WEIGHT.get(n.severity, 1))
        breakdown[p]["max_score"] += w
        breakdown[p]["violations"].append(n)

    # Per-policy score is also 0 since all violations fired
    for entry in breakdown.values():
        entry["score"] = 0

    return PolicyDecision(
        passed=not has_errors,
        score=score,
        max_score=max_score,
        percentage=percentage,
        grade=_grade_score(percentage),
        violations=normalized,
        breakdown=breakdown,
    )


# ---------------------------------------------------------------------------
# Merge multiple PolicyDecisions
# ---------------------------------------------------------------------------

def merge_decisions(decisions: list[PolicyDecision]) -> PolicyDecision:
    """Merge multiple PolicyDecision objects into a single aggregate decision."""
    if not decisions:
        return PolicyDecision(
            passed=True,
            score=0,
            max_score=0,
            percentage=100,
            grade="A",
            violations=[],
            breakdown={},
        )

    all_violations: list[PolicyViolation] = []
    merged_breakdown: dict[str, dict] = {}
    total_score = 0.0
    total_max = 0.0

    for d in decisions:
        all_violations.extend(d.violations)
        total_score += d.score
        total_max += d.max_score

        for key, entry in d.breakdown.items():
            if key not in merged_breakdown:
                merged_breakdown[key] = {"score": 0, "max_score": 0, "violations": []}
            merged_breakdown[key]["score"] += entry.get("score", 0)
            merged_breakdown[key]["max_score"] += entry.get("max_score", 0)
            merged_breakdown[key]["violations"].extend(entry.get("violations", []))

    percentage = round((total_score / total_max) * 100) if total_max > 0 else 100
    has_errors = any(v.severity == "error" for v in all_violations)

    return PolicyDecision(
        passed=not has_errors,
        score=total_score,
        max_score=total_max,
        percentage=percentage,
        grade=_grade_score(percentage),
        violations=all_violations,
        breakdown=merged_breakdown,
    )
