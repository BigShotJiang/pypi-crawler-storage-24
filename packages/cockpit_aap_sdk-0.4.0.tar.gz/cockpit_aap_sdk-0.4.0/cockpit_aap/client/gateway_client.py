"""AAP Gateway client with dynamic namespace proxy."""

from __future__ import annotations

from typing import Any, Awaitable, Callable

from cockpit_aap.mcp_types import (
    PromptResult,
    PromptSchema,
    ResourceContents,
    ResourceSchema,
    ResourceTemplate,
)
from cockpit_aap.transport import Transport, TransportContext
from cockpit_aap.transports.rest import RestTransport
from cockpit_aap.transports.mcp import McpTransport


class _NamespaceProxy:
    """Attribute access on a namespace becomes a tool call."""

    def __init__(self, client: AAPGatewayClient, namespace: str) -> None:
        self._client = client
        self._ns = namespace

    def __getattr__(self, tool_name: str) -> Callable[..., Any]:
        async def call(**kwargs: Any) -> dict[str, Any]:
            return await self._client.call_tool(self._ns, tool_name, kwargs)

        return call


class AAPGatewayClient:
    """Async AAP Gateway client with dynamic namespace/tool access.

    Usage (REST — default):
        async with AAPGatewayClient(
            endpoint="http://localhost:3100",
            token=get_token,
            tenant_id="acme-corp",
        ) as sdk:
            result = await sdk.azuredevops.create_work_item(
                project="Cockpit", type="Task", title="New feature",
            )

    Usage (MCP protocol):
        async with AAPGatewayClient(
            endpoint="https://mcp-server.example.com/mcp",
            token="unused",
            transport="mcp",
            default_namespace="cockpit-agent",
            headers={"x-api-key": "..."},
        ) as sdk:
            result = await sdk.cockpit_agent.execute_agent(user_input="Hello")
    """

    def __init__(
        self,
        endpoint: str,
        token: str | Callable[[], str | Awaitable[str]],
        tenant_id: str | None = None,
        timeout: float = 30.0,
        transport: str = "rest",
        default_namespace: str = "default",
        headers: dict[str, str] | None = None,
        mcp_protocol_version: str = "2024-11-05",
    ) -> None:
        self._endpoint = endpoint.rstrip("/")
        self._token = token
        self._tenant_id = tenant_id
        self._timeout = timeout
        self._custom_headers = headers or {}
        self._schemas: dict[str, list[dict[str, Any]]] = {}
        self._prompts: dict[str, list[PromptSchema]] = {}
        self._resources: dict[str, list[ResourceSchema]] = {}
        self._resource_templates: dict[str, list[ResourceTemplate]] = {}

        # Create transport
        self._transport: Transport
        if transport == "mcp":
            self._transport = McpTransport(
                default_namespace=default_namespace,
                protocol_version=mcp_protocol_version,
            )
        else:
            self._transport = RestTransport()

    async def init(self) -> AAPGatewayClient:
        """Load tool schemas from the server's discovery endpoint."""
        ctx = self._build_context()
        tools: list[dict[str, Any]] = await self._transport.init(ctx)
        for tool in tools:
            ns = tool.get("namespace", "")
            if ns not in self._schemas:
                self._schemas[ns] = []
            self._schemas[ns].append(tool)

        # Discover prompts (non-blocking — returns [] if unsupported)
        prompt_list = await self._transport.list_prompts(ctx)
        for p in prompt_list:
            ns = p.namespace
            if ns not in self._prompts:
                self._prompts[ns] = []
            self._prompts[ns].append(p)

        # Discover resources
        resource_list = await self._transport.list_resources(ctx)
        for r in resource_list:
            ns = r.namespace
            if ns not in self._resources:
                self._resources[ns] = []
            self._resources[ns].append(r)

        # Discover resource templates
        template_list = await self._transport.list_resource_templates(ctx)
        for t in template_list:
            ns = t.namespace
            if ns not in self._resource_templates:
                self._resource_templates[ns] = []
            self._resource_templates[ns].append(t)

        return self

    async def call_tool(
        self, ns: str, tool: str, args: dict[str, Any]
    ) -> dict[str, Any]:
        """Call a namespaced tool with the given arguments."""
        ctx = self._build_context()
        return await self._transport.call_tool(ctx, ns, tool, args)

    @property
    def namespaces(self) -> list[str]:
        """List available namespaces."""
        return list(self._schemas.keys())

    def get_tools(self, ns: str) -> list[dict[str, Any]]:
        """List tools for a given namespace."""
        return self._schemas.get(ns, [])

    # ------------------------------------------------------------------
    # MCP Prompts
    # ------------------------------------------------------------------

    def get_prompts(self, ns: str) -> list[PromptSchema]:
        """List discovered prompts for a namespace."""
        return self._prompts.get(ns, [])

    def get_prompt_schema(self, ns: str, name: str) -> PromptSchema | None:
        """Get a single prompt schema by namespace and name."""
        for p in self._prompts.get(ns, []):
            if p.name == name:
                return p
        return None

    async def get_prompt(
        self, ns: str, name: str, args: dict[str, str] | None = None
    ) -> PromptResult:
        """Execute a prompt on the server."""
        ctx = self._build_context()
        return await self._transport.get_prompt(ctx, ns, name, args)

    # ------------------------------------------------------------------
    # MCP Resources
    # ------------------------------------------------------------------

    def get_resources(self, ns: str) -> list[ResourceSchema]:
        """List discovered resources for a namespace."""
        return self._resources.get(ns, [])

    def get_resource_schema(self, ns: str, uri: str) -> ResourceSchema | None:
        """Get a single resource schema by namespace and URI."""
        for r in self._resources.get(ns, []):
            if r.uri == uri:
                return r
        return None

    async def read_resource(self, ns: str, uri: str) -> list[ResourceContents]:
        """Read a resource by URI from the server."""
        ctx = self._build_context()
        return await self._transport.read_resource(ctx, ns, uri)

    def get_resource_templates(self, ns: str) -> list[ResourceTemplate]:
        """List discovered resource templates for a namespace."""
        return self._resource_templates.get(ns, [])

    def __getattr__(self, ns: str) -> _NamespaceProxy:
        if ns.startswith("_"):
            raise AttributeError(ns)
        return _NamespaceProxy(self, ns)

    def _build_context(self) -> TransportContext:
        return TransportContext(
            endpoint=self._endpoint,
            timeout=self._timeout,
            get_headers=self._build_headers,
        )

    async def _build_headers(self) -> dict[str, str]:
        token = (
            self._token
            if isinstance(self._token, str)
            else await self._token()  # type: ignore[misc]
        )
        headers: dict[str, str] = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {token}",
            **self._custom_headers,
        }
        if self._tenant_id:
            headers["X-Tenant-ID"] = self._tenant_id
        return headers

    async def __aenter__(self) -> AAPGatewayClient:
        return await self.init()

    async def __aexit__(self, *a: Any) -> None:
        if hasattr(self._transport, "close"):
            await self._transport.close()  # type: ignore[attr-defined]
