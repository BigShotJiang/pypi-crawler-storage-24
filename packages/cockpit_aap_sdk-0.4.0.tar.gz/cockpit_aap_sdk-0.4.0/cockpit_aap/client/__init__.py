"""cockpit_aap.client — AAP Gateway client and ManifestClient."""

from .gateway_client import AAPGatewayClient, _NamespaceProxy
from .manifest_client import ManifestClient

__all__ = ["AAPGatewayClient", "_NamespaceProxy", "ManifestClient"]
