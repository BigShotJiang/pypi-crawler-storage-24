"""ManifestClient — HTTP client for fetching and pushing manifests with TTL cache."""
from __future__ import annotations

import time
from dataclasses import dataclass
from typing import Any, Callable

import httpx


@dataclass
class _CacheEntry:
    manifest: dict[str, Any]
    expires_at: float


class ManifestClient:
    """HTTP client for a manifest server with in-memory TTL cache.

    Args:
        url: Base URL of the manifest server (no trailing slash).
        ttl: Cache time-to-live in seconds (default: 30).
        tenant: Optional dict with ``licenseId`` and ``namespaceId`` keys.
        headers: Extra HTTP headers to send with every request.
    """

    def __init__(
        self,
        url: str,
        ttl: int = 30,
        tenant: dict[str, str] | None = None,
        headers: dict[str, str] | None = None,
    ) -> None:
        self._url = url.rstrip("/")
        self._ttl = ttl
        self._tenant = tenant or {}
        self._extra_headers = headers or {}
        self._cache: dict[str, _CacheEntry] = {}
        self._callbacks: list[Callable[[str], None]] = []
        self._http: httpx.AsyncClient = httpx.AsyncClient()

    def _build_headers(self) -> dict[str, str]:
        h: dict[str, str] = {"Content-Type": "application/json", **self._extra_headers}
        if license_id := self._tenant.get("licenseId"):
            h["x-cockpit-license-id"] = license_id
        if namespace_id := self._tenant.get("namespaceId"):
            h["x-cockpit-namespace-id"] = namespace_id
        return h

    def invalidate(self, module_id: str) -> None:
        """Remove a module from the cache and notify callbacks."""
        self._cache.pop(module_id, None)
        for cb in self._callbacks:
            cb(module_id)

    def on_invalidate(self, callback: Callable[[str], None]) -> None:
        """Register a callback to be called when a module is invalidated."""
        self._callbacks.append(callback)

    async def get_manifest(self, module_id: str) -> dict[str, Any]:
        """Fetch a manifest, returning a cached copy if within TTL."""
        now = time.monotonic()
        entry = self._cache.get(module_id)
        if entry is not None and now < entry.expires_at:
            return entry.manifest

        response = await self._http.get(
            f"{self._url}/{module_id}",
            headers=self._build_headers(),
        )
        response.raise_for_status()
        manifest: dict[str, Any] = response.json()

        self._cache[module_id] = _CacheEntry(
            manifest=manifest,
            expires_at=now + self._ttl,
        )
        return manifest

    async def push_manifest(self, module_id: str, manifest: Any) -> None:
        """POST a manifest to the server and invalidate the local cache."""
        response = await self._http.post(
            f"{self._url}/{module_id}/push",
            json=manifest,
            headers=self._build_headers(),
        )
        response.raise_for_status()
        self.invalidate(module_id)

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()
