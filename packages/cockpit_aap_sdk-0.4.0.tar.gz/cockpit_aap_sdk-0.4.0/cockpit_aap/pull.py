"""Pull manifest from server to disk.

Port of ``packages/bootstrap/src/manifest-bootstrap.ts`` (pull/scaffold section).
"""

from __future__ import annotations

import os
import logging
from dataclasses import dataclass, field
from typing import Any

import yaml

from .manifest.parser import parse_manifest
from .manifest.writer import write_manifest, WriteManifestOptions

logger = logging.getLogger(__name__)

DEFAULT_ARTIFACTS_NS = "artifacts"
META_KEY_SUFFIX = "._meta.manifest"


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class PullManifestResult:
    """Result of pulling a manifest from the server."""

    manifest: Any  # Manifest
    files_written: list[str] = field(default_factory=list)
    version: str = ""


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


async def read_manifest_artifact(
    sdk: Any,
    namespace: str,
    key: str,
) -> str | None:
    """Read a manifest YAML string from a server artifact.

    Returns ``None`` if the artifact is not found.
    This function is now **public** (TS also exports it).
    """
    import re

    try:
        result = await sdk.call_tool(namespace, "get_artifact", {
            "key_pattern": f"^{re.escape(key)}$",
        })

        content = result.get("content")
        if not content or result.get("isError"):
            return None

        if isinstance(content, dict):
            artifacts = content.get("artifacts", [])
            if artifacts and isinstance(artifacts, list) and len(artifacts) > 0:
                val = artifacts[0].get("value")
                if val:
                    return val
            if content.get("value"):
                return content["value"]
            if content.get("content"):
                return content["content"]
        if isinstance(content, str):
            return content
        return None
    except Exception as e:
        logger.debug("Failed to read manifest artifact %s: %s", key, e)
        return None


async def pull_manifest(
    sdk: Any,
    module_id: str,
    output_dir: str,
    *,
    namespace: str = DEFAULT_ARTIFACTS_NS,
    manifest_key: str | None = None,
    write_options: WriteManifestOptions | None = None,
    verbose: bool = False,
) -> PullManifestResult:
    """Pull a manifest from the MCP server and write it to disk.

    Reverse of :func:`bootstrap_manifest` — reads the ``_meta.manifest``
    artifact from the server, parses it, and writes multi-file structure.

    Use cases:
    - **Brownfield pull**: PO edited manifest on the platform, dev pulls updates
    - **Greenfield PO-first**: PO created manifest on the platform, dev downloads

    Raises :class:`RuntimeError` when the manifest is not found on the server.
    """
    key = manifest_key or f"{module_id}{META_KEY_SUFFIX}"

    if verbose:
        logger.info('Pulling manifest for "%s" from server...', module_id)

    # Step 1: Read manifest YAML from server
    server_yaml = await read_manifest_artifact(sdk, namespace, key)
    if not server_yaml:
        raise RuntimeError(
            f'Manifest not found on server: "{key}". '
            f'Ensure the module "{module_id}" has been bootstrapped at least once.'
        )

    if verbose:
        logger.info("Manifest YAML downloaded (%d chars)", len(server_yaml))

    # Step 2: Parse the YAML
    manifest = parse_manifest(server_yaml)
    if verbose:
        logger.info(
            "Parsed: %s v%s",
            manifest.metadata.display_name,
            manifest.metadata.version,
        )

    # Step 3: Write to disk
    opts = write_options or WriteManifestOptions()
    files_written = write_manifest(manifest, output_dir, opts)
    if verbose:
        logger.info("Wrote %d file(s) to %s", len(files_written), output_dir)

    return PullManifestResult(
        manifest=manifest,
        files_written=files_written,
        version=manifest.metadata.version or "",
    )


async def scaffold_from_server(
    sdk: Any,
    module_id: str,
    output_dir: str,
    *,
    namespace: str = DEFAULT_ARTIFACTS_NS,
    generate_init: bool = True,
    generate_definition: bool = True,
    verbose: bool = False,
) -> PullManifestResult:
    """Pull manifest from server and scaffold boilerplate Python files.

    Generated files:
    - ``init.py`` — ``bootstrap_manifest()`` call with placeholder comments
    - ``definition.py`` — ``MODULE_ID`` and ``DEFAULT_*`` constants
    """
    result = await pull_manifest(
        sdk,
        module_id,
        output_dir,
        namespace=namespace,
        verbose=verbose,
    )

    manifest = result.manifest

    if generate_init:
        init_path = os.path.join(output_dir, "init.py")
        with open(init_path, "w", encoding="utf-8") as fh:
            fh.write(_generate_init_template(module_id))
        result.files_written.append(init_path)
        if verbose:
            logger.info("Generated init.py")

    if generate_definition:
        def_path = os.path.join(output_dir, "definition.py")
        with open(def_path, "w", encoding="utf-8") as fh:
            fh.write(_generate_definition_template(manifest))
        result.files_written.append(def_path)
        if verbose:
            logger.info("Generated definition.py")

    return result


# ---------------------------------------------------------------------------
# Template generators
# ---------------------------------------------------------------------------


def _generate_init_template(module_id: str) -> str:
    return f'''"""Bootstrap initialisation for {module_id}."""

from cockpit_aap import AAPGatewayClient, bootstrap_manifest
from .definition import MODULE_ID

# TODO: Configure your MCP server endpoint
sdk = AAPGatewayClient(endpoint="http://localhost:3100/mcp", token="...")


async def main() -> None:
    async with sdk:
        await sdk.init()
        result = await bootstrap_manifest(sdk, __file__.rsplit("/", 1)[0], verbose=True)
        print(f"Bootstrapped {{result.module}} v{{result.manifest.metadata.version}}")
        print(f"Source: {{result.manifest_source}}")
        print(f"Agents: {{len(result.agents)}}")
        print(f"Duration: {{result.duration_ms:.0f}}ms")


if __name__ == "__main__":
    import asyncio
    asyncio.run(main())
'''


def _generate_definition_template(manifest: Any) -> str:
    lines: list[str] = [
        f"# Auto-generated from manifest v{manifest.metadata.version}",
        "# TODO: Customise these constants for your module\n",
        f'MODULE_ID = "{manifest.metadata.name}"',
        f'MODULE_VERSION = "{manifest.metadata.version}"',
        f'MODULE_NAME = "{manifest.metadata.display_name}"',
        "",
    ]

    # Artifact keys
    if manifest.spec.artifacts:
        lines.append("# Artifact keys")
        for art in manifest.spec.artifacts:
            const = f"KEY_{art.key.replace('.', '_').replace('-', '_').upper()}"
            lines.append(f'{const} = "{art.key}"')
        lines.append("")

    # Default artifact values
    if manifest.spec.artifacts:
        lines.append("# Default artifact values")
        for art in manifest.spec.artifacts:
            const = f"DEFAULT_{art.key.replace('.', '_').replace('-', '_').upper()}"
            escaped = art.default_value.replace("\\", "\\\\").replace('"', '\\"')
            lines.append(f'{const} = "{escaped}"')
        lines.append("")

    # Agent names
    if manifest.spec.agents:
        lines.append("# Agent names")
        for agent in manifest.spec.agents:
            const = f"AGENT_{agent.id.replace('.', '_').replace('-', '_').upper()}"
            lines.append(f'{const} = "{agent.name}"')
        lines.append("")

    return "\n".join(lines) + "\n"
