"""TenantResolverPort — multi-tenant context resolution.

Resolves the current tenant (license_id + namespace_id) from an incoming
request.  Multiple adapters are provided: header-based, env-var-based,
JWT-claim-based, and composite (try-each).

Python equivalent of TenantResolverPort (TypeScript, packages/ports/src/tenant-resolver.ts).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass
class TenantContext:
    """Resolved tenant identity for a single request."""

    license_id: str
    namespace_id: str
    user_id: str | None = None
    roles: list[str] = field(default_factory=list)


@runtime_checkable
class TenantResolverPort(Protocol):
    """Abstrai a resolução de tenant a partir de um request qualquer."""

    async def resolve(self, request: Any) -> TenantContext: ...
