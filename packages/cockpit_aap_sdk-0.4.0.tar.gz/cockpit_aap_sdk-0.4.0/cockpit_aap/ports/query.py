"""QueryPort — evaluate expressions against data."""
from __future__ import annotations
from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class QueryPort(Protocol):
    async def evaluate(self, expression: str, data: Any) -> Any: ...
