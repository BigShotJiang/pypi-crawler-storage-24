"""GuardrailPort — input/output enforcement for AI agents."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass
class GuardrailContext:
    agent_id: str
    input: str | None = None
    tool_name: str | None = None
    metadata: dict | None = None


@dataclass
class GuardrailViolation:
    rule_id: str
    category: str
    message: str
    severity: str = "warn"  # "block" | "warn" | "info"


@dataclass
class GuardrailDecision:
    allowed: bool = True
    action: str = "pass"  # "pass" | "block" | "warn" | "rewrite" | "filter"
    violations: list[GuardrailViolation] = field(default_factory=list)
    rewritten: str | None = None


@runtime_checkable
class GuardrailPort(Protocol):
    async def evaluate_input(self, context: GuardrailContext) -> GuardrailDecision: ...
    async def evaluate_output(self, context: GuardrailContext) -> GuardrailDecision: ...
