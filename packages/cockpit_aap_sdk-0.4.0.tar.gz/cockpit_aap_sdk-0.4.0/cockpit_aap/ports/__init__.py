"""Port interfaces for the hexagonal architecture of the AAP SDK.

Each port is a ``typing.Protocol`` — any class with the right methods
satisfies the protocol without explicit inheritance (structural subtyping).

Python equivalent of ``@ruinosus/aap-ports`` (TypeScript).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


# ---------------------------------------------------------------------------
# ManifestStorePort
# ---------------------------------------------------------------------------


@dataclass
class StoreArtifact:
    id: str
    key: str
    value: str


@dataclass
class StoreAgent:
    id: str
    name: str
    instructions: str | None = None
    agent_type_id: str | None = None


@dataclass
class StoreAgentType:
    id: str
    name: str


@runtime_checkable
class ArtifactsProtocol(Protocol):
    """Artifact CRUD operations — matches Cockpit MCP wire format."""

    async def get_artifact(self, *, key_pattern: str) -> dict[str, Any]: ...
    async def create_artifact(
        self,
        *,
        key: str,
        value: str,
        conflict_strategy: str = "SKIP",
        **kwargs: Any,
    ) -> dict[str, Any]: ...
    async def update_artifact(
        self,
        *,
        id: str,
        value: str,
        promote_to_production: bool = True,
    ) -> dict[str, Any]: ...


@runtime_checkable
class AgentsProtocol(Protocol):
    """Agent CRUD operations — matches Cockpit MCP wire format."""

    async def list_agent_types(self) -> dict[str, Any]: ...
    async def search_utility_agents(self, *, query: str) -> dict[str, Any]: ...
    async def get_full_utility_agent(self, *, agent_id: str) -> dict[str, Any]: ...
    async def create_utility_agent(
        self,
        *,
        name: str,
        instructions: str,
        agent_type_id: str,
    ) -> dict[str, Any]: ...


class ManifestStorePort(Protocol):
    """Unified storage backend for manifest bootstrap operations.

    Combine artifacts + agents namespaces.  The Cockpit SDK adapter
    satisfies this protocol structurally (snake_case matches wire format).
    """

    @property
    def artifacts(self) -> ArtifactsProtocol: ...

    @property
    def agents(self) -> AgentsProtocol: ...


# ---------------------------------------------------------------------------
# AuthPort
# ---------------------------------------------------------------------------


@dataclass
class AuthUser:
    id: str
    name: str | None = None
    email: str | None = None
    image: str | None = None
    roles: list[str] = field(default_factory=list)


@dataclass
class AuthSession:
    user: AuthUser
    access_token: str | None = None
    expires_at: int | None = None  # Unix timestamp ms


class AuthPort(Protocol):
    """Authentication abstraction — session, token, role check."""

    async def get_session(self) -> AuthSession | None: ...
    async def get_access_token(self) -> str | None: ...
    async def has_role(self, role: str) -> bool: ...


# ---------------------------------------------------------------------------
# ObservabilityPort
# ---------------------------------------------------------------------------


class Span(Protocol):
    """OpenTelemetry-compatible span."""

    def set_status(self, status: str, message: str | None = None) -> None: ...
    def set_attribute(self, key: str, value: Any) -> None: ...
    def record_exception(self, exc: Exception) -> None: ...
    def __enter__(self) -> "Span": ...
    def __exit__(self, *args: Any) -> None: ...


class ObservabilityPort(Protocol):
    """Telemetry and audit logging abstraction."""

    def start_span(
        self,
        name: str,
        *,
        attributes: dict[str, Any] | None = None,
    ) -> Span: ...

    def record_metric(
        self,
        name: str,
        value: float,
        *,
        metric_type: str = "count",
        unit: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> None: ...

    def log_event(
        self,
        event_name: str,
        payload: dict[str, Any],
    ) -> None: ...


# ---------------------------------------------------------------------------
# LLMPort
# ---------------------------------------------------------------------------


@dataclass
class LLMMessage:
    role: str  # "system" | "user" | "assistant"
    content: str


@dataclass
class LLMUsage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class LLMResponse:
    content: str
    model: str | None = None
    usage: LLMUsage | None = None


@dataclass
class LLMOptions:
    model: str | None = None
    max_tokens: int | None = None
    temperature: float | None = None


class LLMPort(Protocol):
    """Language model inference abstraction."""

    async def complete(
        self,
        messages: list[LLMMessage],
        options: LLMOptions | None = None,
    ) -> LLMResponse: ...


# ---------------------------------------------------------------------------
# SessionStorePort
# ---------------------------------------------------------------------------


class SessionStorePort(Protocol):
    """Agent thread/session persistence abstraction."""

    async def save(self, thread_id: str, state: Any) -> None: ...
    async def load(self, thread_id: str) -> Any | None: ...
    async def delete(self, thread_id: str) -> None: ...
    async def list(self, prefix: str | None = None) -> list[str]: ...
    async def prune(self, ttl_ms: int = 3_600_000) -> int: ...


# ---------------------------------------------------------------------------
# FileStoragePort
# ---------------------------------------------------------------------------


@dataclass
class FileEntry:
    path: str
    url: str
    size: int
    created_at: float | None = None


@dataclass
class UploadOptions:
    content_type: str | None = None
    public: bool = False
    metadata: dict[str, str] | None = None


class FileStoragePort(Protocol):
    """Blob/file storage abstraction."""

    async def write(
        self,
        path: str,
        content: bytes | str,
        options: UploadOptions | None = None,
    ) -> str: ...  # returns URL

    async def read(self, path: str) -> bytes: ...
    async def delete(self, path: str) -> None: ...
    async def exists(self, path: str) -> bool: ...
    async def list(self, prefix: str | None = None) -> list[FileEntry]: ...


# ---------------------------------------------------------------------------
# EmbeddingPort
# ---------------------------------------------------------------------------


class EmbeddingPort(Protocol):
    """Semantic embedding abstraction."""

    @property
    def dimensions(self) -> int: ...

    async def embed(self, texts: list[str]) -> list[list[float]]: ...


# ---------------------------------------------------------------------------
# MigratableProtocol
# ---------------------------------------------------------------------------


class MigratableProtocol(Protocol):
    """Contrato para adaptadores que gerem o próprio schema de base de dados.

    Padrão: LangGraph checkpoint-postgres / Better Auth Kysely adapter.
    O método setup() é idempotente — pode ser chamado múltiplas vezes.

    Equivalente Python de MigratablePort (TypeScript, packages/ports/src/migratable.ts).
    """

    async def setup(self) -> None:
        """Cria tabelas e aplica todas as migrations pendentes.

        Deve ser chamado no startup da aplicação, antes de qualquer operação.
        É idempotente: não falha se as tabelas já existirem.
        """
        ...

    async def schema_version(self) -> int:
        """Retorna a versão corrente do schema aplicada nesta base de dados.

        Retorna 0 se nenhuma migration foi ainda aplicada.
        """
        ...


# ---------------------------------------------------------------------------
# ManifestSourceProtocol
# ---------------------------------------------------------------------------


@dataclass
class ManifestEntry:
    """Metadata returned by list() — enough to identify a manifest without loading it."""

    id: str
    kind: str
    version: str | None = None
    source: str | None = None


class ManifestSourceProtocol(Protocol):
    """Abstrai a origem do manifest de um recurso por ID e kind.

    Dois adaptadores principais:
      - FileSystemManifestSource: lê de .aap/<id>/manifest.yaml
      - PostgresManifestSource: lê de tabela aap_manifests (produção, K8s)

    Suporta todos os kinds registados no KindRegistry (Module, Agent, MCPTool, ...).
    Utilizadores podem registar custom kinds e usá-los transparentemente.

    Equivalente Python de ManifestSourcePort (TypeScript, packages/ports/src/manifest-source.ts).
    """

    async def load(self, id: str, kind: str = "Module") -> Any:
        """Carrega o manifest pelo ID e kind.

        Args:
            id:   identificador do recurso (ex: "my-module", "my-agent")
            kind: kind do manifest (ex: "Module", "Agent"). Default: "Module"

        Raises:
            ValueError: se o recurso não for encontrado ou o kind não estiver registado.
        """
        ...

    async def save(self, id: str, kind: str, manifest: Any) -> None:
        """Persiste o manifest na fonte.

        Args:
            id:       identificador do recurso
            kind:     kind do manifest
            manifest: objecto manifest
        """
        ...

    async def list(self, kind: str | None = None) -> list[ManifestEntry]:
        """Lista os manifests disponíveis, opcionalmente filtrado por kind.

        Returns a list of ManifestEntry objects with id, kind, version and source.
        """
        ...


# ---------------------------------------------------------------------------
# KnowledgePort
# ---------------------------------------------------------------------------


@dataclass
class KnowledgeDocument:
    """A document to be indexed into the knowledge store."""

    id: str
    content: str
    metadata: dict[str, Any] | None = None


@dataclass
class KnowledgeResult:
    """A search result from the knowledge store."""

    id: str
    content: str
    score: float
    metadata: dict[str, Any] | None = None


@dataclass
class SearchOptions:
    """Options for search queries."""

    top_k: int = 5
    min_score: float = 0.0
    filter: dict[str, Any] | None = None


class KnowledgeProtocol(Protocol):
    """Hexagonal port for knowledge retrieval and ingestion."""

    async def ingest(self, documents: list[KnowledgeDocument]) -> list[str]: ...
    async def search(self, query: str, options: SearchOptions | None = None) -> list[KnowledgeResult]: ...
    async def remove(self, ids: list[str]) -> None: ...
    async def count(self) -> int: ...


# ---------------------------------------------------------------------------
# New ports (external tooling adoption: JSONata, Spectral, OPA, CUE)
# ---------------------------------------------------------------------------

from .query import QueryPort
from .linter import LinterPort, LintResult, CategoryScore, Diagnostic
from .policy_engine import PolicyEnginePort, PolicyDecision, PolicyViolation, PolicySource, PolicyInput
from .composer import ComposerPort, ComposedResult, Conflict, ComposerValidationResult
from .guardrail import GuardrailPort, GuardrailContext, GuardrailDecision, GuardrailViolation
from .cost_tracker import CostTrackerPort, CostUsage, CostFilter, CostSummary, BudgetStatus
from .agent_telemetry import AgentTelemetryPort, AgentSpanContext, SpanHandle, AgentEvent, AgentSpanResult
from .tenant_resolver import TenantResolverPort, TenantContext
