"""PolicyEnginePort — evaluate policies against manifests."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass
class PolicyViolation:
    policy: str
    rule: str
    message: str
    severity: str  # "error" | "warning" | "info"
    path: str | None = None
    suggestion: str | None = None


@dataclass
class PolicyDecision:
    passed: bool = True
    score: float = 0
    max_score: float = 0
    percentage: float = 100
    grade: str = "A"
    violations: list[PolicyViolation] = field(default_factory=list)
    breakdown: dict[str, Any] = field(default_factory=dict)


@dataclass
class PolicySource:
    type: str  # "rego" | "yaml"
    content: str
    id: str


@dataclass
class PolicyInput:
    manifest: dict
    context: dict | None = None
    policies: list[str] | None = None


@runtime_checkable
class PolicyEnginePort(Protocol):
    async def evaluate(self, input: PolicyInput) -> PolicyDecision: ...
    async def load_policies(self, sources: list[PolicySource]) -> None: ...
    def is_ready(self) -> bool: ...
