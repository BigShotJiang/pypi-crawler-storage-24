"""ComposerPort — compose multi-file manifests."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable

from .linter import Diagnostic


@dataclass
class Conflict:
    path: str
    values: list[Any] = field(default_factory=list)
    sources: list[str] = field(default_factory=list)


@dataclass
class ComposedResult:
    data: dict = field(default_factory=dict)
    sources: list[str] = field(default_factory=list)
    conflicts: list[Conflict] = field(default_factory=list)


@dataclass
class ComposerValidationResult:
    valid: bool = True
    errors: list[Diagnostic] = field(default_factory=list)


@runtime_checkable
class ComposerPort(Protocol):
    async def compose(self, files: list[str]) -> ComposedResult: ...
    async def validate(self, data: Any, schema: str) -> ComposerValidationResult: ...
    async def export(self, files: list[str], format: str) -> str: ...
