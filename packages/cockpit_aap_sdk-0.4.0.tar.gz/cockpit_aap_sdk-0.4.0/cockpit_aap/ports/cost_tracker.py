"""CostTrackerPort — FinOps tracking for AI agents."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@dataclass
class CostUsage:
    agent_id: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float | None = None
    timestamp: float = 0
    request_id: str | None = None
    tenant_id: str | None = None


@dataclass
class CostFilter:
    agent_id: str | None = None
    model: str | None = None
    since: float | None = None
    until: float | None = None
    tenant_id: str | None = None


@dataclass
class CostSummary:
    total_cost: float = 0
    total_tokens: int = 0
    entries: list[CostUsage] = field(default_factory=list)


@dataclass
class TimeseriesEntry:
    bucket: str = ""
    cost: float = 0
    requests: int = 0


@dataclass
class BudgetStatus:
    within_budget: bool = True
    spent: float = 0
    limit: float = 0
    currency: str = "USD"
    period: str = "monthly"


@runtime_checkable
class CostTrackerPort(Protocol):
    async def record(self, usage: CostUsage) -> None: ...
    async def query(self, filter: CostFilter) -> CostSummary: ...
    async def query_timeseries(self, filter: CostFilter, granularity: str = "hour") -> list[TimeseriesEntry]: ...
    async def check_budget(self, agent_id: str, tenant_id: str | None = None) -> BudgetStatus: ...
