"""AgentTelemetryPort — OTEL-compatible agent tracing."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Protocol, runtime_checkable


@dataclass
class AgentSpanContext:
    agent_id: str
    request_id: str
    model: str
    user_id: str | None = None
    tenant_id: str | None = None


@dataclass
class SpanHandle:
    span_id: str
    trace_id: str


@dataclass
class AgentEvent:
    name: str
    attributes: dict[str, str | int | float | bool] = field(default_factory=dict)


@dataclass
class AgentSpanResult:
    status: str = "ok"  # "ok" | "error" | "blocked" | "budget_exceeded"
    duration_ms: float | None = None
    attributes: dict[str, str | int | float | bool] = field(default_factory=dict)


@runtime_checkable
class AgentTelemetryPort(Protocol):
    def start_agent_span(self, context: AgentSpanContext) -> SpanHandle: ...
    def record_event(self, span: SpanHandle, event: AgentEvent) -> None: ...
    def end_span(self, span: SpanHandle, result: AgentSpanResult) -> None: ...
