"""LinterPort — lint manifests with weighted scoring."""
from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass
class Diagnostic:
    path: str
    message: str
    severity: str  # "error" | "warning" | "info" | "hint"
    code: str | None = None
    source: str | None = None


@dataclass
class CategoryScore:
    score: float = 0
    max_score: float = 0
    diagnostics: list[Diagnostic] = field(default_factory=list)


@dataclass
class LintResult:
    diagnostics: list[Diagnostic] = field(default_factory=list)
    score: float = 0
    max_score: float = 0
    grade: str = "A"
    categories: dict[str, CategoryScore] = field(default_factory=dict)


@runtime_checkable
class LinterPort(Protocol):
    async def lint(self, document: dict, options: dict | None = None) -> LintResult: ...
