"""AAP Scribe — Manifest-driven LLM orchestrator for AI-assisted completion.

Port of ``@ruinosus/aap-scribe`` (TypeScript).

Provides:
- ``Scribe``             — manifest-driven completion/compose/preview engine
- ``create_scribe``      — factory
- ``quick_match``        — zero-latency ghost trigger matching
- ``build_artifact_patterns_table`` — knowledge table builder
- LLM adapter re-exports: ``create_openai_llm``, ``create_anthropic_llm``,
  ``create_azure_openai_llm``, ``create_noop_llm``
"""

from cockpit_aap.scribe.types import (
    ScribeSource,
    ScribeResult,
    ScribeContext,
    ScribeCallOptions,
    ScribeOptions,
)
from cockpit_aap.scribe.scribe import Scribe, create_scribe
from cockpit_aap.scribe.quick_match import quick_match
from cockpit_aap.scribe.artifact_patterns import build_artifact_patterns_table
from cockpit_aap.scribe.azure_openai_llm import create_azure_openai_llm
from cockpit_aap.scribe.agents import (
    RouterDecision,
    EnhancedResult,
    run_router,
    run_completion,
    run_compose,
    run_enhanced,
)

# Re-export existing LLM adapters
from cockpit_aap.adapters.openai_llm import OpenAILLMAdapter, create_openai_llm
from cockpit_aap.adapters.anthropic_llm import AnthropicLLMAdapter, create_anthropic_llm
from cockpit_aap.adapters.noop_adapters import NoopLLMAdapter, create_noop_llm

__all__ = [
    # Types
    "ScribeSource",
    "ScribeResult",
    "ScribeContext",
    "ScribeCallOptions",
    "ScribeOptions",
    # Scribe
    "Scribe",
    "create_scribe",
    # Utilities
    "quick_match",
    "build_artifact_patterns_table",
    # LLM adapters
    "create_openai_llm",
    "create_anthropic_llm",
    "create_azure_openai_llm",
    "create_noop_llm",
    "OpenAILLMAdapter",
    "AnthropicLLMAdapter",
    "NoopLLMAdapter",
    # Agents
    "RouterDecision",
    "EnhancedResult",
    "run_router",
    "run_completion",
    "run_compose",
    "run_enhanced",
]
