"""Build artifact patterns table from spec.knowledge for prompt injection.

Port of ``packages/scribe/src/artifact-patterns.ts``.
"""

from __future__ import annotations

from typing import Any


def build_artifact_patterns_table(manifest: Any) -> str:
    """Build a markdown table from spec.knowledge[] for LLM prompts.

    Returns empty string if no knowledge section exists.
    """
    if isinstance(manifest, dict):
        spec = manifest.get("spec") or {}
    else:
        spec = getattr(manifest, "spec", None) or {}
        if not isinstance(spec, dict):
            spec = vars(spec) if hasattr(spec, "__dict__") else {}

    knowledge = spec.get("knowledge") or []
    if not knowledge:
        return ""

    rows: list[str] = []
    for k in knowledge:
        if isinstance(k, dict):
            kind_val = k.get("kind", "")
            pattern_val = k.get("keyPattern") or k.get("key_pattern", "")
            desc_val = k.get("description", "")
        else:
            kind_val = getattr(k, "kind", "")
            pattern_val = getattr(k, "key_pattern", "") or getattr(k, "keyPattern", "")
            desc_val = getattr(k, "description", "")
        rows.append(f"| {kind_val} | {pattern_val} | {desc_val} |")

    return "\n".join(
        [
            "| Kind | Key Pattern | Description |",
            "|------|-------------|-------------|",
            *rows,
        ]
    )
