"""Scribe agent runners — router, completion, compose, enhanced.

Port of ``packages/scribe/src/agents/*.ts``.

Uses the AAP LLMPort protocol instead of LangChain's BaseChatModel.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from cockpit_aap.ports import LLMMessage


@dataclass
class RouterDecision:
    decision: str = "NO_SEARCH"  # "SEARCH" | "NO_SEARCH"
    pattern: str | None = None
    reason: str | None = None


async def run_router(prompt: str, llm: Any) -> RouterDecision:
    """Run the Decision Router agent.

    Args:
        prompt: Fully interpolated instruction string.
        llm: Any LLMPort-compatible adapter.
    """
    response = await llm.complete([LLMMessage(role="user", content=prompt)])
    text = (response.content or "").strip()

    # Expected format: SEARCH|pattern or NO_SEARCH|reason
    parts = text.split("|", 1)
    if len(parts) == 2:
        decision, value = parts[0].strip(), parts[1].strip()
        if decision == "SEARCH":
            return RouterDecision(decision="SEARCH", pattern=value)
        if decision == "NO_SEARCH":
            return RouterDecision(decision="NO_SEARCH", reason=value)

    return RouterDecision(decision="NO_SEARCH", reason="malformed_response")


async def run_completion(prompt: str, llm: Any) -> str | None:
    """Run the Completion agent. Returns trimmed text or None."""
    response = await llm.complete([LLMMessage(role="user", content=prompt)])
    text = (response.content or "").strip()
    return text or None


async def run_compose(prompt: str, llm: Any) -> str:
    """Run the Compose agent. Returns markdown analysis."""
    response = await llm.complete([LLMMessage(role="user", content=prompt)])
    return response.content or ""


@dataclass
class EnhancedResult:
    rewritten_intent: str = ""
    key_points: list[str] | None = None
    suggested_full_message: str = ""


async def run_enhanced(prompt: str, llm: Any) -> EnhancedResult:
    """Run the Enhanced agent. Returns parsed JSON preview.

    Falls back to raw text if JSON parsing fails.
    """
    response = await llm.complete([LLMMessage(role="user", content=prompt)])
    text = response.content or ""

    try:
        parsed = json.loads(text)
        if (
            isinstance(parsed, dict)
            and isinstance(parsed.get("rewrittenIntent"), str)
            and isinstance(parsed.get("keyPoints"), list)
            and isinstance(parsed.get("suggestedFullMessage"), str)
        ):
            return EnhancedResult(
                rewritten_intent=parsed["rewrittenIntent"],
                key_points=parsed["keyPoints"],
                suggested_full_message=parsed["suggestedFullMessage"],
            )
    except (json.JSONDecodeError, TypeError):
        pass

    return EnhancedResult(
        rewritten_intent=text,
        key_points=[],
        suggested_full_message=text,
    )
