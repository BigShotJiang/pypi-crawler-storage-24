"""Zero-latency quick match via ghost triggers.

Port of ``packages/scribe/src/quick-match.ts``.
"""

from __future__ import annotations

from typing import Any


def quick_match(manifest: Any, text: str, stage: str) -> str | None:
    """Synchronous zero-latency completion via ghostTriggers.

    Returns the completion suffix when the input (trimmed, lowercased)
    exactly matches a key in any skill's ghostTriggers for the given stage.
    Returns None if no match.
    """
    if not text:
        return None

    normalized = text.strip().lower()

    if isinstance(manifest, dict):
        spec = manifest.get("spec") or {}
    else:
        spec = getattr(manifest, "spec", None) or {}
        if not isinstance(spec, dict):
            spec = vars(spec) if hasattr(spec, "__dict__") else {}

    skills = spec.get("skills") or []

    # Filter skills by trigger == "input_context" and matching stage
    for skill in skills:
        trigger = skill.get("trigger", "")
        if trigger != "input_context":
            continue
        if skill.get("stage") != stage:
            continue
        ghost_triggers = skill.get("ghostTriggers") or {}
        if isinstance(ghost_triggers, dict):
            completion = ghost_triggers.get(normalized)
            if completion is not None:
                return str(completion)

    return None
