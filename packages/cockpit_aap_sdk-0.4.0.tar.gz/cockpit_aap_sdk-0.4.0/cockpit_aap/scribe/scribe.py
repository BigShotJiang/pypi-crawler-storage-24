"""Scribe — manifest-driven AI completion engine.

Port of ``packages/scribe/src/scribe.ts``.

The Scribe loads a built-in manifest (or accepts one from the caller),
merges it with an optional user manifest, and orchestrates a pipeline of
agents (router → completion / compose / enhanced) to provide context-aware
text completion or analysis.
"""

from __future__ import annotations

import re
import time
from dataclasses import dataclass, field
from typing import Any

from cockpit_aap.manifest.helpers import get_manifest_agent_instruction
from cockpit_aap.manifest.merge import merge_manifests
from cockpit_aap.manifest.types import Manifest, ManifestMetadata, ManifestSpec

from .agents import run_completion, run_compose, run_enhanced, run_router
from .artifact_patterns import build_artifact_patterns_table
from .quick_match import quick_match as _quick_match
from .types import ScribeCallOptions, ScribeOptions, ScribeResult


# ---------------------------------------------------------------------------
# Simple Handlebars-like template interpolation for agent instructions
# ---------------------------------------------------------------------------

_HB_VAR = re.compile(r"\{\{(\w+)\}\}")
_HB_IF = re.compile(
    r"\{\{#if\s+(\w+)\}\}(.*?)\{\{/if\}\}", re.DOTALL
)
_HB_UNLESS = re.compile(
    r"\{\{#unless\s+(\w+)\}\}(.*?)\{\{/unless\}\}", re.DOTALL
)


def _render_template(text: str, ctx: dict[str, Any]) -> str:
    """Minimal Handlebars-style interpolation for agent instructions."""
    # {{#if key}}...{{/if}}
    def _if_replace(m: re.Match) -> str:
        key = m.group(1)
        return m.group(2) if ctx.get(key) else ""

    result = _HB_IF.sub(_if_replace, text)

    # {{#unless key}}...{{/unless}}
    def _unless_replace(m: re.Match) -> str:
        key = m.group(1)
        return m.group(2) if not ctx.get(key) else ""

    result = _HB_UNLESS.sub(_unless_replace, result)

    # {{var}}
    def _var_replace(m: re.Match) -> str:
        return str(ctx.get(m.group(1), ""))

    result = _HB_VAR.sub(_var_replace, result)
    return result


def _get_instruction(manifest: Manifest, agent_id: str, ctx: dict[str, Any]) -> str:
    """Get agent instruction with template interpolation."""
    raw = get_manifest_agent_instruction(manifest, agent_id)
    if not raw or not ctx:
        return raw
    full_ctx = {
        "moduleId": manifest.metadata.name if manifest.metadata else "",
        "moduleName": (
            (manifest.metadata.display_name or manifest.metadata.name)
            if manifest.metadata
            else ""
        ),
        "version": (manifest.metadata.version or "") if manifest.metadata else "",
        **ctx,
    }
    return _render_template(raw, full_ctx)


# ---------------------------------------------------------------------------
# Scribe protocol / class
# ---------------------------------------------------------------------------


@dataclass
class Scribe:
    """Manifest-driven AI completion engine."""

    _llm: Any
    _mcp: Any | None
    _language: str
    _manifest: Manifest

    def quick_match(self, text: str, stage: str) -> str | None:
        """Zero-latency ghost trigger.  Returns ``None`` when no pattern matches."""
        return _quick_match(self._manifest, text, stage)

    async def complete(self, text: str, options: ScribeCallOptions) -> ScribeResult:
        """Run the full completion pipeline: quick_match → router → completion."""
        start = time.monotonic()

        # Phase 0: Quick Match
        qm = _quick_match(self._manifest, text, options.stage)
        if qm is not None:
            return ScribeResult(
                suggestion=qm,
                confidence=1.0,
                source="quick-match",
                latency=time.monotonic() - start,
            )

        ctx, _artifacts, source = await self._run_preamble(text, options)
        completion_ctx = {**ctx, "artifacts": _artifacts}
        prompt = _get_instruction(self._manifest, "scribe-completion", completion_ctx)
        suggestion = await run_completion(prompt, self._llm)

        return ScribeResult(
            suggestion=suggestion,
            confidence=0.8 if suggestion else 0.0,
            source=source,
            latency=time.monotonic() - start,
        )

    async def compose(self, text: str, options: ScribeCallOptions) -> ScribeResult:
        """Run the compose pipeline: router → compose agent."""
        start = time.monotonic()

        ctx, _artifacts, source = await self._run_preamble(text, options)
        compose_ctx = {**ctx, "artifacts": _artifacts}
        prompt = _get_instruction(self._manifest, "scribe-compose", compose_ctx)
        suggestion = await run_compose(prompt, self._llm)

        return ScribeResult(
            suggestion=suggestion,
            confidence=0.75,
            source=source,
            latency=time.monotonic() - start,
        )

    async def preview(self, text: str, options: ScribeCallOptions) -> ScribeResult:
        """Run the enhanced/preview pipeline: router → enhanced agent (JSON)."""
        start = time.monotonic()

        ctx, _artifacts, source = await self._run_preamble(text, options)
        enhanced_ctx = {
            **ctx,
            "artifacts": _artifacts,
            "currentSuggestion": options.current_suggestion or "",
        }
        prompt = _get_instruction(self._manifest, "scribe-enhanced", enhanced_ctx)
        parsed = await run_enhanced(prompt, self._llm)

        return ScribeResult(
            suggestion=parsed.suggested_full_message,
            confidence=0.85,
            source=source,
            latency=time.monotonic() - start,
            rewritten_intent=parsed.rewritten_intent,
            key_points=parsed.key_points,
            suggested_full_message=parsed.suggested_full_message,
        )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_context(
        self, text: str, opts: ScribeCallOptions
    ) -> dict[str, Any]:
        """Build the template context dict."""
        table = build_artifact_patterns_table(self._manifest)
        ctx: dict[str, Any] = {
            "text": text,
            "stage": opts.stage,
            "language": self._language,
            "artifactPatternsTable": table,
        }
        if opts.context:
            ctx.update(opts.context)
        return ctx

    async def _run_preamble(
        self, text: str, opts: ScribeCallOptions
    ) -> tuple[dict[str, Any], str, str]:
        """Run the router agent and determine source strategy.

        Returns:
            (handlebars_ctx, artifacts_str, source_label)
        """
        ctx = self._build_context(text, opts)
        router_prompt = _get_instruction(self._manifest, "scribe-router", ctx)
        decision = await run_router(router_prompt, self._llm)

        artifacts = ""
        source = "llm-direct"
        if decision.decision == "SEARCH" and decision.pattern:
            source = "mcp-static" if self._mcp else "llm-direct"

        return ctx, artifacts, source


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def _empty_manifest() -> Manifest:
    """Return a minimal empty manifest to use as fallback."""
    return Manifest(
        api_version="cockpit.io/v1",
        kind="Module",
        metadata=ManifestMetadata(name="scribe-fallback"),
        spec=ManifestSpec(),
    )


def create_scribe(options: ScribeOptions) -> Scribe:
    """Create a :class:`Scribe` instance.

    Args:
        options: Configuration — at minimum an ``llm`` adapter is required.

    Returns:
        A fully configured Scribe ready to call ``complete()``, ``compose()``,
        ``preview()``, or ``quick_match()``.
    """
    base = options.manifest or _empty_manifest()
    effective = base  # no built-in manifest in Python — use caller's manifest directly

    return Scribe(
        _llm=options.llm,
        _mcp=options.mcp_endpoint,
        _language=options.language or "en",
        _manifest=effective,
    )
