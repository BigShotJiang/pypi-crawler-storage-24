"""Scribe types — result, options, context.

Port of ``packages/scribe/src/types.ts``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal


ScribeSource = Literal["quick-match", "llm-direct", "mcp-static", "mcp-dynamic"]


@dataclass
class ScribeResult:
    """Result of a scribe operation."""

    suggestion: str | None = None
    confidence: float = 0.0
    source: ScribeSource = "llm-direct"
    latency: float = 0.0  # ms
    artifacts_used: list[str] | None = None
    rewritten_intent: str | None = None
    key_points: list[str] | None = None
    suggested_full_message: str | None = None


ScribeContext = dict[str, Any]


@dataclass
class ScribeCallOptions:
    """Options passed to scribe operations."""

    stage: str = ""
    context: ScribeContext | None = None
    current_suggestion: str | None = None


@dataclass
class ScribeOptions:
    """Configuration for creating a Scribe instance."""

    manifest: Any = None  # Manifest dict
    llm: Any = None  # LLMPort
    mcp_endpoint: str | None = None
    mcp_api_key: str | None = None
    language: str = "en"
