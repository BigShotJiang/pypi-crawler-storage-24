"""Azure OpenAI LLM adapter — wraps :func:`create_openai_llm` with Azure endpoint.

Port of ``packages/scribe/src/adapters/azure-openai-llm.ts``.
"""

from __future__ import annotations

from cockpit_aap.adapters.openai_llm import OpenAILLMAdapter, create_openai_llm


def create_azure_openai_llm(
    api_key: str,
    endpoint: str,
    deployment: str,
    api_version: str = "2024-02-01",
) -> OpenAILLMAdapter:
    """Create an LLMPort adapter backed by Azure OpenAI.

    Args:
        api_key: Azure OpenAI API key.
        endpoint: e.g. ``https://my-resource.openai.azure.com``
        deployment: Deployment name (used as the model).
        api_version: Azure API version string.

    Returns:
        An :class:`OpenAILLMAdapter` instance configured for Azure.
    """
    base_url = f"{endpoint.rstrip('/')}/openai/deployments/{deployment}"
    return create_openai_llm(api_key=api_key, model=deployment, base_url=base_url)
