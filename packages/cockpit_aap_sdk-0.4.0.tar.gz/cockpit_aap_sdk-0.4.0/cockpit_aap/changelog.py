"""Changelog — Python port of the TypeScript ``changelog.ts``.

Provides reading/writing module changelogs to the artifact server and
building changelog entries from bootstrap results.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

META_KEY_SUFFIX = "._meta.changelog"


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class ChangelogNote:
    """A developer-authored change note."""

    type: str  # "added" | "changed" | "removed" | "fixed" | "deprecated"
    summary: str
    key: str | None = None


@dataclass
class ChangelogPreservedEntry:
    """Entry describing an artifact that was preserved (not overwritten)."""

    key: str
    reason: str  # "conflict:server-wins" | "conflict:log-warning" | "server-drifted"
    detail: str | None = None


@dataclass
class ChangelogEntry:
    """A single changelog entry for a bootstrap run."""

    version: str
    date: str
    type: str  # "release" | "upgrade"
    title: str
    notes: list[ChangelogNote] = field(default_factory=list)
    artifacts: dict[str, Any] = field(default_factory=dict)
    agents: dict[str, Any] = field(default_factory=dict)
    feedback_addressed: list[str] = field(default_factory=list)


@dataclass
class ModuleChangelog:
    """Full changelog for a module."""

    module: str
    entries: list[ChangelogEntry] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _escape_regex(s: str) -> str:
    return re.escape(s)


def _extract_value(content: Any) -> str | None:
    if not content or not isinstance(content, dict):
        return None

    artifacts = content.get("artifacts")
    if isinstance(artifacts, list) and len(artifacts) > 0:
        first = artifacts[0]
        if isinstance(first, dict) and isinstance(first.get("value"), str):
            return first["value"]

    if isinstance(content.get("value"), str):
        return content["value"]
    if isinstance(content.get("content"), str):
        return content["content"]
    return None


# ---------------------------------------------------------------------------
# Read / Write
# ---------------------------------------------------------------------------


async def read_changelog(
    sdk: Any,
    namespace: str,
    module: str,
) -> ModuleChangelog | None:
    """Read the changelog from the artifact server.

    Returns ``None`` if not found or on error.
    """
    try:
        key = f"{module}{META_KEY_SUFFIX}"
        result = await sdk[namespace].get_artifact(
            key_pattern=f"^{_escape_regex(key)}$"
        )

        content = result.content if hasattr(result, "content") else result
        value = _extract_value(content) if isinstance(content, dict) else None
        if not value:
            return None

        raw = json.loads(value)
        return _parse_module_changelog(raw)
    except Exception:
        return None


async def write_changelog(
    sdk: Any,
    namespace: str,
    module: str,
    changelog: ModuleChangelog,
) -> None:
    """Write the changelog to the artifact server."""
    from .meta import _upsert_meta_artifact  # noqa: WPS433

    key = f"{module}{META_KEY_SUFFIX}"
    value = json.dumps(_module_changelog_to_dict(changelog), indent=2)
    await _upsert_meta_artifact(
        sdk, namespace, key, value,
        f'Changelog for module "{module}"',
        module,
    )


# ---------------------------------------------------------------------------
# Build entry
# ---------------------------------------------------------------------------


def build_changelog_entry(
    definition: Any,
    resolved_artifacts: dict[str, Any],
    resolved_agents: dict[str, Any],
    meta: Any | None,
    summary: Any,
    feedback_addressed: list[str] | None = None,
) -> ChangelogEntry:
    """Build a changelog entry for the current bootstrap run."""
    version = getattr(definition, "version", None) or "0.0.0"

    # Developer notes for this version
    dev_notes: list[ChangelogNote] = []
    changelog_entries = getattr(definition, "changelog", None) or []
    for c in changelog_entries:
        c_version = c.version if hasattr(c, "version") else c.get("version")
        if c_version == version:
            raw_notes = c.notes if hasattr(c, "notes") else c.get("notes", [])
            for n in raw_notes:
                dev_notes.append(ChangelogNote(
                    type=n.type if hasattr(n, "type") else n["type"],
                    summary=n.summary if hasattr(n, "summary") else n["summary"],
                    key=n.key if hasattr(n, "key") else n.get("key"),
                ))
            break

    # Classify artifact changes
    created: list[str] = []
    upgraded: list[str] = []
    for key, artifact in resolved_artifacts.items():
        if "._meta." in key:
            continue
        source = artifact.source if hasattr(artifact, "source") else artifact.get("source")
        if source == "created":
            created.append(key)
        elif source == "upgraded":
            upgraded.append(key)

    # Preserved artifacts from meta conflicts
    preserved: list[dict[str, Any]] = []
    if meta:
        conflicts = (
            meta.conflicts if hasattr(meta, "conflicts") else meta.get("conflicts", {})
        )
        if isinstance(conflicts, dict):
            for key, conflict in conflicts.items():
                resolution = (
                    conflict.resolution
                    if hasattr(conflict, "resolution")
                    else conflict.get("resolution")
                )
                if resolution == "server-wins":
                    preserved.append({
                        "key": key,
                        "reason": "conflict:server-wins",
                        "detail": "Code changed but PO had edits — PO version kept",
                    })
                elif resolution == "log-warning":
                    preserved.append({
                        "key": key,
                        "reason": "conflict:log-warning",
                        "detail": "Code changed but PO had edits — PO version kept with warning",
                    })

    # Agent creations
    agents_created: list[str] = []
    for name, agent in resolved_agents.items():
        source = agent.source if hasattr(agent, "source") else agent.get("source")
        if source == "created":
            agents_created.append(name)

    # Determine title
    artifacts_from_server = (
        summary.artifacts_from_server
        if hasattr(summary, "artifacts_from_server")
        else summary.get("artifactsFromServer", 0)
    )
    artifacts_upgraded = (
        summary.artifacts_upgraded
        if hasattr(summary, "artifacts_upgraded")
        else summary.get("artifactsUpgraded", 0)
    )
    is_initial = artifacts_from_server == 0 and artifacts_upgraded == 0
    title = (
        "Initial release"
        if is_initial
        else (dev_notes[0].summary if dev_notes else f"Upgrade to v{version}")
    )

    return ChangelogEntry(
        version=version,
        date=datetime.now(timezone.utc).isoformat(),
        type="release" if is_initial else "upgrade",
        title=title,
        notes=dev_notes,
        artifacts={
            "created": created,
            "upgraded": upgraded,
            "preserved": preserved,
            "removed": [],
        },
        agents={
            "created": agents_created,
            "upgraded": [],
            "removed": [],
        },
        feedback_addressed=feedback_addressed or [],
    )


# ---------------------------------------------------------------------------
# Merge
# ---------------------------------------------------------------------------


def merge_changelog(
    existing: ModuleChangelog | None,
    module: str,
    new_entry: ChangelogEntry,
) -> ModuleChangelog:
    """Merge a new entry into an existing changelog.

    If an entry for the same version exists, replaces it.
    """
    entries = list(existing.entries) if existing else []

    # Replace if same version exists, otherwise prepend
    idx = next(
        (i for i, e in enumerate(entries) if e.version == new_entry.version),
        -1,
    )
    if idx >= 0:
        entries[idx] = new_entry
    else:
        entries.insert(0, new_entry)

    return ModuleChangelog(module=module, entries=entries)


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


def _module_changelog_to_dict(changelog: ModuleChangelog) -> dict[str, Any]:
    return {
        "module": changelog.module,
        "entries": [_changelog_entry_to_dict(e) for e in changelog.entries],
    }


def _changelog_entry_to_dict(entry: ChangelogEntry) -> dict[str, Any]:
    return {
        "version": entry.version,
        "date": entry.date,
        "type": entry.type,
        "title": entry.title,
        "notes": [
            {"type": n.type, "summary": n.summary, **({"key": n.key} if n.key else {})}
            for n in entry.notes
        ],
        "artifacts": entry.artifacts,
        "agents": entry.agents,
        "feedbackAddressed": entry.feedback_addressed,
    }


def _parse_module_changelog(raw: dict[str, Any]) -> ModuleChangelog:
    """Parse raw JSON into ModuleChangelog."""
    entries: list[ChangelogEntry] = []
    for e in raw.get("entries", []):
        notes = [
            ChangelogNote(type=n["type"], summary=n["summary"], key=n.get("key"))
            for n in e.get("notes", [])
        ]
        entries.append(ChangelogEntry(
            version=e["version"],
            date=e["date"],
            type=e["type"],
            title=e["title"],
            notes=notes,
            artifacts=e.get("artifacts", {}),
            agents=e.get("agents", {}),
            feedback_addressed=e.get("feedbackAddressed", []),
        ))
    return ModuleChangelog(module=raw["module"], entries=entries)
