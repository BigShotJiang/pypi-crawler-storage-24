"""Feedback — Python port of the TypeScript ``feedback.ts``.

Provides reading/writing PO feedback artifacts and analyzing which
feedback items were potentially addressed by a bootstrap run.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

META_KEY_SUFFIX = "._meta.feedback"


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class FeedbackItem:
    """A single PO feedback item."""

    id: str
    target: str  # artifact key
    status: str  # "open" | "resolved" | "potentially-addressed"
    comment: str | None = None
    created_at: str | None = None
    status_reason: str | None = None


@dataclass
class ModuleFeedback:
    """All feedback items for a module."""

    module: str
    items: list[FeedbackItem] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _escape_regex(s: str) -> str:
    return re.escape(s)


def _extract_value(content: Any) -> str | None:
    if not content or not isinstance(content, dict):
        return None

    artifacts = content.get("artifacts")
    if isinstance(artifacts, list) and len(artifacts) > 0:
        first = artifacts[0]
        if isinstance(first, dict) and isinstance(first.get("value"), str):
            return first["value"]

    if isinstance(content.get("value"), str):
        return content["value"]
    if isinstance(content.get("content"), str):
        return content["content"]
    return None


# ---------------------------------------------------------------------------
# Read / Write
# ---------------------------------------------------------------------------


async def read_feedback(
    sdk: Any,
    namespace: str,
    module: str,
) -> ModuleFeedback | None:
    """Read the feedback artifact from the server.

    Returns ``None`` if not found or on error.
    """
    try:
        key = f"{module}{META_KEY_SUFFIX}"
        result = await sdk[namespace].get_artifact(
            key_pattern=f"^{_escape_regex(key)}$"
        )

        content = result.content if hasattr(result, "content") else result
        value = _extract_value(content) if isinstance(content, dict) else None
        if not value:
            return None

        raw = json.loads(value)
        return _parse_module_feedback(raw)
    except Exception:
        return None


async def write_feedback(
    sdk: Any,
    namespace: str,
    module: str,
    feedback: ModuleFeedback,
) -> None:
    """Write the updated feedback artifact back to the server."""
    key = f"{module}{META_KEY_SUFFIX}"
    value = json.dumps(_module_feedback_to_dict(feedback), indent=2)

    try:
        await sdk[namespace].update_artifact(key=key, value=value)
    except Exception:
        # Feedback artifact is PO-created, don't create if doesn't exist
        pass


# ---------------------------------------------------------------------------
# Analyze
# ---------------------------------------------------------------------------


def analyze_feedback_status(
    feedback: ModuleFeedback | None,
    resolved_artifacts: dict[str, Any],
) -> tuple[ModuleFeedback | None, list[str]]:
    """Update feedback status based on which artifacts changed.

    A feedback item is "potentially-addressed" when its target artifact
    was created or upgraded in this bootstrap run.

    Returns ``(updated_feedback, addressed_ids)``.
    """
    if not feedback or not feedback.items:
        return feedback, []

    addressed: list[str] = []
    updated_items: list[FeedbackItem] = []

    for item in feedback.items:
        if item.status != "open":
            updated_items.append(item)
            continue

        resolved = resolved_artifacts.get(item.target)
        if resolved:
            source = (
                resolved.source
                if hasattr(resolved, "source")
                else resolved.get("source")
            )
            if source in ("created", "upgraded"):
                addressed.append(item.id)
                updated_items.append(FeedbackItem(
                    id=item.id,
                    target=item.target,
                    status="potentially-addressed",
                    comment=item.comment,
                    created_at=item.created_at,
                    status_reason=f'Target artifact "{item.target}" was {source} in this version',
                ))
                continue

        updated_items.append(item)

    return (
        ModuleFeedback(module=feedback.module, items=updated_items),
        addressed,
    )


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------


def _module_feedback_to_dict(feedback: ModuleFeedback) -> dict[str, Any]:
    return {
        "module": feedback.module,
        "items": [
            {
                "id": item.id,
                "target": item.target,
                "status": item.status,
                **({"comment": item.comment} if item.comment else {}),
                **({"createdAt": item.created_at} if item.created_at else {}),
                **({"statusReason": item.status_reason} if item.status_reason else {}),
            }
            for item in feedback.items
        ],
    }


def _parse_module_feedback(raw: dict[str, Any]) -> ModuleFeedback:
    items = [
        FeedbackItem(
            id=item["id"],
            target=item["target"],
            status=item["status"],
            comment=item.get("comment"),
            created_at=item.get("createdAt"),
            status_reason=item.get("statusReason"),
        )
        for item in raw.get("items", [])
    ]
    return ModuleFeedback(module=raw["module"], items=items)
