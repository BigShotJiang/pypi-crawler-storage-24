"""Cockpit AAP SDK — Async Python client for the AAP Gateway."""

from cockpit_aap.client import AAPGatewayClient
from cockpit_aap.multi_client import MultiAAPClient, create_multi_aap_client
from cockpit_aap.transport import Transport, TransportContext
from cockpit_aap.transports.rest import RestTransport
from cockpit_aap.transports.mcp import McpTransport
from cockpit_aap.mcp_types import (
    AAPServerConfig,
    MultiAAPClientConfig,
    PromptArgument,
    PromptMessage,
    PromptResult,
    PromptSchema,
    ResourceContents,
    ResourceSchema,
    ResourceTemplate,
    ToolResult,
    ToolSchema,
)
from cockpit_aap.bootstrap import bootstrap_manifest, ManifestResult, ResolvedAgent
from cockpit_aap.bootstrap_kind import bootstrap_kind, BootstrapKindResult
from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAgent,
    ManifestAgentExecution,
    ManifestConnection,
    ManifestProject,
    ManifestProjectResolved,
    ManifestResolvedModule,
)
from cockpit_aap.manifest.scanner import scan_manifest
from cockpit_aap.manifest.parser import parse_manifest
from cockpit_aap.conformance import (
    ConformanceViolation,
    ConformanceResult,
    ManifestPolicyViolation,
    ManifestPolicyResult,
    HealthCategory,
    HealthResult,
    evaluate_conformance,
    evaluate_manifest_policy,
    check_health,
    eval_expression,
    field_exists,
    get_field_value,
    grade_from_pct,
    grade_to_number,
)
from cockpit_aap.manifest.writer import serialize_manifest, write_manifest, WriteManifestOptions
from cockpit_aap.manifest.dependencies import (
    find_package_root,
    get_package_connections,
    load_manifest_dependencies,
)
from cockpit_aap.manifest.helpers import (
    get_project_default_module,
    get_project_enabled_modules,
    get_project_module,
    get_project_module_access,
    get_project_module_connections,
    get_project_module_i18n,
    get_project_module_theme,
    # Persona middleware helpers
    get_default_persona_id,
    extract_persona,
    filter_tools_for_persona,
    filter_skills_for_persona,
    build_persona_prompt,
    # HITL middleware helpers
    build_hitl_request,
)
from cockpit_aap.meta import (
    MetaManifest,
    MetaArtifactEntry,
    MetaAgentEntry,
    DriftInfo,
    ConflictInfo,
    BootstrapMeta,
    checksum,
    read_meta_manifest,
    write_meta_manifest,
    build_manifest as build_meta_manifest,
    analyze_drift,
    resolve_upgrade_action,
)
from cockpit_aap.changelog import (
    ModuleChangelog,
    ChangelogEntry,
    ChangelogNote,
    ChangelogPreservedEntry,
    read_changelog,
    write_changelog,
    build_changelog_entry,
    merge_changelog,
)
from cockpit_aap.feedback import (
    ModuleFeedback,
    FeedbackItem,
    read_feedback,
    write_feedback,
    analyze_feedback_status,
)
from cockpit_aap.about import (
    AboutPayload,
    read_about,
    write_about,
)
from cockpit_aap.context import AAPContext, create_aap_context
from cockpit_aap.adapters.pg_pool import AsyncConnectionLike
from cockpit_aap.adapters.postgres_session import PostgresSessionStore, create_postgres_session
from cockpit_aap.adapters.postgres_manifest_store import PostgresManifestStore, create_postgres_manifest_store
from cockpit_aap.adapters.filesystem_manifest_source import FileSystemManifestSource, create_filesystem_manifest_source
from cockpit_aap.adapters.postgres_manifest_source import PostgresManifestSource, create_postgres_manifest_source
from cockpit_aap.manifest.kind_registry import (
    KindFieldSchema,
    KindRegistry,
    KindSchemaExport,
    ResolvedField,
    kind_registry,
    get_field_content_type,
    create_kind_registry,
    scan_kind_manifest,
)
from cockpit_aap.manifest.resolve_ref import is_file_ref, resolve_ref, resolve_json_ref
from cockpit_aap.manifest.merge import merge_manifests
from cockpit_aap.manifest.registry import (
    Registry,
    RegistryModule,
    scan_registry,
    parse_registry,
    resolve_module,
    filter_modules_by_category,
    filter_modules_by_tag,
    search_modules,
)
from cockpit_aap.manifest.project_scanner import (
    scan_project,
    is_project_dir,
    read_project_meta,
)
from cockpit_aap.errors import BootstrapError
from cockpit_aap.cache import BootstrapCache, global_cache
from cockpit_aap.enforcement import (
    GovernanceWarningLight,
    GovernanceEnforcementResult,
    validate_enforcement_mode,
)
from cockpit_aap.pull import (
    PullManifestResult,
    pull_manifest,
    scaffold_from_server,
    read_manifest_artifact,
)
from cockpit_aap.project_bootstrap import ProjectResult, bootstrap_project
from cockpit_aap.adapters.local_artifact_store import LocalArtifactStore, create_local_artifact_store
from cockpit_aap.adapters.local_fs_storage import LocalFSStorage, create_local_fs_storage
from cockpit_aap.adapters.sqlite_session import SQLiteSession, create_sqlite_session
from cockpit_aap.adapters.filesystem_session import FilesystemSession, create_filesystem_session
from cockpit_aap.adapters.cockpit_adapter import CockpitAdapter, create_cockpit_adapter
from cockpit_aap.adapters.sentence_transformer_embedding import (
    SentenceTransformerEmbeddingAdapter,
    create_sentence_transformer_embedding,
)
from cockpit_aap.adapters.noop_knowledge_adapter import NoopKnowledgeAdapter, create_noop_knowledge_adapter
from cockpit_aap.adapters.filesystem_knowledge_adapter import FileSystemKnowledgeAdapter, create_filesystem_knowledge_adapter
from cockpit_aap.adapters.yaml_to_rego import compile_to_rego
from cockpit_aap.manifest.front_matter import parse_front_matter
from cockpit_aap.runtime import (
    RuntimeContext,
    RuntimeResult,
    RuntimeDecision,
    ToolCallInfo,
    create_agent_runtime,
    RegexGuardrailAdapter,
    ConsoleTelemetryAdapter,
    InMemoryCostTracker,
)
from cockpit_aap.cost import CostPolicyReader, CostEmitter, CostEnforcer, EnforcementResult
from cockpit_aap.testing import create_test_runtime, assert_guardrail_blocks, assert_guardrail_passes, mock_manifest, BuiltInEval
from cockpit_aap.skill_adapter import create_manifest_skill_adapter
from cockpit_aap.local_sdk import LocalSdk, create_local_sdk
from cockpit_aap.artifact_bootstrapper import (
    ArtifactDefinition,
    ResolvedArtifact,
    UpgradeContext,
    bootstrap_artifact,
)
from cockpit_aap.agent_bootstrapper import (
    AgentDefinition,
    ResolvedAgentGranular,
    bootstrap_agent,
    reset_type_id_cache,
)
from cockpit_aap.ports import (
    ManifestStorePort,
    AuthPort,
    AuthUser,
    AuthSession,
    ObservabilityPort,
    Span,
    LLMPort,
    LLMMessage,
    LLMOptions,
    LLMResponse,
    LLMUsage,
    SessionStorePort,
    FileStoragePort,
    FileEntry,
    UploadOptions,
    EmbeddingPort,
    MigratableProtocol,
    ManifestSourceProtocol,
    ManifestEntry,
    KnowledgeDocument,
    KnowledgeResult,
    SearchOptions,
    KnowledgeProtocol,
)

__all__ = [
    # Client
    "AAPGatewayClient",
    "MultiAAPClient",
    "create_multi_aap_client",
    "Transport",
    "TransportContext",
    "RestTransport",
    "McpTransport",
    # MCP Types
    "AAPServerConfig",
    "MultiAAPClientConfig",
    "PromptArgument",
    "PromptMessage",
    "PromptResult",
    "PromptSchema",
    "ResourceContents",
    "ResourceSchema",
    "ResourceTemplate",
    "ToolResult",
    "ToolSchema",
    # Bootstrap
    "bootstrap_manifest",
    "bootstrap_kind",
    "BootstrapKindResult",
    "ManifestResult",
    "ResolvedAgent",
    # Manifest
    "Manifest",
    "ManifestAgent",
    "ManifestAgentExecution",
    "ManifestConnection",
    "ManifestProject",
    "ManifestProjectResolved",
    "ManifestResolvedModule",
    "scan_manifest",
    "parse_manifest",
    # Conformance & Governance
    "ConformanceViolation",
    "ConformanceResult",
    "ManifestPolicyViolation",
    "ManifestPolicyResult",
    "HealthCategory",
    "HealthResult",
    "evaluate_conformance",
    "evaluate_manifest_policy",
    "check_health",
    "eval_expression",
    "field_exists",
    "get_field_value",
    "grade_from_pct",
    "grade_to_number",
    # Writer
    "serialize_manifest",
    "write_manifest",
    "WriteManifestOptions",
    # Dependencies
    "find_package_root",
    "get_package_connections",
    "load_manifest_dependencies",
    # Project helpers
    "get_project_default_module",
    "get_project_enabled_modules",
    "get_project_module",
    "get_project_module_access",
    "get_project_module_connections",
    "get_project_module_i18n",
    "get_project_module_theme",
    # Persona middleware helpers
    "get_default_persona_id",
    "extract_persona",
    "filter_tools_for_persona",
    "filter_skills_for_persona",
    "build_persona_prompt",
    # HITL middleware helpers
    "build_hitl_request",
    # Meta
    "MetaManifest",
    "MetaArtifactEntry",
    "MetaAgentEntry",
    "DriftInfo",
    "ConflictInfo",
    "BootstrapMeta",
    "checksum",
    "read_meta_manifest",
    "write_meta_manifest",
    "build_meta_manifest",
    "analyze_drift",
    "resolve_upgrade_action",
    # Changelog
    "ModuleChangelog",
    "ChangelogEntry",
    "ChangelogNote",
    "ChangelogPreservedEntry",
    "read_changelog",
    "write_changelog",
    "build_changelog_entry",
    "merge_changelog",
    # Feedback
    "ModuleFeedback",
    "FeedbackItem",
    "read_feedback",
    "write_feedback",
    "analyze_feedback_status",
    # About
    "AboutPayload",
    "read_about",
    "write_about",
    # Context + Ports
    "AAPContext",
    "create_aap_context",
    "ManifestStorePort",
    "AuthPort",
    "AuthUser",
    "AuthSession",
    "ObservabilityPort",
    "Span",
    "LLMPort",
    "LLMMessage",
    "LLMOptions",
    "LLMResponse",
    "LLMUsage",
    "SessionStorePort",
    "FileStoragePort",
    "FileEntry",
    "UploadOptions",
    "EmbeddingPort",
    # KindRegistry
    "KindRegistry",
    "KindFieldSchema",
    "KindSchemaExport",
    "ResolvedField",
    "kind_registry",
    "get_field_content_type",
    "create_kind_registry",
    "scan_kind_manifest",
    # resolve_ref
    "is_file_ref",
    "resolve_ref",
    "resolve_json_ref",
    # Merge
    "merge_manifests",
    # Registry
    "Registry",
    "RegistryModule",
    "scan_registry",
    "parse_registry",
    "resolve_module",
    "filter_modules_by_category",
    "filter_modules_by_tag",
    "search_modules",
    # Project Scanner
    "scan_project",
    "is_project_dir",
    "read_project_meta",
    # Errors
    "BootstrapError",
    # Cache
    "BootstrapCache",
    "global_cache",
    # Enforcement
    "GovernanceWarningLight",
    "GovernanceEnforcementResult",
    "validate_enforcement_mode",
    # Pull / Scaffold
    "PullManifestResult",
    "pull_manifest",
    "scaffold_from_server",
    "read_manifest_artifact",
    # Project Bootstrap
    "ProjectResult",
    "bootstrap_project",
    # Local adapters
    "LocalArtifactStore",
    "create_local_artifact_store",
    "LocalFSStorage",
    "create_local_fs_storage",
    "SQLiteSession",
    "create_sqlite_session",
    "FilesystemSession",
    "create_filesystem_session",
    "CockpitAdapter",
    "create_cockpit_adapter",
    # Sentence Transformer (local embedding)
    "SentenceTransformerEmbeddingAdapter",
    "create_sentence_transformer_embedding",
    # Knowledge port + adapters
    "KnowledgeDocument",
    "KnowledgeResult",
    "SearchOptions",
    "KnowledgeProtocol",
    "NoopKnowledgeAdapter",
    "create_noop_knowledge_adapter",
    "FileSystemKnowledgeAdapter",
    "create_filesystem_knowledge_adapter",
    # Front matter parser
    "parse_front_matter",
    # YAML-to-Rego compiler
    "compile_to_rego",
    # Skill adapter
    "create_manifest_skill_adapter",
    # Testing helpers
    "create_test_runtime",
    "assert_guardrail_blocks",
    "assert_guardrail_passes",
    "mock_manifest",
    "BuiltInEval",
    # Runtime
    "RuntimeContext",
    "RuntimeResult",
    "RuntimeDecision",
    "ToolCallInfo",
    "create_agent_runtime",
    "RegexGuardrailAdapter",
    "ConsoleTelemetryAdapter",
    "InMemoryCostTracker",
    # Local SDK
    "LocalSdk",
    "create_local_sdk",
    # Granular bootstrappers
    "ArtifactDefinition",
    "ResolvedArtifact",
    "UpgradeContext",
    "bootstrap_artifact",
    "AgentDefinition",
    "ResolvedAgentGranular",
    "bootstrap_agent",
    "reset_type_id_cache",
    # ManifestSource adapters + ManifestSourceProtocol
    "ManifestSourceProtocol",
    "ManifestEntry",
    "FileSystemManifestSource",
    "create_filesystem_manifest_source",
    "PostgresManifestSource",
    "create_postgres_manifest_source",
    # Postgres session/store adapters + MigratableProtocol
    "MigratableProtocol",
    "AsyncConnectionLike",
    "PostgresSessionStore",
    "create_postgres_session",
    "PostgresManifestStore",
    "create_postgres_manifest_store",
    # Sub-packages (import via cockpit_aap.telemetry, .graph, .scribe)
    "telemetry",
    "graph",
    "scribe",
]

try:
    from cockpit_aap.mcp_server import create_manifest_mcp_server  # noqa: E402
    from cockpit_aap.kind_crud_server import (  # noqa: E402
        create_kind_crud_server,
        register_kind_health_checker,
    )
    from cockpit_aap.mcp_loader import (  # noqa: E402
        load_manifest_server,
        MCPServerManifest as MCPServerManifestType,
        MCPServerSpec as MCPServerSpecType,
    )

    __all__ = __all__ + [
        "create_manifest_mcp_server",
        "create_kind_crud_server",
        "register_kind_health_checker",
        "load_manifest_server",
    ]
except ImportError:  # pragma: no cover
    pass  # fastmcp not installed — cockpit_aap[mcp] extra not used

# Lazy sub-package access — importable as `from cockpit_aap import telemetry`
from cockpit_aap import telemetry as telemetry  # noqa: E402
from cockpit_aap import graph as graph  # noqa: E402
from cockpit_aap import scribe as scribe  # noqa: E402
