"""About — Python port of the TypeScript ``about.ts``.

Provides reading/writing module presentation (about) artifacts
to the artifact server.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

META_KEY_SUFFIX = "._meta.about"


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class AboutPayload:
    """Serialized form of the about artifact."""

    module: str
    version: str
    about: dict[str, Any]  # { title, summary, features?, audience?, category? }
    technical: dict[str, Any]  # { description, stack?, entryPoints? }
    artifact_count: int = 0
    agent_count: int = 0


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _escape_regex(s: str) -> str:
    return re.escape(s)


def _extract_value(content: Any) -> str | None:
    if not content or not isinstance(content, dict):
        return None

    artifacts = content.get("artifacts")
    if isinstance(artifacts, list) and len(artifacts) > 0:
        first = artifacts[0]
        if isinstance(first, dict) and isinstance(first.get("value"), str):
            return first["value"]

    if isinstance(content.get("value"), str):
        return content["value"]
    if isinstance(content.get("content"), str):
        return content["content"]
    return None


# ---------------------------------------------------------------------------
# Read / Write
# ---------------------------------------------------------------------------


async def read_about(
    sdk: Any,
    namespace: str,
    module: str,
) -> AboutPayload | None:
    """Read the about artifact from the server.

    Returns ``None`` if not found or on error.
    """
    try:
        key = f"{module}{META_KEY_SUFFIX}"
        result = await sdk[namespace].get_artifact(
            key_pattern=f"^{_escape_regex(key)}$"
        )

        content = result.content if hasattr(result, "content") else result
        value = _extract_value(content) if isinstance(content, dict) else None
        if not value:
            return None

        raw = json.loads(value)
        return AboutPayload(
            module=raw["module"],
            version=raw.get("version", "0.0.0"),
            about=raw.get("about", {}),
            technical=raw.get("technical", {"description": ""}),
            artifact_count=raw.get("artifactCount", 0),
            agent_count=raw.get("agentCount", 0),
        )
    except Exception:
        return None


async def write_about(
    sdk: Any,
    namespace: str,
    definition: Any,
) -> None:
    """Write the about artifact to the server.

    Serializes ``definition.about`` + ``definition.technical``
    into a single JSON artifact.
    """
    from .meta import _upsert_meta_artifact  # noqa: WPS433

    about = getattr(definition, "about", None)
    if not about:
        return

    module = (
        definition.module if hasattr(definition, "module") else definition["module"]
    )
    version = (
        getattr(definition, "version", None) or "0.0.0"
    )
    technical = getattr(definition, "technical", None) or {"description": ""}
    artifacts_list = getattr(definition, "artifacts", None) or []
    agents_list = getattr(definition, "agents", None) or []

    key = f"{module}{META_KEY_SUFFIX}"
    payload = {
        "module": module,
        "version": version,
        "about": about if isinstance(about, dict) else {"title": str(about)},
        "technical": technical if isinstance(technical, dict) else {"description": str(technical)},
        "artifactCount": len(artifacts_list),
        "agentCount": len(agents_list),
    }

    value = json.dumps(payload, indent=2)
    await _upsert_meta_artifact(
        sdk, namespace, key, value,
        f'Module presentation for "{module}"',
        module,
    )
