"""Conformance & ManifestPolicy evaluation engine — pure functions, no I/O.

Port of ``packages/mcp-server/src/tools/conformance-ops.ts`` and
``scripts/ci-governance-gate.ts`` evaluation logic.

Provides:
  * ``evaluate_conformance()`` — evaluates a ConformancePolicy against a manifest
  * ``evaluate_manifest_policy()`` — evaluates a ManifestPolicy against a manifest
  * ``check_health()`` — lightweight health scoring for Module-kind manifests
  * ``eval_expression()`` — sandboxed expression evaluator (simpleeval)
  * ``field_exists()`` — check presence of a dot-path field
  * ``get_field_value()`` — resolve a dot-path field value
  * ``grade_from_pct()`` / ``grade_to_number()`` — grading helpers
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Any


# ── Expression evaluator ──────────────────────────────────────────────────────


def eval_expression(expr: str, context: dict[str, Any]) -> bool:
    """Evaluate a JavaScript-like expression in a sandboxed context.

    Uses Python ``eval()`` with a restricted ``__builtins__`` namespace.
    Supports dot-path access on ``metadata`` and ``spec`` objects via
    the context dict.

    Parameters
    ----------
    expr:
        A boolean expression — e.g. ``metadata.group === 'demo'``
        or ``spec.agents && spec.agents.length > 0``.
    context:
        Dictionary with ``metadata`` and ``spec`` keys (plain dicts).

    Returns
    -------
    bool
        ``True`` if the expression evaluates truthy, ``False`` on any error.
    """
    try:
        # Convert JS-style operators to Python
        import re
        py_expr = expr
        py_expr = py_expr.replace("===", "==")
        py_expr = py_expr.replace("!==", "!=")
        py_expr = py_expr.replace("&&", " and ")
        py_expr = py_expr.replace("||", " or ")
        # Replace `!` (logical NOT) but NOT `!=` — use regex negative lookahead
        py_expr = re.sub(r"!(?!=)", " not ", py_expr)
        # Handle `.length` → `len()`
        py_expr = re.sub(r"(\w[\w.]*?)\.length", r"len(\1)", py_expr)

        # Build a flat namespace from the context for dot-path access
        namespace = _build_namespace(context)
        namespace["len"] = len
        namespace["True"] = True
        namespace["False"] = False
        namespace["None"] = None
        namespace["true"] = True
        namespace["false"] = False
        namespace["null"] = None

        result = eval(py_expr, {"__builtins__": {}}, namespace)  # noqa: S307
        return bool(result)
    except Exception:
        return False


def _build_namespace(context: dict[str, Any]) -> dict[str, Any]:
    """Flatten a context dict into a namespace for eval access.

    Given ``{"metadata": {"name": "foo", "group": "demo"}, "spec": {"agents": [...]}}``,
    produces ``{"metadata": <DotDict>, "spec": <DotDict>}`` where DotDict supports
    attribute access for dot-path expressions.
    """
    ns: dict[str, Any] = {}
    for key, value in context.items():
        ns[key] = _DotDict(value) if isinstance(value, dict) else value
    return ns


class _DotDict:
    """Dict wrapper that allows attribute-style access for eval expressions."""

    def __init__(self, data: dict[str, Any] | Any) -> None:
        self._data = data if isinstance(data, dict) else {}

    def __getattr__(self, name: str) -> Any:
        value = self._data.get(name)
        if isinstance(value, dict):
            return _DotDict(value)
        if value is None:
            return _DotDict({})
        return value

    def __bool__(self) -> bool:
        return bool(self._data)

    def __len__(self) -> int:
        return len(self._data)

    def __repr__(self) -> str:
        return repr(self._data)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, _DotDict):
            return self._data == other._data
        if isinstance(other, dict):
            return self._data == other
        if isinstance(other, str):
            return str(self._data) == other
        return NotImplemented

    def __iter__(self):
        return iter(self._data)


# ── Field path resolver ──────────────────────────────────────────────────────


def get_field_value(obj: dict[str, Any], path: str) -> Any:
    """Resolve a dot-notation path in a nested dict.

    Strips ``[]`` suffixes (array markers) and traverses nested dicts.

    Parameters
    ----------
    obj:
        Root dict (typically a manifest).
    path:
        Dot-notation path, e.g. ``spec.agents`` or ``metadata.annotations.tier``.

    Returns
    -------
    Any
        The resolved value, or ``None`` if not found.
    """
    clean = path.replace("[]", "")
    parts = clean.split(".")
    current: Any = obj
    for part in parts:
        if current is None:
            return None
        if isinstance(current, dict):
            current = current.get(part)
        elif hasattr(current, part):
            current = getattr(current, part)
        else:
            return None
    return current


def field_exists(manifest: dict[str, Any], field: str) -> bool:
    """Check if a field path exists and has a meaningful value.

    Parameters
    ----------
    manifest:
        The manifest dict.
    field:
        Dot-notation field path.

    Returns
    -------
    bool
        ``True`` if the field is present and non-empty.
    """
    value = get_field_value(manifest, field)
    if value is None:
        return False
    if isinstance(value, list):
        return len(value) > 0
    if isinstance(value, str):
        return len(value.strip()) > 0
    if isinstance(value, dict):
        return len(value) > 0
    return True


# ── Grade helpers ─────────────────────────────────────────────────────────────


def grade_from_pct(pct: float) -> str:
    """Convert a percentage score to a letter grade."""
    if pct >= 90:
        return "A"
    if pct >= 75:
        return "B"
    if pct >= 60:
        return "C"
    if pct >= 40:
        return "D"
    return "F"


def grade_to_number(grade: str) -> int:
    """Convert a letter grade to a numeric value for comparison."""
    return {"A": 5, "B": 4, "C": 3, "D": 2, "F": 1}.get(grade, 0)


# ── ConformancePolicy evaluation ─────────────────────────────────────────────


@dataclass
class ConformanceViolation:
    """A single conformance requirement violation."""

    requirement_id: str
    field: str
    severity: str
    weight: float
    message: str


@dataclass
class ConformanceResult:
    """Result of evaluating a ConformancePolicy against a manifest."""

    policy_name: str
    score: float
    max_score: float
    percentage: float
    grade: str
    violations: list[ConformanceViolation] = field(default_factory=list)
    exempted_count: int = 0


def evaluate_conformance(
    policy: dict[str, Any],
    manifest: dict[str, Any],
) -> ConformanceResult:
    """Evaluate a ConformancePolicy against a manifest.

    Parameters
    ----------
    policy:
        A ConformancePolicy manifest (dict or dataclass-like with .metadata, .spec).
    manifest:
        The manifest to evaluate (dict with metadata, spec, kind keys).

    Returns
    -------
    ConformanceResult
        Score, grade, violations, and exemption count.
    """
    meta = _get_dict(manifest, "metadata")
    spec = _get_dict(manifest, "spec")
    ctx = {"metadata": meta, "spec": spec}

    policy_meta = _get_dict(policy, "metadata")
    policy_spec = _get_dict(policy, "spec")
    requirements = _get_list(policy_spec, "requirements")

    score = 0.0
    max_score = 0.0
    violations: list[ConformanceViolation] = []
    exempted_count = 0

    for req in requirements:
        if not isinstance(req, dict):
            continue

        severity = req.get("severity", "recommended")
        weight = req.get("weight")
        if weight is None:
            weight = 4.0 if severity == "required" else (2.0 if severity == "recommended" else 0.0)
        weight = float(weight)

        # Check exemptions
        exempt_when = req.get("exempt_when") or req.get("exemptWhen") or []
        if isinstance(exempt_when, str):
            exempt_when = [exempt_when]
        if any(eval_expression(expr, ctx) for expr in exempt_when):
            exempted_count += 1
            continue

        req_field = req.get("field", "")
        req_id = req.get("id", req_field)
        req_message = req.get("message", f"Missing: {req_field}")

        # Forbidden
        if severity == "forbidden":
            if field_exists(manifest, req_field):
                violations.append(ConformanceViolation(
                    requirement_id=req_id, field=req_field,
                    severity="forbidden", weight=0.0,
                    message=req_message,
                ))
            continue

        # Info
        if severity == "info":
            if not field_exists(manifest, req_field):
                violations.append(ConformanceViolation(
                    requirement_id=req_id, field=req_field,
                    severity="info", weight=0.0,
                    message=req_message,
                ))
            continue

        # Required / Recommended — scored
        max_score += weight
        if field_exists(manifest, req_field):
            score += weight
        else:
            violations.append(ConformanceViolation(
                requirement_id=req_id, field=req_field,
                severity=severity, weight=weight,
                message=req_message,
            ))

    percentage = round((score / max_score) * 100) if max_score > 0 else 100
    return ConformanceResult(
        policy_name=policy_meta.get("name", "unknown"),
        score=score,
        max_score=max_score,
        percentage=percentage,
        grade=grade_from_pct(percentage),
        violations=violations,
        exempted_count=exempted_count,
    )


# ── ManifestPolicy evaluation ────────────────────────────────────────────────


@dataclass
class ManifestPolicyViolation:
    """A single manifest policy requirement violation."""

    requirement_id: str
    type: str
    severity: str
    message: str


@dataclass
class ManifestPolicyResult:
    """Result of evaluating a ManifestPolicy against a manifest."""

    policy_name: str
    matched: bool
    violations: list[ManifestPolicyViolation] = field(default_factory=list)
    exempted_count: int = 0


def _evaluate_manifest_policy_req(req: dict[str, Any], manifest: dict[str, Any]) -> bool:
    """Evaluate a single ManifestPolicy requirement. Returns True if satisfied."""
    spec = _get_dict(manifest, "spec")
    meta = _get_dict(manifest, "metadata")

    req_type = req.get("type", "")

    if req_type == "mustHaveRef":
        refs = spec.get("refs") or []
        if not isinstance(refs, list):
            refs = []
        target_kind = req.get("target_kind") or req.get("targetKind")
        target_relation = req.get("target_relation") or req.get("targetRelation")
        min_count = int(req.get("min_ref_count") or req.get("minRefCount") or 1)
        matches = [
            r for r in refs
            if (not target_kind or r.get("kind") == target_kind)
            and (not target_relation or r.get("relation") == target_relation)
        ]
        return len(matches) >= min_count

    if req_type == "forbidRef":
        refs = spec.get("refs") or []
        if not isinstance(refs, list):
            refs = []
        target_kind = req.get("target_kind") or req.get("targetKind")
        return len([r for r in refs if not target_kind or r.get("kind") == target_kind]) == 0

    if req_type == "mustHaveAnnotation":
        annotations = meta.get("annotations") or {}
        ann_key = req.get("annotation_key") or req.get("annotationKey") or ""
        value = annotations.get(ann_key)
        if value is None:
            return False
        allowed = req.get("allowed_annotation_values") or req.get("allowedAnnotationValues")
        if allowed and str(value) not in allowed:
            return False
        return True

    if req_type == "forbidAnnotation":
        annotations = meta.get("annotations") or {}
        ann_key = req.get("annotation_key") or req.get("annotationKey") or ""
        return annotations.get(ann_key) is None

    if req_type == "mustHaveArtifact":
        artifacts = spec.get("artifacts") or []
        if not isinstance(artifacts, list):
            return False
        pattern = req.get("artifact_pattern") or req.get("artifactPattern") or ""
        category = req.get("artifact_category") or req.get("artifactCategory") or ""
        clean_pattern = pattern.replace("*", "")
        return any(
            (not clean_pattern or clean_pattern in (a.get("key") or ""))
            and (not category or a.get("category") == category)
            for a in artifacts
        )

    if req_type == "mustHaveAgent":
        agents = spec.get("agents") or []
        min_count = int(req.get("min_agent_count") or req.get("minAgentCount") or 1)
        return len(agents) >= min_count

    if req_type == "agentHasTool":
        agents = spec.get("agents") or []
        if not isinstance(agents, list):
            return False
        agent_id = req.get("agent_id") or req.get("agentId")
        tool_id = req.get("tool_id") or req.get("toolId") or ""
        to_check = [a for a in agents if a.get("id") == agent_id] if agent_id else agents
        return any(tool_id in (a.get("tools") or []) for a in to_check)

    if req_type == "fieldExpression":
        expression = req.get("expression") or ""
        if not expression:
            return True
        return eval_expression(expression, {"metadata": meta, "spec": spec})

    return True


def evaluate_manifest_policy(
    policy: dict[str, Any],
    manifest: dict[str, Any],
) -> ManifestPolicyResult:
    """Evaluate a ManifestPolicy against a manifest.

    Parameters
    ----------
    policy:
        A ManifestPolicy manifest (dict with metadata, spec).
    manifest:
        The manifest to evaluate.

    Returns
    -------
    ManifestPolicyResult
        Whether the policy matched, violations, and exemption count.
    """
    meta = _get_dict(manifest, "metadata")
    spec = _get_dict(manifest, "spec")
    ctx = {"metadata": meta, "spec": spec}

    policy_meta = _get_dict(policy, "metadata")
    policy_spec = _get_dict(policy, "spec")
    applies_to = _get_dict(policy_spec, "applies_to") or _get_dict(policy_spec, "appliesTo")

    manifest_kind = manifest.get("kind", "Module")
    target_kind = applies_to.get("kind", "*")
    kind_match = target_kind == "*" or target_kind == manifest_kind
    when_expr = applies_to.get("when")
    when_match = not when_expr or eval_expression(when_expr, ctx)
    matched = kind_match and when_match

    if not matched:
        return ManifestPolicyResult(
            policy_name=policy_meta.get("name", "unknown"),
            matched=False,
        )

    requirements = _get_list(policy_spec, "requirements")
    violations: list[ManifestPolicyViolation] = []
    exempted_count = 0

    for req in requirements:
        if not isinstance(req, dict):
            continue

        exempt_when = req.get("exempt_when") or req.get("exemptWhen")
        if exempt_when and eval_expression(str(exempt_when), ctx):
            exempted_count += 1
            continue

        if not _evaluate_manifest_policy_req(req, manifest):
            violations.append(ManifestPolicyViolation(
                requirement_id=req.get("id", ""),
                type=req.get("type", ""),
                severity=req.get("severity", "required"),
                message=req.get("message", ""),
            ))

    return ManifestPolicyResult(
        policy_name=policy_meta.get("name", "unknown"),
        matched=matched,
        violations=violations,
        exempted_count=exempted_count,
    )


# ── Health scoring ────────────────────────────────────────────────────────────


@dataclass
class HealthCategory:
    """A single health scoring category."""

    name: str
    score: float
    max_score: float


@dataclass
class HealthResult:
    """Health scoring result for a Module manifest."""

    score: float
    max_score: float
    percentage: float
    grade: str
    categories: list[HealthCategory] = field(default_factory=list)


_HEALTH_CHECKS = [
    ("Identity", [
        ("metadata.name", 1), ("metadata.displayName", 1),
        ("metadata.version", 1), ("metadata.description", 1),
    ]),
    ("Agents", [("spec.agents", 4)]),
    ("Artifacts", [("spec.artifacts", 2)]),
    ("i18n", [("spec.i18n", 4)]),
    ("Theme", [("spec.theme", 2)]),
    ("Lifecycle", [("spec.lifecycle", 4)]),
    ("Governance", [("spec.rules", 2), ("spec.guardrails", 2)]),
]


def check_health(manifest: dict[str, Any]) -> HealthResult:
    """Lightweight health scoring for Module-kind manifests.

    Parameters
    ----------
    manifest:
        A Module manifest (dict with metadata, spec).

    Returns
    -------
    HealthResult
        Score, grade, and per-category breakdown.
    """
    categories: list[HealthCategory] = []

    for cat_name, fields in _HEALTH_CHECKS:
        cat_score = 0.0
        cat_max = 0.0
        for path, weight in fields:
            cat_max += weight
            if field_exists(manifest, path):
                cat_score += weight
        categories.append(HealthCategory(name=cat_name, score=cat_score, max_score=cat_max))

    total_score = sum(c.score for c in categories)
    total_max = sum(c.max_score for c in categories)
    percentage = round((total_score / total_max) * 100) if total_max > 0 else 100

    return HealthResult(
        score=total_score,
        max_score=total_max,
        percentage=percentage,
        grade=grade_from_pct(percentage),
        categories=categories,
    )


# ── Internal helpers ──────────────────────────────────────────────────────────


def _get_dict(obj: Any, key: str) -> dict[str, Any]:
    """Safely get a dict from an object (supports dict access and attribute access)."""
    if isinstance(obj, dict):
        val = obj.get(key)
    elif hasattr(obj, key):
        val = getattr(obj, key)
    else:
        return {}
    return val if isinstance(val, dict) else {}


def _get_list(obj: Any, key: str) -> list[Any]:
    """Safely get a list from an object."""
    if isinstance(obj, dict):
        val = obj.get(key)
    elif hasattr(obj, key):
        val = getattr(obj, key)
    else:
        return []
    return val if isinstance(val, list) else []
