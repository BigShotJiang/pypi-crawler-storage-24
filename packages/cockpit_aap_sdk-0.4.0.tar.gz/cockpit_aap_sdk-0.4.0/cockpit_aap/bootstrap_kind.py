"""Generic bootstrap for any registered kind.

Port of TypeScript bootstrapKind() from @ruinosus/aap-bootstrap.
Uses ManifestSourceProtocol + KindRegistry for kind-agnostic sync.
"""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any

from cockpit_aap.manifest.kind_registry import kind_registry


@dataclass
class BootstrapKindResult:
    """Result of a bootstrapKind() operation."""
    kind: str
    id: str
    manifest: Any
    action: str  # "created" | "updated" | "preserved" | "validated-only"
    source: str  # "local" | "remote"
    duration_ms: float = 0
    policy_decision: dict | None = None


async def bootstrap_kind(
    *,
    source: Any,
    kind: str,
    id: str,
    manifest_dir: str | None = None,
    policy_engine: Any | None = None,
    strategy: str = "local-wins",
    dry_run: bool = False,
    verbose: bool = False,
) -> BootstrapKindResult:
    """Generic bootstrap for any registered kind.

    Unlike bootstrap_manifest() which is hardcoded for kind: Module,
    bootstrap_kind() works for ANY registered kind using ManifestSourceProtocol.

    Args:
        source: ManifestSourceProtocol adapter (filesystem, postgres, in-memory)
        kind: Kind to bootstrap (e.g., "Agent", "Guardrail", "Pipeline")
        id: Manifest ID (metadata.name)
        manifest_dir: Optional directory to scan from (for filesystem source with KindRegistry.scan)
        policy_engine: Optional PolicyEnginePort for validation
        strategy: Sync strategy — "local-wins", "remote-wins", or "error"
        dry_run: If True, validate only — don't save
        verbose: If True, log progress

    Returns:
        BootstrapKindResult with manifest, action taken, and optional policy decision

    Raises:
        ValueError: If kind is not registered
        RuntimeError: If no manifest found, or strategy is "error" and both exist
    """
    start = time.monotonic()

    def log(msg: str) -> None:
        if verbose:
            print(f"[bootstrapKind:{kind}] {msg}")

    # 1. Verify kind is registered
    if not kind_registry.is_registered(kind):
        registered = ", ".join(kind_registry.registered_kinds())
        raise ValueError(
            f'Kind "{kind}" is not registered in KindRegistry. '
            f"Registered kinds: [{registered}]. "
            f"Register it first with kind_registry.register()."
        )

    # 2. Load local manifest (from directory scan via KindRegistry)
    local_manifest = None
    if manifest_dir:
        try:
            local_manifest = kind_registry.scan(manifest_dir)
            log(f"Scanned local manifest from {manifest_dir}")
        except Exception as e:
            log(f"No local manifest found: {e}")

    # 3. Load remote manifest (from source)
    remote_manifest = None
    try:
        remote_manifest = await source.load(id, kind)
        log(f'Loaded remote manifest "{id}" (kind: {kind})')
    except Exception:
        log(f'No remote manifest found for "{id}"')

    # 4. Determine which manifest to use and what action to take
    if dry_run:
        manifest = local_manifest or remote_manifest
        if manifest is None:
            raise RuntimeError(f'No manifest found for "{id}" (kind: {kind}) — neither local nor remote.')
        action = "validated-only"
        manifest_source = "local" if local_manifest else "remote"

    elif local_manifest and remote_manifest:
        if strategy == "local-wins":
            manifest = local_manifest
            manifest_source = "local"
            action = "updated"
        elif strategy == "remote-wins":
            manifest = remote_manifest
            manifest_source = "remote"
            action = "preserved"
        else:
            raise RuntimeError(
                f'Both local and remote manifests exist for "{id}" (kind: {kind}). '
                f'Use strategy "local-wins" or "remote-wins".'
            )

    elif local_manifest:
        manifest = local_manifest
        manifest_source = "local"
        action = "created"

    elif remote_manifest:
        manifest = remote_manifest
        manifest_source = "remote"
        action = "preserved"

    else:
        raise RuntimeError(f'No manifest found for "{id}" (kind: {kind}) — neither local nor remote.')

    # 5. Evaluate policies (if engine provided)
    policy_decision = None
    if policy_engine is not None and hasattr(policy_engine, "evaluate"):
        try:
            from cockpit_aap.ports.policy_engine import PolicyInput

            decision = await policy_engine.evaluate(PolicyInput(
                manifest=manifest if isinstance(manifest, dict) else {},
            ))
            policy_decision = {
                "passed": decision.passed,
                "grade": decision.grade,
                "violations": [
                    {"rule": v.rule, "severity": v.severity, "message": v.message}
                    for v in decision.violations
                ],
            }
            log(f"Policy evaluation: grade {decision.grade}, {len(decision.violations)} violations")

            # Block if critical violations and not dry-run
            if not decision.passed and not dry_run:
                critical = [v for v in decision.violations if v.severity == "error"]
                if critical:
                    msgs = "\n".join(f"  - [{v.severity}] {v.rule}: {v.message}" for v in critical)
                    raise RuntimeError(
                        f'Policy evaluation failed for "{id}" (kind: {kind}): '
                        f"{len(critical)} critical violation(s):\n{msgs}"
                    )
        except ImportError:
            log("PolicyEnginePort not available — skipping policy evaluation")

    # 6. Save to source (if local-wins and not dry-run)
    if not dry_run and manifest_source == "local" and action in ("created", "updated"):
        if hasattr(source, "save"):
            await source.save(id, kind, manifest)
            log(f'Saved manifest "{id}" to source')

    elapsed = (time.monotonic() - start) * 1000
    return BootstrapKindResult(
        kind=kind,
        id=id,
        manifest=manifest,
        action=action,
        source=manifest_source,
        policy_decision=policy_decision,
        duration_ms=round(elapsed, 1),
    )
