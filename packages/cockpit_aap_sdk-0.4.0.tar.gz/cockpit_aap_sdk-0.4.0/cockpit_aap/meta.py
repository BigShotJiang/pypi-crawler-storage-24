"""Meta manifest — Python port of the TypeScript ``meta.ts``.

Provides checksum computation, MetaManifest reading/writing to artifact
server, drift analysis, and upgrade conflict resolution.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Literal


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

META_KEY_SUFFIX = "._meta.config"


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class MetaArtifactEntry:
    """Tracks one artifact's checksums and drift state."""

    id: str
    source: str  # "created" | "found" | "updated"
    default_checksum: str
    server_checksum: str
    drifted: bool
    drifted_at: str | None = None
    artifact_category: str | None = None  # "state" | "configuration" | "content"


@dataclass
class MetaAgentEntry:
    """Tracks one agent's checksums and drift state."""

    id: str
    source: str
    default_checksum: str
    server_checksum: str
    drifted: bool
    drifted_at: str | None = None


@dataclass
class MetaManifest:
    """Persisted bootstrap metadata — stored as a ``_meta.config`` artifact."""

    module: str
    code_version: str
    bootstrapped_at: str
    artifacts: dict[str, MetaArtifactEntry] = field(default_factory=dict)
    agents: dict[str, MetaAgentEntry] = field(default_factory=dict)


@dataclass
class DriftInfo:
    """Information about a single drifted artifact or agent."""

    key: str
    default_checksum: str
    server_checksum: str
    drifted_at: str


@dataclass
class ConflictInfo:
    """Information about a version-upgrade conflict."""

    key: str
    old_default_checksum: str
    new_default_checksum: str
    server_checksum: str
    resolution: str  # UpgradeStrategy


@dataclass
class BootstrapMeta:
    """Result of drift analysis comparing new vs old manifest."""

    manifest: MetaManifest
    drifted_artifacts: dict[str, DriftInfo] = field(default_factory=dict)
    conflicts: dict[str, ConflictInfo] = field(default_factory=dict)
    upgraded: list[str] = field(default_factory=list)


# Upgrade strategy type alias
UpgradeStrategy = Literal["server-wins", "code-wins", "log-warning"]


# ---------------------------------------------------------------------------
# Checksum
# ---------------------------------------------------------------------------


def checksum(value: str) -> str:
    """Compute SHA-256 checksum of a string value.

    Returns ``"sha256:<hex>"`` format.
    """
    digest = hashlib.sha256(value.encode("utf-8")).hexdigest()
    return f"sha256:{digest}"


# ---------------------------------------------------------------------------
# Read / Write
# ---------------------------------------------------------------------------


def _escape_regex(s: str) -> str:
    return re.escape(s)


def _extract_manifest_value(content: Any) -> str | None:
    if not content or not isinstance(content, dict):
        return None

    # Handle { artifacts: [{ value: "..." }] } wrapper
    artifacts = content.get("artifacts")
    if isinstance(artifacts, list) and len(artifacts) > 0:
        first = artifacts[0]
        if isinstance(first, dict) and isinstance(first.get("value"), str):
            return first["value"]

    # Direct { value: "..." }
    if isinstance(content.get("value"), str):
        return content["value"]

    # { content: "..." }
    if isinstance(content.get("content"), str):
        return content["content"]

    return None


async def read_meta_manifest(
    sdk: Any,
    namespace: str,
    module: str,
) -> MetaManifest | None:
    """Read the meta manifest from the artifact server.

    Returns ``None`` if not found or on error.
    """
    try:
        key = f"{module}{META_KEY_SUFFIX}"
        result = await sdk[namespace].get_artifact(
            key_pattern=f"^{_escape_regex(key)}$"
        )

        content = result.content if hasattr(result, "content") else result
        if isinstance(content, dict):
            value = _extract_manifest_value(content)
        else:
            value = None
        if not value:
            return None

        raw = json.loads(value)
        return _parse_meta_manifest(raw)
    except Exception:
        return None


async def write_meta_manifest(
    sdk: Any,
    namespace: str,
    module: str,
    manifest: MetaManifest,
) -> None:
    """Write the meta manifest to the artifact server."""
    key = f"{module}{META_KEY_SUFFIX}"
    value = json.dumps(_meta_manifest_to_dict(manifest), indent=2)
    await _upsert_meta_artifact(
        sdk, namespace, key, value,
        f'Bootstrap meta manifest for module "{module}"',
        module,
    )


# ---------------------------------------------------------------------------
# Upsert logic
# ---------------------------------------------------------------------------


async def _find_artifact_id(sdk: Any, namespace: str, key: str) -> str | None:
    """Find the artifact UUID by key. Returns ``None`` if not found."""
    try:
        result = await sdk[namespace].get_artifact(
            key_pattern=f"^{_escape_regex(key)}$"
        )
        content = result.content if hasattr(result, "content") else result
        if not content or not isinstance(content, dict):
            return None

        # Extract from { artifacts: [{ id: "..." }] }
        artifacts = content.get("artifacts")
        if isinstance(artifacts, list) and len(artifacts) > 0:
            first = artifacts[0]
            if isinstance(first, dict):
                raw_id = first.get("id") or first.get("artifact_id")
                if raw_id:
                    return str(raw_id)

        if content.get("id"):
            return str(content["id"])

        return None
    except Exception:
        return None


async def _create_meta_artifact(
    sdk: Any,
    namespace: str,
    key: str,
    value: str,
    description: str,
    module: str,
) -> None:
    """Create a meta artifact (best-effort)."""
    try:
        await sdk[namespace].create_artifact(
            key=key,
            value=value,
            description=description,
            tags=f"bootstrap,meta,{module}",
            artifact_type="JSON",
            accessibility="Namespace",
            conflict_strategy="OVERWRITE",
        )
    except Exception:
        pass  # Best-effort


async def _upsert_meta_artifact(
    sdk: Any,
    namespace: str,
    key: str,
    value: str,
    description: str,
    module: str,
) -> None:
    """Upsert a meta artifact: find by key → update by UUID or create."""
    existing_id = await _find_artifact_id(sdk, namespace, key)

    if existing_id:
        try:
            update_result = await sdk[namespace].update_artifact(
                id=existing_id,
                value=value,
                promote_to_production=True,
            )
            content = (
                update_result.content
                if hasattr(update_result, "content")
                else update_result
            )
            if isinstance(content, dict) and content.get("success") is False:
                await _create_meta_artifact(sdk, namespace, key, value, description, module)
        except Exception:
            await _create_meta_artifact(sdk, namespace, key, value, description, module)
    else:
        await _create_meta_artifact(sdk, namespace, key, value, description, module)


# ---------------------------------------------------------------------------
# Build manifest
# ---------------------------------------------------------------------------


def build_manifest(
    definition: Any,
    resolved_artifacts: dict[str, Any],
    resolved_agents: dict[str, Any],
) -> MetaManifest:
    """Build a meta manifest from bootstrap results.

    ``definition`` should have ``.module``, ``.version``, ``.artifacts``,
    ``.agents`` attributes.  ``resolved_artifacts`` and ``resolved_agents``
    are dicts mapping key/name → resolved object with ``id``, ``source``,
    ``value``/``instruction`` attributes.
    """
    artifact_entries: dict[str, MetaArtifactEntry] = {}
    agent_entries: dict[str, MetaAgentEntry] = {}

    for art_def in getattr(definition, "artifacts", None) or []:
        key = art_def.key if hasattr(art_def, "key") else art_def["key"]
        resolved = resolved_artifacts.get(key)
        if not resolved:
            continue

        default_value = (
            art_def.default_value
            if hasattr(art_def, "default_value")
            else art_def.get("defaultValue", "")
        )
        resolved_value = (
            resolved.value if hasattr(resolved, "value") else resolved.get("value", "")
        )
        resolved_id = (
            resolved.id if hasattr(resolved, "id") else resolved.get("id", "")
        )
        resolved_source = (
            resolved.source if hasattr(resolved, "source") else resolved.get("source", "")
        )

        def_checksum = checksum(str(default_value))
        server_checksum_val = checksum(str(resolved_value))

        art_category = (
            art_def.artifact_category
            if hasattr(art_def, "artifact_category")
            else art_def.get("artifactCategory")
        )
        is_state = art_category == "state"
        drifted = False if is_state else def_checksum != server_checksum_val

        entry = MetaArtifactEntry(
            id=str(resolved_id),
            source=str(resolved_source),
            default_checksum=def_checksum,
            server_checksum=server_checksum_val,
            drifted=drifted,
            drifted_at=datetime.now(timezone.utc).isoformat() if drifted else None,
            artifact_category="state" if is_state else None,
        )
        artifact_entries[key] = entry

    for agent_def in getattr(definition, "agents", None) or []:
        name = (
            agent_def.name if hasattr(agent_def, "name") else agent_def["name"]
        )
        resolved = resolved_agents.get(name)
        if not resolved:
            continue

        default_instruction = (
            agent_def.default_instruction
            if hasattr(agent_def, "default_instruction")
            else agent_def.get("defaultInstruction", "")
        )
        resolved_instruction = (
            resolved.instruction
            if hasattr(resolved, "instruction")
            else resolved.get("instruction", "")
        )
        resolved_id = (
            resolved.id if hasattr(resolved, "id") else resolved.get("id", "")
        )
        resolved_source = (
            resolved.source if hasattr(resolved, "source") else resolved.get("source", "")
        )

        def_checksum = checksum(str(default_instruction))
        server_checksum_val = checksum(str(resolved_instruction))
        drifted = def_checksum != server_checksum_val

        entry = MetaAgentEntry(
            id=str(resolved_id),
            source=str(resolved_source),
            default_checksum=def_checksum,
            server_checksum=server_checksum_val,
            drifted=drifted,
            drifted_at=datetime.now(timezone.utc).isoformat() if drifted else None,
        )
        agent_entries[name] = entry

    module_name = (
        definition.module if hasattr(definition, "module") else definition["module"]
    )
    version = (
        definition.version if hasattr(definition, "version") else definition.get("version", "0.0.0")
    )

    return MetaManifest(
        module=module_name,
        code_version=version or "0.0.0",
        bootstrapped_at=datetime.now(timezone.utc).isoformat(),
        artifacts=artifact_entries,
        agents=agent_entries,
    )


# ---------------------------------------------------------------------------
# Drift analysis
# ---------------------------------------------------------------------------


def analyze_drift(
    new_manifest: MetaManifest,
    old_manifest: MetaManifest | None,
    strategy: UpgradeStrategy,
) -> BootstrapMeta:
    """Compute drift and conflict info comparing new vs old manifest."""
    drifted_artifacts: dict[str, DriftInfo] = {}
    conflicts: dict[str, ConflictInfo] = {}
    upgraded: list[str] = []

    _detect_artifact_drift(
        new_manifest, old_manifest, strategy,
        drifted_artifacts, conflicts, upgraded,
    )
    _detect_agent_drift(new_manifest, drifted_artifacts)

    if old_manifest:
        _preserve_drift_timestamps(new_manifest, old_manifest, drifted_artifacts)

    return BootstrapMeta(
        manifest=new_manifest,
        drifted_artifacts=drifted_artifacts,
        conflicts=conflicts,
        upgraded=upgraded,
    )


def resolve_upgrade_action(
    key: str,
    new_default_checksum: str,
    current_server_checksum: str,
    old_manifest: MetaManifest | None,
    strategy: UpgradeStrategy,
) -> str | None:
    """Determine what action to take for an artifact during upgrade.

    Returns:
    - ``"skip"``: Artifact unchanged
    - ``"update"``: Code changed, no drift → update server
    - Strategy string: Conflict resolution
    - ``None``: No old manifest (first bootstrap)
    """
    if not old_manifest:
        return None

    old_entry = old_manifest.artifacts.get(key)
    if not old_entry:
        return None  # New artifact

    code_changed = new_default_checksum != old_entry.default_checksum
    if not code_changed:
        return "skip"

    server_drifted = (
        old_entry.drifted
        or current_server_checksum != old_entry.default_checksum
    )
    if server_drifted:
        return strategy

    return "update"


# ---------------------------------------------------------------------------
# Internal drift helpers
# ---------------------------------------------------------------------------


def _detect_artifact_drift(
    new_manifest: MetaManifest,
    old_manifest: MetaManifest | None,
    strategy: UpgradeStrategy,
    drifted_artifacts: dict[str, DriftInfo],
    conflicts: dict[str, ConflictInfo],
    upgraded: list[str],
) -> None:
    for key, entry in new_manifest.artifacts.items():
        if entry.artifact_category == "state":
            continue

        if entry.drifted:
            drifted_artifacts[key] = DriftInfo(
                key=key,
                default_checksum=entry.default_checksum,
                server_checksum=entry.server_checksum,
                drifted_at=entry.drifted_at or datetime.now(timezone.utc).isoformat(),
            )

        _classify_artifact_upgrade(
            key, entry, old_manifest, strategy, conflicts, upgraded,
        )


def _classify_artifact_upgrade(
    key: str,
    entry: MetaArtifactEntry,
    old_manifest: MetaManifest | None,
    strategy: UpgradeStrategy,
    conflicts: dict[str, ConflictInfo],
    upgraded: list[str],
) -> None:
    if not old_manifest or key not in old_manifest.artifacts:
        return

    old_entry = old_manifest.artifacts[key]
    code_changed = entry.default_checksum != old_entry.default_checksum
    server_drifted = old_entry.drifted or entry.drifted

    if code_changed and server_drifted:
        conflicts[key] = ConflictInfo(
            key=key,
            old_default_checksum=old_entry.default_checksum,
            new_default_checksum=entry.default_checksum,
            server_checksum=entry.server_checksum,
            resolution=strategy,
        )
    elif code_changed and not server_drifted:
        upgraded.append(key)


def _detect_agent_drift(
    new_manifest: MetaManifest,
    drifted_artifacts: dict[str, DriftInfo],
) -> None:
    for name, entry in new_manifest.agents.items():
        if entry.drifted:
            drifted_artifacts[f"agent:{name}"] = DriftInfo(
                key=name,
                default_checksum=entry.default_checksum,
                server_checksum=entry.server_checksum,
                drifted_at=entry.drifted_at or datetime.now(timezone.utc).isoformat(),
            )


def _preserve_drift_timestamps(
    new_manifest: MetaManifest,
    old_manifest: MetaManifest,
    drifted_artifacts: dict[str, DriftInfo],
) -> None:
    for key, old_entry in old_manifest.artifacts.items():
        if old_entry.drifted_at and key in new_manifest.artifacts and new_manifest.artifacts[key].drifted:
            new_manifest.artifacts[key].drifted_at = old_entry.drifted_at
            if key in drifted_artifacts:
                drifted_artifacts[key].drifted_at = old_entry.drifted_at

    for name, old_entry in old_manifest.agents.items():
        if old_entry.drifted_at and name in new_manifest.agents and new_manifest.agents[name].drifted:
            new_manifest.agents[name].drifted_at = old_entry.drifted_at


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------


def _meta_manifest_to_dict(manifest: MetaManifest) -> dict[str, Any]:
    """Convert a MetaManifest to a JSON-friendly dict with camelCase keys."""
    return {
        "module": manifest.module,
        "codeVersion": manifest.code_version,
        "bootstrappedAt": manifest.bootstrapped_at,
        "artifacts": {
            k: _meta_artifact_entry_to_dict(v)
            for k, v in manifest.artifacts.items()
        },
        "agents": {
            k: _meta_agent_entry_to_dict(v)
            for k, v in manifest.agents.items()
        },
    }


def _meta_artifact_entry_to_dict(entry: MetaArtifactEntry) -> dict[str, Any]:
    d: dict[str, Any] = {
        "id": entry.id,
        "source": entry.source,
        "defaultChecksum": entry.default_checksum,
        "serverChecksum": entry.server_checksum,
        "drifted": entry.drifted,
    }
    if entry.drifted_at:
        d["driftedAt"] = entry.drifted_at
    if entry.artifact_category:
        d["artifactCategory"] = entry.artifact_category
    return d


def _meta_agent_entry_to_dict(entry: MetaAgentEntry) -> dict[str, Any]:
    d: dict[str, Any] = {
        "id": entry.id,
        "source": entry.source,
        "defaultChecksum": entry.default_checksum,
        "serverChecksum": entry.server_checksum,
        "drifted": entry.drifted,
    }
    if entry.drifted_at:
        d["driftedAt"] = entry.drifted_at
    return d


def _parse_meta_manifest(raw: dict[str, Any]) -> MetaManifest:
    """Parse a raw JSON dict into MetaManifest."""
    artifacts: dict[str, MetaArtifactEntry] = {}
    for k, v in raw.get("artifacts", {}).items():
        artifacts[k] = MetaArtifactEntry(
            id=v["id"],
            source=v["source"],
            default_checksum=v["defaultChecksum"],
            server_checksum=v["serverChecksum"],
            drifted=v["drifted"],
            drifted_at=v.get("driftedAt"),
            artifact_category=v.get("artifactCategory"),
        )

    agents: dict[str, MetaAgentEntry] = {}
    for k, v in raw.get("agents", {}).items():
        agents[k] = MetaAgentEntry(
            id=v["id"],
            source=v["source"],
            default_checksum=v["defaultChecksum"],
            server_checksum=v["serverChecksum"],
            drifted=v["drifted"],
            drifted_at=v.get("driftedAt"),
        )

    return MetaManifest(
        module=raw["module"],
        code_version=raw.get("codeVersion", "0.0.0"),
        bootstrapped_at=raw["bootstrappedAt"],
        artifacts=artifacts,
        agents=agents,
    )
