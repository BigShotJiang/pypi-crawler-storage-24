"""Governance enforcement logic — pure function, no I/O.

Port of ``packages/bootstrap/src/bootstrap/enforcement.ts``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal


@dataclass
class GovernanceWarningLight:
    """A single governance warning."""

    kind: str
    severity: Literal["critical", "high", "medium", "low"]
    message: str


@dataclass
class GovernanceEnforcementResult:
    """Result of enforcement-mode validation."""

    blocked: bool
    block_reason: str | None = None
    warnings: list[GovernanceWarningLight] = field(default_factory=list)


def validate_enforcement_mode(
    warnings: list[GovernanceWarningLight],
    mode: Literal["advisory", "hard"],
) -> GovernanceEnforcementResult:
    """Validate governance warnings against the enforcement mode.

    In ``"advisory"`` mode warnings are returned but bootstrap is never blocked.
    In ``"hard"`` mode bootstrap is blocked when any ``critical`` warning exists.

    Pure function — no I/O, no side effects.
    """
    if mode != "hard":
        return GovernanceEnforcementResult(blocked=False, warnings=warnings)

    critical_gaps = [w for w in warnings if w.severity == "critical"]
    if not critical_gaps:
        return GovernanceEnforcementResult(blocked=False, warnings=warnings)

    details = "\n".join(f"  - {g.kind}: {g.message}" for g in critical_gaps)
    block_reason = (
        f"Bootstrap blocked: {len(critical_gaps)} critical governance gap(s):\n"
        + details
    )

    return GovernanceEnforcementResult(
        blocked=True,
        block_reason=block_reason,
        warnings=warnings,
    )
