"""
Ebbinghaus forgetting curve for AgentMemory — Python parity.

Core formula: R = importance × e^(−epoch / halfLife)
Floor at 0.01 — memories never fully vanish.

Rates (validated by engram-rs + FadeMem paper):
  episodic:   ~35 epochs half-life (decays fast)
  semantic:   ~58 epochs half-life (decays moderate)
  procedural: ~173 epochs half-life (decays slow)
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import Optional

# ── Constants ────────────────────────────────────────────────────────────────

DEFAULT_DECAY_RATES = {"episodic": 35, "semantic": 58, "procedural": 173}
DECAY_FLOOR = 0.01
RECALL_BOOST_FACTOR = 0.3  # 30% importance recovery on access

PROMOTION_THRESHOLDS = {
    "buffer_to_working": {"min_importance": 0.3, "min_access_count": 2},
    "working_to_core": {
        "min_importance": 0.7,
        "min_access_count": 5,
        "min_age_hours": 24,
    },
    "demotion_threshold": 0.2,
    "archive_threshold": 0.05,
    "core_floor": 0.5,
}


# ── Data Types ───────────────────────────────────────────────────────────────


@dataclass
class EpisodeMemory:
    """Minimal episodic memory representation for decay calculations."""

    session: str
    actions: list[str] = field(default_factory=list)
    importance: float = 0.5
    tier: str = "buffer"  # buffer | working | core
    decay_epoch: int = 0
    timestamp: Optional[str] = None
    tags: list[str] = field(default_factory=list)
    access_count: int = 0
    decisions: Optional[list[dict]] = None
    patterns: Optional[list[str]] = None


@dataclass
class DecayCycleResult:
    """Result of applying one decay cycle."""

    retained: list[EpisodeMemory]
    archived: list[EpisodeMemory]


# ── Core Functions ───────────────────────────────────────────────────────────


def compute_decay(importance: float, epoch: int, half_life: float) -> float:
    """
    Compute decayed importance using Ebbinghaus forgetting curve.
    R = importance × e^(-epoch / halfLife), floored at DECAY_FLOOR.
    """
    if epoch <= 0:
        return importance
    decayed = importance * math.exp(-epoch / half_life)
    return max(DECAY_FLOOR, decayed)


def apply_recall_boost(current_importance: float) -> float:
    """
    Apply recall boost — accessing a memory partially restores its importance.
    newImportance = min(1.0, current + RECALL_BOOST_FACTOR × (1 - current))
    """
    return min(1.0, current_importance + RECALL_BOOST_FACTOR * (1 - current_importance))


def tick_episode(
    episode: EpisodeMemory, half_life: float
) -> EpisodeMemory:
    """Increment decay epoch and compute new importance for a single episodic memory."""
    epoch = episode.decay_epoch + 1
    base_importance = episode.importance
    new_importance = compute_decay(base_importance, epoch, half_life)

    # Core memories never go below core_floor
    floor = (
        PROMOTION_THRESHOLDS["core_floor"]
        if episode.tier == "core"
        else DECAY_FLOOR
    )

    return EpisodeMemory(
        session=episode.session,
        actions=episode.actions,
        importance=max(floor, new_importance),
        tier=episode.tier,
        decay_epoch=epoch,
        timestamp=episode.timestamp,
        tags=episode.tags,
        access_count=episode.access_count,
        decisions=episode.decisions,
        patterns=episode.patterns,
    )


def apply_decay_cycle(
    episodes: list[EpisodeMemory],
    rates: Optional[dict[str, float]] = None,
) -> DecayCycleResult:
    """
    Apply one decay cycle to all episodic memories.
    Returns partition: { retained, archived }
    """
    rates = rates or {}
    half_life = rates.get("episodic", DEFAULT_DECAY_RATES["episodic"])
    retained: list[EpisodeMemory] = []
    archived: list[EpisodeMemory] = []

    for ep in episodes:
        ticked = tick_episode(ep, half_life)
        if (
            ticked.tier != "core"
            and ticked.importance < PROMOTION_THRESHOLDS["archive_threshold"]
        ):
            archived.append(ticked)
        else:
            retained.append(ticked)

    return DecayCycleResult(retained=retained, archived=archived)


def evaluate_promotion(episode: EpisodeMemory) -> Optional[str]:
    """
    Determine eligible promotion for a memory based on rule-based thresholds.
    Returns the new tier if promotion/demotion is warranted, or None for no change.
    """
    importance = episode.importance
    access_count = episode.access_count
    tier = episode.tier

    if tier == "core":
        return None  # Core is permanent

    if tier == "buffer":
        thresholds = PROMOTION_THRESHOLDS["buffer_to_working"]
        if (
            importance > thresholds["min_importance"]
            and access_count >= thresholds["min_access_count"]
        ):
            return "working"

    if tier == "working":
        thresholds = PROMOTION_THRESHOLDS["working_to_core"]
        if (
            importance > thresholds["min_importance"]
            and access_count >= thresholds["min_access_count"]
        ):
            return "core"

    # Demotion check: Working → Buffer
    if tier == "working" and importance < PROMOTION_THRESHOLDS["demotion_threshold"]:
        return "buffer"

    return None  # No change
