"""Cockpit AAP Manifest types, parser, scanner, and helpers -- Python dataclasses mirroring Manifest TypeScript types.

Type sources:
  - ``types.py``: Handwritten dataclasses with ``from_dict`` parsing (public API)
  - ``_generated.py``: Auto-generated from JSON Schema via ``scripts/generate-python-types.sh`` (contract reference)
  - ``_generated_kinds.py``: Auto-generated per-kind types (Agent, Skill, Soul, etc.) from JSON Schema (contract reference)
"""

from cockpit_aap.manifest.parser import parse_manifest
from cockpit_aap.manifest.scanner import scan_manifest
from cockpit_aap.manifest.merge import merge_manifests

# Side-effect import — registers all 34 non-Module built-in kinds
import cockpit_aap.manifest.scanners as _scanners  # noqa: F401

from cockpit_aap.manifest.resolve_ref import (
    is_file_ref,
    resolve_ref,
    resolve_json_ref,
)
from cockpit_aap.manifest.registry import (
    Registry,
    RegistryModule,
    scan_registry,
    parse_registry,
    resolve_module,
    filter_modules_by_category,
    filter_modules_by_tag,
    search_modules,
)
from cockpit_aap.manifest.project_scanner import (
    scan_project,
    is_project_dir,
    read_project_meta,
)

# Auto-generated contract types (read-only, no parsing logic)
from cockpit_aap.manifest import _generated as contract_types

# Auto-generated per-kind contract types (Agent, Skill, Soul, etc.)
from cockpit_aap.manifest import _generated_kinds as kind_types

from cockpit_aap.manifest.types import (
    Manifest,
    ManifestAccess,
    ManifestAgent,
    ManifestAgentRef,
    ManifestAgentExecution,
    ManifestAgentPlatformConfig,
    ManifestAgentAzureFoundryConfig,
    ManifestAIEcosystem,
    ManifestArtifact,
    ManifestAudit,
    ManifestRecognition,
    ManifestRecognitionBadge,
    ManifestRecognitionReward,
    ManifestChangelog,
    ManifestChangelogNote,
    ManifestCommand,
    ManifestCommandArg,
    ManifestConnection,
    ManifestDecision,
    ManifestFeatures,
    ManifestHealthCheck,
    ManifestHelp,
    ManifestHITLField,
    ManifestHITLParameter,
    ManifestHITLTool,
    ManifestHook,
    ManifestI18n,
    ManifestIssue,
    ManifestJourney,
    ManifestJourneyStage,
    ManifestKnowledge,
    ManifestLabels,
    ManifestLifecycle,
    ManifestLocale,
    ManifestLocaleOverrides,
    ManifestMetadata,
    ManifestOnboarding,
    ManifestOnboardingStep,
    ManifestOwnerRef,
    ManifestPersonas,
    ManifestPersonaConfig,
    ManifestNetwork,
    ManifestProject,
    ManifestProjectInfo,
    ManifestProjectModule,
    ManifestProjectShared,
    ManifestProjectRouting,
    ManifestProjectResolved,
    ManifestRef,
    ManifestResolvedModule,
    ManifestRoadmapItem,
    ManifestRule,
    ManifestSDLC,
    ManifestSDLCPhaseState,
    ManifestSkill,
    ManifestSkillAutoInvoke,
    ManifestSkillSuggestion,
    ManifestSpec,
    ManifestTelemetry,
    ManifestTelemetryInstrument,
    ManifestTheme,
    ManifestThemeColors,
    ManifestThemePreset,
    ManifestTutorial,
    ManifestUI,
    ManifestUIAgentMode,
    ManifestUIInputMode,
    ManifestUISection,
)
from cockpit_aap.manifest.helpers import (
    # Agent helpers
    get_manifest_agent,
    get_manifest_agent_instruction,
    # Persona-agent helpers
    get_manifest_persona,
    get_agent_for_persona,
    get_persona_agents,
    # Artifact helpers
    get_manifest_artifact_value,
    get_manifest_artifact_json,
    get_state_artifacts,
    get_manifest_artifacts_by_category,
    get_manifest_artifacts_by_prefix,
    # i18n helpers
    get_manifest_locale,
    get_manifest_default_locale,
    get_manifest_prompt_pills,
    get_manifest_welcome,
    get_manifest_i18n_resources,
    get_manifest_localized_content,
    get_manifest_localized_collection,
    get_localized_manifest,
    # Command helpers
    get_manifest_commands,
    get_manifest_command,
    get_manifest_commands_by_persona,
    # Skill helpers
    get_manifest_skills,
    get_manifest_skill,
    get_manifest_skills_by_persona,
    get_manifest_skills_by_trigger,
    # Hook helpers
    get_manifest_hooks,
    get_manifest_hooks_by_event,
    get_manifest_hooks_for_tool,
    # Connection helpers
    get_manifest_connections,
    get_manifest_connection,
    # Theme helpers
    get_manifest_theme,
    get_manifest_default_theme,
    get_manifest_theme_preset,
    get_manifest_theme_preset_ids,
    get_manifest_theme_css_vars,
    # Rules helpers
    get_manifest_rules,
    get_manifest_rules_by_scope,
    get_manifest_rules_by_enforcement,
    get_manifest_rules_for_agent,
    get_manifest_rules_for_agent_and_scope,
    build_rules_instruction_snippet,
    # Lifecycle helpers
    get_manifest_roadmap,
    get_manifest_roadmap_by_status,
    get_manifest_issues,
    get_manifest_open_issues,
    get_manifest_issues_by_severity,
    get_manifest_decisions,
    # Agent execution helpers
    get_agent_execution_mode,
    get_agents_by_execution_mode,
    get_local_agents,
    get_platform_agents,
    get_azure_foundry_agents,
    # Knowledge helpers
    get_manifest_knowledge,
    get_manifest_knowledge_by_kind,
    # HITL helpers
    get_manifest_hitl_tools,
    get_manifest_hitl_tool,
    # Health check helpers
    get_manifest_health_checks,
    # UI helpers
    get_manifest_ui_agent_modes,
    get_manifest_ui_input_modes,
    get_manifest_ui_sections,
    # Network helpers
    get_manifest_network,
    # Journey helpers
    get_manifest_journey_stages,
    # Input context skills
    get_manifest_input_context_skills,
)

from .rule_engine import (
    compile_manifest_rules,
    validate_rules,
    RuleViolation,
    ValidationResult,
)

from .writer import (
    serialize_manifest,
    write_manifest,
    WriteManifestOptions,
)

__all__ = [
    # Parser & Scanner
    "parse_manifest",
    "scan_manifest",
    # Types
    "Manifest",
    "ManifestAccess",
    "ManifestAgent",
    "ManifestAgentRef",
    "ManifestAgentExecution",
    "ManifestAgentPlatformConfig",
    "ManifestAgentAzureFoundryConfig",
    "ManifestAIEcosystem",
    "ManifestArtifact",
    "ManifestAudit",
    "ManifestRecognition",
    "ManifestRecognitionBadge",
    "ManifestRecognitionReward",
    "ManifestChangelog",
    "ManifestChangelogNote",
    "ManifestCommand",
    "ManifestCommandArg",
    "ManifestConnection",
    "ManifestDecision",
    "ManifestFeatures",
    "ManifestHealthCheck",
    "ManifestHelp",
    "ManifestHITLField",
    "ManifestHITLParameter",
    "ManifestHITLTool",
    "ManifestHook",
    "ManifestI18n",
    "ManifestIssue",
    "ManifestJourney",
    "ManifestJourneyStage",
    "ManifestKnowledge",
    "ManifestLabels",
    "ManifestLifecycle",
    "ManifestLocale",
    "ManifestLocaleOverrides",
    "ManifestMetadata",
    "ManifestOnboarding",
    "ManifestOnboardingStep",
    "ManifestOwnerRef",
    "ManifestPersonas",
    "ManifestPersonaConfig",
    "ManifestNetwork",
    "ManifestProject",
    "ManifestProjectInfo",
    "ManifestProjectModule",
    "ManifestProjectShared",
    "ManifestProjectRouting",
    "ManifestProjectResolved",
    "ManifestRef",
    "ManifestResolvedModule",
    "ManifestRoadmapItem",
    "ManifestRule",
    "ManifestSDLC",
    "ManifestSDLCPhaseState",
    "ManifestSkill",
    "ManifestSkillAutoInvoke",
    "ManifestSkillSuggestion",
    "ManifestSpec",
    "ManifestTelemetry",
    "ManifestTelemetryInstrument",
    "ManifestTheme",
    "ManifestThemeColors",
    "ManifestThemePreset",
    "ManifestTutorial",
    "ManifestUI",
    "ManifestUIAgentMode",
    "ManifestUIInputMode",
    "ManifestUISection",
    # Agent helpers
    "get_manifest_agent",
    "get_manifest_agent_instruction",
    # Persona-agent helpers
    "get_manifest_persona",
    "get_agent_for_persona",
    "get_persona_agents",
    # Artifact helpers
    "get_manifest_artifact_value",
    "get_manifest_artifact_json",
    "get_state_artifacts",
    "get_manifest_artifacts_by_category",
    "get_manifest_artifacts_by_prefix",
    # i18n helpers
    "get_manifest_locale",
    "get_manifest_default_locale",
    "get_manifest_prompt_pills",
    "get_manifest_welcome",
    "get_manifest_i18n_resources",
    "get_manifest_localized_content",
    "get_manifest_localized_collection",
    "get_localized_manifest",
    # Command helpers
    "get_manifest_commands",
    "get_manifest_command",
    "get_manifest_commands_by_persona",
    # Skill helpers
    "get_manifest_skills",
    "get_manifest_skill",
    "get_manifest_skills_by_persona",
    "get_manifest_skills_by_trigger",
    # Hook helpers
    "get_manifest_hooks",
    "get_manifest_hooks_by_event",
    "get_manifest_hooks_for_tool",
    # Connection helpers
    "get_manifest_connections",
    "get_manifest_connection",
    # Theme helpers
    "get_manifest_theme",
    "get_manifest_default_theme",
    "get_manifest_theme_preset",
    "get_manifest_theme_preset_ids",
    "get_manifest_theme_css_vars",
    # Rules helpers
    "get_manifest_rules",
    "get_manifest_rules_by_scope",
    "get_manifest_rules_by_enforcement",
    "get_manifest_rules_for_agent",
    "get_manifest_rules_for_agent_and_scope",
    "build_rules_instruction_snippet",
    # Lifecycle helpers
    "get_manifest_roadmap",
    "get_manifest_roadmap_by_status",
    "get_manifest_issues",
    "get_manifest_open_issues",
    "get_manifest_issues_by_severity",
    "get_manifest_decisions",
    # Agent execution helpers
    "get_agent_execution_mode",
    "get_agents_by_execution_mode",
    "get_local_agents",
    "get_platform_agents",
    "get_azure_foundry_agents",
    # Knowledge helpers
    "get_manifest_knowledge",
    "get_manifest_knowledge_by_kind",
    # HITL helpers
    "get_manifest_hitl_tools",
    "get_manifest_hitl_tool",
    # Health check helpers
    "get_manifest_health_checks",
    # UI helpers
    "get_manifest_ui_agent_modes",
    "get_manifest_ui_input_modes",
    "get_manifest_ui_sections",
    # Network helpers
    "get_manifest_network",
    # Journey helpers
    "get_manifest_journey_stages",
    # Input context skills
    "get_manifest_input_context_skills",
    # Rule engine
    "compile_manifest_rules",
    "validate_rules",
    "RuleViolation",
    "ValidationResult",
    # Writer
    "serialize_manifest",
    "write_manifest",
    "WriteManifestOptions",
    # Merge
    "merge_manifests",
    # Registry
    "Registry",
    "RegistryModule",
    "scan_registry",
    "parse_registry",
    "resolve_module",
    "filter_modules_by_category",
    "filter_modules_by_tag",
    "search_modules",
    # Project scanner
    "scan_project",
    "is_project_dir",
    "read_project_meta",
    # resolve_ref
    "is_file_ref",
    "resolve_ref",
    "resolve_json_ref",
]
