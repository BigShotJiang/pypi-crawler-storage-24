# packages/py/cockpit_aap/manifest/kind_registry.py
"""KindRegistry — registo extensível de parsers e schemas de manifest por kind.

Equivalente Python de KindRegistry (TypeScript, packages/bootstrap/src/manifest/kind-registry.ts).

Exemplo de uso:
    from cockpit_aap.manifest.kind_registry import kind_registry

    # Registar custom kind
    kind_registry.register(
        "Pipeline",
        parse_fn=parse_pipeline_yaml,
        description="An orchestrated sequence of steps...",
        fields=[
            KindFieldSchema(path="metadata.name", type="string", required=True),
            KindFieldSchema(path="spec.steps[].id", type="string", required=True),
        ],
    )

    # Parsear a partir de uma string YAML
    manifest = kind_registry.parse_yaml(yaml_str, "Module")

    # Exportar schema para LLM
    print(kind_registry.to_llm_context())
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any, Callable

import yaml


# ── Types ──────────────────────────────────────────────────────────────────────


@dataclass
class KindFieldSchema:
    """Describes a single field within a kind's manifest spec.

    Used to generate LLM context, JSON Schema, and documentation.
    """

    path: str
    """Dot-notation path — e.g. 'spec.instruction' or 'spec.tools[].name'"""

    type: str
    """TypeScript-style type — e.g. 'string', 'string[]', 'object', 'boolean'"""

    description: str | None = None
    """Human-readable description of this field"""

    required: bool = False
    """Whether this field is required"""

    enum: list[str] | None = None
    """Allowed values for union/enum types"""

    content_type: str | None = None
    """Semantic content type (MIME) — e.g. 'text/markdown', 'application/json', 'text/uri-list'.
    When set, renderers use this to apply the correct visual treatment."""

    kind_ref: str | None = None
    """When set, items at this path are instances of another registered kind.
    Use ``kind_registry.resolve_schema(kind_ref)`` to get the full field schema."""


@dataclass
class ResolvedField:
    """A field with its kindRef expanded inline (returned by resolve_schema).

    Enables full cross-kind awareness for Lens template generation.
    """

    path: str
    type: str
    description: str | None = None
    required: bool = False
    enum: list[str] | None = None
    content_type: str | None = None
    kind_ref: str | None = None
    resolved_kind: dict[str, Any] | None = None
    """When kindRef was resolved, the referenced kind's full schema is inlined here."""


@dataclass
class KindSchemaExport:
    """Structured export of a kind's schema — suitable for JSON serialisation."""

    kind: str
    api_version: str
    description: str | None = None
    fields: list[KindFieldSchema] = field(default_factory=list)
    resolved_fields: list[ResolvedField] | None = None
    """Fields with kindRef entries expanded inline (returned by resolve_schema)."""
    sample: dict[str, Any] | None = None
    default_template: str | None = None
    """Pre-built Handlebars template for this kind."""

    def to_dict(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            "kind": self.kind,
            "apiVersion": self.api_version,
            "description": self.description,
            "fields": [
                {
                    "path": f.path,
                    "type": f.type,
                    **({"description": f.description} if f.description else {}),
                    **({"required": f.required} if f.required else {}),
                    **({"enum": f.enum} if f.enum else {}),
                    **({"contentType": f.content_type} if f.content_type else {}),
                    **({"kindRef": f.kind_ref} if f.kind_ref else {}),
                }
                for f in self.fields
            ],
        }
        if self.sample is not None:
            result["sample"] = self.sample
        if self.default_template is not None:
            result["defaultTemplate"] = self.default_template
        return result


# ── KindEntry (internal) ───────────────────────────────────────────────────────


@dataclass
class _KindEntry:
    api_version: str
    parse_fn: Callable[[str], Any] | None
    description: str
    fields: list[KindFieldSchema]
    sample: dict[str, Any] | None
    scan_fn: Callable[[str], Any] | None = None
    """Function that reads a manifest dir and returns the typed manifest."""
    default_template: str | None = None
    """Pre-built Handlebars template for visualising this kind."""


# ── KindRegistry ───────────────────────────────────────────────────────────────


class KindRegistry:
    """Registo de parsers e schemas por kind. Thread-safe para leitura; registo feito no import."""

    def __init__(self) -> None:
        self._entries: dict[str, _KindEntry] = {}

    def register(
        self,
        kind: str,
        *,
        description: str,
        fields: list[KindFieldSchema],
        api_version: str = "cockpit.io/v1",
        parse_fn: Callable[[str], Any] | None = None,
        scan_fn: Callable[[str], Any] | None = None,
        sample: dict[str, Any] | None = None,
        default_template: str | None = None,
    ) -> None:
        """Registar um kind com schema e parser opcional.

        Args:
            kind:             nome do kind (ex: "Module", "Agent", "Pipeline")
            description:      descrição humana obrigatória do kind.
            fields:           campos do schema — obrigatório ter pelo menos os campos chave.
            api_version:      apiVersion esperada (default: cockpit.io/v1).
            parse_fn:         função que recebe uma string YAML e retorna o manifest tipado.
            scan_fn:          função que recebe um directório e retorna o manifest tipado.
            sample:           exemplo de manifest — usado em previews e contexto LLM.
            default_template: Handlebars template pré-built para renderizar este kind.
        """
        self._entries[kind] = _KindEntry(
            api_version=api_version,
            parse_fn=parse_fn,
            description=description,
            fields=fields,
            sample=sample,
            scan_fn=scan_fn,
            default_template=default_template,
        )

    def parse_yaml(self, yaml_content: str, kind: str) -> Any:
        """Parsear um manifest a partir de uma string YAML self-contained.

        Args:
            yaml_content: YAML do manifest, com todas as referências já resolvidas.
            kind:         kind do manifest (ex: "Module", "Agent").

        Raises:
            ValueError: se o kind não estiver registado ou não tiver parse_fn.
        """
        entry = self._entries.get(kind)
        if entry is None:
            registered = ", ".join(sorted(self._entries.keys()))
            raise ValueError(
                f'Unknown kind "{kind}". '
                f"Registered kinds: [{registered}]. "
                f'Register with: kind_registry.register("{kind}", description=..., fields=..., parse_fn=...)'
            )
        if entry.parse_fn is None:
            raise ValueError(
                f'Kind "{kind}" does not support YAML-string parsing (parse_fn not registered). '
                f"Register a parse_fn: kind_registry.register(\"{kind}\", ..., parse_fn=lambda y: ...)"
            )
        return entry.parse_fn(yaml_content)

    def is_registered(self, kind: str) -> bool:
        return kind in self._entries

    def registered_kinds(self) -> list[str]:
        return sorted(self._entries.keys())

    # ── Scan & resolve ─────────────────────────────────────────────────────────

    def scan(self, directory: str) -> Any:
        """Universal entry point. Reads manifest.yaml, detects kind, delegates to registered scanner.

        Args:
            directory: path to a manifest directory containing ``manifest.yaml``.

        Raises:
            FileNotFoundError: if no manifest.yaml found.
            ValueError: if kind is missing or not registered.
        """
        import os

        abs_dir = os.path.realpath(directory)
        manifest_file = os.path.join(abs_dir, "manifest.yaml")

        if not os.path.isfile(manifest_file):
            raise FileNotFoundError(f"No manifest.yaml found in {abs_dir}")

        with open(manifest_file, encoding="utf-8") as fh:
            raw = yaml.safe_load(fh)

        kind = raw.get("kind") if isinstance(raw, dict) else None
        if not kind:
            raise ValueError(f"manifest.yaml in {abs_dir} is missing the required 'kind' field")

        entry = self._entries.get(kind)
        if entry is None:
            registered = ", ".join(sorted(self._entries.keys()))
            raise ValueError(
                f'Unknown kind "{kind}" in {manifest_file}. '
                f"Registered kinds: [{registered}]. "
                f'Register your kind with kind_registry.register("{kind}", description=..., fields=...).'
            )

        if entry.scan_fn is not None:
            return entry.scan_fn(abs_dir)

        # Fallback: generic scan via _generic_scan_kind
        from cockpit_aap.manifest.resolve_ref import resolve_ref as _resolve_ref_public

        # Read full manifest YAML + resolve file references
        spec = raw.get("spec", {}) if isinstance(raw, dict) else {}
        _resolve_spec_refs(spec, abs_dir, _resolve_ref_public)
        return raw

    def set_default_template(self, kind: str, template: str) -> None:
        """Set or override the default Handlebars template for an already-registered kind.

        Args:
            kind:     kind name (e.g. "Module", "Agent").
            template: Handlebars template string.
        """
        entry = self._entries.get(kind)
        if entry is not None:
            entry.default_template = template

    def resolve_schema(self, kind: str, max_depth: int = 2) -> KindSchemaExport:
        """Returns the full schema for a kind with all ``kindRef`` fields expanded inline.

        Circular references are protected by a visited set.

        Args:
            kind:      kind name to resolve.
            max_depth: max recursion depth for nested kindRefs (default: 2).
        """
        entry = self._entries.get(kind)
        if entry is None:
            return KindSchemaExport(kind=kind, api_version="unknown", resolved_fields=[])

        visited: set[str] = set()

        def _resolve_fields(fields: list[KindFieldSchema], depth: int) -> list[ResolvedField]:
            result: list[ResolvedField] = []
            for f in fields:
                rf = ResolvedField(
                    path=f.path,
                    type=f.type,
                    description=f.description,
                    required=f.required,
                    enum=f.enum,
                    content_type=f.content_type,
                    kind_ref=f.kind_ref,
                )
                if f.kind_ref and depth > 0 and f.kind_ref not in visited:
                    ref_entry = self._entries.get(f.kind_ref)
                    if ref_entry is not None:
                        visited.add(f.kind_ref)
                        rf.resolved_kind = {
                            "kind": f.kind_ref,
                            "apiVersion": ref_entry.api_version,
                            "description": ref_entry.description,
                            "fields": _resolve_fields(ref_entry.fields, depth - 1),
                        }
                        visited.discard(f.kind_ref)
                result.append(rf)
            return result

        return KindSchemaExport(
            kind=kind,
            api_version=entry.api_version,
            description=entry.description,
            fields=entry.fields,
            resolved_fields=_resolve_fields(entry.fields, max_depth),
            sample=entry.sample,
            default_template=entry.default_template,
        )

    # ── Schema export ──────────────────────────────────────────────────────────

    def to_json_list(self, kinds: list[str] | None = None) -> list[dict[str, Any]]:
        """Export schema for one or all kinds as a list of dicts (JSON-serialisable).

        Args:
            kinds: optional list of kinds to export; defaults to all registered kinds.
        """
        targets = kinds if kinds is not None else sorted(self._entries.keys())
        return [
            KindSchemaExport(
                kind=k,
                api_version=e.api_version,
                description=e.description,
                fields=e.fields,
                sample=e.sample,
                default_template=e.default_template,
            ).to_dict()
            for k in targets
            if (e := self._entries.get(k)) is not None
        ]

    def to_json(self, kinds: list[str] | None = None) -> str:
        """Export schema as a JSON string.

        Args:
            kinds: optional list of kinds to export; defaults to all registered kinds.
        """
        return json.dumps(self.to_json_list(kinds), indent=2, ensure_ascii=False)

    def to_markdown(self, kinds: list[str] | None = None) -> str:
        """Export schema for one or all kinds as a Markdown reference.

        Optimised for injection into LLM system prompts and agent context.

        Args:
            kinds: optional list of kinds to export; defaults to all registered kinds.
        """
        schemas = self.to_json_list(kinds)
        if not schemas:
            return ""

        lines: list[str] = [
            "## AAP SDK — Registered Kinds",
            "",
            f"> {len(schemas)} kinds registered. Use exact field paths in templates and prompts.",
            "",
        ]

        for schema in schemas:
            lines.append(f"### `kind: {schema['kind']}` ({schema['apiVersion']})")
            if schema.get("description"):
                lines.extend(["", schema["description"]])

            fields: list[dict[str, Any]] = schema.get("fields", [])
            if fields:
                lines.extend([
                    "",
                    "| Field | Type | Required | Description |",
                    "|-------|------|----------|-------------|",
                ])
                for f in fields:
                    type_str = " \\| ".join(f["enum"]) if f.get("enum") else f["type"]
                    req = "yes" if f.get("required") else "no"
                    desc = f.get("description", "")
                    lines.append(f"| `{f['path']}` | {type_str} | {req} | {desc} |")
            else:
                lines.extend(["", "_No field schema registered for this kind._"])

            if schema.get("sample"):
                lines.extend([
                    "",
                    "<details><summary>Sample YAML</summary>",
                    "",
                    "```yaml",
                    yaml.dump(schema["sample"], allow_unicode=True, indent=2).rstrip(),
                    "```",
                    "",
                    "</details>",
                ])

            lines.append("")

        return "\n".join(lines)

    def to_llm_context(self, kinds: list[str] | None = None) -> str:
        """Alias for to_markdown() — named for clarity when used in LLM context injection.

        Args:
            kinds: optional list of kinds to export; defaults to all registered kinds.
        """
        return self.to_markdown(kinds)

    def to_yaml(self, kinds: list[str] | None = None) -> str:
        """Export schema as a YAML string.

        Args:
            kinds: optional list of kinds to export; defaults to all registered kinds.
        """
        return yaml.dump(
            self.to_json_list(kinds),
            allow_unicode=True,
            indent=2,
            default_flow_style=False,
        )


# Singleton global — importar e usar em qualquer parte do código
kind_registry = KindRegistry()


# ── Standalone functions ───────────────────────────────────────────────────────


def get_field_content_type(kind: str, field_path: str) -> str | None:
    """Look up the declared content type for a field within a registered kind.

    Supports exact path matching and wildcard suffix matching:
        get_field_content_type("Agent", "spec.instruction") → "text/markdown"
        get_field_content_type("Module", "metadata.annotations.vision") → "text/markdown"

    Returns ``None`` when the kind is not registered or the field has no declared content type.
    """
    entry = kind_registry._entries.get(kind)
    if entry is None or not entry.fields:
        return None

    for f in entry.fields:
        if f.content_type is None:
            continue
        # Exact match
        if f.path == field_path:
            return f.content_type
        # Wildcard suffix: "metadata.annotations.*" matches "metadata.annotations.vision"
        if f.path.endswith(".*"):
            prefix = f.path[:-2]
            if field_path.startswith(prefix + "."):
                return f.content_type
    return None


def create_kind_registry() -> KindRegistry:
    """Factory for testing — creates a fresh isolated registry (no built-in kinds)."""
    return KindRegistry()


def scan_kind_manifest(directory: str) -> Any:
    """Universal entry point using the global registry.

    Reads ``manifest.yaml`` in *directory*, detects the ``kind`` field,
    and delegates to the registered scanner/parser.
    """
    return kind_registry.scan(directory)


def _resolve_spec_refs(
    spec: dict[str, Any],
    base_dir: str,
    resolve_fn: Callable[[str, str], str],
) -> None:
    """Walk a spec dict and resolve string values that look like file references.

    This is a generic, recursive version used by the ``scan()`` fallback.
    """
    for key, value in list(spec.items()):
        if isinstance(value, str):
            spec[key] = resolve_fn(value, base_dir)
        elif isinstance(value, dict):
            _resolve_spec_refs(value, base_dir, resolve_fn)
        elif isinstance(value, list):
            for i, item in enumerate(value):
                if isinstance(item, str):
                    value[i] = resolve_fn(item, base_dir)
                elif isinstance(item, dict):
                    _resolve_spec_refs(item, base_dir, resolve_fn)


def _register_builtin_kinds() -> None:
    """Registar os kinds built-in do SDK."""
    from cockpit_aap.manifest.parser import parse_manifest

    kind_registry.register(
        "Module",
        api_version="cockpit.io/v1",
        description=(
            "A Cockpit module manifest — defines the full spec for a deployable module: "
            "agents, artifacts, i18n, theme, commands, skills, hooks, connections, personas, "
            "guardrails, telemetry, governance, lifecycle, and labels."
        ),
        fields=[
            KindFieldSchema(path="metadata.name", type="string", required=True, description="kebab-case module id"),
            KindFieldSchema(path="metadata.displayName", type="string", description="human-readable module name"),
            KindFieldSchema(path="metadata.version", type="string", required=True, description="semver version"),
            KindFieldSchema(path="metadata.description", type="string", description="short module description"),
            KindFieldSchema(path="metadata.icon", type="string", description="Lucide icon name"),
            KindFieldSchema(path="metadata.group", type="string", description="sidebar group label"),
            KindFieldSchema(path="metadata.route", type="string", description="app route path"),
            KindFieldSchema(path="metadata.artifactPrefix", type="string", required=True, description="prefix for all artifact keys"),
            KindFieldSchema(path="spec.agents[].id", type="string", required=True, description="agent kebab-case id"),
            KindFieldSchema(path="spec.agents[].kind", type="string", enum=["BuiltInAgent", "UtilityAgent", "DeepAgent"], description="agent kind"),
            KindFieldSchema(path="spec.agents[].instruction", type="string", description="inline instruction or file ref"),
            KindFieldSchema(path="spec.artifacts[].key", type="string", required=True, description="artifact key (with prefix)"),
            KindFieldSchema(path="spec.artifacts[].defaultValue", type="string", description="default value or file ref"),
            KindFieldSchema(path="spec.artifacts[].category", type="string", enum=["configuration", "state", "content"], description="artifact category"),
            KindFieldSchema(path="spec.i18n.defaultLocale", type="string", description="default locale code"),
            KindFieldSchema(path="spec.i18n.locales", type="object", description="locale overrides keyed by locale code"),
            KindFieldSchema(path="spec.theme.default", type="string", description="default theme preset id"),
            KindFieldSchema(path="spec.theme.presets", type="object", description="theme presets record"),
            KindFieldSchema(path="spec.connections[].id", type="string", required=True, description="connection id"),
            KindFieldSchema(path="spec.connections[].transport", type="string", enum=["streamable-http", "rest"], description="connection transport"),
        ],
        parse_fn=parse_manifest,
        sample={
            "apiVersion": "cockpit.io/v1",
            "kind": "Module",
            "metadata": {
                "name": "my-module",
                "displayName": "My Module",
                "version": "1.0.0",
                "artifactPrefix": "my-module.",
            },
            "spec": {
                "agents": [{"id": "assistant", "kind": "BuiltInAgent", "instruction": "You are a helpful assistant."}],
                "artifacts": [{"key": "my-module.config.settings", "defaultValue": "{}", "category": "configuration"}],
            },
        },
    )


def _register_utility_agent_kind() -> None:
    """Register the UtilityAgent kind."""

    def _parse_utility_agent_yaml(yaml_str: str) -> dict:
        return yaml.safe_load(yaml_str)

    kind_registry.register(
        "UtilityAgent",
        api_version="cockpit.io/v1",
        description=(
            "AI agent with personas, knowledge refs, teams, front matter, guardrails. "
            "Supports inline instruction or file ref, persona-specific overlays, "
            "tool declarations, and team composition."
        ),
        fields=[
            KindFieldSchema(path="metadata.name", type="string", required=True, description="kebab-case identifier"),
            KindFieldSchema(path="spec.type", type="string", required=True, description="standard | supervisor | deepagent"),
            KindFieldSchema(path="spec.instruction", type="string", required=True, description="base instruction"),
            KindFieldSchema(path="spec.model", type="string", description="LLM model"),
            KindFieldSchema(path="spec.personaInstructions", type="object", description="persona overlays keyed by persona id"),
            KindFieldSchema(path="spec.knowledgeRefs[]", type="string[]", description="knowledge refs"),
            KindFieldSchema(path="spec.tools[]", type="string[]", description="tool names"),
        ],
        parse_fn=_parse_utility_agent_yaml,
    )


_register_builtin_kinds()
_register_utility_agent_kind()
