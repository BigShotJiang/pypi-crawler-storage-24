"""Module registry — scan, parse, query.

Port of ``packages/bootstrap/src/manifest/registry.ts``.
A *Registry* is a standalone YAML file that catalogues multiple modules.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional

import yaml


REGISTRY_FILENAMES = ("registry.yaml", "registry.yml", "module-registry.yaml")


# ---------------------------------------------------------------------------
# Types
# ---------------------------------------------------------------------------


@dataclass
class RegistryModule:
    """A single module entry inside a :class:`Registry`."""

    id: str
    name: str
    description: str
    source: str
    version: str
    category: str | None = None
    author: str | None = None
    tags: list[str] = field(default_factory=list)
    icon: str | None = None


@dataclass
class Registry:
    """A module registry document (``$schema: cockpit://registry/v1``)."""

    schema: str  # "$schema" field
    name: str
    version: str
    owner: str | None = None
    modules: list[RegistryModule] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Scanning & Parsing
# ---------------------------------------------------------------------------


def scan_registry(directory: str) -> Registry | None:
    """Scan *directory* for a registry file and return the parsed :class:`Registry`.

    Looks for ``registry.yaml``, ``registry.yml``, or ``module-registry.yaml``.
    Returns ``None`` if no registry file is found.
    """
    resolved = os.path.abspath(directory)
    for filename in REGISTRY_FILENAMES:
        path = os.path.join(resolved, filename)
        if os.path.isfile(path):
            with open(path, encoding="utf-8") as fh:
                return parse_registry(fh.read())
    return None


def parse_registry(yaml_content: str) -> Registry:
    """Parse a YAML string as a :class:`Registry` document.

    Raises :class:`ValueError` / :class:`TypeError` on invalid input.
    """
    parsed = yaml.safe_load(yaml_content)
    if not parsed or not isinstance(parsed, dict):
        raise ValueError("Invalid registry: expected a YAML object")

    schema = parsed.get("$schema", "")
    if schema != "cockpit://registry/v1":
        raise TypeError(
            f'Invalid registry schema: expected "cockpit://registry/v1", got "{schema}"'
        )

    name = parsed.get("name")
    if not name:
        raise TypeError("Invalid registry: name is required")

    raw_modules = parsed.get("modules")
    if not isinstance(raw_modules, list):
        raise TypeError("Invalid registry: modules array is required")

    modules = [
        RegistryModule(
            id=m.get("id", ""),
            name=m.get("name", ""),
            description=m.get("description", ""),
            source=m.get("source", ""),
            version=m.get("version", ""),
            category=m.get("category"),
            author=m.get("author"),
            tags=m.get("tags", []),
            icon=m.get("icon"),
        )
        for m in raw_modules
        if isinstance(m, dict)
    ]

    return Registry(
        schema=schema,
        name=name,
        version=parsed.get("version", ""),
        owner=parsed.get("owner"),
        modules=modules,
    )


# ---------------------------------------------------------------------------
# Query helpers
# ---------------------------------------------------------------------------


def resolve_module(registry: Registry, module_id: str) -> RegistryModule | None:
    """Find a module by *module_id* (exact match) inside *registry*."""
    for m in registry.modules:
        if m.id == module_id:
            return m
    return None


def filter_modules_by_category(registry: Registry, category: str) -> list[RegistryModule]:
    """Return all modules in *registry* matching *category*."""
    return [m for m in registry.modules if m.category == category]


def filter_modules_by_tag(registry: Registry, tag: str) -> list[RegistryModule]:
    """Return all modules in *registry* that include *tag*."""
    return [m for m in registry.modules if tag in (m.tags or [])]


def search_modules(registry: Registry, query: str) -> list[RegistryModule]:
    """Search modules by *query* (case-insensitive, matches id/name/description/tags)."""
    q = query.lower()
    results: list[RegistryModule] = []
    for m in registry.modules:
        fields = [m.id, m.name, m.description] + (m.tags or [])
        if any(q in f.lower() for f in fields if f):
            results.append(m)
    return results
