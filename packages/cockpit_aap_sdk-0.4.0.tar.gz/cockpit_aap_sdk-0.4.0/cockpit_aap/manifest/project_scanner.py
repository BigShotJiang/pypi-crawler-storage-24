"""Multi-module project scanner.

Port of ``packages/bootstrap/src/manifest/project-scanner.ts``.
Scans ``project.yaml`` / ``cockpit-project.yaml`` and resolves all modules.
"""

from __future__ import annotations

import os
from typing import Any

import yaml

from .scanner import scan_manifest
from .types import (
    ManifestProject,
    ManifestProjectResolved,
    ManifestResolvedModule,
    ManifestProjectModule,
)

PROJECT_FILES = ("project.yaml", "cockpit-project.yaml")


def scan_project(project_dir: str) -> ManifestProjectResolved:
    """Scan a project directory and resolve all referenced modules.

    Looks for ``project.yaml`` or ``cockpit-project.yaml`` at the project root,
    then scans each referenced module's Manifest.

    Raises :class:`FileNotFoundError` when no project file exists.
    Raises :class:`ValueError` when the project file is invalid.
    """
    resolved_dir = os.path.abspath(project_dir)
    project_file: str | None = None

    for name in PROJECT_FILES:
        candidate = os.path.join(resolved_dir, name)
        if os.path.isfile(candidate):
            project_file = candidate
            break

    if not project_file:
        raise FileNotFoundError(
            f"No project manifest found in {resolved_dir}. "
            f"Expected one of: {', '.join(PROJECT_FILES)}"
        )

    with open(project_file, encoding="utf-8") as fh:
        raw = yaml.safe_load(fh.read())

    if not raw or not isinstance(raw, dict):
        raise ValueError(f"Invalid project manifest in {project_file}")

    project_info = raw.get("project", {})
    if not project_info.get("id"):
        raise ValueError(f"Invalid project manifest: missing project.id in {project_file}")

    raw_modules = raw.get("modules", [])
    if not raw_modules:
        raise ValueError(f"Project {project_info['id']} has no modules defined")

    # Build ManifestProject
    project = ManifestProject(
        project=_to_project_info(project_info),
        modules=[_to_project_module(m) for m in raw_modules],
        shared=_to_project_shared(raw.get("shared")),
        routing=_to_project_routing(raw.get("routing")),
    )

    # Resolve modules
    modules = _resolve_modules(resolved_dir, project.modules)
    default_id = _find_default_module(modules, project.routing)

    for m in modules:
        m.default = m.id == default_id

    return ManifestProjectResolved(
        project=project.project,
        modules=modules,
        shared=project.shared,
        routing=project.routing,
    )


def is_project_dir(directory: str) -> bool:
    """Return ``True`` if *directory* contains a project manifest."""
    resolved = os.path.abspath(directory)
    return any(os.path.isfile(os.path.join(resolved, n)) for n in PROJECT_FILES)


def read_project_meta(project_dir: str) -> ManifestProject:
    """Read just the project metadata without scanning child modules."""
    resolved = os.path.abspath(project_dir)

    for name in PROJECT_FILES:
        candidate = os.path.join(resolved, name)
        if os.path.isfile(candidate):
            with open(candidate, encoding="utf-8") as fh:
                raw = yaml.safe_load(fh.read())
            return ManifestProject(
                project=_to_project_info(raw.get("project", {})),
                modules=[_to_project_module(m) for m in raw.get("modules", [])],
                shared=_to_project_shared(raw.get("shared")),
                routing=_to_project_routing(raw.get("routing")),
            )

    raise FileNotFoundError(f"No project manifest found in {resolved}")


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _to_project_info(raw: dict) -> Any:
    """Convert raw dict to ManifestProjectInfo."""
    from .types import ManifestProjectInfo

    return ManifestProjectInfo(
        id=raw.get("id", ""),
        name=raw.get("name", ""),
        description=raw.get("description"),
        version=raw.get("version"),
    )


def _to_project_module(raw: dict) -> ManifestProjectModule:
    return ManifestProjectModule(
        id=raw.get("id"),
        path=raw.get("path", ""),
        route=raw.get("route"),
        default=raw.get("default", False),
        enabled=raw.get("enabled", True),
    )


def _to_project_shared(raw: Any) -> Any:
    """Convert raw shared config to ManifestProjectShared (or None)."""
    if not raw or not isinstance(raw, dict):
        return None
    from .types import ManifestProjectShared

    return ManifestProjectShared(
        theme=raw.get("theme"),
        i18n=raw.get("i18n"),
        access=raw.get("access"),
        connections=raw.get("connections"),
    )


def _to_project_routing(raw: Any) -> Any:
    """Convert raw routing config to ManifestProjectRouting (or None)."""
    if not raw or not isinstance(raw, dict):
        return None
    from .types import ManifestProjectRouting

    return ManifestProjectRouting(
        default_module=raw.get("defaultModule"),
        base_path=raw.get("basePath"),
    )


def _resolve_modules(
    project_dir: str,
    module_defs: list[ManifestProjectModule],
) -> list[ManifestResolvedModule]:
    resolved: list[ManifestResolvedModule] = []

    for defn in module_defs:
        manifest_dir = os.path.join(project_dir, defn.path)

        if not os.path.isdir(manifest_dir):
            raise FileNotFoundError(
                f"Module path not found: {defn.path} (resolved: {manifest_dir})"
            )

        manifest = scan_manifest(manifest_dir)
        module_id = defn.id or manifest.metadata.name
        route = defn.route or getattr(manifest.metadata, "route", None) or f"/{module_id}"
        enabled = defn.enabled if defn.enabled is not None else True

        resolved.append(
            ManifestResolvedModule(
                id=module_id,
                path=defn.path,
                route=route,
                default=defn.default or False,
                enabled=enabled,
                manifest=manifest,
            )
        )

    return resolved


def _find_default_module(
    modules: list[ManifestResolvedModule],
    routing: Any,
) -> str:
    # 1. Routing-level default
    if routing and hasattr(routing, "default_module") and routing.default_module:
        for m in modules:
            if m.id == routing.default_module and m.enabled:
                return m.id

    # 2. Module-level default: True
    for m in modules:
        if m.default and m.enabled:
            return m.id

    # 3. First enabled module
    for m in modules:
        if m.enabled:
            return m.id

    # Fallback
    return modules[0].id if modules else ""
