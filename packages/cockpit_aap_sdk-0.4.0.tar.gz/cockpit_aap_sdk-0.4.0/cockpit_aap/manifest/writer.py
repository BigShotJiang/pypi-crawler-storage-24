"""Manifest writer — Python port of the TypeScript ``writer.ts``.

Provides ``serialize_manifest()`` for YAML serialization and
``write_manifest()`` for multi-file extraction to disk.
"""

from __future__ import annotations

import copy
import json
import os
import re
from dataclasses import asdict, fields as dataclass_fields, is_dataclass
from pathlib import Path
from typing import Any

import yaml


# ---------------------------------------------------------------------------
# Options
# ---------------------------------------------------------------------------

class WriteManifestOptions:
    """Options for :func:`write_manifest`."""

    def __init__(
        self,
        *,
        single_file: bool = False,
        extract_agent_instructions: bool = True,
        extract_command_scripts: bool = True,
        extract_skill_instructions: bool = True,
        extract_i18n_files: bool = True,
    ) -> None:
        self.single_file = single_file
        self.extract_agent_instructions = extract_agent_instructions
        self.extract_command_scripts = extract_command_scripts
        self.extract_skill_instructions = extract_skill_instructions
        self.extract_i18n_files = extract_i18n_files


# ---------------------------------------------------------------------------
# Internal utilities
# ---------------------------------------------------------------------------

_CAMEL_RE_1 = re.compile(r"([A-Z]+)([A-Z][a-z])")
_CAMEL_RE_2 = re.compile(r"([a-z0-9])([A-Z])")


def _to_camel_case(name: str) -> str:
    """Convert ``snake_case`` to ``camelCase``."""
    parts = name.split("_")
    return parts[0] + "".join(p.capitalize() for p in parts[1:])


def _dataclass_to_dict(obj: Any) -> Any:
    """Recursively convert a dataclass to a dict with camelCase keys.

    ``None`` values are omitted to keep YAML clean.
    """
    if is_dataclass(obj) and not isinstance(obj, type):
        result: dict[str, Any] = {}
        for f in dataclass_fields(obj):
            value = getattr(obj, f.name)
            if value is None:
                continue
            key = _to_camel_case(f.name)
            result[key] = _dataclass_to_dict(value)
        return result
    if isinstance(obj, list):
        return [_dataclass_to_dict(item) for item in obj]
    if isinstance(obj, dict):
        return {k: _dataclass_to_dict(v) for k, v in obj.items()}
    return obj


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def serialize_manifest(manifest: Any) -> str:
    """Serialize a ``Manifest`` to a YAML string.

    Emits ``apiVersion``, ``kind``, ``metadata``, ``spec`` in camelCase.
    """
    data = _dataclass_to_dict(manifest)
    return yaml.dump(
        data,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
        width=120,
    )


def write_manifest(
    manifest: Any,
    output_dir: str | Path,
    options: WriteManifestOptions | None = None,
) -> list[str]:
    """Write a ``Manifest`` to disk.

    Uses multi-file extraction by default (agents/*.md, commands/*.md,
    skills/*/SKILL.md, i18n/*.json, theme.yaml).  Pass
    ``WriteManifestOptions(single_file=True)`` to write everything inline.

    Returns a list of absolute paths of files written.
    """
    opts = options or WriteManifestOptions()
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    if opts.single_file:
        return _write_single_file(manifest, output_dir)

    return _write_multi_file(
        manifest,
        output_dir,
        extract_instructions=opts.extract_agent_instructions,
        extract_commands=opts.extract_command_scripts,
        extract_skills=opts.extract_skill_instructions,
        extract_i18n=opts.extract_i18n_files,
    )


# ---------------------------------------------------------------------------
# Internal — single file
# ---------------------------------------------------------------------------


def _write_single_file(manifest: Any, output_dir: Path) -> list[str]:
    file_path = output_dir / "manifest.yaml"
    yaml_str = serialize_manifest(manifest)
    file_path.write_text(yaml_str, encoding="utf-8")
    return [str(file_path)]


# ---------------------------------------------------------------------------
# Internal — multi-file extraction helpers
# ---------------------------------------------------------------------------


def _extract_agent_instructions(
    manifest_dict: dict[str, Any],
    output_dir: Path,
    files_written: list[str],
) -> None:
    agents = (manifest_dict.get("spec") or {}).get("agents")
    if not agents:
        return

    has_multi_line = any(
        isinstance(a.get("instruction"), str) and "\n" in a["instruction"]
        for a in agents
    )
    if not has_multi_line:
        return

    agents_dir = output_dir / "agents"
    agents_dir.mkdir(parents=True, exist_ok=True)

    for agent in agents:
        instruction = agent.get("instruction", "")
        if isinstance(instruction, str) and "\n" in instruction:
            md_file = f"{agent['id']}.md"
            md_path = agents_dir / md_file
            md_path.write_text(instruction, encoding="utf-8")
            files_written.append(str(md_path))
            agent["instruction"] = f"agents/{md_file}"


def _extract_command_scripts(
    manifest_dict: dict[str, Any],
    output_dir: Path,
    files_written: list[str],
) -> None:
    commands = (manifest_dict.get("spec") or {}).get("commands")
    if not commands:
        return

    has_multi_line = any(
        isinstance(c.get("script"), str) and "\n" in c["script"]
        for c in commands
    )
    if not has_multi_line:
        return

    commands_dir = output_dir / "commands"
    commands_dir.mkdir(parents=True, exist_ok=True)

    for command in commands:
        script = command.get("script", "")
        if isinstance(script, str) and "\n" in script:
            md_file = f"{command['id']}.md"
            md_path = commands_dir / md_file
            md_path.write_text(script, encoding="utf-8")
            files_written.append(str(md_path))
            command["script"] = f"commands/{md_file}"


def _extract_skill_instructions(
    manifest_dict: dict[str, Any],
    output_dir: Path,
    files_written: list[str],
) -> None:
    skills = (manifest_dict.get("spec") or {}).get("skills")
    if not skills:
        return

    has_multi_line = any(
        isinstance(s.get("instruction"), str) and "\n" in s["instruction"]
        for s in skills
    )
    if not has_multi_line:
        return

    for skill in skills:
        instruction = skill.get("instruction", "")
        if isinstance(instruction, str) and "\n" in instruction:
            skill_dir = output_dir / "skills" / skill["id"]
            skill_dir.mkdir(parents=True, exist_ok=True)
            md_path = skill_dir / "SKILL.md"
            md_path.write_text(instruction, encoding="utf-8")
            files_written.append(str(md_path))
            skill["instruction"] = f"skills/{skill['id']}/SKILL.md"


def _extract_i18n_files(
    manifest_dict: dict[str, Any],
    output_dir: Path,
    files_written: list[str],
) -> None:
    i18n = (manifest_dict.get("spec") or {}).get("i18n")
    if not i18n:
        return

    locales = i18n.get("locales", {})
    for locale_code, locale_data in locales.items():
        if not isinstance(locale_data, dict):
            continue

        # Extract resources → i18n/{locale}.json
        resources = locale_data.get("resources")
        if resources and isinstance(resources, dict):
            i18n_dir = output_dir / "i18n"
            i18n_dir.mkdir(parents=True, exist_ok=True)
            file_path = i18n_dir / f"{locale_code}.json"
            file_path.write_text(
                json.dumps(resources, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )
            files_written.append(str(file_path))
            locale_data["resources"] = f"i18n/{locale_code}.json"

        # Extract content → content/{locale}/{key}.json
        content = locale_data.get("content")
        if content and isinstance(content, dict):
            for key, value in list(content.items()):
                if isinstance(value, dict):
                    content_dir = output_dir / "content" / locale_code
                    content_dir.mkdir(parents=True, exist_ok=True)
                    file_path = content_dir / f"{key}.json"
                    file_path.write_text(
                        json.dumps(value, indent=2, ensure_ascii=False),
                        encoding="utf-8",
                    )
                    files_written.append(str(file_path))
                    content[key] = f"content/{locale_code}/{key}.json"


# ---------------------------------------------------------------------------
# Internal — multi-file orchestrator
# ---------------------------------------------------------------------------


def _write_multi_file(
    manifest: Any,
    output_dir: Path,
    *,
    extract_instructions: bool,
    extract_commands: bool,
    extract_skills: bool,
    extract_i18n: bool,
) -> list[str]:
    files_written: list[str] = []

    # Deep clone → convert to dict for mutation
    manifest_dict = _dataclass_to_dict(copy.deepcopy(manifest))

    spec = manifest_dict.get("spec") or {}

    if extract_instructions:
        _extract_agent_instructions(manifest_dict, output_dir, files_written)
    if extract_commands:
        _extract_command_scripts(manifest_dict, output_dir, files_written)
    if extract_skills:
        _extract_skill_instructions(manifest_dict, output_dir, files_written)

    # Extract theme → theme.yaml
    if spec.get("theme"):
        theme_yaml = yaml.dump(
            spec["theme"],
            default_flow_style=False,
            allow_unicode=True,
            sort_keys=False,
            width=120,
        )
        theme_path = output_dir / "theme.yaml"
        theme_path.write_text(theme_yaml, encoding="utf-8")
        files_written.append(str(theme_path))
        del spec["theme"]

    if extract_i18n:
        _extract_i18n_files(manifest_dict, output_dir, files_written)

    # Write core manifest.yaml
    manifest_path = output_dir / "manifest.yaml"
    yaml_str = yaml.dump(
        manifest_dict,
        default_flow_style=False,
        allow_unicode=True,
        sort_keys=False,
        width=120,
    )
    manifest_path.write_text(yaml_str, encoding="utf-8")
    files_written.insert(0, str(manifest_path))

    return files_written
