"""
Consolidation cycle for AgentMemory — orchestrates the full memory management pipeline.

6-step cycle:
  1. DECAY     — Apply Ebbinghaus decay to all episodic memories
  2. DEDUP     — Semantic deduplication (cosine > threshold → merge)
  3. TRIAGE    — Classify memories by tier eligibility
  4. GATE      — Apply promotion gate (rule-based or LLM)
  5. RECONCILE — Update tiers, archive decayed memories
  6. TOPIC     — Rebuild topic tree (if autoOrganize enabled)

Python parity with packages/bootstrap/src/manifest/consolidation-cycle.ts
"""

from __future__ import annotations

import math
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Awaitable, Protocol, TypedDict

from .decay_engine import (
    EpisodeMemory,
    DecayCycleResult,
    apply_decay_cycle,
    DEFAULT_DECAY_RATES,
    compute_decay,
    evaluate_promotion,
)


# ── Port Protocols ────────────────────────────────────────────────────────────


class EmbeddingPort(Protocol):
    """Minimal embedding port."""

    async def embed_batch(self, texts: list[str]) -> list[list[float]]: ...


class LLMPort(Protocol):
    """Minimal LLM port."""

    async def complete(self, prompt: str, max_tokens: int = 200) -> str: ...


# ── Types ─────────────────────────────────────────────────────────────────────


class TierDistribution(TypedDict):
    buffer: int
    working: int
    core: int


@dataclass
class PromotionResult:
    """Record of a single tier change."""

    episode: EpisodeMemory
    previous_tier: str
    new_tier: str
    reason: str


@dataclass
class ConsolidationResult:
    """Result of a full consolidation cycle."""

    total_before: int = 0
    total_after: int = 0
    archived: int = 0
    deduplicated: int = 0
    promotions: list[PromotionResult] = field(default_factory=list)
    duration_ms: float = 0.0
    timestamp: str = ""


# ── Cosine Similarity ─────────────────────────────────────────────────────────


def cosine_similarity(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors."""
    if len(a) != len(b) or len(a) == 0:
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    denom = norm_a * norm_b
    if denom == 0:
        return 0.0
    return dot / denom


# ── Dedup ─────────────────────────────────────────────────────────────────────


async def deduplicate_memories(
    episodes: list[EpisodeMemory],
    embedding: EmbeddingPort,
    threshold: float = 0.78,
) -> tuple[list[EpisodeMemory], int]:
    """Semantic deduplication via cosine similarity."""
    if len(episodes) < 2:
        return episodes, 0

    texts = [
        "; ".join(ep.actions) if ep.actions else ep.session for ep in episodes
    ]
    embeddings = await embedding.embed_batch(texts)

    merged: set[int] = set()
    for i in range(len(episodes)):
        if i in merged:
            continue
        for j in range(i + 1, len(episodes)):
            if j in merged:
                continue
            sim = cosine_similarity(embeddings[i], embeddings[j])
            if sim >= threshold:
                keep_i = episodes[i].importance >= episodes[j].importance
                merged.add(j if keep_i else i)
                if not keep_i:
                    break

    unique = [ep for idx, ep in enumerate(episodes) if idx not in merged]
    return unique, len(merged)


# ── Tier Promotions ───────────────────────────────────────────────────────────


async def apply_tier_promotions(
    episodes: list[EpisodeMemory],
    *,
    promotion_gate: str = "rule-based",
    min_confidence: float = 0.7,
    llm: LLMPort | None = None,
) -> tuple[list[EpisodeMemory], list[PromotionResult]]:
    """Apply tier promotions/demotions with optional LLM gate."""
    core_memories = [e for e in episodes if e.tier == "core"]
    promotions: list[PromotionResult] = []
    updated: list[EpisodeMemory] = []

    for ep in episodes:
        candidate_tier = evaluate_promotion(ep)

        if candidate_tier is None:
            updated.append(ep)
            continue

        # Working → Core with LLM gate
        if candidate_tier == "core" and promotion_gate == "llm-gate" and llm:
            try:
                core_summary = "\n".join(
                    "; ".join(c.actions) if c.actions else c.session
                    for c in core_memories
                )
                prompt = (
                    f"Evaluate if this memory is worth long-term retention.\n"
                    f"Memory: {ep.actions}\n"
                    f"Core memories ({len(core_memories)}):\n{core_summary}\n"
                    f'Respond JSON: {{"promote": bool, "confidence": float, "reason": str}}'
                )
                import json

                response = await llm.complete(prompt, max_tokens=200)
                result = json.loads(response)
                if result.get("promote") and result.get("confidence", 0) >= min_confidence:
                    promoted = EpisodeMemory(
                        session=ep.session,
                        actions=ep.actions,
                        importance=max(ep.importance, 0.5),
                        tier="core",
                        decay_epoch=ep.decay_epoch,
                        access_count=ep.access_count,
                        tags=ep.tags,
                    )
                    updated.append(promoted)
                    promotions.append(
                        PromotionResult(
                            episode=promoted,
                            previous_tier=ep.tier,
                            new_tier="core",
                            reason=f"LLM gate: {result.get('reason', '')}",
                        )
                    )
                else:
                    updated.append(ep)
                continue
            except Exception:
                pass  # Fall through to rule-based

        # Rule-based
        new_ep = EpisodeMemory(
            session=ep.session,
            actions=ep.actions,
            importance=ep.importance,
            tier=candidate_tier,
            decay_epoch=ep.decay_epoch,
            access_count=ep.access_count,
            tags=ep.tags,
        )
        updated.append(new_ep)
        promotions.append(
            PromotionResult(
                episode=new_ep,
                previous_tier=ep.tier,
                new_tier=candidate_tier,
                reason=f"Rule-based: {ep.tier} → {candidate_tier}",
            )
        )

    return updated, promotions


# ── Core Function ─────────────────────────────────────────────────────────────


async def run_consolidation_cycle(
    spec: dict[str, Any],
    *,
    embedding: EmbeddingPort | None = None,
    llm: LLMPort | None = None,
) -> ConsolidationResult:
    """
    Run a full consolidation cycle on an AgentMemory spec dict.

    Args:
        spec: The manifest spec dictionary (mutated in-place).
        embedding: Optional embedding port for dedup + topics.
        llm: Optional LLM port for quality gate + topic naming.

    Returns:
        ConsolidationResult with cycle statistics.
    """
    start = time.monotonic()
    consolidation = spec.get("consolidation", {})
    raw_episodes = spec.get("episodic", [])

    # Convert raw dicts to EpisodeMemory
    episodes = []
    for raw in raw_episodes:
        if isinstance(raw, EpisodeMemory):
            episodes.append(raw)
        else:
            episodes.append(
                EpisodeMemory(
                    session=raw.get("session", ""),
                    actions=raw.get("actions", []),
                    importance=raw.get("importance", 0.5),
                    tier=raw.get("tier", "buffer"),
                    decay_epoch=raw.get("decayEpoch", raw.get("decay_epoch", 0)),
                    access_count=raw.get("accessCount", raw.get("access_count", 0)),
                    tags=raw.get("tags", []),
                )
            )

    total_before = len(episodes)

    # 1. DECAY
    decay_rates = spec.get("decayRates", DEFAULT_DECAY_RATES)
    if not isinstance(decay_rates, dict):
        decay_rates = DEFAULT_DECAY_RATES

    cycle_result = apply_decay_cycle(episodes, decay_rates)
    retained = cycle_result.retained
    archived_episodes = cycle_result.archived

    # 2. DEDUP
    deduped = retained
    deduplicated = 0
    if consolidation.get("dedup") and embedding:
        deduped, deduplicated = await deduplicate_memories(
            deduped,
            embedding,
            consolidation.get("dedupThreshold", 0.78),
        )

    # 3-4. TRIAGE + GATE
    updated, promotions = await apply_tier_promotions(
        deduped,
        promotion_gate=consolidation.get("promotionGate", "rule-based"),
        min_confidence=consolidation.get("minConfidence", 0.7),
        llm=llm,
    )

    # 5. RECONCILE
    spec["episodic"] = [
        {
            "session": ep.session,
            "actions": ep.actions,
            "importance": ep.importance,
            "tier": ep.tier,
            "decayEpoch": ep.decay_epoch,
            "accessCount": ep.access_count,
            "tags": ep.tags,
        }
        for ep in updated
    ]
    spec["meta"] = {
        **spec.get("meta", {"lastUpdated": "", "totalSessions": 0}),
        "lastConsolidation": datetime.now(timezone.utc).isoformat(),
        "totalMemories": len(updated),
        "tierDistribution": {
            "buffer": sum(1 for e in updated if e.tier == "buffer"),
            "working": sum(1 for e in updated if e.tier == "working"),
            "core": sum(1 for e in updated if e.tier == "core"),
        },
    }

    elapsed = (time.monotonic() - start) * 1000

    return ConsolidationResult(
        total_before=total_before,
        total_after=len(updated),
        archived=len(archived_episodes),
        deduplicated=deduplicated,
        promotions=promotions,
        duration_ms=elapsed,
        timestamp=datetime.now(timezone.utc).isoformat(),
    )
