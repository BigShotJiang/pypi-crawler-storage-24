"""Manifest dataclass types -- Python mirror of the TypeScript Manifest interfaces.

All types use snake_case field names. The top-level ``Manifest`` class provides a
``from_dict`` classmethod that accepts a raw dict with camelCase keys (as read from
JSON/YAML) and recursively converts it into typed dataclasses.

Only the Kubernetes-style format is supported:

- ``apiVersion: "cockpit.io/v1"``, ``kind: "Module"``,
  ``metadata.*``, ``spec.*``
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

_CAMEL_RE = re.compile(r"(?<=[a-z0-9])([A-Z])")


def _camel_to_snake(name: str) -> str:
    """Convert a camelCase or PascalCase string to snake_case.

    Handles common patterns like:
      - ``defaultValue`` -> ``default_value``
      - ``artifactPrefix`` -> ``artifact_prefix``
      - ``typeId`` -> ``type_id``
      - ``aiEcosystem`` -> ``ai_ecosystem``
      - ``xpRewards`` -> ``xp_rewards``
      - ``colorScheme`` -> ``color_scheme``
      - ``copilotKit`` -> ``copilot_kit``

    """
    result = _CAMEL_RE.sub(r"_\1", name).lower()
    return result


def _snake_keys(d: dict[str, Any]) -> dict[str, Any]:
    """Return a shallow copy of *d* with all keys converted to snake_case."""
    return {_camel_to_snake(k): v for k, v in d.items()}


# ---------------------------------------------------------------------------
# Cross-manifest References
# ---------------------------------------------------------------------------

@dataclass
class ManifestRef:
    """Typed cross-manifest reference (Backstage-style entity link)."""

    kind: str
    name: str
    relation: str  # "dependsOn" | "uses" | "consumes" | "produces" | etc.
    description: str | None = None


@dataclass
class ManifestOwnerRef:
    """Parent-child ownership declaration (Kubernetes ownerRef pattern)."""

    kind: str
    name: str


# ---------------------------------------------------------------------------
# Journey (onboarding stages)
# ---------------------------------------------------------------------------

@dataclass
class ManifestJourneyStage:
    """A stage in the onboarding journey."""

    id: str
    reward_id: str | None = None
    icon: str | None = None


@dataclass
class ManifestJourney:
    """Journey stages for the module's onboarding flow."""

    stages: list[ManifestJourneyStage] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Telemetry Configuration
# ---------------------------------------------------------------------------

@dataclass
class ManifestTelemetryInstrument:
    """Instrumentation toggles by area."""

    agents: bool | None = None
    artifacts: bool | None = None
    hooks: bool | None = None
    rules: bool | None = None
    tools: bool | None = None
    hitl: bool | None = None


@dataclass
class ManifestTelemetry:
    """Telemetry configuration for the module."""

    enabled: bool | None = None
    service_name: str | None = None
    exporter: str | dict[str, Any] | None = None
    instrument: ManifestTelemetryInstrument | None = None
    blueprint: str | None = None


# ---------------------------------------------------------------------------
# Network
# ---------------------------------------------------------------------------

@dataclass
class ManifestNetwork:
    """Declared service ports for this module."""

    app: int | None = None
    mcp: int | None = None
    agent: int | None = None
    mock: int | None = None
    extra: dict[str, int] | None = None


# ---------------------------------------------------------------------------
# SDLC
# ---------------------------------------------------------------------------

@dataclass
class ManifestSDLCPhaseState:
    """SDLC phase state tracked per module."""

    completed_at: str | None = None
    approved_by: list[str] | None = None
    evidence: list[dict[str, str]] | None = None


@dataclass
class ManifestSDLC:
    """SDLC section in a Module manifest."""

    policy: str | None = None
    current_phase: str | None = None
    phases: dict[str, ManifestSDLCPhaseState] | None = None


# ---------------------------------------------------------------------------
# Knowledge
# ---------------------------------------------------------------------------

@dataclass
class ManifestKnowledge:
    """Knowledge taxonomy entry for Scribe."""

    kind: str
    key_pattern: str
    description: str


# ---------------------------------------------------------------------------
# HITL (Human-in-the-Loop)
# ---------------------------------------------------------------------------

@dataclass
class ManifestHITLParameter:
    """A parameter in a HITL tool's schema."""

    name: str
    type: str  # "string" | "number" | "boolean" | "enum"
    values: list[str] | None = None
    description: str | None = None
    optional: bool | None = None


@dataclass
class ManifestHITLField:
    """A UI field definition inside a HITL card."""

    name: str
    label: str
    type: str | None = None  # "text" | "textarea" | "checkbox" | "select" | "number"
    options: list[dict[str, str]] | None = None


@dataclass
class ManifestHITLTool:
    """A HITL tool definition."""

    name: str
    title: str
    description: str
    parameters: list[ManifestHITLParameter] | None = None
    ui: dict[str, Any] | None = None  # { fields?: ManifestHITLField[] }


# ---------------------------------------------------------------------------
# Health Checks
# ---------------------------------------------------------------------------

@dataclass
class ManifestHealthCheck:
    """A build-time health/governance check definition."""

    id: str
    label: str
    detail: str | None = None
    severity: str | None = None  # "error" | "warning" | "info"


# ---------------------------------------------------------------------------
# UI Config
# ---------------------------------------------------------------------------

@dataclass
class ManifestUIAgentMode:
    """Agent execution mode available in the UI switcher."""

    id: str
    label: str
    description: str


@dataclass
class ManifestUIInputMode:
    """Chat input mode entry."""

    id: str
    icon: str | None = None


@dataclass
class ManifestUISection:
    """A step/section entry in the module configurator UI."""

    id: str
    icon: str | None = None


@dataclass
class ManifestUI:
    """UI metadata section for the module."""

    agent_modes: list[ManifestUIAgentMode] | None = None
    input_modes: list[ManifestUIInputMode] | None = None
    sections: list[ManifestUISection] | None = None


# ---------------------------------------------------------------------------
# Audit
# ---------------------------------------------------------------------------

@dataclass
class ManifestAudit:
    """Audit usage data for the module."""

    collected_at: str | None = None
    unique_users: int | None = None
    sessions: int | None = None
    period_days: int | None = None
    top_skills: list[dict[str, Any]] | None = None
    top_agents: list[dict[str, Any]] | None = None
    top_artifacts: list[dict[str, Any]] | None = None
    notes: str | None = None


# ---------------------------------------------------------------------------
# Skill Suggestion
# ---------------------------------------------------------------------------

@dataclass
class ManifestSkillSuggestion:
    """Quick action pill shown in SmartInput."""

    label: str
    prompt: str


# ---------------------------------------------------------------------------
# Kubernetes-style Metadata
# ---------------------------------------------------------------------------

@dataclass
class ManifestMetadata:
    """Module identification metadata — new Kubernetes-style schema (v0.3.0+).

    Maps to the ``metadata:`` block in manifests with
    ``apiVersion: "cockpit.io/v1"``.
    """

    name: str
    display_name: str | None = None
    version: str | None = None
    description: str | None = None
    icon: str | None = None
    group: str | None = None
    route: str | None = None
    artifact_prefix: str | None = None
    annotations: dict[str, str] | None = None
    content_type_hints: dict[str, str] | None = None
    owner_ref: ManifestOwnerRef | None = None


# ---------------------------------------------------------------------------
# Access Control
# ---------------------------------------------------------------------------

@dataclass
class ManifestAccess:
    """Access control configuration."""

    roles: list[str] | None = None
    permissions: list[str] | None = None


# ---------------------------------------------------------------------------
# Personas
# ---------------------------------------------------------------------------

@dataclass
class ManifestPersonaConfig:
    """Individual persona configuration.

    ``ui`` and ``ai`` are kept as plain dicts with snake_case keys for flexibility,
    matching the TypeScript inline object types.
    """

    persona_id: str
    display_name: str
    description: str
    enabled: bool | None = None
    icon: str | None = None
    ui: dict[str, Any] | None = None
    ai: dict[str, Any] | None = None
    default_agent: str | None = None
    """The primary agent ID (spec.agents[].id) that serves this persona by default."""
    allowed_agents: list[str] | None = None
    """Agent IDs allowed for this persona. None means no restriction (all agents)."""


@dataclass
class ManifestPersonas:
    """Persona system configuration."""

    default_persona: str
    definitions: list[ManifestPersonaConfig] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Features
# ---------------------------------------------------------------------------

@dataclass
class ManifestFeatures:
    """Feature flags."""

    flags: dict[str, bool] | None = None


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

@dataclass
class ManifestAgentPlatformConfig:
    """Configuration for running an agent on the Cockpit platform via execute_agent."""

    namespace: str | None = None
    agent_id: str | None = None
    input_format: str | None = None  # "text" | "structured"


@dataclass
class ManifestAgentAzureFoundryConfig:
    """Configuration for running an agent on Azure AI Foundry (Agent Service)."""

    endpoint: str | None = None
    deployment: str | None = None
    project: str | None = None
    api_version: str | None = None
    connection_id: str | None = None


@dataclass
class ManifestAgentExecution:
    """Defines how/where an agent is executed.

    Modes:
    - ``"local"`` (default): Prompt assembled client-side (CopilotKit/LangGraph)
    - ``"platform"``: Runs on Cockpit platform via execute_agent MCP tool
    - ``"azure-foundry"``: Runs on Azure AI Foundry (Agent Service)
    """

    mode: str = "local"  # "local" | "platform" | "azure-foundry"
    platform: ManifestAgentPlatformConfig | None = None
    azure_foundry: ManifestAgentAzureFoundryConfig | None = None


@dataclass
class ManifestAgent:
    """AI agent configuration."""

    id: str
    name: str
    description: str | None = None
    instruction: str = ""
    objective: str | None = None
    persona: str | None = None
    tools: list[str] | None = None
    type_id: str | None = None
    model: str | None = None
    runtime: str = "any"
    execution: ManifestAgentExecution | None = None


@dataclass
class ManifestAgentRef:
    """Reference to a standalone Agent manifest (kind: Agent) by metadata.name."""

    name: str
    persona: str | None = None
    tools: list[str] | None = None


# ---------------------------------------------------------------------------
# Artifacts
# ---------------------------------------------------------------------------

@dataclass
class ManifestArtifact:
    """Artifact (configuration/state/content) definition."""

    key: str
    default_value: str
    description: str | None = None
    artifact_type: str | None = None
    accessibility: str | None = None
    category: str | None = None
    tags: list[str] | None = None
    persona: str | None = None


# ---------------------------------------------------------------------------
# Recognition
# ---------------------------------------------------------------------------

@dataclass
class ManifestRecognitionBadge:
    """Recognition badge definition."""

    id: str
    name: str
    description: str | None = None
    icon: str | None = None
    criteria: str | None = None


@dataclass
class ManifestRecognitionReward:
    """Recognition reward definition."""

    id: str
    name: str
    description: str | None = None
    xp: int | None = None
    value: dict[str, Any] | None = None


@dataclass
class ManifestRecognition:
    """Recognition system configuration."""

    badges: list[ManifestRecognitionBadge] | None = None
    rewards: list[ManifestRecognitionReward] | None = None


# ---------------------------------------------------------------------------
# AI Ecosystem
# ---------------------------------------------------------------------------

@dataclass
class ManifestAIEcosystem:
    """AI ecosystem metadata."""

    value_category: str | None = None
    estimated_hours_saved: float | None = None
    observation_types: list[str] | None = None


# ---------------------------------------------------------------------------
# Onboarding
# ---------------------------------------------------------------------------

@dataclass
class ManifestOnboardingStep:
    """Individual onboarding step."""

    title: str
    description: str
    action: str | None = None


@dataclass
class ManifestOnboarding:
    """Onboarding configuration."""

    welcome_message: str | None = None
    steps: list[ManifestOnboardingStep] | None = None


# ---------------------------------------------------------------------------
# Help
# ---------------------------------------------------------------------------

@dataclass
class ManifestTutorial:
    """Tutorial reference."""

    title: str
    url: str
    description: str | None = None


@dataclass
class ManifestHelp:
    """Help and documentation links."""

    documentation: str | None = None
    support: str | None = None
    tutorials: list[ManifestTutorial] | None = None


# ---------------------------------------------------------------------------
# Changelog
# ---------------------------------------------------------------------------

@dataclass
class ManifestChangelogNote:
    """Individual changelog note."""

    type: str
    summary: str
    key: str | None = None


@dataclass
class ManifestChangelog:
    """Changelog entry for a version."""

    version: str
    notes: list[ManifestChangelogNote] = field(default_factory=list)
    date: str | None = None


# ---------------------------------------------------------------------------
# Labels (used in spec.labels in new format)
# ---------------------------------------------------------------------------

@dataclass
class ManifestLabels:
    """Module labels for discovery and categorization (spec.labels)."""

    tags: list[str] | None = None
    custom: dict[str, str] | None = None


# ---------------------------------------------------------------------------
# Spec (new format, v0.3.0+)
# ---------------------------------------------------------------------------

@dataclass
class ManifestSpec:
    """The ``spec:`` block in new-format manifests (apiVersion: cockpit.io/v1).

    Groups all configuration that was previously at the top-level in the old
    ``$schema: "cockpit://manifest"`` format.
    """

    access: "ManifestAccess | None" = None
    personas: "ManifestPersonas | None" = None
    features: "ManifestFeatures | None" = None
    agents: "list[ManifestAgent] | None" = None
    agent_refs: "list[ManifestAgentRef] | None" = None
    artifacts: "list[ManifestArtifact] | None" = None
    recognition: "ManifestRecognition | None" = None
    classification: dict[str, Any] | None = None
    guardrails: dict[str, Any] | None = None
    telemetry: "ManifestTelemetry | None" = None
    governance: dict[str, Any] | None = None
    memory: dict[str, Any] | None = None
    ai_ecosystem: "ManifestAIEcosystem | None" = None
    onboarding: "ManifestOnboarding | None" = None
    help: "ManifestHelp | None" = None
    changelog: "list[ManifestChangelog] | None" = None
    i18n: "ManifestI18n | None" = None
    commands: "list[ManifestCommand] | None" = None
    skills: "list[ManifestSkill] | None" = None
    hooks: "list[ManifestHook] | None" = None
    connections: "list[ManifestConnection] | None" = None
    theme: "ManifestTheme | None" = None
    rules: "list[ManifestRule] | None" = None
    lifecycle: "ManifestLifecycle | None" = None
    labels: ManifestLabels | None = None
    audit: "ManifestAudit | None" = None
    knowledge: "list[ManifestKnowledge] | None" = None
    hitl: dict[str, Any] | None = None
    journey: "ManifestJourney | None" = None
    health: dict[str, Any] | None = None
    ui: "ManifestUI | None" = None
    network: "ManifestNetwork | None" = None
    refs: "list[ManifestRef] | None" = None
    sdlc: "ManifestSDLC | None" = None


# ---------------------------------------------------------------------------
# I18n
# ---------------------------------------------------------------------------

@dataclass
class ManifestLocaleOverrides:
    """Locale-specific overrides for various manifest sections.

    Each field is kept as a plain dict to match the flexible TypeScript inline types.
    """

    module: dict[str, Any] | None = None
    agents: dict[str, dict[str, Any]] | None = None
    personas: dict[str, dict[str, Any]] | None = None
    onboarding: dict[str, Any] | None = None
    recognition: dict[str, Any] | None = None
    commands: dict[str, dict[str, Any]] | None = None
    skills: dict[str, dict[str, Any]] | None = None
    hooks: dict[str, dict[str, Any]] | None = None
    connections: dict[str, dict[str, Any]] | None = None


@dataclass
class ManifestLocale(ManifestLocaleOverrides):
    """Locale-specific configuration including prompt pills, welcome, resources."""

    prompt_pills: list[dict[str, str]] | None = None
    welcome: dict[str, Any] | None = None
    resources: dict[str, Any] | None = None
    content: dict[str, Any] | None = None


@dataclass
class ManifestI18n:
    """Internationalization configuration."""

    default_locale: str
    locales: dict[str, ManifestLocale] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Commands
# ---------------------------------------------------------------------------

@dataclass
class ManifestCommandArg:
    """Command argument definition."""

    name: str
    type: str
    required: bool | None = None
    description: str | None = None
    default: str | None = None


@dataclass
class ManifestCommand:
    """Command definition."""

    id: str
    name: str
    description: str | None = None
    script: str | None = None
    args: list[ManifestCommandArg] | None = None
    allowed_tools: list[str] | None = None
    persona: str | None = None


# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------

@dataclass
class ManifestSkillAutoInvoke:
    """Auto-invocation configuration for a skill."""

    triggers: list[str] = field(default_factory=list)


@dataclass
class ManifestSkill:
    """Skill definition."""

    id: str
    name: str
    description: str
    instruction: str
    auto_invoke: ManifestSkillAutoInvoke | None = None
    persona: str | None = None
    references: list[str] | None = None
    examples: list[str] | None = None
    trigger: str | None = None
    stage: str | None = None
    suggestions: list[ManifestSkillSuggestion] | None = None
    ghost_triggers: dict[str, str] | None = None
    placeholder: str | None = None


# ---------------------------------------------------------------------------
# Hooks
# ---------------------------------------------------------------------------

@dataclass
class ManifestHook:
    """Lifecycle hook definition."""

    event: str
    type: str
    matcher: str | None = None
    script: str | None = None
    artifact: str | None = None
    description: str | None = None


# ---------------------------------------------------------------------------
# Connections
# ---------------------------------------------------------------------------

@dataclass
class ManifestConnection:
    """External connection definition.

    Remote connections (transport ``streamable-http`` or ``rest``) use ``url``.
    Local package connections (transport ``local``) use ``package`` instead.
    """

    id: str
    transport: str
    url: str | None = None
    package: str | None = None
    headers: dict[str, str] | None = None
    description: str | None = None


# ---------------------------------------------------------------------------
# Theme
# ---------------------------------------------------------------------------

@dataclass
class ManifestThemeColors:
    """Theme color tokens (CSS custom properties).

    Named properties use underscores in Python (e.g. ``primary_foreground``).
    Additional/custom color keys can be stored in ``extra``.
    """

    primary: str | None = None
    primary_foreground: str | None = None
    background: str | None = None
    foreground: str | None = None
    card: str | None = None
    card_foreground: str | None = None
    popover: str | None = None
    popover_foreground: str | None = None
    secondary: str | None = None
    secondary_foreground: str | None = None
    muted: str | None = None
    muted_foreground: str | None = None
    accent: str | None = None
    accent_foreground: str | None = None
    destructive: str | None = None
    destructive_foreground: str | None = None
    border: str | None = None
    input: str | None = None
    ring: str | None = None
    sidebar: str | None = None
    sidebar_foreground: str | None = None
    sidebar_primary: str | None = None
    sidebar_primary_foreground: str | None = None
    sidebar_accent: str | None = None
    sidebar_accent_foreground: str | None = None
    sidebar_border: str | None = None
    sidebar_ring: str | None = None
    extra: dict[str, str] | None = None


@dataclass
class ManifestThemePreset:
    """Theme preset definition."""

    label: str
    colors: ManifestThemeColors = field(default_factory=ManifestThemeColors)
    copilot_kit: dict[str, str] | None = None
    fonts: dict[str, str] | None = None
    logo: str | None = None
    color_scheme: str | None = None


@dataclass
class ManifestTheme:
    """Theme configuration."""

    default: str
    presets: dict[str, ManifestThemePreset] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Rules
# ---------------------------------------------------------------------------

@dataclass
class ManifestRule:
    """Declarative business rule with deterministic or semantic evaluation."""

    id: str
    name: str
    condition: str
    enforcement: str  # "block" | "redact" | "mask" | "warn" | "log"
    scope: str        # "input" | "output" | "both"
    evaluation: str   # "deterministic" | "semantic"
    category: str | None = None
    applies_to: list[str] | None = None
    message: str | None = None
    required_actions: list[str] | None = None
    hitl_if_unresolved: bool | None = None
    tags: list[str] | None = None


# ---------------------------------------------------------------------------
# Lifecycle
# ---------------------------------------------------------------------------

@dataclass
class ManifestRoadmapItem:
    """A planned or in-progress roadmap entry."""

    id: str
    title: str
    status: str    # "planned" | "in-progress" | "completed" | "cancelled"
    priority: str  # "low" | "medium" | "high" | "critical"
    description: str | None = None
    quarter: str | None = None
    owner: str | None = None
    tags: list[str] | None = None


@dataclass
class ManifestIssue:
    """A tracked issue, bug, or feature request."""

    id: str
    title: str
    type: str | None = None   # "bug" | "feature" | "improvement" | "security" | "compliance"
    status: str | None = None  # "open" | "in-progress" | "resolved" | "wontfix" | "duplicate"
    severity: str | None = None  # "low" | "medium" | "high" | "critical"
    description: str | None = None
    reported_by: str | None = None
    reported_at: str | None = None
    resolved_at: str | None = None
    related_artifact: str | None = None
    tags: list[str] | None = None


@dataclass
class ManifestDecision:
    """Architectural Decision Record (ADR)."""

    id: str
    title: str
    context: str | None = None
    decision: str | None = None
    status: str | None = None  # "accepted" | "superseded" | "deprecated"
    rationale: str | None = None
    alternatives: list[str] | None = None
    consequences: str | None = None
    decided_by: str | None = None
    decided_at: str | None = None
    superseded_by: str | None = None
    tags: list[str] | None = None


@dataclass
class ManifestLifecycle:
    """Module lifecycle: roadmap, issues, and architectural decisions."""

    roadmap: list[ManifestRoadmapItem] | None = None
    issues: list[ManifestIssue] | None = None
    decisions: list[ManifestDecision] | None = None


# ---------------------------------------------------------------------------
# Top-level Manifest
# ---------------------------------------------------------------------------

@dataclass
class Manifest:
    """Top-level Manifest dataclass.

    Only the Kubernetes-style format is supported:

    ``apiVersion: "cockpit.io/v1"``:
        Module identity goes in ``metadata``, all configuration goes in ``spec``.
    """

    api_version: str = "cockpit.io/v1"
    kind: str = "Module"
    metadata: ManifestMetadata = field(default_factory=lambda: ManifestMetadata(name=""))
    spec: ManifestSpec = field(default_factory=ManifestSpec)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Manifest:
        """Parse a raw dict (camelCase keys) into a typed ``Manifest``.

        Only accepts new-format manifests with ``apiVersion: "cockpit.io/v1"``.
        """
        api_version = data.get("apiVersion")

        if api_version != "cockpit.io/v1":
            raise ValueError(
                f'Invalid manifest: expected apiVersion "cockpit.io/v1", '
                f'got "{api_version or "(missing)"}"'
            )

        metadata_raw = data.get("metadata", {})
        spec_raw = data.get("spec", {})

        metadata = _parse_manifest_metadata(metadata_raw)
        spec = _parse_manifest_spec(spec_raw)

        return cls(
            api_version=data.get("apiVersion", "cockpit.io/v1"),
            kind=data.get("kind", "Module"),
            metadata=metadata,
            spec=spec,
        )


# ---------------------------------------------------------------------------
# Project (multi-module)
# ---------------------------------------------------------------------------

@dataclass
class ManifestProjectInfo:
    """Project-level metadata."""

    id: str
    name: str
    description: str | None = None
    version: str | None = None
    icon: str | None = None


@dataclass
class ManifestProjectModule:
    """Reference to a module within a project."""

    path: str
    id: str | None = None
    route: str | None = None
    default: bool = False
    enabled: bool = True


@dataclass
class ManifestProjectShared:
    """Shared configuration inherited by all modules in a project."""

    theme: ManifestTheme | None = None
    i18n: ManifestI18n | None = None
    access: ManifestAccess | None = None
    connections: list[ManifestConnection] | None = None


@dataclass
class ManifestProjectRouting:
    """How multiple modules are presented in the frontend."""

    type: str = "path-based"  # "path-based" | "tab-based" | "sidebar"
    default_module: str | None = None


@dataclass
class ManifestProject:
    """Project-level manifest that groups multiple modules under a single frontend.

    Lives at the app root as ``project.yaml`` or ``cockpit-project.yaml``.
    """

    schema: str = "cockpit://project/v1"
    project: ManifestProjectInfo | None = None
    modules: list[ManifestProjectModule] = field(default_factory=list)
    shared: ManifestProjectShared | None = None
    routing: ManifestProjectRouting | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ManifestProject:
        """Parse a raw dict with camelCase keys into a typed ``ManifestProject``."""
        d = _snake_keys(data)

        project_raw = d.get("project", {})
        proj_d = _snake_keys(project_raw) if project_raw else {}
        project_info = ManifestProjectInfo(
            id=proj_d["id"],
            name=proj_d["name"],
            description=proj_d.get("description"),
            version=proj_d.get("version"),
            icon=proj_d.get("icon"),
        ) if project_raw else None

        modules_raw = d.get("modules", [])
        modules = []
        for m in modules_raw:
            md = _snake_keys(m)
            modules.append(ManifestProjectModule(
                path=md["path"],
                id=md.get("id"),
                route=md.get("route"),
                default=md.get("default", False),
                enabled=md.get("enabled", True),
            ))

        shared = None
        shared_raw = d.get("shared")
        if shared_raw:
            sd = _snake_keys(shared_raw)
            shared = ManifestProjectShared(
                theme=_parse_theme(sd.get("theme")),
                i18n=_parse_i18n(sd.get("i18n")),
                access=_parse_access(sd.get("access")),
                connections=_parse_list(sd.get("connections"), _parse_connection) if sd.get("connections") else None,
            )

        routing = None
        routing_raw = d.get("routing")
        if routing_raw:
            rd = _snake_keys(routing_raw)
            routing = ManifestProjectRouting(
                type=rd.get("type", "path-based"),
                default_module=rd.get("default_module"),
            )

        return cls(
            schema=d.get("schema", "cockpit://project/v1"),
            project=project_info,
            modules=modules,
            shared=shared,
            routing=routing,
        )


@dataclass
class ManifestResolvedModule:
    """A module within a project with its full resolved Manifest."""

    id: str
    path: str
    route: str
    default: bool
    enabled: bool
    manifest: Manifest | None = None


@dataclass
class ManifestProjectResolved:
    """A resolved project with all modules scanned and merged."""

    project: ManifestProjectInfo | None = None
    modules: list[ManifestResolvedModule] = field(default_factory=list)
    shared: ManifestProjectShared | None = None
    routing: ManifestProjectRouting | None = None


# ---------------------------------------------------------------------------
# Internal parse helpers
# ---------------------------------------------------------------------------

from typing import Callable, TypeVar  # noqa: E402

_T = TypeVar("_T")


def _parse_list(
    raw: list[dict[str, Any]] | None,
    parser: Callable[[dict[str, Any]], _T],
) -> list[_T] | None:
    if raw is None:
        return None
    return [parser(item) for item in raw]


def _parse_access(raw: dict[str, Any] | None) -> ManifestAccess | None:
    if raw is None:
        return None
    return ManifestAccess(
        roles=raw.get("roles"),
        permissions=raw.get("permissions"),
    )


def _parse_persona_config(raw: dict[str, Any]) -> ManifestPersonaConfig:
    d = _snake_keys(raw)
    ui = d.get("ui")
    if ui is not None:
        ui = _snake_keys(ui)
    ai = d.get("ai")
    if ai is not None:
        ai = _snake_keys(ai)
    return ManifestPersonaConfig(
        persona_id=d["persona_id"],
        display_name=d["display_name"],
        description=d["description"],
        enabled=d.get("enabled"),
        icon=d.get("icon"),
        ui=ui,
        ai=ai,
        default_agent=d.get("default_agent"),
        allowed_agents=d.get("allowed_agents"),
    )


def _parse_personas(raw: dict[str, Any] | None) -> ManifestPersonas | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    defs = d.get("definitions", [])
    return ManifestPersonas(
        default_persona=d["default_persona"],
        definitions=[_parse_persona_config(p) for p in defs],
    )


def _parse_features(raw: dict[str, Any] | None) -> ManifestFeatures | None:
    if raw is None:
        return None
    return ManifestFeatures(flags=raw.get("flags"))


def _parse_agent_execution(raw: dict[str, Any] | None) -> ManifestAgentExecution | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    platform = None
    if d.get("platform"):
        pd = _snake_keys(d["platform"])
        platform = ManifestAgentPlatformConfig(
            namespace=pd.get("namespace"),
            agent_id=pd.get("agent_id"),
            input_format=pd.get("input_format"),
        )
    azure_foundry = None
    if d.get("azure_foundry"):
        ad = _snake_keys(d["azure_foundry"])
        azure_foundry = ManifestAgentAzureFoundryConfig(
            endpoint=ad.get("endpoint"),
            deployment=ad.get("deployment"),
            project=ad.get("project"),
            api_version=ad.get("api_version"),
            connection_id=ad.get("connection_id"),
        )
    return ManifestAgentExecution(
        mode=d.get("mode", "local"),
        platform=platform,
        azure_foundry=azure_foundry,
    )


def _parse_agent_ref(raw: dict[str, Any]) -> ManifestAgentRef:
    d = _snake_keys(raw)
    return ManifestAgentRef(
        name=d["name"],
        persona=d.get("persona"),
        tools=d.get("tools"),
    )


def _parse_agent(raw: dict[str, Any]) -> ManifestAgent:
    d = _snake_keys(raw)
    return ManifestAgent(
        id=d["id"],
        name=d["name"],
        description=d.get("description"),
        instruction=d.get("instruction", ""),
        objective=d.get("objective"),
        persona=d.get("persona"),
        tools=d.get("tools"),
        type_id=d.get("type_id"),
        model=d.get("model"),
        runtime=d.get("runtime", "any"),
        execution=_parse_agent_execution(d.get("execution")),
    )


def _parse_artifact(raw: dict[str, Any]) -> ManifestArtifact:
    d = _snake_keys(raw)
    return ManifestArtifact(
        key=d["key"],
        default_value=d["default_value"],
        description=d.get("description"),
        artifact_type=d.get("artifact_type"),
        accessibility=d.get("accessibility"),
        category=d.get("category"),
        tags=d.get("tags"),
        persona=d.get("persona"),
    )


def _parse_recognition_badge(raw: dict[str, Any]) -> ManifestRecognitionBadge:
    d = _snake_keys(raw)
    return ManifestRecognitionBadge(
        id=d["id"],
        name=d["name"],
        description=d.get("description"),
        icon=d.get("icon"),
        criteria=d.get("criteria"),
    )


def _parse_recognition_reward(raw: dict[str, Any]) -> ManifestRecognitionReward:
    d = _snake_keys(raw)
    return ManifestRecognitionReward(
        id=d["id"],
        name=d["name"],
        description=d.get("description"),
        xp=d.get("xp"),
        value=d.get("value"),
    )


def _parse_recognition(raw: dict[str, Any] | None) -> ManifestRecognition | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    return ManifestRecognition(
        badges=_parse_list(d.get("badges"), _parse_recognition_badge),
        rewards=_parse_list(d.get("rewards"), _parse_recognition_reward),
    )


def _parse_ai_ecosystem(raw: dict[str, Any] | None) -> ManifestAIEcosystem | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    return ManifestAIEcosystem(
        value_category=d.get("value_category"),
        estimated_hours_saved=d.get("estimated_hours_saved"),
        observation_types=d.get("observation_types"),
    )


def _parse_onboarding_step(raw: dict[str, Any]) -> ManifestOnboardingStep:
    d = _snake_keys(raw)
    return ManifestOnboardingStep(
        title=d["title"],
        description=d["description"],
        action=d.get("action"),
    )


def _parse_onboarding(raw: dict[str, Any] | None) -> ManifestOnboarding | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    return ManifestOnboarding(
        welcome_message=d.get("welcome_message"),
        steps=_parse_list(d.get("steps"), _parse_onboarding_step),
    )


def _parse_tutorial(raw: dict[str, Any]) -> ManifestTutorial:
    return ManifestTutorial(
        title=raw["title"],
        url=raw["url"],
        description=raw.get("description"),
    )


def _parse_help(raw: dict[str, Any] | None) -> ManifestHelp | None:
    if raw is None:
        return None
    return ManifestHelp(
        documentation=raw.get("documentation"),
        support=raw.get("support"),
        tutorials=_parse_list(raw.get("tutorials"), _parse_tutorial),
    )


def _parse_changelog_note(raw: dict[str, Any]) -> ManifestChangelogNote:
    return ManifestChangelogNote(
        type=raw["type"],
        summary=raw["summary"],
        key=raw.get("key"),
    )


def _parse_changelog(raw: dict[str, Any]) -> ManifestChangelog:
    return ManifestChangelog(
        version=raw["version"],
        notes=[_parse_changelog_note(n) for n in raw.get("notes", [])],
        date=raw.get("date"),
    )


def _parse_manifest_metadata(raw: dict[str, Any]) -> ManifestMetadata:
    """Parse the ``metadata:`` block in new-format manifests."""
    d = _snake_keys(raw)
    owner_ref_raw = d.get("owner_ref")
    owner_ref = None
    if owner_ref_raw and isinstance(owner_ref_raw, dict):
        owner_ref = ManifestOwnerRef(kind=owner_ref_raw["kind"], name=owner_ref_raw["name"])
    return ManifestMetadata(
        name=d.get("name", ""),
        display_name=d.get("display_name"),
        version=d.get("version"),
        description=d.get("description"),
        icon=d.get("icon"),
        group=d.get("group"),
        route=d.get("route"),
        artifact_prefix=d.get("artifact_prefix"),
        annotations=d.get("annotations"),
        content_type_hints=d.get("content_type_hints"),
        owner_ref=owner_ref,
    )


def _parse_manifest_spec(raw: dict[str, Any]) -> ManifestSpec:
    """Parse the ``spec:`` block in new-format manifests."""
    d = _snake_keys(raw)
    # Parse labels sub-block
    labels_raw = d.get("labels")
    labels = None
    if labels_raw is not None:
        ld = _snake_keys(labels_raw) if isinstance(labels_raw, dict) else {}
        labels = ManifestLabels(
            tags=ld.get("tags"),
            custom=ld.get("custom"),
        )

    return ManifestSpec(
        access=_parse_access(d.get("access")),
        personas=_parse_personas(d.get("personas")),
        features=_parse_features(d.get("features")),
        agents=_parse_list(d.get("agents"), _parse_agent),
        agent_refs=_parse_list(d.get("agentRefs"), _parse_agent_ref),
        artifacts=_parse_list(d.get("artifacts"), _parse_artifact),
        recognition=_parse_recognition(d.get("recognition")),
        classification=d.get("classification"),
        guardrails=d.get("guardrails"),
        telemetry=_parse_telemetry(d.get("telemetry")),
        governance=d.get("governance"),
        memory=d.get("memory"),
        ai_ecosystem=_parse_ai_ecosystem(d.get("ai_ecosystem")),
        onboarding=_parse_onboarding(d.get("onboarding")),
        help=_parse_help(d.get("help")),
        changelog=_parse_list(d.get("changelog"), _parse_changelog),
        i18n=_parse_i18n(d.get("i18n")),
        commands=_parse_list(d.get("commands"), _parse_command),
        skills=_parse_list(d.get("skills"), _parse_skill),
        hooks=_parse_list(d.get("hooks"), _parse_hook),
        connections=_parse_list(d.get("connections"), _parse_connection),
        theme=_parse_theme(d.get("theme")),
        rules=_parse_list(d.get("rules"), _parse_rule),
        lifecycle=_parse_lifecycle(d.get("lifecycle")),
        labels=labels,
        audit=_parse_audit(d.get("audit")),
        knowledge=_parse_list(d.get("knowledge"), _parse_knowledge),
        hitl=d.get("hitl"),
        journey=_parse_journey(d.get("journey")),
        health=d.get("health"),
        ui=_parse_ui(d.get("ui")),
        network=_parse_network(d.get("network")),
        refs=_parse_list(d.get("refs"), _parse_ref),
        sdlc=_parse_sdlc(d.get("sdlc")),
    )


def _parse_locale(raw: dict[str, Any]) -> ManifestLocale:
    """Parse a single locale entry.

    The TypeScript ``ManifestLocale`` extends ``ManifestLocaleOverrides`` and adds
    ``prompt-pills``, ``welcome``, ``resources``, ``content``. The ``prompt-pills`` key
    uses a hyphen in JSON/YAML, so we handle that explicitly.
    """
    d = _snake_keys(raw)
    # prompt-pills comes through as prompt_pills after _snake_keys (hyphen is kept)
    # but the raw key is "prompt-pills", so handle both
    prompt_pills = raw.get("prompt-pills") or d.get("prompt_pills")

    return ManifestLocale(
        module=d.get("module"),
        agents=d.get("agents"),
        personas=d.get("personas"),
        onboarding=d.get("onboarding"),
        recognition=d.get("recognition"),
        commands=d.get("commands"),
        skills=d.get("skills"),
        hooks=d.get("hooks"),
        connections=d.get("connections"),
        prompt_pills=prompt_pills,
        welcome=d.get("welcome"),
        resources=d.get("resources"),
        content=d.get("content"),
    )


def _parse_i18n(raw: dict[str, Any] | None) -> ManifestI18n | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    locales_raw: dict[str, Any] = d.get("locales", {})
    locales = {code: _parse_locale(loc) for code, loc in locales_raw.items()}
    return ManifestI18n(
        default_locale=d["default_locale"],
        locales=locales,
    )


def _parse_command_arg(raw: dict[str, Any]) -> ManifestCommandArg:
    return ManifestCommandArg(
        name=raw["name"],
        type=raw["type"],
        required=raw.get("required"),
        description=raw.get("description"),
        default=raw.get("default"),
    )


def _parse_command(raw: dict[str, Any]) -> ManifestCommand:
    d = _snake_keys(raw)
    return ManifestCommand(
        id=d["id"],
        name=d["name"],
        description=d.get("description"),
        script=d.get("script"),
        args=_parse_list(d.get("args"), _parse_command_arg),
        allowed_tools=d.get("allowed_tools"),
        persona=d.get("persona"),
    )


def _parse_skill_auto_invoke(raw: dict[str, Any]) -> ManifestSkillAutoInvoke:
    return ManifestSkillAutoInvoke(triggers=raw.get("triggers", []))


def _parse_skill_suggestion(raw: dict[str, Any]) -> ManifestSkillSuggestion:
    return ManifestSkillSuggestion(label=raw["label"], prompt=raw["prompt"])


def _parse_skill(raw: dict[str, Any]) -> ManifestSkill:
    d = _snake_keys(raw)
    auto_invoke = d.get("auto_invoke")
    return ManifestSkill(
        id=d["id"],
        name=d["name"],
        description=d["description"],
        instruction=d["instruction"],
        auto_invoke=_parse_skill_auto_invoke(auto_invoke) if auto_invoke else None,
        persona=d.get("persona"),
        references=d.get("references"),
        examples=d.get("examples"),
        trigger=d.get("trigger"),
        stage=d.get("stage"),
        suggestions=_parse_list(d.get("suggestions"), _parse_skill_suggestion),
        ghost_triggers=d.get("ghost_triggers"),
        placeholder=d.get("placeholder"),
    )


def _parse_hook(raw: dict[str, Any]) -> ManifestHook:
    return ManifestHook(
        event=raw["event"],
        type=raw["type"],
        matcher=raw.get("matcher"),
        script=raw.get("script"),
        artifact=raw.get("artifact"),
        description=raw.get("description"),
    )


def _parse_connection(raw: dict[str, Any]) -> ManifestConnection:
    return ManifestConnection(
        id=raw["id"],
        transport=raw["transport"],
        url=raw.get("url"),
        package=raw.get("package"),
        headers=raw.get("headers"),
        description=raw.get("description"),
    )


# Known ThemeColors field names that map from hyphenated CSS keys to snake_case
_THEME_COLORS_FIELDS: dict[str, str] = {
    "primary": "primary",
    "primary-foreground": "primary_foreground",
    "background": "background",
    "foreground": "foreground",
    "card": "card",
    "card-foreground": "card_foreground",
    "popover": "popover",
    "popover-foreground": "popover_foreground",
    "secondary": "secondary",
    "secondary-foreground": "secondary_foreground",
    "muted": "muted",
    "muted-foreground": "muted_foreground",
    "accent": "accent",
    "accent-foreground": "accent_foreground",
    "destructive": "destructive",
    "destructive-foreground": "destructive_foreground",
    "border": "border",
    "input": "input",
    "ring": "ring",
    "sidebar": "sidebar",
    "sidebar-foreground": "sidebar_foreground",
    "sidebar-primary": "sidebar_primary",
    "sidebar-primary-foreground": "sidebar_primary_foreground",
    "sidebar-accent": "sidebar_accent",
    "sidebar-accent-foreground": "sidebar_accent_foreground",
    "sidebar-border": "sidebar_border",
    "sidebar-ring": "sidebar_ring",
}


def _parse_theme_colors(raw: dict[str, Any]) -> ManifestThemeColors:
    kwargs: dict[str, Any] = {}
    extra: dict[str, str] = {}
    for key, value in raw.items():
        snake = _THEME_COLORS_FIELDS.get(key)
        if snake is not None:
            kwargs[snake] = value
        else:
            extra[key] = value
    if extra:
        kwargs["extra"] = extra
    return ManifestThemeColors(**kwargs)


def _parse_theme_preset(raw: dict[str, Any]) -> ManifestThemePreset:
    d = _snake_keys(raw)
    colors_raw = d.get("colors", {})
    return ManifestThemePreset(
        label=d["label"],
        colors=_parse_theme_colors(colors_raw),
        copilot_kit=d.get("copilot_kit"),
        fonts=d.get("fonts"),
        logo=d.get("logo"),
        color_scheme=d.get("color_scheme"),
    )


def _parse_theme(raw: dict[str, Any] | None) -> ManifestTheme | None:
    if raw is None:
        return None
    presets_raw: dict[str, Any] = raw.get("presets", {})
    return ManifestTheme(
        default=raw["default"],
        presets={name: _parse_theme_preset(p) for name, p in presets_raw.items()},
    )


def _parse_rule(raw: dict[str, Any]) -> ManifestRule:
    d = _snake_keys(raw)
    return ManifestRule(
        id=d["id"],
        name=d["name"],
        condition=d["condition"],
        enforcement=d["enforcement"],
        scope=d["scope"],
        evaluation=d["evaluation"],
        category=d.get("category"),
        applies_to=d.get("applies_to"),
        message=d.get("message"),
        required_actions=d.get("required_actions"),
        hitl_if_unresolved=d.get("hitl_if_unresolved"),
        tags=d.get("tags"),
    )


def _parse_roadmap_item(raw: dict[str, Any]) -> ManifestRoadmapItem:
    d = _snake_keys(raw)
    return ManifestRoadmapItem(
        id=d["id"],
        title=d["title"],
        status=d["status"],
        priority=d["priority"],
        description=d.get("description"),
        quarter=d.get("quarter"),
        owner=d.get("owner"),
        tags=d.get("tags"),
    )


def _parse_issue(raw: dict[str, Any]) -> ManifestIssue:
    d = _snake_keys(raw)
    return ManifestIssue(
        id=d["id"],
        title=d["title"],
        type=d.get("type"),
        status=d.get("status"),
        severity=d.get("severity"),
        description=d.get("description"),
        reported_by=d.get("reported_by"),
        reported_at=d.get("reported_at"),
        resolved_at=d.get("resolved_at"),
        related_artifact=d.get("related_artifact"),
        tags=d.get("tags"),
    )


def _parse_decision(raw: dict[str, Any]) -> ManifestDecision:
    d = _snake_keys(raw)
    return ManifestDecision(
        id=d["id"],
        title=d["title"],
        context=d.get("context"),
        decision=d.get("decision"),
        status=d.get("status"),
        rationale=d.get("rationale"),
        alternatives=d.get("alternatives"),
        consequences=d.get("consequences"),
        decided_by=d.get("decided_by"),
        decided_at=d.get("decided_at"),
        superseded_by=d.get("superseded_by"),
        tags=d.get("tags"),
    )


def _parse_lifecycle(raw: dict[str, Any] | None) -> ManifestLifecycle | None:
    if raw is None:
        return None
    return ManifestLifecycle(
        roadmap=_parse_list(raw.get("roadmap"), _parse_roadmap_item),
        issues=_parse_list(raw.get("issues"), _parse_issue),
        decisions=_parse_list(raw.get("decisions"), _parse_decision),
    )


# ---------------------------------------------------------------------------
# Parsers for new Phase-4.8+ types
# ---------------------------------------------------------------------------


def _parse_ref(raw: dict[str, Any]) -> ManifestRef:
    return ManifestRef(
        kind=raw["kind"],
        name=raw["name"],
        relation=raw["relation"],
        description=raw.get("description"),
    )


def _parse_journey_stage(raw: dict[str, Any]) -> ManifestJourneyStage:
    d = _snake_keys(raw)
    return ManifestJourneyStage(
        id=d["id"],
        reward_id=d.get("reward_id"),
        icon=d.get("icon"),
    )


def _parse_journey(raw: dict[str, Any] | None) -> ManifestJourney | None:
    if raw is None:
        return None
    return ManifestJourney(
        stages=_parse_list(raw.get("stages"), _parse_journey_stage),
    )


def _parse_telemetry_instrument(raw: dict[str, Any]) -> ManifestTelemetryInstrument:
    return ManifestTelemetryInstrument(
        agents=raw.get("agents"),
        artifacts=raw.get("artifacts"),
        hooks=raw.get("hooks"),
        rules=raw.get("rules"),
        tools=raw.get("tools"),
        hitl=raw.get("hitl"),
    )


def _parse_telemetry(raw: dict[str, Any] | None) -> ManifestTelemetry | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    inst_raw = d.get("instrument")
    return ManifestTelemetry(
        enabled=d.get("enabled"),
        service_name=d.get("service_name"),
        exporter=d.get("exporter"),
        instrument=_parse_telemetry_instrument(inst_raw) if inst_raw else None,
        blueprint=d.get("blueprint"),
    )


def _parse_network(raw: dict[str, Any] | None) -> ManifestNetwork | None:
    if raw is None:
        return None
    return ManifestNetwork(
        app=raw.get("app"),
        mcp=raw.get("mcp"),
        agent=raw.get("agent"),
        mock=raw.get("mock"),
        extra=raw.get("extra"),
    )


def _parse_sdlc_phase_state(raw: dict[str, Any]) -> ManifestSDLCPhaseState:
    d = _snake_keys(raw)
    return ManifestSDLCPhaseState(
        completed_at=d.get("completed_at"),
        approved_by=d.get("approved_by"),
        evidence=d.get("evidence"),
    )


def _parse_sdlc(raw: dict[str, Any] | None) -> ManifestSDLC | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    phases_raw = d.get("phases")
    phases = None
    if isinstance(phases_raw, dict):
        phases = {k: _parse_sdlc_phase_state(v) for k, v in phases_raw.items()}
    return ManifestSDLC(
        policy=d.get("policy"),
        current_phase=d.get("current_phase"),
        phases=phases,
    )


def _parse_knowledge(raw: dict[str, Any]) -> ManifestKnowledge:
    d = _snake_keys(raw)
    return ManifestKnowledge(
        kind=d["kind"],
        key_pattern=d["key_pattern"],
        description=d["description"],
    )


def _parse_hitl_parameter(raw: dict[str, Any]) -> ManifestHITLParameter:
    return ManifestHITLParameter(
        name=raw["name"],
        type=raw["type"],
        values=raw.get("values"),
        description=raw.get("description"),
        optional=raw.get("optional"),
    )


def _parse_hitl_field(raw: dict[str, Any]) -> ManifestHITLField:
    return ManifestHITLField(
        name=raw["name"],
        label=raw["label"],
        type=raw.get("type"),
        options=raw.get("options"),
    )


def _parse_hitl_tool(raw: dict[str, Any]) -> ManifestHITLTool:
    d = _snake_keys(raw)
    ui_raw = d.get("ui")
    ui = None
    if ui_raw and isinstance(ui_raw, dict) and "fields" in ui_raw:
        ui = {"fields": [_parse_hitl_field(f) for f in ui_raw["fields"]]}
    elif ui_raw:
        ui = ui_raw
    return ManifestHITLTool(
        name=d["name"],
        title=d["title"],
        description=d["description"],
        parameters=_parse_list(d.get("parameters"), _parse_hitl_parameter),
        ui=ui,
    )


def _parse_health_check(raw: dict[str, Any]) -> ManifestHealthCheck:
    return ManifestHealthCheck(
        id=raw["id"],
        label=raw["label"],
        detail=raw.get("detail"),
        severity=raw.get("severity"),
    )


def _parse_ui_agent_mode(raw: dict[str, Any]) -> ManifestUIAgentMode:
    return ManifestUIAgentMode(
        id=raw["id"],
        label=raw["label"],
        description=raw["description"],
    )


def _parse_ui_input_mode(raw: dict[str, Any]) -> ManifestUIInputMode:
    return ManifestUIInputMode(
        id=raw["id"],
        icon=raw.get("icon"),
    )


def _parse_ui_section(raw: dict[str, Any]) -> ManifestUISection:
    return ManifestUISection(
        id=raw["id"],
        icon=raw.get("icon"),
    )


def _parse_ui(raw: dict[str, Any] | None) -> ManifestUI | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    return ManifestUI(
        agent_modes=_parse_list(d.get("agent_modes"), _parse_ui_agent_mode),
        input_modes=_parse_list(d.get("input_modes"), _parse_ui_input_mode),
        sections=_parse_list(d.get("sections"), _parse_ui_section),
    )


def _parse_audit(raw: dict[str, Any] | None) -> ManifestAudit | None:
    if raw is None:
        return None
    d = _snake_keys(raw)
    return ManifestAudit(
        collected_at=d.get("collected_at"),
        unique_users=d.get("unique_users"),
        sessions=d.get("sessions"),
        period_days=d.get("period_days"),
        top_skills=d.get("top_skills"),
        top_agents=d.get("top_agents"),
        top_artifacts=d.get("top_artifacts"),
        notes=d.get("notes"),
    )
