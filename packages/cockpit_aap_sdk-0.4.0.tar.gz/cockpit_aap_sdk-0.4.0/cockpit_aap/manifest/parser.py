"""Parse YAML strings into Manifest dataclasses.

Supports the new schema format:

- ``apiVersion: "cockpit.io/v1"``, ``kind: Module``,
  ``metadata.*``, ``spec.*``
"""

import yaml

from .types import Manifest

EXPECTED_API_VERSION = "cockpit.io/v1"
EXPECTED_KIND = "Module"


def parse_manifest(yaml_content: str) -> Manifest:
    """Parse a YAML string into a Manifest dataclass.

    Expects the new format with ``apiVersion: "cockpit.io/v1"``.
    Validates that ``metadata.name`` is present.

    Raises
    ------
    ValueError
        If the YAML is not a mapping, if the apiVersion is missing or
        wrong, or if required identity fields are absent.
    """
    raw = yaml.safe_load(yaml_content)
    if not isinstance(raw, dict):
        raise ValueError("Manifest YAML must be a mapping")

    api_version = raw.get("apiVersion")

    if api_version == EXPECTED_API_VERSION:
        return _parse_new_format(raw)

    # Not the expected format
    if api_version is not None:
        raise ValueError(
            f"Invalid manifest: expected apiVersion \"{EXPECTED_API_VERSION}\", "
            f"got \"{api_version}\""
        )
    raise ValueError(
        f"Invalid manifest: must have apiVersion \"{EXPECTED_API_VERSION}\""
    )


def _parse_new_format(raw: dict) -> Manifest:
    """Validate and parse a new-format manifest (apiVersion: cockpit.io/v1)."""
    kind = raw.get("kind")
    if kind != EXPECTED_KIND:
        raise ValueError(
            f"Invalid manifest: expected kind \"{EXPECTED_KIND}\", got \"{kind}\""
        )

    metadata = raw.get("metadata", {})
    if not metadata.get("name"):
        raise ValueError("metadata.name is required")

    return Manifest.from_dict(raw)
