"""Front matter parser for UtilityAgent instruction files."""
from __future__ import annotations

import re

import yaml

_FRONT_MATTER_RE = re.compile(r"^---[ \t]*\n(.*?)---[ \t]*\n", re.DOTALL)


def parse_front_matter(content: str) -> dict:
    """Parse YAML front matter from a markdown/instruction string.

    Returns a dict with:
        - ``metadata``: parsed YAML front matter as dict (or empty dict)
        - ``instruction``: the body text after the front matter block
        - ``has_front_matter``: True if a valid front matter block was found
    """
    match = _FRONT_MATTER_RE.match(content)
    if not match:
        return {"metadata": {}, "instruction": content.strip(), "has_front_matter": False}
    yaml_block = match.group(1)
    instruction = content[match.end():].strip()
    try:
        parsed = yaml.safe_load(yaml_block)
        metadata = parsed if isinstance(parsed, dict) else {}
        return {"metadata": metadata, "instruction": instruction, "has_front_matter": True}
    except yaml.YAMLError:
        return {"metadata": {}, "instruction": content.strip(), "has_front_matter": False}
