"""Deterministic rule engine for Manifest business rules.

Uses simpleeval to parse and evaluate human-readable condition strings
with zero LLM involvement -- microsecond latency, 100% deterministic.

Enforcement levels:
- block: Hard stop -- sets allowed=False. ONLY with evaluation:deterministic.
- redact: Mark content for removal -- does NOT set allowed=False.
- mask: Mark content for masking -- does NOT set allowed=False.
- warn: Non-blocking violation (still appears in violations list).
- log: Silent -- not added to violations list.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

try:
    from simpleeval import simple_eval, InvalidExpression, NameNotDefined
except ImportError as exc:
    raise ImportError(
        "simpleeval is required for the rule engine. Install it: pip install simpleeval"
    ) from exc

from .types import Manifest, ManifestRule


# ---------------------------------------------------------------------------
# Output types
# ---------------------------------------------------------------------------

@dataclass
class RuleViolation:
    """A single rule violation."""

    rule_id: str
    rule_name: str
    enforcement: str  # block | redact | mask | warn | log
    message: str
    required_actions: list[str] = field(default_factory=list)
    hitl_required: bool = False


@dataclass
class ValidationResult:
    """Result of evaluating all applicable rules."""

    allowed: bool  # False only when at least one block rule fires
    violations: list[RuleViolation] = field(default_factory=list)
    required_actions: list[str] = field(default_factory=list)
    hitl_required: bool = False


# ---------------------------------------------------------------------------
# Compile-time validation
# ---------------------------------------------------------------------------

def compile_manifest_rules(manifest: Manifest) -> None:
    """Pre-validate all deterministic rule conditions at bootstrap time.

    Only validates rules with evaluation="deterministic" -- semantic rules
    use natural language and must not be parsed by simpleeval.

    Raises ValueError if any deterministic condition fails to parse.
    """
    for rule in manifest.spec.rules or []:
        if rule.enforcement == "block" and rule.evaluation == "semantic":
            raise ValueError(
                f'Rule "{rule.id}": enforcement "block" requires evaluation "deterministic". '
                "Semantic/LLM evaluation is non-deterministic and unsafe for blocking."
            )
        if rule.evaluation != "deterministic":
            continue
        try:
            # Evaluate with empty names to check syntax only.
            # KeyError/NameError are expected (variables not in scope yet).
            simple_eval(rule.condition, names={})
        except (KeyError, NameError, AttributeError, NameNotDefined):
            # Variable lookup failures are expected at compile time
            pass
        except (InvalidExpression, SyntaxError, TypeError, ValueError) as exc:
            raise ValueError(
                f'Rule "{rule.id}" has invalid condition expression '
                f'"{rule.condition}": {exc}'
            ) from exc


# ---------------------------------------------------------------------------
# Runtime validation
# ---------------------------------------------------------------------------

def validate_rules(
    manifest: Manifest,
    scope: str,
    context: dict[str, Any],
    agent_id: str | None = None,
) -> ValidationResult:
    """Evaluate all applicable rules for the given scope and context.

    Args:
        manifest: The module manifest containing rules.
        scope: "input" (before agent) or "output" (after agent).
        context: Key-value map of variables available in conditions.
        agent_id: Optional agent ID to filter rules by applies_to.

    Returns:
        ValidationResult with allowed status, violations, and required actions.
    """
    all_rules = manifest.spec.rules or []

    # Filter by scope (includes rules with scope="both")
    scoped = [r for r in all_rules if r.scope == scope or r.scope == "both"]

    # Filter by agent
    if agent_id is not None:
        scoped = [
            r for r in scoped
            if not r.applies_to or agent_id in r.applies_to
        ]

    # Only evaluate deterministic rules
    deterministic = [r for r in scoped if r.evaluation == "deterministic"]

    violations: list[RuleViolation] = []
    allowed = True

    for rule in deterministic:
        if not _evaluate_condition(rule.condition, context):
            continue

        # Rule fires
        if rule.enforcement == "log":
            continue  # Silent -- not added to violations

        violation = RuleViolation(
            rule_id=rule.id,
            rule_name=rule.name,
            enforcement=rule.enforcement,
            message=rule.message or f'Rule "{rule.name}" violated',
            required_actions=rule.required_actions or [],
            hitl_required=rule.hitl_if_unresolved or False,
        )
        violations.append(violation)

        if rule.enforcement == "block":
            allowed = False

    # Deduplicate required_actions (preserve order)
    seen: set[str] = set()
    required_actions: list[str] = []
    for v in violations:
        for action in v.required_actions:
            if action not in seen:
                seen.add(action)
                required_actions.append(action)

    hitl_required = any(v.hitl_required for v in violations)

    return ValidationResult(
        allowed=allowed,
        violations=violations,
        required_actions=required_actions,
        hitl_required=hitl_required,
    )


def _evaluate_condition(condition: str, context: dict[str, Any]) -> bool:
    """Safely evaluate a condition string with the given context variables.

    Returns False (not True) on any error -- missing variables, type errors, etc.
    This is the safe default: if we can't evaluate, don't fire the rule.
    """
    try:
        result = simple_eval(condition, names=context)
        return bool(result)
    except (KeyError, NameError, AttributeError, NameNotDefined):
        # Variable referenced in condition not in context -- condition not met
        return False
    except (InvalidExpression, SyntaxError, TypeError, ValueError, Exception):
        # Any evaluation error at runtime means condition not met.
        # Unlike compile_manifest_rules(), we never raise here -- caller must
        # not be interrupted by rule evaluation failures.
        return False
