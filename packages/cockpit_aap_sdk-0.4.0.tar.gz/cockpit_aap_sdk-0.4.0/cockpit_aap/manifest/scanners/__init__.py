"""Bulk registration of all 34 non-Module built-in kinds.

Importing this package is a **side-effect** that populates
:data:`cockpit_aap.manifest.kind_registry.kind_registry` with every
kind that has a TypeScript scanner counterpart in
``packages/bootstrap/src/manifest/*-scanner.ts``.

Design:
  * Data-driven — field lists live in :mod:`._definitions`.
  * A generic ``parse_fn`` is created for every kind that supports parsing
    (the TS scanner has a dedicated ``parse*Yaml()``). The generic parser
    just runs ``yaml.safe_load`` + validates ``kind``/``apiVersion``.
  * A per-kind ``scan_fn`` is created that mirrors the TS scanner:
    - Validates ``apiVersion`` and ``kind`` strictly
    - Resolves ``file_ref_fields`` via ``resolve_ref()``
    - Resolves ``json_ref_fields`` via ``resolve_json_ref()``
    - Runs ``validators`` (e.g. ``non_empty_array``)
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import yaml

from cockpit_aap.manifest.kind_registry import (
    KindFieldSchema,
    kind_registry,
)
from cockpit_aap.manifest.resolve_ref import resolve_ref, resolve_json_ref
from cockpit_aap.manifest.scanners._definitions import BUILTIN_KIND_DEFINITIONS


# ── Generic parse_fn factory ──────────────────────────────────────────────────


def _make_parse_fn(kind: str, expected_api_version: str):
    """Return a parse_fn that ``yaml.safe_load``s + validates ``kind`` & ``apiVersion``."""

    def _parse(yaml_content: str) -> dict[str, Any]:
        data = yaml.safe_load(yaml_content)
        if not isinstance(data, dict):
            raise ValueError(f"Expected YAML mapping for kind={kind}, got {type(data).__name__}")

        actual_kind = data.get("kind")
        if actual_kind and actual_kind != kind:
            raise ValueError(
                f"Kind mismatch: expected '{kind}', got '{actual_kind}'"
            )

        actual_api = data.get("apiVersion")
        if actual_api and actual_api != expected_api_version:
            raise ValueError(
                f"apiVersion mismatch for kind={kind}: "
                f"expected '{expected_api_version}', got '{actual_api}'"
            )

        return data

    _parse.__qualname__ = f"parse_{kind.lower()}_yaml"
    _parse.__name__ = f"parse_{kind.lower()}_yaml"
    return _parse


# ── Nested path resolution helpers ────────────────────────────────────────────


def _get_nested(obj: dict[str, Any], dotpath: str) -> Any:
    """Get a value from a nested dict using dot notation (supports ``[]`` for arrays)."""
    parts = dotpath.split(".")
    current: Any = obj
    for part in parts:
        if part.endswith("[]"):
            part = part[:-2]
            if isinstance(current, dict):
                current = current.get(part, [])
            else:
                return None
            if not isinstance(current, list):
                return None
            return current  # return the list for the caller to iterate
        if isinstance(current, dict):
            current = current.get(part)
        else:
            return None
    return current


def _set_nested(obj: dict[str, Any], dotpath: str, value: Any) -> None:
    """Set a value in a nested dict using dot notation."""
    parts = dotpath.split(".")
    current = obj
    for part in parts[:-1]:
        if isinstance(current, dict):
            current = current.setdefault(part, {})
        else:
            return
    if isinstance(current, dict):
        current[parts[-1]] = value


def _resolve_field_refs(
    data: dict[str, Any],
    base_dir: str,
    file_ref_fields: list[str],
    json_ref_fields: list[str],
) -> None:
    """Resolve specific fields (by dot-path) in a manifest dict.

    This mirrors the TS scanner approach where each scanner resolves
    known fields rather than walking the entire tree generically.

    Supports:
    - Simple paths: ``spec.instruction``
    - Array element paths: ``spec.examples[].outputRef`` — resolves each item's field
    - Nested array paths: ``spec.evals.iterations[].benchmark``
    """
    for field_path in file_ref_fields:
        _resolve_path(data, base_dir, field_path, resolve_ref)

    for field_path in json_ref_fields:
        _resolve_path(data, base_dir, field_path, resolve_json_ref)


def _resolve_path(
    data: dict[str, Any],
    base_dir: str,
    field_path: str,
    resolve_fn,
) -> None:
    """Resolve a single dot-path field in the data dict."""
    # Handle array paths like "spec.examples[].outputRef"
    if "[]." in field_path:
        before, after = field_path.split("[].", 1)
        array = _get_nested(data, before + "[]")
        if isinstance(array, list):
            for item in array:
                if isinstance(item, dict):
                    _resolve_path(item, base_dir, after, resolve_fn)
        return

    value = _get_nested(data, field_path)
    if isinstance(value, str):
        resolved = resolve_fn(value, base_dir)
        _set_nested(data, field_path, resolved)


# ── Validators ────────────────────────────────────────────────────────────────


def _run_validators(
    data: dict[str, Any],
    validators: list[dict[str, str]],
    kind: str,
) -> None:
    """Run business-rule validators on a manifest dict.

    Supported rules:
    - ``non_empty_array``: field must be a non-empty list
    """
    for v in validators:
        field = v.get("field", "")
        rule = v.get("rule", "")

        value = _get_nested(data, field)

        if rule == "non_empty_array":
            if not isinstance(value, list) or len(value) == 0:
                raise ValueError(
                    f"Validation failed for kind={kind}: "
                    f"'{field}' must be a non-empty array"
                )


# ── Generic scan_fn factory ──────────────────────────────────────────────────


def _make_scan_fn(
    kind: str,
    expected_api_version: str,
    file_ref_fields: list[str] | None = None,
    json_ref_fields: list[str] | None = None,
    validators: list[dict[str, str]] | None = None,
):
    """Return a scan_fn that reads manifest.yaml, validates, and resolves refs."""

    _file_ref_fields = file_ref_fields or []
    _json_ref_fields = json_ref_fields or []
    _validators = validators or []

    def _scan(directory: str) -> dict[str, Any]:
        abs_dir = os.path.realpath(directory)
        manifest_file = os.path.join(abs_dir, "manifest.yaml")

        if not os.path.isfile(manifest_file):
            raise FileNotFoundError(f"No manifest.yaml found in {abs_dir}")

        with open(manifest_file, encoding="utf-8") as fh:
            data: dict[str, Any] = yaml.safe_load(fh)

        if not isinstance(data, dict):
            raise ValueError(
                f"Expected YAML mapping for kind={kind}, got {type(data).__name__}"
            )

        # Validate kind
        actual_kind = data.get("kind")
        if actual_kind != kind:
            raise ValueError(
                f"Kind mismatch in {manifest_file}: expected '{kind}', got '{actual_kind}'"
            )

        # Validate apiVersion
        actual_api = data.get("apiVersion")
        if actual_api != expected_api_version:
            raise ValueError(
                f"apiVersion mismatch in {manifest_file} for kind={kind}: "
                f"expected '{expected_api_version}', got '{actual_api}'"
            )

        # Run business validators
        if _validators:
            _run_validators(data, _validators, kind)

        # Resolve file references on specific fields
        if _file_ref_fields or _json_ref_fields:
            _resolve_field_refs(data, abs_dir, _file_ref_fields, _json_ref_fields)

        return data

    _scan.__qualname__ = f"scan_{kind.lower()}_manifest"
    _scan.__name__ = f"scan_{kind.lower()}_manifest"
    return _scan


# ── Bulk registration ─────────────────────────────────────────────────────────


def _register_all() -> None:
    """Convert raw definition dicts into ``KindFieldSchema`` and register."""
    for defn in BUILTIN_KIND_DEFINITIONS:
        kind_name: str = defn["kind"]
        api_version: str = defn["api_version"]

        # Skip if already registered (e.g. Module, or a user-registered override)
        if kind_registry.is_registered(kind_name):
            continue

        fields = [
            KindFieldSchema(
                path=f["path"],
                type=f["type"],
                description=f.get("description"),
                required=f.get("required", False),
                enum=f.get("enum"),
                content_type=f.get("content_type"),
                kind_ref=f.get("kind_ref"),
            )
            for f in defn.get("fields", [])
        ]

        parse_fn = _make_parse_fn(kind_name, api_version) if defn.get("has_parse") else None

        # Create a per-kind scan_fn with field-specific resolution + validation
        scan_fn = _make_scan_fn(
            kind_name,
            api_version,
            file_ref_fields=defn.get("file_ref_fields"),
            json_ref_fields=defn.get("json_ref_fields"),
            validators=defn.get("validators"),
        )

        kind_registry.register(
            kind_name,
            api_version=api_version,
            description=defn.get("description", ""),
            fields=fields,
            scan_fn=scan_fn,
            parse_fn=parse_fn,
            sample=defn.get("sample"),
        )


_register_all()
