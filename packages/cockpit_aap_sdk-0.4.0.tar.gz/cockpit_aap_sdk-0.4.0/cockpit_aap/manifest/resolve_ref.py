"""Shared file-reference resolution for all kind scanners.

Equivalent of ``packages/bootstrap/src/manifest/resolve-ref.ts``.

All non-Module scanners use ``resolve_ref()`` (and optionally ``resolve_json_ref()``)
to inline file references (paths ending in ``.md``, ``.txt``, ``.json``, etc.) found
in manifest YAML values.

The Module-specific scanner in ``scanner.py`` has its own private ``_resolve_ref``
that is functionally identical — kept for backward compatibility.  New scanners
should import from this module.
"""

from __future__ import annotations

import json
import os
from pathlib import Path

_FILE_EXTENSIONS = frozenset({
    ".md", ".txt", ".json", ".yaml", ".yml", ".xml", ".html",
})


def is_file_ref(value: str) -> bool:
    """Check if a string looks like a file path reference.

    A file reference:
    - Has a recognised extension (.md, .txt, .json, .yaml, .yml, .xml, .html)
    - Does not contain newlines (multi-line strings are inline content)
    - Is not excessively long (> 260 chars)
    """
    if not value or len(value) > 260:
        return False
    trimmed = value.strip()
    if "\n" in trimmed:
        return False
    _, ext = os.path.splitext(trimmed)
    return ext in _FILE_EXTENSIONS


def resolve_ref(value: str, base_dir: str) -> str:
    """Resolve a string value: if it looks like a file ref and the file exists, inline it.

    Args:
        value:    the string to resolve (may be a file path or inline content).
        base_dir: directory from which relative paths are resolved.

    Returns:
        The file contents if the file exists, otherwise the original *value*.

    Raises:
        ValueError: if a path traversal is detected (resolved path outside *base_dir*).
    """
    if not is_file_ref(value):
        return value
    filepath = os.path.join(base_dir, value.strip())
    resolved = os.path.realpath(filepath)
    if not resolved.startswith(os.path.realpath(base_dir)):
        raise ValueError(f"Path traversal detected: {value.strip()}")
    if os.path.isfile(resolved):
        return Path(resolved).read_text(encoding="utf-8")
    return value


def resolve_json_ref(value: str, base_dir: str) -> str:
    """Resolve a string value and, if it was a file reference, re-serialise as compact JSON.

    Useful for JSON artifact values stored as file references.

    Args:
        value:    the string to resolve.
        base_dir: base directory for relative paths.

    Returns:
        If the file exists and is valid JSON: re-serialised compact JSON.
        Otherwise, the original *value* (or raw file contents if not valid JSON).
    """
    resolved = resolve_ref(value, base_dir)
    if resolved is value:
        return value
    try:
        parsed = json.loads(resolved)
        return json.dumps(parsed, ensure_ascii=False)
    except (json.JSONDecodeError, TypeError):
        return resolved
