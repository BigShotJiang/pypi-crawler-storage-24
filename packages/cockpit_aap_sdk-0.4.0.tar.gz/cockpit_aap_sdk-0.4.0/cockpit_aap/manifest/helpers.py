"""Manifest helper functions -- Python port of the TypeScript manifest helpers.

Provides 30+ pure functions for querying agents, artifacts, i18n, commands,
skills, hooks, connections, and themes from a ``Manifest`` dataclass.

All public functions follow the naming convention ``get_manifest_*`` and accept
a ``Manifest`` as the first argument.  None of these functions mutate the
manifest; ``get_localized_manifest`` returns a deep copy when overrides are
applied.
"""

from __future__ import annotations

import copy
import json
import re
from dataclasses import fields as dataclass_fields
from typing import Any

from .types import (
    Manifest,
    ManifestAccess,
    ManifestAgent,
    ManifestArtifact,
    ManifestCommand,
    ManifestConnection,
    ManifestDecision,
    ManifestHealthCheck,
    ManifestHITLTool,
    ManifestHook,
    ManifestI18n,
    ManifestIssue,
    ManifestJourneyStage,
    ManifestKnowledge,
    ManifestLocale,
    ManifestNetwork,
    ManifestProjectResolved,
    ManifestResolvedModule,
    ManifestRoadmapItem,
    ManifestRule,
    ManifestSkill,
    ManifestTheme,
    ManifestThemePreset,
    ManifestUI,
    ManifestUIAgentMode,
    ManifestUIInputMode,
    ManifestUISection,
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

# Reverse map: snake_case field name -> CSS hyphenated key  (e.g. "primary_foreground" -> "primary-foreground")
_SNAKE_TO_CSS: dict[str, str] = {
    "primary": "primary",
    "primary_foreground": "primary-foreground",
    "background": "background",
    "foreground": "foreground",
    "card": "card",
    "card_foreground": "card-foreground",
    "popover": "popover",
    "popover_foreground": "popover-foreground",
    "secondary": "secondary",
    "secondary_foreground": "secondary-foreground",
    "muted": "muted",
    "muted_foreground": "muted-foreground",
    "accent": "accent",
    "accent_foreground": "accent-foreground",
    "destructive": "destructive",
    "destructive_foreground": "destructive-foreground",
    "border": "border",
    "input": "input",
    "ring": "ring",
    "sidebar": "sidebar",
    "sidebar_foreground": "sidebar-foreground",
    "sidebar_primary": "sidebar-primary",
    "sidebar_primary_foreground": "sidebar-primary-foreground",
    "sidebar_accent": "sidebar-accent",
    "sidebar_accent_foreground": "sidebar-accent-foreground",
    "sidebar_border": "sidebar-border",
    "sidebar_ring": "sidebar-ring",
}


def _get_artifact_prefix(manifest: Manifest) -> str:
    """Return the artifact prefix (with trailing dot)."""
    prefix = manifest.metadata.artifact_prefix
    if prefix:
        return prefix
    module_id = manifest.metadata.name
    return f"{module_id}."


# =========================================================================
# Agent helpers
# =========================================================================


def get_manifest_agent(manifest: Manifest, agent_id: str) -> ManifestAgent | None:
    """Get an agent definition from the manifest by its ID."""
    if manifest.spec.agents is None:
        return None
    for agent in manifest.spec.agents:
        if agent.id == agent_id:
            return agent
    return None


def get_manifest_persona(manifest: Manifest, persona_id: str):
    """Get a persona config by persona_id. Returns None if not found."""
    if manifest.spec.personas is None:
        return None
    for p in manifest.spec.personas.definitions:
        if p.persona_id == persona_id:
            return p
    return None


def get_agent_for_persona(manifest: Manifest, persona_id: str) -> str | None:
    """Get the default agent ID for a persona.

    Returns ``default_agent`` if set on the persona, or falls back to the
    first agent defined in the manifest. Returns ``None`` if there are no agents.
    """
    persona = get_manifest_persona(manifest, persona_id)
    if persona is not None and persona.default_agent:
        return persona.default_agent
    agents = manifest.spec.agents
    if agents:
        return agents[0].id
    return None


def get_persona_agents(manifest: Manifest, persona_id: str) -> list[str]:
    """Get all agent IDs allowed for a persona.

    Returns ``allowed_agents`` if set, otherwise returns all agent IDs
    (no restriction — the persona may interact with every agent).
    """
    persona = get_manifest_persona(manifest, persona_id)
    if persona is not None and persona.allowed_agents:
        return list(persona.allowed_agents)
    return [a.id for a in (manifest.spec.agents or [])]


def get_manifest_agent_instruction(manifest: Manifest, agent_id: str) -> str:
    """Get the instruction text for an agent. Returns ``""`` if not found."""
    agent = get_manifest_agent(manifest, agent_id)
    return agent.instruction if agent is not None else ""


# =========================================================================
# Artifact helpers
# =========================================================================


def get_manifest_artifact_value(manifest: Manifest, key: str) -> str | None:
    """Get the raw ``default_value`` string for an artifact by key."""
    if manifest.spec.artifacts is None:
        return None
    for artifact in manifest.spec.artifacts:
        if artifact.key == key:
            return artifact.default_value
    return None


def get_manifest_artifact_json(manifest: Manifest, key: str) -> Any | None:
    """Get an artifact's ``default_value`` parsed as JSON.

    Returns ``None`` if the key is not found or if the value is not valid JSON.
    """
    raw = get_manifest_artifact_value(manifest, key)
    if raw is None:
        return None
    try:
        return json.loads(raw)
    except ValueError:
        return None


def get_state_artifacts(manifest: Manifest) -> list[ManifestArtifact]:
    """Get only the state-category artifacts."""
    return [a for a in (manifest.spec.artifacts or []) if a.category == "state"]


def get_manifest_artifacts_by_category(
    manifest: Manifest, category: str
) -> list[ManifestArtifact]:
    """Filter artifacts by category."""
    return [a for a in (manifest.spec.artifacts or []) if a.category == category]


def get_manifest_artifacts_by_prefix(
    manifest: Manifest, prefix: str
) -> list[dict[str, Any]]:
    """Get all artifacts whose keys start with ``{prefix}.``, parsed as JSON.

    Returns a list of ``{"key": key, "value": parsed_json}`` dicts.
    Non-JSON values are silently skipped.
    """
    needle = f"{prefix}."
    results: list[dict[str, Any]] = []
    for artifact in manifest.spec.artifacts or []:
        if artifact.key.startswith(needle):
            try:
                results.append({"key": artifact.key, "value": json.loads(artifact.default_value)})
            except ValueError:
                pass  # skip non-JSON
    return results


# =========================================================================
# i18n helpers
# =========================================================================


def get_manifest_locale(
    manifest: Manifest, locale: str | None = None
) -> ManifestLocale | None:
    """Get the locale definition, with fallback to ``defaultLocale``.

    Returns ``None`` if no ``i18n`` section exists.
    """
    if manifest.spec.i18n is None:
        return None
    code = locale if locale is not None else manifest.spec.i18n.default_locale
    loc = manifest.spec.i18n.locales.get(code)
    if loc is not None:
        return loc
    return manifest.spec.i18n.locales.get(manifest.spec.i18n.default_locale)


def get_manifest_default_locale(manifest: Manifest) -> str:
    """Get the default locale string. Falls back to ``"en"``."""
    if manifest.spec.i18n is not None:
        return manifest.spec.i18n.default_locale
    return "en"


def get_manifest_prompt_pills(
    manifest: Manifest, locale: str | None = None
) -> list[dict[str, str]]:
    """Get prompt pills from i18n locale, falling back to the artifact value.

    Priority 1: ``locale.prompt_pills``
    Priority 2: artifact ``{prefix}ui.prompt-pills`` parsed as JSON
    Returns ``[]`` if nothing found.
    """
    loc = get_manifest_locale(manifest, locale)
    if loc is not None and loc.prompt_pills:
        return loc.prompt_pills

    # Fallback: artifact
    prefix = _get_artifact_prefix(manifest)
    key = f"{prefix}ui.prompt-pills"
    raw = get_manifest_artifact_value(manifest, key)
    if raw:
        try:
            return json.loads(raw)
        except ValueError:
            pass
    return []


def get_manifest_welcome(
    manifest: Manifest, locale: str | None = None
) -> dict[str, Any] | None:
    """Get welcome content from i18n locale, falling back to the artifact value.

    Priority 1: ``locale.welcome``
    Priority 2: artifact ``{prefix}ui.welcome-message`` parsed as JSON
    Returns ``None`` if nothing found.
    """
    loc = get_manifest_locale(manifest, locale)
    if loc is not None and loc.welcome:
        return loc.welcome

    # Fallback: artifact
    prefix = _get_artifact_prefix(manifest)
    key = f"{prefix}ui.welcome-message"
    raw = get_manifest_artifact_value(manifest, key)
    if raw:
        try:
            return json.loads(raw)
        except ValueError:
            pass
    return None


def _resolve_locale_resources(
    manifest: Manifest, code: str
) -> dict[str, Any] | None:
    """Resolve i18next resource bundle for a single locale code.

    Returns ``{"translation": ...}`` or ``None`` if nothing found.
    """
    # Priority 1: resources field from i18n
    if manifest.spec.i18n is not None:
        locale_data = manifest.spec.i18n.locales.get(code)
        if locale_data is not None and locale_data.resources and isinstance(locale_data.resources, dict):
            return {"translation": locale_data.resources}

    # Priority 2: artifact scan
    prefix = _get_artifact_prefix(manifest)
    data = get_manifest_artifact_json(manifest, f"{prefix}i18n.{code}")
    if data is not None:
        return {"translation": data}
    return None


def get_manifest_i18n_resources(manifest: Manifest) -> dict[str, dict[str, Any]]:
    """Build i18next-compatible resources from manifest i18n.

    Returns ``{locale: {"translation": {...}}}`` for each locale.

    Priority per locale:
    1. ``locale.resources`` field (unified pattern)
    2. artifact ``{prefix}i18n.{locale}`` parsed as JSON (legacy)
    """
    if manifest.spec.i18n is not None:
        locale_codes = list(manifest.spec.i18n.locales.keys())
    else:
        locale_codes = ["en"]

    resources: dict[str, dict[str, Any]] = {}
    for code in locale_codes:
        resolved = _resolve_locale_resources(manifest, code)
        if resolved is not None:
            resources[code] = resolved
    return resources


def _get_i18n_content_item(
    manifest: Manifest, locale_code: str, item_id: str
) -> Any | None:
    """Look up a single content item from an i18n locale.

    Returns the item value or ``None`` if not found.
    """
    if manifest.spec.i18n is None:
        return None
    locale_data = manifest.spec.i18n.locales.get(locale_code)
    if locale_data is not None and locale_data.content and isinstance(locale_data.content, dict):
        if item_id in locale_data.content:
            return locale_data.content[item_id]
    return None


def get_manifest_localized_content(
    manifest: Manifest,
    prefix: str,
    item_id: str,
    locale: str | None = None,
) -> Any | None:
    """Get one localized content item.

    Priority 1: ``i18n.locales.{locale}.content[item_id]``
    Fallback: ``i18n.locales.{defaultLocale}.content[item_id]``
    Priority 2: artifact ``{prefix}.{locale}.{item_id}`` parsed as JSON
    """
    default_locale = get_manifest_default_locale(manifest)
    requested = locale if locale is not None else default_locale

    # Priority 1: i18n content
    result = _get_i18n_content_item(manifest, requested, item_id)
    if result is not None:
        return result
    if requested != default_locale:
        fallback = _get_i18n_content_item(manifest, default_locale, item_id)
        if fallback is not None:
            return fallback

    # Priority 2: artifact scan
    primary = get_manifest_artifact_json(manifest, f"{prefix}.{requested}.{item_id}")
    if primary is not None:
        return primary
    if requested != default_locale:
        return get_manifest_artifact_json(manifest, f"{prefix}.{default_locale}.{item_id}")
    return None


def _get_i18n_content_values(
    manifest: Manifest, locale_code: str
) -> list[Any] | None:
    """Get all content values from an i18n locale.

    Returns values list or ``None`` if no content found.
    """
    if manifest.spec.i18n is None:
        return None
    locale_data = manifest.spec.i18n.locales.get(locale_code)
    if locale_data is not None and locale_data.content and isinstance(locale_data.content, dict):
        values = list(locale_data.content.values())
        if values:
            return values
    return None


def get_manifest_localized_collection(
    manifest: Manifest,
    prefix: str,
    locale: str | None = None,
) -> list[Any]:
    """Get ALL localized content items for a prefix and locale.

    Priority 1: ``i18n.locales.{locale}.content`` values
    Fallback: ``i18n.locales.{defaultLocale}.content`` values
    Priority 2: artifacts matching ``{prefix}.{locale}.*``
    """
    default_locale = get_manifest_default_locale(manifest)
    requested = locale if locale is not None else default_locale

    # Priority 1: i18n content
    values = _get_i18n_content_values(manifest, requested)
    if values:
        return values
    if requested != default_locale:
        fallback = _get_i18n_content_values(manifest, default_locale)
        if fallback:
            return fallback

    # Priority 2: artifact scan
    items = get_manifest_artifacts_by_prefix(manifest, f"{prefix}.{requested}")
    if items:
        return [i["value"] for i in items]
    if requested != default_locale:
        fallback_items = get_manifest_artifacts_by_prefix(manifest, f"{prefix}.{default_locale}")
        return [i["value"] for i in fallback_items]
    return []


def _apply_module_overrides(localized: Manifest, overrides: ManifestLocale) -> None:
    """Apply locale overrides for module name and description."""
    if not overrides.module:
        return
    if overrides.module.get("name"):
        localized.metadata.display_name = overrides.module["name"]
    if overrides.module.get("description"):
        localized.metadata.description = overrides.module["description"]


def _apply_agent_overrides(localized: Manifest, overrides: ManifestLocale) -> None:
    """Apply locale overrides for agent fields (name, description, instruction, objective)."""
    if not overrides.agents or not localized.spec.agents:
        return
    for agent in localized.spec.agents:
        ao = overrides.agents.get(agent.id)
        if ao is None:
            continue
        if ao.get("name"):
            agent.name = ao["name"]
        if ao.get("description") is not None:
            agent.description = ao["description"]
        if ao.get("instruction"):
            agent.instruction = ao["instruction"]
        if ao.get("objective"):
            agent.objective = ao["objective"]


def _apply_persona_overrides(localized: Manifest, overrides: ManifestLocale) -> None:
    """Apply locale overrides for persona display_name and description."""
    if not overrides.personas or not localized.spec.personas or not localized.spec.personas.definitions:
        return
    for persona in localized.spec.personas.definitions:
        po = overrides.personas.get(persona.persona_id)
        if po is None:
            continue
        if po.get("display_name"):
            persona.display_name = po["display_name"]
        if po.get("description"):
            persona.description = po["description"]


def _apply_command_overrides(localized: Manifest, overrides: ManifestLocale) -> None:
    """Apply locale overrides for command name and description."""
    if not overrides.commands or not localized.spec.commands:
        return
    for cmd in localized.spec.commands:
        co = overrides.commands.get(cmd.id)
        if co is None:
            continue
        if co.get("name"):
            cmd.name = co["name"]
        if co.get("description"):
            cmd.description = co["description"]


def _apply_skill_overrides(localized: Manifest, overrides: ManifestLocale) -> None:
    """Apply locale overrides for skill name, description, and instruction."""
    if not overrides.skills or not localized.spec.skills:
        return
    for skill in localized.spec.skills:
        so = overrides.skills.get(skill.id)
        if so is None:
            continue
        if so.get("name"):
            skill.name = so["name"]
        if so.get("description"):
            skill.description = so["description"]
        if so.get("instruction"):
            skill.instruction = so["instruction"]


def _apply_recognition_overrides(localized: Manifest, overrides: ManifestLocale) -> None:
    """Apply locale overrides for recognition badge name and description."""
    if not overrides.recognition or not localized.spec.recognition or not localized.spec.recognition.badges:
        return
    badge_overrides = overrides.recognition.get("badges", {})
    if not badge_overrides:
        return
    for badge in localized.spec.recognition.badges:
        bo = badge_overrides.get(badge.id)
        if bo is None:
            continue
        if bo.get("name"):
            badge.name = bo["name"]
        if bo.get("description"):
            badge.description = bo["description"]


def _apply_onboarding_overrides(localized: Manifest, overrides: ManifestLocale) -> None:
    """Apply locale overrides for onboarding welcome_message."""
    if not overrides.onboarding or not localized.spec.onboarding:
        return
    if overrides.onboarding.get("welcome_message"):
        localized.spec.onboarding.welcome_message = overrides.onboarding["welcome_message"]


def get_localized_manifest(
    manifest: Manifest, locale: str | None = None
) -> Manifest:
    """Return a manifest with human-readable fields overridden for the given locale.

    If the target locale is the default locale or no overrides exist, the
    **original** manifest object is returned (no clone).
    """
    default_locale = get_manifest_default_locale(manifest)
    target_locale = locale if locale is not None else default_locale

    if target_locale == default_locale:
        return manifest

    if manifest.spec.i18n is None:
        return manifest

    overrides = manifest.spec.i18n.locales.get(target_locale)
    if overrides is None:
        return manifest

    localized = copy.deepcopy(manifest)

    _apply_module_overrides(localized, overrides)
    _apply_agent_overrides(localized, overrides)
    _apply_persona_overrides(localized, overrides)
    _apply_command_overrides(localized, overrides)
    _apply_skill_overrides(localized, overrides)
    _apply_recognition_overrides(localized, overrides)
    _apply_onboarding_overrides(localized, overrides)

    return localized


# =========================================================================
# Command helpers
# =========================================================================


def get_manifest_commands(manifest: Manifest) -> list[ManifestCommand]:
    """Get all commands from the manifest."""
    return manifest.spec.commands or []


def get_manifest_command(manifest: Manifest, id: str) -> ManifestCommand | None:
    """Get a single command by ID."""
    for cmd in manifest.spec.commands or []:
        if cmd.id == id:
            return cmd
    return None


def get_manifest_commands_by_persona(
    manifest: Manifest, persona: str
) -> list[ManifestCommand]:
    """Get all commands scoped to a persona."""
    return [c for c in (manifest.spec.commands or []) if c.persona == persona]


# =========================================================================
# Skill helpers
# =========================================================================


def get_manifest_skills(manifest: Manifest) -> list[ManifestSkill]:
    """Get all skills from the manifest."""
    return manifest.spec.skills or []


def get_manifest_skill(manifest: Manifest, id: str) -> ManifestSkill | None:
    """Get a single skill by ID."""
    for skill in manifest.spec.skills or []:
        if skill.id == id:
            return skill
    return None


def get_manifest_skills_by_persona(
    manifest: Manifest, persona: str
) -> list[ManifestSkill]:
    """Get all skills scoped to a persona."""
    return [s for s in (manifest.spec.skills or []) if s.persona == persona]


def get_manifest_skills_by_trigger(
    manifest: Manifest, trigger: str
) -> list[ManifestSkill]:
    """Get all skills that match a given trigger string."""
    return [
        s
        for s in (manifest.spec.skills or [])
        if s.auto_invoke is not None and trigger in s.auto_invoke.triggers
    ]


# =========================================================================
# Hook helpers
# =========================================================================


def get_manifest_hooks(manifest: Manifest) -> list[ManifestHook]:
    """Get all hooks from the manifest."""
    return manifest.spec.hooks or []


def get_manifest_hooks_by_event(manifest: Manifest, event: str) -> list[ManifestHook]:
    """Get all hooks for a specific event."""
    return [h for h in (manifest.spec.hooks or []) if h.event == event]


def get_manifest_hooks_for_tool(
    manifest: Manifest, event: str, tool_name: str
) -> list[ManifestHook]:
    """Get hooks matching an event and tool name (via matcher regex).

    Hooks with no ``matcher`` match all tools.
    """
    results: list[ManifestHook] = []
    for hook in manifest.spec.hooks or []:
        if hook.event != event:
            continue
        if hook.matcher is None or re.search(hook.matcher, tool_name):
            results.append(hook)
    return results


# =========================================================================
# Connection helpers
# =========================================================================


def get_manifest_connections(manifest: Manifest) -> list[ManifestConnection]:
    """Get all connections from the manifest."""
    return manifest.spec.connections or []


def get_manifest_connection(
    manifest: Manifest, id: str
) -> ManifestConnection | None:
    """Get a single connection by ID."""
    for conn in manifest.spec.connections or []:
        if conn.id == id:
            return conn
    return None


# =========================================================================
# Theme helpers
# =========================================================================


def get_manifest_theme(manifest: Manifest) -> ManifestTheme | None:
    """Get the full theme definition from the manifest."""
    return manifest.spec.theme


def get_manifest_default_theme(manifest: Manifest) -> str | None:
    """Get the default theme preset ID."""
    if manifest.spec.theme is None:
        return None
    return manifest.spec.theme.default


def get_manifest_theme_preset(
    manifest: Manifest, preset_id: str
) -> ManifestThemePreset | None:
    """Get a specific theme preset by ID."""
    if manifest.spec.theme is None:
        return None
    return manifest.spec.theme.presets.get(preset_id)


def get_manifest_theme_preset_ids(manifest: Manifest) -> list[str]:
    """Get all available theme preset IDs."""
    if manifest.spec.theme is None or not manifest.spec.theme.presets:
        return []
    return list(manifest.spec.theme.presets.keys())


def _collect_color_css_vars(preset: ManifestThemePreset) -> dict[str, str]:
    """Collect CSS variables from theme preset colors."""
    css_vars: dict[str, str] = {}
    if preset.colors is None:
        return css_vars
    for field_name, css_key in _SNAKE_TO_CSS.items():
        value = getattr(preset.colors, field_name, None)
        if value is not None:
            css_vars[f"--{css_key}"] = value
    if preset.colors.extra:
        for key, value in preset.colors.extra.items():
            css_vars[f"--{key}"] = value
    return css_vars


def _collect_copilotkit_css_vars(preset: ManifestThemePreset) -> dict[str, str]:
    """Collect CopilotKit CSS variables from theme preset."""
    if not preset.copilot_kit:
        return {}
    return {f"--copilot-kit-{key}": value for key, value in preset.copilot_kit.items()}


def _collect_font_css_vars(preset: ManifestThemePreset) -> dict[str, str]:
    """Collect font CSS variables from theme preset."""
    if not preset.fonts:
        return {}
    return {f"--font-{key}": value for key, value in preset.fonts.items()}


def get_manifest_theme_css_vars(
    manifest: Manifest, preset_id: str
) -> dict[str, str] | None:
    """Get a flat CSS variable map for a theme preset.

    Maps:
    - ``colors.{key}`` -> ``--{key}``
    - ``copilot_kit.{key}`` -> ``--copilot-kit-{key}``
    - ``fonts.{key}`` -> ``--font-{key}``
    """
    if manifest.spec.theme is None:
        return None
    preset = manifest.spec.theme.presets.get(preset_id)
    if preset is None:
        return None

    css_vars: dict[str, str] = {}
    css_vars.update(_collect_color_css_vars(preset))
    css_vars.update(_collect_copilotkit_css_vars(preset))
    css_vars.update(_collect_font_css_vars(preset))
    return css_vars


# ---------------------------------------------------------------------------
# Rules helpers
# ---------------------------------------------------------------------------


def get_manifest_rules(manifest: Manifest) -> list[ManifestRule]:
    """Get all rules from the manifest. Returns empty list if none."""
    return list(manifest.spec.rules or [])


def get_manifest_rules_by_scope(manifest: Manifest, scope: str) -> list[ManifestRule]:
    """Get rules filtered by scope ('input', 'output', 'both')."""
    return [r for r in get_manifest_rules(manifest) if r.scope == scope]


def get_manifest_rules_by_enforcement(manifest: Manifest, enforcement: str) -> list[ManifestRule]:
    """Get rules filtered by enforcement level."""
    return [r for r in get_manifest_rules(manifest) if r.enforcement == enforcement]


def get_manifest_rules_for_agent(manifest: Manifest, agent_id: str) -> list[ManifestRule]:
    """Get rules that apply to the given agent.

    Rules with applies_to omitted apply to ALL agents.
    Rules with applies_to defined only apply to listed agents.
    """
    return [
        r for r in get_manifest_rules(manifest)
        if not r.applies_to or agent_id in r.applies_to
    ]


def get_manifest_rules_for_agent_and_scope(
    manifest: Manifest, agent_id: str, scope: str
) -> list[ManifestRule]:
    """Get rules for a given agent filtered to a specific scope (input or output).

    Also includes rules with scope='both'.
    """
    return [
        r for r in get_manifest_rules_for_agent(manifest, agent_id)
        if r.scope == scope or r.scope == "both"
    ]


def build_rules_instruction_snippet(manifest: Manifest, agent_id: str) -> str:
    """Build a concise rules summary for injecting into an agent instruction.

    Only includes block/redact/mask rules (blocking/modifying).
    Returns empty string if no applicable blocking rules.
    """
    rules = [
        r for r in get_manifest_rules_for_agent(manifest, agent_id)
        if r.enforcement in ("block", "redact", "mask")
    ]
    if not rules:
        return ""

    lines = [
        "\n## Business Rules\n",
        "The following business rules apply to your actions. Before taking any action, "
        "call `validate_rules` with the relevant context.\n",
    ]
    for r in rules:
        lines.append(f"- **{r.name}** ({r.enforcement.upper()}): {r.message or r.condition}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Lifecycle helpers
# ---------------------------------------------------------------------------


def get_manifest_roadmap(manifest: Manifest) -> list[ManifestRoadmapItem]:
    """Get all roadmap items. Returns empty list if no lifecycle section."""
    if not manifest.spec.lifecycle:
        return []
    return list(manifest.spec.lifecycle.roadmap or [])


def get_manifest_roadmap_by_status(manifest: Manifest, status: str) -> list[ManifestRoadmapItem]:
    """Get roadmap items filtered by status."""
    return [r for r in get_manifest_roadmap(manifest) if r.status == status]


def get_manifest_issues(manifest: Manifest) -> list[ManifestIssue]:
    """Get all issues from the lifecycle section."""
    if not manifest.spec.lifecycle:
        return []
    return list(manifest.spec.lifecycle.issues or [])


def get_manifest_open_issues(manifest: Manifest) -> list[ManifestIssue]:
    """Get only open or in-progress issues."""
    return [i for i in get_manifest_issues(manifest) if i.status in ("open", "in-progress")]


def get_manifest_issues_by_severity(manifest: Manifest, severity: str) -> list[ManifestIssue]:
    """Get issues filtered by severity."""
    return [i for i in get_manifest_issues(manifest) if i.severity == severity]


def get_manifest_decisions(manifest: Manifest) -> list[ManifestDecision]:
    """Get all architectural decisions."""
    if not manifest.spec.lifecycle:
        return []
    return list(manifest.spec.lifecycle.decisions or [])


# ---------------------------------------------------------------------------
# Agent Execution helpers
# ---------------------------------------------------------------------------


def get_agent_execution_mode(agent: ManifestAgent) -> str:
    """Get the effective execution mode for an agent. Defaults to ``"local"``."""
    exec_block = getattr(agent, "execution", None)
    if exec_block and isinstance(exec_block, dict):
        return exec_block.get("mode", "local")
    return "local"


def get_agents_by_execution_mode(manifest: Manifest, mode: str) -> list[ManifestAgent]:
    """Get all agents with a specific execution mode."""
    return [a for a in (manifest.spec.agents or []) if get_agent_execution_mode(a) == mode]


def get_local_agents(manifest: Manifest) -> list[ManifestAgent]:
    """Get local agents (assembled client-side)."""
    return get_agents_by_execution_mode(manifest, "local")


def get_platform_agents(manifest: Manifest) -> list[ManifestAgent]:
    """Get platform agents (executed via Cockpit MCP ``execute_agent``)."""
    return get_agents_by_execution_mode(manifest, "platform")


def get_azure_foundry_agents(manifest: Manifest) -> list[ManifestAgent]:
    """Get Azure AI Foundry agents."""
    return get_agents_by_execution_mode(manifest, "azure-foundry")


# ---------------------------------------------------------------------------
# Knowledge helpers
# ---------------------------------------------------------------------------


def get_manifest_knowledge(manifest: Manifest) -> list[ManifestKnowledge]:
    """Get all knowledge taxonomy entries from the manifest."""
    return list(manifest.spec.knowledge or [])


def get_manifest_knowledge_by_kind(manifest: Manifest, kind: str) -> ManifestKnowledge | None:
    """Get a single knowledge entry by its kind label."""
    for k in (manifest.spec.knowledge or []):
        if k.kind == kind:
            return k
    return None


# ---------------------------------------------------------------------------
# HITL helpers
# ---------------------------------------------------------------------------


def get_manifest_hitl_tools(manifest: Manifest) -> list[ManifestHITLTool]:
    """Get all HITL tool definitions from the manifest.

    Returns an empty list if ``spec.hitl.tools`` is not defined.
    """
    hitl = manifest.spec.hitl
    if not hitl or not isinstance(hitl, dict):
        return []
    tools_raw = hitl.get("tools", [])
    if not tools_raw:
        return []
    # If already parsed as ManifestHITLTool, return as-is
    if tools_raw and isinstance(tools_raw[0], ManifestHITLTool):
        return list(tools_raw)
    # Otherwise parse from dicts
    from .types import _parse_hitl_tool  # noqa: WPS433
    return [_parse_hitl_tool(t) for t in tools_raw]


def get_manifest_hitl_tool(manifest: Manifest, name: str) -> ManifestHITLTool | None:
    """Get a specific HITL tool definition by name."""
    for t in get_manifest_hitl_tools(manifest):
        if t.name == name:
            return t
    return None


# ---------------------------------------------------------------------------
# Health check helpers
# ---------------------------------------------------------------------------


def get_manifest_health_checks(manifest: Manifest) -> list[ManifestHealthCheck]:
    """Get all health check definitions from the manifest.

    Returns an empty list if ``spec.health.checks`` is not defined.
    """
    health = manifest.spec.health
    if not health or not isinstance(health, dict):
        return []
    checks_raw = health.get("checks", [])
    if not checks_raw:
        return []
    if checks_raw and isinstance(checks_raw[0], ManifestHealthCheck):
        return list(checks_raw)
    from .types import _parse_health_check  # noqa: WPS433
    return [_parse_health_check(c) for c in checks_raw]


# ---------------------------------------------------------------------------
# UI helpers
# ---------------------------------------------------------------------------


def get_manifest_ui_agent_modes(manifest: Manifest) -> list[ManifestUIAgentMode]:
    """Get all agent mode definitions from the manifest UI config."""
    ui = manifest.spec.ui
    if not ui:
        return []
    return list(ui.agent_modes or [])


def get_manifest_ui_input_modes(manifest: Manifest) -> list[ManifestUIInputMode]:
    """Get the UI input modes defined in ``spec.ui.inputModes``."""
    ui = manifest.spec.ui
    if not ui:
        return []
    return list(ui.input_modes or [])


def get_manifest_ui_sections(manifest: Manifest) -> list[ManifestUISection]:
    """Get the UI sections defined in ``spec.ui.sections``."""
    ui = manifest.spec.ui
    if not ui:
        return []
    return list(ui.sections or [])


# ---------------------------------------------------------------------------
# Network helpers
# ---------------------------------------------------------------------------


def get_manifest_network(manifest: Manifest) -> ManifestNetwork | None:
    """Get the declared service network ports for this module."""
    return manifest.spec.network


# ---------------------------------------------------------------------------
# Journey helpers
# ---------------------------------------------------------------------------


def get_manifest_journey_stages(manifest: Manifest) -> list[ManifestJourneyStage]:
    """Get all journey stages from the manifest."""
    journey = manifest.spec.journey
    if not journey:
        return []
    return list(journey.stages or [])


# ---------------------------------------------------------------------------
# Input Context Skills helpers
# ---------------------------------------------------------------------------


def get_manifest_input_context_skills(
    manifest: Manifest,
    stage: str | None = None,
) -> list[ManifestSkill]:
    """Get skills with ``trigger='input_context'``, optionally filtered by stage.

    Skills without a ``stage`` field are considered global and are always
    included when a stage filter is provided.
    """
    skills = get_manifest_skills_by_trigger(manifest, "input_context")
    if stage is None:
        return skills
    return [s for s in skills if not s.stage or s.stage == stage]


# =========================================================================
# Persona middleware helpers
# =========================================================================


def get_default_persona_id(manifest: Manifest) -> str:
    """Get the default persona ID from the manifest.

    Falls back to ``"developer"`` when no personas section is defined.
    """
    if manifest.spec.personas is not None:
        return manifest.spec.personas.default_persona
    return "developer"


def extract_persona(state: dict, default_persona: str = "developer") -> str:
    """Extract persona ID from a CopilotKit agent state dict.

    Checks ``state.copilotkit.properties.persona`` first, then scans
    ``state.copilotkit.context`` items whose description contains "persona".
    Returns *default_persona* when no persona information is found.

    Args:
        state: The CopilotKit agent state dict.
        default_persona: Fallback persona ID (should come from
            ``manifest.spec.personas.defaultPersona``).
    """
    copilotkit = state.get("copilotkit", {})
    # Check direct properties
    properties = copilotkit.get("properties", {})
    if "persona" in properties:
        return properties["persona"]
    # Check context items
    for item in copilotkit.get("context", []):
        desc = str(item.get("description", "")).lower()
        if "persona" in desc:
            return item.get("value", default_persona)
    return default_persona


def filter_tools_for_persona(tools: list, allowed: list[str] | str | None) -> list:
    """Filter a tool list by a persona whitelist.

    Args:
        tools: List of tool objects (each must have a ``name`` attribute).
        allowed: ``"*"`` or ``None`` to allow all, or a list of allowed
            tool names.

    Returns:
        Filtered list of tools whose ``name`` is in *allowed*.
    """
    if allowed == "*" or allowed is None:
        return tools
    if isinstance(allowed, list):
        return [t for t in tools if t.name in allowed]
    return tools


def filter_skills_for_persona(skill_index: str, allowed: list[str] | str | None) -> str:
    """Filter a skill index string by a persona whitelist.

    Each line of *skill_index* represents one skill.  Lines that contain at
    least one of the *allowed* skill names are kept.

    Args:
        skill_index: Newline-separated skill descriptions.
        allowed: ``"*"`` or ``None`` to allow all, or a list of allowed
            skill names.

    Returns:
        Filtered skill index string.
    """
    if allowed == "*" or allowed is None:
        return skill_index
    if isinstance(allowed, list):
        lines = skill_index.strip().split("\n")
        filtered = [line for line in lines if any(s in line for s in allowed)]
        return "\n".join(filtered)
    return skill_index


def build_persona_prompt(persona_def: dict, base_prompt: str) -> str:
    """Prepend persona instruction to a base system prompt.

    If the persona definition contains an ``instruction`` key, it is
    prepended (separated by a blank line) to *base_prompt*.  Otherwise
    *base_prompt* is returned unchanged.
    """
    instruction = persona_def.get("instruction", "")
    if instruction:
        return f"{instruction}\n\n{base_prompt}"
    return base_prompt


# =========================================================================
# HITL (Human-in-the-Loop) middleware helpers
# =========================================================================


def build_hitl_request(
    tool_name: str,
    args: dict,
    hitl_def: dict,
    trace_id: str | None = None,
    agent_id: str | None = None,
) -> dict:
    """Build a HITL request payload for the frontend.

    The *hitl_def* dict is typically obtained via
    :func:`get_manifest_hitl_tool` and may contain ``risk``, ``timeout``,
    and ``actions`` fields.  Missing fields fall back to sensible defaults.

    Args:
        tool_name: The tool that requires approval.
        args: The arguments passed to the tool.
        hitl_def: HITL tool definition dict from the manifest.
        trace_id: Optional trace ID for observability correlation.
        agent_id: Optional agent ID that initiated the call.

    Returns:
        A dict payload with keys: ``type``, ``tool``, ``displayName``,
        ``args``, ``risk``, ``timeout``, ``traceId``, ``agentId``,
        ``actions``.
    """
    return {
        "type": "hitl_request",
        "tool": tool_name,
        "displayName": (
            hitl_def.get("displayName")
            or hitl_def.get("title")
            or hitl_def.get("name")
            or tool_name
        ),
        "args": args,
        "risk": hitl_def.get("risk", "medium"),
        "timeout": hitl_def.get("timeout", 300),
        "traceId": trace_id,
        "agentId": agent_id,
        "actions": hitl_def.get("actions", ["approve", "reject"]),
    }


# =========================================================================
# Project helpers — Python port of TS ``getProject*`` functions
# =========================================================================


def get_project_default_module(
    project: ManifestProjectResolved,
) -> ManifestResolvedModule | None:
    """Get the default module in a resolved project.

    Returns the first module whose ``default`` flag is ``True``, or ``None``.
    """
    for m in project.modules:
        if m.default:
            return m
    return None


def get_project_module(
    project: ManifestProjectResolved,
    module_id: str,
) -> ManifestResolvedModule | None:
    """Find a module in a resolved project by its ID."""
    for m in project.modules:
        if m.id == module_id:
            return m
    return None


def get_project_enabled_modules(
    project: ManifestProjectResolved,
) -> list[ManifestResolvedModule]:
    """Return all enabled modules in a resolved project."""
    return [m for m in project.modules if m.enabled]


def get_project_module_theme(
    project: ManifestProjectResolved,
    module_id: str,
) -> ManifestTheme | None:
    """Get the theme for a specific module, falling back to the project shared theme."""
    mod = get_project_module(project, module_id)
    if mod and mod.manifest and mod.manifest.spec.theme:
        return mod.manifest.spec.theme
    if project.shared and project.shared.theme:
        return project.shared.theme
    return None


def get_project_module_i18n(
    project: ManifestProjectResolved,
    module_id: str,
) -> ManifestI18n | None:
    """Get the i18n config for a specific module, falling back to the project shared i18n."""
    mod = get_project_module(project, module_id)
    if mod and mod.manifest and mod.manifest.spec.i18n:
        return mod.manifest.spec.i18n
    if project.shared and project.shared.i18n:
        return project.shared.i18n
    return None


def get_project_module_access(
    project: ManifestProjectResolved,
    module_id: str,
) -> ManifestAccess | None:
    """Get the access config for a specific module, falling back to the project shared access."""
    mod = get_project_module(project, module_id)
    if mod and mod.manifest and mod.manifest.spec.access:
        return mod.manifest.spec.access
    if project.shared and project.shared.access:
        return project.shared.access
    return None


def get_project_module_connections(
    project: ManifestProjectResolved,
    module_id: str,
) -> list[ManifestConnection]:
    """Get connections for a specific module, falling back to the project shared connections."""
    mod = get_project_module(project, module_id)
    if mod and mod.manifest and mod.manifest.spec.connections:
        return mod.manifest.spec.connections
    if project.shared and project.shared.connections:
        return project.shared.connections
    return []
