"""Load manifest dependencies from local package connections.

Python port of ``loadManifestDependencies`` from
``@ruinosus/aap-bootstrap/src/manifest/dependencies.ts``.

Scans ``connections`` with ``transport: "local"`` and resolves their
manifests from ``node_modules/<package>/.aap/*/manifest.yaml``.
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any

from cockpit_aap.bootstrap import ManifestResult, ResolvedAgent
from cockpit_aap.manifest.scanner import scan_manifest
from cockpit_aap.manifest.types import Manifest, ManifestConnection


def get_package_connections(manifest: Manifest) -> list[ManifestConnection]:
    """Filter connections with ``transport == "local"`` (local package deps)."""
    connections = manifest.spec.connections or []
    return [c for c in connections if c.transport == "local"]


def find_package_root(
    package_name: str,
    from_dir: str | None = None,
) -> str | None:
    """Walk up from *from_dir* looking for ``node_modules/<package>/package.json``.

    Returns the package root directory or ``None`` if not found.
    This mirrors the TypeScript implementation's filesystem-based resolution
    (compatible with Turbopack / Bun workspaces).
    """
    current = Path(from_dir) if from_dir else Path.cwd()
    while True:
        candidate = current / "node_modules" / package_name / "package.json"
        if candidate.is_file():
            return str(candidate.parent)
        parent = current.parent
        if parent == current:
            break
        current = parent
    return None


def load_manifest_dependencies(
    manifest: Manifest,
    from_dir: str | None = None,
) -> list[ManifestResult]:
    """Resolve manifests from local package connections.

    For each connection with ``transport: "local"``, the function:
    1. Walks up from *from_dir* (default: ``cwd``) to find
       ``node_modules/<package>/package.json``.
    2. Looks for a ``.aap/`` directory inside the package root.
    3. Scans each subdirectory of ``.aap/`` as a manifest.
    4. Returns a ``ManifestResult`` per discovered manifest.

    Args:
        manifest: The root manifest whose connections to resolve.
        from_dir: Starting directory for the upward walk (default: ``os.getcwd()``).

    Returns:
        A list of ``ManifestResult`` for each discovered dependency manifest.
    """
    pkg_connections = get_package_connections(manifest)
    if not pkg_connections:
        return []

    results: list[ManifestResult] = []

    for conn in pkg_connections:
        pkg_name = conn.package
        if not pkg_name:
            continue

        try:
            pkg_root = find_package_root(pkg_name, from_dir)
            if pkg_root is None:
                import warnings
                warnings.warn(
                    f"Package '{pkg_name}' not found in node_modules",
                    stacklevel=2,
                )
                continue

            aap_dir = os.path.join(pkg_root, ".aap")
            if not os.path.isdir(aap_dir):
                import warnings
                warnings.warn(
                    f"No .aap directory found in {pkg_root}",
                    stacklevel=2,
                )
                continue

            # Scan each subdirectory of .aap/
            for entry in os.scandir(aap_dir):
                if not entry.is_dir():
                    continue
                try:
                    dep_manifest = scan_manifest(entry.path)
                    agents: dict[str, ResolvedAgent] = {}
                    for a in (dep_manifest.spec.agents or []):
                        instruction = (
                            a.instruction if isinstance(a.instruction, str) else ""
                        )
                        agents[a.name] = ResolvedAgent(
                            name=a.name,
                            instruction=instruction,
                            source="default-fallback",
                        )
                    results.append(
                        ManifestResult(
                            module=dep_manifest.metadata.name,
                            manifest=dep_manifest,
                            manifest_source="local",
                            duration_ms=0,
                            agents=agents,
                        )
                    )
                except Exception:
                    pass  # skip malformed sub-manifests

        except Exception:
            import warnings
            warnings.warn(
                f"Failed to resolve dependency package '{pkg_name}'",
                stacklevel=2,
            )

    return results
