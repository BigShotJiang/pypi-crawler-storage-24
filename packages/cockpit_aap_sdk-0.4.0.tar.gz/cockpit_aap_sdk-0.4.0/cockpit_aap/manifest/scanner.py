"""Manifest directory scanner -- reads single-file or multi-file manifests.

Supports two patterns:

1. **Single-file**: ``manifest.yaml`` containing everything.
2. **Multi-file**: ``manifest.yaml`` (core) + subdirectories:
   - ``agents/*.md`` / ``agents/*.yaml`` -- agent instructions and configs
   - ``i18n/{locale}/resources.json`` / ``content.json`` -- locale resources
   - ``personas/*.yaml`` -- persona definitions
   - ``theme.yaml`` or ``theme.yml`` -- theme configuration
   - ``commands/*.md`` / ``commands/*.yaml`` -- command scripts and configs
   - ``skills/{id}/SKILL.md`` / ``skills/{id}/meta.yaml`` -- skill definitions
   - ``hooks/hooks.yaml`` -- lifecycle hooks

File references in instruction, defaultValue, and script fields are resolved
relative to the manifest directory.
"""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import yaml

from .parser import parse_manifest
from .types import (
    Manifest,
    ManifestI18n,
    ManifestLocale,
    ManifestPersonas,
    ManifestPersonaConfig,
    ManifestAgent,
    ManifestCommand,
    ManifestHook,
    ManifestSkill,
)

# Extensions treated as file references
_FILE_EXTENSIONS = frozenset((".md", ".txt", ".json", ".yaml", ".yml", ".xml", ".html"))

# Common YAML extension constants to avoid S1192 duplication
_YAML_EXT = ".yaml"
_YML_EXT = ".yml"
_YAML_EXTS = (_YAML_EXT, _YML_EXT)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def scan_manifest(manifest_dir: str) -> Manifest:
    """Scan a directory for a Manifest (single-file or multi-file).

    Always loads ``manifest.yaml`` as the core file, then merges any
    subdirectories (personas, agents, etc.) if they exist.
    If no subdirectories are present, this behaves like a single-file manifest.

    Parameters
    ----------
    manifest_dir:
        Path to the directory containing ``manifest.yaml``.

    Returns
    -------
    Manifest
        Fully resolved manifest with file references inlined.

    Raises
    ------
    FileNotFoundError
        If the directory does not exist or contains no manifest file.
    """
    base_dir = os.path.abspath(manifest_dir)

    if not os.path.isdir(base_dir):
        raise FileNotFoundError(f"Manifest directory not found: {base_dir}")

    # Load core manifest from manifest.yaml
    core_file = os.path.join(base_dir, "manifest.yaml")
    if not os.path.isfile(core_file):
        raise FileNotFoundError(
            f"No manifest found in {base_dir}. Expected manifest.yaml"
        )

    core_content = Path(core_file).read_text(encoding="utf-8")
    manifest = parse_manifest(core_content)

    # Merge from subdirectories (order matches TypeScript scanner)
    _load_personas(manifest, os.path.join(base_dir, "personas"))
    _merge_agents(manifest, os.path.join(base_dir, "agents"))
    _load_theme(manifest, base_dir)
    _load_commands(manifest, os.path.join(base_dir, "commands"))
    _load_skills(manifest, os.path.join(base_dir, "skills"))
    _load_hooks(manifest, base_dir)
    _load_i18n(manifest, os.path.join(base_dir, "i18n"))

    # Resolve any remaining file references
    _resolve_file_references(manifest, base_dir)

    return manifest


# ---------------------------------------------------------------------------
# Multi-file merge helpers
# ---------------------------------------------------------------------------


def _merge_agent_md_file(
    agents: list[ManifestAgent], stem: str, filepath: str, filename: str
) -> None:
    """Merge a markdown file as agent instruction."""
    content = Path(filepath).read_text(encoding="utf-8")
    existing = _find_agent(agents, stem, f"agents/{filename}")
    if existing is not None:
        existing.instruction = content


def _merge_agent_yaml_file(agents: list[ManifestAgent], filepath: str) -> None:
    """Merge a YAML file as agent config."""
    raw = yaml.safe_load(Path(filepath).read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or not raw.get("id"):
        return
    idx = _find_agent_index(agents, raw["id"])
    if idx >= 0:
        _merge_agent_dict(agents[idx], raw)
    else:
        agents.append(_agent_from_dict(raw))


def _merge_agents(manifest: Manifest, agents_dir: str) -> None:
    """Merge agent definitions from the ``agents/`` directory.

    - ``.md`` files: matched by filename stem to an existing agent's ``id`` or
      ``instruction`` field (treated as file ref). Content replaces instruction.
    - ``.yaml`` / ``.yml`` files: full agent config that merges into or adds to
      the agents list.
    """
    if not os.path.isdir(agents_dir):
        return

    if manifest.spec.agents is None:
        manifest.spec.agents = []

    for filename in sorted(os.listdir(agents_dir)):
        filepath = os.path.join(agents_dir, filename)
        if not os.path.isfile(filepath):
            continue

        stem, ext = os.path.splitext(filename)

        if ext == ".md":
            _merge_agent_md_file(manifest.spec.agents, stem, filepath, filename)
        elif ext in _YAML_EXTS:
            _merge_agent_yaml_file(manifest.spec.agents, filepath)


def _find_agent(
    agents: list[ManifestAgent], agent_id: str, instruction_ref: str
) -> ManifestAgent | None:
    for a in agents:
        if a.id == agent_id or a.instruction == instruction_ref:
            return a
    return None


def _find_agent_index(agents: list[ManifestAgent], agent_id: str) -> int:
    for i, a in enumerate(agents):
        if a.id == agent_id:
            return i
    return -1


def _merge_agent_dict(agent: ManifestAgent, raw: dict[str, Any]) -> None:
    """Merge raw dict fields onto an existing ManifestAgent."""
    from .types import _camel_to_snake

    for key, value in raw.items():
        attr = _camel_to_snake(key)
        if hasattr(agent, attr) and value is not None:
            setattr(agent, attr, value)


def _agent_from_dict(raw: dict[str, Any]) -> ManifestAgent:
    """Create a ManifestAgent from a raw dict."""
    from .types import _snake_keys

    d = _snake_keys(raw)
    return ManifestAgent(
        id=d["id"],
        name=d.get("name", d["id"]),
        description=d.get("description", ""),
        instruction=d.get("instruction", ""),
        objective=d.get("objective"),
        persona=d.get("persona"),
        tools=d.get("tools"),
        type_id=d.get("type_id"),
        model=d.get("model"),
        runtime=d.get("runtime", "any"),
    )


def _read_json_file(filepath: str) -> Any | None:
    """Read and parse a JSON file, returning ``None`` if it doesn't exist."""
    if not os.path.isfile(filepath):
        return None
    raw = Path(filepath).read_text(encoding="utf-8")
    return json.loads(raw)


def _ensure_locale_obj(manifest: Manifest, locale_name: str) -> ManifestLocale:
    """Ensure the i18n structure and locale object exist, returning the locale."""
    if manifest.spec.i18n is None:
        manifest.spec.i18n = ManifestI18n(default_locale=locale_name)
    locale_obj = manifest.spec.i18n.locales.get(locale_name)
    if locale_obj is None:
        locale_obj = ManifestLocale()
        manifest.spec.i18n.locales[locale_name] = locale_obj
    return locale_obj


def _load_locale_dir(manifest: Manifest, locale_name: str, locale_dir: str) -> None:
    """Load resources.json and content.json from a single locale directory."""
    resources = _read_json_file(os.path.join(locale_dir, "resources.json"))
    content = _read_json_file(os.path.join(locale_dir, "content.json"))

    if resources is None and content is None:
        return

    locale_obj = _ensure_locale_obj(manifest, locale_name)
    if resources is not None:
        locale_obj.resources = resources
    if content is not None:
        locale_obj.content = content


def _load_i18n(manifest: Manifest, i18n_dir: str) -> None:
    """Load i18n resources from the ``i18n/{locale}/`` directory structure.

    Each subdirectory name is a locale code (e.g. ``en``, ``pt-BR``).
    Inside each, ``resources.json`` and/or ``content.json`` are loaded.
    """
    if not os.path.isdir(i18n_dir):
        return

    for locale_name in sorted(os.listdir(i18n_dir)):
        locale_dir = os.path.join(i18n_dir, locale_name)
        if not os.path.isdir(locale_dir):
            continue
        _load_locale_dir(manifest, locale_name, locale_dir)


def _load_personas_index(
    personas_dir: str,
) -> tuple[str, list[ManifestPersonaConfig]]:
    """Load _index.yaml for default persona and inline definitions."""
    default_persona = ""
    definitions: list[ManifestPersonaConfig] = []
    index_file = os.path.join(personas_dir, "_index.yaml")
    if os.path.isfile(index_file):
        raw = yaml.safe_load(Path(index_file).read_text(encoding="utf-8"))
        if isinstance(raw, dict):
            default_persona = raw.get("defaultPersona", "")
            for d in raw.get("definitions", []):
                definitions.append(_persona_from_dict(d))
    return default_persona, definitions


def _merge_persona_file(
    definitions: list[ManifestPersonaConfig], filepath: str
) -> None:
    """Merge a single persona YAML file into the definitions list."""
    raw = yaml.safe_load(Path(filepath).read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or not raw.get("personaId"):
        return
    persona = _persona_from_dict(raw)
    idx = next(
        (i for i, d in enumerate(definitions) if d.persona_id == persona.persona_id),
        -1,
    )
    if idx >= 0:
        definitions[idx] = persona
    else:
        definitions.append(persona)


def _load_personas(manifest: Manifest, personas_dir: str) -> None:
    """Load persona definitions from the ``personas/`` directory."""
    if not os.path.isdir(personas_dir):
        return

    default_persona, definitions = _load_personas_index(personas_dir)

    # Load individual persona files (excluding _index.yaml)
    for filename in sorted(os.listdir(personas_dir)):
        if filename == "_index.yaml":
            continue
        filepath = os.path.join(personas_dir, filename)
        if not os.path.isfile(filepath):
            continue
        _, ext = os.path.splitext(filename)
        if ext not in _YAML_EXTS:
            continue
        _merge_persona_file(definitions, filepath)

    if definitions or default_persona:
        manifest.spec.personas = ManifestPersonas(
            default_persona=default_persona,
            definitions=definitions,
        )


def _persona_from_dict(raw: dict[str, Any]) -> ManifestPersonaConfig:
    from .types import _snake_keys

    d = _snake_keys(raw)
    return ManifestPersonaConfig(
        persona_id=d["persona_id"],
        display_name=d.get("display_name", ""),
        description=d.get("description", ""),
        enabled=d.get("enabled"),
        icon=d.get("icon"),
        ui=d.get("ui"),
        ai=d.get("ai"),
    )


def _load_theme(manifest: Manifest, base_dir: str) -> None:
    """Load theme.yaml or theme.yml from the manifest base directory."""
    for name in (f"theme{_YAML_EXT}", f"theme{_YML_EXT}"):
        theme_path = os.path.join(base_dir, name)
        if os.path.isfile(theme_path):
            raw = yaml.safe_load(Path(theme_path).read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                from .types import _parse_theme

                manifest.spec.theme = _parse_theme(raw)
            return


def _merge_command_md(
    commands: list[ManifestCommand], stem: str, filepath: str
) -> None:
    """Merge a markdown file as command script content."""
    content = Path(filepath).read_text(encoding="utf-8")
    existing = next((c for c in commands if c.id == stem), None)
    if existing is not None:
        existing.script = content
    else:
        commands.append(
            ManifestCommand(id=stem, name=stem, description="", script=content)
        )


def _merge_command_yaml(commands: list[ManifestCommand], filepath: str) -> None:
    """Merge a YAML file as command config."""
    raw = yaml.safe_load(Path(filepath).read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or not raw.get("id"):
        return
    from .types import _snake_keys

    d = _snake_keys(raw)
    idx = next((i for i, c in enumerate(commands) if c.id == d["id"]), -1)
    if idx >= 0:
        cmd = commands[idx]
        for key, value in d.items():
            if hasattr(cmd, key) and value is not None:
                setattr(cmd, key, value)
    else:
        commands.append(
            ManifestCommand(
                id=d["id"],
                name=d.get("name", d["id"]),
                description=d.get("description", ""),
                script=d.get("script", ""),
            )
        )


def _load_commands(manifest: Manifest, commands_dir: str) -> None:
    """Load command definitions from the ``commands/`` directory."""
    if not os.path.isdir(commands_dir):
        return

    if manifest.spec.commands is None:
        manifest.spec.commands = []

    for filename in sorted(os.listdir(commands_dir)):
        filepath = os.path.join(commands_dir, filename)
        if not os.path.isfile(filepath):
            continue

        stem, ext = os.path.splitext(filename)

        if ext == ".md":
            _merge_command_md(manifest.spec.commands, stem, filepath)
        elif ext in _YAML_EXTS:
            _merge_command_yaml(manifest.spec.commands, filepath)


def _apply_meta_dict(skill: ManifestSkill, d: dict, skill_id: str) -> None:
    """Apply a parsed meta dictionary onto a skill object."""
    for key, value in d.items():
        if hasattr(skill, key) and value is not None:
            setattr(skill, key, value)
    skill.id = d.get("id", skill_id)


def _load_skill_meta(entry_path: str, skill: ManifestSkill, skill_id: str) -> None:
    """Load meta.yaml/meta.yml and apply fields onto a skill."""
    for meta_name in (f"meta{_YAML_EXT}", f"meta{_YML_EXT}"):
        meta_path = os.path.join(entry_path, meta_name)
        if os.path.isfile(meta_path):
            raw = yaml.safe_load(Path(meta_path).read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                from .types import _snake_keys

                _apply_meta_dict(skill, _snake_keys(raw), skill_id)
            break


def _load_skill_instruction(entry_path: str, skill: ManifestSkill) -> None:
    """Load SKILL.md as the skill instruction."""
    skill_md = os.path.join(entry_path, "SKILL.md")
    if os.path.isfile(skill_md):
        skill.instruction = Path(skill_md).read_text(encoding="utf-8")


def _load_md_files_from_dir(dir_path: str) -> list[str]:
    """Read all .md files from a directory, sorted, returning their contents."""
    if not os.path.isdir(dir_path):
        return []
    return [
        Path(os.path.join(dir_path, f)).read_text(encoding="utf-8")
        for f in sorted(os.listdir(dir_path))
        if f.endswith(".md")
    ]


def _merge_or_add_skill(skills: list[ManifestSkill], skill: ManifestSkill) -> None:
    """Merge skill into existing list entry or append as new."""
    idx = next((i for i, s in enumerate(skills) if s.id == skill.id), -1)
    if idx >= 0:
        existing = skills[idx]
        for attr in ("name", "description", "instruction", "auto_invoke", "persona", "references", "examples"):
            val = getattr(skill, attr)
            if val is not None and val != "" and val != []:
                setattr(existing, attr, val)
    else:
        skills.append(skill)


def _load_skill_from_dir(entry_path: str, entry_name: str) -> ManifestSkill:
    """Build a ManifestSkill from a skill subdirectory."""
    skill = ManifestSkill(
        id=entry_name, name=entry_name, description="", instruction=""
    )
    _load_skill_meta(entry_path, skill, entry_name)
    _load_skill_instruction(entry_path, skill)
    skill.references = _load_md_files_from_dir(os.path.join(entry_path, "references")) or None
    skill.examples = _load_md_files_from_dir(os.path.join(entry_path, "examples")) or None
    return skill


def _merge_skill_yaml(skills: list[ManifestSkill], filepath: str) -> None:
    """Merge a YAML file as skill config."""
    raw = yaml.safe_load(Path(filepath).read_text(encoding="utf-8"))
    if not isinstance(raw, dict) or not raw.get("id"):
        return
    from .types import _snake_keys

    d = _snake_keys(raw)
    idx = next((i for i, s in enumerate(skills) if s.id == d["id"]), -1)
    if idx >= 0:
        existing = skills[idx]
        for key, value in d.items():
            if hasattr(existing, key) and value is not None:
                setattr(existing, key, value)
    else:
        skills.append(
            ManifestSkill(
                id=d["id"],
                name=d.get("name", d["id"]),
                description=d.get("description", ""),
                instruction=d.get("instruction", ""),
            )
        )


def _load_skills(manifest: Manifest, skills_dir: str) -> None:
    """Load skill definitions from the ``skills/`` directory.

    Supports both subdirectory layout (``skills/{id}/SKILL.md`` + ``meta.yaml``)
    and inline YAML files (``skills/{id}.yaml``).
    """
    if not os.path.isdir(skills_dir):
        return

    if manifest.spec.skills is None:
        manifest.spec.skills = []

    for entry_name in sorted(os.listdir(skills_dir)):
        entry_path = os.path.join(skills_dir, entry_name)

        if os.path.isdir(entry_path):
            skill = _load_skill_from_dir(entry_path, entry_name)
            _merge_or_add_skill(manifest.spec.skills, skill)
        elif os.path.isfile(entry_path):
            _, ext = os.path.splitext(entry_name)
            if ext in _YAML_EXTS:
                _merge_skill_yaml(manifest.spec.skills, entry_path)


def _parse_hooks_list(raw: Any) -> list[dict[str, Any]]:
    """Extract a list of hook dicts from raw YAML data."""
    if isinstance(raw, list):
        return raw
    if isinstance(raw, dict) and "hooks" in raw:
        return raw["hooks"]
    return []


def _hook_from_dict(h: dict[str, Any]) -> ManifestHook:
    """Create a ManifestHook from a raw dict."""
    return ManifestHook(
        event=h["event"],
        type=h["type"],
        matcher=h.get("matcher"),
        script=h.get("script"),
        artifact=h.get("artifact"),
        description=h.get("description"),
    )


def _load_hooks(manifest: Manifest, base_dir: str) -> None:
    """Load lifecycle hooks from ``hooks/hooks.yaml`` or ``hooks/hooks.yml``."""
    for name in (f"hooks/hooks{_YAML_EXT}", f"hooks/hooks{_YML_EXT}"):
        hooks_path = os.path.join(base_dir, name)
        if not os.path.isfile(hooks_path):
            continue
        raw = yaml.safe_load(Path(hooks_path).read_text(encoding="utf-8"))
        hooks_list = _parse_hooks_list(raw)
        if hooks_list:
            if manifest.spec.hooks is None:
                manifest.spec.hooks = []
            manifest.spec.hooks.extend(_hook_from_dict(h) for h in hooks_list)
        return


# ---------------------------------------------------------------------------
# File reference resolution
# ---------------------------------------------------------------------------


def _is_file_ref(value: str) -> bool:
    """Check if a string looks like a file path reference.

    A file reference:
    - Has a recognized extension (.md, .txt, .json, .yaml, .yml, .xml, .html)
    - Does not contain newlines (multi-line strings are inline content)
    - Is not excessively long
    """
    if not value or len(value) > 260:
        return False
    trimmed = value.strip()
    if "\n" in trimmed:
        return False
    _, ext = os.path.splitext(trimmed)
    return ext in _FILE_EXTENSIONS


def _resolve_ref(value: str, base_dir: str) -> str:
    """Resolve a string value: if it looks like a file ref and the file exists, inline it."""
    if not _is_file_ref(value):
        return value
    filepath = os.path.join(base_dir, value.strip())
    # Validate resolved path stays within base directory (prevent path traversal)
    resolved = os.path.realpath(filepath)
    if not resolved.startswith(os.path.realpath(base_dir)):
        raise ValueError(f"Path traversal detected: {value.strip()}")
    if os.path.isfile(resolved):
        return Path(resolved).read_text(encoding="utf-8")
    return value  # Return as-is if file not found


def _resolve_agent_refs(agents: list[ManifestAgent], base_dir: str) -> None:
    """Resolve file references in agent instructions."""
    for agent in agents:
        agent.instruction = _resolve_ref(agent.instruction, base_dir)


def _resolve_artifact_refs(
    artifacts: list[Any], base_dir: str
) -> None:
    """Resolve file references in artifact defaultValues."""
    for artifact in artifacts:
        artifact.default_value = _resolve_ref(artifact.default_value, base_dir)


def _resolve_command_refs(
    commands: list[ManifestCommand], base_dir: str
) -> None:
    """Resolve file references in command scripts."""
    for command in commands:
        command.script = _resolve_ref(command.script, base_dir)


def _resolve_skill_refs(skills: list[ManifestSkill], base_dir: str) -> None:
    """Resolve file references in skill instructions."""
    for skill in skills:
        skill.instruction = _resolve_ref(skill.instruction, base_dir)


def _resolve_hook_refs(hooks: list[ManifestHook], base_dir: str) -> None:
    """Resolve file references in hook scripts."""
    for hook in hooks:
        if hook.script:
            hook.script = _resolve_ref(hook.script, base_dir)


def _resolve_locale_agent_refs(locale_data: ManifestLocale, base_dir: str) -> None:
    """Resolve file refs in locale agent instruction overrides."""
    if not locale_data.agents or not isinstance(locale_data.agents, dict):
        return
    for agent_override in locale_data.agents.values():
        if isinstance(agent_override, dict) and isinstance(
            agent_override.get("instruction"), str
        ):
            agent_override["instruction"] = _resolve_ref(
                agent_override["instruction"], base_dir
            )


def _resolve_locale_skill_refs(locale_data: ManifestLocale, base_dir: str) -> None:
    """Resolve file refs in locale skill instruction overrides."""
    if not locale_data.skills or not isinstance(locale_data.skills, dict):
        return
    for skill_override in locale_data.skills.values():
        if isinstance(skill_override, dict) and isinstance(
            skill_override.get("instruction"), str
        ):
            skill_override["instruction"] = _resolve_ref(
                skill_override["instruction"], base_dir
            )


def _resolve_locale_resources_ref(locale_data: ManifestLocale, base_dir: str) -> None:
    """Resolve a file ref in locale resources (string → parsed JSON)."""
    if not isinstance(locale_data.resources, str) or not _is_file_ref(locale_data.resources):
        return
    filepath = os.path.join(base_dir, locale_data.resources.strip())
    if os.path.isfile(filepath):
        raw = Path(filepath).read_text(encoding="utf-8")
        try:
            locale_data.resources = json.loads(raw)
        except json.JSONDecodeError:
            pass


def _resolve_locale_content_refs(locale_data: ManifestLocale, base_dir: str) -> None:
    """Resolve file refs in locale content dict values (string → parsed JSON)."""
    if not locale_data.content or not isinstance(locale_data.content, dict):
        return
    for key, val in locale_data.content.items():
        if isinstance(val, str) and _is_file_ref(val):
            filepath = os.path.join(base_dir, val.strip())
            if os.path.isfile(filepath):
                raw = Path(filepath).read_text(encoding="utf-8")
                try:
                    locale_data.content[key] = json.loads(raw)
                except json.JSONDecodeError:
                    pass


def _resolve_i18n_refs(i18n: ManifestI18n, base_dir: str) -> None:
    """Resolve all file references within i18n locales."""
    for locale_data in i18n.locales.values():
        _resolve_locale_agent_refs(locale_data, base_dir)
        _resolve_locale_skill_refs(locale_data, base_dir)
        _resolve_locale_resources_ref(locale_data, base_dir)
        _resolve_locale_content_refs(locale_data, base_dir)


def _resolve_file_references(manifest: Manifest, base_dir: str) -> None:
    """Walk known string fields and inline file references.

    Resolves file references in:
    - agent instructions
    - artifact defaultValues
    - command scripts
    - skill instructions
    - hook scripts
    """
    if manifest.spec.agents:
        _resolve_agent_refs(manifest.spec.agents, base_dir)

    if manifest.spec.artifacts:
        _resolve_artifact_refs(manifest.spec.artifacts, base_dir)

    if manifest.spec.commands:
        _resolve_command_refs(manifest.spec.commands, base_dir)

    if manifest.spec.skills:
        _resolve_skill_refs(manifest.spec.skills, base_dir)

    if manifest.spec.hooks:
        _resolve_hook_refs(manifest.spec.hooks, base_dir)

    if manifest.spec.i18n and manifest.spec.i18n.locales:
        _resolve_i18n_refs(manifest.spec.i18n, base_dir)
