"""Merge two Manifest objects (deep, spec-aware merge).

Port of ``packages/bootstrap/src/manifest/merge.ts``.

Rules:
- Arrays of objects with ``id`` field → merged by id (override wins; unmatched base kept)
- Arrays of objects without ``id`` field → override replaces completely
- Scalar values → override wins (``None`` in override keeps base value)
- ``metadata`` → shallow merged (override wins per key)
"""

from __future__ import annotations

import copy
from dataclasses import fields, asdict
from typing import Any

from .types import Manifest, ManifestSpec


def merge_manifests(base: Manifest, override: Manifest) -> Manifest:
    """Deep-merge *override* into *base* and return a new :class:`Manifest`.

    The original objects are **not** mutated.
    """
    merged = copy.deepcopy(base)

    # metadata — shallow merge (override wins)
    if override.metadata is not None:
        base_meta = asdict(merged.metadata) if merged.metadata else {}
        over_meta = asdict(override.metadata) if override.metadata else {}
        for k, v in over_meta.items():
            if v is not None:
                base_meta[k] = v
        from .types import ManifestMetadata
        merged.metadata = ManifestMetadata(**base_meta)

    # Top-level scalars
    if override.api_version:
        merged.api_version = override.api_version
    if override.kind:
        merged.kind = override.kind

    # spec — field-by-field merge
    merged.spec = _merge_spec(merged.spec, override.spec)

    return merged


def _merge_spec(base: ManifestSpec, override: ManifestSpec) -> ManifestSpec:
    """Merge spec fields: arrays by id when possible, scalars by override-wins."""
    if override is None:
        return base
    if base is None:
        return copy.deepcopy(override)

    result = copy.deepcopy(base)

    for f in fields(ManifestSpec):
        name = f.name
        over_val = getattr(override, name, None)
        if over_val is None:
            continue

        base_val = getattr(result, name, None)

        if isinstance(over_val, list) and isinstance(base_val, list):
            setattr(result, name, _merge_arrays(base_val, over_val))
        else:
            setattr(result, name, copy.deepcopy(over_val))

    return result


def _merge_arrays(base: list[Any], override: list[Any]) -> list[Any]:
    """Merge two arrays.  If items have an ``id`` key, merge by id."""
    if not override:
        return base[:]
    if not base:
        return override[:]

    # Check if items have an "id" field (dict-like or dataclass with .id)
    sample = override[0] if override else (base[0] if base else None)
    has_id = False
    if sample is not None:
        if isinstance(sample, dict):
            has_id = "id" in sample
        elif hasattr(sample, "id"):
            has_id = True

    if not has_id:
        return copy.deepcopy(override)

    # Merge by id
    def _get_id(item: Any) -> str | None:
        if isinstance(item, dict):
            return item.get("id")
        return getattr(item, "id", None)

    override_by_id: dict[str | None, Any] = {}
    for item in override:
        override_by_id[_get_id(item)] = item

    result: list[Any] = []
    seen_ids: set[str | None] = set()
    for item in base:
        item_id = _get_id(item)
        if item_id in override_by_id:
            result.append(copy.deepcopy(override_by_id[item_id]))
            seen_ids.add(item_id)
        else:
            result.append(copy.deepcopy(item))

    # Append new items from override not in base
    for item in override:
        item_id = _get_id(item)
        if item_id not in seen_ids:
            result.append(copy.deepcopy(item))

    return result
