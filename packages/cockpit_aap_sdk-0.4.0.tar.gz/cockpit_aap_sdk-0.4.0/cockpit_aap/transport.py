"""Transport abstraction for AAP Gateway SDK."""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from cockpit_aap.mcp_types import (
    PromptResult,
    PromptSchema,
    ResourceContents,
    ResourceSchema,
    ResourceTemplate,
)


@dataclass
class TransportContext:
    """Shared context passed to transport methods."""

    endpoint: str
    timeout: float
    get_headers: Callable[[], Awaitable[dict[str, str]]]


class Transport(ABC):
    """Abstract transport — REST or MCP protocol."""

    @abstractmethod
    async def init(self, ctx: TransportContext) -> list[dict[str, Any]]:
        """Discover tools from the server. Returns list of tool schemas."""
        ...

    @abstractmethod
    async def call_tool(
        self,
        ctx: TransportContext,
        namespace: str,
        tool_name: str,
        args: dict[str, Any],
    ) -> dict[str, Any]:
        """Invoke a tool and return the result."""
        ...

    async def list_prompts(self, ctx: TransportContext) -> list[PromptSchema]:
        """List available prompts from the server."""
        return []

    async def get_prompt(
        self,
        ctx: TransportContext,
        namespace: str,
        name: str,
        args: dict[str, str] | None = None,
    ) -> PromptResult:
        """Execute a prompt and return the result."""
        return PromptResult()

    async def list_resources(self, ctx: TransportContext) -> list[ResourceSchema]:
        """List available resources from the server."""
        return []

    async def read_resource(
        self,
        ctx: TransportContext,
        namespace: str,
        uri: str,
    ) -> list[ResourceContents]:
        """Read a resource by URI."""
        return []

    async def list_resource_templates(
        self, ctx: TransportContext
    ) -> list[ResourceTemplate]:
        """List available resource templates from the server."""
        return []
