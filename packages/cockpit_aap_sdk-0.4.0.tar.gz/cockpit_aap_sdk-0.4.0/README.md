# cockpit-aap-sdk

Async Python SDK for the Avanade Agentic Platform. Provides dynamic namespace/tool access via `__getattr__` magic — same `sdk.namespace.tool_name(args)` pattern as the TypeScript SDK. Includes full **Manifest bootstrap** with server sync, scanning, parsing, and 30+ helper functions.

## Installation

```bash
pip install cockpit-aap-sdk

# Or with uv
uv add cockpit-aap-sdk
```

## Quick Start

```python
from cockpit_aap import AAPGatewayClient

async with AAPGatewayClient(
    endpoint="http://localhost:3100",
    token="your-token",
    tenant_id="acme-corp",
) as sdk:
    await sdk.init()

    # Dynamic access: sdk.namespace.tool_name(args)
    result = await sdk.artifacts.search_artifacts(
        query="my-module", search_type="key"
    )
    print(result)

    # Discovery
    print(sdk.namespaces)               # ['artifacts', 'agents', ...]
    tools = await sdk.get_tools("artifacts")  # List tool schemas
```

## Client Configuration

```python
from cockpit_aap import AAPGatewayClient

sdk = AAPGatewayClient(
    endpoint="https://your-cockpit/mcp",  # MCP server URL
    token="your-jwt",                      # Static token or callable
    tenant_id="tenant-123",                # Optional tenant ID
    transport="mcp",                       # "mcp" (JSON-RPC) or "rest"
    timeout=30.0,                          # Request timeout in seconds
    headers={                              # Additional headers
        "x-api-key": "...",
        "x-cockpit-license-id": "...",
    },
)
```

### Token Refresh

```python
# Static token
sdk = AAPGatewayClient(endpoint="...", token="static-jwt")

# Callable (called on each request)
async def get_token():
    return await fetch_fresh_token()

sdk = AAPGatewayClient(endpoint="...", token=get_token)
```

## Manifest Bootstrap

Full feature parity with the TypeScript `bootstrapManifest()`:

```python
from cockpit_aap import AAPGatewayClient, bootstrap_manifest, scan_manifest

# Read and resolve a manifest directory
manifest = scan_manifest(".aap/my-module")

# Sync to Cockpit server (creates artifacts + registers agents)
async with AAPGatewayClient(endpoint="...", token="...") as sdk:
    await sdk.init()
    result = await bootstrap_manifest(sdk, ".aap/my-module")

    print(result.created)    # Artifacts created
    print(result.upgraded)   # Artifacts upgraded
    print(result.preserved)  # Artifacts preserved (server-wins)
    print(result.agents)     # Agents registered
```

## Manifest Scanning & Parsing

```python
from cockpit_aap import scan_manifest, parse_manifest

# Scan multi-file manifest directory (resolves file refs)
manifest = scan_manifest(".aap/my-module")
print(manifest.module.name)
print(manifest.agents)
print(manifest.i18n)

# Parse raw YAML content
with open("manifest.yaml") as f:
    manifest = parse_manifest(f.read())
```

## Manifest Helper Functions

30+ read-only helpers for extracting data from manifests:

```python
from cockpit_aap.manifest.helpers import (
    get_manifest_agent,
    get_manifest_agent_instruction,
    get_manifest_artifact_value,
    get_manifest_artifact_json,
    get_state_artifacts,
    get_manifest_artifacts_by_category,
    get_manifest_prompt_pills,
    get_manifest_welcome,
    get_manifest_commands,
    get_manifest_skills,
    get_manifest_hooks,
    get_manifest_connections,
    get_manifest_theme,
    get_manifest_theme_css_vars,
    get_manifest_i18n_resources,
    get_localized_manifest,
)

manifest = scan_manifest(".aap/my-module")

# Agent helpers
agent = get_manifest_agent(manifest, "main-agent")
instruction = get_manifest_agent_instruction(manifest, "main-agent")

# Artifact helpers
value = get_manifest_artifact_value(manifest, "config.maxItems")
config = get_manifest_artifact_json(manifest, "config.settings")
state_artifacts = get_state_artifacts(manifest)

# i18n helpers
pills = get_manifest_prompt_pills(manifest, "en")
welcome = get_manifest_welcome(manifest, "pt-BR")
resources = get_manifest_i18n_resources(manifest, "en")

# Theme helpers
css_vars = get_manifest_theme_css_vars(manifest, "dark")
```

## Exported Types

```python
from cockpit_aap import (
    # Client
    AAPGatewayClient,
    Transport,
    TransportContext,
    RestTransport,
    McpTransport,
    # Bootstrap
    bootstrap_manifest,
    ManifestResult,
    ResolvedAgent,
    # Manifest types
    Manifest,
    ManifestModule,
    ManifestAgent,
    ManifestConnection,
    # Scanning
    scan_manifest,
    parse_manifest,
)
```

## Development

```bash
# Install dev dependencies
uv sync --extra dev

# Run tests
uv run pytest

# Type checking
uv run mypy cockpit_aap/
```

## License

MIT
