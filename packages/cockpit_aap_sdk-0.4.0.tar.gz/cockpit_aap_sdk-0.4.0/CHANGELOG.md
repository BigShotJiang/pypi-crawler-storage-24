# cockpit-aap-sdk

## 0.2.0

### Minor Changes

- Full manifest support: types, parser, scanner, 30+ helpers
- Bootstrap with server sync and drift detection
- Postgres adapters (SessionStore, ManifestStore, ManifestSource)
- KindRegistry for extensible kind system
- Auto-generated types from JSON Schema contracts

## 0.1.0

### Minor Changes

- Initial release: async httpx client with dynamic namespace proxy
- MCP and REST transport support
