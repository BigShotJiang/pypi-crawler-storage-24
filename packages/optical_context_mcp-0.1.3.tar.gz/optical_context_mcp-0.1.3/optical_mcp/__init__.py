"""Optical Context MCP package."""
