#!/bin/bash
# Wrapper to forward GPG signing to WSL2 with loopback pinentry
wsl gpg --pinentry-mode loopback "$@"
