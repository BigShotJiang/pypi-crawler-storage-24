from __future__ import annotations

import time
from typing import Any, Protocol
from urllib.parse import quote

from .errors import EnfermerIAError, EnfermerIAErrorContext, EnfermerIAJobError, EnfermerIATimeoutError
from .file import resolve_input_file
from .http import HttpClient
from .types import (
    AnalysisJobResponse,
    AnalysisResult,
    AnalyzeFileInput,
    AnalyzeImageResponse,
    ClinicalContext,
    GetJobResponse,
    UploadUrlResponse,
    WaitForJobOptions,
)
from .utils import assert_non_empty_string, normalize_base_url, sleep_ms

DEFAULT_TIMEOUT_MS = 30_000
DEFAULT_POLLING_INTERVAL_MS = 3_000
DEFAULT_WAIT_TIMEOUT_MS = 120_000


class SupportsHttpClient(Protocol):
    def request_json(
        self,
        *,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        timeout_ms: int | None = None,
    ) -> Any:
        ...

    def upload(
        self,
        *,
        upload_url: str,
        file_bytes: bytes,
        content_type: str,
        timeout_ms: int | None = None,
    ) -> None:
        ...


class EnfermerIAClient:
    def __init__(
        self,
        *,
        api_key: str,
        base_url: str | None = None,
        timeout_ms: int = DEFAULT_TIMEOUT_MS,
        debug: bool = False,
        http_client: SupportsHttpClient | None = None,
    ) -> None:
        assert_non_empty_string(api_key, "api_key")
        self.base_url = normalize_base_url(base_url)
        self._http = http_client or HttpClient(
            api_key=api_key,
            base_url=self.base_url,
            timeout_ms=timeout_ms,
            debug=debug,
        )

    def get_upload_url(
        self,
        *,
        filename: str | None = None,
        ext: str | None = None,
        content_type: str,
    ) -> UploadUrlResponse:
        normalized_filename = filename.strip() if filename else None
        normalized_ext = ext.strip() if ext else None
        normalized_content_type = content_type.strip() if content_type else None

        if not normalized_filename and not normalized_ext:
            raise EnfermerIAError("filename or ext is required.")

        assert_non_empty_string(normalized_content_type, "content_type")

        data = self._http.request_json(
            method="POST",
            path="/v1/images/upload-url",
            body={
                "filename": normalized_filename,
                "ext": normalized_ext,
                "contentType": normalized_content_type,
            },
        )

        return UploadUrlResponse(
            upload_url=data["upload_url"],
            path=data["path"],
            file_url=data["file_url"],
        )

    def upload_file_to_signed_url(
        self,
        *,
        upload_url: str,
        file: bytes | bytearray | memoryview,
        content_type: str,
    ) -> None:
        assert_non_empty_string(upload_url, "upload_url")
        assert_non_empty_string(content_type, "content_type")

        file_bytes = file if isinstance(file, bytes) else bytes(file)
        if not file_bytes:
            raise EnfermerIAError("file must not be empty.")

        self._http.upload(
            upload_url=upload_url,
            file_bytes=file_bytes,
            content_type=content_type,
        )

    def create_analysis_job(
        self,
        *,
        image_url: str,
        clinical_context: ClinicalContext | None = None,
    ) -> AnalysisJobResponse:
        assert_non_empty_string(image_url, "image_url")

        data = self._http.request_json(
            method="POST",
            path="/v1/analysis/jobs",
            body={
                "image_url": image_url,
                **({"clinical_context": clinical_context} if clinical_context is not None else {}),
            },
        )

        return AnalysisJobResponse(job_id=data["job_id"], status=data["status"])

    def get_job(self, job_id: str) -> GetJobResponse:
        assert_non_empty_string(job_id, "job_id")
        encoded_job_id = quote(job_id, safe="")

        data = self._http.request_json(
            method="GET",
            path=f"/v1/analysis/jobs/{encoded_job_id}",
        )

        return GetJobResponse(
            job_id=data["job_id"],
            status=data["status"],
            result=data.get("result"),
            error_message=data.get("error_message"),
        )

    def wait_for_job(
        self,
        job_id: str,
        *,
        interval_ms: int = DEFAULT_POLLING_INTERVAL_MS,
        timeout_ms: int = DEFAULT_WAIT_TIMEOUT_MS,
    ) -> AnalysisResult:
        assert_non_empty_string(job_id, "job_id")
        started_at = time.monotonic()

        while True:
            job = self.get_job(job_id)

            if job.status == "completed":
                if job.result is None:
                    raise EnfermerIAJobError(
                        "Job completed without a result payload.",
                        EnfermerIAErrorContext(endpoint=f"/v1/analysis/jobs/{job_id}", job_id=job_id),
                    )
                return job.result

            if job.status == "error":
                raise EnfermerIAJobError(
                    job.error_message or "Analysis job failed.",
                    EnfermerIAErrorContext(
                        endpoint=f"/v1/analysis/jobs/{job_id}",
                        job_id=job_id,
                        api_message=job.error_message,
                    ),
                )

            elapsed_ms = int((time.monotonic() - started_at) * 1000)
            if elapsed_ms >= timeout_ms:
                raise EnfermerIATimeoutError(
                    f"Timed out waiting for job {job_id} after {timeout_ms}ms.",
                    EnfermerIAErrorContext(endpoint=f"/v1/analysis/jobs/{job_id}", job_id=job_id),
                )

            sleep_ms(interval_ms)

    def analyze_image(
        self,
        *,
        file: AnalyzeFileInput,
        filename: str | None = None,
        content_type: str | None = None,
        clinical_context: ClinicalContext | None = None,
    ) -> AnalyzeImageResponse:
        resolved_file = resolve_input_file(file=file, filename=filename, content_type=content_type)

        upload = self.get_upload_url(
            filename=resolved_file.filename,
            content_type=resolved_file.content_type,
        )

        self.upload_file_to_signed_url(
            upload_url=upload.upload_url,
            file=resolved_file.file_bytes,
            content_type=resolved_file.content_type,
        )

        job = self.create_analysis_job(
            image_url=upload.file_url,
            clinical_context=clinical_context,
        )

        return AnalyzeImageResponse(job_id=job.job_id, status=job.status, file_url=upload.file_url)

    def analyze_image_and_wait(
        self,
        *,
        file: AnalyzeFileInput,
        filename: str | None = None,
        content_type: str | None = None,
        clinical_context: ClinicalContext | None = None,
        wait_options: WaitForJobOptions | None = None,
    ) -> AnalysisResult:
        job = self.analyze_image(
            file=file,
            filename=filename,
            content_type=content_type,
            clinical_context=clinical_context,
        )
        wait_options = wait_options or WaitForJobOptions()
        return self.wait_for_job(
            job.job_id,
            interval_ms=wait_options.interval_ms,
            timeout_ms=wait_options.timeout_ms,
        )
