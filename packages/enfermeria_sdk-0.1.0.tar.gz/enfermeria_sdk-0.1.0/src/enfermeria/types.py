from __future__ import annotations

from dataclasses import dataclass
from os import PathLike
from typing import Any, Literal, Mapping, TypedDict

JobStatus = Literal["queued", "processing", "completed", "error"]
ClinicalContext = str | Mapping[str, Any]
AnalyzeFileInput = str | PathLike[str] | bytes | bytearray | memoryview
AnalysisResult = dict[str, Any]


@dataclass(slots=True)
class UploadUrlResponse:
    upload_url: str
    path: str
    file_url: str


@dataclass(slots=True)
class AnalysisJobResponse:
    job_id: str
    status: Literal["queued"]


@dataclass(slots=True)
class GetJobResponse:
    job_id: str
    status: JobStatus
    result: AnalysisResult | None
    error_message: str | None


@dataclass(slots=True)
class AnalyzeImageResponse:
    job_id: str
    status: Literal["queued"]
    file_url: str


@dataclass(slots=True)
class WaitForJobOptions:
    interval_ms: int = 3000
    timeout_ms: int = 120000


@dataclass(slots=True)
class ResolvedAnalyzeFile:
    file_bytes: bytes
    filename: str
    content_type: str


class ApiErrorPayload(TypedDict, total=False):
    success: bool
    error: str


class ApiSuccessEnvelope(TypedDict):
    success: bool
    data: Any
