from __future__ import annotations

import time
from typing import Any
from urllib.parse import urljoin

from .errors import EnfermerIAError

DEFAULT_BASE_URL = "https://enfermer-ia.com/api"


def normalize_base_url(base_url: str | None) -> str:
    normalized = (base_url or DEFAULT_BASE_URL).strip().rstrip("/")
    if not normalized:
        raise EnfermerIAError("base_url must not be empty.")

    if normalized.endswith("/api"):
        return normalized

    if normalized.endswith("/api/v1"):
        return normalized[:-3]

    return f"{normalized}/api"


def build_url(base_url: str, path: str) -> str:
    normalized_path = path if path.startswith("/") else f"/{path}"
    return urljoin(f"{base_url}/", normalized_path.lstrip("/"))


def assert_non_empty_string(value: str | None, field_name: str) -> None:
    if not value or not value.strip():
        raise EnfermerIAError(f"{field_name} is required.")


def sleep_ms(duration_ms: int) -> None:
    time.sleep(duration_ms / 1000)


def debug_log(enabled: bool, event: str, payload: dict[str, Any]) -> None:
    if enabled:
        print(f"[EnfermerIA SDK] {event} {payload}")
