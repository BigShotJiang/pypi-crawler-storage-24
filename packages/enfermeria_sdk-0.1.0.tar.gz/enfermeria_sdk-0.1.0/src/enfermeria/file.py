from __future__ import annotations

from os import PathLike
from pathlib import Path

from .errors import EnfermerIAError
from .types import AnalyzeFileInput, ResolvedAnalyzeFile

CONTENT_TYPE_BY_EXTENSION = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".webp": "image/webp",
    ".gif": "image/gif",
    ".bmp": "image/bmp",
    ".tif": "image/tiff",
    ".tiff": "image/tiff",
}

EXTENSION_BY_CONTENT_TYPE = {
    "image/jpeg": ".jpg",
    "image/png": ".png",
    "image/webp": ".webp",
    "image/gif": ".gif",
    "image/bmp": ".bmp",
    "image/tiff": ".tiff",
}

DEFAULT_CONTENT_TYPE = "application/octet-stream"


def infer_content_type_from_filename(filename: str | None) -> str | None:
    if not filename:
        return None
    return CONTENT_TYPE_BY_EXTENSION.get(Path(filename).suffix.lower())


def infer_content_type(file: AnalyzeFileInput, filename: str | None = None) -> str:
    from_filename = infer_content_type_from_filename(filename)
    if from_filename:
        return from_filename

    if isinstance(file, (str, PathLike)):
        return infer_content_type_from_filename(str(file)) or DEFAULT_CONTENT_TYPE

    return DEFAULT_CONTENT_TYPE


def fallback_filename_from_content_type(content_type: str | None) -> str:
    normalized = (content_type or "").strip().lower()
    extension = EXTENSION_BY_CONTENT_TYPE.get(normalized, ".bin")
    return f"upload{extension}"


def infer_filename(file: AnalyzeFileInput, filename: str | None = None, content_type: str | None = None) -> str:
    explicit_filename = (filename or "").strip()
    if explicit_filename:
        return explicit_filename

    if isinstance(file, (str, PathLike)):
        path_name = Path(file).name
        if path_name:
            return path_name

    return fallback_filename_from_content_type(content_type)


def read_file_from_path(file_path: str | PathLike[str]) -> bytes:
    path = Path(file_path)
    if not path.exists() or not path.is_file():
        raise EnfermerIAError(f"File not found at path: {path}")

    file_bytes = path.read_bytes()
    if not file_bytes:
        raise EnfermerIAError(f"File is empty at path: {path}")

    return file_bytes


def validate_non_empty_file(file_bytes: bytes) -> None:
    if not file_bytes:
        raise EnfermerIAError("file must not be empty.")


def to_file_bytes(file: AnalyzeFileInput) -> bytes:
    if isinstance(file, (str, PathLike)):
        return read_file_from_path(file)

    if isinstance(file, bytes):
        return file

    if isinstance(file, bytearray):
        return bytes(file)

    if isinstance(file, memoryview):
        return file.tobytes()

    raise EnfermerIAError(
        "Unsupported file type. Use a local file path, bytes, bytearray, or memoryview."
    )


def resolve_input_file(*, file: AnalyzeFileInput, filename: str | None = None, content_type: str | None = None) -> ResolvedAnalyzeFile:
    file_bytes = to_file_bytes(file)
    validate_non_empty_file(file_bytes)

    resolved_content_type = (content_type or "").strip() or infer_content_type(file, filename)
    resolved_filename = infer_filename(file, filename, resolved_content_type)

    if resolved_content_type == DEFAULT_CONTENT_TYPE:
        raise EnfermerIAError(
            "Unable to infer content_type from the provided file. Pass content_type explicitly or provide a filename/path with a supported image extension."
        )

    return ResolvedAnalyzeFile(
        file_bytes=file_bytes,
        filename=resolved_filename,
        content_type=resolved_content_type,
    )
