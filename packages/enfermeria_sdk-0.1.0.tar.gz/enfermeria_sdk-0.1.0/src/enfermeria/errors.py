from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(slots=True)
class EnfermerIAErrorContext:
    status_code: int | None = None
    endpoint: str | None = None
    api_message: str | None = None
    job_id: str | None = None
    cause: Exception | None = None


class EnfermerIAError(Exception):
    def __init__(self, message: str, context: EnfermerIAErrorContext | None = None) -> None:
        super().__init__(message)
        context = context or EnfermerIAErrorContext()
        self.status_code = context.status_code
        self.endpoint = context.endpoint
        self.api_message = context.api_message
        self.job_id = context.job_id
        self.cause = context.cause


class EnfermerIAApiError(EnfermerIAError):
    pass


class EnfermerIATimeoutError(EnfermerIAError):
    pass


class EnfermerIAUploadError(EnfermerIAError):
    pass


class EnfermerIAJobError(EnfermerIAError):
    pass
