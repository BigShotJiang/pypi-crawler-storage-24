from __future__ import annotations

import json
import socket
from dataclasses import dataclass
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .errors import (
    EnfermerIAApiError,
    EnfermerIAErrorContext,
    EnfermerIATimeoutError,
    EnfermerIAUploadError,
)
from .utils import build_url, debug_log


@dataclass(slots=True)
class HttpClient:
    api_key: str
    base_url: str
    timeout_ms: int
    debug: bool = False

    def request_json(
        self,
        *,
        method: str,
        path: str,
        body: dict[str, Any] | None = None,
        timeout_ms: int | None = None,
    ) -> Any:
        url = build_url(self.base_url, path)
        payload = None if body is None else json.dumps(body).encode("utf-8")
        request = Request(
            url,
            method=method,
            data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                **({"Content-Type": "application/json"} if payload is not None else {}),
            },
        )

        debug_log(self.debug, "request", {"method": method, "url": url})

        try:
            with urlopen(request, timeout=(timeout_ms or self.timeout_ms) / 1000) as response:
                status_code = response.getcode()
                raw_body = response.read()
                parsed = self._parse_response(raw_body, response.headers.get_content_type())
        except HTTPError as error:
            parsed = self._parse_response(error.read(), error.headers.get_content_type() if error.headers else None)
            api_message = parsed.get("error") if isinstance(parsed, dict) else None
            raise EnfermerIAApiError(
                api_message or f"Request failed with status {error.code}.",
                EnfermerIAErrorContext(
                    status_code=error.code,
                    endpoint=url,
                    api_message=api_message,
                    cause=error,
                ),
            ) from error
        except (TimeoutError, socket.timeout) as error:
            raise EnfermerIATimeoutError(
                f"Request timed out after {timeout_ms or self.timeout_ms}ms.",
                EnfermerIAErrorContext(endpoint=url, cause=error),
            ) from error
        except URLError as error:
            if isinstance(error.reason, TimeoutError):
                raise EnfermerIATimeoutError(
                    f"Request timed out after {timeout_ms or self.timeout_ms}ms.",
                    EnfermerIAErrorContext(endpoint=url, cause=error),
                ) from error
            raise

        debug_log(self.debug, "response", {"method": method, "url": url, "status": status_code})

        if not isinstance(parsed, dict) or not parsed.get("success") or "data" not in parsed:
            raise EnfermerIAApiError(
                "Unexpected API response format.",
                EnfermerIAErrorContext(status_code=status_code, endpoint=url),
            )

        return parsed["data"]

    def upload(
        self,
        *,
        upload_url: str,
        file_bytes: bytes,
        content_type: str,
        timeout_ms: int | None = None,
    ) -> None:
        request = Request(
            upload_url,
            method="PUT",
            data=file_bytes,
            headers={"Content-Type": content_type},
        )

        debug_log(self.debug, "upload", {"url": upload_url, "contentType": content_type})

        try:
            with urlopen(request, timeout=(timeout_ms or self.timeout_ms) / 1000) as response:
                status_code = response.getcode()
                if status_code < 200 or status_code >= 300:
                    raise EnfermerIAUploadError(
                        f"Upload failed with status {status_code}.",
                        EnfermerIAErrorContext(status_code=status_code, endpoint=upload_url),
                    )
        except HTTPError as error:
            parsed = self._parse_response(error.read(), error.headers.get_content_type() if error.headers else None)
            api_message = parsed.get("error") if isinstance(parsed, dict) else None
            if not api_message and isinstance(parsed, str):
                api_message = parsed
            raise EnfermerIAUploadError(
                api_message or f"Upload failed with status {error.code}.",
                EnfermerIAErrorContext(
                    status_code=error.code,
                    endpoint=upload_url,
                    api_message=api_message,
                    cause=error,
                ),
            ) from error
        except (TimeoutError, socket.timeout) as error:
            raise EnfermerIATimeoutError(
                f"Upload timed out after {timeout_ms or self.timeout_ms}ms.",
                EnfermerIAErrorContext(endpoint=upload_url, cause=error),
            ) from error
        except URLError as error:
            if isinstance(error.reason, TimeoutError):
                raise EnfermerIATimeoutError(
                    f"Upload timed out after {timeout_ms or self.timeout_ms}ms.",
                    EnfermerIAErrorContext(endpoint=upload_url, cause=error),
                ) from error
            raise

    @staticmethod
    def _parse_response(raw_body: bytes, content_type: str | None) -> dict[str, Any] | str | None:
        if not raw_body:
            return None

        if content_type and "json" in content_type:
            return json.loads(raw_body.decode("utf-8"))

        text = raw_body.decode("utf-8")
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            return text
