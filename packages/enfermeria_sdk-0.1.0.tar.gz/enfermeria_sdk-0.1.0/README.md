# EnfermerIA Python SDK

SDK oficial de Python para consumir la API publica de EnfermerIA sin tener que montar manualmente el flujo de subida, creacion de jobs y polling.

## Requisitos

- Python `3.9+`
- Sin dependencias runtime externas

## Instalacion

### Instalacion local desde ruta del disco

Desde otro proyecto consumidor:

```bash
pip install C:\ruta\al\repo\sdk\python
```

O con una ruta relativa:

```bash
pip install ../EnfermerIA/sdk/python
```

### Desarrollo local en modo editable

```bash
cd sdk/python
pip install -e .
```

### Publicacion futura en PyPI

El paquete ya queda preparado para publicarse mas adelante como `enfermeria-sdk`, sin cambios estructurales grandes.

## Configuracion

```python
from enfermeria import EnfermerIAClient

client = EnfermerIAClient(
    api_key="YOUR_API_KEY",
    base_url="https://enfermer-ia.com/api",
    timeout_ms=30_000,
)
```

`base_url` acepta tanto la raiz del sitio (`https://enfermer-ia.com`) como la raiz de la API (`https://enfermer-ia.com/api`). Para local puedes usar `http://localhost:3000` o `http://localhost:3000/api`.

## Ejemplo minimo

```python
from pathlib import Path

from enfermeria import EnfermerIAClient

client = EnfermerIAClient(api_key="YOUR_API_KEY")

result = client.analyze_image_and_wait(
    file=Path("./talon.png"),
    clinical_context="Paciente con ulcera en talon",
)

print(result)
```

## Ejemplo paso a paso

```python
from pathlib import Path

from enfermeria import EnfermerIAClient

client = EnfermerIAClient(api_key="YOUR_API_KEY")

job = client.analyze_image(
    file=Path("./talon.png"),
    clinical_context="Paciente con ulcera en talon",
)

result = client.wait_for_job(job.job_id)
print(result)
```

## Inputs soportados para `file`

- `str` con ruta local
- `pathlib.Path`
- `bytes`
- `bytearray`
- `memoryview`

## Reglas de inferencia

### `filename`

El SDK intenta inferir `filename` en este orden:

1. `filename` explicito.
2. El nombre de la ruta local si `file` es `str` o `Path`.
3. Un fallback basado en el MIME, por ejemplo `upload.png`.
4. Si no hay pistas, `upload.bin`.

### `content_type`

El SDK intenta inferir `content_type` en este orden:

1. `content_type` explicito.
2. La extension de `filename`.
3. La extension de la ruta local si `file` es `str` o `Path`.
4. Fallback interno `application/octet-stream`.

Extensiones soportadas por inferencia:

- `png -> image/png`
- `jpg/jpeg -> image/jpeg`
- `webp -> image/webp`
- `gif -> image/gif`
- `bmp -> image/bmp`
- `tif/tiff -> image/tiff`

Si el SDK no puede inferir un MIME suficientemente claro, lanza un error explicito pidiendo `filename` o `content_type`.

## Metodos principales

- `get_upload_url()`
- `upload_file_to_signed_url()`
- `create_analysis_job()`
- `get_job()`
- `wait_for_job()`
- `analyze_image()`
- `analyze_image_and_wait()`

## Manejo de errores

```python
from enfermeria import EnfermerIAApiError, EnfermerIAClient, EnfermerIAJobError

client = EnfermerIAClient(api_key="YOUR_API_KEY")

try:
    result = client.analyze_image_and_wait(file="./talon.png")
    print(result)
except EnfermerIAApiError as error:
    print(error.status_code, error.endpoint, error.api_message)
except EnfermerIAJobError as error:
    print(error.job_id, error.api_message)
```

## Tipos devueltos

- `UploadUrlResponse`
- `AnalysisJobResponse`
- `GetJobResponse`
- `AnalyzeImageResponse`
- `WaitForJobOptions`

## Como probarlo contra produccion

```python
client = EnfermerIAClient(
    api_key="YOUR_API_KEY",
    base_url="https://enfermer-ia.com",
)
```

## Como probarlo contra localhost

```python
client = EnfermerIAClient(
    api_key="YOUR_API_KEY",
    base_url="http://localhost:3000",
)
```

## Ejemplos incluidos

- `examples/basic.py`
- `examples/analyze_and_wait.py`
- `examples/from_path.py`
- `examples/from_bytes.py`

## Desarrollo

```bash
cd sdk/python
python -m unittest discover -s tests
```
