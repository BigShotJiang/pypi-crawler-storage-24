from __future__ import annotations

import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from enfermeria import EnfermerIAClient
from enfermeria.errors import EnfermerIAApiError, EnfermerIAJobError, EnfermerIATimeoutError
from enfermeria.types import WaitForJobOptions


class FakeHttpClient:
    def __init__(self, responses: list[dict] | None = None, upload_error: Exception | None = None) -> None:
        self.responses = responses or []
        self.upload_error = upload_error
        self.requests: list[dict] = []
        self.uploads: list[dict] = []

    def request_json(self, *, method: str, path: str, body: dict | None = None, timeout_ms: int | None = None):
        self.requests.append({"method": method, "path": path, "body": body, "timeout_ms": timeout_ms})
        if not self.responses:
            raise AssertionError("No fake response configured")
        response = self.responses.pop(0)
        if isinstance(response, Exception):
            raise response
        return response

    def upload(self, *, upload_url: str, file_bytes: bytes, content_type: str, timeout_ms: int | None = None) -> None:
        if self.upload_error:
            raise self.upload_error
        self.uploads.append(
            {
                "upload_url": upload_url,
                "file_bytes": file_bytes,
                "content_type": content_type,
                "timeout_ms": timeout_ms,
            }
        )


class EnfermerIAClientTests(unittest.TestCase):
    def test_analyze_image_infers_from_path(self) -> None:
        with tempfile.TemporaryDirectory() as temp_dir:
            image_path = Path(temp_dir) / "talon.png"
            image_path.write_bytes(b"png-bytes")

            http_client = FakeHttpClient(
                responses=[
                    {
                        "upload_url": "https://upload.example.com/file",
                        "path": "uploads/talon.png",
                        "file_url": "https://cdn.example.com/talon.png",
                    },
                    {"job_id": "job_123", "status": "queued"},
                ]
            )
            client = EnfermerIAClient(api_key="test-key", http_client=http_client)

            job = client.analyze_image(file=image_path, clinical_context="Paciente con ulcera en talon")

            self.assertEqual(job.job_id, "job_123")
            self.assertEqual(http_client.requests[0]["body"]["filename"], "talon.png")
            self.assertEqual(http_client.requests[0]["body"]["contentType"], "image/png")
            self.assertEqual(http_client.uploads[0]["content_type"], "image/png")
            self.assertEqual(http_client.uploads[0]["file_bytes"], b"png-bytes")

    def test_analyze_image_infers_content_type_from_filename_for_bytes(self) -> None:
        http_client = FakeHttpClient(
            responses=[
                {
                    "upload_url": "https://upload.example.com/file",
                    "path": "uploads/talon.png",
                    "file_url": "https://cdn.example.com/talon.png",
                },
                {"job_id": "job_123", "status": "queued"},
            ]
        )
        client = EnfermerIAClient(api_key="test-key", http_client=http_client)

        client.analyze_image(file=b"png-bytes", filename="talon.png")

        self.assertEqual(http_client.requests[0]["body"]["contentType"], "image/png")

    def test_analyze_image_and_wait_returns_completed_result(self) -> None:
        http_client = FakeHttpClient(
            responses=[
                {
                    "upload_url": "https://upload.example.com/file",
                    "path": "uploads/talon.png",
                    "file_url": "https://cdn.example.com/talon.png",
                },
                {"job_id": "job_123", "status": "queued"},
                {"job_id": "job_123", "status": "processing", "result": None, "error_message": None},
                {
                    "job_id": "job_123",
                    "status": "completed",
                    "result": {"clinical_disclaimer": "demo", "clinical_disclaimer_title": "demo"},
                    "error_message": None,
                },
            ]
        )
        client = EnfermerIAClient(api_key="test-key", http_client=http_client)

        result = client.analyze_image_and_wait(
            file=b"png-bytes",
            filename="talon.png",
            wait_options=WaitForJobOptions(interval_ms=0, timeout_ms=1000),
        )

        self.assertEqual(result["clinical_disclaimer"], "demo")

    def test_wait_for_job_raises_job_error(self) -> None:
        http_client = FakeHttpClient(
            responses=[
                {
                    "job_id": "job_123",
                    "status": "error",
                    "result": None,
                    "error_message": "Analysis failed",
                }
            ]
        )
        client = EnfermerIAClient(api_key="test-key", http_client=http_client)

        with self.assertRaises(EnfermerIAJobError):
            client.wait_for_job("job_123", interval_ms=0, timeout_ms=100)

    def test_wait_for_job_raises_timeout(self) -> None:
        http_client = FakeHttpClient(
            responses=[
                {"job_id": "job_123", "status": "processing", "result": None, "error_message": None},
                {"job_id": "job_123", "status": "processing", "result": None, "error_message": None},
                {"job_id": "job_123", "status": "processing", "result": None, "error_message": None},
            ]
        )
        client = EnfermerIAClient(api_key="test-key", http_client=http_client)

        original_get_job = client.get_job
        timestamps = iter([0.0, 0.2, 0.4])

        def fake_get_job(job_id: str):
            return original_get_job(job_id)

        client.get_job = fake_get_job  # type: ignore[method-assign]

        original_monotonic = time.monotonic
        time.monotonic = lambda: next(timestamps)
        try:
            with self.assertRaises(EnfermerIATimeoutError):
                client.wait_for_job("job_123", interval_ms=0, timeout_ms=100)
        finally:
            time.monotonic = original_monotonic

    def test_missing_file_path_raises_clear_error(self) -> None:
        client = EnfermerIAClient(api_key="test-key", http_client=FakeHttpClient())

        with self.assertRaisesRegex(Exception, "File not found at path"):
            client.analyze_image(file="./does-not-exist.png")

    def test_ambiguous_bytes_require_content_type_or_filename(self) -> None:
        client = EnfermerIAClient(api_key="test-key", http_client=FakeHttpClient())

        with self.assertRaisesRegex(Exception, "Unable to infer content_type"):
            client.analyze_image(file=b"raw-bytes")

    def test_api_error_bubbles_up(self) -> None:
        http_client = FakeHttpClient(responses=[EnfermerIAApiError("Bad request")])
        client = EnfermerIAClient(api_key="test-key", http_client=http_client)

        with self.assertRaises(EnfermerIAApiError):
            client.get_upload_url(filename="talon.png", content_type="image/png")


if __name__ == "__main__":
    unittest.main()
