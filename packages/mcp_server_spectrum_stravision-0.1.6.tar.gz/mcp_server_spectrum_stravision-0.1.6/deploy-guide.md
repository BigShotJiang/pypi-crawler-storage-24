# 光谱 MCP 服务器部署指南

## 部署到云服务器

### 1. 上传代码到服务器

```bash
# 在本地打包代码
cd D:\stravision\Stravision-IOT-PlatForm\mcpserver_spectrum
tar -czf mcpserver_spectrum.tar.gz .

# 上传到服务器（使用 scp 或 FTP）
scp mcpserver_spectrum.tar.gz root@8.153.175.190:/opt/
```

### 2. 在服务器上解压并安装依赖

```bash
# SSH 登录到服务器
ssh root@8.153.175.190

# 解压代码
cd /opt
tar -xzf mcpserver_spectrum.tar.gz -C mcpserver_spectrum
cd mcpserver_spectrum

# 安装 Python 和 uv（如果未安装）
curl -LsSf https://astral.sh/uv/install.sh | sh

# 安装依赖
uv pip install -e .
```

### 3. 配置环境变量

创建 `.env` 文件：

```bash
cat > .env << 'EOF'
# MQTT 配置（已在代码中硬编码，可选）
MQTT_BROKER=be18721454da4600b14a92424bb1181c.s1.eu.hivemq.cloud
MQTT_PORT=8883
MQTT_TOPIC=meimefarm/Spectrum
MQTT_USER=meimeifarm
MQTT_PASSWORD=Meimei83036666

# MCP 服务器配置
MCP_HOST=0.0.0.0
PORT=8000
MCP_TRANSPORT=sse
EOF
```

### 4. 使用 systemd 创建服务（推荐）

```bash
cat > /etc/systemd/system/spectrum-mcp.service << 'EOF'
[Unit]
Description=Spectrum MCP Server
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/mcpserver_spectrum
Environment="PATH=/root/.local/bin:/usr/local/bin:/usr/bin:/bin"
EnvironmentFile=/opt/mcpserver_spectrum/.env
ExecStart=/root/.local/bin/uv run python src/mcp_server_spectrum/server.py
Restart=always
RestartSec=10

[Install]
WantedBy=multi-user.target
EOF

# 启动服务
systemctl daemon-reload
systemctl enable spectrum-mcp
systemctl start spectrum-mcp

# 查看状态
systemctl status spectrum-mcp

# 查看日志
journalctl -u spectrum-mcp -f
```

### 5. 使用 screen 或 nohup（简单方式）

```bash
# 使用 screen
screen -S spectrum-mcp
cd /opt/mcpserver_spectrum
uv run python src/mcp_server_spectrum/server.py
# 按 Ctrl+A, D 退出 screen

# 或使用 nohup
cd /opt/mcpserver_spectrum
nohup uv run python src/mcp_server_spectrum/server.py > spectrum-mcp.log 2>&1 &
```

### 6. 验证服务

```bash
# 检查端口是否监听
netstat -tlnp | grep 8000

# 测试 SSE 连接
curl -N http://8.153.175.190:8000/sse

# 测试工具调用（需要先建立 SSE 会话）
curl -X POST http://8.153.175.190:8000/messages \
  -H "Content-Type: application/json" \
  -d '{"jsonrpc":"2.0","method":"get_all_spectrum","params":{},"id":1}'
```

## 防火墙配置

确保服务器防火墙允许 8000 端口：

```bash
# CentOS/RHEL
firewall-cmd --permanent --add-port=8000/tcp
firewall-cmd --reload

# Ubuntu/Debian
ufw allow 8000/tcp
ufw reload

# 阿里云/腾讯云：在控制台安全组中添加规则
```

## 故障排查

### 查看日志
```bash
# systemd 服务
journalctl -u spectrum-mcp -n 100 --no-pager

# nohup
tail -f /opt/mcpserver_spectrum/spectrum-mcp.log
```

### 常见问题

1. **MQTT 连接失败**：检查网络和凭据
2. **端口被占用**：修改 PORT 环境变量
3. **权限问题**：确保运行用户有读写权限

## 更新部署

```bash
# 停止服务
systemctl stop spectrum-mcp

# 更新代码
cd /opt/mcpserver_spectrum
git pull  # 或重新上传

# 重启服务
systemctl start spectrum-mcp
```
