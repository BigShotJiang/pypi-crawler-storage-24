import json
import threading
import time
import logging
import os
from mcp.server.fastmcp import FastMCP
import paho.mqtt.client as mqtt
import argparse
import sys

# basic logging configuration
logging.basicConfig(level=logging.DEBUG, format='[%(levelname)s] %(message)s')

# --- Configuration (edit as needed) ---
# NOTE: It is recommended to use environment variables for sensitive data.
MQTT_BROKER = os.environ.get("MQTT_BROKER", "be18721454da4600b14a92424bb1181c.s1.eu.hivemq.cloud")
MQTT_PORT = int(os.environ.get("MQTT_PORT", 8883))
MQTT_TOPIC = os.environ.get("MQTT_TOPIC", "meimefarm/Spectrum")
MQTT_USER = os.environ.get("MQTT_USER", "meimeifarm")
MQTT_PASSWORD = os.environ.get("MQTT_PASSWORD", "Meimei83036666")

# Shared state updated by MQTT callback
latest_spectrum = {}

def _on_connect(client, userdata, flags, rc):
    if rc == 0:
        client.subscribe(MQTT_TOPIC)
        logging.info(f"[MQTT] Connected, subscribed to {MQTT_TOPIC}")
    else:
        logging.error(f"[MQTT] Connect failed rc={rc}")

def _on_message(client, userdata, msg):
    global latest_spectrum
    try:
        payload = msg.payload.decode('utf-8')
        data = json.loads(payload)
        if isinstance(data, dict):
            latest_spectrum = data
            # small log
            logging.debug(f"[MQTT] Received spectrum: {list(data.keys())}")
    except Exception as e:
        logging.error(f"[MQTT] Message parse error: {e}")

def start_mqtt():
    client = mqtt.Client()
    if MQTT_USER:
        client.username_pw_set(MQTT_USER, MQTT_PASSWORD)
    # If using TLS port, enable TLS (use default CA certs)
    if MQTT_PORT == 8883:
        try:
            client.tls_set()
        except Exception:
            pass

    client.on_connect = _on_connect
    client.on_message = _on_message

    try:
        client.connect(MQTT_BROKER, MQTT_PORT, keepalive=60)
    except Exception as e:
        logging.error(f"[MQTT] Connect error: {e}")
        return None

    client.loop_start()
    return client


# --- FastMCP server exposing spectrum ---
# Configure host/port for SSE transport via constructor
mcp = FastMCP(
    "Spectrum",
    host=os.environ.get("MCP_HOST", "0.0.0.0"),
    port=int(os.environ.get("PORT", 8000))
)

@mcp.resource("spectrum://latest")
def get_latest_spectrum() -> dict:
    """Return the latest spectrum payload received over MQTT."""
    return latest_spectrum

@mcp.tool()
def get_channel(name: str) -> int:
    """Get an individual channel value by key, e.g. 'channel1'."""
    return int(latest_spectrum.get(name, 0))
@mcp.resource("spectrum://channels")
def get_all_channels() -> dict:
    """Return all channel values as ints when possible.

    This resource returns the full latest spectrum payload. It will try to
    convert numeric-looking values to `int`, and leave other values as-is.
    """
    out = {}
    for k, v in latest_spectrum.items():
        try:
            out[k] = int(v)
        except Exception:
            out[k] = v
    return out
@mcp.tool()
def get_all_spectrum() -> dict:
    """Tool to return the full latest spectrum payload.

    Tries to convert numeric-looking values to `int`, leaves others as-is.
    """
    out = {}
    for k, v in latest_spectrum.items():
        try:
            out[k] = int(v)
        except Exception:
            out[k] = v
    return out
def main():
    parser = argparse.ArgumentParser(description='Spectrum MCP')
    parser.add_argument('--no-mqtt', action='store_true', help='Do not start MQTT client (for testing)')
    args = parser.parse_args()

    logging.info("Starting spectrum MCP server...")
    mqtt_client = None
    if not args.no_mqtt:
        mqtt_client = start_mqtt()

    try:
        raw_transport = os.environ.get('MCP_TRANSPORT', 'stdio')
        # accept some common alias values
        if raw_transport == 'http':
            transport = 'streamable-http'
        elif raw_transport == 'sse':
            transport = 'sse'
        else:
            transport = raw_transport
        logging.info(f"Starting MCP with transport={transport} (raw={raw_transport})")
        
        # Note: port/host are already configured in FastMCP constructor
        mcp.run(transport=transport)
    except KeyboardInterrupt:
        pass
    except Exception:
        logging.exception("MCP run failed")
        raise
    finally:
        if mqtt_client:
            mqtt_client.loop_stop()
            try:
                mqtt_client.disconnect()
            except Exception:
                pass

if __name__ == '__main__':
    main()
