#!/usr/bin/env python3
"""
Propose quelques fonctions et procédures outils pour le projet
"""

import importlib.resources
import json
import os.path
import re
import sys
import textwrap
from collections import Counter, OrderedDict
from configparser import ConfigParser
from datetime import date, datetime
from typing import Any, Iterable, List, Sequence, Tuple

import colorama
import keyboard

#from querycraft.logger import get_logger
from querycraft.security import SQLSecurityValidator

# paramètres des tableaux (affichage des tables)
MAX_TABLE_WIDTH = 160  # Largeur maximale autorisée (bordures comprises)
MIN_COLUMN_WIDTH = 8  # Permet d’afficher au moins « a… »


# keywords = ["select", "from", "where", "group by", "order by", "having", "limit",
#            "offset", "on", "using", "join", "inner", "outer", "left", "right", "full",
#            "cross", "natural", "union", "intersect", "except", "distinct",
#            "all", "as", "and", "or", "not", "in", "like", "between", "is",
#            "null", "true", "false", "asc", "desc", "case", "when", "then", "else", "end"]

keywords = [
    "select",
    "from",
    "where",
    "group by",
    "order by",
    "having",
    "limit",
    "offset",
]
keywords2 = [
    "on",
    "using",
    "join",
    "inner",
    "outer",
    "left",
    "right",
    "full",
    "cross",
    "natural",
    "union",
    "intersect",
    "except",
    "distinct",
    "all",
    "as",
    "and",
    "or",
    "not",
    "in",
    "like",
    "between",
    "is",
    "null",
    "true",
    "false",
    "asc",
    "desc",
    "case",
    "when",
    "then",
    "else",
    "end",
]

# ==================================================
# ============ Tools ===============================
# ==================================================


def highlight_keywords(text: str, keywords: list[str], type: str = "cap") -> str:
    if not text or not keywords:
        return text

    # Crée un pattern regex avec tous les mots-clés
    pattern = r"\b(" + "|".join(map(re.escape, keywords)) + r")\b"
    if type == "cap":
        return re.sub(
            pattern, lambda m: m.group(0).capitalize(), text, flags=re.IGNORECASE
        )
    else:
        # Remplace chaque mot trouvé par sa version en majuscules
        return re.sub(pattern, lambda m: m.group(0).upper(), text, flags=re.IGNORECASE)


def highlight_sql_keywords(text: str) -> str:
    text = highlight_keywords(text, keywords2, "cap")
    text = highlight_keywords(text, keywords, "up")
    return text


def count_lines(s: str) -> int:
    return len(s.splitlines())


def clear_line():
    if not sys.stdout.isatty():
        return
    sys.stdout.write("\033[F\033[2K")
    sys.stdout.flush()


def clear_terminal():
    # Windows
    if os.name == "nt":
        os.system("cls")
    # Unix/Linux/MacOS
    else:
        os.system("clear")


class Spinner:
    """
    Animation ASCII pour faire patienter en ligne de commande.

    Exemples d'utilisation :

    # Méthode 1 : Context manager (recommandé)
    with Spinner("Chargement en cours"):
        time.sleep(5)  # Votre traitement

    # Méthode 2 : Utilisation manuelle
    spinner = Spinner("Traitement")
    spinner.start()
    # ... votre code ...
    spinner.stop("Terminé !")

    # Méthode 3 : Comme décorateur
    @Spinner.decorator("Exécution de la requête")
    def ma_fonction():
        time.sleep(5)
    """

    SPINNERS = {
        "dots": ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"],
        "line": ["-", "\\", "|", "/"],
        "arrow": ["←", "↖", "↑", "↗", "→", "↘", "↓", "↙"],
        "dots2": ["⣾", "⣽", "⣻", "⢿", "⡿", "⣟", "⣯", "⣷"],
        "circle": ["◐", "◓", "◑", "◒"],
        "square": ["◰", "◳", "◲", "◱"],
        "bounce": ["⠁", "⠂", "⠄", "⠂"],
        "clock": [
            "🕐",
            "🕑",
            "🕒",
            "🕓",
            "🕔",
            "🕕",
            "🕖",
            "🕗",
            "🕘",
            "🕙",
            "🕚",
            "🕛",
        ],
        "moon": ["🌑", "🌒", "🌓", "🌔", "🌕", "🌖", "🌗", "🌘"],
        "earth": ["🌍", "🌎", "🌏"],
        "progress": ["▱▱▱▱▱", "▰▱▱▱▱", "▰▰▱▱▱", "▰▰▰▱▱", "▰▰▰▰▱", "▰▰▰▰▰"],
    }

    def __init__(self, message="Chargement", style="dots", color=None):
        """
        Args:
            message: Message à afficher
            style: Style de spinner ('dots', 'line', 'arrow', etc.)
            color: Couleur colorama (ex: colorama.Fore.CYAN)
        """
        self.message = message
        self.frames = self.SPINNERS.get(style, self.SPINNERS["dots"])
        self.color = color or colorama.Fore.CYAN
        self.stop_event = None
        self.thread = None
        self.idx = 0

    def _animate(self):
        """Animation dans un thread séparé"""
        import time

        while not self.stop_event.is_set():
            frame = self.frames[self.idx % len(self.frames)]
            text = f"\r{self.color}{frame}{colorama.Style.RESET_ALL} {self.message}..."
            sys.stdout.write(text)
            sys.stdout.flush()
            self.idx += 1
            time.sleep(0.1)

    def start(self):
        """Démarre l'animation"""
        if not sys.stdout.isatty():
            print(f"{self.message}...")
            return

        import threading

        self.stop_event = threading.Event()
        self.thread = threading.Thread(target=self._animate, daemon=True)
        self.thread.start()

    def stop(self, final_message=None):
        """
        Arrête l'animation

        Args:
            final_message: Message final à afficher (optionnel)
        """
        if not sys.stdout.isatty():
            if final_message:
                print(final_message)
            return

        if self.stop_event:
            self.stop_event.set()
        if self.thread:
            self.thread.join()

        # Effacer la ligne et afficher le message final
        sys.stdout.write("\r" + " " * 80 + "\r")
        if final_message:
            print(f"{colorama.Fore.GREEN}✓{colorama.Style.RESET_ALL} {final_message}")
        sys.stdout.flush()

    def __enter__(self):
        """Support du context manager"""
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Support du context manager"""
        if exc_type is None:
            self.stop(f"{self.message} terminé")
        else:
            self.stop(f"{self.message} échoué")
        return False

    @staticmethod
    def decorator(message="Traitement", style="dots"):
        """
        Décorateur pour ajouter un spinner à une fonction

        Exemple:
            @Spinner.decorator("Chargement des données")
            def load_data():
                time.sleep(5)
        """

        def decorator_wrapper(func):
            def wrapper(*args, **kwargs):
                with Spinner(message, style):
                    return func(*args, **kwargs)

            return wrapper

        return decorator_wrapper


def show_progress(current, total, message="Progression", bar_length=40):
    """
    Affiche une barre de progression en ligne de commande.

    Args:
        current: Valeur actuelle
        total: Valeur totale
        message: Message à afficher
        bar_length: Longueur de la barre

    Exemple:
        for i in range(100):
            show_progress(i + 1, 100, "Traitement")
            time.sleep(0.05)
    """
    if not sys.stdout.isatty():
        return

    percent = float(current) / total
    filled = int(bar_length * percent)
    bar = "█" * filled + "░" * (bar_length - filled)

    # Couleur en fonction du pourcentage
    if percent < 0.33:
        color = colorama.Fore.RED
    elif percent < 0.66:
        color = colorama.Fore.YELLOW
    else:
        color = colorama.Fore.GREEN

    text = f"\r{message}: {color}[{bar}]{colorama.Style.RESET_ALL} {percent * 100:.1f}% ({current}/{total})"
    sys.stdout.write(text)
    sys.stdout.flush()

    if current >= total:
        print()  # Nouvelle ligne à la fin


def wait_with_dots(seconds, message="Veuillez patienter"):
    """
    Affiche des points qui s'ajoutent pendant l'attente.

    Args:
        seconds: Nombre de secondes à attendre
        message: Message à afficher

    Exemple:
        wait_with_dots(5, "Connexion au serveur")
    """
    import time

    if not sys.stdout.isatty():
        print(f"{message}...")
        time.sleep(seconds)
        return

    for i in range(seconds):
        dots = "." * (i % 4)
        text = f"\r{message}{dots:<4}"
        sys.stdout.write(text)
        sys.stdout.flush()
        time.sleep(1)

    sys.stdout.write("\r" + " " * 80 + "\r")
    print(f"{colorama.Fore.GREEN}✓{colorama.Style.RESET_ALL} {message} terminé")


##########################################################################################################
##########################################################################################################
##########################################################################################################

# keywords = ["select", "from", "where", "group by", "order by", "having", "limit",
#            "offset", "on", "using", "join", "inner", "outer", "left", "right", "full",
#            "cross", "natural", "union", "intersect", "except", "distinct",
#            "all", "as", "and", "or", "not", "in", "like", "between", "is",
#            "null", "true", "false", "asc", "desc", "case", "when", "then", "else", "end"]

keywords = [
    "select",
    "from",
    "where",
    "group by",
    "order by",
    "having",
    "limit",
    "offset",
]
keywords2 = [
    "on",
    "using",
    "join",
    "inner",
    "outer",
    "left",
    "right",
    "full",
    "cross",
    "natural",
    "union",
    "intersect",
    "except",
    "distinct",
    "all",
    "as",
    "and",
    "or",
    "not",
    "in",
    "like",
    "between",
    "is",
    "null",
    "true",
    "false",
    "asc",
    "desc",
    "case",
    "when",
    "then",
    "else",
    "end",
]

colorama.just_fix_windows_console()
colorama.init(autoreset=True)


def colorize_sql(sql: str) -> str:
    placeholder_cache: dict[str, str] = {}

    KEYWORD_PATTERN = re.compile(
        r"\b(" + "|".join(re.escape(kw) for kw in keywords) + r")\b",
        flags=re.IGNORECASE,
    )

    KEYWORD_PATTERN2 = re.compile(
        r"\b(" + "|".join(re.escape(kw) for kw in keywords2) + r")\b",
        flags=re.IGNORECASE,
    )

    # Autorise n’importe quel contenu (sauf #) entre deux dièses.
    PLACEHOLDER_PATTERN = re.compile(r"#([^#]+)#")

    def placeholder_replacer(match: re.Match[str]) -> str:
        inner = match.group(1)
        token = f"__PLACEHOLDER_{len(placeholder_cache)}__"
        placeholder_cache[token] = (
            f"{colorama.Style.BRIGHT}{colorama.Fore.GREEN}{inner}{colorama.Style.RESET_ALL}"
        )
        return token  # on enlève les '#'

    def keyword_replacer(match: re.Match[str]) -> str:
        token = match.group(0)
        return f"{token.upper()}"

    def keyword_replacer2(match: re.Match[str]) -> str:
        token = match.group(0)
        if token == "SELECT":
            return f"{colorama.Style.BRIGHT}{colorama.Fore.CYAN}{token.upper()}{colorama.Style.RESET_ALL}"
        else:
            return f"\n  {colorama.Style.BRIGHT}{colorama.Fore.CYAN}{token.upper()}{colorama.Style.RESET_ALL}"

    def keyword_replacer3(match: re.Match[str]) -> str:
        token = match.group(0)
        if token == "SELECT":
            return f"{token.upper()}"
        else:
            return f"\n  {token.upper()}"

    def keyword2_replacer(match: re.Match[str]) -> str:
        token = match.group(0)
        return f"{token.capitalize()}"

    def keyword2_replacer2(match: re.Match[str]) -> str:
        token = match.group(0)
        return f"{colorama.Fore.CYAN}{token.capitalize()}{colorama.Style.RESET_ALL}"

    highlighted = KEYWORD_PATTERN.sub(
        keyword_replacer, SQLSecurityValidator.sanitize_sql_for_display(sql)
    )
    highlighted = KEYWORD_PATTERN2.sub(keyword2_replacer, highlighted)

    # 1) remplace temporairement les placeholders par des jetons
    highlighted = PLACEHOLDER_PATTERN.sub(placeholder_replacer, highlighted)
    # 2) colore les mots-clés sur le texte restant
    highlighted = KEYWORD_PATTERN.sub(keyword_replacer2, highlighted)
    highlighted = KEYWORD_PATTERN2.sub(keyword2_replacer2, highlighted)
    # 3) réinjecte les segments verts
    for token, colored_value in placeholder_cache.items():
        highlighted = highlighted.replace(token, colored_value)
    # 4) indente la partie verte
    highlighted = KEYWORD_PATTERN.sub(keyword_replacer3, highlighted)

    return highlighted


def markdown_to_html(markdown_text: str, add_style=False, classType="info") -> str:
    """
    Convertit du texte Markdown en HTML.

    Args:
        markdown_text: Texte au format Markdown
        add_style: Si True, ajoute des styles CSS de base pour un rendu élégant

    Returns:
        str: Code HTML généré

    Exemple:
        >>> md = "# Titre\\n\\nCeci est un **texte en gras**."
        >>> html = markdown_to_html(md)
        >>> print(html)
        <h1>Titre</h1>
        <p>Ceci est un <strong>texte en gras</strong>.</p>
    """
    try:
        import markdown
    except ImportError:
        # Fallback simple si markdown n'est pas installé
        return f"<pre>{markdown_text}</pre>"

    # Conversion Markdown → HTML avec extensions utiles
    html = markdown.markdown(
        markdown_text,
        extensions=[
            "extra",  # Tables, attributs, etc.
            "codehilite",  # Coloration syntaxique du code
            "fenced_code",  # Blocs de code avec ```
            "tables",  # Support des tableaux
            "nl2br",  # Retours à la ligne → <br>
        ],
    )

    if add_style:
        # Ajouter des styles CSS de base pour un rendu élégant
        styled_html = f"""
<div class="{classType}">
    {html}
</div>
"""
        return styled_html
    else:
        return html


def colorize_sql_html(sql: str) -> str:
    """
    Colore une requête SQL pour l'affichage HTML avec syntaxe highlighting.

    Args:
        sql: La requête SQL à formater

    Returns:
        str: Code HTML avec la requête SQL colorée

    Exemple:
        >>> colorize_sql_html("SELECT nom FROM etudiants WHERE age > 20")
        '<span class="sql-keyword">SELECT</span> nom <span class="sql-keyword">FROM</span> ...'
    """
    placeholder_cache: dict[str, str] = {}

    KEYWORD_PATTERN = re.compile(
        r"\b(" + "|".join(re.escape(kw) for kw in keywords) + r")\b",
        flags=re.IGNORECASE,
    )

    KEYWORD_PATTERN2 = re.compile(
        r"\b(" + "|".join(re.escape(kw) for kw in keywords2) + r")\b",
        flags=re.IGNORECASE,
    )

    # Autorise n'importe quel contenu (sauf #) entre deux dièses (pour les highlights)
    PLACEHOLDER_PATTERN = re.compile(r"#([^#]+)#")

    def placeholder_replacer(match: re.Match[str]) -> str:
        """Remplace les placeholders #...# par des tokens temporaires"""
        inner = match.group(1)
        token = f"__PLACEHOLDER_{len(placeholder_cache)}__"
        # Vert brillant pour les placeholders
        placeholder_cache[token] = (
            f'<span style="color:#28a745;font-weight:bold;">{inner}</span>'
        )
        return token

    def keyword_replacer(match: re.Match[str]) -> str:
        """Met en majuscules les mots-clés"""
        token = match.group(0)
        return f"{token.upper()}"

    def keyword_replacer2(match: re.Match[str]) -> str:
        """Colore les mots-clés principaux en bleu cyan et ajoute des retours à la ligne"""
        token = match.group(0)
        if token.upper() == "SELECT":
            return (
                f'<span style="color:#17a2b8;font-weight:bold;">{token.upper()}</span>'
            )
        else:
            return f'<br>&nbsp;&nbsp;<span style="color:#17a2b8;font-weight:bold;">{token.upper()}</span>'

    def keyword_replacer3(match: re.Match[str]) -> str:
        """Ajoute l'indentation sans couleur supplémentaire"""
        token = match.group(0)
        if token.upper() == "SELECT":
            return f"{token.upper()}"
        else:
            return f"<br>&nbsp;&nbsp;{token.upper()}"

    def keyword2_replacer(match: re.Match[str]) -> str:
        """Capitalise les mots-clés secondaires (fonctions SQL, etc.)"""
        token = match.group(0)
        return f"{token.capitalize()}"

    def keyword2_replacer2(match: re.Match[str]) -> str:
        """Colore les mots-clés secondaires en cyan"""
        token = match.group(0)
        return f'<span style="color:#17a2b8;">{token.capitalize()}</span>'

    # Étape 1 : Normalisation basique
    highlighted = KEYWORD_PATTERN.sub(
        keyword_replacer, SQLSecurityValidator.sanitize_sql_for_display(sql)
    )
    highlighted = KEYWORD_PATTERN2.sub(keyword2_replacer, highlighted)

    # Étape 2 : Protection des placeholders
    highlighted = PLACEHOLDER_PATTERN.sub(placeholder_replacer, highlighted)

    # Étape 3 : Coloration des mots-clés
    highlighted = KEYWORD_PATTERN.sub(keyword_replacer2, highlighted)
    highlighted = KEYWORD_PATTERN2.sub(keyword2_replacer2, highlighted)

    # Étape 4 : Réinjection des placeholders colorés
    for token, colored_value in placeholder_cache.items():
        highlighted = highlighted.replace(token, colored_value)

    # Étape 5 : Indentation finale
    highlighted = KEYWORD_PATTERN.sub(keyword_replacer3, highlighted)

    # Échapper les caractères HTML spéciaux qui n'ont pas été traités
    # (déjà fait via les spans, donc pas besoin de html.escape global)

    return highlighted


##########################################################################################################
##########################################################################################################
##########################################################################################################


def cadre(texte, symbole="=", output="txt", couleur=colorama.Fore.BLACK):
    """Affiche un texte encadré avec une couleur donnée.
    - '*' pour le niveau 1
    - '=' pour le niveau 2
    - '-' pour le niveau 3
    - autre caractère pour le niveau 4
    """
    s = ""
    if output == "txt":
        eg = symbole * 80
        leneg = len(eg)
        s += f"{couleur}{eg}\n"  # print(eg, end='\n')
        nmln = len(texte) + 2
        pre = int((leneg - nmln) / 2)
        post = leneg - nmln - pre
        for _ in range(pre):
            s += f"{symbole}"  # print(symbole, end='')
        s += f" {texte} "  # print(f" {couleur}{texte}{colorama.Style.RESET_ALL} ", end='')
        for _ in range(post):
            s += f"{symbole}"  # print(symbole, end='')
        # print('')
        # print(eg, end='\n')
        s += f"\n{eg}{colorama.Style.RESET_ALL}\n"  #
    elif output == "md":
        if symbole == "*":
            s += f"# {texte}"  # print(f"# {texte}")
        elif symbole == "=":
            s += f"## {texte}"  # print(f"## {texte}")
        elif symbole == "—" or symbole == "-":
            s += f"### {texte}"  # print(f"### {texte}")
        else:
            s += f"#### {texte}"  # print(f"#### {texte}")
    elif output == "html":
        if symbole == "*":
            s += f"<h1>{texte}</h1><br>"  # print(f"<h1>{texte}</h1>")
        elif symbole == "=":
            s += f"<h2>{texte}</h2><br>"  # print(f"<h2>{texte}</h2>")
        elif symbole == "—" or symbole == "-":
            s += f"<h3>{texte}</h3><br>"  # print(f"<h3>{texte}</h3>")
        else:
            s += f"<h4>{texte}</h4><br>"  # print(f"<h4>{texte}</h4>")
    s += "\n"  # print()
    return s


##########################################################################################################
##########################################################################################################
##########################################################################################################


def readConfigFile():
    # lecture du fichier de configuration
    cfg = ConfigParser()
    with importlib.resources.path("querycraft.config", "config-sbs.cfg") as log_file:
        if not os.path.exists(log_file):
            # print(f"Le fichier de configuration {log_file} n'existe pas. Création d'un fichier par défaut.")
            with importlib.resources.open_text(
                "querycraft.config", "config-sbs-std.cfg"
            ) as fichier:
                cfg.read_file(fichier)

            # Sauvegarder dans le fichier
            with importlib.resources.path(
                "querycraft.config", "config-sbs.cfg"
            ) as config_file:
                with open(config_file, "w") as f:
                    cfg.write(f)
        else:
            with log_file.open("r", encoding="utf-8") as fichier:
                cfg.read_file(fichier)

    return cfg


##########################################################################################################
##########################################################################################################
##########################################################################################################


def diff_dates_iso(date_iso1: str, date_iso2: str):
    d1 = date.fromisoformat(date_iso1)
    d2 = date.fromisoformat(date_iso2)
    age = abs(d2 - d1).days
    return age


##########################################################################################################
##########################################################################################################
##########################################################################################################


def getTemplate(templatefile: str) -> str:
    try:
        with importlib.resources.open_text(
            "querycraft.templates", templatefile
        ) as fichier:
            return fichier.read()
    except FileNotFoundError:
        print(f"Le fichier '{templatefile}' est introuvable.")
        return ""


##########################################################################################################
##########################################################################################################
##########################################################################################################


def getAge(date_iso: str) -> int:
    age = diff_dates_iso(date_iso, datetime.now().date().isoformat())
    return age


def loadCache(cacheName: str, duree=2) -> dict():
    cache = dict()
    cache2 = dict()
    # print(f"Chargement du cache {cacheName}")
    with importlib.resources.path("querycraft.cache", f"{cacheName}") as file:
        if existFile(file):
            with file.open("r", encoding="utf-8") as fichier:
                cache = json.load(fichier)
            # purge des valeurs trop anciennes
            for k, v in cache.items():
                (sql, date_creation) = v
                if getAge(date_creation) <= duree:
                    cache2[k] = v
                else:
                    pass
    return cache2


def saveCache(cacheName, cache, cle, val):
    # print(f"Sauvegarde du cache {cacheName}")
    cache[cle] = (val, datetime.now().date().isoformat())
    with importlib.resources.path("querycraft.cache", f"{cacheName}") as file:
        with file.open("w", encoding="utf-8") as fichier:
            json.dump(cache, fichier, ensure_ascii=False, indent=2)
    # print(f"Cache {cacheName} sauvegardé")


##########################################################################################################
##########################################################################################################
##########################################################################################################


def loadExos(codeex):
    exos = {}
    with importlib.resources.path("querycraft.exos", f"{codeex}.json") as file:
        if existFile(file):
            with file.open("r", encoding="utf-8") as fichier:
                exos = json.load(fichier)
        else:
            print(f"Exo {codeex} introuvable")
    return exos


def getQuestion(codeex, codeq):
    exos = {}
    with importlib.resources.path("querycraft.exos", f"{codeex}.json") as file:
        if existFile(file):
            with file.open("r", encoding="utf-8") as fichier:
                exos = json.load(fichier)
            if codeq in exos:
                (requete, intention, comment, type, instuctions) = exos[codeq]
                return (requete, intention, comment, type, instuctions)
            else:
                print(f"Question {codeq} introuvable")
                return None
        else:
            # print(f"Fichier {file} inexistant")
            print(f"Exo {codeex} introuvable")
            return None


def saveExos(codeex, exos):
    with importlib.resources.path("querycraft.exos", f"{codeex}.json") as file:
        with file.open("w", encoding="utf-8") as fichier:
            json.dump(exos, fichier, ensure_ascii=False, indent=2)
            print(f"Exo {codeex} sauvegardé")


##########################################################################################################
##########################################################################################################
##########################################################################################################


def wait_for_user(
    message: str = "Appuyez sur Entrée pour continuer", allow_quit: bool = True
) -> bool:
    """
    Attend une action de l'utilisateur (Entrée pour continuer, Ctrl+C pour quitter).

    Args:
        message: Message à afficher
        allow_quit: Si True, permet Ctrl+C pour quitter proprement

    Returns:
        bool: True si l'utilisateur veut continuer, False s'il veut quitter

    Exemple:
        >>> if not wait_for_user("Appuyez sur Entrée pour continuer"):
        ...     print("Arrêt demandé par l'utilisateur")
        ...     return
    """
    try:
        if allow_quit:
            prompt = f"{message} (ou Ctrl+C pour quitter)"
        else:
            prompt = message

        input(f"\n{colorama.Fore.CYAN}▶ {prompt}{colorama.Style.RESET_ALL} ")
        return True

    except KeyboardInterrupt:
        # Ctrl+C pressé
        print(
            f"\n{colorama.Fore.YELLOW}⚠ Arrêt demandé par l'utilisateur{colorama.Style.RESET_ALL}"
        )
        return False
    except EOFError:
        # Ctrl+D pressé (Unix) ou Ctrl+Z puis Entrée (Windows)
        print(
            f"\n{colorama.Fore.YELLOW}⚠ Fin de saisie détectée{colorama.Style.RESET_ALL}"
        )
        return False


def stopWithEscKey(
    mssg: str = "Appuyez sur ESC pour arrêter ou sur une autre touche pour continuer.",
) -> bool:
    """
    Fonction legacy - Utilisez wait_for_user() à la place.
    """
    print(mssg)
    # return keyboard.read_key() == 'esc'
    stop = False
    try:
        while True:
            # Attendre qu'une touche soit pressée
            event = keyboard.read_event()

            # Vérifier si la touche ESC est pressée
            if event.event_type == keyboard.KEY_DOWN:
                stop = event.name == "esc"
                break
    except KeyboardInterrupt:
        print(f"\n{colorama.Fore.YELLOW}⚠ Arrêt demandé{colorama.Style.RESET_ALL}")
        stop = True
    return stop


##########################################################################################################
##########################################################################################################
##########################################################################################################


def delEntete(string, char):
    first_index = string.find(char)
    if first_index == -1:
        return ""  # Le caractère n'est pas dans la chaîne
    second_index = string.find(char, first_index + 1)
    return string[second_index + 2 :]


##########################################################################################################
##########################################################################################################
##########################################################################################################


def existFile(f: str) -> bool:
    return os.path.isfile(f)


def deleteFile(f: str) -> None:
    if existFile(f):
        os.remove(f)


def existDir(d: str) -> bool:
    return os.path.exists(d)


##########################################################################################################
##########################################################################################################
##########################################################################################################


# == changer date d'un fichier
# touch -t 2006010000 tmp/s88581.ics
# ==
def modifDate(f: str) -> date:
    return date.fromtimestamp(os.stat(f).st_mtime)


def daysOld(f: str) -> int:
    """
    Calculate the number of days since the last modification of a file.

    Parameters:
    - f (str): The path to the file.

    Returns:
    - int: The number of days since the last modification.

    This function uses the `modifDate` function to get the last modification date of the file.
    It then calculates the difference between the current date and the modification date using the `date.today()` and `datetime.timedelta` functions.
    Finally, it returns the number of days as an integer.
    """
    n = date.today()
    d = modifDate(f)
    delta = n - d
    return delta.days


def bold_substring(string: str, substring: str) -> str:
    """
    This function takes a string and a substring as input, and returns a new string with the substring
    enclosed in ANSI escape codes for bold formatting.

    Parameters:
    - string (str): The original string.
    - substring (str): The substring to be bolded.

    Returns:
    - str: The new string with the substring bolded.

    "Example:
    ">>> bold_substring("Hello, World!", "World")
    "Hello, #\033[1mWorld\033[0m!"

    Pour les codes (mise en gras) : https://gist.github.com/fnky/458719343aabd01cfb17a3a4f7296797
    Voir aussi :
    - https://emojipedia.org/
    - https://unicode-explorer.com/

    """
    match = re.search(re.escape(substring), rf"{string}", re.IGNORECASE)
    coord = match.span()
    # return string[:coord[0]] + " #\033[1m" + substring + "\033[0m# " + string[coord[1]:]
    return string[: coord[0]] + " #" + substring + "# " + string[coord[1] :]


#################################################################################################
## Codes en partie générés par ChatGPT 5.2 Codex fev. 2026
#################################################################################################


def lignes_disparues(
    a: Sequence[Sequence[Any]], b: Sequence[Sequence[Any]]
) -> List[bool]:
    """
    True si la ligne de `a` n'apparaît pas dans `b`.
    """
    set_b = {tuple(row) for row in b}
    return [tuple(row) not in set_b for row in a]


def lignes_disparues2(
    a: Sequence[Sequence[Any]], b: Sequence[Sequence[Any]]
) -> List[bool]:
    cb = Counter(str(row) for row in b)
    result = []
    for row in a:
        t = str(row)
        if cb[t] > 0:
            cb[t] -= 1
            result.append(False)
        else:
            result.append(True)
    return result


def lignes_disparues3(
    a: Sequence[Sequence[Any]], b: Sequence[Sequence[Any]]
) -> List[bool]:
    """
    Indique si une ligne de `a` n'apparaît pas dans `b`.
    Les listes dans les cellules sont comparées indépendamment de leur ordre.

    Args:
        a: Premier ensemble de lignes
        b: Deuxième ensemble de lignes

    Returns:
        List[bool]: Liste de booléens (True = ligne disparue, False = ligne présente)

    Note:
        Cette version ignore les duplicata (utilise un set).
        Pour gérer les duplicata, utilisez lignes_disparues2().
    """
    set_b = {normalize_row_for_comparison(row) for row in b}
    return [normalize_row_for_comparison(row) not in set_b for row in a]


def normalize_row_for_comparison(row: Sequence[Any]) -> str:
    """
    Normalise une ligne pour la comparaison en traitant les listes indépendamment de leur ordre.

    Args:
        row: Une ligne de données (liste/tuple de valeurs)

    Returns:
        str: Représentation normalisée de la ligne

    Exemple:
        >>> normalize_row_for_comparison(['Alice', [3, 1, 2], 20])
        "('Alice', (1, 2, 3), 20)"
        >>> normalize_row_for_comparison(['Alice', [1, 2, 3], 20])
        "('Alice', (1, 2, 3), 20)"  # Même résultat !
    """
    normalized = []
    for cell in row:
        if isinstance(cell, list):
            # Trier la liste pour ignorer l'ordre
            # Convertir en tuple pour la rendre hashable
            try:
                normalized.append(tuple(sorted(cell)))
            except TypeError:
                # Si les éléments ne sont pas comparables (ex: types mixtes),
                # convertir en strings puis trier
                normalized.append(tuple(sorted(str(x) for x in cell)))
        elif isinstance(cell, set) or isinstance(cell, frozenset):
            # Convertir les ensembles en tuple trié
            normalized.append(tuple(sorted(cell)))
        else:
            # Valeurs scalaires : garder telles quelles
            normalized.append(cell)

    return str(tuple(normalized))


def lignes_disparues4(
    a: Sequence[Sequence[Any]], b: Sequence[Sequence[Any]]
) -> List[bool]:
    """
    Compare deux ensembles de lignes en tenant compte des duplicata.
    Les listes dans les cellules sont comparées indépendamment de leur ordre.

    Args:
        a: Premier ensemble de lignes
        b: Deuxième ensemble de lignes

    Returns:
        List[bool]: Liste de booléens (True = ligne disparue, False = ligne présente)

    Exemple:
        >>> a = [['Alice', [1, 2, 3]], ['Bob', [5, 4]]]
        >>> b = [['Alice', [3, 2, 1]], ['Charlie', [6]]]
        >>> lignes_disparues2(a, b)
        [False, True]  # Alice OK (ordre différent mais même contenu), Bob absent
    """
    cb = Counter(normalize_row_for_comparison(row) for row in b)
    result = []
    for row in a:
        t = normalize_row_for_comparison(row)
        if cb[t] > 0:
            cb[t] -= 1
            result.append(False)
        else:
            result.append(True)
    return result


#################################################################################################
## Codes en partie générés par ChatGPT 5.1 Codex nov. 2025
#################################################################################################


def normalize_rows(
    columns_ref: Sequence[str],
    columns_src: Sequence[str],
    rows_src: Iterable[Sequence[Any]],
) -> List[Tuple[Any, ...]]:
    """
    Réordonne les lignes de rows_src pour qu'elles suivent columns_ref.
    """
    print(f"normalize_rows(\n {columns_ref=},\n {columns_src=},\n {rows_src=})")
    # if len(columns_src) != len(set(columns_src)):
    #     raise ValueError("Les colonnes doivent être uniques par table.")

    # pos_src = {col: idx for idx, col in enumerate(columns_src)}
    pos_src = {}
    for i in range(len(columns_src)):
        for x in columns_src[i]:
            pos_src[x] = i
    print("pos_src:", pos_src)
    try:
        index_map = []
        for i in range(len(columns_ref)):
            c = columns_ref[i]
            for j in c:
                index_map.append(pos_src[j])
        print("index_map:", index_map)
        # index_map = [pos_src[col] for col in columns_ref]
    except KeyError as missing:
        raise ValueError(f"Colonne absente : {missing.args[0]!r}") from None

    normalized = []
    for ridx, row in enumerate(rows_src):
        normalized.append(tuple(row[idx] for idx in index_map))
    print(f"normalized:{normalized}")
    return normalized


# *****************************************************************************************


def normalize_col(name: str, table_prefixes: list[tuple[str, str]]) -> dict:
    """
    Normalise un nom de colonne et extrait son alias éventuel.
    Retourne {"expr": expression_normalisée, "alias": alias_normalisé_ou_None}
    """
    n = name.strip()

    # Extraire l'alias (AS alias ou juste un mot final après espace)
    alias = None
    as_match = re.search(r'\bAS\s+(["`\[]?\w+["`\]]?)\s*$', n, re.IGNORECASE)
    if as_match:
        alias = re.sub(r'["`\[\]]', "", as_match.group(1)).lower().strip()
        n = n[: as_match.start()].strip()

    # Supprimer les guillemets
    n = re.sub(r'["`\[\]]', "", n)

    # Supprimer les préfixes de table connus
    for table_name, alias_table in table_prefixes:
        for prefix in (alias_table, table_name):
            if prefix:
                n = re.sub(rf"(?i)^{re.escape(prefix)}\.", "", n)

    # Normaliser casse
    n = n.lower()

    # Normaliser espaces autour des parenthèses et virgules
    n = re.sub(r"\s*\(\s*", "(", n)
    n = re.sub(r"\s*\)\s*", ")", n)
    n = re.sub(r"\s*,\s*", ",", n)

    # Normaliser espaces autour des opérateurs
    n = re.sub(r"\s*\+\s*", "+", n)
    n = re.sub(r"\s*\-\s*", "-", n)
    n = re.sub(r"\s*\/\s*", "/", n)
    n = re.sub(r"\s*\*\s*", "*", n)

    # Supprimer les espaces multiples
    n = re.sub(r"\s+", " ", n).strip()

    return {"expr": n, "alias": alias}


def match(s1: set, s2: set) -> bool:
    return bool(s1 & s2)


def compare_column_names2(
    cols1: list[str], cols2: list[str], table_prefixes: list[tuple[str, str]]
):
    """
    Compare deux listes de colonnes après normalisation.
    Deux colonnes sont considérées identiques si :
      - leurs expressions normalisées sont égales, OU
      - l'une des deux a un alias qui correspond à l'expression ou l'alias de l'autre
    """
    norm1 = [normalize_col(c, table_prefixes) for c in cols1]
    norm2 = [normalize_col(c, table_prefixes) for c in cols2]

    def signatures(norm):
        """Retourne toutes les formes sous lesquelles une colonne peut être reconnue."""
        sigs = {norm["expr"]}
        if norm["alias"]:
            sigs.add(norm["alias"])
        return sigs

    sigs1 = [signatures(n) for n in norm1]
    sigs2 = [signatures(n) for n in norm2]

    # Construire les ensembles de colonnes matchées
    matched1 = set()
    matched2 = set()
    pairs = []

    for i, s1 in enumerate(sigs1):
        for j, s2 in enumerate(sigs2):
            if j not in matched2 and match(s1, s2):
                matched1.add(i)
                matched2.add(j)
                pairs.append((i, j))
                break

    only_in_1 = [(i, cols1[i]) for i in range(len(cols1)) if i not in matched1]
    only_in_2 = [(j, cols2[j]) for j in range(len(cols2)) if j not in matched2]

    # Vérifier l'ordre (sur les paires matchées)
    order_ok = all(i == j for i, j in pairs)

    return (
        sigs1,
        sigs2,
        {
            "identiques": not only_in_1 and not only_in_2,
            "ordre_ok": order_ok,
            "paires": [(cols1[i], cols2[j]) for i, j in pairs],
            "absentes_de_2": only_in_1,
            "absentes_de_1": only_in_2,
            "détail_norm_1": [(c, norm1[i]) for i, c in enumerate(cols1)],
            "détail_norm_2": [(c, norm2[j]) for j, c in enumerate(cols2)],
        },
    )


def print_rapport(rapport):
    print(f"Identiques : {'✅' if rapport['identiques'] else '❌'}")
    print(f"Ordre OK   : {'✅' if rapport['ordre_ok'] else '⚠️'}")

    if rapport["paires"]:
        print(f"\n{'Colonne Q1':<35} {'Colonne Q2':<35} Statut")
        print("-" * 80)
        for c1, c2 in rapport["paires"]:
            statut = "✅" if c1 == c2 else "〰️ normalisé"
            print(f"  {c1:<33} {c2:<33} {statut}")

    if rapport["absentes_de_2"]:
        print(f"\n❌ Absentes de Q2 : {rapport['absentes_de_2']}")
    if rapport["absentes_de_1"]:
        print(f"❌ Absentes de Q1 : {rapport['absentes_de_1']}")

    print("\nNormalisation Q1 :")
    for orig, norm in rapport["détail_norm_1"]:
        print(f"  {orig!r:35} → expr={norm['expr']!r}  alias={norm['alias']!r}")
    print("\nNormalisation Q2 :")
    for orig, norm in rapport["détail_norm_2"]:
        print(f"  {orig!r:35} → expr={norm['expr']!r}  alias={norm['alias']!r}")


# *****************************************************************************************


def normalize_cols(col_name: str) -> str:
    """
    - Met en minuscules
    - Supprime les préfixes séparés par un point
    - Gère les alias (ex :  SUM(t.amount) AS total → total)
    - Si pas d'alias, garde le dernier identifiant de l'expression
    """
    # 1. Retirer les espaces superflus
    col_name = col_name.strip()

    # 2. Détecter un alias explicite « AS alias »
    m = re.search(r"\s+AS\s+([^\s]+)$", col_name, flags=re.IGNORECASE)
    if m:
        base = m.group(1)  # l'alias devient le nom « propre »
    else:
        # 3. Pas d'alias : extraire le dernier identifiant
        #    - si c’est une fonction, on prend le contenu entre les parenthèses
        #    - sinon on prend le dernier segment après le point
        func_match = re.search(r"\b\w+\s*\(\s*([^\)]+)\s*\)", col_name)
        if func_match:
            # ex : SUM(schema.table.col) → schema.table.col
            inner = func_match.group(1)
            base = inner.split(".")[-1]
        else:
            base = col_name.split(".")[-1]

    return base.lower()


def compare_column_names(
    columns1: list[str], columns2: list[str], table_prefixes: list[tuple[str, str]] = []
) -> int:
    # Normalisation des colonnes
    cols1 = list(columns1)
    cols1 = [normalize_cols(c) for c in cols1]
    cols2 = list(columns2)
    cols2 = [normalize_cols(c) for c in cols2]

    # Vérifications structurelles minimales
    if len(cols1) != len(cols2):
        return (None, None, 0)
    if set(cols1) != set(cols2):
        return (None, None, 0)

    same_col_order = cols1 == cols2

    if same_col_order:
        return (cols1, cols2, 2)
    else:
        return (cols1, cols2, 1)


def compare_query_results_raw(
    columns1: Sequence[str],
    rows1: Iterable[Sequence[Any]],
    columns2: Sequence[str],
    rows2: Iterable[Sequence[Any]],
    table_prefixes: list[tuple[str, str]] = [],
) -> int:
    """
    Compare deux tables de résultats SQL.

    :return: code {0,1,2,3,4}
        0 : différences de contenu
        1 : mêmes données, ordre des lignes ET des colonnes différents
        2 : mêmes données, même ordre des colonnes, ordre des lignes différent
        3 : mêmes données, même ordre des lignes, ordre des colonnes différent
        4 : mêmes données, même ordre des colonnes et des lignes
    """

    # log = get_logger("compare_query_results_raw")
    # log.info("Comparaison des résultats")
    # log.info(f"t1 {columns1} {rows1}")
    # log.info(f"t2 {columns2} {rows2}")

    (cols1, cols2, cmp_cols) = compare_column_names2(columns1, columns2, table_prefixes)
    # if cmp_cols == 0:
    #    return 0
    # same_col_order = cmp_cols == 2

    if not cmp_cols["identiques"]:
        cabs1 = [c[0] for c in cmp_cols["absentes_de_2"]]
        cabs2 = [c[0] for c in cmp_cols["absentes_de_1"]]
        # print(f"cabs1 {cabs1}")
        # print(f"cabs2 {cabs2}")
        if cabs1 == cabs2 and len(cabs1) + len(cmp_cols["paires"]) == len(columns1):
            return 0
        else:
            return -1
    same_col_order = cmp_cols["ordre_ok"]

    rows1 = list(rows1)
    rows2 = list(rows2)
    if len(rows1) != len(rows2):
        return 0

    norm_rows1 = normalize_rows(cols1, cols1, rows1)
    norm_rows2 = normalize_rows(cols1, cols2, rows2)

    same_row_order = norm_rows1 == norm_rows2
    if same_row_order:
        if same_col_order:
            return 4
        else:
            return 3

    # Égalité en ignorant l’ordre des lignes (multiset de tuples)
    # Hypothèse : chaque cellule est hashable (types SQL usuels).
    if Counter(norm_rows1) != Counter(norm_rows2):
        return 0

    return 2 if same_col_order else 1


#################################################################################################
## Fonctions auxiliaires pour les formats HTML et Markdown
#################################################################################################


def _format_table_html(headers, rows, dif=None):
    """Génère un tableau au format HTML."""
    lines = ['<table border="1" cellpadding="5" cellspacing="0">']

    # En-têtes
    lines.append("  <thead>")
    lines.append("    <tr>")
    for header in headers:
        lines.append(f"      <th>{header}</th>")
    lines.append("    </tr>")
    lines.append("  </thead>")

    # Corps du tableau
    lines.append("  <tbody>")
    for i, row in enumerate(rows):
        style = ""
        if dif:
            if dif[i]:
                style = ' style="background-color: #ffcccc;"'  # Rouge clair
            else:
                style = ' style="background-color: #ccffcc;"'  # Vert clair
        lines.append(f"    <tr{style}>")
        for value in row:
            cell_value = str(value if value is not None else "").replace("\n", "<br>")
            lines.append(f"      <td>{cell_value}</td>")
        lines.append("    </tr>")
    lines.append("  </tbody>")
    lines.append("</table>")

    return "\n".join(lines)


def _format_table_md(headers, rows, dif=None):
    """Génère un tableau au format Markdown."""
    lines = []

    # En-têtes
    header_line = "| " + " | ".join(str(h) for h in headers) + " |"
    lines.append(header_line)

    # Ligne de séparation
    separator = "| " + " | ".join("---" for _ in headers) + " |"
    lines.append(separator)

    # Lignes de données
    for i, row in enumerate(rows):
        # Note: Markdown ne supporte pas nativement les couleurs,
        # on peut ajouter un indicateur textuel si dif est fourni
        row_values = []
        for value in row:
            cell_value = str(value if value is not None else "").replace("\n", " ")
            row_values.append(cell_value)

        row_line = "| " + " | ".join(row_values) + " |"

        # Optionnel : ajouter un marqueur visuel pour les différences
        if dif and dif[i]:
            row_line += " ❌"  # Indicateur de différence
        elif dif and not dif[i]:
            row_line += " ✓"  # Indicateur de correspondance

        lines.append(row_line)

    return "\n".join(lines)


#################################################################################################
def truncate_rows(headers, rows, max_rows=15):
    """
    Tronque un tableau pour qu'il ne dépasse pas un certain nombre de lignes.
    Args:
        rows: Tableau à tronquer
        max_rows: Nombre maximum de lignes à conserver
        Returns: Tableau tronqué
    """
    res = rows.copy()
    msg = None
    if rows and max_rows and len(rows) > max_rows > 0:
        nbr = len(res)
        if nbr > max_rows:
            res = res[:max_rows]
            i = len(headers)
            res.append(["..." for i in range(i)])
            msg = f"Seuls les {max_rows} premiers enregistrements sont affichés."
    return (res, msg)


def format_table_1(
    headers,
    rows,
    dif=None,
    padding=2,
    inter=False,
    table_size=MAX_TABLE_WIDTH,
    min_col_width=MIN_COLUMN_WIDTH,
    output="txt",
):
    """
    Formate un tableau avec les données fournies.

    Args:
        headers: En-têtes des colonnes
        rows: Lignes de données
        dif: Liste de booléens pour indiquer les différences (True = rouge, False = vert)
        padding: Espacement supplémentaire pour les colonnes
        inter: Afficher des séparateurs entre les lignes
        table_size: Largeur maximale du tableau
        min_col_width: Largeur minimale des colonnes
        output: Format de sortie ('txt', 'html', 'md')

    Returns:
        str: Tableau formaté
    """
    if output == "html":
        return _format_table_html(headers, rows, dif)
    elif output == "md":
        return _format_table_md(headers, rows, dif)

    # Format texte (par défaut)
    # Calcule la largeur maximale pour chaque colonne
    col_widths = [
        max(len(str(value)) for value in column) for column in zip(headers, *rows)
    ]
    col_widths = [w + padding for w in col_widths]

    def format_row(row):
        return (
            "│ "
            + " ┆ ".join(
                str(value if value is not None else "").replace("\n", " ").ljust(width)
                for value, width in zip(row, col_widths)
            )
            + " │"
        )

    def format_row_hd(row):
        return (
            "│ "
            + " ┆ ".join(
                "\033[1m" + str(value).replace("\n", " ").ljust(width) + "\033[0m"
                for value, width in zip(row, col_widths)
            )
            + " │"
        )

    # Construire la ligne séparatrice
    separator0 = "┌─" + "─┬─".join("─" * width for width in col_widths) + "─┐"
    separator = "╞═" + "═╪═".join("═" * width for width in col_widths) + "═╡"
    separator2 = "├─" + "─┼─".join("─" * width for width in col_widths) + "─┤"
    separator3 = "└─" + "─┴─".join("─" * width for width in col_widths) + "─┘"

    # Générer le tableau complet
    lines = [separator0, format_row_hd(headers), separator]
    # for row in rows[:-1]:
    #     lines.append(format_row(row))
    #     if inter: lines.append(separator2)
    # if rows: lines.append(format_row(rows[-1]))
    # lines.append(separator3)

    for i, row in enumerate(rows[:-1]):
        if dif:
            if dif[i]:
                lines.append(
                    f"{colorama.Fore.RED}"
                    + format_row(row)
                    + f"{colorama.Style.RESET_ALL}"
                )
            else:
                lines.append(
                    f"{colorama.Fore.GREEN}"
                    + format_row(row)
                    + f"{colorama.Style.RESET_ALL}"
                )
        else:
            lines.append(format_row(row))
        if inter:
            lines.append(separator2)
    if rows:
        if dif:
            if dif[-1]:
                lines.append(
                    f"{colorama.Fore.RED}"
                    + format_row(rows[-1])
                    + f"{colorama.Style.RESET_ALL}"
                )
            else:
                lines.append(
                    f"{colorama.Fore.GREEN}"
                    + format_row(rows[-1])
                    + f"{colorama.Style.RESET_ALL}"
                )
        else:
            lines.append(format_row(rows[-1]))
    lines.append(separator3)

    return "\n".join(lines)


#################################################################################################


def fit_text(text, width):
    """Ajuste le texte à la largeur demandée en ajoutant éventuellement une ellipse."""
    text = str(text)
    if len(text) <= width:
        return text.ljust(width)
    if width == 1:
        return "…"
    if width == 2:
        return text[0] + "…"
    return text[: width - 1] + "…"


def clamp_widths(
    widths, max_data_width, table_size=MAX_TABLE_WIDTH, min_col_width=MIN_COLUMN_WIDTH
):
    """Réduit les largeurs de colonnes jusqu’à rentrer dans la contrainte globale."""
    total = sum(widths)
    if total <= max_data_width:
        return widths

    reducible = sum(max(0, w - min_col_width) for w in widths)
    deficit = total - max_data_width
    if reducible < deficit:
        raise ValueError(
            f"Impossible de faire tenir le tableau dans {table_size} caractères "
            "(trop de colonnes ou contenus trop larges)."
        )

    widths = widths[:]
    while deficit > 0:
        for idx in sorted(range(len(widths)), key=lambda i: widths[i], reverse=True):
            if widths[idx] > min_col_width:
                widths[idx] -= 1
                deficit -= 1
                if deficit == 0:
                    break
    return widths


def format_table_2(
    headers,
    rows,
    dif=None,
    padding=1,
    inter=False,
    table_size=MAX_TABLE_WIDTH,
    min_col_width=MIN_COLUMN_WIDTH,
    output="txt",
):
    """
    Formate un tableau avec ajustement automatique des largeurs de colonnes.

    Args:
        headers: En-têtes des colonnes
        rows: Lignes de données
        dif: Liste de booléens pour indiquer les différences (True = rouge, False = vert)
        padding: Espacement supplémentaire pour les colonnes
        inter: Afficher des séparateurs entre les lignes
        table_size: Largeur maximale du tableau
        min_col_width: Largeur minimale des colonnes
        output: Format de sortie ('txt', 'html', 'md')

    Returns:
        str: Tableau formaté
    """
    if output == "html":
        return _format_table_html(headers, rows, dif)
    elif output == "md":
        return _format_table_md(headers, rows, dif)

    # Format texte (par défaut)
    n_cols = len(headers)
    max_data_width = table_size - (3 * n_cols + 1)
    if max_data_width < n_cols * min_col_width:
        raise ValueError(
            f"Trop de colonnes pour une largeur de {table_size} caractères."
        )

    # Largeurs brutes (en tenant compte du padding)
    raw_widths = [
        max(len(str(value).replace("\n", " ")) for value in column) + padding
        for column in zip(headers, *rows)
    ]

    col_widths = clamp_widths(raw_widths, max_data_width, table_size, min_col_width)

    def format_row(row):
        cells = [
            fit_text(str(value if value is not None else "").replace("\n", " "), width)
            for value, width in zip(row, col_widths)
        ]
        return "│ " + " ┆ ".join(cells) + " │"

    def format_row_hd(row):
        cells = [
            "\033[1m" + fit_text(str(value).replace("\n", " "), width) + "\033[0m"
            for value, width in zip(row, col_widths)
        ]
        return "│ " + " ┆ ".join(cells) + " │"

    separator0 = "┌─" + "─┬─".join("─" * width for width in col_widths) + "─┐"
    separator = "╞═" + "═╪═".join("═" * width for width in col_widths) + "═╡"
    separator2 = "├─" + "─┼─".join("─" * width for width in col_widths) + "─┤"
    separator3 = "└─" + "─┴─".join("─" * width for width in col_widths) + "─┘"

    # if dif is None:
    #    dif = [False] * len(rows)
    # Construction des lignes du tableau
    lines = [separator0, format_row_hd(headers), separator]
    for i, row in enumerate(rows[:-1]):
        if dif:
            if dif[i]:
                lines.append(
                    f"{colorama.Fore.RED}"
                    + format_row(row)
                    + f"{colorama.Style.RESET_ALL}"
                )
            else:
                lines.append(
                    f"{colorama.Fore.GREEN}"
                    + format_row(row)
                    + f"{colorama.Style.RESET_ALL}"
                )
        else:
            lines.append(format_row(row))
        if inter:
            lines.append(separator2)
    if rows:
        if dif:
            if dif[-1]:
                lines.append(
                    f"{colorama.Fore.RED}"
                    + format_row(rows[-1])
                    + f"{colorama.Style.RESET_ALL}"
                )
            else:
                lines.append(
                    f"{colorama.Fore.GREEN}"
                    + format_row(rows[-1])
                    + f"{colorama.Style.RESET_ALL}"
                )
        else:
            lines.append(format_row(rows[-1]))
    lines.append(separator3)

    return "\n".join(lines)


#################################################################################################


def wrap_cell(text, width):
    """Retourne une liste de lignes de longueur ≤ width pour le contenu donné."""
    text = str(text)
    if not text:
        return [""]
    lines = []
    for raw_line in text.splitlines() or [""]:
        wrapped = textwrap.wrap(
            raw_line,
            width=width,
            drop_whitespace=False,
            replace_whitespace=False,
            break_long_words=True,
        )
        lines.extend(wrapped or [""])
    return lines


def format_table_3(
    headers,
    rows,
    dif=None,
    padding=1,
    inter=False,
    table_size=MAX_TABLE_WIDTH,
    min_col_width=MIN_COLUMN_WIDTH,
    output="txt",
):
    """
    Formate un tableau avec retour à la ligne dans les cellules.

    Args:
        headers: En-têtes des colonnes
        rows: Lignes de données
        dif: Liste de booléens pour indiquer les différences (True = rouge, False = vert)
        padding: Espacement supplémentaire pour les colonnes
        inter: Afficher des séparateurs entre les lignes
        table_size: Largeur maximale du tableau
        min_col_width: Largeur minimale des colonnes
        output: Format de sortie ('txt', 'html', 'md')

    Returns:
        str: Tableau formaté
    """
    if output == "html":
        return _format_table_html(headers, rows, dif)
    elif output == "md":
        return _format_table_md(headers, rows, dif)

    # Format texte (par défaut)
    n_cols = len(headers)
    if n_cols == 0:
        return ""

    # Largeur disponible pour les seules données (sans bordures ni espaces)
    max_data_width = table_size - (3 * n_cols + 1)
    if max_data_width < n_cols * min_col_width:
        raise ValueError(
            f"Trop de colonnes pour une largeur totale de {table_size} caractères."
        )

    raw_widths = [
        max(len(str(value)) for value in column) + padding
        for column in zip(headers, *rows)
    ]
    col_widths = clamp_widths(raw_widths, max_data_width)

    def format_physical_lines(row):
        wrapped_cells = [
            wrap_cell(value, width) for value, width in zip(row, col_widths)
        ]
        row_height = max(len(cell) for cell in wrapped_cells)
        physical_lines = []
        for line_idx in range(row_height):
            cells = [
                (cell[line_idx] if line_idx < len(cell) else "").ljust(width)
                for cell, width in zip(wrapped_cells, col_widths)
            ]
            physical_lines.append("│ " + " ┆ ".join(cells) + " │")
        return physical_lines

    def format_physical_lines_hd(row):
        wrapped_cells = [
            wrap_cell(value, width) for value, width in zip(row, col_widths)
        ]
        row_height = max(len(cell) for cell in wrapped_cells)
        physical_lines = []
        for line_idx in range(row_height):
            cells = [
                "\033[1m"
                + (cell[line_idx] if line_idx < len(cell) else "").ljust(width)
                + "\033[0m"
                for cell, width in zip(wrapped_cells, col_widths)
            ]
            physical_lines.append("│ " + " ┆ ".join(cells) + " │")
        return physical_lines

    separator0 = "┌─" + "─┬─".join("─" * width for width in col_widths) + "─┐"
    separator = "╞═" + "═╪═".join("═" * width for width in col_widths) + "═╡"
    separator2 = "├─" + "─┼─".join("─" * width for width in col_widths) + "─┤"
    separator3 = "└─" + "─┴─".join("─" * width for width in col_widths) + "─┘"

    lines = [separator0]
    lines.extend(format_physical_lines_hd(headers))
    lines.append(separator)

    # for row in rows[:-1]:
    #     lines.extend(format_physical_lines(row))
    #     if inter: lines.append(separator2)
    # if rows:
    #     lines.extend(format_physical_lines(rows[-1]))
    # lines.append(separator3)

    for i, row in enumerate(rows[:-1]):
        lst = format_physical_lines(row)
        for l in lst:
            if dif:
                if dif[i]:
                    lines.append(
                        f"{colorama.Fore.RED}" + l + f"{colorama.Style.RESET_ALL}"
                    )
                else:
                    lines.append(
                        f"{colorama.Fore.GREEN}" + l + f"{colorama.Style.RESET_ALL}"
                    )
            else:
                lines.append(l)
        if inter:
            lines.append(separator2)
    if rows:
        lst = format_physical_lines(rows[-1])
        for l in lst:
            if dif:
                if dif[-1]:
                    lines.append(
                        f"{colorama.Fore.RED}" + l + f"{colorama.Style.RESET_ALL}"
                    )
                else:
                    lines.append(
                        f"{colorama.Fore.GREEN}" + l + f"{colorama.Style.RESET_ALL}"
                    )
            else:
                lines.append(l)
    lines.append(separator3)

    return "\n".join(lines)


#################################################################################################


def group_table_as_rows(
    columns: Sequence[str],
    data_rows: Iterable[Sequence[Any]],
    group_cols: Sequence[str] | None = None,
):
    """
    Regroupe des lignes (listes/tuples) et renvoie une liste de lignes.

    - `columns` : noms des colonnes (ordre fixe).
    - `data_rows` : lignes alignées sur `columns`.
    - `group_cols` : colonnes servant de clé (scalaires dans le résultat).
      Les autres colonnes deviennent des listes de valeurs.

    Retour :
        list[list[Any]]
    """
    cols = list(columns)
    rows = [list(row) for row in data_rows]
    if not rows:
        return []

    group_cols = list(group_cols or [])
    col_index = {col: idx for idx, col in enumerate(cols)}

    # Vérifications simples
    for col in group_cols:
        if col not in col_index:
            raise ValueError(f"Colonne inconnue pour le regroupement : {col!r}")

    grouped = OrderedDict()  # clé -> listes de lignes complètes
    for ridx, row in enumerate(rows):
        if len(row) != len(cols):
            raise ValueError(
                f"Ligne {ridx} : attendu {len(cols)} valeurs, reçu {len(row)}."
            )
        key = tuple(row[col_index[col]] for col in group_cols)
        grouped.setdefault(key, []).append(row)

    result = []
    for key, matching_rows in grouped.items():
        out_row = []
        for col in cols:
            idx = col_index[col]
            if col in group_cols:
                # valeur scalaire (issue de la clé)
                out_row.append(key[group_cols.index(col)])
            else:
                # liste de toutes les valeurs correspondantes
                out_row.append([r[idx] for r in matching_rows])
        result.append(out_row)

    return result


#################################################################################################
#################################################################################################
#################################################################################################


if __name__ == "__main__":
    headers = ["Produit", "Quantité", "Prix (€)", "Description"]
    rows = [
        [
            "Pommes",
            12,
            3.40,
            "Variété Gala, croquante et très sucrée. Idéale pour les tartes et compotes.",
        ],
        ["Oranges", 8, 4.10, "Riche en vitamine C.\nConvient bien pour les jus frais."],
        [
            "Bananes",
            15,
            2.80,
            "Origine Guadeloupe. Bien mûres, parfaites pour les smoothies ou les desserts.",
        ],
    ]

    print(format_table_1(headers, rows))
    print(format_table_2(headers, rows))
    print(format_table_3(headers, rows, inter=True))

    cols = ["ville", "jour", "ventes", "devise"]
    data = [
        ["Paris", "Lundi", 12, "EUR"],
        ["Paris", "Mardi", 18, "EUR"],
        ["Lyon", "Lundi", 9, "EUR"],
        ["Paris", "Mercredi", 22, "EUR"],
        ["Lyon", "Mardi", 11, "EUR"],
    ]

    rows = group_table_as_rows(cols, data, group_cols=["ville"])
    print(format_table_3(headers, rows))
    # for line in rows:
    #    print(line)

    cols_a = ["id", "nom", "age"]
    rows_a = [
        (1, "Ana", 30),
        (2, "Ben", 41),
    ]
    cols_b = ["id", "age", "nom"]
    rows_b = [
        (1, 30, "Ana"),
        (2, 41, "Ben"),
    ]
    cols_c = ["id", "n", "age"]
    rows_c = [
        (2, "Ben", 41),
        (1, "Ana", 30),
    ]

    data2 = [
        ["Paris", "Lundi", 12, "EUR"],
        ["Lyon", "Lundi", 9, "EUR"],
        ["Paris", "Mercredi", 22, "EUR"],
    ]
    """
        0 : différences de contenu
        1 : mêmes données, ordre des lignes ET des colonnes différents
        2 : mêmes données, même ordre des colonnes, ordre des lignes différent
        3 : mêmes données, même ordre des lignes, ordre des colonnes différent
        4 : mêmes données, même ordre des colonnes et des lignes

    """
    print(compare_query_results_raw(cols_b, rows_b, cols_c, rows_c, []))  # 1
    print(compare_query_results_raw(cols_a, rows_a, cols_c, rows_c, []))  # 2
    print(compare_query_results_raw(cols_a, rows_a, cols_b, rows_b, []))  # 3
    print(compare_query_results_raw(cols_a, rows_a, cols_a, rows_a, []))  # 4

    dif = lignes_disparues(data, data2)
    print(dif)
    print(format_table_2(cols, data, dif, output="md"))

    # --- Exemple ---
    cols1 = [
        "orders.id",
        "SUM( total_ht ) AS total",
        "COUNT(*)",
        "t1.client_name AS client",
        "3*AVG((noteex+notecc)/2)-3 AS moyenne",
    ]
    cols2 = [
        "total",  # alias seul
        "t1.id",
        "nb",  # sans alias, expression brute
        "client",  # alias seul
        "3 * AVG( (noteex + notecc) / 2) - 3",
    ]

    prefixes = [
        ("orders", "t1"),
        ("clients", "t2"),
    ]

    (c1, c2, rapport) = compare_column_names2(cols1, cols2, prefixes)

    print(c1)
    print(c2)

    print_rapport(rapport)
