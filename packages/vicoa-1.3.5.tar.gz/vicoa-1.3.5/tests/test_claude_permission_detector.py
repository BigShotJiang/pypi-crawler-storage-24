from integrations.cli_wrappers.claude_code.detection.permission_detector import (
    PermissionDetector,
)


def test_permission_detector_extracts_mixed_menu_layout() -> None:
    detector = PermissionDetector()
    buffer_text = """
Do you want to make this edit to ask_user_question_panel.dart?
❯ 1. Yes

2. Yes, allow all edits during this session (shift+tab)
3. No
(esc to cancel)
"""

    result = detector.detect_and_extract(buffer_text)

    assert result.detected is True
    assert result.data is not None
    assert (
        result.data["question"]
        == "Do you want to make this edit to ask_user_question_panel.dart?"
    )
    assert result.data["options"] == [
        "1. Yes",
        "2. Yes, allow all edits during this session (shift+tab)",
        "3. No",
    ]


def test_permission_detector_repairs_corrupted_terminal_redraw_text() -> None:
    detector = PermissionDetector()
    buffer_text = """
Do you want t mkeths eit toask_user_question_panel.dart?
❯ 1. Yes 2. Yes,allowalleditsduringthissession(shift+tab) 3. No
(esc to cancel)
"""

    result = detector.detect_and_extract(buffer_text)

    assert result.detected is True
    assert result.data is not None
    assert (
        result.data["question"]
        == "Do you want to make this edit to ask_user_question_panel.dart?"
    )
    assert result.data["options"] == [
        "1. Yes",
        "2. Yes, allow all edits during this session (shift+tab)",
        "3. No",
    ]


def test_permission_detector_keeps_terminal_option_count() -> None:
    detector = PermissionDetector()
    buffer_text = """
Do you want to run this command?
1. Yes
2. No
(esc to cancel)
"""

    result = detector.detect_and_extract(buffer_text)

    assert result.detected is True
    assert result.data is not None
    assert result.data["options"] == ["1. Yes", "2. No"]


def test_permission_detector_keeps_first_option_when_question_repeats() -> None:
    detector = PermissionDetector()
    buffer_text = """
Do you want to make this edit to README.md?
❯ 1. Yes
Do you want to make this edit to README.md?
  2. Yes, allow all edits during this session (shift+tab)
  3. No
"""

    result = detector.detect_and_extract(buffer_text)

    assert result.detected is True
    assert result.data is not None
    assert result.data["options"] == [
        "1. Yes",
        "2. Yes, allow all edits during this session (shift+tab)",
        "3. No",
    ]


def test_permission_detector_recovers_missing_first_option_from_fallback() -> None:
    detector = PermissionDetector()
    buffer_text = """
Do you want to make this edit to README.md?

❯ 1. Yes

Do you want to make this edit to README.md?
2. Yes, allow all edits during this session (shift+tab)
3. No
"""

    # Simulate a parse where direct scan can pick 2/3 first and fallback must recover 1.
    result = detector.detect_and_extract(buffer_text)

    assert result.detected is True
    assert result.data is not None
    assert result.data["options"] == [
        "1. Yes",
        "2. Yes, allow all edits during this session (shift+tab)",
        "3. No",
    ]


def test_permission_detector_infers_primary_yes_when_options_start_at_two() -> None:
    detector = PermissionDetector()
    buffer_text = """
Do you want to make this edit to README.md?
2. Yes, allow all edits during this session (shift+tab)
3. No
"""

    result = detector.detect_and_extract(buffer_text)

    assert result.detected is True
    assert result.data is not None
    assert result.data["options"] == [
        "1. Yes",
        "2. Yes, allow all edits during this session (shift+tab)",
        "3. No",
    ]
