# Aviation MCP Server — Projektanweisungen

## Projektübersicht
MCP-Server der AI-Agents Zugriff auf Flug- und Luftfahrtdaten gibt (Live-Tracking, Wetter, Flughäfen, Airlines).

## Tech Stack
- Python 3.11+
- MCP SDK (FastMCP)
- httpx (async HTTP)
- OpenSky Network, AviationWeather.gov, AirLabs APIs

## Konventionen
- Code-Kommentare auf Deutsch
- Variablennamen auf Englisch
- Ein API-Client pro Datei in `src/clients/`
- Ein Tool-Modul pro Themengruppe in `src/tools/`

## Architektur
- `src/server.py` — FastMCP Server, registriert alle Tools
- `src/config.py` — Lädt .env, stellt Settings bereit
- `src/clients/` — Async HTTP-Clients für externe APIs
- `src/tools/` — MCP-Tool-Definitionen (nutzen Clients)

## Wichtige Hinweise
- OpenSky Anonymous: 100 Calls/Tag
- AviationWeather.gov: 100 Requests/Min
- AirLabs Free Tier: 1.000 Calls/Monat
- Server läuft standardmäßig über stdio-Transport
- FastMCP nutzt `instructions` Parameter (nicht `description`)
