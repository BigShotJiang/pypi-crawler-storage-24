"""Flughafen- und Airline-Tools — Informationen über AirLabs API."""

from mcp.server.fastmcp import FastMCP

from src.clients.airlabs import AirLabsClient

# Gemeinsame Client-Instanz für alle Airport/Airline-Tools
_airlabs = AirLabsClient()


def register_airport_tools(mcp: FastMCP):
    """Flughafen- und Airline-Tools registrieren."""

    @mcp.tool()
    async def get_airport_info(
        iata_code: str | None = None,
        icao_code: str | None = None,
        country_code: str | None = None,
    ) -> dict:
        """Flughafen-Details abrufen (AirLabs).

        Suche nach IATA-Code, ICAO-Code oder Land.
        Gibt Name, Standort, Zeitzone und weitere Details zurück.

        Benötigt einen AirLabs API-Key (kostenlos, 1.000 Calls/Monat).

        Args:
            iata_code: IATA-Code des Flughafens (z.B. "JFK", "FRA", "MUC")
            icao_code: ICAO-Code des Flughafens (z.B. "KJFK", "EDDF", "EDDM")
            country_code: ISO-Ländercode für alle Flughäfen eines Landes (z.B. "DE", "US")
        """
        try:
            if not _airlabs.has_key:
                return {
                    "error": "Kein AirLabs API-Key konfiguriert. "
                    "Setze AIRLABS_API_KEY in der .env-Datei. "
                    "Kostenloser Key: https://airlabs.co"
                }

            if not any([iata_code, icao_code, country_code]):
                return {
                    "error": "Mindestens ein Suchparameter nötig: "
                    "iata_code, icao_code oder country_code."
                }

            data = await _airlabs.get_airports(
                iata_code=iata_code,
                icao_code=icao_code,
                country_code=country_code,
            )

            response = data.get("response") or []
            if not response:
                return {"error": "Keine Flughäfen gefunden."}

            airports = []
            for airport in response:
                airports.append({
                    "name": airport.get("name", ""),
                    "iata_code": airport.get("iata_code", ""),
                    "icao_code": airport.get("icao_code", ""),
                    "country_code": airport.get("country_code", ""),
                    "city": airport.get("city", ""),
                    "latitude": airport.get("lat"),
                    "longitude": airport.get("lng"),
                    "altitude_m": airport.get("alt"),
                    "timezone": airport.get("timezone", ""),
                    "phone": airport.get("phone", ""),
                    "website": airport.get("website", ""),
                })

            return {
                "airport_count": len(airports),
                "airports": airports,
            }
        except Exception as e:
            return {"error": f"Flughafen-Info konnte nicht abgerufen werden: {e}"}

    @mcp.tool()
    async def get_airline_info(
        iata_code: str | None = None,
        icao_code: str | None = None,
        name: str | None = None,
    ) -> dict:
        """Airline-Details abrufen (AirLabs).

        Suche nach IATA-Code, ICAO-Code oder Name.
        Gibt Name, Herkunftsland, IATA/ICAO-Codes und Status zurück.

        Benötigt einen AirLabs API-Key (kostenlos, 1.000 Calls/Monat).

        Args:
            iata_code: IATA-Code der Airline (z.B. "LH" für Lufthansa, "UA" für United)
            icao_code: ICAO-Code der Airline (z.B. "DLH" für Lufthansa, "UAL" für United)
            name: Name der Airline (z.B. "Lufthansa", "Ryanair")
        """
        try:
            if not _airlabs.has_key:
                return {
                    "error": "Kein AirLabs API-Key konfiguriert. "
                    "Setze AIRLABS_API_KEY in der .env-Datei. "
                    "Kostenloser Key: https://airlabs.co"
                }

            if not any([iata_code, icao_code, name]):
                return {
                    "error": "Mindestens ein Suchparameter nötig: "
                    "iata_code, icao_code oder name."
                }

            data = await _airlabs.get_airlines(
                iata_code=iata_code,
                icao_code=icao_code,
                name=name,
            )

            response = data.get("response") or []
            if not response:
                return {"error": "Keine Airlines gefunden."}

            airlines = []
            for airline in response:
                airlines.append({
                    "name": airline.get("name", ""),
                    "iata_code": airline.get("iata_code", ""),
                    "icao_code": airline.get("icao_code", ""),
                    "country_code": airline.get("country_code", ""),
                    "hub_code": airline.get("hub_code", ""),
                    "fleet_size": airline.get("fleet_size"),
                    "is_active": airline.get("status") == "active",
                })

            return {
                "airline_count": len(airlines),
                "airlines": airlines,
            }
        except Exception as e:
            return {"error": f"Airline-Info konnte nicht abgerufen werden: {e}"}
