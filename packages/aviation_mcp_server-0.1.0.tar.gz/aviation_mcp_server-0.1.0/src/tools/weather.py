"""Flugwetter-Tools — METAR, TAF und SIGMETs über AviationWeather.gov."""

from mcp.server.fastmcp import FastMCP

from src.clients.aviation_weather import AviationWeatherClient

# Gemeinsame Client-Instanz für alle Wetter-Tools
_weather = AviationWeatherClient()


def register_weather_tools(mcp: FastMCP):
    """Flugwetter-Tools registrieren."""

    @mcp.tool()
    async def get_airport_weather(airport_icao: str) -> dict:
        """Aktuelles Flugwetter (METAR) an einem Flughafen abrufen.

        METAR enthält: Wind, Sichtweite, Wolken, Temperatur, Luftdruck.

        Args:
            airport_icao: ICAO-Code des Flughafens (z.B. "KJFK" für New York JFK,
                "EDDF" für Frankfurt, "EDDM" für München)
        """
        try:
            data = await _weather.get_metar(airport_icao)

            if not data:
                return {"error": f"Keine METAR-Daten für {airport_icao.upper()} gefunden."}

            # Erstes Ergebnis nehmen (ein Flughafen = ein METAR)
            metar = data[0] if isinstance(data, list) else data

            return {
                "airport": airport_icao.upper(),
                "raw_metar": metar.get("rawOb", ""),
                "station_id": metar.get("icaoId", ""),
                "observation_time": metar.get("reportTime", ""),
                "temperature_c": metar.get("temp"),
                "dewpoint_c": metar.get("dewp"),
                "wind_direction_deg": metar.get("wdir"),
                "wind_speed_kt": metar.get("wspd"),
                "wind_gust_kt": metar.get("wgst"),
                "visibility_miles": metar.get("visib"),
                "altimeter_hpa": metar.get("altim"),
                "flight_category": metar.get("fltcat", ""),
                "clouds": metar.get("clouds", []),
                "weather_conditions": metar.get("wxString", ""),
            }
        except Exception as e:
            return {"error": f"Wetterdaten konnten nicht abgerufen werden: {e}"}

    @mcp.tool()
    async def get_weather_forecast(airport_icao: str) -> dict:
        """Flugwetter-Vorhersage (TAF) für einen Flughafen abrufen.

        TAF deckt typischerweise 24-30 Stunden ab und enthält
        erwartete Wetteränderungen in Zeitgruppen.

        Args:
            airport_icao: ICAO-Code des Flughafens (z.B. "KJFK" für New York JFK,
                "EDDF" für Frankfurt, "EDDM" für München)
        """
        try:
            data = await _weather.get_taf(airport_icao)

            if not data:
                return {"error": f"Keine TAF-Daten für {airport_icao.upper()} gefunden."}

            taf = data[0] if isinstance(data, list) else data

            # Forecast-Gruppen aufbereiten
            fcsts = taf.get("fcsts", [])
            forecast_periods = []
            for period in fcsts:
                forecast_periods.append({
                    "time_from": period.get("timeFrom", ""),
                    "time_to": period.get("timeTo", ""),
                    "change_type": period.get("fcstChange", ""),
                    "wind_direction_deg": period.get("wdir"),
                    "wind_speed_kt": period.get("wspd"),
                    "wind_gust_kt": period.get("wgst"),
                    "visibility_miles": period.get("visib"),
                    "clouds": period.get("clouds", []),
                    "weather_conditions": period.get("wxString", ""),
                })

            return {
                "airport": airport_icao.upper(),
                "raw_taf": taf.get("rawTAF", ""),
                "station_id": taf.get("icaoId", ""),
                "issue_time": taf.get("issueTime", ""),
                "valid_from": taf.get("validTimeFrom", ""),
                "valid_to": taf.get("validTimeTo", ""),
                "period_count": len(forecast_periods),
                "forecast_periods": forecast_periods,
            }
        except Exception as e:
            return {"error": f"Vorhersage konnte nicht abgerufen werden: {e}"}

    @mcp.tool()
    async def get_aviation_warnings() -> dict:
        """Aktive SIGMETs und Flugwetter-Warnungen weltweit abrufen.

        SIGMETs warnen vor gefährlichem Wetter für den Flugverkehr:
        Gewitter, Vereisung, Turbulenz, Vulkanasche, Sandstürme.
        """
        try:
            sigmets = await _weather.get_sigmets()

            warnings = []
            for sigmet in (sigmets or []):
                warnings.append({
                    "sigmet_id": sigmet.get("airSigmetId", ""),
                    "icao_id": sigmet.get("icaoId", ""),
                    "hazard": sigmet.get("hazard", ""),
                    "severity": sigmet.get("severity", ""),
                    "valid_from": sigmet.get("validTimeFrom", ""),
                    "valid_to": sigmet.get("validTimeTo", ""),
                    "altitude_low_ft": sigmet.get("altitudeLow1"),
                    "altitude_high_ft": sigmet.get("altitudeHi1"),
                    "raw_text": sigmet.get("rawAirSigmet", ""),
                })

            return {
                "warning_count": len(warnings),
                "warnings": warnings,
            }
        except Exception as e:
            return {"error": f"Warnungen konnten nicht abgerufen werden: {e}"}
