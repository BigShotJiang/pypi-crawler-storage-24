"""Aviation MCP Server — gibt AI-Agents Zugriff auf Flug- und Wetterdaten."""

import logging

from mcp.server.fastmcp import FastMCP

from src.tools.tracking import register_tracking_tools
from src.tools.weather import register_weather_tools
from src.tools.airports import register_airport_tools

logging.basicConfig(level=logging.INFO)

# MCP-Server erstellen
mcp = FastMCP(
    "Aviation MCP Server",
    instructions=(
        "Gibt AI-Agents Zugriff auf Flug- und Luftfahrtdaten: "
        "Live-Flugverfolgung, Flughafen-Wetter (METAR/TAF), "
        "SIGMETs, Flughafen- und Airline-Informationen."
    ),
)

# Alle Tools registrieren
register_tracking_tools(mcp)
register_weather_tools(mcp)
register_airport_tools(mcp)


def main():
    """Server starten (stdio-Transport für lokale Nutzung)."""
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
