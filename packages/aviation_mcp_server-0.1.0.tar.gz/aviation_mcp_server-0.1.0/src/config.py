"""Konfiguration — lädt API-Keys aus .env und stellt Settings bereit."""

import os
from pathlib import Path

from dotenv import load_dotenv
from pydantic import BaseModel

# .env oder keys.env aus dem Projektverzeichnis laden
_project_root = Path(__file__).resolve().parent.parent
_env_path = _project_root / "keys.env"
if not _env_path.exists():
    _env_path = _project_root / ".env"
load_dotenv(_env_path)


class Settings(BaseModel):
    """Zentrale Konfiguration für alle API-Clients."""

    # AirLabs (Flughäfen, Airlines, Flüge — optional)
    airlabs_api_key: str = os.getenv("AIRLABS_API_KEY", "")
    airlabs_base_url: str = "https://airlabs.co/api/v9"

    # OpenSky Network (Live Flight Tracking — kein Key nötig)
    opensky_base_url: str = "https://opensky-network.org/api"

    # AviationWeather.gov (METAR/TAF — kein Key nötig)
    aviation_weather_base_url: str = "https://aviationweather.gov/api/data"

    # HTTP-Client Defaults
    http_timeout: float = 30.0


# Globale Settings-Instanz
settings = Settings()
