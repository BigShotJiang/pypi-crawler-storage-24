"""AviationWeather.gov API Client — METAR, TAF, SIGMETs und PIREPs."""

import httpx

from src.config import settings


class AviationWeatherClient:
    """Async-Client für die AviationWeather.gov API (Flugwetterdaten).

    Kein API-Key nötig. Rate-Limit: 100 Requests/Minute.
    Nutzt ICAO-Flughafencodes (z.B. KJFK, EDDF, EDDM).
    """

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=settings.http_timeout)
        self._base = settings.aviation_weather_base_url

    async def get_metar(self, station_ids: str) -> list:
        """Aktuelle METAR-Wetterdaten für einen oder mehrere Flughäfen.

        Args:
            station_ids: Kommagetrennte ICAO-Codes (z.B. "KJFK,EDDF")
        """
        url = f"{self._base}/metar"
        params = {"ids": station_ids.upper(), "format": "json"}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_taf(self, station_ids: str) -> list:
        """TAF-Wettervorhersage für einen oder mehrere Flughäfen.

        Args:
            station_ids: Kommagetrennte ICAO-Codes (z.B. "KJFK,EDDF")
        """
        url = f"{self._base}/taf"
        params = {"ids": station_ids.upper(), "format": "json"}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_pireps(self) -> list:
        """Aktuelle Pilotberichte (PIREPs) abrufen."""
        url = f"{self._base}/pirep"
        params = {"format": "json"}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_sigmets(self) -> list:
        """Aktuelle SIGMETs (Flugwetter-Warnungen) abrufen."""
        url = f"{self._base}/sigmet"
        params = {"format": "json"}
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def close(self):
        """HTTP-Client schließen."""
        await self._client.aclose()
