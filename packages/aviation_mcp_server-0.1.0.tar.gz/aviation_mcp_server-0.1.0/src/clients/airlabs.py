"""AirLabs API Client — Flughäfen, Airlines, Flüge und Routen."""

import httpx

from src.config import settings


class AirLabsClient:
    """Async-Client für die AirLabs API (Flughafen- und Airline-Daten).

    Free Tier: 1.000 Calls/Monat. API-Key erforderlich.
    """

    def __init__(self):
        self._client = httpx.AsyncClient(timeout=settings.http_timeout)
        self._base = settings.airlabs_base_url

    @property
    def _api_key(self) -> str:
        return settings.airlabs_api_key

    @property
    def has_key(self) -> bool:
        """Prüft ob ein API-Key konfiguriert ist."""
        return bool(self._api_key) and self._api_key != "your-key-here"

    def _params(self, **kwargs) -> dict:
        """Basis-Parameter mit API-Key zusammenbauen."""
        params = {"api_key": self._api_key}
        params.update({k: v for k, v in kwargs.items() if v is not None})
        return params

    async def get_airports(
        self,
        iata_code: str | None = None,
        icao_code: str | None = None,
        country_code: str | None = None,
    ) -> dict:
        """Flughafen-Datenbank abfragen.

        Args:
            iata_code: IATA-Code (z.B. JFK, FRA)
            icao_code: ICAO-Code (z.B. KJFK, EDDF)
            country_code: ISO-Ländercode (z.B. DE, US)
        """
        url = f"{self._base}/airports"
        params = self._params(
            iata_code=iata_code,
            icao_code=icao_code,
            country_code=country_code,
        )
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_airlines(
        self,
        iata_code: str | None = None,
        icao_code: str | None = None,
        name: str | None = None,
    ) -> dict:
        """Airline-Datenbank abfragen.

        Args:
            iata_code: IATA-Code der Airline (z.B. LH, UA)
            icao_code: ICAO-Code der Airline (z.B. DLH, UAL)
            name: Name der Airline (z.B. Lufthansa)
        """
        url = f"{self._base}/airlines"
        params = self._params(
            iata_code=iata_code,
            icao_code=icao_code,
            name=name,
        )
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_nearby_airports(
        self, lat: float, lng: float, distance: int = 100
    ) -> dict:
        """Flughäfen in der Nähe eines Standorts finden.

        Args:
            lat: Breitengrad
            lng: Längengrad
            distance: Maximale Entfernung in km (Standard: 100)
        """
        url = f"{self._base}/nearby"
        params = self._params(lat=lat, lng=lng, distance=distance)
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_flights(
        self,
        flight_iata: str | None = None,
        airline_iata: str | None = None,
        dep_iata: str | None = None,
        arr_iata: str | None = None,
    ) -> dict:
        """Echtzeit-Flugdaten abfragen.

        Args:
            flight_iata: IATA-Flugnummer (z.B. LH400)
            airline_iata: IATA-Code der Airline (z.B. LH)
            dep_iata: IATA-Code des Abflughafens
            arr_iata: IATA-Code des Zielflughafens
        """
        url = f"{self._base}/flights"
        params = self._params(
            flight_iata=flight_iata,
            airline_iata=airline_iata,
            dep_iata=dep_iata,
            arr_iata=arr_iata,
        )
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_schedules(
        self,
        dep_iata: str | None = None,
        arr_iata: str | None = None,
        airline_iata: str | None = None,
    ) -> dict:
        """Flugpläne abfragen.

        Args:
            dep_iata: IATA-Code des Abflughafens
            arr_iata: IATA-Code des Zielflughafens
            airline_iata: IATA-Code der Airline
        """
        url = f"{self._base}/schedules"
        params = self._params(
            dep_iata=dep_iata,
            arr_iata=arr_iata,
            airline_iata=airline_iata,
        )
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_delays(
        self,
        dep_iata: str | None = None,
        arr_iata: str | None = None,
    ) -> dict:
        """Flugverspätungen abfragen.

        Args:
            dep_iata: IATA-Code des Abflughafens
            arr_iata: IATA-Code des Zielflughafens
        """
        url = f"{self._base}/delays"
        params = self._params(dep_iata=dep_iata, arr_iata=arr_iata)
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def get_routes(
        self,
        dep_iata: str | None = None,
        arr_iata: str | None = None,
        airline_iata: str | None = None,
    ) -> dict:
        """Airline-Routen abfragen.

        Args:
            dep_iata: IATA-Code des Abflughafens
            arr_iata: IATA-Code des Zielflughafens
            airline_iata: IATA-Code der Airline
        """
        url = f"{self._base}/routes"
        params = self._params(
            dep_iata=dep_iata,
            arr_iata=arr_iata,
            airline_iata=airline_iata,
        )
        resp = await self._client.get(url, params=params)
        resp.raise_for_status()
        return resp.json()

    async def close(self):
        """HTTP-Client schließen."""
        await self._client.aclose()
