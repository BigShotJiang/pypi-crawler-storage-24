# -*- coding: utf-8 -*-

"""
Core mixins package providing compatibility
utilities and interfaces.
"""
