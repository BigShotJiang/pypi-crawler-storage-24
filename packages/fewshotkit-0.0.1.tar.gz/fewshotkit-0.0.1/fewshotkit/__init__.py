"""fewshotkit public API."""

from fewshotkit.evaluation.episodic import evaluate_n_way_k_shot
from fewshotkit.models.base import FewShotModel
from fewshotkit.models.matching import MatchingNet
from fewshotkit.models.proto import ProtoNet
from fewshotkit.models.siamese import SiameseKNN

__all__ = [
    "FewShotModel",
    "ProtoNet",
    "SiameseKNN",
    "MatchingNet",
    "evaluate_n_way_k_shot",
]
