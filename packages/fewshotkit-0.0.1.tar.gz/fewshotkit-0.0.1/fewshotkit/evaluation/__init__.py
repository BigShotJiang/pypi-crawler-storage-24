"""Evaluation utilities for fewshotkit."""

from fewshotkit.evaluation.episodic import evaluate_n_way_k_shot

__all__ = ["evaluate_n_way_k_shot"]
