"""Episodic evaluation helpers."""

from __future__ import annotations

import copy
from typing import Any

import numpy as np

from fewshotkit.models.base import FewShotModel


def evaluate_n_way_k_shot(
    model: FewShotModel,
    x: np.ndarray,
    y: np.ndarray,
    n_way: int = 5,
    k_shot: int = 5,
    n_query: int = 10,
    n_episodes: int = 100,
    random_state: int = 42,
) -> dict[str, Any]:
    """Evaluate a model with N-way K-shot episodic sampling.

    Args:
        model (FewShotModel): Model instance implementing fit/predict API.
        x (np.ndarray): Embeddings with shape (N, D).
        y (np.ndarray): Labels with shape (N,).
        n_way (int): Number of classes sampled per episode.
        k_shot (int): Number of support samples per class.
        n_query (int): Number of query samples per class.
        n_episodes (int): Number of episodes.
        random_state (int): Seed for deterministic episode sampling.

    Returns:
        dict[str, Any]: Aggregated episodic metrics.

    Raises:
        ValueError: If inputs are invalid or classes have insufficient samples.

    Example:
        >>> metrics = evaluate_n_way_k_shot(model, x, y, n_way=5, k_shot=5, n_query=10)
        >>> metrics["accuracy_mean"]
    """
    x_arr = np.asarray(x, dtype=np.float64)
    y_arr = np.asarray(y)

    if x_arr.ndim != 2:
        raise ValueError("x must be a 2D array with shape (N, D).")
    if y_arr.ndim != 1:
        raise ValueError("y must be a 1D array with shape (N,).")
    if x_arr.shape[0] != y_arr.shape[0]:
        raise ValueError("x and y must contain the same number of rows.")
    if n_way <= 1 or k_shot <= 0 or n_query <= 0 or n_episodes <= 0:
        raise ValueError("n_way, k_shot, n_query, and n_episodes must be positive.")

    rng = np.random.default_rng(random_state)
    classes = np.unique(y_arr)
    if classes.shape[0] < n_way:
        raise ValueError("Not enough distinct classes for n_way sampling.")

    required_per_class = k_shot + n_query
    for cls in classes:
        cls_count = np.sum(y_arr == cls)
        if cls_count < required_per_class:
            raise ValueError(
                f"Class '{cls}' has {cls_count} samples, requires at least "
                f"{required_per_class}."
            )

    episode_accuracies: list[float] = []
    for _ in range(n_episodes):
        sampled_classes = rng.choice(classes, size=n_way, replace=False)
        support_embeddings = []
        support_labels = []
        query_embeddings = []
        query_labels = []

        for cls in sampled_classes:
            class_indices = np.flatnonzero(y_arr == cls)
            chosen = rng.choice(class_indices, size=required_per_class, replace=False)
            support_idx = chosen[:k_shot]
            query_idx = chosen[k_shot:]

            support_embeddings.append(x_arr[support_idx])
            support_labels.append(np.full((k_shot,), cls, dtype=object))
            query_embeddings.append(x_arr[query_idx])
            query_labels.append(np.full((n_query,), cls, dtype=object))

        x_support = np.vstack(support_embeddings)
        y_support = np.concatenate(support_labels)
        x_query = np.vstack(query_embeddings)
        y_query = np.concatenate(query_labels)

        model_episode = copy.deepcopy(model)
        model_episode.fit(x_support, y_support)
        y_pred = model_episode.predict(x_query)
        accuracy = float(np.mean(y_pred == y_query))
        episode_accuracies.append(accuracy)

    accuracies = np.asarray(episode_accuracies, dtype=np.float64)
    return {
        "accuracy_mean": float(np.mean(accuracies)),
        "accuracy_std": float(np.std(accuracies)),
        "episode_accuracies": accuracies,
        "n_way": n_way,
        "k_shot": k_shot,
        "n_query": n_query,
        "n_episodes": n_episodes,
        "random_state": random_state,
    }
