"""Few-shot model implementations."""

from fewshotkit.models.base import FewShotModel
from fewshotkit.models.matching import MatchingNet
from fewshotkit.models.proto import ProtoNet
from fewshotkit.models.siamese import SiameseKNN

__all__ = ["FewShotModel", "ProtoNet", "SiameseKNN", "MatchingNet"]
