"""Base interface and shared utilities for few-shot models."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

import numpy as np


class FewShotModel(ABC):
    """Abstract base class for embedding-based few-shot models.

    Args:
        metric (str): Similarity metric name, either "cosine" or "euclidean".
        threshold (float | None): Optional unknown-detection threshold.
        unknown_label (Any): Label returned when unknown is detected.

    Attributes:
        metric (str): Metric name.
        threshold (float | None): Unknown-detection threshold.
        unknown_label (Any): Label returned for unknown predictions.
        embedding_dim_ (int | None): Learned embedding dimension after fit.
        classes_ (np.ndarray | None): Sorted class labels after fit.
    """

    VALID_METRICS = {"cosine", "euclidean"}

    def __init__(
        self,
        metric: str = "cosine",
        threshold: float | None = None,
        unknown_label: Any = -1,
    ) -> None:
        if metric not in self.VALID_METRICS:
            supported = sorted(self.VALID_METRICS)
            raise ValueError(f"Unsupported metric '{metric}'. Supported: {supported}")
        self.metric = metric
        self.threshold = threshold
        self.unknown_label = unknown_label
        self.embedding_dim_: int | None = None
        self.classes_: np.ndarray | None = None
        self._is_fitted: bool = False

    @abstractmethod
    def fit(self, x: np.ndarray, y: np.ndarray) -> "FewShotModel":
        """Fit the model using support embeddings.

        Args:
            x (np.ndarray): Support embeddings of shape (N, D).
            y (np.ndarray): Labels of shape (N,).

        Returns:
            FewShotModel: Fitted model instance.
        """

    @abstractmethod
    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict class labels for query embeddings.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).

        Returns:
            np.ndarray: Predicted labels of shape (M,).
        """

    @abstractmethod
    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        """Predict class probabilities for query embeddings.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).

        Returns:
            np.ndarray: Predicted probabilities of shape (M, C).
        """

    @abstractmethod
    def add_class(self, label: Any, embeddings: np.ndarray) -> None:
        """Add a class dynamically after model initialization.

        Args:
            label (Any): Class label.
            embeddings (np.ndarray): Support embeddings of shape (N, D).
        """

    @abstractmethod
    def remove_class(self, label: Any) -> None:
        """Remove a class from the fitted model.

        Args:
            label (Any): Class label to remove.
        """

    def score(self, x: np.ndarray, y: np.ndarray) -> float:
        """Compute classification accuracy.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).
            y (np.ndarray): Ground-truth labels of shape (M,).

        Returns:
            float: Accuracy between 0 and 1.

        Raises:
            ValueError: If query and label lengths mismatch.

        Example:
            >>> model.score(x_query, y_query)
            0.95
        """
        y_pred = self.predict(x)
        y_true = self._validate_1d_labels(y)
        if y_pred.shape[0] != y_true.shape[0]:
            raise ValueError("Prediction and target lengths must match.")
        return float(np.mean(y_pred == y_true))

    def _validate_xy(
        self, x: np.ndarray, y: np.ndarray
    ) -> tuple[np.ndarray, np.ndarray]:
        """Validate support embeddings and labels."""
        x_arr = self._validate_2d_embeddings(x)
        y_arr = self._validate_1d_labels(y)
        if x_arr.shape[0] != y_arr.shape[0]:
            raise ValueError("x and y must have the same number of rows.")
        if x_arr.shape[0] == 0:
            raise ValueError("x and y must not be empty.")
        return x_arr, y_arr

    def _validate_2d_embeddings(self, x: np.ndarray) -> np.ndarray:
        """Validate embedding matrix shape and dtype."""
        x_arr = np.asarray(x, dtype=np.float64)
        if x_arr.ndim != 2:
            raise ValueError("Embeddings must be a 2D array with shape (N, D).")
        if x_arr.shape[1] == 0:
            raise ValueError("Embedding dimension D must be > 0.")
        if self.embedding_dim_ is not None and x_arr.shape[1] != self.embedding_dim_:
            raise ValueError(
                f"Embedding dimension mismatch: expected {self.embedding_dim_}, "
                f"got {x_arr.shape[1]}."
            )
        return x_arr

    def _validate_1d_labels(self, y: np.ndarray) -> np.ndarray:
        """Validate label vector shape."""
        y_arr = np.asarray(y)
        if y_arr.ndim != 1:
            raise ValueError("Labels must be a 1D array with shape (N,).")
        if y_arr.shape[0] == 0:
            raise ValueError("Labels array must not be empty.")
        return y_arr

    def _check_is_fitted(self) -> None:
        """Raise if model has not been fitted."""
        if not self._is_fitted:
            raise ValueError("Model is not fitted. Call fit() before prediction.")

    def _sorted_unique_labels(self, y: np.ndarray) -> np.ndarray:
        """Return deterministic sorted unique labels."""
        # Use Python-level sorting to support mixed/object labels deterministically.
        labels = list(dict.fromkeys(np.asarray(y, dtype=object).tolist()))
        labels.sort(key=lambda value: (str(type(value)), repr(value)))
        return np.asarray(labels, dtype=object)

    @staticmethod
    def _softmax(logits: np.ndarray) -> np.ndarray:
        """Compute row-wise stable softmax."""
        shifted = logits - np.max(logits, axis=1, keepdims=True)
        exp = np.exp(shifted)
        denom = np.sum(exp, axis=1, keepdims=True)
        return exp / denom
