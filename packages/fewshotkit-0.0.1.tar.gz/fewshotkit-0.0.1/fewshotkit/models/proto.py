"""Prototypical network model."""

from __future__ import annotations

from typing import Any

import numpy as np

from fewshotkit.metrics import cosine_similarity_matrix, euclidean_distance_matrix
from fewshotkit.models.base import FewShotModel


class ProtoNet(FewShotModel):
    """Prototypical Network for few-shot classification.

    This model computes one centroid for each class from support embeddings,
    then predicts classes by nearest centroid (euclidean) or highest centroid
    similarity (cosine).

    Args:
        metric (str): Distance metric ("cosine" or "euclidean").
        threshold (float | None): Optional unknown-detection threshold.
        unknown_label (Any): Label returned when unknown is detected.

    Attributes:
        centroids_ (np.ndarray | None): Class prototypes with shape (C, D).
        classes_ (np.ndarray | None): Sorted unique class labels.
    """

    def __init__(
        self,
        metric: str = "cosine",
        threshold: float | None = None,
        unknown_label: Any = -1,
    ) -> None:
        super().__init__(
            metric=metric, threshold=threshold, unknown_label=unknown_label
        )
        self.centroids_: np.ndarray | None = None
        self._support_map: dict[Any, np.ndarray] = {}

    def fit(self, x: np.ndarray, y: np.ndarray) -> "ProtoNet":
        """Fit class centroids from support embeddings.

        Args:
            x (np.ndarray): Support embeddings of shape (N, D).
            y (np.ndarray): Labels of shape (N,).

        Returns:
            ProtoNet: Fitted model.

        Raises:
            ValueError: If input shapes are invalid.

        Example:
            >>> model = ProtoNet(metric="cosine")
            >>> _ = model.fit(x_support, y_support)
        """
        x_arr, y_arr = self._validate_xy(x, y)
        self.embedding_dim_ = x_arr.shape[1]
        self._support_map = {}

        for cls in self._sorted_unique_labels(y_arr):
            cls_embeddings = x_arr[y_arr == cls]
            self._support_map[cls] = cls_embeddings

        self._recompute_prototypes()
        self._is_fitted = True
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict class labels for query embeddings.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).

        Returns:
            np.ndarray: Predicted labels of shape (M,).

        Raises:
            ValueError: If model is not fitted or shape is invalid.

        Example:
            >>> model.predict(x_query)
        """
        self._check_is_fitted()
        scores = self._class_scores(self._validate_2d_embeddings(x))
        best_idx = np.argmax(scores, axis=1)
        preds = np.asarray(self.classes_, dtype=object)[best_idx]
        if self.threshold is None:
            return preds

        max_scores = np.max(scores, axis=1)
        unknown_mask = max_scores < self.threshold
        if np.any(unknown_mask):
            preds = preds.astype(object)
            preds[unknown_mask] = self.unknown_label
        return preds

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        """Predict class probabilities for query embeddings.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).

        Returns:
            np.ndarray: Probability matrix of shape (M, C).

        Raises:
            ValueError: If model is not fitted or input shape is invalid.

        Example:
            >>> model.predict_proba(x_query)
        """
        self._check_is_fitted()
        scores = self._class_scores(self._validate_2d_embeddings(x))
        return self._softmax(scores)

    def add_class(self, label: Any, embeddings: np.ndarray) -> None:
        """Add a class and recompute centroids.

        Args:
            label (Any): Class label.
            embeddings (np.ndarray): Embeddings of shape (N, D).

        Raises:
            ValueError: If shape is invalid or class already exists.

        Example:
            >>> model.add_class("wake_word", x_new)
        """
        x_arr = self._validate_2d_embeddings(embeddings)
        if not self._is_fitted:
            raise ValueError("Model must be fitted before add_class().")
        if label in self._support_map:
            raise ValueError(f"Class '{label}' already exists.")
        self._support_map[label] = x_arr
        self._recompute_prototypes()

    def remove_class(self, label: Any) -> None:
        """Remove a class and recompute centroids.

        Args:
            label (Any): Class label.

        Raises:
            ValueError: If class does not exist or removal makes model empty.

        Example:
            >>> model.remove_class("wake_word")
        """
        self._check_is_fitted()
        if label not in self._support_map:
            raise ValueError(f"Class '{label}' does not exist.")
        if len(self._support_map) <= 1:
            raise ValueError("Cannot remove the last remaining class.")
        del self._support_map[label]
        self._recompute_prototypes()

    def _recompute_prototypes(self) -> None:
        """Recompute class centroids in deterministic class order."""
        labels = np.array(list(self._support_map.keys()), dtype=object)
        self.classes_ = self._sorted_unique_labels(labels)
        centroids = [np.mean(self._support_map[cls], axis=0) for cls in self.classes_]
        self.centroids_ = np.vstack(centroids)

    def _class_scores(self, x: np.ndarray) -> np.ndarray:
        """Compute class scores where larger values are better."""
        if self.centroids_ is None or self.classes_ is None:
            raise ValueError("Model is not fitted.")
        if self.metric == "cosine":
            return cosine_similarity_matrix(x, self.centroids_)
        distances = euclidean_distance_matrix(x, self.centroids_)
        return -distances
