"""Siamese-style KNN inference model."""

from __future__ import annotations

from typing import Any

import numpy as np

from fewshotkit.metrics import cosine_similarity_matrix, euclidean_distance_matrix
from fewshotkit.models.base import FewShotModel


class SiameseKNN(FewShotModel):
    """Siamese-style inference-only model using nearest-neighbor voting.

    Args:
        metric (str): Similarity metric ("cosine" or "euclidean").
        k (int): Number of nearest support samples used for voting.
        threshold (float | None): Optional unknown-detection threshold.
        unknown_label (Any): Label returned when unknown is detected.

    Attributes:
        x_support_ (np.ndarray | None): Support embeddings (N, D).
        y_support_ (np.ndarray | None): Support labels (N,).
        classes_ (np.ndarray | None): Sorted class labels.
    """

    def __init__(
        self,
        metric: str = "cosine",
        k: int = 1,
        threshold: float | None = None,
        unknown_label: Any = -1,
    ) -> None:
        super().__init__(
            metric=metric, threshold=threshold, unknown_label=unknown_label
        )
        if k <= 0:
            raise ValueError("k must be a positive integer.")
        self.k = k
        self.x_support_: np.ndarray | None = None
        self.y_support_: np.ndarray | None = None

    def fit(self, x: np.ndarray, y: np.ndarray) -> "SiameseKNN":
        """Store support embeddings and labels.

        Args:
            x (np.ndarray): Support embeddings of shape (N, D).
            y (np.ndarray): Labels of shape (N,).

        Returns:
            SiameseKNN: Fitted model.

        Raises:
            ValueError: If input shape is invalid.

        Example:
            >>> model = SiameseKNN(k=3)
            >>> _ = model.fit(x_support, y_support)
        """
        x_arr, y_arr = self._validate_xy(x, y)
        self.embedding_dim_ = x_arr.shape[1]
        self.x_support_ = x_arr
        self.y_support_ = y_arr
        self.classes_ = self._sorted_unique_labels(y_arr)
        self._is_fitted = True
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict class labels with top-k weighted voting.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).

        Returns:
            np.ndarray: Predicted labels of shape (M,).

        Raises:
            ValueError: If model is not fitted or input shape is invalid.

        Example:
            >>> model.predict(x_query)
        """
        self._check_is_fitted()
        proba = self.predict_proba(x)
        classes_obj = np.asarray(self.classes_, dtype=object)
        best_idx = np.argmax(proba, axis=1)
        preds = classes_obj[best_idx]

        if self.threshold is None:
            return preds

        scores = self._max_neighbor_score(self._validate_2d_embeddings(x))
        unknown_mask = scores < self.threshold
        if np.any(unknown_mask):
            preds = preds.astype(object)
            preds[unknown_mask] = self.unknown_label
        return preds

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        """Estimate class probabilities from top-k neighbor weights.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).

        Returns:
            np.ndarray: Probability matrix with shape (M, C).

        Raises:
            ValueError: If model is not fitted or input shape is invalid.

        Example:
            >>> model.predict_proba(x_query)
        """
        self._check_is_fitted()
        x_arr = self._validate_2d_embeddings(x)
        class_weights, _ = self._class_weight_matrix(x_arr)
        row_sums = np.sum(class_weights, axis=1, keepdims=True)
        zero_rows = row_sums.squeeze(axis=1) <= 0.0
        class_weights = class_weights / np.where(row_sums == 0.0, 1.0, row_sums)

        if np.any(zero_rows):
            class_weights[zero_rows] = 1.0 / class_weights.shape[1]
        return class_weights

    def add_class(self, label: Any, embeddings: np.ndarray) -> None:
        """Add support samples for a new class.

        Args:
            label (Any): New class label.
            embeddings (np.ndarray): Embeddings of shape (N, D).

        Raises:
            ValueError: If model is not fitted, shape invalid, or class exists.

        Example:
            >>> model.add_class("new_word", x_new)
        """
        self._check_is_fitted()
        x_arr = self._validate_2d_embeddings(embeddings)
        if self.y_support_ is None or self.x_support_ is None:
            raise ValueError("Model is not fitted.")
        if np.any(self.y_support_ == label):
            raise ValueError(f"Class '{label}' already exists.")
        new_labels = np.full((x_arr.shape[0],), label, dtype=object)
        self.x_support_ = np.vstack([self.x_support_, x_arr])
        self.y_support_ = np.concatenate([self.y_support_.astype(object), new_labels])
        self.classes_ = self._sorted_unique_labels(self.y_support_)

    def remove_class(self, label: Any) -> None:
        """Remove all support samples of a class.

        Args:
            label (Any): Class label.

        Raises:
            ValueError: If class does not exist or becomes empty.

        Example:
            >>> model.remove_class("old_word")
        """
        self._check_is_fitted()
        if self.y_support_ is None or self.x_support_ is None:
            raise ValueError("Model is not fitted.")
        mask = self.y_support_ != label
        if np.all(mask):
            raise ValueError(f"Class '{label}' does not exist.")
        if np.sum(mask) == 0:
            raise ValueError("Cannot remove all support samples.")
        remaining_labels = self.y_support_[mask]
        if np.unique(remaining_labels).shape[0] == 0:
            raise ValueError("Cannot remove the last remaining class.")
        self.x_support_ = self.x_support_[mask]
        self.y_support_ = remaining_labels
        self.classes_ = self._sorted_unique_labels(self.y_support_)

    def _pair_scores(self, x: np.ndarray) -> np.ndarray:
        """Return pairwise scores where larger values are better."""
        if self.x_support_ is None:
            raise ValueError("Model is not fitted.")
        if self.metric == "cosine":
            return cosine_similarity_matrix(x, self.x_support_)
        return -euclidean_distance_matrix(x, self.x_support_)

    def _class_weight_matrix(self, x: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """Compute weighted votes over classes for each query.

        Returns:
            tuple[np.ndarray, np.ndarray]: Class weights (M, C) and strongest
                top-k scores (M,).
        """
        if self.y_support_ is None or self.classes_ is None:
            raise ValueError("Model is not fitted.")

        scores = self._pair_scores(x)
        k_eff = min(self.k, scores.shape[1])
        top_idx = np.argpartition(-scores, kth=k_eff - 1, axis=1)[:, :k_eff]
        top_scores = np.take_along_axis(scores, top_idx, axis=1)
        top_labels = self.y_support_[top_idx]

        shifted = top_scores - np.max(top_scores, axis=1, keepdims=True)
        weights = np.exp(shifted)

        class_weights = np.zeros((x.shape[0], self.classes_.shape[0]), dtype=np.float64)
        for class_idx, cls in enumerate(self.classes_):
            class_weights[:, class_idx] = np.sum(
                weights * (top_labels == cls), axis=1, dtype=np.float64
            )
        return class_weights, np.max(top_scores, axis=1)

    def _max_neighbor_score(self, x: np.ndarray) -> np.ndarray:
        """Compute strongest neighbor score for unknown detection."""
        _, max_scores = self._class_weight_matrix(x)
        return max_scores
