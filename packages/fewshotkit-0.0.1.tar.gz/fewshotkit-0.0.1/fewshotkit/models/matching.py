"""Matching Network style classifier."""

from __future__ import annotations

from typing import Any

import numpy as np

from fewshotkit.metrics import cosine_similarity_matrix, euclidean_distance_matrix
from fewshotkit.models.base import FewShotModel


class MatchingNet(FewShotModel):
    """Matching Network style classifier with attention over support samples.

    Args:
        metric (str): Similarity metric ("cosine" or "euclidean").
        threshold (float | None): Optional unknown-detection threshold.
        unknown_label (Any): Label returned when unknown is detected.

    Attributes:
        x_support_ (np.ndarray | None): Support embeddings with shape (N, D).
        y_support_ (np.ndarray | None): Support labels with shape (N,).
        classes_ (np.ndarray | None): Deterministic sorted unique labels.
    """

    def __init__(
        self,
        metric: str = "cosine",
        threshold: float | None = None,
        unknown_label: Any = -1,
    ) -> None:
        super().__init__(
            metric=metric, threshold=threshold, unknown_label=unknown_label
        )
        self.x_support_: np.ndarray | None = None
        self.y_support_: np.ndarray | None = None

    def fit(self, x: np.ndarray, y: np.ndarray) -> "MatchingNet":
        """Store support embeddings and labels for attention-based inference.

        Args:
            x (np.ndarray): Support embeddings of shape (N, D).
            y (np.ndarray): Labels of shape (N,).

        Returns:
            MatchingNet: Fitted model.

        Raises:
            ValueError: If input shape is invalid.

        Example:
            >>> model = MatchingNet(metric="cosine")
            >>> _ = model.fit(x_support, y_support)
        """
        x_arr, y_arr = self._validate_xy(x, y)
        self.embedding_dim_ = x_arr.shape[1]
        self.x_support_ = x_arr
        self.y_support_ = y_arr
        self.classes_ = self._sorted_unique_labels(y_arr)
        self._is_fitted = True
        return self

    def predict(self, x: np.ndarray) -> np.ndarray:
        """Predict labels from attention-weighted class probabilities.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).

        Returns:
            np.ndarray: Predicted labels with shape (M,).

        Raises:
            ValueError: If model is not fitted or input shape is invalid.

        Example:
            >>> model.predict(x_query)
        """
        self._check_is_fitted()
        x_arr = self._validate_2d_embeddings(x)
        proba = self.predict_proba(x_arr)
        best_idx = np.argmax(proba, axis=1)
        preds = np.asarray(self.classes_, dtype=object)[best_idx]

        if self.threshold is None:
            return preds

        max_scores = self._max_pair_score(x_arr)
        unknown_mask = max_scores < self.threshold
        if np.any(unknown_mask):
            preds = preds.astype(object)
            preds[unknown_mask] = self.unknown_label
        return preds

    def predict_proba(self, x: np.ndarray) -> np.ndarray:
        """Predict probabilities via softmax attention over support samples.

        Args:
            x (np.ndarray): Query embeddings of shape (M, D).

        Returns:
            np.ndarray: Probability matrix with shape (M, C).

        Raises:
            ValueError: If model is not fitted or input shape is invalid.

        Example:
            >>> model.predict_proba(x_query)
        """
        self._check_is_fitted()
        x_arr = self._validate_2d_embeddings(x)
        scores = self._pair_scores(x_arr)
        attention = self._softmax(scores)

        if self.classes_ is None or self.y_support_ is None:
            raise ValueError("Model is not fitted.")

        class_probs = np.zeros(
            (x_arr.shape[0], self.classes_.shape[0]), dtype=np.float64
        )
        for class_idx, cls in enumerate(self.classes_):
            class_probs[:, class_idx] = np.sum(
                attention * (self.y_support_ == cls), axis=1, dtype=np.float64
            )
        return class_probs

    def add_class(self, label: Any, embeddings: np.ndarray) -> None:
        """Add support samples for a new class.

        Args:
            label (Any): New class label.
            embeddings (np.ndarray): Embeddings of shape (N, D).

        Raises:
            ValueError: If model is not fitted, class exists, or shape invalid.

        Example:
            >>> model.add_class("keyword", x_new)
        """
        self._check_is_fitted()
        x_arr = self._validate_2d_embeddings(embeddings)
        if self.y_support_ is None or self.x_support_ is None:
            raise ValueError("Model is not fitted.")
        if np.any(self.y_support_ == label):
            raise ValueError(f"Class '{label}' already exists.")
        new_labels = np.full((x_arr.shape[0],), label, dtype=object)
        self.x_support_ = np.vstack([self.x_support_, x_arr])
        self.y_support_ = np.concatenate([self.y_support_.astype(object), new_labels])
        self.classes_ = self._sorted_unique_labels(self.y_support_)

    def remove_class(self, label: Any) -> None:
        """Remove all support samples for an existing class.

        Args:
            label (Any): Class label.

        Raises:
            ValueError: If class does not exist or removal makes set empty.

        Example:
            >>> model.remove_class("keyword")
        """
        self._check_is_fitted()
        if self.y_support_ is None or self.x_support_ is None:
            raise ValueError("Model is not fitted.")

        mask = self.y_support_ != label
        if np.all(mask):
            raise ValueError(f"Class '{label}' does not exist.")
        if np.sum(mask) == 0:
            raise ValueError("Cannot remove all support samples.")

        self.x_support_ = self.x_support_[mask]
        self.y_support_ = self.y_support_[mask]
        if self.y_support_.shape[0] == 0:
            raise ValueError("Cannot remove the last remaining class.")
        self.classes_ = self._sorted_unique_labels(self.y_support_)

    def _pair_scores(self, x: np.ndarray) -> np.ndarray:
        """Return pairwise support scores where larger values are better."""
        if self.x_support_ is None:
            raise ValueError("Model is not fitted.")
        if self.metric == "cosine":
            return cosine_similarity_matrix(x, self.x_support_)
        return -euclidean_distance_matrix(x, self.x_support_)

    def _max_pair_score(self, x: np.ndarray) -> np.ndarray:
        """Return the strongest support score per query."""
        scores = self._pair_scores(x)
        return np.max(scores, axis=1)
