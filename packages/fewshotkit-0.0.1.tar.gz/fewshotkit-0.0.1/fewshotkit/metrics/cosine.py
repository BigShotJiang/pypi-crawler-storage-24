"""Cosine similarity metric implementations."""

from __future__ import annotations

import numpy as np

EPSILON = 1e-8


def cosine_similarity_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Compute pairwise cosine similarity between two embedding matrices.

    Args:
        a (np.ndarray): Matrix with shape (N, D).
        b (np.ndarray): Matrix with shape (M, D).

    Returns:
        np.ndarray: Pairwise cosine similarities with shape (N, M).

    Raises:
        ValueError: If input matrices are not two-dimensional or dimensions mismatch.

    Example:
        >>> x = np.array([[1.0, 0.0]])
        >>> y = np.array([[0.0, 1.0], [1.0, 0.0]])
        >>> cosine_similarity_matrix(x, y)
        array([[0., 1.]])
    """
    if a.ndim != 2 or b.ndim != 2:
        raise ValueError("Inputs must be 2D matrices.")
    if a.shape[1] != b.shape[1]:
        raise ValueError("Embedding dimension mismatch between inputs.")

    a_norm = np.linalg.norm(a, axis=1, keepdims=True)
    b_norm = np.linalg.norm(b, axis=1, keepdims=True)
    denom = (a_norm + EPSILON) * (b_norm.T + EPSILON)
    return (a @ b.T) / denom
