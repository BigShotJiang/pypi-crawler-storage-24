"""Distance and similarity metrics for fewshotkit."""

from fewshotkit.metrics.cosine import cosine_similarity_matrix
from fewshotkit.metrics.euclidean import euclidean_distance_matrix

__all__ = ["cosine_similarity_matrix", "euclidean_distance_matrix"]
