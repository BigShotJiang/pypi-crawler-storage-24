"""Euclidean distance metric implementations."""

from __future__ import annotations

import numpy as np


def euclidean_distance_matrix(a: np.ndarray, b: np.ndarray) -> np.ndarray:
    """Compute pairwise Euclidean distances between two embedding matrices.

    Args:
        a (np.ndarray): Matrix with shape (N, D).
        b (np.ndarray): Matrix with shape (M, D).

    Returns:
        np.ndarray: Pairwise distances with shape (N, M).

    Raises:
        ValueError: If input matrices are not two-dimensional or dimensions mismatch.

    Example:
        >>> x = np.array([[1.0, 0.0]])
        >>> y = np.array([[0.0, 1.0], [1.0, 0.0]])
        >>> euclidean_distance_matrix(x, y)
        array([[1.41421356, 0.        ]])
    """
    if a.ndim != 2 or b.ndim != 2:
        raise ValueError("Inputs must be 2D matrices.")
    if a.shape[1] != b.shape[1]:
        raise ValueError("Embedding dimension mismatch between inputs.")

    sq_norm_a = np.sum(a * a, axis=1, keepdims=True)
    sq_norm_b = np.sum(b * b, axis=1, keepdims=True).T
    distances_sq = np.maximum(sq_norm_a + sq_norm_b - 2.0 * (a @ b.T), 0.0)
    return np.sqrt(distances_sq)
