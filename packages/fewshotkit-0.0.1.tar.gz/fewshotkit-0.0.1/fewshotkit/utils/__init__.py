"""Utility helpers for fewshotkit."""
