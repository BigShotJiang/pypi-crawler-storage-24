import numpy as np
import pytest

from fewshotkit.metrics import cosine_similarity_matrix, euclidean_distance_matrix


def test_cosine_similarity_matrix_values() -> None:
    x = np.array([[1.0, 0.0], [0.0, 1.0]])
    y = np.array([[1.0, 0.0], [1.0, 1.0]])

    sims = cosine_similarity_matrix(x, y)
    expected = np.array([[1.0, 1.0 / np.sqrt(2.0)], [0.0, 1.0 / np.sqrt(2.0)]])
    assert sims.shape == (2, 2)
    np.testing.assert_allclose(sims, expected, atol=1e-7)


def test_cosine_similarity_handles_zero_vectors() -> None:
    x = np.array([[0.0, 0.0]])
    y = np.array([[1.0, 0.0]])
    sims = cosine_similarity_matrix(x, y)
    assert sims.shape == (1, 1)
    np.testing.assert_allclose(sims, np.array([[0.0]]), atol=1e-8)


def test_euclidean_distance_matrix_values() -> None:
    x = np.array([[1.0, 0.0], [0.0, 0.0]])
    y = np.array([[0.0, 0.0], [1.0, 1.0]])

    dists = euclidean_distance_matrix(x, y)
    expected = np.array([[1.0, 1.0], [0.0, np.sqrt(2.0)]])
    assert dists.shape == (2, 2)
    np.testing.assert_allclose(dists, expected, atol=1e-7)


@pytest.mark.parametrize("fn", [cosine_similarity_matrix, euclidean_distance_matrix])
def test_metrics_validate_shapes(fn) -> None:
    with pytest.raises(ValueError):
        fn(np.array([1.0, 2.0]), np.array([[1.0, 2.0]]))

    with pytest.raises(ValueError):
        fn(np.array([[1.0, 2.0]]), np.array([[1.0, 2.0, 3.0]]))
