import numpy as np
import pytest

from fewshotkit.evaluation import evaluate_n_way_k_shot
from fewshotkit.models.proto import ProtoNet


def _episodic_data() -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(7)
    centers = np.array([[0.0, 0.0], [3.0, 3.0], [-3.0, 3.0]], dtype=np.float64)
    per_class = 30

    xs = []
    ys = []
    for idx, center in enumerate(centers):
        xs.append(center + 0.2 * rng.normal(size=(per_class, 2)))
        ys.append(np.full((per_class,), idx))
    return np.vstack(xs), np.concatenate(ys)


def test_evaluate_n_way_k_shot_outputs_expected_fields() -> None:
    x, y = _episodic_data()
    model = ProtoNet(metric="euclidean")

    result = evaluate_n_way_k_shot(
        model,
        x,
        y,
        n_way=3,
        k_shot=5,
        n_query=5,
        n_episodes=20,
        random_state=123,
    )

    assert result["n_way"] == 3
    assert result["k_shot"] == 5
    assert result["n_query"] == 5
    assert result["n_episodes"] == 20
    assert result["random_state"] == 123
    assert 0.0 <= result["accuracy_mean"] <= 1.0
    assert result["accuracy_std"] >= 0.0
    assert result["episode_accuracies"].shape == (20,)


def test_evaluate_n_way_k_shot_is_deterministic() -> None:
    x, y = _episodic_data()
    model = ProtoNet(metric="euclidean")

    r1 = evaluate_n_way_k_shot(model, x, y, n_way=3, k_shot=3, n_query=4, n_episodes=15)
    r2 = evaluate_n_way_k_shot(model, x, y, n_way=3, k_shot=3, n_query=4, n_episodes=15)

    np.testing.assert_allclose(r1["episode_accuracies"], r2["episode_accuracies"])


def test_evaluate_n_way_k_shot_invalid_inputs() -> None:
    model = ProtoNet()
    x = np.random.randn(10, 2)
    y = np.array([0, 1] * 5)

    with pytest.raises(ValueError):
        evaluate_n_way_k_shot(model, x[:, 0], y)

    with pytest.raises(ValueError):
        evaluate_n_way_k_shot(model, x, y.reshape(5, 2))

    with pytest.raises(ValueError):
        evaluate_n_way_k_shot(model, x, y, n_way=3, k_shot=3, n_query=3)
