import numpy as np
import pytest

from fewshotkit.models.matching import MatchingNet
from fewshotkit.models.siamese import SiameseKNN


def _dataset() -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    x_support = np.array(
        [
            [0.0, 0.0],
            [0.2, 0.0],
            [2.0, 2.0],
            [2.2, 2.0],
            [4.0, 4.0],
            [4.2, 4.0],
        ],
        dtype=np.float64,
    )
    y_support = np.array(["a", "a", "b", "b", "c", "c"], dtype=object)
    x_query = np.array([[0.1, 0.0], [2.1, 2.0], [4.1, 4.0]], dtype=np.float64)
    y_query = np.array(["a", "b", "c"], dtype=object)
    return x_support, y_support, x_query, y_query


@pytest.mark.parametrize("model_cls", [SiameseKNN, MatchingNet])
def test_models_predict_and_proba(model_cls) -> None:
    x_support, y_support, x_query, y_query = _dataset()

    if model_cls is SiameseKNN:
        model = model_cls(metric="euclidean", k=3)
    else:
        model = model_cls(metric="euclidean")

    model.fit(x_support, y_support)
    pred = model.predict(x_query)
    proba = model.predict_proba(x_query)

    np.testing.assert_array_equal(pred, y_query)
    assert proba.shape == (3, 3)
    np.testing.assert_allclose(np.sum(proba, axis=1), np.ones(3), atol=1e-7)


@pytest.mark.parametrize("model", [SiameseKNN(k=1), MatchingNet()])
def test_models_add_remove_class(model) -> None:
    x_support, y_support, _, _ = _dataset()
    model.fit(x_support, y_support)

    model.add_class("d", np.array([[6.0, 6.0], [6.1, 6.0]], dtype=np.float64))
    assert "d" in model.classes_

    model.remove_class("d")
    assert "d" not in model.classes_


@pytest.mark.parametrize("model_cls", [SiameseKNN, MatchingNet])
def test_models_unknown_detection(model_cls) -> None:
    x_support, y_support, _, _ = _dataset()

    if model_cls is SiameseKNN:
        model = model_cls(metric="cosine", k=1, threshold=0.8, unknown_label="unknown")
    else:
        model = model_cls(metric="cosine", threshold=0.8, unknown_label="unknown")

    model.fit(x_support, y_support)
    pred = model.predict(np.array([[1.0, -1.0]], dtype=np.float64))
    np.testing.assert_array_equal(pred, np.array(["unknown"], dtype=object))


def test_siamese_validates_k() -> None:
    with pytest.raises(ValueError):
        SiameseKNN(k=0)
