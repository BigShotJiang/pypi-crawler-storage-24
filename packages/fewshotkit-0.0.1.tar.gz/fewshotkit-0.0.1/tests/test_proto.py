import numpy as np
import pytest

from fewshotkit.models.proto import ProtoNet


def _make_data() -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x_support = np.array(
        [
            [0.0, 0.0],
            [0.1, 0.0],
            [1.0, 1.0],
            [1.1, 1.0],
        ]
    )
    y_support = np.array([0, 0, 1, 1])
    x_query = np.array([[0.05, 0.0], [1.05, 1.0]])
    return x_support, y_support, x_query


def test_proto_predict_and_proba() -> None:
    x_support, y_support, x_query = _make_data()
    model = ProtoNet(metric="cosine")
    model.fit(x_support, y_support)

    pred = model.predict(x_query)
    proba = model.predict_proba(x_query)

    np.testing.assert_array_equal(pred, np.array([0, 1], dtype=object))
    assert proba.shape == (2, 2)
    np.testing.assert_allclose(np.sum(proba, axis=1), np.ones(2), atol=1e-7)


def test_proto_add_remove_class() -> None:
    x_support, y_support, _ = _make_data()
    model = ProtoNet().fit(x_support, y_support)

    model.add_class(2, np.array([[2.0, 2.0], [2.1, 2.0]]))
    assert 2 in model.classes_

    model.remove_class(2)
    assert 2 not in model.classes_


def test_proto_unknown_threshold() -> None:
    x_support, y_support, _ = _make_data()
    model = ProtoNet(metric="cosine", threshold=0.95, unknown_label="unknown")
    model.fit(x_support, y_support)

    pred = model.predict(np.array([[0.0, 1.0]]))
    np.testing.assert_array_equal(pred, np.array(["unknown"], dtype=object))


def test_proto_validation_errors() -> None:
    model = ProtoNet()
    with pytest.raises(ValueError):
        model.predict(np.array([[0.0, 1.0]]))

    with pytest.raises(ValueError):
        model.fit(np.array([[0.0, 1.0]]), np.array([0, 1]))
