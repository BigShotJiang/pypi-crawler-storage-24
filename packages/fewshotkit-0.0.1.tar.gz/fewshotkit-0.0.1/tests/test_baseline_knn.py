import numpy as np

from fewshotkit.models.proto import ProtoNet
from fewshotkit.models.siamese import SiameseKNN


def test_against_sklearn_knn_baseline() -> None:
    sklearn = __import__("sklearn.neighbors", fromlist=["KNeighborsClassifier"])
    KNeighborsClassifier = sklearn.KNeighborsClassifier

    rng = np.random.default_rng(42)
    class_centers = np.array([[0.0, 0.0], [2.5, 2.5], [-2.5, 2.5]], dtype=np.float64)

    x_train = []
    y_train = []
    x_test = []
    y_test = []
    for idx, center in enumerate(class_centers):
        x_train.append(center + 0.35 * rng.normal(size=(40, 2)))
        y_train.append(np.full((40,), idx))
        x_test.append(center + 0.35 * rng.normal(size=(20, 2)))
        y_test.append(np.full((20,), idx))

    x_train_arr = np.vstack(x_train)
    y_train_arr = np.concatenate(y_train)
    x_test_arr = np.vstack(x_test)
    y_test_arr = np.concatenate(y_test)

    knn = KNeighborsClassifier(n_neighbors=3)
    knn.fit(x_train_arr, y_train_arr)
    knn_acc = float(knn.score(x_test_arr, y_test_arr))

    proto = ProtoNet(metric="euclidean").fit(x_train_arr, y_train_arr)
    siamese = SiameseKNN(metric="euclidean", k=3).fit(x_train_arr, y_train_arr)

    proto_acc = proto.score(x_test_arr, y_test_arr)
    siamese_acc = siamese.score(x_test_arr, y_test_arr)

    assert proto_acc >= 0.75
    assert siamese_acc >= 0.75
    assert abs(siamese_acc - knn_acc) <= 0.15
