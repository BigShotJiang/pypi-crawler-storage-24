/**
 * PULSE Brain REST API client.
 *
 * All brain operations go through the local PULSE API server.
 * Localhost bypass means no auth token needed for local usage.
 */

export interface BrainSearchResult {
  query: string;
  total_results: number;
  elapsed_ms: number;
  results: Record<string, BrainResultItem[]>;
}

export interface BrainResultItem {
  text: string;
  title?: string;
  salience?: number;
  confidence?: number;
  timestamp?: string;
  source?: string;
}

export interface CaptureResult {
  status: string;
  wants_stored?: number;
  dont_wants_stored?: number;
  session_items?: number;
}

export interface SaveResult {
  status: string;
  learnings_saved?: number;
  failures_saved?: number;
}

export interface BriefingResult {
  query: string;
  briefing: string;
  empty: boolean;
}

export class PulseClient {
  private baseUrl: string;
  private timeout: number;

  constructor(baseUrl: string, timeout = 10_000) {
    this.baseUrl = baseUrl.replace(/\/+$/, "");
    this.timeout = timeout;
  }

  async healthCheck(): Promise<boolean> {
    try {
      const res = await this.fetch("/healthz");
      return res.status === "ok";
    } catch {
      return false;
    }
  }

  async search(query: string, maxResults = 10): Promise<BrainSearchResult> {
    return this.fetch(`/v1/brain/search?q=${encodeURIComponent(query)}`);
  }

  async getBriefing(query: string): Promise<string> {
    const data: BriefingResult = await this.fetch(
      `/v1/brain/briefing?q=${encodeURIComponent(query)}`
    );
    return data.briefing || "";
  }

  async capture(
    userPrompt: string,
    agentResponse: string,
    sessionId = ""
  ): Promise<CaptureResult> {
    return this.fetch("/v1/brain/capture", {
      method: "POST",
      body: JSON.stringify({
        user_prompt: userPrompt,
        agent_response: agentResponse,
        session_id: sessionId,
      }),
    });
  }

  async save(
    agentName: string,
    learnings: string[] = [],
    failures: string[] = [],
    domain = "general",
    outcome = ""
  ): Promise<SaveResult> {
    return this.fetch("/v1/brain/save", {
      method: "POST",
      body: JSON.stringify({
        agent_name: agentName,
        learnings,
        failures,
        domain,
        outcome,
      }),
    });
  }

  async getLessons(limit = 50): Promise<{ lessons: string[]; count: number }> {
    return this.fetch(`/v1/brain/lessons?limit=${limit}`);
  }

  async getFailures(limit = 50): Promise<{ failures: string[]; count: number }> {
    return this.fetch(`/v1/brain/failures?limit=${limit}`);
  }

  async getPatterns(limit = 50): Promise<{ patterns: string[]; count: number }> {
    return this.fetch(`/v1/brain/patterns?limit=${limit}`);
  }

  async getAntiPatterns(): Promise<{ anti_patterns: unknown[]; count: number }> {
    return this.fetch("/v1/brain/anti_patterns");
  }

  private async fetch(path: string, init?: RequestInit): Promise<any> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), this.timeout);
    try {
      const res = await globalThis.fetch(`${this.baseUrl}${path}`, {
        ...init,
        headers: {
          "Content-Type": "application/json",
          ...init?.headers,
        },
        signal: controller.signal,
      });
      if (!res.ok) {
        const text = await res.text().catch(() => "");
        throw new Error(`PULSE API ${res.status}: ${text.slice(0, 200)}`);
      }
      return res.json();
    } finally {
      clearTimeout(timer);
    }
  }
}
