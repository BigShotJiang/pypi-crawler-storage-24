#!/usr/bin/env python3
# Copyright (c) 2026 PULSE Contributors. Proprietary. All rights reserved.
# See LICENSE file for details.
"""
PULSE API — Integration router. Write endpoints for external plugins (OpenClaw, etc).

Separated from pulse_api_brain.py (read endpoints) for SoC.
"""
from __future__ import annotations

import sys
from pathlib import Path

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel, Field

SCRIPT_DIR = Path(__file__).resolve().parent
ROOT_DIR = SCRIPT_DIR.parent.parent

if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

router = APIRouter(prefix="/v1/brain", tags=["integrations"])


# --- Pydantic Models (underscore-prefixed: internal to this module) ---

class _CaptureReq(BaseModel):
    user_prompt: str = Field(..., min_length=3, examples=["Fix the auth bug"])
    agent_response: str = Field("", examples=["Here's the fix..."])
    session_id: str = Field("", examples=["session_001"])


class _SaveReq(BaseModel):
    agent_name: str = Field(..., examples=["openclaw"])
    learnings: list[str] = Field(default_factory=list)
    failures: list[str] = Field(default_factory=list)
    domain: str = Field("general", examples=["security"])
    outcome: str = Field("", examples=["success"])
    task_id: str = Field("")


# --- Endpoints ---

@router.post("/capture")
async def capture_interaction(req: _CaptureReq, request: Request):
    """Capture a conversation turn into the PULSE brain pipeline.

    Runs wants_parser + knowledge_extractor + routes to Hippocampus.
    Used by external plugins (OpenClaw, etc.) to feed the brain.
    """
    try:
        from pulse.brain.auto_capture import capture
        result = capture(
            user_prompt=req.user_prompt,
            agent_response=req.agent_response,
            session_id=req.session_id or "external",
        )
        return {"status": "captured", **result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Capture failed: {e}")


@router.post("/save")
async def save_knowledge(req: _SaveReq, request: Request):
    """Save learnings and failures to the PULSE brain.

    Wraps pulse_save.save() for external plugins.
    """
    try:
        from pulse.brain.pulse_save import save
        result = save(
            agent_name=req.agent_name,
            task_id=req.task_id,
            learnings=req.learnings,
            failures=req.failures,
            domain=req.domain,
            outcome=req.outcome,
        )
        return {"status": "saved", **result}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Save failed: {e}")


@router.get("/briefing")
async def get_briefing(q: str = ""):
    """Get a formatted brain briefing for a query.

    Returns the same [BRAIN] formatted output that Claude/Gemini hooks receive.
    Includes predictions, anti-patterns, proven approaches, failures, etc.
    """
    if not q or len(q) < 3:
        raise HTTPException(status_code=400, detail="Query 'q' must be at least 3 characters.")
    try:
        from pulse.brain.brain_query import run_query
        briefing = run_query(q)
        return {"query": q, "briefing": briefing or "", "empty": not briefing}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Briefing failed: {e}")
