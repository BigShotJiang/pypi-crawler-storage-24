import { Routes, Route } from 'react-router-dom'
import { ErrorBoundary } from './components/ErrorBoundary'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Landing from './pages/Landing'
import Brain from './pages/Brain'
import Pricing from './pages/Pricing'
import Install from './pages/Install'
import Docs from './pages/Docs'
import Success from './pages/Success'
import Recover from './pages/Recover'
import OpenClaw from './pages/OpenClaw'
import NotFound from './pages/NotFound'

function App() {
  return (
    <ErrorBoundary>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/dashboard" element={<Layout><Dashboard /></Layout>} />
        <Route path="/brain" element={<Layout><Brain /></Layout>} />
        <Route path="/pricing" element={<Layout><Pricing /></Layout>} />
        <Route path="/install" element={<Layout><Install /></Layout>} />
        <Route path="/docs" element={<Layout><Docs /></Layout>} />
        <Route path="/openclaw" element={<Layout><OpenClaw /></Layout>} />
        <Route path="/success" element={<Success />} />
        <Route path="/recover" element={<Recover />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </ErrorBoundary>
  )
}

export default App
