"""This module provides core functions for handling Unicode and Unix quirks

The @interruptable functions retry when system calls are interrupted,
e.g. when python raises an IOError or OSError with errno == EINTR.
"""
from __future__ import annotations
import ctypes
import functools
import itertools
import mimetypes
import os
import platform
import subprocess
import sys
from typing import Any, Callable, TYPE_CHECKING

from .decorators import interruptable
from .compat import ustr
from .compat import PY2
from .compat import PY3
from .compat import WIN32

if TYPE_CHECKING:
    from io import BufferedReader, BufferedWriter, TextIOWrapper

# /usr/include/stdlib.h
# #define EXIT_SUCCESS    0   /* Successful exit status.  */
# #define EXIT_FAILURE    1   /* Failing exit status.  */
EXIT_SUCCESS = 0
EXIT_FAILURE = 1

# /usr/include/sysexits.h
# #define EX_USAGE        64  /* command line usage error */
# #define EX_NOINPUT      66  /* cannot open input */
# #define EX_UNAVAILABLE  69  /* service unavailable */
EXIT_USAGE = 64
EXIT_NOINPUT = 66
EXIT_UNAVAILABLE = 69

# Default encoding
ENCODING = 'utf-8'

# Some files are not in UTF-8; some other aren't in any codification.
# Remember that GIT doesn't care about encodings (saves binary data)
_encoding_tests = [
    ENCODING,
    'iso-8859-15',
    'windows1252',
    'ascii',
    # <-- add encodings here
]


class UStr(ustr):
    """Unicode string wrapper that remembers its encoding

    UStr wraps Unicode strings to provide the `encoding` attribute.
    UStr is used when decoding strings of an unknown encoding.
    In order to generate patches that contain the original byte sequences,
    we must preserve the original encoding when calling decode()
    so that it can later be used when reconstructing the original
    byte sequences.

    """

    def __new__(cls: type[UStr], string: str | UStr, encoding: str) -> UStr:
        if isinstance(string, UStr):
            if encoding != string.encoding:
                raise ValueError(f'Encoding conflict: {string.encoding} vs. {encoding}')
            string = ustr(string)

        obj = ustr.__new__(cls, string)
        obj.encoding = encoding
        return obj


def decode_maybe(value, encoding, errors: str = 'strict') -> Any:
    """Decode a value when the "decode" method exists"""
    if hasattr(value, 'decode'):
        result = value.decode(encoding, errors=errors)
    else:
        result = value
    return result


def decode(
    value: bytes | str | UStr | None,
    encoding: None = None,
    errors: str = 'strict',
) -> UStr | None:
    """decode(encoded_string) returns an un-encoded Unicode string"""
    if value is None:
        result = None
    elif isinstance(value, ustr):
        result: bytes | UStr | None = UStr(value, ENCODING)
    elif encoding == 'bytes':
        result: bytes | UStr | None = value
    else:
        result = None
        if encoding is None:
            encoding_tests: itertools.chain | list[str] = _encoding_tests
        else:
            encoding_tests: itertools.chain | list[str] = itertools.chain(
                [encoding], _encoding_tests
            )

        for enc in encoding_tests:
            try:
                decoded = value.decode(enc, errors)
                result = UStr(decoded, enc)
                break
            except ValueError:
                pass

        if result is None:
            decoded = value.decode(ENCODING, errors='ignore')
            result = UStr(decoded, ENCODING)

    return result


def encode(string: str | UStr, encoding: str | None = None) -> bytes:
    """encode(string) returns a byte string encoded to UTF-8"""
    if not isinstance(string, ustr):
        return string
    return string.encode(encoding or ENCODING, 'replace')


def mkpath(path: str | UStr, encoding: None = None) -> bytes | UStr:
    # The Windows API requires Unicode strings regardless of python version
    if WIN32:
        return decode(path, encoding=encoding)
    # UNIX prefers bytes
    return encode(path, encoding=encoding)


def decode_seq(seq: list[bytes], encoding: None = None) -> list[UStr]:
    """Decode a sequence of values"""
    return [decode(x, encoding=encoding) for x in seq]


def list2cmdline(cmd: list[str | Any | UStr]) -> str:
    return subprocess.list2cmdline([decode(c) for c in cmd])


def read(
    filename: str, size: int = -1, encoding: str | None = None, errors: str = 'strict'
) -> UStr:
    """Read filename and return contents"""
    with xopen(filename, 'rb') as fh:
        return xread(fh, size=size, encoding=encoding, errors=errors)


def write(
    path: str, contents: str, encoding: str | None = None, append: bool = False
) -> int:
    """Writes a Unicode string to a file"""
    if append:
        mode = 'ab'
    else:
        mode = 'wb'
    with xopen(path, mode) as fh:
        return xwrite(fh, contents, encoding=encoding)


@interruptable
def xread(
    fh: BufferedReader, size: int = -1, encoding: None = None, errors: str = 'strict'
) -> UStr:
    """Read from a file handle and retry when interrupted"""
    return decode(fh.read(size), encoding=encoding, errors=errors)


@interruptable
def xwrite(fh: BufferedWriter, content: str, encoding: None = None) -> int:
    """Write to a file handle and retry when interrupted"""
    return fh.write(encode(content, encoding=encoding))


@interruptable
def wait(proc) -> Any:
    """Wait on a subprocess and retry when interrupted"""
    return proc.wait()


@interruptable
def readline(fh, encoding=None) -> UStr | None:
    return decode(fh.readline(), encoding=encoding)


@interruptable
def start_command(
    cmd: list[UStr | str],
    cwd: UStr | None = None,
    add_env: None = None,
    universal_newlines: bool = False,
    stdin: int | None = subprocess.PIPE,
    stdout: int | None = subprocess.PIPE,
    no_win32_startupinfo: bool = False,
    stderr: int | None = subprocess.PIPE,
    **extra,
) -> subprocess.Popen:
    """Start the given command, and return a subprocess object.

    This provides a simpler interface to the subprocess module.

    """
    env = extra.pop('env', None)
    if add_env is not None:
        env = os.environ.copy()
        env.update(add_env)

    # Python3 on windows always goes through list2cmdline() internally inside
    # of subprocess.py so we must provide Unicode strings here otherwise
    # Python3 breaks when bytes are provided.
    #
    # Additionally, the preferred usage on Python3 is to pass Unicode
    # strings to subprocess.  Python will automatically encode into the
    # default encoding (UTF-8) when it gets Unicode strings.
    shell = extra.get('shell', False)
    cmd: list[UStr | str] = prep_for_subprocess(cmd, shell=shell)

    if WIN32 and cwd == getcwd():
        # Windows cannot deal with passing a cwd that contains Unicode
        # but we luckily can pass None when the supplied cwd is the same
        # as our current directory and get the same effect.
        # Not doing this causes Unicode encoding errors when launching
        # the subprocess.
        cwd = None

    if PY2 and cwd:
        cwd = encode(cwd)

    if WIN32:
        # If git-cola is invoked on Windows using "start pythonw git-cola",
        # a console window will briefly flash on the screen each time
        # git-cola invokes git, which is very annoying.  The code below
        # prevents this by ensuring that any window will be hidden.
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        extra['startupinfo'] = startupinfo

        if WIN32 and not no_win32_startupinfo:
            CREATE_NO_WINDOW = 0x08000000
            extra['creationflags'] = CREATE_NO_WINDOW

    # Use line buffering when in text/universal_newlines mode,
    # otherwise use the system default buffer size.
    bufsize = 1 if universal_newlines else -1
    return subprocess.Popen(
        cmd,
        bufsize=bufsize,
        stdin=stdin,
        stdout=stdout,
        stderr=stderr,
        cwd=cwd,
        env=env,
        universal_newlines=universal_newlines,
        **extra,
    )


def prep_for_subprocess(cmd: list[UStr | str], shell: bool = False) -> list[UStr | str]:
    """Decode on Python3, encode on Python2"""
    # See the comment in start_command()
    if shell:
        if PY3:
            cmd = decode(cmd)  # type: ignore[assignment, arg-type]
        else:
            cmd = encode(cmd)  # type: ignore[assignment, arg-type]
    else:
        if PY3:
            cmd = [decode(c) for c in cmd]  # type: ignore[assignment, arg-type]
        else:
            cmd = [encode(c) for c in cmd]  # type: ignore[assignment, arg-type]
    return cmd


@interruptable
def communicate(
    proc: subprocess.Popen,
) -> tuple[None, bytes] | tuple[bytes, bytes]:
    return proc.communicate()


def run_command(cmd: list[UStr | str], *args, **kwargs) -> tuple[int, UStr, UStr]:
    """Run the given command to completion, and return its results.

    This provides a simpler interface to the subprocess module.
    The results are formatted as a 3-tuple: (exit_code, output, errors)
    The other arguments are passed on to start_command().

    """
    encoding = kwargs.pop('encoding', None)
    try:
        process = start_command(cmd, *args, **kwargs)
    except FileNotFoundError as err:
        return (EXIT_UNAVAILABLE, UStr('', ENCODING), UStr(f'{err}', ENCODING))
    (output, errors) = communicate(process)
    output = decode(output, encoding=encoding)
    errors = decode(errors, encoding=encoding)
    exit_code = process.returncode
    return (exit_code, output or UStr('', ENCODING), errors or UStr('', ENCODING))


@interruptable
def _fork_posix(args: list[str], cwd: None = None, shell: bool = False) -> int:
    """Launch a process in the background."""
    encoded_args = [encode(arg) for arg in args]
    return subprocess.Popen(encoded_args, cwd=cwd, shell=shell).pid


def _fork_win32(args, cwd=None, shell: bool = False) -> int:
    """Launch a background process using crazy win32 voodoo."""
    # This is probably wrong, but it works.  Windows.. Wow.
    if args[0] == 'git-dag':
        # win32 can't exec python scripts
        args = [sys.executable] + args

    if not shell:
        args[0] = _win32_find_exe(args[0])

    if PY3:
        # see comment in start_command()
        argv = [decode(arg) for arg in args]
    else:
        argv = [encode(arg) for arg in args]

    DETACHED_PROCESS = 0x00000008  # Amazing!
    return subprocess.Popen(
        argv, cwd=cwd, creationflags=DETACHED_PROCESS, shell=shell
    ).pid


def _win32_find_exe(exe: Any) -> Any:
    """Find the actual file for a Windows executable.

    This function goes through the same process that the Windows shell uses to
    locate an executable, taking into account the PATH and PATHEXT environment
    variables.  This allows us to avoid passing shell=True to subprocess.Popen.

    For reference, see:
    https://technet.microsoft.com/en-us/library/cc723564.aspx#XSLTsection127121120120

    """
    # try the argument itself
    candidates = [exe]
    # if argument does not have an extension, also try it with each of the
    # extensions specified in PATHEXT
    if '.' not in exe:
        extensions = getenv('PATHEXT', '').split(os.pathsep)
        candidates.extend([(exe + ext) for ext in extensions if ext.startswith('.')])
    # search the current directory first
    for candidate in candidates:
        if exists(candidate):
            return candidate
    # if the argument does not include a path separator, search each of the
    # directories on the PATH
    if not os.path.dirname(exe):
        for path in getenv('PATH').split(os.pathsep):
            if path:
                for candidate in candidates:
                    full_path = os.path.join(path, candidate)
                    if exists(full_path):
                        return full_path
    # not found, punt and return the argument unchanged
    return exe


# Portability wrappers
if sys.platform in {'win32', 'cygwin'}:
    fork = _fork_win32
else:
    fork = _fork_posix


def _decorator_noop(x: bool | os.stat_result | None) -> bool | os.stat_result | None:
    return x


def wrap(
    action: Callable, func: Callable, decorator: Callable | None = None
) -> Callable:
    """Wrap arguments with `action`, optionally decorate the result"""
    if decorator is None:
        decorator = _decorator_noop

    @functools.wraps(func)
    def wrapped(*args, **kwargs):
        return decorator(func(action(*args, **kwargs)))

    return wrapped


def decorate(decorator, func) -> functools._Wrapped[..., Any, ..., Any]:
    """Decorate the result of `func` with `action`"""

    @functools.wraps(func)
    def decorated(*args, **kwargs):
        return decorator(func(*args, **kwargs))

    return decorated


def getenv(name: str, default: str | None = None) -> UStr | None:
    return decode(os.getenv(name, default))


def guess_mimetype(filename: str) -> str | None:
    """Robustly guess a filename's mimetype"""
    mimetype = None
    try:
        mimetype = mimetypes.guess_type(filename)[0]
    except UnicodeEncodeError:
        mimetype = mimetypes.guess_type(encode(filename))[0]  # type: ignore[arg-type]
    except (TypeError, ValueError):
        mimetype = mimetypes.guess_type(decode(filename))[0]
    return mimetype


def xopen(path: str, mode: str = 'r', encoding: None = None) -> Any:
    """Open a file with the specified mode and encoding

    The path is decoded into Unicode on Windows and encoded into bytes on Unix.
    """
    return open(mkpath(path, encoding=encoding), mode)


def open_append(path, encoding=None) -> TextIOWrapper:
    """Open a file for appending in UTF-8 text mode"""
    return open(mkpath(path, encoding=encoding), 'a', encoding='utf-8')


def open_read(path: str, encoding: None = None) -> TextIOWrapper:
    """Open a file for reading in UTF-8 text mode"""
    return open(mkpath(path, encoding=encoding), encoding='utf-8')


def open_write(path: str, encoding: None = None) -> TextIOWrapper:
    """Open a file for writing in UTF-8 text mode"""
    return open(mkpath(path, encoding=encoding), 'w', encoding='utf-8')


def print_stdout(msg, linesep: str = '\n') -> None:
    msg = msg + linesep
    if PY2:
        msg = encode(msg, encoding=ENCODING)
    sys.stdout.write(msg)


def print_stderr(msg, linesep: str = '\n') -> None:
    msg = msg + linesep
    if PY2:
        msg = encode(msg, encoding=ENCODING)
    sys.stderr.write(msg)


def error(msg, status=EXIT_FAILURE, linesep: str = '\n') -> None:
    print_stderr(msg, linesep=linesep)
    sys.exit(status)


@interruptable
def node() -> str:
    return platform.node()


abspath = wrap(mkpath, os.path.abspath, decorator=decode)
chdir = wrap(mkpath, os.chdir)
exists = wrap(mkpath, os.path.exists)
expanduser = wrap(encode, os.path.expanduser, decorator=decode)
if PY2:
    if hasattr(os, 'getcwdu'):
        getcwd = os.getcwdu
    else:
        getcwd = decorate(decode, os.getcwd)
else:
    getcwd = os.getcwd


# NOTE: find_executable() is originally from the stdlib, but starting with
# python3.7 the stdlib no longer bundles distutils.
def _find_executable(executable: UStr, path: str | None = None) -> str | None:
    """Tries to find 'executable' in the directories listed in 'path'.

    A string listing directories separated by 'os.pathsep'; defaults to
    os.environ['PATH'].  Returns the complete filename or None if not found.
    """
    if path is None:
        path = os.environ['PATH']

    paths = path.split(os.pathsep)
    _, ext = os.path.splitext(executable)

    if (sys.platform == 'win32') and (ext != '.exe'):
        executable = executable + '.exe'

    if not os.path.isfile(executable):
        for dirname in paths:
            filename = os.path.join(dirname, executable)
            if os.path.isfile(filename):
                # the file exists, we have a shot at spawn working
                return filename
        return None

    return executable


def _fdatasync(fd: int) -> None:
    """fdatasync the file descriptor. Returns True on success"""
    try:
        os.fdatasync(fd)
    except OSError:
        pass


def _fsync(fd) -> None:
    """fsync the file descriptor. Returns True on success"""
    try:
        os.fsync(fd)
    except OSError:
        pass


def fsync(fd: int) -> None:
    """Flush contents to disk using fdatasync() / fsync()"""
    has_libc_fdatasync = False
    has_libc_fsync = False
    has_os_fdatasync = hasattr(os, 'fdatasync')
    has_os_fsync = hasattr(os, 'fsync')
    if not has_os_fdatasync and not has_os_fsync:
        try:
            libc = ctypes.CDLL('libc.so.6')
        except OSError:
            libc = None
        has_libc_fdatasync: bool | None = libc and hasattr(libc, 'fdatasync')
        has_libc_fsync: bool | None = libc and hasattr(libc, 'fsync')
    if has_os_fdatasync:
        _fdatasync(fd)
    elif has_os_fsync:
        _fsync(fd)
    elif has_libc_fdatasync:
        libc.fdatasync(fd)
    elif has_libc_fsync:
        libc.fsync(fd)


def rename(old: str, new: str) -> None:
    """Rename a path. Transform arguments to handle non-ASCII file paths"""
    os.rename(mkpath(old), mkpath(new))


if PY2:
    find_executable = wrap(mkpath, _find_executable, decorator=decode)
else:
    find_executable = wrap(decode, _find_executable, decorator=decode)
isdir = wrap(mkpath, os.path.isdir)
isfile = wrap(mkpath, os.path.isfile)
islink = wrap(mkpath, os.path.islink)
listdir = wrap(mkpath, os.listdir, decorator=decode_seq)
makedirs = wrap(mkpath, os.makedirs)
try:
    readlink = wrap(mkpath, os.readlink, decorator=decode)
except AttributeError:

    def _readlink_noop(p):
        return p

    readlink = _readlink_noop

realpath = wrap(mkpath, os.path.realpath, decorator=decode)
relpath = wrap(mkpath, os.path.relpath, decorator=decode)
remove = wrap(mkpath, os.remove)
stat = wrap(mkpath, os.stat)
unlink = wrap(mkpath, os.unlink)
if PY2:
    walk = wrap(mkpath, os.walk)
else:
    walk = os.walk
