"""File download with SHA256 verification."""

import hashlib
import time
from pathlib import Path

import httpx


def download_file(url: str, dest: Path, chunk_size: int = 8192) -> dict:
    """Download a file and return path + SHA256 checksum."""
    dest.parent.mkdir(parents=True, exist_ok=True)

    sha256 = hashlib.sha256()
    downloaded = 0
    started = time.time()

    with httpx.stream("GET", url, timeout=120, follow_redirects=True) as r:
        r.raise_for_status()
        with open(dest, "wb") as f:
            for chunk in r.iter_bytes(chunk_size):
                f.write(chunk)
                sha256.update(chunk)
                downloaded += len(chunk)

    elapsed = round(time.time() - started, 2)

    return {
        "path": str(dest),
        "url": url,
        "sha256": sha256.hexdigest(),
        "size_bytes": downloaded,
        "elapsed_seconds": elapsed,
    }


def verify_bundle(bundle_dir: Path) -> list[dict]:
    """Verify SHA256 checksums of all files listed in manifest.json."""
    import json

    manifest_path = bundle_dir / "manifest.json"
    if not manifest_path.exists():
        raise FileNotFoundError(f"No manifest.json found in {bundle_dir}")

    manifest = json.loads(manifest_path.read_text())
    results = []

    for entry in manifest.get("files", []):
        path = bundle_dir / Path(entry["path"]).name
        expected = entry.get("sha256", "")

        if not path.exists():
            results.append({"file": str(path), "status": "MISSING"})
            continue

        sha256 = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256.update(chunk)

        actual = sha256.hexdigest()
        status = "OK" if actual == expected else "MISMATCH"
        results.append({
            "file": str(path),
            "status": status,
            "expected": expected,
            "actual": actual,
        })

    return results
