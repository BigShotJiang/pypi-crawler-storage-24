"""Command line interface for genomebundle."""

import json
import sys
from pathlib import Path

import click

from genomebundle.goat import fetch_assembly
from genomebundle.ncbi import fetch_assembly_report, build_ftp_urls
from genomebundle.blobtoolkit import fetch_busco
from genomebundle.manifest import build_manifest, write_manifest, write_readme
from genomebundle.download import download_file, verify_bundle


@click.group()
@click.version_option()
def main():
    """genomebundle — reproducible bundles for EBP genome assemblies."""


@main.command()
@click.argument("accession")
@click.option(
    "--output-dir", "-o",
    default=None,
    help="Output directory (default: ./<accession>)",
)
@click.option(
    "--no-download",
    is_flag=True,
    default=False,
    help="Build manifest only, do not download files.",
)
@click.option(
    "--files",
    default="fasta,gff",
    show_default=True,
    help="Comma-separated list of file types to download: "
         "fasta, gff, rna, protein, cds, report, stats, md5, all",
)
def fetch(accession: str, output_dir: str, no_download: bool, files: str):
    """Fetch metadata and files for an assembly ACCESSION.

    Example: genomebundle fetch GCF_040938575.1
    """
    bundle_dir = Path(output_dir) if output_dir else Path(accession)

    click.echo(f"[1/4] Fetching GoaT metadata for {accession}...")
    try:
        goat_data = fetch_assembly(accession)
    except Exception as e:
        click.echo(f"  Warning: GoaT fetch failed ({e})", err=True)
        goat_data = {
            "accession": accession,
            "scientific_name": "",
            "common_name": "",
            "taxon_id": "",
            "lineage": [],
            "goat_url": f"https://goat.genomehubs.org/record?recordId={accession}&result=assembly",
        }

    click.echo(f"[2/4] Fetching NCBI assembly report...")
    try:
        ncbi_data = fetch_assembly_report(accession)
    except Exception as e:
        click.echo(f"  Error: NCBI fetch failed ({e})", err=True)
        sys.exit(1)

    click.echo(f"[3/4] Fetching BlobToolKit BUSCO results...")
    try:
        btk_data = fetch_busco(accession)
        if not btk_data["found"]:
            click.echo("  Warning: no BlobToolKit dataset found for this accession.")
    except Exception as e:
        click.echo(f"  Warning: BlobToolKit fetch failed ({e})", err=True)
        btk_data = {"found": False, "accession": accession, "btk_url": None, "busco": {}}

    assembly_name = ncbi_data["assembly_name"]
    ftp_urls = build_ftp_urls(accession, assembly_name)

    downloaded_files = []

    if not no_download:
        click.echo(f"[4/4] Downloading files to {bundle_dir}/...")

        file_keys = _resolve_file_keys(files)

        for key in file_keys:
            url = ftp_urls.get(key)
            if not url:
                click.echo(f"  Skipping unknown file type: {key}")
                continue
            filename = url.split("/")[-1]
            dest = bundle_dir / filename
            click.echo(f"  Downloading {filename}...")
            try:
                result = download_file(url, dest)
                downloaded_files.append(result)
                click.echo(f"  OK ({result['size_bytes']} bytes, sha256: {result['sha256'][:16]}...)")
            except Exception as e:
                click.echo(f"  Warning: failed to download {filename}: {e}", err=True)
    else:
        click.echo("[4/4] Skipping downloads (--no-download)")

    manifest = build_manifest(goat_data, ncbi_data, btk_data, ftp_urls, downloaded_files)
    manifest_path = write_manifest(manifest, bundle_dir)
    readme_path = write_readme(manifest, bundle_dir)

    click.echo(f"\nDone.")
    click.echo(f"  manifest : {manifest_path}")
    click.echo(f"  readme   : {readme_path}")
    click.echo(f"  assembly : {ncbi_data['organism_name']} ({accession})")
    click.echo(f"  level    : {ncbi_data['assembly_level']}")


@main.command()
@click.argument("bundle_dir", default=".")
def verify(bundle_dir: str):
    """Verify SHA256 checksums of a downloaded bundle.

    Example: genomebundle verify ./GCF_040938575.1/
    """
    path = Path(bundle_dir)
    click.echo(f"Verifying bundle in {path}...")
    try:
        results = verify_bundle(path)
    except FileNotFoundError as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)

    all_ok = True
    for r in results:
        status = r["status"]
        fname = Path(r["file"]).name
        if status == "OK":
            click.echo(f"  OK       {fname}")
        elif status == "MISSING":
            click.echo(f"  MISSING  {fname}")
            all_ok = False
        else:
            click.echo(f"  MISMATCH {fname}")
            click.echo(f"    expected: {r['expected']}")
            click.echo(f"    actual:   {r['actual']}")
            all_ok = False

    if all_ok:
        click.echo("All files verified successfully.")
    else:
        click.echo("Verification failed.", err=True)
        sys.exit(1)


@main.command()
@click.argument("bundle_dir", default=".")
def show(bundle_dir: str):
    """Print the manifest of an existing bundle.

    Example: genomebundle show ./GCF_040938575.1/
    """
    path = Path(bundle_dir) / "manifest.json"
    if not path.exists():
        click.echo(f"Error: no manifest.json found in {bundle_dir}", err=True)
        sys.exit(1)
    click.echo(path.read_text())


@main.command()
@click.argument("bundle_dir", default=".")
@click.option("--format", "fmt", 
              type=click.Choice(["text", "bibtex"]), 
              default="text",
              help="Output format.")
def cite(bundle_dir: str, fmt: str):
    """Generate a Data Availability statement from a bundle.

    Example: genomebundle cite ./GCF_040938575.1/
    """
    from genomebundle.manifest import build_citation

    path = Path(bundle_dir) / "manifest.json"
    if not path.exists():
        click.echo(f"Error: no manifest.json found in {bundle_dir}", err=True)
        sys.exit(1)

    import json
    manifest = json.loads(path.read_text())
    click.echo(build_citation(manifest))


def _resolve_file_keys(files_str: str) -> list[str]:
    """Resolve comma-separated file type string to FTP URL keys."""
    all_keys = [
        "fasta_genomic", "gff_genomic", "rna_fasta",
        "protein_fasta", "cds_fasta", "assembly_report",
        "assembly_stats", "md5checksums",
    ]
    alias_map = {
        "fasta": "fasta_genomic",
        "gff": "gff_genomic",
        "rna": "rna_fasta",
        "protein": "protein_fasta",
        "cds": "cds_fasta",
        "report": "assembly_report",
        "stats": "assembly_stats",
        "md5": "md5checksums",
    }
    if files_str.strip() == "all":
        return all_keys

    result = []
    for token in files_str.split(","):
        token = token.strip()
        key = alias_map.get(token, token)
        if key in all_keys:
            result.append(key)
        else:
            click.echo(f"  Warning: unknown file type '{token}', skipping.")
    return result
