"""Build manifest and README for a genomebundle."""

import json
from datetime import datetime, timezone
from pathlib import Path


def build_manifest(
    goat_data: dict,
    ncbi_data: dict,
    btk_data: dict,
    ftp_urls: dict,
    downloaded_files: list[dict],
) -> dict:
    """Assemble the machine-readable manifest."""
    return {
        "genomebundle_version": "0.1.0",
        "generated": datetime.now(timezone.utc).isoformat(),
        "assembly": {
            "accession": ncbi_data["accession"],
            "name": ncbi_data["assembly_name"],
            "level": ncbi_data["assembly_level"],
            "status": ncbi_data["assembly_status"],
            "release_date": ncbi_data["release_date"],
            "submitter": ncbi_data["submitter"],
            "bioproject": ncbi_data["bioproject"],
            "biosample": ncbi_data["biosample"],
        },
        "organism": {
            "scientific_name": goat_data["scientific_name"],
            "common_name": goat_data["common_name"],
            "taxon_id": goat_data["taxon_id"],
        },
        "stats": {
            "total_sequence_length": ncbi_data["total_sequence_length"],
            "scaffold_n50": ncbi_data["scaffold_n50"],
            "contig_n50": ncbi_data["contig_n50"],
            "number_of_chromosomes": ncbi_data["number_of_chromosomes"],
            "gc_percent": ncbi_data["gc_percent"],
        },
        "busco": btk_data.get("busco", {}),
        "sources": {
            "goat": goat_data["goat_url"],
            "ncbi": f"https://www.ncbi.nlm.nih.gov/datasets/genome/{ncbi_data['accession']}/",
            "blobtoolkit": btk_data.get("btk_url"),
        },
        "ftp_urls": ftp_urls,
        "files": downloaded_files,
    }


def write_manifest(manifest: dict, bundle_dir: Path) -> Path:
    """Write manifest.json to bundle directory."""
    bundle_dir.mkdir(parents=True, exist_ok=True)
    path = bundle_dir / "manifest.json"
    path.write_text(json.dumps(manifest, indent=2))
    return path


def build_readme(manifest: dict) -> str:
    """Build human-readable README.txt from manifest."""
    m = manifest
    asm = m["assembly"]
    org = m["organism"]
    stats = m["stats"]
    sources = m["sources"]

    lines = [
        "genomebundle",
        "=" * 60,
        f"Generated:    {m['generated']}",
        "",
        "ORGANISM",
        f"  Scientific name : {org['scientific_name']}",
        f"  Common name     : {org['common_name']}",
        f"  TaxID           : {org['taxon_id']}",
        "",
        "ASSEMBLY",
        f"  Accession       : {asm['accession']}",
        f"  Name            : {asm['name']}",
        f"  Level           : {asm['level']}",
        f"  Release date    : {asm['release_date']}",
        f"  Submitter       : {asm['submitter']}",
        f"  BioProject      : {asm['bioproject']}",
        f"  BioSample       : {asm['biosample']}",
        "",
        "STATISTICS",
        f"  Total length    : {stats['total_sequence_length']} bp",
        f"  Scaffold N50    : {stats['scaffold_n50']} bp",
        f"  Contig N50      : {stats['contig_n50']} bp",
        f"  Chromosomes     : {stats['number_of_chromosomes']}",
        f"  GC%             : {stats['gc_percent']}",
        "",
        "BUSCO",
    ]

    busco = m.get("busco", {})
    if busco:
        for lineage, vals in busco.items():
            lines.append(f"  {lineage}")
            lines.append(f"    Complete    : {vals.get('complete', 'N/A')}%")
            lines.append(f"    Duplicated  : {vals.get('duplicated', 'N/A')}%")
            lines.append(f"    Fragmented  : {vals.get('fragmented', 'N/A')}%")
            lines.append(f"    Missing     : {vals.get('missing', 'N/A')}%")
            lines.append(f"    Markers     : {vals.get('n_markers', 'N/A')}")
    else:
        lines.append("  Not available")

    lines += [
        "",
        "SOURCES",
        f"  GoaT        : {sources['goat']}",
        f"  NCBI        : {sources['ncbi']}",
        f"  BlobToolKit : {sources.get('blobtoolkit', 'N/A')}",
        "",
        "FILES",
    ]

    for f in m.get("files", []):
        lines.append(f"  {Path(f['path']).name}")
        lines.append(f"    SHA256  : {f.get('sha256', 'N/A')}")
        lines.append(f"    Size    : {f.get('size_bytes', 'N/A')} bytes")
        lines.append(f"    Source  : {f.get('url', 'N/A')}")

    return "\n".join(lines) + "\n"


def write_readme(manifest: dict, bundle_dir: Path) -> Path:
    """Write README.txt to bundle directory."""
    path = bundle_dir / "README.txt"
    path.write_text(build_readme(manifest))
    return path


def build_citation(manifest: dict) -> str:
    """Generate a ready-to-paste Data Availability statement."""
    asm = manifest["assembly"]
    org = manifest["organism"]
    stats = manifest["stats"]
    sources = manifest["sources"]
    generated = manifest["generated"][:10]  # YYYY-MM-DD
    version = manifest.get("genomebundle_version", "")

    # pick most relevant BUSCO lineage (first available)
    busco_str = ""
    busco = manifest.get("busco", {})
    if busco:
        lineage, vals = next(iter(busco.items()))
        busco_str = (
            f" Assembly completeness was assessed via BlobToolKit "
            f"({lineage} BUSCO complete: {vals['complete']}%)."
        )

    name = org["scientific_name"]
    common = f" ({org['common_name']})" if org["common_name"] else ""
    taxid = org["taxon_id"]

    return (
        f"Genome assembly data for {name}{common} (TaxID: {taxid}) "
        f"was obtained from NCBI (accession {asm['accession']}, "
        f"assembly {asm['name']}, released {asm['release_date']}, "
        f"BioProject {asm['bioproject']}). "
        f"Metadata was retrieved from GoaT on {generated} "
        f"({sources['goat']})."
        f"{busco_str} "
        f"Files were downloaded with genomebundle v{version} "
        f"(https://github.com/gbell27/genomebundle)."
    )


