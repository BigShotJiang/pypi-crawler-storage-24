"""genomebundle — reproducible bundles for EBP genome assemblies."""

from genomebundle.goat import fetch_assembly
from genomebundle.ncbi import fetch_assembly_report, build_ftp_urls
from genomebundle.blobtoolkit import fetch_busco
from genomebundle.manifest import build_manifest, write_manifest, build_readme, write_readme, build_citation
from genomebundle.download import download_file, verify_bundle

__version__ = "0.1.0"

__all__ = [
    "fetch_assembly",
    "fetch_assembly_report",
    "build_ftp_urls",
    "fetch_busco",
    "build_manifest",
    "write_manifest",
    "build_readme",
    "write_readme",
    "download_file",
    "verify_bundle",
	"build_citation"
]
