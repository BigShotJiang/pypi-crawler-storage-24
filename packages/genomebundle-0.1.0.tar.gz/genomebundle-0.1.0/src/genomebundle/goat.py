"""GoaT API client — Genomes on a Tree (goat.genomehubs.org)."""

import httpx

GOAT_BASE = "https://goat.genomehubs.org/api/v2"


def fetch_assembly(accession: str) -> dict:
    """Fetch assembly record from GoaT by INSDC accession."""
    url = f"{GOAT_BASE}/record"
    params = {
        "recordId": accession,
        "result": "assembly",
        "taxonomy": "ncbi",
    }
    r = httpx.get(url, params=params, timeout=30)
    r.raise_for_status()
    data = r.json()

    records = data.get("records", [])
    if not records:
        raise ValueError(f"No GoaT record found for accession: {accession}")

    record = records[0].get("record", {})

    scientific_name = record.get("scientific_name", "")
    taxon_id = str(record.get("taxon_id", ""))
    lineage = record.get("lineage", [])

    # extract common name from taxon_names list
    common_name = ""
    for entry in record.get("taxon_names", []):
        if entry.get("class") == "genbank common name":
            common_name = entry.get("name", "")
            break

    return {
        "accession": accession,
        "scientific_name": scientific_name,
        "common_name": common_name,
        "taxon_id": taxon_id,
        "lineage": lineage,
        "goat_url": f"https://goat.genomehubs.org/record?recordId={accession}&result=assembly",
    }
