"""BlobToolKit API client — blobtoolkit.genomehubs.org"""

import httpx

BTK_BASE = "https://blobtoolkit.genomehubs.org/api/v1"


def fetch_busco(accession: str) -> dict:
    """Fetch BUSCO results from BlobToolKit by assembly accession."""
    url = f"{BTK_BASE}/search/{accession}"
    r = httpx.get(url, timeout=30)
    r.raise_for_status()
    results = r.json()

    if not results:
        return {
            "found": False,
            "accession": accession,
            "btk_url": None,
            "busco": {},
        }

    dataset = results[0]
    dataset_id = dataset.get("id", "")

    busco_raw = dataset.get("summaryStats", {}).get("busco", {})
    busco = {}
    for lineage, vals in busco_raw.items():
        total = vals.get("t", 0)
        busco[lineage] = {
            "complete":   round(vals.get("c", 0) / total * 100, 1) if total else "",
            "single":     round(vals.get("s", 0) / total * 100, 1) if total else "",
            "duplicated": round(vals.get("d", 0) / total * 100, 1) if total else "",
            "fragmented": round(vals.get("f", 0) / total * 100, 1) if total else "",
            "missing":    round(vals.get("m", 0) / total * 100, 1) if total else "",
            "n_markers":  total,
            "string":     vals.get("string", ""),
        }

    return {
        "found": True,
        "accession": accession,
        "dataset_id": dataset_id,
        "busco": busco,
        "btk_url": f"https://blobtoolkit.genomehubs.org/view/{dataset_id}",
    }
