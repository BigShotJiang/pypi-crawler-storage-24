"""aiohttp application factory."""

from __future__ import annotations

from typing import TYPE_CHECKING

from aiohttp import web

from meeting_helper.server.routes import setup_routes

if TYPE_CHECKING:
    from meeting_helper.config import AppConfig


def create_app(config: "AppConfig") -> web.Application:
    app = web.Application()
    app["config"] = config
    setup_routes(app)
    return app
