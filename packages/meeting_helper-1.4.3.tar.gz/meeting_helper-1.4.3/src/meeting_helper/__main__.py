"""Entry point for `python -m meeting_helper`."""

from meeting_helper.cli import cli

if __name__ == "__main__":
    cli()
