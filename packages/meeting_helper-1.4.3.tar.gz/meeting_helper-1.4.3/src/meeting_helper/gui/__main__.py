"""Entry point for `python -m meeting_helper.gui`."""

from meeting_helper.config import get_config
from meeting_helper.gui.app import run_gui

if __name__ == "__main__":
    config = get_config()
    run_gui(config)
