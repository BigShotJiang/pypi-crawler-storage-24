"""Transcript text viewer widget."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import QLabel, QTextEdit, QVBoxLayout, QWidget


class TranscriptView(QWidget):
    """Read-only text viewer for transcripts and summaries."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        self._title = QLabel()
        self._title.setStyleSheet("font-size: 14px; font-weight: 600; color: #ffffff; padding: 8px 0;")
        self._title.hide()
        layout.addWidget(self._title)

        self._text = QTextEdit()
        self._text.setReadOnly(True)
        self._text.setStyleSheet("""
            QTextEdit {
                background-color: #0d0d0d;
                border: 1px solid #2a2a2a;
                border-radius: 6px;
                color: #d4d4d4;
                font-family: "Menlo", monospace;
                font-size: 13px;
                padding: 12px;
            }
        """)
        layout.addWidget(self._text)

    def set_title(self, title: str):
        self._title.setText(title)
        self._title.show()

    def set_text(self, text: str):
        self._text.setPlainText(text)

    def load_file(self, path: str | Path):
        p = Path(path)
        if p.exists():
            self.set_title(p.name)
            self.set_text(p.read_text())
        else:
            self.set_title("File not found")
            self.set_text(f"Could not find: {path}")

    def clear(self):
        self._title.hide()
        self._text.clear()
