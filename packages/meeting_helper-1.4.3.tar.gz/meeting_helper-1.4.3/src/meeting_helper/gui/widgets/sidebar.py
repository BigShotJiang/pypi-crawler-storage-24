"""Navigation sidebar for Meeting Helper GUI."""

from __future__ import annotations

from PySide6.QtCore import Qt, Signal
from PySide6.QtWidgets import (
    QButtonGroup,
    QFrame,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QVBoxLayout,
    QWidget,
)


class Sidebar(QWidget):
    """Navigation sidebar with screen buttons and status display."""

    screen_selected = Signal(str)
    quit_requested = Signal()

    NAV_ITEMS = [
        ("dashboard", "Dashboard"),
        ("recordings", "Recordings"),
        ("workspace", "Workspace"),
        ("settings", "Settings"),
    ]

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("sidebar")
        self.setFixedWidth(200)
        self._buttons: dict[str, QPushButton] = {}
        self._setup_ui()

    def _setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Title
        title_frame = QFrame()
        title_frame.setObjectName("sidebar-title-frame")
        title_layout = QHBoxLayout(title_frame)
        title_layout.setContentsMargins(15, 18, 15, 18)
        title_label = QLabel("Meeting Helper")
        title_label.setObjectName("sidebar-title")
        title_layout.addWidget(title_label)
        layout.addWidget(title_frame)

        # Navigation buttons
        layout.addSpacing(8)
        self._btn_group = QButtonGroup(self)
        self._btn_group.setExclusive(True)

        for screen_id, label in self.NAV_ITEMS:
            btn = QPushButton(f"  {label}")
            btn.setCheckable(True)
            btn.setCursor(Qt.PointingHandCursor)
            self._btn_group.addButton(btn)
            self._buttons[screen_id] = btn
            btn.clicked.connect(lambda checked, sid=screen_id: self.screen_selected.emit(sid))
            layout.addWidget(btn)

        layout.addStretch()

        # Status area
        self._status_frame = QFrame()
        self._status_frame.setObjectName("sidebar-status")
        status_layout = QVBoxLayout(self._status_frame)
        status_layout.setContentsMargins(15, 10, 15, 10)

        self._status_label = QLabel("Idle")
        self._status_label.setStyleSheet("color: #808080; font-size: 12px;")
        self._status_label.setWordWrap(True)
        status_layout.addWidget(self._status_label)

        layout.addWidget(self._status_frame)

        # Quit button
        quit_btn = QPushButton("  Quit")
        quit_btn.setCursor(Qt.PointingHandCursor)
        quit_btn.setStyleSheet("""
            QPushButton { background: transparent; color: #808080; border: none; padding: 12px 15px; text-align: left; margin: 3px 10px; font-size: 14px; }
            QPushButton:hover { color: #f14c4c; background-color: #1a1a1a; }
        """)
        quit_btn.clicked.connect(self.quit_requested.emit)
        layout.addWidget(quit_btn)
        layout.addSpacing(8)

    def select_screen(self, screen_id: str):
        """Select a screen button programmatically."""
        btn = self._buttons.get(screen_id)
        if btn:
            btn.setChecked(True)

    def update_status(self, recording: bool, meeting_name: str):
        """Update the status display."""
        if recording:
            name = meeting_name[:25] + "..." if len(meeting_name) > 25 else meeting_name
            self._status_label.setText(f"Recording: {name}")
            self._status_label.setStyleSheet("color: #f14c4c; font-size: 12px;")
        else:
            self._status_label.setText("Idle")
            self._status_label.setStyleSheet("color: #808080; font-size: 12px;")
