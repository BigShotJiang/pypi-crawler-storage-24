"""Dark theme colors and styling for Meeting Helper GUI."""

from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QApplication

COLORS = {
    "bg_primary": "#1e1e1e",
    "bg_secondary": "#252526",
    "bg_tertiary": "#2d2d2d",
    "bg_hover": "#3c3c3c",
    "bg_selected": "#094771",
    "text_primary": "#cccccc",
    "text_secondary": "#858585",
    "text_disabled": "#5a5a5a",
    "text_white": "#ffffff",
    "accent_primary": "#0078d4",
    "accent_success": "#4ec9b0",
    "accent_warning": "#dcdcaa",
    "accent_error": "#f14c4c",
    "accent_info": "#9cdcfe",
    "status_recording": "#f14c4c",
    "status_ready": "#4ec9b0",
    "status_idle": "#5a5a5a",
    "border_default": "#3c3c3c",
    "border_focus": "#007acc",
    "sidebar_bg": "#252526",
    "sidebar_item_hover": "#2a2d2e",
    "sidebar_item_selected": "#37373d",
}


def get_stylesheet() -> str:
    """Load the QSS stylesheet."""
    stylesheet_path = Path(__file__).parent / "styles.qss"
    if stylesheet_path.exists():
        return stylesheet_path.read_text()
    return ""


def apply_theme(app: QApplication) -> None:
    """Apply the dark theme to the application."""
    stylesheet = get_stylesheet()
    app.setStyleSheet(stylesheet)
