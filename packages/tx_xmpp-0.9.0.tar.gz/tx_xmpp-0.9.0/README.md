Tx-XMPP
======

Forewords
---------

This is an XMPP implementation for Twisted.

This project is a friendly fork of [Wokkel](https://github.com/ralphm/wokkel.git) due to it
being currently unmaintained and not compatible with the latest version of Twisted.
Its aim is to keep the project up-to-date and improved, but the maintenance will be
minimal. It keeps the same license as the original Wokkel, and the same package name once
installed. If one day the original Wokkel comes back to life, this project may be stopped
and changes merged back to Wokkel.

This project also implements changes necessary for the Libervia project
([https://libervia.org](https://libervia.org)), in particular RSM and MAM support. Modern tooling (notably
`pyproject.toml` support) and type hints should progressively be added.

A big thanks to Ralph Meijer and other contributors for all the work done.

The sections below are taken from the original projects, but updated to reflect the current
situation.

What is this?
-------------

Tx-XMPP is an implementation built on top of Twisted. It is a friendly fork of Wokkel
maintained to keep compatible with the latest Python and Twisted versions, to use modern
tooling and type hints, and to add some features.

The original Wokkel description was:
Wokkel is a Python module for experimenting with future enhancements to Twisted
Words, that should eventually be included in the main Twisted development
tree. Some of the code in Wokkel has already made that transition, but is still
included to be used with older Twisted releases.

Requirements
------------

- Python 3.10 or later
- Twisted 22.1.0 or later with TLS support
- python-dateutil
- constantly

Resources
---------

Wokkel has a [home](https://wokkel.ik.nu/) and [documentation](https://wokkel.ik.nu/documentation/).

Besides the general Twisted resources, help is available on the
[Twisted-Jabber mailing list](https://mailman.ik.nu/mailman/listinfo/twisted-jabber).

Copyright and Warranty
----------------------

The original code in this distribution (pre-fork) is Copyright (c) Ralph Meijer, unless
explicitly specified otherwise.

The Tx-XMPP fork was created on 2026-03-20. Please check the Git logs to see the author of
changes and the related copyright.

Tx-XMPP is made available under the MIT License (same as Wokkel). The included [LICENSE](LICENSE) file
describes this in detail.

Contributors
------------

- Christopher Zorn
- Jack Moffitt
- Mike Malone
- Pablo Martín
- Fabio Forno
- Kandaurov Oleg
- Jérôme Poisson
- Ilja Braude
- Alexey Bezhan
- Mayank Singh
- Adrien Cossa
- Arnaud Joset (contribution to `sat_tmp`)

Original Author
---------------

Ralph Meijer
- Email: [ralphm@ik.nu](mailto:ralphm@ik.nu)
- XMPP: [ralphm@ik.nu](xmpp:ralphm@ik.nu)

Current Maintainer
------------------

Jérôme Poisson (aka Goffi)
- Email: [goffi@goffi.org](mailto:goffi@goffi.org)
- You can contact me on the official Libervia XMPP room at
  [xmpp:libervia@chat.jabberfr.org?join](xmpp:libervia@chat.jabberfr.org?join)

Name
----

Wokkel lends its name from a popular Twisted savory snack in the Netherlands.

The current fork has been named Tx-XMPP to avoid confusion with the original, but the
Python package keeps the `wokkel` name (for compatibility). `Tx` is a common prefix used
in the Twisted community to indicate that it's a Twisted-related package.
