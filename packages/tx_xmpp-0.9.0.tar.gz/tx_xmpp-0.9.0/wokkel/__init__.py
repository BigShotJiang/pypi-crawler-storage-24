# Copyright (c) Ralph Meijer.
# See LICENSE for details

"""
Wokkel.

Support library for Twisted applications using XMPP protocols.
"""

from importlib.metadata import PackageNotFoundError, version

try:
    __version__ = version("tx-xmpp")
except PackageNotFoundError:
    __version__ = "0.0.0"

__all__ = ["__version__"]
