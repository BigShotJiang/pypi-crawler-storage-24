# m2datakit/__init__.py

# Convenience imports available at package import time
import glob  # noqa: F401
import json  # noqa: F401
import os  # noqa: F401
import re  # noqa: F401

from dotenv import load_dotenv  # noqa: F401

from . import core, tasks

__all__ = [
    "core",
    "tasks",
]
