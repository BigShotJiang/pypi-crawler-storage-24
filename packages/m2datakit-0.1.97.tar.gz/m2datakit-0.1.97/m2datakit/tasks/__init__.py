"""Task modules and summarize helpers.

Auto-builds a mapping from task name -> summarize function by scanning
modules in this package that define `summarize`.
"""

from __future__ import annotations

from importlib import import_module
from pkgutil import iter_modules
from typing import Callable, Dict


def _title_case(name: str) -> str:
    return " ".join(part.capitalize() for part in name.split("_"))


def _camel_case(name: str) -> str:
    parts = name.split("_")
    if not parts:
        return name
    return parts[0] + "".join(part.capitalize() for part in parts[1:])


def build_summary_func_map() -> Dict[str, Callable]:
    """Return a mapping of task names to summarize functions.

    Adds "Title Case", "kebab-case", "snake_case", and "camelCase" keys
    for each task module that defines a `summarize` function.
    """
    mapping: Dict[str, Callable] = {}
    for modinfo in iter_modules(__path__):  # type: ignore[name-defined]
        module_name = modinfo.name
        module = import_module(f"{__name__}.{module_name}")
        summarize = getattr(module, "summarize", None)
        if summarize is None:
            continue
        title_key = _title_case(module_name)
        kebab_key = module_name.replace("_", "-")
        snake_key = module_name
        camel_key = _camel_case(module_name)
        mapping[title_key] = summarize
        mapping[kebab_key] = summarize
        mapping[snake_key] = summarize
        mapping[camel_key] = summarize
    return mapping


# Build once at import time for convenience (can be rebuilt if needed)
summary_func_map = build_summary_func_map()

__all__ = ["build_summary_func_map", "summary_func_map"]
