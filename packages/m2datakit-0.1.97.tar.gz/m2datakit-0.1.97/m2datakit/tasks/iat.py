import numpy as np
import pandas as pd

from ..core import helpers


def score_accuracy(row: pd.Series):
    """
    Score initial-response accuracy for a single IAT trial.

    Reads initial accuracy from actions_array[0]['response_correct'].

    Args:
        row (pd.Series): A single trial row.

    Returns:
        (int | None): 1 if correct, 0 if incorrect, None on null/error.
    """
    try:
        actions = row["actions_array"]
        if isinstance(actions, list) and actions:
            val = actions[0].get("response_correct")
            if val is None:
                return None
            return int(bool(val))
        return None
    except Exception as e:
        raise ValueError(f"Error processing row: {e}") from e


def score_initial_rt(row: pd.Series):
    """
    Extract the initial response time (ms) for a single IAT trial.

    Reads elapsed_duration_ms from the first entry in actions_array.

    Args:
        row (pd.Series): A single trial row.

    Returns:
        (float | None): Initial response time in ms, or None on null/error.
    """
    try:
        actions = row["actions_array"]
        if isinstance(actions, list) and actions:
            val = actions[0].get("elapsed_duration_ms")
            if val is None:
                return None
            return float(val)
        return None
    except Exception as e:
        raise ValueError(f"Error processing row: {e}") from e


def _derive_block_types_from_labels(df: pd.DataFrame) -> pd.Series:
    """
    Derive COMPATIBLE/INCOMPATIBLE block type for each trial from response_label_text.

    Uses combined-key labels (containing ' OR ') to identify which block_index values
    correspond to COMPATIBLE or INCOMPATIBLE pairings. Required because of
    counterbalancing (block ordering varies across sessions).

    Affective IAT:
      "Good OR Physical Activity" → COMPATIBLE
      "Bad OR Physical Activity"  → INCOMPATIBLE

    Identity IAT:
      "Self OR Physical Activity"     → COMPATIBLE
      "Not Self OR Physical Activity" → INCOMPATIBLE

    Requires 'block_index', 'short_code', and 'response_label_text' columns.

    Args:
        df (pd.DataFrame): Trial-level DataFrame.

    Returns:
        (pd.Series): Block type ('COMPATIBLE', 'INCOMPATIBLE', or None) per row.
    """
    result = pd.Series(None, index=df.index, dtype=object)
    required = {"block_index", "short_code", "response_label_text"}
    if not required.issubset(df.columns):
        return result

    for (bi, sc), group in df.groupby(["block_index", "short_code"]):
        combined = group.loc[
            group["response_label_text"].str.contains(" OR ", na=False, case=False),
            "response_label_text",
        ]
        if combined.empty:
            continue

        label = combined.iloc[0].lower()
        if "physical activity" not in label:
            continue

        if sc == "affective":
            if "good" in label:
                block_type = "COMPATIBLE"
            elif "bad" in label:
                block_type = "INCOMPATIBLE"
            else:
                continue
        elif sc == "identity":
            if "not self" in label:
                block_type = "INCOMPATIBLE"
            elif "self" in label:
                block_type = "COMPATIBLE"
            else:
                continue
        else:
            continue

        result.loc[group.index] = block_type

    return result


def _compute_d_score(
    df: pd.DataFrame,
    rt_col: str = "metric_initial_rt",
    rt_max: float = 10000,
    error_penalty_ms: float = 600,
) -> float:
    """
    Compute the IAT D-score using the D4 algorithm (Greenwald et al., 2003).

    Steps:
        1. Exclude trials with RT > rt_max or RT <= 0.
        2. For error trials, replace RT with mean correct RT of that block + error_penalty_ms.
        3. D = (mean_incompatible_RT - mean_compatible_RT) / SD_all_RT (pooled).

    A positive D-score indicates slower responses on incompatible trials,
    reflecting a stronger implicit association.

    Args:
        df (pd.DataFrame): Trial-level data with `metric_accuracy`, `metric_block_type`,
            and the RT column already scored.
        rt_col (str): Column to use for RT. Defaults to "metric_initial_rt".
        rt_max (float): Upper RT cutoff in ms. Trials above this are excluded.
        error_penalty_ms (float): Penalty added to block mean RT for error trials.

    Returns:
        (float): The D-score, or np.nan if computation is not possible.
    """
    df = df.copy()

    # Step 1: exclude extreme/invalid RTs
    valid_mask = df[rt_col].notna() & (df[rt_col] > 0) & (df[rt_col] <= rt_max)
    df = df[valid_mask]

    if df.empty:
        return np.nan

    compatible_mask = df["metric_block_type"] == "COMPATIBLE"
    incompatible_mask = df["metric_block_type"] == "INCOMPATIBLE"
    correct_mask = df["metric_accuracy"] == 1

    if compatible_mask.sum() == 0 or incompatible_mask.sum() == 0:
        return np.nan

    # Step 2: compute mean correct RT per block for error penalty
    mean_rt_compatible_correct = df.loc[compatible_mask & correct_mask, rt_col].mean()
    mean_rt_incompatible_correct = df.loc[
        incompatible_mask & correct_mask, rt_col
    ].mean()

    if pd.isna(mean_rt_compatible_correct) or pd.isna(mean_rt_incompatible_correct):
        return np.nan

    # Apply error penalty
    df["rt_adjusted"] = df[rt_col]
    error_mask = df["metric_accuracy"] == 0

    df.loc[compatible_mask & error_mask, "rt_adjusted"] = (
        mean_rt_compatible_correct + error_penalty_ms
    )
    df.loc[incompatible_mask & error_mask, "rt_adjusted"] = (
        mean_rt_incompatible_correct + error_penalty_ms
    )

    # Step 3: compute D-score
    rt_compatible = df.loc[compatible_mask, "rt_adjusted"]
    rt_incompatible = df.loc[incompatible_mask, "rt_adjusted"]

    mean_compatible = rt_compatible.mean()
    mean_incompatible = rt_incompatible.mean()
    # ddof=1 (sample SD) matches the dominant R-based IAT implementations (e.g., R 'IAT' package)
    sd_all = pd.concat([rt_compatible, rt_incompatible]).std()

    if pd.isna(sd_all) or sd_all == 0:
        return np.nan

    return (mean_incompatible - mean_compatible) / sd_all


def summarize(
    x: pd.DataFrame,
    trials_expected: int = 24,
    rt_outlier_low: float = 100,
    rt_outlier_high: float = 10000,
) -> pd.Series:
    """
    Summarize IAT trial-level data for a single participant/session.

    Computes the D-score (primary metric), accuracy by block type, and response
    time statistics for the m2c2kit API data format.

    Block type is derived from response_label_text at the session level
    (handles counterbalancing). If number_of_trials is present, it overrides
    the trials_expected parameter.

    Args:
        x (pd.DataFrame): Trial-level scored DataFrame.
        trials_expected (int): Expected number of trials. Defaults to 24.
        rt_outlier_low (float): Lower RT bound (ms) for outlier filtering. Defaults to 100.
        rt_outlier_high (float): Upper RT bound (ms) for outlier filtering. Defaults to 10000.

    Returns:
        (pd.Series): Summary statistics for the IAT session.
    """

    d = helpers.summarize_common_metadata(x, trials_expected)

    # Derive block types from response labels (handles counterbalancing)
    derived = _derive_block_types_from_labels(x)
    if not derived.isna().all():
        x = x.copy()
        x["metric_block_type"] = derived

    # Which IAT variant (short_code) is this? ("affective" or "identity")
    if "short_code" in x.columns:
        d["short_code"] = (
            x["short_code"].dropna().iloc[0] if x["short_code"].notna().any() else None
        )

    # D4 uses initial response time (metric_initial_rt scored by score_initial_rt)
    if "metric_initial_rt" in x.columns:
        d["d_score"] = _compute_d_score(x, rt_col="metric_initial_rt")
    else:
        d["d_score"] = np.nan

    # --- Accuracy counts and rate ---
    n_correct = (x["metric_accuracy"] == 1).sum()
    n_incorrect = (x["metric_accuracy"] == 0).sum()
    n_accuracy_missing = x["metric_accuracy"].isna().sum()
    d["n_trials_correct"] = n_correct
    d["n_trials_incorrect"] = n_incorrect
    d["n_trials_accuracy_missing"] = n_accuracy_missing
    d["accuracy_rate"] = (
        n_correct / (n_correct + n_incorrect)
        if (n_correct + n_incorrect) > 0
        else np.nan
    )

    # --- Block type counts ---
    d["n_trials_compatible"] = (x["metric_block_type"] == "COMPATIBLE").sum()
    d["n_trials_incompatible"] = (x["metric_block_type"] == "INCOMPATIBLE").sum()

    # --- Accuracy by block type ---
    for block in ["COMPATIBLE", "INCOMPATIBLE"]:
        bk = block.lower()
        block_mask = x["metric_block_type"] == block
        n_blk_correct = (block_mask & (x["metric_accuracy"] == 1)).sum()
        n_blk_incorrect = (block_mask & (x["metric_accuracy"] == 0)).sum()
        n_blk_total = n_blk_correct + n_blk_incorrect
        d[f"n_trials_{bk}_correct"] = n_blk_correct
        d[f"n_trials_{bk}_incorrect"] = n_blk_incorrect
        d[f"accuracy_rate_{bk}"] = (
            n_blk_correct / n_blk_total if n_blk_total > 0 else np.nan
        )

    # --- RT statistics ---
    rt_columns = {}
    if "metric_initial_rt" in x.columns:
        rt_columns["initial_rt"] = "metric_initial_rt"
    if "metric_correct_rt" in x.columns:
        rt_columns["correct_rt"] = "metric_correct_rt"
    elif "response_time_ms" in x.columns:
        rt_columns["correct_rt"] = "response_time_ms"

    for rt_key, rt_col in rt_columns.items():
        valid_rt_mask = pd.notna(x[rt_col]) & (x[rt_col] > 0)
        valid_rt = x.loc[valid_rt_mask, rt_col]

        d[f"n_trials_{rt_key}_invalid"] = x[rt_col].shape[0] - valid_rt.shape[0]
        d[f"median_{rt_key}_overall"] = valid_rt.median()
        d[f"sd_{rt_key}_overall"] = valid_rt.std()

        # By block type (no outlier filter)
        for block in ["COMPATIBLE", "INCOMPATIBLE"]:
            bk = block.lower()
            block_rt_mask = (x["metric_block_type"] == block) & valid_rt_mask
            block_rt = x.loc[block_rt_mask, rt_col]
            d[f"median_{rt_key}_{bk}"] = block_rt.median()
            d[f"sd_{rt_key}_{bk}"] = block_rt.std()

        # Filtered overall (outliers removed)
        filtered_mask = (
            valid_rt_mask
            & (x[rt_col] >= rt_outlier_low)
            & (x[rt_col] <= rt_outlier_high)
        )
        filtered_rt = x.loc[filtered_mask, rt_col]
        d[f"n_outliers_{rt_key}"] = valid_rt.shape[0] - filtered_rt.shape[0]
        d[f"median_{rt_key}_filtered"] = filtered_rt.median()
        d[f"sd_{rt_key}_filtered"] = filtered_rt.std()

        # Filtered by block type
        for block in ["COMPATIBLE", "INCOMPATIBLE"]:
            bk = block.lower()
            block_filtered = x.loc[
                filtered_mask & (x["metric_block_type"] == block), rt_col
            ]
            d[f"median_{rt_key}_{bk}_filtered"] = block_filtered.median()
            d[f"sd_{rt_key}_{bk}_filtered"] = block_filtered.std()

    return pd.Series(d)
