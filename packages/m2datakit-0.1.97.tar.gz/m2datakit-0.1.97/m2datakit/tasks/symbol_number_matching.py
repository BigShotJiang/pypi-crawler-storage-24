import pandas as pd



def score_matching(row, legacy=False):
    """
    There isn't currently anything baked into the assessment code, to infer whether or not the drawing is accurate.
    """
    return None
        

def summarize(x, rt_outlier_low=100, rt_outlier_high=10000):
    d = {}

    # total trials
    d["n_trials"] = x["trial_index"].nunique()

    # filter outliers on full rows
    rt_filtered = x.loc[
        (x["response_time_ms"] >= rt_outlier_low) &
        (x["response_time_ms"] <= rt_outlier_high)
    ]

    # number of trials after filtering
    d["n_trials_filtered"] = rt_filtered["trial_index"].nunique()

    # number of outliers removed
    d["n_outliers"] = d["n_trials"] - d["n_trials_filtered"]

    # RT summary statistics after filtering
    d["median_response_time_filtered"] = rt_filtered["response_time_ms"].median()
    d["mean_response_time_filtered"] = rt_filtered["response_time_ms"].mean()
    d["sd_response_time_filtered"] = rt_filtered["response_time_ms"].std()

    d["symbols_ordered"] = rt_filtered["symbols_ordered"]
    d["digits_ordered"] = rt_filtered["digits_ordered"]
    
    return pd.Series(d)
