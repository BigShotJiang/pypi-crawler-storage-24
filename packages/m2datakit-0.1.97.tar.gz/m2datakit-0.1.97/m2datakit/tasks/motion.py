import numpy as np
import pandas as pd

from ..core import helpers


def score_motion(row, legacy=False):
    """
    Trial-level scoring for a single motion trial.
    Simply calls summarize on the row. 
    
    -- sensor availability? 
    """
    return None

def vector_magnitude(df, keys):
    """
    Compute the vector magnitude of columns in df specified by keys.
    Useful for calculating combined acceleration or rotation magnitude.
    
    Formula:
    magnitude = sqrt(x^2 + y^2 + z^2)
    """
    return np.sqrt(np.sum([df[k]**2 for k in keys], axis=0))

def sway_path(angles):
    """
    Compute the total 'sway path' for a series of angles.
    Sway path is the sum of absolute differences between consecutive values.
    
    Formula:
    sway_path = sum(|angle[i+1] - angle[i]|)
    """
    angles = np.array(angles)
    return np.sum(np.abs(np.diff(angles)))

    
def summarize(x, trials_expected=0):
    # Start with common metadata
    d = helpers.summarize_common_metadata(x, trials_expected)
    
    
    # ----------------------
    # DEVICEMOTION FEATURES
    # ----------------------
    
    # Get devicemotion events, ensure it's a list
    dm = x.get('devicemotion_events', [])
    if isinstance(dm, pd.Series):
        dm = dm.dropna().tolist()

    # Flatten all batches
    all_dm_events = [event for batch in dm for event in (batch or []) if isinstance(event, dict)]
    total_dm_events = len(all_dm_events)

    # Extract acceleration values
    acc_x, acc_y, acc_z = [], [], []
    for event in all_dm_events:
        acc = event.get('acceleration', {})
        if acc:
            acc_x.append(acc.get('x'))
            acc_y.append(acc.get('y'))
            acc_z.append(acc.get('z'))

    total_accel_events = len(acc_x)

    # Initialize stats as NA
    accel_mag_mean = accel_mag_std = accel_mag_rms = accel_mag_peak = np.nan

    # Compute statistics only if there is valid acceleration data
    if total_accel_events > 0:
        accel_mag = np.sqrt(np.array(acc_x)**2 + np.array(acc_y)**2 + np.array(acc_z)**2)
        accel_mag_mean = np.mean(accel_mag)
        accel_mag_std = np.std(accel_mag)
        accel_mag_rms = np.sqrt(np.mean(accel_mag**2))
        accel_mag_peak = np.max(accel_mag)

    # Update summary dictionary
    d.update({
        'total_dm_events': total_dm_events,
        'total_accel_events': total_accel_events,
        'accel_mag_mean': accel_mag_mean,
        'accel_mag_std': accel_mag_std,
        'accel_mag_rms': accel_mag_rms,
        'accel_mag_peak': accel_mag_peak
    })
    
    
    # Extract rotation rates
    rot_alpha, rot_beta, rot_gamma = [], [], []
    for event in all_dm_events:
        rot = event.get('rotation_rate', {})
        if rot:
            rot_alpha.append(rot.get('alpha'))
            rot_beta.append(rot.get('beta'))
            rot_gamma.append(rot.get('gamma'))

    total_rot_events = len(rot_alpha)

    # Initialize stats as NaN
    rot_mag_mean = rot_mag_std = rot_mag_peak = np.nan

    # Compute statistics only if there is valid rotation data
    if total_rot_events > 0:
        rot_mag = np.sqrt(np.array(rot_alpha)**2 + np.array(rot_beta)**2 + np.array(rot_gamma)**2)
        rot_mag_mean = np.nanmean(rot_mag)
        rot_mag_std = np.nanstd(rot_mag)
        rot_mag_peak = np.nanmax(rot_mag)

    # Update summary dictionary
    d.update({
        'total_dm_events': total_dm_events,
        'total_rot_events': total_rot_events,
        'rot_mean': rot_mag_mean,
        'rot_std': rot_mag_std,
        'rot_peak': rot_mag_peak
    })


    # ----------------------
    # DEVICEORIENTATION FEATURES
    # ----------------------

    do = x.get('deviceorientation_events', [])
    if isinstance(do, pd.Series):
        do = do.dropna().tolist()

    # Flatten all batches
    all_do_events = [event for batch in do for event in (batch or []) if isinstance(event, dict)]
    total_do_events = len(all_do_events)

    # Extract beta and gamma
    beta, gamma = [], []
    for event in all_do_events:
        beta.append(event.get('beta'))
        gamma.append(event.get('gamma'))

    # Initialize as NaN
    beta_std = gamma_std = beta_range = gamma_range = sway_beta = sway_gamma = np.nan

    # Compute stats if we have valid events
    if total_do_events > 0:
        beta_arr = np.array(beta, dtype=float)
        gamma_arr = np.array(gamma, dtype=float)
        
        beta_std = np.nanstd(beta_arr)
        gamma_std = np.nanstd(gamma_arr)
        
        beta_range = np.nanmax(beta_arr) - np.nanmin(beta_arr)
        gamma_range = np.nanmax(gamma_arr) - np.nanmin(gamma_arr)
        
        # sway = sum of absolute differences between consecutive samples
        sway_beta = np.nansum(np.abs(np.diff(beta_arr)))
        sway_gamma = np.nansum(np.abs(np.diff(gamma_arr)))

    # Update summary dictionary
    d.update({
        'total_do_events': total_do_events,
        'beta_std': beta_std,
        'gamma_std': gamma_std,
        'beta_range': beta_range,
        'gamma_range': gamma_range,
        'sway_beta': sway_beta,
        'sway_gamma': sway_gamma
    })
    
    
    # ----------------------
    # COMPOSITE SCORES
    # ----------------------
    
    # rot_std from devicemotion rotation magnitude
    rot_std = 0 if pd.isna(d.get('rot_std', np.nan)) else d.get('rot_std', 0)

    # beta and gamma std from deviceorientation
    beta_std = 0 if pd.isna(d.get('beta_std', np.nan)) else d.get('beta_std', 0)
    gamma_std = 0 if pd.isna(d.get('gamma_std', np.nan)) else d.get('gamma_std', 0)

    # balance score: lower std → higher score
    d['balance_score'] = 1 / (1 + beta_std + gamma_std + rot_std)

    # motion intensity: just the accel RMS
    accel_rms = 0 if pd.isna(d.get('accel_mag_rms', np.nan)) else d.get('accel_mag_rms', 0)
    d['motion_intensity'] = accel_rms

    # mobility score: average of motion intensity and balance
    d['mobility_score'] = 0.5 * d['motion_intensity'] + 0.5 * d['balance_score']

    
    return pd.Series(d)





