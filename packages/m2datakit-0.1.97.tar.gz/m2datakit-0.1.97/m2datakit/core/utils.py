import datetime
import hashlib
import uuid


def get_package_version():
    """Return the installed package version string."""
    from importlib.metadata import version
    return version("m2datakit")


def get_sys_stats() -> dict:
    """Retrieve system statistics for the current process.

    Returns:
        dict: Memory usage (MB) and CPU percentage.
    """
    import psutil
    process = psutil.Process()
    memory = process.memory_info().rss / (1024**2)  # Memory usage in MB
    cpu = process.cpu_percent(interval=0.1)  # CPU usage percentage
    return {"memory_mb": memory, "cpu_percent": cpu}


def get_timestamp() -> datetime.datetime:
    """Return the current timestamp.

    Returns:
        datetime.datetime: Current timestamp.
    """
    return datetime.datetime.now()


def get_filename_timestamp() -> str:
    """Return a timestamp formatted for filenames.

    Returns:
        str: Timestamp in "YYYYMMDD_HHMMSS" format.
    """
    return get_timestamp().strftime("%Y%m%d_%H%M%S")


def get_uuid(version: int = 4) -> str:
    """Generate a UUID.

    Args:
        version: UUID version (1 or 4).

    Returns:
        str: UUID string.
    """
    if version == 1:
        return str(uuid.uuid1())
    return str(uuid.uuid4())


def compute_md5_hash(df) -> str:
    """Compute an MD5 hash of a pandas DataFrame.

    Args:
        df: DataFrame to hash.

    Returns:
        str: MD5 hash as a hexadecimal string.
    """
    import pandas as pd
    if not isinstance(df, pd.DataFrame):
        raise TypeError("Input must be a pandas DataFrame.")

    df_string = df.to_json()
    return hashlib.md5(df_string.encode()).hexdigest()
