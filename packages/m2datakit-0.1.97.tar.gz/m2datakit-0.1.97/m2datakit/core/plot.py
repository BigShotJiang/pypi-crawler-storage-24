import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

from .config import settings


def _apply_plot_style():
    """Apply accessible plotting defaults (color-blind safe, larger fonts)."""
    sns.set_theme(style="whitegrid")
    mpl.rcParams.update(
        {
            "font.size": 12,
            "axes.titlesize": 16,
            "axes.labelsize": 13,
            "xtick.labelsize": 11,
            "ytick.labelsize": 11,
            "legend.fontsize": 11,
            "figure.dpi": settings.DEFAULT_DPI,
            "axes.facecolor": "#F9F9F9",
        }
    )


def plot_pairplot(df: pd.DataFrame):
    """Plot a pairplot for all numeric variables in the DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to plot.
    """
    _apply_plot_style()

    # Use a color-blind safe palette for scatter points
    palette = sns.color_palette("colorblind")

    pairplot = sns.pairplot(
        df.select_dtypes(include=["number"]),
        diag_kind="kde",
        plot_kws={"alpha": 0.7, "color": palette[0]},
        diag_kws={"color": palette[0]},
    )
    pairplot.fig.suptitle(
        "Pairplot of Variables", fontsize=16, fontweight="bold", y=1.02
    )
    plt.show()


def plot_distribution(df: pd.DataFrame):
    """Plot the distribution of each numeric variable in the DataFrame.

    Parameters
    ----------
    df : pd.DataFrame
        The DataFrame to plot.
    """
    _apply_plot_style()

    numeric_cols = df.select_dtypes(include=["number"]).columns
    if len(numeric_cols) == 0:
        return

    palette = sns.color_palette("colorblind", len(numeric_cols))

    for i, column in enumerate(numeric_cols):
        fig, ax = plt.subplots(figsize=(8, 4))
        sns.histplot(
            df[column],
            kde=True,
            label=column,
            alpha=0.85,
            color=palette[i % len(palette)],
            edgecolor="black",
            ax=ax,
        )

        ax.set_title(f"Distribution of {column}", fontweight="bold", pad=12)
        ax.set_xlabel("Value")
        ax.set_ylabel("Frequency")
        ax.legend(loc="best", frameon=False)

        sns.despine(ax=ax)
        plt.tight_layout()
        plt.show()
