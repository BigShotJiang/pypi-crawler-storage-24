# Mobile Monitoring of Cognitive Change (M2C2) Platform

## 📘 M2C2 DataKit (m2datakit): Universal Loading, Assurance, and Scoring

This is the documentation for the **M2C2 DataKit** Python package 🐍, which is part of the M2C2 Platform. The M2C2 Platform is a comprehensive system designed to facilitate the collection, processing, and analysis of mobile cognitive data (aka, ambulatory cognitive assessments, cognitive activities, and brain games). 

🚀 **A set of R, Python, and NPM packages for scoring M2C2kit Data!** 🚀

[![PyPI version](https://img.shields.io/pypi/v/m2datakit.svg)](https://pypi.org/project/m2datakit/)

## Documentation

See [here for documentation](https://m2c2-project.github.io/datakit/site/index.html)

### Notebooks

Notebooks are included in the **source distribution** (sdist). To access them:

```bash
pip download --no-binary :all: m2datakit
# unpack the .tar.gz, then open notebooks/
```

## 🔧 Installation

```bash
pip install m2datakit
```

### Optional: Jupyter kernel (if using notebooks)
```bash
python -m ipykernel install --user --name="m2datakit" --display-name "Python (m2datakit)"
```

---

### 🛠️ Setup for Developers of this Package
```bash
# Create a local venv (uv) and install the package in editable mode
uv venv
uv pip install -e .

# (optional) install dev tools you use (isort/ruff/flake8, etc.)
```
---

**Developers**

- [Dr. Nelson Roque](https://www.linkedin.com/in/nelsonroque/)
  - ORCID: https://orcid.org/0000-0003-1184-202X

- [Dr. Scott Yabiku](https://www.linkedin.com/in/scottyabiku)
  - ORCID: Coming soon

---

## Changelog

[Source: https://github.com/m2c2-project/datakit](https://github.com/m2c2-project/datakit)

See [CHANGELOG.md](CHANGELOG.md)

---

## 🗺️ Roadmap

- Clear API docs (MkDocs + mkdocstrings)
- Reliable error handling (no silent exceptions, explicit strict/lenient modes)
- Robust logging policy (opt-in, no import-time side effects)
- Typed source configs + schema validation
- CI + golden-data tests per task
- Performance optimization (vectorization / fewer copies)

---

## 🎯 Purpose

Enable researchers to plug in data from varied sources (e.g., MongoDB, UAS, MetricWire, CSV bundles) and apply a consistent pipeline for:

- Input validation
- Scoring via predefined rules
- Inspection and summarization
- Tidy export and codebook generation

---

## 🧠 L.A.S.S.I.E. Pipeline Summary

| Step | Method           | Purpose                                                                 |
|------|------------------|-------------------------------------------------------------------------|
| L    | `LASSIE.load()`         | Load raw data from a supported source (e.g., MongoDB, UAS, MetricWire). |
| A    | `LASSIE.assure()`       | Validate that required columns exist before processing.                 |
| S    | `LASSIE.score()`        | Apply scoring logic based on predefined or custom rules.                |
| S    | `LASSIE.summarize()`    | Aggregate scored data by participant, session, or custom groups.        |
| I    | `LASSIE.inspect()`      | Visualize distributions or pairwise plots for quality checks.           |
| E    | `LASSIE.export()`       | Save scored and summarized data to tidy files and optionally metadata.  |

---

## 🔌 Supported Sources

You may have used M2C2kit tasks via our various integrations, including the ones listed below. Each integration has its own loader class, which is responsible for reading the data and converting it into a format that can be processed by the `m2datakit` package. Keep in mind that you are responsible for ensuring that the data is in the correct format for each loader class.

In the future we anticipate creating loaders for downloading data via API.

| Source Type   | Loader Class          | Key Arguments                            | Notes                                 |
|---------------|------------------------|-------------------------------------------|----------------------------------------|
| `mongodb`     | `MongoDBImporter`      | `source_path` (URL, to JSON)                      | Expects flat or nested JSON documents. |
| `multicsv`    | `MultiCSVImporter`     | `source_map` (dict of CSV paths)          | Each activity type is its own file.    |
| `metricwire`  | `MetricWireImporter`   | `source_path` (glob pattern or default)   | Processes JSON files from unzipped export. |
| `qualtrics`   | `QualtricsImporter`     | `source_path` (URL to CSV)          | Each activity's trial saves data to a new column.    |

---

## 🧪 Example: Full Pipeline

For a full pipeline, [go to our `datakit-notebooks` repo](https://github.com/m2c2-project/datakit-notebooks)

---

## **💡 Contributions Welcome!**

📌 Have ideas? Found a bug? Want to improve the package?  [Open an issue!](https://github.com/m2c2-project/datakit).

📜 **[Code of Conduct](https://docs.github.com/en/site-policy/github-terms/github-community-code-of-conduct) - Please be respectful and follow community guidelines.**

---

## Acknowledgements
The development of `m2datakit` was made possible with support from NIA (1U2CAG060408-01).

---

## 🌎 **More Resources:**  

📌 [M2C2 Official Website](https://m2c2.io)

📌 [M2C2kit Official Documentation Website](https://m2c2-project.github.io/m2c2kit-docs/)

📌 [Pushing to PyPI](https://docs.astral.sh/uv/guides/publish/#publishing-your-package)

  - https://docs.astral.sh/uv/guides/integration/github/#setting-up-python

📌 [What is JSON?](https://www.w3schools.com/whatis/whatis_json.asp)

---

## What is What? 🧠 Summary

| Thing                         | Type            | Description                       |
| -------------------------------| -----------------| -----------------------------------|
| `m2datakit`                   | Library/Package | Top-level Python package          |
| `core/`, `loaders/`, `tasks/` | Subpackages     | Contain logically grouped modules |
| `log.py`, `export.py`, etc.   | Modules         | Individual Python files           |
| `__init__.py`                 | Special Module  | Marks the directory as a package  |

---

## 🎬 Inspired by:
<img src="https://m.media-amazon.com/images/M/MV5BNDNkZDk0ODktYjc0My00MzY4LWE3NzgtNjU5NmMzZDA3YTA1XkEyXkFqcGc@._V1_FMjpg_UX1000_.jpg" alt="Inspiration for Package, Lassie Movie" width="250"/>

---

🚀 Let's go study some brains!