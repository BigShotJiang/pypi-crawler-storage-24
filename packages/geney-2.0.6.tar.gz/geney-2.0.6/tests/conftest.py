# tests/conftest.py — Shared fixtures and environment setup for test suite.
"""
Stubs external dependencies (seqmat, ViennaRNA, borzoi_pytorch) so that
pure-Python tests can run without the full genomics environment installed.

Tests requiring the real seqmat/ViennaRNA/Borzoi should use markers:
    @pytest.mark.requires_seqmat
    @pytest.mark.requires_vienna
    @pytest.mark.requires_borzoi
"""
import sys
import types

# Stub external genomics dependencies if not installed
_STUBS = {
    "seqmat": {
        "Gene": type("Gene", (), {"from_file": staticmethod(lambda *a, **k: None)}),
        "SeqMat": type("SeqMat", (), {}),
    },
    "borzoi_pytorch": {
        "Borzoi": type("Borzoi", (), {}),
    },
}

for mod_name, attrs in _STUBS.items():
    if mod_name not in sys.modules:
        mod = types.ModuleType(mod_name)
        for attr_name, attr_val in attrs.items():
            setattr(mod, attr_name, attr_val)
        sys.modules[mod_name] = mod
