# geney/__init__.py
__version__ = "2.0.3"

from .variants import Mutation, MutationalEvent, MutationLibrary

from .oncosplice import Oncosplice

from .results import (
    SplicingResult,
    ProteinResult,
    TISSite,
    TISResult,
    FoldingWindow,
    FoldingResult,
    TranscriptionResult,
    MiRNAResult,
    MechanismScore,
    MutationResult,
)

from .pipelines import (
    mutation_pipeline,
    mutation_pipeline_batch,
    oncosplice_pipeline,
    oncosplice_top_isoform,
    max_splicing_delta,
    tis_pipeline,
    tis_quick_check,
    folding_pipeline,
)

from .api import serialize_mutation
from .engine import Geney
from .concurrent import analyze_concurrent

from .screen import (
    ScreenResult,
    screen_mutation,
    screen_mutations,
    screen_and_select,
)

from .screen_alphagenome import (
    AlphaGenomeScreenResult,
    screen_mutation_alphagenome,
    screen_mutations_alphagenome,
    screen_and_select_alphagenome,
    set_alphagenome_model,
)

# -- Configuration setters --
from .splicing import (
    set_openspliceai_model_dir,
    get_openspliceai_model_dir,
    set_splicing_device,
    get_splicing_device,
)

from .tis import (
    set_titer_model_dir,
    get_titer_model_dir,
    set_titer_device,
    get_titer_device,
)

from .transcription import (
    set_borzoi_model,
    get_borzoi_model_name,
    set_borzoi_device,
    get_borzoi_device,
)

from .folding import (
    set_folding_data_dir,
    get_folding_data_dir,
)

__all__ = [
    # Core types
    "Mutation",
    "MutationalEvent",
    "MutationLibrary",
    "Oncosplice",
    "MutationResult",
    # Result types
    "SplicingResult",
    "TISSite",
    "TISResult",
    "FoldingWindow",
    "FoldingResult",
    "TranscriptionResult",
    "MechanismScore",
    # Engine
    "Geney",
    "analyze_concurrent",
    # Pipelines
    "mutation_pipeline",
    "mutation_pipeline_batch",
    "oncosplice_pipeline",
    "oncosplice_top_isoform",
    "max_splicing_delta",
    "tis_pipeline",
    "tis_quick_check",
    "folding_pipeline",
    # Screening
    "ScreenResult",
    "screen_mutation",
    "screen_mutations",
    "screen_and_select",
    # AlphaGenome screening
    "AlphaGenomeScreenResult",
    "screen_mutation_alphagenome",
    "screen_mutations_alphagenome",
    "screen_and_select_alphagenome",
    "set_alphagenome_model",
    # Configuration
    "set_openspliceai_model_dir",
    "get_openspliceai_model_dir",
    "set_splicing_device",
    "get_splicing_device",
    "set_titer_model_dir",
    "get_titer_model_dir",
    "set_titer_device",
    "get_titer_device",
    "set_borzoi_model",
    "get_borzoi_model_name",
    "set_borzoi_device",
    "get_borzoi_device",
    "set_folding_data_dir",
    "get_folding_data_dir",
]
