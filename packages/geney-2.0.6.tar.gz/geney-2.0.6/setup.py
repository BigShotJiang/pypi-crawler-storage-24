import setuptools

with open('requirements.txt') as f:
    requirements = [
        line.split('#')[0].strip()
        for line in f
        if line.split('#')[0].strip()
    ]

setuptools.setup(
    name='geney',
    version='2.0.6',
    python_requires='>=3.10',
    description='Computational genomics pipeline for predicting functional impacts of mutations on gene expression.',
    url='https://github.com/nicolaslynn/geney',
    author='Nicolas Lynn',
    author_email='nicolasalynn@gmail.com',
    license='Free for non-commercial use',
    packages=setuptools.find_packages(exclude=['geney.models', 'geney.models.*']),
    install_requires=requirements,
    include_package_data=False,
    package_data={
        'geney': [
            'transcription/targets_human.txt',
            'mirna/*.json',
            'mirna/data/*.json',
            'mirna/data/*.fa',
        ],
    },
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Science/Research',
        'License :: Free for non-commercial use',
        'Operating System :: POSIX :: Linux',
        'Operating System :: MacOS',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
    ],
)



