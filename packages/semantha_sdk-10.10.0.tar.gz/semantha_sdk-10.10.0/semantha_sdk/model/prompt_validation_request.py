from dataclasses import dataclass

from marshmallow_dataclass import class_schema

from semantha_sdk.rest.rest_client import RestSchema

from semantha_sdk.model.prompt_validation_template import PromptValidationTemplate
from typing import List

@dataclass
class PromptValidationRequest:
    """ author semantha, this is a generated class do not change manually! """
    prompt_template: PromptValidationTemplate
    # Ordered arguments mapped by placeholder position.
    arguments: List[str]

PromptValidationRequestSchema = class_schema(PromptValidationRequest, base_schema=RestSchema)
