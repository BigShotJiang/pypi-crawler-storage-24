from semantha_sdk.model.prompt_validation_request import PromptValidationRequest
from semantha_sdk.model.prompt_validation_request import PromptValidationRequestSchema
from semantha_sdk.model.prompt_validation_response import PromptValidationResponse
from semantha_sdk.model.prompt_validation_response import PromptValidationResponseSchema
from semantha_sdk.rest.rest_client import MediaType
from semantha_sdk.rest.rest_client import RestClient, RestEndpoint

class PromptValidationEndpoint(RestEndpoint):
    """
    Class to access resource: "/api/domains/{domainname}/prompts/validation"
    author semantha, this is a generated class do not change manually! 
    
    """

    @property
    def _endpoint(self) -> str:
        return self._parent_endpoint + "/validation"

    def __init__(
        self,
        session: RestClient,
        parent_endpoint: str,
    ) -> None:
        super().__init__(session, parent_endpoint)

    
    def post(
        self,
        body: PromptValidationRequest = None,
    ) -> PromptValidationResponse:
        """
        Validates prompt templating and executes role against the configured model. Requires domain admin role.
        Args:
        body (PromptValidationRequest): 
        """
        q_params = {}
        response = self._session.post(
            url=self._endpoint,
            json=PromptValidationRequestSchema().dump(body),
            headers=RestClient.to_header(MediaType.JSON),
            q_params=q_params
        ).execute()
        return response.to(PromptValidationResponseSchema)

    
    
    