from semantha_sdk.model.document_information import DocumentInformation
from semantha_sdk.model.document_information import DocumentInformationSchema
from semantha_sdk.rest.rest_client import MediaType
from semantha_sdk.rest.rest_client import RestClient, RestEndpoint
from typing import List

class ReferencedocumentsStreamEndpoint(RestEndpoint):
    """
    Class to access resource: "/api/domains/{domainname}/referencedocuments/stream"
    author semantha, this is a generated class do not change manually! 
    
    """

    @property
    def _endpoint(self) -> str:
        return self._parent_endpoint + "/stream"

    def __init__(
        self,
        session: RestClient,
        parent_endpoint: str,
    ) -> None:
        super().__init__(session, parent_endpoint)

    def get(
        self,
        fields: str = None,
    ) -> List[DocumentInformation]:
        """
        Get all reference document information as a streamed JSON array.
            Returns only document metadata (e.g. id, name, tags, document class) without document content such as pages, paragraphs or sentences. Ignored documents are excluded. Results are sorted by creation date descending.
        Args:
        fields str: Define which fields should be returned. The following values can be sent as a comma-separated list: 'id', 'name', 'tags', 'derivedtags', 'documentclass'. If empty or null all fields will be returned.
        """
        q_params = {}
        if fields is not None:
            q_params["fields"] = fields
    
        return self._session.get(self._endpoint, q_params=q_params, headers=RestClient.to_header(MediaType.JSON)).execute().to(DocumentInformationSchema)

    
    
    
    