# Docker 测试环境需求规格 (PM-Agent参考)

**版本**: v1.1  
**创建日期**: 2026-02-21  
**来源**: HQ docs/05-process/PROCESS_docker_test_environment_requirements.md

---

## 重大更新 (v1.1)

> **事故教训**: Docker 构建失败导致测试在生产库运行，数据被清空

> 新增强制防护措施，确保测试只在 Docker 内运行

---

## 一、背景

所有系统（包括 pm-agent）必须使用 Docker 测试环境来：
1. 在隔离环境中运行测试
2. 确保测试可重复执行
3. **防止测试在生产环境运行** ⭐

---

## 二、强制防护措施

### 2.1 强制 Docker 运行

| # | 防护措施 | 说明 |
|---|----------|------|
| 1 | **强制测试在 Docker 内运行** | 不允许直接运行 pytest |
| 2 | **Docker 构建失败禁止测试** | 构建失败时终止测试 |
| 3 | **环境检查** | 启动前检查 TEST_MODE=true |
| 4 | **生产数据库只读** | 生产数据只读，禁止写入 |

---

## 三、pm-agent 测试要求

### 3.1 当前状态

pm-agent 尚未使用 Docker 测试。需要评估是否需要建立 Docker 测试环境。

### 3.2 未来要求

当 pm-agent 需要进行测试时，必须：

1. **使用 Docker**: 所有测试必须在 Docker 内运行
2. **环境检查**: 确保 TEST_MODE=true
3. **构建验证**: Docker 构建成功后再执行测试

---

## 四、关联文档

| 文档 | 说明 |
|------|------|
| `HQ/docs/07-reports/BUG_docker_production_data_incident.md` | Docker 生产数据事故报告 |
| `dual-agent-collaboration-system/docs/04-deployment/REQUIREMENT_docker_test_environment_v1.1.md` | oc-collab Docker 测试需求 |
| `conf-man/docs/04-deployment/REQUIREMENT_docker_test_environment_v1.1.md` | conf-man Docker 测试需求 |
| `test-agent/docs/04-proposals/PROPOSAL_docker_test_environment_v1.1.md` | test-agent Docker 测试需求 |

---

*来源: HQ/docs/05-process/PROCESS_docker_test_environment_requirements.md*  
*编写人: agent5 (顾问)*  
*日期: 2026-02-21*
