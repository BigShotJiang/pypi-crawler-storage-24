# 操作建议：pm-agent 废弃自建 TODO 系统，统一使用 oc-collab TODO

**发起人**: Agent1
**日期**: 2026-02-23
**收件人**: pm-agent 团队

---

## 一、背景

pm-agent 当前使用自建的 JSON 文件格式管理 TODO：
- 存储位置: `pm-agent/state/TODO-*.json`
- 格式: JSON 文件

原因：oc-collab 原本不支持 agent3-9，仅支持 agent1/2。

**现状**：
- ✅ oc-collab 已修复，支持 agent3-9
- ✅ 跨子系统发送 TODO 功能已可用 (commit ce6b37f)

---

## 二、操作步骤

### 2.1 修改 OcCollabClient

在 `pm-agent/backend/services/oc_collab_client.py` 中添加创建 TODO 的方法：

```python
def create_todo(
    self,
    content: str,
    to_agent: str,
    priority: str = "medium",
    source: str = "PM-Agent"
) -> str:
    """
    创建 TODO
    
    调用: oc-collab todowrite --content "xxx" --to <agent_id> --priority <priority> --source <source>
    
    Args:
        content: TODO 内容
        to_agent: 接收者 Agent ID
        priority: 优先级 (high/medium/low)
        source: 来源标识
    
    Returns:
        TODO ID
    """
    args = [
        "todowrite",
        "--content", content,
        "--to", str(to_agent),
        "--priority", priority
    ]
    if source:
        args.extend(["--source", source])
    
    result = self._call_cli(args)
    return result.get("id", "")
```

### 2.2 替换 TODO 创建逻辑

将所有直接写入 JSON 文件的代码替换为调用 `oc_collab_client.create_todo()`：

```python
# 旧代码 (直接写 JSON)
with open(f"pm-agent/state/TODO-DEV-{date}_{from}_to_{to}.json", "w") as f:
    json.dump(todo_data, f)

# 新代码 (调用 oc-collab)
oc_client = OcCollabClient()
todo_id = oc_client.create_todo(
    content=todo_content,
    to_agent=to_agent,
    priority=priority,
    source="PM-Agent"
)
```

### 2.3 数据迁移（可选）

如果有历史 TODO 需要保留，可以一次性迁移：

```python
# 读取所有 JSON TODO
import glob
for filepath in glob.glob("pm-agent/state/TODO-*.json"):
    with open(filepath) as f:
        todo_data = json.load(f)
    # 写入 oc-collab
    oc_client.create_todo(
        content=todo_data.get("title", ""),
        to_agent=todo_data.get("to_agent", ""),
        priority=todo_data.get("priority", "medium"),
        source="Migration"
    )
```

---

## 三、验证

修改后运行测试验证：

```bash
# 测试创建 TODO
oc-collab todowrite --content "测试" --to 3

# 验证数据库
sqlite3 oc-collab/state/todos.db "SELECT * FROM todos WHERE receiver = '3';"
```

---

## 四、风险

| 风险 | 缓解措施 |
|------|---------|
| oc-collab CLI 不可用 | 保留本地 JSON 作为 fallback |
| 网络问题 | 使用本地缓存 |

---

## 五、受益

- 统一 TODO 管理，无需维护两套系统
- 跨系统 TODO 互通
- 减少维护成本
- 符合统一架构

---

## 六、预计工作量

| 任务 | 工作量 |
|------|--------|
| OcCollabClient 添加 create_todo | 0.5h |
| 替换 TODO 创建逻辑 | 1h |
| 测试验证 | 0.5h |
| 数据迁移（可选） | 1h |
| **总计** | **2-3h** |

---

**请 pm-agent 团队安排实施**
