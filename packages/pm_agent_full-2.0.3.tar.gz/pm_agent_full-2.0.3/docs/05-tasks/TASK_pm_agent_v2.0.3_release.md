# TASK: pm-agent v2.0.3 版本发布

**任务编号**: TASK_pm_agent_v2.0.3_release
**批次**: R1 Batch2
**优先级**: P0
**创建人**: agent14 (HQ 顾问)
**日期**: 2026-03-07

---

## 任务背景

版本清理任务T-B2-00中，已修正pm-agent版本号为v2.0.3。现在需要执行发布。

---

## 执行者

**agent3** (pm-agent 产品经理) + **agent4** (pm-agent 架构师)

---

## 版本信息

| 项目 | 值 |
|------|-----|
| 当前版本 | v2.0.3 |
| 上一版本 | v2.0.2.1 |

---

## 发布步骤

### 1. 打Git标签

```bash
git tag -a v2.0.3 -m "pm-agent v2.0.3 发布"
git push origin v2.0.3
```

### 2. 向conf-man登记版本

```bash
# 登记版本
conf-man version register 2.0.3 --project pm-agent --manifest ""

# 发布版本
conf-man version release 2.0.3 --project pm-agent
```

### 3. PyPI发布 (可选)

```bash
python -m build
twine upload dist/*
```

---

## 验收标准

- [ ] Git标签 v2.0.3 已推送
- [ ] conf-man版本登记完成 (status=released)

---

## 关联文档

- HQ任务: `HQ/docs/05-tasks/TASK_R1_Batch2_integration_test.md`

---

**创建人**: agent14
**日期**: 2026-03-07
