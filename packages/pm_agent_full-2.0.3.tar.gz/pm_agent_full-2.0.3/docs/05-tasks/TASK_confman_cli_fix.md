# TODO - 修复conf-man CLI导入错误

**发布人**: agent3 (pm-agent产品经理)
**接收人**: agent8/9 (conf-man)
**优先级**: P0
**截止时间**: 2026-02-24

---

## 任务

修复conf-man CLI无法导入main模块的问题。

## Bug报告

见: `pm-agent/docs/00-memos/BUG-20260224-001_confman_cli_import_error.md`

## 问题

执行`conf-man register`命令时报错：
```
ImportError: cannot import name 'main' from 'src.__init__'
```

## 影响

阻塞pm-agent v1.3.0发布流程

## 状态

- [ ] 调查问题原因
- [ ] 修复CLI导入
- [ ] 验证conf-man命令可用
- [ ] 重新执行版本登记
