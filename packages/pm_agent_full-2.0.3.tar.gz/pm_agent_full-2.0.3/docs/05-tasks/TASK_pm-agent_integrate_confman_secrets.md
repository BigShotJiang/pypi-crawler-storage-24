# 任务单 - PM-Agent集成conf-man secrets

**版本**: v2.0
**创建日期**: 2026-02-23
**创建人**: Agent3 (产品经理)
**接收人**: Agent4 (架构师)
**优先级**: P1

---

## 需求来源

HQ任务 `9543efc`：
- 各子系统改用conf-man获取密钥

---

## 任务

### 1. 确认conf-man secrets CLI接口

等待conf-man实现后，确认以下CLI接口可用：
```bash
conf-man secret get siliconflow_key
conf-man secret get webhook_github_secret
conf-man secret get webhook_gitee_secret
```

### 2. 修改pm-agent获取密钥方式

将 `${SILICONFLOW_API_KEY}` 等环境变量引用改为调用conf-man CLI获取：

| 配置项 | 当前方式 | 目标方式 |
|--------|----------|----------|
| siliconflow.api_key | `${SILICONFLOW_API_KEY}` | `conf-man secret get siliconflow_key` |
| llm.api_key | `${OPENAI_API_KEY}` | `conf-man secret get openai_key` |
| webhook.github.secret | `${WEBHOOK_GITHUB_SECRET}` | `conf-man secret get webhook_github_secret` |
| webhook.gitee.secret | `${WEBHOOK_GITEE_SECRET}` | `conf-man secret get webhook_gitee_secret` |

### 3. 实现方案

**方案A：直接调用CLI**
```python
import subprocess
result = subprocess.run(
    ["conf-man", "secret", "get", "siliconflow_key"],
    capture_output=True, text=True
)
api_key = result.stdout.strip()
```

**方案B：调用conf-man API**
```python
import requests
response = requests.get("http://conf-man:8000/api/v1/secrets/siliconflow_key")
api_key = response.json()["value"]
```

**方案C：使用conf-man Python SDK**
（如果有）

### 4. 密钥命名规范

| 密钥名 | 说明 |
|--------|------|
| `siliconflow_key` | SiliconFlow API Key |
| `openai_key` | OpenAI API Key |
| `webhook_github_secret` | GitHub Webhook Secret |
| `webhook_gitee_secret` | Gitee Webhook Secret |

---

## 验收标准

- [ ] 能通过conf-man获取密钥
- [ ] 原有功能正常工作
- [ ] 密钥不泄露到日志或错误信息

---

## 相关文档

- conf-man任务: `conf-man/docs/05-tasks/TASK_v1.3_DEVELOPMENT_by_agent8.md`
- HQ任务: `HQ/docs/05-tasks/TASK_conf-man_secrets_v1.3.md`
