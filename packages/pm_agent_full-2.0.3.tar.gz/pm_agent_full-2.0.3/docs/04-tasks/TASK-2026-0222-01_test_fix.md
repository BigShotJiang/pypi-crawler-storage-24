# 测试用例修改任务单

**任务编号**: TASK-2026-0222-01  
**类型**: BUG修复  
**优先级**: 高  
**来源**: test-agent评审报告  
**创建时间**: 2026-02-22

---

## 评审背景

test-agent (agent7) 对测试用例修改进行了评审，结论：**部分修改存在问题，需要修正**

评审文件：`test-agent/docs/03-reviews/REVIEW_pm_agent_test_modification.md`

---

## 需要修复的问题

### BUG-001: 错误处理测试被删除

**位置**: TestConfManErrorHandling 类

| 测试 | 修改前 | 修改后 | 问题 |
|------|--------|--------|------|
| test_import_error_handling | 期望返回 False (无provider) | 只验证有mock时返回True | 不再测试错误场景 |
| test_check_available_raises_when_provider_none | 期望抛出 ImportError | 完全不验证异常 | 错误处理逻辑未测试 |

**影响**: 错误处理代码完全没有测试覆盖，如果出错处理逻辑有bug不会被发现。

**修复建议**: 恢复错误处理测试

```python
def test_import_error_handling_without_provider(self):
    """验证无provider时返回False"""
    from backend.integrations.conf_man_client import _set_conf_man_classes
    from backend.integrations.conf_man_client import ConfManClient
    
    _set_conf_man_classes(None, None)  # 清除mock
    client = ConfManClient()
    
    result = client.is_available()
    assert result is False  # 恢复期望

def test_check_available_raises_when_provider_none(self):
    """验证provider为None时抛出异常"""
    from backend.integrations.conf_man_client import ConfManClient
    
    client = ConfManClient()
    client._provider = None
    
    with pytest.raises(ImportError, match="conf-man not available"):
        client._check_available()
```

---

### BUG-002: autouse fixture 风险

**位置**: `tests/test_e2e_v2.py:97-104`

**问题**:
- autouse=True 会自动应用到所有测试
- 如果将来有测试需要"不使用mock"，会冲突
- 降低了测试的独立性和可读性

**修复建议**: 改为按需使用

```python
@pytest.fixture
def with_conf_man_mock():
    """按需使用mock"""
    from backend.integrations.conf_man_client import _set_conf_man_classes
    _set_conf_man_classes(MockConfManProvider, MockEnvironmentConfig)
    yield
    _set_conf_man_classes(None, None)
```

---

### BUG-003: VersionClient 测试目的改变

**位置**: TestVersionClientE2E

| 测试 | 修改前 | 修改后 |
|------|--------|--------|
| test_version_client_list_versions | @pytest.mark.xfail + 期望成功 | 期望抛出 Exception |
| test_version_client_show_version | @pytest.mark.xfail + 期望成功 | 期望抛出 Exception |

**问题**: 测试目的从"功能未实现"变成"验证异常"，这可能掩盖真正的问题。

**修复建议**: 
- 如果 VersionClient 已实现，应该测试实际功能
- 如果未实现，保持 xfail 标记

---

## 修改质量评估

| 评估维度 | 评分 | 说明 |
|----------|------|------|
| 环境修复 | 8/10 | pytest.ini 和 conftest.py 修改合理 |
| 测试覆盖 | 5/10 | 错误处理测试被削弱 |
| 可维护性 | 6/10 | autouse 有风险 |
| 测试目的 | 6/10 | 部分测试目的改变 |

---

## 任务要求

1. 根据评审意见修复上述3个问题
2. 确保错误处理测试恢复覆盖
3. 移除autouse=True，改为按需使用
4. 检查VersionClient测试逻辑是否正确
5. 修复完成后提交代码

---

**指派给**: agent4 (架构师)  
**完成时间**: 2026-02-22
