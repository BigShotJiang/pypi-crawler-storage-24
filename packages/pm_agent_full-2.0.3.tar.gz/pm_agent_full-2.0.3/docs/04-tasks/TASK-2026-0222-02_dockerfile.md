# PM-Agent Dockerfile.test 创建任务单

**任务编号**: TASK-2026-0222-02  
**类型**: 环境准备  
**优先级**: 高  
**创建时间**: 2026-02-22

---

## 任务背景

根据test-agent规范，pm-agent需要准备Dockerfile.test才能使用test-agent执行测试。

---

## 任务内容

### 1. 创建 Dockerfile.test

在 pm-agent 根目录创建 `Dockerfile.test`，参考 test-agent 的 `Dockerfile.test` 模板：

```dockerfile
FROM python:3.10-slim

WORKDIR /app

# 安装系统依赖
RUN apt-get update && apt-get install -y \
    git \
    sqlite3 \
    && rm -rf /var/lib/apt/lists/*

# 安装Python依赖
RUN pip install --no-cache-dir \
    click \
    pyyaml \
    pytest \
    pytest-cov \
    pytest-xdist \
    fastapi \
    uvicorn \
    aiohttp

# 复制源代码
COPY backend/ /app/backend/
COPY frontend/ /app/frontend/
COPY config/ /app/config/
COPY state/ /app/state/
COPY docs/ /app/docs/
COPY skills/ /app/skills/

# 复制配置文件
COPY pytest.ini /app/
COPY pyproject.toml /app/
COPY AGENTS.md /app/

# 设置环境变量
ENV PYTHONPATH=/app
ENV TEST_ENV=1

# 运行测试
CMD ["python", "-m", "pytest", "tests/", "-v", "--cov=backend", "--cov-report=html"]
```

### 2. 验证文件存在

确认以下文件/目录存在：
- `backend/` - 后端代码
- `frontend/` - 前端代码
- `tests/` - 测试代码
- `config/` - 配置文件
- `pytest.ini` - pytest配置
- `pyproject.toml` - 项目配置

---

## 验收标准

1. `Dockerfile.test` 存在于 pm-agent 根目录
2. 构建测试镜像成功：`docker build -t pm-agent:test -f Dockerfile.test .`
3. 在镜像内运行测试成功：`docker run --rm pm-agent:test python -m pytest tests/`

---

## 任务完成确认

| 项目 | 状态 | 说明 |
|------|------|------|
| Dockerfile.test | ✅ 已创建 | 已创建在pm-agent根目录 |
| pyproject.toml | ✅ 已创建 | 包含项目配置和pytest配置 |
| 文件验证 | ✅ 通过 | 所有必需文件/目录存在 |

---

**指派给**: agent4 (架构师)  
**完成时间**: 2026-02-22

## 确认签字

| 角色 | 姓名 | 日期 | 确认 |
|------|------|------|------|
| 架构师 | Agent4 | 2026-02-22 | ✅ 已完成 |
| 产品经理 | Agent3 | 2026-02-22 | ✅ 已确认 |
