# 详细设计文档：PM-Agent v1.2.0

**版本**: v2
**创建日期**: 2026-02-19
**作者**: Agent 4 (架构师/开发工程师)
**关联需求**: requirements_pm_agent_v1.2.0_DRAFT.md
**概要设计**: OUTLINE_pm_agent_v1.2.md

---

## 一、变更历史

| 版本 | 日期 | 变更 |
|------|------|------|
| v1 | 2026-02-19 | 初始版本 |
| v2 | 2026-02-19 | 根据评审意见添加功能模块映射、数据流图、签署确认 |
| v3 | 2026-02-19 | 补充完整数据库设计，包含现有9张表详解、新增3张表设计、数据关系图 |

---

## 二、功能模块映射

### 2.1 映射表

| 功能ID | 功能模块 (概要设计) | 技术模块 (详细设计) | 对应文件 | 工时 |
|--------|---------------------|---------------------|----------|------|
| F-021 | Git数据同步 | GitSyncService | backend/services/git_sync_service.py | 4.5h |
| F-022 | 跨项目查询 | OcCollabClient | backend/services/oc_collab_client.py | 3.5h |
| F-023 | 动态状态反馈 | StatusFeedbackService | backend/services/status_feedback_service.py | 4.5h |
| F-024 | Dashboard进度 | ProgressService | backend/services/progress_service.py | 3h |
| F-025 | 问题跟踪同步 | IssueSyncService | backend/services/issue_sync_service.py | 2.5h |
| F-026 | 项目文档汇总 | DocumentFetcher | backend/services/document_fetcher.py | 3h |
| F-027 | 项目保密级别配置 | Project.confidentiality | backend/models/database.py | 1h |
| F-028 | 差异化同步规则 | GitSyncService.should_sync_file | backend/services/git_sync_service.py | 1h |
| F-029 | 保密项目自动同步控制 | SyncPermissionService | backend/services/sync_permission_service.py | 1h |
| F-030 | 保密信息同步检查 | SensitiveContentChecker | backend/services/confidential_checker.py | 2h |

### 2.2 新增文件

| 文件路径 | 功能 | 工时 |
|----------|------|------|
| backend/services/git_sync_service.py | Git同步服务 | 3h |
| backend/services/oc_collab_client.py | oc-collab CLI封装 | 2h |
| backend/services/status_feedback_service.py | 状态反馈服务 | 3h |
| backend/services/progress_service.py | 进度计算服务 | 2h |
| backend/services/issue_sync_service.py | 问题同步服务 | 1.5h |
| backend/services/document_fetcher.py | 文档拉取服务 | 2h |
| backend/services/confidential_checker.py | 敏感信息检查 | 2h |
| backend/services/sync_permission_service.py | 同步权限控制 | 1h |
| backend/api/routes/sync.py | 同步API | 1h |
| backend/api/routes/progress.py | 进度API | 0.5h |
| frontend/src/api/sync.ts | 同步API调用 | 0.5h |

---

## 三、设计目标

v1.2.0的核心目标：
1. **Git数据同步** - 从oc-collab项目拉取数据
2. **跨项目查询** - 调用oc-collab CLI获取状态
3. **动态状态反馈** - 接收状态变更通知
4. **Dashboard完善** - 显示真实项目进度
5. **保密项目隔离** - 差异化同步和敏感信息检查

---

## 四、技术架构

### 3.1 技术选型

| 技术 | 选型 | 说明 |
|------|------|------|
| Git同步 | GitPython | 仓库克隆/同步 |
| CLI调用 | subprocess | 调用oc-collab命令 |
| 定时任务 | schedule | 轮询状态变更 |
| 数据解析 | JSON | 解析CLI返回 |
| 数据库 | SQLite | 已有 |

### 3.2 文件结构

```
backend/
├── services/
│   ├── git_sync_service.py          # M21: Git同步服务
│   ├── oc_collab_client.py          # M22: oc-collab CLI封装
│   ├── status_feedback_service.py    # M23: 状态反馈服务
│   ├── progress_service.py           # M24: 进度计算
│   ├── issue_sync_service.py        # M25: 问题同步
│   ├── document_fetcher.py          # M26: 文档拉取
│   ├── confidential_checker.py      # F030: 敏感信息检查
│   └── sync_permission_service.py   # F029: 同步权限控制
├── api/routes/
│   ├── sync.py                     # 同步API
│   ├── progress.py                 # 进度API
│   └── oc_collab.py               # oc-collab CLI调用API
├── models/
│   └── database.py                 # 扩展数据模型
└── config.py                       # 配置管理

frontend/src/
├── api/
│   └── sync.ts                    # 同步API调用
└── views/
    └── DashboardView.vue          # M24: 进度显示
```

---

## 五、数据流图

### 5.1 数据存储位置

| 数据类型 | 存储位置 | 格式 | 读取方 | 写入方 |
|----------|----------|------|--------|--------|
| 项目同步状态 | project_sync_status表 | SQLite | 前端Dashboard | GitSyncService |
| 同步日志 | sync_logs表 | SQLite | 前端/后台 | GitSyncService |
| 变更历史 | change_history表 | SQLite | 问题跟踪页面 | StatusFeedbackService |
| 进度数据 | project_sync_status表 | SQLite | Dashboard | ProgressService |

### 5.2 数据流图

```
oc-collab项目仓库
       │
       │ git clone / git pull
       ▼
GitSyncService
       │
       ├──→ SQLite (project_sync_status)
       │     │
       │     ▼
       │  ProgressService ──→ DashboardView.vue (进度显示)
       │
       ├──→ StatusFeedbackService
       │     │
       │     ▼
       │  change_history表 ──→ IssuesView.vue (问题跟踪)
       │
       └──→ SensitiveContentChecker
              │
              ▼
            告警/阻止同步

oc-collab CLI
       │
       │ oc-collab project status/todos/progress
       ▼
OcCollabClient
       │
       ▼
ProgressService / IssueSyncService
       │
       ▼
SQLite
```

### 5.3 状态同步路径

| 场景 | 源 | 目标 | 同步方式 | 验证方法 |
|------|-----|------|----------|----------|
| Git同步 | 项目仓库 | 本地 | git pull | 检查last_sync_time |
| 进度更新 | oc-collab CLI | SQLite | CLI查询 | 刷新Dashboard |
| 问题同步 | oc-collab CLI | SQLite | CLI查询 | 刷新Issues页面 |
| 敏感检查 | 同步前扫描 | 内存 | 文件扫描 | 阻止同步并告警 |

### 5.4 风险点

| 风险 | 影响 | 缓解措施 |
|------|------|----------|
| Git仓库访问失败 | 同步中断 | 添加重试机制，记录失败日志 |
| CLI调用超时 | 状态获取失败 | 超时返回缓存数据 |
| 敏感信息泄漏 | 安全风险 | F030严格检查流程 |
backend/
├── services/
│   ├── git_sync_service.py          # M21: Git同步服务
│   ├── oc_collab_client.py          # M22: oc-collab CLI封装
│   ├── status_feedback_service.py    # M23: 状态反馈服务
│   ├── progress_service.py           # M24: 进度计算
│   ├── issue_sync_service.py        # M25: 问题同步
│   ├── document_fetcher.py          # M26: 文档拉取
│   └── confidential_checker.py      # F030: 敏感信息检查
├── api/routes/
│   ├── sync.py                     # 同步API
│   ├── progress.py                 # 进度API
│   └── oc_collab.py                # oc-collab CLI调用API
├── models/
│   └── database.py                 # 扩展数据模型
└── config.py                       # 配置管理

frontend/src/
├── api/
│   └── sync.ts                    # 同步API调用
└── views/
    └── DashboardView.vue          # M24: 进度显示
```

---

## 四、模块详细设计

### 4.1 M21: Git同步服务

**功能**: 定期从oc-collab项目仓库拉取数据

**核心方法**:

```python
class GitSyncService:
    """Git同步服务"""
    
    def __init__(self, base_path: str = None):
        """
        初始化
        
        Args:
            base_path: Git仓库根目录，默认配置中的repos_path
        """
        self.base_path = base_path or get_config('repos_path')
        self.logger = logging.getLogger(__name__)
    
    def sync_project(self, project_name: str, git_repo: str) -> SyncResult:
        """
        同步单个项目
        
        Args:
            project_name: 项目名称
            git_repo: Git仓库路径
            
        Returns:
            SyncResult: 同步结果
        """
        pass
    
    def sync_all(self) -> Dict[str, SyncResult]:
        """同步所有项目"""
        pass
    
    def get_last_sync_time(self, project_name: str) -> Optional[datetime]:
        """获取最后同步时间"""
        pass
    
    def clone_if_not_exists(self, project_name: str, git_repo: str) -> bool:
        """克隆仓库（如果不存在）"""
        pass
    
    def pull_changes(self, project_path: str) -> bool:
        """拉取最新变更"""
        pass
    
    def get_sync_status(self, project_name: str) -> Dict:
        """获取同步状态"""
        pass
```

**新增数据模型 - SyncLog**:

```python
class SyncLog:
    """同步日志模型"""
    id: int
    project_id: int
    sync_type: str  # 'full', 'incremental', 'manual'
    status: str  # 'success', 'failed', 'partial'
    files_synced: int
    error_message: str = None
    started_at: datetime
    completed_at: datetime = None
```

### 4.2 M22: oc-collab CLI封装

**功能**: 调用oc-collab命令查询项目状态

**依赖**: oc-collab v2.3.3 F-AT-11

**核心方法**:

```python
class OcCollabClient:
    """oc-collab CLI封装"""
    
    def __init__(self, timeout: int = 30, max_retries: int = 3):
        """
        初始化
        
        Args:
            timeout: CLI调用超时时间（秒）
            max_retries: 最大重试次数
        """
        self.env = {"OC_COLLAB_INTERNAL": "PM-Agent"}
        self.timeout = timeout
        self.max_retries = max_retries
        self.logger = logging.getLogger(__name__)
    
    def _call_cli(self, args: List[str]) -> Dict:
        """
        调用CLI并处理异常
        
        Args:
            args: CLI参数列表
            
        Returns:
            Dict: 解析后的JSON响应
            
        Raises:
            OcCollabError: CLI调用失败
        """
        pass
    
    def get_project_status(self, project_name: str) -> ProjectStatus:
        """
        获取项目状态
        
        调用: oc-collab project <name> status --json
        
        Returns:
            ProjectStatus: 项目状态
        """
        pass
    
    def get_project_todos(self, project_name: str, status: str = None) -> List[Todo]:
        """
        获取TODO列表
        
        调用: oc-collab project <name> todos --json
        
        Args:
            project_name: 项目名称
            status: 过滤状态（pending/completed/all）
            
        Returns:
            List[Todo]: TODO列表
        """
        pass
    
    def get_project_progress(self, project_name: str) -> Progress:
        """
        获取项目进度
        
        调用: oc-collab project <name> progress --json
        
        Returns:
            Progress: 项目进度
        """
        pass
    
    def get_changes(self, project_name: str, since: str) -> List[Change]:
        """
        获取变更记录
        
        调用: oc-collab project <name> changes --since=<timestamp> --json
        
        Args:
            project_name: 项目名称
            since: ISO格式时间戳
            
        Returns:
            List[Change]: 变更列表
        """
        pass
    
    def is_cli_available(self) -> bool:
        """检查CLI是否可用"""
        pass
```

**错误处理（重点）**:

```python
class OcCollabError(Exception):
    """oc-collab调用异常"""
    def __init__(self, message: str, error_type: str = None, raw_output: str = None):
        super().__init__(message)
        self.error_type = error_type
        self.raw_output = raw_output

class OcCollabTimeoutError(OcCollabError):
    """CLI调用超时"""

class OcCollabAuthError(OcCollabError):
    """认证失败"""

class OcCollabNotFoundError(OcCollabError):
    """项目不存在"""

class OcCollabParseError(OcCollabError):
    """JSON解析失败"""
```

**错误处理策略**:

| 异常类型 | 处理方式 | 返回 |
|----------|----------|------|
| CLI调用超时 | 重试3次，记录日志 | {"error": "timeout", "message": "..."} |
| 网络异常 | 返回离线状态 | {"error": "offline", "message": "..."} |
| 权限问题 | 返回"未认证"提示 | {"error": "unauthorized", "message": "..."} |
| 项目不存在 | 返回404错误 | {"error": "not_found", "message": "..."} |
| JSON解析失败 | 返回原始输出 | {"error": "parse_error", "raw": "..."} |

### 4.3 M23: 状态反馈服务

**功能**: 接收oc-collab状态变更通知

**核心方法**:

```python
class StatusFeedbackService:
    """状态反馈服务"""
    
    def __init__(self, client: OcCollabClient, storage: TodoStorage):
        self.client = client
        self.storage = storage
        self.last_check_time: Optional[datetime] = None
        self.polling_interval = 60  # 秒
        self.logger = logging.getLogger(__name__)
    
    def poll_changes(self) -> List[Change]:
        """
        轮询状态变更
        
        Returns:
            List[Change]: 变更列表
        """
        pass
    
    def update_local_status(self, changes: List[Change]) -> int:
        """
        更新本地状态
        
        Args:
            changes: 变更列表
            
        Returns:
            int: 更新的记录数
        """
        pass
    
    def start_polling(self, interval: int = 60):
        """
        启动定时轮询
        
        Args:
            interval: 轮询间隔（秒）
        """
        pass
    
    def stop_polling(self):
        """停止轮询"""
        pass
    
    def process_change(self, change: Change) -> bool:
        """
        处理单条变更
        
        Args:
            change: 变更记录
            
        Returns:
            bool: 是否处理成功
        """
        pass
```

### 4.4 M24: Dashboard进度

**功能**: 显示项目真实进度

**数据来源**:
- 需求完成情况（从oc-collab获取）
- BUG修复情况（从oc-collab获取）
- TODO完成情况（从oc-collab获取）

**进度计算公式**:
```
进度 = (需求完成数/需求总数 × 40%) + (BUG解决数/BUG总数 × 30%) + (TODO完成数/TODO总数 × 30%)
```

**核心方法**:

```python
class ProgressService:
    """进度计算服务"""
    
    def __init__(self, client: OcCollabClient):
        self.client = client
    
    def get_project_progress(self, project_name: str) -> ProjectProgress:
        """
        获取项目进度
        
        Args:
            project_name: 项目名称
            
        Returns:
            ProjectProgress: 项目进度
        """
        pass
    
    def calculate_overall_progress(self, progress: ProjectProgress) -> int:
        """
        计算综合进度百分比
        
        Args:
            progress: 项目进度数据
            
        Returns:
            int: 进度百分比 (0-100)
        """
        requirements_weight = 0.4
        bugs_weight = 0.3
        todos_weight = 0.3
        
        req_progress = progress.requirements.completed / progress.requirements.total if progress.requirements.total > 0 else 0
        bug_progress = progress.bugs.resolved / progress.bugs.total if progress.bugs.total > 0 else 0
        todo_progress = progress.todos.completed / progress.todos.total if progress.todos.total > 0 else 0
        
        return int((req_progress * requirements_weight + 
                   bug_progress * bugs_weight + 
                   todo_progress * todos_weight) * 100)
    
    def get_all_projects_summary(self) -> ProjectsSummary:
        """获取所有项目汇总"""
        pass
```

### 4.5 M25: 问题跟踪同步

**功能**: 问题跟踪页面显示真实状态

**核心方法**:

```python
class IssueSyncService:
    """问题同步服务"""
    
    def __init__(self, client: OcCollabClient):
        self.client = client
    
    def sync_bugs(self, project_name: str) -> List[Bug]:
        """
        同步BUG列表
        
        Args:
            project_name: 项目名称
            
        Returns:
            List[Bug]: BUG列表
        """
        pass
    
    def sync_requirements(self, project_name: str) -> List[Requirement]:
        """
        同步需求列表
        
        Args:
            project_name: 项目名称
            
        Returns:
            List[Requirement]: 需求列表
        """
        pass
    
    def update_bug_status(self, bug_id: str, status: str) -> bool:
        """更新BUG状态"""
        pass
    
    def update_requirement_status(self, req_id: str, status: str) -> bool:
        """更新需求状态"""
        pass
```

### 4.6 M26: 项目文档汇总

**功能**: 从oc-collab项目拉取开发文档

**核心方法**:

```python
class DocumentFetcher:
    """文档拉取服务"""
    
    def __init__(self, base_path: str):
        self.base_path = base_path
    
    def fetch_docs(self, project_path: str) -> List[Document]:
        """
        从项目仓库拉取文档
        
        Args:
            project_path: 项目路径
            
        Returns:
            List[Document]: 文档列表
        """
        pass
    
    def search(self, keyword: str, project_name: str = None) -> List[Document]:
        """
        搜索文档
        
        Args:
            keyword: 关键字
            project_name: 项目名称（可选）
            
        Returns:
            List[Document]: 匹配的文档
        """
        pass
    
    def get_doc_content(self, doc_path: str) -> str:
        """获取文档内容"""
        pass
    
    def list_doc_categories(self, project_path: str) -> Dict[str, List[str]]:
        """列出文档分类"""
        pass
```

---

## 五、API设计

### 5.1 同步API

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | /api/sync/project/{project_name} | 手动触发同步 |
| POST | /api/sync/all | 同步所有项目 |
| GET | /api/sync/status | 获取同步状态 |
| GET | /api/sync/logs | 获取同步日志 |

**响应格式**:

```json
// POST /api/sync/project/{project_name}
{
  "status": "success",
  "project_name": "金融法院",
  "synced_at": "2026-02-19T10:00:00Z",
  "files_synced": 15
}

// GET /api/sync/status
{
  "projects": {
    "金融法院": {
      "last_sync": "2026-02-19T10:00:00Z",
      "status": "ok",
      "files_count": 150
    },
    "阳光执法": {
      "last_sync": "2026-02-19T09:00:00Z",
      "status": "ok",
      "files_count": 80
    }
  }
}
```

### 5.2 进度API

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/progress/{project_name} | 获取项目进度 |
| GET | /api/progress/summary | 获取所有项目汇总 |

**响应格式**:

```json
// GET /api/progress/{project_name}
{
  "project": "金融法院",
  "progress": 65,
  "requirements": {
    "total": 10,
    "completed": 5,
    "in_progress": 3,
    "pending": 2
  },
  "bugs": {
    "total": 3,
    "resolved": 2,
    "open": 1
  },
  "todos": {
    "total": 8,
    "completed": 5,
    "pending": 3
  },
  "updated_at": "2026-02-19T10:00:00Z"
}

// GET /api/progress/summary
{
  "total_projects": 5,
  "avg_progress": 45,
  "projects": [...]
}
```

### 5.3 配置API

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | /api/config/sync | 获取同步配置 |
| PUT | /api/config/sync | 更新同步配置 |

---

## 六、数据库设计

### 6.1 设计原则

本系统的数据库设计遵循以下原则：

| 原则 | 说明 |
|------|------|
| **继承现有结构** | v1.2.0的新功能基于现有数据库结构扩展，不破坏已有数据 |
| **可追溯性** | 所有重要操作都记录日志，便于问题排查和审计 |
| **性能优化** | 对常用查询字段建立索引，确保系统响应速度 |
| **扩展性** | 新增表预留扩展字段，支持未来功能迭代 |

### 6.2 现有数据库结构（v1.1.0）

系统已有以下9张核心数据表，这些表支撑着项目管理、材料处理、问题跟踪等核心功能。

#### 6.2.1 客户表（customers）

**用途**：存储客户信息，每个客户可以包含多个项目

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键，系统自动生成 | 1 |
| name | 文本(255) | 是 | 客户名称，唯一不可重复 | "上海市第一中级人民法院" |
| keywords | 文本 | 否 | 关键词，用于快速搜索 | "法院,诉讼,审判" |
| git_repo | 文本(500) | 否 | Git仓库地址 | "/repos/shanghai_court" |
| contact | 文本(255) | 否 | 联系人信息 | "张法官, 138****8888" |
| status | 文本(20) | 否 | 状态：active(活跃)/inactive(停用) | "active" |
| created_at | 时间戳 | 是 | 创建时间 | 2026-01-01 10:00:00 |
| updated_at | 时间戳 | 是 | 最后更新时间 | 2026-02-19 15:30:00 |

**关联关系**：一个客户可以拥有多个项目（projects）

---

#### 6.2.2 项目表（projects）

**用途**：核心表，存储项目基本信息，一个项目属于一个客户

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键，系统自动生成 | 1 |
| customer_id | 整数 | 否 | 关联客户ID，删除客户时项目保留 | 1 |
| name | 文本(255) | 是 | 项目名称 | "金融法院智能化项目" |
| keywords | 文本 | 否 | 项目关键词 | "AI,法官助手,智能审判" |
| status | 文本(20) | 否 | 项目状态：planning/planning/active/completed/suspended | "active" |
| progress | 整数 | 否 | 进度百分比(0-100) | 65 |
| git_repo | 文本(500) | 否 | Git仓库路径 | "/repos/financial_court" |
| **confidentiality** | 文本(20) | 否 | **保密级别：normal(普通)/confidential(保密)** | "normal" |
| created_at | 时间戳 | 是 | 创建时间 | 2026-01-15 09:00:00 |
| updated_at | 时间戳 | 是 | 最后更新时间 | 2026-02-19 14:20:00 |

**新增字段说明**：
- **confidentiality**：v1.2.0新增，用于标记项目保密级别，是F027功能的核心字段

**关联关系**：
- 属于一个客户（customers）
- 可以包含多个处理日志（processing_logs）
- 可以包含多个BUG（bugs）
- 可以包含多个需求（proposals）
- 可以包含多个材料（materials）
- 可以包含多个模板（project_templates）

---

#### 6.2.3 处理日志表（processing_logs）

**用途**：记录材料处理的全过程，从输入到AI处理结果

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键 | 1 |
| input_type | 文本(20) | 是 | 输入类型：file(文件)/text(文本)/url(网址) | "file" |
| file_path | 文本(500) | 否 | 文件路径 | "/uploads/2026/01/test.pdf" |
| content | 文本 | 否 | 原始输入内容 | "案件编号: 2026-001..." |
| extracted_text | 文本 | 否 | 提取的文本内容 | "原告: 张三..." |
| dossierai_response | 文本 | 否 | AI处理结果 | "识别到合同纠纷..." |
| issue_type | 文本(20) | 否 | 问题类型：bug/requirement/proposal | "bug" |
| issue_id | 文本(50) | 否 | 关联的问题ID | "BUG-2026-001" |
| customer_id | 整数 | 否 | 关联客户ID | 1 |
| project_id | 整数 | 否 | 关联项目ID | 1 |
| result | 文本(20) | 否 | 处理结果：pending/success/failed | "success" |
| error_message | 文本 | 否 | 错误信息 | "文件格式不支持" |
| created_at | 时间戳 | 是 | 创建时间 | 2026-02-19 10:00:00 |
| updated_at | 时间戳 | 是 | 更新时间 | 2026-02-19 10:05:00 |

---

#### 6.2.4 BUG表（bugs）

**用途**：记录项目中发现的问题/bug

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键 | 1 |
| bug_id | 文本(50) | 是 | BUG编号，唯一 | "BUG-2026-001" |
| project_id | 整数 | 是 | 所属项目ID | 1 |
| title | 文本(255) | 是 | BUG标题 | "登录页面按钮无响应" |
| description | 文本 | 否 | 详细描述 | "点击登录按钮无任何反应..." |
| severity | 文本(5) | 否 | 严重程度：critical/high/medium/low | "high" |
| status | 文本(20) | 否 | 状态：open/in_progress/resolved/closed | "open" |
| steps_to_reproduce | 文本 | 否 | 复现步骤 | "1. 打开首页\n2. 点击登录" |
| expected_behavior | 文本 | 否 | 预期行为 | "弹出登录对话框" |
| actual_behavior | 文本 | 否 | 实际行为 | "无任何反应" |
| environment | 文本 | 否 | 环境信息 | "Chrome 120, Windows 11" |
| assigned_to | 文本(100) | 否 | 负责人 | "李开发" |
| oc_git_commit_hash | 文本(40) | 否 | oc-collab提交哈希 | "a1b2c3d4..." |
| created_by | 文本(50) | 否 | 创建者 | "PM-Agent" |
| created_at | 时间戳 | 是 | 创建时间 | 2026-02-15 09:00:00 |
| updated_at | 时间戳 | 是 | 更新时间 | 2026-02-19 11:00:00 |
| resolved_at | 时间戳 | 否 | 解决时间 | 2026-02-18 16:00:00 |

---

#### 6.2.5 需求表（proposals）

**用途**：记录项目需求/提案

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键 | 1 |
| proposal_id | 文本(50) | 是 | 需求编号，唯一 | "REQ-2026-001" |
| project_id | 整数 | 是 | 所属项目ID | 1 |
| title | 文本(255) | 是 | 需求标题 | "支持PDF文件上传" |
| background | 文本 | 否 | 需求背景 | "当前系统仅支持图片..." |
| user_scenario | 文本 | 否 | 用户场景 | "作为用户，我需要..." |
| expected_behavior | 文本 | 否 | 预期行为 | "系统应接受PDF文件..." |
| priority | 文本(10) | 否 | 优先级：high/medium/low | "high" |
| status | 文本(20) | 否 | 状态：draft/proposed/in_progress/implemented/rejected | "implemented" |
| estimated_hours | 浮点数 | 否 | 预估工时(小时) | 8.5 |
| oc_git_commit_hash | 文本(40) | 否 | oc-collab提交哈希 | "e5f6g7h8..." |
| created_by | 文本(50) | 否 | 创建者 | "PM-Agent" |
| created_at | 时间戳 | 是 | 创建时间 | 2026-01-20 10:00:00 |
| updated_at | 时间戳 | 是 | 更新时间 | 2026-02-19 14:00:00 |
| implemented_at | 时间戳 | 否 | 实现时间 | 2026-02-18 17:00:00 |

---

#### 6.2.6 材料表（materials）

**用途**：存储项目相关的文档、材料文件

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 文本(36) | 是 | 主键(UUID格式) | "550e8400-e29b-41d4-a716-446655440000" |
| project_id | 整数 | 否 | 关联项目ID | 1 |
| file_name | 文本(255) | 是 | 文件名 | "案件材料.pdf" |
| file_type | 文本(20) | 是 | 文件类型：pdf/doc/docx/txt/img | "pdf" |
| file_hash | 文本(64) | 是 | 文件哈希值(SHA256) | "a1b2c3d4e5f6..." |
| file_size | 整数 | 是 | 文件大小(字节) | 1024000 |
| storage_path | 文本(500) | 是 | 存储路径 | "/data/materials/2026/01/..." |
| status | 文本(20) | 否 | 状态：pending/processed/error | "processed" |
| issue_type | 文本(20) | 否 | 关联问题类型 | "bug" |
| issue_id | 文本(50) | 否 | 关联问题ID | "BUG-2026-001" |
| raw_content | 文本 | 否 | 原始内容 | "案件编号: 2026-001..." |
| processed_content | 文本 | 否 | 处理后内容 | "原告: 张三\n被告: 李四..." |
| template_id | 文本(36) | 否 | 使用的模板ID | "template-001" |
| route_target | 文本(500) | 否 | 路由目标页面 | "/materials/detail/xxx" |
| route_history | 文本 | 否 | 浏览历史记录(JSON格式) | "[{"path": "/", "time": ...}]" |
| created_at | 时间戳 | 是 | 创建时间 | 2026-02-19 09:00:00 |
| updated_at | 时间戳 | 是 | 更新时间 | 2026-02-19 09:30:00 |

---

#### 6.2.7 项目模板表（project_templates）

**用途**：存储项目使用的提示词模板

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 文本(36) | 是 | 主键(UUID格式) | "template-001" |
| project_id | 整数 | 是 | 所属项目ID | 1 |
| name | 文本(255) | 是 | 模板名称 | "案件分析模板" |
| template_type | 文本(20) | 是 | 模板类型：analysis/summary/extract | "analysis" |
| prompt_template | 文本 | 是 | 提示词模板内容 | "请分析以下案件材料..." |
| output_format | 文本(20) | 否 | 输出格式：markdown/json/text | "markdown" |
| fields | 文本 | 是 | 字段定义(JSON格式) | "{"plaintiff": "原告", ...}" |
| enabled | 布尔 | 否 | 是否启用 | true |
| created_at | 时间戳 | 是 | 创建时间 | 2026-01-10 10:00:00 |
| updated_at | 时间戳 | 是 | 更新时间 | 2026-02-15 11:00:00 |

---

#### 6.2.8 操作日志表（operation_logs）

**用途**：记录系统操作日志，用于审计和问题排查

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键 | 1 |
| operation_type | 文本(50) | 是 | 操作类型 | "create_project" |
| target_type | 文本(50) | 否 | 操作对象类型 | "project" |
| target_id | 文本(50) | 否 | 操作对象ID | "1" |
| details | 文本 | 否 | 详细信息(JSON) | "{"name": "新项目"}" |
| operator | 文本(50) | 否 | 操作人 | "admin" |
| created_at | 时间戳 | 是 | 操作时间 | 2026-02-19 14:00:00 |

---

#### 6.2.9 系统设置表（settings）

**用途**：存储系统配置参数

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键 | 1 |
| key | 文本(100) | 是 | 配置键，唯一 | "sync_interval" |
| value | 文本 | 否 | 配置值 | "3600" |
| description | 文本 | 否 | 配置说明 | "同步间隔(秒)" |
| created_at | 时间戳 | 是 | 创建时间 | 2026-01-01 00:00:00 |
| updated_at | 时间戳 | 是 | 更新时间 | 2026-02-19 00:00:00 |

---

### 6.3 v1.2.0新增数据表

v1.2.0版本新增3张数据表，用于支撑Git同步、进度追踪、变更历史等功能。

#### 6.3.1 项目同步状态表（project_sync_status）

**用途**：记录每个项目的Git同步状态和进度数据，是Dashboard显示的核心数据源

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键 | 1 |
| project_id | 整数 | 是 | 关联项目ID，外键指向projects表 | 1 |
| last_sync_time | 时间戳 | 否 | 最后一次同步时间 | 2026-02-19 15:00:00 |
| sync_status | 文本(20) | 否 | 同步状态：ok(正常)/failed(失败)/syncing(同步中) | "ok" |
| requirements_total | 整数 | 否 | 需求总数 | 10 |
| requirements_completed | 整数 | 否 | 已完成需求数 | 5 |
| requirements_in_progress | 整数 | 否 | 进行中需求数 | 3 |
| bugs_total | 整数 | 否 | BUG总数 | 3 |
| bugs_resolved | 整数 | 否 | 已解决BUG数 | 2 |
| todos_total | 整数 | 否 | TODO总数 | 8 |
| todos_completed | 整数 | 否 | 已完成TODO数 | 5 |
| progress_percentage | 整数 | 否 | 综合进度百分比(0-100) | 65 |
| files_count | 整数 | 否 | 同步的文件数量 | 150 |
| updated_at | 时间戳 | 是 | 数据更新时间 | 2026-02-19 15:05:00 |

**数据来源**：
- 通过M21 GitSyncService从Git仓库获取files_count
- 通过M22 OcCollabClient从CLI获取requirements/bugs/todos数据
- 通过M24 ProgressService计算progress_percentage

**更新频率**：
- 每次同步操作后更新
- 定时任务每60秒轮询更新

---

#### 6.3.2 同步日志表（sync_logs）

**用途**：记录每次Git同步操作的详细日志，便于问题排查和审计

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键 | 1 |
| project_id | 整数 | 是 | 关联项目ID，外键指向projects表 | 1 |
| sync_type | 文本(20) | 是 | 同步类型：full(全量)/incremental(增量)/manual(手动) | "incremental" |
| status | 文本(20) | 是 | 同步结果：success(成功)/failed(失败)/partial(部分成功) | "success" |
| files_synced | 整数 | 否 | 同步的文件数量 | 15 |
| files_added | 整数 | 否 | 新增文件数 | 3 |
| files_modified | 整数 | 否 | 修改文件数 | 10 |
| files_deleted | 整数 | 否 | 删除文件数 | 2 |
| error_message | 文本 | 否 | 错误信息(失败时) | "网络超时" |
| started_at | 时间戳 | 是 | 同步开始时间 | 2026-02-19 15:00:00 |
| completed_at | 时间戳 | 否 | 同步完成时间 | 2026-02-19 15:05:00 |

**保留策略**：
- 保留最近90天的同步日志
- 超过90天的日志自动归档或清理

---

#### 6.3.3 变更历史表（change_history）

**用途**：记录项目状态变更历史，支持问题跟踪页面的时间线展示

| 字段名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | 整数 | 是 | 主键 | 1 |
| project_id | 整数 | 是 | 关联项目ID，外键指向projects表 | 1 |
| change_type | 文本(20) | 是 | 变更类型：bug/requirement/todo/progress | "bug" |
| change_id | 文本(50) | 是 | 变更项ID | "BUG-2026-001" |
| change_title | 文本(255) | 否 | 变更项标题 | "修复登录按钮无响应" |
| old_status | 文本(20) | 否 | 变更前状态 | "open" |
| new_status | 文本(20) | 否 | 变更后状态 | "in_progress" |
| old_value | 文本 | 否 | 变更前数值(用于进度变更) | "50" |
| new_value | 文本 | 否 | 变更后数值 | "65" |
| change_description | 文本 | 否 | 变更描述 | "开始处理此BUG" |
| changed_at | 时间戳 | 是 | 变更发生时间 | 2026-02-19 14:30:00 |
| synced_at | 时间戳 | 是 | 同步到本地时间 | 2026-02-19 14:35:00 |
| source | 文本(50) | 否 | 变更来源：oc_collab/manual/system | "oc_collab" |

**用途说明**：
- M23 StatusFeedbackService通过轮询oc-collab检测状态变更
- 发现新变更时写入此表
- 前端问题跟踪页面展示时间线

---

### 6.4 数据表关系图

```
┌─────────────────┐       ┌─────────────────┐
│   customers     │       │    settings     │
│   (客户)         │       │    (设置)       │
└────────┬────────┘       └─────────────────┘
         │
         │ 1:N
         ▼
┌──────────────────────────────────────────────┐
│                  projects                    │
│                  (项目)                       │
│  + confidentiality (新增)                     │
└────────┬─────────────┬──────────────┬─────────┘
         │             │              │
    1:N  │        1:N  │         1:N  │
    ▼    │        ▼    │         ▼    │
┌────────┐  ┌────────┐ ┌────────┐  ┌──────────┐
│processing│  │ bugs  │ │proposals│ │ materials│
│  logs   │  │(BUG)  │ │(需求)   │ │ (材料)   │
└────────┘  └────────┘ └────────┘  └──────────┘
                  │
                  │ 1:N
                  ▼
         ┌────────────────┐
         │project_templates│
         │    (模板)       │
         └────────────────┘

=== v1.2.0 新增表 ===

┌──────────────────────────┐     ┌──────────────────┐
│  project_sync_status     │     │   sync_logs      │
│  (项目同步状态)           │     │   (同步日志)      │
│  - project_id (FK)       │     │  - project_id(FK)│
└──────────────────────────┘     └──────────────────┘

┌──────────────────────────┐
│    change_history        │
│    (变更历史)             │
│  - project_id (FK)       │
└──────────────────────────┘
```

---

### 6.5 字段变更汇总

#### 6.5.1 现有表新增字段

| 表名 | 新增字段 | 类型 | 说明 |
|------|----------|------|------|
| projects | confidentiality | 文本(20) | 保密级别：normal/confidential |

#### 6.5.2 新建数据表

| 表名 | 说明 | 主要用途 |
|------|------|----------|
| project_sync_status | 项目同步状态 | Dashboard进度显示、同步状态查询 |
| sync_logs | 同步日志 | 同步历史记录、问题排查 |
| change_history | 变更历史 | 问题跟踪时间线、状态变更记录 |

---

### 6.6 数据库性能考虑

#### 6.6.1 索引设计

为保证查询性能，对常用查询字段建立索引：

| 表名 | 索引字段 | 用途 |
|------|----------|------|
| customers | name, status | 按名称搜索、客户列表 |
| projects | customer_id, status, confidentiality | 项目列表查询、保密筛选 |
| processing_logs | customer_id, project_id | 处理日志查询 |
| bugs | project_id, status | BUG列表、状态筛选 |
| proposals | project_id, status | 需求列表、状态筛选 |
| materials | project_id, file_hash, status | 材料查询、去重检查 |
| project_templates | project_id | 模板查询 |
| project_sync_status | project_id, last_sync_time | 同步状态查询 |
| sync_logs | project_id, started_at | 同步历史查询 |
| change_history | project_id, change_type, changed_at | 变更历史查询 |

#### 6.6.2 数据量预估

| 数据类型 | 预估增长 | 保留策略 |
|----------|----------|----------|
| 项目同步状态 | 每个项目1条 | 长期保留 |
| 同步日志 | 每周每项目约10-50条 | 保留90天 |
| 变更历史 | 每周每项目约20-100条 | 保留180天 |

---

### 6.7 与现有代码的集成

#### 6.7.1 修改现有模型

在 `backend/models/database.py` 的 `Project` 类中添加新字段：

```python
class Project(Base):
    # 现有字段...
    oc_collab_enabled = Column(Boolean, default=False)
    # 新增字段
    confidentiality = Column(String(20), default='normal')  # 'normal' | 'confidential'
```

#### 6.7.2 新增模型

在 `backend/models/database.py` 中新增3个模型类：

```python
class ProjectSyncStatus(Base):
    """项目同步状态"""
    __tablename__ = 'project_sync_status'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False)
    last_sync_time = Column(DateTime)
    sync_status = Column(String(20), default='ok')
    requirements_total = Column(Integer, default=0)
    requirements_completed = Column(Integer, default=0)
    requirements_in_progress = Column(Integer, default=0)
    bugs_total = Column(Integer, default=0)
    bugs_resolved = Column(Integer, default=0)
    todos_total = Column(Integer, default=0)
    todos_completed = Column(Integer, default=0)
    progress_percentage = Column(Integer, default=0)
    files_count = Column(Integer, default=0)
    updated_at = Column(DateTime, default=datetime.now, onupdate=datetime.now)
    
    project = relationship("Project", back_populates="sync_status")


class SyncLog(Base):
    """同步日志"""
    __tablename__ = 'sync_logs'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False)
    sync_type = Column(String(20), nullable=False)
    status = Column(String(20), default='success')
    files_synced = Column(Integer, default=0)
    files_added = Column(Integer, default=0)
    files_modified = Column(Integer, default=0)
    files_deleted = Column(Integer, default=0)
    error_message = Column(Text)
    started_at = Column(DateTime, default=datetime.now)
    completed_at = Column(DateTime)
    
    project = relationship("Project", back_populates="sync_logs")


class ChangeHistory(Base):
    """变更历史"""
    __tablename__ = 'change_history'
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    project_id = Column(Integer, ForeignKey('projects.id'), nullable=False)
    change_type = Column(String(20), nullable=False)
    change_id = Column(String(50), nullable=False)
    change_title = Column(String(255))
    old_status = Column(String(20))
    new_status = Column(String(20))
    old_value = Column(Text)
    new_value = Column(Text)
    change_description = Column(Text)
    changed_at = Column(DateTime, nullable=False)
    synced_at = Column(DateTime, default=datetime.now)
    source = Column(String(50), default='oc_collab')
    
    project = relationship("Project", back_populates="change_history")
```

#### 6.7.3 更新Project关系

```python
class Project(Base):
    # 现有关系...
    templates = relationship("ProjectTemplate", back_populates="project")
    # 新增关系
    sync_status = relationship("ProjectSyncStatus", back_populates="project", uselist=False)
    sync_logs = relationship("SyncLog", back_populates="project")
    change_history = relationship("ChangeHistory", back_populates="project")
```

---

### 6.8 数据库设计验证

| 验证项 | 状态 | 说明 |
|--------|------|------|
| 现有9张表完整性 | ✅ | Customer, Project, ProcessingLog, Bug, Proposal, Material, ProjectTemplate, OperationLog, Setting |
| v1.2.0新增3张表 | ✅ | ProjectSyncStatus, SyncLog, ChangeHistory |
| Project保密字段 | ✅ | confidentiality字段 |
| 外键关系完整性 | ✅ | 所有关联关系正确建立 |
| 索引覆盖 | ✅ | 常用查询字段已建索引 |
| 与现有代码兼容 | ✅ | 不破坏现有数据结构 |

---

## 七、配置文件

### sync_config.yaml

```yaml
sync:
  # 同步间隔（秒）
  interval: 3600
  
  # 是否启用自动同步
  auto_sync: true
  
  # 同步超时时间（秒）
  timeout: 300
  
  # 每次最大同步文件数
  max_files_per_sync: 100

projects:
  - name: "金融法院"
    git_repo: "/path/to/金融法院"
    enabled: true
    confidentiality: "normal"  # normal / confidential
  
  - name: "阳光执法"
    git_repo: "/path/to/阳光执法"
    enabled: true
    confidentiality: "normal"

confidential:
  # 敏感关键词检测
  sensitive_keywords:
    - "保密"
    - "内部"
    - "confidential"
    - "secret"
    - "private"
  
  # 排除检查的目录
  exclude_dirs:
    - ".git"
    - "node_modules"
  
  # 排除检查的文件模式
  exclude_patterns:
    - "*.lock"
    - "package-lock.json"
```

---

## 八、保密项目功能设计

### 8.1 F-027: 项目保密级别配置

**实现**:

```python
class Project:
    # 现有字段 + 新增字段
    confidentiality = Column(String(20), default='normal')  # 'normal' | 'confidential'
```

### 8.2 F-028: 差异化同步规则

**实现**:

```python
class GitSyncService:
    def should_sync_file(self, file_path: str, project_confidentiality: str) -> bool:
        """
        判断文件是否应该同步
        
        Args:
            file_path: 文件路径
            project_confidentiality: 项目保密级别
            
        Returns:
            bool: 是否同步
        """
        if project_confidentiality == 'normal':
            return True  # 全量同步
        
        # 保密项目：跳过文档目录
        doc_dirs = ['docs/01-requirements/', 'docs/02-design/']
        for doc_dir in doc_dirs:
            if file_path.startswith(doc_dir):
                return False
        return True
```

### 8.3 F-029: 保密项目自动同步控制

**实现**:

```python
class SyncPermissionService:
    def can_auto_sync(self) -> Tuple[bool, str]:
        """
        检查是否允许自动同步
        
        Returns:
            (允许, 原因)
        """
        confidential_projects = self.db.query(Project).filter(
            Project.confidentiality == 'confidential',
            Project.status == 'active'
        ).all()
        
        if confidential_projects:
            return False, f"存在{len(confidential_projects)}个活跃保密项目，禁用自动同步"
        return True, "允许自动同步"
    
    def should_warn_before_manual_sync(self) -> Tuple[bool, str]:
        """检查手动同步是否需要警告"""
        # 类似实现
        pass
```

### 8.4 F-030: 保密信息同步检查

**实现**:

```python
class SensitiveContentChecker:
    """敏感内容检查器"""
    
    def __init__(self, config: dict):
        self.keywords = config.get('sensitive_keywords', [])
        self.exclude_patterns = config.get('exclude_patterns', [])
    
    def check_files(self, project_path: str) -> List[SensitiveFile]:
        """
        检查项目文件
        
        Args:
            project_path: 项目路径
            
        Returns:
            List[SensitiveFile]: 包含敏感信息的文件列表
        """
        sensitive_files = []
        
        for root, dirs, files in os.walk(project_path):
            # 跳过排除目录
            dirs[:] = [d for d in dirs if not self._is_excluded(d)]
            
            for file in files:
                if self._is_excluded(file):
                    continue
                    
                file_path = os.path.join(root, file)
                if self._contains_sensitive(file_path):
                    sensitive_files.append(SensitiveFile(
                        path=file_path,
                        matched_keywords=self._find_keywords(file_path),
                        line_numbers=self._find_line_numbers(file_path)
                    ))
        
        return sensitive_files
    
    def _contains_sensitive(self, file_path: str) -> bool:
        """检查文件是否包含敏感词"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                return any(keyword in content for keyword in self.keywords)
        except:
            return False
    
    def _find_keywords(self, file_path: str) -> List[str]:
        """找出匹配的关键词"""
        matched = []
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
                for keyword in self.keywords:
                    if keyword in content:
                        matched.append(keyword)
        except:
            pass
        return matched
```

---

## 九、前端设计

### 9.1 Dashboard进度显示

**组件**: DashboardView.vue

**新增功能**:
1. 显示项目进度百分比（环形进度条）
2. 显示需求统计（总数/完成/进行中）
3. 显示BUG统计（总数/已解决/待解决）
4. 显示TODO统计（总数/完成/待处理）
5. 支持多项目汇总视图

**API调用**:

```typescript
// 获取项目进度
async function fetchProjectProgress(projectName: string) {
  const response = await fetch(`/api/progress/${projectName}`)
  return response.json()
}

// 获取所有项目汇总
async function fetchProjectsSummary() {
  const response = await fetch('/api/progress/summary')
  return response.json()
}
```

---

## 十、错误处理策略

### 10.1 CLI调用错误

| 错误类型 | 错误码 | 用户提示 | 日志级别 |
|----------|--------|----------|----------|
| CLI不存在 | 1001 | "oc-collab CLI未安装" | ERROR |
| 超时 | 1002 | "请求超时，请重试" | WARNING |
| 认证失败 | 1003 | "请检查oc-collab登录状态" | ERROR |
| 项目不存在 | 1004 | "项目不存在" | INFO |
| 网络错误 | 1005 | "网络异常，请检查连接" | WARNING |

### 10.2 Git同步错误

| 错误类型 | 错误码 | 用户提示 |
|----------|--------|----------|
| 仓库不存在 | 2001 | "Git仓库路径不存在" |
| 权限不足 | 2002 | "无仓库访问权限" |
| 同步冲突 | 2003 | "存在冲突，请手动解决" |
| 网络错误 | 2004 | "网络异常，同步失败" |

---

## 十一、测试策略

### 11.1 单元测试

| 模块 | 测试用例数 |
|------|-----------|
| M21 Git同步服务 | 15 |
| M22 CLI封装 | 20 |
| M23 状态反馈 | 10 |
| M24 进度计算 | 8 |
| M25 问题同步 | 10 |
| M26 文档拉取 | 8 |
| F027-F030 保密功能 | 12 |
| **总计** | **83** |

### 11.2 集成测试

| 测试场景 | 说明 |
|----------|------|
| CLI可用性检测 | oc-collab CLI是否可用 |
| 仓库同步流程 | 完整同步流程 |
| 进度计算准确性 | 计算结果验证 |
| 错误恢复 | 异常场景处理 |

---

## 十二、工时预估

| 模块 | 设计 | 开发 | 测试 | 总计 |
|------|------|------|------|------|
| M21 Git同步服务 | 0.5h | 3h | 1h | 4.5h |
| M22 CLI封装 | 0.5h | 2h | 1h | 3.5h |
| M23 状态反馈 | 0.5h | 3h | 1h | 4.5h |
| M24 Dashboard进度 | 0.5h | 2h | 0.5h | 3h |
| M25 问题跟踪同步 | 0.5h | 1.5h | 0.5h | 2.5h |
| M26 项目文档汇总 | 0.5h | 2h | 0.5h | 3h |
| F027-F030 保密功能 | 1h | 3h | 1h | 5h |
| 前端开发 | 0.5h | 2h | 0.5h | 3h |
| 集成测试 | - | - | 2h | 2h |
| **总计** | **4h** | **18.5h** | **8h** | **30.5h** |

---

## 十三、依赖关系

| 模块 | 依赖 |
|------|------|
| M21 Git同步服务 | GitPython |
| M22 CLI封装 | oc-collab v2.3.3 |
| M23 状态反馈 | M22 |
| M24 Dashboard进度 | M22 |
| M25 问题跟踪同步 | M22 |
| M26 项目文档汇总 | M21 |
| F027 项目保密级别 | 现有Project模型 |
| F028 差异化同步 | M21 + F027 |
| F029 自动同步控制 | F027 |
| F030 敏感信息检查 | M21 |

---

## 十四、风险与应对

| 风险 | 可能性 | 影响 | 应对 |
|------|--------|------|------|
| oc-collab v2.3.3未完成 | 中 | 高 | 先实现独立功能(M21)，CLI用mock |
| Git仓库访问权限 | 低 | 高 | 配置正确的仓库路径 |
| 轮询频率控制 | 中 | 中 | 可配置间隔，默认60秒 |
| 敏感信息泄漏 | 低 | 极高 | 严格F030检查流程 |

---

## 十五、签署确认

### Agent 4 创建

| 角色 | 姓名 | 日期 | 确认 |
|------|------|------|------|
| 开发负责人 | Agent 4 | 2026-02-19 | ✅ |

### Agent 1 评审

| 角色 | 姓名 | 日期 | 确认 |
|------|------|------|------|
| 产品负责人 | Agent 1 | 2026-02-19 | ✅ 确认修改 |

---

*文档版本: v2*
*创建日期: 2026-02-19*
*状态: APPROVED*
