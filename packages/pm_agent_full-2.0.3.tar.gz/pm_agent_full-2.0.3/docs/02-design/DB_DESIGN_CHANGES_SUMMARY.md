## 数据库设计修改摘要

### 修改原因

根据Agent4评审意见，补充了以下改进：

---

### 1. 新增字段

| 表 | 新增字段 | 用途 |
|---|---|---|
| processing_logs | `dossierai_response TEXT` | 保存dossierai原始响应，便于调试和追溯 |
| bugs | `oc_git_commit_hash TEXT` | 关联Git提交，追溯oc-collab修复记录 |
| proposals | `oc_git_commit_hash TEXT` | 关联Git提交，追溯oc-collab实现记录 |
| **processing_logs** | **`file_hash TEXT`** | **SHA256哈希值，用于材料去重 (F-013)** |
| **processing_logs** | **`is_duplicate BOOLEAN`** | **标记是否为重复材料 (F-013)** |
| **processing_logs** | **`original_material_id INTEGER`** | **关联原始材料ID，用于去重追溯 (F-013)** |

---

### 2. 新增表

| 表名 | 用途 |
|------|------|
| `operation_logs` | 记录关键操作日志（创建/修改/删除等），便于审计 |
| `templates` | 项目模板配置表，存储模板定义和字段 (F-014) |
| `template_fields` | 模板字段定义表 (F-014) |

**表结构 - templates**：
- project_id: 关联项目ID
- name: 模板名称
- type: 模板类型（庭审记录/会议纪要/需求文档/证据材料）
- prompt: LLM提示词
- is_enabled: 是否启用
- created_at: 创建时间
- updated_at: 更新时间

**表结构 - template_fields**：
- template_id: 关联模板ID
- field_name: 字段名称
- field_type: 字段类型（TEXT/NUMBER/DATE等）
- field_order: 字段顺序

---

### 3. 解决的问题

| 原问题 | 解决方案 |
|--------|----------|
| 与Git数据一致性 | 新增oc_git_commit_hash字段关联 |
| 调试困难 | 新增dossierai_response保存原始响应 |
| 缺少操作记录 | 新增operation_logs表 |
| **重复材料处理** | **新增file_hash、is_duplicate字段 (F-013)** |
| **模板转换** | **新增templates、template_fields表 (F-014)** |
