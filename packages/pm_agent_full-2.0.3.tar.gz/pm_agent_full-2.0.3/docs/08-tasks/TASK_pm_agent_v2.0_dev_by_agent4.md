# PM-Agent v2.0 开发任务单

**任务编号**: TASK-PM-2026-0223-01  
**创建人**: Agent3 (产品经理)  
**日期**: 2026-02-23  
**负责人**: Agent4 (架构师)  
**优先级**: 高  
**状态**: 待开始

---

## 任务背景

PM-Agent v2.0 需求与设计文档已通过评审（commit: fdf3f09f），批准进入开发阶段。

**评审记录**:
- agent1 (产品经理): ✅ 通过
- agent4 (架构师): ✅ 通过
- agent6 (测试控制): ✅ 通过

---

## 开发范围

### F-031: ConfManClient集成

**文件**: `backend/integrations/conf_man_client.py`

**实现要求**:
- [ ] 模块导入方式（不是CLI调用）
- [ ] 支持测试mock注入
- [ ] 实现方法:
  - `get_data_dir()` - 获取数据目录
  - `get_config_dir()` - 获取配置目录
  - `get_log_dir()` - 获取日志目录
  - `get_temp_dir()` - 获取临时目录
  - `get_todo_db_path()` - 获取TODO数据库路径
  - `get_lock_file_path(name)` - 获取锁文件路径
  - `get_environment()` - 获取环境信息
  - `is_test_mode()` - 检查测试模式
- [ ] 异常处理: ConfManError, ConfManNotFoundError, ConfManExecutionError
- [ ] 单元测试: 15个

**工时**: 5h (开发4h + 测试1h)

---

### F-032: VersionClient开发

**文件**: `backend/services/version_service.py`

**实现要求**:
- [ ] CLI封装方式（调用conf-man version命令）
- [ ] 实现方法:
  - `list_versions(project)` - 列出版本
  - `show_version(version)` - 显示版本详情
  - `register_version(version, description, components)` - 登记版本
  - `release_version(version, target)` - 发布版本
  - `get_dependencies(version)` - 获取依赖
  - `create_project(name)` - 创建项目
- [ ] 单元测试: 20个

**工时**: 7h (开发5h + 测试2h)

---

### F-033: 版本信息前端展示（后续开发）

**文件**: `frontend/src/views/VersionView.vue`

**状态**: 待开发（当前标注为"未开始"）

**工时**: 5h (开发3h + 测试2h)

---

## 技术规范

### ConfManClient 实现模板

```python
class ConfManClient:
    """conf-man 配置管理客户端（模块导入方式）"""
    
    def __init__(self, conf_man_module=None):
        """
        Args:
            conf_man_module: 用于测试的mock模块
        """
        self._conf_man = conf_man_module
    
    def _get_conf_man(self):
        if self._conf_man is None:
            import conf_man
            self._conf_man = conf_man
        return self._conf_man
    
    def get_data_dir(self) -> str:
        return self._get_conf_man().path.data()
```

### 测试Mock注入示例

```python
def test_get_data_dir():
    mock_conf_man = Mock()
    mock_conf_man.path.data.return_value = "/data"
    client = ConfManClient(conf_man_module=mock_conf_man)
    assert client.get_data_dir() == "/data"
```

---

## 交付要求

1. **代码实现**: 符合上述技术规范
2. **单元测试**: 覆盖所有方法，达到85%覆盖率
3. **代码质量**: 通过lint检查
4. **文档更新**: 更新实现状态

---

## 里程碑

| 里程碑 | 验收标准 | 截止日期 |
|--------|---------|----------|
| M1: ConfManClient | 15个单元测试通过 | 2026-02-24 |
| M2: VersionClient | 20个单元测试通过 | 2026-02-25 |
| M3: 前端展示 | 页面功能可用 | 2026-02-26 |

---

## 任务确认

| 角色 | 姓名 | 日期 | 确认 |
|------|------|------|------|
| 产品经理 | Agent3 | 2026-02-23 | ✅ |
| 架构师 | Agent4 | 2026-02-23 | ✅ 已完成 |

---

## 开发进度

### F-031 ConfManClient ✅ 已完成

- [x] 模块导入方式
- [x] 支持测试mock注入
- [x] 异常类: ConfManError, ConfManNotFoundError, ConfManExecutionError
- [x] 单元测试: 15个

### F-032 VersionClient ✅ 已实现

- [x] CLI封装方式
- [x] 单元测试: 20个

### F-033 前端展示 ⏳ 待开发

- [ ] 后续开发

### 交付产出

- commit: 33487cea
- 测试文件: tests/test_conf_man_client.py (15用例)
- 测试文件: tests/test_version_client.py (20用例)
- 异常类: conf_man_client.py 新增3个异常类
