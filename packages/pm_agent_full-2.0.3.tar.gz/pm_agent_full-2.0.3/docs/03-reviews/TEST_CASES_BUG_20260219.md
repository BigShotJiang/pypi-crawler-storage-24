# BUG回归测试用例

## BUG-20260219-002: 字段名不匹配导致转写内容不显示

### 测试用例

#### TC-002-01: 材料列表显示转写内容

**测试步骤**：
1. 访问材料列表页面 `/materials`
2. 查找"转写/OCR内容"列
3. 验证列中显示转写内容（前50字）

**预期结果**：
- 转写/OCR内容列应显示文本，如"他天生就有这个..."

**验证方式**：
```python
# 检查表格中是否有转写内容
cell = page.locator("td:has-text('他天生')").first
assert cell.is_visible()
```

---

#### TC-002-02: 首页材料卡片显示转写预览

**测试步骤**：
1. 访问首页 `/`
2. 查找材料卡片
3. 验证卡片中显示转写内容预览

**预期结果**：
- 材料卡片应显示转写内容前100字

---

## BUG-20260219-003: 材料详情页不显示转写内容

### 测试用例

#### TC-003-01: 材料详情页显示原始材料转写内容

**测试步骤**：
1. 访问材料列表页面 `/materials`
2. 点击任意材料的"查看"按钮
3. 进入材料详情页 `/materials/{id}`
4. 查找"原始材料"卡片
5. 验证其中显示转写内容

**预期结果**：
- "原始材料"卡片中应显示完整的转写内容
- 内容应为音频/图片的OCR或转写结果

**验证方式**：
```python
# 检查详情页是否有转写内容
content = page.locator(".nc-card:has-text('原始材料') pre").inner_text()
assert len(content) > 0
assert "他天生就有" in content
```

---

#### TC-003-02: 材料详情页显示转写/OCR结果卡片

**测试步骤**：
1. 访问材料详情页
2. 查找"转写/OCR结果"卡片
3. 验证卡片中显示转写内容

**预期结果**：
- "转写/OCR结果"卡片中应显示转写内容
- 或显示"请点击处理按钮进行转写/OCR"（如未处理）

---

#### TC-003-03: 有转写内容时按钮可用

**测试步骤**：
1. 访问材料详情页（已有转写内容的材料）
2. 验证"处理"、"生成BUG"、"生成Proposal"按钮可用

**预期结果**：
- 按钮应可用（不处于disabled状态）

**验证方式**：
```python
# 检查按钮是否可用
convert_btn = page.locator("button:has-text('处理')")
assert not convert_btn.is_disabled()
```

---

## 测试数据准备

### 需要的测试数据

| 数据 | 说明 |
|------|------|
| 材料A | 音频文件，已完成转写（有raw_content） |
| 材料B | 文档文件，已完成OCR（有raw_content） |
| 材料C | 图片文件，已完成OCR（有raw_content） |

### 获取测试材料ID

```bash
# 查询已有转写内容的材料
curl http://localhost:8000/api/materials | jq '.items[] | select(.raw_content != null) | {id, file_name, file_type}'
```

---

## 运行测试

```bash
cd frontend
python3 tests/test_bug_regression.py
```

---

*测试用例版本: v1*
*创建日期: 2026-02-19*
