# PM-Agent Agents 配置

## Agent编号与角色

| Agent编号 | 角色 | 说明 |
|-----------|------|------|
| agent3 | 产品经理 | PM-Agent产品经理，负责需求管理 |
| agent4 | 架构师 | PM-Agent架构师，负责技术设计 |

## 角色定义

### 产品经理 (Product Manager)

**职责**：
- 接收客户材料，识别问题
- 分类：BUG / 需求 / 会议
- 创建需求文档
- 与oc-collab协作，下发任务

**使用的Skill**：
- 信息分类Skill
- 需求文档生成Skill
- BUG报告生成Skill

### 架构师 (Architect)

**职责**：
- 技术方案设计
- 评审需求可行性
- 与oc-collab对接

**使用的Skill**：
- 技术方案Skill
- 架构设计Skill

## Agent管理

- **Agent编号**：用于oc-collab TODO路由（agent3, agent4）
- **角色**：用于Skill匹配和行为定义
- **团队**：pm-agent

## 与oc-collab协同

| PM-Agent Agent | oc-collab Agent | 交互 |
|---------------|-----------------|------|
| agent3 (产品经理) | agent1 (产品经理) | 下发需求 |
| agent4 (架构师) | agent2 (开发) | 技术评审 |
