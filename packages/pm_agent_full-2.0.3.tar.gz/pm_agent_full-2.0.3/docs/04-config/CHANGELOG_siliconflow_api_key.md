# PM-Agent 配置变更记录

**变更日期**: 2026-02-23
**变更人**: agent3 (产品经理)
**用途**: 提交给conf-man做配置管理

---

## 变更概述

将硬编码的敏感配置改为环境变量引用，消除安全风险。

---

## 变更详情

### 1. SiliconFlow API Key

| 项目 | 变更前 | 变更后 |
|------|--------|--------|
| 配置文件 | `pm-agent/config/settings.yaml` | 同上 |
| 配置文件 | `pm-agent/backend/config/settings.yaml` | 同上 |
| 配置路径 | `siliconflow.api_key` | 同上 |
| 变更内容 | `sk-fjephnssumhgkxhakpxlfrqayiuckkyogvwkchqutqolqilk` | `${SILICONFLOW_API_KEY}` |

### 2. Webhook Secret (GitHub)

| 项目 | 变更前 | 变更后 |
|------|--------|--------|
| 配置文件 | `pm-agent/config/webhook.yaml` | 同上 |
| 配置路径 | `webhook.github.secret` | 同上 |
| 变更内容 | `d549e1f619f376e90d1bcc7d6865c9e2fd4413345a768db172e47f324064c194` | `${WEBHOOK_GITHUB_SECRET}` |

### 3. Webhook Secret (Gitee)

| 项目 | 变更前 | 变更后 |
|------|--------|--------|
| 配置文件 | `pm-agent/config/webhook.yaml` | 同上 |
| 配置路径 | `webhook.gitee.secret` | 同上 |
| 变更内容 | `e4f8c0db79ac0210ee77bbf56a237981aa82a8c864be8edf46d5a3d66198ca87` | `${WEBHOOK_GITEE_SECRET}` |

---

## 环境变量清单

| 变量名 | 说明 | 必需 |
|--------|------|------|
| `SILICONFLOW_API_KEY` | SiliconFlow API Key | 是 |
| `OPENAI_API_KEY` | OpenAI API Key | 是 |
| `WEBHOOK_GITHUB_SECRET` | GitHub Webhook Secret | 是 |
| `WEBHOOK_GITEE_SECRET` | Gitee Webhook Secret | 是 |

---

## Git提交

- **提交ID**: `acfddd80` (SiliconFlow API Key)
- **提交ID**: `[新提交]` (Webhook Secret)
