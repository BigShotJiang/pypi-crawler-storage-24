# BUG报告

## 基本信息
- **ID**: BUG-20260219-001
- **标题**: 转写内容不在材料列表/首页显示
- **严重程度**: P1
- **项目**: PM-Agent
- **模块**: 前端显示
- **创建时间**: 2026-02-19

---

## 问题描述

转写内容已存储在后端API中（raw_content字段，14417字符），但前端首页和材料列表不显示转写内容预览。

---

## 复现步骤

1. 上传音频文件（如.m4a）
2. 系统自动进行语音转写（已有数据）
3. 查看首页材料列表 → 转写内容列不显示
4. 查看材料列表页面 → 转写/OCR内容列不显示

---

## 预期行为

- 首页材料卡片应显示转写内容预览
- 材料列表表格应显示转写/OCR内容（前50字）
- 材料详情页显示完整转写内容

---

## 实际行为

- 首页材料卡片不显示rawContent预览
- 材料列表表格缺少"转写/OCR内容"列（或数据为空）
- 材料详情页应正常显示

---

## 数据验证

```bash
# API确认有数据
curl http://localhost:8000/api/materials | jq '.[0].raw_content'
# 返回: "他天生就有这个能力..." (14417字符)
```

---

## 根因分析

前端代码问题：
1. `HomeView.vue` - 可能未正确获取/显示rawContent
2. `MaterialsView.vue` - 表格列定义可能有问题

---

## 修复建议

1. 检查HomeView.vue中getPreviewText函数调用
2. 检查MaterialsView.vue表格列定义
3. 确保API返回的rawContent正确映射到前端字段

---

## 相关文件

- `frontend/src/views/HomeView.vue`
- `frontend/src/views/MaterialsView.vue`
- `frontend/src/views/MaterialDetailView.vue` (参考实现)

---

## 验收标准

- [ ] 首页材料卡片显示转写内容预览（前50字）
- [ ] 材料列表表格显示转写/OCR内容列
- [ ] 点击材料可查看完整转写内容

---

*由PM-Agent自动生成*
