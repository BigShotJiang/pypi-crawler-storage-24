# BUG报告

## 基本信息
- **ID**: BUG-20260219-009
- **标题**: 材料详情页缺少路由历史记录显示
- **严重程度**: P3
- **项目**: PM-Agent
- **模块**: 前端-材料详情
- **创建时间**: 2026-02-19

---

## 问题描述

E2E测试用例TC-F005-02（路由历史记录）失败，错误：材料详情页未找到"路由历史"元素。

---

## 失败的测试用例

| 测试用例 | 失败原因 |
|----------|----------|
| TC-F005-02 | `getByText('路由历史')` 未找到 |

---

## 根因分析

材料详情页`MaterialsDetailView.vue`未实现路由历史记录显示功能。

---

## 修复方案

在材料详情页添加路由历史记录展示区域：
```vue
<template>
  <div class="routing-history">
    <n-card title="路由历史">
      <n-timeline>
        <n-timeline-item 
          v-for="record in routingHistory" 
          :key="record.id"
          :type="record.type"
          :title="record.action"
          :time="record.timestamp"
        />
      </n-timeline>
    </n-card>
  </div>
</template>
```

路由历史应记录：
1. 材料上传时间
2. 客户匹配时间
3. 项目匹配时间
4. 路由目标目录
5. Git推送记录（如有）

---

## 验收标准

- [ ] 材料详情页显示路由历史
- [ ] 记录包含时间戳和操作描述
- [ ] 至少显示初始上传记录

---

## 相关测试用例

- TC-F005-02: 路由历史记录

---

*由PM-Agent测试生成*
