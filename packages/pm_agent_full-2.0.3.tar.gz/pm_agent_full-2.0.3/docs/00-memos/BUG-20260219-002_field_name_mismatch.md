# BUG报告

## 基本信息
- **ID**: BUG-20260219-002
- **标题**: API字段名与前端不匹配导致转写内容不显示
- **严重程度**: P1
- **项目**: PM-Agent
- **模块**: 前端/API
- **创建时间**: 2026-02-19

---

## 问题描述

API返回的字段名使用snake_case（如`raw_content`），但前端使用camelCase（如`rawContent`），导致转写内容无法显示。

---

## 根因分析

### API返回字段（snake_case）
```
raw_content, file_name, file_type, project_id, created_at, ...
```

### 前端期望字段（camelCase）
```
rawContent, fileName, fileType, projectId, createdAt, ...
```

---

## 受影响的字段

| API字段 | 前端字段 | 影响 |
|---------|----------|------|
| raw_content | rawContent | 转写内容不显示 |
| file_name | fileName | 文件名显示异常 |
| file_type | fileType | 文件类型显示异常 |
| project_id | projectId | 项目ID异常 |
| created_at | createdAt | 时间显示异常 |
| is_duplicate | isDuplicate | 去重状态异常 |
| issue_type | issueType | 问题类型异常 |
| issue_id | issueId | 问题ID异常 |

---

## 修复方案

### 方案A：后端修改
修改API返回字段名为camelCase（推荐）

### 方案B：前端修改
修改前端使用snake_case字段名

### 方案C：前端适配
在API调用处做字段映射

---

## 验收标准

- [ ] 材料详情页显示完整转写内容
- [ ] 材料列表显示转写/OCR内容
- [ ] 所有字段正确显示

---

*由PM-Agent自动生成*
