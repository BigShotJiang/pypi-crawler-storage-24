# BUG报告

## 基本信息
- **ID**: BUG-20260224-001
- **标题**: conf-man CLI无法导入main模块
- **严重程度**: P0
- **项目**: conf-man
- **模块**: CLI
- **创建时间**: 2026-02-24
- **报告人**: agent3 (pm-agent)

---

## 问题描述

执行`conf-man register`命令时报错：
```
ImportError: cannot import name 'main' from 'src.__init__'
(/Users/liuzhen/Library/Python/3.9/lib/python/site-packages/src/__init__.py)
```

---

## 复现步骤

1. 在任意目录执行`conf-man register v1.3.0 --manifest <file>`
2. 报错ImportError

---

## 预期行为

conf-man CLI应正常执行，支持register、secret等命令

---

## 实际行为

报错ImportError，无法执行任何conf-man命令

---

## 影响范围

- 无法登记版本
- 无法管理secrets
- 阻塞pm-agent v1.3.0发布流程

---

## 环境信息

- Python: 3.9
- conf-man: v1.3.0 (代码已更新)
- 系统: macOS

---

## 初步分析

问题可能是：
1. pip安装的conf-man版本过旧
2. 本地安装的conf-man与源码版本不一致
3. CLI入口点配置错误

---

## 建议

1. 检查pip安装的conf-man版本
2. 确认CLI入口点配置
3. 重新安装或更新conf-man
