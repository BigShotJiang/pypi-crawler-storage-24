# BUG报告

## 基本信息
- **ID**: BUG-20260219-004
- **标题**: E2E测试无法通过标准input元素上传文件
- **严重程度**: P2
- **项目**: PM-Agent
- **模块**: 前端-文件上传
- **创建时间**: 2026-02-19

---

## 问题描述

E2E测试用例TC-F001-01/02/03（图片/音频/文档上传）失败，错误信息：`TypeError: uploadInput.setInputFiles is not a function`

前端使用拖拽上传区域，未包含标准的`<input type="file">`元素，导致Playwright无法通过`setInputFiles`方法上传文件。

---

## 根因分析

前端Upload组件未包含标准的文件输入元素：
```html
<!-- 当前实现 -->
<div class="upload-area">
  <!-- 无input[type="file"]元素 -->
  <div class="drop-zone">拖拽文件到此处</div>
</div>
```

Playwright的`setInputFiles`方法需要标准的input元素才能工作。

---

## 测试日志

```
TypeError: uploadInput.setInputFiles is not a function

  9 |     test('TC-F001-01: 图片上传', async ({ page }) => {
 10 |       const uploadInput = page.locator('input[type="file"]').first;
> 11 |       await uploadInput.setInputFiles('tests/fixtures/test.png');
```

---

## 修复方案

### 方案A：在上传组件中添加隐藏的input元素（推荐）
```vue
<template>
  <div class="upload-area" @drop="handleDrop" @click="triggerInput">
    <input 
      type="file" 
      ref="fileInput" 
      style="display: none" 
      @change="handleFileSelect"
      accept="image/*,audio/*,.pdf,.docx"
      multiple
    />
    <div class="drop-zone">拖拽文件到此处</div>
  </div>
</template>
```

### 方案B：使用Playwright拖拽API
```typescript
await page.dragAndDrop('tests/fixtures/test.pdf', '.drop-zone');
```

---

## 验收标准

- [ ] E2E测试可以通过标准input元素上传文件
- [ ] 支持图片、音频、文档多种格式上传
- [ ] 上传后材料出现在材料列表中

---

## 相关测试用例

- TC-F001-01: 图片上传
- TC-F001-02: 音频上传
- TC-F001-03: 文档上传
- TC-F013-01: 重复文件检测

---

*由PM-Agent测试生成*
