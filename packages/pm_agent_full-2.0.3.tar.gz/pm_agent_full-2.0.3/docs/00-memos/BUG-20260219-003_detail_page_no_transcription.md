# BUG报告

## 基本信息
- **ID**: BUG-20260219-003
- **标题**: 材料详情页不显示转写内容
- **严重程度**: P1
- **项目**: PM-Agent
- **模块**: 前端/后端API
- **创建时间**: 2026-02-19

---

## 问题描述

材料详情页不显示转写内容，但API已返回raw_content数据。

---

## 根因分析

### 1. 后端API返回格式

`backend/api/routes/materials.py` 的 `model_to_dict` 函数已同时返回两种格式：

```python
"rawContent": raw_content,    # camelCase
"raw_content": raw_content,    # snake_case
```

API同时返回了两个字段名的数据。

### 2. 前端期望字段

`MaterialDetailView.vue` 使用 `material.rawContent`（camelCase）

### 3. 问题定位

根据API调试：
```bash
# API返回字段: raw_content = "他天生就有这个能力..."
curl http://localhost:8000/api/materials/{id}
# 返回: {"raw_content": "...", "rawContent": "..."}
```

但详情页显示为空，说明前端获取或渲染有问题。

### 4. 可能原因

| 可能原因 | 说明 |
|----------|------|
| A | 前端API调用未正确获取数据 |
| B | 前端字段映射问题 |
| C | 详情页加载逻辑问题 |

---

## 待开发排查

开发需要排查：

1. **检查前端API调用**：MaterialDetailView.vue 的 `loadMaterial()` 函数是否正确调用API
2. **检查数据绑定**：API返回的rawContent是否正确赋值给material变量
3. **检查渲染逻辑**：v-if/v-show条件是否正确

---

## 修复建议

1. 在MaterialDetailView.vue的loadMaterial函数中添加console.log调试
2. 检查material.rawContent是否有值
3. 对比材料列表页(MaterialsView.vue)的实现，看为何那里能显示

---

## 验收标准

- [ ] 材料详情页显示完整转写内容

---

*由PM-Agent调查后撰写*
