# PM-Agent v1.3.0 发布记录

**版本**: v1.3.0
**发布日期**: 2026-02-24
**状态**: 已发布

---

## 发布概述

本版本主要完成conf-man secrets集成，消除配置文件中的敏感信息。

---

## 变更内容

### 新增功能

| 功能 | 说明 |
|------|------|
| ConfManClient | 封装conf-man CLI调用 |
| VersionClient | 封装版本管理功能 |
| SecretClient | 通过conf-man获取加密密钥 |
| 版本信息前端展示 | 前端版本信息页面 |

### 代码修复

| 问题 | 说明 |
|------|------|
| BaseModel未导入 | sync.py中添加pydantic导入 |
| 路径硬编码 | conf_man_client.py支持CONF_MAN_PATH环境变量 |
| 硬编码API Key | 移除SiliconFlow API Key硬编码 |
| 硬编码Webhook Secret | 移除GitHub/Gitee Webhook Secret硬编码 |

---

## 技术变更

### 配置管理

| 配置项 | 变更前 | 变更后 |
|--------|--------|--------|
| SiliconFlow API Key | 硬编码 | `${SILICONFLOW_API_KEY}` 或 conf-man secret |
| OpenAI API Key | 环境变量 | 环境变量 或 conf-man secret |
| Webhook Secret | 硬编码 | 环境变量 或 conf-man secret |

---

## 发布清单

| 类型 | 产物 | 状态 |
|------|------|------|
| Python包 | pm-agent-1.3.0.tar.gz | ✅ |
| Git标签 | v1.3.0 | ✅ |
| PyPI | - | ⏳ 待发布 |
| npm | - | ⏳ 待发布 |

---

## 依赖版本

| 组件 | 版本 |
|------|------|
| Python | >=3.10 |
| FastAPI | >=0.109.0 |
| conf-man | >=1.3.0 |

---

## 升级指南

1. 更新pm-agent到v1.3.0
2. 配置conf-man secrets或设置环境变量：
   - `SILICONFLOW_API_KEY`
   - `OPENAI_API_KEY`
3. 启动服务

---

## 相关文档

- CHANGELOG: `CHANGELOG.md`
- 任务报告: `docs/05-tasks/REPORT_pm-agent_integrate_confman_secrets.md`
