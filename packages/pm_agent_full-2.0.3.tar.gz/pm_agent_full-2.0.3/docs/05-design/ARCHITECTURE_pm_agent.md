# PM-Agent 核心架构

**版本**: v1.0  
**日期**: 2026-02-18

---

## 一、系统架构

```
PM-Agent
    │
    ├── API层 (FastAPI)
    │   ├── 客户管理 API
    │   ├── 项目管理 API
    │   ├── 材料处理 API
    │   └── Webhook接收
    │
    ├── Service层
    │   ├── CustomerService
    │   ├── ProjectService
    │   ├── MaterialService
    │   └── ...
    │
    ├── 数据层 (SQLite)
    │   ├── customers
    │   ├── projects
    │   ├── materials
    │   └── ...
    │
    └── 集成层
        ├── oc-collab CLI调用
        ├── 文件系统操作
        └── Gitee API
```

---

## 二、核心模块

| 模块 | 说明 |
|------|------|
| 客户管理 | 客户CRUD、关键词匹配 |
| 项目管理 | 项目CRUD、仓库关联 |
| 材料处理 | 文件上传、OCR处理、识别 |
| 文件同步 | 本地保存、手动/自动同步 |
| Agent管理 | 启动/停止（下一期） |

---

## 三、数据模型

### 客户表 (customers)

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Integer | 主键 |
| name | String | 客户名称 |
| keywords | Text | 关键词 |
| git_repo | String | Git仓库 |
| contact | String | 联系人 |
| status | String | 状态 |

### 项目表 (projects)

| 字段 | 类型 | 说明 |
|------|------|------|
| id | Integer | 主键 |
| customer_id | Integer | 外键 |
| name | String | 项目名称 |
| keywords | Text | 关键词 |
| status | String | 状态 |
| git_repo | String | 仓库(JSON数组) |

---

## 四、相关文档

- 需求设计: 由产品经理负责
- oc-collab集成: 参考 `../dual-agent-collaboration-system/docs/06-roadmap/ROADMAP_sync_development.md`
