"""
回归测试 - PM-Agent v2.0 核心模块
验证v2.0更新不影响现有功能
"""
import pytest
import sys
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))


class TestLLMServiceRegression:
    """回归测试: LLM服务"""

    def test_llm_client_import(self):
        """RT-002: 测试LLM客户端可导入"""
        from backend.integrations.siliconflow_client import SiliconFlowClient
        assert SiliconFlowClient is not None


class TestDocumentFetcherRegression:
    """回归测试: 文档获取服务"""

    def test_document_fetcher_import(self):
        """RT-004: 测试文档获取器可导入"""
        from backend.services.document_fetcher import DocumentFetcher
        assert DocumentFetcher is not None


class TestProcessingLogRegression:
    """回归测试: 处理日志服务"""

    def test_processing_log_import(self):
        """RT-005: 测试处理日志可导入"""
        from backend.services.processing_log_service import ProcessingLogService
        assert ProcessingLogService is not None


class TestBugGeneratorRegression:
    """回归测试: Bug生成服务"""

    def test_bug_generator_import(self):
        """RT-006: 测试Bug生成器可导入"""
        from backend.services.bug_generator_service import BugGeneratorService
        assert BugGeneratorService is not None


class TestProposalGeneratorRegression:
    """回归测试: 提案生成服务"""

    def test_proposal_generator_import(self):
        """RT-007: 测试提案生成器可导入"""
        from backend.services.proposal_generator_service import ProposalGeneratorService
        assert ProposalGeneratorService is not None


class TestConfidentialCheckerRegression:
    """回归测试: 机密检查服务"""

    def test_confidential_checker_import(self):
        """RT-008: 测试机密检查器可导入"""
        from backend.services.confidential_checker import SensitiveContentChecker as Checker
        assert Checker is not None


class TestInputHandlerRegression:
    """回归测试: 输入处理服务"""

    def test_input_handler_import(self):
        """RT-009: 测试输入处理器可导入"""
        from backend.services.input_handler import InputHandler
        assert InputHandler is not None


class TestClassifierServiceRegression:
    """回归测试: 分类服务"""

    def test_classifier_service_import(self):
        """RT-010: 测试分类服务可导入"""
        from backend.services.classifier_service import ClassifierService
        assert ClassifierService is not None


class TestGitSyncServiceRegression:
    """回归测试: Git同步服务"""

    def test_git_sync_service_import(self):
        """RT-011: 测试Git同步服务可导入"""
        from backend.services.git_sync_service import GitSyncService
        assert GitSyncService is not None


class TestSyncPermissionServiceRegression:
    """回归测试: 同步权限服务"""

    def test_sync_permission_service_import(self):
        """RT-012: 测试同步权限服务可导入"""
        from backend.services.sync_permission_service import SyncPermissionService
        assert SyncPermissionService is not None


class TestStatusFeedbackServiceRegression:
    """回归测试: 状态反馈服务"""

    def test_status_feedback_service_import(self):
        """RT-013: 测试状态反馈服务可导入"""
        from backend.services.status_feedback_service import StatusFeedbackService
        assert StatusFeedbackService is not None


class TestIssueSyncServiceRegression:
    """回归测试: 问题同步服务"""

    def test_issue_sync_service_import(self):
        """RT-014: 测试问题同步服务可导入"""
        from backend.services.issue_sync_service import IssueSyncService
        assert IssueSyncService is not None


class TestGitServiceRegression:
    """回归测试: Git服务"""

    def test_git_service_import(self):
        """RT-015: 测试Git服务可导入"""
        from backend.services.git_service import GitService
        assert GitService is not None


class TestCustomerServiceRegression:
    """回归测试: 客户服务"""

    def test_customer_service_import(self):
        """RT-016: 测试客户服务可导入"""
        from backend.services.customer_service import CustomerService
        assert CustomerService is not None


class TestProgressServiceRegression:
    """回归测试: 进度服务"""

    def test_progress_service_import(self):
        """RT-017: 测试进度服务可导入"""
        from backend.services.progress_service import ProgressService
        assert ProgressService is not None


class TestProjectServiceRegression:
    """回归测试: 项目服务"""

    def test_project_service_import(self):
        """RT-018: 测试项目服务可导入"""
        from backend.services.project_service import ProjectService
        assert ProjectService is not None


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
