"""
ConfManClient 单元测试
PM-Agent v2.0 - F-031

测试用例: 15个
"""
import pytest
import sys
from pathlib import Path
from unittest.mock import Mock, patch, MagicMock

sys.path.insert(0, str(Path(__file__).parent.parent / "backend"))


@pytest.fixture(autouse=True)
def reset_classes():
    """重置conf_man类"""
    from backend.integrations.conf_man_client import _set_conf_man_classes
    _set_conf_man_classes(None, None)
    yield
    _set_conf_man_classes(None, None)


class TestConfManClientInit:
    """测试ConfManClient初始化"""

    def test_init_with_mock_provider(self):
        """TC-001: 测试使用mock类初始化"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_class = Mock()
        mock_provider_class.return_value = Mock()
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        assert client._provider is not None
        assert client._env_config is not None

    def test_init_without_provider(self):
        """TC-002: 测试无provider时初始化"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        _set_conf_man_classes(None, None)
        
        with patch('builtins.__import__', side_effect=ImportError("Mock error")):
            client = ConfManClient()
            assert client._provider is None

    def test_lazy_load_module(self):
        """TC-003: 测试延迟加载模块"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_class = Mock()
        mock_provider_class.return_value = Mock()
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        assert client._provider is not None

    def test_mock_module_injection(self):
        """TC-004: 测试mock模块注入"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_class = Mock()
        mock_provider_instance = Mock()
        mock_provider_instance.get_data_dir.return_value = "/data"
        mock_provider_class.return_value = mock_provider_instance
        
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        assert client.is_available() is True


class TestConfManClientPaths:
    """测试路径获取方法"""

    def test_get_data_dir_success(self):
        """TC-005: 测试获取数据目录成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_instance = Mock()
        mock_provider_instance.get_data_dir.return_value = "/data"
        mock_provider_class = Mock()
        mock_provider_class.return_value = mock_provider_instance
        
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.get_data_dir()
        assert result == "/data"

    def test_get_config_dir_success(self):
        """TC-006: 测试获取配置目录成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_instance = Mock()
        mock_provider_instance.get_config_dir.return_value = "/config"
        mock_provider_class = Mock()
        mock_provider_class.return_value = mock_provider_instance
        
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.get_config_dir()
        assert result == "/config"

    def test_get_log_dir_success(self):
        """TC-007: 测试获取日志目录成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_instance = Mock()
        mock_provider_instance.get_log_dir.return_value = "/log"
        mock_provider_class = Mock()
        mock_provider_class.return_value = mock_provider_instance
        
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.get_log_dir()
        assert result == "/log"

    def test_get_temp_dir_success(self):
        """TC-008: 测试获取临时目录成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_instance = Mock()
        mock_provider_instance.get_temp_dir.return_value = "/temp"
        mock_provider_class = Mock()
        mock_provider_class.return_value = mock_provider_instance
        
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.get_temp_dir()
        assert result == "/temp"

    def test_get_todo_db_path_success(self):
        """TC-009: 测试获取TODO数据库路径成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_instance = Mock()
        mock_provider_instance.get_todo_db_path.return_value = "/data/todos.db"
        mock_provider_class = Mock()
        mock_provider_class.return_value = mock_provider_instance
        
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.get_todo_db_path()
        assert result == "/data/todos.db"

    def test_get_lock_file_path_success(self):
        """TC-010: 测试获取锁文件路径成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_instance = Mock()
        mock_provider_instance.get_lock_file_path.return_value = "/locks/test.lock"
        mock_provider_class = Mock()
        mock_provider_class.return_value = mock_provider_instance
        
        mock_env_class = Mock()
        mock_env_class.return_value = Mock()
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.get_lock_file_path("test")
        assert result == "/locks/test.lock"


class TestConfManClientEnvironment:
    """测试环境查询方法"""

    def test_get_environment_success(self):
        """TC-011: 测试获取环境信息成功"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_class = Mock()
        mock_provider_class.return_value = Mock()
        
        mock_env_instance = Mock()
        mock_env_instance.get_environment.return_value = "production"
        mock_env_class = Mock()
        mock_env_class.return_value = mock_env_instance
        
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.get_environment()
        assert result == "production"

    def test_is_test_mode_true(self):
        """TC-012: 测试测试模式启用"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_class = Mock()
        mock_provider_class.return_value = Mock()
        
        mock_env_instance = Mock()
        mock_env_instance.is_test_mode.return_value = True
        mock_env_class = Mock()
        mock_env_class.return_value = mock_env_instance
        
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.is_test_mode()
        assert result is True

    def test_is_test_mode_false(self):
        """TC-013: 测试测试模式未启用"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes
        
        mock_provider_class = Mock()
        mock_provider_class.return_value = Mock()
        
        mock_env_instance = Mock()
        mock_env_instance.is_test_mode.return_value = False
        mock_env_class = Mock()
        mock_env_class.return_value = mock_env_instance
        
        _set_conf_man_classes(mock_provider_class, mock_env_class)
        
        client = ConfManClient()
        result = client.is_test_mode()
        assert result is False


class TestConfManClientErrors:
    """测试错误处理"""

    def test_module_not_found(self):
        """TC-014: 测试模块未找到异常"""
        from backend.integrations.conf_man_client import ConfManClient, ConfManError
        
        with patch('builtins.__import__', side_effect=ImportError("Module not found")):
            client = ConfManClient()
            with pytest.raises((ImportError, ConfManError)):
                client.get_data_dir()

    def test_check_available_raises(self):
        """TC-015: 测试_check_available抛出异常"""
        from backend.integrations.conf_man_client import ConfManClient, _set_conf_man_classes, _conf_man_provider_class, _conf_man_env_class
        import backend.integrations.conf_man_client as client_module
        
        client_module._conf_man_provider_class = None
        client_module._conf_man_env_class = None
        
        client = ConfManClient()
        client._provider = None
        
        with pytest.raises(ImportError, match="conf-man not available"):
            client._check_available()


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
