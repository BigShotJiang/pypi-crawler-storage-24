import uuid
from datetime import datetime
from typing import Optional, Union

import traewelling_pydantic.models as traewelling
from requests.exceptions import HTTPError
from requests.status_codes import codes as httpCode
from pydantic_extra_types.coordinate import Latitude, Longitude

from . import api


class TraewellingClient:
    """
    Traewelling Client object to manage the token

    Behavior Note: 404s will return None
    """

    def __init__(self, token: str):
        self.token = token

    def get_stations(
        self,
        identifier_provider: Optional[str] = None,
        query: Optional[str] = None,
        identifier: Optional[str] = None,
        min_lat: Optional[Latitude] = None,
        max_lat: Optional[Latitude] = None,
        min_lon: Optional[Longitude] = None,
        max_lon: Optional[Longitude] = None,
        limit: int = 50,
        with_identifiers: bool = False,
    ) -> Optional[list[traewelling.Station]]:
        try:
            return api.checkin.get_stations(
                self.token,
                identifier=identifier,
                identifier_provider=identifier_provider,
                min_lat=min_lat,
                max_lat=max_lat,
                min_lon=min_lon,
                max_lon=max_lon,
                limit=limit,
                with_identifiers=with_identifiers,
                query=query
            )
        except HTTPError as error:
            if error.response.status_code == httpCode.not_found:
                return None
            raise error

    def get_station_by_id(
        self,
        station_id: Union[int, uuid.UUID],
        with_identifiers: bool = False,
    ) -> Optional[traewelling.Station]:
        """
        This request returns a single station object

        :param station_id: Either the traewelling integer ID or UUID
        :type station_id: int, uuid.UUID

        :param with_identifiers: If further identifiers should be requested from Traewelling
        :type with_identifiers: bool

        :raises HTTPError: Might raise a 401, 403, or 5xx error

        :return: Either returns a Station object or in case of a 404 returns None
        :rtype: Station(optional)
        """
        try:
            return api.checkin.get_stations_by_id(
                self.token, station_id=station_id, with_identifiers=with_identifiers
            )
        except HTTPError as error:
            if error.response.status_code == httpCode.not_found:
                return None
            raise error

    def get_operators(self) -> list[traewelling.Operator]:
        """
        Get a list of 'all' operators.

        :raises HTTPError: Might raise a 401, 403, or 5xx error

        :return: Returns a list of Operator objects
        :rtype: list[Operator]
        """

        return api.checkin.get_operators(self.token)

    def get_event(self, slug: str) -> Optional[traewelling.Event]:
        """
        Get basic information for event

        :param slug: A slug for an event
        :type slug: str

        :raises HTTPError: Might raise a 401, 403, or 5xx error

        :return: Either returns an Event object or in case of a 404 returns None
        :rtype: Event(optional)
        """
        try:
            return api.events.get_event(self.token, slug=slug)
        except HTTPError as error:
            if error.response.status_code == httpCode.not_found:
                return None
            raise error

    def get_events(
        self, timestamp: datetime, only_upcoming: bool = False
    ) -> list[traewelling.Event]:
        """
        Returns all active or upcoming events for the given timestamp. Default timestamp is now. If upcoming is set to true, all events ending after the timestamp are returned.

        :raises HTTPError: Might raise a 401, 403, or 5xx error

        :return: Returns a list of Event objects
        :rtype: list[Event]
        """
        return api.events.get_events(
            self.token, timestamp=timestamp, only_upcoming=only_upcoming
        )
