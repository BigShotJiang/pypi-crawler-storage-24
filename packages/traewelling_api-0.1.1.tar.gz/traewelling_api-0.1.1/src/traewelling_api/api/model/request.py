import traewelling_pydantic as trwl
from typing import Optional, Union
import uuid
import pydantic

from datetime import datetime


class TraewellingRequestModel(trwl.models.TraewellingModel):
    pass


class UpdateProfileInformationRequest(TraewellingRequestModel):
    username: str
    displayName: str
    privateProfile: Optional[bool] = None
    preventIndex: Optional[bool] = None
    privacyHideDays: Optional[int] = None
    defaultStatusVisibility: Optional[trwl.enums.Visibility] = None
    mastodonVisibility: Optional[trwl.enums.MastodonVisibility] = None
    mapProvider: Optional[trwl.enums.MapProvider] = None
    friendCheckin: Optional[trwl.enums.FriendCheckinSetting] = None
    pointsEnabled: Optional[bool] = None
    bio: Optional[str] = None
    experimental: bool
    profileLinks: Optional[list[trwl.models.ProfileLink]] = None
    timezone: str


class CheckinRequest(TraewellingRequestModel):
    body: str
    business: trwl.enums.Business
    visibility: trwl.enums.Visibility
    eventId: int
    toot: bool
    chainPost: bool
    ibnr: bool
    tripId: str
    lineName: str
    start: int
    destination: int
    departure: datetime
    arrival: datetime
    force: bool
    with_: list[Union[int, uuid.UUID]] = pydantic.Field(alias="with")


class EventSuggestionRequest(TraewellingRequestModel):
    name: str
    host: str
    begin: datetime
    end: datetime
    url: Optional[str] = None
    hashtag: Optional[str] = None
    nearestStationId: Optional[int] = None


class ICSTokenRequest(TraewellingRequestModel):
    name: str


class ICSTokenDeleteRequest(TraewellingRequestModel):
    tokenId: int


class PolylineRequest(TraewellingRequestModel):
    from_station_id: int
    to_station_id: int
    stopover_id: int


class ReportRequest(TraewellingRequestModel):
    subjectType: str
    subjectId: int
    reason: str
    description: str


class UpdateEmailRequest(TraewellingRequestModel):
    email: str
    password: str


class AccountDeletionRequest(TraewellingRequestModel):
    confirmation: str


class UpdateStatusRequest(TraewellingRequestModel):
    body: Optional[str] = None
    business: Optional[trwl.enums.Business] = None
    visibility: Optional[trwl.enums.Visibility] = None
    eventId: Optional[str] = None
    manualDeparture: Optional[datetime] = None
    manualArrival: Optional[datetime] = None
    destinationId: Optional[str] = None
    destinationArrivalPlanned: Optional[datetime] = None


class UpdateStatusTagRequest(TraewellingRequestModel):
    key: str
    value: str
    visibility: trwl.enums.Visibility


class UpdateUserTrustedRequest(TraewellingRequestModel):
    userId: str
    expiresAt: datetime
