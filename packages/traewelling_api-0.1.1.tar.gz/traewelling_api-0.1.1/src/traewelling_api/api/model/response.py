from datetime import datetime
from typing import Union, Optional
import uuid
import pydantic
import traewelling_pydantic as trwl
import fptf_pydantic.models as fptf


class TraewellingResponseModel(trwl.models.TraewellingModel):
    pass


class Meta(TraewellingResponseModel):
    current_page: int
    from_: int = pydantic.Field(alias="from")
    path: str
    per_page: int
    to: int


class Links(TraewellingResponseModel):
    first: str
    last: Optional[str] = None
    prev: Optional[str] = None
    next_: Optional[str] = pydantic.Field(default=None, alias="next")


class BearerTokenResponse(TraewellingResponseModel):
    token: str
    expires_at: datetime


class LikeResponse(TraewellingResponseModel):
    count: int


class CheckinResponse(TraewellingResponseModel):
    status: trwl.models.Status
    points: trwl.models.Points
    alsoOnThisConnection: list[trwl.models.Status]


class EventDetailsResponse(TraewellingResponseModel):
    id: int
    slug: str
    totalDistance: int
    totalDuration: int

class Departure(trwl.models.TraewellingModel):
    tripId: str
    stop: fptf.Stop
    when: datetime
    plannedWhen: datetime
    platform: str
    plannedPlatform: str
    direction: str
    line: fptf.Line
    station: trwl.models.Station


class DepartureMetaTimes(TraewellingResponseModel):
    now: datetime
    prev: datetime
    next_: datetime = pydantic.Field(alias="next")


class DepartureMeta(TraewellingResponseModel):
    station: trwl.models.Station
    times: DepartureMetaTimes
    removedLicenses: list[Union[str, trwl.models.LicenseDTO]]
    removedCount: int
