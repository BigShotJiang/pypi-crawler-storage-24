"""
Logging in, creating Accounts, etc.
"""

from typing import Optional

from . import generic
import traewelling_pydantic.models as trwlm
from . import model


def post_auth_logout(token: str) -> bool:
    """
    Logout & invalidate current bearer token
    """

    generic.post(token=token, path="auth/logout")

    return True


def get_auth_user(token: str) -> trwlm.UserAuth:
    """
    Get authenticated user information
    """

    response, status_code = generic.get(token=token, path="auth/user")

    return trwlm.UserAuth.model_validate(response["data"])


def post_auth_refresh(token: str) -> model.response.BearerTokenResponse:
    """
    Refresh Bearer Token
    """

    response, status_code = generic.post(token=token, path="auth/refresh")

    return model.response.BearerTokenResponse.model_validate(response["data"])


def get_user_statuses_active(token: str) -> Optional[trwlm.Status]:
    """
    User state
    """

    response, status_code = generic.get(token=token, path="user/statuses/active")

    if status_code == 204:
        return None

    return trwlm.Status.model_validate(response["data"])
