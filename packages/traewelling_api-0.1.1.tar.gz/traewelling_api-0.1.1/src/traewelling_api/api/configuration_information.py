"""
Endpoints related to application configuration information.
"""

from . import generic
import traewelling_pydantic.config as trwlc


def get_app_configuration(token: str) -> trwlc.ConfigurationInformation:
    """
    Retrieves configuration information about the application, including features and supported languages.
    """
    
    response, status_code = generic.get(token=token, path="app/configuration")

    return trwlc.ConfigurationInformation.model_validate(response)
