"""
Events that users can check in to
"""

from datetime import datetime
from typing import Optional

import traewelling_pydantic.models as trwlm
from requests import HTTPError

from . import generic, model


def get_event(token: str, slug: str) -> trwlm.Event:
    """
    [Auth optional] Get basic information for event
    """
    response, status_code = generic.get(token=token, path=f"event/{slug}")

    return trwlm.Event.model_validate(response["data"])


def get_events(
    token: str, timestamp: datetime, only_upcoming: bool = False
) -> list[trwlm.Event]:
    """
    Returns all active or upcoming events for the given timestamp. Default timestamp is now. If upcoming is set to true, all events ending after the timestamp are returned.
    """
    response, status_code = generic.get(
        token=token,
        path="events",
        params={"timestamp": timestamp.isoformat(), "upcoming": only_upcoming},
    )

    return [trwlm.Event.model_validate(event) for event in response["data"]]


def get_event_details(token: str, slug: str) -> model.response.EventDetailsResponse:
    """
    Returns overall travelled distance and duration for an event
    """
    response, status_code = generic.get(token=token, path=f"event/{slug}/details")

    return model.response.EventDetailsResponse.model_validate(response["data"])


def get_event_statuses(
    token: str, slug: str, page: int
) -> Optional[tuple[list[trwlm.Event], model.response.Links, model.response.Meta]]:
    """
    Returns all for user visible statuses for an event
    """
    try:
        response, status_code = generic.get(
            token=token,
            path=f"event/{slug}/statuses",
            params={"page": page},
        )
    except HTTPError as error:
        if error.response.status_code == 404:
            return None
        raise error

    return (
        [trwlm.Event.model_validate(event) for event in response["data"]],
        model.response.Links.model_validate(response["links"]),
        model.response.Meta.model_validate(response["meta"]),
    )


def post_event(
    token: str, event_suggestion: model.request.EventSuggestionRequest
) -> bool:
    """
    Submit a possible event for our administrators to publish
    """
    response, status_code = generic.post(
        token=token, path="event", data=event_suggestion.model_dump(mode="json")
    )

    return True
