"""
Checkin related endpoints. Regular process is departures -> trip -> checkin
"""

from datetime import datetime
from typing import Optional, Union
import uuid
from pydantic_extra_types.coordinate import Latitude, Longitude

from . import generic
import traewelling_pydantic.api_models as trwla
import traewelling_pydantic.models as trwlm
from . import model
from requests.exceptions import HTTPError
from urllib.parse import quote


def get_operators(token: str) -> list[trwlm.Operator]:
    response, status_code = generic.get(token=token, path="operators")

    return [
        trwlm.Operator.model_validate(operator) for operator in response["data"]
    ]


def get_stations(
    token: str,
    identifier_provider: Optional[str] = None,
    query: Optional[str] = None,
    identifier: Optional[str] = None,
    min_lat: Optional[Latitude] = None,
    max_lat: Optional[Latitude] = None,
    min_lon: Optional[Longitude] = None,
    max_lon: Optional[Longitude] = None,
    limit: int = 50,
    with_identifiers: bool = False,
) -> Optional[list[trwlm.Station]]:
    """
    UNSTABLE: Returns stations by fuzzy text, exact identifier, or within a bounding box (BBOX).
    """

    def valid_bounding_box(
        min_lat: Optional[Latitude] = None,
        max_lat: Optional[Latitude] = None,
        min_lon: Optional[Longitude] = None,
        max_lon: Optional[Longitude] = None,
    ) -> bool:
        if min_lat is None:
            return False
        if max_lat is None:
            return False
        if min_lon is None:
            return False
        if max_lon is None:
            return False

        if min_lat > max_lat:
            return False

        if min_lon > max_lon:
            return False

        return True

    if (
        query is not None
        and (identifier is not None and identifier_provider is not None)
        and valid_bounding_box(min_lat, max_lat, min_lon, max_lon)
    ):
        raise ValueError(
            "Only specify one: query, identifier+identifier_provider or bounding box"
        )

    if query is not None:
        params = {
            "query": quote(query),
            "limit": limit,
            "withIdentifiers": with_identifiers,
        }
    elif identifier is not None:
        params = {
            "identifier_provider": identifier_provider,
            "identifier": identifier,
            "limit": limit,
            "withIdentifiers": with_identifiers,
        }
    elif valid_bounding_box(min_lat, max_lat, min_lon, max_lon):
        params = {
            "min_lat": min_lat,
            "max_lat": max_lat,
            "min_lon": min_lon,
            "max_lon": max_lon,
            "limit": limit,
            "withIdentifiers": with_identifiers,
        }
    else:
        raise ValueError(
            "Specify one: query, identifier+identifier_provider or bounding box"
        )

    try:
        response, status_code = generic.get(token=token, path="stations", params=params)

        return [trwlm.Station.model_validate(i) for i in response["data"]]
    except HTTPError as error:
        if error.response.status_code == 404:
            return None
        raise error


def get_stations_by_id(
    token: str, station_id: Union[uuid.UUID, int], with_identifiers: bool = False
) -> Optional[trwlm.Station]:
    """
    This request returns a single station object
    """
    try:
        response, status_code = generic.get(
            token=token,
            path=f"station/{station_id}",
            params={"withIdentifiers": with_identifiers},
        )

        return trwlm.Station.model_validate(response["data"])
    except HTTPError as error:
        if error.response.status_code == 404:
            return None
        raise error

def get_station_departures(token: str, station_id: Union[uuid.UUID, int], when: datetime, travelType: str) -> Optional[tuple[list[model.response.Departure], model.response.DepartureMeta]]:
    """
    Get departures from a station.
    """
    try:
        response, status_code = generic.get(
            token=token,
            path=f"station/{station_id}/departures",
            params={"when": when, "travelType": travelType},
        )

        return [model.response.Departure.model_validate(i) for i in response["data"]], model.response.DepartureMeta.model_validate(response["meta"])
    except HTTPError as error:
        if error.response.status_code == 404:
            return None
        raise error
    

def get_trains_trip(token: str, hafasTripId: str, lineName: str) -> Optional[trwlm.Trip]:
    """
    Get the stopovers and trip information for a given train
    """
    try:
        response, status_code = generic.get(
                token=token,
                path="trains/trip",
                params={"hafasTripId": hafasTripId, "lineName": lineName},
            )
        return trwlm.Trip.model_validate(response["data"])
    except HTTPError as error:
        if error.response.status_code == 404:
            return None
        raise error

def get_trains_station_nearby(token: str, latitude: Latitude, longitude: Longitude) -> Optional[list[trwlm.Station]]:
    """
    Location based search for stations
    """
    try:
        response, status_code = generic.get(
                token=token,
                path="trains/trip",
                params={"latidtude": latitude, "longitude": longitude},
            )
        return [trwlm.Station.model_validate(i) for i in response["data"]]
    except HTTPError as error:
        if error.response.status_code == 404:
            return None
        raise error

def post_trains_checkin(token: str, checkin: model.request.CheckinRequest) -> trwla.CheckinResponse:
    """
    Check in to a trip.
    """
    response, status_code = generic.post(
        token=token,
        path="trains/checkin",
        data=checkin.model_dump(mode="json")
    )

    return trwla.CheckinResponse.model_validate(response)

def put_station_as_home(token: str, station_id: int) -> Optional[trwlm.Station]:
    """
    Set a station as home station
    """
    try:
        response, status_code = generic.put(
                token=token,
                path=f"station/{station_id}/home",
            )
        return trwlm.Station.model_validate(response["data"])
    except HTTPError as error:
        if error.response.status_code == 404:
            return None
        raise error

def get_trains_station_autocomplete(token: str, query: str) -> list[trwlm.Station]:
    """
    This request returns an array of max. 10 station objects matching the query.
    """
    response, status_code = generic.get(
            token=token,
            path=f"trains/station/autocomplete/{quote(query)}",
        )
    return [trwlm.Station.model_validate(i) for i in response["data"]]


def get_trains_station_history(token: str) -> list[trwlm.Station]:
    """
    This request returns an array of max. 10 most recent station objects that the user has arrived at.
    """
    response, status_code = generic.get(
            token=token,
            path="trains/station/history",
        )
    return [trwlm.Station.model_validate(i) for i in response["data"]]
