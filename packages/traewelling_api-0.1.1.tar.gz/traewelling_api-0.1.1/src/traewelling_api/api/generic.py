from typing import Optional
import requests
from urllib.parse import urljoin


def request(
    token: str,
    path: str,
    method: str = "GET",
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    headers: Optional[dict] = None,
    base_url: str = "https://traewelling.de/api/v1/",
) -> tuple[dict, int]:
    response = requests.request(
        method=method.upper(),
        url=urljoin(base_url, path),
        params=params,
        headers={"Authorization": f"Bearer {token}"}
        if headers is None
        else {"Authorization": f"Bearer {token}", **headers},
        data=data,
    )

    response.raise_for_status()

    return response.json(), response.status_code


def get(
    token: str,
    path: str,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    headers: Optional[dict] = None,
    base_url: str = "https://traewelling.de/api/v1/",
) -> tuple[dict, int]:
    return request(
        method="GET",
        token=token,
        path=path,
        params=params,
        data=data,
        headers=headers,
        base_url=base_url,
    )

def put(
    token: str,
    path: str,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    headers: Optional[dict] = None,
    base_url: str = "https://traewelling.de/api/v1/",
) -> tuple[dict, int]:
    return request(
        method="PUT",
        token=token,
        path=path,
        params=params,
        data=data,
        headers=headers,
        base_url=base_url,
    )

def post(
    token: str,
    path: str,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    headers: Optional[dict] = None,
    base_url: str = "https://traewelling.de/api/v1/",
) -> tuple[dict, int]:
    return request(
        method="POST",
        token=token,
        path=path,
        params=params,
        data=data,
        headers=headers,
        base_url=base_url,
    )

def delete(
    token: str,
    path: str,
    params: Optional[dict] = None,
    data: Optional[dict] = None,
    headers: Optional[dict] = None,
    base_url: str = "https://traewelling.de/api/v1/",
) -> tuple[dict, int]:
    return request(
        method="DELETE",
        token=token,
        path=path,
        params=params,
        data=data,
        headers=headers,
        base_url=base_url,
    )
