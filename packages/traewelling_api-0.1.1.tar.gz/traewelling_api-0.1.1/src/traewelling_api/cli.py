import json
from typing import Annotated, Optional

from pydantic_extra_types.coordinate import Latitude, Longitude

from . import client
import traewelling_pydantic.models as traewelling
import typer
from rich.console import Console
from requests.exceptions import HTTPError
from requests import status_codes

app = typer.Typer()
console = Console()


@app.command("station", no_args_is_help=True)
def get_station(
    token: Annotated[str, typer.Option("--token", "-t", envvar="TRAEWELLING_TOKEN")],
    station_id: Annotated[Optional[int], typer.Option("--station-id", "-i")] = None,
    name: Annotated[Optional[str], typer.Option("--name", "-n")] = None,
    identifier: Annotated[Optional[str], typer.Option("--identifier")] = None,
    identifier_provider: Annotated[
        Optional[str], typer.Option("--identifier-provider")
    ] = None,
    bounding_box: Annotated[
        Optional[tuple[float, float, float, float]], typer.Option("--bounding-box")
    ] = None,
    with_identifiers: Annotated[bool, typer.Option("--with-identifiers")] = False,
    as_json: Annotated[bool, typer.Option("--json", "-j", envvar="AS_JSON")] = False,
):
    trwl = client.TraewellingClient(token)

    try: 
        response = trwl.get_stations(
            query=name,
            identifier=identifier,
            identifier_provider=identifier_provider,
            min_lat=Latitude(bounding_box[0]) if bounding_box is not None else None,
            max_lat=Latitude(bounding_box[1]) if bounding_box is not None else None,
            min_lon=Longitude(bounding_box[2]) if bounding_box is not None else None,
            max_lon=Longitude(bounding_box[3]) if bounding_box is not None else None,
            with_identifiers=with_identifiers
        )

    except ValueError:
        if station_id is None:
            raise ValueError("No valid identifiers or bounding box specified")

        response = trwl.get_station_by_id(station_id, with_identifiers)
        

    if as_json:
        if response is not None:
            if isinstance(response, list):
                response = json.dumps([i.model_dump(mode="json") for i in response])
            else:
                response = response.model_dump_json()

            console.print_json(response)
        else:
            console.print_json(None)
    else:
        console.print(response)


@app.command("stations")
def get_stations(
    token: Annotated[str, typer.Option("--token", "-t", envvar="TRAEWELLING_TOKEN")],
    ids: list[int],
    with_identifiers: Annotated[bool, typer.Option("--with-identifiers")] = False,
    as_json: Annotated[bool, typer.Option("--json", "-j", envvar="AS_JSON")] = False,
):
    trwl = client.TraewellingClient(token)
    responses: list[Optional[traewelling.Station]] = []

    for id in ids:
        try:
            responses.append(trwl.get_station_by_id(id, with_identifiers))
        except HTTPError as error:
            if not as_json:
                if (
                    error.response.status_code == status_codes.codes.forbidden
                    or error.response.status_code == status_codes.codes.unauthorized
                ):
                    console.print(
                        f"Don't have permission to query the station for ID {id}"
                    )
                elif error.response.status_code == status_codes.codes.too_many_requests:
                    console.print("Too many requests")

    if as_json:
        console.print_json(
            json.dumps(
                [
                    response.model_dump() if response is not None else None
                    for response in responses
                ]
            )
        )
    else:
        console.print(responses)


@app.command("operators")
def get_operators(
    token: Annotated[str, typer.Option("--token", "-t", envvar="TRAEWELLING_TOKEN")],
    as_json: Annotated[bool, typer.Option("--json", "-j", envvar="AS_JSON")] = False,
):
    trwl = client.TraewellingClient(token)
    response = trwl.get_operators()

    if as_json:
        console.print_json(json.dumps([r.model_dump() for r in response]))
    else:
        console.print(response)


if __name__ == "__main__":
    app()
