# Traewelling-API

This is a simple Traewelling API wrapper.

The goal is to provide an easy way to talk with the Traewelling API from Python

## TODOs

- add every API endpoint for Traewelling
- add FPTF converterter for Traewelling API responses
- add command for every API endpoint to CLI
- [OPTIONAL] add TUI for interactive API requests
