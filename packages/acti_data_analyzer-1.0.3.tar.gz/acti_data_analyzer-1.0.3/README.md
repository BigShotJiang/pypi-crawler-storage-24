# ADA – Actigraphic Data Analyzer
ADA stands for Actigraphic Data Analyzer, coincidentally being also the name of the first programmer in the world.
It is an open source Python module for processing, analyzing and visualizing actigraphic data, with the main focus on bedtime sleep/wake classification and circadian rhythms analysis.
ADA is usable in form of a python package, and in form of standalone application with graphical interface (GUI).

## Installation
Python 3.11 or higher is required. To install the Python package use pip:

```shell
pip install acti-data-analyzer
```

<!-- The GUI for Windows 10 and Windows 11 is availabe as a standalone executable. -->

GUI version of ADA can installed and run on any system as a Python script, best within a venv. To do use following commands:

```shell
pip install 'acti-data-analyzer[gui]'
python -m ada_gui
```

## Main features

* Reading and writing data from:
  * GENEActiv .bin and .csv files
  * Actigraph Corp .gt3x and .csv files
  * The MESA dataset.
* Converting data to native .ada format (much more efficient in terms of disk space and reading speed).
* Multiple algorithms allowing collapsing into epochs:
  * MIMS
  * ActivityIndex
  * ENMO
  * Resampling
* Sleep/wake scoring using multiple algorithms:
  * Cole-Kripke
  * Webster
  * Scripps Clinic
  * UCSD
  * Sazonov
  * Unified Filter, with possibility of custom filter construction.
* Estimating multiple sleep metrics:
  * Sleep efficiency
  * Sleep fragmentation index
  * Sleep onset latency
  * Wake after sleep onset
  * And more.
* Assessing circadian rhythms:
  * Single and multi-component cosinor in linear and nonlinear variants
  * Sigmoidally-transformed cosinor
  * Spectrum estimator using autoregressive model
  * Detrended Fluctuation Analysis
  * Nonparametric measures: Interdaily Stability, Intradaily Variability, M10, L5.
* Easy to read and analyze summaries of sleep/wake and circadian assessments for multiple subjects (in a form of comma-separated CSV).
* Automatic and customizable synchronization of actigraphic data with PSG staging.
* Plotting of all analysis steps.

## Documentation

Full documentation together with tutorial providing basic insight into functionalities of ADA as a Python package can be found under the [link](https://fuw_software.gitlab.io/aktygrafy/).

## Example data
Sample dataset, consisting of 87 weekly recordings of healthy subjects, can be found under the [link](https://danebadawcze.uw.edu.pl/dataset.xhtml?persistentId=doi:10.58132/HFHM56). Do not hesitate to test the package capabilities using this data!

## Acknowledgments

`pygt3x` source code included in ADA is developed under the GPL-3.0 license by the Actigraph team. The original repository can be found under the [link](https://github.com/actigraph/pygt3x).

### Funding
Study financed from the state budget within the program of the Polish Minister of Education and Science under the name ”Perły Nauki”, project number PN/01/0111/2022, funding value 239 998.00 zł, total value 239 998.00 zł
