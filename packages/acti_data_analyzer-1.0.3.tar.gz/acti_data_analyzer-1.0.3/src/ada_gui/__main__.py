"""Entry point for the ADA GUI application.

Run with ``python -m ada_gui``.  The multiprocess library is configured
here (before any other imports) so that child processes launched during
analysis use the "spawn" start method, which is safe on all platforms.
``freeze_support()`` is required for bundled executables (e.g. PyInstaller).
"""

if __name__ == "__main__":
    from ada_gui.gui import main
    import multiprocess
    multiprocess.freeze_support()
    multiprocess.set_start_method("spawn", force=True)
    main()
