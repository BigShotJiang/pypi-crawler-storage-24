"""Custom exceptions for pymyarm."""


class PyMyArmError(Exception):
    """Base exception for pymyarm."""


class ConnectionError(PyMyArmError):
    """Raised when serial connection is not available."""


class CommunicationError(PyMyArmError):
    """Raised when protocol communication fails."""


class TimeoutError(PyMyArmError):
    """Raised when response timeout occurs."""


class InvalidParameterError(PyMyArmError):
    """Raised when user input parameter is invalid."""


class NotImplementedFeatureError(PyMyArmError):
    """Raised when feature is intentionally unsupported on this hardware."""

    def __init__(self, feature: str) -> None:
        super().__init__(
            f"Feature '{feature}' is not supported on current STS implementation."
        )


class ServoError(PyMyArmError):
    """Raised when servo status/error byte indicates failure."""

    def __init__(self, servo_id: int, error_code: int, message: str = "") -> None:
        detail = f"Servo {servo_id} error 0x{error_code:02X}"
        if message:
            detail = f"{detail}: {message}"
        super().__init__(detail)
