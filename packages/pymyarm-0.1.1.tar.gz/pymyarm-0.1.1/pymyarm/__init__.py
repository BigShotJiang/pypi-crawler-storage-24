"""pymyarm public API."""

from .conversion import angle_to_encoder, encoder_to_angle
from .exceptions import (
    CommunicationError,
    ConnectionError,
    InvalidParameterError,
    NotImplementedFeatureError,
    PyMyArmError,
    ServoError,
)
from .joint_config import DEFAULT_ARM_CONFIG, ArmConfig, GripperConfig, JointConfig
from .myarm_sts import MyArmSTS, ServoSnapshot
from .port import find_servo_port

__all__ = [
    "MyArmSTS",
    "ServoSnapshot",
    "find_servo_port",
    "ArmConfig",
    "JointConfig",
    "GripperConfig",
    "DEFAULT_ARM_CONFIG",
    "angle_to_encoder",
    "encoder_to_angle",
    "PyMyArmError",
    "ConnectionError",
    "CommunicationError",
    "InvalidParameterError",
    "NotImplementedFeatureError",
    "ServoError",
]

__version__ = "0.1.1"
