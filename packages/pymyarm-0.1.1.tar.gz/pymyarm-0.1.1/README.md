# pymyarm

pymycobot-compatible Python API for Feetech STS servo-based robotic arms.

## Installation

```bash
pip install pymyarm
```

## Quick Start

```python
from pymyarm import MyArmSTS

arm = MyArmSTS(port="/dev/ttyACM0", baudrate=1000000)
arm.connect()

# Read all joint angles
angles = arm.get_angles()
print(angles)

# Move joints
arm.set_angles([0, 0, 0, 0, 0, 0], speed=200)

# Read encoder values
encoders = arm.get_servos_encoder()

# Control gripper
arm.set_gripper_value(50, speed=200)

arm.disconnect()
```

## Architecture

```
┌─────────────────────────────────────────┐
│            MyArmSTS (myarm_sts.py)      │  User API: angles, encoders, gripper
├─────────────────────────────────────────┤
│  STS (sts.py)      conversion.py        │  Register-level ops + unit conversion
├─────────────────────────────────────────┤
│          ServoController                │  Thread-safe TX/RX, retries, error cache
│          (servo_controller.py)          │
├─────────────────────────────────────────┤
│  protocol.py            port.py         │  Frame encoding/decoding + serial I/O
├─────────────────────────────────────────┤
│  constants.py       joint_config.py     │  Protocol constants + arm mapping
└─────────────────────────────────────────┘
```

## Features

- **pymycobot-compatible API** — drop-in replacement for pymycobot with Feetech STS servos
- **Thread-safe** — all serial communication is locked and safe for multi-threaded use
- **Joint calibration** — offset calibration, encoder centering
- **Dual-motor joints** — supports joints driven by two servos (e.g. shoulder)
- **Sync read/write** — efficient batch operations for all servos
- **Auto port detection** — finds servo controllers automatically

## Requirements

- Python >= 3.8
- pyserial >= 3.5

## Documentation

- [API Reference (English)](API_REFERENCE_EN.md)
- [API Reference (Chinese)](API_REFERENCE.md)
- [Changelog](CHANGELOG.md)

## License

MIT
