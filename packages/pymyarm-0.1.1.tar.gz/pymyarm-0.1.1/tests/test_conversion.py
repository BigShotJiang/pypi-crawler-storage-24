"""Conversion helper tests."""

from pymyarm.conversion import angle_to_encoder, encoder_to_angle


def test_center_conversion():
    assert angle_to_encoder(0.0) == 2048
    assert encoder_to_angle(2048) == 0.0


def test_limit_clamp():
    assert angle_to_encoder(400.0) == 4095
    assert angle_to_encoder(-400.0) == 0
