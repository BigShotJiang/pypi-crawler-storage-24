"""Joint config mapping tests."""

from pymyarm.joint_config import DEFAULT_ARM_CONFIG


def test_default_arm_servo_ids():
    assert DEFAULT_ARM_CONFIG.all_servo_ids() == [1, 2, 3, 4, 5, 6, 7, 8]


def test_joint2_dual_mapping():
    pairs = DEFAULT_ARM_CONFIG.joint_to_motor_pairs(2, 1000)
    assert pairs == [(2, 1000), (3, 3096)]


def test_joint_single_mapping():
    pairs = DEFAULT_ARM_CONFIG.joint_to_motor_pairs(3, 2000)
    assert pairs == [(4, 2000)]
