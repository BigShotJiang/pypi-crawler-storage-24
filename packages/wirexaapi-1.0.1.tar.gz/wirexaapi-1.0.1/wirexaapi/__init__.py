"""
Wirexa API SDK - Drop-in replacement del SDK de SignalWire/Twilio.

CREDENCIALES (las obtienes del dashboard):
  space_url  = "your-space.example.com:5000"
  project_id = "your-project-id"
  api_token  = "your-api-token"

USO:

  ANTES (SignalWire original):
    from signalwire.rest import Client
    client = Client(project_id, api_token, signalwire_space_url=space_url)

  DESPUÉS (Wirexa API):
    from wirexaapi import Client
    client = Client(project_id, api_token, signalwire_space_url=space_url)

  El resto del código NO cambia.
"""
from wirexaapi.rest import Client

__all__ = ["Client"]
