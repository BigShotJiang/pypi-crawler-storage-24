# Wirexa API SDK

A production-ready Python SDK for Wirexa API - a self-hosted telephony platform compatible with SignalWire and Twilio REST API.

## Installation

```bash
pip install wirexaapi
```

## Quick Start

```python
from wirexaapi import Client

# Connect to your Wirexa API instance
client = Client(
    project_id="your-project-id",
    api_token="your-api-token", 
    signalwire_space_url="your-space.example.com:5000"
)

# Make a call
call = client.calls.create(
    to="+573001234567",
    from_="+18005550100",
    url="https://your-backend.com/xml",
    method="POST",
    timeout=28,
    record=True,
    status_callback="https://your-backend.com/status",
    status_callback_event=["initiated", "ringing", "completed"],
)

print(f"Call SID: {call.sid}")
print(f"Call Status: {call.status}")
```

## Migration from SignalWire

If you're migrating from SignalWire SDK:

```python
# Before
from signalwire.rest import Client as SignalWireClient

# After
from wirexaapi import Client as SignalWireClient
```

The rest of your code stays the same!

## Features

- Full SignalWire/Twilio API compatibility
- Call creation, retrieval, and listing
- Machine Detection (AMD)
- Recording
- Status callbacks
- Async AMD support

## License

MIT
