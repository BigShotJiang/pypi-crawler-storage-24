from .clawgrep import *

__doc__ = clawgrep.__doc__
if hasattr(clawgrep, "__all__"):
    __all__ = clawgrep.__all__