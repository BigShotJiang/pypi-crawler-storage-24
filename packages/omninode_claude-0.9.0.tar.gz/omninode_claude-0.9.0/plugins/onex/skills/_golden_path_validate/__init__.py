# SPDX-License-Identifier: MIT
# Copyright (c) 2025 OmniNode Team
"""golden-path-validate skill package."""
