"""HTTP client for Full-Time URLs."""

from urllib.parse import urlencode

import requests


class FullTimeClient:
    """Fetches HTML from Full-Time URLs."""

    _DEFAULT_HEADERS = {
        "User-Agent": (
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
            "AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/141.0.0.0 Safari/537.36"
        )
    }

    def get(
        self,
        url: str,
        params: dict | None = None,
        headers: dict[str, str] | None = None,
    ) -> str:
        """GET a URL and return the response body as text."""
        url = self._build_url(url, params or {})
        request_headers = {**self._DEFAULT_HEADERS, **(headers or {})}
        try:
            response = requests.get(url, headers=request_headers, timeout=30)
            response.raise_for_status()
            return response.text
        except requests.RequestException as e:
            raise RuntimeError(f"Failed to fetch data from {url}: {e}") from e

    def _build_url(self, url: str, params: dict) -> str:
        if params:
            url = f"{url}?{urlencode(params)}"
        return url
