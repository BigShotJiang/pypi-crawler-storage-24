"""Async goal handler framework for CLIPS 7.0x backward chaining.

When rules generate goals via backward chaining, the async run loop dispatches
them to registered Python async handlers. Handlers fulfill goals by asserting
facts. Timers are the first built-in handler type.

"""

import asyncio
import inspect
import time as _time
from dataclasses import dataclass, field

from clipspyx.common import CLIPS_MAJOR
from clipspyx.values import Symbol
from clipspyx.dsl.timer import AFTER, AT, EVERY  # re-export


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------

class GoalHandlerError(Exception):
    """Raised when an async goal handler fails."""


# ---------------------------------------------------------------------------
# Per-environment state
# ---------------------------------------------------------------------------

@dataclass
class GoalHandlerState:
    handlers: dict = field(default_factory=dict)        # template_name -> async callable
    pending: dict = field(default_factory=dict)          # goal_index -> asyncio.Task
    halted: bool = False                                 # set by halt_async()


# ---------------------------------------------------------------------------
# Timer-event deftemplate
# ---------------------------------------------------------------------------

TIMER_EVENT_DEFTEMPLATE = """\
(deftemplate timer-event
  (slot kind (type SYMBOL))
  (slot name (type SYMBOL))
  (slot seconds (type FLOAT) (default 0.0))
  (slot time (type FLOAT) (default 0.0))
  (slot count (type INTEGER) (default 0))
  (slot fired_at (type FLOAT) (default 0.0)))"""


# ---------------------------------------------------------------------------
# Built-in timer handler
# ---------------------------------------------------------------------------

_EXHAUSTED = object()
"""Sentinel returned by _gen_step when an async generator is exhausted."""


async def _gen_step(agen):
    """Advance an async generator by one step."""
    try:
        return await agen.__anext__()
    except StopAsyncIteration:
        return _EXHAUSTED


def _timer_handler(goal, env):
    """Dispatch to one-shot or periodic timer handler.

    Returns a coroutine for ``at``/``after`` timers, or an async generator
    for ``every`` timers.
    """
    kind = str(goal['kind'])
    if kind == 'every':
        return _timer_every(goal, env)
    return _timer_oneshot(goal, env)


async def _timer_oneshot(goal, env):
    """Handle at/after timer-event goals (one-shot)."""
    kind = str(goal['kind'])
    name = str(goal['name'])

    seconds = 0.0
    target_time = 0.0

    if kind == 'at':
        target_time = float(goal['time'])
        sleep_for = max(0, target_time - _time.time())
    else:
        seconds = float(goal['seconds'])
        sleep_for = seconds

    await asyncio.sleep(sleep_for)

    tpl = env.find_template('timer-event')
    tpl.assert_fact(
        kind=Symbol(kind), name=Symbol(name),
        seconds=seconds, time=target_time,
        count=0, fired_at=_time.time())


async def _timer_every(goal, env):
    """Handle periodic timer-event goals (async generator).

    Each iteration sleeps, asserts the fact, and yields.  The fact is
    scoped to the yield via try/finally: it is retracted when the
    generator resumes (normal) or is cancelled (close/exception).
    """
    name = str(goal['name'])
    seconds = float(goal['seconds'])
    tpl = env.find_template('timer-event')

    count = 0
    while True:
        await asyncio.sleep(seconds)
        fact = tpl.assert_fact(
            kind=Symbol('every'), name=Symbol(name),
            seconds=seconds, time=0.0,
            count=count, fired_at=_time.time())
        try:
            yield
        finally:
            if fact.exists:
                fact.retract()
        count += 1



# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def enable_goal_handlers(env):
    """Enable the async goal handler framework for the given environment.

    Registers the timer-event deftemplate and the built-in timer handler.
    Must be called before async_run() or register_goal_handler().

    Requires CLIPS 7.0x (goals are a 7.0x feature).
    """
    if CLIPS_MAJOR < 7:
        raise TypeError("Async goal handlers require CLIPS 7.0 or later")

    # Build the timer-event template
    env.build(TIMER_EVENT_DEFTEMPLATE)

    # Create and store state
    state = GoalHandlerState()
    state.handlers['timer-event'] = _timer_handler
    env._goal_handler_state = state


def disable_goal_handlers(env):
    """Disable the async goal handler framework and cancel pending tasks."""
    state = getattr(env, '_goal_handler_state', None)
    if state is None:
        return

    # Cancel all pending handler tasks
    for task in state.pending.values():
        task.cancel()
    state.pending.clear()

    env._goal_handler_state = None


def register_goal_handler(env, template, handler):
    """Register an async handler for goals matching a template.

    ``template`` can be a DSL Template class or a CLIPS template name string.

    The handler is an async callable with signature:
        async def handler(goal, env) -> None

    The handler receives the goal (a TemplateFact) and the Environment.
    It should assert facts to satisfy the goal.
    """
    state = env._goal_handler_state
    if state is None:
        raise RuntimeError("Call enable_goal_handlers(env) first")
    if isinstance(template, str):
        name = template
    else:
        name = template.__clipspyx_dsl__.name
    state.handlers[name] = handler




# ---------------------------------------------------------------------------
# AsyncRunner - resource context for async goal handling
# ---------------------------------------------------------------------------

class AsyncRunner:
    """Manages async goal handler lifecycle across multiple run() calls.

    Unlike the deprecated ``async_run()`` function, ``AsyncRunner`` owns the
    full goal handler lifecycle: it auto-enables on creation and disables on
    ``close()``.  Persistent handler tasks survive when ``stop_event`` fires
    and are only cancelled by ``close()``.

    Usage::

        async with AsyncRunner(env) as runner:
            runner.register_handler(MyTemplate, my_handler, persistent=True)
            while not done:
                work_ready.clear()
                result = await runner.run(stop_event=work_ready)
        # close() called automatically - all tasks cancelled, handlers disabled
    """

    def __init__(self, env):
        state = getattr(env, '_goal_handler_state', None)
        if state is None:
            enable_goal_handlers(env)
        self.env = env
        self._persistent_tasks = {}           # template_name -> asyncio.Task
        self._generators = {}                 # task_id -> async generator
        self._closed = False
        self._skipped = set()                 # goal indices completed without satisfying

    def register_handler(self, template, handler):
        """Register an async handler for goals matching a template.

        Regular async handlers (coroutines) are tracked per-goal and
        cancelled when ``stop_event`` fires.  Async generator handlers
        (functions with ``yield``) are tracked per-template and survive
        across ``run()`` calls -- ``yield`` encodes persistence.
        """
        register_goal_handler(self.env, template, handler)

    # -- run() and its cycle steps --

    async def run(self, limit=None, max_cycles=None):
        """Run the CLIPS engine with async goal handler processing.

        Raises ``RuntimeError`` if called after :meth:`close`.

        Returns a string indicating why the loop stopped:

        - ``"completed"``: no goals remain, no pending handlers
        - ``"max_cycles"``: reached the *max_cycles* limit
        - ``"halted"``: ``halt_async()`` was called (internal cancellation)
        """
        if self._closed:
            raise RuntimeError("AsyncRunner is closed")
        state = self.env._goal_handler_state
        if state is None:
            raise RuntimeError("Call enable_goal_handlers(env) first")

        return await self._run_loop(state, limit, max_cycles)

    async def _run_loop(self, state, limit, max_cycles):
        """Core inference loop."""
        state.halted = False
        self._skipped.clear()
        cycle = 0
        while max_cycles is None or cycle < max_cycles:
            cycle += 1

            self._prune_done_persistent()

            if state.halted:
                return "halted"

            self.env.run(limit)

            if state.halted:
                return "halted"

            self._dispatch_goals(state)
            self._cancel_retracted_goals(state)

            if not state.pending and not self._has_active_persistent():
                return "completed"
            if max_cycles is not None and cycle >= max_cycles:
                return "max_cycles"

            reason = await self._wait_for_handlers(state)
            if reason is not None:
                return reason

        return "max_cycles"

    def _prune_done_persistent(self):
        """Remove completed persistent tasks from tracking."""
        for name in [n for n, t in self._persistent_tasks.items()
                     if t.done()]:
            del self._persistent_tasks[name]

    def _has_active_persistent(self):
        """True if any persistent task is still running."""
        return any(not t.done() for t in self._persistent_tasks.values())

    def _create_handler_task(self, handler, goal):
        """Create a task from a handler invocation.

        Returns ``(task, is_generator)``.  If the handler returns a
        coroutine, wraps it in a task directly.  If it returns an async
        generator, creates a task for the first ``anext()`` step.
        """
        invocation = handler(goal, self.env)
        if inspect.isasyncgen(invocation):
            task = asyncio.create_task(_gen_step(invocation))
            self._generators[id(task)] = invocation
            return task, True
        return asyncio.create_task(invocation), False

    def _dispatch_goals(self, state):
        """Scan CLIPS goals and create handler tasks for new ones.

        Generators (yield) are tracked per-template in _persistent_tasks.
        Coroutines are tracked per-goal in state.pending.
        """
        for goal in self.env.goals():
            tname = goal.template.name
            # Already have a running persistent task for this template?
            if tname in self._persistent_tasks \
                    and not self._persistent_tasks[tname].done():
                continue
            handler = state.handlers.get(tname)
            if handler is None:
                continue
            idx = goal.index
            if idx in self._skipped or idx in state.pending:
                continue
            task, is_gen = self._create_handler_task(handler, goal)
            if is_gen:
                self._persistent_tasks[tname] = task
            else:
                state.pending[idx] = task

    def _cancel_retracted_goals(self, state):
        """Cancel non-persistent tasks whose goals no longer exist."""
        for idx in list(state.pending):
            try:
                self.env.find_goal(idx)
            except LookupError:
                task = state.pending.pop(idx)
                task.cancel()
                gen = self._generators.pop(id(task), None)
                if gen is not None:
                    asyncio.create_task(gen.aclose())

        for idx in list(self._skipped):
            try:
                self.env.find_goal(idx)
            except LookupError:
                self._skipped.discard(idx)

    async def _wait_for_handlers(self, state):
        """Wait for at least one handler to complete.

        Returns ``"completed"`` if no tasks remain, or ``None`` to
        continue cycling.
        """
        wait_set = set(state.pending.values()) | {
            t for t in self._persistent_tasks.values() if not t.done()
        }
        if not wait_set:
            return "completed"

        done, _ = await asyncio.wait(
            wait_set, return_when=asyncio.FIRST_COMPLETED)
        self._process_done(state, done)
        return None

    def _process_done(self, state, done):
        """Remove completed tasks from tracking and propagate errors.

        For generator-backed tasks, creates a replacement task for the
        next iteration instead of removing.
        """
        # Build reverse lookup: task id -> (owning dict, key)
        owners = {}
        for idx, t in state.pending.items():
            owners[id(t)] = (state.pending, idx)
        for name, t in self._persistent_tasks.items():
            owners[id(t)] = (self._persistent_tasks, name)

        for task in done:
            owner = owners.get(id(task))
            gen = self._generators.pop(id(task), None)

            if task.cancelled():
                if owner: del owner[0][owner[1]]
                if gen: asyncio.create_task(gen.aclose())
                continue

            if task.exception():
                if owner: del owner[0][owner[1]]
                if gen: asyncio.create_task(gen.aclose())
                raise GoalHandlerError(
                    f"Handler failed: {task.exception()}"
                ) from task.exception()

            if gen and task.result() is not _EXHAUSTED:
                new_task = asyncio.create_task(_gen_step(gen))
                self._generators[id(new_task)] = gen
                if owner: owner[0][owner[1]] = new_task
            else:
                if owner:
                    if gen is None and owner[0] is state.pending:
                        idx = owner[1]
                        try:
                            self.env.find_goal(idx)
                            self._skipped.add(idx)
                        except LookupError:
                            pass
                    del owner[0][owner[1]]

    async def close(self):
        """Cancel all tasks (persistent and non-persistent) and disable
        goal handlers.
        """
        if self._closed:
            return
        for task in self._persistent_tasks.values():
            task.cancel()
        self._persistent_tasks.clear()
        state = self.env._goal_handler_state
        if state is not None:
            for task in state.pending.values():
                task.cancel()
            state.pending.clear()
        # Generator cleanup happens via task cancellation above
        self._generators.clear()
        self._skipped.clear()
        disable_goal_handlers(self.env)
        self._closed = True

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        await self.close()
