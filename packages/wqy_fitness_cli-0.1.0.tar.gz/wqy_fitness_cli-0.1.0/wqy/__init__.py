"""
WQY - Workout & Quality You
你的专属健身鼓励小伙伴
"""
from .core import WQY, get_random_workout
from .cli import main

__version__ = "0.1.0"
__author__ = "OpenClaw"
__all__ = ['WQY', 'get_random_workout', 'main']
