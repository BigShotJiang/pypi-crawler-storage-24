"""
WQY - 健身鼓励库 (Workout & Quality You)
一个有趣、有创意的健身鼓励和追踪库
"""
import random
import json
import os
from datetime import datetime, timedelta
from typing import List, Dict, Optional

# 创意鼓励语库
ENCOURAGEMENTS = {
    "start": [
        "💪 今天的汗水是明天的笑容！开始吧！",
        "🔥 你比昨天更强！冲！",
        "⭐ 每一滴汗水都在雕刻更好的自己！",
        "🚀 动起来！你的未来感谢现在的你！",
        "💯 不需要完美，只需要开始！",
    ],
    "halfway": [
        "🎯 已经一半了！坚持就是胜利！",
        "⚡ 能量满满！继续保持！",
        "🌟 你在发光！继续保持这种状态！",
        "💪 肌肉在燃烧，脂肪在哭泣！",
        "🔥 热度起来了！别停！",
    ],
    "finish": [
        "🏆 完成了！你真是战士！",
        "🎉 恭喜你！又征服了一天！",
        "💎 今天的你闪闪发光！",
        "👑 王者归来！休息一下吧！",
        "⭐ 超级棒！明天继续！",
    ],
    "rest": [
        "😌 休息也是训练的一部分~",
        "🧘 给身体充充电，明天更强大！",
        "💤 肌肉是在休息时生长的，好好恢复！",
        "🌙 今天的努力已存档，明天继续！",
    ]
}

# 健身计划模板
WORKOUT_PLANS = {
    "减脂": {
        "description": "🔥 高效燃脂计划",
        "exercises": [
            ("开合跳", "3组 x 30秒"),
            ("波比跳", "3组 x 10个"),
            ("高抬腿", "3组 x 30秒"),
            ("登山者", "3组 x 20个"),
            ("平板支撑", "3组 x 30秒"),
        ],
        "tips": "💡 保持心率在最大心率的60-70%之间，燃脂效果最好！"
    },
    "增肌": {
        "description": "💪 力量增肌计划",
        "exercises": [
            ("俯卧撑", "4组 x 12个"),
            ("深蹲", "4组 x 15个"),
            ("引体向上/器械下拉", "4组 x 8个"),
            ("哑铃弯举", "3组 x 12个"),
            ("平板支撑", "3组 x 45秒"),
        ],
        "tips": "💡 注意动作标准，宁可少做也要做对！"
    },
    "塑形": {
        "description": "✨ 线条塑形计划",
        "exercises": [
            ("瑜伽拉伸", "10分钟"),
            ("侧平板", "3组 x 20秒/侧"),
            ("臀桥", "3组 x 15个"),
            ("卷腹", "3组 x 20个"),
            ("拉伸放松", "5分钟"),
        ],
        "tips": "💡 呼吸要均匀，感受肌肉的收缩！"
    },
    "有氧": {
        "description": "🏃 心肺有氧计划",
        "exercises": [
            ("慢跑/快走", "20分钟"),
            ("跳绳", "3组 x 1分钟"),
            ("原地跑", "3组 x 2分钟"),
            ("拉伸", "5分钟"),
        ],
        "tips": "💡 保持匀速呼吸，不要憋气！"
    }
}

# 成就徽章
ACHIEVEMENTS = {
    "first_workout": {"name": "🌱 初次尝试", "desc": "完成第一次打卡"},
    "week_warrior": {"name": "🔥 周战士", "desc": "连续打卡7天"},
    "month_master": {"name": "💎 月度大师", "desc": "连续打卡30天"},
    "hundred_club": {"name": "🏆 百次俱乐部", "desc": "累计打卡100次"},
    "early_bird": {"name": "🌅 早鸟", "desc": "早上6点前完成打卡"},
    "night_owl": {"name": "🦉 夜猫子", "desc": "晚上10点后完成打卡"},
}


class WQY:
    """Workout & Quality You - 你的健身小伙伴"""
    
    def __init__(self, user_name: str = "健身达人"):
        self.user_name = user_name
        self.data_file = f".wqy_{user_name}.json"
        self.data = self._load_data()
    
    def _load_data(self) -> Dict:
        """加载用户数据"""
        if os.path.exists(self.data_file):
            with open(self.data_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {
            "workouts": [],
            "achievements": [],
            "start_date": datetime.now().isoformat(),
            "total_minutes": 0
        }
    
    def _save_data(self):
        """保存用户数据"""
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, ensure_ascii=False, indent=2)
    
    def encourage(self, stage: str = "start") -> str:
        """获取鼓励语"""
        return random.choice(ENCOURAGEMENTS.get(stage, ENCOURAGEMENTS["start"]))
    
    def generate_plan(self, goal: str = "减脂") -> Dict:
        """生成健身计划"""
        plan = WORKOUT_PLANS.get(goal, WORKOUT_PLANS["减脂"])
        return {
            "goal": goal,
            "description": plan["description"],
            "exercises": plan["exercises"],
            "tips": plan["tips"],
            "message": f"\n{self.user_name}，{plan['description']}来啦！"
        }
    
    def check_in(self, workout_type: str = "健身", duration: int = 30, note: str = "") -> Dict:
        """打卡记录"""
        today = datetime.now()
        workout = {
            "date": today.isoformat(),
            "type": workout_type,
            "duration": duration,
            "note": note
        }
        self.data["workouts"].append(workout)
        self.data["total_minutes"] += duration
        
        # 检查成就
        new_achievements = self._check_achievements()
        self._save_data()
        
        return {
            "message": f"🎉 {self.user_name}，打卡成功！运动{duration}分钟！",
            "encouragement": self.encourage("finish"),
            "new_achievements": new_achievements,
            "total_workouts": len(self.data["workouts"]),
            "total_minutes": self.data["total_minutes"]
        }
    
    def _check_achievements(self) -> List[str]:
        """检查新成就"""
        new_achievements = []
        workouts = self.data["workouts"]
        
        # 初次尝试
        if len(workouts) == 1 and "first_workout" not in self.data["achievements"]:
            self.data["achievements"].append("first_workout")
            new_achievements.append(ACHIEVEMENTS["first_workout"])
        
        # 百次俱乐部
        if len(workouts) >= 100 and "hundred_club" not in self.data["achievements"]:
            self.data["achievements"].append("hundred_club")
            new_achievements.append(ACHIEVEMENTS["hundred_club"])
        
        # 检查连续打卡
        if len(workouts) >= 7:
            dates = [datetime.fromisoformat(w["date"]).date() for w in workouts[-7:]]
            if all((dates[i+1] - dates[i]).days == 1 for i in range(6)):
                if "week_warrior" not in self.data["achievements"]:
                    self.data["achievements"].append("week_warrior")
                    new_achievements.append(ACHIEVEMENTS["week_warrior"])
        
        return new_achievements
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        workouts = self.data["workouts"]
        if not workouts:
            return {"message": "还没有打卡记录哦，快开始第一次吧！💪"}
        
        recent = [w for w in workouts if 
                  datetime.now() - datetime.fromisoformat(w["date"]) < timedelta(days=7)]
        
        return {
            "total_workouts": len(workouts),
            "total_minutes": self.data["total_minutes"],
            "total_hours": round(self.data["total_minutes"] / 60, 1),
            "this_week": len(recent),
            "achievements": [ACHIEVEMENTS[a] for a in self.data["achievements"]],
            "last_workout": workouts[-1]["date"][:10] if workouts else None
        }
    
    def bmi_calculator(self, height_cm: float, weight_kg: float) -> Dict:
        """BMI计算器"""
        height_m = height_cm / 100
        bmi = weight_kg / (height_m ** 2)
        
        if bmi < 18.5:
            status = "偏瘦"
            advice = "💪 建议适当增加营养摄入，配合力量训练增肌！"
        elif 18.5 <= bmi < 24:
            status = "正常"
            advice = "🌟 继续保持！适度运动维持健康状态！"
        elif 24 <= bmi < 28:
            status = "偏胖"
            advice = "🏃 建议增加有氧运动，注意饮食控制！"
        else:
            status = "肥胖"
            advice = "🔥 建议制定系统的减脂计划，循序渐进！"
        
        return {
            "bmi": round(bmi, 1),
            "status": status,
            "advice": advice,
            "ideal_weight": f"{round(18.5 * height_m**2, 1)} - {round(24 * height_m**2, 1)} kg"
        }
    
    def water_reminder(self, progress: int = 0) -> str:
        """饮水提醒"""
        reminders = [
            "💧 该喝水啦！保持水分充足！",
            "🌊 喝水时间到！一天8杯水哦！",
            "💦 补充点水分吧，身体需要它！",
            "🥤 来杯水，让代谢快起来！",
        ]
        if progress >= 8:
            return "🎉 今天的饮水目标达成！太棒了！"
        return f"{random.choice(reminders)} (已完成 {progress}/8 杯)"
    
    def daily_quote(self) -> str:
        """每日健身名言"""
        quotes = [
            "\"身材不好就去锻炼，别把窘境迁怒于别人。\"",
            "\"你流下的每一滴汗水，都会变成他们羡慕的口水。\"",
            "\"自律给我自由。\"",
            "\"没有什么比健康更珍贵，没有什么比运动更实在。\"",
            "\"今天的努力，是明天的实力。\"",
            "\"不要假装努力，结果不会陪你演戏。\"",
        ]
        return f"📖 今日金句：{random.choice(quotes)}"
    
    def progress_bar(self, current: int, goal: int, width: int = 20) -> str:
        """进度条可视化"""
        progress = min(current / goal, 1.0)
        filled = int(width * progress)
        bar = "█" * filled + "░" * (width - filled)
        percentage = int(progress * 100)
        return f"[{bar}] {percentage}% ({current}/{goal})"


def get_random_workout() -> str:
    """获取随机运动建议"""
    workouts = [
        "🏃 快走20分钟",
        "🧘 瑜伽拉伸15分钟",
        "💪 俯卧撑3组",
        "🏋️ 深蹲20个",
        "🤸 平板支撑1分钟",
        "🚴 骑行30分钟",
        "🏊 游泳20分钟",
        "🧗 爬楼梯10分钟",
    ]
    return f"今天的随机运动：{random.choice(workouts)}"
