"""
WQY - 健身鼓励 CLI 界面
"""
import os
import sys
from .core import WQY, get_random_workout


def clear_screen():
    """清屏"""
    os.system('cls' if os.name == 'nt' else 'clear')


def print_header():
    """打印标题"""
    print("\n" + "="*50)
    print("     💪 WQY - Workout & Quality You 💪")
    print("         你的专属健身小伙伴")
    print("="*50 + "\n")


def print_menu():
    """打印菜单"""
    print("\n📋 功能菜单：")
    print("  1. 🎯 生成健身计划")
    print("  2. ✅ 打卡记录")
    print("  3. 📊 查看统计")
    print("  4. ⚖️  BMI计算器")
    print("  5. 💧 饮水提醒")
    print("  6. 💬 每日鼓励")
    print("  7. 📖 每日金句")
    print("  8. 🎲 随机运动建议")
    print("  9. 🏆 我的成就")
    print("  0. 🚪 退出")


def generate_plan_flow(wqy: WQY):
    """生成计划流程"""
    print("\n🎯 选择你的健身目标：")
    print("  1. 减脂")
    print("  2. 增肌")
    print("  3. 塑形")
    print("  4. 有氧")
    
    choice = input("\n请输入 (1-4): ").strip()
    goals = {"1": "减脂", "2": "增肌", "3": "塑形", "4": "有氧"}
    
    goal = goals.get(choice, "减脂")
    plan = wqy.generate_plan(goal)
    
    print(f"\n{plan['message']}")
    print(f"\n📋 训练内容：")
    for i, (exercise, sets) in enumerate(plan['exercises'], 1):
        print(f"  {i}. {exercise}: {sets}")
    print(f"\n{plan['tips']}")
    input("\n按 Enter 继续...")


def check_in_flow(wqy: WQY):
    """打卡流程"""
    print("\n✅ 健身打卡")
    print(wqy.encourage("start"))
    
    workout_type = input("\n运动类型 (如: 跑步/健身/瑜伽): ").strip() or "健身"
    
    try:
        duration = int(input("运动时长 (分钟): ").strip() or "30")
    except ValueError:
        duration = 30
    
    note = input("备注 (可选): ").strip()
    
    result = wqy.check_in(workout_type, duration, note)
    
    print(f"\n{result['message']}")
    print(result['encouragement'])
    
    if result['new_achievements']:
        print("\n🎉 解锁新成就！")
        for ach in result['new_achievements']:
            print(f"   🏅 {ach['name']}: {ach['desc']}")
    
    print(f"\n📊 累计打卡: {result['total_workouts']} 次")
    print(f"⏱️  累计运动: {result['total_minutes']} 分钟")
    input("\n按 Enter 继续...")


def show_stats(wqy: WQY):
    """显示统计"""
    stats = wqy.get_stats()
    
    if "message" in stats:
        print(f"\n{stats['message']}")
    else:
        print("\n📊 你的健身统计")
        print("-" * 40)
        print(f"💪 总打卡次数: {stats['total_workouts']} 次")
        print(f"⏱️  总运动时长: {stats['total_hours']} 小时")
        print(f"📅 本周打卡: {stats['this_week']} 次")
        print(f"🕐 上次运动: {stats['last_workout']}")
        
        if stats['achievements']:
            print(f"\n🏆 已获得成就 ({len(stats['achievements'])}):")
            for ach in stats['achievements']:
                print(f"   {ach['name']}")
    
    input("\n按 Enter 继续...")


def bmi_calculator_flow(wqy: WQY):
    """BMI计算流程"""
    print("\n⚖️  BMI 计算器")
    
    try:
        height = float(input("请输入身高 (cm): ").strip())
        weight = float(input("请输入体重 (kg): ").strip())
        
        result = wqy.bmi_calculator(height, weight)
        
        print(f"\n📊 计算结果：")
        print(f"   BMI: {result['bmi']}")
        print(f"   状态: {result['status']}")
        print(f"   理想体重: {result['ideal_weight']}")
        print(f"\n💡 {result['advice']}")
    except ValueError:
        print("❌ 请输入有效的数字！")
    
    input("\n按 Enter 继续...")


def water_reminder_flow(wqy: WQY):
    """饮水提醒流程"""
    print("\n💧 饮水提醒")
    
    try:
        progress = int(input("今天已完成几杯水 (0-8): ").strip() or "0")
        print(f"\n{wqy.water_reminder(progress)}")
    except ValueError:
        print(f"\n{wqy.water_reminder(0)}")
    
    input("\n按 Enter 继续...")


def show_achievements(wqy: WQY):
    """显示成就"""
    print("\n🏆 成就系统")
    print("-" * 40)
    
    from .core import ACHIEVEMENTS
    
    unlocked = set(wqy.data.get("achievements", []))
    
    for key, ach in ACHIEVEMENTS.items():
        status = "✅" if key in unlocked else "🔒"
        print(f"{status} {ach['name']}")
        print(f"   {ach['desc']}")
        print()
    
    print(f"解锁进度: {len(unlocked)}/{len(ACHIEVEMENTS)}")
    print(wqy.progress_bar(len(unlocked), len(ACHIEVEMENTS)))
    
    input("\n按 Enter 继续...")


def main():
    """主程序入口"""
    clear_screen()
    print_header()
    
    print("👋 欢迎使用 WQY 健身助手！")
    name = input("请输入你的名字 (默认: 健身达人): ").strip() or "健身达人"
    
    wqy = WQY(name)
    
    while True:
        clear_screen()
        print_header()
        print(f"👤 用户: {name}")
        
        # 显示今日鼓励
        print(f"\n💬 {wqy.encourage()}")
        
        print_menu()
        
        choice = input("\n请选择功能 (0-9): ").strip()
        
        if choice == "1":
            generate_plan_flow(wqy)
        elif choice == "2":
            check_in_flow(wqy)
        elif choice == "3":
            show_stats(wqy)
        elif choice == "4":
            bmi_calculator_flow(wqy)
        elif choice == "5":
            water_reminder_flow(wqy)
        elif choice == "6":
            print(f"\n💬 {wqy.encourage()}")
            input("\n按 Enter 继续...")
        elif choice == "7":
            print(f"\n{wqy.daily_quote()}")
            input("\n按 Enter 继续...")
        elif choice == "8":
            print(f"\n{get_random_workout()}")
            input("\n按 Enter 继续...")
        elif choice == "9":
            show_achievements(wqy)
        elif choice == "0":
            print(f"\n💪 {name}，明天见！坚持就是胜利！")
            break
        else:
            print("\n❌ 无效选择，请重新输入！")
            input("按 Enter 继续...")


if __name__ == '__main__':
    main()
