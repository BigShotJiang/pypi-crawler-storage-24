"""
WQY 健身库测试
"""
import unittest
import os
import tempfile
from wqy import WQY

class TestWQY(unittest.TestCase):
    
    def setUp(self):
        """测试前准备"""
        # 使用临时目录存储测试数据
        self.test_dir = tempfile.mkdtemp()
        self.old_cwd = os.getcwd()
        os.chdir(self.test_dir)
        self.wqy = WQY("测试用户")
    
    def tearDown(self):
        """测试后清理"""
        os.chdir(self.old_cwd)
    
    def test_init(self):
        """测试初始化"""
        self.assertEqual(self.wqy.user_name, "测试用户")
        self.assertEqual(self.wqy.data["total_minutes"], 0)
        self.assertEqual(len(self.wqy.data["workouts"]), 0)
    
    def test_encourage(self):
        """测试鼓励语"""
        msg = self.wqy.encourage("start")
        self.assertIsInstance(msg, str)
        self.assertTrue(len(msg) > 0)
    
    def test_generate_plan(self):
        """测试生成计划"""
        plan = self.wqy.generate_plan("减脂")
        self.assertIn("description", plan)
        self.assertIn("exercises", plan)
        self.assertIn("tips", plan)
        self.assertTrue(len(plan["exercises"]) > 0)
    
    def test_check_in(self):
        """测试打卡"""
        result = self.wqy.check_in("跑步", 30, "测试备注")
        self.assertEqual(result["total_workouts"], 1)
        self.assertEqual(result["total_minutes"], 30)
        self.assertIn("message", result)
        self.assertIn("encouragement", result)
    
    def test_get_stats(self):
        """测试统计"""
        # 空数据测试
        stats = self.wqy.get_stats()
        self.assertIn("message", stats)
        
        # 有数据测试
        self.wqy.check_in("健身", 45)
        stats = self.wqy.get_stats()
        self.assertEqual(stats["total_workouts"], 1)
        self.assertEqual(stats["total_minutes"], 45)
    
    def test_bmi_calculator(self):
        """测试BMI计算"""
        result = self.wqy.bmi_calculator(175, 70)
        self.assertIn("bmi", result)
        self.assertIn("status", result)
        self.assertIn("advice", result)
        self.assertEqual(result["status"], "正常")
    
    def test_water_reminder(self):
        """测试饮水提醒"""
        msg = self.wqy.water_reminder(3)
        self.assertIn("3/8", msg)
        
        # 完成测试
        msg_done = self.wqy.water_reminder(8)
        self.assertIn("达成", msg_done)
    
    def test_daily_quote(self):
        """测试每日金句"""
        quote = self.wqy.daily_quote()
        self.assertIsInstance(quote, str)
        self.assertTrue(len(quote) > 0)
    
    def test_progress_bar(self):
        """测试进度条"""
        bar = self.wqy.progress_bar(50, 100)
        self.assertIn("50%", bar)
        self.assertIn("█", bar)

if __name__ == '__main__':
    unittest.main()
