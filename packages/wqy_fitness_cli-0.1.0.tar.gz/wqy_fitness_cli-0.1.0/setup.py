from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="wqy-fitness-cli",
    version="0.1.0",
    author="OpenClaw",
    author_email="openclaw@example.com",
    description="Workout & Quality You - 你的专属健身鼓励小伙伴",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/openclaw/wqy",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: End Users/Desktop",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.6",
    entry_points={
        "console_scripts": [
            "wqy=wqy.cli:main",
            "fit=wqy.cli:main",
        ],
    },
    keywords="fitness workout health exercise gym motivation",
    project_urls={
        "Bug Reports": "https://github.com/openclaw/wqy/issues",
        "Source": "https://github.com/openclaw/wqy",
    },
)
