# archo

Auto-generate architecture docs from your codebase. Always in sync.

`archo` scans your project, sends the source files to an LLM, and generates an `ARCHO.md` file with a Mermaid architecture diagram and a structured breakdown of routes, dependencies, databases, and pub/sub topics.

```
$ archo
Scanning repo: .

Collected (12 files):
  + src/app.py
  + src/routes/users.py
  + src/services/notification.py
  ...

The following files will be sent to anthropic: [...]
Would you like to continue? [y/n]: y

Generating ARCHO.md...
Done — ARCHO.md written.
```

## Install

```bash
pip install archo
```

For OpenAI support:

```bash
pip install archo[openai]
```

## Quick start

Run `archo` in any project directory:

```bash
cd your-project
archo
```

On first run, you'll be prompted to configure your LLM provider, model, and API key. Config is stored in your system config directory (e.g. `~/.config/archo/config.toml`).

## Supported providers

| Provider | Models                  | Notes |
|----------|-------------------------|-------|
| Anthropic | claude-sonnet-4-6, etc. | Default provider |
| OpenAI | gpt-5.4, etc.           | Requires `pip install archo[openai]` |
| Ollama | Any local model         | Requires a running Ollama instance |

## Commands

```bash
archo              # Generate architecture docs for current directory
archo init         # First-time setup (provider, model, API key)
archo provider     # View or change LLM provider
archo model        # View or change model
archo api-key      # View or change API key
archo llm-host     # View or change Ollama host URL
```

## What it generates

`archo` creates an `ARCHO.md` file containing:

- **Mermaid diagram** — visual map of your service, its routes, outbound calls, databases, and pub/sub topics
- **Routes** — all HTTP endpoints with methods and paths
- **Outbound calls** — services your code talks to and how (REST, gRPC, SDK, etc.)
- **Pub/Sub** — topics your service publishes to and subscribes from
- **Databases** — database types and their collections/tables

## Security

`archo` never sends sensitive files to any LLM provider. The following are always excluded:

- `.env`, `.env.production`, `.env.prod`
- `*.pem`, `*.key`, `*.p12`
- `secrets.yaml`, `credentials.json`

Large files (>50KB), lock files, logs, and common non-source directories (`node_modules`, `.venv`, `__pycache__`, etc.) are also skipped.

## License

MIT