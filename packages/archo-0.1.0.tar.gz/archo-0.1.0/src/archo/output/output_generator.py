from archo.output.mermaid_generator import generate_mermaid
from archo.output.markdown_generator import generate_markdown
from archo.schemas.architecture import ArchitectureResponse


def write_output(data: ArchitectureResponse, output_path: str = "ARCHO.md") -> None:
    """Write the combined Mermaid diagram and markdown detail to a single file."""
    print(f"Generating {output_path}...")
    mermaid = generate_mermaid(data)
    markdown = generate_markdown(data)
    content = "```mermaid\n" + mermaid + "```\n\n" + markdown
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"Done — {output_path} written.")
    except Exception as e:
        raise RuntimeError(f"Failed to write {output_path}: {e}")
