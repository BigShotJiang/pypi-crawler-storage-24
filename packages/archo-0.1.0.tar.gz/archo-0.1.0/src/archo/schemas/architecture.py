from pydantic import BaseModel

class Route(BaseModel):
    method: str
    path: str

class OutboundCall(BaseModel):
    target_service: str
    via: str

class Pubsub(BaseModel):
    subscribes: list[str]
    publishes: list[str]

class Database(BaseModel):
    type: str
    collections_or_tables: list[str]

class ArchitectureResponse(BaseModel):
    service_name: str
    language: str
    framework: str
    routes: list[Route]
    outbound_calls: list[OutboundCall] | None = None
    pubsub: Pubsub | None = None
    databases: list[Database] | None = None
