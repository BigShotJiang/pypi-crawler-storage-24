from archo.schemas.architecture import ArchitectureResponse

class LLMProvider:
    def call(self, file_bundle: str) -> ArchitectureResponse:
        raise NotImplementedError