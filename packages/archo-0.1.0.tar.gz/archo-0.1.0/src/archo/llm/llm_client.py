import os

from archo.llm.providers.llm_base import LLMProvider
from archo.schemas.architecture import ArchitectureResponse


def build_prompt(file_bundle: str) -> str:
    """Build the user prompt wrapping the collected file bundle."""
    return f"Analyze these service files and return the architecture JSON:\n\n{file_bundle}"

def get_provider(provider: str, model, api_key_value: str = None, llm_host: str = None) -> LLMProvider:
    """Return an instance of the configured provider."""
    if provider == "anthropic":
        from archo.llm.providers.anthropic import AnthropicProvider
        return AnthropicProvider(api_key_value, model)
    elif provider == "openai":
        from archo.llm.providers.openai import OpenAIProvider
        return OpenAIProvider(api_key_value, model)
    elif provider == "ollama":
        from archo.llm.providers.ollama import OllamaProvider
        return OllamaProvider(model, llm_host)
    else:
        raise ValueError(f"Unknown LLM_PROVIDER '{provider}'. Supported: anthropic, openai, ollama")


def call_llm(file_bundle: str, provider: str, model: str, api_key_value: str = None, llm_host: str = None) -> ArchitectureResponse:
    """Send the file bundle to the configured LLM provider and return parsed architecture JSON."""
    provider = get_provider(provider, model, api_key_value, llm_host)
    prompt = build_prompt(file_bundle)

    architecture_response = provider.call(prompt)

    return architecture_response
