#!/usr/bin/env python3
"""
List of path for nomad examples to run test in nomad.
"""
# -*- coding: utf-8 -*-
#
# Copyright The NOMAD Authors.
#
# This file is part of NOMAD. See https://nomad-lab.eu for further info.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
#

import os


STS_DEFAULT_CONF_EXAMPLE_PATH = os.path.join(
    os.path.dirname(__file__), "example_uploads", "sts", "STSDefaultExample"
)
STS_CUSTOMIZED_EXAMPLE_PATH = os.path.join(
    os.path.dirname(__file__), "example_uploads", "sts", "STSExampleWithCustomization"
)

STM_DEFAULT_CONF_EXAMPLE_PATH = os.path.join(
    os.path.dirname(__file__), "example_uploads", "stm", "STMDefaultExample"
)
STM_CUSTOMIZED_EXAMPLE_PATH = os.path.join(
    os.path.dirname(__file__), "example_uploads", "stm", "STMExampleWithCustomization"
)

AFM_DEFAULT_CONF_EXAMPLE_PATH = os.path.join(
    os.path.dirname(__file__), "example_uploads", "afm", "AFMDefaultExample"
)
AFM_CUSTOMIZED_EXAMPLE_PATH = os.path.join(
    os.path.dirname(__file__), "example_uploads", "afm", "AFMExampleWithCustomization"
)
