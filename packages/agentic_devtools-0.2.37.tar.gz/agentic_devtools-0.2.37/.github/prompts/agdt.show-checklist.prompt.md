---
agent: agdt.show-checklist
---
