from pathlib import Path

RUNS_DIR_NAME = "runs"
CONFIG_SNAPSHOT_NAME = "config.snapshot.yaml"
METADATA_NAME = "metadata.json"
STATUS_NAME = "status.json"
RUNTIME_NAME = "runtime.json"
SUMMARY_NAME = "summary.json"
SUMMARY_MIN_NAME = "summary_min.json"
EVENTS_NAME = "events.jsonl"
LOGS_DIR_NAME = "logs"
STDOUT_LOG_NAME = "stdout.log"
STDERR_LOG_NAME = "stderr.log"
ARTIFACTS_DIR_NAME = "artifacts"
METRICS_DIR_NAME = "metrics"
JOB_SCRIPT_NAME = "job.sbatch"
LOCAL_PID_NAME = "local.pid"
LOCAL_EXIT_CODE_NAME = "local.exit_code"

ALLOWED_PLACEHOLDERS = {"config", "run_dir", "seed", "project_root"}

DEFAULT_RUNS_DIR = Path(RUNS_DIR_NAME)
JSON_SCHEMA_VERSION = "one-run/v1"
AUTOMATION_ENV_VAR = "ONE_RUN_AUTOMATION"
