from __future__ import annotations

from datetime import datetime


def make_run_id(experiment_name: str, now: datetime | None = None) -> str:
    _ = experiment_name
    ts = (now or datetime.now()).strftime("%m%d%H%M%S")
    return ts
