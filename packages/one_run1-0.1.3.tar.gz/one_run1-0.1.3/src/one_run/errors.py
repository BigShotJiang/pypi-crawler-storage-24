class OneRunError(Exception):
    """base one-run error"""


class ManifestError(OneRunError):
    """manifest parsing/validation errors"""


class TemplateError(OneRunError):
    """entrypoint templating errors"""


class BackendError(OneRunError):
    """backend runtime errors"""
