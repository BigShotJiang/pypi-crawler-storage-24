from __future__ import annotations

from datetime import datetime
from typing import Any


def iso_short(value: Any) -> str:
    if value is None:
        return "-"
    if isinstance(value, datetime):
        return value.replace(microsecond=0).isoformat()
    if isinstance(value, str):
        parsed = datetime.fromisoformat(value)
        return parsed.replace(microsecond=0).isoformat()
    return str(value)
