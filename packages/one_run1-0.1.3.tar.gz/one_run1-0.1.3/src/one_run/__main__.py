from one_run.cli import main

raise SystemExit(main())
