from __future__ import annotations

from functools import wraps
from pathlib import Path
from typing import Any, Callable, Dict, Optional, TypeVar

from .client import CanopyClient
from .core import authorize_action

T = TypeVar("T")


def _default_payload(args: tuple[Any, ...], kwargs: Dict[str, Any]) -> Any:
    if len(args) == 1 and isinstance(args[0], str) and not kwargs:
        return args[0]
    return {"args": list(args), "kwargs": dict(kwargs)}


def guard_tool(
    *,
    agent_ctx: Optional[Dict[str, Any]] = None,
    action_type: Optional[str] = None,
    payload_builder: Optional[Callable[..., Any]] = None,
    policy_file: str | Path | None = None,
    audit_log_path: str | Path | None = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator that gates tool execution using local `authorize_action`."""

    def _decorator(fn: Callable[..., T]) -> Callable[..., T]:
        atype = action_type or fn.__name__

        @wraps(fn)
        def _wrapped(*args: Any, **kwargs: Any) -> T:
            payload = payload_builder(*args, **kwargs) if payload_builder else _default_payload(args, kwargs)
            decision = authorize_action(
                agent_ctx or {},
                atype,
                payload,
                policy_file=policy_file,
                audit_log_path=audit_log_path,
            )
            d = (decision.get("decision") or "").upper()
            if d != "ALLOW":
                raise PermissionError(decision.get("reason") or "Blocked by policy")
            return fn(*args, **kwargs)

        return _wrapped

    return _decorator


def guard_tool_http(
    *,
    client: CanopyClient,
    agent_ctx: Dict[str, Any],
    action_type: str,
    payload_builder: Optional[Callable[..., Any]] = None,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """Decorator that gates execution via the HTTP gateway."""

    def _decorator(fn: Callable[..., T]) -> Callable[..., T]:
        @wraps(fn)
        def _wrapped(*args: Any, **kwargs: Any) -> T:
            payload = payload_builder(*args, **kwargs) if payload_builder else _default_payload(args, kwargs)
            decision = client.authorize_action(agent_ctx, action_type, payload)
            d = (decision.get("decision") or "").upper()
            if d != "ALLOW":
                raise PermissionError(decision.get("reason") or "Blocked by policy")
            return fn(*args, **kwargs)

        return _wrapped

    return _decorator

