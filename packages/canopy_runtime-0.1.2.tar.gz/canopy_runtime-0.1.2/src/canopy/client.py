from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class CanopyClient:
    base_url: str = "http://127.0.0.1:8010"
    timeout_s: float = 5.0
    headers: Optional[Dict[str, str]] = None

    # For tests or advanced usage you can inject a TestClient/httpx-style client.
    http_client: Any = None

    def authorize_action(self, agent_ctx: Dict[str, Any], action_type: str, action_payload: Any) -> Dict[str, Any]:
        payload = {"agent_ctx": agent_ctx or {}, "action_type": action_type, "action_payload": action_payload}
        if self.http_client is not None:
            res = self.http_client.post("/authorize_action", json=payload)
            res.raise_for_status()
            return res.json()

        try:
            import requests  # type: ignore
        except ModuleNotFoundError as e:
            raise ModuleNotFoundError(
                "Optional dependency missing: install HTTP client support with `pip install canopy-runtime[http]`"
            ) from e

        url = self.base_url.rstrip("/") + "/authorize_action"
        res = requests.post(url, json=payload, headers=self.headers, timeout=self.timeout_s)
        res.raise_for_status()
        return res.json()
