from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Dict


def _canonical_json(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str).encode("utf-8")


def generate_avid(agent_ctx: Dict[str, Any]) -> str:
    """Generate an internal AVID for audit correlation.

    If `created_at` is missing, it is set to a UTC ISO timestamp, which makes the AVID unique
    but not stable across processes. Provide a stable `created_at` if you need stability.
    """
    ctx = dict(agent_ctx or {})
    public_key = str(ctx.get("public_key", "") or "")
    created_at = ctx.get("created_at")
    if not created_at:
        created_at = datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")
        ctx["created_at"] = created_at

    payload = {
        "public_key": public_key,
        "metadata": {k: v for k, v in ctx.items() if k not in {"public_key"}},
        "created_at": created_at,
    }
    digest = hashlib.sha256(_canonical_json(payload)).hexdigest()
    return f"AVID-{digest}"

