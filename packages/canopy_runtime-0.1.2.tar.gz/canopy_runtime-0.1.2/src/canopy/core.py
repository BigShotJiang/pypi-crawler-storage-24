from __future__ import annotations

import os
import re
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

from .audit import HashChainAuditLog
from .identity import generate_avid


class Decision(str, Enum):
    ALLOW = "ALLOW"
    DENY = "DENY"
    REQUIRE_APPROVAL = "REQUIRE_APPROVAL"


def _parse_minimal_yaml(text: str) -> Dict[str, Any]:
    """Parse a tiny subset of YAML without external dependencies.

    Supports:
      rules:
        - action_type: "execute_shell"
          deny_if: "rm -rf"
        - action_type: "execute_shell"
          deny_if:
            - "sudo"
            - "mkfs"
          deny_regex: 'rm\\s+-rf'
        - action_type: "call_external_api"
          require_approval: true
    """
    lines = [ln.rstrip("\n") for ln in text.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    out: Dict[str, Any] = {"rules": []}
    rules: List[Dict[str, Any]] = out["rules"]

    def parse_scalar(v: str) -> Any:
        v = v.strip()
        if v.lower() in {"true", "false"}:
            return v.lower() == "true"
        if (v.startswith('"') and v.endswith('"')) or (v.startswith("'") and v.endswith("'")):
            return v[1:-1]
        return v

    i = 0
    in_rules = False
    current: Optional[Dict[str, Any]] = None
    while i < len(lines):
        ln = lines[i]
        stripped = ln.lstrip(" ")
        indent = len(ln) - len(stripped)
        if indent == 0 and stripped == "rules:":
            in_rules = True
            current = None
            i += 1
            continue

        if not in_rules:
            i += 1
            continue

        if stripped.startswith("- "):
            current = {}
            rules.append(current)
            rest = stripped[2:].strip()
            if rest and ":" in rest:
                k, v = rest.split(":", 1)
                current[k.strip()] = parse_scalar(v)
            i += 1
            continue

        if current is not None and ":" in stripped:
            k, v = stripped.split(":", 1)
            key = k.strip()
            val = v.strip()
            if val == "":
                items: List[Any] = []
                i += 1
                while i < len(lines):
                    ln2 = lines[i]
                    stripped2 = ln2.lstrip(" ")
                    indent2 = len(ln2) - len(stripped2)
                    if indent2 <= indent:
                        break
                    if stripped2.startswith("- "):
                        items.append(parse_scalar(stripped2[2:]))
                    i += 1
                current[key] = items
                continue
            current[key] = parse_scalar(val)
        i += 1
    return out


def load_policies(policy_file: str | Path) -> Dict[str, Any]:
    return _parse_minimal_yaml(Path(policy_file).read_text(encoding="utf-8"))


def _default_policy_file() -> Path:
    return Path(__file__).with_name("policies") / "default.yaml"


def _payload_text(payload: Any) -> str:
    if payload is None:
        return ""
    if isinstance(payload, str):
        return payload
    if isinstance(payload, dict):
        # Prefer deterministic rendering for matching/logging.
        try:
            import json

            return json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)
        except Exception:
            return str(payload)
    return str(payload)


def _match_text(action_type: str, action_payload: Any) -> str:
    """Extract the primary matching string for a given action type.

    This keeps policies stable when payloads are structured dicts.
    """
    if isinstance(action_payload, dict):
        if action_type == "execute_shell":
            return str(action_payload.get("command", "") or "")
        if action_type == "modify_file":
            return str(action_payload.get("path", "") or "")
        if action_type == "call_external_api":
            return str(action_payload.get("url", "") or action_payload.get("endpoint", "") or "")
    return _payload_text(action_payload)


def _safe_paths(ctx: Dict[str, Any]) -> List[str]:
    sp = ctx.get("safe_paths")
    if isinstance(sp, list):
        return [str(x) for x in sp]
    return []


def authorize_action(
    agent_ctx: Dict[str, Any],
    action_type: str,
    action_payload: Any,
    *,
    policy_file: str | Path | None = None,
    audit_log_path: str | Path | None = None,
) -> Dict[str, Any]:
    """Authorize an agent action and append a hash-chain audit entry."""
    ctx = dict(agent_ctx or {})
    avid = str(ctx.get("avid") or "") or generate_avid(ctx)

    pf = Path(policy_file) if policy_file else _default_policy_file()
    policies = load_policies(pf)
    rules = policies.get("rules") if isinstance(policies.get("rules"), list) else []

    decision = Decision.ALLOW
    reason = "Allowed by default"

    payload_text = _match_text(action_type, action_payload).lower()
    for rule in rules:
        if not isinstance(rule, dict):
            continue
        if str(rule.get("action_type", "")).strip() != action_type:
            continue

        if rule.get("require_approval") is True:
            decision = Decision.REQUIRE_APPROVAL
            reason = "Policy requires approval"
            break

        require_if = rule.get("require_approval_if")
        require_items: List[str]
        if isinstance(require_if, str):
            require_items = [require_if]
        elif isinstance(require_if, list):
            require_items = [str(x) for x in require_if if str(x).strip()]
        else:
            require_items = []
        for item in require_items:
            if item.lower() in payload_text:
                decision = Decision.REQUIRE_APPROVAL
                reason = f"Policy requires approval: matched '{item}'"
                break
        if decision == Decision.REQUIRE_APPROVAL:
            break

        require_regex = rule.get("require_approval_regex")
        req_regexes: List[str]
        if isinstance(require_regex, str):
            req_regexes = [require_regex]
        elif isinstance(require_regex, list):
            req_regexes = [str(x) for x in require_regex if str(x).strip()]
        else:
            req_regexes = []
        for rx in req_regexes:
            if re.search(rx, payload_text):
                decision = Decision.REQUIRE_APPROVAL
                reason = f"Policy requires approval: matched /{rx}/"
                break
        if decision == Decision.REQUIRE_APPROVAL:
            break

        deny_if = rule.get("deny_if")
        deny_items: List[str]
        if isinstance(deny_if, str):
            deny_items = [deny_if]
        elif isinstance(deny_if, list):
            deny_items = [str(x) for x in deny_if if str(x).strip()]
        else:
            deny_items = []
        for item in deny_items:
            if item.lower() in payload_text:
                decision = Decision.DENY
                reason = f"Denied by policy: matched '{item}'"
                break
        if decision == Decision.DENY:
            break

        allow_if = rule.get("allow_if")
        if allow_if == "safe_paths":
            if isinstance(action_payload, dict):
                path = str(action_payload.get("path", "") or "")
            else:
                path = str(action_payload or "")
            safe_prefixes = _safe_paths(ctx)
            if not safe_prefixes:
                decision = Decision.REQUIRE_APPROVAL
                reason = "Policy requires approval: safe_paths not configured"
            elif any(path.startswith(prefix) for prefix in safe_prefixes):
                decision = Decision.ALLOW
                reason = "Allowed by policy: safe_paths"
            else:
                decision = Decision.DENY
                reason = "Denied by policy: unsafe path"
            break

        deny_regex = rule.get("deny_regex")
        regexes: List[str]
        if isinstance(deny_regex, str):
            regexes = [deny_regex]
        elif isinstance(deny_regex, list):
            regexes = [str(x) for x in deny_regex if str(x).strip()]
        else:
            regexes = []
        for rx in regexes:
            if re.search(rx, payload_text):
                decision = Decision.DENY
                reason = f"Denied by policy: matched /{rx}/"
                break
        if decision == Decision.DENY:
            break

    alp = Path(audit_log_path) if audit_log_path else Path(os.getenv("CANOPY_AUDIT_LOG_PATH", "audit.log"))
    HashChainAuditLog(alp).append(avid=avid, action_type=action_type, decision=decision.value, reason=reason)
    return {"decision": decision.value, "reason": reason, "avid": avid}
