"""Canopy Agent Safety Runtime (minimal).

Core primitive:
  - authorize_action(agent_ctx, action_type, action_payload) -> decision dict
"""

from .client import CanopyClient
from .core import Decision, authorize_action
from .middleware import guard_tool, guard_tool_http

__all__ = ["CanopyClient", "Decision", "authorize_action", "guard_tool", "guard_tool_http"]

