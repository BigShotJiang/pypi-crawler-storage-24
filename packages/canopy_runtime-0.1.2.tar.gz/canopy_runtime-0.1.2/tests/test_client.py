from __future__ import annotations

from fastapi.testclient import TestClient

from canopy.client import CanopyClient
from canopy.service import app


def test_client_against_service(monkeypatch, tmp_path):
    monkeypatch.setenv("CANOPY_AUDIT_LOG_PATH", str(tmp_path / "audit.log"))
    http = TestClient(app)
    client = CanopyClient(http_client=http)
    res = client.authorize_action(
        {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"},
        "call_external_api",
        {"url": "https://example.com"},
    )
    assert res["decision"] == "REQUIRE_APPROVAL"

