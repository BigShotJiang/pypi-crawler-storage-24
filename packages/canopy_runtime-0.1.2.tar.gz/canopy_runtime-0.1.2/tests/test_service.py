from __future__ import annotations

from fastapi.testclient import TestClient

from canopy.service import app


def test_service_authorize_action(monkeypatch, tmp_path):
    monkeypatch.setenv("CANOPY_AUDIT_LOG_PATH", str(tmp_path / "audit.log"))
    client = TestClient(app)
    res = client.post(
        "/authorize_action",
        json={
            "agent_ctx": {"public_key": "pk", "created_at": "2026-03-15T00:00:00Z"},
            "action_type": "execute_shell",
            "action_payload": "rm -rf /",
        },
    )
    assert res.status_code == 200
    data = res.json()
    assert data["decision"] == "DENY"

