import numpy as np

from pyfr.mpiutil import get_comm_rank_root, mpi
from pyfr.plugins.base import (BaseSolnPlugin, DatasetAppender,
                               init_csv, open_hdf5_a)
from pyfr.quadrules.surface import SurfaceIntegrator


class FluidForceIntegrator(SurfaceIntegrator):
    def __init__(self, cfg, cfgsect, system, bcname, morigin):
        surf_list = system.mesh.bcon.get(bcname, [])
        surf_list = [(etype, fidx, eidxs) for etype, eidxs, fidx in surf_list]

        super().__init__(cfg, cfgsect, system.ele_map, surf_list, flags='s')

        if surf_list and morigin is not None:
            self.rfpts = {k: loc - morigin for k, loc in self.locs.items()}


class FluidForcePlugin(BaseSolnPlugin):
    name = 'fluidforce'
    systems = ['ac-euler', 'ac-navier-stokes', 'euler', 'navier-stokes']
    formulations = ['dual', 'std']
    dimensions = [2, 3]

    def __init__(self, intg, cfgsect, suffix):
        super().__init__(intg, cfgsect, suffix)

        comm, rank, root = get_comm_rank_root()

        # Output frequency
        self.nsteps = self.cfg.getint(cfgsect, 'nsteps')

        # Check if we need to compute viscous force
        self._viscous = 'navier-stokes' in intg.system.name

        # Check if the system is incompressible
        self._ac = intg.system.name.startswith('ac')

        # Viscous correction
        self._viscorr = self.cfg.get('solver', 'viscosity-correction', 'none')

        # Constant variables
        self._constants = self.cfg.items_as('constants', float)

        # Underlying elements class
        self.elementscls = intg.system.elementscls

        # Moments
        morigin = None
        mcomp = 3 if self.ndims == 3 else 1
        self._mcomp = mcomp if self.cfg.hasopt(cfgsect, 'morigin') else 0
        if self._mcomp:
            morigin = np.array(self.cfg.getliteral(cfgsect, 'morigin'))
            if len(morigin) != self.ndims:
                raise ValueError(f'morigin must have {self.ndims} components')

        # See which ranks have the boundary
        bcranks = comm.gather(suffix in intg.system.mesh.bcon, root=root)

        # The root rank needs to open the output file
        if rank == root:
            if not any(bcranks):
                raise RuntimeError(f'Boundary {suffix} does not exist')

            match self.cfg.get(cfgsect, 'file-format', 'csv'):
                case 'csv':
                    self._init_csv()
                case 'hdf5':
                    self._init_hdf5()
                case _:
                    raise ValueError('Invalid file format')

        # Set interpolation matrices and quadrature weights
        self.ff_int = FluidForceIntegrator(self.cfg, cfgsect, intg.system,
                                           suffix, morigin)

    @property
    def _header(self):
        header = ['t', 'px', 'py', 'pz'][:self.ndims + 1]
        if self._mcomp:
            header += ['mpx', 'mpy', 'mpz'][3 - self._mcomp:]
        if self._viscous:
            header += ['vx', 'vy', 'vz'][:self.ndims]
            if self._mcomp:
                header += ['mvx', 'mvy', 'mvz'][3 - self._mcomp:]

        return ','.join(header)

    def _init_csv(self):
        self.csv = init_csv(self.cfg, self.cfgsect, self._header, nflush=1)
        self._write = self._write_csv

    def _write_csv(self, t, forces):
        self.csv(t, *forces.ravel())

    def _init_hdf5(self):
        outf = open_hdf5_a(self.cfg.get(self.cfgsect, 'file'))
        nvars = 1 + (2 if self._viscous else 1)*(self.ndims + self._mcomp)

        dset = self.cfg.get(self.cfgsect, 'file-dataset')
        if dset in outf:
            ff = outf[dset]

            if ff.shape[1] != nvars:
                raise ValueError('Invalid dataset')
        else:
            ff = outf.create_dataset(dset, (0, nvars), float,
                                     chunks=(128, nvars),
                                     maxshape=(None, nvars))
            ff.dims[1].label = self._header

        self._forces = DatasetAppender(ff)
        self._write = self._write_hdf5

    def _write_hdf5(self, t, forces):
        self._forces(np.concatenate(([t], forces.ravel())))

    def __call__(self, intg):
        # Return if no output is due
        if intg.nacptsteps % self.nsteps:
            return

        # MPI info
        comm, rank, root = get_comm_rank_root()

        ndims, nvars, mcomp = self.ndims, self.nvars, self._mcomp
        pidx = 0 if self._ac else -1

        # Solution matrices indexed by element type
        solns = dict(zip(intg.system.ele_types, intg.soln))

        # Corrected solution gradients indexed by element type
        if self._viscous:
            grads = dict(zip(intg.system.ele_types, intg.grad_soln))

        # Force and moment vectors
        fm = np.zeros((2 if self._viscous else 1, ndims + mcomp))

        for (etype, fidx), m0 in self.ff_int.m0.items():
            nfpts, nupts = m0.shape

            # Extract the relevant elements from the solution
            uupts = solns[etype][..., self.ff_int.eidxs[etype, fidx]]

            # Interpolate to the face
            ufpts = m0 @ uupts.reshape(nupts, -1)
            ufpts = ufpts.reshape(nfpts, nvars, -1)
            ufpts = ufpts.swapaxes(0, 1)

            # Compute the pressure
            p = self.elementscls.con_to_pri(ufpts, self.cfg)[pidx]

            # Get the quadrature weights and normal vectors
            qwts = self.ff_int.qwts[etype, fidx]
            norms = self.ff_int.norms[etype, fidx]

            # Do the quadrature
            fm[0, :ndims] += np.einsum('i...,ij,jik', qwts, p, norms)

            if self._viscous:
                # Corrected gradients at solution points
                duupts = grads[etype][..., self.ff_int.eidxs[etype, fidx]]
                duupts = duupts.reshape(ndims, nupts, -1)

                # Interpolate gradient to flux points
                dufpts = np.array([m0 @ du for du in duupts])
                dufpts = dufpts.reshape(ndims, nfpts, nvars, -1)
                dufpts = dufpts.swapaxes(1, 2)

                # Viscous stress
                if self._ac:
                    vis = self.ac_stress_tensor(dufpts)
                else:
                    vis = self.stress_tensor(ufpts, dufpts)

                # Do the quadrature
                fm[1, :ndims] += np.einsum('i...,klij,jil', qwts, vis, norms)

            if self._mcomp:
                # Get the flux points positions relative to the moment origin
                rfpts = self.ff_int.rfpts[etype, fidx]

                # Do the cross product with the normal vectors
                rcn = np.atleast_3d(np.cross(rfpts, norms))

                # Pressure force moments
                fm[0, ndims:] += np.einsum('i...,ij,jik->k', qwts, p, rcn)

                if self._viscous:
                    # Normal viscous force at each flux point
                    viscf = np.einsum('ijkl,lkj->lki', vis, norms)

                    # Normal viscous force moments at each flux point
                    rcf = np.atleast_3d(np.cross(rfpts, viscf))

                    # Do the quadrature
                    fm[1, ndims:] += np.einsum('i,jik->k', qwts, rcf)

        # Reduce and output if we're the root rank
        if rank != root:
            comm.Reduce(fm, None, op=mpi.SUM, root=root)
        else:
            comm.Reduce(mpi.IN_PLACE, fm, op=mpi.SUM, root=root)

            self._write(intg.tcurr, fm)

    def stress_tensor(self, u, du):
        c = self._constants

        # Density, energy
        rho, E = u[0], u[-1]

        # Gradient of density and momentum
        gradrho, gradrhou = du[:, 0], du[:, 1:-1]

        # Gradient of velocity
        gradu = (gradrhou - gradrho[:, None]*u[None, 1:-1]/rho) / rho

        # Bulk tensor
        bulk = np.eye(self.ndims)[:, :, None, None]*np.trace(gradu)

        # Viscosity
        mu = c['mu']

        if self._viscorr == 'sutherland':
            cpT = c['gamma']*(E/rho - 0.5*np.sum(u[1:-1]**2, axis=0)/rho**2)
            Trat = cpT/c['cpTref']
            mu *= (c['cpTref'] + c['cpTs'])*Trat**1.5 / (cpT + c['cpTs'])

        return -mu*(gradu + gradu.swapaxes(0, 1) - 2/3*bulk)

    def ac_stress_tensor(self, du):
        # Gradient of velocity and kinematic viscosity
        gradu, nu = du[:, 1:], self._constants['nu']

        return -nu*(gradu + gradu.swapaxes(0, 1))
