from setuptools import setup, find_packages

setup(
    name="pyjms",
    version="0.0.1",
    description="A Python library for working with Java Message Service (JMS) APIs.",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    author="Til Schwarze",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[],
    license="MIT",
)
