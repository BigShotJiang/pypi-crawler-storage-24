raise ImportError(
    "neurram has been renamed to neuram. Please update your dependency:\n"
    "  pip install neuram\n"
    "  from neuram import Brain, MemoryType, Engram"
)
