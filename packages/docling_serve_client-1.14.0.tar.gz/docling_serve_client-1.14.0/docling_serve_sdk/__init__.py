"""
Docling Serve SDK v2.0.0

A Python SDK for interacting with Docling Serve API v1.14.

Usage
-----
>>> from docling_serve_sdk import DoclingClient
>>> with DoclingClient("http://localhost:5001", api_key="...") as client:
...     health = client.health_check()
...     result = client.convert_file("document.pdf")
"""

from .client import (
    DoclingClient,
    DoclingError,
    DoclingAPIError,
    DoclingTimeoutError,
    DoclingConnectionError,
    DoclingValidationError,
    RequestHook,
    ResponseHook,
    ErrorHook,
)
from .models import (
    # Enums
    ConversionStatus,
    ImageRefMode,
    InferenceFramework,
    InputFormat,
    OCREngine,
    OutputFormat,
    PdfBackend,
    ProcessingPipeline,
    ResponseFormat,
    TableFormerMode,
    TargetName,
    TaskType,
    TransformersModelType,
    VlmEngineType,
    VlmModelType,
    # Source models
    FileSourceRequest,
    HttpSourceRequest,
    S3SourceRequest,
    SourceRequest,
    # Target models
    InBodyTarget,
    ZipTarget,
    S3Target,
    PutTarget,
    TargetRequest,
    # Picture description models
    PictureDescriptionLocal,
    PictureDescriptionApi,
    # Request options
    ConvertDocumentsRequestOptions,
    ConvertDocumentsRequest,
    # Response models
    ConvertDocumentResponse,
    PresignedUrlConvertDocumentResponse,
    ExportDocumentResponse,
    ExportResult,
    ErrorItem,
    ProfilingItem,
    HealthCheckResponse,
    TaskProcessingMeta,
    TaskStatusResponse,
    ClearResponse,
    # Chunker options & requests
    HierarchicalChunkerOptions,
    HybridChunkerOptions,
    HierarchicalChunkerOptionsDocumentsRequest,
    HybridChunkerOptionsDocumentsRequest,
    ChunkedDocumentResultItem,
    ChunkDocumentResponse,
    # Validation
    HTTPValidationError,
    ValidationErrorDetail,
)

__version__ = "1.14.0"
__all__ = [
    # Client
    "DoclingClient",
    # Exceptions
    "DoclingError",
    "DoclingAPIError",
    "DoclingTimeoutError",
    "DoclingConnectionError",
    "DoclingValidationError",
    # Enterprise hooks
    "RequestHook",
    "ResponseHook",
    "ErrorHook",
    # Enums
    "ConversionStatus",
    "ImageRefMode",
    "InferenceFramework",
    "InputFormat",
    "OCREngine",
    "OutputFormat",
    "PdfBackend",
    "ProcessingPipeline",
    "ResponseFormat",
    "TableFormerMode",
    "TargetName",
    "TaskType",
    "TransformersModelType",
    "VlmEngineType",
    "VlmModelType",
    # Source models
    "FileSourceRequest",
    "HttpSourceRequest",
    "S3SourceRequest",
    "SourceRequest",
    # Target models
    "InBodyTarget",
    "ZipTarget",
    "S3Target",
    "PutTarget",
    "TargetRequest",
    # Request models
    "ConvertDocumentsRequestOptions",
    "ConvertDocumentsRequest",
    # Picture description models
    "PictureDescriptionLocal",
    "PictureDescriptionApi",
    # Response models
    "ConvertDocumentResponse",
    "PresignedUrlConvertDocumentResponse",
    "ExportDocumentResponse",
    "ExportResult",
    "ErrorItem",
    "ProfilingItem",
    "HealthCheckResponse",
    "TaskProcessingMeta",
    "TaskStatusResponse",
    "ClearResponse",
    # Chunker
    "HierarchicalChunkerOptions",
    "HybridChunkerOptions",
    "HierarchicalChunkerOptionsDocumentsRequest",
    "HybridChunkerOptionsDocumentsRequest",
    "ChunkedDocumentResultItem",
    "ChunkDocumentResponse",
    # Validation
    "HTTPValidationError",
    "ValidationErrorDetail",
]