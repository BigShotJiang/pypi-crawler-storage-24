from setuptools import setup, find_packages

setup(
    name="blang-lang",
    version="1.0.0",
    author="Bernardo",
    description="BLang - Uma linguagem de programação simples em português",
    long_description=open("README.md", encoding="utf-8").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    python_requires=">=3.7",
    entry_points={
        "console_scripts": [
            "blang=blang.__main__:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
