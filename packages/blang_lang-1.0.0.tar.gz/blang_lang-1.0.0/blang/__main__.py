import sys
import os
from .interpreter import BLang

def main():
    lang = BLang()

    if len(sys.argv) > 1:
        arquivo = sys.argv[1]
        if not arquivo.endswith(".bl"):
            print("[BLang] Arquivos BLang devem ter extensão .bl")
            sys.exit(1)
        if not os.path.exists(arquivo):
            print(f"[BLang] Arquivo '{arquivo}' não encontrado.")
            sys.exit(1)
        try:
            with open(arquivo, "r", encoding="utf-8") as f:
                codigo = f.read()
            lang.executar(codigo)
        except Exception as e:
            print(f"Erro: {e}")
            sys.exit(1)
    else:
        print("BLang 1.0 - Digite 'sair' para sair")
        print("--------------------------------------")
        while True:
            try:
                linha = input(">> ")
                if linha.strip().lower() == "sair":
                    break
                if linha.strip():
                    lang.executar(linha)
            except KeyboardInterrupt:
                print()
                break
            except Exception as e:
                print(f"Erro: {e}")

if __name__ == "__main__":
    main()
