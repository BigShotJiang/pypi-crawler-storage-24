# BLang 🇧🇷

Uma linguagem de programação simples escrita em português.

## Instalação

```
pip install blang-lang
```

## Como usar

Crie um arquivo `teste.bl` e rode:

```
blang teste.bl
```

Ou modo interativo:

```
blang
```

## Sintaxe

```
# variável
var nome = "Bernardo"
var vida = 100

# imprimir
fala "Olá " + nome
fala vida

# condicional
se vida > 50 entao
  fala "tá vivo!"
senao
  fala "game over"
fim

# loop
repete 3 vezes
  fala "oi"
fim

# função
funcao somar(a, b)
  retorna a + b
fim

var resultado = somar(10, 20)
fala resultado
```

## Funções nativas

| Função | Descrição |
|--------|-----------|
| `texto(x)` | Converte para texto |
| `num(x)` | Converte para número |
| `tipo(x)` | Retorna o tipo do valor |
| `tamanho(x)` | Retorna o tamanho do texto |
