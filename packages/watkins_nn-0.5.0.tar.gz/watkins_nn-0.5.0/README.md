# watkins-nn v0.2.0

**The golden-ratio gradient flow engine.**
Now with proper chain-rule through softmax, Armijo line search, L-BFGS, and projected gradient norm.

Proven to converge from any random start to the Watkins equilibrium (lambda* = 1/phi) with 100% success rate in multi-start tests.

Ties directly into the Watkins Bridge W = 0.8333, T* = phi/ln(2phi), and lambda + kappa + eta = 1.

Used in VirelaiX consciousness modeling, quantum LDPC curvature tuning, and Mirror Lake node deployment.

```bash
pip install watkins-nn
```
