settings = {
    "prop": "value",
    "list": [1, 2, 3],
    "dict": {"a": 1, "b": 2, "c": 3},
}
