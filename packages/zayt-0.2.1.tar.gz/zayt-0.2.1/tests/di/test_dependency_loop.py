from typing import Annotated

import pytest

from zayt.di.container import Container
from zayt.di.error import DependencyLoopError
from zayt.di.inject import Inject


class Service1:
    service2: Annotated["Service2", Inject]


class Service2:
    service1: Annotated[Service1, Inject]


def factory1(service2: Service2) -> Service1:
    instance = Service1()
    instance.service2 = service2
    return instance


def factory2(service1: Service1) -> Service2:
    instance =  Service2()
    instance.service1 = service1
    return instance


async def test_service_class(ioc: Container):
    ioc.register(Service1)
    ioc.register(Service2)

    service1 = await ioc.get(Service1)
    service2 = await ioc.get(Service2)

    assert service1 is service2.service1
    assert service2 is service1.service2


async def test_service_factory(ioc: Container):
    ioc.register(factory1)
    ioc.register(factory2)

    with pytest.raises(DependencyLoopError):
        await ioc.get(Service1)
