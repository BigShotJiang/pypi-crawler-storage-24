from typing import Annotated

import pytest

from zayt.di.container import Container
from zayt.di.error import IncompatibleDependencyScopeError
from zayt.di.inject import Inject


class Service1:
    pass


class Service2:
    service1: Annotated[Service1, Inject]


class Service3:
    service2: Annotated[Service2, Inject]


async def test_service_chain_with_mixed_scopes(ioc: Container):
    ioc.register(Service1, scoped=True)
    ioc.register(Service2, scoped=False)
    ioc.register(Service3, scoped=True)

    context = object()

    with pytest.raises(IncompatibleDependencyScopeError):
        await ioc.get(Service3, context=context)
