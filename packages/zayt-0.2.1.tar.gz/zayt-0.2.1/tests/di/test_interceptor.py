from typing import Any

from zayt.di.container import Container


class MyInterceptor:
    async def intercept(self, instance: Any, _service_type: type):
        setattr(instance, "intercepted", True)


class MyService:
    pass


async def test_intercept(ioc: Container):
    ioc.register(MyService)
    ioc.interceptor(MyInterceptor)

    instance = await ioc.get(MyService)

    assert getattr(instance, "intercepted")
