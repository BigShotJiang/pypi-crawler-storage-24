import copy

import pytest

from zayt.conf.defaults import default_settings
from zayt.conf.settings import Settings
from zayt.web.application import Zayt


async def test_non_existent_module_should_fail():
    settings = Settings(
        copy.copy(default_settings)
        | {
            "modules": [
                f"{__package__}.application",
                "does.not.exist",
            ],
        }
    )

    with pytest.raises(ModuleNotFoundError):
        Zayt(settings)
