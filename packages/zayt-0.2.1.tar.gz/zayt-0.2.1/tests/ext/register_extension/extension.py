from zayt.conf import Settings
from zayt.web.lifecycle.decorator import startup


@startup
def init(settings: Settings):
    setattr(settings, "tested", True)
