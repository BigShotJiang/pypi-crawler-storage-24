from zayt.conf.defaults import default_settings
from zayt.conf.settings import Settings
from zayt.web.application import Zayt


async def test_extension(monkeypatch):
    monkeypatch.chdir(__file__.rsplit("/", maxsplit=1)[0])
    settings = Settings(
        default_settings
        | {
            "modules": [f"{__package__}.extension"],
        }
    )

    app = Zayt(settings)

    # pylint: disable=protected-access
    await app._lifespan_startup()

    assert settings.tested
