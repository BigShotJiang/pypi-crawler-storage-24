from importlib.util import find_spec

from zayt.conf.settings import Settings
from zayt.di.container import Container
from zayt.web.lifecycle.decorator import startup

from .service import make_service


@startup
async def init(container: Container, settings: Settings):
    if find_spec("aiomcache") is None:
        raise ModuleNotFoundError(
            "Missing 'aiomcache'. Install 'zayt' with 'memcached' extra."
        )

    for name in settings.memcached:
        assert isinstance(name, str)
        name = name.strip()
        container.register(make_service(name), name=name if name else None)
