from importlib.util import find_spec

from zayt.web.lifecycle.decorator import startup

from .service import JinjaTemplate

__all__ = ("JinjaTemplate",)


@startup
async def init():
    if find_spec("jinja2") is None:
        raise ModuleNotFoundError(
            "Missing 'jinja2'. Install 'zayt' with 'jinja' extra."
        )
