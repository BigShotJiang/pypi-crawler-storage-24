from zayt.util.package_scan import scan_packages
from zayt.web.lifecycle.decorator import ATTRIBUTE_BACKGROUND, ATTRIBUTE_STARTUP


def _predicate_startup_hooks(item) -> bool:
    return getattr(item, ATTRIBUTE_STARTUP, False)


def find_startup_hooks(*modules):
    return list(scan_packages(*modules, predicate=_predicate_startup_hooks))


def _predicate_background_services(item) -> bool:
    return getattr(item, ATTRIBUTE_BACKGROUND, False)


def find_background_services(*modules):
    return list(scan_packages(*modules, predicate=_predicate_background_services))
