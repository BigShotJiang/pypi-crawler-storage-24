# Plan: Create standalone `imo` Python package

## Context

The `imo` package was developed in the nteract/desktop monorepo at `python/imo/`. It provides marimo-compatible display primitives for IPython/Jupyter via custom MIME types. The user wants to extract this into a standalone package for independent development outside the monorepo.

## Source Files

From `nteract-desktop/claude/marimo-nteract-integration-clahz`:
- `python/imo/pyproject.toml`
- `python/imo/src/imo/__init__.py`
- `python/imo/src/imo/_html.py`
- `python/imo/src/imo/_callout.py`
- `python/imo/src/imo/_layout.py`
- `python/imo/src/imo/_md.py`
- `python/imo/src/imo/_stat.py`
- `python/imo/src/imo/_style.py`
- `python/imo/tests/test_renderers.py`
- `python/imo/uv.lock`

**Note:** TypeScript components (`src/components/imo/`) stay in nteract - they render the custom MIME types in the frontend.

## Implementation Steps

1. **Initialize uv project**
   ```bash
   uv init --package imo
   ```

2. **Copy Python source files from fetched branch**
   - Extract each file using `git show` and write to appropriate location
   - Target structure:
     ```
     imo/
     ├── pyproject.toml
     ├── src/
     │   └── imo/
     │       ├── __init__.py
     │       ├── _html.py
     │       ├── _callout.py
     │       ├── _layout.py
     │       ├── _md.py
     │       ├── _stat.py
     │       └── _style.py
     └── tests/
         └── test_renderers.py
     ```

3. **Adjust pyproject.toml if needed**
   - The existing config uses hatchling which works with uv
   - May need minor adjustments for standalone repo

4. **Generate fresh uv.lock**
   ```bash
   uv lock
   ```

## Verification

1. Run tests:
   ```bash
   uv run pytest
   ```

2. Verify package can be imported:
   ```bash
   uv run python -c "import imo as mo; print(mo.stat(42))"
   ```
