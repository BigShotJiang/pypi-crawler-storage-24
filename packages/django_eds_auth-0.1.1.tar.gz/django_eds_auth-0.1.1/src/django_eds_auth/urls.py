"""
URL configuration for EDS authentication endpoints.

API Endpoints:
    GET  /auth/eds/nonce/ - Generate authentication nonce
    POST /auth/eds/authenticate/ - Authenticate user with signed nonce
    POST /auth/eds/register-certificate/ - Register/upload certificate
    GET  /auth/eds/my-certificate/ - Get current user's certificate info
"""

from django.urls import path

from . import views

app_name = "django_eds_auth"

urlpatterns = [
    # Generate nonce for signing
    path("nonce/", views.GetNonceView.as_view(), name="get_nonce"),
    # Authenticate with signed nonce
    path("authenticate/", views.AuthenticateView.as_view(), name="authenticate"),
    # Register/upload certificate
    path(
        "register-certificate/",
        views.RegisterCertificateView.as_view(),
        name="register_certificate",
    ),
    # Get current user's certificate
    path("my-certificate/", views.user_certificate_view, name="my_certificate"),
    
    # ========== ADMIN ENDPOINTS ==========
    # Rate limiting admin endpoints
    path(
        "admin/rate-limit-status/",
        views.rate_limit_status_view,
        name="rate_limit_status",
    ),
    path("admin/unlock-account/", views.unlock_account_view, name="unlock_account"),
    path(
        "admin/security-dashboard/",
        views.security_dashboard_view,
        name="security_dashboard",
    ),
    path(
        "admin/failed-attempts/",
        views.failed_attempts_list_view,
        name="failed_attempts_list",
    ),
]
