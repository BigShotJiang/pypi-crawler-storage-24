"""
Django management command for cleaning up expired authentication nonces.

Usage:
    python manage.py cleanup_nonces

This command should be run periodically (e.g., via Celery beat or cron) to
remove expired nonces from the database.
"""

from django.core.management.base import BaseCommand

from django_eds_auth.backends import NonceManager


class Command(BaseCommand):
    """Management command to cleanup expired nonces."""

    help = "Clean up expired authentication nonces from the database"

    def add_arguments(self, parser):
        """Add command arguments."""
        parser.add_argument(
            "--dry-run",
            action="store_true",
            help="Show what would be deleted without actually deleting",
        )

    def handle(self, *args, **options):
        """Handle command execution."""
        dry_run = options.get("dry_run", False)

        if dry_run:
            self.stdout.write(
                self.style.SUCCESS("DRY RUN: No actual deletions will occur")
            )
            count = NonceManager.cleanup_expired_nonces()
            self.stdout.write(
                self.style.SUCCESS(f"Would delete {count} expired nonces")
            )
        else:
            count = NonceManager.cleanup_expired_nonces()
            self.stdout.write(
                self.style.SUCCESS(f"Successfully deleted {count} expired nonces")
            )
