"""
Views for EDS authentication flow.

Provides endpoints for:
1. Nonce generation (for client to sign)
2. Authentication (verify signature and authenticate user)
3. Certificate upload (register user's certificate)
"""

import json
import logging

from django.contrib.auth import authenticate, get_user_model, login
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.utils.decorators import method_decorator
from django.views import View
from django.views.decorators.csrf import csrf_exempt
from django.db.models import Count, Q
from django.utils import timezone
from datetime import timedelta

from .backends import EDSAuthBackend, NonceManager
from .models import EDSCertificate, FailedAuthenticationAttempt, SignatureVerificationLog
from .rate_limiting import RateLimiter, RateLimitConfig
from .signature_verification import CertificateValidationError, EDSCertificateValidator

logger = logging.getLogger(__name__)
User = get_user_model()


@method_decorator(csrf_exempt, name="dispatch")
class GetNonceView(View):
    """
    GET /auth/eds/nonce/?username=<username>

    Returns a random nonce that user should sign with their private key.

    Response:
    {
        "nonce": "random_string",
        "expires_in": 300
    }
    """

    def get(self, request):
        """Generate and return authentication nonce."""
        username = request.GET.get("username", "").strip()

        if not username:
            return JsonResponse({"error": "username parameter required"}, status=400)

        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            # Don't reveal if user exists
            return JsonResponse({"error": "User not found"}, status=404)

        # Generate nonce
        nonce = NonceManager.generate_nonce(user)

        return JsonResponse(
            {
                "nonce": nonce,
                "expires_in": 300,  # 5 minutes in seconds
            }
        )


@method_decorator(csrf_exempt, name="dispatch")
class AuthenticateView(View):
    """
    POST /auth/eds/authenticate/

    Authenticates user based on signed nonce and certificate.

    Request body:
    {
        "username": "user@example.com",
        "certificate": "-----BEGIN CERTIFICATE-----\\n...\\n-----END CERTIFICATE-----",
        "nonce": "random_string_from_nonce_endpoint",
        "signed_nonce": "hex_encoded_signature"
    }

    Response on success:
    {
        "success": true,
        "user_id": 123,
        "username": "user@example.com"
    }

    Response on failure:
    {
        "success": false,
        "error": "error message"
    }
    """

    def post(self, request):
        """Authenticate user via EDS."""
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({"success": False, "error": "Invalid JSON"}, status=400)

        # Extract parameters
        username = data.get("username", "").strip()
        certificate_pem = data.get("certificate", "").strip()
        nonce = data.get("nonce", "").strip()
        signed_nonce_hex = data.get("signed_nonce", "").strip()

        # Validate parameters
        if not all([username, certificate_pem, nonce, signed_nonce_hex]):
            return JsonResponse(
                {
                    "success": False,
                    "error": "Missing required fields: username, certificate, nonce, signed_nonce",
                },
                status=400,
            )

        # Authenticate user
        backend = EDSAuthBackend()
        user = backend.authenticate(
            request=request,
            username=username,
            certificate_pem=certificate_pem,
            signed_nonce_hex=signed_nonce_hex,
            nonce=nonce,
        )

        if user:
            login(request, user, backend="django_eds_auth.backends.EDSAuthBackend")
            logger.info(f"User {username} authenticated via EDS")
            return JsonResponse(
                {
                    "success": True,
                    "user_id": user.id,
                    "username": user.username,
                }
            )
        else:
            logger.warning(f"EDS authentication failed for user {username}")
            return JsonResponse(
                {
                    "success": False,
                    "error": "Authentication failed. Check nonce, certificate, and signature.",
                },
                status=401,
            )


@method_decorator(csrf_exempt, name="dispatch")
class RegisterCertificateView(View):
    """
    POST /auth/eds/register-certificate/

    Registers user's EDS certificate.

    Request body:
    {
        "username": "user@example.com",
        "password": "user_password",
        "certificate": "-----BEGIN CERTIFICATE-----\\n...\\n-----END CERTIFICATE-----"
    }

    Or authenticated request (with session):
    {
        "certificate": "-----BEGIN CERTIFICATE-----\\n...\\n-----END CERTIFICATE-----"
    }
    """

    def post(self, request):
        """Register or update user's certificate."""
        try:
            data = json.loads(request.body)
        except json.JSONDecodeError:
            return JsonResponse({"error": "Invalid JSON"}, status=400)

        certificate_pem = data.get("certificate", "").strip()

        if not certificate_pem:
            return JsonResponse({"error": "certificate field required"}, status=400)

        # Determine user
        if request.user.is_authenticated:
            user = request.user
        else:
            username = data.get("username", "").strip()
            password = data.get("password", "").strip()

            if not username or not password:
                return JsonResponse(
                    {"error": "Unauthenticated: provide username and password"},
                    status=401,
                )

            user = authenticate(username=username, password=password)
            if not user:
                return JsonResponse({"error": "Invalid credentials"}, status=401)

        # Validate certificate
        try:
            validator = EDSCertificateValidator()
            cert = validator.load_certificate(certificate_pem)
            is_valid, reason = validator.validate_certificate(cert)

            if not is_valid:
                return JsonResponse(
                    {"error": f"Certificate validation failed: {reason}"}, status=400
                )

            cert_info = validator.extract_certificate_info(cert)

        except CertificateValidationError as e:
            return JsonResponse({"error": f"Certificate error: {e}"}, status=400)

        # Create or update certificate
        try:
            eds_cert, created = EDSCertificate.objects.update_or_create(
                user=user,
                defaults={
                    "subject": cert_info["subject"],
                    "issuer": cert_info["issuer"],
                    "serial_number": cert_info["serial_number"],
                    "valid_from": cert_info["valid_from"],
                    "valid_to": cert_info["valid_to"],
                    "public_key_pem": certificate_pem,
                    "thumbprint": cert_info["thumbprint"],
                    "is_revoked": False,
                },
            )

            action = "registered" if created else "updated"
            logger.info(f"Certificate {action} for user {user.username}")

            return JsonResponse(
                {
                    "success": True,
                    "message": f"Certificate {action} successfully",
                    "certificate": {
                        "subject": cert_info["subject"],
                        "thumbprint": cert_info["thumbprint"],
                        "valid_from": cert_info["valid_from"].isoformat(),
                        "valid_to": cert_info["valid_to"].isoformat(),
                    },
                },
                status=201 if created else 200,
            )

        except Exception as e:
            logger.exception(f"Error registering certificate: {e}")
            return JsonResponse(
                {"error": f"Failed to register certificate: {e}"}, status=500
            )


@login_required
def user_certificate_view(request):
    """
    GET /auth/eds/my-certificate/

    Returns authenticated user's certificate info.
    """
    try:
        cert = EDSCertificate.objects.get(user=request.user)
        return JsonResponse(
            {
                "subject": cert.subject,
                "issuer": cert.issuer,
                "thumbprint": cert.thumbprint,
                "valid_from": cert.valid_from.isoformat(),
                "valid_to": cert.valid_to.isoformat(),
                "is_revoked": cert.is_revoked,
            }
        )
    except EDSCertificate.DoesNotExist:
        return JsonResponse({"error": "User has no certificate registered"}, status=404)


# ========== RATE LIMITING ADMIN VIEWS ==========


@login_required
def rate_limit_status_view(request, username: str = None):
    """
    GET /auth/eds/admin/rate-limit-status/?username=<username>

    Returns rate limit status for a specific username.
    Admin only.
    """
    if not request.user.is_staff:
        return JsonResponse({"error": "Admin access required"}, status=403)

    username = username or request.GET.get("username", "").strip()

    if not username:
        return JsonResponse({"error": "username parameter required"}, status=400)

    limiter = RateLimiter(config=RateLimitConfig())
    status = limiter.get_status(username, "eds_auth")

    return JsonResponse(status)


@login_required
def unlock_account_view(request, username: str = None):
    """
    POST /auth/eds/admin/unlock-account/

    Manually unlock rate-limited account. Admin only.
    """
    if not request.method == "POST":
        return JsonResponse({"error": "POST required"}, status=405)

    if not request.user.is_staff:
        return JsonResponse({"error": "Admin access required"}, status=403)

    username = username or request.POST.get("username", "").strip()

    if not username:
        return JsonResponse({"error": "username parameter required"}, status=400)

    limiter = RateLimiter(config=RateLimitConfig())
    cleared = limiter.reset_all_for_identifier(username)

    logger.info(
        f"Admin {request.user.username} unlocked account {username} "
        f"({cleared} rate limit records cleared)"
    )

    return JsonResponse(
        {"success": True, "message": f"Cleared {cleared} rate limit records"}
    )


@login_required
def security_dashboard_view(request):
    """
    GET /auth/eds/admin/security-dashboard/

    Returns security overview for admin dashboard.
    """
    if not request.user.is_staff:
        return JsonResponse({"error": "Admin access required"}, status=403)

    last_24h = timezone.now() - timedelta(hours=24)
    last_7d = timezone.now() - timedelta(days=7)

    # Overview statistics
    total_users = User.objects.count()
    users_with_eds = EDSCertificate.objects.values("user").distinct().count()

    # Recent activity
    successful_logins_24h = SignatureVerificationLog.objects.filter(
        created_at__gte=last_24h, status="success"
    ).count()

    failed_logins_24h = SignatureVerificationLog.objects.filter(
        created_at__gte=last_24h, status__startswith="failed"
    ).count()

    # Failed attempts by type
    failed_by_type = (
        FailedAuthenticationAttempt.objects.filter(timestamp__gte=last_24h)
        .values("attempt_type")
        .annotate(count=Count("id"))
        .order_by("-count")
    )

    # Locked accounts
    locked_attempts = FailedAuthenticationAttempt.objects.filter(
        timestamp__gte=last_24h, is_locked=True
    ).values("username").distinct()

    # Suspicious IPs (more than 10 failures in 24h)
    suspicious_ips = (
        FailedAuthenticationAttempt.objects.filter(timestamp__gte=last_24h)
        .values("ip_address")
        .annotate(count=Count("id"))
        .filter(count__gte=10)
        .order_by("-count")
    )

    # Trending data (daily counts)
    daily_logins = []
    for i in range(6, -1, -1):
        day = timezone.now() - timedelta(days=i)
        day_start = day.replace(hour=0, minute=0, second=0, microsecond=0)
        day_end = day_start + timedelta(days=1)

        count = SignatureVerificationLog.objects.filter(
            created_at__gte=day_start,
            created_at__lt=day_end,
            status="success",
        ).count()

        daily_logins.append({"date": day_start.date().isoformat(), "count": count})

    stats = {
        "overview": {
            "total_users": total_users,
            "users_with_eds": users_with_eds,
        },
        "activity_24h": {
            "successful_logins": successful_logins_24h,
            "failed_logins": failed_logins_24h,
            "failed_by_type": list(failed_by_type),
        },
        "security_alerts": {
            "locked_accounts_count": locked_attempts.count(),
            "locked_usernames": [item["username"] for item in locked_attempts],
            "suspicious_ips_count": suspicious_ips.count(),
            "suspicious_ips": list(suspicious_ips),
        },
        "trends_7d": {
            "daily_logins": daily_logins,
        },
    }

    return JsonResponse(stats)


@login_required
def failed_attempts_list_view(request):
    """
    GET /auth/eds/admin/failed-attempts/?hours=24&limit=100

    List failed authentication attempts for admin review.
    """
    if not request.user.is_staff:
        return JsonResponse({"error": "Admin access required"}, status=403)

    hours = int(request.GET.get("hours", "24"))
    limit = int(request.GET.get("limit", "100"))

    since = timezone.now() - timedelta(hours=hours)

    attempts = FailedAuthenticationAttempt.objects.filter(
        timestamp__gte=since
    ).order_by("-timestamp")[:limit]

    data = [
        {
            "username": att.username,
            "ip_address": att.ip_address,
            "attempt_type": att.attempt_type,
            "attempt_number": att.attempt_number,
            "is_locked": att.is_locked,
            "timestamp": att.timestamp.isoformat(),
            "reason": att.reason,
        }
        for att in attempts
    ]

    return JsonResponse({"count": len(data), "attempts": data})
