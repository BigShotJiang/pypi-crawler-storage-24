"""FINNBAR package."""
