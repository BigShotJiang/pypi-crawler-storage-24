"""
Linux Clipboard Manager
A lightweight PyQT6 based clipboard manager for linux.
"""
__version__ = "1.0.0"
