use crate::chat_completions_openai::convert::mapping::chat_completions_finish_reason_to_open_responses_status;
use crate::chat_completions_openai::stream::{
    ChatCompletionsStreamChunk, ChatCompletionsStreamDelta, ChatCompletionsStreamToolCall,
};
use crate::error::{ConversionError, ConversionWarning};
use crate::open_responses::response::OpenResponsesResponse;
use crate::open_responses::stream::OpenResponsesStreamEvent;
use crate::open_responses::types::*;
use crate::stream::StreamTransform;

use super::accum::{ChatCompletionsToOpenResponsesAccum, ResponsePhase, ToolCallAccum};

/// Converts Chat Completions stream chunks to Open Responses stream events.
pub struct ChatCompletionsToOpenResponsesStream {
    accum: ChatCompletionsToOpenResponsesAccum,
    message_content_parts: Vec<ContentPart>,
    output_items: Vec<OutputItem>,
    reasoning_text: String,
    pending_terminal: Option<(ResponseStatus, Option<IncompleteDetails>)>,
    pending_usage: Option<crate::chat_completions_openai::types::ChatCompletionsUsage>,
}

impl Default for ChatCompletionsToOpenResponsesStream {
    fn default() -> Self {
        Self::new()
    }
}

impl ChatCompletionsToOpenResponsesStream {
    pub fn new() -> Self {
        Self {
            accum: ChatCompletionsToOpenResponsesAccum::new(),
            message_content_parts: Vec::new(),
            output_items: Vec::new(),
            reasoning_text: String::new(),
            pending_terminal: None,
            pending_usage: None,
        }
    }

    fn finalize_pending(&mut self) -> Vec<OpenResponsesStreamEvent> {
        let accum = &mut self.accum;
        let (status, incomplete_details) = if let Some(terminal) = self.pending_terminal.take() {
            terminal
        } else {
            accum.ctx.warn(
                "finish_reason",
                "stream finalized without explicit terminal finish_reason; emitted response as incomplete",
            );
            (
                ResponseStatus::Incomplete,
                Some(IncompleteDetails {
                    reason: "stream_ended".into(),
                }),
            )
        };

        let mut events = Vec::new();
        events.extend(close_message(
            accum,
            &mut self.message_content_parts,
            &mut self.output_items,
            status,
        ));
        events.extend(close_reasoning(
            accum,
            &mut self.output_items,
            &mut self.reasoning_text,
        ));
        events.extend(close_tool_calls(accum, &mut self.output_items, status));

        let usage = self.pending_usage.take().map(Into::into);
        let response = OpenResponsesResponse {
            id: accum.response_id.clone(),
            object: "response".into(),
            created_at: accum.created_at,
            status,
            model: accum.model.clone(),
            output: std::mem::take(&mut self.output_items),
            usage,
            incomplete_details,
            ..Default::default()
        };

        events.push(match status {
            ResponseStatus::Completed => OpenResponsesStreamEvent::ResponseCompleted {
                sequence_number: accum.next_sequence_number(),
                response,
            },
            ResponseStatus::Incomplete => OpenResponsesStreamEvent::ResponseIncomplete {
                sequence_number: accum.next_sequence_number(),
                response,
            },
            ResponseStatus::Failed => OpenResponsesStreamEvent::ResponseFailed {
                sequence_number: accum.next_sequence_number(),
                response,
            },
            ResponseStatus::InProgress | ResponseStatus::Queued => {
                OpenResponsesStreamEvent::ResponseCompleted {
                    sequence_number: accum.next_sequence_number(),
                    response,
                }
            }
        });

        accum.phase = ResponsePhase::TerminalEmitted;
        events
    }
}

impl StreamTransform for ChatCompletionsToOpenResponsesStream {
    type Input = ChatCompletionsStreamChunk;
    type Output = OpenResponsesStreamEvent;

    fn transform(
        &mut self,
        input: ChatCompletionsStreamChunk,
    ) -> Result<Vec<OpenResponsesStreamEvent>, ConversionError> {
        let accum = &mut self.accum;
        let mut events = Vec::new();

        events.extend(handle_response_start(accum, &input));
        warn_unsupported_chunk_fields(accum, &input);

        if let Some(usage) = input.usage {
            self.pending_usage = Some(usage);
        }

        if input.choices.is_empty() {
            if self.pending_terminal.is_some() {
                events.extend(self.finalize_pending());
            }
            return Ok(events);
        }

        if input.choices.len() > 1 {
            accum.ctx.warn(
                "choices",
                "multiple stream choices are not representable in Open Responses stream; only the first choice was used",
            );
        }

        let choice = &input.choices[0];
        if choice.logprobs.is_some() {
            accum.ctx.warn(
                "choices[0].logprobs",
                "choice-level logprobs are not supported in Open Responses stream, dropped",
            );
        }

        events.extend(handle_delta(
            accum,
            &choice.delta,
            &mut self.message_content_parts,
            &mut self.output_items,
            &mut self.reasoning_text,
        ));

        if let Some(finish_reason) = choice.finish_reason.clone() {
            self.pending_terminal = Some(chat_completions_finish_reason_to_open_responses_status(
                Some(finish_reason),
            ));
            accum.phase = ResponsePhase::TerminalPending;
            if self.pending_usage.is_some() {
                events.extend(self.finalize_pending());
            }
        }

        Ok(events)
    }

    fn flush(&mut self) -> Result<Vec<OpenResponsesStreamEvent>, ConversionError> {
        if self.pending_terminal.is_none()
            && !matches!(
                self.accum.phase,
                ResponsePhase::InProgress | ResponsePhase::TerminalPending
            )
        {
            return Ok(vec![]);
        }

        Ok(self.finalize_pending())
    }

    fn take_warnings(&mut self) -> Vec<ConversionWarning> {
        self.accum.ctx.take_warnings()
    }
}

fn handle_response_start(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
    chunk: &ChatCompletionsStreamChunk,
) -> Vec<OpenResponsesStreamEvent> {
    if accum.phase != ResponsePhase::NotStarted {
        return vec![];
    }

    accum.phase = ResponsePhase::InProgress;
    accum.response_id = chunk.id.clone();
    accum.model = chunk.model.clone();
    accum.created_at = chunk.created;

    let response = OpenResponsesResponse {
        id: accum.response_id.clone(),
        object: "response".into(),
        created_at: accum.created_at,
        status: ResponseStatus::InProgress,
        model: accum.model.clone(),
        output: vec![],
        ..Default::default()
    };

    vec![
        OpenResponsesStreamEvent::ResponseCreated {
            sequence_number: accum.next_sequence_number(),
            response: response.clone(),
        },
        OpenResponsesStreamEvent::ResponseInProgress {
            sequence_number: accum.next_sequence_number(),
            response,
        },
    ]
}

fn handle_delta(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
    delta: &ChatCompletionsStreamDelta,
    message_content_parts: &mut Vec<ContentPart>,
    output_items: &mut Vec<OutputItem>,
    reasoning_text: &mut String,
) -> Vec<OpenResponsesStreamEvent> {
    let mut events = Vec::new();

    if delta
        .role
        .as_deref()
        .is_some_and(|role| role != "assistant")
    {
        accum.ctx.warn(
            "choices[0].delta.role",
            "non-assistant delta role is not valid in Open Responses stream and was coerced to assistant",
        );
    }

    if let Some(content) = &delta.content
        && !content.is_empty()
    {
        events.extend(close_reasoning(accum, output_items, reasoning_text));
        events.extend(open_message_if_needed(accum));
        events.extend(open_text_part_if_needed(accum));

        accum.text_part.accumulated_text.push_str(content);
        events.push(OpenResponsesStreamEvent::OutputTextDelta {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.message_item_id.clone(),
            output_index: accum.message_output_index,
            content_index: accum.text_part.content_index,
            delta: content.clone(),
            logprobs: vec![],
            obfuscation: None,
        });
    }

    if let Some(refusal) = &delta.refusal
        && !refusal.is_empty()
    {
        events.extend(close_reasoning(accum, output_items, reasoning_text));
        events.extend(open_message_if_needed(accum));
        events.extend(open_refusal_part_if_needed(accum));

        accum.refusal_part.accumulated_text.push_str(refusal);
        events.push(OpenResponsesStreamEvent::RefusalDelta {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.message_item_id.clone(),
            output_index: accum.message_output_index,
            content_index: accum.refusal_part.content_index,
            delta: refusal.clone(),
        });
    }

    if let Some(reasoning_delta) = &delta.reasoning_content
        && !reasoning_delta.is_empty()
    {
        events.extend(close_message(
            accum,
            message_content_parts,
            output_items,
            ResponseStatus::InProgress,
        ));
        events.extend(open_reasoning_if_needed(accum));

        reasoning_text.push_str(reasoning_delta);
        events.push(OpenResponsesStreamEvent::ReasoningSummaryTextDelta {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.reasoning_item_id.clone(),
            output_index: accum.reasoning_output_index,
            summary_index: accum.reasoning_summary_index,
            delta: reasoning_delta.clone(),
            obfuscation: None,
        });
    }

    if let Some(tool_calls) = &delta.tool_calls {
        events.extend(close_message(
            accum,
            message_content_parts,
            output_items,
            ResponseStatus::InProgress,
        ));
        events.extend(close_reasoning(accum, output_items, reasoning_text));
        for (index, tool_call) in tool_calls.iter().enumerate() {
            accum
                .ctx
                .push(format!("choices[0].delta.tool_calls[{index}]"));
            events.extend(handle_tool_call_delta(accum, tool_call));
            accum.ctx.pop();
        }
    }

    events
}

fn handle_tool_call_delta(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
    tool_call: &ChatCompletionsStreamToolCall,
) -> Vec<OpenResponsesStreamEvent> {
    let mut events = Vec::new();

    if !accum.tool_call_accums.contains_key(&tool_call.index) {
        let output_index = accum.next_output_index();
        accum.tool_call_accums.insert(
            tool_call.index,
            ToolCallAccum {
                output_index,
                item_id: format!("fc_{}", tool_call.index),
                call_id: String::new(),
                name: String::new(),
                arguments: String::new(),
                output_item_added: false,
            },
        );
    }

    if let Some(kind) = &tool_call.kind
        && kind != "function"
    {
        accum.ctx.warn(
            "type",
            "non-function tool call type downgraded to function_call",
        );
    }

    let mut maybe_added: Option<(u64, OutputItem)> = None;
    let mut maybe_arguments_delta: Option<(String, u64, String)> = None;

    {
        let tool_call_accum = accum
            .tool_call_accums
            .get_mut(&tool_call.index)
            .expect("tool call accum exists");

        if let Some(id) = &tool_call.id
            && !id.is_empty()
        {
            tool_call_accum.call_id = id.clone();
        }

        if let Some(function_delta) = &tool_call.function {
            if let Some(name) = &function_delta.name
                && !name.is_empty()
            {
                tool_call_accum.name.push_str(name);
            }

            if !tool_call_accum.output_item_added {
                tool_call_accum.output_item_added = true;
                maybe_added = Some((
                    tool_call_accum.output_index,
                    OutputItem::FunctionCall {
                        id: tool_call_accum.item_id.clone(),
                        call_id: tool_call_accum.call_id.clone(),
                        name: tool_call_accum.name.clone(),
                        arguments: tool_call_accum.arguments.clone(),
                        status: ItemStatus::InProgress,
                    },
                ));
            }

            if let Some(arguments_delta) = &function_delta.arguments
                && !arguments_delta.is_empty()
            {
                tool_call_accum.arguments.push_str(arguments_delta);
                maybe_arguments_delta = Some((
                    tool_call_accum.item_id.clone(),
                    tool_call_accum.output_index,
                    arguments_delta.clone(),
                ));
            }
        }
    }

    if let Some((output_index, item)) = maybe_added {
        events.push(OpenResponsesStreamEvent::OutputItemAdded {
            sequence_number: accum.next_sequence_number(),
            output_index,
            item,
        });
    }

    if let Some((item_id, output_index, delta)) = maybe_arguments_delta {
        events.push(OpenResponsesStreamEvent::FunctionCallArgumentsDelta {
            sequence_number: accum.next_sequence_number(),
            item_id,
            output_index,
            delta,
            obfuscation: None,
        });
    }

    events
}

fn open_message_if_needed(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
) -> Vec<OpenResponsesStreamEvent> {
    if accum.message_is_open {
        return vec![];
    }

    accum.message_is_open = true;
    let (item_id, output_index) = allocate_item_id_and_output_index(accum, "msg");
    accum.message_item_id = item_id;
    accum.message_output_index = output_index;
    accum.reset_message_parts();

    vec![OpenResponsesStreamEvent::OutputItemAdded {
        sequence_number: accum.next_sequence_number(),
        output_index: accum.message_output_index,
        item: OutputItem::Message {
            id: accum.message_item_id.clone(),
            status: ItemStatus::InProgress,
            role: MessageRole::Assistant,
            content: vec![],
        },
    }]
}

fn open_text_part_if_needed(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
) -> Vec<OpenResponsesStreamEvent> {
    if accum.text_part.is_open {
        return vec![];
    }

    accum.text_part.is_open = true;
    accum.text_part.content_index = accum.next_content_index();

    vec![OpenResponsesStreamEvent::ContentPartAdded {
        sequence_number: accum.next_sequence_number(),
        item_id: accum.message_item_id.clone(),
        output_index: accum.message_output_index,
        content_index: accum.text_part.content_index,
        part: ContentPart::OutputText {
            text: String::new(),
            annotations: vec![],
            logprobs: vec![],
        },
    }]
}

fn open_refusal_part_if_needed(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
) -> Vec<OpenResponsesStreamEvent> {
    if accum.refusal_part.is_open {
        return vec![];
    }

    accum.refusal_part.is_open = true;
    accum.refusal_part.content_index = accum.next_content_index();

    vec![OpenResponsesStreamEvent::ContentPartAdded {
        sequence_number: accum.next_sequence_number(),
        item_id: accum.message_item_id.clone(),
        output_index: accum.message_output_index,
        content_index: accum.refusal_part.content_index,
        part: ContentPart::Refusal {
            refusal: String::new(),
        },
    }]
}

fn open_reasoning_if_needed(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
) -> Vec<OpenResponsesStreamEvent> {
    if accum.reasoning_is_open {
        return vec![];
    }

    accum.reasoning_is_open = true;
    let (item_id, output_index) = allocate_item_id_and_output_index(accum, "rs");
    accum.reasoning_item_id = item_id;
    accum.reasoning_output_index = output_index;
    accum.reasoning_summary_index = 0;

    vec![
        OpenResponsesStreamEvent::OutputItemAdded {
            sequence_number: accum.next_sequence_number(),
            output_index: accum.reasoning_output_index,
            item: OutputItem::Reasoning {
                id: accum.reasoning_item_id.clone(),
                summary: vec![],
                content: None,
                encrypted_content: None,
            },
        },
        OpenResponsesStreamEvent::ReasoningSummaryPartAdded {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.reasoning_item_id.clone(),
            output_index: accum.reasoning_output_index,
            summary_index: accum.reasoning_summary_index,
            part: ContentPart::SummaryText {
                text: String::new(),
            },
        },
    ]
}

fn allocate_item_id_and_output_index(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
    prefix: &str,
) -> (String, u64) {
    let output_index = accum.next_output_index();
    (format!("{prefix}_{output_index}"), output_index)
}

fn close_message(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
    message_content_parts: &mut Vec<ContentPart>,
    output_items: &mut Vec<OutputItem>,
    status: ResponseStatus,
) -> Vec<OpenResponsesStreamEvent> {
    if !accum.message_is_open {
        return vec![];
    }

    let mut events = Vec::new();

    if accum.text_part.is_open {
        let text = std::mem::take(&mut accum.text_part.accumulated_text);
        let content_index = accum.text_part.content_index;
        events.push(OpenResponsesStreamEvent::OutputTextDone {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.message_item_id.clone(),
            output_index: accum.message_output_index,
            content_index,
            text: text.clone(),
            logprobs: vec![],
        });
        events.push(OpenResponsesStreamEvent::ContentPartDone {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.message_item_id.clone(),
            output_index: accum.message_output_index,
            content_index,
            part: ContentPart::OutputText {
                text: text.clone(),
                annotations: vec![],
                logprobs: vec![],
            },
        });
        message_content_parts.push(ContentPart::OutputText {
            text,
            annotations: vec![],
            logprobs: vec![],
        });
    }

    if accum.refusal_part.is_open {
        let refusal = std::mem::take(&mut accum.refusal_part.accumulated_text);
        let content_index = accum.refusal_part.content_index;
        events.push(OpenResponsesStreamEvent::RefusalDone {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.message_item_id.clone(),
            output_index: accum.message_output_index,
            content_index,
            refusal: refusal.clone(),
        });
        events.push(OpenResponsesStreamEvent::ContentPartDone {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.message_item_id.clone(),
            output_index: accum.message_output_index,
            content_index,
            part: ContentPart::Refusal {
                refusal: refusal.clone(),
            },
        });
        message_content_parts.push(ContentPart::Refusal { refusal });
    }

    let item_status = if matches!(status, ResponseStatus::Incomplete) {
        ItemStatus::Incomplete
    } else {
        ItemStatus::Completed
    };

    let item = OutputItem::Message {
        id: accum.message_item_id.clone(),
        status: item_status,
        role: MessageRole::Assistant,
        content: std::mem::take(message_content_parts),
    };
    output_items.push(item.clone());

    events.push(OpenResponsesStreamEvent::OutputItemDone {
        sequence_number: accum.next_sequence_number(),
        output_index: accum.message_output_index,
        item,
    });

    accum.message_is_open = false;
    accum.reset_message_parts();

    events
}

fn close_reasoning(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
    output_items: &mut Vec<OutputItem>,
    reasoning_text: &mut String,
) -> Vec<OpenResponsesStreamEvent> {
    if !accum.reasoning_is_open {
        return vec![];
    }

    let text = std::mem::take(reasoning_text);
    let mut events = vec![
        OpenResponsesStreamEvent::ReasoningSummaryTextDone {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.reasoning_item_id.clone(),
            output_index: accum.reasoning_output_index,
            summary_index: accum.reasoning_summary_index,
            text: text.clone(),
        },
        OpenResponsesStreamEvent::ReasoningSummaryPartDone {
            sequence_number: accum.next_sequence_number(),
            item_id: accum.reasoning_item_id.clone(),
            output_index: accum.reasoning_output_index,
            summary_index: accum.reasoning_summary_index,
            part: ContentPart::SummaryText { text: text.clone() },
        },
    ];

    let item = OutputItem::Reasoning {
        id: accum.reasoning_item_id.clone(),
        summary: vec![ContentPart::SummaryText { text }],
        content: None,
        encrypted_content: None,
    };
    output_items.push(item.clone());
    events.push(OpenResponsesStreamEvent::OutputItemDone {
        sequence_number: accum.next_sequence_number(),
        output_index: accum.reasoning_output_index,
        item,
    });

    accum.reasoning_is_open = false;

    events
}

fn close_tool_calls(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
    output_items: &mut Vec<OutputItem>,
    status: ResponseStatus,
) -> Vec<OpenResponsesStreamEvent> {
    let item_status = if matches!(status, ResponseStatus::Incomplete) {
        ItemStatus::Incomplete
    } else {
        ItemStatus::Completed
    };

    let mut accums = std::mem::take(&mut accum.tool_call_accums)
        .into_values()
        .collect::<Vec<_>>();
    accums.sort_by_key(|entry| entry.output_index);

    let mut events = Vec::new();
    for entry in accums {
        if !entry.output_item_added {
            events.push(OpenResponsesStreamEvent::OutputItemAdded {
                sequence_number: accum.next_sequence_number(),
                output_index: entry.output_index,
                item: OutputItem::FunctionCall {
                    id: entry.item_id.clone(),
                    call_id: entry.call_id.clone(),
                    name: entry.name.clone(),
                    arguments: entry.arguments.clone(),
                    status: ItemStatus::InProgress,
                },
            });
        }

        events.push(OpenResponsesStreamEvent::FunctionCallArgumentsDone {
            sequence_number: accum.next_sequence_number(),
            item_id: entry.item_id.clone(),
            output_index: entry.output_index,
            arguments: entry.arguments.clone(),
        });

        let item = OutputItem::FunctionCall {
            id: entry.item_id,
            call_id: entry.call_id,
            name: entry.name,
            arguments: entry.arguments,
            status: item_status.clone(),
        };
        output_items.push(item.clone());
        events.push(OpenResponsesStreamEvent::OutputItemDone {
            sequence_number: accum.next_sequence_number(),
            output_index: entry.output_index,
            item,
        });
    }

    events
}

fn warn_unsupported_chunk_fields(
    accum: &mut ChatCompletionsToOpenResponsesAccum,
    input: &ChatCompletionsStreamChunk,
) {
    if input.system_fingerprint.is_some() && !accum.saw_system_fingerprint {
        accum.saw_system_fingerprint = true;
        accum.ctx.warn(
            "system_fingerprint",
            "not supported in Open Responses streaming, dropped",
        );
    }
    if input.service_tier.is_some() && !accum.saw_service_tier {
        accum.saw_service_tier = true;
        accum.ctx.warn(
            "service_tier",
            "not supported in Open Responses streaming, dropped",
        );
    }
    if input.obfuscation.is_some() && !accum.saw_obfuscation {
        accum.saw_obfuscation = true;
        accum.ctx.warn(
            "obfuscation",
            "not supported in Open Responses streaming, dropped",
        );
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn content_delta_emits_text_delta_immediately() {
        let mut stream = ChatCompletionsToOpenResponsesStream::new();
        let events = stream
            .transform(ChatCompletionsStreamChunk {
                id: "chatcmpl_1".into(),
                object: "chat.completion.chunk".into(),
                created: 1,
                model: "gpt-5".into(),
                usage: None,
                system_fingerprint: None,
                service_tier: None,
                obfuscation: None,
                choices: vec![
                    crate::chat_completions_openai::stream::ChatCompletionsStreamChoice {
                        index: 0,
                        delta: ChatCompletionsStreamDelta {
                            role: Some("assistant".into()),
                            content: Some("hello".into()),
                            tool_calls: None,
                            refusal: None,
                            reasoning_content: None,
                        },
                        finish_reason: None,
                        logprobs: None,
                    },
                ],
            })
            .expect("ok");

        assert!(
            events
                .iter()
                .any(|event| matches!(event, OpenResponsesStreamEvent::OutputTextDelta { .. }))
        );
    }

    #[test]
    fn terminal_waits_for_usage_until_usage_chunk_arrives() {
        let mut stream = ChatCompletionsToOpenResponsesStream::new();
        let first = stream
            .transform(ChatCompletionsStreamChunk {
                id: "chatcmpl_1".into(),
                object: "chat.completion.chunk".into(),
                created: 1,
                model: "gpt-5".into(),
                usage: None,
                system_fingerprint: None,
                service_tier: None,
                obfuscation: None,
                choices: vec![crate::chat_completions_openai::stream::ChatCompletionsStreamChoice {
                    index: 0,
                    delta: ChatCompletionsStreamDelta {
                        role: Some("assistant".into()),
                        content: Some("hello".into()),
                        tool_calls: None,
                        refusal: None,
                        reasoning_content: None,
                    },
                    finish_reason: Some(
                        crate::chat_completions_openai::types::ChatCompletionsFinishReason::Stop,
                    ),
                    logprobs: None,
                }],
            })
            .expect("ok");

        assert!(
            !first
                .iter()
                .any(|event| matches!(event, OpenResponsesStreamEvent::ResponseCompleted { .. }))
        );

        let second = stream
            .transform(ChatCompletionsStreamChunk {
                id: "chatcmpl_1".into(),
                object: "chat.completion.chunk".into(),
                created: 1,
                model: "gpt-5".into(),
                usage: Some(
                    crate::chat_completions_openai::types::ChatCompletionsUsage {
                        prompt_tokens: 10,
                        completion_tokens: 5,
                        total_tokens: 15,
                        prompt_tokens_details: None,
                        completion_tokens_details: None,
                    },
                ),
                system_fingerprint: None,
                service_tier: None,
                obfuscation: None,
                choices: vec![],
            })
            .expect("ok");

        assert!(
            second
                .iter()
                .any(|event| matches!(event, OpenResponsesStreamEvent::ResponseCompleted { .. }))
        );
    }

    #[test]
    fn text_reasoning_text_interleaving_closes_reasoning_before_next_text_delta() {
        let mut stream = ChatCompletionsToOpenResponsesStream::new();

        stream
            .transform(ChatCompletionsStreamChunk {
                id: "chatcmpl_1".into(),
                object: "chat.completion.chunk".into(),
                created: 1,
                model: "gpt-5".into(),
                usage: None,
                system_fingerprint: None,
                service_tier: None,
                obfuscation: None,
                choices: vec![
                    crate::chat_completions_openai::stream::ChatCompletionsStreamChoice {
                        index: 0,
                        delta: ChatCompletionsStreamDelta {
                            role: Some("assistant".into()),
                            content: Some("A".into()),
                            tool_calls: None,
                            refusal: None,
                            reasoning_content: None,
                        },
                        finish_reason: None,
                        logprobs: None,
                    },
                ],
            })
            .expect("ok");

        stream
            .transform(ChatCompletionsStreamChunk {
                id: "chatcmpl_1".into(),
                object: "chat.completion.chunk".into(),
                created: 1,
                model: "gpt-5".into(),
                usage: None,
                system_fingerprint: None,
                service_tier: None,
                obfuscation: None,
                choices: vec![
                    crate::chat_completions_openai::stream::ChatCompletionsStreamChoice {
                        index: 0,
                        delta: ChatCompletionsStreamDelta {
                            role: None,
                            content: None,
                            tool_calls: None,
                            refusal: None,
                            reasoning_content: Some("R".into()),
                        },
                        finish_reason: None,
                        logprobs: None,
                    },
                ],
            })
            .expect("ok");

        let events = stream
            .transform(ChatCompletionsStreamChunk {
                id: "chatcmpl_1".into(),
                object: "chat.completion.chunk".into(),
                created: 1,
                model: "gpt-5".into(),
                usage: None,
                system_fingerprint: None,
                service_tier: None,
                obfuscation: None,
                choices: vec![
                    crate::chat_completions_openai::stream::ChatCompletionsStreamChoice {
                        index: 0,
                        delta: ChatCompletionsStreamDelta {
                            role: None,
                            content: Some("B".into()),
                            tool_calls: None,
                            refusal: None,
                            reasoning_content: None,
                        },
                        finish_reason: None,
                        logprobs: None,
                    },
                ],
            })
            .expect("ok");

        let reasoning_done_index = events
            .iter()
            .position(|event| {
                matches!(
                    event,
                    OpenResponsesStreamEvent::ReasoningSummaryTextDone { .. }
                )
            })
            .expect("reasoning done");
        let text_delta_index = events
            .iter()
            .position(|event| matches!(event, OpenResponsesStreamEvent::OutputTextDelta { .. }))
            .expect("text delta");

        assert!(reasoning_done_index < text_delta_index);
    }

    #[test]
    fn flush_without_terminal_marks_response_incomplete_and_warns() {
        let mut stream = ChatCompletionsToOpenResponsesStream::new();

        stream
            .transform(ChatCompletionsStreamChunk {
                id: "chatcmpl_1".into(),
                object: "chat.completion.chunk".into(),
                created: 1,
                model: "gpt-5".into(),
                usage: None,
                system_fingerprint: None,
                service_tier: None,
                obfuscation: None,
                choices: vec![
                    crate::chat_completions_openai::stream::ChatCompletionsStreamChoice {
                        index: 0,
                        delta: ChatCompletionsStreamDelta {
                            role: Some("assistant".into()),
                            content: Some("hello".into()),
                            tool_calls: None,
                            refusal: None,
                            reasoning_content: None,
                        },
                        finish_reason: None,
                        logprobs: None,
                    },
                ],
            })
            .expect("ok");

        let events = stream.flush().expect("ok");
        assert!(
            events
                .iter()
                .any(|event| matches!(event, OpenResponsesStreamEvent::ResponseIncomplete { .. }))
        );

        let warnings = stream.take_warnings();
        assert!(warnings.iter().any(|warning| {
            warning.field == "finish_reason"
                && warning
                    .message
                    .contains("stream finalized without explicit terminal finish_reason")
        }));
    }

    #[test]
    fn unsupported_chunk_fields_warn_once() {
        let mut stream = ChatCompletionsToOpenResponsesStream::new();

        for _ in 0..2 {
            stream
                .transform(ChatCompletionsStreamChunk {
                    id: "chatcmpl_1".into(),
                    object: "chat.completion.chunk".into(),
                    created: 1,
                    model: "gpt-5".into(),
                    usage: None,
                    system_fingerprint: Some("fp_123".into()),
                    service_tier: Some("default".into()),
                    obfuscation: Some("abc".into()),
                    choices: vec![],
                })
                .expect("ok");
        }

        let warnings = stream.take_warnings();
        let fields: Vec<&str> = warnings
            .iter()
            .map(|warning| warning.field.as_str())
            .collect();
        assert_eq!(
            fields,
            vec!["system_fingerprint", "service_tier", "obfuscation"]
        );
    }
}
