use crate::chat_completions_openai::convert::mapping::chat_completions_finish_reason_to_open_responses_status;
use crate::chat_completions_openai::response::{
    ChatCompletionsChoice, ChatCompletionsOpenAiResponse,
};
use crate::chat_completions_openai::types::*;
use crate::convert::ctx::ConversionCtx;
use crate::error::{ConversionError, ConversionResult};
use crate::open_responses::response::OpenResponsesResponse;
use crate::open_responses::types::*;
use crate::traits::IntoOpenResponses;

type Ctx = ConversionCtx<()>;

impl IntoOpenResponses for ChatCompletionsOpenAiResponse {
    type Target = OpenResponsesResponse;

    fn into_open_responses(
        self,
    ) -> Result<ConversionResult<OpenResponsesResponse>, ConversionError> {
        let mut ctx = Ctx::new();

        let mut choices = self.choices;
        if choices.is_empty() {
            return Err(ConversionError::InvalidInput(
                "chat completions response has no choices".into(),
            ));
        }
        if choices.len() > 1 {
            ctx.warn(
                "choices",
                "multiple choices are not representable in Open Responses response; only the first choice was used",
            );
        }

        let choice = choices.swap_remove(0);
        if choice.logprobs.is_some() {
            ctx.warn(
                "choices[0].logprobs",
                "choice-level logprobs are not supported in Open Responses response, dropped",
            );
        }

        let (status, incomplete_details) =
            chat_completions_finish_reason_to_open_responses_status(choice.finish_reason.clone());
        let output = convert_choice_to_open_responses_output(choice, &mut ctx);
        let usage = self.usage.map(Into::into);

        let mut result = ConversionResult::with_warnings(
            OpenResponsesResponse {
                id: self.id,
                object: "response".into(),
                created_at: self.created,
                status,
                model: self.model,
                output,
                incomplete_details,
                usage,
                service_tier: self
                    .service_tier
                    .and_then(|tier| convert_service_tier_to_open_responses(tier, &mut ctx)),
                ..Default::default()
            },
            ctx.into_warnings(),
        );

        result.warn_unsupported(
            "Open Responses",
            &[("system_fingerprint", self.system_fingerprint.is_some())],
        );

        Ok(result)
    }
}

fn convert_choice_to_open_responses_output(
    choice: ChatCompletionsChoice,
    ctx: &mut Ctx,
) -> Vec<OutputItem> {
    let mut output = Vec::new();

    let ChatCompletionsChoice { message, .. } = choice;

    let mut message_parts = Vec::new();

    if message.role != "assistant" {
        ctx.warn(
            "choices[0].message.role",
            "non-assistant response role is not valid for Open Responses output and was coerced to assistant",
        );
    }

    if let Some(content) = message.content {
        message_parts.push(ContentPart::OutputText {
            text: content,
            annotations: message
                .annotations
                .into_iter()
                .map(convert_chat_completions_annotation_to_open_responses)
                .collect(),
            logprobs: vec![],
        });
    } else if !message.annotations.is_empty() {
        ctx.warn(
            "choices[0].message.annotations",
            "annotations without message content are not representable in Open Responses response, dropped",
        );
    }

    if let Some(refusal) = message.refusal {
        message_parts.push(ContentPart::Refusal { refusal });
    }

    if !message_parts.is_empty() {
        output.push(OutputItem::Message {
            id: "msg_0".into(),
            status: ItemStatus::Completed,
            role: MessageRole::Assistant,
            content: message_parts,
        });
    }

    if let Some(tool_calls) = message.tool_calls {
        for (i, tool_call) in tool_calls.into_iter().enumerate() {
            ctx.push(format!("choices[0].message.tool_calls[{i}]"));
            if let Some(item) =
                convert_chat_completions_tool_call_to_open_responses(tool_call, i, ctx)
            {
                output.push(item);
            }
            ctx.pop();
        }
    }

    if let Some(reasoning_content) = message.reasoning_content
        && !reasoning_content.is_empty()
    {
        output.push(OutputItem::Reasoning {
            id: "rs_0".into(),
            summary: vec![ContentPart::SummaryText {
                text: reasoning_content,
            }],
            content: None,
            encrypted_content: None,
        });
    }

    if message.audio.is_some() {
        ctx.warn(
            "choices[0].message.audio",
            "audio output is not supported in Open Responses response, dropped",
        );
    }

    output
}

fn convert_chat_completions_tool_call_to_open_responses(
    tool_call: ChatCompletionsToolCall,
    index: usize,
    ctx: &mut Ctx,
) -> Option<OutputItem> {
    match tool_call {
        ChatCompletionsToolCall::Function { id, function } => Some(OutputItem::FunctionCall {
            id: format!("fc_{index}"),
            call_id: id,
            name: function.name,
            arguments: function.arguments,
            status: ItemStatus::Completed,
        }),
        ChatCompletionsToolCall::Custom { id, custom } => {
            let arguments = serde_json::to_string(&custom.input).unwrap_or_else(|_| {
                ctx.warn(
                    "custom.input",
                    "failed to serialize custom tool call input, replaced with empty object",
                );
                "{}".into()
            });
            ctx.warn(
                "custom",
                "custom tool call downgraded to function_call for Open Responses",
            );
            Some(OutputItem::FunctionCall {
                id: format!("fc_{index}"),
                call_id: id,
                name: custom.name,
                arguments,
                status: ItemStatus::Completed,
            })
        }
    }
}

fn convert_chat_completions_annotation_to_open_responses(
    ann: ChatCompletionsAnnotation,
) -> Annotation {
    match ann {
        ChatCompletionsAnnotation::UrlCitation { url_citation } => Annotation::UrlCitation {
            url: url_citation.url,
            title: url_citation.title,
            start_index: url_citation.start_index,
            end_index: url_citation.end_index,
        },
    }
}

fn convert_service_tier_to_open_responses(tier: String, ctx: &mut Ctx) -> Option<ServiceTier> {
    match tier.as_str() {
        "auto" => Some(ServiceTier::Auto),
        "default" => Some(ServiceTier::Default),
        "flex" => Some(ServiceTier::Flex),
        "priority" => Some(ServiceTier::Priority),
        "scale" => {
            ctx.warn(
                "service_tier",
                "service_tier=scale is not available in Open Responses and was mapped to priority",
            );
            Some(ServiceTier::Priority)
        }
        _ => {
            ctx.warn(
                "service_tier",
                format!("unknown service_tier '{tier}', dropped"),
            );
            None
        }
    }
}
