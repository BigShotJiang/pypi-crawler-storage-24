use super::accum::AnthropicMessageAccum;
use crate::anthropic::convert::ctx::ConversionCtx;
use crate::anthropic::convert::helpers::*;
use crate::anthropic::request::AnthropicRequest;
use crate::anthropic::types::*;
use crate::convert::mapping::LossyTryFromWithCtx;
use crate::error::{ConversionError, ConversionResult};
use crate::open_responses::request::{OpenResponsesInput, OpenResponsesRequest};
use crate::open_responses::types::*;
use crate::traits::FromOpenResponses;

impl FromOpenResponses for AnthropicRequest {
    type Source = OpenResponsesRequest;

    fn from_open_responses(
        source: OpenResponsesRequest,
    ) -> Result<ConversionResult<Self>, ConversionError> {
        let mut ctx = ConversionCtx::new();
        let (messages, system_from_input) =
            convert_open_responses_input_to_anthropic_messages(source.input, &mut ctx);

        let system = source
            .instructions
            .map(AnthropicSystem::Text)
            .or(system_from_input);

        let mut result = ConversionResult::with_warnings(
            AnthropicRequest {
                model: source.model,
                max_tokens: source
                    .max_output_tokens
                    .unwrap_or(ctx.config.default_max_tokens),
                messages,
                system,
                temperature: source.temperature,
                top_p: source.top_p,
                top_k: None,
                stop_sequences: None,
                stream: source.stream,
                metadata: None,
                tools: source.tools.map(|tools| {
                    tools
                        .into_iter()
                        .map(|t| convert_open_responses_tool_to_anthropic_messages(t, &mut ctx))
                        .collect()
                }),
                tool_choice: source
                    .tool_choice
                    .map(convert_open_responses_tool_choice_to_anthropic_messages),
                thinking: source.reasoning.and_then(|r| {
                    convert_open_responses_reasoning_to_anthropic_messages_thinking(r, &ctx)
                }),
                service_tier: source.service_tier.and_then(|tier| {
                    AnthropicServiceTier::lossy_try_from(tier, &mut ctx, "service_tier")
                }),
                cache_control: None,
                container: None,
                inference_geo: None,
                output_config: None,
            },
            ctx.into_warnings(),
        );

        result.warn_unsupported(
            "Anthropic",
            &[
                ("presence_penalty", source.presence_penalty.is_some()),
                ("frequency_penalty", source.frequency_penalty.is_some()),
                ("truncation", source.truncation.is_some()),
                ("store", source.store.is_some()),
                ("background", source.background.is_some()),
                (
                    "previous_response_id",
                    source.previous_response_id.is_some(),
                ),
                ("parallel_tool_calls", source.parallel_tool_calls.is_some()),
                ("top_logprobs", source.top_logprobs.is_some()),
                ("text", source.text.is_some()),
            ],
        );

        Ok(result)
    }
}

fn convert_open_responses_input_to_anthropic_messages(
    input: OpenResponsesInput,
    ctx: &mut ConversionCtx,
) -> (Vec<AnthropicMessage>, Option<AnthropicSystem>) {
    match input {
        OpenResponsesInput::Text(t) => (
            vec![AnthropicMessage {
                role: AnthropicRole::User,
                content: AnthropicMessageContent::Text(t),
            }],
            None,
        ),
        OpenResponsesInput::Items(items) => {
            let mut accum = AnthropicMessageAccum::new();
            let mut system_texts: Vec<String> = Vec::new();

            for (i, item) in items.into_iter().enumerate() {
                ctx.push(format!("input[{i}]"));
                match item {
                    InputItem::Message {
                        role: MessageRole::System,
                        content,
                        ..
                    } => {
                        let text = match content {
                            InputContent::Text(t) => t,
                            InputContent::Parts(parts) => parts
                                .into_iter()
                                .filter_map(|p| match p {
                                    InputContentPart::Text { text } => Some(text),
                                    _ => None,
                                })
                                .collect::<Vec<_>>()
                                .join("\n"),
                        };
                        system_texts.push(text);
                    }
                    InputItem::Message { role, content, .. } => {
                        convert_open_responses_message_to_anthropic_messages(
                            &mut accum, role, content, ctx,
                        );
                    }
                    InputItem::FunctionCall {
                        call_id,
                        name,
                        arguments,
                        ..
                    } => {
                        convert_open_responses_function_call_to_anthropic_messages(
                            &mut accum, call_id, name, arguments, ctx,
                        );
                    }
                    InputItem::FunctionCallOutput {
                        call_id, output, ..
                    } => {
                        convert_open_responses_function_call_output_to_anthropic_messages(
                            &mut accum, call_id, output, ctx,
                        );
                    }
                    InputItem::Reasoning {
                        summary,
                        encrypted_content,
                        ..
                    } => {
                        convert_open_responses_reasoning_to_anthropic_messages_block(
                            &mut accum,
                            summary,
                            encrypted_content,
                            ctx,
                        );
                    }
                    InputItem::ItemReference { .. } => {
                        ctx.warn("item_reference", "not supported in Anthropic, dropped");
                    }
                }
                ctx.pop();
            }

            let system = if system_texts.is_empty() {
                None
            } else {
                Some(AnthropicSystem::Text(system_texts.join("\n")))
            };
            (accum.into_messages(), system)
        }
    }
}

fn convert_open_responses_message_to_anthropic_messages(
    accum: &mut AnthropicMessageAccum,
    role: MessageRole,
    content: InputContent,
    ctx: &mut ConversionCtx,
) {
    let am_role = match role {
        MessageRole::User | MessageRole::System | MessageRole::Developer => AnthropicRole::User,
        MessageRole::Assistant => AnthropicRole::Assistant,
    };

    match content {
        InputContent::Text(t) => accum.push_text(am_role, t),
        InputContent::Parts(parts) => {
            let blocks = parts
                .into_iter()
                .enumerate()
                .filter_map(|(j, part)| {
                    ctx.push(format!("content[{j}]"));
                    let result = convert_open_responses_part_to_anthropic_messages(part, ctx);
                    ctx.pop();
                    result
                })
                .collect();
            accum.push_blocks(am_role, blocks);
        }
    }
}

fn convert_open_responses_function_call_to_anthropic_messages(
    accum: &mut AnthropicMessageAccum,
    call_id: String,
    name: String,
    arguments: String,
    ctx: &mut ConversionCtx,
) {
    let input = serde_json::from_str(&arguments).unwrap_or_else(|_| {
        ctx.warn(
            "function_call.arguments",
            "malformed JSON arguments, replaced with empty object",
        );
        serde_json::Value::Object(Default::default())
    });
    let block = AnthropicInputContentBlock::ToolUse {
        id: call_id,
        name,
        input,
        cache_control: None,
    };
    accum.push_blocks(AnthropicRole::Assistant, vec![block]);
}

fn convert_open_responses_function_call_output_to_anthropic_messages(
    accum: &mut AnthropicMessageAccum,
    call_id: String,
    output: FunctionCallOutputValue,
    ctx: &mut ConversionCtx,
) {
    let content = match output {
        FunctionCallOutputValue::Text(t) => Some(AnthropicToolResultContent::Text(t)),
        FunctionCallOutputValue::Parts(parts) => {
            let blocks: Vec<AnthropicToolResultBlock> = parts
                .into_iter()
                .enumerate()
                .filter_map(|(j, p)| {
                    ctx.push(format!("output[{j}]"));
                    let result = match p {
                        InputContentPart::Text { text } => {
                            Some(AnthropicToolResultBlock::Text { text })
                        }
                        InputContentPart::Image { image_url, .. } => {
                            let url = image_url?;
                            let (source, warn) = url_to_image_source(url);
                            if let Some(msg) = warn {
                                ctx.warn("image", msg);
                            }
                            Some(AnthropicToolResultBlock::Image { source })
                        }
                        InputContentPart::File {
                            filename,
                            file_data,
                            file_url,
                        } => {
                            let source = open_responses_file_to_document_source(
                                file_url,
                                file_data,
                                filename.as_deref(),
                            )?;
                            Some(AnthropicToolResultBlock::Document {
                                source,
                                citations: None,
                                context: None,
                                title: filename,
                            })
                        }
                    };
                    ctx.pop();
                    result
                })
                .collect();
            if blocks.is_empty() {
                None
            } else {
                Some(AnthropicToolResultContent::Blocks(blocks))
            }
        }
    };
    let block = AnthropicInputContentBlock::ToolResult {
        tool_use_id: call_id,
        content,
        is_error: None,
        cache_control: None,
    };
    accum.push_blocks(AnthropicRole::User, vec![block]);
}

/// Non-empty summary → Thinking (signature restored from encrypted_content).
/// Empty summary + encrypted_content → RedactedThinking.
fn convert_open_responses_reasoning_to_anthropic_messages_block(
    accum: &mut AnthropicMessageAccum,
    summary: Vec<SummaryContent>,
    encrypted_content: Option<String>,
    ctx: &mut ConversionCtx,
) {
    let block = if !summary.is_empty() {
        let text = summary
            .into_iter()
            .map(|s| s.text)
            .collect::<Vec<_>>()
            .join("\n");
        AnthropicInputContentBlock::Thinking {
            thinking: text,
            signature: encrypted_content.unwrap_or_default(),
        }
    } else if let Some(data) = encrypted_content {
        AnthropicInputContentBlock::RedactedThinking { data }
    } else {
        ctx.warn("reasoning", "empty reasoning item, skipped");
        return;
    };
    accum.push_blocks(AnthropicRole::Assistant, vec![block]);
}

fn convert_open_responses_part_to_anthropic_messages(
    part: InputContentPart,
    ctx: &mut ConversionCtx,
) -> Option<AnthropicInputContentBlock> {
    match part {
        InputContentPart::Text { text } => Some(AnthropicInputContentBlock::Text {
            text,
            cache_control: None,
            citations: None,
        }),
        InputContentPart::Image { image_url, .. } => {
            let url = image_url?;
            let (source, warn) = url_to_image_source(url);
            if let Some(msg) = warn {
                ctx.warn("image", msg);
            }
            Some(AnthropicInputContentBlock::Image {
                source,
                cache_control: None,
            })
        }
        InputContentPart::File {
            filename,
            file_data,
            file_url,
        } => {
            let source =
                open_responses_file_to_document_source(file_url, file_data, filename.as_deref())?;
            Some(AnthropicInputContentBlock::Document {
                source,
                cache_control: None,
                citations: None,
                context: None,
                title: filename,
            })
        }
    }
}

fn convert_open_responses_tool_to_anthropic_messages(
    tool: Tool,
    ctx: &mut ConversionCtx,
) -> AnthropicToolUnion {
    match tool {
        Tool::Function {
            name,
            description,
            parameters,
            strict,
        } => AnthropicToolUnion::Known(AnthropicTool {
            name,
            description,
            input_schema: parameters.unwrap_or(serde_json::json!({"type": "object"})),
            cache_control: None,
            strict,
            kind: None,
        }),
        Tool::WebSearch {
            search_context_size,
            user_location,
            filters,
        } => {
            if search_context_size.is_some() {
                ctx.warn("search_context_size", "not supported in Anthropic, dropped");
            }
            let mut obj = serde_json::json!({
                "type": "web_search_20260209",
                "name": "web_search"
            });
            if let Some(loc) = user_location {
                obj["user_location"] = serde_json::json!({
                    "type": loc.kind,
                    "city": loc.city,
                    "country": loc.country,
                    "region": loc.region,
                    "timezone": loc.timezone,
                });
            }
            if let Some(f) = filters
                && !f.allowed_domains.is_empty()
            {
                obj["allowed_domains"] = serde_json::json!(f.allowed_domains);
            }
            AnthropicToolUnion::Other(obj)
        }
    }
}

fn convert_open_responses_tool_choice_to_anthropic_messages(tc: ToolChoice) -> AnthropicToolChoice {
    match tc {
        ToolChoice::Mode(ToolChoiceMode::Auto) => AnthropicToolChoice::Auto {
            disable_parallel_tool_use: None,
        },
        ToolChoice::Mode(ToolChoiceMode::Required) => AnthropicToolChoice::Any {
            disable_parallel_tool_use: None,
        },
        ToolChoice::Mode(ToolChoiceMode::None) => AnthropicToolChoice::None,
        // TODO: error out when name is None — an empty tool name is invalid for Anthropic
        ToolChoice::Specific(SpecificToolChoice::Function { name }) => AnthropicToolChoice::Tool {
            name: name.unwrap_or_default(),
            disable_parallel_tool_use: None,
        },
        ToolChoice::AllowedTools(_) => AnthropicToolChoice::Auto {
            disable_parallel_tool_use: None,
        },
    }
}

fn convert_open_responses_reasoning_to_anthropic_messages_thinking(
    reasoning: ReasoningConfig,
    ctx: &ConversionCtx,
) -> Option<AnthropicThinkingConfig> {
    match reasoning.effort {
        Some(ReasoningEffort::None) => Some(AnthropicThinkingConfig::Disabled),
        Some(ref effort) => {
            let budget_tokens = ctx.config.effort_to_budget(effort);
            Some(AnthropicThinkingConfig::Enabled { budget_tokens })
        }
        None => None,
    }
}
