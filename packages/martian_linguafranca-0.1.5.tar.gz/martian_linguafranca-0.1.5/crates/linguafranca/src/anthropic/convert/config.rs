use crate::open_responses::types::ReasoningEffort;

pub struct AnthropicConvertConfig {
    pub default_max_tokens: u64,
    /// Maps budget_tokens thresholds to reasoning effort levels.
    /// Anthropic Messages → Open Responses: budget_tokens <= threshold → that effort level.
    /// Open Responses → Anthropic Messages: effort level → corresponding threshold as budget_tokens.
    pub reasoning_thresholds: &'static [(u64, ReasoningEffort)],
}

impl Default for AnthropicConvertConfig {
    fn default() -> Self {
        Self {
            default_max_tokens: 32_768,
            reasoning_thresholds: &[
                (2048, ReasoningEffort::Low),
                (8192, ReasoningEffort::Medium),
                (16384, ReasoningEffort::High),
                (32768, ReasoningEffort::Xhigh),
            ],
        }
    }
}

impl AnthropicConvertConfig {
    pub fn effort_to_budget(&self, effort: &ReasoningEffort) -> u64 {
        self.reasoning_thresholds
            .iter()
            .find(|(_, e)| e == effort)
            .map(|(threshold, _)| *threshold)
            .unwrap_or(self.reasoning_thresholds.last().unwrap().0)
    }

    pub fn budget_to_effort(&self, budget_tokens: u64) -> ReasoningEffort {
        self.reasoning_thresholds
            .iter()
            .find(|(threshold, _)| budget_tokens <= *threshold)
            .map(|(_, effort)| effort.clone())
            .unwrap_or(ReasoningEffort::Xhigh)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn effort_to_budget_roundtrip() {
        let config = AnthropicConvertConfig::default();
        for &(expected_budget, ref effort) in config.reasoning_thresholds {
            assert_eq!(config.effort_to_budget(effort), expected_budget);
        }
    }

    #[test]
    fn budget_to_effort_boundaries() {
        let config = AnthropicConvertConfig::default();
        assert_eq!(config.budget_to_effort(1), ReasoningEffort::Low);
        assert_eq!(config.budget_to_effort(2048), ReasoningEffort::Low);
        assert_eq!(config.budget_to_effort(2049), ReasoningEffort::Medium);
        assert_eq!(config.budget_to_effort(8192), ReasoningEffort::Medium);
        assert_eq!(config.budget_to_effort(8193), ReasoningEffort::High);
        assert_eq!(config.budget_to_effort(32768), ReasoningEffort::Xhigh);
        assert_eq!(config.budget_to_effort(99999), ReasoningEffort::Xhigh);
    }

    #[test]
    fn unknown_effort_falls_back_to_last_threshold() {
        let config = AnthropicConvertConfig {
            default_max_tokens: 1000,
            reasoning_thresholds: &[(100, ReasoningEffort::Low)],
        };
        assert_eq!(config.effort_to_budget(&ReasoningEffort::Xhigh), 100);
    }
}
