use sha2::{Digest, Sha256};

use crate::anthropic::convert::ctx::ConversionCtx;
use crate::anthropic::types::*;
use crate::open_responses::types::*;

/// Tracks state for Anthropic Messages → Open Responses streaming conversion.
///
/// Consecutive Anthropic Messages text content blocks map to content parts within a single
/// Open Responses Message item. Tool use and thinking blocks produce separate Open Responses items.
/// This accumulator manages the open Message, content indexing, sequence
/// numbering, and string buffers for "done" events.
pub(super) struct AnthropicMessagesToOpenResponsesAccum {
    pub ctx: ConversionCtx,
    pub seq: u64,
    pub output_index: u64,
    pub content_index: u64,

    pub response_id: String,
    pub model: String,
    pub service_tier: Option<ServiceTier>,

    pub message_open: bool,
    pub message_item_id: String,
    pub message_output_index: u64,

    pub current_block: CurrentBlock,
    pub text_buf: String,
    pub args_buf: String,
    pub thinking_buf: String,
    pub signature_buf: String,

    pub message_content_parts: Vec<ContentPart>,
    pub output_items: Vec<OutputItem>,
    pub usage: Option<AnthropicUsage>,
    pub stop_reason: Option<AnthropicStopReason>,

    pub pending_web_search: Option<PendingWebSearch>,

    tool_use_index: u64,
    reasoning_index: u64,
    message_index: u64,
}

#[derive(Default)]
pub(super) enum CurrentBlock {
    #[default]
    None,
    Text,
    ToolUse {
        id: String,
        name: String,
        fc_id: String,
        output_index: u64,
    },
    Thinking {
        rs_id: String,
        output_index: u64,
    },
    RedactedThinking,
    WebSearchServerToolUse {
        id: String,
        output_index: u64,
    },
    WebSearchToolResult,
}

pub(super) struct PendingWebSearch {
    pub id: String,
    pub query: Option<String>,
    pub output_index: u64,
}

impl AnthropicMessagesToOpenResponsesAccum {
    pub fn new() -> Self {
        Self {
            ctx: ConversionCtx::new(),
            seq: 0,
            output_index: 0,
            content_index: 0,
            response_id: String::new(),
            model: String::new(),
            service_tier: None,
            message_open: false,
            message_item_id: String::new(),
            message_output_index: 0,
            current_block: CurrentBlock::None,
            text_buf: String::new(),
            args_buf: String::new(),
            thinking_buf: String::new(),
            signature_buf: String::new(),
            message_content_parts: Vec::new(),
            output_items: Vec::new(),
            usage: None,
            stop_reason: None,
            pending_web_search: None,
            tool_use_index: 0,
            reasoning_index: 0,
            message_index: 0,
        }
    }

    pub fn next_seq(&mut self) -> u64 {
        let current = self.seq;
        self.seq += 1;
        current
    }

    pub fn next_output_index(&mut self) -> u64 {
        let current = self.output_index;
        self.output_index += 1;
        current
    }

    pub fn next_content_index(&mut self) -> u64 {
        let current = self.content_index;
        self.content_index += 1;
        current
    }

    pub fn gen_message_id(&mut self) -> String {
        let id = self.gen_item_id("msg", self.message_index);
        self.message_index += 1;
        id
    }

    pub fn gen_tool_use_item_id(&mut self) -> String {
        let id = self.gen_item_id("fc", self.tool_use_index);
        self.tool_use_index += 1;
        id
    }

    pub fn gen_reasoning_item_id(&mut self) -> String {
        let id = self.gen_item_id("rs", self.reasoning_index);
        self.reasoning_index += 1;
        id
    }

    fn gen_item_id(&self, prefix: &str, index: u64) -> String {
        let hash = Sha256::new()
            .chain_update(self.response_id.as_bytes())
            .chain_update(prefix.as_bytes())
            .chain_update(index.to_le_bytes())
            .finalize();
        let hex: String = hash.iter().map(|b| format!("{b:02x}")).collect();
        format!("{prefix}_{}", &hex[..56])
    }
}

/// Tracks state for Open Responses → Anthropic Messages streaming conversion.
///
/// Nearly stateless — only tracks the flat content block index and whether
/// the current thinking block needs a deferred ContentBlockStop.
pub(super) struct OpenResponsesToAnthropicMessagesAccum {
    pub ctx: ConversionCtx,
    pub block_index: u64,
    /// When true, the current thinking block's ContentBlockStop is deferred
    /// until OutputItemDone arrives with encrypted_content for SignatureDelta.
    pub thinking_block_open: bool,
    pub thinking_block_index: u64,
    /// Block index of the server_tool_use block awaiting completion via OutputItemDone.
    pub pending_web_search_block_index: Option<u64>,
}

impl OpenResponsesToAnthropicMessagesAccum {
    pub fn new() -> Self {
        Self {
            ctx: ConversionCtx::new(),
            block_index: 0,
            thinking_block_open: false,
            thinking_block_index: 0,
            pending_web_search_block_index: None,
        }
    }

    pub fn next_block_index(&mut self) -> u64 {
        let current = self.block_index;
        self.block_index += 1;
        current
    }
}
