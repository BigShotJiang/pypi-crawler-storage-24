"""
AgentApps Flow — Visual builder for multi-agent flows.

Usage:
    agentapps-flow              # start on default port 7860
    agentapps-flow --port 8080  # custom port
    agentapps-flow --no-browser # don't auto-open browser
"""

from .server import main, app

__all__ = ["main", "app"]
