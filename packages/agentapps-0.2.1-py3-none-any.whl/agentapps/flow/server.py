"""
AgentApps Flow Builder — Backend Server
Run:    python server.py
Needs:  pip install fastapi uvicorn agentapps

Key insight from reading agentapps source:
  - agent._stream_response() calls model.stream() directly — bypasses ALL tool handling
  - agent._generate_response() → _handle_tool_calls() is where tools actually run
  - So we must call agent.run(stream=False) to get tool execution,
    then simulate streaming of the final text ourselves
  - conversation_history lives on the agent object between calls — so multi-turn works
    as long as we reuse the same agent instances
"""

# ═══════════════════════════════════════════════════════════════════════
# PATCH httpx FIRST — before openai is imported
# openai==1.54.x internally calls httpx.Client(proxies=...) in its
# transport setup. httpx==0.28.x removed that kwarg. Patch here.
# ═══════════════════════════════════════════════════════════════════════
try:
    import httpx as _httpx

    _orig_client       = _httpx.Client.__init__
    _orig_async_client = _httpx.AsyncClient.__init__

    def _patched_client(self, *a, **kw):
        kw.pop("proxies", None)
        _orig_client(self, *a, **kw)

    def _patched_async_client(self, *a, **kw):
        kw.pop("proxies", None)
        _orig_async_client(self, *a, **kw)

    _httpx.Client.__init__      = _patched_client
    _httpx.AsyncClient.__init__ = _patched_async_client
    print("[compat] httpx patched — openai's internal 'proxies' kwarg dropped")

except ImportError:
    print("[compat] httpx not installed")

# ═══════════════════════════════════════════════════════════════════════
# Normal imports
# ═══════════════════════════════════════════════════════════════════════
import json, sys, asyncio, inspect, traceback, threading, queue, time
import secrets, os
from typing import Any, Optional, Dict
from datetime import datetime

from pathlib import Path

from fastapi import FastAPI, Request, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles

# Path to the bundled UI — works whether run as script OR installed as package
_UI_DIR = Path(__file__).parent / "ui"


print("\n  AgentApps Flow Builder Server")
print("  " + "─" * 38)
for _pkg, _imp in [("agentapps","agentapps"),("openai","openai"),
                   ("httpx","httpx"),("fastapi","fastapi"),("ddgs","ddgs")]:
    try:
        import importlib as _il
        _m = _il.import_module(_imp)
        print(f"  ✓ {_pkg:<14} {getattr(_m,'__version__','installed')}")
    except ImportError:
        print(f"  ✗ {_pkg:<14} NOT INSTALLED — pip install {_pkg}")
print("  " + "─" * 38 + "\n")

app = FastAPI(title="AgentApps Flow Builder", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True,
                   allow_methods=["*"], allow_headers=["*"])

# ═══════════════════════════════════════════════════════════════════════
# AUTH — session-based password protection
# ═══════════════════════════════════════════════════════════════════════

# Active session tokens: {token: created_at}
_sessions: Dict[str, str] = {}

# The UI password — set via --password flag or AGENTAPPS_PASSWORD env var
# If neither is set, an auto-generated password is printed to the console at startup
_ui_password: str = ""

# Routes that are always public (webhooks must stay accessible without login)
_PUBLIC_PREFIXES = ("/webhook/", "/health", "/login", "/auth/")


def _is_authed(request: Request) -> bool:
    """Check if request carries a valid session cookie."""
    if not _ui_password:
        return True  # auth disabled
    token = request.cookies.get("aa_session", "")
    return token in _sessions


def _login_html(error: str = "") -> str:
    err_html = f'<div class="error">{error}</div>' if error else ''
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AgentApps — Sign In</title>
<style>
  *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{
    min-height: 100vh; display: flex; align-items: center; justify-content: center;
    background: #0e0e16;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
  }}
  .card {{
    background: #16161f; border: 1px solid #2a2a3a; border-radius: 16px;
    padding: 40px 36px; width: 360px; box-shadow: 0 20px 60px #00000066;
  }}
  .logo {{ display: flex; align-items: center; gap: 10px; margin-bottom: 28px; }}
  .logo-icon {{
    width: 38px; height: 38px; background: #a78bfa22; border-radius: 10px;
    display: flex; align-items: center; justify-content: center; font-size: 18px;
  }}
  .logo-text {{ font-size: 16px; font-weight: 800; color: #e8e8f0; }}
  .logo-sub  {{ font-size: 10px; color: #6b6b8a; }}
  h2 {{ font-size: 20px; font-weight: 700; color: #e8e8f0; margin-bottom: 6px; }}
  p  {{ font-size: 12px; color: #6b6b8a; margin-bottom: 24px; }}
  label {{ font-size: 11px; font-weight: 600; color: #9090aa; display: block; margin-bottom: 6px; }}
  input {{
    width: 100%; background: #1e1e2a; border: 1px solid #2a2a3a; border-radius: 8px;
    color: #e8e8f0; font-size: 14px; padding: 10px 12px; outline: none;
    transition: border-color 0.15s; margin-bottom: 18px;
  }}
  input:focus {{ border-color: #a78bfa; }}
  button {{
    width: 100%; background: #a78bfa; border: none; border-radius: 8px;
    color: #fff; font-size: 14px; font-weight: 700; padding: 11px;
    cursor: pointer; transition: opacity 0.15s;
  }}
  button:hover {{ opacity: 0.88; }}
  .error {{
    background: #ff445520; border: 1px solid #ff445544; border-radius: 7px;
    color: #ff8899; font-size: 12px; padding: 9px 12px; margin-bottom: 16px;
  }}
</style>
</head>
<body>
<div class="card">
  <div class="logo">
    <div class="logo-icon">▶</div>
    <div><div class="logo-text">AgentApps</div><div class="logo-sub">Flow Builder</div></div>
  </div>
  <h2>Sign In</h2>
  <p>Enter your password to access the Flow Builder.</p>
  {err_html}
  <form method="POST" action="/auth/login">
    <label>Password</label>
    <input type="password" name="password" autofocus placeholder="Enter password" />
    <button type="submit">Sign In →</button>
  </form>
</div>
</body>
</html>"""


@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    """Block unauthenticated access to UI/API routes. Always allow webhook and auth routes."""
    path = request.url.path

    # Always allow public routes
    for prefix in _PUBLIC_PREFIXES:
        if path.startswith(prefix):
            return await call_next(request)

    # Auth disabled — let through
    if not _ui_password:
        return await call_next(request)

    # Authenticated — let through
    if _is_authed(request):
        return await call_next(request)

    # Not authenticated — redirect to login (HTML requests) or 401 (API requests)
    accept = request.headers.get("accept", "")
    if "text/html" in accept:
        from fastapi.responses import RedirectResponse
        return RedirectResponse(url="/login", status_code=302)
    return JSONResponse({"error": "Unauthorized"}, status_code=401)


@app.get("/login")
async def login_page():
    from fastapi.responses import HTMLResponse
    return HTMLResponse(_login_html())


@app.post("/auth/login")
async def do_login(request: Request):
    from fastapi.responses import HTMLResponse, RedirectResponse
    form = await request.form()
    password = form.get("password", "")
    if password == _ui_password:
        token = secrets.token_urlsafe(32)
        _sessions[token] = datetime.utcnow().isoformat() + "Z"
        resp = RedirectResponse(url="/", status_code=302)
        # HttpOnly cookie — not accessible from JS
        resp.set_cookie(
            "aa_session", token,
            httponly=True, samesite="lax",
            max_age=60 * 60 * 24 * 7  # 7 days
        )
        return resp
    return HTMLResponse(_login_html(error="Incorrect password. Please try again."))


@app.post("/auth/logout")
async def do_logout(request: Request):
    from fastapi.responses import RedirectResponse
    token = request.cookies.get("aa_session", "")
    _sessions.pop(token, None)
    resp = RedirectResponse(url="/login", status_code=302)
    resp.delete_cookie("aa_session")
    return resp


@app.get("/", response_class=FileResponse)
async def serve_ui():
    """Serve the Flow Builder UI."""
    return FileResponse(_UI_DIR / "index.html")


def sse(event: str, data: dict) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"

# ═══════════════════════════════════════════════════════════════════════
# Session store — keeps agent instances alive between turns so that
# conversation_history persists and multi-turn works correctly
# ═══════════════════════════════════════════════════════════════════════
import hashlib

_sessions: dict = {}   # session_key → {"built": {}, "nodes": {}, "conns": []}

# ── Imported custom tool registry ──
# key: class_name → {"cls": <the actual class>, "source": "...", "configs": {...}}
_imported_tool_registry: dict = {}

# ── Config store: persisted key→value pairs injected at exec time ──
# key: source_hash → {CONST_NAME: value, ...}
_tool_configs: dict = {}


# ===================================================================
# PROJECT + TOKEN STORE
# ===================================================================
_DATA_DIR     = Path.home() / ".agentapps"
_PROJECTS_DIR = _DATA_DIR / "projects"
_TOKENS_FILE  = _DATA_DIR / "tokens.json"

def _ensure_dirs():
    _PROJECTS_DIR.mkdir(parents=True, exist_ok=True)

def _load_tokens():
    _ensure_dirs()
    if _TOKENS_FILE.exists():
        try: return json.loads(_TOKENS_FILE.read_text())
        except Exception: return {}
    return {}

def _save_tokens(tokens):
    _ensure_dirs()
    _TOKENS_FILE.write_text(json.dumps(tokens, indent=2))

def _normalize_name(name):
    """Normalize project name for fuzzy matching: lowercase, collapse spaces/dashes/underscores."""
    import re
    return re.sub(r'[\s\-_]+', '-', name.strip().lower())

def _save_project_file(name, data):
    _ensure_dirs()
    safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in name)
    (_PROJECTS_DIR / f"{safe}.json").write_text(json.dumps(data, indent=2))

def _load_project_file(name):
    """Load project by name. Tries exact slug first, then fuzzy-matches by normalized name.
    This means 'Jira Request Refine', 'jira-request-refine', 'jira_request_refine' all find
    the same file regardless of how it was saved."""
    _ensure_dirs()
    # 1. Exact slug match (fast path)
    safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in name)
    p = _PROJECTS_DIR / f"{safe}.json"
    if p.exists():
        try: return json.loads(p.read_text())
        except Exception: return None

    # 2. Fuzzy match — scan all files, compare normalized names
    target = _normalize_name(name)
    for f in _PROJECTS_DIR.glob("*.json"):
        try:
            d = json.loads(f.read_text())
            stored_name = d.get("name", f.stem)
            if _normalize_name(stored_name) == target:
                return d
        except Exception:
            pass
    return None

def _list_project_files():
    _ensure_dirs()
    out = []
    for f in sorted(_PROJECTS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
        try:
            d = json.loads(f.read_text())
            out.append({"name": d.get("name", f.stem), "savedAt": d.get("savedAt",""),
                        "nodeCount": len(d.get("nodes",[])), "webhook": d.get("webhook",{})})
        except Exception: pass
    return out

def _require_token(authorization, query_token: str = ""):
    """
    Validate a bearer token. Accepts the token from:
      1. Authorization: Bearer <token>  header  (curl, custom clients)
      2. ?token=<token>  query parameter        (Jira, Zapier, n8n — can't set headers)
    Returns (entry_dict, raw_token_string).
    """
    raw = ""
    if authorization and authorization.startswith("Bearer "):
        raw = authorization[7:].strip()
    elif query_token:
        raw = query_token.strip()

    if not raw:
        raise HTTPException(
            status_code=401,
            detail="Missing token. Use Authorization: Bearer <token> header or ?token=<token> query param"
        )
    entry = _load_tokens().get(raw)
    if not entry:
        raise HTTPException(status_code=403, detail="Invalid or expired token")
    return entry, raw

def _src_key(source: str) -> str:
    """Same hash as the JS _srcKey() function for matching configs to source."""
    import hashlib
    # Match JS: imul(31, h) accumulation → just use md5 prefix for stability
    h = 0
    for ch in source:
        h = (31 * h + ord(ch)) & 0xFFFFFFFF
        if h >= 0x80000000:
            h -= 0x100000000
    return 'src_' + format(abs(h), 'x')

def _flow_key(flow: dict, provider: str = "openai", api_key: str = "") -> str:
    """Stable hash of flow topology + provider + masked api key (first 8 chars)."""
    topology = json.dumps(
        {"nodes": sorted(flow.get("nodes", []), key=lambda n: n["id"]),
         "connections": sorted(flow.get("connections", []),
                               key=lambda c: (c["fNode"], c["tNode"])),
         "provider": provider,
         "key_prefix": api_key[:8]},   # include key prefix so different keys get different sessions
        sort_keys=True
    )
    return hashlib.md5(topology.encode()).hexdigest()

# ═══════════════════════════════════════════════════════════════════════
# Build real agentapps objects from flow JSON
# ═══════════════════════════════════════════════════════════════════════
def build_flow(flow: dict, api_key: str, model_id: str, provider: str = 'openai'):
    from agentapps import Agent, Tool
    from agentapps.tools import SearchSummaryTool, WebScraperTool, CalculatorTool
    # Import all model classes — agentapps bundles them all
    from agentapps.model import OpenAIChat
    try:
        from agentapps.model import GeminiChat
    except ImportError:
        GeminiChat = None
    try:
        from agentapps.model import GrokChat
    except ImportError:
        GrokChat = None

    nodes = {n["id"]: n for n in flow.get("nodes", [])}
    conns = flow.get("connections", [])

    # Per-provider defaults
    _PROV_DEFAULTS = {
        "openai": {"cls": "OpenAIChat", "model": "gpt-4o"},
        "gemini": {"cls": "GeminiChat", "model": "gemini-2.0-flash-exp"},
        "grok":   {"cls": "GrokChat",   "model": "grok-3-mini"},
    }

    def make_model(node_id):
        c  = next((c for c in conns if c["tNode"] == node_id and c["tPort"] == "model"), None)
        mn = nodes.get(c["fNode"]) if c else              next((n for n in flow["nodes"] if n["type"] == "model"), None)

        # Determine provider: node setting > request-level provider > default openai
        if mn:
            d     = mn.get("data", {})
            prov  = d.get("provider") or provider or "openai"
            mid   = model_id or d.get("id") or _PROV_DEFAULTS.get(prov, _PROV_DEFAULTS["openai"])["model"]
            key   = api_key or d.get("api_key", "")
            if not key or key.startswith("os.environ"):
                key = api_key
        else:
            # No model node in flow — use request-level settings
            prov  = provider or "openai"
            mid   = model_id or _PROV_DEFAULTS.get(prov, _PROV_DEFAULTS["openai"])["model"]
            key   = api_key

        if not key:
            raise ValueError(f"No API key provided for {prov} model.")

        prov = prov.lower()
        if prov == "gemini":
            if GeminiChat is None:
                raise ImportError("GeminiChat not available. Run: pip install agentapps google-genai")
            return GeminiChat(id=mid, api_key=key)
        elif prov == "grok":
            if GrokChat is None:
                raise ImportError("GrokChat not available. Run: pip install agentapps")
            return GrokChat(id=mid, api_key=key)
        else:
            return OpenAIChat(id=mid, api_key=key)

    def make_tools(agent_node_id):
        tools = []
        for c in conns:
            if c["tNode"] != agent_node_id or c["tPort"] != "tools":
                continue
            tn = nodes.get(c["fNode"])
            if not tn:
                continue
            t, d = tn["type"], tn.get("data", {})

            if   t == "search":     tools.append(SearchSummaryTool())
            elif t == "scraper":    tools.append(WebScraperTool())
            elif t == "calculator": tools.append(CalculatorTool())
            elif t == "custom":
                tname = d.get("tool_name", "custom_tool")
                tdesc = d.get("description", "Custom tool")
                class _Dyn(Tool):
                    _n, _d = tname, tdesc
                    def __init__(self):
                        super().__init__(name=self._n, description=self._d)
                    def execute(self, input: str = "") -> str:
                        return f"[{self._n}] input={input}"
                    def get_parameters(self):
                        return {"type":"object","properties":
                                {"input":{"type":"string"}},"required":["input"]}
                tools.append(_Dyn())

            elif t.startswith("imported_"):
                class_name = t[len("imported_"):]

                # ── Extract cfg_ prefixed values from node.data ──
                # These are the config fields the user edited directly on the node
                # e.g. node.data["cfg_JIRA_API_TOKEN"] = "real-token"
                node_configs = {}
                for dk, dv in d.items():
                    if dk.startswith("cfg_"):
                        orig_key = dk[4:]   # strip cfg_ prefix → JIRA_API_TOKEN
                        node_configs[orig_key] = dv

                # Merge with any server-side stored configs (node values win)
                registry_entry = _imported_tool_registry.get(class_name, {})
                merged_configs = {**(registry_entry.get("configs") or {}), **node_configs}

                if class_name in _imported_tool_registry:
                    # ALWAYS re-exec from source with the latest configs from node fields.
                    # This ensures module-level vars (AUTH, HEADERS, etc.) are rebuilt
                    # with the actual values the user entered — not cached placeholders.
                    source = registry_entry.get("source", "")
                    print(f"[make_tools] {class_name}: node_configs={list(node_configs.keys())}, merged={list(merged_configs.keys())}")
                    if source:
                        try:
                            ns = {"__builtins__": __builtins__, "Tool": Tool}
                            for lib in ["json","os","re","requests","math","datetime","collections"]:
                                try:
                                    import importlib as _il3
                                    ns[lib] = _il3.import_module(lib)
                                except ImportError:
                                    pass
                            # Inject config values BEFORE exec
                            if merged_configs:
                                ns.update(merged_configs)
                                safe = {k: v[:4]+'***' if any(s in k.lower() for s in ['token','key','pass','secret','auth']) else v
                                        for k,v in merged_configs.items()}
                                print(f"[make_tools] injecting: {safe}")

                            # CRITICAL: strip lines where source re-assigns the injected constants
                            # e.g. JIRA_API_TOKEN = "your_api_token_here" would overwrite our injection
                            const_keys = set(merged_configs.keys())
                            if const_keys:
                                import re as _re
                                source_to_exec = "\n".join(
                                    line for line in source.split("\n")
                                    if not (_re.match(r'^([A-Z][A-Z0-9_]{2,})\s*=', line)
                                            and _re.match(r'^([A-Z][A-Z0-9_]{2,})\s*=', line).group(1) in const_keys)
                                )
                            else:
                                source_to_exec = source

                            exec(compile(source_to_exec, "<imported_tool_live>", "exec"), ns)
                            cls = ns.get(class_name)
                            if cls and issubclass(cls, Tool):
                                tools.append(cls())
                                print(f"[make_tools] ✓ instantiated {class_name} with live configs")
                            else:
                                print(f"[make_tools] class {class_name} not found in exec ns, falling back")
                                tools.append(registry_entry["cls"]())
                        except Exception as e:
                            tb = traceback.format_exc()
                            print(f"[make_tools] re-exec error for {class_name}:\n{tb}")
                            # Fall back to cached class — tool may still work if configs match
                            try:
                                tools.append(registry_entry["cls"]())
                            except Exception as e2:
                                print(f"[make_tools] fallback also failed: {e2}")
                    else:
                        # No source stored — use cached class (configs may be stale)
                        try:
                            tools.append(registry_entry["cls"]())
                            print(f"[make_tools] no source for {class_name}, using cached class")
                        except Exception as e:
                            print(f"[make_tools] cached instantiate failed: {e}")
                else:
                    # Not yet registered — need source from a previous /tools/register call
                    print(f"[make_tools] WARNING: {class_name} not in registry. "
                          f"Import the tool file first via the UI.")
        return tools

    built = {}

    # Agents first
    for nid, node in nodes.items():
        if node["type"] != "agent":
            continue
        d = node.get("data", {})
        built[nid] = Agent(
            name            = d.get("name", "Agent"),
            role            = d.get("role", "General Assistant"),
            model           = make_model(nid),
            tools           = make_tools(nid) or None,
            instructions    = [d["instructions"]] if d.get("instructions") else None,
            show_tool_calls = str(d.get("show_tool_calls","True")).lower()  in ("true","1"),
            markdown        = str(d.get("markdown","False")).lower() in ("true","1"),
        )

    # Teams second
    for nid, node in nodes.items():
        if node["type"] != "team":
            continue
        d  = node.get("data", {})
        ac = [c for c in conns if c["tNode"] == nid and c["tPort"] == "agents"]
        members = [built[c["fNode"]] for c in ac if c["fNode"] in built]
        if not members:
            raise ValueError("Team has no connected agents. Connect Agent → Team.")
        instr = None
        if d.get("instructions"):
            instr = [i.strip() for i in d["instructions"].split("\n") if i.strip()]
        built[nid] = Agent(
            team            = members,
            model           = make_model(nid),
            instructions    = instr,
            show_tool_calls = str(d.get("show_tool_calls","True")).lower() in ("true","1"),
        )

    return built, nodes, conns


def find_entry(flow: dict, built: dict) -> Optional[Any]:
    conns = flow.get("connections", [])
    prompt = next((n for n in flow["nodes"] if n["type"] == "prompt"), None)
    if prompt:
        rc = next((c for c in conns
                   if c["tNode"] == prompt["id"] and c["tPort"] == "run_target"), None)
        if rc and rc["fNode"] in built:
            return built[rc["fNode"]]
    for n in flow["nodes"]:
        if n["type"] == "team"  and n["id"] in built: return built[n["id"]]
    for n in flow["nodes"]:
        if n["type"] == "agent" and n["id"] in built: return built[n["id"]]
    return None

# ═══════════════════════════════════════════════════════════════════════
# Event capture — wraps tool.execute for live tool_call/tool_result events
# ═══════════════════════════════════════════════════════════════════════
class EventCapture:
    def __init__(self, q: queue.Queue):
        self.q = q

    def emit(self, event: str, data: dict):
        self.q.put((event, data))

    def on_text(self, text: str):
        self.q.put(("text", {"content": text}))

    def wrap_tools(self, agent: Any, agent_name: str):
        """
        Wrap every tool.execute() to emit tool_call/tool_result events.

        We store the ORIGINAL unwrapped function on the tool as _orig_execute.
        Every request re-wraps from _orig_execute so the new cap (queue) is
        always current. Without this, turn 2+ events go to the dead turn-1 queue.
        """
        cap = self
        for tool in (getattr(agent, "tools", None) or []):
            tname = getattr(tool, "name", tool.__class__.__name__)

            # Stash the pristine original once, then always wrap from it
            if not hasattr(tool, "_orig_execute"):
                tool._orig_execute = tool.execute

            orig_fn = tool._orig_execute  # always the unwrapped real function

            def _make(fn, tn, an):
                def _wrapped(*args, **kwargs):
                    try:
                        sig   = inspect.signature(fn)
                        bound = sig.bind(*args, **kwargs)
                        bound.apply_defaults()
                        call_args = {k: str(v)[:300] for k, v in bound.arguments.items()}
                    except Exception:
                        call_args = {"args": str(args)[:200]}
                    cap.emit("tool_call", {"tool": tn, "agent": an, "args": call_args})
                    try:
                        result = fn(*args, **kwargs)
                    except Exception as e:
                        cap.emit("tool_error", {"tool": tn, "agent": an, "error": str(e)})
                        raise
                    rs = str(result)
                    cap.emit("tool_result", {"tool": tn, "agent": an,
                                             "result": rs[:800], "truncated": len(rs) > 800})
                    return result
                return _wrapped

            tool.execute = _make(orig_fn, tname, agent_name)

        # Recurse into sub-agents
        for sub in (getattr(agent, "team", None) or []):
            self.wrap_tools(sub, getattr(sub, "name", "Agent"))


def fake_stream(text: str, cap: EventCapture, agent_name: str):
    """Emit text token by token to simulate streaming."""
    cap.emit("stream_start", {"agent": agent_name})
    # Split on word boundaries to stream word-by-word
    import re
    tokens = re.findall(r'\S+\s*|\n', text)
    buf = ""
    for tok in tokens:
        buf += tok
        if len(buf) >= 12 or "\n" in buf:
            cap.emit("token", {"agent": agent_name, "text": buf})
            buf = ""
            time.sleep(0.012)   # ~80 wpm pacing
    if buf:
        cap.emit("token", {"agent": agent_name, "text": buf})
    cap.emit("stream_end", {"agent": agent_name, "full": text})


def run_in_thread(agent: Any, message: str, cap: EventCapture,
                  done_q: queue.Queue, history: list = None):
    """
    Run agent.run(stream=False) so tools execute, then fake-stream the result.

    Why stream=False?
      agentapps._stream_response() calls model.stream() directly, completely
      bypassing _handle_tool_calls — tools NEVER fire in stream mode.
      _generate_response() -> _handle_tool_calls() is the only path where
      tools execute. We use stream=False then simulate streaming ourselves.

    history: previous {role, content} turns injected for multi-turn context.
    """
    try:
        is_team = bool(getattr(agent, "team", None))
        name    = getattr(agent, "name", "Team" if is_team else "Agent")

        # Restore conversation history so follow-up messages have full context
        if history:
            agent.conversation_history = list(history)
            for sub in (getattr(agent, "team", None) or []):
                sub.conversation_history = list(history)

        # Announce start
        if is_team:
            sub_names = [getattr(a, "name", "Agent") for a in (agent.team or [])]
            cap.emit("team_start", {"name": name, "agents": sub_names})
        else:
            cap.emit("agent_start", {
                "name":  name,
                "role":  getattr(agent, "role", ""),
                "tools": [getattr(t, "name", t.__class__.__name__)
                          for t in (getattr(agent, "tools", None) or [])],
            })

        # Wrap tools BEFORE run() so we get tool_call/tool_result events
        cap.wrap_tools(agent, name)

        # For team agents: inject a strong directive to act immediately.
        # Without this the LLM sometimes asks "what task?" instead of acting.
        run_message = message
        if is_team and agent.tools:
            tool_names = ", ".join(getattr(t, "name", t.__class__.__name__)
                                   for t in agent.tools)
            run_message = (
                f"Complete this task immediately using your available tools "
                f"({tool_names}). Do NOT ask for clarification — use the tools now.\n\n"
                f"Task: {message}"
            )

        # Run with stream=False so _handle_tool_calls() fires
        result = agent.run(run_message, stream=False)

        # Fake-stream the final answer
        text = (str(result).strip() if result else "") or "(no response generated)"
        fake_stream(text, cap, name)

        cap.emit("team_done" if is_team else "agent_done", {"name": name})

    except Exception as e:
        tb = traceback.format_exc()
        print(f"\n[agent error in \'{name}\']\n{tb}\n")
        cap.emit("error", {"message": str(e), "type": type(e).__name__, "trace": tb})
    finally:
        done_q.put(None)

# ═══════════════════════════════════════════════════════════════════════
# Endpoints
# ═══════════════════════════════════════════════════════════════════════

@app.get("/health")
async def health():
    info = {"status": "ok", "python": sys.version.split()[0], "httpx_patch": "applied"}
    try:
        import agentapps, openai, httpx
        info["agentapps"] = getattr(agentapps, "__version__", "installed")
        info["openai"]    = openai.__version__
        info["httpx"]     = httpx.__version__
    except ImportError as e:
        info["status"] = "degraded"; info["error"] = str(e)
    return info


@app.get("/diagnose")
async def diagnose():
    import importlib
    rep = {"python": sys.version, "packages": {}, "issues": [], "httpx_patch": "applied"}
    for pkg, imp in [("agentapps","agentapps"),("openai","openai"),("httpx","httpx"),
                     ("fastapi","fastapi"),("uvicorn","uvicorn"),
                     ("ddgs","ddgs"),("beautifulsoup4","bs4"),("requests","requests")]:
        try:
            m = importlib.import_module(imp)
            rep["packages"][pkg] = getattr(m, "__version__", "installed")
        except ImportError:
            rep["packages"][pkg] = "NOT INSTALLED"
            rep["issues"].append(f"pip install {pkg}")
    # Smoke-test all model classes
    model_status = {}
    try:
        from agentapps.model import OpenAIChat
        OpenAIChat(id="gpt-4o", api_key="smoke-test")
        model_status["OpenAIChat"] = "OK"
    except Exception as e:
        model_status["OpenAIChat"] = f"FAILED: {e}"
        rep["issues"].append(str(e))
        if "proxies" in str(e):
            rep["issues"].append("Fix: pip install 'httpx>=0.20,<0.28'")
    try:
        from agentapps.model import GeminiChat
        model_status["GeminiChat"] = "available"
    except ImportError:
        model_status["GeminiChat"] = "not installed (pip install google-genai)"
    try:
        from agentapps.model import GrokChat
        model_status["GrokChat"] = "available"
    except ImportError:
        model_status["GrokChat"] = "not installed"
    rep["model_status"] = model_status
    rep["smoke_test"] = model_status.get("OpenAIChat", "unknown")
    rep["overall"] = "OK" if not rep["issues"] else "ISSUES"
    return rep


@app.post("/run")
async def run_flow(request: Request):
    """
    Execute a flow. Body:
      { "flow": {nodes, connections}, "message": "...", "api_key": "sk-...", "model_id": "gpt-4o" }
    Returns SSE stream.
    """
    try:
        body = await request.json()
    except Exception as e:
        return JSONResponse({"error": f"Invalid JSON: {e}"}, status_code=400)

    flow     = body.get("flow", {})
    message  = body.get("message",  "").strip()
    api_key  = body.get("api_key",  "").strip()
    model_id = body.get("model_id", "").strip()
    provider = body.get("provider", "openai").strip().lower()
    # history: list of {role, content} from previous turns for multi-turn context
    history  = body.get("history",  [])

    if not message:           return JSONResponse({"error": "message required"},  status_code=400)
    if not api_key:           return JSONResponse({"error": "api_key required"},  status_code=400)
    if not flow.get("nodes"): return JSONResponse({"error": "flow has no nodes"}, status_code=400)

    async def event_stream():
        loop = asyncio.get_event_loop()
        q: queue.Queue = queue.Queue()
        cap = EventCapture(q)

        # Check session cache — reuse agents across turns for conversation memory
        fkey = _flow_key(flow, provider, api_key)
        session = _sessions.get(fkey)

        if session and session.get("api_key") == api_key:
            # Reuse existing agent instances (conversation_history preserved)
            built = session["built"]
            print(f"[session] reusing agents for flow {fkey[:8]}… (turn {session['turns']+1})")
            session["turns"] += 1
        else:
            # Build fresh agents
            try:
                built, *_ = await loop.run_in_executor(None, build_flow, flow, api_key, model_id, provider)
            except Exception as e:
                tb = traceback.format_exc()
                print(f"\n[build_flow error]\n{tb}\n")
                hint = ""
                if "proxies" in str(e):
                    hint = "Fix: pip install 'httpx>=0.20,<0.28'"
                elif "No module" in str(e):
                    hint = f"pip install {str(e).split()[-1]}"
                yield sse("error", {"message": str(e), "type": type(e).__name__,
                                    "trace": tb, "hint": hint})
                yield sse("done", {})
                return
            _sessions[fkey] = {"built": built, "api_key": api_key, "turns": 1}
            print(f"[session] created new session {fkey[:8]}…")

        entry = find_entry(flow, built)
        if not entry:
            yield sse("error", {"message": "No agent/team found. Check flow connections."})
            yield sse("done", {})
            return

        # Run agent in background thread
        threading.Thread(target=run_in_thread, args=(entry, message, cap, q, history), daemon=True).start()

        # Relay SSE events
        while True:
            try:
                item = await loop.run_in_executor(None, lambda: q.get(timeout=180))
            except Exception:
                yield sse("error", {"message": "Agent timed out after 3 minutes."})
                break
            if item is None:
                break
            yield sse(item[0], item[1])

        yield sse("done", {})

    return StreamingResponse(event_stream(), media_type="text/event-stream",
                             headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no"})


@app.post("/ai/chat")
async def ai_chat_proxy(request: Request):
    """
    Proxy for the AI Assistant panel — forwards to the correct LLM API
    based on the provider from the model node (openai / gemini / grok).
    Body: {api_key, provider, model_id, messages: [{role, content}]}
    """
    try:
        body = await request.json()
    except Exception as e:
        return JSONResponse({"error": f"Invalid JSON: {e}"}, status_code=400)

    api_key  = body.pop("api_key", "")
    provider = body.pop("provider", "openai").lower()
    model_id = body.pop("model_id", "")

    if not api_key:
        return JSONResponse({"error": "api_key required"}, status_code=400)

    messages   = body.get("messages", [])
    max_tokens = 1500

    # Extract system message for providers that need it separately
    system_msg = ""
    chat_msgs  = []
    for m in messages:
        if m.get("role") == "system":
            system_msg = m.get("content", "")
        else:
            chat_msgs.append(m)

    import httpx

    try:
        async with httpx.AsyncClient(timeout=60) as client:

            # ── OpenAI ──
            if provider == "openai":
                model = model_id or "gpt-4o"
                resp = await client.post(
                    "https://api.openai.com/v1/chat/completions",
                    headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
                    json={"model": model, "max_tokens": max_tokens, "messages": messages}
                )
                return JSONResponse(resp.json(), status_code=resp.status_code)

            # ── Grok (xAI) — OpenAI-compatible API ──
            elif provider == "grok":
                model = model_id or "grok-3-mini"
                resp = await client.post(
                    "https://api.x.ai/v1/chat/completions",
                    headers={"Content-Type": "application/json", "Authorization": f"Bearer {api_key}"},
                    json={"model": model, "max_tokens": max_tokens, "messages": messages}
                )
                return JSONResponse(resp.json(), status_code=resp.status_code)

            # ── Gemini ──
            elif provider == "gemini":
                model = model_id or "gemini-2.0-flash-exp"
                # Convert OpenAI message format to Gemini format
                gemini_contents = []
                for m in chat_msgs:
                    role = "user" if m["role"] == "user" else "model"
                    gemini_contents.append({"role": role, "parts": [{"text": m["content"]}]})
                payload = {
                    "system_instruction": {"parts": [{"text": system_msg}]} if system_msg else None,
                    "contents": gemini_contents,
                    "generationConfig": {"maxOutputTokens": max_tokens}
                }
                if payload["system_instruction"] is None:
                    del payload["system_instruction"]
                resp = await client.post(
                    f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent?key={api_key}",
                    headers={"Content-Type": "application/json"},
                    json=payload
                )
                # Normalize Gemini response to OpenAI format so UI parsing is consistent
                raw = resp.json()
                text_out = ""
                try:
                    text_out = raw["candidates"][0]["content"]["parts"][0]["text"]
                except Exception:
                    text_out = raw.get("error", {}).get("message", "No response")
                normalized = {"choices": [{"message": {"role": "assistant", "content": text_out}}]}
                return JSONResponse(normalized, status_code=resp.status_code)

            else:
                return JSONResponse({"error": f"Unknown provider: {provider}"}, status_code=400)

    except Exception as e:
        return JSONResponse({"error": str(e)}, status_code=500)


@app.post("/tools/register")
async def register_tools(request: Request):
    """
    Receive Python source code containing Tool subclasses.
    Exec the code in a sandboxed namespace and store the resulting classes.
    The UI calls this when user imports a tool file.
    """
    try:
        body = await request.json()
    except Exception as e:
        return JSONResponse({"ok": False, "error": f"Invalid JSON: {e}"}, status_code=400)

    source      = body.get("source", "")
    class_names = body.get("tools",   [])    # list of class names the UI detected
    configs     = body.get("configs", {})    # {CONST_NAME: value} from UI config editor

    if not source:
        return JSONResponse({"ok": False, "error": "No source provided"}, status_code=400)

    # Build a namespace that includes all agentapps symbols
    try:
        from agentapps import Tool, Agent
        from agentapps.tools import SearchSummaryTool, WebScraperTool, CalculatorTool
    except ImportError as e:
        return JSONResponse({"ok": False, "error": f"agentapps not installed: {e}"}, status_code=500)

    ns = {
        "__builtins__": __builtins__,
        "Tool": Tool, "Agent": Agent,
        "SearchSummaryTool": SearchSummaryTool,
        "WebScraperTool": WebScraperTool,
        "CalculatorTool": CalculatorTool,
    }
    # Pre-import common libs
    for lib in ["json", "os", "re", "requests", "math", "datetime", "collections"]:
        try:
            import importlib as _il
            ns[lib] = _il.import_module(lib)
        except ImportError:
            pass

    # ── Inject config values into namespace BEFORE exec ──
    # This replaces placeholder strings (e.g. "your_api_token_here") with real values
    if configs:
        ns.update(configs)
        skey = _src_key(source)
        _tool_configs[skey] = configs
        print(f"[tool register] injected {len(configs)} config values: {list(configs.keys())}")

    # Strip constant assignment lines for keys we're injecting
    # so the source doesn't overwrite our injected values with placeholders
    if configs:
        import re as _re2
        cfg_keys = set(configs.keys())
        source_to_exec = "\n".join(
            line for line in source.split("\n")
            if not (_re2.match(r'^([A-Z][A-Z0-9_]{2,})\s*=', line)
                    and _re2.match(r'^([A-Z][A-Z0-9_]{2,})\s*=', line).group(1) in cfg_keys)
        )
    else:
        source_to_exec = source

    try:
        exec(compile(source_to_exec, "<imported_tool>", "exec"), ns)
    except Exception as e:
        tb = traceback.format_exc()
        print(f"[tool register] exec error:\n{tb}")
        return JSONResponse({"ok": False, "error": str(e), "trace": tb}, status_code=400)

    # Collect Tool subclasses from the executed namespace
    registered = []
    for name, obj in ns.items():
        if (isinstance(obj, type) and issubclass(obj, Tool) and obj is not Tool
                and (not class_names or name in class_names)):
            # Merge new configs with any existing ones so partial updates work
            existing = _imported_tool_registry.get(name, {})
            merged   = {**(existing.get("configs") or {}), **configs}
            _imported_tool_registry[name] = {
                "cls":     obj,
                "source":  source,   # always store latest source
                "configs": merged,   # always store latest merged configs
            }
            registered.append(name)
            print(f"[tool register] registered: {name} | configs: {list(merged.keys())}")

    # Invalidate sessions — agents need to be rebuilt with new tools
    _sessions.clear()
    print(f"[tool register] sessions cleared — {len(registered)} tools registered")

    return JSONResponse({
        "ok": True,
        "registered": registered,
        "configs_applied": list(configs.keys()),
        "message": f"Registered {len(registered)} tool(s) with {len(configs)} config value(s)"
    })


@app.get("/tools/list")
async def list_tools():
    """Return currently registered custom tools with their config keys.""";
    return {
        "tools": [
            {"class_name": name,
             "available": True,
             "config_keys": list((entry.get("configs") or {}).keys())}
            for name, entry in _imported_tool_registry.items()
        ]
    }

@app.post("/tools/config")
async def update_tool_config(request: Request):
    """Update config values for already-registered tools without re-execing source.
    Just stores the new values — they're used on next agent instantiation."""
    try:
        body = await request.json()
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)

    source  = body.get("source",  "")
    configs = body.get("configs", {})
    if not configs:
        return JSONResponse({"ok": False, "error": "No configs provided"}, status_code=400)

    skey = _src_key(source) if source else None

    # Update stored configs for matching tools
    updated = []
    for name, entry in _imported_tool_registry.items():
        if entry.get("source") == source or not source:
            entry["configs"] = {**(entry.get("configs") or {}), **configs}
            updated.append(name)

    if skey:
        _tool_configs[skey] = {**(_tool_configs.get(skey) or {}), **configs}

    # Invalidate sessions so agents pick up new values
    _sessions.clear()
    print(f"[config update] updated {len(configs)} values for tools: {updated}")
    return JSONResponse({"ok": True, "updated_tools": updated, "keys": list(configs.keys())})


@app.delete("/session")
async def clear_session(request: Request):
    """Clear cached session for a flow (forces agent rebuild on next call)."""
    body = await request.json()
    fkey = _flow_key(body.get("flow", {}))
    removed = _sessions.pop(fkey, None)
    return {"cleared": removed is not None, "key": fkey[:8]}




# ===================================================================
# PROJECT API  —  server-side project persistence
# ===================================================================

@app.get("/projects")
async def list_projects():
    return {"projects": _list_project_files()}

@app.get("/projects/{name}")
async def get_project(name: str):
    data = _load_project_file(name)
    if not data:
        raise HTTPException(status_code=404, detail=f"Project not found: {name}")
    return data

@app.post("/projects/save")
async def save_project(request: Request):
    try:
        body = await request.json()
    except Exception as e:
        return JSONResponse({"ok": False, "error": str(e)}, status_code=400)
    name = body.get("name", "").strip()
    if not name:
        return JSONResponse({"ok": False, "error": "name required"}, status_code=400)
    # Preserve existing webhook config when re-saving
    existing = _load_project_file(name) or {}
    body["webhook"] = {**existing.get("webhook", {}), **body.get("webhook", {})}
    _save_project_file(name, body)
    print(f"[project] saved: {name} ({len(body.get('nodes',[]))} nodes)")
    return {"ok": True, "name": name, "savedAt": body.get("savedAt")}

@app.delete("/projects/{name}")
async def delete_project(name: str):
    import urllib.parse
    safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in name)
    p = _PROJECTS_DIR / f"{safe}.json"
    if p.exists():
        p.unlink()
        return {"ok": True, "deleted": name}
    raise HTTPException(status_code=404, detail=f"Project not found: {name}")


# ===================================================================
# TOKEN API  —  create / list / revoke webhook tokens
# ===================================================================

@app.post("/tokens/create")
async def create_token(request: Request):
    try:
        body = await request.json()
    except Exception:
        body = {}
    label   = body.get("label", "token-" + secrets.token_hex(3))
    project = body.get("project", "")    # optional: scope token to one project
    token   = secrets.token_urlsafe(32)   # 256-bit URL-safe token
    tokens  = _load_tokens()
    tokens[token] = {
        "label":     label,
        "project":   project,
        "createdAt": datetime.utcnow().isoformat() + "Z",
        "calls":     0,
    }
    _save_tokens(tokens)
    base_url = body.get("base_url", "http://localhost:7860")
    project_slug = "".join(c if c.isalnum() or c in "-_ " else "_" for c in project) if project else "{project_name}"
    print(f"[token] created: {label} (project={project or 'any'})")
    return {
        "ok":    True,
        "token": token,
        "label": label,
        "webhook_url": f"{base_url}/webhook/{project_slug}",
        "example_curl": (
            f'curl -X POST {base_url}/webhook/{project_slug} \
'
            f'  -H "Authorization: Bearer {token}" \
'
            f'  -H "Content-Type: application/json" \
'
            f'  -d \'{{"message": "your prompt here"}}\''
        ),
    }

@app.get("/tokens/debug")
async def debug_tokens():
    """Shows full token entries (except the token value itself) for troubleshooting."""
    tokens = _load_tokens()
    return {"tokens": [
        {"token_prefix": k[:12]+"...", "label": v["label"],
         "project_raw": v.get("project",""), "createdAt": v["createdAt"],
         "calls": v.get("calls", 0), "lastCall": v.get("lastCall","")}
        for k, v in tokens.items()
    ]}

@app.get("/tokens")
async def list_tokens():
    tokens = _load_tokens()
    return {"tokens": [
        {"token_prefix": k[:8]+"...", "label": v["label"],
         "project": v.get("project",""), "createdAt": v["createdAt"],
         "calls": v.get("calls", 0)}
        for k, v in tokens.items()
    ]}

@app.delete("/tokens/{token_prefix}")
async def revoke_token(token_prefix: str):
    tokens = _load_tokens()
    to_delete = [k for k in tokens if k.startswith(token_prefix)]
    if not to_delete:
        raise HTTPException(status_code=404, detail="Token not found")
    for k in to_delete:
        del tokens[k]
    _save_tokens(tokens)
    return {"ok": True, "revoked": len(to_delete)}


# ===================================================================
# WEBHOOK ENDPOINT  —  incoming trigger from external systems
# ===================================================================

async def _run_flow_for_webhook(project_data: dict, message: str, variables: dict = None) -> str:
    flow = {
        "nodes":       project_data.get("nodes", []),
        "connections": project_data.get("connections", []),
    }
    api_key  = project_data.get("webhook", {}).get("api_key", "")
    model_id = project_data.get("webhook", {}).get("model_id", "")
    provider = project_data.get("webhook", {}).get("provider", "openai")

    # Variable substitution in message — supports both:
    #   {{var}}    — our double-brace format
    #   {var}      — Jira's single-brace format (e.g. {issue.key}, {project.key})
    # Dotted keys like issue.key are stored as-is and also aliased to the last segment
    # so {issue.key} and {key} both work.
    if variables:
        # Build an expanded dict that includes dotted aliases
        # e.g. {"issue.key": "KAN-12"} also adds {"key": "KAN-12"}
        expanded = {}
        for k, v in variables.items():
            expanded[k] = str(v)
            if "." in k:
                expanded[k.split(".")[-1]] = str(v)   # alias: issue.key → key

        for k, v in expanded.items():
            message = message.replace("{{" + k + "}}", v)   # {{issue.key}}
            message = message.replace("{" + k + "}", v)     # {issue.key}  — Jira format

    loop = asyncio.get_event_loop()
    q: queue.Queue = queue.Queue()

    try:
        built, *_ = await loop.run_in_executor(None, build_flow, flow, api_key, model_id, provider)
    except Exception as e:
        return f"ERROR: {e}"

    entry = find_entry(flow, built)
    if not entry:
        return "ERROR: No agent found in project flow"

    cap = EventCapture(q)
    result_text = []

    def _collect(agent, msg, capture, q_ref, history):
        try:
            response = agent.run(msg, stream=False)
            if isinstance(response, str):
                capture.on_text(response)
            else:
                for chunk in response:
                    capture.on_text(chunk)
        except Exception as ex:
            capture.on_text(f"ERROR: {ex}")
        finally:
            q_ref.put(None)

    threading.Thread(target=_collect, args=(entry, message, cap, q, []), daemon=True).start()

    # Collect all text chunks
    timeout = 180
    start = time.time()
    while True:
        try:
            item = await loop.run_in_executor(None, lambda: q.get(timeout=5))
            if item is None:
                break
            if item[0] == "text":
                result_text.append(item[1].get("content", ""))
        except Exception:
            if time.time() - start > timeout:
                return "ERROR: Agent timed out"

    return "".join(result_text).strip() or "(no response)"


@app.post("/webhook/{project_name}")
async def incoming_webhook(project_name: str, request: Request):
    """
    Incoming webhook trigger.

    Accepts token + message from multiple sources:
      - JSON body          {"message": "..."}        curl / API clients
      - Form-encoded body  Body=..., From=...         Twilio, WhatsApp, SMS
      - Query parameters   ?message=...&token=...    Jira, Zapier, n8n, Make

    Twilio WhatsApp fields auto-mapped to variables:
      Body        → message text  + {{message_body}}
      From        → {{from_number}}
      To          → {{to_number}}
      WaId        → {{whatsapp_id}}
      ProfileName → {{sender_name}}
    """
    params = dict(request.query_params)

    # ── Auth: header takes priority, query param as fallback ──
    auth        = request.headers.get("Authorization", "")
    query_token = params.get("token", "")
    try:
        token_entry, raw_token = _require_token(auth, query_token)
    except HTTPException as e:
        print(f"[webhook] 401 auth fail | header={auth[:20]!r} | qtoken={query_token[:20]!r}")
        return JSONResponse({"error": e.detail}, status_code=e.status_code)

    scoped = token_entry.get("project", "").strip()
    print(f"[webhook] token={token_entry['label']!r} scoped={scoped!r} ({_normalize_name(scoped)!r}) project_name={project_name!r} ({_normalize_name(project_name)!r})")
    if scoped and _normalize_name(scoped) != _normalize_name(project_name):
        return JSONResponse({"error": f"Token scoped to '{scoped}', but request is for '{project_name}'"}, status_code=403)

    # ── Load project ──
    project_data = _load_project_file(project_name)
    if not project_data:
        return JSONResponse({"error": f"Project not found: {project_name}"}, status_code=404)

    # ── Parse body — supports JSON, form-encoded (Twilio/WhatsApp), and query params ──
    import urllib.parse
    body      = {}
    form_data = {}
    content_type = request.headers.get("content-type", "")

    if "application/json" in content_type:
        try:
            body = await request.json()
        except Exception:
            body = {}
    elif "application/x-www-form-urlencoded" in content_type or "multipart/form-data" in content_type:
        # Twilio, WhatsApp, SMS webhooks send form-encoded data
        try:
            form = await request.form()
            form_data = dict(form)
        except Exception:
            form_data = {}
    else:
        # Try JSON first, fall back to form
        raw_body = await request.body()
        if raw_body:
            try:
                body = await request.json()
            except Exception:
                try:
                    form_data = dict(urllib.parse.parse_qsl(raw_body.decode("utf-8", errors="replace")))
                except Exception:
                    pass

    # ── Twilio / WhatsApp field mapping ──
    # Twilio sends: Body (message text), From (sender), To (recipient),
    #               WaId (WhatsApp ID), ProfileName, NumMedia, etc.
    # Map these into our variables dict automatically.
    twilio_fields = {}
    if form_data:
        twilio_fields = form_data  # all form fields become variables
        # Common Twilio → friendly name aliases
        alias_map = {
            "Body":        "message_body",
            "From":        "from_number",
            "To":          "to_number",
            "WaId":        "whatsapp_id",
            "ProfileName": "sender_name",
            "NumMedia":    "media_count",
            "MediaUrl0":   "media_url",
            "SmsMessageSid": "sms_sid",
            "AccountSid":  "account_sid",
        }
        for twilio_key, alias in alias_map.items():
            if twilio_key in form_data:
                twilio_fields[alias] = form_data[twilio_key]

    # ── Resolve message ──
    # Priority: JSON body.message → form Body field → query param message
    raw_message = (
        body.get("message")
        or form_data.get("Body")        # Twilio WhatsApp/SMS message text
        or form_data.get("body")
        or form_data.get("text")
        or params.get("message")
        or ""
    )
    # Fix double URL-encoding (Jira sends %2520 instead of %20)
    for _ in range(3):
        decoded = urllib.parse.unquote(raw_message)
        if decoded == raw_message:
            break
        raw_message = decoded
    message = raw_message.strip()
    print(f"[webhook] content-type={content_type!r}")
    print(f"[webhook] message: {message!r}")
    if twilio_fields:
        safe_log = {k: v for k, v in twilio_fields.items() if k not in ("token",)}
        print(f"[webhook] twilio fields: {safe_log}")

    # ── Variables ──
    # Merge: JSON body.variables → form fields (Twilio) → extra query params
    variables = {**body.get("variables", {}), **twilio_fields}
    for k, v in params.items():
        if k not in ("token", "message") and k not in variables:
            variables[k] = v

    # Allow inline api_key override
    req_api_key = body.get("api_key", "") or form_data.get("api_key", "")
    if req_api_key:
        project_data.setdefault("webhook", {})["api_key"] = req_api_key

    if not message:
        return JSONResponse(
            {"error": (
                "message required. Send as: "
                "JSON {\"message\": \"...\"}, "
                "form field 'Body' (Twilio/WhatsApp), "
                "or query param ?message=..."
            )},
            status_code=400
        )

    webhook_cfg = project_data.get("webhook", {})
    if not webhook_cfg.get("api_key"):
        return JSONResponse(
            {"error": "Project has no API key configured. Set it in the Webhook panel → API Key field."},
            status_code=400
        )

    # ── Update token call counter ──
    tokens = _load_tokens()
    if raw_token in tokens:
        tokens[raw_token]["calls"] = tokens[raw_token].get("calls", 0) + 1
        tokens[raw_token]["lastCall"] = datetime.utcnow().isoformat() + "Z"
        _save_tokens(tokens)

    started_at = time.time()
    print(f"[webhook] {project_name} | token={token_entry['label']}")
    print(f"[webhook] raw message : {message[:120]}")
    if variables:
        print(f"[webhook] variables  : {variables}")

    # ── Apply message template if configured ──
    msg_template = webhook_cfg.get("message_template", "").strip()
    if msg_template:
        final_message = msg_template
        all_vars = {"message_body": message, "message": message, **variables}
        for k, v in all_vars.items():
            final_message = final_message.replace("{{" + k + "}}", str(v))
            final_message = final_message.replace("{" + k + "}", str(v))
        print(f"[webhook] templated message : {final_message[:200]}")
    else:
        final_message = message

    # ── Run agent (once) ──
    result = await _run_flow_for_webhook(project_data, final_message, variables)

    elapsed = round(time.time() - started_at, 2)
    print(f"[webhook] {project_name} completed in {elapsed}s")

    # ── Outgoing webhook (fire and forget) ──
    outgoing_url = webhook_cfg.get("outgoing_url", "")
    if outgoing_url:
        async def _post_outgoing():
            import httpx
            try:
                async with httpx.AsyncClient(timeout=15) as client:
                    await client.post(outgoing_url, json={
                        "project":  project_name,
                        "message":  message,
                        "response": result,
                        "elapsed":  elapsed,
                        "ts":       datetime.utcnow().isoformat() + "Z",
                    })
                print(f"[webhook] outgoing posted to {outgoing_url}")
            except Exception as e:
                print(f"[webhook] outgoing failed: {e}")
        asyncio.create_task(_post_outgoing())

    return {
        "ok":       True,
        "project":  project_name,
        "message":  message,
        "response": result,
        "elapsed":  elapsed,
        "ts":       datetime.utcnow().isoformat() + "Z",
    }


@app.get("/webhook/{project_name}/info")
async def webhook_info(project_name: str, request: Request):
    auth        = request.headers.get("Authorization", "")
    query_token = request.query_params.get("token", "")
    try:
        _require_token(auth, query_token)
    except HTTPException as e:
        return JSONResponse({"error": e.detail}, status_code=e.status_code)
    project_data = _load_project_file(project_name)
    if not project_data:
        raise HTTPException(status_code=404, detail=f"Project not found: {project_name}")
    nodes = project_data.get("nodes", [])
    agent_nodes = [n for n in nodes if n["type"] == "agent" or n["type"] == "team"]
    tool_nodes  = [n for n in nodes if "tool" in n["type"]]
    return {
        "project":    project_name,
        "savedAt":    project_data.get("savedAt", ""),
        "agents":     [n.get("data",{}).get("name","Agent") for n in agent_nodes],
        "tools":      [n.get("type","") for n in tool_nodes],
        "webhook_url": f"/webhook/{project_name}",
        "has_api_key": bool(project_data.get("webhook",{}).get("api_key")),
    }

# ═══════════════════════════════════════════════════════════════════════
# CLI entry point — called by `agentapps-flow` command after pip install
# ═══════════════════════════════════════════════════════════════════════

def _generate_self_signed_cert(ssl_dir: Path):
    """Generate a self-signed TLS certificate and store in ssl_dir.
    Returns (cert_path, key_path). Uses cryptography lib if available,
    falls back to subprocess openssl."""
    ssl_dir.mkdir(parents=True, exist_ok=True)
    cert_path = ssl_dir / "cert.pem"
    key_path  = ssl_dir / "key.pem"

    if cert_path.exists() and key_path.exists():
        print("  [ssl] reusing existing self-signed cert in", ssl_dir)
        return cert_path, key_path

    # Try cryptography library first (pure Python, no openssl binary needed)
    try:
        from cryptography import x509
        from cryptography.x509.oid import NameOID
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.hazmat.backends import default_backend
        import datetime as _dt, ipaddress

        print("  [ssl] generating self-signed certificate (cryptography)...")
        key = rsa.generate_private_key(
            public_exponent=65537, key_size=2048, backend=default_backend()
        )
        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.COMMON_NAME, u"agentapps-local"),
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, u"AgentApps"),
        ])
        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(_dt.datetime.utcnow())
            .not_valid_after(_dt.datetime.utcnow() + _dt.timedelta(days=825))
            .add_extension(x509.SubjectAlternativeName([
                x509.DNSName(u"localhost"),
                x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
            ]), critical=False)
            .sign(key, hashes.SHA256(), default_backend())
        )
        cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))
        key_path.write_bytes(key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        ))
        print("  [ssl] ✅ certificate written to", ssl_dir)
        return cert_path, key_path

    except ImportError:
        pass  # fall through to openssl subprocess

    # Fallback: system openssl binary
    import subprocess
    print("  [ssl] generating self-signed certificate (openssl)...")
    try:
        subprocess.run([
            "openssl", "req", "-x509", "-newkey", "rsa:2048",
            "-keyout", str(key_path), "-out", str(cert_path),
            "-days", "825", "-nodes",
            "-subj", "/CN=agentapps-local/O=AgentApps",
        ], check=True, capture_output=True)
        print("  [ssl] ✅ certificate written to", ssl_dir)
        return cert_path, key_path
    except (subprocess.CalledProcessError, FileNotFoundError) as e:
        raise RuntimeError(
            "Could not generate SSL certificate.\n"
            "Install the cryptography library:  pip install cryptography\n"
            f"Or provide --ssl-cert and --ssl-key manually.\nError: {e}"
        )


def main():
    """
    Start the AgentApps Flow Builder server and open the UI in a browser.

    Usage:
        agentapps-flow                              # HTTP on port 7860
        agentapps-flow --ssl-self-signed            # HTTPS with auto self-signed cert
        agentapps-flow --ssl-cert cert.pem --ssl-key key.pem   # HTTPS with your cert
        agentapps-flow --port 443 --ssl-cert ...    # standard HTTPS port
        agentapps-flow --port 8080 --no-browser
    """
    import argparse, uvicorn, webbrowser, threading

    parser = argparse.ArgumentParser(
        prog="agentapps-flow",
        description="AgentApps Flow Builder — visual multi-agent flow editor"
    )
    parser.add_argument("--port",           type=int,  default=7860,      help="Port (default: 7860)")
    parser.add_argument("--host",           type=str,  default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    parser.add_argument("--no-browser",     action="store_true",          help="Don't auto-open browser")
    parser.add_argument("--reload",         action="store_true",          help="Hot-reload (dev mode)")
    parser.add_argument("--password",       type=str,  default="",        help="UI password (or set AGENTAPPS_PASSWORD env var)")
    # SSL options
    parser.add_argument("--ssl-cert",       type=str,  default="",        help="Path to SSL certificate file (.pem)")
    parser.add_argument("--ssl-key",        type=str,  default="",        help="Path to SSL private key file (.pem)")
    parser.add_argument("--ssl-self-signed",action="store_true",          help="Auto-generate a self-signed certificate")
    args = parser.parse_args()

    # ── Set UI password ──
    global _ui_password
    _ui_password = (
        args.password
        or os.environ.get("AGENTAPPS_PASSWORD", "")
    )
    if not _ui_password:
        _ui_password = secrets.token_urlsafe(12)
        _auto_pw = True
    else:
        _auto_pw = False

    # ── Resolve SSL ──
    ssl_certfile = None
    ssl_keyfile  = None
    ssl_active   = False

    if args.ssl_self_signed:
        ssl_dir = Path.home() / ".agentapps" / "ssl"
        try:
            ssl_certfile, ssl_keyfile = _generate_self_signed_cert(ssl_dir)
            ssl_active = True
        except RuntimeError as e:
            print(f"\n  ❌ SSL Error: {e}\n")
            raise SystemExit(1)

    elif args.ssl_cert or args.ssl_key:
        if not args.ssl_cert or not args.ssl_key:
            print("\n  ❌ Both --ssl-cert and --ssl-key are required together.\n")
            raise SystemExit(1)
        ssl_certfile = Path(args.ssl_cert)
        ssl_keyfile  = Path(args.ssl_key)
        if not ssl_certfile.exists():
            print(f"\n  ❌ Certificate file not found: {ssl_certfile}\n")
            raise SystemExit(1)
        if not ssl_keyfile.exists():
            print(f"\n  ❌ Key file not found: {ssl_keyfile}\n")
            raise SystemExit(1)
        ssl_active = True
        print(f"  [ssl] using certificate: {ssl_certfile}")

    scheme = "https" if ssl_active else "http"
    url      = f"{scheme}://localhost:{args.port}"
    docs_url = url + "/docs"
    data_dir = Path.home() / ".agentapps"

    print()
    print("  ╔══════════════════════════════════════════════╗")
    print("  ║         AgentApps Flow Builder               ║")
    print(f"  ║   UI   → {url:<36}║")
    print(f"  ║   API  → {docs_url:<36}║")
    print(f"  ║   Data → {str(data_dir):<36}║")
    if ssl_active:
        print("  ║   🔒 HTTPS/TLS enabled                       ║")
        if args.ssl_self_signed:
            print("  ║   ⚠  Self-signed: browser will warn once     ║")
    else:
        print("  ║   ⚠  HTTP only — use --ssl-self-signed for    ║")
        print("  ║      secure webhooks                          ║")
    print("  ╠══════════════════════════════════════════════╣")
    if _auto_pw:
        print(f"  ║   🔑 Auto-generated password:                 ║")
        print(f"  ║      {_ui_password:<44}║")
        print("  ║   💡 Set a fixed password with --password      ║")
        print("  ║      or AGENTAPPS_PASSWORD env var            ║")
    else:
        print(f"  ║   🔑 Password protected ({'env var' if os.environ.get('AGENTAPPS_PASSWORD') else '--password flag'}){'':<14}║")
    print("  ║   Ctrl+C to stop                             ║")
    print("  ╚══════════════════════════════════════════════╝")
    print()

    if ssl_active:
        print("  Webhook URL format:")
        print(f"    {url}/webhook/<project-name>?token=<token>")
        print()

    # Open browser after server starts
    if not args.no_browser:
        def _open():
            import time
            time.sleep(1.6)
            webbrowser.open(url)
        threading.Thread(target=_open, daemon=True).start()

    uvicorn_kwargs = dict(
        host=args.host,
        port=args.port,
        reload=args.reload,
        log_level="info",
    )
    if ssl_active:
        uvicorn_kwargs["ssl_certfile"] = str(ssl_certfile)
        uvicorn_kwargs["ssl_keyfile"]  = str(ssl_keyfile)

    uvicorn.run("agentapps.flow.server:app", **uvicorn_kwargs)


if __name__ == "__main__":
    main()
