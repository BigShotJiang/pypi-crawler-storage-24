# agentknowledge

Official Python package for Agentknowledge.

## Status

`agentknowledge` is currently a bootstrap release.

This package is published as the official Python entry for Agentknowledge on PyPI.
It is intentionally minimal at this stage.

Future releases are expected to distribute the official Agentknowledge CLI and related binaries.

## Installation

```bash
pip install agentknowledge
```

## Usage

```bash
agentknowledge
agentknowledge --version
python -m agentknowledge
```

## Notes

- This is the official `agentknowledge` package on PyPI.
- This package is currently minimal by design.
- Source code for Agentknowledge is not published at this time.

## Links

- Homepage: https://agentable.ai

## License

Proprietary.
