use markdownify_rs::bs4::{Element, Filter, Soup};
use regex::Regex;

fn element_text(element: Element<'_>) -> String {
    match element {
        Element::Tag(tag) => tag.outer_html(),
        Element::String(text) => text.text().to_string(),
    }
}

#[test]
fn soup_find_and_find_all() {
    let soup = Soup::new("<div id='root'><p class='lead'>Hello</p><p>World</p></div>");

    let first = soup.find("p").unwrap();
    assert_eq!(first.string(), Some("Hello"));
    assert_eq!(first.get("class"), Some("lead"));

    let all = soup.find_all("p");
    assert_eq!(all.len(), 2);
    assert_eq!(all[1].string(), Some("World"));
}

#[test]
fn class_and_attribute_matching() {
    let soup = Soup::new("<div><p class='a b c'>x</p><p id='keep'>y</p></div>");

    let class_match = soup
        .find(Filter::new().name("p").attr("class", "b"))
        .unwrap();
    assert_eq!(class_match.string(), Some("x"));

    let without_id = soup.find_all(Filter::new().name("p").attr("id", false));
    assert_eq!(without_id.len(), 1);
    assert_eq!(without_id[0].string(), Some("x"));
}

#[test]
fn regex_name_matching() {
    let soup = Soup::new("<h1>A</h1><h2>B</h2><p>C</p>");
    let name_re = Regex::new(r"^h\d$").unwrap();

    let headings = soup.find_all(Filter::new().name(name_re));
    assert_eq!(headings.len(), 2);
    assert_eq!(headings[0].name(), "h1");
    assert_eq!(headings[1].name(), "h2");
}

#[test]
fn recursive_search_control() {
    let soup = Soup::new("<div><span>one</span><p><span>two</span></p></div>");
    let div = soup.find("div").unwrap();

    let direct = div.find_all(Filter::new().name("span").recursive(false));
    let deep = div.find_all(Filter::new().name("span").recursive(true));

    assert_eq!(direct.len(), 1);
    assert_eq!(deep.len(), 2);
}

#[test]
fn find_with_string_supports_text_nodes() {
    let soup = Soup::new("<div>alpha<span>beta</span></div>");
    let div = soup.find("div").unwrap();

    let text = div.find_with_string(Filter::new().string("alpha")).unwrap();
    assert_eq!(element_text(text), "alpha");

    let span = div
        .find_with_string(Filter::new().name("span").string("beta"))
        .unwrap();
    match span {
        Element::Tag(tag) => assert_eq!(tag.name(), "span"),
        Element::String(_) => panic!("expected tag"),
    }
}

#[test]
fn parent_navigation() {
    let soup = Soup::new("<section><div><p>txt</p></div></section>");
    let p = soup.find("p").unwrap();

    assert_eq!(p.parent().unwrap().name(), "div");

    let parents = p
        .parents()
        .map(|tag| tag.name().to_string())
        .collect::<Vec<_>>();

    assert!(parents.iter().any(|name| name == "div"));
    assert!(parents.iter().any(|name| name == "section"));
}

#[test]
fn sibling_navigation() {
    let soup = Soup::new("<div><p>one</p>mid<p>two</p><p>three</p></div>");
    let first = soup.find("p").unwrap();

    let next = first.next_sibling().unwrap();
    assert_eq!(element_text(next), "mid");

    let next_p = first.find_next_sibling("p").unwrap();
    assert_eq!(next_p.string(), Some("two"));

    let prev = next_p.previous_sibling().unwrap();
    assert_eq!(element_text(prev), "mid");
}

#[test]
fn document_order_navigation() {
    let soup = Soup::new("<div><p>one<b>two</b></p><p>three</p></div>");
    let p = soup.find("p").unwrap();

    let next = p.next_element().unwrap();
    assert_eq!(element_text(next), "one");

    let b = p.find("b").unwrap();
    let prev = b.previous_element().unwrap();
    assert_eq!(element_text(prev), "one");
}

#[test]
fn directional_find_apis() {
    let soup = Soup::new("<div><p>one<b>two</b></p><p>three</p></div>");
    let first = soup.find("p").unwrap();
    let second = first.find_next("p").unwrap();

    assert_eq!(second.string(), Some("three"));
    assert_eq!(
        second.find_previous("p").unwrap().get_text("", false),
        "onetwo"
    );

    let all_next = first.find_all_next("p");
    assert_eq!(all_next.len(), 1);
}

#[test]
fn css_select_support() {
    let soup = Soup::new("<div class='main'><p class='x'>a</p><p>b</p></div>");

    let selected = soup.select("div.main > p");
    assert_eq!(selected.len(), 2);

    let div = soup.find("div").unwrap();
    let first = div.select_one("p.x").unwrap();
    assert_eq!(first.string(), Some("a"));
}

#[test]
fn css_body_fallback_rewrites_only_tag_tokens() {
    let soup = Soup::new("<div data-section='html'>x</div>");

    // Should not rewrite "body" inside an attribute selector value.
    let selected = soup.select("[data-section='body']");
    assert!(selected.is_empty());
}

#[test]
fn string_iterators_and_get_text() {
    let soup = Soup::new("<div>  one <span> two </span><span>three</span></div>");
    let div = soup.find("div").unwrap();

    assert_eq!(div.string(), None);

    let strings = div.strings().map(ToString::to_string).collect::<Vec<_>>();
    assert_eq!(strings, vec!["  one ", " two ", "three"]);

    let stripped = div
        .stripped_strings()
        .map(ToString::to_string)
        .collect::<Vec<_>>();
    assert_eq!(stripped, vec!["one", "two", "three"]);

    assert_eq!(div.get_text(" ", true), "one two three");
}

#[test]
fn html_output_helpers() {
    let soup = Soup::new("<div><span>hi</span></div>");
    let div = soup.find("div").unwrap();

    assert_eq!(div.inner_html(), "<span>hi</span>");
    assert_eq!(div.outer_html(), "<div><span>hi</span></div>");

    let pretty = div.prettify();
    assert!(pretty.contains("\n"));
    assert!(pretty.contains("<span>"));
}
