#!/usr/bin/env python3
"""Ported bs4 parity tests for markdownify_rs.Soup.

This suite is intentionally focused on the read-only API surface we expose.
It ports/derives cases from:
- bs4/tests/test_tree.py
- bs4/tests/test_css.py
- bs4/tests/test_tag.py
- bs4/tests/test_navigablestring.py
"""

from __future__ import annotations

import re
import unittest
from typing import Iterable

from bs4 import BeautifulSoup
from bs4.element import NavigableString as Bs4NavigableString
from bs4.element import Tag as Bs4Tag

from markdownify_rs import NavigableString as RsNavigableString
from markdownify_rs import Soup as RsSoup
from markdownify_rs import Tag as RsTag


def norm_text(value: str) -> str:
    return "[ws]" if value.strip() == "" else value


def node_sig(node):
    if node is None:
        return None
    if isinstance(node, (RsTag, Bs4Tag)):
        return ("tag", node.name, node.get("id"), node.get_text("", True))
    if isinstance(node, (RsNavigableString, Bs4NavigableString, str)):
        return ("string", norm_text(str(node)))
    return ("other", str(node))


def node_sig_list(nodes: Iterable):
    return [node_sig(node) for node in nodes]


def id_list(nodes: Iterable):
    out = []
    for node in nodes:
        if isinstance(node, (RsTag, Bs4Tag)):
            value = node.get("id")
            if value is not None:
                out.append(str(value))
    return out


class FindFilterParity(unittest.TestCase):
    def test_find_and_find_all_core_cases(self):
        cases = [
            {
                "name": "find_tag",
                "html": "<a>1</a><b>2</b><a>3</a><b>4</b>",
                "check": lambda rs, bs: (
                    node_sig(rs.find("b")),
                    node_sig(bs.find("b")),
                ),
            },
            {
                "name": "unicode_text_find",
                "html": "<h1>Räksmörgås</h1>",
                "check": lambda rs, bs: (
                    node_sig(rs.find(string="Räksmörgås")),
                    node_sig(bs.find(string="Räksmörgås")),
                ),
            },
            {
                "name": "unicode_attribute_find",
                "html": '<h1 id="Räksmörgås">here it is</h1>',
                "check": lambda rs, bs: (
                    rs.find(id="Räksmörgås").get_text(),
                    bs.find(id="Räksmörgås").get_text(),
                ),
            },
            {
                "name": "find_everything",
                "html": "<a>foo</a><b>bar</b>",
                "check": lambda rs, bs: (len(rs.find_all()), len(bs.find_all())),
            },
            {
                "name": "find_everything_with_name",
                "html": "<a>foo</a><b>bar</b><a>baz</a>",
                "check": lambda rs, bs: (
                    len(rs.find_all("a")),
                    len(bs.find_all("a")),
                ),
            },
            {
                "name": "find_with_no_arguments",
                "html": "<div></div><p></p>",
                "check": lambda rs, bs: (
                    (rs.find().name, rs.find("p").find_previous_sibling().name),
                    (bs.find().name, bs.find("p").find_previous_sibling().name),
                ),
            },
            {
                "name": "find_with_no_arguments_only_finds_tags",
                "html": "text<div>text</div>text<p>text</p>",
                "check": lambda rs, bs: (
                    (
                        rs.find().name,
                        rs.find("p").find_previous_sibling().name,
                        rs.find("div").find_next_sibling().name,
                    ),
                    (
                        bs.find().name,
                        bs.find("p").find_previous_sibling().name,
                        bs.find("div").find_next_sibling().name,
                    ),
                ),
            },
            {
                "name": "find_all_text_nodes_exact",
                "html": "<html>Foo<b>bar</b>»</html>",
                "check": lambda rs, bs: (
                    [str(x) for x in rs.find_all(string="bar")],
                    [str(x) for x in bs.find_all(string="bar")],
                ),
            },
            {
                "name": "find_all_text_nodes_list",
                "html": "<html>Foo<b>bar</b>»</html>",
                "check": lambda rs, bs: (
                    [str(x) for x in rs.find_all(string=["Foo", "bar"])],
                    [str(x) for x in bs.find_all(string=["Foo", "bar"])],
                ),
            },
            {
                "name": "find_all_text_nodes_regex",
                "html": "<html>Foo<b>bar</b>»</html>",
                "check": lambda rs, bs: (
                    [str(x) for x in rs.find_all(string=re.compile(".*"))],
                    [str(x) for x in bs.find_all(string=re.compile(".*"))],
                ),
            },
            {
                "name": "find_all_text_nodes_true",
                "html": "<html>Foo<b>bar</b>»</html>",
                "check": lambda rs, bs: (
                    [str(x) for x in rs.find_all(string=True)],
                    [str(x) for x in bs.find_all(string=True)],
                ),
            },
            {
                "name": "find_all_limit",
                "html": "<a>1</a><a>2</a><a>3</a><a>4</a><a>5</a>",
                "check": lambda rs, bs: (
                    (
                        [x.get_text() for x in rs.find_all("a", limit=3)],
                        [x.get_text() for x in rs.find_all("a", limit=1)],
                        [x.get_text() for x in rs.find_all("a", limit=10)],
                        [x.get_text() for x in rs.find_all("a", limit=0)],
                    ),
                    (
                        [x.get_text() for x in bs.find_all("a", limit=3)],
                        [x.get_text() for x in bs.find_all("a", limit=1)],
                        [x.get_text() for x in bs.find_all("a", limit=10)],
                        [x.get_text() for x in bs.find_all("a", limit=0)],
                    ),
                ),
            },
            {
                "name": "find_all_by_tag_names",
                "html": "<a>First</a><b>Second</b><c>Third <a>Nested</a></c>",
                "check": lambda rs, bs: (
                    [x.get_text() for x in rs.find_all(["a", "b"])],
                    [x.get_text() for x in bs.find_all(["a", "b"])],
                ),
            },
            {
                "name": "find_all_by_tag_regex",
                "html": "<a>First</a><b>Second</b><c>Third <a>Nested</a></c>",
                "check": lambda rs, bs: (
                    [x.get_text() for x in rs.find_all(re.compile("^[ab]$"))],
                    [x.get_text() for x in bs.find_all(re.compile("^[ab]$"))],
                ),
            },
            {
                "name": "find_with_multi_valued_attribute",
                "html": "<div class='a b'>1</div><div class='a c'>2</div><div class='a d'>3</div>",
                "check": lambda rs, bs: (
                    (
                        rs.find("div", "a d").get_text(),
                        rs.find("div", re.compile(r"a d")).get_text(),
                        [x.get_text() for x in rs.find_all("div", ["a b", "a d"])],
                    ),
                    (
                        bs.find("div", "a d").get_text(),
                        bs.find("div", re.compile(r"a d")).get_text(),
                        [x.get_text() for x in bs.find_all("div", ["a b", "a d"])],
                    ),
                ),
            },
            {
                "name": "find_all_by_attribute_name",
                "html": "<a id='first'>Matching a.</a><a id='second'>Non-matching <b id='first'>Matching b.</b>a.</a>",
                "check": lambda rs, bs: (
                    [x.get_text() for x in rs.find_all(id="first")],
                    [x.get_text() for x in bs.find_all(id="first")],
                ),
            },
            {
                "name": "find_all_by_attribute_dict",
                "html": "<a name='name1' class='class1'>Name match.</a><a name='name2' class='class2'>Class match.</a><a name='name3' class='class3'>Non-match.</a><name1>A tag called 'name1'.</name1>",
                "check": lambda rs, bs: (
                    (
                        [x.get_text() for x in rs.find_all(attrs={"name": "name1"})],
                        [x.get_text() for x in rs.find_all(attrs={"class": "class2"})],
                        [x.get_text() for x in rs.find_all(name="name1")],
                    ),
                    (
                        [x.get_text() for x in bs.find_all(attrs={"name": "name1"})],
                        [x.get_text() for x in bs.find_all(attrs={"class": "class2"})],
                        [x.get_text() for x in bs.find_all(name="name1")],
                    ),
                ),
            },
            {
                "name": "find_all_by_class",
                "html": "<a class='1'>Class 1.</a><a class='2'>Class 2.</a><b class='1'>Class 1.</b><c class='3 4'>Class 3 and 4.</c>",
                "check": lambda rs, bs: (
                    (
                        [x.get_text() for x in rs.find_all("a", class_="1")],
                        [x.get_text() for x in rs.find_all("c", class_="3")],
                        [x.get_text() for x in rs.find_all("c", class_="4")],
                        [x.get_text() for x in rs.find_all("a", "1")],
                        [x.get_text() for x in rs.find_all(attrs="1")],
                    ),
                    (
                        [x.get_text() for x in bs.find_all("a", class_="1")],
                        [x.get_text() for x in bs.find_all("c", class_="3")],
                        [x.get_text() for x in bs.find_all("c", class_="4")],
                        [x.get_text() for x in bs.find_all("a", "1")],
                        [x.get_text() for x in bs.find_all(attrs="1")],
                    ),
                ),
            },
            {
                "name": "find_by_class_when_multiple_classes_present",
                "html": "<gar class='foo bar'>Found it</gar>",
                "check": lambda rs, bs: (
                    (
                        [x.get_text() for x in rs.find_all("gar", class_=re.compile("o"))],
                        [x.get_text() for x in rs.find_all("gar", class_=re.compile("a"))],
                        [x.get_text() for x in rs.find_all("gar", class_=re.compile("o b"))],
                    ),
                    (
                        [x.get_text() for x in bs.find_all("gar", class_=re.compile("o"))],
                        [x.get_text() for x in bs.find_all("gar", class_=re.compile("a"))],
                        [x.get_text() for x in bs.find_all("gar", class_=re.compile("o b"))],
                    ),
                ),
            },
            {
                "name": "find_all_with_non_dictionary_for_attrs",
                "html": "<a class='bar'>Found it</a>",
                "check": lambda rs, bs: (
                    (
                        [x.get_text() for x in rs.find_all("a", re.compile("ba"))],
                        [x.get_text() for x in rs.find_all("a", lambda v: len(v) > 3)],
                        [x.get_text() for x in rs.find_all("a", lambda v: len(v) <= 3)],
                    ),
                    (
                        [x.get_text() for x in bs.find_all("a", re.compile("ba"))],
                        [x.get_text() for x in bs.find_all("a", lambda v: len(v) > 3)],
                        [x.get_text() for x in bs.find_all("a", lambda v: len(v) <= 3)],
                    ),
                ),
            },
            {
                "name": "find_all_with_string_for_attrs_finds_multiple_classes",
                "html": '<a class="foo bar"></a><a class="foo"></a>',
                "check": lambda rs, bs: (
                    (
                        id_list(rs.find_all("a", "foo")),
                        id_list(rs.find_all("a", "bar")),
                        [node_sig(x) for x in rs.find_all("a", class_="foo bar")],
                        [node_sig(x) for x in rs.find_all("a", "foo bar")],
                        [node_sig(x) for x in rs.find_all("a", "bar foo")],
                    ),
                    (
                        id_list(bs.find_all("a", "foo")),
                        id_list(bs.find_all("a", "bar")),
                        [node_sig(x) for x in bs.find_all("a", class_="foo bar")],
                        [node_sig(x) for x in bs.find_all("a", "foo bar")],
                        [node_sig(x) for x in bs.find_all("a", "bar foo")],
                    ),
                ),
            },
            {
                "name": "find_all_with_missing_and_defined_attribute",
                "html": "<a id='1'>ID present.</a><a>No ID present.</a><a id=''>ID is empty.</a>",
                "check": lambda rs, bs: (
                    (
                        [x.get_text() for x in rs.find_all("a", id=None)],
                        [x.get_text() for x in rs.find_all(id=True)],
                    ),
                    (
                        [x.get_text() for x in bs.find_all("a", id=None)],
                        [x.get_text() for x in bs.find_all(id=True)],
                    ),
                ),
            },
            {
                "name": "find_all_with_numeric_attribute",
                "html": "<a id=1>Unquoted attribute.</a><a id='1'>Quoted attribute.</a>",
                "check": lambda rs, bs: (
                    (
                        [x.get_text() for x in rs.find_all(id=1)],
                        [x.get_text() for x in rs.find_all(id="1")],
                    ),
                    (
                        [x.get_text() for x in bs.find_all(id=1)],
                        [x.get_text() for x in bs.find_all(id="1")],
                    ),
                ),
            },
            {
                "name": "find_all_with_list_attribute_values",
                "html": "<a id='1'>1</a><a id='2'>2</a><a id='3'>3</a><a>No ID.</a>",
                "check": lambda rs, bs: (
                    (
                        [x.get_text() for x in rs.find_all(id=["1", "3", "4"])],
                        [x.get_text() for x in rs.find_all(id=[])],
                    ),
                    (
                        [x.get_text() for x in bs.find_all(id=["1", "3", "4"])],
                        [x.get_text() for x in bs.find_all(id=[])],
                    ),
                ),
            },
            {
                "name": "find_all_with_regex_attribute_value",
                "html": "<a id='a'>One a.</a><a id='aa'>Two as.</a><a id='ab'>Mixed.</a><a id='b'>One b.</a><a>No ID.</a>",
                "check": lambda rs, bs: (
                    [x.get_text() for x in rs.find_all(id=re.compile("^a+$"))],
                    [x.get_text() for x in bs.find_all(id=re.compile("^a+$"))],
                ),
            },
            {
                "name": "find_by_name_and_containing_string",
                "html": "<b>foo</b><b>bar</b><a>foo</a>",
                "check": lambda rs, bs: (
                    [node_sig(x) for x in rs.find_all("a", string="foo")],
                    [node_sig(x) for x in bs.find_all("a", string="foo")],
                ),
            },
            {
                "name": "find_by_name_and_containing_string_when_buried",
                "html": "<a>foo</a><a><b><c>foo</c></b></a>",
                "check": lambda rs, bs: (
                    [node_sig(x) for x in rs.find_all("a")],
                    [node_sig(x) for x in rs.find_all("a", string="foo")],
                ),
            },
            {
                "name": "find_by_attribute_and_containing_string",
                "html": "<b id='1'>foo</b><a id='2'>foo</a>",
                "check": lambda rs, bs: (
                    (
                        [node_sig(x) for x in rs.find_all(id=2, string="foo")],
                        [node_sig(x) for x in rs.find_all(id=1, string="bar")],
                    ),
                    (
                        [node_sig(x) for x in bs.find_all(id=2, string="foo")],
                        [node_sig(x) for x in bs.find_all(id=1, string="bar")],
                    ),
                ),
            },
        ]

        for case in cases:
            with self.subTest(case=case["name"]):
                rs = RsSoup(case["html"])
                bs = BeautifulSoup(case["html"], "html.parser")
                got_rs, got_bs = case["check"](rs, bs)
                self.assertEqual(got_rs, got_bs)

    def test_tag_string_and_text_methods(self):
        html = "<a>a<b>r</b>   <r> t </r></a>"
        rs = RsSoup(html)
        bs = BeautifulSoup(html, "html.parser")

        self.assertEqual(rs.find("a").string, bs.find("a").string)
        self.assertEqual(rs.find("a").get_text(strip=True), bs.find("a").get_text(strip=True))
        self.assertEqual(rs.find("a").get_text(","), bs.find("a").get_text(","))
        self.assertEqual(
            rs.find("a").get_text(",", strip=True),
            bs.find("a").get_text(",", strip=True),
        )


class NavigationParity(unittest.TestCase):
    def test_parent_navigation(self):
        html = """<ul id='empty'></ul><ul id='top'><ul id='middle'><ul id='bottom'><b id='start'>Start here</b></ul></ul></ul>"""
        rs = RsSoup(html)
        bs = BeautifulSoup(html, "html.parser")

        rs_start = rs.find("b")
        bs_start = bs.find("b")

        self.assertEqual(rs_start.parent.get("id"), bs_start.parent.get("id"))
        self.assertEqual(rs_start.parent.parent.get("id"), bs_start.parent.parent.get("id"))
        self.assertEqual(rs_start.parent.parent.parent.get("id"), bs_start.parent.parent.parent.get("id"))

        self.assertEqual(
            [x.get("id") for x in rs_start.find_parents("ul")],
            [x.get("id") for x in bs_start.find_parents("ul")],
        )
        self.assertEqual(
            [x.get("id") for x in rs_start.find_parents("ul", id="middle")],
            [x.get("id") for x in bs_start.find_parents("ul", id="middle")],
        )

    def test_next_previous_and_document_order(self):
        html = '<html id="start"><head id="headtag"></head><body id="bodytag"><b id="1">One</b><b id="2">Two</b><b id="3">Three</b></body></html>'
        rs = RsSoup(html)
        bs = BeautifulSoup(html, "html.parser")

        rs_start = rs.find("b")
        bs_start = bs.find("b")

        self.assertEqual(node_sig(rs_start.next_element), node_sig(bs_start.next_element))
        self.assertEqual(
            node_sig(rs_start.next_element.next_element),
            node_sig(bs_start.next_element.next_element),
        )

        self.assertEqual(
            [node_sig(x) for x in rs_start.find_all_next("b")],
            [node_sig(x) for x in bs_start.find_all_next("b")],
        )
        self.assertEqual(node_sig(rs_start.find_next("b")), node_sig(bs_start.find_next("b")))

        rs_end_text = rs.find(string="Three")
        bs_end_text = bs.find(string="Three")

        self.assertEqual(node_sig(rs_end_text.previous_element), node_sig(bs_end_text.previous_element))
        def drop_head_body(signatures):
            return [
                sig
                for sig in signatures
                if not (sig and sig[0] == "tag" and sig[1] in ("head", "body"))
            ]

        self.assertEqual(
            drop_head_body([node_sig(x) for x in rs_end_text.previous_elements()]),
            drop_head_body([node_sig(x) for x in bs_end_text.previous_elements]),
        )

    def test_sibling_navigation(self):
        markup = """<html><span id='1'><span id='1.1'></span></span><span id='2'><span id='2.1'></span></span><span id='3'><span id='3.1'></span></span><span id='4'></span></html>"""
        rs = RsSoup(markup)
        bs = BeautifulSoup(markup, "html.parser")

        rs_start = rs.find(id="1")
        bs_start = bs.find(id="1")

        self.assertEqual(node_sig(rs_start.next_sibling), node_sig(bs_start.next_sibling))
        self.assertEqual(node_sig(rs_start.next_element), node_sig(bs_start.next_element))

        self.assertEqual(
            [node_sig(x) for x in rs_start.find_next_siblings("span")],
            [node_sig(x) for x in bs_start.find_next_siblings("span")],
        )

        rs_end = rs.find(id="4")
        bs_end = bs.find(id="4")

        self.assertEqual(node_sig(rs_end.previous_sibling), node_sig(bs_end.previous_sibling))
        self.assertEqual(node_sig(rs_end.previous_element), node_sig(bs_end.previous_element))

        self.assertEqual(
            [node_sig(x) for x in rs_end.find_previous_siblings("span")],
            [node_sig(x) for x in bs_end.find_previous_siblings("span")],
        )


class CssSelectorParity(unittest.TestCase):
    HTML = """
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01//EN"
"http://www.w3.org/TR/html4/strict.dtd">
<html>
<head>
<title>The title</title>
<link rel="stylesheet" href="blah.css" type="text/css" id="l1">
</head>
<body>
<custom-dashed-tag class="dashed" id="dash1">Hello there.</custom-dashed-tag>
<div id="main" class="fancy">
<div id="inner">
<h1 id="header1">An H1</h1>
<p>Some text</p>
<p class="onep" id="p1">Some more text</p>
<h2 id="header2">An H2</h2>
<p class="class1 class2 class3" id="pmulti">Another</p>
<a href="http://bob.example.org/" rel="friend met" id="bob">Bob</a>
<h2 id="header3">Another H2</h2>
<a id="me" href="http://simonwillison.net/" rel="me">me</a>
<span class="s1">
<a href="#" id="s1a1">span1a1</a>
<a href="#" id="s1a2">span1a2 <span id="s1a2s1">test</span></a>
<span class="span2">
<a href="#" id="s2a1">span2a1</a>
</span>
<span class="span3"></span>
<custom-dashed-tag class="dashed" id="dash2"></custom-dashed-tag>
<div data-tag="dashedvalue" id="data1"></div>
</span>
</div>
<x id="xid">
<z id="zida"></z>
<z id="zidab"></z>
<z id="zidac"></z>
</x>
<y id="yid">
<z id="zidb"></z>
</y>
<p lang="en" id="lang-en">English</p>
<p lang="en-gb" id="lang-en-gb">English UK</p>
<p lang="en-us" id="lang-en-us">English US</p>
<p lang="fr" id="lang-fr">French</p>
</div>

<div id="footer">
</div>
"""

    def setUp(self):
        self.rs = RsSoup(self.HTML)
        self.bs = BeautifulSoup(self.HTML, "html.parser")

    def assert_select_ids(self, selector: str, expected: list[str]):
        rs_selected = self.rs.select(selector)
        bs_selected = self.bs.select(selector)
        rs_ids = sorted(id_list(rs_selected))
        bs_ids = sorted(id_list(bs_selected))
        self.assertEqual(len(bs_selected), len(rs_selected), msg=f"selector={selector}")
        self.assertEqual(sorted(expected), rs_ids, msg=f"selector={selector}")
        self.assertEqual(bs_ids, rs_ids, msg=f"selector={selector}")

    def test_css_selector_matrix(self):
        cases = [
            ("title", []),
            ("div", ["main", "inner", "data1", "footer"]),
            ("div div", ["inner", "data1"]),
            ("body div", ["main", "inner", "data1", "footer"]),
            ("custom-dashed-tag", ["dash1", "dash2"]),
            ("custom-dashed-tag[id='dash2']", ["dash2"]),
            ("h1", ["header1"]),
            ("h2", ["header2", "header3"]),
            (".onep", ["p1"]),
            ("p.onep", ["p1"]),
            ("div#inner", ["inner"]),
            ("#inner", ["inner"]),
            ("div div#inner", ["inner"]),
            ("div#inner p", ["p1", "pmulti"]),
            (".class1", ["pmulti"]),
            (".class2", ["pmulti"]),
            (".class3", ["pmulti"]),
            (".class1.class3", ["pmulti"]),
            (".class1.class2.class3", ["pmulti"]),
            (".s1 > a", ["s1a1", "s1a2"]),
            (".s1 > a#s1a2 span", ["s1a2s1"]),
            ('p[class="onep"]', ["p1"]),
            ('p[id="p1"]', ["p1"]),
            ('[class="onep"]', ["p1"]),
            ('[id="p1"]', ["p1"]),
            ('link[rel="stylesheet"]', ["l1"]),
            ('p[class~="class1"]', ["pmulti"]),
            ('a[rel~="friend"]', ["bob"]),
            ('[rel~="met"]', ["bob"]),
            ('[rel^="style"]', ["l1"]),
            ('[href^="http://"]', ["bob", "me"]),
            ('[id^="p"]', ["p1", "pmulti"]),
            ('div[id^="m"]', ["main"]),
            ('a[id^="m"]', ["me"]),
            ('[href$=".css"]', ["l1"]),
            ('link[id$="1"]', ["l1"]),
            ('div[id$="1"]', ["data1"]),
            ('[href*="http://"]', ["bob", "me"]),
            ('div[id*="nn"]', ["inner"]),
            ('div[data-tag*="edval"]', ["data1"]),
            ('p[lang|="en"]', ["lang-en", "lang-en-gb", "lang-en-us"]),
            ('p[lang|="fr"]', ["lang-fr"]),
            ('[rel]', ["l1", "bob", "me"]),
            ('[lang]', ["lang-en", "lang-en-gb", "lang-en-us", "lang-fr"]),
            ("div#inner p:nth-of-type(1)", []),
            ("#inner > p:nth-of-type(2)", ["p1"]),
            ("#p1 + h2", ["header2"]),
            ("#p1 + h2 + p", ["pmulti"]),
            ("#p1 ~ h2", ["header2", "header3"]),
            ('#p1 ~ h2 + [rel="me"]', ["me"]),
            ("x, y", ["xid", "yid"]),
            ("x, y > z", ["xid", "zidb"]),
            ("div > x, y, z", ["xid", "yid", "zida", "zidab", "zidac", "zidb"]),
            ("body > div > x, y > z", ["xid", "zidb"]),
            ("p[lang] ~ p", ["lang-en-gb", "lang-en-us", "lang-fr"]),
        ]

        for selector, expected in cases:
            with self.subTest(selector=selector):
                self.assert_select_ids(selector, expected)

    def test_select_one_and_on_element(self):
        rs = self.rs.select_one("div")
        bs = self.bs.select_one("div")
        self.assertEqual(node_sig(rs), node_sig(bs))

        rs_inner = self.rs.find("div", id="main")
        bs_inner = self.bs.find("div", id="main")
        self.assertEqual(
            sorted(id_list(rs_inner.select("div"))),
            sorted(id_list(bs_inner.select("div"))),
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
