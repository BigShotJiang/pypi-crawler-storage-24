#!/usr/bin/env python3
import re
from bs4 import BeautifulSoup
from bs4.element import NavigableString as Bs4String
from bs4.element import Tag as Bs4Tag

from markdownify_rs import NavigableString as RsString
from markdownify_rs import Soup as RsSoup
from markdownify_rs import Tag as RsTag

HTML = """
<div id="root">
  <h1 class="title main">Hello <em>World</em></h1>
  <p class="lead">alpha <b>beta</b></p>
  <p data-kind="note">gamma</p>
  <ul><li>A</li><li>B</li></ul>
</div>
"""


def normalize_node(node):
    if node is None:
        return None

    if isinstance(node, RsTag):
        return ("tag", node.outer_html())
    if isinstance(node, RsString):
        text = str(node)
        return ("string", "[ws]" if text.strip() == "" else text)

    if isinstance(node, Bs4Tag):
        return ("tag", str(node))
    if isinstance(node, Bs4String):
        text = str(node)
        return ("string", "[ws]" if text.strip() == "" else text)

    return ("other", str(node))


def normalize_list(values):
    return [normalize_node(v) for v in values]


def check(label, left, right, failures):
    if left != right:
        failures.append((label, left, right))


def main():
    bs = BeautifulSoup(HTML, "html.parser")
    rs = RsSoup(HTML)

    failures = []

    check("find(h1)", normalize_node(rs.find("h1")), normalize_node(bs.find("h1")), failures)

    check(
        "find(p, class_=lead)",
        normalize_node(rs.find("p", class_="lead")),
        normalize_node(bs.find("p", class_="lead")),
        failures,
    )

    check(
        "find_all(p)",
        normalize_list(rs.find_all("p")),
        normalize_list(bs.find_all("p")),
        failures,
    )

    check(
        "find_all([h1,p])",
        normalize_list(rs.find_all(["h1", "p"])),
        normalize_list(bs.find_all(["h1", "p"])),
        failures,
    )

    check(
        "find_all(regex)",
        normalize_list(rs.find_all(re.compile(r"^h\d$"))),
        normalize_list(bs.find_all(re.compile(r"^h\d$"))),
        failures,
    )

    check(
        "find_all(id=False)",
        normalize_list(rs.find_all("p", id=False)),
        normalize_list(bs.find_all("p", id=False)),
        failures,
    )

    check(
        "find(string='gamma')",
        normalize_node(rs.find(string="gamma")),
        normalize_node(bs.find(string="gamma")),
        failures,
    )

    check(
        "find(p,string=regex)",
        normalize_node(rs.find("p", string=re.compile("gamma"))),
        normalize_node(bs.find("p", string=re.compile("gamma"))),
        failures,
    )

    check(
        "select(div#root > p)",
        normalize_list(rs.select("div#root > p")),
        normalize_list(bs.select("div#root > p")),
        failures,
    )

    check(
        "select_one(h1 em)",
        normalize_node(rs.select_one("h1 em")),
        normalize_node(bs.select_one("h1 em")),
        failures,
    )

    rs_em = rs.find("em")
    bs_em = bs.find("em")
    check("parent.name", rs_em.parent.name, bs_em.parent.name, failures)

    rs_first_p = rs.find("p")
    bs_first_p = bs.find("p")

    check(
        "find_next_sibling(p)",
        normalize_node(rs_first_p.find_next_sibling("p")),
        normalize_node(bs_first_p.find_next_sibling("p")),
        failures,
    )

    rs_second_p = rs.find_all("p")[1]
    bs_second_p = bs.find_all("p")[1]
    check(
        "find_previous_sibling(p)",
        normalize_node(rs_second_p.find_previous_sibling("p")),
        normalize_node(bs_second_p.find_previous_sibling("p")),
        failures,
    )

    check(
        "next_element(first p)",
        normalize_node(rs_first_p.next_element),
        normalize_node(bs_first_p.next_element),
        failures,
    )

    check(
        "previous_element(second p)",
        normalize_node(rs_second_p.previous_element),
        normalize_node(bs_second_p.previous_element),
        failures,
    )

    check("get_text(strip)", rs.get_text(" ", True), bs.get_text(" ", strip=True), failures)
    check("h1.classes", rs.find("h1").classes, bs.find("h1").get("class", []), failures)

    if failures:
        print("bs4 parity mismatches:")
        for label, left, right in failures:
            print(f"- {label}")
            print(f"  rs : {left}")
            print(f"  bs4: {right}")
        raise SystemExit(1)

    print("bs4 parity checks passed (17 checks)")


if __name__ == "__main__":
    main()
