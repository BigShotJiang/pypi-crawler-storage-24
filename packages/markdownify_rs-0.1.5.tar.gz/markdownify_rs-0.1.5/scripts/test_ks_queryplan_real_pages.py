#!/usr/bin/env python3
"""Compare Kansas ingest_ks.py extraction using Soup vs QueryPlan on real pages."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path

from markdownify_rs import QueryPlan, Soup, run_batch


# Copied from ../full-text-search/scripts/ingest/ingest_ks.py for parity.
CHAPTER_NAMES = {
    "1": "Accountants; Certified Public",
    "2": "Agriculture",
    "3": "Aircraft and Airfields",
    "4": "Apportionment",
    "5": "Arbitration and Award",
    "6": "Architects",
    "7": "Attorneys at Law",
    "8": "Automobiles and Other Vehicles",
    "9": "Banks and Banking; Trust Companies",
    "10": "Bonds and Warrants",
    "11": "Census",
    "12": "Cities and Municipalities",
    "13": "Cities of the First Class",
    "14": "Cities of the Second Class",
    "15": "Cities of the Third Class",
    "16": "Contracts and Promises",
    "16a": "Consumer Credit Code",
    "17": "Corporations",
    "18": "Counties",
    "19": "Counties and County Officers",
    "20": "Courts",
    "21": "Crimes and Punishments",
    "22": "Criminal Procedure",
    "22a": "District Officers and Employees",
    "23": "Kansas Family Law Code-Revised",
    "24": "Drainage and Levees",
    "25": "Elections",
    "26": "Eminent Domain",
    "26a": "Engineers",
    "27": "Federal Jurisdiction",
    "28": "Fees and Salaries",
    "29": "Fences",
    "30": "Ferries",
    "31": "Fire Protection",
    "32": "Wildlife, Parks and Recreation",
    "33": "Statute of Frauds; Fraudulent Conveyances",
    "34": "Grain and Forage",
    "35": "Holidays and Days of Commemoration",
    "36": "Hotels, Lodginghouses and Restaurants",
    "37": "Impeachment",
    "38": "Minors",
    "39": "Dependent Persons and Persons with Disabilities; Social Welfare",
    "40": "Insurance",
    "41": "Intoxicating Liquors and Beverages",
    "42": "Irrigation",
    "43": "Jurors",
    "44": "Labor and Industries",
    "45": "Public Records, Documents and Information",
    "46": "Legislature",
    "47": "Livestock and Domestic Animals",
    "48": "Militia, Defense and Public Safety",
    "49": "Mines and Mining",
    "50": "Unfair Trade and Consumer Protection",
    "51": "Motion Pictures",
    "52": "Negotiable Instruments",
    "53": "Notaries Public and Commissioners",
    "54": "Oaths and Affirmations",
    "55": "Oil and Gas",
    "56": "Partnerships",
    "56a": "Kansas Uniform Partnership Act",
    "57": "Patent Rights and Copyrights",
    "58": "Personal and Real Property",
    "58a": "Kansas Uniform Trust Code",
    "59": "Probate Code",
    "60": "Procedure, Civil",
    "61": "Procedure, Civil, for Limited Actions",
    "62": "Procedure, Criminal",
    "63": "Procedure, Criminal, Before Justices",
    "64": "Publications, Bibliography and Calendar",
    "65": "Public Health",
    "66": "Public Utilities",
    "67": "Real Property",
    "68": "Roads and Bridges",
    "69": "Sabbath",
    "70": "Salvage",
    "70a": "Sand and Gravel",
    "71": "Schools—Community Colleges",
    "72": "Schools",
    "73": "Soldiers, Sailors and Patriotic Emblems",
    "74": "State Boards, Commissions and Authorities",
    "75": "State Departments; Public Officers and Employees",
    "76": "State Institutions and Agencies; Historical Property",
    "77": "Statutes; Administrative Rules and Regulations and Procedure",
    "78": "Suretyship",
    "79": "Taxation",
    "80": "Townships and Township Officers",
    "81": "Trademarks and Service Marks",
    "82": "Warehouses",
    "82a": "Waters and Watercourses",
    "83": "Weights and Measures",
    "84": "Uniform Commercial Code",
}


def parse_section_url(url: str) -> dict[str, str]:
    m = re.search(r"/ch(\d+[a-z]?)/(\d+[a-z]?)_(\d+)_(\d+[a-z]?)\.html", url)
    if not m:
        return {}
    chapter = m.group(1).lstrip("0") or "0"
    ch_num = m.group(2).lstrip("0") or "0"
    article_num = m.group(3).lstrip("0") or "0"
    section_num = m.group(4).lstrip("0") or "0"
    return {
        "chapter": chapter,
        "chapter_num": ch_num,
        "article_num": article_num,
        "section_file_num": section_num,
    }


def clean_text(text: str) -> str:
    return re.sub(r"\s+", " ", text).strip()


def build_output(
    *,
    section_number: str,
    section_caption: str,
    content_parts: list[str],
    history: str,
    extras: list[str],
    url: str,
) -> dict[str, str]:
    url_info = parse_section_url(url)
    chapter = url_info.get("chapter", "")
    chapter_name = CHAPTER_NAMES.get(chapter, "")

    lines: list[str] = []
    if chapter_name:
        lines.append(f"**Kansas Statutes Annotated, Chapter {chapter}: {chapter_name}**")
    else:
        lines.append(f"**Kansas Statutes Annotated, Chapter {chapter}**")
    lines.append("")

    title_line = f"## K.S.A. {section_number}"
    if section_caption:
        title_line += f". {section_caption}"
    lines.append(title_line)
    lines.append("")

    lines.extend(content_parts)

    if history:
        lines.append("")
        lines.append(f"**History:** {history}")

    if extras:
        lines.append("")
        lines.extend(extras)

    full_content = "\n\n".join(lines)
    full_content = re.sub(r"\n{3,}", "\n\n", full_content)

    display_title = f"K.S.A. {section_number}"
    if section_caption:
        display_title += f" - {section_caption}"

    return {
        "title": display_title,
        "content": full_content,
        "section_number": section_number,
        "chapter": chapter,
        "chapter_name": chapter_name,
        "article": url_info.get("article_num", ""),
        "url": url,
    }


def parse_with_soup(html: str, url: str) -> dict[str, str] | None:
    soup = Soup(html)
    print_div = soup.select_one("#print")
    if not print_div:
        return None

    stat_number_el = print_div.select_one("span.stat_number")
    stat_caption_el = print_div.select_one("span.stat_caption")

    section_number = stat_number_el.get_text(" ", True) if stat_number_el else ""
    section_caption = stat_caption_el.get_text(" ", True) if stat_caption_el else ""
    section_number = section_number.rstrip(".")

    if not section_number:
        title_tag = soup.select_one("title")
        if title_tag:
            section_number = title_tag.get_text(" ", True)
        if not section_number:
            return None

    content_parts: list[str] = []
    for p in print_div.select("p.ksa_stat"):
        text = clean_text(p.get_text(" ", True))
        if text:
            content_parts.append(text)
    if not content_parts:
        return None

    history = ""
    for p in print_div.select("p.ksa_stat_hist"):
        hist_text = clean_text(p.get_text(" ", True))
        if hist_text:
            history = re.sub(r"^History:\s*", "", hist_text)

    extras: list[str] = []
    for p in print_div.select("p.ksa_crossref, p.ksa_annotations, p.ksa_notes"):
        text = clean_text(p.get_text(" ", True))
        if text:
            extras.append(text)

    return build_output(
        section_number=section_number,
        section_caption=section_caption,
        content_parts=content_parts,
        history=history,
        extras=extras,
        url=url,
    )


def build_query_plan() -> QueryPlan:
    plan = QueryPlan()
    plan.add_select_exists("has_print", "#print")
    plan.add_select_one_text("section_number_raw", "#print span.stat_number", separator=" ", strip=True)
    plan.add_select_one_text("section_caption", "#print span.stat_caption", separator=" ", strip=True)
    plan.add_select_one_text("page_title", "title", separator=" ", strip=True)
    plan.add_select_all_texts("content_parts_raw", "#print p.ksa_stat", separator=" ", strip=True)
    plan.add_select_all_texts("history_parts_raw", "#print p.ksa_stat_hist", separator=" ", strip=True)
    plan.add_select_all_texts(
        "extras_raw",
        "#print p.ksa_crossref, #print p.ksa_annotations, #print p.ksa_notes",
        separator=" ",
        strip=True,
    )
    return plan


def parse_queryplan_rows(rows: list[dict[str, object]], urls: list[str]) -> list[dict[str, str] | None]:
    parsed: list[dict[str, str] | None] = []
    for row, url in zip(rows, urls):
        if not row["has_print"]:
            parsed.append(None)
            continue

        section_number = ((row["section_number_raw"] or "")).rstrip(".")
        section_caption = row["section_caption"] or ""
        if not section_number:
            section_number = row["page_title"] or ""
        if not section_number:
            parsed.append(None)
            continue

        content_parts = [clean_text(text) for text in row["content_parts_raw"] if clean_text(text)]
        if not content_parts:
            parsed.append(None)
            continue

        history = ""
        for hist_text in row["history_parts_raw"]:
            cleaned = clean_text(hist_text)
            if cleaned:
                history = re.sub(r"^History:\s*", "", cleaned)

        extras = [clean_text(text) for text in row["extras_raw"] if clean_text(text)]

        parsed.append(
            build_output(
                section_number=section_number,
                section_caption=section_caption,
                content_parts=content_parts,
                history=history,
                extras=extras,
                url=url,
            )
        )
    return parsed


def load_fixture(path: Path) -> tuple[str, str]:
    html = path.read_text()
    stem = path.stem
    if stem == "ks_58a_004_0008":
        url = "https://ksrevisor.gov/statutes/chapters/ch58a/058a_004_0008.html"
    elif stem == "ks_21_054_0001":
        url = "https://ksrevisor.gov/statutes/chapters/ch21/021_054_0001.html"
    elif stem == "ks_60_002_0001":
        url = "https://ksrevisor.gov/statutes/chapters/ch60/060_002_0001.html"
    else:
        raise ValueError(f"unknown fixture filename {path.name!r}")
    return html, url


def assert_equal(label: str, left: object, right: object) -> None:
    if left != right:
        raise AssertionError(
            f"{label} mismatch\nleft={json.dumps(left, ensure_ascii=False, indent=2)}\n"
            f"right={json.dumps(right, ensure_ascii=False, indent=2)}"
        )


def main(argv: list[str]) -> int:
    if argv:
        fixture_paths = [Path(arg) for arg in argv]
    else:
        fixture_paths = [
            Path("/tmp/ks_58a_004_0008.html"),
            Path("/tmp/ks_21_054_0001.html"),
            Path("/tmp/ks_60_002_0001.html"),
        ]

    loaded = [load_fixture(path) for path in fixture_paths]
    html_docs = [html for html, _ in loaded]
    urls = [url for _, url in loaded]

    soup_results = [parse_with_soup(html, url) for html, url in zip(html_docs, urls)]
    rows_default = run_batch(html_docs, build_query_plan())
    rows_single = run_batch(html_docs, build_query_plan(), workers=1)
    rows_four = run_batch(html_docs, build_query_plan(), workers=4)

    assert_equal("workers parity (default vs 1)", rows_default, rows_single)
    assert_equal("workers parity (default vs 4)", rows_default, rows_four)

    qp_results = parse_queryplan_rows(rows_default, urls)
    assert_equal("Kansas ingest parity", qp_results, soup_results)

    print("Kansas QueryPlan real-page parity passed")
    for url, result in zip(urls, qp_results):
        assert result is not None
        print(f"- {url}")
        print(f"  title: {result['title']}")
        print(f"  content length: {len(result['content'])}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
