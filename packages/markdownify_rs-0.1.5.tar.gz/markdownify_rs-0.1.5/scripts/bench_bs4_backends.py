#!/usr/bin/env python3
"""Benchmark bs4 backends vs markdownify_rs Soup on real HTML inputs."""

from __future__ import annotations

import argparse
import datetime as dt
import gc
import math
import os
import platform
import re
import statistics
import sys
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Tuple

from bs4 import BeautifulSoup
from markdownify_rs import Soup as RustSoup


HEADING_RE = re.compile(r"^h\\d$")
DASHED_RE = re.compile(r"dashed", re.I)
SELECTORS = [
    "a[href]",
    "div",
    "p",
    "li",
    "table",
    "tr",
    "td",
    "h1, h2, h3, h4, h5, h6",
    "#main, #content, main, article",
    ".class1, .class2, .class3",
    "[id]",
    "[class]",
    "[href*='http']",
    "[lang|='en']",
    "div a[href], p, li",
    "p + p",
    "p ~ p",
    "body div",
    "body > div",
    "body > div > x, y > z",
]


@dataclass
class BenchStats:
    iterations: int
    total_seconds: float
    min_ms: float
    median_ms: float
    mean_ms: float
    p95_ms: float
    max_ms: float


class Backend:
    def __init__(self, name: str, parse_fn: Callable[[str], object]) -> None:
        self.name = name
        self._parse_fn = parse_fn

    def parse(self, html: str):
        return self._parse_fn(html)


def percentile_ms(values: List[float], p: float) -> float:
    if not values:
        return 0.0
    if len(values) == 1:
        return values[0] * 1000.0
    ordered = sorted(values)
    pos = (len(ordered) - 1) * p
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return ordered[lo] * 1000.0
    frac = pos - lo
    return (ordered[lo] * (1.0 - frac) + ordered[hi] * frac) * 1000.0


def benchmark(fn: Callable[[], object], warmups: int, min_seconds: float, max_iters: int) -> BenchStats:
    for _ in range(warmups):
        fn()

    samples: List[float] = []
    total = 0.0

    gc_was_enabled = gc.isenabled()
    if gc_was_enabled:
        gc.disable()

    try:
        while len(samples) < 5 or total < min_seconds:
            if len(samples) >= max_iters:
                break
            start = time.perf_counter()
            fn()
            elapsed = time.perf_counter() - start
            samples.append(elapsed)
            total += elapsed
    finally:
        if gc_was_enabled:
            gc.enable()

    return BenchStats(
        iterations=len(samples),
        total_seconds=total,
        min_ms=min(samples) * 1000.0,
        median_ms=statistics.median(samples) * 1000.0,
        mean_ms=statistics.mean(samples) * 1000.0,
        p95_ms=percentile_ms(samples, 0.95),
        max_ms=max(samples) * 1000.0,
    )


def count_limited_next_elements(node: object, limit: int) -> int:
    attr = getattr(node, "next_elements", None)
    if attr is None:
        return 0

    iterator = attr() if callable(attr) else attr
    count = 0
    for _ in iterator:
        count += 1
        if count >= limit:
            break
    return count


def workload_find_heavy(soup: object) -> int:
    total = 0
    total += len(soup.find_all("a"))
    total += len(soup.find_all("p"))
    total += len(soup.find_all("div"))
    total += len(soup.find_all("li"))
    total += len(soup.find_all(HEADING_RE))
    total += len(soup.find_all(id=True))
    total += len(soup.find_all(class_=True))
    total += len(soup.find_all(attrs={"data-tag": DASHED_RE}))
    total += len(soup.find_all("a", string=True))
    total += len(soup.find_all(string=HEADING_RE))
    return total


def workload_select_heavy(soup: object) -> int:
    total = 0
    for selector in SELECTORS:
        total += len(soup.select(selector))
    one = soup.select_one("body > div")
    if one is not None:
        total += 1
    return total


def workload_navigation_heavy(soup: object) -> int:
    start = soup.find("a") or soup.find("p") or soup.find("div")
    if start is None:
        return 0

    total = 0
    total += count_limited_next_elements(start, 300)

    total += len(start.find_next_siblings())
    total += len(start.find_previous_siblings())

    found_next = start.find_next("p")
    if found_next is not None:
        total += 1

    paragraphs = soup.find_all("p")
    if paragraphs:
        total += len(paragraphs[0].find_next_siblings("p"))
        total += len(paragraphs[-1].find_previous_siblings("p"))

    node = start
    for _ in range(300):
        nxt = getattr(node, "next_element", None)
        if nxt is None:
            break
        total += 1
        node = nxt

    return total


def workload_text_heavy(soup: object) -> int:
    text_strip = soup.get_text(" ", True)
    text_raw = soup.get_text("\n", False)
    strings = soup.find_all(string=True)
    sample = strings[:200]
    string_chars = sum(len(str(s)) for s in sample)
    return len(text_strip) + len(text_raw) + len(strings) + string_chars


def workload_query_suite(soup: object) -> int:
    total = 0
    total += workload_find_heavy(soup)
    total += workload_select_heavy(soup)
    total += workload_navigation_heavy(soup)
    total += workload_text_heavy(soup)

    title = soup.find("title")
    if title is not None:
        total += len(title.get_text("", True))

    return total


def compute_sanity(soup: object) -> Dict[str, int]:
    return {
        "a_tags": len(soup.find_all("a")),
        "p_tags": len(soup.find_all("p")),
        "div_tags": len(soup.find_all("div")),
        "text_nodes": len(soup.find_all(string=True)),
        "text_len_strip": len(soup.get_text(" ", True)),
        "selector_hits": len(soup.select("a[href], p, li")),
        "suite_score": workload_query_suite(soup),
    }


def geometric_mean(values: List[float]) -> float:
    if not values:
        return 0.0
    return math.exp(sum(math.log(v) for v in values) / len(values))


def render_report(
    html_path: str,
    html_size: int,
    min_seconds: float,
    warmups: int,
    results: Dict[Tuple[str, str], BenchStats],
    sanity: Dict[str, Dict[str, int]],
) -> str:
    now = dt.datetime.now().isoformat(timespec="seconds")

    backends = ["bs4_html_parser", "bs4_lxml", "rust_bs4"]
    cases = [
        "parse_only",
        "find_heavy",
        "select_heavy",
        "navigation_heavy",
        "text_heavy",
        "end_to_end",
    ]

    out: List[str] = []
    out.append("# BS4 Backend Benchmark (Real HTML)")
    out.append("")
    out.append(f"- Timestamp: `{now}`")
    out.append(f"- Host: `{platform.platform()}`")
    out.append(f"- Python: `{sys.version.split()[0]}`")
    out.append(f"- Input HTML: `{html_path}`")
    out.append(f"- Input size: `{html_size:,}` bytes")
    out.append(f"- Warmups per case/backend: `{warmups}`")
    out.append(f"- Min timed duration per case/backend: `{min_seconds:.2f}` s")
    out.append("")

    out.append("## Workloads")
    out.append("")
    out.append("- `parse_only`: Parse HTML into a tree.")
    out.append("- `find_heavy`: Repeated `find/find_all` with names, attrs, regex, and string filters.")
    out.append("- `select_heavy`: Repeated CSS selector queries (simple + combinators + attribute selectors).")
    out.append("- `navigation_heavy`: Sibling/document-order traversal (`next_element`, `find_next_siblings`, etc.).")
    out.append("- `text_heavy`: `get_text` and string-node scans.")
    out.append("- `end_to_end`: Parse + full mixed query suite.")
    out.append("")

    out.append("## Sanity Check Outputs")
    out.append("")
    out.append("These values confirm each backend ran the same workload shape (parser differences can cause minor count differences).")
    out.append("")
    out.append("| Backend | a_tags | p_tags | div_tags | text_nodes | text_len_strip | selector_hits | suite_score |")
    out.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")
    for backend in backends:
        s = sanity[backend]
        out.append(
            f"| {backend} | {s['a_tags']} | {s['p_tags']} | {s['div_tags']} | {s['text_nodes']} | {s['text_len_strip']} | {s['selector_hits']} | {s['suite_score']} |"
        )
    out.append("")

    out.append("## Per-Case Results")
    out.append("")
    for case in cases:
        out.append(f"### `{case}`")
        out.append("")
        out.append("| Backend | Median (ms) | Mean (ms) | p95 (ms) | Min (ms) | Max (ms) | Iterations | Speedup vs `bs4_html_parser` |")
        out.append("| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |")

        baseline = results[(case, "bs4_html_parser")].median_ms
        for backend in backends:
            stat = results[(case, backend)]
            speed = baseline / stat.median_ms if stat.median_ms > 0 else 0.0
            out.append(
                f"| {backend} | {stat.median_ms:.3f} | {stat.mean_ms:.3f} | {stat.p95_ms:.3f} | {stat.min_ms:.3f} | {stat.max_ms:.3f} | {stat.iterations} | {speed:.2f}x |"
            )
        out.append("")

    out.append("## Overall Speedup (Geometric Mean Of Medians)")
    out.append("")
    out.append("Computed across all workloads above.")
    out.append("")
    out.append("| Backend | Relative to `bs4_html_parser` |")
    out.append("| --- | ---: |")

    baseline_ratios = []
    lxml_ratios = []
    rust_ratios = []

    for case in cases:
        m_html = results[(case, "bs4_html_parser")].median_ms
        m_lxml = results[(case, "bs4_lxml")].median_ms
        m_rust = results[(case, "rust_bs4")].median_ms
        baseline_ratios.append(1.0)
        lxml_ratios.append(m_html / m_lxml)
        rust_ratios.append(m_html / m_rust)

    out.append(f"| bs4_html_parser | {geometric_mean(baseline_ratios):.2f}x |")
    out.append(f"| bs4_lxml | {geometric_mean(lxml_ratios):.2f}x |")
    out.append(f"| rust_bs4 | {geometric_mean(rust_ratios):.2f}x |")
    out.append("")

    out.append("## Direct Relative Comparisons")
    out.append("")

    rust_vs_lxml = []
    for case in cases:
        m_lxml = results[(case, "bs4_lxml")].median_ms
        m_rust = results[(case, "rust_bs4")].median_ms
        rust_vs_lxml.append(m_lxml / m_rust)

    out.append(f"- rust_bs4 vs bs4_html_parser (geo mean): `{geometric_mean(rust_ratios):.2f}x` faster")
    out.append(f"- bs4_lxml vs bs4_html_parser (geo mean): `{geometric_mean(lxml_ratios):.2f}x` faster")
    out.append(f"- rust_bs4 vs bs4_lxml (geo mean): `{geometric_mean(rust_vs_lxml):.2f}x` faster")
    out.append("")

    return "\n".join(out)


def run(html: str, html_path: str, min_seconds: float, warmups: int, max_iters: int) -> Tuple[Dict[Tuple[str, str], BenchStats], Dict[str, Dict[str, int]]]:
    backends = [
        Backend("bs4_html_parser", lambda data: BeautifulSoup(data, "html.parser")),
        Backend("bs4_lxml", lambda data: BeautifulSoup(data, "lxml")),
        Backend("rust_bs4", lambda data: RustSoup(data)),
    ]

    results: Dict[Tuple[str, str], BenchStats] = {}
    sanity: Dict[str, Dict[str, int]] = {}

    for backend in backends:
        parsed = backend.parse(html)
        sanity[backend.name] = compute_sanity(parsed)

        jobs = {
            "parse_only": lambda b=backend, h=html: b.parse(h),
            "find_heavy": lambda s=parsed: workload_find_heavy(s),
            "select_heavy": lambda s=parsed: workload_select_heavy(s),
            "navigation_heavy": lambda s=parsed: workload_navigation_heavy(s),
            "text_heavy": lambda s=parsed: workload_text_heavy(s),
            "end_to_end": lambda b=backend, h=html: workload_query_suite(b.parse(h)),
        }

        for case, fn in jobs.items():
            stats = benchmark(fn, warmups=warmups, min_seconds=min_seconds, max_iters=max_iters)
            results[(case, backend.name)] = stats

    return results, sanity


def main() -> int:
    parser = argparse.ArgumentParser(description="Benchmark bs4 backends vs rust bs4 bindings.")
    parser.add_argument("--html-path", required=True, help="Path to HTML file to benchmark")
    parser.add_argument(
        "--report",
        default="BENCHMARKS_BS4_REAL_HTML.md",
        help="Output markdown report path (default: BENCHMARKS_BS4_REAL_HTML.md)",
    )
    parser.add_argument("--min-seconds", type=float, default=1.2, help="Min timed seconds per case/backend")
    parser.add_argument("--warmups", type=int, default=3, help="Warmup runs per case/backend")
    parser.add_argument("--max-iters", type=int, default=300, help="Max timed iterations per case/backend")
    args = parser.parse_args()

    html_path = os.path.abspath(args.html_path)
    with open(html_path, "r", encoding="utf-8", errors="replace") as f:
        html = f.read()

    results, sanity = run(
        html=html,
        html_path=html_path,
        min_seconds=args.min_seconds,
        warmups=args.warmups,
        max_iters=args.max_iters,
    )

    report = render_report(
        html_path=html_path,
        html_size=len(html.encode("utf-8", errors="replace")),
        min_seconds=args.min_seconds,
        warmups=args.warmups,
        results=results,
        sanity=sanity,
    )

    report_path = os.path.abspath(args.report)
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(report)

    print(report)
    print(f"\nWrote report: {report_path}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
