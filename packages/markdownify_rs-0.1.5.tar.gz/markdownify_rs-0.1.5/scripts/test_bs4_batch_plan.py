#!/usr/bin/env python3
"""Parity/smoke tests for markdownify_rs QueryPlan + run_batch."""

from __future__ import annotations

import re

from bs4 import BeautifulSoup

from markdownify_rs import QueryPlan, run_batch


HTML_DOCS = [
    """
    <html><head><title>Doc A</title></head>
    <body>
      <main id="main">
        <a href="/a">A</a>
        <a href="/b">B</a>
        <p class="lead">Hello <b>world</b></p>
      </main>
    </body></html>
    """,
    """
    <html><head><title>Doc B</title></head>
    <body>
      <article>
        <a>Missing href</a>
        <p class="lead note">Second</p>
        <p>Third</p>
      </article>
    </body></html>
    """,
    """
    <html><head></head><body>
      <section>
        <h1>Header</h1>
        <p data-kind="x">Alpha</p>
        <p data-kind="y">Beta</p>
      </section>
    </body></html>
    """,
]


def build_plan() -> QueryPlan:
    plan = QueryPlan()
    plan.add_select_count("link_count", "a[href]")
    plan.add_select_exists("has_main", "main, article")
    plan.add_select_one_text("title", "title")
    plan.add_select_one_attr("main_id", "main", "id")
    plan.add_select_all_texts("all_link_texts", "a", separator=" ", strip=True)
    plan.add_select_all_attrs("hrefs", "a", "href")
    plan.add_select_all_attrs("hrefs_aligned", "a", "href", skip_missing_attrs=False)
    plan.add_select_all_inner_html("content_blocks_html", "main, article")
    plan.add_find_count("p_count", "p")
    plan.add_find_count("lead_count", "p", class_=re.compile("lead"))
    plan.add_find_one_text("first_p_text", "p", separator=" ", strip=True)
    plan.add_find_all_texts("all_p_texts", "p", separator=" ", strip=True)
    plan.add_find_all_texts(
        "matching_text_nodes",
        string=re.compile(r"^(A|B|Alpha|Beta)$"),
        include_text_nodes=True,
        strip=True,
    )
    plan.add_find_all_texts(
        "matching_text_nodes_excluded",
        string=re.compile(r"^(A|B|Alpha|Beta)$"),
        include_text_nodes=False,
        strip=True,
    )
    plan.add_find_all_texts("limited_p_texts", "p", limit=1, separator=" ", strip=True)
    plan.add_get_text("all_text", " ", True)
    return plan


def expected_row(html: str) -> dict[str, object]:
    soup = BeautifulSoup(html, "html.parser")
    selected_links = soup.select("a")
    content_blocks = soup.select("main, article")
    matching_text_nodes = soup.find_all(string=re.compile(r"^(A|B|Alpha|Beta)$"))
    return {
        "link_count": len(soup.select("a[href]")),
        "has_main": soup.select_one("main, article") is not None,
        "title": soup.select_one("title").get_text(" ", strip=True)
        if soup.select_one("title")
        else None,
        "main_id": soup.select_one("main").get("id") if soup.select_one("main") else None,
        "all_link_texts": [tag.get_text(" ", strip=True) for tag in selected_links],
        "hrefs": [tag.get("href") for tag in selected_links if tag.has_attr("href")],
        "hrefs_aligned": [tag.get("href") for tag in selected_links],
        "content_blocks_html": [tag.decode_contents() for tag in content_blocks],
        "p_count": len(soup.find_all("p")),
        "lead_count": len(soup.find_all("p", class_=re.compile("lead"))),
        "first_p_text": soup.find("p").get_text(" ", strip=True) if soup.find("p") else None,
        "all_p_texts": [tag.get_text(" ", strip=True) for tag in soup.find_all("p")],
        "matching_text_nodes": [str(node).strip() for node in matching_text_nodes],
        "matching_text_nodes_excluded": [],
        "limited_p_texts": [
            tag.get_text(" ", strip=True) for tag in soup.find_all("p", limit=1)
        ],
        "all_text": soup.get_text(" ", strip=True),
    }


def assert_equal(label: str, left, right) -> None:
    if left != right:
        raise AssertionError(f"{label} mismatch\nleft={left!r}\nright={right!r}")


def normalize_inner_html(html: str) -> str:
    return re.sub(r"\n[ \t]+", "\n", html)


def normalize_rows(rows: list[dict[str, object]]) -> list[dict[str, object]]:
    normalized: list[dict[str, object]] = []
    for row in rows:
        copy = dict(row)
        content_blocks_html = copy.get("content_blocks_html")
        if isinstance(content_blocks_html, list):
            copy["content_blocks_html"] = [
                normalize_inner_html(item) if isinstance(item, str) else item
                for item in content_blocks_html
            ]
        normalized.append(copy)
    return normalized


def main() -> None:
    plan = build_plan()

    rows_default = run_batch(HTML_DOCS, plan)
    rows_single = run_batch(HTML_DOCS, plan, workers=1)
    rows_four = run_batch(HTML_DOCS, plan, workers=4)

    assert_equal("workers parity (default vs 1)", rows_default, rows_single)
    assert_equal("workers parity (default vs 4)", rows_default, rows_four)

    expected = [expected_row(doc) for doc in HTML_DOCS]
    assert_equal("bs4 parity", normalize_rows(rows_default), normalize_rows(expected))

    # Duplicate keys are rejected to avoid silent overwrite.
    dup = QueryPlan()
    dup.add_select_count("x", "a")
    try:
        dup.add_select_exists("x", "p")
        raise AssertionError("expected duplicate key error")
    except ValueError:
        pass

    # Callable filters are intentionally unsupported in batch mode.
    bad = QueryPlan()
    try:
        bad.add_find_count("x", "a", class_=lambda _: True)
        raise AssertionError("expected callable filter error")
    except ValueError:
        pass

    print("QueryPlan batch tests passed")


if __name__ == "__main__":
    main()
