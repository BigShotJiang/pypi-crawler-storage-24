# BS4 Backend Benchmark (Real HTML)

- Timestamp: `2026-02-24T21:00:08`
- Host: `macOS-26.2-arm64-arm-64bit`
- Python: `3.12.11`
- Input HTML: `/Users/benjamin/Downloads/Illinois General Assembly - FullText Illinois Administrative Procedure Act..html`
- Input size: `441,054` bytes
- Warmups per case/backend: `4`
- Min timed duration per case/backend: `2.00` s

## Workloads

- `parse_only`: Parse HTML into a tree.
- `find_heavy`: Repeated `find/find_all` with names, attrs, regex, and string filters.
- `select_heavy`: Repeated CSS selector queries (simple + combinators + attribute selectors).
- `navigation_heavy`: Sibling/document-order traversal (`next_element`, `find_next_siblings`, etc.).
- `text_heavy`: `get_text` and string-node scans.
- `end_to_end`: Parse + full mixed query suite.

## Sanity Check Outputs

These values confirm each backend ran the same workload shape (parser differences can cause minor count differences).

| Backend | a_tags | p_tags | div_tags | text_nodes | text_len_strip | selector_hits | suite_score |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bs4_html_parser | 154 | 147 | 401 | 4477 | 170268 | 347 | 365356 |
| bs4_lxml | 154 | 147 | 401 | 4475 | 170268 | 347 | 365386 |
| rust_bs4 | 154 | 147 | 401 | 4435 | 177357 | 347 | 378813 |

## Per-Case Results

### `parse_only`

| Backend | Median (ms) | Mean (ms) | p95 (ms) | Min (ms) | Max (ms) | Iterations | Speedup vs `bs4_html_parser` |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bs4_html_parser | 55.129 | 55.333 | 57.123 | 53.960 | 57.809 | 37 | 1.00x |
| bs4_lxml | 29.409 | 29.443 | 30.345 | 28.568 | 30.517 | 68 | 1.87x |
| rust_bs4 | 4.816 | 4.812 | 4.912 | 4.616 | 4.952 | 400 | 11.45x |

### `find_heavy`

| Backend | Median (ms) | Mean (ms) | p95 (ms) | Min (ms) | Max (ms) | Iterations | Speedup vs `bs4_html_parser` |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bs4_html_parser | 18.270 | 18.298 | 18.844 | 17.745 | 18.928 | 110 | 1.00x |
| bs4_lxml | 18.019 | 18.291 | 18.987 | 17.598 | 19.016 | 110 | 1.01x |
| rust_bs4 | 1.780 | 1.779 | 1.822 | 1.702 | 1.852 | 400 | 10.26x |

### `select_heavy`

| Backend | Median (ms) | Mean (ms) | p95 (ms) | Min (ms) | Max (ms) | Iterations | Speedup vs `bs4_html_parser` |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bs4_html_parser | 179.067 | 180.958 | 185.999 | 178.125 | 188.054 | 12 | 1.00x |
| bs4_lxml | 182.977 | 184.124 | 188.773 | 180.725 | 189.940 | 11 | 0.98x |
| rust_bs4 | 2.245 | 2.249 | 2.296 | 2.116 | 2.394 | 400 | 79.75x |

### `navigation_heavy`

| Backend | Median (ms) | Mean (ms) | p95 (ms) | Min (ms) | Max (ms) | Iterations | Speedup vs `bs4_html_parser` |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bs4_html_parser | 0.582 | 0.580 | 0.606 | 0.544 | 0.635 | 400 | 1.00x |
| bs4_lxml | 0.620 | 0.619 | 0.635 | 0.565 | 0.672 | 400 | 0.94x |
| rust_bs4 | 0.636 | 0.634 | 0.656 | 0.605 | 0.689 | 400 | 0.91x |

### `text_heavy`

| Backend | Median (ms) | Mean (ms) | p95 (ms) | Min (ms) | Max (ms) | Iterations | Speedup vs `bs4_html_parser` |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bs4_html_parser | 3.219 | 3.233 | 3.361 | 3.056 | 3.391 | 400 | 1.00x |
| bs4_lxml | 3.327 | 3.323 | 3.404 | 3.086 | 3.553 | 400 | 0.97x |
| rust_bs4 | 0.484 | 0.488 | 0.512 | 0.474 | 0.549 | 400 | 6.65x |

### `end_to_end`

| Backend | Median (ms) | Mean (ms) | p95 (ms) | Min (ms) | Max (ms) | Iterations | Speedup vs `bs4_html_parser` |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| bs4_html_parser | 260.357 | 260.955 | 264.942 | 256.964 | 265.726 | 8 | 1.00x |
| bs4_lxml | 242.374 | 242.200 | 245.637 | 238.608 | 246.339 | 9 | 1.07x |
| rust_bs4 | 10.072 | 10.010 | 10.314 | 9.684 | 10.388 | 200 | 25.85x |

## Overall Speedup (Geometric Mean Of Medians)

Computed across all workloads above.

| Backend | Relative to `bs4_html_parser` |
| --- | ---: |
| bs4_html_parser | 1.00x |
| bs4_lxml | 1.10x |
| rust_bs4 | 10.67x |

## Direct Relative Comparisons

- rust_bs4 vs bs4_html_parser (geo mean): `10.67x` faster
- bs4_lxml vs bs4_html_parser (geo mean): `1.10x` faster
- rust_bs4 vs bs4_lxml (geo mean): `9.66x` faster
