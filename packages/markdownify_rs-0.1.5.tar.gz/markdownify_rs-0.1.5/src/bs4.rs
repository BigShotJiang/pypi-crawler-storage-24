use std::collections::HashMap;
use std::fmt;
use std::sync::Arc;

use ego_tree::{NodeId, NodeRef};
use regex::Regex;
use scraper::node::Node;
use scraper::{ElementRef, Html, Selector};

/// Read-only HTML tree wrapper with a BeautifulSoup-like API.
pub struct Soup {
    html: Html,
    visible_doc_order: Vec<NodeId>,
    visible_doc_positions: HashMap<NodeId, usize>,
}

#[derive(Clone, Copy)]
pub struct Tag<'a> {
    soup: &'a Soup,
    id: NodeId,
}

#[derive(Clone, Copy)]
pub struct NavigableString<'a> {
    soup: &'a Soup,
    id: NodeId,
}

#[derive(Clone, Copy)]
pub enum Element<'a> {
    Tag(Tag<'a>),
    String(NavigableString<'a>),
}

#[derive(Clone)]
pub enum Matchable {
    Exact(String),
    ExactList(Vec<String>),
    Regex(Regex),
    Bool(bool),
    Predicate(Arc<dyn Fn(&str) -> bool>),
}

#[derive(Clone)]
pub struct Filter {
    pub name: Option<Matchable>,
    pub attrs: HashMap<String, Vec<Matchable>>,
    pub string: Option<Matchable>,
    pub limit: Option<usize>,
    pub recursive: bool,
}

impl Default for Filter {
    fn default() -> Self {
        Self {
            name: None,
            attrs: HashMap::new(),
            string: None,
            limit: None,
            recursive: true,
        }
    }
}

impl Matchable {
    pub fn matches(&self, value: Option<&str>) -> bool {
        match self {
            Self::Exact(expected) => value.map(|v| v == expected).unwrap_or(false),
            Self::ExactList(expected) => value
                .map(|v| expected.iter().any(|candidate| candidate == v))
                .unwrap_or(false),
            Self::Regex(pattern) => value.map(|v| pattern.is_match(v)).unwrap_or(false),
            Self::Bool(expected) => {
                if *expected {
                    value.is_some()
                } else {
                    value.is_none()
                }
            }
            Self::Predicate(predicate) => value.map(|v| predicate(v)).unwrap_or(false),
        }
    }
}

impl From<&str> for Matchable {
    fn from(value: &str) -> Self {
        Self::Exact(value.to_string())
    }
}

impl From<String> for Matchable {
    fn from(value: String) -> Self {
        Self::Exact(value)
    }
}

impl From<Vec<String>> for Matchable {
    fn from(values: Vec<String>) -> Self {
        Self::ExactList(values)
    }
}

impl From<Vec<&str>> for Matchable {
    fn from(values: Vec<&str>) -> Self {
        Self::ExactList(values.into_iter().map(ToString::to_string).collect())
    }
}

impl From<Regex> for Matchable {
    fn from(value: Regex) -> Self {
        Self::Regex(value)
    }
}

impl From<bool> for Matchable {
    fn from(value: bool) -> Self {
        Self::Bool(value)
    }
}

impl<F> From<F> for Matchable
where
    F: Fn(&str) -> bool + 'static,
{
    fn from(value: F) -> Self {
        Self::Predicate(Arc::new(value))
    }
}

impl Filter {
    pub fn new() -> Self {
        Self::default()
    }

    pub fn name<M: Into<Matchable>>(mut self, matcher: M) -> Self {
        self.name = Some(matcher.into());
        self
    }

    pub fn attr<M: Into<Matchable>>(mut self, attr: &str, matcher: M) -> Self {
        let attr = normalize_attr_name(attr);
        self.attrs.entry(attr).or_default().push(matcher.into());
        self
    }

    pub fn string<M: Into<Matchable>>(mut self, matcher: M) -> Self {
        self.string = Some(matcher.into());
        self
    }

    pub fn limit(mut self, limit: usize) -> Self {
        // bs4 semantics: limit=0 means "no limit".
        self.limit = if limit == 0 { None } else { Some(limit) };
        self
    }

    pub fn recursive(mut self, recursive: bool) -> Self {
        self.recursive = recursive;
        self
    }

    fn matches_tag<'a>(&self, tag: Tag<'a>) -> bool {
        if self.is_string_only_query() {
            return false;
        }

        if let Some(name_matcher) = &self.name {
            if !matches_name(name_matcher, tag.name()) {
                return false;
            }
        }

        for (attr, matchers) in &self.attrs {
            let raw_value = tag.get(attr);
            if !matches_attr_matchers(attr, raw_value, matchers) {
                return false;
            }
        }

        if let Some(string_matcher) = &self.string {
            if !string_matcher.matches(tag.string()) {
                return false;
            }
        }

        true
    }

    fn matches_string_node(&self, text: &str) -> bool {
        if !self.is_string_only_query() {
            return false;
        }
        match &self.string {
            Some(matcher) => matcher.matches(Some(text)),
            None => false,
        }
    }

    fn is_string_only_query(&self) -> bool {
        self.name.is_none() && self.attrs.is_empty() && self.string.is_some()
    }
}

impl From<&str> for Filter {
    fn from(value: &str) -> Self {
        Self::new().name(value)
    }
}

impl From<String> for Filter {
    fn from(value: String) -> Self {
        Self::new().name(value)
    }
}

impl From<Regex> for Filter {
    fn from(value: Regex) -> Self {
        Self::new().name(value)
    }
}

impl From<Matchable> for Filter {
    fn from(value: Matchable) -> Self {
        Self::new().name(value)
    }
}

impl From<Vec<&str>> for Filter {
    fn from(values: Vec<&str>) -> Self {
        Self::new().name(values)
    }
}

impl From<Vec<String>> for Filter {
    fn from(values: Vec<String>) -> Self {
        Self::new().name(values)
    }
}

impl Soup {
    pub fn new(html: &str) -> Self {
        let html = Html::parse_fragment(html);
        let (visible_doc_order, visible_doc_positions) = build_visible_doc_order(&html);
        Self {
            html,
            visible_doc_order,
            visible_doc_positions,
        }
    }

    pub fn root(&self) -> Tag<'_> {
        Tag::new(self, self.html.tree.root().id())
    }

    pub fn find(&self, filter: impl Into<Filter>) -> Option<Tag<'_>> {
        self.root().find(filter)
    }

    pub fn find_all(&self, filter: impl Into<Filter>) -> Vec<Tag<'_>> {
        self.root().find_all(filter)
    }

    pub fn select(&self, css: &str) -> Vec<Tag<'_>> {
        let mut primary = self.select_with_css(css).unwrap_or_default();

        // `scraper` fragment parsing can diverge from bs4 around `body` selectors.
        // Retry by mapping `body` tag tokens to `html`, and keep whichever
        // result set is larger.
        if css.contains("body") {
            if let Some(fallback_css) = rewrite_body_selector_tokens(css) {
                if let Some(fallback) = self.select_with_css(&fallback_css) {
                    if fallback.len() > primary.len() {
                        primary = fallback;
                    }
                }
            }
        }

        primary
    }

    pub fn select_one(&self, css: &str) -> Option<Tag<'_>> {
        self.select(css).into_iter().next()
    }

    pub fn get_text(&self, separator: &str, strip: bool) -> String {
        self.root().get_text(separator, strip)
    }

    pub(crate) fn node_by_id(&self, id: NodeId) -> Option<NodeRef<'_, Node>> {
        self.html.tree.get(id)
    }

    fn visible_doc_position(&self, id: NodeId) -> Option<usize> {
        self.visible_doc_positions.get(&id).copied()
    }

    fn element_at_visible_doc_index(&self, index: usize) -> Option<Element<'_>> {
        let id = *self.visible_doc_order.get(index)?;
        let node = self.node_by_id(id)?;
        element_from_node(self, node)
    }

    fn next_visible_element(&self, id: NodeId) -> Option<Element<'_>> {
        let position = self.visible_doc_position(id)?;
        self.element_at_visible_doc_index(position + 1)
    }

    fn previous_visible_element(&self, id: NodeId) -> Option<Element<'_>> {
        let position = self.visible_doc_position(id)?;
        let previous = position.checked_sub(1)?;
        self.element_at_visible_doc_index(previous)
    }

    fn collect_next_visible_elements(&self, id: NodeId) -> Option<Vec<Element<'_>>> {
        let start = self.visible_doc_position(id)? + 1;
        let mut out = Vec::with_capacity(self.visible_doc_order.len().saturating_sub(start));
        for next_id in self.visible_doc_order.iter().skip(start).copied() {
            let Some(node) = self.node_by_id(next_id) else {
                continue;
            };
            if let Some(element) = element_from_node(self, node) {
                out.push(element);
            }
        }
        Some(out)
    }

    fn collect_previous_visible_elements(&self, id: NodeId) -> Option<Vec<Element<'_>>> {
        let start = self.visible_doc_position(id)?;
        let mut out = Vec::with_capacity(start);
        for previous_id in self.visible_doc_order.iter().take(start).rev().copied() {
            let Some(node) = self.node_by_id(previous_id) else {
                continue;
            };
            if let Some(element) = element_from_node(self, node) {
                out.push(element);
            }
        }
        Some(out)
    }

    fn collect_matching_next_tags(&self, id: NodeId, filter: &Filter) -> Option<Vec<Tag<'_>>> {
        let start = self.visible_doc_position(id)? + 1;
        let mut out = Vec::new();
        for next_id in self.visible_doc_order.iter().skip(start).copied() {
            let Some(node) = self.node_by_id(next_id) else {
                continue;
            };
            if !matches!(node.value(), Node::Element(_)) {
                continue;
            }
            let candidate = Tag::new(self, next_id);
            if filter.matches_tag(candidate) {
                out.push(candidate);
                if filter
                    .limit
                    .map(|limit| out.len() >= limit)
                    .unwrap_or(false)
                {
                    break;
                }
            }
        }
        Some(out)
    }

    fn collect_matching_previous_tags(&self, id: NodeId, filter: &Filter) -> Option<Vec<Tag<'_>>> {
        let start = self.visible_doc_position(id)?;
        let mut out = Vec::new();
        for previous_id in self.visible_doc_order.iter().take(start).rev().copied() {
            let Some(node) = self.node_by_id(previous_id) else {
                continue;
            };
            if !matches!(node.value(), Node::Element(_)) {
                continue;
            }
            let candidate = Tag::new(self, previous_id);
            if filter.matches_tag(candidate) {
                out.push(candidate);
                if filter
                    .limit
                    .map(|limit| out.len() >= limit)
                    .unwrap_or(false)
                {
                    break;
                }
            }
        }
        Some(out)
    }

    fn select_with_css(&self, css: &str) -> Option<Vec<Tag<'_>>> {
        let selector = Selector::parse(css).ok()?;
        Some(
            self.html
                .select(&selector)
                .map(|element| Tag::new(self, element.id()))
                .collect(),
        )
    }

    #[cfg(feature = "python")]
    pub(crate) fn tag_by_id(&self, id: NodeId) -> Option<Tag<'_>> {
        let node = self.node_by_id(id)?;
        if is_tag_like_node(node) {
            Some(Tag::new(self, id))
        } else {
            None
        }
    }

    #[cfg(feature = "python")]
    pub(crate) fn string_by_id(&self, id: NodeId) -> Option<NavigableString<'_>> {
        let node = self.node_by_id(id)?;
        if matches!(node.value(), Node::Text(_)) {
            Some(NavigableString::new(self, id))
        } else {
            None
        }
    }
}

impl<'a> Tag<'a> {
    fn new(soup: &'a Soup, id: NodeId) -> Self {
        Self { soup, id }
    }

    pub fn node_id(&self) -> NodeId {
        self.id
    }

    fn node(&self) -> NodeRef<'a, Node> {
        self.soup
            .node_by_id(self.id)
            .expect("tag points to a stale node id")
    }

    fn element_ref(&self) -> Option<ElementRef<'a>> {
        ElementRef::wrap(self.node())
    }

    fn for_each_candidate_node(
        &self,
        recursive: bool,
        mut visit: impl FnMut(NodeRef<'a, Node>) -> bool,
    ) {
        if self.name() == "[document]" {
            if let Some(html_node) = synthetic_html_container(self.node()) {
                if recursive {
                    for node in html_node.descendants().skip(1) {
                        if !visit(node) {
                            return;
                        }
                    }
                } else {
                    for node in html_node.children() {
                        if !visit(node) {
                            return;
                        }
                    }
                }
                return;
            }
        }

        if recursive {
            for node in self.node().descendants().skip(1) {
                if !visit(node) {
                    return;
                }
            }
        } else {
            for node in self.node().children() {
                if !visit(node) {
                    return;
                }
            }
        }
    }

    pub fn name(&self) -> &'a str {
        match self.node().value() {
            Node::Element(element) => element.name(),
            Node::Document | Node::Fragment => "[document]",
            _ => "[unknown]",
        }
    }

    pub fn attrs(&self) -> Vec<(String, String)> {
        self.node()
            .value()
            .as_element()
            .map(|element| {
                element
                    .attrs()
                    .map(|(name, value)| (name.to_string(), value.to_string()))
                    .collect()
            })
            .unwrap_or_default()
    }

    pub fn get(&self, attr: &str) -> Option<&'a str> {
        let attr = normalize_attr_name(attr);
        self.node()
            .value()
            .as_element()
            .and_then(|el| el.attr(&attr))
    }

    pub fn has_attr(&self, attr: &str) -> bool {
        self.get(attr).is_some()
    }

    pub fn id(&self) -> Option<&'a str> {
        self.get("id")
    }

    pub fn classes(&self) -> Vec<&'a str> {
        match self.get("class") {
            Some(raw) => raw.split_whitespace().collect(),
            None => Vec::new(),
        }
    }

    pub fn find(&self, filter: impl Into<Filter>) -> Option<Tag<'a>> {
        self.find_all(filter).into_iter().next()
    }

    pub fn find_all(&self, filter: impl Into<Filter>) -> Vec<Tag<'a>> {
        let filter: Filter = filter.into();
        if filter.limit == Some(0) {
            return Vec::new();
        }

        let mut out = Vec::new();
        self.for_each_candidate_node(filter.recursive, |node| {
            if !matches!(node.value(), Node::Element(_)) {
                return true;
            }
            let candidate = Tag::new(self.soup, node.id());
            if filter.matches_tag(candidate) {
                out.push(candidate);
            }
            !filter
                .limit
                .map(|limit| out.len() >= limit)
                .unwrap_or(false)
        });
        out
    }

    pub fn find_with_string(&self, filter: impl Into<Filter>) -> Option<Element<'a>> {
        self.find_all_with_string(filter).into_iter().next()
    }

    pub fn find_all_with_string(&self, filter: impl Into<Filter>) -> Vec<Element<'a>> {
        let filter: Filter = filter.into();
        if filter.limit == Some(0) {
            return Vec::new();
        }

        let mut out = Vec::new();
        self.for_each_candidate_node(filter.recursive, |node| {
            match node.value() {
                Node::Element(_) => {
                    let candidate = Tag::new(self.soup, node.id());
                    if filter.matches_tag(candidate) {
                        out.push(Element::Tag(candidate));
                    }
                }
                Node::Text(text) => {
                    if filter.matches_string_node(text.text.as_ref()) {
                        out.push(Element::String(NavigableString::new(self.soup, node.id())));
                    }
                }
                _ => {}
            }
            !filter
                .limit
                .map(|limit| out.len() >= limit)
                .unwrap_or(false)
        });
        out
    }

    pub fn find_parent(&self, filter: impl Into<Filter>) -> Option<Tag<'a>> {
        self.find_parents(filter).into_iter().next()
    }

    pub fn find_parents(&self, filter: impl Into<Filter>) -> Vec<Tag<'a>> {
        let filter: Filter = filter.into();
        if filter.limit == Some(0) {
            return Vec::new();
        }

        let mut out = Vec::new();
        let mut current = self.node().parent();

        while let Some(parent) = current {
            if matches!(parent.value(), Node::Element(_)) {
                let parent_tag = Tag::new(self.soup, parent.id());
                if filter.matches_tag(parent_tag) {
                    out.push(parent_tag);
                    if filter
                        .limit
                        .map(|limit| out.len() >= limit)
                        .unwrap_or(false)
                    {
                        break;
                    }
                }
            }
            current = parent.parent();
        }

        out
    }

    pub fn find_next_sibling(&self, filter: impl Into<Filter>) -> Option<Tag<'a>> {
        self.find_next_siblings(filter).into_iter().next()
    }

    pub fn find_next_siblings(&self, filter: impl Into<Filter>) -> Vec<Tag<'a>> {
        let filter: Filter = filter.into();
        if filter.limit == Some(0) {
            return Vec::new();
        }

        let mut out = Vec::new();
        let mut current = self.node().next_sibling();

        while let Some(sibling) = current {
            if matches!(sibling.value(), Node::Element(_)) {
                let sibling_tag = Tag::new(self.soup, sibling.id());
                if filter.matches_tag(sibling_tag) {
                    out.push(sibling_tag);
                    if filter
                        .limit
                        .map(|limit| out.len() >= limit)
                        .unwrap_or(false)
                    {
                        break;
                    }
                }
            }
            current = sibling.next_sibling();
        }

        out
    }

    pub fn find_previous_sibling(&self, filter: impl Into<Filter>) -> Option<Tag<'a>> {
        self.find_previous_siblings(filter).into_iter().next()
    }

    pub fn find_previous_siblings(&self, filter: impl Into<Filter>) -> Vec<Tag<'a>> {
        let filter: Filter = filter.into();
        if filter.limit == Some(0) {
            return Vec::new();
        }

        let mut out = Vec::new();
        let mut current = self.node().prev_sibling();

        while let Some(sibling) = current {
            if matches!(sibling.value(), Node::Element(_)) {
                let sibling_tag = Tag::new(self.soup, sibling.id());
                if filter.matches_tag(sibling_tag) {
                    out.push(sibling_tag);
                    if filter
                        .limit
                        .map(|limit| out.len() >= limit)
                        .unwrap_or(false)
                    {
                        break;
                    }
                }
            }
            current = sibling.prev_sibling();
        }

        out
    }

    pub fn find_next(&self, filter: impl Into<Filter>) -> Option<Tag<'a>> {
        self.find_all_next(filter).into_iter().next()
    }

    pub fn find_all_next(&self, filter: impl Into<Filter>) -> Vec<Tag<'a>> {
        let filter: Filter = filter.into();
        if filter.limit == Some(0) {
            return Vec::new();
        }

        if let Some(out) = self.soup.collect_matching_next_tags(self.id, &filter) {
            return out;
        }

        let mut out = Vec::new();
        let mut current = next_node_in_document(self.node());

        while let Some(node) = current {
            if matches!(node.value(), Node::Element(_)) {
                let candidate = Tag::new(self.soup, node.id());
                if filter.matches_tag(candidate) {
                    out.push(candidate);
                    if filter
                        .limit
                        .map(|limit| out.len() >= limit)
                        .unwrap_or(false)
                    {
                        break;
                    }
                }
            }
            current = next_node_in_document(node);
        }

        out
    }

    pub fn find_previous(&self, filter: impl Into<Filter>) -> Option<Tag<'a>> {
        self.find_all_previous(filter).into_iter().next()
    }

    pub fn find_all_previous(&self, filter: impl Into<Filter>) -> Vec<Tag<'a>> {
        let filter: Filter = filter.into();
        if filter.limit == Some(0) {
            return Vec::new();
        }

        if let Some(out) = self.soup.collect_matching_previous_tags(self.id, &filter) {
            return out;
        }

        let mut out = Vec::new();
        let mut current = previous_node_in_document(self.node());

        while let Some(node) = current {
            if matches!(node.value(), Node::Element(_)) {
                let candidate = Tag::new(self.soup, node.id());
                if filter.matches_tag(candidate) {
                    out.push(candidate);
                    if filter
                        .limit
                        .map(|limit| out.len() >= limit)
                        .unwrap_or(false)
                    {
                        break;
                    }
                }
            }
            current = previous_node_in_document(node);
        }

        out
    }

    pub fn select(&self, css: &str) -> Vec<Tag<'a>> {
        let selector = match Selector::parse(css) {
            Ok(selector) => selector,
            Err(_) => return Vec::new(),
        };

        match self.element_ref() {
            Some(element) => element
                .select(&selector)
                .map(|matched| Tag::new(self.soup, matched.id()))
                .collect(),
            None => self.soup.select(css),
        }
    }

    pub fn select_one(&self, css: &str) -> Option<Tag<'a>> {
        self.select(css).into_iter().next()
    }

    pub fn parent(&self) -> Option<Tag<'a>> {
        self.node()
            .parent()
            .and_then(|parent| tag_from_node(self.soup, parent))
    }

    pub fn parents(&self) -> std::vec::IntoIter<Tag<'a>> {
        let mut out = Vec::new();
        let mut current = self.node().parent();
        while let Some(parent) = current {
            if let Some(tag) = tag_from_node(self.soup, parent) {
                out.push(tag);
            }
            current = parent.parent();
        }
        out.into_iter()
    }

    pub fn children(&self) -> std::vec::IntoIter<Element<'a>> {
        self.contents().into_iter()
    }

    pub fn children_tags(&self) -> std::vec::IntoIter<Tag<'a>> {
        self.node()
            .children()
            .filter_map(|node| {
                if matches!(node.value(), Node::Element(_)) {
                    Some(Tag::new(self.soup, node.id()))
                } else {
                    None
                }
            })
            .collect::<Vec<_>>()
            .into_iter()
    }

    pub fn contents(&self) -> Vec<Element<'a>> {
        self.node()
            .children()
            .filter_map(|node| element_from_node(self.soup, node))
            .collect()
    }

    pub fn descendants(&self) -> std::vec::IntoIter<Element<'a>> {
        self.node()
            .descendants()
            .skip(1)
            .filter_map(|node| element_from_node(self.soup, node))
            .collect::<Vec<_>>()
            .into_iter()
    }

    pub fn next_sibling(&self) -> Option<Element<'a>> {
        sibling_element(self.soup, self.node().next_sibling(), Direction::Next)
    }

    pub fn previous_sibling(&self) -> Option<Element<'a>> {
        sibling_element(self.soup, self.node().prev_sibling(), Direction::Previous)
    }

    pub fn next_siblings(&self) -> std::vec::IntoIter<Element<'a>> {
        sibling_elements(self.soup, self.node().next_sibling(), Direction::Next).into_iter()
    }

    pub fn previous_siblings(&self) -> std::vec::IntoIter<Element<'a>> {
        sibling_elements(self.soup, self.node().prev_sibling(), Direction::Previous).into_iter()
    }

    pub fn next_element(&self) -> Option<Element<'a>> {
        if let Some(next) = self.soup.next_visible_element(self.id) {
            return Some(next);
        }

        let mut current = next_node_in_document(self.node());
        while let Some(node) = current {
            if let Some(element) = element_from_node(self.soup, node) {
                return Some(element);
            }
            current = next_node_in_document(node);
        }
        None
    }

    pub fn previous_element(&self) -> Option<Element<'a>> {
        if let Some(previous) = self.soup.previous_visible_element(self.id) {
            return Some(previous);
        }

        let mut current = previous_node_in_document(self.node());
        while let Some(node) = current {
            if let Some(element) = element_from_node(self.soup, node) {
                return Some(element);
            }
            current = previous_node_in_document(node);
        }
        None
    }

    pub fn next_elements(&self) -> std::vec::IntoIter<Element<'a>> {
        if let Some(out) = self.soup.collect_next_visible_elements(self.id) {
            return out.into_iter();
        }

        let mut out = Vec::new();
        let mut current = next_node_in_document(self.node());
        while let Some(node) = current {
            if let Some(element) = element_from_node(self.soup, node) {
                out.push(element);
            }
            current = next_node_in_document(node);
        }
        out.into_iter()
    }

    pub fn previous_elements(&self) -> std::vec::IntoIter<Element<'a>> {
        if let Some(out) = self.soup.collect_previous_visible_elements(self.id) {
            return out.into_iter();
        }

        let mut out = Vec::new();
        let mut current = previous_node_in_document(self.node());
        while let Some(node) = current {
            if let Some(element) = element_from_node(self.soup, node) {
                out.push(element);
            }
            current = previous_node_in_document(node);
        }
        out.into_iter()
    }

    pub fn string(&self) -> Option<&'a str> {
        single_string_descendant(self.node())
    }

    pub fn strings(&self) -> std::vec::IntoIter<&'a str> {
        self.node()
            .descendants()
            .skip(1)
            .filter_map(|node| match node.value() {
                Node::Text(text) => Some(text.text.as_ref()),
                _ => None,
            })
            .collect::<Vec<_>>()
            .into_iter()
    }

    pub fn stripped_strings(&self) -> std::vec::IntoIter<&'a str> {
        self.strings()
            .filter_map(|text| {
                let trimmed = text.trim();
                if trimmed.is_empty() {
                    None
                } else {
                    Some(trimmed)
                }
            })
            .collect::<Vec<_>>()
            .into_iter()
    }

    pub fn get_text(&self, separator: &str, strip: bool) -> String {
        let mut out = Vec::new();
        for text in self.strings() {
            if strip {
                let trimmed = text.trim();
                if !trimmed.is_empty() {
                    out.push(trimmed);
                }
            } else {
                out.push(normalize_bs4_whitespace_text(text));
            }
        }
        out.join(separator)
    }

    pub fn inner_html(&self) -> String {
        match self.element_ref() {
            Some(element) => element.inner_html(),
            None => self
                .node()
                .children()
                .map(node_outer_html)
                .collect::<Vec<_>>()
                .join(""),
        }
    }

    pub fn outer_html(&self) -> String {
        node_outer_html(self.node())
    }

    pub fn prettify(&self) -> String {
        let mut out = String::new();
        prettify_node(self.node(), 0, &mut out);
        out.trim_end().to_string()
    }
}

impl<'a> NavigableString<'a> {
    fn new(soup: &'a Soup, id: NodeId) -> Self {
        Self { soup, id }
    }

    pub fn node_id(&self) -> NodeId {
        self.id
    }

    fn node(&self) -> NodeRef<'a, Node> {
        self.soup
            .node_by_id(self.id)
            .expect("string points to a stale node id")
    }

    pub fn text(&self) -> &'a str {
        match self.node().value() {
            Node::Text(text) => text.text.as_ref(),
            _ => "",
        }
    }

    pub fn parent(&self) -> Option<Tag<'a>> {
        self.node()
            .parent()
            .and_then(|parent| tag_from_node(self.soup, parent))
    }

    pub fn next_sibling(&self) -> Option<Element<'a>> {
        sibling_element(self.soup, self.node().next_sibling(), Direction::Next)
    }

    pub fn previous_sibling(&self) -> Option<Element<'a>> {
        sibling_element(self.soup, self.node().prev_sibling(), Direction::Previous)
    }

    pub fn next_element(&self) -> Option<Element<'a>> {
        if let Some(next) = self.soup.next_visible_element(self.id) {
            return Some(next);
        }

        let mut current = next_node_in_document(self.node());
        while let Some(node) = current {
            if let Some(element) = element_from_node(self.soup, node) {
                return Some(element);
            }
            current = next_node_in_document(node);
        }
        None
    }

    pub fn previous_element(&self) -> Option<Element<'a>> {
        if let Some(previous) = self.soup.previous_visible_element(self.id) {
            return Some(previous);
        }

        let mut current = previous_node_in_document(self.node());
        while let Some(node) = current {
            if let Some(element) = element_from_node(self.soup, node) {
                return Some(element);
            }
            current = previous_node_in_document(node);
        }
        None
    }
}

impl<'a> Element<'a> {
    pub fn as_tag(&self) -> Option<Tag<'a>> {
        match self {
            Self::Tag(tag) => Some(*tag),
            Self::String(_) => None,
        }
    }

    pub fn as_string(&self) -> Option<NavigableString<'a>> {
        match self {
            Self::Tag(_) => None,
            Self::String(string) => Some(*string),
        }
    }
}

impl fmt::Debug for Tag<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("Tag").field("name", &self.name()).finish()
    }
}

impl fmt::Debug for NavigableString<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("NavigableString")
            .field("text", &self.text())
            .finish()
    }
}

impl fmt::Debug for Element<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::Tag(tag) => tag.fmt(f),
            Self::String(string) => string.fmt(f),
        }
    }
}

impl fmt::Display for Tag<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(&self.outer_html())
    }
}

impl fmt::Display for NavigableString<'_> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.write_str(self.text())
    }
}

fn normalize_attr_name(attr: &str) -> String {
    let lowered = attr.trim().to_ascii_lowercase();
    if lowered.ends_with('_') {
        lowered.trim_end_matches('_').to_string()
    } else {
        lowered
    }
}

fn matches_name(matcher: &Matchable, value: &str) -> bool {
    match matcher {
        Matchable::Exact(expected) => value.eq_ignore_ascii_case(expected),
        Matchable::ExactList(expected) => expected
            .iter()
            .any(|candidate| value.eq_ignore_ascii_case(candidate)),
        Matchable::Regex(pattern) => pattern.is_match(value),
        Matchable::Bool(expected) => *expected,
        Matchable::Predicate(predicate) => predicate(value),
    }
}

fn matches_attr_matchers(attr: &str, value: Option<&str>, matchers: &[Matchable]) -> bool {
    if matchers.is_empty() {
        return true;
    }
    matchers
        .iter()
        .any(|matcher| matches_single_attr_matcher(attr, value, matcher))
}

fn matches_single_attr_matcher(attr: &str, value: Option<&str>, matcher: &Matchable) -> bool {
    if let Matchable::Bool(expected) = matcher {
        return if *expected {
            value.is_some()
        } else {
            value.is_none()
        };
    }

    let Some(raw) = value else {
        return false;
    };

    if matcher.matches(Some(raw)) {
        return true;
    }

    if is_multi_valued_attr(attr) {
        return raw
            .split_whitespace()
            .any(|candidate| matcher.matches(Some(candidate)));
    }

    false
}

fn is_multi_valued_attr(attr: &str) -> bool {
    matches!(
        attr,
        "class" | "rel" | "rev" | "headers" | "accept-charset" | "accesskey"
    )
}

fn is_tag_like_node(node: NodeRef<'_, Node>) -> bool {
    matches!(
        node.value(),
        Node::Element(_) | Node::Document | Node::Fragment
    )
}

fn tag_from_node<'a>(soup: &'a Soup, node: NodeRef<'a, Node>) -> Option<Tag<'a>> {
    if is_tag_like_node(node) {
        Some(Tag::new(soup, node.id()))
    } else {
        None
    }
}

fn element_from_node<'a>(soup: &'a Soup, node: NodeRef<'a, Node>) -> Option<Element<'a>> {
    match node.value() {
        Node::Element(_) => Some(Element::Tag(Tag::new(soup, node.id()))),
        Node::Text(_) => Some(Element::String(NavigableString::new(soup, node.id()))),
        _ => None,
    }
}

enum Direction {
    Next,
    Previous,
}

fn sibling_element<'a>(
    soup: &'a Soup,
    current: Option<NodeRef<'a, Node>>,
    direction: Direction,
) -> Option<Element<'a>> {
    let mut node = current;
    while let Some(candidate) = node {
        if let Some(element) = element_from_node(soup, candidate) {
            return Some(element);
        }
        node = match direction {
            Direction::Next => candidate.next_sibling(),
            Direction::Previous => candidate.prev_sibling(),
        };
    }
    None
}

fn sibling_elements<'a>(
    soup: &'a Soup,
    current: Option<NodeRef<'a, Node>>,
    direction: Direction,
) -> Vec<Element<'a>> {
    let mut out = Vec::new();
    let mut node = current;
    while let Some(candidate) = node {
        if let Some(element) = element_from_node(soup, candidate) {
            out.push(element);
        }
        node = match direction {
            Direction::Next => candidate.next_sibling(),
            Direction::Previous => candidate.prev_sibling(),
        };
    }
    out
}

fn next_node_in_document(node: NodeRef<'_, Node>) -> Option<NodeRef<'_, Node>> {
    if let Some(first_child) = node.first_child() {
        return Some(first_child);
    }

    let mut current = node;
    loop {
        if let Some(next_sibling) = current.next_sibling() {
            return Some(next_sibling);
        }
        current = current.parent()?;
    }
}

fn previous_node_in_document(node: NodeRef<'_, Node>) -> Option<NodeRef<'_, Node>> {
    if let Some(previous_sibling) = node.prev_sibling() {
        let mut current = previous_sibling;
        while let Some(last_child) = current.last_child() {
            current = last_child;
        }
        return Some(current);
    }

    node.parent()
}

fn single_string_descendant<'a>(node: NodeRef<'a, Node>) -> Option<&'a str> {
    let mut current = node;

    loop {
        let mut children = current.children().filter(|child| match child.value() {
            Node::Element(_) => true,
            Node::Text(_) => true,
            _ => false,
        });

        let first = children.next()?;
        if children.next().is_some() {
            return None;
        }

        match first.value() {
            Node::Text(text) => return Some(text.text.as_ref()),
            Node::Element(_) => current = first,
            _ => return None,
        }
    }
}

fn node_outer_html(node: NodeRef<'_, Node>) -> String {
    match node.value() {
        Node::Element(_) => ElementRef::wrap(node)
            .map(|element| element.html())
            .unwrap_or_default(),
        Node::Text(text) => text.text.to_string(),
        Node::Comment(comment) => {
            let comment_text: &str = comment;
            format!("<!--{}-->", comment_text)
        }
        Node::Document | Node::Fragment => node
            .children()
            .map(node_outer_html)
            .collect::<Vec<_>>()
            .join(""),
        _ => String::new(),
    }
}

fn prettify_node(node: NodeRef<'_, Node>, depth: usize, out: &mut String) {
    match node.value() {
        Node::Document | Node::Fragment => {
            for child in node.children() {
                prettify_node(child, depth, out);
            }
        }
        Node::Element(element) => {
            let indent = "  ".repeat(depth);
            out.push_str(&indent);
            out.push('<');
            out.push_str(element.name());
            for (name, value) in element.attrs() {
                out.push(' ');
                out.push_str(name);
                out.push_str("=\"");
                out.push_str(value);
                out.push('"');
            }
            out.push('>');

            let mut child_count = 0usize;
            for child in node.children() {
                if should_skip_pretty_child(child) {
                    continue;
                }
                child_count += 1;
                out.push('\n');
                prettify_node(child, depth + 1, out);
            }

            if child_count > 0 {
                out.push('\n');
                out.push_str(&indent);
            }
            out.push_str("</");
            out.push_str(element.name());
            out.push('>');
        }
        Node::Text(text) => {
            let trimmed = text.text.trim();
            if trimmed.is_empty() {
                return;
            }
            let indent = "  ".repeat(depth);
            out.push_str(&indent);
            out.push_str(trimmed);
        }
        _ => {}
    }
}

fn should_skip_pretty_child(node: NodeRef<'_, Node>) -> bool {
    match node.value() {
        Node::Text(text) => text.text.trim().is_empty(),
        Node::Comment(comment) => comment.trim().is_empty(),
        Node::Doctype(_) | Node::ProcessingInstruction(_) => true,
        _ => false,
    }
}

fn normalize_bs4_whitespace_text(text: &str) -> &str {
    if text.chars().all(char::is_whitespace) {
        if text.contains('\n') { "\n" } else { " " }
    } else {
        text
    }
}

fn synthetic_html_container<'a>(document: NodeRef<'a, Node>) -> Option<NodeRef<'a, Node>> {
    let mut children = document.children();
    let html = children.next()?;
    if children.next().is_some() {
        return None;
    }
    let element = html.value().as_element()?;
    if element.name() != "html" {
        return None;
    }
    if element.attrs().next().is_some() {
        return None;
    }
    Some(html)
}

fn build_visible_doc_order(html: &Html) -> (Vec<NodeId>, HashMap<NodeId, usize>) {
    let mut order = Vec::new();
    for node in html.tree.root().descendants() {
        if matches!(node.value(), Node::Element(_) | Node::Text(_)) {
            order.push(node.id());
        }
    }

    let mut positions = HashMap::with_capacity(order.len());
    for (idx, node_id) in order.iter().copied().enumerate() {
        positions.insert(node_id, idx);
    }

    (order, positions)
}

fn rewrite_body_selector_tokens(css: &str) -> Option<String> {
    if !css.contains("body") {
        return None;
    }

    let chars: Vec<char> = css.chars().collect();
    let mut out = String::with_capacity(css.len());
    let mut i = 0usize;
    let mut bracket_depth = 0usize;
    let mut in_single_quote = false;
    let mut in_double_quote = false;
    let mut replaced = false;

    while i < chars.len() {
        let ch = chars[i];

        if in_single_quote {
            out.push(ch);
            if ch == '\\' && i + 1 < chars.len() {
                i += 1;
                out.push(chars[i]);
            } else if ch == '\'' {
                in_single_quote = false;
            }
            i += 1;
            continue;
        }

        if in_double_quote {
            out.push(ch);
            if ch == '\\' && i + 1 < chars.len() {
                i += 1;
                out.push(chars[i]);
            } else if ch == '"' {
                in_double_quote = false;
            }
            i += 1;
            continue;
        }

        if ch == '\'' {
            in_single_quote = true;
            out.push(ch);
            i += 1;
            continue;
        }

        if ch == '"' {
            in_double_quote = true;
            out.push(ch);
            i += 1;
            continue;
        }

        if ch == '[' {
            bracket_depth += 1;
            out.push(ch);
            i += 1;
            continue;
        }

        if ch == ']' {
            bracket_depth = bracket_depth.saturating_sub(1);
            out.push(ch);
            i += 1;
            continue;
        }

        if bracket_depth == 0
            && starts_with_keyword(&chars, i, ['b', 'o', 'd', 'y'])
            && is_body_tag_prefix(chars.get(i.wrapping_sub(1)).copied(), i == 0)
            && is_body_tag_suffix(chars.get(i + 4).copied())
        {
            out.push_str("html");
            i += 4;
            replaced = true;
            continue;
        }

        out.push(ch);
        i += 1;
    }

    if replaced { Some(out) } else { None }
}

fn starts_with_keyword(chars: &[char], index: usize, keyword: [char; 4]) -> bool {
    chars
        .get(index..index + 4)
        .map(|slice| slice == keyword)
        .unwrap_or(false)
}

fn is_body_tag_prefix(previous: Option<char>, is_start: bool) -> bool {
    if is_start {
        return true;
    }

    previous
        .map(|ch| ch.is_whitespace() || matches!(ch, '>' | '+' | '~' | ',' | '('))
        .unwrap_or(true)
}

fn is_body_tag_suffix(next: Option<char>) -> bool {
    next.map(|ch| !is_css_ident_char(ch)).unwrap_or(true)
}

fn is_css_ident_char(ch: char) -> bool {
    ch.is_ascii_alphanumeric() || matches!(ch, '-' | '_')
}
