# Python BS4 API Guide

This guide covers the `markdownify_rs` bs4-style read-only HTML API and the
`QueryPlan` batch API.

## Import

```python
from markdownify_rs import Soup, Tag, NavigableString, QueryPlan, run_batch
```

## Overview

- `Soup(html)` parses HTML into a read-only tree.
- `Tag` represents an element node.
- `NavigableString` represents a text node.
- The regular API mirrors common BeautifulSoup navigation/search patterns.
- `QueryPlan` + `run_batch` is a Rust-native batch extraction API for
  high-throughput workloads.

## Threading Model

- `Soup`, `Tag`, and `NavigableString` are Python-bound node wrappers and are
  not designed to be shared across Python threads.
- For parallel extraction across many documents, prefer `QueryPlan` +
  `run_batch(...)`.

## Quick Start

```python
from markdownify_rs import Soup

html = """
<div id="root">
  <h1 class="title main">Hello <em>World</em></h1>
  <p class="lead">alpha <b>beta</b></p>
  <p data-kind="note">gamma</p>
</div>
"""

soup = Soup(html)

print(soup.find("h1").get_text(" ", True))      # Hello World
print(soup.find("p", class_="lead").name)       # p
print(len(soup.select("div#root > p")))         # 2
print(soup.find("em").parent.name)              # h1
```

## `Soup` API

### Parse and root

```python
soup = Soup("<div><p>Hello</p></div>")
root = soup.root()  # Tag (document root)
```

### Search

```python
soup.find(name=None, attrs=None, string=None, recursive=True, **kwargs)
soup.find_all(name=None, attrs=None, string=None, limit=None, recursive=True, **kwargs)
```

- Returns `Tag` by default.
- When searching with `string=...`, return values can be `NavigableString`.
- `limit=0` behaves like bs4: no limit.

### CSS selectors

```python
soup.select(css) -> list[Tag]
soup.select_one(css) -> Tag | None
```

Examples:

```python
soup.select("a[href]")
soup.select("div.main > p")
soup.select("p + p")
soup.select("p ~ p")
soup.select("[id]")
soup.select("[href*='http']")
soup.select("h1, h2, h3")
```

### Text

```python
soup.get_text(separator="", strip=False) -> str
```

## `Tag` API

### Identity and attributes

```python
tag.name            # str
tag.attrs           # dict[str, str]
tag.get("href")     # value or None/default
tag.has_attr("id")  # bool
tag.id              # str | None
tag.classes         # list[str]
```

### Search from a node

```python
tag.find(...)
tag.find_all(...)
tag.find_parent(...)
tag.find_parents(...)
tag.find_next_sibling(...)
tag.find_next_siblings(...)
tag.find_previous_sibling(...)
tag.find_previous_siblings(...)
tag.find_next(...)
tag.find_all_next(...)
tag.find_previous(...)
tag.find_all_previous(...)
```

### CSS selectors

```python
tag.select(css)
tag.select_one(css)
```

### Navigation

```python
tag.parent
tag.parents()
tag.children()
tag.children_tags()
tag.contents()
tag.descendants()
tag.next_sibling
tag.previous_sibling
tag.next_siblings()
tag.previous_siblings()
tag.next_element
tag.previous_element
tag.next_elements()
tag.previous_elements()
```

### Text and serialization

```python
tag.string                # str | None
tag.strings()             # list[str]
tag.stripped_strings()    # list[str]
tag.get_text(separator="", strip=False)
tag.inner_html()
tag.outer_html()
tag.prettify()
```

## `NavigableString` API

```python
text.text
text.parent
text.next_sibling
text.previous_sibling
text.next_element
text.previous_element
text.next_elements()
text.previous_elements()
str(text)
```

## Filter Semantics (`find` / `find_all`)

`name`, `attrs`, `string`, and keyword attributes support bs4-style matcher types:

- Exact string: `"div"`
- List of strings: `["div", "span"]`
- Regex: `re.compile(r"^h\d$")`
- Bool: `True`/`False`
- Callable: `lambda value: ...` (regular API only)

Examples:

```python
import re

soup.find_all("a")
soup.find_all(["h1", "h2", "h3"])
soup.find_all(re.compile(r"^h\d$"))
soup.find_all(id=True)                # has id
soup.find_all(id=False)               # no id
soup.find_all(class_="lead")
soup.find_all(attrs={"data-kind": re.compile("note")})
soup.find_all(string=True)            # text nodes
soup.find(string=re.compile("hello", re.I))
soup.find_all("a", href=lambda v: v and v.startswith("https://"))
```

Notes:

- `class_` maps to the `class` attribute.
- `attrs="foo"` is shorthand for class matching.
- Multi-valued attrs like `class="a b"` support token matching for filters.

## QueryPlan Batch API

`QueryPlan` is for high-throughput extraction from many documents with minimal
Python overhead. It returns plain Python values, not `Tag` objects.

### Why use it

- Executes in Rust under `allow_threads` (GIL released during batch execution).
- Parallelizes across docs with Rayon.
- Reuses one plan shape across many HTML inputs.

### Build a plan

```python
from markdownify_rs import QueryPlan
import re

plan = QueryPlan()
plan.add_select_count("links", "a[href]")
plan.add_select_exists("has_main", "main, article")
plan.add_select_one_text("title", "title", separator=" ", strip=True)
plan.add_select_one_attr("main_id", "main", "id")
plan.add_select_all_texts("link_texts", "a", separator=" ", strip=True)
plan.add_select_all_attrs("hrefs", "a", "href")
plan.add_select_all_attrs("hrefs_aligned", "a", "href", skip_missing_attrs=False)
plan.add_select_all_inner_html("section_html", "main, article")
plan.add_find_count("p_count", "p")
plan.add_find_count("lead_count", "p", class_=re.compile("lead"))
plan.add_find_one_text("first_p", "p", separator=" ", strip=True)
plan.add_find_all_texts("all_p", "p", separator=" ", strip=True)
plan.add_get_text("all_text", " ", True)
```

### Run the plan

```python
from markdownify_rs import run_batch

rows = run_batch(html_docs, plan, workers=None)
```

`workers` behavior:

- `None` or `0`: use default Rayon pool (parallel).
- `1`: force sequential execution.
- `N > 1`: use a dedicated pool with `N` worker threads.

Output shape:

```python
[
  {
    "links": 12,
    "has_main": True,
    "title": "Example",
    "main_id": "content",
    "link_texts": ["Home", "About"],
    "hrefs": ["/", "/about"],
    "hrefs_aligned": ["/", None],
    "section_html": ["<p>Hello</p>"],
    "p_count": 88,
    "lead_count": 4,
    "first_p": "Hello world",
    "all_p": ["Hello world", "Second paragraph"],
    "all_text": "...",
  },
  ...
]
```

Output order matches `html_docs` input order.

### QueryPlan method reference

```python
QueryPlan()
len(plan)
plan.keys()
plan.clear()

plan.add_select_count(key, css)
plan.add_select_exists(key, css)
plan.add_select_one_text(key, css, separator="", strip=True)
plan.add_select_one_attr(key, css, attr)
plan.add_select_all_texts(key, css, separator="", strip=True)
plan.add_select_all_attrs(key, css, attr, skip_missing_attrs=True)
plan.add_select_all_inner_html(key, css)
plan.add_get_text(key, separator="", strip=False)

plan.add_find_count(
    key,
    name=None,
    attrs=None,
    string=None,
    limit=None,
    recursive=True,
    **kwargs,
)

plan.add_find_one_text(
    key,
    name=None,
    attrs=None,
    string=None,
    recursive=True,
    separator="",
    strip=True,
    **kwargs,
)

plan.add_find_all_texts(
    key,
    name=None,
    attrs=None,
    string=None,
    limit=None,
    recursive=True,
    include_text_nodes=True,
    separator="",
    strip=True,
    **kwargs,
)

run_batch(html_docs, plan, workers=None)
```

### Important constraints

- Query keys must be unique in a plan.
- Singular text/attr ops return `str | None`; plural ops always return lists.
- `add_select_all_attrs(..., skip_missing_attrs=False)` returns `list[str | None]`
  to preserve positional alignment with matched elements.
- `include_text_nodes` only applies to `add_find_all_texts(...)`.
- Callable matchers are intentionally not supported in `QueryPlan` filters.
  Use regular `Soup.find/find_all` when you need callable predicates.
- `QueryPlan` is extraction-oriented; it does not return `Tag`/`NavigableString`.

## Compatibility Notes

- API is read-only (no tree mutation/builders).
- Behavior aims to track BeautifulSoup for the covered subset, with minor parser
  differences possible between engines.
- If you need exact per-node bs4 behavior for complex edge cases, validate with
  your own fixtures.
