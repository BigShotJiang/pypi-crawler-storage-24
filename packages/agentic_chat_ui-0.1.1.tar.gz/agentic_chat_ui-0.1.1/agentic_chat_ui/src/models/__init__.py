# services/agent_client.py
import logging
from abc import ABC, abstractmethod
from typing import AsyncGenerator, Generic

from agentic_chat_ui.src.constants import TCAgentClient
from agentic_chat_ui.src.mixins import FromConfigMixin

_logger = logging.getLogger(__name__)


class AgentClient(FromConfigMixin[TCAgentClient], ABC, Generic[TCAgentClient]):

    def __init__(self, config: TCAgentClient) -> None:
        self.config = config

    @abstractmethod
    async def astream_chat(self, query: str) -> AsyncGenerator[str, None]:
        raise NotImplementedError()
