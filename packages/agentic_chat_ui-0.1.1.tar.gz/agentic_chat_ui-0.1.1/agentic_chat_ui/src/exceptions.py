class ArxivMechAgentError(Exception):
    """
    Base exception for all agentic-chat-ui errors.

    All custom exceptions in the project should inherit from this.
    """

    def __init__(self, message: str, *, cause: Exception | None = None) -> None:
        super().__init__(message)
        self.cause = cause


class StreamingError(ArxivMechAgentError):
    """
    Raised when token streaming fails (agent, API, or transport).
    """
