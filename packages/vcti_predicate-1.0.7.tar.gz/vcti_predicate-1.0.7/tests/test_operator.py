"""Tests for vcti.predicate.operator — Operator dataclass."""

from vcti.predicate.group import OperatorGroup, default_group
from vcti.predicate.operator import Operator


class TestOperatorConstruction:
    """Test Operator creation and defaults."""

    def test_minimal(self):
        op = Operator(
            name="test_op",
            arity=2,
            fn=lambda x, y, **_: x == y,
        )
        assert op.name == "test_op"
        assert op.arity == 2
        assert op.group is default_group
        assert op.description == ""
        assert op.options == ()

    def test_with_group(self):
        g = OperatorGroup(name="custom")
        op = Operator(
            name="op",
            arity=1,
            fn=lambda x, **_: x is not None,
            group=g,
        )
        assert op.group is g

    def test_with_options(self):
        op = Operator(
            name="op",
            arity=2,
            fn=lambda x, y, **_: True,
            options=("multiline", "dotall"),
        )
        assert op.options == ("multiline", "dotall")

    def test_with_description(self):
        op = Operator(
            name="op",
            arity=2,
            fn=lambda x, y, **_: True,
            description="Does something",
        )
        assert op.description == "Does something"


class TestOperatorImmutability:
    """Operator is frozen — no attribute mutation."""

    def test_frozen(self):
        op = Operator(name="op", arity=2, fn=lambda x, y, **_: True)
        import pytest

        with pytest.raises(AttributeError):
            op.name = "changed"

    def test_hashable(self):
        op = Operator(name="op", arity=2, fn=lambda x, y, **_: True)
        # frozen dataclasses are hashable
        {op: 1}  # should not raise


class TestOperatorCallable:
    """Test that the fn is callable."""

    def test_binary_fn(self):
        op = Operator(
            name="eq",
            arity=2,
            fn=lambda x, y, **_: x == y,
        )
        assert op.fn(1, 1) is True
        assert op.fn(1, 2) is False

    def test_unary_fn(self):
        op = Operator(
            name="check",
            arity=1,
            fn=lambda x, **_: x is not None,
        )
        assert op.fn("hello") is True
        assert op.fn(None) is False

    def test_fn_with_kwargs(self):
        op = Operator(
            name="approx",
            arity=2,
            fn=lambda x, y, **opts: abs(x - y) <= opts.get("tolerance", 0.0),
            options=("tolerance",),
        )
        assert op.fn(1.0, 1.001, tolerance=0.01) is True
        assert op.fn(1.0, 1.1, tolerance=0.01) is False
