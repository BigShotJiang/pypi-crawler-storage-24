"""Tests for collection operators (@=, ?=, all, any)."""

import pytest

from vcti.predicate.evaluator import check, evaluate


class TestInCollection:
    """@= with collection RHS."""

    def test_list(self):
        assert evaluate("@=", 2, [1, 2, 3]) is True
        assert evaluate("@=", 4, [1, 2, 3]) is False

    def test_tuple(self):
        assert evaluate("@=", 2, (1, 2, 3)) is True
        assert evaluate("@=", 4, (1, 2, 3)) is False

    def test_set(self):
        assert evaluate("@=", 2, {1, 2, 3}) is True
        assert evaluate("@=", 4, {1, 2, 3}) is False

    def test_frozenset(self):
        assert evaluate("@=", 2, frozenset([1, 2, 3])) is True

    def test_alias_in(self):
        assert evaluate("in", 2, [1, 2, 3]) is True

    def test_empty_collection(self):
        assert evaluate("@=", 1, []) is False
        assert evaluate("@=", 1, ()) is False
        assert evaluate("@=", 1, set()) is False

    def test_none_in_collection(self):
        assert evaluate("@=", None, [None, 1, 2]) is True
        assert evaluate("@=", None, [1, 2, 3]) is False

    def test_string_in_list_case_insensitive(self):
        assert evaluate("?=", ["doc", "important"], "DOC") is True

    def test_string_in_list_case_sensitive(self):
        assert evaluate("?=", ["doc", "important"], "DOC", case_sensitive=True) is False


class TestNotInCollection:
    """!@= with collection RHS."""

    def test_not_in(self):
        assert evaluate("!@=", 4, [1, 2, 3]) is True
        assert evaluate("!@=", 2, [1, 2, 3]) is False

    def test_alias(self):
        assert evaluate("!in", 4, [1, 2, 3]) is True

    def test_not_in_empty(self):
        assert evaluate("!@=", 1, []) is True


class TestContainsCollection:
    """?= with collection LHS."""

    def test_list_contains(self):
        assert evaluate("?=", [1, 2, 3], 2) is True
        assert evaluate("?=", [1, 2, 3], 4) is False

    def test_tuple_contains(self):
        assert evaluate("?=", (1, 2, 3), 2) is True

    def test_set_contains(self):
        assert evaluate("?=", {1, 2, 3}, 2) is True

    def test_alias_contains(self):
        assert evaluate("contains", [1, 2, 3], 2) is True

    def test_alias_has(self):
        assert evaluate("has", [1, 2, 3], 2) is True

    def test_empty_collection(self):
        assert evaluate("?=", [], 1) is False

    def test_none_in_collection(self):
        assert evaluate("?=", [None, 1, 2], None) is True


class TestNotContainsCollection:
    """!?= with collection LHS."""

    def test_not_contains(self):
        assert evaluate("!?=", [1, 2, 3], 4) is True
        assert evaluate("!?=", [1, 2, 3], 2) is False

    def test_aliases(self):
        assert evaluate("!contains", [1, 2, 3], 4) is True
        assert evaluate("!has", [1, 2, 3], 4) is True


class TestAll:
    """all operator — every LHS item is in RHS."""

    def test_all_present(self):
        assert evaluate("all", [1, 2], [1, 2, 3]) is True

    def test_not_all_present(self):
        assert evaluate("all", [1, 4], [1, 2, 3]) is False

    def test_empty_lhs(self):
        assert evaluate("all", [], [1, 2, 3]) is True

    def test_empty_rhs(self):
        assert evaluate("all", [1], []) is False

    def test_both_empty(self):
        assert evaluate("all", [], []) is True

    def test_with_strings_case_insensitive(self):
        assert evaluate("all", ["a", "b"], ["A", "B", "C"]) is True

    def test_tuple_lhs(self):
        assert evaluate("all", (1, 2), [1, 2, 3]) is True

    def test_set_lhs(self):
        assert evaluate("all", {1, 2}, [1, 2, 3]) is True

    def test_duplicate_in_lhs(self):
        assert evaluate("all", [1, 1, 1], [1, 2, 3]) is True


class TestAny:
    """any operator — at least one LHS item is in RHS."""

    def test_some_present(self):
        assert evaluate("any", [2, 4], [1, 2, 3]) is True

    def test_none_present(self):
        assert evaluate("any", [4, 5], [1, 2, 3]) is False

    def test_empty_lhs(self):
        # any([]) is False — no items to satisfy
        assert evaluate("any", [], [1, 2, 3]) is False

    def test_empty_rhs(self):
        assert evaluate("any", [1], []) is False

    def test_both_empty(self):
        assert evaluate("any", [], []) is False

    def test_with_strings_case_insensitive(self):
        assert evaluate("any", ["X", "B"], ["a", "b", "c"]) is True

    def test_single_element(self):
        assert evaluate("any", [2], [1, 2, 3]) is True


class TestTypeErrors:
    """Operators raise TypeError for unsupported types."""

    def test_in_with_non_container_rhs(self):
        with pytest.raises(TypeError, match="does not support containment"):
            evaluate("@=", 1, 42)

    def test_contains_with_non_container_lhs(self):
        with pytest.raises(TypeError, match="does not support containment"):
            evaluate("?=", 42, 1)

    def test_all_with_non_iterable_lhs(self):
        with pytest.raises(TypeError, match="not iterable"):
            evaluate("all", 42, [1, 2, 3])

    def test_any_with_non_iterable_lhs(self):
        with pytest.raises(TypeError, match="not iterable"):
            evaluate("any", 42, [1, 2, 3])

    def test_all_with_non_container_rhs(self):
        with pytest.raises(TypeError, match="does not support containment"):
            evaluate("all", [1, 2], 42)

    def test_any_with_non_container_rhs(self):
        with pytest.raises(TypeError, match="does not support containment"):
            evaluate("any", [1, 2], 42)


class TestDefaultFallback:
    """Collection operators with non-collection types use default operator."""

    def test_in_with_int_lhs(self):
        # int LHS, list RHS — uses default_in
        assert evaluate("@=", 2, [1, 2, 3]) is True

    def test_contains_with_default(self):
        # None type raises TypeError — does not support containment
        with pytest.raises(TypeError, match="does not support containment"):
            evaluate("?=", None, "value")


class TestCheckCollectionOperators:
    """Test check() with collection operators."""

    def test_in(self):
        assert check(2, "@=", [1, 2, 3]) is True

    def test_contains(self):
        assert check([1, 2, 3], "?=", 2) is True

    def test_all(self):
        assert check([1, 2], "all", [1, 2, 3]) is True

    def test_any(self):
        assert check([2, 4], "any", [1, 2, 3]) is True
