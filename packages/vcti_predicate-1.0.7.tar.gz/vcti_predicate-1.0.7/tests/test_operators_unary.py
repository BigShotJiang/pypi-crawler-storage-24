"""Tests for unary operators (is_empty, exists, is_numeric, is_file, etc.)."""

import pytest

from vcti.predicate.evaluator import check, evaluate


class TestIsEmpty:
    """is_empty — None, empty string, empty collections."""

    def test_none(self):
        assert evaluate("is_empty", None) is True

    def test_empty_string(self):
        assert evaluate("is_empty", "") is True

    def test_empty_list(self):
        assert evaluate("is_empty", []) is True

    def test_empty_dict(self):
        assert evaluate("is_empty", {}) is True

    def test_empty_tuple(self):
        assert evaluate("is_empty", ()) is True

    def test_nonempty_string(self):
        assert evaluate("is_empty", "hello") is False

    def test_nonempty_list(self):
        assert evaluate("is_empty", [1]) is False

    def test_nonempty_dict(self):
        assert evaluate("is_empty", {"key": "val"}) is False

    def test_zero_is_not_empty(self):
        assert evaluate("is_empty", 0) is False

    def test_false_is_not_empty(self):
        assert evaluate("is_empty", False) is False

    def test_whitespace_is_not_empty(self):
        # Whitespace string is not empty (it has characters)
        assert evaluate("is_empty", "  ") is False

    def test_empty_set(self):
        assert evaluate("is_empty", set()) is True

    def test_empty_frozenset(self):
        assert evaluate("is_empty", frozenset()) is True

    def test_nonempty_set(self):
        assert evaluate("is_empty", {1, 2}) is False

    def test_nonempty_frozenset(self):
        assert evaluate("is_empty", frozenset([1])) is False


class TestNotEmpty:
    """!is_empty — negation."""

    def test_nonempty(self):
        assert evaluate("!is_empty", "hello") is True
        assert evaluate("!is_empty", [1]) is True

    def test_empty(self):
        assert evaluate("!is_empty", None) is False
        assert evaluate("!is_empty", "") is False
        assert evaluate("!is_empty", []) is False


class TestExists:
    """exists — value is not None."""

    def test_string(self):
        assert evaluate("exists", "hello") is True

    def test_zero(self):
        assert evaluate("exists", 0) is True

    def test_false(self):
        assert evaluate("exists", False) is True

    def test_empty_string(self):
        assert evaluate("exists", "") is True

    def test_empty_list(self):
        assert evaluate("exists", []) is True

    def test_none(self):
        assert evaluate("exists", None) is False


class TestNotExists:
    """!exists — value is None."""

    def test_none(self):
        assert evaluate("!exists", None) is True

    def test_value(self):
        assert evaluate("!exists", "hello") is False

    def test_zero(self):
        assert evaluate("!exists", 0) is False

    def test_false(self):
        assert evaluate("!exists", False) is False


class TestIsNumeric:
    """is_numeric — int or float, not bool."""

    def test_int(self):
        assert evaluate("is_numeric", 5) is True
        assert evaluate("is_numeric", 0) is True
        assert evaluate("is_numeric", -42) is True

    def test_float(self):
        assert evaluate("is_numeric", 3.14) is True
        assert evaluate("is_numeric", 0.0) is True
        assert evaluate("is_numeric", -1.5) is True

    def test_bool_excluded(self):
        assert evaluate("is_numeric", True) is False
        assert evaluate("is_numeric", False) is False

    def test_string(self):
        assert evaluate("is_numeric", "5") is False
        assert evaluate("is_numeric", "3.14") is False

    def test_none(self):
        assert evaluate("is_numeric", None) is False

    def test_list(self):
        assert evaluate("is_numeric", [1, 2]) is False

    def test_complex_not_numeric(self):
        # complex is not int or float
        assert evaluate("is_numeric", 1 + 2j) is False


class TestIsFile:
    """is_file — path points to a file."""

    def test_existing_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        assert evaluate("is_file", f) is True
        assert evaluate("is_file", str(f)) is True

    def test_directory_is_not_file(self, tmp_path):
        assert evaluate("is_file", tmp_path) is False
        assert evaluate("is_file", str(tmp_path)) is False

    def test_nonexistent_path(self, tmp_path):
        assert evaluate("is_file", tmp_path / "nope.txt") is False

    def test_none_input(self):
        assert evaluate("is_file", None) is False

    def test_int_input(self):
        assert evaluate("is_file", 123) is False

    def test_empty_string(self):
        assert evaluate("is_file", "") is False


class TestIsDir:
    """is_dir — path points to a directory."""

    def test_existing_dir(self, tmp_path):
        assert evaluate("is_dir", tmp_path) is True
        assert evaluate("is_dir", str(tmp_path)) is True

    def test_file_is_not_dir(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        assert evaluate("is_dir", f) is False

    def test_nonexistent_path(self, tmp_path):
        assert evaluate("is_dir", tmp_path / "nope") is False

    def test_none_input(self):
        assert evaluate("is_dir", None) is False

    def test_int_input(self):
        assert evaluate("is_dir", 123) is False


class TestPathExists:
    """path_exists — path exists on filesystem."""

    def test_existing_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        assert evaluate("path_exists", f) is True

    def test_existing_dir(self, tmp_path):
        assert evaluate("path_exists", tmp_path) is True

    def test_nonexistent(self, tmp_path):
        assert evaluate("path_exists", tmp_path / "nope") is False

    def test_none_input(self):
        assert evaluate("path_exists", None) is False

    def test_string_path(self, tmp_path):
        assert evaluate("path_exists", str(tmp_path)) is True


class TestUnaryArityValidation:
    """Unary operators reject extra operands."""

    def test_rejects_rhs(self):
        with pytest.raises(ValueError, match="unary"):
            evaluate("is_empty", "hello", "extra")

    def test_rejects_rhs_exists(self):
        with pytest.raises(ValueError, match="unary"):
            evaluate("exists", "hello", "extra")

    def test_rejects_rhs_is_file(self):
        with pytest.raises(ValueError, match="unary"):
            evaluate("is_file", "/tmp", "extra")


class TestCheckUnaryOperators:
    """Test check() with unary operators."""

    def test_is_empty(self):
        assert check("", "is_empty") is True
        assert check(None, "is_empty") is True
        assert check("hello", "is_empty") is False

    def test_exists(self):
        assert check("hello", "exists") is True
        assert check(None, "exists") is False

    def test_not_exists(self):
        assert check(None, "!exists") is True
        assert check("hello", "!exists") is False

    def test_is_numeric(self):
        assert check(5, "is_numeric") is True
        assert check(3.14, "is_numeric") is True
        assert check("5", "is_numeric") is False

    def test_is_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        assert check(f, "is_file") is True
        assert check(tmp_path, "is_file") is False

    def test_is_dir(self, tmp_path):
        assert check(tmp_path, "is_dir") is True

    def test_path_exists(self, tmp_path):
        assert check(tmp_path, "path_exists") is True
        assert check(tmp_path / "nope", "path_exists") is False
