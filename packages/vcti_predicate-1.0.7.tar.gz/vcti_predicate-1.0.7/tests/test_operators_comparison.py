"""Tests for comparison operators (==, !=, <, <=, >, >=)."""

from pathlib import Path

import pytest

from vcti.predicate.evaluator import check, evaluate


class TestStringEquality:
    """== and != with string LHS."""

    def test_case_insensitive_default(self):
        assert evaluate("==", "Hello", "hello") is True
        assert evaluate("==", "HELLO", "hello") is True

    def test_case_sensitive(self):
        assert evaluate("==", "Hello", "hello", case_sensitive=True) is False
        assert evaluate("==", "Hello", "Hello", case_sensitive=True) is True

    def test_ne_case_insensitive(self):
        assert evaluate("!=", "Hello", "hello") is False
        assert evaluate("!=", "Hello", "world") is True

    def test_ne_case_sensitive(self):
        assert evaluate("!=", "Hello", "hello", case_sensitive=True) is True

    def test_empty_strings(self):
        assert evaluate("==", "", "") is True
        assert evaluate("!=", "", "") is False

    def test_alias_eq(self):
        assert evaluate("eq", "Hello", "hello") is True

    def test_alias_ne(self):
        assert evaluate("ne", "Hello", "world") is True


class TestIntEquality:
    """== and != with int LHS."""

    def test_equal(self):
        assert evaluate("==", 5, 5) is True
        assert evaluate("==", 5, 3) is False

    def test_not_equal(self):
        assert evaluate("!=", 5, 3) is True
        assert evaluate("!=", 5, 5) is False

    def test_zero(self):
        assert evaluate("==", 0, 0) is True
        assert evaluate("==", 0, -0) is True

    def test_negative(self):
        assert evaluate("==", -5, -5) is True
        assert evaluate("==", -5, 5) is False

    def test_rejects_case_sensitive(self):
        with pytest.raises(ValueError, match="does not accept"):
            evaluate("==", 5, 5, case_sensitive=True)


class TestFloatEquality:
    """== and != with float LHS."""

    def test_exact(self):
        assert evaluate("==", 1.0, 1.0) is True
        assert evaluate("==", 1.0, 1.1) is False

    def test_tolerance(self):
        assert evaluate("==", 1.0, 1.001, tolerance=0.01) is True
        assert evaluate("==", 1.0, 1.1, tolerance=0.01) is False

    def test_ne_tolerance(self):
        assert evaluate("!=", 1.0, 1.001, tolerance=0.01) is False
        assert evaluate("!=", 1.0, 1.1, tolerance=0.01) is True

    def test_zero_tolerance_default(self):
        # Default tolerance is 0.0 — exact comparison
        assert evaluate("==", 1.0, 1.0000000001) is False

    def test_negative_floats(self):
        assert evaluate("==", -1.5, -1.5) is True
        assert evaluate("==", -1.5, -1.6, tolerance=0.2) is True


class TestBoolAsInt:
    """bool is in int group — should resolve to int operators."""

    def test_bool_equality(self):
        assert evaluate("==", True, True) is True
        assert evaluate("==", True, False) is False

    def test_bool_equals_int(self):
        # bool is subclass of int, True == 1
        assert evaluate("==", True, 1) is True
        assert evaluate("==", False, 0) is True

    def test_bool_comparison(self):
        assert evaluate(">", True, False) is True
        assert evaluate("<", False, True) is True


class TestPathAsString:
    """Path is in string group — should resolve to string operators."""

    def test_path_equality(self):
        p = Path("/tmp/file")
        assert evaluate("==", p, str(p)) is True

    def test_path_case_insensitive(self):
        p = Path("/tmp/file")
        assert evaluate("==", p, str(p).upper()) is True

    def test_path_case_sensitive(self):
        p = Path("/tmp/file")
        assert evaluate("==", p, str(p).upper(), case_sensitive=True) is False
        assert evaluate("==", p, str(p), case_sensitive=True) is True


class TestOrdering:
    """<, <=, >, >= across types."""

    def test_int_ordering(self):
        assert evaluate(">", 5, 3) is True
        assert evaluate(">", 3, 5) is False
        assert evaluate(">=", 5, 5) is True
        assert evaluate("<", 3, 5) is True
        assert evaluate("<", 5, 3) is False
        assert evaluate("<=", 3, 3) is True

    def test_float_ordering(self):
        assert evaluate(">", 3.14, 2.71) is True
        assert evaluate("<", 2.71, 3.14) is True

    def test_string_ordering(self):
        assert evaluate(">", "banana", "apple") is True
        assert evaluate("<", "apple", "banana") is True
        assert evaluate(">=", "apple", "apple") is True

    def test_string_ordering_case_insensitive(self):
        assert evaluate(">", "Banana", "apple") is True

    def test_string_ordering_case_sensitive(self):
        # Uppercase 'B' < lowercase 'a' in ASCII
        assert evaluate(">", "Banana", "apple", case_sensitive=True) is False

    def test_aliases(self):
        assert evaluate("gt", 5, 3) is True
        assert evaluate("ge", 5, 5) is True
        assert evaluate("lt", 3, 5) is True
        assert evaluate("le", 3, 3) is True


class TestMixedTypes:
    """Cross-type comparisons."""

    def test_str_vs_int_eq(self):
        # str LHS → string group → both normalized as strings
        assert evaluate("==", "5", 5) is False

    def test_none_equality_via_default(self):
        # None type should fall back to default (string_eq for ==)
        # string_normalize passes non-string types through
        assert evaluate("==", None, None) is True

    def test_none_inequality(self):
        assert evaluate("!=", None, "value") is True


class TestCheckBinaryComparison:
    """Test check() with binary comparisons."""

    def test_string(self):
        assert check("Hello", "==", "hello") is True

    def test_int(self):
        assert check(5, ">", 3) is True

    def test_float_tolerance(self):
        assert check(1.0, "==", 1.001, tolerance=0.01) is True

    def test_case_sensitive(self):
        assert check("Hello", "==", "hello", case_sensitive=True) is False
