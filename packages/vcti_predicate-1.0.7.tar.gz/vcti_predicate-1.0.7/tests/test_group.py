"""Tests for vcti.predicate.group — OperatorGroup and built-in groups."""

from pathlib import Path

from vcti.predicate.group import (
    OperatorGroup,
    _string_normalize,
    collection_group,
    default_group,
    float_group,
    int_group,
    regex_group,
    string_group,
)


class TestOperatorGroupConstruction:
    """Test OperatorGroup creation and defaults."""

    def test_minimal_group(self):
        g = OperatorGroup(name="custom")
        assert g.name == "custom"
        assert g.types == ()
        assert g.modifiers == {}
        assert g.defaults == {}

    def test_group_with_types(self):
        g = OperatorGroup(name="t", types=(int, float))
        assert g.types == (int, float)

    def test_group_with_modifiers_and_defaults(self):
        g = OperatorGroup(
            name="t",
            modifiers={"flag": bool},
            defaults={"flag": True},
        )
        assert g.modifiers == {"flag": bool}
        assert g.defaults == {"flag": True}


class TestOperatorGroupEquality:
    """Groups are equal iff their names match."""

    def test_same_name(self):
        a = OperatorGroup(name="x")
        b = OperatorGroup(name="x", types=(int,))
        assert a == b

    def test_different_name(self):
        a = OperatorGroup(name="x")
        b = OperatorGroup(name="y")
        assert a != b

    def test_hash_same_name(self):
        a = OperatorGroup(name="x")
        b = OperatorGroup(name="x")
        assert hash(a) == hash(b)
        assert len({a, b}) == 1

    def test_hash_different_name(self):
        a = OperatorGroup(name="x")
        b = OperatorGroup(name="y")
        assert len({a, b}) == 2

    def test_eq_non_group(self):
        g = OperatorGroup(name="x")
        assert g != "x"
        assert g != 42

    def test_usable_as_dict_key(self):
        g1 = OperatorGroup(name="a")
        g2 = OperatorGroup(name="b")
        d = {g1: 1, g2: 2}
        assert d[OperatorGroup(name="a")] == 1
        assert d[OperatorGroup(name="b")] == 2


class TestDefaultNormalize:
    """Default normalize is identity."""

    def test_identity(self):
        g = OperatorGroup(name="t")
        assert g.normalize("hello", {}) == "hello"
        assert g.normalize(42, {}) == 42
        assert g.normalize(None, {}) is None


class TestStringNormalize:
    """Test _string_normalize used by string and collection groups."""

    def test_lowercases_by_default(self):
        assert _string_normalize("Hello", {"case_sensitive": False}) == "hello"

    def test_preserves_case_when_sensitive(self):
        assert _string_normalize("Hello", {"case_sensitive": True}) == "Hello"

    def test_path_lowercased(self):
        result = _string_normalize(Path("/Some/Path"), {"case_sensitive": False})
        assert isinstance(result, str)
        assert result == str(Path("/Some/Path")).lower()

    def test_path_preserved(self):
        p = Path("/Some/Path")
        result = _string_normalize(p, {"case_sensitive": True})
        assert result == str(p)

    def test_list_of_strings(self):
        result = _string_normalize(["Hello", "WORLD"], {"case_sensitive": False})
        assert result == ["hello", "world"]

    def test_list_case_sensitive(self):
        result = _string_normalize(["Hello", "WORLD"], {"case_sensitive": True})
        assert result == ["Hello", "WORLD"]

    def test_non_string_passthrough(self):
        assert _string_normalize(42, {"case_sensitive": False}) == 42
        assert _string_normalize(None, {"case_sensitive": False}) is None

    def test_nested_list(self):
        result = _string_normalize([["ABC"]], {"case_sensitive": False})
        assert result == [["abc"]]

    def test_empty_string(self):
        assert _string_normalize("", {"case_sensitive": False}) == ""

    def test_empty_list(self):
        assert _string_normalize([], {"case_sensitive": False}) == []


class TestBuiltInGroups:
    """Test built-in group configurations."""

    def test_default_group(self):
        assert default_group.name == "default"
        assert default_group.types == ()
        assert default_group.modifiers == {}

    def test_int_group(self):
        assert int_group.name == "int"
        assert int in int_group.types
        assert bool in int_group.types
        assert int_group.modifiers == {}

    def test_float_group(self):
        assert float_group.name == "float"
        assert float in float_group.types
        assert float_group.modifiers == {"tolerance": float}
        assert float_group.defaults == {"tolerance": 0.0}

    def test_string_group(self):
        assert string_group.name == "string"
        assert str in string_group.types
        assert Path in string_group.types
        assert string_group.modifiers == {"case_sensitive": bool}
        assert string_group.defaults == {"case_sensitive": False}

    def test_regex_group(self):
        assert regex_group.name == "regex"
        assert str in regex_group.types
        assert regex_group.modifiers == {"case_sensitive": bool}
        assert regex_group.defaults == {"case_sensitive": False}

    def test_collection_group(self):
        assert collection_group.name == "collection"
        assert list in collection_group.types
        assert tuple in collection_group.types
        assert set in collection_group.types
        assert frozenset in collection_group.types
        assert collection_group.modifiers == {"case_sensitive": bool}

    def test_string_group_normalize(self):
        assert string_group.normalize("HI", {"case_sensitive": False}) == "hi"
        assert string_group.normalize("HI", {"case_sensitive": True}) == "HI"

    def test_collection_group_normalize(self):
        result = collection_group.normalize(["HI", "BYE"], {"case_sensitive": False})
        assert result == ["hi", "bye"]
