"""Tests for range operators (between, !between)."""

import pytest

from vcti.predicate.evaluator import check, evaluate


class TestBetweenInclusive:
    """between with inclusive=True (default)."""

    def test_int_in_range(self):
        assert evaluate("between", 5, (1, 10)) is True

    def test_int_at_lower_bound(self):
        assert evaluate("between", 1, (1, 10)) is True

    def test_int_at_upper_bound(self):
        assert evaluate("between", 10, (1, 10)) is True

    def test_int_below_range(self):
        assert evaluate("between", 0, (1, 10)) is False

    def test_int_above_range(self):
        assert evaluate("between", 11, (1, 10)) is False

    def test_float_in_range(self):
        assert evaluate("between", 3.14, (1.0, 10.0)) is True

    def test_float_at_bounds(self):
        assert evaluate("between", 1.0, (1.0, 10.0)) is True
        assert evaluate("between", 10.0, (1.0, 10.0)) is True

    def test_float_below_range(self):
        assert evaluate("between", 0.5, (1.0, 10.0)) is False

    def test_negative_range(self):
        assert evaluate("between", -5, (-10, -1)) is True
        assert evaluate("between", 0, (-10, -1)) is False

    def test_zero_span(self):
        assert evaluate("between", -1, (-5, 5)) is True
        assert evaluate("between", 0, (-5, 5)) is True


class TestBetweenExclusive:
    """between with inclusive=False."""

    def test_in_range(self):
        assert evaluate("between", 5, (1, 10), inclusive=False) is True

    def test_at_lower_bound_excluded(self):
        assert evaluate("between", 1, (1, 10), inclusive=False) is False

    def test_at_upper_bound_excluded(self):
        assert evaluate("between", 10, (1, 10), inclusive=False) is False

    def test_just_inside(self):
        assert evaluate("between", 1.001, (1.0, 10.0), inclusive=False) is True
        assert evaluate("between", 9.999, (1.0, 10.0), inclusive=False) is True


class TestBetweenEdgeCases:
    """Edge cases for between."""

    def test_equal_bounds_inclusive(self):
        assert evaluate("between", 5, (5, 5)) is True

    def test_equal_bounds_exclusive(self):
        assert evaluate("between", 5, (5, 5), inclusive=False) is False

    def test_int_with_float_bounds(self):
        assert evaluate("between", 5, (1.0, 10.0)) is True

    def test_float_with_int_bounds(self):
        assert evaluate("between", 5.5, (1, 10)) is True

    def test_large_values(self):
        assert evaluate("between", 1_000_000, (0, 2_000_000)) is True

    def test_small_float_range(self):
        assert evaluate("between", 0.5, (0.0, 1.0)) is True
        assert evaluate("between", 0.0, (0.0, 1.0)) is True
        assert evaluate("between", 1.0, (0.0, 1.0)) is True

    def test_list_bounds(self):
        # Bounds can be a list too
        assert evaluate("between", 5, [1, 10]) is True

    def test_invalid_bounds_single_value(self):
        with pytest.raises(ValueError, match="2-element sequence"):
            evaluate("between", 5, 10)

    def test_invalid_bounds_three_elements(self):
        with pytest.raises(ValueError, match="2-element sequence"):
            evaluate("between", 5, (1, 5, 10))

    def test_invalid_bounds_empty(self):
        with pytest.raises(ValueError, match="2-element sequence"):
            evaluate("between", 5, ())


class TestNotBetween:
    """!between — value is NOT in range."""

    def test_outside_range(self):
        assert evaluate("!between", 0, (1, 10)) is True
        assert evaluate("!between", 11, (1, 10)) is True

    def test_inside_range(self):
        assert evaluate("!between", 5, (1, 10)) is False

    def test_at_bounds_inclusive(self):
        assert evaluate("!between", 1, (1, 10)) is False
        assert evaluate("!between", 10, (1, 10)) is False

    def test_at_bounds_exclusive(self):
        assert evaluate("!between", 1, (1, 10), inclusive=False) is True
        assert evaluate("!between", 10, (1, 10), inclusive=False) is True

    def test_float_not_between(self):
        assert evaluate("!between", 0.5, (1.0, 10.0)) is True
        assert evaluate("!between", 5.0, (1.0, 10.0)) is False


class TestBetweenDefaultFallback:
    """between with non-int/float types uses default operator."""

    def test_string_between(self):
        # String comparison — "d" is between "a" and "z"
        assert evaluate("between", "d", ("a", "z")) is True
        assert evaluate("between", "a", ("a", "z")) is True


class TestCheckRangeOperators:
    """Test check() with range operators."""

    def test_between(self):
        assert check(5, "between", (1, 10)) is True

    def test_between_exclusive(self):
        assert check(5, "between", (1, 10), inclusive=False) is True
        assert check(1, "between", (1, 10), inclusive=False) is False

    def test_not_between(self):
        assert check(0, "!between", (1, 10)) is True
        assert check(5, "!between", (1, 10)) is False
