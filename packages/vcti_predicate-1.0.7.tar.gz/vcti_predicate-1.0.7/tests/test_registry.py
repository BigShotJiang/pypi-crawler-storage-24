"""Tests for vcti.predicate.registry — OperatorRegistry."""

import pytest

from vcti.predicate.evaluator import default_registry
from vcti.predicate.group import OperatorGroup
from vcti.predicate.operator import Operator
from vcti.predicate.registry import OperatorRegistry


class TestSymbolRegistration:
    """Test symbol() and add_operator_to_symbol()."""

    def test_register_symbol(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="t", types=(int,))
        op = Operator(name="op", arity=2, fn=lambda x, y, **_: x == y, group=g)
        reg.symbol("==", operators={g: op})
        assert "==" in reg.symbol_names()

    def test_register_with_aliases(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="t", types=(int,))
        op = Operator(name="op", arity=2, fn=lambda x, y, **_: x == y, group=g)
        reg.symbol("==", aliases=("eq", "equal"), operators={g: op})
        assert "eq" in reg.symbol_names()
        assert "equal" in reg.symbol_names()

    def test_alias_resolves_same_as_canonical(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="t", types=(int,))
        op = Operator(name="op", arity=2, fn=lambda x, y, **_: x == y, group=g)
        reg.symbol("==", aliases=("eq",), operators={g: op})
        assert reg.resolve("==", 5) is reg.resolve("eq", 5)

    def test_add_operator_to_existing_symbol(self):
        reg = OperatorRegistry()
        g1 = OperatorGroup(name="int", types=(int,))
        op1 = Operator(name="int_eq", arity=2, fn=lambda x, y, **_: x == y, group=g1)
        reg.symbol("==", operators={g1: op1})

        g2 = OperatorGroup(name="str", types=(str,))
        op2 = Operator(name="str_eq", arity=2, fn=lambda x, y, **_: x == y, group=g2)
        reg.add_operator_to_symbol("==", g2, op2)

        assert reg.resolve("==", "hello").name == "str_eq"
        assert reg.resolve("==", 5).name == "int_eq"

    def test_add_operator_to_unknown_symbol_raises(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="t", types=(int,))
        op = Operator(name="op", arity=2, fn=lambda x, y, **_: True, group=g)
        with pytest.raises(ValueError, match="Unknown symbol"):
            reg.add_operator_to_symbol("nonexistent", g, op)

    def test_register_operator_directly(self):
        reg = OperatorRegistry()
        op = Operator(name="custom_op", arity=2, fn=lambda x, y, **_: True)
        reg.register_operator(op)
        assert "custom_op" in reg.operator_names()


class TestResolution:
    """Test resolve() with different scenarios."""

    def test_resolve_by_type(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="int", types=(int,))
        op = Operator(name="int_eq", arity=2, fn=lambda x, y, **_: x == y, group=g)
        reg.symbol("==", operators={g: op})
        assert reg.resolve("==", 42) is op

    def test_resolve_unknown_symbol_raises(self):
        reg = OperatorRegistry()
        with pytest.raises(ValueError, match="Unknown symbol"):
            reg.resolve("??", 42)

    def test_resolve_with_operator_override(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="t", types=(int,))
        op = Operator(name="my_op", arity=2, fn=lambda x, y, **_: True, group=g)
        reg.symbol("==", operators={g: op})
        reg.register_operator(Operator(name="other_op", arity=2, fn=lambda x, y, **_: False))
        resolved = reg.resolve("==", 42, operator_name="other_op")
        assert resolved.name == "other_op"

    def test_resolve_with_unknown_operator_raises(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="t", types=(int,))
        op = Operator(name="op", arity=2, fn=lambda x, y, **_: True, group=g)
        reg.symbol("==", operators={g: op})
        with pytest.raises(ValueError, match="Unknown operator"):
            reg.resolve("==", 42, operator_name="nonexistent")

    def test_resolve_with_default_fallback(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="int", types=(int,))
        int_op = Operator(name="int_eq", arity=2, fn=lambda x, y, **_: True, group=g)
        default_op = Operator(name="default_eq", arity=2, fn=lambda x, y, **_: True)
        reg.symbol("==", operators={g: int_op}, default=default_op)
        # float has no group — falls back to default
        assert reg.resolve("==", 3.14) is default_op

    def test_resolve_no_match_no_default_raises(self):
        reg = OperatorRegistry()
        g = OperatorGroup(name="int", types=(int,))
        op = Operator(name="int_eq", arity=2, fn=lambda x, y, **_: True, group=g)
        reg.symbol("==", operators={g: op})
        with pytest.raises(ValueError, match="no operator for type"):
            reg.resolve("==", "hello")


class TestCopy:
    """Test registry copy isolation."""

    def test_copy_is_independent(self):
        reg = default_registry.copy()
        g = OperatorGroup(name="bytes", types=(bytes,))
        op = Operator(name="bytes_eq", arity=2, fn=lambda x, y, **_: x == y, group=g)
        reg.symbol("bytes_eq", operators={g: op})
        assert "bytes_eq" in reg.symbol_names()
        assert "bytes_eq" not in default_registry.symbol_names()

    def test_copy_preserves_symbols(self):
        reg = default_registry.copy()
        assert "==" in reg.symbol_names()
        assert "^=" in reg.symbol_names()
        assert "is_empty" in reg.symbol_names()

    def test_copy_preserves_operators(self):
        reg = default_registry.copy()
        assert "string_eq" in reg.operator_names()
        assert "int_eq" in reg.operator_names()

    def test_copy_resolves_correctly(self):
        reg = default_registry.copy()
        op = reg.resolve("==", "hello")
        assert op.name == "string_eq"


class TestIntrospection:
    """Test symbol_names(), operator_names(), describe_symbol()."""

    def test_symbol_names_sorted(self):
        names = default_registry.symbol_names()
        assert names == sorted(names)

    def test_operator_names_sorted(self):
        names = default_registry.operator_names()
        assert names == sorted(names)

    def test_describe_symbol_contains_name(self):
        desc = default_registry.describe_symbol("==")
        assert "Symbol: ==" in desc

    def test_describe_symbol_contains_operators(self):
        desc = default_registry.describe_symbol("==")
        assert "string_eq" in desc
        assert "int_eq" in desc
        assert "float_eq" in desc

    def test_describe_symbol_contains_aliases(self):
        desc = default_registry.describe_symbol("==")
        assert "eq" in desc

    def test_describe_symbol_contains_modifiers(self):
        desc = default_registry.describe_symbol("==")
        assert "case_sensitive" in desc or "tolerance" in desc

    def test_describe_unknown_symbol_raises(self):
        with pytest.raises(ValueError, match="Unknown symbol"):
            default_registry.describe_symbol("nonexistent")

    def test_symbol_names_includes_canonical(self):
        names = default_registry.symbol_names()
        for sym in ["==", "!=", "<", "<=", ">", ">=", "^=", "$=", "?=", "@=", "~="]:
            assert sym in names, f"Missing canonical symbol: {sym}"

    def test_symbol_names_includes_aliases(self):
        names = default_registry.symbol_names()
        for alias in [
            "eq",
            "ne",
            "lt",
            "le",
            "gt",
            "ge",
            "startswith",
            "endswith",
            "contains",
            "has",
            "in",
            "matches",
        ]:
            assert alias in names, f"Missing alias: {alias}"

    def test_symbol_names_includes_negations(self):
        names = default_registry.symbol_names()
        for neg in ["!^=", "!$=", "!?=", "!@=", "!~=", "!between", "!is_empty", "!exists"]:
            assert neg in names, f"Missing negation: {neg}"

    def test_symbol_names_includes_suffixes(self):
        names = default_registry.symbol_names()
        for suffix in [
            "^=cs",
            "^=ic",
            "$=cs",
            "$=ic",
            "?=cs",
            "?=ic",
            "@=cs",
            "@=ic",
            "~=cs",
            "~=ic",
        ]:
            assert suffix in names, f"Missing suffix: {suffix}"

    def test_symbol_names_includes_unary(self):
        names = default_registry.symbol_names()
        for sym in ["is_empty", "exists", "is_numeric", "is_file", "is_dir", "path_exists"]:
            assert sym in names, f"Missing unary symbol: {sym}"

    def test_symbol_names_includes_range(self):
        names = default_registry.symbol_names()
        assert "between" in names
        assert "!between" in names
