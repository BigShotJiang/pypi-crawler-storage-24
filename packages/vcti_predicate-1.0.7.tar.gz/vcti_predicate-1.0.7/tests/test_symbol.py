"""Tests for vcti.predicate.symbol — Symbol and type-based resolution."""

from pathlib import Path

import pytest

from vcti.predicate.group import OperatorGroup
from vcti.predicate.operator import Operator
from vcti.predicate.symbol import Symbol


class TestSymbolResolution:
    """Test Symbol.resolve() type matching logic."""

    def setup_method(self):
        self.str_group = OperatorGroup(name="string", types=(str,))
        self.int_group = OperatorGroup(name="int", types=(int,))
        self.str_op = Operator(
            name="str_op",
            arity=2,
            fn=lambda x, y, **_: True,
            group=self.str_group,
        )
        self.int_op = Operator(
            name="int_op",
            arity=2,
            fn=lambda x, y, **_: True,
            group=self.int_group,
        )
        self.default_op = Operator(
            name="default_op",
            arity=2,
            fn=lambda x, y, **_: True,
        )

    def test_exact_type_match_str(self):
        sym = Symbol(
            name="==",
            operators={
                self.str_group: self.str_op,
                self.int_group: self.int_op,
            },
        )
        assert sym.resolve(str) is self.str_op

    def test_exact_type_match_int(self):
        sym = Symbol(
            name="==",
            operators={
                self.str_group: self.str_op,
                self.int_group: self.int_op,
            },
        )
        assert sym.resolve(int) is self.int_op

    def test_subclass_match(self):
        """Path is a subclass — should match string group."""
        str_group = OperatorGroup(name="string", types=(str, Path))
        str_op = Operator(
            name="str_op",
            arity=2,
            fn=lambda x, y, **_: True,
            group=str_group,
        )
        sym = Symbol(name="==", operators={str_group: str_op})

        # PurePosixPath is a subclass of Path which is in str_group.types
        # But Path itself is directly in types, so exact match
        assert sym.resolve(Path) is str_op

    def test_subclass_match_custom(self):
        """A custom subclass should resolve via issubclass."""

        class MyStr(str):
            pass

        sym = Symbol(
            name="==",
            operators={
                self.str_group: self.str_op,
            },
        )
        assert sym.resolve(MyStr) is self.str_op

    def test_default_fallback(self):
        sym = Symbol(
            name="==",
            operators={
                self.str_group: self.str_op,
            },
            default=self.default_op,
        )
        assert sym.resolve(float) is self.default_op

    def test_no_match_no_default_raises(self):
        sym = Symbol(
            name="==",
            operators={
                self.str_group: self.str_op,
            },
        )
        with pytest.raises(ValueError, match="no operator for type 'float'"):
            sym.resolve(float)

    def test_error_lists_registered_groups(self):
        sym = Symbol(
            name="==",
            operators={
                self.str_group: self.str_op,
                self.int_group: self.int_op,
            },
        )
        with pytest.raises(ValueError, match="string.*int"):
            sym.resolve(list)

    def test_bool_resolves_to_int_group(self):
        """bool is subclass of int — should match int group."""
        int_group = OperatorGroup(name="int", types=(int, bool))
        int_op = Operator(
            name="int_op",
            arity=2,
            fn=lambda x, y, **_: True,
            group=int_group,
        )
        sym = Symbol(name="==", operators={int_group: int_op})
        assert sym.resolve(bool) is int_op


class TestSymbolAttributes:
    """Test Symbol dataclass attributes."""

    def test_defaults(self):
        sym = Symbol(name="test")
        assert sym.operators == {}
        assert sym.default is None
        assert sym.aliases == ()
        assert sym.description == ""

    def test_with_aliases(self):
        sym = Symbol(name="==", aliases=("eq", "equal"))
        assert sym.aliases == ("eq", "equal")

    def test_with_description(self):
        sym = Symbol(name="==", description="Equality check")
        assert sym.description == "Equality check"
