"""Tests for regex operators (~=, !~=) and suffix variants."""

import pytest

from vcti.predicate.evaluator import check, evaluate


class TestRegexMatch:
    """~= (matches) operator."""

    def test_basic_match(self):
        assert evaluate("~=", "test123", r"\d+") is True
        assert evaluate("~=", "hello", r"\d+") is False

    def test_case_insensitive_default(self):
        assert evaluate("~=", "TEST", "test") is True
        assert evaluate("~=", "Hello World", "hello") is True

    def test_case_sensitive(self):
        assert evaluate("~=", "TEST", "test", case_sensitive=True) is False
        assert evaluate("~=", "TEST", "TEST", case_sensitive=True) is True

    def test_alias_matches(self):
        assert evaluate("matches", "test123", r"\d+") is True

    def test_full_pattern(self):
        assert evaluate("~=", "abc-123-def", r"^[a-z]+-\d+-[a-z]+$") is True
        assert evaluate("~=", "abc-xxx-def", r"^[a-z]+-\d+-[a-z]+$") is False

    def test_special_regex_chars(self):
        assert evaluate("~=", "price: $5.00", r"\$\d+\.\d+") is True

    def test_empty_pattern(self):
        # Empty pattern matches everything
        assert evaluate("~=", "hello", "") is True

    def test_empty_string(self):
        assert evaluate("~=", "", r"\d+") is False
        assert evaluate("~=", "", "") is True


class TestRegexMultiline:
    """~= with multiline option."""

    def test_multiline_true(self):
        text = "line1\nline2"
        assert evaluate("~=", text, r"^line2", multiline=True) is True

    def test_multiline_false(self):
        text = "line1\nline2"
        assert evaluate("~=", text, r"^line2", multiline=False) is False
        # Without multiline, ^line2 doesn't match because ^ only anchors to start

    def test_multiline_default_off(self):
        text = "line1\nline2"
        assert evaluate("~=", text, r"^line2") is False


class TestRegexDotall:
    """~= with dotall option."""

    def test_dotall_true(self):
        text = "hello\nworld"
        assert evaluate("~=", text, r"hello.world", dotall=True) is True

    def test_dotall_false(self):
        text = "hello\nworld"
        assert evaluate("~=", text, r"hello.world", dotall=False) is False

    def test_dotall_default_off(self):
        text = "hello\nworld"
        assert evaluate("~=", text, r"hello.world") is False


class TestRegexCombinedOptions:
    """~= with multiple options."""

    def test_multiline_and_dotall(self):
        text = "line1\nline2\nline3"
        assert evaluate("~=", text, r"^line2.line3", multiline=True, dotall=True) is True

    def test_case_sensitive_and_multiline(self):
        text = "Line1\nline2"
        assert evaluate("~=", text, r"^Line1", multiline=True, case_sensitive=True) is True
        assert evaluate("~=", text, r"^line1", multiline=True, case_sensitive=True) is False

    def test_all_three_options(self):
        text = "HELLO\nworld"
        assert (
            evaluate(
                "~=", text, r"^hello.world", case_sensitive=False, multiline=True, dotall=True
            )
            is True
        )


class TestRegexNegation:
    """!~= (does not match)."""

    def test_negated_no_match(self):
        assert evaluate("!~=", "hello", r"\d+") is True

    def test_negated_has_match(self):
        assert evaluate("!~=", "test123", r"\d+") is False

    def test_negated_alias(self):
        assert evaluate("!matches", "hello", r"\d+") is True

    def test_negated_case_sensitive(self):
        assert evaluate("!~=", "TEST", "test", case_sensitive=True) is True
        assert evaluate("!~=", "TEST", "TEST", case_sensitive=True) is False


class TestRegexSuffixVariants:
    """~=cs and ~=ic."""

    def test_cs(self):
        assert evaluate("~=cs", "TEST", "TEST") is True
        assert evaluate("~=cs", "TEST", "test") is False

    def test_ic(self):
        assert evaluate("~=ic", "TEST", "test") is True

    def test_cs_with_multiline(self):
        text = "Line1\nLine2"
        assert evaluate("~=cs", text, r"^Line2", multiline=True) is True
        assert evaluate("~=cs", text, r"^line2", multiline=True) is False

    def test_ic_with_dotall(self):
        text = "HELLO\nworld"
        assert evaluate("~=ic", text, r"hello.world", dotall=True) is True


class TestRegexEdgeCases:
    """Edge cases for regex operators."""

    def test_non_string_lhs_via_str_conversion(self):
        # regex_group only accepts str type — non-string LHS has no operator
        # Users should convert to str before calling
        with pytest.raises(ValueError, match="no operator for type"):
            evaluate("~=", 12345, r"\d+")

    def test_invalid_regex_raises_with_message(self):
        with pytest.raises(ValueError, match="Invalid regex pattern"):
            evaluate("~=", "test", r"[invalid")

    def test_rejects_unknown_option(self):
        with pytest.raises(ValueError, match="does not accept"):
            evaluate("~=", "test", r"test", unknown_flag=True)


class TestCheckRegexOperators:
    """Test check() with regex operators."""

    def test_match(self):
        assert check("test123", "~=", r"\d+") is True

    def test_negated(self):
        assert check("hello", "!~=", r"\d+") is True

    def test_multiline(self):
        text = "line1\nline2"
        assert check(text, "~=", r"^line2", multiline=True) is True
