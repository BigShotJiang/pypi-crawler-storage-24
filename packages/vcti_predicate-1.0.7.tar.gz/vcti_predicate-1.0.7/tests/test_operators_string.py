"""Tests for string operators (^=, $=) and suffix variants."""

from pathlib import Path

import pytest

from vcti.predicate.evaluator import check, evaluate


class TestStartsWith:
    """^= and its variants."""

    def test_basic(self):
        assert evaluate("^=", "hello world", "hello") is True
        assert evaluate("^=", "hello world", "world") is False

    def test_case_insensitive_default(self):
        assert evaluate("^=", "Hello", "he") is True
        assert evaluate("^=", "Hello", "HE") is True

    def test_case_sensitive_modifier(self):
        assert evaluate("^=", "Hello", "he", case_sensitive=True) is False
        assert evaluate("^=", "Hello", "He", case_sensitive=True) is True

    def test_alias_startswith(self):
        assert evaluate("startswith", "hello", "he") is True

    def test_empty_prefix(self):
        assert evaluate("^=", "hello", "") is True

    def test_empty_string(self):
        assert evaluate("^=", "", "") is True
        assert evaluate("^=", "", "x") is False

    def test_full_string_match(self):
        assert evaluate("^=", "hello", "hello") is True

    def test_path_lhs(self):
        p = Path("/tmp/test.txt")
        assert evaluate("^=", p, str(p)[:4].lower()) is True


class TestStartsWithNegation:
    """!^= (does not start with)."""

    def test_negated(self):
        assert evaluate("!^=", "hello", "xyz") is True
        assert evaluate("!^=", "hello", "he") is False

    def test_negated_alias(self):
        assert evaluate("!startswith", "hello", "xyz") is True

    def test_negated_case_sensitive(self):
        assert evaluate("!^=", "Hello", "he", case_sensitive=True) is True
        assert evaluate("!^=", "Hello", "He", case_sensitive=True) is False


class TestStartsWithSuffix:
    """^=cs and ^=ic."""

    def test_cs(self):
        assert evaluate("^=cs", "Hello", "He") is True
        assert evaluate("^=cs", "Hello", "he") is False

    def test_ic(self):
        assert evaluate("^=ic", "Hello", "he") is True
        assert evaluate("^=ic", "Hello", "HE") is True


class TestEndsWith:
    """$= and its variants."""

    def test_basic(self):
        assert evaluate("$=", "hello world", "world") is True
        assert evaluate("$=", "hello world", "hello") is False

    def test_case_insensitive_default(self):
        assert evaluate("$=", "hello", "LO") is True

    def test_case_sensitive_modifier(self):
        assert evaluate("$=", "hello", "LO", case_sensitive=True) is False
        assert evaluate("$=", "hello", "lo", case_sensitive=True) is True

    def test_alias_endswith(self):
        assert evaluate("endswith", "hello", "lo") is True

    def test_empty_suffix(self):
        assert evaluate("$=", "hello", "") is True

    def test_full_string_match(self):
        assert evaluate("$=", "hello", "hello") is True

    def test_path_lhs(self):
        assert evaluate("$=", Path("/tmp/test.txt"), ".txt") is True


class TestEndsWithNegation:
    """!$= (does not end with)."""

    def test_negated(self):
        assert evaluate("!$=", "hello", "xyz") is True
        assert evaluate("!$=", "hello", "lo") is False

    def test_negated_alias(self):
        assert evaluate("!endswith", "hello", "xyz") is True


class TestEndsWithSuffix:
    """$=cs and $=ic."""

    def test_cs(self):
        assert evaluate("$=cs", "Hello", "llo") is True
        assert evaluate("$=cs", "Hello", "LLO") is False

    def test_ic(self):
        assert evaluate("$=ic", "Hello", "LLO") is True


class TestContainsString:
    """?= with string LHS (substring check)."""

    def test_basic(self):
        assert evaluate("?=", "filename", "name") is True
        assert evaluate("?=", "filename", "xyz") is False

    def test_case_insensitive_default(self):
        assert evaluate("?=", "FileName", "name") is True
        assert evaluate("?=", "FileName", "NAME") is True

    def test_case_sensitive_modifier(self):
        assert evaluate("?=", "FileName", "name", case_sensitive=True) is False
        assert evaluate("?=", "FileName", "Name", case_sensitive=True) is True

    def test_alias_contains(self):
        assert evaluate("contains", "filename", "name") is True

    def test_alias_has(self):
        assert evaluate("has", "filename", "name") is True

    def test_empty_substring(self):
        assert evaluate("?=", "hello", "") is True

    def test_full_match(self):
        assert evaluate("?=", "hello", "hello") is True

    def test_none_lhs(self):
        with pytest.raises(TypeError, match="does not support containment"):
            evaluate("?=", None, "value")

    def test_path_lhs(self):
        assert evaluate("?=", Path("/tmp/myfile.txt"), "myfile") is True


class TestContainsStringNegation:
    """!?= with string LHS."""

    def test_negated(self):
        assert evaluate("!?=", "filename", "xyz") is True
        assert evaluate("!?=", "filename", "name") is False

    def test_negated_aliases(self):
        assert evaluate("!contains", "filename", "xyz") is True
        assert evaluate("!has", "filename", "xyz") is True


class TestContainsSuffix:
    """?=cs and ?=ic."""

    def test_cs(self):
        assert evaluate("?=cs", "FileName", "Name") is True
        assert evaluate("?=cs", "FileName", "name") is False

    def test_ic(self):
        assert evaluate("?=ic", "FileName", "name") is True


class TestInString:
    """@= with string LHS — "is LHS a substring of RHS"."""

    def test_string_in_string(self):
        assert evaluate("@=", "name", "filename") is True
        assert evaluate("@=", "xyz", "filename") is False

    def test_case_insensitive_default(self):
        assert evaluate("@=", "NAME", "filename") is True

    def test_alias_in(self):
        assert evaluate("in", "name", "filename") is True


class TestInStringSuffix:
    """@=cs and @=ic for string."""

    def test_cs(self):
        assert evaluate("@=cs", "Name", "FileName") is True
        assert evaluate("@=cs", "name", "FileName") is False

    def test_ic(self):
        assert evaluate("@=ic", "name", "FileName") is True


class TestCheckStringOperators:
    """Test check() with string operators."""

    def test_startswith(self):
        assert check("hello", "^=", "he") is True

    def test_endswith(self):
        assert check("hello", "$=", "lo") is True

    def test_contains(self):
        assert check("filename", "?=", "name") is True

    def test_in_string(self):
        assert check("name", "@=", "filename") is True

    def test_negated_startswith(self):
        assert check("hello", "!^=", "xyz") is True

    def test_suffix_cs(self):
        assert check("Hello", "^=cs", "He") is True
        assert check("Hello", "^=cs", "he") is False
