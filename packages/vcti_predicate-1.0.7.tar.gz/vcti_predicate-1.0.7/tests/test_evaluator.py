"""Tests for vcti.predicate.evaluator — evaluate() and check() entry points."""

import re

import pytest

import vcti.predicate
from vcti.predicate.evaluator import check, default_registry, evaluate
from vcti.predicate.group import OperatorGroup
from vcti.predicate.operator import Operator


class TestVersion:
    def test_version_exists(self):
        assert hasattr(vcti.predicate, "__version__")

    def test_version_is_valid_semver(self):
        assert re.match(r"^\d+\.\d+\.\d+", vcti.predicate.__version__)


class TestEvaluateBasic:
    """Basic evaluate() behavior."""

    def test_binary(self):
        assert evaluate("==", "hello", "hello") is True

    def test_unary(self):
        assert evaluate("is_empty", "") is True

    def test_returns_bool(self):
        result = evaluate("==", 5, 5)
        assert result is True
        assert isinstance(result, bool)


class TestEvaluateArityValidation:
    """evaluate() validates operand count against resolved arity."""

    def test_no_operands_raises(self):
        with pytest.raises(ValueError, match="at least one operand"):
            evaluate("==")

    def test_binary_with_one_operand_raises(self):
        with pytest.raises(ValueError, match="binary.*expected 2"):
            evaluate("==", 5)

    def test_unary_with_two_operands_raises(self):
        with pytest.raises(ValueError, match="unary"):
            evaluate("is_empty", "hello", "extra")

    def test_binary_with_three_operands_raises(self):
        with pytest.raises(ValueError):
            evaluate("==", 1, 2, 3)


class TestEvaluateSymbolResolution:
    """evaluate() resolves symbols by LHS type."""

    def test_string_lhs_uses_string_group(self):
        # case-insensitive default proves string group was used
        assert evaluate("==", "Hello", "hello") is True

    def test_int_lhs_uses_int_group(self):
        # int group has no modifiers — case_sensitive should be rejected
        with pytest.raises(ValueError, match="does not accept"):
            evaluate("==", 5, 5, case_sensitive=True)

    def test_float_lhs_uses_float_group(self):
        # float group accepts tolerance
        assert evaluate("==", 1.0, 1.001, tolerance=0.01) is True

    def test_unknown_symbol_raises(self):
        with pytest.raises(ValueError, match="Unknown symbol"):
            evaluate("$$$", 1, 2)


class TestEvaluateKwargRouting:
    """evaluate() routes kwargs to group modifiers vs operator options."""

    def test_group_modifier(self):
        # case_sensitive is a string group modifier
        assert evaluate("==", "Hello", "hello", case_sensitive=False) is True
        assert evaluate("==", "Hello", "hello", case_sensitive=True) is False

    def test_operator_option(self):
        # multiline is a regex operator option
        text = "line1\nline2"
        assert evaluate("~=", text, r"^line2", multiline=True) is True

    def test_unknown_kwarg_raises(self):
        with pytest.raises(ValueError, match="does not accept"):
            evaluate("==", "hello", "hello", unknown_arg=True)

    def test_invalid_modifier_for_group(self):
        # tolerance is not valid for string group
        with pytest.raises(ValueError, match="does not accept"):
            evaluate("^=", "hello", "h", tolerance=0.1)

    def test_invalid_option_for_operator(self):
        # multiline is not valid for startswith
        with pytest.raises(ValueError, match="does not accept"):
            evaluate("^=", "hello", "h", multiline=True)


class TestEvaluateOperatorOverride:
    """evaluate() with explicit operator= keyword."""

    def test_override_bypasses_type_resolution(self):
        # Force string_eq even though both args are technically strings already
        assert evaluate("==", "5", "5", operator="string_eq") is True

    def test_unknown_operator_raises(self):
        with pytest.raises(ValueError, match="Unknown operator"):
            evaluate("==", 5, 5, operator="nonexistent")


class TestEvaluateRegistryParam:
    """evaluate() with custom registry."""

    def test_custom_registry(self):
        reg = default_registry.copy()
        g = OperatorGroup(name="bytes", types=(bytes,))
        op = Operator(
            name="bytes_eq",
            arity=2,
            fn=lambda x, y, **_: x == y,
            group=g,
        )
        reg.add_operator_to_symbol("==", g, op)
        assert evaluate("==", b"hello", b"hello", registry=reg) is True


class TestCheckBinary:
    """check() with binary (value-first) operations."""

    def test_string_eq(self):
        assert check("Hello", "==", "hello") is True

    def test_int_gt(self):
        assert check(5, ">", 3) is True

    def test_float_tolerance(self):
        assert check(1.0, "==", 1.001, tolerance=0.01) is True

    def test_case_sensitive(self):
        assert check("Hello", "==", "hello", case_sensitive=True) is False

    def test_startswith(self):
        assert check("hello", "^=", "he") is True

    def test_between(self):
        assert check(5, "between", (1, 10)) is True

    def test_regex(self):
        assert check("test123", "~=", r"\d+") is True


class TestCheckUnary:
    """check() with unary (value-first) operations."""

    def test_is_empty(self):
        assert check("", "is_empty") is True
        assert check("hello", "is_empty") is False

    def test_exists(self):
        assert check("hello", "exists") is True
        assert check(None, "exists") is False

    def test_is_numeric(self):
        assert check(5, "is_numeric") is True
        assert check("5", "is_numeric") is False

    def test_is_file(self, tmp_path):
        f = tmp_path / "test.txt"
        f.write_text("hello")
        assert check(f, "is_file") is True

    def test_is_dir(self, tmp_path):
        assert check(tmp_path, "is_dir") is True


class TestCheckOperatorOverride:
    """check() with operator= keyword."""

    def test_override(self):
        assert check("5", "==", "5", operator="string_eq") is True


class TestCheckNoneRhsVsUnset:
    """check() distinguishes None rhs from missing rhs."""

    def test_binary_with_none_rhs(self):
        # Passing None explicitly is binary comparison
        assert check(None, "==", None) is True

    def test_unary_no_rhs(self):
        # Not passing rhs is unary
        assert check(None, "exists") is False

    def test_binary_with_none_rhs_uses_binary(self):
        # This should NOT be treated as unary
        assert check("hello", "==", None) is False
