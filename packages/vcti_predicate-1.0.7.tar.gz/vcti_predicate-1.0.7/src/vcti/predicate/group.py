# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Operator groups — type-specific behavior for operator families."""

from collections.abc import Callable
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


@dataclass(eq=False)
class OperatorGroup:
    """Defines shared behavior for a category of operators.

    Groups are identified by name. Two groups with the same name are
    considered the same group. Groups are used as dict keys in Symbol
    mappings.

    Attributes:
        name: Group identifier (e.g., "string", "int", "float").
        types: Python types this group handles. Used during symbol
            resolution to match operand types to operators.
        modifiers: Accepted modifier names mapped to their types.
        defaults: Default values for each modifier.
        normalize: Preprocesses a value given active modifiers.
    """

    name: str
    types: tuple[type, ...] = ()
    modifiers: dict[str, type] = field(default_factory=dict)
    defaults: dict[str, Any] = field(default_factory=dict)
    normalize: Callable[[Any, dict[str, Any]], Any] = field(default=lambda v, m: v)

    def __hash__(self) -> int:
        return hash(self.name)

    def __eq__(self, other: object) -> bool:
        if isinstance(other, OperatorGroup):
            return self.name == other.name
        return NotImplemented


# ── Built-in groups ──


def _string_normalize(value: Any, modifiers: dict[str, Any]) -> Any:
    """Normalize string/path values based on case_sensitive modifier."""
    if modifiers.get("case_sensitive", False):
        if isinstance(value, (str, Path)):
            return str(value)
        return value
    if isinstance(value, (str, Path)):
        return str(value).lower()
    if isinstance(value, list):
        return [_string_normalize(item, modifiers) for item in value]
    return value


default_group = OperatorGroup(name="default")

int_group = OperatorGroup(
    name="int",
    types=(int, bool),
)

float_group = OperatorGroup(
    name="float",
    types=(float,),
    modifiers={"tolerance": float},
    defaults={"tolerance": 0.0},
)

string_group = OperatorGroup(
    name="string",
    types=(str, Path),
    modifiers={"case_sensitive": bool},
    defaults={"case_sensitive": False},
    normalize=_string_normalize,
)

regex_group = OperatorGroup(
    name="regex",
    types=(str,),
    modifiers={"case_sensitive": bool},
    defaults={"case_sensitive": False},
)

collection_group = OperatorGroup(
    name="collection",
    types=(list, tuple, set, frozenset),
    modifiers={"case_sensitive": bool},
    defaults={"case_sensitive": False},
    normalize=_string_normalize,
)
