# vcti.predicate package
#
# Public API re-exports for convenient access.

from importlib.metadata import version

from .evaluator import check, default_registry, evaluate
from .group import OperatorGroup
from .operator import Operator
from .registry import OperatorRegistry
from .symbol import Symbol

__version__ = version("vcti-predicate")

__all__ = [
    "__version__",
    "check",
    "evaluate",
    "default_registry",
    "Operator",
    "OperatorGroup",
    "OperatorRegistry",
    "Symbol",
]
