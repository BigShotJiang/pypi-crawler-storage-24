# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Operator dataclass — a concrete comparison implementation."""

from collections.abc import Callable
from dataclasses import dataclass

from .group import OperatorGroup, default_group


@dataclass(frozen=True)
class Operator:
    """A concrete comparison implementation bound to a group.

    Operators are internal — users interact with symbols, not operators
    directly (unless using the explicit ``operator=`` override).

    Attributes:
        name: Internal identifier (e.g., "string_eq", "float_gt").
        arity: 1 (unary), 2 (binary), or 3 (ternary).
        fn: The comparison function. Receives normalized values.
            Signature depends on arity and whether kwargs are declared:
            - Simple:   fn(lhs, rhs) → bool
            - With opts: fn(lhs, rhs, **opts) → bool
        group: The operator group (controls modifiers, normalization).
        description: Human-readable description.
        options: Operator-specific option names (beyond group modifiers).
    """

    name: str
    arity: int
    fn: Callable[..., bool]
    group: OperatorGroup = default_group
    description: str = ""
    options: tuple[str, ...] = ()
