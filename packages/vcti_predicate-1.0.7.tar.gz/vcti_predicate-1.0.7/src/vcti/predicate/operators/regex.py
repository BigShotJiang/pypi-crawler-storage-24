# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Regex matching operators."""

import re
from typing import Any

from ..group import regex_group
from ..operator import Operator
from ..registry import OperatorRegistry


def _regex_match(x: Any, y: Any, **opts: Any) -> bool:
    """Regex search with case_sensitive, multiline, and dotall support."""
    flags = 0
    if not opts.get("case_sensitive", False):
        flags |= re.IGNORECASE
    if opts.get("multiline", False):
        flags |= re.MULTILINE
    if opts.get("dotall", False):
        flags |= re.DOTALL
    pattern = str(y)
    try:
        return bool(re.search(pattern, str(x), flags))
    except re.error as exc:
        raise ValueError(f"Invalid regex pattern {pattern!r}: {exc}") from exc


def _regex_not_match(x: Any, y: Any, **opts: Any) -> bool:
    """Negated regex search."""
    return not _regex_match(x, y, **opts)


def register(registry: OperatorRegistry) -> None:
    """Register regex symbols and operators."""

    registry.symbol(
        "~=",
        aliases=("matches",),
        operators={
            regex_group: Operator(
                name="regex_matches",
                arity=2,
                fn=_regex_match,
                group=regex_group,
                description="Regex search (case-insensitive by default)",
                options=("case_sensitive", "multiline", "dotall"),
            ),
        },
        description="Regex search",
    )

    registry.symbol(
        "!~=",
        aliases=("!matches",),
        operators={
            regex_group: Operator(
                name="regex_not_matches",
                arity=2,
                fn=_regex_not_match,
                group=regex_group,
                description="Negated regex search (case-insensitive by default)",
                options=("case_sensitive", "multiline", "dotall"),
            ),
        },
        description="Negated regex search",
    )
