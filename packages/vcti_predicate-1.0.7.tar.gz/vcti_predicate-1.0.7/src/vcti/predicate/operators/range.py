# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Range operators — check if a value falls within bounds."""

from typing import Any

from ..group import OperatorGroup, float_group, int_group
from ..operator import Operator
from ..registry import OperatorRegistry

# Range group for generic use (no normalization, supports inclusive option)
_range_group = OperatorGroup(
    name="range",
    modifiers={"inclusive": bool},
    defaults={"inclusive": True},
)


def _between(x: Any, bounds: Any, **opts: Any) -> bool:
    """Check if value is between bounds[0] and bounds[1]."""
    try:
        lo, hi = bounds
    except (TypeError, ValueError):
        raise ValueError(
            f"'between' expects a 2-element sequence for bounds, got {bounds!r}"
        ) from None
    if opts.get("inclusive", True):
        return lo <= x <= hi
    return lo < x < hi


def _not_between(x: Any, bounds: Any, **opts: Any) -> bool:
    """Check if value is NOT between bounds[0] and bounds[1]."""
    return not _between(x, bounds, **opts)


def register(registry: OperatorRegistry) -> None:
    """Register range symbols and operators."""

    registry.symbol(
        "between",
        operators={
            int_group: Operator(
                name="int_between",
                arity=2,
                fn=_between,
                group=_range_group,
                description="Integer is between bounds (inclusive by default)",
                options=("inclusive",),
            ),
            float_group: Operator(
                name="float_between",
                arity=2,
                fn=_between,
                group=_range_group,
                description="Float is between bounds (inclusive by default)",
                options=("inclusive",),
            ),
        },
        default=Operator(
            name="default_between",
            arity=2,
            fn=_between,
            group=_range_group,
            description="Value is between bounds (inclusive by default)",
            options=("inclusive",),
        ),
        description="Value is between bounds",
    )

    registry.symbol(
        "!between",
        operators={
            int_group: Operator(
                name="int_not_between",
                arity=2,
                fn=_not_between,
                group=_range_group,
                description="Integer is not between bounds",
                options=("inclusive",),
            ),
            float_group: Operator(
                name="float_not_between",
                arity=2,
                fn=_not_between,
                group=_range_group,
                description="Float is not between bounds",
                options=("inclusive",),
            ),
        },
        default=Operator(
            name="default_not_between",
            arity=2,
            fn=_not_between,
            group=_range_group,
            description="Value is not between bounds",
            options=("inclusive",),
        ),
        description="Value is not between bounds",
    )
