# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Comparison and equality operators."""

from ..group import float_group, int_group, string_group
from ..operator import Operator
from ..registry import OperatorRegistry


def register(registry: OperatorRegistry) -> None:
    """Register comparison/equality symbols and operators."""

    # ── Equal ──

    string_eq = Operator(
        name="string_eq",
        arity=2,
        fn=lambda x, y, **_: x == y,
        group=string_group,
        description="Case-insensitive string equality",
    )
    int_eq = Operator(
        name="int_eq",
        arity=2,
        fn=lambda x, y, **_: x == y,
        group=int_group,
        description="Exact integer equality",
    )
    float_eq = Operator(
        name="float_eq",
        arity=2,
        fn=lambda x, y, **opts: abs(x - y) <= opts.get("tolerance", 0.0),
        group=float_group,
        description="Float equality with optional tolerance",
        options=("tolerance",),
    )
    registry.symbol(
        "==",
        aliases=("eq",),
        operators={
            string_group: string_eq,
            int_group: int_eq,
            float_group: float_eq,
        },
        default=string_eq,
        description="Equal",
    )

    # ── Not equal ──

    string_ne = Operator(
        name="string_ne",
        arity=2,
        fn=lambda x, y, **_: x != y,
        group=string_group,
        description="Case-insensitive string inequality",
    )
    int_ne = Operator(
        name="int_ne",
        arity=2,
        fn=lambda x, y, **_: x != y,
        group=int_group,
        description="Integer inequality",
    )
    float_ne = Operator(
        name="float_ne",
        arity=2,
        fn=lambda x, y, **opts: abs(x - y) > opts.get("tolerance", 0.0),
        group=float_group,
        description="Float inequality with optional tolerance",
        options=("tolerance",),
    )
    registry.symbol(
        "!=",
        aliases=("ne",),
        operators={
            string_group: string_ne,
            int_group: int_ne,
            float_group: float_ne,
        },
        default=string_ne,
        description="Not equal",
    )

    # ── Ordering ──

    for sym, alias, fn, desc in [
        ("<", "lt", lambda x, y, **_: x < y, "Less than"),
        ("<=", "le", lambda x, y, **_: x <= y, "Less than or equal"),
        (">", "gt", lambda x, y, **_: x > y, "Greater than"),
        (">=", "ge", lambda x, y, **_: x >= y, "Greater than or equal"),
    ]:
        str_op = Operator(
            name=f"string_{alias}",
            arity=2,
            fn=fn,
            group=string_group,
        )
        int_op = Operator(
            name=f"int_{alias}",
            arity=2,
            fn=fn,
            group=int_group,
        )
        float_op = Operator(
            name=f"float_{alias}",
            arity=2,
            fn=fn,
            group=float_group,
        )
        registry.symbol(
            sym,
            aliases=(alias,),
            operators={
                string_group: str_op,
                int_group: int_op,
                float_group: float_op,
            },
            default=str_op,
            description=desc,
        )
