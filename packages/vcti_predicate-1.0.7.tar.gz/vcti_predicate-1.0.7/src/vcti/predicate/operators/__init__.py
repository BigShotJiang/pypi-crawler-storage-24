# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Built-in operator definitions assembled into a default registry."""

from ..registry import OperatorRegistry
from . import collection, comparison, range, regex, string, unary


def create_default_registry() -> OperatorRegistry:
    """Build the default operator registry with all built-in operators."""
    registry = OperatorRegistry()
    comparison.register(registry)
    collection.register(registry)
    string.register(registry)
    regex.register(registry)
    unary.register(registry)
    range.register(registry)
    return registry
