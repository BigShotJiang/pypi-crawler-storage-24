# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""String prefix and suffix operators."""

from ..group import OperatorGroup, string_group
from ..operator import Operator
from ..registry import OperatorRegistry
from .collection import _contains, _in
from .regex import _regex_match

# Case-sensitive string group — same types, no normalization
_string_cs_group = OperatorGroup(
    name="string_cs",
    types=(str,),
)

# Explicit case-insensitive string group (same as string_group, for clarity)
_string_ic_group = string_group


def register(registry: OperatorRegistry) -> None:
    """Register string symbols and operators."""

    # ── starts with (^=) ──

    registry.symbol(
        "^=",
        aliases=("startswith",),
        operators={
            string_group: Operator(
                name="string_startswith",
                arity=2,
                fn=lambda x, y, **_: x.startswith(y),
                group=string_group,
                description="String starts with the value",
            ),
        },
        description="String starts with the value",
    )

    registry.symbol(
        "!^=",
        aliases=("!startswith",),
        operators={
            string_group: Operator(
                name="string_not_startswith",
                arity=2,
                fn=lambda x, y, **_: not x.startswith(y),
                group=string_group,
                description="String does not start with the value",
            ),
        },
        description="String does not start with the value",
    )

    # ── ends with ($=) ──

    registry.symbol(
        "$=",
        aliases=("endswith",),
        operators={
            string_group: Operator(
                name="string_endswith",
                arity=2,
                fn=lambda x, y, **_: x.endswith(y),
                group=string_group,
                description="String ends with the value",
            ),
        },
        description="String ends with the value",
    )

    registry.symbol(
        "!$=",
        aliases=("!endswith",),
        operators={
            string_group: Operator(
                name="string_not_endswith",
                arity=2,
                fn=lambda x, y, **_: not x.endswith(y),
                group=string_group,
                description="String does not end with the value",
            ),
        },
        description="String does not end with the value",
    )

    # ── Case-sensitive suffix variants ──

    # ^=cs / ^=ic
    registry.symbol(
        "^=cs",
        operators={
            _string_cs_group: Operator(
                name="string_startswith_cs",
                arity=2,
                fn=lambda x, y, **_: x.startswith(y),
                group=_string_cs_group,
                description="String starts with the value (case-sensitive)",
            ),
        },
        description="String starts with (case-sensitive)",
    )

    registry.symbol(
        "^=ic",
        operators={
            _string_ic_group: Operator(
                name="string_startswith_ic",
                arity=2,
                fn=lambda x, y, **_: x.startswith(y),
                group=_string_ic_group,
                description="String starts with the value (case-insensitive)",
            ),
        },
        description="String starts with (case-insensitive)",
    )

    # $=cs / $=ic
    registry.symbol(
        "$=cs",
        operators={
            _string_cs_group: Operator(
                name="string_endswith_cs",
                arity=2,
                fn=lambda x, y, **_: x.endswith(y),
                group=_string_cs_group,
                description="String ends with the value (case-sensitive)",
            ),
        },
        description="String ends with (case-sensitive)",
    )

    registry.symbol(
        "$=ic",
        operators={
            _string_ic_group: Operator(
                name="string_endswith_ic",
                arity=2,
                fn=lambda x, y, **_: x.endswith(y),
                group=_string_ic_group,
                description="String ends with the value (case-insensitive)",
            ),
        },
        description="String ends with (case-insensitive)",
    )

    # ?=cs / ?=ic
    registry.symbol(
        "?=cs",
        operators={
            _string_cs_group: Operator(
                name="string_contains_cs",
                arity=2,
                fn=_contains,
                group=_string_cs_group,
                description="String contains substring (case-sensitive)",
            ),
        },
        description="String contains (case-sensitive)",
    )

    registry.symbol(
        "?=ic",
        operators={
            _string_ic_group: Operator(
                name="string_contains_ic",
                arity=2,
                fn=_contains,
                group=_string_ic_group,
                description="String contains substring (case-insensitive)",
            ),
        },
        description="String contains (case-insensitive)",
    )

    # @=cs / @=ic (in — case variants)
    registry.symbol(
        "@=cs",
        operators={
            _string_cs_group: Operator(
                name="string_in_cs",
                arity=2,
                fn=_in,
                group=_string_cs_group,
                description="Value is in collection/string (case-sensitive)",
            ),
        },
        description="In (case-sensitive)",
    )

    registry.symbol(
        "@=ic",
        operators={
            _string_ic_group: Operator(
                name="string_in_ic",
                arity=2,
                fn=_in,
                group=_string_ic_group,
                description="Value is in collection/string (case-insensitive)",
            ),
        },
        description="In (case-insensitive)",
    )

    # ~=cs / ~=ic (regex case variants — delegate to regex._regex_match)
    # Override case_sensitive in opts before forwarding to avoid duplicate kwargs
    registry.symbol(
        "~=cs",
        operators={
            _string_cs_group: Operator(
                name="regex_matches_cs",
                arity=2,
                fn=lambda x, y, **opts: _regex_match(x, y, **{**opts, "case_sensitive": True}),
                group=_string_cs_group,
                description="Regex search (case-sensitive)",
                options=("multiline", "dotall"),
            ),
        },
        description="Regex search (case-sensitive)",
    )

    registry.symbol(
        "~=ic",
        operators={
            _string_ic_group: Operator(
                name="regex_matches_ic",
                arity=2,
                fn=lambda x, y, **opts: _regex_match(x, y, **{**opts, "case_sensitive": False}),
                group=_string_ic_group,
                description="Regex search (case-insensitive)",
                options=("multiline", "dotall"),
            ),
        },
        description="Regex search (case-insensitive)",
    )
