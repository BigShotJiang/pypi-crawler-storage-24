# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Collection membership and containment operators."""

from typing import Any

from ..group import collection_group, string_group
from ..operator import Operator
from ..registry import OperatorRegistry


def _check_rhs_contains(y: Any) -> None:
    """Raise TypeError if RHS does not support containment checks."""
    if not hasattr(y, "__contains__"):
        raise TypeError(f"RHS type {type(y).__name__!r} does not support containment checks")


def _check_lhs_contains(x: Any) -> None:
    """Raise TypeError if LHS does not support containment checks."""
    if not hasattr(x, "__contains__"):
        raise TypeError(f"LHS type {type(x).__name__!r} does not support containment checks")


def _in(x: Any, y: Any, **_: Any) -> bool:
    _check_rhs_contains(y)
    return x in y


def _not_in(x: Any, y: Any, **_: Any) -> bool:
    _check_rhs_contains(y)
    return x not in y


def _contains(x: Any, y: Any, **_: Any) -> bool:
    _check_lhs_contains(x)
    return y in x


def _not_contains(x: Any, y: Any, **_: Any) -> bool:
    _check_lhs_contains(x)
    return y not in x


def _all(x: Any, y: Any, **_: Any) -> bool:
    if not hasattr(x, "__iter__"):
        raise TypeError(f"LHS type {type(x).__name__!r} is not iterable")
    _check_rhs_contains(y)
    return all(item in y for item in x)


def _any(x: Any, y: Any, **_: Any) -> bool:
    if not hasattr(x, "__iter__"):
        raise TypeError(f"LHS type {type(x).__name__!r} is not iterable")
    _check_rhs_contains(y)
    return any(item in y for item in x)


def register(registry: OperatorRegistry) -> None:
    """Register collection symbols and operators."""

    # ── in (@=) ──

    registry.symbol(
        "@=",
        aliases=("in",),
        operators={
            string_group: Operator(
                name="string_in",
                arity=2,
                fn=_in,
                group=string_group,
                description="Substring check or membership (case-insensitive)",
            ),
            collection_group: Operator(
                name="collection_in",
                arity=2,
                fn=_in,
                group=collection_group,
                description="Value is in the collection",
            ),
        },
        default=Operator(
            name="default_in",
            arity=2,
            fn=_in,
            description="Value is in the collection",
        ),
        description="Value is in the collection",
    )

    # ── not in (!@=) ──

    registry.symbol(
        "!@=",
        aliases=("!in",),
        operators={
            string_group: Operator(
                name="string_not_in",
                arity=2,
                fn=_not_in,
                group=string_group,
            ),
            collection_group: Operator(
                name="collection_not_in",
                arity=2,
                fn=_not_in,
                group=collection_group,
            ),
        },
        default=Operator(
            name="default_not_in",
            arity=2,
            fn=_not_in,
        ),
        description="Value is not in the collection",
    )

    # ── contains (?=) ──

    registry.symbol(
        "?=",
        aliases=("contains", "has"),
        operators={
            string_group: Operator(
                name="string_contains",
                arity=2,
                fn=_contains,
                group=string_group,
                description="String contains substring",
            ),
            collection_group: Operator(
                name="collection_contains",
                arity=2,
                fn=_contains,
                group=collection_group,
                description="Collection contains the value",
            ),
        },
        default=Operator(
            name="default_contains",
            arity=2,
            fn=_contains,
        ),
        description="Collection/string contains the value",
    )

    # ── not contains (!?=) ──

    registry.symbol(
        "!?=",
        aliases=("!contains", "!has"),
        operators={
            string_group: Operator(
                name="string_not_contains",
                arity=2,
                fn=_not_contains,
                group=string_group,
            ),
            collection_group: Operator(
                name="collection_not_contains",
                arity=2,
                fn=_not_contains,
                group=collection_group,
            ),
        },
        default=Operator(
            name="default_not_contains",
            arity=2,
            fn=_not_contains,
        ),
        description="Collection/string does not contain the value",
    )

    # ── all ──

    registry.symbol(
        "all",
        operators={
            collection_group: Operator(
                name="collection_all",
                arity=2,
                fn=_all,
                group=collection_group,
                description="All items from LHS are in RHS",
            ),
        },
        default=Operator(
            name="default_all",
            arity=2,
            fn=_all,
        ),
        description="All items from LHS are in RHS",
    )

    # ── any ──

    registry.symbol(
        "any",
        operators={
            collection_group: Operator(
                name="collection_any",
                arity=2,
                fn=_any,
                group=collection_group,
                description="At least one item from LHS is in RHS",
            ),
        },
        default=Operator(
            name="default_any",
            arity=2,
            fn=_any,
        ),
        description="At least one item from LHS is in RHS",
    )
