# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Unary operators — test a property of a single value."""

from pathlib import Path
from typing import Any

from ..group import OperatorGroup
from ..operator import Operator
from ..registry import OperatorRegistry

# Unary operators don't need type-based resolution — they work on any type.
# Use default_group with no normalization.
_unary_group = OperatorGroup(name="unary")

# File system group — for path-related checks
_fs_group = OperatorGroup(
    name="filesystem",
    types=(str, Path),
)


def register(registry: OperatorRegistry) -> None:
    """Register unary symbols and operators."""

    # ── Value checks ──

    registry.symbol(
        "is_empty",
        operators={
            _unary_group: Operator(
                name="is_empty",
                arity=1,
                fn=_is_empty,
                group=_unary_group,
                description="Value is None or an empty container",
            ),
        },
        default=Operator(
            name="is_empty",
            arity=1,
            fn=_is_empty,
            group=_unary_group,
        ),
        description="Value is empty or None",
    )

    registry.symbol(
        "!is_empty",
        operators={
            _unary_group: Operator(
                name="is_not_empty",
                arity=1,
                fn=lambda x, **_: not _is_empty(x),
                group=_unary_group,
                description="Value is not empty and not None",
            ),
        },
        default=Operator(
            name="is_not_empty",
            arity=1,
            fn=lambda x, **_: not _is_empty(x),
            group=_unary_group,
        ),
        description="Value is not empty",
    )

    registry.symbol(
        "exists",
        operators={
            _unary_group: Operator(
                name="exists",
                arity=1,
                fn=lambda x, **_: x is not None,
                group=_unary_group,
                description="Value is not None",
            ),
        },
        default=Operator(
            name="exists",
            arity=1,
            fn=lambda x, **_: x is not None,
            group=_unary_group,
        ),
        description="Value is not None",
    )

    registry.symbol(
        "!exists",
        operators={
            _unary_group: Operator(
                name="not_exists",
                arity=1,
                fn=lambda x, **_: x is None,
                group=_unary_group,
                description="Value is None",
            ),
        },
        default=Operator(
            name="not_exists",
            arity=1,
            fn=lambda x, **_: x is None,
            group=_unary_group,
        ),
        description="Value is None",
    )

    registry.symbol(
        "is_numeric",
        operators={
            _unary_group: Operator(
                name="is_numeric",
                arity=1,
                fn=lambda x, **_: isinstance(x, (int, float)) and not isinstance(x, bool),
                group=_unary_group,
                description="Value is int or float (not bool)",
            ),
        },
        default=Operator(
            name="is_numeric",
            arity=1,
            fn=lambda x, **_: isinstance(x, (int, float)) and not isinstance(x, bool),
            group=_unary_group,
        ),
        description="Value is numeric",
    )

    # ── Filesystem checks ──

    _is_file_op = Operator(
        name="is_file",
        arity=1,
        fn=_is_file,
        group=_fs_group,
        description="Path points to an existing file",
    )
    registry.symbol(
        "is_file",
        operators={
            _fs_group: _is_file_op,
        },
        default=_is_file_op,
        description="Path is an existing file",
    )

    _is_dir_op = Operator(
        name="is_dir",
        arity=1,
        fn=_is_dir,
        group=_fs_group,
        description="Path points to an existing directory",
    )
    registry.symbol(
        "is_dir",
        operators={
            _fs_group: _is_dir_op,
        },
        default=_is_dir_op,
        description="Path is an existing directory",
    )

    _path_exists_op = Operator(
        name="path_exists",
        arity=1,
        fn=_path_exists,
        group=_fs_group,
        description="Path exists on the filesystem",
    )
    registry.symbol(
        "path_exists",
        operators={
            _fs_group: _path_exists_op,
        },
        default=_path_exists_op,
        description="Path exists on the filesystem",
    )


def _is_empty(x: Any, **_: Any) -> bool:
    """Check if value is None or an empty container (str, list, dict, tuple, set, frozenset)."""
    if x is None:
        return True
    if isinstance(x, (str, list, dict, tuple, set, frozenset)):
        return len(x) == 0
    return False


def _is_file(x: Any, **_: Any) -> bool:
    try:
        return Path(x).is_file()
    except (TypeError, ValueError, OSError):
        return False


def _is_dir(x: Any, **_: Any) -> bool:
    try:
        return Path(x).is_dir()
    except (TypeError, ValueError, OSError):
        return False


def _path_exists(x: Any, **_: Any) -> bool:
    try:
        return Path(x).exists()
    except (TypeError, ValueError, OSError):
        return False
