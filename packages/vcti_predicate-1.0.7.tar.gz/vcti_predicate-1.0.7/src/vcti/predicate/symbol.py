# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Symbol — a user-facing name that resolves to operators by type."""

from dataclasses import dataclass, field

from .group import OperatorGroup
from .operator import Operator


@dataclass
class Symbol:
    """A user-facing comparison symbol that resolves to operators.

    Attributes:
        name: The symbol string (e.g., "==", ">", "contains").
        operators: Mapping from OperatorGroup to the Operator that
            handles this symbol for that group's types.
        default: Fallback operator when no group matches the operand
            type. If None and no group matches, resolution raises.
        aliases: Alternative names for this symbol.
        description: Human-readable description.
    """

    name: str
    operators: dict[OperatorGroup, Operator] = field(default_factory=dict)
    default: Operator | None = None
    aliases: tuple[str, ...] = ()
    description: str = ""

    def resolve(self, lhs_type: type) -> Operator:
        """Find the right operator for the given LHS type.

        Resolution order:
        1. Exact type match against group.types
        2. Subclass match against group.types
        3. Default operator (if set)
        4. ValueError

        Args:
            lhs_type: The type of the left-hand operand.

        Returns:
            The resolved Operator.

        Raises:
            ValueError: If no operator matches and no default is set.
        """
        # Exact match
        for group, op in self.operators.items():
            if lhs_type in group.types:
                return op

        # Subclass match
        for group, op in self.operators.items():
            if group.types and issubclass(lhs_type, group.types):
                return op

        # Default fallback
        if self.default is not None:
            return self.default

        registered = [g.name for g in self.operators]
        raise ValueError(
            f"Symbol '{self.name}' has no operator for type "
            f"'{lhs_type.__name__}'. Registered groups: {registered}"
        )
