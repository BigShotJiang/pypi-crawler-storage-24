# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Public entry point for predicate evaluation."""

from typing import Any

from .group import OperatorGroup
from .operator import Operator
from .operators import create_default_registry
from .registry import OperatorRegistry

_UNSET = object()

default_registry: OperatorRegistry = create_default_registry()


def check(
    lhs: Any,
    op: str,
    rhs: Any = _UNSET,
    *,
    operator: str | None = None,
    registry: OperatorRegistry = default_registry,
    **kwargs: Any,
) -> bool:
    """Check if a condition holds.

    For binary symbols, pass ``lhs``, ``op``, and ``rhs``.
    For unary symbols, pass ``lhs`` and ``op`` only.

    The symbol ``op`` is resolved to a concrete operator based on the
    type of ``lhs``. Group modifiers and operator-specific options are
    passed as keyword arguments.

    Args:
        lhs: The value to test.
        op: Symbol name (e.g., "==", "^=", "is_empty", "is_file").
        rhs: Second operand. Required for binary symbols, omit for
             unary symbols.
        operator: Explicit operator name, bypassing type-based
            resolution.
        registry: Operator registry to use.
        **kwargs: Group modifiers and/or operator-specific options.

    Returns:
        True if the condition holds, False otherwise.

    Raises:
        ValueError: If the symbol is unknown, no operator matches
            the LHS type, arity doesn't match, or unknown kwargs
            are passed.

    Examples:
        >>> check("Hello", "==", "hello")
        True
        >>> check(5, ">", 3)
        True
        >>> check(1.0, "==", 1.001, tolerance=0.01)
        True
        >>> check("Hello", "==", "hello", case_sensitive=True)
        False
        >>> check("", "is_empty")
        True
        >>> check(path, "is_file")
        True
    """
    args = (lhs,) if rhs is _UNSET else (lhs, rhs)
    return evaluate(op, *args, operator=operator, registry=registry, **kwargs)


def evaluate(
    op: str,
    *args: Any,
    operator: str | None = None,
    registry: OperatorRegistry = default_registry,
    **kwargs: Any,
) -> bool:
    """Evaluate a predicate condition (symbol-first, extensible arity).

    Generic entry point used by rule engines and programmatic callers.
    Accepts any number of operands — arity is validated against the
    resolved operator. For interactive use, prefer :func:`check` which
    has value-first argument order.

    Args:
        op: Symbol name (e.g., "==", "^=", "~=", "is_empty").
        *args: Operands. The first operand is used for type-based
            symbol resolution. The number of operands must match the
            resolved operator's arity.
        operator: Explicit operator name, bypassing type-based
            resolution.
        registry: Operator registry to use.
        **kwargs: Group modifiers and/or operator-specific options.

    Returns:
        True if the condition holds, False otherwise.

    Raises:
        ValueError: If the symbol is unknown, no operator matches
            the first operand's type, operand count doesn't match
            arity, or unknown kwargs are passed.
    """
    if not args:
        raise ValueError("evaluate() requires at least one operand")

    lhs = args[0]

    # ── Resolve symbol → operator ──
    resolved = registry.resolve(op, lhs, operator_name=operator)
    group = resolved.group

    # ── Validate arity ──
    if len(args) != resolved.arity:
        arity_label = {1: "unary", 2: "binary"}.get(resolved.arity, f"{resolved.arity}-ary")
        raise ValueError(
            f"Symbol '{op}' resolved to '{resolved.name}' which is "
            f"{arity_label} — expected {resolved.arity} operand(s), "
            f"got {len(args)}"
        )

    # ── Route kwargs ──
    group_modifiers, op_options, unknown = _route_kwargs(kwargs, group, resolved)
    if unknown:
        _raise_unknown_kwargs(op, resolved, unknown, group)

    # ── Apply group defaults ──
    active_modifiers = {**group.defaults, **group_modifiers}

    # ── Normalize operands via group ──
    norm_args = tuple(group.normalize(arg, active_modifiers) for arg in args)

    # ── Build forwarded kwargs ──
    fwd = {**active_modifiers, **op_options}

    # ── Call operator ──
    return resolved.fn(*norm_args, **fwd)


def _route_kwargs(
    kwargs: dict[str, Any],
    group: OperatorGroup,
    op: Operator,
) -> tuple[dict[str, Any], dict[str, Any], set[str]]:
    """Split kwargs into group modifiers, operator options, and unknown."""
    group_mods: dict[str, Any] = {}
    op_opts: dict[str, Any] = {}
    unknown: set[str] = set()

    for key, value in kwargs.items():
        if key in group.modifiers:
            group_mods[key] = value
        elif key in op.options:
            op_opts[key] = value
        else:
            unknown.add(key)

    return group_mods, op_opts, unknown


def _raise_unknown_kwargs(
    symbol_name: str,
    op: Operator,
    unknown: set[str],
    group: OperatorGroup,
) -> None:
    """Raise ValueError with a helpful message about unknown kwargs."""
    accepted = sorted(set(group.modifiers.keys()) | set(op.options))
    if accepted:
        raise ValueError(
            f"Symbol '{symbol_name}' resolved to '{op.name}' ({group.name} "
            f"group) which does not accept: {sorted(unknown)}. "
            f"Accepted: {accepted}"
        )
    raise ValueError(
        f"Symbol '{symbol_name}' resolved to '{op.name}' ({group.name} "
        f"group) which does not accept any keyword arguments."
    )
