# Copyright Visual Collaboration Technologies Inc. All Rights Reserved.
# See LICENSE for details.
"""Operator registry — manages symbols, operators, and resolution."""

from typing import Any

from .group import OperatorGroup
from .operator import Operator
from .symbol import Symbol


class OperatorRegistry:
    """Manages symbols, operators, and type-based resolution."""

    def __init__(self) -> None:
        self._symbols: dict[str, Symbol] = {}
        self._operators: dict[str, Operator] = {}

    # ── Symbol registration ──

    def symbol(
        self,
        name: str,
        *,
        operators: dict[OperatorGroup, Operator],
        default: Operator | None = None,
        aliases: tuple[str, ...] = (),
        description: str = "",
    ) -> Symbol:
        """Register a symbol with its type-specific operators."""
        sym = Symbol(
            name=name,
            operators=operators,
            default=default,
            aliases=aliases,
            description=description,
        )
        self._symbols[name] = sym
        for alias in aliases:
            self._symbols[alias] = sym
        for op in operators.values():
            self._operators[op.name] = op
        if default and default.name not in self._operators:
            self._operators[default.name] = default
        return sym

    def add_operator_to_symbol(
        self,
        symbol_name: str,
        group: OperatorGroup,
        op: Operator,
    ) -> None:
        """Add a type-specific operator to an existing symbol."""
        if symbol_name not in self._symbols:
            raise ValueError(f"Unknown symbol: '{symbol_name}'")
        self._symbols[symbol_name].operators[group] = op
        self._operators[op.name] = op

    # ── Direct operator registration ──

    def register_operator(self, op: Operator) -> None:
        """Register an operator directly (for explicit operator= usage)."""
        self._operators[op.name] = op

    # ── Resolution ──

    def resolve(
        self,
        symbol_name: str,
        lhs: Any,
        *,
        operator_name: str | None = None,
    ) -> Operator:
        """Resolve a symbol + LHS type to a concrete operator.

        Args:
            symbol_name: The symbol string (e.g., "==").
            lhs: The left-hand value (type used for resolution).
            operator_name: If provided, bypass symbol resolution and
                use this operator directly.

        Returns:
            The resolved Operator.
        """
        if operator_name is not None:
            if operator_name not in self._operators:
                raise ValueError(f"Unknown operator: '{operator_name}'")
            return self._operators[operator_name]

        if symbol_name not in self._symbols:
            raise ValueError(
                f"Unknown symbol: '{symbol_name}'. Valid symbols: {sorted(self.symbol_names())}"
            )
        return self._symbols[symbol_name].resolve(type(lhs))

    # ── Introspection ──

    def symbol_names(self) -> list[str]:
        """All symbol names (including aliases), sorted."""
        return sorted(self._symbols.keys())

    def operator_names(self) -> list[str]:
        """All registered operator names, sorted."""
        return sorted(self._operators.keys())

    def describe_symbol(self, name: str) -> str:
        """Human-readable description of a symbol and its operators."""
        if name not in self._symbols:
            raise ValueError(f"Unknown symbol: '{name}'")
        sym = self._symbols[name]
        parts = [f"Symbol: {sym.name}"]
        if sym.aliases:
            parts.append(f"  aliases: {', '.join(sym.aliases)}")
        if sym.description:
            parts.append(f"  {sym.description}")
        parts.append("  operators:")
        for group, op in sym.operators.items():
            mod_str = ""
            if group.modifiers:
                mods = [f"{k}: {v.__name__}" for k, v in group.modifiers.items()]
                mod_str = f" (modifiers: {', '.join(mods)})"
            opts_str = ""
            if op.options:
                opts_str = f" (options: {', '.join(op.options)})"
            parts.append(f"    {group.name}: {op.name}{mod_str}{opts_str}")
        if sym.default:
            parts.append(f"  default: {sym.default.name}")
        return "\n".join(parts)

    # ── Copy ──

    def copy(self) -> "OperatorRegistry":
        """Create an independent copy for scoped customization."""
        new = OperatorRegistry()
        for name, sym in self._symbols.items():
            if name == sym.name:  # skip aliases, reconstruct from Symbol
                new.symbol(
                    sym.name,
                    operators=dict(sym.operators),
                    default=sym.default,
                    aliases=sym.aliases,
                    description=sym.description,
                )
        # Copy any directly registered operators not part of symbols
        for op_name, op in self._operators.items():
            if op_name not in new._operators:
                new._operators[op_name] = op
        return new
