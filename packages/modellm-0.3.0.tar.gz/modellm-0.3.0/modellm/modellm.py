
"""
Modellm 
------------------
A framework for declarative creation of LLM-powered agents with 
structured inputs and outputs using Pydantic data models and the pipe operator.
"""

from pydantic import BaseModel
from typing import List, Union, Callable, ClassVar, TypeVar, Generic, Type, Optional
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import SystemMessage, HumanMessage

InputT = TypeVar('InputT', bound=Union[str, BaseModel])
OutputT = TypeVar('OutputT', bound=BaseModel)
T = TypeVar('T', bound=BaseModel)


def BaseModelAI(llm: BaseChatModel):
    """
    Factory function that returns a Pydantic BaseModel configured with LLM capabilities.
    
    This follows established Python patterns like Generic[T] and provides a clean,
    explicit way to create AI-powered models.
    
    Args:
        llm: The language model to use for generating structured outputs
        
    Returns:
        A base class with generate_from() method for LLM-powered generation
        
    Example:
        from modellm import BaseModelAI
        from langchain_openai import ChatOpenAI
        
        llm = ChatOpenAI(model="gpt-4")
        
        class Recipe(BaseModelAI(llm)):
            name: str
            ingredients: list[str]
            instructions: list[str]
        
        # Generate structured output - this will GLOW in your IDE! ✨
        recipe = Recipe.generate_from("chocolate chip cookies")
        
        # Pipe operator also works
        recipe = "chocolate chip cookies" | Recipe
    """
    
    # Create a metaclass that supports the pipe operator
    class _AIModelMeta(type(BaseModel)):
        """Metaclass that enables pipe operator for AI models."""
        
        def __ror__(cls, other: Union[str, BaseModel]):
            """Implements the right pipe operator (input | Model)."""
            return cls.generate_from(other)
    
    class _BaseModelAI(BaseModel, metaclass=_AIModelMeta):
        """Base model class with LLM generation capabilities."""
        
        @classmethod
        def build_messages(
            cls,
            input_data: Union[str, BaseModel],
            system_prompt: Optional[str] = None,
            extra_guidance: Optional[str] = None,
        ) -> list:
            """
            Build the message list that would be sent to the LLM, without invoking it.
            
            Useful for inspecting prompts, counting tokens, or debugging.
            
            Args:
                input_data: String prompt or Pydantic model instance to process
                system_prompt: Optional system message for behavioral instructions
                extra_guidance: Optional additional guidance appended to input
                
            Returns:
                List of LangChain message objects (SystemMessage / HumanMessage)
            """
            if isinstance(input_data, BaseModel):
                content = input_data.model_dump_json()
            elif isinstance(input_data, str):
                content = input_data
            else:
                raise ValueError("Input must be a string or Pydantic model instance")
            
            if extra_guidance:
                content = f"{content}\n\n{extra_guidance}"
            
            messages = []
            if system_prompt:
                messages.append(SystemMessage(content=system_prompt))
            messages.append(HumanMessage(content=content))
            return messages

        @classmethod
        def generate_from(
            cls: Type[T], 
            input_data: Union[str, BaseModel],
            system_prompt: Optional[str] = None,
            extra_guidance: Optional[str] = None,
            include_usage: bool = False,
        ) -> T:
            """
            Generate a structured instance from input using the configured LLM.
            
            This method processes the input through the LLM and returns a validated
            instance of this model with structured output.
            
            Args:
                input_data: String prompt or Pydantic model instance to process
                system_prompt: Optional system message for behavioral instructions
                extra_guidance: Optional additional guidance appended to input
                include_usage: If True, attach token usage metadata as _usage_metadata
                    on the returned instance (dict with 'input_tokens', 'output_tokens', etc.)
                
            Returns:
                Instance of this model with LLM-generated data
                
            Raises:
                ValueError: If input type is invalid
                
            Example:
                recipe = Recipe.generate_from("Make a chocolate cake recipe")
                # With system prompt:
                recipe = Recipe.generate_from(
                    "chocolate cake",
                    system_prompt="You are a professional pastry chef."
                )
                # With token usage:
                recipe = Recipe.generate_from("chocolate cake", include_usage=True)
                print(recipe._usage_metadata)  # {'input_tokens': ..., 'output_tokens': ...}
            """
            structured_llm = llm.with_structured_output(cls, include_raw=include_usage)
            messages = cls.build_messages(input_data, system_prompt=system_prompt, extra_guidance=extra_guidance)
            result = structured_llm.invoke(messages)
            
            if include_usage:
                parsed = result["parsed"]
                raw = result["raw"]
                parsed._usage_metadata = getattr(raw, "usage_metadata", None)
                return parsed
            return result
    
    return _BaseModelAI

def _build_messages(
    input_data: Union[str, BaseModel],
    system_prompt: Optional[str] = None,
    extra_guidance: Optional[str] = None,
) -> list:
    """
    Build the message list from input data without invoking the LLM.

    Args:
        input_data: String prompt or Pydantic model instance
        system_prompt: Optional system message for behavioral instructions
        extra_guidance: Optional additional guidance appended to input

    Returns:
        List of LangChain message objects
    """
    if isinstance(input_data, BaseModel):
        content = input_data.model_dump_json()
    elif isinstance(input_data, str):
        content = input_data
    else:
        raise ValueError("Input must be a string or Pydantic model instance")

    if extra_guidance:
        content = f"{content}\n\n{extra_guidance}"

    messages = []
    if system_prompt:
        messages.append(SystemMessage(content=system_prompt))
    messages.append(HumanMessage(content=content))
    return messages


def _get_agent_function(
    input_model: Union[Type[BaseModel], Type[str]],
    output_model: Type[BaseModel],
    llm: BaseChatModel,
    system_prompt: Optional[str] = None,
    extra_guidance: Optional[str] = None,
    include_usage: bool = False,
) -> Callable[[InputT], OutputT]:
    """
    Creates an agent function that processes input through an LLM and returns structured output.

    Args:
        input_model: The expected input type (either str or a Pydantic model)
        output_model: The Pydantic model class for structured output
        llm: The language model to use for processing
        system_prompt: Optional system message for behavioral instructions
        extra_guidance: Optional additional guidance appended to input
        include_usage: If True, attach token usage metadata on the returned instance

    Returns:
        A callable that takes input_model and returns output_model
    """
    structured_llm = llm.with_structured_output(output_model, include_raw=include_usage)
    
    def run_llm(input_data: InputT) -> OutputT:
        """
        Process the input through the LLM and return structured output.

        Args:
            input_data: Input matching input_model type

        Returns:
            Structured output matching output_model

        Raises:
            ValueError: If input_data doesn't match the expected input_model type
        """
        if input_model == str:
            if not isinstance(input_data, str):
                raise ValueError("Input must be a string")
        elif not isinstance(input_data, input_model):
            raise ValueError(f"Input must be an instance of {input_model}")
        
        messages = _build_messages(input_data, system_prompt=system_prompt, extra_guidance=extra_guidance)
        result = structured_llm.invoke(messages)
        
        if include_usage:
            parsed = result["parsed"]
            raw = result["raw"]
            parsed._usage_metadata = getattr(raw, "usage_metadata", None)
            return parsed
        return result
        
    return run_llm

def add_llm(llm: BaseChatModel) -> Callable[[Type[BaseModel]], Type[BaseModel]]:
    """
    Decorator that adds LLM processing capabilities to a Pydantic model using the pipe operator.

    Args:
        llm: The language model to use for processing

    Returns:
        A decorator function that enhances a Pydantic model with LLM processing
    """
    def decorator(cls: Type[BaseModel]) -> Type[BaseModel]:
        class AushaMeta(type(cls)):
            """Metaclass that implements the pipe operator for LLM processing."""
            
            def __ror__(cls, other: InputT) -> OutputT:
                """Implements the right pipe operator (input | Model)."""
                agent_function = _get_agent_function(
                    str if isinstance(other, str) else type(other),
                    cls, 
                    llm
                )
                return agent_function(other)

        # Create new class with our metaclass
        class WrappedClass(cls, metaclass=AushaMeta):
            """A wrapper class that adds LLM processing capabilities to the original model."""
            
            @classmethod
            def build_messages(
                cls,
                input_data: Union[str, BaseModel],
                system_prompt: Optional[str] = None,
                extra_guidance: Optional[str] = None,
            ) -> list:
                """
                Build the message list that would be sent to the LLM, without invoking it.
                
                Useful for inspecting prompts, counting tokens, or debugging.
                """
                return _build_messages(input_data, system_prompt=system_prompt, extra_guidance=extra_guidance)

            @classmethod
            def generate_from(
                cls, 
                input_data: Union[str, BaseModel],
                system_prompt: Optional[str] = None,
                extra_guidance: Optional[str] = None,
                include_usage: bool = False,
            ) -> BaseModel:
                """
                Generate a structured instance from input using the configured LLM.
                
                This is an alternative to the pipe operator syntax.
                Instead of: input | MyModel
                You can use: MyModel.generate_from(input)
                
                Args:
                    input_data: String prompt or Pydantic model instance
                    system_prompt: Optional system message for behavioral instructions
                    extra_guidance: Optional additional guidance appended to input
                    include_usage: If True, attach token usage metadata as _usage_metadata
                    
                Returns:
                    Instance of this model with LLM-generated data
                """
                agent_function = _get_agent_function(
                    str if isinstance(input_data, str) else type(input_data),
                    cls, 
                    llm,
                    system_prompt=system_prompt,
                    extra_guidance=extra_guidance,
                    include_usage=include_usage,
                )
                return agent_function(input_data)

        # Preserve the original class metadata
        WrappedClass.__name__ = cls.__name__
        WrappedClass.__qualname__ = cls.__qualname__
        WrappedClass.__doc__ = cls.__doc__
        
        return WrappedClass
    return decorator

