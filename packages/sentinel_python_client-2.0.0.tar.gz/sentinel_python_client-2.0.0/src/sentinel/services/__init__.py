"""Sentinel API services."""
