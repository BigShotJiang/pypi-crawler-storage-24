"""VRIN API Key Authentication.

This module handles API key validation for the VRIN MCP Server.
It supports both standard (vrin_) and enterprise (vrin_ent_) API keys.

Enterprise keys route to customer-owned infrastructure for data sovereignty.

Authentication sources (in priority order):
1. Request context (Authorization header) - for remote MCP servers
2. VRIN_API_KEY environment variable - for local MCP servers
"""

import logging
import re
from dataclasses import dataclass
from typing import Optional

from vrin_mcp.client.vrin_api import VRINClient
from vrin_mcp.auth.context import get_api_key as get_api_key_from_context

logger = logging.getLogger(__name__)

# API key format patterns
STANDARD_KEY_PATTERN = re.compile(r"^vrin_[a-f0-9]{16,}$")
ENTERPRISE_KEY_PATTERN = re.compile(r"^vrin_ent_[a-f0-9]{16,}$")


class AuthError(Exception):
    """Authentication error.

    Raised when API key validation fails.
    """

    pass


@dataclass
class AuthContext:
    """Authentication context after successful validation.

    Attributes:
        api_key: The validated API key
        is_enterprise: True if using enterprise key (data sovereignty)
        user_id: User identifier (if available)
    """

    api_key: str
    is_enterprise: bool
    user_id: Optional[str] = None


def validate_key_format(api_key: str) -> bool:
    """Validate API key format without calling backend.

    Args:
        api_key: API key to validate

    Returns:
        True if format is valid, False otherwise
    """
    if not api_key:
        return False

    return bool(
        STANDARD_KEY_PATTERN.match(api_key) or ENTERPRISE_KEY_PATTERN.match(api_key)
    )


async def validate_api_key(api_key: str) -> AuthContext:
    """Validate VRIN API key and return authentication context.

    This function performs:
    1. Format validation (vrin_ or vrin_ent_ prefix)
    2. Backend validation (calls VRIN auth API)

    Args:
        api_key: API key with vrin_ or vrin_ent_ prefix

    Returns:
        AuthContext with validation results

    Raises:
        AuthError: If key is missing, malformed, or invalid
    """
    # Check for missing key
    if not api_key:
        raise AuthError("API key is required. Set VRIN_API_KEY environment variable.")

    # Check key format
    if not api_key.startswith(("vrin_", "vrin_ent_")):
        raise AuthError(
            "Invalid API key format. "
            "Key must start with 'vrin_' (standard) or 'vrin_ent_' (enterprise)."
        )

    # Validate format with regex
    if not validate_key_format(api_key):
        raise AuthError(
            "Invalid API key format. "
            "Key must be in format: vrin_<hex> or vrin_ent_<hex>"
        )

    is_enterprise = api_key.startswith("vrin_ent_")

    # Validate with backend
    logger.info(f"Validating API key (enterprise={is_enterprise})")

    try:
        async with VRINClient(api_key) as client:
            is_valid = await client.validate_key()

            if not is_valid:
                raise AuthError(
                    "API key validation failed. "
                    "Key may be invalid, expired, or deactivated."
                )

            logger.info("API key validated successfully")

            return AuthContext(
                api_key=api_key,
                is_enterprise=is_enterprise,
            )

    except AuthError:
        raise
    except Exception as e:
        logger.error(f"API key validation error: {e}")
        raise AuthError(f"API key validation failed: {e}")


def get_api_key_from_env() -> str:
    """Get API key from environment variable.

    Returns:
        API key string

    Raises:
        AuthError: If VRIN_API_KEY is not set
    """
    import os

    api_key = os.environ.get("VRIN_API_KEY")
    if not api_key:
        raise AuthError(
            "VRIN_API_KEY environment variable is required. "
            "Get your API key at https://vrin.cloud"
        )
    return api_key


def get_api_key() -> str:
    """Get API key from request context or environment variable.

    This is the primary function for getting the API key. It checks:
    1. Request context (from Authorization header) - for remote MCP
    2. VRIN_API_KEY environment variable - for local MCP

    Returns:
        API key string

    Raises:
        AuthError: If no API key is available from either source
    """
    api_key = get_api_key_from_context()

    if not api_key:
        raise AuthError(
            "Authentication required. Either:\n"
            "  • Pass 'Authorization: Bearer vrin_xxx' header (API key)\n"
            "  • Pass 'Authorization: Bearer eyJ...' header (Stytch OAuth JWT)\n"
            "  • Set VRIN_API_KEY environment variable (local MCP)\n"
            "Get your API key at https://vrin.cloud"
        )

    return api_key
