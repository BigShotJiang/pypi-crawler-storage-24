"""JWT Claims to VRiN API Key Resolver.

Maps Stytch JWT claims (member_id, email) to VRiN API keys by calling
the VRiN auth API. Results are cached in-memory with a 5-minute TTL.

The /auth/stytch/sync endpoint handles user creation/lookup on the
VRiN backend side.
"""

import logging
import time
from typing import Optional

import httpx

from vrin_mcp.auth.jwt_validator import JWTClaims

logger = logging.getLogger(__name__)

# Cache TTL in seconds (5 minutes)
_CACHE_TTL = 300


class UserResolveError(Exception):
    """Raised when JWT-to-API-key resolution fails."""

    pass


class _CacheEntry:
    """In-memory cache entry with TTL."""

    __slots__ = ("api_key", "expires_at")

    def __init__(self, api_key: str, ttl: float = _CACHE_TTL) -> None:
        self.api_key = api_key
        self.expires_at = time.time() + ttl

    @property
    def is_expired(self) -> bool:
        return time.time() > self.expires_at


class UserResolver:
    """Resolves Stytch JWT claims to VRiN API keys.

    Flow:
    1. Extract email + member_id from JWT claims
    2. Call VRiN auth API: POST /auth/stytch/sync
    3. Cache mapping (member_id -> api_key) for 5 minutes
    4. If user doesn't exist, return error

    Example:
        resolver = UserResolver()
        api_key = await resolver.resolve(claims)
    """

    def __init__(self, auth_url: Optional[str] = None) -> None:
        import os

        self._auth_url = auth_url or os.environ.get(
            "VRIN_AUTH_URL",
            "https://gp7g651udc.execute-api.us-east-1.amazonaws.com/Prod",
        )
        # member_id -> _CacheEntry
        self._cache: dict[str, _CacheEntry] = {}

    async def resolve(self, claims: JWTClaims) -> str:
        """Resolve JWT claims to a VRiN API key.

        Args:
            claims: Validated JWT claims from StytchJWTValidator

        Returns:
            VRiN API key string (vrin_... or vrin_ent_...)

        Raises:
            UserResolveError: If user cannot be resolved
        """
        if not claims.sub:
            raise UserResolveError("JWT missing 'sub' claim (member_id)")

        # Check cache first
        cached = self._cache.get(claims.sub)
        if cached and not cached.is_expired:
            logger.debug(f"Cache hit for member {claims.sub}")
            return cached.api_key

        # Evict expired entry
        if cached and cached.is_expired:
            del self._cache[claims.sub]

        # Call VRiN auth API to resolve
        api_key = await self._sync_user(claims)

        # Cache the result
        self._cache[claims.sub] = _CacheEntry(api_key)
        logger.info(f"Resolved member {claims.sub} to API key")

        return api_key

    async def _sync_user(self, claims: JWTClaims) -> str:
        """Call VRiN auth API to sync/resolve user.

        Args:
            claims: JWT claims with member_id and email

        Returns:
            VRiN API key

        Raises:
            UserResolveError: If sync fails
        """
        if not claims.email:
            logger.warning(
                f"JWT has no email claim for member {claims.sub}. "
                f"Available claims: {list(claims.raw_claims.keys())}"
            )

        payload = {
            "member_id": claims.sub,
        }
        if claims.email:
            payload["email"] = claims.email
        if claims.organization_id:
            payload["organization_id"] = claims.organization_id

        try:
            async with httpx.AsyncClient(timeout=10.0) as client:
                response = await client.post(
                    f"{self._auth_url}/auth/stytch/sync",
                    json=payload,
                    headers={"Content-Type": "application/json"},
                )

                if response.status_code == 404:
                    raise UserResolveError(
                        "User not found. Must be invited by an enterprise admin first."
                    )

                if response.status_code != 200:
                    raise UserResolveError(
                        f"Auth sync failed: HTTP {response.status_code}"
                    )

                data = response.json()
                api_key = data.get("api_key")

                if not api_key:
                    raise UserResolveError(
                        "Auth sync response missing api_key field"
                    )

                return api_key

        except UserResolveError:
            raise
        except httpx.TimeoutException:
            raise UserResolveError("Auth sync timed out")
        except Exception as e:
            logger.error(f"Auth sync error: {e}")
            raise UserResolveError(f"Auth sync failed: {e}")

    def clear_cache(self) -> None:
        """Clear the entire resolution cache."""
        self._cache.clear()

    def evict(self, member_id: str) -> None:
        """Evict a specific member from cache."""
        self._cache.pop(member_id, None)
