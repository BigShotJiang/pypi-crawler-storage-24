"""VRIN MCP Authentication - API key + OAuth JWT validation."""

from vrin_mcp.auth.api_key import validate_api_key, AuthError, get_api_key, get_api_key_from_env
from vrin_mcp.auth.context import (
    set_request_api_key,
    get_request_api_key,
    clear_request_api_key,
    extract_bearer_token,
    is_jwt,
    set_auth_info,
    get_auth_info,
    clear_auth_info,
)
from vrin_mcp.auth.jwt_validator import StytchJWTValidator, JWTValidationError, JWTClaims
from vrin_mcp.auth.user_resolver import UserResolver, UserResolveError

__all__ = [
    # API key auth
    "validate_api_key",
    "AuthError",
    "get_api_key",
    "get_api_key_from_env",
    # Context
    "set_request_api_key",
    "get_request_api_key",
    "clear_request_api_key",
    "extract_bearer_token",
    "is_jwt",
    "set_auth_info",
    "get_auth_info",
    "clear_auth_info",
    # JWT / OAuth
    "StytchJWTValidator",
    "JWTValidationError",
    "JWTClaims",
    "UserResolver",
    "UserResolveError",
]
