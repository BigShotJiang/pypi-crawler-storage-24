"""Request-scoped authentication context using contextvars.

This module provides thread-safe, request-scoped storage for authentication
using API keys (vrin_...) or JWT tokens (Stytch OAuth 2.1).

The MCP server can handle multiple concurrent requests, each with their own
authentication context from the Authorization header.

Usage:
    # In middleware (set the API key from header or JWT resolution)
    set_request_api_key("vrin_abc123...")

    # In tool handlers (get the API key)
    api_key = get_request_api_key()  # Returns key or None
    api_key = get_api_key()  # Returns key from context OR env var (fallback)
"""

import logging
import os
from contextvars import ContextVar
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Context variable for request-scoped API key
# This is thread-safe and async-safe - each request gets its own value
_request_api_key: ContextVar[Optional[str]] = ContextVar("request_api_key", default=None)

# Context variable for auth metadata (method, email, member_id)
# Used for logging/audit — tool handlers don't need this
_request_auth_info: ContextVar[Optional[dict[str, Any]]] = ContextVar(
    "request_auth_info", default=None
)


def set_request_api_key(api_key: Optional[str]) -> None:
    """Set the API key for the current request context.

    Called by middleware after extracting from Authorization header
    or resolving from JWT.

    Args:
        api_key: The API key from the request, or None if not provided
    """
    _request_api_key.set(api_key)


def get_request_api_key() -> Optional[str]:
    """Get the API key from the current request context.

    Returns:
        API key if set for this request, None otherwise
    """
    return _request_api_key.get()


def clear_request_api_key() -> None:
    """Clear the API key from the current request context.

    Called by middleware after request completes (cleanup).
    """
    _request_api_key.set(None)


def set_auth_info(info: Optional[dict[str, Any]]) -> None:
    """Set auth metadata for the current request (logging/audit only).

    Args:
        info: Dict with keys like 'method', 'email', 'member_id'
    """
    _request_auth_info.set(info)


def get_auth_info() -> Optional[dict[str, Any]]:
    """Get auth metadata for the current request.

    Returns:
        Auth info dict or None
    """
    return _request_auth_info.get()


def clear_auth_info() -> None:
    """Clear auth metadata after request completes."""
    _request_auth_info.set(None)


def get_api_key() -> Optional[str]:
    """Get API key from request context, falling back to environment variable.

    Priority:
    1. Request context (from Authorization header or JWT) - for remote MCP
    2. VRIN_API_KEY environment variable - for local MCP

    Returns:
        API key string, or None if not available from either source
    """
    # First try request context (remote MCP with per-request auth)
    api_key = get_request_api_key()
    if api_key:
        return api_key

    # Fall back to environment variable (local MCP)
    return os.environ.get("VRIN_API_KEY")


def extract_bearer_token(authorization_header: Optional[str]) -> Optional[str]:
    """Extract the token from a Bearer authorization header.

    Args:
        authorization_header: The full Authorization header value
            e.g., "Bearer vrin_abc123..." or "Bearer eyJ..."

    Returns:
        The token part (without "Bearer " prefix), or None if invalid
    """
    if not authorization_header:
        return None

    # Handle "Bearer <token>" format
    if authorization_header.startswith("Bearer "):
        return authorization_header[7:].strip()

    # Also accept just the token directly (for flexibility)
    if authorization_header.startswith("vrin_"):
        return authorization_header.strip()

    return None


def is_jwt(token: str) -> bool:
    """Check if a token looks like a JWT (header.payload.signature).

    Simple heuristic: starts with 'ey' and has exactly 2 dots.

    Args:
        token: Raw token string

    Returns:
        True if token appears to be a JWT
    """
    return token.startswith("ey") and token.count(".") == 2
