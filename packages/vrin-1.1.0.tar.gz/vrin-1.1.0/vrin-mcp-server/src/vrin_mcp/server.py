"""VRIN MCP Server - Enterprise Hybrid RAG for AI Agents.

This module implements the main MCP server using FastMCP. It exposes VRIN's
Hybrid RAG capabilities to any MCP-compatible AI agent including Claude Desktop,
ChatGPT, OpenClaw, and custom agents.

Example:
    # Run with STDIO transport (for Claude Desktop)
    $ VRIN_API_KEY=vrin_xxx python -m vrin_mcp.server

    # Or use the entry point
    $ VRIN_API_KEY=vrin_xxx vrin-mcp
"""

import json
import logging
import os
import sys
import uuid
from datetime import datetime, timezone
from typing import Any

import boto3
from mcp.server.fastmcp import FastMCP

from vrin_mcp.auth.api_key import AuthError, get_api_key_from_env, get_api_key
from vrin_mcp.client.vrin_api import VRINClient
from vrin_mcp.job_store import create_job, get_job, hash_api_key

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,  # MCP uses stderr for logs
)
logger = logging.getLogger(__name__)

# Initialize FastMCP server
# Note: FastMCP uses 'instructions' for server description, not 'description'
mcp = FastMCP(
    name="vrin-knowledge",
    instructions=(
        "VRIN Hybrid RAG knowledge base for AI agents. "
        "Query enterprise knowledge graphs with natural language. "
        "Use vrin_query_async to start queries — it returns instantly "
        "with a job_id. Then call vrin_check_job to poll for results. "
        "Keep calling vrin_check_job until status is 'completed' or 'failed'. "
        "Do NOT stop polling or ask the user — VRIN queries take 10-60 seconds."
    ),
)


# =============================================================================
# MCP Tools
# =============================================================================


@mcp.tool()
async def vrin_query_async(
    query: str,
    mode: str = "context",
    depth: str = "basic",
    include_sources: bool = True,
) -> dict[str, Any]:
    """Start a VRIN knowledge base query. Returns immediately with a job_id.

    After calling this, call vrin_check_job with the returned job_id.
    vrin_check_job blocks for up to 55 seconds polling internally,
    so you typically need only 1-2 calls total. Do NOT stop polling
    or ask the user — just keep calling vrin_check_job silently until
    status is "completed" or "failed", then present the answer.

    Args:
        query: Natural language question to answer.
            Examples: "What is ACME's revenue?", "Compare risk factors across companies"
        mode: 'context' (recommended — returns structured facts for you to synthesize),
            'chat', 'expert', 'brainstorm', 'raw_facts'. Default: 'context'
        depth: Retrieval depth — 'basic' (fast), 'thinking' (cross-doc analysis),
            'research' (exhaustive). Only used when mode='context'. Default: 'basic'
        include_sources: Include source document references. Default: True

    Returns:
        job_id: Unique ID to poll with vrin_check_job
        status: Always "working" on success
    """
    try:
        api_key = get_api_key()
    except AuthError as e:
        return {"success": False, "error": str(e)}

    job_id = str(uuid.uuid4())
    params = {
        "mode": mode,
        "depth": depth,
        "include_sources": include_sources,
    }

    logger.info(f"vrin_query_async: creating job {job_id} for: {query[:80]}...")

    try:
        # Write job record to DynamoDB
        create_job(job_id, api_key, query, params)

        # Invoke worker Lambda asynchronously
        worker_name = os.environ.get("VRIN_WORKER_LAMBDA", "vrin-mcp-job-worker")
        region = os.environ.get("AWS_REGION", "us-east-1")
        lambda_client = boto3.client("lambda", region_name=region)
        lambda_client.invoke(
            FunctionName=worker_name,
            InvocationType="Event",  # Async — returns immediately
            Payload=json.dumps({
                "job_id": job_id,
                "api_key": api_key,
                "query": query,
                "params": params,
            }),
        )

        return {
            "success": True,
            "job_id": job_id,
            "status": "working",
        }
    except Exception as e:
        logger.error(f"vrin_query_async error: {type(e).__name__}: {e}")
        return {"success": False, "error": f"Failed to start job: {e}"}


@mcp.tool()
async def vrin_check_job(
    job_id: str,
) -> dict[str, Any]:
    """Wait for a VRIN query to complete and return the result.

    This tool polls internally for up to 55 seconds. Most VRIN queries
    complete within this window, so you typically need only 1-2 calls.

    IMPORTANT: If status is "working", you MUST call this tool again.
    The query IS still running and WILL complete. Do NOT stop polling
    or ask the user — just call again silently. Queries take 30-120
    seconds total, meaning at most 2-3 calls to this tool.

    When status is "completed", use the result to answer the user.

    Args:
        job_id: The job ID returned by vrin_query_async.

    Returns:
        If completed: { status: "completed", result: { context, facts_count, ... } }
        If still working: { status: "working", progress, elapsed_seconds }
        If failed: { status: "failed", error: "..." }
    """
    import asyncio

    try:
        api_key = get_api_key()
    except AuthError as e:
        return {"success": False, "error": str(e)}

    logger.info(f"vrin_check_job: long-polling {job_id}")

    # Long-poll: check every 5 seconds for up to 55 seconds.
    # This keeps the tool call blocking so the agent makes fewer calls.
    # Most queries complete within 30-90s, so 1-2 calls suffice.
    latest_progress = ""
    for _ in range(11):
        job = get_job(job_id, api_key)
        if not job:
            return {
                "success": False,
                "job_id": job_id,
                "status": "not_found",
                "error": "Job not found. It may have expired (jobs expire after 1 hour).",
            }

        status = job.get("status", "unknown")

        if status == "completed":
            result_json = job.get("result_json", "{}")
            try:
                result = json.loads(result_json)
            except (json.JSONDecodeError, TypeError):
                result = {}
            elapsed = _calc_elapsed(job)
            logger.info(f"vrin_check_job: job {job_id} completed in {elapsed}s")
            return {
                "success": True,
                "job_id": job_id,
                "status": "completed",
                "elapsed_seconds": elapsed,
                "result": result,
            }
        elif status == "failed":
            elapsed = _calc_elapsed(job)
            return {
                "success": False,
                "job_id": job_id,
                "status": "failed",
                "elapsed_seconds": elapsed,
                "error": job.get("error_message", "Unknown error"),
            }

        # Track latest progress for the final response
        progress_label = job.get("progress_label", "")
        if progress_label:
            progress_step = job.get("progress_step", 0)
            progress_total = job.get("progress_total", 0)
            latest_progress = (
                f"Step {progress_step}/{progress_total}: {progress_label}"
            )

        await asyncio.sleep(5)

    # After 55 seconds, return working status with latest progress
    elapsed = _calc_elapsed(job)
    logger.info(f"vrin_check_job: job {job_id} still working after long-poll ({elapsed}s)")

    result = {
        "success": True,
        "job_id": job_id,
        "status": "working",
        "elapsed_seconds": elapsed,
        "message": (
            f"VRIN query is still processing ({elapsed}s elapsed). "
            f"Call vrin_check_job again — the query will complete soon."
        ),
    }
    if latest_progress:
        result["progress"] = latest_progress

    return result


def _calc_elapsed(job: dict) -> int:
    """Calculate elapsed seconds from job created_at."""
    created_at = job.get("created_at", "")
    if created_at:
        try:
            created = datetime.fromisoformat(created_at)
            return int((datetime.now(timezone.utc) - created).total_seconds())
        except (ValueError, TypeError):
            pass
    return 0


# =============================================================================
# MCP Resources
# =============================================================================


@mcp.resource("vrin://stats")
async def get_statistics() -> str:
    """Get knowledge graph statistics.

    Returns high-level statistics about the VRIN knowledge graph including
    entity counts, fact counts, and document counts.
    """
    try:
        api_key = get_api_key()
    except AuthError as e:
        return f"Error: {e}"

    logger.info("get_statistics resource")

    try:
        async with VRINClient(api_key) as client:
            response = await client.get_stats()

            if not response.success:
                return f"Error: {response.error}"

            return (
                f"VRIN Knowledge Graph Statistics\n"
                f"================================\n"
                f"Total Entities: {response.total_entities}\n"
                f"Total Facts: {response.total_facts}\n"
                f"Total Documents: {response.total_documents}\n"
            )
    except Exception as e:
        logger.error(f"get_statistics error: {e}")
        return f"Error: {e}"


@mcp.resource("vrin://config")
async def get_config() -> str:
    """Get current VRIN MCP server configuration.

    Returns the server configuration including API key type (standard/enterprise)
    and endpoint URLs.
    """
    try:
        api_key = get_api_key()
        is_enterprise = api_key.startswith("vrin_ent_")

        return (
            f"VRIN MCP Server Configuration\n"
            f"==============================\n"
            f"Server Version: 1.0.0\n"
            f"API Key Type: {'Enterprise' if is_enterprise else 'Standard'}\n"
            f"Data Sovereignty: {'Enabled (customer infrastructure)' if is_enterprise else 'Shared infrastructure'}\n"
        )
    except AuthError as e:
        return f"Error: {e}"


# =============================================================================
# Entry Point
# =============================================================================


def main():
    """Run the VRIN MCP Server with STDIO transport.

    This is the main entry point for Claude Desktop and other local MCP clients.
    """
    # Validate API key on startup
    try:
        api_key = get_api_key()
        is_enterprise = api_key.startswith("vrin_ent_")
        logger.info(
            f"Starting VRIN MCP Server v1.0.0 "
            f"(enterprise={is_enterprise})"
        )
    except AuthError as e:
        logger.error(f"Configuration error: {e}")
        print(f"Error: {e}", file=sys.stderr)
        print(
            "Set VRIN_API_KEY environment variable to your VRIN API key.",
            file=sys.stderr,
        )
        print("Get your API key at https://vrin.cloud", file=sys.stderr)
        sys.exit(1)

    # Run with STDIO transport
    mcp.run(transport="stdio")


if __name__ == "__main__":
    main()
