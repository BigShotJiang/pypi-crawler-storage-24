"""Tests for VRIN MCP authentication."""

import pytest

from vrin_mcp.auth.api_key import (
    AuthError,
    validate_key_format,
)


class TestKeyFormatValidation:
    """Tests for API key format validation."""

    def test_valid_standard_key(self):
        """Test valid standard API key format."""
        assert validate_key_format("vrin_1234567890abcdef") is True
        assert validate_key_format("vrin_abcdef1234567890abcdef") is True

    def test_valid_enterprise_key(self):
        """Test valid enterprise API key format."""
        assert validate_key_format("vrin_ent_1234567890abcdef") is True
        assert validate_key_format("vrin_ent_abcdef1234567890abcdef") is True

    def test_invalid_key_no_prefix(self):
        """Test key without vrin_ prefix."""
        assert validate_key_format("1234567890abcdef") is False
        assert validate_key_format("api_1234567890abcdef") is False

    def test_invalid_key_wrong_prefix(self):
        """Test key with wrong prefix."""
        assert validate_key_format("openai_1234567890abcdef") is False
        assert validate_key_format("sk_1234567890abcdef") is False

    def test_invalid_key_too_short(self):
        """Test key that's too short."""
        assert validate_key_format("vrin_abc") is False
        assert validate_key_format("vrin_ent_abc") is False

    def test_invalid_key_empty(self):
        """Test empty key."""
        assert validate_key_format("") is False
        assert validate_key_format(None) is False

    def test_invalid_key_non_hex(self):
        """Test key with non-hex characters."""
        assert validate_key_format("vrin_ghijklmnopqrstuv") is False


class TestAuthError:
    """Tests for AuthError exception."""

    def test_auth_error_message(self):
        """Test AuthError contains message."""
        error = AuthError("Test error message")
        assert str(error) == "Test error message"

    def test_auth_error_is_exception(self):
        """Test AuthError is an Exception."""
        assert issubclass(AuthError, Exception)

    def test_auth_error_can_be_raised(self):
        """Test AuthError can be raised and caught."""
        with pytest.raises(AuthError) as exc_info:
            raise AuthError("Missing API key")
        assert "Missing API key" in str(exc_info.value)
