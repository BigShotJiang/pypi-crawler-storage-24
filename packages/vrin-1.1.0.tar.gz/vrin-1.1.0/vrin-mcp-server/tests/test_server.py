"""Tests for VRIN MCP server."""

import os
import pytest
from unittest.mock import patch


class TestServerConfiguration:
    """Tests for server configuration."""

    def test_server_name(self):
        """Test server has correct name."""
        with patch.dict(os.environ, {"VRIN_API_KEY": "vrin_test1234567890ab"}):
            from vrin_mcp.server import mcp
            assert mcp.name == "vrin-knowledge"

    def test_server_has_instructions(self):
        """Test server has instructions set."""
        with patch.dict(os.environ, {"VRIN_API_KEY": "vrin_test1234567890ab"}):
            from vrin_mcp.server import mcp
            # FastMCP stores instructions for client context
            assert mcp.instructions is not None
            assert "VRIN" in mcp.instructions


class TestServerTools:
    """Tests for server tool registration."""

    def test_tools_registered(self):
        """Test all tools are registered."""
        with patch.dict(os.environ, {"VRIN_API_KEY": "vrin_test1234567890ab"}):
            from vrin_mcp.server import mcp

            # Get registered tool names
            # Note: Actual method depends on FastMCP implementation
            # This is a placeholder test structure
            assert mcp is not None


class TestConfigModule:
    """Tests for config module."""

    def test_config_loads_defaults(self):
        """Test config loads with default URLs."""
        import vrin_mcp.config as config_module
        config_module._config = None

        config = config_module.get_config()

        assert "lambda-url" in config.streaming_url
        assert "execute-api" in config.auth_url

    def test_config_loads_env_overrides(self):
        """Test config picks up environment variable overrides."""
        with patch.dict(os.environ, {
            "VRIN_STREAMING_URL": "https://custom-streaming.example.com",
            "VRIN_AUTH_URL": "https://custom-auth.example.com",
        }):
            import vrin_mcp.config as config_module
            config_module._config = None

            config = config_module.get_config()

            assert config.streaming_url == "https://custom-streaming.example.com"
            assert config.auth_url == "https://custom-auth.example.com"

    def test_config_stytch_settings(self):
        """Test config loads Stytch OAuth settings."""
        with patch.dict(os.environ, {
            "STYTCH_PROJECT_ID": "project-test-123",
            "STYTCH_JWKS_URL": "https://test.stytch.com/v1/sessions/jwks/project-test-123",
        }):
            import vrin_mcp.config as config_module
            config_module._config = None

            config = config_module.get_config()

            assert config.stytch_project_id == "project-test-123"
            assert "stytch.com" in config.stytch_jwks_url

    def test_config_default_timeouts(self):
        """Test config has sensible default timeouts."""
        import vrin_mcp.config as config_module
        config_module._config = None

        config = config_module.get_config()

        assert config.query_timeout == 120.0
        assert config.search_timeout == 30.0
        assert config.auth_timeout == 10.0
