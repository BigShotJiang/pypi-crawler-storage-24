"""Tests for VRIN MCP tools (inline in server.py)."""

import os
import pytest
from unittest.mock import AsyncMock, patch

from vrin_mcp.client.vrin_api import (
    QueryResponse,
    SearchResponse,
    FactsResponse,
    EntitySearchResult,
    Fact,
)


class TestVrinQuery:
    """Tests for vrin_query tool."""

    @pytest.mark.asyncio
    async def test_query_missing_api_key(self):
        """Test query returns error without API key."""
        with patch.dict(os.environ, {}, clear=True):
            from vrin_mcp.auth.context import set_request_api_key, clear_request_api_key

            set_request_api_key(None)
            try:
                from vrin_mcp.server import vrin_query

                result = await vrin_query("Test query")
                assert result["success"] is False
                assert "required" in result["error"].lower() or "API key" in result["error"]
            finally:
                clear_request_api_key()

    @pytest.mark.asyncio
    async def test_query_success(self):
        """Test successful query."""
        mock_response = QueryResponse(
            success=True,
            summary="ACME Corporation has revenue of $312.7M",
            answer="ACME Corporation has revenue of $312.7M",
            sources=[{"document": "annual_report.pdf", "relevance": 0.95}],
            facts_used=12,
            reasoning_steps=["Found entity ACME", "Retrieved 12 facts"],
        )

        with patch.dict(os.environ, {"VRIN_API_KEY": "vrin_test1234567890ab"}):
            with patch("vrin_mcp.server.VRINClient") as MockClient:
                mock_instance = AsyncMock()
                mock_instance.query.return_value = mock_response
                mock_instance.__aenter__.return_value = mock_instance
                mock_instance.__aexit__.return_value = None
                MockClient.return_value = mock_instance

                from vrin_mcp.server import vrin_query

                result = await vrin_query("What is ACME's revenue?")

                assert result["success"] is True
                assert "312.7M" in result["summary"]
                assert result["facts_used"] == 12


class TestVrinSearchEntities:
    """Tests for vrin_search_entities tool."""

    @pytest.mark.asyncio
    async def test_search_success(self):
        """Test successful entity search."""
        mock_response = SearchResponse(
            success=True,
            entities=[
                EntitySearchResult(
                    name="ACME Corporation",
                    type="organization",
                    fact_count=106,
                    relevance_score=0.95,
                ),
                EntitySearchResult(
                    name="ACME Integration Hub",
                    type="product",
                    fact_count=18,
                    relevance_score=0.82,
                ),
            ],
            total=2,
        )

        with patch.dict(os.environ, {"VRIN_API_KEY": "vrin_test1234567890ab"}):
            with patch("vrin_mcp.server.VRINClient") as MockClient:
                mock_instance = AsyncMock()
                mock_instance.search_entities.return_value = mock_response
                mock_instance.__aenter__.return_value = mock_instance
                mock_instance.__aexit__.return_value = None
                MockClient.return_value = mock_instance

                from vrin_mcp.server import vrin_search_entities

                result = await vrin_search_entities("ACME")

                assert result["success"] is True
                assert result["total"] == 2
                assert result["entities"][0]["name"] == "ACME Corporation"

    @pytest.mark.asyncio
    async def test_search_limit_clamped(self):
        """Test search limit is clamped to valid range."""
        mock_response = SearchResponse(success=True, entities=[], total=0)

        with patch.dict(os.environ, {"VRIN_API_KEY": "vrin_test1234567890ab"}):
            with patch("vrin_mcp.server.VRINClient") as MockClient:
                mock_instance = AsyncMock()
                mock_instance.search_entities.return_value = mock_response
                mock_instance.__aenter__.return_value = mock_instance
                mock_instance.__aexit__.return_value = None
                MockClient.return_value = mock_instance

                from vrin_mcp.server import vrin_search_entities

                # Test with limit > 50
                await vrin_search_entities("test", limit=100)
                mock_instance.search_entities.assert_called_with(
                    entity_name="test",
                    limit=50,  # Should be clamped to 50
                )


class TestVrinGetFacts:
    """Tests for vrin_get_facts tool."""

    @pytest.mark.asyncio
    async def test_get_facts_success(self):
        """Test successful fact retrieval."""
        mock_response = FactsResponse(
            success=True,
            entity="ACME Corporation",
            facts=[
                Fact(
                    subject="ACME Corporation",
                    predicate="has revenue",
                    object="$312.7M",
                    confidence=0.95,
                    source_document="annual_report.pdf",
                ),
                Fact(
                    subject="ACME Corporation",
                    predicate="has CEO",
                    object="Sarah Martinez",
                    confidence=0.98,
                ),
            ],
            total=2,
        )

        with patch.dict(os.environ, {"VRIN_API_KEY": "vrin_test1234567890ab"}):
            with patch("vrin_mcp.server.VRINClient") as MockClient:
                mock_instance = AsyncMock()
                mock_instance.get_facts.return_value = mock_response
                mock_instance.__aenter__.return_value = mock_instance
                mock_instance.__aexit__.return_value = None
                MockClient.return_value = mock_instance

                from vrin_mcp.server import vrin_get_facts

                result = await vrin_get_facts("ACME Corporation")

                assert result["success"] is True
                assert result["entity"] == "ACME Corporation"
                assert result["total"] == 2
                assert result["facts"][0]["predicate"] == "has revenue"

    @pytest.mark.asyncio
    async def test_get_facts_with_temporal_filter(self):
        """Test fact retrieval with temporal filter."""
        mock_response = FactsResponse(
            success=True,
            entity="ACME Corporation",
            facts=[],
            total=0,
        )

        with patch.dict(os.environ, {"VRIN_API_KEY": "vrin_test1234567890ab"}):
            with patch("vrin_mcp.server.VRINClient") as MockClient:
                mock_instance = AsyncMock()
                mock_instance.get_facts.return_value = mock_response
                mock_instance.__aenter__.return_value = mock_instance
                mock_instance.__aexit__.return_value = None
                MockClient.return_value = mock_instance

                from vrin_mcp.server import vrin_get_facts

                await vrin_get_facts("ACME Corporation", temporal_filter="2023")

                mock_instance.get_facts.assert_called_with(
                    entity="ACME Corporation",
                    temporal_filter="2023",
                )
