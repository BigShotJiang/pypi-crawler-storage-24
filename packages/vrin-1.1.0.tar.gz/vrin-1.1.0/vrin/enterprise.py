"""
VRIN Enterprise Client — thin subclass of VRINClient for enterprise API key users.

Enterprise routing is **server-side**: the ``vrin_ent_`` API key prefix triggers
DynamoDB config lookup → STS AssumeRole → customer infrastructure. This client
simply validates the key prefix and adds enterprise-portal helper methods.
"""

import logging
from typing import Any, Dict, List, Optional

from . import _endpoints as ep
from .client import VRINClient

logger = logging.getLogger(__name__)


class VRINEnterpriseClient(VRINClient):
    """Enterprise VRIN client (``vrin_ent_*`` API keys).

    Inherits all standard ``VRINClient`` methods — query, insert, upload,
    conversations, etc. — and adds enterprise portal management.

    Example::

        client = VRINEnterpriseClient(api_key="vrin_ent_abc123")

        # All standard methods work exactly the same
        result = client.query("What is our Q4 revenue?")

        # Enterprise portal methods
        org = client.get_organization()
        config = client.get_configuration()
    """

    def __init__(self, api_key: str, **kwargs: Any) -> None:
        if not api_key.startswith("vrin_ent_"):
            raise ValueError(
                f"Enterprise API key must start with 'vrin_ent_', "
                f"got '{api_key[:10]}...'"
            )
        super().__init__(api_key, **kwargs)

    # -----------------------------------------------------------------------
    # Enterprise Portal (ENTERPRISE_PORTAL_URL)
    # -----------------------------------------------------------------------

    def get_organization(self) -> Dict[str, Any]:
        """Get organization details."""
        resp = self._request(
            "GET", ep.enterprise_organization_url(), timeout=10.0
        )
        return resp.json()

    def list_users(self) -> Dict[str, Any]:
        """List users in the enterprise organization."""
        resp = self._request(
            "GET", ep.enterprise_users_url(), timeout=10.0
        )
        return resp.json()

    def list_enterprise_api_keys(self) -> Dict[str, Any]:
        """List enterprise API keys."""
        resp = self._request(
            "GET", ep.enterprise_api_keys_url(), timeout=10.0
        )
        return resp.json()

    def create_enterprise_api_key(self, **kwargs: Any) -> Dict[str, Any]:
        """Create a new enterprise API key."""
        resp = self._request(
            "POST",
            ep.enterprise_api_keys_url(),
            json_body=kwargs or {},
            timeout=10.0,
        )
        return resp.json()

    def get_configuration(self) -> Dict[str, Any]:
        """Get enterprise infrastructure configuration."""
        resp = self._request(
            "GET", ep.enterprise_configuration_url(), timeout=10.0
        )
        return resp.json()

    def save_configuration(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Save enterprise infrastructure configuration."""
        resp = self._request(
            "POST",
            ep.enterprise_configuration_url(),
            json_body=config,
            timeout=30.0,
        )
        return resp.json()

    def validate_connectivity(self) -> Dict[str, Any]:
        """Validate connectivity to enterprise infrastructure (Neptune, OpenSearch, S3, Bedrock)."""
        resp = self._request(
            "POST",
            ep.enterprise_validate_connectivity_url(),
            json_body={},
            timeout=60.0,
        )
        return resp.json()

    def __repr__(self) -> str:
        key_preview = self.api_key[:16] + "..." if len(self.api_key) > 16 else self.api_key
        return f"VRINEnterpriseClient(api_key='{key_preview}')"
