"""
SSE (Server-Sent Events) streaming support for VRIN SDK.

Provides true streaming iteration over query responses — tokens are
yielded as they arrive rather than buffered into a single response.
"""

import json
import logging
from dataclasses import dataclass, field
from typing import Any, Dict, Iterator, List, Optional

from .exceptions import StreamingError

logger = logging.getLogger(__name__)


@dataclass
class SSEEvent:
    """A single parsed SSE event."""

    type: str
    data: Dict[str, Any] = field(default_factory=dict)


def iter_sse_events(response: Any) -> Iterator[SSEEvent]:
    """Yield ``SSEEvent`` objects from a streaming ``requests.Response``.

    Uses ``response.iter_lines()`` so events are delivered as they arrive.
    """
    for raw_line in response.iter_lines(decode_unicode=True):
        if not raw_line:
            continue
        line = raw_line.strip()
        if not line.startswith("data:"):
            continue
        json_str = line[5:].strip()
        if not json_str:
            continue
        try:
            payload = json.loads(json_str)
            yield SSEEvent(
                type=payload.get("type", ""),
                data=payload.get("data", {}),
            )
        except json.JSONDecodeError:
            logger.debug(f"Skipping non-JSON SSE line: {line[:120]}")


class StreamingResponse:
    """Wraps a streaming ``requests.Response`` and yields content deltas.

    Usage::

        resp = client.query("hello", stream=True)
        for token in resp:
            print(token, end="", flush=True)

        # After iteration completes, metadata is available:
        print(resp.full_text)
        print(resp.sources)
    """

    def __init__(self, response: Any) -> None:
        self._response = response
        self._consumed = False

        # Accumulated state (populated during iteration)
        self._full_text: str = ""
        self._session_id: Optional[str] = None
        self._metadata: Dict[str, Any] = {}
        self._sources: List[Dict[str, Any]] = []
        self._thinking_steps: List[str] = []
        self._entities: List[str] = []
        self._total_facts: int = 0
        self._total_chunks: int = 0
        self._model: Optional[str] = None
        self._search_time: Optional[str] = None
        self._error: Optional[str] = None
        self._insufficient_coverage: bool = False

    # -- Iteration -----------------------------------------------------------

    def __iter__(self) -> Iterator[str]:
        if self._consumed:
            return
        self._consumed = True
        try:
            for event in iter_sse_events(self._response):
                delta = self._handle_event(event)
                if delta:
                    yield delta
        finally:
            self._close()

    def _handle_event(self, event: SSEEvent) -> Optional[str]:
        """Process a single SSE event; return content delta or ``None``."""
        t = event.type
        d = event.data

        if t == "content":
            delta = d.get("delta", "")
            self._full_text += delta
            return delta

        if t == "metadata":
            self._metadata = d
            self._session_id = d.get("session_id")
            self._total_facts = d.get("total_facts", 0)
            self._total_chunks = d.get("total_chunks", 0)
            self._entities = d.get("entities", [])
            self._model = d.get("model")
            self._search_time = d.get("search_time")
            return None

        if t == "reasoning":
            steps = d.get("chains", d.get("steps", []))
            if isinstance(steps, list):
                self._thinking_steps.extend(steps)
            return None

        if t == "sources":
            self._sources = d.get("sources", [])
            return None

        if t == "done":
            if d.get("error"):
                self._error = d["error"]
            if d.get("insufficient_coverage"):
                self._insufficient_coverage = True
            # Some done events carry final text
            text = d.get("text", d.get("delta", ""))
            if text:
                self._full_text += text
                return text
            return None

        if t == "error":
            self._error = d.get("message", "Unknown streaming error")
            raise StreamingError(self._error)

        # Unknown event type — log but don't crash
        logger.debug(f"Unhandled SSE event type: {t}")
        return None

    # -- Properties ----------------------------------------------------------

    @property
    def session_id(self) -> Optional[str]:
        return self._session_id

    @property
    def metadata(self) -> Dict[str, Any]:
        return self._metadata

    @property
    def sources(self) -> List[Dict[str, Any]]:
        return self._sources

    @property
    def thinking_steps(self) -> List[str]:
        return self._thinking_steps

    @property
    def entities(self) -> List[str]:
        return self._entities

    @property
    def total_facts(self) -> int:
        return self._total_facts

    @property
    def total_chunks(self) -> int:
        return self._total_chunks

    @property
    def model(self) -> Optional[str]:
        return self._model

    @property
    def search_time(self) -> Optional[str]:
        return self._search_time

    @property
    def full_text(self) -> str:
        return self._full_text

    @property
    def error(self) -> Optional[str]:
        return self._error

    @property
    def insufficient_coverage(self) -> bool:
        return self._insufficient_coverage

    # -- Helpers -------------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Convert the completed stream into a dict matching non-streaming format."""
        return {
            "success": self._error is None,
            "summary": self._full_text,
            "session_id": self._session_id,
            "entities": self._entities,
            "total_facts": self._total_facts,
            "total_chunks": self._total_chunks,
            "model": self._model,
            "search_time": self._search_time,
            "sources": self._sources,
            "thinking_steps": self._thinking_steps,
            "insufficient_coverage": self._insufficient_coverage,
            "error": self._error,
        }

    # -- Cleanup -------------------------------------------------------------

    def _close(self) -> None:
        try:
            self._response.close()
        except Exception:
            pass

    def __enter__(self) -> "StreamingResponse":
        return self

    def __exit__(self, *exc: Any) -> None:
        self._close()

    def __del__(self) -> None:
        self._close()


# ---------------------------------------------------------------------------
# Fallback parser for complete SSE text (non-streaming path)
# ---------------------------------------------------------------------------

def parse_complete_sse(text: str) -> Dict[str, Any]:
    """Parse a complete SSE text blob into a result dict.

    Used when the backend returns SSE-formatted text in a non-streaming
    response (e.g. content-type mismatch).
    """
    result: Dict[str, Any] = {
        "success": True,
        "summary": "",
        "session_id": None,
        "metadata": {},
    }

    for line in text.strip().split("\n"):
        line = line.strip()
        if not line.startswith("data:"):
            continue
        json_str = line[5:].strip()
        if not json_str:
            continue
        try:
            payload = json.loads(json_str)
        except json.JSONDecodeError:
            continue

        event_type = payload.get("type", "")
        data = payload.get("data", {})

        if event_type == "metadata":
            result["metadata"] = data
            result["session_id"] = data.get("session_id")
            result["total_facts"] = data.get("total_facts", 0)
            result["total_chunks"] = data.get("total_chunks", 0)
        elif event_type == "content":
            result["summary"] += data.get("delta", "")
        elif event_type == "error":
            result["success"] = False
            result["error"] = data.get("message", "Unknown error")
        elif event_type == "done":
            if data.get("error"):
                result["success"] = False
                result["error"] = data["error"]
            if data.get("insufficient_coverage"):
                result["insufficient_coverage"] = True

    return result
