"""
Test suite for PermissionManager class

This validates permission and authorization operations including:
- Policy CRUD operations
- Four-layer security checks
- Clearance validation
- Resource access control

Week 2, Milestone 1.3
"""

import sys
import time
sys.path.insert(0, '/Users/Vedant/Documents/vrin-engine')

from lambda_deployment.enterprise_permission_management import PermissionManager
from lambda_deployment.enterprise_team_management import TeamManager
from lambda_deployment.constants import CLEARANCE_LEVELS, SENSITIVITY_LEVELS
import boto3


def setup_test_environment():
    """Setup test organization, team, and users."""
    org_id = 'org-test-permissions'

    # Create test team
    team_manager = TeamManager()
    team_result = team_manager.create_team(
        organization_id=org_id,
        name=f'Test Security Team {time.time()}',
        team_type='department',
        created_by='user-admin',
        description='Team for permission testing'
    )

    team_id = team_result['team_id']

    # Create test users with different clearance levels
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    users_table = dynamodb.Table('vrin-enterprise-users')

    # User 1: Junior member (standard clearance)
    junior_user = {
        'user_id': 'user-junior',
        'organization_id': org_id,
        'email': 'junior@test.com',
        'first_name': 'Junior',
        'last_name': 'Member',
        'role': 'member',
        'status': 'active',
        'created_at': int(time.time()),
        'team_memberships': [{
            'team_id': team_id,
            'team_name': 'Test Security Team',
            'role': 'member',
            'clearance_level': 'standard',
            'departments': ['engineering'],
            'job_title': 'Junior Engineer',
            'employment_type': 'full_time',
            'joined_at': int(time.time()),
            'added_by': 'user-admin',
            'permissions': ['read', 'write']
        }],
        'current_team_id': team_id,
        'global_clearance_level': 'standard'
    }

    # User 2: Senior member (senior clearance)
    senior_user = {
        'user_id': 'user-senior',
        'organization_id': org_id,
        'email': 'senior@test.com',
        'first_name': 'Senior',
        'last_name': 'Engineer',
        'role': 'member',
        'status': 'active',
        'created_at': int(time.time()),
        'team_memberships': [{
            'team_id': team_id,
            'team_name': 'Test Security Team',
            'role': 'team_admin',
            'clearance_level': 'senior',
            'departments': ['engineering', 'security'],
            'job_title': 'Senior Engineer',
            'employment_type': 'full_time',
            'joined_at': int(time.time()),
            'added_by': 'user-admin',
            'permissions': ['read', 'write', 'delete']
        }],
        'current_team_id': team_id,
        'global_clearance_level': 'senior'
    }

    # User 3: Executive (executive clearance)
    exec_user = {
        'user_id': 'user-executive',
        'organization_id': org_id,
        'email': 'exec@test.com',
        'first_name': 'Executive',
        'last_name': 'Officer',
        'role': 'org_admin',
        'status': 'active',
        'created_at': int(time.time()),
        'team_memberships': [{
            'team_id': team_id,
            'team_name': 'Test Security Team',
            'role': 'org_admin',
            'clearance_level': 'executive',
            'departments': ['executive', 'engineering'],
            'job_title': 'CTO',
            'employment_type': 'full_time',
            'joined_at': int(time.time()),
            'added_by': 'user-admin',
            'permissions': ['read', 'write', 'delete', 'manage']
        }],
        'current_team_id': team_id,
        'global_clearance_level': 'executive'
    }

    users_table.put_item(Item=junior_user)
    users_table.put_item(Item=senior_user)
    users_table.put_item(Item=exec_user)

    print(f"  ✅ Test environment created")
    print(f"     Organization: {org_id}")
    print(f"     Team: {team_id}")
    print(f"     Users: junior (standard), senior (senior), executive (executive)")

    return {
        'org_id': org_id,
        'team_id': team_id,
        'users': {
            'junior': 'user-junior',
            'senior': 'user-senior',
            'executive': 'user-executive'
        }
    }


def test_create_policy():
    """Test policy creation."""
    print("\n🧪 Testing policy creation...")

    manager = PermissionManager()
    env = setup_test_environment()

    result = manager.create_policy(
        organization_id=env['org_id'],
        policy_name='Engineering Read-Write Policy',
        policy_type='team_default',
        created_by='user-admin',
        description='Standard policy for engineering team members',
        rules=[
            {'action': 'read', 'resource_types': ['*'], 'allowed': True},
            {'action': 'write', 'resource_types': ['document', 'code'], 'allowed': True}
        ],
        applies_to={'teams': [env['team_id']]}
    )

    assert result['success'], f"Policy creation failed: {result.get('error')}"
    assert 'policy_id' in result
    assert result['policy']['policy_name'] == 'Engineering Read-Write Policy'
    assert len(result['policy']['rules']) == 2

    print(f"  ✅ Policy created: {result['policy_id']}")
    print(f"     Name: {result['policy']['policy_name']}")
    print(f"     Type: {result['policy']['policy_type']}")
    print(f"     Rules: {len(result['policy']['rules'])}")

    return result['policy_id'], env


def test_get_policy(policy_id, env):
    """Test retrieving a policy."""
    print(f"\n🧪 Testing policy retrieval...")

    manager = PermissionManager()

    policy = manager.get_policy(policy_id, env['org_id'])

    assert policy is not None, "Policy not found"
    assert policy['policy_id'] == policy_id
    assert policy['policy_name'] == 'Engineering Read-Write Policy'

    print(f"  ✅ Policy retrieved: {policy['policy_id']}")
    print(f"     Name: {policy['policy_name']}")


def test_list_policies(env):
    """Test listing policies."""
    print("\n🧪 Testing policy listing...")

    manager = PermissionManager()

    policies = manager.list_policies(env['org_id'])

    assert len(policies) > 0, "No policies found"
    print(f"  ✅ Found {len(policies)} policy/policies")

    # Test filtering by type
    team_policies = manager.list_policies(env['org_id'], policy_type='team_default')
    print(f"  ✅ Found {len(team_policies)} team_default policy/policies")


def test_update_policy(policy_id, env):
    """Test updating a policy."""
    print(f"\n🧪 Testing policy update...")

    manager = PermissionManager()

    result = manager.update_policy(
        policy_id=policy_id,
        organization_id=env['org_id'],
        updates={
            'description': 'Updated policy description',
            'rules': [
                {'action': 'read', 'resource_types': ['*'], 'allowed': True},
                {'action': 'write', 'resource_types': ['*'], 'allowed': True},
                {'action': 'delete', 'resource_types': ['document'], 'allowed': True}
            ]
        },
        updated_by='user-admin'
    )

    assert result['success'], f"Policy update failed: {result.get('error')}"
    assert result['policy']['description'] == 'Updated policy description'
    assert len(result['policy']['rules']) == 3

    print("  ✅ Policy updated successfully")
    print(f"     New description: {result['policy']['description']}")
    print(f"     New rules count: {len(result['policy']['rules'])}")


def test_clearance_check(env):
    """Test clearance level checks."""
    print("\n🧪 Testing clearance checks...")

    manager = PermissionManager()

    # Test 1: Junior user accessing internal resource
    result = manager.check_clearance(
        user_id=env['users']['junior'],
        organization_id=env['org_id'],
        required_sensitivity='internal'
    )

    assert result['has_clearance'] == True, "Junior should access internal resources"
    assert result['user_clearance'] == 'standard'
    print(f"  ✅ Junior user can access 'internal' resources (clearance: {result['user_clearance']})")

    # Test 2: Junior user accessing confidential resource
    result = manager.check_clearance(
        user_id=env['users']['junior'],
        organization_id=env['org_id'],
        required_sensitivity='confidential'
    )

    assert result['has_clearance'] == False, "Junior should not access confidential resources"
    print(f"  ✅ Junior user CANNOT access 'confidential' resources (clearance gap: {result['clearance_gap']})")

    # Test 3: Senior user accessing confidential resource
    result = manager.check_clearance(
        user_id=env['users']['senior'],
        organization_id=env['org_id'],
        required_sensitivity='confidential'
    )

    assert result['has_clearance'] == True, "Senior should access confidential resources"
    assert result['user_clearance'] == 'senior'
    print(f"  ✅ Senior user can access 'confidential' resources (clearance: {result['user_clearance']})")

    # Test 4: Executive accessing executive resources
    result = manager.check_clearance(
        user_id=env['users']['executive'],
        organization_id=env['org_id'],
        required_sensitivity='executive'
    )

    assert result['has_clearance'] == True, "Executive should access executive resources"
    print(f"  ✅ Executive user can access 'executive' resources (clearance: {result['user_clearance']})")


def test_four_layer_security(env):
    """Test the four-layer security model."""
    print("\n🧪 Testing four-layer security model...")

    manager = PermissionManager()

    # Create test resource
    resource = {
        'resource_id': 'doc-test-001',
        'team_id': env['team_id'],
        'sensitivity_level': 'confidential',
        'need_to_know_departments': ['engineering', 'security']
    }

    # Test 1: Junior user (standard clearance) accessing confidential resource - SHOULD FAIL at Layer 2
    result = manager.can_user_access_resource(
        user_id=env['users']['junior'],
        organization_id=env['org_id'],
        resource=resource,
        action='read'
    )

    assert result['allowed'] == False, "Junior should not access confidential resource"
    assert 'clearance_level' in result['layer_results']
    assert result['layer_results']['clearance_level']['passed'] == False
    print(f"  ✅ Layer 2 (Clearance): Junior blocked from confidential resource")
    print(f"     Reason: {result['layer_results']['clearance_level']['reason']}")

    # Test 2: Senior user accessing confidential resource in engineering dept - SHOULD PASS
    result = manager.can_user_access_resource(
        user_id=env['users']['senior'],
        organization_id=env['org_id'],
        resource=resource,
        action='read'
    )

    assert result['allowed'] == True, "Senior in engineering should access confidential engineering resource"
    assert result['layer_results']['team_boundary']['passed'] == True
    assert result['layer_results']['clearance_level']['passed'] == True
    assert result['layer_results']['role_permissions']['passed'] == True
    assert result['layer_results']['need_to_know']['passed'] == True
    print(f"  ✅ All 4 Layers: Senior granted access to confidential resource")
    print(f"     Layer 1 (Team): ✅ {result['layer_results']['team_boundary']['passed']}")
    print(f"     Layer 2 (Clearance): ✅ {result['layer_results']['clearance_level']['passed']}")
    print(f"     Layer 3 (Role): ✅ {result['layer_results']['role_permissions']['passed']}")
    print(f"     Layer 4 (Need-to-Know): ✅ {result['layer_results']['need_to_know']['passed']}")

    # Test 3: Create resource requiring legal department - Senior should FAIL at Layer 4
    legal_resource = {
        'resource_id': 'doc-legal-001',
        'team_id': env['team_id'],
        'sensitivity_level': 'confidential',
        'need_to_know_departments': ['legal']  # Senior is only in engineering and security
    }

    result = manager.can_user_access_resource(
        user_id=env['users']['senior'],
        organization_id=env['org_id'],
        resource=legal_resource,
        action='read'
    )

    assert result['allowed'] == False, "Senior should not access legal-only resource"
    assert 'need_to_know' in result['layer_results']
    assert result['layer_results']['need_to_know']['passed'] == False
    print(f"  ✅ Layer 4 (Need-to-Know): Senior blocked from legal-only resource")
    print(f"     Reason: {result['layer_results']['need_to_know']['reason']}")

    # Test 4: Test delete action without permission - Junior should FAIL at Layer 3
    result = manager.can_user_access_resource(
        user_id=env['users']['junior'],
        organization_id=env['org_id'],
        resource={
            'resource_id': 'doc-public-001',
            'team_id': env['team_id'],
            'sensitivity_level': 'public'  # Junior can access public
        },
        action='delete'  # But junior doesn't have delete permission
    )

    assert result['allowed'] == False, "Junior should not have delete permission"
    assert 'role_permissions' in result['layer_results']
    assert result['layer_results']['role_permissions']['passed'] == False
    print(f"  ✅ Layer 3 (Permissions): Junior blocked from deleting (lacks permission)")
    print(f"     Reason: {result['layer_results']['role_permissions']['reason']}")


def test_get_user_permissions(env):
    """Test getting comprehensive user permissions."""
    print("\n🧪 Testing get user permissions...")

    manager = PermissionManager()

    # Get junior user permissions
    result = manager.get_user_permissions(
        user_id=env['users']['junior'],
        organization_id=env['org_id']
    )

    assert result['success'] == True
    assert result['permissions']['global_clearance_level'] == 'standard'
    assert result['permissions']['current_team'] is not None
    assert result['permissions']['current_team']['role'] == 'member'

    print(f"  ✅ Retrieved junior user permissions")
    print(f"     Global clearance: {result['permissions']['global_clearance_level']}")
    print(f"     Current team role: {result['permissions']['current_team']['role']}")
    print(f"     Permissions: {result['permissions']['current_team']['permissions']}")

    # Get executive user permissions
    result = manager.get_user_permissions(
        user_id=env['users']['executive'],
        organization_id=env['org_id']
    )

    assert result['success'] == True
    assert result['permissions']['global_clearance_level'] == 'executive'
    assert 'manage' in result['permissions']['current_team']['permissions']

    print(f"  ✅ Retrieved executive user permissions")
    print(f"     Global clearance: {result['permissions']['global_clearance_level']}")
    print(f"     Permissions: {result['permissions']['current_team']['permissions']}")


def cleanup_test_data(env):
    """Clean up test data."""
    print("\n🧹 Cleaning up test data...")

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    users_table = dynamodb.Table('vrin-enterprise-users')

    try:
        # Delete test users
        for user_id in env['users'].values():
            users_table.delete_item(Key={'user_id': user_id, 'organization_id': env['org_id']})
        print("  ✅ Test users deleted")
    except Exception as e:
        print(f"  ⚠️  User cleanup: {str(e)}")


def run_all_tests():
    """Run complete permission management test suite."""
    print("=" * 80)
    print("PERMISSION MANAGER TEST SUITE")
    print("=" * 80)

    try:
        # Policy CRUD tests
        policy_id, env = test_create_policy()
        test_get_policy(policy_id, env)
        test_list_policies(env)
        test_update_policy(policy_id, env)

        # Clearance validation tests
        test_clearance_check(env)

        # Four-layer security tests
        test_four_layer_security(env)

        # Permission retrieval tests
        test_get_user_permissions(env)

        # Cleanup
        cleanup_test_data(env)

        print("\n" + "=" * 80)
        print("✅ ALL PERMISSION TESTS PASSED!")
        print("=" * 80)
        print("\nSummary:")
        print("  ✅ Policy CRUD operations")
        print("  ✅ Clearance level validation")
        print("  ✅ Four-layer security model:")
        print("     - Layer 1: Team boundary checks")
        print("     - Layer 2: Clearance level checks")
        print("     - Layer 3: Role permission checks")
        print("     - Layer 4: Need-to-know department checks")
        print("  ✅ User permission retrieval")
        print("\n✅ Permission & authorization system ready for production")

        return True

    except AssertionError as e:
        print("\n" + "=" * 80)
        print("❌ TEST FAILED!")
        print("=" * 80)
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
