"""
Test suite for multi-tenant constants module
"""

import sys
sys.path.insert(0, '/Users/Vedant/Documents/vrin-engine')

from lambda_deployment.constants import (
    CLEARANCE_LEVELS,
    SENSITIVITY_LEVELS,
    has_sufficient_clearance,
    get_clearance_numeric,
    get_sensitivity_numeric,
    get_accessible_sensitivities,
    validate_clearance_level,
    validate_sensitivity_level,
    DEFAULT_CLEARANCE,
    DEFAULT_SENSITIVITY
)

def test_clearance_hierarchy():
    """Test that clearance levels are properly ordered"""
    print("🧪 Testing clearance hierarchy...")

    assert CLEARANCE_LEVELS["guest"] < CLEARANCE_LEVELS["standard"]
    assert CLEARANCE_LEVELS["standard"] < CLEARANCE_LEVELS["senior"]
    assert CLEARANCE_LEVELS["senior"] < CLEARANCE_LEVELS["management"]
    assert CLEARANCE_LEVELS["management"] < CLEARANCE_LEVELS["executive"]

    print("  ✅ Clearance hierarchy correct")


def test_sensitivity_hierarchy():
    """Test that sensitivity levels are properly ordered"""
    print("🧪 Testing sensitivity hierarchy...")

    assert SENSITIVITY_LEVELS["public"] < SENSITIVITY_LEVELS["internal"]
    assert SENSITIVITY_LEVELS["internal"] < SENSITIVITY_LEVELS["confidential"]
    assert SENSITIVITY_LEVELS["confidential"] < SENSITIVITY_LEVELS["restricted"]
    assert SENSITIVITY_LEVELS["restricted"] < SENSITIVITY_LEVELS["executive"]

    print("  ✅ Sensitivity hierarchy correct")


def test_clearance_checks():
    """Test clearance checking logic"""
    print("🧪 Testing clearance checks...")

    # Guest can only access public
    assert has_sufficient_clearance("guest", "public") == True
    assert has_sufficient_clearance("guest", "internal") == False
    assert has_sufficient_clearance("guest", "executive") == False

    # Standard can access public and internal
    assert has_sufficient_clearance("standard", "public") == True
    assert has_sufficient_clearance("standard", "internal") == True
    assert has_sufficient_clearance("standard", "confidential") == False

    # Senior can access up to confidential
    assert has_sufficient_clearance("senior", "public") == True
    assert has_sufficient_clearance("senior", "confidential") == True
    assert has_sufficient_clearance("senior", "restricted") == False

    # Management can access up to restricted
    assert has_sufficient_clearance("management", "restricted") == True
    assert has_sufficient_clearance("management", "executive") == False

    # Executive can access everything
    assert has_sufficient_clearance("executive", "public") == True
    assert has_sufficient_clearance("executive", "executive") == True

    print("  ✅ All clearance checks passed")


def test_numeric_conversion():
    """Test numeric conversion functions"""
    print("🧪 Testing numeric conversions...")

    assert get_clearance_numeric("guest") == 1
    assert get_clearance_numeric("standard") == 2
    assert get_clearance_numeric("senior") == 3
    assert get_clearance_numeric("management") == 4
    assert get_clearance_numeric("executive") == 5
    assert get_clearance_numeric("invalid") == 0

    assert get_sensitivity_numeric("public") == 1
    assert get_sensitivity_numeric("internal") == 2
    assert get_sensitivity_numeric("confidential") == 3
    assert get_sensitivity_numeric("restricted") == 4
    assert get_sensitivity_numeric("executive") == 5
    assert get_sensitivity_numeric("invalid") == 999

    print("  ✅ Numeric conversions work correctly")


def test_accessible_sensitivities():
    """Test getting accessible sensitivity levels for clearance"""
    print("🧪 Testing accessible sensitivities...")

    guest_access = get_accessible_sensitivities("guest")
    assert guest_access == ["public"]

    standard_access = get_accessible_sensitivities("standard")
    assert standard_access == ["public", "internal"]

    senior_access = get_accessible_sensitivities("senior")
    assert senior_access == ["public", "internal", "confidential"]

    management_access = get_accessible_sensitivities("management")
    assert management_access == ["public", "internal", "confidential", "restricted"]

    executive_access = get_accessible_sensitivities("executive")
    assert executive_access == ["public", "internal", "confidential", "restricted", "executive"]

    print("  ✅ Accessible sensitivities calculated correctly")


def test_validation():
    """Test validation functions"""
    print("🧪 Testing validation functions...")

    # Valid clearance levels
    assert validate_clearance_level("guest") == True
    assert validate_clearance_level("standard") == True
    assert validate_clearance_level("senior") == True
    assert validate_clearance_level("management") == True
    assert validate_clearance_level("executive") == True

    # Invalid clearance levels
    assert validate_clearance_level("super_admin") == False
    assert validate_clearance_level("") == False
    assert validate_clearance_level("invalid") == False

    # Valid sensitivity levels
    assert validate_sensitivity_level("public") == True
    assert validate_sensitivity_level("internal") == True
    assert validate_sensitivity_level("confidential") == True
    assert validate_sensitivity_level("restricted") == True
    assert validate_sensitivity_level("executive") == True

    # Invalid sensitivity levels
    assert validate_sensitivity_level("top_secret") == False
    assert validate_sensitivity_level("") == False

    print("  ✅ Validation functions work correctly")


def test_real_world_scenarios():
    """Test real-world access control scenarios"""
    print("🧪 Testing real-world scenarios...")

    # Scenario 1: Executive team with mixed clearances
    ceo_clearance = "executive"
    assistant_clearance = "standard"
    exec_comp_sensitivity = "executive"

    assert has_sufficient_clearance(ceo_clearance, exec_comp_sensitivity) == True
    assert has_sufficient_clearance(assistant_clearance, exec_comp_sensitivity) == False
    print("  ✅ Executive team scenario: CEO can access exec comp, assistant cannot")

    # Scenario 2: Legal team with attorney-client privilege
    partner_clearance = "management"
    paralegal_clearance = "standard"
    privileged_doc_sensitivity = "restricted"

    assert has_sufficient_clearance(partner_clearance, privileged_doc_sensitivity) == True
    assert has_sufficient_clearance(paralegal_clearance, privileged_doc_sensitivity) == False
    print("  ✅ Legal team scenario: Partner can access privileged docs, paralegal cannot")

    # Scenario 3: Engineering team with product roadmap
    senior_engineer_clearance = "senior"
    junior_engineer_clearance = "standard"
    roadmap_sensitivity = "confidential"

    assert has_sufficient_clearance(senior_engineer_clearance, roadmap_sensitivity) == True
    assert has_sufficient_clearance(junior_engineer_clearance, roadmap_sensitivity) == False
    print("  ✅ Engineering team scenario: Senior can access roadmap, junior cannot")


def test_defaults():
    """Test default values"""
    print("🧪 Testing default values...")

    assert DEFAULT_CLEARANCE == "standard"
    assert DEFAULT_SENSITIVITY == "internal"

    print("  ✅ Default values set correctly")


if __name__ == "__main__":
    print("=" * 80)
    print("MULTI-TENANT CONSTANTS TEST SUITE")
    print("=" * 80)
    print()

    try:
        test_clearance_hierarchy()
        test_sensitivity_hierarchy()
        test_clearance_checks()
        test_numeric_conversion()
        test_accessible_sensitivities()
        test_validation()
        test_real_world_scenarios()
        test_defaults()

        print()
        print("=" * 80)
        print("✅ ALL TESTS PASSED!")
        print("=" * 80)
        print()
        print("Summary:")
        print("  ✅ Clearance hierarchy: 5 levels (guest → executive)")
        print("  ✅ Sensitivity hierarchy: 5 levels (public → executive)")
        print("  ✅ Access control logic validated")
        print("  ✅ Real-world scenarios working")
        print("  ✅ Constants module ready for production")

    except AssertionError as e:
        print()
        print("=" * 80)
        print("❌ TEST FAILED!")
        print("=" * 80)
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
