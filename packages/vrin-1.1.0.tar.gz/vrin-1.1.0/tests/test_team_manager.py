"""
Test suite for TeamManager class

This validates all team management operations including:
- Team CRUD operations
- Team membership management
- Clearance level validation
- Error handling

Week 2, Milestone 1.2
"""

import sys
import time
sys.path.insert(0, '/Users/Vedant/Documents/vrin-engine')

from lambda_deployment.enterprise_team_management import TeamManager
from lambda_deployment.constants import DEFAULT_CLEARANCE


def setup_test_data():
    """Setup test organization and user for testing."""
    return {
        'organization_id': 'org-test-team-mgmt',
        'user_id': 'user-test-admin',
        'user_id_2': 'user-test-member'
    }


def test_create_team():
    """Test team creation with valid inputs."""
    print("\n🧪 Testing team creation...")

    manager = TeamManager()
    test_data = setup_test_data()

    result = manager.create_team(
        organization_id=test_data['organization_id'],
        name='Engineering Team',
        team_type='department',
        created_by=test_data['user_id'],
        description='Test engineering department',
        settings={
            'default_clearance': 'senior',
            'max_members': 50
        }
    )

    assert result['success'] == True, f"Team creation failed: {result.get('error')}"
    assert 'team_id' in result, "No team_id returned"
    assert result['team']['name'] == 'Engineering Team'
    assert result['team']['team_type'] == 'department'
    assert result['team']['status'] == 'active'

    print(f"  ✅ Team created: {result['team_id']}")
    print(f"     Name: {result['team']['name']}")
    print(f"     Type: {result['team']['team_type']}")
    print(f"     Settings: {result['team']['settings']}")

    return result['team_id']


def test_create_team_invalid_inputs():
    """Test team creation with invalid inputs."""
    print("\n🧪 Testing team creation with invalid inputs...")

    manager = TeamManager()
    test_data = setup_test_data()

    # Test invalid team_type
    result = manager.create_team(
        organization_id=test_data['organization_id'],
        name='Invalid Team',
        team_type='invalid_type',
        created_by=test_data['user_id']
    )

    assert result['success'] == False, "Should reject invalid team_type"
    assert 'Invalid team_type' in result['error']
    print("  ✅ Rejected invalid team_type")

    # Test missing name
    result = manager.create_team(
        organization_id=test_data['organization_id'],
        name='',
        team_type='workspace',
        created_by=test_data['user_id']
    )

    assert result['success'] == False, "Should reject empty name"
    print("  ✅ Rejected empty team name")


def test_get_team(team_id):
    """Test retrieving a team by ID."""
    print(f"\n🧪 Testing team retrieval...")

    manager = TeamManager()
    test_data = setup_test_data()

    team = manager.get_team(team_id, test_data['organization_id'])

    assert team is not None, "Team not found"
    assert team['team_id'] == team_id
    assert team['name'] == 'Engineering Team'

    print(f"  ✅ Team retrieved: {team['team_id']}")
    print(f"     Name: {team['name']}")
    print(f"     Members: {team.get('member_count', 0)}")

    return team


def test_list_teams():
    """Test listing teams in organization."""
    print("\n🧪 Testing team listing...")

    manager = TeamManager()
    test_data = setup_test_data()

    # List all teams
    teams = manager.list_teams(test_data['organization_id'])

    assert len(teams) > 0, "No teams found"
    print(f"  ✅ Found {len(teams)} team(s) in organization")

    # List only active teams
    active_teams = manager.list_teams(
        test_data['organization_id'],
        status='active'
    )

    assert len(active_teams) > 0, "No active teams found"
    print(f"  ✅ Found {len(active_teams)} active team(s)")

    # List by team type
    dept_teams = manager.list_teams(
        test_data['organization_id'],
        team_type='department'
    )

    print(f"  ✅ Found {len(dept_teams)} department team(s)")


def test_update_team(team_id):
    """Test updating team attributes."""
    print(f"\n🧪 Testing team update...")

    manager = TeamManager()
    test_data = setup_test_data()

    result = manager.update_team(
        team_id=team_id,
        organization_id=test_data['organization_id'],
        updates={
            'description': 'Updated engineering department description',
            'settings': {
                'default_clearance': 'management',
                'max_members': 100
            }
        },
        updated_by=test_data['user_id']
    )

    assert result['success'] == True, f"Update failed: {result.get('error')}"
    assert result['team']['description'] == 'Updated engineering department description'
    assert result['team']['settings']['max_members'] == 100

    print("  ✅ Team updated successfully")
    print(f"     New description: {result['team']['description']}")
    print(f"     New settings: {result['team']['settings']}")


def test_update_team_invalid_fields(team_id):
    """Test updating team with invalid fields."""
    print(f"\n🧪 Testing team update with invalid fields...")

    manager = TeamManager()
    test_data = setup_test_data()

    result = manager.update_team(
        team_id=team_id,
        organization_id=test_data['organization_id'],
        updates={
            'team_id': 'new-id',  # Should not be allowed
            'organization_id': 'new-org'  # Should not be allowed
        },
        updated_by=test_data['user_id']
    )

    assert result['success'] == False, "Should reject invalid update fields"
    assert 'Invalid update fields' in result['error']

    print("  ✅ Rejected invalid update fields")


def test_create_nested_team(parent_team_id):
    """Test creating a nested team (child team)."""
    print(f"\n🧪 Testing nested team creation...")

    manager = TeamManager()
    test_data = setup_test_data()

    result = manager.create_team(
        organization_id=test_data['organization_id'],
        name='Backend Team',
        team_type='project',
        created_by=test_data['user_id'],
        description='Backend engineering sub-team',
        parent_team_id=parent_team_id
    )

    assert result['success'] == True, f"Nested team creation failed: {result.get('error')}"
    assert result['team']['parent_team_id'] == parent_team_id

    print(f"  ✅ Nested team created: {result['team_id']}")
    print(f"     Parent: {result['team']['parent_team_id']}")

    return result['team_id']


def test_delete_team_soft(child_team_id):
    """Test soft deletion (deactivation) of a team."""
    print(f"\n🧪 Testing soft team deletion...")

    manager = TeamManager()
    test_data = setup_test_data()

    result = manager.delete_team(
        team_id=child_team_id,
        organization_id=test_data['organization_id'],
        deleted_by=test_data['user_id'],
        hard_delete=False
    )

    assert result['success'] == True, f"Soft delete failed: {result.get('error')}"
    assert 'deactivated' in result['message'].lower()

    # Verify team is inactive
    team = manager.get_team(child_team_id, test_data['organization_id'])
    assert team['status'] == 'inactive'

    print("  ✅ Team soft deleted (deactivated)")
    print(f"     Status: {team['status']}")


def test_delete_team_hard(team_id):
    """Test hard deletion (permanent) of a team."""
    print(f"\n🧪 Testing hard team deletion...")

    manager = TeamManager()
    test_data = setup_test_data()

    result = manager.delete_team(
        team_id=team_id,
        organization_id=test_data['organization_id'],
        deleted_by=test_data['user_id'],
        hard_delete=True
    )

    assert result['success'] == True, f"Hard delete failed: {result.get('error')}"
    assert 'permanently deleted' in result['message'].lower()

    # Verify team is gone
    team = manager.get_team(team_id, test_data['organization_id'])
    assert team is None, "Team should not exist after hard delete"

    print("  ✅ Team hard deleted (permanently removed)")


def test_validation_functions():
    """Test input validation helper functions."""
    print("\n🧪 Testing validation functions...")

    manager = TeamManager()

    # Test invalid organization_id
    error = manager._validate_team_creation('', 'Team Name', 'workspace', 'user-123')
    assert error is not None, "Should reject empty organization_id"
    print("  ✅ Rejected empty organization_id")

    # Test short team name
    error = manager._validate_team_creation('org-123', 'A', 'workspace', 'user-123')
    assert error is not None, "Should reject short team name"
    print("  ✅ Rejected short team name")

    # Test invalid team type
    error = manager._validate_team_creation('org-123', 'Team Name', 'invalid', 'user-123')
    assert error is not None, "Should reject invalid team type"
    print("  ✅ Rejected invalid team type")

    # Test valid inputs
    error = manager._validate_team_creation('org-123', 'Valid Team', 'workspace', 'user-123')
    assert error is None, "Should accept valid inputs"
    print("  ✅ Accepted valid team creation inputs")


def run_all_tests():
    """Run complete test suite for TeamManager."""
    print("=" * 80)
    print("TEAM MANAGER TEST SUITE")
    print("=" * 80)

    try:
        # Test validation
        test_validation_functions()

        # Test team creation
        team_id = test_create_team()
        test_create_team_invalid_inputs()

        # Test team retrieval
        test_get_team(team_id)
        test_list_teams()

        # Test team updates
        test_update_team(team_id)
        test_update_team_invalid_fields(team_id)

        # Test nested teams
        child_team_id = test_create_nested_team(team_id)

        # Test team deletion
        test_delete_team_soft(child_team_id)
        test_delete_team_hard(team_id)

        print("\n" + "=" * 80)
        print("✅ ALL TEAM MANAGER TESTS PASSED!")
        print("=" * 80)
        print("\nSummary:")
        print("  ✅ Team creation and validation")
        print("  ✅ Team retrieval (get and list)")
        print("  ✅ Team updates")
        print("  ✅ Nested teams")
        print("  ✅ Soft and hard deletion")
        print("  ✅ Input validation")
        print("\n✅ TeamManager ready for integration")

        return True

    except AssertionError as e:
        print("\n" + "=" * 80)
        print("❌ TEST FAILED!")
        print("=" * 80)
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
