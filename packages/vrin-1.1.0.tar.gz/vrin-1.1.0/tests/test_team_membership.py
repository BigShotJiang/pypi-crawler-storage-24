"""
Test suite for Team Membership Management

This validates team membership operations including:
- Adding users to teams with clearance levels
- Removing users from teams
- Clearance level validation
- Global clearance level updates

Week 2, Milestone 1.2
"""

import sys
import time
sys.path.insert(0, '/Users/Vedant/Documents/vrin-engine')

from lambda_deployment.enterprise_team_management import TeamManager
from lambda_deployment.constants import DEFAULT_CLEARANCE
import boto3


def setup_test_user():
    """Create a test user in the users table."""
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    users_table = dynamodb.Table('vrin-enterprise-users')

    test_user = {
        'user_id': 'user-test-membership',
        'organization_id': 'org-test-membership',
        'email': 'test@example.com',
        'first_name': 'Test',
        'last_name': 'User',
        'role': 'member',
        'status': 'active',
        'created_at': int(time.time()),
        'team_memberships': [],  # Start with no teams
        'global_clearance_level': DEFAULT_CLEARANCE
    }

    users_table.put_item(Item=test_user)
    print(f"  ✅ Test user created: {test_user['user_id']}")

    return test_user


def create_test_team(team_name=None):
    """Create a test team with unique name."""
    import uuid
    manager = TeamManager()

    if team_name is None:
        team_name = f'Test Engineering Team {uuid.uuid4().hex[:8]}'

    result = manager.create_team(
        organization_id='org-test-membership',
        name=team_name,
        team_type='department',
        created_by='user-admin',
        description='Team for membership testing'
    )

    assert result['success'], f"Failed to create test team: {result.get('error')}"
    print(f"  ✅ Test team created: {result['team_id']}")

    return result['team_id']


def test_add_team_member():
    """Test adding a user to a team."""
    print("\n🧪 Testing add team member...")

    manager = TeamManager()

    # Setup
    user = setup_test_user()
    team_id = create_test_team()

    # Add user to team with senior clearance
    result = manager.add_team_member(
        user_id=user['user_id'],
        organization_id=user['organization_id'],
        team_id=team_id,
        role='member',
        clearance_level='senior',
        added_by='user-admin',
        departments=['engineering', 'backend'],
        job_title='Senior Engineer',
        employment_type='full_time',
        permissions=['read', 'write', 'manage_resources']
    )

    assert result['success'], f"Failed to add member: {result.get('error')}"
    assert result['team_membership']['clearance_level'] == 'senior'
    assert result['team_membership']['role'] == 'member'
    assert 'backend' in result['team_membership']['departments']

    print("  ✅ User added to team successfully")
    print(f"     Clearance: {result['team_membership']['clearance_level']}")
    print(f"     Role: {result['team_membership']['role']}")
    print(f"     Departments: {result['team_membership']['departments']}")

    return user['user_id'], user['organization_id'], team_id


def test_add_member_invalid_clearance():
    """Test adding member with invalid clearance level."""
    print("\n🧪 Testing add member with invalid clearance...")

    manager = TeamManager()

    # Setup
    user = setup_test_user()
    user['user_id'] = 'user-test-invalid'

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    users_table = dynamodb.Table('vrin-enterprise-users')
    users_table.put_item(Item=user)

    team_id = create_test_team()

    # Try to add with invalid clearance
    result = manager.add_team_member(
        user_id=user['user_id'],
        organization_id=user['organization_id'],
        team_id=team_id,
        role='member',
        clearance_level='super_admin',  # Invalid
        added_by='user-admin'
    )

    assert not result['success'], "Should reject invalid clearance level"
    assert 'Invalid clearance level' in result['error']

    print("  ✅ Rejected invalid clearance level")

    # Cleanup
    users_table.delete_item(Key={'user_id': user['user_id'], 'organization_id': user['organization_id']})


def test_add_member_duplicate():
    """Test adding user to team they're already in."""
    print("\n🧪 Testing duplicate team membership...")

    manager = TeamManager()

    # Reuse existing user and team from previous test
    user_id = 'user-test-membership'
    org_id = 'org-test-membership'

    # Get existing teams
    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    users_table = dynamodb.Table('vrin-enterprise-users')

    user_response = users_table.get_item(Key={'user_id': user_id, 'organization_id': org_id})
    user = user_response.get('Item')

    if user and user.get('team_memberships'):
        team_id = user['team_memberships'][0]['team_id']

        # Try to add again
        result = manager.add_team_member(
            user_id=user_id,
            organization_id=org_id,
            team_id=team_id,
            role='member',
            clearance_level='standard',
            added_by='user-admin'
        )

        assert not result['success'], "Should reject duplicate membership"
        assert 'already member' in result['error'].lower()

        print("  ✅ Rejected duplicate team membership")
    else:
        print("  ⚠️  Skipped (no existing membership to test)")


def test_remove_team_member():
    """Test removing a user from a team."""
    print("\n🧪 Testing remove team member...")

    manager = TeamManager()

    # Get user with existing team membership
    user_id = 'user-test-membership'
    org_id = 'org-test-membership'

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    users_table = dynamodb.Table('vrin-enterprise-users')

    user_response = users_table.get_item(Key={'user_id': user_id, 'organization_id': org_id})
    user = user_response.get('Item')

    if not user or not user.get('team_memberships'):
        print("  ⚠️  Skipped (no membership to remove)")
        return

    team_id = user['team_memberships'][0]['team_id']

    # Remove user from team
    result = manager.remove_team_member(
        user_id=user_id,
        organization_id=org_id,
        team_id=team_id,
        removed_by='user-admin'
    )

    assert result['success'], f"Failed to remove member: {result.get('error')}"

    # Verify user no longer in team
    user_response = users_table.get_item(Key={'user_id': user_id, 'organization_id': org_id})
    updated_user = user_response.get('Item')

    team_ids = [m['team_id'] for m in updated_user.get('team_memberships', [])]
    assert team_id not in team_ids, "User should not be in team after removal"

    print("  ✅ User removed from team successfully")
    print(f"     Remaining teams: {len(updated_user.get('team_memberships', []))}")


def test_global_clearance_update():
    """Test that global clearance level updates correctly."""
    print("\n🧪 Testing global clearance level updates...")

    manager = TeamManager()

    # Create new user
    user = setup_test_user()
    user['user_id'] = 'user-test-clearance'

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    users_table = dynamodb.Table('vrin-enterprise-users')
    users_table.put_item(Item=user)

    # Create two teams
    team1_id = create_test_team()

    import uuid
    result2 = manager.create_team(
        organization_id='org-test-membership',
        name=f'Executive Team {uuid.uuid4().hex[:8]}',
        team_type='executive',
        created_by='user-admin'
    )
    team2_id = result2['team_id']

    # Add to first team with standard clearance
    manager.add_team_member(
        user_id=user['user_id'],
        organization_id=user['organization_id'],
        team_id=team1_id,
        role='member',
        clearance_level='standard',
        added_by='user-admin'
    )

    # Check global clearance
    user_response = users_table.get_item(Key={'user_id': user['user_id'], 'organization_id': user['organization_id']})
    user_data = user_response['Item']
    assert user_data['global_clearance_level'] == 'standard'
    print("  ✅ Global clearance set to 'standard' after first team")

    # Add to second team with executive clearance
    manager.add_team_member(
        user_id=user['user_id'],
        organization_id=user['organization_id'],
        team_id=team2_id,
        role='member',
        clearance_level='executive',
        added_by='user-admin'
    )

    # Check global clearance updated to highest
    user_response = users_table.get_item(Key={'user_id': user['user_id'], 'organization_id': user['organization_id']})
    user_data = user_response['Item']
    assert user_data['global_clearance_level'] == 'executive'
    print("  ✅ Global clearance updated to 'executive' (highest across teams)")

    # Cleanup
    users_table.delete_item(Key={'user_id': user['user_id'], 'organization_id': user['organization_id']})


def cleanup_test_data():
    """Clean up all test data."""
    print("\n🧹 Cleaning up test data...")

    dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
    users_table = dynamodb.Table('vrin-enterprise-users')
    teams_table = dynamodb.Table('vrin-enterprise-teams')

    # Delete test users
    try:
        users_table.delete_item(Key={'user_id': 'user-test-membership', 'organization_id': 'org-test-membership'})
        users_table.delete_item(Key={'user_id': 'user-test-invalid', 'organization_id': 'org-test-membership'})
        users_table.delete_item(Key={'user_id': 'user-test-clearance', 'organization_id': 'org-test-membership'})
        print("  ✅ Test users deleted")
    except Exception as e:
        print(f"  ⚠️  User cleanup: {str(e)}")

    # Delete test teams
    try:
        # We'd need to scan and delete all test teams - skipping for now as they'll be cleaned up manually
        print("  ⚠️  Team cleanup skipped (teams can be cleaned manually)")
    except Exception as e:
        print(f"  ⚠️  Team cleanup: {str(e)}")


def run_all_tests():
    """Run complete membership management test suite."""
    print("=" * 80)
    print("TEAM MEMBERSHIP MANAGEMENT TEST SUITE")
    print("=" * 80)

    try:
        # Core membership tests
        test_add_team_member()
        test_add_member_invalid_clearance()
        test_add_member_duplicate()
        test_remove_team_member()

        # Advanced tests
        test_global_clearance_update()

        # Cleanup
        cleanup_test_data()

        print("\n" + "=" * 80)
        print("✅ ALL MEMBERSHIP TESTS PASSED!")
        print("=" * 80)
        print("\nSummary:")
        print("  ✅ Add team member with clearance levels")
        print("  ✅ Reject invalid clearance levels")
        print("  ✅ Reject duplicate memberships")
        print("  ✅ Remove team member")
        print("  ✅ Global clearance level updates correctly")
        print("\n✅ Team membership management ready for production")

        return True

    except AssertionError as e:
        print("\n" + "=" * 80)
        print("❌ TEST FAILED!")
        print("=" * 80)
        print(f"Error: {e}")
        import traceback
        traceback.print_exc()
        cleanup_test_data()
        return False


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
