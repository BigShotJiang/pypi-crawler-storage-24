import torch
import pandas as pd
import numpy as np
import os.path as osp
from sklearn.model_selection import KFold
from datasets.csv_dataset import CsvDataset
from evaluate import start_evaluate
import warnings
warnings.filterwarnings('ignore')

# 导入我们刚刚写的 Wrapper
from sklearn_wrapper import BPXNetClassifier 
from models.classifiers import ClassifierNames

def build_fold_path(task, classifier, BPRD_gama, use_prior, fold):
    return '{0}_{1}_gama{2}_{3}_prior/fold{4}'.format(task, classifier, BPRD_gama, use_prior, fold)

if __name__ == '__main__':
    # 定义超参数
    classifier = ClassifierNames.kan 
    BPRD_gama = 0.2
    use_prior = 'expert' 
    categories = ['viral', 'fungal', 'bacterial']
    num_classes = len(categories)
    device = 'cuda' if torch.cuda.is_available() else 'cpu'  

    # 加载先验知识
    prior_root = 'datasets/priors/pneu'
    if use_prior is None: 
        prior_weights = None
    else:
        prior_weights_file = 'expert_importance.csv' if use_prior=='expert' else 'foundation_importance.csv'
        prior_weights = pd.read_csv(osp.join(prior_root, prior_weights_file)).drop(
            columns=['left lung volume', 'right lung volume', 'total lung volume'], axis=1)
        prior_weights = np.squeeze(np.array(prior_weights))   
        print('Prior loaded!')

    # 加载数据集
    ignores = ['allergic history', 'hospitalization days', 'left lung volume', 'right lung volume', 'total lung volume']
    maxv_for_norm = pd.read_csv(osp.join('datasets', 'PathCls-Pneu-MaxValues.csv'), encoding='gbk').drop(columns=ignores, axis=1)
    maxv_for_norm.pop('label')       
    maxv_for_norm = np.array(maxv_for_norm)[0,...]
   
    data_file = ['datasets/PathoCls-Pneu.csv']
    ignores.append('Hospital')
    dataset = CsvDataset(data_file, label_column='label', ignores=ignores, max_norm=True, maxv_for_norm=maxv_for_norm, repeat_fews=True)    
   
    # 提取所有数据为 Numpy 数组，以匹配 sklearn 风格
    # 假设你的 dataset 可以通过 dataset.xs 和 dataset.ys 获取，或者遍历获取
    X_all = np.array([item[0] for item in dataset])
    y_all = np.array([item[1] for item in dataset])

    kfold = KFold(n_splits=5, shuffle=True, random_state=42)
    
    for fold, (train_ids, val_ids) in enumerate(kfold.split(X_all)):
        print(f'\n================ Folds: {fold+1}/5 ================')
        
        # 划分训练集和验证集
        X_train, y_train = X_all[train_ids], y_all[train_ids]
        X_val, y_val = X_all[val_ids], y_all[val_ids]

        ckpoint_save_path = 'checkpoints/' + build_fold_path('pneu', classifier, BPRD_gama, use_prior, fold+1)

        # 1. 初始化 Sklearn 风格模型
        model = BPXNetClassifier(
            num_variables=dataset.getNumFeatures(),
            bprd_gama=BPRD_gama,
            fill_v=-1,
            anfs_hiden_features=128,
            classifier_name=classifier,
            classifier_layers=[dataset.getNumFeatures(), 128, 128, 128],
            num_classes=num_classes,
            prior_knowledge=prior_weights,
            epochs=100,
            batch_size=512,
            lr=0.001,
            device=device
        )
        
        # 2. 训练模型 (一条语句搞定！)
        model.fit(X_train, y_train, eval_set=(X_val, y_val), save_model_dir=ckpoint_save_path)

        # 3. 开始评估
        print('Start testing')
        # 如果 evaluate.py 需要底层 nn.Module，可以传入 model.network
        # 注意：fit 结束后，内部的 self.network 已经自动加载了 best_weights.pth
        for topr in [0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0]:
            metric_save_path = 'results/' + build_fold_path('pneu', classifier, BPRD_gama, use_prior, fold+1) + f'/topr{topr}'
            
            # 兼容你现有的 evaluate 脚本，我们需要传入 PyTorch 原生的 dataset subset 和 nn.Module
            from torch.utils.data import Subset
            val_subset = Subset(dataset, val_ids)
            start_evaluate(model.network, val_subset, topr, categories, metric_save_path, True, dataset.feature_names, device)