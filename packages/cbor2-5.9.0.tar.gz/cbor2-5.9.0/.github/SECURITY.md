# Security Policy

## Supported Versions

The latest major/minor versions will get security updates and bug fixes.
Earlier versions are unsupported.

| Version | Supported          |
|---------| ------------------ |
| 5.9.x   | :white_check_mark: |
| < 5.9.x | :x:                |

## Reporting a Vulnerability

See the [security](https://github.com/agronholm/cbor2/security)
section to view existing security advisories or to report a new vulnerability.
