# airlinefyi

[![PyPI version](https://agentgif.com/badge/pypi/airlinefyi/version.svg)](https://pypi.org/project/airlinefyi/)
[![Python](https://img.shields.io/pypi/pyversions/airlinefyi)](https://pypi.org/project/airlinefyi/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](https://opensource.org/licenses/MIT)
[![Zero Dependencies](https://img.shields.io/badge/dependencies-0-brightgreen)](https://pypi.org/project/airlinefyi/)

Python API client for airline data. Look up airlines by IATA/ICAO code, explore fleet compositions, query alliance memberships (Star Alliance, oneworld, SkyTeam), and retrieve route networks — all from [AirlineFYI](https://airlinefyi.com/), a comprehensive airline reference covering carriers worldwide.

AirlineFYI catalogs airline identification codes, fleet sizes and aircraft types, hub airports, founding dates, and operational status — providing structured data for travel-tech developers, aviation analytics, and flight booking platforms.

> **Explore airlines at [airlinefyi.com](https://airlinefyi.com/)** — browse by [alliance](https://airlinefyi.com/alliances/), search by [IATA code](https://airlinefyi.com/airlines/), and view fleet details.

<p align="center">
  <img src="https://raw.githubusercontent.com/fyipedia/airlinefyi/main/demo.gif" alt="airlinefyi demo — airline lookup, fleet data, and alliance information in Python" width="800">
</p>

## Table of Contents

- [Install](#install)
- [Quick Start](#quick-start)
- [What You Can Do](#what-you-can-do)
  - [Airline Alliances](#airline-alliances)
  - [Fleet Composition](#fleet-composition)
  - [Hub Airports and Route Networks](#hub-airports-and-route-networks)
  - [Airline Identification Codes](#airline-identification-codes)
- [Command-Line Interface](#command-line-interface)
- [MCP Server (Claude, Cursor, Windsurf)](#mcp-server-claude-cursor-windsurf)
- [REST API Client](#rest-api-client)
- [API Reference](#api-reference)
- [Learn More About Airlines](#learn-more-about-airlines)
- [Also Available](#also-available)
- [Transport FYI Family](#transport-fyi-family)
- [License](#license)

## Install

```bash
pip install airlinefyi                # Core (zero deps)
pip install "airlinefyi[cli]"         # + Command-line interface
pip install "airlinefyi[mcp]"         # + MCP server for AI assistants
pip install "airlinefyi[api]"         # + HTTP client for airlinefyi.com API
pip install "airlinefyi[all]"         # Everything
```

## Quick Start

```python
from airlinefyi.api import AirlineFYI

with AirlineFYI() as api:
    # Look up an airline
    ke = api.get_airline("korean-air")
    print(ke["iata"])           # KE
    print(ke["icao"])           # KAL
    print(ke["alliance"])       # SkyTeam
    print(ke["fleet_size"])     # Fleet count

    # List airlines by alliance
    skyteam = api.list_airlines(alliance="skyteam")
    for airline in skyteam:
        print(f"{airline['iata']} — {airline['name']}")

    # Search airlines
    results = api.search("emirates")
```

## What You Can Do

### Airline Alliances

The three global airline alliances — Star Alliance, oneworld, and SkyTeam — enable codeshare agreements, shared frequent flyer programs, and coordinated route networks. Together they cover over 60% of global air traffic.

| Alliance | Founded | Members | Annual Passengers | Key Members |
|----------|---------|---------|-------------------|-------------|
| Star Alliance | 1997 | 26 | 762M | United, Lufthansa, ANA, Singapore |
| SkyTeam | 2000 | 19 | 630M | Delta, Air France-KLM, Korean Air |
| oneworld | 1999 | 13 | 535M | American, British Airways, Qantas, JAL |

```python
from airlinefyi.api import AirlineFYI

with AirlineFYI() as api:
    # List all airline alliances
    alliances = api.list_alliances()
    for a in alliances:
        print(f"{a['name']}: {a['member_count']} members")

    # Get all airlines in an alliance
    star = api.list_airlines(alliance="star-alliance")
    for airline in star:
        print(f"{airline['iata']} {airline['name']}")
```

Learn more: [Airline Alliances](https://airlinefyi.com/alliances/) · [Glossary](https://airlinefyi.com/glossary/)

### Fleet Composition

An airline's fleet determines its route capabilities. Narrowbody aircraft (A320neo, B737 MAX) serve short-to-medium routes (1-6 hours), while widebody aircraft (A350, B787, B777) operate long-haul intercontinental routes. Fleet age and composition directly impact operating costs and passenger experience.

| Aircraft Category | Typical Range | Seats | Example Types |
|-------------------|--------------|-------|---------------|
| Regional | <2,000 km | 50-100 | E175, CRJ-900, ATR 72 |
| Narrowbody | 2,000-6,000 km | 120-240 | A320neo, B737 MAX, A321XLR |
| Widebody | 6,000-15,000 km | 250-400 | A350, B787, B777 |
| Super-widebody | 8,000-18,000 km | 400-600 | A380, B747-8 |

```python
from airlinefyi.api import AirlineFYI

with AirlineFYI() as api:
    # Get fleet composition
    airline = api.get_airline("singapore-airlines")
    print(f"Fleet size: {airline['fleet_size']}")
    for aircraft in airline.get("fleet", []):
        print(f"  {aircraft['type']}: {aircraft['count']} aircraft")
```

Learn more: [Airline Fleets](https://airlinefyi.com/airlines/) · [Guides](https://airlinefyi.com/guides/)

### Hub Airports and Route Networks

Airlines organize their route networks around hub airports, creating spoke-and-hub systems that maximize connectivity. Major carriers operate multiple hubs — United uses EWR, IAH, SFO, and ORD; Lufthansa Group uses FRA, MUC, ZRH, and VIE.

```python
from airlinefyi.api import AirlineFYI

with AirlineFYI() as api:
    # Get airline hub airports
    airline = api.get_airline("united-airlines")
    for hub in airline.get("hubs", []):
        print(f"Hub: {hub['name']} ({hub['iata']})")
```

Learn more: [Airlines](https://airlinefyi.com/airlines/) · [Glossary](https://airlinefyi.com/glossary/)

### Airline Identification Codes

Like airports, airlines are assigned IATA (2-letter) and ICAO (3-letter) codes. IATA codes appear on tickets and displays (AA, BA, LH), while ICAO codes are used in flight plans and ATC communications (AAL, BAW, DLH). The ICAO callsign is the radio name used by pilots.

| Airline | IATA | ICAO | Callsign |
|---------|------|------|----------|
| American Airlines | AA | AAL | AMERICAN |
| British Airways | BA | BAW | SPEEDBIRD |
| Lufthansa | LH | DLH | LUFTHANSA |
| Korean Air | KE | KAL | KOREAN AIR |
| Emirates | EK | UAE | EMIRATES |

```python
from airlinefyi.api import AirlineFYI

with AirlineFYI() as api:
    # Search by IATA code
    results = api.search("BA")
    airline = results[0]
    print(f"{airline['iata']}/{airline['icao']} — {airline['callsign']}")
```

Learn more: [Airline Directory](https://airlinefyi.com/airlines/) · [API Documentation](https://airlinefyi.com/developers/)

## Command-Line Interface

```bash
pip install "airlinefyi[cli]"

airlinefyi airline korean-air               # Airline details
airlinefyi search "delta"                   # Search airlines
airlinefyi alliances                        # List all alliances
airlinefyi alliance star-alliance           # Alliance members
```

## MCP Server (Claude, Cursor, Windsurf)

```bash
pip install "airlinefyi[mcp]"
```

```json
{
    "mcpServers": {
        "airlinefyi": {
            "command": "uvx",
            "args": ["--from", "airlinefyi[mcp]", "python", "-m", "airlinefyi.mcp_server"]
        }
    }
}
```

## REST API Client

```python
from airlinefyi.api import AirlineFYI

with AirlineFYI() as api:
    airline = api.get_airline("korean-air")          # GET /api/v1/airlines/korean-air/
    airlines = api.list_airlines(alliance="skyteam")  # GET /api/v1/airlines/?alliance=skyteam
    alliances = api.list_alliances()                 # GET /api/v1/alliances/
    results = api.search("emirates")                 # GET /api/v1/search/?q=emirates
```

### Example

```bash
curl -s "https://airlinefyi.com/api/v1/airlines/korean-air/"
```

```json
{
    "slug": "korean-air",
    "name": "Korean Air",
    "iata": "KE",
    "icao": "KAL",
    "alliance": "SkyTeam",
    "country": "South Korea"
}
```

Full API documentation at [airlinefyi.com/developers/](https://airlinefyi.com/developers/).

## API Reference

| Function | Description |
|----------|-------------|
| `api.get_airline(slug)` | Airline details (codes, alliance, fleet, hubs) |
| `api.list_airlines(alliance)` | List airlines, optionally by alliance |
| `api.list_alliances()` | All airline alliances |
| `api.get_alliance(slug)` | Alliance details with member list |
| `api.search(query)` | Search by name, IATA, or ICAO code |

## Learn More About Airlines

- **Browse**: [Airline Directory](https://airlinefyi.com/airlines/) · [Alliances](https://airlinefyi.com/alliances/)
- **Guides**: [Aviation Guides](https://airlinefyi.com/guides/) · [Glossary](https://airlinefyi.com/glossary/)
- **API**: [REST API Docs](https://airlinefyi.com/developers/) · [OpenAPI Spec](https://airlinefyi.com/api/openapi.json)

## Also Available

| Platform | Install | Link |
|----------|---------|------|
| **npm** | `npm install airlinefyi` | [npm](https://www.npmjs.com/package/airlinefyi) |
| **MCP** | `uvx --from "airlinefyi[mcp]" python -m airlinefyi.mcp_server` | [Config](#mcp-server-claude-cursor-windsurf) |

## Transport FYI Family

Part of the [FYIPedia](https://fyipedia.com) open-source developer tools ecosystem — airports, airlines, aircraft, and railways.

| Package | PyPI | npm | Description |
|---------|------|-----|-------------|
| airportfyi | [PyPI](https://pypi.org/project/airportfyi/) | [npm](https://www.npmjs.com/package/airportfyi) | 4,500+ airports, IATA/ICAO codes, routes — [airportfyi.com](https://airportfyi.com/) |
| **airlinefyi** | [PyPI](https://pypi.org/project/airlinefyi/) | [npm](https://www.npmjs.com/package/airlinefyi) | **Airlines, fleets, alliances, routes — [airlinefyi.com](https://airlinefyi.com/)** |
| planefyi | [PyPI](https://pypi.org/project/planefyi/) | [npm](https://www.npmjs.com/package/planefyi) | Aircraft models, specifications, manufacturers — [planefyi.com](https://planefyi.com/) |
| trainfyi | [PyPI](https://pypi.org/project/trainfyi/) | [npm](https://www.npmjs.com/package/trainfyi) | Railway stations, train routes, rail networks — [trainfyi.com](https://trainfyi.com/) |

## License

MIT
