"""Command-line interface for airlinefyi."""

from __future__ import annotations

import json

import typer

from airlinefyi.api import AirlineFYI

app = typer.Typer(help="AirlineFYI — Airlines, fleets and route data API client.")


@app.command()
def search(query: str) -> None:
    """Search airlinefyi.com."""
    with AirlineFYI() as api:
        result = api.search(query)
        typer.echo(json.dumps(result, indent=2))
