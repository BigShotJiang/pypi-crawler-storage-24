"""MCP server for airlinefyi — AI assistant tools for airlinefyi.com.

Run: uvx --from "airlinefyi[mcp]" python -m airlinefyi.mcp_server
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("AirlineFYI")


@mcp.tool()
def list_airlines(limit: int = 20, offset: int = 0) -> str:
    """List airlines from airlinefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from airlinefyi.api import AirlineFYI

    with AirlineFYI() as api:
        data = api.list_airlines(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No airlines found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def get_airline(slug: str) -> str:
    """Get detailed information about a specific airline.

    Args:
        slug: URL slug identifier for the airline.
    """
    from airlinefyi.api import AirlineFYI

    with AirlineFYI() as api:
        data = api.get_airline(slug)
        return str(data)


@mcp.tool()
def list_flight_corridors(limit: int = 20, offset: int = 0) -> str:
    """List flight_corridors from airlinefyi.com.

    Args:
        limit: Maximum number of results. Default 20.
        offset: Number of results to skip. Default 0.
    """
    from airlinefyi.api import AirlineFYI

    with AirlineFYI() as api:
        data = api.list_flight_corridors(limit=limit, offset=offset)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return "No flight_corridors found."
        items = results[:limit] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


@mcp.tool()
def search_airline(query: str) -> str:
    """Search airlinefyi.com for airlines, flights, cabin products, and alliances.

    Args:
        query: Search query string.
    """
    from airlinefyi.api import AirlineFYI

    with AirlineFYI() as api:
        data = api.search(query)
        results = data.get("results", data) if isinstance(data, dict) else data
        if not results:
            return f"No results found for \"{query}\"."
        items = results[:10] if isinstance(results, list) else []
        return "\n".join(f"- {item.get('name', item.get('slug', '?'))}" for item in items)


def main() -> None:
    """Run the MCP server."""
    mcp.run()


if __name__ == "__main__":
    main()
