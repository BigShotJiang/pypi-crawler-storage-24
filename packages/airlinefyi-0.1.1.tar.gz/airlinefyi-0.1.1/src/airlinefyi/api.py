"""HTTP API client for airlinefyi.com REST endpoints.

Requires the ``api`` extra: ``pip install airlinefyi[api]``

Usage::

    from airlinefyi.api import AirlineFYI

    with AirlineFYI() as api:
        items = api.list_airlines()
        detail = api.get_airline("example-slug")
        results = api.search("query")
"""

from __future__ import annotations

from typing import Any

import httpx


class AirlineFYI:
    """API client for the airlinefyi.com REST API.

    Provides typed access to all airlinefyi.com endpoints including
    list, detail, and search operations.

    Args:
        base_url: API base URL. Defaults to ``https://airlinefyi.com``.
        timeout: Request timeout in seconds. Defaults to ``10.0``.
    """

    def __init__(
        self,
        base_url: str = "https://airlinefyi.com",
        timeout: float = 10.0,
    ) -> None:
        self._client = httpx.Client(base_url=base_url, timeout=timeout)

    def _get(self, path: str, **params: Any) -> dict[str, Any]:
        resp = self._client.get(
            path,
            params={k: v for k, v in params.items() if v is not None},
        )
        resp.raise_for_status()
        result: dict[str, Any] = resp.json()
        return result

    # -- Endpoints -----------------------------------------------------------

    def list_airlines(self, **params: Any) -> dict[str, Any]:
        """List all airlines."""
        return self._get("/api/v1/airlines/", **params)

    def get_airline(self, slug: str) -> dict[str, Any]:
        """Get airline by slug."""
        return self._get(f"/api/v1/airlines/" + slug + "/")

    def list_airports(self, **params: Any) -> dict[str, Any]:
        """List all airports."""
        return self._get("/api/v1/airports/", **params)

    def get_airport(self, slug: str) -> dict[str, Any]:
        """Get airport by slug."""
        return self._get(f"/api/v1/airports/" + slug + "/")

    def list_brief_series(self, **params: Any) -> dict[str, Any]:
        """List all brief series."""
        return self._get("/api/v1/brief-series/", **params)

    def get_brief_sery(self, slug: str) -> dict[str, Any]:
        """Get brief sery by slug."""
        return self._get(f"/api/v1/brief-series/" + slug + "/")

    def list_cabin_products(self, **params: Any) -> dict[str, Any]:
        """List all cabin products."""
        return self._get("/api/v1/cabin-products/", **params)

    def get_cabin_product(self, slug: str) -> dict[str, Any]:
        """Get cabin product by slug."""
        return self._get(f"/api/v1/cabin-products/" + slug + "/")

    def list_countries(self, **params: Any) -> dict[str, Any]:
        """List all countries."""
        return self._get("/api/v1/countries/", **params)

    def get_country(self, slug: str) -> dict[str, Any]:
        """Get country by slug."""
        return self._get(f"/api/v1/countries/" + slug + "/")

    def list_faqs(self, **params: Any) -> dict[str, Any]:
        """List all faqs."""
        return self._get("/api/v1/faqs/", **params)

    def get_faq(self, slug: str) -> dict[str, Any]:
        """Get faq by slug."""
        return self._get(f"/api/v1/faqs/" + slug + "/")

    def list_flight_corridors(self, **params: Any) -> dict[str, Any]:
        """List all flight corridors."""
        return self._get("/api/v1/flight-corridors/", **params)

    def get_flight_corridor(self, slug: str) -> dict[str, Any]:
        """Get flight corridor by slug."""
        return self._get(f"/api/v1/flight-corridors/" + slug + "/")

    def list_flights(self, **params: Any) -> dict[str, Any]:
        """List all flights."""
        return self._get("/api/v1/flights/", **params)

    def get_flight(self, slug: str) -> dict[str, Any]:
        """Get flight by slug."""
        return self._get(f"/api/v1/flights/" + slug + "/")

    def list_glossary(self, **params: Any) -> dict[str, Any]:
        """List all glossary."""
        return self._get("/api/v1/glossary/", **params)

    def get_term(self, slug: str) -> dict[str, Any]:
        """Get term by slug."""
        return self._get(f"/api/v1/glossary/" + slug + "/")

    def list_guide_series(self, **params: Any) -> dict[str, Any]:
        """List all guide series."""
        return self._get("/api/v1/guide-series/", **params)

    def get_guide_sery(self, slug: str) -> dict[str, Any]:
        """Get guide sery by slug."""
        return self._get(f"/api/v1/guide-series/" + slug + "/")

    def list_guides(self, **params: Any) -> dict[str, Any]:
        """List all guides."""
        return self._get("/api/v1/guides/", **params)

    def get_guide(self, slug: str) -> dict[str, Any]:
        """Get guide by slug."""
        return self._get(f"/api/v1/guides/" + slug + "/")

    def list_hub_profiles(self, **params: Any) -> dict[str, Any]:
        """List all hub profiles."""
        return self._get("/api/v1/hub-profiles/", **params)

    def get_hub_profile(self, slug: str) -> dict[str, Any]:
        """Get hub profile by slug."""
        return self._get(f"/api/v1/hub-profiles/" + slug + "/")

    def list_industry_briefs(self, **params: Any) -> dict[str, Any]:
        """List all industry briefs."""
        return self._get("/api/v1/industry-briefs/", **params)

    def get_industry_brief(self, slug: str) -> dict[str, Any]:
        """Get industry brief by slug."""
        return self._get(f"/api/v1/industry-briefs/" + slug + "/")

    def list_loyalty_programs(self, **params: Any) -> dict[str, Any]:
        """List all loyalty programs."""
        return self._get("/api/v1/loyalty-programs/", **params)

    def get_loyalty_program(self, slug: str) -> dict[str, Any]:
        """Get loyalty program by slug."""
        return self._get(f"/api/v1/loyalty-programs/" + slug + "/")

    def list_tools(self, **params: Any) -> dict[str, Any]:
        """List all tools."""
        return self._get("/api/v1/tools/", **params)

    def get_tool(self, slug: str) -> dict[str, Any]:
        """Get tool by slug."""
        return self._get(f"/api/v1/tools/" + slug + "/")

    def search(self, query: str, **params: Any) -> dict[str, Any]:
        """Search across all content."""
        return self._get(f"/api/v1/search/", q=query, **params)

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> AirlineFYI:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()
