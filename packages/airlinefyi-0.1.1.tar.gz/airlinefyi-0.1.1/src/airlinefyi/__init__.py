"""Python API client for airlinefyi.com."""

__version__ = "0.1.0"
