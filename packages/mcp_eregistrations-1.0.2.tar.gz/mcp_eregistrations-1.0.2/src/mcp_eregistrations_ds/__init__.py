"""MCP server for eRegistrations Display System (DS)."""
