"""HTTP client for the DS Django REST Framework API."""

from __future__ import annotations

from typing import Any

import httpx

from mcp_eregistrations_ds.ds_client.errors import (
    DSAuthenticationError,
    DSClientError,
    DSConnectionError,
    DSNotFoundError,
    DSPermissionError,
    DSServerError,
    DSTimeoutError,
)


class DSClient:
    """Async HTTP client for DS REST API.

    Usage::

        async with DSClient(base_url="https://jamaica.eregistrations.org") as c:
            files = await c.get_paginated("/backend/admin/files")
    """

    def __init__(
        self,
        base_url: str,
        token: str | None = None,
        timeout: float = 30.0,
    ):
        self._base_url = base_url.rstrip("/")
        self._token = token
        self._timeout = timeout
        self._client: httpx.AsyncClient | None = None
        self._instance: str | None = None  # Set by for_instance()

    async def __aenter__(self) -> DSClient:
        # Try shared keyring if no in-memory token
        if not self._token and self._instance:
            from mcp_eregistrations_common.auth import get_or_refresh_token

            self._token = await get_or_refresh_token(self._instance)

        headers: dict[str, str] = {}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        self._client = httpx.AsyncClient(
            base_url=self._base_url,
            headers=headers,
            timeout=self._timeout,
        )
        return self

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._client:
            await self._client.aclose()
            self._client = None

    def _raise_for_status(self, response: httpx.Response) -> None:
        """Translate HTTP status codes to DS errors."""
        if response.is_success:
            return
        status = response.status_code
        detail = ""
        try:
            detail = response.json().get("detail", response.text)
        except Exception:
            detail = response.text

        if status == 401:
            raise DSAuthenticationError(detail, status_code=status)
        if status == 403:
            raise DSPermissionError(detail, status_code=status)
        if status == 404:
            raise DSNotFoundError(detail, status_code=status)
        if status >= 500:
            raise DSServerError(detail, status_code=status)
        # Generic 4xx client error
        raise DSClientError(f"HTTP {status}: {detail}", status_code=status)

    async def get(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> Any:
        """GET request returning JSON response."""
        assert self._client is not None, (
            "DSClient must be used as async context manager"
        )
        kwargs: dict[str, Any] = {"params": params}
        if timeout is not None:
            kwargs["timeout"] = httpx.Timeout(timeout)
        try:
            response = await self._client.get(path, **kwargs)
        except httpx.ConnectError as e:
            raise DSConnectionError(str(e)) from e
        except httpx.TimeoutException as e:
            raise DSTimeoutError(str(e)) from e
        self._raise_for_status(response)
        return response.json()

    async def get_paginated(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        timeout: float | None = None,
    ) -> dict[str, Any]:
        """GET for DRF paginated endpoints.

        Normalizes: results->items, adds has_next/page.
        """
        params = params or {}
        page = params.get("page", 1)
        raw = await self.get(path, params=params, timeout=timeout)

        # DRF PageNumberPagination format
        if isinstance(raw, dict) and "results" in raw:
            items = raw["results"]
            return {
                "items": items,
                "count": raw.get("count", len(items)),
                "page": page,
                "page_size": len(items),
                "has_next": raw.get("next") is not None,
            }
        # Non-paginated list response — apply client-side pagination
        if isinstance(raw, list):
            default_page_size = 20
            total = len(raw)
            start = (page - 1) * default_page_size
            end = start + default_page_size
            items = raw[start:end]
            return {
                "items": items,
                "count": total,
                "page": page,
                "page_size": len(items),
                "has_next": end < total,
            }
        # Already a dict without "results" key
        result: dict[str, Any] = raw
        return result

    @classmethod
    def for_instance(cls, instance: str | None = None) -> DSClient:
        """Create DSClient from instance profile config.

        Looks up ds_url from common config (built-in or custom profiles).
        Requires an explicit instance name — no env var fallback.
        Token is retrieved from DS's own in-process token store
        (populated by ds_auth_login), with keyring fallback on __aenter__.
        """
        from fastmcp.exceptions import ToolError

        from mcp_eregistrations_common.config import get_instance_config

        if instance is None:
            raise ToolError(
                "No instance specified. Pass instance='<name>'. "
                "Use ds_instance_list to see available instances."
            )

        config = get_instance_config(instance, component="ds")
        ds_url = config.get("ds_url")

        if not ds_url:
            raise ToolError(
                f"No DS URL configured for instance '{instance}'. "
                f"Use ds_instance_add to register an instance."
            )

        token = _ds_tokens.get(instance)
        client = cls(base_url=ds_url, token=token)
        client._instance = instance
        return client


# DS-local in-process token store (populated by ds_auth_login)
_ds_tokens: dict[str, str] = {}


def store_ds_token(instance: str, token: str) -> None:
    """Store an access token for a DS instance."""
    _ds_tokens[instance] = token


def get_ds_token(instance: str) -> str | None:
    """Get stored access token for a DS instance."""
    return _ds_tokens.get(instance)
