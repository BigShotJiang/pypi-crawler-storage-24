"""DS REST API client."""

from mcp_eregistrations_ds.ds_client.client import (
    DSClient,
    get_ds_token,
    store_ds_token,
)
from mcp_eregistrations_ds.ds_client.errors import (
    DSAuthenticationError,
    DSClientError,
    DSConnectionError,
    DSNotFoundError,
    DSPermissionError,
    DSServerError,
    DSTimeoutError,
    translate_error,
)

__all__ = [
    "DSClient",
    "DSAuthenticationError",
    "DSClientError",
    "DSConnectionError",
    "DSNotFoundError",
    "DSPermissionError",
    "DSServerError",
    "DSTimeoutError",
    "get_ds_token",
    "store_ds_token",
    "translate_error",
]
