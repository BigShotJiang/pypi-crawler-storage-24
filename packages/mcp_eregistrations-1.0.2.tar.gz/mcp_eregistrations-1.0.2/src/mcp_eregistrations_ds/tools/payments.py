"""Payment monitoring tools."""

from __future__ import annotations

from typing import Any

from mcp.types import ToolAnnotations

from mcp_eregistrations_ds.ds_client import DSClient, DSClientError, translate_error
from mcp_eregistrations_ds.server import mcp


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def payment_provider_list(
    instance: str | None = None,
) -> dict[str, Any]:
    """List configured payment providers.

    Args:
        instance: Instance profile name.

    Returns:
        dict with total, providers (list of code, name, config).
    """
    try:
        async with DSClient.for_instance(instance) as client:
            data = await client.get("/backend/payment_providers")
    except DSClientError as e:
        raise translate_error(e, resource_type="payment_provider") from e

    providers = data if isinstance(data, list) else data.get("results", [])
    return {"total": len(providers), "providers": providers}


@mcp.tool(annotations=ToolAnnotations(readOnlyHint=True))
async def payment_transaction_list(
    file_id: str | None = None,
    page: int = 1,
    instance: str | None = None,
) -> dict[str, Any]:
    """List payment transactions.

    Args:
        file_id: Filter by file UUID.
        page: Page number (default: 1).
        instance: Instance profile name.

    Returns:
        dict with items (transaction_id, status, total_cost, provider),
        count.
    """
    params: dict[str, Any] = {"page": page}
    if file_id:
        params["file_id"] = file_id

    try:
        async with DSClient.for_instance(instance) as client:
            return await client.get_paginated(
                "/backend/payment_transaction", params=params
            )
    except DSClientError as e:
        raise translate_error(e, resource_type="payment_transaction") from e
