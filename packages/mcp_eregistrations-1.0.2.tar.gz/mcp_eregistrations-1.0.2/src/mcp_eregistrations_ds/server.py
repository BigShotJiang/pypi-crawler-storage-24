"""DS MCP Server — admin/ops monitoring for eRegistrations Display System."""

from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-ds",
    instructions=(
        "DS (Display System) admin/ops tools for monitoring application files, "
        "payments, workflows, documents, and system health. "
        "All tools are read-only. Use ds_auth_login to authenticate first."
    ),
)


import mcp_eregistrations_ds.tools.documents  # noqa: F401, E402
import mcp_eregistrations_ds.tools.files  # noqa: F401, E402
import mcp_eregistrations_ds.tools.financial_reports  # noqa: F401, E402
import mcp_eregistrations_ds.tools.instances  # noqa: F401, E402
import mcp_eregistrations_ds.tools.messages  # noqa: F401, E402
import mcp_eregistrations_ds.tools.payments  # noqa: F401, E402
import mcp_eregistrations_ds.tools.processes  # noqa: F401, E402
import mcp_eregistrations_ds.tools.system  # noqa: F401, E402


def main() -> None:
    """Entry point for mcp-eregistrations-ds."""
    mcp.run()


if __name__ == "__main__":
    main()
