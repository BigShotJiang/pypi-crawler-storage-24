"""Form patch engine for safe Form.io JSON editing."""

from mcp_eregistrations_bpa.patch.adapters.base import FormAdapter
from mcp_eregistrations_bpa.patch.adapters.role_form import RoleFormAdapter
from mcp_eregistrations_bpa.patch.diff import (
    DiffEntry,
    DiffResult,
    DiffType,
    generate_diff,
)
from mcp_eregistrations_bpa.patch.engine import (
    FormPatchEngine,
    PatchResult,
)
from mcp_eregistrations_bpa.patch.operations import (
    Operation,
    OperationType,
    validate_operation,
)

__all__ = [
    "DiffEntry",
    "DiffResult",
    "DiffType",
    "FormAdapter",
    "FormPatchEngine",
    "Operation",
    "OperationType",
    "PatchResult",
    "RoleFormAdapter",
    "generate_diff",
    "validate_operation",
]
