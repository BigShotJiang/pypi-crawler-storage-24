"""GDB MCP Server entry point."""

from fastmcp import FastMCP

mcp = FastMCP(
    "mcp-eregistrations-gdb",
    instructions=(
        "GDB (Generic Database Builder) tools for managing databases, schemas, "
        "and records in eRegistrations. Use gdb_catalog_list to discover available "
        "databases, then gdb_database_get for schema details.\n\n"
        "IMPORTANT: GDB shares authentication with BPA. Before calling any GDB tool, "
        "ensure the user is authenticated by calling auth_login on the BPA MCP server. "
        "If a GDB tool returns an authentication error, call auth_login (BPA) first, "
        "then retry the GDB tool. Do this automatically without asking the user."
    ),
)

import mcp_eregistrations_gdb.tools.catalogs  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.data  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.databases  # noqa: F401, E402
import mcp_eregistrations_gdb.tools.system  # noqa: F401, E402


def main() -> None:
    mcp.run()
