"""Take upload orchestration for Evercoast CLI.

Manages the full take upload pipeline: metadata reading, API calls,
frame processing, S3 uploads, and finalization. Replicates the
Mavericks desktop app upload workflow.
"""

import os
import shutil
from pathlib import Path

from rich.console import Console
from rich.progress import (
    BarColumn,
    DownloadColumn,
    Progress,
    SpinnerColumn,
    TextColumn,
    TimeRemainingColumn,
    TransferSpeedColumn,
)
from rich.table import Table

from .api import (
    APIError,
    finish_take_file_upload,
    finish_take_upload,
    start_take_upload,
)
from .raw_frames import (
    check_ffmpeg,
    chunk_raw_frames,
    generate_metadata_tar,
    generate_preview_mp4,
    generate_thumbnail,
    parse_take_naming,
    read_timestamp_json,
)
from .upload import (
    _upload_single_file_with_retry,
    format_size,
)

console = Console()


def get_temp_dir(dir_name: str) -> str:
    """Get the temp directory for intermediate files.

    Creates ~/.evercoast/tmp/{dir_name}/ if it doesn't exist.
    """
    temp_dir = Path.home() / ".evercoast" / "tmp" / dir_name
    temp_dir.mkdir(parents=True, exist_ok=True)
    return str(temp_dir)


class TakeUploader:
    """Orchestrates the full take upload pipeline.

    Steps:
    1. Validate prerequisites (ffmpeg, .timestamp.json)
    2. Read metadata and parse take naming
    3. Check for existing upload (resume support)
    4. Start take upload via API → get slug
    5. Upload .timestamp.json to S3
    6. Generate and upload meta_data.tar.gz
    7. Generate and upload thumbnail.png
    8. Generate and upload preview.mp4
    9. Upload audio WAV (if exists)
    10. Chunk and upload raw frame archives
    11. Finalize upload via API
    """

    def __init__(
        self,
        take_dir: str,
        api_url: str,
        token: str,
        s3_client,
        bucket: str,
        region: str,
        no_preview: bool = False,
    ):
        self.take_dir = os.path.abspath(take_dir)
        self.dir_name = os.path.basename(self.take_dir)
        self.api_url = api_url
        self.token = token
        self.s3_client = s3_client
        self.bucket = bucket
        self.region = region
        self.no_preview = no_preview
        self.slug = None
        self.metadata = None
        self.naming = None
        self.temp_dir = get_temp_dir(self.dir_name)

    def _s3_prefix(self) -> str:
        """S3 key prefix for this take (e.g. 'production.scene.ec.take.001/')."""
        return f"{self.dir_name}/"

    def _upload_file(self, local_path: str, s3_filename: str) -> None:
        """Upload a single file to S3 under the take's prefix with progress."""
        s3_key = f"{self._s3_prefix()}{s3_filename}"
        file_size = os.path.getsize(local_path)

        with Progress(
            SpinnerColumn(),
            TextColumn("[bold blue]{task.description}"),
            BarColumn(),
            DownloadColumn(),
            TransferSpeedColumn(),
            TimeRemainingColumn(),
            console=console,
        ) as progress:
            file_task = progress.add_task(s3_filename, total=file_size)

            _upload_single_file_with_retry(
                s3_client=self.s3_client,
                filepath=local_path,
                bucket=self.bucket,
                s3_key=s3_key,
                extra_args={"ChecksumAlgorithm": "SHA256"},
                progress=progress,
                file_task=file_task,
                overall_task=file_task,  # use same task for both
            )

    def _check_s3_file_exists(self, s3_filename: str) -> bool:
        """Check if a file already exists at the take's S3 path."""
        s3_key = f"{self._s3_prefix()}{s3_filename}"
        try:
            self.s3_client.head_object(Bucket=self.bucket, Key=s3_key)
            return True
        except Exception:
            return False

    def run(self, dry_run: bool = False) -> bool:
        """Execute the full take upload pipeline.

        Args:
            dry_run: If True, show what would be done without uploading

        Returns:
            True if upload completed successfully
        """
        total_steps = 8 if not self.no_preview else 6
        step = 0

        def step_header(label: str):
            nonlocal step
            step += 1
            console.print(f"\n[bold cyan]Step {step}/{total_steps}: {label}[/]")

        try:
            # Step 1: Validate prerequisites
            step_header("Validating prerequisites")
            if not self.no_preview:
                check_ffmpeg()
            # Read metadata if not already loaded (may have been set by caller)
            if not self.metadata:
                self.metadata = read_timestamp_json(self.take_dir)
            if not self.naming:
                self.naming = parse_take_naming(self.dir_name)
            console.print("[green]Prerequisites OK[/]")

            # Show take summary
            self._print_summary()

            if dry_run:
                self._print_dry_run()
                return True

            # Step 2: Start take upload on Cloudbreak
            step_header("Creating take on Cloudbreak")
            self._start_or_resume_upload()
            console.print(f"[green]Take slug: {self.slug}[/]")

            # Step 3: Upload .timestamp.json
            step_header("Uploading metadata")
            self._upload_timestamp_json()
            self._upload_metadata_tar()

            # Step 4-5: Generate and upload preview (unless --no-preview)
            if not self.no_preview:
                step_header("Generating thumbnail")
                self._generate_and_upload_thumbnail()

                step_header("Generating preview video")
                self._generate_and_upload_preview()

            # Step 6: Upload audio
            step_header("Uploading audio")
            self._upload_audio()

            # Step 7: Chunk and upload raw frames
            step_header("Chunking and uploading raw frames")
            self._chunk_and_upload_frames()

            # Step 8: Finalize
            step_header("Finalizing upload")
            finish_take_upload(self.api_url, self.token, self.slug)
            console.print("[bold green]Take upload complete![/]")

            # Clean up temp directory
            shutil.rmtree(self.temp_dir, ignore_errors=True)

            return True

        except KeyboardInterrupt:
            console.print("\n[yellow]Upload interrupted. You can resume by running the same command again.[/]")
            return False
        except Exception as e:
            console.print(f"\n[red]Error: {e}[/]")
            if self.slug:
                console.print(
                    f"[dim]Take slug '{self.slug}' was created. "
                    f"Re-run the command to resume, or the take will remain in UPLOADING status.[/]"
                )
            return False

    def _print_summary(self):
        """Print a formatted take summary."""
        table = Table(title="Take Summary", show_header=False, padding=(0, 2))
        table.add_column("Key", style="bold")
        table.add_column("Value")

        table.add_row("Directory", self.dir_name)
        table.add_row("Production", self.naming["sequence"])
        table.add_row("Scene", self.naming["scene"])
        table.add_row("Take", self.naming["take_number"])
        table.add_row("FPS", str(self.metadata.get("frames_per_second", 15)))
        table.add_row("Total Frames", str(self.metadata.get("total_frames", "unknown")))
        table.add_row("Format", self.metadata.get("formats_recorded", "RAW"))

        cameras = self.metadata.get("cameras", [])
        table.add_row("Cameras", str(len(cameras)))

        preview_cam = self.metadata.get("preview_camera", "none")
        table.add_row("Preview Camera", preview_cam)

        if self.metadata.get("camera_rotation"):
            table.add_row("Rotation", f"{self.metadata['camera_rotation']}°")

        console.print()
        console.print(table)
        console.print()

    def _print_dry_run(self):
        """Show what would be uploaded in dry-run mode."""
        console.print("[bold yellow]DRY RUN — no files will be uploaded[/]")
        console.print()
        console.print("Would upload to:")
        console.print(f"  s3://{self.bucket}/{self._s3_prefix()}")
        console.print()
        console.print("Files that would be created and uploaded:")
        console.print("  .timestamp.json")
        console.print("  meta_data.tar.gz (if meta_data/ exists)")
        if not self.no_preview:
            console.print("  thumbnail.png")
            console.print("  preview.mp4")

        from .raw_frames import _find_audio_file
        audio = _find_audio_file(self.take_dir, self.naming)
        if audio:
            console.print(f"  {audio}")

        # Count raw files to estimate archive count
        raw_count = len([f for f in os.listdir(self.take_dir) if f.endswith(".raw")])
        if raw_count > 0:
            # Estimate frame count from raw files
            frame_nums = set()
            for f in os.listdir(self.take_dir):
                if f.endswith(".raw"):
                    parts = f.split(".")
                    if len(parts) >= 3:
                        try:
                            frame_nums.add(int(parts[-2]))
                        except ValueError:
                            pass

            if frame_nums:
                max_frame = max(frame_nums)
                num_archives = (max_frame - 1) // 32 + 1
                console.print(f"  ~{num_archives} raw_frames.*.tar.gz archives ({raw_count} raw files)")

        console.print()

    def _start_or_resume_upload(self):
        """Start a new take upload or resume an existing one.

        Tries to create a new take via the API. If the take already exists
        (API returns an error because the take_bucket_name is taken),
        we look for an existing take in UPLOADING status to resume.
        """
        try:
            self.slug = start_take_upload(
                api_url=self.api_url,
                token=self.token,
                bucket=self.bucket,
                take_path=f"{self.dir_name}/",
                take_details=self.metadata,
                sequence=self.naming["sequence"],
                scene=self.naming["scene"],
                element=self.naming["element"],
                take_number=self.naming["take_number"],
            )
            if not self.slug:
                raise RuntimeError("Failed to create take on Cloudbreak (no slug returned)")
            console.print("[green]  New take created[/]")
        except APIError as e:
            # Take might already exist — try to find it for resume
            # The slug format is: {company}-{dir_name} with dots replaced by dashes
            # We can try the expected slug based on directory name
            expected_slug_suffix = self.dir_name.lower().replace(".", "-")
            console.print(
                f"[yellow]  Take creation returned error: {e}[/]"
            )
            console.print("[cyan]  Checking if take already exists for resume...[/]")

            # Try to look up by the expected slug pattern
            from .api import get_take_details
            # We don't know the full slug (need company prefix), so we
            # re-raise the error and let the user handle it
            raise RuntimeError(
                f"Could not create take: {e}\n"
                f"If this take was previously started, it may need to be "
                f"deleted from Cloudbreak before re-uploading."
            )

    def _upload_timestamp_json(self):
        """Upload .timestamp.json to S3."""
        ts_path = os.path.join(self.take_dir, ".timestamp.json")
        if self._check_s3_file_exists(".timestamp.json"):
            console.print("[dim]  .timestamp.json already uploaded, skipping[/]")
        else:
            self._upload_file(ts_path, ".timestamp.json")
            console.print("[green]  .timestamp.json uploaded[/]")

    def _upload_metadata_tar(self):
        """Generate and upload meta_data.tar.gz."""
        tar_path = generate_metadata_tar(self.take_dir, self.temp_dir)
        if tar_path:
            if self._check_s3_file_exists("meta_data.tar.gz"):
                console.print("[dim]  meta_data.tar.gz already uploaded, skipping[/]")
            else:
                self._upload_file(tar_path, "meta_data.tar.gz")
                console.print("[green]  meta_data.tar.gz uploaded[/]")
            # Clean up temp file
            os.unlink(tar_path)

    def _generate_and_upload_thumbnail(self):
        """Generate thumbnail and upload to S3."""
        if self._check_s3_file_exists("thumbnail.png"):
            console.print("[dim]  thumbnail.png already uploaded, skipping[/]")
            return

        thumbnail_path = generate_thumbnail(
            self.take_dir, self.metadata, self.temp_dir
        )
        if thumbnail_path:
            self._upload_file(thumbnail_path, "thumbnail.png")
            # Notify Cloudbreak
            try:
                finish_take_file_upload(
                    self.api_url, self.token, self.slug,
                    "thumbnail", "thumbnail.png",
                )
            except APIError as e:
                console.print(f"[yellow]Warning: Failed to notify thumbnail upload: {e}[/]")
            console.print("[green]  thumbnail.png uploaded[/]")
            os.unlink(thumbnail_path)

    def _generate_and_upload_preview(self):
        """Generate preview MP4 and upload to S3."""
        if self._check_s3_file_exists("preview.mp4"):
            console.print("[dim]  preview.mp4 already uploaded, skipping[/]")
            return

        mp4_path = generate_preview_mp4(
            self.take_dir, self.metadata, self.temp_dir, self.naming
        )
        if mp4_path:
            self._upload_file(mp4_path, "preview.mp4")
            # Notify Cloudbreak
            try:
                finish_take_file_upload(
                    self.api_url, self.token, self.slug,
                    "preview", "preview.mp4",
                )
            except APIError as e:
                console.print(f"[yellow]Warning: Failed to notify preview upload: {e}[/]")
            console.print("[green]  preview.mp4 uploaded[/]")
            os.unlink(mp4_path)

    def _upload_audio(self):
        """Upload audio WAV file if it exists."""
        from .raw_frames import _find_audio_file

        audio_file = _find_audio_file(self.take_dir, self.naming)
        if not audio_file:
            console.print("[dim]  No audio file found, skipping[/]")
            return

        if self._check_s3_file_exists(audio_file):
            console.print(f"[dim]  {audio_file} already uploaded, skipping[/]")
            return

        audio_path = os.path.join(self.take_dir, audio_file)
        self._upload_file(audio_path, audio_file)

        # Notify Cloudbreak
        try:
            finish_take_file_upload(
                self.api_url, self.token, self.slug,
                "audio", audio_file,
            )
        except APIError as e:
            console.print(f"[yellow]Warning: Failed to notify audio upload: {e}[/]")
        console.print(f"[green]  {audio_file} uploaded[/]")

    def _chunk_and_upload_frames(self):
        """Chunk raw frames into archives and upload each one."""
        archives = chunk_raw_frames(self.take_dir, self.temp_dir)

        if not archives:
            console.print("[yellow]  No raw frame archives to upload[/]")
            return

        console.print(f"[cyan]  Uploading {len(archives)} frame archives...[/]")

        total_size = sum(os.path.getsize(p) for p, _ in archives)
        uploaded_size = 0
        skipped = 0

        for archive_path, frame_count in archives:
            archive_name = os.path.basename(archive_path)

            if self._check_s3_file_exists(archive_name):
                console.print(f"[dim]  {archive_name} already uploaded, skipping[/]")
                skipped += 1
                # Clean up local archive
                if os.path.exists(archive_path):
                    os.unlink(archive_path)
                continue

            archive_size = os.path.getsize(archive_path)
            self._upload_file(archive_path, archive_name)
            uploaded_size += archive_size

            # Clean up local archive after upload
            os.unlink(archive_path)

        uploaded_count = len(archives) - skipped
        if uploaded_count > 0:
            console.print(
                f"[green]  {uploaded_count} archives uploaded "
                f"({format_size(uploaded_size)})[/]"
            )
        if skipped > 0:
            console.print(f"[dim]  {skipped} archives already existed, skipped[/]")
