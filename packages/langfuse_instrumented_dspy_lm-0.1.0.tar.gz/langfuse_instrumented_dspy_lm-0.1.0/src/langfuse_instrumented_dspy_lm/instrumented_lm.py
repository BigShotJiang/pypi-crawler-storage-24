"""
Custom DSPy LM that captures token usage from LiteLLM responses
and sets OpenInference span attributes for Langfuse integration.

This addresses the issue where openinference-instrumentation-dspy
doesn't properly capture token counts for LLM models.
"""

import logging
from typing import Any

import dspy
from openinference.semconv.trace import SpanAttributes
from opentelemetry import trace

logger = logging.getLogger(__name__)


class LangfuseInstrumentedLm(dspy.LM):
    """
    DSPy LM that instruments LiteLLM responses with OpenInference
    span attributes for token usage tracking in Langfuse.

    This class overrides forward() and aforward() to intercept the LiteLLM
    ModelResponse and set token usage metrics as OpenTelemetry span attributes
    using the OpenInference semantic conventions.

    By overriding forward/aforward instead of __call__/acall, we ensure the
    DSPyInstrumentor's wrapper remains intact and creates the proper LLM span
    that we can then enrich with token attributes.

    Usage:
        from langfuse_instrumented_dspy_lm import LangfuseInstrumentedLm

        lm = LangfuseInstrumentedLm(
            "gemini/gemini-2.0-flash",
            max_tokens=10000,
            temperature=0,
            cache=False,
        )
        dspy.configure(lm=lm)
    """

    def _set_span_attributes(self, response: Any) -> None:
        """
        Extract token usage from LiteLLM ModelResponse and set OpenInference
        span attributes on the current OpenTelemetry span.

        Args:
            response: LiteLLM ModelResponse object containing usage information

        The method safely handles:
        - Missing usage attribute
        - Missing individual token fields
        - Missing token details objects
        - Non-recording spans
        """
        span = trace.get_current_span()

        if not span.is_recording():
            return

        try:
            # Get usage information
            usage = getattr(response, "usage", None)
            if usage is None:
                return

            # Primary token counts
            if usage.prompt_tokens is not None:
                span.set_attribute(
                    SpanAttributes.LLM_TOKEN_COUNT_PROMPT, usage.prompt_tokens
                )

            if usage.completion_tokens is not None:
                span.set_attribute(
                    SpanAttributes.LLM_TOKEN_COUNT_COMPLETION, usage.completion_tokens
                )

            if usage.total_tokens is not None:
                span.set_attribute(
                    SpanAttributes.LLM_TOKEN_COUNT_TOTAL, usage.total_tokens
                )

            # Cost from usage
            if getattr(usage, "cost", None) is not None:
                span.set_attribute(SpanAttributes.LLM_COST_TOTAL, usage.cost)

            # Completion token details
            completion_details = getattr(usage, "completion_tokens_details", None)
            if completion_details is not None:
                reasoning_tokens = getattr(completion_details, "reasoning_tokens", None)
                if reasoning_tokens is not None:
                    span.set_attribute(
                        SpanAttributes.LLM_TOKEN_COUNT_COMPLETION_DETAILS_REASONING,
                        reasoning_tokens,
                    )

            # Prompt token details
            prompt_details = getattr(usage, "prompt_tokens_details", None)
            if prompt_details is not None:
                cached_tokens = getattr(prompt_details, "cached_tokens", None)
                if cached_tokens is not None:
                    span.set_attribute(
                        SpanAttributes.LLM_TOKEN_COUNT_PROMPT_DETAILS_CACHE_READ,
                        cached_tokens,
                    )

        except Exception as e:
            logger.warning("Failed to set span attributes: %s", str(e), exc_info=True)

    def forward(self, prompt=None, messages=None, **kwargs):
        """
        Synchronous forward with token usage instrumentation.

        Calls parent's forward() and then sets token usage span attributes
        on the current span (which is the LLM span created by DSPyInstrumentor).
        """
        response = super().forward(prompt=prompt, messages=messages, **kwargs)
        self._set_span_attributes(response)
        return response

    async def aforward(self, prompt=None, messages=None, **kwargs):
        """
        Asynchronous forward with token usage instrumentation.

        Calls parent's aforward() and then sets token usage span attributes
        on the current span (which is the LLM span created by DSPyInstrumentor).
        """
        response = await super().aforward(prompt=prompt, messages=messages, **kwargs)
        self._set_span_attributes(response)
        return response
