"""
langfuse-instrumented-dspy-lm

Custom DSPy LM class for token usage tracking with Langfuse.
"""

from langfuse_instrumented_dspy_lm._version import __version__
from langfuse_instrumented_dspy_lm.instrumented_lm import LangfuseInstrumentedLm

__all__ = ["LangfuseInstrumentedLm", "__version__"]
