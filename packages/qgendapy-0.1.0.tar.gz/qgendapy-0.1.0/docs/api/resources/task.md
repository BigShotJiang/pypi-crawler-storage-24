# Task

::: qgendapy.resources.task
