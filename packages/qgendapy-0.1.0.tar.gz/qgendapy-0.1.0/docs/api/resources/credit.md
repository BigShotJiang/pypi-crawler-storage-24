# Credit

::: qgendapy.resources.credit
