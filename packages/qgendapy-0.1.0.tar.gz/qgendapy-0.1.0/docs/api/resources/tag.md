# Tag

::: qgendapy.resources.tag
