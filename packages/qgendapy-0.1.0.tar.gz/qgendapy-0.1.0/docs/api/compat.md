# Compat (Legacy)

::: qgendapy.compat
