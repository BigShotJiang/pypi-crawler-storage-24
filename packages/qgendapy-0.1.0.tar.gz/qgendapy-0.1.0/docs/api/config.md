# Configuration

::: qgendapy._config
