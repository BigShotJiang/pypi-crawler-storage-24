# Response

::: qgendapy.response
