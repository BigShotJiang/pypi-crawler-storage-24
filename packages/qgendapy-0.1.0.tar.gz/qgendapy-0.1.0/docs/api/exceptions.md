# Exceptions

::: qgendapy.exceptions
