"""Unit tests for platform validation of structured outputs.

Tests the fix in vllm_spyre/platform.py that strips structured_outputs
from SamplingParams during request validation.
"""

from unittest.mock import MagicMock
import pytest

from vllm import SamplingParams
from vllm.inputs.data import token_inputs
from vllm.pooling_params import PoolingParams
from vllm.sampling_params import StructuredOutputsParams
from vllm_spyre.platform import SpyrePlatform

pytestmark = pytest.mark.skip_global_cleanup


@pytest.fixture(autouse=True)
def mock_spyre_config():
    """Mock SpyrePlatform._config for all tests."""
    original_config = SpyrePlatform._config
    mock_config = MagicMock()
    mock_config.model_config.max_model_len = 512
    SpyrePlatform._config = mock_config
    yield mock_config
    SpyrePlatform._config = original_config


class TestStructuredOutputValidation:
    """Test that platform validation strips structured outputs from requests."""

    def test_strips_structured_outputs(self):
        """Test that validate_request sets structured_outputs to None."""
        params = SamplingParams(
            max_tokens=20, structured_outputs=StructuredOutputsParams(json_object=True)
        )

        assert params.structured_outputs is not None

        processed_inputs = token_inputs(prompt_token_ids=[1, 2, 3])
        SpyrePlatform.validate_request(processed_inputs, params)

        assert params.structured_outputs is None

    def test_logs_warning_when_stripping(self, caplog_vllm_spyre):
        """Test that a warning is logged when stripping structured_outputs."""
        params = SamplingParams(
            max_tokens=20, structured_outputs=StructuredOutputsParams(json_object=True)
        )

        processed_inputs = token_inputs(prompt_token_ids=[1, 2, 3])
        SpyrePlatform.validate_request(processed_inputs, params)

        assert len(caplog_vllm_spyre.records) > 0
        warning_record = caplog_vllm_spyre.records[0]
        assert warning_record.levelname == "WARNING"
        assert "Structured outputs" in warning_record.message
        assert "not supported" in warning_record.message

    @pytest.mark.parametrize(
        "structured_output",
        [
            StructuredOutputsParams(json_object=True),
            StructuredOutputsParams(regex="[0-9]+"),
        ],
    )
    def test_strips_different_structured_output_types(self, structured_output):
        """Test validation with different types of structured outputs."""
        params = SamplingParams(max_tokens=20, structured_outputs=structured_output)

        assert params.structured_outputs is not None

        processed_inputs = token_inputs(prompt_token_ids=[1, 2, 3])
        SpyrePlatform.validate_request(processed_inputs, params)

        assert params.structured_outputs is None

    def test_preserves_other_sampling_params(self):
        """Test that other sampling params are not affected by the fix."""
        params = SamplingParams(
            max_tokens=20,
            temperature=0.5,
            top_p=0.9,
            top_k=50,
            structured_outputs=StructuredOutputsParams(json_object=True),
        )

        # Store original values
        original_values = {
            "max_tokens": params.max_tokens,
            "temperature": params.temperature,
            "top_p": params.top_p,
            "top_k": params.top_k,
        }

        processed_inputs = token_inputs(prompt_token_ids=[1, 2, 3])
        SpyrePlatform.validate_request(processed_inputs, params)

        # Verify other params are unchanged
        assert params.max_tokens == original_values["max_tokens"]
        assert params.temperature == original_values["temperature"]
        assert params.top_p == original_values["top_p"]
        assert params.top_k == original_values["top_k"]
        # But structured_outputs should be None
        assert params.structured_outputs is None

    def test_does_not_affect_pooling_params(self):
        """Test that PoolingParams are not affected (early return in validate_request)."""
        pooling_params = PoolingParams()

        # Should not raise any errors and should return early
        processed_inputs = token_inputs(prompt_token_ids=[1, 2, 3])
        SpyrePlatform.validate_request(processed_inputs, pooling_params)

        # PoolingParams don't have structured_outputs, so just verify no exception
        assert True  # If we got here, the early return worked


# Made with Bob
