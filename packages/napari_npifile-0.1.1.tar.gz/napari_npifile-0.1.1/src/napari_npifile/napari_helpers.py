import collections.abc

import napari
import napari.utils.notifications

#
# layer manipulation
#


def clear_all_layers() -> None:
    viewer = napari.current_viewer()
    viewer.layers.clear()


def hide_all_layers() -> None:
    viewer = napari.current_viewer()
    for layer in viewer.layers:
        layer.visible = False


#
# viewer property setters
#


def viewer_set_attr_properties(attr_name, properties: dict | None) -> None:
    if properties is None:
        return
    viewer = napari.current_viewer()
    for key, value in properties.items():
        attr = getattr(viewer, attr_name)
        setattr(attr, key, value)


def viewer_set_axis_labels(labels: collections.abc.Sequence[str] | None) -> None:
    """
    We can't just simply call `viewer.dims.axis_labels = axis_labels`, because we can
    only do this *before* the new layers are added. Therefore, the number of viewer
    axes might differ from the number of labels provided. Solution: first force the
    viewer to have at least the required number of dims, then set the labels.
    """
    if labels is None:
        return

    viewer = napari.current_viewer()
    viewer_dim_count = viewer.dims.ndim
    label_count = len(labels)

    if label_count < viewer_dim_count:
        napari.utils.notifications.show_warning(
            f"Can't set viewer axis labels, because the viewer has {viewer_dim_count} axes, but only {label_count} labels were provided."
        )
        return
    else:
        viewer.dims.ndim = label_count
        viewer.dims.axis_labels = labels


def viewer_dims_set_point(
    axis: int | collections.abc.Sequence[int] | None,
    value: float | collections.abc.Sequence[float] | None,
) -> None:
    if (axis is None) or (value is None):
        return

    viewer = napari.current_viewer()
    viewer.dims.set_point(axis=axis, value=value)


def viewer_set_ndisplay(value: int | None) -> None:
    if value is None:
        return
    viewer = napari.current_viewer()
    viewer.dims.ndisplay = value


def viewer_set_title(value: str | None) -> None:
    if value is None:
        return
    viewer = napari.current_viewer()
    viewer.title = value
