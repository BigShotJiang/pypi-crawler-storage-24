import json
import pathlib
import zipfile

import numpy as np


class NpiFormatError(Exception):
    pass


def read_npi_format_from_npi_metadata(npi_path: pathlib.Path) -> str:
    # load the metadata from a .npi file and extract the value for 'npi_format'
    with zipfile.ZipFile(npi_path, mode="r") as npi_file:
        metadata_path = zipfile.Path(npi_file).joinpath("metadata.json")
        with metadata_path.open("r") as metadata_file:
            metadata = json.load(metadata_file)
    npi_format = metadata["npi_format"]
    return npi_format


def read_npi_v1(path: pathlib.Path) -> dict:
    # these will be returned to napari as defined in
    # https://napari.org/stable/plugins/building_a_plugin/guides.html#layer-data-tuples
    layers = []

    with zipfile.ZipFile(path, mode="r") as npi_file:
        # load metadata
        metadata_path = zipfile.Path(npi_file).joinpath("metadata.json")
        with metadata_path.open("r") as metadata_file:
            metadata = json.load(metadata_file)

        # load viewer settings
        viewer_settings_path = zipfile.Path(npi_file).joinpath("viewer_settings.json")
        if viewer_settings_path.exists():
            with viewer_settings_path.open("r") as viewer_settings_file:
                viewer_settings = json.load(viewer_settings_file)
        else:
            viewer_settings = {}

        # for each layer...
        layers_root_path = zipfile.Path(npi_file).joinpath("layers/")
        layer_paths = tuple(layers_root_path.iterdir())
        for layer_path in layer_paths:
            # load layer attributes
            attributes_path = layer_path.joinpath("attributes.json")
            with attributes_path.open("r") as attributes_file:
                attributes = json.load(attributes_file)

            # load layer data
            data_path = layer_path.joinpath("data.npy")
            with data_path.open("rb") as data_file:
                data = np.load(data_file)

            # add to layers
            layers.append(
                {
                    "data": data,
                    "attributes": attributes,
                }
            )

    return {
        "metadata": metadata,
        "layers": layers,
        "viewer_settings": viewer_settings,
    }


def read_npi(path: pathlib.Path) -> dict:
    npi_format = read_npi_format_from_npi_metadata(npi_path=path)

    readers = {
        "v1": read_npi_v1,
    }
    try:
        reader = readers[npi_format]
    except KeyError:
        raise NpiFormatError(f"Format '{npi_format}' is not supported")

    return reader(path=path)
