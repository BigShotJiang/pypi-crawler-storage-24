import collections.abc
import pathlib

import napari_npifile.napari_helpers
import napari_npifile.standalone_reader


def get_reader(path: str | tuple[str, ...]):
    return read_npi


def read_npi(path: str | tuple[str, ...]) -> list[tuple]:
    # convert path(s) to a list of pathlib.Path
    if isinstance(path, (str | pathlib.Path)):
        paths = [path]
    elif isinstance(path, collections.abc.Sequence):
        paths = path
    else:
        # TODO
        raise ValueError
    paths = [pathlib.Path(path) for path in paths]

    readers = {
        "v1": read_npi_v1,
    }

    # collect layers from all paths
    layers = []
    for path in paths:
        npi_format = napari_npifile.standalone_reader.read_npi_format_from_npi_metadata(
            npi_path=path
        )
        try:
            reader = readers[npi_format]
        except KeyError:
            raise napari_npifile.standalone_reader.NpiFormatError(
                f"Format '{npi_format}' is not supported"
            )

        layers += reader(path=path)

    if len(layers) > 0:
        return layers
    else:
        # claim file(s), but return no data
        # see https://napari.org/stable/plugins/building_a_plugin/guides.html#readers
        return [(None,)]


def read_npi_v1(path: pathlib.Path) -> list[tuple]:
    npi = napari_npifile.standalone_reader.read_npi_v1(path=path)

    # prepare LayerData tuples to be returned to napari as defined in
    # https://napari.org/stable/plugins/building_a_plugin/guides.html#layer-data-tuples
    layers = [
        (
            layer["data"],
            layer["attributes"],
            "image",
        )
        for layer in npi["layers"]
    ]

    #
    # apply viewer settings
    #

    # clear all existing layers before adding the new ones
    if npi["viewer_settings"].get("clear_existing_layers", False):
        napari_npifile.napari_helpers.clear_all_layers()

    # hide all existing layers before adding the new ones
    if npi["viewer_settings"].get("hide_existing_layers", False):
        napari_npifile.napari_helpers.hide_all_layers()

    # set window title
    napari_npifile.napari_helpers.viewer_set_title(
        value=npi["viewer_settings"].get("title"),
    )

    # ndisplay (number of displayed dimensions, i.e., 2d or 3d mode)
    # important: this must come before setting the axis labels
    # (because setting axis labels might temporarily add new axes,
    # whose size is problematic for 3d view)
    napari_npifile.napari_helpers.viewer_set_ndisplay(
        value=npi["viewer_settings"].get("ndisplay"),
    )

    # axis labels
    napari_npifile.napari_helpers.viewer_set_axis_labels(
        labels=npi["viewer_settings"].get("axis_labels"),
    )

    # properties of camera, grid, scale_bar, text_overlay
    for attr_name in ("camera", "grid", "scale_bar", "text_overlay"):
        napari_npifile.napari_helpers.viewer_set_attr_properties(
            attr_name=attr_name,
            properties=npi["viewer_settings"].get(f"{attr_name}_properties"),
        )

    # set position of the current slice/sliders
    napari_npifile.napari_helpers.viewer_dims_set_point(
        axis=npi["viewer_settings"].get("dims_set_point", {}).get("axis"),
        value=npi["viewer_settings"].get("dims_set_point", {}).get("value"),
    )

    # return LayerData tuples to napari
    return layers
