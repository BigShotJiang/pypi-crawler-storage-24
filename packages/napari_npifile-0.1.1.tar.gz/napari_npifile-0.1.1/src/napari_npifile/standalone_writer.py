import collections.abc
import json
import pathlib
import zipfile

import numpy as np


class NpiArchiveFileExistsError(Exception):
    pass


class _NpiWriterBase:
    def __init__(
        self,
        out_path: str | pathlib.Path,
        exist_ok: bool = False,
    ) -> None:
        self._out_path = pathlib.Path(out_path)
        self._create_empty_npi_file(exist_ok=exist_ok)

    @property
    def out_path(self) -> pathlib.Path:
        """
        This ensures that `out_path` does not change after initialization.
        """
        return self._out_path

    def _create_empty_npi_file(self, exist_ok: bool) -> None:
        # abort if file exists and no overwrite
        if self.out_path.exists() and (not exist_ok):
            raise FileExistsError(
                f"File '{self.out_path}' exists already -- use 'exist_ok=True' to overwrite"
            )

        # create empty ZIP archive
        self.out_path.parent.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(self.out_path, "w") as _:
            pass

    def _write_dict_as_json(self, filename_rel: str, dict_: dict) -> None:
        with zipfile.ZipFile(self.out_path, "a") as npi_file:
            json_path = zipfile.Path(npi_file).joinpath(filename_rel)
            if json_path.exists():
                raise NpiArchiveFileExistsError(
                    f"File '{json_path}' exists already in '{self.out_path}'"
                )
            with json_path.open("w") as json_file:
                json.dump(
                    obj=dict_,
                    fp=json_file,
                    indent=4,
                )

    def _write_data_as_npy(
        self,
        filename_rel: str,
        data: np.ndarray,
        np_save_kwargs: dict | None = None,
    ) -> None:
        if np_save_kwargs is None:
            np_save_kwargs = {}

        with zipfile.ZipFile(self.out_path, "a") as npi_file:
            npy_path = zipfile.Path(npi_file).joinpath(filename_rel)
            if npy_path.exists():
                raise NpiArchiveFileExistsError(
                    f"File '{npy_path}' exists already in '{self.out_path}'"
                )
            with npy_path.open("wb") as npy_file:
                np.save(file=npy_file, arr=data, **np_save_kwargs)


class NpiWriter_v1(_NpiWriterBase):
    def __init__(
        self,
        out_path: str | pathlib.Path,
        exist_ok: bool = False,
    ):
        super().__init__(out_path=out_path, exist_ok=exist_ok)

        self._write_dict_as_json(
            filename_rel="metadata.json",
            dict_={"npi_format": "v1"},
        )

    def __str__(self) -> str:
        return f"<{type(self).__name__} out_path='{self.out_path}' layer_count={self.get_layer_count()}>"

    def get_layer_count(self) -> int:
        """
        Return the number of layers currently stored in the .npi file.
        """
        with zipfile.ZipFile(self.out_path, "r") as npi_file:
            layers_root_path = zipfile.Path(npi_file).joinpath("layers/")
            layer_paths = tuple(layers_root_path.iterdir())
        return len(layer_paths)

    def get_next_free_layer_key(self) -> str:
        layer_count = self.get_layer_count()
        # TODO: check if this new key is already taken?
        return f"{layer_count:>08d}"

    def write_viewer_settings(self, settings: dict) -> None:
        try:
            self._write_dict_as_json(
                filename_rel="viewer_settings.json",
                dict_=settings,
            )
        except NpiArchiveFileExistsError as err:
            raise NpiArchiveFileExistsError(
                f"Viewer settings have already been saved for '{self.out_path}'"
            ) from err

    def write_layer(
        self,
        data: np.ndarray,
        attributes: dict | None = None,
        np_save_kwargs: dict | None = None,
    ) -> None:
        layer_key = self.get_next_free_layer_key()

        self._write_data_as_npy(
            filename_rel=f"layers/{layer_key}/data.npy",
            data=data,
            np_save_kwargs=np_save_kwargs,
        )

        if attributes is None:
            attributes = {}
        self._write_dict_as_json(
            filename_rel=f"layers/{layer_key}/attributes.json",
            dict_=attributes,
        )


def write_npi(
    out_path: str | pathlib.Path,
    data: np.ndarray,
    layer_attributes: dict | None = None,
    viewer_settings: dict | None = None,
    exist_ok: bool = False,
) -> None:
    """
    Convenience wrapper for `NpiWriter` which saves a single layer.
    """

    writer = NpiWriter_v1(
        out_path=out_path,
        exist_ok=exist_ok,
    )

    if viewer_settings is not None:
        writer.write_viewer_settings(settings=viewer_settings)

    writer.write_layer(
        data=data,
        attributes=layer_attributes,
    )


def write_multilayer_npi(
    out_path: str | pathlib.Path,
    data_seq: collections.abc.Sequence[np.ndarray],
    layer_attributes_seq: collections.abc.Sequence[dict | None] | None = None,
    viewer_settings: dict | None = None,
    exist_ok: bool = False,
) -> None:
    """
    Convenience wrapper for `NpiWriter`.
    """

    writer = NpiWriter_v1(
        out_path=out_path,
        exist_ok=exist_ok,
    )

    if viewer_settings is not None:
        writer.write_viewer_settings(settings=viewer_settings)

    if layer_attributes_seq is None:
        layer_attributes_seq = [None] * len(data_seq)

    for data, layer_attributes in zip(data_seq, layer_attributes_seq):
        writer.write_layer(
            data=data,
            attributes=layer_attributes,
        )
