import json
import pathlib
import zipfile

import napari
import numpy as np
import pytest

import napari_npifile


#
# helpers
#


@pytest.fixture
def npi_path(tmp_path):
    return pathlib.Path(tmp_path).joinpath("test.npi")


@pytest.fixture
def npi_path_2(tmp_path):
    return pathlib.Path(tmp_path).joinpath("test_2.npi")


#
# tests
#


def test_read_unsupported_format_npi(npi_path, make_napari_viewer_proxy):
    with zipfile.ZipFile(npi_path, "w") as npi_file:
        metadata_path = zipfile.Path(npi_file).joinpath("metadata.json")
        with metadata_path.open("w") as metadata_file:
            json.dump({"npi_format": "v0xDEADBEEF"}, metadata_file)
    assert npi_path.exists()

    viewer = make_napari_viewer_proxy()
    with pytest.raises(napari_npifile.NpiFormatError):
        viewer.open(npi_path, plugin="napari-npifile")


def test_read_empty_npi(npi_path, make_napari_viewer_proxy):
    assert not npi_path.exists()
    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    assert npi_path.exists()

    viewer = make_napari_viewer_proxy()
    assert len(viewer.layers) == 0
    viewer.open(npi_path, plugin="napari-npifile")
    assert len(viewer.layers) == 0


def test_read_single_layer_npi(npi_path, make_napari_viewer_proxy):
    data = np.random.random((10, 20, 30))

    assert not npi_path.exists()
    napari_npifile.write_npi(
        out_path=npi_path,
        data=data,
        layer_attributes={"colormap": "green"},
        viewer_settings={"title": "test"},
    )
    assert npi_path.exists()

    viewer = make_napari_viewer_proxy()
    viewer.open(npi_path, plugin="napari-npifile")

    assert len(viewer.layers) == 1
    assert viewer.layers[0].data.shape == data.shape
    assert np.all(viewer.layers[0].data == data)
    assert viewer.layers[0].colormap.name == "green"
    assert viewer.title == "test"


def test_read_multilayer_npi(npi_path, make_napari_viewer_proxy):
    data_seq = [
        np.random.random((5, 5)),
        np.random.random((10, 10)),
        np.random.random((3, 7)),
    ]
    attributes_seq = [
        {"name": "a", "colormap": "gray"},
        {"name": "b", "colormap": "green"},
        {"name": "c", "colormap": "magma"},
    ]

    napari_npifile.write_multilayer_npi(
        out_path=npi_path,
        data_seq=data_seq,
        layer_attributes_seq=attributes_seq,
        viewer_settings={"title": "multi_test"}
    )

    viewer = make_napari_viewer_proxy()
    viewer.open(npi_path, plugin="napari-npifile")

    assert len(viewer.layers) == len(data_seq)
    for n_layer, layer in enumerate(viewer.layers):
        assert layer.name == attributes_seq[n_layer]["name"]
        assert layer.colormap.name == attributes_seq[n_layer]["colormap"]
        assert np.all(layer.data == data_seq[n_layer])
    assert viewer.title == "multi_test"


def test_read_multiple_npi_files(npi_path, npi_path_2, make_napari_viewer_proxy):
    data_1 = np.random.random((10, 20, 30))
    data_2 = np.random.random((1, 20, 30))

    assert npi_path != npi_path_2

    napari_npifile.write_npi(
        out_path=npi_path,
        data=data_1,
        layer_attributes={"colormap": "green"},
        viewer_settings={"title": "test_1"},
    )

    napari_npifile.write_npi(
        out_path=npi_path_2,
        data=data_2,
        layer_attributes={"colormap": "red"},
        viewer_settings={"title": "test_2"},
    )

    viewer = make_napari_viewer_proxy()
    viewer.open([npi_path, npi_path_2], plugin="napari-npifile")

    assert len(viewer.layers) == 2
    assert viewer.layers[0].data.shape == data_1.shape
    assert viewer.layers[1].data.shape == data_2.shape
    assert np.all(viewer.layers[0].data == data_1)
    assert np.all(viewer.layers[1].data == data_2)
    assert viewer.layers[0].colormap.name == "green"
    assert viewer.layers[1].colormap.name == "red"
    assert viewer.title == "test_2"


def test_clear_existing_layers(npi_path, make_napari_viewer_proxy):
    data = np.random.random(size=(10, 20))

    assert not npi_path.exists()
    napari_npifile.write_npi(
        out_path=npi_path,
        data=data,
        layer_attributes={"name": "new_layer"},
        viewer_settings={"clear_existing_layers": True}
    )
    assert npi_path.exists()

    viewer = make_napari_viewer_proxy()
    viewer.add_image(np.random.random(size=(10, 20)))
    assert len(viewer.layers) == 1
    viewer.open(npi_path, plugin="napari-npifile")
    assert len(viewer.layers) == 1
    assert viewer.layers[0].name == "new_layer"
    assert np.all(viewer.layers[0].data == data)


def test_hide_existing_layers(npi_path, make_napari_viewer_proxy):
    # write .npi file
    assert not npi_path.exists()
    data = np.random.random(size=(10, 20))
    napari_npifile.write_npi(
        out_path=npi_path,
        data=data,
        layer_attributes={"name": "new_layer"},
        viewer_settings={"hide_existing_layers": True}
    )
    assert npi_path.exists()

    # create viewer with existing image layer
    viewer = make_napari_viewer_proxy()
    viewer.add_image(np.random.random(size=(10, 20)))
    assert len(viewer.layers) == 1
    assert viewer.layers[0].visible is True

    # load .npi file in viewer
    viewer.open(npi_path, plugin="napari-npifile")

    # check that existing layer is no longer visible
    assert len(viewer.layers) == 2
    assert viewer.layers[1].name == "new_layer"
    assert np.all(viewer.layers[1].data == data)
    assert viewer.layers[0].visible is False
    assert viewer.layers[1].visible is True


def test_ndisplay_and_axis_labels(npi_path, make_napari_viewer_proxy):
    data = np.random.random((2, 3, 4))
    viewer_settings = {
        "ndisplay": 3,
        "axis_labels": ["T", "Z", "Y"],
    }

    napari_npifile.write_npi(
        out_path=npi_path,
        data=data,
        viewer_settings=viewer_settings,
    )

    viewer = make_napari_viewer_proxy()
    viewer.open(npi_path, plugin="napari-npifile")

    assert viewer.dims.ndisplay == 3
    assert viewer.dims.axis_labels == ("T", "Z", "Y")


def test_dims_set_points(npi_path, make_napari_viewer_proxy):
    data = np.random.random((10, 20, 30, 40))
    viewer_settings = {
        "dims_set_point": {
            "axis": [0, 1],
            "value": [1, 2],
        }
    }

    napari_npifile.write_npi(
        out_path=npi_path,
        data=data,
        viewer_settings=viewer_settings,
    )

    viewer = make_napari_viewer_proxy()
    viewer.open(npi_path, plugin="napari-npifile")

    # set_point only works if layers existed before loading...
    assert tuple(int(item) for item in viewer.dims.point[:2]) != (1, 2)
    viewer.open(npi_path, plugin="napari-npifile")
    assert tuple(int(item) for item in viewer.dims.point[:2]) == (1, 2)


def test_camera_grid_scale_text_properties(npi_path, make_napari_viewer_proxy):
    data = np.random.random((5, 5))
    viewer_settings = {
        "camera_properties": {"center": (1.0, 2.0, 3.0), "zoom": 2.5},
        "grid_properties": {"enabled": True, "shape": (1, -1), "stride": 1, "spacing": 0.5},
        "scale_bar_properties": {"visible": True, "unit": "px", "gridded": True},
        "text_overlay_properties": {"visible": True, "text": "hello", "gridded": True, "font_size": 12},
    }

    napari_npifile.write_npi(
        out_path=npi_path,
        data=data,
        viewer_settings=viewer_settings,
    )

    viewer = make_napari_viewer_proxy()
    viewer.open(npi_path, plugin="napari-npifile")

    assert viewer.grid.spacing == viewer_settings["grid_properties"]["spacing"]
    assert viewer.scale_bar.unit == viewer_settings["scale_bar_properties"]["unit"]
    assert viewer.text_overlay.text == viewer_settings["text_overlay_properties"]["text"]

    # the camera setting only works if layers existed before loading...
    assert tuple(float(item) for item in viewer.camera.center)[1:] != viewer_settings["camera_properties"]["center"][1:]
    viewer.open(npi_path, plugin="napari-npifile")
    assert tuple(float(item) for item in viewer.camera.center)[1:] == viewer_settings["camera_properties"]["center"][1:]
