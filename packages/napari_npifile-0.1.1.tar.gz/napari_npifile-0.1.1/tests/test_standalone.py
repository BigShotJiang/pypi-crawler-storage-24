import pathlib
import json
import zipfile

import numpy as np
import pytest

import napari_npifile


#
# helpers
#


@pytest.fixture
def npi_path(tmp_path):
    return pathlib.Path(tmp_path).joinpath("test.npi")


@pytest.fixture
def npi_path_2(tmp_path):
    return pathlib.Path(tmp_path).joinpath("test_2.npi")


def assert_empty_npi(path: pathlib.Path):
    with zipfile.ZipFile(path, "r") as npi_file:
        namelist = npi_file.namelist()
        assert namelist == ["metadata.json"]

        metadata_path = zipfile.Path(npi_file).joinpath(namelist[0])
        with metadata_path.open("r") as metadata_file:
            metadata = json.load(metadata_file)

        assert metadata == {"npi_format": "v1"}


#
# tests
#


def test_read_nonexisting_npi(npi_path):
    assert not npi_path.exists()
    with pytest.raises(FileNotFoundError):
        napari_npifile.read_npi(path=npi_path)


def test_read_empty_zip(npi_path):
    with zipfile.ZipFile(npi_path, "w"):
        pass
    assert npi_path.exists()

    with pytest.raises(FileNotFoundError):
        napari_npifile.read_npi(path=npi_path)


def test_read_empty_format_npi(npi_path):
    with zipfile.ZipFile(npi_path, "w") as npi_file:
        metadata_path = zipfile.Path(npi_file).joinpath("metadata.json")
        with metadata_path.open("w") as metadata_file:
            json.dump({}, metadata_file)
    assert npi_path.exists()

    with pytest.raises(KeyError):
        napari_npifile.read_npi(path=npi_path)


def test_read_unsupported_format_npi(npi_path):
    with zipfile.ZipFile(npi_path, "w") as npi_file:
        metadata_path = zipfile.Path(npi_file).joinpath("metadata.json")
        with metadata_path.open("w") as metadata_file:
            json.dump({"npi_format": "v0xDEADBEEF"}, metadata_file)
    assert npi_path.exists()

    with pytest.raises(napari_npifile.NpiFormatError):
        napari_npifile.read_npi(path=npi_path)


def test_write_empty_npi_via_writer(npi_path):
    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    assert_empty_npi(path=npi_path)


def test_write_empty_npi_via_wrapper(npi_path):
    napari_npifile.write_multilayer_npi(
        out_path=npi_path,
        data_seq=[],
        layer_attributes_seq=None,
        viewer_settings=None,
    )
    assert_empty_npi(path=npi_path)


def test_write_layer_with_none_attributes(npi_path):
    data = np.random.random((5, 5))

    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    writer.write_layer(data=data, attributes=None)

    result = napari_npifile.read_npi(path=npi_path)
    assert result["layers"][0]["attributes"] == {}
    assert np.all(result["layers"][0]["data"] == data)


def test_write_layer_with_np_save_kwargs(npi_path):
    data = np.random.random((3, 3))
    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    writer.write_layer(data=data, np_save_kwargs={"allow_pickle": True})

    result = napari_npifile.read_npi(path=npi_path)
    assert np.all(result["layers"][0]["data"] == data)


def test_write_incremental_layer_paths(npi_path):
    data1 = np.random.random((1, 1))
    data2 = np.random.random((2, 2))
    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    writer.write_layer(data=data1)
    writer.write_layer(data=data2)

    with zipfile.ZipFile(npi_path, "r") as npi_file:
        layers_root = zipfile.Path(npi_file).joinpath("layers")
        layer_dirnames = sorted(path.name for path in layers_root.iterdir())
        assert layer_dirnames == ["00000000", "00000001"]


def test_write_single_layer_data_only_npi_via_writer(npi_path):
    data = np.random.random((10, 20))

    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    writer.write_layer(data=data)

    result = napari_npifile.read_npi(path=npi_path)
    assert result["viewer_settings"] == {}
    assert len(result["layers"]) == 1
    assert result["layers"][0]["attributes"] == {}
    assert np.all(result["layers"][0]["data"] == data)


def test_write_single_layer_data_only_npi_via_wrapper(npi_path):
    data = np.random.random((10, 20))

    napari_npifile.write_npi(
        out_path=npi_path,
        data=data,
        viewer_settings={"title": "test"},
    )

    result = napari_npifile.read_npi(path=npi_path)
    assert result["viewer_settings"] == {"title": "test"}
    assert len(result["layers"]) == 1
    assert result["layers"][0]["attributes"] == {}
    assert np.all(result["layers"][0]["data"] == data)


def test_write_single_layer_data_only_npi_via_multilayer_wrapper(npi_path):
    data = np.random.random((10, 20))

    napari_npifile.write_multilayer_npi(
        out_path=npi_path,
        data_seq=[data],
        viewer_settings={"title": "test"},
    )

    result = napari_npifile.read_npi(path=npi_path)
    assert result["viewer_settings"] == {"title": "test"}
    assert len(result["layers"]) == 1
    assert result["layers"][0]["attributes"] == {}
    assert np.all(result["layers"][0]["data"] == data)


def test_write_single_layer_full_metadata_npi_via_writer(npi_path):
    data = np.random.random((10, 20))
    attributes = {"name": "foo", "colormap": "green"}
    viewer_settings = {"title": "test"}

    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    writer.write_viewer_settings(settings=viewer_settings)
    writer.write_layer(data=data, attributes=attributes)

    result = napari_npifile.read_npi(path=npi_path)
    assert result["viewer_settings"] == viewer_settings
    assert len(result["layers"]) == 1
    assert result["layers"][0]["attributes"] == attributes
    assert np.all(result["layers"][0]["data"] == data)


def test_write_multi_layer_npi_via_writer(npi_path):
    data1 = np.random.random((3, 3))
    data2 = np.random.random((4, 4))
    attributes1 = {"name": "first"}
    attributes2 = {"name": "second"}

    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    writer.write_layer(data=data1, attributes=attributes1)
    writer.write_layer(data=data2, attributes=attributes2)

    result = napari_npifile.read_npi(path=npi_path)
    assert len(result["layers"]) == 2
    assert np.all(result["layers"][0]["data"] == data1)
    assert np.all(result["layers"][1]["data"] == data2)
    assert result["layers"][0]["attributes"] == attributes1
    assert result["layers"][1]["attributes"] == attributes2


def test_write_multi_layer_npi_via_wrapper(npi_path):
    data_seq = [np.random.random((2, 2)), np.random.random((3, 3))]
    attributes_seq = [{"name": "a"}, {"name": "b"}]

    napari_npifile.write_multilayer_npi(
        out_path=npi_path,
        data_seq=data_seq,
        layer_attributes_seq=attributes_seq,
    )

    result = napari_npifile.read_npi(path=npi_path)
    assert len(result["layers"]) == 2
    for i in range(2):
        assert np.all(result["layers"][i]["data"] == data_seq[i])
        assert result["layers"][i]["attributes"] == attributes_seq[i]


def test_write_double_viewer_settings_npi_via_writer(npi_path):
    viewer_settings = {"title": "test"}

    writer = napari_npifile.NpiWriter_v1(out_path=npi_path)
    writer.write_viewer_settings(settings=viewer_settings)

    with pytest.raises(napari_npifile.NpiArchiveFileExistsError):
        writer.write_viewer_settings(settings=viewer_settings)


def test_write_existing_npi_nok(npi_path):
    assert not npi_path.exists()
    writer = napari_npifile.NpiWriter_v1(out_path=npi_path, exist_ok=False)

    assert npi_path.exists()

    with pytest.raises(FileExistsError):
        writer = napari_npifile.NpiWriter_v1(out_path=npi_path, exist_ok=False)


def test_write_existing_npi_ok(npi_path):
    assert not npi_path.exists()
    writer = napari_npifile.NpiWriter_v1(out_path=npi_path, exist_ok=False)

    assert npi_path.exists()

    writer = napari_npifile.NpiWriter_v1(out_path=npi_path, exist_ok=True)
    assert npi_path.exists()


def test_writer_str(npi_path):
    assert not npi_path.exists()
    writer = napari_npifile.NpiWriter_v1(out_path=npi_path, exist_ok=False)
    assert npi_path.exists()

    assert str(writer) == f"<NpiWriter_v1 out_path='{npi_path}' layer_count=0>"
