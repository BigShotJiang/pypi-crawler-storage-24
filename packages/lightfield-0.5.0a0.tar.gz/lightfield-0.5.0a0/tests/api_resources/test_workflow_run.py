# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from lightfield import Lightfield, AsyncLightfield
from tests.utils import assert_matches_type
from lightfield.types import WorkflowRunStatusResponse

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestWorkflowRun:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @parametrize
    def test_method_status(self, client: Lightfield) -> None:
        workflow_run = client.workflow_run.status(
            "runId",
        )
        assert_matches_type(WorkflowRunStatusResponse, workflow_run, path=["response"])

    @parametrize
    def test_raw_response_status(self, client: Lightfield) -> None:
        response = client.workflow_run.with_raw_response.status(
            "runId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        workflow_run = response.parse()
        assert_matches_type(WorkflowRunStatusResponse, workflow_run, path=["response"])

    @parametrize
    def test_streaming_response_status(self, client: Lightfield) -> None:
        with client.workflow_run.with_streaming_response.status(
            "runId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            workflow_run = response.parse()
            assert_matches_type(WorkflowRunStatusResponse, workflow_run, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    def test_path_params_status(self, client: Lightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `run_id` but received ''"):
            client.workflow_run.with_raw_response.status(
                "",
            )


class TestAsyncWorkflowRun:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @parametrize
    async def test_method_status(self, async_client: AsyncLightfield) -> None:
        workflow_run = await async_client.workflow_run.status(
            "runId",
        )
        assert_matches_type(WorkflowRunStatusResponse, workflow_run, path=["response"])

    @parametrize
    async def test_raw_response_status(self, async_client: AsyncLightfield) -> None:
        response = await async_client.workflow_run.with_raw_response.status(
            "runId",
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        workflow_run = await response.parse()
        assert_matches_type(WorkflowRunStatusResponse, workflow_run, path=["response"])

    @parametrize
    async def test_streaming_response_status(self, async_client: AsyncLightfield) -> None:
        async with async_client.workflow_run.with_streaming_response.status(
            "runId",
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            workflow_run = await response.parse()
            assert_matches_type(WorkflowRunStatusResponse, workflow_run, path=["response"])

        assert cast(Any, response.is_closed) is True

    @parametrize
    async def test_path_params_status(self, async_client: AsyncLightfield) -> None:
        with pytest.raises(ValueError, match=r"Expected a non-empty value for `run_id` but received ''"):
            await async_client.workflow_run.with_raw_response.status(
                "",
            )
