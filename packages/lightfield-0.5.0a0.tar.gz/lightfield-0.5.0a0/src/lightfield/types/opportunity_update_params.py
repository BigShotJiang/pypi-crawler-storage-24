# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "OpportunityUpdateParams",
    "Fields",
    "Relationships",
    "RelationshipsChampion",
    "RelationshipsEvaluator",
    "RelationshipsOwner",
    "Relationship",
]


class OpportunityUpdateParams(TypedDict, total=False):
    fields: Fields
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged. System fields use a `$` prefix (e.g. `$name`, `$stage`); custom
    attributes use their bare slug. `SINGLE_SELECT` and `MULTI_SELECT` fields accept
    an option ID or label — call the
    <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u>
    for available options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Relationships
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$owner`, `$champion`). Each value
    is an operation object with `add`, `remove`, or `replace`.
    """


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    """
    Field values to update — only provided fields are modified; omitted fields are left unchanged. System fields use a `$` prefix (e.g. `$name`, `$stage`); custom attributes use their bare slug. `SINGLE_SELECT` and `MULTI_SELECT` fields accept an option ID or label — call the <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> for available options. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    name: Annotated[Optional[str], PropertyInfo(alias="$name")]
    """Display name of the opportunity."""

    stage: Annotated[Optional[str], PropertyInfo(alias="$stage")]
    """Pipeline stage (`SINGLE_SELECT`).

    Pass the option ID or label from the field definition.
    """


class RelationshipsChampion(TypedDict, total=False):
    """Operation to modify the internal champion."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class RelationshipsEvaluator(TypedDict, total=False):
    """Operation to modify the evaluator."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class RelationshipsOwner(TypedDict, total=False):
    """Operation to modify the opportunity owner."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class Relationship(TypedDict, total=False):
    """An operation to modify a relationship.

    Provide one of `add`, `remove`, or `replace`.
    """

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class Relationships(TypedDict, total=False, extra_items=Relationship):  # type: ignore[call-arg]
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$owner`, `$champion`). Each value is an operation object with `add`, `remove`, or `replace`.
    """

    champion: Annotated[RelationshipsChampion, PropertyInfo(alias="$champion")]
    """Operation to modify the internal champion."""

    evaluator: Annotated[RelationshipsEvaluator, PropertyInfo(alias="$evaluator")]
    """Operation to modify the evaluator."""

    owner: Annotated[RelationshipsOwner, PropertyInfo(alias="$owner")]
    """Operation to modify the opportunity owner."""
