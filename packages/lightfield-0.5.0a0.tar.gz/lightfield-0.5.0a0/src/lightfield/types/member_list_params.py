# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import TypedDict

__all__ = ["MemberListParams"]


class MemberListParams(TypedDict, total=False):
    limit: int
    """Maximum number of records to return. Defaults to 25, maximum 25."""

    offset: int
    """Number of records to skip for pagination. Defaults to 0."""
