# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["AccountCreateParams", "Fields", "FieldsPrimaryAddress", "Relationships"]


class AccountCreateParams(TypedDict, total=False):
    fields: Required[Fields]
    """Field values for the new account.

    System fields use a `$` prefix (e.g. `$name`, `$website`); custom attributes use
    their bare slug (e.g. `tier`, `renewalDate`). Required: `$name` (string). Fields
    of type `SINGLE_SELECT` or `MULTI_SELECT` accept either an option ID or label
    from the field's `typeConfiguration.options` — call the
    <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> to
    discover available fields and options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Relationships
    """Relationships to set on the new account.

    System relationships use a `$` prefix (e.g. `$owner`, `$contact`); custom
    relationships use their bare slug. Each value is a single entity ID or an array
    of IDs. Call the
    <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> to
    list available relationship keys.
    """


class FieldsPrimaryAddress(TypedDict, total=False):
    """Primary address (`ADDRESS`)."""

    city: Optional[str]
    """City name."""

    country: Optional[str]
    """2-letter ISO 3166-1 alpha-2 country code."""

    latitude: Optional[float]
    """Latitude coordinate."""

    longitude: Optional[float]
    """Longitude coordinate."""

    postal_code: Annotated[Optional[str], PropertyInfo(alias="postalCode")]
    """Postal or ZIP code."""

    state: Optional[str]
    """State or province."""

    street: Optional[str]
    """Street address line 1."""

    street2: Optional[str]
    """Street address line 2."""


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    """Field values for the new account.

    System fields use a `$` prefix (e.g. `$name`, `$website`); custom attributes use their bare slug (e.g. `tier`, `renewalDate`). Required: `$name` (string). Fields of type `SINGLE_SELECT` or `MULTI_SELECT` accept either an option ID or label from the field's `typeConfiguration.options` — call the <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> to discover available fields and options. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    name: Required[Annotated[str, PropertyInfo(alias="$name")]]
    """Display name of the account."""

    facebook: Annotated[Optional[str], PropertyInfo(alias="$facebook")]
    """Facebook handle or profile identifier (`SOCIAL_HANDLE`)."""

    headcount: Annotated[Optional[str], PropertyInfo(alias="$headcount")]
    """Employee count range (`SINGLE_SELECT`).

    Pass the option ID or label from the field definition.
    """

    industry: Annotated[Optional[SequenceNotStr[str]], PropertyInfo(alias="$industry")]
    """Industries the account operates in (`MULTI_SELECT`).

    Pass option IDs or labels from the field definition.
    """

    instagram: Annotated[Optional[str], PropertyInfo(alias="$instagram")]
    """Instagram handle or profile identifier (`SOCIAL_HANDLE`)."""

    last_funding_type: Annotated[Optional[str], PropertyInfo(alias="$lastFundingType")]
    """Most recent funding round type (`SINGLE_SELECT`).

    Pass the option ID or label from the field definition.
    """

    linked_in: Annotated[Optional[str], PropertyInfo(alias="$linkedIn")]
    """LinkedIn handle or profile identifier (`SOCIAL_HANDLE`)."""

    primary_address: Annotated[Optional[FieldsPrimaryAddress], PropertyInfo(alias="$primaryAddress")]
    """Primary address (`ADDRESS`)."""

    twitter: Annotated[Optional[str], PropertyInfo(alias="$twitter")]
    """Twitter/X handle (`SOCIAL_HANDLE`)."""

    website: Annotated[Optional[SequenceNotStr[str]], PropertyInfo(alias="$website")]
    """Website URLs associated with the account (`URL`, multi-value)."""


class Relationships(TypedDict, total=False, extra_items=Union[str, SequenceNotStr[str]]):  # type: ignore[call-arg]
    """Relationships to set on the new account.

    System relationships use a `$` prefix (e.g. `$owner`, `$contact`); custom relationships use their bare slug. Each value is a single entity ID or an array of IDs. Call the <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> to list available relationship keys.
    """

    contact: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$contact")]
    """ID(s) of contacts to associate with this account."""

    owner: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$owner")]
    """ID of the user who owns this account."""
