# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["ContactCreateParams", "Fields", "FieldsName", "Relationships"]


class ContactCreateParams(TypedDict, total=False):
    fields: Required[Fields]
    """Field values for the new contact.

    System fields use a `$` prefix (e.g. `$email`, `$name`); custom attributes use
    their bare slug. Note: `$name` is an object `{ firstName, lastName }`, not a
    plain string. Call the
    <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> to
    discover available fields and their types. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Relationships
    """Relationships to set on the new contact.

    System relationships use a `$` prefix (e.g. `$account`); custom relationships
    use their bare slug. Each value is a single entity ID or an array of IDs. Call
    the <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> to
    list available relationship keys.
    """


class FieldsName(TypedDict, total=False):
    """The contact's name.

    Unlike other resources, this is an object: `{ firstName?: string, lastName?: string }`, not a plain string.
    """

    first_name: Annotated[str, PropertyInfo(alias="firstName")]
    """The contact's first name."""

    last_name: Annotated[str, PropertyInfo(alias="lastName")]
    """The contact's last name."""


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    """Field values for the new contact.

    System fields use a `$` prefix (e.g. `$email`, `$name`); custom attributes use their bare slug. Note: `$name` is an object `{ firstName, lastName }`, not a plain string. Call the <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> to discover available fields and their types. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    email: Annotated[Optional[SequenceNotStr[str]], PropertyInfo(alias="$email")]
    """List of email addresses for the contact (`EMAIL`, multi-value)."""

    name: Annotated[Optional[FieldsName], PropertyInfo(alias="$name")]
    """The contact's name.

    Unlike other resources, this is an object:
    `{ firstName?: string, lastName?: string }`, not a plain string.
    """

    profile_photo_url: Annotated[Optional[str], PropertyInfo(alias="$profilePhotoUrl")]
    """URL of the contact's profile photo (`URL`)."""


class Relationships(TypedDict, total=False, extra_items=Union[str, SequenceNotStr[str]]):  # type: ignore[call-arg]
    """Relationships to set on the new contact.

    System relationships use a `$` prefix (e.g. `$account`); custom relationships use their bare slug. Each value is a single entity ID or an array of IDs. Call the <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> to list available relationship keys.
    """

    account: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$account")]
    """ID(s) of accounts to associate with this contact."""
