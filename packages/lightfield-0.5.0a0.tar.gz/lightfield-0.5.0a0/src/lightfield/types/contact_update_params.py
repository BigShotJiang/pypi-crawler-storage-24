# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["ContactUpdateParams", "Fields", "FieldsName", "Relationships", "RelationshipsAccount", "Relationship"]


class ContactUpdateParams(TypedDict, total=False):
    fields: Fields
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged. System fields use a `$` prefix (e.g. `$email`); custom
    attributes use their bare slug. Note: `$name` is an object
    `{ firstName, lastName }`, not a plain string. Call the
    <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> for
    available fields and types. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Relationships
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$account`). Each value is an
    operation object with `add`, `remove`, or `replace`.
    """


class FieldsName(TypedDict, total=False):
    """The contact's name.

    Unlike other resources, this is an object: `{ firstName?: string, lastName?: string }`, not a plain string.
    """

    first_name: Annotated[str, PropertyInfo(alias="firstName")]
    """The contact's first name."""

    last_name: Annotated[str, PropertyInfo(alias="lastName")]
    """The contact's last name."""


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    """
    Field values to update — only provided fields are modified; omitted fields are left unchanged. System fields use a `$` prefix (e.g. `$email`); custom attributes use their bare slug. Note: `$name` is an object `{ firstName, lastName }`, not a plain string. Call the <u>[definitions endpoint](/api/resources/contact/methods/definitions)</u> for available fields and types. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    email: Annotated[Optional[SequenceNotStr[str]], PropertyInfo(alias="$email")]
    """List of email addresses for the contact (`EMAIL`, multi-value)."""

    name: Annotated[Optional[FieldsName], PropertyInfo(alias="$name")]
    """The contact's name.

    Unlike other resources, this is an object:
    `{ firstName?: string, lastName?: string }`, not a plain string.
    """

    profile_photo_url: Annotated[Optional[str], PropertyInfo(alias="$profilePhotoUrl")]
    """URL of the contact's profile photo (`URL`)."""


class RelationshipsAccount(TypedDict, total=False):
    """Operation to modify associated accounts."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class Relationship(TypedDict, total=False):
    """An operation to modify a relationship.

    Provide one of `add`, `remove`, or `replace`.
    """

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class Relationships(TypedDict, total=False, extra_items=Relationship):  # type: ignore[call-arg]
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$account`). Each value is an operation object with `add`, `remove`, or `replace`.
    """

    account: Annotated[RelationshipsAccount, PropertyInfo(alias="$account")]
    """Operation to modify associated accounts."""
