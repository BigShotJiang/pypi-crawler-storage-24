# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal

from pydantic import Field as FieldInfo

from .._models import BaseModel

__all__ = ["MemberRetrieveResponse", "Fields"]


class Fields(BaseModel):
    value: Union[
        str,
        float,
        bool,
        List[Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, List[Optional[object]], Dict[str, object], None]],
        None,
    ] = None
    """The field value, or null if unset."""

    value_type: Literal[
        "ADDRESS",
        "CHECKBOX",
        "CURRENCY",
        "DATETIME",
        "EMAIL",
        "FULL_NAME",
        "MARKDOWN",
        "MULTI_SELECT",
        "NUMBER",
        "SINGLE_SELECT",
        "SOCIAL_HANDLE",
        "TELEPHONE",
        "TEXT",
        "URL",
    ] = FieldInfo(alias="valueType")
    """The data type of the field value."""


class MemberRetrieveResponse(BaseModel):
    id: str
    """Unique identifier for the member."""

    created_at: str = FieldInfo(alias="createdAt")
    """ISO 8601 timestamp of when the member was created."""

    fields: Dict[str, Fields]
    """Map of field names to their typed values."""

    http_link: Optional[str] = FieldInfo(alias="httpLink", default=None)
    """URL to view the member in the Lightfield web app, or null."""
