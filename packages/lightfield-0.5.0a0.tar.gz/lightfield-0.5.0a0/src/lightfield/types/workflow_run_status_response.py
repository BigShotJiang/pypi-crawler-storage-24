# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from .._models import BaseModel

__all__ = ["WorkflowRunStatusResponse"]


class WorkflowRunStatusResponse(BaseModel):
    status: str
    """Current status of the workflow run (e.g. `running`, `completed`, `failed`)."""
