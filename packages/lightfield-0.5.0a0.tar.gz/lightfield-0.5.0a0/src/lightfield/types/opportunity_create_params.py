# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable
from typing_extensions import Required, Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = ["OpportunityCreateParams", "Fields", "Relationships"]


class OpportunityCreateParams(TypedDict, total=False):
    fields: Required[Fields]
    """Field values for the new opportunity.

    System fields use a `$` prefix (e.g. `$name`, `$stage`); custom attributes use
    their bare slug. Required: `$name` (string) and `$stage` (option ID or label).
    Fields of type `SINGLE_SELECT` or `MULTI_SELECT` accept either an option ID or
    label from the field's `typeConfiguration.options` — call the
    <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> to
    discover available fields and options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Required[Relationships]
    """Relationships to set on the new opportunity.

    System relationships use a `$` prefix (e.g. `$account`, `$owner`); custom
    relationships use their bare slug. `$account` is required. Each value is a
    single entity ID or an array of IDs. Call the
    <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> to
    list available relationship keys.
    """


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    """Field values for the new opportunity.

    System fields use a `$` prefix (e.g. `$name`, `$stage`); custom attributes use their bare slug. Required: `$name` (string) and `$stage` (option ID or label). Fields of type `SINGLE_SELECT` or `MULTI_SELECT` accept either an option ID or label from the field's `typeConfiguration.options` — call the <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> to discover available fields and options. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    name: Required[Annotated[str, PropertyInfo(alias="$name")]]
    """Display name of the opportunity."""

    stage: Required[Annotated[str, PropertyInfo(alias="$stage")]]
    """Pipeline stage (`SINGLE_SELECT`).

    Pass the option ID or label from the field definition.
    """


class Relationships(TypedDict, total=False, extra_items=Union[str, SequenceNotStr[str]]):  # type: ignore[call-arg]
    """Relationships to set on the new opportunity.

    System relationships use a `$` prefix (e.g. `$account`, `$owner`); custom relationships use their bare slug. `$account` is required. Each value is a single entity ID or an array of IDs. Call the <u>[definitions endpoint](/api/resources/opportunity/methods/definitions)</u> to list available relationship keys.
    """

    account: Required[Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$account")]]
    """ID of the account this opportunity belongs to."""

    champion: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$champion")]
    """ID of the contact who is the internal champion."""

    created_by: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$createdBy")]
    """ID of the user who created this opportunity."""

    evaluator: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$evaluator")]
    """ID of the contact who is the evaluator."""

    owner: Annotated[Union[str, SequenceNotStr[str]], PropertyInfo(alias="$owner")]
    """ID of the user who owns this opportunity."""
