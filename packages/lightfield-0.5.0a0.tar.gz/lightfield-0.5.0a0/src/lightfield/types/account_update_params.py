# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Union, Iterable, Optional
from typing_extensions import Annotated, TypedDict

from .._types import SequenceNotStr
from .._utils import PropertyInfo

__all__ = [
    "AccountUpdateParams",
    "Fields",
    "FieldsPrimaryAddress",
    "Relationships",
    "RelationshipsContact",
    "RelationshipsOwner",
    "Relationship",
]


class AccountUpdateParams(TypedDict, total=False):
    fields: Fields
    """
    Field values to update — only provided fields are modified; omitted fields are
    left unchanged. System fields use a `$` prefix (e.g. `$name`); custom attributes
    use their bare slug. `SINGLE_SELECT` and `MULTI_SELECT` fields accept an option
    ID or label — call the
    <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> for
    available options. See
    <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for
    value type details.
    """

    relationships: Relationships
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$owner`, `$contact`). Each value is
    an operation object with `add`, `remove`, or `replace`.
    """


class FieldsPrimaryAddress(TypedDict, total=False):
    """Primary address (`ADDRESS`)."""

    city: Optional[str]
    """City name."""

    country: Optional[str]
    """2-letter ISO 3166-1 alpha-2 country code."""

    latitude: Optional[float]
    """Latitude coordinate."""

    longitude: Optional[float]
    """Longitude coordinate."""

    postal_code: Annotated[Optional[str], PropertyInfo(alias="postalCode")]
    """Postal or ZIP code."""

    state: Optional[str]
    """State or province."""

    street: Optional[str]
    """Street address line 1."""

    street2: Optional[str]
    """Street address line 2."""


class Fields(
    TypedDict,
    total=False,
    extra_items=Union[
        str,
        float,
        bool,
        SequenceNotStr[Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        Dict[str, Union[str, float, bool, Iterable[object], Dict[str, object], None]],
        None,
    ],
):  # type: ignore[call-arg]
    """
    Field values to update — only provided fields are modified; omitted fields are left unchanged. System fields use a `$` prefix (e.g. `$name`); custom attributes use their bare slug. `SINGLE_SELECT` and `MULTI_SELECT` fields accept an option ID or label — call the <u>[definitions endpoint](/api/resources/account/methods/definitions)</u> for available options. See <u>[Fields and relationships](/using-the-api/fields-and-relationships/)</u> for value type details.
    """

    facebook: Annotated[Optional[str], PropertyInfo(alias="$facebook")]
    """Facebook handle or profile identifier (`SOCIAL_HANDLE`)."""

    headcount: Annotated[Optional[str], PropertyInfo(alias="$headcount")]
    """Employee count range (`SINGLE_SELECT`).

    Pass the option ID or label from the field definition.
    """

    industry: Annotated[Optional[SequenceNotStr[str]], PropertyInfo(alias="$industry")]
    """Industries the account operates in (`MULTI_SELECT`).

    Pass option IDs or labels from the field definition.
    """

    instagram: Annotated[Optional[str], PropertyInfo(alias="$instagram")]
    """Instagram handle or profile identifier (`SOCIAL_HANDLE`)."""

    last_funding_type: Annotated[Optional[str], PropertyInfo(alias="$lastFundingType")]
    """Most recent funding round type (`SINGLE_SELECT`).

    Pass the option ID or label from the field definition.
    """

    linked_in: Annotated[Optional[str], PropertyInfo(alias="$linkedIn")]
    """LinkedIn handle or profile identifier (`SOCIAL_HANDLE`)."""

    name: Annotated[Optional[str], PropertyInfo(alias="$name")]
    """Display name of the account."""

    primary_address: Annotated[Optional[FieldsPrimaryAddress], PropertyInfo(alias="$primaryAddress")]
    """Primary address (`ADDRESS`)."""

    twitter: Annotated[Optional[str], PropertyInfo(alias="$twitter")]
    """Twitter/X handle (`SOCIAL_HANDLE`)."""

    website: Annotated[Optional[SequenceNotStr[str]], PropertyInfo(alias="$website")]
    """Website URLs associated with the account (`URL`, multi-value)."""


class RelationshipsContact(TypedDict, total=False):
    """Operation to modify associated contacts."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class RelationshipsOwner(TypedDict, total=False):
    """Operation to modify the account owner."""

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class Relationship(TypedDict, total=False):
    """An operation to modify a relationship.

    Provide one of `add`, `remove`, or `replace`.
    """

    add: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to add to the relationship."""

    remove: Union[str, SequenceNotStr[str]]
    """Entity ID(s) to remove from the relationship."""

    replace: Union[str, SequenceNotStr[str]]
    """
    Entity ID(s) to set as the entire relationship, replacing all existing
    associations.
    """


class Relationships(TypedDict, total=False, extra_items=Relationship):  # type: ignore[call-arg]
    """Relationship operations to apply.

    System relationships use a `$` prefix (e.g. `$owner`, `$contact`). Each value is an operation object with `add`, `remove`, or `replace`.
    """

    contact: Annotated[RelationshipsContact, PropertyInfo(alias="$contact")]
    """Operation to modify associated contacts."""

    owner: Annotated[RelationshipsOwner, PropertyInfo(alias="$owner")]
    """Operation to modify the account owner."""
