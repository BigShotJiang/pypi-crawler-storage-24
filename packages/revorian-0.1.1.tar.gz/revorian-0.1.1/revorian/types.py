from __future__ import annotations

from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Nested helper types
# ---------------------------------------------------------------------------

@dataclass
class CompanyRef:
    """Inline company reference on a transaction."""
    ticker: Optional[str]
    name: str
    cik: str
    sector: Optional[str]


@dataclass
class InsiderRef:
    """Inline insider reference on a transaction."""
    name: str
    cik: str


# ---------------------------------------------------------------------------
# Core entities
# ---------------------------------------------------------------------------

@dataclass
class Transaction:
    id: int
    accession_number: str
    filing_date: str
    transaction_date: Optional[str]
    company: CompanyRef
    insider: InsiderRef
    is_director: bool
    is_officer: bool
    is_ten_percent_owner: bool
    officer_title: Optional[str]
    transaction_code: str
    shares: Optional[float]
    price_per_share: Optional[float]
    total_value: Optional[float]
    acquired_disposed: str
    shares_owned_after: Optional[float]
    ownership_type: str
    significance: str
    signals: List[str]
    is_derivative: bool


@dataclass
class Company:
    ticker: Optional[str]
    name: str
    cik: str
    exchange: Optional[str]
    sector: Optional[str]


@dataclass
class PeriodStats:
    buys: int
    sells: int
    buy_value: float
    sell_value: float
    net_sentiment: str


@dataclass
class TopInsider:
    name: str
    cik: str
    trade_count: int
    total_value: float


@dataclass
class Signal:
    id: int
    signal_type: str
    company: Company
    description: str
    severity: str
    transaction_ids: List[int]
    detected_at: str


@dataclass
class CompanySummary:
    company: Company
    periods: Dict[str, PeriodStats]
    top_insiders: List[TopInsider]


@dataclass
class Watchlist:
    id: int
    company: Company
    webhook_url: Optional[str]
    notify_email: bool
    min_significance: str
    created_at: str


@dataclass
class PaginatedResponse:
    """Generic paginated response. Check transactions/signals/data for the items."""
    total: int
    transactions: Optional[List[Transaction]] = None
    signals: Optional[List[Signal]] = None
    data: Optional[List[Any]] = None
