from __future__ import annotations

import time
from typing import Any, Dict, List, Optional

import requests

from .exceptions import AuthenticationError, RevorianError, RateLimitError

_DEFAULT_BASE_URL = "https://revorian.com/api"
_MAX_RETRIES = 3
_INITIAL_BACKOFF_S = 1.0


class RevorianClient:
    """Synchronous Python client for the Revorian API.

    Usage::

        from revorian import RevorianClient

        client = RevorianClient(api_key="rev_live_sk_...")
        txns = client.get_transactions(limit=10)
        print(txns)
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        *,
        timeout: float = 30.0,
    ) -> None:
        if not api_key:
            raise ValueError("api_key is required")

        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._session = requests.Session()
        self._session.headers.update(
            {
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            }
        )

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    def __enter__(self) -> RevorianClient:
        return self

    def __exit__(self, *exc: Any) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP session."""
        self._session.close()

    # ------------------------------------------------------------------
    # Transactions
    # ------------------------------------------------------------------

    def get_transactions(self, **params: Any) -> Dict[str, Any]:
        """Search / list insider transactions with optional filters."""
        return self._request("GET", "/v1/transactions", params=params)

    def get_transaction(self, id: int) -> Dict[str, Any]:
        """Get a single transaction by ID."""
        return self._request("GET", f"/v1/transactions/{id}")

    def get_company_transactions(self, ticker: str, **params: Any) -> Dict[str, Any]:
        """Get all insider transactions for a specific company."""
        return self._request("GET", f"/v1/companies/{ticker}/transactions", params=params)

    def get_company_summary(self, ticker: str, **params: Any) -> Dict[str, Any]:
        """Get aggregated insider trading summary for a company."""
        return self._request("GET", f"/v1/companies/{ticker}/summary", params=params)

    def get_insider_transactions(self, cik: str, **params: Any) -> Dict[str, Any]:
        """Get transaction history for a specific insider by CIK."""
        return self._request("GET", f"/v1/insiders/{cik}/transactions", params=params)

    # ------------------------------------------------------------------
    # Signals & intelligence
    # ------------------------------------------------------------------

    def get_signals(self, **params: Any) -> Dict[str, Any]:
        """Search / list trading signals."""
        return self._request("GET", "/v1/signals", params=params)

    def get_clusters(self, **params: Any) -> Dict[str, Any]:
        """Get cluster buy/sell alerts."""
        return self._request("GET", "/v1/signals/clusters", params=params)

    def get_sector_sentiment(self, **params: Any) -> Dict[str, Any]:
        """Get aggregated sector-level sentiment data."""
        return self._request("GET", "/v1/stats/sector-sentiment", params=params)

    def get_top_buys(self, **params: Any) -> Dict[str, Any]:
        """Get the top insider purchases."""
        return self._request("GET", "/v1/transactions/top-buys", params=params)

    def get_top_sells(self, **params: Any) -> Dict[str, Any]:
        """Get the top insider sales."""
        return self._request("GET", "/v1/transactions/top-sells", params=params)

    # ------------------------------------------------------------------
    # Watchlist
    # ------------------------------------------------------------------

    def get_watchlist(self) -> List[Dict[str, Any]]:
        """List all companies on your watchlist."""
        return self._request("GET", "/v1/watchlist")

    def watch_company(
        self,
        ticker: str,
        *,
        webhook_url: Optional[str] = None,
        notify_email: Optional[bool] = None,
        min_significance: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Add a company to your watchlist."""
        body: Dict[str, Any] = {"ticker": ticker}
        if webhook_url is not None:
            body["webhook_url"] = webhook_url
        if notify_email is not None:
            body["notify_email"] = notify_email
        if min_significance is not None:
            body["min_significance"] = min_significance
        return self._request("POST", "/v1/watchlist", body=body)

    def unwatch_company(self, id: int) -> Dict[str, Any]:
        """Remove a company from your watchlist."""
        return self._request("DELETE", f"/v1/watchlist/{id}")

    # ------------------------------------------------------------------
    # Public feed
    # ------------------------------------------------------------------

    def get_feed(self, **params: Any) -> Dict[str, Any]:
        """Get the public transaction feed (no auth required)."""
        return self._request("GET", "/v1/feed", params=params, auth=False)

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[Dict[str, Any]] = None,
        body: Optional[Dict[str, Any]] = None,
        auth: bool = True,
    ) -> Any:
        url = f"{self._base_url}{path}"

        # Clean None values from query params
        clean_params: Optional[Dict[str, Any]] = None
        if params:
            clean_params = {k: v for k, v in params.items() if v is not None}

        headers: Dict[str, str] = {}
        if not auth:
            headers["Authorization"] = ""  # override session header

        last_error: Exception | None = None

        for attempt in range(_MAX_RETRIES + 1):
            if attempt > 0:
                delay = _INITIAL_BACKOFF_S * (2 ** (attempt - 1))
                time.sleep(delay)

            try:
                response = self._session.request(
                    method,
                    url,
                    params=clean_params,
                    json=body,
                    headers=headers if headers else None,
                    timeout=self._timeout,
                )
            except requests.RequestException as exc:
                last_error = exc
                continue

            # Retry on 429 or 5xx
            if (response.status_code == 429 or response.status_code >= 500) and attempt < _MAX_RETRIES:
                last_error = RevorianError(response.status_code, f"HTTP {response.status_code}")
                continue

            try:
                data = response.json()
            except Exception:
                raise RevorianError(
                    response.status_code,
                    f"Unexpected non-JSON response (HTTP {response.status_code})",
                )

            if not response.ok:
                error_body = data.get("error", {}) if isinstance(data, dict) else {}
                message = error_body.get("message", f"Request failed with status {response.status_code}")
                code = error_body.get("code")

                if response.status_code == 429:
                    raise RateLimitError(message=message, retry_after=error_body.get("retry_after"))
                if response.status_code in (401, 403):
                    raise AuthenticationError(message=message)

                raise RevorianError(
                    status_code=response.status_code,
                    message=message,
                    code=code,
                )

            # Unwrap { success, data } envelope if present
            if isinstance(data, dict) and data.get("success") and "data" in data:
                return data["data"]

            return data

        # All retries exhausted
        if isinstance(last_error, RevorianError):
            raise last_error
        raise RevorianError(
            0,
            str(last_error) if last_error else "Request failed after retries",
        )
