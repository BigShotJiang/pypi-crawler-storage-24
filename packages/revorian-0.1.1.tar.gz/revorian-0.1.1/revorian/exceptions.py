from __future__ import annotations


class RevorianError(Exception):
    """Raised when the Revorian API returns a non-success response."""

    def __init__(
        self,
        status_code: int,
        message: str,
        code: str | None = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.message = message
        self.code = code

    def __repr__(self) -> str:
        return (
            f"RevorianError(status_code={self.status_code!r}, "
            f"message={self.message!r}, code={self.code!r})"
        )


class RateLimitError(RevorianError):
    """Raised when the API returns a 429 rate-limit response after all retries."""

    def __init__(self, message: str = "Rate limited", retry_after: int | None = None) -> None:
        super().__init__(status_code=429, message=message)
        self.retry_after = retry_after


class AuthenticationError(RevorianError):
    """Raised when the API returns a 401 or 403 authentication error."""

    def __init__(self, message: str = "Authentication failed") -> None:
        super().__init__(status_code=401, message=message, code="auth_error")
