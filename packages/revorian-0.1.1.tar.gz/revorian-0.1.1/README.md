# Revorian

Official Python SDK for the [Revorian](https://revorian.com) insider trading API.

## Installation

```bash
pip install revorian
```

## Quick Start

```python
from revorian import RevorianClient

client = RevorianClient(api_key="rev_live_sk_...")

# Get the latest insider trades
feed = client.get_feed(filter="buys", limit=10)

# Get company insider trading profile
summary = client.get_company_summary("AAPL")

# Search transactions
txns = client.get_transactions(ticker="TSLA", limit=20)

# Get trading signals
signals = client.get_signals(type="cluster_buy")
```

## Authentication

Sign up at [revorian.com](https://revorian.com/signup) to get a free API key. Pass it when creating the client:

```python
client = RevorianClient(api_key="rev_live_sk_...")
```

Public endpoints (feed, companies, insiders) work without authentication. Authenticated endpoints (watchlist) require an API key.

## API Reference

### Transactions

- `client.get_feed(**params)` - Public insider trading feed
- `client.get_transactions(**params)` - Search/filter transactions
- `client.get_transaction(id)` - Get single transaction
- `client.get_company_transactions(ticker, **params)` - Company transactions
- `client.get_insider_transactions(cik, **params)` - Insider transactions
- `client.get_top_buys(**params)` - Top insider purchases
- `client.get_top_sells(**params)` - Top insider sales

### Intelligence

- `client.get_company_summary(ticker, **params)` - Company trading summary
- `client.get_signals(**params)` - Trading signals
- `client.get_clusters(**params)` - Cluster buy/sell alerts
- `client.get_sector_sentiment(**params)` - Sector-level sentiment

### Watchlist

- `client.get_watchlist()` - List watched companies
- `client.watch_company(ticker, webhook_url=None)` - Add to watchlist
- `client.unwatch_company(id)` - Remove from watchlist

## Free Tier

- 100 API requests/day
- 7 days of historical data

## License

MIT
