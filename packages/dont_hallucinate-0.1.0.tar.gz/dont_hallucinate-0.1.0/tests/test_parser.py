from hallucinate.parser import classify_failure, extract_hallucinated_flag


def test_extract_hallucinated_flag() -> None:
    stderr = "tar: unrecognized option '--zip-everything'"
    assert extract_hallucinated_flag(stderr) == "--zip-everything"


def test_classify_invalid_flag() -> None:
    parsed = classify_failure(
        command="tar --zip-everything src",
        stderr_text="tar: unrecognized option '--zip-everything'",
        exit_code=2,
    )
    assert parsed.error_type == "invalid_flag"
    assert parsed.hallucinated_flag == "--zip-everything"


def test_classify_command_not_found() -> None:
    parsed = classify_failure(
        command="pnpmx install",
        stderr_text="pnpmx: command not found",
        exit_code=127,
    )
    assert parsed.error_type == "missing_package"
    assert parsed.missing_command == "pnpmx"
