from hallucinate.runtime import is_within_workspace
from hallucinate.watcher import _parse_line


def test_parse_line_reads_workspace_fields() -> None:
    event = _parse_line(
        '{"ts":"2026-03-07T00:00:00Z","exit_code":1,"command":"pnpmx install","stderr":"pnpmx: command not found","shell":"bash","actor":"agent","cwd":"E:/repo","workspace_root":"E:/repo"}'
    )

    assert event is not None
    assert event.actor == "agent"
    assert event.cwd == "E:/repo"
    assert event.workspace_root == "E:/repo"


def test_parse_line_accepts_utf8_bom() -> None:
    event = _parse_line('\ufeff{"ts":"2026-03-07T00:00:00Z","exit_code":1,"command":"bad","stderr":"oops"}')
    assert event is not None
    assert event.command == "bad"


def test_workspace_filter_rejects_other_projects() -> None:
    assert not is_within_workspace("E:/elsewhere", "E:/repo")
