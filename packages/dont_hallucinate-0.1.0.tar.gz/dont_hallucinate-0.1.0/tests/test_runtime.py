from pathlib import Path

from hallucinate.runtime import default_stream_file, is_within_workspace, runtime_dir, workspace_root


def test_workspace_paths_are_local_to_project(tmp_path: Path) -> None:
    root = workspace_root(tmp_path)
    assert runtime_dir(root) == tmp_path / ".hallucinate"
    assert default_stream_file(root) == tmp_path / ".hallucinate" / "stream.jsonl"


def test_is_within_workspace() -> None:
    root = Path("E:/project").resolve()
    assert is_within_workspace(root / "src" / "main.py", root)
    assert is_within_workspace(root, root)
    assert not is_within_workspace(Path("E:/other/place").resolve(), root)
    assert not is_within_workspace("", root)
