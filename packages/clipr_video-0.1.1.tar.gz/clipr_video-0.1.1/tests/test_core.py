import unittest
from unittest.mock import MagicMock, patch

from clipr.core import (
    AudioEnhancementSettings,
    CropMode,
    CropSettings,
    EnhancementSettings,
    OrientationMode,
    ProcessingOptions,
    ResizeMode,
    SocialPreset,
    TrimSettings,
    VideoToolkitError,
    _build_audio_filters,
    _build_crop_filters,
    _build_enhancement_filters,
    _build_orientation_filters,
    _build_resize_filters,
    _build_trim_args,
    _merge_social_preset,
    _normalize_lengths,
    _run_command,
    make_4k_widescreen,
    make_instagram_reel,
)


class EnhancementFilterTests(unittest.TestCase):
    def test_builds_expected_enhancement_filters(self) -> None:
        filters = _build_enhancement_filters(
            EnhancementSettings(
                denoise=True,
                sharpen=True,
                brightness=0.1,
                contrast=1.2,
                upscale_width=1920,
                upscale_height=1080,
                resize_mode=ResizeMode.STRETCH,
            )
        )
        self.assertEqual(
            filters,
            [
                "hqdn3d=1.5:1.5:6:6",
                "unsharp=5:5:1.0:5:5:0.0",
                "eq=brightness=0.1:contrast=1.2",
                "scale=1920:1080:flags=lanczos",
            ],
        )

    def test_requires_both_upscale_dimensions(self) -> None:
        with self.assertRaises(VideoToolkitError):
            _build_enhancement_filters(EnhancementSettings(upscale_width=1920))


class AudioFilterTests(unittest.TestCase):
    def test_builds_audio_filters(self) -> None:
        filters = _build_audio_filters(
            AudioEnhancementSettings(normalize=True, denoise=True, volume=1.1, sample_rate=44100)
        )
        self.assertEqual(filters, ["afftdn", "loudnorm", "volume=1.1", "aresample=44100"])


class OrientationFilterTests(unittest.TestCase):
    def test_portrait_rotates_landscape_video(self) -> None:
        filters = _build_orientation_filters(OrientationMode.PORTRAIT, width=1920, height=1080)
        self.assertEqual(filters, ["transpose=1"])

    def test_landscape_keeps_landscape_video(self) -> None:
        filters = _build_orientation_filters(OrientationMode.LANDSCAPE, width=1920, height=1080)
        self.assertEqual(filters, [])

    def test_rotate_180_uses_two_transposes(self) -> None:
        filters = _build_orientation_filters(OrientationMode.ROTATE_180, width=1920, height=1080)
        self.assertEqual(filters, ["transpose=1", "transpose=1"])


class CropFilterTests(unittest.TestCase):
    def test_vertical_crop_mode(self) -> None:
        filters = _build_crop_filters(CropSettings(mode=CropMode.CENTER_VERTICAL), width=1920, height=1080)
        self.assertEqual(filters, ["crop=607:1080:656:0"])

    def test_custom_crop_defaults_to_center(self) -> None:
        filters = _build_crop_filters(CropSettings(width=1000, height=500), width=1920, height=1080)
        self.assertEqual(filters, ["crop=1000:500:460:290"])


class ResizeFilterTests(unittest.TestCase):
    def test_fit_resize_preserves_aspect_ratio_with_padding(self) -> None:
        filters = _build_resize_filters(1080, 1920, ResizeMode.FIT)
        self.assertEqual(
            filters,
            [
                "scale=1080:1920:force_original_aspect_ratio=decrease:flags=lanczos",
                "pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=black",
            ],
        )


class TrimValidationTests(unittest.TestCase):
    def test_trim_args_support_start_and_duration(self) -> None:
        self.assertEqual(_build_trim_args(TrimSettings(start_time=5, duration=20)), ["-ss", "5", "-t", "20"])

    def test_trim_rejects_invalid_combination(self) -> None:
        with self.assertRaises(VideoToolkitError):
            _build_trim_args(TrimSettings(start_time=5, end_time=10, duration=3))


class SocialPresetTests(unittest.TestCase):
    def test_social_preset_adds_vertical_defaults(self) -> None:
        merged = _merge_social_preset(ProcessingOptions(social_preset=SocialPreset.TIKTOK))
        self.assertIsNone(merged.orientation)
        self.assertIsNone(merged.crop)
        self.assertEqual(merged.enhancement.upscale_width, 1080)
        self.assertEqual(merged.enhancement.resize_mode, ResizeMode.FIT)


class SplitValidationTests(unittest.TestCase):
    def test_normalize_lengths_sorts_and_deduplicates(self) -> None:
        self.assertEqual(_normalize_lengths([90, 30, 60, 30]), [30, 60, 90])

    def test_normalize_lengths_rejects_invalid_values(self) -> None:
        with self.assertRaises(VideoToolkitError):
            _normalize_lengths([30, 0])


class ProgressParsingTests(unittest.TestCase):
    @patch("clipr.core.subprocess.Popen")
    def test_run_command_ignores_na_progress_values(self, mock_popen: MagicMock) -> None:
        process = MagicMock()
        process.stdout = iter(["out_time_ms=N/A\n", "out_time_ms=5000000\n", "progress=end\n"])
        process.stderr.read.return_value = ""
        process.wait.return_value = 0
        process.__enter__.return_value = process
        process.__exit__.return_value = False
        mock_popen.return_value = process

        updates: list[float] = []
        _run_command(
            ["ffmpeg", "-i", "input.mp4", "output.mp4"],
            total_duration=10.0,
            progress_callback=lambda percent, _message: updates.append(percent),
        )

        self.assertEqual(updates, [50.0, 100.0])


class ConvenienceHelperTests(unittest.TestCase):
    @patch("clipr.core.process_video")
    def test_make_4k_widescreen_uses_expected_defaults(self, mock_process_video: MagicMock) -> None:
        make_4k_widescreen("input.mp4", "output.mp4")
        options = mock_process_video.call_args.kwargs["options"]
        self.assertEqual(options.enhancement.upscale_width, 3840)
        self.assertEqual(options.enhancement.upscale_height, 2160)
        self.assertEqual(options.enhancement.resize_mode, ResizeMode.FILL)
        self.assertEqual(options.crop.mode, CropMode.CENTER_WIDE)
        self.assertIsNone(options.orientation)

    @patch("clipr.core.process_video")
    def test_make_instagram_reel_uses_expected_defaults(self, mock_process_video: MagicMock) -> None:
        make_instagram_reel("input.mp4", "output.mp4")
        options = mock_process_video.call_args.kwargs["options"]
        self.assertEqual(options.enhancement.upscale_width, 1080)
        self.assertEqual(options.enhancement.upscale_height, 1920)
        self.assertEqual(options.enhancement.resize_mode, ResizeMode.FIT)
        self.assertIsNone(options.crop)
        self.assertIsNone(options.orientation)
        self.assertEqual(options.social_preset, SocialPreset.INSTAGRAM_REEL)


if __name__ == "__main__":
    unittest.main()
