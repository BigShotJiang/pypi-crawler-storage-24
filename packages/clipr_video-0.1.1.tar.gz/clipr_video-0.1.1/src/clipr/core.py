from __future__ import annotations

import json
import subprocess
from dataclasses import dataclass, replace
from enum import Enum
from pathlib import Path
from typing import Callable, Iterable


ProgressCallback = Callable[[float, str], None]


class VideoToolkitError(RuntimeError):
    """Raised when a video processing operation fails."""


class OrientationMode(str, Enum):
    PORTRAIT = "portrait"
    LANDSCAPE = "landscape"
    ROTATE_90 = "rotate_90"
    ROTATE_180 = "rotate_180"
    ROTATE_270 = "rotate_270"


class CropMode(str, Enum):
    CENTER_SQUARE = "center_square"
    CENTER_VERTICAL = "center_vertical"
    CENTER_WIDE = "center_wide"


class ResizeMode(str, Enum):
    STRETCH = "stretch"
    FIT = "fit"
    FILL = "fill"


class SocialPreset(str, Enum):
    YOUTUBE = "youtube"
    INSTAGRAM_REEL = "instagram_reel"
    TIKTOK = "tiktok"
    WHATSAPP = "whatsapp"
    PRESENTATION = "presentation"


@dataclass(slots=True)
class EnhancementSettings:
    denoise: bool = True
    sharpen: bool = True
    brightness: float = 0.0
    contrast: float = 1.0
    upscale_width: int | None = None
    upscale_height: int | None = None
    resize_mode: ResizeMode = ResizeMode.STRETCH
    video_codec: str = "libx264"
    crf: int = 18
    preset: str = "medium"
    audio_codec: str = "aac"
    audio_bitrate: str = "192k"


@dataclass(slots=True)
class AudioEnhancementSettings:
    normalize: bool = True
    denoise: bool = False
    volume: float = 1.0
    sample_rate: int | None = None


@dataclass(slots=True)
class TrimSettings:
    start_time: float | None = None
    end_time: float | None = None
    duration: float | None = None


@dataclass(slots=True)
class CropSettings:
    mode: CropMode | None = None
    width: int | None = None
    height: int | None = None
    x: int | None = None
    y: int | None = None


@dataclass(slots=True)
class ProcessingOptions:
    enhancement: EnhancementSettings | None = None
    audio: AudioEnhancementSettings | None = None
    trim: TrimSettings | None = None
    crop: CropSettings | None = None
    orientation: OrientationMode | None = None
    social_preset: SocialPreset | None = None


@dataclass(slots=True)
class BatchResult:
    input_path: Path
    output_path: Path


def split_video(
    input_path: str | Path,
    segment_lengths: Iterable[int] = (30, 60, 90),
    output_dir: str | Path | None = None,
    video_codec: str = "libx264",
    crf: int = 20,
    preset: str = "medium",
    progress_callback: ProgressCallback | None = None,
) -> dict[int, list[Path]]:
    input_file = _ensure_input_file(input_path)
    lengths = _normalize_lengths(segment_lengths)
    base_output_dir = Path(output_dir) if output_dir else input_file.parent / f"{input_file.stem}_segments"
    base_output_dir.mkdir(parents=True, exist_ok=True)

    results: dict[int, list[Path]] = {}
    total_duration = probe_video_duration(input_file)

    for seconds in lengths:
        current_dir = base_output_dir / f"{seconds}s"
        current_dir.mkdir(parents=True, exist_ok=True)
        pattern = current_dir / f"{input_file.stem}_{seconds}s_%03d.mp4"
        command = [
            "ffmpeg",
            "-y",
            "-i",
            str(input_file),
            "-map",
            "0",
            "-c:v",
            video_codec,
            "-preset",
            preset,
            "-crf",
            str(crf),
            "-c:a",
            "aac",
            "-f",
            "segment",
            "-segment_time",
            str(seconds),
            "-reset_timestamps",
            "1",
            str(pattern),
        ]
        _run_command(command, total_duration=total_duration, progress_callback=progress_callback)
        results[seconds] = sorted(current_dir.glob("*.mp4"))

    return results


def enhance_video(
    input_path: str | Path,
    output_path: str | Path,
    settings: EnhancementSettings | None = None,
    audio_settings: AudioEnhancementSettings | None = None,
    trim: TrimSettings | None = None,
    crop: CropSettings | None = None,
    social_preset: SocialPreset | str | None = None,
    progress_callback: ProgressCallback | None = None,
) -> Path:
    options = ProcessingOptions(
        enhancement=settings or EnhancementSettings(),
        audio=audio_settings,
        trim=trim,
        crop=crop,
        social_preset=SocialPreset(social_preset) if social_preset else None,
    )
    return process_video(input_path, output_path, options=options, progress_callback=progress_callback)


def change_orientation(
    input_path: str | Path,
    output_path: str | Path,
    orientation: OrientationMode | str,
    video_codec: str = "libx264",
    crf: int = 18,
    preset: str = "medium",
    progress_callback: ProgressCallback | None = None,
) -> Path:
    options = ProcessingOptions(
        orientation=OrientationMode(orientation),
        enhancement=EnhancementSettings(video_codec=video_codec, crf=crf, preset=preset),
    )
    return process_video(input_path, output_path, options=options, progress_callback=progress_callback)


def process_video(
    input_path: str | Path,
    output_path: str | Path,
    options: ProcessingOptions | None = None,
    progress_callback: ProgressCallback | None = None,
) -> Path:
    input_file = _ensure_input_file(input_path)
    output_file = Path(output_path)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    cfg = options or ProcessingOptions(enhancement=EnhancementSettings())
    merged = _merge_social_preset(cfg)

    width, height = probe_video_dimensions(input_file)
    total_duration = probe_video_duration(input_file)

    command = ["ffmpeg", "-y"]
    command.extend(_build_trim_args(merged.trim))
    command.extend(["-i", str(input_file)])

    video_filters = _build_video_filters(
        enhancement=merged.enhancement,
        crop=merged.crop,
        orientation=merged.orientation,
        width=width,
        height=height,
    )
    audio_filters = _build_audio_filters(merged.audio)

    if video_filters:
        command.extend(["-vf", ",".join(video_filters)])
    if audio_filters:
        command.extend(["-af", ",".join(audio_filters)])

    enhancement = merged.enhancement or EnhancementSettings()
    command.extend(
        [
            "-c:v",
            enhancement.video_codec,
            "-preset",
            enhancement.preset,
            "-crf",
            str(enhancement.crf),
            "-c:a",
            enhancement.audio_codec,
            "-b:a",
            enhancement.audio_bitrate,
            str(output_file),
        ]
    )
    _run_command(command, total_duration=total_duration, progress_callback=progress_callback)
    return output_file


def make_4k_widescreen(
    input_path: str | Path,
    output_path: str | Path,
    progress_callback: ProgressCallback | None = None,
) -> Path:
    return process_video(
        input_path,
        output_path,
        options=ProcessingOptions(
            enhancement=EnhancementSettings(
                denoise=True,
                sharpen=True,
                brightness=0.03,
                contrast=1.08,
                upscale_width=3840,
                upscale_height=2160,
                resize_mode=ResizeMode.FILL,
            ),
            audio=AudioEnhancementSettings(
                normalize=True,
                denoise=True,
                volume=1.1,
                sample_rate=48000,
            ),
            crop=CropSettings(mode=CropMode.CENTER_WIDE),
            orientation=None,
        ),
        progress_callback=progress_callback,
    )


def make_instagram_reel(
    input_path: str | Path,
    output_path: str | Path,
    progress_callback: ProgressCallback | None = None,
) -> Path:
    return process_video(
        input_path,
        output_path,
        options=ProcessingOptions(
            enhancement=EnhancementSettings(
                denoise=True,
                sharpen=True,
                brightness=0.02,
                contrast=1.05,
                upscale_width=1080,
                upscale_height=1920,
                resize_mode=ResizeMode.FIT,
                crf=20,
            ),
            audio=AudioEnhancementSettings(
                normalize=True,
                denoise=True,
                volume=1.05,
                sample_rate=48000,
            ),
            trim=None,
            crop=None,
            orientation=None,
            social_preset=SocialPreset.INSTAGRAM_REEL,
        ),
        progress_callback=progress_callback,
    )


def batch_process_videos(
    input_paths: Iterable[str | Path],
    output_dir: str | Path,
    options: ProcessingOptions | None = None,
    progress_callback: ProgressCallback | None = None,
) -> list[BatchResult]:
    output_root = Path(output_dir)
    output_root.mkdir(parents=True, exist_ok=True)
    results: list[BatchResult] = []

    for input_path in input_paths:
        input_file = _ensure_input_file(input_path)
        output_file = output_root / f"{input_file.stem}_processed.mp4"
        scoped_callback = None
        if progress_callback:
            scoped_callback = lambda percent, message, file=input_file: progress_callback(
                percent, f"{file.name}: {message}"
            )
        process_video(input_file, output_file, options=options, progress_callback=scoped_callback)
        results.append(BatchResult(input_path=input_file, output_path=output_file))

    return results


def batch_process_directory(
    input_dir: str | Path,
    output_dir: str | Path,
    options: ProcessingOptions | None = None,
    extensions: Iterable[str] = (".mp4", ".mov", ".mkv", ".avi", ".webm"),
    progress_callback: ProgressCallback | None = None,
) -> list[BatchResult]:
    directory = Path(input_dir)
    if not directory.exists() or not directory.is_dir():
        raise VideoToolkitError(f"Input directory does not exist: {directory}")
    allowed = {ext.lower() for ext in extensions}
    files = sorted(path for path in directory.iterdir() if path.is_file() and path.suffix.lower() in allowed)
    if not files:
        raise VideoToolkitError(f"No supported video files found in {directory}")
    return batch_process_videos(files, output_dir=output_dir, options=options, progress_callback=progress_callback)


def probe_video_dimensions(input_path: str | Path) -> tuple[int, int]:
    input_file = _ensure_input_file(input_path)
    data = _probe_video_stream(input_file)
    width = data.get("width")
    height = data.get("height")
    if not width or not height:
        raise VideoToolkitError(f"Missing width/height metadata for {input_file}")
    return int(width), int(height)


def probe_video_duration(input_path: str | Path) -> float:
    input_file = _ensure_input_file(input_path)
    command = [
        "ffprobe",
        "-v",
        "error",
        "-show_entries",
        "format=duration",
        "-of",
        "json",
        str(input_file),
    ]
    completed = _run_command(command)
    data = json.loads(completed.stdout or "{}")
    duration = data.get("format", {}).get("duration")
    if duration is None:
        raise VideoToolkitError(f"Could not read video duration for {input_file}")
    return float(duration)


def _probe_video_stream(input_file: Path) -> dict[str, object]:
    command = [
        "ffprobe",
        "-v",
        "error",
        "-select_streams",
        "v:0",
        "-show_entries",
        "stream=width,height",
        "-of",
        "json",
        str(input_file),
    ]
    completed = _run_command(command)
    data = json.loads(completed.stdout or "{}")
    streams = data.get("streams", [])
    if not streams:
        raise VideoToolkitError(f"Could not read video dimensions for {input_file}")
    return streams[0]


def _build_video_filters(
    enhancement: EnhancementSettings | None,
    crop: CropSettings | None,
    orientation: OrientationMode | None,
    width: int,
    height: int,
) -> list[str]:
    filters: list[str] = []
    if crop:
        filters.extend(_build_crop_filters(crop, width, height))
    if orientation:
        filters.extend(_build_orientation_filters(orientation, width, height))
    if enhancement:
        filters.extend(_build_enhancement_filters(enhancement))
    return filters


def _build_enhancement_filters(settings: EnhancementSettings) -> list[str]:
    filters: list[str] = []
    if settings.denoise:
        filters.append("hqdn3d=1.5:1.5:6:6")
    if settings.sharpen:
        filters.append("unsharp=5:5:1.0:5:5:0.0")
    if settings.brightness != 0.0 or settings.contrast != 1.0:
        filters.append(f"eq=brightness={settings.brightness}:contrast={settings.contrast}")
    if settings.upscale_width and settings.upscale_height:
        filters.extend(
            _build_resize_filters(
                settings.upscale_width,
                settings.upscale_height,
                settings.resize_mode,
            )
        )
    elif settings.upscale_width or settings.upscale_height:
        raise VideoToolkitError("Both upscale_width and upscale_height must be provided together.")
    return filters


def _build_resize_filters(width: int, height: int, mode: ResizeMode) -> list[str]:
    if mode == ResizeMode.STRETCH:
        return [f"scale={width}:{height}:flags=lanczos"]
    if mode == ResizeMode.FIT:
        return [
            f"scale={width}:{height}:force_original_aspect_ratio=decrease:flags=lanczos",
            f"pad={width}:{height}:(ow-iw)/2:(oh-ih)/2:color=black",
        ]
    if mode == ResizeMode.FILL:
        return [
            f"scale={width}:{height}:force_original_aspect_ratio=increase:flags=lanczos",
            f"crop={width}:{height}",
        ]
    raise VideoToolkitError(f"Unsupported resize mode: {mode}")


def _build_audio_filters(settings: AudioEnhancementSettings | None) -> list[str]:
    if settings is None:
        return []
    filters: list[str] = []
    if settings.denoise:
        filters.append("afftdn")
    if settings.normalize:
        filters.append("loudnorm")
    if settings.volume != 1.0:
        filters.append(f"volume={settings.volume}")
    if settings.sample_rate:
        filters.append(f"aresample={settings.sample_rate}")
    return filters


def _build_trim_args(trim: TrimSettings | None) -> list[str]:
    if trim is None:
        return []
    args: list[str] = []
    if trim.start_time is not None:
        if trim.start_time < 0:
            raise VideoToolkitError("Trim start_time cannot be negative.")
        args.extend(["-ss", str(trim.start_time)])
    if trim.end_time is not None and trim.duration is not None:
        raise VideoToolkitError("Provide either end_time or duration, not both.")
    if trim.end_time is not None:
        if trim.start_time is not None and trim.end_time <= trim.start_time:
            raise VideoToolkitError("Trim end_time must be greater than start_time.")
        args.extend(["-to", str(trim.end_time)])
    if trim.duration is not None:
        if trim.duration <= 0:
            raise VideoToolkitError("Trim duration must be positive.")
        args.extend(["-t", str(trim.duration)])
    return args


def _build_crop_filters(crop: CropSettings, width: int, height: int) -> list[str]:
    if crop.mode is not None:
        return [_build_crop_filter_for_mode(crop.mode, width, height)]
    if crop.width is None or crop.height is None:
        raise VideoToolkitError("Custom crop requires width and height.")
    x = crop.x if crop.x is not None else max((width - crop.width) // 2, 0)
    y = crop.y if crop.y is not None else max((height - crop.height) // 2, 0)
    return [f"crop={crop.width}:{crop.height}:{x}:{y}"]


def _build_crop_filter_for_mode(mode: CropMode, width: int, height: int) -> str:
    if mode == CropMode.CENTER_SQUARE:
        size = min(width, height)
        x = (width - size) // 2
        y = (height - size) // 2
        return f"crop={size}:{size}:{x}:{y}"
    if mode == CropMode.CENTER_VERTICAL:
        target_width = min(width, (height * 9) // 16)
        x = (width - target_width) // 2
        return f"crop={target_width}:{height}:{x}:0"
    if mode == CropMode.CENTER_WIDE:
        target_height = min(height, (width * 9) // 16)
        y = (height - target_height) // 2
        return f"crop={width}:{target_height}:0:{y}"
    raise VideoToolkitError(f"Unsupported crop mode: {mode}")


def _build_orientation_filters(
    mode: OrientationMode,
    width: int,
    height: int,
) -> list[str]:
    if mode == OrientationMode.ROTATE_90:
        return ["transpose=1"]
    if mode == OrientationMode.ROTATE_180:
        return ["transpose=1", "transpose=1"]
    if mode == OrientationMode.ROTATE_270:
        return ["transpose=2"]
    if mode == OrientationMode.PORTRAIT:
        return [] if height >= width else ["transpose=1"]
    if mode == OrientationMode.LANDSCAPE:
        return [] if width >= height else ["transpose=1"]
    raise VideoToolkitError(f"Unsupported orientation mode: {mode}")


def _merge_social_preset(options: ProcessingOptions) -> ProcessingOptions:
    if options.social_preset is None:
        if options.enhancement is None:
            return replace(options, enhancement=EnhancementSettings())
        return options

    preset_options = _social_preset_options(options.social_preset)
    merged = ProcessingOptions(
        enhancement=_merge_enhancement(preset_options.enhancement, options.enhancement),
        audio=options.audio or preset_options.audio,
        trim=options.trim,
        crop=options.crop or preset_options.crop,
        orientation=options.orientation or preset_options.orientation,
        social_preset=options.social_preset,
    )
    return merged


def _social_preset_options(preset: SocialPreset) -> ProcessingOptions:
    if preset == SocialPreset.YOUTUBE:
        return ProcessingOptions(
            enhancement=EnhancementSettings(
                upscale_width=1920,
                upscale_height=1080,
                resize_mode=ResizeMode.FILL,
                crf=18,
            ),
            audio=AudioEnhancementSettings(normalize=True),
            orientation=None,
        )
    if preset == SocialPreset.INSTAGRAM_REEL:
        return ProcessingOptions(
            enhancement=EnhancementSettings(
                upscale_width=1080,
                upscale_height=1920,
                resize_mode=ResizeMode.FIT,
                crf=20,
            ),
            audio=AudioEnhancementSettings(normalize=True),
            crop=None,
            orientation=None,
        )
    if preset == SocialPreset.TIKTOK:
        return ProcessingOptions(
            enhancement=EnhancementSettings(
                upscale_width=1080,
                upscale_height=1920,
                resize_mode=ResizeMode.FIT,
                crf=20,
            ),
            audio=AudioEnhancementSettings(normalize=True, denoise=True),
            crop=None,
            orientation=None,
        )
    if preset == SocialPreset.WHATSAPP:
        return ProcessingOptions(
            enhancement=EnhancementSettings(
                upscale_width=720,
                upscale_height=1280,
                resize_mode=ResizeMode.FIT,
                crf=24,
            ),
            audio=AudioEnhancementSettings(normalize=True),
            crop=None,
            orientation=None,
        )
    if preset == SocialPreset.PRESENTATION:
        return ProcessingOptions(
            enhancement=EnhancementSettings(
                upscale_width=1920,
                upscale_height=1080,
                resize_mode=ResizeMode.FIT,
                crf=18,
                sharpen=False,
            ),
            audio=AudioEnhancementSettings(normalize=True, volume=1.1),
            orientation=None,
        )
    raise VideoToolkitError(f"Unsupported social preset: {preset}")


def _merge_enhancement(
    base: EnhancementSettings | None,
    override: EnhancementSettings | None,
) -> EnhancementSettings:
    if base is None and override is None:
        return EnhancementSettings()
    if base is None:
        return override or EnhancementSettings()
    if override is None:
        return base
    return replace(
        base,
        denoise=override.denoise,
        sharpen=override.sharpen,
        brightness=override.brightness,
        contrast=override.contrast,
        upscale_width=override.upscale_width or base.upscale_width,
        upscale_height=override.upscale_height or base.upscale_height,
        resize_mode=override.resize_mode,
        video_codec=override.video_codec,
        crf=override.crf,
        preset=override.preset,
        audio_codec=override.audio_codec,
        audio_bitrate=override.audio_bitrate,
    )


def _normalize_lengths(segment_lengths: Iterable[int]) -> list[int]:
    values = sorted({int(length) for length in segment_lengths})
    if not values:
        raise VideoToolkitError("At least one segment length must be provided.")
    if any(value <= 0 for value in values):
        raise VideoToolkitError("Segment lengths must be positive integers.")
    return values


def _ensure_input_file(input_path: str | Path) -> Path:
    path = Path(input_path)
    if not path.exists():
        raise VideoToolkitError(f"Input video does not exist: {path}")
    if not path.is_file():
        raise VideoToolkitError(f"Input path is not a file: {path}")
    return path


def _run_command(
    command: list[str],
    total_duration: float | None = None,
    progress_callback: ProgressCallback | None = None,
) -> subprocess.CompletedProcess[str]:
    if progress_callback is None or total_duration is None:
        return _run_simple_command(command)

    progress_command = command[:1] + ["-progress", "pipe:1", "-nostats"] + command[1:]
    try:
        with subprocess.Popen(
            progress_command,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        ) as process:
            latest_out_time = 0.0
            assert process.stdout is not None
            for line in process.stdout:
                line = line.strip()
                if line.startswith("out_time_ms="):
                    raw_out_time = line.split("=", 1)[1]
                    if raw_out_time == "N/A":
                        continue
                    latest_out_time = int(raw_out_time) / 1_000_000
                    percent = min((latest_out_time / total_duration) * 100, 100.0)
                    progress_callback(percent, f"{percent:.1f}%")
                elif line.startswith("progress=") and line.endswith("end"):
                    progress_callback(100.0, "100.0%")
            stderr = process.stderr.read() if process.stderr is not None else ""
            returncode = process.wait()
    except FileNotFoundError as exc:
        raise VideoToolkitError(
            f"Required executable not found while running: {' '.join(command)}"
        ) from exc

    if returncode != 0:
        raise VideoToolkitError(stderr.strip() or "Video processing command failed.")

    return subprocess.CompletedProcess(progress_command, returncode, "", stderr)


def _run_simple_command(command: list[str]) -> subprocess.CompletedProcess[str]:
    try:
        completed = subprocess.run(
            command,
            capture_output=True,
            text=True,
            check=True,
        )
    except FileNotFoundError as exc:
        raise VideoToolkitError(
            f"Required executable not found while running: {' '.join(command)}"
        ) from exc
    except subprocess.CalledProcessError as exc:
        raise VideoToolkitError(exc.stderr.strip() or "Video processing command failed.") from exc
    return completed
