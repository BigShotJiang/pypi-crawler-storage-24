from __future__ import annotations

import argparse
import sys
from pathlib import Path

from .core import (
    AudioEnhancementSettings,
    CropMode,
    CropSettings,
    EnhancementSettings,
    OrientationMode,
    ProcessingOptions,
    SocialPreset,
    TrimSettings,
    VideoToolkitError,
    batch_process_directory,
    change_orientation,
    enhance_video,
    process_video,
    split_video,
)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="clipr",
        description="CLIPR: Clip Improvement, Processing, and Reframing.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    split_parser = subparsers.add_parser("split", help="Split a video into fixed-duration chunks.")
    split_parser.add_argument("input", type=Path, help="Path to the input video.")
    split_parser.add_argument("--durations", type=int, nargs="+", default=[30, 60, 90], help="Chunk lengths in seconds.")
    split_parser.add_argument("--output-dir", type=Path, default=None, help="Base output directory for generated chunks.")
    split_parser.add_argument("--show-progress", action="store_true", help="Print ffmpeg progress updates.")

    enhance_parser = subparsers.add_parser("enhance", help="Enhance the quality of a video.")
    enhance_parser.add_argument("input", type=Path, help="Path to the input video.")
    enhance_parser.add_argument("output", type=Path, help="Path for the enhanced video.")
    enhance_parser.add_argument("--no-denoise", action="store_false", dest="denoise", help="Disable the default denoise filter.")
    enhance_parser.add_argument("--no-sharpen", action="store_false", dest="sharpen", help="Disable the default sharpen filter.")
    enhance_parser.set_defaults(denoise=True, sharpen=True)
    enhance_parser.add_argument("--brightness", type=float, default=0.0, help="Brightness adjustment.")
    enhance_parser.add_argument("--contrast", type=float, default=1.0, help="Contrast adjustment.")
    enhance_parser.add_argument("--upscale-width", type=int, default=None, help="Upscale width in pixels.")
    enhance_parser.add_argument("--upscale-height", type=int, default=None, help="Upscale height in pixels.")
    enhance_parser.add_argument("--audio-denoise", action="store_true", help="Reduce background noise in audio.")
    enhance_parser.add_argument("--no-audio-normalize", action="store_false", dest="audio_normalize", help="Disable audio normalization.")
    enhance_parser.add_argument("--volume", type=float, default=1.0, help="Audio volume multiplier.")
    enhance_parser.add_argument("--sample-rate", type=int, default=None, help="Target audio sample rate.")
    enhance_parser.add_argument("--start-time", type=float, default=None, help="Trim start time in seconds.")
    enhance_parser.add_argument("--end-time", type=float, default=None, help="Trim end time in seconds.")
    enhance_parser.add_argument("--duration", type=float, default=None, help="Trim duration in seconds.")
    enhance_parser.add_argument("--crop-mode", type=str, choices=[mode.value for mode in CropMode], default=None, help="Preset crop mode.")
    enhance_parser.add_argument("--crop-width", type=int, default=None, help="Custom crop width.")
    enhance_parser.add_argument("--crop-height", type=int, default=None, help="Custom crop height.")
    enhance_parser.add_argument("--crop-x", type=int, default=None, help="Custom crop X offset.")
    enhance_parser.add_argument("--crop-y", type=int, default=None, help="Custom crop Y offset.")
    enhance_parser.add_argument("--social-preset", type=str, choices=[preset.value for preset in SocialPreset], default=None, help="Apply a social-media preset.")
    enhance_parser.add_argument("--show-progress", action="store_true", help="Print ffmpeg progress updates.")
    enhance_parser.set_defaults(audio_normalize=True)

    orient_parser = subparsers.add_parser("orient", help="Change the orientation of a video.")
    orient_parser.add_argument("input", type=Path, help="Path to the input video.")
    orient_parser.add_argument("output", type=Path, help="Path for the output video.")
    orient_parser.add_argument("--mode", type=str, choices=[mode.value for mode in OrientationMode], required=True, help="Orientation mode to apply.")
    orient_parser.add_argument("--show-progress", action="store_true", help="Print ffmpeg progress updates.")

    process_parser = subparsers.add_parser("process", help="Run a full processing pipeline on a single video.")
    process_parser.add_argument("input", type=Path, help="Path to the input video.")
    process_parser.add_argument("output", type=Path, help="Path for the processed video.")
    process_parser.add_argument("--social-preset", type=str, choices=[preset.value for preset in SocialPreset], default=None, help="Apply a social-media preset.")
    process_parser.add_argument("--orientation", type=str, choices=[mode.value for mode in OrientationMode], default=None, help="Orientation mode.")
    process_parser.add_argument("--crop-mode", type=str, choices=[mode.value for mode in CropMode], default=None, help="Preset crop mode.")
    process_parser.add_argument("--start-time", type=float, default=None, help="Trim start time in seconds.")
    process_parser.add_argument("--end-time", type=float, default=None, help="Trim end time in seconds.")
    process_parser.add_argument("--duration", type=float, default=None, help="Trim duration in seconds.")
    process_parser.add_argument("--audio-denoise", action="store_true", help="Reduce background noise in audio.")
    process_parser.add_argument("--no-audio-normalize", action="store_false", dest="audio_normalize", help="Disable audio normalization.")
    process_parser.add_argument("--volume", type=float, default=1.0, help="Audio volume multiplier.")
    process_parser.add_argument("--show-progress", action="store_true", help="Print ffmpeg progress updates.")
    process_parser.set_defaults(audio_normalize=True)

    batch_parser = subparsers.add_parser("batch", help="Process all videos in a directory.")
    batch_parser.add_argument("input_dir", type=Path, help="Directory containing input videos.")
    batch_parser.add_argument("output_dir", type=Path, help="Directory for processed output videos.")
    batch_parser.add_argument("--social-preset", type=str, choices=[preset.value for preset in SocialPreset], default=None, help="Apply a social-media preset.")
    batch_parser.add_argument("--orientation", type=str, choices=[mode.value for mode in OrientationMode], default=None, help="Orientation mode.")
    batch_parser.add_argument("--crop-mode", type=str, choices=[mode.value for mode in CropMode], default=None, help="Preset crop mode.")
    batch_parser.add_argument("--start-time", type=float, default=None, help="Trim start time in seconds.")
    batch_parser.add_argument("--end-time", type=float, default=None, help="Trim end time in seconds.")
    batch_parser.add_argument("--duration", type=float, default=None, help="Trim duration in seconds.")
    batch_parser.add_argument("--audio-denoise", action="store_true", help="Reduce background noise in audio.")
    batch_parser.add_argument("--no-audio-normalize", action="store_false", dest="audio_normalize", help="Disable audio normalization.")
    batch_parser.add_argument("--volume", type=float, default=1.0, help="Audio volume multiplier.")
    batch_parser.add_argument("--show-progress", action="store_true", help="Print ffmpeg progress updates.")
    batch_parser.set_defaults(audio_normalize=True)

    return parser


def _progress_printer(enabled: bool):
    if not enabled:
        return None

    state = {"completed": False}

    def callback(percent: float, message: str) -> None:
        percent = max(0.0, min(percent, 100.0))
        width = 28
        filled = int((percent / 100.0) * width)
        bar = "#" * filled + "-" * (width - filled)
        line = f"\r[{bar}] {percent:6.2f}% {message:<24}"
        sys.stdout.write(line)
        sys.stdout.flush()
        if percent >= 100.0 and not state["completed"]:
            sys.stdout.write("\n")
            sys.stdout.flush()
            state["completed"] = True
        elif percent < 100.0:
            state["completed"] = False

    return callback


def _build_trim(args: argparse.Namespace) -> TrimSettings | None:
    if args.start_time is None and args.end_time is None and args.duration is None:
        return None
    return TrimSettings(start_time=args.start_time, end_time=args.end_time, duration=args.duration)


def _build_crop(args: argparse.Namespace) -> CropSettings | None:
    crop_mode = getattr(args, "crop_mode", None)
    crop_width = getattr(args, "crop_width", None)
    crop_height = getattr(args, "crop_height", None)
    crop_x = getattr(args, "crop_x", None)
    crop_y = getattr(args, "crop_y", None)
    if crop_mode is None and crop_width is None and crop_height is None:
        return None
    mode = CropMode(crop_mode) if crop_mode else None
    return CropSettings(mode=mode, width=crop_width, height=crop_height, x=crop_x, y=crop_y)


def _build_audio(args: argparse.Namespace) -> AudioEnhancementSettings | None:
    if not args.audio_denoise and args.audio_normalize and args.volume == 1.0 and getattr(args, "sample_rate", None) is None:
        return AudioEnhancementSettings()
    return AudioEnhancementSettings(
        normalize=args.audio_normalize,
        denoise=args.audio_denoise,
        volume=args.volume,
        sample_rate=getattr(args, "sample_rate", None),
    )


def _build_options(args: argparse.Namespace) -> ProcessingOptions:
    social_preset = SocialPreset(args.social_preset) if args.social_preset else None
    orientation = OrientationMode(args.orientation) if getattr(args, "orientation", None) else None
    return ProcessingOptions(
        enhancement=None,
        audio=_build_audio(args),
        trim=_build_trim(args),
        crop=_build_crop(args),
        orientation=orientation,
        social_preset=social_preset,
    )


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    try:
        if args.command == "split":
            results = split_video(
                args.input,
                segment_lengths=args.durations,
                output_dir=args.output_dir,
                progress_callback=_progress_printer(args.show_progress),
            )
            for seconds, paths in results.items():
                print(f"{seconds}s: {len(paths)} file(s)")
                for path in paths:
                    print(path)
            return 0

        if args.command == "enhance":
            settings = EnhancementSettings(
                denoise=args.denoise,
                sharpen=args.sharpen,
                brightness=args.brightness,
                contrast=args.contrast,
                upscale_width=args.upscale_width,
                upscale_height=args.upscale_height,
            )
            output = enhance_video(
                args.input,
                args.output,
                settings=settings,
                audio_settings=_build_audio(args),
                trim=_build_trim(args),
                crop=_build_crop(args),
                social_preset=args.social_preset,
                progress_callback=_progress_printer(args.show_progress),
            )
            print(output)
            return 0

        if args.command == "orient":
            output = change_orientation(
                args.input,
                args.output,
                OrientationMode(args.mode),
                progress_callback=_progress_printer(args.show_progress),
            )
            print(output)
            return 0

        if args.command == "process":
            options = _build_options(args)
            output = process_video(
                args.input,
                args.output,
                options=options,
                progress_callback=_progress_printer(args.show_progress),
            )
            print(output)
            return 0

        if args.command == "batch":
            options = _build_options(args)
            results = batch_process_directory(
                args.input_dir,
                args.output_dir,
                options=options,
                progress_callback=_progress_printer(args.show_progress),
            )
            for result in results:
                print(f"{result.input_path} -> {result.output_path}")
            return 0

    except VideoToolkitError as exc:
        parser.exit(status=1, message=f"Error: {exc}\n")

    return 1


if __name__ == "__main__":
    raise SystemExit(main())
