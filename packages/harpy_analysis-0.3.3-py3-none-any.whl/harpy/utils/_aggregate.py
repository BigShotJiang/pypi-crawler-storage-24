from __future__ import annotations

from collections.abc import Callable
from functools import partial
from typing import Literal

import dask.array as da
import numpy as np
import pandas as pd
from dask_image import ndmeasure
from loguru import logger as log
from numpy.typing import NDArray
from scipy import ndimage

from harpy.utils._keys import _CELLSIZE_KEY, _INSTANCE_KEY
from harpy.utils.utils import _da_unique, _get_xp, _to_cupy_dask_array, _to_numpy


class RasterAggregator:
    """
    Helper class to calulate aggregated 'sum', 'mean', 'var', 'kurtosis', 'skew', 'area', 'min', 'max', 'center of mass', 'radii' or 'principal_axes' of image and labels using Dask.

    Parameters
    ----------
    mask_dask_array
        A 3D Dask array of integer labels representing segmented regions.
        Expected shape is ('z', 'y', 'x'). Each unique integer value represents a separate label.
    image_dask_array
        A 4D Dask array representing the image data with shape ('c', 'z', 'y', 'x'),
        where 'c' is the number of channels. Can be `None` if only mask-based computations
        (e.g., count or center of mass) are required.
    instance_key
        name of the instance key
    instance_size_key
        name of the instance size key
    run_on_gpu
        Whether to run on gpu. If no installation of cupy could be detected, will fall back to cpu.

    Raises
    ------
    ValueError
        If `mask_dask_array` does not contain an integer dtype.
    AssertionError
        If `mask_dask_array` is not 3D.
    AssertionError
        If `image_dask_array` is provided but is not 4D.
    AssertionError
        If spatial dimensions of `image_dask_array` and `mask_dask_array` do not match.
    AssertionError
        If chunk sizes of spatial dimensions do not match between image and mask.

    Notes
    -----
    The aggregate operation computes statistics per chunk.
    For each chunk in `mask_dask_array` and `image_dask_array`, it
    produces a matrix with shape (i, c, z, y, x), where:

    - i: total number of labels in the global mask
    - c: number of channels in the chunk
    - z = 1, y = 1, x = 1

    These matrices (chunks) are then aggregated, to obtain statistics for the
    global mask and image.

    We intentionally avoid the optimization of setting i to the maximum number of
    labels in any chunk, because this would require an additional pass over the
    global mask to count labels per chunk (as done in :class:`harpy.utils.Featurizer`).

    Because i typically ranges from thousands to millions, and because only a single
    feature (e.g., a mean statistic) is computed, each chunk of the aggregated
    matrix remains under ~50 MB (for a chunksize of c = 1), even when the global
    mask contains around 10 million labels.

    By chunking the underlying dask arrays along the (c, z, y, x) dimensions in the
    on-disk Zarr store, the user can effectively control RAM usage during
    aggregation. As a practical guideline, choose chunk sizes of roughly
    z, y, x ≈ 4096 and c ≈ 5, adjusting these values based on the available memory.
    """

    def __init__(
        self,
        mask_dask_array: da.Array,
        image_dask_array: da.Array | None = None,
        instance_key: str = _INSTANCE_KEY,
        instance_size_key: str = _CELLSIZE_KEY,
        run_on_gpu: bool = True,
    ):
        if not np.issubdtype(mask_dask_array.dtype, np.integer):
            raise ValueError(f"'mask_dask_array' should contains chunks of type {np.integer}.")
        self._image = None
        if image_dask_array is not None:
            assert image_dask_array.ndim == 4, "Currently only 4D image arrays are supported ('c', 'z', 'y', 'x')."
            assert image_dask_array.shape[1:] == mask_dask_array.shape, (
                "The mask and the image should have the same spatial dimensions ('z', 'y', 'x')."
            )
            assert image_dask_array.chunksize[1:] == mask_dask_array.chunksize, (
                "Provided mask ('mask_dask_array') and image ('image_dask_array') do not have the same chunksize in ( 'z', 'y', 'x' ). Please rechunk."
            )
            self._image = image_dask_array
        assert mask_dask_array.ndim == 3, "Currently only 3D masks are supported ('z', 'y', 'x')."

        if run_on_gpu:
            try:
                import cupy

                _ = cupy
            except ImportError:
                log.warning(
                    "Parameter 'run_on_gpu' was set to True, but 'cupy' is not installed. "
                    "Falling back to CPU execution. Please install 'cupy' to enable GPU support."
                )
                run_on_gpu = False

        if run_on_gpu:
            mask_dask_array = _to_cupy_dask_array(mask_dask_array)
            if self._image is not None:
                self._image = _to_cupy_dask_array(self._image)

        self._mask = mask_dask_array
        self._instance_key = instance_key
        self._instance_size_key = instance_size_key
        # where area will be saved (avoid recomputation)
        self._count = None
        # where mean will be saved (avoid recomputation)
        self._mean = None
        self._run_on_gpu = run_on_gpu

    def aggregate_stats(
        self,
        stats_funcs: tuple[str, ...] = ("sum", "mean", "count", "var", "kurtosis", "skew"),
        index: NDArray | None = None,
    ) -> list[pd.DataFrame]:
        """
        Computes multiple statistical metrics for each label in the mask, across all image channels.

        Parameters
        ----------
        stats_funcs
            A tuple of statistical functions to apply. Supported values include: "sum", "mean",
            "count", "var", "kurtosis", and "skew". Defaults to all.
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        A list of DataFrames, each corresponding to one of the requested statistics.
        Each DataFrame contains one row per label a column per image channel and a column with the label ID,
        except for stat "count", which only contains a column with the counts and a column with the label ID.

        Example
        --------
        .. code-block:: python

            import harpy as hp

            # Load example dataset
            sdata = hp.datasets.pixie_example()

            img_layer = "raw_image_fov0"
            labels_layer = "label_whole_fov0"

            image_array = hp.im.get_dataarray(sdata, layer=img_layer).data
            mask_array = hp.im.get_dataarray(sdata, layer=labels_layer).data

            # Add dummy z dimension
            image_array = image_array[:, None, ...]
            mask_array = mask_array[None, ...]

            aggregator = hp.utils.RasterAggregator(
                mask_dask_array=mask_array,
                image_dask_array=image_array,
            )

            df_mean, df_area = aggregator.aggregate_stats(
                stats_funcs=("mean", "count")
            )

        See Also
        --------
        harpy.tb.allocate_intensity : create an AnnData table from raster data.
        """
        if index is None:
            index = _da_unique(self._mask, run_on_gpu=self._run_on_gpu)
        if isinstance(stats_funcs, str):
            stats_funcs = (stats_funcs,)
        results = self._aggregate_stats(stats_funcs=stats_funcs, index=index)
        dfs = []
        for _result in results:
            df = pd.DataFrame(_to_numpy(_result))
            df[self._instance_key] = _to_numpy(index)
            dfs.append(df)

        return dfs

    def aggregate_sum(
        self,
        index: NDArray | None = None,
    ) -> pd.DataFrame:
        """
        Computes the sum of pixel values within each labeled region for all image channels.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        DataFrame where rows represent labels and columns represent channels.
        """
        return self._aggregate(
            aggregate_func=partial(self._aggregate_stats, stats_funcs=("sum"), index=index), index=index
        )

    def aggregate_mean(
        self,
        index: NDArray | None = None,
    ) -> pd.DataFrame:
        """
        Computes the mean of pixel values within each labeled region for all image channels.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        DataFrame where rows represent labels and columns represent channels.
        """
        return self._aggregate(
            aggregate_func=partial(self._aggregate_stats, stats_funcs=("mean"), index=index), index=index
        )

    def aggregate_var(
        self,
        index: NDArray | None = None,
    ) -> pd.DataFrame:
        """
        Computes the variance of pixel values within each labeled region for all image channels.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        DataFrame where rows represent labels and columns represent channels.
        """
        return self._aggregate(
            aggregate_func=partial(self._aggregate_stats, stats_funcs=("var"), index=index), index=index
        )

    def aggregate_kurtosis(
        self,
        index: NDArray | None = None,
    ) -> pd.DataFrame:
        """
        Computes the kurtosis of pixel values within each labeled region for all image channels.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        DataFrame where rows represent labels and columns represent channels.
        """
        return self._aggregate(
            aggregate_func=partial(self._aggregate_stats, stats_funcs=("kurtosis"), index=index), index=index
        )

    def aggregate_skew(
        self,
        index: NDArray | None = None,
    ) -> pd.DataFrame:
        """
        Computes the skewness of pixel values within each labeled region for all image channels.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        DataFrame where rows represent labels and columns represent channels.
        """
        return self._aggregate(
            aggregate_func=partial(self._aggregate_stats, stats_funcs=("skew"), index=index), index=index
        )

    def aggregate_max(
        self,
        index: NDArray | None = None,
    ) -> pd.DataFrame:
        """
        Computes the maximum pixel value within each labeled region for all image channels.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        DataFrame where rows represent labels and columns represent channels.
        """
        return self._aggregate(aggregate_func=partial(self._aggregate_max, index=index), index=index)

    def aggregate_min(
        self,
        index: NDArray | None = None,
    ) -> pd.DataFrame:
        """
        Computes the minimum pixel value within each labeled region for all image channels.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        DataFrame where rows represent labels and columns represent channels.
        """
        return self._aggregate(aggregate_func=partial(self._aggregate_min, index=index), index=index)

    def aggregate_area(self, index: NDArray | None = None) -> pd.DataFrame:
        """
        Computes the area (number of pixels) for each labeled region in the mask.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        A DataFrame with one column for area and one for label ID.
        """
        return _get_mask_area(
            self._mask, index=index, instance_key=self._instance_key, instance_size_key=self._instance_size_key
        )

    def center_of_mass(self, index: NDArray | None = None) -> pd.DataFrame:
        """
        Computes the center of mass for each labeled region in the mask.

        Parameters
        ----------
        index
            Labels to consider. If None all labels will be considered, including background.

        Returns
        -------
        A DataFrame with columns for spatial coordinates (z,y,x) and label ID.
        """
        if index is None:
            index = _da_unique(self._mask, run_on_gpu=self._run_on_gpu)
        center_of_mass = self._center_of_mass(index=index)
        df = pd.DataFrame(_to_numpy(center_of_mass))
        df[self._instance_key] = _to_numpy(index)
        return df

    '''
    def aggregate_quantiles(
        self,
        depth: int,
        quantiles: list[float] | NDArray | None = None,
        quantile_background: bool = False,
    ) -> list[pd.DataFrame]:
        """
        Computes quantiles of pixel values for each label in the mask, across all channels.

        Parameters
        ----------
        depth
            Depth to apply during Dask's `map_overlap` operation. Set depth > estimated diameter of labels.
        quantiles
            List of quantile values to compute (between 0 and 1). Defaults to [0.1, ..., 0.9].
        quantile_background
            Whether to include background label (0) in computation. Defaults to False.

        Returns
        -------
        List of DataFrames, one per quantile, with rows as labels and columns as channels.
        """
        log.warning(
            "'RasterAggregator.aggregate_quantiles' is deprecated and will be removed in a future release. "
            "Please use 'harpy.utils.Featurizer.quantiles' instead."
        )
        # Returns a list of pandas DataFrames, one for per quantile.
        # Each DataFrame contains cells as rows and channels as columns.
        if quantiles is None:
            quantiles = np.linspace(0.1, 0.9, 9)
        # return a list of dataframes, one dataframe per quantile
        if quantile_background:
            _labels = self._labels
        else:
            _labels = self._labels[self._labels != 0]

        result = np.full((len(self._image), len(_labels), len(quantiles)), np.nan, dtype=np.float32)
        for i, _c_image in enumerate(self._image):
            result[i] = self._aggregate_quantiles_channel(
                image=_c_image,
                mask=self._mask,
                depth=depth,
                quantiles=quantiles,
                quantile_background=quantile_background,
            )

        result = result.transpose(2, 1, 0)  # shape after transpose: (nr_of_quantiles, nr_of_labels, nr_of_channels)
        dfs = [pd.DataFrame(_result) for _result in result]

        for _df in dfs:
            _df[self._instance_key] = _labels

        return dfs
    '''

    '''
    def aggregate_radii_and_axes(self, depth: int, calculate_axes: bool = True) -> pd.DataFrame:
        """
        Computes and aggregates radii and principal axes for segmented regions in the mask.

        This method returns a pandas DataFrame where each row represents a segmented cell.
        The DataFrame includes a column for the cell ID, three columns for the radii (sorted
        from largest to smallest), and optionally, nine columns (3*3) for the principal axes.

        Parameters
        ----------
        depth
            The depth at which the aggregation is performed, passed to `dask.array.map_overlap`.
            Please set `depth` > expected diameter of the labels.
        calculate_axes
            If True, the DataFrame will include the principal axes (default is True).

        Returns
        -------
        A DataFrame where:
        - Each row corresponds to a segmented cell, sorted by cell ID.
        - The next three columns contain the radii (sorted from highest to lowest).
        - If `calculate_axes` is True, the next nine columns contain the corresponding principal axes (flattened 3*3 matrix).
        - One column contains the cell ID.
        """
        log.warning(
            "'RasterAggregator.aggregate_radii_and_axes' is deprecated and will be removed in a future release. "
            "Please use 'harpy.utils.Featurizer.radii_and_principal_axes' instead."
        )
        results = self.aggregate_custom_channel(
            image=None,
            mask=self._mask,
            depth=depth,
            features=self._mask.ndim + self._mask.ndim * self._mask.ndim
            if calculate_axes
            else self._mask.ndim,  # returns 3 radii and 3 axis with (z,y,x) coordinates.
            dtype=np.float32,
            fn=_all_region_radii_and_axes,
            fn_kwargs={"calculate_axes": calculate_axes},
        )
        df = pd.DataFrame(results)
        df[self._instance_key] = self._labels[self._labels != 0]
        return df
    '''

    def _aggregate(
        self, aggregate_func: Callable[[da.Array], pd.DataFrame], index: NDArray | None = None
    ) -> pd.DataFrame:
        if index is None:
            index = _da_unique(self._mask, run_on_gpu=self._run_on_gpu)
        results = aggregate_func(index=index)
        assert len(results) == 1
        df = pd.DataFrame(_to_numpy(results[0]))
        df[self._instance_key] = _to_numpy(index)
        return df

    # this calculates "sum", "count", "mean", "var", "kurtosis" and "skew"
    def _aggregate_stats(
        self,
        stats_funcs: tuple[str, ...] = ("sum", "mean", "count", "var", "kurtosis", "skew"),
        index: NDArray | None = None,
    ) -> list[NDArray]:
        # add an assert that checks that stats_funcs is in the list that is given.
        # first calculate the sum.
        _, is_cupy_mask = _get_xp(getattr(self._mask, "_meta", None), run_on_gpu=self._run_on_gpu)
        xp, is_cupy_image = _get_xp(getattr(self._image, "_meta", None), run_on_gpu=self._run_on_gpu)
        if is_cupy_mask != is_cupy_image:
            raise ValueError("Mask and image should be on the same backend.")
        if index is None:
            index = _da_unique(self._mask, run_on_gpu=self._run_on_gpu)
        # put on currect backend
        index = xp.asarray(index)
        if isinstance(stats_funcs, str):
            stats_funcs = (stats_funcs,)

        allowed_funcs = {"sum", "mean", "count", "var", "kurtosis", "skew"}
        invalid_funcs = [func for func in stats_funcs if func not in allowed_funcs]
        assert not invalid_funcs, (
            f"Invalid statistic function(s): '{invalid_funcs}'. Allowed functions: '{allowed_funcs}'."
        )
        if (
            "sum" in stats_funcs
            or "mean" in stats_funcs
            or "var" in stats_funcs
            or "kurtosis" in stats_funcs
            or "skew" in stats_funcs
        ):
            # calculate the sum
            def _calculate_sum_per_chunk(*arrays: NDArray) -> NDArray:
                assert len(arrays) == 2
                mask_block = arrays[0][0]  # make it z,y,x
                image_block = arrays[1]
                _, is_cupy_index = _get_xp(index, run_on_gpu=self._run_on_gpu)
                _, is_cupy_mask = _get_xp(mask_block, run_on_gpu=self._run_on_gpu)
                xp, is_cupy_image = _get_xp(image_block, run_on_gpu=self._run_on_gpu)
                if len({is_cupy_mask, is_cupy_image, is_cupy_index}) != 1:
                    raise ValueError("Mask and image should be on the same backend.")
                unique_labels, new_labels = xp.unique(mask_block, return_inverse=True)
                new_labels = xp.reshape(new_labels, (-1,))  # flatten, since it may be >1-D
                idxs = xp.searchsorted(unique_labels, index)
                # make all of idxs valid
                idxs = xp.where(idxs >= unique_labels.size, 0, idxs)
                found = unique_labels[idxs] == index

                n_unique = unique_labels.size

                # NOTE: doing it without a for loop, e.g. with one bincount, # FIXME: check if on GPU one big bincount is not faster
                # takes a lot of RAM when there are many channels (>100)
                # C = image.shape[0]
                # encoded_labels = new_labels[None, :] + n_unique * np.arange(C)[:, None]  # shape (c,i)
                # sums = np.bincount(
                #    encoded_labels.ravel(),
                #    weights=image_block.reshape(C, -1).ravel(),
                #    minlength=C
                #    * n_unique,
                # ).reshape(C, n_unique)

                sums = []
                for _c_image_block in image_block:
                    sums.append(
                        xp.bincount(new_labels.ravel(), _c_image_block.ravel(), minlength=n_unique),
                    )
                sums = xp.stack(sums)
                sums = sums[:, idxs]
                sums = xp.where(found[None, :], sums, 0)
                # sums is of shape (c,i), with i = len(index)
                # we make it i,c,z,y,x
                sums = sums.T
                return sums[..., None, None, None].astype(xp.float32)

            # add dummy C dimension for the mask, so we can pass it to map_blocks
            arrays = [self._mask[None, ...], self._image]

            meta = xp.empty((0, 0, 0, 0, 0), dtype=xp.float32)
            chunk_sum = da.map_blocks(
                _calculate_sum_per_chunk,
                *arrays,
                dtype=np.float32,  # for background pixels, theoretically this could overflow for float32
                chunks=(
                    (len(index),),
                    self._image.chunks[0],
                    (1,) * self._image.numblocks[1],
                    (1,) * self._image.numblocks[2],
                    (1,) * self._image.numblocks[3],
                ),
                new_axis=0,  # add the i dimension
                meta=meta,
            )

            # chunk_sum is an array of shape (i, c, num_blocks_z,  num_blocks_y, num_blocks_x), with i=nr of unique labels
            sum = chunk_sum.reshape(len(index), self._image.shape[0], -1).sum(axis=-1).compute()

        # then calculate the mean
        # i) first calculate the area
        if (
            "mean" in stats_funcs
            or "count" in stats_funcs
            or "var" in stats_funcs
            or "kurtosis" in stats_funcs
            or "skew" in stats_funcs
        ):
            if getattr(self, "_count_index", None) is not None:
                self._count_index = xp.asarray(self._count_index)
            if (
                self._count is None
                or getattr(self, "_count_index", None) is None
                or not xp.array_equal(self._count_index, index)
            ):
                if self._count is not None:
                    log.warning("Count was computed for a different index. Recalculating.")
                self._count = _calculate_area(self._mask, index=index, run_on_gpu=self._run_on_gpu)
                self._count_index = index.copy()
            self._count = xp.asarray(self._count)

        # ii) then calculate the mean
        if "mean" in stats_funcs or "var" in stats_funcs or "kurtosis" in stats_funcs or "skew" in stats_funcs:
            if getattr(self, "_mean_index", None) is not None:
                self._mean_index = xp.asarray(self._mean_index)
            if (
                self._mean is None
                or getattr(self, "_mean_index", None) is None
                or not xp.array_equal(self._mean_index, index)
            ):
                if self._mean is not None:
                    log.warning("Mean was computed for a different index. Recalculating.")
                self._mean = sum / self._count
                self._mean_index = index.copy()
            self._mean = xp.asarray(self._mean)

        def sum_of_n(n: int) -> NDArray:
            # calculate the sum of n (e.g. squares if n=2) per cell
            def _calculate_sum_c_per_chunk(mask_block: NDArray, image_block: NDArray, block_info=None) -> NDArray:
                mask_block = mask_block[0]  # make it z,y,x again
                _, is_cupy_index = _get_xp(index, run_on_gpu=self._run_on_gpu)
                _, is_cupy_mask = _get_xp(mask_block, run_on_gpu=self._run_on_gpu)
                xp, is_cupy_image = _get_xp(image_block, run_on_gpu=self._run_on_gpu)
                if len({is_cupy_mask, is_cupy_image, is_cupy_index}) != 1:
                    raise ValueError("Mask, image and index should be on the same backend.")
                unique_labels, new_labels = xp.unique(mask_block, return_inverse=True)
                new_labels = xp.reshape(new_labels, (-1,))  # flatten, since it may be >1-D
                idxs = xp.searchsorted(unique_labels, index)
                # make all of idxs valid
                idxs = xp.where(idxs >= unique_labels.size, 0, idxs)
                found = unique_labels[idxs] == index

                # i) self._mean contains the mean over all channels (global), i.e. it is of shape (I,C),
                #  we only need the channels that are in the current block
                # ii) self._mean is the mean for all i, but we only select the ones that are in current block
                img_info = block_info[1]
                c_start, c_stop = img_info["array-location"][0]
                mean_found = self._mean[found, c_start:c_stop]

                n_unique = unique_labels.size
                C = image_block.shape[0]

                # NOTE: doing it without a for loop, e.g. with one bincount,
                # takes a lot of RAM when there are many channels (>100)
                # encoded_labels = new_labels[None, :] + n_unique * np.arange(C)[:, None]  # shape (c,i)
                # sums_c = np.bincount(
                #    encoded_labels.ravel(),
                #    weights=weights.ravel(),
                #    minlength=C
                #    * n_unique,  # NOTE: specifying minlength not really necessary here, keep it for documentation
                # ).reshape(C, n_unique)

                mean_per_pixel = mean_found.T[
                    :, new_labels
                ]  # creates an array of shape (c,image_block.shape[1]*image_block.shape[2]*image_block.shape[3])
                centered_weights = (image_block.reshape(C, -1) - mean_per_pixel) ** n
                sums_c = []
                for _c_weights in centered_weights:
                    sums_c.append(
                        xp.bincount(new_labels.ravel(), _c_weights.ravel(), minlength=n_unique),
                    )
                sums_c = xp.stack(sums_c)
                sums_c = sums_c[:, idxs]
                sums_c = xp.where(found[None, :], sums_c, 0)
                # sums_c[:, ~found] = 0
                # sums_c is of shape (c,i), with i = len(index)
                # we make it i,c,z,y,x
                sums_c = sums_c.T
                return sums_c[..., None, None, None].astype(xp.float32)

            arrays = [self._mask[None, ...], self._image]

            meta = xp.empty((0, 0, 0, 0, 0), dtype=xp.float32)
            chunk_sum_c = da.map_blocks(
                _calculate_sum_c_per_chunk,
                *arrays,
                dtype=np.float32,
                chunks=(
                    (len(index),),  # i: labels
                    self._image.chunks[0],  # c: channels
                    (1,) * self._image.numblocks[1],  # z-block index
                    (1,) * self._image.numblocks[2],  # y-block index
                    (1,) * self._image.numblocks[3],  # x-block index
                ),
                new_axis=0,  # add the i dimension
                meta=meta,
            )
            # chunk_sum_c is an array of shape (i, c, num_blocks_z,  num_blocks_y, num_blocks_x),
            # with i=nr of unique labels, and num_blocks the number of blocks in z,y,x of the image and the mask.
            sum_c_n = (
                chunk_sum_c.reshape(len(index), self._image.shape[0], -1)
                .sum(axis=-1)  # sum over all chunks
                .compute()
            )

            return sum_c_n

        if "var" in stats_funcs or "kurtosis" in stats_funcs or "skew" in stats_funcs:
            sum_square = sum_of_n(n=2)
        if "kurtosis" in stats_funcs:
            sum_fourth = sum_of_n(n=4)
        if "skew" in stats_funcs:
            sum_third = sum_of_n(n=3)

        to_return = {}
        if "sum" in stats_funcs:
            to_return["sum"] = sum
        if "mean" in stats_funcs:
            to_return["mean"] = self._mean
        if "count" in stats_funcs:
            to_return["count"] = self._count
        if "var" in stats_funcs:
            to_return["var"] = sum_square / self._count
        if "kurtosis" in stats_funcs:
            # fisher kurtosis
            kurtosis = ((sum_fourth / self._count) / ((sum_square / self._count) ** 2)) - 3
            if xp.isnan(kurtosis).any():
                log.warning("Replacing NaN values in 'kurtosis' with 0 for affected instances.")
                kurtosis = xp.nan_to_num(kurtosis, nan=0)
            to_return["kurtosis"] = kurtosis
        if "skew" in stats_funcs:
            skewness = (sum_third / self._count) / (xp.sqrt(sum_square / self._count)) ** 3
            if xp.isnan(skewness).any():
                log.warning("Replacing NaN values in 'skewness' with 0 for affected instances.")
                skewness = xp.nan_to_num(skewness, nan=0)

            to_return["skew"] = skewness

        to_return = [to_return[func] for func in stats_funcs if func in to_return]

        return to_return

    def _aggregate_max(
        self,
        index: NDArray | None = None,
    ):
        return self._min_max(min_or_max="max", index=index)

    def _aggregate_min(
        self,
        index: NDArray | None = None,
    ):
        return self._min_max(min_or_max="min", index=index)

    def _min_max(
        self,
        min_or_max: Literal["max", "min"],
        index: NDArray | None = None,
    ) -> list[NDArray]:
        _, is_cupy_mask = _get_xp(getattr(self._mask, "_meta", None), run_on_gpu=self._run_on_gpu)
        xp, is_cupy_image = _get_xp(getattr(self._image, "_meta", None), run_on_gpu=self._run_on_gpu)
        if is_cupy_mask != is_cupy_image:
            raise ValueError("Mask and image should be on the same backend.")
        if index is None:
            index = _da_unique(self._mask, run_on_gpu=self._run_on_gpu)
        # put on currect backend
        index = xp.asarray(index)
        assert min_or_max in ["max", "min"], "Please choose from [ 'min', 'max' ]."

        def _calculate_min_max_per_chunk(*arrays: NDArray):
            """Returns (mins, maxs) with shape (C, n_labels+1). Row = channel, col = label id."""
            assert len(arrays) == 2
            mask_block = arrays[0][0]  # make it z,y,x
            image_block = arrays[1]
            C = image_block.shape[0]
            assert mask_block.shape == image_block.shape[1:]

            # relabel to 0....K-1
            unique_labels, new_labels = xp.unique(mask_block, return_inverse=True)
            new_labels = xp.reshape(new_labels, (-1,))  # flatten, since it may be >1-D
            idxs = xp.searchsorted(unique_labels, index)
            # make all of idxs valid
            idxs = xp.where(idxs >= unique_labels.size, 0, idxs)
            found = unique_labels[idxs] == index
            image_block = image_block.reshape(C, -1)
            K = unique_labels.size

            if xp.issubdtype(image_block.dtype, xp.integer):
                info = xp.iinfo(image_block.dtype)
                init_min = info.max
                init_max = info.min
            else:
                init_min = xp.inf
                init_max = -xp.inf

            if min_or_max == "min":
                out = xp.full((C, K), init_min, dtype=image_block.dtype)
            else:
                out = xp.full((C, K), init_max, dtype=image_block.dtype)

            N = new_labels.size
            ch = xp.repeat(xp.arange(C), N)  # (c*N,)
            lab = xp.tile(new_labels, C)  # (c*N,)
            vals = image_block.reshape(-1)  # (c*N,)

            if min_or_max == "min":
                xp.minimum.at(out, (ch, lab), vals)
            else:
                xp.maximum.at(out, (ch, lab), vals)

            out = out.transpose(1, 0)  # make it (N,c)
            out = out[idxs]  # make it (i,c)
            # fill
            out = xp.where(found[:, None], out, init_min if min_or_max == "min" else init_max)
            return out[..., None, None, None]  # make it i,c,z,y,x

        """ alternative implementation, slower, especially on GPU
        def _calculate_min_max_per_chunk(*arrays: NDArray) -> NDArray:
            assert len(arrays) == 2
            mask_block = arrays[0][0]  # make it z,y,x
            image_block = arrays[1]
            _, is_cupy_index = _get_xp(index, run_on_gpu=self._run_on_gpu)
            _, is_cupy_mask = _get_xp(mask_block, run_on_gpu=self._run_on_gpu)
            xp, is_cupy_image = _get_xp(image_block, run_on_gpu=self._run_on_gpu)
            if len({is_cupy_mask, is_cupy_image, is_cupy_index}) != 1:
                raise ValueError("Mask and image should be on the same backend.")

            min_or_max_array = []
            for _c_image_block in image_block:
                min_or_max_c = labeled_comprehension(
                    _c_image_block,
                    mask_block,
                    index,
                    func=xp.max if min_or_max == "max" else xp.min,
                    out_dtype=image_block.dtype,
                    default=min_dtype
                    if min_or_max == "max"
                    else max_dtype,  # set the default for labels in index not found in current mask_block
                )  # also works if we have a lot of labels. scipy makes sure it only searches for labels of index that are in mask_block
                min_or_max_array.append(min_or_max_c)
            min_or_max_array = xp.stack(min_or_max_array)
            # max is (c,i)
            # make it (i,c,z,y,x)
            min_or_max_array = min_or_max_array.T
            return min_or_max_array[..., None, None, None]
        """

        arrays = [self._mask[None, ...], self._image]
        meta = xp.empty((0, 0, 0, 0, 0), dtype=self._image.dtype)

        chunk_min_max = da.map_blocks(
            _calculate_min_max_per_chunk,
            *arrays,
            dtype=self._image.dtype,
            chunks=(
                (len(index),),
                self._image.chunks[0],
                (1,) * self._image.numblocks[1],
                (1,) * self._image.numblocks[2],
                (1,) * self._image.numblocks[3],
            ),
            new_axis=0,  # add the i dimension
            meta=meta,
        )

        # chunk_min_max is an array of shape (i, c, num_blocks_z,  num_blocks_y, num_blocks_x),
        # with i=nr of unique labels, and num_blocks the number of blocks in z,y,x of the image and the mask.
        chunk_min_max = chunk_min_max.reshape(len(index), self._image.shape[0], -1)

        dask_min_max_func = da.max if min_or_max == "max" else da.min

        # return a list, so it is in line with self._aggregate_stats()
        return [dask_min_max_func(chunk_min_max, axis=-1).compute()]

    def _center_of_mass(
        self,
        index: NDArray | None = None,
    ) -> NDArray:
        xp, _ = _get_xp(getattr(self._mask, "_meta", None), run_on_gpu=self._run_on_gpu)

        if index is None:
            index = _da_unique(self._mask, run_on_gpu=self._run_on_gpu)
        # put on correct backend
        index = xp.asarray(index)
        if getattr(self, "_count_index", None) is not None:
            self._count_index = xp.asarray(self._count_index)
        if (
            self._count is None
            or getattr(self, "_count_index", None) is None
            or not xp.array_equal(self._count_index, index)
        ):
            if self._count is not None:
                log.warning("Count was computed for a different index. Recalculating.")
            self._count = _calculate_area(self._mask, index=index, run_on_gpu=self._run_on_gpu)
            self._count_index = index.copy()
        self._count = xp.asarray(self._count)

        def _calculate_mass_moment_vector_chunk(mask_block: NDArray, block_info) -> NDArray:
            _, is_cupy_index = _get_xp(index, run_on_gpu=self._run_on_gpu)
            xp, is_cupy_mask = _get_xp(mask_block, run_on_gpu=self._run_on_gpu)
            if len({is_cupy_mask, is_cupy_index}) != 1:
                raise ValueError("Mask and index should be on the same backend.")
            # fix labels, so we do not need to calculate for all
            unique_labels, new_labels = xp.unique(mask_block, return_inverse=True)
            new_labels = xp.reshape(new_labels, (-1,))
            idxs = xp.searchsorted(unique_labels, index)
            # make all of idxs valid
            idxs = xp.where(idxs >= unique_labels.size, 0, idxs)
            found = unique_labels[idxs] == index
            info = block_info[0]
            # global start indices of this block in the full array
            start_position = tuple(s.start if hasattr(s, "start") else s[0] for s in info["array-location"])
            start_z, start_y, start_x = map(int, start_position)
            # get the coordinates
            nz, ny, nx = mask_block.shape
            N = nz * ny * nx
            lin = xp.arange(N, dtype=xp.int64)
            stride_yx = ny * nx
            z = lin // stride_yx
            rem = lin - z * stride_yx
            y = rem // nx
            x = rem - y * nx
            # shift to global coords
            z = z + start_z
            y = y + start_y
            x = x + start_x

            # now get the mass moment vector
            wdtype = xp.float64
            sum_z = xp.bincount(new_labels.ravel(), weights=z.astype(wdtype), minlength=unique_labels.size)
            sum_y = xp.bincount(new_labels.ravel(), weights=y.astype(wdtype), minlength=unique_labels.size)
            sum_x = xp.bincount(new_labels.ravel(), weights=x.astype(wdtype), minlength=unique_labels.size)

            result = xp.stack([sum_z, sum_y, sum_x], axis=1)
            result = result[idxs]
            result = xp.where(found[:, None], result, 0)

            return result[..., None, None, None]  # potential overflow problem, so we do not cast to float64

        mask = self._mask
        meta = xp.empty((0, 0, 0, 0, 0), dtype=xp.float64)
        mass_moment_vector = da.map_blocks(
            _calculate_mass_moment_vector_chunk,
            mask,
            dtype=np.float64,
            chunks=(
                (len(index)),
                (3),
                (1,) * mask.numblocks[0],
                (1,) * mask.numblocks[1],
                (1,) * mask.numblocks[2],
            ),
            new_axis=[0, 1],  # i,3 are new axis containing (sum(mi*zi), sum(mi*yi), sum(mi*xi)) for each chunk
            meta=meta,
        )
        center_of_mass = mass_moment_vector.reshape(len(index), 3, -1).sum(axis=-1) / self._count

        return center_of_mass.compute()

    '''
    def _aggregate_quantiles_channel(
        self,
        image: da.Array,
        mask: da.Array,
        depth: int,
        quantiles: list[float] | None,
        quantile_background: bool = False,
    ) -> NDArray:
        if quantiles is None:
            quantiles = np.linspace(0.1, 0.9, 9)

        fn_kwargs = {
            "quantiles": quantiles,
        }

        results = self.aggregate_custom_channel(
            image=image,
            mask=mask,
            depth=depth,
            features=len(quantiles),
            dtype=np.float32,
            fn=_quantile_intensity_distribution,
            fn_kwargs=fn_kwargs,
        )

        def _quantile_background(
            image: da.Array,
            mask: da.Array,
            q: float = None,
            internal_method: str = "tdigest",
            background_label: int = 0,
        ) -> float:
            # calculate the quantile of the background
            q = q * 100
            image = image.flatten()
            mask = mask.flatten()
            background_non_nan_mask = (mask == background_label) & (~da.isnan(image))

            array = da.compress(background_non_nan_mask, image)

            return da.percentile(array, q=q, internal_method=internal_method).astype(np.float32)[0].compute()

        if quantile_background and quantiles is not None:
            results_background = np.array([_quantile_background(image, mask, q=_quantile) for _quantile in quantiles])
            results = np.vstack((np.array(results_background), results))

        return results

    def aggregate_custom_channel(
        self,
        image: da.Array | None,
        mask: da.Array,
        depth: int,  # choose depth > estimated diameter of largest cell
        fn: Callable[[NDArray[np.int_], NDArray[np.int_ | np.float_] | None], NDArray[np.float_]],
        fn_kwargs: Mapping[str, Any] = MappingProxyType(
            {}
        ),  # fn is a callable that returns a 1D array with len == nr of unique labels in the mask passed to fn excluding 0
        dtype: np.dtype = np.float32,  # output dtype
        features: int = 1,
    ) -> NDArray:
        """
        Aggregates a custom operation over a masked region of an image, with the option to pass additional parameters to a custom function.

        Deprecated. Please use :func:`harpy.utils.Featurizer.calculate_instance_statistics` instead.

        Parameters
        ----------
        image
            The input image array. If None, the function will only process the `mask`. The array is expected
            to be a dask array. If not None, the function will apply the operation to the image
            based on the mask regions.
        mask
            A dask array representing the mask. Each unique non-zero value in the mask identifies
            a separate region of interest (ROI), typically a cell. The mask array must have integer values corresponding to
            different cells in the image.
        depth
            depth is passed as `depth` to `dask.array.map_overlap`, where `depth` must be greater than the estimated
            diameter of the largest region of interest in the `mask`. This value ensures the appropriate
            neighborhood is considered when applying the function `fn`.
        fn
            A custom function that processes a mask and, optionally, an image array.
            The function must accept either one or two NumPy arrays:

            - The first argument is the mask, provided as an integer array.
            - The second argument (optional) is the image, given as a float or integer array.

            The function must return a 2D NumPy array of type `np.float`, where:

            - The first dimension corresponds to the number of unique labels in the mask (excluding label `0`), sorted by label number.
            - The second dimension represents the number of features computed by `fn`.

            The output of `fn` must **not** contain `NaN` values.
            User warning: the number of unique labels in the mask passed to `fn` is not equal to the number of
            unique labels from the global `mask` due to the use of `dask.array.map_overlap`.
        fn_kwargs
            Additional keyword arguments to be passed to the function `fn`. The default is an empty `MappingProxyType`.
        dtype
            The data type of the output array. By default, this is `np.float32`. It can be changed to any valid
            NumPy data type if necessary.
        features
            The number of features `fn` calculates.

        Returns
        -------
        A 2D NumPy array containing the aggregated results of the custom operation `fn`, applied to the regions defined by the `mask`.
        The array has the same number of elements as the unique labels in the `mask` excluding `0`, and the results are ordered based on the ordered labels.
        The shape of the 2D Numpy array is thus (`len( self._labels[[self._labels!=0]]), features)`, with `self._labels = dask.array.unique( mask ).compute()`.
        """
        log.warning(
            "RasterAggregator.aggregate_custom_channel() is deprecated and will be removed in a future release. "
            "Please use harpy.utils.Featurizer.calculate_instance_statistics instead."
        )
        assert mask.numblocks[0] == 1, "mask can not be chunked in z-dimension. Please rechunk."
        depth = (0, depth, depth)
        _labels = self._labels[self._labels != 0]
        if image is not None:
            assert image.numblocks[0] == 1, "image can not be chunked in z-dimension. Please rechunk."
            if mask.ndim != 3 or image.ndim != 3 or mask.ndim != image.ndim:
                raise ValueError(
                    f"mask and image must both be 3D (z, y, x). Got mask.shape={mask.shape}, image.shape={image.shape}"
                )
            arrays = [mask, image]
        else:
            arrays = [mask]
            if mask.ndim != 3:
                raise ValueError(f"mask must be 3D (z, y, x), but got {mask.ndim}D with shape {mask.shape}")
        dask_chunks = da.map_overlap(
            lambda *arrays, block_info=None, **kw: _aggregate_custom_block(*arrays, block_info=block_info, **kw),
            *arrays,
            dtype=dtype,
            chunks=(len(_labels), features),
            trim=False,
            drop_axis=0,
            boundary=0,
            depth=depth,
            index=_labels,
            _depth=depth,
            fn=fn,  # callable.
            fn_kwargs=fn_kwargs,  # keywords of the callable
            features=features,
        )
        dask_chunks = [
            da.from_delayed(_chunk, shape=(len(_labels), features), dtype=dtype).reshape(-1, 1)
            for _chunk in dask_chunks.to_delayed().flatten()
        ]  # put all features under each other

        dask_array = da.concatenate(dask_chunks, axis=1)
        # this gives you dask array of shape (features*len(_labels), nr_of_chunks in mask ) with chunksize (features*len(_labels), 1)

        sanity = da.all((~da.isnan(dask_array)).sum(axis=1) == 1)
        # da.nansum ignores np.nan added by _featurize_custom_block
        results = da.nansum(dask_array, axis=1, dtype=dtype).reshape(-1, features)

        sanity, results = dask.compute(*[sanity, results])

        assert sanity, (
            "We expect exactly one non-NaN element per row (each column corresponding to a chunk of 'mask'). Please consider increasing 'depth' parameter."
        )

        return results
    '''


def _get_mask_area(
    mask: da.Array,
    index: NDArray | None = None,
    instance_key: str = _INSTANCE_KEY,
    instance_size_key: str = _CELLSIZE_KEY,
    run_on_gpu: bool = True,
) -> pd.DataFrame:
    assert mask.ndim == 3, "Currently only 3D masks are supported ('z','y','x')."
    if index is None:
        index = _da_unique(mask, run_on_gpu=run_on_gpu)
    _result = _calculate_area(mask, index=index, run_on_gpu=run_on_gpu)
    return pd.DataFrame({instance_key: _to_numpy(index), instance_size_key: _to_numpy(_result.ravel())})


def _calculate_area(mask: da.Array, index: NDArray | None = None, run_on_gpu: bool = True) -> NDArray:
    assert mask.ndim == 3, "Currently only 3D masks are supported ('z','y','x')."
    xp, _ = _get_xp(getattr(mask, "_meta", None), run_on_gpu=run_on_gpu)

    if index is None:
        index = _da_unique(mask, run_on_gpu=run_on_gpu)

    # put on correct backend
    index = xp.asarray(index)

    def _calculate_count_per_chunk(mask_block: NDArray) -> NDArray:
        # for safety
        _, is_cupy_index = _get_xp(index, run_on_gpu=run_on_gpu)
        xp, is_cupy_mask = _get_xp(mask_block, run_on_gpu=run_on_gpu)
        if len({is_cupy_mask, is_cupy_index}) != 1:
            raise ValueError("Mask and index should be on the same backend.")
        # fix labels, so we do not need to calculate for all
        unique_labels, new_labels = xp.unique(mask_block, return_inverse=True)
        new_labels = xp.reshape(new_labels, (-1,))  # flatten, since it may be >1-D
        idxs = xp.searchsorted(unique_labels, index)
        # make all of idxs valid
        idxs = xp.where(idxs >= unique_labels.size, 0, idxs)
        found = unique_labels[idxs] == index
        # calculate counts
        counts = xp.bincount(
            new_labels, minlength=unique_labels.size
        )  # NOTE: specifying minlength not really necessary here, we keep it for documentation
        counts = counts[idxs]
        counts = xp.where(found, counts, 0)
        # counts is an array of shape len(self._lables)
        # we make it i,z,y,x
        return counts[
            :, None, None, None
        ].astype(
            xp.float32
        )  # TODO, potential overflow problem, should we remove background, or just cast to np.float64 (which it is already)

    meta = xp.empty((0, 0, 0, 0, 0), dtype=xp.float32)
    chunk_count = da.map_blocks(
        _calculate_count_per_chunk,
        mask,
        dtype=np.float32,
        chunks=(
            (len(index)),
            (1,) * mask.numblocks[0],
            (1,) * mask.numblocks[1],
            (1,) * mask.numblocks[2],
        ),
        new_axis=0,  # i, new axis contains the sum for each label (in the chunk)
        meta=meta,
    )
    sum = chunk_count.reshape(len(index), -1).sum(axis=-1).compute()
    return sum.reshape(-1, 1)


def _get_center_of_mass(
    mask: da.Array, index: NDArray | None = None, instance_key: str = _INSTANCE_KEY
) -> pd.DataFrame:
    assert mask.ndim == 3, "Currently only 3D masks are supported."
    if index is None:
        index = da.unique(mask).compute()

    # dask image center of mass for masks seems bugged (very slow), use in memory scipy.ndimage.center_of_mass.
    in_memory = True
    if not in_memory:
        coordinates = ndmeasure.center_of_mass(
            image=mask,
            label_image=mask,
            index=index,
        )
        coordinates = coordinates.compute()

    else:
        mask_in_memory = mask.compute()
        coordinates = np.array(
            ndimage.center_of_mass(
                input=mask_in_memory,
                labels=mask_in_memory,
                index=index,
            )
        )

    return pd.DataFrame(
        {
            instance_key: index,
            0: coordinates[:, 0],
            1: coordinates[:, 1],
            2: coordinates[:, 2],
        }
    )


def _get_min_max_dtype(array):
    dtype = array.dtype
    if np.issubdtype(dtype, np.integer):
        return np.iinfo(dtype).min, np.iinfo(dtype).max
    elif np.issubdtype(dtype, np.floating):
        return np.finfo(dtype).min, np.finfo(dtype).max
    else:
        raise TypeError("Unsupported dtype")


'''
def _quantile_intensity_distribution(
    mask: NDArray, image: NDArray, quantiles: list[float] | NDArray | None = None
) -> NDArray:
    """
    Calculate the quantile intensity distribution for each object in the mask.

    Parameters
    ----------
    image
        intensity values.
    mask
       should have same shape as image, with integer cell IDs (0 for background).
    quantiles
        list of quantiles to compute (e.g., [0.1, 0.2, ..., 0.9]).

    Returns
    -------
        The computed quantiles as a numpy array of shape `(nr of non zero labels, len(quantiles))`.
    """
    if quantiles is None:
        quantiles = np.linspace(0.1, 0.9, 9)

    unique_labels = np.unique(mask)
    unique_labels = unique_labels[unique_labels != 0]

    if len(unique_labels) == 0:
        # No objects in the mask, return an empty array with shape (0, len(quantiles))
        return np.empty((0, len(quantiles)))

    result = np.full((len(unique_labels), len(quantiles)), np.nan, dtype=np.float32)

    for i, label in enumerate(unique_labels):
        object_intensities = image[mask == label]
        if object_intensities.size > 0:
            result[i] = np.quantile(object_intensities, quantiles)

    return result
'''

"""'
def _all_region_radii_and_axes(mask: NDArray, calculate_axes: bool = True) -> NDArray:
    unique_labels = np.unique(mask)
    unique_labels = unique_labels[unique_labels != 0]

    nr_of_features = mask.ndim + mask.ndim**2 if calculate_axes else mask.ndim

    if len(unique_labels) == 0:
        return np.empty((0, nr_of_features))

    result = np.full((len(unique_labels), nr_of_features), np.nan, dtype=np.float32)

    for i, label in enumerate(unique_labels):
        radii, axes = _region_radii_and_axes(mask=mask, label=label)
        assert radii.shape == (mask.ndim,), f"Unexpected radii shape: {radii.shape}"
        assert axes.shape == (mask.ndim, mask.ndim), f"Unexpected axes shape: {axes.shape}"
        result[i] = np.concatenate((radii, axes.flatten())) if calculate_axes else radii
    return result
"""

"""
def _aggregate_custom_block(
    *arrays,
    index: NDArray,
    block_info,
    _depth,
    fn: Callable,
    fn_kwargs: Mapping[str, Any] = MappingProxyType({}),
    features: int = 1,
) -> NDArray:
    mask_block = arrays[0]
    if len(arrays) == 2:
        image_block = arrays[1]
        assert mask_block.shape == image_block.shape
    if len(arrays) > 2:
        raise ValueError("Only accepts one or two arrays.")
    assert 0 not in index
    total_nr_of_blocks = block_info[0]["num-chunks"]
    block_location = block_info[0]["chunk-location"]
    # check if chunk is on border of larger dask array
    y_upper_border = block_location[1] + 1 == total_nr_of_blocks[1]
    x_upper_border = block_location[2] + 1 == total_nr_of_blocks[2]
    y_lower_border = block_location[1] == 0
    x_lower_border = block_location[2] == 0

    border_labels = set()
    if not y_upper_border:
        # you do not only extract the ones on border, but in the overlap region that is in the current block,
        # e.g. you go from _depth[1] : _depth[1] * 2
        # otherwise you could miss masks that are crossing the border, but are non-continuous and do not overlap with the border.
        # we still assume diameter < depth
        border_labels.update(set(np.unique(mask_block[:, -(_depth[1] * 2) : -(_depth[1]), _depth[2] : -_depth[2]])))
    if not x_upper_border:
        border_labels.update(set(np.unique(mask_block[:, _depth[1] : -_depth[1], -(_depth[2] * 2) : -(_depth[2])])))
    if not y_lower_border:
        border_labels.update(set(np.unique(mask_block[:, _depth[1] : _depth[1] * 2, _depth[2] : -_depth[2]])))
    if not x_lower_border:
        border_labels.update(set(np.unique(mask_block[:, _depth[1] : -_depth[1], _depth[2] : _depth[2] * 2])))
    if 0 in border_labels:
        border_labels.remove(0)

    border_labels = list(border_labels)
    center_of_mass_border_labels = ndimage.center_of_mass(input=mask_block, labels=mask_block, index=border_labels)

    def _isin_original(center: tuple[float, float, float]):
        return (
            center[1] >= _depth[1]
            and center[1] < (mask_block.shape[1] - _depth[1])
            and center[2] >= _depth[2]
            and center[2] < (mask_block.shape[2] - _depth[2])
        )

    border_labels_in_original_block = []
    for _center in center_of_mass_border_labels:
        if _isin_original(_center):
            border_labels_in_original_block.append(True)
        else:
            border_labels_in_original_block.append(False)

    # get the border labels not to consider
    if border_labels:
        border_labels_not_to_consider = np.array(border_labels)[~np.array(border_labels_in_original_block)]

    # Set all masks that are fully outside the region to zero, they will be covered by other chunks
    subset = mask_block[:, _depth[1] : -_depth[1], _depth[2] : -_depth[2]]
    # Unique masks gives you all masks that are at least partially in 'original' array (i.e. without depth added)
    unique_masks = np.unique(subset)
    # remove masks that are on border, but are covered by other chunks, because center of mass is in other chunk
    if border_labels:
        unique_masks = unique_masks[~np.isin(unique_masks, border_labels_not_to_consider)]

    # Create a mask for labels that are NOT in unique_masks
    mask = ~np.isin(mask_block, unique_masks)
    mask_block[mask] = 0

    unique_masks = unique_masks[unique_masks != 0]
    index = index[index != 0]

    # if no labels in the block, there is nothing to calculate,
    # so return 1D array containing nan at each position.
    if len(unique_masks) == 0:
        return np.full((index.shape[0], features), np.nan)

    idxs = np.searchsorted(unique_masks, index)
    idxs[idxs >= unique_masks.size] = 0
    found = unique_masks[idxs] == index

    result = fn(*arrays, **fn_kwargs)  # fn can either take in a mask + image, or only a mask
    result = result.reshape(-1, features)
    assert result.shape[0] == unique_masks.shape[0], (
        "Callable 'fn' should return an array with length equal to the number of non zero labels in the provided mask."
    )
    assert np.issubdtype(result.dtype, np.floating), "Callable 'fn' should return an array of dtype 'float'."
    if any(np.isnan(result).ravel()):
        raise AssertionError("Result of callable 'fn' is not allowed to contain NaN.")
    result = result[idxs]
    result[~found] = np.nan
    return result
"""
