import asyncio
import json

import pytest

from mrp.auth import Keypair
from mrp.websocket import WSClient


class TestWSUrl:
    def test_http_to_ws(self):
        ws = WSClient("http://localhost:8080", Keypair.generate())
        assert ws._ws_url() == "ws://localhost:8080/v1/ws"

    def test_https_to_wss(self):
        ws = WSClient("https://relay.example.com", Keypair.generate())
        assert ws._ws_url() == "wss://relay.example.com/v1/ws"

    def test_trailing_slash_stripped(self):
        ws = WSClient("http://localhost:8080/", Keypair.generate())
        assert ws._ws_url() == "ws://localhost:8080/v1/ws"
