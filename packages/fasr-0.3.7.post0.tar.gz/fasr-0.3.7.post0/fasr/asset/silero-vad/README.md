# SileroVAD 语音活动检测模型

SileroVAD是一个轻量级但高效的语音活动检测（VAD）模型，基于PyTorch实现。它支持多种语言，具有低延迟和高准确率的特点。

## 🚀 模型特点

- **轻量级**: 模型文件小，内存占用低
- **多语言**: 支持11种语言（英语、德语、西班牙语、法语、意大利语、波兰语、葡萄牙语、俄语、土耳其语、乌克兰语、中文）
- **高准确率**: 在多种噪声环境下表现优异
- **低延迟**: 实时处理能力，延迟<50ms
- **易部署**: 支持CPU和GPU，无需额外依赖

## 📁 文件结构

```
silero-vad/
├── config.yaml         # 模型配置文件
├── configuration.json  # 模型元信息
└── README.md          # 说明文档
```

## 🔧 安装依赖

```bash
# 安装SileroVAD
pip install silero-vad

# 安装PyTorch（如果还没有安装）
pip install torch torchaudio

# 安装项目依赖
pip install -r requirements.txt
```

## 📖 使用方法

### 基本使用

```python
from fasr.models.vad.silero_vad import SileroForVAD
from fasr.data import Waveform

# 创建模型实例
vad_model = SileroForVAD()

# 加载模型
vad_model.from_checkpoint(
    checkpoint_dir="fasr/asset/silero-vad",
    device_id="cpu"  # 或指定GPU: device_id=0
)

# 检测语音活动
segments = vad_model.detect(waveform)
```

### 高级配置

```python
# 自定义参数
vad_model.from_checkpoint(
    checkpoint_dir="fasr/asset/silero-vad",
    device_id="cuda:0",
    threshold=0.6,                    # VAD阈值
    min_speech_duration_ms=300,       # 最小语音段时长
    min_silence_duration_ms=150,      # 最小静音段时长
    window_size_ms=40,                # 窗口大小
    speech_pad_ms=40                  # 语音段填充
)
```

## ⚙️ 配置参数

### 主要参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `threshold` | 0.5 | VAD检测阈值 (0.0-1.0) |
| `min_speech_duration_ms` | 250 | 最小语音段时长（毫秒） |
| `min_silence_duration_ms` | 100 | 最小静音段时长（毫秒） |
| `window_size_ms` | 30 | 检测窗口大小（毫秒） |
| `speech_pad_ms` | 30 | 语音段前后填充（毫秒） |
| `sample_rate` | 16000 | 音频采样率（Hz） |

### 高级参数

| 参数 | 说明 |
|------|------|
| `language` | 支持的语言代码 |
| `model_size` | 模型大小 (tiny/small/base/large) |
| `use_onnx` | 是否使用ONNX优化 |
| `return_visualization` | 是否返回可视化结果 |

## 🌍 多语言支持

SileroVAD支持以下语言：

- **en**: 英语 (English)
- **de**: 德语 (Deutsch)
- **es**: 西班牙语 (Español)
- **fr**: 法语 (Français)
- **it**: 意大利语 (Italiano)
- **pl**: 波兰语 (Polski)
- **pt**: 葡萄牙语 (Português)
- **ru**: 俄语 (Русский)
- **tr**: 土耳其语 (Türkçe)
- **uk**: 乌克兰语 (Українська)
- **zh**: 中文 (中文)

## 📊 性能指标

- **准确率**: >95%
- **召回率**: >90%
- **延迟**: <50ms
- **内存占用**: <100MB
- **支持采样率**: 8kHz, 16kHz, 32kHz, 48kHz

## 🔍 输出格式

模型输出为 `AudioSpan` 对象列表，每个对象包含：

```python
AudioSpan(
    start_ms=1000,      # 开始时间（毫秒）
    end_ms=2000,        # 结束时间（毫秒）
    waveform=...,        # 对应的音频波形
    sample_rate=16000    # 采样率
)
```

## 📈 性能优化建议

### 1. 设备选择
- **CPU**: 适合轻量级应用，延迟较高
- **GPU**: 适合实时应用，延迟低

### 2. 参数调优
- 降低 `threshold` 提高召回率
- 增加 `min_speech_duration_ms` 减少误检
- 调整 `window_size_ms` 平衡延迟和准确率

### 3. 批处理
- 对于长音频，可以分段处理
- 使用适当的缓冲区大小

## 🚨 注意事项

1. **依赖要求**: 需要安装 `silero-vad` 和 `torch`
2. **内存管理**: 首次加载模型会下载权重文件
3. **采样率**: 建议使用16kHz采样率
4. **音频格式**: 支持常见音频格式（wav, mp3, flac等）

## 🐛 故障排除

### 常见问题

1. **ImportError: No module named 'silero_vad'**
   ```bash
   pip install silero-vad
   ```

2. **CUDA out of memory**
   - 使用CPU: `device_id="cpu"`
   - 或减少批处理大小

3. **检测结果不准确**
   - 调整 `threshold` 参数
   - 检查音频质量
   - 确认采样率设置

4. **性能问题**
   - 使用GPU加速
   - 调整窗口大小
   - 优化音频预处理

## 📚 参考资料

- [SileroVAD GitHub](https://github.com/snakers4/silero-vad)
- [论文链接](https://arxiv.org/abs/2207.12966)
- [在线演示](https://huggingface.co/spaces/snakers4/silero-vad)

## 📝 更新日志

- **v4.0.0**: 支持多语言，性能大幅提升
- **v3.0.0**: 添加ONNX支持，优化推理速度
- **v2.0.0**: 改进模型架构，提高准确率
- **v1.0.0**: 初始版本发布

## 🤝 贡献

欢迎提交Issue和Pull Request来改进这个模型！

## 📄 许可证

本项目采用MIT许可证。SileroVAD模型遵循其原始许可证。
