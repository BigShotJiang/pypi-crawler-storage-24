from .config import registry
from .data import Audio
from .pipeline import AudioPipeline

import nest_asyncio
nest_asyncio.apply() # jupyter


def load(pipeline_name: str) -> AudioPipeline:
    from importlib.metadata import entry_points

    for plugin in entry_points(group="fasr.pipelines"):
        if plugin.name == pipeline_name:
            plugin.load()
    return registry.pipelines.get(pipeline_name)()


__all__ = [
    "Audio",
    "AudioPipeline",
    "load"
]
