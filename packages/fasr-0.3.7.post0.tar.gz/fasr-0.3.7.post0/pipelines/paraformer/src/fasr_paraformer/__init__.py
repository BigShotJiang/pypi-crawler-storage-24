from fasr.config import registry
from fasr.pipeline import AudioPipeline

from .models.asr import ParaformerForASR
from .models.pun import CTTransformerForPunc
from .models.vad import FSMNForVAD


@registry.pipelines.register("paraformer")
def build_paraformer_pipeline() -> AudioPipeline:
    pipeline = (
        AudioPipeline()
        .add_pipe("detector", model="fsmn")
        .add_pipe("recognizer", model="paraformer")
        .add_pipe("sentencizer", model="ct_transformer")
    )
    return pipeline


@registry.pipelines.register("seaco_paraformer")
def build_seaco_paraformer_pipeline() -> AudioPipeline:
    pipeline = (
        AudioPipeline()
        .add_pipe("detector", model="fsmn")
        .add_pipe("recognizer", model="seaco_paraformer")
        .add_pipe("sentencizer", model="ct_transformer")
    )
    return pipeline


__all__ = [
    "build_paraformer_pipeline",
    "build_seaco_paraformer_pipeline",
    "FSMNForVAD",
    "ParaformerForASR",
    "CTTransformerForPunc",
]
