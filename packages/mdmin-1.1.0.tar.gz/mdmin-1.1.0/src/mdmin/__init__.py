"""
mdmin — Rule-based markdown compression + context extraction for LLM consumption.

Basic usage::

    from mdmin import compress, extract, estimate_tokens

    # Compress
    result = compress(text, level="medium")
    print(result.output)
    print(result.stats.pct)   # % saved

    # Extract relevant context
    result = extract(text, "how does auth work", max_tokens=2000)
    print(result.text)
    print(result.stats.reduction)  # % reduction

"""

from mdmin.engine import compress, estimate_tokens, CompressResult, CompressionStats
from mdmin._extractor import (
    ContextExtractor,
    quick_extract,
    ExtractResult,
    ExtractStats,
    TopScore,
)


def extract(text: str, query: str, *, max_tokens: int = 2000) -> "ExtractResult":
    """Extract query-relevant chunks from *text* within *max_tokens* budget."""
    return quick_extract(text, query, {"maxTokens": max_tokens})


__all__ = [
    "compress",
    "estimate_tokens",
    "CompressResult",
    "CompressionStats",
    "extract",
    "ContextExtractor",
    "quick_extract",
    "ExtractResult",
    "ExtractStats",
    "TopScore",
]
__version__ = "1.1.0"
