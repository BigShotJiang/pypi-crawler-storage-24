# My Mongolian Programing Tools
# 我的蒙古文相关编程工具


# 1. sort_skygalig_mgl
sort words as traditional mongolian order
拉丁词按蒙古文顺序排序

拉丁和顺序如下 
'a', 'e', 'ë','i', 'o', 'u', 'ö', 'ü', 'n','b','p','x','g','m','l','s','š','t','d', 'č','ǰ','y','r','w','f','k','c','z','h','ž', 'lh','ĵi','ĉi'

使用方法：\
from huqitulib import sort_skygalig_mgl

test_sorted = sorted([
'enger',
'ente', 
'enehu',
], key=sort_skygalig_mgl.sort_key)

sort_skygalig_mgl.sort_text_file(input_file, output_file="排序.txt")

sort_skygalig_mgl.sort_excel_file(input_file, output_file="排序.xlsx", column_index=0)

# 2. encode_converter
convert traditional mongolian latin to unicode 
拉丁与传统蒙古文编码转换器

使用方法：\
from huqitulib import encode_converter

encode_converter.convert_unicode_to_latin(unicode_word_list: list, output_word: list):

encode_converter.convert_latin_to_unicode(word_list: list, output_word: list):

encode_converter.convert_latin_to_unicode_file(in_file: str, out_file: str):
encode_converter.convert_unicode_to_latin_file与上面相反

encode_converter.convert_latin_to_unicode_excel(in_file: str, out_file: str, column_in_index=0, column_out_index=1):
encode_converter.convert_unicode_to_latin_excel()与上面相反