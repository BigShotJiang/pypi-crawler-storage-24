import pandas as pd

# 国际标准编码
_unicode_mapping = {
    'a': 'U+1820', 'e': 'U+1821', 'i': 'U+1822', 'o': 'U+1823', 'u': 'U+1824', 
    'ö': 'U+1825', 'ü': 'U+1826', 'ë': 'U+1827',
    'n': 'U+1828', 'ng': 'U+1829','b': 'U+182A', 'p': 'U+182B', 'x': 'U+182C', 
    'g': 'U+182D', 'm': 'U+182E', 'l': 'U+182F', 's': 'U+1830', 'š': 'U+1831', 
    't': 'U+1832', 'd': 'U+1833', 'č': 'U+1834', 'ǰ': 'U+1835', 'y': 'U+1836', 
    'r': 'U+1837', 'w': 'U+1838', 'f': 'U+1839', 'k': 'U+183A', # 'u+183B'没有对应的拉丁字母
    'c': 'U+183C', 'z': 'U+183D', 'h': 'U+183E', 
    'ž': 'U+183f',
    #"yi": "U+1836+U+1822",
    # 特殊字母
    "lh": "U+1840", "ĵi": "U+1841", "ĉi": "U+1842",
    # _ -
    "_": "U+180E", "-": "U+202F", "'": "U+180B",
    "....": "U+1801", ",": "U+1802", ".": "U+1803", ":": "U+1804", 
    ";": "U+FE14", "!": "U+FE15", "?": "U+FE16",
    "--": "U+FE31", "(": "U+FE35", ")": "U+FE36", "<<": "U+FE3D", ">>": "U+FE3E", "<": "U+FE3F", ">": "U+FE4D",
    "[": "U+FE47", "]": "U+FE48",
}

# 将'U+1820'等格式的unicode编码转换成实际字符
def _unicode_to_char(unicode_str):
    return chr(int(unicode_str[2:], 16))

# 将蒙古文拉丁转换成国际标准编码
def convert_latin_to_unicode(word_list: list, output_word: list):
    for word in word_list:
        unicode_word = ""
        i = 0
        while i < len(word):
            # "...."
            if word[i:i+4] == "....":
                unicode_word += _unicode_to_char(_unicode_mapping["...."])
                i += 4
            # ng
            elif word[i:i+2] == "ng":
                unicode_word += _unicode_to_char(_unicode_mapping["ng"])
                i += 2

            # lh, ĵi, ĉi
            elif word[i:i+2] in {"lh","ĵi","ĉi","<<",">>","--"}:
                unicode_word += _unicode_to_char(_unicode_mapping[word[i:i+2]])
                i += 2

            else:
                # 判断单个字符是否在unicode_mapping中，如果在则转换，否则直接添加
                if word[i] in _unicode_mapping:
                    unicode_word += _unicode_to_char(_unicode_mapping[word[i]])
                else:
                    unicode_word += word[i]
                i += 1

        output_word.append(unicode_word)

#蒙古文unicode转换回拉丁字母的函数
def convert_unicode_to_latin(unicode_word_list: list, output_word: list):
    # 反转unicode_mapping字典
    reverse_unicode_mapping = {v: k for k, v in _unicode_mapping.items()}

    for unicode_word in unicode_word_list:
        latin_word = ""
        i = 0
        while i < len(unicode_word):
            # 获取当前字符的unicode编码
            unicode_char = f"U+{ord(unicode_word[i]):04X}"
            # 判断该编码是否在reverse_unicode_mapping中
            if unicode_char in reverse_unicode_mapping:
                latin_word += reverse_unicode_mapping[unicode_char]
            else:
                latin_word += unicode_word[i]
            i += 1

        output_word.append(latin_word)

# 拉丁文件转国际标准编码文件
def convert_latin_to_unicode_file(in_file: str, out_file: str):
    with open(in_file, 'r', encoding='utf-8') as f:
        word_list = f.read().splitlines()

    output_word = []
    convert_latin_to_unicode(word_list, output_word)

    with open(out_file, 'w', encoding='utf-8') as f:
        for word in output_word:
            f.write(word + '\n')

# 国际标准编码转拉丁文件
def convert_unicode_to_latin_file(in_file: str, out_file: str):
    with open(in_file, 'r', encoding='utf-8') as f:
        word_list = f.read().splitlines()

    output_word = []
    convert_unicode_to_latin(word_list, output_word)

    with open(out_file, 'w', encoding='utf-8') as f:
        for word in output_word:
            f.write(word + '\n')

# 拉丁excel文件转国际标准编码excel文件
def convert_latin_to_unicode_excel(in_file: str, out_file: str, column_in_index=0, column_out_index=1):
    print(f"正在读取文件: {in_file}")
    
    # 读取Excel文件
    df = pd.read_excel(in_file)
    
    print(f"读取了 {len(df)} 行数据")
    print(f"列名: {list(df.columns)}")
    
    column_name = df.columns[column_in_index]
    print(f"\n正在对第 {column_in_index} 列 '{column_name}' 进行转换...")
    
    # 转换指定列
    output_word = []
    convert_latin_to_unicode(df[column_name].astype(str).tolist(), output_word)
    
    column_out_name = df.columns[column_out_index]
    df[column_out_name] = output_word
    
    # 导出到新文件
    print(f"\n正在导出到: {out_file}")
    df.to_excel(out_file, index=False)
    
    print(f"✓ 导出完成！")
    print(f"  总行数: {len(df)}")
    
    return df


# 国际标准编码转拉丁，excel文件
def convert_unicode_to_latin_excel(in_file: str, out_file: str, column_in_index=0, column_out_index=1):
    print(f"正在读取文件: {in_file}")
    
    # 读取Excel文件
    df = pd.read_excel(in_file)
    
    print(f"读取了 {len(df)} 行数据")
    print(f"列名: {list(df.columns)}")
    
    column_name = df.columns[column_in_index]
    print(f"\n正在对第 {column_in_index} 列 '{column_name}' 进行转换...")
    
    # 转换指定列
    output_word = []
    convert_unicode_to_latin(df[column_name].astype(str).tolist(), output_word)
    
    column_out_name = df.columns[column_out_index]
    df[column_out_name] = output_word
    
    # 导出到新文件
    print(f"\n正在导出到: {out_file}")
    df.to_excel(out_file, index=False)
    
    print(f"✓ 导出完成！")
    print(f"  总行数: {len(df)}")
    
    return df