import pandas as pd

# 1. 给定顺序
_order = ['a', 'e', 'ë','i', 'o', 'u', 'ö', 'ü',
         'n','b','p','x','g','m','l','s','š','t','d',
         'č','ǰ','y','r','w','f','k','c','z','h','ž',
         'lh','ĵi','ĉi']

_order_index = {c: i for i, c in enumerate(_order)}

# 2. 特殊字母
_special_letters = {'yi','y','u','ü','ng','n','b','g','m','l','s','d','r'}

# 3. 元音
_vowels = {'a', 'e', 'ë','i', 'o', 'u', 'ö', 'ü'}

# 4. 罗马数字 'Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ', 'Ⅵ', 'Ⅶ', 'Ⅷ', 'Ⅸ', 'Ⅹ', 'Ⅺ', 'Ⅻ'
_roman_numerals = ['Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ', 'Ⅴ', 'Ⅵ', 'Ⅶ', 'Ⅷ', 'Ⅸ', 'Ⅹ', 'Ⅺ', 'Ⅻ']
# ---------- tokenize ----------
def _tokenize(word: str):
    w = word.lower()
    tokens = []
    i = 0

    while i < len(w):
        # yi
        if w[i:i+2] == "yi":
            tokens.append("yi")
            i += 2

        # ng
        elif w[i:i+2] == "ng":
            tokens.append("ng")
            i += 2

        # lh, ĵi, ĉi
        elif w[i:i+2] in {"lh","ĵi","ĉi"}:
            tokens.append(w[i:i+2])
            i += 2

        # n + vowel
        elif w[i] == "n" and i+1 < len(w) and w[i+1] in _vowels:
            tokens.append("n"+w[i+1])
            i += 2

        # - + some
        # elif w[i] == "-" and i+1 < len(w):
        #     tokens.append(w[i+1]+"-")
        #     i += 2

        # # n + consonant
        # elif w[i] == "n" and i+1 < len(w):
        #     tokens.append("n"+w[i+1])
        #     i += 2

        else:
            tokens.append(w[i])
            i += 1

    return tokens


def _char_weight(tok: str):
    # roman numerals (排在最前面)
    tok_upper = tok.upper()
    if tok_upper in _roman_numerals:
        return -100 + _roman_numerals.index(tok_upper)

    # special symbol order: space < -
    if tok == " ":
        return -0.6
    if tok == "-":
        return -0.5

    # yi == i but after
    if tok == "yi":
        return _order_index["i"] + 0.5

    # n + vowel
    if len(tok) == 2 and tok[0] == "n" and tok[1] in _vowels:
        return _order_index["n"] + _order_index[tok[1]] + 0.1

    # _ + some
    if len(tok) == 2 and tok[1] == "_":
        return _order_index[tok[0]] + 0.1

    # n (no vowel)
    if tok == "n":
        return _order_index["n"] + 0.2

    # ng
    if tok == "ng":
        return _order_index["n"] + 0.3

    # # nd,nf,nm,nr...
    # if len(tok) == 2 and tok[0] == "n":
    #     return _order_index["n"] + 0.4

    return _order_index.get(tok, 999)


# ---------- ending penalty ----------
def _ending_penalty(word: str):
    w = word.lower()
    if not w:
        return 0

    if len(w) >= 2 and w[-2:] in _special_letters:
        return 1

    if len(w) >= 2 and w[-2] in _special_letters and w[-1] in _vowels:
        return 1

    if w[-1] in _special_letters:
        return 1

    return 0




# ---------- sort key ----------
# 排序时使用的key函数，如 sorted(word_list, key=sort_key)
def sort_key(word: str):
    tokens = _tokenize(word)
    weights = [_char_weight(t) for t in tokens]
    return (weights, len(tokens))

# 给excel文件排序，使用方法：sort_excel_file("输入文件名.xlsx", "输出文件名.xlsx", 列索引)
# 列索引从0开始，例如第四列索引为3
def sort_excel_file(input_file, output_file="排序.xlsx", column_index=0):
    print(f"正在读取文件: {input_file}")
    
    # 读取Excel文件
    df = pd.read_excel(input_file)
    
    print(f"读取了 {len(df)} 行数据")
    print(f"列名: {list(df.columns)}")
    
    column_name = df.columns[column_index]
    print(f"\n正在对第 {column_index} 列 '{column_name}' 进行排序...")
    
    # 使用 sort_values 和自定义 key 函数进行排序
    # 注意：pandas 的 sort_values 的 key 参数接收一个 Series，返回一个 Series
    # 我们需要对 Series 中的每个值应用 sort_key 函数
    df_sorted = df.sort_values(
        by=column_name,
        key=lambda col: col.map(lambda x: sort_key(str(x)) if pd.notna(x) else ([], 0))
    )
    
    # 重置索引
    df_sorted = df_sorted.reset_index(drop=True)
    
    # 导出到新文件
    print(f"\n正在导出到: {output_file}")
    df_sorted.to_excel(output_file, index=False)
    
    print(f"✓ 导出完成！")
    print(f"  总行数: {len(df_sorted)}")
    
    return df_sorted

# 对文本文件进行排序，使用方法：sort_text_file("输入文件名.txt", "输出文件名.txt")
def sort_text_file(input_file, output_file="排序.txt"):
    print(f"正在读取文件: {input_file}")
    
    # 读取文本文件
    with open(input_file, 'r', encoding='utf-8') as f:
        lines = f.read().splitlines()
    print(f"读取了 {len(lines)} 行数据")
    
    # 对行进行排序
    sorted_lines = sorted(lines, key=sort_key)
    
    # 写入输出文件
    with open(output_file, 'w', encoding='utf-8') as f:
        for line in sorted_lines:
            f.write(line + '\n')
    
    print(f"✓ 排序完成并导出到: {output_file}")
    






# test_sorted = sorted([
# 'anig_a Ⅱ',
# 'anig_a Ⅰ',
# 'anag_a Ⅰ',
# 'anag_a Ⅱ',
# 'anag_a Ⅲ',
# 'anag_a Ⅳ'
# ], key=sort_key)
# print(test_sorted)

# def sort_excel(in_file_name: str, out_file_name: str):
#     df = pd.read_excel(in_file_name)
#     df.sort_values(by="地名", key=sort_key, inplace=True)
#     df.to_excel(out_file_name, index=False)

# ---------- 给Excel排序 ----------
# def sort_excel():
#     df = pd.read_excel("地名数据_去重修改.xlsx")
#     df.sort_values(by="地名", key=sort_key, inplace=True)
#     df.to_excel("地名数据_去重修改_排序.xlsx", index=False)

# sort_excel()

# # --- 测试 ---
# words = [
#     "aguy ama",
#     "aguy-yin ayil",
#     "aguy-yin gool",
#     "aguy-yin guu",
#     "aguy-yin tal_a",
#     "aguy-yin sili",
#     "aguy-yin nur_a",
#     "aguy-yin süm_e",
#     "aguy otor",
#     "aguy xosigu",
#     "aguytu"
# ]
# # --- 排序 ---
# sorted_words = sorted(words, key=sort_key)


# print("排序结果：\n")
# for w in sorted_words:
#     print(w)
