from __future__ import annotations

import asyncio
import logging
import threading
from typing import Any
import uuid

from aethergraph.api.v1.deps import RequestIdentity
from aethergraph.contracts.errors.errors import (
    GraphBuildError,
    GraphHasPendingWaits,
    GraphInputBindError,
    GraphMaterializationError,
    build_error_hints,
)
from aethergraph.contracts.services.state_stores import GraphSnapshot
from aethergraph.core.graph.node_state import NodeStatus
from aethergraph.core.graph.task_graph import TaskGraph
from aethergraph.core.runtime.recovery import hash_spec, recover_graph_run
from aethergraph.services.state_stores.graph_observer import PersistenceObserver
from aethergraph.services.state_stores.resume_policy import (
    assert_snapshot_json_only,
)
from aethergraph.services.state_stores.utils import snapshot_from_graph

from ..execution.forward_scheduler import ForwardScheduler
from ..execution.retry_policy import RetryPolicy
from ..graph.graph_fn import GraphFunction
from ..graph.graph_refs import resolve_any as _resolve_any
from ..runtime.run_cancellation import (
    LocalSchedulerCancellationAdapter,
    get_run_cancellation_registry,
)
from ..runtime.runtime_env import RuntimeEnv
from ..runtime.runtime_metering import current_meter_context
from ..runtime.runtime_services import ensure_services_installed
from .run_registration import RunRegistrationGuard


# ---------- env helpers ----------
def _get_container():
    from aethergraph.services.container.default_container import build_default_container

    # install once if not installed by sidecar/server
    return ensure_services_installed(build_default_container)


async def _attach_persistence(graph, env, spec, snapshot_every=1) -> PersistenceObserver | None:
    """
    Wire the centralized state_store to the graph via PersistenceObserver.
    Returns the observer instance so caller can optionally force a final snapshot.
    """
    store = getattr(env.container, "state_store", None) or getattr(env, "state_store", None)
    if not store:
        # Safe no-op: resumability won't work but run still executes.
        return None

    obs = PersistenceObserver(
        store=store,
        artifact_store=env.container.artifacts,
        spec_hash=hash_spec(spec),
        snapshot_every=snapshot_every,
    )
    graph.add_observer(obs)
    return obs


async def _build_env(
    owner, inputs: dict[str, Any], identity: RequestIdentity | None = None, **rt_overrides
) -> tuple[RuntimeEnv, RetryPolicy, int]:
    container = _get_container()
    # apply optional overrides onto the container instance
    for k, v in rt_overrides.items():
        if v is not None and hasattr(container, k):
            setattr(container, k, v)

    run_id = rt_overrides.get("run_id") or f"run-{uuid.uuid4().hex[:8]}"
    session_id = rt_overrides.get("session_id")
    graph_id = getattr(owner, "graph_id", None) or getattr(owner, "name", None)

    # Prefer runtime overrides (from RunRecord) over static graph metadata -- UI provenance
    agent_id = (
        rt_overrides.get("agent_id")
        or getattr(owner, "agent_id", None)
        or getattr(getattr(owner, "spec", None) or {}, "agent_id", None)
        or (getattr(owner, "spec", None) or {}).get("agent_id")  # for dict-like spec
    )

    app_id = (
        rt_overrides.get("app_id")
        or getattr(owner, "app_id", None)
        or getattr(getattr(owner, "spec", None) or {}, "app_id", None)
        or (getattr(owner, "spec", None) or {}).get("app_id")
    )

    env = RuntimeEnv(
        run_id=run_id,
        graph_id=graph_id,
        session_id=session_id,
        identity=identity,
        graph_inputs=inputs,
        outputs_by_node={},
        container=container,
        agent_id=agent_id,
        app_id=app_id,
        memory_level_override=rt_overrides.get("memory_level"),
        memory_scope_override=rt_overrides.get("memory_scope"),
    )

    retry = rt_overrides.get("retry") or RetryPolicy()
    max_conc = rt_overrides.get("max_concurrency", getattr(owner, "max_concurrency", 4))
    return env, retry, max_conc


# ---------- materialization ----------
def _materialize_target(target) -> Any:
    """
    Accept:
      - TaskGraph instance
      - GraphFunction instance
      - graph/graphfn builders marked with __ag_builder__
      - builder object with .build()
      - a callable builder that returns a TaskGraph/GraphFunction when invoked with no args
    """
    if isinstance(target, (TaskGraph, GraphFunction)):  # noqa: UP038
        return target

    # explicit lazy builder marker used by registry entries
    if getattr(target, "__ag_builder__", False) and callable(target):
        built = target()
        if isinstance(built, (TaskGraph, GraphFunction)):  # noqa: UP038
            return built

    # already graph-like by duck typing
    if hasattr(target, "io_signature") and hasattr(target, "spec"):
        return target

    # builder pattern with .build() - expected for TaskGraph builders
    if hasattr(target, "build") and callable(target.build):
        g = target.build()
        if isinstance(g, (TaskGraph, GraphFunction)):  # noqa: UP038
            return g
        if hasattr(g, "io_signature") and hasattr(g, "spec"):
            return g

    # callable builder that returns a TaskGraph or GraphFunction
    if callable(target):
        g = target()
        if isinstance(g, (TaskGraph, GraphFunction)):  # noqa: UP038
            return g
        if hasattr(g, "io_signature") and hasattr(g, "spec"):
            return g

    raise TypeError(
        "run_async: target must be a TaskGraph/GraphFunction instance, "
        "a graph builder, or a callable returning one."
    )


def _materialize_task_graph(target) -> TaskGraph:
    graph = _materialize_target(target)
    if isinstance(graph, TaskGraph):  # noqa: UP038
        return graph
    raise TypeError("run_async: target resolved to GraphFunction where TaskGraph was required.")


async def _resolve_graph_outputs(
    graph,
    inputs: dict[str, Any],
    env: RuntimeEnv,
):
    bindings = graph.io_signature().get("outputs", {}).get("bindings", {})

    def _res(b):
        return _resolve_any(b, graph_inputs=inputs, outputs_by_node=env.outputs_by_node)

    try:
        result = {k: _res(v) for k, v in bindings.items()}
    except KeyError as e:
        failed = [
            nid
            for nid, n in graph.state.nodes.items()
            if getattr(n, "status", "") in (NodeStatus.FAILED, NodeStatus.CANCELLED)
        ]
        if failed:
            raise RuntimeError(
                "Graph failed before outputs became resolvable. "
                f"Failed nodes: {', '.join(sorted(failed))}"
            ) from e
        waiting = [
            nid
            for nid, n in graph.state.nodes.items()
            if getattr(n, "status", "").startswith("WAITING_")
        ]
        if not waiting:
            raise RuntimeError(
                "Graph terminated without resolvable outputs and without pending waits."
            ) from e
        continuations = []
        if env.continuation_store and hasattr(env.continuation_store, "get"):
            conts = await asyncio.gather(
                *[env.continuation_store.get(run_id=env.run_id, node_id=nid) for nid in waiting]
            )
            for nid, cont in zip(waiting, conts, strict=False):
                if cont:
                    continuations.append(
                        {
                            "node_id": nid,
                            "kind": cont.kind,
                            "token": cont.token,
                            "channel": cont.channel,
                            "deadline": getattr(cont.deadline, "isoformat", lambda: None)(),
                        }
                    )
        raise GraphHasPendingWaits(
            "Graph quiesced with pending waits; outputs are not yet resolvable.",
            waiting_nodes=waiting,
            continuations=continuations,
        ) from e

    return result


async def _resolve_graph_outputs_or_waits(graph, inputs, env, *, raise_on_waits: bool = True):
    try:
        return await _resolve_graph_outputs(graph, inputs, env)
    except GraphHasPendingWaits as e:
        if raise_on_waits:
            raise
        return {
            "status": "waiting",
            "waiting_nodes": e.waiting_nodes,
            "continuations": e.continuations,
        }


def _seed_outputs_from_snapshot(env, snap: GraphSnapshot):
    env.outputs_by_node = env.outputs_by_node or {}
    nodes = snap.state.get("nodes", {})
    for nid, ns in nodes.items():
        outs = (ns or {}).get("outputs") or {}
        if outs:
            env.outputs_by_node[nid] = outs


def _seed_outputs_from_graph(env: RuntimeEnv, graph: TaskGraph):
    env.outputs_by_node = env.outputs_by_node or {}
    for nid, ns in graph.state.nodes.items():
        outs = (ns.outputs or {}) if ns is not None else {}
        if outs:
            env.outputs_by_node[nid] = dict(outs)
        else:
            env.outputs_by_node.pop(nid, None)


def _is_graph_complete(snap: GraphSnapshot) -> bool:
    nodes = snap.state.get("nodes", {})
    if not nodes:
        return False

    # completed if every node is DONE/SKIPPED or has outputs matching spec
    def doneish(st):
        s = (st or {}).get("status", "")
        return s in ("DONE", "SKIPPED")

    return all(doneish(ns) for ns in nodes.values())


async def load_latest_snapshot_json(store, run_id: str) -> dict[str, Any] | None:
    """
    Returns the raw JSON dict of the latest snapshot (or None).
    """
    snap = await store.load_latest_snapshot(run_id)
    if not snap:
        return None
    # JsonGraphStateStore serializes GraphSnapshot via snap.__dict__
    # load_latest_snapshot already returns a GraphSnapshot(**jsondict).
    # Convert back to plain JSON-ish dict:

    return {
        "run_id": snap.run_id,
        "graph_id": snap.graph_id,
        "rev": snap.rev,
        "spec_hash": snap.spec_hash,
        "state": snap.state,
    }


def _recover_graph_from_snapshot(
    *,
    spec,
    target_run_id: str,
    source_run_id: str,
    snap: GraphSnapshot,
) -> TaskGraph:
    graph = TaskGraph.from_spec(spec=spec, state=None)
    graph.state.run_id = target_run_id
    if not snap:
        return graph

    want = hash_spec(spec)
    if snap.spec_hash != want:
        logging.getLogger("aethergraph.core.runtime.recovery").warning(
            "[recover_graph_run] Spec hash mismatch for source run %s -> target run %s: snapshot has %s..., want %s...",
            source_run_id,
            target_run_id,
            snap.spec_hash[:8],
            want[:8],
        )

    graph.state.rev = snap.state.get("rev", 0)
    graph.state._bound_inputs = snap.state.get("_bound_inputs")
    for nid, ns_json in snap.state.get("nodes", {}).items():
        ns = graph.state.nodes.setdefault(nid, graph.state.nodes.get(nid))
        status_name = ns_json.get("status", "PENDING")
        status = getattr(NodeStatus, status_name, NodeStatus.PENDING)
        if status == NodeStatus.RUNNING:
            status = NodeStatus.PENDING
        ns.status = status
        ns.outputs = ns_json.get("outputs") or {}
        ns.error = ns_json.get("error")
        ns.attempts = ns_json.get("attempts", 0)
        ns.next_wakeup_at = ns_json.get("next_wakeup_at")
        ns.wait_token = ns_json.get("wait_token")
        ns.wait_spec = ns_json.get("wait_spec")
        ns.started_at = ns_json.get("started_at")
        ns.finished_at = ns_json.get("finished_at")
    return graph


def _is_resume_failed_status(status: Any) -> bool:
    return str(status or "").upper() in {
        NodeStatus.FAILED,
        NodeStatus.FAILED_TIMEOUT,
        NodeStatus.CANCELLED,
    }


async def _prepare_resume_failed_nodes(
    *,
    graph: TaskGraph,
    snap: GraphSnapshot,
    source_run_id: str,
) -> list[str]:
    raw_nodes = (snap.state or {}).get("nodes") or {}
    if not isinstance(raw_nodes, dict) or not raw_nodes:
        raise GraphBuildError(
            f"Resume source run '{source_run_id}' has no node state to replay.",
            code="resume_missing_node_state",
            stage="resume_prepare",
            hints=build_error_hints(
                "resume_missing_node_state",
                f"Run '{source_run_id}' does not have a node snapshot to resume from.",
            ),
        )

    failed_roots = sorted(
        nid for nid, ns in raw_nodes.items() if _is_resume_failed_status((ns or {}).get("status"))
    )
    if not failed_roots:
        raise GraphBuildError(
            f"Resume source run '{source_run_id}' has no failed or canceled nodes to replay.",
            code="resume_no_failed_nodes",
            stage="resume_prepare",
            hints=build_error_hints(
                "resume_no_failed_nodes",
                f"Run '{source_run_id}' is not resumable in failed_nodes mode.",
            ),
        )

    await graph.reset(
        node_ids=failed_roots, recursive=True, direction="forward", preserve_outputs=False
    )
    return failed_roots


def _register_metering_context(env: RuntimeEnv, target: GraphFunction | TaskGraph | Any):
    """
    Build a metering context dict from the RuntimeEnv.
    """
    run_id = env.run_id
    # derive graph_id from target if possible - GraphFunction.name or TaskGraph.spec.graph_id
    graph_id = getattr(target, "name", None) or getattr(
        getattr(target, "spec", None), "graph_id", None
    )

    # user id etc through auth context if available
    user_id = getattr(getattr(env, "identity", None), "user_id", None)
    org_id = getattr(getattr(env, "identity", None), "org_id", None)

    token = current_meter_context.set(
        {
            "run_id": run_id,
            "graph_id": graph_id,
            "session_id": env.session_id,
            "agent_id": env.agent_id,
            "app_id": env.app_id,
            "user_id": user_id,
            "org_id": org_id,
            "client_id": getattr(getattr(env, "identity", None), "client_id", None),
            "trace_id": f"tr_{uuid.uuid4().hex}",
            "span_id": None,
            "parent_span_id": None,
        }
    )
    return token


# ---------- public API ----------
async def run_async(
    target,
    inputs: dict[str, Any] | None = None,
    identity: RequestIdentity | None = None,
    **rt_overrides,
):
    """
    Execute a TaskGraph or GraphFunction asynchronously with optional persistence and resumability.

    This method handles environment setup, cold-resume from persisted state (if available),
    input validation, scheduling, and output resolution. It supports both fresh runs and
    resuming incomplete runs, automatically wiring up persistence observers and enforcing
    snapshot policies.

    Examples:
        Running a graph function:
        ```python
        result = await run_async(my_graph_fn, {"x": 1, "y": 2})
        ```

        Running a TaskGraph with custom run ID and identity:
        ```python
        result = await run_async(
            my_task_graph,
            {"input": 42},
            run_id="custom-run-123",
            identity=my_identity,     # Only used with API requests. Ignored when running locally.
            max_concurrency=8
        )
        ```

    Args:
        target: The TaskGraph, GraphFunction, or builder to execute.
        inputs: Dictionary of input values for the graph.
        identity: Optional RequestIdentity for user/session context.
        **rt_overrides: Optional runtime overrides for environment and execution. Recognized runtime overrides include:

            - run_id (str): Custom run identifier.
            - session_id (str): Session identifier for grouping runs.
            - agent_id (str): Agent identifier for provenance.
            - app_id (str): Application identifier for provenance.
            - retry (RetryPolicy): Custom retry policy.
            - max_concurrency (int): Maximum number of concurrent tasks.
            - Any additional container attributes supported by your environment.

    Returns:
        dict: The resolved outputs of the graph, or a status dict if waiting on continuations.

    Raises:
        GraphHasPendingWaits: If the graph is waiting on external events and outputs are not ready.
        TypeError: If the target is not a valid TaskGraph or GraphFunction.

    Notes:
        - Speficially for GraphFunctions, you can directly use `await graph_fn(**inputs)` without needing `run_async`.
        - `graph_fn` is not resumable; use TaskGraphs for persistence and recovery features.
        - when using `graph` for persistence/resumability, ensure your outputs are JSON-serializable, for examples:
            - primitive types (str, int, float, bool, None)
            - lists/dicts of primitive types

            - graph that can be resumed with JSON-serializable outputs:
            ```python
            @graphify(...)
            def my_graph(...):
                ...
                return {"result": 42, "data": [1, 2, 3], "info": None} # valid JSON-serializable output
            ```
            - graph that cannot be resumed due to non-JSON-serializable outputs:
            ```python
            @graphify(...)
            def my_graph(...):
                ...
                return {"chekpoint": torch.pt, "file": open("data.bin", "rb")} # invalid outputs for resuming (but valid for fresh runs)
            ```
            - Despite this, you can still use `graph` without persistence features; just avoid resuming such graphs.

    """

    inputs = inputs or {}
    try:
        target = _materialize_target(target)
    except GraphBuildError:
        raise
    except Exception as exc:
        raise GraphMaterializationError(
            str(exc),
            code="run_async_invalid_target",
            hints=build_error_hints("run_async_invalid_target", str(exc)),
            cause=exc,
        ) from exc

    # GraphFunction path
    if isinstance(target, GraphFunction):
        inherited_identity = identity
        inherited_overrides = dict(rt_overrides)

        parent_ctx = inputs.get("context")
        if parent_ctx is not None:
            # Prefer explicit context overrides, but also attempt to inherit from parent_ctx if available (e.g. for nested graph_fn calls within a graph run)
            if inherited_identity is None:
                inherited_identity = getattr(parent_ctx, "identity", None)
            for key in ("run_id", "session_id", "agent_id", "app_id"):
                value = getattr(parent_ctx, key, None)
                if value is not None:
                    inherited_overrides.setdefault(key, value)
        else:
            # If no explicit context is provided, attempt to inherit from current interpreter's env if available (e.g. for nested graph_fn calls within a graph run)
            from ..graph.interpreter import current_interpreter

            interp = current_interpreter()
            parent_env = getattr(interp, "env", None) if interp is not None else None
            if parent_env is not None:
                if inherited_identity is None:
                    inherited_identity = getattr(parent_env, "identity", None)
                for key in ("run_id", "session_id", "agent_id", "app_id"):
                    value = getattr(parent_env, key, None)
                    if value is not None:
                        inherited_overrides.setdefault(key, value)

        env_inputs = dict(inputs)
        env_inputs.pop("context", None)
        env, retry, max_conc = await _build_env(
            target,
            env_inputs,
            identity=inherited_identity,
            **inherited_overrides,
        )
        token = _register_metering_context(env, target)  # set metering context
        try:
            return await target.run(env=env, max_concurrency=max_conc, **inputs)
        finally:
            # reset metering context
            current_meter_context.reset(token)

    # TaskGraph path
    try:
        graph = _materialize_task_graph(target)
    except GraphBuildError:
        raise
    except Exception as exc:
        raise GraphMaterializationError(
            str(exc),
            code="run_async_target_not_task_graph",
            hints=build_error_hints("run_async_target_not_task_graph", str(exc)),
            cause=exc,
        ) from exc
    env, retry, max_conc = await _build_env(graph, inputs, identity=identity, **rt_overrides)

    # Extract spec for run/recovery ...
    spec = getattr(graph, "spec", None) or getattr(graph, "get_spec", lambda: None)()
    if spec is None:
        spec = graph.spec

    store = getattr(env.container, "state_store", None)
    snap = None
    resume_from_run_id = rt_overrides.get("resume_from_run_id")
    resume_mode = rt_overrides.get("resume_mode")
    assert store is None or hasattr(
        store, "load_latest_snapshot"
    ), "state_store must implement lo  ad_latest_snapshot(run_id)"

    if store:
        resume_source_run_id = resume_from_run_id or env.run_id
        if resume_from_run_id and resume_from_run_id != env.run_id:
            snap = await store.load_latest_snapshot(resume_source_run_id)
            if snap is None:
                raise GraphBuildError(
                    f"Resume source run '{resume_source_run_id}' not found.",
                    code="resume_source_run_missing",
                    stage="resume_prepare",
                    hints=build_error_hints(
                        "resume_source_run_missing",
                        f"Run '{resume_source_run_id}' has no persisted snapshot to resume from.",
                    ),
                )
            graph = _recover_graph_from_snapshot(
                spec=spec,
                target_run_id=env.run_id,
                source_run_id=resume_source_run_id,
                snap=snap,
            )
        else:
            # 1) Attempt cold-resume (build a graph with hydrated state)
            graph = await recover_graph_run(spec=spec, run_id=env.run_id, store=store)
            snap = await store.load_latest_snapshot(env.run_id)

        # 2) Load raw JSON snapshot and ENFORCE strict policy
        snap_json = await load_latest_snapshot_json(store, resume_source_run_id)
        if snap_json:
            # keep for short-circuit + seeding
            # Short-circuit if already complete
            if snap and not (resume_from_run_id and resume_from_run_id != env.run_id):
                _seed_outputs_from_snapshot(env, snap)
                if _is_graph_complete(snap):
                    return await _resolve_graph_outputs(graph, inputs, env)

            # strict policy: block resume if any non-JSON / __aether_ref__ is present
            try:
                assert_snapshot_json_only(env.run_id, snap_json, mode="reuse_only")
            except GraphBuildError:
                raise
            except Exception as exc:
                raise GraphBuildError(
                    str(exc),
                    code="resume_snapshot_policy_violation",
                    stage="resume_guard",
                    hints=build_error_hints("resume_snapshot_policy_violation", str(exc)),
                    cause=exc,
                ) from exc

        if resume_mode == "failed_nodes":
            if snap is None:
                raise GraphBuildError(
                    f"Resume source run '{resume_source_run_id}' has no persisted snapshot to resume from.",
                    code="resume_source_run_missing",
                    stage="resume_prepare",
                    hints=build_error_hints(
                        "resume_source_run_missing",
                        f"Run '{resume_source_run_id}' has no persisted snapshot to resume from.",
                    ),
                )
            resumed_failed_nodes = await _prepare_resume_failed_nodes(
                graph=graph,
                snap=snap,
                source_run_id=resume_source_run_id,
            )
            env.run_id = env.run_id
            _seed_outputs_from_graph(env, graph)
            rt_overrides.setdefault("resumed_failed_nodes", resumed_failed_nodes)
        elif snap:
            _seed_outputs_from_graph(env, graph)
    else:
        try:
            graph = _materialize_task_graph(target)
        except GraphBuildError:
            raise
        except Exception as exc:
            raise GraphMaterializationError(
                str(exc),
                code="run_async_target_not_task_graph",
                hints=build_error_hints("run_async_target_not_task_graph", str(exc)),
                cause=exc,
            ) from exc

    graph.state.run_id = graph.state.run_id or env.run_id

    # Bind/validate inputs
    try:
        graph._validate_and_bind_inputs(inputs)
    except GraphBuildError:
        raise
    except Exception as exc:
        code = "graph_inputs_missing_required"
        raise GraphInputBindError(
            str(exc),
            code=code,
            hints=build_error_hints(code, str(exc)),
            cause=exc,
        ) from exc

    # Attach persistence observer + run (unchanged) ...
    obs = await _attach_persistence(graph, env, spec, snapshot_every=1)

    # get logger from env's container
    from ..runtime.runtime_services import current_logger_factory

    logger = current_logger_factory().for_scheduler()

    sched = ForwardScheduler(
        graph,
        env,
        retry_policy=retry,
        max_concurrency=max_conc,
        skip_dep_on_failure=True,
        stop_on_first_error=True,
        logger=logger,
    )
    cancel_registry = get_run_cancellation_registry(env.container)
    cancel_handle = await cancel_registry.create(env.run_id)
    cancel_handle.register_adapter(
        LocalSchedulerCancellationAdapter(sched),
        adapter_kind="local_scheduler",
    )

    # Register for resumes and run
    token = _register_metering_context(env, target)  # set metering context
    try:
        with RunRegistrationGuard(run_id=env.run_id, scheduler=sched, container=env.container):
            try:
                await sched.run()
            except asyncio.CancelledError:
                raise
            finally:
                # FINAL SNAPSHOT on normal or cancelled exit (if store exists)
                if store and obs:
                    artifacts = getattr(env.container, "artifacts", None)
                    snap = await snapshot_from_graph(
                        run_id=graph.state.run_id or env.run_id,
                        graph_id=graph.graph_id,
                        rev=graph.state.rev,
                        spec_hash=hash_spec(spec),
                        state_obj=graph.state,
                        graph_obj=graph,
                        artifacts=artifacts,
                        allow_externalize=False,  # FIXME: artifact writer async loop error; set False to *avoid* writing artifacts during snapshot
                        include_wait_spec=True,
                    )
                    await store.save_snapshot(snap)
                if cancel_handle.is_cancel_requested():
                    backend_state = await cancel_handle.backend_state()
                    cancel_handle.mark_backend_stopped(
                        backend_state=backend_state,
                        terminal_status="canceled",
                    )

        # Resolve graph-level outputs (will raise  if waits)
        return await _resolve_graph_outputs_or_waits(graph, inputs, env, raise_on_waits=True)
    finally:
        # reset metering context
        current_meter_context.reset(token)


async def run_or_resume_async(
    target,
    inputs: dict[str, Any],
    *,
    run_id: str | None = None,
    session_id: str | None = None,
    identity: RequestIdentity | None = None,
    **rt_overrides,
):
    """
    If state exists for run_id → cold resume, else fresh run.
    Exactly the same signature as run_async plus optional run_id.
    """
    if run_id is not None:
        rt_overrides = dict(rt_overrides or {}, run_id=run_id)
    if session_id is not None:
        rt_overrides = dict(rt_overrides or {}, session_id=session_id)
    return await run_async(target, inputs, identity=identity, **rt_overrides)


# sync adapter (optional, safe in notebooks/servers)
class _LoopThread:
    def __init__(self):
        self._ev = threading.Event()
        self._thread = threading.Thread(target=self._worker, daemon=True)
        self._loop: asyncio.AbstractEventLoop | None = None
        self._thread.start()
        self._ev.wait()

    def _worker(self):
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        self._loop = loop
        self._ev.set()
        loop.run_forever()

    def submit_old(self, coro):
        # this will block terminal until coro is done
        loop = self._loop
        if loop is None:
            raise RuntimeError("Event loop not initialized")
        fut = asyncio.run_coroutine_threadsafe(coro, loop)
        return fut.result()

    def submit(self, coro):
        # this will allow KeyboardInterrupt to propagate -> still not perfect. Use async main if possible.
        loop = self._loop
        if loop is None:
            raise RuntimeError("Event loop not initialized")
        fut = asyncio.run_coroutine_threadsafe(coro, loop)
        try:
            return fut.result()
        except KeyboardInterrupt:
            # cancel the task in the loop thread and wait for cleanup
            fut.cancel()

            def _cancel_all():
                for t in asyncio.all_tasks(loop):
                    t.cancel()

            loop.call_soon_threadsafe(_cancel_all)
            raise


_LOOP = _LoopThread()


def run(
    target,
    inputs: dict[str, Any] | None = None,
    identity: RequestIdentity | None = None,
    **rt_overrides,
):
    """
    Execute a target graph node synchronously with the provided inputs.

    This function submits the execution of a target node (or graph) to the event loop,
    allowing for asynchronous execution while providing a synchronous interface.
    Runtime configuration overrides can be supplied as keyword arguments.

    Examples:
        Running a graph node with default inputs:
        ```python
        future = run(my_node)
        result = future.result()
        ```

        Running with custom inputs and runtime overrides:
        ```python
        future = run(my_node, inputs={"x": 42}, timeout=10)
        output = future.result()
        ```

    Args:
        target: The graph node or callable to execute.
        inputs: Optional dictionary of input values to pass to the node.
        identity: Optional RequestIdentity for user/session context.
        **rt_overrides: Additional keyword arguments to override runtime configuration.

    Returns:
        concurrent.futures.Future: A future representing the asynchronous execution of the node.

    Notes:
        - This function is suitable for use in synchronous contexts where asynchronous execution is desired.
        - It is recommended to use asynchronous execution directly when possible for better performance and responsiveness.

    Warnings:
        - KeyboardInterrupt handling may not be perfect; consider using an async main function when possible.
        - This function blocks the calling thread until the execution is complete.
    """
    inputs = inputs or {}
    return _LOOP.submit(run_async(target, inputs, identity=identity, **rt_overrides))
