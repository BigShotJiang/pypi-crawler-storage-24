"""Setup configuration for DepRaptor."""

from setuptools import setup, find_packages
from pathlib import Path

# Read README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="depraptor",
    version="1.0.0",
    author="LAKSHMIKANTHAN K (letchupkt)",
    author_email="",
    description="Dependency Confusion Vulnerability Scanner and PoC Generator",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/letchupkt/depraptor",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Security",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
    ],
    python_requires=">=3.10",
    install_requires=[
        "typer>=0.9.0",
        "rich>=13.0.0",
        "requests>=2.31.0",
        "gitpython>=3.1.0",
        "tomli>=2.0.0",
    ],
    entry_points={
        "console_scripts": [
            "depraptor=depraptor.cli.main:app",
        ],
    },
)
