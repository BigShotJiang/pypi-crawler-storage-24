"""
DepRaptor - Dependency Confusion Vulnerability Scanner
Developer: LAKSHMIKANTHAN K (letchupkt)
"""

__version__ = "1.0.0"
__author__ = "LAKSHMIKANTHAN K (letchupkt)"
