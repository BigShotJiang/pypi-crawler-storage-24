"""YAML agent validation and reference resolution helpers.

This module provides helper functions for parsing YAML agent files and
resolving $ref references. These functions are used by YamlDefinitionLoader.
"""

from pathlib import Path
from typing import Any

import yaml
from pydantic import ValidationError

from streetrace.agents.base_agent_loader import (
    AgentCycleError,
    AgentValidationError,
)
from streetrace.agents.resolver import SourceResolver
from streetrace.agents.yaml_models import (
    AgentRef,
    InlineAgentSpec,
    ToolSpec,
    YamlAgentDocument,
    YamlAgentSpec,
)
from streetrace.log import get_logger

logger = get_logger(__name__)

# Maximum depth for $ref resolution to prevent infinite recursion
MAX_REF_DEPTH = 5


def _parse_yaml_string(content: str, source: str) -> dict[str, Any]:
    """Parse YAML content from string.

    Args:
        content: YAML content as string
        source: Source identifier for error messages

    Returns:
        Parsed YAML data as dict

    Raises:
        AgentValidationError: If parsing fails

    """
    try:
        data = yaml.safe_load(content)
        if not isinstance(data, dict):
            msg = f"YAML must contain a mapping/object, got {type(data).__name__}"
            raise AgentValidationError(msg)
    except yaml.YAMLError as e:
        msg = f"Invalid YAML syntax in {source}: {e}"
        raise AgentValidationError(msg, cause=e) from e
    else:
        return data


def _load_agent_by_identifier(
    identifier: str,
    resolver: SourceResolver,
    current_file: Path | None,
    visited: set[Path | str],
    depth: int,
) -> YamlAgentDocument:
    """Load agent using resolver (supports names, paths, URLs).

    Args:
        identifier: Agent identifier (name, path, or URL)
        resolver: Source resolver instance
        current_file: Current file path for relative resolution
        visited: Set of visited sources for cycle detection
        depth: Current recursion depth

    Returns:
        YamlAgentDocument with resolved references

    Raises:
        AgentValidationError: If loading or validation fails
        AgentCycleError: If circular references detected

    """
    # Resolve the identifier
    try:
        resolution = resolver.resolve(
            identifier,
            current_file,
            accept_types=["application/x-yaml", "application/yaml", "text/yaml"],
        )
    except ValueError as e:
        msg = f"Failed to resolve agent identifier '{identifier}': {e}"
        raise AgentValidationError(msg, current_file, e) from e

    # Check for cycles using source as key
    source_key = resolution.file_path if resolution.file_path else resolution.source
    if source_key in visited:
        cycle_path = " -> ".join(str(p) for p in visited) + f" -> {source_key}"
        msg = f"Circular reference detected: {cycle_path}"
        raise AgentCycleError(msg, current_file)

    # Parse YAML
    data = _parse_yaml_string(resolution.content, resolution.source)

    # Validate and parse with Pydantic
    try:
        spec = YamlAgentSpec.model_validate(data)
    except ValidationError as e:
        msg = f"Agent specification validation failed for {resolution.source}: {e}"
        raise AgentValidationError(msg, resolution.file_path, e) from e

    # Additional validation
    _validate_agent_spec(spec, resolution.file_path or Path(resolution.source), depth)

    # Resolve references
    visited_copy = visited.copy()
    visited_copy.add(source_key)
    resolved_spec = _resolve_agent_refs(
        spec,
        resolution.file_path or Path.cwd(),
        visited_copy,
        depth,
        resolver,
    )

    return YamlAgentDocument(spec=resolved_spec, file_path=resolution.file_path)


def _validate_agent_spec(
    spec: YamlAgentSpec,
    file_path: Path,
    depth: int,
) -> None:
    """Validate agent specification beyond Pydantic validation."""
    # Enforce global_instruction only at root level
    if depth > 0 and spec.global_instruction is not None:
        msg = "global_instruction can only be used at the root agent level"
        raise AgentValidationError(msg, file_path)


def _resolve_agent_refs(
    spec: YamlAgentSpec,
    current_file: Path,
    visited: set[Path | str],
    depth: int,
    resolver: SourceResolver,
) -> YamlAgentSpec:
    """Recursively resolve $ref references in agent specification.

    Args:
        spec: Agent specification to resolve
        current_file: Path of the current file being processed
        visited: Set of already visited sources for cycle detection
        depth: Current recursion depth
        resolver: Source resolver for loading references

    Returns:
        Agent specification with all references resolved

    Raises:
        AgentCycleError: If circular references detected
        AgentValidationError: If reference resolution fails

    """
    if depth > MAX_REF_DEPTH:
        msg = f"Maximum reference depth ({MAX_REF_DEPTH}) exceeded"
        raise AgentValidationError(msg, current_file)

    # Resolve sub_agents
    resolved_sub_agents: list[AgentRef | InlineAgentSpec] = []
    for sub_agent in spec.sub_agents:
        if isinstance(sub_agent, AgentRef):
            # Use resolver to load by identifier (name, path, or URL)
            referenced_doc = _load_agent_by_identifier(
                sub_agent.ref,
                resolver,
                current_file,
                visited,
                depth + 1,
            )
            resolved_sub_agents.append(InlineAgentSpec(agent=referenced_doc.spec))
        # Inline agent - resolve its references recursively
        elif isinstance(sub_agent, InlineAgentSpec):
            resolved_inline = _resolve_agent_refs(
                sub_agent.agent,
                current_file,
                visited,
                depth + 1,
                resolver,
            )
            resolved_sub_agents.append(InlineAgentSpec(agent=resolved_inline))
        else:
            resolved_sub_agents.append(sub_agent)

    # Resolve agent_tools
    resolved_agent_tools: list[ToolSpec | AgentRef | InlineAgentSpec] = []
    for agent_tool in spec.tools:
        if isinstance(agent_tool, AgentRef):
            # Use resolver to load by identifier (name, path, or URL)
            referenced_doc = _load_agent_by_identifier(
                agent_tool.ref,
                resolver,
                current_file,
                visited,
                depth + 1,
            )
            resolved_agent_tools.append(InlineAgentSpec(agent=referenced_doc.spec))
        # Inline agent - resolve its references recursively
        elif isinstance(agent_tool, InlineAgentSpec):
            resolved_inline = _resolve_agent_refs(
                agent_tool.agent,
                current_file,
                visited,
                depth + 1,
                resolver,
            )
            resolved_agent_tools.append(InlineAgentSpec(agent=resolved_inline))
        else:
            resolved_agent_tools.append(agent_tool)

    # Create new spec with resolved references
    return YamlAgentSpec(
        version=spec.version,
        kind=spec.kind,
        name=spec.name,
        description=spec.description,
        model=spec.model,
        instruction=spec.instruction,
        global_instruction=spec.global_instruction,
        prompt=spec.prompt,
        attributes=spec.attributes,
        adk=spec.adk,
        tools=resolved_agent_tools,
        sub_agents=resolved_sub_agents,
    )


