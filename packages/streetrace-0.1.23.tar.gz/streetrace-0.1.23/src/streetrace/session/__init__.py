"""Conversation session management module."""
