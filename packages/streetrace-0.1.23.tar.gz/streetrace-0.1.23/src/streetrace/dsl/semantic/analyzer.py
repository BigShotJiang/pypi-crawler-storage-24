"""Semantic analyzer for Streetrace DSL.

Validate AST nodes for semantic correctness including reference
resolution, variable scoping, and type checking.
"""

import re
from dataclasses import dataclass, field

from streetrace.dsl.ast.nodes import (
    AgentDef,
    Assignment,
    BinaryOp,
    CallStmt,
    DslFile,
    EventHandler,
    FlowDef,
    ForLoop,
    FunctionCall,
    IfBlock,
    ListLiteral,
    LoopBlock,
    MatchBlock,
    ModelDef,
    ObjectLiteral,
    ParallelBlock,
    PromptDef,
    PropertyAccess,
    PushStmt,
    RetryPolicyDef,
    ReturnStmt,
    RunStmt,
    SchemaDef,
    SourcePosition,
    TimeoutPolicyDef,
    ToolDef,
    UnaryOp,
    VarRef,
)
from streetrace.dsl.semantic.errors import SemanticError
from streetrace.dsl.semantic.scope import Scope, ScopeType, SymbolKind
from streetrace.log import get_logger

logger = get_logger(__name__)


# Built-in variables available in all scopes
BUILTIN_VARIABLES = frozenset({
    "input_prompt",
    "conversation",
    "current_agent",
    "session_id",
    "turn_count",
})

# Pattern to match variable references in prompt bodies: ${var} or ${var.prop}
# Bare $var is literal text and not matched.
PROMPT_VAR_PATTERN = re.compile(
    r"\$\{([a-zA-Z_][a-zA-Z0-9_]*(?:\.[a-zA-Z_][a-zA-Z0-9_]*)*)\}",
)

TYPO_SIMILARITY_THRESHOLD = 0.85
"""Minimum LCS similarity ratio to consider a variable name a likely typo."""


def _extract_prompt_variables(body: str) -> list[tuple[str, int]]:
    """Extract variable references from prompt body.

    Returns list of (base_variable_name, char_offset) tuples.
    The base variable name is the root of any property access chain.
    """
    results = []
    for match in PROMPT_VAR_PATTERN.finditer(body):
        full_ref = match.group(1)
        base_var = full_ref.split(".")[0]
        results.append((base_var, match.start()))
    return results


@dataclass
class SymbolTable:
    """Collected symbol information from analysis."""

    models: dict[str, ModelDef] = field(default_factory=dict)
    schemas: dict[str, SchemaDef] = field(default_factory=dict)
    tools: dict[str, ToolDef] = field(default_factory=dict)
    prompts: dict[str, PromptDef] = field(default_factory=dict)
    agents: dict[str, AgentDef] = field(default_factory=dict)
    flows: dict[str, FlowDef] = field(default_factory=dict)
    retry_policies: dict[str, RetryPolicyDef] = field(default_factory=dict)
    timeout_policies: dict[str, TimeoutPolicyDef] = field(default_factory=dict)


@dataclass
class AnalysisResult:
    """Result of semantic analysis."""

    is_valid: bool
    """Whether the AST passed semantic validation."""

    errors: list[SemanticError] = field(default_factory=list)
    """List of semantic errors found."""

    symbols: SymbolTable = field(default_factory=SymbolTable)
    """Collected symbol information."""


class SemanticAnalyzer:
    """Semantic analyzer for Streetrace DSL AST.

    Perform semantic validation including:
    - Reference validation (models, tools, prompts, agents)
    - Variable scoping (global, flow-local, handler-local)
    - Type checking for expressions
    - Duplicate detection
    """

    def __init__(self) -> None:
        """Initialize the semantic analyzer."""
        self._errors: list[SemanticError] = []
        self._symbols = SymbolTable()
        self._global_scope: Scope | None = None
        self._current_scope: Scope | None = None
        self._loop_depth: int = 0

    def analyze(self, ast: DslFile) -> AnalysisResult:
        """Analyze a DSL file AST for semantic correctness.

        Args:
            ast: The DslFile AST node to analyze.

        Returns:
            AnalysisResult with validation status and any errors.

        """
        self._errors = []
        self._symbols = SymbolTable()
        self._global_scope = Scope(scope_type=ScopeType.GLOBAL)
        self._current_scope = self._global_scope
        self._loop_depth = 0

        # Define built-in variables in global scope
        self._define_builtins()

        # First pass: collect all top-level definitions (prompts are merged)
        self._collect_definitions(ast)

        # Validate merged prompts have bodies
        self._validate_prompts_have_bodies()

        # Second pass: validate references and scoping
        self._validate_references(ast)

        # Third pass: validate instruction prompts don't use runtime variables
        self._validate_instruction_prompts()

        # Validation passes if there are no actual errors (warnings don't fail)
        actual_errors = [e for e in self._errors if not e.is_warning]
        return AnalysisResult(
            is_valid=len(actual_errors) == 0,
            errors=self._errors,
            symbols=self._symbols,
        )

    def _define_builtins(self) -> None:
        """Define built-in variables in global scope."""
        if self._global_scope is None:
            return

        for name in BUILTIN_VARIABLES:
            self._global_scope.define(
                name=name,
                kind=SymbolKind.VARIABLE,
                type_info="builtin",
            )

    def _collect_definitions(self, ast: DslFile) -> None:
        """Collect all top-level definitions from the AST.

        Args:
            ast: The DslFile AST node.

        """
        for stmt in ast.statements:
            self._collect_definition(stmt)

    def _collect_definition(self, stmt: object) -> None:
        """Collect a single top-level definition.

        Args:
            stmt: The statement to collect.

        """
        if isinstance(stmt, ModelDef):
            self._collect_model(stmt)
        elif isinstance(stmt, SchemaDef):
            self._collect_schema(stmt)
        elif isinstance(stmt, ToolDef):
            self._collect_tool(stmt)
        elif isinstance(stmt, PromptDef):
            self._collect_prompt(stmt)
        elif isinstance(stmt, AgentDef):
            self._collect_agent(stmt)
        elif isinstance(stmt, (FlowDef, RetryPolicyDef, TimeoutPolicyDef)):
            self._collect_flow_or_policy(stmt)

    def _collect_model(self, model: ModelDef) -> None:
        """Collect a model definition."""
        if model.name in self._symbols.models:
            self._add_error(
                SemanticError.duplicate_definition(
                    kind="model",
                    name=model.name,
                    position=model.meta,
                ),
            )
            return
        self._symbols.models[model.name] = model
        if self._global_scope is not None:
            self._global_scope.define(
                name=model.name,
                kind=SymbolKind.MODEL,
                node=model,
            )

    def _collect_schema(self, schema: SchemaDef) -> None:
        """Collect a schema definition."""
        if schema.name in self._symbols.schemas:
            self._add_error(
                SemanticError.duplicate_definition(
                    kind="schema",
                    name=schema.name,
                    position=schema.meta,
                ),
            )
            return
        self._symbols.schemas[schema.name] = schema
        if self._global_scope is not None:
            self._global_scope.define(
                name=schema.name,
                kind=SymbolKind.SCHEMA,
                node=schema,
            )

    def _collect_tool(self, tool: ToolDef) -> None:
        """Collect a tool definition."""
        if tool.name in self._symbols.tools:
            self._add_error(
                SemanticError.duplicate_definition(
                    kind="tool",
                    name=tool.name,
                    position=tool.meta,
                ),
            )
            return
        self._symbols.tools[tool.name] = tool
        if self._global_scope is not None:
            self._global_scope.define(
                name=tool.name,
                kind=SymbolKind.TOOL,
                node=tool,
            )

    def _collect_prompt(self, prompt: PromptDef) -> None:
        """Collect a prompt definition, merging with existing definition if present.

        Support the override pattern where prompts can be defined multiple times:
        - Declarations (no body) define metadata at top of file
        - Full definitions (with body) define prompt text at bottom
        - Multiple definitions are merged following these rules:
          - body: later non-empty body overwrites
          - model, expecting, inherit: fill if not set, error if conflicting
          - escalation_condition: later non-None overwrites
        """
        if prompt.name not in self._symbols.prompts:
            # First definition - store as-is
            self._symbols.prompts[prompt.name] = prompt
            if self._global_scope is not None:
                self._global_scope.define(
                    name=prompt.name,
                    kind=SymbolKind.PROMPT,
                    node=prompt,
                )
            return

        # Merge with existing definition
        existing = self._symbols.prompts[prompt.name]
        merged = self._merge_prompts(existing, prompt)
        if merged is not None:
            self._symbols.prompts[prompt.name] = merged
            # Update scope node reference
            if self._global_scope is not None:
                self._global_scope.define(
                    name=prompt.name,
                    kind=SymbolKind.PROMPT,
                    node=merged,
                )

    def _merge_prompts(
        self,
        existing: PromptDef,
        new: PromptDef,
    ) -> PromptDef | None:
        """Merge two prompt definitions.

        Args:
            existing: The existing prompt definition.
            new: The new prompt definition to merge.

        Returns:
            Merged PromptDef, or None if merge failed due to conflicts.

        """
        # Check for modifier conflicts
        if not self._check_prompt_modifier_conflict(
            existing, new, "model", existing.model, new.model,
        ):
            return None
        if not self._check_prompt_modifier_conflict(
            existing, new, "expecting", existing.expecting, new.expecting,
        ):
            return None
        if not self._check_prompt_modifier_conflict(
            existing, new, "inherit", existing.inherit, new.inherit,
        ):
            return None

        # Merge: later non-empty values overwrite
        merged_body = new.body if new.body else existing.body
        merged_model = new.model if new.model else existing.model
        merged_expecting = new.expecting if new.expecting else existing.expecting
        merged_inherit = new.inherit if new.inherit else existing.inherit
        merged_escalation = (
            new.escalation_condition
            if new.escalation_condition
            else existing.escalation_condition
        )

        # Use the position of the definition with body, or the later one
        merged_meta = new.meta if new.body else existing.meta

        return PromptDef(
            name=existing.name,
            body=merged_body,
            model=merged_model,
            expecting=merged_expecting,
            inherit=merged_inherit,
            escalation_condition=merged_escalation,
            meta=merged_meta,
        )

    def _check_prompt_modifier_conflict(
        self,
        _existing: PromptDef,
        new: PromptDef,
        modifier_name: str,
        existing_value: str | None,
        new_value: str | None,
    ) -> bool:
        """Check if two prompt modifier values conflict.

        Args:
            _existing: The existing prompt definition (unused, for context).
            new: The new prompt definition.
            modifier_name: Name of the modifier being checked.
            existing_value: Value from existing definition.
            new_value: Value from new definition.

        Returns:
            True if no conflict, False if conflict (error added).

        """
        if existing_value and new_value and existing_value != new_value:
            self._add_error(
                SemanticError.conflicting_prompt_modifier(
                    name=new.name,
                    modifier=modifier_name,
                    first=existing_value,
                    second=new_value,
                    position=new.meta,
                ),
            )
            return False
        return True

    def _validate_prompts_have_bodies(self) -> None:
        """Validate that all prompts have bodies after merging.

        Report E0013 error for any prompt that has no body definition.
        This catches cases where only declarations exist without a full definition.
        """
        for name, prompt in self._symbols.prompts.items():
            if not prompt.body:
                self._add_error(
                    SemanticError.prompt_missing_body(
                        name=name,
                        position=prompt.meta,
                    ),
                )

    def _collect_agent(self, agent: AgentDef) -> None:
        """Collect an agent definition."""
        name = agent.name or "default"
        if name in self._symbols.agents:
            self._add_error(
                SemanticError.duplicate_definition(
                    kind="agent",
                    name=name,
                    position=agent.meta,
                ),
            )
            return
        self._symbols.agents[name] = agent
        if self._global_scope is not None:
            self._global_scope.define(
                name=name,
                kind=SymbolKind.AGENT,
                node=agent,
            )

    def _collect_flow_or_policy(
        self,
        stmt: FlowDef | RetryPolicyDef | TimeoutPolicyDef,
    ) -> None:
        """Collect a flow or policy definition.

        Args:
            stmt: Flow or policy definition to collect.

        """
        if isinstance(stmt, FlowDef):
            self._collect_flow(stmt)
        elif isinstance(stmt, RetryPolicyDef):
            self._collect_retry_policy(stmt)
        elif isinstance(stmt, TimeoutPolicyDef):
            self._collect_timeout_policy(stmt)

    def _collect_flow(self, flow: FlowDef) -> None:
        """Collect a flow definition."""
        if flow.name in self._symbols.flows:
            self._add_error(
                SemanticError.duplicate_definition(
                    kind="flow",
                    name=flow.name,
                    position=flow.meta,
                ),
            )
            return
        self._symbols.flows[flow.name] = flow
        if self._global_scope is not None:
            self._global_scope.define(
                name=flow.name,
                kind=SymbolKind.FLOW,
                node=flow,
            )

    def _collect_retry_policy(self, policy: RetryPolicyDef) -> None:
        """Collect a retry policy definition."""
        if policy.name in self._symbols.retry_policies:
            self._add_error(
                SemanticError.duplicate_definition(
                    kind="retry policy",
                    name=policy.name,
                    position=policy.meta,
                ),
            )
            return
        self._symbols.retry_policies[policy.name] = policy
        if self._global_scope is not None:
            self._global_scope.define(
                name=policy.name,
                kind=SymbolKind.RETRY_POLICY,
                node=policy,
            )

    def _collect_timeout_policy(self, policy: TimeoutPolicyDef) -> None:
        """Collect a timeout policy definition."""
        if policy.name in self._symbols.timeout_policies:
            self._add_error(
                SemanticError.duplicate_definition(
                    kind="timeout policy",
                    name=policy.name,
                    position=policy.meta,
                ),
            )
            return
        self._symbols.timeout_policies[policy.name] = policy
        if self._global_scope is not None:
            self._global_scope.define(
                name=policy.name,
                kind=SymbolKind.TIMEOUT_POLICY,
                node=policy,
            )

    def _validate_references(self, ast: DslFile) -> None:
        """Validate all references in the AST.

        Args:
            ast: The DslFile AST node.

        """
        for stmt in ast.statements:
            if isinstance(stmt, PromptDef):
                self._validate_prompt_refs(stmt)
            elif isinstance(stmt, AgentDef):
                self._validate_agent_refs(stmt)
            elif isinstance(stmt, FlowDef):
                self._validate_flow(stmt)
            elif isinstance(stmt, EventHandler):
                self._validate_event_handler(stmt)

        # After validating all individual references, detect circular references
        self._detect_circular_agent_refs()

    def _validate_prompt_refs(self, prompt: PromptDef) -> None:
        """Validate references in a prompt definition."""
        # Check model reference if specified
        if prompt.model is not None and prompt.model not in self._symbols.models:
            self._add_error(
                SemanticError.undefined_reference(
                    kind="model",
                    name=prompt.model,
                    position=prompt.meta,
                    suggestion=self._suggest_similar("model", prompt.model),
                ),
            )

        # Check expecting (schema) reference if specified
        # Strip [] suffix for array types before validating schema reference
        if prompt.expecting is not None:
            schema_name = prompt.expecting.rstrip("[]")
            if schema_name not in self._symbols.schemas:
                self._add_error(
                    SemanticError.undefined_reference(
                        kind="schema",
                        name=schema_name,
                        position=prompt.meta,
                    ),
                )

        # Validate variable references in body
        self._validate_prompt_body_vars(prompt)

    def _validate_prompt_body_vars(self, prompt: PromptDef) -> None:
        """Validate variable references in prompt body.

        Every ``${var}`` must resolve to a known symbol: a builtin
        variable, another prompt name, an agent ``produces`` name, or
        a variable assigned anywhere in a flow.  Unknown references
        are errors.
        """
        if not prompt.body:
            return

        vars_in_body = _extract_prompt_variables(prompt.body)

        for var_name, char_offset in vars_in_body:
            if self._is_valid_prompt_var(var_name):
                continue

            # Check if this looks like a typo of a known symbol
            typo_suggestion = self._find_likely_typo(var_name)
            self._add_error(
                SemanticError.undefined_prompt_variable(
                    prompt=prompt.name,
                    name=var_name,
                    position=self._calc_var_position(prompt, char_offset),
                    suggestion=typo_suggestion,
                ),
            )

    def _is_valid_prompt_var(self, var_name: str) -> bool:
        """Check if variable is valid in prompt context.

        A variable is valid if it is:
        - A built-in variable (input_prompt, conversation, etc.)
        - Another prompt name (for composition)
        - An agent produces name (becomes variable at runtime)
        - A variable assigned in any flow (set, for, run target)
        """
        if var_name in BUILTIN_VARIABLES:
            return True
        if var_name in self._symbols.prompts:
            return True
        if self._is_known_produces_name(var_name):
            return True
        return self._is_known_flow_var(var_name)

    def _find_likely_typo(self, name: str) -> str | None:
        """Find if a variable name is likely a typo of a known symbol.

        Use string similarity to detect likely typos. Only return a
        suggestion if there's a very strong match indicating a typo.
        """
        candidates = list(BUILTIN_VARIABLES)
        candidates.extend(self._symbols.prompts.keys())
        candidates.extend(
            a.produces for a in self._symbols.agents.values() if a.produces
        )
        candidates.extend(self._collect_all_flow_var_names())

        name_lower = name.lower()
        best_match = None
        best_score = 0.0

        for candidate in candidates:
            candidate_lower = candidate.lower()
            score = self._similarity_score(name_lower, candidate_lower)
            if score > best_score:
                best_score = score
                best_match = candidate

        # Only suggest if very high similarity (likely typo)
        if best_score >= TYPO_SIMILARITY_THRESHOLD and best_match is not None:
            return f"did you mean '${{{best_match}}}'?"

        return None

    def _collect_all_flow_var_names(self) -> list[str]:
        """Collect all variable names assigned in any flow.

        Returns:
            List of variable names from assignments, run targets, etc.

        """
        from streetrace.dsl.ast.nodes import (
            Assignment,
            CallStmt,
            ForLoop,
            IfBlock,
            LoopBlock,
            ParallelBlock,
            RunStmt,
        )

        names: list[str] = []

        def _walk(stmts: list[object]) -> None:
            for stmt in stmts:
                if isinstance(stmt, Assignment):
                    names.append(stmt.target)
                elif isinstance(stmt, (RunStmt, CallStmt)):
                    if stmt.target is not None:
                        names.append(stmt.target)
                elif isinstance(stmt, ForLoop):
                    names.append(stmt.variable)
                    _walk(stmt.body)
                if isinstance(stmt, (ParallelBlock, LoopBlock, IfBlock)):
                    _walk(stmt.body)

        for flow in self._symbols.flows.values():
            names.extend(flow.params)
            _walk(flow.body)

        return names

    def _similarity_score(self, s1: str, s2: str) -> float:
        """Compute similarity score between two strings.

        Returns a value between 0 and 1 where 1 means identical.
        Uses a simple algorithm based on longest common subsequence.
        """
        if s1 == s2:
            return 1.0
        if not s1 or not s2:
            return 0.0

        # Use length of longest common subsequence ratio
        lcs_len = self._lcs_length(s1, s2)
        max_len = max(len(s1), len(s2))
        return lcs_len / max_len

    def _lcs_length(self, s1: str, s2: str) -> int:
        """Compute length of longest common subsequence."""
        m, n = len(s1), len(s2)
        # Use 1D DP for space efficiency
        prev = [0] * (n + 1)
        curr = [0] * (n + 1)

        for i in range(1, m + 1):
            for j in range(1, n + 1):
                if s1[i - 1] == s2[j - 1]:
                    curr[j] = prev[j - 1] + 1
                else:
                    curr[j] = max(prev[j], curr[j - 1])
            prev, curr = curr, prev

        return prev[n]

    def _calc_var_position(
        self,
        prompt: PromptDef,
        char_offset: int,
    ) -> SourcePosition | None:
        """Calculate position of variable within prompt body.

        Walk through the prompt body counting lines and columns to
        find the position of the variable reference.
        """
        if prompt.meta is None or not prompt.body:
            return prompt.meta

        line = prompt.meta.line
        col = prompt.meta.column
        for i, char in enumerate(prompt.body):
            if i >= char_offset:
                break
            if char == "\n":
                line += 1
                col = 1
            else:
                col += 1
        return SourcePosition(line=line, column=col)

    def _validate_instruction_prompts(self) -> None:
        """Validate that instruction prompts don't use runtime variables.

        Instruction prompts are resolved at agent creation time when
        runtime variables (produces, flow variables, loop variables) are
        not yet available. Only prompt composition is allowed.
        """
        for agent_name, agent in self._symbols.agents.items():
            if not agent.instruction:
                continue

            prompt = self._symbols.prompts.get(agent.instruction)
            if prompt is None or not prompt.body:
                continue

            self._validate_instruction_body(prompt, agent_name)

    def _validate_instruction_body(
        self,
        prompt: PromptDef,
        agent_name: str,
    ) -> None:
        """Validate an instruction prompt body for runtime variables.

        Args:
            prompt: The instruction prompt definition.
            agent_name: Name of the agent using this instruction.

        """
        vars_in_body = _extract_prompt_variables(prompt.body)

        for var_name, char_offset in vars_in_body:
            # Prompt composition is allowed - referencing other prompts
            if var_name in self._symbols.prompts:
                continue

            # Any other variable is a runtime variable (not available at creation)
            self._add_error(
                SemanticError.instruction_runtime_variable(
                    prompt=prompt.name,
                    name=var_name,
                    agent=agent_name,
                    position=self._calc_var_position(prompt, char_offset),
                ),
            )

    def _validate_agent_refs(self, agent: AgentDef) -> None:
        """Validate references in an agent definition."""
        agent_name = agent.name or "default"

        self._validate_agent_instruction(agent, agent_name)
        self._validate_agent_prompt_ref(agent)
        self._validate_agent_tool_refs(agent)
        self._validate_agent_policy_refs(agent)
        self._validate_agent_delegate_refs(agent, agent_name)

    def _validate_agent_instruction(
        self,
        agent: AgentDef,
        agent_name: str,
    ) -> None:
        """Validate agent instruction property."""
        if not agent.instruction:
            suggestion = (
                "add 'instruction <prompt_name>' to specify the agent's "
                "instruction prompt"
            )
            self._add_error(
                SemanticError.missing_required_property(
                    kind="agent",
                    name=agent_name,
                    prop="instruction",
                    position=agent.meta,
                    suggestion=suggestion,
                ),
            )

    def _validate_agent_prompt_ref(self, agent: AgentDef) -> None:
        """Validate agent prompt field references a defined prompt or variable.

        The agent prompt field is resolved at runtime via ctx.resolve(),
        which checks ctx.vars first then prompt definitions. Accept:
        - Defined prompt names
        - Built-in variables (e.g. input_prompt)
        - Produces names from other agents (become variables at runtime)
        """
        if agent.prompt is None:
            return
        if agent.prompt in self._symbols.prompts:
            return
        if agent.prompt in BUILTIN_VARIABLES:
            return
        if self._is_known_produces_name(agent.prompt):
            return
        self._add_error(
            SemanticError.undefined_reference(
                kind="prompt or variable",
                name=agent.prompt,
                position=agent.prompt_meta or agent.meta,
                suggestion=self._suggest_prompt_or_variable(agent.prompt),
            ),
        )

    def _validate_agent_tool_refs(self, agent: AgentDef) -> None:
        """Validate agent tool references."""
        for tool_name in agent.tools:
            if tool_name not in self._symbols.tools:
                self._add_error(
                    SemanticError.undefined_reference(
                        kind="tool",
                        name=tool_name,
                        position=agent.meta,
                        suggestion=self._suggest_similar("tool", tool_name),
                    ),
                )

    def _validate_agent_policy_refs(self, agent: AgentDef) -> None:
        """Validate agent retry and timeout policy references."""
        if agent.retry is not None and agent.retry not in self._symbols.retry_policies:
            self._add_error(
                SemanticError.undefined_reference(
                    kind="retry policy",
                    name=agent.retry,
                    position=agent.meta,
                ),
            )

        if (
            agent.timeout_ref is not None
            and agent.timeout_ref not in self._symbols.timeout_policies
        ):
            self._add_error(
                SemanticError.undefined_reference(
                    kind="timeout policy",
                    name=agent.timeout_ref,
                    position=agent.meta,
                ),
            )

    def _validate_agent_delegate_refs(
        self,
        agent: AgentDef,
        agent_name: str,
    ) -> None:
        """Validate agent delegate and use references."""
        # Check delegate references
        if agent.delegate:
            for delegate_name in agent.delegate:
                if delegate_name not in self._symbols.agents:
                    self._add_error(
                        SemanticError.undefined_reference(
                            kind="agent",
                            name=delegate_name,
                            position=agent.meta,
                            suggestion=self._suggest_similar("agent", delegate_name),
                        ),
                    )

        # Check use references
        if agent.use:
            for use_name in agent.use:
                if use_name not in self._symbols.agents:
                    self._add_error(
                        SemanticError.undefined_reference(
                            kind="agent",
                            name=use_name,
                            position=agent.meta,
                            suggestion=self._suggest_similar("agent", use_name),
                        ),
                    )

        # Warn if agent has both delegate and use
        if agent.delegate and agent.use:
            self._add_error(
                SemanticError.agent_has_both_delegate_and_use(
                    name=agent_name,
                    position=agent.meta,
                ),
            )

    def _validate_flow(self, flow: FlowDef) -> None:
        """Validate a flow definition including scoping."""
        # Create flow scope
        flow_scope = Scope(
            scope_type=ScopeType.FLOW,
            parent=self._global_scope,
        )

        # Flows read from ambient context (ctx.vars) -- no parameter scope
        self._validate_statements(flow.body, flow_scope)

    def _validate_event_handler(self, handler: EventHandler) -> None:
        """Validate an event handler."""
        # Check if this is an "on start" handler - defines global vars
        is_start_handler = handler.timing == "on" and handler.event_type == "start"

        if is_start_handler:
            # Variables defined in on start are global
            scope = self._global_scope
        else:
            # Create handler scope
            scope = Scope(
                scope_type=ScopeType.HANDLER,
                parent=self._global_scope,
            )

        if scope is not None:
            self._validate_statements(handler.body, scope)

    def _validate_statements(self, stmts: list[object], scope: Scope) -> None:
        """Validate a list of statements with given scope.

        Args:
            stmts: List of AST statement nodes.
            scope: Current scope for variable resolution.

        """
        for stmt in stmts:
            self._validate_statement(stmt, scope)

    def _validate_statement(self, stmt: object, scope: Scope) -> None:
        """Validate a single statement.

        Args:
            stmt: AST statement node.
            scope: Current scope for variable resolution.

        """
        if isinstance(stmt, Assignment):
            self._validate_assignment(stmt, scope)
        elif isinstance(stmt, RunStmt):
            self._validate_run_stmt(stmt, scope)
        elif isinstance(stmt, CallStmt):
            self._validate_call_stmt(stmt, scope)
        elif isinstance(stmt, (ReturnStmt, PushStmt)):
            self._validate_return_or_push(stmt, scope)
        elif isinstance(stmt, (ForLoop, IfBlock, MatchBlock, ParallelBlock, LoopBlock)):
            self._validate_control_flow(stmt, scope)
        # Guardrail actions and other statements don't need special handling

    def _validate_assignment(self, stmt: Assignment, scope: Scope) -> None:
        """Validate an assignment statement."""
        self._validate_expression(stmt.value, scope)
        scope.define(name=stmt.target, kind=SymbolKind.VARIABLE)

    def _validate_run_stmt(self, stmt: RunStmt, scope: Scope) -> None:
        """Validate a run statement for agents or flows."""
        if stmt.is_flow:
            # Validate flow call
            if stmt.agent not in self._symbols.flows:
                self._add_error(
                    SemanticError.undefined_reference(
                        kind="flow",
                        name=stmt.agent,
                        position=stmt.meta,
                        suggestion=self._suggest_similar("flow", stmt.agent),
                    ),
                )
        elif stmt.agent not in self._symbols.agents:
            # Validate agent call
            self._add_error(
                SemanticError.undefined_reference(
                    kind="agent",
                    name=stmt.agent,
                    position=stmt.meta,
                    suggestion=self._suggest_similar("agent", stmt.agent),
                ),
            )
        if stmt.input is not None:
            self._validate_expression(stmt.input, scope)
        if stmt.target is not None:
            scope.define(name=stmt.target, kind=SymbolKind.VARIABLE)
        elif not stmt.is_flow:
            # Auto-define produces variable when agent has produces field
            agent_def = self._symbols.agents.get(stmt.agent)
            if agent_def and agent_def.produces:
                scope.define(name=agent_def.produces, kind=SymbolKind.VARIABLE)
        # Validate escalation handler context
        self._validate_escalation_handler(stmt)

    def _validate_escalation_handler(self, stmt: RunStmt) -> None:
        """Validate escalation handler context for run statements.

        Check that 'on escalate continue' is only used inside a loop context.

        Args:
            stmt: RunStmt node with potential escalation handler.

        """
        if stmt.escalation_handler is None:
            return

        handler = stmt.escalation_handler
        if handler.action == "continue" and self._loop_depth == 0:
            # Get position from handler if available, otherwise from statement
            position = handler.meta if handler.meta else stmt.meta
            self._add_error(
                SemanticError.continue_outside_loop(position=position),
            )

    def _validate_call_stmt(self, stmt: CallStmt, scope: Scope) -> None:
        """Validate a call LLM statement."""
        if stmt.prompt not in self._symbols.prompts:
            self._add_error(
                SemanticError.undefined_reference(
                    kind="prompt",
                    name=stmt.prompt,
                    position=stmt.meta,
                    suggestion=self._suggest_similar("prompt", stmt.prompt),
                ),
            )
        if stmt.model is not None and stmt.model not in self._symbols.models:
            self._add_error(
                SemanticError.undefined_reference(
                    kind="model",
                    name=stmt.model,
                    position=stmt.meta,
                ),
            )
        if stmt.input is not None:
            self._validate_expression(stmt.input, scope)
        if stmt.target is not None:
            scope.define(name=stmt.target, kind=SymbolKind.VARIABLE)

    def _validate_return_or_push(
        self,
        stmt: ReturnStmt | PushStmt,
        scope: Scope,
    ) -> None:
        """Validate return or push statements."""
        if isinstance(stmt, ReturnStmt):
            self._validate_expression(stmt.value, scope)
        elif isinstance(stmt, PushStmt):
            self._validate_expression(stmt.value, scope)
            if scope.lookup(stmt.target) is None:
                self._add_error(
                    SemanticError.undefined_variable(
                        name=stmt.target,
                        position=stmt.meta,
                    ),
                )

    def _validate_control_flow(
        self,
        stmt: ForLoop | IfBlock | MatchBlock | ParallelBlock | LoopBlock,
        scope: Scope,
    ) -> None:
        """Validate control flow statements."""
        if isinstance(stmt, ForLoop):
            self._validate_for_loop(stmt, scope)
        elif isinstance(stmt, IfBlock):
            self._validate_if_block(stmt, scope)
        elif isinstance(stmt, MatchBlock):
            self._validate_match_block(stmt, scope)
        elif isinstance(stmt, ParallelBlock):
            self._validate_statements(stmt.body, scope)
        elif isinstance(stmt, LoopBlock):
            self._validate_loop_block(stmt, scope)

    def _validate_for_loop(self, stmt: ForLoop, scope: Scope) -> None:
        """Validate a for loop statement."""
        block_scope = Scope(scope_type=ScopeType.BLOCK, parent=scope)
        block_scope.define(name=stmt.variable, kind=SymbolKind.VARIABLE)
        self._validate_expression(stmt.iterable, scope)
        self._loop_depth += 1
        try:
            self._validate_statements(stmt.body, block_scope)
        finally:
            self._loop_depth -= 1

    def _validate_if_block(self, stmt: IfBlock, scope: Scope) -> None:
        """Validate an if block statement."""
        self._validate_expression(stmt.condition, scope)
        block_scope = Scope(scope_type=ScopeType.BLOCK, parent=scope)
        self._validate_statements(stmt.body, block_scope)

    def _validate_match_block(self, stmt: MatchBlock, scope: Scope) -> None:
        """Validate a match block statement."""
        self._validate_expression(stmt.expression, scope)
        for case in stmt.cases:
            case_scope = Scope(scope_type=ScopeType.BLOCK, parent=scope)
            if hasattr(case, "body") and isinstance(case.body, list):
                self._validate_statements(case.body, case_scope)
        if stmt.else_body is not None:
            else_scope = Scope(scope_type=ScopeType.BLOCK, parent=scope)
            if isinstance(stmt.else_body, list):
                self._validate_statements(stmt.else_body, else_scope)

    def _validate_loop_block(self, stmt: LoopBlock, scope: Scope) -> None:
        """Validate a loop block statement.

        Args:
            stmt: LoopBlock AST node.
            scope: Current scope for variable resolution.

        """
        block_scope = Scope(scope_type=ScopeType.BLOCK, parent=scope)
        self._loop_depth += 1
        try:
            self._validate_statements(stmt.body, block_scope)
        finally:
            self._loop_depth -= 1

    def _detect_circular_agent_refs(self) -> None:
        """Detect circular references in agent delegate/use relationships.

        Build a directed graph of agent relationships and use DFS to detect
        cycles. Report E0011 error for any circular agent references found.
        """
        graph = self._build_agent_graph()
        cycle = self._find_cycle_in_graph(graph)
        if cycle is not None:
            first_agent = self._symbols.agents.get(cycle[0])
            position = first_agent.meta if first_agent else None
            self._add_error(
                SemanticError.circular_agent_reference(
                    agents=cycle,
                    position=position,
                ),
            )

    def _build_agent_graph(self) -> dict[str, list[str]]:
        """Build adjacency list for agent delegate/use relationships.

        Self-references via ``use`` are filtered out because the ``use``
        pattern wraps an agent as an AgentTool — the LLM chooses when to
        call it, providing natural recursion termination.  Self-references
        via ``delegate`` remain in the graph because delegate transfers
        control unconditionally and is harder to bound.

        Returns:
            Dictionary mapping agent names to their referenced agents.

        """
        graph: dict[str, list[str]] = {}
        for agent_name, agent in self._symbols.agents.items():
            neighbors: list[str] = []
            if agent.delegate:
                neighbors.extend(agent.delegate)
            if agent.use:
                neighbors.extend(
                    name for name in agent.use if name != agent_name
                )
            graph[agent_name] = neighbors
        return graph

    def _find_cycle_in_graph(
        self,
        graph: dict[str, list[str]],
    ) -> list[str] | None:
        """Find a cycle in the agent dependency graph using DFS.

        Args:
            graph: Adjacency list of agent relationships.

        Returns:
            List of agents forming a cycle, or None if no cycle found.

        """
        visited: set[str] = set()
        rec_stack: set[str] = set()

        for agent_name in self._symbols.agents:
            if agent_name not in visited:
                cycle = self._dfs_find_cycle(
                    agent_name,
                    graph,
                    visited,
                    rec_stack,
                    [],
                )
                if cycle is not None:
                    return cycle
        return None

    def _dfs_find_cycle(
        self,
        node: str,
        graph: dict[str, list[str]],
        visited: set[str],
        rec_stack: set[str],
        path: list[str],
    ) -> list[str] | None:
        """DFS helper to find cycles in agent graph.

        Args:
            node: Current node being visited.
            graph: Adjacency list of agent relationships.
            visited: Set of fully visited nodes.
            rec_stack: Set of nodes in current recursion stack.
            path: Current path from root.

        Returns:
            List of agents forming a cycle, or None if no cycle found.

        """
        if node in rec_stack:
            cycle_start = path.index(node)
            return [*path[cycle_start:], node]

        if node in visited:
            return None

        visited.add(node)
        rec_stack.add(node)
        path.append(node)

        for neighbor in graph.get(node, []):
            if neighbor in self._symbols.agents:
                cycle = self._dfs_find_cycle(
                    neighbor,
                    graph,
                    visited,
                    rec_stack,
                    path,
                )
                if cycle is not None:
                    return cycle

        path.pop()
        rec_stack.remove(node)
        return None

    def _validate_expression(self, expr: object, scope: Scope) -> None:
        """Validate an expression.

        Args:
            expr: AST expression node.
            scope: Current scope for variable resolution.

        """
        if isinstance(expr, VarRef):
            self._validate_var_ref(expr, scope)
        elif isinstance(expr, PropertyAccess):
            self._validate_expression(expr.base, scope)
        elif isinstance(expr, (BinaryOp, UnaryOp)):
            self._validate_binary_or_unary(expr, scope)
        elif isinstance(expr, (FunctionCall, ListLiteral, ObjectLiteral)):
            self._validate_compound_expr(expr, scope)
        # Literals are always valid - no validation needed

    def _validate_var_ref(self, expr: VarRef, scope: Scope) -> None:
        """Validate a variable reference."""
        if scope.lookup(expr.name) is None:
            self._add_error(
                SemanticError.undefined_variable(
                    name=expr.name,
                    position=expr.meta,
                ),
            )

    def _validate_binary_or_unary(
        self,
        expr: BinaryOp | UnaryOp,
        scope: Scope,
    ) -> None:
        """Validate binary or unary operations."""
        if isinstance(expr, BinaryOp):
            self._validate_expression(expr.left, scope)
            self._validate_expression(expr.right, scope)
        elif isinstance(expr, UnaryOp):
            self._validate_expression(expr.operand, scope)

    def _validate_compound_expr(
        self,
        expr: FunctionCall | ListLiteral | ObjectLiteral,
        scope: Scope,
    ) -> None:
        """Validate compound expressions with child elements."""
        if isinstance(expr, FunctionCall):
            for arg in expr.args:
                self._validate_expression(arg, scope)
        elif isinstance(expr, ListLiteral):
            for elem in expr.elements:
                self._validate_expression(elem, scope)
        elif isinstance(expr, ObjectLiteral):
            for value in expr.entries.values():
                self._validate_expression(value, scope)

    def _add_error(self, error: SemanticError) -> None:
        """Add an error to the error list.

        Args:
            error: The semantic error to add.

        """
        self._errors.append(error)
        logger.debug("Semantic error: %s", error.message)

    def _suggest_similar(self, kind: str, name: str) -> str | None:
        """Suggest similar names for an undefined reference.

        Args:
            kind: Kind of reference (model, tool, etc.).
            name: Name that was not found.

        Returns:
            Suggestion string or None.

        """
        candidates: list[str] = []
        if kind == "model":
            candidates = list(self._symbols.models.keys())
        elif kind == "tool":
            candidates = list(self._symbols.tools.keys())
        elif kind == "prompt":
            candidates = list(self._symbols.prompts.keys())
        elif kind == "agent":
            candidates = list(self._symbols.agents.keys())
        elif kind == "flow":
            candidates = list(self._symbols.flows.keys())

        if not candidates:
            return None

        # Simple similarity check - could be improved with Levenshtein
        for candidate in candidates:
            if candidate.lower().startswith(name.lower()[:3]):
                return f"did you mean '{candidate}'?"

        if candidates:
            return f"defined {kind}s are: {', '.join(candidates)}"

        return None

    def _is_known_produces_name(self, name: str) -> bool:
        """Check if a name matches any agent's produces field.

        Args:
            name: Name to check.

        Returns:
            True if any agent produces this name.

        """
        return any(
            a.produces == name
            for a in self._symbols.agents.values()
        )

    def _is_known_flow_var(self, name: str) -> bool:
        """Check if a name is assigned in any flow.

        Collect variables from assignments, run targets, call targets,
        and for-loop iterators across all flows.

        Args:
            name: Variable name to check.

        Returns:
            True if the name is defined in any flow scope.

        """
        for flow in self._symbols.flows.values():
            if name in flow.params:
                return True
            if self._flow_body_defines_var(flow.body, name):
                return True
        return False

    def _flow_body_defines_var(
        self,
        stmts: list[object],
        name: str,
    ) -> bool:
        """Recursively check if a statement list defines a variable.

        Walk into nested blocks (parallel, if, loop, for) to find
        assignments at any depth.

        Args:
            stmts: List of AST statement nodes.
            name: Variable name to search for.

        Returns:
            True if any statement defines the variable.

        """
        from streetrace.dsl.ast.nodes import (
            Assignment,
            CallStmt,
            ForLoop,
            IfBlock,
            LoopBlock,
            ParallelBlock,
            RunStmt,
        )

        for stmt in stmts:
            if (
                isinstance(stmt, (Assignment, RunStmt, CallStmt))
                and stmt.target == name
            ):
                return True
            if isinstance(stmt, ForLoop) and (
                stmt.variable == name
                or self._flow_body_defines_var(stmt.body, name)
            ):
                return True
            if isinstance(
                stmt, (ParallelBlock, LoopBlock, IfBlock),
            ) and self._flow_body_defines_var(stmt.body, name):
                return True
        return False

    def _suggest_prompt_or_variable(self, name: str) -> str | None:
        """Suggest similar prompts or variable names.

        Combine prompt names, built-in variables, and produces names
        as candidates for suggestions.

        Args:
            name: Name that was not found.

        Returns:
            Suggestion string or None.

        """
        candidates = list(self._symbols.prompts.keys())
        candidates.extend(BUILTIN_VARIABLES)
        candidates.extend(
            a.produces for a in self._symbols.agents.values() if a.produces
        )
        for candidate in candidates:
            if candidate.lower().startswith(name.lower()[:3]):
                return f"did you mean '{candidate}'?"
        if candidates:
            return (
                f"defined prompts are: "
                f"{', '.join(self._symbols.prompts.keys())}"
            )
        return None
