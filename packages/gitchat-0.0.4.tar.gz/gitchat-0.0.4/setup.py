from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="gitchat",
    version="0.0.4",
    author="Shkvaldev",
    author_email="shkvalgrozny@gmail.com",
    description="Proof-of-work realtime chat, using only `git` as a transport",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/Shkvaldev/gitchat",
    packages=find_packages(exclude=["__pycache__", "*.pyc"]),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.12",
    include_package_data=True,
    install_requires=["loguru", "pycryptodomex"],
    entry_points={
        "console_scripts": ["gitchat=gitchat.cli:main"],
    },
)
