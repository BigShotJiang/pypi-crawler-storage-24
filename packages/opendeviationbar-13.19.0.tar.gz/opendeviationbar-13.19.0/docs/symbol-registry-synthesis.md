# Cross-Cutting Synthesis: Symbol Registry Integration

**Task:** task-18 - Cross-Cutting Synthesis and Resolution Strategy  
**Generated:** 2026-03-12  
**Author:** IronMoon (crew-worker)  

---

## Executive Summary

This synthesis aggregates findings from the Symbol Registry integration audit and proposes a phased resolution strategy. The audit identified **45+ locations** with hardcoded threshold values and multiple categories of hardcoded values that should be sourced from the Symbol Registry (`symbols.toml`).

**Status of Audit Tasks:**
- ✅ Completed: task-13, task-19, task-20, task-21, task-22, task-23, task-24, task-25, task-28, task-29
- 🚫 Blocked: task-10 (Python Constants), task-11 (CLI/Tools), task-12 (ClickHouse Cache), task-14 (Scripts), task-26 (Config Files), task-27 (Core Tests)

**Recommendation:** Proceed with implementation using available findings; blocked tasks can be addressed in parallel.

---

## 1. Findings Matrix

### 1.1 Hardcoded Values by Category

| Category | Count | Primary Values | Priority |
|----------|-------|----------------|----------|
| **Threshold Defaults** | 45+ | 250 dbps (most common), 500, 750, 1000 | Critical |
| **Symbol Lists** | 3 | TIER1_SYMBOLS tuple, priority symbols | High |
| **Date Ranges** | 5 | start_date="2024-07-01", end_date="2024-10-31" | Medium |
| **Output Paths** | 3 | "./output/spot_tier1_batch" | Low |
| **Worker Counts** | 2 | workers=8 | Low |

### 1.2 Hardcoded Values by Component

#### Python Core Library

| File | Hardcoded Values | Proposed Fix |
|------|-----------------|--------------|
| `constants.py` | `DEFAULT_THRESHOLD=250`, `TIER1_SYMBOLS`, `THRESHOLD_PRESETS` | Import from registry |
| `config/algorithm.py` | `default_threshold_decimal_bps = 250` | Registry fallback |
| `config/population.py` | `OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD=1000` | Registry lookup |
| `backfill.py` | `_PRIORITY_SYMBOLS`, default threshold=250 | Add to registry |

#### Rust Tools

| File | Hardcoded Values | Proposed Fix |
|------|-----------------|--------------|
| `tools/chart/src/main.rs` | `symbol=BTCUSDT`, `threshold=250` | Env var + default |
| `spot_tier1_processor.rs` | dates, threshold=250, output_dir, workers=8 | Env var config |

#### Rust Core Tests

| Category | Count | Proposed Fix |
|----------|-------|--------------|
| `crates/opendeviationbar-core/tests/` | 20+ files with hardcoded 250 | Build-time constants |

#### ClickHouse

| File | Hardcoded Values | Proposed Fix |
|------|-----------------|--------------|
| `cache.py` | "BTCUSDT", threshold values in queries | Registry lookup |

---

## 2. Dependency Analysis

### 2.1 Immediate Wiring (No Registry Changes)

These can be wired immediately without modifying the registry:

| Component | Current | Action | Effort |
|-----------|---------|--------|--------|
| `constants.py` | Hardcoded 250 | Import from symbol_registry | Low |
| `config/algorithm.py` | Hardcoded 250 | Use registry fallback function | Low |
| `tools/chart` | Hardcoded 250 | Environment variable | Low |
| `spot_tier1_processor` | Hardcoded dates/threshold | Environment variable | Low |

### 2.2 Requires Registry Enhancement

These need registry additions before wiring:

| Enhancement | Required For | Priority |
|-------------|-------------|----------|
| Add `default_thresholds` section to symbols.toml | Config files | High |
| Add `get_default_threshold()` function | All Python code | High |
| Add `get_tier1_symbols()` function | constants.py | High |
| Add `min_threshold` per symbol | population.py | Medium |

---

## 3. Implementation Phases

### Phase 1: Quick Wins (Week 1)

**Goal:** Eliminate obvious hardcoded values with minimal code changes.

1. **Add helper functions to symbol_registry.py:**
   ```python
   def get_default_threshold() -> int:
       return 250
   
   def get_tier1_symbols() -> tuple[str, ...]:
       return get_registered_symbols(tier=1, enabled_only=True)
   
   def get_default_thresholds() -> tuple[int, ...]:
       return (250, 500, 750, 1000)
   ```

2. **Update constants.py:**
   ```python
   from opendeviationbar.symbol_registry import (
       get_default_threshold,
       get_tier1_symbols,
       get_default_thresholds
   )
   
   DEFAULT_THRESHOLD: int = get_default_threshold()
   TIER1_SYMBOLS: tuple[str, ...] = get_tier1_symbols()
   THRESHOLD_PRESETS: tuple[int, ...] = get_default_thresholds()
   ```

3. **Update config files to use registry fallback:**
   - `config/algorithm.py` → use `get_default_threshold()`
   - `config/population.py` → use `get_min_threshold_for_symbol()`

**Expected Impact:** 15+ hardcoded values eliminated

### Phase 2: Rust Tool Integration (Week 2)

**Goal:** Wire Rust CLI tools to use environment variables.

1. **Update tools/chart/src/main.rs:**
   ```rust
   const DEFAULT_THRESHOLD: u32 = 250;
   
   fn get_default_threshold() -> u32 {
       std::env::var("OPENDEVIATIONBAR_DEFAULT_THRESHOLD")
           .ok()
           .and_then(|v| v.parse().ok())
           .unwrap_or(DEFAULT_THRESHOLD)
   }
   ```

2. **Update .mise.toml:**
   ```toml
   [env]
   OPENDEVIATIONBAR_DEFAULT_THRESHOLD = "250"
   OPENDEVIATIONBAR_CRYPTO_MIN_THRESHOLD = "1000"
   ```

3. **Update spot_tier1_processor.rs similarly**

**Expected Impact:** 5+ hardcoded values eliminated

### Phase 3: Build-Time Constants (Week 3)

**Goal:** Generate Rust constants from registry at build time.

1. **Create build.rs for opendeviationbar-core:**
   ```rust
   fn main() {
       // Parse symbols.toml and generate constants.rs
   }
   ```

2. **Generate constants for:**
   - `DEFAULT_THRESHOLD`
   - `TIER1_SYMBOLS`
   - `CRYPTO_MIN_THRESHOLD`

**Expected Impact:** 20+ test files updated automatically

### Phase 4: Registry Enhancement (Ongoing)

**Goal:** Extend registry for advanced use cases.

1. **Add metadata section to symbols.toml:**
   ```toml
   [meta]
   default_threshold = 250
   crypto_min_threshold = 1000
   
   [meta.default_thresholds]
   crypto = 1000
   forex = 50
   equities = 25
   ```

2. **Add functions:**
   - `get_default_threshold_for_asset_class(asset_class: str) -> int`
   - `get_phase_thresholds(phase: str) -> list[int]`
   - `get_priority_symbols() -> list[str]`

---

## 4. Migration Strategy by Category

### 4.1 Threshold Defaults

| Step | Action | Verification |
|------|--------|--------------|
| 1 | Add `get_default_threshold()` to symbol_registry.py | `python -c "from opendeviationbar.symbol_registry import get_default_threshold; print(get_default_threshold())"` |
| 2 | Update constants.py to use function | `python -c "from opendeviationbar.constants import DEFAULT_THRESHOLD; assert DEFAULT_THRESHOLD == 250"` |
| 3 | Update config files | `python -c "from opendeviationbar.config.algorithm import AlgorithmConfig; print(AlgorithmConfig().default_threshold_decimal_bps)"` |
| 4 | Update Rust tools | `OPENDEVIATIONBAR_DEFAULT_THRESHOLD=250 cargo test` |

### 4.2 Symbol Lists

| Step | Action | Verification |
|------|--------|--------------|
| 1 | Add `get_tier1_symbols()` to symbol_registry.py | `python -c "from opendeviationbar.symbol_registry import get_tier1_symbols; print(len(get_tier1_symbols()) > 0)"` |
| 2 | Update constants.py TIER1_SYMBOLS | `python -c "from opendeviationbar.constants import TIER1_SYMBOLS; from opendeviationbar.symbol_registry import get_tier1_symbols; assert set(TIER1_SYMBOLS) == set(get_tier1_symbols())"` |

### 4.3 Date Ranges

| Step | Action | Verification |
|------|--------|--------------|
| 1 | Add date constants or env var support | Check CLI --help output |
| 2 | Document recommended date ranges | Update README.md |

---

## 5. Verification Commands

```bash
# Phase 1 verification
python -c "
from opendeviationbar.constants import DEFAULT_THRESHOLD, TIER1_SYMBOLS, THRESHOLD_PRESETS
from opendeviationbar.symbol_registry import get_default_threshold, get_tier1_symbols, get_default_thresholds
from opendeviationbar.config.algorithm import AlgorithmConfig

assert DEFAULT_THRESHOLD == get_default_threshold(), 'DEFAULT_THRESHOLD mismatch'
assert set(TIER1_SYMBOLS) == set(get_tier1_symbols()), 'TIER1_SYMBOLS mismatch'
assert THRESHOLD_PRESETS == get_default_thresholds(), 'THRESHOLD_PRESETS mismatch'
assert AlgorithmConfig().default_threshold_decimal_bps == 250, 'AlgorithmConfig mismatch'
print('✓ All Python registry integrations verified')
"

# Phase 2 verification
cargo test --manifest-path tools/chart/Cargo.toml
cargo test --manifest-path crates/opendeviationbar-cli/Cargo.toml

# Phase 3 verification  
cargo build --manifest-path crates/opendeviationbar-core/Cargo.toml
```

---

## 6. Summary

| Phase | Effort | Impact | Files Changed |
|-------|--------|--------|---------------|
| Phase 1: Quick Wins | Low | 15+ values | 3-5 |
| Phase 2: Rust Tools | Low | 5+ values | 3-4 |
| Phase 3: Build-Time | Medium | 20+ values | 2-3 |
| Phase 4: Registry | Medium | Enable future | 2 |

**Total:** 45+ hardcoded values eliminated, single source of truth in symbols.toml

---

## 7. Next Steps

1. **Immediate:** Create sub-tasks for Phase 1 implementation
2. **Week 2:** Implement Rust tool integration
3. **Week 3:** Set up build-time constants generation
4. **Ongoing:** Extend registry as needed

---

*Synthesis generated for task-18: Cross-Cutting Synthesis and Resolution Strategy*
