"""Type stubs for opendeviationbar package.

Public API re-exports. Per-module stubs live alongside their source files.
See PEP 561 and https://typing.python.org/en/latest/guides/writing_stubs.html
"""

# Version
__version__: str

# PyO3 bindings (opendeviationbar._core)
from ._core import PositionVerification as PositionVerification

# Gap backfill (opendeviationbar.backfill)
from .backfill import BackfillResult as BackfillResult
from .backfill import backfill_all_gaps as backfill_all_gaps
from .backfill import backfill_gap as backfill_gap

# Binance Vision probe (opendeviationbar.binance_vision)
from .binance_vision import (
    BINANCE_VISION_AGGTRADES_URL as BINANCE_VISION_AGGTRADES_URL,
)
from .binance_vision import (
    probe_latest_available_date as probe_latest_available_date,
)

# Cache population (opendeviationbar.checkpoint)
from .checkpoint import (
    populate_cache_multi_threshold as populate_cache_multi_threshold,
)
from .checkpoint import populate_cache_resumable as populate_cache_resumable

# Alpha-forge compatibility layer (opendeviationbar.compat) — Issue #95
from .compat import get_available_symbols as get_available_symbols
from .compat import get_cache_coverage as get_cache_coverage
from .compat import get_feature_groups as get_feature_groups
from .compat import get_feature_manifest as get_feature_manifest
from .compat import get_open_deviation_bars_panel as get_open_deviation_bars_panel
from .compat import to_panel_format as to_panel_format

# Constants (opendeviationbar.constants)
from .constants import ALL_OPTIONAL_COLUMNS as ALL_OPTIONAL_COLUMNS
from .constants import BAR_FLAG_COLUMNS as BAR_FLAG_COLUMNS
from .constants import EXCHANGE_SESSION_COLUMNS as EXCHANGE_SESSION_COLUMNS
from .constants import INTER_BAR_FEATURE_COLUMNS as INTER_BAR_FEATURE_COLUMNS
from .constants import INTRA_BAR_FEATURE_COLUMNS as INTRA_BAR_FEATURE_COLUMNS
from .constants import LONG_RANGE_DAYS as LONG_RANGE_DAYS
from .constants import MICROSTRUCTURE_COLUMNS as MICROSTRUCTURE_COLUMNS
from .constants import (
    MIN_VERSION_FOR_MICROSTRUCTURE as MIN_VERSION_FOR_MICROSTRUCTURE,
)
from .constants import MIN_VERSION_FOR_OUROBOROS as MIN_VERSION_FOR_OUROBOROS
from .constants import (
    SCHEMA_VERSION_MICROSTRUCTURE as SCHEMA_VERSION_MICROSTRUCTURE,
)
from .constants import SCHEMA_VERSION_OHLCV_ONLY as SCHEMA_VERSION_OHLCV_ONLY
from .constants import SCHEMA_VERSION_OUROBOROS as SCHEMA_VERSION_OUROBOROS
from .constants import THRESHOLD_DECIMAL_MAX as THRESHOLD_DECIMAL_MAX
from .constants import THRESHOLD_DECIMAL_MIN as THRESHOLD_DECIMAL_MIN
from .constants import THRESHOLD_PRESETS as THRESHOLD_PRESETS
from .constants import TIER1_SYMBOLS as TIER1_SYMBOLS
from .constants import TRADE_ID_RANGE_COLUMNS as TRADE_ID_RANGE_COLUMNS

# Conversion utilities (opendeviationbar.conversion)
from .conversion import normalize_arrow_dtypes as normalize_arrow_dtypes
from .conversion import normalize_temporal_precision as normalize_temporal_precision

# Exceptions (opendeviationbar.exceptions)
from .exceptions import SymbolNotRegisteredError as SymbolNotRegisteredError

# Main API (opendeviationbar.orchestration.*)
from .orchestration.count_bounded import (
    get_n_open_deviation_bars as get_n_open_deviation_bars,
)

# Orchestration models (opendeviationbar.orchestration.models)
from .orchestration.models import PrecomputeProgress as PrecomputeProgress
from .orchestration.models import PrecomputeResult as PrecomputeResult
from .orchestration.open_deviation_bars import (
    get_open_deviation_bars as get_open_deviation_bars,
)
from .orchestration.open_deviation_bars import (
    get_open_deviation_bars_pandas as get_open_deviation_bars_pandas,
)
from .orchestration.precompute import (
    precompute_open_deviation_bars as precompute_open_deviation_bars,
)

# Ouroboros (opendeviationbar.ouroboros)
from .ouroboros import OrphanedBarMetadata as OrphanedBarMetadata
from .ouroboros import OuroborosBoundary as OuroborosBoundary
from .ouroboros import OuroborosMode as OuroborosMode
from .ouroboros import get_ouroboros_boundaries as get_ouroboros_boundaries

# Plugin discovery (opendeviationbar.plugins.loader)
from .plugins.loader import discover_providers as discover_providers

# Processor (opendeviationbar.processors.core)
from .processors.api import process_trades_chunked as process_trades_chunked
from .processors.api import process_trades_polars as process_trades_polars
from .processors.api import process_trades_polars_lazy as process_trades_polars_lazy
from .processors.api import (
    process_trades_to_dataframe as process_trades_to_dataframe,
)
from .processors.api import (
    process_trades_to_dataframe_cached as process_trades_to_dataframe_cached,
)

# Processor (opendeviationbar.processors.core)
from .processors.core import OpenDeviationBarProcessor as OpenDeviationBarProcessor

# Resource guard (opendeviationbar.resource_guard)
from .resource_guard import auto_memory_guard as auto_memory_guard
from .resource_guard import ensure_memory_limit as ensure_memory_limit

# Streaming sidecar (opendeviationbar.sidecar) — Issue #91
from .sidecar import SidecarConfig as SidecarConfig
from .sidecar import run_sidecar as run_sidecar

# Streaming API (opendeviationbar.streaming)
from .streaming import AsyncStreamingProcessor as AsyncStreamingProcessor
from .streaming import BinanceLiveStream as BinanceLiveStream
from .streaming import ReconnectionConfig as ReconnectionConfig
from .streaming import StreamingConfig as StreamingConfig
from .streaming import StreamingError as StreamingError
from .streaming import StreamingMetrics as StreamingMetrics
from .streaming import (
    StreamingOpenDeviationBarProcessor as StreamingOpenDeviationBarProcessor,
)
from .streaming import stream_binance_live as stream_binance_live

# Symbol registry (opendeviationbar.symbol_registry)
from .symbol_registry import SymbolEntry as SymbolEntry
from .symbol_registry import SymbolTransition as SymbolTransition
from .symbol_registry import (
    clear_symbol_registry_cache as clear_symbol_registry_cache,
)
from .symbol_registry import get_effective_start_date as get_effective_start_date
from .symbol_registry import get_registered_symbols as get_registered_symbols
from .symbol_registry import get_symbol_entries as get_symbol_entries
from .symbol_registry import get_symbol_market as get_symbol_market
from .symbol_registry import get_transitions as get_transitions
from .symbol_registry import resolve_market as resolve_market
from .symbol_registry import (
    validate_and_clamp_start_date as validate_and_clamp_start_date,
)
from .symbol_registry import validate_symbol_registered as validate_symbol_registered

# Threshold validation (opendeviationbar.threshold) — Issue #62
from .threshold import CryptoThresholdError as CryptoThresholdError
from .threshold import ThresholdError as ThresholdError
from .threshold import clear_threshold_cache as clear_threshold_cache
from .threshold import get_min_threshold as get_min_threshold
from .threshold import get_min_threshold_for_symbol as get_min_threshold_for_symbol
from .threshold import (
    resolve_and_validate_threshold as resolve_and_validate_threshold,
)

# Cache staleness (opendeviationbar.validation.cache_staleness)
from .validation.cache_staleness import StalenessResult as StalenessResult
from .validation.cache_staleness import detect_staleness as detect_staleness

# Tiered validation (opendeviationbar.validation.continuity)
from .validation.continuity import ASSET_CLASS_MULTIPLIERS as ASSET_CLASS_MULTIPLIERS
from .validation.continuity import VALIDATION_PRESETS as VALIDATION_PRESETS
from .validation.continuity import AssetClass as AssetClass
from .validation.continuity import ContinuityError as ContinuityError
from .validation.continuity import ContinuityWarning as ContinuityWarning
from .validation.continuity import GapInfo as GapInfo
from .validation.continuity import GapTier as GapTier
from .validation.continuity import TieredValidationResult as TieredValidationResult
from .validation.continuity import TierSummary as TierSummary
from .validation.continuity import TierThresholds as TierThresholds
from .validation.continuity import ValidationPreset as ValidationPreset
from .validation.continuity import detect_asset_class as detect_asset_class
from .validation.continuity import validate_continuity as validate_continuity
from .validation.continuity import (
    validate_continuity_tiered as validate_continuity_tiered,
)
