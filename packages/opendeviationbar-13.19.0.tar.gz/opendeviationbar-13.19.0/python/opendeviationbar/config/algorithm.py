"""Algorithm configuration for Rust tunables.

Issue #110 Phase 7: Expose user-tunable subset of
opendeviationbar-config AlgorithmConfig via pydantic-settings.
Safety invariants (validate_*, fixed_point_decimals) stay
Rust-only -- they're correctness guarantees, not user knobs.

Environment variables use OPENDEVIATIONBAR_ALGORITHM_ prefix.
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict

# Quick win: use symbol_registry for default threshold (will read from [meta] in future)
from opendeviationbar.symbol_registry import get_default_threshold


class AlgorithmConfig(BaseSettings):
    """User-tunable subset of Rust AlgorithmConfig.

    Environment Variables
    ---------------------
    OPENDEVIATIONBAR_ALGORITHM_DEFAULT_THRESHOLD_DECIMAL_BPS : int
        Default threshold in dbps (default: 250)
    OPENDEVIATIONBAR_ALGORITHM_PROCESSING_BATCH_SIZE : int
        Processing batch size for chunked operations (default: 100000)
    OPENDEVIATIONBAR_ALGORITHM_ENABLE_MEMORY_OPTIMIZATION : bool
        Enable memory optimization in Rust processor (default: True)
    OPENDEVIATIONBAR_ALGORITHM_COLLECT_PERFORMANCE_METRICS : bool
        Collect performance metrics during processing (default: False)
    """

    model_config = SettingsConfigDict(
        env_prefix="OPENDEVIATIONBAR_ALGORITHM_",
        case_sensitive=False,
    )

    default_threshold_decimal_bps: int = get_default_threshold()
    processing_batch_size: int = 100_000
    enable_memory_optimization: bool = True
    collect_performance_metrics: bool = False
