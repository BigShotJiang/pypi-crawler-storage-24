"""Kintsugi gap reconciliation configuration.

Centralizes all kintsugi operational constants: repair timeouts, batch sizing,
alert formatting, and daemon tuning.

All values load from environment variables (OPENDEVIATIONBAR_KINTSUGI_ prefix).
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class KintsugiConfig(BaseSettings):
    """Kintsugi repair engine configuration.

    Environment Variables
    ---------------------
    OPENDEVIATIONBAR_KINTSUGI_REPAIR_TIMEOUT_S : int
        Per-day repair timeout for lock TTL calculation (default: 600)
    OPENDEVIATIONBAR_KINTSUGI_BATCH_DAYS : int
        Max days to process per shard per repair pass (default: 30)
    OPENDEVIATIONBAR_KINTSUGI_BATCH_WORKERS : int
        Parallel day repairs within a batch (default: 4)
    OPENDEVIATIONBAR_KINTSUGI_MAX_REPAIRS_PER_PASS : int
        Shards repaired per kintsugi pass (default: 3)
    OPENDEVIATIONBAR_KINTSUGI_MAX_CONCURRENT_REPAIRS : int
        Max concurrent shard repairs for Vision-download shards (default: 4)
    OPENDEVIATIONBAR_KINTSUGI_MAX_CONCURRENT_PARQUET : int
        Max concurrent repairs when ALL candidates are Parquet-cached (default: 64).
        SSoT for production values: deploy/opendeviationbar.env
    OPENDEVIATIONBAR_KINTSUGI_MAX_ATTEMPTS_PER_SHARD : int
        Per-24h retry limit tracked in kintsugi_log (default: 3)
    OPENDEVIATIONBAR_KINTSUGI_NDJSON_MAX_BYTES : int
        NDJSON event log rotation threshold (default: 10485760 = 10MB)
    OPENDEVIATIONBAR_KINTSUGI_MAX_FAILURES_IN_ALERT : int
        Telegram alert: max failed shards shown (default: 5)
    OPENDEVIATIONBAR_KINTSUGI_MAX_HEALED_DETAILS : int
        Telegram summary: max healed shard details shown (default: 5)
    OPENDEVIATIONBAR_KINTSUGI_RECTIFICATION_CYCLE_INTERVAL : int
        Stathera rectification every N daemon iterations (default: 12)
    OPENDEVIATIONBAR_KINTSUGI_CONVERGENCE_MAX_REPAIRS_PER_DAY : int
        Day-mode convergence check: max repairs before flagging (default: 10)
    OPENDEVIATIONBAR_KINTSUGI_MIN_DEAD_LETTER_PARTS : int
        Minimum filename parts for valid dead-letter files (default: 3)
    """

    model_config = SettingsConfigDict(
        env_prefix="OPENDEVIATIONBAR_KINTSUGI_",
        case_sensitive=False,
    )

    # Per-day repair timeout: used for lock TTL = (timeout + 60) * batch_days
    repair_timeout_s: int = 600

    # Max days to process per shard per repair pass
    batch_days: int = 30

    # Parallel day repairs within a batch (Vision parallelizable, REST shares rate limits)
    batch_workers: int = 4

    # Shards repaired per kintsugi pass
    max_repairs_per_pass: int = 3

    # Max concurrent shard repairs (outer parallelism across different pairs)
    max_concurrent_repairs: int = 4

    # Max concurrent repairs when ALL candidates are already in the Parquet tick cache
    # (no Vision download needed — local CPU/IO only, no cascade-heal risk).
    # Higher than max_concurrent_repairs because we're not bandwidth-limited.
    max_concurrent_parquet: int = 64

    # Per-24h retry limit per shard (tracked in kintsugi_log)
    max_attempts_per_shard: int = 3

    # NDJSON event log rotation threshold (bytes)
    ndjson_max_bytes: int = 10 * 1024 * 1024  # 10 MB

    # Telegram alert: max failed shards shown before truncation
    max_failures_in_alert: int = 5

    # Telegram summary: max healed shard details shown
    max_healed_details: int = 5

    # Stathera rectification every N daemon iterations (0 = disabled)
    rectification_cycle_interval: int = 12

    # Day-mode convergence observation: max repairs before flagging
    convergence_max_repairs_per_day: int = 10

    # Minimum filename parts for valid dead-letter files (symbol_threshold_timestamp)
    min_dead_letter_parts: int = 3
