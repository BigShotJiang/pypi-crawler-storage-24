"""Proactive Parquet tick cache seeder configuration (Issue #270).

Seeds bigblack's local tick cache from Binance Vision archives so that
kintsugi's 64-worker Parquet path (_shard_is_parquet_cached) is always active.
"""

from __future__ import annotations

from pydantic_settings import BaseSettings, SettingsConfigDict


class SeederConfig(BaseSettings):
    """Tick cache seeder configuration.

    Environment Variables
    ---------------------
    OPENDEVIATIONBAR_SEEDER_HISTORICAL_START : str
        Earliest date to seed (YYYY-MM-DD). Per-symbol effective_start in
        symbols.toml overrides this when it is later (default: "2018-01-01").
    OPENDEVIATIONBAR_SEEDER_MAX_CONCURRENT_DOWNLOADS : int
        Concurrent Vision ZIP downloads per symbol batch (default: 4).
        USB ethernet budget on bigblack: ~10-12 MB/s / ~15 MB/ZIP ≈ 6 max.
        Set to 4 to leave headroom for kintsugi and sidecar.
    OPENDEVIATIONBAR_SEEDER_VISION_TIMEOUT_S : int
        HTTP timeout for Vision ZIP downloads in seconds (default: 120).
    OPENDEVIATIONBAR_SEEDER_HEAD_TIMEOUT_S : int
        HTTP timeout for Vision availability HEAD checks (default: 10).
    OPENDEVIATIONBAR_SEEDER_STATE_FILE : str
        Path to state file written on completion (read by monit health check).
        Default: "/var/tmp/opendeviationbar-seeder-state.txt"
    """

    model_config = SettingsConfigDict(
        env_prefix="OPENDEVIATIONBAR_SEEDER_",
        case_sensitive=False,
    )

    historical_start: str = "2018-01-01"
    max_concurrent_downloads: int = 4
    vision_timeout_s: int = 120
    head_timeout_s: int = 10
    state_file: str = "/var/tmp/opendeviationbar-seeder-state.txt"
