from pathlib import Path
from typing import Literal

def populate_cache_resumable(
    symbol: str,
    start_date: str,
    end_date: str,
    *,
    threshold_decimal_bps: int | list[int] = 250,
    force_refresh: bool = False,
    include_microstructure: bool = False,
    ouroboros_mode: Literal["day"] | None = None,
    checkpoint_dir: str | Path | None = None,
    notify: bool = True,
    verbose: bool = True,
    inter_bar_lookback_bars: int | None = None,
    num_async_writers: int = 0,
    max_days: int | None = 366,
    skip_missing_days: bool = False,
    market: str | None = None,
) -> int: ...

def populate_cache_multi_threshold(
    symbol: str,
    start_date: str,
    end_date: str,
    thresholds: list[int],
    *,
    force_refresh: bool = False,
    include_microstructure: bool = False,
    ouroboros_mode: Literal["day"] | None = None,
    checkpoint_dir: str | Path | None = None,
    notify: bool = True,
    verbose: bool = True,
    inter_bar_lookback_bars: int | None = None,
    num_async_writers: int = 0,
    max_days: int | None = 366,
    skip_missing_days: bool = False,
    market: str | None = None,
) -> dict[int, int]: ...
