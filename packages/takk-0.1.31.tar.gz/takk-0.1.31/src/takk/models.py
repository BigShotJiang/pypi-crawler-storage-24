from __future__ import annotations
from contextlib import suppress
from functools import lru_cache, partial
import inspect
import json
import types
import typing
from uuid import UUID
from httpx import AsyncClient
from dataclasses import dataclass, field, fields as dataclass_fields, MISSING as DATACLASS_MISSING, is_dataclass
import logging
from pathlib import Path
from types import ModuleType, NoneType
from typing import TYPE_CHECKING, Any, Awaitable, Callable, ClassVar, Generic, Iterable, Literal, Mapping, Protocol, Sequence, TypeVar, overload
from pydantic import BaseModel, Field, MySQLDsn, PostgresDsn, SecretStr, ValidationError
from pydantic.fields import FieldInfo
from pydantic_core import PydanticUndefined
from pydantic_settings import BaseSettings

from takk.alembic import Revision, revisions_for_alembic_config
from takk.resources import CompiledResource, Resource
from takk.secrets import ResourceRef, ResourceTags, NatsConfig, ObjectStorageConfig, SecretTypes, ServiceUrl, SqsConfig, SqsQueueSettings, UnleashConfig, Environments
from rich.console import Console
from nats.js.api import ConsumerConfig, StreamConfig

if TYPE_CHECKING:
    from takk.queue import QueueBroker

logger = logging.getLogger(__name__)

console = Console()

T = TypeVar("T", bound=BaseModel)
FunctionType = TypeVar("FunctionType")

class DataclassFields(Protocol):
    __dataclass_fields__: ClassVar[dict[str, Any]]

# A secrets class can be a Pydantic BaseModel subclass or a Python dataclass
SecretClass = type[BaseModel] | type[DataclassFields]

class TakkEnvironment(BaseSettings):
    takk_env: Environments | str = Field(default="dev")

class _NoValue:
    pass

@lru_cache
def current_env() -> Environments | str:
    return TakkEnvironment().takk_env


NoValue = _NoValue()

@overload
def value_for(
    default: FunctionType,
    prod: FunctionType | _NoValue = ...,
    test: FunctionType | _NoValue = ...,
    dev: FunctionType | _NoValue = ...,
    qa: FunctionType | _NoValue = ...,
) -> FunctionType: ...

# May return None: either default is None/missing, or any arg allows None
@overload
def value_for(
    default: FunctionType | None = ...,
    prod: FunctionType | _NoValue | None = ...,
    test: FunctionType | _NoValue | None = ...,
    dev: FunctionType | _NoValue | None = ...,
    qa: FunctionType | _NoValue | None = ...,
) -> FunctionType | None: ...

def value_for(
    default: FunctionType | None = None,
    prod: FunctionType | _NoValue | None = NoValue,
    test: FunctionType | _NoValue | None = NoValue,
    dev: FunctionType | _NoValue | None = NoValue,
    qa: FunctionType | _NoValue | None = NoValue,
) -> FunctionType | None:

    def resolve(val: FunctionType | _NoValue | None) -> FunctionType | None:
        if val is NoValue:
            return default
        return val # type: ignore

    match current_env():
        case "prod": 
            return resolve(prod)
        case "test": 
            return resolve(test)
        case "dev": 
            return resolve(dev)
        case "qa": 
            return resolve(qa)
        case _: 
            return default
        

class Contact(BaseModel):
    name: str
    email: str | None = None
    discord_member_id: str | None = None
    slack_member_id: str | None = None


class SettingsValue(BaseModel):
    name: str
    data_type: str
    description: str | None = Field(default=None)
    default_value: str | None = Field(default=None)
    is_optional: bool = Field(default=False)
    is_secret: bool = Field(default=False)
    tags: list[str] = Field(default_factory=list)

    def __hash__(self):
        return hash(self.name + self.data_type)


class Compute(BaseModel):
    mvcpu_limit: int = 1000
    mb_memory_limit: int = 1024
    mb_local_storage_limit: int = 1000

def tags_for(attrs: Iterable) -> list[str]:
    tags = []
    for attr in attrs:
        if isinstance(attr, str):
            tags.append(attr)
        elif isinstance(attr, ResourceTags):
            tags.append(attr.value)
        elif isinstance(attr, ResourceRef):
            tags.append(attr.to_string())
        elif isinstance(attr, ServiceUrl):
            tags.append(str(attr))
        elif isinstance(attr, SecretTypes):
            tags.append(attr.value)
    return tags


def tags_for_annotation(annotation: Any) -> tuple[str, list[str], bool, bool]:
    data_type = "str"
    is_optional = False
    is_secret = False

    if typing.get_origin(annotation) is typing.Annotated:
        args = typing.get_args(annotation)
        tags = tags_for(args)
        arg_type = args[0]

        dtype, sub_tags, is_optional, sub_is_secret = tags_for_annotation(arg_type)

        is_secret = any(
            isinstance(arg, SecretTypes)
            for arg in args
        )
        return (dtype, [*tags, *sub_tags], is_optional, is_secret or sub_is_secret)


    if typing.get_origin(annotation) is typing.Union:
        args = typing.get_args(annotation)
        is_optional = NoneType in args
        data_type = annotation.__name__

        all_dtypes: set[str] = set()
        all_tags = []

        for arg in args:
            dtype, sub_tags, sub_is_optional, sub_is_secret = tags_for_annotation(arg)
            all_tags.extend(sub_tags)

            if dtype != "NoneType":
                all_dtypes.add(dtype)

            is_optional = is_optional or sub_is_optional
            is_secret = is_secret or sub_is_secret

        if len(all_dtypes) == 1:
            return (next(iter(all_dtypes)), all_tags, is_optional, is_secret)

        return (" | ".join(all_dtypes), all_tags, is_optional, is_secret)

    elif annotation == SecretStr:
        data_type = "str"
        is_secret = True
    elif annotation:
        is_optional = NoneType == annotation
        if hasattr(annotation, "__name__"):
            data_type = annotation.__name__
            if data_type.endswith("Dsn"):
                is_secret = True
        else:
            data_type = str(annotation)

    return (data_type, [], is_optional, is_secret)

def settings_for(settings_type: SecretClass | list[SecretClass]) -> list[SettingsValue]:

    values: list[SettingsValue] = []

    if isinstance(settings_type, list):
        for stype in settings_type:
            values.extend(settings_for(stype))

    elif is_dataclass(settings_type):
        type_hints = typing.get_type_hints(settings_type, include_extras=True)
        for dc_field in dataclass_fields(settings_type):
            annotation = type_hints.get(dc_field.name, dc_field.type)
            data_type, tags, is_optional, is_secret = tags_for_annotation(annotation)
            default_value = (
                str(dc_field.default)
                if dc_field.default is not DATACLASS_MISSING
                else None
            )
            description = dc_field.metadata.get("description") if dc_field.metadata else None
            values.append(
                SettingsValue(
                    name=dc_field.name,
                    data_type=data_type,
                    description=description,
                    default_value=default_value,
                    is_optional=is_optional,
                    is_secret=is_secret,
                    tags=[*tags, *tags_for(dc_field.metadata.values())],
                )
            )

    else:
        # Pydantic model path (unchanged)
        for name, pyd_field in settings_type.__pydantic_fields__.items(): # type: ignore
            data_type, tags, is_optional, sub_is_secret = tags_for_annotation(pyd_field.annotation)

            is_secret = any(
                isinstance(tag, SecretTypes)
                for tag in pyd_field.metadata
            )

            values.append(
                SettingsValue(
                    name=name,
                    data_type=data_type,
                    description=pyd_field.description,
                    default_value=str(pyd_field.default) if pyd_field.default != PydanticUndefined else None,
                    is_optional=is_optional,
                    is_secret=is_secret or sub_is_secret,
                    tags=[*tags, *tags_for(pyd_field.metadata)],
                )
            )

    return values

@overload
def Partial(settings_cls: type[BaseModel]) -> type[BaseModel]:
    ...

@overload
def Partial(settings_cls: type[DataclassFields]) -> type[DataclassFields]:
    ...

def Partial(settings_cls: SecretClass) -> SecretClass:
    """Create a version of settings_cls where all fields are Optional[T] = None."""
    import dataclasses
    from pydantic import create_model

    def _make_optional(annotation: Any) -> Any:
        origin = typing.get_origin(annotation)
        if origin is typing.Union:
            args = typing.get_args(annotation)
            if NoneType in args:
                return annotation
            return typing.Union[annotation, None]
        if isinstance(annotation, types.UnionType):
            args = typing.get_args(annotation)
            if NoneType in args:
                return annotation
            return typing.Union[annotation, None]  # type: ignore[operator]
        return typing.Union[annotation, None]

    if is_dataclass(settings_cls):
        type_hints = typing.get_type_hints(settings_cls, include_extras=True)
        fields = []
        for dc_field in dataclass_fields(settings_cls):  # type: ignore[arg-type]
            annotation = type_hints.get(dc_field.name, dc_field.type)
            opt_annotation = _make_optional(annotation)
            fields.append((dc_field.name, opt_annotation, dataclasses.field(metadata=dc_field.metadata)))
        return dataclasses.make_dataclass(f"Partial{settings_cls.__name__}", fields)  # type: ignore[return-value]
    else:
        if issubclass(settings_cls, BaseSettings):  # type: ignore[arg-type]
            base: type[BaseModel] = BaseSettings
        else:
            base = BaseModel
        field_definitions: dict[str, Any] = {}
        for name, pyd_field in settings_cls.__pydantic_fields__.items():  # type: ignore[union-attr]
            annotation = pyd_field.annotation
            opt_annotation = _make_optional(annotation)
            field_definitions[name] = (opt_annotation, pyd_field)
        return create_model(f"Partial{settings_cls.__name__}", __base__=base, **field_definitions)  # type: ignore[return-value]


def settings_for_secrets(
    settings: list[SettingsValue],
    resources: "dict[ResourceRef | ServiceUrl, str]",
    envs: dict[str, str | None]
) -> dict[str, str]:
    from takk.secrets import ResourceRef, ServiceUrl
    vals: dict[str, str] = {}
    for secret in settings:
        val = envs.get(secret.name, envs.get(secret.name.upper()))

        if val:
            vals[secret.name] = val
            continue

        for resource, value in resources.items():

            if isinstance(resource, ResourceRef):
                if resource.tag in secret.tags or resource.to_string() in secret.tags:
                    val = value
            elif isinstance(resource, ServiceUrl):
                if resource.to_string() in secret.tags:
                    val = value

        if not val and ResourceTags.is_tag(secret.data_type):
            val = resources.get(
                ResourceRef(ResourceTags(secret.data_type))
            )

        if val is None:
            import os
            val = os.environ.get(secret.name, os.environ.get(secret.name.upper()))
            # Set the default explicitly, as this will set them for non Python applications
            val = val or secret.default_value

        if not val:
            continue

        vals[secret.name] = val

        if ResourceTags.sqlalchemy_uri in secret.tags:
            if secret.data_type == PostgresDsn.__name__:
                protocol = "postgresql"

                with suppress(ImportError):
                    import psycopg
                    protocol = "postgresql+psycopg"

                with suppress(ImportError):
                    import psycopg2
                    protocol = "postgresql+psycopg2"

                with suppress(ImportError):
                    import asyncpg
                    protocol = "postgresql+asyncpg"

                vals[secret.name] = vals[secret.name].replace("postgresql://", f"{protocol}://", 1)

            elif secret.data_type == MySQLDsn.__name__:
                protocol = "mysql"

                with suppress(ImportError):
                    import aiomysql
                    protocol = "mysql+aiomysql"

                vals[secret.name] = vals[secret.name].replace("mysql://", f"{protocol}://", 1)

    return vals


class NetworkHealthCheck(BaseModel):
    url: str
    interval: int = 10
    timeout: int = 5
    retries: int = 5


class DockerBuild(BaseModel):
    image_name: str
    dockerfile: str | Path = Path("Dockerfile")
    context: Path = Path(".")
    args: dict[str, str] = field(default_factory=dict)

    build_hash: tuple[Path, str] | None = None
    source_dir: Path | None = None

    
    @staticmethod
    def generate_default_uv_image(
        project: "Project",
        image_name: "str | None" = None,
        build_args: "dict[str, str] | None" = None,
    ) -> "DockerBuild":
        from takk.docker import generate_uv_dockerfile, find_lockfile, ImageKeys

        lockfile = find_lockfile()
        dockerfile, context, source_dir = generate_uv_dockerfile(project)

        return DockerBuild(
            image_name=image_name or project.name or "",
            dockerfile=dockerfile,
            context=context,
            args=build_args or {}, # type: ignore
            build_hash=(lockfile, ImageKeys.lock_hash),
            source_dir=source_dir
        )

    @staticmethod
    def default_uv_image(
        image_name: "str | None" = None,
        build_args: "dict[str, str] | None" = None,
    ) -> Callable[["Project"], "DockerBuild"]:
        return partial(
            DockerBuild.generate_default_uv_image,
            image_name=image_name,
            build_args=build_args
        )

class CompiledNetworkApp(BaseModel):
    name: str
    command: list[str] | None
    port: int

    description: str | None = None
    environments: dict[str, str] | None = None
    settings: list[SettingsValue] | None = None
    contacts: list[Contact] | None = None

    health_check: NetworkHealthCheck | None = None

    compute: Compute = field(default_factory=Compute)
    min_scale: int = 0
    max_scale: int = 1

    https_only: bool = True
    tags: list[str] | None = None

    domain_names: list[str] | None = None

    resource_id: str | None = None
    docker_image: str | None = None
    docker_build: DockerBuild | None = None

    private_network_name: str | None = None

    def id(self) -> str:
        from hashlib import sha1
        return sha1(self.name.encode()).hexdigest()


@dataclass
class ComputeRequest:
    min_mvcpus: int = field(default=1000)
    min_mb_ram: int = field(default=1024)
    min_mb_local_storage: int = field(default=1000)
    min_gpus: int = field(default=0)


@dataclass
class ServerlessCompute:
    compute: Compute
    min_scale: int = 0
    max_scale: int = 1


@dataclass
class NetworkApp:
    port: int

    command: list[str] | None = None
    description: str | None = None
    environments: dict[str, str] | None = None
    settings: list[SecretClass] | None = None
    contacts: list[Contact] | Contact | None = None

    compute: Compute = field(default_factory=Compute)
    min_scale: int = 0
    max_scale: int = 1

    https_only: bool = True
    domain_names: list[str] | str | None = None
    tags: list[str] | None = None

    health_check: str | NetworkHealthCheck | None = None

    docker_image: str | None = None
    docker_build: DockerBuild | Callable[["Project"], DockerBuild] | None = None

    def compile(self, name: str) -> CompiledNetworkApp:
        docker_build = None
        if callable(self.docker_build):
            docker_build = self.docker_build(Project(name))

        return CompiledNetworkApp(
            name=name,
            command=self.command,
            port=self.port,
            description=self.description,
            environments=self.environments,
            settings=settings_for(self.settings or []),
            contacts=[self.contacts] if isinstance(self.contacts, Contact) else self.contacts,
            health_check=NetworkHealthCheck(url=self.health_check) if isinstance(self.health_check, str) else self.health_check,  
            compute=self.compute,
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            tags=self.tags,
            https_only=self.https_only,
            domain_names=[self.domain_names] if isinstance(self.domain_names, str) else self.domain_names,
            docker_image=self.docker_image,
            docker_build=docker_build
        )

def startup_command(scripts: Sequence[str | Callable], root_path: Path) -> list[str]:
    commands = []

    for script in scripts:
        if isinstance(script, str):
            commands.append(script)
        else:
            source_file = Path(inspect.getfile(script))
            relative_file = source_file.relative_to(root_path).as_posix().replace("/", ".").removesuffix(".py")
            commands.append(f"python -m {relative_file}")

    return commands


@dataclass
class JupyterNotebook:

    port: int = 8888

    def network_app(self, root_path: Path) -> NetworkApp:
        return NetworkApp(
            port=8888,
            command=["jupyter", "lab", "--ip=0.0.0.0", f"--port={self.port}", "--no-browser", "--allow-root", "--NotebookApp.token=''", "--NotebookApp.password=''"]
        )

@dataclass
class FastAPIApp:
    app: ModuleType | str | None = None
    settings: list[SecretClass] | None = None
    environments: dict[str, str] | None = None
    contacts: list[Contact] | Contact | None = None
    
    port: int = 8000
    compute: Compute = field(default_factory=Compute)
    min_scale: int = 0
    max_scale: int = 1

    https_only: bool = True
    domain_names: list[str] | str | None = None
    health_check: str | NetworkHealthCheck | None = None

    def network_app(self, root_path: Path) -> NetworkApp:
        import inspect

        bash_commands = []
        if self.app is None:
            relative_file = "Unknown"
            bash_commands.append(f"fastapi run --host 0.0.0.0 --port {self.port}")
        else:
            if isinstance(self.app, str):
                relative_file = self.app
            else:
                source_file = Path(inspect.getfile(self.app))
                relative_file = source_file.relative_to(root_path).as_posix().replace("/", ".").removesuffix(".py")

            if ":" not in relative_file:
                relative_file += ":app"

            bash_commands.append(f"uvicorn {relative_file} --host 0.0.0.0 --port {self.port}")

        command = ["/bin/bash", "-c", " && ".join(bash_commands)]

        return NetworkApp(
            command=command,
            port=self.port,
            settings=self.settings,
            environments=self.environments,
            description=f"FastAPI application at {relative_file}",
            contacts=self.contacts,
            compute=self.compute,
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            https_only=self.https_only,
            domain_names=self.domain_names,
            health_check=self.health_check,
            tags=["fastapi"]
        )


@dataclass
class UvicornApp:
    app: str
    settings: list[SecretClass] | None = None
    environments: dict[str, str] | None = None
    contacts: list[Contact] | Contact | None = None

    port: int = 8000
    compute: Compute = field(default_factory=Compute)
    min_scale: int = 0
    max_scale: int = 1

    https_only: bool = True
    domain_names: list[str] | str | None = None
    health_check: str | NetworkHealthCheck | None = None

    tags: list[str] | None = None

    def network_app(self, root_path: Path) -> NetworkApp:
        command = ["/bin/bash", "-c", f"uvicorn {self.app} --host 0.0.0.0 --port {self.port}"]

        return NetworkApp(
            command=command,
            port=self.port,
            settings=self.settings,
            environments=self.environments,
            description=f"Uvicorn application at {self.app}",
            contacts=self.contacts,
            compute=self.compute,
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            https_only=self.https_only,
            domain_names=self.domain_names,
            health_check=self.health_check,
            tags=[*(self.tags or []), "uvicorn"],
        )


@dataclass
class GuvicornApp:
    app: str
    settings: list[SecretClass] | None = None
    environments: dict[str, str] | None = None
    contacts: list[Contact] | Contact | None = None

    port: int = 8000
    workers: int = 1
    compute: Compute = field(default_factory=Compute)
    min_scale: int = 0
    max_scale: int = 1

    https_only: bool = True
    domain_names: list[str] | str | None = None
    health_check: str | NetworkHealthCheck | None = None

    tags: list[str] | None = None

    def network_app(self, root_path: Path) -> NetworkApp:
        command = ["/bin/bash", "-c", f"gunicorn {self.app} -k uvicorn.workers.UvicornWorker --bind 0.0.0.0:{self.port} --workers {self.workers}"]

        return NetworkApp(
            command=command,
            port=self.port,
            settings=self.settings,
            environments=self.environments,
            description=f"Gunicorn/Uvicorn application at {self.app}",
            contacts=self.contacts,
            compute=self.compute,
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            https_only=self.https_only,
            domain_names=self.domain_names,
            health_check=self.health_check,
            tags=[*(self.tags or []), "gunicorn"],
        )


@dataclass
class DbtServer:

    settings: list[SecretClass] | None = None
    environments: dict[str, str] | None = None
    contacts: list[Contact] | Contact | None = None

    compute: Compute = field(default_factory=Compute)
    min_scale: int = 0
    max_scale: int = 1

    tags: list[str] | None = None

    https_only: bool = True
    domain_names: list[str] | str | None = None

    def network_app(self, root_path: Path) -> NetworkApp:
        port = 8000
        command = ["bash", "-c", f"dbt docs generate --static && dbt docs serve --port {port} --host 0.0.0.0"]

        return NetworkApp(
            command=command,
            port=port,
            environments=self.environments,
            settings=self.settings,
            contacts=self.contacts,
            health_check="/healthz",
            compute=self.compute,
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            tags=[*(self.tags or []), "dbt"],
            description="DBT Docs server",
            https_only=self.https_only,
            domain_names=self.domain_names
        )



@dataclass
class StreamlitApp:
    app: Callable[[], None] | Callable[[], Awaitable[None]] | str
    settings: list[SecretClass] | None = None
    environments: dict[str, str] | None = None
    contacts: list[Contact] | Contact | None = None

    compute: Compute = field(default_factory=Compute)
    min_scale: int = 0
    max_scale: int = 1

    tags: list[str] | None = None

    https_only: bool = True
    domain_names: list[str] | str | None = None

    def network_app(self, root_path: Path) -> NetworkApp:
        import inspect

        if isinstance(self.app, str):
            app_path = self.app
            description = None
        else:
            function_file = Path(inspect.getfile(self.app))
            relative_function = function_file.relative_to(root_path)
            app_path = relative_function.as_posix()
            description = self.app.__doc__

        command = ["bash", "-c", f"python -m streamlit run {app_path}"]

        return NetworkApp(
            command=command,
            port=8501,
            environments=self.environments,
            settings=self.settings,
            contacts=self.contacts,
            health_check="/healthz",
            compute=self.compute,
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            tags=[*(self.tags or []), "streamlit"],
            description=description,
            https_only=self.https_only,
            domain_names=self.domain_names
        )

class CompiledJob(BaseModel):
    name: str
    function_ref: str
    arguments: dict
    description: str
    cron_schedule: str | None = None
    contacts: list[Contact] | None = None
    settings: list[SettingsValue] | None = None
    environments: dict[str, str] = field(default_factory=dict)
    compute: Compute = field(default_factory=Compute)
    custom_command: str | None = None

    definition_id: str | None = None


    def command(self, project_name: str) -> str:
        if self.custom_command:
            return self.custom_command

        function_ref = self.function_ref
        encoded_args = json.dumps(self.arguments, separators=(',', ':'))
        return f"python -m takk.cli run-job --project-name={project_name} --job-id={self.id()} --file-ref {function_ref} --args '{encoded_args}'"


    def id(self) -> str:
        from hashlib import sha1
        return sha1(self.name.encode(), usedforsecurity=False).hexdigest()


@dataclass
class Job(Generic[T]):
    main_function: Callable[[T], None] | Callable[[T], Awaitable[None]]

    arguments: T

    cron_schedule: str | None = None
    description: str | None = None
    contacts: list[Contact] | Contact | None = None
    settings: list[SecretClass] | None = None
    environments: dict[str, str] = field(default_factory=dict)

    compute: Compute = field(default_factory=Compute)

    async def run(self, arguments: T | None = None) -> None:
        if inspect.iscoroutinefunction(self.main_function):
            await self.main_function(arguments or self.arguments)
        else:
            self.main_function(arguments or self.arguments)

    def used_description(self) -> str:
        if self.description:
            return self.description
        if self.main_function.__doc__:
            return self.main_function.__doc__
        fn_name = getattr(self.main_function, "__name__", repr(self.main_function))
        return f"A cron job with schedule '{self.cron_schedule}' that runs {fn_name}"


    def function_ref(self, root_path: Path) -> str:
        function_file = Path(inspect.getfile(self.main_function))
        relative_function = function_file.relative_to(root_path)
        module_path = relative_function.as_posix().replace("/", ".").removesuffix(".py")
        fn_name = getattr(self.main_function, "__name__", repr(self.main_function))
        return f"{module_path}:{fn_name}"


    def command(self, root_path: Path) -> str:
        function_ref = self.function_ref(root_path)
        encoded_args = self.arguments.model_dump_json()
        return f"bash -c python -m src.apps --file-ref {function_ref} --args '{encoded_args}'"


    def compile(self, name: str) -> CompiledJob:
        return CompiledJob(
            name=name,
            function_ref=self.function_ref(Path.cwd()),
            arguments=self.arguments.model_dump(),
            cron_schedule=self.cron_schedule,
            description=self.used_description(),
            contacts=[self.contacts] if isinstance(self.contacts, Contact) else self.contacts,
            settings=settings_for(self.settings or []),  # type: ignore[arg-type]
            environments=self.environments,
            compute=self.compute
        )

@dataclass
class SubscriberRef:
    function_ref: str
    input_type_ref: str

@dataclass
class Subscriber(Generic[T]):

    method: Callable[[T], None] | Callable[[T], Awaitable[None]] | SubscriberRef

    subject: str
    config: NatsSubscriberConfig
    pub_config: NatsStreamConfig
    contacts: list[Contact] = field(default_factory=list)
    secret_type: list[SecretClass] = field(default_factory=list)
    compute: Compute = field(default_factory=Compute)
    image: DockerBuild | str | Callable[["Project"], DockerBuild] | None = field(default=None)
    environments: dict[str, str] = field(default_factory=dict)

    # Mainly used for testing
    max_iterations: int | None = None


    def function(self) -> Callable[[T], None] | Callable[[T], Awaitable[None]]:
        if isinstance(self.method, SubscriberRef):
            import importlib

            module_parts = self.method.function_ref.split(".")
            module_path = ".".join(module_parts[:-1])
            type_name= module_parts[-1]

            return getattr(importlib.import_module(module_path), type_name)

        return self.method

    def function_ref(self, root_path: Path) -> str:
        if isinstance(self.method, SubscriberRef):
            return self.method.function_ref

        import inspect

        function_file = Path(inspect.getfile(self.method))
        relative_function = function_file.relative_to(root_path)
        module_path = relative_function.as_posix().replace("/", ".").removesuffix(".py")

        fn_name = getattr(self.method, "__name__", repr(self.method))
        return f"{module_path}:{fn_name}"


    def compile(self, name: str, root_path: Path | None = None) -> CompiledSubscriber:

        image = self.image.image_name if isinstance(self.image, DockerBuild) else self.image

        if callable(image):
            image = image(Project(name=name)).image_name

        return CompiledSubscriber(
            name=name,
            function_ref=self.function_ref(root_path or Path.cwd()),
            subject=self.subject,
            broker_type="nats",
            contacts=self.contacts,
            settings=settings_for(self.secret_type or []),  # type: ignore[arg-type]
            compute=self.compute,
            docker_image=image,
            environments=self.environments
        )

    def arg_type(self) -> type[BaseModel]:
        import inspect

        if isinstance(self.method, SubscriberRef):
            import importlib

            module_parts = self.method.input_type_ref.split(".")
            module_path = ".".join(module_parts[:-1])
            type_name= module_parts[-1]

            arg_type = getattr(importlib.import_module(module_path), type_name)
        else:

            sign = inspect.signature(self.method)   
            params = sign.parameters

            assert len(params) == 1
            _, param = list(params.items())[0]

            arg_type = param.annotation

        assert not isinstance(arg_type, str), f"Make sure to not use string annotations for {arg_type}"
        assert issubclass(arg_type, BaseModel), f"Expected a subclass of BaseModel got {arg_type}"
        return arg_type

    async def subscribe(self):
        arg_type = self.arg_type()

        connector = await self.config.subscriber(self.subject)
        connector.max_iterations = self.max_iterations
        await connector.subscribe(self.function(), arg_type) # type: ignore


@dataclass
class NatsStreamConfig:
    auth_settings: type[BaseModel] = field(default=NatsConfig)
    stream: StreamConfig = field(default_factory=StreamConfig)
    deduplicate_key: str | None = field(default=None)

    async def connection(self):
        from pydantic import NatsDsn
        import nats

        settings = self.auth_settings()

        servers = [
            val.encoded_string() for val in
            settings.model_dump().values()
            if isinstance(val, NatsDsn)
        ]

        user_credentials = None

        for key, model_field in type(settings).model_fields.items():
            if ResourceTags.nats_creds_file in model_field.metadata:
                user_credentials = getattr(settings, key)

        if not servers:
            raise ValueError("Unable to find any nats connections. Remember to tag the secret with the NatsDsn type.")

        return await nats.connect(servers=servers, user_credentials=user_credentials)

    async def publisher(self, subject: str):
        from takk.pubsub import NatsStream
        return NatsStream(
            conn=await self.connection(),
            subject=subject,
            deduplicate_key=self.deduplicate_key,
            config=self.stream
        )

@dataclass
class NatsSubscriberConfig:

    auth_settings: type[BaseModel] = field(default=NatsConfig)
    guarantee: Literal["at-least-once", "at-most-once"] = "at-least-once"
    durable: str | None = None
    queue: str | None = None
    consume_config: ConsumerConfig | None = None

    async def subscriber(self, subject: str):
        from takk.pubsub import NatsSubscriber

        conn = await NatsStreamConfig(auth_settings=self.auth_settings).connection()

        return NatsSubscriber(
            conn=conn,
            subject=subject,
            guarantee=self.guarantee,
            durable=self.durable,
            queue=self.queue,
            consume_config=self.consume_config
        )


@dataclass
class PubSub(Generic[T]):
    """
    A pub/sub component.

    Aka. a one to many brodcast message system.

    Currently this only supports NATS Jetstream, but that may change in the future.
    """
    content_type: type[T]
    subject: str

    config: NatsStreamConfig

    def __init__(self, content_type: type[T], subject: str, broker: NatsStreamConfig | None = None) -> None:
        self.content_type = content_type
        self.subject = subject

        self.config = broker or NatsStreamConfig()

        if self.config.deduplicate_key and not self.config.stream.duplicate_window:
            # Default to two minutes
            self.config.stream.duplicate_window = 2 * 60


        if self.config.stream.name is None:
            self.config.stream.name = self.subject.upper().replace(".", "_").replace("*", "any").replace(">", "all")

        if self.config.stream.subjects is None:
            self.config.stream.subjects = [self.subject]


    def subscriber(
        self, 
        method: Callable[[T], None] | Callable[[T], Awaitable[None]] | SubscriberRef, 
        compute: Compute | None = None,
        settings: list[SecretClass] | None = None,
        image: str | DockerBuild | Callable[["Project"], DockerBuild] | None = None,
        config: NatsSubscriberConfig | None = None,
        environments: dict[str, str] | None = None
    ) -> Subscriber[T]:

        if config is None:
            name = method.__name__ if callable(method) else method.function_ref

            config = NatsSubscriberConfig(
                auth_settings=self.config.auth_settings,
                durable=name,
                queue=name
            )

        return Subscriber(
            method=method,
            subject=self.subject,
            config=config,
            pub_config=self.config,
            secret_type=[self.config.auth_settings, *(settings or [])],
            compute=compute or Compute(),
            image=image,
            environments=environments or {}
        )

    async def publish(self, content: T) -> None:
        pub = await self.config.publisher(self.subject)
        await pub.publish(content)


@dataclass
class LokiServer:
    docker_image: str = field(default="grafana/loki")
    compute: Compute = field(default_factory=Compute)

    min_scale: int = 0
    max_scale: int = 1
    tags: list[str] | None = None

    contacts: list[Contact] | Contact | None = None
    domain_names: list[str] | str | None = None

    def network_app(self, root_path: Path) -> NetworkApp:
        return NetworkApp(
            command=None,
            port=3100,
            description="A logging service",
            docker_image=self.docker_image,
            contacts=self.contacts,
            compute=self.compute,
            tags=[*(self.tags or []), "loki"],
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            domain_names=self.domain_names
        )


@dataclass
class UnleashServer:
    """
    project = Project(
        ...,
        unleash_server=UnleashServer()
    )
    """
    settings: list[SecretClass] = field(default_factory=lambda: [UnleashConfig])
    docker_image: str = field(default="unleashorg/unleash-server:latest")
    compute: Compute = field(default_factory=Compute)

    min_scale: int = 0
    max_scale: int = 1
    tags: list[str] | None = None

    contacts: list[Contact] | Contact | None = None

    domain_names: list[str] | str | None = None


    def network_app(self, root_path: Path) -> NetworkApp:
        return NetworkApp(
            command=None,
            port=4242,
            description="A feature toggle service",
            settings=self.settings,  # type: ignore[arg-type]
            docker_image=self.docker_image,
            contacts=self.contacts,
            compute=self.compute,
            tags=[*(self.tags or []), "unleash"],
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            domain_names=self.domain_names
        )


@dataclass
class MlflowServer:
    """
    project = Project(
        ...,
        mlflow_server=MlflowServer(
            domain_names=[
                "mlflow.my-cool-project.com",
                "www.mlflow.my-cool-project.com",
            ]
        )
    )
    """
    mlflow_version: str | None = None
    settings: list[SecretClass] = field(default_factory=lambda: [ObjectStorageConfig])
    docker_image: str = field(default="ghcr.io/mlflow/mlflow")
    compute: Compute = field(default_factory=Compute)

    min_scale: int = 0
    max_scale: int = 1
    tags: list[str] | None = None

    contacts: list[Contact] | Contact | None = None

    domain_names: list[str] | str | None = None


    def network_app(self, root_path: Path) -> NetworkApp:
        mlflow_version = "3.5.0"
        with suppress(ImportError):
            import mlflow  # type: ignore[import-untyped]
            mlflow_version = mlflow.__version__

        if self.mlflow_version:
            mlflow_version = self.mlflow_version

        port = 8000

        if ":" in self.docker_image:
            docker_image = self.docker_image
        else:
            docker_image = f"{self.docker_image}:v{mlflow_version}"

        command = f"mlflow server --host 0.0.0.0 --port {port}"
        if mlflow_version.startswith("3"):
            command = command + " --allowed-hosts=*"

        return NetworkApp(
            command=["bash", "-c", command],
            port=port,
            description=f"An MLFlow Server used for tracking experiments and managing model versions. Using version: {mlflow_version}.",
            settings=self.settings,  # type: ignore[arg-type]
            docker_image=docker_image,
            contacts=self.contacts,
            compute=self.compute,
            tags=[*(self.tags or []), "mlflow-server"],
            min_scale=self.min_scale,
            max_scale=self.max_scale,
            domain_names=self.domain_names
        )



@dataclass
class Worker:
    name: str

    broker_type: Literal["sqs"] = "sqs"

    queue_settings: SqsQueueSettings = field(default_factory=SqsQueueSettings)

    compute: Compute = field(default_factory=Compute)
    settings: list[SecretClass] | SecretClass = field(default_factory=lambda: [SqsConfig])


    def broker(self) -> QueueBroker:
        from takk.queue import SqsQueueBroker

        return SqsQueueBroker(
            config=SqsConfig(), # type: ignore
            queue_settings=self.queue_settings 
        )


    async def queue(self, method: Callable[[T], None] | Callable[[T], Awaitable[None]], payload: T) -> None:
        import inspect 

        function_file = Path(inspect.getfile(method))
        relative_function = function_file.relative_to(Path.cwd())
        module_path = relative_function.as_posix().replace("/", ".").removesuffix(".py")

        logger.info(f"Queueing function {function_file}")
        assert self.broker_type == "sqs", f"Expected SQS worker, got {self.broker_type}"

        broker = self.broker()
        queue = broker.with_name(self.name)

        sign = inspect.signature(method)
        
        assert len(sign.parameters) == 1
        key = list(sign.parameters.keys())[0]

        await queue.send(
            QueueMessage(
                function_ref=f"{module_path}:{getattr(method, '__name__', repr(method))}",
                arguments={key: payload.model_dump()}
            )
        )

    def compile(self) -> CompiledWorker:
        return CompiledWorker(
            name=self.name,
            broker_type=self.broker_type,
            compute=self.compute,
            settings=settings_for(self.settings) if isinstance(self.settings, list) else settings_for([self.settings])
        )


class NetworkAppable(Protocol):

    def network_app(self, root_path: Path) -> NetworkApp:
        ...


class Project:
    name: str
    additional_dirs: list[Path] | None
    testing_dirs: list[Path] | None
    docker_image: str | DockerBuild | Callable[["Project"], DockerBuild] | None
    shared_settings: list[SecretClass] | None

    workers: list[Worker] | None

    components: dict[str, NetworkApp | Job | Subscriber | NetworkAppable | Resource]
    project_file: str = "unknown"


    def __init__(
        self, 
        name: str,
        additional_dirs: Sequence[str | Path] | None = None,
        testing_dirs: Sequence[str | Path] | None = None,
        docker_image: str | DockerBuild | Callable[["Project"], DockerBuild] | None = None, 
        shared_secrets: list[SecretClass] | None = None,
        shared_settings: list[SecretClass] | None = None,
        workers: list[Worker] | None = None, 
        **kwargs: NetworkApp | NetworkAppable | Job | Subscriber | Resource | None
    ):

        self.name = name.replace("_", "-")
        self.additional_dirs = [
            path if isinstance(path, Path) else Path(path)
            for path in additional_dirs
        ] if additional_dirs else None
        self.testing_dirs = [
            path if isinstance(path, Path) else Path(path)
            for path in testing_dirs or ["tests", "conftest.py"]
        ]
        self.workers = workers
        self.docker_image = docker_image
        self.shared_settings = shared_settings
        if not self.shared_settings:
            self.shared_settings = shared_secrets

        self.components = { name: comp for name, comp in kwargs.items() if comp }


class CompiledWorker(BaseModel):
    name: str

    broker_type: Literal["sqs"]
    compute: Compute = field(default_factory=Compute)
    settings: list[SettingsValue] | None = None

    max_scale: int = 1

    resource_id: str | None = None


class CompiledSubscriber(BaseModel):
    name: str
    function_ref: str
    subject: str
    broker_type: Literal["nats"]

    contacts: list[Contact] | None = None
    settings: list[SettingsValue] | None = None
    environments: dict[str, str] = field(default_factory=dict)
    compute: Compute = field(default_factory=Compute)
    docker_image: str | None = None




def _deploy_version(env: str) -> str:
    import subprocess
    from datetime import datetime, timezone

    try:
        status = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, check=True
        )
        if not status.stdout.strip():
            sha = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                capture_output=True, text=True, check=True
            ).stdout.strip()
            return sha
    except Exception:
        pass

    iso = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return f"{env} at {iso}"


class CompiledProject(BaseModel):
    name: str
    docker_image: str | None
    shared_settings: list[SettingsValue]

    network_apps: list[CompiledNetworkApp]
    jobs: list[CompiledJob]

    workers: list[CompiledWorker]
    subscribers: list[CompiledSubscriber]

    resources: list[CompiledResource]

    packages: list[str]
    project_file: str

    revisions: list[Revision]
    version: str | None = None

    @staticmethod
    def from_project(project: Project, packages: list[str], version: str | None = None) -> "CompiledProject":

        current_dir = Path.cwd()

        network_apps = []
        jobs = []
        subs = []
        resources = []

        for name, component in project.components.items():
            if isinstance(component, NetworkApp):
                network_apps.append(component.compile(name))
            elif isinstance(component, Job):
                jobs.append(component.compile(name))
            elif isinstance(component, Subscriber):
                subs.append(component.compile(name, current_dir))
            elif isinstance(component, Resource):
                if name:
                    resources.append(component.resource(name))
                else:
                    resources.append(component.resource("default"))
            else:
                network_apps.append(component.network_app(current_dir).compile(name))


        alembic_file = current_dir / "alembic.ini"

        revisions = []
        if alembic_file.is_file():
            revisions = revisions_for_alembic_config(alembic_file)

        image = None
        if callable(project.docker_image):
            image = project.docker_image(project).image_name
        elif isinstance(project.docker_image, DockerBuild):
            image = project.docker_image.image_name
        else:
            image = project.docker_image


        return CompiledProject(
            name=project.name,
            docker_image=image,
            shared_settings=settings_for(project.shared_settings or []),
            network_apps=network_apps,
            jobs=jobs,
            workers=[queue.compile() for queue in project.workers or []],
            resources=resources,
            subscribers=subs,
            packages=packages,
            project_file=project.project_file,
            revisions=revisions,
            version=version,
        )


default_takk_file = Path().home() / ".config/takk"

class TakkServer(BaseSettings):
    takk_api: str = "https://takk.dev/api/v1"
    takk_token: SecretStr

    @staticmethod
    def read() -> "TakkServer":
        try:
            return TakkServer() # type: ignore
        except ValidationError:
            if not default_takk_file.is_file():
                raise ValueError("Found no env vars or config file. Try to run `takk login`.")
            content = default_takk_file.read_bytes()
            return TakkServer.model_validate_json(content)
            

class DockerCreds(BaseModel):
    registry: str
    password: str
    project_id: str


class UpdateProjectResponse(BaseModel):
    project_id: UUID
    project_env_id: UUID
    docker_tag: UUID | None = Field(default=None)
    missing_secrets_count: int = Field(default=0)


class ServerSideEvent(BaseModel):
    data: str | None = None
    event: str | None = None

    def decode_data(self, content_type: type[T]) -> T:
        if not self.data:
            raise ValueError("No data to decode")
        return content_type.model_validate_json(self.data)

    @staticmethod
    def from_body(content: str) -> "ServerSideEvent":
        fields: dict[str, str] = {}

        for line in content.splitlines():
            if ":" not in line:
                continue

            key, _, value = line.partition(": ")
            if key not in fields:
                fields[key] = value
            else:
                fields[key] += f"\n{value}"

        return ServerSideEvent.model_validate(fields)



@dataclass
class TakkClient:
    settings: TakkServer = field(default_factory=TakkServer.read)

    def client(self) -> AsyncClient:
        auth_headers = {
            "Authorization": f"Bearer {self.settings.takk_token.get_secret_value()}",
            "Content-Type": "application/json"
        }
        return AsyncClient(follow_redirects=True, timeout=20, headers=auth_headers)

    async def auth_cli(self, login_request_id: UUID) -> str:
        url = f"{self.settings.takk_api}/users/cli-login/{login_request_id}"

        async with self.client() as client:
            res = await client.get(url, timeout=60 * 2)

        res.raise_for_status()
        return res.json()["id"]


    async def docker_creds(self, project_name: str) -> DockerCreds:
        url = f"{self.settings.takk_api}/users/registry"
        
        async with self.client() as client:
            res = await client.get(url, params={"project_name": project_name})
        res.raise_for_status()

        return DockerCreds.model_validate(res.json())

    async def deploy(self, project_env_id: UUID) -> None:
        url = f"{self.settings.takk_api}/projects/env/{project_env_id}/deploy"

        auth_headers = {
            "Authorization": f"Bearer {self.settings.takk_token.get_secret_value()}",
        }

        async with AsyncClient(follow_redirects=True, headers=auth_headers) as client:
            async with client.stream(method="POST", url=url, timeout=60 * 10) as stream:
                async for body in stream.aiter_text():
                    if not body.strip():
                        continue
                    try:
                        event = ServerSideEvent.from_body(body)
                        if event.event == "close":
                            continue

                        if event.event == "error":
                            console.print(
                                f"[bold red]❌ {event.data}[/bold red]",
                            )
                        elif event.event == "success":
                            console.print(
                                f"[bold green]✅ {event.data}[/bold green]",
                            )
                        elif event.data:
                            console.print(event.data)
                    except Exception as e:
                        console.print(
                            f"[bold red]An Error Occurred {e}[/bold red]",
                        )


    async def update(self, project: Project, env: str, packages: list[str], version: str | None = None) -> UpdateProjectResponse:
        url = f"{self.settings.takk_api}/projects/{project.name}/{env}"
        compiled = CompiledProject.from_project(project, packages=packages, version=version)

        async with self.client() as client:
            res = await client.put(url, content=compiled.model_dump_json())

        res.raise_for_status()

        return UpdateProjectResponse.model_validate(res.json())

    async def whoami(self) -> dict[str, Any]:
        url = f"{self.settings.takk_api}/users/whoami"

        async with self.client() as client:
            res = await client.get(url)
        res.raise_for_status()
        return res.json()

    async def notify_about_failure(self, project_name: str, job_id: str, exception: Exception) -> None:
        url = f"{self.settings.takk_api}/projects/{project_name}/jobs/{job_id}/notify/failure"

        body = NotifyFailure(
            exception=str(exception)
        )
        async with self.client() as client:
            res = await client.post(url, json=body.model_dump())
        res.raise_for_status()



class QueueMessage(BaseModel):
    function_ref: str
    arguments: dict

    async def run(self) -> None:
        import importlib
        import inspect

        module_name, func_name = self.function_ref.split(":")
        module = importlib.import_module(module_name)
        func = getattr(module, func_name)

        assert callable(func)

        sign = inspect.signature(func)   

        input_args = {}

        for param in sign.parameters.values():

            annotation = param.annotation
            is_optional = False

            if isinstance(annotation, types.UnionType):
                args = annotation.__args__
                is_optional = NoneType in args
                annotation = next(iter(arg for arg in args if NoneType != arg))

            if is_optional and param.name not in self.arguments:
                input_args[param.name] = None
                continue

            if issubclass(annotation, BaseModel):
                input_args[param.name] = annotation.model_validate(self.arguments[param.name])
            else:
                input_args[param.name] = self.arguments[param.name]

        if inspect.iscoroutinefunction(func):
            await func(**input_args)
        else:
            func(**input_args)


class NotifyFailure(BaseModel):
    exception: str
