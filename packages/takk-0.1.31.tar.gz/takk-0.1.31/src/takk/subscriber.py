import inspect
from functools import lru_cache
import logging
from fastapi import FastAPI, Request
from pydantic_settings import BaseSettings
from takk.cli import project_at
from takk.models import Subscriber

logger = logging.getLogger(__name__)

class SubSettings(BaseSettings):
    ref: str
    subscriber_name: str


@lru_cache
def subscription() -> Subscriber:
    settings = SubSettings() # type: ignore
    project = project_at(settings.ref)

    if settings.subscriber_name not in project.components:
        raise ValueError(f"Unable to find subscriber '{settings.subscriber_name}'")

    sub = project.components[settings.subscriber_name]

    if not isinstance(sub, Subscriber):
        raise ValueError(f"Expected a Subscriber type, got {type(sub)}")

    return sub


app = FastAPI()


@app.post("/")
async def subscriber(request: Request) -> None:
    logging.basicConfig(level=logging.INFO)
    body = await request.body()

    sub = subscription()
    arg_type = sub.arg_type()

    content = arg_type.model_validate_json(body)

    if inspect.iscoroutinefunction(sub.method):
        await sub.method(content)
    else:
        sub.method(content)
