from __future__ import annotations

import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from foldermix.converters.base import ConversionResult, ConverterRegistry
from foldermix.converters.text import TextConverter


class TestTextConverter:
    def test_can_convert_py(self) -> None:
        converter = TextConverter()
        assert converter.can_convert(".py") is True

    def test_can_convert_md(self) -> None:
        converter = TextConverter()
        assert converter.can_convert(".md") is True

    def test_cannot_convert_png(self) -> None:
        converter = TextConverter()
        assert converter.can_convert(".png") is False

    def test_convert_text_file(self, tmp_path: Path) -> None:
        f = tmp_path / "hello.py"
        f.write_text("print('hello')\n")
        converter = TextConverter()
        result = converter.convert(f)
        assert "print('hello')" in result.content
        assert result.converter_name == "text"

    def test_convert_utf8(self, tmp_path: Path) -> None:
        f = tmp_path / "unicode.txt"
        f.write_text("Hello 你好 🌍\n", encoding="utf-8")
        converter = TextConverter()
        result = converter.convert(f, encoding="utf-8")
        assert "你好" in result.content

    def test_convert_no_warnings_on_correct_encoding(self, tmp_path: Path) -> None:
        f = tmp_path / "simple.txt"
        f.write_text("simple text")
        converter = TextConverter()
        result = converter.convert(f, encoding="utf-8")
        assert result.warnings == []

    def test_convert_warns_on_encoding_fallback(self, monkeypatch, tmp_path: Path) -> None:
        import foldermix.utils as utils

        f = tmp_path / "simple.txt"
        f.write_text("simple text")
        monkeypatch.setattr(utils, "read_text_with_fallback", lambda *_: ("content", "latin-1"))
        converter = TextConverter()
        result = converter.convert(f, encoding="utf-8")
        assert "Encoding fallback" in result.warnings[0]


class TestConverterRegistry:
    def test_register_and_get(self) -> None:
        registry = ConverterRegistry()
        converter = TextConverter()
        registry.register(converter)
        result = registry.get_converter(".py")
        assert result is converter

    def test_get_none_for_unknown(self) -> None:
        registry = ConverterRegistry()
        result = registry.get_converter(".unknown_xyz")
        assert result is None

    def test_first_registered_wins(self) -> None:
        registry = ConverterRegistry()

        class FakeConverter:
            def can_convert(self, ext: str) -> bool:
                return ext == ".py"

            def convert(self, path: Path, encoding: str = "utf-8") -> ConversionResult:
                return ConversionResult(content="fake", converter_name="fake")

        fake = FakeConverter()
        registry.register(fake)
        registry.register(TextConverter())
        result = registry.get_converter(".py")
        assert result is fake


class TestMarkitdownConverter:
    def test_can_convert_returns_false_when_not_installed(self) -> None:
        from foldermix.converters.markitdown_conv import MarkitdownConverter

        converter = MarkitdownConverter()
        with patch.dict(sys.modules, {"markitdown": None}):
            assert converter.can_convert(".pdf") is False

    def test_can_convert_returns_true_when_installed(self) -> None:
        from foldermix.converters.markitdown_conv import MarkitdownConverter

        mock_markitdown = MagicMock()
        converter = MarkitdownConverter()
        with patch.dict(sys.modules, {"markitdown": mock_markitdown}):
            assert converter.can_convert(".pdf") is True

    def test_supported_extensions(self) -> None:
        from foldermix.converters.markitdown_conv import MarkitdownConverter

        conv = MarkitdownConverter()
        mock_mod = MagicMock()
        with patch.dict(sys.modules, {"markitdown": mock_mod}):
            assert conv.can_convert(".pdf") is True
            assert conv.can_convert(".docx") is True
            assert conv.can_convert(".pptx") is True
            assert conv.can_convert(".xlsx") is True
            assert conv.can_convert(".txt") is False


class TestImageOcrConverter:
    def test_can_convert_supported_extensions_when_installed(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        converter = ImageOcrConverter()
        mock_mod = MagicMock()
        with patch.dict(sys.modules, {"rapidocr_onnxruntime": mock_mod}):
            assert converter.can_convert(".png") is True
            assert converter.can_convert(".jpg") is True
            assert converter.can_convert(".jpeg") is True
            assert converter.can_convert(".gif") is False

    def test_can_convert_returns_false_when_not_installed(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        converter = ImageOcrConverter()
        with patch.dict(sys.modules, {"rapidocr_onnxruntime": None}):
            assert converter.can_convert(".png") is False

    def test_can_convert_returns_false_when_import_is_broken(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        converter = ImageOcrConverter()
        with patch(
            "foldermix.converters.image_ocr.importlib.import_module",
            side_effect=OSError("dlopen boom"),
        ):
            assert converter.can_convert(".png") is False

    def test_extract_ocr_text_handles_tuple_with_line_entries(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        result = ImageOcrConverter._extract_ocr_text(
            ([[None, "hello", 0.99], [None, "world", 0.88]], 0.01)
        )

        assert result == "hello\nworld"

    def test_extract_ocr_text_handles_none(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        assert ImageOcrConverter._extract_ocr_text(None) == ""

    def test_extract_ocr_text_handles_string(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        assert ImageOcrConverter._extract_ocr_text("  hello world  ") == "hello world"

    def test_extract_ocr_text_handles_dict_entries(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        result = ImageOcrConverter._extract_ocr_text(
            [{"text": "alpha"}, {"text": "  beta  "}, {"text": ""}, {"text": None}, {}]
        )

        assert result == "alpha\nbeta"

    def test_extract_ocr_text_skips_blank_line_entries_and_keeps_dict_text(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        result = ImageOcrConverter._extract_ocr_text(
            [[None, "   ", 0.1], {"text": "gamma"}, object()]
        )

        assert result == "gamma"

    def test_extract_ocr_text_handles_non_list_object(self) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        assert ImageOcrConverter._extract_ocr_text(object()) == ""

    def test_convert_returns_ocr_text(self, tmp_path: Path) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        image = tmp_path / "scan.png"
        image.write_bytes(b"fake-image")

        class _RapidOCR:
            def __call__(self, image_path):
                assert image_path == str(image)
                return ([[None, "hello world", 0.99]], 0.01)

        with patch.dict(sys.modules, {"rapidocr_onnxruntime": MagicMock(RapidOCR=_RapidOCR)}):
            result = ImageOcrConverter().convert(image)

        assert result.content == "hello world"
        assert result.warnings == []
        assert result.converter_name == "rapidocr"
        assert result.original_mime == "image/png"

    def test_convert_warns_when_ocr_returns_no_text(self, tmp_path: Path) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        image = tmp_path / "scan.jpg"
        image.write_bytes(b"fake-image")

        class _RapidOCR:
            def __call__(self, _image_path):
                return ([], 0.01)

        with patch.dict(sys.modules, {"rapidocr_onnxruntime": MagicMock(RapidOCR=_RapidOCR)}):
            result = ImageOcrConverter().convert(image)

        assert result.content == ""
        assert result.warnings == ["Image OCR produced no text."]
        assert result.original_mime == "image/jpeg"

    def test_convert_reuses_cached_engine_within_thread(self, tmp_path: Path) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        image1 = tmp_path / "scan1.png"
        image2 = tmp_path / "scan2.png"
        image1.write_bytes(b"fake-image-1")
        image2.write_bytes(b"fake-image-2")

        init_calls = 0
        seen_paths: list[str] = []

        class _RapidOCR:
            def __init__(self) -> None:
                nonlocal init_calls
                init_calls += 1

            def __call__(self, image_path):
                seen_paths.append(image_path)
                return ([[None, Path(image_path).stem, 0.99]], 0.01)

        converter = ImageOcrConverter()
        with patch.dict(sys.modules, {"rapidocr_onnxruntime": MagicMock(RapidOCR=_RapidOCR)}):
            result1 = converter.convert(image1)
            result2 = converter.convert(image2)

        assert init_calls == 1
        assert seen_paths == [str(image1), str(image2)]
        assert result1.content == "scan1"
        assert result2.content == "scan2"

    def test_convert_warns_when_engine_init_fails(self, tmp_path: Path) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        image = tmp_path / "scan.jpeg"
        image.write_bytes(b"fake-image")

        class _RapidOCR:
            def __init__(self) -> None:
                raise RuntimeError("init boom")

        with patch.dict(sys.modules, {"rapidocr_onnxruntime": MagicMock(RapidOCR=_RapidOCR)}):
            result = ImageOcrConverter().convert(image)

        assert result.content == ""
        assert result.warnings == ["OCR engine initialization failed: init boom"]

    def test_convert_warns_when_import_is_broken(self, tmp_path: Path) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        image = tmp_path / "scan.png"
        image.write_bytes(b"fake-image")

        with patch(
            "foldermix.converters.image_ocr.importlib.import_module",
            side_effect=RuntimeError("native boom"),
        ):
            result = ImageOcrConverter().convert(image)

        assert result.content == ""
        assert result.warnings == ["OCR dependencies missing: native boom"]

    def test_convert_raises_in_strict_mode_when_import_is_broken(self, tmp_path: Path) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        image = tmp_path / "scan.png"
        image.write_bytes(b"fake-image")

        with patch(
            "foldermix.converters.image_ocr.importlib.import_module",
            side_effect=RuntimeError("native boom"),
        ):
            with pytest.raises(RuntimeError, match="OCR dependencies missing: native boom"):
                ImageOcrConverter().convert(image, ocr_strict=True)

    def test_convert_warns_when_runtime_fails(self, tmp_path: Path) -> None:
        from foldermix.converters.image_ocr import ImageOcrConverter

        image = tmp_path / "scan.png"
        image.write_bytes(b"fake-image")

        class _RapidOCR:
            def __call__(self, _image_path):
                raise RuntimeError("ocr boom")

        with patch.dict(sys.modules, {"rapidocr_onnxruntime": MagicMock(RapidOCR=_RapidOCR)}):
            result = ImageOcrConverter().convert(image)

        assert result.content == ""
        assert result.warnings == ["Image OCR failed: ocr boom"]


class TestNotebookConverter:
    def test_can_convert_ipynb(self) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        converter = NotebookConverter()
        assert converter.can_convert(".ipynb") is True
        assert converter.can_convert(".txt") is False

    def test_convert_notebook_without_outputs(self, tmp_path: Path) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "demo.ipynb"
        notebook.write_text(
            (
                '{"metadata":{"language_info":{"name":"python"}},"cells":['
                '{"cell_type":"markdown","source":["# Title\\n","Intro"]},'
                '{"cell_type":"code","source":["print(1)\\n"],"outputs":['
                '{"output_type":"stream","name":"stdout","text":["1\\\\n"]}]}]}'
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=False).convert(notebook)

        assert "### Markdown Cell 1" in result.content
        assert "### Code Cell 2" in result.content
        assert "Language: python" in result.content
        assert "    print(1)" in result.content
        assert "#### Outputs" not in result.content
        assert result.converter_name == "ipynb"

    def test_convert_notebook_with_outputs(self, tmp_path: Path) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "demo.ipynb"
        notebook.write_text(
            (
                '{"metadata":{"language_info":{"name":"python"}},"cells":['
                '{"cell_type":"code","source":["print(1)\\n"],"outputs":['
                '{"output_type":"stream","name":"stdout","text":["1\\\\n"]},'
                '{"output_type":"execute_result","data":{"text/plain":["2"]}}]}]}'
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "#### Outputs" in result.content
        assert "Output 1:" in result.content
        assert "Output 2:" in result.content
        assert "    1" in result.content
        assert "    2" in result.content
        assert "```text" not in result.content
        assert "1" in result.content
        assert "2" in result.content

    def test_convert_notebook_preserves_leading_indentation(self, tmp_path: Path) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "indented.ipynb"
        notebook.write_text(
            (
                '{"metadata":{"language_info":{"name":"python"}},"cells":['
                '{"cell_type":"code","source":["    if True:\\n","        print(1)\\n"]}'
                "]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter().convert(notebook)

        assert "    if True:" in result.content
        assert "        print(1)" in result.content

    def test_convert_notebook_trims_trailing_blank_lines_without_losing_content(
        self, tmp_path: Path
    ) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "trailing-blanks.ipynb"
        notebook.write_text(
            (
                '{"metadata":{"language_info":{"name":"python"}},"cells":['
                '{"cell_type":"code","source":["print(1)\\n","\\n","   \\n"]}'
                "]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter().convert(notebook)

        assert "    print(1)" in result.content
        assert "    \n\n" not in result.content

    def test_convert_notebook_covers_raw_custom_and_output_fallbacks(self, tmp_path: Path) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "rich.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '{"cell_type":"raw","source":["  raw note  "]},'
                '{"cell_type":"custom","source":["custom payload"]},'
                '{"cell_type":"code","source":["x = 1\\n"],"outputs":['
                '{"output_type":"display_data","data":{"application/json":{"value":1}}},'
                '{"output_type":"error","ename":"ValueError","evalue":"bad","traceback":["Trace 1","Trace 2"]},'
                '{"output_type":"mystery","payload":{"ok":true}}'
                "]}]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "### Raw Cell 1" in result.content
        assert "raw note" in result.content
        assert "### Custom Cell 2" in result.content
        assert "custom payload" in result.content
        assert "output_type: display_data" in result.content
        assert "data keys: application/json" in result.content
        assert "Trace 1" in result.content
        assert "Trace 2" in result.content
        assert "output_type: mystery" in result.content
        assert "top-level keys: payload" in result.content
        assert '"ok": true' not in result.content

    def test_convert_notebook_summarizes_empty_data_without_dumping_payloads(
        self, tmp_path: Path
    ) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "empty-data.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '{"cell_type":"code","source":["show()\\n"],"outputs":['
                '{"output_type":"display_data","data":{},"metadata":{"collapsed":true}}'
                "]}]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "output_type: display_data" in result.content
        assert "\n    data keys:" not in result.content
        assert "metadata keys: collapsed" in result.content

    def test_convert_notebook_error_without_traceback(self, tmp_path: Path) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "errors.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '{"cell_type":"code","source":["run()\\n"],"outputs":['
                '{"output_type":"error","ename":"RuntimeError","evalue":"boom"}'
                "]}]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "RuntimeError: boom" in result.content

    def test_convert_notebook_ignores_non_dict_cells_and_empty_content(
        self, tmp_path: Path
    ) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "sparse.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '"skip-me",'
                '{"cell_type":"markdown","source":42},'
                '{"cell_type":"code","source":"","outputs":[]}'
                "]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=False).convert(notebook)

        assert result.content == ""

    def test_convert_notebook_covers_empty_branches(self, tmp_path: Path) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "branches.ipynb"
        notebook.write_text(
            (
                '{"metadata":"not-a-dict","cells":['
                '{"cell_type":"raw","source":""},'
                '{"cell_type":"custom","source":""},'
                '{"cell_type":"code","source":"","outputs":['
                '{"output_type":"display_data","data":"not-a-dict"},'
                '{"output_type":"error","traceback":["","   "]},'
                '{"output_type":"stream","text":["","   "]}'
                "]}]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "### Code Cell 3" in result.content
        assert "output_type: display_data" in result.content
        assert "Error:" in result.content
        assert "#### Outputs" in result.content

    def test_convert_notebook_skips_non_dict_outputs_and_summarizes_rich_payloads(
        self, tmp_path: Path
    ) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "rich-payloads.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '{"cell_type":"code","source":["show()\\n"],"outputs":['
                '"skip-me",'
                '{"output_type":"display_data","data":{"image/png":"AAAA","text/html":"<b>x</b>"},"metadata":{"width":100}}'
                "]}]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "output_type: display_data" in result.content
        assert "data keys: image/png, text/html" in result.content
        assert "metadata keys: width" in result.content
        assert '"image/png": "AAAA"' not in result.content
        assert "skip-me" not in result.content

    def test_convert_notebook_reads_utf8_bom_independent_of_text_encoding(
        self, tmp_path: Path
    ) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "bom.ipynb"
        notebook.write_bytes(
            ('\ufeff{"metadata":{},"cells":[{"cell_type":"markdown","source":["שלום"]}]}').encode()
        )

        result = NotebookConverter().convert(notebook, encoding="latin-1")

        assert "### Markdown Cell 1" in result.content
        assert "שלום" in result.content

    def test_convert_notebook_treats_update_display_data_as_rich_output(
        self, tmp_path: Path
    ) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "update-display.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '{"cell_type":"code","source":["show()\\n"],"outputs":['
                '{"output_type":"update_display_data","data":{"image/png":"AAAA","text/html":"<b>x</b>"},"metadata":{"width":100}}'
                "]}]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "output_type: update_display_data" in result.content
        assert "data keys: image/png, text/html" in result.content
        assert "metadata keys: width" in result.content
        assert '"image/png": "AAAA"' not in result.content

    def test_convert_notebook_summarizes_unknown_outputs_without_dumping_payloads(
        self, tmp_path: Path
    ) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "unknown-output.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '{"cell_type":"code","source":["show()\\n"],"outputs":['
                '{"output_type":"vendor_blob","payload":"AAAA","data":{"image/png":"BBBB"},"metadata":{"width":100}}'
                "]}]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "output_type: vendor_blob" in result.content
        assert "top-level keys: data, metadata, payload" in result.content
        assert "data keys: image/png" in result.content
        assert "metadata keys: width" in result.content
        assert '"payload": "AAAA"' not in result.content

    def test_convert_notebook_summarizes_unknown_output_without_extra_keys(
        self, tmp_path: Path
    ) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "unknown-minimal.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '{"cell_type":"code","source":["show()\\n"],"outputs":['
                '{"output_type":"vendor_blob"}'
                "]}]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert "output_type: vendor_blob" in result.content
        assert "top-level keys:" not in result.content

    def test_convert_notebook_skips_empty_rendered_outputs(self, tmp_path: Path) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        notebook = tmp_path / "empty-outputs.ipynb"
        notebook.write_text(
            (
                '{"metadata":{},"cells":['
                '{"cell_type":"code","source":"",'
                '"outputs":[{"output_type":"stream","text":["","   "]}]}'
                "]}"
            ),
            encoding="utf-8",
        )

        result = NotebookConverter(include_outputs=True).convert(notebook)

        assert result.content == ""

    def test_convert_notebook_validates_root_and_cells(self, tmp_path: Path) -> None:
        from foldermix.converters.ipynb import NotebookConverter

        bad_root = tmp_path / "bad-root.ipynb"
        bad_root.write_text('["not", "an", "object"]', encoding="utf-8")

        bad_cells = tmp_path / "bad-cells.ipynb"
        bad_cells.write_text('{"metadata":{},"cells":"oops"}', encoding="utf-8")

        converter = NotebookConverter()

        with pytest.raises(RuntimeError, match="Notebook root must be a JSON object"):
            converter.convert(bad_root)

        with pytest.raises(RuntimeError, match="Notebook must contain a list of cells"):
            converter.convert(bad_cells)


class TestPdfFallbackConverter:
    def test_can_convert_returns_false_when_not_installed(self) -> None:
        from foldermix.converters.pdf_fallback import PdfFallbackConverter

        converter = PdfFallbackConverter()
        with patch.dict(sys.modules, {"pypdf": None}):
            assert converter.can_convert(".pdf") is False

    def test_can_convert_pdf(self) -> None:
        from foldermix.converters.pdf_fallback import PdfFallbackConverter

        converter = PdfFallbackConverter()
        mock_pypdf = MagicMock()
        with patch.dict(sys.modules, {"pypdf": mock_pypdf}):
            assert converter.can_convert(".pdf") is True

    def test_cannot_convert_non_pdf(self) -> None:
        from foldermix.converters.pdf_fallback import PdfFallbackConverter

        converter = PdfFallbackConverter()
        mock_pypdf = MagicMock()
        with patch.dict(sys.modules, {"pypdf": mock_pypdf}):
            assert converter.can_convert(".txt") is False
