"""Stealth JavaScript payloads."""
