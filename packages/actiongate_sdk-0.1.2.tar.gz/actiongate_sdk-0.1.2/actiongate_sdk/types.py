from __future__ import annotations

from typing import Any, Dict, List, Literal, NotRequired, TypedDict


class X402PaymentRequirements(TypedDict, total=False):
    scheme: str
    network: str
    asset: str
    amount: str
    payTo: str
    maxTimeoutSeconds: int
    extra: Dict[str, Any]


class X402ResourceInfo(TypedDict, total=False):
    url: str
    description: str
    mimeType: str


class X402PaymentRequired(TypedDict, total=False):
    x402Version: int
    error: str
    resource: X402ResourceInfo
    accepts: List[X402PaymentRequirements]
    extensions: Dict[str, Any]


class X402PaymentResponse(TypedDict, total=False):
    success: bool
    errorReason: str
    errorMessage: str
    payer: str
    transaction: str
    network: str
    extensions: Dict[str, Any]


class Actor(TypedDict):
    actor_id: str
    wallet_address: NotRequired[str]


class Action(TypedDict, total=False):
    action_type: str
    network: str
    target: str


class PolicySpec(TypedDict, total=False):
    policy_id: str
    overrides: Dict[str, Any]


class UsageReceipt(TypedDict):
    request_id: str
    units_billed: int
    price_per_unit_usd: str
    currency: Literal["USD"]
    payment_reference: str
    signature: str


class ReasonCode(TypedDict):
    code: str
    message: str


class ErrorBody(TypedDict, total=False):
    code: str
    message: str
    request_id: str
    details: Dict[str, Any]


class ErrorEnvelope(TypedDict):
    error: ErrorBody


class RiskScoreAction(Action, total=False):
    amount: str
    asset_symbol: str


class RiskScoreRequest(TypedDict):
    actor: Actor
    action: RiskScoreAction
    request_id: NotRequired[str]
    context: NotRequired[Dict[str, Any]]


class RiskScoreResponse(TypedDict):
    request_id: str
    score: int
    severity: Literal["low", "medium", "high", "critical"]
    reason_codes: List[ReasonCode]
    confidence: float
    confidence_sources: NotRequired[List[str]]
    latency_ms: int
    usage_receipt: UsageReceipt


class SimulateRequest(TypedDict):
    actor: Actor
    action: Dict[str, Any]
    request_id: NotRequired[str]
    context: NotRequired[Dict[str, Any]]


class SimulateResponse(TypedDict):
    request_id: str
    expected_cost_usd: str
    failure_probability: float
    expected_outcome: str
    notes: List[str]
    simulation_source: NotRequired[Literal["tenderly", "heuristic"]]
    latency_ms: int
    usage_receipt: UsageReceipt


class ViolatedRule(TypedDict, total=False):
    rule_id: str
    description: str
    severity: Literal["info", "warning", "blocking"]


class SafeAlternative(TypedDict, total=False):
    action: Dict[str, Any]
    rationale: str


class PolicyGateRequest(TypedDict):
    actor: Actor
    action: Dict[str, Any]
    policy: PolicySpec
    request_id: NotRequired[str]
    context: NotRequired[Dict[str, Any]]


class PolicyGateResponse(TypedDict):
    request_id: str
    decision: Literal["allow", "deny", "allow_with_limits"]
    violated_rules: List[ViolatedRule]
    safe_alternative: NotRequired[SafeAlternative]
    latency_ms: int
    usage_receipt: UsageReceipt
