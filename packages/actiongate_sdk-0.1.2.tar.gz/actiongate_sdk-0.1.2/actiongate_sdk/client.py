from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional, TypeVar, cast
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .types import (
    ErrorEnvelope,
    PolicyGateRequest,
    PolicyGateResponse,
    RiskScoreRequest,
    RiskScoreResponse,
    SimulateRequest,
    SimulateResponse,
    X402PaymentRequired,
    X402PaymentResponse,
)

TResponse = TypeVar("TResponse")

PAYMENT_SIGNATURE_HEADER = "PAYMENT-SIGNATURE"
PAYMENT_REQUIRED_HEADER = "PAYMENT-REQUIRED"
PAYMENT_RESPONSE_HEADER = "PAYMENT-RESPONSE"


@dataclass
class ActionGateClientConfig:
    base_url: str = "https://api.actiongate.xyz"
    api_key: Optional[str] = None
    payment_signature: Optional[str] = None
    x402_proof: Optional[str] = None
    timeout_seconds: float = 15.0


class ActionGateError(Exception):
    def __init__(
        self,
        message: str,
        *,
        status_code: int,
        code: Optional[str] = None,
        request_id: Optional[str] = None,
        details: Optional[Dict[str, Any]] = None,
        payment_required: Optional[X402PaymentRequired] = None,
        payment_response: Optional[X402PaymentResponse] = None,
    ) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.code = code
        self.request_id = request_id
        self.details = details
        self.payment_required = payment_required
        self.payment_response = payment_response


class ActionGateClient:
    def __init__(
        self,
        *,
        base_url: str = "https://api.actiongate.xyz",
        api_key: Optional[str] = None,
        payment_signature: Optional[str] = None,
        x402_proof: Optional[str] = None,
        timeout_seconds: float = 15.0,
        opener: Optional[Callable[[Request, float], Any]] = None,
    ) -> None:
        self._config = ActionGateClientConfig(
            base_url=base_url.rstrip("/"),
            api_key=api_key,
            payment_signature=payment_signature,
            x402_proof=x402_proof,
            timeout_seconds=timeout_seconds,
        )
        self._opener = opener or (lambda request, timeout: urlopen(request, timeout=timeout))
        self.last_payment_response: Optional[X402PaymentResponse] = None

    def risk_score(self, payload: RiskScoreRequest) -> RiskScoreResponse:
        return self._request("/v1/risk-score", payload, RiskScoreResponse)

    def simulate(self, payload: SimulateRequest) -> SimulateResponse:
        return self._request("/v1/simulate", payload, SimulateResponse)

    def policy_gate(self, payload: PolicyGateRequest) -> PolicyGateResponse:
        return self._request("/v1/policy-gate", payload, PolicyGateResponse)

    def _request(
        self, path: str, payload: Dict[str, Any], response_type: type[TResponse]
    ) -> TResponse:
        del response_type  # Runtime no-op; preserved for typed call sites.

        headers: Dict[str, str] = {"Content-Type": "application/json"}
        if self._config.api_key:
            headers["X-API-Key"] = self._config.api_key

        signature = self._config.payment_signature or self._config.x402_proof
        if signature:
            headers[PAYMENT_SIGNATURE_HEADER] = signature

        body = json.dumps(payload).encode("utf-8")
        request = Request(
            f"{self._config.base_url}{path}",
            data=body,
            headers=headers,
            method="POST",
        )

        try:
            raw_response = self._opener(request, self._config.timeout_seconds)
            status_code = getattr(raw_response, "status", 200)
            raw_payload = raw_response.read().decode("utf-8")
            parsed_payload: Any = json.loads(raw_payload) if raw_payload else {}

            payment_required = _decode_base64_json(
                raw_response.headers.get(PAYMENT_REQUIRED_HEADER)
            )
            payment_response = _decode_base64_json(
                raw_response.headers.get(PAYMENT_RESPONSE_HEADER)
            )
            self.last_payment_response = cast(Optional[X402PaymentResponse], payment_response)

            if status_code >= 400:
                raise self._build_error(
                    status_code,
                    parsed_payload,
                    payment_required=cast(Optional[X402PaymentRequired], payment_required),
                    payment_response=cast(Optional[X402PaymentResponse], payment_response),
                )
            return cast(TResponse, parsed_payload)
        except HTTPError as exc:
            error_payload = _safe_load_json(exc.read().decode("utf-8"))
            payment_required = _decode_base64_json(exc.headers.get(PAYMENT_REQUIRED_HEADER))
            payment_response = _decode_base64_json(exc.headers.get(PAYMENT_RESPONSE_HEADER))
            raise self._build_error(
                exc.code,
                error_payload,
                payment_required=cast(Optional[X402PaymentRequired], payment_required),
                payment_response=cast(Optional[X402PaymentResponse], payment_response),
            ) from exc
        except URLError as exc:
            raise ActionGateError(
                f"Network failure: {exc.reason}",
                status_code=0,
                code="NETWORK_ERROR",
            ) from exc

    def _build_error(
        self,
        status_code: int,
        payload: Any,
        *,
        payment_required: Optional[X402PaymentRequired] = None,
        payment_response: Optional[X402PaymentResponse] = None,
    ) -> ActionGateError:
        if _is_error_envelope(payload):
            error_body = payload["error"]
            return ActionGateError(
                error_body.get("message", f"ActionGate request failed ({status_code})."),
                status_code=status_code,
                code=error_body.get("code"),
                request_id=error_body.get("request_id"),
                details=cast(Optional[Dict[str, Any]], error_body.get("details")),
                payment_required=payment_required,
                payment_response=payment_response,
            )
        return ActionGateError(
            f"ActionGate request failed ({status_code}).",
            status_code=status_code,
            code="REQUEST_FAILED",
            payment_required=payment_required,
            payment_response=payment_response,
        )


def _is_error_envelope(payload: Any) -> bool:
    if not isinstance(payload, dict):
        return False
    error = payload.get("error")
    return isinstance(error, dict) and isinstance(error.get("code"), str)


def _safe_load_json(value: str) -> Any:
    try:
        return json.loads(value)
    except json.JSONDecodeError:
        return {}


def _decode_base64_json(value: Optional[str]) -> Optional[Dict[str, Any]]:
    if value is None or value == "":
        return None
    try:
        decoded = base64.b64decode(value).decode("utf-8")
        parsed = json.loads(decoded)
        if isinstance(parsed, dict):
            return cast(Dict[str, Any], parsed)
        return None
    except Exception:
        return None
