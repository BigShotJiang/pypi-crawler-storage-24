# actiongate-sdk

Python SDK for the ActionGate API.

## Install

```bash
pip install actiongate-sdk
```

## Methods

- `risk_score(payload)`
- `simulate(payload)`
- `policy_gate(payload)`

## Example

```python
from actiongate_sdk import ActionGateClient

client = ActionGateClient(base_url="https://api.actiongate.xyz")
result = client.risk_score({
    "actor": {"actor_id": "treasury-bot"},
    "action": {"action_type": "transfer", "network": "base", "asset_symbol": "USDC", "amount": "2500"},
})
```

## x402 V2 Support

- Sends `PAYMENT-SIGNATURE` when `payment_signature` is configured.
- Parses `PAYMENT-REQUIRED` and `PAYMENT-RESPONSE`.
- Exposes parsed metadata via `ActionGateError` and `client.last_payment_response`.
