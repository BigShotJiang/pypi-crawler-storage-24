# SkillBroker LangChain Integration

Add expert knowledge to your LangChain agents with [SkillBroker](https://skillbroker.io) - the marketplace where AI agents pay for human expertise.

## Installation

```bash
pip install skillbroker-langchain
```

## Quick Start

### Using a Specific Skill

```python
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain_openai import ChatOpenAI
from langchain_core.prompts import ChatPromptTemplate
from skillbroker_langchain import SkillBrokerTool

# Create a tool for a specific skill
tax_advisor = SkillBrokerTool(
    skill_id="freelancer-tax-advisor",
    name="tax_advisor",
    description="Get expert advice on freelancer and self-employment tax questions"
)

# Set up your agent
llm = ChatOpenAI(model="gpt-4")
prompt = ChatPromptTemplate.from_messages([
    ("system", "You are a helpful assistant. Use the tax_advisor tool for tax questions."),
    ("human", "{input}"),
    ("placeholder", "{agent_scratchpad}"),
])

agent = create_openai_tools_agent(llm, [tax_advisor], prompt)
executor = AgentExecutor(agent=agent, tools=[tax_advisor])

# Ask a question
result = executor.invoke({"input": "Can I deduct my home office as a freelancer?"})
print(result["output"])
```

### Searching for Skills

```python
from skillbroker_langchain import SkillBrokerSearchTool

# Create a search tool
search = SkillBrokerSearchTool()

# Find relevant skills
results = search.invoke({"query": "financial planning"})
print(results)
```

### Dynamic Expert Tool

Let the agent automatically find and use the right skill:

```python
from skillbroker_langchain import SkillBrokerDynamicTool

# This tool can handle any domain question
expert = SkillBrokerDynamicTool(
    name="expert_knowledge",
    description="Get expert knowledge on any specialized topic"
)

# The tool will search for and invoke the best matching skill
result = expert.invoke({"query": "What's the best way to structure a holding company?"})
```

### Using the Client Directly

```python
from skillbroker_langchain import SkillBrokerClient

client = SkillBrokerClient()

# Get registry info
info = client.get_registry_info()
print(f"Total skills available: {info['stats']['totalSkills']}")

# Search for skills
results = client.search("machine learning")
for skill in results.skills:
    print(f"- {skill.name}: {skill.description}")

# Get top-rated skills
top_skills = client.get_top_skills(limit=5)

# Invoke a skill directly
response = client.invoke("skill-id", "Your question here")
print(response.response)
```

## Configuration

### Environment Variables

```bash
# Optional: Override the API URL (defaults to https://api.skillbroker.io)
export SKILLBROKER_API_URL="https://api.skillbroker.io"

# Optional: API key for authenticated requests
export SKILLBROKER_API_KEY="your-api-key"
```

### Programmatic Configuration

```python
from skillbroker_langchain import SkillBrokerClient, SkillBrokerTool

# Configure client
client = SkillBrokerClient(
    api_url="https://api.skillbroker.io",
    api_key="your-api-key",
    timeout=30,
)

# Configure tools
tool = SkillBrokerTool(
    skill_id="my-skill",
    api_url="https://api.skillbroker.io",
    api_key="your-api-key",
)
```

## Available Tools

| Tool | Description |
|------|-------------|
| `SkillBrokerTool` | Invoke a specific skill by ID |
| `SkillBrokerSearchTool` | Search the marketplace for skills |
| `SkillBrokerDynamicTool` | Automatically find and invoke the best skill |

## Examples

### Multi-Tool Agent

```python
from langchain.agents import AgentExecutor, create_openai_tools_agent
from langchain_openai import ChatOpenAI
from skillbroker_langchain import SkillBrokerTool, SkillBrokerSearchTool

# Create multiple skill tools
tax_tool = SkillBrokerTool(
    skill_id="freelancer-tax-advisor",
    name="tax_advisor",
    description="Tax advice for freelancers"
)

legal_tool = SkillBrokerTool(
    skill_id="contract-reviewer",
    name="contract_advisor",
    description="Contract and legal document review"
)

search_tool = SkillBrokerSearchTool()

# Use all tools in your agent
tools = [tax_tool, legal_tool, search_tool]
agent = create_openai_tools_agent(llm, tools, prompt)
```

### With CrewAI

```python
from crewai import Agent, Task, Crew
from skillbroker_langchain import SkillBrokerTool

# Create SkillBroker tools
tax_tool = SkillBrokerTool(
    skill_id="freelancer-tax-advisor",
    name="tax_advisor",
    description="Expert tax advice"
)

# Create a CrewAI agent with the tool
tax_agent = Agent(
    role="Tax Consultant",
    goal="Provide accurate tax advice",
    backstory="You are an expert tax consultant.",
    tools=[tax_tool],
)

task = Task(
    description="Help the user understand their tax obligations",
    agent=tax_agent,
)

crew = Crew(agents=[tax_agent], tasks=[task])
result = crew.kickoff()
```

## API Reference

### SkillBrokerClient

```python
client = SkillBrokerClient(api_url=None, api_key=None, timeout=30)

# Methods
client.get_registry_info() -> dict
client.search(query=None, category=None, limit=20) -> SearchResult
client.get_skill(skill_id) -> Skill
client.invoke(skill_id, query, context=None) -> SkillResponse
client.get_categories() -> list
client.get_top_skills(limit=10, category=None) -> list[Skill]
client.get_recommendations(task_description, limit=5) -> list[Skill]
```

### Models

```python
from skillbroker_langchain import Skill, SkillResponse, SkillQuery

# Skill attributes
skill.id
skill.name
skill.description
skill.category
skill.pricing
skill.stats
skill.quality

# Response attributes
response.success
response.response
response.skill_id
response.tokens_used
response.cost
```

## Support

- Documentation: https://skillbroker.io/docs
- API Reference: https://api.skillbroker.io/swagger
- Issues: https://github.com/skillbroker/skillbroker-langchain/issues
- Email: contact@skillbroker.io

## License

MIT License - see LICENSE file for details.
