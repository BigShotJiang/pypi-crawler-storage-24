"""
tests/test_themes.py
Basic smoke tests for all three themes.
Run with:  pytest tests/
"""
import sys
sys.path.insert(0, "..")

import pytest
import matplotlib
matplotlib.use("Agg")  # headless — no display needed
import matplotlib.pyplot as plt

import trishade as ts              # ✅ lowercase folder name


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------

def _close():
    plt.close("all")


# ---------------------------------------------------------------------------
# rosepine
# ---------------------------------------------------------------------------

class TestRosePine:
    def test_variant_count(self):
        assert len(ts.rosepine.VARIANTS) == 20

    @pytest.mark.parametrize("v", ts.rosepine.VARIANTS)
    def test_apply_returns_dict(self, v):
        c = ts.rosepine.apply(v); _close()
        assert isinstance(c, dict)
        assert "base" in c and "text" in c

    @pytest.mark.parametrize("v", ts.rosepine.VARIANTS)
    def test_palette_length(self, v):
        pal = ts.rosepine.palette(v)
        assert len(pal) == 20
        assert len(set(pal)) == 20          # all 20 must be unique
        assert all(p.startswith("#") and len(p) == 7 for p in pal)

    def test_subplots(self):
        fig, ax = ts.rosepine.subplots(1, 1, variant="moon"); _close()
        assert fig is not None

    def test_invalid_variant(self):
        with pytest.raises(ValueError):
            ts.rosepine.apply("invalid")


# ---------------------------------------------------------------------------
# dracula
# ---------------------------------------------------------------------------

class TestDracula:
    def test_variant_count(self):
        assert len(ts.dracula.VARIANTS) == 20

    @pytest.mark.parametrize("v", ts.dracula.VARIANTS)
    def test_apply_returns_dict(self, v):
        c = ts.dracula.apply(v); _close()
        assert isinstance(c, dict)
        assert "base" in c and "text" in c

    @pytest.mark.parametrize("v", ts.dracula.VARIANTS)
    def test_palette_length(self, v):
        pal = ts.dracula.palette(v)
        assert len(pal) == 20
        assert len(set(pal)) == 20
        assert all(p.startswith("#") and len(p) == 7 for p in pal)

    def test_subplots(self):
        fig, ax = ts.dracula.subplots(variant="classic"); _close()
        assert fig is not None

    def test_invalid_variant(self):
        with pytest.raises(ValueError):
            ts.dracula.apply("invalid")


# ---------------------------------------------------------------------------
# palenight
# ---------------------------------------------------------------------------

class TestPalenight:
    def test_variant_count(self):
        assert len(ts.palenight.VARIANTS) == 20

    @pytest.mark.parametrize("v", ts.palenight.VARIANTS)
    def test_apply_returns_dict(self, v):
        c = ts.palenight.apply(v); _close()
        assert isinstance(c, dict)
        assert "base" in c and "text" in c

    @pytest.mark.parametrize("v", ts.palenight.VARIANTS)
    def test_palette_length(self, v):
        pal = ts.palenight.palette(v)
        assert len(pal) == 20
        assert len(set(pal)) == 20
        assert all(p.startswith("#") and len(p) == 7 for p in pal)

    def test_subplots(self):
        fig, ax = ts.palenight.subplots(variant="default"); _close()
        assert fig is not None

    def test_invalid_variant(self):
        with pytest.raises(ValueError):
            ts.palenight.apply("invalid")


# ---------------------------------------------------------------------------
# grid options
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("grid", [True, False, "x", "y"])
def test_grid_options(grid):
    import matplotlib as mpl
    ts.dracula.apply(grid=grid); _close()
    assert mpl.rcParams["axes.grid"] == bool(grid)


# ---------------------------------------------------------------------------
# font options
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("font", ["jetbrains", "sourcecodepro", None])
def test_font_options(font):
    # fonts may not exist in CI — should not raise, just warn
    c = ts.rosepine.apply("moon", font=font); _close()
    assert "base" in c


# ---------------------------------------------------------------------------
# font size
# ---------------------------------------------------------------------------

@pytest.mark.parametrize("size", [10, 13, 16])
def test_font_size(size):
    import matplotlib as mpl
    ts.dracula.apply("classic", font_size_base=size); _close()
    assert mpl.rcParams["font.size"] == size