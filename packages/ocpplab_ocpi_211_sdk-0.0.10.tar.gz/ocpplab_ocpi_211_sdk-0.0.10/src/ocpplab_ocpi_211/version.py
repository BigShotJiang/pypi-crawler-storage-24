from importlib import metadata

__version__ = metadata.version("ocpplab-ocpi-211-sdk")
