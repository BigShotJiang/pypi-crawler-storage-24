"""Voice providers — ElevenLabs, Google Cloud TTS, Azure, AWS Polly + Dummy."""

from __future__ import annotations

import logging
import os
from pathlib import Path

from demodsl.providers.base import VoiceProvider, VoiceProviderFactory

logger = logging.getLogger(__name__)


class ElevenLabsVoiceProvider(VoiceProvider):
    """TTS via the ElevenLabs REST API."""

    API_BASE = "https://api.elevenlabs.io/v1/text-to-speech"

    def __init__(self, output_dir: Path | None = None) -> None:
        self._api_key = os.environ.get("ELEVENLABS_API_KEY", "")
        if not self._api_key:
            raise EnvironmentError(
                "ELEVENLABS_API_KEY not set. Use DummyVoiceProvider or set the env var."
            )
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        import httpx

        url = f"{self.API_BASE}/{voice_id}"
        headers = {"xi-api-key": self._api_key, "Content-Type": "application/json"}
        payload = {
            "text": text,
            "model_id": "eleven_monolingual_v1",
            "voice_settings": {"stability": 0.5, "similarity_boost": 0.75},
        }
        resp = httpx.post(url, json=payload, headers=headers, timeout=60)
        resp.raise_for_status()

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.mp3"
        out_path.write_bytes(resp.content)
        logger.info("Generated narration: %s (%d bytes)", out_path, len(resp.content))
        return out_path

    def close(self) -> None:
        pass


class GoogleTTSVoiceProvider(VoiceProvider):
    """TTS via Google Cloud Text-to-Speech API."""

    def __init__(self, output_dir: Path | None = None) -> None:
        self._credentials = os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", "")
        if not self._credentials:
            raise EnvironmentError(
                "GOOGLE_APPLICATION_CREDENTIALS not set. "
                "Point it to your service account JSON file."
            )
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        from google.cloud import texttospeech

        client = texttospeech.TextToSpeechClient()

        synthesis_input = texttospeech.SynthesisInput(text=text)
        voice = texttospeech.VoiceSelectionParams(
            language_code=voice_id.split("-")[0] + "-" + voice_id.split("-")[1]
            if "-" in voice_id
            else "en-US",
            name=voice_id if "-" in voice_id else f"en-US-Wavenet-D",
        )
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.MP3,
            speaking_rate=speed,
            pitch=float(pitch),
        )

        response = client.synthesize_speech(
            input=synthesis_input, voice=voice, audio_config=audio_config
        )

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.mp3"
        out_path.write_bytes(response.audio_content)
        logger.info("Generated narration (Google TTS): %s (%d bytes)", out_path, len(response.audio_content))
        return out_path

    def close(self) -> None:
        pass


class AzureTTSVoiceProvider(VoiceProvider):
    """TTS via Azure Cognitive Services Speech."""

    API_BASE = "https://{region}.tts.speech.microsoft.com/cognitiveservices/v1"

    def __init__(self, output_dir: Path | None = None) -> None:
        self._api_key = os.environ.get("AZURE_SPEECH_KEY", "")
        self._region = os.environ.get("AZURE_SPEECH_REGION", "eastus")
        if not self._api_key:
            raise EnvironmentError(
                "AZURE_SPEECH_KEY not set. Set it along with AZURE_SPEECH_REGION."
            )
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        import httpx

        url = self.API_BASE.format(region=self._region)
        voice_name = voice_id if "Neural" in voice_id else f"en-US-JennyNeural"
        rate = f"{int((speed - 1) * 100):+d}%"
        pitch_str = f"{pitch:+d}Hz"

        ssml = (
            '<speak version="1.0" xmlns="http://www.w3.org/2001/10/synthesis" xml:lang="en-US">'
            f'<voice name="{voice_name}">'
            f'<prosody rate="{rate}" pitch="{pitch_str}">'
            f"{text}"
            "</prosody></voice></speak>"
        )

        headers = {
            "Ocp-Apim-Subscription-Key": self._api_key,
            "Content-Type": "application/ssml+xml",
            "X-Microsoft-OutputFormat": "audio-16khz-128kbitrate-mono-mp3",
        }
        resp = httpx.post(url, content=ssml, headers=headers, timeout=60)
        resp.raise_for_status()

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.mp3"
        out_path.write_bytes(resp.content)
        logger.info("Generated narration (Azure TTS): %s (%d bytes)", out_path, len(resp.content))
        return out_path

    def close(self) -> None:
        pass


class AWSPollyVoiceProvider(VoiceProvider):
    """TTS via Amazon Polly."""

    def __init__(self, output_dir: Path | None = None) -> None:
        self._access_key = os.environ.get("AWS_ACCESS_KEY_ID", "")
        self._secret_key = os.environ.get("AWS_SECRET_ACCESS_KEY", "")
        self._region = os.environ.get("AWS_DEFAULT_REGION", "us-east-1")
        if not self._access_key or not self._secret_key:
            raise EnvironmentError(
                "AWS_ACCESS_KEY_ID and AWS_SECRET_ACCESS_KEY must be set for Polly."
            )
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        import boto3

        client = boto3.client(
            "polly",
            aws_access_key_id=self._access_key,
            aws_secret_access_key=self._secret_key,
            region_name=self._region,
        )

        polly_voice = voice_id if voice_id[0].isupper() else "Matthew"
        engine = "neural"

        # Wrap in SSML for speed control
        rate = f"{int(speed * 100)}%"
        ssml_text = f'<speak><prosody rate="{rate}">{text}</prosody></speak>'

        response = client.synthesize_speech(
            Text=ssml_text,
            TextType="ssml",
            OutputFormat="mp3",
            VoiceId=polly_voice,
            Engine=engine,
        )

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.mp3"
        with open(out_path, "wb") as f:
            f.write(response["AudioStream"].read())

        logger.info("Generated narration (AWS Polly): %s", out_path)
        return out_path

    def close(self) -> None:
        pass


class OpenAITTSVoiceProvider(VoiceProvider):
    """TTS via OpenAI Audio API (tts-1 / tts-1-hd)."""

    API_BASE = "https://api.openai.com/v1/audio/speech"

    def __init__(self, output_dir: Path | None = None) -> None:
        self._api_key = os.environ.get("OPENAI_API_KEY", "")
        if not self._api_key:
            raise EnvironmentError("OPENAI_API_KEY not set.")
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        import httpx

        valid_voices = {"alloy", "echo", "fable", "onyx", "nova", "shimmer"}
        voice = voice_id if voice_id in valid_voices else "alloy"

        payload = {
            "model": "tts-1-hd",
            "input": text,
            "voice": voice,
            "speed": max(0.25, min(4.0, speed)),
            "response_format": "mp3",
        }
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        resp = httpx.post(self.API_BASE, json=payload, headers=headers, timeout=60)
        resp.raise_for_status()

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.mp3"
        out_path.write_bytes(resp.content)
        logger.info("Generated narration (OpenAI TTS): %s (%d bytes)", out_path, len(resp.content))
        return out_path

    def close(self) -> None:
        pass


class DummyVoiceProvider(VoiceProvider):
    """Generates silent MP3 files for development without an API key."""

    def __init__(self, output_dir: Path | None = None) -> None:
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        from pydub import AudioSegment

        # Estimate duration: ~150 words per minute
        word_count = len(text.split())
        duration_ms = max(1000, int(word_count / 150 * 60 * 1000))

        silence = AudioSegment.silent(duration=duration_ms)
        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.mp3"
        silence.export(str(out_path), format="mp3")
        logger.info("Generated silent narration: %s (%dms)", out_path, duration_ms)
        return out_path

    def close(self) -> None:
        pass


# ── Local providers ──────────────────────────────────────────────────────────


class CosyVoiceProvider(VoiceProvider):
    """TTS via CosyVoice (Alibaba/Qwen ecosystem) served locally or remotely.

    Expects a CosyVoice-compatible HTTP API (e.g. CosyVoice WebUI or a
    FastAPI wrapper). Set COSYVOICE_API_URL to the endpoint base URL.
    """

    def __init__(self, output_dir: Path | None = None) -> None:
        self._api_url = os.environ.get("COSYVOICE_API_URL", "http://localhost:50000")
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        import httpx

        payload = {
            "text": text,
            "speaker": voice_id,
            "speed": speed,
        }
        resp = httpx.post(
            f"{self._api_url}/api/tts",
            json=payload,
            timeout=120,
        )
        resp.raise_for_status()

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.wav"
        out_path.write_bytes(resp.content)
        logger.info("Generated narration (CosyVoice): %s (%d bytes)", out_path, len(resp.content))
        return out_path

    def close(self) -> None:
        pass


class CoquiXTTSVoiceProvider(VoiceProvider):
    """TTS via Coqui XTTS v2, running locally via the TTS Python library."""

    def __init__(self, output_dir: Path | None = None) -> None:
        self._output_dir = output_dir or Path(".")
        self._counter = 0
        self._tts = None

    def _ensure_model(self) -> None:
        if self._tts is not None:
            return
        from TTS.api import TTS

        model_name = os.environ.get("COQUI_MODEL", "tts_models/multilingual/multi-dataset/xtts_v2")
        self._tts = TTS(model_name)
        logger.info("Loaded Coqui model: %s", model_name)

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        self._ensure_model()

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.wav"

        # voice_id is used as the speaker wav path for voice cloning,
        # or as speaker name if available in the model
        speaker_wav = voice_id if Path(voice_id).is_file() else None
        speaker = voice_id if speaker_wav is None else None
        language = os.environ.get("COQUI_LANGUAGE", "en")

        kwargs: dict = {"text": text, "file_path": str(out_path), "language": language}
        if speaker_wav:
            kwargs["speaker_wav"] = speaker_wav
        elif speaker:
            kwargs["speaker"] = speaker

        self._tts.tts_to_file(**kwargs)  # type: ignore[union-attr]
        logger.info("Generated narration (Coqui XTTS): %s", out_path)
        return out_path

    def close(self) -> None:
        self._tts = None


class PiperVoiceProvider(VoiceProvider):
    """TTS via Piper — fast, lightweight local TTS via subprocess."""

    def __init__(self, output_dir: Path | None = None) -> None:
        self._output_dir = output_dir or Path(".")
        self._counter = 0
        self._piper_bin = os.environ.get("PIPER_BIN", "piper")
        self._model_path = os.environ.get("PIPER_MODEL", "")
        if not self._model_path:
            raise EnvironmentError(
                "PIPER_MODEL must be set to the path of the .onnx voice model."
            )

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        import subprocess

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.wav"

        # voice_id can override model path if it's a file
        model = voice_id if Path(voice_id).suffix == ".onnx" else self._model_path
        length_scale = 1.0 / speed if speed > 0 else 1.0

        cmd = [
            self._piper_bin, "--model", model,
            "--output_file", str(out_path),
            "--length_scale", str(length_scale),
        ]
        subprocess.run(
            cmd,
            input=text.encode(),
            check=True,
            capture_output=True,
        )
        logger.info("Generated narration (Piper): %s", out_path)
        return out_path

    def close(self) -> None:
        pass


class LocalOpenAIVoiceProvider(VoiceProvider):
    """TTS via an OpenAI-compatible local API (vLLM, LocalAI, AllTalk, etc.).

    Uses the same /v1/audio/speech endpoint format as OpenAI but against
    a local server. Set LOCAL_TTS_URL to point to your server.
    """

    def __init__(self, output_dir: Path | None = None) -> None:
        self._api_url = os.environ.get("LOCAL_TTS_URL", "http://localhost:8000")
        self._api_key = os.environ.get("LOCAL_TTS_API_KEY", "not-needed")
        self._model = os.environ.get("LOCAL_TTS_MODEL", "tts-1")
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        import httpx

        payload = {
            "model": self._model,
            "input": text,
            "voice": voice_id,
            "speed": max(0.25, min(4.0, speed)),
            "response_format": "mp3",
        }
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }
        resp = httpx.post(
            f"{self._api_url}/v1/audio/speech",
            json=payload,
            headers=headers,
            timeout=120,
        )
        resp.raise_for_status()

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.mp3"
        out_path.write_bytes(resp.content)
        logger.info("Generated narration (Local OpenAI-compat): %s (%d bytes)", out_path, len(resp.content))
        return out_path

    def close(self) -> None:
        pass


# ── Vintage / debug providers ────────────────────────────────────────────────


class ESpeakVoiceProvider(VoiceProvider):
    """TTS via eSpeak-NG — robotic vintage voice, zero dependencies beyond espeak.

    Great for debug runs and retro aesthetics. Supports pitch and speed.
    """

    def __init__(self, output_dir: Path | None = None) -> None:
        self._output_dir = output_dir or Path(".")
        self._counter = 0
        self._espeak_bin = os.environ.get("ESPEAK_BIN", "espeak-ng")

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        import subprocess

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.wav"

        wpm = int(175 * speed)
        pitch_val = max(0, min(99, 50 + pitch))

        cmd = [
            self._espeak_bin,
            "-v", voice_id,
            "-s", str(wpm),
            "-p", str(pitch_val),
            "-w", str(out_path),
            "--", text,
        ]
        subprocess.run(cmd, check=True, capture_output=True)
        logger.info("Generated narration (eSpeak): %s", out_path)
        return out_path

    def close(self) -> None:
        pass


class GTTSVoiceProvider(VoiceProvider):
    """TTS via Google Translate TTS (gTTS) — free, no API key needed.

    Produces natural-ish speech with a slight robotic quality.
    Useful for quick prototyping and debug without any credentials.
    voice_id is used as the language code (e.g. "en", "fr", "de").
    """

    def __init__(self, output_dir: Path | None = None) -> None:
        self._output_dir = output_dir or Path(".")
        self._counter = 0

    def generate(self, text: str, voice_id: str, speed: float = 1.0, pitch: int = 0) -> Path:
        from gtts import gTTS

        self._counter += 1
        out_path = self._output_dir / f"narration_{self._counter:03d}.mp3"

        tts = gTTS(text=text, lang=voice_id, slow=(speed < 0.7))
        tts.save(str(out_path))

        # Apply speed adjustment via pydub if not default
        if speed != 1.0 and speed >= 0.7:
            from pydub import AudioSegment

            audio = AudioSegment.from_mp3(str(out_path))
            # speed_change via frame_rate manipulation
            adjusted = audio._spawn(
                audio.raw_data,
                overrides={"frame_rate": int(audio.frame_rate * speed)},
            ).set_frame_rate(audio.frame_rate)
            adjusted.export(str(out_path), format="mp3")

        logger.info("Generated narration (gTTS): %s", out_path)
        return out_path

    def close(self) -> None:
        pass


# Register with factory
VoiceProviderFactory.register("elevenlabs", ElevenLabsVoiceProvider)
VoiceProviderFactory.register("google", GoogleTTSVoiceProvider)
VoiceProviderFactory.register("azure", AzureTTSVoiceProvider)
VoiceProviderFactory.register("aws_polly", AWSPollyVoiceProvider)
VoiceProviderFactory.register("openai", OpenAITTSVoiceProvider)
VoiceProviderFactory.register("cosyvoice", CosyVoiceProvider)
VoiceProviderFactory.register("coqui", CoquiXTTSVoiceProvider)
VoiceProviderFactory.register("piper", PiperVoiceProvider)
VoiceProviderFactory.register("local_openai", LocalOpenAIVoiceProvider)
VoiceProviderFactory.register("espeak", ESpeakVoiceProvider)
VoiceProviderFactory.register("gtts", GTTSVoiceProvider)
VoiceProviderFactory.register("dummy", DummyVoiceProvider)
