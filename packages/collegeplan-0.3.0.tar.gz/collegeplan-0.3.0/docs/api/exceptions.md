# Exceptions

::: collegeplan.exceptions
