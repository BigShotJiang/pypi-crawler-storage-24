# Solver

::: collegeplan.solver
