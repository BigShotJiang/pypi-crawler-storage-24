# Assumptions

::: collegeplan.assumptions
