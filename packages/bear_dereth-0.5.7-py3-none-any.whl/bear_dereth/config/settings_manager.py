"""Settings Manager using BearBase backend."""

from __future__ import annotations

from contextlib import contextmanager
from datetime import datetime
from functools import partial
import sys
from typing import TYPE_CHECKING, Any, Literal, Self, cast

from bear_epoch_time import EpochTimestamp
from pydantic import BaseModel
from sqlalchemy import create_engine
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker

from bear_shelf.database.schemas import DatabaseConfig
from bear_shelf.datastore.storage._common import StorageChoices  # noqa: TC001
from funcy_bear.typing_stuffs import parse_bool, str_to_type

from .settings_path import derive_settings_path

if TYPE_CHECKING:
    from collections.abc import Generator, Iterator
    from pathlib import Path

    from pydantic import SecretStr
    from sqlalchemy import Engine
    from sqlalchemy.orm import Session

    from bear_shelf.datastore.database import BearBase
    from bear_shelf.datastore.tables.table import Table
    from bear_shelf.dialect import BearShelfDialect


class Base(DeclarativeBase):
    """Base class for SQLAlchemy models."""


class SettingsDB:
    """Database manager for settings storage."""

    __slots__: tuple = ("_config", "_db_url", "_engine", "closed", "session_factory")

    def __init__(self, config: DatabaseConfig, **kwargs) -> None:
        """Initialize the SettingsDB with default parameters."""
        self._config = config
        self._db_url: SecretStr = self._config.db_url
        self._engine: Engine = create_engine(self._db_url.get_secret_value(), connect_args={**kwargs})
        self.session_factory: sessionmaker = sessionmaker(bind=self._engine)
        self.closed: bool = False

    def create_tables(self) -> None:
        Base.metadata.create_all(self._engine)

    def get_session(self) -> Session:
        """Get a new database session."""
        return self.session_factory()

    @property
    def dialect(self) -> BearShelfDialect:
        """Get the database dialect."""
        return cast("BearShelfDialect", self._engine.dialect)

    @property
    def dialect_base(self) -> BearBase:
        """Get the BearBase associated with the dialect."""
        return self.dialect.base

    @property
    def settings_table(self) -> Table:
        """Get the settings table model."""
        return self.dialect_base.table("settings")

    @contextmanager
    def open_session(self) -> Generator[Session]:
        """Context manager for database sessions."""
        session: Session = self.get_session()
        try:
            yield session
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()

    def close(self) -> None:
        if not self.closed:
            self._engine.dispose()
            self.closed = True


class Settings(Base):
    """SQLAlchemy model for settings storage."""

    __tablename__ = "settings"

    id: Mapped[int] = mapped_column(primary_key=True, autoincrement=True)
    key: Mapped[str] = mapped_column(nullable=False)
    value: Mapped[str] = mapped_column(nullable=False, default="")
    type: Mapped[str] = mapped_column(nullable=False, default="str")


class DefaultSettings(BaseModel):
    """Default settings schema."""

    default_name: str = "settings"
    default_table: type[Settings] = Settings
    storage_type: StorageChoices = "toml"


SERIALIZED_MAP: dict[str, type] = {"epochtimestamp": int, "datetime": str}
DESERIALIZED_MAP: dict[str, type] = {"EpochTimestamp": EpochTimestamp, "datetime": datetime}
DEFAULT_EXEMPT: frozenset[str] = frozenset({"memory", "default"})
type Operation = Literal["serialize", "deserialize"]


class BearSettings:
    """Settings manager backed by BearBase instead of temp storage."""

    __slots__: tuple = (
        "_all_values",
        "_config",
        "_db",
        "_db_factory",
        "_default_table",
        "_settings",
        "_storage_type",
        "file_path",
        "name",
    )
    _default_settings: type[DefaultSettings] = DefaultSettings

    def __init__(
        self,
        name: str,
        file_name: str | None = None,
        path: Path | str | None = None,
        storage: StorageChoices = "toml",
        enable_wal: bool = False,
        config: DatabaseConfig | None = None,
        **kwargs,
    ) -> None:
        """Initialize BearBase-backed settings manager.

        Args:
            name: Name of the settings
            file_name: Optional specific file name
            path: Optional path to settings file
            storage (StorageChoices): Storage backend type
            enable_wal: Enable Write-Ahead Logging (default: False)
        """
        self.name: str = name
        self._settings = self._default_settings()
        self._storage_type = storage or self._settings.storage_type
        self.file_path: Path = derive_settings_path(name, file_name, path).full_path
        self._all_values: dict[str, Any] | None = None
        self._config: DatabaseConfig = config or DatabaseConfig(name=str(self.file_path), scheme="bearshelf")
        self._db_factory: partial[SettingsDB] = partial(
            SettingsDB,
            config=self._config,
            enable_wal=enable_wal,
            **kwargs,
        )
        self._db: SettingsDB | None = None

    def __del__(self) -> None:
        if sys.meta_path is not None:
            self.close()

    @property
    def db(self) -> SettingsDB:
        """Get or create the database instance."""
        if self._db is None:
            self._db = self._db_factory()
            self._db.create_tables()
        return self._db

    @property
    def closed(self) -> bool:
        """Check if database is closed."""
        return self._db is None

    def type_parsing(self, value: Any, value_type: str, op: Operation = "deserialize") -> Any:
        """Parse value to the specified type."""
        if value_type == "NoneType":
            return None
        if value_type == "bool":
            return parse_bool(value)
        typing: Any = str_to_type(value_type, custom_map=SERIALIZED_MAP if op == "serialize" else DESERIALIZED_MAP)
        if typing is Any:
            typing = str
        try:
            return typing(value)
        except Exception:
            return value

    @property
    def all_values(self) -> dict[str, Any]:
        """Get all settings as dictionary."""
        if self._all_values is None:
            session: Session = self.db.get_session()
            records: list[Settings] = session.query(Settings).all()
            self._all_values = {record.key: self.type_parsing(record.value, record.type) for record in records}
            session.close()
        return self._all_values

    def get(self, key: str, default: Any = None) -> Any:
        """Get a setting value."""
        with self.db.open_session() as session:
            record: Settings | None = session.query(Settings).filter(Settings.key == key).first()
            if record:
                value: str = record.value
                value_type: str = record.type
                return self.type_parsing(value, value_type, op="deserialize")
        return default

    def set(self, key: str, value: Any) -> None:
        """Set a setting value."""
        self.upsert(key, value)

    def upsert(self, key: str, value: Any) -> None:
        """Insert or update a setting value."""
        with self.db.open_session() as session:
            record: Settings | None = session.query(Settings).filter_by(key=key).first()
            if record is not None:
                record.value = value
            else:
                value_type: str = type(value).__name__
                value = self.type_parsing(value, value_type, op="serialize")
                session.add(Settings(key=key, value=value, type=value_type))

        self.invalidate_cache()

    def has(self, key: str) -> bool:
        """Check if setting exists."""
        return key in self.all_values

    def keys(self) -> list[str]:
        """Get all setting keys."""
        return list(self.all_values.keys())

    def values(self) -> list[Any]:
        """Get all setting values."""
        return list(self.all_values.values())

    def items(self) -> list[tuple[str, Any]]:
        """Get all key-value pairs."""
        return list(self.all_values.items())

    def close(self) -> None:
        """Close the database."""
        if self._db is not None:
            self._db.close()
            self._db = None

    def invalidate_cache(self) -> None:
        """Invalidate the cached settings."""
        self._all_values = None

    @property
    def _class_name(self) -> str:
        return self.__class__.__name__

    def __getattr__(self, key: str) -> Any:
        """Handle dot notation access for settings."""
        if key in self.__slots__:
            raise AttributeError(f"'{key}' not initialized")
        if key.startswith("_"):
            raise AttributeError(f"'{self.__class__.__name__}' object has no attribute '{key}'")
        return self.get(key)

    def __setattr__(self, key: str, value: Any) -> None:
        """Handle dot notation assignment for settings."""
        if key in self.__slots__:
            object.__setattr__(self, key, value)
            return
        self.set(key=key, value=value)

    def __getitem__(self, key: str) -> Any:
        return self.get(key)

    def __setitem__(self, key: str, value: Any) -> None:
        self.set(key, value)

    def __iter__(self) -> Iterator[str]:
        return iter(self.keys())

    def __contains__(self, key: str) -> bool:
        return self.has(key)

    def __len__(self) -> int:
        return len(self.keys())

    def __bool__(self) -> bool:
        return not self.closed and len(self) > 0

    def __enter__(self) -> Self:
        return self

    def __exit__(self, exc_type: object, exc_value: object, traceback: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"<{self._class_name} name='{self.name}'>"

    def __str__(self) -> str:
        return f"{self._class_name} for '{self.name}' with {len(self)} settings."


@contextmanager
def settings(
    name: str,
    file_name: str | None = None,
    path: str | Path | None = None,
    **kwargs,
) -> Generator[BearSettings]:
    """Context manager for SettingsManager.

    Args:
        name: Name of the settings
        file_name: Optional specific file name
        path: Optional path to settings file
        **kwargs: Additional arguments for BearSettings
    """
    sm: BearSettings = BearSettings(name, file_name=file_name, path=path, **kwargs)
    try:
        yield sm
    finally:
        sm.close()


class SettingsManager(BearSettings):
    """Alias for BearSettings."""


__all__ = ["BearSettings", "SettingsManager", "settings"]
