from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, ClassVar, Self

from ._helpers import NOT_SET, FancyCompletedProcess

if TYPE_CHECKING:
    from subprocess import CompletedProcess


def get_default_shell() -> str:
    """Get the default shell for the current platform"""
    from bear_dereth.cli.shells import DEFAULT_SHELL  # noqa: PLC0415
    from bear_dereth.system_bools import get_shell  # noqa: PLC0415

    return get_shell() or DEFAULT_SHELL


class BaseShellCommand:
    """Base class for typed shell commands

    Usage:
        GitCommand.status().get()                    # Get stdout
        GitCommand.add("file.txt").do()             # Execute
        PytestCmd("--cov --html").get_result()       # Get full result
    """

    command_name: ClassVar[str] = ""

    def __init__(self, subcommand: str = "", suffix: str = "", *args, **kwargs) -> None:
        self.cmd_parts: list[str] = [self.command_name]
        if subcommand:
            self.cmd_parts.append(subcommand)
        self.cmd_parts.extend(args)
        if suffix:
            self.cmd_parts.append(suffix)
        self.result: FancyCompletedProcess[str] = NOT_SET
        self.shell: str = kwargs.get("shell", get_default_shell())
        self.cwd: str = str(kwargs.get("cwd", Path.cwd()))
        self.env: dict[str, str] = kwargs.get("env", {})
        self.use_shell: bool = kwargs.get("use_shell", True)

    @classmethod
    def adhoc(cls, name: str, *args, **kwargs) -> BaseShellCommand:
        """Create an ad-hoc command class for a specific command

        Args:
            name (str): The name of the command to create

        Returns:
            BaseShellCommand: An instance of the ad-hoc command class.
        """
        return type(
            f"AdHoc{name.title()}Command",
            (cls,),
            {"command_name": name},
        )(*args, **kwargs)

    @classmethod
    def sub(cls, s: str, *args, **kwargs) -> Self:
        """Create command with a subcommand"""
        return cls(s, "", *args, **kwargs)

    def value(self, *args) -> Self:
        """Add arguments to the command"""
        self.cmd_parts.extend(args)
        return self

    @property
    def cmd(self) -> str:
        """Return the full command as a string"""
        return " ".join(self.cmd_parts).strip()

    def do(self, **kwargs) -> Self:
        """Execute the command and store result"""
        from ._base_shell import shell_session  # noqa: PLC0415

        with shell_session(env=self.env, cwd=self.cwd, shell=self.shell, use_shell=self.use_shell) as session:
            self.result = session.run(self.cmd, **kwargs)

        return self

    def _ensure_executed(self) -> CompletedProcess[str]:
        """Ensure command has been executed and return result"""
        if not self.result:
            self.do()
        if not self.result:
            raise RuntimeError("Command execution failed")
        return self.result

    def get_result(self) -> CompletedProcess[str]:
        """Execute (if needed) and return full CompletedProcess result"""
        return self._ensure_executed()

    def get(self) -> str:
        """Execute (if needed) and return stdout as string"""
        return self._ensure_executed().stdout.strip()

    def __str__(self) -> str:
        """String representation of the command"""
        return self.cmd
