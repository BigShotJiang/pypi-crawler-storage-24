#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""SSE (Server-Sent Events) subscriber management and change detection."""

import json
import os
import queue
import threading
import time
from typing import Optional


class SSEManager:
    """Manages SSE subscribers and broadcasts events."""

    def __init__(self):
        self._subscribers: list = []
        self._lock = threading.Lock()
        self._monitor_thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        # Snapshot state for change detection
        self._last_projects_mtime: float = 0.0
        self._last_project_path: str = ""

    def subscribe(self) -> queue.Queue:
        """Register a new SSE subscriber. Returns a Queue for events."""
        q: queue.Queue = queue.Queue()
        with self._lock:
            self._subscribers.append(q)
        # Send initial connected event
        q.put(("connected", {"status": "ok"}))
        return q

    def unsubscribe(self, q: queue.Queue) -> None:
        """Remove a subscriber."""
        with self._lock:
            try:
                self._subscribers.remove(q)
            except ValueError:
                pass

    def broadcast(self, event_type: str, data: dict) -> None:
        """Send an event to all subscribers."""
        with self._lock:
            dead = []
            for q in self._subscribers:
                try:
                    q.put_nowait((event_type, data))
                except queue.Full:
                    dead.append(q)
            for q in dead:
                try:
                    self._subscribers.remove(q)
                except ValueError:
                    pass

    def subscriber_count(self) -> int:
        with self._lock:
            return len(self._subscribers)

    def start_monitor(self, projects_file_fn, get_current_project_fn) -> None:
        """Start background change-detection daemon thread."""
        if self._monitor_thread and self._monitor_thread.is_alive():
            return
        self._stop_event.clear()
        self._projects_file_fn = projects_file_fn
        self._get_current_project_fn = get_current_project_fn
        self._monitor_thread = threading.Thread(
            target=self._monitor_loop, daemon=True
        )
        self._monitor_thread.start()

    def stop_monitor(self) -> None:
        self._stop_event.set()
        if self._monitor_thread:
            self._monitor_thread.join(timeout=3)

    def _monitor_loop(self) -> None:
        """Poll for changes every 10 seconds and broadcast."""
        while not self._stop_event.is_set():
            try:
                self._check_changes()
            except Exception:
                pass
            self._stop_event.wait(10)

    def _check_changes(self) -> None:
        # Check if projects.json changed
        try:
            pf = self._projects_file_fn()
            if pf and os.path.isfile(pf):
                mtime = os.path.getmtime(pf)
                if mtime != self._last_projects_mtime:
                    self._last_projects_mtime = mtime
                    self.broadcast("projects_list_changed", {})
        except Exception:
            pass

        # Check if current project changed
        try:
            current = self._get_current_project_fn()
            if current != self._last_project_path:
                self._last_project_path = current or ""
                self.broadcast("project_changed", {"path": self._last_project_path})
        except Exception:
            pass


def format_sse(event_type: str, data: dict) -> bytes:
    """Format an SSE message as bytes."""
    payload = json.dumps(data)
    return f"event: {event_type}\ndata: {payload}\n\n".encode("utf-8")
