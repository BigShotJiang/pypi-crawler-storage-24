/* Explore view — compact repo list matching TUI density
 * Columns: Name, Commits, Branch, Status
 * Keyboard-driven actions: r=fetch, R=refresh-all, u=update, b=branches, B=branch-all
 * Click row navigates to full commits view
 *
 * Reads App.state.selectedProject for project context (set by dashboard).
 * Passes ?project= to API so no project activation is needed.
 */
const ExploreView = {
  _activeRow: -1,
  _rows: [],
  _expandedRepos: new Set(),
  _branchesMode: false,
  _branchCache: {},
  _branchExpandGen: 0,
  _repoData: [],
  _verboseMode: false,
  _layersMode: false,
  _discoverMode: false,
  _hiddenMode: false,
  _configuredLayers: new Set(),

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'View commits'},
    {key: '\\', desc: 'Expand/collapse layers'},
    {key: 'Home/End', desc: 'First/last row'},
    {sep: true},
    {key: 'r', desc: 'Fetch repo', action: 'r'},
    {key: 'R', desc: 'Refresh all', action: 'R'},
    {key: 'u', desc: 'Update repo (rebase)', action: 'u'},
    {key: 'm', desc: 'Update repo (merge)', action: 'm'},
    {key: 'U', desc: 'Update all repos', action: 'U'},
    {key: 't', desc: 'History viewer', action: 't'},
    {sep: true},
    {key: 'b', desc: 'Expand branches', action: 'b'},
    {key: 'B', desc: 'Branch all', action: 'B'},
    {sep: true},
    {key: 'c', desc: 'Config', action: 'c'},
    {key: 'S', desc: 'Terminal', action: 'S'},
    {key: 'i', desc: 'Info', action: 'i'},
    {key: 'f', desc: 'Fragments', action: 'f'},
    {key: 'D', desc: 'Dependencies', action: 'D'},
    {sep: true},
    {key: 'M', desc: 'Messages', action: 'M'},
    {key: 'P', desc: 'Pull patches', action: 'P'},
    {key: 'A', desc: 'Discover all', action: 'A'},
    {key: 'H', desc: 'Show hidden', action: 'H'},
    {key: 'X', desc: 'Prune backups', action: 'X'},
    {key: 'v', desc: 'Verbose mode', action: 'v'},
    {key: 'L', desc: 'Layers view', action: 'L'},
  ],

  _project() { return App.state.selectedProject || ''; },

  async render(container, state) {
    // Build project context header (matches TUI: "⇄ hostname [ProjectName]")
    const projectName = state.selectedProjectName || '';
    const projectHost = state.selectedProjectHost || '';
    const isRemote = state.selectedProjectRemote || false;
    let contextHtml = '';
    if (projectHost || projectName) {
      const parts = [];
      if (projectHost) parts.push(`<span style="color:var(--cyan)">\u21c4 ${esc(projectHost)}</span>`);
      if (projectName) parts.push(`<span style="font-weight:600;color:var(--accent)">[${esc(projectName)}]</span>`);
      contextHtml = `<span class="explore-project-context">${parts.join(' ')}</span>`;
    }
    const headerTitle = this._layersMode ? 'Explore \u2014 Layers' : 'Explore';
    container.innerHTML = `
      <div class="view-header">
        <h2>${headerTitle} ${contextHtml}</h2>
      </div>
      <div id="explore-repos" class="loading">Loading repos</div>
      <div class="explore-toolbar" id="explore-toolbar">
        <div class="btn-group">
          <button class="btn btn-sm${this._verboseMode ? ' btn-active' : ''}" id="explore-verbose" title="Toggle verbose mode (v)">Verbose</button>
          <button class="btn btn-sm${this._layersMode ? ' btn-active' : ''}" id="explore-layers" title="Toggle layers view (L)">Layers</button>
          <button class="btn btn-sm${this._branchesMode ? ' btn-active' : ''}" id="explore-branches" title="Toggle branches mode (b)">Branches</button>
          <button class="btn btn-sm${this._discoverMode ? ' btn-active' : ''}" id="explore-discover" title="Toggle discover mode (A)">Discover</button>
          <button class="btn btn-sm${this._hiddenMode ? ' btn-active' : ''}" id="explore-hidden" title="Toggle hidden repos (H)">Hidden</button>
        </div>
        <button class="btn btn-sm" id="explore-pull" title="Pull patches from remote (P)">Pull Patches</button>
        <button class="btn btn-sm" id="explore-refresh" title="Refresh all repos (R)">Refresh All</button>
      </div>
    `;

    document.getElementById('explore-verbose').addEventListener('click', () => {
      this._verboseMode = !this._verboseMode;
      this._renderRepos(this._repoData);
      document.getElementById('explore-verbose').classList.toggle('btn-active', this._verboseMode);
    });
    document.getElementById('explore-layers').addEventListener('click', () => {
      this._layersMode = !this._layersMode;
      const h2 = document.querySelector('.view-header h2');
      if (h2) {
        const ctx = h2.querySelector('.explore-project-context');
        const ctxHtml = ctx ? ' ' + ctx.outerHTML : '';
        h2.innerHTML = (this._layersMode ? 'Explore \u2014 Layers' : 'Explore') + ctxHtml;
      }
      this._renderRepos(this._repoData);
      document.getElementById('explore-layers').classList.toggle('btn-active', this._layersMode);
    });
    document.getElementById('explore-branches').addEventListener('click', () => {
      this._toggleBranchesMode();
    });
    document.getElementById('explore-discover').addEventListener('click', () => {
      this._discoverMode = !this._discoverMode;
      document.getElementById('explore-discover').classList.toggle('btn-active', this._discoverMode);
      this._refreshRepos();
    });
    document.getElementById('explore-hidden').addEventListener('click', () => {
      this._hiddenMode = !this._hiddenMode;
      this._syncToolbarState();
      this._refreshRepos();
    });
    document.getElementById('explore-pull').addEventListener('click', () => {
      this._pullPatchesWizard();
    });
    document.getElementById('explore-refresh').addEventListener('click', async () => {
      const btn = document.getElementById('explore-refresh');
      btn.classList.add('loading');
      try { await API.refreshAll(); App.showToast('Refreshing...'); } catch(e) { App.showToast(e.message, 'error'); }
      btn.classList.remove('loading');
    });

    await this._refreshRepos();
  },

  _renderRepos(repos) {
    const el = document.getElementById('explore-repos');
    el.classList.remove('loading');
    if (!repos.length) {
      el.innerHTML = '<div class="empty-state"><h3>No repos found</h3></div>';
      return;
    }

    if (this._layersMode) {
      this._renderLayers(repos, el);
      return;
    }

    // Apply saved sort order to repo data BEFORE rendering,
    // so layer rows are always created right after their parent.
    const savedRaw = localStorage.getItem('bit-explore-order');
    if (savedRaw) {
      try {
        const order = JSON.parse(savedRaw);
        const orderMap = {};
        order.forEach((name, idx) => { orderMap[name] = idx; });
        repos = repos.slice().sort((a, b) => {
          const na = a.display_name || a.path;
          const nb = b.display_name || b.path;
          const ia = orderMap[na] !== undefined ? orderMap[na] : 9999;
          const ib = orderMap[nb] !== undefined ? orderMap[nb] : 9999;
          return ia - ib;
        });
      } catch (e) { /* ignore */ }
    }

    const verboseHdr = this._verboseMode ? '<th>Head</th>' : '';
    el.innerHTML = `<table class="data-table" id="explore-table" role="grid" aria-label="Repositories">
      <thead><tr>
        <th style="width:2ch"></th><th>Name</th>${verboseHdr}<th>Commits</th><th>Branch</th><th>Status</th><th class="explore-actions-col"></th>
      </tr></thead>
      <tbody id="explore-tbody"></tbody>
    </table>`;

    const project = this._project();
    const tbody = document.getElementById('explore-tbody');
    repos.forEach((repo, i) => {
      const name = repo.display_name || repo.path;
      const dirty = repo.is_dirty;

      // Only expandable when repo has multiple layers (matches TUI)
      const layers = (repo.layers || []).filter(l => {
        const base = l.split('/').pop();
        return base !== name;
      });
      const hasLayers = layers.length > 1;
      const isExpanded = this._expandedRepos.has(name);

      // Compact commits column: \u2191N \u2193N or \u2713
      const commitParts = [];
      if (repo.local_count > 0) commitParts.push(`<span style="color:var(--accent)">\u2191${repo.local_count}</span>`);
      if (repo.upstream_count > 0) commitParts.push(`<span style="color:var(--yellow)">\u2193${repo.upstream_count}</span>`);
      else if (repo.upstream_count === -1) commitParts.push('<span style="color:var(--yellow)">\u2193?</span>');
      if (!commitParts.length) commitParts.push(`<span style="color:var(--green)">\u2713</span>`);
      const commitsStr = commitParts.join(' ');

      // Status: dirty indicator or clean
      const statusStr = dirty
        ? `<span style="color:var(--red)">\u270e dirty</span>`
        : `<span style="color:var(--green)">\u2713 clean</span>`;

      // Expand chevron — always visible (every repo can expand branches)
      const chevron = `<span class="dash-row-toggle" title="Click to expand/collapse">${isExpanded ? '\u25be' : '\u25b8'}</span>`;

      // Use server-side flags matching TUI logic (repo_sets.discovered / .external / .hidden)
      const discovered = repo.is_discovered || false;
      const isExternal = repo.is_external || false;
      const isHidden = repo.is_hidden || false;

      const nameStyle = isHidden ? 'color:var(--text-muted);text-decoration:line-through'
        : discovered ? 'color:var(--text-muted);font-style:italic'
        : isExternal ? 'color:var(--cyan)' : '';
      const discoveredBadge = isHidden
        ? ' <span style="color:var(--text-muted);font-size:var(--font-size-xs)">(hidden)</span>'
        : discovered
        ? ' <span style="color:var(--yellow);font-size:var(--font-size-xs);font-style:normal">(?)</span>'
        : isExternal
        ? ' <span style="color:var(--cyan);font-size:var(--font-size-xs)">(ext)</span>'
        : '';

      // Action buttons — contextual based on discovered/external/hidden state
      let actionBtns = `
          <button class="btn-icon" data-action="fetch" title="Fetch">&#x21bb;</button>
          <button class="btn-icon" data-action="update" title="Update">&#x2191;</button>
          <button class="btn-icon" data-action="branches" title="Branches">&#x2387;</button>
          <button class="btn-icon" data-action="history" title="History">&#x23f1;</button>
          <button class="btn-icon" data-action="browse" title="Browse commits">&#x2192;</button>`;
      if (isHidden) {
        actionBtns += `<button class="btn-icon" data-action="track" title="Unhide (track) this repo" style="color:var(--green)">+</button>`;
      } else if (discovered || isExternal) {
        actionBtns += `<button class="btn-icon" data-action="track" title="Track this repo" style="color:var(--green)">+</button>`;
      } else {
        actionBtns += `<button class="btn-icon" data-action="hide" title="Hide this repo" style="color:var(--text-muted)">&minus;</button>`;
        actionBtns += `<button class="btn-icon" data-action="prune" title="Prune backup branches">&#x2702;</button>`;
      }

      const tr = document.createElement('tr');
      tr.className = 'expandable';
      tr.dataset.repo = name;
      tr.setAttribute('role', 'row');
      tr.setAttribute('tabindex', '-1');
      tr.innerHTML = `
        <td><div class="dash-row-first-cell">${chevron}<span class="drag-handle">&#9776;</span></div></td>
        <td><span class="explore-repo-name" style="${nameStyle}">${esc(name)}</span>${discoveredBadge}</td>
        ${this._verboseMode ? '<td>' + this._verboseCommitHtml(repo) + '</td>' : ''}
        <td>${commitsStr}</td>
        <td style="color:var(--accent)">${esc(repo.branch)}</td>
        <td>${statusStr}</td>
        <td class="explore-actions">${actionBtns}</td>
      `;
      tbody.appendChild(tr);

      // Layer child rows (if expanded and has layers)
      const hasBranchChildren = this._branchesMode && isExpanded && this._branchCache[name] && this._branchCache[name].length > 0;
      if (hasLayers && isExpanded) {
        const layerCounts = repo.layer_upstream_counts || {};
        layers.forEach((layer, li) => {
          const layerName = layer.split('/').pop();
          const isLast = li === layers.length - 1 && !hasBranchChildren;
          const lcount = layerCounts[layer] || 0;
          const lcountHtml = lcount > 0
            ? `<span style="color:var(--yellow)">\u2193${lcount}</span>`
            : '';
          const isConfigured = this._configuredLayers.has(layer);
          const layerActionBtn = isConfigured
            ? `<button class="btn-icon" data-action="remove-layer" data-layer-path="${esc(layer)}" title="Remove layer" style="color:var(--text-muted)">&minus;</button>`
            : `<button class="btn-icon" data-action="add-layer" data-layer-path="${esc(layer)}" title="Add layer" style="color:var(--green)">+</button>`;
          const configDot = isConfigured
            ? '<span style="color:var(--green)" title="Configured">\u25cf</span>'
            : '<span style="color:var(--text-muted)" title="Not configured">\u25cb</span>';
          const layerTr = document.createElement('tr');
          layerTr.className = 'explore-layer-row' + (isLast ? ' tree-last' : '');
          layerTr.dataset.parentRepo = name;
          layerTr.dataset.layer = layerName;
          layerTr.setAttribute('role', 'row');
          layerTr.setAttribute('tabindex', '-1');
          const verboseEmpty = this._verboseMode ? '<td></td>' : '';
          layerTr.innerHTML = `<td class="tree-line"></td><td><span class="explore-child-icon" title="Layer">\u25a7</span>${esc(layerName)} ${configDot}</td>${verboseEmpty}<td>${lcountHtml}</td><td></td><td></td><td class="explore-actions">${layerActionBtn}</td>`;
          tbody.appendChild(layerTr);

          // Layer action button handler
          const layerBtn = layerTr.querySelector('[data-action]');
          if (layerBtn) {
            layerBtn.addEventListener('click', (ev) => {
              ev.stopPropagation();
              const lPath = layerBtn.dataset.layerPath;
              const project = this._project();
              if (layerBtn.dataset.action === 'add-layer') {
                API.addLayer(lPath, project)
                  .then(() => { App.showToast(`Added: ${lPath.split('/').pop()}`, 'success'); this._refreshRepos(); })
                  .catch(err => App.showToast(err.message, 'error'));
              } else if (layerBtn.dataset.action === 'remove-layer') {
                confirmModal(`Remove layer "${lPath.split('/').pop()}"?`).then(ok => {
                  if (!ok) return;
                  API.removeLayer(lPath, project)
                    .then(() => { App.showToast(`Removed: ${lPath.split('/').pop()}`, 'success'); this._refreshRepos(); })
                    .catch(err => App.showToast(err.message, 'error'));
                });
              }
            });
          }
        });
      }

      // Branch child rows (if expanded in branches mode)
      if (this._branchesMode && isExpanded && this._branchCache[name]) {
        const branches = this._branchCache[name] || [];
        branches.forEach((br, bi) => {
          const isLast = bi === branches.length - 1;
          const marker = br.current
            ? ' <span style="color:var(--green)">\u25cf</span>'
            : '';
          const branchStyle = br.current ? 'color:var(--accent);font-weight:600' : '';
          const brTr = document.createElement('tr');
          brTr.className = 'explore-branch-row' + (isLast ? ' tree-last' : '');
          brTr.dataset.parentRepo = name;
          brTr.dataset.branch = br.name;
          brTr.setAttribute('role', 'row');
          brTr.setAttribute('tabindex', '-1');
          const verboseEmpty = this._verboseMode ? '<td></td>' : '';
          brTr.innerHTML = `<td class="tree-line"></td><td style="${branchStyle}"><span class="explore-child-icon" title="Branch">\u2387</span>${esc(br.name)}${marker}</td>${verboseEmpty}<td></td><td></td><td></td><td class="explore-actions"><button class="btn-icon" data-action="checkout-branch" title="Checkout">\u21b5</button></td>`;
          tbody.appendChild(brTr);

          // Click branch row → checkout
          brTr.addEventListener('click', (ev) => {
            ev.stopPropagation();
            this._checkoutBranch(name, br.name);
          });

          // Checkout button
          const coBtn = brTr.querySelector('[data-action="checkout-branch"]');
          if (coBtn) {
            coBtn.addEventListener('click', (ev) => {
              ev.stopPropagation();
              this._checkoutBranch(name, br.name);
            });
          }
        });
      }

      // Action icon bar click handlers
      tr.querySelectorAll('.explore-actions .btn-icon').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.stopPropagation();
          const act = btn.dataset.action;
          const project = this._project();
          if (act === 'fetch') {
            API.fetchRepo(name, project).then(() => App.showToast('Fetched: ' + name, 'success'))
              .catch(err => App.showToast(err.message, 'error'));
          } else if (act === 'update') {
            API.updateRepo(name, undefined, project).then(() => App.showToast('Updated: ' + name, 'success'))
              .catch(err => App.showToast(err.message, 'error'));
          } else if (act === 'branches') {
            this._expandWithBranches(name);
          } else if (act === 'history') {
            const idx = this._rows.indexOf(tr);
            if (idx >= 0) this._moveToIndex(idx);
            this._historyViewer();
          } else if (act === 'browse') {
            App.state.selectedRepo = name;
            location.hash = 'commits';
          } else if (act === 'track') {
            API.trackRepo(name, project).then(() => { App.showToast('Tracked: ' + name, 'success'); this._refreshRepos(); })
              .catch(err => App.showToast(err.message, 'error'));
          } else if (act === 'hide') {
            confirmModal(`Hide "${name}"?`).then(ok => {
              if (!ok) return;
              API.hideRepo(name, project).then(() => { App.showToast('Hidden: ' + name, 'success'); this._refreshRepos(); })
                .catch(err => App.showToast(err.message, 'error'));
            });
          } else if (act === 'prune') {
            confirmModal(`Prune backup branches in "${name}"?`).then(ok => {
              if (!ok) return;
              API.pruneBackups(name, project).then(r => App.showToast(`Pruned ${r.pruned} backups in ${name}`, 'success'))
                .catch(err => App.showToast(err.message, 'error'));
            });
          }
        });
      });

      // Click chevron to expand/collapse (content depends on branches mode)
      const chevronEl = tr.querySelector('.dash-row-toggle');
      if (chevronEl) {
        chevronEl.addEventListener('click', (e) => {
          e.stopPropagation();
          this._toggleExpandRepo(name);
        });
      }

      // Right-click context menu
      tr.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._showRepoContextMenu(e, repo, name);
      });

      // Click row to navigate to commits view
      tr.addEventListener('click', () => {
        App.state.selectedRepo = name;
        location.hash = 'commits';
      });
    });

    // Collect all navigable rows — repo rows AND layer rows
    this._rows = Array.from(tbody.querySelectorAll('tr[role="row"]'));
    this._activeRow = -1;

    // Auto-select first row so keyboard actions have a target
    if (this._rows.length > 0) {
      this._moveToIndex(0);
    }

    // Column resizer
    const table = document.getElementById('explore-table');
    if (table) initColumnResizer(table, 'explore');

    // Drag-and-drop reordering — skip initViewSortable's restore phase
    // (we already pre-sorted the data), only set up drag handler.
    if (tbody && typeof Sortable !== 'undefined') {
      const self = this;
      Sortable.create(tbody, {
        animation: 150,
        handle: '.drag-handle',
        draggable: 'tr[data-repo]',
        ghostClass: 'view-row-ghost',
        onEnd: function() {
          // Save new order
          const order = [];
          tbody.querySelectorAll('tr[data-repo]').forEach(function(row) {
            order.push(row.getAttribute('data-repo'));
          });
          localStorage.setItem('bit-explore-order', JSON.stringify(order));
          // Re-render so layer rows follow their parents
          self._renderRepos(self._repoData);
        }
      });
    }

    // Reset order button
    let resetBtn = document.getElementById('view-reset-order');
    if (!resetBtn) {
      resetBtn = document.createElement('button');
      resetBtn.id = 'view-reset-order';
      resetBtn.className = 'btn dash-reset-order-fixed';
      resetBtn.title = 'Reset row order to default';
      resetBtn.textContent = 'Reset Order';
      document.body.appendChild(resetBtn);
    }
    resetBtn.style.display = '';
    resetBtn.onclick = () => {
      resetViewOrder('bit-explore-order');
      this._renderRepos(this._repoData);
    };
  },

  _verboseCommitHtml(repo) {
    if (!repo.head_commit) return '';
    const sha = (repo.head_commit.sha || '').slice(0, 8);
    const subj = repo.head_commit.subject || '';
    const truncSubj = subj.length > 50 ? subj.slice(0, 50) + '\u2026' : subj;
    return `<span class="explore-verbose-commit"><span class="sha">${esc(sha)}</span> ${esc(truncSubj)}</span>`;
  },

  _renderLayers(repos, el) {
    const verboseHdr = this._verboseMode ? '<th>Head</th>' : '';
    el.innerHTML = `<table class="data-table" id="explore-table" role="grid" aria-label="Layers">
      <thead><tr>
        <th style="width:2ch"></th><th>Layer</th>${verboseHdr}<th>Repository</th><th>Branch</th><th>Status</th>
      </tr></thead>
      <tbody id="explore-tbody"></tbody>
    </table>`;

    const tbody = document.getElementById('explore-tbody');
    repos.forEach(repo => {
      const repoName = repo.display_name || repo.path;
      const dirty = repo.is_dirty;
      const statusStr = dirty
        ? `<span style="color:var(--red)">\u270e dirty</span>`
        : `<span style="color:var(--green)">\u2713 clean</span>`;

      (repo.layers || []).forEach(layerPath => {
        const layerName = layerPath.split('/').pop();
        const configured = this._configuredLayers.has(layerPath);
        const unconfiguredMark = configured ? '' : ' <span style="color:var(--text-muted)">(?\u200b)</span>';

        const verboseTd = this._verboseMode ? '<td>' + this._verboseCommitHtml(repo) + '</td>' : '';

        const tr = document.createElement('tr');
        tr.dataset.repo = repoName;
        tr.setAttribute('role', 'row');
        tr.setAttribute('tabindex', '-1');
        tr.innerHTML = `
          <td></td>
          <td>${esc(layerName)}${unconfiguredMark}</td>
          ${verboseTd}
          <td style="color:var(--text-secondary)">${esc(repoName)}</td>
          <td style="color:var(--accent)">${esc(repo.branch)}</td>
          <td>${statusStr}</td>
        `;
        tbody.appendChild(tr);

        tr.addEventListener('click', () => {
          App.state.selectedRepo = repoName;
          location.hash = 'commits';
        });
      });
    });

    this._rows = Array.from(tbody.querySelectorAll('tr[role="row"]'));
    this._activeRow = -1;
    if (this._rows.length > 0) this._moveToIndex(0);

    // Column resizer
    const table = document.getElementById('explore-table');
    if (table) initColumnResizer(table, 'explore-layers');
  },

  async _refreshRepos() {
    const el = document.getElementById('explore-repos');
    if (el) { el.className = 'loading'; el.textContent = 'Loading repos'; }
    try {
      let url = '/api/repos';
      if (this._discoverMode) url += (url.includes('?') ? '&' : '?') + 'discover=1';
      if (this._hiddenMode) url += (url.includes('?') ? '&' : '?') + 'hidden=1';
      url = this._projUrl(url);
      const data = await API._fetch(url);
      const repos = data.repos || data;
      this._configuredLayers = new Set(data.configured_layers || []);
      this._repoData = repos;
      this._renderRepos(repos);
    } catch (e) {
      if (el) {
        el.classList.remove('loading');
        el.innerHTML = `<div class="empty-state"><h3>Error loading repos</h3><p>${e.message}</p></div>`;
      }
    }
  },

  _projUrl(base) {
    const p = this._project();
    if (!p) return base;
    const sep = base.includes('?') ? '&' : '?';
    return base + sep + 'project=' + encodeURIComponent(p);
  },

  _syncToolbarState() {
    const vBtn = document.getElementById('explore-verbose');
    const lBtn = document.getElementById('explore-layers');
    const bBtn = document.getElementById('explore-branches');
    const dBtn = document.getElementById('explore-discover');
    const hBtn = document.getElementById('explore-hidden');
    if (vBtn) vBtn.classList.toggle('btn-active', this._verboseMode);
    if (lBtn) lBtn.classList.toggle('btn-active', this._layersMode);
    if (bBtn) bBtn.classList.toggle('btn-active', this._branchesMode);
    if (dBtn) dBtn.classList.toggle('btn-active', this._discoverMode);
    if (hBtn) hBtn.classList.toggle('btn-active', this._hiddenMode);
  },

  async _toggleExpandRepo(repoName) {
    if (this._expandedRepos.has(repoName)) {
      this._expandedRepos.delete(repoName);
    } else {
      this._expandedRepos.add(repoName);
      if (this._branchesMode && !this._branchCache[repoName]) {
        await this._fetchBranches(repoName);
      }
    }
    this._renderRepos(this._repoData);
    this._syncToolbarState();
  },

  async _toggleExpandAll() {
    if (this._expandedRepos.size > 0) {
      this._expandedRepos.clear();
    } else {
      this._repoData.forEach(repo => {
        const name = repo.display_name || repo.path;
        if (this._branchesMode) {
          // In branches mode, expand all repos
          this._expandedRepos.add(name);
        } else {
          // In layers mode, only expand repos with multiple layers
          const layers = (repo.layers || []).filter(l => l.split('/').pop() !== name);
          if (layers.length > 1) this._expandedRepos.add(name);
        }
      });
      if (this._branchesMode) {
        await this._fetchBranchesForExpanded();
      }
    }
    this._renderRepos(this._repoData);
    this._syncToolbarState();
  },

  async _toggleBranchesMode() {
    this._branchesMode = !this._branchesMode;
    if (this._branchesMode) {
      // Fetch branches for any currently expanded repos
      await this._fetchBranchesForExpanded();
    }
    this._renderRepos(this._repoData);
    this._syncToolbarState();
  },

  async _expandWithBranches(repoName) {
    // Turn on branches mode and expand this repo (used by icon button / context menu)
    this._branchesMode = true;
    if (!this._expandedRepos.has(repoName)) {
      this._expandedRepos.add(repoName);
    }
    if (!this._branchCache[repoName]) {
      await this._fetchBranches(repoName);
    }
    this._renderRepos(this._repoData);
    this._syncToolbarState();
  },

  async _fetchBranchesForExpanded() {
    const gen = ++this._branchExpandGen;
    const project = this._project();
    const names = [...this._expandedRepos].filter(n => !this._branchCache[n]);
    if (!names.length) return;
    await Promise.all(names.map(async (name) => {
      try {
        const branches = await API.getRepoBranches(name, project);
        if (this._branchExpandGen !== gen) return;
        const current = branches.filter(b => b.current);
        const rest = branches.filter(b => !b.current);
        this._branchCache[name] = [...current, ...rest];
      } catch (e) { /* skip repos that fail */ }
    }));
  },

  async _fetchBranches(repoName) {
    const gen = this._branchExpandGen;
    try {
      const branches = await API.getRepoBranches(repoName, this._project());
      if (this._branchExpandGen !== gen) return;
      const current = branches.filter(b => b.current);
      const rest = branches.filter(b => !b.current);
      this._branchCache[repoName] = [...current, ...rest];
    } catch (e) {
      App.showToast('Error loading branches: ' + e.message, 'error');
    }
  },

  async _checkoutBranch(repoName, branch) {
    try {
      await API.checkoutBranch(repoName, branch, this._project());
      App.showToast(`Checked out: ${branch}`, 'success');
      // Re-fetch branches so current marker updates, keep expanded
      const branches = await API.getRepoBranches(repoName, this._project());
      const current = branches.filter(b => b.current);
      const rest = branches.filter(b => !b.current);
      this._branchCache[repoName] = [...current, ...rest];
      await this._refreshRepos();
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  // Keyboard navigation
  handleKeyboard(e) {
    if (e.key === '\\') {
      e.preventDefault();
      if (this._activeRow >= 0) {
        const row = this._rows[this._activeRow];
        const name = row && (row.dataset.repo || row.dataset.parentRepo);
        if (name) {
          this._toggleExpandRepo(name);
          return;
        }
      }
      // No active row — toggle all
      this._toggleExpandAll();
      return;
    }

    if (e.key === 'B') {
      e.preventDefault();
      this._switchAllModal();
      return;
    }

    if (e.key === 'b') {
      e.preventDefault();
      this._toggleBranchesMode();
      return;
    }

    if (e.key === 'R') {
      e.preventDefault();
      API.refreshAll().then(() => App.showToast('Refreshing...'))
        .catch(err => App.showToast(err.message, 'error'));
      return;
    }

    if (e.key === 'v') {
      e.preventDefault();
      this._verboseMode = !this._verboseMode;
      this._renderRepos(this._repoData);
      this._syncToolbarState();
      return;
    }

    if (e.key === 'L') {
      e.preventDefault();
      this._layersMode = !this._layersMode;
      // Update header text
      const h2 = document.querySelector('.view-header h2');
      if (h2) {
        const ctx = h2.querySelector('.explore-project-context');
        const ctxHtml = ctx ? ' ' + ctx.outerHTML : '';
        h2.innerHTML = (this._layersMode ? 'Explore \u2014 Layers' : 'Explore') + ctxHtml;
      }
      this._renderRepos(this._repoData);
      this._syncToolbarState();
      return;
    }

    if (!this._rows.length) return;

    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      this._moveActive(1);
    } else if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      this._moveActive(-1);
    } else if (e.key === 'Enter' || e.key === 'ArrowRight') {
      e.preventDefault();
      if (this._activeRow >= 0) {
        const row = this._rows[this._activeRow];
        // Branch row — checkout on Enter
        if (row.dataset.branch) {
          const repoName = row.dataset.parentRepo;
          const branch = row.dataset.branch;
          if (repoName && branch) {
            this._checkoutBranch(repoName, branch);
          }
          return;
        }
        // For layer rows, navigate to parent repo's commits
        const name = row.dataset.repo || row.dataset.parentRepo;
        if (name) {
          App.state.selectedRepo = name;
          location.hash = 'commits';
        }
      }
    } else if (e.key === 'Home') {
      e.preventDefault();
      this._moveToIndex(0);
    } else if (e.key === 'End') {
      e.preventDefault();
      this._moveToIndex(this._rows.length - 1);
    } else if (e.key === 'r') {
      e.preventDefault();
      const rName = this._activeRepoName();
      if (!rName) return;
      API.fetchRepo(rName, this._project()).then(() => App.showToast(`Fetched: ${rName}`, 'success'))
        .catch(err => App.showToast(err.message, 'error'));
    } else if (e.key === 'u') {
      e.preventDefault();
      const uName = this._activeRepoName();
      if (!uName) return;
      API.updateRepo(uName, 'rebase', this._project()).then(() => App.showToast(`Updated (rebase): ${uName}`, 'success'))
        .catch(err => App.showToast(err.message, 'error'));
    } else if (e.key === 'm') {
      e.preventDefault();
      const mName = this._activeRepoName();
      if (!mName) return;
      API.updateRepo(mName, 'merge', this._project()).then(() => App.showToast(`Updated (merge): ${mName}`, 'success'))
        .catch(err => App.showToast(err.message, 'error'));
    } else if (e.key === 'U') {
      e.preventDefault();
      if (!this._repoData.length) return;
      App.showToast('Updating all repos...');
      const updates = this._repoData.map(r =>
        API.updateRepo(r.display_name || r.name, undefined, this._project()).catch(() => {})
      );
      Promise.all(updates).then(() => App.showToast('All repos updated', 'success'));
    } else if (e.key === 't') {
      e.preventDefault();
      this._historyViewer();
    } else if (e.key === 'c') {
      e.preventDefault();
      location.hash = 'config';
    } else if (e.key === 'S') {
      e.preventDefault();
      location.hash = 'terminal';
    } else if (e.key === 'i') {
      e.preventDefault();
      location.hash = 'info';
    } else if (e.key === 'f') {
      e.preventDefault();
      location.hash = 'fragments';
    } else if (e.key === 'D') {
      e.preventDefault();
      location.hash = 'deps';
    } else if (e.key === 'A') {
      e.preventDefault();
      this._discoverMode = !this._discoverMode;
      this._syncToolbarState();
      this._refreshRepos();
    } else if (e.key === 'H') {
      e.preventDefault();
      this._hiddenMode = !this._hiddenMode;
      this._syncToolbarState();
      this._refreshRepos();
    } else if (e.key === 'X') {
      e.preventDefault();
      this._pruneBackupsAction();
    } else if (e.key === 'P') {
      e.preventDefault();
      this._pullPatchesWizard();
    } else if (e.key === 'M') {
      e.preventDefault();
      if (window.MessagesPanel) MessagesPanel.toggle();
    }
  },

  async _switchAllModal() {
    try {
      const union = await API.getUnionBranches(this._project());
      if (!union.length) {
        App.showToast('No branches found', 'error');
        return;
      }

      const listHtml = union.map(b => {
        return `<div class="dash-action-item" data-branch="${esc(b.name)}" style="padding:6px 8px;cursor:pointer">
          <span style="flex:1">${esc(b.name)}</span>
          <span class="dash-act-desc">${b.count}/${b.total} repos</span>
        </div>`;
      }).join('');

      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `<div class="modal" style="max-height:80vh;display:flex;flex-direction:column">
        <div class="modal-header">
          <span>Switch All Repos</span>
          <button class="modal-close">\u00d7</button>
        </div>
        <div class="modal-body" style="overflow-y:auto;max-height:60vh;padding:8px">
          ${listHtml}
        </div>
        <div class="modal-footer">
          <button class="btn modal-cancel-btn">Cancel</button>
        </div>
      </div>`;
      document.body.appendChild(overlay);

      const close = () => overlay.remove();
      overlay.querySelector('.modal-close').addEventListener('click', close);
      overlay.querySelector('.modal-cancel-btn').addEventListener('click', close);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });

      overlay.querySelectorAll('[data-branch]').forEach(item => {
        item.addEventListener('click', async () => {
          const branch = item.dataset.branch;
          close();
          const ok = await confirmModal(`Switch ALL repos to "${branch}"?`);
          if (!ok) return;
          try {
            const result = await API.branchAll(branch, this._project());
            const okCount = result.results.filter(r => r.status === 'ok' || r.status === 'already').length;
            const errCount = result.results.filter(r => r.status === 'error').length;
            App.showToast(`Switched: ${okCount} repos${errCount ? `, ${errCount} failed` : ''}`, errCount ? 'error' : 'success');
            const refreshData = await API.getReposRaw(this._project());
            const repos = refreshData.repos || refreshData;
            this._configuredLayers = new Set(refreshData.configured_layers || []);
            this._repoData = repos;
            this._renderRepos(repos);
          } catch (e) {
            App.showToast(e.message, 'error');
          }
        });
      });
    } catch (e) {
      App.showToast('Error loading branches: ' + e.message, 'error');
    }
  },

  /** Return the repo name for the active row, or null with a toast. */
  _activeRepoName() {
    if (this._activeRow < 0 || !this._rows[this._activeRow]) {
      App.showToast('Select a repo first', 'error');
      return null;
    }
    const row = this._rows[this._activeRow];
    return row.dataset.repo || row.dataset.parentRepo || null;
  },

  /** Return the repo data object for the active row. */
  _activeRepoData() {
    const name = this._activeRepoName();
    if (!name) return null;
    return this._repoData.find(r => (r.display_name || r.path) === name) || null;
  },

  async _showRepoContextMenu(e, repo, name) {
    // Highlight the row so the user sees which repo the menu applies to
    const idx = this._rows.findIndex(r => r.dataset.repo === name);
    if (idx >= 0) this._moveToIndex(idx);

    const isDiscovered = repo.is_discovered || false;
    const isHidden = repo.is_hidden || false;

    const menuItems = [
      { label: 'Fetch', icon: '\u21bb', key: 'r', action: 'fetch' },
      { label: 'Update', icon: '\u2191', key: 'u', action: 'update' },
      { sep: true },
      { label: 'Branches', icon: '\u2387', key: 'b', action: 'branches' },
      { label: 'History', icon: '\u23f1', key: 't', action: 'history' },
      { sep: true },
      { label: 'Browse commits', icon: '\u2192', key: 'Enter', action: 'browse' },
      { sep: true },
    ];
    menuItems.push({ label: 'Pull patches', icon: '\u2b07', key: 'P', action: 'pull-patches' });
    menuItems.push({ label: 'Pull request', icon: '\u2699', action: 'export-prep' });
    if ((App.state.selectedProjectPersona || 'yocto') === 'yocto') {
      menuItems.push({ label: 'Export', icon: '\u{1f4e6}', action: 'export' });
    }
    menuItems.push({ sep: true });
    if (isHidden) {
      menuItems.push({ label: 'Unhide repo', icon: '+', key: '+', action: 'track' });
    } else if (isDiscovered) {
      menuItems.push({ label: 'Track repo', icon: '+', key: '+', action: 'track' });
    } else {
      menuItems.push({ label: 'Add layer', icon: '+', key: 'a', action: 'add-layer' });
      menuItems.push({ label: 'Remove layer', icon: '\u2212', key: 'd', action: 'remove-layer' });
      menuItems.push({ label: 'Hide repo', icon: '\u2212', key: '-', action: 'hide' });
      menuItems.push({ label: 'Prune backups', icon: '\u2702', key: 'X', action: 'prune' });
    }

    const action = await contextMenu(e.clientX, e.clientY, menuItems);
    if (!action) return;

    const project = this._project();
    if (action === 'fetch') {
      API.fetchRepo(name, project).then(() => App.showToast('Fetched: ' + name, 'success'))
        .catch(err => App.showToast(err.message, 'error'));
    } else if (action === 'update') {
      API.updateRepo(name, undefined, project).then(() => App.showToast('Updated: ' + name, 'success'))
        .catch(err => App.showToast(err.message, 'error'));
    } else if (action === 'branches') {
      this._expandWithBranches(name);
    } else if (action === 'history') {
      this._historyViewer();
    } else if (action === 'browse') {
      App.state.selectedRepo = name;
      location.hash = 'commits';
    } else if (action === 'track') {
      this._trackRepo();
    } else if (action === 'hide') {
      this._hideRepoAction();
    } else if (action === 'prune') {
      this._pruneBackupsAction();
    } else if (action === 'pull-patches') {
      this._pullPatchesWizard();
    } else if (action === 'export-prep' || action === 'export') {
      location.hash = 'export';
    } else if (action === 'add-layer') {
      this._addLayerAction();
    } else if (action === 'remove-layer') {
      this._removeLayerAction();
    }
  },

  async _historyViewer() {
    const repo = this._activeRepoData();
    if (!repo) return;
    const name = repo.display_name || repo.path;

    const repoPath = repo.path;
    if (!repoPath) {
      App.showToast('Cannot determine repo path', 'error');
      return;
    }

    // Use configured git_viewer setting; fall back to tig for 'auto'
    let tool = null;
    try {
      const config = await API.getConfig();
      tool = (config.settings || {}).git_viewer || 'auto';
    } catch (e) { /* use default */ }
    if (!tool || tool === 'auto') tool = 'tig';

    if (window.TerminalManager) {
      const rm = this._project().match(/^(.+@[^:]+):(.*)$/);
      if (rm) {
        TerminalManager.show({
          ssh: rm[1],
          path: repoPath,
          cmd: tool,
          title: tool + ': ' + name,
        });
      } else {
        TerminalManager.show({
          cwd: repoPath,
          cmd: tool,
          title: tool + ': ' + name,
        });
      }
    }
  },

  async _trackRepo() {
    const name = this._activeRepoName();
    if (!name) return;
    try {
      await API.trackRepo(name, this._project());
      App.showToast(`Tracked: ${name}`, 'success');
      await this._refreshRepos();
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  async _hideRepoAction() {
    const name = this._activeRepoName();
    if (!name) return;
    const ok = await confirmModal(`Hide "${name}"?`);
    if (!ok) return;
    try {
      await API.hideRepo(name, this._project());
      App.showToast(`Hidden: ${name}`, 'success');
      await this._refreshRepos();
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  async _pruneBackupsAction() {
    const name = this._activeRepoName();
    if (!name) {
      // No repo selected — prune all repos
      const ok = await confirmModal('Prune backup branches in all repos?');
      if (!ok) return;
      try {
        let total = 0;
        for (const r of (this._repoData || [])) {
          const rName = r.display_name || r.name;
          const result = await API.pruneBackups(rName, this._project());
          total += result.pruned || 0;
        }
        App.showToast(total ? `Pruned ${total} backup branches` : 'No backup branches to prune',
                      total ? 'success' : 'info');
      } catch (e) {
        App.showToast(e.message, 'error');
      }
      return;
    }
    const ok = await confirmModal(`Prune backup branches in "${name}"?`);
    if (!ok) return;
    try {
      const result = await API.pruneBackups(name, this._project());
      App.showToast(`Pruned ${result.pruned} backup branches in ${name}`, 'success');
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  async _addLayerAction() {
    const name = this._activeRepoName();
    if (!name) return;
    try {
      const data = await API.getRepoLayers(name, this._project());
      const layers = data.layers || [];
      // Show unconfigured layers (those not in bblayers.conf)
      const unconfigured = layers.filter(l => !this._configuredLayers.has(l.path));
      if (!unconfigured.length) {
        App.showToast('All layers already configured', 'success');
        return;
      }
      const listHtml = unconfigured.map(l =>
        `<div class="dash-action-item" data-layer="${esc(l.path)}" style="padding:6px 8px;cursor:pointer">
          <span>${esc(l.name)}</span>
          <span class="dash-act-desc">${esc(l.path)}</span>
        </div>`
      ).join('');
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `<div class="modal" style="max-height:80vh;display:flex;flex-direction:column">
        <div class="modal-header"><span>Add Layer</span><button class="modal-close">\u00d7</button></div>
        <div class="modal-body" style="overflow-y:auto;max-height:60vh;padding:8px">${listHtml}</div>
        <div class="modal-footer"><button class="btn modal-cancel-btn">Cancel</button></div>
      </div>`;
      document.body.appendChild(overlay);
      const close = () => overlay.remove();
      overlay.querySelector('.modal-close').addEventListener('click', close);
      overlay.querySelector('.modal-cancel-btn').addEventListener('click', close);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      overlay.querySelectorAll('[data-layer]').forEach(item => {
        item.addEventListener('click', async () => {
          const layerPath = item.dataset.layer;
          close();
          try {
            await API.addLayer(layerPath, this._project());
            App.showToast(`Added layer: ${layerPath.split('/').pop()}`, 'success');
            await this._refreshRepos();
          } catch (e) {
            App.showToast(e.message, 'error');
          }
        });
      });
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  async _removeLayerAction() {
    const name = this._activeRepoName();
    if (!name) return;
    try {
      const data = await API.getRepoLayers(name, this._project());
      const layers = data.layers || [];
      // Show configured layers only
      const configured = layers.filter(l => this._configuredLayers.has(l.path));
      if (!configured.length) {
        App.showToast('No configured layers to remove', 'error');
        return;
      }
      const listHtml = configured.map(l =>
        `<div class="dash-action-item" data-layer="${esc(l.path)}" style="padding:6px 8px;cursor:pointer">
          <span>${esc(l.name)}</span>
          <span class="dash-act-desc">${esc(l.path)}</span>
        </div>`
      ).join('');
      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = `<div class="modal" style="max-height:80vh;display:flex;flex-direction:column">
        <div class="modal-header"><span>Remove Layer</span><button class="modal-close">\u00d7</button></div>
        <div class="modal-body" style="overflow-y:auto;max-height:60vh;padding:8px">${listHtml}</div>
        <div class="modal-footer"><button class="btn modal-cancel-btn">Cancel</button></div>
      </div>`;
      document.body.appendChild(overlay);
      const close = () => overlay.remove();
      overlay.querySelector('.modal-close').addEventListener('click', close);
      overlay.querySelector('.modal-cancel-btn').addEventListener('click', close);
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(); });
      overlay.querySelectorAll('[data-layer]').forEach(item => {
        item.addEventListener('click', async () => {
          const layerPath = item.dataset.layer;
          close();
          const ok = await confirmModal(`Remove layer "${layerPath.split('/').pop()}"?`);
          if (!ok) return;
          try {
            await API.removeLayer(layerPath, this._project());
            App.showToast(`Removed layer: ${layerPath.split('/').pop()}`, 'success');
            await this._refreshRepos();
          } catch (e) {
            App.showToast(e.message, 'error');
          }
        });
      });
    } catch (e) {
      App.showToast(e.message, 'error');
    }
  },

  _moveToIndex(idx) {
    if (idx < 0 || idx >= this._rows.length) return;
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      this._rows[this._activeRow].classList.remove('keyboard-active');
      this._rows[this._activeRow].setAttribute('tabindex', '-1');
      this._rows[this._activeRow].removeAttribute('aria-selected');
    }
    this._activeRow = idx;
    const row = this._rows[idx];
    if (row) {
      row.classList.add('keyboard-active');
      row.setAttribute('tabindex', '0');
      row.setAttribute('aria-selected', 'true');
      row.focus();
      row.scrollIntoView({ block: 'nearest' });
    }
  },

  _moveActive(delta) {
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      this._rows[this._activeRow].classList.remove('keyboard-active');
      this._rows[this._activeRow].setAttribute('tabindex', '-1');
      this._rows[this._activeRow].removeAttribute('aria-selected');
    }
    let next = this._activeRow + delta;
    if (next < 0) next = this._rows.length - 1;
    if (next >= this._rows.length) next = 0;
    this._activeRow = next;
    const row = this._rows[this._activeRow];
    if (row) {
      row.classList.add('keyboard-active');
      row.setAttribute('tabindex', '0');
      row.setAttribute('aria-selected', 'true');
      row.focus();
      row.scrollIntoView({ block: 'nearest' });
    }
  },

  // --- Pull patches wizard ---

  async _pullPatchesWizard() {
    const localRepoName = this._activeRepoName();
    if (!localRepoName) {
      App.showToast('Select a repo first', 'error');
      return;
    }

    try {
      // Step 1: Get remote projects
      const remotes = await API.getPullRemotes();
      if (!remotes.length) {
        App.showToast('No remote projects configured', 'error');
        return;
      }

      // Step 2: Select remote
      let remote;
      if (remotes.length === 1) {
        remote = remotes[0];
      } else {
        remote = await this._pullSelectRemoteModal(remotes);
        if (!remote) return;
      }

      // Step 3: Match repo
      App.showToast('Connecting to ' + remote.host + '...');
      let match;
      try {
        match = await API.pullMatchRepo(remote.path, localRepoName, this._project());
      } catch (err) {
        App.showToast('SSH error: ' + err.message, 'error');
        return;
      }

      let remoteRepo;
      if (match.matched && match.remote_repo) {
        remoteRepo = match.remote_repo;
      } else if (match.all_repos && match.all_repos.length) {
        remoteRepo = await this._pullSelectRepoModal(match.all_repos, match.host);
        if (!remoteRepo) return;
      } else {
        App.showToast('No repos found on remote', 'error');
        return;
      }

      // Step 4: Fetch commits
      App.showToast('Fetching commits...');
      let data;
      try {
        data = await API.pullCommits(remote.path, remoteRepo, localRepoName, this._project());
      } catch (err) {
        App.showToast('Error fetching commits: ' + err.message, 'error');
        return;
      }
      if (!data.count) {
        App.showToast('No new commits on remote', 'info');
        return;
      }

      // Step 5: Pick commits
      const selected = await this._pullCommitPickerModal(data, remote, remoteRepo, localRepoName);
      if (!selected || !selected.length) return;

      // Step 6: Choose method
      const method = await this._pullMethodModal(selected.length, localRepoName);
      if (!method) return;

      // Step 7: Apply
      App.showToast('Applying ' + selected.length + ' commit(s)...');
      try {
        const result = await API.pullApply(remote.path, remoteRepo, localRepoName, selected, method, this._project());
        App.showToast(result.message, result.status === 'ok' ? 'success' : 'error');
        if (result.status === 'ok') {
          await this._refreshRepos();
        }
      } catch (err) {
        App.showToast('Apply failed: ' + err.message, 'error');
      }
    } catch (err) {
      App.showToast('Pull patches error: ' + err.message, 'error');
    }
  },

  _pullSelectRemoteModal(remotes) {
    return new Promise(resolve => {
      const listHtml = remotes.map((r, i) => {
        return '<div class="dash-action-item" data-idx="' + i + '" style="padding:6px 8px;cursor:pointer">' +
          '<span style="flex:1">' + esc(r.label) + '</span>' +
          '<span class="dash-act-desc">' + esc(r.name) + '</span>' +
        '</div>';
      }).join('');

      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = '<div class="modal" style="max-height:80vh;display:flex;flex-direction:column">' +
        '<div class="modal-header">' +
          '<span>Select Remote Project</span>' +
          '<button class="modal-close">\u00d7</button>' +
        '</div>' +
        '<div class="modal-body" style="overflow-y:auto;max-height:60vh;padding:8px">' + listHtml + '</div>' +
        '<div class="modal-footer">' +
          '<button class="btn modal-cancel-btn">Cancel</button>' +
        '</div>' +
      '</div>';
      document.body.appendChild(overlay);

      const close = (val) => { overlay.remove(); resolve(val); };
      overlay.querySelector('.modal-close').addEventListener('click', () => close(null));
      overlay.querySelector('.modal-cancel-btn').addEventListener('click', () => close(null));
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(null); });
      overlay.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(null); });

      overlay.querySelectorAll('[data-idx]').forEach(item => {
        item.addEventListener('click', () => close(remotes[parseInt(item.dataset.idx)]));
      });

      // Focus first item
      const first = overlay.querySelector('[data-idx]');
      if (first) first.focus();
    });
  },

  _pullSelectRepoModal(repos, host) {
    return new Promise(resolve => {
      const listHtml = repos.map((r, i) => {
        const basename = r.split('/').pop();
        return '<div class="dash-action-item" data-idx="' + i + '" style="padding:6px 8px;cursor:pointer">' +
          '<span style="flex:1;font-weight:600">' + esc(basename) + '</span>' +
          '<span class="dash-act-desc" style="opacity:0.7">' + esc(r) + '</span>' +
        '</div>';
      }).join('');

      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = '<div class="modal" style="max-height:80vh;display:flex;flex-direction:column">' +
        '<div class="modal-header">' +
          '<span>Select Remote Repo (' + esc(host) + ')</span>' +
          '<button class="modal-close">\u00d7</button>' +
        '</div>' +
        '<div class="modal-body" style="overflow-y:auto;max-height:60vh;padding:8px">' + listHtml + '</div>' +
        '<div class="modal-footer">' +
          '<button class="btn modal-cancel-btn">Cancel</button>' +
        '</div>' +
      '</div>';
      document.body.appendChild(overlay);

      const close = (val) => { overlay.remove(); resolve(val); };
      overlay.querySelector('.modal-close').addEventListener('click', () => close(null));
      overlay.querySelector('.modal-cancel-btn').addEventListener('click', () => close(null));
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(null); });
      overlay.addEventListener('keydown', (e) => { if (e.key === 'Escape') close(null); });

      overlay.querySelectorAll('[data-idx]').forEach(item => {
        item.addEventListener('click', () => close(repos[parseInt(item.dataset.idx)]));
      });

      const first = overlay.querySelector('[data-idx]');
      if (first) first.focus();
    });
  },

  _pullCommitPickerModal(data, remote, remoteRepo, localRepoName) {
    return new Promise(resolve => {
      // commits are oldest-first from API; display newest-first
      const commits = data.commits.slice().reverse();
      const selected = new Set();
      let activeRow = -1;
      let rangeAnchor = null;
      let diffMode = 'stat';
      const diffCache = {};
      let rows = [];

      const overlay = document.createElement('div');
      overlay.className = 'modal-overlay';
      overlay.innerHTML = '<div class="modal" style="width:90vw;max-width:1400px;height:80vh;display:flex;flex-direction:column">' +
        '<div class="modal-header">' +
          '<span>Pull Patches \u2014 ' + esc(remoteRepo.split('/').pop()) + ' (' + data.count + ' commits)</span>' +
          '<button class="modal-close">\u00d7</button>' +
        '</div>' +
        '<div class="modal-body" style="display:flex;flex:1;overflow:hidden;padding:0">' +
          '<div class="commits-split" style="flex:1;display:flex">' +
            '<div class="commits-left" style="flex:0 0 clamp(280px,40%,500px);overflow-y:auto;display:flex;flex-direction:column">' +
              '<div class="commits-left-header" style="display:flex;align-items:center;justify-content:space-between">' +
                '<span>Remote (' + data.count + ' new)</span>' +
                '<span class="pull-count-badge badge" style="background:var(--accent);color:var(--bg-primary)">0 selected</span>' +
              '</div>' +
              '<div class="pull-commit-list" style="flex:1;overflow-y:auto"></div>' +
            '</div>' +
            '<div class="commits-resizer"></div>' +
            '<div class="commits-diff-panel">' +
              '<div class="commits-diff-header">' +
                '<span class="pull-diff-title"></span>' +
                '<span class="diff-mode-label">' + diffMode + '</span>' +
              '</div>' +
              '<div class="pull-diff-body">' +
                '<div class="commits-diff-placeholder">Select a commit to view diff</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div class="modal-footer" style="display:flex;gap:8px;align-items:center">' +
          '<span style="flex:1;opacity:0.6;font-size:var(--font-size-sm)">Tab=toggle  Space=range  a=all  n=none  d=stat/diff  Enter=confirm</span>' +
          '<button class="btn modal-cancel-btn">Cancel</button>' +
          '<button class="btn btn-primary pull-confirm-btn" disabled>Pull 0 commits</button>' +
        '</div>' +
      '</div>';
      document.body.appendChild(overlay);

      const listEl = overlay.querySelector('.pull-commit-list');
      const diffBody = overlay.querySelector('.pull-diff-body');
      const diffTitle = overlay.querySelector('.pull-diff-title');
      const modeLabel = overlay.querySelector('.diff-mode-label');
      const confirmBtn = overlay.querySelector('.pull-confirm-btn');
      const countBadge = overlay.querySelector('.pull-count-badge');

      // Build commit rows using same markup as CommitsView._renderSection
      let listHtml = '';
      commits.forEach((c) => {
        const fullSha = c[0];
        const sha = fullSha.slice(0, 7);
        const subject = c[1];
        listHtml += '<div class="commit-row" data-sha="' + esc(fullSha) + '" data-type="local" role="row" tabindex="-1">' +
          '<span class="commit-sha-col">' + esc(sha) + '</span>' +
          '<span class="commit-subject-col">' + esc(subject) + '</span>' +
        '</div>';
      });
      listEl.innerHTML = listHtml;
      rows = Array.from(listEl.querySelectorAll('.commit-row'));

      function updateSelectionUI() {
        const n = selected.size;
        confirmBtn.textContent = 'Pull ' + n + ' commit' + (n !== 1 ? 's' : '');
        confirmBtn.disabled = n === 0;
        countBadge.textContent = n + ' selected';
        countBadge.style.display = n > 0 ? '' : 'none';
        rows.forEach(row => {
          if (selected.has(row.dataset.sha)) {
            row.classList.add('commit-row-selected');
          } else {
            row.classList.remove('commit-row-selected');
          }
        });
      }

      function selectRow(idx) {
        if (activeRow >= 0 && rows[activeRow]) {
          rows[activeRow].classList.remove('active');
          rows[activeRow].setAttribute('tabindex', '-1');
          rows[activeRow].removeAttribute('aria-selected');
        }
        activeRow = idx;
        if (activeRow >= 0 && rows[activeRow]) {
          rows[activeRow].classList.add('active');
          rows[activeRow].setAttribute('tabindex', '0');
          rows[activeRow].setAttribute('aria-selected', 'true');
          rows[activeRow].focus();
          rows[activeRow].scrollIntoView({ block: 'nearest' });
        }
      }

      function moveActive(delta) {
        let next = activeRow + delta;
        if (next < 0) next = rows.length - 1;
        if (next >= rows.length) next = 0;
        selectRow(next);
        showDiffForRow(rows[next]);
      }

      // Toggle select (Tab) — same as CommitsView
      function toggleSelect() {
        if (activeRow < 0 || !rows[activeRow]) return;
        const sha = rows[activeRow].dataset.sha;
        if (!sha) return;
        if (selected.has(sha)) {
          selected.delete(sha);
        } else {
          selected.add(sha);
        }
        updateSelectionUI();
      }

      // Range select (Space) — same as CommitsView
      function rangeSelect() {
        if (activeRow < 0) return;
        if (rangeAnchor === null) {
          rangeAnchor = activeRow;
          const sha = rows[activeRow].dataset.sha;
          if (sha) selected.add(sha);
          updateSelectionUI();
          return;
        }
        const from = Math.min(rangeAnchor, activeRow);
        const to = Math.max(rangeAnchor, activeRow);
        for (let i = from; i <= to; i++) {
          const sha = rows[i].dataset.sha;
          if (sha) selected.add(sha);
        }
        rangeAnchor = null;
        updateSelectionUI();
      }

      function showDiffForRow(row) {
        if (!row) return;
        const sha = row.dataset.sha;
        if (!sha) return;
        diffTitle.textContent = sha.slice(0, 7) + ' \u2014 ' + (row.querySelector('.commit-subject-col')?.textContent || '');
        if (diffCache[sha]) {
          renderDiffBody(diffCache[sha]);
          return;
        }
        diffBody.innerHTML = '<div class="loading">Loading diff</div>';
        API.pullCommitShow(remote.path, remoteRepo, sha).then(info => {
          diffCache[sha] = info;
          // Only render if still focused on this commit
          if (activeRow >= 0 && rows[activeRow] && rows[activeRow].dataset.sha === sha) {
            renderDiffBody(info);
          }
        }).catch(() => {
          if (activeRow >= 0 && rows[activeRow] && rows[activeRow].dataset.sha === sha) {
            diffBody.innerHTML = '<div style="color:var(--red);padding:12px">Failed to load commit details</div>';
          }
        });
      }

      // Render diff body — same structure as CommitsView._renderDiffBody
      function renderDiffBody(d) {
        if (!d) return;
        if (d.error) {
          diffBody.innerHTML = '<div style="color:var(--red);padding:12px">' + esc(d.error) + '</div>';
          return;
        }
        let html = '<div class="commit-info-header">';
        html += '<div class="commit-info-subject">' + esc(d.subject || '') + '</div>';
        if (d.body) html += '<div class="commit-info-body">' + esc(d.body) + '</div>';
        html += '<div class="commit-info-meta">';
        html += '<span class="commit-info-sha">' + esc((d.sha || '').slice(0, 12)) + '</span>';
        if (d.author) html += ' <span class="commit-info-author">' + esc(d.author) + '</span>';
        if (d.date) html += ' <span class="commit-info-date">' + esc(d.date) + '</span>';
        html += '</div></div>';

        if (diffMode === 'stat') {
          if (d.stat) html += '<pre class="commits-diff-stat">' + esc(d.stat) + '</pre>';
          else html += '<div style="color:var(--text-muted);padding:12px">No changes</div>';
        } else {
          if (d.stat) html += '<pre class="commits-diff-stat">' + esc(d.stat) + '</pre>';
          if (d.diff) html += '<pre class="diff-panel">' + formatDiff(d.diff) + '</pre>';
          else html += '<div style="color:var(--text-muted);padding:12px">No diff for this commit</div>';
        }
        modeLabel.textContent = diffMode;
        diffBody.innerHTML = html;
      }

      // Event handlers
      const close = (val) => { overlay.remove(); resolve(val); };

      overlay.querySelector('.modal-close').addEventListener('click', () => close(null));
      overlay.querySelector('.modal-cancel-btn').addEventListener('click', () => close(null));
      overlay.addEventListener('click', (e) => { if (e.target === overlay) close(null); });

      confirmBtn.addEventListener('click', () => {
        // Return in oldest-first order for git am
        const result = data.commits.filter(c => selected.has(c[0])).map(c => c[0]);
        close(result);
      });

      // Click on commit rows — select + show diff (single click focuses, doesn't toggle)
      rows.forEach((row, i) => {
        row.addEventListener('click', () => {
          selectRow(i);
          showDiffForRow(row);
        });
      });

      overlay.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') { close(null); return; }
        if (e.key === 'j' || e.key === 'ArrowDown') {
          e.preventDefault();
          moveActive(1);
        } else if (e.key === 'k' || e.key === 'ArrowUp') {
          e.preventDefault();
          moveActive(-1);
        } else if (e.key === 'Tab') {
          e.preventDefault();
          toggleSelect();
        } else if (e.key === ' ') {
          e.preventDefault();
          rangeSelect();
        } else if (e.key === 'a') {
          e.preventDefault();
          commits.forEach(c => selected.add(c[0]));
          updateSelectionUI();
        } else if (e.key === 'n' || e.key === 'u') {
          e.preventDefault();
          selected.clear();
          rangeAnchor = null;
          updateSelectionUI();
        } else if (e.key === 'd') {
          e.preventDefault();
          diffMode = diffMode === 'stat' ? 'diff' : 'stat';
          const sha = activeRow >= 0 && rows[activeRow] ? rows[activeRow].dataset.sha : null;
          if (sha && diffCache[sha]) renderDiffBody(diffCache[sha]);
        } else if (e.key === 'Home') {
          e.preventDefault();
          selectRow(0);
          if (rows[0]) showDiffForRow(rows[0]);
        } else if (e.key === 'End') {
          e.preventDefault();
          selectRow(rows.length - 1);
          if (rows[rows.length - 1]) showDiffForRow(rows[rows.length - 1]);
        } else if (e.key === 'Enter') {
          e.preventDefault();
          if (selected.size > 0) {
            const result = data.commits.filter(c => selected.has(c[0])).map(c => c[0]);
            close(result);
          }
        }
      });

      // Initial state
      selectRow(0);
      if (rows[0]) showDiffForRow(rows[0]);
      updateSelectionUI();
    });
  },

  _pullMethodModal(count, localRepoName) {
    return modal(
      'Import Method',
      '<p>Import ' + count + ' commit' + (count !== 1 ? 's' : '') + ' into <strong>' + esc(localRepoName) + '</strong></p>' +
        '<p style="opacity:0.6;font-size:13px">Choose how to apply the patches:</p>',
      [
        { label: 'Cancel', value: null },
        { label: 'Save .patch files', value: 'save' },
        { label: 'Fetch + cherry-pick', value: 'fetch' },
        { label: 'Apply (git am)', value: 'am', primary: true },
      ]
    );
  },
};
