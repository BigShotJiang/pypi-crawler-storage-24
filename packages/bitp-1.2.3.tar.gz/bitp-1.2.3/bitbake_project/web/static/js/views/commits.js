/* Commits view — full commit browser for a single repo
 * Navigated to from explore, reads App.state.selectedRepo
 * Split layout: commit list left, terminal-style diff preview right
 *
 * Reads App.state.selectedProject for project context (set by dashboard).
 * Passes ?project= to API so no project activation is needed.
 */
const CommitsView = {
  _activeRow: -1,
  _rows: [],
  _repoName: '',
  _project: '',
  _diffOpen: false,
  _refs: {},          // SHA -> [{name, type}] decoration map
  _diffMode: 'stat',  // 'stat' or 'diff' — toggles with 'd'
  _lastShowData: null, // cached commit show response for mode toggle
  _upstreamLimit: 500,  // pagination: how many upstream-to-pull to fetch
  _contextLimit: 20,    // pagination: how many context commits to fetch
  _selected: new Set(),   // multi-select: set of selected SHAs
  _rangeAnchor: null,     // range select: index of first endpoint
  _graphMode: false,      // graph view toggle
  _fileListMode: false,   // file list view in diff panel
  _commitsData: null,     // cached commits response for reload
  _treeMode: false,
  _treeData: null,        // cached {tree, file_count} from API
  _treeExpanded: new Set(),      // expanded directory paths
  _treeFileExpanded: new Set(),  // expanded file paths (showing commits)
  _treeFileCommits: {},          // path -> [{hash, subject}]
  _treeFileHasMore: {},          // path -> bool
  _treeFileLimits: {},           // path -> current limit
  _treeChangedFiles: new Set(),  // files changed in focus commit
  _treeFocusCommit: null,
  _treeCommitView: false,        // viewing a commit diff from within tree
  _preTreeShowData: null,        // saved diff data before entering tree

  keyBindings: [
    {key: 'j/k', desc: 'Navigate commits'},
    {key: 'Enter', desc: 'Show diff'},
    {key: 'd', desc: 'Toggle stat/diff'},
    {key: 'g', desc: 'Toggle graph', action: 'g'},
    {key: 'c', desc: 'Copy SHA'},
    {key: 'Tab', desc: 'Mark/unmark', action: 'Tab'},
    {key: 'Space', desc: 'Range select', action: ' '},
    {key: 'u', desc: 'Clear selection', action: 'u'},
    {sep: true},
    {key: 'e', desc: 'Export patches', action: 'e'},
    {key: 'f', desc: 'File tree', action: 'f'},
    {key: 'p', desc: 'Lore search', action: 'p'},
    {key: 't', desc: 'History viewer', action: 't'},
    {sep: true},
    {key: 'D', desc: 'Drop commits', action: 'D'},
    {key: 'i', desc: 'Rebase', action: 'i'},
    {key: 'l', desc: 'Layers', action: 'l'},
    {sep: true},
    {key: 'b', desc: 'Back to explore'},
    {key: 'Esc', desc: 'Close diff'},
  ],

  async render(container, state) {
    this._repoName = state.selectedRepo || '';
    this._project = state.selectedProject || '';
    this._activeRow = -1;
    this._rows = [];
    this._diffOpen = false;
    this._refs = {};
    this._diffMode = 'stat';
    this._lastShowData = null;
    this._upstreamLimit = 500;
    this._contextLimit = 20;
    this._selected = new Set();
    this._rangeAnchor = null;
    this._graphMode = false;
    this._fileListMode = false;
    this._commitsData = null;
    this._treeMode = false;
    this._treeData = null;
    this._treeExpanded = new Set();
    this._treeFileExpanded = new Set();
    this._treeFileCommits = {};
    this._treeFileHasMore = {};
    this._treeFileLimits = {};
    this._treeChangedFiles = new Set();
    this._treeFocusCommit = null;
    this._treeCommitView = false;
    this._preTreeShowData = null;

    if (!this._repoName) {
      container.innerHTML = '<div class="empty-state"><h3>No repo selected</h3><p><a href="#explore">Back to Explore</a></p></div>';
      return;
    }

    container.innerHTML = `
      <div class="commits-split">
        <div class="commits-left" id="commits-left">
          <div class="commits-left-header">
            <h2>Commits: <span style="color:var(--accent)">${esc(this._repoName)}</span></h2>
            <div id="commits-info"></div>
          </div>
          <div id="commits-list" class="loading">Loading commits</div>
        </div>
        <div class="commits-resizer" id="commits-resizer"></div>
        <div id="commits-diff-panel" class="commits-diff-panel">
          <div class="commits-diff-header">
            <span id="commits-diff-title"></span>
            <div class="btn-group">
              <span id="diff-mode-label" class="diff-mode-label">stat</span>
              <button class="btn" id="diff-toggle-mode" title="Toggle word wrap">Wrap lines</button>
              <button class="btn btn-link" id="diff-back-btn" style="display:none" title="Back (Esc)">\u2190 Back</button>
            </div>
          </div>
          <div id="commits-diff-body">
            <div class="commits-diff-placeholder">Select a commit to view diff</div>
          </div>
        </div>
      </div>
      <div class="commits-footer">
        <button class="btn btn-link" id="commits-back">\u2190 Back</button>
        <div class="btn-group">
          <button class="btn btn-action" id="commits-fetch">\u21bb Fetch</button>
          <button class="btn btn-primary" id="commits-update">\u2191 Update</button>
        </div>
      </div>
    `;

    // Action buttons
    document.getElementById('commits-back').addEventListener('click', () => {
      location.hash = 'explore';
    });

    document.getElementById('commits-fetch').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.classList.add('loading');
      btn.disabled = true;
      try {
        await API.fetchRepo(this._repoName, this._project);
        App.showToast('Fetch done: ' + this._repoName, 'success');
        this._loadCommits();
      } catch (err) { App.showToast(err.message, 'error'); }
      btn.classList.remove('loading');
      btn.disabled = false;
    });

    document.getElementById('commits-update').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.classList.add('loading');
      btn.disabled = true;
      try {
        await API.updateRepo(this._repoName, undefined, this._project);
        App.showToast('Update done: ' + this._repoName, 'success');
        this._loadCommits();
      } catch (err) { App.showToast(err.message, 'error'); }
      btn.classList.remove('loading');
      btn.disabled = false;
    });

    document.getElementById('diff-toggle-mode').addEventListener('click', () => {
      this._toggleWrap();
    });

    document.getElementById('diff-back-btn').addEventListener('click', () => {
      this._treeBack();
    });

    // Resizable divider between commit list and diff panel
    const resizer = document.getElementById('commits-resizer');
    const leftPanel = document.getElementById('commits-left');
    if (resizer && leftPanel) {
      // Restore saved width
      const saved = localStorage.getItem('bit-commits-left-width');
      if (saved) leftPanel.style.flex = '0 0 ' + saved + 'px';

      let startX, startW;
      const onMouseMove = (e) => {
        const newW = startW + (e.clientX - startX);
        const clamped = Math.max(200, Math.min(newW, window.innerWidth - 300));
        leftPanel.style.flex = '0 0 ' + clamped + 'px';
      };
      const onMouseUp = () => {
        document.removeEventListener('mousemove', onMouseMove);
        document.removeEventListener('mouseup', onMouseUp);
        document.body.style.cursor = '';
        document.body.style.userSelect = '';
        // Save width
        const w = leftPanel.getBoundingClientRect().width;
        localStorage.setItem('bit-commits-left-width', Math.round(w));
      };
      resizer.addEventListener('mousedown', (e) => {
        e.preventDefault();
        startX = e.clientX;
        startW = leftPanel.getBoundingClientRect().width;
        document.body.style.cursor = 'col-resize';
        document.body.style.userSelect = 'none';
        document.addEventListener('mousemove', onMouseMove);
        document.addEventListener('mouseup', onMouseUp);
      });
    }

    this._loadCommits();
  },

  async _loadCommits() {
    const listEl = document.getElementById('commits-list');
    const infoEl = document.getElementById('commits-info');
    if (!listEl) return;
    listEl.innerHTML = '<div class="loading">Loading commits</div>';

    try {
      // Load repo info + commits in parallel
      const [reposData, commitsData] = await Promise.all([
        API.getRepos(this._project),
        API.getRepoCommits(this._repoName, this._project, {
          upstream_limit: this._upstreamLimit,
          context_limit: this._contextLimit,
        }),
      ]);

      // Store refs map for decoration rendering
      this._refs = commitsData.refs || {};
      this._commitsData = commitsData;

      // Find this repo's info
      const repo = reposData.find(r =>
        (r.display_name || r.path) === this._repoName
      );

      // Show branch + dirty info + selection badge
      this._repo = repo;
      this._updateInfoBadges();

      // Build commit list
      this._selected = new Set();
      this._rangeAnchor = null;
      this._renderCommitList(listEl, commitsData, repo);
    } catch (e) {
      listEl.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  _updateInfoBadges() {
    const infoEl = document.getElementById('commits-info');
    if (!infoEl) return;
    let infoHTML = '';
    if (this._commitsData && this._commitsData.branch) {
      infoHTML += `<span class="badge badge-ahead">${esc(this._commitsData.branch)}</span> `;
    }
    if (this._repo && this._repo.is_dirty) {
      infoHTML += '<span class="badge badge-dirty">dirty</span> ';
    }
    if (this._selected.size > 0) {
      infoHTML += `<span class="badge" style="background:var(--accent);color:var(--bg-primary)">${this._selected.size} selected</span> `;
    }
    if (this._graphMode) {
      infoHTML += '<span class="badge" style="background:var(--purple);color:var(--bg-primary)">graph</span> ';
    }
    infoEl.innerHTML = infoHTML;
  },

  _renderCommitList(container, data, repo) {
    const local = data.local || [];
    const upstream = data.upstream || [];
    const context = data.context || [];
    const baseRef = data.base_ref || '';
    let html = '';

    // Dirty indicator at top
    if (repo && repo.is_dirty) {
      html += `<div class="commit-row commit-row-dirty" data-type="dirty" role="row" tabindex="-1">
        <span class="commit-sha-col" style="color:var(--red)">working</span>
        <span class="commit-subject-col" style="color:var(--red)">Uncommitted changes</span>
      </div>`;
    }

    // Local section
    if (local.length > 0) {
      html += `<div class="commits-section-header">Local (${local.length} commit${local.length !== 1 ? 's' : ''})</div>`;
      html += this._renderSection(local, 'local');
    }

    // Upstream section (to pull)
    if (upstream.length > 0) {
      html += `<div class="commits-section-header" style="color:var(--yellow)">Upstream (${upstream.length} to pull)</div>`;
      html += this._renderSection(upstream, 'upstream');
      // Load more upstream if capped
      if (upstream.length >= this._upstreamLimit) {
        html += `<div class="commits-load-more" id="load-more-upstream">Load more upstream commits...</div>`;
      }
    }

    // Base ref separator
    if (baseRef && (upstream.length > 0 || context.length > 0)) {
      html += `<div class="commits-base-ref">\u2500\u2500 ${esc(baseRef)} \u2500\u2500</div>`;
    }

    // Context section (below merge base, for reference)
    if (context.length > 0) {
      html += `<div class="commits-section-header" style="color:var(--text-muted)">Context (${context.length} recent)</div>`;
      html += this._renderSection(context, 'context');
      // Load more context
      if (context.length >= this._contextLimit) {
        html += `<div class="commits-load-more" id="load-more-context">Load more history...</div>`;
      }
    }

    if (!local.length && !upstream.length && !context.length && !(repo && repo.is_dirty)) {
      html = '<div class="empty-state" style="padding:20px"><h3>No commits to show</h3><p>Repo is up to date</p></div>';
    }

    container.innerHTML = html;
    container.classList.remove('loading');

    // Collect navigable rows
    this._rows = Array.from(container.querySelectorAll('.commit-row'));
    this._activeRow = -1;

    // Click handlers
    this._rows.forEach((row, i) => {
      row.addEventListener('click', () => {
        this._selectRow(i);
        this._showDiffForRow(row);
      });
    });

    // Auto-select first commit to show diff preview immediately
    if (this._rows.length > 0) {
      this._selectRow(0);
      this._showDiffForRow(this._rows[0]);
    }

    // Load-more handlers
    const loadMoreUp = document.getElementById('load-more-upstream');
    if (loadMoreUp) {
      loadMoreUp.addEventListener('click', () => {
        this._upstreamLimit += 200;
        this._loadCommits();
      });
    }
    const loadMoreCtx = document.getElementById('load-more-context');
    if (loadMoreCtx) {
      loadMoreCtx.addEventListener('click', () => {
        this._contextLimit += 200;
        this._loadCommits();
      });
    }

    // SHA copy handlers
    container.querySelectorAll('.commit-sha-copy').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const sha = el.dataset.sha;
        if (sha && navigator.clipboard) {
          navigator.clipboard.writeText(sha).then(() => {
            App.showToast('SHA copied', 'success');
          });
        }
      });
    });

    // Icon button handlers
    container.querySelectorAll('.commit-actions .btn-icon').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const row = btn.closest('.commit-row');
        const idx = this._rows.indexOf(row);
        if (idx >= 0) this._selectRow(idx);
        const act = btn.dataset.action;
        if (act === 'copy') this._copyActiveSha();
        else if (act === 'export') this._exportPatches();
        else if (act === 'files') this._showFileList();
        else if (act === 'lore') this._loreSearch();
      });
    });

    // Right-click context menu
    this._rows.forEach((row, i) => {
      row.addEventListener('contextmenu', (e) => {
        e.preventDefault();
        this._showCommitContextMenu(e, row, i);
      });
    });
  },

  /** Format ref decorations tig-style: [local] {remote} <tag> */
  _formatRefs(fullSha) {
    // Check all SHA prefixes that might match
    const refs = this._refs[fullSha];
    if (!refs || !refs.length) {
      // Try prefix match (refs map uses full 40-char SHA, commits may be shorter)
      for (const sha in this._refs) {
        if (sha.startsWith(fullSha) || fullSha.startsWith(sha)) {
          return this._formatRefList(this._refs[sha]);
        }
      }
      return '';
    }
    return this._formatRefList(refs);
  },

  _formatRefList(refs) {
    return refs.map(r => {
      if (r.type === 'local') return `<span class="commit-ref commit-ref-local">[${esc(r.name)}]</span>`;
      if (r.type === 'remote') return `<span class="commit-ref commit-ref-remote">{${esc(r.name)}}</span>`;
      if (r.type === 'tag') return `<span class="commit-ref commit-ref-tag">&lt;${esc(r.name)}&gt;</span>`;
      return '';
    }).join(' ');
  },

  _renderSection(commits, type) {
    let html = '';
    commits.forEach(c => {
      let sha = '', fullSha = '', subject = '';

      if (typeof c === 'string') {
        const match = c.match(/^([0-9a-f]{7,40})\s+(.*)$/);
        if (match) {
          fullSha = match[1];
          sha = match[1].slice(0, 7);
          subject = match[2];
        } else {
          subject = c;
        }
      } else if (c && typeof c === 'object') {
        fullSha = c.sha || c.hash || '';
        sha = fullSha.slice(0, 7);
        subject = c.subject || c.message || '';
      }

      const refsHtml = fullSha ? this._formatRefs(fullSha) : '';

      html += `<div class="commit-row" data-sha="${esc(fullSha)}" data-type="${type}" role="row" tabindex="-1">`;
      if (sha) {
        html += `<span class="commit-sha-col commit-sha-copy" data-sha="${esc(fullSha)}" title="Click to copy">${esc(sha)}</span>`;
      } else {
        html += '<span class="commit-sha-col"></span>';
      }
      if (refsHtml) {
        html += `<span class="commit-refs-col">${refsHtml}</span>`;
      }
      html += `<span class="commit-subject-col">${esc(subject)}</span>`;
      html += `<span class="commit-actions">`;
      html += `<button class="btn-icon" data-action="copy" title="Copy SHA (c)">\u29c9</button>`;
      html += `<button class="btn-icon" data-action="export" title="Export patch (e)">\u2197</button>`;
      html += `<button class="btn-icon" data-action="lore" title="Lore search (p)">\u2315</button>`;
      html += `<button class="btn-icon" data-action="files" title="File tree (f)">\u251c</button>`;
      html += `</span>`;
      html += '</div>';
    });
    return html;
  },

  _selectRow(index) {
    // Deselect previous
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      this._rows[this._activeRow].classList.remove('active');
      this._rows[this._activeRow].setAttribute('tabindex', '-1');
      this._rows[this._activeRow].removeAttribute('aria-selected');
    }
    this._activeRow = index;
    if (this._rows[index]) {
      this._rows[index].classList.add('active');
      this._rows[index].setAttribute('tabindex', '0');
      this._rows[index].setAttribute('aria-selected', 'true');
      this._rows[index].focus();
      this._rows[index].scrollIntoView({ block: 'nearest' });
    }
  },

  async _showDiffForRow(row) {
    const sha = row.dataset.sha;
    const type = row.dataset.type;
    const title = document.getElementById('commits-diff-title');
    const body = document.getElementById('commits-diff-body');

    this._diffOpen = true;
    this._lastShowData = null;
    this._fileListMode = false;

    if (type === 'dirty') {
      title.textContent = 'Working tree changes';
      body.innerHTML = '<div class="loading">Loading diff</div>';
      try {
        const data = await API.getRepoDiff(this._repoName, this._project);
        const diffText = data.diff || '';
        if (diffText) {
          body.innerHTML = '<pre class="diff-panel">' + formatDiff(diffText) + '</pre>';
        } else {
          body.innerHTML = '<div style="color:var(--text-muted);padding:12px">No changes</div>';
        }
      } catch (e) {
        body.innerHTML = `<div style="color:var(--red);padding:12px">Error: ${esc(e.message)}</div>`;
      }
      return;
    }

    if (!sha) return;

    title.textContent = sha.slice(0, 7) + ' \u2014 ' + (row.querySelector('.commit-subject-col')?.textContent || '');
    body.innerHTML = '<div class="loading">Loading diff</div>';

    try {
      const data = await API.getCommitShow(this._repoName, sha, this._project);
      this._lastShowData = data;
      this._renderDiffBody(data);
    } catch (e) {
      body.innerHTML = `<div style="color:var(--red);padding:12px">Error: ${esc(e.message)}</div>`;
    }
  },

  /** Render diff body from cached show data, respecting _diffMode */
  _renderDiffBody(data) {
    const body = document.getElementById('commits-diff-body');
    const modeLabel = document.getElementById('diff-mode-label');
    if (!body || !data) return;

    let html = '';

    // Commit metadata header
    html += '<div class="commit-info-header">';
    html += `<div class="commit-info-subject">${esc(data.subject || '')}</div>`;
    if (data.body) {
      html += `<div class="commit-info-body">${esc(data.body)}</div>`;
    }
    html += '<div class="commit-info-meta">';
    html += `<span class="commit-info-sha">${esc((data.sha || '').slice(0, 12))}</span>`;
    if (data.author) html += ` <span class="commit-info-author">${esc(data.author)}</span>`;
    if (data.date) html += ` <span class="commit-info-date">${esc(data.date)}</span>`;
    html += '</div>';
    html += '</div>';

    if (this._diffMode === 'stat') {
      // Stat-only mode (default, like TUI)
      if (data.stat) {
        html += `<pre class="commits-diff-stat">${esc(data.stat)}</pre>`;
      } else {
        html += '<div style="color:var(--text-muted);padding:12px">No changes</div>';
      }
      if (modeLabel) modeLabel.textContent = 'stat';
    } else {
      // Full diff mode
      if (data.stat) {
        html += `<pre class="commits-diff-stat">${esc(data.stat)}</pre>`;
      }
      if (data.diff) {
        html += '<pre class="diff-panel">' + formatDiff(data.diff) + '</pre>';
      } else {
        html += '<div style="color:var(--text-muted);padding:12px">No diff for this commit</div>';
      }
      if (modeLabel) modeLabel.textContent = 'diff';
    }

    body.innerHTML = html;
  },

  _closeDiff() {
    const body = document.getElementById('commits-diff-body');
    const title = document.getElementById('commits-diff-title');
    if (body) body.innerHTML = '<div class="commits-diff-placeholder">Select a commit to view diff</div>';
    if (title) title.textContent = '';
    this._diffOpen = false;
    this._lastShowData = null;
    this._fileListMode = false;
  },

  _toggleDiffMode() {
    this._diffMode = this._diffMode === 'stat' ? 'diff' : 'stat';
    if (this._lastShowData) {
      this._renderDiffBody(this._lastShowData);
    }
  },

  _toggleWrap() {
    const body = document.getElementById('commits-diff-body');
    if (!body) return;
    const btn = document.getElementById('diff-toggle-mode');
    const wrapped = body.dataset.wrap === 'true';
    body.dataset.wrap = wrapped ? 'false' : 'true';
    btn.textContent = wrapped ? 'Wrap lines' : 'No wrap';
  },

  _copyActiveSha() {
    if (this._activeRow < 0 || !this._rows[this._activeRow]) return;
    const sha = this._rows[this._activeRow].dataset.sha;
    if (sha && navigator.clipboard) {
      navigator.clipboard.writeText(sha).then(() => {
        App.showToast('SHA copied: ' + sha.slice(0, 7), 'success');
      });
    }
  },

  // --- Multi-select (Tab) ---
  _toggleSelect() {
    if (this._activeRow < 0 || !this._rows[this._activeRow]) return;
    const row = this._rows[this._activeRow];
    const sha = row.dataset.sha;
    if (!sha) return;

    if (this._selected.has(sha)) {
      this._selected.delete(sha);
      row.classList.remove('commit-row-selected');
    } else {
      this._selected.add(sha);
      row.classList.add('commit-row-selected');
    }
    this._updateInfoBadges();
  },

  // --- Range select (Space) ---
  _rangeSelect() {
    if (this._activeRow < 0) return;

    if (this._rangeAnchor === null) {
      // Set anchor
      this._rangeAnchor = this._activeRow;
      // Also select the anchor row
      const row = this._rows[this._activeRow];
      if (row && row.dataset.sha) {
        this._selected.add(row.dataset.sha);
        row.classList.add('commit-row-selected');
      }
      this._updateInfoBadges();
      return;
    }

    // Fill range between anchor and current
    const from = Math.min(this._rangeAnchor, this._activeRow);
    const to = Math.max(this._rangeAnchor, this._activeRow);
    for (let i = from; i <= to; i++) {
      const row = this._rows[i];
      if (row && row.dataset.sha) {
        this._selected.add(row.dataset.sha);
        row.classList.add('commit-row-selected');
      }
    }
    this._rangeAnchor = null;
    this._updateInfoBadges();
  },

  // --- Clear all selections (u) ---
  _clearSelection() {
    if (this._selected.size === 0) return;
    this._selected.clear();
    this._rangeAnchor = null;
    this._rows.forEach(row => row.classList.remove('commit-row-selected'));
    this._updateInfoBadges();
    App.showToast('Selection cleared', 'success');
  },

  /** Get selected SHAs or fall back to active row */
  _getTargetShas() {
    if (this._selected.size > 0) return Array.from(this._selected);
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      const sha = this._rows[this._activeRow].dataset.sha;
      if (sha) return [sha];
    }
    return [];
  },

  // --- Export patches (e) ---
  async _exportPatches() {
    const shas = this._getTargetShas();
    if (!shas.length) {
      App.showToast('No commits selected', 'error');
      return;
    }

    App.showToast('Exporting ' + shas.length + ' patch(es)...', 'success');
    try {
      const data = await API.exportRepoPatches(this._repoName, shas, this._project);
      const patches = data.patches || [];
      for (const patch of patches) {
        if (patch.error) {
          App.showToast(patch.error, 'error');
          continue;
        }
        // Trigger browser download
        const blob = new Blob([patch.content], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = patch.filename;
        document.body.appendChild(a);
        a.click();
        a.remove();
        URL.revokeObjectURL(url);
      }
      App.showToast('Exported ' + patches.length + ' patch(es)', 'success');
    } catch (e) {
      App.showToast('Export failed: ' + e.message, 'error');
    }
  },

  // --- Graph view (g) ---
  async _toggleGraph() {
    this._graphMode = !this._graphMode;
    this._updateInfoBadges();

    const listEl = document.getElementById('commits-list');
    if (!listEl) return;

    if (this._graphMode) {
      // Fetch and show graph
      listEl.innerHTML = '<div class="loading">Loading graph</div>';
      try {
        const data = await API.getRepoGraph(this._repoName, 80, this._project);
        listEl.innerHTML = '<pre class="graph-view">' + esc(data.graph || '') + '</pre>';
      } catch (e) {
        listEl.innerHTML = `<div style="color:var(--red);padding:12px">Error: ${esc(e.message)}</div>`;
      }
      this._rows = [];
      this._activeRow = -1;
    } else {
      // Restore normal commit list
      if (this._commitsData) {
        this._renderCommitList(listEl, this._commitsData, this._repo);
      } else {
        this._loadCommits();
      }
    }
  },

  // --- Drop commits (D) ---
  async _dropCommits() {
    // Collect selected local SHAs
    const allShas = this._getTargetShas();
    // Filter to only local commits
    const localShas = allShas.filter(sha => {
      const row = document.querySelector(`.commit-row[data-sha="${sha}"][data-type="local"]`);
      return !!row;
    });

    if (!localShas.length) {
      App.showToast('No local commits selected to drop', 'error');
      return;
    }

    // Build confirmation message
    const lines = localShas.map(sha => {
      const row = document.querySelector(`.commit-row[data-sha="${sha}"]`);
      const subject = row ? (row.querySelector('.commit-subject-col')?.textContent || '') : '';
      return sha.slice(0, 12) + ' ' + subject;
    });
    const bodyHTML = '<p>Drop ' + localShas.length + ' commit(s)?</p>' +
      '<pre style="font-size:var(--font-size-sm);max-height:200px;overflow:auto;margin:8px 0">' +
      esc(lines.join('\n')) + '</pre>' +
      '<p style="color:var(--yellow)">A backup branch will be created.</p>';

    const ok = await modal('Drop Commits', bodyHTML, [
      { label: 'Cancel', value: false },
      { label: 'Drop', value: true, danger: true },
    ]);
    if (!ok) return;

    try {
      const data = await API.dropCommits(this._repoName, localShas, this._project);
      App.showToast(data.message || 'Commits dropped', 'success');
      this._selected = new Set();
      this._loadCommits();
    } catch (e) {
      App.showToast('Drop failed: ' + e.message, 'error');
    }
  },

  // --- Interactive rebase (i) ---
  async _interactiveRebase() {
    const allLocal = this._commitsData ? (this._commitsData.local || []) : [];
    if (!allLocal.length) {
      App.showToast('No local commits to rebase', 'error');
      return;
    }

    // Warn about dirty working tree
    if (this._repo && this._repo.is_dirty) {
      const dirtyOk = await confirmModal(
        'Working tree has uncommitted changes. Rebase may fail or lose changes.\n\nContinue anyway?');
      if (!dirtyOk) return;
    }

    // Build ordered list of local commit SHAs (newest-first, matching API order)
    const localShas = allLocal.map(c => {
      if (typeof c === 'string') {
        const m = c.match(/^([0-9a-f]{7,40})\s/);
        return m ? m[1] : '';
      }
      return c.sha || c.hash || '';
    }).filter(Boolean);

    // Use base_sha (resolved before fetch) so the rebase matches what the
    // user sees.  NEVER fall back to base_ref — it's a symbolic ref that may
    // have moved after the fetch in query_repo_commits.  If base_sha is
    // missing, derive a SHA-based base from the oldest local commit.
    let baseOverride = this._commitsData.base_sha || '';
    if (!baseOverride && localShas.length > 0) {
      // Parent of oldest local commit is the natural rebase base
      baseOverride = localShas[localShas.length - 1] + '^';
    }
    let selectedCount = 0;
    if (this._selected.size > 0) {
      // Find which selected SHAs are local commits
      const selectedLocal = localShas.filter(sha => this._selected.has(sha));
      selectedCount = selectedLocal.length;

      if (selectedCount > 0) {
        // Oldest selected commit (last in newest-first array)
        const oldest = selectedLocal[selectedLocal.length - 1];
        // If it's NOT the oldest local commit, use SHA^ as base
        if (oldest !== localShas[localShas.length - 1]) {
          baseOverride = oldest + '^';
        }
      }
    }

    // Build confirmation message
    let msg = 'Start interactive rebase';
    if (selectedCount > 0) {
      msg += ` on ${selectedCount} selected commit${selectedCount !== 1 ? 's' : ''}`;
    } else {
      msg += ` on all ${allLocal.length} local commit${allLocal.length !== 1 ? 's' : ''}`;
    }
    msg += '?\n\nA backup branch will be created before rebasing.';

    const ok = await confirmModal(msg);
    if (!ok) return;

    try {
      const data = await API.rebasePrepare(this._repoName, this._project, baseOverride);
      App.showToast('Backup: ' + data.backup_branch, 'success');
      if (data.cherry_picked) {
        App.showToast(data.cherry_picked + ' commit' +
          (data.cherry_picked !== 1 ? 's' : '') +
          ' already upstream \u2014 excluded from rebase', 'info');
      }

      const cmd = 'git rebase -i ' + data.base;

      // Open terminal and run the rebase command directly
      if (window.TerminalManager) {
        const rm = this._project.match(/^(.+@[^:]+):(.*)$/);
        if (rm) {
          // Remote project — SSH into host, cd to repo, run rebase
          TerminalManager.show({
            ssh: rm[1],
            path: data.repo_path,
            cmd: cmd,
            title: 'Rebase: ' + this._repoName,
          });
        } else {
          TerminalManager.show({
            cwd: data.repo_path,
            cmd: cmd,
            title: 'Rebase: ' + this._repoName,
          });
        }
      }

      // Show rebase info in diff panel
      const body = document.getElementById('commits-diff-body');
      const title = document.getElementById('commits-diff-title');
      if (body && title) {
        title.textContent = 'Interactive Rebase';
        const cherryNote = data.cherry_picked
          ? '<p style="margin-bottom:8px;color:var(--yellow)">' +
            data.cherry_picked + ' commit' + (data.cherry_picked !== 1 ? 's' : '') +
            ' already upstream \u2014 excluded from rebase editor</p>'
          : '';
        body.innerHTML = '<div style="padding:12px">' +
          '<p style="margin-bottom:8px">Backup branch: <span style="color:var(--green)">' + esc(data.backup_branch) + '</span></p>' +
          cherryNote +
          '<p style="margin-bottom:8px">Rebase running in terminal below:</p>' +
          '<pre style="padding:8px;background:var(--bg-tertiary);border-radius:4px;cursor:pointer" ' +
          'title="Click to copy" id="rebase-cmd-copy">' + esc(cmd) + '</pre>' +
          '<p style="color:var(--text-muted);font-size:var(--font-size-sm);margin-top:8px">' +
          'To undo: <code>git rebase --abort</code> or <code>git reset --hard ' + esc(data.backup_branch) + '</code></p>' +
          '<p style="color:var(--text-muted);font-size:var(--font-size-sm);margin-top:4px">' +
          'After rebase completes, press Enter to reload commits.</p>' +
          '</div>';
        const cmdEl = document.getElementById('rebase-cmd-copy');
        if (cmdEl) {
          cmdEl.addEventListener('click', () => {
            if (navigator.clipboard) {
              navigator.clipboard.writeText(cmd).then(() => {
                App.showToast('Command copied', 'success');
              });
            }
          });
        }
        this._diffOpen = true;
      }
    } catch (e) {
      App.showToast('Rebase prepare failed: ' + e.message, 'error');
    }
  },

  // --- File tree (f) ---
  async _showFileList() {
    if (this._activeRow < 0 || !this._rows[this._activeRow]) {
      App.showToast('No commit selected', 'error');
      return;
    }
    const sha = this._rows[this._activeRow].dataset.sha;
    if (!sha) {
      App.showToast('No commit selected', 'error');
      return;
    }

    const body = document.getElementById('commits-diff-body');
    const title = document.getElementById('commits-diff-title');
    if (!body) return;

    this._fileListMode = true;
    this._treeMode = true;
    this._diffOpen = true;
    this._treeFocusCommit = sha;
    this._preTreeShowData = this._lastShowData;

    // Reset per-commit tree state so a new commit starts fresh
    this._treeFileExpanded = new Set();
    this._treeFileCommits = {};
    this._treeFileHasMore = {};
    this._treeExpanded = new Set();
    this._treeChangedFiles = new Set();

    title.textContent = 'File tree';
    body.innerHTML = '<div class="loading">Loading file tree</div>';

    try {
      // Load tree data (cached per repo) + changed files in parallel
      const promises = [];
      if (!this._treeData) {
        promises.push(API.getRepoTree(this._repoName, 'HEAD', this._project).then(d => { this._treeData = d; }));
      } else {
        promises.push(Promise.resolve());
      }
      promises.push(API.getCommitChangedFiles(this._repoName, sha, this._project).then(d => {
        this._treeChangedFiles = new Set(d.files || []);
      }));
      await Promise.all(promises);

      // Auto-expand directories containing changed files
      for (const filepath of this._treeChangedFiles) {
        const parts = filepath.split('/');
        for (let i = 1; i < parts.length; i++) {
          this._treeExpanded.add(parts.slice(0, i).join('/'));
        }
      }

      // Auto-expand changed files to show their commits
      const fileLoads = [];
      for (const filepath of this._treeChangedFiles) {
        if (!this._treeFileExpanded.has(filepath)) {
          fileLoads.push(
            API.getFileCommits(this._repoName, filepath, this._treeFocusCommit || 'HEAD', 30, this._project)
              .then(data => {
                this._treeFileCommits[filepath] = data.commits || [];
                this._treeFileHasMore[filepath] = data.has_more || false;
                this._treeFileExpanded.add(filepath);
              })
              .catch(() => {})
          );
        }
      }
      if (fileLoads.length) await Promise.all(fileLoads);

      this._renderTree();
    } catch (e) {
      body.innerHTML = `<div style="color:var(--red);padding:12px">Failed to load file tree: ${esc(e.message)}</div>`;
    }
  },

  _renderTree() {
    const body = document.getElementById('commits-diff-body');
    const title = document.getElementById('commits-diff-title');
    if (!body || !this._treeData) return;

    const count = this._treeData.file_count || 0;
    title.textContent = `File tree (${count} files)`;
    this._updateBackButton();

    let html = '<div class="file-tree">';
    html += this._renderTreeLevel(this._treeData.tree, '', 0);
    html += '</div>';
    body.innerHTML = html;

    // Attach click handlers
    body.querySelectorAll('.tree-node').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const path = el.dataset.path;
        const type = el.dataset.type;
        if (type === 'dir') {
          if (this._treeExpanded.has(path)) {
            this._treeExpanded.delete(path);
          } else {
            this._treeExpanded.add(path);
          }
          this._renderTree();
        } else if (type === 'file') {
          if (this._treeFileExpanded.has(path)) {
            this._treeFileExpanded.delete(path);
          } else {
            this._loadFileCommits(path);
            return;  // _loadFileCommits re-renders
          }
          this._renderTree();
        }
      });
    });

    body.querySelectorAll('.tree-commit').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const sha = el.dataset.sha;
        if (sha) this._showDirectCommit(sha);
      });
    });

    body.querySelectorAll('.tree-more').forEach(el => {
      el.addEventListener('click', (e) => {
        e.stopPropagation();
        const path = el.dataset.path;
        if (path) {
          const current = this._treeFileLimits[path] || 30;
          this._treeFileLimits[path] = current * 2;
          // Clear cache so it reloads with new limit
          delete this._treeFileCommits[path];
          delete this._treeFileHasMore[path];
          this._loadFileCommits(path);
        }
      });
    });
  },

  _renderTreeLevel(tree, parent, depth) {
    const entries = tree[parent];
    if (!entries) return '';
    let html = '';
    for (const entry of entries) {
      const fullPath = parent ? parent + '/' + entry.name : entry.name;
      const indent = depth * 20;
      if (entry.is_dir) {
        const expanded = this._treeExpanded.has(fullPath);
        const marker = expanded ? '\u25be' : '\u25b8';
        html += `<div class="tree-node" data-path="${esc(fullPath)}" data-type="dir" style="padding-left:${indent}px">`;
        html += `<span class="tree-marker">${marker}</span>`;
        html += `<span class="tree-dir"><span class="tree-dir-name">${esc(entry.name)}</span>/</span>`;
        html += '</div>';
        if (expanded) {
          html += this._renderTreeLevel(tree, fullPath, depth + 1);
        }
      } else {
        const expanded = this._treeFileExpanded.has(fullPath);
        const marker = expanded ? '\u25be' : '\u25b8';
        const modified = this._treeChangedFiles.has(fullPath);
        const cls = modified ? 'tree-file tree-file--modified' : 'tree-file';
        html += `<div class="tree-node" data-path="${esc(fullPath)}" data-type="file" style="padding-left:${indent}px">`;
        html += `<span class="tree-marker">${marker}</span>`;
        html += `<span class="${cls}">${esc(entry.name)}</span>`;
        html += '</div>';
        if (expanded && this._treeFileCommits[fullPath]) {
          const commits = this._treeFileCommits[fullPath];
          for (const c of commits) {
            html += `<div class="tree-commit" data-sha="${esc(c.hash)}" style="padding-left:${indent + 20}px">`;
            html += `<span class="tree-commit-sha">${esc(c.hash.slice(0, 10))}</span> `;
            html += `<span class="tree-commit-subject">${esc((c.subject || '').slice(0, 60))}</span>`;
            html += '</div>';
          }
          if (this._treeFileHasMore[fullPath]) {
            html += `<div class="tree-more" data-path="${esc(fullPath)}" style="padding-left:${indent + 20}px">Load more\u2026</div>`;
          }
        }
      }
    }
    return html;
  },

  async _loadFileCommits(path) {
    const limit = this._treeFileLimits[path] || 30;
    try {
      const data = await API.getFileCommits(this._repoName, path, this._treeFocusCommit || 'HEAD', limit, this._project);
      this._treeFileCommits[path] = data.commits || [];
      this._treeFileHasMore[path] = data.has_more || false;
      this._treeFileExpanded.add(path);
      this._renderTree();
      // Scroll the expanded file node into view
      const node = document.querySelector(`.tree-node[data-path="${CSS.escape(path)}"][data-type="file"]`);
      if (node) node.scrollIntoView({ block: 'nearest' });
    } catch (e) {
      App.showToast('Failed to load commits for ' + path, 'error');
    }
  },

  async _showDirectCommit(sha) {
    this._treeCommitView = true;
    this._updateBackButton();

    // Check if this commit is in the current list — if so, show its diff
    for (let i = 0; i < this._rows.length; i++) {
      if (this._rows[i].dataset.sha === sha || (this._rows[i].dataset.sha && this._rows[i].dataset.sha.startsWith(sha))) {
        this._selectRow(i);
        this._showDiffForRow(this._rows[i]);
        return;
      }
    }
    // Not in current list — load directly
    const body = document.getElementById('commits-diff-body');
    const title = document.getElementById('commits-diff-title');
    if (!body) return;

    title.textContent = sha.slice(0, 10);
    body.innerHTML = '<div class="loading">Loading commit</div>';

    try {
      const data = await API.getCommitShow(this._repoName, sha, this._project);
      this._lastShowData = data;
      this._diffOpen = true;
      this._renderDiffBody(data);
    } catch (e) {
      body.innerHTML = `<div style="color:var(--red);padding:12px">Failed to load commit: ${esc(e.message)}</div>`;
    }
  },

  _treeBack() {
    if (this._treeCommitView) {
      // Return from commit diff to tree
      this._treeCommitView = false;
      this._renderTree();
    } else if (this._treeMode || this._fileListMode) {
      // Return from tree to normal diff view
      this._treeMode = false;
      this._fileListMode = false;
      this._treeCommitView = false;
      this._updateBackButton();
      // Restore the diff data from before entering tree
      if (this._preTreeShowData) {
        this._lastShowData = this._preTreeShowData;
        this._preTreeShowData = null;
        this._renderDiffBody(this._lastShowData);
      } else {
        const body = document.getElementById('commits-diff-body');
        const title = document.getElementById('commits-diff-title');
        if (body) body.innerHTML = '<div class="commits-diff-placeholder">Select a commit to view diff</div>';
        if (title) title.textContent = '';
      }
    }
  },

  _updateBackButton() {
    const btn = document.getElementById('diff-back-btn');
    if (!btn) return;
    btn.style.display = (this._treeMode || this._treeCommitView) ? '' : 'none';
  },

  _showFileDiff(filename) {
    if (!this._lastShowData || !this._lastShowData.diff) return;
    const body = document.getElementById('commits-diff-body');
    const title = document.getElementById('commits-diff-title');
    if (!body) return;

    // Extract the diff section for this file
    const diffText = this._lastShowData.diff;
    const sections = diffText.split(/(?=^diff --git )/m);
    let fileDiff = '';
    for (const section of sections) {
      if (section.includes('a/' + filename) || section.includes('b/' + filename)) {
        fileDiff = section;
        break;
      }
    }

    title.textContent = filename;
    this._fileListMode = false;
    if (fileDiff) {
      body.innerHTML = '<pre class="diff-panel">' + formatDiff(fileDiff) + '</pre>';
    } else {
      body.innerHTML = '<div style="color:var(--text-muted);padding:12px">No diff found for ' + esc(filename) + '</div>';
    }
  },

  // --- Layer info (l) ---
  async _showLayers() {
    try {
      const data = await API.getRepoLayers(this._repoName, this._project);
      const layers = data.layers || [];
      if (!layers.length) {
        App.showToast('No layers found for this repo', 'error');
        return;
      }

      let bodyHTML = '<div style="margin:8px 0">';
      layers.forEach(layer => {
        bodyHTML += `<div style="padding:4px 0">
          <span style="color:var(--green);font-weight:bold">${esc(layer.name)}</span>
          <span style="color:var(--text-muted);font-size:var(--font-size-sm);margin-left:8px">${esc(layer.path)}</span>
        </div>`;
      });
      bodyHTML += '</div>';

      await modal('Layers (' + layers.length + ')', bodyHTML, [
        { label: 'Close', value: null },
      ]);
    } catch (e) {
      App.showToast('Failed to load layers: ' + e.message, 'error');
    }
  },

  // --- Lore search (p) ---
  async _loreSearch() {
    if (this._activeRow < 0 || !this._rows[this._activeRow]) return;
    const sha = this._rows[this._activeRow].dataset.sha;
    if (!sha) {
      App.showToast('No commit selected', 'error');
      return;
    }

    const body = document.getElementById('commits-diff-body');
    const title = document.getElementById('commits-diff-title');
    if (!body) return;

    title.textContent = 'Lore search: ' + sha.slice(0, 7);
    body.innerHTML = '<div class="loading">Searching lore.kernel.org</div>';
    this._diffOpen = true;

    try {
      const data = await API.getCommitLore(this._repoName, sha, this._project);

      if (data.direct_msgid) {
        const loreUrl = 'https://lore.kernel.org/all/' + encodeURIComponent(data.direct_msgid) + '/';
        body.innerHTML = '<div style="padding:12px">' +
          '<p style="color:var(--green);margin-bottom:8px">Direct link found in commit message:</p>' +
          '<a href="' + esc(loreUrl) + '" target="_blank" rel="noopener" style="color:var(--accent)">' + esc(loreUrl) + '</a>' +
          '</div>';
        return;
      }

      const results = data.results || [];
      if (!results.length) {
        body.innerHTML = '<div style="color:var(--text-muted);padding:12px">No results found on lore.kernel.org</div>';
        return;
      }

      let html = '<div class="lore-results">';
      results.forEach(r => {
        html += `<div class="lore-result-item" style="padding:6px 12px;border-bottom:1px solid var(--border)">
          <div><a href="${esc(r.url)}" target="_blank" rel="noopener" style="color:var(--accent)">${esc(r.subject)}</a></div>
          <div style="font-size:var(--font-size-sm);color:var(--text-muted)">
            ${esc(r.author)} &middot; ${esc(r.date)}
          </div>
        </div>`;
      });
      html += '</div>';
      body.innerHTML = html;
    } catch (e) {
      body.innerHTML = `<div style="color:var(--red);padding:12px">Lore search failed: ${esc(e.message)}</div>`;
    }
  },

  // --- History viewer (t) ---
  async _historyViewer() {
    if (!this._repo) return;

    const repoPath = this._repo.path;
    if (!repoPath) {
      App.showToast('Cannot determine repo path', 'error');
      return;
    }

    // Use configured git_viewer setting; fall back to tig for 'auto'
    let tool = null;
    try {
      const config = await API.getConfig();
      tool = (config.settings || {}).git_viewer || 'auto';
    } catch (e) { /* use default */ }
    if (!tool || tool === 'auto') tool = 'tig';

    if (window.TerminalManager) {
      const rm = this._project.match(/^(.+@[^:]+):(.*)$/);
      if (rm) {
        TerminalManager.show({
          ssh: rm[1],
          path: repoPath,
          cmd: tool,
          title: tool + ': ' + this._repoName,
        });
      } else {
        TerminalManager.show({
          cwd: repoPath,
          cmd: tool,
          title: tool + ': ' + this._repoName,
        });
      }
    }
  },

  async _showCommitContextMenu(e, row, i) {
    this._selectRow(i);
    const items = [
      { label: 'Copy SHA', icon: '\u29c9', key: 'c', action: 'copy' },
      { label: 'Select/Deselect', icon: '\u2610', key: 'Tab', action: 'toggle' },
      { sep: true },
      { label: 'Export patches', icon: '\u2197', key: 'e', action: 'export' },
      { label: 'File tree', icon: '\u2630', key: 'f', action: 'files' },
      { label: 'Lore search', icon: '\u2315', key: 'p', action: 'lore' },
      { label: 'History viewer', icon: '\u23f1', key: 't', action: 'history' },
    ];
    if (row.dataset.type === 'local') {
      items.push({ sep: true });
      const rebaseLabel = this._selected.size > 0
        ? 'Rebase ' + this._selected.size + ' selected'
        : 'Rebase all local';
      items.push({ label: rebaseLabel, icon: '\u21c5', key: 'i', action: 'rebase' });
      items.push({ label: 'Drop commits', icon: '\u2717', key: 'D', action: 'drop', danger: true });
    }
    const action = await contextMenu(e.clientX, e.clientY, items);
    if (!action) return;
    if (action === 'copy') this._copyActiveSha();
    else if (action === 'toggle') this._toggleSelect();
    else if (action === 'export') this._exportPatches();
    else if (action === 'files') this._showFileList();
    else if (action === 'lore') this._loreSearch();
    else if (action === 'history') this._historyViewer();
    else if (action === 'rebase') this._interactiveRebase();
    else if (action === 'drop') this._dropCommits();
  },

  handleKeyboard(e) {
    // Graph mode: only g and b work
    if (this._graphMode) {
      if (e.key === 'g') {
        e.preventDefault();
        this._toggleGraph();
        return;
      }
      if (e.key === 'b') {
        e.preventDefault();
        location.hash = 'explore';
        return;
      }
      if (e.key === 'Escape') {
        e.preventDefault();
        this._toggleGraph();
        return;
      }
      return;
    }

    if (e.key === 'Escape') {
      if (this._rangeAnchor !== null) {
        e.preventDefault();
        this._rangeAnchor = null;
        return;
      }
      if (this._treeCommitView) {
        e.preventDefault();
        // Return to file tree from commit diff
        this._treeCommitView = false;
        this._renderTree();
        return;
      }
      if (this._treeMode || this._fileListMode) {
        e.preventDefault();
        // Return to normal diff view
        this._treeMode = false;
        this._fileListMode = false;
        this._treeCommitView = false;
        this._updateBackButton();
        if (this._preTreeShowData) {
          this._lastShowData = this._preTreeShowData;
          this._preTreeShowData = null;
        }
        if (this._lastShowData) this._renderDiffBody(this._lastShowData);
        return;
      }
      if (this._diffOpen) {
        e.preventDefault();
        this._closeDiff();
        return;
      }
    }

    if (e.key === 'b') {
      e.preventDefault();
      location.hash = 'explore';
      return;
    }

    if (e.key === 'd') {
      e.preventDefault();
      this._toggleDiffMode();
      return;
    }

    if (e.key === 'c') {
      e.preventDefault();
      this._copyActiveSha();
      return;
    }

    if (e.key === 'g') {
      e.preventDefault();
      this._toggleGraph();
      return;
    }

    if (e.key === 'Tab') {
      e.preventDefault();
      this._toggleSelect();
      return;
    }

    if (e.key === ' ') {
      e.preventDefault();
      this._rangeSelect();
      return;
    }

    if (e.key === 'u') {
      e.preventDefault();
      this._clearSelection();
      return;
    }

    if (e.key === 'e') {
      e.preventDefault();
      this._exportPatches();
      return;
    }

    if (e.key === 'f') {
      e.preventDefault();
      this._showFileList();
      return;
    }

    if (e.key === 'p') {
      e.preventDefault();
      this._loreSearch();
      return;
    }

    if (e.key === 't') {
      e.preventDefault();
      this._historyViewer();
      return;
    }

    if (e.key === 'D') {
      e.preventDefault();
      this._dropCommits();
      return;
    }

    if (e.key === 'i') {
      e.preventDefault();
      this._interactiveRebase();
      return;
    }

    if (e.key === 'l') {
      e.preventDefault();
      this._showLayers();
      return;
    }

    if (!this._rows.length) return;

    if (e.key === 'ArrowDown' || e.key === 'j') {
      e.preventDefault();
      this._moveActive(1);
      if (this._activeRow >= 0 && this._rows[this._activeRow]) {
        this._showDiffForRow(this._rows[this._activeRow]);
      }
    } else if (e.key === 'ArrowUp' || e.key === 'k') {
      e.preventDefault();
      this._moveActive(-1);
      if (this._activeRow >= 0 && this._rows[this._activeRow]) {
        this._showDiffForRow(this._rows[this._activeRow]);
      }
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (this._activeRow >= 0 && this._rows[this._activeRow]) {
        this._showDiffForRow(this._rows[this._activeRow]);
      }
    } else if (e.key === 'Home') {
      e.preventDefault();
      this._selectRow(0);
      if (this._rows[0]) this._showDiffForRow(this._rows[0]);
    } else if (e.key === 'End') {
      e.preventDefault();
      const last = this._rows.length - 1;
      if (this._activeRow === last) {
        // Already at end — trigger load more if available
        this._triggerLoadMore();
      } else {
        this._selectRow(last);
        if (this._rows[last]) this._showDiffForRow(this._rows[last]);
      }
    }
  },

  /** Trigger load-more if a load-more element is visible at the bottom */
  _triggerLoadMore() {
    // Prefer context (bottom-most), then upstream
    const ctx = document.getElementById('load-more-context');
    if (ctx) { ctx.click(); return; }
    const up = document.getElementById('load-more-upstream');
    if (up) { up.click(); return; }
  },

  _moveActive(delta) {
    if (this._activeRow >= 0 && this._rows[this._activeRow]) {
      this._rows[this._activeRow].classList.remove('active');
      this._rows[this._activeRow].setAttribute('tabindex', '-1');
      this._rows[this._activeRow].removeAttribute('aria-selected');
    }
    let next = this._activeRow + delta;
    if (next < 0) next = this._rows.length - 1;
    if (next >= this._rows.length) next = 0;
    this._activeRow = next;
    const row = this._rows[this._activeRow];
    if (row) {
      row.classList.add('active');
      row.setAttribute('tabindex', '0');
      row.setAttribute('aria-selected', 'true');
      row.focus();
      row.scrollIntoView({ block: 'nearest' });
    }
  },
};
