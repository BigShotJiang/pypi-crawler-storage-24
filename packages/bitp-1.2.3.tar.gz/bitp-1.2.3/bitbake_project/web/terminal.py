#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""PTY session manager and WebSocket-to-PTY bridge for xterm.js terminals."""

import errno
import fcntl
import json
import os
import select
import signal
import struct
import subprocess
import termios
import threading

from .websocket import (
    OP_BINARY,
    OP_CLOSE,
    OP_PING,
    OP_TEXT,
    read_frame,
    send_binary,
    send_close,
    write_frame,
)

# Active sessions for cleanup on server shutdown
_sessions = []
_sessions_lock = threading.Lock()


class _SockWriter:
    """Adapt a raw socket for write_frame() — uses sendall for reliability."""

    __slots__ = ("_sendall",)

    def __init__(self, sock):
        self._sendall = sock.sendall

    def write(self, data):
        self._sendall(data)

    def flush(self):
        pass


class _SockReader:
    """Read exactly N bytes from a raw socket (for read_frame).

    Bypasses BufferedReader which can malfunction after an HTTP-to-WebSocket
    protocol upgrade — the BufferedReader's internal state doesn't know the
    connection has been upgraded and may return EOF prematurely.
    """

    __slots__ = ("_sock",)

    def __init__(self, sock):
        self._sock = sock

    def read(self, n):
        data = b""
        while len(data) < n:
            try:
                chunk = self._sock.recv(n - len(data))
            except OSError:
                return data
            if not chunk:
                return data
            data += chunk
        return data


class PTYSession:
    """Manage a single PTY + child process."""

    def __init__(self):
        self.master_fd = None
        self.child_pid = None

    def spawn(self, rows: int = 24, cols: int = 80,
              cwd: str = "", cmd: list = None) -> None:
        """Spawn a child process with a PTY.

        Uses subprocess.Popen with _posixsubprocess.fork_exec() which is
        implemented in C — much safer than os.fork() in a multi-threaded
        server (ThreadingHTTPServer) because it minimises work between
        fork and exec, avoiding malloc-lock deadlocks.

        Args:
            rows, cols: Initial terminal size.
            cwd: Working directory for the shell (empty = inherit).
            cmd: Command to exec (default: ["/bin/bash", "--login"]).
        """
        if cmd is None:
            cmd = ["/bin/bash", "--login"]

        env = os.environ.copy()
        env["TERM"] = "xterm-256color"
        env["COLORTERM"] = "truecolor"
        child_cwd = cwd if cwd and os.path.isdir(cwd) else None

        master_fd, slave_fd = os.openpty()

        # Set initial window size on slave before child starts
        winsize = struct.pack("HHHH", rows, cols, 0, 0)
        fcntl.ioctl(slave_fd, termios.TIOCSWINSZ, winsize)

        try:
            proc = subprocess.Popen(
                cmd,
                stdin=slave_fd, stdout=slave_fd, stderr=slave_fd,
                close_fds=True,
                start_new_session=True,
                cwd=child_cwd,
                env=env,
                preexec_fn=lambda: fcntl.ioctl(0, termios.TIOCSCTTY, 0),
            )
        except Exception:
            os.close(master_fd)
            os.close(slave_fd)
            raise

        os.close(slave_fd)
        self.master_fd = master_fd
        self.child_pid = proc.pid
        self._proc = proc  # prevent GC of Popen object

        with _sessions_lock:
            _sessions.append(self)

    def resize(self, rows: int, cols: int) -> None:
        """Resize the PTY window."""
        if self.master_fd is not None:
            winsize = struct.pack("HHHH", rows, cols, 0, 0)
            fcntl.ioctl(self.master_fd, termios.TIOCSWINSZ, winsize)

    def write(self, data: bytes) -> None:
        """Write data to the PTY master."""
        if self.master_fd is not None:
            os.write(self.master_fd, data)

    def read(self, size: int = 4096) -> bytes:
        """Read data from the PTY master."""
        if self.master_fd is not None:
            return os.read(self.master_fd, size)
        return b""

    def close(self) -> None:
        """Close the PTY and terminate the child process."""
        with _sessions_lock:
            if self in _sessions:
                _sessions.remove(self)

        if self.master_fd is not None:
            try:
                os.close(self.master_fd)
            except OSError:
                pass
            self.master_fd = None

        proc = getattr(self, '_proc', None)
        if proc is not None:
            self._proc = None
            self.child_pid = None
            try:
                proc.terminate()  # SIGTERM
                proc.wait(timeout=0.5)
            except subprocess.TimeoutExpired:
                proc.kill()  # SIGKILL
                try:
                    proc.wait(timeout=1)
                except subprocess.TimeoutExpired:
                    pass
            except OSError:
                pass
        elif self.child_pid is not None:
            pid = self.child_pid
            self.child_pid = None
            try:
                os.kill(pid, signal.SIGHUP)
            except OSError:
                return
            import time
            for _ in range(10):
                try:
                    rpid, _ = os.waitpid(pid, os.WNOHANG)
                    if rpid != 0:
                        return
                except ChildProcessError:
                    return
                time.sleep(0.05)
            try:
                os.kill(pid, signal.SIGKILL)
                os.waitpid(pid, 0)
            except (OSError, ChildProcessError):
                pass


def _parse_terminal_params(handler):
    """Parse cwd/ssh/session params from the WebSocket URL query string.

    Returns (cwd, cmd) where cmd is the shell command to exec.
    Supports:
        /ws/terminal?cwd=/path                      — local shell in directory
        /ws/terminal?cwd=/path&session=bit-poky     — local tmux session
        /ws/terminal?ssh=user@host&path=/remote/path — SSH to remote project
        /ws/terminal?ssh=user@host&session=bit-host  — SSH to host (group header)
    """
    import shlex
    from urllib.parse import urlparse, parse_qs
    from ..tmux import tmux_attach_cmd, tmux_session_name
    from ..commands.setup import make_oe_rcfile
    from ..commands.ssh_remote import oe_remote_shell_snippet, tmux_wrap_remote, ssh_resolve_address

    parsed = urlparse(handler.path)
    params = parse_qs(parsed.query)

    cwd = params.get("cwd", [""])[0]
    ssh = params.get("ssh", [""])[0]
    remote_path = params.get("path", [""])[0]
    session = params.get("session", [""])[0]
    run_cmd = params.get("cmd", [""])[0]

    # Direct tool execution (tig, lazygit, etc.) — no tmux wrap
    if run_cmd and not ssh:
        return cwd, ["/bin/bash", "-lc", run_cmd]

    if ssh:
        # Resolve alternate address for this host
        if '@' in ssh:
            user, host = ssh.split('@', 1)
        else:
            user, host = '', ssh
        addr, port = ssh_resolve_address(user, host)
        resolved_ssh = f"{user}@{addr}" if user else addr
        port_args = ["-p", str(port)] if port != 22 else []

        # Direct command on remote (rebase, tig, etc.) — cd to path and exec
        if run_cmd:
            remote_cmd = run_cmd
            if remote_path:
                remote_cmd = f"cd {shlex.quote(remote_path)} && {run_cmd}"
            return "", ["ssh", "-t", *port_args, resolved_ssh, remote_cmd]

        # Build the shell snippet (OE env for project paths, login shell for host headers)
        snippet = oe_remote_shell_snippet(remote_path)

        # Compute session name if not provided
        if not session and remote_path:
            session = tmux_session_name(remote_path)

        if session:
            wrapped = tmux_wrap_remote(session, "shell", snippet)
            return "", ["ssh", "-t", *port_args, resolved_ssh, wrapped]

        # SSH without tmux (no session name)
        return "", ["ssh", "-t", *port_args, resolved_ssh, snippet]

    # Local terminal — source oe-init-build-env if available (matches TUI)
    oe_rcfile = make_oe_rcfile(cwd) if cwd else None

    if not session and cwd:
        session = tmux_session_name(cwd)
    if session:
        if oe_rcfile:
            return cwd, tmux_attach_cmd(session, cwd=cwd,
                                        shell_cmd=oe_rcfile)
        return cwd, tmux_attach_cmd(session, cwd=cwd)

    if oe_rcfile:
        return cwd, ["/bin/bash", "--rcfile", oe_rcfile]
    return cwd, None


def handle_terminal_websocket(handler) -> None:
    """Bridge a WebSocket connection to a PTY session.

    Uses raw socket I/O (bypassing BaseHTTPRequestHandler's BufferedReader/
    Writer) because the protocol upgrade from HTTP to WebSocket leaves the
    handler's rfile in an unreliable state.

    Runs two loops:
    - pty_to_ws thread: reads PTY output → sends binary WS frames
    - Main thread (ws_to_pty): reads WS frames → writes to PTY or resizes
    """
    from . import web_log

    cwd, cmd = _parse_terminal_params(handler)
    web_log(f"[terminal] WebSocket connected: cwd={cwd!r} cmd={cmd!r}")

    session = PTYSession()
    session.spawn(cwd=cwd, cmd=cmd)
    web_log(f"[terminal] PTY spawned: pid={session.child_pid} fd={session.master_fd}")

    stop_event = threading.Event()
    sock = handler.request
    rfile = _SockReader(sock)  # raw socket reader (bypasses BufferedReader)
    wfile = _SockWriter(sock)  # raw socket writer (uses sendall)
    wfile_lock = threading.Lock()

    close_reason = "Session ended"

    def pty_to_ws():
        """Forward PTY output to WebSocket."""
        nonlocal close_reason
        try:
            while not stop_event.is_set():
                ready, _, _ = select.select([session.master_fd], [], [], 0.1)
                if ready:
                    try:
                        data = session.read(4096)
                        if not data:
                            if session.child_pid:
                                try:
                                    rpid, status = os.waitpid(
                                        session.child_pid, os.WNOHANG)
                                    if rpid:
                                        if os.WIFEXITED(status):
                                            web_log(f"[terminal] child exited "
                                                    f"status={os.WEXITSTATUS(status)}")
                                        elif os.WIFSIGNALED(status):
                                            web_log(f"[terminal] child killed "
                                                    f"signal={os.WTERMSIG(status)}")
                                    else:
                                        web_log("[terminal] PTY EOF but child "
                                                "still running")
                                except ChildProcessError:
                                    web_log("[terminal] PTY EOF (child already "
                                            "reaped)")
                            else:
                                web_log("[terminal] PTY EOF")
                            break
                        with wfile_lock:
                            send_binary(wfile, data)
                    except OSError as e:
                        if e.errno == errno.EIO:
                            # EIO is normal when tmux detaches or session ends
                            close_reason = "Session ended"
                            web_log(f"[terminal] session ended (pid={session.child_pid})")
                        else:
                            web_log(f"[terminal] PTY read/send error: {e}")
                        break
        except Exception as e:
            web_log(f"[terminal] pty_to_ws exception: {e}")
        finally:
            stop_event.set()

    reader_thread = threading.Thread(target=pty_to_ws, daemon=True)
    reader_thread.start()

    # ws_to_pty: main thread reads WebSocket frames
    try:
        while not stop_event.is_set():
            opcode, payload = read_frame(rfile)

            if opcode is None or opcode == OP_CLOSE:
                web_log(f"[terminal] ws closed (opcode={opcode})")
                break

            if opcode == OP_PING:
                with wfile_lock:
                    write_frame(wfile, 0xA, payload)
                continue

            if opcode == OP_TEXT:
                try:
                    msg = json.loads(payload.decode("utf-8"))
                except (json.JSONDecodeError, UnicodeDecodeError):
                    continue

                msg_type = msg.get("type")
                if msg_type == "input":
                    data = msg.get("data", "")
                    if data:
                        session.write(data.encode("utf-8"))
                elif msg_type == "resize":
                    cols = msg.get("cols", 80)
                    rows = msg.get("rows", 24)
                    session.resize(rows, cols)

            elif opcode == OP_BINARY:
                session.write(payload)

    except (BrokenPipeError, ConnectionResetError, OSError) as e:
        if isinstance(e, OSError) and e.errno == errno.EIO:
            close_reason = "Session ended"
            web_log(f"[terminal] session ended (pid={session.child_pid})")
        else:
            web_log(f"[terminal] main loop error: {e}")
    finally:
        stop_event.set()
        try:
            with wfile_lock:
                send_close(wfile, reason=close_reason)
        except Exception:
            pass
        session.close()
        reader_thread.join(timeout=2)


def shutdown_all_sessions() -> None:
    """Close all active PTY sessions (called on server shutdown)."""
    with _sessions_lock:
        sessions = list(_sessions)
    for session in sessions:
        session.close()
