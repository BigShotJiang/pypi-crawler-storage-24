#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : redis队列
# @Time         : 2023/6/9 15:39
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  :
import time

import logfire

from meutils.pipe import *
from meutils.db.redis_db import redis_client
from meutils.notice.feishu import send_message


# queue = Queue(connection=redis_client)

from redis import Redis
from rq import Queue

queue = Queue(connection=Redis())
# queue = Queue(name='test', connection=redis_client)

# send_message('xxx')
task = queue.enqueue(
    send_message,
    content="rq",
)  # 通用函数


# task = queue.enqueue(
#     print,
#     "xxx",
# )  # 通用函数


