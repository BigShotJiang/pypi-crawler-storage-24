#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : demo
# @Time         : 2026/2/23 20:50
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : 

from meutils.pipe import *
from metaso_sdk import search, Query
from metaso_sdk import create_topic, upload_directory, Topic, search



# 普通搜索
# result = search(Query(question="Python教程"))

# 带会话ID的追问 多轮对话
# result = search(Query(question="详细说明", sessionId="8550018047390023680"))

# # 流式输出
# for chunk in search(Query(question="ABC"), stream=True):
#     print(chunk)
#     # 输出: {'type': 'heartbeat'} 或 {'type': 'append-text', 'text': '...'}


from metaso_sdk import create_topic, upload_directory, Topic, upload_file
#
topic = create_topic(Topic(name="functional programing"))
files = upload_file(topic, open("/Users/betterme/PycharmProjects/AI/MeUtils/examples/meta/demo.py", 'rb'))