import requests
import json

url = "https://www.kimi.com/apiv2/kimi.gateway.chat.v1.ChatService/Chat"

payload = "\u0000\u0000\u0000\u0001<{\"chat_id\":\"19c8434a-1bf2-8bf9-8000-09db0c65db6d\",\"scenario\":\"SCENARIO_K2D5\",\"tools\":[{\"type\":\"TOOL_TYPE_SEARCH\",\"search\":{}}],\"message\":{\"parent_id\":\"19c8434a-1bf2-8bfa-8000-0adb8b518914\",\"role\":\"user\",\"blocks\":[{\"message_id\":\"\",\"text\":{\"content\":\"你好\"}}],\"scenario\":\"SCENARIO_K2D5\"},\"options\":{\"thinking\":true}}"
headers = {
    'authorization': 'Bearer eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ1c2VyLWNlbnRlciIsImV4cCI6MTc3MTkyMDM2OSwiaWF0IjoxNzY5MzI4MzY5LCJqdGkiOiJkNXFzdHNhbjc1NGVsa3FmOTZoMCIsInR5cCI6ImFjY2VzcyIsImFwcF9pZCI6ImtpbWkiLCJzdWIiOiJja2kwOTRiM2Flc2xnbGo2Zm8zMCIsInNwYWNlX2lkIjoiY2tpMDk0YjNhZXNsZ2xqNmZvMmciLCJhYnN0cmFjdF91c2VyX2lkIjoiY2tpMDk0YjNhZXNsZ2xqNmZvMzAiLCJyb2xlcyI6WyJ2aWRlb19nZW5fYWNjZXNzIiwiZGVlcF9yZXNlYXJjaCJdLCJzc2lkIjoiMTcyOTk1ODQwMTAwNTc0MTc4MSIsImRldmljZV9pZCI6IjczMTEyOTA5MzA5NzUzNDQxNDMiLCJyZWdpb24iOiJjbiIsIm1lbWJlcnNoaXAiOnsibGV2ZWwiOjE1fX0.TSLEkb_CPdaCulFzM--6s19tWJmSoHqo5iLLGXKtKMe2BE-VBiMqMRu9NoqQFQklUf5FBpfp7rvbgkSJAIDGYA',
    'connect-protocol-version': '1',
    'priority': 'u=1, i',
    'r-timezone': 'Asia/Shanghai',
    'x-language': 'zh-CN',
    'x-msh-device-id': '7311290930975344143',
    'x-msh-platform': 'web',
    'x-msh-session-id': '1729958401005741781',
    'x-msh-version': '1.0.0',
    'x-traffic-id': 'cki094b3aeslglj6fo30',
    'Cookie': '_ga=GA1.1.1276391256.1747995747; HMACCOUNT=2774346DF6F02985; theme=dark; _qimei_uuid42=19a11093a06100ae569d6abe078d3ec7acbe85a6fd; _qimei_i_3=5efe6483c40c54889292f9630ed571e4a1b8f7a5470d0685b28f795b73952838653733973989e2999c83; _qimei_h38=47aeffd7569d6abe078d3ec703000006b19a11; __snaker__id=zo6owMlL2j6x2Egy; kimi-auth=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJ1c2VyLWNlbnRlciIsImV4cCI6MTc3MTkyMDM2OSwiaWF0IjoxNzY5MzI4MzY5LCJqdGkiOiJkNXFzdHNhbjc1NGVsa3FmOTZoMCIsInR5cCI6ImFjY2VzcyIsImFwcF9pZCI6ImtpbWkiLCJzdWIiOiJja2kwOTRiM2Flc2xnbGo2Zm8zMCIsInNwYWNlX2lkIjoiY2tpMDk0YjNhZXNsZ2xqNmZvMmciLCJhYnN0cmFjdF91c2VyX2lkIjoiY2tpMDk0YjNhZXNsZ2xqNmZvMzAiLCJyb2xlcyI6WyJ2aWRlb19nZW5fYWNjZXNzIiwiZGVlcF9yZXNlYXJjaCJdLCJzc2lkIjoiMTcyOTk1ODQwMTAwNTc0MTc4MSIsImRldmljZV9pZCI6IjczMTEyOTA5MzA5NzUzNDQxNDMiLCJyZWdpb24iOiJjbiIsIm1lbWJlcnNoaXAiOnsibGV2ZWwiOjE1fX0.TSLEkb_CPdaCulFzM--6s19tWJmSoHqo5iLLGXKtKMe2BE-VBiMqMRu9NoqQFQklUf5FBpfp7rvbgkSJAIDGYA; Hm_lvt_358cae4815e85d48f7e8ab7f3680a74b=1769410162; _qimei_fingerprint=dd38b822c43601e30b795b0bb06bc28b; _gcl_au=1.1.599150341.1771506547; Hm_lpvt_358cae4815e85d48f7e8ab7f3680a74b=1771509755; _qimei_i_1=77bc4886920b058d97c3f9355d8d27e6a6bcf1f115535781e1dc2f582593206c616331c73980b3ddd78bc5d0; _ga_YXD8W70SZP=GS2.1.s1771742966$o536$g1$t1771744568$j57$l0$h0',
    'content-type': 'application/connect+json'
}

_payload = {
    "chat_id": "19c8434a-1bf2-8bf9-8000-09db0c65db6d",
    "scenario": "SCENARIO_K2D5",
    "tools": [
        {
            "type": "TOOL_TYPE_SEARCH",
            "search": {}
        }
    ],
    "message": {
        "parent_id": "19c8434a-1bf2-8bfa-8000-0adb8b518914",
        "role": "user",
        "blocks": [
            {
                "message_id": "",
                "text": {
                    "content": "你好"
                }
            }
        ],
        "scenario": "SCENARIO_K2D5"
    },
    "options": {
        "thinking": True
    }
}

import struct
def build_payload_v3(data_dict: dict, is_end: bool = False) -> bytes:
    json_str = json.dumps(data_dict, ensure_ascii=False)
    # 注意：< 可能是消息内容的一部分，表示消息类型
    full_content = '<' + json_str

    body = full_content.encode('utf-8')
    flags = 0x01 if is_end else 0x00

    # 5字节头: flags(1) + length(4)
    return struct.pack('>BI', flags, len(body)) + body
# 使用示例
_payload = build_payload_v3(_payload)

# response = requests.request("POST", url, headers=headers, data=payload)
#
# print(response.text)
