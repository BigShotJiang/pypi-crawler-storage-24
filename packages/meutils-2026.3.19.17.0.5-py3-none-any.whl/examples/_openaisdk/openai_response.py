#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : openai_response
# @Time         : 2026/2/12 16:11
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  : 

from meutils.pipe import *
from openai import OpenAI

"""
curl --location --request POST 'https://ark.cn-beijing.volces.com/api/v3/responses' \
--header "Authorization: Bearer 65ab0374-e8bb-4647-9954-" \
--header "Content-Type: application/json" \
--data-raw '{
  "model": "doubao-seed-translation-250915",
  "input": [
    {
      "role": "user",
      "content": [
        {
          "type": "input_text",
          "text": "若夫淫雨霏霏，连月不开，阴风怒号，浊浪排空",
          "translation_options": {
            "source_language": "zh", 
            "target_language": "en"
          }
        }
      ]
    }
  ]
}'
"""

client = OpenAI(base_url="https://ark.cn-beijing.volces.com/api/v3", api_key="65ab0374-e8bb-4647--ca1c362d4c75")

r = client.responses.create(
    stream=True,
    model="doubao-seed-translation-250915",
    input=[
        {
            "role": "user",
            "content": [
                {
                    "type": "input_text",
                    "text": "若夫淫雨霏霏，连月不开，阴风怒号，浊浪排空",
                    "translation_options": {
                        "source_language": "zh",
                        "target_language": "en"
                    }
                }
            ]
        }
    ]
)
