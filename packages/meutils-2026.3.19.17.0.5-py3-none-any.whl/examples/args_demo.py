import asyncio
from typing import TypeVar, Callable, Awaitable, Optional

T = TypeVar("T")


async def poll(
    fn: Callable[[], Awaitable[T]],
    *,
    until: Callable[[T], bool] = bool,
    max_attempts: int = 10,
    interval: float = 1.0,
    backoff: float = 1.0,
    timeout: Optional[float] = None,
) -> T:
    """
    轮询直到条件满足。

    Args:
        fn: 每次轮询调用的异步函数
        until: 判断结果是否满足条件，默认 truthy 即通过
        max_attempts: 最大尝试次数
        interval: 初始间隔（秒）
        backoff: 每次间隔的乘数（>1 则递增退避）
        timeout: 总超时时间（秒），None 表示不限
    """
    delay = interval

    async def _poll():
        nonlocal delay
        for attempt in range(1, max_attempts + 1):
            result = await fn()
            if until(result):
                return result
            if attempt < max_attempts:
                await asyncio.sleep(delay)
                delay *= backoff
        raise TimeoutError(f"polling failed after {max_attempts} attempts")

    if timeout is not None:
        return await asyncio.wait_for(_poll(), timeout=timeout)
    return await _poll()


if __name__ == '__main__':
    # 基本用法 — 轮询某个 API 直到状态变为 "done"
    result = await poll(
        lambda: 1,
        until=lambda r: r["status"] == "done",
        max_attempts=20,
        interval=2.0,
        backoff=1.5,  # 2s -> 3s -> 4.5s -> ...
        timeout=60.0,
    )

    # 简单场景 — 等待某个值变为 truthy
    value = await poll(fetch_something, interval=0.5)
