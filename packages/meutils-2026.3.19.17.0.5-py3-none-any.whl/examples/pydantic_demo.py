#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : MeUtils.
# @File         : pydantic_demo
# @Time         : 2021/1/27 8:41 下午
# @Author       : yuanjie
# @Email        : meutils@qq.com
# @Software     : PyCharm
# @Description  : https://blog.csdn.net/swinfans/article/details/89629641
# https://blog.csdn.net/codename_cys/article/details/107675748
import logfire
import yaml
from meutils.pipe import *
from meutils.schemas.openai_types import chat_completion

from pydantic import BaseModel

d = {
  "id": "V2MuMhAJMmAapyMRrVuBGB",
  "bytes": 67591,
  "created_at": 1771681277,
  "filename": "5.2大模型API服务接入协议模版20260211.docx",
  "object": "file",
  "purpose": "file-extract",
  "status": "processed",}

# try:
#     1 / 0
#
# except Exception as e:
#     content_detail = f"{traceback.format_exc()}"
#
#     # logfire.error(str(e), _tags=('error', ), _exc_info=e)
#     # logfire.error(json.dumps(d, indent=4), _tags=('error', ), _exc_info=e)
#
#     logfire.error("{a=!r}", a=chat_completion) # 保留转移 保留=
#     logfire.error("{a=!s}", a=chat_completion)
#     logfire.error("{a=}", a=chat_completion)
#     logfire.error("{a}", a=chat_completion)
#
#     logfire.trace("{a}", a=chat_completion)

# logfire.instrument_openai



@logfire.instrument('This is a span {a=}')
def main(a=1):
    return 1/0


from taskiq import ZeroMQBroker
from taskiq.instrumentation import TaskiqInstrumentor
import logfire

# 配置 Logfire
logfire.configure()

# 启用 Taskiq 的 OpenTelemetry 检测
TaskiqInstrumentor().instrument()

broker = ZeroMQBroker()

from taskiq import ZeroMQBroker
from taskiq.middlewares.opentelemetry_middleware import OpenTelemetryMiddleware
import logfire

logfire.configure()

broker = ZeroMQBroker().with_middlewares(
   OpenTelemetryMiddleware(),
)

if __name__ == '__main__':
    # main(121)
    pass