#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : tc
# @Time         : 2026/2/9 11:51
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  :
import json
import os

from anthropic import Anthropic


# 1. 模拟工具函数
def get_weather(city: str) -> dict:
    return {"weather": "Sunny", "temperature": "25°C", "city": city}


# 映射工具名称到具体实现
tool_map = {
    "get_weather": get_weather
}

# 2. 工具定义 (Anthropic 格式)
# 注意：这里字段名为 'input_schema' 而不是 OpenAI 的 'parameters'
tools = [{
    "name": "get_weather",
    "description": "Retrieve current weather information. Call this when the user asks about the weather.",
    "input_schema": {
        "type": "object",
        "required": ["city"],
        "properties": {
            "city": {
                "type": "string",
                "description": "Name of the city"
            }
        }
    }
}]


def tool_call_with_anthropic(client: Anthropic, model_name: str):
    # System prompt 单独定义
    system_prompt = "You are Kimi, an AI assistant created by Moonshot AI."

    # 初始消息 (不包含 system role)
    messages = [
        {"role": "user", "content": "What's the weather like in Beijing today? Use the tool to check."}
    ]

    print(f"User: {messages[0]['content']}")

    while True:
        # 发送请求
        response = client.messages.create(
            model=model_name,
            max_tokens=1024,
            system=system_prompt,  # system prompt 在这里传入
            messages=messages,
            tools=tools
        )

        # 检查停止原因是否为使用工具
        if response.stop_reason == "tool_use":
            # 必须先将 Assistant 的意图（包含 tool_use 请求）加入历史记录
            messages.append({"role": "assistant", "content": response.content})

            tool_results = []

            # 遍历返回的内容块，寻找 tool_use
            for block in response.content:
                if block.type == "tool_use":
                    tool_name = block.name
                    tool_input = block.input  # Anthropic SDK 已经自动解析为 dict，无需 json.loads
                    tool_use_id = block.id

                    print(f"\n[Tool Call] Name: {tool_name}, Args: {tool_input}")

                    # 执行函数
                    if tool_name in tool_map:
                        function_result = tool_map[tool_name](**tool_input)
                        print(f"[Tool Result] {function_result}")

                        # 构造 Anthropic 特有的 tool_result 格式
                        tool_results.append({
                            "type": "tool_result",
                            "tool_use_id": tool_use_id,
                            "content": json.dumps(function_result)
                        })

            # 将工具结果作为 'user' 消息发送回去
            # Anthropic 规定：Tool results 属于 User 侧的信息
            if tool_results:
                messages.append({
                    "role": "user",
                    "content": tool_results
                })
        else:
            # 如果不是 tool_use，说明是最终回答
            print("-" * 100)
            # response.content 是一个 TextBlock 列表，通常取第一个
            final_text = response.content[0].text
            print("Final Answer:", final_text)
            break


# 使用示例
if __name__ == "__main__":
    # 请确保设置了 ANTHROPIC_API_KEY 环境变量
    client = Anthropic(
        base_url=os.getenv("ANTHROPIC_BASE_URLN"),
        api_key=os.getenv("ANTHROPIC_CC_API_KEY"),
        auth_token=os.getenv("ANTHROPIC_CC_API_KEY"),
    )

    model = "ark-code-latest"
    model = "gpt-5.3-codex"

    # model = "claude-sonnet-4-5-20250929"
    # model = "claude-opus-4-6"
    # 使用 Claude 3.5 Sonnet 或其他支持工具的模型
    tool_call_with_anthropic(client, model)