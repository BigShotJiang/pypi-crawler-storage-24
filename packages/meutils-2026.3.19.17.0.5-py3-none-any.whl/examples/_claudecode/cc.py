#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Project      : AI.  @by PyCharm
# @File         : cc
# @Time         : 2026/2/9 11:42
# @Author       : betterme
# @WeChat       : meutils
# @Software     : PyCharm
# @Description  :
import os

from meutils.pipe import *
from anthropic import Anthropic

client = Anthropic()

model = "claude-sonnet-4-5-20250929"
# model = "claude-opus-4-6"

message = client.messages.create(
    max_tokens=1024,
    messages=[
        {
            "role": "user",
            "content": "Hello, Claude",
        }
    ],
    model=model,
    stream=True
)
# print(message.content)

for  i in message:
    print(i)
