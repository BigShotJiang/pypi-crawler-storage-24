#!/usr/bin/env python3
"""
从 JSON 文件加载请求参数，使用 Anthropic 格式发送流式请求
"""

import json
import sys
from typing import Any

try:
    import anthropic
except ImportError:
    print("请安装 anthropic 包: pip install anthropic")
    sys.exit(1)


def openai_to_anthropic_message(messages: list[dict[str, Any]]) -> tuple[str | None, list[dict[str, Any]]]:
    """将 OpenAI 格式的消息转换为 Anthropic 格式。
    
    Returns:
        tuple: (system_message, user_messages)
        - system_message: 系统消息（字符串或 None）
        - user_messages: 用户消息列表
    """
    system_parts: list[str] = []
    user_messages: list[dict[str, Any]] = []
    
    for message in messages:
        role = message.get("role")
        content = message.get("content", "")
        
        if role == "system":
            if isinstance(content, str):
                system_parts.append(content)
            elif isinstance(content, list):
                # 处理内容块列表
                text_parts = []
                for block in content:
                    if isinstance(block, dict) and block.get("type") == "text":
                        text_parts.append(block.get("text", ""))
                    elif isinstance(block, str):
                        text_parts.append(block)
                system_parts.append(" ".join(text_parts))
        elif role == "user":
            if isinstance(content, str):
                user_messages.append({
                    "role": "user",
                    "content": content
                })
            elif isinstance(content, list):
                # 处理内容块列表
                anthropic_content = []
                for block in content:
                    if isinstance(block, dict):
                        block_type = block.get("type", "text")
                        if block_type == "text":
                            anthropic_content.append({
                                "type": "text",
                                "text": block.get("text", "")
                            })
                        elif block_type == "image_url":
                            # 处理图片
                            image_url = block.get("image_url", {})
                            if isinstance(image_url, str):
                                image_url = {"url": image_url}
                            anthropic_content.append({
                                "type": "image",
                                "source": {
                                    "type": "url",
                                    "url": image_url.get("url", "")
                                }
                            })
                user_messages.append({
                    "role": "user",
                    "content": anthropic_content
                })
        elif role == "assistant":
            anthropic_content = []
            if isinstance(content, str):
                anthropic_content.append({"type": "text", "text": content})
            elif isinstance(content, list):
                for block in content:
                    if isinstance(block, dict):
                        block_type = block.get("type", "text")
                        if block_type == "text":
                            anthropic_content.append({
                                "type": "text",
                                "text": block.get("text", "")
                            })
                        elif block_type == "tool_call":
                            # 处理工具调用
                            anthropic_content.append({
                                "type": "tool_use",
                                "id": block.get("id", ""),
                                "name": block.get("name", ""),
                                "input": block.get("input", {})
                            })
            
            # 处理 tool_calls（OpenAI 格式）
            tool_calls = message.get("tool_calls", [])
            for tool_call in tool_calls:
                anthropic_content.append({
                    "type": "tool_use",
                    "id": tool_call.get("id", ""),
                    "name": tool_call.get("function", {}).get("name", ""),
                    "input": json.loads(tool_call.get("function", {}).get("arguments", "{}"))
                })
            
            user_messages.append({
                "role": "assistant",
                "content": anthropic_content
            })
        elif role == "tool":
            # 工具结果
            tool_call_id = message.get("tool_call_id", "")
            tool_content = content if isinstance(content, str) else str(content)
            user_messages.append({
                "role": "user",
                "content": [{
                    "type": "tool_result",
                    "tool_use_id": tool_call_id,
                    "content": tool_content
                }]
            })
    
    system_message = "\n".join(system_parts) if system_parts else None
    return system_message, user_messages


def convert_openai_tools_to_anthropic(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """将 OpenAI 格式的工具定义转换为 Anthropic 格式"""
    anthropic_tools = []
    for tool in tools:
        if "function" in tool:
            func = tool["function"]
            anthropic_tools.append({
                "name": func.get("name", ""),
                "description": func.get("description", ""),
                "input_schema": func.get("parameters", {})
            })
        else:
            # 如果已经是 Anthropic 格式，直接使用
            anthropic_tools.append(tool)
    return anthropic_tools


def _to_dict(obj: Any) -> dict[str, Any]:
    """将对象转换为字典"""
    if isinstance(obj, dict):
        return obj
    elif hasattr(obj, '__dict__'):
        return obj.__dict__
    elif hasattr(obj, '_asdict'):  # namedtuple
        return obj._asdict()
    else:
        # 尝试转换为 JSON 再解析
        try:
            import json
            return json.loads(json.dumps(obj, default=str))
        except Exception:
            return {}


def load_request_from_json(json_path: str) -> dict[str, Any]:
    """从 JSON 文件加载请求参数"""
    with open(json_path, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # request 字段是一个 JSON 字符串，需要解析
    request_str = data.get("request", "{}")
    if isinstance(request_str, str):
        request_data = json.loads(request_str)
    else:
        request_data = request_str
    
    return request_data


def main():
    # JSON 文件路径
    json_path = "/Users/kausal/Library/Containers/com.tencent.xWeChat/Data/Documents/xwechat_files/wxid_4absa07y7xb522_8539/msg/file/2025-12/20251226110208242812333T1Wx5NHn.json"
    
    # API 配置（请根据实际情况修改）
    base_url = "https://api.chatfire.cn"  # 或你的代理地址
    api_key = "sk-"  # 请替换为实际的 API key
    
    # 从 JSON 文件加载请求参数
    print(f"正在加载请求参数从: {json_path}")
    request_data = load_request_from_json(json_path)
    
    # 提取参数
    model = request_data.get("model", "claude-3-5-sonnet-20241022")
    messages = request_data.get("messages", [])
    tools = request_data.get("tools", None)
    max_tokens = request_data.get("max_tokens", 4096)
    temperature = request_data.get("temperature", None)
    
    print(f"模型: {model}")
    print(f"消息数量: {len(messages)}")
    print(f"工具数量: {len(tools) if tools else 0}")
    print(f"最大 tokens: {max_tokens}")
    
    # 转换消息格式
    system_message, user_messages = openai_to_anthropic_message(messages)
    
    # 转换工具格式
    anthropic_tools = None
    if tools:
        anthropic_tools = convert_openai_tools_to_anthropic(tools)
    
    # 初始化 Anthropic 客户端
    client = anthropic.Anthropic(
        api_key=api_key,
        base_url=base_url
    )
    
    # 构建请求参数
    api_kwargs: dict[str, Any] = {
        "model": model,
        "messages": user_messages,
        "max_tokens": max_tokens,
    }
    
    if system_message:
        api_kwargs["system"] = system_message
    
    if anthropic_tools:
        api_kwargs["tools"] = anthropic_tools
    
    if temperature is not None:
        api_kwargs["temperature"] = temperature
    
    # 发送流式请求
    print("\n开始流式响应:\n")
    print("-" * 80)
    
    # 用于存储 token 使用情况
    usage_info: dict[str, Any] = {}
    
    try:
        with client.messages.stream(**api_kwargs) as stream:
            for event in stream:
                event_type = event.type
                
                if event_type == "message_start":
                    print(f"[消息开始]")
                    # 尝试从 message_start 事件中获取 usage 信息
                    if hasattr(event, 'message'):
                        message = getattr(event, 'message', None)
                        if message:
                            # 尝试多种方式获取 usage
                            if hasattr(message, 'usage'):
                                usage = getattr(message, 'usage', None)
                                if usage:
                                    usage_info = _to_dict(usage) if not isinstance(usage, dict) else usage
                            # 也检查是否有 usage 属性（可能是字典形式）
                            elif isinstance(message, dict) and 'usage' in message:
                                usage_info = message['usage'] if isinstance(message['usage'], dict) else _to_dict(message['usage'])
                elif event_type == "content_block_start":
                    if hasattr(event, 'content_block'):
                        block_type = getattr(event.content_block, 'type', 'unknown')
                        print(f"[内容块开始] 类型: {block_type}")
                elif event_type == "content_block_delta":
                    delta = getattr(event, 'delta', None)
                    if delta:
                        # 处理文本增量
                        if hasattr(delta, 'text') and delta.text:
                            print(delta.text, end="", flush=True)
                        # 处理工具使用增量
                        elif hasattr(delta, 'type') and getattr(delta, 'type', None) == "tool_use":
                            tool_name = getattr(delta, 'name', 'unknown')
                            print(f"\n[工具调用增量] {tool_name}")
                elif event_type == "content_block_stop":
                    print(f"\n[内容块结束]")
                elif event_type == "message_delta":
                    delta = getattr(event, 'delta', None)
                    if delta:
                        # 更新 usage 信息
                        if hasattr(delta, 'usage'):
                            usage = getattr(delta, 'usage', None)
                            if usage:
                                usage_info = _to_dict(usage) if not isinstance(usage, dict) else usage
                        # 处理停止原因
                        if hasattr(delta, 'stop_reason'):
                            stop_reason = getattr(delta, 'stop_reason', None)
                            if stop_reason:
                                print(f"\n[消息增量] 停止原因: {stop_reason}")
                elif event_type == "message_stop":
                    print(f"\n[消息结束]")
                    # 尝试从 message_stop 事件中获取最终的 usage 信息
                    if hasattr(event, 'message'):
                        message = getattr(event, 'message', None)
                        if message:
                            if hasattr(message, 'usage'):
                                usage = getattr(message, 'usage', None)
                                if usage:
                                    usage_info = _to_dict(usage) if not isinstance(usage, dict) else usage
                            elif isinstance(message, dict) and 'usage' in message:
                                usage_info = message['usage'] if isinstance(message['usage'], dict) else _to_dict(message['usage'])
            
            # 尝试从流对象获取最终消息（如果支持）
            try:
                final_message = stream.get_final_message()
                if final_message and hasattr(final_message, 'usage'):
                    usage = getattr(final_message, 'usage', None)
                    if usage:
                        usage_info = _to_dict(usage) if not isinstance(usage, dict) else usage
            except AttributeError:
                # 如果流对象没有 get_final_message 方法，忽略
                pass
        
        print("\n" + "-" * 80)
        print("\n流式响应完成!")
        
        # 输出 token 使用情况
        if usage_info:
            print("\n" + "=" * 80)
            print("Token 使用情况:")
            print("=" * 80)
            
            # 处理不同的 usage 格式
            prompt_tokens = usage_info.get('prompt_tokens') or usage_info.get('input_tokens', 0)
            completion_tokens = usage_info.get('completion_tokens') or usage_info.get('output_tokens', 0)
            total_tokens = usage_info.get('total_tokens', 0)
            reasoning_tokens = usage_info.get('reasoning_tokens', 0)
            
            print(f"输入 tokens (prompt_tokens/input_tokens): {prompt_tokens}")
            if reasoning_tokens > 0:
                print(f"推理 tokens (reasoning_tokens): {reasoning_tokens}")
            print(f"输出 tokens (completion_tokens/output_tokens): {completion_tokens}")
            print(f"总计 tokens (total_tokens): {total_tokens}")
            
            # 输出详细信息（如果有）
            if 'prompt_tokens_details' in usage_info:
                print(f"\n输入 tokens 详情:")
                details = usage_info['prompt_tokens_details']
                if isinstance(details, dict):
                    for key, value in details.items():
                        if value > 0:
                            print(f"  - {key}: {value}")
            
            if 'completion_tokens_details' in usage_info:
                print(f"\n输出 tokens 详情:")
                details = usage_info['completion_tokens_details']
                if isinstance(details, dict):
                    for key, value in details.items():
                        if value > 0:
                            print(f"  - {key}: {value}")
            
            print("=" * 80)
        else:
            print("\n[注意] 未获取到 token 使用信息")
        
    except Exception as e:
        print(f"\n错误: {e}", file=sys.stderr)
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()

