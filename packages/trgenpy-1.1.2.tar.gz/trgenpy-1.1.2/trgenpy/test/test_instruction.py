from trgenpy.instruction import (
    istrUnactiveFor, istrActiveFor, istrWaitPE, istrWaitNE,
    istrRepeat, istrEnd, istrNotAdmissible, decode_instruction
)

def test_unactive_for_us():
    assert istrUnactiveFor(10) == (10 << 3) | 0

def test_active_for_us():
    assert istrActiveFor(5) == (5 << 3) | 1

def test_wait_pe():
    assert istrWaitPE(2) == (2 << 3) | 2

def test_wait_ne():
    assert istrWaitNE(3) == (3 << 3) | 3

def test_repeat():
    assert istrRepeat(1, 2) == (2 << 8) | (1 << 3) | 7

def test_end():
    assert istrEnd() == 4

def test_not_admissible():
    assert istrNotAdmissible() == 5

def test_decode_instruction_active():
    word = istrActiveFor(7)
    assert decode_instruction(word) == ('ACTIVE', 7)