"""Recording test doubles for fixture-driven MasteryTrack tests."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from test_support.transport_base import BaseRecordingTransport
from test_support.transport_helpers import dump_model

from ..types.responses import (
    MasteryTrackAssignResponse,
    MasteryTrackInvalidateResponse,
    MasteryTrackInventorySearchResponse,
)

if TYPE_CHECKING:
    from timeback_common import AuthCheckResult


def create_recording_transport(
    fail_request: dict[str, Any] | None = None,
    transport_config: dict[str, Any] | None = None,
) -> BaseRecordingTransport:
    """Create a transport-like object that records calls and returns stub responses."""
    return _MasteryTrackRecordingTransport(
        fail_request=fail_request, transport_config=transport_config
    )


def create_recording_authenticator() -> _RecordingAuthenticator:
    """Create an authenticator-like object that records token calls."""
    return _RecordingAuthenticator()


class _MasteryTrackRecordingTransport(BaseRecordingTransport):
    """MasteryTrack-specific recording transport."""

    def _default_get_stub(self, path: str) -> dict[str, Any]:
        if "/authoring/inventory/search" in path:
            return dump_model(_stub_inventory_response())
        return {"success": True}

    def _default_post_stub(self, path: str) -> dict[str, Any]:
        if path == "/delivery/assignments/assign":
            return dump_model(_stub_assign_response())
        if path == "/delivery/assignments/invalidate":
            return dump_model(_stub_invalidate_response())
        return {"success": True}


class _RecordingAuthenticator:
    """MasteryTrack authenticator test double for authorizer fixtures."""

    def __init__(self) -> None:
        self.calls: list[dict[str, str]] = []

    async def get_token(self, email_override: str | None = None) -> str:
        record: dict[str, str] = {"path": "/authorizer", "method": "POST"}
        if email_override:
            record["bodyKey"] = email_override
        self.calls.append(record)
        return "mock-jwt-token"

    def invalidate(self) -> None:
        return

    async def check_auth(self) -> AuthCheckResult:
        return {
            "ok": True,
            "latency_ms": 0,
            "checks": {"token_acquisition": True},
        }


def _stub_inventory_response() -> MasteryTrackInventorySearchResponse:
    return MasteryTrackInventorySearchResponse.model_validate(
        {
            "success": True,
            "data": [
                {
                    "id": 101,
                    "timeback_id": "mt-101",
                    "name": "Math Assessment",
                    "subject": "Math",
                    "grade": "3rd",
                    "grade_rank": 3,
                    "version": 1,
                    "active": True,
                    "metadata": {"type": "assessment"},
                    "supported": True,
                    "created_at": "2025-01-01T00:00:00Z",
                    "updated_at": "2025-01-01T00:00:00Z",
                    "invalidated_on": None,
                }
            ],
        }
    )


def _stub_assign_response() -> MasteryTrackAssignResponse:
    return MasteryTrackAssignResponse.model_validate(
        {
            "success": True,
            "platform": "masterytrack",
            "data": {
                "assignment": {
                    "id": 123,
                    "student_email": "student@example.com",
                    "test_name": "Math Assessment",
                    "assigned_by": 1,
                    "test_url": "https://example.com/tests/123",
                    "status": "assigned",
                    "expires_at": None,
                    "metadata": None,
                    "created_at": "2025-01-01T00:00:00Z",
                },
                "message": "Assignment created",
            },
        }
    )


def _stub_invalidate_response() -> MasteryTrackInvalidateResponse:
    return MasteryTrackInvalidateResponse.model_validate(
        {
            "success": True,
            "data": {
                "message": "Assignments invalidated",
                "total_invalidated": 1,
                "invalidated_assignments": [
                    {"assignment_id": 123, "student_email": "student@example.com"}
                ],
            },
        }
    )
