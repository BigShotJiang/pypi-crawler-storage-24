"""
MasteryTrack Input Types

Pydantic models for MasteryTrack request validation.
Ports the Zod schemas from the TypeScript SDK.
"""

from __future__ import annotations

from pydantic import BaseModel, EmailStr, Field, model_validator

from timeback_common import NonEmptyString  # noqa: TC001


class MasteryTrackAuthorizerInput(BaseModel):
    """Input for the MasteryTrack authorizer endpoint."""

    email: EmailStr


class MasteryTrackInventorySearchParams(BaseModel):
    """Parameters for searching the MasteryTrack test inventory."""

    model_config = {"populate_by_name": True}

    name: NonEmptyString | None = None
    timeback_id: NonEmptyString | None = None
    grade: NonEmptyString | None = None
    subject: NonEmptyString | None = None
    all: bool | None = None


class MasteryTrackAssignmentInput(BaseModel):
    """Input for assigning a MasteryTrack test to a student.

    Requires either ``timeback_id`` or ``subject``.
    ``grade_rank`` requires ``subject``.
    ``assessment_line_item_sourced_id`` and ``assessment_result_sourced_id``
    must be provided together.
    """

    model_config = {"populate_by_name": True}

    student_email: EmailStr
    timeback_id: NonEmptyString | None = None
    subject: NonEmptyString | None = None
    grade_rank: int | None = Field(default=None, ge=0, le=12)
    assessment_line_item_sourced_id: NonEmptyString | None = None
    assessment_result_sourced_id: NonEmptyString | None = None

    @model_validator(mode="after")
    def _validate_cross_field_rules(self) -> MasteryTrackAssignmentInput:
        errors: list[str] = []

        if not self.timeback_id and not self.subject:
            errors.append("Must provide either timeback_id or subject")

        if self.grade_rank is not None and not self.subject:
            errors.append("grade_rank requires subject")

        has_line_item = self.assessment_line_item_sourced_id is not None
        has_result_id = self.assessment_result_sourced_id is not None
        if has_line_item != has_result_id:
            errors.append(
                "assessment_line_item_sourced_id and assessment_result_sourced_id "
                "must be provided together"
            )

        if errors:
            raise ValueError("; ".join(errors))

        return self


class MasteryTrackInvalidateAssignmentInput(BaseModel):
    """Input for invalidating MasteryTrack assignments.

    Requires one of: ``assignment_id``, ``timeback_id``,
    or (``subject`` + ``grade_rank``).
    """

    model_config = {"populate_by_name": True}

    student_email: EmailStr
    assignment_id: int | None = Field(default=None, gt=0)
    timeback_id: NonEmptyString | None = None
    subject: NonEmptyString | None = None
    grade_rank: int | None = Field(default=None, ge=0, le=12)

    @model_validator(mode="after")
    def _validate_identifier_required(self) -> MasteryTrackInvalidateAssignmentInput:
        errors: list[str] = []

        by_assignment = self.assignment_id is not None
        by_timeback = bool(self.timeback_id)
        by_subject_grade = bool(self.subject) and self.grade_rank is not None

        if not by_assignment and not by_timeback and not by_subject_grade:
            errors.append(
                "Either assignment_id, timeback_id, or (subject and grade_rank) is required"
            )

        if self.grade_rank is not None and not self.subject:
            errors.append("grade_rank requires subject")

        if errors:
            raise ValueError("; ".join(errors))

        return self


__all__ = [
    "MasteryTrackAssignmentInput",
    "MasteryTrackAuthorizerInput",
    "MasteryTrackInvalidateAssignmentInput",
    "MasteryTrackInventorySearchParams",
]
