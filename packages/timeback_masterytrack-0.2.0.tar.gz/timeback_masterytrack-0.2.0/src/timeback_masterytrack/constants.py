"""
MasteryTrack Constants

Configuration constants for the MasteryTrack client.
"""

MASTERYTRACK_BASE_URLS: dict[str, str] = {
    "staging": "https://l407b3xadi.execute-api.us-east-1.amazonaws.com/dev",
    "production": "https://l407b3xadi.execute-api.us-east-1.amazonaws.com/prod",
}

MASTERYTRACK_ENV_VARS = {
    "base_url": ("TIMEBACK_MASTERYTRACK_BASE_URL", "MASTERYTRACK_BASE_URL"),
    "api_key": ("TIMEBACK_MASTERYTRACK_API_KEY", "MASTERYTRACK_API_KEY"),
    "email": ("TIMEBACK_MASTERYTRACK_EMAIL", "MASTERYTRACK_EMAIL"),
}

SERVICE_NAME = "masterytrack"
