"""Python-native tests for MasteryTrack client initialization and configuration."""

import os
from unittest.mock import AsyncMock, patch

import pytest

from timeback_masterytrack import MasteryTrackClient


class TestMasteryTrackClientInit:
    """Tests for client initialization."""

    def test_staging_environment(self):
        """Staging environment should use staging URL."""
        client = MasteryTrackClient(env="staging", api_key="test-key", email="admin@example.com")
        assert client._transport.base_url is not None
        assert "dev" in client._transport.base_url

    def test_production_environment(self):
        """Production environment should use production URL."""
        client = MasteryTrackClient(env="production", api_key="test-key", email="admin@example.com")
        assert "prod" in client._transport.base_url

    def test_custom_base_url(self):
        """Custom base URL should override environment."""
        client = MasteryTrackClient(
            base_url="https://custom.example.com",
            api_key="test-key",
            email="admin@example.com",
        )
        assert client._transport.base_url == "https://custom.example.com"

    def test_explicit_credentials(self):
        """Explicit credentials should work."""
        client = MasteryTrackClient(env="staging", api_key="my-key", email="admin@example.com")
        assert client._authenticator is not None

    def test_missing_credentials_raises(self):
        """Missing credentials should raise ValueError."""
        with (
            patch.dict(os.environ, {}, clear=True),
            pytest.raises(ValueError, match="Missing MasteryTrack credentials"),
        ):
            MasteryTrackClient(env="staging")

    def test_missing_api_key_raises(self):
        """Missing api_key with email should raise ValueError."""
        with (
            patch.dict(os.environ, {}, clear=True),
            pytest.raises(ValueError, match="Missing MasteryTrack credentials"),
        ):
            MasteryTrackClient(env="staging", email="admin@example.com")

    def test_missing_email_raises(self):
        """Missing email with api_key should raise ValueError."""
        with (
            patch.dict(os.environ, {}, clear=True),
            pytest.raises(ValueError, match="Missing MasteryTrack credentials"),
        ):
            MasteryTrackClient(env="staging", api_key="test-key")

    def test_default_env_is_staging(self):
        """Default environment should be staging when no env is specified."""
        client = MasteryTrackClient(api_key="test-key", email="admin@example.com")
        assert "dev" in client._transport.base_url

    def test_env_var_fallback(self):
        """Should resolve credentials from environment variables."""
        env = {
            "TIMEBACK_MASTERYTRACK_API_KEY": "env-key",
            "TIMEBACK_MASTERYTRACK_EMAIL": "env@example.com",
        }
        with patch.dict(os.environ, env, clear=True):
            client = MasteryTrackClient(env="staging")
            assert client._authenticator is not None

    def test_env_var_secondary_fallback(self):
        """Should fall back to MASTERYTRACK_* env vars."""
        env = {
            "MASTERYTRACK_API_KEY": "env-key",
            "MASTERYTRACK_EMAIL": "env@example.com",
        }
        with patch.dict(os.environ, env, clear=True):
            client = MasteryTrackClient(env="staging")
            assert client._authenticator is not None

    def test_custom_transport_mode(self):
        """Custom transport mode should accept transport + authenticator."""

        class MockTransport:
            base_url = "https://mock.example.com"

            async def close(self) -> None:
                pass

        class MockAuthenticator:
            async def get_token(self, _email_override=None):
                return "jwt-token"

            def invalidate(self):
                pass

            async def check_auth(self):
                return {"ok": True, "latency_ms": 1, "checks": {"token_acquisition": True}}

        client = MasteryTrackClient(
            transport=MockTransport(),
            authenticator=MockAuthenticator(),
        )
        assert client._transport.base_url == "https://mock.example.com"

    def test_custom_transport_without_authenticator_raises(self):
        """Custom transport without authenticator should raise."""

        class MockTransport:
            base_url = "https://mock.example.com"

            async def close(self) -> None:
                pass

        with pytest.raises(ValueError, match="authenticator is required"):
            MasteryTrackClient(transport=MockTransport())


class TestMasteryTrackClientResources:
    """Tests for client resource initialization."""

    def test_all_resources_initialized(self):
        """Client should initialize all three resources."""
        client = MasteryTrackClient(env="staging", api_key="test-key", email="admin@example.com")
        assert hasattr(client, "authorizer")
        assert hasattr(client, "inventory")
        assert hasattr(client, "assignments")


class TestMasteryTrackClientTransport:
    """Tests for transport access."""

    def test_get_transport(self):
        """Client should expose transport via get_transport()."""
        client = MasteryTrackClient(env="staging", api_key="test-key", email="admin@example.com")
        transport = client.get_transport()
        assert transport is not None
        assert transport.base_url is not None


class TestMasteryTrackClientCheckAuth:
    """Tests for check_auth."""

    @pytest.mark.asyncio
    async def test_check_auth_with_custom_authenticator(self):
        """check_auth should delegate to authenticator."""

        class MockTransport:
            base_url = "https://mock.example.com"

            async def close(self) -> None:
                pass

        mock_auth = AsyncMock()
        mock_auth.check_auth = AsyncMock(
            return_value={"ok": True, "latency_ms": 5, "checks": {"token_acquisition": True}}
        )
        mock_auth.get_token = AsyncMock(return_value="jwt")
        mock_auth.invalidate = lambda: None

        client = MasteryTrackClient(
            transport=MockTransport(),
            authenticator=mock_auth,
        )
        result = await client.check_auth()
        assert result["ok"] is True
        mock_auth.check_auth.assert_awaited_once()


class TestMasteryTrackClientContextManager:
    """Tests for context manager support."""

    @pytest.mark.asyncio
    async def test_context_manager(self):
        """Client should work as async context manager."""
        async with MasteryTrackClient(
            env="staging", api_key="test-key", email="admin@example.com"
        ) as client:
            assert client._authenticator is not None
