"""Python-native tests for MasteryTrack JWT token provider behavior."""

import json

import httpx
import pytest

from timeback_masterytrack.lib.token_provider import MasteryTrackJwtProvider


def _make_provider(
    *,
    api_key: str = "api-key",
    email: str = "user@example.com",
    base_url: str = "https://example.com/dev",
    transport: httpx.MockTransport | None = None,
) -> MasteryTrackJwtProvider:
    """Create a JWT provider with an optional mock transport."""
    client = httpx.AsyncClient(transport=transport) if transport else None
    return MasteryTrackJwtProvider(
        base_url=base_url,
        auth={"api_key": api_key, "email": email},
        http_client=client,
    )


def _success_transport(jwt: str = "jwt-1", call_counter: list | None = None):
    """Create a mock transport that returns successful authorizer responses."""

    def handler(_request: httpx.Request) -> httpx.Response:
        count = 1
        if call_counter is not None:
            call_counter.append(1)
            count = len(call_counter)
        return httpx.Response(
            200,
            json={"success": True, "jwt": f"jwt-{count}" if call_counter else jwt},
        )

    return httpx.MockTransport(handler)


class TestJwtProviderTokenFetch:
    """Tests for JWT token fetching and caching."""

    @pytest.mark.asyncio
    async def test_fetches_and_caches_jwt(self):
        """Should fetch JWT and cache for subsequent calls."""
        provider = _make_provider(transport=_success_transport("jwt-1"))

        token_a = await provider.get_token()
        token_b = await provider.get_token()

        assert token_a == "jwt-1"
        assert token_b == "jwt-1"

    @pytest.mark.asyncio
    async def test_refetches_when_email_override_differs(self):
        """Should re-fetch when emailOverride differs from cached token email."""
        calls: list[int] = []
        provider = _make_provider(
            email="default@example.com",
            transport=_success_transport(call_counter=calls),
        )

        token_a = await provider.get_token()
        assert token_a == "jwt-1"

        token_b = await provider.get_token("other@example.com")
        assert token_b == "jwt-2"
        assert len(calls) == 2

    @pytest.mark.asyncio
    async def test_uses_cache_when_email_matches(self):
        """Should use cache when emailOverride matches cached token email."""
        calls: list[int] = []
        provider = _make_provider(
            email="user@example.com",
            transport=_success_transport(call_counter=calls),
        )

        await provider.get_token()
        token_b = await provider.get_token("user@example.com")

        assert token_b == "jwt-1"
        assert len(calls) == 1


class TestJwtProviderErrors:
    """Tests for error handling."""

    @pytest.mark.asyncio
    async def test_throws_descriptive_error_on_failure(self):
        """Should throw a descriptive error when authorizer fails."""

        def handler(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(
                401,
                json={"success": False, "error": "Invalid API key"},
            )

        provider = _make_provider(
            api_key="bad-key",
            transport=httpx.MockTransport(handler),
        )

        with pytest.raises(RuntimeError, match="Invalid API key"):
            await provider.get_token()

    @pytest.mark.asyncio
    async def test_throws_on_invalid_response(self):
        """Should throw when authorizer returns invalid response format."""

        def handler(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(200, json={"unexpected": "data"})

        provider = _make_provider(transport=httpx.MockTransport(handler))

        with pytest.raises(RuntimeError, match="invalid response"):
            await provider.get_token()

    @pytest.mark.asyncio
    async def test_throws_when_email_is_empty(self):
        """Should throw when no email is available."""
        provider = _make_provider(email="", transport=_success_transport())

        with pytest.raises(RuntimeError, match="email is required"):
            await provider.get_token("")


class TestJwtProviderInvalidate:
    """Tests for token invalidation."""

    @pytest.mark.asyncio
    async def test_invalidate_clears_cache(self):
        """After invalidate(), next getToken() should re-fetch."""
        calls: list[int] = []
        provider = _make_provider(transport=_success_transport(call_counter=calls))

        await provider.get_token()
        assert len(calls) == 1

        provider.invalidate()

        await provider.get_token()
        assert len(calls) == 2


class TestJwtProviderCheckAuth:
    """Tests for check_auth."""

    @pytest.mark.asyncio
    async def test_check_auth_success(self):
        """check_auth should return ok=True on success."""
        provider = _make_provider(transport=_success_transport())

        result = await provider.check_auth()
        assert result["ok"] is True
        assert result["checks"]["token_acquisition"] is True

    @pytest.mark.asyncio
    async def test_check_auth_failure(self):
        """check_auth should return ok=False on failure."""

        def handler(_request: httpx.Request) -> httpx.Response:
            return httpx.Response(401, json={"success": False, "error": "Bad key"})

        provider = _make_provider(transport=httpx.MockTransport(handler))

        result = await provider.check_auth()
        assert result["ok"] is False
        assert result["checks"]["token_acquisition"] is False
        assert "Bad key" in (result.get("error") or "")


class TestJwtProviderRequestFormat:
    """Tests for the authorizer request format."""

    @pytest.mark.asyncio
    async def test_sends_correct_headers_and_body(self):
        """Should send x-api-key header and email in body."""
        captured_requests: list[httpx.Request] = []

        def handler(request: httpx.Request) -> httpx.Response:
            captured_requests.append(request)
            return httpx.Response(200, json={"success": True, "jwt": "jwt-1"})

        provider = _make_provider(
            api_key="my-api-key",
            email="test@example.com",
            transport=httpx.MockTransport(handler),
        )

        await provider.get_token()

        assert len(captured_requests) == 1
        req = captured_requests[0]
        assert req.headers["x-api-key"] == "my-api-key"
        body = json.loads(req.content)
        assert body == {"email": "test@example.com"}
        assert "/authorizer" in str(req.url)
