"""Fixture-driven tests for MasteryTrack authorizer resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_masterytrack.lib.testing import create_recording_authenticator
from timeback_masterytrack.resources.authorizer import AuthorizerResource

FIXTURES_DIR = fixtures_dir("masterytrack", "authorizer")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    del fail_request
    del transport_config
    authenticator = create_recording_authenticator()
    return {"resource": AuthorizerResource(authenticator), "calls": authenticator.calls}


test_masterytrack_authorizer_fixtures = make_resource_fixture_test(
    name="masterytrack > authorizer",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
