"""Fixture-driven tests for MasteryTrack assignments resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_masterytrack.lib.testing import create_recording_transport
from timeback_masterytrack.resources.assignments import AssignmentsResource

FIXTURES_DIR = fixtures_dir("masterytrack", "assignments")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": AssignmentsResource(transport), "calls": transport.calls}


test_masterytrack_assignments_fixtures = make_resource_fixture_test(
    name="masterytrack > assignments",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
