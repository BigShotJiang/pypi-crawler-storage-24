"""Fixture-driven tests for MasteryTrack inventory resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_masterytrack.lib.testing import create_recording_transport
from timeback_masterytrack.resources.inventory import InventoryResource

FIXTURES_DIR = fixtures_dir("masterytrack", "inventory")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": InventoryResource(transport), "calls": transport.calls}


test_masterytrack_inventory_fixtures = make_resource_fixture_test(
    name="masterytrack > inventory",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
