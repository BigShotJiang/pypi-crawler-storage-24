# timeback-masterytrack

Timeback MasteryTrack client for Python — assessment assignment, inventory search, and test delivery operations.

## Installation

```bash
pip install timeback-masterytrack
```

## Quick Start

```python
from timeback_masterytrack import MasteryTrackClient

client = MasteryTrackClient(
    env="staging",
    api_key="your-api-key",
    email="admin@example.com",
)

# Search test inventory
results = await client.inventory.search({"subject": "Math"})

# Assign a test
assignment = await client.assignments.assign({
    "student_email": "student@example.com",
    "timeback_id": "_677e37c49e904cafcc66fdb4",
})
```
