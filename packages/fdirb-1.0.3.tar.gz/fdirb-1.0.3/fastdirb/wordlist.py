def generate_default_wordlist() -> list:
    """
    Полный встроенный словарь (~3000 путей).
    Покрывает 99% типичных директорий и файлов.
    Собран из SecLists, dirb/common, dirbuster, fuzzdb.
    """

    paths = []

    # ══════════════════════════════════════
    #  1. АДМИН-ПАНЕЛИ (~150)
    # ══════════════════════════════════════
    admin = [
        "admin", "Admin", "ADMIN",
        "admin1", "admin2", "admin3", "admin4",
        "admin.php", "admin.html", "admin.asp", "admin.aspx",
        "admin.jsp", "admin.cgi", "admin.pl",
        "admin/login", "admin/index", "admin/home",
        "admin/dashboard", "admin/admin",
        "admin/account", "admin/config",
        "admin_area", "admin_page", "admin_login",
        "adminarea", "adminlogin", "adminpanel",
        "admin-panel", "admin-login", "admin-console",
        "admin-area", "admin-dashboard", "admin-site",
        "administrator", "administrator/login",
        "administrator/index", "administrator/account",
        "administration", "admins",
        "adm", "adm.php", "adm.html",
        "administer", "admincp", "adminCP",
        "admin.bak", "admin.old", "admin.txt",
        "panel", "panel-admin", "paneldecontrol",
        "cpanel", "cPanel", "Cpanel",
        "controlpanel", "control-panel", "control_panel",
        "dashboard", "dashboard/login",
        "manage", "manager", "management",
        "manager/html", "manager/text", "manager/status",
        "moderator", "moderator.php",
        "webmaster", "webadmin", "web-admin",
        "sysadmin", "sys-admin", "systemadmin",
        "sysadministrator", "superadmin", "super-admin",
        "su", "super", "supervisor",
        "root", "master", "operator",
        "backend", "back-end", "backoffice", "back-office",
        "cms", "cms-admin", "cms/login",
        "portal", "portal/admin",
        "console", "console/login",
        "cockpit", "cockpit/login",
        "headquarters", "hq",
        "_admin", "__admin",
        "site-admin", "siteadmin",
        "site-manager", "sitemanager",
        "wp-admin", "wp-admin/login",
        "wp-login", "wp-login.php",
        "bitrix/admin", "bitrix/admin/index.php",
        "modx/manager",
        "typo3/login", "typo3conf",
        "umbraco", "umbraco/login",
        "sitefinity", "sitefinity/login",
        "craft/admin", "craft/login",
        "ghost/login", "ghost/api",
        "strapi/admin",
        "keystonejs", "keystone/signin",
        "directus/admin",
    ]
    paths.extend(admin)

    # ══════════════════════════════════════
    #  2. АВТОРИЗАЦИЯ И АККАУНТЫ (~120)
    # ══════════════════════════════════════
    auth = [
        "login", "Login", "LOGIN",
        "login.php", "login.html", "login.asp", "login.aspx",
        "login.jsp", "login.cgi", "login.do", "login.action",
        "signin", "sign-in", "sign_in",
        "signin.php", "signin.html",
        "signup", "sign-up", "sign_up",
        "signup.php", "signup.html",
        "register", "Register",
        "register.php", "register.html",
        "registration", "registration.php",
        "join", "enroll", "subscribe",
        "auth", "auth/login", "auth/signin", "auth/register",
        "authenticate", "authenticate.php",
        "authorization", "authorize",
        "oauth", "oauth2", "oauth/authorize",
        "oauth/token", "oauth/callback",
        "sso", "sso/login", "saml", "saml/login",
        "cas", "cas/login",
        "logout", "Logout", "logout.php",
        "logoff", "log-off", "signout", "sign-out",
        "session", "sessions",
        "token", "tokens", "jwt",
        "account", "accounts", "myaccount", "my-account",
        "account/login", "account/register",
        "profile", "profiles", "myprofile", "my-profile",
        "user", "users", "user/login",
        "member", "members",
        "customer", "customers",
        "client", "clients",
        "password", "passwd",
        "forgot", "forgot-password", "forgotpassword",
        "forgot_password", "forgot-pwd",
        "reset", "reset-password", "resetpassword",
        "reset_password", "reset-pwd",
        "change-password", "changepassword",
        "change_password", "update-password",
        "recover", "recovery", "activate",
        "activation", "verify", "verification",
        "confirm", "confirmation",
        "2fa", "mfa", "two-factor", "otp",
    ]
    paths.extend(auth)

    # ══════════════════════════════════════
    #  3. API И ДОКУМЕНТАЦИЯ (~150)
    # ══════════════════════════════════════
    api = [
        "api", "API", "Api",
        "api/", "api/v1", "api/v2", "api/v3", "api/v4",
        "api/1", "api/2", "api/3",
        "api/v1.0", "api/v2.0",
        "api/index", "api/status", "api/health",
        "api/login", "api/auth", "api/token",
        "api/users", "api/user", "api/me",
        "api/admin", "api/config", "api/settings",
        "api/search", "api/data", "api/info",
        "api/test", "api/debug", "api/ping",
        "api/upload", "api/download", "api/export",
        "api/graphql", "api/rest",
        "api-docs", "api-doc", "apidocs", "apidoc",
        "api/docs", "api/doc", "api/help",
        "api/swagger", "api/openapi",
        "v1", "v2", "v3",
        "rest", "rest/api", "restapi",
        "graphql", "graphiql", "playground",
        "swagger", "swagger-ui", "swagger-ui.html",
        "swagger.json", "swagger.yaml", "swagger.yml",
        "swagger-resources",
        "openapi", "openapi.json", "openapi.yaml",
        "redoc", "rapidoc",
        "docs", "doc", "Docs",
        "docs/api", "docs/index",
        "documentation", "documentation/api",
        "reference", "api-reference",
        "developer", "developers", "dev-portal",
        "endpoints", "routes",
        "schema", "schemas",
        "webhook", "webhooks", "hooks",
        "callback", "callbacks",
        "ws", "wss", "websocket", "websockets",
        "socket", "socket.io",
        "rpc", "jsonrpc", "xmlrpc",
        "wsdl", "soap", "asmx",
        "odata", "feed", "feeds",
        "rss", "rss.xml", "atom", "atom.xml",
        "sitemap", "sitemap.xml", "sitemap_index.xml",
        "sitemaps", "sitemap.gz",
        "robots.txt", "humans.txt", "security.txt",
        ".well-known", ".well-known/security.txt",
        ".well-known/openid-configuration",
        ".well-known/jwks.json",
        ".well-known/change-password",
        "crossdomain.xml", "clientaccesspolicy.xml",
        "manifest.json", "manifest.webmanifest",
        "browserconfig.xml",
    ]
    paths.extend(api)

    # ══════════════════════════════════════
    #  4. ЧУВСТВИТЕЛЬНЫЕ ФАЙЛЫ (~200)
    # ══════════════════════════════════════
    sensitive = [
        # Git
        ".git", ".git/config", ".git/HEAD",
        ".git/index", ".git/logs",
        ".git/logs/HEAD", ".git/refs",
        ".git/objects", ".git/packed-refs",
        ".git/description", ".git/info",
        ".git/info/exclude",
        ".gitignore", ".gitattributes",
        ".gitmodules", ".gitkeep",

        # SVN / Mercurial / Bazaar
        ".svn", ".svn/entries", ".svn/wc.db",
        ".hg", ".hgignore", ".hgrc",
        ".bzr", ".bzrignore",

        # Конфигурация окружения
        ".env", ".env.local", ".env.dev",
        ".env.development", ".env.prod",
        ".env.production", ".env.staging",
        ".env.test", ".env.testing",
        ".env.example", ".env.sample",
        ".env.backup", ".env.bak",
        ".env.old", ".env.save",
        ".env.swp", ".env~",

        # Apache / Nginx
        ".htaccess", ".htpasswd", ".htgroups",
        ".htaccess.bak", ".htaccess.old",
        ".htpasswd.bak",
        "nginx.conf", "nginx/nginx.conf",
        "apache2.conf", "httpd.conf",

        # IDE и редакторы
        ".idea", ".idea/workspace.xml",
        ".vscode", ".vscode/settings.json",
        ".vscode/launch.json",
        ".project", ".classpath",
        ".settings", "nbproject",
        "*.swp", "*.swo", "*~",
        ".editorconfig",

        # OS
        ".DS_Store", "Thumbs.db",
        "desktop.ini", ".Spotlight-V100",
        ".Trashes", "ehthumbs.db",

        # Package managers
        "package.json", "package-lock.json",
        "yarn.lock", "pnpm-lock.yaml",
        "composer.json", "composer.lock",
        "Gemfile", "Gemfile.lock",
        "Pipfile", "Pipfile.lock",
        "requirements.txt", "requirements.in",
        "setup.py", "setup.cfg", "pyproject.toml",
        "Cargo.toml", "Cargo.lock",
        "go.mod", "go.sum",
        "pom.xml", "build.gradle", "build.xml",
        "Makefile", "makefile", "CMakeLists.txt",
        "Rakefile", "Taskfile.yml",
        "Gruntfile.js", "gulpfile.js",
        "webpack.config.js", "rollup.config.js",
        "vite.config.js", "tsconfig.json",
        "babel.config.js", ".babelrc",
        "jest.config.js", ".eslintrc",
        ".prettierrc", ".stylelintrc",
        "bower.json", ".bowerrc",

        # Docker / DevOps
        "Dockerfile", "dockerfile",
        "docker-compose.yml", "docker-compose.yaml",
        "docker-compose.dev.yml",
        "docker-compose.prod.yml",
        "docker-compose.override.yml",
        ".dockerignore",
        "Vagrantfile", "Procfile",
        "Jenkinsfile", ".travis.yml",
        ".github", ".github/workflows",
        ".gitlab-ci.yml", ".circleci",
        "buildspec.yml", "appspec.yml",
        "cloudbuild.yaml",
        "kubernetes", "k8s",
        "helm", "charts",
        "terraform.tfvars", "terraform.tfstate",
        "ansible.cfg", "playbook.yml",
        ".terraform", ".terraform.lock.hcl",

        # Сертификаты и ключи
        "server.key", "server.crt", "server.pem",
        "private.key", "public.key",
        "id_rsa", "id_rsa.pub",
        "id_dsa", "id_ecdsa", "id_ed25519",
        ".ssh", ".ssh/authorized_keys",
        ".ssh/known_hosts", ".ssh/id_rsa",
        "ssl", "ssl/certs", "ssl/private",
        "certs", "certificates",
        ".pem", ".key", ".crt", ".cer",
        ".p12", ".pfx", ".jks",
        "keystore", "keystore.jks",
        "truststore", "truststore.jks",

        # Общие конфиги
        "config", "config.php", "config.inc.php",
        "config.yml", "config.yaml", "config.json",
        "config.xml", "config.ini", "config.cfg",
        "config.toml", "config.conf",
        "config.bak", "config.old", "config.save",
        "config.txt", "config.dist",
        "config.sample", "config.example",
        "config.dev", "config.prod",
        "config.local", "config.default",
        "configuration", "configuration.php",
        "conf", "conf.d", "settings",
        "settings.php", "settings.py",
        "settings.json", "settings.yml",
        "settings.xml", "settings.ini",
        "settings.local", "settings.local.php",
        "local.settings.json",
        "appsettings.json", "appsettings.Development.json",
        "appsettings.Production.json",
        "application.properties", "application.yml",
        "application.yaml", "application-dev.yml",
        "application-prod.yml",
        "web.config", "Web.config",
        "app.config", "App.config",
        "wp-config.php", "wp-config.php.bak",
        "wp-config.php.old", "wp-config.php.save",
        "wp-config.php.txt", "wp-config.php~",
        "wp-config.bak", "wp-config.txt",
        "LocalSettings.php",
        "parameters.yml", "parameters.yaml",
        "database.yml", "database.php",
        "db.php", "db.inc", "conn.php",
        "connect.php", "connection.php",

        # README и документы
        "README", "README.md", "README.txt",
        "README.html", "README.rst",
        "CHANGELOG", "CHANGELOG.md", "CHANGES",
        "LICENSE", "LICENSE.md", "LICENSE.txt",
        "COPYING", "NOTICE",
        "TODO", "TODO.md", "TODO.txt",
        "INSTALL", "INSTALL.md", "INSTALL.txt",
        "CONTRIBUTING", "CONTRIBUTING.md",
        "AUTHORS", "CREDITS", "THANKS",
        "VERSION", "VERSION.txt",
        "RELEASE", "RELEASE_NOTES",
    ]
    paths.extend(sensitive)

    # ══════════════════════════════════════
    #  5. БЭКАПЫ И АРХИВЫ (~150)
    # ══════════════════════════════════════
    backups = [
        "backup", "backups", "bak",
        "backup.zip", "backup.tar.gz", "backup.tar",
        "backup.gz", "backup.rar", "backup.7z",
        "backup.sql", "backup.sql.gz", "backup.sql.zip",
        "backup.sql.bz2", "backup.sql.bak",
        "backup.bak", "backup.old",
        "backup.tar.bz2", "backup.tgz",
        "site.zip", "site.tar.gz", "site.rar",
        "www.zip", "www.tar.gz", "www.rar",
        "web.zip", "web.tar.gz",
        "public.zip", "public.tar.gz",
        "html.zip", "html.tar.gz",
        "htdocs.zip", "htdocs.tar.gz",
        "src.zip", "source.zip", "code.zip",
        "app.zip", "application.zip",
        "old", "old_site", "old-site",
        "archive", "archives",
        "archived", "previous",
        "temp", "tmp", "temporary",
        "cache", "cached", ".cache",
        "swap", ".swap", "recover",
        "dump", "dumps",
        "dump.sql", "dump.sql.gz",
        "data.sql", "data.zip",
        "db.sql", "db.sql.gz", "db.zip",
        "database.sql", "database.sql.gz",
        "database.zip", "database.tar.gz",
        "mysql.sql", "mysql.zip",
        "postgres.sql", "postgres.zip",
        "export", "exports",
        "export.sql", "export.csv", "export.json",
        "export.xml", "export.zip",
        "import", "imports",
        "snapshot", "snapshots",
        "migrate", "migration", "migrations",
        "upgrade", "update", "updates",
        "patch", "patches", "hotfix",
        "dist", "build", "release",
        "output", "out", "target",
        "deploy", "deployment", "deployments",

        # Паттерны с датами
        "backup2023", "backup2024", "backup2025",
        "backup_2023", "backup_2024", "backup_2025",
        "backup-2023", "backup-2024", "backup-2025",
        "bak2024", "bak2025",

        # Паттерны бэкапов конкретных файлов
        "index.php.bak", "index.php.old",
        "index.php.save", "index.php~",
        "index.php.swp", "index.php.orig",
        "index.bak", "index.old",
        "index.html.bak", "index.html.old",
        "config.php.bak", "config.php.old",
        "config.bak", "config.old",
        "login.php.bak", "login.php.old",
        "main.php.bak", "main.php.old",
        "admin.php.bak", "admin.php.old",
        "htaccess.bak", "htaccess.old",
        "htaccess.txt",
        "web.config.bak", "web.config.old",
        ".bak", ".old", ".save", ".orig",
        ".copy", ".tmp", ".temp",
    ]
    paths.extend(backups)

    # ══════════════════════════════════════
    #  6. КОНТЕНТ И СТРАНИЦЫ (~100)
    # ══════════════════════════════════════
    content = [
        "index", "index.php", "index.html", "index.htm",
        "index.asp", "index.aspx", "index.jsp",
        "index.cgi", "index.pl", "index.py",
        "index.rb", "index.cfm",
        "home", "Home", "homepage",
        "main", "Main", "default", "Default",
        "welcome", "Welcome",
        "about", "about-us", "aboutus", "about_us",
        "contact", "contact-us", "contactus", "contact_us",
        "help", "Help", "faq", "FAQ", "faqs",
        "support", "Support",
        "info", "information",
        "news", "News", "press", "press-releases",
        "blog", "Blog", "weblog",
        "posts", "post", "articles", "article",
        "pages", "page",
        "category", "categories", "tag", "tags",
        "search", "Search", "find", "query",
        "results", "result",
        "terms", "terms-of-service", "tos",
        "privacy", "privacy-policy",
        "cookie", "cookie-policy", "cookies",
        "legal", "disclaimer", "gdpr",
        "careers", "jobs", "hiring",
        "team", "our-team", "staff",
        "partners", "clients", "customers",
        "testimonials", "reviews", "feedback",
        "portfolio", "projects", "work", "works",
        "services", "features", "solutions",
        "pricing", "plans", "packages",
        "events", "calendar", "schedule",
        "map", "maps", "directions", "location",
        "forum", "forums", "community",
        "chat", "messaging", "messages",
        "notifications", "alerts",
    ]
    paths.extend(content)

    # ══════════════════════════════════════
    #  7. СТАТИКА И МЕДИА (~80)
    # ══════════════════════════════════════
    static = [
        "assets", "Assets",
        "static", "Static",
        "public", "Public",
        "media", "Media",
        "resources", "Resources",
        "content", "Content",
        "files", "Files",
        "uploads", "Uploads", "upload", "Upload",
        "uploaded", "uploaded_files",
        "user-uploads", "user_uploads",
        "file-upload", "file_upload",
        "images", "Images", "img", "IMG",
        "image", "pics", "pictures", "photos",
        "icons", "icon",
        "css", "CSS", "styles", "style",
        "stylesheets", "stylesheet",
        "js", "JS", "javascript", "Javascript",
        "scripts", "script",
        "fonts", "font", "webfonts",
        "video", "videos", "Video",
        "audio", "Audio", "music", "Music",
        "gallery", "Gallery", "galleries",
        "attachments", "attachment",
        "documents", "docs", "pdfs",
        "downloads", "download", "Download",
        "storage", "store",
        "cdn", "CDN",
        "bundles", "bundle", "chunks",
        "dist", "build", "compiled",
        "assets/images", "assets/css",
        "assets/js", "assets/fonts",
        "static/images", "static/css",
        "static/js", "static/fonts",
        "public/images", "public/css",
        "public/js", "public/uploads",
        "media/images", "media/uploads",
        "wp-content", "wp-content/uploads",
        "wp-content/themes", "wp-content/plugins",
        "wp-includes", "wp-includes/js",
        "wp-includes/css",
    ]
    paths.extend(static)

    # ══════════════════════════════════════
    #  8. РАЗРАБОТКА И ТЕСТИРОВАНИЕ (~100)
    # ══════════════════════════════════════
    dev = [
        "dev", "Dev", "devel", "develop", "development",
        "staging", "stage", "Stage", "stg",
        "test", "Test", "testing", "tests",
        "qa", "QA", "quality",
        "uat", "UAT", "acceptance",
        "debug", "Debug",
        "sandbox", "Sandbox",
        "demo", "Demo", "trial",
        "beta", "Beta", "alpha", "Alpha",
        "preview", "Preview",
        "canary", "nightly", "edge",
        "lab", "labs", "Lab",
        "prototype", "proto",
        "experimental", "experiment",
        "poc", "proof-of-concept",
        "internal", "Internal", "intranet",
        "private", "Private",
        "hidden", "Hidden", "secret",
        "restricted", "secure",
        "sample", "samples", "example", "examples",
        "mock", "mocks", "fake", "dummy",
        "fixture", "fixtures", "seed",
        "phpinfo", "phpinfo.php",
        "php-info", "php-info.php",
        "info.php", "i.php",
        "test.php", "test.html",
        "t.php", "p.php", "x.php",
        "check.php", "probe.php",
        "debug.php", "debug.html",
        "trace", "trace.axd",
        "elmah", "elmah.axd",
        "error_log", "errors.log",
        "debug.log", "app.log",
        "access.log", "error.log",
    ]
    paths.extend(dev)

    # ══════════════════════════════════════
    #  9. DEVOPS, CI/CD, МОНИТОРИНГ (~120)
    # ══════════════════════════════════════
    devops = [
        # CI/CD
        "jenkins", "Jenkins",
        "jenkins/login", "jenkins/script",
        "jenkins/api", "jenkins/manage",
        "hudson",
        "gitlab", "gitlab/login",
        "github", ".github",
        "bitbucket",
        "bamboo", "teamcity",
        "ci", "cd", "cicd",
        "pipeline", "pipelines",
        "build", "builds",
        "artifacts", "artifact",
        "registry", "registries",
        "packages", "repository",

        # Контейнеры
        "docker", "Docker",
        "kubernetes", "k8s",
        "kube", "kubectl",
        "helm", "charts",
        "rancher", "portainer",
        "swarm", "compose",

        # IaC
        "terraform", "ansible",
        "puppet", "chef", "salt",
        "vagrant", "packer",
        "cloudformation",

        # Мониторинг
        "grafana", "Grafana",
        "grafana/login", "grafana/dashboard",
        "prometheus", "prometheus/graph",
        "prometheus/targets", "prometheus/metrics",
        "kibana", "Kibana", "kibana/app",
        "elasticsearch", "elastic",
        "_search", "_cat", "_cluster",
        "_nodes", "_stats", "_mapping",
        "logstash", "filebeat",
        "zabbix", "Zabbix", "zabbix/login",
        "nagios", "Nagios", "nagios/cgi-bin",
        "cacti", "munin", "icinga",
        "datadog", "newrelic",
        "sentry", "sentry/login",
        "graylog", "splunk",
        "apm", "uptime", "uptimerobot",

        # Status
        "status", "Status",
        "health", "healthz", "healthcheck",
        "health-check", "health_check",
        "ready", "readyz", "readiness",
        "live", "livez", "liveness",
        "ping", "pong",
        "alive", "heartbeat",
        "version", "ver", "build-info",
        "info", "server-info", "server-status",
        "server-info.php",
        "metrics", "metrics/prometheus",
        "monitoring", "monitor",
        "stats", "statistics", "stat",
        "analytics", "Analytics",
        "telemetry",
        "logs", "log", "logging",
        "audit", "audit-log", "auditlog",

        # Service mesh
        "envoy", "istio", "linkerd",
        "consul", "consul/ui",
        "vault", "vault/ui",
        "nomad", "nomad/ui",
        "etcd", "zookeeper",
        "eureka", "hystrix",
    ]
    paths.extend(devops)

    # ══════════════════════════════════════
    #  10. БАЗЫ ДАННЫХ (~80)
    # ══════════════════════════════════════
    databases = [
        "db", "database", "databases",
        "mysql", "MySQL",
        "phpmyadmin", "phpMyAdmin", "pma", "PMA",
        "phpmyadmin2", "phpmyadmin3",
        "myadmin", "MyAdmin",
        "sqladmin", "SQLAdmin",
        "dbadmin", "db-admin", "db_admin",
        "adminer", "adminer.php",
        "postgres", "postgresql", "pgsql",
        "pgadmin", "pgAdmin", "pgadmin4",
        "mongo", "mongodb", "mongoadmin",
        "mongo-express",
        "redis", "redis-commander",
        "redisinsight",
        "memcached", "memcache",
        "couchdb", "couchbase",
        "cassandra", "neo4j",
        "influxdb", "clickhouse",
        "oracle", "mssql",
        "sql", "sqlite",
        "data", "dataset", "datasets",
        "sql.php", "db.php",
        "database.php", "dbconfig.php",
        "database.sql", "dump.sql", "data.sql",
        "db.sql", "mysql.sql", "backup.sql",
        "export.sql", "import.sql",
        "schema.sql", "tables.sql",
        "migration.sql", "seed.sql",
    ]
    paths.extend(databases)

    # ══════════════════════════════════════
    #  11. ПОЧТА И КОММУНИКАЦИИ (~50)
    # ══════════════════════════════════════
    mail = [
        "mail", "Mail", "email", "Email",
        "webmail", "Webmail", "webmail2",
        "smtp", "imap", "pop3",
        "postfix", "sendmail",
        "roundcube", "roundcubemail",
        "squirrelmail", "horde",
        "owa", "OWA",
        "exchange", "Exchange",
        "autodiscover", "Autodiscover",
        "autodiscover.xml",
        "EWS", "ews", "EWS/Exchange.asmx",
        "Microsoft-Server-ActiveSync",
        "mapi", "MAPI",
        "zimbra", "Zimbra",
        "mailman", "lists", "listserv",
        "newsletter", "newsletters",
        "subscribe", "unsubscribe",
        "mailinglist", "mailing-list",
        "postmaster", "abuse",
    ]
    paths.extend(mail)

    # ══════════════════════════════════════
    #  12. E-COMMERCE (~60)
    # ══════════════════════════════════════
    ecommerce = [
        "shop", "Shop", "store", "Store",
        "cart", "Cart", "shopping-cart",
        "basket", "bag",
        "checkout", "Checkout",
        "payment", "payments", "pay",
        "billing", "Billing",
        "invoice", "invoices",
        "order", "orders", "my-orders",
        "product", "products", "Products",
        "item", "items",
        "catalog", "catalogue", "Catalog",
        "collection", "collections",
        "pricing", "Pricing", "prices",
        "plans", "subscription", "subscriptions",
        "license", "licenses", "licence",
        "purchase", "buy",
        "refund", "return", "returns",
        "shipping", "delivery",
        "coupon", "coupons", "promo",
        "discount", "discounts", "deal", "deals",
        "wishlist", "favorites", "bookmarks",
        "gift", "gifts", "gift-card",
        "reward", "rewards", "points",
        "affiliate", "affiliates",
        "merchant", "seller", "vendor", "vendors",
        "marketplace",
    ]
    paths.extend(ecommerce)

    # ══════════════════════════════════════
    #  13. CMS-СПЕЦИФИЧНЫЕ (~100)
    # ══════════════════════════════════════
    cms = [
        # WordPress
        "wordpress", "WordPress", "wp",
        "wp-admin", "wp-admin/",
        "wp-admin/admin-ajax.php",
        "wp-admin/install.php",
        "wp-admin/setup-config.php",
        "wp-admin/upgrade.php",
        "wp-login.php", "wp-signup.php",
        "wp-register.php", "wp-cron.php",
        "wp-config.php", "wp-settings.php",
        "wp-mail.php", "wp-links-opml.php",
        "wp-trackback.php", "wp-comments-post.php",
        "wp-blog-header.php", "wp-load.php",
        "xmlrpc.php", "xmlrpc",
        "wp-json", "wp-json/wp/v2",
        "wp-json/wp/v2/users",
        "wp-json/wp/v2/posts",
        "wp-json/wp/v2/pages",
        "wp-content", "wp-content/",
        "wp-content/debug.log",
        "wp-content/uploads",
        "wp-content/themes",
        "wp-content/plugins",
        "wp-content/backup-db",
        "wp-content/backups",
        "wp-includes",

        # Joomla
        "joomla", "Joomla",
        "administrator", "administrator/",
        "administrator/index.php",
        "components", "modules", "plugins",
        "templates", "language",
        "configuration.php",
        "htaccess.txt",

        # Drupal
        "drupal", "Drupal",
        "core", "fastdirb", "fastdirb/default",
        "fastdirb/default/settings.php",
        "fastdirb/default/files",
        "misc", "profiles", "themes",
        "update.php", "install.php",
        "cron.php", "authorize.php",
        "CHANGELOG.txt", "INSTALL.txt",
        "LICENSE.txt", "MAINTAINERS.txt",
        "UPGRADE.txt", "web.config",

        # Magento
        "magento", "Magento",
        "magento/admin", "downloader",
        "app/etc/local.xml",
        "var/log", "var/report",
        "skin", "media/catalog",

        # Bitrix
        "bitrix", "Bitrix",
        "bitrix/admin",
        "bitrix/tools",
        "bitrix/modules",
        "bitrix/components",
        "bitrix/templates",
        "local", "local/templates",
        "upload",

        # Laravel
        "laravel", "storage",
        "storage/logs", "storage/logs/laravel.log",
        "storage/framework",
        "bootstrap", "bootstrap/cache",
        "artisan",

        # Django
        "django", "admin/login",
        "__debug__", "static/admin",
        "media",

        # Node.js / Express
        "node_modules", ".next",
        "server.js", "app.js",
        "nuxt", "_nuxt",
    ]
    paths.extend(cms)

    # ══════════════════════════════════════
    #  14. СЕТЕВЫЕ УСТРОЙСТВА (~60)
    # ══════════════════════════════════════
    network = [
        "console", "terminal", "shell",
        "cmd", "command", "cli",
        "ssh", "ftp", "sftp", "telnet",
        "vnc", "rdp", "remote",
        "remote-access", "remote-desktop",
        "proxy", "Proxy", "proxies",
        "gateway", "Gateway",
        "firewall", "Firewall",
        "router", "Router",
        "switch", "Switch",
        "vpn", "VPN",
        "openvpn", "OpenVPN",
        "wireguard", "WireGuard",
        "ipsec", "l2tp", "pptp",
        "tunnel", "sslvpn",
        "ssl-vpn", "remote-vpn",
        "anyconnect", "globalprotect",
        "fortinet", "fortigate",
        "paloalto", "checkpoint",
        "sophos", "watchguard",
        "mikrotik", "ubiquiti", "unifi",
        "meraki", "aruba",
        "wifi", "wireless", "wlan",
        "radius", "tacacs",
        "snmp", "nms",
        "network", "networking",
        "netstat", "ifconfig",
        "mrtg", "weathermap",
        "topology", "diagram",
    ]
    paths.extend(network)

    # ══════════════════════════════════════
    #  15. БЕЗОПАСНОСТЬ (~40)
    # ══════════════════════════════════════
    security = [
        "security", "Security",
        "secure", "Secure",
        "security.txt",
        ".well-known/security.txt",
        "csp-report", "csp-reports",
        "vulnerability", "vulnerabilities",
        "pentest", "security-audit",
        "waf", "WAF",
        "captcha", "recaptcha",
        "csrf", "xsrf",
        "ssl", "tls", "https",
        "certificate", "certificates",
        "encryption", "decrypt",
        "hash", "hashes",
        "firewall-rules",
        "blocked", "blacklist", "whitelist",
        "allowlist", "denylist",
        "ban", "banned", "block",
        "quarantine", "malware",
        "antivirus", "scan", "scanner",
        "ids", "ips", "siem",
        "forensics", "incident",
    ]
    paths.extend(security)

    # ══════════════════════════════════════
    #  16. УТИЛИТЫ И РАЗНОЕ (~80)
    # ══════════════════════════════════════
    misc = [
        "cgi-bin", "cgi", "cgi-bin/",
        "cgi-bin/test", "cgi-bin/test.cgi",
        "cgi-bin/printenv",
        "bin", "sbin",
        "scripts", "script",
        "include", "includes", "inc",
        "lib", "libs", "library",
        "vendor", "vendors",
        "third-party", "thirdparty",
        "node_modules", "bower_components",
        "packages", "modules", "module",
        "plugins", "plugin", "addons", "addon",
        "extensions", "ext", "extension",
        "components", "component",
        "widgets", "widget",
        "themes", "theme",
        "templates", "template", "tpl",
        "layouts", "layout",
        "views", "view",
        "partials", "partial",
        "shared", "common",
        "core", "framework",
        "src", "source", "sources",
        "app", "application", "apps",
        "services", "service",
        "handlers", "handler",
        "controllers", "controller",
        "models", "model",
        "middleware", "middlewares",
        "helpers", "helper",
        "utils", "utilities", "util",
        "tools", "Tools", "tool",
        "extras", "extra",
        "misc", "other",
        "examples", "example",
        "sample", "samples",
        "assets/vendor",
        "favicon.ico",
        "apple-touch-icon.png",
        "apple-touch-icon-precomposed.png",
    ]
    paths.extend(misc)

    # ══════════════════════════════════════
    #  17. ЧИСЛОВЫЕ И БУКВЕННЫЕ ПАТТЕРНЫ
    # ══════════════════════════════════════
    patterns = []

    # /0 ... /99
    for i in range(100):
        patterns.append(str(i))

    # /a ... /z
    for c in "abcdefghijklmnopqrstuvwxyz":
        patterns.append(c)

    # Общие паттерны
    patterns.extend([
        "aa", "bb", "cc", "dd", "ee", "ff",
        "aaa", "abc", "xyz", "test1", "test2",
        "tmp1", "tmp2", "new", "old",
        "null", "void", "none", "undefined",
        "true", "false",
    ])

    paths.extend(patterns)

    # ══════════════════════════════════════
    #  Дедупликация и сортировка
    # ══════════════════════════════════════
    unique = sorted(set(paths))
    return unique