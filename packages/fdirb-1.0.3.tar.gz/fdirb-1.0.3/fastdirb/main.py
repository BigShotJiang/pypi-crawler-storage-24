#!/usr/bin/env python3
"""
FastDirb - быстрый directory buster
Использование: python3 fastdirb.py example.com
"""

import asyncio
import aiohttp
import argparse
import time
import sys
from pathlib import Path

from fastdirb.wordlist import generate_default_wordlist


# ══════════════════════════════════════════
#  Цвета для терминала
# ══════════════════════════════════════════

class Colors:
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    RED = "\033[91m"
    CYAN = "\033[96m"
    GRAY = "\033[90m"
    BOLD = "\033[1m"
    RESET = "\033[0m"


# ══════════════════════════════════════════
#  Нормализация URL
# ══════════════════════════════════════════

def normalize_url(url: str) -> str:
    """
    yandex.ru       → https://yandex.ru
    http://site.com → http://site.com
    site.com:8080   → https://site.com:8080
    """
    url = url.strip().rstrip("/")
    if not url.startswith(("http://", "https://")):
        url = "https://" + url
    return url


# ══════════════════════════════════════════
#  Загрузка словаря
# ══════════════════════════════════════════

def load_wordlist(path: str = None) -> list:
    """Загружает словарь или генерирует встроенный"""
    if path is None:
        wordlist = generate_default_wordlist()
        print(f"{Colors.CYAN}[*] Встроенный словарь: {len(wordlist)} путей{Colors.RESET}")
        return wordlist

    wordlist_path = Path(path)
    if not wordlist_path.exists():
        print(f"{Colors.YELLOW}[!] {path} не найден — встроенный словарь{Colors.RESET}")
        return generate_default_wordlist()

    with open(wordlist_path, "r", encoding="utf-8", errors="ignore") as f:
        words = [line.strip() for line in f if line.strip() and not line.startswith("#")]

    print(f"{Colors.CYAN}[*] Загружено {len(words)} слов из {path}{Colors.RESET}")
    return words


# ══════════════════════════════════════════
#  Основной сканер
# ══════════════════════════════════════════

class FastDirb:
    def __init__(self, base_url: str, wordlist: list,
                 threads: int = 100,
                 timeout: int = 10,
                 extensions: list = None,
                 show_codes: list = None,
                 hide_codes: list = None,
                 follow_redirects: bool = False,
                 user_agent: str = None):

        self.base_url = base_url
        self.wordlist = wordlist
        self.threads = threads
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self.extensions = extensions or [""]
        self.show_codes = show_codes
        self.hide_codes = hide_codes or [404]
        self.follow_redirects = follow_redirects
        self.user_agent = user_agent or "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"

        self.found = []
        self.scanned = 0
        self.errors = 0
        self.total = 0
        self.lock = asyncio.Lock()

    def _color_status(self, code: int) -> str:
        """Раскраска по статус-коду"""
        if 200 <= code < 300:
            return Colors.GREEN
        elif 300 <= code < 400:
            return Colors.YELLOW
        elif code == 403:
            return Colors.RED
        else:
            return Colors.GRAY

    def _generate_urls(self) -> list:
        """Генерирует все URL для проверки"""
        urls = []
        for word in self.wordlist:
            for ext in self.extensions:
                if ext and not ext.startswith("."):
                    ext = "." + ext
                path = f"/{word}{ext}"
                urls.append(f"{self.base_url}{path}")
        return urls

    async def _check_url(self, session: aiohttp.ClientSession, url: str, semaphore: asyncio.Semaphore):
        """Проверяет один URL"""
        async with semaphore:
            try:
                async with session.get(
                    url,
                    allow_redirects=self.follow_redirects,
                    ssl=False
                ) as response:
                    status = response.status
                    length = response.content_length or 0

                    # Фильтрация по статус-кодам
                    show = True
                    if self.show_codes:
                        show = status in self.show_codes
                    elif self.hide_codes:
                        show = status not in self.hide_codes

                    if show:
                        color = self._color_status(status)
                        path = url.replace(self.base_url, "")
                        result = {
                            "url": url,
                            "status": status,
                            "length": length
                        }

                        async with self.lock:
                            self.found.append(result)
                            print(
                                f"  {color}[{status}]{Colors.RESET} "
                                f"{path:<50} "
                                f"{Colors.GRAY}[{length} bytes]{Colors.RESET}"
                            )

            except (aiohttp.ClientError, asyncio.TimeoutError):
                async with self.lock:
                    self.errors += 1
            finally:
                async with self.lock:
                    self.scanned += 1
                    # Прогресс каждые 500 запросов
                    if self.scanned % 500 == 0:
                        pct = (self.scanned / self.total) * 100
                        print(
                            f"{Colors.GRAY}  ... {self.scanned}/{self.total} "
                            f"({pct:.1f}%) "
                            f"ошибок: {self.errors}{Colors.RESET}",
                            end="\r"
                        )

    async def run(self):
        """Запуск сканирования"""
        urls = self._generate_urls()
        self.total = len(urls)

        print(f"\n{Colors.BOLD}{'=' * 60}")
        print(f"  FastDirb Scanner")
        print(f"{'=' * 60}{Colors.RESET}")
        print(f"  {Colors.CYAN}Цель:{Colors.RESET}       {self.base_url}")
        print(f"  {Colors.CYAN}Слов:{Colors.RESET}       {len(self.wordlist)}")
        print(f"  {Colors.CYAN}Расширения:{Colors.RESET} {self.extensions}")
        print(f"  {Colors.CYAN}Потоков:{Colors.RESET}    {self.threads}")
        print(f"  {Colors.CYAN}Всего URL:{Colors.RESET}  {self.total}")
        print(f"{Colors.BOLD}{'=' * 60}{Colors.RESET}\n")

        semaphore = asyncio.Semaphore(self.threads)
        connector = aiohttp.TCPConnector(limit=self.threads, ssl=False)
        headers = {"User-Agent": self.user_agent}

        async with aiohttp.ClientSession(
            connector=connector,
            timeout=self.timeout,
            headers=headers
        ) as session:

            tasks = [
                self._check_url(session, url, semaphore)
                for url in urls
            ]
            await asyncio.gather(*tasks)

    def print_summary(self, elapsed: float):
        """Итоги сканирования"""
        print(f"\n{Colors.BOLD}{'=' * 60}")
        print(f"  Результаты")
        print(f"{'=' * 60}{Colors.RESET}")
        print(f"  Просканировано: {self.scanned}")
        print(f"  Найдено:        {Colors.GREEN}{len(self.found)}{Colors.RESET}")
        print(f"  Ошибки:         {self.errors}")
        print(f"  Время:          {elapsed:.2f} сек")
        print(f"  Скорость:       {self.scanned / elapsed:.0f} req/sec")
        print(f"{Colors.BOLD}{'=' * 60}{Colors.RESET}")

        if self.found:
            print(f"\n  {Colors.GREEN}Найденные пути:{Colors.RESET}")
            for item in sorted(self.found, key=lambda x: x["status"]):
                color = self._color_status(item["status"])
                path = item["url"].replace(self.base_url, "")
                print(f"    {color}[{item['status']}]{Colors.RESET} {path}")


# ══════════════════════════════════════════
#  Аргументы командной строки
# ══════════════════════════════════════════

def parse_args():
    parser = argparse.ArgumentParser(
        description="FastDirb — быстрый directory buster",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Примеры:
  fdirb example.com
  fdirb example.com -w big.txt
  fdirb example.com -x php,html,txt
  fdirb -x php example.com
  fdirb -t 200 -x php example.com
  fdirb -o results.txt -x php,html example.com
        """
    )

    parser.add_argument(
        "-w", "--wordlist",
        default=None,
        help="Путь к словарю (без указания — встроенный)"
    )
    parser.add_argument(
        "-x", "--extensions",
        default="",
        help="Расширения через запятую: php,html,txt"
    )
    parser.add_argument(
        "-t", "--threads",
        type=int,
        default=100,
        help="Количество потоков (по умолчанию: 100)"
    )
    parser.add_argument(
        "--timeout",
        type=int,
        default=10,
        help="Таймаут запроса в секундах (по умолчанию: 10)"
    )
    parser.add_argument(
        "-sc", "--show-codes",
        default=None,
        help="Показывать только эти коды: 200,301,403"
    )
    parser.add_argument(
        "-hc", "--hide-codes",
        default="404",
        help="Скрывать эти коды (по умолчанию: 404)"
    )
    parser.add_argument(
        "-L", "--follow-redirects",
        action="store_true",
        help="Следовать за редиректами"
    )
    parser.add_argument(
        "-a", "--user-agent",
        default=None,
        help="Кастомный User-Agent"
    )
    parser.add_argument(
        "-o", "--output",
        default=None,
        help="Сохранить результаты в файл"
    )

    # Парсим известные аргументы, остальное в extra
    args, extra = parser.parse_known_args()

    # URL берём из оставшихся аргументов
    if not extra:
        parser.print_help()
        print("\n\033[91mОшибка: укажите URL цели\033[0m")
        print("Пример: fdirb example.com")
        print("        fdirb -x php example.com")
        sys.exit(1)

    args.url = extra[0]

    # Если осталось больше одного — предупредим
    if len(extra) > 1:
        print(f"\033[93mПредупреждение: лишние аргументы игнорируются: {extra[1:]}\033[0m")

    return args


# ══════════════════════════════════════════
#  Сохранение результатов
# ══════════════════════════════════════════

def save_results(scanner: FastDirb, output_path: str):
    with open(output_path, "w") as f:
        for item in sorted(scanner.found, key=lambda x: x["status"]):
            f.write(f"[{item['status']}] {item['url']} [{item['length']} bytes]\n")
    print(f"\n{Colors.CYAN}[*] Результаты сохранены в {output_path}{Colors.RESET}")


# ══════════════════════════════════════════
#  Точка входа
# ══════════════════════════════════════════

def main():
    args = parse_args()

    url = normalize_url(args.url)
    wordlist = load_wordlist(args.wordlist)

    # Парсинг расширений
    extensions = [""]
    if args.extensions:
        extensions += [e.strip() for e in args.extensions.split(",")]

    # Парсинг статус-кодов
    show_codes = None
    if args.show_codes:
        show_codes = [int(c) for c in args.show_codes.split(",")]

    hide_codes = [404]
    if args.hide_codes:
        hide_codes = [int(c) for c in args.hide_codes.split(",")]

    scanner = FastDirb(
        base_url=url,
        wordlist=wordlist,
        threads=args.threads,
        timeout=args.timeout,
        extensions=extensions,
        show_codes=show_codes,
        hide_codes=hide_codes,
        follow_redirects=args.follow_redirects,
        user_agent=args.user_agent,
    )

    start = time.time()

    try:
        asyncio.run(scanner.run())
    except KeyboardInterrupt:
        print(f"\n{Colors.YELLOW}[!] Прервано пользователем{Colors.RESET}")

    elapsed = time.time() - start
    scanner.print_summary(elapsed)

    if args.output:
        save_results(scanner, args.output)

if __name__ == "__main__":
    main()