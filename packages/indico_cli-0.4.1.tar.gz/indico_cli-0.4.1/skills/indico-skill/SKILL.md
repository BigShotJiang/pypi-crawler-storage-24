---
name: indico-skill
description: Interact with Indico event management systems via the indico-cli tool. Use this skill for ANY Indico-related task including searching events, browsing categories, creating events/sessions/contributions, managing timetables, downloading files, checking user info, or configuring credentials. Triggers on any mention of Indico, CERN events, conferences, meetings, agendas, timetables, contributions, or talks in the context of event management.
allowed-tools: Bash
user-invocable: true
---

# Indico CLI Skill

Complete reference for managing Indico events via the `indico-cli` tool. All commands are run with `uvx indico-cli <command>`.

## Prerequisites

The CLI must be configured with a base URL and API token. Run `uvx indico-cli user-info` to check. If it fails, follow the **Configure** section below to set up credentials.

---

## Configure

Set up or update Indico CLI credentials.

### Steps

1. **Check if already configured**: run `uvx indico-cli user-info 2>&1`. If it returns user info, stop — already configured.
2. **Ask the user** which Indico instance to connect to (e.g., `https://indico.cern.ch`, `https://indico.fnal.gov`, or a custom URL).
3. **Guide token creation**: tell the user to open `<base_url>/user/tokens/`, click "Create new token", name it (e.g., "indico-cli"), select all scopes (you can avoid write in case want to play on the safe side), click "Create", and copy the `indp_...` token immediately (shown only once).
4. **Save credentials**:

   ```bash
   uvx indico-cli configure --base-url <BASE_URL> --token <TOKEN>
   ```

   Saves to `~/.config/indico-cli/config.json` (never inside a repo).
5. **Verify**: the configure command tests the connection automatically. On failure: 403/401 = wrong scopes or expired token; connection error = wrong URL; SSL error = network issue.

Environment variables `INDICO_BASE_URL` and `INDICO_API_TOKEN` override the config file.

---

## Working with Results

### When things go wrong

If an event returns "not found" or "deleted", don't stop — use `search-by-term` with relevant keywords from the original request to find similar content elsewhere. Follow through: download files, read them, and answer the user's question.

### Chaining commands for deeper answers

Many tasks require chaining multiple commands. For example, to find out what someone concluded in a talk:

1. `search-by-term` or `contributions` to find the relevant contribution
2. `files` or `download` to get the slides/PDF
3. **Read the downloaded file** and extract the answer

The goal is to answer the user's question, not just list metadata. If slides were downloaded, read them and summarize the relevant content.

### Using event IDs from search results

`search-by-term` returns `Event ID` for every contribution, attachment, and note result. Use this ID to drill into the event:

1. `search-by-term --term "my topic"` — find the contribution and note its Event ID
2. `event-details --event-id <ID>` — get full event info
3. `contributions --event-id <ID>` — list all contributions
4. `files --event-id <ID>` — download materials

### Known limitations

- `search-events` displays at most 10 events. For categories with more events, use date-range filtering (`--from-date` / `--to-date`) to page through results in batches.
- When downloading files from multiple events, use `--download-dir` with a unique directory per event to avoid duplicates and keep things organized.
- Never modify the indico-cli source code. Work only through the CLI commands listed below.

---

## Search Commands

### search-by-term — Full-text search across all Indico content

```bash
uvx indico-cli search-by-term --term "<query>" [--limit N] [--type TYPE]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--term` | Yes | Search keyword or phrase |
| `--limit` | No | Max results per content type (default: 50) |
| `--type` | No | Filter to one content type: `event`, `contribution`, `subcontribution`, `attachment`, `event_note`, `category` |

Searches categories, events, contributions, subcontributions, attachments, and notes.

### search-events — Search events in a category by date

```bash
uvx indico-cli search-events --category-id <ID> [--from-date YYYY-MM-DD] [--to-date YYYY-MM-DD] [--limit N] [--only-public]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--category-id` | Yes | Category ID to search in |
| `--from-date` | No | Start date filter |
| `--to-date` | No | End date filter |
| `--limit` | No | Max results |
| `--only-public` | No | Only show public events |

### search-categories — Browse category tree

```bash
uvx indico-cli search-categories [--category-id ID] [--limit N]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--category-id` | No | Category to explore (default: root "0") |
| `--limit` | No | Max results |

---

## Retrieve Commands

### event-details — Get event information

```bash
uvx indico-cli event-details --event-id <ID> [--contributions] [--sessions]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | Event ID |
| `--contributions` | No | Include contributions/talks |
| `--sessions` | No | Include session details |

### contributions — List event contributions

```bash
uvx indico-cli contributions --event-id <ID> [--subcontributions] [--limit N]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | Event ID |
| `--subcontributions` | No | Include subcontributions |
| `--limit` | No | Max contributions to display |

### user-info — Check authenticated user

```bash
uvx indico-cli user-info
```

No parameters. Returns name, email, user ID, and admin status.

### files — List and download event files

```bash
uvx indico-cli files --event-id <ID> [--download | --no-download] [--download-dir PATH]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | Event ID |
| `--download/--no-download` | No | Download files (default: download) |
| `--download-dir` | No | Directory for downloads |

If the built-in download fails (403), list with `--no-download` to get URLs, then use curl:

```bash
curl -L -H "Authorization: Bearer $INDICO_API_TOKEN" -o filename.pdf "DOWNLOAD_URL"
```

### download — Download a single attachment

```bash
uvx indico-cli download --url "<download-url>" [--filename NAME]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--url` | Yes | Download URL of the attachment |
| `--filename` | No | Custom filename |

---

## Create Commands

All create commands require management/write permissions on the target event or category.

### create-event — Create a new event

```bash
uvx indico-cli create-event --title "Title" --category-id <ID> --type <lecture|meeting|conference> [--start ISO] [--end ISO] [--timezone TZ] [--description TEXT] [--location TEXT] [--room TEXT] [--speakers JSON]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--title` | Yes | Event title |
| `--category-id` | Yes | Category ID |
| `--type` | Yes | `lecture`, `meeting`, or `conference` |
| `--start` | No | Start datetime (ISO format) |
| `--end` | No | End datetime (ISO format) |
| `--timezone` | No | e.g., Europe/Zurich |
| `--description` | No | Event description |
| `--location` | No | Venue name |
| `--room` | No | Room name |
| `--speakers` | No | JSON array of speakers (see Common Formats) |

### create-event-with-agenda — Create event with full agenda

```bash
uvx indico-cli create-event-with-agenda --title "Title" --category-id <ID> --type <lecture|meeting|conference> --start <ISO> --end <ISO> [--timezone TZ] [--description TEXT] [--location TEXT] [--room TEXT] [--speakers JSON] --agenda-file <path>
```

Same parameters as `create-event` plus:

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--agenda-file` | Yes | Path to agenda JSON file (see Common Formats) |

### create-session — Add a session to an event

```bash
uvx indico-cli create-session --event-id <ID> --title "Title" [--description TEXT]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | Event ID |
| `--title` | Yes | Session title |
| `--description` | No | Session description |

### create-contribution — Add a talk/presentation

```bash
uvx indico-cli create-contribution --event-id <ID> --title "Title" [--description TEXT] [--duration N] [--speakers JSON] [--session-id ID]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | Event ID |
| `--title` | Yes | Contribution title |
| `--description` | No | Description |
| `--duration` | No | Duration in minutes (default: 20) |
| `--speakers` | No | JSON array of speakers (see Common Formats) |
| `--session-id` | No | Assign to a session |

---

## Timetable Commands

Require management permissions on the event.

### add-timetable-entry — Schedule an item

```bash
uvx indico-cli add-timetable-entry --event-id <ID> --type <session_block|contribution> --object-id <ID> --start <ISO> [--duration N]
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | Event ID |
| `--type` | Yes | `session_block` or `contribution` |
| `--object-id` | Yes | ID of session or contribution |
| `--start` | Yes | Start datetime (ISO format) |
| `--duration` | No | Duration in minutes |

### delete-timetable-entry — Remove a scheduled item

```bash
uvx indico-cli delete-timetable-entry --event-id <ID> --entry-id <ID>
```

| Parameter | Required | Description |
|-----------|----------|-------------|
| `--event-id` | Yes | Event ID |
| `--entry-id` | Yes | Timetable entry ID to remove |

---

## Common Formats

### Speaker JSON

Used by `create-event`, `create-event-with-agenda`, and `create-contribution`:

```json
[{"first_name": "John", "last_name": "Doe", "email": "john@example.com", "affiliation": "CERN"}]
```

Only `first_name` and `last_name` are required. `email` and `affiliation` are optional.

### Agenda File JSON

Used by `create-event-with-agenda`. A JSON array where items with a `contributions` key become sessions, items without become standalone contributions:

```json
[
  {
    "title": "Opening Session",
    "contributions": [
      {"title": "Welcome", "duration_minutes": 10, "speakers": [{"first_name": "Jane", "last_name": "Doe"}]},
      {"title": "Overview", "duration_minutes": 20}
    ]
  },
  {
    "title": "Coffee Break",
    "duration_minutes": 30
  },
  {
    "title": "Keynote Talk",
    "duration_minutes": 60,
    "speakers": [{"first_name": "John", "last_name": "Smith", "affiliation": "CERN"}]
  }
]
```

---

## Examples

Search for beam dynamics content:

```bash
uvx indico-cli search-by-term --term "beam dynamics" --limit 5
```

Create a meeting with agenda:

```bash
uvx indico-cli create-event-with-agenda \
  --title "Workshop on ML" \
  --category-id 4648 \
  --type meeting \
  --start 2025-06-15T09:00:00 \
  --end 2025-06-15T17:00:00 \
  --timezone Europe/Zurich \
  --location CERN \
  --agenda-file agenda.json
```

Download all files from an event:

```bash
uvx indico-cli files --event-id 137346
```

Schedule a contribution:

```bash
uvx indico-cli add-timetable-entry --event-id 137346 --type contribution --object-id 12 --start 2025-06-15T14:00:00 --duration 30
```
