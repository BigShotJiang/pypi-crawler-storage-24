# CLI

Yoro includes a command-line interface for quick encoding/decoding.

## Commands

### `yoro encode`

```bash
yoro encode <lat> <lon> [--domain CI] [--precision 12]
```

**Example:**

```bash
$ yoro encode 5.345 -4.028 --domain CI
{
  "code": "CI-PV9XD",
  "lat": 5.34519287,
  "lon": -4.02868774,
  "precision": 12,
  "resolution_m": 172.9,
  "bounds": { ... }
}
```

### `yoro decode`

```bash
yoro decode <code>
```

**Example:**

```bash
$ yoro decode CI-PV9XD
{
  "code": "CI-PV9XD",
  "lat": 5.34519287,
  "lon": -4.02868774,
  "precision": 12,
  "domain": "CI",
  "resolution_m": 172.9,
  "bounds": { ... },
  "neighbors": ["CI-PV9XK", "CI-PV9XJ", ...]
}
```

### `yoro precisions`

```bash
yoro precisions [--domain CI] [--max-length 10]
```

**Example:**

```bash
$ yoro precisions --domain CI
   p  k (chars)          grid     total cells    resolution
---------------------------------------------------------
   2          1           4x4              16   177045.00 m
   4          2         16x16             256    44261.25 m
   7          3       128x128          16,384     5532.66 m
   9          4       512x512         262,144     1383.16 m
  12          5     4096x4096      16,777,216      172.90 m
  14          6   16384x16384     268,435,456       43.22 m
  17          7  131072x131072  17,179,869,184        5.40 m
  19          8  524288x524288  274,877,906,944        1.35 m
  21          9  2097152x2097152  4,398,046,511,104        0.34 m
  24         10  16777216x16777216  281,474,976,710,656        0.04 m
```

### `yoro serve`

```bash
yoro serve [--host 0.0.0.0] [--port 8000]
```

Starts the FastAPI server. Requires `pip install yoro[fastapi]`.

### `yoro --version`

```bash
$ yoro --version
yoro 0.1.0
```
