# Installation

## Requirements

- Python 3.10+
- No other dependencies for the core library

## Core only

```bash
pip install yoro
```

This gives you `encode`, `decode`, `neighbors`, `resolution`, `precision_levels` — everything needed to work with Yoro codes. No external dependencies.

## With Django

```bash
pip install yoro[django]
```

Requires Django ≥ 4.2 with GeoDjango (PostGIS or SpatiaLite). Provides:

- `GeoAltiusCode` model (stores codes with geometry)
- `assign_altius_code()` service (auto-assigns codes to model instances)
- Django views for encode/decode/precisions/domains API
- Admin integration

## With FastAPI

```bash
pip install yoro[fastapi]
```

Provides a ready-to-run HTTP API server:

```bash
yoro serve --port 8000
```

Or embed in your own FastAPI app:

```python
from yoro.fastapi import create_app
app = create_app(prefix="/api/v1/geo")
```

## Everything

```bash
pip install yoro[all]
```

## Development

```bash
git clone https://github.com/Altius-Academy-SNC/yoro.git
cd yoro
python -m venv .venv && source .venv/bin/activate
pip install -e ".[dev,fastapi]"
pytest
```
