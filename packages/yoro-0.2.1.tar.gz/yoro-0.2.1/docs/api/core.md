# Core API Reference

::: yoro.codec
    options:
      members:
        - encode
        - decode
        - neighbors
        - resolution
        - get_bounds
        - cells_in_bounds
        - precision_levels
        - snap_precision
        - domain_for_country
      show_root_heading: false
