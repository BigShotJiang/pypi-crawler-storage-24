# FastAPI API Reference

## App Factory

::: yoro.fastapi.app.create_app
    options:
      show_root_heading: true

## Pydantic Schemas

::: yoro.fastapi.app.BoundsSchema
    options:
      show_root_heading: true

::: yoro.fastapi.app.EncodeResponse
    options:
      show_root_heading: true

::: yoro.fastapi.app.DecodeResponse
    options:
      show_root_heading: true

::: yoro.fastapi.app.PrecisionLevelSchema
    options:
      show_root_heading: true

::: yoro.fastapi.app.PrecisionsResponse
    options:
      show_root_heading: true
