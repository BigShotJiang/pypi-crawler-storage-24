# Yoro

**[Documentation](https://altius-academy-snc.github.io/yoro/)** | **[PyPI](https://pypi.org/project/yoro/)** | **[GitHub](https://github.com/Altius-Academy-SNC/yoro)**

Geographic addressing via Hilbert curves — GPS ↔ compact alphanumeric codes.

*"Yoro" means "place" in Manding (West Africa).*

## Install

```bash
pip install yoro              # core only
pip install yoro[django]      # Django/GeoDjango integration
pip install yoro[fastapi]     # FastAPI server
pip install yoro[all]         # everything
```

## Quick start

```python
import yoro

code = yoro.encode(6.8, -5.3, domain="CI")   # "CI-..."
result = yoro.decode(code)                     # {"lat", "lon", "bounds", ...}
nbrs = yoro.neighbors(code)                    # 8 adjacent cells
```

## Django integration

```python
# settings.py
INSTALLED_APPS = [..., "yoro.django"]

# urls.py
urlpatterns = [
    path("api/v1/yoro/", include("yoro.django.urls")),
]
```

## FastAPI server

```bash
yoro serve --port 8000
# or
python -m yoro.fastapi
```

## CLI

```bash
yoro encode 6.8 -5.3 --domain CI
yoro decode CI-4H7A3B
```

## License

MIT — Paul Guindo / Altius Academy SNC.
