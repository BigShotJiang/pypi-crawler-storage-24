"""Run the Yoro FastAPI server: ``python -m yoro.fastapi``."""

import uvicorn

from yoro.fastapi import create_app

app = create_app()

if __name__ == "__main__":
    uvicorn.run("yoro.fastapi.__main__:app", host="0.0.0.0", port=8000, reload=True)
