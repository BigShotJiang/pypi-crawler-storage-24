"""
Yoro FastAPI integration.

Usage::

    from yoro.fastapi import create_app

    app = create_app()

Or run directly::

    python -m yoro.fastapi
    yoro serve --port 8000
"""

from yoro.fastapi.app import create_app

__all__ = ["create_app"]
