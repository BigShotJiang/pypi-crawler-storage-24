"""
Yoro — Geographic addressing via Hilbert curves.

GPS ↔ compact alphanumeric codes (e.g. ``CI-4H7A3B``).

Basic usage::

    import yoro

    code = yoro.encode(6.8, -5.3, domain="CI")
    result = yoro.decode(code)
    nbrs = yoro.neighbors(code)

Theory: Paul Guindo, Altius Academy SNC.
"""

from yoro.codec import (
    cells_in_bounds,
    decode,
    domain_for_country,
    encode,
    get_bounds,
    neighbors,
    precision_levels,
    resolution,
    snap_precision,
)
from yoro.constants import DOMAINS
from yoro.types import Bounds, DecodeResult, DomainInfo, EncodeResult, PrecisionLevel

__version__ = "0.2.1"

__all__ = [
    # Core functions
    "encode",
    "decode",
    "neighbors",
    "resolution",
    "get_bounds",
    "cells_in_bounds",
    "domain_for_country",
    "precision_levels",
    "snap_precision",
    # Data
    "DOMAINS",
    # Types
    "Bounds",
    "EncodeResult",
    "DecodeResult",
    "DomainInfo",
    "PrecisionLevel",
    # Meta
    "__version__",
]
