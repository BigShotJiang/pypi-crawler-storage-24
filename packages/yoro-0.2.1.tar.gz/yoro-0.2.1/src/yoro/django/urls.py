from django.urls import path

from yoro.django import views

app_name = "yoro"

urlpatterns = [
    path("encode/", views.encode_view, name="encode"),
    path("decode/", views.decode_view, name="decode"),
    path("precisions/", views.precisions_view, name="precisions"),
    path("domains/", views.domains_view, name="domains"),
]
