"""
Yoro Django integration.

Add ``"yoro.django"`` to ``INSTALLED_APPS``::

    # settings.py
    INSTALLED_APPS = [
        ...
        "yoro.django",
    ]

Model field with map widget::

    from yoro.django.fields import YoroField

    class Shop(models.Model):
        name = models.CharField(max_length=100)
        address = YoroField(domain="CI", precision=12)

API endpoints::

    # urls.py
    from django.urls import include, path
    urlpatterns = [
        path("api/v1/yoro/", include("yoro.django.urls")),
    ]
"""

default_app_config = "yoro.django.apps.AltiusCodeConfig"
