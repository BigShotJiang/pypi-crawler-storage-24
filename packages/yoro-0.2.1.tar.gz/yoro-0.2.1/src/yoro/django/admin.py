from django.contrib.gis import admin

from yoro.django.models import GeoAltiusCode


@admin.register(GeoAltiusCode)
class GeoAltiusCodeAdmin(admin.GISModelAdmin):
    list_display = ("code", "domain", "precision", "resolution_m", "created_at")
    list_filter = ("domain",)
    search_fields = ("code", "label")
    readonly_fields = ("created_at",)
