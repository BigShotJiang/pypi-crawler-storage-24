from django.contrib.gis.db import models as gis_models
from django.db import models
from django.utils.translation import gettext_lazy as _


class GeoAltiusCode(models.Model):
    """Persisted Yoro geographic address."""

    code = models.CharField(_("Altius code"), max_length=20, unique=True, db_index=True)
    domain = models.CharField(_("domain (ISO)"), max_length=5)
    location = gis_models.PointField(_("GPS point"), srid=4326)
    cell = gis_models.PolygonField(_("Hilbert cell"), srid=4326)
    precision = models.PositiveSmallIntegerField(_("precision (order p)"))
    resolution_m = models.FloatField(_("resolution (meters)"))
    label = models.CharField(_("label"), max_length=255, blank=True, default="")
    created_at = models.DateTimeField(_("created at"), auto_now_add=True)

    class Meta:
        verbose_name = _("Yoro address")
        verbose_name_plural = _("Yoro addresses")
        ordering = ["-created_at"]

    def __str__(self) -> str:
        return self.code
