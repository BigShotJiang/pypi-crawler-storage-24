import django.contrib.gis.db.models.fields
from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = []

    operations = [
        migrations.CreateModel(
            name="GeoAltiusCode",
            fields=[
                (
                    "id",
                    models.BigAutoField(
                        auto_created=True,
                        primary_key=True,
                        serialize=False,
                        verbose_name="ID",
                    ),
                ),
                (
                    "code",
                    models.CharField(
                        db_index=True,
                        max_length=20,
                        unique=True,
                        verbose_name="Altius code",
                    ),
                ),
                (
                    "domain",
                    models.CharField(max_length=5, verbose_name="domain (ISO)"),
                ),
                (
                    "location",
                    django.contrib.gis.db.models.fields.PointField(
                        srid=4326, verbose_name="GPS point"
                    ),
                ),
                (
                    "cell",
                    django.contrib.gis.db.models.fields.PolygonField(
                        srid=4326, verbose_name="Hilbert cell"
                    ),
                ),
                (
                    "precision",
                    models.PositiveSmallIntegerField(
                        verbose_name="precision (order p)"
                    ),
                ),
                (
                    "resolution_m",
                    models.FloatField(verbose_name="resolution (meters)"),
                ),
                (
                    "label",
                    models.CharField(
                        blank=True,
                        default="",
                        max_length=255,
                        verbose_name="label",
                    ),
                ),
                (
                    "created_at",
                    models.DateTimeField(
                        auto_now_add=True, verbose_name="created at"
                    ),
                ),
            ],
            options={
                "verbose_name": "Yoro address",
                "verbose_name_plural": "Yoro addresses",
                "ordering": ["-created_at"],
            },
        ),
    ]
