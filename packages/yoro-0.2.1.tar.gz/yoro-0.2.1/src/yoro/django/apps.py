from django.apps import AppConfig


class AltiusCodeConfig(AppConfig):
    name = "yoro.django"
    label = "yoro"
    verbose_name = "Yoro"
    default_auto_field = "django.db.models.BigAutoField"
