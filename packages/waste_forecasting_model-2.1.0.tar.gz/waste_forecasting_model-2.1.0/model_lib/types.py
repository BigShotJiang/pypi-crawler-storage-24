"""
Typed contracts for WastePredictor inputs and outputs.
Import these in any consumer: FL clients, API routes, tests, event handlers.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional


# ── Input ──────────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class PredictionInput:
    """
    Validated input for a single prediction (V2 model).

    Example
    -------
    >>> inp = PredictionInput(
    ...     production_volume=50_000,
    ...     production_capacity=60_000,
    ...     rain_sum=200.0,
    ...     temperature_mean=28.0,
    ...     humidity_mean=85.0,
    ...     wind_speed_mean=15.0,
    ...     month=6,
    ... )
    """
    production_volume: float
    production_capacity: float
    rain_sum: float
    temperature_mean: float
    humidity_mean: float
    wind_speed_mean: float
    month: int = 6
    year: int = 2026

    def __post_init__(self) -> None:
        if not (1 <= self.month <= 12):
            raise ValueError(f"month must be 1-12, got {self.month}")
        if self.production_volume < 0:
            raise ValueError("production_volume must be >= 0")
        if self.production_capacity < 0:
            raise ValueError("production_capacity must be >= 0")
        if not (0 <= self.humidity_mean <= 100):
            raise ValueError("humidity_mean must be 0-100")

    def to_dict(self) -> Dict[str, float]:
        return {
            "production_volume": self.production_volume,
            "production_capacity": self.production_capacity,
            "rain_sum": self.rain_sum,
            "temperature_mean": self.temperature_mean,
            "humidity_mean": self.humidity_mean,
            "wind_speed_mean": self.wind_speed_mean,
            "month": float(self.month),
            "year": float(self.year),
        }


# ── Output ─────────────────────────────────────────────────────────────────

OUTPUT_COLUMNS: List[str] = [
    "Total_Waste_kg",
    "Solid_Waste_Gypsum_kg",
    "Solid_Waste_Limestone_kg",
    "Solid_Waste_Industrial_Salt_kg",
    "Total_Solid_Waste_kg",
    "Liquid_Waste_Bittern_Liters",
    "Bittern_Mg_Concentration_gL",
    "Bittern_K_Concentration_gL",
    "Bittern_SO4_Concentration_gL",
    "Bittern_Ca_Concentration_gL",
    "Bittern_Magnesium_kg",
    "Bittern_Potassium_kg",
    "Bittern_Sulfate_kg",
    "Bittern_Calcium_kg",
]

INPUT_COLUMNS: List[str] = [
    "production_volume",
    "production_capacity",
    "rain_sum",
    "temperature_mean",
    "humidity_mean",
    "wind_speed_mean",
    "Month",  # capital-M, as expected by AdvancedFeatureEngineer
    "Year",   # capital-Y
]


@dataclass
class PredictionResult:
    """
    Strongly-typed wrapper for model output (V2 model - 14 outputs).

    Access fields directly or call `.to_dict()` for JSON serialisation.
    """
    total_waste_kg: float
    solid_waste_gypsum_kg: float
    solid_waste_limestone_kg: float
    solid_waste_industrial_salt_kg: float
    total_solid_waste_kg: float
    liquid_waste_bittern_liters: float
    bittern_mg_concentration_gl: float
    bittern_k_concentration_gl: float
    bittern_so4_concentration_gl: float
    bittern_ca_concentration_gl: float
    bittern_magnesium_kg: float
    bittern_potassium_kg: float
    bittern_sulfate_kg: float
    bittern_calcium_kg: float
    model_version: str = "unknown"
    confidence: Optional[float] = None

    @classmethod
    def from_dict(cls, d: Dict[str, float], model_version: str = "unknown") -> "PredictionResult":
        return cls(
            total_waste_kg=d["Total_Waste_kg"],
            solid_waste_gypsum_kg=d["Solid_Waste_Gypsum_kg"],
            solid_waste_limestone_kg=d["Solid_Waste_Limestone_kg"],
            solid_waste_industrial_salt_kg=d["Solid_Waste_Industrial_Salt_kg"],
            total_solid_waste_kg=d["Total_Solid_Waste_kg"],
            liquid_waste_bittern_liters=d["Liquid_Waste_Bittern_Liters"],
            bittern_mg_concentration_gl=d["Bittern_Mg_Concentration_gL"],
            bittern_k_concentration_gl=d["Bittern_K_Concentration_gL"],
            bittern_so4_concentration_gl=d["Bittern_SO4_Concentration_gL"],
            bittern_ca_concentration_gl=d["Bittern_Ca_Concentration_gL"],
            bittern_magnesium_kg=d["Bittern_Magnesium_kg"],
            bittern_potassium_kg=d["Bittern_Potassium_kg"],
            bittern_sulfate_kg=d["Bittern_Sulfate_kg"],
            bittern_calcium_kg=d["Bittern_Calcium_kg"],
            model_version=model_version,
        )

    def to_dict(self) -> Dict[str, float]:
        return {
            "Total_Waste_kg": self.total_waste_kg,
            "Solid_Waste_Gypsum_kg": self.solid_waste_gypsum_kg,
            "Solid_Waste_Limestone_kg": self.solid_waste_limestone_kg,
            "Solid_Waste_Industrial_Salt_kg": self.solid_waste_industrial_salt_kg,
            "Total_Solid_Waste_kg": self.total_solid_waste_kg,
            "Liquid_Waste_Bittern_Liters": self.liquid_waste_bittern_liters,
            "Bittern_Mg_Concentration_gL": self.bittern_mg_concentration_gl,
            "Bittern_K_Concentration_gL": self.bittern_k_concentration_gl,
            "Bittern_SO4_Concentration_gL": self.bittern_so4_concentration_gl,
            "Bittern_Ca_Concentration_gL": self.bittern_ca_concentration_gl,
            "Bittern_Magnesium_kg": self.bittern_magnesium_kg,
            "Bittern_Potassium_kg": self.bittern_potassium_kg,
            "Bittern_Sulfate_kg": self.bittern_sulfate_kg,
            "Bittern_Calcium_kg": self.bittern_calcium_kg,
        }
