"""Four-dimension composite score engine.

Weights:
    win_rate                30%
    risk_adjusted_return    30%
    consistency             25%
    confidence_calibration  15%

Each dimension is normalised to [0.0, 1.0] before weighting.
"""

from __future__ import annotations

import math
from collections.abc import Sequence
from dataclasses import dataclass

from tradearena.models.signal import Outcome

WEIGHTS = {
    "win_rate": 0.30,
    "risk_adjusted_return": 0.30,
    "consistency": 0.25,
    "confidence_calibration": 0.15,
}


@dataclass
class ScoreDimensions:
    win_rate: float = 0.0
    risk_adjusted_return: float = 0.0
    consistency: float = 0.0
    confidence_calibration: float = 0.0

    @property
    def composite(self) -> float:
        return (
            self.win_rate * WEIGHTS["win_rate"]
            + self.risk_adjusted_return * WEIGHTS["risk_adjusted_return"]
            + self.consistency * WEIGHTS["consistency"]
            + self.confidence_calibration * WEIGHTS["confidence_calibration"]
        )


def _clamp(value: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, value))


# ---------------------------------------------------------------------------
# Win Rate (30%)
# ---------------------------------------------------------------------------


def score_win_rate(outcomes: Sequence[str | None]) -> float:
    """Fraction of resolved signals that are 'WIN'.

    Pending signals (None) are excluded from the denominator.
    """
    resolved = [o for o in outcomes if o is not None]
    if not resolved:
        return 0.0
    wins = sum(1 for o in resolved if o == Outcome.WIN)
    return _clamp(wins / len(resolved))


# ---------------------------------------------------------------------------
# Risk-Adjusted Return (30%)
# ---------------------------------------------------------------------------


def score_risk_adjusted_return(
    outcomes: Sequence[str | None],
    confidences: Sequence[float],
) -> float:
    """Simplified Sharpe-like score based on confidence-weighted outcomes.

    Returns are modelled as +confidence for WIN, -confidence for LOSS,
    0 for NEUTRAL. The ratio of mean return to std-dev is then normalised
    to [0, 1] via a sigmoid.
    """
    paired = [(o, c) for o, c in zip(outcomes, confidences) if o is not None]
    if len(paired) < 2:
        return 0.0

    returns = []
    for outcome, conf in paired:
        if outcome == Outcome.WIN:
            returns.append(conf)
        elif outcome == Outcome.LOSS:
            returns.append(-conf)
        else:
            returns.append(0.0)

    mean_r = sum(returns) / len(returns)
    variance = sum((r - mean_r) ** 2 for r in returns) / len(returns)
    std_r = math.sqrt(variance) if variance > 0 else 1e-9
    sharpe = mean_r / std_r
    # Sigmoid normalisation: sigmoid(sharpe) maps (-inf,+inf) -> (0,1)
    sharpe_clamped = max(-500.0, min(500.0, sharpe))
    normalised = 1.0 / (1.0 + math.exp(-sharpe_clamped))
    return _clamp(normalised)


# ---------------------------------------------------------------------------
# Consistency (25%)
# ---------------------------------------------------------------------------


def score_consistency(
    outcomes: Sequence[str | None],
    window: int = 10,
) -> float:
    """Measures stability of win-rate across rolling windows.

    A creator who wins consistently across different market periods scores
    higher than one with a single hot streak. Returns 0 if fewer than
    window resolved signals exist.
    """
    resolved = [o for o in outcomes if o is not None]
    if len(resolved) < window:
        return _clamp(len(resolved) / window * 0.5)  # partial credit

    window_rates = []
    for i in range(len(resolved) - window + 1):
        chunk = resolved[i : i + window]
        rate = sum(1 for o in chunk if o == Outcome.WIN) / window
        window_rates.append(rate)

    mean_wr = sum(window_rates) / len(window_rates)
    variance = sum((r - mean_wr) ** 2 for r in window_rates) / len(window_rates)
    std_wr = math.sqrt(variance)

    # Low std_dev → high consistency. Map std in [0, 0.5] to score [1, 0].
    consistency = _clamp(1.0 - (std_wr / 0.5))
    # Blend with mean win-rate so low performers can't score high on consistency alone
    return _clamp(consistency * 0.6 + mean_wr * 0.4)


# ---------------------------------------------------------------------------
# Confidence Calibration (15%)
# ---------------------------------------------------------------------------


def score_confidence_calibration(
    outcomes: Sequence[str | None],
    confidences: Sequence[float],
) -> float:
    """Brier-score-based calibration: how well confidence predicts outcomes.

    Perfect calibration (stated confidence matches win probability) scores 1.0.
    Brier score = mean((confidence - outcome_binary)^2), range [0, 1].
    We invert and normalise: calibration = 1 - 2 * brier_score.
    """
    paired = [(o, c) for o, c in zip(outcomes, confidences) if o is not None]
    if not paired:
        return 0.0

    brier = sum(
        (conf - (1.0 if outcome == Outcome.WIN else 0.0)) ** 2 for outcome, conf in paired
    ) / len(paired)

    # Brier score 0 = perfect, 1 = worst. 1 - 2*brier maps [0,0.5] -> [1,0].
    calibration = 1.0 - 2.0 * brier
    return _clamp(calibration)


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def compute_score(
    outcomes: list[str | None],
    confidences: list[float],
) -> ScoreDimensions:
    """Compute all four dimensions and return a ScoreDimensions instance."""
    return ScoreDimensions(
        win_rate=score_win_rate(outcomes),
        risk_adjusted_return=score_risk_adjusted_return(outcomes, confidences),
        consistency=score_consistency(outcomes),
        confidence_calibration=score_confidence_calibration(outcomes, confidences),
    )
