SERVICE_PREFIX_MAP = {

    "aws_instance": "EC2",
    "aws_ebs": "EBS",
    "aws_s3": "S3",
    "aws_lambda": "Lambda",
    "aws_lb": "ELB",
    "aws_elb": "ELB",
    "aws_nat_gateway": "NAT Gateway",
    "aws_dynamodb": "DynamoDB",
    "aws_db": "RDS",
    "aws_rds": "RDS",
    "aws_redshift": "Redshift",
    "aws_cloudfront": "CloudFront",
    "aws_efs": "EFS",
    "aws_elasticache": "ElastiCache",
    "aws_kinesis": "Kinesis",
    "aws_sqs": "SQS",
    "aws_sns": "SNS",
    "aws_api_gateway": "API Gateway",
    "aws_eks": "EKS"
}


def detect_service(resource_type):

    for prefix, service in SERVICE_PREFIX_MAP.items():

        if resource_type.startswith(prefix):

            return service

    return "Other"