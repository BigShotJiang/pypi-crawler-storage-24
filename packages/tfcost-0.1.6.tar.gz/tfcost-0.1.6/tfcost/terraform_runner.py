import subprocess

def run_terraform_plan(terraform_args):

    cmd = ["terraform", "plan"] + list(terraform_args) + ["-out=tfplan"]

    subprocess.run(cmd, check=True)

    subprocess.run(
        ["terraform", "show", "-json", "tfplan"],
        stdout=open("plan.json", "w"),
        check=True
    )