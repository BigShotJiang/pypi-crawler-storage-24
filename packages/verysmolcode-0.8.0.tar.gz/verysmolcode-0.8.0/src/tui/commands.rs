use crate::tui::app::CommandResponse;

const COMMANDS: &[(&str, &str)] = &[
    ("/help", "Show available commands"),
    ("/clear", "Clear conversation and screen"),
    ("/quit", "Exit VerySmolCode"),
    (
        "/fast",
        "Use Flash models for next message (saves Pro budget)",
    ),
    ("/smart", "Use Pro models for next message (best quality)"),
    ("/plan", "Toggle planning mode (read-only, uses Pro model)"),
    ("/tokens", "Show detailed token usage and rate limits"),
    ("/status", "Show rate limits and token usage"),
    ("/config", "Show/set config: /config set <key> <value>"),
    ("/undo", "Undo the last batch of file changes"),
    ("/compact", "Manually compact conversation to save tokens"),
    ("/model", "Show available models and current selection"),
    ("/mcp", "List configured MCP servers"),
    (
        "/mcp-add",
        "Add an MCP server: /mcp-add <name> <command> [args...]",
    ),
    ("/mcp-rm", "Remove an MCP server: /mcp-rm <name>"),
    ("/version", "Show version information"),
];

pub fn handle_command(input: &str) -> CommandResponse {
    let parts: Vec<&str> = input.splitn(2, ' ').collect();
    let cmd = parts[0].to_lowercase();
    let args = parts.get(1).unwrap_or(&"");

    match cmd.as_str() {
        "/help" | "/h" => {
            let mut help = String::from("Available commands:\n\n");
            for (cmd, desc) in COMMANDS {
                help.push_str(&format!("  {:12} {}\n", cmd, desc));
            }
            help.push_str("\nKeybindings:\n");
            help.push_str("  Ctrl+C     Cancel/Quit\n");
            help.push_str("  Ctrl+L     Clear screen\n");
            help.push_str("  Up/Down    Input history\n");
            help.push_str("  PgUp/PgDn  Scroll output\n");
            help.push_str("  Tab        Auto-complete commands\n");
            CommandResponse::Message(help)
        }
        "/quit" | "/q" | "/exit" => CommandResponse::Quit,
        "/clear" => CommandResponse::Clear,
        "/fast" | "/f" => CommandResponse::SetModelOverride("fast".to_string()),
        "/smart" | "/s" => CommandResponse::SetModelOverride("smart".to_string()),
        "/plan" => CommandResponse::TogglePlan,
        "/tokens" | "/status" => CommandResponse::ShowTokens,
        "/undo" | "/u" => CommandResponse::Undo,
        "/config" => {
            if let Some(set_rest) = args.strip_prefix("set ") {
                let set_args: Vec<&str> = set_rest.splitn(2, ' ').collect();
                if set_args.len() < 2 {
                    return CommandResponse::Message(
                        "Usage: /config set <key> <value>\n\
                         Keys: temperature, max_tokens, compact_threshold, safety"
                            .to_string(),
                    );
                }
                let key = set_args[0];
                let val = set_args[1].trim();
                let mut config = crate::config::Config::load();
                let result = match key {
                    "temperature" | "temp" => val
                        .parse::<f32>()
                        .map(|v| {
                            config.temperature = v.clamp(0.0, 2.0);
                            format!("Temperature set to {}", config.temperature)
                        })
                        .map_err(|_| "Invalid number".to_string()),
                    "max_tokens" => val
                        .parse::<u32>()
                        .map(|v| {
                            config.max_tokens_per_response = v.clamp(256, 65536);
                            format!(
                                "Max tokens/response set to {}",
                                config.max_tokens_per_response
                            )
                        })
                        .map_err(|_| "Invalid number".to_string()),
                    "compact_threshold" => val
                        .parse::<u32>()
                        .map(|v| {
                            config.auto_compact_threshold = v.clamp(4000, 128000);
                            format!(
                                "Auto-compact threshold set to {}",
                                config.auto_compact_threshold
                            )
                        })
                        .map_err(|_| "Invalid number".to_string()),
                    "safety" => match val {
                        "on" | "true" | "enabled" => {
                            config.safety_enabled = true;
                            Ok("Safety checks enabled".to_string())
                        }
                        "off" | "false" | "disabled" => {
                            config.safety_enabled = false;
                            Ok("Safety checks disabled".to_string())
                        }
                        _ => Err("Use: on/off".to_string()),
                    },
                    _ => Err(format!(
                        "Unknown key: {}. Valid: temperature, max_tokens, compact_threshold, safety",
                        key
                    )),
                };
                match result {
                    Ok(msg) => {
                        let _ = config.save();
                        CommandResponse::Message(msg)
                    }
                    Err(e) => CommandResponse::Message(format!("Error: {}", e)),
                }
            } else {
                let config = crate::config::Config::load();
                let msg = format!(
                    "Current configuration:\n\
                     Max tokens/response: {}\n\
                     Max conversation tokens: {}\n\
                     Temperature: {}\n\
                     Auto-compact threshold: {}\n\
                     Safety checks: {}\n\
                     \n\
                     Use /config set <key> <value> to change.\n\
                     Keys: temperature, max_tokens, compact_threshold, safety",
                    config.max_tokens_per_response,
                    config.max_conversation_tokens,
                    config.temperature,
                    config.auto_compact_threshold,
                    if config.safety_enabled {
                        "enabled"
                    } else {
                        "disabled"
                    },
                );
                CommandResponse::Message(msg)
            }
        }
        "/compact" => CommandResponse::Message("Conversation compacted.".to_string()),
        "/model" => {
            let msg = "Available models (Gemini Free Tier):\n\n\
                       Gemini 3.1 Pro        - 5 RPM,  25 RPD  (complex tasks)\n\
                       Gemini 3 Flash        - 10 RPM, 250 RPD (general tasks)\n\
                       Gemini 3.1 Flash-Lite - 15 RPM, 1000 RPD (simple tasks)\n\
                       Gemini 2.5 Pro        - 5 RPM,  25 RPD  (fallback complex)\n\
                       Gemini 2.5 Flash      - 10 RPM, 250 RPD (fallback general)\n\
                       Gemini 2.5 Flash-Lite - 15 RPM, 1000 RPD (fallback simple)\n\n\
                       Gemini 3 models preferred. Falls back to 2.5 when rate-limited.\n\
                       Each model has independent limits, doubling effective daily quota.";
            CommandResponse::Message(msg.to_string())
        }
        "/mcp" => {
            let config = crate::mcp::config::McpConfig::load();
            if config.servers.is_empty() {
                CommandResponse::Message(
                    "No MCP servers configured.\n\
                     Use /mcp-add <name> <command> [args...] to add one.\n\n\
                     Examples:\n\
                     /mcp-add context7 npx -y @anthropic-ai/context7-mcp\n\
                     /mcp-add playwright npx -y @anthropic-ai/playwright-mcp"
                        .to_string(),
                )
            } else {
                let mut msg = String::from("Configured MCP servers:\n\n");
                for server in &config.servers {
                    msg.push_str(&format!(
                        "  {} - {} {}\n",
                        server.name,
                        server.command,
                        server.args.join(" ")
                    ));
                }
                CommandResponse::Message(msg)
            }
        }
        "/mcp-add" => {
            let parts: Vec<&str> = args.splitn(3, ' ').collect();
            if parts.len() < 2 {
                CommandResponse::Message(
                    "Usage: /mcp-add <name> <command> [args...]\n\
                     Example: /mcp-add context7 npx -y @anthropic-ai/context7-mcp"
                        .to_string(),
                )
            } else {
                let name = parts[0].to_string();
                let command = parts[1].to_string();
                let args: Vec<String> = if parts.len() > 2 {
                    parts[2].split_whitespace().map(|s| s.to_string()).collect()
                } else {
                    Vec::new()
                };

                let server_config = crate::mcp::types::McpServerConfig {
                    name: name.clone(),
                    command,
                    args,
                    env: std::collections::HashMap::new(),
                };

                let mut mcp_config = crate::mcp::config::McpConfig::load();
                mcp_config.add_server(server_config);
                match mcp_config.save() {
                    Ok(()) => CommandResponse::Message(format!(
                        "MCP server '{}' added. It will be available on next restart.",
                        name
                    )),
                    Err(e) => CommandResponse::Message(format!("Failed to save config: {}", e)),
                }
            }
        }
        "/mcp-rm" => {
            let name = args.trim();
            if name.is_empty() {
                CommandResponse::Message("Usage: /mcp-rm <name>".to_string())
            } else {
                let mut mcp_config = crate::mcp::config::McpConfig::load();
                if mcp_config.remove_server(name) {
                    match mcp_config.save() {
                        Ok(()) => {
                            CommandResponse::Message(format!("MCP server '{}' removed.", name))
                        }
                        Err(e) => CommandResponse::Message(format!("Failed to save config: {}", e)),
                    }
                } else {
                    CommandResponse::Message(format!("MCP server '{}' not found.", name))
                }
            }
        }
        "/version" => CommandResponse::Message(format!(
            "VerySmolCode v{}\nA lightweight coding assistant for constrained devices",
            env!("CARGO_PKG_VERSION")
        )),
        _ => CommandResponse::Message(format!(
            "Unknown command: {}. Type /help for available commands.",
            cmd
        )),
    }
}

pub fn autocomplete(input: &str) -> Vec<String> {
    COMMANDS
        .iter()
        .filter(|(cmd, _)| cmd.starts_with(input))
        .map(|(cmd, _)| cmd.to_string())
        .collect()
}
