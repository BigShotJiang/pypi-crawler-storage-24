use crate::api::client::{build_request, extract_response, GeminiClient};
use crate::api::models::ModelId;
use crate::api::types::*;
use crate::config::Config;
use crate::mcp::client::McpClient;
use crate::mcp::config::McpConfig;
use crate::tools::registry::ToolRegistry;
use crate::tools::undo::UndoHistory;

/// Represents a message in the conversation
#[derive(Debug, Clone)]
pub struct AgentMessage {
    pub role: String,
    pub content: String,
    pub model: Option<String>,
    pub tool_calls: Vec<(String, serde_json::Value)>,
    pub is_thinking: bool,
}

/// Override for model selection on next request
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum ModelOverride {
    None,
    Fast,  // Force Flash/Lite models
    Smart, // Force Pro models
}

/// The main agent loop that processes user input through the Gemini API
pub struct AgentLoop {
    client: GeminiClient,
    config: Config,
    conversation: Vec<Content>,
    total_conversation_tokens: u32,
    planning_mode: bool,
    mcp_clients: Vec<McpClient>,
    files_modified: bool, // Track if any write/edit tools were used this turn
    pub model_override: ModelOverride,
    undo_history: UndoHistory,
}

/// Max characters for a single tool result before truncation.
/// Gemini's context is large but each token costs requests/day budget.
const MAX_TOOL_RESULT_CHARS: usize = 8000;

/// Truncate a tool result JSON to save tokens
pub fn truncate_tool_result(result: &serde_json::Value) -> serde_json::Value {
    let s = result.to_string();
    if s.len() <= MAX_TOOL_RESULT_CHARS {
        return result.clone();
    }
    // For objects with a "content" or "matches" field, truncate that field
    if let Some(obj) = result.as_object() {
        let mut truncated = obj.clone();
        for key in &["content", "matches", "output", "stdout"] {
            if let Some(val) = truncated.get(*key) {
                let val_str = val.to_string();
                if val_str.len() > MAX_TOOL_RESULT_CHARS / 2 {
                    let cut = &val_str[..MAX_TOOL_RESULT_CHARS / 2];
                    truncated.insert(
                        key.to_string(),
                        serde_json::json!(format!(
                            "{}...[truncated, {} chars total]",
                            cut,
                            val_str.len()
                        )),
                    );
                }
            }
        }
        return serde_json::Value::Object(truncated);
    }
    // Fallback: truncate the whole string
    serde_json::json!(format!(
        "{}...[truncated, {} chars total]",
        &s[..MAX_TOOL_RESULT_CHARS],
        s.len()
    ))
}

/// Strip thinking/thought parts from conversation history to save tokens on resend.
/// Thinking tokens are useful for the model's reasoning but shouldn't be sent back.
pub fn strip_thinking_from_history(conversation: &mut [Content]) {
    for content in conversation.iter_mut() {
        content
            .parts
            .retain(|part| !matches!(part, Part::Thought { .. }));
    }
}

const PLANNING_SYSTEM_PROMPT: &str = r#"You are in PLANNING MODE. Your job is to analyze the task and create a detailed, step-by-step implementation plan.

Rules for planning mode:
1. First, understand the codebase by reading relevant files
2. Break the task into clear, numbered steps
3. Identify files that need to be created or modified
4. Consider edge cases and potential issues
5. Estimate complexity of each step
6. DO NOT make any changes - only read files and create a plan
7. Output a structured plan with clear sections

Format your plan as:
## Analysis
[Brief analysis of the task]

## Steps
1. [Step description] - [files involved]
2. ...

## Risks
- [Potential issues to watch for]

## Estimated Complexity
[Low/Medium/High] - [brief justification]"#;

impl AgentLoop {
    pub fn new() -> Result<Self, String> {
        // Start configured MCP servers
        let mcp_config = McpConfig::load();
        let mut mcp_clients = Vec::new();
        for server_config in &mcp_config.servers {
            match McpClient::start(server_config) {
                Ok(client) => {
                    mcp_clients.push(client);
                }
                Err(_) => {
                    // Non-fatal: skip servers that fail to start
                }
            }
        }

        Ok(Self {
            client: GeminiClient::new()?,
            config: Config::load(),
            conversation: Vec::new(),
            total_conversation_tokens: 0,
            planning_mode: false,
            mcp_clients,
            files_modified: false,
            model_override: ModelOverride::None,
            undo_history: UndoHistory::new(),
        })
    }

    /// Get tool declarations including MCP tools
    fn get_tools(&self, read_only: bool) -> Vec<ToolDeclaration> {
        let mut tools = if read_only {
            ToolRegistry::read_only_declarations()
        } else {
            ToolRegistry::declarations()
        };

        // NOTE: Google Search grounding disabled for now - may not work on free tier
        // tools.push(ToolDeclaration::google_search());

        // Add MCP tool declarations
        if !self.mcp_clients.is_empty() {
            let mut mcp_decls = Vec::new();
            for client in &self.mcp_clients {
                for tool in &client.tools {
                    let params = tool
                        .input_schema
                        .clone()
                        .unwrap_or_else(|| serde_json::json!({"type": "object", "properties": {}}));
                    mcp_decls.push(FunctionDecl {
                        name: format!("mcp_{}_{}", client.name(), tool.name),
                        description: tool
                            .description
                            .clone()
                            .unwrap_or_else(|| format!("MCP tool: {}", tool.name)),
                        parameters: params,
                    });
                }
            }
            if !mcp_decls.is_empty() {
                tools.push(ToolDeclaration {
                    function_declarations: mcp_decls,
                    google_search: None,
                });
            }
        }

        tools
    }

    /// Try to execute an MCP tool call, returns None if not an MCP tool
    fn try_execute_mcp(
        &mut self,
        name: &str,
        args: &serde_json::Value,
    ) -> Option<serde_json::Value> {
        // MCP tools are prefixed: mcp_{server}_{tool}
        let stripped = name.strip_prefix("mcp_")?;

        // Find which MCP client owns this tool
        for client in &mut self.mcp_clients {
            let prefix = format!("{}_", client.name());
            if let Some(tool_name) = stripped.strip_prefix(&prefix) {
                // Found the right client, call the tool
                return match client.call_tool(tool_name, args.clone()) {
                    Ok(result) => Some(result),
                    Err(e) => Some(serde_json::json!({"error": e})),
                };
            }
        }

        None
    }

    pub fn set_planning_mode(&mut self, enabled: bool) {
        self.planning_mode = enabled;
    }

    pub fn is_planning_mode(&self) -> bool {
        self.planning_mode
    }

    /// Process a user message and return agent responses
    /// The callback is called for each response chunk (text, tool use, etc.)
    pub fn process_message<F>(&mut self, user_input: &str, mut on_event: F) -> Result<(), String>
    where
        F: FnMut(AgentEvent),
    {
        // Begin undo tracking for this turn
        self.undo_history.begin_turn();

        // Add user message to conversation
        self.conversation.push(Content {
            role: Some("user".to_string()),
            parts: vec![Part::text(user_input)],
        });

        // Determine model preference: override > planning mode > auto-detect
        let prefer_smart = match self.model_override {
            ModelOverride::Smart => true,
            ModelOverride::Fast => false,
            ModelOverride::None => self.planning_mode || self.is_complex_task(user_input),
        };
        // Reset override after use (one-shot)
        self.model_override = ModelOverride::None;
        self.files_modified = false;

        // Main agent loop - keeps going until no more tool calls
        // Planning mode gets fewer iterations (just reading + planning)
        let max_iterations = if self.planning_mode { 8 } else { 15 };
        let mut had_tool_calls = false;
        for iteration in 0..max_iterations {
            // Strip thinking tokens from history before resending to save tokens
            strip_thinking_from_history(&mut self.conversation);
            // Check if we need to compact conversation
            if self.total_conversation_tokens > self.config.auto_compact_threshold {
                on_event(AgentEvent::Status(
                    "Compacting conversation to save tokens...".to_string(),
                ));
                self.compact_conversation();
            }

            // Pick model: only use Pro for first iteration, Flash for tool-call follow-ups
            // This saves Pro budget (25/day) for initial reasoning
            let use_smart = prefer_smart && iteration == 0;
            let model = self
                .client
                .router
                .pick_model(use_smart)
                .ok_or_else(|| "All models exhausted for today".to_string())?;

            on_event(AgentEvent::ModelSwitch(model.display_name().to_string()));

            // Build request - use planning prompt in planning mode
            let system_prompt = if self.planning_mode {
                format!(
                    "{}\n\n{}",
                    PLANNING_SYSTEM_PROMPT, &self.config.system_prompt
                )
            } else {
                self.config.system_prompt.clone()
            };

            // Make API call with automatic fallback chain on rate limit/overload
            on_event(AgentEvent::Status("Thinking...".to_string()));
            let response = {
                let mut current_model = model;
                let mut retried = false;
                loop {
                    let req = build_request(
                        &system_prompt,
                        self.conversation.clone(),
                        Some(self.get_tools(self.planning_mode)),
                        current_model,
                        self.config.temperature,
                        self.config.max_tokens_per_response,
                    );
                    match self.client.generate(current_model, &req) {
                        Ok(resp) => break resp,
                        Err(e) if is_rate_limit_error(&e) => {
                            // First try: wait for the same model if RPM-limited (not daily)
                            if !retried {
                                if let Some(wait) = self.client.router.wait_for_model(current_model)
                                {
                                    if wait.as_secs() <= 15 && wait.as_secs() > 0 {
                                        on_event(AgentEvent::Status(format!(
                                            "Rate limited, waiting {}s for {}...",
                                            wait.as_secs(),
                                            current_model.display_name()
                                        )));
                                        std::thread::sleep(wait);
                                        retried = true;
                                        continue;
                                    }
                                }
                            }
                            // Fall back to a weaker model
                            if let Some(fb) = self.client.router.fallback_for(current_model) {
                                on_event(AgentEvent::Status(format!(
                                    "{} unavailable, trying {}...",
                                    current_model.display_name(),
                                    fb.display_name()
                                )));
                                on_event(AgentEvent::ModelSwitch(fb.display_name().to_string()));
                                current_model = fb;
                                retried = false;
                            } else {
                                return Err(e);
                            }
                        }
                        Err(e) => return Err(e),
                    }
                }
            };

            // Track tokens
            if let Some(ref usage) = response.usage_metadata {
                self.total_conversation_tokens = usage.total_token_count;
                on_event(AgentEvent::TokenUpdate {
                    input: usage.prompt_token_count,
                    output: usage.candidates_token_count,
                    total: usage.total_token_count,
                    thinking: usage.thoughts_token_count,
                });
            }

            // Extract response
            let (texts, function_calls) = extract_response(&response);

            // Add model response to conversation
            if let Some(candidate) = response.candidates.first() {
                if let Some(ref content) = candidate.content {
                    self.conversation.push(content.clone());
                }
            }

            // Emit text responses
            for text in &texts {
                if !text.trim().is_empty() {
                    on_event(AgentEvent::Text(text.clone()));
                }
            }

            // If no tool calls, we're done
            if function_calls.is_empty() {
                break;
            }

            // Execute tool calls
            had_tool_calls = true;
            let mut function_responses = Vec::new();
            for call in &function_calls {
                on_event(AgentEvent::ToolCall {
                    name: call.name.clone(),
                    args: call.args.clone(),
                });

                // Safety check
                if self.config.safety_enabled && is_dangerous_tool_call(&call.name, &call.args) {
                    let result = serde_json::json!({
                        "error": "This operation was blocked by safety checks. The action could be destructive."
                    });
                    on_event(AgentEvent::ToolResult {
                        name: call.name.clone(),
                        result: result.clone(),
                    });
                    function_responses.push(Part::function_response(&call.name, result));
                    continue;
                }

                // Snapshot file before mutation for undo support
                if matches!(call.name.as_str(), "write_file" | "edit_file") {
                    if let Some(path) = call.args.get("path").and_then(|v| v.as_str()) {
                        self.undo_history
                            .snapshot_before_write(std::path::Path::new(path));
                    }
                }

                // Try MCP tools first, then built-in tools
                let result = self
                    .try_execute_mcp(&call.name, &call.args)
                    .unwrap_or_else(|| ToolRegistry::execute(&call.name, &call.args));

                // Track if files were modified (for critic decision)
                if matches!(
                    call.name.as_str(),
                    "write_file" | "edit_file" | "run_command"
                ) {
                    self.files_modified = true;
                }

                on_event(AgentEvent::ToolResult {
                    name: call.name.clone(),
                    result: result.clone(),
                });

                // Truncate large tool results before adding to conversation history
                let result = truncate_tool_result(&result);

                // For read_image, include the InlineData part so Gemini can see it
                if call.name == "read_image" {
                    if let Some(inline) = result.get("inline_data") {
                        if let (Some(mime), Some(data)) = (
                            inline.get("mime_type").and_then(|v| v.as_str()),
                            inline.get("data").and_then(|v| v.as_str()),
                        ) {
                            function_responses.push(Part::function_response(
                                &call.name,
                                serde_json::json!({"path": result.get("path"), "size_bytes": result.get("size_bytes")}),
                            ));
                            function_responses.push(Part::InlineData {
                                inline_data: crate::api::types::InlineData {
                                    mime_type: mime.to_string(),
                                    data: data.to_string(),
                                },
                            });
                            continue;
                        }
                    }
                }

                function_responses.push(Part::function_response(&call.name, result));
            }

            // Add tool responses to conversation
            self.conversation.push(Content {
                role: Some("user".to_string()),
                parts: function_responses,
            });
        }

        // Run critic check only if files were actually modified (saves API calls)
        // Skip critic for read-only operations, planning mode, or when no budget
        if !self.planning_mode && had_tool_calls && self.files_modified {
            self.run_critic(user_input, &mut on_event)?;
        }

        // Commit undo history for this turn
        self.undo_history.commit_turn();

        Ok(())
    }

    /// Critic step: verify the work was actually done correctly
    fn run_critic<F>(&mut self, original_task: &str, on_event: &mut F) -> Result<(), String>
    where
        F: FnMut(AgentEvent),
    {
        // Pick a cheap model for the critic (prefer Flash-Lite tier)
        let critic_model = if self.client.router.g3_flash_lite.can_request() {
            ModelId::Gemini31FlashLite
        } else if self.client.router.flash_lite.can_request() {
            ModelId::Gemini25FlashLite
        } else {
            return Ok(()); // Skip critic if no budget
        };

        on_event(AgentEvent::Status("Verifying work...".to_string()));

        let critic_prompt = format!(
            "Review if the following task was completed correctly:\n\nTask: {}\n\n\
             Check the recent conversation and tool results. Was the task fully completed? \
             If yes, say 'VERIFIED: [brief summary]'. \
             If not, say 'INCOMPLETE: [what's missing]' and suggest next steps.",
            original_task
        );

        self.conversation.push(Content {
            role: Some("user".to_string()),
            parts: vec![Part::text(&critic_prompt)],
        });

        let request = build_request(
            "You are a code review critic. Verify work was done correctly. Be concise.",
            self.conversation.clone(),
            None, // No tools needed for critic
            critic_model,
            0.3, // Low temperature for consistent evaluation
            512, // Short response
        );

        match self.client.generate(critic_model, &request) {
            Ok(response) => {
                if let Some(ref usage) = response.usage_metadata {
                    self.total_conversation_tokens = usage.total_token_count;
                }

                let (texts, _) = extract_response(&response);
                for text in &texts {
                    if !text.trim().is_empty() {
                        on_event(AgentEvent::Status(format!("Critic: {}", text)));
                    }
                }

                // Add critic response to conversation
                if let Some(candidate) = response.candidates.first() {
                    if let Some(ref content) = candidate.content {
                        self.conversation.push(content.clone());
                    }
                }
            }
            Err(_) => {
                // Critic failure is non-fatal
                on_event(AgentEvent::Status(
                    "Critic check skipped (rate limit)".to_string(),
                ));
            }
        }

        Ok(())
    }

    /// Determine if a task is complex enough to warrant Pro model
    fn is_complex_task(&self, input: &str) -> bool {
        let complex_keywords = [
            "refactor",
            "architect",
            "design",
            "complex",
            "debug",
            "fix bug",
            "optimize",
            "review",
            "analyze",
            "explain",
            "why",
            "implement",
            "create",
            "build",
            "full",
            "entire",
            "complete",
        ];
        let input_lower = input.to_lowercase();
        let has_complex_keyword = complex_keywords.iter().any(|k| input_lower.contains(k));
        let is_long = input.len() > 200;
        has_complex_keyword || is_long
    }

    /// Compact the conversation to reduce token usage
    fn compact_conversation(&mut self) {
        if self.conversation.len() <= 4 {
            return;
        }

        // Keep first message (context) and last 4 messages
        let keep_start = 1;
        let keep_end = 4;

        if self.conversation.len() > keep_start + keep_end {
            let summary = Content {
                role: Some("user".to_string()),
                parts: vec![Part::text(
                    "[Previous conversation was compacted to save tokens. Continue from the recent context below.]"
                )],
            };

            let mut new_conv = vec![self.conversation[0].clone()];
            new_conv.push(summary);
            let start = self.conversation.len() - keep_end;
            new_conv.extend_from_slice(&self.conversation[start..]);
            self.conversation = new_conv;
            self.total_conversation_tokens = 0; // Reset, will be recalculated
        }
    }

    pub fn rate_limit_status(&mut self) -> String {
        self.client.router.status_line()
    }

    /// Check if any model tier is running low and return a warning message
    pub fn rate_limit_warning(&mut self) -> Option<String> {
        let router = &mut self.client.router;
        let pro_left = router.g3_pro.remaining_today() + router.pro.remaining_today();
        let flash_left = router.g3_flash.remaining_today() + router.flash.remaining_today();

        if pro_left == 0 && flash_left == 0 {
            Some(
                "All Pro and Flash models exhausted for today. Only Flash-Lite available."
                    .to_string(),
            )
        } else if pro_left == 0 {
            Some(format!(
                "Pro models exhausted. {} Flash requests remaining.",
                flash_left
            ))
        } else if pro_left <= 5 {
            Some(format!(
                "Low Pro budget: {} requests left. Use /fast to save Pro for complex tasks.",
                pro_left
            ))
        } else {
            None
        }
    }

    pub fn token_usage(&self) -> String {
        self.client.token_usage_summary()
    }

    pub fn config(&self) -> &Config {
        &self.config
    }

    pub fn config_mut(&mut self) -> &mut Config {
        &mut self.config
    }

    pub fn mcp_status(&self) -> String {
        if self.mcp_clients.is_empty() {
            return "No MCP servers connected".to_string();
        }
        let mut status = format!("{} MCP server(s) connected:\n", self.mcp_clients.len());
        for client in &self.mcp_clients {
            status.push_str(&format!(
                "  {} ({} tools)\n",
                client.name(),
                client.tools.len()
            ));
        }
        status
    }

    pub fn clear_conversation(&mut self) {
        self.conversation.clear();
        self.total_conversation_tokens = 0;
    }

    /// Undo the last turn's file changes
    pub fn undo(&mut self) -> Result<Vec<String>, String> {
        self.undo_history.undo()
    }
}

/// Events emitted by the agent loop
#[derive(Debug, Clone)]
pub enum AgentEvent {
    Text(String),
    ToolCall {
        name: String,
        args: serde_json::Value,
    },
    ToolResult {
        name: String,
        result: serde_json::Value,
    },
    ModelSwitch(String),
    TokenUpdate {
        input: u32,
        output: u32,
        total: u32,
        thinking: u32,
    },
    Status(String),
}

/// Check if an error indicates rate limiting or overload
pub fn is_rate_limit_error(e: &str) -> bool {
    e.contains("429")
        || e.contains("rate")
        || e.contains("quota")
        || e.contains("503")
        || e.contains("high demand")
}

/// Check if a tool call looks dangerous
pub fn is_dangerous_tool_call(name: &str, args: &serde_json::Value) -> bool {
    match name {
        "run_command" => {
            if let Some(cmd) = args.get("command").and_then(|v| v.as_str()) {
                let dangerous = [
                    "rm -rf",
                    "rm -r /",
                    "dd if=",
                    "mkfs",
                    "format",
                    "shutdown",
                    "reboot",
                    "init 0",
                    "init 6",
                    "chmod 777",
                    "chmod -R 777",
                    "> /dev/",
                ];
                if dangerous.iter().any(|d| cmd.contains(d)) {
                    return true;
                }
                // Block piping downloads to shell execution
                let has_download = cmd.contains("curl ") || cmd.contains("wget ");
                let has_pipe_exec =
                    cmd.contains("| sh") || cmd.contains("| bash") || cmd.contains("| zsh");
                if has_download && has_pipe_exec {
                    return true;
                }
                false
            } else {
                false
            }
        }
        "write_file" => {
            if let Some(path) = args.get("path").and_then(|v| v.as_str()) {
                let dangerous_paths = [
                    "/etc/", "/boot/", "/usr/", "/bin/", "/sbin/", "/lib/", "/proc/", "/sys/",
                    "/dev/",
                ];
                return dangerous_paths.iter().any(|d| path.starts_with(d));
            }
            false
        }
        _ => false,
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // -- is_complex_task tests --
    // We can't call is_complex_task directly without an AgentLoop (needs API key),
    // so we test the logic inline.

    fn check_complex(input: &str) -> bool {
        let complex_keywords = [
            "refactor",
            "architect",
            "design",
            "complex",
            "debug",
            "fix bug",
            "optimize",
            "review",
            "analyze",
            "explain",
            "why",
            "implement",
            "create",
            "build",
            "full",
            "entire",
            "complete",
        ];
        let input_lower = input.to_lowercase();
        let has_complex_keyword = complex_keywords.iter().any(|k| input_lower.contains(k));
        let is_long = input.len() > 200;
        has_complex_keyword || is_long
    }

    #[test]
    fn test_complex_task_keywords() {
        assert!(check_complex("refactor the auth module"));
        assert!(check_complex("debug this crash"));
        assert!(check_complex("explain why this fails"));
        assert!(check_complex("implement a new feature"));
        assert!(check_complex("build a REST API"));
        assert!(check_complex("optimize the query"));
        assert!(check_complex("review this PR"));
        assert!(check_complex("analyze the codebase"));
    }

    #[test]
    fn test_complex_task_case_insensitive() {
        assert!(check_complex("REFACTOR everything"));
        assert!(check_complex("Design a New System"));
        assert!(check_complex("FIX BUG in auth"));
    }

    #[test]
    fn test_simple_task() {
        assert!(!check_complex("hello"));
        assert!(!check_complex("what is this file"));
        assert!(!check_complex("list files"));
        assert!(!check_complex("show me the code"));
    }

    #[test]
    fn test_complex_task_long_input() {
        let long_input = "a".repeat(201);
        assert!(check_complex(&long_input));
    }

    #[test]
    fn test_complex_task_exactly_200_chars() {
        let input = "a".repeat(200);
        assert!(!check_complex(&input));
    }

    // -- compact_conversation logic tests --

    #[test]
    fn test_compact_small_conversation() {
        // Conversations with 4 or fewer messages should not be compacted
        let conv = vec![
            Content {
                role: Some("user".to_string()),
                parts: vec![Part::text("hello")],
            },
            Content {
                role: Some("model".to_string()),
                parts: vec![Part::text("hi")],
            },
        ];
        // Conversations with 4 or fewer messages should not be compacted
        assert!(conv.len() <= 4);
    }

    #[test]
    fn test_compact_large_conversation() {
        let mut conv: Vec<Content> = (0..10)
            .map(|i| Content {
                role: Some(if i % 2 == 0 { "user" } else { "model" }.to_string()),
                parts: vec![Part::text(&format!("message {}", i))],
            })
            .collect();

        // Simulate compaction: keep first + summary + last 4
        let keep_start = 1;
        let keep_end = 4;

        if conv.len() > keep_start + keep_end {
            let summary = Content {
                role: Some("user".to_string()),
                parts: vec![Part::text("[Compacted]")],
            };
            let mut new_conv = vec![conv[0].clone()];
            new_conv.push(summary);
            let start = conv.len() - keep_end;
            new_conv.extend_from_slice(&conv[start..]);
            conv = new_conv;
        }

        // Should have: first + summary + last 4 = 6
        assert_eq!(conv.len(), 6);
        // First message preserved
        match &conv[0].parts[0] {
            Part::Text { text } => assert_eq!(text, "message 0"),
            _ => panic!("Expected text"),
        }
        // Summary inserted
        match &conv[1].parts[0] {
            Part::Text { text } => assert!(text.contains("Compacted")),
            _ => panic!("Expected text"),
        }
        // Last 4 messages preserved
        match &conv[2].parts[0] {
            Part::Text { text } => assert_eq!(text, "message 6"),
            _ => panic!("Expected text"),
        }
    }

    // -- Planning prompt tests --

    #[test]
    fn test_planning_prompt_contains_rules() {
        assert!(PLANNING_SYSTEM_PROMPT.contains("PLANNING MODE"));
        assert!(PLANNING_SYSTEM_PROMPT.contains("DO NOT make any changes"));
        assert!(PLANNING_SYSTEM_PROMPT.contains("read files"));
    }
}
