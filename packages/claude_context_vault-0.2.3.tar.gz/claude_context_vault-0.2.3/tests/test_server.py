"""Tests for the MCP server tool implementations."""

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from claude_context_vault.server import (
    archive_context,
    check_context_health,
    delete_chunk,
    get_chunk,
    list_archived,
    retrieve_context,
)


@pytest.fixture(autouse=True)
def tmp_vault_root(tmp_path):
    """Override vault root for all server tests."""
    with patch("claude_context_vault.server._get_vault") as mock:
        from claude_context_vault.vault import ContextVault
        vault = ContextVault(vault_root=tmp_path)
        mock.return_value = vault
        yield vault


class TestCheckContextHealth:
    def test_returns_status(self):
        result = check_context_health(text="Hello world", project_path="/test")
        assert "status" in result
        assert "token_estimate" in result
        assert "recommendation" in result


class TestArchiveContext:
    def test_archives_and_returns_id(self):
        result = archive_context(
            text="Long conversation about auth patterns",
            label="auth discussion",
            project_path="/test",
        )
        assert "chunk_id" in result
        assert "summary" in result
        assert result["chunk_id"].startswith("chunk_")

    def test_archive_then_retrieve(self):
        archive_result = archive_context(
            text="Implemented JWT authentication with refresh tokens for the API",
            label="jwt auth",
            project_path="/test",
        )
        results = retrieve_context(query="JWT authentication", project_path="/test")
        assert len(results["results"]) >= 1


class TestRetrieveContext:
    def test_returns_results_list(self):
        archive_context(
            text="Database migration setup for PostgreSQL",
            label="db migrations",
            project_path="/test",
        )
        result = retrieve_context(query="database", project_path="/test")
        assert "results" in result
        assert len(result["results"]) >= 1

    def test_no_results(self):
        result = retrieve_context(query="nonexistent topic", project_path="/test")
        assert result["results"] == []


class TestListArchived:
    def test_lists_chunks(self):
        archive_context(text="First chunk", label="one", project_path="/test")
        archive_context(text="Second chunk", label="two", project_path="/test")
        result = list_archived(project_path="/test")
        assert len(result["chunks"]) == 2

    def test_empty_list(self):
        result = list_archived(project_path="/test")
        assert result["chunks"] == []


class TestGetChunk:
    def test_get_existing_chunk(self):
        archive_result = archive_context(
            text="Some important context",
            label="important",
            project_path="/test",
        )
        result = get_chunk(
            chunk_id=archive_result["chunk_id"],
            project_path="/test",
        )
        assert result["content"] == "Some important context"

    def test_get_nonexistent_chunk(self):
        result = get_chunk(chunk_id="chunk_999", project_path="/test")
        assert "error" in result


class TestDeleteChunk:
    def test_delete_existing(self):
        archive_result = archive_context(
            text="To be deleted",
            label="temp",
            project_path="/test",
        )
        result = delete_chunk(
            chunk_id=archive_result["chunk_id"],
            project_path="/test",
        )
        assert result["deleted"] is True

    def test_delete_nonexistent(self):
        result = delete_chunk(chunk_id="chunk_999", project_path="/test")
        assert result["deleted"] is False
