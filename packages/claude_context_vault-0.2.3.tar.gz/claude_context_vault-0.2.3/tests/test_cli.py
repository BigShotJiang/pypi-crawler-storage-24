"""Tests for the CLI install/uninstall commands."""

import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from claude_context_vault.cli import do_install, do_uninstall


@pytest.fixture
def mock_claude_dir(tmp_path):
    """Create a fake ~/.claude directory."""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()
    settings = claude_dir / "settings.json"
    settings.write_text(json.dumps({"mcpServers": {}}))
    return claude_dir


class TestInstall:
    def test_adds_mcp_server_to_settings(self, mock_claude_dir):
        settings_file = mock_claude_dir / "settings.json"
        do_install(claude_dir=mock_claude_dir)
        settings = json.loads(settings_file.read_text())
        assert "claude-context-vault" in settings["mcpServers"]
        server_config = settings["mcpServers"]["claude-context-vault"]
        assert server_config["command"] == sys.executable
        assert "-m" in server_config["args"]
        assert "claude_context_vault" in server_config["args"]

    def test_creates_vault_directory(self, mock_claude_dir):
        do_install(claude_dir=mock_claude_dir)
        vault_dir = mock_claude_dir / "context-vault"
        assert vault_dir.exists()

    def test_creates_settings_if_missing(self, tmp_path):
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        do_install(claude_dir=claude_dir)
        settings_file = claude_dir / "settings.json"
        assert settings_file.exists()

    def test_preserves_existing_settings(self, mock_claude_dir):
        settings_file = mock_claude_dir / "settings.json"
        settings_file.write_text(json.dumps({
            "mcpServers": {"other-server": {"command": "other"}},
            "customSetting": True,
        }))
        do_install(claude_dir=mock_claude_dir)
        settings = json.loads(settings_file.read_text())
        assert "other-server" in settings["mcpServers"]
        assert settings["customSetting"] is True


class TestUninstall:
    def test_removes_mcp_server(self, mock_claude_dir):
        do_install(claude_dir=mock_claude_dir)
        do_uninstall(claude_dir=mock_claude_dir)
        settings_file = mock_claude_dir / "settings.json"
        settings = json.loads(settings_file.read_text())
        assert "claude-context-vault" not in settings["mcpServers"]

    def test_uninstall_when_not_installed(self, mock_claude_dir):
        # Should not raise
        do_uninstall(claude_dir=mock_claude_dir)
