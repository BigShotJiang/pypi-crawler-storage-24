"""Tests for the context vault storage layer."""

import json
import os
import shutil
import tempfile
from pathlib import Path

import pytest

from claude_context_vault.vault import ContextVault


@pytest.fixture
def tmp_vault(tmp_path):
    """Create a vault with a temporary root directory."""
    vault = ContextVault(vault_root=tmp_path)
    return vault


class TestVaultInit:
    def test_creates_vault_directory(self, tmp_path):
        root = tmp_path / "vault"
        vault = ContextVault(vault_root=root)
        assert root.exists()

    def test_creates_project_directory(self, tmp_vault):
        project_dir = tmp_vault.get_project_dir("/some/project")
        assert project_dir.exists()
        assert (project_dir / "chunks").exists()
        assert (project_dir / "summaries").exists()

    def test_same_project_path_same_dir(self, tmp_vault):
        dir1 = tmp_vault.get_project_dir("/some/project")
        dir2 = tmp_vault.get_project_dir("/some/project")
        assert dir1 == dir2

    def test_different_project_path_different_dir(self, tmp_vault):
        dir1 = tmp_vault.get_project_dir("/project/a")
        dir2 = tmp_vault.get_project_dir("/project/b")
        assert dir1 != dir2


class TestVaultStore:
    def test_store_chunk_returns_id(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="Some conversation context here",
            label="test chunk",
        )
        assert chunk_id.startswith("chunk_")

    def test_store_chunk_creates_files(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="Some conversation context here",
            label="test chunk",
        )
        project_dir = tmp_vault.get_project_dir("/my/project")
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        summary_file = project_dir / "summaries" / f"{chunk_id}.txt"
        assert chunk_file.exists()
        assert summary_file.exists()

    def test_store_chunk_content_is_correct(self, tmp_vault):
        content = "Discussed auth patterns. Decided on JWT."
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content=content,
            label="auth discussion",
        )
        project_dir = tmp_vault.get_project_dir("/my/project")
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        data = json.loads(chunk_file.read_text())
        assert data["content"] == content
        assert data["label"] == "auth discussion"
        assert data["id"] == chunk_id
        assert "timestamp" in data
        assert "keywords" in data
        assert "token_estimate" in data

    def test_store_updates_manifest(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="Some context",
            label="test",
        )
        manifest = tmp_vault.get_manifest("/my/project")
        assert chunk_id in manifest["chunks"]


class TestVaultRetrieve:
    def test_get_chunk_by_id(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="Auth middleware discussion",
            label="auth",
        )
        chunk = tmp_vault.get_chunk("/my/project", chunk_id)
        assert chunk["content"] == "Auth middleware discussion"

    def test_get_chunk_not_found(self, tmp_vault):
        result = tmp_vault.get_chunk("/my/project", "chunk_nonexistent")
        assert result is None

    def test_list_chunks(self, tmp_vault):
        tmp_vault.store(project_path="/my/project", content="First", label="one")
        tmp_vault.store(project_path="/my/project", content="Second", label="two")
        chunks = tmp_vault.list_chunks("/my/project")
        assert len(chunks) == 2

    def test_list_chunks_empty_project(self, tmp_vault):
        chunks = tmp_vault.list_chunks("/empty/project")
        assert chunks == []

    def test_delete_chunk(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="To delete",
            label="temp",
        )
        result = tmp_vault.delete_chunk("/my/project", chunk_id)
        assert result is True
        assert tmp_vault.get_chunk("/my/project", chunk_id) is None
        manifest = tmp_vault.get_manifest("/my/project")
        assert chunk_id not in manifest["chunks"]


class TestVaultSearch:
    def test_search_by_keyword(self, tmp_vault):
        tmp_vault.store(
            project_path="/my/project",
            content="Implemented JWT authentication with refresh tokens",
            label="auth impl",
        )
        tmp_vault.store(
            project_path="/my/project",
            content="Set up database migrations for PostgreSQL",
            label="db setup",
        )
        results = tmp_vault.search("/my/project", query="authentication JWT")
        assert len(results) >= 1
        assert "auth" in results[0]["label"].lower() or "jwt" in results[0]["summary"].lower()

    def test_search_returns_summaries(self, tmp_vault):
        tmp_vault.store(
            project_path="/my/project",
            content="Built the API endpoint for user registration",
            label="user registration",
        )
        results = tmp_vault.search("/my/project", query="registration")
        assert len(results) >= 1
        assert "summary" in results[0]
        assert "id" in results[0]

    def test_search_no_results(self, tmp_vault):
        tmp_vault.store(
            project_path="/my/project",
            content="Something about auth",
            label="auth",
        )
        results = tmp_vault.search("/my/project", query="kubernetes deployment")
        assert len(results) == 0
