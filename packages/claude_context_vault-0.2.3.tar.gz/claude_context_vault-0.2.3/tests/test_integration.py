"""End-to-end integration test — simulates a full context lifecycle."""

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from claude_context_vault.server import (
    archive_context,
    check_context_health,
    delete_chunk,
    get_chunk,
    list_archived,
    retrieve_context,
)


@pytest.fixture(autouse=True)
def tmp_vault_root(tmp_path):
    with patch("claude_context_vault.server._get_vault") as mock:
        from claude_context_vault.vault import ContextVault
        vault = ContextVault(vault_root=tmp_path)
        mock.return_value = vault
        yield vault


PROJECT = "/Users/test/my-project"


class TestEndToEndFlow:
    def test_full_context_lifecycle(self):
        """Simulate: work on feature A, archive it, work on feature B,
        retrieve feature A context when needed."""

        # 1. Check health — should be green with small context
        health = check_context_health(
            text="Starting work on authentication",
            project_path=PROJECT,
        )
        assert health["status"] == "green"
        assert health["archived_chunks"] == 0

        # 2. Archive feature A context (simulating large context)
        feature_a_context = (
            "Discussed authentication approach. Decided to use JWT with "
            "refresh tokens. Access token expires in 15 minutes, refresh "
            "token in 7 days. Modified src/auth/middleware.ts to validate "
            "tokens. Created src/auth/tokens.ts for token generation. "
            "Added rate limiting to login endpoint — max 5 attempts per "
            "minute per IP address."
        )
        archive_result = archive_context(
            text=feature_a_context,
            label="Feature A: JWT authentication implementation",
            project_path=PROJECT,
        )
        assert archive_result["chunk_id"] == "chunk_001"
        assert len(archive_result["summary"]) > 0

        # 3. Archive feature B context too
        feature_b_context = (
            "Set up PostgreSQL database with migrations. Created users "
            "table with columns: id, email, password_hash, created_at. "
            "Added unique index on email. Using alembic for migrations."
        )
        archive_context(
            text=feature_b_context,
            label="Feature B: database setup",
            project_path=PROJECT,
        )

        # 4. List all archived — should have 2 chunks
        listing = list_archived(project_path=PROJECT)
        assert listing["total_chunks"] == 2

        # 5. Retrieve context about auth (simulating: "how did we set up auth?")
        search_results = retrieve_context(
            query="authentication JWT tokens",
            project_path=PROJECT,
        )
        assert len(search_results["results"]) >= 1
        top_result = search_results["results"][0]
        assert "chunk_001" == top_result["id"]

        # 6. Pull full chunk for detail
        full_chunk = get_chunk(
            chunk_id="chunk_001",
            project_path=PROJECT,
        )
        assert "JWT" in full_chunk["content"]
        assert "refresh tokens" in full_chunk["content"]

        # 7. Delete old chunk
        delete_result = delete_chunk(chunk_id="chunk_001", project_path=PROJECT)
        assert delete_result["deleted"] is True

        # 8. Verify it's gone
        listing = list_archived(project_path=PROJECT)
        assert listing["total_chunks"] == 1
