# Claude Context Vault — Design Document

## Overview

`claude-context-vault` is a pip-installable Python extension for Claude Code that prevents
context loss during compaction. It archives old conversation context to a local vault,
provides retrieval tools so Claude can pull back relevant information on demand, and
keeps the active context window lean.

## Architecture

```
+--------------------------------------------------+
|                  Claude Code                      |
|                                                   |
|  +-----------+    +----------------------------+  |
|  |  Session   |<-->|  claude-context-vault MCP  |  |
|  |  Context   |    |  (local Python process)    |  |
|  +-----------+    +-------------+--------------+  |
|                                 |                  |
+--------------------------------------------------+
                                  |
                   +--------------v-----------------+
                   |  ~/.claude/context-vault/       |
                   |                                 |
                   |  +-- <project-hash>/            |
                   |  |   +-- manifest.json          |
                   |  |   +-- chunks/                |
                   |  |   |   +-- chunk_001.json     |
                   |  |   |   +-- chunk_002.json     |
                   |  |   +-- summaries/             |
                   |  |       +-- chunk_001.txt      |
                   |  |       +-- chunk_002.txt      |
                   |  +-- <another-project-hash>/    |
                   +--------------------------------+
```

### Components

1. **MCP Server** (`claude_context.server`) — Local Python process spawned by
   Claude Code via stdin/stdout. Exposes tools for archiving and retrieving context.
   No network, no ports, no hosting.

2. **Context Vault** (`claude_context.vault`) — File-based storage under
   `~/.claude/context-vault/`. Each project gets a directory keyed by a hash of
   the project path. Stores full context chunks as JSON and summaries as text.

3. **Health Monitor** (`claude_context.health`) — Token estimation using `tiktoken`.
   Reports context size and recommends actions (green/yellow/red status).

4. **Chunker** (`claude_context.chunker`) — Splits conversation text into storable
   chunks with metadata.

5. **Summarizer** (`claude_context.summarizer`) — Generates extractive summaries
   from context chunks. v1 uses heuristic extraction (first/last lines, key
   statements). v2 can swap in LLM-based summarization.

6. **CLI** (`claude_context.cli`) — `install` and `uninstall` commands that register
   the MCP server with Claude Code.

## MCP Tools

| Tool | Purpose | Input | Output |
|------|---------|-------|--------|
| `check_context_health` | Estimate context size, recommend action | Conversation text | Size estimate, status (green/yellow/red), recommendation |
| `archive_context` | Store old context in vault | Context text, optional label | Chunk ID, summary, confirmation |
| `retrieve_context` | Find relevant old context | Search query (keywords) | Matching summaries ranked by relevance |
| `list_archived` | Browse vault contents | Optional filter | List of chunks with summaries, timestamps, labels |
| `get_chunk` | Pull specific full chunk | Chunk ID | Full original context |
| `delete_chunk` | Remove old context | Chunk ID | Confirmation |

## Data Model

### Chunk (`chunks/chunk_001.json`)

```json
{
  "id": "chunk_001",
  "timestamp": "2026-03-07T14:30:00Z",
  "label": "authentication refactor discussion",
  "content": "...full conversation text...",
  "summary": "Discussed JWT vs session-based auth. Decided on JWT with refresh tokens. Modified src/auth/middleware.ts and src/auth/tokens.ts.",
  "keywords": ["auth", "jwt", "middleware", "tokens"],
  "token_estimate": 12400,
  "project": "/Users/you/project-name"
}
```

### Manifest (`manifest.json`)

```json
{
  "project_path": "/Users/you/project-name",
  "project_hash": "a1b2c3d4",
  "created": "2026-03-07T14:00:00Z",
  "chunks": ["chunk_001", "chunk_002"],
  "total_tokens_archived": 34800
}
```

## End-to-End Flow

```
SESSION TIMELINE
---

1. User starts session, works on Feature A
   Context: [########________] 30%

2. Context grows as work continues
   Context: [############____] 75%

3. check_context_health -> "Yellow: recommend archiving"

4. archive_context(text="...Feature A...", label="Feature A impl")
   -> Stores chunk_001 + summary in vault
   -> Returns: "Archived as chunk_001: Implemented auth middleware
     with JWT refresh tokens. Modified 4 files."

5. Claude compacts normally — important details are safe in vault
   Context: [####____________] 20%

6. Work continues on Feature B...
   Context: [############____] 75%

7. User asks: "how did we set up the auth middleware earlier?"

8. retrieve_context(query="auth middleware setup")
   -> Returns summary: "JWT auth with refresh tokens.
     Modified src/auth/middleware.ts. 15min token expiry, 7day refresh."

9. Claude has the understanding without loading full old context
   If needed: get_chunk("chunk_001") for full detail

10. Claude answers, continues Feature B
    Context: [#########_______] 55% (lean)
```

## Package Structure

```
claude-context-vault/
+-- pyproject.toml
+-- README.md
+-- LICENSE
+-- src/
|   +-- claude_context/
|       +-- __init__.py
|       +-- __main__.py          # Entry point (MCP server)
|       +-- server.py            # MCP server implementation
|       +-- vault.py             # Context vault read/write/search
|       +-- health.py            # Token estimation & health checks
|       +-- chunker.py           # Splits context into chunks
|       +-- summarizer.py        # Generates summaries
|       +-- cli.py               # install/uninstall commands
+-- tests/
|   +-- test_vault.py
|   +-- test_health.py
|   +-- test_chunker.py
|   +-- test_server.py
+-- docs/
    +-- plans/
```

## Dependencies (v1)

- `mcp` — Python MCP SDK for building the server
- `tiktoken` — Token counting for health checks
- Python 3.10+

No embedding libraries, no numpy, no external API calls. Pure local.

## Installation

```bash
pip install claude-context-vault
claude-context-vault install
```

The `install` command:
1. Adds the MCP server to `~/.claude/settings.json`
2. Creates `~/.claude/context-vault/` if it doesn't exist

Manual alternative:
```bash
pip install claude-context-vault
claude mcp add claude-context-vault -- python -m claude_context
```

Uninstall:
```bash
claude-context-vault uninstall
pip uninstall claude-context-vault
```

## v2 Roadmap

- Semantic search via embeddings (swap in at retrieval layer)
- Auto-archival via hooks (no manual trigger needed)
- Cross-project retrieval
- LLM-based summarization (optional, calls Claude API)
