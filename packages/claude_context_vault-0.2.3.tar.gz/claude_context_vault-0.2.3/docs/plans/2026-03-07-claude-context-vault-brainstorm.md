# Claude Context Vault — Brainstorm Notes

## Problem

Claude Code builds context as you work. As you give it more instructions, context
grows and results become less accurate. The current fix is automatic compaction,
which reduces context to fit more instructions — but compaction loses important
details.

## Core Idea

Instead of losing context when compacting, archive it to a local vault with
references. When old context is needed, retrieve just the relevant parts, understand
them, then return to current work without bloating the context window.

### Flow

1. User starts a Claude session
2. Context grows over time
3. Context approaches capacity — instead of compacting blindly, archive old context
   to a local vault with a summary and reference
4. Clear archived context from session, leave a lightweight reference
5. When old context is needed: retrieve the summary first, pull full chunk only if
   needed, fold the understanding back into current context

## Key Decisions

| Decision | Choice | Reasoning |
|----------|--------|-----------|
| Integration point | MCP server (local process) + hooks | MCP gives Claude tools to call; hooks automate detection. No hosting needed — runs via stdin/stdout |
| Retrieval sophistication | Start simple (keyword/recency), design for semantic search later | Keeps v1 dependency-light. Interface stays the same when embeddings are added |
| Context detection | Manual + automatic hybrid | Claude can call `check_context_health` anytime; hooks fire as safety net |
| Understanding format | Layered (summary + full chunk) | Fast scanning via summaries, full detail available on demand |
| Vault location | `~/.claude/context-vault/` centralized | Keeps projects clean, avoids accidental git commits, namespaced per project inside |
| Distribution | pip-installable Python package | `pip install claude-context-vault` + one command to register with Claude Code |

## Approaches Considered

### Retrieval Sophistication
- **A) Simple file-based** — keyword/recency search, no deps beyond stdlib
- **B) Semantic embeddings** — smarter retrieval, adds numpy + embedding deps
- **C) Start with A, design for B** — chosen. Ship simple, swap in embeddings later

### Context Detection
- **A) Token counting only** — estimate tokens, trigger at threshold
- **B) Hook-triggered only** — rely on Claude Code events
- **C) Manual + automatic hybrid** — chosen. Claude has awareness + safety net

### Understanding Format
- **A) Summaries only** — lightweight but lossy
- **B) Structured extractions** — rich but complex
- **C) Layered** — chosen. Summary for scanning, full chunk for deep dives

### Vault Location
- **A) In project (`.claude-context-vault/`)** — visible but clutters project
- **B) Centralized (`~/.claude/context-vault/`)** — chosen. Clean, no git risk
- **C) Per-project under Claude config** — considered but B with internal namespacing achieves the same
