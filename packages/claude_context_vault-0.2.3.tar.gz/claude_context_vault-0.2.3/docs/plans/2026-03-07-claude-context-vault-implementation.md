# Claude Context Vault Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a pip-installable Python MCP server that prevents context loss in Claude Code by archiving conversation context to a local vault with layered retrieval.

**Architecture:** Local MCP server (FastMCP over stdio) with file-based vault at `~/.claude/context-vault/`. Tools for archiving, retrieving, and monitoring context. Keyword/recency search v1, designed for future semantic search.

**Tech Stack:** Python 3.10+, `mcp` (FastMCP), `tiktoken`, pytest

---

### Task 1: Project Scaffolding

**Files:**
- Create: `pyproject.toml`
- Create: `src/claude_context/__init__.py`
- Create: `src/claude_context/__main__.py`

**Step 1: Create pyproject.toml**

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "claude-context-vault"
version = "0.1.0"
description = "Context vault extension for Claude Code — archive, retrieve, and manage conversation context"
readme = "README.md"
license = "MIT"
requires-python = ">=3.10"
dependencies = [
    "mcp>=1.0.0",
    "tiktoken>=0.7.0",
]

[project.scripts]
claude-context-vault = "claude_context.cli:main"

[tool.hatch.build.targets.wheel]
packages = ["src/claude_context"]

[tool.pytest.ini_options]
testpaths = ["tests"]
pythonpath = ["src"]
```

**Step 2: Create `src/claude_context/__init__.py`**

```python
"""Claude Context — context vault extension for Claude Code."""

__version__ = "0.1.0"
```

**Step 3: Create `src/claude_context/__main__.py`**

```python
"""Entry point for running claude-context-vault as an MCP server."""

from claude_context.server import mcp

def main():
    mcp.run()

if __name__ == "__main__":
    main()
```

**Step 4: Create empty test and source dirs**

```bash
mkdir -p tests
touch tests/__init__.py
```

**Step 5: Install in dev mode and verify**

```bash
cd /Users/akindeju/Documents/Work/Projects/claude-context
pip install -e ".[dev]" 2>/dev/null || pip install -e .
python -c "import claude_context; print(claude_context.__version__)"
```

Expected: `0.1.0`

**Step 6: Commit**

```bash
git init
echo "__pycache__/
*.egg-info/
dist/
.eggs/
*.pyc
.claude-context-vault/
.env
" > .gitignore
git add pyproject.toml src/ tests/ .gitignore
git commit -m "feat: project scaffolding with pyproject.toml and package structure"
```

---

### Task 2: Context Vault — Storage Layer

**Files:**
- Create: `tests/test_vault.py`
- Create: `src/claude_context/vault.py`

**Step 1: Write failing tests for vault**

```python
"""Tests for the context vault storage layer."""

import json
import os
import shutil
import tempfile
from pathlib import Path

import pytest

from claude_context.vault import ContextVault


@pytest.fixture
def tmp_vault(tmp_path):
    """Create a vault with a temporary root directory."""
    vault = ContextVault(vault_root=tmp_path)
    return vault


class TestVaultInit:
    def test_creates_vault_directory(self, tmp_path):
        root = tmp_path / "vault"
        vault = ContextVault(vault_root=root)
        assert root.exists()

    def test_creates_project_directory(self, tmp_vault):
        project_dir = tmp_vault.get_project_dir("/some/project")
        assert project_dir.exists()
        assert (project_dir / "chunks").exists()
        assert (project_dir / "summaries").exists()

    def test_same_project_path_same_dir(self, tmp_vault):
        dir1 = tmp_vault.get_project_dir("/some/project")
        dir2 = tmp_vault.get_project_dir("/some/project")
        assert dir1 == dir2

    def test_different_project_path_different_dir(self, tmp_vault):
        dir1 = tmp_vault.get_project_dir("/project/a")
        dir2 = tmp_vault.get_project_dir("/project/b")
        assert dir1 != dir2


class TestVaultStore:
    def test_store_chunk_returns_id(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="Some conversation context here",
            label="test chunk",
        )
        assert chunk_id.startswith("chunk_")

    def test_store_chunk_creates_files(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="Some conversation context here",
            label="test chunk",
        )
        project_dir = tmp_vault.get_project_dir("/my/project")
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        summary_file = project_dir / "summaries" / f"{chunk_id}.txt"
        assert chunk_file.exists()
        assert summary_file.exists()

    def test_store_chunk_content_is_correct(self, tmp_vault):
        content = "Discussed auth patterns. Decided on JWT."
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content=content,
            label="auth discussion",
        )
        project_dir = tmp_vault.get_project_dir("/my/project")
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        data = json.loads(chunk_file.read_text())
        assert data["content"] == content
        assert data["label"] == "auth discussion"
        assert data["id"] == chunk_id
        assert "timestamp" in data
        assert "keywords" in data
        assert "token_estimate" in data

    def test_store_updates_manifest(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="Some context",
            label="test",
        )
        manifest = tmp_vault.get_manifest("/my/project")
        assert chunk_id in manifest["chunks"]


class TestVaultRetrieve:
    def test_get_chunk_by_id(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="Auth middleware discussion",
            label="auth",
        )
        chunk = tmp_vault.get_chunk("/my/project", chunk_id)
        assert chunk["content"] == "Auth middleware discussion"

    def test_get_chunk_not_found(self, tmp_vault):
        result = tmp_vault.get_chunk("/my/project", "chunk_nonexistent")
        assert result is None

    def test_list_chunks(self, tmp_vault):
        tmp_vault.store(project_path="/my/project", content="First", label="one")
        tmp_vault.store(project_path="/my/project", content="Second", label="two")
        chunks = tmp_vault.list_chunks("/my/project")
        assert len(chunks) == 2

    def test_list_chunks_empty_project(self, tmp_vault):
        chunks = tmp_vault.list_chunks("/empty/project")
        assert chunks == []

    def test_delete_chunk(self, tmp_vault):
        chunk_id = tmp_vault.store(
            project_path="/my/project",
            content="To delete",
            label="temp",
        )
        result = tmp_vault.delete_chunk("/my/project", chunk_id)
        assert result is True
        assert tmp_vault.get_chunk("/my/project", chunk_id) is None
        manifest = tmp_vault.get_manifest("/my/project")
        assert chunk_id not in manifest["chunks"]


class TestVaultSearch:
    def test_search_by_keyword(self, tmp_vault):
        tmp_vault.store(
            project_path="/my/project",
            content="Implemented JWT authentication with refresh tokens",
            label="auth impl",
        )
        tmp_vault.store(
            project_path="/my/project",
            content="Set up database migrations for PostgreSQL",
            label="db setup",
        )
        results = tmp_vault.search("/my/project", query="authentication JWT")
        assert len(results) >= 1
        assert "auth" in results[0]["label"].lower() or "jwt" in results[0]["summary"].lower()

    def test_search_returns_summaries(self, tmp_vault):
        tmp_vault.store(
            project_path="/my/project",
            content="Built the API endpoint for user registration",
            label="user registration",
        )
        results = tmp_vault.search("/my/project", query="registration")
        assert len(results) >= 1
        assert "summary" in results[0]
        assert "id" in results[0]

    def test_search_no_results(self, tmp_vault):
        tmp_vault.store(
            project_path="/my/project",
            content="Something about auth",
            label="auth",
        )
        results = tmp_vault.search("/my/project", query="kubernetes deployment")
        assert len(results) == 0
```

**Step 2: Run tests to verify they fail**

```bash
cd /Users/akindeju/Documents/Work/Projects/claude-context
python -m pytest tests/test_vault.py -v
```

Expected: FAIL — `ModuleNotFoundError: No module named 'claude_context.vault'`

**Step 3: Implement the vault**

```python
"""Context vault — file-based storage for archived conversation context."""

import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import tiktoken


class ContextVault:
    """Manages storage and retrieval of archived context chunks."""

    def __init__(self, vault_root: Optional[Path] = None):
        if vault_root is None:
            vault_root = Path.home() / ".claude" / "context-vault"
        self.vault_root = Path(vault_root)
        self.vault_root.mkdir(parents=True, exist_ok=True)
        self._encoder = None

    @property
    def encoder(self):
        if self._encoder is None:
            self._encoder = tiktoken.get_encoding("cl100k_base")
        return self._encoder

    def _project_hash(self, project_path: str) -> str:
        return hashlib.sha256(project_path.encode()).hexdigest()[:12]

    def get_project_dir(self, project_path: str) -> Path:
        project_hash = self._project_hash(project_path)
        project_dir = self.vault_root / project_hash
        project_dir.mkdir(parents=True, exist_ok=True)
        (project_dir / "chunks").mkdir(exist_ok=True)
        (project_dir / "summaries").mkdir(exist_ok=True)
        return project_dir

    def _next_chunk_id(self, project_path: str) -> str:
        manifest = self.get_manifest(project_path)
        existing = manifest.get("chunks", [])
        num = len(existing) + 1
        return f"chunk_{num:03d}"

    def _extract_keywords(self, text: str) -> list[str]:
        stop_words = {
            "the", "a", "an", "is", "are", "was", "were", "be", "been",
            "being", "have", "has", "had", "do", "does", "did", "will",
            "would", "could", "should", "may", "might", "can", "shall",
            "to", "of", "in", "for", "on", "with", "at", "by", "from",
            "as", "into", "through", "during", "before", "after", "and",
            "but", "or", "nor", "not", "so", "yet", "both", "either",
            "neither", "each", "every", "all", "any", "few", "more",
            "most", "other", "some", "such", "no", "only", "own", "same",
            "than", "too", "very", "just", "about", "above", "also",
            "this", "that", "these", "those", "i", "we", "you", "it",
            "they", "me", "him", "her", "us", "them", "my", "your",
            "his", "its", "our", "their", "what", "which", "who", "whom",
        }
        words = re.findall(r"[a-zA-Z][a-zA-Z0-9_.-]+", text.lower())
        freq: dict[str, int] = {}
        for w in words:
            if w not in stop_words and len(w) > 2:
                freq[w] = freq.get(w, 0) + 1
        sorted_words = sorted(freq, key=lambda w: freq[w], reverse=True)
        return sorted_words[:20]

    def _generate_summary(self, content: str) -> str:
        lines = [l.strip() for l in content.strip().splitlines() if l.strip()]
        if not lines:
            return ""
        if len(lines) <= 3:
            return " ".join(lines)
        summary_lines = []
        summary_lines.append(lines[0])
        mid = len(lines) // 2
        summary_lines.append(lines[mid])
        summary_lines.append(lines[-1])
        return " ".join(summary_lines)

    def _count_tokens(self, text: str) -> int:
        return len(self.encoder.encode(text))

    def get_manifest(self, project_path: str) -> dict:
        project_dir = self.get_project_dir(project_path)
        manifest_file = project_dir / "manifest.json"
        if manifest_file.exists():
            return json.loads(manifest_file.read_text())
        return {
            "project_path": project_path,
            "project_hash": self._project_hash(project_path),
            "created": datetime.now(timezone.utc).isoformat(),
            "chunks": [],
            "total_tokens_archived": 0,
        }

    def _save_manifest(self, project_path: str, manifest: dict) -> None:
        project_dir = self.get_project_dir(project_path)
        manifest_file = project_dir / "manifest.json"
        manifest_file.write_text(json.dumps(manifest, indent=2))

    def store(self, project_path: str, content: str, label: str) -> str:
        chunk_id = self._next_chunk_id(project_path)
        summary = self._generate_summary(content)
        keywords = self._extract_keywords(content)
        token_estimate = self._count_tokens(content)

        chunk_data = {
            "id": chunk_id,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "label": label,
            "content": content,
            "summary": summary,
            "keywords": keywords,
            "token_estimate": token_estimate,
            "project": project_path,
        }

        project_dir = self.get_project_dir(project_path)
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        chunk_file.write_text(json.dumps(chunk_data, indent=2))

        summary_file = project_dir / "summaries" / f"{chunk_id}.txt"
        summary_file.write_text(summary)

        manifest = self.get_manifest(project_path)
        manifest["chunks"].append(chunk_id)
        manifest["total_tokens_archived"] += token_estimate
        self._save_manifest(project_path, manifest)

        return chunk_id

    def get_chunk(self, project_path: str, chunk_id: str) -> Optional[dict]:
        project_dir = self.get_project_dir(project_path)
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        if not chunk_file.exists():
            return None
        return json.loads(chunk_file.read_text())

    def list_chunks(self, project_path: str) -> list[dict]:
        project_dir = self.get_project_dir(project_path)
        chunks_dir = project_dir / "chunks"
        if not chunks_dir.exists():
            return []
        results = []
        for f in sorted(chunks_dir.glob("chunk_*.json")):
            data = json.loads(f.read_text())
            results.append({
                "id": data["id"],
                "label": data["label"],
                "summary": data["summary"],
                "timestamp": data["timestamp"],
                "token_estimate": data["token_estimate"],
            })
        return results

    def delete_chunk(self, project_path: str, chunk_id: str) -> bool:
        project_dir = self.get_project_dir(project_path)
        chunk_file = project_dir / "chunks" / f"{chunk_id}.json"
        summary_file = project_dir / "summaries" / f"{chunk_id}.txt"
        if not chunk_file.exists():
            return False
        chunk_data = json.loads(chunk_file.read_text())
        chunk_file.unlink()
        if summary_file.exists():
            summary_file.unlink()
        manifest = self.get_manifest(project_path)
        if chunk_id in manifest["chunks"]:
            manifest["chunks"].remove(chunk_id)
            manifest["total_tokens_archived"] -= chunk_data.get("token_estimate", 0)
            self._save_manifest(project_path, manifest)
        return True

    def search(self, project_path: str, query: str, limit: int = 5) -> list[dict]:
        chunks = self.list_chunks(project_path)
        if not chunks:
            return []
        query_words = set(re.findall(r"[a-zA-Z][a-zA-Z0-9_.-]+", query.lower()))
        scored = []
        for chunk_meta in chunks:
            full_chunk = self.get_chunk(project_path, chunk_meta["id"])
            if full_chunk is None:
                continue
            chunk_keywords = set(full_chunk.get("keywords", []))
            label_words = set(re.findall(r"[a-zA-Z][a-zA-Z0-9_.-]+", full_chunk["label"].lower()))
            summary_words = set(re.findall(r"[a-zA-Z][a-zA-Z0-9_.-]+", full_chunk["summary"].lower()))
            searchable = chunk_keywords | label_words | summary_words
            overlap = query_words & searchable
            if overlap:
                score = len(overlap) / len(query_words) if query_words else 0
                scored.append({
                    "id": full_chunk["id"],
                    "label": full_chunk["label"],
                    "summary": full_chunk["summary"],
                    "timestamp": full_chunk["timestamp"],
                    "token_estimate": full_chunk["token_estimate"],
                    "relevance": round(score, 2),
                })
        scored.sort(key=lambda x: x["relevance"], reverse=True)
        return scored[:limit]
```

**Step 4: Run tests to verify they pass**

```bash
python -m pytest tests/test_vault.py -v
```

Expected: ALL PASS

**Step 5: Commit**

```bash
git add src/claude_context/vault.py tests/test_vault.py
git commit -m "feat: context vault storage layer with store, retrieve, search, and delete"
```

---

### Task 3: Health Monitor — Token Estimation

**Files:**
- Create: `tests/test_health.py`
- Create: `src/claude_context/health.py`

**Step 1: Write failing tests**

```python
"""Tests for context health monitoring."""

import pytest

from claude_context.health import ContextHealth


@pytest.fixture
def health():
    return ContextHealth()


class TestTokenEstimation:
    def test_estimate_tokens_short_text(self, health):
        tokens = health.estimate_tokens("Hello world")
        assert tokens > 0
        assert tokens < 10

    def test_estimate_tokens_empty(self, health):
        tokens = health.estimate_tokens("")
        assert tokens == 0

    def test_estimate_tokens_long_text(self, health):
        text = "word " * 1000
        tokens = health.estimate_tokens(text)
        assert tokens > 500


class TestHealthCheck:
    def test_green_status(self, health):
        small_text = "Short context" * 10
        result = health.check(small_text)
        assert result["status"] == "green"

    def test_yellow_status(self, health):
        # ~80k tokens worth of text
        text = "word " * 60000
        result = health.check(text, max_tokens=100000)
        assert result["status"] == "yellow"

    def test_red_status(self, health):
        text = "word " * 80000
        result = health.check(text, max_tokens=100000)
        assert result["status"] == "red"

    def test_result_has_fields(self, health):
        result = health.check("Some text")
        assert "token_estimate" in result
        assert "status" in result
        assert "recommendation" in result
        assert "percentage" in result
```

**Step 2: Run tests to verify they fail**

```bash
python -m pytest tests/test_health.py -v
```

Expected: FAIL

**Step 3: Implement health monitor**

```python
"""Context health monitoring — token estimation and status checks."""

import tiktoken


class ContextHealth:
    """Estimates token count and reports context health status."""

    DEFAULT_MAX_TOKENS = 200000  # Claude's context window

    def __init__(self):
        self._encoder = None

    @property
    def encoder(self):
        if self._encoder is None:
            self._encoder = tiktoken.get_encoding("cl100k_base")
        return self._encoder

    def estimate_tokens(self, text: str) -> int:
        if not text:
            return 0
        return len(self.encoder.encode(text))

    def check(self, text: str, max_tokens: int | None = None) -> dict:
        max_tokens = max_tokens or self.DEFAULT_MAX_TOKENS
        token_count = self.estimate_tokens(text)
        percentage = (token_count / max_tokens) * 100 if max_tokens > 0 else 0

        if percentage >= 75:
            status = "red"
            recommendation = (
                "Context is critically full. Archive old context immediately "
                "using archive_context to prevent loss during compaction."
            )
        elif percentage >= 50:
            status = "yellow"
            recommendation = (
                "Context is growing large. Consider archiving older conversation "
                "segments using archive_context to keep the session lean."
            )
        else:
            status = "green"
            recommendation = "Context size is healthy. No action needed."

        return {
            "token_estimate": token_count,
            "max_tokens": max_tokens,
            "percentage": round(percentage, 1),
            "status": status,
            "recommendation": recommendation,
        }
```

**Step 4: Run tests to verify they pass**

```bash
python -m pytest tests/test_health.py -v
```

Expected: ALL PASS

**Step 5: Commit**

```bash
git add src/claude_context/health.py tests/test_health.py
git commit -m "feat: context health monitor with token estimation and status checks"
```

---

### Task 4: MCP Server — Tool Definitions

**Files:**
- Create: `tests/test_server.py`
- Create: `src/claude_context/server.py`

**Step 1: Write failing tests**

```python
"""Tests for the MCP server tool implementations."""

import json
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from claude_context.server import (
    archive_context,
    check_context_health,
    delete_chunk,
    get_chunk,
    list_archived,
    retrieve_context,
)


@pytest.fixture(autouse=True)
def tmp_vault_root(tmp_path):
    """Override vault root for all server tests."""
    with patch("claude_context.server._get_vault") as mock:
        from claude_context.vault import ContextVault
        vault = ContextVault(vault_root=tmp_path)
        mock.return_value = vault
        yield vault


class TestCheckContextHealth:
    def test_returns_status(self):
        result = check_context_health(text="Hello world", project_path="/test")
        assert "status" in result
        assert "token_estimate" in result
        assert "recommendation" in result


class TestArchiveContext:
    def test_archives_and_returns_id(self):
        result = archive_context(
            text="Long conversation about auth patterns",
            label="auth discussion",
            project_path="/test",
        )
        assert "chunk_id" in result
        assert "summary" in result
        assert result["chunk_id"].startswith("chunk_")

    def test_archive_then_retrieve(self):
        archive_result = archive_context(
            text="Implemented JWT authentication with refresh tokens for the API",
            label="jwt auth",
            project_path="/test",
        )
        results = retrieve_context(query="JWT authentication", project_path="/test")
        assert len(results["results"]) >= 1


class TestRetrieveContext:
    def test_returns_results_list(self):
        archive_context(
            text="Database migration setup for PostgreSQL",
            label="db migrations",
            project_path="/test",
        )
        result = retrieve_context(query="database", project_path="/test")
        assert "results" in result
        assert len(result["results"]) >= 1

    def test_no_results(self):
        result = retrieve_context(query="nonexistent topic", project_path="/test")
        assert result["results"] == []


class TestListArchived:
    def test_lists_chunks(self):
        archive_context(text="First chunk", label="one", project_path="/test")
        archive_context(text="Second chunk", label="two", project_path="/test")
        result = list_archived(project_path="/test")
        assert len(result["chunks"]) == 2

    def test_empty_list(self):
        result = list_archived(project_path="/test")
        assert result["chunks"] == []


class TestGetChunk:
    def test_get_existing_chunk(self):
        archive_result = archive_context(
            text="Some important context",
            label="important",
            project_path="/test",
        )
        result = get_chunk(
            chunk_id=archive_result["chunk_id"],
            project_path="/test",
        )
        assert result["content"] == "Some important context"

    def test_get_nonexistent_chunk(self):
        result = get_chunk(chunk_id="chunk_999", project_path="/test")
        assert "error" in result


class TestDeleteChunk:
    def test_delete_existing(self):
        archive_result = archive_context(
            text="To be deleted",
            label="temp",
            project_path="/test",
        )
        result = delete_chunk(
            chunk_id=archive_result["chunk_id"],
            project_path="/test",
        )
        assert result["deleted"] is True

    def test_delete_nonexistent(self):
        result = delete_chunk(chunk_id="chunk_999", project_path="/test")
        assert result["deleted"] is False
```

**Step 2: Run tests to verify they fail**

```bash
python -m pytest tests/test_server.py -v
```

Expected: FAIL

**Step 3: Implement the MCP server**

```python
"""MCP server exposing context vault tools to Claude Code."""

from mcp.server.fastmcp import FastMCP

from claude_context.health import ContextHealth
from claude_context.vault import ContextVault

mcp = FastMCP("claude-context-vault")

_vault: ContextVault | None = None
_health = ContextHealth()


def _get_vault() -> ContextVault:
    global _vault
    if _vault is None:
        _vault = ContextVault()
    return _vault


@mcp.tool()
def check_context_health(text: str, project_path: str, max_tokens: int = 200000) -> dict:
    """Check the health of the current context. Returns token estimate, status
    (green/yellow/red), and a recommendation. Call this to decide whether to
    archive old context.

    Args:
        text: The current conversation/context text to analyze.
        project_path: The absolute path to the current project.
        max_tokens: Maximum token capacity (default 200000 for Claude).
    """
    result = _health.check(text, max_tokens=max_tokens)
    vault = _get_vault()
    manifest = vault.get_manifest(project_path)
    result["archived_chunks"] = len(manifest.get("chunks", []))
    result["total_tokens_archived"] = manifest.get("total_tokens_archived", 0)
    return result


@mcp.tool()
def archive_context(text: str, label: str, project_path: str) -> dict:
    """Archive conversation context to the vault before it gets compacted.
    Stores the full text and generates a summary for quick retrieval later.

    Args:
        text: The conversation context to archive.
        label: A short descriptive label (e.g., "auth middleware discussion").
        project_path: The absolute path to the current project.
    """
    vault = _get_vault()
    chunk_id = vault.store(
        project_path=project_path,
        content=text,
        label=label,
    )
    chunk = vault.get_chunk(project_path, chunk_id)
    return {
        "chunk_id": chunk_id,
        "summary": chunk["summary"],
        "token_estimate": chunk["token_estimate"],
        "message": f"Archived as {chunk_id}. Summary and full content stored in vault.",
    }


@mcp.tool()
def retrieve_context(query: str, project_path: str, limit: int = 5) -> dict:
    """Search archived context by keywords. Returns summaries of matching chunks,
    ranked by relevance. Use get_chunk to pull full content if a summary isn't enough.

    Args:
        query: Search keywords (e.g., "auth middleware JWT").
        project_path: The absolute path to the current project.
        limit: Maximum number of results to return (default 5).
    """
    vault = _get_vault()
    results = vault.search(project_path, query=query, limit=limit)
    return {
        "query": query,
        "results": results,
        "hint": "Use get_chunk with a chunk_id to retrieve full content if needed.",
    }


@mcp.tool()
def list_archived(project_path: str) -> dict:
    """List all archived context chunks for the current project.

    Args:
        project_path: The absolute path to the current project.
    """
    vault = _get_vault()
    chunks = vault.list_chunks(project_path)
    manifest = vault.get_manifest(project_path)
    return {
        "chunks": chunks,
        "total_chunks": len(chunks),
        "total_tokens_archived": manifest.get("total_tokens_archived", 0),
    }


@mcp.tool()
def get_chunk(chunk_id: str, project_path: str) -> dict:
    """Retrieve the full content of a specific archived chunk. Use this when
    a summary from retrieve_context isn't detailed enough.

    Args:
        chunk_id: The chunk ID (e.g., "chunk_001").
        project_path: The absolute path to the current project.
    """
    vault = _get_vault()
    chunk = vault.get_chunk(project_path, chunk_id)
    if chunk is None:
        return {"error": f"Chunk {chunk_id} not found."}
    return chunk


@mcp.tool()
def delete_chunk(chunk_id: str, project_path: str) -> dict:
    """Delete an archived chunk that is no longer needed.

    Args:
        chunk_id: The chunk ID to delete (e.g., "chunk_001").
        project_path: The absolute path to the current project.
    """
    vault = _get_vault()
    success = vault.delete_chunk(project_path, chunk_id)
    return {
        "deleted": success,
        "chunk_id": chunk_id,
        "message": f"Chunk {chunk_id} deleted." if success else f"Chunk {chunk_id} not found.",
    }
```

**Step 4: Run tests to verify they pass**

```bash
python -m pytest tests/test_server.py -v
```

Expected: ALL PASS

**Step 5: Commit**

```bash
git add src/claude_context/server.py tests/test_server.py
git commit -m "feat: MCP server with 6 context management tools"
```

---

### Task 5: CLI — Install & Uninstall Commands

**Files:**
- Create: `tests/test_cli.py`
- Create: `src/claude_context/cli.py`

**Step 1: Write failing tests**

```python
"""Tests for the CLI install/uninstall commands."""

import json
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from claude_context.cli import do_install, do_uninstall


@pytest.fixture
def mock_claude_dir(tmp_path):
    """Create a fake ~/.claude directory."""
    claude_dir = tmp_path / ".claude"
    claude_dir.mkdir()
    settings = claude_dir / "settings.json"
    settings.write_text(json.dumps({"mcpServers": {}}))
    return claude_dir


class TestInstall:
    def test_adds_mcp_server_to_settings(self, mock_claude_dir):
        settings_file = mock_claude_dir / "settings.json"
        do_install(claude_dir=mock_claude_dir)
        settings = json.loads(settings_file.read_text())
        assert "claude-context-vault" in settings["mcpServers"]
        server_config = settings["mcpServers"]["claude-context-vault"]
        assert server_config["command"] == sys.executable
        assert "-m" in server_config["args"]
        assert "claude_context" in server_config["args"]

    def test_creates_vault_directory(self, mock_claude_dir):
        do_install(claude_dir=mock_claude_dir)
        vault_dir = mock_claude_dir / "context-vault"
        assert vault_dir.exists()

    def test_creates_settings_if_missing(self, tmp_path):
        claude_dir = tmp_path / ".claude"
        claude_dir.mkdir()
        do_install(claude_dir=claude_dir)
        settings_file = claude_dir / "settings.json"
        assert settings_file.exists()

    def test_preserves_existing_settings(self, mock_claude_dir):
        settings_file = mock_claude_dir / "settings.json"
        settings_file.write_text(json.dumps({
            "mcpServers": {"other-server": {"command": "other"}},
            "customSetting": True,
        }))
        do_install(claude_dir=mock_claude_dir)
        settings = json.loads(settings_file.read_text())
        assert "other-server" in settings["mcpServers"]
        assert settings["customSetting"] is True


class TestUninstall:
    def test_removes_mcp_server(self, mock_claude_dir):
        do_install(claude_dir=mock_claude_dir)
        do_uninstall(claude_dir=mock_claude_dir)
        settings_file = mock_claude_dir / "settings.json"
        settings = json.loads(settings_file.read_text())
        assert "claude-context-vault" not in settings["mcpServers"]

    def test_uninstall_when_not_installed(self, mock_claude_dir):
        # Should not raise
        do_uninstall(claude_dir=mock_claude_dir)
```

**Step 2: Run tests to verify they fail**

```bash
python -m pytest tests/test_cli.py -v
```

Expected: FAIL

**Step 3: Implement CLI**

```python
"""CLI for installing and uninstalling claude-context-vault with Claude Code."""

import json
import sys
from pathlib import Path


def do_install(claude_dir: Path | None = None) -> None:
    """Register claude-context-vault as an MCP server with Claude Code."""
    if claude_dir is None:
        claude_dir = Path.home() / ".claude"
    claude_dir.mkdir(parents=True, exist_ok=True)

    # Create vault directory
    vault_dir = claude_dir / "context-vault"
    vault_dir.mkdir(parents=True, exist_ok=True)

    # Update settings
    settings_file = claude_dir / "settings.json"
    if settings_file.exists():
        settings = json.loads(settings_file.read_text())
    else:
        settings = {}

    if "mcpServers" not in settings:
        settings["mcpServers"] = {}

    settings["mcpServers"]["claude-context-vault"] = {
        "command": sys.executable,
        "args": ["-m", "claude_context"],
    }

    settings_file.write_text(json.dumps(settings, indent=2))
    print(f"claude-context-vault installed successfully.")
    print(f"  MCP server registered in: {settings_file}")
    print(f"  Context vault directory: {vault_dir}")


def do_uninstall(claude_dir: Path | None = None) -> None:
    """Remove claude-context-vault MCP server registration from Claude Code."""
    if claude_dir is None:
        claude_dir = Path.home() / ".claude"

    settings_file = claude_dir / "settings.json"
    if not settings_file.exists():
        print("Nothing to uninstall — no Claude settings found.")
        return

    settings = json.loads(settings_file.read_text())
    servers = settings.get("mcpServers", {})
    if "claude-context-vault" in servers:
        del servers["claude-context-vault"]
        settings_file.write_text(json.dumps(settings, indent=2))
        print("claude-context-vault uninstalled successfully.")
    else:
        print("claude-context-vault was not installed.")


def main():
    """CLI entry point."""
    import argparse

    parser = argparse.ArgumentParser(
        prog="claude-context-vault",
        description="Context vault extension for Claude Code",
    )
    subparsers = parser.add_subparsers(dest="command")

    subparsers.add_parser("install", help="Register with Claude Code")
    subparsers.add_parser("uninstall", help="Remove from Claude Code")

    args = parser.parse_args()

    if args.command == "install":
        do_install()
    elif args.command == "uninstall":
        do_uninstall()
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
```

**Step 4: Run tests to verify they pass**

```bash
python -m pytest tests/test_cli.py -v
```

Expected: ALL PASS

**Step 5: Commit**

```bash
git add src/claude_context/cli.py tests/test_cli.py
git commit -m "feat: CLI install/uninstall commands for Claude Code registration"
```

---

### Task 6: Integration Test — End-to-End Flow

**Files:**
- Create: `tests/test_integration.py`

**Step 1: Write the integration test**

```python
"""End-to-end integration test — simulates a full context lifecycle."""

import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

from claude_context.server import (
    archive_context,
    check_context_health,
    delete_chunk,
    get_chunk,
    list_archived,
    retrieve_context,
)


@pytest.fixture(autouse=True)
def tmp_vault_root(tmp_path):
    with patch("claude_context.server._get_vault") as mock:
        from claude_context.vault import ContextVault
        vault = ContextVault(vault_root=tmp_path)
        mock.return_value = vault
        yield vault


PROJECT = "/Users/test/my-project"


class TestEndToEndFlow:
    def test_full_context_lifecycle(self):
        """Simulate: work on feature A, archive it, work on feature B,
        retrieve feature A context when needed."""

        # 1. Check health — should be green with small context
        health = check_context_health(
            text="Starting work on authentication",
            project_path=PROJECT,
        )
        assert health["status"] == "green"
        assert health["archived_chunks"] == 0

        # 2. Archive feature A context (simulating large context)
        feature_a_context = (
            "Discussed authentication approach. Decided to use JWT with "
            "refresh tokens. Access token expires in 15 minutes, refresh "
            "token in 7 days. Modified src/auth/middleware.ts to validate "
            "tokens. Created src/auth/tokens.ts for token generation. "
            "Added rate limiting to login endpoint — max 5 attempts per "
            "minute per IP address."
        )
        archive_result = archive_context(
            text=feature_a_context,
            label="Feature A: JWT authentication implementation",
            project_path=PROJECT,
        )
        assert archive_result["chunk_id"] == "chunk_001"
        assert len(archive_result["summary"]) > 0

        # 3. Archive feature B context too
        feature_b_context = (
            "Set up PostgreSQL database with migrations. Created users "
            "table with columns: id, email, password_hash, created_at. "
            "Added unique index on email. Using alembic for migrations."
        )
        archive_context(
            text=feature_b_context,
            label="Feature B: database setup",
            project_path=PROJECT,
        )

        # 4. List all archived — should have 2 chunks
        listing = list_archived(project_path=PROJECT)
        assert listing["total_chunks"] == 2

        # 5. Retrieve context about auth (simulating: "how did we set up auth?")
        search_results = retrieve_context(
            query="authentication JWT tokens",
            project_path=PROJECT,
        )
        assert len(search_results["results"]) >= 1
        top_result = search_results["results"][0]
        assert "chunk_001" == top_result["id"]

        # 6. Pull full chunk for detail
        full_chunk = get_chunk(
            chunk_id="chunk_001",
            project_path=PROJECT,
        )
        assert "JWT" in full_chunk["content"]
        assert "refresh tokens" in full_chunk["content"]

        # 7. Delete old chunk
        delete_result = delete_chunk(chunk_id="chunk_001", project_path=PROJECT)
        assert delete_result["deleted"] is True

        # 8. Verify it's gone
        listing = list_archived(project_path=PROJECT)
        assert listing["total_chunks"] == 1
```

**Step 2: Run integration test**

```bash
python -m pytest tests/test_integration.py -v
```

Expected: ALL PASS

**Step 3: Run full test suite**

```bash
python -m pytest tests/ -v
```

Expected: ALL PASS

**Step 4: Commit**

```bash
git add tests/test_integration.py
git commit -m "test: end-to-end integration test for full context lifecycle"
```

---

### Task 7: README & Final Polish

**Files:**
- Create: `README.md`
- Create: `LICENSE`

**Step 1: Write README**

```markdown
# claude-context-vault

Context vault extension for Claude Code. Prevents context loss during compaction by
archiving conversation context to a local vault with layered retrieval.

## The Problem

Claude Code builds context as you work. When context gets too large, it compacts —
and important details can be lost. You lose track of earlier decisions, code changes,
and discussions.

## The Solution

`claude-context-vault` archives old conversation context to a local vault before it gets
compacted. When you need that old context back, Claude retrieves just the relevant
parts — summaries for quick answers, full chunks for deep dives.

## Install

```bash
pip install claude-context-vault
claude-context-vault install
```

That's it. The install command registers the MCP server with Claude Code and creates
the vault directory at `~/.claude/context-vault/`.

## How It Works

Once installed, Claude Code gains 6 new tools:

| Tool | What it does |
|------|-------------|
| `check_context_health` | Estimates context size, reports green/yellow/red status |
| `archive_context` | Stores conversation context in the vault with a summary |
| `retrieve_context` | Searches archived context by keywords |
| `list_archived` | Shows all archived chunks for the current project |
| `get_chunk` | Pulls full content of a specific archived chunk |
| `delete_chunk` | Removes an archived chunk |

## Usage

Claude will use these tools during your session. When context grows large:

1. `check_context_health` reports yellow/red status
2. Claude archives older context with `archive_context`
3. After compaction, the important details are safe in the vault
4. When old context is needed, `retrieve_context` finds it by keywords
5. If the summary isn't enough, `get_chunk` pulls the full original

## Vault Location

All archived context is stored locally at `~/.claude/context-vault/`, organized by
project. Nothing is sent to any server.

## Uninstall

```bash
claude-context-vault uninstall
pip uninstall claude-context-vault
```

## License

MIT
```

**Step 2: Write LICENSE**

Create an MIT license file with the current year and the user's name.

**Step 3: Run full test suite one final time**

```bash
python -m pytest tests/ -v
```

Expected: ALL PASS

**Step 4: Commit**

```bash
git add README.md LICENSE
git commit -m "docs: README and LICENSE"
```

---

## Task Summary

| Task | Component | Tests | Files |
|------|-----------|-------|-------|
| 1 | Project scaffolding | - | pyproject.toml, __init__.py, __main__.py |
| 2 | Context vault | 15 tests | vault.py, test_vault.py |
| 3 | Health monitor | 7 tests | health.py, test_health.py |
| 4 | MCP server | 10 tests | server.py, test_server.py |
| 5 | CLI install/uninstall | 6 tests | cli.py, test_cli.py |
| 6 | Integration test | 1 test | test_integration.py |
| 7 | README & LICENSE | - | README.md, LICENSE |

**Total: 7 tasks, ~39 tests, 7 commits**
