# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.2.3] - 2026-03-07

### Changed
- Added GitHub and PyPI links to README
- Added note about viewing architecture diagram on GitHub (PyPI can't render Mermaid)
- Renamed Python module from `claude_context` to `claude_context_vault`

## [0.2.2] - 2026-03-07

### Changed
- Added architecture diagram and usage workflow to README

## [0.2.1] - 2026-03-07

### Changed
- Updated all internal documentation references from `claude-context` to `claude-context-vault`
- Renamed plan documents to match new package name

## [0.2.0] - 2026-03-07

### Changed
- Renamed package from `claude-context` to `claude-context-vault` (PyPI availability)

## [0.1.0] - 2026-03-07

### Added
- Context vault storage layer with file-based archiving
- Health monitor with token estimation and green/yellow/red status
- MCP server with 6 tools: check_context_health, archive_context, retrieve_context, list_archived, get_chunk, delete_chunk
- CLI with install/uninstall commands for Claude Code registration
- Keyword-based search with relevance scoring
- Per-project context isolation using hashed directories
- End-to-end integration tests
