"""MCP server exposing context vault tools to Claude Code."""

from mcp.server.fastmcp import FastMCP

from claude_context_vault.health import ContextHealth
from claude_context_vault.vault import ContextVault

mcp = FastMCP("claude-context-vault")

_vault: ContextVault | None = None
_health = ContextHealth()


def _get_vault() -> ContextVault:
    global _vault
    if _vault is None:
        _vault = ContextVault()
    return _vault


@mcp.tool()
def check_context_health(text: str, project_path: str, max_tokens: int = 200000) -> dict:
    """Check the health of the current context. Returns token estimate, status
    (green/yellow/red), and a recommendation. Call this to decide whether to
    archive old context.

    Args:
        text: The current conversation/context text to analyze.
        project_path: The absolute path to the current project.
        max_tokens: Maximum token capacity (default 200000 for Claude).
    """
    result = _health.check(text, max_tokens=max_tokens)
    vault = _get_vault()
    manifest = vault.get_manifest(project_path)
    result["archived_chunks"] = len(manifest.get("chunks", []))
    result["total_tokens_archived"] = manifest.get("total_tokens_archived", 0)
    return result


@mcp.tool()
def archive_context(text: str, label: str, project_path: str) -> dict:
    """Archive conversation context to the vault before it gets compacted.
    Stores the full text and generates a summary for quick retrieval later.

    Args:
        text: The conversation context to archive.
        label: A short descriptive label (e.g., "auth middleware discussion").
        project_path: The absolute path to the current project.
    """
    vault = _get_vault()
    chunk_id = vault.store(
        project_path=project_path,
        content=text,
        label=label,
    )
    chunk = vault.get_chunk(project_path, chunk_id)
    return {
        "chunk_id": chunk_id,
        "summary": chunk["summary"],
        "token_estimate": chunk["token_estimate"],
        "message": f"Archived as {chunk_id}. Summary and full content stored in vault.",
    }


@mcp.tool()
def retrieve_context(query: str, project_path: str, limit: int = 5) -> dict:
    """Search archived context by keywords. Returns summaries of matching chunks,
    ranked by relevance. Use get_chunk to pull full content if a summary isn't enough.

    Args:
        query: Search keywords (e.g., "auth middleware JWT").
        project_path: The absolute path to the current project.
        limit: Maximum number of results to return (default 5).
    """
    vault = _get_vault()
    results = vault.search(project_path, query=query, limit=limit)
    return {
        "query": query,
        "results": results,
        "hint": "Use get_chunk with a chunk_id to retrieve full content if needed.",
    }


@mcp.tool()
def list_archived(project_path: str) -> dict:
    """List all archived context chunks for the current project.

    Args:
        project_path: The absolute path to the current project.
    """
    vault = _get_vault()
    chunks = vault.list_chunks(project_path)
    manifest = vault.get_manifest(project_path)
    return {
        "chunks": chunks,
        "total_chunks": len(chunks),
        "total_tokens_archived": manifest.get("total_tokens_archived", 0),
    }


@mcp.tool()
def get_chunk(chunk_id: str, project_path: str) -> dict:
    """Retrieve the full content of a specific archived chunk. Use this when
    a summary from retrieve_context isn't detailed enough.

    Args:
        chunk_id: The chunk ID (e.g., "chunk_001").
        project_path: The absolute path to the current project.
    """
    vault = _get_vault()
    chunk = vault.get_chunk(project_path, chunk_id)
    if chunk is None:
        return {"error": f"Chunk {chunk_id} not found."}
    return chunk


@mcp.tool()
def delete_chunk(chunk_id: str, project_path: str) -> dict:
    """Delete an archived chunk that is no longer needed.

    Args:
        chunk_id: The chunk ID to delete (e.g., "chunk_001").
        project_path: The absolute path to the current project.
    """
    vault = _get_vault()
    success = vault.delete_chunk(project_path, chunk_id)
    return {
        "deleted": success,
        "chunk_id": chunk_id,
        "message": f"Chunk {chunk_id} deleted." if success else f"Chunk {chunk_id} not found.",
    }
