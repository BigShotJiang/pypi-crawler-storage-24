"""Context health monitoring — token estimation and status checks."""

import tiktoken


class ContextHealth:
    """Estimates token count and reports context health status."""

    DEFAULT_MAX_TOKENS = 200000  # Claude's context window

    def __init__(self):
        self._encoder = None

    @property
    def encoder(self):
        if self._encoder is None:
            self._encoder = tiktoken.get_encoding("cl100k_base")
        return self._encoder

    def estimate_tokens(self, text: str) -> int:
        if not text:
            return 0
        return len(self.encoder.encode(text))

    def check(self, text: str, max_tokens: int | None = None) -> dict:
        max_tokens = max_tokens or self.DEFAULT_MAX_TOKENS
        token_count = self.estimate_tokens(text)
        percentage = (token_count / max_tokens) * 100 if max_tokens > 0 else 0

        if percentage >= 75:
            status = "red"
            recommendation = (
                "Context is critically full. Archive old context immediately "
                "using archive_context to prevent loss during compaction."
            )
        elif percentage >= 50:
            status = "yellow"
            recommendation = (
                "Context is growing large. Consider archiving older conversation "
                "segments using archive_context to keep the session lean."
            )
        else:
            status = "green"
            recommendation = "Context size is healthy. No action needed."

        return {
            "token_estimate": token_count,
            "max_tokens": max_tokens,
            "percentage": round(percentage, 1),
            "status": status,
            "recommendation": recommendation,
        }
