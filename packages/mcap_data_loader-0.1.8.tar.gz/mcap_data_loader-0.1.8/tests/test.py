print(1 + 1e16 - 1e16)
print(1e16 - 1e16 + 1)