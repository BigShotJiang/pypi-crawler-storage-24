"""SCORCH audit phases."""
