"""Applications of AI packages."""
