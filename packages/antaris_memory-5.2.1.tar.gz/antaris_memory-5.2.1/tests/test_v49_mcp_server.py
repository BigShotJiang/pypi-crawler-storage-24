"""
Tests for antaris_memory.mcp_server — JSON-RPC 2.0 over stdio MCP implementation.

This module tests the pure JSON-RPC 2.0 implementation without FastMCP dependencies.
Covers handle_request, run_stdio, tool calls, error handling, and JSON-RPC protocol compliance.
"""

import json
import os
import sys
import tempfile
import unittest.mock
from io import StringIO
from typing import Dict, Any

import pytest

from antaris_memory.mcp_server import AntarisMCPServer
from antaris_memory import __version__


class TestAntarisMCPServer:
    """Test the AntarisMCPServer class."""
    
    @pytest.fixture
    def server(self, tmp_path):
        """Create a server instance with temporary workspace."""
        workspace = str(tmp_path / "memory")
        return AntarisMCPServer(workspace=workspace, agent_name="test-agent")
    
    @pytest.fixture
    def server_with_agent_id(self, tmp_path):
        """Create a server instance with explicit agent_id."""
        workspace = str(tmp_path / "memory")
        return AntarisMCPServer(workspace=workspace, agent_name="test-agent", agent_id="custom-agent-id")
    
    def test_init_defaults(self, tmp_path):
        """Test server initialization with defaults."""
        workspace = str(tmp_path / "memory")
        server = AntarisMCPServer(workspace=workspace)
        
        assert server._workspace == workspace
        assert server._agent_name == "mcp-agent"
        assert server._agent_id == "mcp-agent"
        assert server._memory is None
    
    def test_init_with_agent_id(self, server_with_agent_id):
        """Test that agent_id defaults to agent_name when not specified."""
        assert server_with_agent_id._agent_id == "custom-agent-id"
    
    def test_agent_id_defaults_to_agent_name(self, server):
        """Test that agent_id defaults to agent_name when not specified."""
        assert server._agent_id == server._agent_name
    
    def test_lazy_memory_init(self, server):
        """Test that MemorySystem is not initialized until first tool call."""
        assert server._memory is None
        # This would initialize memory system in a real scenario
        # We'll test this indirectly through tool calls
    
    def test_server_constants(self, server):
        """Test server constants are set correctly."""
        assert server.SERVER_NAME == "antaris-memory"
        assert server.SERVER_VERSION == __version__
        assert server.PROTOCOL_VERSION == "2024-11-05"


class TestHandleRequest:
    """Test the handle_request method."""
    
    @pytest.fixture
    def server(self, tmp_path):
        """Create a server instance with temporary workspace."""
        workspace = str(tmp_path / "memory")
        return AntarisMCPServer(workspace=workspace, agent_name="test-agent")
    
    def test_initialize_returns_server_info(self, server):
        """Test initialize method returns server name, version, and protocol version."""
        request = {
            "jsonrpc": "2.0",
            "method": "initialize",
            "id": 1
        }
        
        response = server.handle_request(request)
        
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == 1
        assert "result" in response
        
        result = response["result"]
        assert result["protocolVersion"] == "2024-11-05"
        assert result["serverInfo"]["name"] == "antaris-memory"
        assert result["serverInfo"]["version"] == __version__
        assert "capabilities" in result
    
    def test_tools_list_returns_all_tools(self, server):
        """Test tools/list returns all 5 tools with correct names."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/list",
            "id": 2
        }
        
        response = server.handle_request(request)
        
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == 2
        assert "result" in response
        
        tools = response["result"]["tools"]
        assert len(tools) == 5
        
        tool_names = [tool["name"] for tool in tools]
        expected_names = ["search_memory", "ingest_memory", "get_stats", "graph_search", "get_entity"]
        assert set(tool_names) == set(expected_names)
    
    def test_tools_list_schemas_have_required_fields(self, server):
        """Test tools/list - each tool has inputSchema with required fields."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/list",
            "id": 3
        }
        
        response = server.handle_request(request)
        tools = response["result"]["tools"]
        
        for tool in tools:
            assert "name" in tool
            assert "description" in tool
            assert "inputSchema" in tool
            assert "type" in tool["inputSchema"]
            assert tool["inputSchema"]["type"] == "object"
            assert "properties" in tool["inputSchema"]
            assert "required" in tool["inputSchema"]
    
    def test_tools_call_search_memory_returns_results(self, server):
        """Test tools/call search_memory returns results list."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "search_memory",
                "arguments": {"query": "test query", "limit": 5}
            },
            "id": 4
        }
        
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_memory = unittest.mock.Mock()
            mock_memory.search.return_value = []
            mock_get_memory.return_value = mock_memory
            
            response = server.handle_request(request)
            
            assert response["jsonrpc"] == "2.0"
            assert response["id"] == 4
            assert "result" in response
            
            result = response["result"]
            assert result["isError"] is False
            assert "content" in result
            
            content_text = json.loads(result["content"][0]["text"])
            assert "results" in content_text
            assert isinstance(content_text["results"], list)
    
    def test_tools_call_ingest_memory_returns_ok_and_hash(self, server):
        """Test tools/call ingest_memory returns ok=True and hash."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "ingest_memory",
                "arguments": {"content": "test content", "category": "tactical"}
            },
            "id": 5
        }
        
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_memory = unittest.mock.Mock()
            mock_memory.ingest.return_value = 1  # 1 entry added
            mock_memory.memories = [unittest.mock.Mock()]
            mock_memory.memories[-1].hash = "test_hash"
            mock_get_memory.return_value = mock_memory
            
            response = server.handle_request(request)
            
            assert response["jsonrpc"] == "2.0"
            assert response["id"] == 5
            assert "result" in response
            
            content_text = json.loads(response["result"]["content"][0]["text"])
            assert "ok" in content_text
            assert "hash" in content_text
            assert content_text["ok"] is True
    
    def test_tools_call_get_stats_returns_dict_with_total_entries(self, server):
        """Test tools/call get_stats returns dict with total_entries key."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "get_stats",
                "arguments": {}
            },
            "id": 6
        }
        
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_memory = unittest.mock.Mock()
            mock_memory.stats.return_value = {"total": 42, "version": "4.9.2"}
            mock_get_memory.return_value = mock_memory
            
            response = server.handle_request(request)
            
            content_text = json.loads(response["result"]["content"][0]["text"])
            assert "total_entries" in content_text
            assert content_text["total_entries"] == 42
            assert "version" in content_text
    
    def test_tools_call_graph_search_returns_results_list(self, server):
        """Test tools/call graph_search returns results list."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "graph_search",
                "arguments": {"subject": "test_entity"}
            },
            "id": 7
        }
        
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_memory = unittest.mock.Mock()
            mock_memory.graph_search.return_value = [
                {"source": "test_entity", "relation": "created", "target": "test_object"}
            ]
            mock_get_memory.return_value = mock_memory
            
            response = server.handle_request(request)
            
            content_text = json.loads(response["result"]["content"][0]["text"])
            assert "results" in content_text
            assert isinstance(content_text["results"], list)
    
    def test_tools_call_get_entity_returns_dict(self, server):
        """Test tools/call get_entity returns dict (empty ok if not found)."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "get_entity",
                "arguments": {"canonical": "test_entity"}
            },
            "id": 8
        }
        
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_memory = unittest.mock.Mock()
            mock_memory.get_entity.return_value = {}
            mock_get_memory.return_value = mock_memory
            
            response = server.handle_request(request)
            
            content_text = json.loads(response["result"]["content"][0]["text"])
            assert isinstance(content_text, dict)
    
    def test_unknown_method_returns_method_not_found_error(self, server):
        """Test unknown method returns -32601 error."""
        request = {
            "jsonrpc": "2.0",
            "method": "unknown/method",
            "id": 9
        }
        
        response = server.handle_request(request)
        
        assert response["jsonrpc"] == "2.0"
        assert response["id"] == 9
        assert "error" in response
        assert response["error"]["code"] == -32601
        assert "Method not found" in response["error"]["message"]
    
    def test_unknown_tool_name_returns_invalid_params_error(self, server):
        """Test unknown tool name returns -32602 error."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "unknown_tool",
                "arguments": {}
            },
            "id": 10
        }
        
        response = server.handle_request(request)
        
        assert response["error"]["code"] == -32602
        assert "Unknown tool" in response["error"]["message"]
    
    def test_missing_required_param_returns_invalid_params_error(self, server):
        """Test missing required param returns -32602 error."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "search_memory",
                "arguments": {}  # Missing required "query" param
            },
            "id": 11
        }
        
        response = server.handle_request(request)
        
        assert response["error"]["code"] == -32602
        assert "Invalid parameters" in response["error"]["message"]
    
    def test_malformed_request_no_method_returns_invalid_request_error(self, server):
        """Test malformed request (no method) returns -32600 error."""
        request = {
            "jsonrpc": "2.0",
            "id": 12
            # Missing "method"
        }
        
        response = server.handle_request(request)
        
        assert response["error"]["code"] == -32600
        assert "Missing method" in response["error"]["message"]
    
    def test_id_echoed_back_in_response(self, server):
        """Test id is echoed back in response."""
        request = {
            "jsonrpc": "2.0",
            "method": "initialize",
            "id": "custom_id_123"
        }
        
        response = server.handle_request(request)
        
        assert response["id"] == "custom_id_123"
    
    def test_id_null_handled(self, server):
        """Test id=null is handled."""
        request = {
            "jsonrpc": "2.0",
            "method": "initialize",
            "id": None
        }
        
        response = server.handle_request(request)
        
        assert response["id"] is None
    
    def test_notification_no_id_returns_none(self, server):
        """Test notification (no id) returns None."""
        request = {
            "jsonrpc": "2.0",
            "method": "initialize"
            # No "id" key
        }
        
        response = server.handle_request(request)
        
        assert response is None
    
    def test_response_always_has_jsonrpc_2_0(self, server):
        """Test JSON-RPC response always has jsonrpc='2.0'."""
        request = {
            "jsonrpc": "2.0",
            "method": "initialize",
            "id": 1
        }
        
        response = server.handle_request(request)
        
        assert response["jsonrpc"] == "2.0"
    
    def test_error_response_has_error_code_and_message(self, server):
        """Test JSON-RPC error response has error.code and error.message."""
        request = {
            "jsonrpc": "2.0",
            "method": "unknown_method",
            "id": 1
        }
        
        response = server.handle_request(request)
        
        assert "error" in response
        assert "code" in response["error"]
        assert "message" in response["error"]
        assert isinstance(response["error"]["code"], int)
        assert isinstance(response["error"]["message"], str)
    
    def test_success_response_has_result_key(self, server):
        """Test JSON-RPC success response has result key."""
        request = {
            "jsonrpc": "2.0",
            "method": "initialize",
            "id": 1
        }
        
        response = server.handle_request(request)
        
        assert "result" in response
        assert "error" not in response


class TestToolImplementations:
    """Test individual tool implementations."""
    
    @pytest.fixture
    def server(self, tmp_path):
        """Create a server instance with temporary workspace."""
        workspace = str(tmp_path / "memory")
        return AntarisMCPServer(workspace=workspace, agent_name="test-agent")
    
    def test_search_result_items_have_required_fields(self, server):
        """Test tools/call search result items have content, score, category, hash fields."""
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_entry = unittest.mock.Mock()
            mock_entry.content = "test content"
            mock_entry.importance = 0.8
            mock_entry.category = "tactical"
            mock_entry.hash = "test_hash"
            
            mock_memory = unittest.mock.Mock()
            mock_memory.search.return_value = [mock_entry]
            mock_get_memory.return_value = mock_memory
            
            result = server._tool_search_memory("test query")
            
            assert "results" in result
            assert len(result["results"]) == 1
            
            item = result["results"][0]
            assert "content" in item
            assert "score" in item
            assert "category" in item
            assert "hash" in item
    
    def test_ingest_result_has_ok_and_hash_fields(self, server):
        """Test tools/call ingest result has ok and hash fields."""
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_memory = unittest.mock.Mock()
            mock_memory.ingest.return_value = 1
            mock_memory.memories = [unittest.mock.Mock()]
            mock_memory.memories[-1].hash = "test_hash"
            mock_get_memory.return_value = mock_memory
            
            result = server._tool_ingest_memory("test content")
            
            assert "ok" in result
            assert "hash" in result
            assert isinstance(result["ok"], bool)
            assert isinstance(result["hash"], str)
    
    def test_get_stats_result_has_total_entries_version(self, server):
        """Test tools/call get_stats result has total_entries, version."""
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_memory = unittest.mock.Mock()
            mock_memory.stats.return_value = {
                "total": 10,
                "version": __version__,
                "hot_entries": 5,
                "warm_entries": 3,
                "cold_entries": 2
            }
            mock_get_memory.return_value = mock_memory
            
            result = server._tool_get_stats()
            
            assert "total_entries" in result
            assert "version" in result
            assert result["total_entries"] == 10
            assert result["version"] == __version__
    
    def test_result_is_json_serializable(self, server):
        """Test tools/call result is JSON-serializable (no datetime objects etc.)."""
        with unittest.mock.patch.object(server, '_get_memory') as mock_get_memory:
            mock_memory = unittest.mock.Mock()
            mock_memory.stats.return_value = {"total": 5}
            mock_get_memory.return_value = mock_memory
            
            result = server._tool_get_stats()
            
            # This should not raise an exception
            json_str = json.dumps(result)
            assert isinstance(json_str, str)
    
    def test_tools_call_with_notification_returns_none(self, server):
        """Test tools/call with notification (no id) returns None."""
        request = {
            "jsonrpc": "2.0",
            "method": "tools/call",
            "params": {
                "name": "get_stats",
                "arguments": {}
            }
            # No "id" key - this is a notification
        }
        
        response = server.handle_request(request)
        
        assert response is None


class TestRunStdio:
    """Test the run_stdio method."""
    
    @pytest.fixture
    def server(self, tmp_path):
        """Create a server instance with temporary workspace."""
        workspace = str(tmp_path / "memory")
        return AntarisMCPServer(workspace=workspace, agent_name="test-agent")
    
    def test_reads_from_stdin_writes_to_stdout(self, server):
        """Test run_stdio reads from stdin, writes to stdout (mock stdin/stdout)."""
        input_data = '{"jsonrpc": "2.0", "method": "initialize", "id": 1}\n'
        
        with unittest.mock.patch('sys.stdin', StringIO(input_data)), \
             unittest.mock.patch('sys.stdout', new_callable=StringIO) as mock_stdout:
            
            server.run_stdio()
            
            output = mock_stdout.getvalue()
            assert output  # Should have written something
            
            # Parse the output
            response = json.loads(output.strip())
            assert response["jsonrpc"] == "2.0"
            assert response["id"] == 1
    
    def test_skips_malformed_lines_doesnt_crash(self, server):
        """Test run_stdio handles malformed lines without crashing.
        Hardened behavior (v4.9.2): malformed lines return -32700 error
        responses rather than being silently dropped.
        """
        input_data = 'invalid json\n{"jsonrpc": "2.0", "method": "initialize", "id": 1}\nmore invalid\n'
        
        with unittest.mock.patch('sys.stdin', StringIO(input_data)), \
             unittest.mock.patch('sys.stdout', new_callable=StringIO) as mock_stdout:
            
            # Should not raise an exception
            server.run_stdio()
            
            output = mock_stdout.getvalue()
            lines = [line.strip() for line in output.split('\n') if line.strip()]
            responses = [json.loads(l) for l in lines]
            
            # Should have responses for all input lines (errors + valid)
            assert len(responses) == 3

            # Parse errors return -32700
            error_responses = [r for r in responses if "error" in r]
            assert len(error_responses) == 2
            assert all(r["error"]["code"] == -32700 for r in error_responses)

            # Valid initialize response
            valid = [r for r in responses if "result" in r]
            assert len(valid) == 1
            assert valid[0]["id"] == 1
    
    def test_handles_empty_lines_gracefully(self, server):
        """Test run_stdio handles empty lines gracefully."""
        input_data = '\n\n{"jsonrpc": "2.0", "method": "initialize", "id": 1}\n\n'
        
        with unittest.mock.patch('sys.stdin', StringIO(input_data)), \
             unittest.mock.patch('sys.stdout', new_callable=StringIO) as mock_stdout:
            
            server.run_stdio()
            
            output = mock_stdout.getvalue()
            lines = [line.strip() for line in output.split('\n') if line.strip()]
            
            # Should have exactly one valid response
            assert len(lines) == 1
            response = json.loads(lines[0])
            assert response["id"] == 1


class TestMainFunction:
    """Test the main() function and argument parsing."""
    
    def test_main_argparse_defaults_work_without_args(self, tmp_path):
        """Test main() argparse defaults work without args."""
        # We can't easily test the full main() function without running the stdio loop,
        # but we can test the argument parsing logic
        import argparse
        
        parser = argparse.ArgumentParser(description="antaris-memory MCP server")
        parser.add_argument("--workspace", default=".", help="Memory workspace path")
        parser.add_argument("--agent-name", default="mcp-agent", help="Agent name for memory scoping")
        
        # Test with no arguments
        args = parser.parse_args([])
        assert args.workspace == "."
        assert args.agent_name == "mcp-agent"
        
        # Test with custom arguments
        args = parser.parse_args(["--workspace", "/tmp/test", "--agent-name", "test-agent"])
        assert args.workspace == "/tmp/test"
        assert args.agent_name == "test-agent"


class TestIntegrationWithTempdir:
    """Integration tests using temporary directories."""
    
    def test_works_with_workspace_as_tempdir(self, tmp_path):
        """Test tools/call works with workspace as tempdir."""
        workspace = str(tmp_path / "memory")
        server = AntarisMCPServer(workspace=workspace, agent_name="test-agent")
        
        # This test would require a real MemorySystem implementation
        # For now, we just test that the server can be created with a tempdir
        assert server._workspace == workspace
        assert os.path.exists(str(tmp_path))  # Temp directory exists