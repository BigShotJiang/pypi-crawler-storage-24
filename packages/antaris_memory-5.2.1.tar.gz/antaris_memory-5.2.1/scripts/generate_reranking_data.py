#!/usr/bin/env python3
"""Generate Layer 7 (word_cluster_map) and Layer 10 (density_calibration) data files.

Reads cached embeddings and memory shards to produce static JSON files
that enable approximate semantic reranking and score calibration at query time
with zero runtime dependencies.
"""

import json
import os
import re
import sys
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np

# Paths
REPO = Path(__file__).resolve().parent.parent
DATA_DIR = REPO / "antaris_memory" / "data"
STORE = Path(os.environ.get("ANTARIS_MEMORY_STORE",
    str(REPO.parent.parent / "antaris_memory_store")))
CACHE_DIR = STORE / ".enrichment_cache"
SHARDS_DIR = STORE / "shards"

EMBEDDINGS_PATH = CACHE_DIR / "embeddings.npy"
HASHES_PATH = CACHE_DIR / "hashes.txt"
CLUSTERS_PATH = DATA_DIR / "embedding_clusters.json"


def tokenize(text: str) -> list[str]:
    """Simple word tokenizer — lowercase alphanumeric tokens, min length 2."""
    return [w for w in re.findall(r'[a-z0-9]+', text.lower()) if len(w) >= 2]


def load_memories() -> dict[str, list[str]]:
    """Load hash -> token list from shards."""
    hash_tokens = {}
    for shard_file in SHARDS_DIR.glob("shard_*.json"):
        with open(shard_file) as f:
            shard = json.load(f)
        for mem in shard.get("memories", []):
            h = mem.get("hash", "")
            if not h:
                continue
            text = mem.get("content", "")
            # Also include search_keywords and tags
            kw = mem.get("search_keywords", [])
            tags = mem.get("tags", [])
            combined = text + " " + " ".join(kw) + " " + " ".join(tags)
            hash_tokens[h] = tokenize(combined)
    return hash_tokens


def generate_word_cluster_map(embeddings, hashes, hash_tokens, clusters_data):
    """Part A: Generate word_cluster_map.json and cluster_centroids_summary.json."""
    print("Generating word cluster map...")

    # Build hash -> index mapping
    hash_to_idx = {h: i for i, h in enumerate(hashes)}

    # Recompute centroids from embeddings + cluster assignments
    hash_to_cluster = clusters_data["hash_to_cluster"]
    n_clusters = clusters_data["n_clusters"]

    centroids = np.zeros((n_clusters, embeddings.shape[1]), dtype=np.float64)
    centroid_counts = np.zeros(n_clusters, dtype=np.int64)
    for h, cid in hash_to_cluster.items():
        if h in hash_to_idx:
            idx = hash_to_idx[h]
            centroids[cid] += embeddings[idx].astype(np.float64)
            centroid_counts[cid] += 1
    for i in range(n_clusters):
        if centroid_counts[i] > 0:
            centroids[i] /= centroid_counts[i]

    # Normalize centroids
    norms = np.linalg.norm(centroids, axis=1, keepdims=True)
    norms[norms == 0] = 1
    centroids_normed = centroids / norms

    # Count word frequencies across memories
    word_freq = Counter()
    word_to_hashes = defaultdict(list)
    for h, tokens in hash_tokens.items():
        unique_tokens = set(tokens)
        for w in unique_tokens:
            word_freq[w] += 1
            word_to_hashes[w].append(h)

    # Filter to words with freq >= 3
    vocab = {w for w, c in word_freq.items() if c >= 3}
    print(f"  Vocabulary: {len(vocab)} words (freq >= 3)")

    # Compute word embeddings (average of memory embeddings containing the word)
    words_data = {}
    for w in sorted(vocab):
        mem_hashes = word_to_hashes[w]
        indices = [hash_to_idx[h] for h in mem_hashes if h in hash_to_idx]
        if not indices:
            continue
        word_emb = embeddings[indices].mean(axis=0).astype(np.float64)
        # Normalize
        norm = np.linalg.norm(word_emb)
        if norm == 0:
            continue
        word_emb /= norm
        # Find nearest centroid (cosine similarity = dot product for normalized vectors)
        sims = centroids_normed @ word_emb
        cluster_id = int(np.argmax(sims))
        distance = round(float(1.0 - sims[cluster_id]), 4)
        words_data[w] = {"cluster": cluster_id, "distance": distance}

    print(f"  Mapped {len(words_data)} words to clusters")

    # Write word_cluster_map.json
    output = {
        "model": "google/embeddinggemma-300m",
        "description": "Maps words to embedding cluster IDs for approximate semantic similarity at query time",
        "vocab_size": len(words_data),
        "n_clusters": n_clusters,
        "words": words_data
    }
    out_path = DATA_DIR / "word_cluster_map.json"
    with open(out_path, "w") as f:
        json.dump(output, f, separators=(",", ":"))
    print(f"  Wrote {out_path} ({os.path.getsize(out_path) / 1024:.0f} KB)")

    # Generate cluster_centroids_summary.json
    # For each cluster, find top-10 words by distance (closest = most representative)
    cluster_words = defaultdict(list)
    for w, info in words_data.items():
        cluster_words[info["cluster"]].append((w, info["distance"]))

    summary = {
        "description": "Human-readable cluster descriptions with top-10 representative words",
        "n_clusters": n_clusters,
        "clusters": {}
    }
    for cid in range(n_clusters):
        cw = sorted(cluster_words.get(cid, []), key=lambda x: x[1])[:10]
        summary["clusters"][str(cid)] = {
            "size": int(centroid_counts[cid]),
            "top_words": [w for w, _ in cw],
            "word_count": len(cluster_words.get(cid, []))
        }

    sum_path = DATA_DIR / "cluster_centroids_summary.json"
    with open(sum_path, "w") as f:
        json.dump(summary, f, indent=2)
    print(f"  Wrote {sum_path}")


def generate_density_calibration(embeddings, hashes):
    """Part B: Generate density_calibration.json."""
    print("Generating density calibration...")

    n = len(embeddings)
    K = 10

    # Normalize embeddings for cosine similarity
    norms = np.linalg.norm(embeddings, axis=1, keepdims=True)
    norms[norms == 0] = 1
    emb_normed = embeddings / norms

    # Compute density in batches to avoid OOM
    batch_size = 500
    densities = np.zeros(n, dtype=np.float64)

    for start in range(0, n, batch_size):
        end = min(start + batch_size, n)
        # Cosine similarity of batch against all
        sims = emb_normed[start:end] @ emb_normed.T  # (batch, n)
        # For each row, find top K+1 (includes self), exclude self
        for i in range(end - start):
            row = sims[i]
            # Set self-similarity to -inf
            row[start + i] = -np.inf
            top_k = np.partition(row, -K)[-K:]
            densities[start + i] = float(np.mean(top_k))
        if (start // batch_size) % 4 == 0:
            print(f"  Batch {start}/{n}...")

    # Build output
    hash_to_density = {}
    for i, h in enumerate(hashes):
        hash_to_density[h] = round(float(densities[i]), 4)

    stats = {
        "mean": round(float(np.mean(densities)), 4),
        "std": round(float(np.std(densities)), 4),
        "min": round(float(np.min(densities)), 4),
        "max": round(float(np.max(densities)), 4)
    }

    output = {
        "description": "Per-memory density scores for score calibration. Dense = redundant, sparse = unique.",
        "method": "avg_cosine_10nn",
        "n_memories": len(hash_to_density),
        "stats": stats,
        "hash_to_density": hash_to_density
    }

    out_path = DATA_DIR / "density_calibration.json"
    with open(out_path, "w") as f:
        json.dump(output, f, separators=(",", ":"))
    print(f"  Wrote {out_path} ({os.path.getsize(out_path) / 1024:.0f} KB)")
    print(f"  Stats: {stats}")


def main():
    print("Loading data...")
    embeddings = np.load(EMBEDDINGS_PATH)
    with open(HASHES_PATH) as f:
        hashes = [line.strip() for line in f if line.strip()]
    with open(CLUSTERS_PATH) as f:
        clusters_data = json.load(f)

    print(f"  Embeddings: {embeddings.shape}")
    print(f"  Hashes: {len(hashes)}")

    # Align lengths
    min_len = min(len(hashes), embeddings.shape[0])
    hashes = hashes[:min_len]
    embeddings = embeddings[:min_len]

    hash_tokens = load_memories()
    print(f"  Memories with content: {len(hash_tokens)}")

    generate_word_cluster_map(embeddings, hashes, hash_tokens, clusters_data)
    generate_density_calibration(embeddings, hashes)

    print("\nDone!")


if __name__ == "__main__":
    main()
