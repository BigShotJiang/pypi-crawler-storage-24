# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListMetricsResponseBodyDatapoint:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'statistic_name': 'str',
        'value': 'float',
        'unit': 'str'
    }

    attribute_map = {
        'statistic_name': 'statistic_name',
        'value': 'value',
        'unit': 'unit'
    }

    def __init__(self, statistic_name=None, value=None, unit=None):
        r"""ListMetricsResponseBodyDatapoint

        The model defined in huaweicloud sdk

        :param statistic_name: 统计维度，例如total,success,failed,
        :type statistic_name: str
        :param value: 指标数据取值
        :type value: float
        :param unit: 指标数据的单位，例如：个、GB、%
        :type unit: str
        """
        
        

        self._statistic_name = None
        self._value = None
        self._unit = None
        self.discriminator = None

        self.statistic_name = statistic_name
        self.value = value
        self.unit = unit

    @property
    def statistic_name(self):
        r"""Gets the statistic_name of this ListMetricsResponseBodyDatapoint.

        统计维度，例如total,success,failed,

        :return: The statistic_name of this ListMetricsResponseBodyDatapoint.
        :rtype: str
        """
        return self._statistic_name

    @statistic_name.setter
    def statistic_name(self, statistic_name):
        r"""Sets the statistic_name of this ListMetricsResponseBodyDatapoint.

        统计维度，例如total,success,failed,

        :param statistic_name: The statistic_name of this ListMetricsResponseBodyDatapoint.
        :type statistic_name: str
        """
        self._statistic_name = statistic_name

    @property
    def value(self):
        r"""Gets the value of this ListMetricsResponseBodyDatapoint.

        指标数据取值

        :return: The value of this ListMetricsResponseBodyDatapoint.
        :rtype: float
        """
        return self._value

    @value.setter
    def value(self, value):
        r"""Sets the value of this ListMetricsResponseBodyDatapoint.

        指标数据取值

        :param value: The value of this ListMetricsResponseBodyDatapoint.
        :type value: float
        """
        self._value = value

    @property
    def unit(self):
        r"""Gets the unit of this ListMetricsResponseBodyDatapoint.

        指标数据的单位，例如：个、GB、%

        :return: The unit of this ListMetricsResponseBodyDatapoint.
        :rtype: str
        """
        return self._unit

    @unit.setter
    def unit(self, unit):
        r"""Sets the unit of this ListMetricsResponseBodyDatapoint.

        指标数据的单位，例如：个、GB、%

        :param unit: The unit of this ListMetricsResponseBodyDatapoint.
        :type unit: str
        """
        self._unit = unit

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListMetricsResponseBodyDatapoint):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
