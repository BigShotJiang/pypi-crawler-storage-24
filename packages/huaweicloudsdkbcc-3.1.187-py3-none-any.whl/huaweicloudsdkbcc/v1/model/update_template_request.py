# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class UpdateTemplateRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'domain_id': 'str',
        'template_id': 'str',
        'body': 'UpdateTemplateBody'
    }

    attribute_map = {
        'domain_id': 'domain_id',
        'template_id': 'template_id',
        'body': 'body'
    }

    def __init__(self, domain_id=None, template_id=None, body=None):
        r"""UpdateTemplateRequest

        The model defined in huaweicloud sdk

        :param domain_id: 账号ID
        :type domain_id: str
        :param template_id: 模板ID
        :type template_id: str
        :param body: Body of the UpdateTemplateRequest
        :type body: :class:`huaweicloudsdkbcc.v1.UpdateTemplateBody`
        """
        
        

        self._domain_id = None
        self._template_id = None
        self._body = None
        self.discriminator = None

        self.domain_id = domain_id
        self.template_id = template_id
        if body is not None:
            self.body = body

    @property
    def domain_id(self):
        r"""Gets the domain_id of this UpdateTemplateRequest.

        账号ID

        :return: The domain_id of this UpdateTemplateRequest.
        :rtype: str
        """
        return self._domain_id

    @domain_id.setter
    def domain_id(self, domain_id):
        r"""Sets the domain_id of this UpdateTemplateRequest.

        账号ID

        :param domain_id: The domain_id of this UpdateTemplateRequest.
        :type domain_id: str
        """
        self._domain_id = domain_id

    @property
    def template_id(self):
        r"""Gets the template_id of this UpdateTemplateRequest.

        模板ID

        :return: The template_id of this UpdateTemplateRequest.
        :rtype: str
        """
        return self._template_id

    @template_id.setter
    def template_id(self, template_id):
        r"""Sets the template_id of this UpdateTemplateRequest.

        模板ID

        :param template_id: The template_id of this UpdateTemplateRequest.
        :type template_id: str
        """
        self._template_id = template_id

    @property
    def body(self):
        r"""Gets the body of this UpdateTemplateRequest.

        :return: The body of this UpdateTemplateRequest.
        :rtype: :class:`huaweicloudsdkbcc.v1.UpdateTemplateBody`
        """
        return self._body

    @body.setter
    def body(self, body):
        r"""Sets the body of this UpdateTemplateRequest.

        :param body: The body of this UpdateTemplateRequest.
        :type body: :class:`huaweicloudsdkbcc.v1.UpdateTemplateBody`
        """
        self._body = body

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, UpdateTemplateRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
