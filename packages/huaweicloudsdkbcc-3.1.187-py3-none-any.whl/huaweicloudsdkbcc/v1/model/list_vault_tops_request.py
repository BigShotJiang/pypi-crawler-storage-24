# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListVaultTopsRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'domain_id': 'str',
        'region_id': 'str',
        'metric_name': 'str',
        'limit': 'int'
    }

    attribute_map = {
        'domain_id': 'domain_id',
        'region_id': 'region_id',
        'metric_name': 'metric_name',
        'limit': 'limit'
    }

    def __init__(self, domain_id=None, region_id=None, metric_name=None, limit=None):
        r"""ListVaultTopsRequest

        The model defined in huaweicloud sdk

        :param domain_id: 账号ID
        :type domain_id: str
        :param region_id: 区域ID
        :type region_id: str
        :param metric_name: 返回的类型：按容量排序返回或者按使用率排序返回，取值范围：vault_util,used_vault_size
        :type metric_name: str
        :param limit: 返回的存储库数量，取值范围(0,100]，默认值为5，用于限制结果数据条数。
        :type limit: int
        """
        
        

        self._domain_id = None
        self._region_id = None
        self._metric_name = None
        self._limit = None
        self.discriminator = None

        self.domain_id = domain_id
        if region_id is not None:
            self.region_id = region_id
        self.metric_name = metric_name
        if limit is not None:
            self.limit = limit

    @property
    def domain_id(self):
        r"""Gets the domain_id of this ListVaultTopsRequest.

        账号ID

        :return: The domain_id of this ListVaultTopsRequest.
        :rtype: str
        """
        return self._domain_id

    @domain_id.setter
    def domain_id(self, domain_id):
        r"""Sets the domain_id of this ListVaultTopsRequest.

        账号ID

        :param domain_id: The domain_id of this ListVaultTopsRequest.
        :type domain_id: str
        """
        self._domain_id = domain_id

    @property
    def region_id(self):
        r"""Gets the region_id of this ListVaultTopsRequest.

        区域ID

        :return: The region_id of this ListVaultTopsRequest.
        :rtype: str
        """
        return self._region_id

    @region_id.setter
    def region_id(self, region_id):
        r"""Sets the region_id of this ListVaultTopsRequest.

        区域ID

        :param region_id: The region_id of this ListVaultTopsRequest.
        :type region_id: str
        """
        self._region_id = region_id

    @property
    def metric_name(self):
        r"""Gets the metric_name of this ListVaultTopsRequest.

        返回的类型：按容量排序返回或者按使用率排序返回，取值范围：vault_util,used_vault_size

        :return: The metric_name of this ListVaultTopsRequest.
        :rtype: str
        """
        return self._metric_name

    @metric_name.setter
    def metric_name(self, metric_name):
        r"""Sets the metric_name of this ListVaultTopsRequest.

        返回的类型：按容量排序返回或者按使用率排序返回，取值范围：vault_util,used_vault_size

        :param metric_name: The metric_name of this ListVaultTopsRequest.
        :type metric_name: str
        """
        self._metric_name = metric_name

    @property
    def limit(self):
        r"""Gets the limit of this ListVaultTopsRequest.

        返回的存储库数量，取值范围(0,100]，默认值为5，用于限制结果数据条数。

        :return: The limit of this ListVaultTopsRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListVaultTopsRequest.

        返回的存储库数量，取值范围(0,100]，默认值为5，用于限制结果数据条数。

        :param limit: The limit of this ListVaultTopsRequest.
        :type limit: int
        """
        self._limit = limit

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListVaultTopsRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
