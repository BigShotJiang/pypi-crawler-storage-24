# coding: utf-8

from huaweicloudsdkcore.sdk_response import SdkResponse
from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListVaultTopsResponse(SdkResponse):

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'count': 'int',
        'vaults': 'list[ListVaultTopsResponseBodyVaults]'
    }

    attribute_map = {
        'count': 'count',
        'vaults': 'vaults'
    }

    def __init__(self, count=None, vaults=None):
        r"""ListVaultTopsResponse

        The model defined in huaweicloud sdk

        :param count: 存储库总数
        :type count: int
        :param vaults: 存储库统计信息
        :type vaults: list[:class:`huaweicloudsdkbcc.v1.ListVaultTopsResponseBodyVaults`]
        """
        
        super().__init__()

        self._count = None
        self._vaults = None
        self.discriminator = None

        if count is not None:
            self.count = count
        if vaults is not None:
            self.vaults = vaults

    @property
    def count(self):
        r"""Gets the count of this ListVaultTopsResponse.

        存储库总数

        :return: The count of this ListVaultTopsResponse.
        :rtype: int
        """
        return self._count

    @count.setter
    def count(self, count):
        r"""Sets the count of this ListVaultTopsResponse.

        存储库总数

        :param count: The count of this ListVaultTopsResponse.
        :type count: int
        """
        self._count = count

    @property
    def vaults(self):
        r"""Gets the vaults of this ListVaultTopsResponse.

        存储库统计信息

        :return: The vaults of this ListVaultTopsResponse.
        :rtype: list[:class:`huaweicloudsdkbcc.v1.ListVaultTopsResponseBodyVaults`]
        """
        return self._vaults

    @vaults.setter
    def vaults(self, vaults):
        r"""Sets the vaults of this ListVaultTopsResponse.

        存储库统计信息

        :param vaults: The vaults of this ListVaultTopsResponse.
        :type vaults: list[:class:`huaweicloudsdkbcc.v1.ListVaultTopsResponseBodyVaults`]
        """
        self._vaults = vaults

    def to_dict(self):
        import warnings
        warnings.warn("ListVaultTopsResponse.to_dict() is deprecated and no longer maintained, "
                      "use to_json_object() to get the response content.", DeprecationWarning)
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListVaultTopsResponse):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
