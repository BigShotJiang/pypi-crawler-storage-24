# coding: utf-8

from huaweicloudsdkcore.utils.http_utils import sanitize_for_serialization


class ListReportSettingsRequest:

    """
    Attributes:
      openapi_types (dict): The key is attribute name
                            and the value is attribute type.
      attribute_map (dict): The key is attribute name
                            and the value is json key in definition.
    """
    sensitive_list = []

    openapi_types = {
        'domain_id': 'str',
        'enabled': 'bool',
        'offset': 'int',
        'limit': 'int'
    }

    attribute_map = {
        'domain_id': 'domain_id',
        'enabled': 'enabled',
        'offset': 'offset',
        'limit': 'limit'
    }

    def __init__(self, domain_id=None, enabled=None, offset=None, limit=None):
        r"""ListReportSettingsRequest

        The model defined in huaweicloud sdk

        :param domain_id: 账号ID
        :type domain_id: str
        :param enabled: 是否启用
        :type enabled: bool
        :param offset: 偏移量
        :type offset: int
        :param limit: 单次请求限制数
        :type limit: int
        """
        
        

        self._domain_id = None
        self._enabled = None
        self._offset = None
        self._limit = None
        self.discriminator = None

        self.domain_id = domain_id
        if enabled is not None:
            self.enabled = enabled
        if offset is not None:
            self.offset = offset
        if limit is not None:
            self.limit = limit

    @property
    def domain_id(self):
        r"""Gets the domain_id of this ListReportSettingsRequest.

        账号ID

        :return: The domain_id of this ListReportSettingsRequest.
        :rtype: str
        """
        return self._domain_id

    @domain_id.setter
    def domain_id(self, domain_id):
        r"""Sets the domain_id of this ListReportSettingsRequest.

        账号ID

        :param domain_id: The domain_id of this ListReportSettingsRequest.
        :type domain_id: str
        """
        self._domain_id = domain_id

    @property
    def enabled(self):
        r"""Gets the enabled of this ListReportSettingsRequest.

        是否启用

        :return: The enabled of this ListReportSettingsRequest.
        :rtype: bool
        """
        return self._enabled

    @enabled.setter
    def enabled(self, enabled):
        r"""Sets the enabled of this ListReportSettingsRequest.

        是否启用

        :param enabled: The enabled of this ListReportSettingsRequest.
        :type enabled: bool
        """
        self._enabled = enabled

    @property
    def offset(self):
        r"""Gets the offset of this ListReportSettingsRequest.

        偏移量

        :return: The offset of this ListReportSettingsRequest.
        :rtype: int
        """
        return self._offset

    @offset.setter
    def offset(self, offset):
        r"""Sets the offset of this ListReportSettingsRequest.

        偏移量

        :param offset: The offset of this ListReportSettingsRequest.
        :type offset: int
        """
        self._offset = offset

    @property
    def limit(self):
        r"""Gets the limit of this ListReportSettingsRequest.

        单次请求限制数

        :return: The limit of this ListReportSettingsRequest.
        :rtype: int
        """
        return self._limit

    @limit.setter
    def limit(self, limit):
        r"""Sets the limit of this ListReportSettingsRequest.

        单次请求限制数

        :param limit: The limit of this ListReportSettingsRequest.
        :type limit: int
        """
        self._limit = limit

    def to_dict(self):
        result = {}

        for attr, _ in self.openapi_types.items():
            value = getattr(self, attr)
            if isinstance(value, list):
                result[attr] = list(map(
                    lambda x: x.to_dict() if hasattr(x, "to_dict") else x,
                    value
                ))
            elif hasattr(value, "to_dict"):
                result[attr] = value.to_dict()
            elif isinstance(value, dict):
                result[attr] = dict(map(
                    lambda item: (item[0], item[1].to_dict())
                    if hasattr(item[1], "to_dict") else item,
                    value.items()
                ))
            else:
                if attr in self.sensitive_list:
                    result[attr] = "****"
                else:
                    result[attr] = value

        return result

    def to_str(self):
        """Returns the string representation of the model"""
        import simplejson as json
        return json.dumps(sanitize_for_serialization(self), ensure_ascii=False)

    def __repr__(self):
        """For `print`"""
        return self.to_str()

    def __eq__(self, other):
        """Returns true if both objects are equal"""
        if not isinstance(other, ListReportSettingsRequest):
            return False

        return self.__dict__ == other.__dict__

    def __ne__(self, other):
        """Returns true if both objects are not equal"""
        return not self == other
