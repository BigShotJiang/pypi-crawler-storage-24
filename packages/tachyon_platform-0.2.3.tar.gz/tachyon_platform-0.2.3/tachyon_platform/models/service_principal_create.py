# coding: utf-8



from __future__ import annotations
import pprint
import re  # noqa: F401
import json

from pydantic import BaseModel, ConfigDict, Field
from typing import Any, ClassVar, Dict, List, Optional
from typing_extensions import Annotated
from tachyon_platform.models.user_role_input import UserRoleInput
from typing import Optional, Set
from typing_extensions import Self

class ServicePrincipalCreate(BaseModel):
    """
    ServicePrincipalCreate
    """ # noqa: E501
    name: Annotated[str, Field(min_length=1, strict=True, max_length=32)] = Field(description="The name of the service principal to create. It can be up to 32 long and can contain uppercase and lowercase letters, numerals, and the hyphen (`-`) and underscore (`_`) characters.")
    display_name: Optional[Annotated[str, Field(strict=True, max_length=128)]] = Field(default=None, description="The display name of the service principal.", alias="displayName")
    roles: List[UserRoleInput] = Field(description="List of roles to assign to the created service principal.")
    __properties: ClassVar[List[str]] = ["name", "displayName", "roles"]

    model_config = ConfigDict(
        populate_by_name=True,
        validate_assignment=True,
        protected_namespaces=(),
    )


    def to_str(self) -> str:
        """Returns the string representation of the model using alias"""
        return pprint.pformat(self.model_dump(by_alias=True))

    def to_json(self) -> str:
        """Returns the JSON representation of the model using alias"""
        # TODO: pydantic v2: use .model_dump_json(by_alias=True, exclude_unset=True) instead
        return json.dumps(self.to_dict())

    @classmethod
    def from_json(cls, json_str: str) -> Optional[Self]:
        """Create an instance of ServicePrincipalCreate from a JSON string"""
        return cls.from_dict(json.loads(json_str))

    def to_dict(self) -> Dict[str, Any]:
        """Return the dictionary representation of the model using alias.

        This has the following differences from calling pydantic's
        `self.model_dump(by_alias=True)`:

        * `None` is only added to the output dict for nullable fields that
          were set at model initialization. Other fields with value `None`
          are ignored.
        """
        excluded_fields: Set[str] = set([
        ])

        _dict = self.model_dump(
            by_alias=True,
            exclude=excluded_fields,
            exclude_none=True,
        )
        # override the default output from pydantic by calling `to_dict()` of each item in roles (list)
        _items = []
        if self.roles:
            for _item_roles in self.roles:
                if _item_roles:
                    _items.append(_item_roles.to_dict())
            _dict['roles'] = _items
        return _dict

    @classmethod
    def from_dict(cls, obj: Optional[Dict[str, Any]]) -> Optional[Self]:
        """Create an instance of ServicePrincipalCreate from a dict"""
        if obj is None:
            return None

        if not isinstance(obj, dict):
            return cls.model_validate(obj)

        _obj = cls.model_validate({
            "name": obj.get("name"),
            "displayName": obj.get("displayName"),
            "roles": [UserRoleInput.from_dict(_item) for _item in obj["roles"]] if obj.get("roles") is not None else None
        })
        return _obj


