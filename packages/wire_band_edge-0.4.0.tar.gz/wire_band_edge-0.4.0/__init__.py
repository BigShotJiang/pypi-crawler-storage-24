"""
wire-band-edge
==============

Lightweight Wire.Band client — semantic data middleware for any domain.
Transports IoT sensor data, AI/ML events, DeFi activity, legal records,
geospatial streams, supply chain events, and more to a Wire.Band backend.

Zero dependencies on private packages. Install on any device with:

    pip install wire-band-edge              # base client
    pip install wire-band-edge[mqtt]      # + MQTT broker support
    pip install wire-band-edge[crypto]    # + frame encryption (AES-256-GCM / ChaCha20 / HKDF)

Usage:

    from wire_band_edge import WireBandEdgeClient, MQTTConnector

    async def main():
        client = WireBandEdgeClient(
            backend_url="http://your-wireband-server:8000",
            device_id="robot-arm-01",
            delta_threshold=0.02,
        )
        connector = MQTTConnector("mqtt://localhost:1883")
        await client.run_mqtt(connector, topics=["sensors/#", "robot/#"])

    asyncio.run(main())
"""

from .edge_client import WireBandEdgeClient, BufferedEvent
from .mqtt_connector import MQTTConnector, MQTTEvent, MQTTTopicClassifier
from .stream_client import WireBandStreamClient

# Crypto is optional — requires wire-band-edge[crypto]
try:
    from .crypto import (
        CryptoContext,
        EnvelopeCipher,
        SymbolRemapper,
        ContextualKeyDeriver,
        ALGO_AES256GCM,
        ALGO_CHACHA20_POLY1305,
    )
    _CRYPTO_AVAILABLE = True
except ImportError:
    _CRYPTO_AVAILABLE = False

__version__ = "0.4.0"

__all__ = [
    "WireBandEdgeClient",
    "BufferedEvent",
    "MQTTConnector",
    "MQTTEvent",
    "MQTTTopicClassifier",
    "WireBandStreamClient",
    # crypto (available when wire-band-edge[crypto] is installed)
    "CryptoContext",
    "EnvelopeCipher",
    "SymbolRemapper",
    "ContextualKeyDeriver",
    "ALGO_AES256GCM",
    "ALGO_CHACHA20_POLY1305",
]
