"""
Wire.Band Edge — WebSocket streaming client for low-latency ingest.

Uses the ws:// protocol instead of HTTP batch flush for sub-second event
delivery.  Suitable for high-frequency sensors or compliance-critical streams
where flush interval latency is unacceptable.

Requires the [stream] optional extra:

    pip install "wire-band-edge[stream]"
"""

import asyncio
import json
import logging
import sys
import time
from typing import Any, Dict, Optional

_EDGE_VERSION = "0.4.0"

logger = logging.getLogger(__name__)


class WireBandStreamClient:
    """
    WebSocket streaming ingest client.

    Connects to ws(s)://backend/iot/v1/ws/ingest and sends each event
    immediately — no local buffer, no batch flush interval.

    Suitable for:
    - High-frequency sensors (>100 Hz)
    - Compliance audit streams requiring per-event timestamped delivery
    - Agent mesh state synchronisation where batch latency is unacceptable

    Args:
        backend_url:  Wire.Band backend HTTP base URL.
                      http:// → ws://, https:// → wss:// automatically.
        device_id:    Unique identifier for this edge node.
        api_key:      Optional bearer token (sent as query param on connect).
        reconnect:    Automatically reconnect on disconnect. Default: True.
        backoff_base: Base seconds for reconnection backoff. Default: 2.0.
        max_backoff:  Maximum reconnection backoff cap (seconds). Default: 60.
    """

    def __init__(
        self,
        backend_url: str = "http://localhost:8000",
        device_id: str = "stream-node",
        api_key: Optional[str] = None,
        reconnect: bool = True,
        backoff_base: float = 2.0,
        max_backoff: float = 60.0,
    ) -> None:
        url = backend_url.rstrip("/")
        if url.startswith("https://"):
            url = "wss://" + url[8:]
        elif url.startswith("http://"):
            url = "ws://" + url[7:]
        self._ws_base = f"{url}/iot/v1/ws/ingest"
        self._device_id = device_id
        self._api_key = api_key
        self._reconnect = reconnect
        self._backoff_base = backoff_base
        self._max_backoff = max_backoff

        self._ws: Any = None
        self._connected = False
        self._reconnect_task: Optional[asyncio.Task] = None

        self._stats: Dict[str, Any] = {
            "events_sent":  0,
            "send_errors":  0,
            "reconnects":   0,
            "started_at":   time.time(),
        }

    # ------------------------------------------------------------------
    # Lifecycle
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Open the WebSocket connection to the backend."""
        try:
            import websockets
        except ImportError:
            raise ImportError(
                "websockets is required for streaming: "
                "pip install 'wire-band-edge[stream]'"
            )

        params = f"device_id={self._device_id}"
        if self._api_key:
            params += f"&api_key={self._api_key}"
        url = f"{self._ws_base}?{params}"

        self._ws = await websockets.connect(
            url,
            additional_headers={
                "User-Agent": (
                    f"wire-band-edge/{_EDGE_VERSION} "
                    f"Python/{sys.version_info.major}.{sys.version_info.minor}"
                )
            },
            ping_interval=20,
            ping_timeout=10,
        )
        self._connected = True
        logger.info(
            "WireBandStreamClient connected: device=%s url=%s",
            self._device_id, self._ws_base,
        )

    async def disconnect(self) -> None:
        """Close the WebSocket connection."""
        self._connected = False
        if self._reconnect_task and not self._reconnect_task.done():
            self._reconnect_task.cancel()
        if self._ws is not None:
            await self._ws.close()
            self._ws = None
        logger.info(
            "WireBandStreamClient disconnected. Stats: %s", self.stats()
        )

    # ------------------------------------------------------------------
    # Send
    # ------------------------------------------------------------------

    async def send(
        self,
        data: Any,
        topic: str = "default",
        symbol: Optional[int] = None,
    ) -> bool:
        """
        Stream a single event immediately over the WebSocket connection.

        Args:
            data:   The payload — dict, list, str, or numeric.
            topic:  Logical topic name (used as routing key on the server).
            symbol: Override semantic symbol. If None, a generic gauge is used.

        Returns:
            True on success, False if the send failed.
        """
        from .symbols import METRICS_GAUGE_SET as _gauge
        sym = symbol if symbol is not None else _gauge

        body = json.dumps(
            {"t": topic, "d": data},
            separators=(",", ":"),
            ensure_ascii=False,
        ).encode("utf-8")
        frame = bytes([sym >> 8, sym & 0xFF]) + body

        msg = json.dumps({
            "device_id": self._device_id,
            "topic":     topic,
            "symbol":    hex(sym),
            "frame":     frame.hex(),
            "ts":        time.time(),
        })

        if not self._connected or self._ws is None:
            logger.warning("WireBandStreamClient.send called while not connected")
            self._stats["send_errors"] += 1
            return False

        try:
            await self._ws.send(msg)
            self._stats["events_sent"] += 1
            return True
        except Exception as exc:
            logger.warning("WireBandStreamClient send error: %s", exc)
            self._stats["send_errors"] += 1
            self._connected = False
            if self._reconnect:
                self._reconnect_task = asyncio.create_task(self._reconnect_loop())
            return False

    # ------------------------------------------------------------------
    # Stats
    # ------------------------------------------------------------------

    def stats(self) -> Dict[str, Any]:
        s = dict(self._stats)
        uptime = time.time() - s.pop("started_at")
        return {
            **s,
            "connected":      self._connected,
            "uptime_seconds": round(uptime, 1),
            "device_id":      self._device_id,
        }

    # ------------------------------------------------------------------
    # Auto-reconnect
    # ------------------------------------------------------------------

    async def _reconnect_loop(self) -> None:
        attempt = 0
        while not self._connected:
            backoff = min(self._backoff_base ** attempt, self._max_backoff)
            logger.info(
                "WireBandStreamClient reconnecting in %.1fs (attempt %d)...",
                backoff, attempt + 1,
            )
            await asyncio.sleep(backoff)
            try:
                await self.connect()
                self._stats["reconnects"] += 1
                return
            except Exception as exc:
                logger.warning(
                    "WireBandStreamClient reconnect attempt %d failed: %s",
                    attempt + 1, exc,
                )
                attempt += 1

    # ------------------------------------------------------------------
    # Context manager
    # ------------------------------------------------------------------

    async def __aenter__(self) -> "WireBandStreamClient":
        await self.connect()
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.disconnect()
