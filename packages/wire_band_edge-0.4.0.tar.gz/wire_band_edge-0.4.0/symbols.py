"""
Theta symbol constants — inlined for zero-dependency edge installs.

Plain int constants (no IntEnum), no imports. Runs on any Python 3.10+
environment including constrained devices.

Covers all symbol families: IoT hardware, geographic, metrics, security,
storage, AI/ML, networking, protocols, DeFi, legal, temporal, and agent/
system coordination families. Wire.Band transports any structured data
domain — not just IoT.

Backward-compat note: three legacy geo names map to values that differ from
the current spec. Use the spec-correct names (GEO_VELOCITY, GF_DEFINE,
GF_ENTER, GF_EXIT, PROX_NEARBY) for new code.
"""

# ===========================================================================
# PRIMARY SYMBOL SPACE — 1-byte frame opcodes
# ===========================================================================

# ---------------------------------------------------------------------------
# SYSTEM (0x00–0x0F)
# ---------------------------------------------------------------------------
SYS_NOP       = 0x00  # No-operation / padding
SYS_PING      = 0x01  # Liveness check
SYS_PONG      = 0x02  # Liveness reply
SYS_ACK       = 0x03  # Acknowledgement
SYS_NACK      = 0x04  # Negative acknowledgement
SYS_RESET     = 0x05  # Reset connection / state
SYS_HELLO     = 0x06  # Session initiation
SYS_BYE       = 0x07  # Session termination
SYS_ERROR     = 0x08  # Error frame
SYS_HEARTBEAT = 0x09  # Keepalive heartbeat
SYS_CAPS      = 0x0A  # Capability advertisement
SYS_ROUTE     = 0x0B  # Routing hint

# ---------------------------------------------------------------------------
# NOUS (0x10–0x1F) — Verification / attestation
# ---------------------------------------------------------------------------
NOUS_VERIFY    = 0x10  # Verify claim
NOUS_ATTEST    = 0x11  # Attestation
NOUS_PROVE     = 0x12  # Submit proof
NOUS_CHALLENGE = 0x13  # Issue challenge
NOUS_RESPOND   = 0x14  # Respond to challenge
NOUS_TRUST     = 0x15  # Trust signal
NOUS_DISTRUST  = 0x16  # Distrust signal
NOUS_REVOKE    = 0x17  # Revoke attestation

# ---------------------------------------------------------------------------
# ERGON (0x20–0x2F) — Token / economic accounting
# ---------------------------------------------------------------------------
ERGON_BALANCE  = 0x20  # Query balance
ERGON_CREDIT   = 0x21  # Credit tokens
ERGON_DEBIT    = 0x22  # Debit tokens
ERGON_TRANSFER = 0x23  # Transfer between accounts
ERGON_RESERVE  = 0x24  # Lock tokens
ERGON_RELEASE  = 0x25  # Release locked tokens
ERGON_INVOICE  = 0x26  # Issue invoice
ERGON_SETTLE   = 0x27  # Settle invoice
ERGON_REFUND   = 0x28  # Refund
ERGON_QUOTE    = 0x29  # Price quote

# ---------------------------------------------------------------------------
# WORK (0x30–0x3F) — Task execution
# ---------------------------------------------------------------------------
WORK_SUBMIT   = 0x30  # Submit task
WORK_ASSIGN   = 0x31  # Assign task to agent
WORK_PROGRESS = 0x32  # Progress update
WORK_COMPLETE = 0x33  # Task completed
WORK_FAIL     = 0x34  # Task failed
WORK_CANCEL   = 0x35  # Cancel task
WORK_QUERY    = 0x36  # Query task status
WORK_ANALYZE  = 0x37  # Analyze / process
WORK_OPTIMIZE = 0x38  # Optimize
WORK_EXECUTE  = 0x39  # Execute directly
WORK_BATCH    = 0x3A  # Batch work items
WORK_SCHEDULE = 0x3B  # Schedule future work

# ---------------------------------------------------------------------------
# SWARM (0x40–0x4F) — Multi-agent coordination
# ---------------------------------------------------------------------------
SWARM_COORDINATE = 0x40  # Coordinate agents
SWARM_BROADCAST  = 0x41  # Broadcast to all
SWARM_CONSENSUS  = 0x42  # Consensus request
SWARM_DELEGATE   = 0x43  # Delegate task
SWARM_AGGREGATE  = 0x44  # Aggregate results
SWARM_DISTRIBUTE = 0x45  # Distribute work
SWARM_ELECT      = 0x46  # Leader election
SWARM_SYNC       = 0x47  # State sync
SWARM_SPLIT      = 0x48  # Split swarm
SWARM_MERGE      = 0x49  # Merge swarms

# ---------------------------------------------------------------------------
# IDENTITY (0x50–0x5F)
# ---------------------------------------------------------------------------
IDENT_REGISTER = 0x50  # Register identity
IDENT_LOOKUP   = 0x51  # Lookup identity
IDENT_UPDATE   = 0x52  # Update identity
IDENT_REVOKE   = 0x53  # Revoke identity
IDENT_BIND     = 0x54  # Bind identity to session
IDENT_UNBIND   = 0x55  # Unbind
IDENT_ALIAS    = 0x56  # Set alias

# ---------------------------------------------------------------------------
# GOVERNANCE (0x60–0x6F)
# ---------------------------------------------------------------------------
GOV_PROPOSE  = 0x60  # Submit proposal
GOV_VOTE     = 0x61  # Cast vote
GOV_TALLY    = 0x62  # Request tally
GOV_ENACT    = 0x63  # Enact decision
GOV_VETO     = 0x64  # Veto proposal
GOV_AMEND    = 0x65  # Amend proposal
GOV_DELEGATE = 0x66  # Delegate voting power

# ---------------------------------------------------------------------------
# AUTHORITY (0x70–0x7F) — Privilege levels
# ---------------------------------------------------------------------------
AUTH_GRANT   = 0x70  # Grant privilege
AUTH_REVOKE  = 0x71  # Revoke privilege
AUTH_CHECK   = 0x72  # Check privilege
AUTH_ELEVATE = 0x73  # Elevate to higher ring
AUTH_DROP    = 0x74  # Drop to lower ring
AUTH_SUDO    = 0x75  # Temporary privilege elevation

# ---------------------------------------------------------------------------
# THETA (0x80–0x9F) — Resource management
# ---------------------------------------------------------------------------
THETA_ALLOCATE = 0x80  # Allocate resources
THETA_CONSUME  = 0x81  # Consume
THETA_TRANSFER = 0x82  # Transfer
THETA_BALANCE  = 0x83  # Balance query
THETA_RESERVE  = 0x84  # Reserve
THETA_RELEASE  = 0x85  # Release reserved
THETA_BURN     = 0x86  # Burn (permanent removal)
THETA_MINT     = 0x87  # Mint (issuance)
THETA_STAKE    = 0x88  # Stake
THETA_UNSTAKE  = 0x89  # Unstake
THETA_REWARD   = 0x8A  # Distribute reward
THETA_SLASH    = 0x8B  # Apply slash
THETA_EPOCH    = 0x8C  # Epoch boundary
THETA_SNAPSHOT = 0x8D  # Take balance snapshot

# ---------------------------------------------------------------------------
# HIVEMIND (0xA0–0xBF) — P2P / distributed fabric
# ---------------------------------------------------------------------------
HIVE_JOIN        = 0xA0  # Join hivemind
HIVE_LEAVE       = 0xA1  # Leave hivemind
HIVE_ANNOUNCE    = 0xA2  # Announce capability
HIVE_DISCOVER    = 0xA3  # Discover peers
HIVE_ROUTE       = 0xA4  # Route message through fabric
HIVE_RELAY       = 0xA5  # Relay message
HIVE_PUBLISH     = 0xA6  # Publish to topic
HIVE_SUBSCRIBE   = 0xA7  # Subscribe to topic
HIVE_UNSUBSCRIBE = 0xA8  # Unsubscribe
HIVE_GOSSIP      = 0xA9  # Gossip protocol
HIVE_DHT_GET     = 0xAA  # DHT lookup
HIVE_DHT_PUT     = 0xAB  # DHT store
HIVE_SHARD       = 0xAC  # Shard coordination
HIVE_REPLICATE   = 0xAD  # Replicate data
HIVE_CONSENSUS   = 0xAE  # Distributed consensus
HIVE_PARTITION   = 0xAF  # Partition event

# ---------------------------------------------------------------------------
# INGEST (0xC0–0xCF) — External → internal
# ---------------------------------------------------------------------------
INGEST_JSON     = 0xC0  # Ingest from JSON
INGEST_TEXT     = 0xC1  # Ingest from plaintext
INGEST_BINARY   = 0xC2  # Ingest from raw binary
INGEST_STREAM   = 0xC3  # Ingest from stream
INGEST_BATCH    = 0xC4  # Ingest batch
INGEST_SCHEMA   = 0xC5  # Ingest with schema hint
INGEST_VALIDATE = 0xC6  # Ingest + validate

# ---------------------------------------------------------------------------
# EMIT (0xD0–0xDF) — Internal → external
# ---------------------------------------------------------------------------
EMIT_JSON   = 0xD0  # Emit as JSON
EMIT_TEXT   = 0xD1  # Emit as plaintext
EMIT_BINARY = 0xD2  # Emit as raw binary
EMIT_STREAM = 0xD3  # Emit to stream
EMIT_BATCH  = 0xD4  # Emit batch
EMIT_FORMAT = 0xD5  # Emit with format hint

# ---------------------------------------------------------------------------
# TRANSFORM (0xE0–0xE7)
# ---------------------------------------------------------------------------
XFORM_COMPRESS   = 0xE0  # Apply compression
XFORM_DECOMPRESS = 0xE1  # Remove compression
XFORM_ENCODE     = 0xE2  # Encode
XFORM_DECODE     = 0xE3  # Decode
XFORM_FILTER     = 0xE4  # Filter fields
XFORM_MAP        = 0xE5  # Map/transform fields
XFORM_REDUCE     = 0xE6  # Reduce / fold
XFORM_MERGE      = 0xE7  # Merge structures

# ---------------------------------------------------------------------------
# ORACLE (0xE8–0xEF)
# ---------------------------------------------------------------------------
ORACLE_EXPLAIN  = 0xE8  # Explain / translate to human-readable
ORACLE_VALIDATE = 0xE9  # Validate frame integrity
ORACLE_INSPECT  = 0xEA  # Inspect symbol families present
ORACLE_TRACE    = 0xEB  # Trace execution path
ORACLE_DIFF     = 0xEC  # Diff two frames
ORACLE_REPLAY   = 0xED  # Replay frame sequence
ORACLE_STATS    = 0xEE  # Statistics / telemetry
ORACLE_HEALTH   = 0xEF  # Health check

# ---------------------------------------------------------------------------
# KAPPA (0xF0–0xF7) — Bonding curve operations
# ---------------------------------------------------------------------------
KAPPA_BUY      = 0xF0  # Buy tokens via bonding curve
KAPPA_SELL     = 0xF1  # Sell tokens via bonding curve
KAPPA_PRICE    = 0xF2  # Query current bonding curve price
KAPPA_GRADUATE = 0xF3  # Graduation event
KAPPA_RESERVE  = 0xF4  # Query reserve balance
KAPPA_STAKE    = 0xF5  # Stake into curve
KAPPA_UNSTAKE  = 0xF6  # Unstake from curve

# ---------------------------------------------------------------------------
# PSI (0xF8–0xFF) — Agent-specific token operations
# ---------------------------------------------------------------------------
PSI_MINT     = 0xF8  # Mint agent token
PSI_BURN     = 0xF9  # Burn agent token
PSI_TRANSFER = 0xFA  # Transfer between agents
PSI_BIND     = 0xFB  # Bind bonding curve to agent identity
PSI_ATTEST   = 0xFC  # Quality attestation
PSI_REWARD   = 0xFD  # Distribute reward to agent
PSI_SLASH    = 0xFE  # Slash agent for misbehaviour

# ===========================================================================
# EXTENDED SYMBOL SPACE — 2-byte payload-embedded symbols
# ===========================================================================

# ---------------------------------------------------------------------------
# PHRONESIS (0xF0xx) — Debug / testing / verification
# ---------------------------------------------------------------------------
PHR_PASS      = 0xF000  # Assertion passed
PHR_FAIL      = 0xF001  # Assertion failed
PHR_SKIP      = 0xF002  # Assertion skipped
PHR_WARN      = 0xF003  # Soft assertion warning
PHR_EQ        = 0xF004  # Assert equal
PHR_NEQ       = 0xF005  # Assert not equal
PHR_GT        = 0xF006  # Assert greater than
PHR_LT        = 0xF007  # Assert less than
PHR_GTE       = 0xF008  # Assert >=
PHR_LTE       = 0xF009  # Assert <=
PHR_NULL      = 0xF00A  # Assert null / None
PHR_NOT_NULL  = 0xF00B  # Assert not null
PHR_TYPE      = 0xF00C  # Assert type match
PHR_RAISES    = 0xF00D  # Assert raises exception
PHR_APPROX    = 0xF00E  # Assert approximately equal
PHR_INVARIANT = 0xF00F  # Assert invariant holds
PHR_SAMPLE      = 0xF010  # Sample current state
PHR_SNAPSHOT    = 0xF011  # Snapshot memory/state
PHR_PROBE_PING  = 0xF012  # Liveness ping
PHR_PROBE_PONG  = 0xF013  # Liveness pong
PHR_HEARTBEAT   = 0xF014  # Heartbeat pulse
PHR_READINESS   = 0xF015  # Readiness check
PHR_HEALTH      = 0xF016  # Health check
PHR_LATENCY     = 0xF017  # Latency measurement
PHR_THROUGHPUT  = 0xF018  # Throughput sample
PHR_MEMORY      = 0xF019  # Memory usage sample
PHR_CPU         = 0xF01A  # CPU usage sample
PHR_NETWORK     = 0xF01B  # Network probe
PHR_DISK        = 0xF01C  # Disk probe
PHR_QUEUE       = 0xF01D  # Queue depth probe
PHR_CONCURRENCY = 0xF01E  # Concurrency probe
PHR_TRACE_ENTER  = 0xF020  # Function enter
PHR_TRACE_EXIT   = 0xF021  # Function exit
PHR_TRACE_CALL   = 0xF022  # Function call
PHR_TRACE_RETURN = 0xF023  # Function return
PHR_TRACE_YIELD  = 0xF024  # Generator yield
PHR_TRACE_AWAIT  = 0xF025  # Coroutine await
PHR_EXCEPTION    = 0xF026  # Exception thrown
PHR_CATCH        = 0xF027  # Exception caught
PHR_BRANCH       = 0xF028  # Branch taken
PHR_LOOP         = 0xF029  # Loop iteration
PHR_RECURSE      = 0xF02A  # Recursive call
PHR_SPAWN        = 0xF02C  # Task/thread spawned
PHR_JOIN         = 0xF02D  # Task/thread joined
PHR_LOCK         = 0xF02E  # Lock acquired
PHR_UNLOCK       = 0xF02F  # Lock released
PHR_BP_SET       = 0xF030  # Breakpoint set
PHR_BP_HIT       = 0xF031  # Breakpoint hit
PHR_BP_CLEAR     = 0xF032  # Breakpoint cleared
PHR_BP_CONDITION = 0xF033  # Conditional breakpoint
PHR_WATCHPOINT   = 0xF034  # Watchpoint set
PHR_WATCH_HIT    = 0xF035  # Watchpoint hit
PHR_STEP         = 0xF036  # Step instruction
PHR_CONTINUE     = 0xF037  # Continue execution
PHR_PAUSE        = 0xF038  # Pause execution
PHR_DUMP         = 0xF039  # Memory / state dump
PHR_STACK        = 0xF03A  # Stack trace captured
PHR_INSPECT      = 0xF03B  # Variable inspected
PHR_EVAL         = 0xF03C  # Expression evaluated
PHR_INJECT       = 0xF03D  # Value injected
PHR_RESET        = 0xF03E  # Reset to checkpoint
PHR_COV_LINE     = 0xF040  # Line covered
PHR_COV_BRANCH_T = 0xF041  # Branch true covered
PHR_COV_BRANCH_F = 0xF042  # Branch false covered
PHR_COV_FUNC     = 0xF043  # Function covered
PHR_COV_STMT     = 0xF044  # Statement covered
PHR_COV_MISS     = 0xF045  # Coverage miss
PHR_COV_REPORT   = 0xF046  # Coverage report
PHR_COV_THRESHOLD= 0xF047  # Below coverage threshold
PHR_COV_EXCLUDE  = 0xF048  # Excluded from coverage
PHR_COV_MUTATION = 0xF049  # Mutation test point
PHR_FUZZ_START   = 0xF050  # Fuzzing started
PHR_FUZZ_STOP    = 0xF051  # Fuzzing stopped
PHR_FUZZ_CORPUS  = 0xF052  # Corpus entry added
PHR_FUZZ_CRASH   = 0xF053  # Crash discovered
PHR_FUZZ_HANG    = 0xF054  # Hang detected
PHR_FUZZ_REDUCE  = 0xF055  # Input minimized
PHR_FUZZ_SEED    = 0xF056  # Seed added
PHR_FUZZ_MUTATE  = 0xF057  # Mutation applied
PHR_FUZZ_NEW_COV = 0xF058  # New coverage found
PHR_REPLAY_REC   = 0xF060  # Recording started
PHR_REPLAY_STOP  = 0xF061  # Recording stopped
PHR_REPLAY_PLAY  = 0xF062  # Replay started
PHR_REPLAY_SEEK  = 0xF063  # Seek to position
PHR_REPLAY_CKPT  = 0xF064  # Checkpoint saved
PHR_REPLAY_RSTR  = 0xF065  # Checkpoint restored
PHR_REPLAY_DIVG  = 0xF066  # Replay diverged
PHR_CANARY_ALIVE = 0xF070  # Canary alive
PHR_CANARY_DEAD  = 0xF071  # Canary dead (sentinel tripped)
PHR_CANARY_STACK = 0xF072  # Stack canary check
PHR_CANARY_HEAP  = 0xF073  # Heap canary check
PHR_TRIPWIRE     = 0xF075  # Tripwire triggered
PHR_INTEGRITY    = 0xF077  # Integrity check passed
PHR_TAMPER       = 0xF078  # Tampering detected
PHR_OVERFLOW     = 0xF07C  # Buffer overflow detected
PHR_UNDERFLOW    = 0xF07D  # Buffer underflow detected
PHR_LEAK         = 0xF07E  # Memory leak detected

# ---------------------------------------------------------------------------
# PROTOCOL (0xF1xx) — External protocols
# ---------------------------------------------------------------------------
PROT_BASE        = 0xF100  # Base protocol operation
PROT_CONNECT     = 0xF101  # Connect to protocol
PROT_DISCONNECT  = 0xF102  # Disconnect
PROT_AUTH        = 0xF103  # Authenticate
PROT_REQUEST     = 0xF104  # Send request
PROT_RESPONSE    = 0xF105  # Receive response
PROT_STREAM      = 0xF106  # Streaming
PROT_SUBSCRIBE   = 0xF107  # Subscribe
PROT_UNSUBSCRIBE = 0xF108  # Unsubscribe
PROT_PING        = 0xF109  # Ping/health check
PROT_ERROR       = 0xF10B  # Error
PROT_RETRY       = 0xF10C  # Retry
PROT_TIMEOUT     = 0xF10D  # Timeout
PROT_RATELIMIT   = 0xF10E  # Rate limited
CHAIN_ETHEREUM   = 0xF110  # Ethereum
CHAIN_BITCOIN    = 0xF111  # Bitcoin
CHAIN_SOLANA     = 0xF112  # Solana
CHAIN_COSMOS     = 0xF113  # Cosmos
CHAIN_TON        = 0xF114  # TON
CHAIN_POLYGON    = 0xF115  # Polygon
CHAIN_ARBITRUM   = 0xF116  # Arbitrum
CHAIN_OPTIMISM   = 0xF117  # Optimism
CHAIN_BASE       = 0xF118  # Base
CHAIN_AVALANCHE  = 0xF119  # Avalanche
CHAIN_BSC        = 0xF11A  # BNB Chain
CHAIN_NEAR       = 0xF11B  # NEAR
CHAIN_APTOS      = 0xF11C  # Aptos
CHAIN_SUI        = 0xF11D  # Sui
CHAIN_TAO        = 0xF11E  # Bittensor
CHAIN_CALL       = 0xF120  # Contract call
CHAIN_SEND       = 0xF121  # Send transaction
CHAIN_SIGN       = 0xF122  # Sign message
CHAIN_VERIFY     = 0xF123  # Verify signature
CHAIN_DEPLOY     = 0xF124  # Deploy contract
CHAIN_EVENT      = 0xF126  # Event emitted
CHAIN_RECEIPT    = 0xF128  # Transaction receipt
CHAIN_REVERT     = 0xF129  # Transaction reverted
CHAIN_GAS        = 0xF12A  # Gas estimation
CHAIN_NONCE      = 0xF12B  # Nonce management
CHAIN_PENDING    = 0xF12C  # Pending transaction
CHAIN_CONFIRM    = 0xF12D  # Confirmed
CHAIN_FINALIZE   = 0xF12E  # Finalized
CHAIN_BLOCK      = 0xF12F  # Block reference
MSG_TELEGRAM     = 0xF130  # Telegram
MSG_DISCORD      = 0xF131  # Discord
MSG_SLACK        = 0xF132  # Slack
MSG_WHATSAPP     = 0xF133  # WhatsApp
MSG_SIGNAL       = 0xF134  # Signal
MSG_MATRIX       = 0xF135  # Matrix
MSG_IRC          = 0xF136  # IRC
MSG_XMPP         = 0xF137  # XMPP/Jabber
MSG_EMAIL        = 0xF138  # Email
MSG_SMS          = 0xF139  # SMS
MSG_PUSH         = 0xF13A  # Push notification
MSG_WEBHOOK      = 0xF13B  # Webhook
MSG_BOT          = 0xF13C  # Bot message
MSG_DIRECT       = 0xF13D  # Direct message
MSG_CHANNEL      = 0xF13E  # Channel message
MSG_THREAD       = 0xF13F  # Thread message
SOCIAL_TWITTER   = 0xF140  # X/Twitter
SOCIAL_FARCASTER = 0xF141  # Farcaster
SOCIAL_LENS      = 0xF142  # Lens Protocol
SOCIAL_BLUESKY   = 0xF143  # Bluesky
SOCIAL_MASTODON  = 0xF144  # Mastodon
SOCIAL_REDDIT    = 0xF145  # Reddit
SOCIAL_LINKEDIN  = 0xF146  # LinkedIn
SOCIAL_GITHUB    = 0xF147  # GitHub
SOCIAL_YOUTUBE   = 0xF148  # YouTube
SOCIAL_NOSTR     = 0xF14C  # Nostr
API_REST         = 0xF150  # REST API
API_GRAPHQL      = 0xF151  # GraphQL
API_GRPC         = 0xF152  # gRPC
API_WEBSOCKET    = 0xF153  # WebSocket
API_SSE          = 0xF154  # Server-Sent Events
API_SOAP         = 0xF155  # SOAP
API_JSONRPC      = 0xF156  # JSON-RPC
API_THRIFT       = 0xF157  # Thrift
API_MSGPACK      = 0xF158  # MessagePack
API_PROTOBUF     = 0xF159  # Protocol Buffers
API_AVRO         = 0xF15A  # Avro
API_MQTT         = 0xF15B  # MQTT
API_AMQP         = 0xF15C  # AMQP
API_NATS         = 0xF15D  # NATS
API_KAFKA        = 0xF15E  # Kafka
API_REDIS        = 0xF15F  # Redis pub/sub
AUTH_OAUTH2      = 0xF160  # OAuth 2.0
AUTH_OIDC        = 0xF161  # OpenID Connect
AUTH_SAML        = 0xF162  # SAML
AUTH_JWT         = 0xF163  # JWT
AUTH_APIKEY      = 0xF164  # API Key
AUTH_BASIC       = 0xF165  # Basic Auth
AUTH_BEARER      = 0xF166  # Bearer Token
AUTH_HMAC        = 0xF167  # HMAC
AUTH_PASSKEY     = 0xF168  # Passkey/WebAuthn
AUTH_SIWE        = 0xF169  # Sign-In with Ethereum
AUTH_WC          = 0xF16A  # WalletConnect
AUTH_2FA         = 0xF16B  # Two-Factor Auth
AUTH_MFA         = 0xF16C  # Multi-Factor Auth
AUTH_SSO         = 0xF16D  # Single Sign-On
AUTH_DEVICE      = 0xF16E  # Device auth
AUTH_REFRESH     = 0xF16F  # Refresh token
BRIDGE_INIT      = 0xF170  # Initialize bridge
BRIDGE_LOCK      = 0xF171  # Lock assets
BRIDGE_UNLOCK    = 0xF172  # Unlock assets
BRIDGE_MINT      = 0xF173  # Mint wrapped
BRIDGE_BURN      = 0xF174  # Burn wrapped
BRIDGE_RELAY     = 0xF175  # Relay message
BRIDGE_VERIFY    = 0xF176  # Verify proof
BRIDGE_CLAIM     = 0xF177  # Claim on dest
BRIDGE_FINALIZE  = 0xF178  # Finalize transfer
BRIDGE_REVERT    = 0xF179  # Revert transfer
BRIDGE_FEE       = 0xF17A  # Bridge fee
BRIDGE_STATUS    = 0xF17C  # Bridge status
BRIDGE_PROOF     = 0xF17D  # Generate proof
BRIDGE_ATTEST    = 0xF17E  # Attestation
BRIDGE_COMPLETE  = 0xF17F  # Bridge complete

# ---------------------------------------------------------------------------
# METRICS (0xF2xx) — Metrics / telemetry / observability
# ---------------------------------------------------------------------------
METRICS_COUNTER_INC    = 0xF200  # Counter increment (+1)
METRICS_COUNTER_ADD    = 0xF201  # Counter increment (+n)
METRICS_COUNTER_RESET  = 0xF202  # Counter reset to zero
METRICS_COUNTER_SNAP   = 0xF203  # Counter snapshot
METRICS_COUNTER_RATE   = 0xF204  # Compute rate
METRICS_COUNTER_DELTA  = 0xF205  # Delta since last snapshot
METRICS_GAUGE_SET      = 0xF210  # Gauge set value
METRICS_GAUGE_INC      = 0xF211  # Gauge increment
METRICS_GAUGE_DEC      = 0xF212  # Gauge decrement
METRICS_GAUGE_MAX      = 0xF213  # Record maximum
METRICS_GAUGE_MIN      = 0xF214  # Record minimum
METRICS_GAUGE_AVG      = 0xF215  # Running average
METRICS_GAUGE_CURRENT  = 0xF216  # Gauge current value
METRICS_GAUGE_PEAK     = 0xF217  # Peak value observed
METRICS_HIST_OBSERVE   = 0xF220  # Histogram observe
METRICS_HIST_P50       = 0xF221  # 50th percentile
METRICS_HIST_P90       = 0xF222  # 90th percentile
METRICS_HIST_P95       = 0xF223  # 95th percentile
METRICS_HIST_P99       = 0xF224  # 99th percentile
METRICS_HIST_P999      = 0xF225  # 99.9th percentile
METRICS_HIST_MAX       = 0xF226  # Maximum observed
METRICS_HIST_MEAN      = 0xF228  # Mean
METRICS_HIST_STDDEV    = 0xF229  # Standard deviation
METRICS_TIMER_START    = 0xF230  # Timer start
METRICS_TIMER_STOP     = 0xF231  # Timer stop
METRICS_TIMER_RECORD   = 0xF232  # Record duration
METRICS_TIMER_SLA      = 0xF237  # SLA boundary check
METRICS_SPAN_START     = 0xF240  # Trace span start
METRICS_SPAN_END       = 0xF241  # Trace span end
METRICS_SPAN_ERROR     = 0xF242  # Trace span error
METRICS_SPAN_CHILD     = 0xF243  # Child span created
METRICS_SPAN_TAG       = 0xF246  # Span tag set
METRICS_EVENT_EMIT_V2  = 0xF250  # Event emitted (use for new code)
METRICS_EVENT_RECEIVE  = 0xF251  # Event received
METRICS_EVENT_DROP     = 0xF252  # Event dropped
METRICS_EVENT_QUEUE    = 0xF253  # Event queued
METRICS_EVENT_PROCESS  = 0xF254  # Event processed
METRICS_ALERT_FIRE     = 0xF260  # Alert fired
METRICS_ALERT_RESOLVE  = 0xF261  # Alert resolved
METRICS_ALERT_SUPPRESS = 0xF262  # Alert suppressed
METRICS_ALERT_ESCALATE = 0xF263  # Alert escalated
METRICS_ALERT_PAGE     = 0xF264  # On-call page triggered
METRICS_FLUSH          = 0xF270  # Flush buffer to backend
METRICS_EXPORT         = 0xF271  # Export metrics batch
METRICS_SCRAPE         = 0xF272  # Prometheus scrape
METRICS_PUSH           = 0xF273  # Push to remote
METRICS_ROLLUP         = 0xF276  # Rollup (downsample)

# Legacy: kept for backward compatibility (tests + mqtt_connector use this)
METRICS_EVENT_EMIT = 0xF230  # DEPRECATED: same value as METRICS_TIMER_START; use METRICS_EVENT_EMIT_V2

# ---------------------------------------------------------------------------
# SECURITY (0xF3xx)
# ---------------------------------------------------------------------------
SEC_BASE       = 0xF300  # Base security operation
SEC_CHECK      = 0xF301  # Security check
SEC_PASS       = 0xF302  # Security passed
SEC_FAIL       = 0xF303  # Security failed
SEC_WARN       = 0xF304  # Security warning
SEC_ALERT      = 0xF305  # Security alert
SEC_BLOCK      = 0xF306  # Block operation
SEC_ALLOW      = 0xF307  # Allow operation
SEC_DENY       = 0xF308  # Deny operation
SEC_LOG        = 0xF309  # Log security event
SEC_ESCALATE   = 0xF30A  # Escalate incident
SEC_RESOLVE    = 0xF30B  # Resolve incident
SEC_SCAN       = 0xF30D  # Security scan
SEC_PATCH      = 0xF30E  # Apply patch
CRYPTO_SIGN    = 0xF310  # Sign
CRYPTO_VERIFY  = 0xF311  # Verify signature
CRYPTO_ENCRYPT = 0xF312  # Encrypt
CRYPTO_DECRYPT = 0xF313  # Decrypt
CRYPTO_HASH    = 0xF314  # Hash
CRYPTO_HMAC    = 0xF315  # HMAC
CRYPTO_KDF     = 0xF316  # Key derivation
CRYPTO_RANDOM  = 0xF317  # Random generation
CRYPTO_SEAL    = 0xF318  # Seal data
CRYPTO_UNSEAL  = 0xF319  # Unseal data
CRYPTO_ZK_PROVE  = 0xF31D  # ZK proof
CRYPTO_ZK_VERIFY = 0xF31E  # ZK verify
CRYPTO_MPC       = 0xF31F  # Multi-party compute
KEY_GENERATE   = 0xF320  # Generate key
KEY_IMPORT     = 0xF321  # Import key
KEY_EXPORT     = 0xF322  # Export key
KEY_ROTATE     = 0xF323  # Rotate key
KEY_REVOKE     = 0xF324  # Revoke key
KEY_BACKUP     = 0xF325  # Backup key
KEY_RESTORE    = 0xF326  # Restore key
KEY_DERIVE     = 0xF327  # Derive key
KEY_WRAP       = 0xF328  # Wrap key
KEY_UNWRAP     = 0xF329  # Unwrap key
KEY_SPLIT      = 0xF32A  # Split key (Shamir)
KEY_COMBINE    = 0xF32B  # Combine shares
KEY_ESCROW     = 0xF32C  # Escrow key
KEY_RECOVER    = 0xF32D  # Recover key
KEY_ATTEST     = 0xF32E  # Key attestation
KEY_EXPIRE     = 0xF32F  # Key expiration
ACCESS_AUTH    = 0xF330  # Authenticate
ACCESS_AUTHZ   = 0xF331  # Authorize
ACCESS_GRANT   = 0xF332  # Grant access
ACCESS_REVOKE  = 0xF333  # Revoke access
ACCESS_ROLE    = 0xF334  # Role assignment
ACCESS_POLICY  = 0xF336  # Policy check
ACCESS_MFA     = 0xF338  # MFA required
ACCESS_SESSION = 0xF339  # Session management
ACCESS_TOKEN   = 0xF33A  # Token issued
ACCESS_REFRESH = 0xF33B  # Token refresh
ACCESS_EXPIRE  = 0xF33C  # Session expire
ACCESS_LOCKOUT = 0xF33D  # Account lockout
AUDIT_LOG      = 0xF340  # Log event
AUDIT_READ     = 0xF341  # Read audit
AUDIT_QUERY    = 0xF342  # Query audit
AUDIT_EXPORT   = 0xF343  # Export audit
AUDIT_INTEGRITY= 0xF347  # Integrity check
AUDIT_TAMPER   = 0xF348  # Tamper detected
THREAT_DETECT  = 0xF350  # Threat detected
THREAT_ANALYZE = 0xF351  # Threat analysis
THREAT_CLASSIFY= 0xF352  # Classify threat
THREAT_SCORE   = 0xF353  # Threat score
THREAT_ALERT   = 0xF354  # Threat alert
THREAT_MITIGATE= 0xF355  # Mitigate threat
THREAT_BLOCK   = 0xF356  # Block threat
THREAT_QUARANTINE = 0xF357  # Quarantine
THREAT_ERADICATE  = 0xF358  # Eradicate
THREAT_INTEL   = 0xF35A  # Threat intel
THREAT_IOC     = 0xF35B  # IOC match
THREAT_ANOMALY = 0xF35D  # Anomaly detected
SECRET_STORE   = 0xF360  # Store secret
SECRET_RETRIEVE= 0xF361  # Retrieve secret
SECRET_UPDATE  = 0xF362  # Update secret
SECRET_DELETE  = 0xF363  # Delete secret
SECRET_ROTATE  = 0xF364  # Rotate secret
SECRET_REVOKE  = 0xF368  # Revoke access
SECRET_LEASE   = 0xF36A  # Lease secret
COMPLY_CHECK   = 0xF370  # Compliance check
COMPLY_PASS    = 0xF371  # Compliant
COMPLY_FAIL    = 0xF372  # Non-compliant
COMPLY_EVIDENCE= 0xF376  # Evidence collected
COMPLY_REPORT  = 0xF377  # Compliance report
COMPLY_GDPR    = 0xF37C  # GDPR specific
COMPLY_SOC2    = 0xF37D  # SOC2 specific
COMPLY_HIPAA   = 0xF37E  # HIPAA specific
COMPLY_PCI     = 0xF37F  # PCI-DSS specific
HSM_CONNECT    = 0xF380  # Connect HSM
HSM_AUTH       = 0xF382  # Authenticate HSM
HSM_SIGN       = 0xF383  # HSM sign
HSM_VERIFY     = 0xF384  # HSM verify
HSM_ENCRYPT    = 0xF385  # HSM encrypt
HSM_DECRYPT    = 0xF386  # HSM decrypt
HSM_KEYGEN     = 0xF387  # HSM key gen
HSM_ATTEST     = 0xF38A  # HSM attestation
HSM_ZEROIZE    = 0xF38C  # Zeroize HSM
HSM_TAMPER     = 0xF38F  # Tamper detected

# ---------------------------------------------------------------------------
# STORAGE (0xF4xx)
# ---------------------------------------------------------------------------
STORE_BASE     = 0xF400  # Base storage operation
STORE_READ     = 0xF401  # Read from storage
STORE_WRITE    = 0xF402  # Write to storage
STORE_DELETE   = 0xF403  # Delete object/file
STORE_EXISTS   = 0xF404  # Check existence
STORE_STAT     = 0xF405  # Get metadata/stats
STORE_LIST     = 0xF406  # List contents
STORE_COPY     = 0xF407  # Copy object
STORE_MOVE     = 0xF408  # Move/rename object
STORE_FLUSH    = 0xF409  # Flush to durable storage
STORE_SYNC     = 0xF40A  # Sync replica
STORE_LOCK     = 0xF40B  # Acquire exclusive lock
STORE_UNLOCK   = 0xF40C  # Release lock
STORE_WATCH    = 0xF40D  # Watch for changes
OBJ_PUT        = 0xF410  # Upload object
OBJ_GET        = 0xF411  # Download object
OBJ_DELETE     = 0xF412  # Delete object
OBJ_LIST       = 0xF413  # List bucket
OBJ_HEAD       = 0xF414  # Head request (metadata only)
OBJ_PRESIGN    = 0xF415  # Generate pre-signed URL
OBJ_MPART_INIT = 0xF416  # Initiate multipart upload
OBJ_MPART_UP   = 0xF417  # Upload part
OBJ_MPART_DONE = 0xF418  # Complete multipart upload
OBJ_MPART_ABORT= 0xF419  # Abort multipart upload
OBJ_COPY       = 0xF41A  # Server-side copy
OBJ_RESTORE    = 0xF41B  # Restore from cold tier
OBJ_TAG        = 0xF41C  # Set tags
OBJ_VERSION    = 0xF41E  # Get specific version
BLK_ALLOC      = 0xF420  # Allocate volume
BLK_FREE       = 0xF421  # Free volume
BLK_READ       = 0xF422  # Read block
BLK_WRITE      = 0xF423  # Write block
BLK_SNAPSHOT   = 0xF424  # Take snapshot
BLK_CLONE      = 0xF426  # Clone volume
BLK_RESIZE     = 0xF427  # Resize volume
BLK_MOUNT      = 0xF42A  # Mount volume
BLK_UNMOUNT    = 0xF42B  # Unmount volume
IDX_CREATE     = 0xF430  # Create index
IDX_DROP       = 0xF431  # Drop index
IDX_INSERT     = 0xF432  # Insert document
IDX_UPDATE     = 0xF433  # Update document
IDX_DELETE     = 0xF434  # Delete document
IDX_SEARCH     = 0xF435  # Full-text / vector search
IDX_SCAN       = 0xF436  # Full scan
IDX_REINDEX    = 0xF437  # Rebuild index
IDX_OPTIMIZE   = 0xF438  # Optimize (merge segments)
IDX_SHARD      = 0xF43B  # Shard index
IDX_REPLICATE  = 0xF43C  # Replicate to replica
CACHE_SET      = 0xF440  # Set cache entry
CACHE_GET      = 0xF441  # Get cache entry
CACHE_EXPIRE   = 0xF443  # Set TTL
CACHE_TTL      = 0xF444  # Query remaining TTL
CACHE_FLUSH    = 0xF445  # Flush all entries
CACHE_EVICT    = 0xF446  # Evict entry (manual)
CACHE_HIT      = 0xF447  # Cache hit
CACHE_MISS     = 0xF448  # Cache miss
CACHE_INVALIDATE = 0xF449  # Invalidate by tag/pattern
CACHE_PRELOAD  = 0xF44A  # Preload into cache
CACHE_WARM     = 0xF44B  # Warm-up cache
CACHE_STATS    = 0xF44C  # Cache stats
CACHE_MULTI_GET= 0xF44F  # Batch get
ARC_ARCHIVE    = 0xF450  # Move to archive tier
ARC_RETRIEVE   = 0xF451  # Retrieve from archive
ARC_VERIFY     = 0xF454  # Verify integrity
ARC_PURGE      = 0xF456  # Permanent delete
ARC_SEAL       = 0xF459  # Seal (make immutable)
LOG_APPEND     = 0xF460  # Append record
LOG_CONSUME    = 0xF461  # Consume record(s)
LOG_SEEK       = 0xF462  # Seek to offset
LOG_CHECKPOINT = 0xF464  # Commit consumer offset
LOG_PARTITION  = 0xF466  # Assign partition
LOG_SUBSCRIBE  = 0xF46B  # Subscribe to stream
LOG_PRODUCE    = 0xF46D  # Produce batch
META_SET       = 0xF470  # Set metadata key
META_GET       = 0xF471  # Get metadata key
META_LIST      = 0xF473  # List all metadata
META_TAG       = 0xF474  # Apply tag
META_SCHEMA    = 0xF47A  # Get/set schema
META_VALIDATE  = 0xF47B  # Validate against schema

# ---------------------------------------------------------------------------
# AI / ML (0xF5xx)
# ---------------------------------------------------------------------------
AI_BASE        = 0xF500  # Base AI operation
AI_INFERENCE   = 0xF501  # Run inference
AI_EMBEDDING   = 0xF502  # Generate embedding
AI_SEMANTIC    = 0xF503  # Semantic search/match
AI_CLASSIFY    = 0xF504  # Classification
AI_GENERATE    = 0xF505  # Content generation
AI_FINETUNE    = 0xF506  # Fine-tuning
AI_SIMILARITY  = 0xF507  # Similarity score
AI_REASON      = 0xF508  # Reasoning task
AI_VISION      = 0xF509  # Vision task
AI_SPEECH      = 0xF50A  # Speech task
AI_SUMMARIZE   = 0xF50B  # Summarization
AI_TRANSLATE   = 0xF50C  # Translation
AI_SENTIMENT   = 0xF50D  # Sentiment analysis
AI_EXTRACT     = 0xF50E  # Entity extraction
AI_COMPLETE    = 0xF50F  # Text completion
EMBED_TEXT     = 0xF510  # Text embedding
EMBED_IMAGE    = 0xF511  # Image embedding
EMBED_AUDIO    = 0xF512  # Audio embedding
EMBED_MULTI    = 0xF513  # Multimodal embedding
EMBED_CHUNK    = 0xF514  # Chunk embedding
EMBED_BATCH    = 0xF515  # Batch embedding
EMBED_CACHE    = 0xF516  # Cached embedding lookup
EMBED_STORE    = 0xF517  # Store embedding
EMBED_SEARCH   = 0xF518  # Search embeddings
EMBED_CLUSTER  = 0xF519  # Cluster embeddings
EMBED_REDUCE   = 0xF51A  # Dimensionality reduction
EMBED_COMPARE  = 0xF51B  # Compare embeddings
TRAIN_START    = 0xF520  # Start training
TRAIN_STEP     = 0xF521  # Training step
TRAIN_EPOCH    = 0xF522  # Epoch complete
TRAIN_STOP     = 0xF523  # Stop training
TRAIN_CHECKPOINT = 0xF524  # Save checkpoint
TRAIN_RESUME   = 0xF525  # Resume training
TRAIN_EVAL     = 0xF526  # Evaluation
TRAIN_LOSS     = 0xF527  # Loss update
TRAIN_CONVERGE = 0xF52D  # Converged
TRAIN_COMPLETE = 0xF52F  # Training complete
REASON_START   = 0xF530  # Start reasoning
REASON_STEP    = 0xF531  # Reasoning step
REASON_BRANCH  = 0xF532  # Branch logic
REASON_CONCLUDE= 0xF534  # Reach conclusion
REASON_CHAIN   = 0xF536  # Chain of thought
REASON_VERIFY  = 0xF537  # Verify reasoning
REASON_SYNTHESIZE = 0xF539  # Synthesize facts
REASON_COMPLETE= 0xF53F  # Reasoning complete
VISION_ANALYZE = 0xF540  # Analyze image
VISION_DETECT  = 0xF541  # Object detection
VISION_SEGMENT = 0xF542  # Segmentation
VISION_CLASSIFY= 0xF543  # Image classification
VISION_CAPTION = 0xF544  # Generate caption
VISION_OCR     = 0xF545  # OCR text extraction
VISION_FACE    = 0xF546  # Face detection
VISION_GENERATE= 0xF549  # Image generation
VISION_EDIT    = 0xF54A  # Image editing
LANG_PARSE     = 0xF550  # Parse text
LANG_TOKENIZE  = 0xF551  # Tokenize
LANG_NER       = 0xF553  # Named entity recognition
LANG_SENTIMENT = 0xF556  # Sentiment
LANG_QUESTION  = 0xF558  # Question answering
LANG_REWRITE   = 0xF55A  # Text rewriting
LANG_INTENT    = 0xF55E  # Intent classification
AUDIO_TRANSCRIBE = 0xF560  # Speech to text
AUDIO_SYNTHESIZE = 0xF561  # Text to speech
AUDIO_CLASSIFY   = 0xF562  # Audio classification
AUDIO_DETECT     = 0xF563  # Sound detection
AUDIO_DENOISE    = 0xF565  # Noise reduction
AUDIO_SPEAKER    = 0xF567  # Speaker recognition
AUDIO_CLONE      = 0xF56C  # Voice cloning
AUDIO_STREAM     = 0xF56D  # Streaming audio
MODEL_LOAD     = 0xF570  # Load model
MODEL_UNLOAD   = 0xF571  # Unload model
MODEL_INFO     = 0xF572  # Model info
MODEL_QUANTIZE = 0xF573  # Quantize model
MODEL_EXPORT   = 0xF576  # Export model
MODEL_IMPORT   = 0xF577  # Import model
MODEL_BENCHMARK= 0xF579  # Benchmark
MODEL_CACHE    = 0xF57A  # Cache model
MODEL_HEALTH   = 0xF57D  # Health check
MODEL_FALLBACK = 0xF57E  # Fallback

# ---------------------------------------------------------------------------
# UI (0xF6xx)
# ---------------------------------------------------------------------------
UI_BASE        = 0xF600  # Base UI operation
UI_RENDER      = 0xF601  # Render component tree
UI_UPDATE      = 0xF602  # Re-render / diff + patch
UI_MOUNT       = 0xF603  # Mount component into DOM
UI_UNMOUNT     = 0xF604  # Unmount / destroy component
UI_FOCUS       = 0xF605  # Component receives focus
UI_BLUR        = 0xF606  # Component loses focus
UI_CLICK       = 0xF607  # Click event
UI_SUBMIT      = 0xF608  # Form/action submit
UI_RESET       = 0xF609  # Reset state
UI_NAVIGATE    = 0xF60A  # Route navigation
UI_SCROLL      = 0xF60B  # Scroll event
UI_RESIZE      = 0xF60C  # Viewport/container resize
UI_THEME       = 0xF60D  # Theme switch
UI_LOCALE      = 0xF60E  # Locale / i18n change
UI_KEY_DOWN    = 0xF610  # Key pressed
UI_KEY_UP      = 0xF611  # Key released
UI_MOUSE_DOWN  = 0xF613  # Mouse button pressed
UI_MOUSE_UP    = 0xF614  # Mouse button released
UI_MOUSE_MOVE  = 0xF615  # Mouse moved
UI_HOVER       = 0xF616  # Mouse hover enter
UI_DRAG        = 0xF617  # Drag gesture
UI_DROP        = 0xF618  # Drop gesture
UI_TOUCH_START = 0xF619  # Touch start
UI_TOUCH_END   = 0xF61A  # Touch end
UI_TOUCH_MOVE  = 0xF61B  # Touch move
UI_PASTE       = 0xF61C  # Clipboard paste
UI_LAYOUT_GRID = 0xF620  # CSS grid layout
UI_LAYOUT_FLEX = 0xF621  # Flexbox layout
UI_LAYOUT_STACK= 0xF622  # Vertical/horizontal stack
UI_TABS        = 0xF624  # Tab container
UI_COLLAPSE    = 0xF625  # Collapse/accordion
UI_SIDEBAR     = 0xF627  # Sidebar panel
UI_DATA_TABLE  = 0xF630  # Data table
UI_DATA_LIST   = 0xF631  # List view
UI_DATA_CARD   = 0xF632  # Card component
UI_DATA_CHART  = 0xF633  # Chart / graph
UI_DATA_TREE   = 0xF635  # Tree view
UI_DATA_TIMELINE = 0xF636  # Timeline component
UI_DATA_KANBAN = 0xF637  # Kanban board
UI_DATA_CALENDAR = 0xF638  # Calendar view
UI_DATA_MAP    = 0xF639  # Map component
UI_DATA_FEED   = 0xF63A  # Infinite scroll feed
UI_DATA_FILTER = 0xF63C  # Filter controls
UI_DATA_SEARCH = 0xF63E  # Search bar
UI_FORM_FIELD  = 0xF640  # Form field
UI_FORM_VALIDATE = 0xF641  # Validate field/form
UI_FORM_SUBMIT = 0xF642  # Submit form
UI_FORM_ERROR  = 0xF644  # Field/form error state
UI_FORM_SUCCESS= 0xF645  # Success state
UI_FORM_UPLOAD = 0xF64D  # File upload field
UI_FORM_PROGRESS = 0xF64E  # Upload / processing progress
UI_MEDIA_IMAGE = 0xF650  # Image component
UI_MEDIA_VIDEO = 0xF651  # Video player
UI_MEDIA_AUDIO = 0xF652  # Audio player
UI_MEDIA_PLAY  = 0xF654  # Play
UI_MEDIA_PAUSE = 0xF655  # Pause
UI_MEDIA_GALLERY = 0xF65A  # Media gallery
UI_NOTIFY_ALERT  = 0xF660  # Alert (generic)
UI_NOTIFY_INFO   = 0xF661  # Info message
UI_NOTIFY_WARN   = 0xF662  # Warning
UI_NOTIFY_ERROR  = 0xF663  # Error notification
UI_NOTIFY_SUCCESS= 0xF664  # Success notification
UI_NOTIFY_BADGE  = 0xF665  # Badge count
UI_NOTIFY_TOAST  = 0xF667  # Snackbar / toast
UI_NOTIFY_DIALOG = 0xF668  # Modal dialog
UI_NOTIFY_LOADING= 0xF66A  # Loading indicator
UI_A11Y_LABEL    = 0xF670  # Set aria-label
UI_A11Y_ANNOUNCE = 0xF673  # Live region announcement
UI_A11Y_ROLE     = 0xF674  # Set ARIA role
UI_A11Y_ALT      = 0xF675  # Set alt text

# ---------------------------------------------------------------------------
# DeFi (0xF8xx)
# ---------------------------------------------------------------------------
DEFI_BASE      = 0xF800  # Base DeFi operation
DEFI_SWAP      = 0xF801  # Token swap
DEFI_DEPOSIT   = 0xF802  # Deposit
DEFI_WITHDRAW  = 0xF803  # Withdraw
DEFI_APPROVE   = 0xF804  # Token approval
DEFI_REVOKE    = 0xF805  # Revoke approval
DEFI_WRAP      = 0xF806  # Wrap token
DEFI_UNWRAP    = 0xF807  # Unwrap token
DEFI_TRANSFER  = 0xF808  # Transfer
DEFI_CLAIM     = 0xF809  # Claim rewards
DEFI_HARVEST   = 0xF80B  # Harvest yield
DEFI_ROUTE     = 0xF80D  # Route through protocols
DEFI_BATCH     = 0xF80F  # Batch operations
AMM_SWAP       = 0xF810  # AMM swap
AMM_ADD_LIQ    = 0xF811  # Add liquidity
AMM_REMOVE_LIQ = 0xF812  # Remove liquidity
AMM_QUOTE      = 0xF813  # Get quote
AMM_SLIPPAGE   = 0xF815  # Slippage tolerance
AMM_POOL_CREATE= 0xF816  # Create pool
AMM_POOL_INFO  = 0xF817  # Pool info
AMM_RESERVES   = 0xF818  # Get reserves
AMM_FEE        = 0xF819  # Pool fees
AMM_POSITION   = 0xF81B  # Position info
AMM_REBALANCE  = 0xF81D  # Rebalance position
AMM_COLLECT    = 0xF81E  # Collect fees
LEND_SUPPLY    = 0xF820  # Supply collateral
LEND_BORROW    = 0xF821  # Borrow
LEND_REPAY     = 0xF822  # Repay
LEND_WITHDRAW  = 0xF823  # Withdraw collateral
LEND_LIQUIDATE = 0xF824  # Liquidation
LEND_HEALTH    = 0xF825  # Health factor
LEND_RATE      = 0xF826  # Interest rate
LEND_APY       = 0xF827  # APY
LEND_FLASH     = 0xF82A  # Flash loan
LEND_LTV       = 0xF82D  # Loan-to-value
YIELD_STAKE    = 0xF830  # Stake
YIELD_UNSTAKE  = 0xF831  # Unstake
YIELD_CLAIM    = 0xF832  # Claim rewards
YIELD_COMPOUND = 0xF833  # Auto-compound
YIELD_APR      = 0xF834  # Current APR
YIELD_APY      = 0xF835  # Current APY
YIELD_TVL      = 0xF836  # Total value locked
YIELD_BOOST    = 0xF837  # Boost multiplier
YIELD_VEST     = 0xF838  # Vesting
YIELD_LOCK     = 0xF839  # Lock period
DERIV_LONG     = 0xF840  # Open long
DERIV_SHORT    = 0xF841  # Open short
DERIV_CLOSE    = 0xF842  # Close position
DERIV_LEVERAGE = 0xF844  # Leverage
DERIV_FUNDING  = 0xF845  # Funding rate
DERIV_PNL      = 0xF848  # Profit/Loss
DERIV_LIQUIDATION = 0xF849  # Liquidation price
DERIV_OPTION_CALL = 0xF84A  # Call option
DERIV_OPTION_PUT  = 0xF84B  # Put option
DERIV_STRIKE   = 0xF84C  # Strike price
DERIV_EXPIRY   = 0xF84D  # Expiry
DERIV_EXERCISE = 0xF84F  # Exercise
DEFI_ORACLE_PRICE = 0xF860  # Get price
DEFI_ORACLE_TWAP  = 0xF861  # TWAP
DEFI_ORACLE_FEED  = 0xF863  # Price feed
DEFI_ORACLE_STALE = 0xF867  # Stale price
DEFI_GOV_VOTE     = 0xF870  # Cast vote
DEFI_GOV_DELEGATE = 0xF871  # Delegate
DEFI_GOV_PROPOSE  = 0xF873  # Create proposal
DEFI_GOV_EXECUTE  = 0xF874  # Execute
RISK_ASSESS    = 0xF880  # Risk assessment
RISK_HEDGE     = 0xF881  # Hedge
RISK_INSURE    = 0xF882  # Insurance
RISK_EXPOSURE  = 0xF884  # Exposure
RISK_VAR       = 0xF886  # Value at Risk
RISK_ALERT     = 0xF889  # Risk alert
RISK_STOP_LOSS = 0xF88C  # Stop loss
RISK_TAKE_PROFIT = 0xF88D  # Take profit

# ---------------------------------------------------------------------------
# LEGAL (0xF9xx)
# ---------------------------------------------------------------------------
LEGAL_OPINION    = 0xF900  # Court opinion / decision
LEGAL_BRIEF      = 0xF901  # Legal brief
LEGAL_MOTION     = 0xF902  # Legal motion
LEGAL_ORDER      = 0xF903  # Court order
LEGAL_JUDGMENT   = 0xF904  # Final judgment
LEGAL_STATUTE    = 0xF905  # Legislative statute
LEGAL_REGULATION = 0xF906  # Administrative regulation
LEGAL_CONTRACT   = 0xF907  # Legal contract / agreement
LEGAL_COMPLAINT  = 0xF908  # Complaint / petition
LEGAL_ANSWER     = 0xF909  # Answer / response
LEGAL_DEPOSITION = 0xF90A  # Deposition transcript
LEGAL_INDICTMENT = 0xF90B  # Criminal indictment
LEGAL_WARRANT    = 0xF90C  # Arrest or search warrant
LEGAL_SUBPOENA   = 0xF90D  # Subpoena
LEGAL_AFFIDAVIT  = 0xF90E  # Sworn affidavit
LEGAL_EXHIBIT    = 0xF90F  # Court exhibit
COURT_SCOTUS     = 0xF910  # U.S. Supreme Court
COURT_CIRCUIT    = 0xF911  # Circuit Court of Appeals
COURT_DISTRICT   = 0xF912  # Federal District Court
COURT_BANKRUPTCY = 0xF913  # Bankruptcy Court
COURT_STATE_SUP  = 0xF914  # State Supreme Court
COURT_FEDERAL    = 0xF917  # Federal jurisdiction
COURT_ARBITRATION= 0xF91C  # Arbitration panel
COURT_INTL       = 0xF91D  # International court
PARTY_PLAINTIFF  = 0xF920  # Plaintiff
PARTY_DEFENDANT  = 0xF921  # Defendant
PARTY_APPELLANT  = 0xF922  # Appellant
PARTY_APPELLEE   = 0xF923  # Appellee
PARTY_WITNESS    = 0xF928  # Witness
PARTY_EXPERT     = 0xF929  # Expert witness
PARTY_COUNSEL    = 0xF92A  # Attorney / counsel
PARTY_JUDGE      = 0xF92B  # Judge / justice
RULING_AFFIRM    = 0xF930  # Affirmed
RULING_REVERSE   = 0xF931  # Reversed
RULING_REMAND    = 0xF932  # Remanded
RULING_DISMISS   = 0xF933  # Dismissed
RULING_GRANT     = 0xF934  # Motion granted
RULING_DENY      = 0xF935  # Motion denied
RULING_VACATE    = 0xF936  # Vacated
RULING_STAY      = 0xF937  # Stay granted
RULING_CERTIORARI= 0xF938  # Certiorari granted/denied
RULING_ENJOIN    = 0xF939  # Injunction issued
RULING_SETTLE    = 0xF93C  # Settled
RULING_ACQUIT    = 0xF93E  # Acquitted
RULING_CONVICT   = 0xF93F  # Convicted
PROC_HEARING     = 0xF940  # Hearing
PROC_TRIAL       = 0xF941  # Trial
PROC_DISCOVERY   = 0xF942  # Discovery phase
PROC_APPEAL      = 0xF946  # Appeal filed
PROC_VERDICT     = 0xF94A  # Verdict reached
PROC_SENTENCING  = 0xF94B  # Sentencing
CITE_CASE        = 0xF950  # Case citation
CITE_STATUTE     = 0xF951  # Statute citation
CITE_REG         = 0xF952  # Regulation citation
CITE_ID          = 0xF955  # Id. citation
CITE_SEE         = 0xF959  # "See" citation signal
CITE_SEE_ALSO    = 0xF95A  # "See also" signal
DOCTRINE_PRECEDENT   = 0xF960  # Stare decisis / precedent
DOCTRINE_JURISDICTION= 0xF961  # Jurisdiction
DOCTRINE_STANDING    = 0xF962  # Standing to sue
DOCTRINE_DUE_PROCESS = 0xF968  # Due process
DOCTRINE_EQUAL_PROTECT = 0xF969  # Equal protection
REMEDY_DAMAGES     = 0xF970  # Damages (general)
REMEDY_INJUNCTION  = 0xF971  # Injunction
REMEDY_RESTITUTION = 0xF972  # Restitution
REMEDY_CONTEMPT    = 0xF975  # Contempt of court
REMEDY_FINE        = 0xF977  # Fine / penalty
CONTRACT_OFFER     = 0xF980  # Offer
CONTRACT_ACCEPT    = 0xF981  # Acceptance
CONTRACT_BREACH    = 0xF983  # Breach
CONTRACT_TERM      = 0xF985  # Termination
CONTRACT_FORCE_MAJEURE = 0xF988  # Force majeure
CONTRACT_ARBITRATE = 0xF989  # Arbitration clause
CONTRACT_NCA       = 0xF98F  # Non-compete / non-solicitation
LAT_PURSUANT_TO    = 0xF990  # "pursuant to"
LAT_WHEREAS        = 0xF994  # "WHEREAS"
LAT_INTER_ALIA     = 0xF998  # "inter alia"
LAT_RES_JUDICATA   = 0xF99A  # "res judicata"
LAT_HABEAS_CORPUS  = 0xF99B  # "habeas corpus"

# ---------------------------------------------------------------------------
# GEOGRAPHIC (0xFAxx)
# ---------------------------------------------------------------------------
GEO_FIX       = 0xFA00  # GPS fix acquired
GEO_NO_FIX    = 0xFA01  # No GPS fix
GEO_COORD     = 0xFA02  # Coordinate recorded
GEO_ALT       = 0xFA03  # Altitude recorded
GEO_ACCURACY  = 0xFA04  # Accuracy estimate
GEO_HDOP      = 0xFA05  # Horizontal dilution of precision
GEO_SAT_COUNT = 0xFA07  # Satellite count
GEO_RTK       = 0xFA09  # RTK centimetre-precision fix
GEO_CELL      = 0xFA0A  # Cell-tower derived position
GEO_WIFI_POS  = 0xFA0B  # WiFi-based position
GEO_FUSED     = 0xFA0C  # Sensor-fused position (IMU + GPS)
GEO_LOST      = 0xFA0D  # Position signal lost
GEO_STALE     = 0xFA0E  # Stale position
GEO_VELOCITY  = 0xFA10  # Speed/velocity recorded
GEO_HEADING   = 0xFA11  # Direction heading (degrees)
GEO_BEARING   = 0xFA12  # Bearing to target
GEO_DISTANCE  = 0xFA13  # Cumulative distance
GEO_STOP      = 0xFA15  # Device stopped
GEO_MOVING    = 0xFA16  # Device moving
GEO_SPEEDING  = 0xFA17  # Speed limit exceeded
GEO_ACCEL     = 0xFA18  # Hard acceleration event
GEO_BRAKE     = 0xFA19  # Hard braking event
GEO_TRIP_START= 0xFA1C  # Trip started
GEO_TRIP_END  = 0xFA1D  # Trip ended
GF_DEFINE     = 0xFA20  # Define geofence
GF_ENTER      = 0xFA21  # Enter geofence
GF_EXIT       = 0xFA22  # Exit geofence
GF_DWELL      = 0xFA23  # Dwell inside geofence
GF_ALERT      = 0xFA24  # Geofence alert triggered
GF_EXPIRE     = 0xFA25  # Geofence expired
GF_UPDATE     = 0xFA26  # Geofence definition updated
GF_DELETE     = 0xFA27  # Geofence deleted
GF_BREACH     = 0xFA28  # Unauthorised breach
GF_APPROACH   = 0xFA29  # Approaching boundary
GF_QUERY      = 0xFA2B  # Query geofences at point
GF_LIST       = 0xFA2C  # List active geofences
MAP_TILE_LOAD = 0xFA30  # Map tile loaded
MAP_ROUTE_PLAN= 0xFA32  # Route planned
MAP_WAYPOINT  = 0xFA33  # Waypoint added
MAP_POI       = 0xFA34  # Point of interest
MAP_ANNOTATE  = 0xFA35  # Map annotation added
MAP_HEATMAP   = 0xFA3A  # Heatmap updated
MAP_ISOCHRONE = 0xFA3B  # Isochrone computed
NAV_START     = 0xFA40  # Navigation started
NAV_TURN_LEFT = 0xFA41  # Turn left
NAV_TURN_RIGHT= 0xFA42  # Turn right
NAV_ARRIVE    = 0xFA44  # Arrived at destination
NAV_RECALC    = 0xFA45  # Route recalculated
NAV_ETA       = 0xFA46  # ETA updated
NAV_REROUTE   = 0xFA47  # Rerouting (traffic)
NAV_TRAFFIC   = 0xFA4A  # Traffic event
LOCSVC_GEOCODE  = 0xFA50  # Forward geocode (address to coord)
LOCSVC_REVERSE  = 0xFA51  # Reverse geocode (coord to address)
LOCSVC_SEARCH   = 0xFA52  # Location search
LOCSVC_TZ       = 0xFA55  # Timezone lookup at coord
LOCSVC_ELEVATION= 0xFA56  # Elevation lookup
LOCSVC_H3_ENCODE= 0xFA5B  # H3 hexagon encode
LOCSVC_BOUNDARY = 0xFA5E  # Admin boundary lookup
REGION_COUNTRY  = 0xFA60  # Country boundary
REGION_STATE    = 0xFA61  # State/province boundary
REGION_CITY     = 0xFA62  # City boundary
REGION_POSTAL   = 0xFA63  # Postal/ZIP code zone
REGION_TIMEZONE = 0xFA64  # Timezone region
REGION_MARITIME = 0xFA69  # Maritime zone (EEZ, territorial)
REGION_AIRSPACE = 0xFA6A  # Airspace zone
REGION_RESTRICTED = 0xFA6B  # Restricted / no-fly zone
PROX_NEARBY    = 0xFA70  # Nearby assets found
PROX_CLOSEST   = 0xFA71  # Closest asset
PROX_RADIUS    = 0xFA72  # Within radius check
PROX_BEACON    = 0xFA74  # Beacon detected
PROX_SEPARATION= 0xFA79  # Separation alert (too close)
PROX_FLEET     = 0xFA7B  # Fleet event
PROX_COLLISION = 0xFA7C  # Collision risk detected
PROX_HANDOFF   = 0xFA7E  # Location handoff (cell/WiFi/GPS)

# Legacy names — backward compatibility (tests + Rust client use these)
GEO_MOVE        = 0xFA10  # DEPRECATED: use GEO_VELOCITY
GEO_FENCE_ENTER = 0xFA20  # DEPRECATED: maps to GF_DEFINE (0xFA20); use GF_ENTER=0xFA21
GEO_FENCE_EXIT  = 0xFA21  # DEPRECATED: maps to GF_ENTER (0xFA21);  use GF_EXIT=0xFA22
GEO_PROXIMITY   = 0xFA70  # DEPRECATED: use PROX_NEARBY

# ---------------------------------------------------------------------------
# TEMPORAL (0xFBxx)
# ---------------------------------------------------------------------------
CLOCK_BASE      = 0xFB00  # Base temporal operation
CLOCK_NOW       = 0xFB01  # Current wall-clock time
CLOCK_MONOTONIC = 0xFB02  # Monotonic tick
CLOCK_UTC       = 0xFB03  # Current UTC time
CLOCK_LOCAL     = 0xFB04  # Current local time
CLOCK_EPOCH_TS  = 0xFB05  # Unix epoch timestamp
CLOCK_SYNC      = 0xFB06  # NTP/PTP sync request
CLOCK_DRIFT     = 0xFB07  # Clock drift measurement
CLOCK_SKEW      = 0xFB08  # Skew detected between nodes
CLOCK_CALIBRATE = 0xFB09  # Recalibrate clock source
CLOCK_TICK      = 0xFB0A  # Scheduler tick event
SCHED_CRON      = 0xFB10  # Schedule by cron expression
SCHED_AT        = 0xFB11  # Schedule at absolute time
SCHED_INTERVAL  = 0xFB12  # Schedule at fixed interval
SCHED_DELAY     = 0xFB13  # Delay execution by duration
SCHED_BACKOFF   = 0xFB14  # Exponential backoff delay
SCHED_RETRY     = 0xFB15  # Retry after failure
SCHED_CANCEL    = 0xFB16  # Cancel scheduled job
SCHED_PAUSE     = 0xFB17  # Pause scheduler
SCHED_RESUME    = 0xFB18  # Resume scheduler
SCHED_ENQUEUE   = 0xFB1A  # Add to schedule queue
SCHED_EXPIRE    = 0xFB1C  # Job TTL expired
SCHED_OVERDUE   = 0xFB1D  # Job past due time
WINDOW_OPEN     = 0xFB20  # Open time window
WINDOW_CLOSE    = 0xFB21  # Close time window
WINDOW_SLIDE    = 0xFB22  # Advance sliding window
WINDOW_TUMBLE   = 0xFB23  # Tumbling window boundary
WINDOW_SESSION  = 0xFB24  # Session window (inactivity gap)
WINDOW_AGGREGATE= 0xFB28  # Emit window aggregate
WINDOW_WATERMARK= 0xFB2A  # Advance event-time watermark
WINDOW_LATE     = 0xFB2B  # Late event arrived
WINDOW_TRIGGER  = 0xFB2D  # Manual window trigger
DUR_START       = 0xFB30  # Start timer
DUR_STOP        = 0xFB31  # Stop timer
DUR_PAUSE       = 0xFB32  # Pause timer
DUR_RESUME      = 0xFB33  # Resume paused timer
DUR_LAP         = 0xFB35  # Lap marker
DUR_RESET       = 0xFB36  # Reset timer to zero
DUR_MEASURE     = 0xFB37  # Read current elapsed time
DUR_BUDGET      = 0xFB39  # Set time budget
DUR_EXCEED      = 0xFB3A  # Budget exceeded
TZ_CONVERT      = 0xFB40  # Convert time between zones
TZ_DETECT       = 0xFB41  # Detect timezone from context
TZ_OFFSET       = 0xFB42  # Get UTC offset
TZ_DST_CHECK    = 0xFB43  # Check if DST active
TZ_DST_TRANS    = 0xFB44  # DST transition event
TZ_AMBIGUOUS    = 0xFB4A  # Ambiguous time (DST overlap)
CAL_EVENT       = 0xFB50  # Calendar event
CAL_RECURRING   = 0xFB51  # Recurring event definition
CAL_HOLIDAY     = 0xFB53  # Public holiday
CAL_BUSINESS    = 0xFB54  # Business day check/advance
CAL_QUARTER     = 0xFB56  # Fiscal/calendar quarter
CAL_BOOK        = 0xFB5A  # Book time slot
CAL_CANCEL      = 0xFB5B  # Cancel event
CAL_INVITE      = 0xFB5D  # Send invite
SLA_SET         = 0xFB60  # Set deadline
SLA_CHECK       = 0xFB61  # Check time remaining
SLA_WARN        = 0xFB62  # Warning: deadline approaching
SLA_BREACH      = 0xFB63  # SLA breached
SLA_EXTEND      = 0xFB64  # Extend deadline
SLA_OK          = 0xFB67  # SLA met
SLA_GRACE       = 0xFB69  # In grace period
EPOCH_BEGIN     = 0xFB70  # Begin new epoch
EPOCH_END       = 0xFB71  # Finalize / close epoch
EPOCH_CURRENT   = 0xFB72  # Query current epoch number
EPOCH_ADVANCE   = 0xFB73  # Increment epoch
EPOCH_SNAPSHOT  = 0xFB75  # Snapshot epoch state
EPOCH_COMMIT    = 0xFB76  # Commit epoch snapshot
EPOCH_FREEZE    = 0xFB77  # Freeze epoch
EPOCH_DIFF      = 0xFB79  # Diff between two epochs
EPOCH_MIGRATE   = 0xFB7F  # Migrate symbols to new epoch

# ---------------------------------------------------------------------------
# HARDWARE / IoT (0xFCxx)
# ---------------------------------------------------------------------------

# CPU (0xFC00–0xFC0F)
CPU_QUERY    = 0xFC00  # Query CPU info
CPU_AFFINITY = 0xFC01  # Set/get core affinity mask
CPU_THROTTLE = 0xFC02  # Throttle CPU
CPU_BOOST    = 0xFC03  # Enable turbo boost
CPU_GOVERNOR = 0xFC04  # Set power governor
CPU_FREQ     = 0xFC05  # Query/set clock frequency
CPU_TEMP     = 0xFC06  # CPU temperature reading
CPU_USAGE    = 0xFC07  # CPU utilization query
CPU_CACHE    = 0xFC08  # CPU cache info / flush
CPU_INTERRUPT= 0xFC09  # IRQ / interrupt stats
CPU_FLUSH    = 0xFC0B  # Flush CPU cache
CPU_PARK     = 0xFC0C  # Park idle core
CPU_UNPARK   = 0xFC0D  # Unpark core
CPU_TOPOLOGY = 0xFC0F  # Query NUMA / socket topology

# Memory (0xFC10–0xFC1F)
MEM_QUERY    = 0xFC10  # Query memory info
MEM_ALLOC    = 0xFC11  # Allocate memory region
MEM_FREE     = 0xFC12  # Free memory region
MEM_MAP      = 0xFC13  # Map physical memory
MEM_UNMAP    = 0xFC14  # Unmap memory region
MEM_LOCK     = 0xFC15  # Lock pages in RAM
MEM_UNLOCK   = 0xFC16  # Unlock pages
MEM_HUGEPAGE = 0xFC17  # Allocate huge page
MEM_NUMA     = 0xFC18  # NUMA node affinity
MEM_SWAP     = 0xFC19  # Swap usage
MEM_RECLAIM  = 0xFC1A  # Reclaim / drop caches
MEM_STATS    = 0xFC1E  # Memory pressure / stats
MEM_OOM      = 0xFC1F  # Out-of-memory event

# GPU (0xFC20–0xFC2F)
GPU_QUERY    = 0xFC20  # Query GPU info
GPU_ALLOC    = 0xFC21  # Allocate VRAM
GPU_FREE     = 0xFC22  # Free VRAM
GPU_TRANSFER = 0xFC23  # Host / device memory transfer
GPU_LAUNCH   = 0xFC24  # Launch GPU kernel
GPU_SYNC     = 0xFC25  # Synchronize device
GPU_TEMP     = 0xFC27  # GPU temperature reading
GPU_UTIL     = 0xFC28  # GPU utilization query
GPU_POWER    = 0xFC29  # GPU power draw
GPU_RESET    = 0xFC2A  # Reset GPU device
GPU_MEMCPY   = 0xFC2E  # Async memory copy

# Disk (0xFC30–0xFC3F)
DISK_QUERY   = 0xFC30  # Query disk info
DISK_READ    = 0xFC31  # Raw block read
DISK_WRITE   = 0xFC32  # Raw block write
DISK_TRIM    = 0xFC33  # TRIM / DISCARD free sectors
DISK_SMART   = 0xFC34  # Read SMART attributes
DISK_TEMP    = 0xFC35  # Disk temperature
DISK_HEALTH  = 0xFC36  # Overall health assessment
DISK_RAID    = 0xFC3A  # RAID array status / rebuild
DISK_LATENCY = 0xFC3C  # IO latency histogram
DISK_THROUGHPUT = 0xFC3D  # Read/write throughput stats

# NIC (0xFC40–0xFC4F)
NIC_QUERY    = 0xFC40  # Query NIC info
NIC_UP       = 0xFC41  # Bring interface up
NIC_DOWN     = 0xFC42  # Take interface down
NIC_SPEED    = 0xFC43  # Query/set link speed
NIC_OFFLOAD  = 0xFC45  # Configure hardware offload
NIC_BOND     = 0xFC47  # Bond / LAG configuration
NIC_VLAN     = 0xFC48  # VLAN tag configuration
NIC_FILTER   = 0xFC4A  # Hardware packet filter
NIC_STATS    = 0xFC4B  # NIC statistics
NIC_RESET    = 0xFC4C  # Reset NIC
NIC_MAC      = 0xFC4E  # MAC address query/set
NIC_MTU      = 0xFC4F  # MTU query/set

# Power (0xFC50–0xFC5F)
PWR_QUERY    = 0xFC50  # Query power state
PWR_STATE    = 0xFC51  # Current power state
PWR_SUSPEND  = 0xFC52  # Suspend to RAM
PWR_RESUME   = 0xFC53  # Resume from suspend
PWR_HIBERNATE= 0xFC54  # Hibernate to disk
PWR_WAKE     = 0xFC55  # Wake-on-LAN / wake event
PWR_BATTERY  = 0xFC56  # Battery level query
PWR_CHARGE   = 0xFC57  # Charging state
PWR_DISCHARGE= 0xFC58  # Discharging / on battery
PWR_THERMAL  = 0xFC59  # Thermal zone reading
PWR_THROTTLE = 0xFC5A  # Thermal throttle event
PWR_PROFILE  = 0xFC5B  # Set power profile
PWR_BUDGET   = 0xFC5C  # Set power draw budget
PWR_EMERGENCY= 0xFC5E  # Emergency power event

# Sensor (0xFC60–0xFC6F)
SENSOR_TEMP       = 0xFC60  # Temperature reading
SENSOR_VOLTAGE    = 0xFC61  # Voltage reading
SENSOR_CURRENT    = 0xFC62  # Current (amps)
SENSOR_FAN        = 0xFC63  # Fan speed
SENSOR_PRESSURE   = 0xFC64  # Pressure
SENSOR_HUMIDITY   = 0xFC65  # Humidity
SENSOR_POWER_DRAW = 0xFC66  # Power draw (watts)
SENSOR_VIBRATION  = 0xFC67  # Vibration
SENSOR_NOISE      = 0xFC68  # Noise level (dB)
SENSOR_ALTITUDE   = 0xFC69  # Altitude
SENSOR_POLL       = 0xFC6A  # Generic sensor read / poll
SENSOR_SUBSCRIBE  = 0xFC6B  # Subscribe to sensor stream
SENSOR_THRESHOLD  = 0xFC6C  # Threshold configuration
SENSOR_ALERT      = 0xFC6D  # Threshold alert triggered
SENSOR_CALIBRATE  = 0xFC6E  # Calibration event
SENSOR_HISTORY    = 0xFC6F  # Historical data query

# Firmware (0xFC70–0xFC7F)
FW_QUERY      = 0xFC70  # Query firmware version
FW_UPDATE     = 0xFC71  # Apply firmware update
FW_VERIFY     = 0xFC72  # Verify firmware integrity
FW_ROLLBACK   = 0xFC73  # Rollback to previous version
FW_LOCK       = 0xFC74  # Lock firmware (write-protect)
FW_FLASH      = 0xFC76  # Write firmware to flash
FW_BOOT       = 0xFC77  # Boot configuration
FW_RESET      = 0xFC78  # Reset to factory defaults
FW_SECURE_BOOT= 0xFC79  # Secure boot status
FW_SIGN       = 0xFC7A  # Sign firmware image
FW_ATTEST     = 0xFC7B  # Remote attestation (TPM quote)
FW_PROVISION  = 0xFC7C  # Provision new device identity

# GPIO (0xFC80–0xFC8F)
GPIO_READ         = 0xFC80  # Read digital pin
GPIO_WRITE        = 0xFC81  # Write digital pin
GPIO_HIGH         = 0xFC82  # Set pin high
GPIO_LOW          = 0xFC83  # Set pin low
GPIO_TOGGLE       = 0xFC84  # Toggle pin
GPIO_PULL_UP      = 0xFC85  # Enable pull-up
GPIO_PULL_DOWN    = 0xFC86  # Enable pull-down
GPIO_FLOATING     = 0xFC87  # Set floating
GPIO_IRQ_RISE     = 0xFC88  # Rising edge interrupt
GPIO_IRQ_FALL     = 0xFC89  # Falling edge interrupt
GPIO_IRQ_BOTH     = 0xFC8A  # Both-edge interrupt
GPIO_PWM_SET      = 0xFC8B  # Set PWM duty cycle
GPIO_PWM_FREQ     = 0xFC8C  # Set PWM frequency
GPIO_ANALOG_READ  = 0xFC8D  # Analog read (ADC)
GPIO_ANALOG_WRITE = 0xFC8E  # Analog write (DAC)

# Actuator (0xFC90–0xFC9F)
ACTUATOR_MOTOR_START    = 0xFC90  # Start motor
ACTUATOR_MOTOR_STOP     = 0xFC91  # Stop motor
ACTUATOR_MOTOR_SPEED    = 0xFC92  # Set motor speed
ACTUATOR_MOTOR_DIR      = 0xFC93  # Set motor direction
ACTUATOR_SERVO_SET      = 0xFC94  # Set servo position
ACTUATOR_SERVO_HOME     = 0xFC95  # Servo home position
ACTUATOR_RELAY_ON       = 0xFC96  # Relay on
ACTUATOR_RELAY_OFF      = 0xFC97  # Relay off
ACTUATOR_RELAY_TOGGLE   = 0xFC98  # Relay toggle
ACTUATOR_SOLENOID_OPEN  = 0xFC99  # Solenoid open
ACTUATOR_SOLENOID_CLOSE = 0xFC9A  # Solenoid close
ACTUATOR_STEPPER_STEP   = 0xFC9B  # Stepper step
ACTUATOR_STEPPER_HOME   = 0xFC9C  # Stepper home
ACTUATOR_BUZZER_ON      = 0xFC9D  # Buzzer on
ACTUATOR_LED_SET        = 0xFC9E  # LED set

# IoT Protocol (0xFCA0–0xFCAF)
PROTO_MQTT_PUB    = 0xFCA0  # MQTT publish
PROTO_MQTT_SUB    = 0xFCA1  # MQTT subscribe
PROTO_MQTT_CONN   = 0xFCA2  # MQTT connect
PROTO_MQTT_DISC   = 0xFCA3  # MQTT disconnect
PROTO_COAP_GET    = 0xFCA4  # CoAP GET
PROTO_COAP_PUT    = 0xFCA5  # CoAP PUT
PROTO_COAP_POST   = 0xFCA6  # CoAP POST
PROTO_COAP_OBS    = 0xFCA7  # CoAP observe
PROTO_ZIGBEE_JOIN = 0xFCA8  # Zigbee join
PROTO_ZIGBEE_SEND = 0xFCA9  # Zigbee send
PROTO_LORA_TX     = 0xFCAA  # LoRa transmit
PROTO_LORA_RX     = 0xFCAB  # LoRa receive
PROTO_BLE_ADV     = 0xFCAC  # BLE advertise
PROTO_BLE_CONN    = 0xFCAD  # BLE connect
PROTO_MATTER_CMD  = 0xFCAE  # Matter command

# Edge lifecycle (0xFCB0–0xFCBF)
EDGE_OTA_START    = 0xFCB0  # OTA update start
EDGE_OTA_CHUNK    = 0xFCB1  # OTA chunk transfer
EDGE_OTA_VERIFY   = 0xFCB2  # OTA verify
EDGE_OTA_APPLY    = 0xFCB3  # OTA apply
EDGE_WDT_KICK     = 0xFCB4  # Watchdog kick
EDGE_WDT_EXPIRE   = 0xFCB5  # Watchdog expired
EDGE_SLEEP        = 0xFCB6  # Enter sleep
EDGE_WAKE         = 0xFCB7  # Wake from sleep
EDGE_DEEP_SLEEP   = 0xFCB8  # Enter deep sleep
EDGE_PROVISION    = 0xFCB9  # Provision device
EDGE_DEPROVISION  = 0xFCBA  # Deprovision device
EDGE_TWIN_SYNC    = 0xFCBB  # Digital twin sync
EDGE_TWIN_DELTA   = 0xFCBC  # Digital twin delta
EDGE_INFER        = 0xFCBD  # Edge inference
EDGE_RESET        = 0xFCBE  # Hardware reset

# ---------------------------------------------------------------------------
# NETWORK (0xFDxx)
# ---------------------------------------------------------------------------
NET_BASE      = 0xFD00  # Base network operation
NET_CONNECT   = 0xFD01  # Open connection
NET_DISCONNECT= 0xFD02  # Close connection
NET_SEND      = 0xFD03  # Send data
NET_RECV      = 0xFD04  # Receive data
NET_PING      = 0xFD05  # Ping
NET_PONG      = 0xFD06  # Pong
NET_LISTEN    = 0xFD07  # Start listening
NET_ACCEPT    = 0xFD08  # Accept inbound connection
NET_CLOSE     = 0xFD09  # Close socket
NET_RESET     = 0xFD0A  # Reset connection (RST)
NET_STATUS    = 0xFD0B  # Connection status
NET_STATS     = 0xFD0C  # Network stats
NET_TIMEOUT   = 0xFD0E  # Connection timeout
HTTP_GET      = 0xFD10  # HTTP GET
HTTP_POST     = 0xFD11  # HTTP POST
HTTP_PUT      = 0xFD12  # HTTP PUT
HTTP_DELETE   = 0xFD13  # HTTP DELETE
HTTP_PATCH    = 0xFD14  # HTTP PATCH
HTTP_HEAD     = 0xFD15  # HTTP HEAD
HTTP_OPTIONS  = 0xFD16  # HTTP OPTIONS
HTTP_REDIRECT = 0xFD17  # 3xx redirect
HTTP_AUTH     = 0xFD18  # Authenticate
HTTP_UPLOAD   = 0xFD19  # File upload
HTTP_DOWNLOAD = 0xFD1A  # File download
HTTP_STREAM   = 0xFD1B  # Streaming response
HTTP_WEBSOCKET= 0xFD1C  # WebSocket upgrade
HTTP_SSE      = 0xFD1D  # Server-Sent Events
GRPC_CALL     = 0xFD20  # Unary RPC call
GRPC_SRV_STREAM = 0xFD21  # Server streaming
GRPC_CLI_STREAM = 0xFD22  # Client streaming
GRPC_BIDI     = 0xFD23  # Bidirectional streaming
GRPC_CANCEL   = 0xFD26  # Cancel call
GRPC_HEALTH   = 0xFD2A  # gRPC health check
DNS_RESOLVE   = 0xFD30  # Resolve hostname
DNS_LOOKUP    = 0xFD31  # Forward lookup
DNS_REVERSE   = 0xFD32  # Reverse lookup
DNS_CACHE     = 0xFD33  # Cache DNS result
DNS_SRV       = 0xFD36  # SRV record lookup
DNS_MX        = 0xFD37  # MX record lookup
DNS_TXT       = 0xFD38  # TXT record lookup
DNS_FLUSH     = 0xFD3D  # Flush DNS cache
DNS_DNSSEC    = 0xFD3F  # DNSSEC validation
TLS_HANDSHAKE = 0xFD40  # TLS handshake
TLS_CERT_VERIFY = 0xFD41  # Verify certificate chain
TLS_SESSION   = 0xFD42  # New TLS session
TLS_RENEW     = 0xFD44  # Renew certificate
TLS_REVOKE    = 0xFD45  # Revoke certificate
TLS_MUTUAL    = 0xFD47  # Mutual TLS (mTLS)
TLS_ALERT     = 0xFD4E  # TLS alert
LB_ROUTE      = 0xFD50  # Route request to backend
LB_HEALTH     = 0xFD51  # Health probe
LB_ADD_BACKEND= 0xFD52  # Register backend
LB_REM_BACKEND= 0xFD53  # Deregister backend
LB_FAILOVER   = 0xFD59  # Failover to standby
LB_DRAIN      = 0xFD5A  # Drain backend (graceful)
LB_CIRCUIT_BRK= 0xFD5B  # Circuit breaker open
LB_RATE_LIMIT = 0xFD5C  # Rate limiting
LB_CANARY     = 0xFD5E  # Canary traffic split
PROXY_FORWARD = 0xFD60  # Forward proxy
PROXY_REVERSE = 0xFD61  # Reverse proxy
PROXY_TUNNEL  = 0xFD62  # TCP tunnel
PROXY_INTERCEPT = 0xFD63  # Intercept request
PROXY_CACHE   = 0xFD64  # Proxy cache hit/store
PROXY_AUTH    = 0xFD66  # Proxy authentication
P2P_DISCOVER  = 0xFD70  # Peer discovery
P2P_ANNOUNCE  = 0xFD71  # Announce presence
P2P_HANDSHAKE = 0xFD72  # P2P handshake
P2P_GOSSIP    = 0xFD73  # Gossip protocol spread
P2P_DHT_GET   = 0xFD75  # DHT get value
P2P_DHT_PUT   = 0xFD76  # DHT put value
P2P_RELAY     = 0xFD78  # Relay through peer
P2P_MESH      = 0xFD7B  # Mesh network join/update
P2P_BOOTSTRAP = 0xFD7D  # Bootstrap from seed nodes
P2P_SYNC      = 0xFD7E  # State sync with peer

# ---------------------------------------------------------------------------
# EXT_THETA (0xFExx) — Extended economics / routing
# ---------------------------------------------------------------------------
EXT_THETA_DECISION  = 0xFE00  # Routing decision accepted
EXT_THETA_REJECT    = 0xFE01  # Rejected / escalated
EXT_THETA_OVERRIDE  = 0xFE02  # Manual override
EXT_THETA_SHADOW    = 0xFE03  # Shadow prediction (logged only)
EXT_THETA_FEEDBACK  = 0xFE04  # Post-execution feedback
EXT_THETA_CACHE_HIT = 0xFE06  # Cached routing result
EXT_THETA_CACHE_MISS= 0xFE07  # Cache miss — full inference
EXT_THETA_ESCALATE  = 0xFE08  # Escalate to primary LLM
EXT_THETA_BATCH     = 0xFE0D  # Batch routing result
EXT_THETA_STATS     = 0xFE0F  # Router stats snapshot
THETA_PRICE_QUERY   = 0xFE10  # Query current price
THETA_PRICE_SET     = 0xFE11  # Set price (governance/admin)
THETA_MARKET_BID    = 0xFE12  # Bid for compute capacity
THETA_MARKET_ASK    = 0xFE13  # Offer compute capacity
THETA_MARKET_MATCH  = 0xFE14  # Bid/ask matched
THETA_MARKET_CLEAR  = 0xFE15  # Market clearing event
THETA_FEE_COMPUTE   = 0xFE16  # Compute fee applied
THETA_FEE_NETWORK   = 0xFE17  # Network fee applied
THETA_FEE_STORAGE   = 0xFE18  # Storage fee applied
THETA_REBATE        = 0xFE19  # Fee rebate issued
THETA_PENALTY       = 0xFE1B  # Economic penalty
THETA_BONUS         = 0xFE1C  # Performance bonus
THETA_SETTLEMENT    = 0xFE1F  # Period settlement
THETA_LOCK_STAKE    = 0xFE20  # Lock in stake
THETA_UNLOCK_STAKE  = 0xFE21  # Unlock staked
THETA_SLASH_STAKE   = 0xFE22  # Slash stake
THETA_REWARD_STAKE  = 0xFE23  # Staking reward earned
THETA_DELEGATE      = 0xFE24  # Delegate stake
THETA_UNDELEGATE    = 0xFE25  # Undelegate stake
THETA_COMPOUND      = 0xFE26  # Auto-compound rewards
THETA_STAKE_QUERY   = 0xFE27  # Query stake state
THETA_EPOCH_END     = 0xFE29  # End of staking epoch
THETA_FLOW_INIT     = 0xFE30  # Initialise cross-agent flow
THETA_FLOW_PUSH     = 0xFE31  # Push to child agent
THETA_FLOW_PULL     = 0xFE32  # Pull from parent
THETA_FLOW_RETURN   = 0xFE33  # Return unused
THETA_FLOW_LOAN     = 0xFE34  # Short-term loan between agents
THETA_FLOW_REPAY    = 0xFE35  # Repay loan
THETA_FLOW_BATCH    = 0xFE36  # Batch flow
THETA_FLOW_SETTLE   = 0xFE37  # Multi-party settle
THETA_FLOW_SWEEP    = 0xFE39  # Sweep all child back to parent
THETA_FLOW_ROUTE    = 0xFE3C  # Route flow through hub
THETA_FLOW_SPLIT    = 0xFE3D  # Split flow to multiple recipients
THETA_FLOW_AUDIT    = 0xFE3F  # Audit full flow ledger
THETA_ANALYTICS_SAMPLE  = 0xFE40  # Point-in-time sample
THETA_ANALYTICS_AGG     = 0xFE41  # Aggregated metrics
THETA_ANALYTICS_RATE    = 0xFE43  # Current consumption rate
THETA_ANALYTICS_TREND   = 0xFE44  # Trend detected
THETA_ANALYTICS_ANOMALY = 0xFE45  # Anomaly detected
THETA_ANALYTICS_FORECAST= 0xFE46  # Forecast future consumption
THETA_ANALYTICS_REPORT  = 0xFE4F  # Periodic analytics report
THETA_POLICY_SET        = 0xFE50  # Set budget policy
THETA_POLICY_GET        = 0xFE51  # Get current policy
THETA_POLICY_DEFAULT    = 0xFE52  # Reset to default policy
THETA_POLICY_THROTTLE   = 0xFE55  # Throttle on low budget
THETA_POLICY_HARD_CAP   = 0xFE57  # Hard cap
THETA_POLICY_SOFT_CAP   = 0xFE58  # Soft cap
THETA_POLICY_PRIORITY   = 0xFE5A  # Priority queue policy
THETA_POLICY_QUOTA_RESET= 0xFE5C  # Reset quota for new period
THETA_ESCROW_CREATE     = 0xFE60  # Create escrow
THETA_ESCROW_FUND       = 0xFE61  # Add to escrow
THETA_ESCROW_RELEASE    = 0xFE62  # Release to recipient
THETA_ESCROW_REFUND     = 0xFE63  # Refund to sender
THETA_ESCROW_DISPUTE    = 0xFE64  # Dispute escrow
THETA_ESCROW_RESOLVE    = 0xFE65  # Resolve dispute
THETA_ESCROW_PARTIAL    = 0xFE66  # Partial release (milestone)
THETA_ESCROW_EXPIRE     = 0xFE67  # Escrow expired
THETA_ESCROW_QUERY      = 0xFE68  # Query escrow state
THETA_ESCROW_FINALIZE   = 0xFE6F  # Final settlement
THETA_RESERVE_DEPOSIT   = 0xFE70  # Deposit to system reserve
THETA_RESERVE_WITHDRAW  = 0xFE71  # Withdraw from reserve
THETA_RESERVE_STATUS    = 0xFE72  # Reserve status query
THETA_RESERVE_INSURE    = 0xFE75  # Insurance fund event
THETA_RESERVE_CLAIM     = 0xFE76  # Insurance claim
THETA_RESERVE_BOND      = 0xFE77  # Bond deposit
THETA_RESERVE_FORFEIT   = 0xFE78  # Bond forfeiture
THETA_RESERVE_YIELD     = 0xFE79  # Reserve yield distributed
THETA_RESERVE_AUDIT     = 0xFE7C  # Audit reserve balances
THETA_RESERVE_REPORT    = 0xFE7F  # Reserve status report

# ===========================================================================
# Default / fallback
# ===========================================================================
GENERIC_POLL = SENSOR_POLL  # fallback when topic is unclassified

# ===========================================================================
# Topic keyword → symbol (used by MQTTTopicClassifier)
# ===========================================================================
TOPIC_KEYWORD_MAP = {
    # Hardware / IoT
    "temp":        SENSOR_TEMP,
    "temperature": SENSOR_TEMP,
    "humidity":    SENSOR_HUMIDITY,
    "pressure":    SENSOR_PRESSURE,
    "voltage":     SENSOR_VOLTAGE,
    "current":     SENSOR_CURRENT,
    "power":       SENSOR_POWER_DRAW,
    "vibration":   SENSOR_VIBRATION,
    "noise":       SENSOR_NOISE,
    "altitude":    SENSOR_ALTITUDE,
    "sensor":      SENSOR_POLL,
    "threshold":   SENSOR_THRESHOLD,
    "alert":       SENSOR_ALERT,
    "motor":       ACTUATOR_MOTOR_START,
    "servo":       ACTUATOR_SERVO_SET,
    "relay":       ACTUATOR_RELAY_ON,
    "solenoid":    ACTUATOR_SOLENOID_OPEN,
    "stepper":     ACTUATOR_STEPPER_STEP,
    "led":         ACTUATOR_LED_SET,
    "buzzer":      ACTUATOR_BUZZER_ON,
    "actuator":    ACTUATOR_MOTOR_START,
    "gpio":        GPIO_READ,
    "pin":         GPIO_READ,
    "pwm":         GPIO_PWM_SET,
    "analog":      GPIO_ANALOG_READ,
    "adc":         GPIO_ANALOG_READ,
    "dac":         GPIO_ANALOG_WRITE,
    "ota":         EDGE_OTA_START,
    "update":      EDGE_OTA_START,
    "watchdog":    EDGE_WDT_KICK,
    "wdt":         EDGE_WDT_KICK,
    "sleep":       EDGE_SLEEP,
    "wake":        EDGE_WAKE,
    "twin":        EDGE_TWIN_SYNC,
    "shadow":      EDGE_TWIN_SYNC,
    "provision":   EDGE_PROVISION,
    "reset":       EDGE_RESET,
    "inference":   EDGE_INFER,
    "metrics":     METRICS_GAUGE_SET,
    "telemetry":   METRICS_GAUGE_SET,
    "counter":     METRICS_COUNTER_INC,
    "event":       METRICS_EVENT_EMIT_V2,
    "log":         METRICS_EVENT_EMIT_V2,
    "status":      METRICS_GAUGE_CURRENT,
    "cmd":         PROTO_MQTT_PUB,
    "command":     PROTO_MQTT_PUB,
    # Geographic
    "gps":         GEO_FIX,
    "location":    GEO_COORD,
    "geo":         GEO_FIX,
    "geofence":    GF_DEFINE,
    "nav":         NAV_START,
    "navigation":  NAV_START,
    "proximity":   PROX_NEARBY,
    "fleet":       PROX_FLEET,
    # AI/ML
    "ai":          AI_INFERENCE,
    "ml":          AI_INFERENCE,
    "embed":       AI_EMBEDDING,
    "embedding":   AI_EMBEDDING,
    "classify":    AI_CLASSIFY,
    "generate":    AI_GENERATE,
    "vision":      AI_VISION,
    "speech":      AI_SPEECH,
    "transcribe":  AUDIO_TRANSCRIBE,
    "sentiment":   AI_SENTIMENT,
    # Security
    "security":    SEC_CHECK,
    "threat":      THREAT_DETECT,
    "audit":       AUDIT_LOG,
    "compliance":  COMPLY_CHECK,
    "secret":      SECRET_STORE,
    "key":         KEY_GENERATE,
    "encrypt":     CRYPTO_ENCRYPT,
    "decrypt":     CRYPTO_DECRYPT,
    "sign":        CRYPTO_SIGN,
    # Storage
    "store":       STORE_WRITE,
    "cache":       CACHE_SET,
    "index":       IDX_SEARCH,
    "search":      IDX_SEARCH,
    "archive":     ARC_ARCHIVE,
    # Protocols
    "http":        HTTP_GET,
    "grpc":        GRPC_CALL,
    "websocket":   HTTP_WEBSOCKET,
    "sse":         HTTP_SSE,
    "kafka":       API_KAFKA,
    "mqtt":        PROTO_MQTT_PUB,
    "amqp":        API_AMQP,
    "nats":        API_NATS,
    # Blockchain / DeFi
    "blockchain":  CHAIN_ETHEREUM,
    "ethereum":    CHAIN_ETHEREUM,
    "bitcoin":     CHAIN_BITCOIN,
    "solana":      CHAIN_SOLANA,
    "swap":        DEFI_SWAP,
    "defi":        DEFI_BASE,
    "stake":       YIELD_STAKE,
    "lend":        LEND_BORROW,
    # Temporal
    "schedule":    SCHED_CRON,
    "cron":        SCHED_CRON,
    "timer":       DUR_START,
    "deadline":    SLA_SET,
    "sla":         SLA_CHECK,
    # Network
    "dns":         DNS_RESOLVE,
    "tls":         TLS_HANDSHAKE,
    "proxy":       PROXY_FORWARD,
    "p2p":         P2P_DISCOVER,
    # Agent / system
    "work":        WORK_SUBMIT,
    "task":        WORK_SUBMIT,
    "swarm":       SWARM_COORDINATE,
    "consensus":   SWARM_CONSENSUS,
    "governance":  GOV_PROPOSE,
    "vote":        GOV_VOTE,
    "identity":    IDENT_REGISTER,
    "auth":        AUTH_CHECK,
}

PAYLOAD_KEY_MAP = {
    "temperature": SENSOR_TEMP,
    "temp":        SENSOR_TEMP,
    "humidity":    SENSOR_HUMIDITY,
    "pressure":    SENSOR_PRESSURE,
    "voltage":     SENSOR_VOLTAGE,
    "current":     SENSOR_CURRENT,
    "rpm":         ACTUATOR_MOTOR_START,
    "speed":       ACTUATOR_MOTOR_START,
    "angle":       ACTUATOR_SERVO_SET,
    "state":       METRICS_GAUGE_CURRENT,
    "value":       METRICS_GAUGE_SET,
    "count":       METRICS_COUNTER_INC,
    "level":       METRICS_GAUGE_SET,
    "lat":         GEO_COORD,
    "lon":         GEO_COORD,
    "latitude":    GEO_COORD,
    "longitude":   GEO_COORD,
    "heading":     GEO_HEADING,
    "velocity":    GEO_VELOCITY,
    "score":       THREAT_SCORE,
    "embedding":   AI_EMBEDDING,
    "inference":   AI_INFERENCE,
    "probability": AI_CLASSIFY,
}
