"""
Wire.Band Edge — Frame Cryptography
=====================================

Three independent, stackable encryption layers. All optional, all zero-config
by default — frames pass through unchanged when no crypto is configured.

Layer 1 — EnvelopeCipher
    AES-256-GCM or ChaCha20-Poly1305 authenticated payload encryption.
    The 2-byte symbol prefix is bound as AEAD Additional Authenticated Data,
    tying each ciphertext to its message type. A ciphertext cannot be replayed
    under a different symbol without authentication failure.

Layer 2 — SymbolRemapper
    Keyed bijective permutation of the full 16-bit symbol space (65,536 values).
    Derived from a 32-byte secret via SHA-256 counter-mode PRNG + Fisher-Yates
    shuffle. Both parties independently derive the same table from the shared
    secret — no table exchange needed. Hides message semantics without the
    overhead of payload encryption.

Layer 3 — ContextualKeyDeriver
    Handshake-less per-frame HKDF-SHA256 key derivation:

        frame_key = HKDF-SHA256(
            IKM  = master_key,
            salt = SHA-256(symbol_bytes ‖ window_counter),
            info = b"wireband_frame_key_v1",
        )

    Both edge and server independently compute the same key. Keys rotate every
    window_seconds (default 3600). After a window expires, past frames cannot be
    decrypted even with the master key — time-windowed forward secrecy with no
    handshake or state exchange.

Stacking order (enforced by CryptoContext):
    Encrypt: encrypt payload (AAD = canonical symbol) → remap symbol
    Decrypt: unmap symbol → decrypt payload (AAD = canonical symbol)

Requirements:
    pip install wire-band-edge[crypto]   # adds the 'cryptography' package
"""
from __future__ import annotations

import hashlib
import hmac as _hmac
import os
import struct
import time as _time
from dataclasses import dataclass
from typing import Optional

try:
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM, ChaCha20Poly1305
    from cryptography.exceptions import InvalidTag
    _CRYPTO_AVAILABLE = True
except ImportError:
    _CRYPTO_AVAILABLE = False
    InvalidTag = Exception  # type: ignore[assignment, misc]


# ---------------------------------------------------------------------------
# Internal constants — not part of the public API contract
# ---------------------------------------------------------------------------

_ENVELOPE_MARKER    = bytes([0xFF, 0x20])
_ALGO_AES256GCM     = 0x01
_ALGO_CHACHA20      = 0x02
_NONCE_LEN          = 12
_TAG_LEN            = 16
_MIN_ENCRYPTED_LEN  = 2 + 1 + _NONCE_LEN + _TAG_LEN  # marker + algo + nonce + min tag

ALGO_AES256GCM         = _ALGO_AES256GCM
ALGO_CHACHA20_POLY1305 = _ALGO_CHACHA20


# ---------------------------------------------------------------------------
# Layer 1 — EnvelopeCipher
# ---------------------------------------------------------------------------

class EnvelopeCipher:
    """
    AES-256-GCM or ChaCha20-Poly1305 authenticated payload encryption.

    Parameters
    ----------
    key  : exactly 32 bytes (256-bit symmetric key)
    algo : ALGO_AES256GCM (default) or ALGO_CHACHA20_POLY1305
    """

    def __init__(self, key: bytes, algo: int = ALGO_AES256GCM) -> None:
        if not _CRYPTO_AVAILABLE:
            raise RuntimeError(
                "EnvelopeCipher requires the 'cryptography' package: "
                "pip install wire-band-edge[crypto]"
            )
        if len(key) != 32:
            raise ValueError("Key must be exactly 32 bytes")
        if algo not in (_ALGO_AES256GCM, _ALGO_CHACHA20):
            raise ValueError(f"Unknown algo: 0x{algo:02X}")
        self._algo        = algo
        self._aead        = AESGCM(key) if algo == _ALGO_AES256GCM else ChaCha20Poly1305(key)
        self._fingerprint = hashlib.sha256(key).hexdigest()[:8]

    @property
    def algo(self) -> int:
        return self._algo

    @property
    def algo_name(self) -> str:
        return "aes256gcm" if self._algo == _ALGO_AES256GCM else "chacha20poly1305"

    @property
    def fingerprint(self) -> str:
        """First 8 hex chars of SHA-256(key) — safe to log for key identification."""
        return self._fingerprint

    def encrypt(self, payload: bytes, aad: bytes = b"") -> bytes:
        """Encrypt payload; returns the full encrypted region including header."""
        nonce      = os.urandom(_NONCE_LEN)
        ct_and_tag = self._aead.encrypt(nonce, payload, aad or None)
        return _ENVELOPE_MARKER + bytes([self._algo]) + nonce + ct_and_tag

    def decrypt(self, data: bytes, aad: bytes = b"") -> bytes:
        """
        Decrypt an encrypted region.

        Raises
        ------
        ValueError  : malformed header
        InvalidTag  : authentication failure (wrong key or tampered bytes)
        """
        if len(data) < _MIN_ENCRYPTED_LEN:
            raise ValueError(f"Encrypted region too short: {len(data)}")
        if data[:2] != _ENVELOPE_MARKER:
            raise ValueError("Missing envelope marker")
        algo = data[2]
        if algo != self._algo:
            raise ValueError(f"Algo mismatch: expected 0x{self._algo:02X}, got 0x{algo:02X}")
        nonce      = data[3 : 3 + _NONCE_LEN]
        ct_and_tag = data[3 + _NONCE_LEN:]
        return self._aead.decrypt(nonce, ct_and_tag, aad or None)

    @classmethod
    def from_hex(cls, hex_key: str, algo: int = ALGO_AES256GCM) -> "EnvelopeCipher":
        """Construct from a 64-character hex string (32 bytes)."""
        return cls(bytes.fromhex(hex_key), algo)


# ---------------------------------------------------------------------------
# Layer 2 — SymbolRemapper
# ---------------------------------------------------------------------------

class SymbolRemapper:
    """
    Keyed bijective permutation of the 16-bit symbol space (65,536 values).

    Derived from a 32-byte secret via SHA-256 counter-mode PRNG + Fisher-Yates
    shuffle. Both parties sharing the same secret independently derive the same
    permutation — no table exchange required.

    Construction is O(n) in the symbol space (~65 k SHA-256 iterations, < 10 ms).
    Tables are built once at construction time.

    Parameters
    ----------
    secret : exactly 32 bytes
    """

    def __init__(self, secret: bytes) -> None:
        if len(secret) != 32:
            raise ValueError("SymbolRemapper secret must be exactly 32 bytes")
        self._fwd, self._inv = self._derive_tables(secret)
        self._fingerprint    = hashlib.sha256(secret).hexdigest()[:8]

    @staticmethod
    def _derive_tables(secret: bytes) -> tuple[list[int], list[int]]:
        # SHA-256 counter-mode PRNG → 4 bytes per Fisher-Yates swap position
        needed = 65536 * 4
        prng   = bytearray()
        counter = 0
        while len(prng) < needed:
            prng.extend(hashlib.sha256(secret + struct.pack(">I", counter)).digest())
            counter += 1

        table = list(range(65536))
        for i in range(65535, 0, -1):
            r = struct.unpack_from(">I", prng, (65535 - i) * 4)[0]
            j = r % (i + 1)
            table[i], table[j] = table[j], table[i]

        inv: list[int] = [0] * 65536
        for i, v in enumerate(table):
            inv[v] = i

        return table, inv

    def remap(self, symbol: int) -> int:
        """Map a symbol to its permuted equivalent."""
        return self._fwd[symbol & 0xFFFF]

    def unmap(self, symbol: int) -> int:
        """Recover the original symbol from its permuted equivalent."""
        return self._inv[symbol & 0xFFFF]

    @property
    def fingerprint(self) -> str:
        """First 8 hex chars of SHA-256(secret) — safe to log for key identification."""
        return self._fingerprint

    @classmethod
    def from_hex(cls, hex_key: str) -> "SymbolRemapper":
        """Construct from a 64-character hex string (32 bytes)."""
        return cls(bytes.fromhex(hex_key))


# ---------------------------------------------------------------------------
# Layer 3 — ContextualKeyDeriver
# ---------------------------------------------------------------------------

def _hkdf_sha256(ikm: bytes, salt: bytes, info: bytes, length: int = 32) -> bytes:
    """RFC 5869 HKDF-SHA256, single-block expand (length ≤ 32)."""
    prk = _hmac.new(salt, ikm, hashlib.sha256).digest()
    okm = _hmac.new(prk, info + b"\x01", hashlib.sha256).digest()
    return okm[:length]


class ContextualKeyDeriver:
    """
    Handshake-less per-frame HKDF-SHA256 key derivation with time-windowed
    forward secrecy.

    Both edge and server derive the same frame key from the shared master key
    and the current time window — no key exchange, no transmitted state. Keys
    rotate every window_seconds. After a window expires, past frames cannot be
    decrypted even with the master key — time-windowed forward secrecy.

    Parameters
    ----------
    master_key     : 32 bytes
    window_seconds : rotation period in seconds (default 3600)
    """

    _INFO = b"wireband_frame_key_v1"

    def __init__(self, master_key: bytes, window_seconds: int = 3600) -> None:
        if len(master_key) != 32:
            raise ValueError("master_key must be exactly 32 bytes")
        if window_seconds < 1:
            raise ValueError("window_seconds must be >= 1")
        self._master_key     = master_key
        self._window_seconds = window_seconds

    @property
    def window_seconds(self) -> int:
        return self._window_seconds

    def derive_key(self, sym_hi: int, sym_lo: int, at_time: Optional[float] = None) -> bytes:
        """Derive a 32-byte frame key for the given symbol and current time window."""
        t      = at_time if at_time is not None else _time.time()
        window = int(t) // self._window_seconds
        salt   = hashlib.sha256(
            bytes([sym_hi, sym_lo]) + struct.pack(">Q", window)
        ).digest()
        return _hkdf_sha256(self._master_key, salt, self._INFO, 32)

    @classmethod
    def from_hex(cls, hex_key: str, window_seconds: int = 3600) -> "ContextualKeyDeriver":
        """Construct from a 64-character hex string (32 bytes)."""
        return cls(bytes.fromhex(hex_key), window_seconds)


# ---------------------------------------------------------------------------
# CryptoContext — combines all three layers
# ---------------------------------------------------------------------------

@dataclass
class CryptoContext:
    """
    Combined crypto context for a Wire.Band edge deployment.

    All three layers are optional. Unset layers are no-ops — frames pass
    through encrypt_frame / decrypt_frame unchanged.

    Encrypt order: encrypt payload (AAD = canonical symbol) → remap symbol
    Decrypt order: unmap symbol → decrypt payload (AAD = canonical symbol)

    This ordering ensures the AEAD cipher and remapper always agree on the
    AAD value, regardless of which layers are active.
    """

    cipher:      Optional[EnvelopeCipher]
    remapper:    Optional[SymbolRemapper]
    key_deriver: Optional[ContextualKeyDeriver] = None

    @property
    def is_active(self) -> bool:
        return self.cipher is not None or self.remapper is not None

    def _cipher_for_symbol(
        self, sym_hi: int, sym_lo: int, at_time: Optional[float] = None
    ) -> Optional[EnvelopeCipher]:
        if self.cipher is None:
            return None
        if self.key_deriver is None:
            return self.cipher
        frame_key = self.key_deriver.derive_key(sym_hi, sym_lo, at_time=at_time)
        return EnvelopeCipher(frame_key, self.cipher.algo)

    def encrypt_frame(self, raw: bytes) -> bytes:
        """
        Encrypt a Wire.Band frame.

        Frame layout: [sym_hi: 1B][sym_lo: 1B][payload...]
        Returns a frame in the same layout with payload encrypted and/or
        symbol remapped according to the active layers.
        """
        if len(raw) < 2:
            return raw
        sym_hi, sym_lo = raw[0], raw[1]
        payload = raw[2:]

        if self.cipher is not None:
            aad    = bytes([sym_hi, sym_lo])
            cipher = self._cipher_for_symbol(sym_hi, sym_lo)
            payload = cipher.encrypt(payload, aad=aad)  # type: ignore[union-attr]

        if self.remapper is not None:
            canonical = (sym_hi << 8) | sym_lo
            ciphered  = self.remapper.remap(canonical)
            sym_hi    = (ciphered >> 8) & 0xFF
            sym_lo    = ciphered & 0xFF

        return bytes([sym_hi, sym_lo]) + payload

    def decrypt_frame(self, raw: bytes) -> bytes:
        """
        Decrypt a Wire.Band frame. Inverse of encrypt_frame.

        Raises ValueError or InvalidTag on crypto failure.
        """
        if len(raw) < 2:
            return raw
        sym_hi, sym_lo = raw[0], raw[1]
        payload = raw[2:]

        if self.remapper is not None:
            ciphered  = (sym_hi << 8) | sym_lo
            canonical = self.remapper.unmap(ciphered)
            sym_hi    = (canonical >> 8) & 0xFF
            sym_lo    = canonical & 0xFF

        if self.cipher is not None and payload[:2] == _ENVELOPE_MARKER:
            aad = bytes([sym_hi, sym_lo])
            if self.key_deriver is not None:
                now      = _time.time()
                last_exc: Exception = Exception("no windows tried")
                for at_time in (now, now - self.key_deriver.window_seconds):
                    cipher = self._cipher_for_symbol(sym_hi, sym_lo, at_time=at_time)
                    try:
                        payload = cipher.decrypt(payload, aad=aad)  # type: ignore[union-attr]
                        break
                    except Exception as exc:
                        last_exc = exc
                else:
                    raise last_exc
            else:
                payload = self.cipher.decrypt(payload, aad=aad)

        return bytes([sym_hi, sym_lo]) + payload

    def status(self) -> dict:
        """Status dict safe to expose via API (no key material)."""
        return {
            "active": self.is_active,
            "envelope_cipher": {
                "enabled":         self.cipher is not None,
                "algo":            self.cipher.algo_name if self.cipher else None,
                "key_fingerprint": self.cipher.fingerprint if self.cipher else None,
            },
            "symbol_remapper": {
                "enabled":         self.remapper is not None,
                "key_fingerprint": self.remapper.fingerprint if self.remapper else None,
            },
            "key_deriver": {
                "enabled":        self.key_deriver is not None,
                "window_seconds": self.key_deriver.window_seconds if self.key_deriver else None,
            },
        }

    @classmethod
    def from_env(cls) -> "CryptoContext":
        """
        Build a CryptoContext from environment variables.

        THETA_ENVELOPE_KEY           64-char hex (32 bytes) — enables envelope cipher
        THETA_ENVELOPE_ALGO          "aes256gcm" (default) or "chacha20poly1305"
        THETA_SYMBOL_REMAP_KEY       64-char hex (32 bytes) — enables symbol remapper
        THETA_CONTEXTUAL_SALT=1      Enable per-frame HKDF key derivation
        THETA_CONTEXTUAL_SALT_WINDOW Rotation period in seconds (default 3600)

        All are optional. Returns an inactive context if none are set.
        """
        cipher:      Optional[EnvelopeCipher]       = None
        remapper:    Optional[SymbolRemapper]        = None
        key_deriver: Optional[ContextualKeyDeriver] = None

        env_key = os.getenv("THETA_ENVELOPE_KEY")
        if env_key:
            algo_str = os.getenv("THETA_ENVELOPE_ALGO", "aes256gcm").lower()
            algo     = ALGO_CHACHA20_POLY1305 if "chacha" in algo_str else ALGO_AES256GCM
            try:
                cipher = EnvelopeCipher.from_hex(env_key, algo)
            except Exception as exc:
                raise RuntimeError(f"THETA_ENVELOPE_KEY invalid: {exc}") from exc

            if os.getenv("THETA_CONTEXTUAL_SALT", "").lower() in ("1", "true", "yes"):
                window = int(os.getenv("THETA_CONTEXTUAL_SALT_WINDOW", "3600"))
                try:
                    key_deriver = ContextualKeyDeriver.from_hex(env_key, window)
                except Exception as exc:
                    raise RuntimeError(f"ContextualKeyDeriver init failed: {exc}") from exc

        remap_key = os.getenv("THETA_SYMBOL_REMAP_KEY")
        if remap_key:
            try:
                remapper = SymbolRemapper.from_hex(remap_key)
            except Exception as exc:
                raise RuntimeError(f"THETA_SYMBOL_REMAP_KEY invalid: {exc}") from exc

        return cls(cipher=cipher, remapper=remapper, key_deriver=key_deriver)
