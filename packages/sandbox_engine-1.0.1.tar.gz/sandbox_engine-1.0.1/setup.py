import os
import sys
import platform
import subprocess
from setuptools import setup, find_packages
from setuptools.command.build_py import build_py

here = os.path.abspath(os.path.dirname(__file__))

try:
    with open(os.path.join(here, "readme.md"), encoding="utf-8") as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = "Automatic Repository Sandbox Runner"

BINARY_NAME = "sandbox-engine.exe" if platform.system() == "Windows" else "sandbox-engine"
PACKAGE_DIR = os.path.join(here, "sandbox_engine_pkg")


class BuildGoAndPy(build_py):
    def run(self):
        binary_out = os.path.join(PACKAGE_DIR, BINARY_NAME)
        print(f"[sandbox-engine] Building Go binary -> {binary_out}")
        try:
            subprocess.run(
                ["go", "build", "-o", binary_out, "."],
                cwd=here,
                check=True
            )
            print("[sandbox-engine] Go binary built successfully.")
        except FileNotFoundError:
            print("ERROR: 'go' not found. Please install Go: https://golang.org/dl/")
            sys.exit(1)
        except subprocess.CalledProcessError as e:
            print(f"ERROR: Go build failed: {e}")
            sys.exit(1)
        super().run()


setup(
    name="sandbox-engine",
    version="1.0.1",
    description="Automatic Repository Sandbox Runner — detects any repo's runtime and launches it in a sandbox",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="Vivan Rajath",
    url="https://github.com/VivanRajath/sandbox-engine",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        "sandbox_engine_pkg": ["sandbox-engine", "sandbox-engine.exe"],
    },
    entry_points={
        "console_scripts": [
            "sandbox-engine=sandbox_engine_pkg.wrapper:main",
        ],
    },
    python_requires=">=3.7",
    cmdclass={"build_py": BuildGoAndPy},
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Environment :: Console",
        "Topic :: Software Development :: Build Tools",
    ],
)
