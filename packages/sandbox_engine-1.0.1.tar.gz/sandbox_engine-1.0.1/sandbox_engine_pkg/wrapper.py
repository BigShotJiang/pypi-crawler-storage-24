import os
import sys
import subprocess

def main():
    # Find the binary in the same directory as this script
    pkg_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Determine the binary name based on the platform
    binary_name = "sandbox-engine.exe" if sys.platform == "win32" else "sandbox-engine"
    binary_path = os.path.join(pkg_dir, binary_name)
    
    if not os.path.exists(binary_path):
        print(f"Error: The compiled Go binary was not found at {binary_path}", file=sys.stderr)
        print("Please ensure the package was installed correctly and Go is available.", file=sys.stderr)
        sys.exit(1)
        
    # Execute the binary, passing all arguments provided to this script
    # sys.argv[0] is the Python script name, so we slice from [1:]
    try:
        sys.exit(subprocess.call([binary_path] + sys.argv[1:]))
    except KeyboardInterrupt:
        sys.exit(130)

if __name__ == "__main__":
    main()
