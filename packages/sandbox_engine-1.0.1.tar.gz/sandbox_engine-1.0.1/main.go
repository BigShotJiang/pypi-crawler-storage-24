// sandbox-engine — Automatic Repository Sandbox Runner
//
// A CLI that scans any repository, detects the runtime/framework, installs
// dependencies in an isolated environment, and launches the application.
//
// Build:
//
//	go build -o sandbox-engine .
//
// Usage:
//
//	sandbox-engine scan
//	sandbox-engine detect
//	sandbox-engine run
//	sandbox-engine run <project-name>
//	sandbox-engine --path /some/repo run frontend
package main

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
	"time"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/detector"
	"sandbox-engine/internal/runtime"
	"sandbox-engine/internal/scanner"
	"sandbox-engine/internal/types"
)

const usageText = `
sandbox-engine — Automatic Repository Sandbox Runner
---------------------------------------------------

Usage:
  sandbox-engine [--path <dir>] <command> [project]

Commands:
  scan              Recursively scan the repository and list all projects
  detect            Detect runtimes and frameworks for every project
  run               Install dependencies and start the first detected project
  run <project>     Install dependencies and start a named sub-project

Flags:
  --path <dir>      Repository root (default: current directory)
  --help, -h        Show this help message

Examples:
  sandbox-engine scan
  sandbox-engine detect
  sandbox-engine run
  sandbox-engine run api-service
  sandbox-engine --path /code/myrepo run frontend
`

func main() {
	args := os.Args[1:]
	if len(args) == 0 || args[0] == "--help" || args[0] == "-h" {
		fmt.Println(usageText)
		os.Exit(0)
	}

	repoPath := "."
	command := ""
	projectName := ""

	for i := 0; i < len(args); i++ {
		switch args[i] {
		case "--path":
			if i+1 >= len(args) {
				color.Error("--path requires an argument")
				os.Exit(1)
			}
			i++
			repoPath = args[i]
		default:
			if command == "" {
				command = args[i]
			} else if projectName == "" {
				projectName = args[i]
			}
		}
	}

	absRoot, err := filepath.Abs(repoPath)
	if err != nil {
		color.Error("Invalid path: %v", err)
		os.Exit(1)
	}

	// Scan
	s := scanner.New(absRoot)
	result, err := s.Scan()
	if err != nil {
		color.Error("Scan failed: %v", err)
		os.Exit(1)
	}
	if len(result.Projects) == 0 {
		color.Warn("No projects detected in: %s", absRoot)
		os.Exit(0)
	}

	// Detect
	d := detector.New()
	d.DetectAll(result)

	// Dispatch
	switch command {
	case "scan":
		cmdScan(result)

	case "detect":
		cmdDetect(result)

	case "run":
		proj := selectProject(result, projectName)
		if proj == nil {
			color.Error("Project %q not found", projectName)
			printProjectList(result)
			os.Exit(1)
		}
		if err := runtime.InstallDependencies(proj); err != nil {
			color.Warn("Dependency install encountered errors: %v", err)
		}
		if err := runtime.RunProject(proj); err != nil {
			color.Error("Run failed: %v", err)
			os.Exit(1)
		}

	default:
		color.Error("Unknown command: %q", command)
		fmt.Println(usageText)
		os.Exit(1)
	}
}

// cmdScan prints a summary of discovered project roots.
func cmdScan(result *types.ScanResult) {
	color.Header("Repository Structure")
	color.Info("Root     : %s", result.RepoRoot)
	color.Info("Duration : %v", result.Duration.Round(time.Millisecond))
	color.Info("Projects : %d", len(result.Projects))
	fmt.Println()
	for i, p := range result.Projects {
		rel, _ := filepath.Rel(result.RepoRoot, p.Root)
		fmt.Printf("  %s[%d]%s  %s%s%s\n",
			color.Bold, i+1, color.Reset,
			color.Cyan, rel, color.Reset)
		fmt.Printf("       %s\n\n",
			color.Sprintf(color.White, strings.Join(p.Files, "  ")))
	}
}

// cmdDetect prints detailed detection results for every project.
func cmdDetect(result *types.ScanResult) {
	color.Header("Detected Projects")
	for i, p := range result.Projects {
		rel, _ := filepath.Rel(result.RepoRoot, p.Root)
		fmt.Printf("\n  %s[%d] %s%s\n", color.Bold, i+1, p.Name, color.Reset)
		fmt.Printf("  |- Path       : %s\n", rel)
		fmt.Printf("  |- Language   : %s\n", color.Sprintf(color.Cyan, string(p.Language)))
		fmt.Printf("  |- Framework  : %s\n", color.Sprintf(color.Yellow, string(p.Framework)))
		fmt.Printf("  |- Entry      : %s\n", p.EntryPoint)
		fmt.Printf("  |- Port       : %d\n", p.Port)
		if p.UseDocker || p.UseDCom {
			dockerStr := ""
			if p.UseDocker {
				dockerStr += " Dockerfile"
			}
			if p.UseDCom {
				dockerStr += " docker-compose"
			}
			fmt.Printf("  `- Docker     :%s\n", dockerStr)
		}
	}
	fmt.Println()
}

// selectProject returns the project matching name, or the first project when
// name is empty. Matching is tried against project name and relative path.
func selectProject(result *types.ScanResult, name string) *types.Project {
	if name == "" && len(result.Projects) > 0 {
		return result.Projects[0]
	}
	nameLower := strings.ToLower(name)
	for _, p := range result.Projects {
		if strings.EqualFold(p.Name, name) {
			return p
		}
		rel, _ := filepath.Rel(result.RepoRoot, p.Root)
		if strings.Contains(strings.ToLower(rel), nameLower) {
			return p
		}
	}
	return nil
}

// printProjectList prints all available projects to stdout.
func printProjectList(result *types.ScanResult) {
	color.Info("Available projects:")
	for _, p := range result.Projects {
		rel, _ := filepath.Rel(result.RepoRoot, p.Root)
		fmt.Printf("    - %-20s  (%s)\n", p.Name, rel)
	}
}
