// Package scanner walks a repository tree concurrently to identify project roots.
package scanner

import (
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/types"
)

// indicatorFiles are lower-cased filenames whose presence marks a project root.
var indicatorFiles = []string{
	"package.json",
	"requirements.txt",
	"pyproject.toml",
	"pipfile",
	"go.mod",
	"cargo.toml",
	"pom.xml",
	"build.gradle",
	"dockerfile",
	"docker-compose.yml",
	"docker-compose.yaml",
	"angular.json",
	"vite.config.js",
	"vite.config.ts",
	"astro.config.mjs",
	"gatsby-config.js",
	"gatsby-config.ts",
	"manage.py",
}

// skipDirs lists directory names that are never recursed into.
var skipDirs = map[string]bool{
	"node_modules":  true,
	".git":          true,
	".svn":          true,
	"vendor":        true,
	"__pycache__":   true,
	".mypy_cache":   true,
	".pytest_cache": true,
	"target":        true,
	"build":         true,
	"dist":          true,
	".gradle":       true,
	".idea":         true,
	".vscode":       true,
}

// Scanner walks the repository using a goroutine pool and collects project roots.
type Scanner struct {
	repoRoot string
	mu       sync.Mutex
	roots    map[string]bool // deduplicated set of discovered project root paths
}

// New creates a Scanner for the given repository root.
func New(repoRoot string) *Scanner {
	return &Scanner{repoRoot: repoRoot, roots: make(map[string]bool)}
}

// Scan performs a concurrent depth-first walk and returns a ScanResult.
func (s *Scanner) Scan() (*types.ScanResult, error) {
	start := time.Now()
	color.Header("Repository Scanner")
	color.Info("Scanning: %s", s.repoRoot)

	dirCh := make(chan string, 1024)
	var wg sync.WaitGroup

	wg.Add(1)
	dirCh <- s.repoRoot

	// Fixed goroutine pool — 8 workers is sufficient for any local file-system.
	const poolSize = 8
	for i := 0; i < poolSize; i++ {
		go func() {
			for dir := range dirCh {
				s.processDir(dir, dirCh, &wg)
			}
		}()
	}

	done := make(chan struct{})
	go func() {
		wg.Wait()
		close(dirCh)
		close(done)
	}()
	<-done

	projects := s.buildProjects()
	dur := time.Since(start)
	color.Success("Scan complete in %v — found %d project(s)",
		dur.Round(time.Millisecond), len(projects))

	return &types.ScanResult{RepoRoot: s.repoRoot, Projects: projects, Duration: dur}, nil
}

// processDir inspects one directory, marks it as a project root if applicable,
// and enqueues sub-directories for further processing.
func (s *Scanner) processDir(dir string, dirCh chan<- string, wg *sync.WaitGroup) {
	defer wg.Done()

	entries, err := os.ReadDir(dir)
	if err != nil {
		return
	}

	isRoot := false
	for _, e := range entries {
		if !e.IsDir() && isIndicatorFile(strings.ToLower(e.Name())) {
			isRoot = true
			break
		}
	}
	if isRoot {
		s.mu.Lock()
		s.roots[dir] = true
		s.mu.Unlock()
	}

	for _, e := range entries {
		if !e.IsDir() || skipDirs[e.Name()] {
			continue
		}
		sub := filepath.Join(dir, e.Name())
		wg.Add(1)
		select {
		case dirCh <- sub:
		default:
			// Channel at capacity: process inline to prevent goroutine starvation.
			s.processDir(sub, dirCh, wg)
		}
	}
}

// isIndicatorFile returns true if the lower-cased filename marks a project root.
func isIndicatorFile(name string) bool {
	for _, ind := range indicatorFiles {
		if name == ind {
			return true
		}
	}
	return strings.HasSuffix(name, ".csproj")
}

// buildProjects converts collected root paths into populated Project values.
func (s *Scanner) buildProjects() []*types.Project {
	projects := make([]*types.Project, 0, len(s.roots))
	for root := range s.roots {
		p := &types.Project{Root: root, Name: filepath.Base(root)}
		if entries, err := os.ReadDir(root); err == nil {
			for _, e := range entries {
				if !e.IsDir() {
					p.Files = append(p.Files, e.Name())
				}
			}
		}
		projects = append(projects, p)
	}
	return projects
}
