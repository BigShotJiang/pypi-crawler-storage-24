// Package pkgjson provides lightweight, zero-allocation helpers for extracting
// data from package.json files without importing encoding/json.
package pkgjson

import (
	"os"
	"strings"
)

// ReadDeps returns a presence map of all dependency names declared in the
// dependencies, devDependencies, and peerDependencies sections.
func ReadDeps(path string) map[string]bool {
	result := map[string]bool{}
	data, err := os.ReadFile(path)
	if err != nil {
		return result
	}
	content := string(data)
	for _, section := range []string{`"dependencies"`, `"devDependencies"`, `"peerDependencies"`} {
		idx := strings.Index(content, section)
		if idx < 0 {
			continue
		}
		rest := content[idx:]
		start := strings.Index(rest, "{")
		end := strings.Index(rest, "}")
		if start < 0 || end < 0 || end <= start {
			continue
		}
		block := rest[start+1 : end]
		for _, line := range strings.Split(block, "\n") {
			line = strings.TrimSpace(line)
			if len(line) == 0 || line[0] != '"' {
				continue
			}
			closeQ := strings.Index(line[1:], `"`)
			if closeQ < 0 {
				continue
			}
			pkg := line[1 : closeQ+1]
			if pkg != "" {
				result[pkg] = true
			}
		}
	}
	return result
}

// ReadMain extracts the value of the "main" field from package.json.
// Returns an empty string when not found.
func ReadMain(path string) string {
	data, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	content := string(data)
	idx := strings.Index(content, `"main"`)
	if idx < 0 {
		return ""
	}
	rest := strings.TrimSpace(content[idx+6:])
	colon := strings.Index(rest, ":")
	if colon < 0 {
		return ""
	}
	rest = strings.TrimSpace(rest[colon+1:])
	if len(rest) == 0 || rest[0] != '"' {
		return ""
	}
	end := strings.Index(rest[1:], `"`)
	if end < 0 {
		return ""
	}
	return rest[1 : end+1]
}

// ReadScripts returns a map of script-name to command string from package.json.
func ReadScripts(path string) map[string]string {
	result := map[string]string{}
	data, err := os.ReadFile(path)
	if err != nil {
		return result
	}
	content := string(data)
	idx := strings.Index(content, `"scripts"`)
	if idx < 0 {
		return result
	}
	rest := content[idx:]
	start := strings.Index(rest, "{")
	end := strings.Index(rest, "}")
	if start < 0 || end < 0 || end <= start {
		return result
	}
	block := rest[start+1 : end]
	for _, line := range strings.Split(block, "\n") {
		line = strings.TrimSpace(strings.TrimRight(line, ","))
		if len(line) == 0 || line[0] != '"' {
			continue
		}
		parts := strings.SplitN(line, ":", 2)
		if len(parts) != 2 {
			continue
		}
		key := strings.Trim(strings.TrimSpace(parts[0]), `"`)
		val := strings.Trim(strings.TrimSpace(parts[1]), `"`)
		result[key] = val
	}
	return result
}
