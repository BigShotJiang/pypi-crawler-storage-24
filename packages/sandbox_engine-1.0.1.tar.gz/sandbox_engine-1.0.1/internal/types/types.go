// Package types defines the core domain types used across sandbox-engine packages.
package types

import "time"

// Language represents a detected programming language.
type Language string

const (
	LangNode    Language = "Node.js"
	LangPython  Language = "Python"
	LangGo      Language = "Go"
	LangJava    Language = "Java"
	LangRust    Language = "Rust"
	LangPHP     Language = "PHP"
	LangDotNet  Language = "C# (.NET)"
	LangStatic  Language = "Static"
	LangDocker  Language = "Docker"
	LangUnknown Language = "Unknown"
)

// Framework represents a detected web or application framework.
type Framework string

const (
	FWReact      Framework = "React"
	FWNextJS     Framework = "Next.js"
	FWVue        Framework = "Vue"
	FWNuxt       Framework = "Nuxt"
	FWAngular    Framework = "Angular"
	FWVite       Framework = "Vite"
	FWSvelte     Framework = "Svelte"
	FWAstro      Framework = "Astro"
	FWGatsby     Framework = "Gatsby"
	FWExpress    Framework = "Express"
	FWNestJS     Framework = "NestJS"
	FWFastAPI    Framework = "FastAPI"
	FWFlask      Framework = "Flask"
	FWDjango     Framework = "Django"
	FWSpringBoot Framework = "Spring Boot"
	FWAspNet     Framework = "ASP.NET"
	FWNone       Framework = ""
)

// Project holds all metadata about a single detected sub-project.
type Project struct {
	Name       string
	Root       string    // Absolute path to the project root directory
	Language   Language
	Framework  Framework
	EntryPoint string
	Port       int
	UseDocker  bool     // Dockerfile present
	UseDCom    bool     // docker-compose.yml / yaml present
	LockFile   string   // "npm" | "pnpm" | "yarn"
	HasVenv    bool     // Python virtual-env already exists on disk
	VenvPath   string   // Path to venv (existing or to-be-created)
	Files      []string // Top-level filenames in Root
}

// ScanResult is the output of a full repository scan.
type ScanResult struct {
	RepoRoot string
	Projects []*Project
	Duration time.Duration
}
