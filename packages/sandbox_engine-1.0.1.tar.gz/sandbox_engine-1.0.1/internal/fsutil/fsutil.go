// Package fsutil provides file-system utility helpers used across sandbox-engine.
package fsutil

import (
	"os"
	"path/filepath"
	"strings"
)

// FileSet converts a filename slice into a lowercase presence map for fast
// membership checks.
func FileSet(files []string) map[string]bool {
	fs := make(map[string]bool, len(files))
	for _, f := range files {
		fs[strings.ToLower(f)] = true
	}
	return fs
}

// HasCsproj returns true if any element of files ends with ".csproj".
func HasCsproj(files []string) bool {
	for _, f := range files {
		if strings.HasSuffix(strings.ToLower(f), ".csproj") {
			return true
		}
	}
	return false
}

// FileExists reports whether path is a regular file.
func FileExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && !info.IsDir()
}

// DirExists reports whether path is a directory.
func DirExists(path string) bool {
	info, err := os.Stat(path)
	return err == nil && info.IsDir()
}

// ReadFileLower reads a file and returns its contents lower-cased.
// Returns an empty string on any error.
func ReadFileLower(path string) string {
	data, err := os.ReadFile(path)
	if err != nil {
		return ""
	}
	return strings.ToLower(string(data))
}

// ReadLines returns the lines of a file split on newline.
// Returns nil on any error.
func ReadLines(path string) []string {
	data, err := os.ReadFile(path)
	if err != nil {
		return nil
	}
	return strings.Split(string(data), "\n")
}

// PythonBin resolves the path to a binary inside a virtual-env.
// Falls back to the bare binary name (PATH lookup) when not found in the venv.
func PythonBin(venvPath, bin string) string {
	// Unix layout
	if p := filepath.Join(venvPath, "bin", bin); FileExists(p) {
		return p
	}
	// Windows layout
	if p := filepath.Join(venvPath, "Scripts", bin+".exe"); FileExists(p) {
		return p
	}
	return bin
}
