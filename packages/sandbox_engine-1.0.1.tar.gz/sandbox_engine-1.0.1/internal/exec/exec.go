// Package exec provides thin wrappers around os/exec for running subprocesses.
package exec

import (
	"os"
	osexec "os/exec"
)

// RunCmd runs name+args in dir, streaming stdout/stderr. Returns any error.
func RunCmd(dir, name string, args ...string) error {
	cmd := osexec.Command(name, args...)
	cmd.Dir = dir
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

// RunCmdAttached attaches stdin/stdout/stderr for interactive or long-lived
// processes (dev servers, docker compose, etc.).
func RunCmdAttached(dir, name string, args ...string) error {
	cmd := osexec.Command(name, args...)
	cmd.Dir = dir
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

// RunCmdAttachedEnv is like RunCmdAttached but prepends extra environment
// variables before the inherited process environment.
func RunCmdAttachedEnv(dir string, extraEnv []string, name string, args ...string) error {
	cmd := osexec.Command(name, args...)
	cmd.Dir = dir
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	cmd.Env = append(os.Environ(), extraEnv...)
	return cmd.Run()
}

// CommandExists reports whether the named binary is accessible via PATH.
func CommandExists(name string) bool {
	_, err := osexec.LookPath(name)
	return err == nil
}
