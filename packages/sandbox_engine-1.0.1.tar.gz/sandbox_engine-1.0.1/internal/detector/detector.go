// Package detector analyses Project metadata to determine language, framework,
// entry point, and default port.
package detector

import (
	"path/filepath"
	"strings"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/fsutil"
	"sandbox-engine/internal/pkgjson"
	"sandbox-engine/internal/types"
)

// Detector analyses Projects and fills Language, Framework, EntryPoint, Port.
type Detector struct{}

// New returns a ready-to-use Detector.
func New() *Detector { return &Detector{} }

// DetectAll runs detection across every project in the scan result.
func (d *Detector) DetectAll(result *types.ScanResult) {
	color.Header("Runtime & Framework Detector")
	for _, p := range result.Projects {
		d.Detect(p)
	}
}

// Detect fills all detection fields for a single project.
func (d *Detector) Detect(p *types.Project) {
	fs := fsutil.FileSet(p.Files)

	// Docker presence
	p.UseDCom = fs["docker-compose.yml"] || fs["docker-compose.yaml"]
	p.UseDocker = fs["dockerfile"]

	// Language — priority order
	switch {
	case fs["package.json"]:
		p.Language = types.LangNode
	case fs["requirements.txt"] || fs["pyproject.toml"] || fs["pipfile"] || fs["manage.py"]:
		p.Language = types.LangPython
	case fs["go.mod"]:
		p.Language = types.LangGo
	case fs["pom.xml"] || fs["build.gradle"]:
		p.Language = types.LangJava
	case fs["cargo.toml"]:
		p.Language = types.LangRust
	case fsutil.HasCsproj(p.Files):
		p.Language = types.LangDotNet
		p.Framework = types.FWAspNet
	case fs["index.html"] || fs["index.htm"]:
		p.Language = types.LangStatic
	case p.UseDCom || p.UseDocker:
		p.Language = types.LangDocker
	default:
		p.Language = types.LangUnknown
	}

	// Framework
	switch p.Language {
	case types.LangNode:
		p.Framework = d.detectNodeFramework(p, fs)
		p.LockFile = detectLockFile(fs)
	case types.LangPython:
		p.Framework = d.detectPythonFramework(p, fs)
	case types.LangJava:
		p.Framework = d.detectJavaFramework(p)
	}

	// Python virtual environment
	if p.Language == types.LangPython {
		for _, name := range []string{"venv", ".venv", "env"} {
			if fsutil.DirExists(filepath.Join(p.Root, name)) {
				p.HasVenv = true
				p.VenvPath = filepath.Join(p.Root, name)
				break
			}
		}
		if !p.HasVenv {
			p.VenvPath = filepath.Join(p.Root, "venv")
		}
	}

	// Entry point and port
	p.EntryPoint = d.detectEntryPoint(p, fs)
	p.Port = defaultPort(p)

	color.Success("%-20s  lang=%-12s  fw=%-12s  port=%d  entry=%s",
		p.Name,
		color.Sprintf(color.Cyan, string(p.Language)),
		color.Sprintf(color.Yellow, string(p.Framework)),
		p.Port,
		p.EntryPoint,
	)
}

// detectNodeFramework returns the JS/Node framework for the project.
func (d *Detector) detectNodeFramework(p *types.Project, fs map[string]bool) types.Framework {
	// Config-file signals carry the highest confidence.
	switch {
	case fs["angular.json"]:
		return types.FWAngular
	case fs["astro.config.mjs"] || fs["astro.config.ts"]:
		return types.FWAstro
	case fs["gatsby-config.js"] || fs["gatsby-config.ts"]:
		return types.FWGatsby
	case fs["vite.config.js"] || fs["vite.config.ts"]:
		return types.FWVite
	}

	// Fall back to scanning package.json dependencies.
	deps := pkgjson.ReadDeps(filepath.Join(p.Root, "package.json"))
	switch {
	case deps["nuxt"]:
		return types.FWNuxt
	case deps["next"]:
		return types.FWNextJS
	case deps["gatsby"]:
		return types.FWGatsby
	case deps["@sveltejs/kit"] || deps["svelte"]:
		return types.FWSvelte
	case deps["@angular/core"]:
		return types.FWAngular
	case deps["@nestjs/core"]:
		return types.FWNestJS
	case deps["express"]:
		return types.FWExpress
	case deps["vue"]:
		return types.FWVue
	case deps["react"]:
		return types.FWReact
	}
	return types.FWNone
}

// detectLockFile returns "pnpm", "yarn", or "npm" based on lock-file presence.
func detectLockFile(fs map[string]bool) string {
	switch {
	case fs["pnpm-lock.yaml"]:
		return "pnpm"
	case fs["yarn.lock"]:
		return "yarn"
	default:
		return "npm"
	}
}

// detectPythonFramework infers the Python web framework.
func (d *Detector) detectPythonFramework(p *types.Project, fs map[string]bool) types.Framework {
	if fs["manage.py"] {
		return types.FWDjango
	}

	// Scan requirements.txt for known package names.
	for _, line := range fsutil.ReadLines(filepath.Join(p.Root, "requirements.txt")) {
		lower := strings.ToLower(strings.TrimSpace(line))
		switch {
		case strings.HasPrefix(lower, "fastapi"):
			return types.FWFastAPI
		case strings.HasPrefix(lower, "flask"):
			return types.FWFlask
		case strings.HasPrefix(lower, "django"):
			return types.FWDjango
		}
	}

	// Scan common Python entry files for import statements.
	for _, candidate := range []string{"app.py", "main.py", "server.py"} {
		content := fsutil.ReadFileLower(filepath.Join(p.Root, candidate))
		switch {
		case strings.Contains(content, "fastapi"):
			return types.FWFastAPI
		case strings.Contains(content, "flask"):
			return types.FWFlask
		case strings.Contains(content, "django"):
			return types.FWDjango
		}
	}
	return types.FWNone
}

// detectJavaFramework checks pom.xml / build.gradle for Spring Boot markers.
func (d *Detector) detectJavaFramework(p *types.Project) types.Framework {
	combined := fsutil.ReadFileLower(filepath.Join(p.Root, "pom.xml")) +
		fsutil.ReadFileLower(filepath.Join(p.Root, "build.gradle"))
	if strings.Contains(combined, "spring-boot") || strings.Contains(combined, "spring.boot") {
		return types.FWSpringBoot
	}
	return types.FWNone
}

// detectEntryPoint returns the primary launch file for the project.
func (d *Detector) detectEntryPoint(p *types.Project, fs map[string]bool) string {
	switch p.Language {
	case types.LangPython:
		for _, ep := range []string{"manage.py", "app.py", "main.py", "server.py"} {
			if fs[strings.ToLower(ep)] {
				return ep
			}
		}
	case types.LangNode:
		if main := pkgjson.ReadMain(filepath.Join(p.Root, "package.json")); main != "" {
			return main
		}
		for _, ep := range []string{"index.js", "server.js", "app.js", "index.ts", "src/index.js", "src/index.ts"} {
			if fsutil.FileExists(filepath.Join(p.Root, ep)) {
				return ep
			}
		}
	case types.LangGo:
		if fs["main.go"] {
			return "main.go"
		}
	case types.LangJava:
		if fs["pom.xml"] {
			return "pom.xml"
		}
		return "build.gradle"
	case types.LangRust:
		return "Cargo.toml"
	case types.LangDotNet:
		for _, f := range p.Files {
			if strings.HasSuffix(strings.ToLower(f), ".csproj") {
				return f
			}
		}
	case types.LangStatic:
		return "index.html"
	}
	return ""
}

// defaultPort returns the conventional port for a project.
func defaultPort(p *types.Project) int {
	switch p.Framework {
	case types.FWFlask:
		return 5000
	case types.FWFastAPI, types.FWDjango:
		return 8000
	case types.FWSpringBoot, types.FWAspNet:
		return 8080
	}
	switch p.Language {
	case types.LangGo, types.LangJava:
		return 8080
	case types.LangPython:
		return 5000
	case types.LangNode, types.LangStatic:
		return 3000
	}
	return 3000
}
