// Package color provides zero-dependency ANSI colour helpers and structured
// log functions for the sandbox-engine CLI.
package color

import (
	"fmt"
	"os"
	"strings"
)

// ANSI escape codes.
const (
	Reset   = "\033[0m"
	Bold    = "\033[1m"
	Cyan    = "\033[36m"
	Green   = "\033[32m"
	Yellow  = "\033[33m"
	Red     = "\033[31m"
	Magenta = "\033[35m"
	White   = "\033[97m"
)

// Sprintf wraps text with an ANSI colour code and resets afterwards.
func Sprintf(code, format string, args ...interface{}) string {
	return code + fmt.Sprintf(format, args...) + Reset
}

// Info prints an informational message to stdout.
func Info(format string, args ...interface{}) {
	fmt.Printf("%s  %s\n", Sprintf(Cyan, "[INFO]"), fmt.Sprintf(format, args...))
}

// Success prints a success message to stdout.
func Success(format string, args ...interface{}) {
	fmt.Printf("%s  %s\n", Sprintf(Green, "[OK]"), fmt.Sprintf(format, args...))
}

// Warn prints a warning message to stdout.
func Warn(format string, args ...interface{}) {
	fmt.Printf("%s  %s\n", Sprintf(Yellow, "[WARN]"), fmt.Sprintf(format, args...))
}

// Error prints an error message to stderr.
func Error(format string, args ...interface{}) {
	fmt.Fprintf(os.Stderr, "%s  %s\n", Sprintf(Red, "[ERR]"), fmt.Sprintf(format, args...))
}

// Step prints a step/action message to stdout.
func Step(format string, args ...interface{}) {
	fmt.Printf("%s  %s\n", Sprintf(Magenta, "[-->]"), fmt.Sprintf(format, args...))
}

// Header prints a bold section header with a horizontal rule.
func Header(title string) {
	line := strings.Repeat("-", 60)
	fmt.Printf("\n%s%s%s\n  %s\n%s%s%s\n",
		Bold, line, Reset,
		Sprintf(Bold, title),
		Bold, line, Reset,
	)
}
