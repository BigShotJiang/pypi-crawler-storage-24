// Package runtime provides per-language dependency installation and application
// launch logic for Node.js projects.
package runtime

import (
	"fmt"
	"path/filepath"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/exec"
	"sandbox-engine/internal/pkgjson"
	"sandbox-engine/internal/types"
)

// NodeInstall runs the appropriate package manager install command.
func NodeInstall(p *types.Project) error {
	pm := p.LockFile
	if pm == "" {
		pm = "npm"
	}
	color.Step("Running: %s install", pm)
	return exec.RunCmd(p.Root, pm, "install")
}

// LaunchNode starts the Node.js application.
// Preference order: dev script -> start script -> direct node invocation.
func LaunchNode(p *types.Project) error {
	pm := p.LockFile
	if pm == "" {
		pm = "npm"
	}
	scripts := pkgjson.ReadScripts(filepath.Join(p.Root, "package.json"))
	portEnv := fmt.Sprintf("PORT=%d", p.Port)

	color.Step("Starting Node server on port %d", p.Port)

	switch {
	case scripts["dev"] != "":
		return exec.RunCmdAttachedEnv(p.Root, []string{portEnv}, pm, "run", "dev")
	case scripts["start"] != "":
		return exec.RunCmdAttachedEnv(p.Root, []string{portEnv}, pm, "start")
	case p.EntryPoint != "":
		return exec.RunCmdAttachedEnv(p.Root, []string{portEnv}, "node", p.EntryPoint)
	}
	return fmt.Errorf("no runnable script or entry point found in package.json")
}
