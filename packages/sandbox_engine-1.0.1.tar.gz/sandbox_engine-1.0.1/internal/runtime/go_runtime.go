// Package runtime — Go module install and launch logic.
package runtime

import (
	"fmt"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/exec"
	"sandbox-engine/internal/types"
)

// GoInstall runs go mod tidy to sync the module graph.
func GoInstall(p *types.Project) error {
	color.Step("Running: go mod tidy")
	return exec.RunCmd(p.Root, "go", "mod", "tidy")
}

// LaunchGo starts the Go application with the PORT environment variable set.
func LaunchGo(p *types.Project) error {
	color.Step("Starting Go application on port %d", p.Port)
	return exec.RunCmdAttachedEnv(p.Root,
		[]string{fmt.Sprintf("PORT=%d", p.Port)},
		"go", "run", ".")
}
