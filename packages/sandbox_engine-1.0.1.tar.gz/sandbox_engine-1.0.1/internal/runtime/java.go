// Package runtime — Java (Maven / Gradle) install and launch logic.
package runtime

import (
	"fmt"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/exec"
	"sandbox-engine/internal/fsutil"
	"sandbox-engine/internal/types"
)

// JavaInstall downloads dependencies using Maven or Gradle.
func JavaInstall(p *types.Project) error {
	fs := fsutil.FileSet(p.Files)
	if fs["pom.xml"] {
		color.Step("Running: mvn install -DskipTests")
		return exec.RunCmd(p.Root, "mvn", "install", "-DskipTests")
	}
	if fs["build.gradle"] {
		color.Step("Running: gradle build -x test")
		return exec.RunCmd(p.Root, "gradle", "build", "-x", "test")
	}
	return nil
}

// LaunchJava starts a Spring Boot application via Maven or Gradle.
func LaunchJava(p *types.Project) error {
	color.Step("Starting Java application on port %d", p.Port)
	portArg := fmt.Sprintf("--server.port=%d", p.Port)
	if fsutil.FileSet(p.Files)["pom.xml"] {
		return exec.RunCmdAttached(p.Root, "mvn", "spring-boot:run",
			"-Dspring-boot.run.arguments="+portArg)
	}
	return exec.RunCmdAttached(p.Root, "gradle", "bootRun", "--args="+portArg)
}
