// Package runtime provides the top-level Install and Run dispatchers that
// delegate to the appropriate language-specific implementation.
package runtime

import (
	"fmt"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/types"
)

// InstallDependencies installs project dependencies in an isolated environment.
// For Docker projects it does nothing; isolation is handled by the container.
func InstallDependencies(p *types.Project) error {
	color.Header(fmt.Sprintf("Installing Dependencies — %s", p.Name))

	if p.UseDCom || p.UseDocker {
		color.Step("Docker project — skipping host-level dependency install")
		return nil
	}

	switch p.Language {
	case types.LangNode:
		return NodeInstall(p)
	case types.LangPython:
		return PythonInstall(p)
	case types.LangJava:
		return JavaInstall(p)
	case types.LangGo:
		return GoInstall(p)
	case types.LangRust:
		return RustInstall(p)
	default:
		color.Warn("No installer defined for language: %s", p.Language)
	}
	return nil
}

// RunProject launches the application described by p.
func RunProject(p *types.Project) error {
	color.Header(fmt.Sprintf("Starting — %s", p.Name))
	color.Info("Language  : %s", color.Sprintf(color.Cyan, string(p.Language)))
	color.Info("Framework : %s", color.Sprintf(color.Yellow, string(p.Framework)))
	color.Info("Entry     : %s", p.EntryPoint)
	color.Info("Port      : %d", p.Port)
	color.Info("Root      : %s", p.Root)
	fmt.Println()

	// Docker has the highest launch priority.
	if p.UseDCom {
		return LaunchDockerCompose(p)
	}
	if p.UseDocker {
		return LaunchDockerfile(p)
	}

	switch p.Language {
	case types.LangNode:
		return LaunchNode(p)
	case types.LangPython:
		return LaunchPython(p)
	case types.LangJava:
		return LaunchJava(p)
	case types.LangGo:
		return LaunchGo(p)
	case types.LangRust:
		return LaunchRust(p)
	case types.LangStatic:
		return LaunchStatic(p)
	}
	return fmt.Errorf("unsupported language: %s", p.Language)
}
