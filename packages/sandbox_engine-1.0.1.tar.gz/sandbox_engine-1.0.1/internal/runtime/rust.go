// Package runtime — Rust (Cargo) install and launch logic.
package runtime

import (
	"fmt"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/exec"
	"sandbox-engine/internal/types"
)

// RustInstall runs cargo build to compile the project and download crates.
func RustInstall(p *types.Project) error {
	color.Step("Running: cargo build")
	return exec.RunCmd(p.Root, "cargo", "build")
}

// LaunchRust runs the compiled Rust binary via cargo run.
func LaunchRust(p *types.Project) error {
	color.Step("Starting Rust application on port %d", p.Port)
	return exec.RunCmdAttachedEnv(p.Root,
		[]string{fmt.Sprintf("PORT=%d", p.Port)},
		"cargo", "run")
}
