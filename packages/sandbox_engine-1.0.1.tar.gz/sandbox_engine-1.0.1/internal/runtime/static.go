// Package runtime — Static site launch logic.
package runtime

import (
	"fmt"
	"strings"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/exec"
	"sandbox-engine/internal/types"
)

// LaunchStatic serves a static site, trying common servers in preference order.
func LaunchStatic(p *types.Project) error {
	color.Step("Serving static site on port %d", p.Port)
	portStr := fmt.Sprintf("%d", p.Port)

	for _, args := range [][]string{
		{"npx", "serve", "-s", ".", "-l", portStr},
		{"python3", "-m", "http.server", portStr},
		{"python", "-m", "http.server", portStr},
	} {
		if exec.CommandExists(args[0]) {
			color.Info("Serving with: %s", strings.Join(args, " "))
			return exec.RunCmdAttached(p.Root, args[0], args[1:]...)
		}
	}
	return fmt.Errorf("no static server available — install Node.js or Python")
}
