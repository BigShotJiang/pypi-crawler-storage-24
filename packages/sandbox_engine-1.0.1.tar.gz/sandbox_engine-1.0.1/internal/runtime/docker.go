// Package runtime — Docker and docker-compose launch logic.
package runtime

import (
	"fmt"
	"strings"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/exec"
	"sandbox-engine/internal/types"
)

// LaunchDockerCompose starts the stack defined by docker-compose.yml.
func LaunchDockerCompose(p *types.Project) error {
	color.Step("docker compose up")
	return exec.RunCmdAttached(p.Root, "docker", "compose", "up")
}

// LaunchDockerfile builds a Docker image then runs a container from it.
func LaunchDockerfile(p *types.Project) error {
	image := strings.ToLower(strings.ReplaceAll(p.Name, " ", "-")) + "-sandbox"
	color.Step("docker build -t %s .", image)
	if err := exec.RunCmd(p.Root, "docker", "build", "-t", image, "."); err != nil {
		return err
	}
	portMap := fmt.Sprintf("%d:%d", p.Port, p.Port)
	color.Step("docker run --rm -p %s %s", portMap, image)
	return exec.RunCmdAttached(p.Root, "docker", "run", "--rm", "-p", portMap, image)
}
