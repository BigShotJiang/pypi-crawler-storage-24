// Package runtime — Python install and launch logic.
package runtime

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"

	"sandbox-engine/internal/color"
	"sandbox-engine/internal/exec"
	"sandbox-engine/internal/fsutil"
	"sandbox-engine/internal/types"
)

// PythonInstall creates a virtual environment (if needed) and installs
// dependencies from requirements.txt.
func PythonInstall(p *types.Project) error {
	if !p.HasVenv {
		color.Step("Creating virtual environment: %s", p.VenvPath)
		if err := createVenv(p); err != nil {
			return fmt.Errorf("venv creation failed: %w", err)
		}
		p.HasVenv = true
		color.Success("Virtual environment created")
	} else {
		color.Info("Existing virtual environment: %s", p.VenvPath)
	}

	pip := fsutil.PythonBin(p.VenvPath, "pip")

	reqsPath := filepath.Join(p.Root, "requirements.txt")
	if !fsutil.FileExists(reqsPath) {
		color.Warn("requirements.txt not found — scanning Python source files")
		if err := generateRequirements(p.Root, reqsPath); err != nil {
			color.Warn("Auto-generation failed: %v", err)
		} else {
			color.Success("Generated requirements.txt from import statements")
		}
	}

	if fsutil.FileExists(reqsPath) {
		color.Step("Running: pip install -r requirements.txt  (inside venv)")
		return exec.RunCmd(p.Root, pip, "install", "-r", reqsPath)
	}
	color.Warn("No requirements.txt available — skipping pip install")
	return nil
}

// LaunchPython starts the Python application using the framework-appropriate runner.
func LaunchPython(p *types.Project) error {
	py := fsutil.PythonBin(p.VenvPath, "python")
	color.Step("Starting Python server on port %d", p.Port)

	switch p.Framework {
	case types.FWDjango:
		return exec.RunCmdAttached(p.Root, py, "manage.py", "runserver",
			fmt.Sprintf("0.0.0.0:%d", p.Port))

	case types.FWFastAPI:
		uvicorn := fsutil.PythonBin(p.VenvPath, "uvicorn")
		app := detectFastAPIApp(p)
		return exec.RunCmdAttached(p.Root, uvicorn, app,
			"--host", "0.0.0.0",
			"--port", fmt.Sprintf("%d", p.Port),
			"--reload")

	case types.FWFlask:
		flask := fsutil.PythonBin(p.VenvPath, "flask")
		env := []string{
			"FLASK_APP=" + p.EntryPoint,
			fmt.Sprintf("FLASK_RUN_PORT=%d", p.Port),
			"FLASK_ENV=development",
		}
		return exec.RunCmdAttachedEnv(p.Root, env, flask, "run", "--host", "0.0.0.0")
	}

	if p.EntryPoint != "" {
		return exec.RunCmdAttached(p.Root, py, p.EntryPoint)
	}
	return fmt.Errorf("no Python entry point detected")
}

// createVenv tries to create a virtual-env using python3 then python.
func createVenv(p *types.Project) error {
	for _, py := range []string{"python3", "python"} {
		if exec.CommandExists(py) {
			if err := exec.RunCmd(p.Root, py, "-m", "venv", p.VenvPath); err == nil {
				return nil
			}
		}
	}
	return fmt.Errorf("neither python3 nor python found in PATH")
}

// detectFastAPIApp returns the "module:app" string expected by uvicorn.
func detectFastAPIApp(p *types.Project) string {
	for _, f := range []string{"main.py", "app.py", "server.py"} {
		content := fsutil.ReadFileLower(filepath.Join(p.Root, f))
		if strings.Contains(content, "fastapi()") {
			return strings.TrimSuffix(f, ".py") + ":app"
		}
	}
	return "main:app"
}

// generateRequirements scans .py files and writes a requirements.txt.
// Standard-library modules are excluded automatically.
func generateRequirements(root, dest string) error {
	stdlib := map[string]bool{
		"os": true, "sys": true, "re": true, "json": true, "math": true,
		"time": true, "datetime": true, "typing": true, "pathlib": true,
		"collections": true, "itertools": true, "functools": true, "io": true,
		"abc": true, "copy": true, "random": true, "threading": true,
		"subprocess": true, "shutil": true, "logging": true, "argparse": true,
		"unittest": true, "dataclasses": true, "enum": true, "hashlib": true,
		"base64": true, "urllib": true, "http": true, "socket": true,
		"struct": true, "pickle": true, "csv": true, "xml": true,
		"html": true, "string": true, "textwrap": true, "traceback": true,
		"inspect": true, "contextlib": true, "warnings": true, "builtins": true,
	}

	imports := map[string]bool{}
	err := filepath.WalkDir(root, func(path string, d os.DirEntry, err error) error {
		if err != nil || d.IsDir() || !strings.HasSuffix(path, ".py") {
			return err
		}
		data, readErr := os.ReadFile(path)
		if readErr != nil {
			return nil
		}
		for _, line := range strings.Split(string(data), "\n") {
			line = strings.TrimSpace(line)
			var pkg string
			switch {
			case strings.HasPrefix(line, "import "):
				parts := strings.Fields(line)
				if len(parts) >= 2 {
					pkg = strings.Split(parts[1], ".")[0]
				}
			case strings.HasPrefix(line, "from "):
				parts := strings.Fields(line)
				if len(parts) >= 2 {
					pkg = strings.Split(parts[1], ".")[0]
				}
			}
			if pkg != "" && !stdlib[pkg] &&
				!strings.HasPrefix(pkg, ".") &&
				!strings.HasPrefix(pkg, "_") {
				imports[pkg] = true
			}
		}
		return nil
	})
	if err != nil {
		return err
	}

	lines := make([]string, 0, len(imports))
	for pkg := range imports {
		lines = append(lines, pkg)
	}
	return os.WriteFile(dest, []byte(strings.Join(lines, "\n")+"\n"), 0644)
}
