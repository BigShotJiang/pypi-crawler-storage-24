"""Pytest configuration for integration tests."""

import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
from pathlib import Path

import pytest


def is_server_available(host="localhost", port=4840, timeout=1.0):
    """Check if OPC UA server is available."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        result = sock.connect_ex((host, port))
        sock.close()
        return result == 0
    except Exception:
        return False


def is_http_api_available(api_base="http://localhost:8080", timeout=1.0):
    """Check if HTTP injection API is available. Returns (available, error_msg)."""
    try:
        req = urllib.request.Request(f"{api_base.rstrip('/')}/inject", method="GET")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return (True, None) if resp.status == 200 else (False, f"HTTP {resp.status}")
    except urllib.error.HTTPError as e:
        return (False, f"HTTP {e.code}: {e.reason}")
    except urllib.error.URLError as e:
        return (False, f"URL error: {e.reason}")
    except Exception as e:
        return (False, f"{type(e).__name__}: {e}")


def wait_for_server(host="localhost", port=4840, timeout=10.0, check_interval=0.2):
    """
    Wait for OPC UA server to become available.

    Args:
        host: Server hostname
        port: Server port
        timeout: Maximum seconds to wait
        check_interval: Seconds between checks

    Returns:
        True if server became available, False if timeout
    """
    elapsed = 0.0
    attempts = 0
    while elapsed < timeout:
        if is_server_available(host, port, timeout=1.0):
            return True
        attempts += 1
        # Print progress every 2 seconds
        if attempts % 10 == 0:
            print(f" {elapsed:.1f}s", end="", flush=True)
        time.sleep(check_interval)
        elapsed += check_interval
    return False


def wait_for_http_api(api_base="http://localhost:8080", timeout=10.0, check_interval=0.2):
    """
    Wait for HTTP injection API to become available.

    Args:
        api_base: API base URL
        timeout: Maximum seconds to wait
        check_interval: Seconds between checks

    Returns:
        (success, last_error_msg): True/False and the last error encountered
    """
    elapsed = 0.0
    last_error = None
    attempts = 0
    while elapsed < timeout:
        available, error_msg = is_http_api_available(api_base, timeout=1.0)
        if available:
            return (True, None)
        last_error = error_msg
        attempts += 1
        # Print progress every 2 seconds
        if attempts % 10 == 0:
            print(f" {elapsed:.1f}s", end="", flush=True)
        time.sleep(check_interval)
        elapsed += check_interval
    return (False, last_error)


@pytest.fixture(scope="session")
def opcua_test_server():
    """
    Start OPC UA replay server for integration tests.

    Automatically starts the server with test data, waits for it to be ready,
    yields to tests, then cleanly shuts down.

    Yields:
        dict with server info (endpoint, api_base, process)
    """
    # Check if server is already running
    if is_server_available():
        # Use existing server
        print("\n[!] OPC UA server already running on localhost:4840 - using existing server")
        yield {
            "endpoint": "opc.tcp://localhost:4840/",
            "api_base": "http://localhost:8080",
            "process": None,
            "using_existing": True,
        }
        return

    # Start new server
    fixtures_dir = Path(__file__).parent / "fixtures"
    test_data = fixtures_dir / "test-data.csv"

    if not test_data.exists():
        pytest.fail(f"Test data not found: {test_data}")

    print(f"\n[*] Starting OPC UA test server with {test_data.name}...")

    try:
        # Start server process
        process = subprocess.Popen(
            [
                sys.executable,
                "-m",
                "opc_replay.server",
                "--data",
                str(test_data),
                "--ts-col",
                "TS",
                "--auto-nodeset",
                "--loop",
                "--speed",
                "10",
                "--api-port",
                "8080",
            ],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=Path(__file__).parent.parent.parent,  # workspace root
        )

        # Wait for OPC UA server to be ready
        print("   Waiting for OPC UA server to be ready...", end="", flush=True)
        if not wait_for_server(timeout=10.0):
            # Server failed to start - terminate and capture output
            process.terminate()
            try:
                stdout, stderr = process.communicate(timeout=5.0)
                error_msg = (
                    f"OPC UA server failed to start within 10s\n"
                    f"stdout: {stdout.decode()}\n"
                    f"stderr: {stderr.decode()}"
                )
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
                error_msg = (
                    "OPC UA server failed to start within 10s (process did not terminate cleanly)"
                )
            pytest.fail(error_msg)

        print(" OK")

        # Wait for HTTP API to be ready
        print("   Waiting for HTTP API to be ready...", end="", flush=True)
        api_success, api_error = wait_for_http_api(api_base="http://localhost:8080", timeout=20.0)
        if not api_success:
            # API failed to start - check if port is bound
            port_bound = is_server_available("localhost", 8080, timeout=0.5)
            process_running = process.poll() is None

            # API failed to start - terminate and capture output
            print(" FAILED")
            print(f"   Last error: {api_error}")
            print(f"   Port 8080 bound: {port_bound}")
            print(f"   Process running: {process_running}")
            process.terminate()
            try:
                stdout, stderr = process.communicate(timeout=5.0)
                # Show recent output
                stdout_lines = stdout.decode().strip().split("\n")
                stderr_lines = stderr.decode().strip().split("\n")
                error_msg = (
                    f"HTTP API failed to start within 20s\n"
                    f"Last error from health check: {api_error}\n"
                    f"\nRecent stdout (last 10 lines):\n"
                    f"{chr(10).join(stdout_lines[-10:]) if stdout_lines else '(empty)'}\n"
                    f"\nRecent stderr (last 10 lines):\n"
                    f"{chr(10).join(stderr_lines[-10:]) if stderr_lines else '(empty)'}"
                )
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
                error_msg = (
                    "HTTP API failed to start within 10s (process did not terminate cleanly)"
                )
            pytest.fail(error_msg)

        print(" OK")

        # Yield server info to tests
        yield {
            "endpoint": "opc.tcp://localhost:4840/",
            "api_base": "http://localhost:8080",
            "process": process,
            "using_existing": False,
        }

    finally:
        # Cleanup: stop server if we started it
        if process is not None and process.poll() is None:
            print("\n[*] Stopping OPC UA test server...")
            process.terminate()
            try:
                process.wait(timeout=5.0)
                print("   OK Server stopped cleanly")
            except subprocess.TimeoutExpired:
                print("   [!] Server didn't stop gracefully, killing...")
                process.kill()
                process.wait()


@pytest.fixture(scope="session")
def opcua_server_available():
    """Fixture that checks if OPC UA server is available."""
    return is_server_available()


@pytest.fixture(scope="session")
def require_opcua_server(opcua_server_available):
    """Fixture that skips test if OPC UA server is not available."""
    if not opcua_server_available:
        pytest.skip("OPC UA server not available (requires server running on localhost:4840)")
