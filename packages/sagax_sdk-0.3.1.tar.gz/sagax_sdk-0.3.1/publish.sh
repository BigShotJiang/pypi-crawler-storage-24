#!/usr/bin/env bash
# Build and optionally upload SAGAX Python SDK to PyPI.
# Usage:
#   ./publish.sh          # build only
#   ./publish.sh upload   # build + upload (needs TWINE_USERNAME=__token__ and TWINE_PASSWORD=pypi-...)

set -e
cd "$(dirname "$0")"

echo "Building sagax SDK..."
rm -rf dist
python -m build

echo "Built:"
ls -la dist/

if [[ "${1:-}" == "upload" ]]; then
  if [[ -z "${TWINE_PASSWORD:-}" ]]; then
    echo "Upload: set TWINE_USERNAME=__token__ and TWINE_PASSWORD=<pypi-token> then run: twine upload dist/*"
    echo "Or run: twine upload dist/*  (will prompt for password)"
    exit 0
  fi
  export TWINE_USERNAME="${TWINE_USERNAME:-__token__}"
  twine upload dist/*
  echo "Done. Users can: pip install sagax --upgrade"
else
  echo "To upload to PyPI, run: ./publish.sh upload"
  echo "  (with TWINE_USERNAME=__token__ and TWINE_PASSWORD=pypi-...)"
fi
