"""SAGAX — Python SDK for the SAGAX Quantitative Trading Platform."""

from sagax.client import SagaxClient
from sagax.exceptions import APIError, AuthError, NotFoundError, RateLimitError, SagaxError

__version__ = "0.2.0"
__all__ = [
    "SagaxClient",
    "SagaxError",
    "AuthError",
    "RateLimitError",
    "NotFoundError",
    "APIError",
    "__version__",
]
