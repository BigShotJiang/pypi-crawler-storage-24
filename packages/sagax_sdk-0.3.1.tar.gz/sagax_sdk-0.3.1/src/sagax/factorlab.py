"""Factor Lab API module (LLM-driven factor generation)."""


class FactorLabAPI:
    """Access the Factor Lab for LLM factor generation (advanced tier).

    Available via ``client.factorlab``.
    """

    def __init__(self, client):
        self._request = client._request

    def generate(self, prompt: str = None, category: str = None,
                 timeout: int = 300) -> dict:
        """Auto-generate a new quant factor via LLM.

        Args:
            prompt: Generation prompt (optional).
            category: Target factor category.
            timeout: Request timeout (default 300s).
        """
        body = {}
        if prompt:
            body["prompt"] = prompt
        if category:
            body["category"] = category
        return self._request(
            "POST", "/api/factor-agent/generate",
            data=body, timeout=timeout,
        )

    def reviews(self) -> dict:
        """Get list of LLM-generated factors pending review."""
        return self._request("GET", "/api/factor-agent/reviews")

    def approve(self, filename: str) -> dict:
        """Approve an LLM-generated factor (auto-registers to factor system).

        Args:
            filename: Factor filename.
        """
        return self._request(
            "POST", f"/api/factor-agent/reviews/{filename}/approve",
        )

    def reject(self, filename: str) -> dict:
        """Reject an LLM-generated factor.

        Args:
            filename: Factor filename.
        """
        return self._request(
            "POST", f"/api/factor-agent/reviews/{filename}/reject",
        )
