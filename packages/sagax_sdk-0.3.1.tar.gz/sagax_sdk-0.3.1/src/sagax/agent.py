"""Multi-agent strategy API module."""


class AgentAPI:
    """Access the multi-agent strategy system (advanced tier).

    Available via ``client.agent``.
    """

    def __init__(self, client):
        self._request = client._request

    def strategy_spec(self) -> dict:
        """Get the default multi-agent strategy specification."""
        return self._request("GET", "/api/adaptive/agent/strategy-specs/default")

    def run(self, spec: dict = None, timeout: int = 300) -> dict:
        """Execute the multi-agent stock selection pipeline.

        Args:
            spec: Strategy specification dict (optional, uses default).
            timeout: Request timeout (default 300s).
        """
        body = {}
        if spec:
            body["spec"] = spec
        return self._request(
            "POST", "/api/adaptive/agent/run",
            data=body, timeout=timeout,
        )

    def llm_decision(self, mode: str = None, timeout: int = 600) -> dict:
        """Run LLM-driven multi-agent real-time decision system.

        Args:
            mode: Decision mode.
            timeout: Request timeout (default 600s).
        """
        body = {}
        if mode:
            body["mode"] = mode
        return self._request(
            "POST", "/api/adaptive/agent/llm-decision/run",
            data=body, timeout=timeout,
        )

    def regime(self) -> dict:
        """Get latest market regime detection result (bull/bear/sideways)."""
        return self._request("GET", "/api/adaptive/agent/regime/latest")
