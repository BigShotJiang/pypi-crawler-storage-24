"""SAGAX SDK exceptions."""


class SagaxError(Exception):
    """Base exception for all SAGAX SDK errors."""

    def __init__(self, message, code=None, status_code=None, response=None):
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.response = response


class AuthError(SagaxError):
    """Authentication or authorization failure (401/403)."""
    pass


class RateLimitError(SagaxError):
    """Rate limit exceeded (429). Check retry_after attribute."""

    def __init__(self, message, retry_after=None, **kwargs):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after


class NotFoundError(SagaxError):
    """Resource not found (404)."""
    pass


class APIError(SagaxError):
    """Generic API error for unexpected status codes."""
    pass
