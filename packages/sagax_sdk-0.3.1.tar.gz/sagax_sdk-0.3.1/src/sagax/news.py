"""News intelligence API module."""


class NewsAPI:
    """Access the news intelligence system (advanced tier).

    Available via ``client.news``.
    """

    def __init__(self, client):
        self._request = client._request

    def articles(self, category: str = None, start_date: str = None,
                 end_date: str = None) -> dict:
        """Get news articles with optional filters.

        Args:
            category: News category filter.
            start_date: Start date (YYYYMMDD). Defaults to server default.
            end_date: End date (YYYYMMDD). Defaults to today.
        """
        return self._request("GET", "/api/news-intel/articles", params={
            "category": category, "start_date": start_date,
            "end_date": end_date,
        })

    def signals(self, ts_code: str = None) -> dict:
        """Get news-based factor signals.

        Args:
            ts_code: Stock code for per-stock signals.
                If provided, queries ``/signals/{ts_code}``.
        """
        if ts_code:
            return self._request("GET", f"/api/news-intel/signals/{ts_code}")
        return self._request("GET", "/api/news-intel/signals")

    def dashboard(self) -> dict:
        """Get news intelligence dashboard statistics."""
        return self._request("GET", "/api/news-intel/dashboard")
