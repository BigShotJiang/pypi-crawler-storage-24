"""Schema discovery API module."""


class SchemaAPI:
    """Discover database tables and columns (advanced tier).

    Available via ``client.schema``.
    """

    def __init__(self, client):
        self._request = client._request

    def tables(self, database: str = None) -> dict:
        """List all tables across SAGAX databases with row counts and sizes.

        Args:
            database: Optional filter — ``sagax_astock``, ``sagax_futures``, or ``sagax_crypto``.
        """
        return self._request("GET", "/api/schema/tables", params={
            "database": database,
        })

    def table_detail(self, database: str, table: str) -> dict:
        """Get column definitions, stats, date range, and sample data for a table.

        Args:
            database: Database name (e.g. ``sagax_astock``).
            table: Table name (e.g. ``price_data``).
        """
        return self._request("GET", f"/api/schema/table/{database}/{table}")
