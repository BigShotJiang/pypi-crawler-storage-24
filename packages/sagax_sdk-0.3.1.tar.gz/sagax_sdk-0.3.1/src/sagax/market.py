"""Market data API module."""


class MarketAPI:
    """Access market-level data (basic tier).

    Available via ``client.market``.
    """

    def __init__(self, client):
        self._request = client._request

    def overview(self) -> dict:
        """Get market overview: major indices, advance/decline counts, volume stats."""
        return self._request("GET", "/api/market/overview")

    def indices(self) -> dict:
        """Get latest quotes for major market indices (SSE, SZSE, CSI300, etc.)."""
        return self._request("GET", "/api/market/indices")

    def sectors(self) -> dict:
        """Get sector/industry performance ranking."""
        return self._request("GET", "/api/market/sectors")

    def gainers(self, start_date: str = None, end_date: str = None) -> dict:
        """Get stocks ranked by daily gain.

        Args:
            start_date: Start date (YYYYMMDD). Defaults to latest trading day.
            end_date: End date (YYYYMMDD). Defaults to latest trading day.
        """
        return self._request("GET", "/api/market/gainers", params={
            "start_date": start_date, "end_date": end_date,
        })

    def losers(self, start_date: str = None, end_date: str = None) -> dict:
        """Get stocks ranked by daily loss.

        Args:
            start_date: Start date (YYYYMMDD). Defaults to latest trading day.
            end_date: End date (YYYYMMDD). Defaults to latest trading day.
        """
        return self._request("GET", "/api/market/losers", params={
            "start_date": start_date, "end_date": end_date,
        })

    def hsgt(self, start_date: str = None, end_date: str = None) -> dict:
        """Get HSGT (沪深港通) capital flow data.

        Args:
            start_date: Start date (YYYYMMDD). Defaults to 60 days ago.
            end_date: End date (YYYYMMDD). Defaults to today.
        """
        return self._request("GET", "/api/market/hsgt", params={
            "start_date": start_date, "end_date": end_date,
        })

    def limit_list(self, trade_date: str = None, limit_type: str = None) -> dict:
        """Get limit-up/limit-down stock list (涨跌停).

        Args:
            trade_date: Trade date (YYYYMMDD).
            limit_type: ``U`` for limit-up, ``D`` for limit-down.
        """
        return self._request("GET", "/api/market/limit-list", params={
            "trade_date": trade_date, "limit_type": limit_type,
        })

    def concepts(self, keyword: str = None) -> dict:
        """Get concept category list (概念板块).

        Args:
            keyword: Search keyword to filter concepts.
        """
        return self._request("GET", "/api/market/concepts", params={
            "keyword": keyword,
        })

    def concept_stocks(self, concept_code: str) -> dict:
        """Get constituent stocks for a concept (概念成分股).

        Args:
            concept_code: Concept code (e.g. ``TS4``).
        """
        return self._request("GET", f"/api/market/concept/{concept_code}/stocks")
