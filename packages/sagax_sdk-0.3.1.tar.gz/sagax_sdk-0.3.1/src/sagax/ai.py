"""AI analysis API module."""

from typing import List


class AIAPI:
    """Access AI-powered analysis (standard tier).

    Available via ``client.ai``.
    """

    def __init__(self, client):
        self._request = client._request

    def search(self, q: str) -> dict:
        """AI-powered smart stock search. Returns all results.

        Args:
            q: Search keyword.
        """
        return self._request("GET", "/api/ai-diagnosis/search/stocks", params={
            "q": q,
        })

    def valuation(self, ts_code: str, mode: str = None,
                  custom_prompt: str = None, timeout: int = None) -> dict:
        """AI valuation analysis (GPT-5.4).

        Args:
            ts_code: Stock code.
            mode: ``standard`` or ``thinking`` (deep analysis, may take 1-5 min).
            custom_prompt: Custom analysis prompt.
            timeout: Override timeout (recommend >=600 for thinking mode).
        """
        body = {"ts_code": ts_code}
        if mode:
            body["mode"] = mode
        if custom_prompt:
            body["custom_prompt"] = custom_prompt
        return self._request(
            "POST", "/api/ai-diagnosis/valuation/analyze",
            data=body, timeout=timeout or (600 if mode == "thinking" else None),
        )

    def comprehensive(self, ts_code: str, mode: str = None,
                      timeout: int = None) -> dict:
        """Multi-dimensional comprehensive evaluation.

        Args:
            ts_code: Stock code.
            mode: ``standard`` or ``thinking``.
            timeout: Override timeout.
        """
        body = {"ts_code": ts_code}
        if mode:
            body["mode"] = mode
        return self._request(
            "POST", "/api/ai-diagnosis/comprehensive-evaluation/analyze",
            data=body, timeout=timeout or (600 if mode == "thinking" else None),
        )

    def trend(self, ts_code: str, timeout: int = None) -> dict:
        """AI trend pattern recognition and prediction.

        Args:
            ts_code: Stock code.
            timeout: Override timeout.
        """
        return self._request(
            "POST", "/api/ai-diagnosis/trend-recognition/analyze",
            data={"ts_code": ts_code}, timeout=timeout,
        )

    def batch(self, ts_codes: List[str],
              analysis_types: List[str] = None, timeout: int = None) -> dict:
        """Batch AI analysis for multiple stocks.

        Args:
            ts_codes: List of stock codes.
            analysis_types: Types to run (``valuation``, ``trend``, ``comprehensive``).
            timeout: Override timeout.
        """
        body = {"ts_codes": ts_codes}
        if analysis_types:
            body["analysis_types"] = analysis_types
        return self._request(
            "POST", "/api/ai-diagnosis/batch/analyze",
            data=body, timeout=timeout,
        )

    def report(self, report_type: str, ts_code: str) -> dict:
        """Generate a PDF analysis report.

        Args:
            report_type: Report type (``valuation``, ``comprehensive``, ``trend``).
            ts_code: Stock code.

        Returns:
            Dict with ``filename`` and ``download_url``.
        """
        return self._request(
            "GET", f"/api/ai-diagnosis/reports/{report_type}/{ts_code}",
        )
