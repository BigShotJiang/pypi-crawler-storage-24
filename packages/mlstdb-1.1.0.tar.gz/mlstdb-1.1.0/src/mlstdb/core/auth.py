import configparser
import click
import os
import sys
from pathlib import Path
from typing import Tuple, Optional
from rauth import OAuth1Service, OAuth1Session
from mlstdb.core.config import get_config_dir, BASE_API, BASE_WEB, DB_MAPPING
from mlstdb.utils import error, success, info
from mlstdb.__about__ import __version__


def setup_client_credentials(site: str) -> Tuple[str, str]:
    """Setup and save client credentials."""
    config = configparser.ConfigParser(interpolation=None)
    file_path = get_config_dir() / "client_credentials"
    
    if file_path.exists():
        config.read(file_path)
    
    info("\nPlease enter your client credentials:")
    client_id = click.prompt("Client ID", type=str).strip()
    while len(client_id) != 24:
        error("Client IDs must be exactly 24 characters long")
        client_id = click.prompt("Client ID", type=str).strip()
    
    client_secret = click.prompt("Client Secret", type=str).strip()
    while len(client_secret) != 42:
        error("Client secrets must be exactly 42 characters long")
        client_secret = click.prompt("Client Secret", type=str).strip()

    config[site] = {"client_id": client_id, "client_secret": client_secret}
    
    fd = os.open(file_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as configfile:
        config.write(configfile)
    success(f"\nClient credentials saved to {file_path}")
    return client_id, client_secret

def register_tokens(db: str):
    """Setup authentication tokens by registering with the service."""
    info(f"\nNo tokens found for {db}. Starting registration process...")
    
    # Setup client credentials
    client_id, client_secret = setup_client_credentials(db)
    
    # Initialize OAuth service
    service = OAuth1Service(
        name="MLSTdb downloader",
        consumer_key=client_id,
        consumer_secret=client_secret,
        request_token_url=f"{BASE_API[db]}/db/{DB_MAPPING[db]}/oauth/get_request_token",
        access_token_url=f"{BASE_API[db]}/db/{DB_MAPPING[db]}/oauth/get_access_token",
        base_url=BASE_API[db],
    )
    
    # Get request token
    info("\nRequesting temporary token...")
    r = service.get_raw_request_token(
        params={"oauth_callback": "oob"},
        headers={"User-Agent": f"mlstdb/{__version__}"}
    )
    if r.status_code != 200:
        error(f"Failed to get request token: {r.json()['message']}")
        sys.exit(1)
    
    request_token = r.json()["oauth_token"]
    request_secret = r.json()["oauth_token_secret"]
    success("Temporary token received")
    
    # Get access token
    click.secho("\nAuthorisation Required", fg="yellow", bold=True)
    info(
        "\nPlease open this URL in your browser:\n"
        f"{BASE_WEB[db]}?db={DB_MAPPING[db]}&page=authorizeClient&oauth_token={request_token}"
    )
    
    verifier = click.prompt("\nEnter the verification code from the website", type=str)
    
    info("\nRequesting access token...")
    r = service.get_raw_access_token(
        request_token,
        request_secret,
        params={"oauth_verifier": verifier},
        headers={"User-Agent": f"mlstdb/{__version__}"},
    )
    
    if r.status_code != 200:
        error(f"Failed to get access token: {r.json()['message']}")
        sys.exit(1)
        
    access_token = r. json()["oauth_token"]
    access_secret = r.json()["oauth_token_secret"]
    
    # Save access token
    config = configparser.ConfigParser(interpolation=None)
    file_path = get_config_dir() / "access_tokens"
    if file_path.exists():
        config.read(file_path)
    config[db] = {"token": access_token, "secret": access_secret}
    fd = os.open(file_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as configfile:
        config.write(configfile)
    success(f"\nAccess token saved to {file_path}")

    # Get session token
    info("\nRequesting session token...")
    url = f"{BASE_API[db]}/db/{DB_MAPPING[db]}/oauth/get_session_token"
    
    session = OAuth1Session(
        service.consumer_key,
        service.consumer_secret,
        access_token=access_token,
        access_token_secret=access_secret
    )
    
    r = session.get(url, headers={"User-Agent": f"mlstdb/{__version__}"})
    
    if r.status_code != 200:
        error(f"Failed to get session token: {r.json()['message']}")
        sys.exit(1)
        
    token = r.json()["oauth_token"]
    secret = r. json()["oauth_token_secret"]
    
    # Save session token
    config = configparser. ConfigParser(interpolation=None)
    file_path = get_config_dir() / "session_tokens"
    if file_path.exists():
        config.read(file_path)
    config[db] = {"token": token, "secret": secret}
    fd = os.open(file_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as configfile:
        config.write(configfile)
    
    success(f"\nSession token saved to {file_path}")
    
    # Message after registration
    click.secho("\n=== Registration Complete ===", fg="green", bold=True)
    
    return token, secret

def get_config_dir() -> Path:
    """Create and return the configuration directory."""
    config_dir = Path.home() / ".config" / "mlstdb"
    if not config_dir.exists():
        config_dir.mkdir(parents=True, mode=0o700)
    return config_dir

def get_client_credentials(key_name: str) -> Tuple[str, str]:
    """Get OAuth client credentials from config file."""
    config = configparser.ConfigParser(interpolation=None)
    file_path = get_config_dir() / "client_credentials"
    
    if file_path.is_file():
        config.read(file_path)
        if config.has_section(key_name):
            return (config[key_name]["client_id"], 
                   config[key_name]["client_secret"])
    
    raise ValueError(f"Client credentials not found for {key_name}")

def remove_db_credentials(config_dir: Path, db: str) -> None:
    """Remove credentials for specific database while preserving others."""
    for file_name in ["client_credentials", "session_tokens", "access_tokens"]:
        file_path = config_dir / file_name
        if file_path.exists():
            config = configparser.ConfigParser(interpolation=None)
            config.read(file_path)
            if db in config:
                config. remove_section(db)
                with open(file_path, 'w') as f:
                    config.write(f)
                success(f"Removed {db} credentials from {file_name}")

def retrieve_session_token(key_name: str) -> Tuple[str, str]:
    """Get OAuth session token from config file."""
    config = configparser.ConfigParser(interpolation=None)
    file_path = get_config_dir() / "session_tokens"
    
    if file_path. is_file():
        config.read(file_path)
        if config.has_section(key_name):
            return (config[key_name]["token"], 
                   config[key_name]["secret"])
    
    return None, None

def test_connection(db: str, verbose: bool = False) -> bool:
    """Test if the connection to the database is valid. 
    
    Args:
        db: Database name ('pubmlst' or 'pasteur')
        verbose: If True, display JSON payload from test URI
        
    Returns:
        True if connection is valid, False otherwise
    """
    try:
        # Get client credentials
        client_id, client_secret = get_client_credentials(db)
        
        # Get session tokens
        session_token, session_secret = retrieve_session_token(db)
        
        if not session_token or not session_secret:
            return False
        
        # Test URL - using the database info endpoint
        test_url = f"{BASE_API[db]}/db/{DB_MAPPING[db]}/schemes"
        
        info(f"\nTesting connection to {db}...")
        info(f"Using test database:  {DB_MAPPING[db]}")
        info("\nPlease ensure you are registered to this database.")
        
        # Create OAuth session
        session = OAuth1Session(
            consumer_key=client_id,
            consumer_secret=client_secret,
            access_token=session_token,
            access_token_secret=session_secret,
        )
        session.headers.update({"User-Agent": f"mlstdb/{__version__}"})
        
        # Make test request
        if verbose:
            info(f"\nRequesting:  {test_url}")
        
        response = session.get(test_url)
        
        if verbose:
            info(f"\nResponse status code: {response.status_code}")
            if response.status_code == 200:
                try:
                    json_payload = response.json()
                    info("\nJSON payload received:")
                    import json as json_module
                    click.echo(json_module.dumps(json_payload, indent=2))
                except Exception as e:
                    error(f"Could not parse JSON response: {e}")
        
        if response.status_code == 200:
            return True
        elif response.status_code == 401:
            # Try to refresh the session token
            info("\nAttempting to refresh session token...")
            new_tokens = refresh_session_token(db, client_id, client_secret, verbose)
            if new_tokens:
                info("Session token refreshed. Testing connection again...")
                # Retry the test with new token
                session_token, session_secret = new_tokens
                session = OAuth1Session(
                    consumer_key=client_id,
                    consumer_secret=client_secret,
                    access_token=session_token,
                    access_token_secret=session_secret,
                )
                session.headers. update({"User-Agent": f"mlstdb/{__version__}"})
                response = session.get(test_url)
                
                if response. status_code == 200:
                    success("Connection successful after token refresh!")
                    return True
                else:
                    error(f"\nAuthentication failed after token refresh - status code: {response.status_code}")
                    return False
            else:
                error("\nAuthentication failed - session token may be invalid or expired")
                return False
        elif response.status_code == 403:
            error("\nAccess denied - you may not have permission to access this database")
            info(f"Please ensure you are registered to the '{DB_MAPPING[db]}' database")
            return False
        else:
            error(f"\nConnection test failed with status code: {response. status_code}")
            return False
            
    except ValueError as e:
        error(f"\n{e}")
        return False
    except Exception as e:
        error(f"\nConnection test failed: {e}")
        if verbose:
            import traceback
            error(traceback.format_exc())
        return False

def refresh_session_token(db:  str, client_key: str, client_secret: str, verbose: bool = False) -> Optional[Tuple[str, str]]: 
    """Refresh session token using existing access tokens. 
    
    Args:
        db: Database name ('pubmlst' or 'pasteur')
        client_key: OAuth client ID
        client_secret: OAuth client secret
        verbose: If True, display detailed information
        
    Returns: 
        Tuple of (new_token, new_secret) if successful, None otherwise
    """
    try:
        info("Invalid session token. Requesting new one...")
        
        # Get access tokens
        config = configparser.ConfigParser(interpolation=None)
        access_tokens_file = get_config_dir() / "access_tokens"
        
        if not access_tokens_file.exists():
            error("Access tokens file not found. Please re-register.")
            return None
        
        config.read(access_tokens_file)
        if not config.has_section(db):
            error(f"No access tokens found for {db}. Please re-register.")
            return None
            
        access_token = config[db]["token"]
        access_secret = config[db]["secret"]
        
        # Get new session token
        url_session = f"{BASE_API[db]}/db/{DB_MAPPING[db]}/oauth/get_session_token"
        session_request = OAuth1Session(
            client_key,
            client_secret,
            access_token=access_token,
            access_token_secret=access_secret,
        )
        session_request.headers.update({"User-Agent": f"mlstdb/{__version__}"})
        
        if verbose:
            info(f"Requesting new session token from:  {url_session}")
        
        r = session_request.get(url_session)
        
        if r.status_code == 200:
            new_token = r.json()["oauth_token"]
            new_secret = r.json()["oauth_token_secret"]
            
            # Save new session token
            config = configparser.ConfigParser(interpolation=None)
            session_tokens_file = get_config_dir() / "session_tokens"
            if session_tokens_file.exists():
                config.read(session_tokens_file)
            config[db] = {"token": new_token, "secret": new_secret}
            with open(session_tokens_file, "w") as configfile:
                config. write(configfile)
            
            if verbose:
                success("New session token obtained and saved")
            else:
                success("Session token refreshed successfully")
            
            return new_token, new_secret
        else:
            error(f"Failed to refresh session token: {r.status_code}")
            if verbose and r.text:
                error(f"Response: {r.text}")
            return None
            
    except Exception as e:
        error(f"Failed to refresh session token: {e}")
        if verbose:
            import traceback
            error(traceback.format_exc())
        return None