"""Tests for the stable public NeuroWeave API."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"

if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))


EXPECTED_API = {
    "BaseEncodingModel",
    "TRF",
    "BaseFeature",
    "FeaturePipeline",
    "FeatureRegistry",
    "FeatureSet",
    "DesignMatrix",
    "LagMetadata",
    "BaseEstimator",
    "RidgeEstimator",
    "CrossValidator",
    "EncodingCV",
    "EncodingResult",
    "plot_kernel",
    "plot_regularization_curve",
    "plot_temporal_generalisation",
    "plot_variance_partition",
}


def _load_public_modules() -> tuple[object, object]:
    """Import the package and API layer from the src layout."""

    original_sys_path = list(sys.path)
    sys.path[:] = [
        str(SRC),
        *[
            path
            for path in original_sys_path
            if path not in {"", str(ROOT), str(ROOT / "tests")}
        ],
    ]
    sys.modules.pop("neuroweave", None)
    sys.modules.pop("neuroweave.api", None)

    try:
        neuroweave = importlib.import_module("neuroweave")
        neuroweave_api = importlib.import_module("neuroweave.api")
    finally:
        sys.path[:] = original_sys_path

    return neuroweave, neuroweave_api


def test_public_api_exports_are_stable() -> None:
    """The top-level public API should remain centrally defined."""

    neuroweave, _ = _load_public_modules()
    exported = set(neuroweave.__all__)
    assert EXPECTED_API <= exported


def test_api_layer_matches_top_level_exports() -> None:
    """The compatibility API layer should mirror stable entry points."""

    neuroweave, neuroweave_api = _load_public_modules()
    for name in EXPECTED_API:
        assert hasattr(neuroweave, name)
        assert hasattr(neuroweave_api, name)
