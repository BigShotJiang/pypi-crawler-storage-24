"""Design utilities for NeuroWeave."""
