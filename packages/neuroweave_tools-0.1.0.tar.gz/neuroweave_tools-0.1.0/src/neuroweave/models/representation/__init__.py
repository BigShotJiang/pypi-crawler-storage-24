"""Representation model modules."""
