"""Connectivity model modules."""
