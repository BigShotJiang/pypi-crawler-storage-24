"""Placeholder module for Granger-style TRF models."""
