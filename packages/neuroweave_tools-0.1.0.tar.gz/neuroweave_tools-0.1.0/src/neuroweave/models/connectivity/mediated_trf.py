"""Placeholder module for mediated TRF models."""
