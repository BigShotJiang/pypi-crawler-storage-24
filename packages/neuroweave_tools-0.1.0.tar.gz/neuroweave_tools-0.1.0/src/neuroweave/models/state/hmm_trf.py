"""Placeholder module for HMM-based TRF models."""
