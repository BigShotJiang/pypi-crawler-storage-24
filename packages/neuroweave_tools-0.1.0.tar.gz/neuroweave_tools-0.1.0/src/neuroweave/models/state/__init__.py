"""State-dependent model modules."""
