"""Placeholder module for switching TRF models."""
