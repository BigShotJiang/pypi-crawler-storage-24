"""Placeholder module for multivariate TRF models."""
