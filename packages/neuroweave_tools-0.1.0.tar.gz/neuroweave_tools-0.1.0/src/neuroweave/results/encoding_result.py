"""Stable result facade."""

from neuroweave.core.result import EncodingResult

__all__ = ["EncodingResult"]
