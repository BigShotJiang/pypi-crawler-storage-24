"""Stable result entry points for NeuroWeave."""

from .encoding_result import EncodingResult

__all__ = ["EncodingResult"]
