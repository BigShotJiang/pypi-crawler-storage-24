"""Evaluation utilities for NeuroWeave."""
