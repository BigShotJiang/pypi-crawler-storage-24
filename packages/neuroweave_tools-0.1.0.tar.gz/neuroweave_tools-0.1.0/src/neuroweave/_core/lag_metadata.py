"""Private alias for lag metadata."""

from neuroweave.design.lag_metadata import LagMetadata

__all__ = ["LagMetadata"]
