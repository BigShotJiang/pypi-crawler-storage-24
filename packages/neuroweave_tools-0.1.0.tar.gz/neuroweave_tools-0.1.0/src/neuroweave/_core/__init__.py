"""Private implementation aliases for core NeuroWeave objects."""

from .base_estimator import BaseEstimator
from .base_model import BaseEncodingModel
from .cross_validator import CrossValidator
from .design_matrix import DesignMatrix
from .lag_metadata import LagMetadata
from .result import EncodingResult

__all__ = [
    "BaseEncodingModel",
    "BaseEstimator",
    "CrossValidator",
    "DesignMatrix",
    "LagMetadata",
    "EncodingResult",
]
