"""Private alias for the core base model."""

from neuroweave.core.base_model import BaseEncodingModel

__all__ = ["BaseEncodingModel"]
