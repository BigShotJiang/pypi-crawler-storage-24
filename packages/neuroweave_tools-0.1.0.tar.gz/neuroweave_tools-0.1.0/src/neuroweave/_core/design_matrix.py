"""Private alias for the design matrix container."""

from neuroweave.design.design_matrix import DesignMatrix

__all__ = ["DesignMatrix"]
