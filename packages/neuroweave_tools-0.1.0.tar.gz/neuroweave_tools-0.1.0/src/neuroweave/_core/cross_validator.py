"""Private alias for the core cross-validator."""

from neuroweave.core.cross_validator import CrossValidator

__all__ = ["CrossValidator"]
