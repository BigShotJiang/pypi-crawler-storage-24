"""Private alias for the core base estimator."""

from neuroweave.core.base_estimator import BaseEstimator

__all__ = ["BaseEstimator"]
