"""Private alias for the core result object."""

from neuroweave.core.result import EncodingResult

__all__ = ["EncodingResult"]
