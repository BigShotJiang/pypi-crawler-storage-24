"""Exporter interfaces for NeuroWeave reports."""

from __future__ import annotations

from .report import AnalysisReport


def export_markdown(report: AnalysisReport, path: str) -> None:
    """Export a report as Markdown.

    Parameters
    ----------
    report : AnalysisReport
        Report object to export.
    path : str
        Destination path for Markdown output.
    """

    raise NotImplementedError()


def export_html(report: AnalysisReport, path: str) -> None:
    """Export a report as HTML.

    Parameters
    ----------
    report : AnalysisReport
        Report object to export.
    path : str
        Destination path for HTML output.
    """

    raise NotImplementedError()


def export_figures(report: AnalysisReport, path: str) -> None:
    """Export report figures to disk.

    Parameters
    ----------
    report : AnalysisReport
        Report object providing figure assets.
    path : str
        Destination path for exported figure files.
    """

    raise NotImplementedError()
