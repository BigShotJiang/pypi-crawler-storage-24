"""Structured report objects for NeuroWeave analyses."""

from __future__ import annotations

from typing import Any

from neuroweave.analysis.analysis_result import AnalysisResult


class AnalysisReport:
    """Aggregate analysis outputs into a structured report.

    Parameters
    ----------
    analysis_result : AnalysisResult
        Analysis result object consumed by the report.
    """

    def __init__(self, analysis_result: AnalysisResult) -> None:
        self.analysis_result = analysis_result
        self.figures: list[Any] = []
        self.tables: list[Any] = []
        self.metadata: dict[str, Any] = {}

    def build(self) -> None:
        """Build report components from the analysis result."""

        raise NotImplementedError()

    def summary(self) -> str:
        """Summarize report contents.

        Returns
        -------
        str
            Human-readable report summary.
        """

        raise NotImplementedError()

    def generate_figures(self) -> list[Any]:
        """Generate figure objects from stored analysis results.

        Returns
        -------
        list[Any]
            Report figure objects.
        """

        raise NotImplementedError()

    def generate_tables(self) -> list[Any]:
        """Generate table objects from stored analysis results.

        Returns
        -------
        list[Any]
            Report table objects.
        """

        raise NotImplementedError()

    def export(self, path: str) -> None:
        """Export the report to disk.

        Parameters
        ----------
        path : str
            Destination path for exported report assets.
        """

        raise NotImplementedError()
