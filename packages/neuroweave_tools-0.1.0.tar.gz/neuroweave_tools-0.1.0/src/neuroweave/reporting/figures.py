"""Figure-building interfaces for NeuroWeave reports."""

from __future__ import annotations

from neuroweave.core.result import EncodingResult
from neuroweave.model_selection.results import (
    ModelComparisonResult,
    VariancePartitionResult,
)
from neuroweave.stats.results import KernelStatsResult


def kernel_plot(result: EncodingResult) -> object:
    """Create a kernel figure from an encoding result.

    Parameters
    ----------
    result : EncodingResult
        Encoding-model result containing kernel estimates.

    Returns
    -------
    object
        Figure object representing encoding kernels.
    """

    raise NotImplementedError()


def model_comparison_plot(result: ModelComparisonResult) -> object:
    """Create a model-comparison figure.

    Parameters
    ----------
    result : ModelComparisonResult
        Result object describing model comparison outcomes.

    Returns
    -------
    object
        Figure object summarizing model scores.
    """

    raise NotImplementedError()


def variance_partition_plot(result: VariancePartitionResult) -> object:
    """Create a variance-partition figure.

    Parameters
    ----------
    result : VariancePartitionResult
        Result object describing variance decomposition.

    Returns
    -------
    object
        Figure object summarizing unique and shared variance.
    """

    raise NotImplementedError()


def lag_statistics_plot(result: KernelStatsResult) -> object:
    """Create a lag-resolved statistics figure.

    Parameters
    ----------
    result : KernelStatsResult
        Result object describing kernel-level statistics.

    Returns
    -------
    object
        Figure object representing lag-resolved statistics.
    """

    raise NotImplementedError()
