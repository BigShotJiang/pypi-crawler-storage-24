"""Public reporting API for NeuroWeave."""

from .exporters import (
    export_figures,
    export_html,
    export_markdown,
)
from .figures import (
    kernel_plot,
    lag_statistics_plot,
    model_comparison_plot,
    variance_partition_plot,
)
from .report import AnalysisReport
from .tables import (
    kernel_statistics_table,
    model_comparison_table,
    variance_partition_table,
)

__all__ = [
    "AnalysisReport",
    "kernel_plot",
    "model_comparison_plot",
    "variance_partition_plot",
    "lag_statistics_plot",
    "model_comparison_table",
    "variance_partition_table",
    "kernel_statistics_table",
    "export_markdown",
    "export_html",
    "export_figures",
]
