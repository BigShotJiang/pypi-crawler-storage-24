"""Table-building interfaces for NeuroWeave reports."""

from __future__ import annotations

from neuroweave.model_selection.results import (
    ModelComparisonResult,
    VariancePartitionResult,
)
from neuroweave.stats.results import KernelStatsResult


def model_comparison_table(result: ModelComparisonResult) -> object:
    """Create a table summarizing model comparison scores.

    Parameters
    ----------
    result : ModelComparisonResult
        Result object describing model comparison outcomes.

    Returns
    -------
    object
        Table representation of model comparison scores.
    """

    raise NotImplementedError()


def variance_partition_table(result: VariancePartitionResult) -> object:
    """Create a table summarizing variance decomposition.

    Parameters
    ----------
    result : VariancePartitionResult
        Result object describing variance decomposition.

    Returns
    -------
    object
        Table representation of variance partitioning outputs.
    """

    raise NotImplementedError()


def kernel_statistics_table(result: KernelStatsResult) -> object:
    """Create a table summarizing kernel statistics.

    Parameters
    ----------
    result : KernelStatsResult
        Result object describing kernel-level statistics.

    Returns
    -------
    object
        Table representation of kernel statistics.
    """

    raise NotImplementedError()
