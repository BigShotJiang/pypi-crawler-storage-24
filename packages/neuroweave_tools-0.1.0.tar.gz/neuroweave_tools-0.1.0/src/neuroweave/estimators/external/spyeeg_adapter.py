"""Placeholder module for SpyEEG adapters."""
