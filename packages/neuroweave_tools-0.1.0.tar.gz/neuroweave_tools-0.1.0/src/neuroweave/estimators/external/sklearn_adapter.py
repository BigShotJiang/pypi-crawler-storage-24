"""Placeholder module for scikit-learn adapters."""
