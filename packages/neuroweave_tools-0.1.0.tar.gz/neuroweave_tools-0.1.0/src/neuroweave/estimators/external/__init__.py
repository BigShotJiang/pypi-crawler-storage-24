"""External estimator adapter modules."""
