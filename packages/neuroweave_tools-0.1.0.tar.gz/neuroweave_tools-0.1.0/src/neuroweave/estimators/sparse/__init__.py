"""Sparse estimator modules."""
