"""Placeholder module for elastic net estimators."""
