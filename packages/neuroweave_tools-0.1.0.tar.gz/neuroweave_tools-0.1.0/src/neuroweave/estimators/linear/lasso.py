"""Placeholder module for lasso estimators."""
