"""Linear estimator modules."""
