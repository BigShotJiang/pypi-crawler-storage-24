"""Bayesian estimator modules."""
