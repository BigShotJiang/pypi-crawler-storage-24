"""Placeholder module for Bayesian ridge estimators."""
