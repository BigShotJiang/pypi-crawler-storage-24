"""Placeholder module for estimator interfaces."""
