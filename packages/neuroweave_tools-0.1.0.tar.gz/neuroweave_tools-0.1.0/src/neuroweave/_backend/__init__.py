"""Private backend aliases for NeuroWeave."""

BACKEND_REGISTRY = {
    "jax": "neuroweave.backends.jax",
    "sklearn": "neuroweave.backends.sklearn",
    "spyeeg": "neuroweave.backends.spyeeg",
    "torch": "neuroweave.backends.torch",
}

__all__ = ["BACKEND_REGISTRY"]
