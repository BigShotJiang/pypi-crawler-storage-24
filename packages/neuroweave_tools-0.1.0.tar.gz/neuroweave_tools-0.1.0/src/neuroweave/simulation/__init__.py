"""Public simulation entry points for NeuroWeave."""

from neuroweave.simulation.stimulus.gaussian import generate_gaussian_stimulus
from neuroweave.simulation.system.trf_system import (
    generate_gaussian_kernel,
    simulate_trf_response,
)

__all__ = [
    "generate_gaussian_stimulus",
    "generate_gaussian_kernel",
    "simulate_trf_response",
]
