"""Stimulus simulation modules."""
