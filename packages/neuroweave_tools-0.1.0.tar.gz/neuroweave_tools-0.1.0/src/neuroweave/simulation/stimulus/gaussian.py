"""Gaussian stimulus generation utilities."""

from __future__ import annotations

import numpy as np


def generate_gaussian_stimulus(
    n_samples: int,
    n_features: int,
    random_state: int = 0,
) -> np.ndarray:
    """Generate a Gaussian stimulus matrix.

    Parameters
    ----------
    n_samples : int
        Number of time samples.
    n_features : int
        Number of stimulus features.
    random_state : int, optional
        Seed used to initialize the random number generator.

    Returns
    -------
    np.ndarray
        Gaussian stimulus matrix with shape ``(n_samples, n_features)``.
    """

    rng = np.random.RandomState(random_state)
    return rng.standard_normal((n_samples, n_features))
