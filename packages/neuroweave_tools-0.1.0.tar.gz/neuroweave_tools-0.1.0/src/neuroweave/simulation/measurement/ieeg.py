"""Placeholder module for iEEG measurement simulation."""
