"""Public statistical API for NeuroWeave."""

from .cluster_tests import cluster_permutation_test
from .kernel_stats import kernel_statistics
from .lagwise import lagwise_statistics
from .permutation import permutation_test
from .results import (
    ClusterTestResult,
    KernelStatsResult,
    LagwiseStatsResult,
    PermutationTestResult,
)

__all__ = [
    "kernel_statistics",
    "permutation_test",
    "cluster_permutation_test",
    "lagwise_statistics",
    "KernelStatsResult",
    "PermutationTestResult",
    "ClusterTestResult",
    "LagwiseStatsResult",
]
