"""Public API for kernel-level statistics."""

from __future__ import annotations

from neuroweave.core.result import EncodingResult

from .results import KernelStatsResult


def kernel_statistics(
    results: list[EncodingResult],
    method: str = "t",
) -> KernelStatsResult:
    """Compute group-level statistics on encoding kernels.

    Parameters
    ----------
    results : list[EncodingResult]
        Encoding-model results contributing subject- or run-level kernels.
    method : str, optional
        Statistical method identifier.

    Returns
    -------
    KernelStatsResult
        Result object describing kernel statistics and associated metadata.
    """

    raise NotImplementedError()
