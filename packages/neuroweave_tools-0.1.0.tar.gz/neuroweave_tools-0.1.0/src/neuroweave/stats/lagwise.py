"""Public API for lag-resolved statistical inference."""

from __future__ import annotations

from neuroweave.core.result import EncodingResult

from .results import LagwiseStatsResult


def lagwise_statistics(
    results: list[EncodingResult],
    metric: str = "kernel",
) -> LagwiseStatsResult:
    """Compute statistics resolved across lags.

    Parameters
    ----------
    results : list[EncodingResult]
        Encoding-model results contributing lag-resolved quantities.
    metric : str, optional
        Result attribute or metric identifier to analyze across lags.

    Returns
    -------
    LagwiseStatsResult
        Result object describing lag-wise statistics and p-values.
    """

    raise NotImplementedError()
