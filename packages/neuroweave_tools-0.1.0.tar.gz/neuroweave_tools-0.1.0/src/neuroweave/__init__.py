"""Public NeuroWeave API."""

from neuroweave._public_api import PUBLIC_API
from neuroweave.design.design_matrix import DesignMatrix
from neuroweave.design.lag_metadata import LagMetadata
from neuroweave.estimators import BaseEstimator, RidgeEstimator
from neuroweave.features import BaseFeature, FeaturePipeline, FeatureRegistry, FeatureSet
from neuroweave.models import BaseEncodingModel, TRF
from neuroweave.results import EncodingResult
from neuroweave.validation import CrossValidator, EncodingCV
from neuroweave.visualization import (
    plot_kernel,
    plot_regularization_curve,
    plot_temporal_generalisation,
    plot_variance_partition,
)

__all__ = PUBLIC_API
