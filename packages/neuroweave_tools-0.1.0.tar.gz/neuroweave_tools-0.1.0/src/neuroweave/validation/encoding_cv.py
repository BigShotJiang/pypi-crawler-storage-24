"""Stable validation facades."""

from neuroweave.core.cross_validator import CrossValidator


class EncodingCV(CrossValidator):
    """Stable facade for encoding-model cross-validation workflows."""


__all__ = ["EncodingCV"]
