"""Configuration objects for NeuroWeave analyses."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from neuroweave.core.cross_validator import CrossValidator
from neuroweave.data.dataset import Dataset
from neuroweave.model_spec.model_spec import ModelSpec
from neuroweave.models import BaseEncodingModel


@dataclass
class AnalysisConfig:
    """Configuration for an encoding analysis workflow.

    Parameters
    ----------
    dataset : Dataset
        Dataset containing neural data and stimulus features.
    model : BaseEncodingModel
        Encoding model used for the analysis.
    spec : ModelSpec
        Model specification defining predictors and lag structure.
    cross_validator : CrossValidator | None, optional
        Cross-validation strategy for evaluation workflows.
    scoring : str | None, optional
        Name of the scoring metric to use.
    random_state : int | None, optional
        Random seed associated with stochastic analysis components.
    """

    dataset: Dataset
    model: BaseEncodingModel
    spec: ModelSpec
    cross_validator: CrossValidator | None = None
    scoring: str | None = None
    random_state: int | None = None

    def validate(self) -> None:
        """Validate configuration consistency.

        Raises
        ------
        NotImplementedError
            Always raised until validation logic is implemented.
        """

        raise NotImplementedError()

    def summary(self) -> str:
        """Summarize the analysis configuration.

        Returns
        -------
        str
            Human-readable configuration summary.
        """

        raise NotImplementedError()
