"""Result objects for NeuroWeave analyses."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from neuroweave.core.result import EncodingResult
from neuroweave.model_selection.results import (
    AblationResult,
    ModelComparisonResult,
    VariancePartitionResult,
)
from neuroweave.stats.results import (
    ClusterTestResult,
    KernelStatsResult,
)

from .analysis_config import AnalysisConfig

CVResult = Any


@dataclass
class AnalysisResult:
    """Container for outputs produced by an encoding analysis.

    Parameters
    ----------
    config : AnalysisConfig
        Configuration used to define the analysis.
    encoding_result : EncodingResult | None, optional
        Result of the main encoding-model fit.
    cv_result : CVResult | None, optional
        Result of cross-validated fitting.
    comparison : ModelComparisonResult | None, optional
        Result of model comparison analyses.
    variance_partition : VariancePartitionResult | None, optional
        Result of variance partitioning.
    ablation : AblationResult | None, optional
        Result of feature ablation.
    statistics : KernelStatsResult | ClusterTestResult | None, optional
        Statistical inference result associated with the analysis.
    """

    config: AnalysisConfig
    encoding_result: EncodingResult | None = None
    cv_result: CVResult | None = None
    comparison: ModelComparisonResult | None = None
    variance_partition: VariancePartitionResult | None = None
    ablation: AblationResult | None = None
    statistics: KernelStatsResult | ClusterTestResult | None = None

    def summary(self) -> str:
        """Summarize stored analysis outputs.

        Returns
        -------
        str
            Human-readable analysis summary.
        """

        raise NotImplementedError()

    def save(self, path: str) -> None:
        """Save an analysis result.

        Parameters
        ----------
        path : str
            Target path for serialized analysis output.
        """

        raise NotImplementedError()

    @classmethod
    def load(cls, path: str) -> AnalysisResult:
        """Load an analysis result from disk.

        Parameters
        ----------
        path : str
            Source path for serialized analysis output.

        Returns
        -------
        AnalysisResult
            Loaded analysis result object.
        """

        raise NotImplementedError()

    def plot(self) -> None:
        """Plot stored analysis outputs."""

        raise NotImplementedError()
