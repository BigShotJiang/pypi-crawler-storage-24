"""Cross-validation step interface for encoding analyses."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .base_step import AnalysisStep

if TYPE_CHECKING:
    from neuroweave.analysis.encoding_analysis import EncodingAnalysis


class CrossValidate(AnalysisStep):
    """Analysis step for cross-validated fitting."""

    requires = ["config"]
    produces = ["cv_result"]

    def run(self, analysis: EncodingAnalysis) -> object:
        """Run the cross-validation step.

        Parameters
        ----------
        analysis : EncodingAnalysis
            Analysis object coordinating the workflow.

        Returns
        -------
        object
            Cross-validation result for the analysis.
        """

        raise NotImplementedError()
