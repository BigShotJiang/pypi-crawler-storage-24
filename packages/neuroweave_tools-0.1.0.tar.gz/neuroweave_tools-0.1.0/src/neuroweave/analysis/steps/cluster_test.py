"""Cluster-test step interface for encoding analyses."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .base_step import AnalysisStep

if TYPE_CHECKING:
    from neuroweave.analysis.encoding_analysis import EncodingAnalysis


class ClusterTest(AnalysisStep):
    """Analysis step for cluster-based statistical inference."""

    requires = ["statistics"]
    produces = ["cluster_test"]

    def run(self, analysis: EncodingAnalysis) -> object:
        """Run the cluster-test step.

        Parameters
        ----------
        analysis : EncodingAnalysis
            Analysis object coordinating the workflow.

        Returns
        -------
        object
            Cluster-based inference result for the analysis.
        """

        raise NotImplementedError()
