"""Fit step interface for encoding analyses."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .base_step import AnalysisStep

if TYPE_CHECKING:
    from neuroweave.analysis.encoding_analysis import EncodingAnalysis


class Fit(AnalysisStep):
    """Analysis step for model fitting."""

    requires = ["config"]
    produces = ["encoding_result"]

    def run(self, analysis: EncodingAnalysis) -> object:
        """Run the model-fitting step.

        Parameters
        ----------
        analysis : EncodingAnalysis
            Analysis object coordinating the workflow.

        Returns
        -------
        object
            Encoding-analysis fit result.
        """

        raise NotImplementedError()
