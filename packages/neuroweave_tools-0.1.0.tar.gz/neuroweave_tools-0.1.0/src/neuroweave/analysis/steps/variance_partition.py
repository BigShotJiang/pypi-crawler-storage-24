"""Variance-partition step interface for encoding analyses."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .base_step import AnalysisStep

if TYPE_CHECKING:
    from neuroweave.analysis.encoding_analysis import EncodingAnalysis


class VariancePartition(AnalysisStep):
    """Analysis step for feature-group variance partitioning."""

    requires = ["config"]
    produces = ["variance_partition"]

    def run(self, analysis: EncodingAnalysis) -> object:
        """Run the variance-partition step.

        Parameters
        ----------
        analysis : EncodingAnalysis
            Analysis object coordinating the workflow.

        Returns
        -------
        object
            Variance partitioning result for the analysis.
        """

        raise NotImplementedError()
