"""Kernel-statistics step interface for encoding analyses."""

from __future__ import annotations

from typing import TYPE_CHECKING

from .base_step import AnalysisStep

if TYPE_CHECKING:
    from neuroweave.analysis.encoding_analysis import EncodingAnalysis


class KernelStatistics(AnalysisStep):
    """Analysis step for kernel-level statistical inference."""

    requires = ["encoding_result"]
    produces = ["statistics"]

    def run(self, analysis: EncodingAnalysis) -> object:
        """Run the kernel-statistics step.

        Parameters
        ----------
        analysis : EncodingAnalysis
            Analysis object coordinating the workflow.

        Returns
        -------
        object
            Kernel statistics result for the analysis.
        """

        raise NotImplementedError()
