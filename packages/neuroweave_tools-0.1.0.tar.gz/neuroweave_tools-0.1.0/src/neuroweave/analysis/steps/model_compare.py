"""Model-comparison step interface for encoding analyses."""

from __future__ import annotations

from typing import TYPE_CHECKING

from neuroweave.model_spec.model_spec import ModelSpec

from .base_step import AnalysisStep

if TYPE_CHECKING:
    from neuroweave.analysis.encoding_analysis import EncodingAnalysis


class ModelCompare(AnalysisStep):
    """Analysis step for comparing alternative model specifications.

    Parameters
    ----------
    specs : list[ModelSpec]
        Alternative specifications to compare.
    name : str | None, optional
        Human-readable step name.
    """

    requires = ["config"]
    produces = ["comparison"]

    def __init__(self, specs: list[ModelSpec], name: str | None = None) -> None:
        super().__init__(name=name)
        self.specs = specs

    def run(self, analysis: EncodingAnalysis) -> object:
        """Run the model-comparison step.

        Parameters
        ----------
        analysis : EncodingAnalysis
            Analysis object coordinating the workflow.

        Returns
        -------
        object
            Model-comparison result for the provided specifications.
        """

        raise NotImplementedError()
