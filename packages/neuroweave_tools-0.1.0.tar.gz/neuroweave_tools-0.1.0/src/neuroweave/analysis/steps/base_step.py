"""Base classes for analysis steps."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from neuroweave.analysis.encoding_analysis import EncodingAnalysis


class AnalysisStep:
    """Base class for a single encoding-analysis step.

    Parameters
    ----------
    name : str | None, optional
        Human-readable step name.
    """

    requires: list[str] = []
    produces: list[str] = []

    def __init__(self, name: str | None = None) -> None:
        self.name = name or self.__class__.__name__.lower()

    def run(self, analysis: EncodingAnalysis) -> object:
        """Execute the step within an encoding analysis.

        Parameters
        ----------
        analysis : EncodingAnalysis
            Analysis object coordinating the workflow.

        Returns
        -------
        object
            Step-specific analysis output.
        """

        raise NotImplementedError()
