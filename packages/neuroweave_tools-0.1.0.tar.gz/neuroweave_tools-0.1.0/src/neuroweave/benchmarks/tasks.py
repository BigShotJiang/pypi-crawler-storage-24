"""Benchmark task definitions for NeuroWeave."""

from __future__ import annotations

from .benchmark import Benchmark
from .results import BenchmarkResult


class ModelRecoveryBenchmark(Benchmark):
    """Benchmark for recovering ground-truth model kernels."""

    def run(self) -> BenchmarkResult:
        """Execute the model-recovery benchmark.

        Returns
        -------
        BenchmarkResult
            Result object describing recovery performance.
        """

        raise NotImplementedError()

    def evaluate(self) -> object:
        """Evaluate model-recovery benchmark outputs."""

        raise NotImplementedError()

    def summary(self) -> str:
        """Summarize the model-recovery benchmark."""

        raise NotImplementedError()


class NoiseRobustnessBenchmark(Benchmark):
    """Benchmark for model performance across noise levels."""

    def run(self) -> BenchmarkResult:
        """Execute the noise-robustness benchmark.

        Returns
        -------
        BenchmarkResult
            Result object describing robustness across noise levels.
        """

        raise NotImplementedError()

    def evaluate(self) -> object:
        """Evaluate noise-robustness benchmark outputs."""

        raise NotImplementedError()

    def summary(self) -> str:
        """Summarize the noise-robustness benchmark."""

        raise NotImplementedError()


class FeatureIdentifiabilityBenchmark(Benchmark):
    """Benchmark for feature-space identifiability."""

    def run(self) -> BenchmarkResult:
        """Execute the feature-identifiability benchmark.

        Returns
        -------
        BenchmarkResult
            Result object describing feature-space recovery.
        """

        raise NotImplementedError()

    def evaluate(self) -> object:
        """Evaluate feature-identifiability benchmark outputs."""

        raise NotImplementedError()

    def summary(self) -> str:
        """Summarize the feature-identifiability benchmark."""

        raise NotImplementedError()


class LagRecoveryBenchmark(Benchmark):
    """Benchmark for recovery of ground-truth lag structure."""

    def run(self) -> BenchmarkResult:
        """Execute the lag-recovery benchmark.

        Returns
        -------
        BenchmarkResult
            Result object describing lag recovery performance.
        """

        raise NotImplementedError()

    def evaluate(self) -> object:
        """Evaluate lag-recovery benchmark outputs."""

        raise NotImplementedError()

    def summary(self) -> str:
        """Summarize the lag-recovery benchmark."""

        raise NotImplementedError()
