"""Base benchmark interfaces for NeuroWeave."""

from __future__ import annotations

from neuroweave.data.dataset import Dataset
from neuroweave.model_spec.model_spec import ModelSpec
from neuroweave.models import BaseEncodingModel

from .results import BenchmarkResult


class Benchmark:
    """Represent a single benchmark experiment.

    Parameters
    ----------
    name : str
        Human-readable benchmark name.
    dataset : Dataset
        Dataset used for the benchmark experiment.
    specs : list[ModelSpec]
        Model specifications evaluated in the benchmark.
    models : list[BaseEncodingModel]
        Encoding models evaluated in the benchmark.
    """

    def __init__(
        self,
        name: str,
        dataset: Dataset,
        specs: list[ModelSpec],
        models: list[BaseEncodingModel],
    ) -> None:
        self.name = name
        self.dataset = dataset
        self.specs = specs
        self.models = models

    def run(self) -> BenchmarkResult:
        """Execute the benchmark experiment.

        Returns
        -------
        BenchmarkResult
            Result object describing benchmark outcomes.
        """

        raise NotImplementedError()

    def evaluate(self) -> object:
        """Evaluate benchmark outputs with benchmark-specific metrics.

        Returns
        -------
        object
            Benchmark evaluation payload.
        """

        raise NotImplementedError()

    def summary(self) -> str:
        """Summarize the benchmark configuration or outcomes.

        Returns
        -------
        str
            Human-readable benchmark summary.
        """

        raise NotImplementedError()
