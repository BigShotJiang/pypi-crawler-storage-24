"""Benchmark suite interfaces for NeuroWeave."""

from __future__ import annotations

from .benchmark import Benchmark
from .results import BenchmarkSuiteResult


class BenchmarkSuite:
    """Group multiple benchmarks into a reproducible experiment suite.

    Parameters
    ----------
    benchmarks : list[Benchmark]
        Benchmarks included in the suite.
    """

    def __init__(self, benchmarks: list[Benchmark]) -> None:
        self.benchmarks = benchmarks

    def run(self) -> BenchmarkSuiteResult:
        """Execute all benchmarks in the suite.

        Returns
        -------
        BenchmarkSuiteResult
            Aggregated result object for the benchmark suite.
        """

        raise NotImplementedError()

    def summary(self) -> str:
        """Summarize the benchmark suite.

        Returns
        -------
        str
            Human-readable suite summary.
        """

        raise NotImplementedError()

    def export(self, path: str) -> None:
        """Export benchmark suite outputs.

        Parameters
        ----------
        path : str
            Destination path for exported benchmark outputs.
        """

        raise NotImplementedError()
