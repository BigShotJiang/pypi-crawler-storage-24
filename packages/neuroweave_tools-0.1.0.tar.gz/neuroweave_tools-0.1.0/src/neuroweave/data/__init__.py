"""Data containers for NeuroWeave."""

from .dataset import Dataset

__all__ = ["Dataset"]
