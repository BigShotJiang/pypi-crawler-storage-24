"""Stable plotting helpers for NeuroWeave results."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from neuroweave.results import EncodingResult
else:
    EncodingResult = Any


def plot_kernel(result: EncodingResult) -> Any:
    """Plot an encoding kernel.

    Parameters
    ----------
    result : EncodingResult
        Result object produced by the public API.

    Returns
    -------
    Any
        Backend-specific plotting handle.
    """

    raise NotImplementedError()


def plot_regularization_curve(result: EncodingResult) -> Any:
    """Plot a regularization curve.

    Parameters
    ----------
    result : EncodingResult
        Result object produced by the public API.

    Returns
    -------
    Any
        Backend-specific plotting handle.
    """

    raise NotImplementedError()


def plot_temporal_generalisation(result: EncodingResult) -> Any:
    """Plot temporal generalisation outputs.

    Parameters
    ----------
    result : EncodingResult
        Result object produced by the public API.

    Returns
    -------
    Any
        Backend-specific plotting handle.
    """

    raise NotImplementedError()


def plot_variance_partition(result: EncodingResult) -> Any:
    """Plot variance partition results.

    Parameters
    ----------
    result : EncodingResult
        Result object produced by the public API.

    Returns
    -------
    Any
        Backend-specific plotting handle.
    """

    raise NotImplementedError()


__all__ = [
    "plot_kernel",
    "plot_regularization_curve",
    "plot_temporal_generalisation",
    "plot_variance_partition",
]
