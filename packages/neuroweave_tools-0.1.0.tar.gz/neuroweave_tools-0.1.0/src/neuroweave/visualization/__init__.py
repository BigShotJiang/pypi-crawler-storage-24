"""Stable visualization entry points for NeuroWeave."""

from .plotting import (
    plot_kernel,
    plot_regularization_curve,
    plot_temporal_generalisation,
    plot_variance_partition,
)

__all__ = [
    "plot_kernel",
    "plot_regularization_curve",
    "plot_temporal_generalisation",
    "plot_variance_partition",
]
