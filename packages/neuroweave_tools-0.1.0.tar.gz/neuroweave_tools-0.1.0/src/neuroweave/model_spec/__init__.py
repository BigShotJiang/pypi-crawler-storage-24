"""Declarative model specifications for NeuroWeave."""

from .model_spec import ModelSpec

__all__ = ["ModelSpec"]
