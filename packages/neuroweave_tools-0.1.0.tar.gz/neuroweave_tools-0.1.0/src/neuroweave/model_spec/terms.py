"""Predictor term definitions for declarative model specifications."""

from __future__ import annotations

import numpy as np

from neuroweave.data.dataset import Dataset


class FeatureTerm:
    """Representation of a single dataset feature predictor.

    Parameters
    ----------
    name : str
        Feature name in ``dataset.features``.
    """

    def __init__(self, name: str) -> None:
        self.name = name

    def apply(self, dataset: Dataset) -> np.ndarray:
        """Extract the named feature from a dataset."""

        return np.asarray(dataset.get_feature(self.name), dtype=float).reshape(-1)


class InteractionTerm:
    """Representation of a multiplicative interaction between two features.

    Parameters
    ----------
    left : str
        Left feature name.
    right : str
        Right feature name.
    """

    def __init__(self, left: str, right: str) -> None:
        self.left = left
        self.right = right

    @property
    def name(self) -> str:
        """Display name for the interaction term."""

        return f"{self.left} × {self.right}"

    def apply(self, dataset: Dataset) -> np.ndarray:
        """Compute the multiplicative interaction from a dataset."""

        left_feature = np.asarray(dataset.get_feature(self.left), dtype=float).reshape(-1)
        right_feature = np.asarray(dataset.get_feature(self.right), dtype=float).reshape(-1)
        return left_feature * right_feature
