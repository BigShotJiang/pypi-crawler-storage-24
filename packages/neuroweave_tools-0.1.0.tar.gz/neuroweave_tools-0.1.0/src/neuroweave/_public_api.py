"""Registry of the stable public NeuroWeave API."""

PUBLIC_API = [
    "BaseEncodingModel",
    "TRF",
    "BaseFeature",
    "FeaturePipeline",
    "FeatureRegistry",
    "FeatureSet",
    "DesignMatrix",
    "LagMetadata",
    "BaseEstimator",
    "RidgeEstimator",
    "CrossValidator",
    "EncodingCV",
    "EncodingResult",
    "plot_kernel",
    "plot_regularization_curve",
    "plot_temporal_generalisation",
    "plot_variance_partition",
]

STABLE_MODULES = [
    "neuroweave.models",
    "neuroweave.features",
    "neuroweave.estimators",
    "neuroweave.validation",
    "neuroweave.results",
    "neuroweave.visualization",
]
