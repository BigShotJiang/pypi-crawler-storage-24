"""SpyEEG backend package."""
