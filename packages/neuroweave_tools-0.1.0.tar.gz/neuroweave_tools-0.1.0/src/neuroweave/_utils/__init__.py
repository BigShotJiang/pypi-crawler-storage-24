"""Private utilities for NeuroWeave internals."""

from .deprecation import deprecated

__all__ = ["deprecated"]
