"""Feature-space registry interfaces for NeuroWeave."""

from __future__ import annotations

from .feature_space import FeatureSpace


FEATURE_SPACES = {
    "acoustic": [
        "envelope",
        "pitch",
        "spectral_centroid",
    ],
    "linguistic": [
        "word_onset",
        "pos_tag",
        "dependency_distance",
    ],
}


def get_feature_space(name: str) -> FeatureSpace:
    """Construct a feature space from the canonical registry.

    Parameters
    ----------
    name : str
        Name of the registered feature space.

    Returns
    -------
    FeatureSpace
        Feature-space object constructed from the registry entry.
    """

    raise NotImplementedError()
