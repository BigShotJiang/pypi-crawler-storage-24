"""Registries for NeuroWeave components."""

from __future__ import annotations

from typing import Any


class ModelRegistry:
    """Registry for NeuroWeave encoding models.

    The registry provides a simple indirection layer for dynamic model
    creation, plugin discovery, and command-line integrations.
    """

    _registry: dict[str, type[Any]] = {}

    @classmethod
    def register_model(cls, name: str, model_cls: type[Any]) -> None:
        """Register an encoding model class.

        Parameters
        ----------
        name : str
            Public name used to identify the model.
        model_cls : type[Any]
            Model class associated with the name.
        """

        raise NotImplementedError()

    @classmethod
    def get_model(cls, name: str) -> type[Any]:
        """Retrieve a registered encoding model class.

        Parameters
        ----------
        name : str
            Public name used to identify the model.

        Returns
        -------
        type[Any]
            Registered model class.
        """

        raise NotImplementedError()

    @classmethod
    def list_models(cls) -> list[str]:
        """List registered model names.

        Returns
        -------
        list[str]
            Sorted or insertion-order list of available model names.
        """

        raise NotImplementedError()
