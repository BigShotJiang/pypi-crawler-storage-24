"""Canonical axis names for NeuroWeave arrays."""

from __future__ import annotations


AXES = {
    "time": "time dimension",
    "lag": "temporal lag",
    "channel": "neural recording channel",
    "feature": "stimulus feature",
    "trial": "trial index",
    "subject": "subject index",
    "condition": "experimental condition",
}


def is_valid_axis(name: str) -> bool:
    """Check whether an axis name is canonical in NeuroWeave.

    Parameters
    ----------
    name : str
        Axis name to validate.

    Returns
    -------
    bool
        Whether the provided axis name is valid.
    """

    raise NotImplementedError()
