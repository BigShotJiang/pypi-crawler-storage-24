"""Core abstractions for NeuroWeave."""
