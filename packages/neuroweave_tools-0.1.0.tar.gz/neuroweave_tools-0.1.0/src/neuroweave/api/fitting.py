"""Compatibility re-exports for fitting helpers."""

from neuroweave.validation.fitting import (
    cross_validate_model,
    fit_encoding_model,
    nested_cv,
)

__all__ = ["fit_encoding_model", "cross_validate_model", "nested_cv"]
