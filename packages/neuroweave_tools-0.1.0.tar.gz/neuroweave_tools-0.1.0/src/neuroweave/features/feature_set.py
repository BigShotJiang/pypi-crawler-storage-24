"""Stable feature-set facade."""

from __future__ import annotations

from neuroweave.features.pipeline import FeaturePipeline


class FeatureSet(FeaturePipeline):
    """Stable facade for a collection of feature steps.

    ``FeatureSet`` provides a user-facing name for feature pipelines so
    higher-level workflows can depend on a consistent abstraction even
    if the internal feature implementation changes.
    """


__all__ = ["FeatureSet"]
