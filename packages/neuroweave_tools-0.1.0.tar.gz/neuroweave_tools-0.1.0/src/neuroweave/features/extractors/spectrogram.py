"""Spectrogram feature extractor."""

from __future__ import annotations

import numpy as np

from .base_extractor import FeatureExtractor


class Spectrogram(FeatureExtractor):
    """Placeholder spectrogram extractor."""

    def transform(self, stimulus: np.ndarray) -> np.ndarray:
        """Return a placeholder spectrogram feature matrix.

        Parameters
        ----------
        stimulus : np.ndarray
            Raw stimulus array.

        Returns
        -------
        np.ndarray
            Feature matrix.
        """

        output = self._as_2d(stimulus)
        self._feature_names = [f"spectrogram_{index}" for index in range(output.shape[1])]
        return output
