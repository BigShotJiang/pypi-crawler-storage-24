"""Pitch feature extractor."""

from __future__ import annotations

import numpy as np

from .base_extractor import FeatureExtractor


class Pitch(FeatureExtractor):
    """Placeholder pitch extractor."""

    def transform(self, stimulus: np.ndarray) -> np.ndarray:
        """Return a placeholder pitch feature matrix.

        Parameters
        ----------
        stimulus : np.ndarray
            Raw stimulus array.

        Returns
        -------
        np.ndarray
            Feature matrix.
        """

        output = self._as_2d(stimulus)
        if output.shape[1] == 1:
            self._feature_names = ["pitch"]
        else:
            self._feature_names = [f"pitch_{index}" for index in range(output.shape[1])]
        return output
