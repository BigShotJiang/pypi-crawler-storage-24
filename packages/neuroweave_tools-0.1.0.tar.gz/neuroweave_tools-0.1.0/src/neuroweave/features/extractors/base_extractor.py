"""Base classes for feature extractors."""

from __future__ import annotations

from abc import abstractmethod

import numpy as np

from neuroweave.features.base import BaseFeature


class FeatureExtractor(BaseFeature):
    """Base class for stimulus-driven feature extractors."""

    @staticmethod
    def _as_2d(X: np.ndarray) -> np.ndarray:
        """Convert an input array to a 2D feature matrix."""

        X_array = np.asarray(X, dtype=float)
        if X_array.ndim == 1:
            return X_array[:, np.newaxis]
        if X_array.ndim != 2:
            raise ValueError("Feature extractors expect a 1D or 2D array.")
        return X_array

    @abstractmethod
    def transform(self, stimulus: np.ndarray) -> np.ndarray:
        """Extract features directly from a stimulus array."""

        raise NotImplementedError()
