"""Envelope feature extractor."""

from __future__ import annotations

import numpy as np

from .base_extractor import FeatureExtractor


class Envelope(FeatureExtractor):
    """Placeholder envelope extractor."""

    def transform(self, stimulus: np.ndarray) -> np.ndarray:
        """Return a placeholder envelope feature matrix.

        Parameters
        ----------
        stimulus : np.ndarray
            Raw stimulus array.

        Returns
        -------
        np.ndarray
            Feature matrix.
        """

        output = self._as_2d(stimulus)
        if output.shape[1] == 1:
            self._feature_names = ["envelope"]
        else:
            self._feature_names = [f"envelope_{index}" for index in range(output.shape[1])]
        return output
