"""Feature extraction and transformation utilities for NeuroWeave."""

from neuroweave.design.design_matrix import DesignMatrix
from neuroweave.design.lag_metadata import LagMetadata

from .base import BaseFeature
from .feature_set import FeatureSet
from .pipeline import FeaturePipeline
from .registry import FeatureRegistry

__all__ = [
    "BaseFeature",
    "FeaturePipeline",
    "FeatureRegistry",
    "FeatureSet",
    "DesignMatrix",
    "LagMetadata",
]
