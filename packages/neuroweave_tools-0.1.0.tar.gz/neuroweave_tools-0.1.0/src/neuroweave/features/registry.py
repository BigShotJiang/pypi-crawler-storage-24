"""Registry for available feature steps."""

from __future__ import annotations

from typing import Any


class FeatureRegistry:
    """Registry for NeuroWeave feature classes."""

    _registry: dict[str, type[Any]] = {}

    @classmethod
    def register_feature(cls, name: str, feature_cls: type[Any]) -> None:
        """Register a feature class under a public name.

        Parameters
        ----------
        name : str
            Feature name.
        feature_cls : type[Any]
            Feature class to register.
        """

        cls._registry[name] = feature_cls

    @classmethod
    def get_feature(cls, name: str) -> type[Any]:
        """Return a registered feature class.

        Parameters
        ----------
        name : str
            Feature name.

        Returns
        -------
        type[Any]
            Registered feature class.
        """

        return cls._registry[name]

    @classmethod
    def list_features(cls) -> list[str]:
        """List registered feature names."""

        return sorted(cls._registry.keys())
