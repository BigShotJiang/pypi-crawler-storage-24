"""Temporal derivative transform."""

from __future__ import annotations

import numpy as np

from .base_transform import FeatureTransform


class Derivative(FeatureTransform):
    """Compute a first-order temporal derivative."""

    def transform(self, X: np.ndarray) -> np.ndarray:
        """Compute a padded temporal derivative.

        Parameters
        ----------
        X : np.ndarray
            Input feature matrix.

        Returns
        -------
        np.ndarray
            Temporal derivative of the input.
        """

        X_array = self._as_2d(X)
        derivative = np.diff(X_array, axis=0, prepend=X_array[[0], :])
        input_names = self.input_feature_names or [
            f"feature_{index}" for index in range(X_array.shape[1])
        ]
        self._feature_names = [f"{name}_derivative" for name in input_names]
        return derivative
