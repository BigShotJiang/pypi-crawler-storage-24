"""Onset transform."""

from __future__ import annotations

import numpy as np

from .base_transform import FeatureTransform


class Onset(FeatureTransform):
    """Placeholder onset transform."""

    def transform(self, X: np.ndarray) -> np.ndarray:
        """Return a placeholder onset-transformed feature matrix.

        Parameters
        ----------
        X : np.ndarray
            Input feature matrix.

        Returns
        -------
        np.ndarray
            Transformed feature matrix.
        """

        X_array = self._as_2d(X)
        input_names = self.input_feature_names or [
            f"feature_{index}" for index in range(X_array.shape[1])
        ]
        self._feature_names = [f"{name}_onset" for name in input_names]
        return X_array
