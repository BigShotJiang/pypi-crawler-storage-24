"""Base classes for feature transforms."""

from __future__ import annotations

from abc import abstractmethod

import numpy as np

from neuroweave.features.base import BaseFeature


class FeatureTransform(BaseFeature):
    """Base class for transforms applied to feature matrices."""

    @staticmethod
    def _as_2d(X: np.ndarray) -> np.ndarray:
        """Convert an input array to a 2D feature matrix."""

        X_array = np.asarray(X, dtype=float)
        if X_array.ndim == 1:
            return X_array[:, np.newaxis]
        if X_array.ndim != 2:
            raise ValueError("Feature transforms expect a 1D or 2D array.")
        return X_array

    @abstractmethod
    def transform(self, X: np.ndarray) -> np.ndarray:
        """Transform an existing feature matrix."""

        raise NotImplementedError()
