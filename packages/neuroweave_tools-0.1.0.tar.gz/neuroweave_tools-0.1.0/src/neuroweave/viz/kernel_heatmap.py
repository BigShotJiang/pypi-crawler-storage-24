"""Placeholder module for kernel heatmaps."""
