"""Placeholder module for kernel plots."""
