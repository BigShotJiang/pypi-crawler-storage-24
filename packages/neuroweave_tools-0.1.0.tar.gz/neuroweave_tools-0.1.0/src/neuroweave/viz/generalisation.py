"""Placeholder module for generalisation plots."""
