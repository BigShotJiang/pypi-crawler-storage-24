# NeuroWeave

NeuroWeave is a modular Python framework for temporal neural encoding models, including TRF-style models and planned extensions for connectivity, state-dependent, representational, and simulation workflows.

## Installation

Install the package in editable mode:

```bash
pip install -e .
```

Install with optional extras as needed:

```bash
pip install -e ".[dev]"
pip install -e ".[docs,viz]"
```

## Building the documentation

Install the documentation dependencies and build the HTML site:

```bash
pip install -e ".[docs]"
cd docs
make html
```

The build uses Sphinx, Sphinx-Gallery, and autosummary to generate the
tutorial gallery, user guide, and API reference.

## Development

The project uses a `src` layout and mirrored tests:

- `src/neuroweave/`: package source code
- `tests/neuroweave/`: test modules mirroring the package hierarchy
- `pyproject.toml`: package metadata and tool configuration

## Architecture Overview

The package is organized into focused modules for:

- `core`: shared abstractions and registry primitives
- `models`: TRF and higher-level model families
- `estimators`: fitting backends and estimator adapters
- `design`, `evaluation`, `stats`, `viz`: analysis utilities and workflows
- `simulation`: synthetic data generation and benchmark datasets
- `api`, `backends`, `utils`: user-facing entry points and integrations

The repository includes a Sphinx documentation skeleton under `docs/`, using
`pydata-sphinx-theme` and autosummary-generated API reference pages.
