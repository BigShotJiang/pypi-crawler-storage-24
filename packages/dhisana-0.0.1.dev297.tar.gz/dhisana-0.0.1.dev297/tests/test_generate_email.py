"""
Integration test for the single-step generate_personalized_email function.
Requires OPENAI_API_KEY environment variable to be set.
"""
import asyncio
import os
import unittest

from dhisana.schemas.sales import (
    CampaignContext,
    ContentGenerationContext,
    ConversationContext,
    Lead,
    MessageGenerationInstructions,
    SenderInfo,
)
from dhisana.utils.generate_email import generate_personalized_email


def _build_tool_config():
    """Build tool_config from environment variables."""
    key = os.environ.get("OPENAI_API_KEY")
    if not key:
        return None
    return [
        {
            "name": "openai",
            "configuration": [
                {"name": "apiKey", "value": key},
            ],
        }
    ]


def _build_context() -> ContentGenerationContext:
    lead = Lead(
        full_name="Jane Smith",
        first_name="Jane",
        last_name="Smith",
        email="jane.smith@acmecorp.com",
        job_title="VP of Engineering",
        organization_name="Acme Corp",
        organization_website="https://acmecorp.com",
        industry="Software",
        company_size="500-1000",
    )
    sender = SenderInfo(
        sender_full_name="John Doe",
        sender_first_name="John",
        sender_last_name="Doe",
        sender_email="john@dhisana.ai",
        sender_bio="Co-founder at Dhisana, helping sales teams automate outreach.",
        sender_appointment_booking_url="https://cal.com/johndoe/30min",
    )
    campaign = CampaignContext(
        product_name="Dhisana AI",
        value_prop="AI-powered sales outreach that writes personalized emails at scale",
        call_to_action="Book a 15-minute demo call",
        pain_points=["Manual email writing is slow", "Low response rates on generic templates"],
        proof_points=["3x response rate improvement", "Used by 500+ sales teams"],
    )
    instructions = MessageGenerationInstructions(
        use_cache=False,
        allow_html=False,
    )
    return ContentGenerationContext(
        lead_info=lead,
        sender_info=sender,
        campaign_context=campaign,
        current_conversation_context=ConversationContext(),
        message_instructions=instructions,
    )


class TestGenerateEmail(unittest.TestCase):
    def test_single_variation(self):
        """Generate 1 email variation and validate the output structure."""
        tool_config = _build_tool_config()
        if not tool_config:
            self.skipTest("OPENAI_API_KEY not set")

        context = _build_context()
        results = asyncio.run(
            generate_personalized_email(
                generation_context=context,
                number_of_variations=1,
                tool_config=tool_config,
            )
        )

        self.assertIsInstance(results, list)
        self.assertEqual(len(results), 1)

        email = results[0]
        self.assertIn("subject", email)
        self.assertIn("body", email)
        self.assertTrue(len(email["subject"]) > 0, "Subject should not be empty")
        self.assertTrue(len(email["body"]) > 0, "Body should not be empty")

        print(f"\n--- Generated Email ---")
        print(f"Subject: {email['subject']}")
        print(f"Body:\n{email['body']}")


if __name__ == "__main__":
    unittest.main()
