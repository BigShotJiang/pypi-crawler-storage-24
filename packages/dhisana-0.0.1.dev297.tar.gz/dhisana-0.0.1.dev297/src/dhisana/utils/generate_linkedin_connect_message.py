# ----------------------------------------------------------------------
# LinkedIn Message Generation Code (Refactored to mirror email structure)
# ----------------------------------------------------------------------

from typing import Dict, List, Optional
from pydantic import BaseModel
from datetime import datetime

from dhisana.schemas.sales import (
    ContentGenerationContext, 
    ConversationContext,
    CampaignContext,
    Lead, 
    MessageGenerationInstructions, 
    MessageItem, 
    SenderInfo
)
from dhisana.utils.generate_structured_output_internal import (
    get_structured_output_internal,
    get_structured_output_with_assistant_and_vector_store
)
from dhisana.utils.assistant_tool_tag import assistant_tool

# ---------------------------------------------------------------------------------------
# CONSTANTS
# ---------------------------------------------------------------------------------------
DEFAULT_EMAIL_GEN_MODEL = "gpt-5.4"


# ----------------------------------------------------------------------
# LinkedIn Connection Message Schema
# ----------------------------------------------------------------------
class LinkedInConnectMessage(BaseModel):
    body: str

# ----------------------------------------------------------------------
# Cleanup function (similar to cleanup_email_context)
# ----------------------------------------------------------------------
def cleanup_linkedin_context(linkedin_context: ContentGenerationContext) -> ContentGenerationContext:
    """
    Return a copy of ContentGenerationContext without unneeded or sensitive fields 
    for LinkedIn generation.
    """
    clone_context = linkedin_context.copy(deep=True)
    
    # Example: remove irrelevant external data for this context
    if clone_context.external_known_data:
        clone_context.external_known_data.external_openai_vector_store_id = None

    # Remove extra fields on the lead_info if desired
    clone_context.lead_info.task_ids = None
    clone_context.lead_info.email_validation_status = None
    clone_context.lead_info.linkedin_validation_status = None
    clone_context.lead_info.research_status = None
    clone_context.lead_info.enchrichment_status = None

    return clone_context

# ----------------------------------------------------------------------
# Known Framework Variations (fallback if user instructions are not provided)
# ----------------------------------------------------------------------
LINKEDIN_FRAMEWORK_VARIATIONS = [
    "Use a friendly intro mentioning their role and a quick reason to connect.",
    "Use social proof: reference an industry success story or insight.",
    "Use a brief mention of mutual interest or connection.",
    "Use P-S-B style (Pain, Solution, Benefit) but under 40 words.",
    "Use a 3-Bullet Approach: Industry/Pain, Value, Simple Ask."
]

# ----------------------------------------------------------------------
# Core function to generate a LinkedIn copy (single-step)
# ----------------------------------------------------------------------
async def generate_personalized_linkedin_copy(
    linkedin_context: ContentGenerationContext,
    variation_text: str,
    tool_config: Optional[List[Dict]] = None,
) -> dict:
    """
    Generate a personalized LinkedIn connection message in a single LLM call.
    Passes all lead, sender, campaign, and conversation context directly
    to the model and returns the final message.
    """
    cleaned_context = cleanup_linkedin_context(linkedin_context)

    lead_data = cleaned_context.lead_info or Lead()
    sender_data = cleaned_context.sender_info or SenderInfo()
    campaign_data = cleaned_context.campaign_context or CampaignContext()
    conversation_data = cleaned_context.current_conversation_context or ConversationContext()

    message_prompt = f"""
Generate a personalized LinkedIn connection request message based on the following context.
The message must be under 40 words total.

LEAD INFORMATION:
{lead_data.dict()}

SENDER INFORMATION:
Full Name: {sender_data.sender_full_name or ''}
First Name: {sender_data.sender_first_name or ''}
Last Name: {sender_data.sender_last_name or ''}
Bio: {sender_data.sender_bio or ''}
Appointment Booking URL: {sender_data.sender_appointment_booking_url or ''}

CAMPAIGN INFORMATION:
Product Name: {campaign_data.product_name or ''}
Value Proposition: {campaign_data.value_prop or ''}
Call To Action: {campaign_data.call_to_action or ''}
Pain Points: {campaign_data.pain_points or []}
Proof Points: {campaign_data.proof_points or []}

MESSAGING FRAMEWORK:
{variation_text}

CONVERSATION HISTORY:
Email Thread: {conversation_data.current_email_thread or ''}
LinkedIn Thread: {conversation_data.current_linkedin_thread or ''}

OUTPUT REQUIREMENTS:
- Output must be JSON with "body" field only.
- The entire message body must be under 40 words total.
- Plain text only, no HTML tags.
- Use salutation Hi followed by first name, unless specified otherwise.
- Use only the information provided.
- Do not use em dash in the output.
    """

    # Check if a vector store is available
    vector_store_id = (
        linkedin_context.external_known_data.external_openai_vector_store_id
        if linkedin_context.external_known_data else None
    )
    use_cache = linkedin_context.message_instructions.use_cache if linkedin_context.message_instructions else True

    if vector_store_id:
        message_response, message_status = await get_structured_output_with_assistant_and_vector_store(
            prompt=message_prompt,
            response_format=LinkedInConnectMessage,
            vector_store_id=vector_store_id,
            model=DEFAULT_EMAIL_GEN_MODEL,
            tool_config=tool_config,
            use_cache=use_cache
        )
    else:
        message_response, message_status = await get_structured_output_internal(
            prompt=message_prompt,
            response_format=LinkedInConnectMessage,
            model=DEFAULT_EMAIL_GEN_MODEL,
            tool_config=tool_config,
            use_cache=use_cache
        )

    if message_status != "SUCCESS":
        raise Exception("Error: Could not generate LinkedIn message.")

    # Wrap in MessageItem for consistency
    response_item = MessageItem(
        message_id="",  # fill in if you have an ID
        thread_id="",
        sender_name=sender_data.sender_full_name or "",
        sender_email=sender_data.sender_email or "",
        receiver_name=lead_data.full_name or "",
        receiver_email=lead_data.email or "",
        iso_datetime=datetime.utcnow().isoformat(),
        subject="Hi",
        body=message_response.body
    )

    return response_item.model_dump()

# ----------------------------------------------------------------------
# Primary function to generate multiple LinkedIn message variations
# (similar to generate_personalized_email)
# ----------------------------------------------------------------------
@assistant_tool
async def generate_personalized_linkedin_message(
    linkedin_context: ContentGenerationContext,
    number_of_variations: int = 3,
    tool_config: Optional[List[Dict]] = None
) -> List[dict]:
    """
    Generate multiple variations of a personalized LinkedIn connection message 
    using the provided context and instructions.

    :param linkedin_context: Consolidated context for LinkedIn generation
    :param number_of_variations: Number of variations to produce
    :param tool_config: Optional config for tool or vector store
    :return: A list of dictionaries, each containing 'subject' and 'body' only
    """
    message_instructions = linkedin_context.message_instructions or MessageGenerationInstructions()
    user_instructions_exist = bool((message_instructions.instructions_to_generate_message or "").strip())

    linkedin_variations = []
    
    for i in range(number_of_variations):
        # If user provided custom instructions, use them for each variation
        # Otherwise, pick from fallback frameworks in a round-robin fashion
        if user_instructions_exist:
            variation_text = message_instructions.instructions_to_generate_message
        else:
            variation_text = LINKEDIN_FRAMEWORK_VARIATIONS[i % len(LINKEDIN_FRAMEWORK_VARIATIONS)]
        
        personalized_copy = await generate_personalized_linkedin_copy(
            linkedin_context=linkedin_context,
            variation_text=variation_text,
            tool_config=tool_config
        )
        linkedin_variations.append(personalized_copy)

    return linkedin_variations
