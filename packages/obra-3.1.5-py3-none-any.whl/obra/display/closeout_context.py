"""Closeout context-building functions.

Extracted from obra.display.closeout (REFACTOR-STRUCTURAL-P26-001 Story 3).
Contains context-building and mapping logic for session closeout messaging.
"""

from __future__ import annotations

import logging
from typing import Any

from obra.display.closeout import (
    CloseoutContext,
    TerminationState,
    _normalize_quality_score,
)
from obra.utils.numeric import _safe_int, _safe_numeric

logger = logging.getLogger(__name__)


def _extract_completion_context(
    result: Any,
) -> tuple[int, Any, Any, bool, str]:
    """Extract completion context from a session result object.

    Returns:
        Tuple of (items_completed, total_iterations, quality_score,
        was_escalated, terminal_phase).
    """
    items_completed = 0
    total_iterations: Any = "N/A"
    quality_score: Any = "N/A"
    was_escalated = False
    terminal_phase = ""

    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        summary = result.session_summary
        items_completed = int(summary.get("items_completed", 0) or 0)
        total_iterations = summary.get("total_iterations", "N/A")
        quality_score = summary.get("quality_score", "N/A")
        was_escalated = bool(summary.get("was_escalated", False))
        terminal_phase = summary.get("terminal_phase", "")
    elif hasattr(result, "items_completed"):
        items_completed = int(getattr(result, "items_completed", 0) or 0)
        total_iterations = getattr(result, "total_iterations", "N/A")
        quality_score = getattr(result, "quality_score", "N/A")

    result_was_escalated = getattr(result, "was_escalated", None)
    if isinstance(result_was_escalated, bool):
        was_escalated = result_was_escalated

    result_terminal_phase = getattr(result, "terminal_phase", None)
    if isinstance(result_terminal_phase, str) and result_terminal_phase:
        terminal_phase = result_terminal_phase

    return (
        items_completed,
        total_iterations,
        quality_score,
        was_escalated,
        terminal_phase,
    )


def _map_to_termination_state(
    result: Any,
    *,
    was_interrupted: bool = False,
) -> TerminationState:
    """Map result to TerminationState for closeout message."""
    if was_interrupted:
        return TerminationState.INTERRUPTED

    was_escalated = getattr(result, "was_escalated", None)
    if was_escalated is True:
        return TerminationState.ESCALATED

    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        if result.session_summary.get("was_escalated"):
            return TerminationState.ESCALATED

    status = getattr(result, "status", None)
    if status is not None:
        status_str = str(status).lower()
        if "failed" in status_str:
            return TerminationState.FAILED
        if "expired" in status_str:
            return TerminationState.EXPIRED
        if "abandoned" in status_str:
            return TerminationState.ABANDONED
        if "escalated" in status_str:
            return TerminationState.ESCALATED

    return TerminationState.COMPLETED


def _build_closeout_context(
    result: Any,
    session_id: str | None,
    objective: str = "",
    *,
    was_interrupted: bool = False,
) -> CloseoutContext:
    """Build CloseoutContext from result for closeout message."""
    (
        items_completed,
        _total_iterations,
        quality_score,
        _was_escalated,
        terminal_phase,
    ) = _extract_completion_context(result)

    quality_score = _normalize_quality_score(quality_score)

    result_objective = getattr(result, "objective", "") or objective
    work_summary = getattr(result, "work_summary", []) or []
    duration_seconds = _safe_numeric(getattr(result, "duration_seconds", 0.0))
    total_duration_seconds = _safe_numeric(getattr(result, "total_duration_seconds", 0.0))
    invocation_count = _safe_int(getattr(result, "invocation_count", 1), default=1)
    files_created = getattr(result, "files_created", []) or []
    files_modified = getattr(result, "files_modified", []) or []
    git_branch = getattr(result, "git_branch", "") or ""
    git_commit_hash = getattr(result, "git_commit_hash", "") or ""
    termination_reason = getattr(result, "termination_reason", "") or ""
    warnings = getattr(result, "warnings", []) or []
    epics_completed = _safe_int(getattr(result, "epics_completed", 0))
    epics_total = _safe_int(getattr(result, "epics_total", 0))
    stories_completed = _safe_int(getattr(result, "stories_completed", 0))
    stories_total = _safe_int(getattr(result, "stories_total", 0))
    tasks_completed = _safe_int(getattr(result, "tasks_completed", 0))
    tasks_total = _safe_int(getattr(result, "tasks_total", 0))

    if hasattr(result, "session_summary") and isinstance(result.session_summary, dict):
        summary = result.session_summary
        if not result_objective:
            result_objective = summary.get("objective", objective)
        if not items_completed:
            items_completed = summary.get("items_completed", 0)

    state = _map_to_termination_state(result, was_interrupted=was_interrupted)
    quality_status = "not_finalized" if state == TerminationState.INTERRUPTED else "finalized"
    if state == TerminationState.INTERRUPTED:
        quality_score = None

    plan_final = getattr(result, "plan_final", []) or []
    if isinstance(plan_final, list):
        counts = {"epic": 0, "story": 0, "task": 0}
        for item in plan_final:
            if not isinstance(item, dict):
                continue
            item_type = item.get("item_type")
            if item_type in counts:
                counts[item_type] += 1
        if epics_total == 0:
            epics_total = counts["epic"]
        if stories_total == 0:
            stories_total = counts["story"]
        if tasks_total == 0:
            tasks_total = counts["task"]

    if state == TerminationState.COMPLETED:
        if epics_total > 0 and epics_completed == 0:
            epics_completed = epics_total
        if stories_total > 0 and stories_completed == 0:
            stories_completed = stories_total
        if tasks_total > 0 and tasks_completed == 0:
            tasks_completed = tasks_total
    elif tasks_completed == 0:
        tasks_completed = items_completed

    items_total = tasks_total if tasks_total > 0 else 0

    # FEAT-CLOSEOUT-SKIP-SUMMARY: Attach pending skips for closeout display
    pending_skips: list[dict[str, str]] | None = None
    try:
        from obra.config import Config

        cfg = Config.load()
        show_summary = (
            cfg.get("orchestration", {})
            .get("skip_tracking", {})
            .get("closeout_summary", True)
        )
        if show_summary:
            from obra.execution.skip_record import SkipStatus, list_skip_records

            pending = list_skip_records(status=SkipStatus.PENDING)
            if session_id:
                pending = [s for s in pending if s.session_id == session_id]
            if pending:
                pending_skips = [
                    {
                        "id": s.task_id,
                        "description": s.description[:80],
                        "reason": s.reason.value,
                    }
                    for s in pending
                ]
    except Exception:
        logger.debug("Skip summary population failed during closeout", exc_info=True)

    return CloseoutContext(
        state=state,
        session_id=session_id or "",
        objective=result_objective,
        work_summary=work_summary if work_summary else None,
        items_completed=items_completed,
        items_total=items_total,
        quality_score=quality_score,
        quality_status=quality_status,
        duration_seconds=duration_seconds,
        total_duration_seconds=total_duration_seconds,
        invocation_count=invocation_count,
        files_created=files_created if files_created else None,
        files_modified=files_modified if files_modified else None,
        git_branch=git_branch,
        git_commit_hash=git_commit_hash,
        termination_reason=termination_reason,
        warnings=warnings if warnings else None,
        terminal_phase=terminal_phase,
        epics_completed=epics_completed,
        epics_total=epics_total,
        stories_completed=stories_completed,
        stories_total=stories_total,
        tasks_completed=tasks_completed or items_completed,
        tasks_total=tasks_total,
        pending_skips=pending_skips,
    )


def _get_orchestrator_closeout_progress(orchestrator: Any | None) -> dict[str, Any]:
    """Best-effort read of orchestrator progress metrics for closeout reconciliation."""
    if orchestrator is None:
        return {}
    tracker = getattr(orchestrator, "_progress_tracker", None)
    if tracker is None:
        return {}
    get_progress = getattr(tracker, "get_closeout_progress_snapshot", None)
    if not callable(get_progress):
        return {}
    try:
        progress = get_progress()
    except Exception as exc:
        logger.debug("Failed to read closeout progress snapshot: %s", exc)
        return {}
    return progress if isinstance(progress, dict) else {}


def _merge_closeout_progress(ctx: CloseoutContext, progress: dict[str, Any]) -> None:
    """Merge orchestrator progress data into closeout context when missing."""
    if not progress:
        return
    progress_tasks_completed = _safe_int(
        progress.get("tasks_completed"),
        default=_safe_int(progress.get("items_completed"), default=0),
    )
    progress_tasks_total = _safe_int(progress.get("tasks_total"), default=0)
    if ctx.tasks_completed <= 0 and progress_tasks_completed > 0:
        ctx.tasks_completed = progress_tasks_completed
    if ctx.tasks_total <= 0 and progress_tasks_total > 0:
        ctx.tasks_total = progress_tasks_total
    if ctx.items_completed <= 0 and progress_tasks_completed > 0:
        ctx.items_completed = progress_tasks_completed
    if ctx.items_total <= 0 and progress_tasks_total > 0:
        ctx.items_total = progress_tasks_total
    # P0-3: Merge epic/story counters from orchestrator plan state
    progress_epics_completed = _safe_int(progress.get("epics_completed"), default=0)
    progress_epics_total = _safe_int(progress.get("epics_total"), default=0)
    progress_stories_completed = _safe_int(progress.get("stories_completed"), default=0)
    progress_stories_total = _safe_int(progress.get("stories_total"), default=0)
    if ctx.epics_completed <= 0 and progress_epics_completed > 0:
        ctx.epics_completed = progress_epics_completed
    if ctx.epics_total <= 0 and progress_epics_total > 0:
        ctx.epics_total = progress_epics_total
    if ctx.stories_completed <= 0 and progress_stories_completed > 0:
        ctx.stories_completed = progress_stories_completed
    if ctx.stories_total <= 0 and progress_stories_total > 0:
        ctx.stories_total = progress_stories_total
    if not ctx.terminal_phase:
        phase = progress.get("last_phase")
        if isinstance(phase, str) and phase.strip():
            ctx.terminal_phase = phase.strip()


def _build_interrupted_closeout_context(
    *,
    orchestrator: Any | None,
    session_id: str,
    objective: str,
    suppress_interrupt_hint: bool,
) -> CloseoutContext:
    """Build interrupted closeout context with best-effort progress reconciliation."""
    ctx = CloseoutContext(
        state=TerminationState.INTERRUPTED,
        session_id=session_id,
        objective=objective,
        quality_score=None,
        quality_status="not_finalized",
        suppress_interrupt_hint=suppress_interrupt_hint,
    )
    _merge_closeout_progress(ctx, _get_orchestrator_closeout_progress(orchestrator))
    return ctx
