"""PlanTreeEmitter — plan-tree, task-tracker, and session-footer progress events.

Owns all plan snapshot rendering, plan-tree state, task-tracker state, and
session footer hints.  Receives EmitterContext at construction and delegates
all shared operations (print, spinner, pipeline, utilities) through self._ctx.

Cross-domain mutation interface (called by ExecutionItemEmitter in S4):
    mark_item_started(item_id, title) — update plan status + tracker state
    mark_item_completed(item_id, status) — update plan status + tracker done set

Shared state read from EmitterContext:
    _plan_mode  (written here and by DerivationEmitter)
    _dashboard_enabled, _footer_hint_enabled, _task_tracker_enabled,
    _task_tracker_max_next  (read-only config caches)

Design decision D3: domain composition — no registry, just explicit wiring
in ProgressEmitter.__init__.
"""

from collections.abc import Callable
from datetime import datetime
from typing import TYPE_CHECKING, Any

from obra.display.charset import glyphs
from obra.display.observability._emitter import VerbosityLevel

if TYPE_CHECKING:
    from obra.display.observability._context import EmitterContext


class TaskTrackerState:
    """Encapsulates task-tracker queue state and rendering.

    Owns the ordered list of executable plan items, done-set bookkeeping,
    current-task pointer, and task-count / plan-version guards.
    Extracted from PlanTreeEmitter to isolate tracker concerns.
    """

    def __init__(self, ctx: "EmitterContext") -> None:
        self._ctx = ctx

        # Task tracker state
        self._task_tracker_items: list[dict[str, str]] = []
        self._task_tracker_index: dict[str, int] = {}
        self._task_tracker_done: set[str] = set()
        self._task_tracker_current_id: str | None = None
        self._task_tracker_current_title: str | None = None

        # Task count / versioning
        self._total_tasks: int = 0
        self._current_task_index: int = 0
        self._plan_total_locked: bool = False
        self._plan_version: int = 0

    def set_plan_items(
        self,
        items: list[dict],
        infer_item_type: "Callable[[str], str]",
        normalize_status: "Callable[[str], str]",
    ) -> None:
        """Set plan items for task tracker rendering.

        Also seeds ``_task_tracker_done`` from item status when available
        (e.g. on resume, where items arrive with ``status: completed``).

        Args:
            items: List of plan item dicts with id/title fields
            infer_item_type: Callback to infer item type from id.
            normalize_status: Callback to normalize status string.
        """
        if not items:
            return

        staged: list[tuple[int, int | None, dict[str, str]]] = []
        # Collect status per item_id so we can seed the done set afterwards.
        status_by_id: dict[str, str] = {}
        has_explicit_order = False
        for index, item in enumerate(items):
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id", "")).strip()
            if not item_id:
                continue
            raw_item_type = str(item.get("item_type", "")).strip().lower()
            item_type = raw_item_type or infer_item_type(item_id)
            if not self._is_executable_item_type(item_type):
                continue
            title = str(item.get("title", "")).strip()
            raw_order = item.get("order")
            order_value: int | None = None
            try:
                if raw_order is not None:
                    order_value = int(raw_order)
            except (TypeError, ValueError):
                order_value = None
            if order_value is not None:
                has_explicit_order = True
            staged.append((index, order_value, {"id": item_id, "title": title}))
            # Capture status if the item carries one (resume / get_session_plan payloads).
            raw_status = str(item.get("status", "")).strip()
            if raw_status:
                status_by_id[item_id] = normalize_status(raw_status)

        if has_explicit_order:
            staged.sort(
                key=lambda entry: (
                    entry[1] if entry[1] is not None else 1_000_000,
                    entry[0],
                )
            )

        normalized = [entry[2] for entry in staged]
        index_map = {entry["id"]: idx for idx, entry in enumerate(normalized)}

        if not normalized:
            return

        self._task_tracker_items = normalized
        self._task_tracker_index = index_map
        self._total_tasks = len(normalized)
        # Plan snapshots are authoritative for tracker totals; prevent stale plan_total overwrites.
        self._plan_total_locked = True

        if self._task_tracker_current_id and not self._task_tracker_current_title:
            current_index = self._task_tracker_index.get(self._task_tracker_current_id)
            if current_index is not None:
                current_title = self._task_tracker_items[current_index].get("title")
                if current_title:
                    self._task_tracker_current_title = current_title

        # Preserve existing done items that still appear in the new plan ...
        preserved_done = {
            task_id for task_id in self._task_tracker_done if task_id in index_map
        }
        # ... and seed from item status (covers resume where items carry status).
        seeded_done = {
            item_id
            for item_id, status in status_by_id.items()
            if status in ("completed", "skipped") and item_id in index_map
        }
        self._task_tracker_done = preserved_done | seeded_done

    def _is_executable_item_type(self, item_type: str) -> bool:
        """Return True when an item should participate in task tracker queueing."""
        return item_type in {"task", "subtask"}

    def set_total_tasks(self, total: int, plan_version: int | None = None) -> None:
        """Set the total task count and reset progress tracking.

        Args:
            total: Total number of tasks expected in this session
            plan_version: Plan version for staleness guard. When provided,
                rejects updates with a lower version than previously seen.
                Once a versioned update is accepted, unversioned updates
                are also rejected to prevent stale event overwrites.
        """
        if plan_version is not None:
            if plan_version < self._plan_version:
                return  # Stale versioned update
            is_newer_version = plan_version > self._plan_version
            prior_plan_version = self._plan_version
            self._plan_version = plan_version
            if (
                is_newer_version
                and prior_plan_version > 0
                and plan_version > 1
                and self._ctx.config.verbosity >= VerbosityLevel.PROGRESS
            ):
                self._ctx._print(f"Info: Plan revised to plan v{plan_version}.")
            if self._plan_total_locked and not is_newer_version:
                if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                    self._ctx._print(
                        f"[DEBUG] ProgressEmitter: ignoring plan_total={total} "
                        f"(plan items locked, plan_version={plan_version})",
                        style="dim",
                    )
                return
        elif self._plan_version > 0:
            return  # Reject unversioned updates once a versioned one is seen
        elif self._plan_total_locked:
            if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                self._ctx._print(
                    f"[DEBUG] ProgressEmitter: ignoring plan_total={total} (plan items locked)",
                    style="dim",
                )
            return

        self._total_tasks = total
        self._current_task_index = 0

        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
            self._ctx._print(
                f"[DEBUG] ProgressEmitter: task count set to {total} (plan_version={plan_version})",
                style="dim",
            )

    def _current_task_label(self, fallback_id: str) -> str:
        if self._task_tracker_current_id:
            title = self._task_tracker_current_title or ""
            if title:
                title = self._ctx._truncate_title(title)
                return f"{self._task_tracker_current_id}: {title}"
            return self._task_tracker_current_id
        if fallback_id.lower() == "execution":
            return "task"
        return fallback_id

    def render_task_tracker(self) -> None:
        """Render task tracker summary when enabled."""
        if not self._ctx._dashboard_feature_enabled(self._ctx._task_tracker_enabled):
            return

        if (
            self._task_tracker_current_id is None
            and not self._task_tracker_items
            and self._total_tasks == 0
        ):
            return

        done_count = len(self._task_tracker_done)
        if (
            self._task_tracker_current_id
            and self._task_tracker_current_id not in self._task_tracker_done
        ):
            # Show ordinal position semantics while a task is actively running.
            done_count += 1
        if self._plan_total_locked and self._task_tracker_items:
            total_count = len(self._task_tracker_items)
        else:
            total_count = self._total_tasks if self._total_tasks > 0 else len(self._task_tracker_items)
        total_label = str(total_count) if total_count > 0 else "?"

        if self._task_tracker_current_id:
            current_title = self._task_tracker_current_title or ""
            if current_title:
                current_label = f"{self._task_tracker_current_id}: {current_title}"
            else:
                current_label = self._task_tracker_current_id
        else:
            current_label = "idle"

        max_next = self._ctx._task_tracker_max_next
        next_label = "none"
        if self._task_tracker_items and max_next > 0:
            start_index = 0
            if self._task_tracker_current_id in self._task_tracker_index:
                start_index = self._task_tracker_index[self._task_tracker_current_id] + 1

            upcoming: list[str] = []
            for item in self._task_tracker_items[start_index:]:
                item_id = item.get("id", "")
                if not item_id or item_id == self._task_tracker_current_id:
                    continue
                if item_id in self._task_tracker_done:
                    continue
                title = item.get("title", "")
                if title:
                    upcoming.append(f"{item_id}: {title}")
                else:
                    upcoming.append(item_id)
                if len(upcoming) >= max_next:
                    break
            if upcoming:
                next_label = ", ".join(upcoming)
            else:
                known_count = len(self._task_tracker_items)
                next_label = "unknown" if total_count > known_count else "none"
        elif total_count > 0:
            next_label = "n/a"

        self._ctx._print(
            f"Tracker: {done_count}/{total_label} | Current: {current_label} | Next: {next_label}",
            style="dim",
        )

    def mark_item_started(self, item_id: str, title: str) -> None:
        """Update tracker state when an item starts.

        Args:
            item_id: Normalised item identifier.
            title: Item title (may be empty string).
        """
        self._task_tracker_current_id = item_id
        if title:
            self._task_tracker_current_title = title
        if item_id not in self._task_tracker_index:
            self._task_tracker_items.append({"id": item_id, "title": title})
            self._task_tracker_index[item_id] = len(self._task_tracker_items) - 1
        elif title and not self._task_tracker_items[self._task_tracker_index[item_id]].get(
            "title"
        ):
            self._task_tracker_items[self._task_tracker_index[item_id]]["title"] = title

    def mark_item_completed(self, item_id: str, status: str) -> None:
        """Update tracker done set when an item completes.

        Args:
            item_id: Normalised item identifier.
            status: Terminal status string (already normalised by caller).
        """
        is_success = status in {"completed", "skipped"}
        if is_success:
            self._task_tracker_done.add(item_id)
        else:
            self._task_tracker_done.discard(item_id)
        if self._task_tracker_current_id == item_id:
            self._task_tracker_current_id = None
            self._task_tracker_current_title = None

    def item_skipped(self, item_id: str) -> None:
        """Update tracker state when an item is skipped.

        Args:
            item_id: Normalised item identifier.
        """
        self._task_tracker_done.add(item_id)
        if self._task_tracker_current_id == item_id:
            self._task_tracker_current_id = None
            self._task_tracker_current_title = None


class MilestoneTracker:
    """Tracks story and epic completion milestones.

    Owns ``_completed_stories`` and ``_completed_epics`` sets and the logic
    to determine whether a story/epic is complete based on plan-tree state.
    Extracted from PlanTreeEmitter to isolate milestone concerns.
    """

    def __init__(self, ctx: "EmitterContext") -> None:
        self._ctx = ctx
        self._completed_stories: set[str] = set()
        self._completed_epics: set[str] = set()

    def _is_story_complete(
        self,
        story_id: str,
        plan_children: dict[str | None, list[str]],
        plan_index: dict[str, dict[str, object]],
        plan_status: dict[str, str],
    ) -> bool:
        descendants = self._iter_descendants(story_id, plan_children)
        if not descendants:
            return False
        leaf_ids = [
            desc
            for desc in descendants
            if not plan_children.get(desc)
            and plan_index.get(desc, {}).get("item_type") in {"task", "subtask"}
        ]
        if not leaf_ids:
            return False
        return all(
            plan_status.get(leaf_id, "pending") in {"completed", "skipped"}
            for leaf_id in leaf_ids
        )

    def _is_epic_complete(
        self,
        epic_id: str,
        plan_children: dict[str | None, list[str]],
        plan_index: dict[str, dict[str, object]],
        plan_status: dict[str, str],
    ) -> bool:
        descendants = self._iter_descendants(epic_id, plan_children)
        story_ids = [
            desc
            for desc in descendants
            if plan_index.get(desc, {}).get("item_type") == "story"
        ]
        if not story_ids:
            return False
        return all(
            self._is_story_complete(story_id, plan_children, plan_index, plan_status)
            for story_id in story_ids
        )

    def _maybe_render_story_completion(
        self,
        item_id: str,
        plan_index: dict[str, dict[str, object]],
        plan_children: dict[str | None, list[str]],
        plan_status: dict[str, str],
        plan_items: list[dict[str, object]],
        task_tracker_items: list[dict[str, str]],
        task_tracker_done: set[str],
    ) -> None:
        story_id = self._find_ancestor(item_id, "story", plan_index)
        if story_id and story_id not in self._completed_stories:
            if self._is_story_complete(story_id, plan_children, plan_index, plan_status):
                self._completed_stories.add(story_id)
                # P2-3: Print compact summary instead of full plan tree.
                tracker_ids = {
                    str(item.get("id", "")).strip()
                    for item in task_tracker_items
                    if str(item.get("id", "")).strip()
                }
                if tracker_ids:
                    total_items = len(tracker_ids)
                    done_count = len(task_tracker_done & tracker_ids)
                else:
                    total_items = len(plan_items)
                    done_count = sum(
                        1
                        for s in plan_status.values()
                        if s in ("completed", "skipped")
                    )
                self._ctx._print(
                    f"\u2713 Story {story_id} complete ({done_count}/{total_items} tasks done)",
                    style="green",
                )

                epic_id = self._find_ancestor(story_id, "epic", plan_index)
                if epic_id and epic_id not in self._completed_epics:
                    if self._is_epic_complete(epic_id, plan_children, plan_index, plan_status):
                        self._completed_epics.add(epic_id)
                        remaining_epics = self._count_remaining_epics(plan_items)
                        self._ctx._print(
                            f"\u2713 Epic {epic_id} complete "
                            f"({done_count}/{total_items} tasks done"
                            f"{f', {remaining_epics} Epics remaining' if remaining_epics > 0 else ''})",
                            style="green",
                        )

    def _count_remaining_epics(self, plan_items: list[dict[str, object]]) -> int:
        """Count epics that are not yet completed.

        P2-3: Used for compact epic completion summary.
        """
        epic_ids = {
            str(item.get("id", ""))
            for item in plan_items
            if str(item.get("item_type", "")).lower() == "epic"
            or str(item.get("depth", "")) == "0"
            or str(item.get("level", "")).lower() == "epic"
        }
        return len(epic_ids - self._completed_epics)

    def _seed_completed_milestones(
        self,
        plan_status: dict[str, str],
        plan_index: dict[str, dict[str, object]],
        plan_children: dict[str | None, list[str]],
    ) -> None:
        """Pre-compute ``_completed_stories`` and ``_completed_epics`` from ``_plan_status``.

        Called after ``_plan_status`` is populated (e.g. on resume) so that
        milestones already achieved in a prior session are recognised.
        This prevents re-emission and ensures future completions render
        correctly relative to already-done siblings.
        """
        if not plan_status or not plan_index:
            return

        # Walk every story; if all its leaf tasks are done, mark it complete.
        story_ids = [
            item_id
            for item_id, item in plan_index.items()
            if str(item.get("item_type", "")).lower() == "story"
        ]
        for story_id in story_ids:
            if self._is_story_complete(story_id, plan_children, plan_index, plan_status):
                self._completed_stories.add(story_id)

        # Walk every epic; if all its stories are done, mark it complete.
        epic_ids = [
            item_id
            for item_id, item in plan_index.items()
            if str(item.get("item_type", "")).lower() == "epic"
        ]
        for epic_id in epic_ids:
            if self._is_epic_complete(epic_id, plan_children, plan_index, plan_status):
                self._completed_epics.add(epic_id)

    @staticmethod
    def _find_ancestor(
        item_id: str,
        target_type: str,
        plan_index: dict[str, dict[str, object]],
    ) -> str | None:
        current_id = item_id
        while current_id:
            current = plan_index.get(current_id)
            if not current:
                return None
            if current.get("item_type") == target_type:
                return current_id
            parent_id = current.get("parent_id") or None
            if not parent_id:
                return None
            current_id = str(parent_id)
        return None

    @staticmethod
    def _iter_descendants(
        item_id: str,
        plan_children: dict[str | None, list[str]],
    ) -> list[str]:
        descendants: list[str] = []
        stack = list(plan_children.get(item_id, []))
        while stack:
            current = stack.pop()
            descendants.append(current)
            stack.extend(plan_children.get(current, []))
        return descendants

    def reset(self) -> None:
        """Clear completed sets for a fresh plan snapshot."""
        self._completed_stories.clear()
        self._completed_epics.clear()


class PlanTreeEmitter:
    """Emits all plan-tree, task-tracker, and session footer progress events.

    Owns the full plan snapshot (items, index, children, status, order),
    task-tracker queue state, story/epic completion milestones, and the
    session footer hint.  All shared infrastructure (print, spinner, utilities)
    is accessed via self._ctx.

    Delegates task-tracker bookkeeping to ``TaskTrackerState`` and milestone
    tracking to ``MilestoneTracker``.
    """

    def __init__(self, ctx: "EmitterContext") -> None:
        self._ctx = ctx

        # Collaborators
        self._task_tracker = TaskTrackerState(ctx)
        self._milestone_tracker = MilestoneTracker(ctx)

        # Plan tree state
        self._plan_items: list[dict[str, object]] = []
        self._plan_index: dict[str, dict[str, object]] = {}
        self._plan_children: dict[str | None, list[str]] = {}
        self._plan_status: dict[str, str] = {}
        self._plan_order: dict[str, int] = {}
        self._last_plan_render_s: float | None = None
        self._last_plan_render_reason: str | None = None
        self._plan_render_min_interval_s: float = 2.0
        self._last_plan_summary: dict[str, int] | None = None
        self._plan_source: str | None = None
        self._plan_tree_rendered_once: bool = False

        # Session / footer hint state
        self._session_id: str | None = None
        self._last_footer_hint_s: float | None = None
        self._footer_hint_min_interval_s: float = 30.0

    # ------------------------------------------------------------------ #
    # Cross-domain mutation interface                                     #
    # ------------------------------------------------------------------ #

    def mark_item_started(self, item_id: str, title: str) -> None:
        """Update plan status and tracker state when an item starts.

        Called by ExecutionItemEmitter.item_started — resolves cross-domain
        mutation of plan-tree state without exposing raw dicts.

        Args:
            item_id: Normalised item identifier.
            title: Item title (may be empty string).
        """
        self._plan_status[item_id] = "in_progress"
        self._task_tracker.mark_item_started(item_id, title)

    def mark_item_completed(self, item_id: str, status: str) -> None:
        """Update plan status and tracker done set when an item completes.

        Called by ExecutionItemEmitter.item_completed — resolves cross-domain
        mutation of plan-tree state.

        Args:
            item_id: Normalised item identifier.
            status: Terminal status string (already normalised by caller).
        """
        self._task_tracker.mark_item_completed(item_id, status)
        self._plan_status[item_id] = status
        if status in {"completed", "skipped"}:
            self._milestone_tracker._maybe_render_story_completion(
                item_id,
                self._plan_index,
                self._plan_children,
                self._plan_status,
                self._plan_items,
                self._task_tracker._task_tracker_items,
                self._task_tracker._task_tracker_done,
            )

    # ------------------------------------------------------------------ #
    # Plan snapshot                                                       #
    # ------------------------------------------------------------------ #

    def update_plan_snapshot(
        self,
        plan_items: list[dict],
        source: str | None = None,
        session_id: str | None = None,
        mode: str | None = None,
    ) -> None:
        """Update cached plan items and render the plan tree."""
        if mode == "partial":
            self._render_partial_plan_snapshot(plan_items, source)
            return
        tracker_sync_only = mode == "tracker_sync"
        if session_id:
            self._session_id = session_id
        if tracker_sync_only:
            self.set_plan_items(plan_items)
            if source:
                self._plan_source = source
            if mode:
                self._ctx._plan_mode = mode
            if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
                self._ctx._print(
                    f"[DEBUG] ProgressEmitter: tracker synced with {len(self._task_tracker._task_tracker_items)} executable plan items",
                    style="dim",
                )
            return

        previous_items = list(self._plan_items)
        self.set_plan_items(plan_items)

        normalized_items: list[dict[str, object]] = []
        plan_index: dict[str, dict[str, object]] = {}
        plan_children: dict[str | None, list[str]] = {}
        plan_status: dict[str, str] = {}
        plan_order: dict[str, int] = {}

        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_id = str(item.get("id") or item.get("item_id") or "").strip()
            if not item_id:
                continue
            title = str(item.get("title") or item.get("description") or "").strip()
            description = str(item.get("description") or "").strip()
            item_type = str(item.get("item_type") or "").strip().lower()
            if not item_type:
                item_type = self._infer_item_type(item_id)
            parent_id = item.get("parent_id")
            parent_id = str(parent_id).strip() if parent_id is not None else None
            depth = item.get("depth")
            try:
                depth_value = int(depth) if depth is not None else 0
            except (TypeError, ValueError):
                depth_value = 0
            order_value = item.get("order")
            try:
                order = int(order_value) if order_value is not None else -1
            except (TypeError, ValueError):
                order = -1
            status = self._normalize_status(str(item.get("status", "")).strip())

            # Extract context if present
            context = item.get("context", {})

            normalized = {
                "id": item_id,
                "title": title,
                "description": description,
                "item_type": item_type,
                "parent_id": parent_id or "",
                "depth": depth_value,
                "context": context,
            }
            normalized_items.append(normalized)
            plan_index[item_id] = normalized
            plan_status[item_id] = status
            plan_order[item_id] = order
            plan_children.setdefault(parent_id or None, []).append(item_id)

        self._plan_items = normalized_items
        self._plan_index = plan_index
        self._plan_children = plan_children
        self._plan_status = plan_status
        self._plan_order = plan_order
        if source:
            self._plan_source = source
        if mode:
            self._ctx._plan_mode = mode
        self._last_plan_summary = {
            "epic": sum(1 for item in normalized_items if item.get("item_type") == "epic"),
            "story": sum(1 for item in normalized_items if item.get("item_type") == "story"),
            "task": sum(1 for item in normalized_items if item.get("item_type") == "task"),
        }
        # Recompute completed stories/epics from plan_status so that
        # items already completed (e.g. from a previous session on resume)
        # are recognised and won't re-emit milestone messages.
        self._milestone_tracker.reset()
        self._milestone_tracker._seed_completed_milestones(
            self._plan_status, self._plan_index, self._plan_children,
        )

        reason = "Plan updated"
        if source == "derive":
            reason = "Plan derived"
        elif source == "revise":
            reason = "Plan revised"

        # For revise: show compact diff instead of full tree after the first render.
        # Full tree is only shown at DETAIL verbosity (-vv) for subsequent revisions.
        is_first_render = self._last_plan_render_s is None
        if source == "revise" and self._plan_tree_rendered_once:
            # Show compact change summary instead of full tree
            if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS:
                summary = self._summarize_plan_changes(previous_items, normalized_items)
                timestamp = self._ctx._timestamp()
                prev_count = len(previous_items)
                curr_count = len(normalized_items)
                header = f"Plan revised: {curr_count} items"
                if prev_count != curr_count:
                    header += f" (was {prev_count})"
                self._ctx._print(f"\n{timestamp}{header}", style="cyan")
                if summary:
                    self._ctx._print(summary, style="dim")
                if self._last_plan_summary:
                    epic_c = self._last_plan_summary.get("epic", 0)
                    story_c = self._last_plan_summary.get("story", 0)
                    task_c = self._last_plan_summary.get("task", 0)
                    self._ctx._print(
                        f"  Plan: {epic_c} Epics, {story_c} Stories, {task_c} Tasks",
                        style="dim",
                    )
            # Still render the full tree at DETAIL verbosity
            if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
                self.render_plan_tree(reason=reason, source=source or None, force=True)
        else:
            # First plan render (from derive) or non-revise source: show full tree
            self.render_plan_tree(reason=reason, source=source or None, force=is_first_render)
            self._plan_tree_rendered_once = True

    def _render_partial_plan_snapshot(self, plan_items: list[dict], source: str | None) -> None:
        """Render a compact, in-progress plan snapshot at DETAIL verbosity."""
        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            return
        if not plan_items:
            return

        epic_item = None
        stories: list[dict] = []
        tasks: list[dict] = []
        for item in plan_items:
            if not isinstance(item, dict):
                continue
            item_type = str(item.get("item_type") or "").lower()
            if item_type == "epic" and epic_item is None:
                epic_item = item
            elif item_type == "story":
                stories.append(item)
            elif item_type == "task":
                tasks.append(item)

        if not epic_item:
            return

        epic_id = str(epic_item.get("id", "")).strip()
        epic_title = str(epic_item.get("title", "")).strip() or "Untitled"
        header = "Plan snapshot (partial)"
        if source:
            header = f"{header}, source: {source}"
        header = f"{header} - {epic_id}: {epic_title}"

        timestamp = self._ctx._timestamp()
        self._ctx._print(f"{timestamp}{header}", style="cyan")

        story_map: dict[str, list[dict]] = {}
        for task in tasks:
            parent_id = str(task.get("parent_id") or "").strip()
            if parent_id:
                story_map.setdefault(parent_id, []).append(task)

        max_stories = 5
        max_tasks = 5
        for story in stories[:max_stories]:
            story_id = str(story.get("id", "")).strip()
            story_title = str(story.get("title", "")).strip() or "Untitled"
            task_count = len(story_map.get(story_id, []))
            self._ctx._print(
                f"  - {story_id}: {story_title} ({task_count} tasks)",
                style="dim",
            )
            for task in story_map.get(story_id, [])[:max_tasks]:
                task_id = str(task.get("id", "")).strip()
                task_title = str(task.get("title", "")).strip() or "Untitled"
                self._ctx._print(f"    - {task_id}: {task_title}", style="dim")
            if task_count > max_tasks:
                self._ctx._print(
                    f"    - +{task_count - max_tasks} more tasks",
                    style="dim",
                )

        if len(stories) > max_stories:
            self._ctx._print(
                f"  - +{len(stories) - max_stories} more stories",
                style="dim",
            )

    def item_skipped(self, item: dict) -> None:
        """Emit event when processing a plan item is skipped."""
        item_id = item.get("id", "?")
        normalized_id = str(item_id).strip()
        if normalized_id and normalized_id != "?":
            self._task_tracker.item_skipped(normalized_id)
            self._plan_status[normalized_id] = "skipped"
            self._milestone_tracker._maybe_render_story_completion(
                normalized_id,
                self._plan_index,
                self._plan_children,
                self._plan_status,
                self._plan_items,
                self._task_tracker._task_tracker_items,
                self._task_tracker._task_tracker_done,
            )

    def render_plan_tree(self, reason: str, source: str | None, *, force: bool = False) -> None:
        """Render the full plan tree at PROGRESS verbosity or higher."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if not self._plan_items:
            return
        if not force and self._last_plan_render_s is not None:
            now = datetime.now().timestamp()
            elapsed = now - self._last_plan_render_s
            if (
                self._last_plan_render_reason == reason
                and elapsed < self._plan_render_min_interval_s
            ):
                return

        header = "Plan"
        if source:
            header = f"{header} (source: {source})"
        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL and self._ctx._plan_mode:
            header = f"{header}, mode: {self._ctx._plan_mode}"
        if reason:
            header = f"{header} - {reason}"
        self._ctx._print("")
        self._ctx._print(header, style="bold cyan")
        self._last_plan_render_s = datetime.now().timestamp()
        self._last_plan_render_reason = reason

        roots: set[str] = set()
        for item_id, item in self._plan_index.items():
            parent_id = item.get("parent_id") or None
            if not parent_id or parent_id not in self._plan_index:
                roots.add(item_id)
        roots_list = self._sort_plan_ids(list(roots))

        for root_id in roots_list:
            self._render_plan_node(root_id, level=0)

        if self._last_plan_summary:
            epic_count = self._last_plan_summary.get("epic", 0)
            story_count = self._last_plan_summary.get("story", 0)
            task_count = self._last_plan_summary.get("task", 0)
            self._ctx._print(
                f"\nPlan: {epic_count} Epics, {story_count} Stories, {task_count} Tasks",
                style="dim",
            )

    def _render_plan_node(self, item_id: str, level: int) -> None:
        item = self._plan_index.get(item_id, {})
        title = str(item.get("title", ""))
        item_type = str(item.get("item_type", "task")).upper()
        status = self._aggregate_status(item_id)
        status_label = self._format_status_label(status)
        indent = "  " * level
        display_title = title if title else "untitled"

        # Add user story traceability if present
        context = item.get("context", {})
        user_story_ids = context.get("user_story_ids", []) if isinstance(context, dict) else []
        story_suffix = f" [{', '.join(user_story_ids)}]" if user_story_ids else ""

        line = f"{indent}[{status_label}] {item_id} {item_type}: {display_title}{story_suffix}"
        self._ctx._print(line, style="dim" if status in ("pending", "skipped") else None)

        children = self._sort_plan_ids(self._plan_children.get(item_id, []))
        for child_id in children:
            self._render_plan_node(child_id, level=level + 1)

    def _sort_plan_ids(self, ids: list[str]) -> list[str]:
        def sort_key(item_id: str) -> tuple[int, str]:
            order = self._plan_order.get(item_id, -1)
            if order < 0:
                order = 1_000_000
            return (order, item_id)

        return sorted(ids, key=sort_key)

    def _normalize_status(self, status: str) -> str:
        normalized = status.lower()
        if normalized in {"completed", "complete", "done", "success", "ok"}:
            return "completed"
        if normalized in {"in_progress", "running", "started"}:
            return "in_progress"
        if normalized in {"failed", "error", "failure", "partial", "interrupted"}:
            return "failed"
        if normalized in {"skipped", "skip"}:
            return "skipped"
        return "pending"

    def _format_status_label(self, status: str) -> str:
        return {
            "completed": "done",
            "in_progress": "running",
            "failed": "failed",
            "skipped": "skipped",
            "pending": "pending",
        }.get(status, "pending")

    def _aggregate_status(self, item_id: str) -> str:
        children = self._plan_children.get(item_id)
        if not children:
            return self._plan_status.get(item_id, "pending")

        child_statuses = [self._aggregate_status(child_id) for child_id in children]
        if any(status == "failed" for status in child_statuses):
            return "failed"
        if any(status == "in_progress" for status in child_statuses):
            return "in_progress"
        if all(status in {"completed", "skipped"} for status in child_statuses):
            return "completed"
        return "pending"

    def _infer_item_type(self, item_id: str) -> str:
        if item_id.startswith("E"):
            return "epic"
        if item_id.startswith("S") and ".T" not in item_id:
            return "story"
        if ".T" in item_id:
            if item_id.count(".") >= 2:
                return "subtask"
            return "task"
        return "task"

    def _summarize_plan_changes(
        self,
        previous_items: list[dict[str, object]],
        current_items: list[dict[str, object]],
    ) -> str | None:
        if not previous_items:
            return None

        def to_map(items: list[dict[str, object]]) -> dict[str, dict[str, object]]:
            result: dict[str, dict[str, object]] = {}
            for item in items:
                item_id = str(item.get("id", "")).strip()
                if item_id:
                    result[item_id] = item
            return result

        prev_map = to_map(previous_items)
        curr_map = to_map(current_items)
        prev_ids = set(prev_map.keys())
        curr_ids = set(curr_map.keys())

        added_ids = sorted(curr_ids - prev_ids)
        removed_ids = sorted(prev_ids - curr_ids)

        updated_ids: list[str] = []
        moved_ids: list[str] = []
        for item_id in sorted(prev_ids & curr_ids):
            prev = prev_map[item_id]
            curr = curr_map[item_id]
            if (prev.get("parent_id") or "") != (curr.get("parent_id") or ""):
                moved_ids.append(item_id)
            if (
                (prev.get("title") or "") != (curr.get("title") or "")
                or (prev.get("description") or "") != (curr.get("description") or "")
                or (prev.get("item_type") or "") != (curr.get("item_type") or "")
            ):
                updated_ids.append(item_id)

        lines: list[str] = []
        max_detail_items = 3

        # Show added items with titles
        if added_ids:
            for item_id in added_ids[:max_detail_items]:
                item = curr_map.get(item_id, {})
                title = str(item.get("title", "")).strip()
                if title:
                    lines.append(f"  + {item_id}: {title}")
                else:
                    lines.append(f"  + {item_id}")
            if len(added_ids) > max_detail_items:
                lines.append(f"  + {len(added_ids) - max_detail_items} more added")

        # Show removed items with titles
        if removed_ids:
            for item_id in removed_ids[:max_detail_items]:
                item = prev_map.get(item_id, {})
                title = str(item.get("title", "")).strip()
                if title:
                    lines.append(f"  - {item_id}: {title}")
                else:
                    lines.append(f"  - {item_id}")
            if len(removed_ids) > max_detail_items:
                lines.append(f"  - {len(removed_ids) - max_detail_items} more removed")

        # Summarize updated/moved as counts
        if updated_ids:
            lines.append(f"  ~ {len(updated_ids)} items updated")
        if moved_ids:
            lines.append(f"  ~ {len(moved_ids)} items moved")

        return "\n".join(lines) if lines else None

    # ------------------------------------------------------------------ #
    # Session identity & pipeline                                         #
    # ------------------------------------------------------------------ #

    def set_session_id(self, session_id: str) -> None:
        """Set the session ID for footer hints and correlation.

        Shows resume hint immediately so user knows how to recover
        if something goes wrong during derivation or execution.

        Args:
            session_id: Session identifier for the current run
        """
        self._session_id = session_id
        self.render_footer_hint()

    def restore_pipeline_checkmarks(self, phase: str) -> None:
        """Mark all pipeline stages before *phase* as completed.

        Call on resume so that the banner shows checkmarks for phases
        that were completed in a prior session.

        Args:
            phase: Current session phase (e.g. ``"EXECUTION"``).
        """
        if self._ctx._pipeline_enabled:
            self._ctx._pipeline.mark_stages_complete_up_to(phase)

    # ------------------------------------------------------------------ #
    # Plan items / task tracker (delegates to TaskTrackerState)           #
    # ------------------------------------------------------------------ #

    def set_plan_items(self, items: list[dict]) -> None:
        """Set plan items for task tracker rendering (delegates to TaskTrackerState)."""
        self._task_tracker.set_plan_items(
            items,
            infer_item_type=self._infer_item_type,
            normalize_status=self._normalize_status,
        )

    def set_total_tasks(self, total: int, plan_version: int | None = None) -> None:
        """Set the total task count and reset progress tracking."""
        self._task_tracker.set_total_tasks(total, plan_version)

    def _current_task_label(self, fallback_id: str) -> str:
        return self._task_tracker._current_task_label(fallback_id)

    # ------------------------------------------------------------------ #
    # Task tracker rendering                                              #
    # ------------------------------------------------------------------ #

    def render_task_tracker(self) -> None:
        """Render task tracker summary when enabled."""
        self._task_tracker.render_task_tracker()

    def _is_executable_item_type(self, item_type: str) -> bool:
        """Proxy to TaskTrackerState for backward compatibility."""
        return self._task_tracker._is_executable_item_type(item_type)

    # ------------------------------------------------------------------ #
    # Behavioral methods                                                   #
    # ------------------------------------------------------------------ #

    def get_progress_summary(self) -> dict[str, Any]:
        """Return a snapshot of task progress state.

        Returns:
            Dict with keys: total_tasks, current_index, done_count,
            current_id, current_title.
        """
        return {
            "total_tasks": self._task_tracker._total_tasks,
            "current_index": self._task_tracker._current_task_index,
            "done_count": len(self._task_tracker._task_tracker_done),
            "current_id": self._task_tracker._task_tracker_current_id,
            "current_title": self._task_tracker._task_tracker_current_title,
        }

    def advance_task_index(self) -> None:
        """Increment the current task index by one."""
        self._task_tracker._current_task_index += 1

    def get_milestone_summary(self) -> dict[str, Any]:
        """Return a snapshot of milestone completion state.

        Returns:
            Dict with keys: completed_stories, completed_epics.
        """
        return {
            "completed_stories": set(self._milestone_tracker._completed_stories),
            "completed_epics": set(self._milestone_tracker._completed_epics),
        }

    def is_plan_locked(self) -> bool:
        """Return whether the plan total is locked."""
        return self._task_tracker._plan_total_locked

    def get_plan_version(self) -> int:
        """Return the current plan version."""
        return self._task_tracker._plan_version

    # ------------------------------------------------------------------ #
    # Session footer hint                                                 #
    # ------------------------------------------------------------------ #

    def render_footer_hint(self, force: bool = False) -> None:
        """Render the session resume footer hint when a session ID is set.

        Rate-limited to avoid cluttering output during rapid phase transitions.
        By default, shows at most once every 30 seconds.

        Args:
            force: If True, bypass rate limiting and always render
        """
        if not self._ctx._dashboard_feature_enabled(self._ctx._footer_hint_enabled):
            return
        if self._session_id is None:
            return

        # Rate limiting: skip if rendered recently (unless forced)
        if not force and self._last_footer_hint_s is not None:
            now = datetime.now().timestamp()
            elapsed = now - self._last_footer_hint_s
            if elapsed < self._footer_hint_min_interval_s:
                return

        from obra.display.recovery_hints import build_interrupt_recovery_hints

        self._ctx._print(glyphs.divider)
        for line in build_interrupt_recovery_hints(self._session_id).splitlines():
            self._ctx._print(line, style="dim")

        # Update timestamp for rate limiting
        self._last_footer_hint_s = datetime.now().timestamp()
