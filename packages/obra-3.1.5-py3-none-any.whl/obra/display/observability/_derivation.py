"""DerivationEmitter — derivation and intent-alignment progress events.

Owns all derivation step, epic derivation, serialization, debug, and
intent-alignment events.  Receives EmitterContext at construction and delegates
all shared operations (print, spinner, utilities) through self._ctx.

Shared state written to EmitterContext:
- _derive_step_start_time  (read by LifecycleEmitter.stage_heartbeat)
- _derive_current_step_name  (read by LifecycleEmitter.stage_heartbeat)
- _current_stage_context  (read by LifecycleEmitter.stage_heartbeat)
- _plan_mode  (read by PlanTreeEmitter and LifecycleEmitter)

Design decision D2: intent-alignment methods belong here (called from derive
handler, zero shared state with review).
Design decision D3: domain composition — no registry, just explicit wiring
in ProgressEmitter.__init__.
"""

import time
from typing import TYPE_CHECKING

from obra.display.charset import glyphs
from obra.display.observability._emitter import VerbosityLevel

if TYPE_CHECKING:
    from obra.display.observability._context import EmitterContext


class DerivationEmitter:
    """Emits all derivation and intent-alignment progress events.

    Owns state:
    - _derive_current_step: current step number (written here, no cross-domain reads)
    - _derive_last_output_time: used for stall detection (written here only)

    Writes shared EmitterContext state:
    - _ctx._derive_step_start_time, _ctx._derive_current_step_name
    - _ctx._current_stage_context, _ctx._plan_mode
    """

    def __init__(self, ctx: "EmitterContext") -> None:
        self._ctx = ctx

        # Derivation-local state (not shared cross-domain)
        self._derive_current_step: int | None = None
        self._derive_last_output_time: float | None = None

        # Intent alignment sub-emitter (D2: extracted for structural clarity)
        self._intent_emitter = IntentAlignmentEmitter(ctx)

    # =========================================================================
    # Derivation step state
    # =========================================================================

    def reset_derive_step_state(self) -> None:
        """Reset unified derivation step tracking (call when step ends or derive phase ends)."""
        self._derive_current_step = None
        self._ctx._derive_current_step_name = None
        self._ctx._derive_step_start_time = None
        self._derive_last_output_time = None

    # =========================================================================
    # Derivation step events
    # =========================================================================

    def derivation_step_started(self, step: int, step_name: str) -> None:
        """Emit event when a unified derivation step starts (3-step pipeline).

        Updates step tracking state and prints progress at PROGRESS verbosity.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
        """
        self._ctx.start_spinner(reason=f"derive_step:{step}")

        # Update tracking state
        self._derive_current_step = step
        self._ctx._derive_current_step_name = step_name
        self._ctx._derive_step_start_time = time.perf_counter()
        self._derive_last_output_time = time.perf_counter()
        if step_name == "tasks" and not self._ctx._plan_mode:
            self._ctx._plan_mode = "one-shot"

        # Update pipeline renderer for derive substep tracking
        if self._ctx._pipeline_enabled:
            self._ctx._pipeline.derive_step_started(step)

        # Emit at PROGRESS verbosity with user-friendly descriptions
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # Map step names to user-friendly descriptions
        step_descriptions = {
            "structure": "identifying epics",
            "tasks": "expanding stories/tasks",
            "serialize": "serializing to JSON",
        }
        description = step_descriptions.get(step_name, step_name)

        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}Derivation step {step}/3: {description}...",
            style="cyan",
        )

    def derivation_step_completed(
        self,
        step: int,
        step_name: str,
        duration_ms: int,
        items_produced: int,
        prose: str | None = None,
        raw_json: str | None = None,
    ) -> None:
        """Emit event when a unified derivation step completes.

        Clears step state and emits counts at DETAIL verbosity.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            duration_ms: Step duration in milliseconds
            items_produced: Number of items produced by this step
            prose: Optional prose output (for steps 1 and 2) to show at DEBUG
            raw_json: Optional raw JSON (for step 3) to show at DEBUG
        """
        self._ctx.stop_spinner(reason=f"derive_step:{step}")

        # Clear step state
        self.reset_derive_step_state()

        # Update pipeline renderer for derive substep tracking
        if self._ctx._pipeline_enabled:
            self._ctx._pipeline.derive_step_completed(step)

        # Emit user-facing summary at PROGRESS (only for structure step)
        if self._ctx.config.verbosity >= VerbosityLevel.PROGRESS and step_name == "structure":
            timestamp = self._ctx._timestamp()
            self._ctx._print(
                f"{timestamp}{glyphs.success} Structure: {items_produced} Epics identified",
                style="green",
            )

        if self._ctx.config.verbosity >= VerbosityLevel.DETAIL:
            timestamp = self._ctx._timestamp()
            self._ctx._print(
                f"{timestamp}  {glyphs.tree_last} {step_name} {glyphs.arrow} {items_produced} items",
                style="dim",
            )

        # At DEBUG verbosity (>= 3), log full prose or raw JSON
        if self._ctx.config.verbosity >= VerbosityLevel.DEBUG:
            if prose:
                self._ctx._print(f"[DEBUG] Step {step} prose output:", style="dim")
                max_chars = 1000
                display_prose = prose if len(prose) <= max_chars else prose[:max_chars] + "..."
                self._ctx._print(display_prose, style="dim")
            elif raw_json:
                self._ctx._print(f"[DEBUG] Step {step} raw JSON:", style="dim")
                max_chars = 1000
                display_json = (
                    raw_json if len(raw_json) <= max_chars else raw_json[:max_chars] + "..."
                )
                self._ctx._print(display_json, style="dim")

    def derivation_step_failed(
        self, step: int, step_name: str, error: str, duration_ms: int
    ) -> None:
        """Emit event when a unified derivation step fails.

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            error: Error message
            duration_ms: Step duration in milliseconds
        """
        # Clear step state
        self.reset_derive_step_state()

        # Emit at PROGRESS verbosity
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        duration_sec = duration_ms / 1000.0
        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}[derive] Step {step}/3 ({step_name}) failed after {duration_sec:.1f}s: {error}",
            style="red",
        )

    def derivation_stall_warning(self, step: int, step_name: str, no_output_seconds: int) -> None:
        """Emit warning when derivation step appears stalled (no output for threshold).

        Args:
            step: Step number (1, 2, or 3)
            step_name: Step name (e.g., 'structure', 'tasks', 'serialize')
            no_output_seconds: Number of seconds without output
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}[derive] Step {step}/3 ({step_name}) appears stalled "
            f"(no output for {no_output_seconds}s)...",
            style="yellow",
        )

    def derivation_streaming_heartbeat(self, step: int, elapsed_seconds: int) -> None:
        """Update spinner during long derivation step with streaming output.

        Args:
            step: Step number (1, 2, or 3)
            elapsed_seconds: Elapsed seconds since step start
        """
        # Only update spinner at PROGRESS verbosity
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        # StatusSpinner animates independently; no manual heartbeat updates needed.
        return

    def derivation_validation_started(self, pass_num: int, max_passes: int) -> None:
        """Emit event when plan validation/refinement starts.

        Args:
            pass_num: Current validation pass number (1-indexed)
            max_passes: Maximum number of validation passes
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}[derive] Validating plan... (pass {pass_num}/{max_passes})",
            style="cyan",
        )

    def derivation_validation_completed(self, pass_num: int, violations: int, passed: bool) -> None:
        """Emit event when plan validation/refinement completes.

        Args:
            pass_num: Current validation pass number (1-indexed)
            violations: Number of validation violations found
            passed: Whether validation passed (no violations)
        """
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return

        if passed:
            self._ctx._print(
                self._ctx._format_status_line(
                    f"[green]{glyphs.success}[/green]",
                    f"Validation passed (pass {pass_num})",
                ),
                style=None,
            )
        else:
            self._ctx._print(
                self._ctx._format_status_line(
                    "[yellow]![/yellow]",
                    f"Validation found {violations} issues (pass {pass_num})",
                ),
                style=None,
            )

    # =========================================================================
    # Epic derivation events
    # =========================================================================

    def epic_derivation_heartbeat(
        self,
        epic_index: int,
        epic_count: int,
        epic_title: str,
        items_so_far: int,
        elapsed_s: int,
    ) -> None:
        """Emit heartbeat during long per-epic derivation."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        title = self._ctx._truncate_title(epic_title)
        elapsed_str = self._ctx._format_elapsed(elapsed_s)
        detail = (
            f"{items_so_far} items, {elapsed_str}" if items_so_far > 0 else elapsed_str
        )
        if self._ctx._should_inline_heartbeat():
            # Stage heartbeat already refreshes inline status every second.
            # Suppress per-epic heartbeat prints to avoid log spam in TTY mode.
            return

        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} ({detail})...",
            style="cyan",
        )

    def epic_derivation_started(
        self,
        epic_index: int,
        epic_count: int,
        epic_id: str,
        epic_title: str,
    ) -> None:
        """Emit event when per-epic derivation starts."""
        self._ctx._current_stage_context = {
            "epic_index": epic_index,
            "epic_count": epic_count,
            "epic_title": epic_title,
        }
        self._ctx._plan_mode = "per-epic"
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        title = self._ctx._truncate_title(epic_title)
        self._ctx._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} (deriving...)",
            style="cyan",
        )

    def epic_derivation_completed(
        self,
        epic_index: int,
        epic_count: int,
        epic_id: str,
        epic_title: str | None,
        stories_derived: int,
        tasks_derived: int,
    ) -> None:
        """Emit event when per-epic derivation completes."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        title = epic_title or epic_id
        title = self._ctx._truncate_title(title)
        self._ctx._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} {glyphs.arrow} {stories_derived} stories, {tasks_derived} tasks",
            style="green",
        )
        self._ctx._current_stage_context = None

    def epic_serialization_batch_started(
        self,
        epic_count: int,
        max_concurrent: int,
    ) -> None:
        """Emit event when parallel epic serialization batch starts."""
        self._ctx._current_stage_context = {
            "serialize_batch": True,
            "epic_count": epic_count,
            "max_concurrent": max_concurrent,
        }
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}  → {epic_count} epics (parallel, {max_concurrent} workers)...",
            style="dim",
        )

    def epic_serialization_completed(
        self,
        epic_index: int,
        epic_count: int,
        epic_id: str,
        epic_title: str,
        items_serialized: int,
    ) -> None:
        """Emit event when per-epic serialization completes."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            self._ctx._current_stage_context = None
            return
        timestamp = self._ctx._timestamp()
        title = self._ctx._truncate_title(epic_title)
        self._ctx._print(
            f"{timestamp}  Epic {epic_index}/{epic_count}: {title} {glyphs.arrow} {items_serialized} items",
            style="green",
        )
        self._ctx._current_stage_context = None

    # =========================================================================
    # Debug events
    # =========================================================================

    def debug_tokens(
        self,
        total: int,
        input_tokens: int,
        output_tokens: int,
        source: str | None = None,
    ) -> None:
        """Emit token usage details at DETAIL verbosity."""
        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            return
        source_label = f" [{source}]" if source else ""
        self._ctx._print(
            f"Tokens: {total:,} (in: {input_tokens:,}, out: {output_tokens:,}){source_label}",
            style="dim",
        )

    def debug_quality(self, message: str) -> None:
        """Emit quality gate details at DETAIL verbosity."""
        if self._ctx.config.verbosity < VerbosityLevel.DETAIL:
            return
        self._ctx._print(message, style="dim")

    # =========================================================================
    # Intent alignment events (D2: belong here — called from derive handler)
    # Delegated to IntentAlignmentEmitter for structural clarity.
    # =========================================================================

    def intent_alignment_started(self, epic_count: int, story_count: int) -> None:
        self._intent_emitter.intent_alignment_started(epic_count, story_count)

    def intent_story_batch_started(self, story_count: int, max_concurrent: int) -> None:
        self._intent_emitter.intent_story_batch_started(story_count, max_concurrent)

    def intent_story_assessed(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        status: str,
        note: str,
    ) -> None:
        self._intent_emitter.intent_story_assessed(
            story_id, story_title, story_index, total_stories, status, note,
        )

    def intent_story_added(self, title: str, parent_id: str | None) -> None:
        self._intent_emitter.intent_story_added(title, parent_id)

    def intent_alignment_completed(
        self,
        coverage_status: str,
        changes_required: bool,
        missing_count: int,
        scope_creep_count: int,
        stories_added: int,
        stories_removed: int,
        duration_s: float,
    ) -> None:
        self._intent_emitter.intent_alignment_completed(
            coverage_status, changes_required, missing_count,
            scope_creep_count, stories_added, stories_removed, duration_s,
        )

    def intent_alignment_fixes_applied(
        self, stories_added: list[str], stories_removed: list[str]
    ) -> None:
        self._intent_emitter.intent_alignment_fixes_applied(stories_added, stories_removed)

    def intent_gap_detection_started(self, story_count: int) -> None:
        self._intent_emitter.intent_gap_detection_started(story_count)

    def intent_gap_detection_completed(
        self,
        gaps_found: bool,
        missing_count: int,
        stories_to_add: int,
        duration_s: float,
    ) -> None:
        self._intent_emitter.intent_gap_detection_completed(
            gaps_found, missing_count, stories_to_add, duration_s,
        )


class IntentAlignmentEmitter:
    """Owns intent-alignment progress events.

    Extracted from DerivationEmitter to reduce class size.
    DerivationEmitter instantiates and delegates to this class.
    """

    def __init__(self, ctx: "EmitterContext") -> None:
        self._ctx = ctx

    def intent_alignment_started(self, epic_count: int, story_count: int) -> None:
        """Emit event when intent alignment starts."""
        self._ctx.start_spinner(reason="intent_alignment")
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}Checking intent coverage ({epic_count} epic(s), {story_count} story/stories)...",
            style="cyan",
        )

    def intent_story_batch_started(self, story_count: int, max_concurrent: int) -> None:
        """Emit event when parallel story intent checks start."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}  -> Checking {story_count} stories (parallel, {max_concurrent} workers)...",
            style="dim",
        )

    def intent_story_assessed(
        self,
        story_id: str,
        story_title: str,
        story_index: int,
        total_stories: int,
        status: str,
        note: str,
    ) -> None:
        """Emit event for per-story intent assessment."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        title = self._ctx._truncate_title(story_title)
        if status == "ok":
            status_str = "[green]OK[/green]"
        elif status == "scope_creep":
            status_str = "[red]SCOPE CREEP[/red]"
        else:
            status_str = f"[yellow]{status.upper()}[/yellow]"
        msg = self._ctx._format_status_line(status_str, f"Story {story_index}/{total_stories}: {title}")
        if note and status != "ok":
            note_text = self._ctx._truncate_note(note)
            msg += f" - {note_text}"
        self._ctx._print(msg)

    def intent_story_added(self, title: str, parent_id: str | None) -> None:
        """Emit event when intent alignment adds a story."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        title_text = self._ctx._truncate_note(title)
        self._ctx._print(f"{timestamp}  [green]+[/green] Adding story: {title_text}")

    def intent_alignment_completed(
        self,
        coverage_status: str,
        changes_required: bool,
        missing_count: int,
        scope_creep_count: int,
        stories_added: int,
        stories_removed: int,
        duration_s: float,
    ) -> None:
        """Emit event when intent alignment completes."""
        self._ctx.stop_spinner(reason="intent_alignment")
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if coverage_status == "pass" or (not changes_required and missing_count == 0):
            status = "[green]OK[/green]"
            detail = ""
        elif coverage_status == "warn":
            status = "[yellow]WARN[/yellow]"
            issues = []
            if missing_count > 0:
                issues.append(f"{missing_count} gap(s)")
            if scope_creep_count > 0:
                issues.append(f"{scope_creep_count} scope creep")
            detail = f" ({', '.join(issues)})" if issues else ""
        else:
            status = "[red]FAIL[/red]"
            issues = []
            if missing_count > 0:
                issues.append(f"{missing_count} gap(s)")
            if scope_creep_count > 0:
                issues.append(f"{scope_creep_count} scope creep")
            detail = f" ({', '.join(issues)})" if issues else ""

        fixes = []
        if stories_added > 0:
            fixes.append(f"+{stories_added} story/stories")
        if stories_removed > 0:
            fixes.append(f"-{stories_removed} story/stories")
        fix_detail = f" [cyan][{', '.join(fixes)}][/cyan]" if fixes else ""

        self._ctx._print(
            self._ctx._format_status_line(
                status,
                f"Intent alignment:{detail}{fix_detail} ({duration_s:.1f}s)",
            )
        )

    def intent_alignment_fixes_applied(
        self, stories_added: list[str], stories_removed: list[str]
    ) -> None:
        """Emit event when intent alignment applies fixes."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        if stories_added:
            for title in stories_added:
                self._ctx._print(f"{timestamp}  [green]+[/green] Added story: {title}")
        if stories_removed:
            for story_id in stories_removed:
                self._ctx._print(f"{timestamp}  [red]-[/red] Removed story: {story_id}")

    def intent_gap_detection_started(self, story_count: int) -> None:
        """Emit event when gap detection starts."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        timestamp = self._ctx._timestamp()
        self._ctx._print(
            f"{timestamp}Checking for missing requirements ({story_count} stories)...",
            style="cyan",
        )

    def intent_gap_detection_completed(
        self,
        gaps_found: bool,
        missing_count: int,
        stories_to_add: int,
        duration_s: float,
    ) -> None:
        """Emit event when gap detection completes."""
        if self._ctx.config.verbosity < VerbosityLevel.PROGRESS:
            return
        if gaps_found:
            status = "[yellow]GAPS FOUND[/yellow]"
            detail = f" ({missing_count} missing)"
        else:
            status = "[green]OK[/green]"
            detail = ""
        fix_detail = (
            f" [cyan][+{stories_to_add} story/stories][/cyan]" if stories_to_add > 0 else ""
        )
        self._ctx._print(
            self._ctx._format_status_line(
                status,
                f"Gap detection:{detail}{fix_detail} ({duration_s:.1f}s)",
            )
        )
