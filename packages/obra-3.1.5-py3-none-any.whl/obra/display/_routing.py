"""Routing dispatcher for progress-event family handlers.

Extracted from ``event_router_handlers.py`` (Story 7, REFACTOR-CODEBASE-CLEANUP-001).
Each ``_route_*`` function handles a family of related progress events.
``RoutingDispatcher.dispatch()`` tries them in canonical order and returns
``True`` on the first match.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from obra.display._coercion import coerce_float, coerce_int
from obra.display.observability import ProgressEmitter

if TYPE_CHECKING:
    from obra.display.event_router_handlers import EventRouteContext

_log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Family routing functions
# ---------------------------------------------------------------------------


def _route_lifecycle_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "phase_completed":
        phase = payload.get("phase", "UNKNOWN")
        duration_ms = payload.get("duration_ms", 0)
        result = payload.get("result")
        progress_emitter.phase_completed(phase, result, duration_ms)
        if phase == "DERIVATION" and isinstance(result, dict):
            item_count = result.get("item_count")
            plan_version = result.get("plan_version")
            if isinstance(item_count, int) and item_count > 0:
                progress_emitter.set_total_tasks(
                    item_count,
                    plan_version=(
                        plan_version if isinstance(plan_version, int) else None
                    ),
                )
            items = result.get("items")
            if isinstance(items, list):
                progress_emitter.set_plan_items(items)
        return True
    if action == "plan_total":
        total = payload.get("total") or payload.get("total_tasks")
        plan_version = payload.get("plan_version")
        if isinstance(total, int):
            progress_emitter.set_total_tasks(
                total,
                plan_version=plan_version if isinstance(plan_version, int) else None,
            )
        return True
    if action == "workflow_derivation_stage_started":
        progress_emitter.planning_stage_started(
            str(payload.get("stage", "unknown")),
            str(payload.get("label", payload.get("user_label", ""))),
        )
        return True
    if action == "planning_stage_completed":
        duration_s = payload.get("duration_s", 0.0)
        summary = payload.get("summary")
        progress_emitter.planning_stage_completed(
            str(payload.get("stage", "unknown")),
            str(payload.get("user_label", "")),
            coerce_float(duration_s),
            str(summary) if summary else None,
        )
        return True
    if action == "workflow_derivation_stage_completed":
        duration_s = payload.get("duration_s", 0.0)
        summary = payload.get("summary")
        progress_emitter.planning_stage_completed(
            str(payload.get("stage", "unknown")),
            str(payload.get("label", payload.get("user_label", ""))),
            coerce_float(duration_s),
            str(summary) if summary else None,
        )
        return True
    if action == "stage_heartbeat":
        progress_emitter.stage_heartbeat(
            payload.get("stage", "unknown"),
            int(payload.get("elapsed_s", payload.get("elapsed", 0))),
        )
        return True
    return False


def _route_derivation_event(context: EventRouteContext) -> bool:
    action = context.action

    # Silent-consume events (no emitter call needed).
    if action == "derivation_step_heartbeat":
        return True
    if action in ("epic_derivation_recovery", "epic_serialization_recovery"):
        return True
    if action == "epic_derivation_heartbeat":
        payload = context.payload
        progress_emitter = context.progress_emitter
        elapsed_s = payload.get("elapsed_s", payload.get("elapsed", 0))
        progress_emitter.epic_derivation_heartbeat(
            int(payload.get("epic_index", 1)),
            int(payload.get("epic_count", 1)),
            str(payload.get("epic_title", "Untitled")),
            int(payload.get("items_so_far", 0)),
            coerce_int(elapsed_s),
        )
        return True
    if action == "stage_summary":
        return True
    return False


def _route_review_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action in ("item_heartbeat", "heartbeat"):
        item_id = payload.get("item_id") or payload.get("item", {}).get("id")
        if not item_id:
            return True
        elapsed_s = payload.get("elapsed_s", payload.get("elapsed", 0))
        file_count = payload.get("file_count", payload.get("files_changed", 0))
        liveness = payload.get("liveness_indicators") or payload.get("liveness")
        progress_emitter.item_heartbeat(
            str(item_id),
            coerce_int(elapsed_s),
            coerce_int(file_count),
            liveness if isinstance(liveness, dict) else None,
        )
        return True
    if action == "review":
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.set_review_context(
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return True
    if action == "file_event":
        filepath = payload.get("filepath") or payload.get("path")
        event_type = payload.get("event_type")
        if filepath and event_type:
            progress_emitter.file_event(
                filepath,
                event_type,
                payload.get("line_count"),
            )
        return True
    if action == "review_loop_started":
        agent_count = payload.get("agent_count")
        parallel = payload.get("parallel")
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.review_loop_started(
            int(payload.get("attempt", 1)),
            int(payload.get("max_attempts", 0)),
            agent_count=coerce_int(agent_count, None),
            parallel=bool(parallel) if isinstance(parallel, bool) else None,
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return True
    if action == "review_agent_started":
        agent_name = payload.get("agent_name") or payload.get("agent")
        if agent_name:
            progress_emitter.review_agent_started(str(agent_name))
        return True
    if action == "review_agent_completed":
        agent_name = payload.get("agent_name") or payload.get("agent")
        if not agent_name:
            return True
        status = str(payload.get("status", "")).lower()
        passed = payload.get("passed")
        if passed is None:
            passed = status in ("complete", "pass", "passed")
        details = payload.get("details") or payload.get("error_message")
        item_id = payload.get("item_id")
        review_cycle_id = payload.get("review_cycle_id")
        progress_emitter.review_agent_completed(
            str(agent_name),
            bool(passed),
            details,
            status=status or None,
            item_id=str(item_id) if item_id else None,
            review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        )
        return True
    if action == "fix_started":
        issue_count = payload.get("issue_count")
        if issue_count is not None:
            progress_emitter.fix_started(int(issue_count))
        return True
    if action == "fix_cycle_cap_reached":
        item_id = payload.get("item_id", "unknown")
        fix_cycles = payload.get("fix_cycles", "?")
        quality_score = payload.get("quality_score", "?")
        has_high_severity = payload.get("has_high_severity", False)
        resolution = (
            "high-severity blockers remain; escalation policy will decide next action"
            if has_high_severity
            else "accepting"
        )
        progress_emitter.warning(
            f"Fix cycle cap reached for {item_id} after {fix_cycles} cycles "
            f"(score {quality_score}) \u2014 {resolution}"
        )
        return True
    if action == "stabilization_auto_accept":
        raw_threshold = payload.get("threshold")
        raw_threshold_ratio = payload.get("threshold_ratio")
        progress_emitter.stabilization_auto_accept(
            item_id=str(payload.get("item_id")) if payload.get("item_id") else "unknown",
            quality_score=coerce_float(payload.get("quality_score")),
            fix_cycles=coerce_int(payload.get("fix_cycles")),
            reason=(
                str(payload.get("reason"))
                if payload.get("reason")
                else "only_deferred_non_critical_remain"
            ),
            threshold=coerce_int(raw_threshold, None),
            threshold_ratio=coerce_float(raw_threshold_ratio, None),
        )
        return True
    if action == "review_filter_applied":
        progress_emitter.review_filter_applied(
            removed_count=int(payload.get("removed_count", 0)),
            adjusted_count=int(payload.get("adjusted_count", 0)),
            kept_count=int(payload.get("kept_count", 0)),
            enriched_count=int(payload.get("enriched_count", 0)),
            item_id=(
                str(payload.get("item_id"))
                if payload.get("item_id") is not None
                else None
            ),
            review_cycle_id=(
                str(payload.get("review_cycle_id"))
                if payload.get("review_cycle_id") is not None
                else None
            ),
        )
        return True
    if action == "scorecard_available":
        _route_scorecard_available(progress_emitter, payload)
        return True
    if action == "scorecard_warning":
        message = payload.get("message")
        if message:
            progress_emitter.scorecard_warning(str(message))
        return True
    if action == "review_indeterminate":
        item_id = payload.get("item_id")
        reason = payload.get("decision_reason")
        progress_emitter.review_indeterminate(
            item_id=str(item_id) if item_id else None,
            reason=str(reason) if reason else None,
        )
        return True
    return False


def _route_session_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "session_completed":
        progress_emitter.session_completed(
            coerce_int(payload.get("items_completed")),
            coerce_float(payload.get("quality_score")),
            str(payload.get("session_summary")) if payload.get("session_summary") else "",
            was_escalated=bool(payload.get("was_escalated", False)),
        )
        return True
    if action == "plan_snapshot":
        plan_items = payload.get("plan_items")
        if isinstance(plan_items, list):
            source = payload.get("source")
            progress_emitter.update_plan_snapshot(
                plan_items,
                source=str(source) if source is not None else None,
                session_id=payload.get("session_id"),
                mode=payload.get("mode"),
            )
        return True
    if action == "refinement_batch_completed":
        batch_index = payload.get("batch_index", 0)
        batch_size = payload.get("batch_size", 0)
        batches_done = payload.get("batches_done", 0)
        batches_total = payload.get("batches_total", 0)
        elapsed_ms = payload.get("elapsed_ms", 0)
        progress_emitter.examine_batch_progress(
            batch_index=coerce_int(batch_index),
            batch_size=coerce_int(batch_size),
            batches_done=coerce_int(batches_done),
            batches_total=coerce_int(batches_total),
            elapsed_ms=coerce_float(elapsed_ms),
            status=str(payload.get("status", "success")),
            phase=str(payload.get("phase", "examine")),
        )
        return True
    if action == "revision_batch_progress":
        from obra.display import print_info

        print_info(
            "Revision batch "
            f"{payload.get('batch_index', 0)}/{payload.get('total_batches', 0)}: "
            f"{payload.get('items_revised', 0)} items processed"
        )
        return True
    if action == "execute":
        plan_items = payload.get("plan_items")
        if isinstance(plan_items, list):
            progress_emitter.update_plan_snapshot(
                plan_items,
                source="execute",
                session_id=payload.get("session_id"),
                mode="tracker_sync",
            )
        return True
    if action == "story0_prerequisite_status":
        reason = payload.get("reason")
        progress_emitter.story0_prerequisite_status(
            str(payload.get("category", "")),
            str(payload.get("name", "")),
            str(payload.get("status", "")),
            str(reason) if reason else None,
        )
        return True
    if action == "story0_message":
        message = payload.get("message", "")
        if message:
            progress_emitter.story0_message(str(message))
        return True
    if action == "story0_blocked":
        failures_summary = payload.get("failures_summary", "")
        if failures_summary:
            progress_emitter.story0_blocked(str(failures_summary))
        return True
    if action == "debug_tokens":
        source = payload.get("source")
        progress_emitter.debug_tokens(
            int(payload.get("total", 0)),
            int(payload.get("input", 0)),
            int(payload.get("output", 0)),
            str(source) if source else None,
        )
        return True
    if action == "debug_quality":
        message = payload.get("message", "")
        if message:
            progress_emitter.debug_quality(str(message))
        return True
    return False


def _route_verification_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "code_verify_completed":
        tools_used = payload.get("tools_used", [])
        if not isinstance(tools_used, list):
            tools_used = []
        item_id = payload.get("item_id")
        progress_emitter.code_verify_completed(
            status=str(payload.get("status", "inconclusive")),
            tools_used=[str(tool) for tool in tools_used if str(tool).strip()],
            pass_count=coerce_int(payload.get("pass_count")),
            fail_count=coerce_int(payload.get("fail_count")),
            inconclusive_count=coerce_int(payload.get("inconclusive_count")),
            item_id=str(item_id) if item_id else None,
        )
        return True
    return False


def _route_alignment_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action == "story_review_completed":
        issues = payload.get("issues", [])
        progress_emitter.story_review_completed(
            payload.get("story_id", ""),
            payload.get("story_title", ""),
            payload.get("story_index", 0),
            payload.get("total_stories", 0),
            payload.get("changes_required", False),
            payload.get("issue_count", 0),
            payload.get("duration_s", 0.0),
        )
        if issues:
            progress_emitter.review_issues_found(
                payload.get("story_id", ""),
                payload.get("story_title", ""),
                issues,
            )
        return True
    return False


def _route_error_event(context: EventRouteContext) -> bool:
    action = context.action
    payload = context.payload
    progress_emitter = context.progress_emitter

    if action in (
        "interactive_guard_triggered",
        "interactive_guard_rollback",
        "interactive_guard_retry",
    ):
        message = payload.get("message")
        if not message:
            message = "Interactive guard event recorded."
        progress_emitter.interactive_guard_notice(message)
        return True
    return False


def _route_scorecard_available(
    progress_emitter: ProgressEmitter,
    payload: dict[str, Any],
) -> None:
    component_scores = payload.get("component_scores_normalized")
    issue_counts = payload.get("issue_counts")
    legacy_scores = payload.get("scores") or {}
    score_units = str(payload.get("score_units", "")).strip().lower()
    total = payload.get("total")
    threshold = payload.get("threshold")
    item_id = payload.get("item_id")
    review_cycle_id = payload.get("review_cycle_id")
    scorecard_source = payload.get("scorecard_source")
    filtered_issue_count = payload.get("filtered_issue_count")
    review_filter_applied = bool(payload.get("review_filter_applied", False))
    scorecard_status = payload.get("status")
    decision_state = payload.get("decision_state")
    failed_agents = payload.get("failed_agents")
    degraded = payload.get("degraded")
    total_agents = payload.get("total_agents")
    if total is None and "compiled_score" in payload:
        total = round(float(payload.get("compiled_score", 0)) * 100)
    if threshold is None and "threshold_ratio" in payload:
        threshold = round(float(payload.get("threshold_ratio", 0)) * 100)

    normalized_scores: dict[str, int] = {}
    if isinstance(component_scores, dict):
        for name, value in component_scores.items():
            try:
                normalized_scores[str(name)] = round(float(value))
            except (TypeError, ValueError):
                continue

    parsed_issue_counts: dict[str, int] = {}
    if isinstance(issue_counts, dict):
        for name, value in issue_counts.items():
            try:
                parsed_issue_counts[str(name)] = int(value)
            except (TypeError, ValueError):
                continue

    if isinstance(legacy_scores, dict):
        if not normalized_scores and score_units in {"normalized_100", "percent_100"}:
            for name, value in legacy_scores.items():
                try:
                    normalized_scores[str(name)] = round(float(value))
                except (TypeError, ValueError):
                    continue
        elif not normalized_scores and score_units in {"ratio_0_1", "ratio"}:
            for name, value in legacy_scores.items():
                try:
                    normalized_scores[str(name)] = round(float(value) * 100)
                except (TypeError, ValueError):
                    continue
        elif not normalized_scores and not score_units:
            numeric_values: list[float] = []
            for value in legacy_scores.values():
                try:
                    numeric_values.append(float(value))
                except (TypeError, ValueError):
                    numeric_values = []
                    break
            if numeric_values and all(0.0 <= value <= 1.0 for value in numeric_values):
                has_fractional_score = any(
                    value not in (0.0, 1.0) for value in numeric_values
                )
                if has_fractional_score:
                    for name, value in legacy_scores.items():
                        try:
                            normalized_scores[str(name)] = round(float(value) * 100)
                        except (TypeError, ValueError):
                            continue
        elif not parsed_issue_counts:
            for name, value in legacy_scores.items():
                try:
                    parsed_issue_counts[str(name)] = int(value)
                except (TypeError, ValueError):
                    continue

    if total is None or threshold is None:
        return

    progress_emitter.scorecard_available(
        normalized_scores,
        int(total),
        int(threshold),
        item_id=str(item_id) if item_id else None,
        review_cycle_id=str(review_cycle_id) if review_cycle_id else None,
        issue_counts=parsed_issue_counts or None,
        scorecard_source=str(scorecard_source) if scorecard_source else None,
        filtered_issue_count=coerce_int(filtered_issue_count, None),
        review_filter_applied=review_filter_applied,
        status=str(scorecard_status) if scorecard_status else None,
        decision_state=str(decision_state) if decision_state else None,
        failed_agents=coerce_int(failed_agents, None),
        degraded=bool(degraded) if degraded is not None else None,
        total_agents=coerce_int(total_agents, None),
        skipped_agents=coerce_int(payload.get("skipped_agents"), None),
    )


# ---------------------------------------------------------------------------
# RoutingDispatcher
# ---------------------------------------------------------------------------


class RoutingDispatcher:
    """Dispatch progress events through family routing functions.

    Tries each routing function in canonical order (lifecycle, derivation,
    review, session, verification, alignment, error) and returns ``True``
    on the first match.
    """

    def dispatch(self, context: EventRouteContext) -> bool:
        """Route *context* through family handlers; return True on match."""
        if _route_lifecycle_event(context):
            return True
        if _route_derivation_event(context):
            return True
        if _route_review_event(context):
            return True
        if _route_session_event(context):
            return True
        if _route_verification_event(context):
            return True
        if _route_alignment_event(context):
            return True
        if _route_error_event(context):
            return True
        return False


__all__ = [
    "RoutingDispatcher",
]
