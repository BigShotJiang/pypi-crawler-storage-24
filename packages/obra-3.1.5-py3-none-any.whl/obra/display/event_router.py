"""Event routing for progress events.

This module provides the event router that dispatches server progress events
to ProgressEmitter calls, plus JSON streaming support.

Usage:
    from obra.display.event_router import _route_progress_event, _emit_progress_json
"""

import json
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from obra.display.event_router_handlers import (
    EventRouteContext,
    dispatch_progress_event,
    is_suppressed_progress_event,
)
from obra.display.observability import ProgressEmitter

if TYPE_CHECKING:
    from rich.console import Console


def _emit_progress_json(action: str, payload: dict) -> None:
    """Emit a JSON progress event to stdout for machine-readable streaming."""
    try:
        event = {
            "event_type": action,
            "payload": payload,
            "timestamp": datetime.now(UTC).isoformat(),
        }
        print(json.dumps(event, default=str))
    except Exception:
        return


def _route_progress_event(
    progress_emitter: ProgressEmitter,
    console: "Console",
    verbose: int,
    action: str,
    payload: dict,
    *,
    progress_json: bool = False,
) -> None:
    """Route progress events to ProgressEmitter with defensive payload parsing."""
    if progress_json and action != "llm_streaming":
        _emit_progress_json(action, payload)
    if dispatch_progress_event(
        EventRouteContext(
            progress_emitter=progress_emitter,
            action=action,
            payload=payload,
        )
    ):
        return
    if is_suppressed_progress_event(action):
        return
    if verbose >= 2:
        console.print(f"[dim]debug: unhandled progress event: {action}[/dim]")
