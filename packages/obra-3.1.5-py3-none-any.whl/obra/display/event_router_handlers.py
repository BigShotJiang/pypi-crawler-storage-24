"""Family handlers for progress event routing."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import Any, Callable

from obra.display._routing import RoutingDispatcher
from obra.display.observability import ProgressEmitter

_log = logging.getLogger(__name__)

# Module-level dispatcher instance (stateless, safe to share).
_routing_dispatcher = RoutingDispatcher()


@dataclass(frozen=True)
class EventRouteContext:
    """Shared routing context for progress-event family handlers."""

    progress_emitter: ProgressEmitter
    action: str
    payload: dict[str, Any]


# ---------------------------------------------------------------------------
# Coerce helpers for _SIMPLE_DISPATCH field specs
# ---------------------------------------------------------------------------

def _noop(x: Any) -> Any:
    """Identity coercion — pass value through unchanged."""
    return x


def _str_or_none(x: Any) -> str | None:
    """Coerce to str if non-None, otherwise return None."""
    return str(x) if x is not None else None


# Sentinel for mutable defaults (dict/list) in the registry.
# When the dispatch loop encounters this, it substitutes a fresh empty dict.
_EMPTY_DICT: dict = {}
_EMPTY_LIST: list = []


def _fresh_dict(x: Any) -> Any:
    """Return *x* unchanged, but if it is the sentinel empty dict, copy it."""
    return {} if x is _EMPTY_DICT else x


def _fresh_list(x: Any) -> Any:
    """Return *x* unchanged, but if it is the sentinel empty list, copy it."""
    return [] if x is _EMPTY_LIST else x


# ---------------------------------------------------------------------------
# Data-driven dispatch registry
# ---------------------------------------------------------------------------
# Structure: action -> (emitter_method_name, [(payload_key, coerce_fn, default), ...])
#
# Each entry replaces a simple ``if action == X: emitter.method(payload.get(...)); return True``
# branch in the old routing functions.  Complex branches (fallback keys, isinstance guards,
# conditional logic beyond the action match) remain in their routing functions.

_SIMPLE_DISPATCH: dict[str, tuple[str, list[tuple[str, Callable, Any]]]] = {
    # -- lifecycle events --
    "phase_started": ("phase_started", [
        ("phase", str, "UNKNOWN"),
        ("context", _noop, None),
    ]),
    "llm_started": ("llm_started", [
        ("purpose", _noop, "LLM invocation"),
    ]),
    "llm_streaming": ("llm_streaming", [
        ("chunk", _noop, ""),
    ]),
    "llm_completed": ("llm_completed", [
        ("summary", _noop, ""),
        ("tokens", _noop, 0),
    ]),
    "stage_started": ("stage_started", [
        ("stage", _noop, "unknown"),
        ("context", _noop, None),
    ]),
    "planning_started": ("planning_started", [
        ("objective", str, ""),
    ]),
    "planning_stage_started": ("planning_stage_started", [
        ("stage", str, "unknown"),
        ("user_label", str, ""),
    ]),
    "stage_completed": ("stage_completed", [
        ("stage", _noop, "unknown"),
        ("result", _noop, None),
        ("duration_ms", _noop, 0),
    ]),
    "stage_failed": ("stage_failed", [
        ("stage", _noop, "unknown"),
        ("error", str, "unknown error"),
        ("duration_ms", _noop, 0),
        ("timeout_s", _noop, None),
    ]),
    # -- derivation events --
    "derivation_step_started": ("derivation_step_started", [
        ("step", _noop, 1),
        ("step_name", _noop, "unknown"),
    ]),
    "epic_derivation_started": ("epic_derivation_started", [
        ("epic_index", int, 1),
        ("epic_count", int, 1),
        ("epic_id", str, "E1"),
        ("epic_title", str, "Untitled"),
    ]),
    "epic_derivation_completed": ("epic_derivation_completed", [
        ("epic_index", int, 1),
        ("epic_count", int, 1),
        ("epic_id", str, "E1"),
        ("epic_title", _str_or_none, None),
        ("stories_derived", int, 0),
        ("tasks_derived", int, 0),
    ]),
    "epic_serialization_batch_started": ("epic_serialization_batch_started", [
        ("epic_count", int, 1),
        ("max_concurrent", int, 4),
    ]),
    "epic_serialization_completed": ("epic_serialization_completed", [
        ("epic_index", int, 1),
        ("epic_count", int, 1),
        ("epic_id", str, "E1"),
        ("epic_title", str, "Untitled"),
        ("items_serialized", int, 0),
    ]),
    "derivation_step_completed": ("derivation_step_completed", [
        ("step", _noop, 1),
        ("step_name", _noop, "unknown"),
        ("duration_ms", _noop, 0),
        ("items_produced", _noop, 0),
        ("prose", _noop, None),
        ("raw_json", _noop, None),
    ]),
    "derivation_step_failed": ("derivation_step_failed", [
        ("step", _noop, 1),
        ("step_name", _noop, "unknown"),
        ("error", _noop, "unknown error"),
        ("duration_ms", _noop, 0),
    ]),
    "derivation_stall_warning": ("derivation_stall_warning", [
        ("step", _noop, 1),
        ("step_name", _noop, "unknown"),
        ("no_output_seconds", _noop, 0),
    ]),
    "derivation_streaming_heartbeat": ("derivation_streaming_heartbeat", [
        ("step", _noop, 1),
        ("elapsed_seconds", _noop, 0),
    ]),
    "derivation_validation_started": ("derivation_validation_started", [
        ("pass", _noop, 1),
        ("max_passes", _noop, 1),
    ]),
    "derivation_validation_completed": ("derivation_validation_completed", [
        ("pass", _noop, 1),
        ("violations", _noop, 0),
        ("passed", _noop, False),
    ]),
    # -- review / execution events --
    "item_started": ("item_started", [
        ("item", _fresh_dict, _EMPTY_DICT),
    ]),
    "item_completed": ("item_completed", [
        ("item", _fresh_dict, _EMPTY_DICT),
        ("result", _noop, None),
    ]),
    "item_skipped": ("item_skipped", [
        ("item", _fresh_dict, _EMPTY_DICT),
    ]),
    "review_no_fixes": ("review_no_fixes", [
        ("item_id", _str_or_none, None),
    ]),
    "fix_completed": ("fix_completed", [
        ("fixed", int, 0),
        ("failed", int, 0),
        ("skipped", int, 0),
    ]),
    # -- session events --
    "story0_started": ("story0_started", []),
    "story0_completed": ("story0_completed", [
        ("blocking_failures", int, 0),
        ("non_blocking_warnings", int, 0),
    ]),
    # -- verification events --
    "code_verify_started": ("code_verify_started", [
        ("item_id", _str_or_none, None),
    ]),
    "verification_preflight_started": ("verification_preflight_started", [
        ("message", str, "Verification tools missing \u2192 running preflight"),
    ]),
    "verification_preflight_installing": ("verification_preflight_installing", [
        ("message", str, "Installing verification tools"),
    ]),
    "verification_preflight_completed": ("verification_preflight_completed", [
        ("message", str, "Verification preflight complete"),
    ]),
    # -- alignment events --
    "story_review_started": ("story_review_started", [
        ("story_id", _noop, ""),
        ("story_title", _noop, ""),
        ("story_index", _noop, 0),
        ("total_stories", _noop, 0),
        ("task_count", _noop, 0),
    ]),
    "story_review_batch_started": ("story_review_batch_started", [
        ("story_count", int, 0),
        ("max_concurrent", int, 4),
    ]),
    "intent_alignment_started": ("intent_alignment_started", [
        ("epic_count", _noop, 0),
        ("story_count", _noop, 0),
    ]),
    "intent_story_batch_started": ("intent_story_batch_started", [
        ("story_count", int, 0),
        ("max_concurrent", int, 4),
    ]),
    "intent_story_assessed": ("intent_story_assessed", [
        ("story_id", _noop, ""),
        ("story_title", _noop, ""),
        ("story_index", _noop, 0),
        ("total_stories", _noop, 0),
        ("status", _noop, "ok"),
        ("note", _noop, ""),
    ]),
    "intent_story_added": ("intent_story_added", [
        ("title", _noop, ""),
        ("parent_id", _noop, None),
    ]),
    "intent_gap_detection_started": ("intent_gap_detection_started", [
        ("story_count", _noop, 0),
    ]),
    "intent_gap_detection_completed": ("intent_gap_detection_completed", [
        ("gaps_found", _noop, False),
        ("missing_count", _noop, 0),
        ("stories_to_add", _noop, 0),
        ("duration_s", _noop, 0.0),
    ]),
    "intent_alignment_completed": ("intent_alignment_completed", [
        ("coverage_status", _noop, ""),
        ("changes_required", _noop, False),
        ("missing_count", _noop, 0),
        ("scope_creep_count", _noop, 0),
        ("stories_added", _noop, 0),
        ("stories_removed", _noop, 0),
        ("duration_s", _noop, 0.0),
    ]),
    "intent_alignment_fixes_applied": ("intent_alignment_fixes_applied", [
        ("stories_added", _fresh_list, _EMPTY_LIST),
        ("stories_removed", _fresh_list, _EMPTY_LIST),
    ]),
    # -- error events --
    "error": ("error", [
        ("message", _noop, "Unknown error"),
        ("hint", _noop, None),
        ("phase", _noop, None),
        ("affected_items", _noop, None),
        ("stack_trace", _noop, None),
        ("raw_response", _noop, None),
    ]),
}


# Sub-events already represented by structured handlers (e.g., [Preflight] messages,
# dependency scan table). Suppress at all verbosity levels to avoid duplicate noise.
_SUPPRESSED_PROGRESS_EVENTS: set[str] = {
    "automation_mode_selected",
    "story0_dependency_resolution_mode",
    "story0_prereq_reclassified",
    "dependency_detect",
    "dependency_present",
    "dependency_prompt",
    "prompt_skipped_reason",
    "dependency_execute",
    "dependency_verify",
    "dependency_report",
    "dependency_mission_summary",
    "invocation_recorded",
    "story0_dependency_resolution_summary",
}


def dispatch_progress_event(context: EventRouteContext) -> bool:
    """Dispatch a progress event through named event families."""
    entry = _SIMPLE_DISPATCH.get(context.action)
    if entry is not None:
        method_name, field_specs = entry
        args: list[Any] = []
        for payload_key, coerce_fn, default in field_specs:
            raw = context.payload.get(payload_key, default)
            try:
                args.append(coerce_fn(raw))
            except (TypeError, ValueError):
                # On coerce failure, produce a safe copy for mutable defaults.
                if default is _EMPTY_DICT:
                    args.append({})
                elif default is _EMPTY_LIST:
                    args.append([])
                else:
                    args.append(default)
        getattr(context.progress_emitter, method_name)(*args)
        return True
    return _routing_dispatcher.dispatch(context)


def is_suppressed_progress_event(action: str) -> bool:
    """Return whether the action should stay silent at every verbosity."""
    return action in _SUPPRESSED_PROGRESS_EVENTS


__all__ = [
    "EventRouteContext",
    "_SIMPLE_DISPATCH",
    "dispatch_progress_event",
    "is_suppressed_progress_event",
]
