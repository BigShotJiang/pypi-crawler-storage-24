"""Structured status payloads for the interactive CLI spinner."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SpinnerStatus:
    """Structured spinner status for action-first inline rendering."""

    label: str
    elapsed_s: int | None = None
    interrupt_hint: str | None = None
    suffix: str | None = None


def _format_elapsed(elapsed_s: int) -> str:
    minutes = max(0, int(elapsed_s)) // 60
    seconds = max(0, int(elapsed_s)) % 60
    return f"{minutes}m {seconds:02d}s"


def _truncate(value: str, width: int) -> str:
    if width <= 0:
        return ""
    if len(value) <= width:
        return value
    if width <= 3:
        return value[:width]
    return value[: width - 3] + "..."


def format_spinner_status(status: SpinnerStatus, width: int | None = None) -> str:
    """Render structured spinner status with width-aware degradation."""
    elapsed = _format_elapsed(status.elapsed_s) if status.elapsed_s is not None else None

    candidates: list[tuple[str | None, str | None]] = [(status.interrupt_hint, status.suffix)]
    if status.interrupt_hint:
        candidates.append((None, status.suffix))
    if status.suffix:
        candidates.append((status.interrupt_hint, None))
    if status.interrupt_hint and status.suffix:
        candidates.append((None, None))

    if width is None:
        interrupt_hint, suffix = candidates[0]
        meta_parts = [part for part in (elapsed, interrupt_hint) if part]
        meta = f" ({' • '.join(meta_parts)})" if meta_parts else ""
        rendered = f"{status.label}{meta}"
        if suffix:
            rendered = f"{rendered} {suffix}"
        return rendered

    truncation_candidates = list(candidates)
    if status.interrupt_hint:
        truncation_candidates.sort(key=lambda item: (item[0] is not None, item[1] is not None))

    for interrupt_hint, suffix in truncation_candidates:
        meta_parts = [part for part in (elapsed, interrupt_hint) if part]
        meta = f" ({' • '.join(meta_parts)})" if meta_parts else ""
        rendered = f"{status.label}{meta}"
        if suffix:
            rendered = f"{rendered} {suffix}"
        if len(rendered) <= width:
            return rendered

    for interrupt_hint, suffix in truncation_candidates:
        meta_parts = [part for part in (elapsed, interrupt_hint) if part]
        meta = f" ({' • '.join(meta_parts)})" if meta_parts else ""
        rendered = f"{status.label}{meta}"
        if suffix:
            rendered = f"{rendered} {suffix}"
        if width > len(meta):
            label_width = max(1, width - len(meta))
            truncated = f"{_truncate(status.label, label_width)}{meta}"
            if len(truncated) <= width:
                return truncated

    return _truncate(status.label, width)
