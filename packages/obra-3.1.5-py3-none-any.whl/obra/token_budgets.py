"""Token Budgets — Context Window and Output Budget Calculations.

Functions for calculating prompt and output token budgets based on model
context windows.  Imports ``MODEL_REGISTRY`` from ``obra.model_lookup``.

Migration Note:
    Extracted from ``obra.model_registry`` as part of REFACTOR-SCHEMAS-P7-001.
    ``obra.model_registry`` re-exports every public symbol for backward
    compatibility.
"""

from obra.model_lookup import MODEL_REGISTRY

# =============================================================================
# Context Budget Calculation
# =============================================================================

# Hard safety limits
MIN_RESERVED_OUTPUT = 30_000  # Always reserve at least 30K for output
MAX_RESERVED_OUTPUT = 100_000  # Never reserve more than 100K (wasteful on huge models)
DEFAULT_CONTEXT_WINDOW = 128_000  # Fallback if model context unknown


def get_model_context_window(provider: str, model: str) -> int | None:
    """Get the context window size for a model.

    Args:
        provider: Provider name (anthropic, google, openai)
        model: Model identifier

    Returns:
        Context window size in tokens, or None if unknown

    Example:
        >>> get_model_context_window("openai", "gpt-5.2")
        400000
        >>> get_model_context_window("anthropic", "sonnet")
        200000
    """
    config = MODEL_REGISTRY.get(provider)
    if not config:
        return None

    model_info = config.models.get(model)
    if model_info:
        return model_info.context_window

    return None


def calculate_max_prompt_tokens(
    context_window: int | None,
    min_reserved: int = MIN_RESERVED_OUTPUT,
    max_reserved: int = MAX_RESERVED_OUTPUT,
) -> int:
    """Calculate maximum tokens for prompt based on model context window.

    Uses tiered percentages with hard safety limits:
    - 500K+: 92% for prompt (8% reserved)
    - 200K-500K: 88% for prompt (12% reserved)
    - 100K-200K: 82% for prompt (18% reserved)
    - <100K: 75% for prompt (25% reserved)

    Safety limits ensure:
    - At least min_reserved tokens for output (default: 30K)
    - At most max_reserved tokens reserved (default: 100K)

    Args:
        context_window: Model's context window size in tokens
        min_reserved: Minimum tokens to reserve for output
        max_reserved: Maximum tokens to reserve for output

    Returns:
        Maximum tokens available for prompt

    Example:
        >>> calculate_max_prompt_tokens(400_000)  # Large-context model
        352000  # 400K * 0.88 = 352K
        >>> calculate_max_prompt_tokens(200_000)  # Claude Sonnet
        176000  # 200K * 0.88 = 176K
        >>> calculate_max_prompt_tokens(50_000)   # Small model
        37500   # 50K * 0.75 = 37.5K
        >>> calculate_max_prompt_tokens(None)     # Unknown
        105600  # 128K fallback * 0.82 = 105K
    """
    # Use fallback if context window unknown
    if context_window is None:
        context_window = DEFAULT_CONTEXT_WINDOW

    # Tiered percentage based on context window size
    if context_window >= 500_000:
        ratio = 0.92  # 8% reserved for 500K+ models
    elif context_window >= 200_000:
        ratio = 0.88  # 12% reserved for 200K-500K models
    elif context_window >= 100_000:
        ratio = 0.82  # 18% reserved for 100K-200K models
    else:
        ratio = 0.75  # 25% reserved for <100K models

    # Calculate based on percentage
    max_prompt = int(context_window * ratio)

    # Apply hard safety limits
    reserved = context_window - max_prompt

    if reserved < min_reserved:
        # Not reserving enough - enforce minimum
        max_prompt = context_window - min_reserved
    elif reserved > max_reserved:
        # Reserving too much - cap it
        max_prompt = context_window - max_reserved

    # Ensure we don't go negative (for very small context windows)
    return max(max_prompt, 0)


def get_max_prompt_tokens_for_model(provider: str, model: str) -> int:
    """Get maximum prompt tokens for a specific model.

    Convenience function that returns a model's explicit input_limit when set;
    otherwise calculates a safe prompt budget from the context window.

    Args:
        provider: Provider name (anthropic, google, openai)
        model: Model identifier

    Returns:
        Maximum tokens available for prompt

    Example:
        >>> get_max_prompt_tokens_for_model("openai", "gpt-5.2")
        258000
        >>> get_max_prompt_tokens_for_model("anthropic", "sonnet")
        176000
    """
    config = MODEL_REGISTRY.get(provider)
    model_info = config.models.get(model) if config else None

    if model_info and model_info.input_limit is not None:
        return model_info.input_limit

    context_window = model_info.context_window if model_info else None
    return calculate_max_prompt_tokens(context_window)


# Default output budget fallback (when model not in registry)
DEFAULT_OUTPUT_BUDGET = 16_384


def get_default_output_budget(provider: str, model: str) -> int:
    """Get recommended output token budget for a model.

    Uses an explicit output_limit when present; otherwise calculates
    the output budget as the reserved space from calculate_max_prompt_tokens()
    (i.e., output_budget = context_window - max_prompt_tokens).

    For models with explicit limits, uses those directly. Otherwise:
    - 50K context: ~30K output (min safety limit applied)
    - 128K context: ~30K output (min safety limit applied)
    - 200K context: ~24K output -> bumped to 30K
    - 400K context: ~48K output
    - 1M context: ~80K output

    Args:
        provider: Provider name (anthropic, google, openai, ollama)
        model: Model identifier

    Returns:
        Recommended output token budget. Falls back to DEFAULT_OUTPUT_BUDGET
        (16K) if model context window is unknown.

    Example:
        >>> get_default_output_budget("anthropic", "sonnet")
        30000  # 200K context, min safety limit
        >>> get_default_output_budget("google", "gemini-2.5-pro")
        80000  # 1M context
        >>> get_default_output_budget("openai", "gpt-5.2")
        128000  # explicit output cap
    """
    config = MODEL_REGISTRY.get(provider)
    model_info = config.models.get(model) if config else None

    if model_info and model_info.output_limit is not None:
        return model_info.output_limit

    context_window = model_info.context_window if model_info else None
    if context_window is None:
        return DEFAULT_OUTPUT_BUDGET

    max_prompt = calculate_max_prompt_tokens(context_window)
    return context_window - max_prompt
