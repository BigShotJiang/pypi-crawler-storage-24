"""HybridSessionLifecycle: session lifecycle collaborator for HybridOrchestrator.

Owns session lifecycle event methods extracted from HybridOrchestrator:
_record_invocation, _log_session_event, _atexit_session_terminal_event,
_force_quit_session_terminal_event.
"""

from __future__ import annotations

import logging
import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

logger = logging.getLogger(__name__)


class HybridSessionLifecycle:
    """Session lifecycle event management.

    Collaborator extracted from HybridOrchestrator to reduce orchestrator
    surface area.  Uses getter callables for dependencies that may be
    replaced after construction (e.g. by tests that swap _event_logger).
    """

    def __init__(
        self,
        *,
        runtime_state_getter: Callable[[], Any],
        event_logger_getter: Callable[[], Any],
        error_handler_getter: Callable[[], Any],
        watchdog_getter: Callable[[], Any],
        emit_progress: Callable[..., None],
    ) -> None:
        self._runtime_state_getter = runtime_state_getter
        self._event_logger_getter = event_logger_getter
        self._error_handler_getter = error_handler_getter
        self._watchdog_getter = watchdog_getter
        self._emit_progress = emit_progress

    def record_invocation(
        self,
        invocation_id: str,
        started_at: float,
        duration_seconds: float,
        termination: str,
        phase_reached: str,
        items_completed: int,
    ) -> None:
        """Record an invocation to session metadata.

        FEAT-SESSION-CLOSEOUT-001: Tracks invocation history for cumulative runtime.
        """
        runtime_state = self._runtime_state_getter()
        if not runtime_state.session_id:
            logger.debug("Cannot record invocation: no session_id")
            return

        try:
            invocation_record = {
                "invocation_id": invocation_id,
                "started_at": datetime.fromtimestamp(started_at, tz=UTC).isoformat(),
                "ended_at": datetime.now(UTC).isoformat(),
                "duration_seconds": duration_seconds,
                "termination": termination,
                "phase_reached": phase_reached,
                "items_completed": items_completed,
            }

            self._emit_progress(
                "invocation_recorded",
                {
                    "invocation": invocation_record,
                    "duration_seconds": duration_seconds,
                },
            )
            logger.debug(
                f"Recorded invocation {invocation_id}: {termination}, "
                f"{duration_seconds:.1f}s, {items_completed} items"
            )
        except Exception as e:
            logger.warning(f"Failed to record invocation: {e}")

    def log_session_event(self, event_type: str, **kwargs: Any) -> None:
        """Log hybrid session event for observability (ISSUE-SAAS-042).

        Thin wrapper around HybridEventLogger — context enrichment (trace_id,
        component, project, invocation) is now auto-injected by the logger via
        set_session_context() / set_trace_context() / set_project().
        """
        kwargs.pop("session_id", None)
        runtime_state = self._runtime_state_getter()
        session_id = runtime_state.session_id or ""

        try:
            self._event_logger_getter().log_event(event_type, session_id=session_id, **kwargs)
            self._watchdog_getter().last_event_time = time.time()
        except Exception as e:
            logger.warning(f"Failed to log hybrid event '{event_type}': {e}")

    def atexit_session_terminal_event(self) -> None:
        """Safety net: emit session_interrupted if session ended without terminal event.

        Registered via atexit.register() to cover force-quit (second Ctrl+C)
        and other abrupt exits where the finally block doesn't complete.
        """
        try:
            self._error_handler_getter()._emit_session_interrupted(reason="atexit_safety_net")
        except Exception:
            pass  # Best-effort — atexit handlers must not raise

    def force_quit_session_terminal_event(self) -> None:
        """Emit an interruption terminal event for second Ctrl+C force-quit."""
        try:
            error_handler = self._error_handler_getter()
            error_handler._emit_session_interrupted(
                reason=error_handler._resolve_interrupt_reason(fallback="sigint_force")
            )
        except Exception:
            pass
