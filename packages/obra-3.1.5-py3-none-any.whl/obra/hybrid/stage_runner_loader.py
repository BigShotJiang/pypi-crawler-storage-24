"""Config-backed registration for extension stage runners."""

from __future__ import annotations

import importlib
import logging
from collections.abc import Callable
from typing import Any, cast

from obra.exceptions import ConfigurationError
from obra.hybrid.stage_runner_registry import StageRunnerFactory, StageRunnerRegistry
from obra.workflow.runner_catalog_sources import load_runner_catalog_sources

logger = logging.getLogger(__name__)


def _import_runner_factory(factory_path: str) -> StageRunnerFactory:
    """Resolve a configured dotted-path or module:attr runner factory."""
    module_path = ""
    attr_name = ""
    if ":" in factory_path:
        module_path, attr_name = factory_path.split(":", 1)
    else:
        module_path, _, attr_name = factory_path.rpartition(".")

    if not module_path or not attr_name:
        msg = (
            f"Invalid stage runner factory path '{factory_path}'. "
            "Use 'package.module:factory' or 'package.module.factory'."
        )
        raise ConfigurationError(msg)

    try:
        module = importlib.import_module(module_path)
    except ImportError as exc:
        msg = f"Unable to import stage runner module '{module_path}': {exc}"
        raise ConfigurationError(msg) from exc

    factory = getattr(module, attr_name, None)
    if not callable(factory):
        msg = (
            f"Configured stage runner factory '{factory_path}' is not callable."
        )
        raise ConfigurationError(msg)
    return cast(StageRunnerFactory, factory)


def register_configured_stage_runners(registry: StageRunnerRegistry) -> int:
    """Register catalog-backed Python runners into the active registry."""
    registrations = load_runner_catalog_sources().entries
    registered_count = 0
    for registration in registrations:
        if registration.kind.value != "python_runner":
            continue
        runner_id = registration.id
        factory_path = registration.activation.factory or ""
        if not runner_id or not factory_path:
            continue
        registry.register_extension_runner(
            runner_id,
            _import_runner_factory(factory_path),
        )
        registered_count += 1
        logger.info(
            "Registered configured stage runner '%s' from '%s'",
            runner_id,
            factory_path,
        )
    return registered_count
