"""Registry for pipeline stage runners."""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from obra.api.protocol import PipelineStageRequest, PipelineStageResult


class StageRunner(Protocol):
    """Executable pipeline stage runner."""

    def execute(self, request: PipelineStageRequest) -> PipelineStageResult:
        """Execute the runner for a pipeline stage request."""


StageRunnerFactory = Callable[[PipelineStageRequest], StageRunner]


class StageRunnerRegistry:
    """Resolve pipeline stage requests into executable runners."""

    def __init__(self) -> None:
        self._runner_kind_factories: dict[str, StageRunnerFactory] = {}
        self._extension_runner_factories: dict[str, StageRunnerFactory] = {}

    def register_runner_kind(
        self,
        runner_kind: str,
        factory: StageRunnerFactory,
    ) -> None:
        """Register a factory for a non-extension runner kind."""
        self._runner_kind_factories[runner_kind] = factory

    def register_extension_runner(
        self,
        runner_id: str,
        factory: StageRunnerFactory,
    ) -> None:
        """Register a concrete extension runner implementation."""
        self._extension_runner_factories[runner_id] = factory

    def resolve(self, request: PipelineStageRequest) -> StageRunner:
        """Resolve a request into an executable runner."""
        if request.runner_kind == "extension_runner":
            factory = self._extension_runner_factories.get(request.runner_id)
            if factory is None:
                raise ValueError(
                    f"Extension runner '{request.runner_id}' is not registered"
                )
            return factory(request)

        factory = self._runner_kind_factories.get(request.runner_kind)
        if factory is None:
            raise ValueError(f"Unsupported runner_kind: {request.runner_kind}")
        return factory(request)
