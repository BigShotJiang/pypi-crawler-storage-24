"""Built-in review-agent adapter for pipeline stage runners."""

from __future__ import annotations

import time
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.agents.base import AgentIssue, AgentResult, BaseAgent
from obra.api.protocol import PipelineStageRequest, PipelineStageResult


class BuiltinAgentStageRunner:
    """Adapter that executes existing BaseAgent implementations as stage runners."""

    def __init__(
        self,
        working_dir: Path,
        *,
        agent_factory: Callable[[str], BaseAgent],
        llm_config: dict[str, Any] | None = None,
        domain: Any = None,
        log_event: Callable[..., None] | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._agent_factory = agent_factory
        self._llm_config = llm_config
        self._domain = domain
        self._log_event = log_event

    def execute(self, request: PipelineStageRequest) -> PipelineStageResult:
        """Execute a built-in review agent through the stage-runner contract."""
        file_targets = self._extract_explicit_file_targets(request)
        if not file_targets:
            finding = {
                "id": "builtin_agent_adapter_requires_file_targets",
                "title": "Explicit file targets required",
                "description": (
                    "The built-in review runner requires explicit file targets from "
                    "typed stage_output_artifacts or workflow_accumulation_artifact."
                ),
                "priority": "P1",
            }
            return PipelineStageResult(
                stage_name=request.stage_name,
                stage_execution_id=request.stage_execution_id,
                execution_status="failed",
                outcome="blocked",
                findings=[finding],
                routing_signal={
                    "recommended_action": "block",
                    "reason": "Built-in review runner requires explicit file targets",
                    "metadata": {"runner_id": request.runner_id},
                },
                loop_signal={
                    "recommended_action": "block",
                    "reason": "No explicit file targets available",
                    "current_iteration": request.iteration,
                    "max_iterations": request.max_iterations,
                    "metadata": {"runner_id": request.runner_id},
                },
                metadata={
                    "runner_id": request.runner_id,
                    "runner_kind": request.runner_kind,
                    "domain": str(self._domain) if self._domain is not None else None,
                    "file_target_source": "none",
                },
                iteration=request.iteration,
                duration_s=0.0,
            )

        start_time = time.time()
        agent = self._agent_factory(request.runner_id)
        agent_result = agent.analyze(
            item_id=request.stage_execution_id or f"{request.stage_name}_{request.iteration}",
            changed_files=file_targets,
            timeout_ms=request.timeout_s * 1000,
        )
        return self._map_agent_result(request, agent_result, time.time() - start_time)

    def _extract_explicit_file_targets(
        self,
        request: PipelineStageRequest,
    ) -> list[str]:
        """Collect explicit file targets from the canonical request context."""
        payload = request.context.payload if isinstance(request.context.payload, dict) else {}
        file_targets: list[str] = []

        for artifact in request.stage_output_artifacts:
            file_targets.extend(self._artifact_file_targets(artifact))
        if request.workflow_accumulation_artifact is not None:
            file_targets.extend(
                self._artifact_file_targets(request.workflow_accumulation_artifact)
            )

        payload_stage_artifacts = payload.get("stage_output_artifacts", [])
        if isinstance(payload_stage_artifacts, list):
            for artifact in payload_stage_artifacts:
                if not isinstance(artifact, dict):
                    continue
                file_targets.extend(self._artifact_file_targets(artifact))
        payload_accumulation_artifact = payload.get("workflow_accumulation_artifact")
        if isinstance(payload_accumulation_artifact, dict):
            file_targets.extend(self._artifact_file_targets(payload_accumulation_artifact))

        history = request.context.history if isinstance(request.context.history, list) else []
        for history_entry in history:
            if not isinstance(history_entry, dict):
                continue
            for artifact in history_entry.get("stage_output_artifacts", []) or []:
                if not isinstance(artifact, dict):
                    continue
                file_targets.extend(self._artifact_file_targets(artifact))
            accumulation_artifact = history_entry.get("workflow_accumulation_artifact")
            if isinstance(accumulation_artifact, dict):
                file_targets.extend(self._artifact_file_targets(accumulation_artifact))

        seen: set[str] = set()
        unique_targets: list[str] = []
        for target in file_targets:
            if target not in seen:
                seen.add(target)
                unique_targets.append(target)
        return unique_targets

    def _artifact_file_targets(self, artifact: Any) -> list[str]:
        """Extract explicit file targets from a typed stage-output artifact."""
        values: list[str] = []
        if hasattr(artifact, "file_targets"):
            values.extend(getattr(artifact, "file_targets", []) or [])
        if hasattr(artifact, "files_changed"):
            values.extend(getattr(artifact, "files_changed", []) or [])
        if hasattr(artifact, "path"):
            path = str(getattr(artifact, "path", "") or "").strip()
            if path:
                values.append(path)
        if isinstance(artifact, dict):
            for raw in artifact.get("file_targets", []) or []:
                values.append(raw)
            for raw in artifact.get("files_changed", []) or []:
                values.append(raw)
            path = str(artifact.get("path", "") or "").strip()
            if path:
                values.append(path)

        targets: list[str] = []
        for raw in values:
            target = str(raw).strip()
            if target:
                targets.append(target)
        return targets

    def _map_agent_result(
        self,
        request: PipelineStageRequest,
        agent_result: AgentResult | dict[str, Any],
        duration_s: float,
    ) -> PipelineStageResult:
        """Map BaseAgent output into canonical PipelineStageResult fields."""
        status = self._get_agent_status(agent_result)
        findings = self._extract_findings(agent_result)
        execution_status = "complete"
        outcome = "passed"
        if status == "timeout":
            execution_status = "timeout"
            outcome = "blocked"
        elif status in {"error", "fail", "failed"}:
            execution_status = "failed"
            outcome = "error" if not findings else "issues_found"
        elif findings:
            outcome = "issues_found"

        metadata = {
            "runner_id": request.runner_id,
            "runner_kind": request.runner_kind,
            "agent_status": status,
            "agent_type": self._get_agent_type(agent_result),
            "scores": self._get_scores(agent_result),
            "error": self._get_error(agent_result),
            "execution_time_ms": self._get_execution_time_ms(agent_result),
            "duration_s": duration_s,
            "llm_configured": self._llm_config is not None,
            "domain_present": self._domain is not None,
            "log_event_configured": self._log_event is not None,
        }

        stage_output_artifacts = self._get_stage_output_artifacts(agent_result)
        workflow_accumulation_artifact = self._get_workflow_accumulation_artifact(
            agent_result
        )

        return PipelineStageResult(
            stage_name=request.stage_name,
            stage_execution_id=request.stage_execution_id,
            execution_status=execution_status,
            outcome=outcome,
            findings=findings,
            stage_output_artifacts=stage_output_artifacts,
            workflow_accumulation_artifact=workflow_accumulation_artifact,
            candidate_stage_output_artifacts=stage_output_artifacts,
            candidate_workflow_accumulation_artifact=workflow_accumulation_artifact,
            metadata=metadata,
            iteration=request.iteration,
            duration_s=duration_s,
        )

    def _extract_findings(self, agent_result: AgentResult | dict[str, Any]) -> list[dict[str, Any]]:
        """Normalize agent issues into protocol dicts."""
        raw_issues = (
            agent_result.issues
            if isinstance(agent_result, AgentResult)
            else agent_result.get("issues", [])
        )
        findings: list[dict[str, Any]] = []
        for issue in raw_issues or []:
            if isinstance(issue, AgentIssue):
                findings.append(issue.to_dict())
            elif hasattr(issue, "to_dict"):
                findings.append(issue.to_dict())
            elif isinstance(issue, dict):
                findings.append(issue)
        return findings

    def _get_agent_status(self, agent_result: AgentResult | dict[str, Any]) -> str:
        if isinstance(agent_result, AgentResult):
            return str(agent_result.status)
        return str(agent_result.get("status", "complete"))

    def _get_agent_type(self, agent_result: AgentResult | dict[str, Any]) -> str | None:
        if isinstance(agent_result, AgentResult):
            return agent_result.agent_type.value
        agent_type = agent_result.get("agent_type")
        return str(agent_type) if agent_type is not None else None

    def _get_scores(self, agent_result: AgentResult | dict[str, Any]) -> dict[str, Any]:
        if isinstance(agent_result, AgentResult):
            return dict(agent_result.scores)
        scores = agent_result.get("scores", {})
        return scores if isinstance(scores, dict) else {}

    def _get_error(self, agent_result: AgentResult | dict[str, Any]) -> str | None:
        if isinstance(agent_result, AgentResult):
            return agent_result.error
        error = agent_result.get("error")
        return str(error) if error is not None else None

    def _get_execution_time_ms(self, agent_result: AgentResult | dict[str, Any]) -> int:
        if isinstance(agent_result, AgentResult):
            return int(agent_result.execution_time_ms or 0)
        return int(agent_result.get("execution_time_ms", 0) or 0)

    def _get_stage_output_artifacts(
        self,
        agent_result: AgentResult | dict[str, Any],
    ) -> list[dict[str, Any]]:
        if isinstance(agent_result, AgentResult):
            return []
        artifacts = agent_result.get("stage_output_artifacts", [])
        if not isinstance(artifacts, list):
            return []
        return [artifact for artifact in artifacts if isinstance(artifact, dict)]

    def _get_workflow_accumulation_artifact(
        self,
        agent_result: AgentResult | dict[str, Any],
    ) -> dict[str, Any] | None:
        if isinstance(agent_result, AgentResult):
            return None
        artifact = agent_result.get("workflow_accumulation_artifact")
        return artifact if isinstance(artifact, dict) else None
