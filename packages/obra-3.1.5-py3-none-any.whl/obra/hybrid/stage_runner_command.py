"""Declarative command-runner adapter for pipeline stages."""

from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path
from typing import Any

from obra.api.protocol import PipelineStageRequest, PipelineStageResult


class CommandStageRunner:
    """Execute command-runner catalog entries via a declarative argv contract."""

    def __init__(self, working_dir: Path) -> None:
        self._working_dir = working_dir

    def execute(self, request: PipelineStageRequest) -> PipelineStageResult:
        """Execute the configured command-runner for a stage request."""
        activation = {}
        if isinstance(request.context.runtime_metadata, dict):
            activation = request.context.runtime_metadata.get("runner_activation", {})
        if not isinstance(activation, dict):
            activation = {}

        command = activation.get("command")
        env_contract = activation.get("env_contract", [])
        if not isinstance(command, list) or not command:
            return self._failure_result(
                request,
                "installability_failure",
                "command_runner request is missing activation.command metadata",
            )

        if not all(isinstance(item, str) and item.strip() for item in command):
            return self._failure_result(
                request,
                "installability_failure",
                "command_runner activation.command must be a non-empty argv list",
            )

        portability = str(
            request.context.runtime_metadata.get("runner_portability", "")
        ) if isinstance(request.context.runtime_metadata, dict) else ""
        if portability == "portable" and os.path.isabs(command[0]):
            return self._failure_result(
                request,
                "installability_failure",
                "portable command runners may not use absolute executable paths",
            )

        allowed_env = set(env_contract) if isinstance(env_contract, list) else set()
        process_env = os.environ.copy()
        stage_context_path = request.context.working_directory or str(self._working_dir)
        provided_env = {
            "OBRA_STAGE_CONTEXT_PATH": stage_context_path,
        }
        for key, value in provided_env.items():
            if key in allowed_env:
                process_env[key] = value

        start_time = time.time()
        try:
            completed = subprocess.run(  # noqa: S603
                command,
                cwd=request.context.working_directory or str(self._working_dir),
                env=process_env,
                capture_output=True,
                text=True,
                check=False,
            )
        except FileNotFoundError:
            return self._failure_result(
                request,
                "installability_failure",
                f"Executable not found for command runner '{request.runner_id}'",
            )

        duration_s = time.time() - start_time
        outcome = "passed" if completed.returncode == 0 else "error"
        execution_status = "complete" if completed.returncode == 0 else "failed"
        findings = []
        if completed.returncode != 0:
            findings.append(
                {
                    "id": "command_runner_failed",
                    "title": "Command runner failed",
                    "description": completed.stderr.strip() or completed.stdout.strip(),
                    "priority": "P1",
                }
            )
        return PipelineStageResult(
            stage_name=request.stage_name,
            stage_execution_id=request.stage_execution_id,
            execution_status=execution_status,
            outcome=outcome,
            findings=findings,
            routing_signal={
                "recommended_action": "continue" if completed.returncode == 0 else "block"
            },
            loop_signal={
                "recommended_action": "continue" if completed.returncode == 0 else "block",
                "current_iteration": request.iteration,
                "max_iterations": request.max_iterations,
            },
            runner_id=request.runner_id,
            runner_version=request.runner_version,
            runner_selector=request.runner_selector,
            metadata={
                "runner_id": request.runner_id,
                "runner_kind": request.runner_kind,
                "runner_version": request.runner_version,
                "runner_selector": request.runner_selector,
                "command": command,
                "stdout": completed.stdout,
                "stderr": completed.stderr,
                "exit_code": completed.returncode,
                "duration_s": duration_s,
            },
            verdict="sound" if completed.returncode == 0 else "issues",
            iteration=request.iteration,
            duration_s=duration_s,
        )

    def _failure_result(
        self,
        request: PipelineStageRequest,
        code: str,
        message: str,
    ) -> PipelineStageResult:
        return PipelineStageResult(
            stage_name=request.stage_name,
            stage_execution_id=request.stage_execution_id,
            execution_status="failed",
            outcome="blocked",
            findings=[
                {
                    "id": code,
                    "title": "Runner installability failure",
                    "description": message,
                    "priority": "P1",
                }
            ],
            routing_signal={"recommended_action": "block"},
            loop_signal={
                "recommended_action": "block",
                "current_iteration": request.iteration,
                "max_iterations": request.max_iterations,
            },
            runner_id=request.runner_id,
            runner_version=request.runner_version,
            runner_selector=request.runner_selector,
            runner_diagnostic={
                "code": code,
                "message": message,
                "runner_id": request.runner_id,
                "requested_selector": request.runner_selector,
                "requested_version": request.runner_version,
            },
            metadata={
                "runner_id": request.runner_id,
                "runner_kind": request.runner_kind,
                "runner_version": request.runner_version,
                "runner_selector": request.runner_selector,
                "runner_diagnostic": {
                    "code": code,
                    "message": message,
                    "runner_id": request.runner_id,
                    "requested_selector": request.runner_selector,
                    "requested_version": request.runner_version,
                },
            },
            verdict="issues",
            iteration=request.iteration,
            duration_s=0.0,
        )
