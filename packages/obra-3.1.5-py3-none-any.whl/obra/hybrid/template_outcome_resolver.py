"""Template outcome resolution for the TemplateEditPipeline.

Encapsulates retry-vs-fallback-vs-recovery decisions extracted from
TemplateEditPipeline. The pipeline composes this collaborator and
delegates outcome resolution after each attempt.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import TYPE_CHECKING, Any

from obra.llm.error_classifier import (
    _classify_failure_class,
    _extract_cli_error_details,
)

if TYPE_CHECKING:
    from obra.hybrid.template_edit_pipeline import _ExecutionContext, _ParsedAttempt

logger = logging.getLogger(__name__)


class TemplateOutcomeResolver:
    """Resolves validation, parse-failure, and exception outcomes for template edits.

    This class owns the four outcome-resolution methods that were previously
    inlined in TemplateEditPipeline. It delegates prompt building and success
    finalization back to the pipeline via injected callables.

    Args:
        log_event: Telemetry callback (mirrors _emit_log_event).
        schedule_cleanup: Template file cleanup callback.
        build_success_result: Delegates back to pipeline's _build_success_result.
        build_validation_retry_prompt: Delegates back to pipeline's _build_validation_retry_prompt.
        build_json_retry_prompt: Delegates back to pipeline's _build_json_retry_prompt.
        output_format: Pipeline's output format ('json' or 'text').
        action_name: Pipeline's action identifier (e.g. 'examine', 'derive').
        try_recover_from_stdout: Stdout recovery callable (initially pipeline's
            _try_recover_from_stdout, later replaced by json_parser reference).
    """

    def __init__(
        self,
        *,
        log_event: Callable[..., None] | None,
        schedule_cleanup: Callable[[Path, bool], None],
        build_success_result: Callable[..., tuple[Any, dict[str, Any]]],
        build_validation_retry_prompt: Callable[..., str],
        build_json_retry_prompt: Callable[..., str],
        output_format: str,
        action_name: str,
        try_recover_from_stdout: Callable[..., dict[str, Any] | None] | None = None,
    ) -> None:
        self._log_event = log_event
        self._cleanup = schedule_cleanup
        self._build_success_result = build_success_result
        self._build_validation_retry_prompt = build_validation_retry_prompt
        self._build_json_retry_prompt = build_json_retry_prompt
        self._output_format = output_format
        self._action_name = action_name
        self._try_recover_from_stdout = try_recover_from_stdout

    def _emit_log_event(self, event_type: str, **kwargs: Any) -> None:
        if self._log_event:
            try:
                self._log_event(event_type, **kwargs)
            except Exception as e:
                logger.debug(f"Failed to log event '{event_type}': {e}")

    def resolve_validation(
        self,
        *,
        attempt_index: int,
        max_attempts: int,
        parsed_attempt: _ParsedAttempt,
        is_valid: bool,
        error_msg: str | None,
        base_prompt: str,
        context: _ExecutionContext,
        template_content: dict[str, Any] | str,
        validator: Callable[[dict | str], tuple[bool, str | None]],
        fallback_fn: Callable[[], Any],
        llm_config: dict[str, Any],
    ) -> tuple[str | None, tuple[Any, dict[str, Any]] | None]:
        """Resolve validation success, retry, stdout recovery, or fallback."""
        attempt_number = attempt_index + 1
        if is_valid:
            return (None, self._build_success_result(
                attempt_index=attempt_index,
                parsed_attempt=parsed_attempt,
                context=context,
            ))

        self._emit_log_event("parse_error", error_msg=error_msg, attempt=attempt_number)
        if parsed_attempt.attempt_content.content_unchanged:
            self._emit_log_event(
                "template_unchanged_rejected",
                attempt=attempt_number,
                template_path=str(context.template_path),
                error_msg=error_msg,
            )
            recovered = None
            if self._try_recover_from_stdout is not None:
                recovered = self._try_recover_from_stdout(
                    parsed_attempt.attempt_content.llm_stdout,
                    template_content,
                    validator,
                )
            if recovered is not None:
                logger.info(
                    "ISSUE-HYBRID-056: Recovered valid output from stdout "
                    "(template unchanged, stdout had parseable data)"
                )
                self._emit_log_event(
                    "template_unchanged_stdout_recovered",
                    attempt=attempt_number,
                    recovered_keys=sorted(recovered.keys()),
                    model=llm_config.get("model", "unknown"),
                )
                self._cleanup(context.template_path, False)
                return (
                    None,
                    (
                        recovered,
                        {"status": "stdout_recovery", "attempts": attempt_number},
                    ),
                )

            logger.warning(
                "ISSUE-HYBRID-056: Deterministic unchanged failure "
                "(valid_output_no_file_edit) - skipping %d remaining retries and using fallback",
                max(0, max_attempts - attempt_index - 1),
            )
            self._emit_log_event(
                "template_unchanged_short_circuit",
                attempt=attempt_number,
                max_retries=max_attempts,
                skipped_retries=max(0, max_attempts - attempt_index - 1),
                failure_class="valid_output_no_file_edit",
                model=llm_config.get("model", "unknown"),
            )
            self._cleanup(context.template_path, True)
            return (
                None,
                (
                    fallback_fn(),
                    {
                        "status": "template_fallback",
                        "attempts": attempt_number,
                        "failure_class": "valid_output_no_file_edit",
                    },
                ),
            )

        if attempt_number < max_attempts:
            next_prompt = self._build_validation_retry_prompt(
                base_prompt=base_prompt,
                context=context,
                error_msg=error_msg,
            )
            logger.warning(
                "Validation failed (attempt %d/%d): %s",
                attempt_number,
                max_attempts,
                error_msg,
            )
            self._emit_log_event(
                "retry_attempt",
                reason="validation_error",
                error_msg=error_msg,
                new_prompt_preview=next_prompt[:100],
            )
            return (next_prompt, None)

        logger.error("Validation failed after %d attempts. Using fallback.", max_attempts)
        self._cleanup(context.template_path, True)
        return (
            None,
            (fallback_fn(), {"status": "template_fallback", "attempts": max_attempts}),
        )

    def resolve_json_parse_failure(
        self,
        *,
        attempt_index: int,
        max_attempts: int,
        error: json.JSONDecodeError,
        base_prompt: str,
        context: _ExecutionContext,
        fallback_fn: Callable[[], Any],
    ) -> tuple[str | None, tuple[Any, dict[str, Any]] | None]:
        """Resolve JSON parse retry vs fallback for one attempt."""
        attempt_number = attempt_index + 1
        failure_class = getattr(error, "_obra_failure_class", None)
        self._emit_log_event(
            "parse_error",
            error_msg=f"JSON parse error: {error!s}",
            attempt=attempt_number,
            failure_class=failure_class,
        )
        if attempt_number < max_attempts:
            next_prompt = self._build_json_retry_prompt(
                base_prompt=base_prompt,
                context=context,
                error=error,
            )
            logger.warning("JSON parse error (attempt %d/%d): %s", attempt_number, max_attempts, error)
            self._emit_log_event(
                "retry_attempt",
                reason="json_parse_error",
                error_msg=str(error),
                new_prompt_preview=next_prompt[:100],
            )
            return (next_prompt, None)

        logger.exception("JSON parse error after %d attempts. Using fallback.", max_attempts)
        self._cleanup(context.template_path, True)
        metadata = {"status": "template_fallback", "attempts": max_attempts}
        if failure_class is not None:
            metadata["failure_class"] = failure_class
        return (
            None,
            (fallback_fn(), metadata),
        )

    def _recover_modified_template_after_exception(
        self,
        *,
        attempt_index: int,
        context: _ExecutionContext,
        validator: Callable[[dict | str], tuple[bool, str | None]],
        error: Exception,
    ) -> tuple[Any, dict[str, Any]] | None:
        """Recover valid file edits even when the invoke layer raised."""
        try:
            current_content = context.template_path.read_text(encoding="utf-8")
        except Exception:
            return None
        if current_content == context.initial_content:
            return None

        recovered_data: dict[str, Any] | str | None = None
        if self._output_format == "text":
            recovered_data = current_content
        else:
            try:
                recovered_data = json.loads(current_content)
            except json.JSONDecodeError:
                return None

        try:
            is_valid, _ = validator(recovered_data)
        except Exception:
            return None
        if not is_valid:
            return None

        self._emit_log_event(
            "template_error_recovered",
            attempt=attempt_index + 1,
            original_error=str(error),
            recovery="file_modified_valid",
            action=self._action_name,
        )
        logger.info(
            "FIX-EMPTY-STDOUT-001: Recovered valid template despite exception: %s",
            error,
        )
        self._cleanup(context.template_path, False)
        status = (
            "template_error_recovered"
            if attempt_index == 0
            else "template_error_retry_recovered"
        )
        return (recovered_data, {"status": status, "attempts": attempt_index + 1})

    def resolve_exception(
        self,
        *,
        attempt_index: int,
        max_attempts: int,
        error: Exception,
        llm_config: dict[str, Any],
        context: _ExecutionContext,
        validator: Callable[[dict | str], tuple[bool, str | None]],
        fallback_fn: Callable[[], Any],
    ) -> tuple[Any, dict[str, Any]] | None:
        """Resolve fail-fast model errors, recovery, retry, or fallback."""
        provider = str(llm_config.get("provider", "unknown"))
        model = str(llm_config.get("model", "unknown"))
        details = _extract_cli_error_details(str(error), "", provider)
        failure_class = _classify_failure_class(
            status="error",
            error_message=details.message,
        )
        if self._is_model_not_found_error(str(error)):
            message = self._build_model_not_found_message(llm_config, str(error))
            self._emit_log_event(
                "template_error",
                error_msg=message,
                attempt=attempt_index + 1,
                failure_class=failure_class,
                provider=provider,
                model=model,
                action=self._action_name,
                status_code=details.status_code,
                request_id=details.request_id,
            )
            logger.exception(message)
            self._cleanup(context.template_path, True)
            raise RuntimeError(message) from error

        recovered = self._recover_modified_template_after_exception(
            attempt_index=attempt_index,
            context=context,
            validator=validator,
            error=error,
        )
        if recovered is not None:
            return recovered

        self._emit_log_event(
            "template_error",
            error_msg=details.message or str(error),
            raw_error=str(error),
            attempt=attempt_index + 1,
            failure_class=failure_class,
            provider=provider,
            model=model,
            action=self._action_name,
            status_code=details.status_code,
            request_id=details.request_id,
        )
        if attempt_index + 1 < max_attempts:
            logger.warning(
                "Template edit failed (attempt %d/%d): %s",
                attempt_index + 1,
                max_attempts,
                error,
            )
            return None

        logger.exception("Template edit failed after %d attempts. Using fallback.", max_attempts)
        self._cleanup(context.template_path, True)
        return (
            fallback_fn(),
            {
                "status": "template_error",
                "attempts": max_attempts,
                "failure_class": failure_class,
            },
        )

    @staticmethod
    def _is_model_not_found_error(message: str) -> bool:
        """Return True when CLI/API reported unknown model."""
        text = message.lower()
        return (
            "model_not_found" in text
            or ("requested model" in text and "does not exist" in text)
            or "unknown model" in text
        )

    def _build_model_not_found_message(self, llm_config: dict[str, Any], detail: str) -> str:
        provider = str(llm_config.get("provider", "unknown"))
        model = str(llm_config.get("model", "unknown"))
        return (
            f"Configured model '{model}' is not available for provider '{provider}'. "
            "Failing fast to avoid repeated retries. "
            "Fix config (for example via 'obra config show llm' and set an available model), "
            f"then retry. Detail: {detail}"
        )
