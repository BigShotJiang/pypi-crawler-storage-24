"""Explicit runtime hooks for dispatch-owned handler context mutation."""

from __future__ import annotations

from typing import Any, Protocol, runtime_checkable


@runtime_checkable
class ParentSpanAwareHandler(Protocol):
    """Handler capability for subphase span propagation."""

    def set_parent_span_id(self, parent_span_id: str | None) -> None: ...


@runtime_checkable
class ObjectiveAwareHandler(Protocol):
    """Handler capability for objective propagation."""

    def set_objective(self, objective: str) -> None: ...


@runtime_checkable
class VerificationToolsAwareHandler(Protocol):
    """Handler capability for verification-tool propagation."""

    def set_verification_tools(self, tools: list[dict[str, Any]]) -> None: ...


@runtime_checkable
class ReviewIterationAwareHandler(Protocol):
    """Handler capability for exposing review-cycle counters."""

    def get_review_iteration(self, item_id: str) -> int: ...


def apply_parent_span_id(handler: Any, parent_span_id: str | None) -> None:
    """Bind subphase span context through the explicit handler hook when present."""
    setter = getattr(type(handler), "set_parent_span_id", None)
    if callable(setter):
        handler.set_parent_span_id(parent_span_id)
        return
    if hasattr(handler, "_parent_span_id"):
        handler._parent_span_id = parent_span_id


def apply_objective(handler: Any, objective: str | None) -> None:
    """Bind objective context through the explicit handler hook when present."""
    if not objective:
        return
    setter = getattr(type(handler), "set_objective", None)
    if callable(setter):
        handler.set_objective(objective)
        return
    if hasattr(handler, "_objective"):
        handler._objective = objective


def apply_verification_tools(handler: Any, tools: list[dict[str, Any]]) -> None:
    """Bind verification tools through the explicit handler hook when present."""
    setter = getattr(type(handler), "set_verification_tools", None)
    if callable(setter):
        handler.set_verification_tools(tools)
        return
    if hasattr(handler, "_verification_tools"):
        handler._verification_tools = tools


def get_review_iteration(handler: Any, item_id: str) -> int:
    """Read review-cycle iteration through the explicit handler hook when present."""
    getter = getattr(type(handler), "get_review_iteration", None)
    if callable(getter):
        return int(handler.get_review_iteration(item_id))
    counters = getattr(handler, "_iteration_counter", {})
    if isinstance(counters, dict):
        return int(counters.get(item_id, 0))
    return 0
