"""Deduplicated verification tool configuration for dispatch.

Replaces duplicate config dicts at the execute and fix dispatch paths.
"""

from __future__ import annotations

from copy import deepcopy
from typing import Any

DEFAULT_VERIFICATION_TOOL_CONFIGS: dict[str, dict[str, Any]] = {
    "tests": {
        "name": "tests",
        "category": "tests",
        "command": "pytest {files}",
        "parser": "llm",
        "patterns": ["test_*.py", "*_test.py"],
    },
    "lint": {
        "name": "lint",
        "category": "lint",
        "command": "ruff check {files}",
        "parser": "llm",
        "patterns": ["*.py"],
    },
    "typecheck": {
        "name": "typecheck",
        "category": "typecheck",
        "command": "mypy {files}",
        "parser": "llm",
        "patterns": ["*.py"],
    },
}

_CATEGORY_TO_DISCOVERY_KEY: dict[str, str] = {
    "tests": "test",
    "lint": "lint",
    "typecheck": "typecheck",
}


def build_fix_handler_tools(
    available_tools: list[str],
    discovery_data: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Return tool config dicts for the requested tool categories.

    Returns copies to prevent mutation of the module-level constant.

    Args:
        available_tools: List of category names (e.g. ['tests', 'lint']).
        discovery_data: Optional ToolingDiscovery cache payload.

    Returns:
        List of tool config dicts for recognized categories.
    """
    discovery_verification = (
        discovery_data.get("verification", {})
        if isinstance(discovery_data, dict)
        else {}
    )
    if not isinstance(discovery_verification, dict):
        discovery_verification = {}

    tool_configs: list[dict[str, Any]] = []
    for category in available_tools:
        default_config = DEFAULT_VERIFICATION_TOOL_CONFIGS.get(category)
        if default_config is None:
            continue

        discovery_category = _CATEGORY_TO_DISCOVERY_KEY.get(category)
        discovery_entry = (
            discovery_verification.get(discovery_category, {})
            if discovery_category
            else {}
        )
        if not isinstance(discovery_entry, dict):
            discovery_entry = {}

        discovery_command = str(discovery_entry.get("command", "") or "").strip()
        if discovery_command:
            tool_config = deepcopy(default_config)
            tool_config["command"] = discovery_command
            tool_config["patterns"] = deepcopy(discovery_entry.get("patterns", []))
            tool_config["scope_type"] = str(
                discovery_entry.get("scope_type", "unscoped") or "unscoped"
            ).lower()
            tool_config["target_files"] = deepcopy(
                discovery_entry.get(
                    "target_files",
                    discovery_entry.get("targets", tool_config.get("patterns", [])),
                )
            )
            tool_config["discovery_source"] = "discovery"
            tool_configs.append(tool_config)
            continue

        fallback_config = deepcopy(default_config)
        fallback_config["discovery_source"] = "default"
        tool_configs.append(fallback_config)

    return tool_configs
