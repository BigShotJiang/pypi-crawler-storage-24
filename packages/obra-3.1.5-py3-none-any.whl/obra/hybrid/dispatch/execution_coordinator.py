"""Execution action coordination extracted from ActionDispatcher."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any, cast

from obra.api.protocol import ExecutionRequest, ExecutionStatus
from obra.core.interrupts import GracefulInterrupt, interrupt_requested
from obra.hybrid.dispatch.context import (
    ExecutionState,
    HandlerFactoryProtocol,
    ObservabilityContext,
    PhaseControl,
)
from obra.hybrid.dispatch.dispatcher_support import ResolvedItemOutcome
from obra.hybrid.dispatch.fix_coordinator import FixActionCoordinator
from obra.hybrid.dispatch.handler_runtime import apply_parent_span_id
from obra.hybrid.dispatch.item_skip import ItemSkipManager

logger = logging.getLogger(__name__)


class ExecutionActionCoordinator:
    """Own execute dispatch, skip handling, item lifecycle events, and terminal outcome resolution."""

    def __init__(
        self,
        *,
        observability: ObservabilityContext,
        phase_control: PhaseControl,
        execution_state: ExecutionState,
        handler_factory: HandlerFactoryProtocol,
        skip_manager: ItemSkipManager,
        fix_coordinator: FixActionCoordinator,
        log_phase_failed: Callable[..., None],
    ) -> None:
        self._obs = observability
        self._phase = phase_control
        self._state = execution_state
        self._factory = handler_factory
        self._skip_manager = skip_manager
        self._fix = fix_coordinator
        self._log_phase_failed = log_phase_failed

    def dispatch(self, handler: Any, payload: dict[str, Any]) -> dict[str, Any]:
        """Execute EXECUTE with skip handling, item lifecycle, and terminal outcome resolution."""
        execute_req = ExecutionRequest.from_payload(payload)
        subphase_start = self._phase.start_subphase("execute")
        apply_parent_span_id(handler, self._phase.subphase_span_id_getter())
        if execute_req.current_item and execute_req.current_item.get("id"):
            self._state.set_last_item_id(execute_req.current_item.get("id"))

        skip_result: dict[str, Any] | None = None
        if execute_req.current_item:
            skip_result = self._skip_manager.check_completed_item_skip(
                execute_req.current_item
            )
            if skip_result is None:
                skip_result = self._skip_manager.check_resume_duplicate_skip(
                    execute_req.current_item
                )
            if skip_result is None and execute_req.plan_items:
                skip_result = self._skip_manager.check_container_skip(
                    execute_req.current_item,
                    cast(list[dict[str, Any]], execute_req.plan_items),
                )
        if skip_result is not None:
            self._phase.complete_subphase("execute", subphase_start, status="skipped")
            return skip_result

        # Compatibility: some server versions return ActionType.EXECUTE with fix payload
        # (item_id + issues_to_fix) instead of ActionType.FIX.
        if execute_req.current_item is None and payload.get("issues_to_fix"):
            return self._fix.handle_execute_fix_compat(
                payload,
                subphase_start=subphase_start,
            )

        # S3.T5: Emit item_started event
        if execute_req.current_item:
            exec_ctx = execute_req.execution_context
            should_emit = True
            current_item_id = execute_req.current_item.get("id")

            # Dedupe using execution_context if available
            if exec_ctx:
                ctx_key = (
                    f"{exec_ctx.get('item_id')}:"
                    f"{exec_ctx.get('iteration')}:"
                    f"{exec_ctx.get('attempt')}"
                )
                if ctx_key in self._state.locally_started_items:
                    should_emit = False
                    # SESSION-92257c4c: Emit item_restarted instead of
                    # silently dropping the duplicate item_started.
                    logger.debug(
                        "Duplicate item_started detected — emitting item_restarted: %s",
                        ctx_key,
                    )
                    self._obs.log_session_event(
                        "item_restarted",
                        item=execute_req.current_item,
                        item_id=current_item_id,
                        reason="post_review_fix",
                        execution_context=exec_ctx,
                        span_id=self._phase.subphase_span_id_getter(),
                        parent_span_id=self._obs.phase_span_id,
                    )
                else:
                    self._state.locally_started_items.add(ctx_key)

            if should_emit:
                self._state.emit_progress(
                    "item_started",
                    {
                        "item": execute_req.current_item,
                        "item_id": current_item_id,
                        "execution_context": exec_ctx,
                    },
                )
                # ISSUE-OBS-002: Log item_started to production logger
                self._obs.log_session_event(
                    "item_started",
                    item=execute_req.current_item,
                    item_id=current_item_id,
                    span_id=self._phase.subphase_span_id_getter(),
                    parent_span_id=self._obs.phase_span_id,
                )

        # P1-1: Wrap execute in try/finally to guarantee item_completed pairs
        result: dict[str, Any] = {}
        item_error: Exception | None = None
        subphase_status = "success"
        subphase_error_message: str | None = None
        try:
            result = cast(dict[str, Any], handler.handle(execute_req))
        except Exception as e:
            item_error = e
            self._phase.complete_subphase(
                "execute", subphase_start, status="error", error_message=str(e)
            )
            self._log_phase_failed(
                failure_stage="execute",
                error_code="HANDLER_ERROR",
                error=e,
            )
        finally:
            # P1-1: Always emit item_completed when item_started was emitted
            if execute_req.current_item:
                item_id = execute_req.current_item.get("id")
                if item_id:
                    self._state.locally_completed_items.add(str(item_id))
                resolved_outcome = self._resolve_item_terminal_outcome(
                    execute_req.current_item,
                    result,
                    item_error,
                )
                item_status = resolved_outcome.status
                item_result = resolved_outcome.result_payload
                files_changed = resolved_outcome.files_changed
                no_op = resolved_outcome.no_op
                empty_response = resolved_outcome.empty_response
                is_interrupted = resolved_outcome.interrupted
                if item_status == ExecutionStatus.SUCCESS.value:
                    subphase_status = "success"
                    subphase_error_message = None
                elif item_status == ExecutionStatus.PARTIAL.value:
                    subphase_status = "partial"
                    subphase_error_message = None
                elif is_interrupted:
                    subphase_status = "interrupted"
                    subphase_error_message = (
                        str(
                            item_result.get("summary")
                            or item_result.get("error")
                            or ""
                        ).strip()
                        or "Execution interrupted"
                    )
                else:
                    subphase_status = "error"
                    subphase_error_message = (
                        str(
                            item_result.get("summary")
                            or item_result.get("error")
                            or ""
                        ).strip()
                        or "Execution failed"
                    )

                # Ensure report_execution receives the normalized terminal result.
                result = dict(item_result)
                if resolved_outcome.counts_as_completed:
                    # FEAT-SESSION-CLOSEOUT-001: Increment only on true success.
                    self._state.increment_items_completed()

                self._state.emit_progress(
                    "item_completed",
                    {
                        "item": execute_req.current_item,
                        "item_id": item_id,
                        "status": item_status,
                        "terminal_reason": resolved_outcome.terminal_reason,
                        "result": item_result,
                    },
                )

                # ISSUE-OBS-002: Log item_completed to production logger
                self._obs.log_session_event(
                    "item_completed",
                    item=execute_req.current_item,
                    item_id=item_id,
                    status=item_status,
                    terminal_reason=resolved_outcome.terminal_reason,
                    files_changed=files_changed,
                    no_op=no_op,
                    empty_response=empty_response,
                    interrupted=is_interrupted,
                    span_id=self._phase.subphase_span_id_getter(),
                    parent_span_id=self._obs.phase_span_id,
                )

        if item_error is not None:
            if isinstance(item_error, GracefulInterrupt):
                self._state.set_was_interrupted(True)
            raise item_error

        self._phase.complete_subphase(
            "execute",
            subphase_start,
            status=subphase_status,
            error_message=subphase_error_message,
        )
        return result

    def _resolve_item_terminal_outcome(
        self,
        current_item: dict[str, Any],
        handler_result: dict[str, Any],
        item_error: Exception | None,
    ) -> ResolvedItemOutcome:
        """Resolve a single authoritative terminal outcome for execute item events."""
        if item_error is None:
            resolved_result: dict[str, Any] = dict(handler_result)
        else:
            resolved_result = {
                "status": ExecutionStatus.FAILURE.value,
                "error": str(item_error),
            }

        status_raw = str(resolved_result.get("status", "")).strip().lower()
        status = status_raw or ExecutionStatus.FAILURE.value
        if status in {"failed", "error"}:
            status = ExecutionStatus.FAILURE.value
        if status not in {
            ExecutionStatus.SUCCESS.value,
            ExecutionStatus.FAILURE.value,
            ExecutionStatus.PARTIAL.value,
        }:
            status = ExecutionStatus.FAILURE.value

        interrupted = (
            isinstance(item_error, GracefulInterrupt)
            or bool(resolved_result.get("interrupted", False))
            or interrupt_requested()
        )
        if interrupted:
            status = ExecutionStatus.FAILURE.value
            resolved_result["interrupted"] = True
            resolved_result.setdefault("failure_class", "interrupted")
            terminal_reason = "interrupted"
        elif item_error is not None:
            status = ExecutionStatus.FAILURE.value
            resolved_result.setdefault("failure_class", "handler_exception")
            terminal_reason = "handler_exception"
        elif status == ExecutionStatus.SUCCESS.value:
            terminal_reason = "success"
        elif status == ExecutionStatus.PARTIAL.value:
            terminal_reason = "partial"
        else:
            terminal_reason = "failure"

        try:
            files_changed = int(resolved_result.get("files_changed", 0))
        except (TypeError, ValueError):
            files_changed = 0
        resolved_result["files_changed"] = files_changed

        explicit_empty_response = (
            str(resolved_result.get("failure_class", "")).strip().lower()
            == "empty_response"
        )

        item_item_type = (
            current_item.get("item_type", "") or current_item.get("type", "")
        ).lower()
        is_code_task = item_item_type not in (
            "verification",
            "validation",
            "lint",
            "check",
        )
        no_op = (
            item_error is None
            and status == ExecutionStatus.SUCCESS.value
            and files_changed == 0
            and is_code_task
        )

        if explicit_empty_response and not interrupted:
            status = ExecutionStatus.FAILURE.value
            terminal_reason = "empty_response"
            resolved_result["status"] = status
            resolved_result.setdefault(
                "summary",
                (
                    "Execution returned no actionable output. "
                    "Marked as retriable failure for re-queue."
                ),
            )
            resolved_result.setdefault("failure_class", "empty_response")
            resolved_result.setdefault("retryable", True)
            empty_response = True
            no_op = False
        else:
            empty_response = no_op and not str(
                resolved_result.get("summary", "")
            ).strip()
        if empty_response and not explicit_empty_response and not interrupted:
            logger.warning(
                "Execution completed with empty response for item %s; converting to failure",
                current_item.get("id", "unknown"),
            )
            status = ExecutionStatus.FAILURE.value
            terminal_reason = "empty_response"
            resolved_result["status"] = status
            resolved_result["summary"] = (
                "Execution returned no actionable output. "
                "Marked as retriable failure for re-queue."
            )
            resolved_result["failure_class"] = "empty_response"
            resolved_result["retryable"] = True
            no_op = False

        resolved_result["status"] = status
        return ResolvedItemOutcome(
            status=status,
            result_payload=resolved_result,
            files_changed=files_changed,
            no_op=no_op,
            empty_response=empty_response,
            interrupted=interrupted,
            terminal_reason=terminal_reason,
            counts_as_completed=(status == ExecutionStatus.SUCCESS.value),
        )
