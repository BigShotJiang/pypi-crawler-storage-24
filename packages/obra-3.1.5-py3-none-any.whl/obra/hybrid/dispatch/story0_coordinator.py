"""Story 0 action coordination extracted from ActionDispatcher."""

from __future__ import annotations

import logging
from typing import Any

from obra.hybrid.dispatch.context import ExecutionState, ObservabilityContext
from obra.hybrid.dispatch.handler_runtime import apply_objective

logger = logging.getLogger(__name__)


class Story0ActionCoordinator:
    """Own Story 0 objective injection and result normalization."""

    def __init__(
        self,
        *,
        execution_state: ExecutionState,
        observability: ObservabilityContext,
    ) -> None:
        self._state = execution_state
        self._obs = observability

    def dispatch(self, handler: Any, payload: dict[str, Any]) -> dict[str, Any]:
        """Execute STORY0 and normalize the result payload for reporting."""
        story0_prerequisites = payload.get("story0_prerequisites", [])
        objective = payload.get("objective") or self._state.objective or ""
        apply_objective(handler, objective)

        result = handler.handle(
            story0_prerequisites,
            resume_reason=payload.get("story0_resume_reason"),
            missing_tools=payload.get("missing_tools"),
        )
        if result.verification_tools:
            self._state.set_verification_tools(result.verification_tools)
            logger.info(
                "Story 0 returned verification_tools: %s",
                result.verification_tools,
            )
        if payload.get("story0_resume_reason") == "verification_tools_missing":
            self._state.set_verification_preflight_attempted(True)
            logger.info("Verification preflight attempted flag set to True")

        completed_prereqs = list(getattr(result, "completed", []) or [])
        failed_prereqs = list(getattr(result, "failed", []) or [])
        skipped_prereqs = list(getattr(result, "skipped", []) or [])
        blocking_failures = list(getattr(result, "blocking_failures", []) or [])
        non_blocking_failures = list(getattr(result, "non_blocking_failures", []) or [])
        mocked_credentials = list(getattr(result, "mocked_credentials", []) or [])
        verification_tools = getattr(result, "verification_tools", {}) or {}

        completed_ids = {str(item).strip() for item in completed_prereqs if str(item).strip()}
        failed_ids = {str(item).strip() for item in failed_prereqs if str(item).strip()}
        skipped_ids = {str(item).strip() for item in skipped_prereqs if str(item).strip()}

        normalized_prereqs: list[dict[str, Any]] = []
        if isinstance(story0_prerequisites, list):
            for prereq in story0_prerequisites:
                if not isinstance(prereq, dict):
                    continue
                prereq_id = str(prereq.get("id") or prereq.get("name") or "").strip()
                prereq_name = str(prereq.get("name") or prereq_id or "unknown").strip()
                lookup_keys = [key for key in (prereq_id, prereq_name) if key]
                if any(key in completed_ids for key in lookup_keys):
                    prereq_status = "installed"
                elif any(key in failed_ids for key in lookup_keys):
                    prereq_status = "failed"
                elif any(key in skipped_ids for key in lookup_keys):
                    prereq_status = "skipped"
                else:
                    prereq_status = "pending"
                normalized_prereqs.append(
                    {
                        "id": prereq_id or prereq_name,
                        "name": prereq_name,
                        "category": str(prereq.get("category", "")).upper(),
                        "source": str(prereq.get("source", "")).upper(),
                        "ecosystem": str(prereq.get("ecosystem", "")),
                        "reason": str(prereq.get("reason", "")),
                        "status": prereq_status,
                    }
                )

        def _dedupe(values: list[str]) -> list[str]:
            ordered: list[str] = []
            seen: set[str] = set()
            for value in values:
                item = str(value).strip()
                if not item or item in seen:
                    continue
                seen.add(item)
                ordered.append(item)
            return ordered

        installed_manifest = _dedupe(
            [
                prereq.get("name", "")
                for prereq in normalized_prereqs
                if prereq.get("status") == "installed" and prereq.get("source") == "MANIFEST"
            ]
        )
        installed_inferred = _dedupe(
            [
                prereq.get("name", "")
                for prereq in normalized_prereqs
                if prereq.get("status") == "installed" and prereq.get("source") == "INFERRED"
            ]
        )
        failed_prereq_names = _dedupe(
            [
                prereq.get("name", "")
                for prereq in normalized_prereqs
                if prereq.get("status") == "failed"
            ]
        )
        skipped_prereq_names = _dedupe(
            [
                prereq.get("name", "")
                for prereq in normalized_prereqs
                if prereq.get("status") == "skipped"
            ]
        )
        actual_installed = [p for p in normalized_prereqs if p.get("status") == "installed"]
        actual_failed = [p for p in normalized_prereqs if p.get("status") == "failed"]
        actual_skipped = [p for p in normalized_prereqs if p.get("status") == "skipped"]

        prereq_name_map = {p.get("id", ""): p.get("name", "") for p in normalized_prereqs}
        enriched_blocking = [
            {"id": fid, "name": prereq_name_map.get(fid, fid)}
            for fid in blocking_failures
        ]
        enriched_non_blocking = [
            {"id": fid, "name": prereq_name_map.get(fid, fid)}
            for fid in non_blocking_failures
        ]

        self._obs.log_session_event(
            "story0_snapshot",
            status=result.status,
            prerequisites=normalized_prereqs,
            prerequisites_total=len(normalized_prereqs),
            installed_count=len(actual_installed),
            failed_count=len(actual_failed),
            skipped_count=len(actual_skipped),
            installed_manifest=installed_manifest,
            installed_inferred=installed_inferred,
            failed_prereqs=failed_prereq_names,
            skipped_prereqs=skipped_prereq_names,
            blocking_failures=enriched_blocking,
            non_blocking_failures=enriched_non_blocking,
            mocked_credentials=mocked_credentials,
            verification_tools=verification_tools,
        )
        return {
            "status": result.status,
            "completed_prereqs": completed_prereqs,
            "failed_prereqs": failed_prereqs,
            "blocking_failures": blocking_failures,
            "non_blocking_failures": non_blocking_failures,
            "verification_tools": verification_tools,
            "mocked_credentials": mocked_credentials,
        }
