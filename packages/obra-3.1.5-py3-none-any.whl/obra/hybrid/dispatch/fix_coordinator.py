"""Fix-action coordination extracted from ActionDispatcher."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any, cast

from obra.api.protocol import ActionType, FixRequest
from obra.hybrid.dispatch.context import (
    ExecutionState,
    HandlerFactoryProtocol,
    ObservabilityContext,
    PhaseControl,
)
from obra.hybrid.dispatch.handler_runtime import (
    apply_parent_span_id,
    apply_verification_tools,
)
from obra.hybrid.dispatch.verification_tools import build_fix_handler_tools

logger = logging.getLogger(__name__)


class FixActionCoordinator:
    """Own fix-tool propagation, compat routing, and Story 0 preflight injection."""

    def __init__(
        self,
        *,
        observability: ObservabilityContext,
        phase_control: PhaseControl,
        execution_state: ExecutionState,
        handler_factory: HandlerFactoryProtocol,
        log_phase_failed: Callable[..., None],
        dispatch_action: Callable[[Any, ActionType, dict[str, Any]], dict[str, Any]],
        load_tooling_discovery_cache: Callable[[], dict[str, Any] | None],
    ) -> None:
        self._obs = observability
        self._phase = phase_control
        self._state = execution_state
        self._factory = handler_factory
        self._log_phase_failed = log_phase_failed
        self._dispatch_action = dispatch_action
        self._load_tooling_discovery_cache = load_tooling_discovery_cache

    def configure_fix_handler_verification_tools(
        self,
        fix_handler: Any,
        *,
        source_label: str,
    ) -> None:
        """Pass discovered verification tools to fix-handler paths."""
        verification_tools = self._state.get_verification_tools()
        if not verification_tools:
            return

        available_tools = verification_tools.get("available", [])
        if not available_tools:
            return

        discovery_data = self._load_tooling_discovery_cache()
        tool_configs = build_fix_handler_tools(
            available_tools,
            discovery_data=discovery_data,
        )
        if not tool_configs:
            return

        apply_verification_tools(fix_handler, tool_configs)
        logger.info(
            "Passed %d verification tools to FixHandler (%s): %s",
            len(tool_configs),
            source_label,
            [tool["name"] for tool in tool_configs],
        )

    def handle_execute_fix_compat(
        self,
        payload: dict[str, Any],
        *,
        subphase_start: float,
    ) -> dict[str, Any]:
        """Handle legacy EXECUTE payloads that carry fix data."""
        fix_handler = self._factory.get_handler(ActionType.FIX)
        apply_parent_span_id(fix_handler, self._phase.subphase_span_id_getter())
        self.configure_fix_handler_verification_tools(
            fix_handler,
            source_label="compat path",
        )

        fix_req = FixRequest.from_payload(payload)
        try:
            fix_result = cast(dict[str, Any], fix_handler.handle(fix_req))
        except Exception as error:
            self._phase.complete_subphase(
                "execute",
                subphase_start,
                status="error",
                error_message=str(error),
            )
            self._log_phase_failed(
                failure_stage="execute",
                error_code="HANDLER_ERROR",
                error=error,
            )
            raise

        fix_result["_report_as"] = ActionType.FIX.value
        self._phase.complete_subphase("execute", subphase_start)
        return fix_result

    def dispatch(self, handler: Any, payload: dict[str, Any]) -> dict[str, Any]:
        """Execute FIX with Story 0 verification preflight coordination."""
        fix_payload = payload
        if not payload.get("item_id") and self._state.get_last_item_id():
            fix_payload = dict(payload)
            fix_payload["item_id"] = self._state.get_last_item_id()
        fix_req = FixRequest.from_payload(fix_payload)
        if fix_req.item_id:
            self._state.set_last_item_id(fix_req.item_id)

        available_tools = (self._state.get_verification_tools() or {}).get("available", [])
        missing_tools = (self._state.get_verification_tools() or {}).get("missing", [])
        if not available_tools and not self._state.get_verification_preflight_attempted():
            logger.info(
                "Verification tools missing before FIX - injecting Story 0 preflight"
            )
            self._state.emit_progress(
                "verification_preflight_triggered",
                {
                    "message": (
                        "Verification tools missing. "
                        "Running Story 0 preflight to install required tooling."
                    ),
                    "missing_tools": missing_tools,
                },
            )
            saved_phase = self._phase.get_current_phase()
            saved_phase_start = self._phase.get_phase_start_time()

            story0_handler = self._factory.get_handler(ActionType.STORY0)
            story0_result = self._dispatch_action(
                story0_handler,
                ActionType.STORY0,
                {
                    "story0_prerequisites": [],
                    "objective": self._state.objective or "",
                    "story0_resume_reason": "verification_tools_missing",
                    "missing_tools": missing_tools,
                },
            )

            self._phase.set_current_phase(saved_phase)
            self._phase.set_phase_start_time(saved_phase_start)
            if story0_result and story0_result.get("verification_tools"):
                self._state.set_verification_tools(story0_result["verification_tools"])
                available_tools = (self._state.get_verification_tools() or {}).get(
                    "available", []
                )
                try:
                    self._factory.request_with_observability(
                        "POST",
                        "report_story0",
                        json={
                            "session_id": self._obs.session_id,
                            "status": story0_result.get("status", "complete"),
                            "completed_prereqs": [],
                            "failed_prereqs": [],
                            "blocking_failures": [],
                            "non_blocking_failures": [],
                            "verification_tools": self._state.get_verification_tools(),
                            "mocked_credentials": [],
                        },
                    )
                    logger.info(
                        "Reported injected Story 0 verification_tools to server: %s",
                        self._state.get_verification_tools(),
                    )
                except Exception as exc:
                    logger.warning("Failed to report Story 0 to server: %s", exc)
            if not available_tools:
                logger.warning(
                    "Verification tools still missing after preflight - proceeding without"
                )
                self._state.emit_progress(
                    "verification_preflight_incomplete",
                    {
                        "message": (
                            "Verification tools still missing after preflight. "
                            "Proceeding with FIX but verification may be limited."
                        ),
                    },
                )

        subphase_start = self._phase.start_subphase("fix")
        apply_parent_span_id(handler, self._phase.subphase_span_id_getter())
        self.configure_fix_handler_verification_tools(
            handler,
            source_label="from Story 0",
        )

        try:
            result = cast(dict[str, Any], handler.handle(fix_req))
        except Exception as error:
            self._phase.complete_subphase(
                "fix", subphase_start, status="error", error_message=str(error)
            )
            self._log_phase_failed(
                failure_stage="fix",
                error_code="HANDLER_ERROR",
                error=error,
            )
            raise
        self._phase.complete_subphase("fix", subphase_start)
        return result
