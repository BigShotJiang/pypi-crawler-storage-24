"""ActionDispatcher extracted from the former HybridOrchestrator dispatch path.

Routes server action types to private handler methods through four
context protocol dataclasses, replacing the 29-attribute direct coupling
between the dispatcher and the orchestrator.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any, cast

from obra.api.protocol import (
    ActionType,
    DeriveRequest,
    IntentRequest,
    PipelineStageRequest,
    ServerAction,
    StoryPreflightRequest,
)
from obra.exceptions import OrchestratorError
from obra.hybrid.dispatch.context import (
    ExecutionState,
    HandlerFactoryProtocol,
    ObservabilityContext,
    PhaseControl,
)
from obra.hybrid.dispatch.execution_coordinator import ExecutionActionCoordinator
from obra.hybrid.dispatch.fix_coordinator import FixActionCoordinator
from obra.hybrid.dispatch.handler_runtime import apply_parent_span_id
from obra.hybrid.dispatch.refinement_coordinator import RefinementActionCoordinator
from obra.hybrid.dispatch.review_coordinator import ReviewActionCoordinator
from obra.hybrid.dispatch.story0_coordinator import Story0ActionCoordinator
from obra.hybrid.dispatch.dispatcher_support import (
    count_task_items,
    summarize_userplan_steps,
)
from obra.hybrid.dispatch.item_skip import ItemSkipManager
from obra.hybrid.dispatch.refinement_guard import RefinementGuard
from obra.hybrid.tooling_discovery import ToolingDiscovery  # test patch seam

logger = logging.getLogger(__name__)


def _load_tooling_discovery_cache(working_dir: Any) -> dict[str, Any] | None:
    """Load ToolingDiscovery cache through the dispatcher module patch seam."""
    try:
        return ToolingDiscovery(working_dir, {}).load_cache()
    except Exception as exc:
        logger.debug("Failed to load ToolingDiscovery cache: %s", exc)
        return None

class ActionDispatcher:
    """Routes server actions to handler methods through context protocols.

    Extracted from HybridOrchestrator._dispatch_handler. All orchestrator
    attribute access is mediated through four context protocol objects.
    """

    def __init__(
        self,
        observability: ObservabilityContext,
        phase_control: PhaseControl,
        execution_state: ExecutionState,
        handler_factory: HandlerFactoryProtocol,
    ) -> None:
        self._obs = observability
        self._phase = phase_control
        self._state = execution_state
        self._factory = handler_factory
        self._refinement_guard = RefinementGuard(
            production_logger=self._obs.production_logger,
            session_id=self._obs.session_id,
            get_refinement_cycle_count=self._state.get_refinement_cycle_count,
        )
        self._skip_manager = ItemSkipManager(
            execution_state=self._state,
            phase_control=self._phase,
            observability=self._obs,
        )
        self._story0 = Story0ActionCoordinator(
            execution_state=self._state,
            observability=self._obs,
        )
        self._review = ReviewActionCoordinator(
            execution_state=self._state,
            handler_factory=self._factory,
            invoke_with_subphase=self._invoke_with_subphase,
        )
        self._fix = FixActionCoordinator(
            observability=self._obs,
            phase_control=self._phase,
            execution_state=self._state,
            handler_factory=self._factory,
            log_phase_failed=self._log_phase_failed,
            dispatch_action=lambda handler, action, payload: self.dispatch(
                handler,
                action,
                payload,
            ),
            load_tooling_discovery_cache=lambda: _load_tooling_discovery_cache(
                self._state.working_dir
            ),
        )
        self._execution = ExecutionActionCoordinator(
            observability=self._obs,
            phase_control=self._phase,
            execution_state=self._state,
            handler_factory=self._factory,
            skip_manager=self._skip_manager,
            fix_coordinator=self._fix,
            log_phase_failed=self._log_phase_failed,
        )
        self._refinement_coord = RefinementActionCoordinator(
            observability=self._obs,
            phase_control=self._phase,
            execution_state=self._state,
            handler_factory=self._factory,
            refinement_guard=self._refinement_guard,
            skip_manager=self._skip_manager,
            log_phase_failed=self._log_phase_failed,
        )

    # ------------------------------------------------------------------
    # Subphase lifecycle helper
    # ------------------------------------------------------------------

    def _invoke_with_subphase(
        self,
        subphase_name: str,
        handler: Any,
        handler_call: Callable[[], Any],
    ) -> dict[str, Any]:
        """Execute handler_call within subphase lifecycle management.

        Sets handler._parent_span_id if the attribute exists, starts and
        completes the subphase, and emits phase_failed on error.
        """
        start = self._phase.start_subphase(subphase_name)
        apply_parent_span_id(handler, self._phase.subphase_span_id_getter())
        try:
            result = handler_call()
        except Exception as e:
            self._phase.complete_subphase(
                subphase_name, start, status="error", error_message=str(e)
            )
            current_phase = self._phase.get_current_phase()
            if current_phase:
                self._obs.log_session_event(
                    "phase_failed",
                    phase=current_phase.value,
                    failure_stage=subphase_name,
                    error_code="HANDLER_ERROR",
                    error_class=type(e).__name__,
                    error_message=str(e),
                    span_id=self._obs.phase_span_id,
                    parent_span_id=self._obs.pipeline_span_id,
                )
            raise
        self._phase.complete_subphase(subphase_name, start)
        return result

    def _log_phase_failed(
        self,
        *,
        failure_stage: str,
        error_code: str,
        error: Exception,
    ) -> None:
        """Emit a phase_failed session event when a phase is active."""
        current_phase = self._phase.get_current_phase()
        if not current_phase:
            return
        self._obs.log_session_event(
            "phase_failed",
            phase=current_phase.value,
            failure_stage=failure_stage,
            error_code=error_code,
            error_class=type(error).__name__,
            error_message=str(error),
            span_id=self._obs.phase_span_id,
            parent_span_id=self._obs.pipeline_span_id,
        )

    # ------------------------------------------------------------------
    # Main dispatch entry point
    # ------------------------------------------------------------------

    def dispatch(
        self,
        handler: Any,
        action: ActionType,
        payload: dict[str, Any],
        server_action: ServerAction | None = None,
    ) -> dict[str, Any]:
        """Route action to the appropriate private handler method.

        Updates the session guard heartbeat on every call so the
        session-*.json stays fresh during long refinement cycles.
        """
        # ISSUE-HYBRID-033: Update heartbeat on every handler dispatch.
        if self._state.session_guard:
            self._state.session_guard.update(
                items_completed=self._state.get_items_completed(),
                phase=(
                    self._phase.get_current_phase().value
                    if self._phase.get_current_phase()
                    else "unknown"
                ),
            )

        if action == ActionType.INTENT:
            return self._dispatch_intent(handler, payload)
        if action == ActionType.DERIVE:
            return self._dispatch_derive(handler, payload)
        if action == ActionType.STORY0:
            return self._dispatch_story0(handler, payload)
        if action == ActionType.STORY_PREFLIGHT:
            return self._dispatch_story_preflight(handler, payload)
        if action == ActionType.EXAMINE:
            return self._refinement_coord.dispatch_examine(handler, payload, server_action)
        if action == ActionType.REVISE:
            return self._refinement_coord.dispatch_revise(handler, payload, server_action)
        if action == ActionType.EXECUTE:
            return self._execution.dispatch(handler, payload)
        if action == ActionType.REVIEW:
            return self._dispatch_review(handler, payload)
        if action == ActionType.PIPELINE_STAGE:
            return self._dispatch_pipeline_stage(handler, payload)
        if action == ActionType.FIX:
            return self._dispatch_fix(handler, payload)
        if action == ActionType.VALIDATOR:
            return self._dispatch_validator(handler, payload)
        msg = f"Unhandled action: {action.value}"
        raise OrchestratorError(
            msg,
            session_id=self._obs.session_id or "",
        )

    # ------------------------------------------------------------------
    # Individual action dispatch methods
    # ------------------------------------------------------------------

    def _dispatch_intent(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        intent_req = IntentRequest.from_payload(payload)
        self._state.set_last_userplan_id(intent_req.userplan_id)
        self._state.set_last_userplan_version(intent_req.userplan_version)
        self._state.set_derive_from_step(intent_req.from_step)
        return cast(
            dict[str, Any],
            self._invoke_with_subphase(
                "intent", handler, lambda: handler.handle(intent_req)
            ),
        )

    def _dispatch_derive(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        derive_req = DeriveRequest.from_payload(payload)
        # Store userplan info for DerivedPlan reporting
        self._state.set_last_userplan_id(derive_req.userplan_id)
        self._state.set_last_userplan_version(derive_req.userplan_version)
        # Store preserved plan items for --from-step re-derivation merge
        self._state.set_preserved_plan_items(derive_req.plan_items_reference)
        self._state.set_derive_from_step(derive_req.from_step)
        subphase_start = self._phase.start_subphase("derive")
        apply_parent_span_id(handler, self._phase.subphase_span_id_getter())
        summarized_steps, steps_truncated = summarize_userplan_steps(
            derive_req.userplan_steps,
            self._obs.get_log_viewer_int,
        )
        snapshot_ref = self._factory.write_plan_snapshot(
            session_id=self._obs.session_id or "",
            userplan_id=derive_req.userplan_id,
            userplan_version=derive_req.userplan_version,
            userplan_steps=derive_req.userplan_steps,
        )
        self._obs.log_session_event(
            "userplan_snapshot",
            userplan_id=derive_req.userplan_id,
            userplan_version=derive_req.userplan_version,
            userplan_steps_count=len(derive_req.userplan_steps),
            userplan_steps=summarized_steps,
            truncated=steps_truncated,
            plan_snapshot_ref=snapshot_ref,
            span_id=self._phase.subphase_span_id_getter(),
            parent_span_id=self._obs.phase_span_id,
        )
        # ISSUE-OBS-002: Log derivation_started event
        self._obs.log_session_event(
            "derivation_started",
            objective=derive_req.objective,
            plan_id=getattr(derive_req, "plan_id", None),
            span_id=self._phase.subphase_span_id_getter(),
            parent_span_id=self._obs.phase_span_id,
        )
        try:
            result = cast(dict[str, Any], handler.handle(derive_req))
        except Exception as e:
            self._phase.complete_subphase(
                "derive", subphase_start, status="error", error_message=str(e)
            )
            current_phase = self._phase.get_current_phase()
            if current_phase:
                self._obs.log_session_event(
                    "phase_failed",
                    phase=current_phase.value,
                    failure_stage="derive",
                    error_code="HANDLER_ERROR",
                    error_class=type(e).__name__,
                    error_message=str(e),
                    span_id=self._obs.phase_span_id,
                    parent_span_id=self._obs.pipeline_span_id,
                )
            raise
        # ISSUE-OBS-002: Log derivation_complete event
        self._obs.log_session_event(
            "derivation_complete",
            plan_items_count=len(result.get("plan_items", [])),
            span_id=self._phase.subphase_span_id_getter(),
            parent_span_id=self._obs.phase_span_id,
        )
        # FIX-TRACKER-001: Store plan items for phase_completed event
        self._state.set_last_derivation_plan_items(result.get("plan_items", []))
        # P0-2: Track total tasks for terminal event context
        self._state.set_tasks_total(
            count_task_items(self._state.get_last_derivation_plan_items())
        )
        self._phase.complete_subphase(
            "derive",
            subphase_start,
            active_duration_ms=result.get("active_duration_ms"),
        )
        return result

    def _dispatch_story0(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._story0.dispatch(handler, payload)

    def _dispatch_story_preflight(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        preflight_req = StoryPreflightRequest.from_payload(payload)
        preflight = handler.handle(
            story_item=preflight_req.story_item,
            plan_items=preflight_req.plan_items,
            exploration_context=preflight_req.exploration_context,
        )
        if hasattr(preflight, "to_dict"):
            result_dict = cast(dict[str, Any], preflight.to_dict())
        elif isinstance(preflight, dict):
            result_dict = dict(preflight)
        else:
            raise OrchestratorError(
                "Story preflight handler returned invalid payload",
                session_id=self._obs.session_id or "",
            )
        result_dict["story_id"] = str(preflight_req.story_item.get("id", "")).strip()
        return result_dict

    def _dispatch_review(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        item_id = payload.get("item_id") or self._state.get_last_item_id()
        if item_id and item_id in self._state.skipped_item_ids:
            logger.info("Skipping review for skipped item: %s", item_id)
            subphase_start = self._phase.start_subphase("review")
            self._phase.complete_subphase("review", subphase_start, status="skipped")
            return {
                "item_id": item_id,
                "agent_reports": [
                    {
                        "agent_type": "code_quality",
                        "status": "pass",
                        "scores": {"code_quality": 1.0},
                        "issues": [],
                    }
                ],
                "iteration": 0,
            }
        return self._review.dispatch(handler, payload)

    def _dispatch_pipeline_stage(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        # Parse pipeline stage request from payload
        stage_req = PipelineStageRequest.from_payload(payload)
        loop_state = (
            stage_req.context.loop_state
            if isinstance(stage_req.context.loop_state, dict)
            else {}
        )
        current_iteration = loop_state.get("current_iteration", stage_req.iteration)
        max_iterations = loop_state.get("max_iterations", stage_req.max_iterations)

        logger.info(
            "Executing pipeline stage '%s' runner='%s' execution_id='%s' "
            "at trigger '%s' (iteration %s/%s)",
            stage_req.stage_name,
            stage_req.runner_id,
            stage_req.stage_execution_id,
            stage_req.trigger,
            current_iteration,
            max_iterations,
        )

        subphase_name = f"stage_{stage_req.stage_name}"
        subphase_start = self._phase.start_subphase(subphase_name)
        apply_parent_span_id(handler, self._phase.subphase_span_id_getter())

        try:
            result = handler.handle(stage_req)
            result_dict = result.to_dict()
            self._phase.complete_subphase(subphase_name, subphase_start)
            return result_dict
        except Exception as e:
            self._phase.complete_subphase(
                subphase_name, subphase_start, status="error", error_message=str(e)
            )
            self._log_phase_failed(
                failure_stage=subphase_name,
                error_code="STAGE_ERROR",
                error=e,
            )
            raise

    def _dispatch_fix(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        return self._fix.dispatch(handler, payload)

    def _dispatch_validator(
        self, handler: Any, payload: dict[str, Any]
    ) -> dict[str, Any]:
        # FEAT-SENSECHECK-PIPELINE-001: Handle validator requests from server
        from obra.api.protocol import ValidatorRequest

        validator_req = ValidatorRequest.from_payload(payload)
        subphase_name = f"validator_{validator_req.stage}"
        subphase_start = self._phase.start_subphase(subphase_name)
        apply_parent_span_id(handler, self._phase.subphase_span_id_getter())

        try:
            result = handler.handle(validator_req)
            result_dict = result.to_dict()
            self._phase.complete_subphase(subphase_name, subphase_start)
            return result_dict
        except Exception as e:
            self._phase.complete_subphase(
                subphase_name, subphase_start, status="error", error_message=str(e)
            )
            self._log_phase_failed(
                failure_stage=subphase_name,
                error_code="VALIDATOR_ERROR",
                error=e,
            )
            raise

    # ------------------------------------------------------------------
    # Helper methods moved from orchestrator.py
    # ------------------------------------------------------------------

    def _sanitize_review_agents_for_server(
        self, candidate_agents: list[str] | None
    ) -> tuple[list[str], list[str]]:
        """Filter review agents to those accepted by the current server."""
        return self._review.sanitize_review_agents_for_server(candidate_agents)
