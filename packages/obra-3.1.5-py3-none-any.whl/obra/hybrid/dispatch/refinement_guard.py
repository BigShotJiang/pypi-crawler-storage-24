"""Iteration guard helper for refinement dispatcher branches."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)


class RefinementGuard:
    """Centralize examine/revise iteration guard behavior."""

    def __init__(
        self,
        *,
        production_logger: Any | None,
        session_id: str | None,
        get_refinement_cycle_count: Callable[[], int],
    ) -> None:
        self._production_logger = production_logger
        self._session_id = session_id
        self._get_refinement_cycle_count = get_refinement_cycle_count

    def check_iteration_limit(
        self,
        *,
        action: str,
        iteration: int | None,
        effective_max: int | None,
        fallback_max: int | None,
        unchanged_plan_items: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any] | None:
        """Return the current guard-hit payload when refinement should stop."""
        guard_max = effective_max or fallback_max
        if iteration is None or guard_max is None or iteration < guard_max:
            return None

        cycle_count = self._get_refinement_cycle_count()
        if action == "revise":
            logger.warning(
                "ISSUE-HYBRID-055: Client-side iteration guard triggered "
                "for REVISE — iteration %d >= max %d, returning unchanged "
                "plan items",
                iteration,
                guard_max,
            )
            if self._production_logger:
                self._production_logger.log_event(
                    "refinement_guard_triggered",
                    session_id=self._session_id,
                    action="revise",
                    examine_action_count=cycle_count,
                    iteration=iteration,
                    effective_max=guard_max,
                )
            return {
                "plan_items": unchanged_plan_items or [],
                "iteration_limit_exceeded": True,
            }

        logger.warning(
            "ISSUE-HYBRID-055: Client-side iteration guard triggered — "
            "iteration %d >= max %d, skipping examine and returning "
            "empty result to break refinement loop",
            iteration,
            guard_max,
        )
        if self._production_logger:
            self._production_logger.log_event(
                "refinement_guard_triggered",
                session_id=self._session_id,
                examine_action_count=cycle_count,
                iteration=iteration,
                effective_max=guard_max,
            )
        return {"issues": [], "iteration_limit_exceeded": True}
