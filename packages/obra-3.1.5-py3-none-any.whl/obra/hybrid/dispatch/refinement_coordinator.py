"""Refinement action coordination (examine/revise) extracted from ActionDispatcher."""

from __future__ import annotations

import json
import logging
import time
from collections.abc import Callable
from typing import Any, cast

from obra.display import console, print_warning
from obra.display.observability import VerbosityLevel
from obra.exceptions import OrchestratorError
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.hybrid.dispatch.context import (
    ExecutionState,
    HandlerFactoryProtocol,
    ObservabilityContext,
    PhaseControl,
)
from obra.hybrid.dispatch.dispatcher_support import inject_defaults_into_prompt
from obra.hybrid.dispatch.item_skip import ItemSkipManager
from obra.hybrid.dispatch.refinement_guard import RefinementGuard
from obra.hybrid.plan_merger import PlanMerger

logger = logging.getLogger(__name__)


class RefinementActionCoordinator:
    """Own examine and revise dispatch, refinement guard, and proposed-defaults handling."""

    def __init__(
        self,
        *,
        observability: ObservabilityContext,
        phase_control: PhaseControl,
        execution_state: ExecutionState,
        handler_factory: HandlerFactoryProtocol,
        refinement_guard: RefinementGuard,
        skip_manager: ItemSkipManager,
        log_phase_failed: Callable[..., None],
    ) -> None:
        self._obs = observability
        self._phase = phase_control
        self._state = execution_state
        self._factory = handler_factory
        self._refinement_guard = refinement_guard
        self._skip_manager = skip_manager
        self._log_phase_failed = log_phase_failed

    def dispatch_examine(
        self,
        handler: Any,
        payload: dict[str, Any],
        server_action: Any | None,
    ) -> dict[str, Any]:
        """Execute EXAMINE with refinement guard, parallel batch fan-out, and telemetry."""
        # Track refinement cycles (examine action count, NOT logical iteration)
        self._state.set_refinement_cycle_count(
            self._state.get_refinement_cycle_count() + 1
        )
        if self._state.get_refinement_start_time() is None:
            self._state.set_refinement_start_time(time.time())
        # Inject refinement cycle info from server action envelope
        if server_action is not None:
            payload.setdefault("iteration", server_action.iteration)
            payload.setdefault(
                "max_iterations",
                server_action.metadata.get("max_refinement_iterations"),
            )

        guard_result = self._refinement_guard.check_iteration_limit(
            action="examine",
            iteration=cast(int | None, payload.get("iteration")),
            effective_max=(
                server_action.metadata.get("effective_max_refinement_iterations")
                if server_action is not None
                else None
            ),
            fallback_max=cast(int | None, payload.get("max_iterations")),
        )
        if guard_result is not None:
            return guard_result

        # FEAT-REFINEMENT-PARALLEL-001: All EXAMINE actions route through
        # parallel batch fan-out.
        subphase_start = self._phase.start_subphase("examine")
        batch_count = len(payload.get("batches", []))
        # ISSUE-HYBRID-034: Structured telemetry for examine start
        if self._obs.production_logger:
            self._obs.production_logger.log_event(
                "examine_start",
                session_id=self._obs.session_id,
                examine_action_count=self._state.get_refinement_cycle_count(),
                plan_items=sum(
                    len(b.get("plan_items", []))
                    for b in payload.get("batches", [])
                ),
                iteration=payload.get("iteration"),
                max_iterations=payload.get("max_iterations"),
                batch_count=batch_count,
            )
        try:
            result = self._factory.handle_parallel_examine_batches(payload)
        except Exception as e:
            self._phase.complete_subphase(
                "examine", subphase_start, status="error", error_message=str(e)
            )
            if self._obs.progress_emitter:
                self._obs.progress_emitter.parallel_batch_fallback(
                    "examine", error=str(e),
                )
            if self._obs.production_logger:
                self._obs.production_logger.log_event(
                    "examine_failed",
                    session_id=self._obs.session_id,
                    examine_action_count=self._state.get_refinement_cycle_count(),
                    batch_count=batch_count,
                    error_class=type(e).__name__,
                    error_message=str(e),
                )
            self._log_phase_failed(
                failure_stage="examine",
                error_code="HANDLER_ERROR",
                error=e,
            )
            raise
        self._phase.complete_subphase("examine", subphase_start)
        # ISSUE-HYBRID-034: Structured telemetry for examine complete
        issues = result.get("issues", []) if isinstance(result, dict) else []
        blocking_count = PlanMerger.count_effective_blocking_issues(
            issues,
            server_action.bypass_modes_active if server_action is not None else None,
        )
        if self._obs.production_logger:
            self._obs.production_logger.log_event(
                "examine_complete",
                session_id=self._obs.session_id,
                examine_action_count=self._state.get_refinement_cycle_count(),
                issue_count=len(issues),
                blocking_count=blocking_count,
                batch_count=batch_count,
            )
        # Refinement scope summary for CLI visibility
        scope_items = sum(
            len(b.get("plan_items", []))
            for b in payload.get("batches", [])
        )
        total_items = len(payload.get("full_plan_items", payload.get("plan_items", [])))
        if self._obs.progress_emitter:
            self._obs.progress_emitter.refinement_scope_summary(
                cycle=self._state.get_refinement_cycle_count(),
                scope_items=scope_items or total_items,
                total_items=total_items or scope_items,
                scope_mode=payload.get("scope_mode", "full"),
                blocking_count=blocking_count,
                prev_blocking_count=(
                    self._state.get_refinement_last_blocking_count()
                    if self._state.get_refinement_cycle_count() > 1
                    else None
                ),
            )
        self._state.set_refinement_last_blocking_count(blocking_count)
        return result

    def dispatch_revise(
        self,
        handler: Any,
        payload: dict[str, Any],
        server_action: Any | None,
    ) -> dict[str, Any]:
        """Execute REVISE with refinement guard, defaults processing, and parallel fan-out."""
        guard_result = self._refinement_guard.check_iteration_limit(
            action="revise",
            iteration=server_action.iteration if server_action is not None else None,
            effective_max=(
                server_action.metadata.get("effective_max_refinement_iterations")
                if server_action is not None
                else None
            ),
            fallback_max=(
                server_action.metadata.get("max_refinement_iterations")
                if server_action is not None
                else None
            ),
            unchanged_plan_items=cast(
                list[dict[str, Any]],
                payload.get("full_plan_items", []),
            ),
        )
        if guard_result is not None:
            return guard_result

        # FEAT-REFINEMENT-PARALLEL-001: All REVISE actions route through
        # parallel batch fan-out.
        subphase_start = self._phase.start_subphase("revise")
        batch_count = len(payload.get("batches", []))
        # ISSUE-HYBRID-034: Structured telemetry for revise start
        if self._obs.production_logger:
            self._obs.production_logger.log_event(
                "revise_start",
                session_id=self._obs.session_id,
                examine_action_count=self._state.get_refinement_cycle_count(),
                batch_count=batch_count,
                issue_count=sum(
                    len(b.get("issues", []))
                    for b in payload.get("batches", [])
                ),
            )

        # Process proposed defaults once and inject into each batch's
        # base_prompt before parallel fan-out.
        proposed_defaults = payload.get("proposed_defaults") or []
        try:
            if proposed_defaults:
                confirmed_defaults = self._process_proposed_defaults(proposed_defaults)
                for batch_dict in payload.get("batches", []):
                    batch_dict["base_prompt"] = inject_defaults_into_prompt(
                        batch_dict.get("base_prompt", ""),
                        confirmed_defaults,
                    )
                    batch_dict["proposed_defaults"] = confirmed_defaults
        except OrchestratorError:
            self._phase.complete_subphase(
                "revise",
                subphase_start,
                status="error",
                error_message="defaults confirmation aborted",
            )
            raise

        try:
            result = self._factory.handle_parallel_revise_batches(payload)
        except Exception as e:
            self._phase.complete_subphase(
                "revise", subphase_start, status="error", error_message=str(e)
            )
            if self._obs.progress_emitter:
                self._obs.progress_emitter.parallel_batch_fallback(
                    "revise", error=str(e),
                )
            if self._obs.production_logger:
                self._obs.production_logger.log_event(
                    "revise_failed",
                    session_id=self._obs.session_id,
                    examine_action_count=self._state.get_refinement_cycle_count(),
                    batch_count=batch_count,
                    error_class=type(e).__name__,
                    error_message=str(e),
                )
            self._log_phase_failed(
                failure_stage="revise",
                error_code="HANDLER_ERROR",
                error=e,
            )
            raise

        if (
            self._obs.progress_emitter
            and self._obs.progress_emitter.config.verbosity >= VerbosityLevel.DETAIL
        ):
            if batch_count > 1:
                self._obs.progress_emitter._print(
                    f"  Parallel REVISE: {batch_count} batches", style="cyan"
                )
            else:
                self._obs.progress_emitter._print(
                    "  REVISE: sequential (single batch)", style="dim"
                )

        # Skip tracking on consolidated result.
        if self._state.is_skip_tracking_enabled("revision"):
            deferred = result.get("deferred_issues")
            created = 0
            # Build issue map from all batches for lookup.
            all_issues: dict[str, dict[str, Any]] = {}
            for batch_dict in payload.get("batches", []):
                for issue in batch_dict.get("issues", []):
                    issue_id = str(issue.get("id", "")).strip()
                    if issue_id:
                        all_issues[issue_id] = issue

            if isinstance(deferred, list):
                for item in deferred:
                    if not isinstance(item, dict):
                        continue
                    issue_id = str(item.get("id", "")).strip()
                    if not issue_id:
                        continue
                    reason_text = (
                        str(item.get("reason", "")).strip() or "Deferred by revision"
                    )
                    source_issue = all_issues.get(issue_id, {})
                    priority = str(source_issue.get("priority", "")).upper()
                    create_skip_record(
                        session_id=self._obs.session_id or "",
                        task_id=issue_id,
                        source=SkipSource.REVISION,
                        reason=SkipReason.DEFERRED_CONCERN,
                        description=f"Deferred concern: {reason_text}",
                        source_context={
                            "priority": priority,
                            "issue": source_issue,
                            "deferred_reason": reason_text,
                        },
                    )
                    created += 1
            if created > 0:
                logger.info("Run 'obra skips list' to review skipped items")

        self._phase.complete_subphase("revise", subphase_start)
        # ISSUE-HYBRID-034: Structured telemetry for revise complete
        if self._obs.production_logger:
            revised_plan_items = (
                result.get("plan_items", []) if isinstance(result, dict) else []
            )
            revised_plan_item_count = len(revised_plan_items)
            changed_item_count = PlanMerger.count_plan_item_changes(
                payload.get("full_plan_items", []),
                revised_plan_items,
            )
            self._obs.production_logger.log_event(
                "revise_complete",
                session_id=self._obs.session_id,
                examine_action_count=self._state.get_refinement_cycle_count(),
                batch_count=batch_count,
                items_updated=revised_plan_item_count,
                revised_plan_item_count=revised_plan_item_count,
                changed_item_count=changed_item_count,
            )
        return result

    def _process_proposed_defaults(
        self,
        proposed_defaults: list[dict[str, Any]],
    ) -> list[dict[str, Any]]:
        """Render and optionally collect confirmation for proposed defaults."""
        if not proposed_defaults:
            return []

        console.print()
        console.print("[bold]Proposed defaults detected[/bold]")

        if self._state.defaults_json:
            console.print(
                json.dumps({"proposed_defaults": proposed_defaults}, indent=2)
            )
            msg = "Defaults exported via --defaults-json; rerun interactively to confirm."
            raise OrchestratorError(
                msg,
                session_id=self._obs.session_id or "",
            )

        should_prompt = self._state.should_prompt_for_defaults()
        if not should_prompt:
            print_warning(
                "Headless mode: auto-accepting proposed defaults. "
                "Re-run with --interactive to review."
            )

        confirmed: list[dict[str, Any]] = []
        for default in proposed_defaults:
            value = default.get("proposed_value", "")
            issue_id = default.get("issue_id", "unknown")
            description = default.get("description", "")
            confidence = default.get("confidence", 0.0)

            console.print()
            console.print(f"  [bold]Issue {issue_id}[/bold]: {description or value}")
            if description and value != description:
                console.print(f"  [cyan]Proposed[/cyan]: {value}")
            console.print(f"  [dim]Confidence: {confidence:.0%}[/dim]")

            if should_prompt:
                try:
                    from obra.display.prompting import prompt_input

                    user_input = prompt_input(
                        "[bold yellow]?[/bold yellow] Accept, override, or 'skip': ",
                    ).strip()
                except (EOFError, KeyboardInterrupt):
                    user_input = ""

                if user_input.lower() == "skip":
                    continue
                if user_input:
                    default = {
                        **default,
                        "proposed_value": user_input,
                        "rationale": (
                            f"User override: {default.get('rationale', 'custom default')}"
                        ),
                    }

            confirmed.append(default)

        return confirmed
