"""Review action coordination extracted from ActionDispatcher."""

from __future__ import annotations

import logging
from collections.abc import Callable
from typing import Any, cast

from obra.api.protocol import ReviewRequest
from obra.hybrid.dispatch.context import ExecutionState, HandlerFactoryProtocol
from obra.hybrid.dispatch.handler_runtime import get_review_iteration

logger = logging.getLogger(__name__)


class ReviewActionCoordinator:
    """Own review-agent sanitization and review request normalization."""

    def __init__(
        self,
        *,
        execution_state: ExecutionState,
        handler_factory: HandlerFactoryProtocol,
        invoke_with_subphase: Callable[[str, Any, Callable[[], Any]], dict[str, Any]],
    ) -> None:
        self._state = execution_state
        self._factory = handler_factory
        self._invoke_with_subphase = invoke_with_subphase

    def sanitize_review_agents_for_server(
        self, candidate_agents: list[str] | None
    ) -> tuple[list[str], list[str]]:
        """Filter review agents to those accepted by the current server."""
        supported = set(self._factory.ordered_supported_review_agents())
        if not candidate_agents:
            return self._factory.ordered_supported_review_agents(), []

        sanitized: list[str] = []
        dropped: list[str] = []
        seen: set[str] = set()

        for agent in candidate_agents:
            normalized = str(agent).strip()
            if not normalized or normalized in seen:
                continue
            seen.add(normalized)
            if normalized in supported:
                sanitized.append(normalized)
            else:
                dropped.append(normalized)

        if sanitized:
            return sanitized, dropped
        return self._factory.ordered_supported_review_agents(), dropped

    def dispatch(self, handler: Any, payload: dict[str, Any]) -> dict[str, Any]:
        """Execute REVIEW with explicit review-agent and cycle metadata handling."""
        review_payload = dict(payload)
        if not review_payload.get("item_id") and self._state.get_last_item_id():
            review_payload["item_id"] = self._state.get_last_item_id()

        candidate_agents = review_payload.get("agents_to_run")
        if not candidate_agents:
            legacy_agents = review_payload.get("review_agents")
            if isinstance(legacy_agents, list):
                candidate_agents = legacy_agents
        if isinstance(candidate_agents, list):
            sanitized_agents, dropped_agents = self.sanitize_review_agents_for_server(
                candidate_agents
            )
        else:
            sanitized_agents, dropped_agents = self.sanitize_review_agents_for_server(None)

        if dropped_agents:
            logger.warning(
                "Dropped unsupported review agents for current server contract: %s",
                sorted(set(dropped_agents)),
            )
        review_payload["agents_to_run"] = sanitized_agents

        review_req = ReviewRequest.from_payload(review_payload)
        if review_req.item_id:
            self._state.set_last_item_id(review_req.item_id)

        if not review_req.review_cycle_id and review_req.item_id:
            iteration = get_review_iteration(handler, review_req.item_id)
            review_req.review_cycle_id = f"{review_req.item_id}:{iteration}"

        if review_req.item_id and review_req.item_id in self._state.skipped_item_ids:
            logger.info("Skipping review for skipped item: %s", review_req.item_id)
            return {
                "item_id": review_req.item_id,
                "agent_reports": [
                    {
                        "agent_type": "code_quality",
                        "status": "pass",
                        "scores": {"code_quality": 1.0},
                        "issues": [],
                    }
                ],
                "iteration": 0,
            }

        return cast(
            dict[str, Any],
            self._invoke_with_subphase(
                "review", handler, lambda: handler.handle(review_req)
            ),
        )
