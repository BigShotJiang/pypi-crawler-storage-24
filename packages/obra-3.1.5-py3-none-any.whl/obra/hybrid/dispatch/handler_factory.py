"""HandlerFactory extracted from HybridOrchestrator._get_handler.

Lazily instantiates and caches handler objects for each ActionType.
Constructed once per session (on first _get_handler call) so all
orchestrator attributes are fully populated by from_config() and
session-start before any handler is built.
"""

from __future__ import annotations

import sys
from collections.abc import Callable
from pathlib import Path
from typing import Any

from obra.api.protocol import ActionType
from obra.exceptions import ConfigurationError, OrchestratorError
from obra.utils.obra_home import get_runtime_dir


class HandlerFactory:
    """Lazily creates and caches handlers for each ActionType.

    Mirrors the body of HybridOrchestrator._get_handler.
    All self._xxx references in the original method become self._xxx
    on this object (same names, different owner).
    """

    def __init__(
        self,
        working_dir: Path,
        llm_config: dict[str, Any] | None,
        domain: Any | None,
        config: dict[str, Any] | None,
        session_id: str | None,
        trace_id: str | None,
        phase_span_id: str | None,
        on_stream: Callable[..., None] | None,
        on_progress: Callable[..., None] | None,
        observability_config: Any | None,
        progress_emitter: Any | None,
        production_logger: Any | None,
        review_config: Any | None,
        client: Any | None,
        planning_mode: str | None,
        bypass_modes: list[str] | None,
        work_type_override: str | None,
        process_registry: Any | None,
        objective: str | None,
        log_session_event: Callable[..., None],
        get_role_llm_config: Callable[[ActionType], dict[str, Any]],
        get_review_config: Callable[[], dict[str, Any]],
        create_monitoring_context: Callable[[], dict[str, Any]],
        handlers_cache: dict[ActionType | tuple[ActionType, str], Any] | None = None,
    ) -> None:
        self._working_dir = working_dir
        self._llm_config = llm_config
        self._domain = domain
        self._config = config
        self._session_id = session_id
        self._trace_id = trace_id
        self._phase_span_id = phase_span_id
        self._on_stream = on_stream
        self._on_progress = on_progress
        self._observability_config = observability_config
        self._progress_emitter = progress_emitter
        self._production_logger = production_logger
        self._review_config = review_config
        self._client = client
        self._planning_mode = planning_mode
        self._bypass_modes = bypass_modes or []
        self._work_type_override = work_type_override
        self._process_registry = process_registry
        self._objective = objective
        self._log_session_event = log_session_event
        self._get_role_llm_config = get_role_llm_config
        self._get_review_config = get_review_config
        self._create_monitoring_context = create_monitoring_context

        # Handler registry — keyed by ActionType or (ActionType, stage) for VALIDATOR.
        # Accepts an external dict to share state with the orchestrator (allows tests
        # to pre-populate handlers before the factory is constructed).
        self._handlers: dict[ActionType | tuple[ActionType, str], Any] = (
            handlers_cache if handlers_cache is not None else {}
        )

    def get_handler(
        self,
        action: ActionType,
        payload: dict[str, Any] | None = None,
    ) -> Any:
        """Get handler for action type.

        Lazily imports and instantiates handlers.

        Args:
            action: Action type
            payload: Optional payload (used to extract validator stage)

        Returns:
            Handler instance

        Raises:
            OrchestratorError: If handler not found
            ConfigurationError: If llm_config is invalid or missing required keys
        """
        validator_stage = None
        if action == ActionType.VALIDATOR and isinstance(payload, dict):
            stage = payload.get("stage")
            if isinstance(stage, str):
                validator_stage = stage.strip().lower()

        handler_key: ActionType | tuple[ActionType, str]
        if action == ActionType.VALIDATOR and validator_stage:
            handler_key = (action, validator_stage)
        else:
            handler_key = action

        if handler_key not in self._handlers:
            # Validate llm_config for handlers that require it (C11)
            # DERIVE, EXAMINE, REVISE, EXECUTE, FIX, and VALIDATOR all need llm_config
            # ADR-069: Use role-based resolution for validation
            if action in (
                ActionType.DERIVE,
                ActionType.INTENT,
                ActionType.EXAMINE,
                ActionType.REVISE,
                ActionType.EXECUTE,
                ActionType.FIX,
                ActionType.STORY_PREFLIGHT,
                ActionType.VALIDATOR,  # FEAT-SENSECHECK-PIPELINE-001
            ):
                # Get role-based config (has fallbacks, should rarely fail)
                role_config = self._get_role_llm_config(action)

                # Validate required keys
                required_keys = {"provider"}
                missing_keys = required_keys - set(role_config.keys())
                if missing_keys:
                    msg = (
                        f"Cannot create {action.value} handler: resolved llm_config missing required keys: {missing_keys}. "
                        f"Current config: {role_config}"
                    )
                    raise ConfigurationError(
                        msg,
                        recovery="Run 'obra config' to set up LLM configuration or use 'obra derive' with --model and --provider flags.",
                    )
            # ISSUE-CLI-016/CLI-017 FIX: Build monitoring context for liveness checks
            # ADR-043 Phase 3: Use helper factory for consistent context construction
            monitoring_context = self._create_monitoring_context()

            # Import handlers lazily to avoid circular imports
            if action == ActionType.DERIVE:
                from obra.hybrid.handlers.derive import DeriveHandler

                # S3.T6: Pass on_stream callback to handler
                # S4.T2: Pass llm_config to handler
                # ISSUE-CLI-016/017: Pass monitoring context
                # Quality gate: Pass API client for UserPlan quality assessment
                # Production logger: Pass for detailed derivation/quality metrics
                # FEAT-COMPLEXITY-ROUTING-001: Pass planning mode for complexity routing
                # ADR-069: Use role-based LLM config resolution
                self._handlers[action] = DeriveHandler(
                    self._working_dir,
                    on_stream=self._on_stream,
                    on_progress=self._on_progress,
                    llm_config=self._get_role_llm_config(action),
                    domain=self._domain,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    monitoring_context=monitoring_context,
                    observability_config=self._observability_config,
                    bypass_modes=self._bypass_modes,
                    api_client=self._client,
                    work_type_override=self._work_type_override,
                    production_logger=self._production_logger,
                    planning_mode=self._planning_mode,
                )
            elif action == ActionType.INTENT:
                from obra.hybrid.handlers.intent_stage import IntentStageHandler

                self._handlers[action] = IntentStageHandler(
                    self._working_dir,
                    on_stream=self._on_stream,
                    on_progress=self._on_progress,
                    llm_config=self._get_role_llm_config(ActionType.DERIVE),
                    domain=self._domain,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    monitoring_context=monitoring_context,
                    production_logger=self._production_logger,
                )
            elif action == ActionType.STORY0:
                from obra.config.loaders import load_layered_config
                from obra.hybrid.handlers.story0 import Story0Handler

                config = self._config
                if config is None:
                    config, _, _ = load_layered_config(include_defaults=True)
                    self._config = config

                from obra.cli.run_support.interaction_mode import current_mode_is_interactive

                self._handlers[action] = Story0Handler(
                    self._working_dir,
                    config,
                    on_progress=self._on_progress,
                    session_id=self._session_id or "",
                    objective=self._objective or "",
                    is_tty=current_mode_is_interactive(),
                    llm_config=self._get_role_llm_config(ActionType.DERIVE),
                )
            elif action == ActionType.STORY_PREFLIGHT:
                from obra.agents.tier_config import resolve_agent_tier_config
                from obra.config.loaders import load_layered_config
                from obra.hybrid.handlers.story_preflight import StoryPreflightHandler

                config = self._config
                if config is None:
                    config, _, _ = load_layered_config(include_defaults=True)
                    self._config = config

                validator_llm_config = resolve_agent_tier_config("code_verify")
                if self._llm_config:
                    for key in ("git", "codex", "auth_method"):
                        if key in self._llm_config and key not in validator_llm_config:
                            validator_llm_config[key] = self._llm_config[key]

                self._handlers[action] = StoryPreflightHandler(
                    self._working_dir,
                    config=config,
                    llm_config=validator_llm_config,
                    log_event=self._log_session_event,
                    session_id=self._session_id or "",
                    trace_id=self._trace_id,
                    progress_emitter=self._progress_emitter,
                )
            elif action == ActionType.EXAMINE:
                from obra.hybrid.handlers.examine import ExamineHandler

                # S3.T6: Pass on_stream callback to handler
                # S4.T3: Pass llm_config to handler
                # ISSUE-CLI-016/017: Pass monitoring context
                # ADR-069: Use role-based LLM config resolution
                self._handlers[action] = ExamineHandler(
                    self._working_dir,
                    on_stream=self._on_stream,
                    llm_config=self._get_role_llm_config(action),
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    monitoring_context=monitoring_context,
                )
            elif action == ActionType.REVISE:
                from obra.hybrid.handlers.revise import ReviseHandler

                # S3.T6: Pass on_stream callback to handler
                # S4.T4: Pass llm_config to handler
                # ISSUE-CLI-016/017: Pass monitoring context
                # ADR-069: Use role-based LLM config resolution
                self._handlers[action] = ReviseHandler(
                    self._working_dir,
                    on_stream=self._on_stream,
                    llm_config=self._get_role_llm_config(action),
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    monitoring_context=monitoring_context,
                )
            elif action == ActionType.EXECUTE:
                from obra.hybrid.handlers.execute import ExecuteHandler

                # S5.T3: Pass llm_config to ExecuteHandler
                # ISSUE-OBS-003: Pass observability context for cross-process propagation
                # S2.T4: Pass observability_config and progress_emitter for heartbeat
                # ADR-069: Use role-based LLM config resolution
                log_file = get_runtime_dir() / "logs" / "hybrid.jsonl"
                self._handlers[action] = ExecuteHandler(
                    self._working_dir,
                    llm_config=self._get_role_llm_config(action),
                    session_id=self._session_id,
                    log_file=log_file,
                    trace_id=self._trace_id,
                    log_event=self._log_session_event,
                    parent_span_id=self._phase_span_id,
                    observability_config=self._observability_config,
                    progress_emitter=self._progress_emitter,
                    on_stream=self._on_stream,
                    process_registry=self._process_registry,  # FEAT-PROCESS-LIFECYCLE-001
                    monitoring_context=monitoring_context,
                )
            elif action == ActionType.REVIEW:
                from obra.hybrid.handlers.review import ReviewHandler

                self._handlers[action] = ReviewHandler(
                    self._working_dir,
                    llm_config=self._get_role_llm_config(action),
                    domain=self._domain,
                    review_config=self._review_config,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    progress_emitter=self._progress_emitter,
                )
            elif action == ActionType.PIPELINE_STAGE:
                from obra.hybrid.handlers.stage import StageHandler
                from obra.hybrid.stage_runner_registry import StageRunnerRegistry

                self._handlers[action] = StageHandler(
                    self._working_dir,
                    llm_config=self._get_role_llm_config(ActionType.REVIEW),  # Stage agents use review tier
                    domain=self._domain,
                    log_event=self._log_session_event,
                    runner_registry=StageRunnerRegistry(),
                )
            elif action == ActionType.FIX:
                from obra.hybrid.handlers.fix import FixHandler

                # ISSUE-OBS-003: Pass observability context for cross-process propagation
                # S3.T2: Pass observability_config and progress_emitter for heartbeat
                # ADR-069: Use role-based LLM config resolution
                log_file = get_runtime_dir() / "logs" / "hybrid.jsonl"
                self._handlers[action] = FixHandler(
                    self._working_dir,
                    llm_config=self._get_role_llm_config(action),
                    domain=self._domain,
                    session_id=self._session_id,
                    log_file=log_file,
                    trace_id=self._trace_id,
                    log_event=self._log_session_event,
                    parent_span_id=self._phase_span_id,
                    observability_config=self._observability_config,
                    progress_emitter=self._progress_emitter,
                    on_stream=self._on_stream,
                    process_registry=self._process_registry,  # FEAT-PROCESS-LIFECYCLE-001
                )
            elif action == ActionType.VALIDATOR and validator_stage == "code_verify":
                from obra.agents.tier_config import resolve_agent_tier_config
                from obra.hybrid.handlers.code_verify import CodeVerifyHandler

                validator_llm_config = resolve_agent_tier_config("code_verify")
                if self._llm_config:
                    for key in ("git", "codex", "auth_method"):
                        if key in self._llm_config and key not in validator_llm_config:
                            validator_llm_config[key] = self._llm_config[key]
                validator_llm_config["allowed_tools"] = ["Read", "Grep", "Glob"]
                self._handlers[handler_key] = CodeVerifyHandler(
                    self._working_dir,
                    llm_config=validator_llm_config,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                )
            elif action == ActionType.VALIDATOR and validator_stage == "escalation_fix":
                from obra.agents.tier_config import resolve_agent_tier_config
                from obra.hybrid.handlers.validator_executor import ValidatorExecutor

                validator_llm_config = resolve_agent_tier_config("escalation_fixer")
                if self._llm_config:
                    for key in ("git", "codex", "auth_method"):
                        if key in self._llm_config and key not in validator_llm_config:
                            validator_llm_config[key] = self._llm_config[key]
                self._handlers[handler_key] = ValidatorExecutor(
                    self._working_dir,
                    llm_config=validator_llm_config,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    progress_emitter=self._progress_emitter,
                )
            elif action == ActionType.VALIDATOR:
                from obra.agents.tier_config import resolve_agent_tier_config
                from obra.hybrid.handlers.validator_executor import ValidatorExecutor

                # FEAT-SENSECHECK-PIPELINE-001: SenseCheck pipeline validator execution
                # Validators use SenseCheck agent config (Menu 5 > Specialized Agents)
                # which inherits from Review LLM config (Menu 3)
                validator_llm_config = resolve_agent_tier_config("sense_check")
                # Merge session-level settings (git, codex) from runtime config
                if self._llm_config:
                    for key in ("git", "codex", "auth_method"):
                        if key in self._llm_config and key not in validator_llm_config:
                            validator_llm_config[key] = self._llm_config[key]
                self._handlers[handler_key] = ValidatorExecutor(
                    self._working_dir,
                    llm_config=validator_llm_config,
                    log_event=self._log_session_event,
                    trace_id=self._trace_id,
                    parent_span_id=self._phase_span_id,
                    progress_emitter=self._progress_emitter,
                )
            else:
                msg = f"No handler for action: {action.value}"
                raise OrchestratorError(
                    msg,
                    session_id=self._session_id or "",
                )

        return self._handlers[handler_key]
