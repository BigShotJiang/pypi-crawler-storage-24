"""Skip-branch helper for execution dispatch."""

from __future__ import annotations

import logging
from typing import Any

from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.hybrid.dispatch.context import ExecutionState, ObservabilityContext, PhaseControl

logger = logging.getLogger(__name__)


def _is_leaf_item(current_item: dict[str, Any], plan_items: list[dict[str, Any]]) -> bool:
    """Check whether the current item has no children in the plan."""
    item_id = current_item.get("id")
    if not item_id:
        return True
    return all(item.get("parent_id") != item_id for item in plan_items)


class ItemSkipManager:
    """Centralize execute-branch skip handling."""

    def __init__(
        self,
        *,
        execution_state: ExecutionState,
        phase_control: PhaseControl,
        observability: ObservabilityContext,
    ) -> None:
        self._state = execution_state
        self._phase = phase_control
        self._obs = observability

    def _emit_skip_event(self, current_item: dict[str, Any], reason: str) -> None:
        self._state.emit_progress(
            "item_skipped",
            {
                "item": current_item,
                "reason": reason,
            },
        )
        self._obs.log_session_event(
            "item_skipped",
            item=current_item,
            reason=reason,
            span_id=self._phase.subphase_span_id_getter(),
            parent_span_id=self._obs.phase_span_id,
        )

    @staticmethod
    def _build_skip_result(
        item_id: str,
        summary: str,
        *,
        skip_reason: str,
    ) -> dict[str, Any]:
        return {
            "item_id": item_id,
            "status": "success",
            "summary": summary,
            "files_changed": 0,
            "tests_passed": True,
            "skip_reason": skip_reason,
        }

    def check_completed_item_skip(
        self,
        current_item: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Skip items already completed in the source session."""
        item_title = str(current_item.get("title", ""))
        if not self._state.skip_completed_items or item_title not in self._state.skip_completed_items:
            return None

        logger.info("Skipping completed item: %s", item_title)
        self._emit_skip_event(current_item, "completed_in_previous_session")

        item_id = str(current_item.get("id", ""))
        if item_id:
            self._state.skipped_item_ids.add(item_id)
            if self._state.is_skip_tracking_enabled("orchestrator"):
                create_skip_record(
                    session_id=self._obs.session_id or "",
                    task_id=item_id,
                    source=SkipSource.ORCHESTRATOR,
                    reason=SkipReason.RESUME_RECOVERY,
                    description=f"Item {item_id} skipped (completed in previous session)",
                    source_context={
                        "skip_type": "resume_recovery",
                        "item_title": item_title,
                    },
                )
                logger.info("Run 'obra skips list' to review skipped items")

        return self._build_skip_result(
            item_id,
            f"Skipped (completed in previous session): {item_title}",
            skip_reason="completed_in_previous_session",
        )

    def check_resume_duplicate_skip(
        self,
        current_item: dict[str, Any],
    ) -> dict[str, Any] | None:
        """Skip duplicate execution when resuming."""
        item_id = str(current_item.get("id", ""))
        if (
            not item_id
            or not self._state.resume_completed_item_ids
            or item_id not in self._state.resume_completed_item_ids
        ):
            return None

        item_title = str(current_item.get("title", ""))
        logger.warning(
            "Resume duplicate-execution guard: skipping already-completed item %s (%s)",
            item_id,
            item_title,
        )
        self._emit_skip_event(current_item, "already_completed_on_resume")

        if self._state.is_skip_tracking_enabled("orchestrator"):
            create_skip_record(
                session_id=self._obs.session_id or "",
                task_id=item_id,
                source=SkipSource.ORCHESTRATOR,
                reason=SkipReason.RESUME_RECOVERY,
                description=f"Item {item_id} skipped (already completed before resume)",
                source_context={
                    "skip_type": "resume_duplicate_guard",
                    "item_title": item_title,
                },
            )

        return self._build_skip_result(
            item_id,
            f"Skipped (already completed before resume): {item_title}",
            skip_reason="already_completed_on_resume",
        )

    def check_container_skip(
        self,
        current_item: dict[str, Any],
        plan_items: list[dict[str, Any]],
    ) -> dict[str, Any] | None:
        """Skip non-leaf container items in hierarchical plans."""
        if not plan_items or _is_leaf_item(current_item, plan_items):
            return None

        item_title = str(current_item.get("title", ""))
        logger.info("Skipping container item (non-leaf): %s", item_title)
        self._emit_skip_event(current_item, "non_leaf_container")

        item_id = str(current_item.get("id", ""))
        if item_id:
            self._state.skipped_item_ids.add(item_id)
            if self._state.is_skip_tracking_enabled("orchestrator"):
                create_skip_record(
                    session_id=self._obs.session_id or "",
                    task_id=item_id,
                    source=SkipSource.ORCHESTRATOR,
                    reason=SkipReason.CONTAINER_EXECUTION,
                    description=f"Item {item_id} skipped (non-leaf container)",
                    source_context={
                        "skip_type": "container",
                        "item_title": item_title,
                    },
                )
                logger.info("Run 'obra skips list' to review skipped items")

        return self._build_skip_result(
            item_id,
            f"Skipped container item: {item_title}",
            skip_reason="non_leaf_container",
        )
