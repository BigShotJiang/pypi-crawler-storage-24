"""Pure helpers shared by ActionDispatcher internals."""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

_DEFAULT_MAX_USERPLAN_STEPS_LOGGED = 200
_DEFAULT_MAX_PLAN_TITLE_LEN = 300


@dataclass(frozen=True)
class ResolvedItemOutcome:
    """Canonical terminal outcome for a dispatched execute item."""

    status: str
    result_payload: dict[str, Any]
    files_changed: int
    no_op: bool
    empty_response: bool
    interrupted: bool
    terminal_reason: str
    counts_as_completed: bool


def count_task_items(plan_items: list[dict[str, Any]] | None) -> int:
    """Count task leaf items from a derived plan payload."""
    if not isinstance(plan_items, list):
        return 0
    task_count = 0
    for item in plan_items:
        if not isinstance(item, dict):
            continue
        item_type = str(item.get("item_type") or item.get("type") or "").strip().lower()
        if item_type == "task":
            task_count += 1
    return task_count


def inject_defaults_into_prompt(
    base_prompt: str | None,
    defaults: list[dict[str, Any]],
) -> str:
    """Append confirmed defaults to the revision prompt."""
    defaults_block = json.dumps(defaults, indent=2)
    prefix = base_prompt or ""
    return (
        f"{prefix}\n\n"
        "# User-confirmed defaults (apply unless overridden)\n"
        "The following defaults were confirmed to unblock refinement. "
        "Incorporate them into the revised plan explicitly:\n"
        f"{defaults_block}\n"
    )


def summarize_userplan_steps(
    steps: list[dict[str, Any]],
    get_log_viewer_int: Callable[[str, int], int],
) -> tuple[list[dict[str, Any]], bool]:
    """Return a capped summary of userplan steps for logging."""
    max_steps = get_log_viewer_int(
        "OBRA_LOG_VIEWER_MAX_USERPLAN_STEPS",
        _DEFAULT_MAX_USERPLAN_STEPS_LOGGED,
    )
    max_title_len = get_log_viewer_int(
        "OBRA_LOG_VIEWER_MAX_TITLE_LEN",
        _DEFAULT_MAX_PLAN_TITLE_LEN,
    )
    summarized: list[dict[str, Any]] = []
    for step in steps[:max_steps]:
        if not isinstance(step, dict):
            continue
        title = str(step.get("title", "")).strip()
        if len(title) > max_title_len:
            title = f"{title[:max_title_len]}..."
        summarized.append(
            {
                "id": step.get("id"),
                "index": step.get("index"),
                "title": title,
            }
        )
    truncated = len(steps) > max_steps
    return summarized, truncated
