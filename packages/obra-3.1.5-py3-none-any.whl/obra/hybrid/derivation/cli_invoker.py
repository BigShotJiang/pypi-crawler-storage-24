"""CLI-backed LLM invoker adapter for DerivationEngine."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from obra.llm.cli_runner import invoke_llm_via_cli
from obra.llm.invoker import InvocationResult, LLMInvoker
from obra.model_registry import supports_extended_thinking


@dataclass
class CLIInvokerConfig:
    """Configuration for CLI invoker adapter."""

    cwd: Path
    model: str
    auth_method: str
    reasoning_level: str
    timeout_s: int | None = None
    on_stream: Any | None = None
    log_event: Any | None = None
    trace_id: str | None = None
    parent_span_id: str | None = None
    skip_git_check: bool = False
    bypass_sandbox: bool = False
    approval_mode: str | None = None
    monitoring_context: dict[str, Any] | None = None


class CLIInvoker:
    """LLMInvoker-compatible adapter that calls provider CLIs."""

    def __init__(self, config: CLIInvokerConfig) -> None:
        self._config = config
        # Metadata-only invoker for provider capability checks.
        self._metadata_invoker = LLMInvoker()

    def _get_provider(self, name: str):
        """Return provider metadata for capability checks."""
        if self._config.auth_method == "oauth":
            if name == "anthropic":
                return _OAuthAnthropicMetadata(self._config.model)
            return _OAuthProviderMetadata(self._config.model)
        return self._metadata_invoker._get_provider(name)

    def invoke(
        self,
        *,
        prompt: str,
        provider: str | None = None,
        model: str | None = None,
        reasoning_level: str | None = None,
        response_format: str = "json",
        **_kwargs,
    ) -> InvocationResult:
        effective_provider = provider or "openai"
        effective_model = model or self._config.model
        effective_reasoning = reasoning_level or self._config.reasoning_level

        output = invoke_llm_via_cli(
            prompt=prompt,
            cwd=self._config.cwd,
            provider=effective_provider,
            model=effective_model,
            reasoning_level=effective_reasoning,
            auth_method=self._config.auth_method,
            on_stream=self._config.on_stream,
            timeout_s=self._config.timeout_s,
            log_event=self._config.log_event,
            trace_id=self._config.trace_id,
            parent_span_id=self._config.parent_span_id,
            call_site="derive",
            monitoring_context=self._config.monitoring_context,
            skip_git_check=self._config.skip_git_check,
            bypass_sandbox=self._config.bypass_sandbox,
            approval_mode=self._config.approval_mode,
            response_format=response_format,
        )

        return InvocationResult(
            content=output,
            tokens_used=0,
            thinking_tokens=0,
            provider=effective_provider,
            model=effective_model,
            duration_seconds=0.0,
            success=True,
        )


class _OAuthProviderMetadata:
    """Metadata-only provider used for OAuth capability probing."""

    def __init__(self, default_model: str) -> None:
        self.default_model = default_model


class _OAuthAnthropicMetadata(_OAuthProviderMetadata):
    """Anthropic capability metadata for OAuth probing."""

    def supports_extended_thinking(self, model: str) -> bool:
        return supports_extended_thinking("anthropic", model)


__all__ = ["CLIInvoker", "CLIInvokerConfig"]
