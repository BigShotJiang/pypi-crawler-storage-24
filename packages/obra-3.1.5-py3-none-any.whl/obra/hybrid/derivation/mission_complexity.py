"""Mission-level sizing and rigor-routing ownership for derivation.

This module is the canonical owner for two distinct concepts:

1. Semantic sizing (`SizeClass` / `SizingGuidance`)
2. Resolved routing posture (`RigorMode` / `ResolvedRoutingPolicy`)

The sizing gate classifies the objective into a semantic size class. Routing
then resolves a canonical rigor posture from operator overrides plus the
size-to-rigor matrix. Downstream derive and workflow surfaces should consume
the resolved routing policy rather than inferring behavior from size alone.
"""

import logging
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

logger = logging.getLogger(__name__)


class PlanningMode(str, Enum):
    """Compatibility enum for the legacy `plan_mode` override surface."""

    AUTO = "auto"
    LIGHT = "light"
    BALANCED = "balanced"
    THOROUGH = "thorough"


class RigorMode(str, Enum):
    """Canonical rigor posture for derive/workflow routing."""

    LIGHT = "light"
    BALANCED = "balanced"
    THOROUGH = "thorough"


class SizeClass(str, Enum):
    """Sizing classification for objectives."""

    TRIVIAL = "trivial"
    SIMPLE = "simple"
    MODERATE = "moderate"
    COMPLEX = "complex"


@dataclass
class SizingGuidance:
    """Semantic sizing guidance derived from objective classification."""

    size_class: SizeClass
    description: str
    scope: str
    use_single_shot: bool
    rationale: str = field(default="")
    method: str = field(default="")

    def to_dict(self) -> dict[str, Any]:
        """Serialize sizing guidance to a dictionary."""
        return {
            "size_class": self.size_class.value,
            "description": self.description,
            "scope": self.scope,
            "use_single_shot": self.use_single_shot,
            "rationale": self.rationale,
            "method": self.method,
        }


@dataclass(frozen=True)
class ResolvedRoutingPolicy:
    """Resolved downstream routing posture for one derivation objective."""

    rigor_mode: RigorMode
    source: str
    rationale: str
    skip_analogues: bool
    skip_brief: bool
    use_single_shot: bool
    validation_intensity: str
    closeout_enabled: bool
    requested_override: str | None = None
    alias_applied: str | None = None

    @property
    def derivation_mode(self) -> str:
        return "single_shot" if self.use_single_shot else "three_step"

    def to_dict(self) -> dict[str, Any]:
        return {
            "rigor_mode": self.rigor_mode.value,
            "source": self.source,
            "rationale": self.rationale,
            "skip_analogues": self.skip_analogues,
            "skip_brief": self.skip_brief,
            "use_single_shot": self.use_single_shot,
            "derivation_mode": self.derivation_mode,
            "validation_intensity": self.validation_intensity,
            "closeout_enabled": self.closeout_enabled,
            "requested_override": self.requested_override,
            "alias_applied": self.alias_applied,
        }


@dataclass
class PreFilterResult:
    """Result for the pre-filter classification."""

    is_trivial: bool
    reason: str
    method: str


_RIGOR_ALIAS_MAP = {
    "quick": RigorMode.LIGHT,
    "light": RigorMode.LIGHT,
    "standard": RigorMode.BALANCED,
    "balanced": RigorMode.BALANCED,
    "thorough": RigorMode.THOROUGH,
}
_DEFAULT_INFERRED_RIGOR_BY_SIZE = {
    SizeClass.TRIVIAL.value: RigorMode.LIGHT,
    SizeClass.SIMPLE.value: RigorMode.LIGHT,
    SizeClass.MODERATE.value: RigorMode.BALANCED,
    SizeClass.COMPLEX.value: RigorMode.THOROUGH,
}
_DEFAULT_POLICY_BY_RIGOR = {
    RigorMode.LIGHT.value: {
        "skip_analogues": True,
        "skip_brief": True,
        "use_single_shot": True,
        "validation_intensity": "light",
    },
    RigorMode.BALANCED.value: {
        "skip_analogues": True,
        "skip_brief": False,
        "use_single_shot": False,
        "validation_intensity": "standard",
    },
    RigorMode.THOROUGH.value: {
        "skip_analogues": False,
        "skip_brief": False,
        "use_single_shot": False,
        "validation_intensity": "thorough",
    },
}
_RIGOR_ORDER = {
    RigorMode.LIGHT.value: 0,
    RigorMode.BALANCED.value: 1,
    RigorMode.THOROUGH.value: 2,
}


def normalize_rigor_mode(raw_mode: str | None) -> tuple[RigorMode | None, str | None]:
    """Normalize a raw CLI/config override to canonical rigor semantics.

    Returns:
        Tuple of (canonical rigor mode, alias that was applied).
    """
    if raw_mode is None:
        return None, None
    normalized = raw_mode.strip().lower()
    if not normalized or normalized == PlanningMode.AUTO.value:
        return None, None
    mode = _RIGOR_ALIAS_MAP.get(normalized)
    if mode is None:
        return None, None
    alias_applied = normalized if normalized != mode.value else None
    return mode, alias_applied


def resolve_rigor_override(
    *,
    cli_mode: str | None,
    config_mode: str | None,
) -> tuple[RigorMode | None, str | None, str | None, str | None]:
    """Resolve the effective rigor override with CLI-over-config precedence."""
    for source, value in (("cli", cli_mode), ("config", config_mode)):
        rigor_mode, alias_applied = normalize_rigor_mode(value)
        if rigor_mode is not None:
            return rigor_mode, source, value.strip().lower() if value else None, alias_applied
    return None, None, None, None


def build_resolved_routing_policy(
    *,
    config: dict[str, Any],
    sizing_guidance: SizingGuidance,
    override_mode: RigorMode | None = None,
    override_source: str | None = None,
    requested_override: str | None = None,
    alias_applied: str | None = None,
) -> ResolvedRoutingPolicy:
    """Resolve the canonical routing policy from size plus override precedence."""
    routing_config = config.get("derivation", {}).get("sizing", {}).get("routing", {})
    inferred_map = routing_config.get("inferred_rigor_by_size", {})
    inferred_raw = str(
        inferred_map.get(
            sizing_guidance.size_class.value,
            _DEFAULT_INFERRED_RIGOR_BY_SIZE[sizing_guidance.size_class.value].value,
        )
    ).strip()
    inferred_mode, _ = normalize_rigor_mode(inferred_raw)
    effective_mode = override_mode or inferred_mode or RigorMode.BALANCED

    policies = routing_config.get("policies", {})
    policy_config = policies.get(effective_mode.value, _DEFAULT_POLICY_BY_RIGOR[effective_mode.value])

    closeout_enabled = is_closeout_enabled(config, effective_mode)
    source = override_source or "inferred"
    if override_mode is not None:
        rationale = (
            f"Resolved {effective_mode.value} rigor from {source} override"
            f" for size_class={sizing_guidance.size_class.value}"
        )
    else:
        rationale = (
            f"Inferred {effective_mode.value} rigor from size_class="
            f"{sizing_guidance.size_class.value}"
        )

    return ResolvedRoutingPolicy(
        rigor_mode=effective_mode,
        source=source,
        rationale=rationale,
        skip_analogues=bool(policy_config.get("skip_analogues")),
        skip_brief=bool(policy_config.get("skip_brief")),
        use_single_shot=bool(policy_config.get("use_single_shot")),
        validation_intensity=str(policy_config.get("validation_intensity", "standard")),
        closeout_enabled=closeout_enabled,
        requested_override=requested_override,
        alias_applied=alias_applied,
    )


def is_closeout_enabled(config: dict[str, Any], rigor_mode: RigorMode) -> bool:
    """Return whether the resolved rigor posture should inject close-out work."""
    min_rigor = (
        config.get("derivation", {})
        .get("hierarchy", {})
        .get("story", {})
        .get("closeout_min_rigor", RigorMode.THOROUGH.value)
    )
    normalized_min_rigor, _ = normalize_rigor_mode(str(min_rigor))
    effective_min = normalized_min_rigor or RigorMode.THOROUGH
    return _RIGOR_ORDER[rigor_mode.value] >= _RIGOR_ORDER[effective_min.value]


def get_default_sizing_guidance(size_class: SizeClass | str) -> SizingGuidance:
    """Get default sizing guidance for a size class.

    Used as fallback when sizing gate fails or for forced modes.

    Args:
        size_class: Size class enum or string value

    Returns:
        SizingGuidance with appropriate defaults
    """
    if isinstance(size_class, str):
        size_class = SizeClass(size_class.lower())

    defaults = {
        SizeClass.TRIVIAL: {
            "description": "A quick fix or minor tweak",
            "scope": "Single file or tiny change",
            "use_single_shot": True,
        },
        SizeClass.SIMPLE: {
            "description": "A focused, self-contained change",
            "scope": "Small surface area, limited dependencies",
            "use_single_shot": True,
        },
        SizeClass.MODERATE: {
            "description": "A cohesive feature with clear boundaries",
            "scope": "Multiple files, keep boundaries explicit",
            "use_single_shot": False,
        },
        SizeClass.COMPLEX: {
            "description": "A cross-cutting change requiring architectural consideration",
            "scope": "Multiple subsystems, plan for sequencing",
            "use_single_shot": False,
        },
    }

    config: dict[str, Any] = defaults.get(size_class, defaults[SizeClass.MODERATE])
    return SizingGuidance(
        size_class=size_class,
        description=str(config["description"]),
        scope=str(config["scope"]),
        use_single_shot=bool(config["use_single_shot"]),
        rationale="default",
        method="fallback",
    )


# Convenience exports
__all__ = [
    "PlanningMode",
    "PreFilterResult",
    "ResolvedRoutingPolicy",
    "RigorMode",
    "SizeClass",
    "SizingGuidance",
    "build_resolved_routing_policy",
    "get_default_sizing_guidance",
    "is_closeout_enabled",
    "normalize_rigor_mode",
    "resolve_rigor_override",
]
