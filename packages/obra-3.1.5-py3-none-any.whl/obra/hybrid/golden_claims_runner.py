"""Business-domain simulation runner for the golden claims workflow."""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra.api.protocol import PipelineStageRequest, PipelineStageResult, ProducedArtifactPayload


class GoldenClaimsNormalizationRunner:
    """Normalize the golden claims execution input into a durable stage artifact."""

    def execute(self, request: PipelineStageRequest) -> PipelineStageResult:
        config = request.context.runner_config
        working_dir = Path(request.context.working_directory or ".").expanduser()
        input_path = working_dir / str(config.get("input_path") or "")
        output_path = working_dir / str(config.get("output_path") or "")
        accumulation_path = working_dir / str(
            config.get("accumulation_output_path") or "runtime/generated/workflow_accumulation.json"
        )

        if not input_path.exists():
            raise ValueError(f"Golden claims input not found: {input_path}")
        if not output_path.parent.exists():
            output_path.parent.mkdir(parents=True, exist_ok=True)
        if not accumulation_path.parent.exists():
            accumulation_path.parent.mkdir(parents=True, exist_ok=True)

        raw_claim = json.loads(input_path.read_text(encoding="utf-8"))
        normalized_claim: dict[str, Any] = {
            "claim_id": raw_claim.get("claim_id"),
            "member_id": str(raw_claim.get("member_id") or "").strip(),
            "provider_npi": str(raw_claim.get("provider_npi") or "").strip(),
            "payer_id": str(raw_claim.get("payer_id") or "").strip(),
            "service_date": str(raw_claim.get("service_date") or "").strip(),
            "diagnosis_codes": list(raw_claim.get("diagnosis_codes") or []),
            "procedure_codes": list(raw_claim.get("procedure_codes") or []),
            "billed_amount": float(raw_claim.get("billed_amount") or 0.0),
            "prior_auth_id": str(raw_claim.get("prior_auth_id") or "").strip(),
            "provider_name": str(raw_claim.get("rendering_provider_name") or "").strip(),
            "notes": str(raw_claim.get("notes") or "").strip(),
            "normalization_status": "normalized",
            "normalized_by": request.runner_id,
            "derived_plan_item_count": len(request.content.get("plan_items", [])),
        }
        output_path.write_text(
            json.dumps(normalized_claim, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

        accumulation_summary = {
            "stage_name": request.stage_name,
            "runner_id": request.runner_id,
            "stage_execution_id": request.stage_execution_id,
            "produced_artifact_id": str(
                config.get("artifact_id") or "artifact.normalized_claim.claim_001.v1"
            ),
            "output_path": str(output_path.relative_to(working_dir)),
            "domain_id": request.context.domain_id,
        }
        accumulation_path.write_text(
            json.dumps(accumulation_summary, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )

        now = datetime.now(UTC).isoformat()
        output_rel = str(output_path.relative_to(working_dir))
        accumulation_rel = str(accumulation_path.relative_to(working_dir))
        workflow_execution_id = str(
            request.context.workflow_refs.get("workflow_execution_id")
            or request.context.workflow_refs.get("session_id")
            or "golden-claims-execution"
        )
        attempt_id = str(
            request.context.runtime_metadata.get("attempt_id")
            or request.stage_execution_id
            or "attempt-1"
        )

        output_artifact = ProducedArtifactPayload(
            artifact_type="stage_output",
            artifact_id=str(
                config.get("artifact_id") or "artifact.normalized_claim.claim_001.v1"
            ),
            version="v1",
            compatibility_version="1.0",
            created_at=now,
            producer_kind="extension_runner",
            producer_id=request.runner_id,
            operation_kind="executed",
            workflow_execution_id=workflow_execution_id,
            attempt_id=attempt_id,
            stage_id=request.stage_name,
            stage_name=request.stage_name,
            path=output_rel,
            file_targets=[output_rel],
            files_changed=[output_rel],
            metadata={
                "artifact_role": "normalized_claim",
                "claim_id": normalized_claim.get("claim_id"),
            },
        )
        accumulation_artifact = ProducedArtifactPayload(
            artifact_type="workflow_accumulation",
            artifact_id=str(
                config.get("accumulation_artifact_id")
                or "workflow_accumulation.claim_001.v1"
            ),
            version="v1",
            compatibility_version="1.0",
            created_at=now,
            producer_kind="extension_runner",
            producer_id=request.runner_id,
            operation_kind="accumulated",
            workflow_execution_id=workflow_execution_id,
            attempt_id=attempt_id,
            stage_id=request.stage_name,
            stage_name=request.stage_name,
            path=accumulation_rel,
            file_targets=[accumulation_rel],
            files_changed=[accumulation_rel],
            metadata={"artifact_role": "accumulation_summary"},
        )

        return PipelineStageResult(
            stage_name=request.stage_name,
            stage_execution_id=request.stage_execution_id,
            execution_status="complete",
            outcome="passed",
            findings=[],
            stage_output_artifacts=[output_artifact],
            workflow_accumulation_artifact=accumulation_artifact,
            candidate_stage_output_artifacts=[output_artifact],
            candidate_workflow_accumulation_artifact=accumulation_artifact,
            routing_signal={"recommended_action": "continue"},
            loop_signal={
                "recommended_action": "continue",
                "current_iteration": request.iteration,
                "max_iterations": request.max_iterations,
            },
            metadata={
                "source": "golden_claims_runner",
                "output_path": output_rel,
            },
            iteration=request.iteration,
            duration_s=0.0,
        )


def create_golden_claims_runner(_request: PipelineStageRequest) -> GoldenClaimsNormalizationRunner:
    """Factory used by pipeline.registered_runners."""
    return GoldenClaimsNormalizationRunner()
