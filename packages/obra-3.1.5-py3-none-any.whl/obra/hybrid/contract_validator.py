"""Contract-validation helpers for HybridOrchestrator."""

from __future__ import annotations

import logging
from typing import Any, Callable

from obra.api.protocol import BYPASS_MODE_TO_CLI_FLAG, CompletionNotice, ServerAction
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record


class SessionContractValidator:
    """Render bypass notices and session-start contract warnings."""

    def __init__(
        self,
        *,
        logger: logging.Logger,
        safety_override_modes: frozenset[str],
        console: Any,
        print_warning: Callable[[str], None],
        print_info: Callable[[str], None],
    ) -> None:
        self._logger = logger
        self._safety_override_modes = safety_override_modes
        self._console = console
        self._print_warning = print_warning
        self._print_info = print_info

    def display_bypass_notices(
        self,
        server_action: ServerAction,
        *,
        current_phase: str | None,
        bypass_notice_keys: set[str],
        session_id: str | None,
        is_skip_tracking_enabled: callable,
        validate_bypass_modes_applied: callable,
    ) -> None:
        """Render bypass-related notices for the current action."""
        active_bypass_modes = list(server_action.bypass_modes_active or [])
        if active_bypass_modes:
            phase_label = current_phase or "unknown"
            safety_overrides = [
                mode for mode in active_bypass_modes if mode in self._safety_override_modes
            ]
            info_modes = [
                mode for mode in active_bypass_modes if mode not in self._safety_override_modes
            ]

            if safety_overrides:
                notice_key = f"{phase_label}|safety|{','.join(sorted(safety_overrides))}"
                if notice_key not in bypass_notice_keys:
                    bypass_notice_keys.add(notice_key)
                    self._print_warning(f"Bypass modes active: {', '.join(safety_overrides)}")
                    permissive_modes = {"planning_permissive", "permissive_planning", "permissive"}
                    if any(mode in permissive_modes for mode in safety_overrides):
                        self._console.print(
                            "  Permissive mode may relax P1 blocking, strict quality thresholds, and escalation safeguards."
                        )
                    else:
                        self._console.print("  Results may not reflect production behavior.")

            if info_modes:
                notice_key = f"info|{','.join(sorted(info_modes))}"
                if notice_key not in bypass_notice_keys:
                    bypass_notice_keys.add(notice_key)
                    self._print_info(f"Session modes: {', '.join(info_modes)}")

        bypassed_p1 = None
        if isinstance(server_action.metadata, dict):
            bypassed_p1 = server_action.metadata.get("bypassed_p1_count")
            bypassed_p1_issues = server_action.metadata.get("bypassed_p1_issues")
        else:
            bypassed_p1_issues = None

        if isinstance(bypassed_p1, int) and bypassed_p1 > 0:
            self._console.print(
                f"[yellow]Bypassing {bypassed_p1} P1 issues in permissive mode[/yellow]"
            )
            if is_skip_tracking_enabled("permissive_mode") and bypassed_p1_issues:
                for idx, issue in enumerate(bypassed_p1_issues):
                    issue_id = issue.get("id") or f"p1-issue-{idx + 1}"
                    create_skip_record(
                        session_id=session_id or "",
                        task_id=str(issue_id),
                        source=SkipSource.PERMISSIVE_MODE,
                        reason=SkipReason.QUALITY_THRESHOLD,
                        description=f"P1 issue bypassed in permissive mode: {issue.get('description', '')}",
                        source_context={"issue": issue},
                    )
                self._logger.info("Run 'obra skips list' to review skipped items")

        validate_bypass_modes_applied(server_action)

    def validate_bypass_modes_applied(
        self,
        server_action: ServerAction,
        *,
        requested_bypass_modes: list[str],
    ) -> list[str]:
        """Check if requested bypass modes were acknowledged by server."""
        if not requested_bypass_modes:
            return []

        active = set(server_action.bypass_modes_active or [])
        requested = set(requested_bypass_modes)
        unapplied = requested - active

        if unapplied:
            flags = [BYPASS_MODE_TO_CLI_FLAG.get(mode, f"--{mode}") for mode in sorted(unapplied)]
            self._print_warning(f"Flags requested but not applied by server: {', '.join(flags)}")
            self._logger.warning(
                "Bypass mode mismatch: requested=%s, active=%s, unapplied=%s",
                list(requested),
                list(active),
                list(unapplied),
            )

        return list(unapplied)

    @staticmethod
    def extract_session_start_contract_warnings(metadata: Any) -> list[str]:
        """Extract server-reported SessionStart contract warnings from metadata."""
        if not isinstance(metadata, dict):
            return []
        raw_fields = metadata.get("session_start_unknown_fields")
        if not isinstance(raw_fields, list):
            return []

        fields = [text for value in raw_fields if (text := str(value).strip())]
        if not fields:
            return []

        return [
            (
                "Server ignored unknown session-start fields from this client: "
                f"{', '.join(fields)}. "
                "This indicates client/server contract drift; align versions."
            )
        ]

    def emit_session_start_contract_warnings(self, warnings: list[str]) -> None:
        """Display prominent SessionStart contract warnings."""
        for warning in warnings:
            self._print_warning(f"API contract warning: {warning}")
            self._logger.warning("API contract warning: %s", warning)

    def append_session_start_contract_warnings(
        self,
        notice: CompletionNotice,
        warnings: list[str],
    ) -> CompletionNotice:
        """Attach and re-emit SessionStart contract warnings at session end."""
        if not warnings:
            return notice

        existing = set(notice.warnings or [])
        for warning in warnings:
            tagged = f"API contract warning: {warning}"
            if tagged not in existing:
                notice.warnings.append(tagged)
                existing.add(tagged)
            self._print_warning(f"{tagged} (session end)")
        return notice
