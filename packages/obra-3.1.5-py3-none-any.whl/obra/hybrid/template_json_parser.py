"""Template JSON parsing and recovery for the TemplateEditPipeline.

Encapsulates all structured-output extraction from LLM responses,
including JSON parsing, comma repair, stdout recovery, and array
auto-wrapping. Extracted from TemplateEditPipeline.
"""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from obra.hybrid.json_utils import _sanitize_control_chars, extract_json_payload

if TYPE_CHECKING:
    from obra.hybrid.template_edit_pipeline import _AttemptContent, _ExecutionContext

logger = logging.getLogger(__name__)


class TemplateJsonParser:
    """Handles JSON parsing and recovery for template edit attempts.

    This class owns the five JSON parsing/recovery methods that were
    previously inlined in TemplateEditPipeline.

    Args:
        log_event: Telemetry callback (mirrors _emit_log_event).
        action_name: Pipeline's action identifier for telemetry.
    """

    def __init__(
        self,
        *,
        log_event: Callable[..., None] | None,
        action_name: str,
    ) -> None:
        self._log_event = log_event
        self._action_name = action_name

    def _emit_log_event(self, event_type: str, **kwargs: Any) -> None:
        if self._log_event:
            try:
                self._log_event(event_type, **kwargs)
            except Exception as e:
                logger.debug(f"Failed to log event '{event_type}': {e}")

    def parse_json_attempt(
        self,
        *,
        attempt_index: int,
        attempt_content: _AttemptContent,
        template_content: dict[str, Any] | str,
        output_schema: dict[str, Any] | None,
        llm_config: dict[str, Any],
        context: _ExecutionContext,
    ) -> dict[str, Any]:
        """Parse JSON-mode content, preserving current recovery semantics."""
        attempt_number = attempt_index + 1
        content = attempt_content.content
        content_unchanged = attempt_content.content_unchanged
        data: dict[str, Any] | list[Any] | None = None

        if content_unchanged:
            self._emit_log_event(
                "template_unchanged_detected",
                attempt=attempt_number,
                template_path=str(context.template_path),
                model=llm_config.get("model", "unknown"),
                provider=llm_config.get("provider", "unknown"),
                action=self._action_name,
            )
            data = {k: v for k, v in template_content.items() if k != "_instructions"}
        else:
            if not content.strip():
                data = self.extract_json_payload_from_stdout(attempt_content.llm_stdout)
                if data is not None:
                    self._emit_log_event(
                        "parse_recovered",
                        attempt=attempt_number,
                        error_msg="Template file was empty after edit; recovered structured output from stdout",
                        extracted_length=len(attempt_content.llm_stdout.strip()),
                        source="stdout_empty_template",
                    )
                else:
                    error = json.JSONDecodeError("Expecting value", content, 0)
                    setattr(error, "_obra_failure_class", "empty_response")
                    raise error

            if data is None:
                try:
                    data = json.loads(content)
                except json.JSONDecodeError as e:
                    repaired_data = self.repair_missing_comma(content, e)
                    if repaired_data is not None:
                        data = repaired_data
                        self._emit_log_event(
                            "parse_repaired",
                            attempt=attempt_number,
                            error_msg=str(e),
                            repair_type="missing_comma",
                            source="content",
                        )
                    else:
                        recovered_data, extracted_length = self.recover_json_payload(content)
                        if recovered_data is None:
                            raise
                        data = recovered_data
                        self._emit_log_event(
                            "parse_recovered",
                            attempt=attempt_number,
                            error_msg=str(e),
                            extracted_length=extracted_length or 0,
                        )

        if data is None:
            raise ValueError("Template edit returned no data")

        if isinstance(data, list):
            data_keys = [k for k in template_content if k != "_instructions"]
            if len(data_keys) == 1 and isinstance(template_content[data_keys[0]], list):
                self._emit_log_event(
                    "array_auto_wrapped",
                    attempt=attempt_number,
                    wrap_key=data_keys[0],
                    array_length=len(data),
                )
                data = {data_keys[0]: data}
            else:
                raise ValueError(
                    "LLM returned a JSON array but template expects object "
                    f"with keys: {data_keys}"
                )

        if not content_unchanged and output_schema is None:
            for key, value in template_content.items():
                if key == "_instructions":
                    continue
                if key not in data:
                    data[key] = value

            data.pop("_instructions", None)

        return data

    def recover_json_payload(self, content: str) -> tuple[dict[str, Any] | None, int | None]:
        """Extract, sanitize, and parse JSON from mixed content."""
        payload = extract_json_payload(content)
        if not payload:
            return (None, None)
        payload = _sanitize_control_chars(payload)
        try:
            parsed = json.loads(payload)
        except json.JSONDecodeError as e:
            repaired = self.repair_missing_comma(payload, e)
            if repaired is None:
                return (None, None)
            return (repaired, len(payload))
        if not isinstance(parsed, dict):
            return (None, None)
        return (parsed, len(payload))

    def repair_missing_comma(
        self,
        content: str,
        error: json.JSONDecodeError,
    ) -> dict[str, Any] | None:
        """Insert comma at JSONDecodeError position and reparse."""
        if error.msg != "Expecting ',' delimiter":
            return None
        insert_at = error.pos
        if insert_at <= 0 or insert_at > len(content):
            return None
        prev_index = insert_at - 1
        while prev_index >= 0 and content[prev_index].isspace():
            prev_index -= 1
        if prev_index < 0:
            return None
        if content[prev_index] in "{[,":
            return None
        repaired_text = f"{content[:insert_at]},{content[insert_at:]}"
        repaired_text = _sanitize_control_chars(repaired_text)
        try:
            repaired = json.loads(repaired_text)
        except json.JSONDecodeError:
            return None
        if not isinstance(repaired, dict):
            return None
        return repaired

    def try_recover_from_stdout(
        self,
        stdout: str,
        template_content: dict[str, Any],
        validator: Callable[[dict[str, Any]], tuple[bool, str | None]],
    ) -> dict[str, Any] | None:
        """Attempt to recover valid structured output from LLM stdout.

        When the LLM writes revision/examination JSON to stdout instead of
        editing the template file, this method tries to extract and validate
        that output.  Uses the existing ``extract_json_payload`` utility which
        handles markdown code fences and bare JSON objects in mixed text.

        Returns validated data dict on success, ``None`` on failure.
        """
        data = self.extract_json_payload_from_stdout(stdout)
        if isinstance(data, dict):
            data.pop("_instructions", None)
            is_valid, _ = validator(data)
            if is_valid:
                return data

        return None

    def extract_json_payload_from_stdout(
        self,
        stdout: str,
    ) -> dict[str, Any] | list[Any] | None:
        """Extract structured JSON data from stdout-only output."""
        if not stdout or not stdout.strip():
            return None

        try:
            return json.loads(stdout.strip())
        except (json.JSONDecodeError, ValueError):
            pass

        recovered_data, _ = self.recover_json_payload(stdout)
        if recovered_data is not None:
            return recovered_data

        return None
