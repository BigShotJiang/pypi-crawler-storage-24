"""FlowContext: typed runtime context for session flows.

Replaces direct ``self._orch._*`` field accesses in DeriveFlow and
ResumeFlow with reads/writes on an explicit, documented contract.
Internally proxies to the underlying orchestrator so that all mutations
remain visible to atexit handlers, signal handlers, and any other code
that reads orchestrator state during flow execution.

Usage in flows::

    class DeriveFlow:
        def __init__(self, runtime: FlowContext, ...) -> None:
            self._rt = runtime
            ...

        def _setup_parameters(self) -> None:
            self._rt.runtime_state.bypass_modes = self._bypass_modes
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from obra.api import APIClient
    from obra.api.protocol import SessionPhase
    from obra.display.observability import ProgressEmitter
    from obra.hybrid.contract_validator import SessionContractValidator
    from obra.hybrid.dispatch.dispatcher import ActionDispatcher
    from obra.hybrid.error_handler import ErrorHandler
    from obra.hybrid.event_logger import HybridEventLogger
    from obra.hybrid.git_ops import GitOperations
    from obra.hybrid.health_monitor import HealthMonitor
    from obra.hybrid.llm_setup import LLMConfigurator
    from obra.hybrid.progress_tracker import ProgressTracker
    from obra.hybrid.runtime_state import HybridRuntimeState
    from obra.hybrid.server_protocol import ServerProtocol
    from obra.hybrid.session_guard import SessionGuard
    from obra.observability.production_logger import ProductionLogger


# All field names that FlowContext exposes.  Used by __setattr__ to guard
# against typos — only names in this set (plus '_orch') are proxied.
_KNOWN_FIELDS: frozenset[str] = frozenset({
    # Core infrastructure
    "client", "contract_validator", "error_handler", "event_logger",
    "git_ops", "health_monitor", "invocation", "llm_configurator",
    "progress_emitter", "progress_tracker", "refinement", "runtime_state",
    "server_protocol", "trace", "working_dir",
    # Callable references (bound orchestrator methods)
    "atexit_session_terminal_event", "cleanup_story0_containers",
    "display_bypass_notices", "emit_progress", "emit_runtime_banner",
    "ensure_online", "force_quit_session_terminal_event",
    "get_project_context", "get_session_files", "log_session_event",
    "record_invocation", "request_with_observability",
    "resolve_project_name",
    # Mutable session state
    "current_phase", "dispatcher", "domain", "effective_llm_map",
    "fix_result_history", "inflight_client_requests",
    "polling_failure_count", "preflight_results",
    "production_logger", "project_id", "project_name",
    "server_validation", "session_guard",
    "session_start_contract_warnings", "work_type_override",
    # Property delegates
    "was_escalated",
    # Session flow runtime (dispatch runtime — not this class)
    "session_flow_runtime",
    # Session lifecycle collaborator
    "session_lifecycle",
})


class FlowContext:
    """Typed runtime context for DeriveFlow / ResumeFlow.

    Provides explicit ``@property`` definitions for every field that flows
    access, mapping ``context.field`` to ``orchestrator._field``.  Write
    access is proxied through ``__setattr__`` so that all mutations remain
    visible to orchestrator-level signal/atexit handlers.

    An unknown-attribute ``__getattr__`` fallback raises ``AttributeError``
    instead of silently proxying, so typos are caught at development time.
    """

    __slots__ = ("_orch",)

    def __init__(self, orch: Any) -> None:
        object.__setattr__(self, "_orch", orch)

    # Fields that live on HybridRuntimeState rather than the orchestrator
    _RUNTIME_STATE_FIELDS: frozenset[str] = frozenset({
        "current_phase", "polling_failure_count", "project_id",
    })

    # ------------------------------------------------------------------
    # Write proxy — delegates ``ctx.field = value`` to ``orch._field = value``
    # For fields on HybridRuntimeState, writes to ``orch._runtime_state.field``.
    # ------------------------------------------------------------------

    def __setattr__(self, name: str, value: Any) -> None:
        if name not in _KNOWN_FIELDS:
            raise AttributeError(
                f"{type(self).__name__} has no attribute {name!r}. "
                f"Add it to _KNOWN_FIELDS and define a @property if needed."
            )
        if name in self._RUNTIME_STATE_FIELDS:
            setattr(self._orch._runtime_state, name, value)
        else:
            setattr(self._orch, f"_{name}", value)

    # ------------------------------------------------------------------
    # Fallback for unknown attributes — strict, not silently proxied
    # ------------------------------------------------------------------

    def __getattr__(self, name: str) -> Any:
        if name in _KNOWN_FIELDS:
            # Property descriptor was not defined yet — fall back to orch proxy.
            return getattr(self._orch, f"_{name}")
        raise AttributeError(
            f"{type(self).__name__} has no attribute {name!r}. "
            f"Add it to _KNOWN_FIELDS and define a @property if needed."
        )

    # ------------------------------------------------------------------
    # Core infrastructure properties
    # ------------------------------------------------------------------

    @property
    def client(self) -> APIClient:
        return self._orch._client

    @property
    def contract_validator(self) -> SessionContractValidator:
        return self._orch._contract_validator

    @property
    def error_handler(self) -> ErrorHandler:
        return self._orch._error_handler

    @property
    def event_logger(self) -> HybridEventLogger:
        return self._orch._event_logger

    @property
    def git_ops(self) -> GitOperations:
        return self._orch._git_ops

    @property
    def health_monitor(self) -> HealthMonitor:
        return self._orch._health_monitor

    @property
    def invocation(self) -> Any:
        return self._orch._invocation

    @property
    def llm_configurator(self) -> LLMConfigurator:
        return self._orch._llm_configurator

    @property
    def progress_emitter(self) -> ProgressEmitter | None:
        return self._orch._progress_emitter

    @property
    def progress_tracker(self) -> ProgressTracker:
        return self._orch._progress_tracker

    @property
    def refinement(self) -> Any:
        return self._orch._refinement

    @property
    def runtime_state(self) -> HybridRuntimeState:
        return self._orch._runtime_state

    @property
    def server_protocol(self) -> ServerProtocol:
        return self._orch._server_protocol

    @property
    def trace(self) -> Any:
        return self._orch._trace

    @property
    def working_dir(self) -> Any:
        return self._orch._working_dir

    # ------------------------------------------------------------------
    # Callable references (bound orchestrator methods)
    # ------------------------------------------------------------------

    @property
    def atexit_session_terminal_event(self) -> Any:
        return self._orch._atexit_session_terminal_event

    @property
    def cleanup_story0_containers(self) -> Any:
        return self._orch._cleanup_story0_containers

    @property
    def display_bypass_notices(self) -> Any:
        return self._orch._display_bypass_notices

    @property
    def emit_progress(self) -> Any:
        return self._orch._emit_progress

    @property
    def emit_runtime_banner(self) -> Any:
        return self._orch._emit_runtime_banner

    @property
    def ensure_online(self) -> Any:
        return self._orch._ensure_online

    @property
    def force_quit_session_terminal_event(self) -> Any:
        return self._orch._force_quit_session_terminal_event

    @property
    def get_project_context(self) -> Any:
        return self._orch._get_project_context

    @property
    def get_session_files(self) -> Any:
        return self._orch._get_session_files

    @property
    def log_session_event(self) -> Any:
        return self._orch._log_session_event

    @property
    def record_invocation(self) -> Any:
        return self._orch._record_invocation

    @property
    def request_with_observability(self) -> Any:
        return self._orch._request_with_observability

    @property
    def resolve_project_name(self) -> Any:
        return self._orch._resolve_project_name

    # ------------------------------------------------------------------
    # Mutable session state (read via property, write via __setattr__)
    # ------------------------------------------------------------------

    @property
    def current_phase(self) -> SessionPhase | None:
        return self._orch._runtime_state.current_phase

    @property
    def dispatcher(self) -> ActionDispatcher | None:
        return self._orch._dispatcher

    @property
    def domain(self) -> Any:
        return self._orch._domain

    @property
    def effective_llm_map(self) -> dict[str, Any] | None:
        return getattr(self._orch, "_effective_llm_map", None)

    @property
    def fix_result_history(self) -> list[dict[str, Any]]:
        return self._orch._runtime_state.fix_result_history

    @property
    def inflight_client_requests(self) -> set[str]:
        return self._orch._inflight_client_requests

    @property
    def polling_failure_count(self) -> int:
        return self._orch._runtime_state.polling_failure_count

    @property
    def preflight_results(self) -> dict[str, Any] | None:
        return getattr(self._orch, "_preflight_results", None)

    @property
    def production_logger(self) -> ProductionLogger | None:
        return self._orch._production_logger

    @property
    def project_id(self) -> str | None:
        return self._orch._runtime_state.project_id

    @property
    def project_name(self) -> str | None:
        return self._orch._project_name

    @property
    def server_validation(self) -> dict[str, Any] | None:
        return getattr(self._orch, "_server_validation", None)

    @property
    def session_guard(self) -> SessionGuard | None:
        return self._orch._session_guard

    @property
    def session_start_contract_warnings(self) -> list[Any] | None:
        return self._orch._session_start_contract_warnings

    @property
    def work_type_override(self) -> str | None:
        return getattr(self._orch, "_work_type_override", None)

    # ------------------------------------------------------------------
    # Property delegates
    # ------------------------------------------------------------------

    @property
    def was_escalated(self) -> bool:
        return self._orch._was_escalated

    # ------------------------------------------------------------------
    # Session flow runtime (dispatch runtime — not this class)
    # ------------------------------------------------------------------

    @property
    def session_flow_runtime(self) -> Any:
        return self._orch._session_flow_runtime

    # ------------------------------------------------------------------
    # Representation
    # ------------------------------------------------------------------

    def __repr__(self) -> str:
        sid = getattr(self._orch, "_runtime_state", None)
        session_id = getattr(sid, "session_id", None) if sid else None
        return f"<FlowContext session={session_id}>"


# Backward-compatible alias
SessionFlowRuntime = FlowContext
