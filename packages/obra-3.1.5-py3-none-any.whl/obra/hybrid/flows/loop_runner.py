"""Shared orchestration loop for DeriveFlow and ResumeFlow."""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Protocol

from obra.api.protocol import ActionType, CompletionNotice, ServerAction
from obra.core.interrupts import GracefulInterrupt, interrupt_requested
from obra.exceptions import OrchestratorError
from obra.execution.skip_record import SkipReason, SkipSource, create_skip_record
from obra.messages import get_message

if TYPE_CHECKING:
    from obra.hybrid.orchestrator import HybridOrchestrator

logger = logging.getLogger(__name__)

PLAN_ONLY_EXIT_ACTIONS = frozenset(
    {
        ActionType.STORY0,
        ActionType.STORY_PREFLIGHT,
        ActionType.EXECUTE,
        ActionType.REVIEW,
        ActionType.FIX,
    }
)


@dataclass(frozen=True)
class LoopConfig:
    """Configuration flags controlling shared orchestration loop behaviour."""

    max_iterations: int
    enable_session_guard_timeout: bool = False
    enable_report_as_transform: bool = False
    enable_skip_tracking: bool = False
    on_plan_only_exit: Callable[[dict[str, Any], ActionType, int], CompletionNotice] | None = None


class LoopCallbacks(Protocol):
    """Structural protocol satisfied by DeriveFlow and ResumeFlow."""

    def _handle_completion(self, result: dict[str, Any], iteration: int) -> CompletionNotice: ...

    def _handle_waiting(
        self, server_action: ServerAction, poll_count: int, iteration: int
    ) -> tuple[ServerAction, int]: ...

    def _handle_exception(self, exc: Exception) -> None: ...

    def _cleanup(self) -> None: ...


def run_orchestration_loop(
    orch: HybridOrchestrator,
    initial_action: ServerAction,
    config: LoopConfig,
    callbacks: LoopCallbacks,
) -> CompletionNotice:
    """Execute the shared orchestration while-loop.

    This is the canonical loop body shared by DeriveFlow and ResumeFlow.
    Flow-specific behaviour is controlled by ``config`` flags.
    """
    iteration = 0
    poll_count = 0
    stall_iterations = 0
    loop_error: OrchestratorError | None = None
    server_action = initial_action

    try:
        while True:
            iteration += 1
            logger.debug(f"Orchestration loop iteration {iteration}")

            # ISSUE-HYBRID-074: Break if pipeline/session already completed
            # Prevents post-completion execution leakage
            if orch._event_logger.session_completed_logged:
                logger.info("Session already completed, exiting action loop")
                break

            # FEAT-SESSION-GUARD-001: Check session timeout (may prompt user)
            if (
                config.enable_session_guard_timeout
                and orch._session_guard
                and orch._session_guard.check_timeout()
            ):
                loop_error = OrchestratorError(
                    f"Session terminated: runtime exceeded {orch._session_guard.max_hours}h limit",
                    session_id=orch._runtime_state.session_id or "",
                    recovery="Use OBRA_SESSION_MAX_HOURS to increase limit if needed",
                )
                break

            # CLI-CACHE-MONITOR-001: Mid-session cache check every 10 iterations
            if iteration % 10 == 0:
                orch._health_monitor._check_cli_cache_health("mid_session")

            # Handle current action
            progress_before = orch._progress_tracker._progress_snapshot(server_action.action)
            result = orch._handle_action(server_action)

            # FEAT-SESSION-GUARD-001: Update session guard with progress
            if orch._session_guard:
                try:
                    heartbeat_iteration = int(server_action.iteration)
                except (TypeError, ValueError):
                    heartbeat_iteration = iteration
                orch._session_guard.update(
                    iteration=heartbeat_iteration,
                    items_completed=orch._invocation.items_completed_this_invocation,
                    phase=(orch._runtime_state.current_phase.value if orch._runtime_state.current_phase else "unknown"),
                )

            # Check for completion
            if result.get("completed"):
                return callbacks._handle_completion(result, iteration)

            # Check for waiting (async processing)
            if result.get("waiting"):
                server_action, poll_count = callbacks._handle_waiting(
                    server_action, poll_count, iteration
                )
                continue
            # Reset poll count when not waiting
            poll_count = 0

            # Report result and get next action
            if config.enable_report_as_transform:
                report_as = result.pop("_report_as", None)
                action_to_report = (
                    ActionType(report_as)
                    if isinstance(report_as, str) and report_as
                    else server_action.action
                )
            else:
                action_to_report = server_action.action

            server_action = orch._report_result(action_to_report, result)
            if interrupt_requested():
                orch._error_handler._emit_session_interrupted(
                    reason=orch._error_handler._resolve_interrupt_reason(fallback="sigint")
                )
                msg = "post_action_report"
                raise GracefulInterrupt(msg)

            # Plan-only mode: stop before execution once plan is ready.
            if (
                config.on_plan_only_exit is not None
                and server_action.action in PLAN_ONLY_EXIT_ACTIONS
            ):
                return config.on_plan_only_exit(result, action_to_report, iteration)

            # Check for error response
            if server_action.is_error():
                loop_error = OrchestratorError(
                    server_action.error_message or "Server returned error",
                    session_id=orch._runtime_state.session_id,
                )
                break

            if orch._progress_tracker._detect_progress(progress_before, server_action.action, result):
                stall_iterations = 0
            else:
                stall_iterations += 1
                if stall_iterations >= config.max_iterations:
                    error_message = (
                        "Orchestration loop exceeded "
                        f"{config.max_iterations} consecutive non-progress iterations"
                    )
                    # Emit session_failed before raising so log viewer can display termination reason
                    orch._log_session_event(
                        "session_failed",
                        error_code="MAX_ITERATIONS",
                        error_class="OrchestratorError",
                        error_message=error_message,
                        phase=(orch._runtime_state.current_phase.value if orch._runtime_state.current_phase else "unknown"),
                    )
                    if config.enable_skip_tracking and orch._is_skip_tracking_enabled(
                        "orchestrator"
                    ):
                        current_item_id = (orch._runtime_state.last_item_id or "") or "unknown"
                        create_skip_record(
                            session_id=orch._runtime_state.session_id or "",
                            task_id=current_item_id,
                            source=SkipSource.ORCHESTRATOR,
                            reason=SkipReason.MAX_ITERATIONS,
                            description=(
                                "Execution terminated at max non-progress iterations "
                                "with work remaining"
                            ),
                            source_context={
                                "iteration": iteration,
                                "stall_iterations": stall_iterations,
                                "max_iterations": config.max_iterations,
                            },
                        )
                        logger.info("Run 'obra skips list' to review skipped items")
                    short_id = orch._runtime_state.session_id.split("-")[0] if orch._runtime_state.session_id else ""
                    loop_error = OrchestratorError(
                        error_message,
                        session_id=orch._runtime_state.session_id,
                        recovery=(
                            "This may indicate a bug. Resume with: "
                            f"{get_message('recovery.session.resume', short_id=short_id)}"
                        ),
                    )
                    break

        # Unexpected loop exit - set error to raise outside try block (TRY301)
        if loop_error is None:
            error_message = "Orchestration loop exited unexpectedly"
            # Emit session_failed before raising so log viewer can display termination reason
            orch._log_session_event(
                "session_failed",
                error_code="ORCHESTRATOR_ERROR",
                error_class="OrchestratorError",
                error_message=error_message,
                phase=(orch._runtime_state.current_phase.value if orch._runtime_state.current_phase else "unknown"),
            )
            short_id = orch._runtime_state.session_id.split("-")[0] if orch._runtime_state.session_id else ""
            loop_error = OrchestratorError(
                error_message,
                session_id=orch._runtime_state.session_id,
                recovery=f"This may indicate a bug. Resume with: {get_message('recovery.session.resume', short_id=short_id)}",
            )
    except Exception as e:
        callbacks._handle_exception(e)
        raise
    finally:
        callbacks._cleanup()

    # TRY301: Raise loop error outside try block
    if loop_error is not None:
        orch._cleanup_story0_containers()
        raise loop_error
    return None  # type: ignore[return-value]
