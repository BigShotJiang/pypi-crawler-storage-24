"""Session lifecycle flow runners extracted from HybridOrchestrator."""

from __future__ import annotations

import importlib

__all__ = ["DeriveFlow", "LoopCallbacks", "LoopConfig", "ResumeFlow", "run_orchestration_loop"]


def __getattr__(name: str) -> object:
    if name == "DeriveFlow":
        module = importlib.import_module(".derive", __name__)
        return module.DeriveFlow
    if name == "ResumeFlow":
        module = importlib.import_module(".resume", __name__)
        return module.ResumeFlow
    if name == "LoopConfig":
        module = importlib.import_module(".loop_runner", __name__)
        return module.LoopConfig
    if name == "LoopCallbacks":
        module = importlib.import_module(".loop_runner", __name__)
        return module.LoopCallbacks
    if name == "run_orchestration_loop":
        module = importlib.import_module(".loop_runner", __name__)
        return module.run_orchestration_loop
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
