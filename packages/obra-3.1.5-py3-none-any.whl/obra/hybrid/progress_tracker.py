"""Progress and phase tracking for HybridOrchestrator.

Extracted from obra/hybrid/orchestrator.py as part of REFACTOR-ORCH-EXTRACT-001.
Handles work summary extraction, task item counting, progress snapshots,
stall detection progress checks, and phase transition events.
"""

from __future__ import annotations

import logging
import uuid
from collections.abc import Callable
from typing import TYPE_CHECKING, Any

from obra.api.protocol import ActionType, SessionPhase
from obra.hybrid.event_logger import HybridEventLogger

if TYPE_CHECKING:
    from obra.hybrid.orchestrator import (
        InvocationState,
        RefinementState,
        TraceContext,
    )
    from obra.hybrid.runtime_state import HybridRuntimeState

logger = logging.getLogger(__name__)


class ProgressTracker:
    """Progress and phase tracking extracted from HybridOrchestrator.

    Handles work summary extraction, task item counting, progress snapshots,
    stall detection progress checks, and phase transition event emission.
    Receives shared state via constructor injection.
    """

    def __init__(
        self,
        invocation: InvocationState,
        trace: TraceContext,
        refinement: RefinementState,
        event_logger: HybridEventLogger,
        runtime_state: HybridRuntimeState,
        locally_completed_items: set[str],
        locally_completed_phases: set[str],
        locally_started_phases: set[str],
        was_escalated_getter: Callable[[], bool],
        emit_progress: Callable[[str, dict[str, Any]], None],
        log_session_event: Callable[..., None],
    ) -> None:
        self._invocation = invocation
        self._trace = trace
        self._refinement = refinement
        self._event_logger = event_logger
        self._state = runtime_state
        self._locally_completed_items = locally_completed_items
        self._locally_completed_phases = locally_completed_phases
        self._locally_started_phases = locally_started_phases
        self._was_escalated_getter = was_escalated_getter
        self._emit_progress = emit_progress
        self._log_session_event_callable = log_session_event

    def _log_session_event(self, event_type: str, **kwargs) -> None:
        self._log_session_event_callable(event_type, **kwargs)

    def _extract_work_summary(self) -> list[str]:
        """Extract 2-3 bullet summary of completed work.

        FEAT-SESSION-CLOSEOUT-001 S4.T3: Generate human-readable work summary.

        Returns:
            List of 2-3 strings summarizing completed work, or empty list.
        """
        summary: list[str] = []

        # Extract from last derivation plan items that were completed
        last_derivation_plan_items = self._state.last_derivation_plan_items
        if last_derivation_plan_items and self._locally_completed_items:
            for item in last_derivation_plan_items:
                item_id = item.get("item_id") or item.get("id", "")
                if item_id in self._locally_completed_items:
                    # Use title or description
                    title = item.get("title") or item.get("description", "")
                    if title and len(summary) < 3:
                        # Truncate long titles
                        if len(title) > 80:
                            title = title[:77] + "..."
                        summary.append(title)

        # If no items from plan, use items_completed count
        if not summary and self._invocation.items_completed_this_invocation > 0:
            summary.append(f"Completed {self._invocation.items_completed_this_invocation} item(s)")

        return summary

    def get_closeout_progress_snapshot(self) -> dict[str, Any]:
        """Return progress metrics used by interrupted closeout telemetry."""
        epics_total = 0
        epics_completed = 0
        stories_total = 0
        stories_completed = 0

        last_derivation_plan_items = self._state.last_derivation_plan_items
        if last_derivation_plan_items:
            # Build child→parent mapping to derive epic/story completion
            # from completed task items.
            completed = self._locally_completed_items
            for item in last_derivation_plan_items:
                if not isinstance(item, dict):
                    continue
                item_type = str(
                    item.get("item_type") or item.get("type") or ""
                ).strip().lower()
                item_id = str(item.get("item_id") or item.get("id") or "")
                if item_type == "epic":
                    epics_total += 1
                    if item_id in completed:
                        epics_completed += 1
                elif item_type == "story":
                    stories_total += 1
                    if item_id in completed:
                        stories_completed += 1

            # Derive completion from children: an epic/story is complete
            # when all its child tasks are complete.
            if completed and (epics_completed == 0 or stories_completed == 0):
                children_by_parent: dict[str, list[str]] = {}
                parent_types: dict[str, str] = {}
                for item in last_derivation_plan_items:
                    if not isinstance(item, dict):
                        continue
                    item_id = str(item.get("item_id") or item.get("id") or "")
                    parent_id = str(item.get("parent_id") or "")
                    item_type = str(
                        item.get("item_type") or item.get("type") or ""
                    ).strip().lower()
                    if parent_id:
                        children_by_parent.setdefault(parent_id, []).append(item_id)
                    if item_type in ("epic", "story"):
                        parent_types[item_id] = item_type

                for parent_id, child_ids in children_by_parent.items():
                    if parent_id not in parent_types:
                        continue
                    if all(cid in completed for cid in child_ids):
                        ptype = parent_types[parent_id]
                        if ptype == "epic":
                            epics_completed += 1
                        elif ptype == "story":
                            stories_completed += 1

            # Clamp to totals (defensive)
            epics_completed = min(epics_completed, epics_total)
            stories_completed = min(stories_completed, stories_total)

        current_phase = self._state.current_phase
        return {
            "items_completed": int(self._invocation.items_completed_this_invocation),
            "tasks_completed": int(self._invocation.items_completed_this_invocation),
            "tasks_total": int(self._state.tasks_total),
            "epics_completed": epics_completed,
            "epics_total": epics_total,
            "stories_completed": stories_completed,
            "stories_total": stories_total,
            "last_phase": current_phase.value if current_phase else "unknown",
            "was_escalated": bool(self._was_escalated_getter()),
        }

    def _action_to_phase(self, action: ActionType) -> SessionPhase | None:
        """Map action type to session phase.

        Args:
            action: Action type from server

        Returns:
            Corresponding session phase, or None for non-phase actions
        """
        phase_mapping = {
            ActionType.DERIVE: SessionPhase.DERIVATION,
            ActionType.INTENT: SessionPhase.DERIVATION,
            ActionType.STORY0: SessionPhase.STORY0,
            ActionType.STORY_PREFLIGHT: SessionPhase.EXECUTION,
            ActionType.EXAMINE: SessionPhase.REFINEMENT,
            ActionType.REVISE: SessionPhase.REFINEMENT,
            ActionType.EXECUTE: SessionPhase.EXECUTION,
            ActionType.REVIEW: SessionPhase.REVIEW,
        }
        return phase_mapping.get(action)

    def _progress_snapshot(self, action: ActionType | None) -> dict[str, Any]:
        """Capture minimal progress state for stall detection."""
        current_phase = self._state.current_phase
        return {
            "items_completed": self._invocation.items_completed_this_invocation,
            "last_item_id": self._state.last_item_id,
            "phase": current_phase.value if current_phase else "unknown",
            "action": action.value if action else None,
        }

    def _detect_progress(
        self,
        before: dict[str, Any],
        next_action: ActionType | None,
        result: dict[str, Any],
    ) -> bool:
        """Detect meaningful progress to reset stall iteration counter."""
        if result.get("completed"):
            return True
        if self._invocation.items_completed_this_invocation > before["items_completed"]:
            return True
        last_item_id = self._state.last_item_id
        if last_item_id and last_item_id != before["last_item_id"]:
            return True
        current_phase = self._state.current_phase
        current_phase_val = current_phase.value if current_phase else "unknown"
        if current_phase_val != before["phase"]:
            return True
        if next_action and before.get("action") and next_action.value != before.get("action"):
            return True
        return False

    def _emit_phase_event(self, action: ActionType) -> None:
        """Emit phase transition events based on action.

        Tracks phase changes and emits phase_started/phase_completed events
        via the on_progress callback.

        Args:
            action: Current action type
        """
        import time

        new_phase = self._action_to_phase(action)
        current_phase = self._state.current_phase
        phase_start_time = self._state.phase_start_time
        if new_phase is None:
            # FIX-SPINNER-HANG-001: Terminal actions (COMPLETE, ESCALATE) don't map
            # to a phase, but we still need to close the current phase so the CLI
            # spinner is stopped and console output is no longer buffered by Live.
            if current_phase is not None and phase_start_time is not None:
                duration_ms = int((time.time() - phase_start_time) * 1000)
                self._emit_progress(
                    "phase_completed",
                    {
                        "phase": current_phase.value,
                        "duration_ms": duration_ms,
                        "result": None,
                    },
                )
                self._locally_completed_phases.add(current_phase.value)
                self._log_session_event(
                    "phase_completed",
                    phase=current_phase.value,
                    duration_ms=duration_ms,
                    duration_seconds=round(duration_ms / 1000, 1),
                    span_id=self._trace.phase_span_id,
                    parent_span_id=self._trace.pipeline_span_id,
                )
                self._log_session_event("resource_snapshot", snapshot_type=f"phase_{current_phase.value}_end")
                self._state.current_phase = None
                self._state.phase_start_time = None
                self._event_logger.set_phase_span_id(None)
            return

        # Check if phase changed
        if new_phase != current_phase:
            # Emit phase_completed for previous phase
            if current_phase is not None and phase_start_time is not None:
                duration_ms = int((time.time() - phase_start_time) * 1000)
                # FIX-TRACKER-001: Include plan items in DERIVATION phase_completed
                # This enables the CLI tracker to populate all items upfront
                phase_result: dict[str, Any] = {}
                last_derivation_plan_items = self._state.last_derivation_plan_items
                if current_phase == SessionPhase.DERIVATION:
                    phase_result = {
                        "item_count": len(last_derivation_plan_items),
                        "items": last_derivation_plan_items,
                    }
                # Emit refinement summary when refinement phase ends
                if (
                    current_phase == SessionPhase.REFINEMENT
                    and self._refinement.cycle_count > 0
                ):
                    refinement_duration_s = 0.0
                    if self._refinement.start_time:
                        refinement_duration_s = time.time() - self._refinement.start_time
                    phase_result["refinement_cycles"] = self._refinement.cycle_count
                    phase_result["refinement_duration_s"] = refinement_duration_s

                self._emit_progress(
                    "phase_completed",
                    {
                        "phase": current_phase.value,
                        "duration_ms": duration_ms,
                        "result": phase_result if phase_result else None,
                    },
                )
                # Track locally completed phases to prevent duplicate server-echoed emissions
                self._locally_completed_phases.add(current_phase.value)
                # ISSUE-OBS-002: Log phase_completed to production logger
                self._log_session_event(
                    "phase_completed",
                    phase=current_phase.value,
                    duration_ms=duration_ms,
                    duration_seconds=round(duration_ms / 1000, 1),
                    span_id=self._trace.phase_span_id,
                    parent_span_id=self._trace.pipeline_span_id,
                )
                self._log_session_event("resource_snapshot", snapshot_type=f"phase_{current_phase.value}_end")
                self._event_logger.set_phase_span_id(None)

            # Emit phase_started for new phase
            self._state.current_phase = new_phase
            self._state.phase_start_time = time.time()
            self._trace.phase_span_id = uuid.uuid4().hex
            self._event_logger.set_phase_span_id(self._trace.phase_span_id)
            self._emit_progress(
                "phase_started",
                {
                    "phase": new_phase.value,
                },
            )
            self._locally_started_phases.add(new_phase.value)
            # ISSUE-OBS-002: Log phase_started to production logger
            self._log_session_event(
                "phase_started",
                phase=new_phase.value,
                span_id=self._trace.phase_span_id,
                parent_span_id=self._trace.pipeline_span_id,
            )
            self._log_session_event("resource_snapshot", snapshot_type=f"phase_{new_phase.value}_start")
