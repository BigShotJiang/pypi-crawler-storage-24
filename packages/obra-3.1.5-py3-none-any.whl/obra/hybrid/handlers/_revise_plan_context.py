"""Plan-context extraction helpers for ReviseHandler.

These functions were extracted from ReviseHandler to reduce class size.
They handle parsing current-plan JSON from revision prompts, building
source-step-id and hierarchy context maps, merging server-supplied
full-plan context, and canonicalising decomposition subtask items.

Related:
    - obra/hybrid/handlers/revise.py (ReviseHandler)
    - docs/design/prds/UNIFIED_HYBRID_ARCHITECTURE_PRD.md
"""

from __future__ import annotations

import json
import logging
import re as _re
from collections.abc import Callable
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal helpers (not part of the 9 public functions, but needed by them)
# ---------------------------------------------------------------------------


def _coerce_depth(value: Any) -> int | None:
    """Parse depth values from LLM/context payloads."""
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _generate_decomposition_subtask_id(
    *,
    parent_id: str,
    index: int,
    existing_ids: set[str],
) -> str:
    """Generate stable client-side subtask IDs aligned with server decomposition IDs."""
    base_id = f"{parent_id}.sub{index}"
    candidate_id = base_id
    suffix = 1
    while candidate_id in existing_ids:
        candidate_id = f"{base_id}.{suffix}"
        suffix += 1
    existing_ids.add(candidate_id)
    return candidate_id


# ---------------------------------------------------------------------------
# Extracted plan-context functions
# ---------------------------------------------------------------------------


def _build_item_context_map(items: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    """Build a map of item ID to hierarchy/context fields from current plan."""
    context_map: dict[str, dict[str, Any]] = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        item_id = item.get("id")
        if not item_id:
            continue
        context_map[item_id] = {
            "parent_id": item.get("parent_id"),
            "depth": item.get("depth"),
            "item_type": item.get("item_type"),
            "title": item.get("title"),
            "description": item.get("description"),
            "acceptance_criteria": item.get("acceptance_criteria", []),
            "dependencies": item.get("dependencies", []),
        }
    return context_map


def _build_source_step_id_map(items: list[dict[str, Any]]) -> dict[str, str]:
    """Build a map of item ID to source_step_id from current plan items.

    ISSUE-HYBRID-006: Used to inherit source_step_id for revised items
    that match by ID.

    Args:
        items: Current plan items from the prompt

    Returns:
        Dict mapping item ID to source_step_id
    """
    source_map: dict[str, str] = {}
    for item in items:
        if not isinstance(item, dict):
            continue
        item_id = item.get("id")
        source_step_id = item.get("source_step_id")
        if item_id and source_step_id:
            source_map[item_id] = source_step_id
    return source_map


def _get_default_source_step_id(items: list[dict[str, Any]]) -> str | None:
    """Get the first source_step_id from current plan items as default.

    ISSUE-HYBRID-006: When LLM returns new items without source_step_id,
    default to the first source_step_id in the current plan.

    Args:
        items: Current plan items from the prompt

    Returns:
        First source_step_id found, or None if none exist
    """
    for item in items:
        if isinstance(item, dict):
            source_step_id = item.get("source_step_id")
            if source_step_id:
                return source_step_id
    return None


def _extract_plan_items_from_json_blocks(prompt: str) -> list[dict[str, Any]]:
    """Last-resort extraction of plan items from JSON blocks in prompt.

    FIX-HYBRID-036: When _extract_plan_from_prompt fails (missing markers),
    scan the prompt for JSON arrays containing plan-item-shaped objects.
    """
    items: list[dict[str, Any]] = []
    required_keys = {"id", "item_type", "title"}
    # Find JSON arrays in the prompt
    for match in _re.finditer(r"\[[\s\S]*?\]", prompt):
        try:
            candidate = json.loads(match.group())
        except (json.JSONDecodeError, ValueError):
            continue
        if not isinstance(candidate, list) or not candidate:
            continue
        # Check if first element looks like a plan item
        first = candidate[0]
        if isinstance(first, dict) and required_keys.issubset(first.keys()):
            items.extend(
                item for item in candidate if isinstance(item, dict)
            )
    return items


def _extract_source_context_from_prompt(
    prompt: str,
) -> tuple[dict[str, str], str | None, dict[str, dict[str, Any]]]:
    """Extract source_step_id and hierarchy context from the current plan in the prompt.

    ISSUE-HYBRID-006: Parses the current plan from the revision prompt
    to build source_step_id inheritance context.

    Args:
        prompt: The enriched revision prompt containing current plan

    Returns:
        Tuple of (source_step_id_map, default_source_step_id, item_context_map)
    """
    start_marker = "BEGIN CURRENT PLAN JSON"
    end_marker = "END CURRENT PLAN JSON"
    start = prompt.find(start_marker)
    end = prompt.find(end_marker)
    if start == -1 or end == -1 or end <= start:
        return {}, None, {}

    json_block = prompt[start + len(start_marker) : end].strip()
    try:
        data = json.loads(json_block)
    except json.JSONDecodeError:
        return {}, None, {}

    if isinstance(data, dict):
        items = data.get("plan_items", [])
    elif isinstance(data, list):
        items = data
    else:
        return {}, None, {}

    source_map = _build_source_step_id_map(items)
    default_source = _get_default_source_step_id(items)
    context_map = _build_item_context_map(items)
    return source_map, default_source, context_map


def _extract_plan_from_prompt(
    prompt: str,
    *,
    userplan_id: str | None = None,
    normalize_fn: Callable[..., list[dict[str, Any]]] | None = None,
) -> tuple[list[dict[str, Any]], str]:
    """Extract current plan items from the revision prompt if available.

    Args:
        prompt: The enriched revision prompt containing current plan
        userplan_id: Optional UserPlan ID for fallback source_step_id
        normalize_fn: Callable matching the signature of
            ``ReviseHandler._normalize_plan_items`` used to normalise the
            extracted items.  When *None*, items are returned as-is.
    """
    start_marker = "BEGIN CURRENT PLAN JSON"
    end_marker = "END CURRENT PLAN JSON"
    start = prompt.find(start_marker)
    end = prompt.find(end_marker)
    if start == -1 or end == -1 or end <= start:
        return [], "missing_markers"

    json_block = prompt[start + len(start_marker) : end].strip()
    try:
        data = json.loads(json_block)
    except json.JSONDecodeError:
        return [], "invalid_json"

    if isinstance(data, dict):
        items = data.get("plan_items", [])
    elif isinstance(data, list):
        items = data
    else:
        return [], "unexpected_format"

    # ISSUE-HYBRID-006: Extract source_step_id context for normalization
    source_step_id_map = _build_source_step_id_map(items)
    default_source_step_id = _get_default_source_step_id(items)
    item_context_map = _build_item_context_map(items)

    if normalize_fn is not None:
        normalized = normalize_fn(
            items,
            default_source_step_id=default_source_step_id,
            source_step_id_map=source_step_id_map,
            item_context_map=item_context_map,
            userplan_id=userplan_id,
        )
    else:
        normalized = items

    if not normalized:
        return [], "empty_items"
    return normalized, "parsed_current_plan"


def _merge_full_plan_context(
    full_plan_items: list[dict[str, Any]] | None,
    *,
    source_step_id_map: dict[str, str],
    default_source_step_id: str | None,
    item_context_map: dict[str, dict[str, Any]],
) -> tuple[dict[str, str], str | None, dict[str, dict[str, Any]]]:
    """Merge server-supplied full-plan context with prompt-derived context."""
    if not full_plan_items:
        return source_step_id_map, default_source_step_id, item_context_map

    merged_source_map = dict(_build_source_step_id_map(full_plan_items))
    merged_source_map.update(source_step_id_map)

    merged_context_map = _build_item_context_map(full_plan_items)
    merged_context_map.update(item_context_map)

    merged_default_source = default_source_step_id or _get_default_source_step_id(
        full_plan_items
    )
    return merged_source_map, merged_default_source, merged_context_map


def _extract_decomposition_parent_id(
    blocking_issues: list[dict[str, Any]] | None,
) -> str | None:
    """Return the decomposition target item ID when revise is decomposing a task."""
    for issue in blocking_issues or []:
        if not isinstance(issue, dict):
            continue

        category = str(issue.get("category", "")).strip().lower()
        issue_id = str(issue.get("id", "")).strip()
        is_decomposition_issue = category == "decomposition" or issue_id.startswith(
            "decompose-"
        )
        if not is_decomposition_issue:
            continue

        affected_items = issue.get("affected_items")
        if isinstance(affected_items, list):
            for candidate in affected_items:
                candidate_id = str(candidate).strip()
                if candidate_id:
                    return candidate_id

        if issue_id.startswith("decompose-"):
            return issue_id.removeprefix("decompose-")
    return None


def _canonicalize_decomposition_items(
    items: list[dict[str, Any]],
    *,
    parent_id: str,
    full_plan_items: list[dict[str, Any]] | None,
    source_step_id_map: dict[str, str],
    item_context_map: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    """Attach decomposition subtasks to their parent before merge/report."""
    parent_context = item_context_map.get(parent_id, {})
    parent_depth = _coerce_depth(parent_context.get("depth"))
    if parent_depth is None:
        parent_depth = 0
    parent_source_step_id = source_step_id_map.get(parent_id)
    existing_ids = {
        str(item.get("id")).strip()
        for item in full_plan_items or []
        if isinstance(item, dict) and str(item.get("id")).strip()
    }

    id_map: dict[str, str] = {}
    canonical_items: list[dict[str, Any]] = []
    for index, item in enumerate(items, start=1):
        if not isinstance(item, dict):
            continue

        provided_id = str(item.get("id") or f"SUB{index}").strip() or f"SUB{index}"
        scoped_id = _generate_decomposition_subtask_id(
            parent_id=parent_id,
            index=index,
            existing_ids=existing_ids,
        )
        id_map[provided_id] = scoped_id

        scoped_item = dict(item)
        scoped_item["id"] = scoped_id
        scoped_item["item_type"] = scoped_item.get("item_type") or "subtask"
        scoped_item["parent_id"] = parent_id
        scoped_item["depth"] = parent_depth + 1
        if not scoped_item.get("source_step_id") and parent_source_step_id:
            scoped_item["source_step_id"] = parent_source_step_id
        canonical_items.append(scoped_item)

    for item in canonical_items:
        dependencies = item.get("dependencies")
        if not isinstance(dependencies, list):
            continue
        item["dependencies"] = [
            id_map.get(str(dep).strip(), dep) for dep in dependencies
        ]

    return canonical_items
