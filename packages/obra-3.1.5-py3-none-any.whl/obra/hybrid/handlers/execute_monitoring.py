"""Monitoring helpers extracted from the execute handler.

Contains the monitoring event adapter, file change tracking, and heartbeat
thread that were previously embedded in execute.py alongside ExecuteHandler.
"""

from __future__ import annotations

import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol

from obra.config.loaders import get_timeout
from obra.constants import LIVENESS_CHECK_INTERVAL_S
from obra.display.observability import ProgressEmitter, VerbosityLevel


class ExecuteHandlerProtocol(Protocol):
    """Protocol for the subset of ExecuteHandler used by monitoring classes."""

    _working_dir: Path

    def _get_file_changes(self) -> FileChangeSet: ...

    def _count_file_changes(self) -> int: ...

    def _count_lines(self, filepath: str) -> int | None: ...


class _MonitoringEventAdapter:
    """Adapter to emit monitoring events via log_event callback."""

    def __init__(self, log_event: Callable[..., None] | None) -> None:
        self._log_event = log_event

    def _emit(self, event_type: str, **kwargs: Any) -> None:
        if self._log_event:
            self._log_event(event_type, **kwargs)

    def log_liveness_check(
        self,
        session_id: str,
        task_id: int,
        status: str,
        alive_count: int,
        total_indicators: int,
        indicators: dict[str, bool],
    ) -> None:
        self._emit(
            "liveness_check",
            session_id=session_id,
            task_id=task_id,
            status=status,
            alive_count=alive_count,
            total_indicators=total_indicators,
            indicators=indicators,
        )

    def log_hang_investigation_started(
        self,
        session_id: str,
        task_id: int,
        pid: int,
    ) -> None:
        self._emit(
            "hang_investigation_started",
            session_id=session_id,
            task_id=task_id,
            pid=pid,
        )

    def log_hang_investigation_complete(
        self,
        session_id: str,
        task_id: int,
        pid: int,
        classification: str,
        confidence: float,
        action_recommended: str,
        evidence: dict[str, Any],
    ) -> None:
        self._emit(
            "hang_investigation_complete",
            session_id=session_id,
            task_id=task_id,
            pid=pid,
            classification=classification,
            confidence=confidence,
            action_recommended=action_recommended,
            evidence=evidence,
        )

    def log_timeout_extended(
        self,
        session_id: str,
        task_id: int,
        pid: int,
        reason: str,
        old_timeout: float,
        new_timeout: float,
        justification: str,
    ) -> None:
        self._emit(
            "timeout_extended",
            session_id=session_id,
            task_id=task_id,
            pid=pid,
            reason=reason,
            old_timeout=old_timeout,
            new_timeout=new_timeout,
            justification=justification,
        )

    def log_hang_detected(
        self,
        session_id: str,
        task_id: int,
        pid: int,
        classification: str,
        signal_sent: str,
        confidence: float,
    ) -> None:
        self._emit(
            "hang_detected",
            session_id=session_id,
            task_id=task_id,
            pid=pid,
            classification=classification,
            signal_sent=signal_sent,
            confidence=confidence,
        )


@dataclass
class FileChangeSet:
    """Represents a set of file changes detected in the working directory.

    Attributes:
        added: Set of filepaths for newly created files
        modified: Set of filepaths for modified existing files
        count: Total number of changed files (added + modified)
    """

    added: set[str]
    modified: set[str]
    count: int


class FileChangeTracker:
    """Tracks file changes between polls, returning only new changes.

    This class maintains state of previously seen file changes and returns
    only the delta (new changes) on each poll() call.

    Attributes:
        _handler: ExecuteHandler instance for file change detection
        _previous_added: Previously seen added files
        _previous_modified: Previously seen modified files
    """

    def __init__(self, handler: ExecuteHandlerProtocol) -> None:
        """Initialize the tracker.

        Args:
            handler: ExecuteHandler instance that provides _get_file_changes()
        """
        self._handler = handler
        self._previous_added: set[str] = set()
        self._previous_modified: set[str] = set()

    def poll(self) -> FileChangeSet:
        """Poll for new file changes since last poll.

        Returns:
            FileChangeSet containing only files that changed since the last poll
        """
        # Get current file changes
        current = self._handler._get_file_changes()

        # Calculate delta - only new files since last poll
        new_added = current.added - self._previous_added
        new_modified = current.modified - self._previous_modified

        # Update tracked state
        self._previous_added = current.added
        self._previous_modified = current.modified

        # Return only the delta
        new_count = len(new_added) + len(new_modified)
        return FileChangeSet(added=new_added, modified=new_modified, count=new_count)


class HeartbeatThread(threading.Thread):
    """Background thread that emits heartbeat messages during long-running execution.

    This thread runs alongside subprocess execution, periodically emitting
    heartbeat messages via ProgressEmitter to show execution is still active.
    It also monitors file changes and emits file events when detected.
    Additionally, it emits liveness_check events via log_event callback.

    Attributes:
        _item_id: ID of the plan item being executed
        _emitter: ProgressEmitter for output
        _file_tracker: FileChangeTracker for detecting file changes
        _handler: ExecuteHandler for line counting
        _interval: Seconds between heartbeats (scaled by verbosity)
        _initial_delay: Seconds to wait before first heartbeat
        _stop_event: Event signaling thread should stop
        _log_event: Optional callback for emitting liveness_check events
        _session_id: Optional session ID for trace correlation
        _trace_id: Optional trace ID for distributed tracing
        _start_time: Timestamp when execution started
        _alive_count: Counter for number of liveness checks emitted
    """

    def __init__(
        self,
        item_id: str,
        emitter: ProgressEmitter,
        file_tracker: FileChangeTracker,
        handler: ExecuteHandlerProtocol,
        interval: int,
        initial_delay: int,
        stop_event: threading.Event,
        log_event: Callable[..., None] | None = None,
        session_id: str | None = None,
        trace_id: str | None = None,
    ) -> None:
        """Initialize HeartbeatThread.

        Args:
            item_id: ID of the plan item being executed
            emitter: ProgressEmitter for output
            file_tracker: FileChangeTracker for detecting file changes
            handler: ExecuteHandler for line counting
            interval: Base interval between heartbeats (seconds)
            initial_delay: Delay before first heartbeat (seconds)
            stop_event: Event to signal thread should stop
            log_event: Optional callback for emitting liveness_check events
            session_id: Optional session ID for trace correlation
            trace_id: Optional trace ID for distributed tracing
        """
        super().__init__(daemon=True)
        self._item_id = item_id
        self._emitter = emitter
        self._file_tracker = file_tracker
        self._handler = handler
        self._interval = interval
        self._initial_delay = initial_delay
        self._stop_event = stop_event
        self._log_event = log_event
        self._session_id = session_id
        self._trace_id = trace_id
        self._start_time = time.time()
        self._alive_count = 0

    def run(self) -> None:
        """Main thread loop - emits heartbeats and file events until stopped.

        Waits for initial_delay, then emits heartbeats every interval seconds.
        On each iteration, also polls for file changes and emits file events.
        Every 180 seconds, emits liveness_check event via log_event callback.
        """
        # Wait for initial delay before first heartbeat
        self._stop_event.wait(self._initial_delay)

        # Track last liveness check time
        last_liveness_check = time.time()

        # Main heartbeat loop
        while not self._stop_event.is_set():
            # Calculate elapsed time since execution started
            elapsed = int(time.time() - self._start_time)

            # Get current file count for heartbeat
            file_count = self._get_file_count()

            # S4.T1: Get liveness indicators at DETAIL verbosity level
            liveness_indicators = None
            if self._emitter.config.verbosity >= VerbosityLevel.DETAIL:
                liveness_indicators = self._get_liveness_indicators()

            # Emit heartbeat with liveness indicators at DETAIL level
            self._emitter.item_heartbeat(self._item_id, elapsed, file_count, liveness_indicators)

            # S3.T1: Emit liveness_check event every LIVENESS_CHECK_INTERVAL_S
            current_time = time.time()
            if (
                self._log_event
                and (current_time - last_liveness_check) >= LIVENESS_CHECK_INTERVAL_S
            ):
                indicators = self._get_liveness_indicators()
                # Calculate status: "active" if any indicator is True, else "idle"
                status = "active" if any(indicators.values()) else "idle"
                self._alive_count += 1

                self._log_event(
                    "liveness_check",
                    status=status,
                    alive_count=self._alive_count,
                    indicators=indicators,
                    elapsed_seconds=elapsed,
                    session_id=self._session_id,
                    trace_id=self._trace_id,
                )
                last_liveness_check = current_time

            # Poll for file changes and emit file events
            changes = self._file_tracker.poll()
            if changes.count > 0:
                # Emit events for new files
                for filepath in changes.added:
                    line_count = self._handler._count_lines(filepath)
                    self._emitter.file_event(filepath, "new", line_count)

                # Emit events for modified files
                for filepath in changes.modified:
                    line_count = self._handler._count_lines(filepath)
                    self._emitter.file_event(filepath, "modified", line_count)

            # Wait for next interval (or until stop event)
            self._stop_event.wait(self._interval)

    def _get_file_count(self) -> int:
        """Get current count of changed files.

        Returns:
            Number of files changed since execution started
        """
        return self._handler._count_file_changes()

    def _get_liveness_indicators(self) -> dict[str, bool]:
        """Get liveness indicators showing agent activity.

        Returns a dict with boolean indicators for:
        - files: Files being modified in workspace
        - log: Log files being written to
        - proc: Process is running
        - cpu: CPU activity (requires psutil, graceful degradation)
        - db: Database updates (placeholder for future implementation)

        Returns:
            Dict mapping indicator names to boolean active status
        """
        indicators = {
            "files": False,
            "log": False,
            "proc": True,  # If we're in heartbeat loop, process is running
            "cpu": False,  # Requires psutil, graceful degradation
            "db": False,  # Placeholder - would need StateManager integration
        }

        # Check if files have been modified
        file_count = self._get_file_count()
        indicators["files"] = file_count > 0

        # Check if log files have been written to recently
        # Look for .log or .jsonl files modified in the last interval
        try:
            working_dir = self._handler._working_dir
            current_time = time.time()
            log_activity = False

            # Check common log file patterns
            for pattern in ["*.log", "*.jsonl"]:
                for log_file in working_dir.glob(f"**/{pattern}"):
                    if log_file.is_file():
                        # Check if modified within last interval (+ some buffer)
                        mtime = log_file.stat().st_mtime
                        if current_time - mtime < (self._interval * 2):
                            log_activity = True
                            break
                if log_activity:
                    break

            indicators["log"] = log_activity
        except Exception:
            # If log checking fails, just report False
            pass

        # S3.T2: Check CPU activity via psutil (optional dependency)
        try:
            import psutil  # type: ignore[import-untyped]

            # Get CPU usage over a short interval
            # cpu_percent() with interval returns average CPU usage over that period
            # Using 0.1 seconds to avoid blocking the heartbeat thread
            cpu_percent = psutil.cpu_percent(interval=0.1)
            # Consider CPU active if usage is above 5% (low threshold for any activity)
            indicators["cpu"] = cpu_percent > 5.0
        except ImportError:
            # psutil not available - graceful degradation
            pass
        except Exception:
            # Any other error - graceful degradation
            pass

        return indicators

    def stop(self) -> None:
        """Signal the thread to stop and wait for it to exit.

        This method is thread-safe and can be called multiple times.
        """
        self._stop_event.set()
        # Wait for thread to finish using configured timeout
        self.join(timeout=get_timeout("handler", "thread_join_s"))
