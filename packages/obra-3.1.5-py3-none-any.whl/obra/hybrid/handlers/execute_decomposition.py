"""Execute-time adaptive decomposition policy resolution."""

from __future__ import annotations

from dataclasses import dataclass

from obra.config.loaders import (
    get_decomposition_duration_threshold_s,
    get_decomposition_max_attempts,
    get_decomposition_summary_max_chars,
    get_decomposition_warning_threshold_s,
    get_execute_decomposition_stream_idle_timeout_s,
    is_decomposition_enabled,
)
from obra.exceptions import ConfigurationError
from obra.simulation_controls import get_adaptive_decomposition_config_overrides


@dataclass(frozen=True)
class ExecuteDecompositionPolicy:
    """Resolved execute-time decomposition controls."""

    enabled: bool
    warning_threshold_s: int
    duration_threshold_s: int
    execute_stream_idle_s: int
    max_attempts: int
    summary_max_chars: int


def resolve_execute_decomposition_policy() -> ExecuteDecompositionPolicy:
    """Resolve and validate execute-time decomposition controls from config."""
    simulation_overrides = get_adaptive_decomposition_config_overrides()
    policy = ExecuteDecompositionPolicy(
        enabled=is_decomposition_enabled(),
        warning_threshold_s=max(
            0,
            int(
                simulation_overrides.get(
                    "warning_threshold_s",
                    get_decomposition_warning_threshold_s(),
                )
            ),
        ),
        duration_threshold_s=max(
            0,
            int(
                simulation_overrides.get(
                    "duration_threshold_s",
                    get_decomposition_duration_threshold_s(),
                )
            ),
        ),
        execute_stream_idle_s=max(
            0,
            int(
                simulation_overrides.get(
                    "execute_stream_idle_s",
                    get_execute_decomposition_stream_idle_timeout_s(),
                )
            ),
        ),
        max_attempts=max(
            0,
            int(
                simulation_overrides.get(
                    "max_attempts",
                    get_decomposition_max_attempts(),
                )
            ),
        ),
        summary_max_chars=max(
            0,
            int(
                simulation_overrides.get(
                    "summary_max_chars",
                    get_decomposition_summary_max_chars(),
                )
            ),
        ),
    )

    if (
        policy.execute_stream_idle_s > 0
        and policy.duration_threshold_s > 0
        and policy.execute_stream_idle_s < policy.duration_threshold_s
    ):
        raise ConfigurationError(
            "Config orchestration.decomposition.execute_stream_idle_s must be 0 or "
            "greater than or equal to orchestration.decomposition.duration_threshold_s"
        )

    return policy
