"""Client-side derive handler for imported machine plans.

This handler is used for `obra run --plan-file/--plan-id` flows where the user
has already supplied a concrete machine plan. It converts the hierarchical plan
into canonical flat plan items and reports them as the derivation result,
avoiding an unnecessary LLM derive pass before execution.
"""

from __future__ import annotations

import logging
from typing import Any

from obra.api.protocol import DeriveRequest
from obra.schemas.userplan_schema import UserPlan
from obra.workflow.derivation.synthesis import (
    build_execution_plan_items_from_workflow_definition,
)

logger = logging.getLogger(__name__)


class ImportedPlanDeriveHandler:
    """Return a deterministic derivation result from an imported machine plan."""

    def __init__(self, plan_context: dict[str, Any]) -> None:
        self._plan_context = plan_context

    def handle(self, request: DeriveRequest) -> dict[str, Any]:
        """Convert the imported hierarchical plan into flat canonical plan items."""
        plan_items = _resolve_plan_items(
            self._plan_context,
            objective=request.objective,
            userplan_id=request.userplan_id,
            userplan_steps=request.userplan_steps,
        )
        logger.info(
            "Using imported plan for derivation: userplan_id=%s items=%d",
            request.userplan_id,
            len(plan_items),
        )
        return {
            "plan_items": plan_items,
            "raw_response": "Imported machine plan accepted without live derivation.",
            "work_type": self._infer_work_type(request),
        }

    @staticmethod
    def _infer_work_type(request: DeriveRequest) -> str | None:
        project_context = (
            request.project_context
            if isinstance(request.project_context, dict)
            else {}
        )
        value = project_context.get("work_type") or project_context.get("domain")
        return str(value) if value else None


def _resolve_plan_items(
    plan_context: dict[str, Any],
    *,
    objective: str,
    userplan_id: str,
    userplan_steps: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    workflow_definition = (
        plan_context.get("workflow_definition")
        if isinstance(plan_context.get("workflow_definition"), dict)
        else {}
    )
    if workflow_definition:
        workflow_source_artifact = (
            plan_context.get("workflow_source_artifact")
            if isinstance(plan_context.get("workflow_source_artifact"), dict)
            else {}
        )
        return build_execution_plan_items_from_workflow_definition(
            workflow_definition=workflow_definition,
            userplan_id=userplan_id,
            objective=str(plan_context.get("objective") or objective or ""),
            workflow_artifact_id=str(
                plan_context.get("workflow_artifact_id")
                or workflow_source_artifact.get("artifact_id")
                or workflow_definition.get("workflow_id")
                or ""
            ).strip()
            or None,
            userplan_steps=userplan_steps,
        )

    step_ids = [
        str(step.get("id"))
        for step in userplan_steps
        if isinstance(step, dict) and step.get("id")
    ]
    return _flatten_plan_context(
        plan_context,
        userplan_id=userplan_id,
        step_ids=step_ids,
    )


def _flatten_plan_context(
    plan_context: dict[str, Any],
    *,
    userplan_id: str,
    step_ids: list[str],
) -> list[dict[str, Any]]:
    epics = plan_context.get("epics")
    if not isinstance(epics, list) or not epics:
        msg = "Imported plan context must contain a non-empty 'epics' list"
        raise ValueError(msg)

    items: list[dict[str, Any]] = []
    story_index = 0
    default_step_id = step_ids[0] if step_ids else UserPlan.generate_step_id(userplan_id, 1)

    for epic_idx, epic in enumerate(epics, start=1):
        if not isinstance(epic, dict):
            continue
        epic_id = str(epic.get("id") or f"E{epic_idx}")
        epic_title = str(epic.get("title") or f"Epic {epic_idx}")
        epic_desc = str(epic.get("description") or epic_title)
        epic_step_id = default_step_id

        stories = epic.get("stories")
        if isinstance(stories, list) and stories:
            epic_step_id = _resolve_story_step_id(
                story_index=story_index + 1,
                step_ids=step_ids,
                userplan_id=userplan_id,
            )

        items.append(
            {
                "id": epic_id,
                "item_type": "epic",
                "title": epic_title,
                "description": epic_desc,
                "acceptance_criteria": _as_list(epic.get("acceptance_criteria")),
                "dependencies": _as_list(epic.get("dependencies")),
                "parent_id": None,
                "depth": 0,
                "status": str(epic.get("status") or "pending"),
                "source_step_id": str(epic.get("source_step_id") or epic_step_id),
            }
        )

        if not isinstance(stories, list):
            continue
        for story_pos, story in enumerate(stories, start=1):
            if not isinstance(story, dict):
                continue
            story_index += 1
            story_step_id = str(
                story.get("source_step_id")
                or _resolve_story_step_id(
                    story_index=story_index,
                    step_ids=step_ids,
                    userplan_id=userplan_id,
                )
            )
            story_id = str(story.get("id") or f"{epic_id}.S{story_pos}")
            story_title = str(story.get("title") or story.get("desc") or f"Story {story_pos}")
            story_desc = str(story.get("description") or story_title)
            items.append(
                {
                    "id": story_id,
                    "item_type": "story",
                    "title": story_title,
                    "description": story_desc,
                    "acceptance_criteria": _as_list(story.get("acceptance_criteria")),
                    "dependencies": _as_list(story.get("dependencies")),
                    "parent_id": epic_id,
                    "depth": 1,
                    "status": str(story.get("status") or "pending"),
                    "source_step_id": story_step_id,
                }
            )

            tasks = story.get("tasks")
            if not isinstance(tasks, list):
                continue
            for task_pos, task in enumerate(tasks, start=1):
                if not isinstance(task, dict):
                    continue
                task_id = str(task.get("id") or f"{story_id}.T{task_pos}")
                task_title = str(task.get("title") or task.get("desc") or f"Task {task_pos}")
                task_desc = str(task.get("description") or task.get("desc") or task_title)
                task_context = dict(task.get("context", {})) if isinstance(task.get("context"), dict) else {}
                if task.get("execution_mode") and "execution_mode" not in task_context:
                    task_context["execution_mode"] = str(task.get("execution_mode"))
                if task.get("execution_summary") and "execution_summary" not in task_context:
                    task_context["execution_summary"] = str(task.get("execution_summary"))
                items.append(
                    {
                        "id": task_id,
                        "item_type": "task",
                        "title": task_title,
                        "description": task_desc,
                        "acceptance_criteria": _as_list(task.get("acceptance_criteria")),
                        "dependencies": _as_list(task.get("dependencies")),
                        "parent_id": story_id,
                        "depth": 2,
                        "status": str(task.get("status") or "pending"),
                        "source_step_id": str(task.get("source_step_id") or story_step_id),
                        "verification": _as_list(task.get("verify")),
                        "context": task_context,
                    }
                )

    if not items:
        msg = "Imported plan context did not yield any canonical plan items"
        raise ValueError(msg)
    return items


def _resolve_story_step_id(
    *,
    story_index: int,
    step_ids: list[str],
    userplan_id: str,
) -> str:
    if story_index > 0 and story_index <= len(step_ids):
        return str(step_ids[story_index - 1])
    return UserPlan.generate_step_id(userplan_id, story_index if story_index > 0 else 1)


def _as_list(value: Any) -> list[Any]:
    if isinstance(value, list):
        return list(value)
    if isinstance(value, str) and value.strip():
        return [value]
    return []
