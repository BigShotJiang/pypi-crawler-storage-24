"""Business workflow domain module.

This domain provides specialized configuration for business process
automation workflows including document processing, approval workflows,
and compliance reviews.

Usage:
    >>> from obra.domains.business import BusinessDomain
    >>> domain = BusinessDomain()
    >>> print(domain.name)
    business
    >>> work_types = domain.get_work_type_patterns()
    >>> print(len(work_types['work_types']))
    5

Related:
    - obra/domains/interface.py (protocol definition)
    - docs/guides/domains/using-domains.md
"""

import importlib.resources
from functools import lru_cache
from typing import Any

import yaml

from obra.domains.lifecycle import (
    ACTIVE_STATE,
    DERIVE_CAPABILITY,
    DomainDerivationDefaults,
    DomainLifecyclePolicy,
    EXECUTE_CAPABILITY,
    GIT_REQUIRED_CAPABILITY,
    PREFLIGHT_CAPABILITY,
    REVIEW_CAPABILITY,
    SKIPPED_STATE,
    STORY0_CAPABILITY,
    TOOLING_VERIFICATION_CAPABILITY,
    WAIT_RESUME_CAPABILITY,
)
from obra.domains.interface import FileFilterConfig, QualityDimension

from .derivation import SIZING_GUIDANCE, WORK_TYPE_KEYWORDS
from .filters import (
    BINARY_EXTENSIONS,
    EXCLUDED_FILES,
    EXCLUDED_PATTERNS,
    IGNORE_DIR_SUFFIXES,
    IGNORE_DIRS,
)

# Runtime quality keys expected by active review agents.
RUNTIME_QUALITY_PROMPT_TO_FILE: dict[str, str] = {
    "code_quality": "document_quality",
    "docs_analysis": "docs_analysis",
    "testing_coverage": "data_consistency",
    "security_sweep": "process_compliance",
    "security_deep": "security_deep",
}

# Backward-compatible business-native aliases.
LEGACY_QUALITY_ALIASES: dict[str, str] = {
    "document_quality": "code_quality",
    "process_compliance": "security_sweep",
    "data_consistency": "testing_coverage",
}


class BusinessDomain:
    """Domain module for business workflow automation.

    Provides work types, quality prompts, and file filters optimized for
    business process automation tasks.
    """

    @property
    def name(self) -> str:
        """Return domain name."""
        return "business"

    @property
    def display_name(self) -> str:
        """Return human-readable domain name."""
        return "Business Workflows"

    @property
    def description(self) -> str:
        """Return short description for this domain."""
        return "Orchestration for document processing and approval workflows"

    @property
    def example_objectives(self) -> list[str]:
        """Return representative objective examples."""
        return [
            "Process quarterly invoices",
            "Review compliance documents",
            "Generate financial report",
        ]

    @property
    def requires_git(self) -> bool:
        """Return whether this domain requires a git repository."""
        return False

    @property
    def default_sandbox_policy(self) -> str:
        """Return default sandbox policy for this domain."""
        return "WORKSPACE_WRITE"

    @property
    def closeout_key(self) -> str:
        """Return closeout template key for this domain."""
        return self.name

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_work_types(self) -> dict[str, Any]:
        """Load work type patterns from YAML."""
        files = importlib.resources.files("obra.domains.business")
        content = (files / "work_types.yaml").read_text()
        return yaml.safe_load(content)

    def get_work_type_patterns(self) -> dict[str, Any]:
        """Return work type definitions for business workflows.

        Returns:
            Dictionary with work_types list, detection_settings, and fallback
        """
        return self._load_work_types()

    def get_quality_prompts(self) -> dict[str, str]:
        """Return quality assessment prompts for business workflows.

        Returns:
            Dictionary mapping prompt name to prompt content
        """
        return self._load_prompts()

    def get_quality_dimensions(self) -> list[QualityDimension]:
        """Return quality assessment dimensions for business workflows."""
        return [
            QualityDimension(
                id="code_quality",
                display_name="Document Quality",
                description="Review document completeness and execution readiness",
                default_enabled=True,
            ),
            QualityDimension(
                id="security_sweep",
                display_name="Process Compliance",
                description="Validate workflow compliance and policy adherence",
                default_enabled=True,
            ),
            QualityDimension(
                id="testing_coverage",
                display_name="Data Consistency",
                description="Detect conflicting values across business artifacts",
                default_enabled=False,
            ),
            QualityDimension(
                id="docs_analysis",
                display_name="Documentation",
                description="Review business-document clarity and delivery readiness",
                default_enabled=False,
            ),
        ]

    @lru_cache(maxsize=1)  # noqa: B019 - singleton domain, no memory leak concern
    def _load_prompts(self) -> dict[str, str]:
        """Load quality prompts from prompt files."""
        files = importlib.resources.files("obra.domains.business.prompts")
        prompts: dict[str, str] = {}

        # Canonical runtime key set consumed by active quality agents.
        for prompt_key, file_stem in RUNTIME_QUALITY_PROMPT_TO_FILE.items():
            prompts[prompt_key] = (files / f"{file_stem}.txt").read_text()

        # Compatibility aliases for existing business-native keys.
        for legacy_key, canonical_key in LEGACY_QUALITY_ALIASES.items():
            prompts[legacy_key] = prompts[canonical_key]

        return prompts

    def get_file_filters(self) -> FileFilterConfig:
        """Return file exclusion/inclusion patterns for business projects.

        Returns:
            FileFilterConfig with business-specific exclusion rules
        """
        return FileFilterConfig(
            excluded_files=EXCLUDED_FILES,
            excluded_patterns=EXCLUDED_PATTERNS,
            binary_extensions=BINARY_EXTENSIONS,
            ignore_dirs=IGNORE_DIRS,
            ignore_dir_suffixes=IGNORE_DIR_SUFFIXES,
        )

    def get_derivation_keywords(self) -> dict[str, list[str]]:
        """Return keywords for work type detection.

        Returns:
            Dictionary mapping work type ID to list of detection keywords
        """
        return WORK_TYPE_KEYWORDS

    def get_sizing_guidance(self) -> str:
        """Return sizing guidance text for business workflows.

        Returns:
            Markdown-formatted sizing guidance
        """
        return SIZING_GUIDANCE

    def get_lifecycle_policy(self) -> DomainLifecyclePolicy:
        """Return workflow-lifecycle defaults for business workflows."""
        return DomainLifecyclePolicy(
            capability_states={
                DERIVE_CAPABILITY: ACTIVE_STATE,
                EXECUTE_CAPABILITY: ACTIVE_STATE,
                STORY0_CAPABILITY: SKIPPED_STATE,
                PREFLIGHT_CAPABILITY: SKIPPED_STATE,
                REVIEW_CAPABILITY: SKIPPED_STATE,
                WAIT_RESUME_CAPABILITY: ACTIVE_STATE,
                GIT_REQUIRED_CAPABILITY: SKIPPED_STATE,
                TOOLING_VERIFICATION_CAPABILITY: SKIPPED_STATE,
            }
        )

    def get_derivation_defaults(self) -> DomainDerivationDefaults:
        """Return structured derivation defaults for business workflows."""
        return DomainDerivationDefaults(default_work_type="general_business")


def build_code_quality_prompt() -> str:
    """Return business-domain prompt for code-quality review slot."""
    return BusinessDomain().get_quality_prompts()["code_quality"]


def build_testing_coverage_prompt() -> str:
    """Return business-domain prompt for testing-coverage review slot."""
    return BusinessDomain().get_quality_prompts()["testing_coverage"]


def build_docs_analysis_prompt() -> str:
    """Return business-domain prompt for docs-analysis review slot."""
    return BusinessDomain().get_quality_prompts()["docs_analysis"]


def build_security_sweep_prompt() -> str:
    """Return business-domain prompt for fast security/compliance sweep."""
    return BusinessDomain().get_quality_prompts()["security_sweep"]


def build_security_deep_prompt() -> str:
    """Return business-domain prompt for deep security/compliance sweep."""
    return BusinessDomain().get_quality_prompts()["security_deep"]
