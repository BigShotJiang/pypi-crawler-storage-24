"""Prompt resolution helpers for domain-aware quality agents."""

from typing import Any

from obra.domains.loader import load_domain
from obra.prompts.agents import load_prompt


def resolve_quality_prompt(
    domain: Any,
    prompt_name: str,
    *,
    fallback: str | None = None,
) -> str:
    """Resolve a quality prompt through the active domain or fallback loader.

    Args:
        domain: Optional domain module implementing ``get_quality_prompts``.
        prompt_name: Quality prompt key (for example ``code_quality``).
        fallback: Optional prompt text fallback if loader lookup fails.

    Returns:
        Prompt template text.

    Raises:
        KeyError: If domain is provided but prompt_name is not defined.
        FileNotFoundError: If no prompt can be resolved.
    """
    if domain is not None:
        return domain.get_quality_prompts()[prompt_name]

    try:
        return load_domain("software").get_quality_prompts()[prompt_name]
    except KeyError:
        pass

    try:
        return load_prompt(prompt_name)
    except FileNotFoundError:
        if fallback is not None:
            return fallback
        raise


__all__ = ["resolve_quality_prompt"]
