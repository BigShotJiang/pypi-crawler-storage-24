"""Core filter constants shared by review agents.

These defaults represent the baseline software-analysis filters that apply
when no domain-specific override is provided.
"""

from obra.utils.ignore_rules import (
    REPO_LOCAL_IGNORE_DIRS,
    REPO_LOCAL_IGNORE_DIR_SUFFIXES,
)

# Files that should be excluded from most agent analysis.
EXCLUDED_FILES: frozenset[str] = frozenset(
    {
        # Pytest infrastructure
        "conftest.py",
        # Build/packaging
        "setup.py",
        "setup.cfg",
        "pyproject.toml",
        "package-lock.json",
        "pnpm-lock.yaml",
        "yarn.lock",
        "go.sum",
        "Cargo.lock",
        "Gemfile.lock",
        "composer.lock",
        # Noxfile/tox
        "noxfile.py",
        "toxfile.py",
        # Type stubs
        "py.typed",
    }
)

# Patterns for files that should be excluded (checked with fnmatch).
EXCLUDED_PATTERNS: list[str] = [
    # Migration files
    "**/migrations/*.py",
    "**/alembic/versions/*.py",
    "**/migrations/*.sql",
    # Auto-generated
    "**/*_pb2.py",  # protobuf
    "**/*_pb2_grpc.py",
]

# Binary and generated file extensions to exclude from analysis.
BINARY_EXTENSIONS: frozenset[str] = frozenset(
    {
        # Python bytecode/packaging
        ".pyc",
        ".pyo",
        ".pyd",
        ".egg",
        ".whl",
        # Coverage/testing artifacts
        ".coverage",
        # Compiled binaries
        ".exe",
        ".dll",
        ".so",
        ".dylib",
        ".o",
        ".a",
        ".lib",
        # Archives
        ".tar",
        ".gz",
        ".zip",
        ".rar",
        ".7z",
        ".bz2",
        ".xz",
        # Images
        ".png",
        ".jpg",
        ".jpeg",
        ".gif",
        ".ico",
        ".bmp",
        ".svg",
        ".webp",
        # Fonts
        ".ttf",
        ".otf",
        ".woff",
        ".woff2",
        ".eot",
        # Media
        ".mp3",
        ".mp4",
        ".wav",
        ".avi",
        ".mov",
        ".webm",
        # Documents (binary)
        ".pdf",
        ".doc",
        ".docx",
        ".xls",
        ".xlsx",
        ".ppt",
        ".pptx",
        # Database
        ".db",
        ".sqlite",
        ".sqlite3",
        # Lock files (not useful to analyze)
        ".lock",
        # Minified files (not readable)
        ".min.js",
        ".min.css",
        # Build/cache binary files
        ".pack",  # webpack cache files
        ".idx",  # git index files
        ".map",  # source maps (often large, not useful for code review)
    }
)

# Directories to ignore when scanning for files (exact name match).
IGNORE_DIRS: frozenset[str] = REPO_LOCAL_IGNORE_DIRS | frozenset(
    {
        ".gradle",
        ".cargo",
        "bin",
        "obj",
    }
)

# Directory suffixes to ignore (for patterns like *.egg-info).
IGNORE_DIR_SUFFIXES: tuple[str, ...] = REPO_LOCAL_IGNORE_DIR_SUFFIXES

# File size thresholds for reading.
FILE_SIZE_WARN_BYTES: int = 1 * 1024 * 1024  # 1MB - warn but read
MAX_FILE_SIZE_BYTES: int = 10 * 1024 * 1024  # 10MB - hard skip

# Bytes to read for binary detection (check for null bytes).
BINARY_CHECK_BYTES: int = 8192  # 8KB


__all__ = [
    "BINARY_CHECK_BYTES",
    "BINARY_EXTENSIONS",
    "EXCLUDED_FILES",
    "EXCLUDED_PATTERNS",
    "FILE_SIZE_WARN_BYTES",
    "IGNORE_DIRS",
    "IGNORE_DIR_SUFFIXES",
    "MAX_FILE_SIZE_BYTES",
]
