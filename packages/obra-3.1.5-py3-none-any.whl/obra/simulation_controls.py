"""Shared simulation-control helpers for targeted emulator-backed runs."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

OBRA_SIMULATION_CONTROL_FILE_ENV = "OBRA_SIMULATION_CONTROL_FILE"
_FORCED_FAILURE_COUNTS: dict[str, int] = {}


def load_simulation_control() -> dict[str, Any]:
    """Load the active simulation-control payload from the process env."""
    path_value = os.environ.get(OBRA_SIMULATION_CONTROL_FILE_ENV, "").strip()
    if not path_value:
        return {}
    path = Path(path_value).expanduser()
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}
    return payload if isinstance(payload, dict) else {}


def get_escalation_fixer_control(payload: dict[str, Any] | None = None) -> dict[str, Any]:
    """Return normalized escalation-fixer controls when present."""
    control = payload if isinstance(payload, dict) else load_simulation_control()
    simulation = control.get("simulation")
    if not isinstance(simulation, dict):
        return {}
    escalation_fixer = simulation.get("escalation_fixer")
    if not isinstance(escalation_fixer, dict):
        return {}
    return escalation_fixer


def get_escalation_fixer_llm_fixture(
    *,
    prompt_id: str,
    stage: str,
    payload: dict[str, Any] | None = None,
) -> str | None:
    """Return a scripted escalation-fixer response for the current request."""
    control = get_escalation_fixer_control(payload)
    fixture = control.get("llm_fixture")
    if not isinstance(fixture, dict):
        return None

    fixture_prompt_id = str(fixture.get("prompt_id", "escalation.fixer") or "").strip()
    fixture_stage = str(fixture.get("stage", "escalation_fix") or "").strip()
    if fixture_prompt_id != prompt_id or fixture_stage != stage:
        return None

    response = fixture.get("response")
    if isinstance(response, str):
        return response
    if response is None:
        return None
    return json.dumps(response)


def _control_cache_key(payload: dict[str, Any] | None = None) -> str:
    """Return a stable cache key for the active simulation-control payload."""
    if payload is not None:
        return json.dumps(payload, sort_keys=True)
    return os.environ.get(OBRA_SIMULATION_CONTROL_FILE_ENV, "").strip()


def get_adaptive_decomposition_control(
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return normalized adaptive-decomposition simulator controls when present."""
    control = payload if isinstance(payload, dict) else load_simulation_control()
    simulation = control.get("simulation")
    if not isinstance(simulation, dict):
        return {}
    adaptive = simulation.get("adaptive_decomposition")
    if not isinstance(adaptive, dict):
        return {}
    return adaptive


def get_project_context_adaptive_decomposition_control(
    project_context: dict[str, Any] | None,
) -> dict[str, Any]:
    """Return adaptive-decomposition controls persisted into session project_context."""
    context = project_context if isinstance(project_context, dict) else {}
    simulation = context.get("simulation")
    if not isinstance(simulation, dict):
        return {}
    adaptive = simulation.get("adaptive_decomposition")
    if not isinstance(adaptive, dict):
        return {}
    return adaptive


def get_adaptive_decomposition_config_overrides(
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return simulation-only decomposition config overrides for the active run."""
    adaptive = get_adaptive_decomposition_control(payload)
    config = adaptive.get("config")
    return dict(config) if isinstance(config, dict) else {}


def get_adaptive_decomposition_execute_duration_control(
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return execute-duration trigger forcing controls for the active run."""
    adaptive = get_adaptive_decomposition_control(payload)
    control = adaptive.get("execute_duration")
    return dict(control) if isinstance(control, dict) else {}


def get_adaptive_decomposition_review_control(
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return forced review-decomposition controls for the active run."""
    adaptive = get_adaptive_decomposition_control(payload)
    control = adaptive.get("review")
    return dict(control) if isinstance(control, dict) else {}


def get_project_context_adaptive_decomposition_review_control(
    project_context: dict[str, Any] | None,
) -> dict[str, Any]:
    """Return forced review-decomposition controls persisted in project_context."""
    adaptive = get_project_context_adaptive_decomposition_control(project_context)
    control = adaptive.get("review")
    return dict(control) if isinstance(control, dict) else {}


def consume_adaptive_decomposition_execution_failure(
    payload: dict[str, Any] | None = None,
) -> dict[str, Any] | None:
    """Consume one scripted execution failure when configured for the active run."""
    adaptive = get_adaptive_decomposition_control(payload)
    failure = adaptive.get("execution_failure")
    if not isinstance(failure, dict):
        return None

    remaining = int(failure.get("count", 0) or 0)
    if remaining <= 0:
        return None

    cache_key = _control_cache_key(payload)
    consumed = _FORCED_FAILURE_COUNTS.get(cache_key, 0)
    if consumed >= remaining:
        return None

    _FORCED_FAILURE_COUNTS[cache_key] = consumed + 1
    return dict(failure)
