"""Foundational protocol symbols shared across protocol family modules."""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import Any, TypeVar

from obra.workflow.lifecycle import canonicalize_workflow_lifecycle_payload

logger = logging.getLogger(__name__)

E = TypeVar("E", bound=Enum)


def _coerce_string_list(data: Any) -> list[str]:
    """Return a normalized list of non-empty string values."""
    if not isinstance(data, list):
        return []
    return [str(item).strip() for item in data if str(item).strip()]


def _coerce_lifecycle_payload(data: Any) -> dict[str, Any]:
    """Normalize workflow lifecycle payloads to a dictionary shape."""
    if not isinstance(data, dict):
        return {}
    accepted = canonicalize_workflow_lifecycle_payload(data)
    if accepted:
        if any(
            key in data
            for key in (
                "accepted",
                "decisions",
                "legacy_phase_normalization",
                "resume_checkpoints",
            )
        ):
            normalized: dict[str, Any] = {"accepted": accepted}
            for key in (
                "decisions",
                "legacy_phase_normalization",
                "resume_checkpoints",
            ):
                value = data.get(key)
                if isinstance(value, dict) and value:
                    normalized[key] = {
                        str(item_key): item_value
                        for item_key, item_value in value.items()
                        if str(item_key).strip()
                    }
            return normalized
        return accepted
    normalized: dict[str, Any] = {}
    for key in (
        "accepted",
        "decisions",
        "legacy_phase_normalization",
        "resume_checkpoints",
    ):
        value = data.get(key)
        if isinstance(value, dict) and value:
            normalized[key] = value
    return normalized


def _coerce_optional_dict(data: Any) -> dict[str, Any]:
    """Return a shallow-copied dictionary or an empty mapping."""
    return dict(data) if isinstance(data, dict) else {}


def safe_enum_parse(enum_class: type[E], value: str | None, default: E) -> E:
    """Safely parse an enum value with fallback for unknown values."""
    if value is None:
        return default
    try:
        return enum_class(value)
    except ValueError:
        logger.warning(
            "Unknown %s value '%s', using fallback '%s'. "
            "Consider upgrading obra: pip install --upgrade obra",
            enum_class.__name__,
            value,
            default.value,
        )
        return default


class ActionType(str, Enum):
    """Server action types (server instructs client)."""

    DERIVE = "derive"
    INTENT = "intent"
    STORY0 = "story0"
    EXAMINE = "examine"
    REVISE = "revise"
    EXECUTE = "execute"
    REVIEW = "review"
    VALIDATOR = "validator"
    FIX = "fix"
    PIPELINE_STAGE = "pipeline_stage"
    COMPLETE = "complete"
    STORY_PREFLIGHT = "story_preflight"
    ESCALATE = "escalate"
    WAIT = "wait"
    ERROR = "error"
    UNKNOWN = "unknown"


class SessionPhase(str, Enum):
    """Current phase of the orchestration session."""

    DERIVATION = "derivation"
    STORY0 = "story0"
    REFINEMENT = "refinement"
    EXECUTION = "execution"
    REVIEW = "review"
    COMPLETED = "completed"
    UNKNOWN = "unknown"


class SessionStatus(str, Enum):
    """Session status values."""

    ACTIVE = "active"
    COMPLETED = "completed"
    ESCALATED = "escalated"
    ABANDONED = "abandoned"
    EXPIRED = "expired"
    FAILED = "failed"
    UNKNOWN = "unknown"


class Priority(str, Enum):
    """Priority classification for issues."""

    P0 = "P0"
    P1 = "P1"
    P2 = "P2"
    P3 = "P3"


class ExecutionStatus(str, Enum):
    """Status of plan item execution."""

    SUCCESS = "success"
    FAILURE = "failure"
    PARTIAL = "partial"


class QualityPolicyMode(str, Enum):
    """Quality policy mode for session configuration."""

    AUTO = "auto"
    FAST = "fast"
    MEDIUM = "medium"
    HIGH = "high"


class AgentReportStatus(str, Enum):
    """Agent report execution status (server + client values)."""

    PASS = "pass"
    FAIL = "fail"
    WARNING = "warning"
    COMPLETE = "complete"
    TIMEOUT = "timeout"
    ERROR = "error"
    SKIPPED = "skipped"


class FixStatus(str, Enum):
    """Status of a fix attempt."""

    APPLIED = "applied"
    FAILED = "failed"
    SKIPPED = "skipped"
    INCONCLUSIVE = "inconclusive"
    SCOPE_EXCEEDED = "scope_exceeded"


class VerificationOutcome(str, Enum):
    """Per-issue verification outcome."""

    PASSED = "passed"
    FAILED = "failed"
    INCONCLUSIVE = "inconclusive"


class VerificationScope(str, Enum):
    """Verification scope attribution."""

    SCOPED = "scoped"
    UNSCOPED = "unscoped"


class PlanItemType(str, Enum):
    """Type of plan item in derived/revised plans."""

    EPIC = "epic"
    STORY = "story"
    TASK = "task"
    SUBTASK = "subtask"
    MILESTONE = "milestone"


class AgentType(str, Enum):
    """Types of review agents."""

    SECURITY = "security"
    TESTING = "testing"
    DOCS = "docs"
    CODE_QUALITY = "code_quality"
    TEST_EXECUTION = "test_execution"
    SENSE_CHECK = "sense_check"
    CODE_VERIFY = "code_verify"


DEFAULT_REVIEW_AGENTS = [
    agent.value for agent in AgentType if agent != AgentType.CODE_VERIFY
]

DEFAULT_REPORT_REVIEW_AGENT_TYPES = [
    AgentType.SECURITY.value,
    AgentType.TESTING.value,
    AgentType.DOCS.value,
    AgentType.CODE_QUALITY.value,
    AgentType.TEST_EXECUTION.value,
]

BYPASS_MODE_TO_CLI_FLAG: dict[str, str] = {
    "planning_permissive": "--permissive",
    "no_closeout": "--no-closeout",
    "skip_intent": "--skip-intent",
    "review_intent": "--review-intent",
    "scaffolded": "--scaffolded",
    "no_scaffolded": "--no-scaffolded",
    "skip_quality_check": "--skip-quality-check",
    "skip_complexity_check": "--skip-complexity-check",
    "parallel": "--parallel",
    "skip_explore": "--skip-explore",
    "force_explore": "--force-explore",
}


class EscalationReason(str, Enum):
    """Reasons for escalation."""

    BLOCKED = "blocked"
    EXECUTION_FAILURE = "execution_failure"
    MAX_ITERATIONS = "max_iterations"
    MAX_REFINEMENT_ITERATIONS = "max_refinement_iterations"
    OSCILLATION = "oscillation"
    CONVERGENCE_STALLED = "convergence_stalled"
    BLOCKING_ISSUES_UNRESOLVED = "blocking_issues_unresolved"
    PENDING_HUMAN_REVIEW = "pending_human_review"
    QUALITY_THRESHOLD_NOT_MET = "quality_threshold_not_met"
    USER_REQUESTED = "user_requested"
    UNKNOWN = "unknown"


class UserDecisionChoice(str, Enum):
    """User decision options during escalation."""

    FORCE_COMPLETE = "force_complete"
    CONTINUE_FIXING = "continue_fixing"
    SKIP_ISSUES = "skip_issues"
    ABANDON = "abandon"


@dataclass
class ServerAction:
    """Action instruction from server to client."""

    action: ActionType
    session_id: str
    iteration: int = 0
    payload: dict[str, Any] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    bypass_modes_active: list[str] = field(default_factory=list)
    error_code: str | None = None
    error_message: str | None = None
    timestamp: str | None = None
    rationale: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ServerAction":
        """Create from API response dictionary with Pydantic validation."""
        from pydantic import ValidationError

        from obra.api.schemas import ServerActionSchema

        try:
            validated = ServerActionSchema(**data)
            return cls(
                action=safe_enum_parse(
                    ActionType, validated.action, ActionType.UNKNOWN
                ),
                session_id=validated.session_id,
                iteration=validated.iteration,
                payload=validated.payload,
                metadata=validated.metadata,
                bypass_modes_active=validated.bypass_modes_active,
                error_code=validated.error_code,
                error_message=validated.error_message,
                timestamp=validated.timestamp,
                rationale=validated.rationale,
            )
        except ValidationError as exc:
            error_details = "; ".join(
                [f"{err['loc'][0]}: {err['msg']}" for err in exc.errors()]
            )
            raise ValueError(
                f"ServerAction validation failed: {error_details}"
            ) from exc
        except KeyError as exc:
            raise ValueError(f"ServerAction validation failed: {exc!s}") from exc

    def is_error(self) -> bool:
        """Check if this is an error action."""
        return self.action == ActionType.ERROR or self.error_code is not None

    def to_dict(self) -> dict[str, Any]:
        """Convert to API response format."""
        ts = self.timestamp or datetime.now(UTC).isoformat()
        result = {
            "action": self.action.value,
            "session_id": self.session_id,
            "iteration": self.iteration,
            "payload": self.payload,
            "metadata": self.metadata,
            "bypass_modes_active": self.bypass_modes_active,
            "error_code": self.error_code,
            "error_message": self.error_message,
            "timestamp": ts,
        }
        if self.rationale is not None:
            result["rationale"] = self.rationale
        return result


@dataclass
class WorkflowLifecyclePayload:
    """Explicit accepted-workflow lifecycle summary carried across the wire."""

    workflow_id: str = ""
    domain_id: str = ""
    lifecycle_capabilities: list[str] = field(default_factory=list)
    capability_states: dict[str, str] = field(default_factory=dict)
    active_capabilities: list[str] = field(default_factory=list)
    inherited_capabilities: list[str] = field(default_factory=list)
    compatibility_capabilities: list[str] = field(default_factory=list)
    skipped_capabilities: list[str] = field(default_factory=list)
    quality_dimensions: list[str] = field(default_factory=list)
    source_mode: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "workflow_id": self.workflow_id,
            "domain_id": self.domain_id,
            "lifecycle_capabilities": list(self.lifecycle_capabilities),
            "capability_states": dict(self.capability_states),
            "active_capabilities": list(self.active_capabilities),
            "inherited_capabilities": list(self.inherited_capabilities),
            "compatibility_capabilities": list(self.compatibility_capabilities),
            "skipped_capabilities": list(self.skipped_capabilities),
            "quality_dimensions": list(self.quality_dimensions),
            "source_mode": self.source_mode,
        }

    @classmethod
    def from_dict(
        cls, data: dict[str, Any] | None
    ) -> "WorkflowLifecyclePayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        canonical = canonicalize_workflow_lifecycle_payload(data)
        return cls(
            workflow_id=str(canonical.get("workflow_id", "") or ""),
            domain_id=str(canonical.get("domain_id", "") or ""),
            lifecycle_capabilities=_coerce_string_list(
                canonical.get("lifecycle_capabilities")
            ),
            capability_states=(
                {
                    str(key): str(value)
                    for key, value in canonical.get("capability_states", {}).items()
                    if str(key).strip() and str(value).strip()
                }
                if isinstance(canonical.get("capability_states"), dict)
                else {}
            ),
            active_capabilities=_coerce_string_list(
                canonical.get("active_capabilities")
            ),
            inherited_capabilities=_coerce_string_list(
                canonical.get("inherited_capabilities")
            ),
            compatibility_capabilities=_coerce_string_list(
                canonical.get("compatibility_capabilities")
            ),
            skipped_capabilities=_coerce_string_list(
                canonical.get("skipped_capabilities")
            ),
            quality_dimensions=_coerce_string_list(
                canonical.get("quality_dimensions")
            ),
            source_mode=str(canonical.get("source_mode", "") or ""),
        )


@dataclass
class LifecycleDecisionPayload:
    """Explicit lifecycle-routing decisions computed for the current session."""

    selected_path: str = ""
    next_action: str = ""
    resume_target: str = ""
    current_phase: str = ""
    story0_required: bool = False
    review_required: bool = False
    wait_resume_supported: bool = False
    operator_review_required: bool = False
    operator_review_pending: bool = False
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "selected_path": self.selected_path,
            "next_action": self.next_action,
            "resume_target": self.resume_target,
            "current_phase": self.current_phase,
            "story0_required": self.story0_required,
            "review_required": self.review_required,
            "wait_resume_supported": self.wait_resume_supported,
            "operator_review_required": self.operator_review_required,
            "operator_review_pending": self.operator_review_pending,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(
        cls, data: dict[str, Any] | None
    ) -> "LifecycleDecisionPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            selected_path=str(data.get("selected_path", "") or ""),
            next_action=str(
                data.get("next_action") or data.get("selected_next_action") or ""
            ),
            resume_target=str(data.get("resume_target", "") or ""),
            current_phase=str(data.get("current_phase", "") or ""),
            story0_required=bool(data.get("story0_required", False)),
            review_required=bool(data.get("review_required", False)),
            wait_resume_supported=bool(
                data.get("wait_resume_supported", data.get("resume_supported", False))
            ),
            operator_review_required=bool(data.get("operator_review_required", False)),
            operator_review_pending=bool(data.get("operator_review_pending", False)),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
        )


@dataclass
class LegacyPhaseNormalizationPayload:
    """Explicit legacy-phase normalization metadata shared across server and client."""

    source_phase: str = ""
    normalized_phase: str = ""
    resume_phase: str = ""
    compatibility_phase: str = ""
    reason: str = ""
    metadata: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary for API payload."""
        return {
            "source_phase": self.source_phase,
            "normalized_phase": self.normalized_phase,
            "resume_phase": self.resume_phase,
            "compatibility_phase": self.compatibility_phase,
            "reason": self.reason,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any] | None,
    ) -> "LegacyPhaseNormalizationPayload | None":
        """Create from dictionary."""
        if not isinstance(data, dict):
            return None
        return cls(
            source_phase=str(data.get("source_phase", "") or ""),
            normalized_phase=str(data.get("normalized_phase", "") or ""),
            resume_phase=str(data.get("resume_phase", "") or ""),
            compatibility_phase=str(data.get("compatibility_phase", "") or ""),
            reason=str(data.get("reason", "") or ""),
            metadata=(
                data.get("metadata", {})
                if isinstance(data.get("metadata"), dict)
                else {}
            ),
        )


@dataclass
class EscalationEnvelope:
    """Canonical schema for ESCALATE action payloads."""

    reason: EscalationReason
    escalation_id: str = ""
    reason_code: str = ""
    reason_text: str = ""
    blocking_issues: list[dict[str, Any]] = field(default_factory=list)
    escalation_context: dict[str, Any] = field(default_factory=dict)
    convergence_diagnostic: dict[str, Any] | None = None
    invariant_errors: list[dict[str, Any]] | None = None
    repair_attempt_history: list[dict[str, Any]] | None = None
    quality_score: int | None = None
    extra: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.escalation_id:
            self.escalation_id = str(uuid.uuid4())

    def to_payload(self) -> dict[str, Any]:
        """Convert to a flat dict suitable for ServerAction(payload=...)."""
        result: dict[str, Any] = {
            "escalation_id": self.escalation_id,
            "reason": self.reason.value,
            "reason_code": self.reason_code,
            "reason_text": self.reason_text,
            "blocking_issues": self.blocking_issues,
            "escalation_context": self.escalation_context,
        }
        if self.convergence_diagnostic is not None:
            result["convergence_diagnostic"] = self.convergence_diagnostic
        if self.invariant_errors is not None:
            result["invariant_errors"] = self.invariant_errors
        if self.repair_attempt_history is not None:
            result["repair_attempt_history"] = self.repair_attempt_history
        if self.quality_score is not None:
            result["quality_score"] = self.quality_score
        result.update(self.extra)
        return result

    @classmethod
    def from_payload(cls, data: dict[str, Any]) -> "EscalationEnvelope":
        """Reconstruct from a payload dict."""
        known_fields = {
            "escalation_id",
            "reason",
            "reason_code",
            "reason_text",
            "blocking_issues",
            "escalation_context",
            "convergence_diagnostic",
            "invariant_errors",
            "repair_attempt_history",
            "quality_score",
        }
        extra = {k: v for k, v in data.items() if k not in known_fields}
        return cls(
            escalation_id=data.get("escalation_id", ""),
            reason=safe_enum_parse(
                EscalationReason,
                data.get("reason", "blocked"),
                EscalationReason.BLOCKED,
            ),
            reason_code=data.get("reason_code", ""),
            reason_text=data.get("reason_text", ""),
            blocking_issues=data.get("blocking_issues", []),
            escalation_context=data.get("escalation_context", {}),
            convergence_diagnostic=data.get("convergence_diagnostic"),
            invariant_errors=data.get("invariant_errors"),
            repair_attempt_history=data.get("repair_attempt_history"),
            quality_score=data.get("quality_score"),
            extra=extra,
        )


__all__ = [
    "_coerce_lifecycle_payload",
    "_coerce_optional_dict",
    "safe_enum_parse",
    "ActionType",
    "SessionPhase",
    "SessionStatus",
    "Priority",
    "ExecutionStatus",
    "QualityPolicyMode",
    "AgentReportStatus",
    "FixStatus",
    "VerificationOutcome",
    "VerificationScope",
    "PlanItemType",
    "AgentType",
    "DEFAULT_REVIEW_AGENTS",
    "DEFAULT_REPORT_REVIEW_AGENT_TYPES",
    "BYPASS_MODE_TO_CLI_FLAG",
    "EscalationReason",
    "UserDecisionChoice",
    "ServerAction",
    "WorkflowLifecyclePayload",
    "LifecycleDecisionPayload",
    "LegacyPhaseNormalizationPayload",
    "EscalationEnvelope",
]
