"""Status command implementation extracted from obra.cli._main."""

from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

import typer
from rich.table import Table

from obra.api.protocol import EscalationNotice
from obra.cli._shared import (
    _extract_plan_progress,
    _resolve_command_verbosity,
    require_authenticated_client,
    require_terms_accepted,
    setup_logging,
)
from obra.cli.interrupt import _print_bug_hint
from obra.cli.lifecycle import extract_lifecycle_status, format_lifecycle_capability_states
from obra.constants import KIBIBYTE
from obra.display import console, glyphs, handle_encoding_errors, print_info, print_warning
from obra.display.errors import display_error, display_obra_error
from obra.display import EscalationRenderer
from obra.exceptions import APIError, ConfigurationError, ObraError
from obra.utils.numeric import _safe_int

logger = logging.getLogger(__name__)

def _render_status_json(
    session: dict[str, Any],
    resume_context: dict[str, Any],
    *,
    can_resume: bool,
    escalation_reason: str | None,
    workflow_lifecycle: dict[str, Any],
    lifecycle_decisions: dict[str, Any],
    legacy_phase_normalization: dict[str, Any],
    local_runtime: dict[str, Any] | None,
    local_process_stale: bool,
    completed_tasks: int,
    total_tasks: int,
    plan_items: list[dict[str, Any]],
    tasks_error: str | None,
    show_tasks: bool,
) -> None:
    """Render session status as JSON (Tier 1: machine-readable format)."""
    import json

    artifact_summary = session.get("artifact_summary")
    workflow_derivation_summary = session.get("workflow_derivation_summary")
    output: dict[str, Any] = {
        "session_id": session.get("session_id"),
        "objective": session.get("objective"),
        "status": session.get("status"),
        "phase": session.get("current_phase"),
        "iteration": session.get("current_iteration", session.get("iteration", 0)),
        "created_at": session.get("created_at"),
        "updated_at": session.get("updated_at"),
        "project_id": session.get("project_id"),
        "project_name": session.get("project_name"),
        # Session resume/recovery fields
        "can_resume": can_resume,
        "escalation_reason": escalation_reason,
        # Progress fields
        "completed_tasks": completed_tasks,
        "total_tasks": total_tasks,
    }
    if isinstance(artifact_summary, dict) and artifact_summary.get("total_count"):
        output["artifact_summary"] = artifact_summary
    if isinstance(workflow_derivation_summary, dict):
        output["workflow_derivation_summary"] = workflow_derivation_summary
    if workflow_lifecycle:
        output["workflow_lifecycle"] = workflow_lifecycle
    if lifecycle_decisions:
        output["lifecycle_decisions"] = lifecycle_decisions
    if legacy_phase_normalization:
        output["legacy_phase_normalization"] = legacy_phase_normalization
    if local_runtime:
        output["local_runtime"] = local_runtime
        if session.get("status") == "active" and local_process_stale:
            output["status_note"] = (
                "Server reports active, but local runtime process is not alive. "
                "Session was likely interrupted before clean shutdown."
            )
    # Add optional fields if present
    if "quality_scorecard" in session:
        output["quality_scorecard"] = session["quality_scorecard"]
    if "pending_escalation" in session:
        output["pending_escalation"] = session["pending_escalation"]

    # Add prompt file stats (local filesystem info)
    working_dir = Path.cwd()
    prompts_dir = working_dir / ".obra" / "prompts"
    if prompts_dir.exists():
        prompt_files = list(prompts_dir.rglob(".obra-prompt-*.txt"))
        if prompt_files:
            prompt_size_bytes = sum(f.stat().st_size for f in prompt_files)
            output["prompt_files"] = {
                "count": len(prompt_files),
                "size_bytes": prompt_size_bytes,
            }

    # Add plan items detail if --tasks requested
    if show_tasks:
        if tasks_error:
            output["plan_items"] = None
            output["tasks_error"] = tasks_error
        else:
            output["plan_items"] = plan_items

    # Add recovery suggestion for non-resumable sessions
    if not can_resume and session.get("status") in ("escalated", "completed"):
        output["recovery_command"] = (
            f"obra run --continue-from {session.get('session_id', '')[:8]}"
        )

    print(json.dumps(output, indent=2))


def _render_progress_section(
    table: Table,
    session: dict[str, Any],
    *,
    can_resume: bool,
    escalation_reason: str | None,
    lifecycle_status: dict[str, Any],
    lifecycle_states_display: str,
    local_runtime: dict[str, Any] | None,
    local_process_stale: bool,
    completed_tasks: int,
    total_tasks: int,
    tasks_error: str | None,
    verbose: int,
) -> None:
    """Render progress and lifecycle rows into the status table."""
    table.add_row("Session ID", session.get("session_id", "N/A"))
    table.add_row("Objective", session.get("objective", "N/A"))

    # Status with visual indicator
    status = session.get("status", "N/A")
    if status == "active":
        if local_process_stale:
            status_display = f"[yellow]{status}[/yellow] [dim](local process stale)[/dim]"
        else:
            status_display = f"[green]{status}[/green]"
    elif status == "completed":
        status_display = f"[blue]{status}[/blue]"
    elif status == "escalated":
        status_display = f"[yellow]{status}[/yellow]"
    else:
        status_display = f"[dim]{status}[/dim]"
    table.add_row("Status", status_display)
    if local_runtime:
        pid = local_runtime.get("pid", 0)
        if local_runtime.get("process_alive"):
            table.add_row("Local runtime", f"[green]running[/green] (pid={pid})")
        else:
            table.add_row("Local runtime", f"[yellow]stale[/yellow] (pid={pid})")

    table.add_row("Phase", session.get("current_phase", "N/A"))

    # Progress summary
    if total_tasks > 0:
        progress_display = f"{completed_tasks}/{total_tasks} tasks"
        if completed_tasks == total_tasks:
            progress_display = f"[green]{progress_display}[/green]"
        elif completed_tasks > 0:
            progress_display = f"[yellow]{progress_display}[/yellow]"
        table.add_row("Progress", progress_display)
    elif tasks_error:
        table.add_row("Progress", f"[dim]{tasks_error}[/dim]")

    # Resumable status
    if can_resume:
        table.add_row("Resumable", "[green]Yes[/green]")
    else:
        table.add_row("Resumable", "[red]No[/red]")

    # Escalation reason (if present)
    if escalation_reason:
        table.add_row("Failure Reason", f"[yellow]{escalation_reason}[/yellow]")

    table.add_row(
        "Iteration",
        str(session.get("current_iteration", session.get("iteration", 0))),
    )
    if lifecycle_status["selected_path"]:
        table.add_row("Lifecycle Path", str(lifecycle_status["selected_path"]))
    if lifecycle_states_display:
        table.add_row("Lifecycle", lifecycle_states_display)
    if lifecycle_status["resume_target"]:
        table.add_row("Resume Target", str(lifecycle_status["resume_target"]))

    table.add_row("Created", session.get("created_at", "N/A"))
    table.add_row("Updated", session.get("updated_at", "N/A"))

    if verbose > 0:
        table.add_row("Project ID", session.get("project_id", "N/A"))
        if session.get("project_name"):
            table.add_row("Project", session.get("project_name", "N/A"))

    # Prompt file stats (local filesystem info)
    working_dir = Path.cwd()
    prompts_dir = working_dir / ".obra" / "prompts"
    if prompts_dir.exists():
        prompt_files = list(prompts_dir.rglob(".obra-prompt-*.txt"))
        if prompt_files:
            prompt_size_kb = sum(f.stat().st_size for f in prompt_files) / KIBIBYTE
            table.add_row("Prompt files", f"{len(prompt_files)} ({prompt_size_kb:.1f} KB)")


def _render_workflow_derivation_section(
    table: Table,
    session: dict[str, Any],
    *,
    lifecycle_status: dict[str, Any],
) -> None:
    """Render workflow derivation and artifact rows into the status table."""
    artifact_summary = session.get("artifact_summary")
    if isinstance(artifact_summary, dict) and artifact_summary.get("total_count"):
        counts_by_type = artifact_summary.get("counts_by_type", {})
        counts_display = ", ".join(
            f"{artifact_type}={count}"
            for artifact_type, count in sorted(counts_by_type.items())
        )
        table.add_row(
            "Artifacts",
            f"{artifact_summary.get('total_count', 0)} total"
            + (f" ({counts_display})" if counts_display else ""),
        )
        latest_ids = artifact_summary.get("latest_artifact_ids", {})
        if latest_ids:
            latest_display = ", ".join(
                f"{artifact_type}={artifact_id}"
                for artifact_type, artifact_id in sorted(latest_ids.items())
            )
            table.add_row("Latest Artifacts", latest_display)
    workflow_derivation_summary = session.get("workflow_derivation_summary")
    if isinstance(workflow_derivation_summary, dict):
        derived_artifact = workflow_derivation_summary.get("derived_workflow_artifact")
        validation_outcome = workflow_derivation_summary.get("validation_outcome")
        review_count = int(
            workflow_derivation_summary.get("pending_operator_review_count", 0) or 0
        )
        checkpoint_ids = workflow_derivation_summary.get(
            "pending_operator_review_checkpoint_ids", []
        )
        checkpoint_display = ", ".join(
            str(checkpoint_id)
            for checkpoint_id in checkpoint_ids
            if str(checkpoint_id).strip()
        )
        workflow_summary = (
            f"{workflow_derivation_summary.get('domain_id', 'unknown')} "
            f"mission={workflow_derivation_summary.get('mission', '')}"
        ).strip()
        table.add_row("Workflow Derivation", workflow_summary)
        if isinstance(derived_artifact, dict) and derived_artifact.get("artifact_id"):
            table.add_row(
                "Candidate W2",
                str(derived_artifact.get("artifact_id")),
            )
        if validation_outcome:
            table.add_row("W2 Validation", str(validation_outcome))
        if review_count > 0:
            review_display = f"{review_count} pending"
            if checkpoint_display:
                review_display += f" ({checkpoint_display})"
            table.add_row("Operator Review", review_display)
    elif lifecycle_status["operator_review_pending"]:
        table.add_row("Operator Review", "pending")


def _render_next_steps(session: dict[str, Any]) -> None:
    """Render state-based next-steps guidance to the console."""
    state = session.get("state", "").lower()
    session_id_value = session.get("session_id", "")

    console.print()
    console.print("[bold]Next Steps[/bold]", style="cyan")

    if state == "completed":
        console.print(f"  {glyphs.success} This session is complete")
        console.print()
        console.print("  To start new work:")
        console.print('    [cyan]obra run "your task description"[/cyan]')
    elif state in {"paused", "waiting"}:
        progress = session.get("progress", "")
        console.print(f"  {glyphs.paused} Session paused ({progress})")
        console.print()
        console.print("  To resume execution:")
        console.print(f"    [cyan]obra run --resume {session_id_value}[/cyan]")
    elif state in {"failed", "error"}:
        console.print(f"  {glyphs.failure} Session encountered an error")
        console.print()
        console.print("  To view error details:")
        console.print(f"    [cyan]obra status {session_id_value} -vv[/cyan]")
        console.print()
        console.print("  To start a new session:")
        console.print('    [cyan]obra run "your task description"[/cyan]')
    elif state in {"running", "active"}:
        console.print("  Session is currently running")
        console.print()
        console.print("  To monitor progress:")
        console.print(f"    [cyan]obra status {session_id_value}[/cyan]")
    else:
        # Unknown or other states
        console.print("  To resume this session:")
        console.print(f"    [cyan]obra run --resume {session_id_value}[/cyan]")
        console.print()
        console.print("  To check detailed status:")
        console.print(f"    [cyan]obra status {session_id_value} -vv[/cyan]")

    # AI assistant nudge
    console.print()
    console.print("[dim]Using an AI assistant? Run: [/dim][cyan]obra briefing[/cyan]")


def _render_status_rich(
    session: dict[str, Any],
    resume_context: dict[str, Any],
    *,
    can_resume: bool,
    escalation_reason: str | None,
    lifecycle_status: dict[str, Any],
    lifecycle_states_display: str,
    local_runtime: dict[str, Any] | None,
    local_process_stale: bool,
    completed_tasks: int,
    total_tasks: int,
    plan_items: list[dict[str, Any]],
    tasks_error: str | None,
    show_tasks: bool,
    verbose: int,
) -> None:
    """Render session status using Rich tables for terminal display."""
    console.print()
    console.print("[bold]Session Status[/bold]", style="cyan")
    console.print()

    table = Table(show_header=False, box=None)
    table.add_column("Field", style="dim")
    table.add_column("Value")

    # Progress and lifecycle rows
    _render_progress_section(
        table,
        session,
        can_resume=can_resume,
        escalation_reason=escalation_reason,
        lifecycle_status=lifecycle_status,
        lifecycle_states_display=lifecycle_states_display,
        local_runtime=local_runtime,
        local_process_stale=local_process_stale,
        completed_tasks=completed_tasks,
        total_tasks=total_tasks,
        tasks_error=tasks_error,
        verbose=verbose,
    )

    # Workflow derivation rows
    _render_workflow_derivation_section(
        table,
        session,
        lifecycle_status=lifecycle_status,
    )

    console.print(table)

    status = session.get("status", "N/A")
    if status == "active" and local_process_stale:
        console.print()
        print_warning(
            "Session is marked active on server, but local runtime process is no longer running."
        )

    # Show recovery suggestion for non-resumable sessions
    if not can_resume and status in ("escalated", "completed") and total_tasks > 0:
        console.print()
        console.print("[dim]Session cannot be resumed. To continue from checkpoint:[/dim]")
        console.print(f"  obra run --continue-from {session.get('session_id', '')[:8]}")

    # Show task detail table if requested (uses already-fetched plan data)
    if show_tasks:
        if plan_items:
            console.print()
            console.print("[bold]Task Progress[/bold]", style="cyan")
            console.print(f"[dim]{completed_tasks}/{total_tasks} tasks completed[/dim]")
            console.print()

            task_table = Table(show_header=True, header_style="bold")
            task_table.add_column("#", style="dim", width=3)
            task_table.add_column("Status", width=3)
            task_table.add_column("Task")

            for item in plan_items:
                order = str(item.get("order", ""))
                task_status = item.get("status", "pending")
                title = item.get("title", "Untitled task")

                # Status indicator with color
                if task_status == "completed":
                    status_indicator = f"[green]{glyphs.success}[/green]"
                elif task_status == "in_progress":
                    status_indicator = f"[yellow]{glyphs.paused}[/yellow]"
                elif task_status == "failed":
                    status_indicator = f"[red]{glyphs.failure}[/red]"
                else:  # pending
                    status_indicator = "[dim]o[/dim]"

                task_table.add_row(order, status_indicator, title)

            console.print(task_table)
        elif tasks_error:
            console.print()
            console.print(f"[dim]{tasks_error}[/dim]")
        else:
            console.print()
            console.print("[dim]No plan items found for this session[/dim]")

    # Show quality metrics if available
    if verbose > 0 and "quality_scorecard" in session:
        scorecard = session["quality_scorecard"]
        console.print()
        console.print("[bold]Quality Scorecard[/bold]", style="cyan")

        score_table = Table()
        score_table.add_column("Dimension", style="cyan")
        score_table.add_column("Score")

        for dim, score in scorecard.items():
            score_table.add_row(dim, f"{score:.2f}" if isinstance(score, float) else str(score))

        console.print(score_table)

    # Show pending escalation if any
    if session.get("pending_escalation"):
        console.print()
        print_warning("Pending escalation requires your decision")
        notice = EscalationNotice.from_payload(session["pending_escalation"])
        EscalationRenderer(console).render_summary(notice)

    # Next steps
    _render_next_steps(session)


def _is_process_alive(pid: int) -> bool:
    """Return True when a process with this PID is alive."""
    if pid <= 0:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ValueError):
        return False

def _load_local_session_runtime(session_id: str | None) -> dict[str, Any] | None:
    """Load local session runtime heartbeat metadata for a session, if present."""
    if not session_id:
        return None

    short_id = str(session_id).split("-")[0]
    heartbeat_path = Path.home() / ".obra" / "run" / f"session-{short_id}.json"
    if not heartbeat_path.exists():
        return None

    try:
        raw = json.loads(heartbeat_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None

    if not isinstance(raw, dict):
        return None

    pid = _safe_int(raw.get("pid"), default=0)
    return {
        "heartbeat_path": str(heartbeat_path),
        "pid": pid,
        "process_alive": _is_process_alive(pid),
        "last_heartbeat": raw.get("last_heartbeat"),
        "items_completed": _safe_int(raw.get("items_completed"), default=0),
        "items_total": _safe_int(raw.get("items_total"), default=0),
        "current_phase": raw.get("current_phase"),
    }

def status(
    ctx: typer.Context,
    session_id: str | None = typer.Argument(
        None,
        help="Session ID to check (defaults to most recent)",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output as JSON (Tier 1: machine-readable format for LLM operators)",
    ),
    show_tasks: bool = typer.Option(
        False,
        "--tasks",
        "-t",
        help="Show inline task progress from the execution plan",
    ),
) -> None:
    """Check the status of a derivation session.

    Shows the current state of the session including:
    - Session phase (derive, examine, revise, execute, review)
    - Iteration count
    - Quality metrics
    - Any pending user decisions

    Examples:
        $ obra status
        $ obra status abc123
        $ obra status -v
        $ obra status -vv  # More detail
        $ obra status --tasks  # Include task progress
    """
    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    try:
        client = require_authenticated_client()

        # Get session status
        if session_id:
            session = client.get_session(session_id)
        else:
            # Get most recent session
            sessions = client.list_sessions(limit=1)
            if not sessions:
                print_info("No active sessions found")
                console.print("\nRun 'obra run \"objective\"' to start a new session.")
                return
            session = sessions[0]

        # Extract resume context for can_resume status
        resume_context = (
            session.get("resume_context", {})
            if isinstance(session.get("resume_context"), dict)
            else {}
        )
        can_resume = resume_context.get("can_resume", False)
        workflow_lifecycle = (
            resume_context.get("workflow_lifecycle")
            if isinstance(resume_context.get("workflow_lifecycle"), dict)
            else {}
        )
        lifecycle_decisions = (
            resume_context.get("lifecycle_decisions")
            if isinstance(resume_context.get("lifecycle_decisions"), dict)
            else {}
        )
        legacy_phase_normalization = (
            resume_context.get("legacy_phase_normalization")
            if isinstance(resume_context.get("legacy_phase_normalization"), dict)
            else {}
        )
        lifecycle_status = extract_lifecycle_status(
            workflow_lifecycle,
            lifecycle_decisions,
        )
        lifecycle_states_display = format_lifecycle_capability_states(
            workflow_lifecycle
        )

        # Extract escalation_reason if present
        escalation_reason = session.get("escalation_reason")

        # Fetch task progress (always, not just with --tasks)
        session_id_for_plan = session.get("session_id", session_id)
        total_tasks = 0
        completed_tasks = 0
        plan_items = []
        tasks_error = None
        local_runtime = _load_local_session_runtime(session.get("session_id"))
        local_process_stale = bool(local_runtime and not local_runtime.get("process_alive"))
        if session_id_for_plan:
            try:
                plan_data = client.get_session_plan(session_id_for_plan)
                plan_items, total_tasks, completed_tasks = _extract_plan_progress(plan_data)
            except APIError:
                tasks_error = "Could not fetch task progress"

        # Dispatch to the appropriate renderer
        if json_output:
            _render_status_json(
                session,
                resume_context,
                can_resume=can_resume,
                escalation_reason=escalation_reason,
                workflow_lifecycle=workflow_lifecycle,
                lifecycle_decisions=lifecycle_decisions,
                legacy_phase_normalization=legacy_phase_normalization,
                local_runtime=local_runtime,
                local_process_stale=local_process_stale,
                completed_tasks=completed_tasks,
                total_tasks=total_tasks,
                plan_items=plan_items,
                tasks_error=tasks_error,
                show_tasks=show_tasks,
            )
            return

        _render_status_rich(
            session,
            resume_context,
            can_resume=can_resume,
            escalation_reason=escalation_reason,
            lifecycle_status=lifecycle_status,
            lifecycle_states_display=lifecycle_states_display,
            local_runtime=local_runtime,
            local_process_stale=local_process_stale,
            completed_tasks=completed_tasks,
            total_tasks=total_tasks,
            plan_items=plan_items,
            tasks_error=tasks_error,
            show_tasks=show_tasks,
            verbose=verbose,
        )

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in status command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in status command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in status command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in status command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e
