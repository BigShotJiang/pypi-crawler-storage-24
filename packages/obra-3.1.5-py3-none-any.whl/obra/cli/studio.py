"""Workflow Studio launch command."""

from __future__ import annotations

import webbrowser

import typer

from obra.cli._setup import setup
from obra.cli.auth import login
from obra.cli.studio_runtime import (
    _gateway_base_url,
    mint_studio_launch_url,
    resolve_or_create_gateway_state,
    save_studio_gateway_state,
    start_studio_gateway,
)
from obra.display import handle_encoding_errors, print_info, print_success, print_warning
from obra.utils.terminal import can_open_browser


def _ensure_setup_and_auth(*, timeout: int, no_browser: bool) -> None:
    from obra.auth import get_current_auth
    from obra.config import is_terms_accepted, needs_reacceptance

    if not is_terms_accepted() or needs_reacceptance():
        print_info("Running `obra setup` before Studio launch.")
        setup(timeout=timeout, no_browser=no_browser)
        return

    if get_current_auth() is None:
        print_info("Running `obra login` before Studio launch.")
        login(timeout=timeout, no_browser=no_browser)


@handle_encoding_errors
def studio(
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open the browser automatically; print the Studio URL instead.",
    ),
    host: str | None = typer.Option(
        None,
        "--host",
        help="Gateway host to launch or reuse (default: from gateway config).",
    ),
    port: int | None = typer.Option(
        None,
        "--port",
        help="Gateway port to launch or reuse (default: from gateway config).",
    ),
    route: str = typer.Option(
        "/studio/",
        "--route",
        help="Studio route to enter after bootstrap (must stay under /studio/*).",
    ),
    timeout: int = typer.Option(
        300,
        "--timeout",
        help="Timeout in seconds for hosted auth/setup preflight.",
    ),
) -> None:
    """Launch or reuse the local Workflow Studio control plane and open Studio."""
    from obra.config.loaders import get_gateway_config

    _ensure_setup_and_auth(timeout=timeout, no_browser=no_browser)

    gateway_config = get_gateway_config()
    launch_host = host or str(gateway_config["host"])
    launch_port = port or int(gateway_config["port"])
    configured_token = str(gateway_config.get("auth_token") or "").strip() or None

    state = resolve_or_create_gateway_state(
        host=launch_host,
        port=launch_port,
        configured_token=configured_token,
    )
    if state is None:
        print_info(f"Starting local Studio gateway on {_gateway_base_url(launch_host, launch_port)}")
        state = start_studio_gateway(
            host=launch_host,
            port=launch_port,
            token=configured_token,
        )
    else:
        save_studio_gateway_state(state)

    launch_url = mint_studio_launch_url(
        base_url=_gateway_base_url(state.host, state.port),
        token=state.token,
        next_path=route,
    )

    if no_browser:
        print_success("Studio is ready.")
        print_info(launch_url)
        return

    if can_open_browser():
        if not webbrowser.open(launch_url):
            print_warning("Automatic browser launch was declined by the platform. Open this URL manually:")
            print_info(launch_url)
            return
        print_success(f"Opened Studio at {launch_url}")
        return

    print_warning("No browser launch capability detected in this environment. Open this URL manually:")
    print_info(launch_url)
