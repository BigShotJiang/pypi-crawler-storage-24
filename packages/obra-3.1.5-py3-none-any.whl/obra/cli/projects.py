"""Projects sub-app for the Obra CLI.

Extracted from obra/cli/_main.py (REFACTOR-CLI-SUBAPPS-001 S1.T1).
Includes context_app nested within projects_app.
"""

import logging
from pathlib import Path

import typer
from rich.table import Table

from obra.cli._shared import require_authenticated_client
from obra.display import (
    console,
    glyphs,
    handle_encoding_errors,
    print_error,
    print_info,
    print_success,
    print_warning,
)
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import APIError
from obra.messages import get_message
from obra.session.working_dir import (
    normalize_wsl_unc_path as _normalize_wsl_unc_path,
)
from obra.utils.git_utils import is_git_repository

logger = logging.getLogger(__name__)

projects_app = typer.Typer(help="Manage projects")

context_app = typer.Typer(help="Manage project context notes")
projects_app.add_typer(context_app, name="context")


@projects_app.command("list")
@handle_encoding_errors
def projects_list(
    include_deleted: bool = typer.Option(
        False,
        "--all",
        help="Include soft-deleted projects",
    ),
) -> None:
    """List projects for the current user."""
    try:
        client = require_authenticated_client()
        result = client.list_projects_with_selection(include_deleted=include_deleted)
        projects = result["projects"]
        default_project_id = result.get("default_project_id")

        console.print()
        if not projects:
            print_info("No projects found")
            return

        console.print(f"[bold]Projects[/bold] ({len(projects)} shown)", style="cyan")
        console.print()

        table = Table()
        table.add_column("Project ID", style="cyan")
        table.add_column("Name")
        table.add_column("Working Dir")
        table.add_column("Updated", style="dim")

        for project in projects:
            project_id = str(project.get("project_id", ""))
            name = project.get("project_name", "") or project.get("name", "")
            working_dir = project.get("working_directory") or ""

            updated_at = project.get("updated_at", "N/A")
            if "T" in str(updated_at):
                from datetime import datetime

                try:
                    dt = datetime.fromisoformat(str(updated_at).replace("Z", "+00:00"))
                    updated_at = dt.strftime("%Y-%m-%d %H:%M")
                except (ValueError, TypeError):
                    pass

            # Show indicator for selected default project
            is_selected = default_project_id and str(default_project_id) == project_id
            display_id = (
                f"{project_id} [green]{glyphs.success}[/green]" if is_selected else project_id
            )

            table.add_row(display_id, name, working_dir, str(updated_at))

        console.print(table)

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects list command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects list command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("create")
@handle_encoding_errors
def projects_create(
    name: str = typer.Argument(..., help="Project name"),
    working_dir: str | None = typer.Option(
        None,
        "--dir",
        "-d",
        help="Working directory (defaults to current directory). WSL UNC paths are auto-converted.",
    ),
    description: str = typer.Option("", "--description", "-s", help="Project description"),
) -> None:
    """Create a project."""
    try:
        client = require_authenticated_client()

        # Normalize WSL UNC paths before creating Path object
        # This handles Windows paths like \\wsl.localhost\Ubuntu\home\user
        if working_dir is not None:
            normalized_path = _normalize_wsl_unc_path(working_dir)
            resolved_working_dir = Path(normalized_path).expanduser().resolve(strict=False)
        else:
            resolved_working_dir = Path.cwd().resolve(strict=False)

        # Warn if not in a git repository
        if not is_git_repository(resolved_working_dir):
            console.print(
                "\n[yellow]⚠ Warning: Project directory is not in a git repository[/yellow]\n"
                "Git repositories are required for Obra to track changes and create commits.\n"
                "\nTo initialize git:\n"
                "  [cyan]git init[/cyan]\n"
                "\nOr use auto-init when running Obra:\n"
                '  [cyan]obra run --auto-init-git "your objective"[/cyan]\n'
                "\nOr configure in your project:\n"
                "  [cyan]~/.obra/config-layers/01-user.yaml[/cyan] → [dim]llm.git.auto_init: true[/dim]\n"
            )

        result = client.create_project(
            name=name,
            working_dir=str(resolved_working_dir),
            description=description,
        )

        project_id = result.get("project_id")
        resolved_project_id = str(project_id) if project_id is not None else None
        print_success(f"Project created: {resolved_project_id} (dir: {resolved_working_dir})")
        if resolved_project_id:
            try:
                client.select_project(resolved_project_id)
                print_success(f"Default project set to {resolved_project_id}")
            except APIError as e:
                display_obra_error(e, console)
                print_warning(
                    "Project created, but failed to set it as default. "
                    "Run `obra projects select <id>` to set it manually."
                )
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects create command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects create command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("show")
@handle_encoding_errors
def projects_show(
    project_id: str = typer.Argument(..., help="Project ID"),
) -> None:
    """Show project details."""
    try:
        client = require_authenticated_client()
        project = client.get_project(project_id)

        console.print()
        console.print("[bold]Project Details[/bold]", style="cyan")
        console.print()

        table = Table(show_header=False, box=None)
        table.add_column("Field", style="dim")
        table.add_column("Value")

        table.add_row("Project ID", str(project.get("project_id", "")))
        table.add_row("Name", project.get("project_name", project.get("name", "")))
        table.add_row("Working Dir", project.get("working_directory", ""))
        table.add_row("Status", project.get("status", ""))
        table.add_row("Updated", str(project.get("updated_at", "")))

        console.print(table)
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects show command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects show command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("select")
@handle_encoding_errors
def projects_select(
    project_id: str = typer.Argument(..., help="Project ID"),
) -> None:
    """Set default project."""
    try:
        client = require_authenticated_client()
        client.select_project(project_id)
        print_success(f"Default project set to {project_id}")
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects select command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects select command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("update")
@handle_encoding_errors
def projects_update(
    project_id: str = typer.Argument(..., help="Project ID"),
    name: str | None = typer.Option(None, "--name", help="New project name"),
    working_dir: str | None = typer.Option(
        None, "--dir", help="New working directory. WSL UNC paths are auto-converted."
    ),
) -> None:
    """Update project name or working directory."""
    try:
        if name is None and working_dir is None:
            print_error("No updates provided (use --name and/or --dir)")
            raise typer.Exit(2)

        client = require_authenticated_client()

        # Normalize WSL UNC paths before creating Path object
        resolved_working_dir = None
        if working_dir:
            normalized_path = _normalize_wsl_unc_path(working_dir)
            resolved_working_dir = Path(normalized_path).expanduser().resolve(strict=False)
        project = client.update_project(
            project_id=project_id,
            name=name,
            working_dir=str(resolved_working_dir) if resolved_working_dir else None,
        )
        print_success(f"Project updated: {project.get('project_id')}")
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects update command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects update command: {e}")
        raise typer.Exit(1) from e


@projects_app.command("delete")
@handle_encoding_errors
def projects_delete(
    project_id: str = typer.Argument(..., help="Project ID"),
    confirm: bool = typer.Option(
        False,
        "--confirm",
        help="Confirm soft delete",
    ),
) -> None:
    """Soft delete a project."""
    try:
        if not confirm:
            print_error("Refusing to delete without --confirm")
            raise typer.Exit(2)

        client = require_authenticated_client()
        client.delete_project(project_id)
        print_success(f"Project deleted: {project_id}")
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in projects delete command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in projects delete command: {e}")
        raise typer.Exit(1) from e


# =============================================================================
# Project Context Management (FEAT-PROJECT-CONTEXT-001)
# =============================================================================


@context_app.command("show")
@handle_encoding_errors
def context_show() -> None:
    """Display all project context notes."""
    try:
        from obra.project.context import ProjectContextManager

        manager = ProjectContextManager()
        notes = manager.load_notes()
        metadata = manager.get_metadata()

        console.print()
        if not notes:
            print_info("No project context notes found")
            console.print('\nAdd notes with: [cyan]obra project context add "<note>"[/cyan]')
            return

        console.print(f"[bold]Project Context Notes[/bold] ({len(notes)} total)", style="cyan")
        console.print(f"[dim]Last updated: {metadata.updated}[/dim]")
        console.print(f"[dim]Total injections: {metadata.metrics.get('injections_count', 0)}[/dim]")
        console.print()

        table = Table()
        table.add_column("ID", style="cyan", no_wrap=True)
        table.add_column("Note", style="white")
        table.add_column("Added", style="dim")

        for note in notes:
            # Format timestamp for display
            try:
                from datetime import datetime

                dt = datetime.fromisoformat(note.added.replace("Z", "+00:00"))
                added_str = dt.strftime("%Y-%m-%d %H:%M")
            except Exception:
                added_str = note.added

            table.add_row(note.id, note.text, added_str)

        console.print(table)
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Error displaying context notes: {e}")
        raise typer.Exit(1) from e


@context_app.command("add")
@handle_encoding_errors
def context_add(
    note: str = typer.Argument(..., help="Context amendment to add to active intent"),
) -> None:
    """Add a context amendment to the active intent.

    Appends additional context or clarifications to the active intent's
    Context Amendments section. Use this to provide additional information
    discovered during derivation or implementation.

    Examples:
        obra context add "also need OAuth 2.0 support"
        obra context add "database should be PostgreSQL not MySQL"

    Reference: FEAT-AUTO-INTENT-001 S3.T2
    """
    try:
        from obra.intent import IntentStorage

        # Get the active intent
        working_dir = Path.cwd()
        storage = IntentStorage()
        project_id = storage.get_project_id(working_dir)

        active_intent = storage.load_active(project_id)

        if not active_intent:
            console.print()
            print_error("No active intent found for this project")
            console.print()
            console.print("To create an intent:")
            console.print("  [cyan]obra intent new 'your objective'[/cyan]")
            console.print()
            console.print("Or set an existing intent as active:")
            console.print("  [cyan]obra intent use <intent-id>[/cyan]")
            console.print()
            raise typer.Exit(1)

        # Append the amendment
        active_intent.context_amendments.append(note)

        # Save the updated intent
        storage.save(active_intent)

        console.print()
        print_success(f"Added context amendment to intent: {active_intent.slug}")
        console.print(f"[dim]{note}[/dim]")
        console.print()
        console.print(f"Total amendments: {len(active_intent.context_amendments)}")
        console.print()

    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Error adding context amendment: {e}")
        raise typer.Exit(1) from e


@context_app.command("remove")
@handle_encoding_errors
def context_remove(
    note_id: str = typer.Argument(..., help="Note ID to remove (e.g., note-001)"),
) -> None:
    """Remove a project context note by ID."""
    try:
        from obra.project.context import ProjectContextManager

        manager = ProjectContextManager()

        # Check if note exists
        note = manager.get_note(note_id)
        if not note:
            print_error(f"Note not found: {note_id}")
            console.print("\nRun [cyan]obra project context show[/cyan] to see available notes")
            raise typer.Exit(1)

        # Remove the note
        success = manager.remove_note(note_id)
        if success:
            print_success(f"Removed note {note_id}")
        else:
            print_error(f"Failed to remove note {note_id}")
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Error removing context note: {e}")
        raise typer.Exit(1) from e


@context_app.command("clear")
@handle_encoding_errors
def context_clear(
    yes: bool = typer.Option(
        False,
        "--yes",
        "-y",
        help="Skip confirmation prompt",
    ),
) -> None:
    """Remove all project context notes."""
    try:
        from obra.project.context import ProjectContextManager

        manager = ProjectContextManager()
        notes = manager.load_notes()

        if not notes:
            print_info("No notes to clear")
            return

        # Confirmation prompt
        if not yes:
            console.print()
            console.print(
                f"[yellow]Warning:[/yellow] This will remove [bold]{len(notes)}[/bold] notes"
            )
            console.print()

            response = typer.confirm(get_message("prompt.confirm.clear_notes"))
            if not response:
                print_info("Cancelled")
                return

        # Clear notes
        count = manager.clear_notes()
        print_success(f"Cleared {count} notes")

    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Error clearing context notes: {e}")
        raise typer.Exit(1) from e
