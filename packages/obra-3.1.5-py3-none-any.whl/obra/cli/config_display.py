"""Configuration display helpers for obra.cli.config.

Extracted from config_support.py for separation of concerns.
"""

from __future__ import annotations

import logging

from obra.cli.config_validation import ConfigSchemaIssues
from obra.display import console, glyphs, print_success, print_warning

logger = logging.getLogger(__name__)


def _display_validation_human(
    provider_results: dict,
    config_exists: bool,
    config_path: str,
    warnings: list[str],
    schema_issues: ConfigSchemaIssues | None,
) -> None:
    """Display validation results in human-readable format with colors and icons.

    S4.T3: Display validation with icons and colored output.

    Args:
        provider_results: Provider validation results
        config_exists: Whether config file exists
        config_path: Path to config file
        warnings: List of warning messages
        schema_issues: Optional schema validation issues
    """
    console.print()
    console.print("[bold]Configuration Validation[/bold]", style="cyan")
    console.print()

    # Provider CLI checks
    console.print("[bold]Provider CLIs:[/bold]")
    for _provider_key, result in provider_results.items():
        if result["installed"]:
            icon = f"[green]{glyphs.success}[/green]"
            status_text = f"[green]{result['cli_command']} installed[/green]"
        else:
            icon = f"[red]{glyphs.failure}[/red]"
            status_text = f"[red]{result['cli_command']} not found[/red]"
            if result["install_hint"]:
                status_text += f"\n    [dim]{result['install_hint']}[/dim]"

        console.print(f"  {icon} {result['name']}: {status_text}")

    console.print()

    # Configuration file check
    console.print("[bold]Configuration:[/bold]")
    if config_exists:
        icon = f"[green]{glyphs.success}[/green]"
        status_text = f"[green]Config found at {config_path}[/green]"
    else:
        icon = f"[yellow]{glyphs.warning}[/yellow]"
        status_text = "[yellow]No config file (using defaults)[/yellow]"

    console.print(f"  {icon} {status_text}")
    console.print()

    if warnings:
        console.print("[bold]Schema Warnings:[/bold]")
        for warning in warnings:
            console.print(f"  [yellow]{glyphs.warning}[/yellow] {warning}")
        console.print()

    if schema_issues is not None:
        console.print("[bold]Schema Validation:[/bold]")
        unknown: list[str] = schema_issues.get("unknown_keys") or []
        missing: list[str] = schema_issues.get("missing_sections") or []
        mismatches: list[dict[str, str]] = schema_issues.get("type_mismatches") or []

        if not unknown and not missing and not mismatches:
            console.print(f"  [green]{glyphs.success}[/green] No schema issues found")
        else:
            if unknown:
                preview = ", ".join(unknown[:10])
                suffix = "..." if len(unknown) > 10 else ""
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] Unknown keys: {preview}{suffix}"
                )
            if missing:
                preview = ", ".join(missing[:10])
                suffix = "..." if len(missing) > 10 else ""
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] Missing sections: {preview}{suffix}"
                )
            if mismatches:
                preview = ", ".join(
                    f"{item['path']} ({item['expected']} -> {item['actual']})"
                    for item in mismatches[:5]
                )
                suffix = "..." if len(mismatches) > 5 else ""
                console.print(
                    f"  [yellow]{glyphs.warning}[/yellow] Type mismatches: {preview}{suffix}"
                )
        console.print()

    # Overall status
    all_installed = all(p["installed"] for p in provider_results.values())
    if all_installed and config_exists:
        print_success("All checks passed!")
    elif all_installed:
        print_warning("Providers installed but no config file found (using defaults)")
    else:
        print_warning("Some provider CLIs are not installed")
        console.print(
            "\n[dim]Tip: Install the providers you plan to use with obra run --impl-provider[/dim]"
        )
