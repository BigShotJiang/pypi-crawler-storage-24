"""Configuration validation helpers for obra.cli.config.

Extracted from config_support.py for separation of concerns.
"""

from __future__ import annotations

import json
import logging
from typing import TypedDict

from obra.display import console, glyphs, print_success, print_warning

logger = logging.getLogger(__name__)


class ConfigSchemaIssues(TypedDict, total=False):
    """Schema validation issues used for CLI output."""

    unknown_keys: list[str]
    missing_sections: list[str]
    type_mismatches: list[dict[str, str]]


def _run_config_validation(json_output: bool = False, include_schema: bool = False) -> None:
    """Run configuration validation and display results.

    S4.T2: Validates provider CLIs and configuration settings.

    Args:
        json_output: If True, output JSON instead of human-readable format
        include_schema: If True, include schema validation results
    """
    from obra.cli.config_display import _display_validation_human
    from obra.cli.config_support import _config_schema

    from obra.config import CONFIG_PATH, LLM_PROVIDERS, check_provider_status
    from obra.config.loaders import load_config_with_warnings

    # Check all providers
    provider_results = {}
    for provider_key in LLM_PROVIDERS:
        status = check_provider_status(provider_key)
        provider_results[provider_key] = {
            "name": LLM_PROVIDERS[provider_key].get("name", provider_key),
            "installed": status.installed,
            "cli_command": status.cli_command,
            "install_hint": status.install_hint,
            "docs_url": status.docs_url,
        }

    # Load configuration
    config_data, warnings, config_exists = load_config_with_warnings()
    config_exists = config_exists or bool(config_data)
    schema = _config_schema()
    schema_warnings = _config_schema_version_warnings(config_data, schema)
    if schema and config_data:
        unknown_keys = _config_unknown_keys(config_data, schema)
        if unknown_keys:
            from obra.config.loaders import get_display_limit

            list_max = get_display_limit("list_preview_max_items")
            preview = ", ".join(sorted(unknown_keys)[:list_max])
            suffix = "..." if len(unknown_keys) > list_max else ""
            warnings.append(
                "Unknown config keys in "
                f"{CONFIG_PATH}: {preview}{suffix}. "
                "Hint: remove or check spelling; see `obra config show --json` for valid keys."
            )

    warnings.extend(schema_warnings)

    schema_issues: ConfigSchemaIssues = {}
    if include_schema and schema:
        schema_issues = {
            "unknown_keys": _config_unknown_keys(config_data, schema),
            "missing_sections": (
                _config_schema_missing_sections(config_data, schema) if config_data else []
            ),
            "type_mismatches": [
                {"path": path, "expected": expected, "actual": actual}
                for path, expected, actual in _config_schema_type_mismatches(config_data, schema)
            ],
        }

    # Overall status
    all_installed = all(p["installed"] for p in provider_results.values())

    if json_output:
        # S4.T4: JSON output structure
        output = {
            "status": "valid" if (all_installed and config_exists) else "issues_found",
            "providers": provider_results,
            "configuration": {
                "path": str(CONFIG_PATH),
                "exists": config_exists,
                "keys_present": list(config_data.keys()) if config_data else [],
            },
            "warnings": warnings,
            "schema": {
                "version": str(schema.get("config_version")) if schema else None,
                "config_version": (config_data.get("config_version") if config_data else None),
                "issues": schema_issues if include_schema else {},
            },
        }
        # Use print() for JSON to avoid Rich console word-wrapping
        print(json.dumps(output, indent=2))
    else:
        # S4.T3: Human-readable output with colors and icons
        _display_validation_human(
            provider_results,
            config_exists,
            str(CONFIG_PATH),
            warnings,
            schema_issues if include_schema else None,
        )


def _config_unknown_keys(
    config: dict[str, object],
    schema: dict[str, object],
    prefix: str = "",
) -> list[str]:
    """Return config keys not present in the schema."""
    from obra.cli.config_support import _config_deprecated_paths

    unknown: list[str] = []
    for key, value in config.items():
        path = f"{prefix}.{key}" if prefix else key
        if key not in schema:
            if path in _config_deprecated_paths():
                continue
            unknown.append(path)
            continue
        schema_value = schema.get(key)
        if isinstance(value, dict) and isinstance(schema_value, dict):
            unknown.extend(_config_unknown_keys(value, schema_value, path))
    return unknown


def _config_schema_type_mismatches(
    config: dict[str, object],
    schema: dict[str, object],
    prefix: str = "",
) -> list[tuple[str, str, str]]:
    """Return (path, expected_type, actual_type) for schema mismatches."""
    mismatches: list[tuple[str, str, str]] = []
    for key, value in config.items():
        if key not in schema:
            continue
        path = f"{prefix}.{key}" if prefix else key
        schema_value = schema.get(key)

        if isinstance(schema_value, dict):
            if isinstance(value, dict):
                mismatches.extend(_config_schema_type_mismatches(value, schema_value, path))
            else:
                mismatches.append((path, "object", type(value).__name__))
            continue

        if schema_value is None:
            continue

        if isinstance(schema_value, list):
            if not isinstance(value, list):
                mismatches.append((path, "list", type(value).__name__))
            continue

        if isinstance(schema_value, bool):
            if not isinstance(value, bool):
                mismatches.append((path, "bool", type(value).__name__))
            continue

        if isinstance(schema_value, int):
            if not isinstance(value, int) or isinstance(value, bool):
                mismatches.append((path, "int", type(value).__name__))
            continue

        if isinstance(schema_value, float):
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                mismatches.append((path, "float", type(value).__name__))
            continue

        if isinstance(schema_value, str):
            if not isinstance(value, str):
                mismatches.append((path, "str", type(value).__name__))
            continue

        if not isinstance(value, type(schema_value)):
            mismatches.append((path, type(schema_value).__name__, type(value).__name__))

    return mismatches


def _config_schema_missing_sections(
    config: dict[str, object],
    schema: dict[str, object],
) -> list[str]:
    """Return top-level schema sections missing from config."""
    missing: list[str] = []
    for key, value in schema.items():
        if isinstance(value, dict) and key not in config:
            missing.append(key)
    return missing


def _config_schema_version_warnings(
    config: dict[str, object],
    schema: dict[str, object],
) -> list[str]:
    """Return schema version warnings based on config_version."""
    warnings: list[str] = []
    schema_version = schema.get("config_version")
    if schema_version is None:
        return warnings

    expected = str(schema_version)
    current = config.get("config_version")
    if current is None:
        if config:
            warnings.append(
                f"Config schema version missing. Add config_version: {expected} to your config."
            )
        return warnings

    if str(current) != expected:
        warnings.append(
            f"Config schema version mismatch (config={current}, expected={expected}). "
            "Update your config to the latest schema."
        )

    return warnings
