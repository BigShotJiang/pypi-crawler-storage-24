"""Exception handling for CLI run/derive flows."""

from __future__ import annotations

from typing import Any

from obra.cli.feedback_shared import offer_bug_report


def handle_derive_error(
    cli: Any,
    exc: Exception,
    *,
    progress_emitter: Any | None,
    objective: str | None,
    auto_report: bool,
    orchestrator: Any | None,
) -> None:
    """Handle typed exceptions from the derive session flow and exit.

    Dispatches to the appropriate error display, logging, and exit code
    based on exception type. Always raises ``cli.typer.Exit``.
    """
    if progress_emitter:
        progress_emitter.halt_spinner()

    if isinstance(exc, cli.ConfigurationError):
        cli.display_obra_error(exc, cli.console)
        cli.logger.error("Configuration error in derive command: %s", exc, exc_info=True)
        raise cli.typer.Exit(2) from exc

    if isinstance(exc, cli.ObraConnectionError):
        cli.display_obra_error(exc, cli.console)
        cli._print_session_resume_hints()
        cli.logger.error("Connection error in derive command: %s", exc, exc_info=True)
        raise cli.typer.Exit(3) from exc

    if isinstance(exc, cli.APIError):
        cli.display_obra_error(exc, cli.console)
        cli._print_session_resume_hints()
        cli.logger.error("API error in derive command: %s", exc, exc_info=True)
        offer_bug_report(
            exc,
            context="orchestration",
            command_used="obra derive",
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise cli.typer.Exit(1) from exc

    if isinstance(exc, cli.ObraError):
        cli.display_obra_error(exc, cli.console)
        cli._print_session_resume_hints()
        cli.logger.error("Obra error in derive command: %s", exc, exc_info=True)
        offer_bug_report(
            exc,
            context="orchestration",
            command_used="obra derive",
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
        raise cli.typer.Exit(1) from exc

    # Generic exception
    cli.display_error(exc, cli.console)
    cli._print_session_resume_hints()
    cli.logger.exception("Unexpected error in derive command: %s", exc)
    offer_bug_report(
        exc,
        context="orchestration",
        command_used="obra derive",
        objective=objective,
        auto_report=auto_report,
        orchestrator=orchestrator,
    )
    raise cli.typer.Exit(1) from exc
