"""Session execution flow for CLI run/derive commands."""

from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import typer

from obra.cli.run_support.derive_inputs import (
    _build_review_config_from_cli,
    _detect_input_quality_issues,
    _load_planning_config,
    _show_input_quality_warning,
)
from obra.cli.run_support.launch_context import (
    resolve_continue_from,
    resolve_launch_context,
    resolve_plan_launch_context,
)
from obra.cli.run_support.session_bootstrap import (
    build_session_observability,
    collect_bypass_modes,
    init_session_runtime,
    resolve_effective_runtime,
    try_create_userplan,
)
from obra.cli.run_support.session_closeout import (
    handle_graceful_interrupt,
    render_session_result,
)
from obra.cli.run_support.session_errors import handle_derive_error
from obra.cli.run_support.launch_request import LaunchRequest, validate_launch_request
from obra.cli.run_support.session_display import (
    build_cli_preflight_state,
    build_session_header_context,
    print_llm_preflight,
    print_session_header,
)
from obra.cli.run_support.session_loop import run_session
from obra.config import load_config
from obra.core.interrupts import GracefulInterrupt
from obra.display import console
from obra.feedback.session_logger import start_session_logging, stop_session_logging


def _normalize_objective_preview(objective: str, max_len: int = 160) -> str:
    """Return a single-line objective preview with optional truncation marker."""
    collapsed = re.sub(r"\s+", " ", objective).strip()
    if len(collapsed) <= max_len:
        return collapsed
    trimmed = collapsed[: max_len - 3].rstrip()
    return f"{trimmed}... (truncated)"


def _get_cli_module() -> Any:
    """Lazy-import the CLI run module for sub-modules that still accept ``cli: Any``."""
    import obra.cli.run as _run_module

    return _run_module


def run_derive(
    objective: str | None,
    *,
    working_dir: Path | None = None,
    project_id: str | None = None,
    domain: str | None = None,
    resume_session: str | None = None,
    continue_from: str | None = None,
    resume_from: str | None = None,
    rerun_setup: bool = False,
    plan_id: str | None = None,
    plan_file: Path | None = None,
    model: str | None = None,
    fast_model: str | None = None,
    high_model: str | None = None,
    impl_provider: str | None = None,
    reasoning_level: str | None = None,
    verbose: int = 0,
    stream: bool = False,
    plan_only: bool = False,
    permissive: bool = False,
    defaults_json: bool = False,
    no_closeout: bool = False,
    skip_intent: bool = False,
    review_intent: bool = False,
    enrich: bool = False,
    no_enrich: bool = False,
    isolated: bool | None = None,
    no_isolated: bool | None = None,
    full_review: bool = False,
    skip_review: bool = False,
    review_agents: str | None = None,
    with_security: bool = False,
    with_testing: bool = False,
    with_docs: bool = False,
    with_code_quality: bool = False,
    no_security: bool = False,
    no_testing: bool = False,
    no_docs: bool = False,
    no_code_quality: bool = False,
    review_format: str | None = None,
    review_quiet: bool = False,
    review_summary_only: bool = False,
    fail_on_p1: bool = False,
    fail_on_p2: bool = False,
    review_timeout: int | None = None,
    auto_report: bool = False,
    yes: bool = False,
    mock_credentials: bool = False,
    skip_git_check: bool = False,
    auto_init_git: bool = False,
    skip_quality_check: bool = False,
    skip_complexity_check: bool = False,
    parallel: bool = False,
    skip_tier_check: bool = False,
    from_step: int | None = None,
    cascade: bool = False,
    work_type: str | None = None,
    skip_explore: bool = False,
    force_explore: bool = False,
    plan_mode: str | None = None,
) -> None:
    """Execute the shared run/derive session flow."""
    # Lazy-import the CLI run module for sub-modules that still accept ``cli: Any``.
    cli = _get_cli_module()

    # --- Bootstrap: logging, interrupts, request validation ---
    init_session_runtime(resume_session=resume_session, continue_from=continue_from, verbose=verbose)

    request = LaunchRequest(
        objective=objective,
        working_dir=working_dir,
        project_id=project_id,
        resume_session=resume_session,
        continue_from=continue_from,
        resume_from=resume_from,
        rerun_setup=rerun_setup,
        plan_id=plan_id,
        plan_file=plan_file,
        from_step=from_step,
    )
    validate_launch_request(cli, request)

    # --- Continue-from resolution ---
    continue_resolution = resolve_continue_from(
        continue_from=continue_from,
        objective=objective,
        working_dir=working_dir,
        skip_intent_requested=skip_intent,
    )
    skip_completed_items = continue_resolution.skip_completed_items
    continue_from_objective = continue_resolution.objective
    continue_from_plan_context = continue_resolution.plan_context
    continue_from_session = continue_resolution.session_data
    skip_intent = continue_resolution.skip_intent

    objective_override = (
        objective.strip() if isinstance(objective, str) and objective.strip() else None
    )
    if not objective_override:
        objective = continue_from_objective or objective

    # --- Model/provider resolution ---
    runtime = resolve_effective_runtime(
        model=model,
        fast_model=fast_model,
        high_model=high_model,
        impl_provider=impl_provider,
        reasoning_level=reasoning_level,
        verbose=verbose,
    )
    effective_model = runtime.effective_model
    effective_provider = runtime.effective_provider
    effective_reasoning = runtime.effective_reasoning

    if objective is not None:
        quality_issues = _detect_input_quality_issues(objective)
        if quality_issues:
            _show_input_quality_warning(quality_issues)

    # --- Main session flow ---
    progress_emitter = None
    orchestrator = None
    try:
        from obra.api import APIClient
        from obra.auth import ensure_valid_token
        from obra.config import validate_provider_ready

        client = APIClient.from_config()

        launch_context = resolve_launch_context(
            client=client,
            working_dir=working_dir,
            project_id=project_id,
            resume_session=resume_session,
            continue_from=continue_from,
            continue_from_session=continue_from_session,
            resume_from=resume_from,
            rerun_setup=rerun_setup,
        )
        project_id = launch_context.project_id
        work_dir = launch_context.work_dir
        session_data = launch_context.session_data
        session_project_id = launch_context.session_project_id
        resume_target = launch_context.resume_target
        resolved_resume_session = resume_session
        if resume_session and isinstance(session_data, dict):
            canonical_session_id = str(session_data.get("session_id") or "").strip()
            if canonical_session_id:
                resolved_resume_session = canonical_session_id
                start_session_logging(canonical_session_id)

        review_config = _build_review_config_from_cli(
            full_review=full_review,
            skip_review=skip_review,
            review_agents=review_agents,
            with_security=with_security,
            with_testing=with_testing,
            with_docs=with_docs,
            with_code_quality=with_code_quality,
            no_security=no_security,
            no_testing=no_testing,
            no_docs=no_docs,
            no_code_quality=no_code_quality,
            review_format=review_format,
            review_quiet=review_quiet,
            review_summary_only=review_summary_only,
            fail_on_p1=fail_on_p1,
            fail_on_p2=fail_on_p2,
            review_timeout=review_timeout,
            project_path=work_dir,
        )

        # --- Bypass modes ---
        planning_config = _load_planning_config(work_dir)
        config_permissive = bool(planning_config.get("permissive_mode"))
        if not config_permissive:
            from obra.config.loaders import load_layered_config

            layered_cfg, _, _ = load_layered_config(include_defaults=True)
            config_permissive = bool(layered_cfg.get("review", {}).get("permissive_mode"))

        bypass_modes = collect_bypass_modes(
            permissive=permissive,
            config_permissive=config_permissive,
            no_closeout=no_closeout,
            skip_intent=skip_intent,
            review_intent=review_intent,
            enrich=enrich,
            no_enrich=no_enrich,
            skip_quality_check=skip_quality_check,
            skip_complexity_check=skip_complexity_check,
            parallel=parallel,
            skip_tier_check=skip_tier_check,
            skip_explore=skip_explore,
            force_explore=force_explore,
        )

        # --- Provider validation + auth ---
        from obra.config import DEFAULT_PROVIDER, get_llm_config

        user_llm_config = get_llm_config()
        impl_config = user_llm_config.get("implementation", {})
        display_provider = effective_provider or impl_config.get(
            "provider", DEFAULT_PROVIDER
        )
        validate_provider_ready(display_provider)

        try:
            ensure_valid_token()
        except cli.AuthenticationError as exc:
            cli.display_obra_error(exc, console)
            raise typer.Exit(1) from exc

        # --- Plan launch + userplan creation ---
        plan_launch_context = resolve_plan_launch_context(
            client=client,
            project_id=project_id,
            work_dir=work_dir,
            objective=objective,
            plan_id=plan_id,
            plan_file=plan_file,
            continue_from_plan_context=continue_from_plan_context,
            from_step=from_step,
            cascade=cascade,
            verbose=verbose,
        )
        plan_context = plan_launch_context.plan_context
        effective_plan_id = plan_launch_context.effective_plan_id
        userplan_id = plan_launch_context.userplan_id

        if plan_context is None and objective is not None:
            userplan_id = try_create_userplan(
                objective=objective,
                project_id=project_id,
                userplan_id=userplan_id,
            )

        # --- Session display ---
        objective_preview = _normalize_objective_preview(objective or continue_from_objective or "(resuming)")
        session_header = build_session_header_context(
            cli,
            client=client,
            project_id=project_id,
            objective_preview=objective_preview,
            work_dir=work_dir,
            verbose=verbose,
        )
        preflight_state = build_cli_preflight_state(working_dir=work_dir, verbose=verbose)

        console.print()
        print_session_header(
            cli,
            header=session_header,
            work_dir=work_dir,
            resume_session=resume_session,
            effective_plan_id=effective_plan_id,
        )
        print_llm_preflight(cli, preflight_state)

        # --- Observability + progress ---
        config = load_config()
        obs_setup = build_session_observability(
            config=config,
            verbose=verbose,
            stream=stream,
            parallel=parallel,
            bypass_modes=bypass_modes,
            yes=yes,
            mock_credentials=mock_credentials,
        )
        progress_emitter = obs_setup.progress_emitter
        parallel = obs_setup.parallel
        bypass_modes = obs_setup.bypass_modes

        # --- Run session ---
        orchestrator = None
        try:
            outcome = run_session(
                cli,
                work_dir=work_dir,
                session_data=session_data,
                session_project_id=session_project_id,
                continue_from_session=continue_from_session,
                continue_from_plan_context=continue_from_plan_context,
                progress_emitter=progress_emitter,
                verbose=verbose,
                stream=stream,
                domain=domain,
                effective_provider=effective_provider,
                effective_model=effective_model,
                effective_reasoning=effective_reasoning,
                review_config=review_config,
                bypass_modes=bypass_modes,
                defaults_json=defaults_json,
                obs_config=obs_setup.obs_config,
                skip_git_check=skip_git_check,
                auto_init_git=auto_init_git,
                plan_mode=plan_mode,
                story0_override_config=obs_setup.story0_override_config,
                session_display=preflight_state.session_display,
                plan_context=plan_context,
                resume_session=resolved_resume_session,
                resume_target=resume_target,
                objective=objective,
                plan_only=plan_only,
                project_id=project_id,
                effective_plan_id=effective_plan_id,
                skip_completed_items=skip_completed_items,
                userplan_id=userplan_id,
                from_step=from_step,
                work_type=work_type,
            )
            orchestrator = outcome.orchestrator
            result = outcome.result
            session_id = outcome.session_id
        except GracefulInterrupt:
            handle_graceful_interrupt(
                cli,
                progress_emitter=progress_emitter,
                orchestrator=orchestrator,
                objective=objective or continue_from_objective or "",
                verbose=verbose,
            )

        render_session_result(
            cli,
            result=result,
            progress_emitter=progress_emitter,
            plan_only=plan_only,
            work_dir=work_dir,
            session_id=session_id,
            objective=objective or continue_from_objective or "",
            auto_report=auto_report,
            orchestrator=orchestrator,
            verbose=verbose,
        )

    except typer.Exit:
        raise
    except Exception as exc:
        handle_derive_error(
            cli,
            exc,
            progress_emitter=progress_emitter,
            objective=objective,
            auto_report=auto_report,
            orchestrator=orchestrator,
        )
    finally:
        stop_session_logging()
