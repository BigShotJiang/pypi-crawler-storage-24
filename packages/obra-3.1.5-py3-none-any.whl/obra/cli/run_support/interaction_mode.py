"""CLI interaction-mode resolution for obra run and obra derive.

Owns the single point of truth for whether a CLI invocation should allow
stdin-driven prompts. Runtime handlers should use the resolved mode rather
than probing ambient terminal state (sys.stdin.isatty, is_headless, etc.).

Resolution precedence (highest to lowest):
  1. --interactive CLI flag
  2. --non-interactive CLI flag
  3. OBRA_INTERACTIVE=1 environment variable
  4. Default: headless (no stdin prompts)
"""

from __future__ import annotations

import enum
import os
import sys
from typing import Any


class InteractionMode(enum.Enum):
    """Resolved interaction mode for a CLI invocation."""

    HEADLESS = "headless"
    INTERACTIVE = "interactive"


def resolve_interaction_mode(
    *,
    interactive: bool = False,
    non_interactive: bool = False,
) -> InteractionMode:
    """Resolve the interaction mode from CLI flags and environment.

    Precedence (highest to lowest):
        1. --interactive CLI flag → INTERACTIVE
        2. --non-interactive CLI flag → HEADLESS
        3. OBRA_INTERACTIVE=1 env var → INTERACTIVE
        4. Default → HEADLESS

    Args:
        interactive: True when --interactive was passed.
        non_interactive: True when --non-interactive was passed.

    Returns:
        The resolved InteractionMode.
    """
    # Priority 1: --interactive CLI flag (highest)
    if interactive:
        return InteractionMode.INTERACTIVE

    # Priority 2: --non-interactive CLI flag
    if non_interactive:
        return InteractionMode.HEADLESS

    # Priority 3: OBRA_INTERACTIVE env var
    if os.environ.get("OBRA_INTERACTIVE", "0") == "1":
        return InteractionMode.INTERACTIVE

    # Priority 4: Default is headless
    return InteractionMode.HEADLESS


def is_interactive(mode: InteractionMode) -> bool:
    """Convenience predicate: True when the mode permits stdin prompts."""
    return mode is InteractionMode.INTERACTIVE


# ---------------------------------------------------------------------------
# Thread-local / module-level state for the current invocation
# ---------------------------------------------------------------------------
_current_mode: InteractionMode = InteractionMode.HEADLESS
_mode_explicitly_set = False


def set_current_mode(mode: InteractionMode) -> None:
    """Set the resolved interaction mode for the current CLI invocation."""
    global _current_mode, _mode_explicitly_set  # noqa: PLW0603
    _current_mode = mode
    _mode_explicitly_set = True


def restore_current_mode(mode: InteractionMode, *, explicit: bool) -> None:
    """Restore the prior interaction-mode state after a CLI invocation."""
    global _current_mode, _mode_explicitly_set  # noqa: PLW0603
    _current_mode = mode
    _mode_explicitly_set = explicit


def get_current_mode() -> InteractionMode:
    """Return the resolved interaction mode for the current CLI invocation."""
    if not _mode_explicitly_set:
        return InteractionMode.INTERACTIVE if sys.stdin.isatty() else InteractionMode.HEADLESS
    return _current_mode


def current_mode_is_interactive() -> bool:
    """Convenience: True when the current invocation allows stdin prompts."""
    if not _mode_explicitly_set:
        return sys.stdin.isatty()
    return _current_mode is InteractionMode.INTERACTIVE
