"""Authentication commands for the Obra CLI.

Extracted from obra/cli/_main.py as part of REFACTOR-CLI-SUBAPPS-001.
"""
import logging
from datetime import UTC

import typer
from rich.table import Table

from obra.cli.interrupt import _print_bug_hint
from obra.display import (
    console,
    handle_encoding_errors,
    print_error,
    print_info,
    print_success,
)
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import (
    APIError,
    AuthenticationError,
    ConfigurationError,
    ObraError,
)
from obra.messages import get_message

logger = logging.getLogger(__name__)


@handle_encoding_errors
def login(
    timeout: int = typer.Option(
        300,
        "--timeout",
        "-t",
        help="Timeout in seconds for browser authentication",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Don't open browser, just print URL",
    ),
    device_code: bool = typer.Option(  # noqa: ARG001 - kept for backward compat
        False,
        "--device-code",
        hidden=True,
        help="(Deprecated) Device code flow is now the default.",
    ),
) -> None:
    """Authenticate with Obra.

    Opens your browser to sign in with Google or GitHub.
    After successful authentication, your session is saved locally.

    Examples:
        $ obra login
        $ obra login --no-browser
        $ obra login --timeout 600
    """
    try:
        from obra.auth import login_with_device_code, save_auth

        console.print()
        console.print("[bold]Obra Login[/bold]", style="cyan")
        console.print()

        # Default: device code flow with auto-browser-open. The hosted auth
        # page (obra-205b0.web.app) avoids cross-origin cookie issues that
        # cause signInWithPopup to hang on localhost-served pages.
        if no_browser:
            console.print("Printing authentication URL...")
            result = login_with_device_code(
                timeout=timeout, auto_open_browser=False,
            )
        else:
            console.print("Opening browser for authentication...")
            result = login_with_device_code(
                timeout=timeout, auto_open_browser=True,
            )

        # Save the authentication
        save_auth(result)

        console.print()
        print_success(f"Logged in as: {result.email}")
        if result.display_name:
            console.print(f"Name: {result.display_name}")

        # Display next steps
        console.print()
        console.print("[bold]Next Steps[/bold]", style="cyan")
        console.print()
        console.print("1. [cyan]Validate your environment[/cyan]")
        console.print("   $ obra config --validate")
        console.print()
        console.print("2. [cyan]Explore documentation[/cyan]")
        console.print("   $ obra docs")
        console.print()
        console.print("3. [cyan]Start your first task[/cyan]")
        console.print('   $ obra run "Add user authentication"')
        console.print()
        console.print("4. [cyan]Check session status[/cyan]")
        console.print("   $ obra status")
        console.print()

    except AuthenticationError as e:
        display_obra_error(e, console)
        logger.error(f"Authentication error in login command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in login command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in login command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in login command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in login command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@handle_encoding_errors
def logout() -> None:
    """Log out and clear stored credentials.

    Removes your authentication token from the local config.
    You'll need to run 'obra login' again to use Obra.

    Example:
        $ obra logout
    """
    try:
        from obra.auth import clear_auth, get_current_auth

        auth = get_current_auth()
        if not auth:
            print_info("Not currently logged in")
            return

        email = auth.email
        clear_auth()

        console.print()
        print_success(f"Logged out: {email}")
        console.print(f"\n{get_message('recovery.auth.login')}")

    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in logout command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in logout command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to clear authentication: {e}")
        logger.error(f"File I/O error in logout command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in logout command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e


@handle_encoding_errors
def whoami() -> None:
    """Show current authentication status.

    Displays the currently authenticated user and token status.

    Example:
        $ obra whoami
    """
    try:
        from obra.auth import get_current_auth

        auth = get_current_auth()

        console.print()
        if not auth:
            print_info("Not logged in")
            console.print(f"\n{get_message('recovery.auth.login')}")
            return

        console.print("[bold]Current User[/bold]", style="cyan")
        console.print()

        table = Table(show_header=False, box=None)
        table.add_column("Field", style="dim")
        table.add_column("Value")

        table.add_row("Email", auth.email)
        if auth.display_name:
            table.add_row("Name", auth.display_name)
        table.add_row("Provider", auth.auth_provider)
        table.add_row("User ID", auth.firebase_uid[:16] + "...")

        console.print(table)

        # Check token status
        from obra.config.loaders import load_auth_state

        auth_state = load_auth_state()
        token_expires = auth_state.get("token_expires_at")
        if token_expires:
            from datetime import datetime

            try:
                expires_dt = datetime.fromisoformat(token_expires.replace("Z", "+00:00"))
                now = datetime.now(UTC)
                if expires_dt > now:
                    remaining = expires_dt - now
                    minutes = int(remaining.total_seconds() / 60)
                    console.print(f"\n[dim]Token expires in {minutes} minutes[/dim]")
                else:
                    console.print(
                        "\n[yellow]Token expired - will auto-refresh on next request[/yellow]"
                    )
            except ValueError:
                pass

    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in whoami command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in whoami command: {e}", exc_info=True)
        _print_bug_hint()
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in whoami command: {e}")
        _print_bug_hint()
        raise typer.Exit(1) from e
