"""Feedback triage commands extracted from obra.cli.feedback."""

from __future__ import annotations

import logging

import typer

from obra.display import console, glyphs, handle_encoding_errors, print_error

logger = logging.getLogger(__name__)

triage_app = typer.Typer(
    name="triage",
    help="Evaluate and classify feedback submissions",
    rich_markup_mode="rich",
)

def triage_evaluate(
    feedback_id: str = typer.Option(
        ...,
        "--feedback-id",
        help="Feedback ID to evaluate (e.g., bug-xxx-xxx)",
    ),
    format_output: str = typer.Option(
        "text",
        "--format",
        "-f",
        help="Output format: text, json",
    ),
) -> None:
    """Evaluate a feedback submission through the triage workflow.

    This command runs the feedback through automated triage stages:
    1. Validation (spam detection, quality scoring)
    2. Classification (bug/enhancement/question)
    3. Severity assignment (for bugs: P0/P1/P2/P3)
    4. Routing decision (accept/reject/escalate)

    Examples:
        obra triage evaluate --feedback-id bug-abc-123
        obra triage evaluate --feedback-id bug-abc-123 --format json
    """
    import json

    from obra.workflow.feedback_triage import FeedbackTriageWorkflow

    try:
        # For now, we'll use a mock feedback submission
        # In a future story, this will fetch from Firestore
        # TODO(FEEDBACK-TRIAGE-001 S3): Integrate with StateManager to fetch real feedback
        feedback = {
            "id": feedback_id,
            "type": "bug",
            "description": "Application crashes when clicking the submit button. "
            "Error message: NullPointerException at line 42.",
            "metadata": {
                "version": "2.0.0",
                "environment": "production",
            },
        }

        # Execute triage workflow
        workflow = FeedbackTriageWorkflow()
        decision = workflow.execute(feedback)

        if format_output == "json":
            # JSON output for machine consumption
            output = {
                "feedback_id": feedback_id,
                "decision": decision.decision,
                "confidence": decision.confidence,
                "reasoning": decision.reasoning,
                "severity": decision.severity,
                "human_review_required": decision.human_review_required,
                "destination": decision.destination,
                "metadata": decision.metadata,
            }
            console.print(json.dumps(output, indent=2))
        else:
            # Human-readable output
            console.print()
            console.print("[bold]Feedback Triage Result[/bold]")
            console.print(f"ID: {feedback_id}")
            console.print()

            # Decision
            decision_color = {
                "accept": "green",
                "reject": "red",
                "escalate": "yellow",
            }.get(decision.decision, "white")
            console.print(
                f"Decision: [{decision_color}]{decision.decision.upper()}[/{decision_color}]"
            )
            console.print(f"Confidence: {decision.confidence:.2f}")

            # Severity (for bugs)
            if decision.severity:
                severity_color = {
                    "P0": "red",
                    "P1": "yellow",
                    "P2": "blue",
                    "P3": "cyan",
                }.get(decision.severity, "white")
                console.print(f"Severity: [{severity_color}]{decision.severity}[/{severity_color}]")

            # Human review flag
            if decision.human_review_required:
                console.print(f"[yellow]{glyphs.warning} Human review required[/yellow]")

            # Reasoning
            console.print()
            console.print("[bold]Reasoning:[/bold]")
            console.print(f"  {decision.reasoning}")

            # Destination
            if decision.destination:
                console.print()
                console.print(f"[dim]Destination: {decision.destination}[/dim]")

            console.print()

    except FileNotFoundError as e:
        print_error(f"Configuration error: {e}")
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        print_error(f"Triage evaluation failed: {e}")
        logger.exception("Triage evaluation failed")
        raise typer.Exit(1) from e


triage_evaluate = handle_encoding_errors(triage_evaluate)
triage_app.command("evaluate")(triage_evaluate)
