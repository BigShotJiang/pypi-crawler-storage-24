"""Launch-state helpers for the `obra studio` command."""

from __future__ import annotations

import json
import os
import signal
import subprocess
import sys
import time
from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from pathlib import Path

import requests

from obra.gateway.auth import generate_token
from obra.utils.obra_home import resolve_runtime_dir

_DEFAULT_LAUNCH_TIMEOUT_S = 15.0


@dataclass
class StudioGatewayState:
    """Persisted launcher-owned gateway state."""

    host: str
    port: int
    token: str
    pid: int | None
    started_at: str


def _state_path() -> Path:
    return resolve_runtime_dir().path / "studio" / "gateway_state.json"


def _gateway_log_path() -> Path:
    return resolve_runtime_dir().path / "studio" / "gateway.log"


def _gateway_base_url(host: str, port: int) -> str:
    return f"http://{host}:{port}"


def load_studio_gateway_state() -> StudioGatewayState | None:
    path = _state_path()
    if not path.exists():
        return None
    payload = json.loads(path.read_text(encoding="utf-8"))
    return StudioGatewayState(
        host=str(payload["host"]),
        port=int(payload["port"]),
        token=str(payload["token"]),
        pid=int(payload["pid"]) if payload.get("pid") is not None else None,
        started_at=str(payload["started_at"]),
    )


def save_studio_gateway_state(state: StudioGatewayState) -> None:
    path = _state_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(asdict(state), indent=2, sort_keys=True) + "\n", encoding="utf-8")


def clear_studio_gateway_state() -> None:
    path = _state_path()
    if path.exists():
        path.unlink()


def is_process_running(pid: int | None) -> bool:
    if pid is None or pid <= 0:
        return False
    try:
        os.kill(pid, 0)
    except OSError:
        return False
    return True


def probe_gateway(base_url: str) -> bool:
    try:
        response = requests.get(f"{base_url}/health", timeout=1.5)
    except requests.RequestException:
        return False
    return response.ok


def resolve_or_create_gateway_state(*, host: str, port: int, configured_token: str | None) -> StudioGatewayState | None:
    existing = load_studio_gateway_state()
    if existing and existing.host == host and existing.port == port and is_process_running(existing.pid):
        if probe_gateway(_gateway_base_url(existing.host, existing.port)):
            return existing
        clear_studio_gateway_state()

    if configured_token and probe_gateway(_gateway_base_url(host, port)):
        reused = StudioGatewayState(
            host=host,
            port=port,
            token=configured_token,
            pid=None,
            started_at=datetime.now(UTC).isoformat(),
        )
        save_studio_gateway_state(reused)
        return reused

    return None


def start_studio_gateway(*, host: str, port: int, token: str | None = None, timeout_s: float = _DEFAULT_LAUNCH_TIMEOUT_S) -> StudioGatewayState:
    studio_token = token or generate_token()
    if probe_gateway(_gateway_base_url(host, port)):
        raise RuntimeError(
            f"Gateway already appears to be running on {_gateway_base_url(host, port)}, "
            "but `obra studio` does not have a reusable token for it. Set "
            "`OBRA_GATEWAY_AUTH_TOKEN` or `gateway.auth_token`, or stop the existing "
            "gateway and launch through `obra studio`."
        )

    log_path = _gateway_log_path()
    log_path.parent.mkdir(parents=True, exist_ok=True)
    with log_path.open("ab") as log_handle:
        process = subprocess.Popen(  # noqa: S603
            [
                sys.executable,
                "-m",
                "obra.cli",
                "gateway",
                "start",
                "--host",
                host,
                "--port",
                str(port),
                "--token",
                studio_token,
            ],
            stdout=log_handle,
            stderr=subprocess.STDOUT,
            start_new_session=True,
        )

    deadline = time.monotonic() + timeout_s
    base_url = _gateway_base_url(host, port)
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError(
                f"Studio gateway exited before becoming ready. Check {_gateway_log_path()}."
            )
        if probe_gateway(base_url):
            state = StudioGatewayState(
                host=host,
                port=port,
                token=studio_token,
                pid=process.pid,
                started_at=datetime.now(UTC).isoformat(),
            )
            save_studio_gateway_state(state)
            return state
        time.sleep(0.25)

    try:
        os.killpg(process.pid, signal.SIGTERM)
    except OSError:
        process.terminate()
    raise RuntimeError(f"Timed out waiting for Studio gateway at {base_url} to become ready.")


def mint_studio_launch_url(*, base_url: str, token: str, next_path: str) -> str:
    try:
        response = requests.post(
            f"{base_url}/studio/api/bootstrap-links",
            params={"next": next_path},
            headers={"Authorization": f"Bearer {token}"},
            timeout=5,
        )
    except requests.RequestException as exc:
        raise RuntimeError(f"Failed to mint Studio browser launch URL: {exc}") from exc
    if response.status_code != 200:
        raise RuntimeError(
            f"Gateway rejected Studio browser bootstrap ({response.status_code}): {response.text}"
        )
    payload = response.json()
    launch_url = str(payload.get("launch_url") or "").strip()
    if not launch_url:
        raise RuntimeError("Gateway bootstrap response did not include a Studio launch URL.")
    return launch_url
