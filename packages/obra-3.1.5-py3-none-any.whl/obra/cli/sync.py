"""Sync sub-app for the Obra CLI.

Extracted from obra/cli/_main.py (REFACTOR-CLI-SUBAPPS-001 S1.T3).
"""

import logging
from pathlib import Path
from typing import Any

import typer
import yaml  # type: ignore[import-untyped]

from obra.cli._shared import (
    _extract_plan_progress,
    _resolve_command_verbosity,
    require_authenticated_client,
    require_terms_accepted,
    setup_logging,
)
from obra.display import (
    console,
    glyphs,
    handle_encoding_errors,
    print_error,
    print_info,
    print_success,
)
from obra.display.errors import display_error, display_obra_error
from obra.exceptions import APIError, ConfigurationError, ObraError

logger = logging.getLogger(__name__)

sync_app = typer.Typer(
    name="sync",
    help="Sync session data to local files for observability",
    no_args_is_help=True,
)


@sync_app.command("plan")
@handle_encoding_errors
@require_terms_accepted
def sync_plan(
    ctx: typer.Context,
    session_id: str | None = typer.Argument(
        None,
        help="Session ID to sync (defaults to most recent)",
    ),
    output_dir: Path | None = typer.Option(
        None,
        "--output",
        "-o",
        help="Output directory (defaults to .obra/)",
    ),
    export_format: str = typer.Option(
        "yaml",
        "--format",
        help="Export format: yaml or json",
    ),
    machine_plan: bool = typer.Option(
        False,
        "--machine-plan",
        help="Export as MACHINE_PLAN schema for upload/import workflows",
    ),
    work_id: str | None = typer.Option(
        None,
        "--work-id",
        help="Work ID to use when exporting MACHINE_PLAN",
    ),
    verbose: int = typer.Option(
        0,
        "--verbose",
        "-v",
        count=True,
        max=3,
        help="Verbosity level (0-3, use -v/-vv/-vvv)",
    ),
) -> None:
    """Sync session plan to local YAML file.

    Downloads the execution plan for a session and saves it to
    .obra/plan.yaml for local observability. The YAML file includes:
    - Session metadata (objective, status, progress)
    - Plan items with status (pending, in_progress, completed, failed)
    - Acceptance criteria for each item

    Examples:
        $ obra sync plan
        $ obra sync plan abc123
        $ obra sync plan --output ./my-project/.obra/
    """
    from datetime import UTC, datetime

    verbose = _resolve_command_verbosity(ctx, verbose)
    setup_logging(verbose)

    try:
        client = require_authenticated_client()

        # Resolve session ID
        if session_id:
            target_session_id = session_id
        else:
            # Get most recent session
            sessions = client.list_sessions(limit=1)
            if not sessions:
                print_info("No sessions found")
                console.print("\nRun 'obra run \"objective\"' to start a new session.")
                return
            target_session_id = sessions[0].get("session_id", "")

        console.print()
        console.print("[dim]Fetching plan data...[/dim]")

        # Get session info and plan
        session = client.get_session(target_session_id)
        plan_data = client.get_session_plan(target_session_id)

        # Prepare output structure
        plan_items, total_count, completed_count = _extract_plan_progress(plan_data)

        meta: dict[str, Any] = {
            "synced_at": datetime.now(UTC).isoformat(),
            "session_id": session.get("session_id", target_session_id),
            "objective": session.get("objective", "N/A"),
            "status": session.get("status", "N/A"),
            "phase": session.get("current_phase", "N/A"),
            "iteration": session.get("current_iteration", session.get("iteration", 0)),
        }
        progress: dict[str, Any] = {
            "total": total_count,
            "completed": completed_count,
            "percentage": (round(completed_count / total_count * 100) if total_count > 0 else 0),
        }
        items: list[dict[str, Any]] = []

        # Format plan items
        for item in plan_items:
            formatted_item = {
                "id": item.get("item_id", item.get("id", "")),
                "order": item.get("order", 0),
                "title": item.get("title", "Untitled"),
                "status": item.get("status", "pending"),
            }

            # Add optional fields if present
            if item.get("acceptance_criteria"):
                formatted_item["acceptance_criteria"] = item["acceptance_criteria"]
            if item.get("started_at"):
                formatted_item["started_at"] = item["started_at"]
            if item.get("completed_at"):
                formatted_item["completed_at"] = item["completed_at"]

            items.append(formatted_item)

        export_format = export_format.lower().strip()
        if export_format not in {"yaml", "json"}:
            print_error(f"Unsupported format: {export_format}. Use yaml or json.")
            raise typer.Exit(1)

        if machine_plan:
            from obra.execution.plan_tree import build_machine_plan_export
            plan_export = build_machine_plan_export(
                plan_items=plan_items,
                objective=meta["objective"],
                work_id=work_id,
                session_id=meta["session_id"],
            )
        else:
            plan_export = {
                "_meta": meta,
                "progress": progress,
                "items": items,
            }

        # Determine output path
        obra_dir = output_dir or Path.cwd() / ".obra"

        obra_dir.mkdir(parents=True, exist_ok=True)
        output_filename = "plan.yaml"
        if machine_plan:
            output_filename = "MACHINE_PLAN.yaml"
        if export_format == "json":
            output_filename = output_filename.replace(".yaml", ".json")
        output_path = obra_dir / output_filename

        # Write export file
        with output_path.open("w", encoding="utf-8") as f:
            if export_format == "yaml":
                f.write("# Obra Session Plan\n")
                f.write(f"# Synced: {meta['synced_at']}\n")
                f.write(f"# Session: {meta['session_id'][:8]}...\n")
                f.write("#\n")
                if machine_plan:
                    f.write("# Exported as MACHINE_PLAN\n")
                else:
                    f.write("# Status indicators:\n")
                    f.write("#   pending     - Not yet started\n")
                    f.write("#   in_progress - Currently executing\n")
                    f.write("#   completed   - Successfully finished\n")
                    f.write("#   failed      - Execution failed\n")
                f.write("\n")

                yaml.safe_dump(
                    plan_export,
                    f,
                    default_flow_style=False,
                    sort_keys=False,
                    allow_unicode=True,
                    width=100,
                )
            else:
                import json

                json.dump(plan_export, f, indent=2)

        console.print()
        print_success(f"Plan synced to {output_path}")
        console.print()
        console.print(f"[bold]Session[/bold]: {meta['session_id'][:8]}...")
        console.print(f"[bold]Objective[/bold]: {meta['objective']}")
        console.print(
            f"[bold]Progress[/bold]: {completed_count}/{total_count} items "
            f"({progress['percentage']}%)"
        )

        if verbose > 0:
            console.print()
            console.print("[bold]Items[/bold]:")
            for item in items:
                status = item["status"]
                if status == "completed":
                    status_icon = f"[green]{glyphs.success}[/green]"
                elif status == "in_progress":
                    status_icon = f"[yellow]{glyphs.paused}[/yellow]"
                elif status == "failed":
                    status_icon = f"[red]{glyphs.failure}[/red]"
                else:
                    status_icon = "[dim]o[/dim]"
                console.print(f"  {status_icon} {item['title']}")

    except APIError as e:
        display_obra_error(e, console)
        logger.error(f"API error in sync plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ConfigurationError as e:
        display_obra_error(e, console)
        logger.error(f"Configuration error in sync plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except ObraError as e:
        display_obra_error(e, console)
        logger.error(f"Obra error in sync plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except OSError as e:
        print_error(f"Failed to write plan file: {e}")
        logger.error(f"File I/O error in sync plan command: {e}", exc_info=True)
        raise typer.Exit(1) from e
    except typer.Exit:
        raise
    except Exception as e:
        display_error(e, console)
        logger.exception(f"Unexpected error in sync plan command: {e}")
        raise typer.Exit(1) from e
