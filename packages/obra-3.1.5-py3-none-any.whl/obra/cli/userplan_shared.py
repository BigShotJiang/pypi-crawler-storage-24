"""Shared helpers for UserPlan CLI command modules."""

from __future__ import annotations

from typing import Any

import typer

from obra.display import console, print_error
from obra.messages import get_message


def get_api_client() -> Any:
    """Build an API client from the active CLI configuration."""
    from obra.api import APIClient

    return APIClient.from_config()


def build_json_formatter() -> Any:
    """Create the JSON formatter on demand to keep imports local."""
    from obra.utils.json_output import JsonOutputFormatter

    return JsonOutputFormatter()


def output_json_error(error: str, code: str) -> None:
    """Emit a standardized JSON error payload."""
    formatter = build_json_formatter()
    formatter.output_error(error=error, code=code)


def ensure_authenticated(
    *,
    format_output: str | None = None,
    allow_json_error: bool = False,
) -> None:
    """Require CLI auth before continuing."""
    from obra.auth import ensure_valid_token, get_current_auth

    auth = get_current_auth()
    if auth:
        ensure_valid_token()
        return

    if allow_json_error and format_output == "json":
        output_json_error("Not logged in", "AUTH_REQUIRED")
        raise typer.Exit(1)

    print_error("Not logged in")
    console.print(f"\n{get_message('recovery.auth.login')}")
    raise typer.Exit(1)
