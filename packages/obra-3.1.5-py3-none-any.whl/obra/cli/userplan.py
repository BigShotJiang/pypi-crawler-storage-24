"""UserPlan and Step command cluster for the Obra CLI."""

from __future__ import annotations

from typing import Any

import typer

from obra.cli.userplan_display import display_step_context
from obra.cli.userplan_quality_commands import userplan_clarify, userplan_rederive
from obra.cli.userplan_query_commands import userplan_add, userplan_list, userplan_show
from obra.cli.userplan_step_commands import (
    userplan_step_add,
    userplan_step_context,
    userplan_step_remove,
    userplan_step_update,
    userplan_steps,
)

userplan_app = typer.Typer(
    name="userplan",
    help="Manage UserPlans for derivation workflows",
    rich_markup_mode="rich",
)

step_app = typer.Typer(
    name="step",
    help="Manage individual steps within a UserPlan",
    rich_markup_mode="rich",
)
userplan_app.add_typer(step_app, name="step")

userplan_app.command("add")(userplan_add)
userplan_app.command("list")(userplan_list)
userplan_app.command("show")(userplan_show)
userplan_app.command("steps")(userplan_steps)
userplan_app.command("rederive")(userplan_rederive)
userplan_app.command("clarify")(userplan_clarify)

step_app.command("add")(userplan_step_add)
step_app.command("remove")(userplan_step_remove)
step_app.command("update")(userplan_step_update)
step_app.command("context")(userplan_step_context)


def _display_step_context(context: dict[str, Any], header: str) -> None:
    """Compatibility wrapper for step-context display."""
    display_step_context(context, header)
