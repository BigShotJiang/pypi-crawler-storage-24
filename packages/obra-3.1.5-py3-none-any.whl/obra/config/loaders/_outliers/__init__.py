"""Private config-loader owner package.

This package preserves the historical ``obra.config.loaders._outliers``
compatibility surface while the getter families live in concern-owned modules.
"""

from __future__ import annotations

from importlib import import_module
from typing import Any

from .. import _core, _defaults

_MODULE_EXPORTS = {
    "runtime": [
        "get_api_base_url",
        "get_default_project_override",
        "get_heartbeat_initial_delay",
        "get_heartbeat_interval",
        "get_local_emulator_api_url",
        "get_template_retention_settings",
        "is_local_mode",
    ],
    "timeouts": [
        "get_derive_llm_timeout",
        "get_enrichment_stage_timeout_s",
        "get_fix_llm_suggestion_timeout",
        "get_fix_llm_test_gap_timeout",
        "get_intent_alignment_timeout_s",
        "get_intent_gap_check_timeout_s",
        "get_llm_api_timeout",
        "get_llm_call_timeout",
        "get_llm_timeout",
        "get_story0_llm_schema_timeout",
        "get_timeout",
        "get_user_story_generation_timeout_s",
    ],
    "review": [
        "get_convergence_fresh_fix_enabled",
        "get_convergence_identity_overlap_threshold",
        "get_convergence_max_template_failure_cycles",
        "get_convergence_stale_cycles_for_escalate",
        "get_convergence_stale_cycles_for_fresh_fix",
        "get_escalation_continue_iteration_reset",
        "get_generated_plan_quality_threshold",
        "get_quality_config",
        "get_quality_policy_mode",
        "get_quality_threshold",
        "get_review_blocking_low_priority_strict",
        "get_review_complexity_medium",
        "get_review_complexity_simple",
        "get_review_feedback_config",
        "get_review_flag_weights",
        "get_review_loop_exit_policy_enabled",
        "get_review_loop_exit_policy_max_non_critical_review_cycles",
        "get_review_loop_exit_policy_require_no_new_critical",
        "get_review_loop_exit_policy_require_required_checks_pass",
        "get_review_loop_exit_policy_require_threshold_met",
        "get_review_rating_adjustments",
        "get_review_stabilization_cycle_threshold",
        "get_revision_plan_shrinkage_block_threshold",
        "get_revision_plan_shrinkage_warning_threshold",
    ],
    "derivation": [
        "get_decomposition_failure_threshold",
        "get_derivation_auto_decompose_config",
        "get_derivation_budget_config",
        "get_derivation_exploration_lookback_minutes",
        "get_derivation_serialize_max_concurrent",
        "get_derivation_stall_threshold",
        "get_derivation_step1_tier",
        "get_derivation_step2_tier",
        "get_derivation_step3_tier",
        "get_derivation_step_tier",
        "get_derivation_step_timeout",
        "get_derivation_task_config",
        "get_refinement_parallel_max_workers",
        "get_refinement_regression_min_delta",
        "get_refinement_regression_threshold_multiplier",
        "get_refinement_straggler_alert_threshold",
        "is_decomposition_enabled",
    ],
    "verification": [
        "get_code_verify_config",
        "get_code_verify_preflight_config",
        "get_code_verify_timeout_s",
        "get_verification_discovery_settings",
        "get_verification_tool_installs",
        "get_verification_tools_config",
    ],
    "story0": [
        "get_escalation_fixer_allowed_routes",
        "get_escalation_fixer_config",
        "get_escalation_fixer_eligible_reason_codes",
        "get_escalation_fixer_enabled",
        "get_escalation_fixer_max_attempts_per_episode",
        "get_escalation_fixer_timeout_s",
        "get_execute_zero_output_retry_max",
        "get_story0_capability_checks",
        "get_story0_port_mapping",
        "get_story0_service_image",
    ],
    "pipeline": [
        "get_pipeline_custom_stages",
        "get_pipeline_max_iterations",
        "get_pipeline_registered_runners",
        "get_pipeline_stage_defaults",
        "get_pipeline_stage_timeout",
    ],
    "workflow": [
        "get_priority_order",
        "get_workflow_derivation_config",
        "get_workflow_derivation_llm_config",
    ],
    "llm": [
        "get_input_budget_on_exceed",
        "get_llm_timeouts",
        "get_ollama_endpoint",
        "get_ollama_timeouts",
        "get_provider_tier_defaults",
        "get_role_tier_defaults",
        "get_slow_llm_call_threshold_ms",
        "get_subprocess_runner_timeouts",
        "get_thinking_config",
        "get_tier_fallbacks",
        "get_timeout_config",
        "get_xhigh_supported_models",
    ],
    "api": [
        "get_api_connection_pool_config",
        "get_api_limits",
        "get_api_retry_delays",
        "get_api_timeouts",
    ],
    "gateway": ["get_gateway_assistant_config", "get_gateway_config"],
    "interactive_guard": [
        "get_interactive_guard_enabled",
        "get_interactive_guard_patterns",
        "get_interactive_guard_retry_max",
        "get_interactive_guard_rollback_codes",
        "get_interactive_guard_rollback_enabled",
    ],
    "governor_config": [
        "get_governor_config",
    ],
    "operations": [
        "get_derivation_serialize_worker_delay_s",
        "get_enrichment_review_max_concurrent",
        "get_hang_confidence",
        "get_hierarchy_limit",
        "get_hybrid_polling_config",
        "get_intent_alignment_max_concurrent",
        "get_limit",
        "get_parallel_worker_delay_s",
        "get_retry_config",
    ],
    "display": [
        "get_cli_force_exit_threshold",
        "get_cli_interrupt_threshold",
        "get_cli_update_check_config",
        "get_display_limit",
        "get_spinner_config",
    ],
    "misc": [
        "get_agent_ignore_patterns",
        "get_intent_chunking_config",
        "get_intent_rate_limit_config",
    ],
}
_NAME_TO_MODULE = {
    name: module_name
    for module_name, names in _MODULE_EXPORTS.items()
    for name in names
}

__all__ = ["_core", "_defaults", *_NAME_TO_MODULE]


def __getattr__(name: str) -> Any:
    if name == "_core":
        return _core
    if name == "_defaults":
        return _defaults
    module_name = _NAME_TO_MODULE.get(name)
    if module_name is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module = import_module(f"{__name__}.{module_name}")
    value = getattr(module, name)
    globals()[name] = value
    return value


def __dir__() -> list[str]:
    return sorted(__all__)
