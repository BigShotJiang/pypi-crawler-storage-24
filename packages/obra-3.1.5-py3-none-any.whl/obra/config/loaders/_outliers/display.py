"""Display and CLI getter owners."""

from __future__ import annotations

import os
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults

__all__ = [
    "get_cli_force_exit_threshold",
    "get_cli_interrupt_threshold",
    "get_cli_update_check_config",
    "get_display_limit",
    "get_spinner_config",
]


def get_cli_update_check_config(config: dict | None = None) -> dict[str, Any]:
    """Get CLI update check configuration.

    Args:
        config: Optional config dict. If None, loads from layered config

    Returns:
        Dict with CLI config keys.
    """
    if config is None:
        config, _, _ = _core.load_layered_config()

    return config.get("cli", {})


def get_display_limit(name: str) -> int:
    """Get display truncation limit by name.

    Resolution order (Rule 22):
    1. OBRA_DISPLAY_LIMIT_{NAME.upper()} environment variable
    2. display.limits.{name} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        name: One of 'title_max_chars', 'description_max_chars', etc.

    Returns:
        The limit value as an integer

    Raises:
        ConfigurationError: If name is not a valid display limit name
        ConfigurationError: If limit is not found in config
    """
    if name not in _defaults._DISPLAY_LIMIT_NAMES:
        valid_names = ", ".join(sorted(_defaults._DISPLAY_LIMIT_NAMES))
        msg = f"Invalid display limit name '{name}'. Valid names: {valid_names}"
        raise ConfigurationError(msg)

    env_name = f"OBRA_DISPLAY_LIMIT_{name.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        display_config = config["display"]
        limits_config = display_config["limits"]
        return int(limits_config[name])
    except (KeyError, TypeError) as exc:
        msg = f"Display limit '{name}' not found in config at display.limits.{name}"
        raise ConfigurationError(msg) from exc


def get_spinner_config(key: str) -> bool | int | float | str:
    """Get spinner configuration value by key.

    Resolution order (Rule 22):
    1. OBRA_SPINNER_{KEY.upper()} environment variable
    2. display.spinner.{key} from config file
    3. Fail fast if not found (no silent fallback)

    Args:
        key: One of the valid spinner config keys.

    Returns:
        The config value.

    Raises:
        ConfigurationError: If key is not valid or not found in config
    """
    if key not in _defaults._SPINNER_CONFIG_KEYS:
        valid_keys = ", ".join(sorted(_defaults._SPINNER_CONFIG_KEYS))
        msg = f"Invalid spinner config key '{key}'. Valid keys: {valid_keys}"
        raise ConfigurationError(msg)

    env_name = f"OBRA_SPINNER_{key.upper()}"
    env_val = os.environ.get(env_name)
    if env_val:
        if key in _defaults._SPINNER_BOOL_KEYS:
            return env_val.lower() in ("true", "1", "yes")
        if key in _defaults._SPINNER_STR_KEYS:
            return env_val
        try:
            if key in _defaults._SPINNER_INT_KEYS:
                return int(env_val)
            return float(env_val)
        except ValueError:
            msg = f"Invalid value '{env_val}' for {env_name}"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        spinner_config = config["display"]["spinner"]
        value = spinner_config[key]
        if key in _defaults._SPINNER_BOOL_KEYS:
            return bool(value)
        if key in _defaults._SPINNER_STR_KEYS:
            return str(value)
        if key in _defaults._SPINNER_INT_KEYS:
            return int(value)
        return float(value)
    except (KeyError, TypeError) as exc:
        msg = f"Spinner config '{key}' not found in config at display.spinner.{key}"
        raise ConfigurationError(msg) from exc


def get_cli_interrupt_threshold() -> int:
    """Get the CLI interrupt threshold for force quit.

    Resolution order (Rule 22):
    1. OBRA_CLI_INTERRUPT_THRESHOLD environment variable
    2. cli.interrupt_threshold from config file
    3. Fail fast if not found (no silent fallback)
    """
    env_val = os.environ.get("OBRA_CLI_INTERRUPT_THRESHOLD")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_CLI_INTERRUPT_THRESHOLD"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        return int(config["cli"]["interrupt_threshold"])
    except (KeyError, TypeError) as exc:
        msg = "cli.interrupt_threshold not found in config"
        raise ConfigurationError(msg) from exc


def get_cli_force_exit_threshold() -> int:
    """Get the CLI force exit threshold.

    Resolution order (Rule 22):
    1. OBRA_CLI_FORCE_EXIT_THRESHOLD environment variable
    2. cli.force_exit_threshold from config file
    3. Fail fast if not found (no silent fallback)
    """
    env_val = os.environ.get("OBRA_CLI_FORCE_EXIT_THRESHOLD")
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            msg = f"Invalid integer value '{env_val}' for OBRA_CLI_FORCE_EXIT_THRESHOLD"
            raise ConfigurationError(msg) from None

    config, _, _ = _core.load_layered_config(include_defaults=True)
    try:
        return int(config["cli"]["force_exit_threshold"])
    except (KeyError, TypeError) as exc:
        msg = "cli.force_exit_threshold not found in config"
        raise ConfigurationError(msg) from exc
