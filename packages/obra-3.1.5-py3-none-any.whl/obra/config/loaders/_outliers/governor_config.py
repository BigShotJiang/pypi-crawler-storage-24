"""Governor configuration getter owner."""

from __future__ import annotations

import logging
import os

from .. import _core

logger = logging.getLogger(__name__)

__all__ = [
    "get_governor_config",
]


def get_governor_config():  # -> GovernorConfig (imported lazily to avoid circular deps)
    """Get the LLM concurrency governor configuration.

    Resolution order:
    1. OBRA_GOVERNOR_ENABLED, OBRA_GOVERNOR_MAX_CONCURRENT, OBRA_GOVERNOR_COOLDOWN_S
       env vars for global settings
    2. orchestration.governor.* from config file
    3. Backward compat: when orchestration.governor absent, construct from
       orchestration.parallel.worker_delay_s / provider_overrides
    4. Hardcoded defaults from GovernorConfig()

    Per-provider env overrides use OBRA_GOVERNOR_COOLDOWN_S_<PROVIDER> (uppercase).

    Returns:
        GovernorConfig populated from the resolution order above.
    """
    from obra.llm.governor import (  # local import avoids circular dependency
        GovernorConfig,
        GovernorTelemetryConfig,
        ProviderGovernorConfig,
    )

    defaults = GovernorConfig()

    # ---- Global env var overrides ----
    enabled = defaults.enabled
    env_enabled = os.environ.get("OBRA_GOVERNOR_ENABLED")
    if env_enabled is not None:
        enabled = env_enabled.lower() not in ("0", "false", "no")

    max_concurrent = defaults.max_concurrent_calls
    env_max = os.environ.get("OBRA_GOVERNOR_MAX_CONCURRENT")
    if env_max is not None:
        try:
            value = int(env_max)
            if value > 0:
                max_concurrent = value
            else:
                logger.warning(
                    "OBRA_GOVERNOR_MAX_CONCURRENT must be > 0 (got %s)", env_max
                )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_GOVERNOR_MAX_CONCURRENT must be an integer (got %s)", env_max
            )

    cooldown_s = defaults.cooldown_s
    env_cooldown = os.environ.get("OBRA_GOVERNOR_COOLDOWN_S")
    if env_cooldown is not None:
        try:
            value = float(env_cooldown)
            if value >= 0:
                cooldown_s = value
            else:
                logger.warning(
                    "OBRA_GOVERNOR_COOLDOWN_S must be >= 0 (got %s)", env_cooldown
                )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_GOVERNOR_COOLDOWN_S must be a number (got %s)", env_cooldown
            )

    acquire_timeout_s = defaults.acquire_timeout_s
    env_timeout = os.environ.get("OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S")
    if env_timeout is not None:
        try:
            value = float(env_timeout)
            if value > 0:
                acquire_timeout_s = value
            else:
                logger.warning(
                    "OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S must be > 0 (got %s)", env_timeout
                )
        except (TypeError, ValueError):
            logger.warning(
                "OBRA_GOVERNOR_ACQUIRE_TIMEOUT_S must be a number (got %s)", env_timeout
            )

    # ---- Load config file ----
    config, _, _ = _core.load_layered_config()
    orch_config = config.get("orchestration", {}) if isinstance(config, dict) else {}
    governor_section = (
        orch_config.get("governor", {}) if isinstance(orch_config, dict) else {}
    )

    if isinstance(governor_section, dict) and governor_section:
        # governor section present — read from it
        if env_enabled is None:
            raw = governor_section.get("enabled")
            if raw is not None:
                enabled = bool(raw)
        if env_max is None:
            raw = governor_section.get("max_concurrent_calls")
            if raw is not None:
                try:
                    v = int(raw)
                    if v > 0:
                        max_concurrent = v
                except (TypeError, ValueError):
                    pass
        if env_cooldown is None:
            raw = governor_section.get("cooldown_s")
            if raw is not None:
                try:
                    v = float(raw)
                    if v >= 0:
                        cooldown_s = v
                except (TypeError, ValueError):
                    pass
        if env_timeout is None:
            raw = governor_section.get("acquire_timeout_s")
            if raw is not None:
                try:
                    v = float(raw)
                    if v > 0:
                        acquire_timeout_s = v
                except (TypeError, ValueError):
                    pass

        # Provider overrides from governor section
        providers = dict(defaults.providers)
        raw_providers = governor_section.get("providers", {})
        if isinstance(raw_providers, dict):
            for pname, pdata in raw_providers.items():
                if not isinstance(pdata, dict):
                    continue
                pmax = None
                pcooldown = None
                raw_pmax = pdata.get("max_concurrent_calls")
                if raw_pmax is not None:
                    try:
                        v = int(raw_pmax)
                        if v > 0:
                            pmax = v
                    except (TypeError, ValueError):
                        pass
                raw_pcooldown = pdata.get("cooldown_s")
                if raw_pcooldown is not None:
                    try:
                        v = float(raw_pcooldown)
                        if v >= 0:
                            pcooldown = v
                    except (TypeError, ValueError):
                        pass
                providers[pname] = ProviderGovernorConfig(
                    max_concurrent_calls=pmax,
                    cooldown_s=pcooldown,
                )

        # Telemetry
        log_wait_times = defaults.telemetry.log_wait_times
        warn_threshold_s = defaults.telemetry.warn_threshold_s
        raw_tel = governor_section.get("telemetry", {})
        if isinstance(raw_tel, dict):
            raw_lwt = raw_tel.get("log_wait_times")
            if raw_lwt is not None:
                log_wait_times = bool(raw_lwt)
            raw_wt = raw_tel.get("warn_threshold_s")
            if raw_wt is not None:
                try:
                    v = float(raw_wt)
                    if v > 0:
                        warn_threshold_s = v
                except (TypeError, ValueError):
                    pass

    else:
        # Backward compat: no governor section — fall back to parallel config
        providers = dict(defaults.providers)
        parallel_config = (
            orch_config.get("parallel", {}) if isinstance(orch_config, dict) else {}
        )
        if isinstance(parallel_config, dict) and parallel_config:
            # Use worker_delay_s as the global cooldown
            raw_delay = parallel_config.get("worker_delay_s")
            if raw_delay is not None and env_cooldown is None:
                try:
                    v = float(raw_delay)
                    if v >= 0:
                        cooldown_s = v
                except (TypeError, ValueError):
                    pass
            # Per-provider overrides become per-provider cooldown
            raw_overrides = parallel_config.get("provider_overrides", {})
            if isinstance(raw_overrides, dict):
                for pname, pdelay in raw_overrides.items():
                    try:
                        v = float(pdelay)
                        if v >= 0:
                            existing = providers.get(pname, ProviderGovernorConfig())
                            providers[pname] = ProviderGovernorConfig(
                                max_concurrent_calls=existing.max_concurrent_calls,
                                cooldown_s=v,
                            )
                    except (TypeError, ValueError):
                        pass
        log_wait_times = defaults.telemetry.log_wait_times
        warn_threshold_s = defaults.telemetry.warn_threshold_s

    # Per-provider env var overrides: OBRA_GOVERNOR_COOLDOWN_S_<PROVIDER>
    for pname in list(providers.keys()):
        env_key = f"OBRA_GOVERNOR_COOLDOWN_S_{pname.upper()}"
        env_val = os.environ.get(env_key)
        if env_val is not None:
            try:
                v = float(env_val)
                if v >= 0:
                    existing = providers[pname]
                    providers[pname] = ProviderGovernorConfig(
                        max_concurrent_calls=existing.max_concurrent_calls,
                        cooldown_s=v,
                    )
                else:
                    logger.warning("%s must be >= 0 (got %s)", env_key, env_val)
            except (TypeError, ValueError):
                logger.warning("%s must be a number (got %s)", env_key, env_val)

    return GovernorConfig(
        enabled=enabled,
        max_concurrent_calls=max_concurrent,
        cooldown_s=cooldown_s,
        acquire_timeout_s=acquire_timeout_s,
        providers=providers,
        telemetry=GovernorTelemetryConfig(
            log_wait_times=log_wait_times,
            warn_threshold_s=warn_threshold_s,
        ),
    )
