"""Verification and code-verify getter owners."""

from __future__ import annotations

import os
from copy import deepcopy
from typing import Any

from .. import _core, _defaults

__all__ = [
    "get_code_verify_config",
    "get_code_verify_preflight_config",
    "get_code_verify_timeout_s",
    "get_verification_discovery_settings",
    "get_verification_tool_installs",
    "get_verification_tools_config",
]


def get_verification_tool_installs() -> dict[str, list[str]]:
    """Get install command lists for verification tool categories.

    Returns a mapping of category -> list of install command strings.
    """
    config, _, _ = _core.load_layered_config()
    fix_config = config.get("fix", {})
    if not isinstance(fix_config, dict):
        return {}
    verification_config = fix_config.get("verification", {})
    if not isinstance(verification_config, dict):
        return {}
    tools = verification_config.get("tools", [])
    if not isinstance(tools, list):
        return {}
    installs: dict[str, list[str]] = {}
    for tool in tools:
        if not isinstance(tool, dict):
            continue
        category = str(tool.get("category") or tool.get("name") or "").strip()
        if not category:
            continue
        install = tool.get("install", [])
        if isinstance(install, str):
            commands = [install]
        elif isinstance(install, list):
            commands = [str(cmd).strip() for cmd in install if str(cmd).strip()]
        else:
            commands = []
        if commands:
            installs[category] = commands
    return installs


def get_verification_discovery_settings() -> dict[str, bool | int]:
    """Get verification discovery settings as a composite dict.

    Returns dict with enabled, force_refresh, and timeout_s settings.
    Supports OBRA_VERIFICATION_DISCOVERY_ENABLED env override.

    Resolution order for enabled:
    1. OBRA_VERIFICATION_DISCOVERY_ENABLED environment variable
    2. fix.verification.discovery_enabled from config file
    3. DEFAULT_VERIFICATION_DISCOVERY_ENABLED constant (True)

    Returns:
        Dict with:
        - enabled: Whether tooling discovery is enabled (default: True)
        - force_refresh: Whether to force refresh cache (default: False)
        - timeout_s: Discovery timeout in seconds (default: 120)
    """
    import sys as _sys
    _mod = _sys.modules.get("obra.config.loaders") or _sys.modules.get(__name__.rsplit(".", 1)[0])

    env_enabled = os.environ.get("OBRA_VERIFICATION_DISCOVERY_ENABLED")
    if env_enabled is not None:
        enabled = env_enabled.lower() in ("true", "1", "yes")
    # Call the registry-generated getter via the parent loaders module
    elif _mod is not None and hasattr(_mod, "get_verification_discovery_enabled"):
        enabled = _mod.get_verification_discovery_enabled()
    else:
        enabled = _defaults.DEFAULT_VERIFICATION_DISCOVERY_ENABLED

    force_refresh = False
    timeout_s = 120
    if _mod is not None:
        if hasattr(_mod, "get_verification_force_refresh"):
            force_refresh = _mod.get_verification_force_refresh()
        if hasattr(_mod, "get_tooling_discovery_timeout"):
            timeout_s = _mod.get_tooling_discovery_timeout()

    return {
        "enabled": enabled,
        "force_refresh": force_refresh,
        "timeout_s": timeout_s,
    }


def get_verification_tools_config(
    config: dict | None = None,
) -> dict[str, dict[str, str]]:
    """Get verification tools configuration, handling dual schema.

    Supports both legacy list format and new nested dict format:
    - Legacy: [{category: test, command: pytest}]
    - New: {test: {command: pytest}, lint: {command: ruff check}}

    Args:
        config: Optional config dict. If None, loads via load_layered_config().

    Returns:
        Dict with keys: test, lint, format, typecheck (each with command subkey).
        Empty command string means 'use detected tool'.
    """
    if config is None:
        config, _, _ = _core.load_layered_config()

    fix_config = config.get("fix", {})
    if not isinstance(fix_config, dict):
        return _core._empty_tools_config()

    verification_config = fix_config.get("verification", {})
    if not isinstance(verification_config, dict):
        return _core._empty_tools_config()

    tools = verification_config.get("tools", [])

    if isinstance(tools, list):
        return _core._convert_legacy_tools_config(tools)

    if isinstance(tools, dict):
        return _core._normalize_tools_config(tools)

    return _core._empty_tools_config()


def get_code_verify_config() -> dict[str, Any]:
    """Get full CodeVerify agent configuration with env override support.

    Resolution order for enabled flag:
    1. OBRA_CODE_VERIFY_ENABLED environment variable
    2. features.quality_automation.agents.code_verify.enabled from layered config
    3. Bundled default config (enabled=true)
    """
    env_enabled = os.environ.get("OBRA_CODE_VERIFY_ENABLED")

    config, _, _ = _core.load_layered_config()
    default_config = _core._get_default_code_verify_config()

    agent_value = (
        config.get("features", {})
        .get("quality_automation", {})
        .get("agents", {})
        .get("code_verify")
    )
    agent_config = deepcopy(agent_value) if isinstance(agent_value, dict) else default_config

    if env_enabled is not None:
        agent_config["enabled"] = env_enabled.lower() in ("true", "1", "yes", "on")

    return agent_config


def get_code_verify_timeout_s() -> int:
    """Get CodeVerify timeout in seconds with env override support."""
    env_timeout = os.environ.get("OBRA_CODE_VERIFY_TIMEOUT_S")
    if env_timeout:
        try:
            return int(env_timeout)
        except ValueError:
            pass

    config = get_code_verify_config()
    timeout = config.get("timeout_s")
    if timeout is not None:
        try:
            return int(timeout)
        except (TypeError, ValueError):
            pass

    return int(_core._get_default_code_verify_config().get("timeout_s", 900))


def get_code_verify_preflight_config() -> dict[str, Any]:
    """Get CodeVerify story pre-flight config with env override support."""
    env_enabled = os.environ.get("OBRA_CODE_VERIFY_PREFLIGHT_ENABLED")

    config = get_code_verify_config()
    preflight = config.get("story_preflight")
    preflight_config = (
        deepcopy(preflight)
        if isinstance(preflight, dict)
        else deepcopy(_core._get_default_code_verify_config().get("story_preflight", {}))
    )

    if env_enabled is not None:
        preflight_config["enabled"] = env_enabled.lower() in (
            "true",
            "1",
            "yes",
            "on",
        )

    return preflight_config
