"""Story0 and escalation-fixer getter owners."""

from __future__ import annotations

import os
from copy import deepcopy
from typing import Any

from .. import _core, _defaults

__all__ = [
    "get_escalation_fixer_allowed_routes",
    "get_escalation_fixer_config",
    "get_escalation_fixer_eligible_reason_codes",
    "get_escalation_fixer_enabled",
    "get_escalation_fixer_max_attempts_per_episode",
    "get_escalation_fixer_timeout_s",
    "get_execute_zero_output_retry_max",
    "get_story0_capability_checks",
    "get_story0_port_mapping",
    "get_story0_service_image",
]


def _split_csv_env(value: str) -> list[str]:
    return [item.strip() for item in value.split(",") if item.strip()]


def get_escalation_fixer_config() -> dict[str, Any]:
    """Get full escalation fixer agent configuration with env override support."""
    config, _, _ = _core.load_layered_config()
    default_config = _core._get_default_escalation_fixer_config()
    agent_value = (
        config.get("features", {})
        .get("quality_automation", {})
        .get("agents", {})
        .get("escalation_fixer")
    )
    agent_config = deepcopy(agent_value) if isinstance(agent_value, dict) else default_config

    env_enabled = os.environ.get("OBRA_ESCALATION_FIXER_AGENT_ENABLED")
    if env_enabled is not None:
        agent_config["enabled"] = env_enabled.lower() in ("true", "1", "yes", "on")

    return agent_config


def get_escalation_fixer_enabled() -> bool:
    """Get review escalation fixer enabled flag with env override support."""
    env_value = os.environ.get("OBRA_ESCALATION_FIXER_ENABLED")
    if env_value is not None:
        return env_value.lower() in ("true", "1", "yes", "on")

    config, _, _ = _core.load_layered_config()
    value = (
        config.get("review", {})
        .get("escalation_fixer", {})
        .get("enabled")
    )
    if isinstance(value, bool):
        return value

    defaults = _core._load_default_schema()
    return bool(
        defaults.get("review", {})
        .get("escalation_fixer", {})
        .get("enabled", False)
    )


def get_escalation_fixer_timeout_s() -> int:
    """Get review escalation fixer timeout with env override support."""
    env_value = os.environ.get("OBRA_ESCALATION_FIXER_TIMEOUT_S")
    if env_value:
        try:
            return int(env_value)
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    value = (
        config.get("review", {})
        .get("escalation_fixer", {})
        .get("timeout_s")
    )
    if value is not None:
        try:
            return int(value)
        except (TypeError, ValueError):
            pass

    defaults = _core._load_default_schema()
    return int(
        defaults.get("review", {})
        .get("escalation_fixer", {})
        .get("timeout_s", 600)
    )


def get_escalation_fixer_max_attempts_per_episode() -> int:
    """Get escalation fixer attempt cap with env override support."""
    env_value = os.environ.get("OBRA_ESCALATION_FIXER_MAX_ATTEMPTS_PER_EPISODE")
    if env_value:
        try:
            return int(env_value)
        except ValueError:
            pass

    config, _, _ = _core.load_layered_config()
    value = (
        config.get("review", {})
        .get("escalation_fixer", {})
        .get("max_attempts_per_episode")
    )
    if value is not None:
        try:
            return int(value)
        except (TypeError, ValueError):
            pass

    defaults = _core._load_default_schema()
    return int(
        defaults.get("review", {})
        .get("escalation_fixer", {})
        .get("max_attempts_per_episode", 1)
    )


def get_escalation_fixer_allowed_routes() -> list[str]:
    """Get allowed escalation fixer routes with env override support."""
    env_value = os.environ.get("OBRA_ESCALATION_FIXER_ALLOWED_ROUTES")
    if env_value:
        return _split_csv_env(env_value)

    config, _, _ = _core.load_layered_config()
    value = (
        config.get("review", {})
        .get("escalation_fixer", {})
        .get("allowed_routes")
    )
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]

    defaults = _core._load_default_schema()
    default_value = (
        defaults.get("review", {})
        .get("escalation_fixer", {})
        .get("allowed_routes", [])
    )
    if isinstance(default_value, list):
        return [str(item).strip() for item in default_value if str(item).strip()]
    return []


def get_escalation_fixer_eligible_reason_codes() -> list[str]:
    """Get eligible escalation reason codes with env override support."""
    env_value = os.environ.get("OBRA_ESCALATION_FIXER_ELIGIBLE_REASON_CODES")
    if env_value:
        return _split_csv_env(env_value)

    config, _, _ = _core.load_layered_config()
    value = (
        config.get("review", {})
        .get("escalation_fixer", {})
        .get("eligible_reason_codes")
    )
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]

    defaults = _core._load_default_schema()
    default_value = (
        defaults.get("review", {})
        .get("escalation_fixer", {})
        .get("eligible_reason_codes", [])
    )
    if isinstance(default_value, list):
        return [str(item).strip() for item in default_value if str(item).strip()]
    return []


def get_story0_port_mapping(service_name: str) -> int | None:
    """Get port mapping for a service in story0 handler.

    Args:
        service_name: Name of the service (postgres, redis, mysql, mongodb)

    Returns:
        Port number if configured, None otherwise
    """
    config, _, _ = _core.load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            mappings = story0_config.get("port_mappings", {})
            if isinstance(mappings, dict):
                port = mappings.get(service_name)
                if port is not None:
                    try:
                        return int(port)
                    except (TypeError, ValueError):
                        pass
    return _defaults.DEFAULT_STORY0_PORT_MAPPINGS.get(service_name)


def get_story0_service_image(service_name: str) -> str:
    """Get Docker image for a service in story0 handler.

    Args:
        service_name: Name of the service (postgres, redis, mysql, mongodb)

    Returns:
        Docker image string, defaults to service_name if not configured
    """
    config, _, _ = _core.load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            images = story0_config.get("service_images", {})
            if isinstance(images, dict):
                image = images.get(service_name)
                if image and isinstance(image, str):
                    return image
    return _defaults.DEFAULT_STORY0_SERVICE_IMAGES.get(service_name, service_name)


def get_execute_zero_output_retry_max() -> int:
    """Get max retries for zero-output execution results.

    Config path: handlers.execute.zero_output_retry_max

    Returns:
        Max retry count (default: 1)
    """
    config, _, _ = _core.load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        execute_config = handlers_config.get("execute", {})
        if isinstance(execute_config, dict):
            retry_max = execute_config.get("zero_output_retry_max")
            if retry_max is not None:
                try:
                    return max(0, int(retry_max))
                except (TypeError, ValueError):
                    pass
    return _defaults.DEFAULT_EXECUTE_ZERO_OUTPUT_RETRY_MAX


def get_story0_capability_checks() -> dict[str, dict[str, Any]]:
    """Get host capability check definitions for story0 LOCAL_CAPABILITY handling.

    3-tier resolution: OBRA_STORY0_CAPABILITY_CHECKS env var (JSON) -> config -> default.

    Returns:
        Mapping of capability name to {env_vars, indicators, always_available}.
    """
    import json

    env_val = os.environ.get("OBRA_STORY0_CAPABILITY_CHECKS")
    if env_val:
        try:
            parsed = json.loads(env_val)
            if isinstance(parsed, dict):
                return parsed
        except (json.JSONDecodeError, TypeError):
            pass
    config, _, _ = _core.load_layered_config()
    handlers_config = config.get("handlers", {})
    if isinstance(handlers_config, dict):
        story0_config = handlers_config.get("story0", {})
        if isinstance(story0_config, dict):
            checks = story0_config.get("capability_checks")
            if isinstance(checks, dict) and checks:
                return checks
    return dict(_defaults.DEFAULT_STORY0_CAPABILITY_CHECKS)
