"""Workflow getter owners."""

from __future__ import annotations

import os
from copy import deepcopy
from typing import Any

from obra.exceptions import ConfigurationError

from .. import _core, _defaults

__all__ = [
    "get_priority_order",
    "get_workflow_derivation_config",
    "get_workflow_derivation_llm_config",
]


def _parse_timeout_value(
    raw_value: Any,
    *,
    source: str,
    minimum: int = 600,
    allow_zero: bool = False,
) -> int:
    """Validate and coerce a timeout value."""
    try:
        timeout_s = int(raw_value)
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(f"{source} must be an integer") from exc

    if allow_zero and timeout_s == 0:
        return timeout_s
    if timeout_s < minimum:
        raise ConfigurationError(f"{source} must be >= {minimum}")
    return timeout_s


def get_priority_order() -> dict:
    """Get priority ordering for issue severity levels.

    Returns:
        Dict mapping P0-P3 to numeric order (default: {"P0": 0, "P1": 1, "P2": 2, "P3": 3})
    """
    config, _, _ = _core.load_layered_config()
    workflow_config = config.get("workflow", {})
    if isinstance(workflow_config, dict):
        order = workflow_config.get("priority_order")
        if isinstance(order, dict):
            return order
    return _defaults.DEFAULT_PRIORITY_ORDER.copy()


def _get_workflow_derivation_section() -> dict[str, Any]:
    """Get the derivation.workflow section with env overrides applied."""
    config, _, _ = _core.load_layered_config(include_defaults=True)
    derivation_config = config.get("derivation")
    if not isinstance(derivation_config, dict):
        raise ConfigurationError("derivation section not found in config")
    workflow_config = derivation_config.get("workflow")
    if not isinstance(workflow_config, dict):
        raise ConfigurationError("derivation.workflow section not found in config")

    resolved = deepcopy(workflow_config)

    env_enabled = os.environ.get("OBRA_DERIVATION_WORKFLOW_ENABLED")
    if env_enabled is not None:
        lowered = env_enabled.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            resolved["enabled"] = True
        elif lowered in {"0", "false", "no", "off"}:
            resolved["enabled"] = False
        else:
            raise ConfigurationError(
                "OBRA_DERIVATION_WORKFLOW_ENABLED must be a boolean value"
            )

    llm_config = resolved.get("llm")
    if not isinstance(llm_config, dict):
        raise ConfigurationError("derivation.workflow.llm must be a dictionary")
    validation_config = resolved.get("validation")
    if not isinstance(validation_config, dict):
        raise ConfigurationError(
            "derivation.workflow.validation must be a dictionary"
        )
    operator_review_config = resolved.get("operator_review")
    if not isinstance(operator_review_config, dict):
        raise ConfigurationError(
            "derivation.workflow.operator_review must be a dictionary"
        )
    if "enabled" not in resolved:
        raise ConfigurationError("derivation.workflow.enabled is required")

    env_tier = os.environ.get("OBRA_DERIVATION_WORKFLOW_LLM_TIER")
    if env_tier is not None:
        llm_config["tier"] = env_tier.strip().lower()

    env_timeout = os.environ.get("OBRA_DERIVATION_WORKFLOW_LLM_TIMEOUT_S")
    if env_timeout is not None:
        try:
            llm_config["timeout_s"] = int(env_timeout)
        except ValueError as exc:
            raise ConfigurationError(
                "OBRA_DERIVATION_WORKFLOW_LLM_TIMEOUT_S must be an integer"
            ) from exc

    env_retries = os.environ.get("OBRA_DERIVATION_WORKFLOW_LLM_MAX_RETRIES")
    if env_retries is not None:
        try:
            llm_config["max_retries"] = int(env_retries)
        except ValueError as exc:
            raise ConfigurationError(
                "OBRA_DERIVATION_WORKFLOW_LLM_MAX_RETRIES must be an integer"
            ) from exc

    env_review = os.environ.get(
        "OBRA_DERIVATION_WORKFLOW_VALIDATION_REQUIRE_OPERATOR_REVIEW_FOR_INFERRED_INPUTS"
    )
    if env_review is not None:
        lowered = env_review.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            validation_config["require_operator_review_for_inferred_inputs"] = True
        elif lowered in {"0", "false", "no", "off"}:
            validation_config["require_operator_review_for_inferred_inputs"] = False
        else:
            raise ConfigurationError(
                "OBRA_DERIVATION_WORKFLOW_VALIDATION_REQUIRE_OPERATOR_REVIEW_FOR_INFERRED_INPUTS must be a boolean value"
            )

    env_compile_ready = os.environ.get(
        "OBRA_DERIVATION_WORKFLOW_VALIDATION_REQUIRE_COMPILE_READY_W2"
    )
    if env_compile_ready is not None:
        lowered = env_compile_ready.strip().lower()
        if lowered in {"1", "true", "yes", "on"}:
            validation_config["require_compile_ready_w2"] = True
        elif lowered in {"0", "false", "no", "off"}:
            validation_config["require_compile_ready_w2"] = False
        else:
            raise ConfigurationError(
                "OBRA_DERIVATION_WORKFLOW_VALIDATION_REQUIRE_COMPILE_READY_W2 must be a boolean value"
            )

    env_max_pending = os.environ.get(
        "OBRA_DERIVATION_WORKFLOW_OPERATOR_REVIEW_MAX_PENDING_POINTS"
    )
    if env_max_pending is not None:
        try:
            operator_review_config["max_pending_points"] = int(env_max_pending)
        except ValueError as exc:
            raise ConfigurationError(
                "OBRA_DERIVATION_WORKFLOW_OPERATOR_REVIEW_MAX_PENDING_POINTS must be an integer"
            ) from exc

    required_llm_keys = ("tier", "max_retries")
    missing_llm = [key for key in required_llm_keys if key not in llm_config]
    if missing_llm:
        raise ConfigurationError(
            "derivation.workflow.llm missing required keys: "
            + ", ".join(sorted(missing_llm))
        )
    tier = str(llm_config.get("tier", "") or "").strip().lower()
    if tier not in {"fast", "medium", "high"}:
        raise ConfigurationError(
            "derivation.workflow.llm.tier must be one of: fast, medium, high"
        )
    timeout_raw = llm_config.get("timeout_s")
    if timeout_raw is None:
        # Import the timeout getter from the timeouts module
        from .timeouts import get_llm_call_timeout

        timeout_s = get_llm_call_timeout()
    else:
        timeout_s = _parse_timeout_value(
            timeout_raw,
            source="derivation.workflow.llm.timeout_s",
        )
    try:
        max_retries = int(llm_config["max_retries"])
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(
            "derivation.workflow.llm.max_retries must be an integer"
        ) from exc
    if max_retries < 0:
        raise ConfigurationError(
            "derivation.workflow.llm.max_retries must be >= 0"
        )

    if "require_operator_review_for_inferred_inputs" not in validation_config:
        raise ConfigurationError(
            "derivation.workflow.validation.require_operator_review_for_inferred_inputs is required"
        )
    if "require_compile_ready_w2" not in validation_config:
        raise ConfigurationError(
            "derivation.workflow.validation.require_compile_ready_w2 is required"
        )
    if "max_pending_points" not in operator_review_config:
        raise ConfigurationError(
            "derivation.workflow.operator_review.max_pending_points is required"
        )
    try:
        max_pending_points = int(operator_review_config["max_pending_points"])
    except (TypeError, ValueError) as exc:
        raise ConfigurationError(
            "derivation.workflow.operator_review.max_pending_points must be an integer"
        ) from exc
    if max_pending_points < 1:
        raise ConfigurationError(
            "derivation.workflow.operator_review.max_pending_points must be >= 1"
        )

    resolved["enabled"] = bool(resolved.get("enabled", True))
    llm_config["tier"] = tier
    llm_config["timeout_s"] = timeout_s
    llm_config["max_retries"] = max_retries
    validation_config["require_operator_review_for_inferred_inputs"] = bool(
        validation_config["require_operator_review_for_inferred_inputs"]
    )
    validation_config["require_compile_ready_w2"] = bool(
        validation_config["require_compile_ready_w2"]
    )
    operator_review_config["max_pending_points"] = max_pending_points
    return resolved


def get_workflow_derivation_config() -> dict[str, Any]:
    """Get validated workflow-derivation settings with env overrides applied."""
    return _get_workflow_derivation_section()


def get_workflow_derivation_llm_config() -> dict[str, Any]:
    """Resolve workflow-derivation LLM settings from the configured explicit tier."""
    workflow_config = _get_workflow_derivation_section()
    llm_config = workflow_config["llm"]
    from obra.config.llm import resolve_tier_config

    resolved_tier = resolve_tier_config(str(llm_config["tier"]), role="orchestrator")
    return {
        "enabled": bool(workflow_config["enabled"]),
        "tier": llm_config["tier"],
        "provider": resolved_tier["provider"],
        "model": resolved_tier["model"],
        "reasoning_level": resolved_tier.get("reasoning_level"),
        "timeout_s": llm_config["timeout_s"],
        "max_retries": llm_config["max_retries"],
    }
