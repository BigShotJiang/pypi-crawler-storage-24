"""Residual getter owners with no stronger family match."""

from __future__ import annotations

from .. import _core, _defaults

__all__ = [
    "get_agent_ignore_patterns",
    "get_intent_chunking_config",
    "get_intent_rate_limit_config",
]


def get_agent_ignore_patterns() -> list[str]:
    """Get ignore patterns for agent file scanning.

    Returns:
        List of glob patterns or directory names to skip during agent scans.
    """
    config, _, _ = _core.load_layered_config(include_defaults=True)
    patterns = (
        config.get("features", {})
        .get("quality_automation", {})
        .get("agents", {})
        .get("ignore_patterns")
    )
    if isinstance(patterns, list):
        return [str(item) for item in patterns if item]
    return []


def get_intent_chunking_config() -> dict:
    """Get intent chunking configuration.

    Returns:
        Dict with size_tokens, overlap_tokens, warning_threshold keys
    """
    config, _, _ = _core.load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        chunking_config = intent_config.get("chunking", {})
        if isinstance(chunking_config, dict):
            return {
                "size_tokens": chunking_config.get(
                    "size_tokens", _defaults.DEFAULT_INTENT_CHUNKING_CONFIG["size_tokens"]
                ),
                "overlap_tokens": chunking_config.get(
                    "overlap_tokens", _defaults.DEFAULT_INTENT_CHUNKING_CONFIG["overlap_tokens"]
                ),
                "warning_threshold": chunking_config.get(
                    "warning_threshold",
                    _defaults.DEFAULT_INTENT_CHUNKING_CONFIG["warning_threshold"],
                ),
            }
    return _defaults.DEFAULT_INTENT_CHUNKING_CONFIG.copy()


def get_intent_rate_limit_config() -> dict:
    """Get intent rate limit configuration.

    Returns:
        Dict with max_retries, backoff_delays_s (list) keys
    """
    config, _, _ = _core.load_layered_config()
    intent_config = config.get("intent", {})
    if isinstance(intent_config, dict):
        rate_limit_config = intent_config.get("rate_limit", {})
        if isinstance(rate_limit_config, dict):
            return {
                "max_retries": rate_limit_config.get(
                    "max_retries", _defaults.DEFAULT_INTENT_RATE_LIMIT_CONFIG["max_retries"]
                ),
                "backoff_delays_s": rate_limit_config.get(
                    "backoff_delays_s",
                    _defaults.DEFAULT_INTENT_RATE_LIMIT_CONFIG["backoff_delays_s"],
                ),
            }
    return _defaults.DEFAULT_INTENT_RATE_LIMIT_CONFIG.copy()
