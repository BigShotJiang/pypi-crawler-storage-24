"""Factory functions for building config getter closures from descriptors."""

from __future__ import annotations

import logging
import os
from typing import Any, Callable

from obra.exceptions import ConfigurationError

from ._descriptors import ConfigEntry, ConfigSection

__all__ = [
    "_coerce_value",
    "_make_scalar_getter",
    "_apply_constraints",
    "_make_section_getter",
]

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Internal coercion helper
# ---------------------------------------------------------------------------


def _coerce_value(raw: str, target_type: type) -> Any:
    """Coerce a string value to *target_type*.

    CRITICAL: bool must use string-matching, NOT ``bool(raw)`` — because
    ``bool('false')`` evaluates to ``True``.
    """
    if target_type is bool:
        return raw.lower() in ("true", "1", "yes")
    return target_type(raw)


# ---------------------------------------------------------------------------
# Scalar getter factory
# ---------------------------------------------------------------------------


def _make_scalar_getter(entry: ConfigEntry, loader_fn: Callable) -> Callable:
    """Build a ``get_*()`` closure implementing 3-tier resolution for *entry*."""

    def _getter() -> entry.return_type:  # type: ignore[name-defined]
        # Tier 1: environment variable override
        if entry.env_var is not None:
            env_val = os.environ.get(entry.env_var)
            if entry.return_type is bool:
                # For bool: empty string is a valid env value (yields False),
                # so use "is not None" rather than truthiness check.
                if env_val is not None:
                    try:
                        value = _coerce_value(env_val, entry.return_type)
                        return _apply_constraints(value, entry)
                    except (TypeError, ValueError) as exc:
                        logger.warning(
                            "Config env var %s coercion failed (%s); falling through.",
                            entry.env_var,
                            exc,
                        )
            # For non-bool: empty string means "unset", skip to tier 2.
            elif env_val:
                try:
                    value = _coerce_value(env_val, entry.return_type)
                    return _apply_constraints(value, entry)
                except (TypeError, ValueError) as exc:
                    logger.warning(
                        "Config env var %s coercion failed (%s); falling through.",
                        entry.env_var,
                        exc,
                    )

        # Tier 2: config file
        try:
            config, _, _ = loader_fn()
            segments = entry.config_path.split(".")
            current: Any = config
            found = True
            for seg in segments[:-1]:
                if not isinstance(current, dict):
                    found = False
                    break
                current = current.get(seg, {})
            if found and isinstance(current, dict):
                leaf = current.get(segments[-1])
                if leaf is not None:
                    try:
                        value = _coerce_value(str(leaf), entry.return_type)
                        return _apply_constraints(value, entry)
                    except (TypeError, ValueError):
                        pass  # fall through to default
        except (AttributeError, TypeError, KeyError):
            pass  # malformed config — fall through to default

        # Tier 3: default
        if entry.fail_fast:
            raise ConfigurationError(
                f"Missing required config: {entry.config_path}"
            )
        return _apply_constraints(entry.default, entry)

    # Attach metadata so the function looks like its handwritten counterpart.
    _getter.__name__ = f"get_{entry.name}"
    _getter.__qualname__ = f"get_{entry.name}"
    _getter.__module__ = "obra.config.loaders"
    _getter.__doc__ = entry.docstring or (
        f"Return the ``{entry.config_path}`` config value."
    )
    _getter.__annotations__ = {"return": entry.return_type}
    return _getter


def _apply_constraints(value: Any, entry: ConfigEntry) -> Any:
    """Validate *value* against *entry*'s constraint fields and return it."""
    if entry.min_val is not None and value < entry.min_val:
        raise ConfigurationError(
            f"Config {entry.config_path}={value!r} is below minimum {entry.min_val}"
        )
    if entry.max_val is not None and value > entry.max_val:
        raise ConfigurationError(
            f"Config {entry.config_path}={value!r} exceeds maximum {entry.max_val}"
        )
    if entry.positive and value <= 0:
        raise ConfigurationError(
            f"Config {entry.config_path}={value!r} must be positive (> 0)"
        )
    if entry.choices is not None and value not in entry.choices:
        raise ConfigurationError(
            f"Config {entry.config_path}={value!r} not in allowed choices {entry.choices}"
        )
    return value


# ---------------------------------------------------------------------------
# Section getter factory
# ---------------------------------------------------------------------------


def _make_section_getter(section: ConfigSection, loader_fn: Callable) -> Callable:
    """Build a ``get_*()`` closure returning a dict for *section*."""

    _fallback: dict[str, Any] = {f.name: f.default for f in section.fields}

    def _getter() -> dict:
        try:
            config, _, _ = loader_fn()
            segments = section.config_path.split(".")
            current: Any = config
            for seg in segments:
                if not isinstance(current, dict):
                    return dict(_fallback)
                current = current.get(seg, {})
            # All-or-nothing: bracket-access so missing key raises KeyError.
            result: dict[str, Any] = {}
            for f in section.fields:
                result[f.name] = f.field_type(current[f.config_key])
            return result
        except (AttributeError, TypeError, KeyError):
            return dict(_fallback)

    _getter.__name__ = f"get_{section.name}"
    _getter.__qualname__ = f"get_{section.name}"
    _getter.__module__ = "obra.config.loaders"
    _getter.__doc__ = section.docstring or (
        f"Return the ``{section.config_path}`` config section as a dict."
    )
    _getter.__annotations__ = {"return": dict}
    return _getter
