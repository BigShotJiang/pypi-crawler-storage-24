"""Legacy migration, alias resolution, and pipeline normalization.

Contains all config-transform functions: deprecated field handling,
semantic alias resolution, runner catalog normalization, and session
pipeline compatibility projections.
"""

from __future__ import annotations

import logging
from collections.abc import Mapping, Sequence
from copy import deepcopy
from pathlib import Path
from typing import Any, cast

from obra.workflow.runner_catalog import (
    normalize_runner_catalog_entry,
)

from . import _defaults
from ._dict_utils import _get_nested_value, _has_nested_key, _set_nested_value

logger = logging.getLogger(__name__)


def resolve_semantic_alias(path: str) -> tuple[str, str | None]:
    """Resolve semantic config aliases to canonical paths.

    Returns:
        Tuple of (canonical_path, hint_message or None).
        If an alias was resolved, hint_message explains the mapping.
    """
    canonical = _defaults.SEMANTIC_CONFIG_ALIASES.get(path)
    if canonical:
        return canonical, f"'{path}' maps to '{canonical}'"
    return path, None


def resolve_config_alias(path: str) -> str:
    """Resolve deprecated config paths to their canonical replacements.

    This function checks both deprecated aliases (which trigger warnings)
    and semantic aliases (which are user-friendly shortcuts).
    """
    # First check deprecated aliases
    if path in _defaults.CONFIG_PATH_ALIASES:
        return _defaults.CONFIG_PATH_ALIASES[path]
    # Then check semantic aliases
    if path in _defaults.SEMANTIC_CONFIG_ALIASES:
        return _defaults.SEMANTIC_CONFIG_ALIASES[path]
    return path


def _get_pipeline_project_overlay_entries(config: dict[str, Any]) -> list[Any] | None:
    """Return pipeline runner-catalog project overlay entries when present."""
    pipeline = config.get("pipeline")
    if not isinstance(pipeline, dict):
        return None
    runner_catalog = pipeline.get("runner_catalog")
    if not isinstance(runner_catalog, dict):
        return None
    project_overlay = runner_catalog.get("project_overlay")
    if not isinstance(project_overlay, dict):
        return None
    entries = project_overlay.get("entries")
    if isinstance(entries, list):
        return entries
    return None


def _set_pipeline_project_overlay_entries(config: dict[str, Any], entries: list[Any]) -> None:
    """Set pipeline runner-catalog project overlay entries, creating containers."""
    pipeline = config.setdefault("pipeline", {})
    if not isinstance(pipeline, dict):
        return
    runner_catalog = pipeline.setdefault("runner_catalog", {})
    if not isinstance(runner_catalog, dict):
        return
    project_overlay = runner_catalog.setdefault("project_overlay", {})
    if not isinstance(project_overlay, dict):
        return
    project_overlay["entries"] = entries


def _normalize_pipeline_runner_catalog(config: dict[str, Any]) -> None:
    """Normalize canonical project-overlay runner registrations."""
    pipeline = config.get("pipeline")
    if not isinstance(pipeline, dict):
        return

    canonical_entries = _get_pipeline_project_overlay_entries(config)
    normalized_entries: list[Any] = []
    if canonical_entries is not None:
        for entry in canonical_entries:
            if not isinstance(entry, Mapping):
                normalized_entries.append(entry)
                continue
            try:
                normalized = normalize_runner_catalog_entry(entry)
            except ValueError:
                normalized_entries.append(deepcopy(entry))
                continue
            enabled = entry.get("enabled")
            if isinstance(enabled, bool):
                normalized["enabled"] = enabled
            normalized_entries.append(normalized)
    elif "runner_catalog" in pipeline:
        _set_pipeline_project_overlay_entries(config, normalized_entries)

    if normalized_entries or canonical_entries is not None:
        _set_pipeline_project_overlay_entries(config, normalized_entries)


def _normalize_text(value: Any) -> str | None:
    text = str(value).strip() if value is not None else ""
    return text or None


def _legacy_runner_activation(
    entry: Mapping[str, Any],
) -> tuple[str | None, dict[str, Any]]:
    factory = _normalize_text(entry.get("factory"))
    if factory is not None:
        return "python_runner", {"factory": factory}

    command = entry.get("command")
    if isinstance(command, Sequence) and not isinstance(command, (str, bytes)):
        command_items = [str(item).strip() for item in command if str(item).strip()]
        if command_items:
            return "command_runner", {"command": command_items}
    return None, {}


def _project_legacy_runner_catalog_entry(
    entry: Mapping[str, Any],
) -> dict[str, Any] | None:
    runner_id = _normalize_text(entry.get("id")) or _normalize_text(entry.get("name"))
    if runner_id is None:
        return None

    kind, activation = _legacy_runner_activation(entry)
    if kind is None:
        return None

    projected = {
        "id": runner_id,
        "display_name": _normalize_text(entry.get("display_name")) or runner_id,
        "kind": kind,
        "version": _normalize_text(entry.get("version")) or "legacy",
        "scope": "shared",
        "domain_ids": [],
        "portability": "local_only",
        "compatibility": {"catalog_api_version": "1"},
        "source": {"source_type": "project_overlay"},
        "activation": activation,
    }
    enabled = entry.get("enabled")
    if isinstance(enabled, bool):
        projected["enabled"] = enabled
    return projected


def _legacy_sound_route(value: Any) -> str:
    normalized = _normalize_text(value)
    if normalized in {"stop", "block"}:
        return "block_stage"
    if normalized == "escalate":
        return "escalate"
    if normalized in {"pending_manual", "manual"}:
        return "wait_for_manual_action"
    return "continue"


def _legacy_issue_route(value: Any, action: Any) -> str:
    normalized_then = _normalize_text(value)
    normalized_action = _normalize_text(action)

    if normalized_then in {"continue", "continue_with_findings"}:
        return "continue_with_findings"
    if normalized_then in {"stop", "block"}:
        return "block_stage"
    if normalized_then == "escalate":
        return "escalate"
    if normalized_then in {"pending_manual", "manual"}:
        return "wait_for_manual_action"
    if normalized_then in {"retry", "retry_same_stage"} or normalized_action == "retry":
        return "retry_same_stage"
    if normalized_then in {"re-validate", "refine", "revise"} or normalized_action in {
        "re-validate",
        "refine",
        "revise",
    }:
        return "revise_same_stage"
    return "revise_same_stage"


def _project_legacy_stage_quality_loop(stage: Mapping[str, Any]) -> dict[str, Any] | None:
    if isinstance(stage.get("quality_loop"), Mapping):
        return dict(stage["quality_loop"])

    legacy_issues = stage.get("on_issues")
    legacy_sound = stage.get("on_sound")
    if legacy_issues is None and legacy_sound is None:
        return None

    legacy_then = legacy_issues.get("then") if isinstance(legacy_issues, Mapping) else None
    legacy_action = legacy_issues.get("action") if isinstance(legacy_issues, Mapping) else None
    on_pass = _legacy_sound_route(legacy_sound)
    on_revise_required = _legacy_issue_route(legacy_then, legacy_action)
    if on_revise_required == "continue_with_findings":
        on_advisory_pass = "continue_with_findings"
    else:
        on_advisory_pass = "continue_with_findings" if on_pass == "continue" else on_pass

    return {
        "routing": {
            "on_pass": on_pass,
            "on_advisory_pass": on_advisory_pass,
            "on_revise_required": on_revise_required,
            "on_block": "block_stage",
            "on_escalate": "escalate",
            "on_pending_manual": "wait_for_manual_action",
            "on_manual_resume": "resume_stage",
        },
        "pending_manual": {
            "required_action": "approve_output",
            "resume": {
                "checkpoint": "quality-loop",
                "strategy": "manual_resume",
            },
        },
    }


def _project_session_pipeline_compatibility(
    config: dict[str, Any],
    *,
    warnings: list[str],
    path: Path,
) -> dict[str, Any]:
    pipeline = config.get("pipeline")
    if not isinstance(pipeline, dict):
        return config

    legacy_runners = pipeline.get("registered_runners")
    custom_stages = pipeline.get("custom_stages")
    if not isinstance(legacy_runners, list) and not isinstance(custom_stages, list):
        return config

    projected = deepcopy(config)
    pipeline = projected.setdefault("pipeline", {})
    if not isinstance(pipeline, dict):
        return config

    migrated = False

    if isinstance(legacy_runners, list):
        compat_entries = [
            entry
            for entry in (
                _project_legacy_runner_catalog_entry(item)
                for item in legacy_runners
                if isinstance(item, Mapping)
            )
            if entry is not None
        ]
        if compat_entries:
            existing_entries = _get_pipeline_project_overlay_entries(projected) or []
            _set_pipeline_project_overlay_entries(projected, [*existing_entries, *compat_entries])
            pipeline.pop("registered_runners", None)
            migrated = True

    if isinstance(custom_stages, list):
        normalized_stages: list[Any] = []
        for stage in custom_stages:
            if not isinstance(stage, Mapping):
                normalized_stages.append(stage)
                continue
            stage_dict = deepcopy(dict(stage))
            runner_value = stage_dict.get("runner")
            if isinstance(runner_value, str) and runner_value.strip():
                stage_dict["runner"] = {"runner_id": runner_value.strip()}
                migrated = True
            if stage_dict.get("runner_kind") is not None:
                stage_dict.pop("runner_kind", None)
                migrated = True
            quality_loop = _project_legacy_stage_quality_loop(stage_dict)
            if quality_loop is not None:
                stage_dict["quality_loop"] = quality_loop
                if "on_issues" in stage_dict:
                    stage_dict.pop("on_issues", None)
                if "on_sound" in stage_dict:
                    stage_dict.pop("on_sound", None)
                migrated = True
            normalized_stages.append(stage_dict)
        pipeline["custom_stages"] = normalized_stages

    if migrated:
        warnings.append(
            f"Session config at {path} uses legacy pipeline fields; applying session-layer compatibility projection."
        )
    return projected


def _check_deprecated_fields(
    config: dict[str, Any],
    warnings: list[str],
) -> None:
    """Check for deprecated fields and add migration warnings.

    This function scans user config for deprecated fields defined in
    DEPRECATED_FIELDS and adds actionable warnings to help users migrate.

    Args:
        config: User configuration dictionary
        warnings: List to append warning messages to
    """
    from obra.messages import get_message

    for deprecated_path, (new_path, extra_context) in _defaults.DEPRECATED_FIELDS.items():
        if _has_nested_key(config, deprecated_path):
            # Generate deprecation message using message library
            if new_path:
                base_msg = cast(
                    str,
                    get_message(  # type: ignore[operator]
                        "warning.deprecation.config_key",
                        old=deprecated_path,
                        new=new_path,
                    ),
                )
            else:
                # No replacement - use generic deprecation message
                base_msg = f"Config key '{deprecated_path}' is no longer supported."
            # Append extra context if provided
            full_msg = f"{base_msg} {extra_context}" if extra_context else base_msg
            # Add [LEGACY CONFIG] prefix to make it stand out
            warnings.append(f"[LEGACY CONFIG] {full_msg}")


def _apply_config_aliases(
    config: dict[str, Any],
    warnings: list[str] | None = None,
) -> dict[str, Any]:
    """Apply deprecated path aliases without mutating the source dict."""
    normalized = deepcopy(config)

    # Check for deprecated fields first (before path aliasing)
    if warnings is not None:
        _check_deprecated_fields(normalized, warnings)

    for legacy, canonical in _defaults.CONFIG_PATH_ALIASES.items():
        legacy_exists = _has_nested_key(normalized, legacy)
        canonical_exists = _has_nested_key(normalized, canonical)
        legacy_value = _get_nested_value(normalized, legacy) if legacy_exists else None
        canonical_value = _get_nested_value(normalized, canonical) if canonical_exists else None

        if legacy_exists and not canonical_exists:
            _set_nested_value(normalized, canonical, legacy_value)
            if warnings is not None:
                warnings.append(f"Deprecated config key '{legacy}' detected; use '{canonical}'.")
        elif canonical_exists and not legacy_exists:
            _set_nested_value(normalized, legacy, canonical_value)
        elif legacy_exists and canonical_exists and legacy_value != canonical_value:
            _set_nested_value(normalized, legacy, canonical_value)
            if warnings is not None:
                warnings.append(
                    f"Config keys '{legacy}' and '{canonical}' both set; "
                    f"'{canonical}' takes precedence."
                )

    return normalized


def _normalize_agent_bool_configs(
    config: dict[str, Any],
    origins: dict[str, str] | None,
    include_defaults: bool,
) -> None:
    """Normalize legacy agent booleans to {enabled, llm} objects."""
    agents = _get_nested_value(config, "features.quality_automation.agents")
    if not isinstance(agents, dict):
        return

    for agent_name, value in list(agents.items()):
        if agent_name in ("description", "ignore_patterns"):
            continue
        if isinstance(value, bool):
            path = f"features.quality_automation.agents.{agent_name}"
            origin = origins.get(path) if origins is not None else None
            agents[agent_name] = {
                "enabled": value,
                "llm": deepcopy(_defaults.AGENT_LLM_DEFAULTS),
            }
            if origins is not None:
                if origin:
                    origins[f"{path}.enabled"] = origin
                elif include_defaults and f"{path}.enabled" not in origins:
                    origins[f"{path}.enabled"] = "default"
                for llm_key in _defaults.AGENT_LLM_DEFAULTS:
                    llm_path = f"{path}.llm.{llm_key}"
                    if include_defaults and llm_path not in origins:
                        origins[llm_path] = "default"
                if path in origins:
                    del origins[path]
