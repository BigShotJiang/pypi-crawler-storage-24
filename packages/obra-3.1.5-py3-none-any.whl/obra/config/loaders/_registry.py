"""Declarative config getter registry — coordination facade.

Re-exports descriptors, factory functions, entry lists, and the public
``register_getters()`` injection function.  All implementation lives in
sibling modules; this file exists so that every historical import path
(``from obra.config.loaders._registry import ...``) keeps working.
"""

from __future__ import annotations

import types
from typing import Callable, Sequence

# ── Descriptors ──────────────────────────────────────────────────────────
from ._descriptors import ConfigEntry, ConfigSection, SectionField

# ── Factory helpers ──────────────────────────────────────────────────────
from ._registry_factory import (
    _apply_constraints,
    _coerce_value,
    _make_scalar_getter,
    _make_section_getter,
)

# ── Entry lists ──────────────────────────────────────────────────────────
from ._entries import (
    CONSTRAINT_ENTRIES,
    DOMAIN_ENTRIES,
    HANDLER_ENTRIES,
    INFRA_ENTRIES,
    SECTION_ENTRIES,
)


# ---------------------------------------------------------------------------
# Public injection function
# ---------------------------------------------------------------------------


def register_getters(
    entries: Sequence[ConfigEntry | ConfigSection],
    target_module: types.ModuleType,
    loader_fn: Callable,
) -> list[str]:
    """Generate ``get_*()`` functions from *entries* and inject into *target_module*.

    Args:
        entries: Sequence of :class:`ConfigEntry` or :class:`ConfigSection` objects.
        target_module: Module to inject the generated functions into (typically
            ``sys.modules['obra.config.loaders']``).
        loader_fn: Callable returning ``(config, _, _)`` — passed to each factory.

    Returns:
        List of generated function names (e.g., ``['get_foo', 'get_bar']``).
    """
    names: list[str] = []
    for entry in entries:
        if isinstance(entry, ConfigEntry):
            func = _make_scalar_getter(entry, loader_fn)
        else:
            func = _make_section_getter(entry, loader_fn)
        func_name = f"get_{entry.name}"
        setattr(target_module, func_name, func)
        names.append(func_name)
    return names


# ---------------------------------------------------------------------------
# __all__ — every symbol that was previously importable from this module
# ---------------------------------------------------------------------------

__all__ = [
    # Descriptors
    "ConfigEntry",
    "SectionField",
    "ConfigSection",
    # Factory helpers
    "_coerce_value",
    "_make_scalar_getter",
    "_apply_constraints",
    "_make_section_getter",
    # Public API
    "register_getters",
    # Entry lists
    "HANDLER_ENTRIES",
    "INFRA_ENTRIES",
    "DOMAIN_ENTRIES",
    "SECTION_ENTRIES",
    "CONSTRAINT_ENTRIES",
]
