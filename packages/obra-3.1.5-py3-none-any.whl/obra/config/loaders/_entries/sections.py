"""Composite-dict getter registry declarations (SECTION_ENTRIES).

Covers all-or-nothing bracket-access composite getters: cleanup, auto-retry,
intent detection/template/thresholds, file tracking, cache monitor, intake,
skip tracking, tooling discovery, process registry, execution quality,
log viewer, production logger, CLI retry/cache, oauth, plan validation,
API client, config explorer, derivation preview.
"""

from __future__ import annotations

from .._descriptors import ConfigSection, SectionField

SECTION_ENTRIES: list[ConfigSection] = [
    # --- orchestration.cleanup.investigation ---
    ConfigSection(
        name="cleanup_investigation_config",
        config_path="orchestration.cleanup.investigation",
        fields=(
            SectionField(name="max_hints", config_key="max_hints", default=5, field_type=int),
            SectionField(name="tier_gap", config_key="tier_gap", default=1, field_type=int),
            SectionField(name="tier_context", config_key="tier_context", default=2, field_type=int),
        ),
    ),
    # --- orchestration.auto (retry config) ---
    ConfigSection(
        name="auto_retry_config",
        config_path="orchestration.auto",
        fields=(
            SectionField(name="retry_count", config_key="retry_count", default=2, field_type=int),
            SectionField(
                name="retry_delay_seconds",
                config_key="retry_delay_seconds",
                default=30,
                field_type=int,
            ),
            SectionField(
                name="parallel_max_workers",
                config_key="parallel_max_workers",
                default=4,
                field_type=int,
            ),
        ),
    ),
    # --- intent.detection ---
    ConfigSection(
        name="intent_detection_config",
        config_path="intent.detection",
        fields=(
            SectionField(
                name="rich_min_words", config_key="rich_min_words", default=50, field_type=int
            ),
            SectionField(
                name="min_keyword_matches",
                config_key="min_keyword_matches",
                default=2,
                field_type=int,
            ),
            SectionField(
                name="min_detail_markers",
                config_key="min_detail_markers",
                default=2,
                field_type=int,
            ),
        ),
    ),
    # --- intent.templates ---
    ConfigSection(
        name="intent_template_config",
        config_path="intent.templates",
        fields=(
            SectionField(
                name="summary_preview_length",
                config_key="summary_preview_length",
                default=60,
                field_type=int,
            ),
        ),
    ),
    # --- file_tracking ---
    ConfigSection(
        name="file_tracking_config",
        config_path="file_tracking",
        fields=(
            SectionField(
                name="max_file_size_bytes",
                config_key="max_file_size_bytes",
                default=10485760,
                field_type=int,
            ),
        ),
    ),
    # --- observability.cache_monitor ---
    ConfigSection(
        name="cache_monitor_config",
        config_path="observability.cache_monitor",
        fields=(
            SectionField(
                name="subdir_threshold_mb",
                config_key="subdir_threshold_mb",
                default=50,
                field_type=int,
            ),
            SectionField(
                name="top_subdirs_count",
                config_key="top_subdirs_count",
                default=3,
                field_type=int,
            ),
        ),
    ),
    # --- intake ---
    ConfigSection(
        name="intake_config",
        config_path="intake",
        fields=(
            SectionField(name="min_words", config_key="min_words", default=3, field_type=int),
        ),
    ),
    # --- skip_tracking ---
    ConfigSection(
        name="skip_tracking_config",
        config_path="skip_tracking",
        fields=(
            SectionField(
                name="max_logs_chars",
                config_key="max_logs_chars",
                default=2000,
                field_type=int,
            ),
        ),
    ),
    # --- tooling_discovery ---
    ConfigSection(
        name="tooling_discovery_config",
        config_path="tooling_discovery",
        fields=(
            SectionField(
                name="max_manifest_bytes",
                config_key="max_manifest_bytes",
                default=2048,
                field_type=int,
            ),
        ),
    ),
    # --- process_registry ---
    ConfigSection(
        name="process_registry_config",
        config_path="process_registry",
        fields=(
            SectionField(
                name="terminate_timeout_s",
                config_key="terminate_timeout_s",
                default=3.0,
                field_type=float,
            ),
        ),
    ),
    # --- execution.quality ---
    ConfigSection(
        name="execution_quality_config",
        config_path="execution.quality",
        fields=(
            SectionField(
                name="default_threshold",
                config_key="default_threshold",
                default=0.6,
                field_type=float,
            ),
            SectionField(
                name="generated_plan_threshold",
                config_key="generated_plan_threshold",
                default=0.4,
                field_type=float,
            ),
        ),
    ),
    # --- intent.thresholds ---
    ConfigSection(
        name="intent_thresholds_config",
        config_path="intent.thresholds",
        fields=(
            SectionField(
                name="detection_empty", config_key="detection_empty", default=5, field_type=int
            ),
            SectionField(
                name="detection_existing",
                config_key="detection_existing",
                default=50,
                field_type=int,
            ),
            SectionField(
                name="interrogative_ratio",
                config_key="interrogative_ratio",
                default=0.5,
                field_type=float,
            ),
            SectionField(
                name="token_warning", config_key="token_warning", default=0.8, field_type=float
            ),
        ),
    ),
    # --- observability.log_viewer ---
    ConfigSection(
        name="log_viewer_config",
        config_path="observability.log_viewer",
        fields=(
            SectionField(name="host", config_key="host", default="127.0.0.1", field_type=str),
            SectionField(name="port", config_key="port", default=8844, field_type=int),
            SectionField(
                name="tail_limit", config_key="tail_limit", default=200, field_type=int
            ),
            SectionField(
                name="max_events", config_key="max_events", default=500, field_type=int
            ),
            SectionField(
                name="max_snapshot_bytes",
                config_key="max_snapshot_bytes",
                default=2097152,
                field_type=int,
            ),
            SectionField(
                name="index_rotation_files",
                config_key="index_rotation_files",
                default=3,
                field_type=int,
            ),
            SectionField(
                name="stream_sleep_s",
                config_key="stream_sleep_s",
                default=0.2,
                field_type=float,
            ),
            SectionField(
                name="graceful_shutdown_delay_s",
                config_key="graceful_shutdown_delay_s",
                default=1.0,
                field_type=float,
            ),
        ),
    ),
    # --- observability.production_logger ---
    ConfigSection(
        name="production_logger_config",
        config_path="observability.production_logger",
        fields=(
            SectionField(
                name="max_size_bytes",
                config_key="max_size_bytes",
                default=104857600,
                field_type=int,
            ),
            SectionField(
                name="backup_count", config_key="backup_count", default=10, field_type=int
            ),
        ),
    ),
    # --- cli.retry ---
    ConfigSection(
        name="cli_retry_config",
        config_path="cli.retry",
        fields=(
            SectionField(
                name="max_attempts", config_key="max_attempts", default=3, field_type=int
            ),
            SectionField(
                name="initial_delay_s",
                config_key="initial_delay_s",
                default=2,
                field_type=int,
            ),
            SectionField(
                name="backoff_multiplier",
                config_key="backoff_multiplier",
                default=2,
                field_type=int,
            ),
        ),
    ),
    # --- cli.cache ---
    ConfigSection(
        name="cli_cache_config",
        config_path="cli.cache",
        fields=(
            SectionField(
                name="warn_threshold_mb",
                config_key="warn_threshold_mb",
                default=500,
                field_type=int,
            ),
            SectionField(
                name="critical_threshold_mb",
                config_key="critical_threshold_mb",
                default=1000,
                field_type=int,
            ),
        ),
    ),
    # --- auth.oauth ---
    ConfigSection(
        name="oauth_config",
        config_path="auth.oauth",
        fields=(
            SectionField(
                name="poll_interval_s",
                config_key="poll_interval_s",
                default=0.1,
                field_type=float,
            ),
            SectionField(
                name="thread_join_timeout_s",
                config_key="thread_join_timeout_s",
                default=1.0,
                field_type=float,
            ),
        ),
    ),
    # --- validation.plan_item ---
    ConfigSection(
        name="plan_item_validation_config",
        config_path="validation.plan_item",
        fields=(
            SectionField(
                name="max_acceptance_criteria",
                config_key="max_acceptance_criteria",
                default=5,
                field_type=int,
            ),
            SectionField(
                name="max_description_words",
                config_key="max_description_words",
                default=150,
                field_type=int,
            ),
            SectionField(name="max_tasks", config_key="max_tasks", default=8, field_type=int),
            SectionField(name="max_loc", config_key="max_loc", default=400, field_type=int),
            SectionField(
                name="max_files_per_task",
                config_key="max_files_per_task",
                default=5,
                field_type=int,
            ),
        ),
    ),
    # --- api.client ---
    ConfigSection(
        name="api_client_config",
        config_path="api.client",
        fields=(
            SectionField(
                name="default_timeout_s",
                config_key="default_timeout_s",
                default=120,
                field_type=int,
            ),
        ),
    ),
    # --- config_explorer ---
    ConfigSection(
        name="config_explorer_config",
        config_path="config_explorer",
        fields=(
            SectionField(
                name="notification_timeout_s",
                config_key="notification_timeout_s",
                default=10,
                field_type=int,
            ),
        ),
    ),
    # --- derivation.preview ---
    ConfigSection(
        name="derivation_preview_config",
        config_path="derivation.preview",
        fields=(
            SectionField(
                name="readme_limit", config_key="readme_limit", default=2000, field_type=int
            ),
            SectionField(
                name="raw_response_limit",
                config_key="raw_response_limit",
                default=200,
                field_type=int,
            ),
            SectionField(
                name="raw_response_warn_limit",
                config_key="raw_response_warn_limit",
                default=10000,
                field_type=int,
            ),
        ),
    ),
]
