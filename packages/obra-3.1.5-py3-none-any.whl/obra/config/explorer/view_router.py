"""View routing helpers for the config explorer."""

from __future__ import annotations

from typing import Any

from textual.containers import Container, ScrollableContainer, Vertical

from .widgets import Breadcrumb, ConfigTreeView, NavigationMenu, QuickActionsBar, SearchBar


class ViewRouter:
    """Owns menu/view transitions for ``ConfigExplorerApp``."""

    def __init__(self, app: Any) -> None:
        self._app = app

    def remove_custom_views(self) -> None:
        """Remove any mounted custom view widgets."""
        for widget in self._app.query(".custom-view"):
            widget.remove()

    def show_menu(self) -> None:
        """Show the navigation menu and hide the active view."""
        self._app._current_view = "menu"
        self.remove_custom_views()

        try:
            menu_scroll = self._app.query_one("#menu-scroll", ScrollableContainer)
            menu_scroll.display = True
            nav_menu = self._app.query_one("#nav-menu", NavigationMenu)
            nav_menu.focus()
        except Exception:
            pass

        try:
            breadcrumb = self._app.query_one("#breadcrumb", Breadcrumb)
            breadcrumb.display = False
        except Exception:
            pass

        try:
            main = self._app.query_one("#main", Container)
            main.display = False
        except Exception:
            pass

        try:
            self._app.query_one("#quick-actions", QuickActionsBar).display = False
            self._app.query_one("#search", SearchBar).display = False
        except Exception:
            pass

    def show_view(self, entry_point: str) -> None:
        """Show a single explorer entry point."""
        self._app._current_view = entry_point

        try:
            menu_scroll = self._app.query_one("#menu-scroll", ScrollableContainer)
            menu_scroll.display = False
        except Exception:
            pass

        try:
            breadcrumb = self._app.query_one("#breadcrumb", Breadcrumb)
            breadcrumb.display = True
            breadcrumb.set_location(self._app.VIEW_NAMES.get(entry_point, entry_point))
        except Exception:
            pass

        self.remove_custom_views()

        try:
            main = self._app.query_one("#main", Container)
            main.display = True
            self._set_full_config_visibility(show_tree=entry_point == "full_config")

            if entry_point == "full_config":
                tree_view = self._app.query_one("#tree", ConfigTreeView)
                tree_view.focus()
            elif entry_point == "simple_llm":
                self._app._mount_simple_llm_view()
            elif entry_point == "moderate_llm":
                self._app._mount_moderate_llm_view()
            elif entry_point == "custom_llm":
                self._app._mount_custom_llm_view()
            elif entry_point == "runtime_cli":
                self._app._mount_runtime_cli_view()
            elif entry_point == "pipeline":
                self._app._mount_pipeline_options_view()
            elif entry_point == "agents":
                self._app._mount_specialized_agents_view()
            elif entry_point == "validation":
                self._app._mount_validation_tooling_view()
            elif entry_point == "debug_advanced":
                self._app._mount_debug_advanced_view()
            elif entry_point == "personas":
                self._app._mount_persona_view()
            elif entry_point == "domain":
                self._app._mount_domain_view()
            else:
                self._app.notify(
                    f"{self._app.VIEW_NAMES.get(entry_point, entry_point)}: Coming soon"
                )
        except Exception:
            pass

    def _set_full_config_visibility(self, *, show_tree: bool) -> None:
        """Toggle shared widgets for full-config vs custom views."""
        self._app.query_one("#quick-actions", QuickActionsBar).display = show_tree
        self._app.query_one("#search", SearchBar).display = show_tree
        self._app.query_one("#tree-container", Vertical).display = show_tree
        self._app.query_one("#description").display = show_tree
