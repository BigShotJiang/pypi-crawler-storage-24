"""Confirmation Modal widget.

A generic yes/no confirmation dialog for destructive actions.
"""

from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Container, Horizontal
from textual.screen import ModalScreen
from textual.widgets import Button, Label, Static


class ConfirmModal(ModalScreen[bool]):
    """Modal dialog for confirming destructive actions.

    Returns True if confirmed, False/None if cancelled.
    Keyboard: y to confirm, n/Escape to cancel.
    """

    BINDINGS = [
        Binding("y", "confirm", "Yes", priority=True),
        Binding("n", "cancel", "No", priority=True),
        Binding("escape", "cancel", "Cancel", priority=True, show=False),
    ]

    DEFAULT_CSS = """
    ConfirmModal {
        align: center middle;
    }

    ConfirmModal > Container {
        width: 55;
        height: auto;
        background: $surface;
        border: thick $warning;
        padding: 1 2;
    }

    ConfirmModal #title {
        text-style: bold;
        color: $warning;
        margin-bottom: 1;
    }

    ConfirmModal #message {
        margin-bottom: 1;
    }

    ConfirmModal .buttons {
        height: 3;
        align: center middle;
    }

    ConfirmModal Button {
        margin: 0 1;
    }
    """

    def __init__(self, title: str, message: str) -> None:
        """Initialize the confirmation modal.

        Args:
            title: Dialog title (e.g., "Reset All Settings")
            message: Descriptive message explaining the action
        """
        super().__init__()
        self._title = title
        self._message = message

    def compose(self) -> ComposeResult:
        """Create the modal content."""
        with Container():
            yield Label(self._title, id="title")
            yield Static(self._message, id="message")

            with Horizontal(classes="buttons"):
                yield Button("[n] Cancel", variant="default", id="cancel-btn")
                yield Button("[y] Confirm", variant="error", id="confirm-btn")

    def on_mount(self) -> None:
        """Focus the cancel button (safe default)."""
        cancel_button = self.query_one("#cancel-btn", Button)
        cancel_button.focus()

    def action_confirm(self) -> None:
        """Confirm the action."""
        self.dismiss(True)

    def action_cancel(self) -> None:
        """Cancel the action."""
        self.dismiss(False)

    def on_button_pressed(self, event: Button.Pressed) -> None:
        """Handle button clicks."""
        if event.button.id == "confirm-btn":
            self.action_confirm()
        elif event.button.id == "cancel-btn":
            self.action_cancel()
