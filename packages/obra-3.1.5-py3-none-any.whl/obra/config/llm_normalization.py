"""LLM configuration normalization and coercion helpers.

Provides type coercion for config values, normalization of role/tier/reasoning
configuration, and the master ``_normalized_llm_config`` entry point that
produces a fully validated LLM config dict from raw YAML input.

Extracted from obra.config.llm as part of REFACTOR-HIGH-PRIORITY-P10-001.

Example:
    >>> from obra.config.llm_normalization import _normalized_llm_config
    >>> normalized = _normalized_llm_config({"provider": "anthropic"})
"""

import logging
import os
from typing import Any

from obra.config.provider_inference import infer_provider_from_model, validate_model
from obra.config.providers import (
    DEFAULT_AUTH_METHOD,
    DEFAULT_MODEL,
    DEFAULT_PROVIDER,
    LLM_AUTH_METHODS,
    LLM_PROVIDERS,
)
from obra.exceptions import ConfigurationError
from obra.model_registry import REASONING_LEVELS

# Module logger
logger = logging.getLogger(__name__)

# Default reasoning level (ADR-073: unified terminology)
DEFAULT_REASONING_LEVEL = "medium"
DEFAULT_REASONING_SELECTION = "default"

# Anthropic extended thinking budget constraints
# See: https://docs.anthropic.com/en/docs/build-with-claude/extended-thinking
THINKING_BUDGET_MIN = 1024
THINKING_BUDGET_MAX = 128000
DEFAULT_THINKING_BUDGET = 10000


# ---------------------------------------------------------------------------
# Coercion helpers
# ---------------------------------------------------------------------------


def _coerce_provider(raw: Any, path: str) -> str:
    # Allow "per-role" as a special delegation value at top-level llm.provider
    # Allow "per-tier" as a special delegation value at role-level provider
    # (llm.orchestrator.provider, llm.implementation.provider)
    if isinstance(raw, str) and (raw in LLM_PROVIDERS or raw in ("per-role", "per-tier")):
        return raw
    if raw is not None:
        logger.warning(
            "%s invalid or unknown provider '%s', using default '%s'",
            path,
            raw,
            DEFAULT_PROVIDER,
        )
    return DEFAULT_PROVIDER


def _coerce_auth_method(raw: Any, path: str) -> str:
    if isinstance(raw, str) and raw in LLM_AUTH_METHODS:
        return raw
    if raw is not None:
        logger.warning(
            "%s invalid auth_method '%s', using default '%s'",
            path,
            raw,
            DEFAULT_AUTH_METHOD,
        )
    return DEFAULT_AUTH_METHOD


def _coerce_reasoning_level(raw: Any, path: str) -> str:
    if isinstance(raw, str) and raw in (*REASONING_LEVELS, DEFAULT_REASONING_SELECTION):
        return raw
    if raw is not None:
        logger.warning(
            "%s invalid reasoning_level '%s', using default '%s'",
            path,
            raw,
            DEFAULT_REASONING_LEVEL,
        )
    return DEFAULT_REASONING_LEVEL


def _coerce_optional_reasoning_level(raw: Any, path: str) -> str | None:
    if raw is None:
        return None
    # YAML gotcha: 'off' is parsed as boolean False, 'on' as True
    # Handle this gracefully by converting False -> "off"
    if raw is False:
        return "off"
    if raw is True:
        return "maximum"  # Reasonable interpretation of 'on'
    if isinstance(raw, str):
        stripped = raw.strip()
        if not stripped or stripped == "null":
            return None
        if stripped in REASONING_LEVELS:
            return stripped
    logger.warning(
        "%s invalid reasoning level '%s', using null",
        path,
        raw,
    )
    return None


def _coerce_model(raw: Any, provider: str, path: str) -> str:
    model_value = raw if isinstance(raw, str) and raw.strip() else DEFAULT_MODEL
    try:
        return validate_model(model_value, provider)
    except ValueError as exc:
        logger.warning(
            "%s invalid model '%s' for provider '%s': %s. Using default.",
            path,
            model_value,
            provider,
            exc,
        )
        return DEFAULT_MODEL


def _coerce_bool(raw: Any, default: bool) -> bool:
    if isinstance(raw, bool):
        return raw
    return default


def _coerce_string_list(raw: Any, path: str) -> list[str]:
    """Coerce a config value to a de-duplicated string list.

    Invalid entries are ignored with warnings. Empty strings are dropped.
    """
    if raw is None:
        return []
    if not isinstance(raw, list):
        logger.warning("%s must be a list of strings; ignoring value '%s'", path, raw)
        return []

    normalized: list[str] = []
    seen: set[str] = set()
    for idx, item in enumerate(raw):
        if not isinstance(item, str):
            logger.warning("%s[%d] must be a string; ignoring value '%s'", path, idx, item)
            continue
        feature = item.strip()
        if not feature:
            continue
        if feature in seen:
            continue
        seen.add(feature)
        normalized.append(feature)
    return normalized


def _coerce_thinking_budget(raw: Any, path: str) -> int | None:
    """Coerce thinking_budget to valid int or None.

    Args:
        raw: Raw value from config (int, str, or None)
        path: Config path for logging

    Returns:
        Valid budget int (1024-128000) or None for provider default
    """
    if raw is None:
        return None
    if isinstance(raw, str):
        stripped = raw.strip().lower()
        if not stripped or stripped == "null":
            return None
        try:
            raw = int(stripped)
        except ValueError:
            logger.warning("%s invalid thinking_budget '%s', using null", path, raw)
            return None
    if isinstance(raw, int):
        if raw < THINKING_BUDGET_MIN:
            logger.warning(
                "%s thinking_budget %d below minimum %d, using minimum",
                path,
                raw,
                THINKING_BUDGET_MIN,
            )
            return THINKING_BUDGET_MIN
        if raw > THINKING_BUDGET_MAX:
            logger.warning(
                "%s thinking_budget %d above maximum %d, using maximum",
                path,
                raw,
                THINKING_BUDGET_MAX,
            )
            return THINKING_BUDGET_MAX
        return raw
    logger.warning("%s invalid thinking_budget type %s, using null", path, type(raw).__name__)
    return None


# ---------------------------------------------------------------------------
# Normalization functions
# ---------------------------------------------------------------------------

# Tier names are used by several normalizers; import-safe constant.
TIER_NAMES: tuple[str, str, str] = ("fast", "medium", "high")


def _normalize_reasoning_bounds(
    raw_bounds: Any,
    *,
    tier: str,
) -> dict[str, str | None]:
    if not isinstance(raw_bounds, dict):
        raw_bounds = {}
    min_level = _coerce_optional_reasoning_level(
        raw_bounds.get("min_level"),
        f"llm.reasoning.tiers.{tier}.min_level",
    )
    max_level = _coerce_optional_reasoning_level(
        raw_bounds.get("max_level"),
        f"llm.reasoning.tiers.{tier}.max_level",
    )
    return {
        "min_level": min_level,
        "max_level": max_level,
    }


def _normalize_reasoning_config(raw_llm: dict[str, Any]) -> dict[str, Any]:
    raw_reasoning = raw_llm.get("reasoning", {})
    if not isinstance(raw_reasoning, dict):
        raw_reasoning = {}
    force_level = _coerce_optional_reasoning_level(
        raw_reasoning.get("force_level"),
        "llm.reasoning.force_level",
    )
    strict_mode = _coerce_bool(raw_reasoning.get("strict_mode"), False)
    raw_tiers = raw_reasoning.get("tiers", {})
    if not isinstance(raw_tiers, dict):
        raw_tiers = {}
    tiers = {}
    for tier in TIER_NAMES:
        tiers[tier] = _normalize_reasoning_bounds(raw_tiers.get(tier, {}), tier=tier)
    return {
        "force_level": force_level,
        "strict_mode": strict_mode,
        "tiers": tiers,
    }


def _base_llm_defaults(raw_llm: dict[str, Any]) -> dict[str, Any]:
    provider = _coerce_provider(raw_llm.get("provider", DEFAULT_PROVIDER), "llm.provider")
    auth_method = _coerce_auth_method(
        raw_llm.get("auth_method", DEFAULT_AUTH_METHOD),
        "llm.auth_method",
    )
    reasoning_level = _coerce_reasoning_level(
        raw_llm.get("reasoning_level", DEFAULT_REASONING_LEVEL),
        "llm.reasoning_level",
    )
    thinking_budget = _coerce_thinking_budget(raw_llm.get("thinking_budget"), "llm.thinking_budget")
    model = _coerce_model(raw_llm.get("model", DEFAULT_MODEL), provider, "llm.model")
    return {
        "provider": provider,
        "auth_method": auth_method,
        "model": model,
        "reasoning_level": reasoning_level,
        "thinking_budget": thinking_budget,
        "parse_retry_enabled": _coerce_bool(raw_llm.get("parse_retry_enabled", True), True),
        "parse_retry_providers": raw_llm.get("parse_retry_providers"),
        "parse_retry_models": raw_llm.get("parse_retry_models"),
        "reasoning": _normalize_reasoning_config(raw_llm),
    }


def _normalize_role_config(
    raw_role: Any, base_defaults: dict[str, Any], role: str
) -> dict[str, Any]:
    if not isinstance(raw_role, dict):
        raw_role = {}
    provider = _coerce_provider(
        raw_role.get("provider", base_defaults["provider"]),
        f"llm.{role}.provider",
    )
    auth_method = _coerce_auth_method(
        raw_role.get("auth_method", base_defaults["auth_method"]),
        f"llm.{role}.auth_method",
    )
    reasoning_level = _coerce_reasoning_level(
        raw_role.get("reasoning_level", base_defaults["reasoning_level"]),
        f"llm.{role}.reasoning_level",
    )
    # Role can override thinking_budget; if not set, inherit from base
    raw_budget = raw_role.get("thinking_budget")
    if raw_budget is not None:
        thinking_budget = _coerce_thinking_budget(raw_budget, f"llm.{role}.thinking_budget")
    else:
        thinking_budget = base_defaults.get("thinking_budget")
    model = _coerce_model(
        raw_role.get("model", base_defaults["model"]),
        provider,
        f"llm.{role}.model",
    )
    role_defaults = {
        "provider": provider,
        "auth_method": auth_method,
        "model": model,
        "reasoning_level": reasoning_level,
        "thinking_budget": thinking_budget,
        "parse_retry_enabled": _coerce_bool(
            raw_role.get("parse_retry_enabled", base_defaults["parse_retry_enabled"]),
            base_defaults["parse_retry_enabled"],
        ),
        "parse_retry_providers": raw_role.get(
            "parse_retry_providers", base_defaults["parse_retry_providers"]
        ),
        "parse_retry_models": raw_role.get(
            "parse_retry_models", base_defaults["parse_retry_models"]
        ),
    }

    # Normalize role-specific tiers using role-aware defaults
    raw_tiers = raw_role.get("tiers")
    normalized_tiers = _normalize_role_tiers(raw_tiers, provider, role, role_defaults)

    return {
        "provider": role_defaults["provider"],
        "auth_method": role_defaults["auth_method"],
        "model": role_defaults["model"],
        "reasoning_level": role_defaults["reasoning_level"],
        "thinking_budget": role_defaults["thinking_budget"],
        "parse_retry_enabled": role_defaults["parse_retry_enabled"],
        "parse_retry_providers": role_defaults["parse_retry_providers"],
        "parse_retry_models": role_defaults["parse_retry_models"],
        "tiers": normalized_tiers,
    }


def _normalize_tier_entry(
    tier: str, value: Any, base_defaults: dict[str, Any]
) -> dict[str, Any] | None:
    if value is None:
        return None

    if isinstance(value, str):
        # "default" means "resolve from provider tier defaults" -- return None
        # so _normalize_role_tiers falls through to provider_defaults lookup
        if value in ("default", "per-tier", "per-role"):
            return None
        provider_guess = infer_provider_from_model(value) or base_defaults["provider"]
        return {
            "provider": provider_guess,
            "auth_method": base_defaults["auth_method"],
            "model": _coerce_model(value, provider_guess, f"llm.tiers.{tier}.model"),
            "reasoning_level": base_defaults["reasoning_level"],
        }

    if isinstance(value, dict):
        provider = _coerce_provider(
            value.get("provider", base_defaults["provider"]),
            f"llm.tiers.{tier}.provider",
        )
        auth_method = _coerce_auth_method(
            value.get("auth_method", base_defaults["auth_method"]),
            f"llm.tiers.{tier}.auth_method",
        )
        reasoning_level = _coerce_reasoning_level(
            value.get("reasoning_level", base_defaults["reasoning_level"]),
            f"llm.tiers.{tier}.reasoning_level",
        )
        model_value = value.get("model", base_defaults["model"])
        return {
            "provider": provider,
            "auth_method": auth_method,
            "model": _coerce_model(model_value, provider, f"llm.tiers.{tier}.model"),
            "reasoning_level": reasoning_level,
        }

    msg = f"Invalid llm.tiers.{tier} entry: expected string or mapping, got {type(value).__name__}."
    raise ConfigurationError(
        msg,
        f"Set llm.tiers.{tier} to a model shortcut or a mapping with provider/model.",
    )


def _normalize_role_tiers(
    raw_tiers: Any, provider: str, role: str, base_defaults: dict[str, Any]
) -> dict[str, dict[str, Any]]:
    """Normalize tier configuration for a specific role.

    Uses role-aware tier defaults as primary fallback, then provider-specific tier
    defaults when tiers are not explicitly configured.

    Args:
        raw_tiers: Raw tiers dict from config (e.g., {fast: haiku, medium: sonnet})
        provider: Provider name for this role (anthropic, openai, google, ollama)
        role: Role name (orchestrator, implementation)
        base_defaults: Base config defaults for fallback (provider, auth_method, etc.)

    Returns:
        Dict mapping tier names to normalized config dicts with provider, model, etc.
        Falls back to ROLE_TIER_DEFAULTS then PROVIDER_TIER_DEFAULTS for the provider.

    Example:
        >>> _normalize_role_tiers({"fast": "haiku"}, "anthropic", "orchestrator", base_defaults)
        {
            "fast": {"provider": "anthropic", "model": "haiku", ...},
            "medium": {"provider": "anthropic", "model": "opus", ...},  # from defaults
            "high": {"provider": "anthropic", "model": "opus", ...}     # from defaults
        }
    """
    # Lazy import to avoid circular dependency -- these are _RuntimeRefreshDict
    # instances that live in obra.config.llm_compat and depend on runtime config loaders.
    from obra.config.llm_compat import PROVIDER_TIER_DEFAULTS, ROLE_TIER_DEFAULTS

    if raw_tiers is None:
        raw_tiers = {}
    if not isinstance(raw_tiers, dict):
        raw_tiers = {}

    # Get role-aware tier defaults, falling back to role-agnostic provider defaults
    role_tier_defaults = ROLE_TIER_DEFAULTS.get(provider, {}).get(role, {})
    provider_defaults = PROVIDER_TIER_DEFAULTS.get(provider, {})

    normalized: dict[str, dict[str, Any]] = {}
    for tier_name in TIER_NAMES:
        # Check if tier is explicitly configured
        if tier_name in raw_tiers:
            entry = _normalize_tier_entry(tier_name, raw_tiers[tier_name], base_defaults)
            if entry:
                normalized[tier_name] = entry
        else:
            # Try role-aware defaults first, then role-agnostic
            default_model = role_tier_defaults.get(tier_name) or provider_defaults.get(tier_name)
            if default_model and default_model != "default":
                normalized[tier_name] = {
                    "provider": provider,
                    "auth_method": base_defaults["auth_method"],
                    "model": _coerce_model(default_model, provider, f"llm.{tier_name}.model"),
                    "reasoning_level": base_defaults["reasoning_level"],
                }

    return normalized


def _normalize_tiers(raw_tiers: Any, base_defaults: dict[str, Any]) -> dict[str, dict[str, Any]]:
    if raw_tiers is None:
        return {}
    if not isinstance(raw_tiers, dict):
        msg = "Invalid llm.tiers section in ~/.obra/config-layers/01-user.yaml."
        raise ConfigurationError(
            msg,
            "Set llm.tiers to a mapping like {fast: haiku, medium: sonnet, high: opus}.",
        )

    normalized: dict[str, dict[str, Any]] = {}
    for tier_name in TIER_NAMES:
        if tier_name not in raw_tiers:
            continue
        entry = _normalize_tier_entry(tier_name, raw_tiers[tier_name], base_defaults)
        if entry:
            normalized[tier_name] = entry
    return normalized


def _get_env_tier_override(tier: str) -> str | None:
    env_value = os.environ.get(f"OBRA_{tier.upper()}_MODEL")
    if not env_value:
        return None
    stripped = env_value.strip()
    return stripped or None


def _normalized_llm_config(raw_llm: dict[str, Any]) -> dict[str, Any]:
    base_defaults = _base_llm_defaults(raw_llm)
    raw_roles = raw_llm.get("roles", {})
    raw_profiles = raw_llm.get("profiles", {})
    roles = raw_roles if isinstance(raw_roles, dict) else {}
    profiles = raw_profiles if isinstance(raw_profiles, dict) else {}

    return {
        "provider": base_defaults["provider"],
        "auth_method": base_defaults["auth_method"],
        "model": base_defaults["model"],
        "reasoning_level": base_defaults["reasoning_level"],
        "parse_retry_enabled": base_defaults["parse_retry_enabled"],
        "parse_retry_providers": base_defaults["parse_retry_providers"],
        "parse_retry_models": base_defaults["parse_retry_models"],
        "reasoning": base_defaults["reasoning"],
        "roles": roles,
        "profiles": profiles,
        "orchestrator": _normalize_role_config(
            raw_llm.get("orchestrator", {}),
            base_defaults,
            "orchestrator",
        ),
        "implementation": _normalize_role_config(
            raw_llm.get("implementation", {}), base_defaults, "implementation"
        ),
    }
