"""Planning configuration loading for Obra.

Loads project-level planning configuration (permissive mode, domain overrides)
from the layered config system.
"""

import logging
from pathlib import Path
from typing import Any

import yaml

from obra.exceptions import ConfigurationError

from .loaders import get_project_layer_path

logger = logging.getLogger(__name__)


def get_project_planning_config(project_path: Path | None) -> dict[str, Any]:
    """Load planning configuration from project-level config layer.

    Args:
        project_path: Base project path (repo root preferred)

    Returns:
        Dictionary with planning config values (empty if not set)

    Raises:
        ConfigurationError: If the planning section is malformed
    """
    if project_path is None:
        return {}

    from obra.intent.storage import IntentStorage

    project_id = IntentStorage().get_project_id(project_path)
    config_path = get_project_layer_path(project_id)
    if not config_path.exists():
        return {}

    try:
        with config_path.open(encoding="utf-8") as config_file:
            raw_config = yaml.safe_load(config_file) or {}
    except yaml.YAMLError as exc:
        msg = f"Invalid YAML in {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Fix the YAML syntax in the project config layer and try again.",
        ) from exc
    except OSError as exc:
        msg = f"Unable to read {config_path}: {exc}"
        raise ConfigurationError(
            msg,
            "Check file permissions for the project config layer and retry.",
        ) from exc

    planning_section = raw_config.get("planning")
    if planning_section is None:
        return {}
    if not isinstance(planning_section, dict):
        logger.warning(
            "Ignoring invalid planning section in %s (expected mapping).",
            config_path,
        )
        return {}

    config: dict[str, Any] = {}
    perm_value = planning_section.get("permissive_mode")
    if perm_value is not None:
        if not isinstance(perm_value, bool):
            logger.warning(
                "Ignoring invalid planning.permissive_mode in %s (expected boolean).",
                config_path,
            )
        else:
            config["permissive_mode"] = perm_value

    domain_value = planning_section.get("domain")
    if domain_value is not None:
        if not isinstance(domain_value, str) or not domain_value.strip():
            logger.warning(
                "Ignoring invalid planning.domain in %s (expected non-empty string).",
                config_path,
            )
        else:
            config["domain"] = domain_value.strip()

    # Backward compatibility: allow top-level domain key if present
    if "domain" not in config and isinstance(raw_config.get("domain"), str):
        domain_top = raw_config["domain"].strip()
        if domain_top:
            config["domain"] = domain_top

    return config
