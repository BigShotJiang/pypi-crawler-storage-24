"""Human-readable LLM display helpers."""

from __future__ import annotations

from obra.config.llm_normalization import DEFAULT_REASONING_LEVEL
from obra.config.providers import DEFAULT_PROVIDER, LLM_PROVIDERS
from obra.config.reasoning_selection import REASONING_LEVEL_MAP


def get_llm_display(role: str) -> str:
    """Get a human-readable display string for resolved role config."""
    from obra.config.llm import resolve_llm_config

    resolved = resolve_llm_config(role)
    provider = resolved.get("provider", DEFAULT_PROVIDER)
    auth_method = resolved.get("auth_method", "oauth")
    model = resolved.get("model", "default")

    provider_name = LLM_PROVIDERS.get(provider, {}).get("name", provider)
    auth_name = "OAuth" if auth_method == "oauth" else "API Key"
    return f"{provider_name} ({auth_name}, {model})"


def get_reasoning_keyword(resolved_config: dict[str, str]) -> str | None:
    """Get the prompt keyword to prepend for providers that support it."""
    provider = resolved_config.get("provider", DEFAULT_PROVIDER)
    reasoning_level = resolved_config.get("reasoning_level", DEFAULT_REASONING_LEVEL)

    provider_map = REASONING_LEVEL_MAP.get(provider, {})
    keyword = provider_map.get(reasoning_level)
    if provider == "anthropic" and isinstance(keyword, str) and keyword:
        return keyword
    return None
