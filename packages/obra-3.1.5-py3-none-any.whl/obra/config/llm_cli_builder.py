"""CLI builder helpers extracted from obra.config.llm."""

from __future__ import annotations

import shutil
import warnings
from pathlib import Path

from obra.config.providers import DEFAULT_PROVIDER, LLM_PROVIDERS

_DEPRECATION_WARNED = False


def build_llm_args(
    resolved_config: dict[str, str],
    mode: str = "text",
    response_format: str = "json",
) -> list[str]:
    """Build CLI arguments from resolved LLM configuration."""
    global _DEPRECATION_WARNED
    if not _DEPRECATION_WARNED:
        warnings.warn(
            "build_llm_args() is deprecated. Use build_command_spec() -> "
            "build_provider_spec() pipeline for typed execution.",
            DeprecationWarning,
            stacklevel=2,
        )
        _DEPRECATION_WARNED = True

    from obra.execution.os_compat import resolve_profile
    from obra.execution.spec_builder import build_command_spec, build_provider_spec

    cmd_spec = build_command_spec(
        config=resolved_config,
        mode=mode,
        response_format=response_format,
        cwd=Path("."),
        streaming=False,
        timeout_s=0,
        auth_method="api_key",
    )
    profile = resolve_profile(provider=resolved_config.get("provider", DEFAULT_PROVIDER))
    provider_spec = build_provider_spec(cmd_spec, profile)
    return provider_spec.argv


def get_llm_cli(provider: str = DEFAULT_PROVIDER) -> str:
    """Get the CLI executable path for a provider."""
    provider_info = LLM_PROVIDERS.get(provider, LLM_PROVIDERS[DEFAULT_PROVIDER])
    cli_name = str(provider_info.get("cli", "claude"))
    cli_path = shutil.which(cli_name)
    return cli_path or cli_name
