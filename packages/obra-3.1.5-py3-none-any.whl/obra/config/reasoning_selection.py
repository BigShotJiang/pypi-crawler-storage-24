"""Reasoning level selection and resolution for LLM invocations.

Provides the ``ReasoningSelection`` dataclass, the ``resolve_reasoning_selection``
entry point, and helper functions for mapping abstract reasoning levels to
provider-specific values (thinking parameters, effort levels, etc.).

Extracted from obra.config.llm as part of REFACTOR-HIGH-PRIORITY-P10-001.

Example:
    >>> from obra.config.reasoning_selection import resolve_reasoning_selection
    >>> sel = resolve_reasoning_selection(
    ...     provider="openai", model="gpt-5.2",
    ...     stage_level="high", user_forced_level=None,
    ...     tier_min_level=None, tier_max_level=None,
    ... )
    >>> sel.normalized_level
    'high'
"""

import logging
from dataclasses import dataclass
from typing import Any

from obra.config.llm_normalization import (
    DEFAULT_REASONING_LEVEL,
    DEFAULT_REASONING_SELECTION,
    DEFAULT_THINKING_BUDGET,
    _coerce_optional_reasoning_level,
)
from obra.exceptions import ConfigurationError
from obra.model_registry import REASONING_LEVELS, get_reasoning_profile

# Module logger
logger = logging.getLogger(__name__)

# Provider-specific reasoning level mappings
# See docs/reference/llm-providers/ for official documentation
# NOTE: REASONING_LEVEL_MAP is intentionally NOT migrated to config. It defines
# a domain rule (provider capability mapping) rather than user-configurable values.
# Modifying this requires code changes to handle new reasoning levels.
REASONING_LEVEL_MAP: dict[str, dict[str, str | None]] = {
    "anthropic": {
        # Anthropic provider-level effort mapping lives in model_registry.py
        # (used by resolve_reasoning_selection -> provider_reasoning_level).
        # This map intentionally remains None-only for prompt-keyword behavior.
        "off": None,
        "low": None,
        "medium": None,
        "high": None,
        "maximum": None,
    },
    "openai": {
        # Codex CLI model_reasoning_effort values
        # See: docs/reference/llm-providers/openai-codex-reasoning.md
        "off": "low",  # Codex CLI floor - Obra "off" clamps to low
        "low": "low",
        "medium": "medium",  # Default
        "high": "high",
        "extra high": "xhigh",
        "maximum": "xhigh",  # Supported by OpenAI models listed in llm.xhigh_supported_models
    },
    "google": {
        # Gemini CLI - no reasoning effort control available
        "off": None,
        "low": None,
        "medium": None,
        "high": None,
        "maximum": None,
    },
}


def _materialize_default_reasoning_level(
    provider: str,
    model: str | None,
    reasoning_level: str | None,
    *,
    role: str | None = None,
    tier: str | None = None,
) -> str:
    """Resolve "default" reasoning selection to a concrete normalized level."""
    if reasoning_level and reasoning_level != DEFAULT_REASONING_SELECTION:
        return reasoning_level
    profile = get_reasoning_profile(provider, model, role=role, tier=tier)
    return profile.default_level


def get_reasoning_level_notes(
    provider: str,
    reasoning_level: str,
    model: str | None = None,
) -> list[str]:
    """Get user-facing notes about reasoning level behavior for a provider.

    Provides feedback about how the selected reasoning level maps to
    provider-specific behavior, including limitations and recommendations.

    Note: Anthropic effort crosswalk is handled in the typed pipeline via
    model_registry/provider specs, so this helper remains note-light for
    Anthropic to avoid noisy provider-specific messaging.

    Args:
        provider: LLM provider name
        reasoning_level: Abstract reasoning level (off, low, medium, high, extra high, maximum)
        model: Optional model name for model-specific notes

    Returns:
        List of note strings to display to the user

    Examples:
        >>> get_reasoning_level_notes("anthropic", "maximum")
        []

        >>> get_reasoning_level_notes("google", "high")
        ['Gemini CLI does not support reasoning effort control']

        >>> get_reasoning_level_notes("openai", "maximum", "gpt-5.1")
        ['xhigh reasoning not supported on gpt-5.1, using "high" instead']
        >>> get_reasoning_level_notes("openai", "extra high", "gpt-5.2")
        ['Using xhigh reasoning effort for maximum analysis']
    """
    # Lazy import to avoid circular dependency: XHIGH_SUPPORTED_MODELS is a
    # _RuntimeRefreshDict that lives in obra.config.llm_compat.
    from obra.config.llm_compat import XHIGH_SUPPORTED_MODELS

    notes: list[str] = []
    effective_level = _materialize_default_reasoning_level(provider, model, reasoning_level)

    # Provider-specific notes
    # Note: Anthropic notes are intentionally omitted here; effort mapping is
    # handled in the typed subprocess pipeline.

    if provider == "openai":
        # Check xhigh support
        if effective_level in {"extra high", "maximum"}:
            supported = XHIGH_SUPPORTED_MODELS.get("openai", set())
            if model and model not in supported:
                notes.append(f'xhigh reasoning not supported on {model}, using "high" instead')
                notes.append(f"For xhigh, use: {', '.join(sorted(supported))}")
            else:
                notes.append("Using xhigh reasoning effort for maximum analysis")

    elif provider == "google" and effective_level != "off":
        notes.append("Gemini CLI does not support reasoning effort control")

    return notes


def get_effective_reasoning_value(
    provider: str,
    reasoning_level: str,
    model: str | None = None,
) -> str | None:
    """Get the effective provider-specific reasoning value with fallback.

    Maps abstract reasoning level to provider-specific value, applying
    fallback logic for unsupported configurations (e.g., xhigh -> high
    for OpenAI models that don't support xhigh).

    Args:
        provider: LLM provider name
        reasoning_level: Abstract reasoning level (off, low, medium, high, extra high, maximum)
        model: Optional model name for model-specific fallback

    Returns:
        Provider-specific reasoning value (e.g., "xhigh", "high")
        or None if the provider doesn't support the level

    Examples:
        >>> get_effective_reasoning_value("openai", "maximum", "gpt-5.2")
        'xhigh'
        >>> get_effective_reasoning_value("openai", "extra high", "gpt-5.2")
        'xhigh'
        >>> get_effective_reasoning_value("openai", "maximum", "gpt-5.1")
        'high'  # Fallback - xhigh not supported
        >>> get_effective_reasoning_value("anthropic", "maximum")
        None
        >>> get_effective_reasoning_value("google", "high")
        None  # No reasoning control
    """
    # Lazy import to avoid circular dependency: XHIGH_SUPPORTED_MODELS is a
    # _RuntimeRefreshDict that lives in obra.config.llm_compat.
    from obra.config.llm_compat import XHIGH_SUPPORTED_MODELS

    effective_level = _materialize_default_reasoning_level(provider, model, reasoning_level)

    if provider == "anthropic":
        return None
    if provider == "google":
        return None
    if provider != "openai":
        profile = get_reasoning_profile(provider, model)
        return profile.level_map.get(effective_level)

    if effective_level == "off":
        return "minimal"

    if effective_level in {"extra high", "maximum"}:
        supported_xhigh = XHIGH_SUPPORTED_MODELS.get("openai", set())
        if model and model not in supported_xhigh:
            effective_level = "high"

    profile = get_reasoning_profile(provider, model)
    supported_levels = profile.supported_levels

    if effective_level not in supported_levels:
        level_order = {level: idx for idx, level in enumerate(REASONING_LEVELS)}
        supported_sorted = sorted(supported_levels, key=lambda x: level_order.get(x, 0))
        lower_levels = [
            level for level in supported_sorted if level_order[level] <= level_order[effective_level]
        ]
        effective_level = lower_levels[-1] if lower_levels else supported_sorted[0]

    openai_level_map = {
        "low": "low",
        "medium": "medium",
        "high": "high",
        "extra high": "xhigh",
        "maximum": "xhigh",
    }
    return openai_level_map.get(effective_level)


def get_anthropic_api_thinking_param(
    thinking_level: str,
    thinking_budget: int | None = None,
) -> dict[str, Any] | None:
    """Build Anthropic API thinking parameter for extended thinking.

    This function is for future API path integration. Currently Obra uses
    CLI only, where thinking control is not available. When API path is
    added, this function provides the correctly formatted thinking parameter.

    Args:
        thinking_level: Abstract thinking level ("off" = disabled, else enabled)
        thinking_budget: Token budget for thinking (1024-128000); None = default

    Returns:
        Dict for API ``thinking`` parameter, or None if thinking disabled

    Examples:
        >>> get_anthropic_api_thinking_param("off")
        None
        >>> get_anthropic_api_thinking_param("medium")
        {'type': 'enabled', 'budget_tokens': 10000}
        >>> get_anthropic_api_thinking_param("high", 32000)
        {'type': 'enabled', 'budget_tokens': 32000}

    See:
        https://docs.anthropic.com/en/docs/build-with-claude/extended-thinking
    """
    if thinking_level == "off":
        return None
    budget = thinking_budget if thinking_budget is not None else DEFAULT_THINKING_BUDGET
    return {"type": "enabled", "budget_tokens": budget}


@dataclass(frozen=True)
class ReasoningSelection:
    """Resolved reasoning selection for an invocation."""

    normalized_level: str
    provider_level: str | None
    source: str
    clamped: bool
    clamp_reason: str | None
    supported_levels: list[str]
    default_level: str


def resolve_reasoning_selection(
    *,
    provider: str,
    model: str | None,
    stage_level: str | None,
    user_forced_level: str | None,
    tier_min_level: str | None,
    tier_max_level: str | None,
    cli_override: str | None = None,
    strict_mode: bool = False,
    role: str | None = None,
    tier: str | None = None,
) -> ReasoningSelection:
    """Resolve the effective reasoning level for an invocation.

    Precedence: CLI override > user forced > stage default > model default.
    Clamping: user tier min/max, then provider/model capability.

    Args:
        provider: Provider name (anthropic, openai, google, ollama)
        model: Model identifier (or None for provider default)
        stage_level: Stage default reasoning level
        user_forced_level: User forced reasoning level
        tier_min_level: User min level for the selected tier
        tier_max_level: User max level for the selected tier
        cli_override: CLI-provided override (highest priority)
        strict_mode: If true, unsupported levels raise ConfigurationError
        role: Optional role context (orchestrator, implementation)
        tier: Optional tier context (fast, medium, high)

    Returns:
        ReasoningSelection with normalized and provider-specific values.
    """
    level_order = {level: idx for idx, level in enumerate(REASONING_LEVELS)}

    def _validate_level(level: str | None, label: str, *, allow_default: bool = False) -> None:
        if level is None:
            return
        valid_levels = set(REASONING_LEVELS)
        if allow_default:
            valid_levels.add(DEFAULT_REASONING_SELECTION)
        if level not in valid_levels:
            msg = (
                f"Invalid reasoning level for {label}: {level}. "
                f"Valid: {', '.join(sorted(valid_levels))}"
            )
            raise ConfigurationError(msg)

    _validate_level(stage_level, "stage", allow_default=True)
    _validate_level(user_forced_level, "user_force", allow_default=True)
    _validate_level(tier_min_level, "tier_min")
    _validate_level(tier_max_level, "tier_max")
    _validate_level(cli_override, "cli_override", allow_default=True)

    if tier_min_level and tier_max_level:
        if level_order[tier_min_level] > level_order[tier_max_level]:
            msg = (
                f"Invalid tier reasoning bounds: min '{tier_min_level}' "
                f"is higher than max '{tier_max_level}'."
            )
            raise ConfigurationError(msg)

    profile = get_reasoning_profile(provider, model, role=role, tier=tier)
    default_level = profile.default_level

    selected_raw = cli_override or user_forced_level or stage_level
    selected_level = (
        default_level
        if selected_raw in (None, DEFAULT_REASONING_SELECTION)
        else selected_raw
    )
    source = (
        "cli_override"
        if cli_override
        else (
            "user_forced"
            if user_forced_level
            else "stage_default"
            if stage_level
            else "model_default"
        )
    )

    clamped = False
    clamp_reason = None

    if tier_min_level and level_order[selected_level] < level_order[tier_min_level]:
        selected_level = tier_min_level
        clamped = True
        clamp_reason = "tier_min"
    if tier_max_level and level_order[selected_level] > level_order[tier_max_level]:
        selected_level = tier_max_level
        clamped = True
        clamp_reason = "tier_max"

    supported_levels = profile.supported_levels
    if selected_level not in supported_levels:
        supported_sorted = sorted(supported_levels, key=lambda x: level_order.get(x, 0))
        lower_levels = [
            level for level in supported_sorted if level_order[level] <= level_order[selected_level]
        ]
        fallback_level = lower_levels[-1] if lower_levels else supported_sorted[0]
        if strict_mode:
            msg = (
                f"Reasoning level '{selected_level}' is not supported for "
                f"{provider}:{profile.model_id or model or 'default'}."
            )
            raise ConfigurationError(msg)
        selected_level = fallback_level
        clamped = True
        clamp_reason = "provider_unsupported"

    provider_level = profile.level_map.get(selected_level)

    return ReasoningSelection(
        normalized_level=selected_level,
        provider_level=provider_level,
        source=source,
        clamped=clamped,
        clamp_reason=clamp_reason,
        supported_levels=sorted(supported_levels, key=lambda x: level_order.get(x, 0)),
        default_level=default_level,
    )
