"""Browser-session bootstrap helpers for Workflow Studio."""

from __future__ import annotations

import hmac
import secrets
import threading
import time
from collections.abc import Mapping
from typing import Any

from fastapi import HTTPException, Request, Response, WebSocket, status

_SESSION_COOKIE_PATH = "/"
_DEFAULT_SESSION_COOKIE_NAME = "obra_studio_session"
_DEFAULT_SESSION_TTL_S = 900
_DEFAULT_SESSION_COOKIE_SECURE = False
_DEFAULT_LAUNCH_TOKEN_TTL_S = 120


def initialize_studio_browser_state(app_state: Any) -> None:
    """Attach Studio browser-session state to FastAPI app state."""
    if not hasattr(app_state, "studio_browser_sessions"):
        app_state.studio_browser_sessions = {}
    if not hasattr(app_state, "studio_browser_sessions_lock"):
        app_state.studio_browser_sessions_lock = threading.Lock()
    if not hasattr(app_state, "studio_browser_launch_tokens"):
        app_state.studio_browser_launch_tokens = {}
    if not hasattr(app_state, "studio_browser_launch_tokens_lock"):
        app_state.studio_browser_launch_tokens_lock = threading.Lock()


def _gateway_config(app_or_state: Any) -> dict[str, Any]:
    state = getattr(app_or_state, "state", app_or_state)
    return dict(getattr(state, "gateway_config", {}))


def studio_session_cookie_name(app_or_state: Any) -> str:
    return str(
        _gateway_config(app_or_state).get(
            "studio_session_cookie_name",
            _DEFAULT_SESSION_COOKIE_NAME,
        )
    )


def studio_session_ttl_s(app_or_state: Any) -> int:
    return int(
        _gateway_config(app_or_state).get(
            "studio_session_ttl_s",
            _DEFAULT_SESSION_TTL_S,
        )
    )


def studio_session_cookie_secure(app_or_state: Any) -> bool:
    return bool(
        _gateway_config(app_or_state).get(
            "studio_session_cookie_secure",
            _DEFAULT_SESSION_COOKIE_SECURE,
        )
    )


def studio_launch_token_ttl_s(app_or_state: Any) -> int:
    return int(
        _gateway_config(app_or_state).get(
            "studio_launch_token_ttl_s",
            _DEFAULT_LAUNCH_TOKEN_TTL_S,
        )
    )


def _cookies_from_headers(headers: Mapping[str, str]) -> dict[str, str]:
    raw_cookie = headers.get("cookie", "")
    if not raw_cookie.strip():
        return {}
    cookies: dict[str, str] = {}
    for part in raw_cookie.split(";"):
        name, _, value = part.strip().partition("=")
        if name and value:
            cookies[name] = value
    return cookies


def _constant_time_match(provided: str, expected: str) -> bool:
    return bool(provided) and bool(expected) and hmac.compare_digest(provided, expected)


def parse_bearer_token(headers: Mapping[str, str]) -> str | None:
    auth_header = headers.get("authorization", "").strip()
    if not auth_header:
        return None
    scheme, _, credentials = auth_header.partition(" ")
    if scheme.lower() != "bearer" or not credentials.strip():
        return None
    return credentials.strip()


def is_bearer_authenticated(headers: Mapping[str, str], *, expected_token: str) -> bool:
    token = parse_bearer_token(headers)
    if token is None:
        return False
    return _constant_time_match(token, expected_token)


def _cleanup_expired_entries(entries: dict[str, float], lock: threading.Lock, now_s: float) -> None:
    with lock:
        expired = [token for token, expires_at in entries.items() if expires_at <= now_s]
        for token in expired:
            entries.pop(token, None)


def _get_session_cookie_value(request_or_ws: Request | WebSocket) -> str | None:
    cookie_name = studio_session_cookie_name(request_or_ws.app)
    cookies = getattr(request_or_ws, "cookies", None)
    if isinstance(cookies, dict):
        return cookies.get(cookie_name)
    return _cookies_from_headers(request_or_ws.headers).get(cookie_name)


def is_studio_browser_authenticated_request(request: Request) -> bool:
    now_s = time.time()
    sessions: dict[str, float] = getattr(request.app.state, "studio_browser_sessions", {})
    lock: threading.Lock | None = getattr(request.app.state, "studio_browser_sessions_lock", None)
    if lock is None:
        return False
    _cleanup_expired_entries(sessions, lock, now_s)
    session_id = _get_session_cookie_value(request)
    if not session_id:
        return False
    with lock:
        expires_at = sessions.get(session_id)
        if expires_at is None:
            return False
        if expires_at <= now_s:
            sessions.pop(session_id, None)
            return False
    return True


def is_studio_browser_authenticated_websocket(ws: WebSocket) -> bool:
    now_s = time.time()
    sessions: dict[str, float] = getattr(ws.app.state, "studio_browser_sessions", {})
    lock: threading.Lock | None = getattr(ws.app.state, "studio_browser_sessions_lock", None)
    if lock is None:
        return False
    _cleanup_expired_entries(sessions, lock, now_s)
    session_id = _get_session_cookie_value(ws)
    if not session_id:
        return False
    with lock:
        expires_at = sessions.get(session_id)
        if expires_at is None:
            return False
        if expires_at <= now_s:
            sessions.pop(session_id, None)
            return False
    return True


def require_studio_or_bearer_auth(request: Request) -> None:
    expected_token = str(request.app.state.gateway_token)
    if is_bearer_authenticated(request.headers, expected_token=expected_token):
        return
    if is_studio_browser_authenticated_request(request):
        return
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication failed",
    )


def issue_studio_browser_session(response: Response, request: Request) -> None:
    session_id = secrets.token_urlsafe(32)
    expires_at = time.time() + studio_session_ttl_s(request.app)
    sessions: dict[str, float] = request.app.state.studio_browser_sessions
    lock: threading.Lock = request.app.state.studio_browser_sessions_lock
    with lock:
        sessions[session_id] = expires_at

    response.set_cookie(
        key=studio_session_cookie_name(request.app),
        value=session_id,
        max_age=studio_session_ttl_s(request.app),
        httponly=True,
        secure=studio_session_cookie_secure(request.app),
        samesite="strict",
        path=_SESSION_COOKIE_PATH,
    )


def clear_studio_browser_session(response: Response, request: Request) -> None:
    session_id = _get_session_cookie_value(request)
    if session_id:
        sessions: dict[str, float] = request.app.state.studio_browser_sessions
        lock: threading.Lock = request.app.state.studio_browser_sessions_lock
        with lock:
            sessions.pop(session_id, None)

    response.delete_cookie(
        studio_session_cookie_name(request.app),
        path=_SESSION_COOKIE_PATH,
    )


def issue_studio_launch_token(request: Request) -> str:
    token = secrets.token_urlsafe(24)
    expires_at = time.time() + studio_launch_token_ttl_s(request.app)
    launch_tokens: dict[str, float] = request.app.state.studio_browser_launch_tokens
    lock: threading.Lock = request.app.state.studio_browser_launch_tokens_lock
    with lock:
        launch_tokens[token] = expires_at
    return token


def consume_studio_launch_token(request: Request, token: str) -> bool:
    now_s = time.time()
    launch_tokens: dict[str, float] = request.app.state.studio_browser_launch_tokens
    lock: threading.Lock = request.app.state.studio_browser_launch_tokens_lock
    _cleanup_expired_entries(launch_tokens, lock, now_s)
    with lock:
        expires_at = launch_tokens.pop(token, None)
    return expires_at is not None and expires_at > now_s
