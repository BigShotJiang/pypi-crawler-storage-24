"""Streamed assistant response generator (SSE)."""

from __future__ import annotations

import asyncio
import json
import time
from dataclasses import asdict
from typing import TYPE_CHECKING, Any, AsyncIterator

from obra.gateway.workflow_studio.assistant_llm import call_assistant_llm, _stub_fallback_allowed
from obra.gateway.workflow_studio.assistant_repository import (
    AssistantRepository,
    AssistantThread,
    AssistantTurn,
)

if TYPE_CHECKING:
    from obra.gateway.workflow_studio.assistant_session_logger import AssistantSessionLogger


def _sse(event: str, data: dict[str, Any]) -> str:
    return f"event: {event}\ndata: {json.dumps(data)}\n\n"


async def stream_assistant_response(
    thread: AssistantThread,
    user_turn: AssistantTurn,
    resolved_context: dict[str, Any],
    repository: AssistantRepository,
    *,
    system_prompt: str | None = None,
    app_state: Any | None = None,
    session_logger: AssistantSessionLogger | None = None,
    assistant_turn_context: dict[str, Any] | None = None,
) -> AsyncIterator[str]:
    """Yield SSE events for a streamed assistant response."""
    turn_id = user_turn.turn_id

    try:
        # Emit session_info as the very first event
        if thread.session_id is not None:
            yield _sse("session_info", {"session_id": thread.session_id})

        yield _sse("status", {"phase": "resolving_context", "turn_id": turn_id})

        strategy = "contextual"
        if isinstance(resolved_context.get("strategies"), list) and resolved_context["strategies"]:
            strategy = resolved_context["strategies"][0]

        # Emit context manifest for transparency
        manifest = resolved_context.get("context_manifest")
        if manifest is not None:
            manifest_dict = manifest.to_dict() if hasattr(manifest, "to_dict") else manifest
            yield _sse("context_manifest", manifest_dict)

        yield _sse("status", {"phase": "generating", "turn_id": turn_id, "strategy": strategy})

        model_id = resolved_context.get("model_id")

        # Log LLM request
        t0 = time.perf_counter()
        if session_logger is not None:
            session_logger.log_event(
                "asst.llm_request",
                turn_id=turn_id,
                model_id=model_id,
                safety_mode=thread.safety_mode,
                is_stub_fallback=_stub_fallback_allowed(),
                user_message_length=len(user_turn.message),
                system_prompt_length=len(system_prompt or ""),
            )

        llm_response = await call_assistant_llm(
            system_prompt or "You are the Studio Assistant for Obra Workflow Studio.",
            user_turn.message,
            app_state=app_state,
            resolved_context=resolved_context,
            model_id=model_id,
        )
        full_message = llm_response.message
        if not full_message.strip():
            raise RuntimeError("assistant returned empty content")

        # Log LLM response
        duration_ms = int((time.perf_counter() - t0) * 1000)
        if session_logger is not None:
            session_logger.log_event(
                "asst.llm_response",
                turn_id=turn_id,
                response_length=len(full_message),
                outcome=llm_response.outcome,
                action_count=len(llm_response.action_records or []),
                duration_ms=duration_ms,
                is_stub_fallback=_stub_fallback_allowed(),
            )

        chunk_size = 40
        for i in range(0, len(full_message), chunk_size):
            chunk = full_message[i : i + chunk_size]
            yield _sse("token", {"text": chunk})
            await asyncio.sleep(0)

        assistant_turn = repository.append_turn(
            thread.thread_id,
            role="assistant",
            message=full_message,
            context=assistant_turn_context,
            outcome=llm_response.outcome,
            action_records=llm_response.action_records,
        )

        # Log turn completed
        if session_logger is not None:
            session_logger.log_event(
                "asst.turn_completed",
                turn_id=assistant_turn.turn_id,
                role="assistant",
                message=full_message,
                outcome=llm_response.outcome,
                action_records=llm_response.action_records,
            )

        yield _sse("done", {
            "turn": asdict(assistant_turn),
            "session_id": thread.session_id,
        })

    except Exception as exc:
        # Log turn error
        if session_logger is not None:
            session_logger.log_event(
                "asst.turn_error",
                turn_id=turn_id,
                error_type=type(exc).__name__,
                error_detail=str(exc),
            )

        yield _sse(
            "error",
            {
                "error": "generation_failed",
                "detail": str(exc),
                "turn_id": turn_id,
            },
        )
