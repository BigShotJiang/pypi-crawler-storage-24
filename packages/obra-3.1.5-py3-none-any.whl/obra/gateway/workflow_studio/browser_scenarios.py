"""Deterministic browser automation scenarios for Workflow Studio."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any


@dataclass(frozen=True)
class RunScenario:
    scenario_id: str
    run_id: str
    workflow_id: str
    revision_id: str
    domain_id: str
    objective: str
    artifact_title: str
    stage_bindings: list[dict[str, Any]]
    lifecycle_decisions: dict[str, Any]
    status: str = "completed"
    blocking_summary: dict[str, Any] = field(default_factory=dict)
    remote_phase: str = "execution"
    remote_updated_at: str = "2026-03-08T01:50:00+00:00"
    remote_events: list[dict[str, Any]] = field(default_factory=list)
    checkpoint_id: str | None = None
    escalation_id: str | None = None
    remote_session_overrides: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class DerivationScenario:
    scenario_id: str
    run_id: str
    derivation_id: str
    workflow_id: str
    revision_id: str
    domain_id: str
    mission: str
    validation_outcome: str
    issue_codes: list[str]
    checkpoint_state: dict[str, Any]
    lifecycle_decisions: dict[str, Any]
    accepted_revision_ref: dict[str, Any] | None = None


@dataclass(frozen=True)
class WorkflowScenario:
    scenario_id: str
    workflow_id: str
    revision_id: str


@dataclass(frozen=True)
class BrowserScenarioCatalog:
    run_scenarios: list[RunScenario]
    derivation_scenarios: list[DerivationScenario]
    workflow_scenarios: list[WorkflowScenario]


SCENARIO_IDS = {
    "run_completed_software": "run_completed_software",
    "run_artifact_divergence": "run_artifact_divergence",
    "run_blocked_operator": "run_blocked_operator",
    "run_escalation_pending": "run_escalation_pending",
    "run_replay_failure": "run_replay_failure",
    "derivation_pending_review": "derivation_pending_review",
    "derivation_revision_required": "derivation_revision_required",
    "workflow_edit_conflict": "workflow_edit_conflict",
    "workflow_edit_rich_baseline": "workflow_edit_rich_baseline",
}


def build_browser_scenario_catalog(
    *,
    software_workflow: dict[str, Any],
    business_workflow: dict[str, Any],
) -> BrowserScenarioCatalog:
    software_workflow_id = str(software_workflow["workflow_id"])
    software_revision_id = str(software_workflow["revision_id"])
    business_workflow_id = str(business_workflow["workflow_id"])
    business_revision_id = str(business_workflow["revision_id"])

    return BrowserScenarioCatalog(
        run_scenarios=[
            RunScenario(
                scenario_id=SCENARIO_IDS["run_completed_software"],
                run_id="run_completed_software",
                workflow_id=software_workflow_id,
                revision_id=software_revision_id,
                domain_id="software",
                objective="Execute the software demo workflow",
                artifact_title="Studio Demo Software Workflow",
                stage_bindings=[
                    _stage_binding(
                        stage_name="analyze",
                        stage_id="analyze",
                        stage_execution_id="run_completed_software:analyze",
                        asset_id="templates/software/analyze_task.md",
                    ),
                    _stage_binding(
                        stage_name="verify",
                        stage_id="verify",
                        stage_execution_id="run_completed_software:verify",
                        asset_id="templates/software/verify_change.md",
                    ),
                ],
                lifecycle_decisions={
                    "selected_path": "story0_compatibility",
                    "next_action": "execution_complete",
                    "resume_target": "execution",
                    "story0_required": True,
                    "review_required": True,
                    "wait_resume_supported": True,
                    "operator_review_required": False,
                    "operator_review_pending": False,
                },
                remote_events=_completed_run_events("run_completed_software"),
            ),
            RunScenario(
                scenario_id=SCENARIO_IDS["run_artifact_divergence"],
                run_id="run_artifact_divergence",
                workflow_id=software_workflow_id,
                revision_id=software_revision_id,
                domain_id="software",
                objective="Inspect candidate versus accepted artifact divergence",
                artifact_title="Divergent workflow artifact demo",
                stage_bindings=[
                    _stage_binding(
                        stage_name="analyze",
                        stage_id="analyze",
                        stage_execution_id="run_artifact_divergence:analyze",
                        asset_id="templates/software/analyze_task.md",
                    ),
                ],
                lifecycle_decisions={
                    "selected_path": "story0_compatibility",
                    "next_action": "inspect_divergence",
                    "resume_target": "review",
                    "story0_required": True,
                    "review_required": True,
                    "wait_resume_supported": True,
                    "operator_review_required": False,
                    "operator_review_pending": False,
                },
                remote_events=_completed_run_events("run_artifact_divergence"),
                remote_session_overrides={
                    "workflow_artifacts": [
                        {
                            "artifact_type": "workflow_execution",
                            "artifact_id": "run_artifact_divergence-candidate",
                            "version": "candidate",
                            "domain_id": "software",
                            "title": "Candidate artifact",
                            "lifecycle": "candidate",
                            "trace_id": "trace-run_artifact_divergence",
                            "references": [],
                            "runtime_metadata": {
                                "candidate_state": "candidate",
                                "accepted_artifact_id": "run_artifact_divergence-accepted",
                            },
                            "metadata": {},
                        },
                        {
                            "artifact_type": "workflow_execution",
                            "artifact_id": "run_artifact_divergence-accepted",
                            "version": "accepted",
                            "domain_id": "software",
                            "title": "Accepted artifact",
                            "lifecycle": "accepted",
                            "trace_id": "trace-run_artifact_divergence",
                            "references": [],
                            "runtime_metadata": {
                                "candidate_state": "accepted",
                            },
                            "metadata": {},
                        },
                    ]
                },
            ),
            RunScenario(
                scenario_id=SCENARIO_IDS["run_blocked_operator"],
                run_id="run_blocked_operator",
                workflow_id=business_workflow_id,
                revision_id=business_revision_id,
                domain_id="business",
                objective="Resolve blocked operator review for the business workflow",
                artifact_title="Blocked operator review demo",
                stage_bindings=[
                    _stage_binding(
                        stage_name="review",
                        stage_id="review",
                        stage_execution_id="run_blocked_operator:review",
                        asset_id="templates/business/review_exception.md",
                    ),
                ],
                lifecycle_decisions={
                    "selected_path": "operator_review_hold",
                    "next_action": "approve_operator_review",
                    "resume_target": "operator_review",
                    "story0_required": False,
                    "review_required": True,
                    "wait_resume_supported": True,
                    "operator_review_required": True,
                    "operator_review_pending": True,
                },
                status="awaiting_operator",
                blocking_summary={
                    "state": "awaiting_operator",
                    "terminal": False,
                    "reason": "operator_review_pending",
                },
                checkpoint_id="checkpoint-run-blocked-operator",
                remote_events=[
                    _progress_event(
                        "run_blocked_operator",
                        0,
                        "2026-03-08T02:10:00+00:00",
                        {"action": "operator_review_pending", "checkpoint_id": "checkpoint-run-blocked-operator"},
                    ),
                    _escalation_event(
                        "run_blocked_operator",
                        1,
                        "2026-03-08T02:10:30+00:00",
                        escalation_id="escalation-run-blocked-operator",
                        checkpoint_id="checkpoint-run-blocked-operator",
                    ),
                ],
                remote_session_overrides={
                    "status": "awaiting_operator",
                    "resume_context": {
                        "operator_review": {
                            "status": "pending_review",
                            "checkpoint_id": "checkpoint-run-blocked-operator",
                        }
                    },
                },
            ),
            RunScenario(
                scenario_id=SCENARIO_IDS["run_escalation_pending"],
                run_id="run_escalation_pending",
                workflow_id=business_workflow_id,
                revision_id=business_revision_id,
                domain_id="business",
                objective="Resolve an execution escalation with rich correlation",
                artifact_title="Escalation pending demo",
                stage_bindings=[
                    _stage_binding(
                        stage_name="review",
                        stage_id="review",
                        stage_execution_id="run_escalation_pending:review",
                        asset_id="templates/business/review_exception.md",
                    ),
                ],
                lifecycle_decisions={
                    "selected_path": "direct_execution",
                    "next_action": "resolve_escalation",
                    "resume_target": "execution",
                    "story0_required": False,
                    "review_required": False,
                    "wait_resume_supported": True,
                    "operator_review_required": False,
                    "operator_review_pending": False,
                },
                status="failed",
                blocking_summary={
                    "state": "escalated",
                    "terminal": False,
                    "reason": "policy_conflict",
                },
                escalation_id="escalation-run-escalation-pending",
                remote_events=[
                    _progress_event(
                        "run_escalation_pending",
                        0,
                        "2026-03-08T02:20:00+00:00",
                        {"action": "stage_failed", "stage_name": "review"},
                    ),
                    _escalation_event(
                        "run_escalation_pending",
                        1,
                        "2026-03-08T02:20:20+00:00",
                        escalation_id="escalation-run-escalation-pending",
                    ),
                ],
                remote_session_overrides={
                    "status": "escalated",
                    "current_phase": "review",
                },
            ),
            RunScenario(
                scenario_id=SCENARIO_IDS["run_replay_failure"],
                run_id="run_replay_failure",
                workflow_id=software_workflow_id,
                revision_id=software_revision_id,
                domain_id="software",
                objective="Inspect replay-rich failure output for a software run",
                artifact_title="Replay failure demo",
                stage_bindings=[
                    _stage_binding(
                        stage_name="verify",
                        stage_id="verify",
                        stage_execution_id="run_replay_failure:verify",
                        asset_id="templates/software/verify_change.md",
                    ),
                ],
                lifecycle_decisions={
                    "selected_path": "story0_compatibility",
                    "next_action": "inspect_failure",
                    "resume_target": "verification",
                    "story0_required": True,
                    "review_required": True,
                    "wait_resume_supported": True,
                    "operator_review_required": False,
                    "operator_review_pending": False,
                },
                status="failed",
                blocking_summary={
                    "state": "failed",
                    "terminal": True,
                    "error": "VerificationError",
                },
                remote_events=[
                    _progress_event(
                        "run_replay_failure",
                        0,
                        "2026-03-08T02:30:00+00:00",
                        {"action": "workflow_bound", "workflow_run_id": "run_replay_failure"},
                    ),
                    _progress_event(
                        "run_replay_failure",
                        1,
                        "2026-03-08T02:30:25+00:00",
                        {"action": "stage_failed", "stage_name": "verify"},
                    ),
                    {
                        "event_id": "run_replay_failure:2",
                        "event_type": "session_error",
                        "timestamp": "2026-03-08T02:30:55+00:00",
                        "sequence": 2,
                        "trace_id": "trace-run_replay_failure",
                        "payload": {
                            "error": "VerificationError",
                            "summary": "Verification stage produced blocking issues",
                        },
                    },
                ],
                remote_session_overrides={
                    "status": "failed",
                    "current_phase": "verification",
                },
            ),
        ],
        derivation_scenarios=[
            DerivationScenario(
                scenario_id=SCENARIO_IDS["derivation_pending_review"],
                run_id="derivation_pending_review",
                derivation_id="drv_pending_review",
                workflow_id=business_workflow_id,
                revision_id=business_revision_id,
                domain_id="business",
                mission="Derive a business workflow revision from the accepted baseline.",
                validation_outcome="pass_with_operator_review",
                issue_codes=["operator_review_required_for_inferred_inputs"],
                checkpoint_state={
                    "status": "pending_review",
                    "pending_count": 1,
                    "checkpoint_ids": ["OP-1"],
                    "pending_points": [
                        {
                            "id": "OP-1",
                            "reason": "Confirm inferred intake routing.",
                        }
                    ],
                },
                lifecycle_decisions={
                    "selected_path": "direct_execution",
                    "story0_required": False,
                    "review_required": False,
                    "wait_resume_supported": True,
                },
            ),
            DerivationScenario(
                scenario_id=SCENARIO_IDS["derivation_revision_required"],
                run_id="derivation_revision_required",
                derivation_id="drv_revision_required",
                workflow_id=software_workflow_id,
                revision_id=software_revision_id,
                domain_id="software",
                mission="Derive a software workflow revision from the accepted baseline.",
                validation_outcome="revise_required",
                issue_codes=["stage_quality_gates_unresolvable"],
                checkpoint_state={
                    "status": "revision_required",
                    "pending_count": 0,
                    "checkpoint_ids": [],
                    "pending_points": [],
                },
                lifecycle_decisions={
                    "selected_path": "story0_compatibility",
                    "story0_required": True,
                    "review_required": True,
                    "wait_resume_supported": True,
                },
            ),
        ],
        workflow_scenarios=[
            WorkflowScenario(
                scenario_id=SCENARIO_IDS["workflow_edit_rich_baseline"],
                workflow_id=software_workflow_id,
                revision_id=software_revision_id,
            ),
            WorkflowScenario(
                scenario_id=SCENARIO_IDS["workflow_edit_conflict"],
                workflow_id=business_workflow_id,
                revision_id=business_revision_id,
            ),
        ],
    )


def _stage_binding(
    *,
    stage_name: str,
    stage_id: str,
    stage_execution_id: str,
    asset_id: str,
) -> dict[str, Any]:
    return {
        "binding_role": "primary_stage_instruction",
        "binding_scope": "stage",
        "stage_id": stage_id,
        "content_format": "markdown",
        "adoption_state": "approved_for_execution",
        "materialized_path": asset_id,
        "artifact_ref": {
            "target_artifact_type": "stage_asset",
            "target_artifact_id": asset_id,
            "target_version_selector": "v1",
            "relationship_type": "binds_to",
            "metadata": {"path": asset_id},
        },
        "metadata": {"source": "workflow_definition"},
        "stage_name": stage_name,
        "stage_execution_id": stage_execution_id,
    }


def _progress_event(
    run_id: str,
    sequence: int,
    timestamp: str,
    payload: dict[str, Any],
) -> dict[str, Any]:
    return {
        "event_id": f"{run_id}:{sequence}",
        "event_type": "progress",
        "timestamp": timestamp,
        "sequence": sequence,
        "trace_id": f"trace-{run_id}",
        "payload": payload,
    }


def _escalation_event(
    run_id: str,
    sequence: int,
    timestamp: str,
    *,
    escalation_id: str,
    checkpoint_id: str | None = None,
) -> dict[str, Any]:
    payload = {
        "escalation_id": escalation_id,
    }
    if checkpoint_id:
        payload["checkpoint_id"] = checkpoint_id
    return {
        "event_id": f"{run_id}:{sequence}",
        "event_type": "escalation_notice",
        "timestamp": timestamp,
        "sequence": sequence,
        "trace_id": f"trace-{run_id}",
        "payload": payload,
    }


def _completed_run_events(run_id: str) -> list[dict[str, Any]]:
    return [
        _progress_event(
            run_id,
            0,
            "2026-03-08T01:49:10+00:00",
            {"action": "workflow_bound", "workflow_run_id": run_id},
        ),
        _progress_event(
            run_id,
            1,
            "2026-03-08T01:49:35+00:00",
            {"action": "stage_completed", "stage_name": "finalize"},
        ),
        {
            "event_id": f"{run_id}:2",
            "event_type": "session_completed",
            "timestamp": "2026-03-08T01:50:00+00:00",
            "sequence": 2,
            "trace_id": f"trace-{run_id}",
            "payload": {"summary": "Demo workflow run completed"},
        },
    ]
