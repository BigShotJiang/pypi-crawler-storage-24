"""Assistant thread-memory helpers."""

from __future__ import annotations

from typing import Any


def _message_preview(message: str, limit: int) -> str:
    normalized = " ".join(message.split())
    if len(normalized) <= limit:
        return normalized
    return normalized[: max(0, limit - 1)].rstrip() + "…"


def build_thread_memory(
    turns: list[dict[str, Any]],
    assistant_config: dict[str, Any],
) -> dict[str, Any]:
    """Build bounded transcript memory from stored turns."""
    recent_turn_limit = int(assistant_config.get("memory_recent_turns", 6))
    summary_turn_limit = int(assistant_config.get("memory_summary_turns", 12))
    preview_chars = int(assistant_config.get("memory_summary_message_chars", 160))
    mode_event_limit = int(assistant_config.get("memory_mode_event_limit", 6))

    recent_turns = turns[-recent_turn_limit:] if recent_turn_limit > 0 else []
    older_turns = turns[:-recent_turn_limit] if recent_turn_limit > 0 else turns
    older_turns = older_turns[-summary_turn_limit:] if summary_turn_limit > 0 else []

    summary_lines: list[str] = []
    if older_turns:
        summary_lines.append("Earlier thread summary:")
        for turn in older_turns:
            role = str(turn.get("role") or "assistant")
            label = "System" if role == "system" else role.capitalize()
            event_title = str(turn.get("event_title") or "").strip()
            if role == "system" and event_title:
                summary_lines.append(f"- {label}: {event_title}")
                continue
            summary_lines.append(
                f"- {label}: {_message_preview(str(turn.get('message') or ''), preview_chars)}"
            )

    mode_changes = [
        turn
        for turn in turns
        if str(turn.get("role") or "") == "system"
        and str(turn.get("event_type") or "") == "mode_change"
    ][-mode_event_limit:]

    return {
        "recent_transcript_turns": recent_turns,
        "transcript_summary": "\n".join(summary_lines),
        "mode_change_events": mode_changes,
    }


def summarize_thread_for_archive(
    turns: list[dict[str, Any]],
    assistant_config: dict[str, Any],
) -> str:
    """Build a compact archive or carry-forward summary."""
    preview_chars = int(assistant_config.get("memory_summary_message_chars", 160))
    visible_turns = turns[-6:]
    if not visible_turns:
        return "Empty assistant thread."

    lines = ["Archive summary:"]
    for turn in visible_turns:
        role = str(turn.get("role") or "assistant")
        if role == "system" and turn.get("event_title"):
            lines.append(f"- System: {turn['event_title']}")
            continue
        lines.append(
            f"- {role.capitalize()}: {_message_preview(str(turn.get('message') or ''), preview_chars)}"
        )
    return "\n".join(lines)
