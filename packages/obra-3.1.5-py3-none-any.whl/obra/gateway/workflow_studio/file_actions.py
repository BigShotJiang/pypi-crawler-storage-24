"""Assistant file-generation and documentation handlers."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
from pathlib import Path
import re
from typing import Any, Callable, Iterable

from obra.gateway.assistant.action_broker import HandlerContext

_DEFAULT_VARIANTS = ["happy-path", "edge-case", "minimal"]


class PathTraversalError(ValueError):
    """Raised when a file action escapes the project root or allowed prefixes."""


@dataclass
class FileActionResult:
    """Structured result for assistant file actions."""

    files_written: list[str]
    variant_names: list[str]
    target_directory: str
    error_code: str | None = None
    error_message: str | None = None
    markdown_content: str | None = None


def _validate_path(project_root: Path, target_path: Path) -> Path:
    raw_target = str(target_path)
    if "\x00" in raw_target:
        raise PathTraversalError("Target path contains null bytes")

    resolved_root = project_root.resolve()
    candidate = target_path if target_path.is_absolute() else resolved_root / target_path
    resolved_target = candidate.resolve()
    if not resolved_target.is_relative_to(resolved_root):
        raise PathTraversalError(f"Path {target_path} escapes project root {project_root}")

    relative = resolved_target.relative_to(resolved_root)
    if not relative.parts or relative.parts[0] not in {"test-data", "docs"}:
        raise PathTraversalError("Assistant file actions may only write under test-data/ or docs/")
    return resolved_target


def generate_test_data(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Generate constrained test-data files for a workflow."""
    project_root = _require_project_root(ctx)
    wf_id = workflow_id or str(inputs.get("workflow_id") or "")
    variants = _coerce_variants(inputs.get("variants"))
    format_hint = _string_or_none(inputs.get("format_hint"))
    input_template = _resolve_input_template(ctx, wf_id, inputs)
    if not input_template:
        return _result_payload(
            FileActionResult(
                files_written=[],
                variant_names=[],
                target_directory=f"test-data/{wf_id}",
                error_code="generation_failed",
                error_message="Workflow input template could not be resolved.",
            ),
            outcome="rejected",
            action_id="generate_test_data",
        )

    try:
        result = _generate_test_data_impl(
            project_root=project_root,
            workflow_id=wf_id,
            input_template=input_template,
            llm_call=_require_llm(ctx),
            variants=variants,
            format_hint=format_hint,
        )
    except Exception as exc:
        result = FileActionResult(
            files_written=[],
            variant_names=[],
            target_directory=f"test-data/{wf_id}",
            error_code="generation_failed",
            error_message=f"Unable to generate test data: {exc}",
        )
    return _result_payload(result, outcome="applied" if result.error_code is None else "rejected", action_id="generate_test_data")


def generate_documentation(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Generate Markdown workflow documentation without writing files."""
    wf_id = workflow_id or str(inputs.get("workflow_id") or "")
    workflow_graph = ctx.repository.get_workflow(wf_id) or {}
    markdown = _generate_documentation_impl(
        workflow_graph=workflow_graph,
        llm_call=_require_llm(ctx),
    )
    if not markdown:
        return _result_payload(
            FileActionResult(
                files_written=[],
                variant_names=[],
                target_directory="docs",
                error_code="generation_failed",
                error_message="Unable to generate workflow documentation.",
            ),
            outcome="rejected",
            action_id="generate_documentation",
        )
    return _result_payload(
        FileActionResult(
            files_written=[],
            variant_names=[],
            target_directory="docs",
            markdown_content=markdown,
        ),
        outcome="applied",
        action_id="generate_documentation",
    )


def save_documentation(
    workflow_id: str | None,
    inputs: dict[str, Any],
    ctx: HandlerContext,
) -> dict[str, Any]:
    """Save generated Markdown into the project docs directory."""
    project_root = _require_project_root(ctx)
    wf_id = workflow_id or str(inputs.get("workflow_id") or "")
    markdown_content = str(inputs.get("markdown_content") or "").strip()
    workflow = ctx.repository.get_workflow(wf_id) or {}
    workflow_title = str(
        inputs.get("workflow_title")
        or workflow.get("title")
        or workflow.get("name")
        or wf_id
    )
    result = _save_documentation_impl(
        project_root=project_root,
        workflow_title=workflow_title,
        markdown_content=markdown_content,
    )
    return _result_payload(result, outcome="applied" if result.error_code is None else "rejected", action_id="save_documentation")


def _generate_test_data_impl(
    *,
    project_root: Path,
    workflow_id: str,
    input_template: str,
    llm_call: Callable[..., str],
    variants: list[str] | None = None,
    format_hint: str | None = None,
) -> FileActionResult:
    variant_names = variants or list(_DEFAULT_VARIANTS)
    target_directory = Path("test-data") / workflow_id
    target_root = _validate_path(project_root, target_directory)
    extension = _infer_extension(format_hint, input_template)

    responses: dict[str, str] = {}
    try:
        for variant in variant_names:
            responses[variant] = llm_call(
                _build_generation_system_prompt(),
                _build_variant_prompt(input_template, variant),
            )
    except Exception as exc:
        return FileActionResult(
            files_written=[],
            variant_names=[],
            target_directory=target_directory.as_posix(),
            error_code="generation_failed",
            error_message=f"Unable to generate test data: {exc}",
        )

    if any(not content.strip() for content in responses.values()):
        return FileActionResult(
            files_written=[],
            variant_names=[],
            target_directory=target_directory.as_posix(),
            error_code="generation_failed",
            error_message="The assistant returned empty test data content.",
        )

    target_root.mkdir(parents=True, exist_ok=True)
    written_files: list[str] = []
    for variant, content in responses.items():
        relative_path = target_directory / f"{variant}{extension}"
        destination = _validate_path(project_root, relative_path)
        destination.write_text(content.strip() + "\n", encoding="utf-8")
        written_files.append(relative_path.as_posix())

    return FileActionResult(
        files_written=written_files,
        variant_names=variant_names,
        target_directory=target_directory.as_posix(),
    )


def _generate_documentation_impl(
    *,
    workflow_graph: dict[str, Any],
    llm_call: Callable[..., str],
) -> str:
    title = str(workflow_graph.get("title") or workflow_graph.get("name") or "Workflow")
    stages = _workflow_stages(workflow_graph)
    connections = [
        f"{dependency} -> {stage.get('stage_id') or stage.get('id')}"
        for stage in stages
        for dependency in stage.get("depends_on", [])
    ]
    inputs = [
        str(binding.get("target_artifact_id") or binding.get("artifact_id") or "")
        for stage in stages
        for binding in stage.get("template_asset_bindings", [])
    ]
    prompt = (
        f"Workflow title: {title}\n"
        f"Domain: {workflow_graph.get('domain_id', 'unknown')}\n"
        f"Inputs: {inputs or ['No explicit inputs']}\n"
        f"Connections: {connections or ['No connections']}\n"
        f"Stages: {json.dumps(stages, sort_keys=True)}\n"
        "Produce Markdown with sections: Overview, Inputs, Stages, Connections, Expected Output."
    )
    try:
        markdown = llm_call(
            "Generate concise, plain-language workflow documentation in Markdown.",
            prompt,
        )
    except Exception:
        return ""

    if markdown.strip():
        return markdown.strip()

    stage_lines = "\n".join(
        (
            f"### Stage: {stage.get('title') or stage.get('stage_id') or stage.get('id')}\n"
            f"- Purpose: {stage.get('purpose') or 'No purpose provided'}\n"
            f"- Runner: {stage.get('runner', {}).get('runner_id') or stage.get('runner_id') or 'Unknown'}\n"
            f"- Input: {', '.join(stage.get('inputs', [])) or 'None'}\n"
            f"- Output: {', '.join(stage.get('outputs', [])) or 'None'}"
        )
        for stage in stages
    )
    return (
        f"## Overview\n{title}\n\n"
        f"## Inputs\n{', '.join(inputs) if inputs else 'No explicit inputs'}\n\n"
        f"## Stages\n{stage_lines or 'No stages defined'}\n\n"
        f"## Connections\n{chr(10).join(connections) if connections else 'No connections'}\n\n"
        "## Expected Output\nWorkflow execution produces the documented downstream artifacts."
    )


def _save_documentation_impl(
    *,
    project_root: Path,
    workflow_title: str,
    markdown_content: str,
) -> FileActionResult:
    slug = _slugify(workflow_title or "workflow-documentation")
    relative_path = Path("docs") / f"{slug}.md"
    destination = _validate_path(project_root, relative_path)
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(markdown_content.strip() + "\n", encoding="utf-8")
    return FileActionResult(
        files_written=[relative_path.as_posix()],
        variant_names=[],
        target_directory="docs",
        markdown_content=markdown_content.strip(),
    )


def _require_project_root(ctx: HandlerContext) -> Path:
    if ctx.project_root is None:
        raise PathTraversalError("Project root is required for assistant file actions")
    return ctx.project_root


def _require_llm(ctx: HandlerContext) -> Callable[..., str]:
    if ctx.llm_call is None:
        raise RuntimeError("Assistant LLM callable is not configured")
    return ctx.llm_call


def _resolve_input_template(ctx: HandlerContext, workflow_id: str, inputs: dict[str, Any]) -> str:
    explicit_template = _string_or_none(inputs.get("input_template"))
    if explicit_template:
        return explicit_template

    workflow = ctx.repository.get_workflow(workflow_id) or {}
    definition = workflow.get("workflow_definition", {})
    template_bindings: list[dict[str, Any]] = []
    for stage in definition.get("stages", []):
        template_bindings.extend(stage.get("template_asset_bindings", []) or [])
    if template_bindings:
        return json.dumps(template_bindings, indent=2, sort_keys=True)
    return ""


def _workflow_stages(workflow_graph: dict[str, Any]) -> list[dict[str, Any]]:
    definition = workflow_graph.get("workflow_definition", workflow_graph)
    stages = definition.get("stages", [])
    return [stage for stage in stages if isinstance(stage, dict)]


def _coerce_variants(value: Any) -> list[str]:
    if isinstance(value, Iterable) and not isinstance(value, (str, bytes, dict)):
        variants = [str(item).strip() for item in value if str(item).strip()]
        if variants:
            return variants
    return list(_DEFAULT_VARIANTS)


def _infer_extension(format_hint: str | None, input_template: str) -> str:
    if format_hint:
        normalized = format_hint.strip().lower().lstrip(".")
        return f".{normalized}"
    trimmed = input_template.strip()
    return ".json" if trimmed.startswith("{") or trimmed.startswith("[") else ".txt"


def _build_generation_system_prompt() -> str:
    return (
        "Generate realistic workflow input data. Return only the file contents with no prose, "
        "matching the requested variant profile and the provided input template."
    )


def _build_variant_prompt(input_template: str, variant: str) -> str:
    variant_descriptions = {
        "happy-path": "include all required and optional fields with realistic values",
        "edge-case": "use tricky but valid values, missing optional fields, long strings, and special characters",
        "minimal": "include only the minimum required fields",
    }
    description = variant_descriptions.get(variant, f"produce a {variant} variant")
    return f"Input template:\n{input_template}\n\nVariant: {variant}\nInstructions: {description}."


def _slugify(value: str) -> str:
    normalized = re.sub(r"[^a-z0-9]+", "-", value.strip().lower())
    return normalized.strip("-") or "workflow-documentation"


def _string_or_none(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _result_payload(result: FileActionResult, *, outcome: str, action_id: str) -> dict[str, Any]:
    payload = asdict(result)
    payload["outcome"] = outcome
    payload["action_id"] = action_id
    return payload
