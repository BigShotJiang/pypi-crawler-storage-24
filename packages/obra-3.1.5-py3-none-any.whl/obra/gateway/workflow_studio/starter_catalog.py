"""Shared Workflow Studio starter catalog loader and selector helpers."""

from __future__ import annotations

from functools import lru_cache
import json
from pathlib import Path
from typing import Any


_CATALOG_PATH = Path(__file__).resolve().parents[3] / "config" / "workflow_studio_starter_catalog.json"


def normalize_starter_domain_id(domain_id: str | None) -> str:
    """Normalize domain ids used across client and gateway surfaces."""
    normalized = str(domain_id or "").strip().lower()
    if normalized in {"obra_business", "business"}:
        return "business"
    if normalized in {"obra_software", "software"}:
        return "software"
    return normalized


@lru_cache(maxsize=1)
def load_starter_catalog() -> dict[str, Any]:
    """Load the repository-shared starter catalog."""
    with _CATALOG_PATH.open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("Workflow Studio starter catalog must be a JSON object.")
    return payload


def resolve_domain_starters(domain_id: str | None) -> list[dict[str, Any]]:
    """Return a deep-copied starter list for the requested domain."""
    catalog = load_starter_catalog()
    domains = catalog.get("domains") or {}
    normalized = normalize_starter_domain_id(domain_id)
    starters = domains.get(normalized) or []
    if not isinstance(starters, list):
        return []
    return json.loads(json.dumps(starters))


def choose_recommended_starters(
    *,
    domain_id: str | None,
    request_text: str,
    limit: int = 3,
) -> list[dict[str, Any]]:
    """Rank starters for a request using domain context and catalog metadata."""
    normalized_domain = normalize_starter_domain_id(domain_id)
    request = str(request_text or "").strip().lower()

    domain_starters = resolve_domain_starters(normalized_domain)
    if not domain_starters and normalized_domain:
      domain_starters = resolve_domain_starters("")
    if not domain_starters:
        return []

    def _score(starter: dict[str, Any]) -> tuple[int, str]:
        score = 0
        for keyword in starter.get("keywords") or []:
            token = str(keyword).strip().lower()
            if token and token in request:
                score += 3
        for sentence in starter.get("intended_use_cases") or []:
            text = str(sentence).strip().lower()
            if not text:
                continue
            if any(word in request for word in text.split()):
                score += 1
        title = str(starter.get("title") or "").strip().lower()
        if title and any(part in request for part in title.split()):
            score += 2
        return score, str(starter.get("id") or "")

    ranked = sorted(domain_starters, key=_score, reverse=True)
    return ranked[: max(limit, 1)]
