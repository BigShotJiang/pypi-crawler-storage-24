"""Workflow-run projections for Workflow Studio Stage A."""

from __future__ import annotations

from typing import Any

from obra.gateway.workflow_studio.data_access import (
    WorkflowStudioRunBundle,
    workflow_lifecycle_decisions_from_payload,
    workflow_lifecycle_from_sources,
    workflow_identity_from_sources,
)


def build_workflow_run_summary(bundle: WorkflowStudioRunBundle) -> dict[str, Any]:
    """Build canonical workflow-run summary."""
    identity = workflow_identity_from_sources(bundle.record, bundle.remote_session)
    return {
        "resource_type": "workflow_run",
        "run_id": bundle.record.workflow_run_id,
        "workflow_run_id": bundle.record.workflow_run_id,
        "status": bundle.record.status,
        "created_at": bundle.record.created_at.isoformat(),
        "objective": bundle.record.objective,
        "project_id": bundle.record.project_id,
        "workflow_ref": {
            "workflow_id": identity["workflow_id"],
            "revision_id": identity["revision_id"],
            "domain_id": identity["domain_id"],
        },
        "current_stage": dict(bundle.record.current_stage),
        "blocking_summary": dict(bundle.record.blocking_summary),
        "links": {
            "events": f"/api/workflow-runs/{bundle.record.workflow_run_id}/events",
            "replay": f"/api/workflow-runs/{bundle.record.workflow_run_id}/replay",
        },
    }


def build_workflow_run_detail(bundle: WorkflowStudioRunBundle) -> dict[str, Any]:
    """Build canonical workflow-run detail."""
    summary = build_workflow_run_summary(bundle)
    resume_context = (
        bundle.remote_session.get("resume_context")
        if isinstance(bundle.remote_session.get("resume_context"), dict)
        else {}
    )
    if not isinstance(resume_context, dict):
        resume_context = {}
    else:
        resume_context = dict(resume_context)
    workflow_lifecycle = workflow_lifecycle_from_sources(bundle.record, bundle.remote_session)
    remote_workflow_lifecycle = (
        dict(resume_context.get("workflow_lifecycle", {}))
        if isinstance(resume_context.get("workflow_lifecycle"), dict)
        else {}
    )
    current_lifecycle_decisions = (
        dict(resume_context.get("lifecycle_decisions", {}))
        if isinstance(resume_context.get("lifecycle_decisions"), dict)
        else {}
    )
    if workflow_lifecycle:
        if not remote_workflow_lifecycle:
            resume_context["workflow_lifecycle"] = workflow_lifecycle
        if not current_lifecycle_decisions or (
            not remote_workflow_lifecycle
            and str(current_lifecycle_decisions.get("selected_path") or "").strip()
            == "story0_compatibility"
        ):
            resume_context["lifecycle_decisions"] = workflow_lifecycle_decisions_from_payload(
                workflow_lifecycle
            )
    summary["resume_context"] = resume_context
    summary["remote_status"] = {
        "current_phase": bundle.remote_session.get("current_phase"),
        "status": bundle.remote_session.get("status"),
        "updated_at": bundle.remote_session.get("updated_at"),
    }
    summary["correlation"] = {
        "checkpoint_id": bundle.record.checkpoint_id,
        "escalation_id": bundle.record.escalation_id,
        "trace_id": bundle.record.trace_id,
    }
    return summary
