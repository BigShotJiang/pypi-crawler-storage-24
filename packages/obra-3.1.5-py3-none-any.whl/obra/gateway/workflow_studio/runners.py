"""Runner lookup and compatibility projections for Workflow Studio Stage C."""

from __future__ import annotations

from typing import Any

from obra.workflow.runner_catalog import RunnerReference
from obra.workflow.runner_catalog_resolver import (
    RunnerCatalogResolver,
    RunnerResolutionContext,
)
from obra.workflow.runner_catalog_sources import load_runner_catalog_sources


def list_runners() -> list[dict[str, Any]]:
    """List canonical runner catalog entries."""
    snapshot = load_runner_catalog_sources()
    return [entry.to_dict() for entry in snapshot.entries]


def get_runner(
    runner_id: str,
    *,
    runner_version: str | None = None,
    runner_selector: str | None = None,
) -> dict[str, Any] | None:
    """Resolve one canonical runner detail payload."""
    resolver = RunnerCatalogResolver()
    resolution = resolver.resolve(
        RunnerReference(
            runner_id=runner_id,
            runner_version=runner_version,
            runner_selector=runner_selector,
        )
    )
    if resolution.entry is None:
        return None
    return resolution.entry.to_dict()


def check_runner_compatibility(payload: dict[str, Any]) -> dict[str, Any]:
    """Check runner compatibility against an explicit workflow context."""
    resolver = RunnerCatalogResolver()
    resolution = resolver.resolve(
        RunnerReference(
            runner_id=str(payload.get("runner_id") or ""),
            runner_version=payload.get("runner_version"),
            runner_selector=payload.get("runner_selector"),
        ),
        context=RunnerResolutionContext(
            domain_id=_str_or_none(payload.get("domain_id")),
            input_type=_str_or_none(payload.get("input_type")),
            stage_archetype=_str_or_none(payload.get("stage_archetype")),
            workflow_capabilities=tuple(_string_list(payload.get("workflow_capabilities"))),
            artifact_roles=tuple(_string_list(payload.get("artifact_roles"))),
            available_executables=tuple(_string_list(payload.get("available_executables"))),
            available_packages=tuple(_string_list(payload.get("available_packages"))),
        ),
    )
    return {
        "ok": resolution.ok,
        "runner": resolution.entry.to_dict() if resolution.entry is not None else None,
        "diagnostic": (
            {
                "code": resolution.diagnostic.code.value,
                "message": resolution.diagnostic.message,
                "runner_id": resolution.diagnostic.runner_id,
                "requested_version": resolution.diagnostic.requested_version,
                "requested_selector": resolution.diagnostic.requested_selector,
                "source_layer": resolution.diagnostic.source_layer,
            }
            if resolution.diagnostic is not None
            else {}
        ),
    }


def _string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item) for item in value if str(item).strip()]


def _str_or_none(value: Any) -> str | None:
    if isinstance(value, str) and value.strip():
        return value
    return None
