"""Gateway-side workflow mutation service for Workflow Studio Stage C."""

from __future__ import annotations

from typing import Any, Callable

from obra.api import APIClient


class WorkflowActionService:
    """Dispatch canonical workflow create, validate, and apply flows."""

    def __init__(
        self,
        *,
        client_factory: Callable[[], APIClient] | None = None,
    ) -> None:
        self._client_factory = client_factory or APIClient.from_config
        self._client: APIClient | None = None

    def create_workflow(self, candidate: dict[str, Any]) -> dict[str, Any]:
        """Create a canonical workflow."""
        return self._get_client().create_workflow(candidate)

    def validate_workflow(
        self,
        workflow_id: str,
        candidate: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Validate a canonical workflow candidate."""
        payload = dict(candidate)
        payload["workflow_id"] = workflow_id
        return self._get_client().validate_workflow_candidate(
            payload,
            expected_revision_id=expected_revision_id,
        )

    def apply_workflow(
        self,
        workflow_id: str,
        candidate: dict[str, Any],
        *,
        expected_revision_id: str | None = None,
    ) -> dict[str, Any]:
        """Apply a guarded canonical workflow candidate."""
        payload = dict(candidate)
        payload["workflow_id"] = workflow_id
        return self._get_client().apply_workflow_candidate(
            payload,
            expected_revision_id=expected_revision_id,
        )

    def _get_client(self) -> APIClient:
        if self._client is None:
            self._client = self._client_factory()
        return self._client
