"""Structured JSONL session logger for the Studio Assistant.

Log format:
    One JSON object per line. Each event contains:
    - type:       event name (e.g. ``asst.session_started``, ``asst.turn_submitted``)
    - ts:         UTC ISO-8601 timestamp (monotonic-derived)
    - ts_local:   local-timezone ISO-8601 timestamp
    - session_id: unique per-session identifier (``asst_YYYYMMDD_HHMMSS_XXXX``)
    - thread_id:  assistant thread identifier
    - component:  always ``studio_assistant``
    - (plus event-specific fields)

File locations (default):
    - Per-session:  ``~/.obra-runtime/logs/assistant/sessions/{session_id}.jsonl``
    - Aggregate:    ``~/.obra-runtime/logs/assistant/assistant.jsonl``

Event catalog:
    asst.session_started    — first turn on a thread
    asst.turn_submitted     — user message received
    asst.context_resolved   — context assembly complete (strategies, signals)
    asst.system_prompt      — final system prompt built
    asst.llm_request        — LLM call initiated
    asst.llm_response       — LLM call returned
    asst.turn_completed     — assistant turn persisted
    asst.turn_error         — error during generation
    asst.action_executed    — action broker completed
    asst.action_reverted    — checkpoint-backed revert completed
"""

from __future__ import annotations

import json
import logging
import time
from datetime import UTC, datetime, timedelta
from pathlib import Path
from threading import Lock
from typing import Any

from obra.utils.obra_home import get_runtime_dir
from obra.utils.retention import prune_files_by_mtime

logger = logging.getLogger(__name__)

_DEFAULT_MAX_AGGREGATE_BYTES = 10 * 1024 * 1024  # 10 MB
_DEFAULT_MAX_BACKUP_COUNT = 5
_DEFAULT_MAX_SESSIONS = 20


class AssistantSessionLogger:
    """JSONL session logger for Studio Assistant conversations.

    Writes to two destinations simultaneously:
    - A per-session file keyed by session_id (primary debug artifact)
    - A rolling aggregate file for cross-session tailing

    Thread-safe via :class:`threading.Lock`.
    """

    def __init__(
        self,
        session_id: str,
        *,
        log_dir: Path | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        self._session_id = session_id
        self._thread_id: str | None = None
        self._config = config or {}
        self._lock = Lock()

        # Monotonic clock reference — same pattern as HybridEventLogger
        self._clock_ref_wall = datetime.now(UTC)
        self._clock_ref_mono = time.perf_counter()

        # Tunables from config
        self._max_aggregate_bytes = int(
            self._config.get("aggregate_max_bytes", _DEFAULT_MAX_AGGREGATE_BYTES)
        )
        self._max_backup_count = int(
            self._config.get("aggregate_backup_count", _DEFAULT_MAX_BACKUP_COUNT)
        )
        self._max_sessions = int(
            self._config.get("max_sessions", _DEFAULT_MAX_SESSIONS)
        )

        # Resolve paths
        self._log_dir = log_dir or (get_runtime_dir() / "logs" / "assistant")
        self._sessions_dir = self._log_dir / "sessions"
        self._sessions_dir.mkdir(parents=True, exist_ok=True)

        self._session_path = self._sessions_dir / f"{session_id}.jsonl"
        self._aggregate_path = self._log_dir / "assistant.jsonl"

    def set_thread_context(self, thread_id: str) -> None:
        """Set the thread ID included in all subsequent events."""
        self._thread_id = thread_id

    @staticmethod
    def generate_session_id(thread_id: str) -> str:
        """Generate a human-readable session identifier."""
        now = datetime.now(UTC)
        return f"asst_{now.strftime('%Y%m%d_%H%M%S')}_{thread_id[:4]}"

    # ------------------------------------------------------------------
    # Event logging
    # ------------------------------------------------------------------

    def log_event(self, event_type: str, **fields: Any) -> None:
        """Write one structured event to both session and aggregate files."""
        # Apply redaction / truncation policies
        fields = self._apply_policies(fields)

        # Derive timestamp from monotonic clock
        elapsed = time.perf_counter() - self._clock_ref_mono
        ts_utc = self._clock_ref_wall + timedelta(seconds=elapsed)
        ts_local = ts_utc.astimezone()

        envelope: dict[str, Any] = {
            "type": event_type,
            "ts": ts_utc.isoformat(),
            "ts_local": ts_local.isoformat(),
            "session_id": self._session_id,
            "thread_id": self._thread_id,
            "component": "studio_assistant",
            **fields,
        }

        line = json.dumps(envelope, default=str) + "\n"

        with self._lock:
            try:
                self._rotate_aggregate()
                with open(self._aggregate_path, "a", encoding="utf-8") as fh:
                    fh.write(line)
                    fh.flush()
            except Exception:
                logger.debug("Failed to write aggregate log", exc_info=True)

            try:
                with open(self._session_path, "a", encoding="utf-8") as fh:
                    fh.write(line)
                    fh.flush()
            except Exception:
                logger.debug("Failed to write session log", exc_info=True)

    # ------------------------------------------------------------------
    # Redaction / truncation policies
    # ------------------------------------------------------------------

    def _apply_policies(self, fields: dict[str, Any]) -> dict[str, Any]:
        """Apply config-driven redaction and truncation to event fields."""
        fields = dict(fields)

        # Screenshot redaction
        if self._config.get("redact_screenshots", True):
            ctx = fields.get("context_attachment")
            if isinstance(ctx, dict):
                ui_state = ctx.get("ui_state")
                if isinstance(ui_state, dict) and "screenshot" in ui_state:
                    ctx = dict(ctx)
                    ctx["ui_state"] = {**ui_state, "screenshot": "[screenshot]"}
                    fields["context_attachment"] = ctx

        # Message truncation
        if not self._config.get("include_full_messages", True):
            for key in ("message",):
                val = fields.get(key)
                if isinstance(val, str) and len(val) > 200:
                    fields[key] = val[:200] + "...[truncated]"

        # System prompt redaction
        if not self._config.get("include_system_prompt", True):
            val = fields.get("system_prompt")
            if isinstance(val, str):
                fields["system_prompt"] = f"[redacted, length={len(val)}]"

        return fields

    # ------------------------------------------------------------------
    # Aggregate rotation
    # ------------------------------------------------------------------

    def _rotate_aggregate(self) -> None:
        """Rotate aggregate log if it exceeds the size threshold."""
        try:
            if not self._aggregate_path.exists():
                return
            current_size = self._aggregate_path.stat().st_size
            if current_size < self._max_aggregate_bytes:
                return

            # Shift existing backups (.N -> .N+1, oldest deleted)
            for i in range(self._max_backup_count, 0, -1):
                old_path = self._aggregate_path.with_suffix(f".jsonl.{i}")
                if i == self._max_backup_count:
                    if old_path.exists():
                        old_path.unlink()
                else:
                    new_path = self._aggregate_path.with_suffix(f".jsonl.{i + 1}")
                    if old_path.exists():
                        old_path.rename(new_path)

            backup_path = self._aggregate_path.with_suffix(".jsonl.1")
            self._aggregate_path.rename(backup_path)
        except Exception:
            logger.debug("Aggregate log rotation failed", exc_info=True)

    # ------------------------------------------------------------------
    # Session pruning
    # ------------------------------------------------------------------

    def prune_sessions(self, max_sessions: int | None = None) -> int:
        """Remove oldest per-session files beyond the limit."""
        limit = max_sessions if max_sessions is not None else self._max_sessions
        return prune_files_by_mtime(
            self._sessions_dir,
            max_files=limit,
            glob="*.jsonl",
            protected_paths={self._session_path},
        )
