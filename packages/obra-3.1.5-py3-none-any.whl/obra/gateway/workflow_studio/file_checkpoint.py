"""Checkpoint management for assistant file mutations."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timezone
import json
import shutil
from pathlib import Path
from uuid import uuid4


class AlreadyRevertedError(RuntimeError):
    """Raised when a checkpoint has already been restored."""


@dataclass
class FileCheckpoint:
    """Manifest for a file-mutation checkpoint."""

    checkpoint_id: str
    workflow_id: str
    created_at: str
    action_id: str
    thread_id: str
    turn_index: int
    target_directory: str
    files_before: list[str]
    files_after: list[str]
    reverted: bool = False


def create_checkpoint(
    project_root: Path,
    workflow_id: str,
    target_dir: str,
    action_id: str,
    thread_id: str,
    turn_index: int,
) -> FileCheckpoint:
    """Create a copy-based checkpoint for *target_dir* under *project_root*."""
    checkpoint = FileCheckpoint(
        checkpoint_id=str(uuid4()),
        workflow_id=workflow_id,
        created_at=datetime.now(tz=timezone.utc).isoformat(),
        action_id=action_id,
        thread_id=thread_id,
        turn_index=turn_index,
        target_directory=target_dir,
        files_before=[],
        files_after=[],
    )
    checkpoint_dir = _checkpoint_dir(project_root, workflow_id, checkpoint.checkpoint_id)
    snapshot_root = checkpoint_dir / "snapshot"
    snapshot_root.mkdir(parents=True, exist_ok=True)

    target_root = project_root / target_dir
    if target_root.exists():
        checkpoint.files_before = _copy_tree_to_snapshot(target_root, snapshot_root)
    else:
        (checkpoint_dir / ".empty_checkpoint").write_text("", encoding="utf-8")

    _write_manifest(checkpoint_dir, checkpoint)
    return checkpoint


def restore_checkpoint(
    project_root: Path,
    checkpoint_id: str,
    workflow_id: str | None = None,
) -> FileCheckpoint:
    """Restore *checkpoint_id* into *project_root* and mark it reverted."""
    checkpoint_dir = _find_checkpoint_dir(project_root, checkpoint_id, workflow_id=workflow_id)
    checkpoint = _read_manifest(checkpoint_dir)
    if checkpoint.reverted:
        raise AlreadyRevertedError(checkpoint_id)

    target_root = project_root / checkpoint.target_directory
    target_root.mkdir(parents=True, exist_ok=True)

    for relative_path in sorted(set(checkpoint.files_after) - set(checkpoint.files_before)):
        live_path = target_root / relative_path
        if live_path.exists():
            live_path.unlink()
            _prune_empty_parents(live_path.parent, stop_at=target_root)

    snapshot_root = checkpoint_dir / "snapshot"
    for relative_path in checkpoint.files_before:
        source = snapshot_root / relative_path
        destination = target_root / relative_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)

    checkpoint.reverted = True
    _write_manifest(checkpoint_dir, checkpoint)
    return checkpoint


def prune_checkpoints(project_root: Path, workflow_id: str, keep: int = 10) -> None:
    """Remove older checkpoints for *workflow_id*, keeping the latest *keep*."""
    workflow_root = project_root / ".obra-checkpoints" / workflow_id
    if not workflow_root.exists():
        return

    checkpoints: list[tuple[str, Path]] = []
    for checkpoint_dir in workflow_root.iterdir():
        manifest_path = checkpoint_dir / "manifest.json"
        if not manifest_path.exists():
            continue
        manifest = _read_manifest(checkpoint_dir)
        checkpoints.append((manifest.created_at, checkpoint_dir))

    for _, checkpoint_dir in sorted(checkpoints, key=lambda item: item[0], reverse=True)[keep:]:
        shutil.rmtree(checkpoint_dir, ignore_errors=True)


def update_checkpoint_files_after(
    project_root: Path,
    checkpoint_id: str,
    files_after: list[str],
    workflow_id: str | None = None,
) -> FileCheckpoint:
    """Persist the set of files written by the action guarded by *checkpoint_id*."""
    checkpoint_dir = _find_checkpoint_dir(project_root, checkpoint_id, workflow_id=workflow_id)
    checkpoint = _read_manifest(checkpoint_dir)
    checkpoint.files_after = list(files_after)
    _write_manifest(checkpoint_dir, checkpoint)
    return checkpoint


def _checkpoint_dir(project_root: Path, workflow_id: str, checkpoint_id: str) -> Path:
    return project_root / ".obra-checkpoints" / workflow_id / checkpoint_id


def _find_checkpoint_dir(
    project_root: Path,
    checkpoint_id: str,
    *,
    workflow_id: str | None = None,
) -> Path:
    checkpoints_root = project_root / ".obra-checkpoints"
    if workflow_id is not None:
        candidate = _checkpoint_dir(project_root, workflow_id, checkpoint_id)
        if not (candidate / "manifest.json").exists():
            raise FileNotFoundError(checkpoint_id)
        return candidate

    if not checkpoints_root.exists():
        raise FileNotFoundError(checkpoint_id)

    for workflow_root in checkpoints_root.iterdir():
        candidate = workflow_root / checkpoint_id
        if (candidate / "manifest.json").exists():
            return candidate
    raise FileNotFoundError(checkpoint_id)


def _copy_tree_to_snapshot(target_root: Path, snapshot_root: Path) -> list[str]:
    files_before: list[str] = []
    for path in sorted(target_root.rglob("*")):
        if path.is_dir():
            continue
        relative_path = path.relative_to(target_root)
        destination = snapshot_root / relative_path
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        files_before.append(relative_path.as_posix())
    return files_before


def _manifest_path(checkpoint_dir: Path) -> Path:
    return checkpoint_dir / "manifest.json"


def _write_manifest(checkpoint_dir: Path, checkpoint: FileCheckpoint) -> None:
    _manifest_path(checkpoint_dir).write_text(
        json.dumps(asdict(checkpoint), indent=2, sort_keys=True),
        encoding="utf-8",
    )


def _read_manifest(checkpoint_dir: Path) -> FileCheckpoint:
    payload = json.loads(_manifest_path(checkpoint_dir).read_text(encoding="utf-8"))
    return FileCheckpoint(**payload)


def _prune_empty_parents(path: Path, *, stop_at: Path) -> None:
    current = path
    while current != stop_at and current.exists():
        try:
            current.rmdir()
        except OSError:
            return
        current = current.parent
