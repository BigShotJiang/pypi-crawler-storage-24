"""Data-access adapter for Workflow Studio Stage A projections."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from obra.api import APIClient
from obra.constants import API_EVENTS_DEFAULT_LIMIT
from obra.domains.loader import DomainNotFoundError, load_domain
from obra.domains.lifecycle import (
    ACTIVE_STATE,
    COMPATIBILITY_PATH_STATE,
    REVIEW_CAPABILITY,
    STORY0_CAPABILITY,
    WAIT_RESUME_CAPABILITY,
)
from obra.gateway.session_manager import SessionManager, SessionNotFoundError, SessionRecord
from obra.workflow.derivation import resolve_domain_derivation_metadata
from obra.workflow.lifecycle import canonicalize_workflow_lifecycle_payload, project_workflow_lifecycle


@dataclass(slots=True)
class WorkflowStudioRunBundle:
    """Projection-ready read bundle for one canonical workflow run."""

    record: SessionRecord
    remote_session: dict[str, Any]
    remote_plan: dict[str, Any]
    remote_events: list[dict[str, Any]]
    workflow_artifacts: list[dict[str, Any]]
    pipeline_stages: list[dict[str, Any]]


@dataclass(slots=True)
class WorkflowStudioDerivationBundle:
    """Projection-ready read bundle for one canonical workflow derivation."""

    record: SessionRecord
    remote_session: dict[str, Any]
    remote_plan: dict[str, Any]
    remote_events: list[dict[str, Any]]
    workflow_artifacts: list[dict[str, Any]]
    pipeline_stages: list[dict[str, Any]]
    workflow_derivation_state: dict[str, Any]


def workflow_identity_from_sources(
    record: SessionRecord,
    remote_session: dict[str, Any],
) -> dict[str, str | None]:
    """Extract the strongest available workflow identity tuple."""
    workflow_lifecycle_state = (
        remote_session.get("workflow_lifecycle_state")
        if isinstance(remote_session.get("workflow_lifecycle_state"), dict)
        else {}
    )
    accepted_workflow = (
        workflow_lifecycle_state.get("accepted")
        if isinstance(workflow_lifecycle_state.get("accepted"), dict)
        else workflow_lifecycle_state
    )
    workflow_derivation_state = (
        remote_session.get("workflow_derivation_state")
        if isinstance(remote_session.get("workflow_derivation_state"), dict)
        else {}
    )
    derived_workflow_artifact = (
        workflow_derivation_state.get("derived_workflow_artifact")
        if isinstance(workflow_derivation_state.get("derived_workflow_artifact"), dict)
        else {}
    )

    workflow_id = (
        _non_empty_str(record.workflow_id)
        or _non_empty_str(derived_workflow_artifact.get("artifact_id"))
        or _non_empty_str(accepted_workflow.get("workflow_id"))
    )
    revision_id = (
        _non_empty_str(record.workflow_revision_id)
        or _non_empty_str(derived_workflow_artifact.get("version"))
        or _non_empty_str(accepted_workflow.get("revision_id"))
    )
    domain_id = (
        _non_empty_str(record.domain_id)
        or _non_empty_str(derived_workflow_artifact.get("domain_id"))
        or _non_empty_str(accepted_workflow.get("domain_id"))
        or _non_empty_str(remote_session.get("domain"))
    )
    return {
        "workflow_id": workflow_id,
        "revision_id": revision_id,
        "domain_id": domain_id,
    }


def workflow_lifecycle_from_sources(
    record: SessionRecord,
    remote_session: dict[str, Any],
) -> dict[str, Any]:
    """Extract the strongest available workflow-lifecycle payload."""
    workflow_lifecycle_state = (
        remote_session.get("workflow_lifecycle_state")
        if isinstance(remote_session.get("workflow_lifecycle_state"), dict)
        else {}
    )
    accepted = canonicalize_workflow_lifecycle_payload(workflow_lifecycle_state)
    if accepted:
        return accepted

    plan_context = (
        record.request_context.get("plan_context")
        if isinstance(record.request_context.get("plan_context"), dict)
        else {}
    )
    if not plan_context:
        return {}

    domain_id = (
        _non_empty_str(record.domain_id)
        or _non_empty_str(plan_context.get("domain_id"))
        or _non_empty_str(_as_dict(plan_context.get("workflow_source_summary")).get("domain_id"))
    )
    resolved_domain = _load_domain_for_workflow_studio(domain_id)
    domain_metadata = resolve_domain_derivation_metadata(domain_id=domain_id)
    if resolved_domain is None:
        return {}

    workflow_definition = _workflow_definition_seed_from_plan_context(plan_context)
    projection = project_workflow_lifecycle(
        workflow_definition,
        domain_lifecycle_policy=resolved_domain.get_lifecycle_policy(),
        domain_quality_dimensions=list(domain_metadata.quality_dimensions),
    )
    identity = workflow_identity_from_sources(record, remote_session)
    return canonicalize_workflow_lifecycle_payload(
        {
            "workflow_id": identity["workflow_id"] or _non_empty_str(plan_context.get("workflow_id")) or "",
            "domain_id": domain_id or "",
            "lifecycle_capabilities": list(projection.lifecycle_capabilities),
            "capability_states": dict(projection.capability_states),
            "active_capabilities": list(projection.active_capabilities),
            "inherited_capabilities": list(projection.inherited_capabilities),
            "compatibility_capabilities": list(projection.compatibility_capabilities),
            "skipped_capabilities": list(projection.skipped_capabilities),
            "quality_dimensions": list(projection.quality_dimensions),
            "source_mode": str(
                plan_context.get("workflow_source_provenance")
                or _as_dict(plan_context.get("workflow_source_artifact")).get("synthesis_mode")
                or ""
            ),
        }
    )


def workflow_lifecycle_decisions_from_payload(
    workflow_lifecycle: dict[str, Any],
) -> dict[str, Any]:
    """Build gateway-side lifecycle decisions from a canonical lifecycle payload."""
    accepted = canonicalize_workflow_lifecycle_payload(workflow_lifecycle)
    capability_states = (
        accepted.get("capability_states")
        if isinstance(accepted.get("capability_states"), dict)
        else {}
    )
    story0_state = str(capability_states.get(STORY0_CAPABILITY) or "skipped")
    review_state = str(capability_states.get(REVIEW_CAPABILITY) or "skipped")
    wait_resume_state = str(capability_states.get(WAIT_RESUME_CAPABILITY) or "skipped")
    story0_required = story0_state in {ACTIVE_STATE, COMPATIBILITY_PATH_STATE}
    review_required = review_state in {ACTIVE_STATE, COMPATIBILITY_PATH_STATE}
    selected_path = (
        "story0_compatibility"
        if story0_state == COMPATIBILITY_PATH_STATE
        else (
            "story0"
            if story0_required
            else (
                "execution_review_compatibility"
                if review_state == COMPATIBILITY_PATH_STATE
                else ("execution_review" if review_required else "direct_execution")
            )
        )
    )
    return {
        "selected_path": selected_path,
        "next_action": "story0" if story0_required else "execution",
        "resume_target": "story0" if story0_required else "execution",
        "story0_required": story0_required,
        "review_required": review_required,
        "wait_resume_supported": wait_resume_state != "skipped",
        "operator_review_required": False,
        "operator_review_pending": False,
    }


class StageADataAccess:
    """Read adapter bridging gateway sessions to SaaS-backed workflow state."""

    def __init__(
        self,
        session_manager: SessionManager,
        *,
        client_factory: Callable[[], APIClient] | None = None,
    ) -> None:
        self._session_manager = session_manager
        self._client_factory = client_factory or APIClient.from_config
        self._client: APIClient | None = None

    def list_run_bundles(
        self,
        *,
        workflow_id: str | None = None,
        event_limit: int = API_EVENTS_DEFAULT_LIMIT,
    ) -> list[WorkflowStudioRunBundle]:
        """Load read bundles for all known workflow runs."""
        records = self._session_manager.list_workflow_runs()
        if workflow_id is not None:
            records = [
                record
                for record in records
                if _non_empty_str(record.workflow_id) == workflow_id
            ]
        return [
            self.get_run_bundle(record.session_id, event_limit=event_limit)
            for record in records
        ]

    def list_derivation_bundles(
        self,
        *,
        event_limit: int = API_EVENTS_DEFAULT_LIMIT,
    ) -> list[WorkflowStudioDerivationBundle]:
        """Load read bundles for all known workflow derivations."""
        return [
            self.get_derivation_bundle(record.derivation_id or record.session_id, event_limit=event_limit)
            for record in self._session_manager.list_workflow_derivations()
        ]

    def get_run_bundle(
        self,
        run_id: str,
        *,
        event_limit: int = API_EVENTS_DEFAULT_LIMIT,
    ) -> WorkflowStudioRunBundle:
        """Load a read bundle for one workflow run."""
        try:
            record = self._session_manager.get_session(run_id)
        except SessionNotFoundError:
            raise

        remote_session: dict[str, Any] = dict(record.latest_remote_session or {})
        remote_plan: dict[str, Any] = dict(record.latest_remote_plan or {})
        remote_events: list[dict[str, Any]] = [
            dict(event) for event in (record.latest_remote_events or [])
        ]

        hybrid_session_id = _non_empty_str(record.hybrid_session_id)
        should_refresh_remote = not remote_session or record.status == "running"
        if hybrid_session_id and should_refresh_remote:
            try:
                client = self._get_client()
            except Exception:
                client = None
            if client is not None:
                try:
                    remote_session = client.get_session(hybrid_session_id)
                except Exception:
                    remote_session = dict(record.latest_remote_session or {})
                remote_session = _merge_local_derivation_action_state(
                    local_session=dict(record.latest_remote_session or {}),
                    refreshed_session=remote_session,
                )
                try:
                    remote_plan = client.get_session_plan(hybrid_session_id)
                except Exception:
                    remote_plan = dict(record.latest_remote_plan or {})
                try:
                    remote_events_response = client.get_session_events(
                        hybrid_session_id,
                        limit=event_limit,
                    )
                    raw_events = remote_events_response.get("events", [])
                    remote_events = [
                        dict(event) for event in raw_events if isinstance(event, dict)
                    ]
                except Exception:
                    remote_events = [dict(event) for event in (record.latest_remote_events or [])]

                self._session_manager.update_remote_snapshot(
                    run_id,
                    remote_session=remote_session,
                    remote_plan=remote_plan,
                    remote_events=remote_events,
                )

        workflow_artifacts = _coerce_dict_list(remote_session.get("workflow_artifacts"))
        pipeline_stages = _coerce_dict_list(remote_session.get("pipeline_stages"))
        return WorkflowStudioRunBundle(
            record=record,
            remote_session=remote_session,
            remote_plan=remote_plan,
            remote_events=remote_events,
            workflow_artifacts=workflow_artifacts,
            pipeline_stages=pipeline_stages,
        )

    def get_derivation_bundle(
        self,
        derivation_id: str,
        *,
        event_limit: int = API_EVENTS_DEFAULT_LIMIT,
    ) -> WorkflowStudioDerivationBundle:
        """Load a read bundle for one canonical workflow derivation."""
        record = self._session_manager.get_session_by_derivation_id(derivation_id)
        run_bundle = self.get_run_bundle(record.session_id, event_limit=event_limit)
        workflow_derivation_state = (
            run_bundle.remote_session.get("workflow_derivation_state")
            if isinstance(run_bundle.remote_session.get("workflow_derivation_state"), dict)
            else {}
        )
        return WorkflowStudioDerivationBundle(
            record=run_bundle.record,
            remote_session=run_bundle.remote_session,
            remote_plan=run_bundle.remote_plan,
            remote_events=run_bundle.remote_events,
            workflow_artifacts=run_bundle.workflow_artifacts,
            pipeline_stages=run_bundle.pipeline_stages,
            workflow_derivation_state=dict(workflow_derivation_state),
        )

    def _get_client(self) -> APIClient:
        if self._client is None:
            self._client = self._client_factory()
        return self._client


def _coerce_dict_list(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [dict(item) for item in value if isinstance(item, dict)]


def _as_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    return {}


def _merge_local_derivation_action_state(
    *,
    local_session: dict[str, Any],
    refreshed_session: dict[str, Any],
) -> dict[str, Any]:
    """Preserve gateway-owned derivation action state across backend refreshes."""
    if not isinstance(local_session, dict) or not local_session:
        return dict(refreshed_session)

    merged = dict(refreshed_session)
    local_state = _as_dict(local_session.get("workflow_derivation_state"))
    if not local_state:
        return merged

    refreshed_state = _as_dict(merged.get("workflow_derivation_state"))
    local_checkpoint = _as_dict(local_state.get("operator_review_checkpoint_state"))
    local_checkpoint_status = str(local_checkpoint.get("status") or "").strip().lower()
    if local_checkpoint_status in {
        "accepted",
        "no_pending_review",
        "revision_required",
        "revision_submitted",
    }:
        refreshed_state["operator_review_checkpoint_state"] = local_checkpoint
        if "operator_review_points" in local_state:
            refreshed_state["operator_review_points"] = list(
                local_state.get("operator_review_points") or []
            )

    local_accepted = _as_dict(local_state.get("accepted_revision_ref"))
    if local_accepted:
        refreshed_state["accepted_revision_ref"] = local_accepted

    if "accept_conflict_reason" in local_state:
        refreshed_state["accept_conflict_reason"] = local_state.get("accept_conflict_reason")

    local_expected = _as_dict(local_state.get("expected_baseline_ref"))
    if local_expected:
        refreshed_state["expected_baseline_ref"] = local_expected

    if refreshed_state:
        merged["workflow_derivation_state"] = refreshed_state
    return merged


def _load_domain_for_workflow_studio(domain_id: str | None) -> Any | None:
    normalized = _non_empty_str(domain_id)
    if not normalized:
        return None
    try:
        return load_domain(normalized)
    except DomainNotFoundError:
        return None


def _workflow_definition_seed_from_plan_context(plan_context: dict[str, Any]) -> dict[str, Any]:
    workflow_definition = _as_dict(plan_context.get("workflow_definition"))
    if workflow_definition:
        return workflow_definition

    workflow_source_summary = _as_dict(plan_context.get("workflow_source_summary"))
    workflow_source_artifact = _as_dict(plan_context.get("workflow_source_artifact"))
    seed: dict[str, Any] = {
        "workflow_id": plan_context.get("workflow_id") or workflow_source_artifact.get("artifact_id"),
        "title": workflow_source_summary.get("title") or workflow_source_artifact.get("title"),
        "description": workflow_source_summary.get("description")
        or workflow_source_artifact.get("description"),
        "quality_dimensions": list(workflow_source_summary.get("quality_dimensions") or []),
        "lifecycle_capabilities": list(workflow_source_summary.get("lifecycle_capabilities") or []),
    }
    lifecycle = workflow_source_summary.get("lifecycle")
    if isinstance(lifecycle, dict):
        seed["lifecycle"] = dict(lifecycle)
    return seed


def _non_empty_str(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None
