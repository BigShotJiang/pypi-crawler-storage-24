"""Canonical Workflow Studio template-asset routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, status

from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/template-assets", tags=["workflow-studio"])


@router.get("/")
async def list_template_assets(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return {"template_assets": repository.list_template_assets()}


@router.get("/{asset_id:path}/revisions")
async def list_template_asset_revisions(
    asset_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    revisions = repository.list_template_asset_revisions(asset_id)
    if revisions is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found")
    return {"asset_id": asset_id, "revisions": revisions}


@router.get("/{asset_id:path}/bindings")
async def list_template_asset_bindings(
    asset_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    bindings = repository.list_template_asset_bindings(asset_id)
    if bindings is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found")
    return {"asset_id": asset_id, "bindings": bindings}


@router.get("/{asset_id:path}")
async def get_template_asset(asset_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    asset = repository.get_template_asset(asset_id)
    if asset is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Template asset not found")
    return {"template_asset": asset}
