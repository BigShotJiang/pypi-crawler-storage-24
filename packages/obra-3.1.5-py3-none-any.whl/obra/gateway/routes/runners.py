"""Canonical Workflow Studio runner lookup routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Request, status

from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/runners", tags=["workflow-studio"])


@router.get("/")
async def list_runners(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return {"runners": repository.list_runners()}


@router.get("/{runner_id}")
async def get_runner(
    runner_id: str,
    request: Request,
    runner_version: str | None = None,
    runner_selector: str | None = None,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    runner = repository.get_runner(
        runner_id,
        runner_version=runner_version,
        runner_selector=runner_selector,
    )
    if runner is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Runner not found")
    return {"runner": runner}


@router.post("/compatibility-check")
async def check_runner_compatibility(
    payload: dict[str, Any],
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return repository.check_runner_compatibility(payload)
