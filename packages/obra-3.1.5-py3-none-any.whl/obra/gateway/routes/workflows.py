"""Canonical Workflow Studio workflow inspection routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, Response, status

from obra.gateway.workflow_studio.repository import WorkflowStudioRepository
from obra.gateway.workflow_studio.workflow_actions import WorkflowActionService

router = APIRouter(prefix="/api/workflows", tags=["workflow-studio"])


@router.get("/")
async def list_workflows(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return {"workflows": repository.list_workflows()}


@router.get("/{workflow_id}")
async def get_workflow(workflow_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow = repository.get_workflow(workflow_id)
    if workflow is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")
    return {"workflow": workflow}


@router.get("/{workflow_id}/revisions")
async def list_workflow_revisions(
    workflow_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    revisions = repository.list_workflow_revisions(workflow_id)
    if not revisions:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow not found")
    return {"workflow_id": workflow_id, "revisions": revisions}


@router.get("/{workflow_id}/revisions/{revision_id}")
async def get_workflow_revision(
    workflow_id: str,
    revision_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    revision = repository.get_workflow_revision(workflow_id, revision_id)
    if revision is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow revision not found")
    return {"workflow_revision": revision}


@router.post("/")
async def create_workflow(
    payload: dict[str, Any],
    request: Request,
    response: Response,
) -> dict[str, object]:
    service = _workflow_action_service(request)
    result = service.create_workflow(payload)
    response.status_code = status.HTTP_201_CREATED
    _emit_workflow_event(request, "workflow.created", result)
    return result


@router.post("/{workflow_id}/validate")
async def validate_workflow(
    workflow_id: str,
    payload: dict[str, Any],
    request: Request,
    if_match: str | None = Header(default=None, alias="If-Match"),
) -> dict[str, object]:
    service = _workflow_action_service(request)
    result = service.validate_workflow(
        workflow_id,
        payload,
        expected_revision_id=if_match,
    )
    _emit_workflow_event(request, "workflow.validated", result)
    return result


@router.patch("/{workflow_id}")
async def patch_workflow(
    workflow_id: str,
    payload: dict[str, Any],
    request: Request,
    if_match: str | None = Header(default=None, alias="If-Match"),
) -> dict[str, object]:
    _raise_stale_revision_conflict(
        request,
        workflow_id,
        expected_revision_id=if_match,
    )
    service = _workflow_action_service(request)
    result = service.apply_workflow(
        workflow_id,
        payload,
        expected_revision_id=if_match,
    )
    if str(result.get("outcome") or "").strip().lower() == "conflict":
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=result)
    if str(result.get("outcome") or "").strip().lower() == "accepted":
        _emit_workflow_event(
            request,
            "workflow.created"
            if result.get("resulting_revision_ref", {}).get("workflow_id") != workflow_id
            else "workflow.updated",
            result,
        )
    return result


def _raise_stale_revision_conflict(
    request: Request,
    workflow_id: str,
    *,
    expected_revision_id: str | None,
) -> None:
    normalized_expected = str(expected_revision_id or "").strip()
    if not normalized_expected:
        return

    repository = WorkflowStudioRepository.from_request(request)
    revisions = repository.list_workflow_revisions(workflow_id)
    if not revisions:
        return

    current_revision_id = str(revisions[0].get("revision_id") or "").strip()
    if not current_revision_id or current_revision_id == normalized_expected:
        return

    workflow = repository.get_workflow(workflow_id)
    raise HTTPException(
        status_code=status.HTTP_409_CONFLICT,
        detail={
            "outcome": "conflict",
            "workflow": workflow or {},
            "base_revision_ref": {
                "workflow_id": workflow_id,
                "revision_id": normalized_expected,
            },
            "current_revision_ref": {
                "workflow_id": workflow_id,
                "revision_id": current_revision_id,
            },
            "conflict_summary": {
                "status": "stale_revision",
                "reason": "expected_revision_mismatch",
            },
        },
    )


def _workflow_action_service(request: Request) -> WorkflowActionService:
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        return WorkflowActionService(client_factory=client_factory)
    return WorkflowActionService()


def _emit_workflow_event(request: Request, event_name: str, result: dict[str, Any]) -> None:
    session_manager = request.app.state.session_manager
    emit = getattr(session_manager, "emit_workflow_event", None)
    if not callable(emit):
        return
    workflow_id = str(
        result.get("workflow", {}).get("workflow_id")
        or result.get("resulting_revision_ref", {}).get("workflow_id")
        or ""
    ).strip()
    if not workflow_id:
        return
    emit(
        workflow_id,
        {
            "event_name": event_name,
            "payload": result,
            "workflow_id": workflow_id,
            "workflow_revision_id": (
                result.get("resulting_revision_ref", {}).get("revision_id")
                or result.get("workflow", {}).get("revision_id")
            ),
            "base_revision_id": result.get("base_revision_ref", {}).get("revision_id"),
            "current_revision_id": result.get("current_revision_ref", {}).get("revision_id"),
        },
    )
