"""Canonical Workflow Studio artifact inspection routes."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, status

from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/artifacts", tags=["workflow-studio"])


@router.get("/")
async def list_artifacts(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return {"artifacts": repository.list_artifacts()}


@router.get("/{artifact_id}")
async def get_artifact(artifact_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    artifact = repository.get_artifact(artifact_id)
    if artifact is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Artifact not found")
    return {"artifact": artifact}


@router.get("/{artifact_id}/content")
async def get_artifact_content(
    artifact_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    content = repository.get_artifact_content(artifact_id)
    if content is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Artifact content not found",
        )
    return {
        "artifact_id": artifact_id,
        "content": content,
        "content_type": "text/plain",
    }


@router.get("/{artifact_id}/references")
async def get_artifact_references(
    artifact_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    payload = repository.get_artifact_references(artifact_id)
    if payload is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Artifact not found")
    return payload


@router.get("/{artifact_id}/provenance")
async def get_artifact_provenance(
    artifact_id: str,
    request: Request,
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    payload = repository.get_artifact_provenance(artifact_id)
    if payload is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Artifact not found")
    return payload
