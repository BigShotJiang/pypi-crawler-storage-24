"""Canonical Workflow Studio replay route."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, status

from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/workflow-runs", tags=["workflow-studio"])


@router.get("/{run_id}/replay")
async def get_workflow_run_replay(run_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    replay = repository.get_run_replay(run_id)
    if replay is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")
    return replay
