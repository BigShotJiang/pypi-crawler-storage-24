"""Canonical Workflow Studio workflow-run routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query, Request, status
from pydantic import BaseModel, ConfigDict, Field, field_validator

from obra.domains.resolution import DomainResolutionError
from obra.gateway.session_manager import SessionNotFoundError
from obra.gateway.workflow_studio.comparison import build_run_comparison
from obra.gateway.workflow_studio.operator_actions import WorkflowRunActionService
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/workflow-runs", tags=["workflow-studio"])


class CreateWorkflowRunRequest(BaseModel):
    """Request body for creating a canonical workflow run."""

    model_config = ConfigDict(extra="forbid")

    objective: str = Field(..., max_length=10_000)
    project_id: str = Field(..., max_length=256)
    working_dir: str = Field(..., max_length=4096)
    workflow_id: str | None = None
    revision_id: str | None = None
    domain_id: str | None = None

    @field_validator("workflow_id", "revision_id", "domain_id", mode="before")
    @classmethod
    def _normalize_optional_strings(cls, value: Any) -> str | None:
        if value is None:
            return None
        if isinstance(value, str):
            normalized = value.strip()
            return normalized or None
        return value


class ResumeWorkflowRunRequest(BaseModel):
    """Request body for resuming a workflow run."""

    resume_target: str | None = None


class OperatorActionRequest(BaseModel):
    """Request body for operator actions."""

    action: str = Field(..., max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)


class ResolveEscalationRequest(BaseModel):
    """Request body for escalation resolution."""

    choice: str = Field(..., max_length=128)
    was_timeout: bool = False


@router.get("/")
async def list_workflow_runs(
    request: Request,
    workflow_id: str | None = Query(default=None, max_length=256),
) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return {"workflow_runs": repository.list_runs(workflow_id=workflow_id)}


@router.get("/compare")
async def compare_workflow_runs(
    request: Request,
    run_ids: str = Query(..., description="Comma-separated run IDs"),
) -> dict[str, Any]:
    normalized_run_ids = list(
        dict.fromkeys(run_id.strip() for run_id in run_ids.split(",") if run_id.strip())
    )
    if len(normalized_run_ids) < 2:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At least two run_ids are required",
        )
    if len(normalized_run_ids) > 10:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="At most 10 run_ids are allowed",
        )

    repository = WorkflowStudioRepository.from_request(request)
    bundles = []
    for run_id in normalized_run_ids:
        try:
            bundles.append(repository.get_run_bundle(run_id))
        except (KeyError, SessionNotFoundError) as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Run not found: {run_id}",
            ) from exc
    return build_run_comparison(bundles)


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_workflow_run(
    body: CreateWorkflowRunRequest,
    request: Request,
) -> dict[str, object]:
    session_manager = request.app.state.session_manager
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        session_manager.set_client_factory(client_factory)
    try:
        run_id = session_manager.create_workflow_run(
            objective=body.objective,
            project_id=body.project_id,
            working_dir=body.working_dir,
            workflow_id=body.workflow_id,
            revision_id=body.revision_id,
            domain_id=body.domain_id,
        )
    except DomainResolutionError as exc:
        raise HTTPException(
            status_code=exc.http_status.value,
            detail=exc.to_payload(),
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Working directory not allowed",
        ) from exc

    repository = WorkflowStudioRepository.from_request(request)
    workflow_run = repository.get_run(run_id)
    return {"workflow_run": workflow_run or {"run_id": run_id, "workflow_run_id": run_id}}


@router.get("/{run_id}")
async def get_workflow_run(run_id: str, request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow_run = repository.get_run(run_id)
    if workflow_run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found")
    return {"workflow_run": workflow_run}


@router.post("/{run_id}/cancel")
async def cancel_workflow_run(run_id: str, request: Request) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    try:
        return service.cancel(
            run_id,
            client_request_id=_client_request_id(request),
        )
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found") from exc


@router.post("/{run_id}/resume")
async def resume_workflow_run(
    run_id: str,
    body: ResumeWorkflowRunRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    try:
        return service.resume(
            run_id,
            resume_target=body.resume_target,
            client_request_id=_client_request_id(request),
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Workflow run not found") from exc


@router.post("/{run_id}/operator-actions")
async def perform_operator_action(
    run_id: str,
    body: OperatorActionRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    return service.dispatch(
        run_id,
        action=body.action,
        payload=body.payload,
        client_request_id=_client_request_id(request),
    )


@router.post("/{run_id}/escalations/{escalation_id}/resolve")
async def resolve_workflow_run_escalation(
    run_id: str,
    escalation_id: str,
    body: ResolveEscalationRequest,
    request: Request,
) -> dict[str, object]:
    service = WorkflowRunActionService(request.app.state.session_manager)
    return service.resolve_escalation(
        run_id,
        escalation_id,
        choice=body.choice,
        was_timeout=body.was_timeout,
        client_request_id=_client_request_id(request),
    )


def _client_request_id(request: Request) -> str | None:
    value = (
        request.headers.get("X-Obra-Client-Request-Id", "").strip()
        or request.headers.get("X-Client-Request-Id", "").strip()
    )
    return value or None
