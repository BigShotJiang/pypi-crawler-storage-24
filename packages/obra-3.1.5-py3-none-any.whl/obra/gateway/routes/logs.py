"""Gateway-mounted log viewer endpoints with cookie-session auth and stream safeguards."""

from __future__ import annotations

import asyncio
import json
import secrets
import threading
import time
from http import HTTPStatus
from typing import Any, AsyncIterator

from fastapi import APIRouter, HTTPException, Query, Request, Response
from fastapi.responses import JSONResponse, StreamingResponse
from fastapi.security import HTTPAuthorizationCredentials

from obra.gateway.auth import verify_token
from obra.gateway.security.client_ip import extract_client_ip_from_request
from obra.observability.log_viewer.server import (
    LogTailer,
    _status_payload,
    build_snapshot,
    load_intent_snapshot,
    load_plan_snapshot,
)

router = APIRouter(prefix="/logs", tags=["logs"])

_LOG_CACHE_HEADERS = {
    "Cache-Control": "no-store",
    "Pragma": "no-cache",
}
_LOG_SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
}
_LOG_CSP_HEADER = {
    "Content-Security-Policy": (
        "default-src 'self'; "
        "script-src 'self' 'unsafe-inline'; "
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
        "font-src 'self' https://fonts.gstatic.com data:; "
        "img-src 'self' data:; "
        "connect-src 'self'; "
        "frame-ancestors 'none';"
    )
}


def _headers(include_csp: bool = False) -> dict[str, str]:
    base = dict(_LOG_CACHE_HEADERS)
    base.update(_LOG_SECURITY_HEADERS)
    if include_csp:
        base.update(_LOG_CSP_HEADER)
    return base


def _gateway_config(request: Request) -> dict[str, Any]:
    return dict(getattr(request.app.state, "gateway_config", {}))


def _cookie_name(request: Request) -> str:
    return str(_gateway_config(request)["logs_session_cookie_name"])


def _cookie_ttl_s(request: Request) -> int:
    return int(_gateway_config(request)["logs_session_ttl_s"])


def _cookie_secure(request: Request) -> bool:
    return bool(_gateway_config(request)["logs_session_cookie_secure"])


def _parse_bearer_token(request: Request) -> str | None:
    auth_header = request.headers.get("Authorization", "").strip()
    if not auth_header:
        return None
    parts = auth_header.split(None, 1)
    if len(parts) != 2 or parts[0].lower() != "bearer":
        return None
    token = parts[1].strip()
    return token or None


def _is_bearer_authenticated(request: Request) -> bool:
    token = _parse_bearer_token(request)
    if token is None:
        return False
    expected_token = str(request.app.state.gateway_token)
    credentials = HTTPAuthorizationCredentials(scheme="Bearer", credentials=token)
    return verify_token(credentials, expected_token)


def _cleanup_expired_sessions(request: Request, now_s: float) -> None:
    sessions: dict[str, float] = request.app.state.logs_auth_sessions
    lock: threading.Lock = request.app.state.logs_auth_lock
    with lock:
        expired = [session_id for session_id, expires_at in sessions.items() if expires_at <= now_s]
        for session_id in expired:
            sessions.pop(session_id, None)


def _is_cookie_authenticated(request: Request, now_s: float) -> bool:
    cookie_name = _cookie_name(request)
    session_id = request.cookies.get(cookie_name)
    if not session_id:
        return False
    sessions: dict[str, float] = request.app.state.logs_auth_sessions
    lock: threading.Lock = request.app.state.logs_auth_lock
    with lock:
        expires_at = sessions.get(session_id)
        if expires_at is None:
            return False
        if expires_at <= now_s:
            sessions.pop(session_id, None)
            return False
    return True


def _require_logs_auth(request: Request) -> None:
    now_s = time.time()
    _cleanup_expired_sessions(request, now_s)
    if _is_cookie_authenticated(request, now_s):
        return
    if _is_bearer_authenticated(request):
        return
    raise HTTPException(
        status_code=HTTPStatus.UNAUTHORIZED,
        detail="Authentication required",
    )


def _issue_auth_session_cookie(request: Request, response: Response) -> None:
    session_id = secrets.token_urlsafe(32)
    expires_at = time.time() + _cookie_ttl_s(request)
    sessions: dict[str, float] = request.app.state.logs_auth_sessions
    lock: threading.Lock = request.app.state.logs_auth_lock
    with lock:
        sessions[session_id] = expires_at

    response.set_cookie(
        key=_cookie_name(request),
        value=session_id,
        max_age=_cookie_ttl_s(request),
        httponly=True,
        secure=_cookie_secure(request),
        samesite="strict",
        path="/logs",
    )


def _clear_auth_session_cookie(request: Request, response: Response) -> None:
    cookie_name = _cookie_name(request)
    session_id = request.cookies.get(cookie_name)
    if session_id:
        sessions: dict[str, float] = request.app.state.logs_auth_sessions
        lock: threading.Lock = request.app.state.logs_auth_lock
        with lock:
            sessions.pop(session_id, None)

    response.delete_cookie(cookie_name, path="/logs")


def _redact_log_paths(payload: dict[str, Any], expose_absolute_paths: bool) -> dict[str, Any]:
    if expose_absolute_paths:
        return payload
    log_paths = payload.get("log_paths")
    if not isinstance(log_paths, dict):
        return payload
    sanitized = dict(payload)
    sanitized["log_paths"] = {
        "hybrid": "<redacted>",
        "production": "<redacted>",
    }
    return sanitized


def _sse_frame(event_name: str, payload: dict[str, Any]) -> str:
    return f"event: {event_name}\\ndata: {json.dumps(payload, default=str)}\\n\\n"


def _acquire_stream_slot(request: Request) -> str:
    cfg = _gateway_config(request)
    max_total = int(cfg["logs_stream_max_clients_total"])
    max_per_ip = int(cfg["logs_stream_max_clients_per_ip"])
    client_ip = extract_client_ip_from_request(request, request.app.state.trusted_proxy_cidrs)

    lock: threading.Lock = request.app.state.logs_stream_lock
    with lock:
        total = int(request.app.state.logs_stream_clients_total)
        per_ip: dict[str, int] = request.app.state.logs_stream_clients_by_ip
        ip_count = int(per_ip.get(client_ip, 0))

        if total >= max_total:
            raise HTTPException(
                status_code=HTTPStatus.TOO_MANY_REQUESTS,
                detail="Too many log stream clients",
            )
        if ip_count >= max_per_ip:
            raise HTTPException(
                status_code=HTTPStatus.TOO_MANY_REQUESTS,
                detail="Too many log stream clients from this IP",
            )

        request.app.state.logs_stream_clients_total = total + 1
        per_ip[client_ip] = ip_count + 1

    return client_ip


def _release_stream_slot(request: Request, client_ip: str) -> None:
    lock: threading.Lock = request.app.state.logs_stream_lock
    with lock:
        total = max(0, int(request.app.state.logs_stream_clients_total) - 1)
        request.app.state.logs_stream_clients_total = total

        per_ip: dict[str, int] = request.app.state.logs_stream_clients_by_ip
        next_count = int(per_ip.get(client_ip, 0)) - 1
        if next_count > 0:
            per_ip[client_ip] = next_count
        else:
            per_ip.pop(client_ip, None)


@router.post("/api/auth/session")
async def create_log_auth_session(request: Request) -> JSONResponse:
    """Create an HttpOnly browser auth session for the log viewer."""
    if not _is_bearer_authenticated(request):
        raise HTTPException(
            status_code=HTTPStatus.UNAUTHORIZED,
            detail="Valid bearer token is required",
        )

    response = JSONResponse({"authenticated": True})
    _issue_auth_session_cookie(request, response)
    response.headers.update(_headers())
    return response


@router.get("/api/auth/session")
async def get_log_auth_session(request: Request) -> JSONResponse:
    """Return auth-session status for gateway log viewer browsers."""
    _require_logs_auth(request)
    response = JSONResponse({"authenticated": True})
    response.headers.update(_headers())
    return response


@router.delete("/api/auth/session")
async def delete_log_auth_session(request: Request) -> Response:
    """Invalidate browser auth session cookie for the log viewer."""
    response = Response(status_code=HTTPStatus.NO_CONTENT)
    _clear_auth_session_cookie(request, response)
    response.headers.update(_headers())
    return response


@router.get("/login", include_in_schema=False)
async def serve_log_login_page() -> Response:
    """Serve a minimal login page for creating a browser auth session."""
    html = """<!doctype html>
<html lang=\"en\">
<head>
  <meta charset=\"utf-8\" />
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\" />
  <title>Obra Log Viewer Login</title>
  <style>
    body { font-family: system-ui, sans-serif; margin: 2rem; max-width: 40rem; }
    form { display: grid; gap: 0.75rem; }
    input { padding: 0.6rem; font-size: 1rem; }
    button { padding: 0.6rem 0.8rem; font-size: 1rem; }
    .error { color: #b00020; min-height: 1.25rem; }
  </style>
</head>
<body>
  <h1>Obra Log Viewer Login</h1>
  <p>Enter the gateway bearer token to create a browser session.</p>
  <form id=\"loginForm\">
    <label for=\"token\">Gateway Token</label>
    <input id=\"token\" type=\"password\" autocomplete=\"off\" required />
    <button type=\"submit\">Sign In</button>
    <div class=\"error\" id=\"error\"></div>
  </form>
  <script>
    const form = document.getElementById('loginForm');
    const tokenInput = document.getElementById('token');
    const errorEl = document.getElementById('error');

    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      errorEl.textContent = '';
      const token = tokenInput.value.trim();
      if (!token) {
        errorEl.textContent = 'Token is required.';
        return;
      }

      try {
        const response = await fetch('/logs/api/auth/session', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${token}`,
          },
          credentials: 'same-origin',
        });
        if (!response.ok) {
          errorEl.textContent = 'Authentication failed.';
          return;
        }
        tokenInput.value = '';
        window.location.assign('/logs/');
      } catch (error) {
        errorEl.textContent = 'Unable to reach gateway.';
      }
    });
  </script>
</body>
</html>
"""
    response = Response(content=html, media_type="text/html")
    response.headers.update(_headers(include_csp=True))
    return response


@router.get("/", include_in_schema=False)
async def serve_log_viewer_html(request: Request) -> Response:
    """Serve log viewer UI bytes from app state."""
    _require_logs_auth(request)
    response = Response(content=request.app.state.log_ui_bytes, media_type="text/html")
    response.headers.update(_headers(include_csp=True))
    return response


@router.get("/api/snapshot")
async def get_snapshot(
    request: Request,
    limit: int = Query(default=500, ge=1, le=5000),
) -> JSONResponse:
    """Return current merged log snapshot."""
    _require_logs_auth(request)
    snapshot = build_snapshot(
        request.app.state.log_hybrid_path,
        request.app.state.log_production_path,
        limit,
        session_index=request.app.state.log_session_index,
    )
    payload = json.loads(snapshot.to_json())
    payload = _redact_log_paths(
        payload,
        expose_absolute_paths=bool(_gateway_config(request)["logs_expose_absolute_paths"]),
    )
    response = JSONResponse(payload)
    response.headers.update(_headers())
    return response


@router.get("/api/stream")
async def stream_logs(request: Request) -> StreamingResponse:
    """Stream live log events and periodic source status updates as SSE."""
    _require_logs_auth(request)
    client_ip = _acquire_stream_slot(request)

    tailer = LogTailer(
        request.app.state.log_hybrid_path,
        request.app.state.log_production_path,
    )
    connection_started = time.monotonic()
    status_interval_s = 2.0
    stream_timeout_s = float(_gateway_config(request)["logs_stream_idle_timeout_s"])
    expose_absolute_paths = bool(_gateway_config(request)["logs_expose_absolute_paths"])

    async def _event_generator() -> AsyncIterator[str]:
        last_status_sent = 0.0
        try:
            while True:
                if await request.is_disconnected():
                    break

                now = time.monotonic()
                if now - connection_started > stream_timeout_s:
                    break

                events = await asyncio.to_thread(tailer.poll)
                if events:
                    for event in events:
                        yield _sse_frame("log", event)

                if now - last_status_sent >= status_interval_s:
                    status_payload = _status_payload(
                        request.app.state.log_hybrid_path,
                        request.app.state.log_production_path,
                    )
                    yield _sse_frame(
                        "status",
                        _redact_log_paths(
                            status_payload,
                            expose_absolute_paths=expose_absolute_paths,
                        ),
                    )
                    last_status_sent = now

                if not events:
                    await asyncio.sleep(0.5)
        finally:
            _release_stream_slot(request, client_ip)

    response = StreamingResponse(
        _event_generator(),
        media_type="text/event-stream",
        headers={
            **_headers(),
            "Connection": "keep-alive",
        },
    )
    return response


@router.get("/api/plan_snapshot")
async def get_plan_snapshot(request: Request, ref: str | None = None) -> JSONResponse:
    """Return a stored plan snapshot by reference."""
    _require_logs_auth(request)
    payload = load_plan_snapshot(ref) or {"status": "missing"}
    response = JSONResponse(payload)
    response.headers.update(_headers())
    return response


@router.get("/api/intent_snapshot")
async def get_intent_snapshot(request: Request, ref: str | None = None) -> JSONResponse:
    """Return a stored intent snapshot by reference."""
    _require_logs_auth(request)
    payload = load_intent_snapshot(ref) or {"status": "missing"}
    response = JSONResponse(payload)
    response.headers.update(_headers())
    return response
