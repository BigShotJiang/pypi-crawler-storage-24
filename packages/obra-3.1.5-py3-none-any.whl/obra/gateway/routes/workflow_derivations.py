"""Canonical Workflow Studio workflow-derivation routes."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, status
from pydantic import BaseModel, Field, field_validator

from obra.domains.resolution import DomainResolutionError
from obra.gateway.workflow_studio.derivation_actions import WorkflowDerivationActionService
from obra.gateway.workflow_studio.repository import WorkflowStudioRepository

router = APIRouter(prefix="/api/workflow-derivations", tags=["workflow-studio"])


class CreateWorkflowDerivationRequest(BaseModel):
    """Canonical public request body for derivation creation."""

    project_id: str = Field(..., min_length=1, max_length=256)
    working_dir: str | None = Field(default=None, max_length=4096)
    mission: str = Field(..., min_length=1, max_length=10_000)
    domain_id: str | None = Field(default=None, max_length=256)
    input_spec_refs: list[dict[str, Any]] = Field(default_factory=list)
    output_spec_refs: list[dict[str, Any]] = Field(default_factory=list)
    rule_pack_refs: list[dict[str, Any]] = Field(default_factory=list)
    quality_pack_refs: list[dict[str, Any]] = Field(default_factory=list)
    baseline_workflow_ref: dict[str, Any] | None = None
    example_case_refs: list[dict[str, Any]] = Field(default_factory=list)
    exception_case_refs: list[dict[str, Any]] = Field(default_factory=list)
    policy_precedence_overrides: dict[str, Any] = Field(default_factory=dict)
    operator_constraints: dict[str, Any] = Field(default_factory=dict)

    @field_validator("project_id", "working_dir", "mission", "domain_id", mode="before")
    @classmethod
    def _normalize_required_strings(cls, value: Any) -> Any:
        if isinstance(value, str):
            normalized = value.strip()
            return normalized or None
        return value


class ResumeWorkflowDerivationRequest(BaseModel):
    """Request body for derivation resume."""

    resume_target: str | None = None


class OperatorActionRequest(BaseModel):
    """Request body for derivation operator actions."""

    action: str = Field(..., max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)


class AcceptWorkflowDerivationRequest(BaseModel):
    """Request body for guarded derivation acceptance."""

    expected_baseline_ref: dict[str, Any] = Field(default_factory=dict)


@router.get("/")
async def list_workflow_derivations(request: Request) -> dict[str, object]:
    repository = WorkflowStudioRepository.from_request(request)
    return {"workflow_derivations": repository.list_derivations()}


@router.post("/", status_code=status.HTTP_201_CREATED)
async def create_workflow_derivation(
    body: CreateWorkflowDerivationRequest,
    request: Request,
    idempotency_key: str | None = Header(default=None, alias="Idempotency-Key"),
) -> dict[str, Any]:
    if not isinstance(idempotency_key, str) or not idempotency_key.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Idempotency-Key header is required",
        )

    session_manager = request.app.state.session_manager
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    if callable(client_factory):
        session_manager.set_client_factory(client_factory)

    service = WorkflowDerivationActionService(request.app.state.session_manager)
    try:
        result = service.create(
            request_payload=body.model_dump(),
            idempotency_key=idempotency_key,
            project_id=body.project_id,
            working_dir=body.working_dir,
        )
    except DomainResolutionError as exc:
        raise HTTPException(
            status_code=exc.http_status.value,
            detail=exc.to_payload(),
        ) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc

    repository = WorkflowStudioRepository.from_request(request)
    workflow_derivation = repository.get_derivation(str(result["derivation_id"]))
    return {
        **result,
        "workflow_derivation": workflow_derivation,
    }


@router.get("/{derivation_id}")
async def get_workflow_derivation(
    derivation_id: str,
    request: Request,
) -> dict[str, Any]:
    repository = WorkflowStudioRepository.from_request(request)
    workflow_derivation = repository.get_derivation(derivation_id)
    if workflow_derivation is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workflow derivation not found",
        )
    return {"workflow_derivation": workflow_derivation}


@router.post("/{derivation_id}/cancel")
async def cancel_workflow_derivation(
    derivation_id: str,
    request: Request,
) -> dict[str, Any]:
    service = WorkflowDerivationActionService(request.app.state.session_manager)
    try:
        return service.cancel(derivation_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workflow derivation not found",
        ) from exc


@router.post("/{derivation_id}/resume")
async def resume_workflow_derivation(
    derivation_id: str,
    body: ResumeWorkflowDerivationRequest,
    request: Request,
) -> dict[str, Any]:
    service = WorkflowDerivationActionService(request.app.state.session_manager)
    try:
        return service.resume(derivation_id, resume_target=body.resume_target)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workflow derivation not found",
        ) from exc


@router.post("/{derivation_id}/operator-actions")
async def perform_derivation_operator_action(
    derivation_id: str,
    body: OperatorActionRequest,
    request: Request,
) -> dict[str, Any]:
    service = WorkflowDerivationActionService(request.app.state.session_manager)
    try:
        return service.dispatch(derivation_id, action=body.action, payload=body.payload)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workflow derivation not found",
        ) from exc


@router.post("/{derivation_id}/accept")
async def accept_workflow_derivation(
    derivation_id: str,
    body: AcceptWorkflowDerivationRequest,
    request: Request,
) -> dict[str, Any]:
    service = WorkflowDerivationActionService(request.app.state.session_manager)
    try:
        result = service.accept(
            derivation_id,
            expected_baseline_ref=body.expected_baseline_ref,
        )
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Workflow derivation not found",
        ) from exc
    if result.get("status") == "conflict":
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=result)
    return result
