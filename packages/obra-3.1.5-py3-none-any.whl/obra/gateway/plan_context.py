"""Gateway plan-context loading and hydration helpers extracted from session_manager.py."""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

import yaml

from obra.gateway.session_helpers import _string_or_none

logger = logging.getLogger(__name__)


def _ensure_gateway_userplan(
    *,
    objective: str,
    project_id: str,
    session_id: str,
    request_context: dict[str, Any],
    client_factory: Callable[[], Any] | None = None,
) -> str:
    """Create and persist the internal UserPlan required by derive/intake flows."""
    existing_userplan_id = _string_or_none(request_context.get("userplan_id"))
    if existing_userplan_id is not None:
        return existing_userplan_id

    from obra.execution.userplan_construction import create_userplan_from_objective_text
    from obra.execution.userplan_persistence import persist_userplan_via_api

    userplan = create_userplan_from_objective_text(
        objective=objective,
        project_id=project_id,
        session_id=session_id,
    )
    from obra.api import APIClient

    userplan_client = client_factory() if callable(client_factory) else APIClient.from_config()
    persist_userplan_via_api(
        userplan,
        client=userplan_client,
    )
    return userplan.id


def _load_gateway_workflow_run_plan_context(
    *,
    objective: str,
    working_dir: str,
    workflow_id: str | None,
    revision_id: str | None,
    domain_id: str | None,
    client_factory: Callable[[], Any] | None = None,
) -> dict[str, Any] | None:
    """Load canonical local plan context for workflow-backed gateway runs."""
    if _string_or_none(workflow_id) is None:
        return None

    plan_path = Path(working_dir).expanduser().resolve() / "WORKFLOW_PLAN.json"
    if plan_path.exists():
        plan_data = _load_gateway_plan_file(plan_path)
        plan_context = _extract_gateway_plan_context(plan_data, str(plan_path))
    else:
        plan_context = _load_gateway_remote_workflow_run_plan_context(
            objective=objective,
            workflow_id=workflow_id,
            revision_id=revision_id,
            domain_id=domain_id,
            client_factory=client_factory,
        )
        if plan_context is None:
            return None
    normalized_domain = _string_or_none(domain_id)
    normalized_workflow_id = _string_or_none(workflow_id)
    normalized_revision_id = _string_or_none(revision_id)
    return _hydrate_gateway_workflow_run_plan_context(
        plan_context=plan_context,
        objective=objective,
        workflow_id=normalized_workflow_id,
        revision_id=normalized_revision_id,
        domain_id=normalized_domain,
    )


def _load_gateway_remote_workflow_run_plan_context(
    *,
    objective: str,
    workflow_id: str | None,
    revision_id: str | None,
    domain_id: str | None,
    client_factory: Callable[[], Any] | None = None,
) -> dict[str, Any] | None:
    normalized_workflow_id = _string_or_none(workflow_id)
    if normalized_workflow_id is None:
        return None

    from obra.api import APIClient

    client = client_factory() if callable(client_factory) else APIClient.from_config()
    try:
        if _string_or_none(revision_id) is not None:
            response = client.get_workflow_revision(
                normalized_workflow_id,
                _string_or_none(revision_id) or "",
            )
            workflow_revision = (
                response.get("workflow_revision")
                if isinstance(response.get("workflow_revision"), dict)
                else {}
            )
        else:
            response = client.get_workflow(normalized_workflow_id)
            workflow_revision = (
                response.get("workflow")
                if isinstance(response.get("workflow"), dict)
                else {}
            )
    except Exception as exc:
        logger.debug(
            "Workflow revision-backed run context unavailable for %s/%s: %s",
            normalized_workflow_id,
            revision_id,
            exc,
        )
        return None

    workflow_definition = (
        workflow_revision.get("workflow_definition")
        if isinstance(workflow_revision.get("workflow_definition"), dict)
        else {}
    )
    if not workflow_definition:
        return None

    resolved_title = (
        _string_or_none(workflow_revision.get("title"))
        or _string_or_none(workflow_definition.get("title"))
        or objective
    )
    resolved_description = (
        _string_or_none(workflow_revision.get("description"))
        or _string_or_none(workflow_definition.get("description"))
        or resolved_title
    )
    resolved_domain_id = (
        _string_or_none(domain_id)
        or _string_or_none(workflow_revision.get("domain_id"))
        or _string_or_none(workflow_definition.get("domain_id"))
    )
    resolved_revision_id = (
        _string_or_none(revision_id)
        or _string_or_none(workflow_revision.get("revision_id"))
        or _string_or_none(workflow_revision.get("head_revision_id"))
    )
    return {
        "objective": objective,
        "title": resolved_title,
        "description": resolved_description,
        "workflow_definition": dict(workflow_definition),
        "workflow_source_summary": {
            "workflow_id": normalized_workflow_id,
            "title": resolved_title,
            "description": resolved_description,
            "domain_id": resolved_domain_id,
            "quality_dimensions": list(workflow_definition.get("quality_dimensions") or []),
            "lifecycle_capabilities": list(
                workflow_definition.get("lifecycle_capabilities") or []
            ),
            "lifecycle": (
                dict(workflow_definition.get("lifecycle"))
                if isinstance(workflow_definition.get("lifecycle"), dict)
                else {}
            ),
        },
        "workflow_source_artifact": {
            "artifact_id": normalized_workflow_id,
            "version": resolved_revision_id or "current",
            "domain_id": resolved_domain_id,
            "title": resolved_title,
            "description": resolved_description,
            "synthesis_mode": str(workflow_definition.get("source_mode") or ""),
        },
        "workflow_artifact_id": normalized_workflow_id,
    }


def _hydrate_gateway_workflow_run_plan_context(
    *,
    plan_context: dict[str, Any],
    objective: str,
    workflow_id: str | None,
    revision_id: str | None,
    domain_id: str | None,
) -> dict[str, Any]:
    hydrated = dict(plan_context)
    workflow_definition = (
        dict(hydrated.get("workflow_definition"))
        if isinstance(hydrated.get("workflow_definition"), dict)
        else {}
    )
    if workflow_definition:
        if workflow_id is not None:
            workflow_definition["workflow_id"] = workflow_id
        if domain_id is not None:
            workflow_definition.setdefault("domain_id", domain_id)
        hydrated["workflow_definition"] = workflow_definition

    if workflow_id is not None:
        hydrated["workflow_id"] = workflow_id
        hydrated.setdefault("workflow_artifact_id", workflow_id)
    if revision_id is not None:
        hydrated["revision_id"] = revision_id
    if domain_id is not None:
        hydrated["domain_id"] = domain_id
    hydrated["objective"] = objective

    workflow_source_summary = (
        dict(hydrated.get("workflow_source_summary"))
        if isinstance(hydrated.get("workflow_source_summary"), dict)
        else {}
    )
    if workflow_source_summary or workflow_definition:
        workflow_source_summary.setdefault(
            "title",
            hydrated.get("title") or workflow_definition.get("title") or objective,
        )
        workflow_source_summary.setdefault(
            "description",
            hydrated.get("description")
            or workflow_definition.get("description")
            or workflow_source_summary.get("title")
            or objective,
        )
        if workflow_id is not None:
            workflow_source_summary["workflow_id"] = workflow_id
        if domain_id is not None:
            workflow_source_summary.setdefault("domain_id", domain_id)
        workflow_source_summary.setdefault(
            "quality_dimensions",
            list(workflow_definition.get("quality_dimensions") or []),
        )
        workflow_source_summary.setdefault(
            "lifecycle_capabilities",
            list(workflow_definition.get("lifecycle_capabilities") or []),
        )
        if isinstance(workflow_definition.get("lifecycle"), dict):
            workflow_source_summary.setdefault(
                "lifecycle",
                dict(workflow_definition.get("lifecycle")),
            )
        hydrated["workflow_source_summary"] = workflow_source_summary

    workflow_source_artifact = (
        dict(hydrated.get("workflow_source_artifact"))
        if isinstance(hydrated.get("workflow_source_artifact"), dict)
        else {}
    )
    workflow_source_artifact["artifact_id"] = workflow_id or workflow_source_artifact.get(
        "artifact_id"
    )
    workflow_source_artifact["version"] = revision_id or workflow_source_artifact.get(
        "version"
    ) or "current"
    if domain_id is not None:
        workflow_source_artifact.setdefault("domain_id", domain_id)
    workflow_source_artifact.setdefault(
        "title",
        hydrated.get("title")
        or workflow_definition.get("title")
        or workflow_source_summary.get("title")
        or objective,
    )
    workflow_source_artifact.setdefault(
        "description",
        hydrated.get("description")
        or workflow_definition.get("description")
        or workflow_source_summary.get("description")
        or workflow_source_artifact.get("title")
        or objective,
    )
    workflow_source_artifact.setdefault(
        "synthesis_mode",
        str(workflow_definition.get("source_mode") or ""),
    )
    hydrated["workflow_source_artifact"] = workflow_source_artifact

    resolved_context_domain_id = (
        domain_id
        or _string_or_none(workflow_definition.get("domain_id"))
        or _string_or_none(workflow_source_summary.get("domain_id"))
        or _string_or_none(workflow_source_artifact.get("domain_id"))
    )
    if resolved_context_domain_id is not None:
        hydrated["domain_id"] = resolved_context_domain_id

    if workflow_id is not None:
        hydrated.setdefault(
            "baseline_workflow_ref",
            {
                "target_artifact_type": "workflow_baseline",
                "target_artifact_id": workflow_id,
                "target_version_selector": revision_id or "current",
                "relationship_type": "derived_from",
                "metadata": {
                    "workflow_id": workflow_id,
                    "revision_id": revision_id or "current",
                    "domain_id": resolved_context_domain_id or "",
                },
            },
        )

    from obra.execution.intake import materialize_workflow_derivation_request

    workflow_derivation_request = materialize_workflow_derivation_request(
        objective=objective,
        domain_id=domain_id,
        plan_context=hydrated,
    )
    if workflow_derivation_request is not None:
        hydrated["workflow_derivation_request"] = workflow_derivation_request
    return hydrated


def _load_gateway_plan_file(plan_path: Path) -> Any:
    """Load a gateway-local workflow plan from JSON or YAML."""
    try:
        with plan_path.open(encoding="utf-8") as handle:
            try:
                return json.load(handle)
            except json.JSONDecodeError:
                handle.seek(0)
                return yaml.safe_load(handle)
    except OSError as exc:
        msg = f"Failed to read workflow plan {plan_path}: {exc}"
        raise ValueError(msg) from exc
    except yaml.YAMLError as exc:
        msg = f"Workflow plan is not valid YAML: {plan_path} ({exc})"
        raise ValueError(msg) from exc
    except UnicodeDecodeError as exc:
        msg = f"Workflow plan encoding error (expected UTF-8): {plan_path} ({exc})"
        raise ValueError(msg) from exc


def _extract_gateway_plan_context(plan_data: Any, source: str) -> dict[str, Any]:
    """Validate the minimal imported-plan shape required by gateway workflow runs."""
    if plan_data is None or not isinstance(plan_data, dict):
        msg = f"Plan file must be a JSON/YAML object: {source}"
        raise ValueError(msg)

    epics = plan_data.get("epics")
    if not isinstance(epics, list) or not epics:
        msg = f"Plan file missing 'epics' array: {source}"
        raise ValueError(msg)

    for epic in epics:
        if not isinstance(epic, dict):
            msg = f"Plan file contains an invalid epic entry: {source}"
            raise ValueError(msg)
        stories = epic.get("stories")
        if not isinstance(stories, list) or not stories:
            msg = f"Epic {epic.get('id', '<unknown>')} missing 'stories' array: {source}"
            raise ValueError(msg)
        for story in stories:
            if not isinstance(story, dict):
                msg = f"Plan file contains an invalid story entry: {source}"
                raise ValueError(msg)
            tasks = story.get("tasks")
            if tasks is None or not isinstance(tasks, list):
                msg = (
                    f"Story {story.get('id', '<unknown>')} missing valid 'tasks' array: {source}"
                )
                raise ValueError(msg)

    plan_context = dict(plan_data)
    plan_context["epics"] = epics
    plan_context["_obra_plan_source_path"] = source
    return plan_context


def _install_gateway_imported_plan_handler(
    orchestrator: Any,
    plan_context: dict[str, Any],
) -> None:
    """Mirror the CLI imported-plan derive handler for gateway workflow runs."""
    from obra.api.protocol import ActionType
    from obra.hybrid.handlers.imported_plan import ImportedPlanDeriveHandler

    handlers = getattr(orchestrator, "_handlers", None)
    if not isinstance(handlers, dict):
        handlers = {}
        orchestrator._handlers = handlers
    handlers[ActionType.DERIVE] = ImportedPlanDeriveHandler(plan_context)
    orchestrator._imported_plan_context = plan_context
