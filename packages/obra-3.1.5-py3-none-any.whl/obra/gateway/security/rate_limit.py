"""Rate-limiting primitives for gateway REST and WebSocket traffic."""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass


@dataclass
class _Bucket:
    tokens: float
    last_refill_at: float
    last_seen_at: float


class TokenBucketRateLimiter:
    """Thread-safe token-bucket limiter keyed by caller identity."""

    def __init__(
        self,
        *,
        rate_per_minute: int,
        burst: int,
    ) -> None:
        if rate_per_minute <= 0:
            msg = "rate_per_minute must be > 0"
            raise ValueError(msg)
        if burst <= 0:
            msg = "burst must be > 0"
            raise ValueError(msg)

        self._rate_per_second = float(rate_per_minute) / 60.0
        self._burst = float(burst)
        self._buckets: dict[str, _Bucket] = {}
        self._lock = threading.Lock()
        self._last_cleanup_at = 0.0

        # Bounded map strategy: remove stale keys and cap retained bucket count.
        self._max_idle_seconds = (self._burst / self._rate_per_second) * 4.0
        self._cleanup_interval_seconds = self._max_idle_seconds / 4.0
        self._max_buckets = max(1, int((rate_per_minute + burst) * 20))

    def allow(self, key: str) -> bool:
        """Return True when request is allowed, False when throttled."""
        now = time.monotonic()
        with self._lock:
            self._cleanup(now)

            bucket = self._buckets.get(key)
            if bucket is None:
                bucket = _Bucket(
                    tokens=self._burst,
                    last_refill_at=now,
                    last_seen_at=now,
                )
                self._buckets[key] = bucket
            else:
                elapsed = now - bucket.last_refill_at
                if elapsed > 0:
                    bucket.tokens = min(
                        self._burst,
                        bucket.tokens + (elapsed * self._rate_per_second),
                    )
                    bucket.last_refill_at = now
                bucket.last_seen_at = now

            self._enforce_bucket_bound()

            if bucket.tokens >= 1.0:
                bucket.tokens -= 1.0
                return True
            return False

    def _cleanup(self, now: float) -> None:
        if now - self._last_cleanup_at < self._cleanup_interval_seconds:
            return
        self._last_cleanup_at = now

        stale_keys = [
            key
            for key, bucket in self._buckets.items()
            if (now - bucket.last_seen_at) > self._max_idle_seconds
        ]
        for key in stale_keys:
            self._buckets.pop(key, None)

        self._enforce_bucket_bound()

    def _enforce_bucket_bound(self) -> None:
        if len(self._buckets) <= self._max_buckets:
            return

        overflow = len(self._buckets) - self._max_buckets
        oldest_keys = sorted(
            self._buckets.items(),
            key=lambda item: item[1].last_seen_at,
        )[:overflow]
        for key, _ in oldest_keys:
            self._buckets.pop(key, None)
