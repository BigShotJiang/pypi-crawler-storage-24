"""Bearer token authentication for the gateway server."""

from __future__ import annotations

import asyncio
import hmac
import os
import secrets
from typing import Callable

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from obra.gateway.automation.profile import (
    OBRA_GATEWAY_AUTH_TOKEN_ENV,
    GatewayAutomationProfile,
)

_bearer_scheme = HTTPBearer(auto_error=False)


def verify_token(credentials: HTTPAuthorizationCredentials, expected_token: str) -> bool:
    """Verify bearer token using constant-time comparison.

    Args:
        credentials: The HTTP authorization credentials.
        expected_token: The expected token to compare against.

    Returns:
        True if token matches, False otherwise.
    """
    return hmac.compare_digest(credentials.credentials, expected_token)


def get_auth_dependency(token: str) -> Callable:
    """Create a FastAPI dependency that validates bearer token auth.

    Args:
        token: The expected bearer token.

    Returns:
        A FastAPI Depends callable that raises 401 on invalid/missing tokens.
    """

    async def _verify(
        request: Request,
        credentials: HTTPAuthorizationCredentials | None = Depends(_bearer_scheme),
    ) -> HTTPAuthorizationCredentials:
        from obra.gateway.studio_browser import is_studio_browser_authenticated_request

        browser_rig_faults_enabled = bool(
            getattr(request.app.state, "workflow_studio_browser_faults_enabled", False)
        )
        rig_fault_state = getattr(request.app.state, "workflow_studio_browser_fault_state", None)
        if (
            browser_rig_faults_enabled
            and isinstance(rig_fault_state, dict)
            and request.url.path.startswith("/api/")
        ):
            http_delay_ms = max(0, int(rig_fault_state.get("http_delay_ms", 0) or 0))
            if http_delay_ms > 0:
                await asyncio.sleep(http_delay_ms / 1000)

            unauthorized_remaining = max(
                0,
                int(rig_fault_state.get("unauthorized_requests_remaining", 0) or 0),
            )
            unauthorized_path_prefix = str(
                rig_fault_state.get("unauthorized_path_prefix", "") or ""
            ).strip()
            matches_unauthorized_path = (
                not unauthorized_path_prefix
                or request.url.path.startswith(unauthorized_path_prefix)
            )
            if unauthorized_remaining > 0 and matches_unauthorized_path:
                rig_fault_state["unauthorized_requests_remaining"] = (
                    unauthorized_remaining - 1
                )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication failed",
                )
        if credentials is not None and verify_token(credentials, token):
            return credentials
        if is_studio_browser_authenticated_request(request):
            return HTTPAuthorizationCredentials(scheme="Cookie", credentials="")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing authentication token",
        )

    return _verify


def generate_token() -> str:
    """Generate a cryptographically secure URL-safe token.

    Returns:
        A 32-byte URL-safe token string.
    """
    return secrets.token_urlsafe(32)


def resolve_gateway_auth_token(
    config: dict[str, object],
    *,
    profile: GatewayAutomationProfile,
) -> tuple[str, str]:
    """Resolve auth token according to the active gateway profile."""
    env_token = os.getenv(OBRA_GATEWAY_AUTH_TOKEN_ENV, "").strip()
    if env_token:
        return env_token, "env"

    configured_token = str(config.get("auth_token") or "").strip()
    if configured_token:
        return configured_token, "config"

    if profile.require_explicit_auth_token:
        raise ValueError(
            "Private automation profile requires an explicit gateway bearer token. "
            "Set OBRA_GATEWAY_AUTH_TOKEN or gateway.auth_token before startup."
        )

    return generate_token(), "generated"
