"""Workspace resolution owners for automation-facing gateway flows."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable

from fastapi import Request

from obra.gateway.session_helpers import _validate_working_dir


@dataclass(frozen=True)
class WorkspaceResolution:
    """Resolved project/workspace launch context."""

    project_id: str
    working_dir: str
    source: str
    stored_working_dir: str | None = None

    def to_payload(self) -> dict[str, str | None]:
        return {
            "project_id": self.project_id,
            "working_dir": self.working_dir,
            "source": self.source,
            "stored_working_dir": self.stored_working_dir,
        }


def resolve_gateway_workspace(
    *,
    project_id: str,
    working_dir: str | None,
    allowed_base: Path,
    client_factory: Callable[[], Any] | None = None,
) -> WorkspaceResolution:
    """Resolve the canonical gateway workspace for automation-owned flows."""
    normalized_project_id = _normalize_required_string(project_id, field_name="project_id")
    allowed_base_resolved = allowed_base.expanduser().resolve()

    explicit_working_dir = _normalize_optional_string(working_dir)
    if explicit_working_dir is not None:
        resolved = _validate_working_dir(explicit_working_dir, allowed_base_resolved)
        return WorkspaceResolution(
            project_id=normalized_project_id,
            working_dir=str(resolved),
            source="explicit_working_dir",
        )

    project_metadata_dir = _resolve_project_metadata_working_dir(
        normalized_project_id,
        allowed_base=allowed_base_resolved,
        client_factory=client_factory,
    )
    if project_metadata_dir is not None:
        return WorkspaceResolution(
            project_id=normalized_project_id,
            working_dir=str(project_metadata_dir),
            source="project_metadata",
            stored_working_dir=str(project_metadata_dir),
        )

    candidate = allowed_base_resolved / normalized_project_id
    if candidate.exists():
        resolved = _validate_working_dir(str(candidate), allowed_base_resolved)
        return WorkspaceResolution(
            project_id=normalized_project_id,
            working_dir=str(resolved),
            source="allowed_base_project_id",
        )

    raise ValueError(
        f"No working directory is configured for project '{normalized_project_id}'. "
        "Set the project's working_directory or pass working_dir explicitly."
    )


def resolve_gateway_workspace_from_request(
    request: Request,
    *,
    project_id: str,
    working_dir: str | None,
) -> WorkspaceResolution:
    """Resolve workspace precedence from request-bound gateway state."""
    gateway_config = getattr(request.app.state, "gateway_config", {})
    allowed_base = Path(
        str(gateway_config.get("allowed_working_dir_base", "~/obra-projects"))
    )
    client_factory = getattr(request.app.state, "workflow_studio_client_factory", None)
    return resolve_gateway_workspace(
        project_id=project_id,
        working_dir=working_dir,
        allowed_base=allowed_base,
        client_factory=client_factory if callable(client_factory) else None,
    )


def _resolve_project_metadata_working_dir(
    project_id: str,
    *,
    allowed_base: Path,
    client_factory: Callable[[], Any] | None = None,
) -> Path | None:
    client = _create_api_client(client_factory)
    if client is None:
        return None
    try:
        project = client.get_project(project_id)
    except Exception:
        return None
    configured = _normalize_optional_string(
        project.get("working_directory") or project.get("working_dir")
    )
    if configured is None:
        return None
    return _validate_working_dir(configured, allowed_base)


def _create_api_client(client_factory: Callable[[], Any] | None) -> Any | None:
    if callable(client_factory):
        return client_factory()
    try:
        from obra.api import APIClient
    except Exception:
        return None
    try:
        return APIClient.from_config()
    except Exception:
        return None


def _normalize_optional_string(value: Any) -> str | None:
    if isinstance(value, str):
        normalized = value.strip()
        if normalized:
            return normalized
    return None


def _normalize_required_string(value: Any, *, field_name: str) -> str:
    normalized = _normalize_optional_string(value)
    if normalized is None:
        raise ValueError(f"{field_name} is required")
    return normalized
