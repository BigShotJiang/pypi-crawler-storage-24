"""Automation-facing gateway owners for the private operator contract."""

from __future__ import annotations

from importlib import import_module
from typing import Any

__all__ = [
    "GATEWAY_PROFILE_PRIVATE_AUTOMATION",
    "GATEWAY_PROFILE_STANDARD",
    "GatewayAutomationControlSurface",
    "GatewayAutomationProfile",
    "WorkspaceResolution",
    "resolve_gateway_automation_profile",
    "resolve_gateway_workspace",
]

_EXPORT_MAP = {
    "GATEWAY_PROFILE_PRIVATE_AUTOMATION": (".profile", "GATEWAY_PROFILE_PRIVATE_AUTOMATION"),
    "GATEWAY_PROFILE_STANDARD": (".profile", "GATEWAY_PROFILE_STANDARD"),
    "GatewayAutomationControlSurface": (".control_surface", "GatewayAutomationControlSurface"),
    "GatewayAutomationProfile": (".profile", "GatewayAutomationProfile"),
    "WorkspaceResolution": (".workspaces", "WorkspaceResolution"),
    "resolve_gateway_automation_profile": (".profile", "resolve_gateway_automation_profile"),
    "resolve_gateway_workspace": (".workspaces", "resolve_gateway_workspace"),
}


def __getattr__(name: str) -> Any:
    if name not in _EXPORT_MAP:
        raise AttributeError(name)
    module_name, attr_name = _EXPORT_MAP[name]
    module = import_module(module_name, __name__)
    value = getattr(module, attr_name)
    globals()[name] = value
    return value
