"""Codebase context collection for exploration prompt injection.

Extracted from DeriveHandler._collect_codebase_context() and related
methods as part of REFACTOR-EXPLORATION-001.

Gathers directory tree, file summary by extension, and key file contents
from a working directory. All limits are config-wired under
orchestration.exploration.context.

Related:
    - obra/config/default_config.yaml (orchestration.exploration.context)
    - docs/decisions/ADR-055-conditional-auto-exploration.md
"""

import fnmatch
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


def collect_codebase_context(working_dir: Path, context_config: dict[str, Any]) -> str:
    """Collect codebase context for exploration prompt injection.

    Gathers directory tree, file listing by extension, and key file
    contents from the working directory. All limits are config-wired.

    Args:
        working_dir: Project working directory
        context_config: Context sub-config from orchestration.exploration.context

    Returns:
        Formatted codebase context string for prompt injection
    """
    tree_max_depth = context_config["tree_max_depth"]
    tree_max_entries = context_config["tree_max_entries"]
    key_file_patterns = context_config["key_file_patterns"]
    key_file_max_lines = context_config["key_file_max_lines"]
    max_context_chars = context_config["max_context_chars"]

    sections: list[str] = []

    # 1. Directory tree
    tree = build_directory_tree(working_dir, tree_max_depth, tree_max_entries)
    if tree:
        sections.append(f"#### Directory Structure\n```\n{tree}\n```")

    # 2. File listing by extension
    file_summary = build_file_summary(working_dir)
    if file_summary:
        sections.append(f"#### File Summary\n{file_summary}")

    # 3. Key file contents
    key_contents = read_key_files(working_dir, key_file_patterns, key_file_max_lines)
    if key_contents:
        sections.append(f"#### Key Files\n{key_contents}")

    context = "\n\n".join(sections)

    # Bound total context size
    if len(context) > max_context_chars:
        context = context[:max_context_chars] + "\n... (context truncated)"

    return context


def build_directory_tree(working_dir: Path, max_depth: int, max_entries: int) -> str:
    """Build a directory tree string for the working directory.

    Recursively walks the directory tree, skipping excluded directories
    and patterns. Entries are sorted with directories first, then by name.

    Args:
        working_dir: Root directory to build tree from
        max_depth: Maximum depth to traverse
        max_entries: Maximum total entries to include

    Returns:
        Formatted directory tree string
    """
    from obra.intent.detection import EXCLUDED_DIRS, EXCLUDED_PATTERNS

    lines: list[str] = []
    entry_count = 0

    def _walk(directory: Path, prefix: str, depth: int) -> None:
        nonlocal entry_count
        if depth > max_depth or entry_count >= max_entries:
            return

        try:
            entries = sorted(
                directory.iterdir(), key=lambda e: (not e.is_dir(), e.name)
            )
        except (PermissionError, OSError):
            return

        for entry in entries:
            if entry_count >= max_entries:
                lines.append(f"{prefix}... ({max_entries} entry limit reached)")
                return

            if entry.is_dir():
                if entry.name in EXCLUDED_DIRS:
                    continue
                lines.append(f"{prefix}{entry.name}/")
                entry_count += 1
                _walk(entry, prefix + "  ", depth + 1)
            elif entry.is_file():
                if any(pattern in entry.name for pattern in EXCLUDED_PATTERNS):
                    continue
                lines.append(f"{prefix}{entry.name}")
                entry_count += 1

    _walk(working_dir, "", 0)
    return "\n".join(lines)


def build_file_summary(working_dir: Path, max_files: int = 10000) -> str:
    """Build a file count summary grouped by extension.

    Uses walk_project_files() from the unified walker to iterate files,
    groups by suffix, and outputs extension counts sorted by count descending.

    Args:
        working_dir: Root directory to summarize
        max_files: Stop counting after this many files to bound runtime

    Returns:
        Formatted summary like "- .py: 15 files\\n- .yaml: 3 files"
    """
    from obra.exploration.walker import walk_project_files

    ext_counts: dict[str, int] = {}
    total_counted = 0
    capped = False

    for item in walk_project_files(working_dir, max_files=max_files):
        ext = item.suffix.lower() if item.suffix else "(no extension)"
        ext_counts[ext] = ext_counts.get(ext, 0) + 1
        total_counted += 1
        if total_counted >= max_files:
            capped = True
            break

    if not ext_counts:
        return ""

    # Sort by count descending
    sorted_exts = sorted(ext_counts.items(), key=lambda x: -x[1])
    lines = [f"- {ext}: {count} file{'s' if count != 1 else ''}" for ext, count in sorted_exts]
    total = sum(ext_counts.values())
    suffix = "+" if capped else ""
    lines.append(f"- **Total**: {total}{suffix} files")
    return "\n".join(lines)


def read_key_files(working_dir: Path, patterns: list[str], max_lines: int) -> str:
    """Read contents of key project files matching patterns.

    Matches files in the root directory only (key files are typically
    top-level). Uses fnmatch for pattern matching.

    Args:
        working_dir: Root directory to search for key files
        patterns: Glob patterns for key files (e.g., ["README*", "pyproject.toml"])
        max_lines: Maximum lines to read from each file

    Returns:
        Formatted key file contents
    """
    sections: list[str] = []
    seen_files: set[str] = set()

    for pattern in patterns:
        try:
            for item in working_dir.iterdir():
                if not item.is_file():
                    continue
                if not fnmatch.fnmatch(item.name, pattern):
                    continue

                rel_path = str(item.relative_to(working_dir))
                if rel_path in seen_files:
                    continue
                seen_files.add(rel_path)

                try:
                    content_lines = item.read_text(
                        encoding="utf-8", errors="replace"
                    ).splitlines()[:max_lines]
                    content = "\n".join(content_lines)
                    if len(content_lines) == max_lines:
                        content += f"\n... (first {max_lines} lines)"
                    sections.append(f"##### {rel_path}\n```\n{content}\n```")
                except (PermissionError, OSError):
                    continue
        except (PermissionError, OSError):
            continue

    return "\n\n".join(sections)
