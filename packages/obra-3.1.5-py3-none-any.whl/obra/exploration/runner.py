"""Exploration runner: LLM-based codebase exploration (ADR-055).

Extracted from DeriveHandler._run_exploration() and
DeriveHandler._parse_exploration_response() as part of
REFACTOR-EXPLORATION-001.

Runs codebase exploration by collecting local context, building a prompt,
invoking an LLM, and parsing the structured JSON response.

Bug fixes:
    - P0: Constraint dicts properly stringified via key extraction
      (c.get('rule') or c.get('description') or c.get('constraint') or str(c))

Related:
    - docs/decisions/ADR-055-conditional-auto-exploration.md
"""

import contextlib
import logging
from collections.abc import Callable
from pathlib import Path
from time import perf_counter
from typing import Any

from obra.display import print_info, print_warning
from obra.exploration.config import get_exploration_config
from obra.exploration.context import collect_codebase_context
from obra.exploration.models import ExplorationContext

logger = logging.getLogger(__name__)


def run_exploration(
    objective: str,
    work_type: str,
    working_dir: Path,
    *,
    derive_llm_config: dict[str, Any] | None = None,
    log_event: Callable[..., None] | None = None,
    trace_id: str | None = None,
    parent_span_id: str | None = None,
) -> ExplorationContext:
    """Run codebase exploration using fast tier model (ADR-055).

    Collects codebase context (directory tree, file summary, key files)
    via Python file-system operations, then sends to LLM for analysis
    in a single inference call (mode="text", no tool use required).

    Args:
        objective: User objective text
        work_type: Detected work type
        working_dir: Project working directory
        derive_llm_config: Optional derive LLM config for provider/model overrides
        log_event: Optional event logging callback
        trace_id: Optional trace ID for observability
        parent_span_id: Optional parent span ID for observability

    Returns:
        ExplorationContext with discovered patterns and utilities
    """
    from obra.config.llm import resolve_action_llm_config
    from obra.llm.cli_runner import invoke_llm_via_cli
    from obra.prompts.derive.exploration import build_exploration_prompt

    start_time = perf_counter()
    exploration_config = get_exploration_config()

    # Get config values (wired from config, validated in get_exploration_config)
    timeout_s = exploration_config["timeout_s"]
    max_relevant_files = exploration_config["max_relevant_files"]
    model_tier = exploration_config["model_tier"]
    context_config = exploration_config["context"]

    logger.info(
        "Starting auto-exploration: objective=%s..., work_type=%s, timeout=%ds",
        objective[:50],
        work_type,
        timeout_s,
    )
    print_info(f"Running codebase exploration (timeout: {timeout_s}s)...")

    try:
        # Collect codebase context via Python file-system operations
        codebase_context = collect_codebase_context(working_dir, context_config)
        context_chars = len(codebase_context)
        logger.info("Codebase context collected: %d chars", context_chars)

        # Build exploration prompt with injected codebase context
        prompt = build_exploration_prompt(
            objective=objective,
            work_type=work_type,
            working_dir=str(working_dir),
            max_relevant_files=max_relevant_files,
            codebase_context=codebase_context,
        )

        # Resolve exploration model using derive action profile and active
        # derive config overrides so exploration stays aligned with the run.
        override_provider: str | None = None
        override_auth_method: str | None = None
        override_model: str | None = None

        if derive_llm_config is not None:
            override_provider = derive_llm_config.get("provider")
            override_auth_method = derive_llm_config.get("auth_method")

            if model_tier == "fast":
                fast_model = derive_llm_config.get("fast_model")
                if isinstance(fast_model, str) and fast_model.strip():
                    override_model = fast_model.strip()
            elif model_tier == "high":
                high_model = derive_llm_config.get("high_model")
                if isinstance(high_model, str) and high_model.strip():
                    override_model = high_model.strip()

        tier_config = resolve_action_llm_config(
            "derive",
            model_tier=model_tier,
            override_provider=(
                override_provider if isinstance(override_provider, str) else None
            ),
            override_model=override_model,
            override_auth_method=(
                override_auth_method if isinstance(override_auth_method, str) else None
            ),
        )

        provider = tier_config["provider"]
        model = tier_config["model"]
        auth_method = tier_config.get("auth_method", "oauth")

        logger.debug(
            "Exploration using provider=%s, model=%s, auth=%s",
            provider,
            model,
            auth_method,
        )

        # Invoke LLM for exploration
        raw_response = invoke_llm_via_cli(
            prompt=prompt,
            provider=provider,
            model=model,
            cwd=working_dir,
            reasoning_level="low",
            timeout_s=timeout_s,
            auth_method=auth_method,
            trace_id=trace_id,
        )

        # Parse JSON response
        context = parse_exploration_response(raw_response)
        context.duration_seconds = perf_counter() - start_time

        # Log exploration results
        _log_exploration_result(context, log_event, trace_id, parent_span_id)

        return context

    except Exception as e:
        duration = perf_counter() - start_time
        logger.warning(
            "Exploration failed after %.1fs: %s. Continuing without exploration context.",
            duration,
            str(e),
        )

        if log_event:
            with contextlib.suppress(TypeError):
                log_event(
                    "exploration_failed",
                    error=str(e),
                    duration_seconds=duration,
                    trace_id=trace_id,
                    parent_span_id=parent_span_id,
                )

        return ExplorationContext.from_error(str(e), duration)


def parse_exploration_response(raw_response: str) -> ExplorationContext:
    """Parse exploration LLM response into ExplorationContext.

    Bug fix: Constraint dicts are properly stringified via key extraction
    instead of using plain str(c) which produces ugly repr output.

    Args:
        raw_response: Raw LLM response (expected JSON format)

    Returns:
        ExplorationContext with parsed patterns and utilities
    """
    from obra.config.loaders import get_derive_raw_response_log_preview
    from obra.hybrid.json_utils import parse_planning_json_response

    if not raw_response or not raw_response.strip():
        logger.warning("Empty exploration response")
        return ExplorationContext.from_error("Empty exploration response")

    data, error_reason = parse_planning_json_response(raw_response)
    if error_reason:
        logger.warning("Failed to parse exploration JSON: %s", error_reason)
        logger.debug(
            "Raw exploration response: %s",
            raw_response[: get_derive_raw_response_log_preview()],
        )
        return ExplorationContext.from_error(
            f"Failed to parse exploration JSON: {error_reason}"
        )

    if not isinstance(data, dict):
        logger.warning("Exploration response is not a dict: %s", type(data))
        return ExplorationContext.from_error(
            f"Exploration response is not a dict: {type(data)}"
        )

    # Extract fields with defaults
    patterns = data.get("patterns", [])
    if not isinstance(patterns, list):
        patterns = []

    relevant_files = data.get("relevant_files", [])
    if not isinstance(relevant_files, list):
        relevant_files = []

    utilities = data.get("utilities", [])
    if not isinstance(utilities, list):
        utilities = []

    constraints = data.get("constraints", [])
    if not isinstance(constraints, list):
        constraints = []
    # P0 fix: extract meaningful text from constraint dicts instead of str(c)
    constraints = [
        (
            c if isinstance(c, str)
            else c.get("rule") or c.get("description") or c.get("constraint") or str(c)
        )
        for c in constraints
        if isinstance(c, (str, dict))
    ]

    # Normalize list elements: LLM may return strings instead of dicts
    patterns = [
        e if isinstance(e, dict) else {"pattern": e, "description": ""}
        for e in patterns
        if isinstance(e, (dict, str))
    ]
    normalized_relevant_files: list[dict[str, str]] = []
    for entry in relevant_files:
        if isinstance(entry, str):
            path = entry.strip()
            if path:
                normalized_relevant_files.append({"path": path, "reason": ""})
            continue
        if not isinstance(entry, dict):
            continue
        raw_path = entry.get("path")
        if not isinstance(raw_path, str):
            continue
        path = raw_path.strip()
        if not path:
            continue
        raw_reason = entry.get("reason", "")
        reason = raw_reason if isinstance(raw_reason, str) else str(raw_reason)
        normalized_relevant_files.append({"path": path, "reason": reason})
    relevant_files = normalized_relevant_files
    utilities = [
        e if isinstance(e, dict) else {"name": e, "location": "", "purpose": ""}
        for e in utilities
        if isinstance(e, (dict, str))
    ]

    return ExplorationContext(
        patterns=patterns,
        relevant_files=relevant_files,
        utilities=utilities,
        constraints=constraints,
        success=True,
    )


def _log_exploration_result(
    context: ExplorationContext,
    log_event: Callable[..., None] | None,
    trace_id: str | None,
    parent_span_id: str | None,
) -> None:
    """Log exploration results for observability."""
    pattern_count = len(context.patterns)
    file_count = len(context.relevant_files)
    utility_count = len(context.utilities)
    constraint_count = len(context.constraints)

    logger.info(
        "Exploration complete: %d patterns, %d files, %d utilities, %d constraints (%.1fs)",
        pattern_count,
        file_count,
        utility_count,
        constraint_count,
        context.duration_seconds,
    )

    if context.success:
        print_info(
            f"Exploration found {pattern_count} patterns, "
            f"{file_count} files, {utility_count} utilities"
        )
    else:
        print_warning(f"Exploration failed: {context.error_message}")

    if log_event:
        try:
            log_event(
                "exploration_complete",
                success=context.success,
                pattern_count=pattern_count,
                file_count=file_count,
                utility_count=utility_count,
                constraint_count=constraint_count,
                duration_seconds=context.duration_seconds,
                error_message=(context.error_message if not context.success else None),
                trace_id=trace_id,
                parent_span_id=parent_span_id,
            )
        except TypeError:
            logger.debug(
                "Exploration result logging skipped: incompatible log_event signature"
            )
