"""Exploration configuration loading with process-level caching.

Extracted from DeriveHandler._get_exploration_config() as part of
REFACTOR-EXPLORATION-001.

Loads exploration settings from orchestration.exploration in the layered
config and caches the result for the lifetime of the process.

Related:
    - obra/config/default_config.yaml (orchestration.exploration section)
    - docs/decisions/ADR-055-conditional-auto-exploration.md
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)

# Process-level config cache (Rule 22: config-wired operations)
_CONFIG_CACHE: dict[str, Any] | None = None


def get_exploration_config() -> dict[str, Any]:
    """Get exploration configuration from layered config (cached).

    Loads orchestration.exploration from the layered config on first call
    and caches the result. Validates all required keys are present.

    Returns:
        Exploration config dict from orchestration.exploration

    Raises:
        ConfigurationError: If required config keys are missing
    """
    global _CONFIG_CACHE

    if _CONFIG_CACHE is not None:
        return _CONFIG_CACHE

    from obra.config.loaders import load_layered_config
    from obra.exceptions import ConfigurationError

    config, _, warnings = load_layered_config(include_defaults=True)
    if warnings:
        for warning in warnings:
            logger.warning("Config warning: %s", warning)

    exploration_config = config.get("orchestration", {}).get("exploration", {})

    # Validate required top-level keys (must be wired from config)
    # Note: 'triggers' removed as dead config (REFACTOR-EXPLORATION-001)
    required_keys = [
        "enabled",
        "timeout_s",
        "model_tier",
        "context",
        "max_relevant_files",
        "skip",
        "cache",
    ]
    missing = [k for k in required_keys if k not in exploration_config]
    if missing:
        msg = (
            f"Missing required exploration config keys: {missing}. "
            "Check orchestration.exploration section in default_config.yaml"
        )
        raise ConfigurationError(msg)

    # Validate skip sub-config keys
    skip_config = exploration_config["skip"]
    required_skip_keys = [
        "bug_fix_with_path",
        "recent_exploration_hours",
        "empty_project_files",
    ]
    missing_skip = [k for k in required_skip_keys if k not in skip_config]
    if missing_skip:
        msg = (
            f"Missing required exploration.skip config keys: {missing_skip}. "
            "Check orchestration.exploration.skip section in default_config.yaml"
        )
        raise ConfigurationError(msg)

    # Validate cache sub-config keys
    cache_config = exploration_config["cache"]
    required_cache_keys = ["max_age_seconds", "max_file_delta"]
    missing_cache = [k for k in required_cache_keys if k not in cache_config]
    if missing_cache:
        msg = (
            f"Missing required exploration.cache config keys: {missing_cache}. "
            "Check orchestration.exploration.cache section in default_config.yaml"
        )
        raise ConfigurationError(msg)

    # Validate context sub-config keys
    context_config = exploration_config["context"]
    required_context_keys = [
        "tree_max_depth",
        "tree_max_entries",
        "key_file_patterns",
        "key_file_max_lines",
        "max_context_chars",
    ]
    missing_context = [k for k in required_context_keys if k not in context_config]
    if missing_context:
        msg = (
            f"Missing required exploration.context config keys: {missing_context}. "
            "Check orchestration.exploration.context section in default_config.yaml"
        )
        raise ConfigurationError(msg)

    _CONFIG_CACHE = exploration_config
    return _CONFIG_CACHE


def clear_config_cache() -> None:
    """Clear the exploration config cache, forcing a fresh load on next call."""
    global _CONFIG_CACHE
    _CONFIG_CACHE = None
