"""Persistence and mutation helpers for UserPlan intake flows."""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

from obra.execution.userplan_cache import (
    get_userplan_cache_path,
    write_userplan_cache,
    write_userplan_mapping,
)
from obra.schemas.userplan_schema import UserPlan

if TYPE_CHECKING:
    from obra.execution.intake import UserPlanStorageProtocol


logger = logging.getLogger(__name__)


def _model_dump_if_available(value: Any | None) -> Any | None:
    """Serialize pydantic-style models when available, otherwise pass through."""
    if value is None:
        return None
    model_dump = getattr(value, "model_dump", None)
    if callable(model_dump):
        return model_dump()
    return value


def _enum_value_or_none(value: Any | None) -> Any | None:
    """Return enum-like `.value` when present, otherwise the value itself."""
    if value is None:
        return None
    return getattr(value, "value", value)


@dataclass(frozen=True)
class UserPlanCacheResult:
    """Outcome of local UserPlan cache and mapping writes."""

    cache_ok: bool
    cache_error: str | None
    mapping_ok: bool
    mapping_error: str | None
    cache_path: Path


def build_cache_source_metadata(
    userplan: UserPlan,
    *,
    raw_data: dict[str, Any] | None = None,
    plan_context: dict[str, Any] | None = None,
    source_path_override: str | None = None,
) -> dict[str, Any]:
    """Build source metadata for local mapping artifacts."""
    source_metadata: dict[str, Any] = {
        "type": userplan.source.type.value,
        "path": userplan.source.path if source_path_override is None else source_path_override,
    }
    if userplan.source.raw_objective is not None:
        source_metadata["raw_objective"] = userplan.source.raw_objective
    if raw_data is not None:
        source_metadata["steps"] = raw_data.get("steps", [])
        if "id" in raw_data:
            source_metadata["id"] = raw_data.get("id")
    if plan_context is not None:
        source_metadata["plan_context"] = plan_context
    return source_metadata


def cache_userplan_artifacts(
    userplan: UserPlan,
    *,
    source_metadata: dict[str, Any],
) -> UserPlanCacheResult:
    """Write best-effort local cache and mapping artifacts for a UserPlan."""
    cache_ok, cache_error = write_userplan_cache(userplan, userplan.project_id)
    mapping_ok, mapping_error = write_userplan_mapping(
        userplan,
        userplan.project_id,
        source_metadata,
    )
    return UserPlanCacheResult(
        cache_ok=cache_ok,
        cache_error=cache_error,
        mapping_ok=mapping_ok,
        mapping_error=mapping_error,
        cache_path=get_userplan_cache_path(userplan.project_id, userplan.id),
    )


def log_cache_result(userplan_id: str, cache_result: UserPlanCacheResult) -> None:
    """Log cache write warnings without interrupting the intake flow."""
    logger.info("Writing local cache for UserPlan %s", userplan_id)
    if not cache_result.cache_ok:
        logger.warning("UserPlan cache write failed: %s", cache_result.cache_error)
    if not cache_result.mapping_ok:
        logger.warning("UserPlan mapping write failed: %s", cache_result.mapping_error)


def build_create_userplan_payload(
    userplan: UserPlan,
    *,
    source_path_override: str | None = None,
) -> dict[str, Any]:
    """Build kwargs for create_userplan storage/API calls."""
    generated_at = getattr(userplan.source, "generated_at", None)
    source = {
        "type": userplan.source.type.value,
        "path": userplan.source.path if source_path_override is None else source_path_override,
        "raw_objective": userplan.source.raw_objective,
        "generated": userplan.source.generated,
        "generated_at": (
            generated_at.isoformat()
            if generated_at is not None
            else None
        ),
    }
    steps = [
        {
            "id": step.id,
            "index": step.index,
            "title": step.title,
            "description": step.description,
            "raw_text": step.raw_text,
            "derivation_status": step.derivation_status.value,
            "context": _model_dump_if_available(getattr(step, "context", None)),
            "inherited_keys": getattr(step, "inherited_keys", None),
            "inherited_context": getattr(step, "inherited_context", None),
        }
        for step in userplan.steps
    ]
    return {
        "userplan_id": userplan.id,
        "project_id": userplan.project_id,
        "source": source,
        "steps": steps,
        "session_id": getattr(userplan, "session_id", None),
        "status": _enum_value_or_none(getattr(userplan, "status", None)),
        "quality_score": getattr(userplan, "quality_score", None),
        "quality_status": _enum_value_or_none(getattr(userplan, "quality_status", None)),
        "work_type": _enum_value_or_none(getattr(userplan, "work_type", None)),
        "context": _model_dump_if_available(getattr(userplan, "context", None)),
        "metadata": getattr(userplan, "metadata", None),
    }


def store_userplan_with_storage(
    storage: "UserPlanStorageProtocol | None",
    userplan: UserPlan,
) -> tuple[bool, str | None]:
    """Persist a generated UserPlan via the storage protocol."""
    if storage is None:
        return False, "Storage not configured"

    try:
        storage.create_userplan(**build_create_userplan_payload(userplan))
    except Exception as exc:
        error_msg = f"Failed to store UserPlan: {exc}"
        logger.exception(error_msg)
        return False, error_msg

    logger.info(
        "Stored UserPlan %s to server storage (project=%s)",
        userplan.id,
        userplan.project_id,
    )
    return True, None


def persist_userplan_via_api(
    userplan: UserPlan,
    *,
    client: Any | None = None,
    source_path_override: str | None = None,
) -> dict[str, Any]:
    """Persist a UserPlan through the API client using the shared payload shape."""
    if client is None:
        from obra.api import APIClient

        client = APIClient.from_config()
    return client.create_userplan(
        **build_create_userplan_payload(
            userplan,
            source_path_override=source_path_override,
        )
    )


def apply_from_step_mutations(
    client: Any,
    *,
    userplan_id: str,
    total_steps: int,
    from_step: int | None,
    cascade: bool,
) -> None:
    """Apply plan-file from-step and cascade status updates through the API."""
    if from_step is None:
        return

    if from_step > total_steps:
        from obra.execution.intake import UserPlanFromStepError

        raise UserPlanFromStepError(from_step, total_steps)

    step_indices_to_rederive = list(range(from_step, total_steps + 1))
    try:
        client.update_userplan_steps_status_batch(
            userplan_id=userplan_id,
            step_indices=step_indices_to_rederive,
            derivation_status="deriving",
        )
        logger.info(
            "Marked steps %s as DERIVING for UserPlan %s",
            step_indices_to_rederive,
            userplan_id,
        )
    except Exception as status_err:
        logger.warning("Failed to update step statuses: %s", status_err, exc_info=True)

    if cascade and from_step < total_steps:
        sibling_step_indices = list(range(from_step + 1, total_steps + 1))
        try:
            client.update_userplan_steps_status_batch(
                userplan_id=userplan_id,
                step_indices=sibling_step_indices,
                derivation_status="stale",
            )
            logger.info(
                "Cascade: Marked steps %s as STALE for UserPlan %s",
                sibling_step_indices,
                userplan_id,
            )
        except Exception as cascade_err:
            logger.warning("Failed to cascade staleness: %s", cascade_err, exc_info=True)
