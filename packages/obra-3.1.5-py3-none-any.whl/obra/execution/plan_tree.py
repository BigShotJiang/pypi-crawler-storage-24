"""Plan tree domain logic: normalization, hierarchy building, and export helpers."""
from __future__ import annotations

import re
from datetime import UTC, datetime
from typing import Any

__all__ = [
    "build_plan_tree_snapshot",
    "build_tree_node",
    "aggregate_status",
    "normalize_plan_items",
    "infer_item_type",
    "infer_parent_ids",
    "normalize_status",
    "get_root_items",
    "build_machine_plan_export",
    "build_story_exports",
    "build_synthetic_story_exports",
    "build_task_exports",
    "build_subtask_exports",
]


def build_plan_tree_snapshot(
    plan_items: list[dict[str, Any]],
    objective: str,
) -> dict[str, Any]:
    """Build a hierarchical DerivedPlan tree snapshot from flat plan items."""
    normalized, children_map, status_map, _order_map = normalize_plan_items(plan_items)
    roots = get_root_items(normalized, children_map)
    tree_nodes = [
        build_tree_node(node_id, normalized, children_map, status_map) for node_id in roots
    ]
    return {
        "objective": objective,
        "roots": tree_nodes,
        "count": len(normalized),
    }


def build_tree_node(
    item_id: str,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
    status_map: dict[str, str],
) -> dict[str, Any]:
    item = normalized.get(item_id, {})
    children = children_map.get(item_id, [])
    return {
        "id": item_id,
        "title": item.get("title", "Untitled"),
        "item_type": item.get("item_type", "task"),
        "status": aggregate_status(item_id, children_map, status_map),
        "children": [
            build_tree_node(child_id, normalized, children_map, status_map)
            for child_id in children
        ],
    }


def aggregate_status(
    item_id: str,
    children_map: dict[str | None, list[str]],
    status_map: dict[str, str],
) -> str:
    children = children_map.get(item_id, [])
    if not children:
        return status_map.get(item_id, "pending")
    child_statuses = [
        aggregate_status(child_id, children_map, status_map) for child_id in children
    ]
    if any(status == "failed" for status in child_statuses):
        return "failed"
    if any(status == "in_progress" for status in child_statuses):
        return "in_progress"
    if all(status in {"completed", "skipped"} for status in child_statuses):
        return "completed"
    return "pending"


def normalize_plan_items(
    plan_items: list[dict[str, Any]],
) -> tuple[
    dict[str, dict[str, Any]],
    dict[str | None, list[str]],
    dict[str, str],
    dict[str, int],
]:
    normalized: dict[str, dict[str, Any]] = {}
    children_map: dict[str | None, list[str]] = {}
    status_map: dict[str, str] = {}
    order_map: dict[str, int] = {}

    for item in plan_items:
        item_id = str(item.get("item_id") or item.get("id") or "").strip()
        if not item_id:
            continue
        title = str(item.get("title") or item.get("description") or "Untitled").strip()
        item_type = str(item.get("item_type") or "").strip().lower()
        if not item_type:
            item_type = infer_item_type(item_id)
        parent_id = item.get("parent_id")
        parent_id = str(parent_id).strip() if parent_id else None
        status = normalize_status(str(item.get("status", "")).strip())
        order_value = item.get("order")
        try:
            order = int(order_value) if order_value is not None else 1_000_000
        except (TypeError, ValueError):
            order = 1_000_000

        normalized[item_id] = {
            "id": item_id,
            "title": title,
            "item_type": item_type,
            "parent_id": parent_id,
            "status": status,
            "description": item.get("description", ""),
            "acceptance_criteria": item.get("acceptance_criteria", []),
        }
        status_map[item_id] = status
        order_map[item_id] = order

    parent_defaults = infer_parent_ids(normalized)
    for item_id, parent_id in parent_defaults.items():
        normalized[item_id]["parent_id"] = parent_id

    for item_id, item in normalized.items():
        parent_id = item.get("parent_id") or None
        children_map.setdefault(parent_id, []).append(item_id)

    return normalized, children_map, status_map, order_map


def infer_item_type(item_id: str) -> str:
    if item_id.startswith("E"):
        return "epic"
    if item_id.startswith("S") and ".T" not in item_id:
        return "story"
    if ".T" in item_id:
        # Subtask has 2+ dots (e.g., S1.T1.1) - hierarchy parsing protocol constant
        if item_id.count(".") >= 2:
            return "subtask"
        return "task"
    return "task"


def infer_parent_ids(
    normalized: dict[str, dict[str, Any]],
) -> dict[str, str | None]:
    parent_map: dict[str, str | None] = {}
    epic_ids = [item_id for item_id, item in normalized.items() if item.get("item_type") == "epic"]
    default_epic_id = epic_ids[0] if len(epic_ids) == 1 else None

    for item_id, item in normalized.items():
        if item.get("parent_id"):
            continue
        item_type = item.get("item_type")
        parent_id = None

        if item_type == "subtask":
            parts = item_id.split(".")
            # Subtask format: S1.T1.1 (3 parts) - hierarchy parsing protocol constant
            if len(parts) >= 3:
                parent_id = ".".join(parts[:2])
        elif item_type == "task":
            if ".T" in item_id:
                parent_id = item_id.split(".T")[0]
        elif item_type == "story":
            if default_epic_id:
                parent_id = default_epic_id

        if parent_id and parent_id in normalized:
            parent_map[item_id] = parent_id
        else:
            parent_map[item_id] = None

    return parent_map


def normalize_status(status: str) -> str:
    normalized = status.lower()
    if normalized in {"completed", "complete", "done", "success", "ok"}:
        return "completed"
    if normalized in {"in_progress", "running", "started"}:
        return "in_progress"
    if normalized in {"failed", "error", "failure"}:
        return "failed"
    if normalized in {"skipped", "skip"}:
        return "skipped"
    return "pending"


def get_root_items(
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[str]:
    roots = []
    for item_id, item in normalized.items():
        parent_id = item.get("parent_id")
        if not parent_id or parent_id not in normalized:
            roots.append(item_id)
    return roots


def build_machine_plan_export(
    *,
    plan_items: list[dict[str, Any]],
    objective: str,
    session_id: str,
    work_id: str | None = None,
) -> dict[str, Any]:
    """Build a MACHINE_PLAN export from session plan items."""
    normalized, children_map, _status_map, _order_map = normalize_plan_items(plan_items)
    epic_ids = [item_id for item_id, item in normalized.items() if item.get("item_type") == "epic"]
    if not epic_ids:
        epic_id = "E1"
        normalized[epic_id] = {
            "id": epic_id,
            "title": objective or "Execution Plan",
            "item_type": "epic",
            "status": "pending",
            "parent_id": None,
        }
        children_map.setdefault(None, []).append(epic_id)
        epic_ids = [epic_id]

    epics: list[dict[str, Any]] = []
    for epic_id in epic_ids:
        epic = normalized.get(epic_id, {})
        stories = build_story_exports(epic_id, normalized, children_map)
        if not stories:
            stories = build_story_exports(None, normalized, children_map)
        if not stories:
            stories = build_synthetic_story_exports(normalized, children_map)
        epics.append(
            {
                "id": epic_id,
                "title": epic.get("title", objective or "Execution Plan"),
                "status": epic.get("status", "pending"),
                "stories": stories,
            }
        )

    plan_work_id = work_id or "SESSION-PLAN-EXPORT"
    return {
        "work_id": plan_work_id,
        "version": 1,
        "created": datetime.now(UTC).isoformat(),
        "context": {
            "source_session_id": session_id,
            "objective": objective,
        },
        "epics": epics,
        "completion_checklist": [
            "All plan items completed",
            "Quality checks executed as needed",
            "Final output verified against objective",
        ],
    }


def build_story_exports(
    epic_id: str | None,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[dict[str, Any]]:
    story_ids = [
        child_id
        for child_id in children_map.get(epic_id, [])
        if normalized.get(child_id, {}).get("item_type") == "story"
    ]
    stories: list[dict[str, Any]] = []
    for story_idx, story_id in enumerate(story_ids, start=1):
        story = normalized.get(story_id, {})
        export_story_id = story_id
        if not re.match(r"^S\d+$", export_story_id):
            export_story_id = f"S{story_idx}"
        tasks = build_task_exports(export_story_id, story_id, normalized, children_map)
        stories.append(
            {
                "id": export_story_id,
                "title": story.get("title", "Story"),
                "status": story.get("status", "pending"),
                "tasks": tasks,
            }
        )
    return stories


def build_synthetic_story_exports(
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[dict[str, Any]]:
    task_ids = [
        item_id
        for item_id, item in normalized.items()
        if item.get("item_type") == "task"
        and (
            item.get("parent_id") is None
            or normalized.get(item.get("parent_id", ""), {}).get("item_type") != "story"
        )
    ]
    if not task_ids:
        return []
    tasks = []
    for idx, task_id in enumerate(task_ids, start=1):
        task = normalized.get(task_id, {})
        acceptance = task.get("acceptance_criteria", [])
        if not isinstance(acceptance, list):
            acceptance = [acceptance]
        verify = acceptance[0] if acceptance else "Verify task completion"
        export_task = {
            "id": f"S1.T{idx}",
            "desc": task.get("description") or task.get("title", "Task"),
            "status": task.get("status", "pending"),
            "verify": verify,
        }
        subtasks = build_subtask_exports(task_id, export_task["id"], normalized, children_map)
        if subtasks:
            export_task["subtasks"] = subtasks
        tasks.append(export_task)
    return [
        {
            "id": "S1",
            "title": "Execution Plan",
            "status": "pending",
            "tasks": tasks,
        }
    ]


def build_task_exports(
    export_story_id: str,
    source_story_id: str,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[dict[str, Any]]:
    task_ids = [
        child_id
        for child_id in children_map.get(source_story_id, [])
        if normalized.get(child_id, {}).get("item_type") in {"task", "subtask"}
    ]
    tasks: list[dict[str, Any]] = []
    for idx, task_id in enumerate(task_ids, start=1):
        task = normalized.get(task_id, {})
        acceptance = task.get("acceptance_criteria", [])
        if not isinstance(acceptance, list):
            acceptance = [acceptance]
        verify = acceptance[0] if acceptance else "Verify task completion"
        export_task_id = task_id
        if not re.match(rf"^{re.escape(export_story_id)}\.T\d+$", export_task_id):
            export_task_id = f"{export_story_id}.T{idx}"
        export_task = {
            "id": export_task_id,
            "desc": task.get("description") or task.get("title", "Task"),
            "status": task.get("status", "pending"),
            "verify": verify,
        }
        if task.get("item_type") == "task":
            subtasks = build_subtask_exports(task_id, export_task_id, normalized, children_map)
            if subtasks:
                export_task["subtasks"] = subtasks
        tasks.append(export_task)
    return tasks


def build_subtask_exports(
    task_id: str,
    export_task_id: str,
    normalized: dict[str, dict[str, Any]],
    children_map: dict[str | None, list[str]],
) -> list[dict[str, Any]]:
    subtask_ids = [
        child_id
        for child_id in children_map.get(task_id, [])
        if normalized.get(child_id, {}).get("item_type") == "subtask"
    ]
    subtasks: list[dict[str, Any]] = []
    for idx, subtask_id in enumerate(subtask_ids, start=1):
        subtask = normalized.get(subtask_id, {})
        acceptance = subtask.get("acceptance_criteria", [])
        if not isinstance(acceptance, list):
            acceptance = [acceptance]
        verify = acceptance[0] if acceptance else "Verify subtask completion"
        subtasks.append(
            {
                "id": f"{export_task_id}.{idx}",
                "desc": subtask.get("description") or subtask.get("title", "Subtask"),
                "status": subtask.get("status", "pending"),
                "verify": verify,
            }
        )
    return subtasks
