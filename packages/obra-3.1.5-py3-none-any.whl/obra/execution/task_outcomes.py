"""Task outcome types for standardized execution result reporting.

Provides:
- TaskOutcome enum: SUCCESS, SUCCESS_WITH_LIMITS, PARTIAL, FAILED, BLOCKED
- TaskResult dataclass: outcome + human-readable message + optional details

Usage:
    from obra.execution.task_outcomes import TaskOutcome, TaskResult

    result = TaskResult(
        outcome=TaskOutcome.SUCCESS,
        outcome_message="Task completed successfully",
    )
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any


class TaskOutcome(str, Enum):
    """Enum for standardized task execution result reporting.

    Used to classify the outcome of task execution across the system.

    Attributes:
        SUCCESS: Task completed fully without any issues
        SUCCESS_WITH_LIMITS: Completed but hit budget/time limits during execution
        PARTIAL: Some work completed successfully, some failed
        FAILED: Task failed completely, no useful work done
        BLOCKED: Task cannot proceed, needs human intervention
    """

    SUCCESS = "success"
    SUCCESS_WITH_LIMITS = "success_with_limits"
    PARTIAL = "partial"
    FAILED = "failed"
    BLOCKED = "blocked"


@dataclass
class TaskResult:
    """Container for task execution result with outcome and message.

    Provides a standardized way to report task execution results
    with both a machine-readable outcome and a human-readable message.

    Attributes:
        outcome: The TaskOutcome enum value classifying the result
        outcome_message: Human-readable explanation of the outcome
        details: Optional dictionary with additional result details
    """

    outcome: TaskOutcome
    outcome_message: str
    details: dict[str, Any] = field(default_factory=dict)
