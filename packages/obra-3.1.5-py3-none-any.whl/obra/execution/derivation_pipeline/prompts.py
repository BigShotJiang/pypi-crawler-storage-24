"""Prompt-building helpers for the derivation engine."""

from __future__ import annotations

import logging
from typing import Any

from obra.prompts.derive.derivation import (
    build_derivation_prompt,
    build_four_phase_guidance,
    build_step1_epics_only_prompt,
    build_step2_prompt,
    build_step3_prompt,
    get_pattern_guidance,
)

logger = logging.getLogger(__name__)

WORK_TYPES_NEEDING_EXPLORATION = [
    "feature_implementation",
    "refactoring",
    "integration",
]


class DerivationPromptBuilder:
    """Owns prompt and hierarchy configuration helpers for derivation."""

    def __init__(self, owner: Any) -> None:
        self._owner = owner

    def build_prompt(
        self,
        objective: str,
        context: dict[str, Any],
        constraints: dict[str, Any],
        work_type: str,
    ) -> str:
        """Build the main derivation prompt."""
        context_section = self._owner._context_builder.build_context_section(context)

        max_items = constraints.get("max_items", self._owner._max_items)
        constraint_lines = []
        if max_items:
            constraint_lines.append(
                f"- Advisory: Aim for ~{max_items} plan items if they stay small and testable; no hard cap—split oversized work instead of dropping items."
            )

        if constraints.get("scope_boundaries"):
            constraint_lines.append(
                f"- Scope boundaries: {', '.join(constraints['scope_boundaries'])}"
            )

        constraints_section = ("\n".join(constraint_lines) + "\n") if constraint_lines else ""
        pattern_guidance = self.get_pattern_guidance(work_type)

        four_phase_guidance = ""
        if work_type in WORK_TYPES_NEEDING_EXPLORATION:
            four_phase_guidance = build_four_phase_guidance()

        return build_derivation_prompt(
            objective=objective,
            context_section=context_section,
            work_type=work_type,
            pattern_guidance=pattern_guidance,
            constraints_section=constraints_section,
            four_phase_guidance=four_phase_guidance,
        )

    @staticmethod
    def resolve_hierarchy_config(constraints: dict[str, Any] | None) -> dict[str, Any]:
        """Resolve hierarchy configuration from config and constraints."""
        hierarchy: dict[str, Any] = {}
        try:
            from obra.config.loaders import load_layered_config

            config, _, _ = load_layered_config(include_defaults=True)
            hierarchy = config.get("derivation", {}).get("hierarchy", {}) or {}
        except Exception as exc:
            logger.warning("Failed to load hierarchy config; defaulting to disabled: %s", exc)
            hierarchy = {}

        if constraints and isinstance(constraints.get("hierarchy"), dict):
            hierarchy = {**hierarchy, **constraints["hierarchy"]}

        if hierarchy.get("enabled"):
            required_keys = ["max_depth", "epic", "story", "task", "subtask"]
            missing = [key for key in required_keys if key not in hierarchy]
            if missing:
                msg = f"Hierarchy config missing required keys: {', '.join(missing)}"
                logger.error(msg)
                raise ValueError(msg)

        return hierarchy

    @staticmethod
    def get_pattern_guidance(work_type: str) -> str:
        """Return decomposition guidance for the detected work type."""
        return get_pattern_guidance(work_type)

    def build_step1_prompt(self, objective: str, constraints: str, context: str) -> str:
        return build_step1_epics_only_prompt(
            objective=objective,
            constraints=constraints,
            context=context,
            intent_markdown=self._owner._intent_markdown,
            exploration_context=self._owner._exploration_context,
            strategic_prompt=self._owner._strategic_prompt,
        )

    def build_step2_prompt(self, objective: str, prose_from_step_1: str) -> str:
        return build_step2_prompt(
            objective=objective,
            prose_from_step_1=prose_from_step_1,
            intent_markdown=self._owner._intent_markdown,
            exploration_context=self._owner._exploration_context,
        )

    @staticmethod
    def build_step3_prompt(prose_from_step_2: str) -> str:
        return build_step3_prompt(prose_from_step_2=prose_from_step_2)
