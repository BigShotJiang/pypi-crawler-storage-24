"""Static plan-item assembly helpers for the derivation pipeline."""

from __future__ import annotations

from typing import Any


class PlanAssembler:
    """Own static assembly utilities for building and merging plan items."""

    @staticmethod
    def build_partial_plan_items(
        epic_id: str,
        epic_title: str,
        stories: list[dict[str, str]],
        tasks: list[dict[str, str]],
    ) -> list[dict[str, Any]]:
        """Build minimal plan items for partial plan snapshots."""
        plan_items: list[dict[str, Any]] = [
            {
                "id": epic_id,
                "item_type": "epic",
                "title": epic_title,
                "parent_id": None,
                "depth": 0,
                "order": 0,
            }
        ]

        task_map: dict[str, list[dict[str, str]]] = {}
        for task in tasks:
            task_id = task.get("id", "")
            story_id = task_id.split(".T", 1)[0] if ".T" in task_id else ""
            if story_id:
                task_map.setdefault(story_id, []).append(task)

        for story_index, story in enumerate(stories, start=1):
            story_id = story.get("id", "")
            story_title = story.get("title", "")
            if not story_id:
                continue
            plan_items.append(
                {
                    "id": story_id,
                    "item_type": "story",
                    "title": story_title,
                    "parent_id": epic_id,
                    "depth": 1,
                    "order": story_index,
                }
            )
            for task_index, task in enumerate(task_map.get(story_id, []), start=1):
                task_id = task.get("id", "")
                task_title = task.get("title", "")
                if not task_id:
                    continue
                plan_items.append(
                    {
                        "id": task_id,
                        "item_type": "task",
                        "title": task_title,
                        "parent_id": story_id,
                        "depth": 2,
                        "order": task_index,
                    }
                )

        return plan_items

    @staticmethod
    def merge_epic_details(epics_prose: str, all_epic_details: list[str]) -> str:
        """Merge epic-only prose with per-epic story/task details."""
        merged = [epics_prose.strip()]
        if all_epic_details:
            merged.append("")
            for detail in all_epic_details:
                merged.append(detail.strip())
                merged.append("")
        return "\n".join(merged).strip()
