"""Dedicated UserPlan construction owners for intake flows."""

from __future__ import annotations

import json
from typing import Any

from obra.execution.userplan_metrics import emit_userplan_source_metric
from obra.schemas.userplan_schema import SourceType, UserPlan


def extract_stories_from_plan_context(plan_context: dict[str, Any]) -> list[dict[str, Any]]:
    """Extract story dictionaries from an epics-rooted plan context."""
    epics = plan_context.get("epics")
    if not isinstance(epics, list) or not epics:
        return []

    extracted: list[dict[str, Any]] = []
    for epic in epics:
        if not isinstance(epic, dict):
            continue
        stories = epic.get("stories", [])
        if not isinstance(stories, list):
            continue
        extracted.extend([story for story in stories if isinstance(story, dict)])
    return extracted


def create_userplan_from_plan_context(
    plan_context: dict[str, Any],
    project_id: str,
    *,
    plan_file_path: str | None = None,
    session_id: str | None = None,
    log_event: Any | None = None,
) -> UserPlan:
    """Build a UserPlan from a plan-file context."""
    from datetime import UTC, datetime

    from obra.schemas.userplan_schema import (
        DerivationStatus,
        UserPlanSource,
        UserPlanStep,
        UserPlanStepContext,
    )

    stories = extract_stories_from_plan_context(plan_context)
    if not stories:
        msg = "Plan file must contain a non-empty 'epics' array"
        raise ValueError(msg)

    first_story = stories[0]
    first_title = first_story.get("title", first_story.get("desc", "plan-import"))
    slug = UserPlan.slugify(first_title)
    userplan_id = UserPlan.generate_id(slug)
    now = datetime.now(UTC).isoformat()

    steps: list[UserPlanStep] = []
    for index, story in enumerate(stories, start=1):
        story_title = str(story.get("title", story.get("desc", f"Story {index}")))
        story_description = str(story.get("description", story_title))

        tasks = story.get("tasks", [])
        deliverables: list[str] = []
        if isinstance(tasks, list):
            for task in tasks:
                if isinstance(task, dict):
                    task_title = task.get("title", task.get("desc", ""))
                    if task_title:
                        deliverables.append(task_title)
                elif isinstance(task, str):
                    deliverables.append(task)

        verify = story.get("verify", [])
        success_criteria: str | None = None
        if isinstance(verify, list) and verify:
            success_criteria = "; ".join(str(value) for value in verify)
        elif isinstance(verify, str):
            success_criteria = verify

        step_context = UserPlanStepContext(
            deliverables=deliverables,
            success_criteria=success_criteria,
            constraints=story.get("constraints", [])
            if isinstance(story.get("constraints"), list)
            else [],
        )
        step = UserPlanStep(
            id=UserPlan.generate_step_id(userplan_id, index),
            index=index,
            title=story_title,
            description=story_description,
            raw_text=json.dumps(story),
            derivation_status=DerivationStatus.NOT_DERIVED,
            context=step_context,
        )
        steps.append(step)

    userplan = UserPlan(
        id=userplan_id,
        project_id=project_id,
        session_id=session_id,
        version=1,
        created_at=now,
        updated_at=now,
        source=UserPlanSource(
            type=SourceType.PLAN_FILE,
            path=plan_file_path,
            raw_objective=None,
            generated=False,
        ),
        steps=steps,
        metadata={
            "plan_file_source": plan_file_path,
            "story_count": len(stories),
        },
    )

    emit_userplan_source_metric(
        source_type=SourceType.PLAN_FILE,
        userplan_id=userplan_id,
        project_id=project_id,
        is_generated=False,
        log_event=log_event,
    )
    return userplan


def validate_objective(
    objective: str,
    min_words: int = 3,
    garbage_patterns: list[str] | None = None,
) -> tuple[bool, list[str]]:
    """Validate objective quality before creating a UserPlan."""
    if garbage_patterns is None:
        garbage_patterns = ["do it", "do stuff", "help", "fix it", "make it work"]

    missing_elements: list[str] = []
    objective_lower = objective.lower().strip()
    word_count = len(objective.split())

    if word_count < min_words:
        missing_elements.append(
            f"Too short ({word_count} words, minimum {min_words}). "
            "Add more detail about what you want to accomplish."
        )

    for pattern in garbage_patterns:
        normalized_pattern = pattern.lower()
        if objective_lower == normalized_pattern or objective_lower.startswith(
            normalized_pattern + " "
        ):
            missing_elements.append(
                f"Matches garbage pattern '{pattern}'. "
                "Please provide a specific, actionable objective."
            )
            break

    return len(missing_elements) == 0, missing_elements


def load_intake_validation_config() -> tuple[bool, int, list[str]]:
    """Load intake validation config from layered config."""
    try:
        from obra.config.loaders import get_intake_config, load_layered_config

        cfg, _, _ = load_layered_config(include_defaults=True)
        intake_cfg = cfg.get("features", {}).get("intake", {}).get("validation", {})
        enabled = intake_cfg.get("enabled", True)
        intake_config = get_intake_config()
        min_words = intake_config["min_words"]
        garbage_patterns = intake_cfg.get(
            "garbage_patterns", ["do it", "do stuff", "help", "fix it", "make it work"]
        )
        return enabled, min_words, garbage_patterns
    except Exception:
        return True, 3, ["do it", "do stuff", "help", "fix it", "make it work"]


def create_userplan_from_objective_text(
    objective: str,
    project_id: str,
    *,
    session_id: str | None = None,
    log_event: Any | None = None,
) -> UserPlan:
    """Create a minimal UserPlan from a free-form objective string."""
    from datetime import UTC, datetime

    from obra.exceptions import ObjectiveTooVagueError
    from obra.schemas.userplan_schema import (
        DerivationStatus,
        UserPlanSource,
        UserPlanStep,
        UserPlanStepContext,
    )

    if not objective or not objective.strip():
        msg = "Objective cannot be empty"
        raise ValueError(msg)

    objective = objective.strip()
    enabled, min_words, garbage_patterns = load_intake_validation_config()
    if enabled:
        is_valid, missing_elements = validate_objective(
            objective,
            min_words=min_words,
            garbage_patterns=garbage_patterns,
        )
        if not is_valid:
            raise ObjectiveTooVagueError(
                message=f"Objective is too vague: {missing_elements[0]}",
                objective=objective,
                word_count=len(objective.split()),
                min_words=min_words,
                missing_elements=missing_elements,
            )

    slug_source = objective[:50] if len(objective) > 50 else objective
    userplan_id = UserPlan.generate_id(UserPlan.slugify(slug_source))
    now = datetime.now(UTC).isoformat()
    step = UserPlanStep(
        id=UserPlan.generate_step_id(userplan_id, 1),
        index=1,
        title=objective[:100] if len(objective) > 100 else objective,
        description=objective,
        raw_text=objective,
        derivation_status=DerivationStatus.NOT_DERIVED,
        context=UserPlanStepContext(
            deliverables=[],
            success_criteria=None,
            constraints=[],
        ),
    )
    userplan = UserPlan(
        id=userplan_id,
        project_id=project_id,
        session_id=session_id,
        version=1,
        created_at=now,
        updated_at=now,
        source=UserPlanSource(
            type=SourceType.INTENT,
            path=None,
            raw_objective=objective,
            generated=True,
        ),
        steps=[step],
        metadata={
            "source_type": "free_form_objective",
            "objective_length": len(objective),
        },
    )

    emit_userplan_source_metric(
        source_type=SourceType.INTENT,
        userplan_id=userplan_id,
        project_id=project_id,
        is_generated=True,
        log_event=log_event,
    )
    return userplan
