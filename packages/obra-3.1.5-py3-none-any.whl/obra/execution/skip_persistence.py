"""Skip record persistence helpers.

Extracted from obra/execution/skip_record.py for structural clarity.
Handles filesystem and registry I/O for skip records.
"""

from __future__ import annotations

import json
import logging
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from obra.execution.skip_record import (
    SKIP_REGISTRY_FILENAME,
    SkipRecord,
    SkipRecordStorageProtocol,
    SkipSource,
    SkipStatus,
    get_skip_tracking_dir,
)

logger = logging.getLogger(__name__)


def _generate_skip_filename(task_id: str, source: SkipSource, timestamp: str) -> str:
    """Generate a filename for a skip record file."""
    try:
        dt = datetime.fromisoformat(timestamp)
    except ValueError:
        dt = datetime.now(UTC)

    time_part = dt.strftime("%Y%m%d_%H%M%S")
    safe_task_id = task_id.replace(".", "_")
    unique_suffix = uuid.uuid4().hex[:8]
    return f"{time_part}_{source.value}_{safe_task_id}_{unique_suffix}.json"


def _load_skip_registry(registry_path: Path) -> dict[str, Any]:
    if not registry_path.exists():
        return {"version": 1, "updated_at": None, "entries": []}
    return json.loads(registry_path.read_text())


def _write_skip_registry(registry_path: Path, registry: dict[str, Any]) -> None:
    registry["updated_at"] = datetime.now(UTC).isoformat()
    registry_path.write_text(json.dumps(registry, indent=2))


def persist_skip_record(
    skip: SkipRecord,
    base_dir: str | Path | None = None,
    state_manager: SkipRecordStorageProtocol | None = None,
) -> Path:
    """Persist a skip record to the filesystem and registry index."""
    from obra.execution.skip_record import _sanitize_for_persistence

    if state_manager:
        try:
            state_manager.create_skip_record(_sanitize_for_persistence(skip))
        except Exception as e:
            logger.debug("Failed to persist skip record to StateManager: %s", e)

    skip_dir = get_skip_tracking_dir(base_dir)
    skip_dir.mkdir(parents=True, exist_ok=True)

    filename = _generate_skip_filename(skip.task_id, skip.source, skip.created_at)
    file_path = skip_dir / filename

    sanitized = _sanitize_for_persistence(skip)
    file_path.write_text(json.dumps(sanitized, indent=2))

    registry_path = skip_dir / SKIP_REGISTRY_FILENAME
    registry = _load_skip_registry(registry_path)
    entries = [e for e in registry.get("entries", []) if e.get("id") != skip.id]
    entries.append(
        {
            "id": skip.id,
            "file": str(file_path),
            "source": skip.source.value,
            "reason": skip.reason.value,
            "status": skip.status.value,
            "created_at": skip.created_at,
        }
    )
    entries.sort(key=lambda e: e.get("created_at", ""), reverse=True)
    registry["entries"] = entries
    _write_skip_registry(registry_path, registry)

    logger.info(
        "Skip record created for task %s: %s (source: %s)",
        skip.task_id,
        file_path,
        skip.source.value,
    )

    return file_path


def load_skip_record(file_path: Path) -> SkipRecord:
    """Load a skip record from JSON file."""
    json_str = Path(file_path).read_text()
    return SkipRecord.from_json(json_str)


def list_skip_records(
    base_dir: str | Path | None = None,
    source: SkipSource | None = None,
    status: SkipStatus | None = None,
    state_manager: SkipRecordStorageProtocol | None = None,
) -> list[SkipRecord]:
    """List skip records, preferring StateManager when available."""
    if state_manager:
        try:
            records = [SkipRecord.from_dict(item) for item in state_manager.list_skip_records()]
            if source:
                records = [r for r in records if r.source == source]
            if status:
                records = [r for r in records if r.status == status]
            records.sort(key=lambda r: r.created_at, reverse=True)
        except Exception as e:
            logger.debug("Failed to list skip records from StateManager: %s", e)
        else:
            return records

    skip_dir = get_skip_tracking_dir(base_dir)

    if not skip_dir.exists():
        return []

    skip_files = [f for f in skip_dir.glob("*.json") if f.name != SKIP_REGISTRY_FILENAME]

    file_records: list[SkipRecord] = []
    for skip_file in skip_files:
        try:
            record = load_skip_record(skip_file)
        except Exception as e:
            logger.debug("Failed to load skip record %s: %s", skip_file, e)
            continue
        if source and record.source != source:
            continue
        if status and record.status != status:
            continue
        file_records.append(record)

    file_records.sort(key=lambda r: r.created_at, reverse=True)
    return file_records


__all__ = [
    "list_skip_records",
    "load_skip_record",
    "persist_skip_record",
]
