"""Failure tracking and budget monitoring for auto-decomposition.

Provides:
- DecompositionTriggerMetric / DecompositionMetricsCollector: metrics for
  auto-decomposition trigger events.
- FailureRecord / FailureTracker: consecutive-failure tracking per task.
- BudgetRecord / BudgetMonitor: token and cost budget tracking per task.

Metrics:
    - obra_decomposition_triggers_total: Counter of auto-decomposition trigger events
      Labels: trigger_type (failure/budget/duration), task_id

Usage:
    from obra.execution.failure_tracking import FailureTracker, BudgetMonitor

    tracker = FailureTracker(threshold=3)
    record = tracker.record_failure("S1.T1", "Connection timeout")
    if record.needs_decomposition:
        # trigger auto-decomposition

    monitor = BudgetMonitor()
    monitor.initialize_budget("S1.T1", token_budget=100000)
    record = monitor.record_consumption("S1.T1", tokens=5000)

Related:
    - obra/execution/errors.py (exception hierarchy)
    - obra/execution/error_classifier.py (transient classification)
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Any

from obra.execution.metrics_base import BaseMetric, BaseMetricsCollector

logger = logging.getLogger(__name__)

# Metric names following Prometheus naming convention
METRIC_DECOMPOSITION_TRIGGERS = "obra_decomposition_triggers_total"


@dataclass
class DecompositionTriggerMetric(BaseMetric):
    """Structured metric event for auto-decomposition trigger."""


class DecompositionMetricsCollector(BaseMetricsCollector[DecompositionTriggerMetric]):
    """Collects and aggregates decomposition trigger metrics.

    Thread-safety:
        This class is NOT thread-safe. Use external synchronization if
        accessing from multiple threads.
    """

    def __init__(self) -> None:
        """Initialize the metrics collector."""
        super().__init__()
        self._failure_triggers: int = 0
        self._budget_triggers: int = 0
        self._duration_triggers: int = 0

    def record_trigger(
        self,
        trigger_type: str,
        task_id: str,
        threshold: float | int,
        current_value: float | int,
        reason: str | None = None,
        log_event: Any | None = None,
        trace_id: str | None = None,
        parent_span_id: str | None = None,
    ) -> DecompositionTriggerMetric:
        """Record a decomposition trigger event.

        Args:
            trigger_type: Type of trigger ("failure", "budget", or "duration")
            task_id: The task identifier that triggered decomposition
            threshold: The threshold that was reached/exceeded
            current_value: The current value that triggered (failure count or consumption ratio)
            reason: Optional additional reason/context
            log_event: Optional event logger callback
            trace_id: Optional trace ID for correlation
            parent_span_id: Optional parent span ID for correlation

        Returns:
            The DecompositionTriggerMetric that was recorded
        """
        timestamp = datetime.now(UTC).isoformat()

        # Update counters
        if trigger_type == "failure":
            self._failure_triggers += 1
        elif trigger_type == "budget":
            self._budget_triggers += 1
        elif trigger_type == "duration":
            self._duration_triggers += 1

        metric = DecompositionTriggerMetric(
            metric_name=METRIC_DECOMPOSITION_TRIGGERS,
            value=1.0,
            labels={
                "trigger_type": trigger_type,
                "task_id": task_id,
            },
            timestamp=timestamp,
            metadata={
                "threshold": threshold,
                "current_value": current_value,
                "reason": reason or "",
            },
        )
        self._metrics_buffer.append(metric)

        # Log metric event
        if log_event:
            try:
                log_event(
                    "decomposition_trigger_metric",
                    session_id=None,
                    trace_id=trace_id,
                    parent_span_id=parent_span_id,
                    **metric.to_dict(),
                )
            except Exception as e:
                logger.debug("Failed to log decomposition trigger metric: %s", e)

        logger.info(
            "Decomposition triggered for task %s: type=%s, threshold=%s, value=%s",
            task_id,
            trigger_type,
            threshold,
            current_value,
        )

        return metric

    def get_summary(self) -> dict[str, Any]:
        """Get a summary of decomposition trigger metrics.

        Returns:
            Dict with:
            - total_triggers: Total number of decomposition triggers
            - failure_triggers: Number of failure-based triggers
            - budget_triggers: Number of budget-based triggers
            - duration_triggers: Number of duration-based triggers
        """
        return {
            "total_triggers": (
                self._failure_triggers + self._budget_triggers + self._duration_triggers
            ),
            "failure_triggers": self._failure_triggers,
            "budget_triggers": self._budget_triggers,
            "duration_triggers": self._duration_triggers,
        }

    def clear(self) -> None:
        """Clear all metrics and reset counters."""
        super().clear()
        self._failure_triggers = 0
        self._budget_triggers = 0
        self._duration_triggers = 0


# ---------------------------------------------------------------------------
# Shared auto-decompose check (extracted from FailureTracker + BudgetMonitor)
# ---------------------------------------------------------------------------

_auto_decompose_cache: bool | None = None


def is_auto_decompose_enabled() -> bool:
    """Check if auto-decomposition is enabled via config flag.

    Reads ``features.userplan.auto_decompose.enabled`` from the layered config.
    Defaults to ``True`` if not set (preserves existing behavior).

    The result is cached at module level to avoid repeated config reads.

    Returns:
        True if auto-decomposition is enabled, False if disabled via config.
    """
    global _auto_decompose_cache
    if _auto_decompose_cache is not None:
        return _auto_decompose_cache

    try:
        from obra.config.loaders import load_layered_config

        config, _, _ = load_layered_config(include_defaults=True)
        features = config.get("features", {})
        userplan = features.get("userplan", {})
        auto_decompose = userplan.get("auto_decompose", {})
        _auto_decompose_cache = auto_decompose.get("enabled", True)
    except Exception as e:
        logger.warning(
            "Failed to read auto_decompose config flag, defaulting to enabled: %s",
            e,
        )
        _auto_decompose_cache = True

    return _auto_decompose_cache


# Global singleton instance
_decomposition_metrics_collector: DecompositionMetricsCollector | None = None


def get_decomposition_metrics_collector() -> DecompositionMetricsCollector:
    """Get the global decomposition metrics collector singleton.

    Returns:
        The global DecompositionMetricsCollector instance
    """
    global _decomposition_metrics_collector
    if _decomposition_metrics_collector is None:
        _decomposition_metrics_collector = DecompositionMetricsCollector()
    return _decomposition_metrics_collector


@dataclass
class FailureRecord:
    """Record of consecutive failures for a single task.

    Tracks failure count and context for auto-decomposition decisions.

    Attributes:
        task_id: The task identifier (e.g., "S1.T1")
        consecutive_failures: Number of consecutive failures
        needs_decomposition: Flag set when failure threshold is reached
        last_error_message: The most recent error message for context
        failure_reasons: List of error messages from each failure
    """

    task_id: str
    consecutive_failures: int = 0
    needs_decomposition: bool = False
    last_error_message: str = ""
    failure_reasons: list[str] = field(default_factory=list)


class FailureTracker:
    """Tracks consecutive failures per task for auto-decomposition triggering.

    The tracker maintains failure counts per task ID. When a task fails
    consecutively N times (where N is the configured threshold), the
    `needs_decomposition` flag is set to True on the FailureRecord.

    The counter resets to 0 when a task succeeds.

    Auto-decomposition can be globally disabled via the config flag:
    features.userplan.auto_decompose.enabled = false

    When disabled, failure tracking still occurs (for monitoring), but
    needs_decomposition will never be set to True.

    Usage:
        from obra.execution.failure_tracking import FailureTracker

        tracker = FailureTracker(threshold=3)

        # Track a failure
        record = tracker.record_failure("S1.T1", "Connection timeout")
        if record.needs_decomposition:
            # Trigger auto-decomposition logic
            pass

        # Track a success (resets counter)
        record = tracker.record_success("S1.T1")
        assert record.consecutive_failures == 0

    Thread-safety:
        This class is NOT thread-safe. Use external synchronization if
        accessing from multiple threads.
    """

    def __init__(self, threshold: int | None = None) -> None:
        """Initialize FailureTracker.

        Args:
            threshold: Number of consecutive failures before needs_decomposition
                is set. If None, uses AUTO_DECOMPOSE_FAILURE_THRESHOLD from
                constants (default: 3).
        """
        if threshold is None:
            from obra.config.loaders import get_derivation_auto_decompose_config

            threshold = get_derivation_auto_decompose_config()["failure_threshold"]

        self._threshold = threshold
        self._records: dict[str, FailureRecord] = {}

    @property
    def threshold(self) -> int:
        """The failure threshold for triggering decomposition."""
        return self._threshold

    def record_failure(self, task_id: str, error_message: str = "") -> FailureRecord:
        """Record a failure for a task.

        Increments the consecutive failure count for the task. If the count
        reaches the threshold, sets needs_decomposition=True and logs a
        warning.

        Args:
            task_id: The task identifier (e.g., "S1.T1")
            error_message: Optional error message for context

        Returns:
            The updated FailureRecord for the task
        """
        if task_id not in self._records:
            self._records[task_id] = FailureRecord(task_id=task_id)

        record = self._records[task_id]
        record.consecutive_failures += 1
        record.last_error_message = error_message

        if error_message:
            record.failure_reasons.append(error_message)

        # Check if threshold is reached
        if record.consecutive_failures >= self._threshold:
            if not record.needs_decomposition:
                # Check if auto-decomposition is enabled via config flag
                if is_auto_decompose_enabled():
                    # First time reaching threshold - flag for decomposition
                    record.needs_decomposition = True
                    logger.warning(
                        "Task %s reached %d consecutive failures (threshold: %d). "
                        "Flagging for auto-decomposition. Last error: %s",
                        task_id,
                        record.consecutive_failures,
                        self._threshold,
                        error_message or "(no message)",
                    )
                    # Emit decomposition trigger metric
                    get_decomposition_metrics_collector().record_trigger(
                        trigger_type="failure",
                        task_id=task_id,
                        threshold=self._threshold,
                        current_value=record.consecutive_failures,
                        reason=error_message or None,
                    )
                else:
                    # Auto-decomposition disabled - log but don't flag
                    logger.info(
                        "Task %s reached %d consecutive failures (threshold: %d). "
                        "Auto-decomposition skipped (disabled via config). Last error: %s",
                        task_id,
                        record.consecutive_failures,
                        self._threshold,
                        error_message or "(no message)",
                    )
        else:
            logger.debug(
                "Task %s failed (%d/%d consecutive failures): %s",
                task_id,
                record.consecutive_failures,
                self._threshold,
                error_message or "(no message)",
            )

        return record

    def record_success(self, task_id: str) -> FailureRecord:
        """Record a success for a task.

        Resets the consecutive failure count to 0 and clears the
        needs_decomposition flag. The failure_reasons list is preserved
        for historical context.

        Args:
            task_id: The task identifier (e.g., "S1.T1")

        Returns:
            The updated FailureRecord for the task
        """
        if task_id not in self._records:
            self._records[task_id] = FailureRecord(task_id=task_id)

        record = self._records[task_id]
        previous_failures = record.consecutive_failures

        # Reset on success
        record.consecutive_failures = 0
        record.needs_decomposition = False
        record.last_error_message = ""

        if previous_failures > 0:
            logger.info(
                "Task %s succeeded after %d consecutive failure(s). Counter reset.",
                task_id,
                previous_failures,
            )

        return record

    def get_record(self, task_id: str) -> FailureRecord | None:
        """Get the failure record for a task.

        Args:
            task_id: The task identifier

        Returns:
            The FailureRecord if it exists, None otherwise
        """
        return self._records.get(task_id)

    def needs_decomposition(self, task_id: str) -> bool:
        """Check if a task needs decomposition.

        Args:
            task_id: The task identifier

        Returns:
            True if the task has reached the failure threshold
        """
        record = self._records.get(task_id)
        return record.needs_decomposition if record else False

    def get_failure_count(self, task_id: str) -> int:
        """Get the consecutive failure count for a task.

        Args:
            task_id: The task identifier

        Returns:
            The number of consecutive failures (0 if task not tracked)
        """
        record = self._records.get(task_id)
        return record.consecutive_failures if record else 0

    def clear(self, task_id: str | None = None) -> None:
        """Clear failure tracking data.

        Args:
            task_id: If provided, clears only that task's record.
                If None, clears all records.
        """
        if task_id is not None:
            self._records.pop(task_id, None)
        else:
            self._records.clear()

    def get_all_needing_decomposition(self) -> list[FailureRecord]:
        """Get all tasks that need decomposition.

        Returns:
            List of FailureRecords where needs_decomposition is True
        """
        return [record for record in self._records.values() if record.needs_decomposition]


@dataclass
class BudgetRecord:
    """Record of budget consumption for a single task.

    Tracks token and cost budget usage for auto-decomposition decisions.

    Attributes:
        task_id: The task identifier (e.g., "S1.T1")
        token_budget: Total token budget allocated to this task
        cost_budget_usd: Total cost budget in USD allocated to this task
        tokens_consumed: Tokens consumed so far
        cost_consumed_usd: Cost consumed so far in USD
        needs_decomposition: Flag set when budget threshold is reached
        decomposition_reason: Reason for decomposition trigger
    """

    task_id: str
    token_budget: int = 0
    cost_budget_usd: float = 0.0
    tokens_consumed: int = 0
    cost_consumed_usd: float = 0.0
    needs_decomposition: bool = False
    decomposition_reason: str = ""

    @property
    def token_consumption_ratio(self) -> float:
        """Calculate the ratio of tokens consumed to token budget.

        Returns:
            Float between 0.0 and 1.0+ (can exceed 1.0 if over budget)
        """
        if self.token_budget <= 0:
            return 0.0
        return self.tokens_consumed / self.token_budget

    @property
    def cost_consumption_ratio(self) -> float:
        """Calculate the ratio of cost consumed to cost budget.

        Returns:
            Float between 0.0 and 1.0+ (can exceed 1.0 if over budget)
        """
        if self.cost_budget_usd <= 0:
            return 0.0
        return self.cost_consumed_usd / self.cost_budget_usd

    @property
    def remaining_tokens(self) -> int:
        """Calculate remaining token budget.

        Returns:
            Remaining tokens (can be negative if over budget)
        """
        return self.token_budget - self.tokens_consumed

    @property
    def remaining_cost_usd(self) -> float:
        """Calculate remaining cost budget in USD.

        Returns:
            Remaining cost in USD (can be negative if over budget)
        """
        return self.cost_budget_usd - self.cost_consumed_usd

    def to_decomposition_context(self) -> dict[str, Any]:
        """Create decomposition context with remaining budget info.

        Returns:
            Dict with budget context for subtask decomposition
        """
        return {
            "parent_task_id": self.task_id,
            "remaining_token_budget": max(0, self.remaining_tokens),
            "remaining_cost_budget_usd": max(0.0, self.remaining_cost_usd),
            "consumed_tokens": self.tokens_consumed,
            "consumed_cost_usd": self.cost_consumed_usd,
            "budget_triggered_decomposition": self.needs_decomposition,
            "decomposition_reason": self.decomposition_reason,
        }


class BudgetMonitor:
    """Monitors budget consumption per task for auto-decomposition triggering.

    The monitor tracks token and cost usage per task ID. When a task's budget
    consumption exceeds the configured threshold without completion, the
    `needs_decomposition` flag is set to True on the BudgetRecord.

    This enables the orchestrator to automatically decompose tasks that are
    consuming too many resources, creating smaller subtasks that can be
    completed within budget.

    Auto-decomposition can be globally disabled via the config flag:
    features.userplan.auto_decompose.enabled = false

    When disabled, budget tracking still occurs (for monitoring), but
    needs_decomposition will never be set to True.

    Usage:
        from obra.execution.failure_tracking import BudgetMonitor

        monitor = BudgetMonitor()

        # Initialize budget for a task
        record = monitor.initialize_budget(
            "S1.T1",
            token_budget=100000,
            cost_budget_usd=0.50
        )

        # Record consumption during execution
        record = monitor.record_consumption(
            "S1.T1",
            tokens=5000,
            cost_usd=0.025
        )

        # Check if decomposition is needed
        if record.needs_decomposition:
            # Get context for subtask decomposition
            context = record.to_decomposition_context()
            # Trigger auto-decomposition logic

    Thread-safety:
        This class is NOT thread-safe. Use external synchronization if
        accessing from multiple threads.
    """

    def __init__(
        self,
        decompose_threshold: float | None = None,
        warning_threshold: float | None = None,
    ) -> None:
        """Initialize BudgetMonitor.

        Args:
            decompose_threshold: Budget consumption ratio (0.0-1.0) that triggers
                decomposition. If None, uses BUDGET_DECOMPOSE_THRESHOLD from
                constants (default: 0.80).
            warning_threshold: Budget consumption ratio (0.0-1.0) that triggers
                a warning. If None, uses BUDGET_WARNING_THRESHOLD from
                constants (default: 0.60).
        """
        from obra.config.loaders import get_derivation_budget_config

        budget_config = get_derivation_budget_config()
        self._decompose_threshold = (
            decompose_threshold
            if decompose_threshold is not None
            else budget_config["decompose_threshold"]
        )
        self._warning_threshold = (
            warning_threshold
            if warning_threshold is not None
            else budget_config["warning_threshold"]
        )
        self._records: dict[str, BudgetRecord] = {}

    @property
    def decompose_threshold(self) -> float:
        """The budget consumption threshold for triggering decomposition."""
        return self._decompose_threshold

    @property
    def warning_threshold(self) -> float:
        """The budget consumption threshold for logging warnings."""
        return self._warning_threshold

    def initialize_budget(
        self,
        task_id: str,
        token_budget: int | None = None,
        cost_budget_usd: float | None = None,
    ) -> BudgetRecord:
        """Initialize budget tracking for a task.

        If the task already exists, its budget is updated (useful for adjusting
        budget allocations mid-execution).

        Args:
            task_id: The task identifier (e.g., "S1.T1")
            token_budget: Token budget for the task. If None, uses
                DEFAULT_TASK_TOKEN_BUDGET from constants.
            cost_budget_usd: Cost budget in USD. If None, uses
                DEFAULT_TASK_COST_BUDGET_USD from constants.

        Returns:
            The initialized BudgetRecord for the task
        """
        from obra.config.loaders import get_derivation_task_config

        task_config = get_derivation_task_config()
        effective_token_budget = (
            token_budget if token_budget is not None else task_config["token_budget"]
        )
        effective_cost_budget = (
            cost_budget_usd if cost_budget_usd is not None else task_config["cost_budget_usd"]
        )

        if task_id in self._records:
            # Update existing record's budget (preserve consumption)
            record = self._records[task_id]
            record.token_budget = effective_token_budget
            record.cost_budget_usd = effective_cost_budget
            logger.debug(
                "Updated budget for task %s: tokens=%d, cost_usd=%.4f",
                task_id,
                effective_token_budget,
                effective_cost_budget,
            )
        else:
            # Create new record
            record = BudgetRecord(
                task_id=task_id,
                token_budget=effective_token_budget,
                cost_budget_usd=effective_cost_budget,
            )
            self._records[task_id] = record
            logger.debug(
                "Initialized budget for task %s: tokens=%d, cost_usd=%.4f",
                task_id,
                effective_token_budget,
                effective_cost_budget,
            )

        return record

    def record_consumption(
        self,
        task_id: str,
        tokens: int = 0,
        cost_usd: float = 0.0,
    ) -> BudgetRecord:
        """Record budget consumption for a task.

        Increments the consumption counters and checks if thresholds are reached.
        If the task hasn't been initialized, it will be auto-initialized with
        default budgets.

        Args:
            task_id: The task identifier (e.g., "S1.T1")
            tokens: Number of tokens consumed in this increment
            cost_usd: Cost consumed in USD in this increment

        Returns:
            The updated BudgetRecord for the task
        """
        # Auto-initialize if not tracked
        if task_id not in self._records:
            self.initialize_budget(task_id)

        record = self._records[task_id]
        record.tokens_consumed += tokens
        record.cost_consumed_usd += cost_usd

        # Check thresholds
        token_ratio = record.token_consumption_ratio
        cost_ratio = record.cost_consumption_ratio
        max_ratio = max(token_ratio, cost_ratio)

        # Determine which budget triggered (for decomposition context)
        trigger_type = "token" if token_ratio >= cost_ratio else "cost"

        # Log warning if approaching threshold
        if max_ratio >= self._warning_threshold and max_ratio < self._decompose_threshold:
            logger.warning(
                "Task %s approaching budget threshold: %.1f%% consumed "
                "(tokens: %d/%d, cost: $%.4f/$%.4f)",
                task_id,
                max_ratio * 100,
                record.tokens_consumed,
                record.token_budget,
                record.cost_consumed_usd,
                record.cost_budget_usd,
            )

        # Check if decomposition threshold is reached
        if max_ratio >= self._decompose_threshold:
            if not record.needs_decomposition:
                # Check if auto-decomposition is enabled via config flag
                if is_auto_decompose_enabled():
                    # First time reaching threshold - flag for decomposition
                    record.needs_decomposition = True
                    record.decomposition_reason = (
                        f"Budget threshold exceeded: {trigger_type} at {max_ratio:.1%} "
                        f"(threshold: {self._decompose_threshold:.0%})"
                    )
                    logger.warning(
                        "Task %s exceeded budget threshold (%.1f%% consumed). "
                        "Flagging for auto-decomposition. "
                        "Tokens: %d/%d (%.1f%%), Cost: $%.4f/$%.4f (%.1f%%)",
                        task_id,
                        max_ratio * 100,
                        record.tokens_consumed,
                        record.token_budget,
                        token_ratio * 100,
                        record.cost_consumed_usd,
                        record.cost_budget_usd,
                        cost_ratio * 100,
                    )
                    # Emit decomposition trigger metric
                    get_decomposition_metrics_collector().record_trigger(
                        trigger_type="budget",
                        task_id=task_id,
                        threshold=self._decompose_threshold,
                        current_value=max_ratio,
                        reason=record.decomposition_reason,
                    )
                else:
                    # Auto-decomposition disabled - log but don't flag
                    record.decomposition_reason = (
                        f"Budget threshold exceeded: {trigger_type} at {max_ratio:.1%} "
                        f"(threshold: {self._decompose_threshold:.0%}) - auto-decomposition disabled"
                    )
                    logger.info(
                        "Task %s exceeded budget threshold (%.1f%% consumed). "
                        "Auto-decomposition skipped (disabled via config). "
                        "Tokens: %d/%d (%.1f%%), Cost: $%.4f/$%.4f (%.1f%%)",
                        task_id,
                        max_ratio * 100,
                        record.tokens_consumed,
                        record.token_budget,
                        token_ratio * 100,
                        record.cost_consumed_usd,
                        record.cost_budget_usd,
                        cost_ratio * 100,
                    )
        else:
            logger.debug(
                "Task %s budget consumption: %.1f%% (tokens: %d/%d, cost: $%.4f/$%.4f)",
                task_id,
                max_ratio * 100,
                record.tokens_consumed,
                record.token_budget,
                record.cost_consumed_usd,
                record.cost_budget_usd,
            )

        return record

    def record_success(self, task_id: str) -> BudgetRecord:
        """Record successful task completion.

        Clears the needs_decomposition flag since the task completed.
        The consumption data is preserved for historical/reporting purposes.

        Args:
            task_id: The task identifier (e.g., "S1.T1")

        Returns:
            The updated BudgetRecord for the task
        """
        if task_id not in self._records:
            self.initialize_budget(task_id)

        record = self._records[task_id]
        was_flagged = record.needs_decomposition

        # Clear decomposition flag on success
        record.needs_decomposition = False
        record.decomposition_reason = ""

        if was_flagged:
            logger.info(
                "Task %s completed despite budget threshold. "
                "Final consumption: tokens=%d (%.1f%%), cost=$%.4f (%.1f%%)",
                task_id,
                record.tokens_consumed,
                record.token_consumption_ratio * 100,
                record.cost_consumed_usd,
                record.cost_consumption_ratio * 100,
            )
        else:
            logger.debug(
                "Task %s completed successfully. "
                "Final consumption: tokens=%d (%.1f%%), cost=$%.4f (%.1f%%)",
                task_id,
                record.tokens_consumed,
                record.token_consumption_ratio * 100,
                record.cost_consumed_usd,
                record.cost_consumption_ratio * 100,
            )

        return record

    def get_record(self, task_id: str) -> BudgetRecord | None:
        """Get the budget record for a task.

        Args:
            task_id: The task identifier

        Returns:
            The BudgetRecord if it exists, None otherwise
        """
        return self._records.get(task_id)

    def needs_decomposition(self, task_id: str) -> bool:
        """Check if a task needs decomposition due to budget.

        Args:
            task_id: The task identifier

        Returns:
            True if the task has reached the budget threshold
        """
        record = self._records.get(task_id)
        return record.needs_decomposition if record else False

    def get_decomposition_context(self, task_id: str) -> dict[str, Any] | None:
        """Get decomposition context for a task.

        Args:
            task_id: The task identifier

        Returns:
            Dict with budget context for subtask decomposition, or None if
            task is not being tracked
        """
        record = self._records.get(task_id)
        return record.to_decomposition_context() if record else None

    def get_remaining_budget(self, task_id: str) -> tuple[int, float] | None:
        """Get remaining budget for a task.

        Args:
            task_id: The task identifier

        Returns:
            Tuple of (remaining_tokens, remaining_cost_usd) or None if
            task is not being tracked
        """
        record = self._records.get(task_id)
        if record is None:
            return None
        return (record.remaining_tokens, record.remaining_cost_usd)

    def clear(self, task_id: str | None = None) -> None:
        """Clear budget tracking data.

        Args:
            task_id: If provided, clears only that task's record.
                If None, clears all records.
        """
        if task_id is not None:
            self._records.pop(task_id, None)
        else:
            self._records.clear()

    def get_all_needing_decomposition(self) -> list[BudgetRecord]:
        """Get all tasks that need decomposition due to budget.

        Returns:
            List of BudgetRecords where needs_decomposition is True
        """
        return [record for record in self._records.values() if record.needs_decomposition]

    def get_status_summary(self, task_id: str) -> dict[str, Any] | None:
        """Get a summary of budget status for a task.

        Useful for logging and observability.

        Args:
            task_id: The task identifier

        Returns:
            Dict with budget status summary, or None if task not tracked
        """
        record = self._records.get(task_id)
        if record is None:
            return None

        return {
            "task_id": task_id,
            "token_budget": record.token_budget,
            "tokens_consumed": record.tokens_consumed,
            "token_consumption_pct": round(record.token_consumption_ratio * 100, 1),
            "cost_budget_usd": record.cost_budget_usd,
            "cost_consumed_usd": record.cost_consumed_usd,
            "cost_consumption_pct": round(record.cost_consumption_ratio * 100, 1),
            "remaining_tokens": record.remaining_tokens,
            "remaining_cost_usd": round(record.remaining_cost_usd, 4),
            "needs_decomposition": record.needs_decomposition,
            "decomposition_reason": record.decomposition_reason,
        }
