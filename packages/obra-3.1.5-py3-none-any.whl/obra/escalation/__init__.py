"""Escalation subsystem — typed models, state machine, telemetry events, and configuration."""

from typing import Any

__all__ = [
    "EscalationConfig",
    "EscalationEvent",
    "EscalationInvariantError",
    "EscalationManager",
    "EscalationOutcome",
    "EscalationState",
    "EscalationStateMachine",
]

# Submodule import map for PEP 562 lazy loading (Rule 20, ADR-045)
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "EscalationState": (".models", "EscalationState"),
    "EscalationOutcome": (".models", "EscalationOutcome"),
    "EscalationInvariantError": (".models", "EscalationInvariantError"),
    "EscalationStateMachine": (".state_machine", "EscalationStateMachine"),
    "EscalationConfig": (".config", "EscalationConfig"),
    "EscalationEvent": (".telemetry", "EscalationEvent"),
    "EscalationManager": (".manager", "EscalationManager"),
}


def __getattr__(name: str) -> Any:
    """PEP 562 lazy loading for escalation submodules (ADR-045, Rule 20)."""
    if name in _LAZY_IMPORTS:
        import importlib

        module_path, attr_name = _LAZY_IMPORTS[name]
        module = importlib.import_module(module_path, __name__)
        return getattr(module, attr_name)
    msg = f"module {__name__!r} has no attribute {name!r}"
    raise AttributeError(msg)
