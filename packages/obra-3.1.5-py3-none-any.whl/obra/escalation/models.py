"""Escalation domain models — state enum, outcome dataclass, and invariant error."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class EscalationState(str, Enum):
    """Escalation lifecycle states."""

    NONE = "none"
    """No escalation in progress."""

    TRIGGERED = "triggered"
    """Server emitted ESCALATE action."""

    WAITING_DECISION = "waiting"
    """Prompt displayed, awaiting user input."""

    DECIDED = "decided"
    """User made a choice."""

    RESUMED = "resumed"
    """CONTINUE_FIXING accepted, refinement restarted."""

    TERMINAL = "terminal"
    """FORCE_COMPLETE, SKIP_ISSUES, or ABANDON applied."""


@dataclass
class EscalationOutcome:
    """Result of handling an escalation notice.

    Replaces the ad-hoc dict previously returned by orchestrator._handle_escalation.
    """

    escalation_id: str
    decision: str
    """UserDecisionChoice.value string, e.g. 'force_complete'."""

    reason: str
    """EscalationReason.value string."""

    decision_reason: str
    """Free-text reason for the decision, e.g. 'Auto-completed (no interactive handler)'.

    Maps to the 'reason' field in the UserDecision payload sent to server.
    """

    was_timeout: bool
    blocking_issues_count: int
    decision_source: str
    """One of 'user_input', 'timeout', 'default_no_callback'."""

    decision_wait_ms: float
    blocking_item_ids: list[str] = field(default_factory=list)


class EscalationInvariantError(Exception):
    """Raised when the escalation state machine detects an invalid transition."""
