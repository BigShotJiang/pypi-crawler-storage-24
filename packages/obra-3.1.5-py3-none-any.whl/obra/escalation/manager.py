"""EscalationManager — extracted escalation lifecycle handler.

Owns the escalation state machine, telemetry emission, and decision handling
previously embedded in ``obra.hybrid.orchestrator.HybridOrchestrator``.
"""

from __future__ import annotations

import logging
import time
import uuid
from collections.abc import Callable
from typing import Any

from obra.api.protocol import (
    EscalationDecision,
    EscalationNotice,
    EscalationReason,
    UserDecisionChoice,
)
from obra.display.observability import ProgressEmitter
from obra.escalation.config import EscalationConfig
from obra.escalation.models import EscalationOutcome, EscalationState
from obra.escalation.state_machine import EscalationStateMachine
from obra.escalation.telemetry import (
    EscalationDecisionEvent,
    EscalationPromptWaitingEvent,
    emit,
)

logger = logging.getLogger(__name__)


class EscalationManager:
    """Manages the full escalation lifecycle with typed state machine and telemetry.

    Dependencies are injected via constructor to avoid tight coupling to
    orchestrator internals.

    Args:
        log_session_event: Callback with signature ``(event_type: str, **kwargs) -> None``.
        progress_emitter: ProgressEmitter for console output.
        on_escalation: Optional interactive escalation callback (CLI or gateway).
        config: Escalation configuration. Defaults to ``EscalationConfig()`` if None.
        fix_result_history: Reference to orchestrator's fix result history list.
    """

    def __init__(
        self,
        *,
        log_session_event: Callable[..., None],
        progress_emitter: ProgressEmitter | None = None,
        on_escalation: Callable[[EscalationNotice], EscalationDecision] | None = None,
        config: EscalationConfig | None = None,
        fix_result_history: list[dict[str, Any]] | None = None,
    ) -> None:
        self._log_session_event = log_session_event
        self._progress_emitter = progress_emitter
        self._on_escalation = on_escalation
        self._config = config or EscalationConfig()
        self._fix_result_history: list[dict[str, Any]] = fix_result_history if fix_result_history is not None else []

        self._state_machine = EscalationStateMachine(
            on_transition=self._on_state_transition,
        )

    def _on_state_transition(
        self, from_state: EscalationState, to_state: EscalationState
    ) -> None:
        """Log state transitions for debugging."""
        logger.debug(
            "Escalation state transition: %s -> %s",
            from_state.value,
            to_state.value,
        )

    @property
    def was_escalated(self) -> bool:
        """Whether this session ever experienced an escalation (permanent flag)."""
        return self._state_machine.was_escalated

    # Reasons where a non-zero blocking count is expected.
    _BLOCKING_REASONS = frozenset({
        "blocked",
        "blocking_issues_unresolved",
        "max_refinement_iterations",
    })

    def derive_blocking_count(self, notice: EscalationNotice) -> int:
        """Derive blocking issue count from notice with protocol-compatible fallbacks.

        Precedence:
            1) ``len(notice.blocking_issues)``
            2) ``len(escalation_context.blocking_failures)`` for Story0 blocker escalations
            3) ``max(convergence_diagnostic.per_cycle_blocking_sizes)`` for convergence stalls

        Args:
            notice: Escalation notice from server.

        Returns:
            Number of blocking issues.
        """
        blocking_count = len(notice.blocking_issues or [])
        if blocking_count == 0 and isinstance(notice.escalation_context, dict):
            raw_blocking_failures = notice.escalation_context.get("blocking_failures")
            if isinstance(raw_blocking_failures, list):
                blocking_count = len(raw_blocking_failures)
        if blocking_count == 0 and isinstance(notice.convergence_diagnostic, dict):
            sizes = notice.convergence_diagnostic.get(
                "per_cycle_blocking_sizes", {}
            )
            if isinstance(sizes, dict) and sizes:
                blocking_count = max(
                    (int(v) for v in sizes.values()), default=0
                )
        if blocking_count == 0 and notice.reason.value in self._BLOCKING_REASONS:
            logger.warning(
                "Escalation %s has reason %s but blocking_issues_count derived as 0",
                notice.escalation_id,
                notice.reason.value,
            )
        return blocking_count

    def _build_fix_failure_summary(self) -> dict[str, Any] | None:
        """Build fix failure summary from fix result history."""
        if not self._fix_result_history:
            return None
        failed_fixes = [
            fr for fr in self._fix_result_history if fr.get("status") == "failed"
        ]
        return {
            "total_attempts": len(self._fix_result_history),
            "failed": len(failed_fixes),
            "recent_failures": failed_fixes[-5:],
        }

    @staticmethod
    def extract_blocking_item_ids(notice: EscalationNotice) -> list[str]:
        """Extract blocking item IDs from notice with multi-source fallback.

        Checks ``notice.blocking_issues`` dicts for ``id`` keys first,
        then falls back to ``convergence_diagnostic.persisted_issues``.

        Args:
            notice: Escalation notice from server.

        Returns:
            De-duplicated list of blocking item ID strings (may be empty).
        """
        ids: list[str] = []
        raw_issues = notice.blocking_issues if isinstance(notice.blocking_issues, list) else []
        for issue in raw_issues:
            if isinstance(issue, dict):
                issue_id = issue.get("id") or issue.get("issue_id") or issue.get("item_id")
                if issue_id and str(issue_id).strip():
                    ids.append(str(issue_id).strip())
        if not ids and isinstance(notice.convergence_diagnostic, dict):
            persisted = notice.convergence_diagnostic.get("persisted_issues", [])
            if isinstance(persisted, list):
                for pid in persisted:
                    if pid and str(pid).strip():
                        ids.append(str(pid).strip())
        # De-duplicate while preserving order
        seen: set[str] = set()
        unique: list[str] = []
        for item_id in ids:
            if item_id not in seen:
                seen.add(item_id)
                unique.append(item_id)
        return unique

    def log_escalation_decision(
        self,
        notice: EscalationNotice,
        decision: str,
        was_timeout: bool,
        blocking_count: int,
        decision_source: str,
        decision_wait_ms: float,
    ) -> None:
        """Log escalation decision event and emit progress summary.

        Args:
            notice: Escalation notice from server.
            decision: User decision value (e.g. 'force_complete').
            was_timeout: Whether the decision was due to timeout.
            blocking_count: Number of blocking issues.
            decision_source: Where decision came from.
            decision_wait_ms: Time spent waiting for escalation decision.
        """
        esc_id = notice.escalation_id or f"esc-{uuid.uuid4().hex[:12]}"
        blocking_item_ids = self.extract_blocking_item_ids(notice)
        event = EscalationDecisionEvent(
            escalation_id=esc_id,
            reason=notice.reason.value,
            decision=decision,
            was_timeout=was_timeout,
            decision_source=decision_source,
            decision_wait_ms=decision_wait_ms,
            blocking_issues_count=blocking_count,
            blocking_item_ids=blocking_item_ids,
            fix_failure_summary=self._build_fix_failure_summary(),
        )
        emit(event, self._log_session_event)

        if self._progress_emitter:
            failed_fixes = [
                fr for fr in self._fix_result_history if fr.get("status") == "failed"
            ]
            self._progress_emitter.escalation_summary(
                reason=notice.reason.value,
                fix_attempts=len(self._fix_result_history),
                fix_results=failed_fixes[-5:] if failed_fixes else None,
            )

    def handle(self, notice: EscalationNotice) -> EscalationOutcome:
        """Handle an escalation notice through the full lifecycle.

        Transitions the state machine through NONE -> TRIGGERED -> WAITING_DECISION
        -> DECIDED -> TERMINAL (or RESUMED -> NONE for CONTINUE_FIXING).

        Args:
            notice: Escalation notice from server.

        Returns:
            Typed outcome describing the decision and telemetry context.
        """
        # Transition: NONE -> TRIGGERED -> WAITING_DECISION
        self._state_machine.transition(EscalationState.TRIGGERED)
        self._state_machine.transition(EscalationState.WAITING_DECISION)

        blocking_count = self.derive_blocking_count(notice)
        esc_id = notice.escalation_id or f"esc-{uuid.uuid4().hex[:12]}"

        # Emit prompt-waiting event before blocking on input
        prompt_event = EscalationPromptWaitingEvent(
            escalation_id=esc_id,
            reason=notice.reason.value,
        )
        emit(prompt_event, self._log_session_event)

        start_time = time.monotonic()

        if self._on_escalation is not None:
            # Interactive path (CLI callback or gateway)
            result = self._on_escalation(notice)
            decision = result.choice.value
            was_timeout = result.was_timeout
            decision_source = "timeout" if result.was_timeout else "user_input"
            decision_reason = ""
        else:
            # No-callback path: render and auto-force-complete
            from obra.display import EscalationRenderer, console

            EscalationRenderer(console).render_full(notice)

            # Show --permissive tip for refinement-related escalations
            blocking_issues = notice.blocking_issues if isinstance(notice.blocking_issues, list) else []
            refinement_reasons = {
                EscalationReason.MAX_ITERATIONS,
                EscalationReason.MAX_REFINEMENT_ITERATIONS,
                EscalationReason.BLOCKED,
                EscalationReason.QUALITY_THRESHOLD_NOT_MET,
            }
            if notice.reason in refinement_reasons and blocking_issues:
                console.print("\n  [bold]Tip:[/bold] Use --permissive to bypass P1 issues and proceed.")
                console.print("       Or clarify your objective and retry, e.g.:")
                console.print('       "Add feature X (use library Y, handle errors with Z)"')

            decision = UserDecisionChoice.FORCE_COMPLETE.value
            was_timeout = True
            decision_source = "default_no_callback"
            decision_reason = "Auto-completed (no interactive handler)"

        decision_wait_ms = (time.monotonic() - start_time) * 1000

        # Transition: WAITING_DECISION -> DECIDED
        self._state_machine.transition(EscalationState.DECIDED)

        # Log decision event and progress summary
        self.log_escalation_decision(
            notice, decision, was_timeout, blocking_count,
            decision_source, decision_wait_ms,
        )

        # Transition: DECIDED -> TERMINAL or DECIDED -> RESUMED -> NONE
        if decision == UserDecisionChoice.CONTINUE_FIXING.value:
            self._state_machine.transition(EscalationState.RESUMED)
            self._state_machine.transition(EscalationState.NONE)
        else:
            self._state_machine.transition(EscalationState.TERMINAL)

        return EscalationOutcome(
            escalation_id=esc_id,
            decision=decision,
            reason=notice.reason.value,
            decision_reason=decision_reason,
            was_timeout=was_timeout,
            blocking_issues_count=blocking_count,
            blocking_item_ids=self.extract_blocking_item_ids(notice),
            decision_source=decision_source,
            decision_wait_ms=decision_wait_ms,
        )
