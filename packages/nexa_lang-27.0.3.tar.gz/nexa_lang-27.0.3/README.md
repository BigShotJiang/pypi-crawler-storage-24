<div align="center">

<<<<<<< HEAD
<img src="https://nexa-lang.dev/logo.svg" alt="Nexa Language" width="120">

# Nexa Language

**The first programming language where `model`, `train`, and `predict` are keywords.**

[![CI](https://github.com/yuvaraj030/nexa-lang/actions/workflows/test.yml/badge.svg)](https://github.com/yuvaraj030/nexa-lang/actions)
[![PyPI](https://img.shields.io/pypi/v/nexa-lang.svg)](https://pypi.org/project/nexa-lang/)
[![Python](https://img.shields.io/pypi/pyversions/nexa-lang.svg)](https://pypi.org/project/nexa-lang/)
[![License: MIT](https://img.shields.io/badge/License-MIT-blue.svg)](LICENSE)
[![Discord](https://img.shields.io/discord/nexa-lang.svg?logo=discord)](https://discord.gg/nexa-lang)
[![Registry](https://img.shields.io/badge/registry-registry.nexa--lang.dev-9cf)](https://registry.nexa-lang.dev)

[Website](https://nexa-lang.dev) · [Docs](https://docs.nexa-lang.dev) · [Packages](https://registry.nexa-lang.dev) · [Discord](https://discord.gg/nexa-lang) · [Blog](https://blog.nexa-lang.dev)
=======
<h1>
  <img src="https://img.shields.io/badge/NEXA-v27-blueviolet?style=for-the-badge&logo=data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHZpZXdCb3g9IjAgMCAyNCAyNCI+PHBhdGggZmlsbD0id2hpdGUiIGQ9Ik0xMiAyTDIgN2wxMCA1IDEwLTV6TTIgMTdsIDEwIDUgMTAtNXYtN2wtMTAgNUwyIDEweiIvPjwvc3ZnPg==" alt="Nexa v27" />
</h1>

<h2>⚡ Nexa Programming Language</h2>

<p><strong>Modern · AI-Native · Expressive · Safe</strong></p>

<p>
  <em>The language where AI is a first-class citizen.</em><br/>
  Blending the clarity of Python, the safety of Rust, and built-in AI primitives — in one clean syntax.
</p>

[![Build](https://img.shields.io/badge/build-passing-brightgreen?style=flat-square)](https://github.com/nexa-lang/nexa)
[![Version](https://img.shields.io/badge/version-v27-blueviolet?style=flat-square)](https://github.com/nexa-lang/nexa/releases)
[![License](https://img.shields.io/badge/license-MIT-blue?style=flat-square)](LICENSE.md)
[![Python](https://img.shields.io/badge/runtime-Python%203.10+-yellow?style=flat-square)](https://python.org)
[![Discord](https://img.shields.io/badge/community-Discord-5865F2?style=flat-square&logo=discord)](https://discord.gg/nexa-lang)
[![Stars](https://img.shields.io/github/stars/nexa-lang/nexa?style=flat-square&color=orange)](https://github.com/nexa-lang/nexa/stargazers)

<br/>

```nexa
import "agent"

// Build an AI chatbot in 10 lines 🤖
let bot = agent.create("groq", model="llama-3.3-70b")
var history = []

loop {
    let input = read("You: ")
    if input == "quit" { break }
    append(history, {"role": "user", "content": input})
    let reply = await bot.chat(history)
    print(f"Bot: {reply}")
}
```

**👆 That's it. An AI chatbot with memory. In Nexa.**

[📖 Documentation](#documentation) · [🚀 Quick Start](#quick-start) · [💬 Community](https://discord.gg/nexa-lang) · [🗺️ Roadmap](ROADMAP.md)
>>>>>>> 505371e59d95447c4de1bb675f9eb2687f79f60d

</div>

---

<<<<<<< HEAD
## 🚀 Install
=======
## ✨ Why Nexa?

| Feature | Python | Rust | Go | **Nexa** |
|---------|--------|------|----|----------|
| Easy syntax | ✅ | ❌ | ✅ | ✅ |
| Type safety | ⚠️ | ✅ | ✅ | ✅ |
| AI keywords built-in | ❌ | ❌ | ❌ | **✅** |
| Pattern matching | ⚠️ | ✅ | ❌ | **✅** |
| Async/await | ✅ | ✅ | ✅ | **✅** |
| REPL | ✅ | ❌ | ❌ | **✅** |
| Built-in test framework | ❌ | ✅ | ✅ | **✅** |
| Pipe operators | ❌ | ❌ | ❌ | **✅** |
| Package manager | ✅ | ✅ | ✅ | **✅** |

---

## 🚀 Quick Start

### Install
>>>>>>> 505371e59d95447c4de1bb675f9eb2687f79f60d

```bash
pip install nexa-lang
```

<<<<<<< HEAD
That's it. No build system. No dependencies. Works on Windows, Mac, Linux.

---

## ✨ What makes Nexa different?

```nexa
// Train a neural network in 3 lines — no imports, no boilerplate
model Classifier {
    layers: [Dense(256), ReLU, Dropout(0.3), Dense(10)]
    optimizer: "adam"
}
train Classifier on my_dataset { epochs: 50, batch: 32 }
let prediction = predict Classifier(new_input)
```

No other language on Earth makes this possible. `model`, `train`, and `predict` are **keywords** — not library calls, not decorators, not framework syntax. First-class language citizens.

---

## 🌟 Language Features

| Feature | Nexa | Python | Rust | Go |
|---------|------|--------|------|-----|
| AI-native syntax (`model`/`train`) | ✅ Native | Library | ❌ | ❌ |
| Null safety | ✅ Runtime+Static | ❌ | ✅ Option | ✅ nil |
| Traits | ✅ | ❌ | ✅ | ✅ interface |
| Async generators | ✅ | ✅ | ✅ | ✅ |
| `const` enforcement | ✅ Runtime | ❌ | ✅ | `const` |
| Newtype pattern | ✅ | ❌ | ✅ | ❌ |
| Goroutine-style concurrency | ✅ `spawn()` | ❌ | ❌ | ✅ |
| Package signing (GPG) | ✅ | ❌ | ✅ | ❌ |
| One-command deploy | ✅ 4 targets | ❌ | ❌ | ❌ |

---

## 📖 Quick Examples

<details>
<summary><b>💡 Basic Syntax</b></summary>

```nexa
// Immutable by default — like Rust, friendly like Python
let name: String = "Alice"      // immutable
var counter: Int = 0            // explicitly mutable
const MAX: Int = 100            // compile + runtime constant

// F-strings with {{ literal brace escape
let msg = f"Hello, {name}! Max is {MAX}"
let template_msg = f"Brace: {{literal}}"  // → "Brace: {literal}"

// Null safety
let city = user?.address?.city ?? "Unknown"
let x: Int? = null    // ✅  nullable
let y: Int  = null    // ❌  NexaRuntimeError at runtime
```
</details>

<details>
<summary><b>🔧 Functions & Traits</b></summary>

```nexa
def greet(name: String, greeting: String = "Hello") -> String {
    return f"{greeting}, {name}!"
}

// Lambda
let double = fn(x) => x * 2
let result = [1, 2, 3] |> map(double) |> filter(fn(x) => x > 2)

// Traits
trait Serializable {
    def to_json(self) -> String {}
}

class User(name: String, age: Int) {
    impl Serializable {
        def to_json(self) -> String {
            return f"{{\"name\":\"{self.name}\",\"age\":{self.age}}}"
        }
    }
}
```
</details>

<details>
<summary><b>🔀 Pattern Matching</b></summary>

```nexa
import "result"

def safe_divide(a: Int, b: Int) -> Result<Float, String> {
    if b == 0 { return result.err("Division by zero") }
    return result.ok(a / b)
}

let r = safe_divide(10, 2)
match r {
    case Ok(val)  => print(f"Result: {val}")
    case Err(msg) => print(f"Error: {msg}")
}

// Error pipe — only runs on Err
r |? fn(e) => log(f"Pipeline failed: {e}")
=======
### Run your first Nexa program

```bash
echo 'print("Hello, Nexa!")' > hello.nexa
nexa run hello.nexa
```

### Or use the REPL

```bash
nexa repl
```

---

## 🌟 Core Features

### 🔒 Immutable by Default
```nexa
let name = "Nexa"   // immutable — safe
var count = 0       // explicit mutability
count += 1
```

### 🤖 AI as a First-Class Citizen
```nexa
// Train an ML model with language-level keywords
model Classifier {
    layer Dense(128, activation="relu")
    layer Dense(64,  activation="relu")
    layer Dense(10,  activation="softmax")
}

let clf = new Classifier()
train clf on training_data {
    epochs    = 10
    optimizer = "adam"
    loss      = "crossentropy"
}

let output = predict clf(input_features)
```

### 🔀 Pipe Operators
```nexa
// Chain transformations elegantly
let result = [1, 2, 3, 4, 5]
    |> map(fn(x) => x * 2)
    |> filter(fn(x) => x > 4)
    |> sum()
// result = 24
```

### 🎯 Pattern Matching
```nexa
match response {
    case {"ok": true,  "data": d} { process(d) }
    case {"ok": false, "error": e} { log_error(e) }
    default { print("unexpected response") }
}
```

### ⚡ Async / Concurrent
```nexa
async def fetch_all(urls) {
    for url in urls {
        spawn fetch(url)   // concurrent tasks
    }
}
```

### 🧪 Built-in Testing
```nexa
test "addition works" {
    assert 2 + 2 == 4
}

bench "list append x1000" {
    var l = []
    for i in 0..1000 { append(l, i) }
}
```

Run with:
```bash
nexa test myfile.nexa
nexa bench myfile.nexa
```

### 🌐 Generics (Templates)
```nexa
template Stack<T> {
    var items: List = []
    def push(item: T)  { append(items, item) }
    def pop()  -> T    { return items[len(items)-1] }
    def size() -> Int  { return len(items) }
}

let s = new Stack<Int>()
s.push(42)
s.pop()   // 42
```

---

## 📦 Package Manager

```bash
# Install a package
nexa pkg install nexa_http

# Search packages
nexa pkg search ai

# Publish your package
nexa pkg publish
```

---

## 🛠️ CLI Reference

| Command | Description |
|---------|-------------|
| `nexa run file.nexa` | Execute a Nexa script |
| `nexa repl` | Start the interactive REPL |
| `nexa test file.nexa` | Run all tests |
| `nexa check file.nexa` | Static type checking |
| `nexa fmt file.nexa` | Format code |
| `nexa bench file.nexa` | Run benchmarks |
| `nexa doc file.nexa` | Generate documentation |
| `nexa pkg install <pkg>` | Install a package |
| `nexa pkg publish` | Publish a package |

---

## 📚 Documentation

| Resource | Description |
|----------|-------------|
| [📖 The Nexa Book](docs/) | Complete language reference (Ch 1–20) |
| [⚡ Nexa by Example](examples/) | Quick copy-paste examples |
| [🤖 AI Tutorial](docs/ai-tutorial.md) | Build AI apps with Nexa |
| [🌐 Web Tutorial](docs/web-tutorial.md) | REST APIs and web servers |
| [🔐 Security Guide](docs/security.md) | Nexa for cybersecurity |

---

## 🏗️ Real-World Examples

<details>
<summary>🌐 <strong>REST API Server</strong></summary>

```nexa
import "http"

def handle_hello(req) {
    return {"message": f"Hello, {req.params.name}!"}
}

let app = http.server()
app.get("/hello/:name", handle_hello)
app.listen(8080)
print("Server running on http://localhost:8080")
>>>>>>> 505371e59d95447c4de1bb675f9eb2687f79f60d
```
</details>

<details>
<<<<<<< HEAD
<summary><b>⚡ Concurrency</b></summary>

```nexa
// Goroutine-style parallel tasks
let data = spawn({
    "prices": fn() => fetch("https://api.example.com/prices"),
    "news":   fn() => fetch("https://api.example.com/news"),
})
print(data["prices"])

// Async generators
async def stream_events() {
    yield fetch("/api/event/1")
    yield fetch("/api/event/2")
}
for event in stream_events() { process(event) }

// Channels
let ch = Channel()
spawn({ "sender": fn() => { ch.send(42); ch.send(99) } })
print(ch.recv())   // → 42
```
</details>

<details>
<summary><b>🧪 Testing</b></summary>

```nexa
test "user service" {
    let user = User("Alice", 30)
    
    // Rich matchers (v27)
    expect(user.name).to_equal("Alice")
    expect(user.age).to_be_in_range(18, 120)
    expect(user.to_json()).to_contain("Alice")
    expect(fn() => validate(null)).to_throw("NullError")
    
    // ML-specific
    expect(model.accuracy).to_be_greater_than(0.9)
</details>

<details>
<summary><b>🤖 Multi-Provider AI Agents</b></summary>
=======
<summary>🤖 <strong>AI Agent with Memory</strong></summary>
>>>>>>> 505371e59d95447c4de1bb675f9eb2687f79f60d

```nexa
import "agent"

<<<<<<< HEAD
// Chat with Anthropic, OpenAI, Groq, or local Ollama models natively
let res = agent.ask("Write a Haiku about code", model="claude-3-opus", provider="anthropic")

// Enforce strict JSON output with schema parsing
let data = agent.ask_json("Extract user details", schema={"name": "str", "age": "int"})

// Or stream tokens directly to stdout
for token in agent.stream("Explain quantum physics") {
    print(token)
=======
let bot = agent.create("groq", model="llama-3.3-70b")
var history = []

loop {
    let user_input = read("You: ")
    if user_input == "quit" { break }

    append(history, {"role": "user", "content": user_input})
    let reply = await bot.chat(history)
    print(f"Bot: {reply}")
    append(history, {"role": "assistant", "content": reply})
}
```
</details>

<details>
<summary>🧠 <strong>ML Classifier</strong></summary>

```nexa
// AutoML — Nexa picks the best model automatically
automl target=labels from features {
    task       = "classification"
    time_limit = 60
>>>>>>> 505371e59d95447c4de1bb675f9eb2687f79f60d
}
```
</details>

---

<<<<<<< HEAD
```bash
# Core
nexa run   main.nexa           # run a program
nexa check main.nexa           # strict type check + return checking
nexa test  test_suite.nexa     # run tests
nexa bench bench.nexa          # benchmark
nexa fmt   main.nexa           # format code
nexa shell                     # smart REPL (.history, .type, multiline)

# Build
nexa build --target llvm       # compile to native binary
nexa build-vm                  # compile C VM (5-15× speedup)

# Project
nexa new my-app --template ai|web|cli|pwa
nexa deploy --target vercel|railway|hf|fly
nexa migrate existing.py       # migrate Python → Nexa

# Packages
nexa install  nexa-http        # install from registry
nexa publish  --sign           # publish with GPG signature
nexa search   "http client"    # search registry

# Help
nexa explain "result.ok"       # context-aware docs
nexa explain error E0010       # error code guide
nexa lsp                       # language server (VS Code)
```

---

## 📦 Package Registry

Browse and install packages at **[registry.nexa-lang.dev](https://registry.nexa-lang.dev)**

```bash
nexa install nexa-http         # HTTP client
nexa install nexa-env          # .env file loader
nexa install nexa-log          # structured logging
nexa install nexa-retry        # retry with backoff
nexa install nexa-color        # terminal colors
```

---

## ⚡ Performance

| Mode | Speed vs Python | Command |
|------|----------------|---------|
| Interpreter | ~0.5× | `nexa run` |
| Bytecode VM | ~0.9× | `nexa run` |
| **C VM (native)** | **5–15×** | `nexa build-vm && nexa run` |
| LLVM native | 10–50× | `nexa build --target llvm` |

```bash
# Compile the native C VM once:
nexa build-vm
# From now on, nexa run automatically uses the fast VM
```
=======
## 🗺️ Roadmap

- [x] Lexer, Parser, Interpreter (v1–v14)
- [x] Type checker (`nexa check`)
- [x] Async/await, concurrency (`spawn`)
- [x] Generics / Templates, Structs, Enums, Newtypes
- [x] Package manager + registry
- [x] LSP server (VSCode extension)
- [x] AI keywords (`model`, `train`, `predict`, `automl`)
- [x] WASM bridge
- [ ] LLVM native compilation
- [ ] Nexa Playground (browser IDE)
- [ ] `awesome-nexa` community list
- [ ] Official nexa-lang.org website
>>>>>>> 505371e59d95447c4de1bb675f9eb2687f79f60d

---

## 🤝 Contributing

<<<<<<< HEAD
We welcome contributions! See [CONTRIBUTING.md](CONTRIBUTING.md).

- 🐛 [Report a bug](https://github.com/yuvaraj030/nexa-lang/issues/new?template=bug_report.md)
- 💡 [Request a feature](https://github.com/yuvaraj030/nexa-lang/issues/new?template=feature_request.md)
- 📦 [Publish a package](https://docs.nexa-lang.dev/registry)
- 💬 [Join Discord](https://discord.gg/nexa-lang)
=======
We love contributions! See [CONTRIBUTING.md](CONTRIBUTING.md) to get started.

```bash
# Clone and set up
git clone https://github.com/nexa-lang/nexa.git
cd nexa
pip install -e .

# Run the test suite
python -m pytest tests/

# Try a Nexa file
nexa run examples/hello.nexa
```

Good first issues are tagged [`good first issue`](https://github.com/nexa-lang/nexa/issues?q=is%3Aissue+label%3A%22good+first+issue%22).

---

## 🌍 Community

- 💬 **Discord**: [discord.gg/fYWWpnkjgn](https://discord.gg/fYWWpnkjgn)
- 📣 **Reddit**: [r/nexalang](https://reddit.com/r/nexalang)
- 🐦 **Twitter**: [@nexalang](https://twitter.com/nexalang)
>>>>>>> 505371e59d95447c4de1bb675f9eb2687f79f60d

---

## 📄 License

<<<<<<< HEAD
MIT © [Yuvaraj](https://github.com/yuvaraj030)

<div align="center">
<sub>Built with ❤️ for the AI era</sub>
=======
Nexa is open-source under the [MIT License](LICENSE.md).

---

<div align="center">

**Built with ❤️ for the future of programming.**

*If Nexa helps you, give it a ⭐ — it helps the project grow!*

[![Star History](https://img.shields.io/badge/⭐_Star_this_repo-orange?style=for-the-badge)](https://github.com/nexa-lang/nexa)

>>>>>>> 505371e59d95447c4de1bb675f9eb2687f79f60d
</div>
