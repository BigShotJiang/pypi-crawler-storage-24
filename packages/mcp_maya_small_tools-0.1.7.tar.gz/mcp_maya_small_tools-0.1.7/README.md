# mcp_maya_small_tools

这是一个mcp服务器，提供的tools有

 - list_maya_references 列出指定目录下所有ma文件，其referenc列表
 - view_maya_file_frame_range 查看maya文件帧数范围
