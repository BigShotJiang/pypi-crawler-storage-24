from setuptools import setup, find_packages
from pathlib import Path

# 读取 README
readme_file = Path(__file__).parent / "README.md"
long_description = readme_file.read_text(encoding="utf-8") if readme_file.exists() else ""

setup(
    name="SHICTHRSPyIcons",
    version="1.1.1",
    description="SHICTHRSPyIcons 图标库",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="SHICTHRS",
    author_email="",
    url="",
    packages=find_packages(),
    package_data={
        "SHICTHRSPyIcons": ["svg/*.svg"],
    },
    include_package_data=True,
    python_requires=">=3.14",
    install_requires=[
        "colorthief==0.2.1",
        "darkdetect==0.8.0",
        "numpy>=2.4.3",
        "pillow>=12.1.1",
        "PySide6>=6.10.2",
        "PySide6-Fluent-Widgets>=1.11.1",
        "PySide6_Addons>=6.10.2",
        "PySide6_Essentials>=6.10.2",
        "PySideSix-Frameless-Window>=0.8.0",
        "pywin32>=311",
        "scipy>=1.17.1",
        "shiboken6>=6.10.2",
    ],
    classifiers=[
        "License :: OSI Approved :: GNU General Public License v3 (GPLv3)",
    ],
)
