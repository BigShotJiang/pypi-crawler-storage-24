# Core utilities for ContextBridge
