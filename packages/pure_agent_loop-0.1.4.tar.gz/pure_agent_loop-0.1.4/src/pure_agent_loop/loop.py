"""ReAct 循环引擎

实现 Thought → Action → Observation 的循环流程。
"""

import asyncio
import json
import logging
import time
from typing import Any, AsyncIterator

from .events import Event, EventType
from .limits import LoopLimits, LimitChecker
from .llm.base import BaseLLMClient
from .llm.types import LLMResponse
from .retry import RetryConfig, RetryHandler
from .tool import ToolRegistry
from .builtin_tools import TodoStore

logger = logging.getLogger(__name__)


class ReactLoop:
    """ReAct 循环引擎

    执行 Thought → Action → Observation 循环，直到满足终止条件。

    Args:
        llm: LLM 客户端实例
        tool_registry: 工具注册表
        limits: 终止条件配置
        retry: 重试配置
    """

    def __init__(
        self,
        llm: BaseLLMClient,
        tool_registry: ToolRegistry,
        limits: LoopLimits,
        retry: RetryConfig,
        llm_kwargs: dict[str, Any] | None = None,
        todo_store: TodoStore | None = None,
        emit_reasoning_events: bool = False,
    ):
        self._llm = llm
        self._tools = tool_registry
        self._limits = limits
        self._retry_handler = RetryHandler(retry)
        self._llm_kwargs = llm_kwargs or {}
        self._todo_store = todo_store
        self._emit_reasoning_events = emit_reasoning_events

    async def _execute_with_timing(
        self, name: str, arguments: dict[str, Any]
    ) -> tuple[str, float]:
        """执行单个工具并计时

        Args:
            name: 工具名称
            arguments: 工具参数

        Returns:
            (执行结果, 耗时秒数)
        """
        start_time = time.time()
        result = await self._tools.execute(name, arguments)
        duration = time.time() - start_time
        return result, duration

    async def run(
        self,
        task: str,
        system_prompt: str = "You are a helpful assistant.",
        messages: list[dict[str, Any]] | None = None,
    ) -> AsyncIterator[Event]:
        """执行 ReAct 循环

        Args:
            task: 用户任务描述
            system_prompt: 系统提示
            messages: 初始消息历史（用于多轮对话）

        Yields:
            Event: 执行过程中的结构化事件
        """
        # 初始化消息历史
        if messages:
            msg_history = list(messages)
            msg_history.append({"role": "user", "content": task})
        else:
            msg_history = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": task},
            ]

        # 初始化限制检查器
        checker = LimitChecker(self._limits)

        # 获取工具 schema
        tool_schemas = self._tools.to_openai_schemas() or None

        # 产出循环启动事件
        yield Event.loop_start(task=task)

        step = 0
        final_content = ""

        while True:
            step += 1
            checker.current_step = step

            # ---- 硬限制：判断是否为最后一步 ----
            is_hard_limit_step = checker.is_last_step
            current_tools = tool_schemas
            if is_hard_limit_step:
                # 最后一步：禁用工具，注入硬限制提示
                # 使用 user 角色避免部分模型不支持中途 system 消息
                current_tools = None
                msg_history.append(
                    {"role": "user", "content": f"[System] {self._limits.hard_limit_prompt}"}
                )

            # ---- 调用 LLM ----
            try:
                response = await self._retry_handler.execute(
                    self._llm.chat,
                    messages=msg_history,
                    tools=current_tools,
                    **self._llm_kwargs,
                )
            except Exception as e:
                logger.error("LLM 调用失败 (重试耗尽): %s", e)
                yield Event.error(step=step, error=str(e), fatal=True)
                yield Event.loop_end(
                    step=step,
                    stop_reason="error",
                    content=f"LLM 调用失败: {e}",
                    messages=msg_history,
                )
                return

            # 累加生成 token（仅 completion，避免 prompt 重复计算导致虚高）
            checker.add_tokens(response.usage.completion_tokens)

            # ---- 处理响应 ----
            # 产出 REASONING 事件（如果启用且有内容）
            if self._emit_reasoning_events and response.reasoning_content:
                yield Event.reasoning(step=step, content=response.reasoning_content)

            if response.has_tool_calls:
                # Thought（如果有文本内容）
                if response.content:
                    yield Event.thought(step=step, content=response.content)

                # 构建 assistant 消息
                assistant_msg: dict[str, Any] = {"role": "assistant"}
                if response.content:
                    assistant_msg["content"] = response.content
                assistant_msg["tool_calls"] = [
                    {
                        "id": tc.id,
                        "type": "function",
                        "function": {
                            "name": tc.name,
                            "arguments": json.dumps(tc.arguments),
                        },
                    }
                    for tc in response.tool_calls
                ]
                msg_history.append(assistant_msg)

                # ---- 执行工具（并行） ----
                # 1. 先产出所有 ACTION 事件
                for tc in response.tool_calls:
                    yield Event.action(step=step, tool=tc.name, args=tc.arguments)

                # 2. 并行执行所有工具
                results_with_timing = await asyncio.gather(*[
                    self._execute_with_timing(tc.name, tc.arguments)
                    for tc in response.tool_calls
                ])

                # 3. 批量产出 OBSERVATION 事件并更新消息历史
                for tc, (result, duration) in zip(response.tool_calls, results_with_timing):
                    yield Event.observation(
                        step=step, tool=tc.name, result=result, duration=duration
                    )

                    # 如果是 todo_write 工具，额外产出 TODO_UPDATE 事件
                    if tc.name == "todo_write" and self._todo_store is not None:
                        yield Event.todo_update(
                            step=step,
                            todos=[t.to_dict() for t in self._todo_store.todos],
                        )

                    # 将工具结果追加到消息历史
                    msg_history.append(
                        {
                            "role": "tool",
                            "tool_call_id": tc.id,
                            "content": result,
                        }
                    )

                # 4. 记录工具调用并检测 doom loop
                for tc in response.tool_calls:
                    checker.record_tool_call(
                        tc.name, json.dumps(tc.arguments, sort_keys=True)
                    )

                if checker.is_doom_loop:
                    logger.warning(
                        "检测到 doom loop: 连续 %d 次相同工具调用",
                        self._limits.doom_loop_threshold,
                    )
                    yield Event.error(
                        step=step,
                        error=f"检测到 doom loop: 连续 {self._limits.doom_loop_threshold} 次相同工具调用",
                        fatal=True,
                    )
                    yield Event.loop_end(
                        step=step,
                        stop_reason="doom_loop",
                        content=final_content,
                        messages=msg_history,
                    )
                    return

            else:
                # 无工具调用 = 最终回答
                final_content = response.content or ""
                if final_content:
                    yield Event.thought(step=step, content=final_content)

                msg_history.append(
                    {"role": "assistant", "content": final_content}
                )

                # 硬限制步骤使用 "max_steps" 作为终止原因
                stop_reason = "max_steps" if is_hard_limit_step else "completed"
                yield Event.loop_end(
                    step=step,
                    stop_reason=stop_reason,
                    content=final_content,
                    messages=msg_history,
                )
                return

            # ---- 检查限制 ----
            limit_result = checker.check()

            if limit_result.action == "stop":
                yield Event.loop_end(
                    step=step,
                    stop_reason=limit_result.reason,
                    content=final_content,
                    messages=msg_history,
                )
                return

            if limit_result.action == "warn":
                yield Event.soft_limit(
                    step=step,
                    reason=limit_result.reason,
                    prompt=limit_result.prompt,
                )
                # 注入系统提示（使用 user 角色避免部分模型不支持中途 system 消息）
                msg_history.append(
                    {"role": "user", "content": f"[System] {limit_result.prompt}"}
                )
