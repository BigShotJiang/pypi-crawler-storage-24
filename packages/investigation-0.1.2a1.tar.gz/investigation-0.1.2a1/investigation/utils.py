import random, string


def get_hashname(length=8):
    return ''.join(random.choices(
        list(string.ascii_uppercase) + list(string.digits),
        k=length,
    ))
