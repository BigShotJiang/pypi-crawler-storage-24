from pathlib import Path
import environs

env = environs.Env()
env.read_env()
cwd = Path.cwd()
investigation_home = Path(__file__).parent.parent
entry_path = cwd / "entry" / "__init__.py"

storage_path = cwd / ".investigation"
pending_investigation_path = cwd / "_investigation_pending.json"

# Import the main decorator
from investigation.decorator import main

__all__ = ['main', 'cwd', 'investigation_home', 'entry_path', 'storage_path', 'pending_investigation_path']
