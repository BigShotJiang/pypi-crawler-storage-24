"""
Visualization module for training logs.
Provides web-based interface for visualizing and analyzing training curves.
"""

__version__ = "0.1.0"
