#!/usr/bin/env python3
"""
Command-line interface for starting the training log visualization server.
"""

import argparse
import sys


def main():
    parser = argparse.ArgumentParser(description='启动训练日志可视化服务器 (Start training log visualization server)')
    parser.add_argument('--host', default='127.0.0.1', help='服务器地址 (Server host, default: 127.0.0.1)')
    parser.add_argument('--port', type=int, default=5000, help='服务器端口 (Server port, default: 5000)')
    parser.add_argument('--debug', action='store_true', help='启用调试模式 (Enable debug mode)')
    parser.add_argument('--storage', type=str, default=None, help='训练日志存储路径 (Storage path for training logs)')

    args = parser.parse_args()

    # import  here to avoid loading Flask if just showing help
    try:
        from visualization.app import run_app, DEFAULT_STORAGE_PATH
        import os

        # Set storage path if provided
        if args.storage:
            os.environ['Investigation_STORAGE'] = args.storage
            print(f"使用存储路径 (Using storage path): {args.storage}")
        else:
            print(f"使用默认存储路径 (Using default storage path): {DEFAULT_STORAGE_PATH}")

        print(f"\n🚀 启动训练日志可视化服务器...")
        print(f"📊 访问地址: http://{args.host}:{args.port}")
        print(f"💡 按 Ctrl+C 停止服务器\n")

        run_app(host=args.host, port=args.port, debug=args.debug)

    except ImportError as e:
        print(f"错误: 缺少依赖包。请运行: pip install flask", file=sys.stderr)
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
    except KeyboardInterrupt:
        print("\n\n👋 服务器已停止")
        sys.exit(0)
    except Exception as e:
        print(f"错误: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
