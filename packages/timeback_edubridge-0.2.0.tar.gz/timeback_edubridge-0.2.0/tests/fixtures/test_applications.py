"""Fixture-driven tests for EduBridge applications resource."""

from __future__ import annotations

from test_support.fixtures import fixtures_dir, make_resource_fixture_test
from timeback_edubridge.lib.testing import create_recording_transport
from timeback_edubridge.resources.applications import ApplicationsResource

FIXTURES_DIR = fixtures_dir("edubridge", "applications")


def _setup(
    fail_request: dict[str, object] | None, transport_config: dict[str, object] | None
) -> dict[str, object]:
    transport = create_recording_transport(fail_request, transport_config)
    return {"resource": ApplicationsResource(transport), "calls": transport.calls}


test_edubridge_applications_fixtures = make_resource_fixture_test(
    name="edubridge > applications",
    fixtures_dir=FIXTURES_DIR,
    setup=_setup,
)
