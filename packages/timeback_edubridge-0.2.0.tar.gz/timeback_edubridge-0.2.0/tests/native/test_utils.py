"""Native tests for EduBridge utility helpers."""

from __future__ import annotations

from datetime import UTC, datetime

from pydantic import BaseModel, ConfigDict, Field

from timeback_edubridge import (
    AggregatedMetrics,
    aggregate_activity_metrics,
    normalize_boolean,
    normalize_date,
    normalize_user,
)
from timeback_edubridge.types.analytics import (
    ActivityMetricsData,
    SubjectMetrics,
    TimeSpentMetricsData,
)


def _subject_metrics() -> SubjectMetrics:
    return SubjectMetrics(
        activityMetrics=ActivityMetricsData(
            xpEarned=100,
            totalQuestions=10,
            correctQuestions=8,
            masteredUnits=2,
        ),
        timeSpentMetrics=TimeSpentMetricsData(
            activeSeconds=3600, inactiveSeconds=600, wasteSeconds=120
        ),
        apps=["TestApp"],
    )


def test_normalize_boolean() -> None:
    assert normalize_boolean(True) is True
    assert normalize_boolean(False) is False
    assert normalize_boolean("true") is True
    assert normalize_boolean("false") is False


def test_normalize_date() -> None:
    assert normalize_date("2025-12-25") == "2025-12-25T00:00:00.000Z"
    assert normalize_date("2025-12-25T10:30:00+00:00") == "2025-12-25T10:30:00Z"
    dt = datetime(2025, 12, 25, 10, 30, 0, tzinfo=UTC)
    assert normalize_date(dt) is not None


def test_normalize_user() -> None:
    class MockUser(BaseModel):
        enabled_user: str = Field(alias="enabledUser")
        model_config = ConfigDict(populate_by_name=True)

    user = MockUser(enabledUser="true")
    normalized = normalize_user(user)  # type: ignore[type-var]
    assert normalized.enabled_user is True  # type: ignore[comparison-overlap]


def test_aggregate_activity_metrics() -> None:
    result = aggregate_activity_metrics({"2025-01-01": {"Math": _subject_metrics()}})
    assert result.total_xp == 100
    assert result.mastered_units == 2
    assert result.day_count == 1


def test_aggregated_metrics_model() -> None:
    metrics = AggregatedMetrics(
        totalXp=100.5,
        totalQuestions=50,
        correctQuestions=45,
        masteredUnits=3,
        activeSeconds=7200,
        inactiveSeconds=600,
        wasteSeconds=120,
        dayCount=5,
        subjectCount=10,
    )
    assert metrics.total_xp == 100.5
