"""Native validation tests that must fail before transport requests."""

from __future__ import annotations

from typing import Any

import pytest

from timeback_common import EdubridgePaths, InputValidationError
from timeback_edubridge.resources.analytics import AnalyticsResource
from timeback_edubridge.resources.applications import ApplicationsResource
from timeback_edubridge.resources.enrollments import EnrollmentsResource
from timeback_edubridge.resources.users import UsersResource


class _StubTransport:
    def __init__(self) -> None:
        self.request_count = 0
        self.base_url = "https://example.test"
        self.paths = EdubridgePaths(base="/edubridge")

    async def get(self, _path: str, *, params: dict[str, Any] | None = None) -> dict[str, Any]:
        del params
        self.request_count += 1
        raise AssertionError("request should not be called")

    async def post(self, _path: str, _body: Any) -> dict[str, Any]:
        self.request_count += 1
        raise AssertionError("request should not be called")

    async def put(self, _path: str, _body: Any) -> dict[str, Any]:
        self.request_count += 1
        raise AssertionError("request should not be called")

    async def delete(self, _path: str) -> None:
        self.request_count += 1
        raise AssertionError("request should not be called")


@pytest.mark.asyncio
async def test_enrollments_list_validates_user_id_before_request() -> None:
    transport = _StubTransport()
    with pytest.raises(InputValidationError):
        await EnrollmentsResource(transport).list(user_id="")  # type: ignore[arg-type]
    assert transport.request_count == 0


@pytest.mark.asyncio
async def test_users_list_validates_roles_before_request() -> None:
    transport = _StubTransport()
    with pytest.raises(InputValidationError):
        await UsersResource(transport).list(roles=[])  # type: ignore[arg-type]
    assert transport.request_count == 0


@pytest.mark.asyncio
async def test_analytics_get_activity_validates_identifier_before_request() -> None:
    transport = _StubTransport()
    with pytest.raises(InputValidationError):
        await AnalyticsResource(transport).get_activity(  # type: ignore[arg-type]
            start_date="2025-01-01",
            end_date="2025-01-02",
        )
    assert transport.request_count == 0


@pytest.mark.asyncio
async def test_applications_get_metrics_validates_id_before_request() -> None:
    transport = _StubTransport()
    with pytest.raises(InputValidationError):
        await ApplicationsResource(transport).get_metrics("")  # type: ignore[arg-type]
    assert transport.request_count == 0
