import logging
import threading
import traceback
from collections.abc import Callable
from traceback import FrameSummary

from codespeak_shared.exceptions import RunCancelledInternalError, RunCancelledUserError
from codespeak_shared.utils.type_utils import nn


class CancellationManager:
    def __init__(self):
        self._is_cancelled: bool
        self._reason: str | None
        self._request_traceback: list[FrameSummary]
        self._is_user_error: bool
        self._subscribers: list[Callable[[], None]]
        self._subscribers_lock: threading.Lock
        self._logger = logging.getLogger(__class__.__name__)
        self.reset()

    def request_build_cancellation_user_error(self, user_visible_message: str):
        self._request_build_cancellation(user_visible_message, is_user_error=True)

    def request_build_cancellation_internal_error(self, internal_message: str):
        self._request_build_cancellation(internal_message, is_user_error=False)

    def _request_build_cancellation(self, reason: str, is_user_error: bool):
        self._reason = reason
        self._is_user_error = is_user_error

        self._request_traceback = traceback.extract_stack()[:-1]

        # NB: Publishing through _is_cancelled
        self._is_cancelled = True

        self._logger.info(f"Cancellation requested, reason: {reason}, is user error: {is_user_error}")

        with self._subscribers_lock:
            subscribers_snapshot = list(self._subscribers)
            self._logger.info(f"Calling {len(subscribers_snapshot)} subscribers")

        for callback in subscribers_snapshot:
            callback()

    @property
    def is_cancelled(self) -> bool:
        return self._is_cancelled

    @property
    def user_visible_reason(self) -> str:
        if self._is_user_error:
            return nn(self._reason)
        else:
            return "Internal error"

    def check_cancelled(self) -> None:
        if self._is_cancelled:
            error_msg = nn(self._reason)

            # "raise from None" to avoid another exception
            # (which just happened and which we're catching, but actually related to cancellation)
            # cause "During handling of the above exception, another exception occurred" in logs
            raise (
                RunCancelledUserError(error_msg, self._request_traceback)
                if self._is_user_error
                else RunCancelledInternalError(error_msg, self._request_traceback)
            ) from None

    def subscribe(self, callback: Callable[[], None]) -> None:
        self._logger.info(f"Subscribing {callback}")
        with self._subscribers_lock:
            self._subscribers.append(callback)
            already_cancelled = self._is_cancelled
        if already_cancelled:
            callback()

    def unsubscribe(self, callback: Callable[[], None]) -> None:
        self._logger.info(f"Unsubscribing {callback}")
        with self._subscribers_lock:
            try:
                self._subscribers.remove(callback)
            except ValueError:
                pass

    def reset(self) -> None:
        self._is_cancelled = False
        self._reason = None
        self._is_user_error = False
        self._request_traceback = []
        self._subscribers = []
        self._subscribers_lock = threading.Lock()
