from pathlib import Path

import codespeak_shared.exceptions
from codespeak_shared.codespeak_project import CodeSpeakProject
from codespeak_shared.exceptions import CodespeakUserError
from codespeak_shared.project_path import ProjectPath


def convert_user_string_to_path_in_project(raw_path: str, project: CodeSpeakProject, cwd: Path) -> ProjectPath:
    """Resolve raw_path (relative to cwd or absolute) into a project-relative ProjectPath.

    Raises CodespeakUserError if the resolved path falls outside the project root.
    """
    """Resolve raw_path (relative to cwd or absolute) into a project-relative ProjectPath.

    Returns None if the resolved path falls outside the project root.
    """
    if not cwd.is_absolute():
        raise codespeak_shared.exceptions.CodespeakInternalError(f"CWD must be absolute, got {cwd}")

    path = Path(raw_path)
    if path.is_absolute():
        return ProjectPath.from_path(path)

    # Relative path is given
    # 1. resolve it relative to cwd
    resolved_absolute = ProjectPath.from_path((cwd / path).resolve())

    # 2. Try to re-relativize to project root
    if not resolved_absolute.is_relative_to(project.project_root):
        raise CodespeakUserError(
            f"Provided path '{raw_path}' resolves to '{resolved_absolute}', which is outside the project root '{project.project_root}'.\n"
            f"Tip: Specify a path within the project directory"
        )
    return resolved_absolute.relative_to(project.project_root)
