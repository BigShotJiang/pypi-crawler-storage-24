import json
import logging
from typing import Any

from anthropic import APIStatusError
from pydantic.dataclasses import dataclass

from codespeak_shared.exceptions import (
    AnthropicApiKeyInsufficientBalanceUserError,
    AnthropicApiKeyInvalidUserError,
    AnthropicApiProviderError,
    AnthropicApiUserError,
    BedrockCredentialsInvalidUserError,
    CodespeakInternalError,
)
from codespeak_shared.utils.type_utils import instanceof

_logger = logging.getLogger(__name__)


@dataclass
class RawResponse:
    status_code: int
    response_body: str


def translate_error(error: APIStatusError | RawResponse) -> Exception:
    def extract_error_message(response_node: dict[str, Any]) -> str | None:
        # Anthropic format: {"error": {"message": "..."}}
        # Bedrock format: {"message": "..."}
        return response_node.get("error", {}).get("message") or response_node.get("message")

    if isinstance(error, APIStatusError):
        status_code = error.status_code
        if error.body and instanceof(error.body, dict[str, Any]):
            raw_response = json.dumps(error.body)
            # error response is valid json
            error_message = extract_error_message(error.body)
            if not error_message:
                # we failed to find an error in response JSON, dump full body
                _logger.warning(f"Failed to extract error from error response: {raw_response}")
                error_message = raw_response
        elif error.body:
            raw_response = str(error.body)
            _logger.warning(f"Error response is not a valid JSON: {raw_response}")
            error_message = raw_response
        else:
            raw_response = "(empty)"
            error_message = "(no response)"

    else:
        status_code = error.status_code
        raw_response = error.response_body
        try:
            response_json = json.loads(raw_response)
            error_message = extract_error_message(response_json)
            if not error_message:
                # we failed to find an error in response JSON, dump ful body
                _logger.warning(f"Failed to extract error from error response: {raw_response}")
                error_message = raw_response
        except json.JSONDecodeError:
            _logger.warning(f"Error response is not a valid JSON: {raw_response}")
            error_message = raw_response

    if 400 <= status_code <= 499:
        # 4xx codes, user error
        if "balance is too low" in error_message:
            return AnthropicApiKeyInsufficientBalanceUserError()
        elif error_message == "invalid x-api-key":
            raise AnthropicApiKeyInvalidUserError()
        elif status_code == 403 and error_message == "The security token included in the request is invalid.":
            return BedrockCredentialsInvalidUserError()
        else:
            return AnthropicApiUserError(error_message)
    elif 500 <= status_code <= 599:
        return AnthropicApiProviderError(error_message)

    _logger.warning(f"Unexpected status code: {status_code}")
    return CodespeakInternalError(f"Unexpected status code: {status_code}, response: {raw_response}")
