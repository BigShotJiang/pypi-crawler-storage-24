from argparse import Namespace
from typing import TypeVar

from rich.console import Console

from codespeak_shared import BuildResult
from codespeak_shared.codespeak_project import CodeSpeakProject
from codespeak_shared.exceptions import (
    CodeChangeRequestFileAlreadyExists,
    CodeChangeRequestFileDoesntExist,
)
from codespeak_shared.os_environment import FileNotFoundException
from codespeak_shared.project_initializer import load_shared_resource

T = TypeVar("T")


def verify_code_change_request(
    project: CodeSpeakProject,
    args: Namespace,
    console: Console,
) -> BuildResult | None:
    if args.new:
        path = project.code_change_request_path()
        if project.os_env().exists(path):
            return BuildResult.failed("change", CodeChangeRequestFileAlreadyExists(str(path.get_underlying_path())))
        project.os_env().write_file(path, load_shared_resource("change-request-template.cs.md"))
        console.print(f"[progress.success.text]Created template change request in [/progress.success.text] {path}.")
        return BuildResult.succeeded("change")
    else:
        path = project.code_change_request_path()

        try:
            file_content = project.os_env().read_file(path)
        except FileNotFoundException:
            file_content = None

        if args.message and file_content:
            # File exists, and `-m` passed.
            # Check if the message is EXACTLY the file content - it helps
            # a popular case of `codespeak change -m "content"` - it fails/aborted - press up arrow in terminal, hit enter
            if args.message == file_content:
                return None
            else:
                return BuildResult.failed("change", CodeChangeRequestFileAlreadyExists(str(path.get_underlying_path())))
        elif not args.message and not file_content:
            return BuildResult.failed("change", CodeChangeRequestFileDoesntExist(str(path.get_underlying_path())))
        else:
            # not args.message and path.exists() - normal case
            # or
            # args.message and not path.exists() - need to create change-request and build it
            #
            # In both cases, just let the server do its job
            return None
