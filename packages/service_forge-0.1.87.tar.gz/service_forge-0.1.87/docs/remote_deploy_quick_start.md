# SFT 快速使用（仅 uv run 示例）

简介：SFT 用于打包并将服务发布到 Service Center，随后可在 Service Center 发起远端部署。下面仅给出极简说明与 `uv run` 示例，适合复制粘贴使用。

何时使用
- 需要把本地服务打包并上传到 Service Center（以便在远端集群部署）时使用。
- 需要在 Service Center 列表中查看或触发远端部署时使用。

主要功能（简短）
- upload：打包并上传项目（会在 sf-meta 中写入当前 Git 分支与短 sha）。
- remote-list：列出远端已上传的包。
- remote-deploy：在 Service Center 非交互式触发指定 tar 的远端部署。
- config set：设置默认 Service Center 地址。

示例命令（仅 uv run，逐行可复制）
```bash
uv run sft config set service_center_address http://ring.shiweinan.com:32850/service_center
uv run sft upload --version latest
uv run sft remote-list
uv run sft remote-deploy sf_my-service_latestv.tar
uv run sft --help
```

备注
- 需要通过 `sft config set service_center_address` 设置远端地址，目前包含地址 http://vps.shiweinan.com:37919/service_center 和 http://ring.shiweinan.com:32850/service_center ，请向用户确认使用哪个地址。

- 不在本地包含 `deploy` 示例（本地可能无部署环境）；若需在远端或 CI 触发部署，请使用 `remote-deploy`。

