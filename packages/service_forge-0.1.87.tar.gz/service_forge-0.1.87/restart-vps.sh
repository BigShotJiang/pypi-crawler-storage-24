#!/bin/bash

ssh -p 6000 zcc@vps.shiweinan.com << 'EOF'
cd /home/zcc/service-forge || exit 1
git pull
export SF_REGISTRY_LOCAL_ADDRESS=10.31.4.6:37920/library
./build.sh --local
EOF
