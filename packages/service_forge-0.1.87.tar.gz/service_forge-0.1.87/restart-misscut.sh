#!/bin/bash

ssh -p 32000 misscut@118.193.124.158 << 'EOF'
cd /home/misscut/zcc/service-forge || exit 1
git pull
export SF_REGISTRY_LOCAL_ADDRESS=192.168.3.12:32810/library
./build.sh --local
EOF
