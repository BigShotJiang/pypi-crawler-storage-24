#!/bin/bash
# 从远程仓库拉取最新基础镜像并同步到本地仓库
# 用法: ./sync_registry.sh
#
# 依赖环境变量:
#   - SF_REGISTRY_REMOTE_ADDRESS: 远程镜像仓库地址 (如: registry.example.com)
#   - SF_REGISTRY_LOCAL_ADDRESS : 本地镜像仓库地址 (如: 127.0.0.1:5000)

set -e

IMAGE_NAME="service-forge"
REPOSITORY_NAME="service-forge"
VERSION="latest"

if [ -z "${SF_REGISTRY_REMOTE_ADDRESS}" ]; then
    echo "错误: 环境变量 SF_REGISTRY_REMOTE_ADDRESS 未设置!"
    exit 1
fi

if [ -z "${SF_REGISTRY_LOCAL_ADDRESS}" ]; then
    echo "错误: 环境变量 SF_REGISTRY_LOCAL_ADDRESS 未设置!"
    exit 1
fi

REMOTE_IMAGE="${SF_REGISTRY_REMOTE_ADDRESS}/${REPOSITORY_NAME}:${VERSION}"
LOCAL_IMAGE="${SF_REGISTRY_LOCAL_ADDRESS}/${REPOSITORY_NAME}:${VERSION}"

echo "=== 开始同步基础镜像到本地仓库 ==="
echo "远程镜像: ${REMOTE_IMAGE}"
echo "本地镜像: ${LOCAL_IMAGE}"

echo "步骤 1/3: 从远程仓库拉取最新镜像..."
docker pull "${REMOTE_IMAGE}"
echo "✓ 远程镜像拉取成功"

echo "步骤 2/3: 重新标记镜像到本地仓库地址..."
docker tag "${REMOTE_IMAGE}" "${LOCAL_IMAGE}"
echo "✓ 镜像标记成功"

echo "步骤 3/3: 推送镜像到本地仓库..."
docker push "${LOCAL_IMAGE}"
echo "✓ 镜像推送到本地仓库成功"

echo "=== 同步完成 ==="
echo "本地可用基础镜像: ${LOCAL_IMAGE}"

