# lqh – Liquid Harness

A fine-tuning tool for foundation models by [Liquid AI](https://liquid.ai).

**This package is under active development. Stay tuned.**

## Installation

```bash
pip install lqh
```

## Usage

```bash
lqh --help
```
