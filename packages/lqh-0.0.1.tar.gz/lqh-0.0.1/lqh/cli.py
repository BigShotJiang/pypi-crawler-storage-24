"""Liquid Harness CLI."""


def main():
    print("lqh (Liquid Harness) v0.0.1 – coming soon.")
    print("A fine-tuning tool for foundation models.")


if __name__ == "__main__":
    main()
