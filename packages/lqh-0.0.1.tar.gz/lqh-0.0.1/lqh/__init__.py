"""Liquid Harness (lqh) – A fine-tuning tool for foundation models."""

__version__ = "0.0.1"
