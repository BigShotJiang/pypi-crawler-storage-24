"""TUI-specific tests."""
