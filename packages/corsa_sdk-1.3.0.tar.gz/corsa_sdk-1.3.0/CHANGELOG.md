# CHANGELOG

<!-- version list -->

## v1.3.0 (2026-03-23)

### Continuous Integration

- Add AI PR title and description generator workflow
  ([`9ef1fce`](https://github.com/corsa-labs/corsa-sdk-py/commit/9ef1fce1e7fca9373b9ba8193c055cf61715820b))

### Features

- **sdk**: Regenerate Python SDK from API Gateway
  ([#2](https://github.com/corsa-labs/corsa-sdk-py/pull/2),
  [`a2003aa`](https://github.com/corsa-labs/corsa-sdk-py/commit/a2003aa301f1344b2dc3cd0cf4612fa5080e89c0))


## v1.2.1 (2026-03-21)

### Bug Fixes

- Rename example script to quickstart.py
  ([`e9120e2`](https://github.com/corsa-labs/corsa-sdk-py/commit/e9120e2c2255da933798995af09cc344feb4f6f5))

- Simplify example to show SDK usage rather than test assertions
  ([`bef1845`](https://github.com/corsa-labs/corsa-sdk-py/commit/bef18451ce48f071d41109209028899b2ed013ec))


## v1.2.0 (2026-03-21)

### Features

- Add standalone verification example
  ([`238df2c`](https://github.com/corsa-labs/corsa-sdk-py/commit/238df2c3de9258ae3f7d76f8d9d72ed35ca74d7f))


## v1.1.1 (2026-03-21)

### Bug Fixes

- Add readme to package metadata and update API URL references
  ([`7153a40`](https://github.com/corsa-labs/corsa-sdk-py/commit/7153a409b9207814e48826efb844ea124c88e1e1))

### Continuous Integration

- Switch PyPI publishing to OIDC trusted publisher
  ([`96be9fc`](https://github.com/corsa-labs/corsa-sdk-py/commit/96be9fc690e8bb49e1468d3961356271d8cb6648))


## v1.1.0 (2026-03-19)

### Bug Fixes

- Bump requires-python to >=3.10 for union syntax compatibility
  ([`55b32c5`](https://github.com/corsa-labs/corsa-sdk-py/commit/55b32c58e3dad6e699806e2bf52d7e12eb513bbc))

### Features

- **sdk**: Regenerate Python SDK from API Gateway
  ([`55b32c5`](https://github.com/corsa-labs/corsa-sdk-py/commit/55b32c58e3dad6e699806e2bf52d7e12eb513bbc))


## v1.0.2 (2026-03-19)

### Bug Fixes

- Stabilize e2e tests and add CI workflow
  ([`807aa4e`](https://github.com/corsa-labs/corsa-sdk-py/commit/807aa4e102e14fdbc527a7752a451b055101f62b))

### Documentation

- Add README with usage examples and API reference
  ([`945f5db`](https://github.com/corsa-labs/corsa-sdk-py/commit/945f5db7e77eb6486afe9ba3c574e7aa12c1ac86))

### Testing

- Add e2e tests against live Corsa API
  ([`5b3d8c8`](https://github.com/corsa-labs/corsa-sdk-py/commit/5b3d8c8f235a678cf198d3cf4d92284767b063a5))


## v1.0.1 (2026-03-19)

### Bug Fixes

- Address bugs in client wrapper and CI workflows
  ([`c411e37`](https://github.com/corsa-labs/corsa-sdk-py/commit/c411e372a8d642908af9abaeb1d34811f125e2c3))


## v1.0.0 (2026-03-19)

- Initial Release
