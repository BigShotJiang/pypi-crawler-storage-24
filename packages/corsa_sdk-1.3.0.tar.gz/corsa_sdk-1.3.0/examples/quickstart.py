#!/usr/bin/env python3
"""Quick example showing how to use the Corsa Python SDK.

Usage:
    export CORSA_API_URL=https://api.corsa.finance
    export CORSA_API_TOKEN=<your-api-token>
    python verify_sdk.py
"""

from __future__ import annotations

import json
import os
import sys
import uuid

import corsa_sdk
from corsa_sdk import CorsaClient
from corsa_sdk.api.alerts.create_alert import _get_kwargs as create_alert_kwargs
from corsa_sdk.api.alerts.get_alert import _get_kwargs as get_alert_kwargs
from corsa_sdk.models.create_alert_dto import CreateAlertDto
from corsa_sdk.models.create_alert_dto_category import CreateAlertDtoCategory
from corsa_sdk.models.create_alert_dto_priority import CreateAlertDtoPriority
from corsa_sdk.models.create_alert_dto_status import CreateAlertDtoStatus


def main() -> None:
    api_url = os.environ.get("CORSA_API_URL")
    api_token = os.environ.get("CORSA_API_TOKEN")

    if not api_url or not api_token:
        print("Set CORSA_API_URL and CORSA_API_TOKEN environment variables first.")
        sys.exit(1)

    print(f"corsa-sdk v{corsa_sdk.__version__}")
    print(f"Connecting to {api_url}\n")

    client = CorsaClient(base_url=api_url, token=api_token)
    httpx_client = client.raw_client.get_httpx_client()
    ref = f"example-{uuid.uuid4().hex[:8]}"

    # Create an alert
    resp = httpx_client.request(**create_alert_kwargs(body=CreateAlertDto(
        category=CreateAlertDtoCategory.OTHER,
        description="Created from the Python SDK example",
        priority=CreateAlertDtoPriority.LOW,
        status=CreateAlertDtoStatus.NEW,
        reference_id=ref,
    )))
    alert = resp.json()
    print(f"Created alert  {alert['id']}  (ref={ref})")

    # Fetch it back
    resp = httpx_client.request(**get_alert_kwargs(alert_id=alert["id"]))
    fetched = resp.json()
    print(f"Fetched alert  {fetched['id']}  status={fetched['status']}")

    client.close()
    print("\nDone.")


if __name__ == "__main__":
    main()
