from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_external_document_dto import CreateExternalDocumentDto
from ...models.create_external_document_response_dto import CreateExternalDocumentResponseDto
from typing import cast



def _get_kwargs(
    *,
    body: CreateExternalDocumentDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/attachments/external-document",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | CreateExternalDocumentResponseDto | None:
    if response.status_code == 201:
        response_201 = CreateExternalDocumentResponseDto.from_dict(response.json())



        return response_201

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | CreateExternalDocumentResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateExternalDocumentDto,

) -> Response[Any | CreateExternalDocumentResponseDto]:
    """  Create an external document attachment from a download URL

    Args:
        body (CreateExternalDocumentDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateExternalDocumentResponseDto]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateExternalDocumentDto,

) -> Any | CreateExternalDocumentResponseDto | None:
    """  Create an external document attachment from a download URL

    Args:
        body (CreateExternalDocumentDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateExternalDocumentResponseDto
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateExternalDocumentDto,

) -> Response[Any | CreateExternalDocumentResponseDto]:
    """  Create an external document attachment from a download URL

    Args:
        body (CreateExternalDocumentDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | CreateExternalDocumentResponseDto]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateExternalDocumentDto,

) -> Any | CreateExternalDocumentResponseDto | None:
    """  Create an external document attachment from a download URL

    Args:
        body (CreateExternalDocumentDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | CreateExternalDocumentResponseDto
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
