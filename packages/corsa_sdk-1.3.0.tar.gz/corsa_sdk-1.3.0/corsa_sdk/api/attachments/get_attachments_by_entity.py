from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_attachments_by_entity_entity_type import GetAttachmentsByEntityEntityType



def _get_kwargs(
    *,
    entity_type: GetAttachmentsByEntityEntityType,
    entity_id: str,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_entity_type = entity_type.value
    params["entityType"] = json_entity_type

    params["entityId"] = entity_id


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/attachments",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 200:
        return None

    if response.status_code == 400:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    entity_type: GetAttachmentsByEntityEntityType,
    entity_id: str,

) -> Response[Any]:
    """  Get all attachments for a specific entity

    Args:
        entity_type (GetAttachmentsByEntityEntityType):
        entity_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
     """


    kwargs = _get_kwargs(
        entity_type=entity_type,
entity_id=entity_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    entity_type: GetAttachmentsByEntityEntityType,
    entity_id: str,

) -> Response[Any]:
    """  Get all attachments for a specific entity

    Args:
        entity_type (GetAttachmentsByEntityEntityType):
        entity_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
     """


    kwargs = _get_kwargs(
        entity_type=entity_type,
entity_id=entity_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

