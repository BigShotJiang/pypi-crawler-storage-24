from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.individual_client_dto import IndividualClientDto
from ...models.update_individual_client_dto import UpdateIndividualClientDto
from typing import cast



def _get_kwargs(
    client_id: str,
    *,
    body: UpdateIndividualClientDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/clients/individuals/{client_id}".format(client_id=quote(str(client_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> IndividualClientDto | None:
    if response.status_code == 200:
        response_200 = IndividualClientDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[IndividualClientDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    client_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateIndividualClientDto,

) -> Response[IndividualClientDto]:
    """  Update an existing individual client

    Args:
        client_id (str):
        body (UpdateIndividualClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualClientDto]
     """


    kwargs = _get_kwargs(
        client_id=client_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    client_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateIndividualClientDto,

) -> IndividualClientDto | None:
    """  Update an existing individual client

    Args:
        client_id (str):
        body (UpdateIndividualClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualClientDto
     """


    return sync_detailed(
        client_id=client_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    client_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateIndividualClientDto,

) -> Response[IndividualClientDto]:
    """  Update an existing individual client

    Args:
        client_id (str):
        body (UpdateIndividualClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualClientDto]
     """


    kwargs = _get_kwargs(
        client_id=client_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    client_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateIndividualClientDto,

) -> IndividualClientDto | None:
    """  Update an existing individual client

    Args:
        client_id (str):
        body (UpdateIndividualClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualClientDto
     """


    return (await asyncio_detailed(
        client_id=client_id,
client=client,
body=body,

    )).parsed
