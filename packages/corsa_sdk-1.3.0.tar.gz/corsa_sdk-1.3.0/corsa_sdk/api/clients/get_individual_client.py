from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.get_individual_client_integration_id import GetIndividualClientIntegrationId
from ...models.individual_client_dto import IndividualClientDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    client_id: str,
    *,
    integration_id: GetIndividualClientIntegrationId | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    json_integration_id: str | Unset = UNSET
    if not isinstance(integration_id, Unset):
        json_integration_id = integration_id.value

    params["integrationId"] = json_integration_id


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/clients/individuals/{client_id}".format(client_id=quote(str(client_id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> IndividualClientDto | None:
    if response.status_code == 200:
        response_200 = IndividualClientDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[IndividualClientDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    client_id: str,
    *,
    client: AuthenticatedClient,
    integration_id: GetIndividualClientIntegrationId | Unset = UNSET,

) -> Response[IndividualClientDto]:
    """  Get an individual client by ID

    Args:
        client_id (str):
        integration_id (GetIndividualClientIntegrationId | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualClientDto]
     """


    kwargs = _get_kwargs(
        client_id=client_id,
integration_id=integration_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    client_id: str,
    *,
    client: AuthenticatedClient,
    integration_id: GetIndividualClientIntegrationId | Unset = UNSET,

) -> IndividualClientDto | None:
    """  Get an individual client by ID

    Args:
        client_id (str):
        integration_id (GetIndividualClientIntegrationId | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualClientDto
     """


    return sync_detailed(
        client_id=client_id,
client=client,
integration_id=integration_id,

    ).parsed

async def asyncio_detailed(
    client_id: str,
    *,
    client: AuthenticatedClient,
    integration_id: GetIndividualClientIntegrationId | Unset = UNSET,

) -> Response[IndividualClientDto]:
    """  Get an individual client by ID

    Args:
        client_id (str):
        integration_id (GetIndividualClientIntegrationId | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualClientDto]
     """


    kwargs = _get_kwargs(
        client_id=client_id,
integration_id=integration_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    client_id: str,
    *,
    client: AuthenticatedClient,
    integration_id: GetIndividualClientIntegrationId | Unset = UNSET,

) -> IndividualClientDto | None:
    """  Get an individual client by ID

    Args:
        client_id (str):
        integration_id (GetIndividualClientIntegrationId | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualClientDto
     """


    return (await asyncio_detailed(
        client_id=client_id,
client=client,
integration_id=integration_id,

    )).parsed
