from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_individual_client_dto import CreateIndividualClientDto
from ...models.individual_client_dto import IndividualClientDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: CreateIndividualClientDto,
    upsert: bool | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["upsert"] = upsert


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/clients/individuals",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> IndividualClientDto | None:
    if response.status_code == 201:
        response_201 = IndividualClientDto.from_dict(response.json())



        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[IndividualClientDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateIndividualClientDto,
    upsert: bool | Unset = UNSET,

) -> Response[IndividualClientDto]:
    """  Create a new individual client. If upsert is true, update existing client if found by referenceId,
    id, sardineCustomerId, chainalysisUserId, or sumsubApplicantId

    Args:
        upsert (bool | Unset):
        body (CreateIndividualClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualClientDto]
     """


    kwargs = _get_kwargs(
        body=body,
upsert=upsert,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateIndividualClientDto,
    upsert: bool | Unset = UNSET,

) -> IndividualClientDto | None:
    """  Create a new individual client. If upsert is true, update existing client if found by referenceId,
    id, sardineCustomerId, chainalysisUserId, or sumsubApplicantId

    Args:
        upsert (bool | Unset):
        body (CreateIndividualClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualClientDto
     """


    return sync_detailed(
        client=client,
body=body,
upsert=upsert,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateIndividualClientDto,
    upsert: bool | Unset = UNSET,

) -> Response[IndividualClientDto]:
    """  Create a new individual client. If upsert is true, update existing client if found by referenceId,
    id, sardineCustomerId, chainalysisUserId, or sumsubApplicantId

    Args:
        upsert (bool | Unset):
        body (CreateIndividualClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualClientDto]
     """


    kwargs = _get_kwargs(
        body=body,
upsert=upsert,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateIndividualClientDto,
    upsert: bool | Unset = UNSET,

) -> IndividualClientDto | None:
    """  Create a new individual client. If upsert is true, update existing client if found by referenceId,
    id, sardineCustomerId, chainalysisUserId, or sumsubApplicantId

    Args:
        upsert (bool | Unset):
        body (CreateIndividualClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualClientDto
     """


    return (await asyncio_detailed(
        client=client,
body=body,
upsert=upsert,

    )).parsed
