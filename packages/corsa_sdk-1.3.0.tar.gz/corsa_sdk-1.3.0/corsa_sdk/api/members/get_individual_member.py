from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.individual_member_dto import IndividualMemberDto
from typing import cast



def _get_kwargs(
    member_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/members/individuals/{member_id}".format(member_id=quote(str(member_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> IndividualMemberDto | None:
    if response.status_code == 200:
        response_200 = IndividualMemberDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[IndividualMemberDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    member_id: str,
    *,
    client: AuthenticatedClient,

) -> Response[IndividualMemberDto]:
    """  Get an individual member by ID

    Args:
        member_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualMemberDto]
     """


    kwargs = _get_kwargs(
        member_id=member_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    member_id: str,
    *,
    client: AuthenticatedClient,

) -> IndividualMemberDto | None:
    """  Get an individual member by ID

    Args:
        member_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualMemberDto
     """


    return sync_detailed(
        member_id=member_id,
client=client,

    ).parsed

async def asyncio_detailed(
    member_id: str,
    *,
    client: AuthenticatedClient,

) -> Response[IndividualMemberDto]:
    """  Get an individual member by ID

    Args:
        member_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualMemberDto]
     """


    kwargs = _get_kwargs(
        member_id=member_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    member_id: str,
    *,
    client: AuthenticatedClient,

) -> IndividualMemberDto | None:
    """  Get an individual member by ID

    Args:
        member_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualMemberDto
     """


    return (await asyncio_detailed(
        member_id=member_id,
client=client,

    )).parsed
