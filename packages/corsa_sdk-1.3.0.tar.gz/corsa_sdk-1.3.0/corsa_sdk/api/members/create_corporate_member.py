from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.corporate_member_dto import CorporateMemberDto
from ...models.create_corporate_member_dto import CreateCorporateMemberDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: CreateCorporateMemberDto,
    upsert: bool | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["upsert"] = upsert


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/members/corporates",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CorporateMemberDto | None:
    if response.status_code == 201:
        response_201 = CorporateMemberDto.from_dict(response.json())



        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CorporateMemberDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateCorporateMemberDto,
    upsert: bool | Unset = UNSET,

) -> Response[CorporateMemberDto]:
    """  Create a new corporate member. If upsert is true, update existing member if found by referenceId

    Args:
        upsert (bool | Unset):
        body (CreateCorporateMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CorporateMemberDto]
     """


    kwargs = _get_kwargs(
        body=body,
upsert=upsert,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateCorporateMemberDto,
    upsert: bool | Unset = UNSET,

) -> CorporateMemberDto | None:
    """  Create a new corporate member. If upsert is true, update existing member if found by referenceId

    Args:
        upsert (bool | Unset):
        body (CreateCorporateMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CorporateMemberDto
     """


    return sync_detailed(
        client=client,
body=body,
upsert=upsert,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateCorporateMemberDto,
    upsert: bool | Unset = UNSET,

) -> Response[CorporateMemberDto]:
    """  Create a new corporate member. If upsert is true, update existing member if found by referenceId

    Args:
        upsert (bool | Unset):
        body (CreateCorporateMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CorporateMemberDto]
     """


    kwargs = _get_kwargs(
        body=body,
upsert=upsert,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateCorporateMemberDto,
    upsert: bool | Unset = UNSET,

) -> CorporateMemberDto | None:
    """  Create a new corporate member. If upsert is true, update existing member if found by referenceId

    Args:
        upsert (bool | Unset):
        body (CreateCorporateMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CorporateMemberDto
     """


    return (await asyncio_detailed(
        client=client,
body=body,
upsert=upsert,

    )).parsed
