from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.individual_member_dto import IndividualMemberDto
from ...models.update_individual_member_dto import UpdateIndividualMemberDto
from typing import cast



def _get_kwargs(
    member_id: str,
    *,
    body: UpdateIndividualMemberDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/members/individuals/{member_id}".format(member_id=quote(str(member_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> IndividualMemberDto | None:
    if response.status_code == 200:
        response_200 = IndividualMemberDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[IndividualMemberDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    member_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateIndividualMemberDto,

) -> Response[IndividualMemberDto]:
    """  Update an individual member

    Args:
        member_id (str):
        body (UpdateIndividualMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualMemberDto]
     """


    kwargs = _get_kwargs(
        member_id=member_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    member_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateIndividualMemberDto,

) -> IndividualMemberDto | None:
    """  Update an individual member

    Args:
        member_id (str):
        body (UpdateIndividualMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualMemberDto
     """


    return sync_detailed(
        member_id=member_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    member_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateIndividualMemberDto,

) -> Response[IndividualMemberDto]:
    """  Update an individual member

    Args:
        member_id (str):
        body (UpdateIndividualMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[IndividualMemberDto]
     """


    kwargs = _get_kwargs(
        member_id=member_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    member_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateIndividualMemberDto,

) -> IndividualMemberDto | None:
    """  Update an individual member

    Args:
        member_id (str):
        body (UpdateIndividualMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        IndividualMemberDto
     """


    return (await asyncio_detailed(
        member_id=member_id,
client=client,
body=body,

    )).parsed
