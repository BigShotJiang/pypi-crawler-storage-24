from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.corporate_member_dto import CorporateMemberDto
from ...models.update_corporate_member_dto import UpdateCorporateMemberDto
from typing import cast



def _get_kwargs(
    member_id: str,
    *,
    body: UpdateCorporateMemberDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/members/corporates/{member_id}".format(member_id=quote(str(member_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CorporateMemberDto | None:
    if response.status_code == 200:
        response_200 = CorporateMemberDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CorporateMemberDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    member_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateCorporateMemberDto,

) -> Response[CorporateMemberDto]:
    """  Update a corporate member

    Args:
        member_id (str):
        body (UpdateCorporateMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CorporateMemberDto]
     """


    kwargs = _get_kwargs(
        member_id=member_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    member_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateCorporateMemberDto,

) -> CorporateMemberDto | None:
    """  Update a corporate member

    Args:
        member_id (str):
        body (UpdateCorporateMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CorporateMemberDto
     """


    return sync_detailed(
        member_id=member_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    member_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateCorporateMemberDto,

) -> Response[CorporateMemberDto]:
    """  Update a corporate member

    Args:
        member_id (str):
        body (UpdateCorporateMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CorporateMemberDto]
     """


    kwargs = _get_kwargs(
        member_id=member_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    member_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateCorporateMemberDto,

) -> CorporateMemberDto | None:
    """  Update a corporate member

    Args:
        member_id (str):
        body (UpdateCorporateMemberDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CorporateMemberDto
     """


    return (await asyncio_detailed(
        member_id=member_id,
client=client,
body=body,

    )).parsed
