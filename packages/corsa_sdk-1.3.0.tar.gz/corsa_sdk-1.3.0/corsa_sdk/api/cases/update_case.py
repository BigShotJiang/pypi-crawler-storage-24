from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.case_dto import CaseDto
from ...models.update_case_dto import UpdateCaseDto
from typing import cast



def _get_kwargs(
    case_id: str,
    *,
    body: UpdateCaseDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/cases/{case_id}/update".format(case_id=quote(str(case_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> CaseDto | None:
    if response.status_code == 200:
        response_200 = CaseDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[CaseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    case_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateCaseDto,

) -> Response[CaseDto]:
    """  Update a case

    Args:
        case_id (str):
        body (UpdateCaseDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CaseDto]
     """


    kwargs = _get_kwargs(
        case_id=case_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    case_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateCaseDto,

) -> CaseDto | None:
    """  Update a case

    Args:
        case_id (str):
        body (UpdateCaseDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CaseDto
     """


    return sync_detailed(
        case_id=case_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    case_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateCaseDto,

) -> Response[CaseDto]:
    """  Update a case

    Args:
        case_id (str):
        body (UpdateCaseDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[CaseDto]
     """


    kwargs = _get_kwargs(
        case_id=case_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    case_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateCaseDto,

) -> CaseDto | None:
    """  Update a case

    Args:
        case_id (str):
        body (UpdateCaseDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        CaseDto
     """


    return (await asyncio_detailed(
        case_id=case_id,
client=client,
body=body,

    )).parsed
