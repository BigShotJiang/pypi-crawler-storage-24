from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.transaction_evaluations_response_dto import TransactionEvaluationsResponseDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    transaction_id: str,
    *,
    page: float | Unset = UNSET,
    page_size: float | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["page"] = page

    params["pageSize"] = page_size


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/evaluation/transaction/{transaction_id}/results".format(transaction_id=quote(str(transaction_id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> TransactionEvaluationsResponseDto | None:
    if response.status_code == 200:
        response_200 = TransactionEvaluationsResponseDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[TransactionEvaluationsResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    transaction_id: str,
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    page_size: float | Unset = UNSET,

) -> Response[TransactionEvaluationsResponseDto]:
    """ Get all rule evaluations for a transaction

     Get all rule evaluations for a specific transaction

    Args:
        transaction_id (str):
        page (float | Unset):
        page_size (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TransactionEvaluationsResponseDto]
     """


    kwargs = _get_kwargs(
        transaction_id=transaction_id,
page=page,
page_size=page_size,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    transaction_id: str,
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    page_size: float | Unset = UNSET,

) -> TransactionEvaluationsResponseDto | None:
    """ Get all rule evaluations for a transaction

     Get all rule evaluations for a specific transaction

    Args:
        transaction_id (str):
        page (float | Unset):
        page_size (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TransactionEvaluationsResponseDto
     """


    return sync_detailed(
        transaction_id=transaction_id,
client=client,
page=page,
page_size=page_size,

    ).parsed

async def asyncio_detailed(
    transaction_id: str,
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    page_size: float | Unset = UNSET,

) -> Response[TransactionEvaluationsResponseDto]:
    """ Get all rule evaluations for a transaction

     Get all rule evaluations for a specific transaction

    Args:
        transaction_id (str):
        page (float | Unset):
        page_size (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TransactionEvaluationsResponseDto]
     """


    kwargs = _get_kwargs(
        transaction_id=transaction_id,
page=page,
page_size=page_size,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    transaction_id: str,
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    page_size: float | Unset = UNSET,

) -> TransactionEvaluationsResponseDto | None:
    """ Get all rule evaluations for a transaction

     Get all rule evaluations for a specific transaction

    Args:
        transaction_id (str):
        page (float | Unset):
        page_size (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TransactionEvaluationsResponseDto
     """


    return (await asyncio_detailed(
        transaction_id=transaction_id,
client=client,
page=page,
page_size=page_size,

    )).parsed
