from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.checklist_item_response_dto import ChecklistItemResponseDto
from ...models.update_checklist_item_dto import UpdateChecklistItemDto
from typing import cast



def _get_kwargs(
    checklist_id: str,
    item_id: str,
    *,
    body: UpdateChecklistItemDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/checklists/{checklist_id}/items/{item_id}".format(checklist_id=quote(str(checklist_id), safe=""),item_id=quote(str(item_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | ChecklistItemResponseDto | None:
    if response.status_code == 200:
        response_200 = ChecklistItemResponseDto.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 500:
        response_500 = cast(Any, None)
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | ChecklistItemResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    checklist_id: str,
    item_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateChecklistItemDto,

) -> Response[Any | ChecklistItemResponseDto]:
    """  Update checklist item

    Args:
        checklist_id (str):  Example: checklist-123.
        item_id (str):  Example: item-123.
        body (UpdateChecklistItemDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ChecklistItemResponseDto]
     """


    kwargs = _get_kwargs(
        checklist_id=checklist_id,
item_id=item_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    checklist_id: str,
    item_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateChecklistItemDto,

) -> Any | ChecklistItemResponseDto | None:
    """  Update checklist item

    Args:
        checklist_id (str):  Example: checklist-123.
        item_id (str):  Example: item-123.
        body (UpdateChecklistItemDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ChecklistItemResponseDto
     """


    return sync_detailed(
        checklist_id=checklist_id,
item_id=item_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    checklist_id: str,
    item_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateChecklistItemDto,

) -> Response[Any | ChecklistItemResponseDto]:
    """  Update checklist item

    Args:
        checklist_id (str):  Example: checklist-123.
        item_id (str):  Example: item-123.
        body (UpdateChecklistItemDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ChecklistItemResponseDto]
     """


    kwargs = _get_kwargs(
        checklist_id=checklist_id,
item_id=item_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    checklist_id: str,
    item_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateChecklistItemDto,

) -> Any | ChecklistItemResponseDto | None:
    """  Update checklist item

    Args:
        checklist_id (str):  Example: checklist-123.
        item_id (str):  Example: item-123.
        body (UpdateChecklistItemDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ChecklistItemResponseDto
     """


    return (await asyncio_detailed(
        checklist_id=checklist_id,
item_id=item_id,
client=client,
body=body,

    )).parsed
