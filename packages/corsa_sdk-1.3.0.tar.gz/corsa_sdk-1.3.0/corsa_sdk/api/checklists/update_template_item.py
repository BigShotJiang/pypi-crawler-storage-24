from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.checklist_template_item_response_dto import ChecklistTemplateItemResponseDto
from ...models.update_checklist_template_item_dto import UpdateChecklistTemplateItemDto
from typing import cast



def _get_kwargs(
    item_id: str,
    *,
    body: UpdateChecklistTemplateItemDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/checklist-templates/items/{item_id}".format(item_id=quote(str(item_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | ChecklistTemplateItemResponseDto | None:
    if response.status_code == 200:
        response_200 = ChecklistTemplateItemResponseDto.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 404:
        response_404 = cast(Any, None)
        return response_404

    if response.status_code == 500:
        response_500 = cast(Any, None)
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | ChecklistTemplateItemResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    item_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChecklistTemplateItemDto,

) -> Response[Any | ChecklistTemplateItemResponseDto]:
    """  Update template item

    Args:
        item_id (str):  Example: item-123.
        body (UpdateChecklistTemplateItemDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ChecklistTemplateItemResponseDto]
     """


    kwargs = _get_kwargs(
        item_id=item_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    item_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChecklistTemplateItemDto,

) -> Any | ChecklistTemplateItemResponseDto | None:
    """  Update template item

    Args:
        item_id (str):  Example: item-123.
        body (UpdateChecklistTemplateItemDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ChecklistTemplateItemResponseDto
     """


    return sync_detailed(
        item_id=item_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    item_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChecklistTemplateItemDto,

) -> Response[Any | ChecklistTemplateItemResponseDto]:
    """  Update template item

    Args:
        item_id (str):  Example: item-123.
        body (UpdateChecklistTemplateItemDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ChecklistTemplateItemResponseDto]
     """


    kwargs = _get_kwargs(
        item_id=item_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    item_id: str,
    *,
    client: AuthenticatedClient | Client,
    body: UpdateChecklistTemplateItemDto,

) -> Any | ChecklistTemplateItemResponseDto | None:
    """  Update template item

    Args:
        item_id (str):  Example: item-123.
        body (UpdateChecklistTemplateItemDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ChecklistTemplateItemResponseDto
     """


    return (await asyncio_detailed(
        item_id=item_id,
client=client,
body=body,

    )).parsed
