from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.checklist_response_dto import ChecklistResponseDto
from typing import cast



def _get_kwargs(
    *,
    entity_id: str,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["entityId"] = entity_id


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/checklists/entity",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | ChecklistResponseDto | None:
    if response.status_code == 200:
        response_200 = ChecklistResponseDto.from_dict(response.json())



        return response_200

    if response.status_code == 400:
        response_400 = cast(Any, None)
        return response_400

    if response.status_code == 500:
        response_500 = cast(Any, None)
        return response_500

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | ChecklistResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    entity_id: str,

) -> Response[Any | ChecklistResponseDto]:
    """  Get the newest active checklist for an entity

    Args:
        entity_id (str):  Example: client-123.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ChecklistResponseDto]
     """


    kwargs = _get_kwargs(
        entity_id=entity_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    entity_id: str,

) -> Any | ChecklistResponseDto | None:
    """  Get the newest active checklist for an entity

    Args:
        entity_id (str):  Example: client-123.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ChecklistResponseDto
     """


    return sync_detailed(
        client=client,
entity_id=entity_id,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    entity_id: str,

) -> Response[Any | ChecklistResponseDto]:
    """  Get the newest active checklist for an entity

    Args:
        entity_id (str):  Example: client-123.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ChecklistResponseDto]
     """


    kwargs = _get_kwargs(
        entity_id=entity_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    entity_id: str,

) -> Any | ChecklistResponseDto | None:
    """  Get the newest active checklist for an entity

    Args:
        entity_id (str):  Example: client-123.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ChecklistResponseDto
     """


    return (await asyncio_detailed(
        client=client,
entity_id=entity_id,

    )).parsed
