from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.associate_blockchain_wallet_with_client_dto import AssociateBlockchainWalletWithClientDto
from ...models.blockchain_wallet_dto import BlockchainWalletDto
from typing import cast



def _get_kwargs(
    blockchain_wallet_id: str,
    *,
    body: AssociateBlockchainWalletWithClientDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/blockchain-wallets/{blockchain_wallet_id}/clients".format(blockchain_wallet_id=quote(str(blockchain_wallet_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BlockchainWalletDto | None:
    if response.status_code == 200:
        response_200 = BlockchainWalletDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BlockchainWalletDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    blockchain_wallet_id: str,
    *,
    client: AuthenticatedClient,
    body: AssociateBlockchainWalletWithClientDto,

) -> Response[BlockchainWalletDto]:
    """  Associate a blockchain wallet with one or more clients by ID, reference ID, or wallet address

    Args:
        blockchain_wallet_id (str):
        body (AssociateBlockchainWalletWithClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BlockchainWalletDto]
     """


    kwargs = _get_kwargs(
        blockchain_wallet_id=blockchain_wallet_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    blockchain_wallet_id: str,
    *,
    client: AuthenticatedClient,
    body: AssociateBlockchainWalletWithClientDto,

) -> BlockchainWalletDto | None:
    """  Associate a blockchain wallet with one or more clients by ID, reference ID, or wallet address

    Args:
        blockchain_wallet_id (str):
        body (AssociateBlockchainWalletWithClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BlockchainWalletDto
     """


    return sync_detailed(
        blockchain_wallet_id=blockchain_wallet_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    blockchain_wallet_id: str,
    *,
    client: AuthenticatedClient,
    body: AssociateBlockchainWalletWithClientDto,

) -> Response[BlockchainWalletDto]:
    """  Associate a blockchain wallet with one or more clients by ID, reference ID, or wallet address

    Args:
        blockchain_wallet_id (str):
        body (AssociateBlockchainWalletWithClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BlockchainWalletDto]
     """


    kwargs = _get_kwargs(
        blockchain_wallet_id=blockchain_wallet_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    blockchain_wallet_id: str,
    *,
    client: AuthenticatedClient,
    body: AssociateBlockchainWalletWithClientDto,

) -> BlockchainWalletDto | None:
    """  Associate a blockchain wallet with one or more clients by ID, reference ID, or wallet address

    Args:
        blockchain_wallet_id (str):
        body (AssociateBlockchainWalletWithClientDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BlockchainWalletDto
     """


    return (await asyncio_detailed(
        blockchain_wallet_id=blockchain_wallet_id,
client=client,
body=body,

    )).parsed
