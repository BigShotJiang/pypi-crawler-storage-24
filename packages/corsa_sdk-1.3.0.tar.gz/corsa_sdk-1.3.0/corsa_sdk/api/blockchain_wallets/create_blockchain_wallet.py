from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.blockchain_wallet_dto import BlockchainWalletDto
from ...models.create_blockchain_wallet_dto import CreateBlockchainWalletDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: CreateBlockchainWalletDto,
    upsert: bool | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["upsert"] = upsert


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/blockchain-wallets",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BlockchainWalletDto | None:
    if response.status_code == 201:
        response_201 = BlockchainWalletDto.from_dict(response.json())



        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BlockchainWalletDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateBlockchainWalletDto,
    upsert: bool | Unset = UNSET,

) -> Response[BlockchainWalletDto]:
    """  Create a new blockchain wallet. If upsert is true, update existing wallet if found by referenceId or
    address

    Args:
        upsert (bool | Unset):
        body (CreateBlockchainWalletDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BlockchainWalletDto]
     """


    kwargs = _get_kwargs(
        body=body,
upsert=upsert,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateBlockchainWalletDto,
    upsert: bool | Unset = UNSET,

) -> BlockchainWalletDto | None:
    """  Create a new blockchain wallet. If upsert is true, update existing wallet if found by referenceId or
    address

    Args:
        upsert (bool | Unset):
        body (CreateBlockchainWalletDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BlockchainWalletDto
     """


    return sync_detailed(
        client=client,
body=body,
upsert=upsert,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateBlockchainWalletDto,
    upsert: bool | Unset = UNSET,

) -> Response[BlockchainWalletDto]:
    """  Create a new blockchain wallet. If upsert is true, update existing wallet if found by referenceId or
    address

    Args:
        upsert (bool | Unset):
        body (CreateBlockchainWalletDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BlockchainWalletDto]
     """


    kwargs = _get_kwargs(
        body=body,
upsert=upsert,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateBlockchainWalletDto,
    upsert: bool | Unset = UNSET,

) -> BlockchainWalletDto | None:
    """  Create a new blockchain wallet. If upsert is true, update existing wallet if found by referenceId or
    address

    Args:
        upsert (bool | Unset):
        body (CreateBlockchainWalletDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BlockchainWalletDto
     """


    return (await asyncio_detailed(
        client=client,
body=body,
upsert=upsert,

    )).parsed
