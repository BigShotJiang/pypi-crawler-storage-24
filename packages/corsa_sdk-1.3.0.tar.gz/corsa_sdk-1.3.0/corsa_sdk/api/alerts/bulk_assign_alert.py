from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.bulk_assign_alert_dto import BulkAssignAlertDto
from ...models.bulk_assign_alert_response_dto import BulkAssignAlertResponseDto
from typing import cast



def _get_kwargs(
    *,
    body: BulkAssignAlertDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/alerts/bulk/assign",
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BulkAssignAlertResponseDto | None:
    if response.status_code == 200:
        response_200 = BulkAssignAlertResponseDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BulkAssignAlertResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: BulkAssignAlertDto,

) -> Response[BulkAssignAlertResponseDto]:
    """ Assign multiple alerts to a user

     Assign multiple alerts to a user (maximum 100)

    Args:
        body (BulkAssignAlertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BulkAssignAlertResponseDto]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: BulkAssignAlertDto,

) -> BulkAssignAlertResponseDto | None:
    """ Assign multiple alerts to a user

     Assign multiple alerts to a user (maximum 100)

    Args:
        body (BulkAssignAlertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BulkAssignAlertResponseDto
     """


    return sync_detailed(
        client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: BulkAssignAlertDto,

) -> Response[BulkAssignAlertResponseDto]:
    """ Assign multiple alerts to a user

     Assign multiple alerts to a user (maximum 100)

    Args:
        body (BulkAssignAlertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BulkAssignAlertResponseDto]
     """


    kwargs = _get_kwargs(
        body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: BulkAssignAlertDto,

) -> BulkAssignAlertResponseDto | None:
    """ Assign multiple alerts to a user

     Assign multiple alerts to a user (maximum 100)

    Args:
        body (BulkAssignAlertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BulkAssignAlertResponseDto
     """


    return (await asyncio_detailed(
        client=client,
body=body,

    )).parsed
