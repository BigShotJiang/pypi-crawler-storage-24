from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.alert_dto import AlertDto
from ...models.update_alert_dto import UpdateAlertDto
from typing import cast



def _get_kwargs(
    alert_id: str,
    *,
    body: UpdateAlertDto,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/alerts/{alert_id}/update".format(alert_id=quote(str(alert_id), safe=""),),
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> AlertDto | None:
    if response.status_code == 200:
        response_200 = AlertDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[AlertDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    alert_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateAlertDto,

) -> Response[AlertDto]:
    """  Update an alert

    Args:
        alert_id (str):
        body (UpdateAlertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AlertDto]
     """


    kwargs = _get_kwargs(
        alert_id=alert_id,
body=body,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    alert_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateAlertDto,

) -> AlertDto | None:
    """  Update an alert

    Args:
        alert_id (str):
        body (UpdateAlertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AlertDto
     """


    return sync_detailed(
        alert_id=alert_id,
client=client,
body=body,

    ).parsed

async def asyncio_detailed(
    alert_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateAlertDto,

) -> Response[AlertDto]:
    """  Update an alert

    Args:
        alert_id (str):
        body (UpdateAlertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AlertDto]
     """


    kwargs = _get_kwargs(
        alert_id=alert_id,
body=body,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    alert_id: str,
    *,
    client: AuthenticatedClient,
    body: UpdateAlertDto,

) -> AlertDto | None:
    """  Update an alert

    Args:
        alert_id (str):
        body (UpdateAlertDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AlertDto
     """


    return (await asyncio_detailed(
        alert_id=alert_id,
client=client,
body=body,

    )).parsed
