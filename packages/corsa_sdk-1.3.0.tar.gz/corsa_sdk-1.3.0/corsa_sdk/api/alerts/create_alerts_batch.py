from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.batch_create_alerts_dto import BatchCreateAlertsDto
from ...models.batch_create_alerts_response_dto import BatchCreateAlertsResponseDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: BatchCreateAlertsDto,
    fail_on_association: bool | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["failOnAssociation"] = fail_on_association


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/alerts/batch",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BatchCreateAlertsResponseDto | None:
    if response.status_code == 201:
        response_201 = BatchCreateAlertsResponseDto.from_dict(response.json())



        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BatchCreateAlertsResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: BatchCreateAlertsDto,
    fail_on_association: bool | Unset = UNSET,

) -> Response[BatchCreateAlertsResponseDto]:
    """  Create multiple alerts in batch (maximum 50 alerts)

    Args:
        fail_on_association (bool | Unset):
        body (BatchCreateAlertsDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BatchCreateAlertsResponseDto]
     """


    kwargs = _get_kwargs(
        body=body,
fail_on_association=fail_on_association,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: BatchCreateAlertsDto,
    fail_on_association: bool | Unset = UNSET,

) -> BatchCreateAlertsResponseDto | None:
    """  Create multiple alerts in batch (maximum 50 alerts)

    Args:
        fail_on_association (bool | Unset):
        body (BatchCreateAlertsDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BatchCreateAlertsResponseDto
     """


    return sync_detailed(
        client=client,
body=body,
fail_on_association=fail_on_association,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: BatchCreateAlertsDto,
    fail_on_association: bool | Unset = UNSET,

) -> Response[BatchCreateAlertsResponseDto]:
    """  Create multiple alerts in batch (maximum 50 alerts)

    Args:
        fail_on_association (bool | Unset):
        body (BatchCreateAlertsDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BatchCreateAlertsResponseDto]
     """


    kwargs = _get_kwargs(
        body=body,
fail_on_association=fail_on_association,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: BatchCreateAlertsDto,
    fail_on_association: bool | Unset = UNSET,

) -> BatchCreateAlertsResponseDto | None:
    """  Create multiple alerts in batch (maximum 50 alerts)

    Args:
        fail_on_association (bool | Unset):
        body (BatchCreateAlertsDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BatchCreateAlertsResponseDto
     """


    return (await asyncio_detailed(
        client=client,
body=body,
fail_on_association=fail_on_association,

    )).parsed
