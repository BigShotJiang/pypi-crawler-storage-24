from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.bank_account_dto import BankAccountDto
from typing import cast



def _get_kwargs(
    bank_account_id: str,

) -> dict[str, Any]:
    

    

    

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/bank-accounts/{bank_account_id}".format(bank_account_id=quote(str(bank_account_id), safe=""),),
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> BankAccountDto | None:
    if response.status_code == 200:
        response_200 = BankAccountDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[BankAccountDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    bank_account_id: str,
    *,
    client: AuthenticatedClient,

) -> Response[BankAccountDto]:
    """  Get a bank account by ID or reference ID

    Args:
        bank_account_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BankAccountDto]
     """


    kwargs = _get_kwargs(
        bank_account_id=bank_account_id,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    bank_account_id: str,
    *,
    client: AuthenticatedClient,

) -> BankAccountDto | None:
    """  Get a bank account by ID or reference ID

    Args:
        bank_account_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BankAccountDto
     """


    return sync_detailed(
        bank_account_id=bank_account_id,
client=client,

    ).parsed

async def asyncio_detailed(
    bank_account_id: str,
    *,
    client: AuthenticatedClient,

) -> Response[BankAccountDto]:
    """  Get a bank account by ID or reference ID

    Args:
        bank_account_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BankAccountDto]
     """


    kwargs = _get_kwargs(
        bank_account_id=bank_account_id,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    bank_account_id: str,
    *,
    client: AuthenticatedClient,

) -> BankAccountDto | None:
    """  Get a bank account by ID or reference ID

    Args:
        bank_account_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BankAccountDto
     """


    return (await asyncio_detailed(
        bank_account_id=bank_account_id,
client=client,

    )).parsed
