from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.create_trade_operation_dto import CreateTradeOperationDto
from ...models.trade_operation_dto import TradeOperationDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    body: CreateTradeOperationDto,
    should_append_to_existing_trade: bool | Unset = UNSET,
    upsert: bool | Unset = UNSET,

) -> dict[str, Any]:
    headers: dict[str, Any] = {}


    

    params: dict[str, Any] = {}

    params["shouldAppendToExistingTrade"] = should_append_to_existing_trade

    params["upsert"] = upsert


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/operations/trades",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()


    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> TradeOperationDto | None:
    if response.status_code == 201:
        response_201 = TradeOperationDto.from_dict(response.json())



        return response_201

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[TradeOperationDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateTradeOperationDto,
    should_append_to_existing_trade: bool | Unset = UNSET,
    upsert: bool | Unset = UNSET,

) -> Response[TradeOperationDto]:
    """  Create a new trade

    Args:
        should_append_to_existing_trade (bool | Unset):
        upsert (bool | Unset):
        body (CreateTradeOperationDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TradeOperationDto]
     """


    kwargs = _get_kwargs(
        body=body,
should_append_to_existing_trade=should_append_to_existing_trade,
upsert=upsert,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    *,
    client: AuthenticatedClient,
    body: CreateTradeOperationDto,
    should_append_to_existing_trade: bool | Unset = UNSET,
    upsert: bool | Unset = UNSET,

) -> TradeOperationDto | None:
    """  Create a new trade

    Args:
        should_append_to_existing_trade (bool | Unset):
        upsert (bool | Unset):
        body (CreateTradeOperationDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TradeOperationDto
     """


    return sync_detailed(
        client=client,
body=body,
should_append_to_existing_trade=should_append_to_existing_trade,
upsert=upsert,

    ).parsed

async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateTradeOperationDto,
    should_append_to_existing_trade: bool | Unset = UNSET,
    upsert: bool | Unset = UNSET,

) -> Response[TradeOperationDto]:
    """  Create a new trade

    Args:
        should_append_to_existing_trade (bool | Unset):
        upsert (bool | Unset):
        body (CreateTradeOperationDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[TradeOperationDto]
     """


    kwargs = _get_kwargs(
        body=body,
should_append_to_existing_trade=should_append_to_existing_trade,
upsert=upsert,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateTradeOperationDto,
    should_append_to_existing_trade: bool | Unset = UNSET,
    upsert: bool | Unset = UNSET,

) -> TradeOperationDto | None:
    """  Create a new trade

    Args:
        should_append_to_existing_trade (bool | Unset):
        upsert (bool | Unset):
        body (CreateTradeOperationDto):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        TradeOperationDto
     """


    return (await asyncio_detailed(
        client=client,
body=body,
should_append_to_existing_trade=should_append_to_existing_trade,
upsert=upsert,

    )).parsed
