from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.list_rules_sort_by_item import ListRulesSortByItem
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    *,
    page: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    filter_id: list[str] | Unset = UNSET,
    filter_name: list[str] | Unset = UNSET,
    filter_status: list[str] | Unset = UNSET,
    filter_updated_at: list[str] | Unset = UNSET,
    filter_created_at: list[str] | Unset = UNSET,
    sort_by: list[ListRulesSortByItem] | Unset = UNSET,
    search: str | Unset = UNSET,
    search_by: list[str] | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["page"] = page

    params["limit"] = limit

    json_filter_id: list[str] | Unset = UNSET
    if not isinstance(filter_id, Unset):
        json_filter_id = filter_id


    params["filter.id"] = json_filter_id

    json_filter_name: list[str] | Unset = UNSET
    if not isinstance(filter_name, Unset):
        json_filter_name = filter_name


    params["filter.name"] = json_filter_name

    json_filter_status: list[str] | Unset = UNSET
    if not isinstance(filter_status, Unset):
        json_filter_status = filter_status


    params["filter.status"] = json_filter_status

    json_filter_updated_at: list[str] | Unset = UNSET
    if not isinstance(filter_updated_at, Unset):
        json_filter_updated_at = filter_updated_at


    params["filter.updatedAt"] = json_filter_updated_at

    json_filter_created_at: list[str] | Unset = UNSET
    if not isinstance(filter_created_at, Unset):
        json_filter_created_at = filter_created_at


    params["filter.createdAt"] = json_filter_created_at

    json_sort_by: list[str] | Unset = UNSET
    if not isinstance(sort_by, Unset):
        json_sort_by = []
        for sort_by_item_data in sort_by:
            sort_by_item = sort_by_item_data.value
            json_sort_by.append(sort_by_item)


    params["sortBy"] = json_sort_by

    params["search"] = search

    json_search_by: list[str] | Unset = UNSET
    if not isinstance(search_by, Unset):
        json_search_by = search_by


    params["searchBy"] = json_search_by


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/rules",
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | None:
    if response.status_code == 200:
        return None

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    filter_id: list[str] | Unset = UNSET,
    filter_name: list[str] | Unset = UNSET,
    filter_status: list[str] | Unset = UNSET,
    filter_updated_at: list[str] | Unset = UNSET,
    filter_created_at: list[str] | Unset = UNSET,
    sort_by: list[ListRulesSortByItem] | Unset = UNSET,
    search: str | Unset = UNSET,
    search_by: list[str] | Unset = UNSET,

) -> Response[Any]:
    """ List rules with pagination

     List rules with pagination

    Args:
        page (float | Unset):
        limit (float | Unset):
        filter_id (list[str] | Unset):
        filter_name (list[str] | Unset):
        filter_status (list[str] | Unset):
        filter_updated_at (list[str] | Unset):
        filter_created_at (list[str] | Unset):
        sort_by (list[ListRulesSortByItem] | Unset):
        search (str | Unset):
        search_by (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
filter_id=filter_id,
filter_name=filter_name,
filter_status=filter_status,
filter_updated_at=filter_updated_at,
filter_created_at=filter_created_at,
sort_by=sort_by,
search=search,
search_by=search_by,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    page: float | Unset = UNSET,
    limit: float | Unset = UNSET,
    filter_id: list[str] | Unset = UNSET,
    filter_name: list[str] | Unset = UNSET,
    filter_status: list[str] | Unset = UNSET,
    filter_updated_at: list[str] | Unset = UNSET,
    filter_created_at: list[str] | Unset = UNSET,
    sort_by: list[ListRulesSortByItem] | Unset = UNSET,
    search: str | Unset = UNSET,
    search_by: list[str] | Unset = UNSET,

) -> Response[Any]:
    """ List rules with pagination

     List rules with pagination

    Args:
        page (float | Unset):
        limit (float | Unset):
        filter_id (list[str] | Unset):
        filter_name (list[str] | Unset):
        filter_status (list[str] | Unset):
        filter_updated_at (list[str] | Unset):
        filter_created_at (list[str] | Unset):
        sort_by (list[ListRulesSortByItem] | Unset):
        search (str | Unset):
        search_by (list[str] | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any]
     """


    kwargs = _get_kwargs(
        page=page,
limit=limit,
filter_id=filter_id,
filter_name=filter_name,
filter_status=filter_status,
filter_updated_at=filter_updated_at,
filter_created_at=filter_created_at,
sort_by=sort_by,
search=search,
search_by=search_by,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

