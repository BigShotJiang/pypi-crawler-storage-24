from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ...client import AuthenticatedClient, Client
from ...types import Response, UNSET
from ... import errors

from ...models.rule_response_dto import RuleResponseDto
from ...types import UNSET, Unset
from typing import cast



def _get_kwargs(
    id: str,
    *,
    version: float | Unset = UNSET,

) -> dict[str, Any]:
    

    

    params: dict[str, Any] = {}

    params["version"] = version


    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}


    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/rules/{id}".format(id=quote(str(id), safe=""),),
        "params": params,
    }


    return _kwargs



def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> RuleResponseDto | None:
    if response.status_code == 200:
        response_200 = RuleResponseDto.from_dict(response.json())



        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[RuleResponseDto]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    version: float | Unset = UNSET,

) -> Response[RuleResponseDto]:
    """ Get a rule by ID

     Get a rule by ID

    Args:
        id (str):
        version (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RuleResponseDto]
     """


    kwargs = _get_kwargs(
        id=id,
version=version,

    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)

def sync(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    version: float | Unset = UNSET,

) -> RuleResponseDto | None:
    """ Get a rule by ID

     Get a rule by ID

    Args:
        id (str):
        version (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RuleResponseDto
     """


    return sync_detailed(
        id=id,
client=client,
version=version,

    ).parsed

async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    version: float | Unset = UNSET,

) -> Response[RuleResponseDto]:
    """ Get a rule by ID

     Get a rule by ID

    Args:
        id (str):
        version (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[RuleResponseDto]
     """


    kwargs = _get_kwargs(
        id=id,
version=version,

    )

    response = await client.get_async_httpx_client().request(
        **kwargs
    )

    return _build_response(client=client, response=response)

async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient | Client,
    version: float | Unset = UNSET,

) -> RuleResponseDto | None:
    """ Get a rule by ID

     Get a rule by ID

    Args:
        id (str):
        version (float | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        RuleResponseDto
     """


    return (await asyncio_detailed(
        id=id,
client=client,
version=version,

    )).parsed
