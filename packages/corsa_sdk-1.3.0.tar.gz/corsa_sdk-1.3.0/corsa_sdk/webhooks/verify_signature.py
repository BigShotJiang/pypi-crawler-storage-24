"""Webhook signature verification utilities.

Port of the TypeScript webhook verification from @corsa-labs/sdk.
Uses HMAC-SHA256 with timing-safe comparison to prevent timing attacks.
"""

from __future__ import annotations

import hashlib
import hmac


def sign_webhook_payload(secret: str, payload: str) -> str:
    """Sign a payload with a secret using HMAC-SHA256.

    Args:
        secret: The webhook secret.
        payload: The raw payload string to sign.

    Returns:
        The signature in the format ``sha256=<hex digest>``.

    Raises:
        TypeError: If secret or payload are empty / not strings.
    """
    if not secret or not payload:
        raise TypeError("[corsa-sdk] secret & payload required for sign()")
    if not isinstance(payload, str):
        raise TypeError("[corsa-sdk] payload must be a string")

    digest = hmac.new(
        secret.encode("utf-8"),
        payload.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return f"sha256={digest}"


def verify_webhook_signature(secret: str, event_payload: str, signature: str) -> bool:
    """Verify a webhook signature against a secret.

    Uses constant-time comparison to prevent timing attacks.

    Args:
        secret: The webhook secret.
        event_payload: The raw event payload string.
        signature: The signature header value to verify.

    Returns:
        ``True`` if the signature is valid, ``False`` otherwise.

    Raises:
        TypeError: If any required argument is missing or not a string.
    """
    if not secret or not event_payload or not signature:
        raise TypeError("[corsa-sdk] secret, event_payload & signature required")
    if not isinstance(event_payload, str):
        raise TypeError("[corsa-sdk] event_payload must be a string")

    expected = sign_webhook_payload(secret, event_payload)

    if len(signature) != len(expected):
        return False

    return hmac.compare_digest(signature, expected)
