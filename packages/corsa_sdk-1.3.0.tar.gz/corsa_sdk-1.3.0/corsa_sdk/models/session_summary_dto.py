from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="SessionSummaryDto")



@_attrs_define
class SessionSummaryDto:
    """ 
        Attributes:
            id (str): Session ID
            ip_address (str): IP address
            geo_country_code (str | Unset): Geo country code
            geo_city (str | Unset): Geo city
            is_vpn (bool | Unset):
            is_tor (bool | Unset):
            is_proxy (bool | Unset):
            device_fingerprint (str | Unset): Device fingerprint
            device_type (str | Unset): Device type
     """

    id: str
    ip_address: str
    geo_country_code: str | Unset = UNSET
    geo_city: str | Unset = UNSET
    is_vpn: bool | Unset = UNSET
    is_tor: bool | Unset = UNSET
    is_proxy: bool | Unset = UNSET
    device_fingerprint: str | Unset = UNSET
    device_type: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        ip_address = self.ip_address

        geo_country_code = self.geo_country_code

        geo_city = self.geo_city

        is_vpn = self.is_vpn

        is_tor = self.is_tor

        is_proxy = self.is_proxy

        device_fingerprint = self.device_fingerprint

        device_type = self.device_type


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "ipAddress": ip_address,
        })
        if geo_country_code is not UNSET:
            field_dict["geoCountryCode"] = geo_country_code
        if geo_city is not UNSET:
            field_dict["geoCity"] = geo_city
        if is_vpn is not UNSET:
            field_dict["isVpn"] = is_vpn
        if is_tor is not UNSET:
            field_dict["isTor"] = is_tor
        if is_proxy is not UNSET:
            field_dict["isProxy"] = is_proxy
        if device_fingerprint is not UNSET:
            field_dict["deviceFingerprint"] = device_fingerprint
        if device_type is not UNSET:
            field_dict["deviceType"] = device_type

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        ip_address = d.pop("ipAddress")

        geo_country_code = d.pop("geoCountryCode", UNSET)

        geo_city = d.pop("geoCity", UNSET)

        is_vpn = d.pop("isVpn", UNSET)

        is_tor = d.pop("isTor", UNSET)

        is_proxy = d.pop("isProxy", UNSET)

        device_fingerprint = d.pop("deviceFingerprint", UNSET)

        device_type = d.pop("deviceType", UNSET)

        session_summary_dto = cls(
            id=id,
            ip_address=ip_address,
            geo_country_code=geo_country_code,
            geo_city=geo_city,
            is_vpn=is_vpn,
            is_tor=is_tor,
            is_proxy=is_proxy,
            device_fingerprint=device_fingerprint,
            device_type=device_type,
        )


        session_summary_dto.additional_properties = d
        return session_summary_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
