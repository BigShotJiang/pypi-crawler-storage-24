from enum import Enum

class ParticipantDtoRole(str, Enum):
    ANY = "any"
    DESTINATION = "destination"
    SOURCE = "source"

    def __str__(self) -> str:
        return str(self.value)
