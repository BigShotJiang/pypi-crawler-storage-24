from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_corporate_member_dto_adverse_media_status import UpdateCorporateMemberDtoAdverseMediaStatus
from ..models.update_corporate_member_dto_pep_status import UpdateCorporateMemberDtoPepStatus
from ..models.update_corporate_member_dto_role_type import UpdateCorporateMemberDtoRoleType
from ..models.update_corporate_member_dto_sanctions_status import UpdateCorporateMemberDtoSanctionsStatus
from ..models.update_corporate_member_dto_status import UpdateCorporateMemberDtoStatus
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="UpdateCorporateMemberDto")



@_attrs_define
class UpdateCorporateMemberDto:
    """ 
        Attributes:
            reference_id (str | Unset): External reference ID Example: CORP123.
            legal_entity_name (str | Unset): Legal entity name Example: Acme Corporation Ltd.
            country_of_incorporation (str | Unset): Country of incorporation code Example: USA.
            registration_number (str | Unset): Registration number Example: 12345678.
            date_of_incorporation (str | Unset): Date of incorporation in ISO format Example: 2010-05-15T00:00:00Z.
            business_address_line_1 (str | Unset): First line of business address Example: 123 Business Street.
            business_address_line_2 (str | Unset): Second line of business address Example: Suite 400.
            business_address_city (str | Unset): Business address city Example: New York.
            business_address_postal_code (str | Unset): Business address postal code Example: 10001.
            business_address_country (str | Unset): Business address country code Example: USA.
            logo_url (str | Unset): URL to company logo Example: https://example.com/logo.png.
            email (str | Unset): Email address of the corporate member Example: contact@acme.com.
            phone_number (str | Unset): Phone number of the corporate member Example: +1-555-123-4567.
            ownership_percentage (float | Unset): Ownership percentage (0-100) Example: 25.5.
            sanctions_status (UpdateCorporateMemberDtoSanctionsStatus | Unset): Sanctions screening status Example: CLEAR.
            sanctions_status_date (str | Unset): Date of sanctions status determination Example: 2023-08-15T10:30:00Z.
            pep_status (UpdateCorporateMemberDtoPepStatus | Unset): PEP (Politically Exposed Person) status Example: CLEAR.
            pep_status_date (str | Unset): Date of PEP status determination Example: 2023-08-15T10:30:00Z.
            adverse_media_status (UpdateCorporateMemberDtoAdverseMediaStatus | Unset): Adverse media screening status
                Example: CLEAR.
            adverse_media_status_date (str | Unset): Date of adverse media status determination Example:
                2023-08-15T10:30:00Z.
            status (UpdateCorporateMemberDtoStatus | Unset): Overall member status Example: APPROVED.
            status_date (str | Unset): Date of status determination Example: 2023-08-15T10:30:00Z.
            title (str | Unset): Member's title or position Example: Subsidiary Company.
            role_type (UpdateCorporateMemberDtoRoleType | Unset): Categorized role type Example: SHAREHOLDER.
            corporates (list[str] | Unset): List of corporate client IDs this member is associated with Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
     """

    reference_id: str | Unset = UNSET
    legal_entity_name: str | Unset = UNSET
    country_of_incorporation: str | Unset = UNSET
    registration_number: str | Unset = UNSET
    date_of_incorporation: str | Unset = UNSET
    business_address_line_1: str | Unset = UNSET
    business_address_line_2: str | Unset = UNSET
    business_address_city: str | Unset = UNSET
    business_address_postal_code: str | Unset = UNSET
    business_address_country: str | Unset = UNSET
    logo_url: str | Unset = UNSET
    email: str | Unset = UNSET
    phone_number: str | Unset = UNSET
    ownership_percentage: float | Unset = UNSET
    sanctions_status: UpdateCorporateMemberDtoSanctionsStatus | Unset = UNSET
    sanctions_status_date: str | Unset = UNSET
    pep_status: UpdateCorporateMemberDtoPepStatus | Unset = UNSET
    pep_status_date: str | Unset = UNSET
    adverse_media_status: UpdateCorporateMemberDtoAdverseMediaStatus | Unset = UNSET
    adverse_media_status_date: str | Unset = UNSET
    status: UpdateCorporateMemberDtoStatus | Unset = UNSET
    status_date: str | Unset = UNSET
    title: str | Unset = UNSET
    role_type: UpdateCorporateMemberDtoRoleType | Unset = UNSET
    corporates: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        reference_id = self.reference_id

        legal_entity_name = self.legal_entity_name

        country_of_incorporation = self.country_of_incorporation

        registration_number = self.registration_number

        date_of_incorporation = self.date_of_incorporation

        business_address_line_1 = self.business_address_line_1

        business_address_line_2 = self.business_address_line_2

        business_address_city = self.business_address_city

        business_address_postal_code = self.business_address_postal_code

        business_address_country = self.business_address_country

        logo_url = self.logo_url

        email = self.email

        phone_number = self.phone_number

        ownership_percentage = self.ownership_percentage

        sanctions_status: str | Unset = UNSET
        if not isinstance(self.sanctions_status, Unset):
            sanctions_status = self.sanctions_status.value


        sanctions_status_date = self.sanctions_status_date

        pep_status: str | Unset = UNSET
        if not isinstance(self.pep_status, Unset):
            pep_status = self.pep_status.value


        pep_status_date = self.pep_status_date

        adverse_media_status: str | Unset = UNSET
        if not isinstance(self.adverse_media_status, Unset):
            adverse_media_status = self.adverse_media_status.value


        adverse_media_status_date = self.adverse_media_status_date

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        status_date = self.status_date

        title = self.title

        role_type: str | Unset = UNSET
        if not isinstance(self.role_type, Unset):
            role_type = self.role_type.value


        corporates: list[str] | Unset = UNSET
        if not isinstance(self.corporates, Unset):
            corporates = self.corporates




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if legal_entity_name is not UNSET:
            field_dict["legalEntityName"] = legal_entity_name
        if country_of_incorporation is not UNSET:
            field_dict["countryOfIncorporation"] = country_of_incorporation
        if registration_number is not UNSET:
            field_dict["registrationNumber"] = registration_number
        if date_of_incorporation is not UNSET:
            field_dict["dateOfIncorporation"] = date_of_incorporation
        if business_address_line_1 is not UNSET:
            field_dict["businessAddressLine1"] = business_address_line_1
        if business_address_line_2 is not UNSET:
            field_dict["businessAddressLine2"] = business_address_line_2
        if business_address_city is not UNSET:
            field_dict["businessAddressCity"] = business_address_city
        if business_address_postal_code is not UNSET:
            field_dict["businessAddressPostalCode"] = business_address_postal_code
        if business_address_country is not UNSET:
            field_dict["businessAddressCountry"] = business_address_country
        if logo_url is not UNSET:
            field_dict["logoUrl"] = logo_url
        if email is not UNSET:
            field_dict["email"] = email
        if phone_number is not UNSET:
            field_dict["phoneNumber"] = phone_number
        if ownership_percentage is not UNSET:
            field_dict["ownershipPercentage"] = ownership_percentage
        if sanctions_status is not UNSET:
            field_dict["sanctionsStatus"] = sanctions_status
        if sanctions_status_date is not UNSET:
            field_dict["sanctionsStatusDate"] = sanctions_status_date
        if pep_status is not UNSET:
            field_dict["pepStatus"] = pep_status
        if pep_status_date is not UNSET:
            field_dict["pepStatusDate"] = pep_status_date
        if adverse_media_status is not UNSET:
            field_dict["adverseMediaStatus"] = adverse_media_status
        if adverse_media_status_date is not UNSET:
            field_dict["adverseMediaStatusDate"] = adverse_media_status_date
        if status is not UNSET:
            field_dict["status"] = status
        if status_date is not UNSET:
            field_dict["statusDate"] = status_date
        if title is not UNSET:
            field_dict["title"] = title
        if role_type is not UNSET:
            field_dict["roleType"] = role_type
        if corporates is not UNSET:
            field_dict["corporates"] = corporates

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        reference_id = d.pop("referenceId", UNSET)

        legal_entity_name = d.pop("legalEntityName", UNSET)

        country_of_incorporation = d.pop("countryOfIncorporation", UNSET)

        registration_number = d.pop("registrationNumber", UNSET)

        date_of_incorporation = d.pop("dateOfIncorporation", UNSET)

        business_address_line_1 = d.pop("businessAddressLine1", UNSET)

        business_address_line_2 = d.pop("businessAddressLine2", UNSET)

        business_address_city = d.pop("businessAddressCity", UNSET)

        business_address_postal_code = d.pop("businessAddressPostalCode", UNSET)

        business_address_country = d.pop("businessAddressCountry", UNSET)

        logo_url = d.pop("logoUrl", UNSET)

        email = d.pop("email", UNSET)

        phone_number = d.pop("phoneNumber", UNSET)

        ownership_percentage = d.pop("ownershipPercentage", UNSET)

        _sanctions_status = d.pop("sanctionsStatus", UNSET)
        sanctions_status: UpdateCorporateMemberDtoSanctionsStatus | Unset
        if isinstance(_sanctions_status,  Unset):
            sanctions_status = UNSET
        else:
            sanctions_status = UpdateCorporateMemberDtoSanctionsStatus(_sanctions_status)




        sanctions_status_date = d.pop("sanctionsStatusDate", UNSET)

        _pep_status = d.pop("pepStatus", UNSET)
        pep_status: UpdateCorporateMemberDtoPepStatus | Unset
        if isinstance(_pep_status,  Unset):
            pep_status = UNSET
        else:
            pep_status = UpdateCorporateMemberDtoPepStatus(_pep_status)




        pep_status_date = d.pop("pepStatusDate", UNSET)

        _adverse_media_status = d.pop("adverseMediaStatus", UNSET)
        adverse_media_status: UpdateCorporateMemberDtoAdverseMediaStatus | Unset
        if isinstance(_adverse_media_status,  Unset):
            adverse_media_status = UNSET
        else:
            adverse_media_status = UpdateCorporateMemberDtoAdverseMediaStatus(_adverse_media_status)




        adverse_media_status_date = d.pop("adverseMediaStatusDate", UNSET)

        _status = d.pop("status", UNSET)
        status: UpdateCorporateMemberDtoStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = UpdateCorporateMemberDtoStatus(_status)




        status_date = d.pop("statusDate", UNSET)

        title = d.pop("title", UNSET)

        _role_type = d.pop("roleType", UNSET)
        role_type: UpdateCorporateMemberDtoRoleType | Unset
        if isinstance(_role_type,  Unset):
            role_type = UNSET
        else:
            role_type = UpdateCorporateMemberDtoRoleType(_role_type)




        corporates = cast(list[str], d.pop("corporates", UNSET))


        update_corporate_member_dto = cls(
            reference_id=reference_id,
            legal_entity_name=legal_entity_name,
            country_of_incorporation=country_of_incorporation,
            registration_number=registration_number,
            date_of_incorporation=date_of_incorporation,
            business_address_line_1=business_address_line_1,
            business_address_line_2=business_address_line_2,
            business_address_city=business_address_city,
            business_address_postal_code=business_address_postal_code,
            business_address_country=business_address_country,
            logo_url=logo_url,
            email=email,
            phone_number=phone_number,
            ownership_percentage=ownership_percentage,
            sanctions_status=sanctions_status,
            sanctions_status_date=sanctions_status_date,
            pep_status=pep_status,
            pep_status_date=pep_status_date,
            adverse_media_status=adverse_media_status,
            adverse_media_status_date=adverse_media_status_date,
            status=status,
            status_date=status_date,
            title=title,
            role_type=role_type,
            corporates=corporates,
        )


        update_corporate_member_dto.additional_properties = d
        return update_corporate_member_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
