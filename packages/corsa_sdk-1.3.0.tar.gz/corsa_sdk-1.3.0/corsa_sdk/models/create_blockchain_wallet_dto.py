from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.blockchain_wallet_integrations_dto import BlockchainWalletIntegrationsDto
  from ..models.client_blockchain_wallet_relation_dto import ClientBlockchainWalletRelationDto
  from ..models.create_blockchain_wallet_dto_custom_fields import CreateBlockchainWalletDtoCustomFields
  from ..models.risk_dto import RiskDto





T = TypeVar("T", bound="CreateBlockchainWalletDto")



@_attrs_define
class CreateBlockchainWalletDto:
    """ 
        Attributes:
            address (str): Wallet address on the blockchain Example: 0x742d35Cc6634C0532925a3b844Bc454e4438f44e.
            reference_id (str | Unset): External reference ID for the blockchain wallet Example: REF-WALLET-001.
            screening_date (str | Unset): Screening date of the blockchain wallet Example: 2024-01-15T10:30:00.000Z.
            chain (str | Unset): Blockchain network or chain identifier Example: ethereum.
            risk_history (list[RiskDto] | Unset): Historical risk assessments of the blockchain wallet
            custom_fields (CreateBlockchainWalletDtoCustomFields | Unset): Custom fields data
            associated_clients (list[ClientBlockchainWalletRelationDto] | Unset): List of clients associated with the
                blockchain wallet (maximum 50)
            integrations (BlockchainWalletIntegrationsDto | Unset):
     """

    address: str
    reference_id: str | Unset = UNSET
    screening_date: str | Unset = UNSET
    chain: str | Unset = UNSET
    risk_history: list[RiskDto] | Unset = UNSET
    custom_fields: CreateBlockchainWalletDtoCustomFields | Unset = UNSET
    associated_clients: list[ClientBlockchainWalletRelationDto] | Unset = UNSET
    integrations: BlockchainWalletIntegrationsDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.blockchain_wallet_integrations_dto import BlockchainWalletIntegrationsDto
        from ..models.client_blockchain_wallet_relation_dto import ClientBlockchainWalletRelationDto
        from ..models.create_blockchain_wallet_dto_custom_fields import CreateBlockchainWalletDtoCustomFields
        from ..models.risk_dto import RiskDto
        address = self.address

        reference_id = self.reference_id

        screening_date = self.screening_date

        chain = self.chain

        risk_history: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.risk_history, Unset):
            risk_history = []
            for risk_history_item_data in self.risk_history:
                risk_history_item = risk_history_item_data.to_dict()
                risk_history.append(risk_history_item)



        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        associated_clients: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.associated_clients, Unset):
            associated_clients = []
            for associated_clients_item_data in self.associated_clients:
                associated_clients_item = associated_clients_item_data.to_dict()
                associated_clients.append(associated_clients_item)



        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "address": address,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if screening_date is not UNSET:
            field_dict["screeningDate"] = screening_date
        if chain is not UNSET:
            field_dict["chain"] = chain
        if risk_history is not UNSET:
            field_dict["riskHistory"] = risk_history
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if associated_clients is not UNSET:
            field_dict["associatedClients"] = associated_clients
        if integrations is not UNSET:
            field_dict["integrations"] = integrations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.blockchain_wallet_integrations_dto import BlockchainWalletIntegrationsDto
        from ..models.client_blockchain_wallet_relation_dto import ClientBlockchainWalletRelationDto
        from ..models.create_blockchain_wallet_dto_custom_fields import CreateBlockchainWalletDtoCustomFields
        from ..models.risk_dto import RiskDto
        d = dict(src_dict)
        address = d.pop("address")

        reference_id = d.pop("referenceId", UNSET)

        screening_date = d.pop("screeningDate", UNSET)

        chain = d.pop("chain", UNSET)

        _risk_history = d.pop("riskHistory", UNSET)
        risk_history: list[RiskDto] | Unset = UNSET
        if _risk_history is not UNSET:
            risk_history = []
            for risk_history_item_data in _risk_history:
                risk_history_item = RiskDto.from_dict(risk_history_item_data)



                risk_history.append(risk_history_item)


        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: CreateBlockchainWalletDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = CreateBlockchainWalletDtoCustomFields.from_dict(_custom_fields)




        _associated_clients = d.pop("associatedClients", UNSET)
        associated_clients: list[ClientBlockchainWalletRelationDto] | Unset = UNSET
        if _associated_clients is not UNSET:
            associated_clients = []
            for associated_clients_item_data in _associated_clients:
                associated_clients_item = ClientBlockchainWalletRelationDto.from_dict(associated_clients_item_data)



                associated_clients.append(associated_clients_item)


        _integrations = d.pop("integrations", UNSET)
        integrations: BlockchainWalletIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = BlockchainWalletIntegrationsDto.from_dict(_integrations)




        create_blockchain_wallet_dto = cls(
            address=address,
            reference_id=reference_id,
            screening_date=screening_date,
            chain=chain,
            risk_history=risk_history,
            custom_fields=custom_fields,
            associated_clients=associated_clients,
            integrations=integrations,
        )


        create_blockchain_wallet_dto.additional_properties = d
        return create_blockchain_wallet_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
