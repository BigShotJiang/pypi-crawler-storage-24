from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="SanctionsListEntryDto")



@_attrs_define
class SanctionsListEntryDto:
    """ 
        Attributes:
            list_name (str): Name of the sanctions list Example: OFAC SDN.
            listing_date (str | Unset): Date when the entity was listed (ISO format) Example: 2024-01-15.
            reason (str | Unset): Reason for the sanctions listing Example: Terrorism financing.
     """

    list_name: str
    listing_date: str | Unset = UNSET
    reason: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        list_name = self.list_name

        listing_date = self.listing_date

        reason = self.reason


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "listName": list_name,
        })
        if listing_date is not UNSET:
            field_dict["listingDate"] = listing_date
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        list_name = d.pop("listName")

        listing_date = d.pop("listingDate", UNSET)

        reason = d.pop("reason", UNSET)

        sanctions_list_entry_dto = cls(
            list_name=list_name,
            listing_date=listing_date,
            reason=reason,
        )


        sanctions_list_entry_dto.additional_properties = d
        return sanctions_list_entry_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
