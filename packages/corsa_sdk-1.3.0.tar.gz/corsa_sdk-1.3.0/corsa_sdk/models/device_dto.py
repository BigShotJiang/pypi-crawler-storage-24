from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.device_dto_device_type import DeviceDtoDeviceType
from ..types import UNSET, Unset






T = TypeVar("T", bound="DeviceDto")



@_attrs_define
class DeviceDto:
    """ 
        Attributes:
            fingerprint (str): Unique device fingerprint hash Example: a1b2c3d4e5f6g7h8i9j0.
            user_agent (str | Unset): Full user agent string Example: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)
                AppleWebKit/537.36.
            browser (str | Unset): Browser name Example: Chrome.
            browser_version (str | Unset): Browser version Example: 120.0.6099.109.
            os (str | Unset): Operating system name Example: macOS.
            os_version (str | Unset): Operating system version Example: 14.2.1.
            device_type (DeviceDtoDeviceType | Unset): Type of device Example: DESKTOP.
            screen_resolution (str | Unset): Screen resolution Example: 1920x1080.
            language (str | Unset): Browser language Example: en-US.
            timezone (str | Unset): Timezone of the device Example: America/New_York.
     """

    fingerprint: str
    user_agent: str | Unset = UNSET
    browser: str | Unset = UNSET
    browser_version: str | Unset = UNSET
    os: str | Unset = UNSET
    os_version: str | Unset = UNSET
    device_type: DeviceDtoDeviceType | Unset = UNSET
    screen_resolution: str | Unset = UNSET
    language: str | Unset = UNSET
    timezone: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        fingerprint = self.fingerprint

        user_agent = self.user_agent

        browser = self.browser

        browser_version = self.browser_version

        os = self.os

        os_version = self.os_version

        device_type: str | Unset = UNSET
        if not isinstance(self.device_type, Unset):
            device_type = self.device_type.value


        screen_resolution = self.screen_resolution

        language = self.language

        timezone = self.timezone


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "fingerprint": fingerprint,
        })
        if user_agent is not UNSET:
            field_dict["userAgent"] = user_agent
        if browser is not UNSET:
            field_dict["browser"] = browser
        if browser_version is not UNSET:
            field_dict["browserVersion"] = browser_version
        if os is not UNSET:
            field_dict["os"] = os
        if os_version is not UNSET:
            field_dict["osVersion"] = os_version
        if device_type is not UNSET:
            field_dict["deviceType"] = device_type
        if screen_resolution is not UNSET:
            field_dict["screenResolution"] = screen_resolution
        if language is not UNSET:
            field_dict["language"] = language
        if timezone is not UNSET:
            field_dict["timezone"] = timezone

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        fingerprint = d.pop("fingerprint")

        user_agent = d.pop("userAgent", UNSET)

        browser = d.pop("browser", UNSET)

        browser_version = d.pop("browserVersion", UNSET)

        os = d.pop("os", UNSET)

        os_version = d.pop("osVersion", UNSET)

        _device_type = d.pop("deviceType", UNSET)
        device_type: DeviceDtoDeviceType | Unset
        if isinstance(_device_type,  Unset):
            device_type = UNSET
        else:
            device_type = DeviceDtoDeviceType(_device_type)




        screen_resolution = d.pop("screenResolution", UNSET)

        language = d.pop("language", UNSET)

        timezone = d.pop("timezone", UNSET)

        device_dto = cls(
            fingerprint=fingerprint,
            user_agent=user_agent,
            browser=browser,
            browser_version=browser_version,
            os=os,
            os_version=os_version,
            device_type=device_type,
            screen_resolution=screen_resolution,
            language=language,
            timezone=timezone,
        )


        device_dto.additional_properties = d
        return device_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
