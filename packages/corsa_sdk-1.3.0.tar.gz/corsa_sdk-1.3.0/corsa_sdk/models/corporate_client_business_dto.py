from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.corporate_client_business_dto_business_sub_type import CorporateClientBusinessDtoBusinessSubType
from ..models.corporate_client_business_dto_business_type import CorporateClientBusinessDtoBusinessType
from ..models.corporate_client_business_dto_incorporation_type import CorporateClientBusinessDtoIncorporationType
from ..models.corporate_client_business_dto_ownership_complexity import CorporateClientBusinessDtoOwnershipComplexity
from ..models.corporate_client_business_dto_ownership_type import CorporateClientBusinessDtoOwnershipType
from ..types import UNSET, Unset






T = TypeVar("T", bound="CorporateClientBusinessDto")



@_attrs_define
class CorporateClientBusinessDto:
    """ 
        Attributes:
            industry (str | Unset): Primary industry sector of the business Example: Technology.
            description (str | Unset): Description of the business Example: A technology company.
            business_type (CorporateClientBusinessDtoBusinessType | Unset): Type of business Example: BLOCKCHAIN_NATIVE.
            business_sub_type (CorporateClientBusinessDtoBusinessSubType | Unset): Sub-type of business Example:
                TOKEN_PROJECT.
            ownership_type (CorporateClientBusinessDtoOwnershipType | Unset): Ownership type of the business Example:
                PRIVATELY_HELD.
            ownership_complexity (CorporateClientBusinessDtoOwnershipComplexity | Unset): Complexity of the ownership
                structure Example: SIMPLE_OWNERSHIP.
            incorporation_type (CorporateClientBusinessDtoIncorporationType | Unset): Type of incorporation Example:
                CORPORATION.
     """

    industry: str | Unset = UNSET
    description: str | Unset = UNSET
    business_type: CorporateClientBusinessDtoBusinessType | Unset = UNSET
    business_sub_type: CorporateClientBusinessDtoBusinessSubType | Unset = UNSET
    ownership_type: CorporateClientBusinessDtoOwnershipType | Unset = UNSET
    ownership_complexity: CorporateClientBusinessDtoOwnershipComplexity | Unset = UNSET
    incorporation_type: CorporateClientBusinessDtoIncorporationType | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        industry = self.industry

        description = self.description

        business_type: str | Unset = UNSET
        if not isinstance(self.business_type, Unset):
            business_type = self.business_type.value


        business_sub_type: str | Unset = UNSET
        if not isinstance(self.business_sub_type, Unset):
            business_sub_type = self.business_sub_type.value


        ownership_type: str | Unset = UNSET
        if not isinstance(self.ownership_type, Unset):
            ownership_type = self.ownership_type.value


        ownership_complexity: str | Unset = UNSET
        if not isinstance(self.ownership_complexity, Unset):
            ownership_complexity = self.ownership_complexity.value


        incorporation_type: str | Unset = UNSET
        if not isinstance(self.incorporation_type, Unset):
            incorporation_type = self.incorporation_type.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if industry is not UNSET:
            field_dict["industry"] = industry
        if description is not UNSET:
            field_dict["description"] = description
        if business_type is not UNSET:
            field_dict["businessType"] = business_type
        if business_sub_type is not UNSET:
            field_dict["businessSubType"] = business_sub_type
        if ownership_type is not UNSET:
            field_dict["ownershipType"] = ownership_type
        if ownership_complexity is not UNSET:
            field_dict["ownershipComplexity"] = ownership_complexity
        if incorporation_type is not UNSET:
            field_dict["incorporationType"] = incorporation_type

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        industry = d.pop("industry", UNSET)

        description = d.pop("description", UNSET)

        _business_type = d.pop("businessType", UNSET)
        business_type: CorporateClientBusinessDtoBusinessType | Unset
        if isinstance(_business_type,  Unset):
            business_type = UNSET
        else:
            business_type = CorporateClientBusinessDtoBusinessType(_business_type)




        _business_sub_type = d.pop("businessSubType", UNSET)
        business_sub_type: CorporateClientBusinessDtoBusinessSubType | Unset
        if isinstance(_business_sub_type,  Unset):
            business_sub_type = UNSET
        else:
            business_sub_type = CorporateClientBusinessDtoBusinessSubType(_business_sub_type)




        _ownership_type = d.pop("ownershipType", UNSET)
        ownership_type: CorporateClientBusinessDtoOwnershipType | Unset
        if isinstance(_ownership_type,  Unset):
            ownership_type = UNSET
        else:
            ownership_type = CorporateClientBusinessDtoOwnershipType(_ownership_type)




        _ownership_complexity = d.pop("ownershipComplexity", UNSET)
        ownership_complexity: CorporateClientBusinessDtoOwnershipComplexity | Unset
        if isinstance(_ownership_complexity,  Unset):
            ownership_complexity = UNSET
        else:
            ownership_complexity = CorporateClientBusinessDtoOwnershipComplexity(_ownership_complexity)




        _incorporation_type = d.pop("incorporationType", UNSET)
        incorporation_type: CorporateClientBusinessDtoIncorporationType | Unset
        if isinstance(_incorporation_type,  Unset):
            incorporation_type = UNSET
        else:
            incorporation_type = CorporateClientBusinessDtoIncorporationType(_incorporation_type)




        corporate_client_business_dto = cls(
            industry=industry,
            description=description,
            business_type=business_type,
            business_sub_type=business_sub_type,
            ownership_type=ownership_type,
            ownership_complexity=ownership_complexity,
            incorporation_type=incorporation_type,
        )


        corporate_client_business_dto.additional_properties = d
        return corporate_client_business_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
