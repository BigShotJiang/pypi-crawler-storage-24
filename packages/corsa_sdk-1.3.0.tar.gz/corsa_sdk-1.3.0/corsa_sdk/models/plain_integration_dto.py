from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="PlainIntegrationDto")



@_attrs_define
class PlainIntegrationDto:
    """ 
        Attributes:
            customer_id (str | Unset): Plain customer ID Example: c_01HXYZ123ABC.
            threads_imported_at (str | Unset): ISO timestamp when Plain threads were imported Example: 2024-01-15T10:30:00Z.
     """

    customer_id: str | Unset = UNSET
    threads_imported_at: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        customer_id = self.customer_id

        threads_imported_at = self.threads_imported_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if customer_id is not UNSET:
            field_dict["customerId"] = customer_id
        if threads_imported_at is not UNSET:
            field_dict["threadsImportedAt"] = threads_imported_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        customer_id = d.pop("customerId", UNSET)

        threads_imported_at = d.pop("threadsImportedAt", UNSET)

        plain_integration_dto = cls(
            customer_id=customer_id,
            threads_imported_at=threads_imported_at,
        )


        plain_integration_dto.additional_properties = d
        return plain_integration_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
