from enum import Enum

class UpdateAttachmentDtoSource(str, Enum):
    CHECKLIST = "CHECKLIST"
    DISCUSSION = "DISCUSSION"
    DOCUMENT_REPOSITORY = "DOCUMENT_REPOSITORY"
    EXTERNAL = "EXTERNAL"
    ISSUE_DECISION = "ISSUE_DECISION"

    def __str__(self) -> str:
        return str(self.value)
