from enum import Enum

class ConditionDtoAggregationOperator(str, Enum):
    AVG = "avg"
    COUNT = "count"
    COUNTDISTINCT = "countDistinct"
    FIRST = "first"
    LAST = "last"
    MAX = "max"
    MEDIAN = "median"
    MIN = "min"
    PERCENTILE = "percentile"
    STDDEV = "stddev"
    SUM = "sum"

    def __str__(self) -> str:
        return str(self.value)
