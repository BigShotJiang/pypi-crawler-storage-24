from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.evaluation_result_dto_decision import EvaluationResultDtoDecision
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.rule_match_dto import RuleMatchDto





T = TypeVar("T", bound="EvaluationResultDto")



@_attrs_define
class EvaluationResultDto:
    """ 
        Attributes:
            decision (EvaluationResultDtoDecision): Final decision: FREEZE if any rule would freeze, otherwise ALLOW
            triggered_rule_ids (list[str]): List of triggered rule IDs
            matches (list[RuleMatchDto]):
            evaluated_at (datetime.datetime):
            latency_ms (float):
            transaction_id (str | Unset): Transaction ID if provided, undefined for anonymous evaluations
     """

    decision: EvaluationResultDtoDecision
    triggered_rule_ids: list[str]
    matches: list[RuleMatchDto]
    evaluated_at: datetime.datetime
    latency_ms: float
    transaction_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rule_match_dto import RuleMatchDto
        decision = self.decision.value

        triggered_rule_ids = self.triggered_rule_ids



        matches = []
        for matches_item_data in self.matches:
            matches_item = matches_item_data.to_dict()
            matches.append(matches_item)



        evaluated_at = self.evaluated_at.isoformat()

        latency_ms = self.latency_ms

        transaction_id = self.transaction_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "decision": decision,
            "triggeredRuleIds": triggered_rule_ids,
            "matches": matches,
            "evaluatedAt": evaluated_at,
            "latencyMs": latency_ms,
        })
        if transaction_id is not UNSET:
            field_dict["transactionId"] = transaction_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rule_match_dto import RuleMatchDto
        d = dict(src_dict)
        decision = EvaluationResultDtoDecision(d.pop("decision"))




        triggered_rule_ids = cast(list[str], d.pop("triggeredRuleIds"))


        matches = []
        _matches = d.pop("matches")
        for matches_item_data in (_matches):
            matches_item = RuleMatchDto.from_dict(matches_item_data)



            matches.append(matches_item)


        evaluated_at = isoparse(d.pop("evaluatedAt"))




        latency_ms = d.pop("latencyMs")

        transaction_id = d.pop("transactionId", UNSET)

        evaluation_result_dto = cls(
            decision=decision,
            triggered_rule_ids=triggered_rule_ids,
            matches=matches,
            evaluated_at=evaluated_at,
            latency_ms=latency_ms,
            transaction_id=transaction_id,
        )


        evaluation_result_dto.additional_properties = d
        return evaluation_result_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
