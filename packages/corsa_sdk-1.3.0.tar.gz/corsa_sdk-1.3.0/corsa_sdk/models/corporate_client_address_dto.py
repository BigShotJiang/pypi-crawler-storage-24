from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.corporate_client_address_line_dto import CorporateClientAddressLineDto





T = TypeVar("T", bound="CorporateClientAddressDto")



@_attrs_define
class CorporateClientAddressDto:
    """ 
        Attributes:
            registration_address (CorporateClientAddressLineDto | Unset):
            business_address (CorporateClientAddressLineDto | Unset):
     """

    registration_address: CorporateClientAddressLineDto | Unset = UNSET
    business_address: CorporateClientAddressLineDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.corporate_client_address_line_dto import CorporateClientAddressLineDto
        registration_address: dict[str, Any] | Unset = UNSET
        if not isinstance(self.registration_address, Unset):
            registration_address = self.registration_address.to_dict()

        business_address: dict[str, Any] | Unset = UNSET
        if not isinstance(self.business_address, Unset):
            business_address = self.business_address.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if registration_address is not UNSET:
            field_dict["registrationAddress"] = registration_address
        if business_address is not UNSET:
            field_dict["businessAddress"] = business_address

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.corporate_client_address_line_dto import CorporateClientAddressLineDto
        d = dict(src_dict)
        _registration_address = d.pop("registrationAddress", UNSET)
        registration_address: CorporateClientAddressLineDto | Unset
        if isinstance(_registration_address,  Unset):
            registration_address = UNSET
        else:
            registration_address = CorporateClientAddressLineDto.from_dict(_registration_address)




        _business_address = d.pop("businessAddress", UNSET)
        business_address: CorporateClientAddressLineDto | Unset
        if isinstance(_business_address,  Unset):
            business_address = UNSET
        else:
            business_address = CorporateClientAddressLineDto.from_dict(_business_address)




        corporate_client_address_dto = cls(
            registration_address=registration_address,
            business_address=business_address,
        )


        corporate_client_address_dto.additional_properties = d
        return corporate_client_address_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
