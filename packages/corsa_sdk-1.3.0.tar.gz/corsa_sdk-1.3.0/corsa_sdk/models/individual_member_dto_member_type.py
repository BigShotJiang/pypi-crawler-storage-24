from enum import Enum

class IndividualMemberDtoMemberType(str, Enum):
    CORPORATE = "CORPORATE"
    INDIVIDUAL = "INDIVIDUAL"

    def __str__(self) -> str:
        return str(self.value)
