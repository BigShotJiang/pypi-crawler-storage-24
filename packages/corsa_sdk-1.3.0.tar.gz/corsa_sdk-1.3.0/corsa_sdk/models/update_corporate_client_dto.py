from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_corporate_client_dto_account_status import UpdateCorporateClientDtoAccountStatus
from ..models.update_corporate_client_dto_activity_status import UpdateCorporateClientDtoActivityStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.corporate_client_address_dto import CorporateClientAddressDto
  from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
  from ..models.corporate_client_application_dto import CorporateClientApplicationDto
  from ..models.corporate_client_business_dto import CorporateClientBusinessDto
  from ..models.corporate_client_contact_dto import CorporateClientContactDto
  from ..models.corporate_client_general_dto import CorporateClientGeneralDto
  from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
  from ..models.corporate_client_pep_dto import CorporateClientPEPDto
  from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
  from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
  from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
  from ..models.create_or_update_risk_dto import CreateOrUpdateRiskDto
  from ..models.update_corporate_client_dto_custom_fields import UpdateCorporateClientDtoCustomFields





T = TypeVar("T", bound="UpdateCorporateClientDto")



@_attrs_define
class UpdateCorporateClientDto:
    """ 
        Attributes:
            activity_status (UpdateCorporateClientDtoActivityStatus | Unset): Activity status of the corporate client
            account_status (UpdateCorporateClientDtoAccountStatus | Unset): Account status of the corporate client
            general (CorporateClientGeneralDto | Unset):
            contact (CorporateClientContactDto | Unset):
            current_risk (CreateOrUpdateRiskDto | Unset):
            onboarding_risk (CreateOrUpdateRiskDto | Unset):
            address (CorporateClientAddressDto | Unset):
            business (CorporateClientBusinessDto | Unset):
            application (CorporateClientApplicationDto | Unset):
            source_of_funds_info (CorporateClientSourceOfFundsDto | Unset):
            adverse_media (CorporateClientAdverseMediaDto | Unset):
            political_exposure (CorporateClientPEPDto | Unset):
            sanctions (CorporateClientSanctionsDto | Unset):
            screening (CorporateClientScreeningDto | Unset):
            custom_fields (UpdateCorporateClientDtoCustomFields | Unset): Custom fields data
            tags_to_add (list[str] | Unset): Tags to add to the corporate client (maximum 50)
            tags_to_remove (list[str] | Unset): Tags to remove from the corporate client (maximum 50)
            declared_assets (list[str] | Unset): Array of asset symbols the client is expected to trade with (maximum 50).
                This will replace the existing declaredAssets. Example: ['BTC', 'ETH', 'USDT'].
            controls_to_add (list[str] | Unset): Controls to add to the corporate client (maximum 50)
            controls_to_remove (list[str] | Unset): Controls to remove from the corporate client (maximum 50)
            integrations (CorporateClientIntegrationsDto | Unset):
            partner_client_id (None | str | Unset): ID or referenceId of the partner corporate client. Set to null to remove
                the partner. Example: 123e4567-e89b-12d3-a456-426614174000.
     """

    activity_status: UpdateCorporateClientDtoActivityStatus | Unset = UNSET
    account_status: UpdateCorporateClientDtoAccountStatus | Unset = UNSET
    general: CorporateClientGeneralDto | Unset = UNSET
    contact: CorporateClientContactDto | Unset = UNSET
    current_risk: CreateOrUpdateRiskDto | Unset = UNSET
    onboarding_risk: CreateOrUpdateRiskDto | Unset = UNSET
    address: CorporateClientAddressDto | Unset = UNSET
    business: CorporateClientBusinessDto | Unset = UNSET
    application: CorporateClientApplicationDto | Unset = UNSET
    source_of_funds_info: CorporateClientSourceOfFundsDto | Unset = UNSET
    adverse_media: CorporateClientAdverseMediaDto | Unset = UNSET
    political_exposure: CorporateClientPEPDto | Unset = UNSET
    sanctions: CorporateClientSanctionsDto | Unset = UNSET
    screening: CorporateClientScreeningDto | Unset = UNSET
    custom_fields: UpdateCorporateClientDtoCustomFields | Unset = UNSET
    tags_to_add: list[str] | Unset = UNSET
    tags_to_remove: list[str] | Unset = UNSET
    declared_assets: list[str] | Unset = UNSET
    controls_to_add: list[str] | Unset = UNSET
    controls_to_remove: list[str] | Unset = UNSET
    integrations: CorporateClientIntegrationsDto | Unset = UNSET
    partner_client_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.corporate_client_address_dto import CorporateClientAddressDto
        from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
        from ..models.corporate_client_application_dto import CorporateClientApplicationDto
        from ..models.corporate_client_business_dto import CorporateClientBusinessDto
        from ..models.corporate_client_contact_dto import CorporateClientContactDto
        from ..models.corporate_client_general_dto import CorporateClientGeneralDto
        from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
        from ..models.corporate_client_pep_dto import CorporateClientPEPDto
        from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
        from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
        from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
        from ..models.create_or_update_risk_dto import CreateOrUpdateRiskDto
        from ..models.update_corporate_client_dto_custom_fields import UpdateCorporateClientDtoCustomFields
        activity_status: str | Unset = UNSET
        if not isinstance(self.activity_status, Unset):
            activity_status = self.activity_status.value


        account_status: str | Unset = UNSET
        if not isinstance(self.account_status, Unset):
            account_status = self.account_status.value


        general: dict[str, Any] | Unset = UNSET
        if not isinstance(self.general, Unset):
            general = self.general.to_dict()

        contact: dict[str, Any] | Unset = UNSET
        if not isinstance(self.contact, Unset):
            contact = self.contact.to_dict()

        current_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.current_risk, Unset):
            current_risk = self.current_risk.to_dict()

        onboarding_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.onboarding_risk, Unset):
            onboarding_risk = self.onboarding_risk.to_dict()

        address: dict[str, Any] | Unset = UNSET
        if not isinstance(self.address, Unset):
            address = self.address.to_dict()

        business: dict[str, Any] | Unset = UNSET
        if not isinstance(self.business, Unset):
            business = self.business.to_dict()

        application: dict[str, Any] | Unset = UNSET
        if not isinstance(self.application, Unset):
            application = self.application.to_dict()

        source_of_funds_info: dict[str, Any] | Unset = UNSET
        if not isinstance(self.source_of_funds_info, Unset):
            source_of_funds_info = self.source_of_funds_info.to_dict()

        adverse_media: dict[str, Any] | Unset = UNSET
        if not isinstance(self.adverse_media, Unset):
            adverse_media = self.adverse_media.to_dict()

        political_exposure: dict[str, Any] | Unset = UNSET
        if not isinstance(self.political_exposure, Unset):
            political_exposure = self.political_exposure.to_dict()

        sanctions: dict[str, Any] | Unset = UNSET
        if not isinstance(self.sanctions, Unset):
            sanctions = self.sanctions.to_dict()

        screening: dict[str, Any] | Unset = UNSET
        if not isinstance(self.screening, Unset):
            screening = self.screening.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        tags_to_add: list[str] | Unset = UNSET
        if not isinstance(self.tags_to_add, Unset):
            tags_to_add = self.tags_to_add



        tags_to_remove: list[str] | Unset = UNSET
        if not isinstance(self.tags_to_remove, Unset):
            tags_to_remove = self.tags_to_remove



        declared_assets: list[str] | Unset = UNSET
        if not isinstance(self.declared_assets, Unset):
            declared_assets = self.declared_assets



        controls_to_add: list[str] | Unset = UNSET
        if not isinstance(self.controls_to_add, Unset):
            controls_to_add = self.controls_to_add



        controls_to_remove: list[str] | Unset = UNSET
        if not isinstance(self.controls_to_remove, Unset):
            controls_to_remove = self.controls_to_remove



        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()

        partner_client_id: None | str | Unset
        if isinstance(self.partner_client_id, Unset):
            partner_client_id = UNSET
        else:
            partner_client_id = self.partner_client_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if activity_status is not UNSET:
            field_dict["activityStatus"] = activity_status
        if account_status is not UNSET:
            field_dict["accountStatus"] = account_status
        if general is not UNSET:
            field_dict["general"] = general
        if contact is not UNSET:
            field_dict["contact"] = contact
        if current_risk is not UNSET:
            field_dict["currentRisk"] = current_risk
        if onboarding_risk is not UNSET:
            field_dict["onboardingRisk"] = onboarding_risk
        if address is not UNSET:
            field_dict["address"] = address
        if business is not UNSET:
            field_dict["business"] = business
        if application is not UNSET:
            field_dict["application"] = application
        if source_of_funds_info is not UNSET:
            field_dict["sourceOfFundsInfo"] = source_of_funds_info
        if adverse_media is not UNSET:
            field_dict["adverseMedia"] = adverse_media
        if political_exposure is not UNSET:
            field_dict["politicalExposure"] = political_exposure
        if sanctions is not UNSET:
            field_dict["sanctions"] = sanctions
        if screening is not UNSET:
            field_dict["screening"] = screening
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if tags_to_add is not UNSET:
            field_dict["tagsToAdd"] = tags_to_add
        if tags_to_remove is not UNSET:
            field_dict["tagsToRemove"] = tags_to_remove
        if declared_assets is not UNSET:
            field_dict["declaredAssets"] = declared_assets
        if controls_to_add is not UNSET:
            field_dict["controlsToAdd"] = controls_to_add
        if controls_to_remove is not UNSET:
            field_dict["controlsToRemove"] = controls_to_remove
        if integrations is not UNSET:
            field_dict["integrations"] = integrations
        if partner_client_id is not UNSET:
            field_dict["partnerClientId"] = partner_client_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.corporate_client_address_dto import CorporateClientAddressDto
        from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
        from ..models.corporate_client_application_dto import CorporateClientApplicationDto
        from ..models.corporate_client_business_dto import CorporateClientBusinessDto
        from ..models.corporate_client_contact_dto import CorporateClientContactDto
        from ..models.corporate_client_general_dto import CorporateClientGeneralDto
        from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
        from ..models.corporate_client_pep_dto import CorporateClientPEPDto
        from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
        from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
        from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
        from ..models.create_or_update_risk_dto import CreateOrUpdateRiskDto
        from ..models.update_corporate_client_dto_custom_fields import UpdateCorporateClientDtoCustomFields
        d = dict(src_dict)
        _activity_status = d.pop("activityStatus", UNSET)
        activity_status: UpdateCorporateClientDtoActivityStatus | Unset
        if isinstance(_activity_status,  Unset):
            activity_status = UNSET
        else:
            activity_status = UpdateCorporateClientDtoActivityStatus(_activity_status)




        _account_status = d.pop("accountStatus", UNSET)
        account_status: UpdateCorporateClientDtoAccountStatus | Unset
        if isinstance(_account_status,  Unset):
            account_status = UNSET
        else:
            account_status = UpdateCorporateClientDtoAccountStatus(_account_status)




        _general = d.pop("general", UNSET)
        general: CorporateClientGeneralDto | Unset
        if isinstance(_general,  Unset):
            general = UNSET
        else:
            general = CorporateClientGeneralDto.from_dict(_general)




        _contact = d.pop("contact", UNSET)
        contact: CorporateClientContactDto | Unset
        if isinstance(_contact,  Unset):
            contact = UNSET
        else:
            contact = CorporateClientContactDto.from_dict(_contact)




        _current_risk = d.pop("currentRisk", UNSET)
        current_risk: CreateOrUpdateRiskDto | Unset
        if isinstance(_current_risk,  Unset):
            current_risk = UNSET
        else:
            current_risk = CreateOrUpdateRiskDto.from_dict(_current_risk)




        _onboarding_risk = d.pop("onboardingRisk", UNSET)
        onboarding_risk: CreateOrUpdateRiskDto | Unset
        if isinstance(_onboarding_risk,  Unset):
            onboarding_risk = UNSET
        else:
            onboarding_risk = CreateOrUpdateRiskDto.from_dict(_onboarding_risk)




        _address = d.pop("address", UNSET)
        address: CorporateClientAddressDto | Unset
        if isinstance(_address,  Unset):
            address = UNSET
        else:
            address = CorporateClientAddressDto.from_dict(_address)




        _business = d.pop("business", UNSET)
        business: CorporateClientBusinessDto | Unset
        if isinstance(_business,  Unset):
            business = UNSET
        else:
            business = CorporateClientBusinessDto.from_dict(_business)




        _application = d.pop("application", UNSET)
        application: CorporateClientApplicationDto | Unset
        if isinstance(_application,  Unset):
            application = UNSET
        else:
            application = CorporateClientApplicationDto.from_dict(_application)




        _source_of_funds_info = d.pop("sourceOfFundsInfo", UNSET)
        source_of_funds_info: CorporateClientSourceOfFundsDto | Unset
        if isinstance(_source_of_funds_info,  Unset):
            source_of_funds_info = UNSET
        else:
            source_of_funds_info = CorporateClientSourceOfFundsDto.from_dict(_source_of_funds_info)




        _adverse_media = d.pop("adverseMedia", UNSET)
        adverse_media: CorporateClientAdverseMediaDto | Unset
        if isinstance(_adverse_media,  Unset):
            adverse_media = UNSET
        else:
            adverse_media = CorporateClientAdverseMediaDto.from_dict(_adverse_media)




        _political_exposure = d.pop("politicalExposure", UNSET)
        political_exposure: CorporateClientPEPDto | Unset
        if isinstance(_political_exposure,  Unset):
            political_exposure = UNSET
        else:
            political_exposure = CorporateClientPEPDto.from_dict(_political_exposure)




        _sanctions = d.pop("sanctions", UNSET)
        sanctions: CorporateClientSanctionsDto | Unset
        if isinstance(_sanctions,  Unset):
            sanctions = UNSET
        else:
            sanctions = CorporateClientSanctionsDto.from_dict(_sanctions)




        _screening = d.pop("screening", UNSET)
        screening: CorporateClientScreeningDto | Unset
        if isinstance(_screening,  Unset):
            screening = UNSET
        else:
            screening = CorporateClientScreeningDto.from_dict(_screening)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: UpdateCorporateClientDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = UpdateCorporateClientDtoCustomFields.from_dict(_custom_fields)




        tags_to_add = cast(list[str], d.pop("tagsToAdd", UNSET))


        tags_to_remove = cast(list[str], d.pop("tagsToRemove", UNSET))


        declared_assets = cast(list[str], d.pop("declaredAssets", UNSET))


        controls_to_add = cast(list[str], d.pop("controlsToAdd", UNSET))


        controls_to_remove = cast(list[str], d.pop("controlsToRemove", UNSET))


        _integrations = d.pop("integrations", UNSET)
        integrations: CorporateClientIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = CorporateClientIntegrationsDto.from_dict(_integrations)




        def _parse_partner_client_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        partner_client_id = _parse_partner_client_id(d.pop("partnerClientId", UNSET))


        update_corporate_client_dto = cls(
            activity_status=activity_status,
            account_status=account_status,
            general=general,
            contact=contact,
            current_risk=current_risk,
            onboarding_risk=onboarding_risk,
            address=address,
            business=business,
            application=application,
            source_of_funds_info=source_of_funds_info,
            adverse_media=adverse_media,
            political_exposure=political_exposure,
            sanctions=sanctions,
            screening=screening,
            custom_fields=custom_fields,
            tags_to_add=tags_to_add,
            tags_to_remove=tags_to_remove,
            declared_assets=declared_assets,
            controls_to_add=controls_to_add,
            controls_to_remove=controls_to_remove,
            integrations=integrations,
            partner_client_id=partner_client_id,
        )


        update_corporate_client_dto.additional_properties = d
        return update_corporate_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
