from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.case_category import CaseCategory
from ..models.case_priority import CasePriority
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="BulkEscalateAlertDto")



@_attrs_define
class BulkEscalateAlertDto:
    """ 
        Attributes:
            alert_ids (list[str]): Array of alert IDs or reference IDs (maximum 100) Example:
                ['123e4567-e89b-12d3-a456-426614174000', 'ALT-REF-001'].
            reason (str): Reason for escalating the alerts to cases Example: Multiple suspicious transactions detected.
            description (str): Detailed description for the cases to be created Example: Suspicious transaction activity
                detected requiring investigation.
            case_category (CaseCategory | Unset): Category of the cases to be created. When omitted, each case inherits its
                alert's category.
            case_priority (CasePriority | Unset): Priority level of the cases to be created. When omitted, each case
                inherits its alert's priority.
            case_sub_category (str | Unset): Subcategory of the cases to be created Example: AML.
            case_assignee_id (str | Unset): ID of the user to assign the cases to Example:
                123e4567-e89b-12d3-a456-426614174000.
            due_date (datetime.datetime | Unset): Due date for the cases
            attachment_ids (list[str] | Unset): Attachment IDs to associate with the cases Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
     """

    alert_ids: list[str]
    reason: str
    description: str
    case_category: CaseCategory | Unset = UNSET
    case_priority: CasePriority | Unset = UNSET
    case_sub_category: str | Unset = UNSET
    case_assignee_id: str | Unset = UNSET
    due_date: datetime.datetime | Unset = UNSET
    attachment_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        alert_ids = self.alert_ids



        reason = self.reason

        description = self.description

        case_category: str | Unset = UNSET
        if not isinstance(self.case_category, Unset):
            case_category = self.case_category.value


        case_priority: str | Unset = UNSET
        if not isinstance(self.case_priority, Unset):
            case_priority = self.case_priority.value


        case_sub_category = self.case_sub_category

        case_assignee_id = self.case_assignee_id

        due_date: str | Unset = UNSET
        if not isinstance(self.due_date, Unset):
            due_date = self.due_date.isoformat()

        attachment_ids: list[str] | Unset = UNSET
        if not isinstance(self.attachment_ids, Unset):
            attachment_ids = self.attachment_ids




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "alertIds": alert_ids,
            "reason": reason,
            "description": description,
        })
        if case_category is not UNSET:
            field_dict["caseCategory"] = case_category
        if case_priority is not UNSET:
            field_dict["casePriority"] = case_priority
        if case_sub_category is not UNSET:
            field_dict["caseSubCategory"] = case_sub_category
        if case_assignee_id is not UNSET:
            field_dict["caseAssigneeId"] = case_assignee_id
        if due_date is not UNSET:
            field_dict["dueDate"] = due_date
        if attachment_ids is not UNSET:
            field_dict["attachmentIds"] = attachment_ids

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        alert_ids = cast(list[str], d.pop("alertIds"))


        reason = d.pop("reason")

        description = d.pop("description")

        _case_category = d.pop("caseCategory", UNSET)
        case_category: CaseCategory | Unset
        if isinstance(_case_category,  Unset):
            case_category = UNSET
        else:
            case_category = CaseCategory(_case_category)




        _case_priority = d.pop("casePriority", UNSET)
        case_priority: CasePriority | Unset
        if isinstance(_case_priority,  Unset):
            case_priority = UNSET
        else:
            case_priority = CasePriority(_case_priority)




        case_sub_category = d.pop("caseSubCategory", UNSET)

        case_assignee_id = d.pop("caseAssigneeId", UNSET)

        _due_date = d.pop("dueDate", UNSET)
        due_date: datetime.datetime | Unset
        if isinstance(_due_date,  Unset):
            due_date = UNSET
        else:
            due_date = isoparse(_due_date)




        attachment_ids = cast(list[str], d.pop("attachmentIds", UNSET))


        bulk_escalate_alert_dto = cls(
            alert_ids=alert_ids,
            reason=reason,
            description=description,
            case_category=case_category,
            case_priority=case_priority,
            case_sub_category=case_sub_category,
            case_assignee_id=case_assignee_id,
            due_date=due_date,
            attachment_ids=attachment_ids,
        )


        bulk_escalate_alert_dto.additional_properties = d
        return bulk_escalate_alert_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
