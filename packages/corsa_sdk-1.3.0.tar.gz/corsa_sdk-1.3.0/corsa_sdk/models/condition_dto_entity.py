from enum import Enum

class ConditionDtoEntity(str, Enum):
    BANKACCOUNT = "bankAccount"
    CLIENT = "client"
    TRANSACTION = "transaction"
    WALLET = "wallet"

    def __str__(self) -> str:
        return str(self.value)
