from enum import Enum

class CorporateClientCustomFieldDataDtoCategory(str, Enum):
    ADDRESS = "ADDRESS"
    APPLICATION = "APPLICATION"
    BUSINESS = "BUSINESS"
    FINANCIAL = "FINANCIAL"
    GENERAL = "GENERAL"
    OTHER = "OTHER"
    VERIFICATION = "VERIFICATION"

    def __str__(self) -> str:
        return str(self.value)
