from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_transaction_dto import CreateTransactionDto
  from ..models.session_reference_dto import SessionReferenceDto





T = TypeVar("T", bound="CreateDepositOperationDto")



@_attrs_define
class CreateDepositOperationDto:
    """ 
        Attributes:
            deposit_transaction (CreateTransactionDto):
            reference_id (str | Unset): External reference ID for the deposit operation Example: DEP-2023-001.
            initiated_by (str | Unset): UUID of the client who initiated the deposit Example:
                123e4567-e89b-12d3-a456-426614174000.
            initiated_at (str | Unset): Date and time the deposit was initiated. Defaults to current date and time if not
                provided Example: 2023-01-01T00:00:00.000Z.
            session (SessionReferenceDto | Unset):
     """

    deposit_transaction: CreateTransactionDto
    reference_id: str | Unset = UNSET
    initiated_by: str | Unset = UNSET
    initiated_at: str | Unset = UNSET
    session: SessionReferenceDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_transaction_dto import CreateTransactionDto
        from ..models.session_reference_dto import SessionReferenceDto
        deposit_transaction = self.deposit_transaction.to_dict()

        reference_id = self.reference_id

        initiated_by = self.initiated_by

        initiated_at = self.initiated_at

        session: dict[str, Any] | Unset = UNSET
        if not isinstance(self.session, Unset):
            session = self.session.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "depositTransaction": deposit_transaction,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if initiated_by is not UNSET:
            field_dict["initiatedBy"] = initiated_by
        if initiated_at is not UNSET:
            field_dict["initiatedAt"] = initiated_at
        if session is not UNSET:
            field_dict["session"] = session

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_transaction_dto import CreateTransactionDto
        from ..models.session_reference_dto import SessionReferenceDto
        d = dict(src_dict)
        deposit_transaction = CreateTransactionDto.from_dict(d.pop("depositTransaction"))




        reference_id = d.pop("referenceId", UNSET)

        initiated_by = d.pop("initiatedBy", UNSET)

        initiated_at = d.pop("initiatedAt", UNSET)

        _session = d.pop("session", UNSET)
        session: SessionReferenceDto | Unset
        if isinstance(_session,  Unset):
            session = UNSET
        else:
            session = SessionReferenceDto.from_dict(_session)




        create_deposit_operation_dto = cls(
            deposit_transaction=deposit_transaction,
            reference_id=reference_id,
            initiated_by=initiated_by,
            initiated_at=initiated_at,
            session=session,
        )


        create_deposit_operation_dto.additional_properties = d
        return create_deposit_operation_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
