from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.corporate_client_custom_field_data_dto_category import CorporateClientCustomFieldDataDtoCategory
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.corporate_client_custom_field_data_dto_value_type_3 import CorporateClientCustomFieldDataDtoValueType3
  from ..models.corporate_client_custom_field_data_dto_value_type_4_item import CorporateClientCustomFieldDataDtoValueType4Item





T = TypeVar("T", bound="CorporateClientCustomFieldDataDto")



@_attrs_define
class CorporateClientCustomFieldDataDto:
    """ 
        Attributes:
            label (str): The label of the custom field Example: Custom Field 1.
            value (bool | CorporateClientCustomFieldDataDtoValueType3 | float |
                list[CorporateClientCustomFieldDataDtoValueType4Item] | str): Value of the custom field. It can be a string,
                number, boolean, object (JSON), or array of objects. If you'd like to submit a country code, use the ISO 3166-1
                alpha-2 code. If you'd like to submit a date, use the ISO 8601 format. Example: value1.
            category (CorporateClientCustomFieldDataDtoCategory): Category of the custom field Example: BUSINESS.
            description (str | Unset): Description of the custom field Example: This is a description of the custom field.
            possible_values (list[str] | Unset): Array of possible values for this custom field (enum). Only applies to
                string and number values. Example: ['value1', 'value2', 'value3'].
            immutable (bool | Unset): Whether this custom field is immutable and cannot be changed after creation
     """

    label: str
    value: bool | CorporateClientCustomFieldDataDtoValueType3 | float | list[CorporateClientCustomFieldDataDtoValueType4Item] | str
    category: CorporateClientCustomFieldDataDtoCategory
    description: str | Unset = UNSET
    possible_values: list[str] | Unset = UNSET
    immutable: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.corporate_client_custom_field_data_dto_value_type_3 import CorporateClientCustomFieldDataDtoValueType3
        from ..models.corporate_client_custom_field_data_dto_value_type_4_item import CorporateClientCustomFieldDataDtoValueType4Item
        label = self.label

        value: bool | dict[str, Any] | float | list[dict[str, Any]] | str
        if isinstance(self.value, CorporateClientCustomFieldDataDtoValueType3):
            value = self.value.to_dict()
        elif isinstance(self.value, list):
            value = []
            for value_type_4_item_data in self.value:
                value_type_4_item = value_type_4_item_data.to_dict()
                value.append(value_type_4_item)


        else:
            value = self.value

        category = self.category.value

        description = self.description

        possible_values: list[str] | Unset = UNSET
        if not isinstance(self.possible_values, Unset):
            possible_values = self.possible_values



        immutable = self.immutable


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "label": label,
            "value": value,
            "category": category,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if possible_values is not UNSET:
            field_dict["possibleValues"] = possible_values
        if immutable is not UNSET:
            field_dict["immutable"] = immutable

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.corporate_client_custom_field_data_dto_value_type_3 import CorporateClientCustomFieldDataDtoValueType3
        from ..models.corporate_client_custom_field_data_dto_value_type_4_item import CorporateClientCustomFieldDataDtoValueType4Item
        d = dict(src_dict)
        label = d.pop("label")

        def _parse_value(data: object) -> bool | CorporateClientCustomFieldDataDtoValueType3 | float | list[CorporateClientCustomFieldDataDtoValueType4Item] | str:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                value_type_3 = CorporateClientCustomFieldDataDtoValueType3.from_dict(data)



                return value_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, list):
                    raise TypeError()
                value_type_4 = []
                _value_type_4 = data
                for value_type_4_item_data in (_value_type_4):
                    value_type_4_item = CorporateClientCustomFieldDataDtoValueType4Item.from_dict(value_type_4_item_data)



                    value_type_4.append(value_type_4_item)

                return value_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(bool | CorporateClientCustomFieldDataDtoValueType3 | float | list[CorporateClientCustomFieldDataDtoValueType4Item] | str, data)

        value = _parse_value(d.pop("value"))


        category = CorporateClientCustomFieldDataDtoCategory(d.pop("category"))




        description = d.pop("description", UNSET)

        possible_values = cast(list[str], d.pop("possibleValues", UNSET))


        immutable = d.pop("immutable", UNSET)

        corporate_client_custom_field_data_dto = cls(
            label=label,
            value=value,
            category=category,
            description=description,
            possible_values=possible_values,
            immutable=immutable,
        )


        corporate_client_custom_field_data_dto.additional_properties = d
        return corporate_client_custom_field_data_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
