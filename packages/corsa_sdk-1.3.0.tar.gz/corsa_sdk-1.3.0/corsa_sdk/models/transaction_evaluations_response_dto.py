from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.transaction_evaluation_record_dto import TransactionEvaluationRecordDto





T = TypeVar("T", bound="TransactionEvaluationsResponseDto")



@_attrs_define
class TransactionEvaluationsResponseDto:
    """ 
        Attributes:
            data (list[TransactionEvaluationRecordDto]):
            total_items (float): Total number of matching records
            page (float): Current page number
            page_size (float): Page size
            total_pages (float): Total number of pages
     """

    data: list[TransactionEvaluationRecordDto]
    total_items: float
    page: float
    page_size: float
    total_pages: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.transaction_evaluation_record_dto import TransactionEvaluationRecordDto
        data = []
        for data_item_data in self.data:
            data_item = data_item_data.to_dict()
            data.append(data_item)



        total_items = self.total_items

        page = self.page

        page_size = self.page_size

        total_pages = self.total_pages


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "data": data,
            "totalItems": total_items,
            "page": page,
            "pageSize": page_size,
            "totalPages": total_pages,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.transaction_evaluation_record_dto import TransactionEvaluationRecordDto
        d = dict(src_dict)
        data = []
        _data = d.pop("data")
        for data_item_data in (_data):
            data_item = TransactionEvaluationRecordDto.from_dict(data_item_data)



            data.append(data_item)


        total_items = d.pop("totalItems")

        page = d.pop("page")

        page_size = d.pop("pageSize")

        total_pages = d.pop("totalPages")

        transaction_evaluations_response_dto = cls(
            data=data,
            total_items=total_items,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
        )


        transaction_evaluations_response_dto.additional_properties = d
        return transaction_evaluations_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
