from enum import Enum

class ChecklistResponseDtoStatus(str, Enum):
    ACTIVE = "ACTIVE"
    ARCHIVED = "ARCHIVED"
    COMPLETED = "COMPLETED"

    def __str__(self) -> str:
        return str(self.value)
