from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.trade_operation_dto_trade_type import TradeOperationDtoTradeType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.operation_initiator_dto import OperationInitiatorDto
  from ..models.operation_status_dto import OperationStatusDto
  from ..models.transaction_dto import TransactionDto





T = TypeVar("T", bound="TradeOperationDto")



@_attrs_define
class TradeOperationDto:
    """ 
        Attributes:
            id (str): Unique identifier of the trade operation Example: 123e4567-e89b-12d3-a456-426614174000.
            created_at (str): ISO timestamp when the trade operation was created Example: 2023-08-15T10:30:00Z.
            initiated_at (str): ISO timestamp when the trade operation was initiated or reported to the platform Example:
                2023-08-15T10:30:00Z.
            updated_at (str): ISO timestamp when the trade operation was last updated Example: 2023-08-15T10:35:00Z.
            trade_type (TradeOperationDtoTradeType): Type of the trade Example: BUY.
            price (float): Price of the trade Example: 100.
            quantity (float): Quantity of the trade Example: 100.
            instrument_base_asset (str): Base asset of the trade Example: BTC.
            transactions (list[TransactionDto]): The transactions for the trade
            instrument_quote_asset (str): Quote asset of the trade Example: USD.
            reference_id (str | Unset): External reference ID for the trade operation Example: TRD-2023-001.
            initiated_by (OperationInitiatorDto | Unset):
            status_history (list[OperationStatusDto] | Unset): Status history of the trade
     """

    id: str
    created_at: str
    initiated_at: str
    updated_at: str
    trade_type: TradeOperationDtoTradeType
    price: float
    quantity: float
    instrument_base_asset: str
    transactions: list[TransactionDto]
    instrument_quote_asset: str
    reference_id: str | Unset = UNSET
    initiated_by: OperationInitiatorDto | Unset = UNSET
    status_history: list[OperationStatusDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.operation_initiator_dto import OperationInitiatorDto
        from ..models.operation_status_dto import OperationStatusDto
        from ..models.transaction_dto import TransactionDto
        id = self.id

        created_at = self.created_at

        initiated_at = self.initiated_at

        updated_at = self.updated_at

        trade_type = self.trade_type.value

        price = self.price

        quantity = self.quantity

        instrument_base_asset = self.instrument_base_asset

        transactions = []
        for transactions_item_data in self.transactions:
            transactions_item = transactions_item_data.to_dict()
            transactions.append(transactions_item)



        instrument_quote_asset = self.instrument_quote_asset

        reference_id = self.reference_id

        initiated_by: dict[str, Any] | Unset = UNSET
        if not isinstance(self.initiated_by, Unset):
            initiated_by = self.initiated_by.to_dict()

        status_history: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.status_history, Unset):
            status_history = []
            for status_history_item_data in self.status_history:
                status_history_item = status_history_item_data.to_dict()
                status_history.append(status_history_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "createdAt": created_at,
            "initiatedAt": initiated_at,
            "updatedAt": updated_at,
            "tradeType": trade_type,
            "price": price,
            "quantity": quantity,
            "instrumentBaseAsset": instrument_base_asset,
            "transactions": transactions,
            "instrumentQuoteAsset": instrument_quote_asset,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if initiated_by is not UNSET:
            field_dict["initiatedBy"] = initiated_by
        if status_history is not UNSET:
            field_dict["statusHistory"] = status_history

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.operation_initiator_dto import OperationInitiatorDto
        from ..models.operation_status_dto import OperationStatusDto
        from ..models.transaction_dto import TransactionDto
        d = dict(src_dict)
        id = d.pop("id")

        created_at = d.pop("createdAt")

        initiated_at = d.pop("initiatedAt")

        updated_at = d.pop("updatedAt")

        trade_type = TradeOperationDtoTradeType(d.pop("tradeType"))




        price = d.pop("price")

        quantity = d.pop("quantity")

        instrument_base_asset = d.pop("instrumentBaseAsset")

        transactions = []
        _transactions = d.pop("transactions")
        for transactions_item_data in (_transactions):
            transactions_item = TransactionDto.from_dict(transactions_item_data)



            transactions.append(transactions_item)


        instrument_quote_asset = d.pop("instrumentQuoteAsset")

        reference_id = d.pop("referenceId", UNSET)

        _initiated_by = d.pop("initiatedBy", UNSET)
        initiated_by: OperationInitiatorDto | Unset
        if isinstance(_initiated_by,  Unset):
            initiated_by = UNSET
        else:
            initiated_by = OperationInitiatorDto.from_dict(_initiated_by)




        _status_history = d.pop("statusHistory", UNSET)
        status_history: list[OperationStatusDto] | Unset = UNSET
        if _status_history is not UNSET:
            status_history = []
            for status_history_item_data in _status_history:
                status_history_item = OperationStatusDto.from_dict(status_history_item_data)



                status_history.append(status_history_item)


        trade_operation_dto = cls(
            id=id,
            created_at=created_at,
            initiated_at=initiated_at,
            updated_at=updated_at,
            trade_type=trade_type,
            price=price,
            quantity=quantity,
            instrument_base_asset=instrument_base_asset,
            transactions=transactions,
            instrument_quote_asset=instrument_quote_asset,
            reference_id=reference_id,
            initiated_by=initiated_by,
            status_history=status_history,
        )


        trade_operation_dto.additional_properties = d
        return trade_operation_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
