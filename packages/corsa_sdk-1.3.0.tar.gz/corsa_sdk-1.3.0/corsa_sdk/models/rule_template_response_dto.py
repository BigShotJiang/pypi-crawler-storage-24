from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.rule_template_response_dto_actions_item import RuleTemplateResponseDtoActionsItem
  from ..models.rule_template_response_dto_conditions import RuleTemplateResponseDtoConditions





T = TypeVar("T", bound="RuleTemplateResponseDto")



@_attrs_define
class RuleTemplateResponseDto:
    """ 
        Attributes:
            id (str):
            template_key (str):
            name (str):
            description (None | str):
            products (list[str]):
            typologies (list[str]):
            conditions (RuleTemplateResponseDtoConditions):
            actions (list[RuleTemplateResponseDtoActionsItem]):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
     """

    id: str
    template_key: str
    name: str
    description: None | str
    products: list[str]
    typologies: list[str]
    conditions: RuleTemplateResponseDtoConditions
    actions: list[RuleTemplateResponseDtoActionsItem]
    created_at: datetime.datetime
    updated_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rule_template_response_dto_actions_item import RuleTemplateResponseDtoActionsItem
        from ..models.rule_template_response_dto_conditions import RuleTemplateResponseDtoConditions
        id = self.id

        template_key = self.template_key

        name = self.name

        description: None | str
        description = self.description

        products = self.products



        typologies = self.typologies



        conditions = self.conditions.to_dict()

        actions = []
        for actions_item_data in self.actions:
            actions_item = actions_item_data.to_dict()
            actions.append(actions_item)



        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "templateKey": template_key,
            "name": name,
            "description": description,
            "products": products,
            "typologies": typologies,
            "conditions": conditions,
            "actions": actions,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rule_template_response_dto_actions_item import RuleTemplateResponseDtoActionsItem
        from ..models.rule_template_response_dto_conditions import RuleTemplateResponseDtoConditions
        d = dict(src_dict)
        id = d.pop("id")

        template_key = d.pop("templateKey")

        name = d.pop("name")

        def _parse_description(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        description = _parse_description(d.pop("description"))


        products = cast(list[str], d.pop("products"))


        typologies = cast(list[str], d.pop("typologies"))


        conditions = RuleTemplateResponseDtoConditions.from_dict(d.pop("conditions"))




        actions = []
        _actions = d.pop("actions")
        for actions_item_data in (_actions):
            actions_item = RuleTemplateResponseDtoActionsItem.from_dict(actions_item_data)



            actions.append(actions_item)


        created_at = isoparse(d.pop("createdAt"))




        updated_at = isoparse(d.pop("updatedAt"))




        rule_template_response_dto = cls(
            id=id,
            template_key=template_key,
            name=name,
            description=description,
            products=products,
            typologies=typologies,
            conditions=conditions,
            actions=actions,
            created_at=created_at,
            updated_at=updated_at,
        )


        rule_template_response_dto.additional_properties = d
        return rule_template_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
