from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.action_config_dto_type import ActionConfigDtoType
from typing import cast

if TYPE_CHECKING:
  from ..models.action_config_dto_config import ActionConfigDtoConfig





T = TypeVar("T", bound="ActionConfigDto")



@_attrs_define
class ActionConfigDto:
    """ 
        Attributes:
            type_ (ActionConfigDtoType): Action type Example: CREATE_ALERT.
            config (ActionConfigDtoConfig): Action-specific configuration Example: {'category': 'TRANSACTION_MONITORING',
                'priority': 'HIGH', 'status': 'NEW'}.
     """

    type_: ActionConfigDtoType
    config: ActionConfigDtoConfig
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.action_config_dto_config import ActionConfigDtoConfig
        type_ = self.type_.value

        config = self.config.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
            "config": config,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_config_dto_config import ActionConfigDtoConfig
        d = dict(src_dict)
        type_ = ActionConfigDtoType(d.pop("type"))




        config = ActionConfigDtoConfig.from_dict(d.pop("config"))




        action_config_dto = cls(
            type_=type_,
            config=config,
        )


        action_config_dto.additional_properties = d
        return action_config_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
