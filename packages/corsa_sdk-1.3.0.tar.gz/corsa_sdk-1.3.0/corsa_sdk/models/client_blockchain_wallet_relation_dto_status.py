from enum import Enum

class ClientBlockchainWalletRelationDtoStatus(str, Enum):
    ACTIVE = "ACTIVE"
    CLOSED = "CLOSED"
    INACTIVE = "INACTIVE"

    def __str__(self) -> str:
        return str(self.value)
