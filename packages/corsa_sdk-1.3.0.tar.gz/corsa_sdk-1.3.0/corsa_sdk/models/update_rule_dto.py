from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.action_config_dto import ActionConfigDto
  from ..models.conditions_dto import ConditionsDto





T = TypeVar("T", bound="UpdateRuleDto")



@_attrs_define
class UpdateRuleDto:
    """ 
        Attributes:
            name (str | Unset):
            description (str | Unset):
            actions (list[ActionConfigDto] | Unset):
            conditions (ConditionsDto | Unset):
            reason (str | Unset): Reason for updating the rule (used for audit trail when updating active rules)
     """

    name: str | Unset = UNSET
    description: str | Unset = UNSET
    actions: list[ActionConfigDto] | Unset = UNSET
    conditions: ConditionsDto | Unset = UNSET
    reason: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.action_config_dto import ActionConfigDto
        from ..models.conditions_dto import ConditionsDto
        name = self.name

        description = self.description

        actions: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.actions, Unset):
            actions = []
            for actions_item_data in self.actions:
                actions_item = actions_item_data.to_dict()
                actions.append(actions_item)



        conditions: dict[str, Any] | Unset = UNSET
        if not isinstance(self.conditions, Unset):
            conditions = self.conditions.to_dict()

        reason = self.reason


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if actions is not UNSET:
            field_dict["actions"] = actions
        if conditions is not UNSET:
            field_dict["conditions"] = conditions
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_config_dto import ActionConfigDto
        from ..models.conditions_dto import ConditionsDto
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        _actions = d.pop("actions", UNSET)
        actions: list[ActionConfigDto] | Unset = UNSET
        if _actions is not UNSET:
            actions = []
            for actions_item_data in _actions:
                actions_item = ActionConfigDto.from_dict(actions_item_data)



                actions.append(actions_item)


        _conditions = d.pop("conditions", UNSET)
        conditions: ConditionsDto | Unset
        if isinstance(_conditions,  Unset):
            conditions = UNSET
        else:
            conditions = ConditionsDto.from_dict(_conditions)




        reason = d.pop("reason", UNSET)

        update_rule_dto = cls(
            name=name,
            description=description,
            actions=actions,
            conditions=conditions,
            reason=reason,
        )


        update_rule_dto.additional_properties = d
        return update_rule_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
