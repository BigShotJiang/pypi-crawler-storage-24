from enum import Enum

class IndividualClientCustomFieldDataDtoCategory(str, Enum):
    ADDRESS = "ADDRESS"
    APPLICATION = "APPLICATION"
    CONTACT = "CONTACT"
    FINANCIAL = "FINANCIAL"
    GENERAL = "GENERAL"
    VERIFICATION = "VERIFICATION"
    WORK = "WORK"

    def __str__(self) -> str:
        return str(self.value)
