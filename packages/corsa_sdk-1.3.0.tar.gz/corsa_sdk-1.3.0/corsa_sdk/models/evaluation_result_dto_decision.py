from enum import Enum

class EvaluationResultDtoDecision(str, Enum):
    ALLOW = "ALLOW"
    FREEZE = "FREEZE"

    def __str__(self) -> str:
        return str(self.value)
