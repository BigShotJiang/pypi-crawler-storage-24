from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.sanctions_list_entry_dto import SanctionsListEntryDto





T = TypeVar("T", bound="SanctionsDto")



@_attrs_define
class SanctionsDto:
    """ 
        Attributes:
            is_sanctioned (bool | None): Indicates if the client is under any sanctions
            sanctions_list (list[SanctionsListEntryDto] | Unset): List of sanctions lists the client appears on
     """

    is_sanctioned: bool | None
    sanctions_list: list[SanctionsListEntryDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.sanctions_list_entry_dto import SanctionsListEntryDto
        is_sanctioned: bool | None
        is_sanctioned = self.is_sanctioned

        sanctions_list: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.sanctions_list, Unset):
            sanctions_list = []
            for sanctions_list_item_data in self.sanctions_list:
                sanctions_list_item = sanctions_list_item_data.to_dict()
                sanctions_list.append(sanctions_list_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "isSanctioned": is_sanctioned,
        })
        if sanctions_list is not UNSET:
            field_dict["sanctionsList"] = sanctions_list

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.sanctions_list_entry_dto import SanctionsListEntryDto
        d = dict(src_dict)
        def _parse_is_sanctioned(data: object) -> bool | None:
            if data is None:
                return data
            return cast(bool | None, data)

        is_sanctioned = _parse_is_sanctioned(d.pop("isSanctioned"))


        _sanctions_list = d.pop("sanctionsList", UNSET)
        sanctions_list: list[SanctionsListEntryDto] | Unset = UNSET
        if _sanctions_list is not UNSET:
            sanctions_list = []
            for sanctions_list_item_data in _sanctions_list:
                sanctions_list_item = SanctionsListEntryDto.from_dict(sanctions_list_item_data)



                sanctions_list.append(sanctions_list_item)


        sanctions_dto = cls(
            is_sanctioned=is_sanctioned,
            sanctions_list=sanctions_list,
        )


        sanctions_dto.additional_properties = d
        return sanctions_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
