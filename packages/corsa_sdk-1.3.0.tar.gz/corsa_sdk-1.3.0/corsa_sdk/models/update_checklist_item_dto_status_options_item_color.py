from enum import Enum

class UpdateChecklistItemDtoStatusOptionsItemColor(str, Enum):
    BLACK = "black"
    BLUE = "blue"
    GRAY = "gray"
    GREEN = "green"
    ORANGE = "orange"
    PINK = "pink"
    PURPLE = "purple"
    RED = "red"
    WHITE = "white"
    YELLOW = "yellow"

    def __str__(self) -> str:
        return str(self.value)
