from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_external_document_dto_entity_type import CreateExternalDocumentDtoEntityType
from ..models.create_external_document_dto_source import CreateExternalDocumentDtoSource
from ..types import UNSET, Unset






T = TypeVar("T", bound="CreateExternalDocumentDto")



@_attrs_define
class CreateExternalDocumentDto:
    """ 
        Attributes:
            download_url (str): The download URL for the external document Example: https://example.com/documents/file.pdf.
            file_name (str): The name of the file Example: document.pdf.
            entity_type (CreateExternalDocumentDtoEntityType): The type of entity the attachment is associated with Example:
                case.
            entity_id (str): The ID of the entity the attachment is associated with Example:
                case_123e4567-e89b-12d3-a456-426614174000.
            file_type (str | Unset): The MIME type of the file Example: application/pdf.
            file_size_in_bytes (float | Unset): The size of the file in bytes Example: 1024000.
            metadata (str | Unset): Optional metadata for the attachment as JSON string Example: {"category": "compliance",
                "version": "1.0"}.
            source (CreateExternalDocumentDtoSource | Unset): The source of the attachment Example: EXTERNAL.
     """

    download_url: str
    file_name: str
    entity_type: CreateExternalDocumentDtoEntityType
    entity_id: str
    file_type: str | Unset = UNSET
    file_size_in_bytes: float | Unset = UNSET
    metadata: str | Unset = UNSET
    source: CreateExternalDocumentDtoSource | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        download_url = self.download_url

        file_name = self.file_name

        entity_type = self.entity_type.value

        entity_id = self.entity_id

        file_type = self.file_type

        file_size_in_bytes = self.file_size_in_bytes

        metadata = self.metadata

        source: str | Unset = UNSET
        if not isinstance(self.source, Unset):
            source = self.source.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "downloadUrl": download_url,
            "fileName": file_name,
            "entityType": entity_type,
            "entityId": entity_id,
        })
        if file_type is not UNSET:
            field_dict["fileType"] = file_type
        if file_size_in_bytes is not UNSET:
            field_dict["fileSizeInBytes"] = file_size_in_bytes
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if source is not UNSET:
            field_dict["source"] = source

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        download_url = d.pop("downloadUrl")

        file_name = d.pop("fileName")

        entity_type = CreateExternalDocumentDtoEntityType(d.pop("entityType"))




        entity_id = d.pop("entityId")

        file_type = d.pop("fileType", UNSET)

        file_size_in_bytes = d.pop("fileSizeInBytes", UNSET)

        metadata = d.pop("metadata", UNSET)

        _source = d.pop("source", UNSET)
        source: CreateExternalDocumentDtoSource | Unset
        if isinstance(_source,  Unset):
            source = UNSET
        else:
            source = CreateExternalDocumentDtoSource(_source)




        create_external_document_dto = cls(
            download_url=download_url,
            file_name=file_name,
            entity_type=entity_type,
            entity_id=entity_id,
            file_type=file_type,
            file_size_in_bytes=file_size_in_bytes,
            metadata=metadata,
            source=source,
        )


        create_external_document_dto.additional_properties = d
        return create_external_document_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
