from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.transaction_evaluation_record_dto_decision import TransactionEvaluationRecordDtoDecision
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.condition_result_dto import ConditionResultDto





T = TypeVar("T", bound="TransactionEvaluationRecordDto")



@_attrs_define
class TransactionEvaluationRecordDto:
    """ 
        Attributes:
            id (str): Evaluation record unique identifier
            rule_id (str): Rule ID that was evaluated
            rule_name (str): Rule name at time of evaluation
            rule_version (float): Rule version at time of evaluation
            matched (bool): Whether the rule matched (hit)
            evaluation_source (str): How the evaluation was triggered (API or EVENT)
            condition_results (list[ConditionResultDto] | None): Detailed condition results for this evaluation
            condition_pattern_hash (None | str): Hash of the passing condition pattern for path analytics
            evaluated_at (datetime.datetime): When the rule engine processed this evaluation
            latency_ms (float | None): Evaluation latency in milliseconds
            decision (TransactionEvaluationRecordDtoDecision | Unset): Rule decision: FREEZE if rule would halt the
                transaction, ALLOW otherwise. Null for legacy records.
            transaction_id (str | Unset): Transaction ID
            current_rule_version (float | None | Unset): Current (latest) version of this rule, null if rule no longer
                exists
            rule_exists (bool | Unset): Whether the rule still exists in the system (not soft-deleted)
            rule_active (bool | Unset): Whether the rule is currently active
            current_rule_name (None | str | Unset): Current display name of the rule from the latest version
            current_rule_description (None | str | Unset): Current description of the rule from the latest version
            narrative (None | str | Unset): AI-generated human-readable narrative for this evaluation
     """

    id: str
    rule_id: str
    rule_name: str
    rule_version: float
    matched: bool
    evaluation_source: str
    condition_results: list[ConditionResultDto] | None
    condition_pattern_hash: None | str
    evaluated_at: datetime.datetime
    latency_ms: float | None
    decision: TransactionEvaluationRecordDtoDecision | Unset = UNSET
    transaction_id: str | Unset = UNSET
    current_rule_version: float | None | Unset = UNSET
    rule_exists: bool | Unset = UNSET
    rule_active: bool | Unset = UNSET
    current_rule_name: None | str | Unset = UNSET
    current_rule_description: None | str | Unset = UNSET
    narrative: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.condition_result_dto import ConditionResultDto
        id = self.id

        rule_id = self.rule_id

        rule_name = self.rule_name

        rule_version = self.rule_version

        matched = self.matched

        evaluation_source = self.evaluation_source

        condition_results: list[dict[str, Any]] | None
        if isinstance(self.condition_results, list):
            condition_results = []
            for condition_results_type_0_item_data in self.condition_results:
                condition_results_type_0_item = condition_results_type_0_item_data.to_dict()
                condition_results.append(condition_results_type_0_item)


        else:
            condition_results = self.condition_results

        condition_pattern_hash: None | str
        condition_pattern_hash = self.condition_pattern_hash

        evaluated_at = self.evaluated_at.isoformat()

        latency_ms: float | None
        latency_ms = self.latency_ms

        decision: str | Unset = UNSET
        if not isinstance(self.decision, Unset):
            decision = self.decision.value


        transaction_id = self.transaction_id

        current_rule_version: float | None | Unset
        if isinstance(self.current_rule_version, Unset):
            current_rule_version = UNSET
        else:
            current_rule_version = self.current_rule_version

        rule_exists = self.rule_exists

        rule_active = self.rule_active

        current_rule_name: None | str | Unset
        if isinstance(self.current_rule_name, Unset):
            current_rule_name = UNSET
        else:
            current_rule_name = self.current_rule_name

        current_rule_description: None | str | Unset
        if isinstance(self.current_rule_description, Unset):
            current_rule_description = UNSET
        else:
            current_rule_description = self.current_rule_description

        narrative: None | str | Unset
        if isinstance(self.narrative, Unset):
            narrative = UNSET
        else:
            narrative = self.narrative


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "ruleId": rule_id,
            "ruleName": rule_name,
            "ruleVersion": rule_version,
            "matched": matched,
            "evaluationSource": evaluation_source,
            "conditionResults": condition_results,
            "conditionPatternHash": condition_pattern_hash,
            "evaluatedAt": evaluated_at,
            "latencyMs": latency_ms,
        })
        if decision is not UNSET:
            field_dict["decision"] = decision
        if transaction_id is not UNSET:
            field_dict["transactionId"] = transaction_id
        if current_rule_version is not UNSET:
            field_dict["currentRuleVersion"] = current_rule_version
        if rule_exists is not UNSET:
            field_dict["ruleExists"] = rule_exists
        if rule_active is not UNSET:
            field_dict["ruleActive"] = rule_active
        if current_rule_name is not UNSET:
            field_dict["currentRuleName"] = current_rule_name
        if current_rule_description is not UNSET:
            field_dict["currentRuleDescription"] = current_rule_description
        if narrative is not UNSET:
            field_dict["narrative"] = narrative

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.condition_result_dto import ConditionResultDto
        d = dict(src_dict)
        id = d.pop("id")

        rule_id = d.pop("ruleId")

        rule_name = d.pop("ruleName")

        rule_version = d.pop("ruleVersion")

        matched = d.pop("matched")

        evaluation_source = d.pop("evaluationSource")

        def _parse_condition_results(data: object) -> list[ConditionResultDto] | None:
            if data is None:
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                condition_results_type_0 = []
                _condition_results_type_0 = data
                for condition_results_type_0_item_data in (_condition_results_type_0):
                    condition_results_type_0_item = ConditionResultDto.from_dict(condition_results_type_0_item_data)



                    condition_results_type_0.append(condition_results_type_0_item)

                return condition_results_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ConditionResultDto] | None, data)

        condition_results = _parse_condition_results(d.pop("conditionResults"))


        def _parse_condition_pattern_hash(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        condition_pattern_hash = _parse_condition_pattern_hash(d.pop("conditionPatternHash"))


        evaluated_at = isoparse(d.pop("evaluatedAt"))




        def _parse_latency_ms(data: object) -> float | None:
            if data is None:
                return data
            return cast(float | None, data)

        latency_ms = _parse_latency_ms(d.pop("latencyMs"))


        _decision = d.pop("decision", UNSET)
        decision: TransactionEvaluationRecordDtoDecision | Unset
        if isinstance(_decision,  Unset):
            decision = UNSET
        else:
            decision = TransactionEvaluationRecordDtoDecision(_decision)




        transaction_id = d.pop("transactionId", UNSET)

        def _parse_current_rule_version(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        current_rule_version = _parse_current_rule_version(d.pop("currentRuleVersion", UNSET))


        rule_exists = d.pop("ruleExists", UNSET)

        rule_active = d.pop("ruleActive", UNSET)

        def _parse_current_rule_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        current_rule_name = _parse_current_rule_name(d.pop("currentRuleName", UNSET))


        def _parse_current_rule_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        current_rule_description = _parse_current_rule_description(d.pop("currentRuleDescription", UNSET))


        def _parse_narrative(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        narrative = _parse_narrative(d.pop("narrative", UNSET))


        transaction_evaluation_record_dto = cls(
            id=id,
            rule_id=rule_id,
            rule_name=rule_name,
            rule_version=rule_version,
            matched=matched,
            evaluation_source=evaluation_source,
            condition_results=condition_results,
            condition_pattern_hash=condition_pattern_hash,
            evaluated_at=evaluated_at,
            latency_ms=latency_ms,
            decision=decision,
            transaction_id=transaction_id,
            current_rule_version=current_rule_version,
            rule_exists=rule_exists,
            rule_active=rule_active,
            current_rule_name=current_rule_name,
            current_rule_description=current_rule_description,
            narrative=narrative,
        )


        transaction_evaluation_record_dto.additional_properties = d
        return transaction_evaluation_record_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
