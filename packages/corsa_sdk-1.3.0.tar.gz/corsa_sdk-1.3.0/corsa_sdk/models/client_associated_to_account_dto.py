from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.client_associated_to_account_dto_status import ClientAssociatedToAccountDtoStatus
from ..types import UNSET, Unset






T = TypeVar("T", bound="ClientAssociatedToAccountDto")



@_attrs_define
class ClientAssociatedToAccountDto:
    """ 
        Attributes:
            id (str): Client ID or reference ID to associate with the blockchain wallet Example: client-123.
            reference_id (str | Unset): Client reference ID Example: REF-CLIENT-001.
            name (str | Unset): Custom name for this client-wallet relationship Example: Primary Trading Wallet.
            status (ClientAssociatedToAccountDtoStatus | Unset): Status of the client-bank account relationship Example:
                ACTIVE.
     """

    id: str
    reference_id: str | Unset = UNSET
    name: str | Unset = UNSET
    status: ClientAssociatedToAccountDtoStatus | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        reference_id = self.reference_id

        name = self.name

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if name is not UNSET:
            field_dict["name"] = name
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        reference_id = d.pop("referenceId", UNSET)

        name = d.pop("name", UNSET)

        _status = d.pop("status", UNSET)
        status: ClientAssociatedToAccountDtoStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = ClientAssociatedToAccountDtoStatus(_status)




        client_associated_to_account_dto = cls(
            id=id,
            reference_id=reference_id,
            name=name,
            status=status,
        )


        client_associated_to_account_dto.additional_properties = d
        return client_associated_to_account_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
