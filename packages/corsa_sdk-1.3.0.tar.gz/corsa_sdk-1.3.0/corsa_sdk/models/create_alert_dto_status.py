from enum import Enum

class CreateAlertDtoStatus(str, Enum):
    ESCALATED = "ESCALATED"
    IN_REVIEW = "IN_REVIEW"
    NEW = "NEW"
    RESOLVED = "RESOLVED"

    def __str__(self) -> str:
        return str(self.value)
