from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.checklist_response_dto_entity_type import ChecklistResponseDtoEntityType
from ..models.checklist_response_dto_status import ChecklistResponseDtoStatus
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.checklist_item_response_dto import ChecklistItemResponseDto





T = TypeVar("T", bound="ChecklistResponseDto")



@_attrs_define
class ChecklistResponseDto:
    """ 
        Attributes:
            id (str): Unique identifier for the checklist Example: 123e4567-e89b-12d3-a456-426614174000.
            entity_id (str): ID of the entity this checklist belongs to Example: 123e4567-e89b-12d3-a456-426614174000.
            entity_type (ChecklistResponseDtoEntityType): Type of entity this checklist is for Example: INDIVIDUAL_CLIENT.
            status (ChecklistResponseDtoStatus): Current status of the checklist Example: ACTIVE.
            items (list[ChecklistItemResponseDto]): List of checklist items
            created_at (datetime.datetime): When the checklist was created Example: 2024-01-15T10:30:00Z.
            updated_at (datetime.datetime): When the checklist was last updated Example: 2024-01-15T10:30:00Z.
            reference_id (str | Unset): Reference ID from other applications to identify this checklist Example: ext-12345.
            name (str | Unset): Name of the checklist Example: Client Onboarding Checklist.
            description (str | Unset): Description of the checklist Example: Complete onboarding checklist for new
                individual client.
     """

    id: str
    entity_id: str
    entity_type: ChecklistResponseDtoEntityType
    status: ChecklistResponseDtoStatus
    items: list[ChecklistItemResponseDto]
    created_at: datetime.datetime
    updated_at: datetime.datetime
    reference_id: str | Unset = UNSET
    name: str | Unset = UNSET
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.checklist_item_response_dto import ChecklistItemResponseDto
        id = self.id

        entity_id = self.entity_id

        entity_type = self.entity_type.value

        status = self.status.value

        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)



        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        reference_id = self.reference_id

        name = self.name

        description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "entityId": entity_id,
            "entityType": entity_type,
            "status": status,
            "items": items,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.checklist_item_response_dto import ChecklistItemResponseDto
        d = dict(src_dict)
        id = d.pop("id")

        entity_id = d.pop("entityId")

        entity_type = ChecklistResponseDtoEntityType(d.pop("entityType"))




        status = ChecklistResponseDtoStatus(d.pop("status"))




        items = []
        _items = d.pop("items")
        for items_item_data in (_items):
            items_item = ChecklistItemResponseDto.from_dict(items_item_data)



            items.append(items_item)


        created_at = isoparse(d.pop("createdAt"))




        updated_at = isoparse(d.pop("updatedAt"))




        reference_id = d.pop("referenceId", UNSET)

        name = d.pop("name", UNSET)

        description = d.pop("description", UNSET)

        checklist_response_dto = cls(
            id=id,
            entity_id=entity_id,
            entity_type=entity_type,
            status=status,
            items=items,
            created_at=created_at,
            updated_at=updated_at,
            reference_id=reference_id,
            name=name,
            description=description,
        )


        checklist_response_dto.additional_properties = d
        return checklist_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
