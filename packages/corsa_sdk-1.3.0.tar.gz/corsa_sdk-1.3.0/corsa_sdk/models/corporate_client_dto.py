from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.corporate_client_dto_account_status import CorporateClientDtoAccountStatus
from ..models.corporate_client_dto_activity_status import CorporateClientDtoActivityStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.corporate_client_address_dto import CorporateClientAddressDto
  from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
  from ..models.corporate_client_application_dto import CorporateClientApplicationDto
  from ..models.corporate_client_business_dto import CorporateClientBusinessDto
  from ..models.corporate_client_contact_dto import CorporateClientContactDto
  from ..models.corporate_client_dto_custom_fields import CorporateClientDtoCustomFields
  from ..models.corporate_client_general_dto import CorporateClientGeneralDto
  from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
  from ..models.corporate_client_members_dto import CorporateClientMembersDto
  from ..models.corporate_client_pep_dto import CorporateClientPEPDto
  from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
  from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
  from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
  from ..models.risk_dto import RiskDto





T = TypeVar("T", bound="CorporateClientDto")



@_attrs_define
class CorporateClientDto:
    """ 
        Attributes:
            id (str): Unique identifier of the corporate client Example: 123e4567-e89b-12d3-a456-426614174000.
            account_status (CorporateClientDtoAccountStatus): Current status of the client account Example: ACTIVE.
            activity_status (CorporateClientDtoActivityStatus): Current activity status of the client Example: ACTIVE.
            address (CorporateClientAddressDto):
            application (CorporateClientApplicationDto):
            business (CorporateClientBusinessDto):
            general (CorporateClientGeneralDto):
            risk_history (list[RiskDto]): Historical risk assessments of the client
            tags (list[str]): Tags associated with the client Example: ['VIP', 'HIGH_VALUE'].
            controls (list[str]): List of control measures applied (DEPRECATED) Example: ['enhanced-due-diligence',
                'quarterly-review'].
            created_at (str): ISO Date when the client record was created Example: 2023-01-01T00:00:00Z.
            updated_at (str): ISO Date when the client record was last updated Example: 2023-01-15T00:00:00Z.
            reference_id (str | Unset): External reference ID for the client Example: CLIENT_REF_001.
            alerts (list[str] | Unset): List of alert IDs associated with the client Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
            source_of_funds_info (CorporateClientSourceOfFundsDto | Unset):
            adverse_media (CorporateClientAdverseMediaDto | Unset):
            political_exposure (CorporateClientPEPDto | Unset):
            sanctions (CorporateClientSanctionsDto | Unset):
            screening (CorporateClientScreeningDto | Unset):
            current_risk (RiskDto | Unset):
            onboarding_risk (RiskDto | Unset):
            custom_fields (CorporateClientDtoCustomFields | Unset): Custom fields data
            financial_operations (list[str] | Unset): List of financial operation IDs associated with the client Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
            contact (CorporateClientContactDto | Unset):
            members (CorporateClientMembersDto | Unset):
            declared_assets (list[str] | Unset): Array of asset symbols the client is expected to trade with (Maximum 50)
                Example: ['BTC', 'ETH', 'USDT'].
            integrations (CorporateClientIntegrationsDto | Unset):
            partner_client_id (str | Unset): ID or referenceId of the partner corporate client Example:
                123e4567-e89b-12d3-a456-426614174000.
     """

    id: str
    account_status: CorporateClientDtoAccountStatus
    activity_status: CorporateClientDtoActivityStatus
    address: CorporateClientAddressDto
    application: CorporateClientApplicationDto
    business: CorporateClientBusinessDto
    general: CorporateClientGeneralDto
    risk_history: list[RiskDto]
    tags: list[str]
    controls: list[str]
    created_at: str
    updated_at: str
    reference_id: str | Unset = UNSET
    alerts: list[str] | Unset = UNSET
    source_of_funds_info: CorporateClientSourceOfFundsDto | Unset = UNSET
    adverse_media: CorporateClientAdverseMediaDto | Unset = UNSET
    political_exposure: CorporateClientPEPDto | Unset = UNSET
    sanctions: CorporateClientSanctionsDto | Unset = UNSET
    screening: CorporateClientScreeningDto | Unset = UNSET
    current_risk: RiskDto | Unset = UNSET
    onboarding_risk: RiskDto | Unset = UNSET
    custom_fields: CorporateClientDtoCustomFields | Unset = UNSET
    financial_operations: list[str] | Unset = UNSET
    contact: CorporateClientContactDto | Unset = UNSET
    members: CorporateClientMembersDto | Unset = UNSET
    declared_assets: list[str] | Unset = UNSET
    integrations: CorporateClientIntegrationsDto | Unset = UNSET
    partner_client_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.corporate_client_address_dto import CorporateClientAddressDto
        from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
        from ..models.corporate_client_application_dto import CorporateClientApplicationDto
        from ..models.corporate_client_business_dto import CorporateClientBusinessDto
        from ..models.corporate_client_contact_dto import CorporateClientContactDto
        from ..models.corporate_client_dto_custom_fields import CorporateClientDtoCustomFields
        from ..models.corporate_client_general_dto import CorporateClientGeneralDto
        from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
        from ..models.corporate_client_members_dto import CorporateClientMembersDto
        from ..models.corporate_client_pep_dto import CorporateClientPEPDto
        from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
        from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
        from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
        from ..models.risk_dto import RiskDto
        id = self.id

        account_status = self.account_status.value

        activity_status = self.activity_status.value

        address = self.address.to_dict()

        application = self.application.to_dict()

        business = self.business.to_dict()

        general = self.general.to_dict()

        risk_history = []
        for risk_history_item_data in self.risk_history:
            risk_history_item = risk_history_item_data.to_dict()
            risk_history.append(risk_history_item)



        tags = self.tags



        controls = self.controls



        created_at = self.created_at

        updated_at = self.updated_at

        reference_id = self.reference_id

        alerts: list[str] | Unset = UNSET
        if not isinstance(self.alerts, Unset):
            alerts = self.alerts



        source_of_funds_info: dict[str, Any] | Unset = UNSET
        if not isinstance(self.source_of_funds_info, Unset):
            source_of_funds_info = self.source_of_funds_info.to_dict()

        adverse_media: dict[str, Any] | Unset = UNSET
        if not isinstance(self.adverse_media, Unset):
            adverse_media = self.adverse_media.to_dict()

        political_exposure: dict[str, Any] | Unset = UNSET
        if not isinstance(self.political_exposure, Unset):
            political_exposure = self.political_exposure.to_dict()

        sanctions: dict[str, Any] | Unset = UNSET
        if not isinstance(self.sanctions, Unset):
            sanctions = self.sanctions.to_dict()

        screening: dict[str, Any] | Unset = UNSET
        if not isinstance(self.screening, Unset):
            screening = self.screening.to_dict()

        current_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.current_risk, Unset):
            current_risk = self.current_risk.to_dict()

        onboarding_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.onboarding_risk, Unset):
            onboarding_risk = self.onboarding_risk.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        financial_operations: list[str] | Unset = UNSET
        if not isinstance(self.financial_operations, Unset):
            financial_operations = self.financial_operations



        contact: dict[str, Any] | Unset = UNSET
        if not isinstance(self.contact, Unset):
            contact = self.contact.to_dict()

        members: dict[str, Any] | Unset = UNSET
        if not isinstance(self.members, Unset):
            members = self.members.to_dict()

        declared_assets: list[str] | Unset = UNSET
        if not isinstance(self.declared_assets, Unset):
            declared_assets = self.declared_assets



        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()

        partner_client_id = self.partner_client_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "accountStatus": account_status,
            "activityStatus": activity_status,
            "address": address,
            "application": application,
            "business": business,
            "general": general,
            "riskHistory": risk_history,
            "tags": tags,
            "controls": controls,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if alerts is not UNSET:
            field_dict["alerts"] = alerts
        if source_of_funds_info is not UNSET:
            field_dict["sourceOfFundsInfo"] = source_of_funds_info
        if adverse_media is not UNSET:
            field_dict["adverseMedia"] = adverse_media
        if political_exposure is not UNSET:
            field_dict["politicalExposure"] = political_exposure
        if sanctions is not UNSET:
            field_dict["sanctions"] = sanctions
        if screening is not UNSET:
            field_dict["screening"] = screening
        if current_risk is not UNSET:
            field_dict["currentRisk"] = current_risk
        if onboarding_risk is not UNSET:
            field_dict["onboardingRisk"] = onboarding_risk
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if financial_operations is not UNSET:
            field_dict["financialOperations"] = financial_operations
        if contact is not UNSET:
            field_dict["contact"] = contact
        if members is not UNSET:
            field_dict["members"] = members
        if declared_assets is not UNSET:
            field_dict["declaredAssets"] = declared_assets
        if integrations is not UNSET:
            field_dict["integrations"] = integrations
        if partner_client_id is not UNSET:
            field_dict["partnerClientId"] = partner_client_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.corporate_client_address_dto import CorporateClientAddressDto
        from ..models.corporate_client_adverse_media_dto import CorporateClientAdverseMediaDto
        from ..models.corporate_client_application_dto import CorporateClientApplicationDto
        from ..models.corporate_client_business_dto import CorporateClientBusinessDto
        from ..models.corporate_client_contact_dto import CorporateClientContactDto
        from ..models.corporate_client_dto_custom_fields import CorporateClientDtoCustomFields
        from ..models.corporate_client_general_dto import CorporateClientGeneralDto
        from ..models.corporate_client_integrations_dto import CorporateClientIntegrationsDto
        from ..models.corporate_client_members_dto import CorporateClientMembersDto
        from ..models.corporate_client_pep_dto import CorporateClientPEPDto
        from ..models.corporate_client_sanctions_dto import CorporateClientSanctionsDto
        from ..models.corporate_client_screening_dto import CorporateClientScreeningDto
        from ..models.corporate_client_source_of_funds_dto import CorporateClientSourceOfFundsDto
        from ..models.risk_dto import RiskDto
        d = dict(src_dict)
        id = d.pop("id")

        account_status = CorporateClientDtoAccountStatus(d.pop("accountStatus"))




        activity_status = CorporateClientDtoActivityStatus(d.pop("activityStatus"))




        address = CorporateClientAddressDto.from_dict(d.pop("address"))




        application = CorporateClientApplicationDto.from_dict(d.pop("application"))




        business = CorporateClientBusinessDto.from_dict(d.pop("business"))




        general = CorporateClientGeneralDto.from_dict(d.pop("general"))




        risk_history = []
        _risk_history = d.pop("riskHistory")
        for risk_history_item_data in (_risk_history):
            risk_history_item = RiskDto.from_dict(risk_history_item_data)



            risk_history.append(risk_history_item)


        tags = cast(list[str], d.pop("tags"))


        controls = cast(list[str], d.pop("controls"))


        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        reference_id = d.pop("referenceId", UNSET)

        alerts = cast(list[str], d.pop("alerts", UNSET))


        _source_of_funds_info = d.pop("sourceOfFundsInfo", UNSET)
        source_of_funds_info: CorporateClientSourceOfFundsDto | Unset
        if isinstance(_source_of_funds_info,  Unset):
            source_of_funds_info = UNSET
        else:
            source_of_funds_info = CorporateClientSourceOfFundsDto.from_dict(_source_of_funds_info)




        _adverse_media = d.pop("adverseMedia", UNSET)
        adverse_media: CorporateClientAdverseMediaDto | Unset
        if isinstance(_adverse_media,  Unset):
            adverse_media = UNSET
        else:
            adverse_media = CorporateClientAdverseMediaDto.from_dict(_adverse_media)




        _political_exposure = d.pop("politicalExposure", UNSET)
        political_exposure: CorporateClientPEPDto | Unset
        if isinstance(_political_exposure,  Unset):
            political_exposure = UNSET
        else:
            political_exposure = CorporateClientPEPDto.from_dict(_political_exposure)




        _sanctions = d.pop("sanctions", UNSET)
        sanctions: CorporateClientSanctionsDto | Unset
        if isinstance(_sanctions,  Unset):
            sanctions = UNSET
        else:
            sanctions = CorporateClientSanctionsDto.from_dict(_sanctions)




        _screening = d.pop("screening", UNSET)
        screening: CorporateClientScreeningDto | Unset
        if isinstance(_screening,  Unset):
            screening = UNSET
        else:
            screening = CorporateClientScreeningDto.from_dict(_screening)




        _current_risk = d.pop("currentRisk", UNSET)
        current_risk: RiskDto | Unset
        if isinstance(_current_risk,  Unset):
            current_risk = UNSET
        else:
            current_risk = RiskDto.from_dict(_current_risk)




        _onboarding_risk = d.pop("onboardingRisk", UNSET)
        onboarding_risk: RiskDto | Unset
        if isinstance(_onboarding_risk,  Unset):
            onboarding_risk = UNSET
        else:
            onboarding_risk = RiskDto.from_dict(_onboarding_risk)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: CorporateClientDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = CorporateClientDtoCustomFields.from_dict(_custom_fields)




        financial_operations = cast(list[str], d.pop("financialOperations", UNSET))


        _contact = d.pop("contact", UNSET)
        contact: CorporateClientContactDto | Unset
        if isinstance(_contact,  Unset):
            contact = UNSET
        else:
            contact = CorporateClientContactDto.from_dict(_contact)




        _members = d.pop("members", UNSET)
        members: CorporateClientMembersDto | Unset
        if isinstance(_members,  Unset):
            members = UNSET
        else:
            members = CorporateClientMembersDto.from_dict(_members)




        declared_assets = cast(list[str], d.pop("declaredAssets", UNSET))


        _integrations = d.pop("integrations", UNSET)
        integrations: CorporateClientIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = CorporateClientIntegrationsDto.from_dict(_integrations)




        partner_client_id = d.pop("partnerClientId", UNSET)

        corporate_client_dto = cls(
            id=id,
            account_status=account_status,
            activity_status=activity_status,
            address=address,
            application=application,
            business=business,
            general=general,
            risk_history=risk_history,
            tags=tags,
            controls=controls,
            created_at=created_at,
            updated_at=updated_at,
            reference_id=reference_id,
            alerts=alerts,
            source_of_funds_info=source_of_funds_info,
            adverse_media=adverse_media,
            political_exposure=political_exposure,
            sanctions=sanctions,
            screening=screening,
            current_risk=current_risk,
            onboarding_risk=onboarding_risk,
            custom_fields=custom_fields,
            financial_operations=financial_operations,
            contact=contact,
            members=members,
            declared_assets=declared_assets,
            integrations=integrations,
            partner_client_id=partner_client_id,
        )


        corporate_client_dto.additional_properties = d
        return corporate_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
