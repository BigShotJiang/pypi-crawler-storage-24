from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_transaction_dto_transfer_type import UpdateTransactionDtoTransferType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.transaction_amount_dto import TransactionAmountDto
  from ..models.transaction_integrations_dto import TransactionIntegrationsDto
  from ..models.update_transaction_dto_custom_fields import UpdateTransactionDtoCustomFields





T = TypeVar("T", bound="UpdateTransactionDto")



@_attrs_define
class UpdateTransactionDto:
    """ 
        Attributes:
            tx_hash (str | Unset): Blockchain transaction hash Example:
                0x742d35Cc6634C0532925a3b844Bc454e4438f44e123456789abcdef.
            amount (TransactionAmountDto | Unset):
            converted_amount (TransactionAmountDto | Unset):
            payment_method (str | Unset): Method used for payment Example: CRYPTO_TRANSFER.
            payment_rail (str | Unset): Payment network or settlement rail used for the transaction. Predefined values:
                SWIFT, SEPA, Fedwire, ACH, NIP, PIX, MobileMoney, SPEI. Custom values are also accepted. Example: SWIFT.
            transfer_type (UpdateTransactionDtoTransferType | Unset): Categorization of the transfer nature Example:
                INTERNATIONAL.
            integrations (TransactionIntegrationsDto | Unset):
            custom_fields (UpdateTransactionDtoCustomFields | Unset): Custom fields data
     """

    tx_hash: str | Unset = UNSET
    amount: TransactionAmountDto | Unset = UNSET
    converted_amount: TransactionAmountDto | Unset = UNSET
    payment_method: str | Unset = UNSET
    payment_rail: str | Unset = UNSET
    transfer_type: UpdateTransactionDtoTransferType | Unset = UNSET
    integrations: TransactionIntegrationsDto | Unset = UNSET
    custom_fields: UpdateTransactionDtoCustomFields | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.transaction_amount_dto import TransactionAmountDto
        from ..models.transaction_integrations_dto import TransactionIntegrationsDto
        from ..models.update_transaction_dto_custom_fields import UpdateTransactionDtoCustomFields
        tx_hash = self.tx_hash

        amount: dict[str, Any] | Unset = UNSET
        if not isinstance(self.amount, Unset):
            amount = self.amount.to_dict()

        converted_amount: dict[str, Any] | Unset = UNSET
        if not isinstance(self.converted_amount, Unset):
            converted_amount = self.converted_amount.to_dict()

        payment_method = self.payment_method

        payment_rail = self.payment_rail

        transfer_type: str | Unset = UNSET
        if not isinstance(self.transfer_type, Unset):
            transfer_type = self.transfer_type.value


        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if tx_hash is not UNSET:
            field_dict["txHash"] = tx_hash
        if amount is not UNSET:
            field_dict["amount"] = amount
        if converted_amount is not UNSET:
            field_dict["convertedAmount"] = converted_amount
        if payment_method is not UNSET:
            field_dict["paymentMethod"] = payment_method
        if payment_rail is not UNSET:
            field_dict["paymentRail"] = payment_rail
        if transfer_type is not UNSET:
            field_dict["transferType"] = transfer_type
        if integrations is not UNSET:
            field_dict["integrations"] = integrations
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.transaction_amount_dto import TransactionAmountDto
        from ..models.transaction_integrations_dto import TransactionIntegrationsDto
        from ..models.update_transaction_dto_custom_fields import UpdateTransactionDtoCustomFields
        d = dict(src_dict)
        tx_hash = d.pop("txHash", UNSET)

        _amount = d.pop("amount", UNSET)
        amount: TransactionAmountDto | Unset
        if isinstance(_amount,  Unset):
            amount = UNSET
        else:
            amount = TransactionAmountDto.from_dict(_amount)




        _converted_amount = d.pop("convertedAmount", UNSET)
        converted_amount: TransactionAmountDto | Unset
        if isinstance(_converted_amount,  Unset):
            converted_amount = UNSET
        else:
            converted_amount = TransactionAmountDto.from_dict(_converted_amount)




        payment_method = d.pop("paymentMethod", UNSET)

        payment_rail = d.pop("paymentRail", UNSET)

        _transfer_type = d.pop("transferType", UNSET)
        transfer_type: UpdateTransactionDtoTransferType | Unset
        if isinstance(_transfer_type,  Unset):
            transfer_type = UNSET
        else:
            transfer_type = UpdateTransactionDtoTransferType(_transfer_type)




        _integrations = d.pop("integrations", UNSET)
        integrations: TransactionIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = TransactionIntegrationsDto.from_dict(_integrations)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: UpdateTransactionDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = UpdateTransactionDtoCustomFields.from_dict(_custom_fields)




        update_transaction_dto = cls(
            tx_hash=tx_hash,
            amount=amount,
            converted_amount=converted_amount,
            payment_method=payment_method,
            payment_rail=payment_rail,
            transfer_type=transfer_type,
            integrations=integrations,
            custom_fields=custom_fields,
        )


        update_transaction_dto.additional_properties = d
        return update_transaction_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
