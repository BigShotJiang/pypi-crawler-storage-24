from enum import Enum

class ChecklistTemplateResponseDtoEntityType(str, Enum):
    ALERT = "ALERT"
    CASE = "CASE"
    CORPORATE_CLIENT = "CORPORATE_CLIENT"
    INDIVIDUAL_CLIENT = "INDIVIDUAL_CLIENT"

    def __str__(self) -> str:
        return str(self.value)
