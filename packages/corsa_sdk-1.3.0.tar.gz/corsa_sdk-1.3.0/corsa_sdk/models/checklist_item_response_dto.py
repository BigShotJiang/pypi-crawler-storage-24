from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.checklist_item_response_dto_category import ChecklistItemResponseDtoCategory
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.checklist_item_response_dto_custom_fields import ChecklistItemResponseDtoCustomFields
  from ..models.checklist_item_response_dto_status_options_item import ChecklistItemResponseDtoStatusOptionsItem





T = TypeVar("T", bound="ChecklistItemResponseDto")



@_attrs_define
class ChecklistItemResponseDto:
    """ 
        Attributes:
            id (str): Unique identifier for the checklist item Example: 123e4567-e89b-12d3-a456-426614174000.
            name (str): Name of the checklist item Example: Passport Copy.
            category (ChecklistItemResponseDtoCategory): Category of the checklist item Example: PERSONAL_IDENTIFICATION.
            status (str): Current status of the checklist item (can be default or custom status) Example: SUBMITTED.
            is_archived (bool): Whether this item is archived
            status_options (list[ChecklistItemResponseDtoStatusOptionsItem]): Status options for the checklist item Example:
                [{'value': 'SUBMITTED', 'label': 'Submitted'}, {'value': 'COMPLETED', 'label': 'Completed'}].
            created_at (datetime.datetime): When the item was created Example: 2024-01-15T10:30:00Z.
            updated_at (datetime.datetime): When the item was last updated Example: 2024-01-15T10:30:00Z.
            note (str | Unset): Note/description of the checklist item Example: Please provide a clear copy of your
                passport.
            document_url (str | Unset): URL to the attached document Example: https://example.com/document.pdf.
            attachment_id (str | Unset): Attachment ID from the attachment service Example: attachment-123-uuid.
            document_mime_type (str | Unset): MIME type of the attached document Example: application/pdf.
            document_submission_date (datetime.datetime | Unset): Date when the document was submitted Example:
                2024-01-15T10:30:00Z.
            expiration_date (datetime.datetime | Unset): Expiration date for the checklist item Example:
                2024-12-31T23:59:59Z.
            custom_fields (ChecklistItemResponseDtoCustomFields | Unset): Additional custom fields for the checklist item
                Example: {'priority': {'label': 'Priority Level', 'value': 'high', 'description': 'Urgency level of this item',
                'category': 'workflow', 'possibleValues': ['low', 'medium', 'high', 'critical'], 'immutable': False}, 'tags':
                {'label': 'Tags', 'value': ['urgent', 'review'], 'description': 'Classification tags', 'category':
                'organization', 'immutable': False}}.
     """

    id: str
    name: str
    category: ChecklistItemResponseDtoCategory
    status: str
    is_archived: bool
    status_options: list[ChecklistItemResponseDtoStatusOptionsItem]
    created_at: datetime.datetime
    updated_at: datetime.datetime
    note: str | Unset = UNSET
    document_url: str | Unset = UNSET
    attachment_id: str | Unset = UNSET
    document_mime_type: str | Unset = UNSET
    document_submission_date: datetime.datetime | Unset = UNSET
    expiration_date: datetime.datetime | Unset = UNSET
    custom_fields: ChecklistItemResponseDtoCustomFields | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.checklist_item_response_dto_custom_fields import ChecklistItemResponseDtoCustomFields
        from ..models.checklist_item_response_dto_status_options_item import ChecklistItemResponseDtoStatusOptionsItem
        id = self.id

        name = self.name

        category = self.category.value

        status = self.status

        is_archived = self.is_archived

        status_options = []
        for status_options_item_data in self.status_options:
            status_options_item = status_options_item_data.to_dict()
            status_options.append(status_options_item)



        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        note = self.note

        document_url = self.document_url

        attachment_id = self.attachment_id

        document_mime_type = self.document_mime_type

        document_submission_date: str | Unset = UNSET
        if not isinstance(self.document_submission_date, Unset):
            document_submission_date = self.document_submission_date.isoformat()

        expiration_date: str | Unset = UNSET
        if not isinstance(self.expiration_date, Unset):
            expiration_date = self.expiration_date.isoformat()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "category": category,
            "status": status,
            "isArchived": is_archived,
            "statusOptions": status_options,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })
        if note is not UNSET:
            field_dict["note"] = note
        if document_url is not UNSET:
            field_dict["documentUrl"] = document_url
        if attachment_id is not UNSET:
            field_dict["attachmentId"] = attachment_id
        if document_mime_type is not UNSET:
            field_dict["documentMimeType"] = document_mime_type
        if document_submission_date is not UNSET:
            field_dict["documentSubmissionDate"] = document_submission_date
        if expiration_date is not UNSET:
            field_dict["expirationDate"] = expiration_date
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.checklist_item_response_dto_custom_fields import ChecklistItemResponseDtoCustomFields
        from ..models.checklist_item_response_dto_status_options_item import ChecklistItemResponseDtoStatusOptionsItem
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        category = ChecklistItemResponseDtoCategory(d.pop("category"))




        status = d.pop("status")

        is_archived = d.pop("isArchived")

        status_options = []
        _status_options = d.pop("statusOptions")
        for status_options_item_data in (_status_options):
            status_options_item = ChecklistItemResponseDtoStatusOptionsItem.from_dict(status_options_item_data)



            status_options.append(status_options_item)


        created_at = isoparse(d.pop("createdAt"))




        updated_at = isoparse(d.pop("updatedAt"))




        note = d.pop("note", UNSET)

        document_url = d.pop("documentUrl", UNSET)

        attachment_id = d.pop("attachmentId", UNSET)

        document_mime_type = d.pop("documentMimeType", UNSET)

        _document_submission_date = d.pop("documentSubmissionDate", UNSET)
        document_submission_date: datetime.datetime | Unset
        if isinstance(_document_submission_date,  Unset):
            document_submission_date = UNSET
        else:
            document_submission_date = isoparse(_document_submission_date)




        _expiration_date = d.pop("expirationDate", UNSET)
        expiration_date: datetime.datetime | Unset
        if isinstance(_expiration_date,  Unset):
            expiration_date = UNSET
        else:
            expiration_date = isoparse(_expiration_date)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: ChecklistItemResponseDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = ChecklistItemResponseDtoCustomFields.from_dict(_custom_fields)




        checklist_item_response_dto = cls(
            id=id,
            name=name,
            category=category,
            status=status,
            is_archived=is_archived,
            status_options=status_options,
            created_at=created_at,
            updated_at=updated_at,
            note=note,
            document_url=document_url,
            attachment_id=attachment_id,
            document_mime_type=document_mime_type,
            document_submission_date=document_submission_date,
            expiration_date=expiration_date,
            custom_fields=custom_fields,
        )


        checklist_item_response_dto.additional_properties = d
        return checklist_item_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
