from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.corporate_client_source_of_funds_dto_source_of_funds import CorporateClientSourceOfFundsDtoSourceOfFunds
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CorporateClientSourceOfFundsDto")



@_attrs_define
class CorporateClientSourceOfFundsDto:
    """ 
        Attributes:
            source_of_funds (CorporateClientSourceOfFundsDtoSourceOfFunds | Unset): Source of funds Example:
                PROPRIETARY_FUNDS.
            source_of_funds_details (str | Unset): Additional details about the source of funds Example: Investment
                portfolio.
            source_of_funds_jurisdictions (list[str] | Unset): Country codes where the funds originate from (maximum 20,
                always sorted lexicographically) Example: ['GBR', 'USA'].
            monthly_transaction_volume (float | Unset): Estimated monthly transaction volume Example: 500000.
            annual_transaction_volume (float | Unset): Estimated annual transaction volume Example: 6000000.
     """

    source_of_funds: CorporateClientSourceOfFundsDtoSourceOfFunds | Unset = UNSET
    source_of_funds_details: str | Unset = UNSET
    source_of_funds_jurisdictions: list[str] | Unset = UNSET
    monthly_transaction_volume: float | Unset = UNSET
    annual_transaction_volume: float | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        source_of_funds: str | Unset = UNSET
        if not isinstance(self.source_of_funds, Unset):
            source_of_funds = self.source_of_funds.value


        source_of_funds_details = self.source_of_funds_details

        source_of_funds_jurisdictions: list[str] | Unset = UNSET
        if not isinstance(self.source_of_funds_jurisdictions, Unset):
            source_of_funds_jurisdictions = self.source_of_funds_jurisdictions



        monthly_transaction_volume = self.monthly_transaction_volume

        annual_transaction_volume = self.annual_transaction_volume


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if source_of_funds is not UNSET:
            field_dict["sourceOfFunds"] = source_of_funds
        if source_of_funds_details is not UNSET:
            field_dict["sourceOfFundsDetails"] = source_of_funds_details
        if source_of_funds_jurisdictions is not UNSET:
            field_dict["sourceOfFundsJurisdictions"] = source_of_funds_jurisdictions
        if monthly_transaction_volume is not UNSET:
            field_dict["monthlyTransactionVolume"] = monthly_transaction_volume
        if annual_transaction_volume is not UNSET:
            field_dict["annualTransactionVolume"] = annual_transaction_volume

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _source_of_funds = d.pop("sourceOfFunds", UNSET)
        source_of_funds: CorporateClientSourceOfFundsDtoSourceOfFunds | Unset
        if isinstance(_source_of_funds,  Unset):
            source_of_funds = UNSET
        else:
            source_of_funds = CorporateClientSourceOfFundsDtoSourceOfFunds(_source_of_funds)




        source_of_funds_details = d.pop("sourceOfFundsDetails", UNSET)

        source_of_funds_jurisdictions = cast(list[str], d.pop("sourceOfFundsJurisdictions", UNSET))


        monthly_transaction_volume = d.pop("monthlyTransactionVolume", UNSET)

        annual_transaction_volume = d.pop("annualTransactionVolume", UNSET)

        corporate_client_source_of_funds_dto = cls(
            source_of_funds=source_of_funds,
            source_of_funds_details=source_of_funds_details,
            source_of_funds_jurisdictions=source_of_funds_jurisdictions,
            monthly_transaction_volume=monthly_transaction_volume,
            annual_transaction_volume=annual_transaction_volume,
        )


        corporate_client_source_of_funds_dto.additional_properties = d
        return corporate_client_source_of_funds_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
