from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.fact_path_dto_entity import FactPathDtoEntity
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.participant_dto import ParticipantDto





T = TypeVar("T", bound="FactPathDto")



@_attrs_define
class FactPathDto:
    """ 
        Attributes:
            entity (FactPathDtoEntity): Root entity type Example: wallet.
            property_ (str): Property name Example: riskLevel.
            participant (ParticipantDto | Unset):
     """

    entity: FactPathDtoEntity
    property_: str
    participant: ParticipantDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.participant_dto import ParticipantDto
        entity = self.entity.value

        property_ = self.property_

        participant: dict[str, Any] | Unset = UNSET
        if not isinstance(self.participant, Unset):
            participant = self.participant.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "entity": entity,
            "property": property_,
        })
        if participant is not UNSET:
            field_dict["participant"] = participant

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.participant_dto import ParticipantDto
        d = dict(src_dict)
        entity = FactPathDtoEntity(d.pop("entity"))




        property_ = d.pop("property")

        _participant = d.pop("participant", UNSET)
        participant: ParticipantDto | Unset
        if isinstance(_participant,  Unset):
            participant = UNSET
        else:
            participant = ParticipantDto.from_dict(_participant)




        fact_path_dto = cls(
            entity=entity,
            property_=property_,
            participant=participant,
        )


        fact_path_dto.additional_properties = d
        return fact_path_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
