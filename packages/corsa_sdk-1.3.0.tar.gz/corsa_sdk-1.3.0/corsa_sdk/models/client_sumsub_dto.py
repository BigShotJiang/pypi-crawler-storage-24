from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.sumsub_verification_dto import SumsubVerificationDto





T = TypeVar("T", bound="ClientSumsubDto")



@_attrs_define
class ClientSumsubDto:
    """ 
        Attributes:
            id (str | Unset): Sumsub applicant ID Example: SUMSUB123.
            status (str | Unset): Status of the verification image Example: approved.
            reject_labels (list[str] | Unset): Reject labels if the image was rejected Example: ['DOCUMENT_PAGE_MISSING',
                'FRONT_SIDE_MISSING'].
            reason (str | Unset): Reason for rejection if applicable Example: Document is expired.
            verifications (list[SumsubVerificationDto] | Unset): Sumsub verifications
     """

    id: str | Unset = UNSET
    status: str | Unset = UNSET
    reject_labels: list[str] | Unset = UNSET
    reason: str | Unset = UNSET
    verifications: list[SumsubVerificationDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.sumsub_verification_dto import SumsubVerificationDto
        id = self.id

        status = self.status

        reject_labels: list[str] | Unset = UNSET
        if not isinstance(self.reject_labels, Unset):
            reject_labels = self.reject_labels



        reason = self.reason

        verifications: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.verifications, Unset):
            verifications = []
            for verifications_item_data in self.verifications:
                verifications_item = verifications_item_data.to_dict()
                verifications.append(verifications_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if id is not UNSET:
            field_dict["id"] = id
        if status is not UNSET:
            field_dict["status"] = status
        if reject_labels is not UNSET:
            field_dict["rejectLabels"] = reject_labels
        if reason is not UNSET:
            field_dict["reason"] = reason
        if verifications is not UNSET:
            field_dict["verifications"] = verifications

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.sumsub_verification_dto import SumsubVerificationDto
        d = dict(src_dict)
        id = d.pop("id", UNSET)

        status = d.pop("status", UNSET)

        reject_labels = cast(list[str], d.pop("rejectLabels", UNSET))


        reason = d.pop("reason", UNSET)

        _verifications = d.pop("verifications", UNSET)
        verifications: list[SumsubVerificationDto] | Unset = UNSET
        if _verifications is not UNSET:
            verifications = []
            for verifications_item_data in _verifications:
                verifications_item = SumsubVerificationDto.from_dict(verifications_item_data)



                verifications.append(verifications_item)


        client_sumsub_dto = cls(
            id=id,
            status=status,
            reject_labels=reject_labels,
            reason=reason,
            verifications=verifications,
        )


        client_sumsub_dto.additional_properties = d
        return client_sumsub_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
