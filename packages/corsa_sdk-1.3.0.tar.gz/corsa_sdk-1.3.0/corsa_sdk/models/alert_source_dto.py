from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.alert_source_dto_alert_source import AlertSourceDtoAlertSource
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.alert_source_dto_vendor_data import AlertSourceDtoVendorData





T = TypeVar("T", bound="AlertSourceDto")



@_attrs_define
class AlertSourceDto:
    """ 
        Attributes:
            vendor (str | Unset): The vendor that generated the alert Example: CHAINALYSIS.
            vendor_alert_id (str | Unset): The ID of the alert in the vendor system Example: CHAIN-123.
            vendor_data (AlertSourceDtoVendorData | Unset): Additional data provided by the vendor Example: {'riskScore':
                85, 'category': 'high_risk_jurisdiction'}.
            link (str | Unset): Link to the alert details in the vendor system Example: https://vendor.com/alerts/CHAIN-123.
            alert_source (AlertSourceDtoAlertSource | Unset): The source of the alert Example: MANUAL.
     """

    vendor: str | Unset = UNSET
    vendor_alert_id: str | Unset = UNSET
    vendor_data: AlertSourceDtoVendorData | Unset = UNSET
    link: str | Unset = UNSET
    alert_source: AlertSourceDtoAlertSource | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.alert_source_dto_vendor_data import AlertSourceDtoVendorData
        vendor = self.vendor

        vendor_alert_id = self.vendor_alert_id

        vendor_data: dict[str, Any] | Unset = UNSET
        if not isinstance(self.vendor_data, Unset):
            vendor_data = self.vendor_data.to_dict()

        link = self.link

        alert_source: str | Unset = UNSET
        if not isinstance(self.alert_source, Unset):
            alert_source = self.alert_source.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if vendor is not UNSET:
            field_dict["vendor"] = vendor
        if vendor_alert_id is not UNSET:
            field_dict["vendorAlertId"] = vendor_alert_id
        if vendor_data is not UNSET:
            field_dict["vendorData"] = vendor_data
        if link is not UNSET:
            field_dict["link"] = link
        if alert_source is not UNSET:
            field_dict["alertSource"] = alert_source

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_source_dto_vendor_data import AlertSourceDtoVendorData
        d = dict(src_dict)
        vendor = d.pop("vendor", UNSET)

        vendor_alert_id = d.pop("vendorAlertId", UNSET)

        _vendor_data = d.pop("vendorData", UNSET)
        vendor_data: AlertSourceDtoVendorData | Unset
        if isinstance(_vendor_data,  Unset):
            vendor_data = UNSET
        else:
            vendor_data = AlertSourceDtoVendorData.from_dict(_vendor_data)




        link = d.pop("link", UNSET)

        _alert_source = d.pop("alertSource", UNSET)
        alert_source: AlertSourceDtoAlertSource | Unset
        if isinstance(_alert_source,  Unset):
            alert_source = UNSET
        else:
            alert_source = AlertSourceDtoAlertSource(_alert_source)




        alert_source_dto = cls(
            vendor=vendor,
            vendor_alert_id=vendor_alert_id,
            vendor_data=vendor_data,
            link=link,
            alert_source=alert_source,
        )


        alert_source_dto.additional_properties = d
        return alert_source_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
