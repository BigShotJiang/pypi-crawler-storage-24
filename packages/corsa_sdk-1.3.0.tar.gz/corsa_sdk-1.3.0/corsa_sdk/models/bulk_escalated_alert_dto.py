from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="BulkEscalatedAlertDto")



@_attrs_define
class BulkEscalatedAlertDto:
    """ 
        Attributes:
            id (str): The ID of the escalated alert Example: 123e4567-e89b-12d3-a456-426614174000.
            reference_id (str | Unset): The reference ID of the escalated alert Example: ALT-REF-001.
            case_id (str | Unset): The ID of the case created from the escalation Example:
                123e4567-e89b-12d3-a456-426614174000.
     """

    id: str
    reference_id: str | Unset = UNSET
    case_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        reference_id = self.reference_id

        case_id = self.case_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if case_id is not UNSET:
            field_dict["caseId"] = case_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        reference_id = d.pop("referenceId", UNSET)

        case_id = d.pop("caseId", UNSET)

        bulk_escalated_alert_dto = cls(
            id=id,
            reference_id=reference_id,
            case_id=case_id,
        )


        bulk_escalated_alert_dto.additional_properties = d
        return bulk_escalated_alert_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
