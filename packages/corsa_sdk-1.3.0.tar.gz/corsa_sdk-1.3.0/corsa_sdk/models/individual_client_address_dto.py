from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="IndividualClientAddressDto")



@_attrs_define
class IndividualClientAddressDto:
    """ 
        Attributes:
            address_line_1 (str | Unset): First line of the address Example: 123 Main Street.
            address_line_2 (str | Unset): Second line of the address Example: Apt 4B.
            city (str | Unset): City name Example: New York.
            country (str | Unset): Country code in ISO format Example: USA.
            postal_code (str | Unset): Postal code Example: 10001.
     """

    address_line_1: str | Unset = UNSET
    address_line_2: str | Unset = UNSET
    city: str | Unset = UNSET
    country: str | Unset = UNSET
    postal_code: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        address_line_1 = self.address_line_1

        address_line_2 = self.address_line_2

        city = self.city

        country = self.country

        postal_code = self.postal_code


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if address_line_1 is not UNSET:
            field_dict["addressLine1"] = address_line_1
        if address_line_2 is not UNSET:
            field_dict["addressLine2"] = address_line_2
        if city is not UNSET:
            field_dict["city"] = city
        if country is not UNSET:
            field_dict["country"] = country
        if postal_code is not UNSET:
            field_dict["postalCode"] = postal_code

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        address_line_1 = d.pop("addressLine1", UNSET)

        address_line_2 = d.pop("addressLine2", UNSET)

        city = d.pop("city", UNSET)

        country = d.pop("country", UNSET)

        postal_code = d.pop("postalCode", UNSET)

        individual_client_address_dto = cls(
            address_line_1=address_line_1,
            address_line_2=address_line_2,
            city=city,
            country=country,
            postal_code=postal_code,
        )


        individual_client_address_dto.additional_properties = d
        return individual_client_address_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
