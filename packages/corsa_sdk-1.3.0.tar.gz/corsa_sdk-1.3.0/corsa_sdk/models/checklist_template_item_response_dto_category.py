from enum import Enum

class ChecklistTemplateItemResponseDtoCategory(str, Enum):
    CORPORATE_INFORMATION = "CORPORATE_INFORMATION"
    DECLARATIONS_COMPLIANCE = "DECLARATIONS_COMPLIANCE"
    FINANCIAL_INFORMATION = "FINANCIAL_INFORMATION"
    OTHER = "OTHER"
    PERSONAL_IDENTIFICATION = "PERSONAL_IDENTIFICATION"

    def __str__(self) -> str:
        return str(self.value)
