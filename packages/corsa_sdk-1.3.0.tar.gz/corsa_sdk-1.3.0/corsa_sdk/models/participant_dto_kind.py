from enum import Enum

class ParticipantDtoKind(str, Enum):
    BANKACCOUNT = "BankAccount"
    CLIENT = "Client"
    WALLET = "Wallet"

    def __str__(self) -> str:
        return str(self.value)
