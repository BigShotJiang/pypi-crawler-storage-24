from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_alert_dto import CreateAlertDto





T = TypeVar("T", bound="BatchCreateAlertsDto")



@_attrs_define
class BatchCreateAlertsDto:
    """ 
        Attributes:
            alerts (list[CreateAlertDto]): Array of alerts to create in batch (maximum 50 alerts) Example: [{'category':
                'KYC', 'description': 'Suspicious pattern detected', 'priority': 'HIGH', 'status': 'NEW'}].
            upsert (bool | Unset): Whether to upsert the alerts Default: False.
     """

    alerts: list[CreateAlertDto]
    upsert: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_alert_dto import CreateAlertDto
        alerts = []
        for alerts_item_data in self.alerts:
            alerts_item = alerts_item_data.to_dict()
            alerts.append(alerts_item)



        upsert = self.upsert


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "alerts": alerts,
        })
        if upsert is not UNSET:
            field_dict["upsert"] = upsert

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_alert_dto import CreateAlertDto
        d = dict(src_dict)
        alerts = []
        _alerts = d.pop("alerts")
        for alerts_item_data in (_alerts):
            alerts_item = CreateAlertDto.from_dict(alerts_item_data)



            alerts.append(alerts_item)


        upsert = d.pop("upsert", UNSET)

        batch_create_alerts_dto = cls(
            alerts=alerts,
            upsert=upsert,
        )


        batch_create_alerts_dto.additional_properties = d
        return batch_create_alerts_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
