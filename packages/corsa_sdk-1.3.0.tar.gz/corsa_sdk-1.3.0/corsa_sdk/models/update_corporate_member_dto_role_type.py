from enum import Enum

class UpdateCorporateMemberDtoRoleType(str, Enum):
    AUTHORIZED_REPRESENTATIVE = "AUTHORIZED_REPRESENTATIVE"
    BENEFICIAL_OWNER = "BENEFICIAL_OWNER"
    DIRECTOR = "DIRECTOR"
    OFFICER = "OFFICER"
    OTHER = "OTHER"
    OWNER = "OWNER"
    PROTECTOR = "PROTECTOR"
    SETTLOR = "SETTLOR"
    SHAREHOLDER = "SHAREHOLDER"
    SIGNATORY = "SIGNATORY"
    TRUSTEE = "TRUSTEE"

    def __str__(self) -> str:
        return str(self.value)
