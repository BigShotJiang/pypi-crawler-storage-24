from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.bulk_update_case_status_dto_status import BulkUpdateCaseStatusDtoStatus
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="BulkUpdateCaseStatusDto")



@_attrs_define
class BulkUpdateCaseStatusDto:
    """ 
        Attributes:
            case_ids (list[str]): Array of case IDs or reference IDs (maximum 100) Example:
                ['123e4567-e89b-12d3-a456-426614174000', 'CASE-REF-001'].
            status (BulkUpdateCaseStatusDtoStatus): The new status to apply to all specified cases Example:
                UNDER_INVESTIGATION.
            reason (str | Unset): Reason for the status change Example: Batch triage complete.
            sub_status (str | Unset): Sub-status providing additional context Example: AWAITING_DOCUMENTS.
     """

    case_ids: list[str]
    status: BulkUpdateCaseStatusDtoStatus
    reason: str | Unset = UNSET
    sub_status: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        case_ids = self.case_ids



        status = self.status.value

        reason = self.reason

        sub_status = self.sub_status


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "caseIds": case_ids,
            "status": status,
        })
        if reason is not UNSET:
            field_dict["reason"] = reason
        if sub_status is not UNSET:
            field_dict["subStatus"] = sub_status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        case_ids = cast(list[str], d.pop("caseIds"))


        status = BulkUpdateCaseStatusDtoStatus(d.pop("status"))




        reason = d.pop("reason", UNSET)

        sub_status = d.pop("subStatus", UNSET)

        bulk_update_case_status_dto = cls(
            case_ids=case_ids,
            status=status,
            reason=reason,
            sub_status=sub_status,
        )


        bulk_update_case_status_dto.additional_properties = d
        return bulk_update_case_status_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
