from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.participant_dto_kind import ParticipantDtoKind
from ..models.participant_dto_role import ParticipantDtoRole






T = TypeVar("T", bound="ParticipantDto")



@_attrs_define
class ParticipantDto:
    """ 
        Attributes:
            role (ParticipantDtoRole): Participant role in transaction Example: source.
            kind (ParticipantDtoKind): Type of participant Example: Wallet.
     """

    role: ParticipantDtoRole
    kind: ParticipantDtoKind
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        role = self.role.value

        kind = self.kind.value


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "role": role,
            "kind": kind,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        role = ParticipantDtoRole(d.pop("role"))




        kind = ParticipantDtoKind(d.pop("kind"))




        participant_dto = cls(
            role=role,
            kind=kind,
        )


        participant_dto.additional_properties = d
        return participant_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
