from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.individual_client_general_information_dto_gender import IndividualClientGeneralInformationDtoGender
from ..types import UNSET, Unset






T = TypeVar("T", bound="IndividualClientGeneralInformationDto")



@_attrs_define
class IndividualClientGeneralInformationDto:
    """ 
        Attributes:
            first_name (str | Unset): First name of the client Example: John.
            middle_name (str | Unset): Middle name of the client Example: Michael.
            last_name (str | Unset): Last name of the client Example: Doe.
            gender (IndividualClientGeneralInformationDtoGender | Unset): Gender of the client Example: MALE.
            date_of_birth (str | Unset): Date of birth of the client in YYYY-MM-DD format Example: 1993-08-15.
            citizenship (str | Unset): Country code of citizenship Example: USA.
            jurisdiction (str | Unset): Jurisdiction country code (ISO 3166-1 alpha-2) Example: US.
            personal_id (str | Unset): Personal identification number Example: 123-45-6789.
     """

    first_name: str | Unset = UNSET
    middle_name: str | Unset = UNSET
    last_name: str | Unset = UNSET
    gender: IndividualClientGeneralInformationDtoGender | Unset = UNSET
    date_of_birth: str | Unset = UNSET
    citizenship: str | Unset = UNSET
    jurisdiction: str | Unset = UNSET
    personal_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        first_name = self.first_name

        middle_name = self.middle_name

        last_name = self.last_name

        gender: str | Unset = UNSET
        if not isinstance(self.gender, Unset):
            gender = self.gender.value


        date_of_birth = self.date_of_birth

        citizenship = self.citizenship

        jurisdiction = self.jurisdiction

        personal_id = self.personal_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if first_name is not UNSET:
            field_dict["firstName"] = first_name
        if middle_name is not UNSET:
            field_dict["middleName"] = middle_name
        if last_name is not UNSET:
            field_dict["lastName"] = last_name
        if gender is not UNSET:
            field_dict["gender"] = gender
        if date_of_birth is not UNSET:
            field_dict["dateOfBirth"] = date_of_birth
        if citizenship is not UNSET:
            field_dict["citizenship"] = citizenship
        if jurisdiction is not UNSET:
            field_dict["jurisdiction"] = jurisdiction
        if personal_id is not UNSET:
            field_dict["personalId"] = personal_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        first_name = d.pop("firstName", UNSET)

        middle_name = d.pop("middleName", UNSET)

        last_name = d.pop("lastName", UNSET)

        _gender = d.pop("gender", UNSET)
        gender: IndividualClientGeneralInformationDtoGender | Unset
        if isinstance(_gender,  Unset):
            gender = UNSET
        else:
            gender = IndividualClientGeneralInformationDtoGender(_gender)




        date_of_birth = d.pop("dateOfBirth", UNSET)

        citizenship = d.pop("citizenship", UNSET)

        jurisdiction = d.pop("jurisdiction", UNSET)

        personal_id = d.pop("personalId", UNSET)

        individual_client_general_information_dto = cls(
            first_name=first_name,
            middle_name=middle_name,
            last_name=last_name,
            gender=gender,
            date_of_birth=date_of_birth,
            citizenship=citizenship,
            jurisdiction=jurisdiction,
            personal_id=personal_id,
        )


        individual_client_general_information_dto.additional_properties = d
        return individual_client_general_information_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
