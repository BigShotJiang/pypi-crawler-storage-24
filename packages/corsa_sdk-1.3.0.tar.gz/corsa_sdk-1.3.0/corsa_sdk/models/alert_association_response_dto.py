from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.associated_client_dto import AssociatedClientDto
  from ..models.associated_transaction_dto import AssociatedTransactionDto





T = TypeVar("T", bound="AlertAssociationResponseDto")



@_attrs_define
class AlertAssociationResponseDto:
    """ 
        Attributes:
            id (str): UUID of the alert Example: 123e4567-e89b-12d3-a456-426614174000.
            associated_transactions (AssociatedTransactionDto):
            associated_clients (AssociatedClientDto):
     """

    id: str
    associated_transactions: AssociatedTransactionDto
    associated_clients: AssociatedClientDto
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.associated_client_dto import AssociatedClientDto
        from ..models.associated_transaction_dto import AssociatedTransactionDto
        id = self.id

        associated_transactions = self.associated_transactions.to_dict()

        associated_clients = self.associated_clients.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "associatedTransactions": associated_transactions,
            "associatedClients": associated_clients,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.associated_client_dto import AssociatedClientDto
        from ..models.associated_transaction_dto import AssociatedTransactionDto
        d = dict(src_dict)
        id = d.pop("id")

        associated_transactions = AssociatedTransactionDto.from_dict(d.pop("associatedTransactions"))




        associated_clients = AssociatedClientDto.from_dict(d.pop("associatedClients"))




        alert_association_response_dto = cls(
            id=id,
            associated_transactions=associated_transactions,
            associated_clients=associated_clients,
        )


        alert_association_response_dto.additional_properties = d
        return alert_association_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
