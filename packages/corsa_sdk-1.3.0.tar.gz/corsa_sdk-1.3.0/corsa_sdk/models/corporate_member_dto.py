from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.corporate_member_dto_adverse_media_status import CorporateMemberDtoAdverseMediaStatus
from ..models.corporate_member_dto_member_type import CorporateMemberDtoMemberType
from ..models.corporate_member_dto_pep_status import CorporateMemberDtoPepStatus
from ..models.corporate_member_dto_role_type import CorporateMemberDtoRoleType
from ..models.corporate_member_dto_sanctions_status import CorporateMemberDtoSanctionsStatus
from ..models.corporate_member_dto_status import CorporateMemberDtoStatus
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CorporateMemberDto")



@_attrs_define
class CorporateMemberDto:
    """ 
        Attributes:
            id (str): Unique identifier of the member Example: 123e4567-e89b-12d3-a456-426614174000.
            platform_id (str): Platform identifier Example: platform-123.
            created_at (str): ISO timestamp of creation Example: 2023-08-15T10:30:00Z.
            updated_at (str): ISO timestamp of last update Example: 2023-08-20T14:30:00Z.
            member_type (CorporateMemberDtoMemberType): Type of member Example: CORPORATE.
            legal_entity_name (str): Legal entity name Example: Acme Corporation Ltd.
            sanctions_status (CorporateMemberDtoSanctionsStatus): Sanctions screening status Example: CLEAR.
            pep_status (CorporateMemberDtoPepStatus): PEP (Politically Exposed Person) status Example: CLEAR.
            adverse_media_status (CorporateMemberDtoAdverseMediaStatus): Adverse media screening status Example: CLEAR.
            status (CorporateMemberDtoStatus): Overall member status Example: APPROVED.
            status_date (str): Date of status determination Example: 2023-08-15T10:30:00Z.
            title (str): Member's title or position Example: Subsidiary Company.
            role_type (CorporateMemberDtoRoleType): Categorized role type Example: SHAREHOLDER.
            reference_id (str | Unset): External reference ID Example: CORP123.
            country_of_incorporation (str | Unset): Country of incorporation code Example: USA.
            registration_number (str | Unset): Registration number Example: 12345678.
            date_of_incorporation (str | Unset): Date of incorporation in ISO format Example: 2010-05-15T00:00:00Z.
            business_address_line_1 (str | Unset): First line of business address Example: 123 Business Street.
            business_address_line_2 (str | Unset): Second line of business address Example: Suite 400.
            business_address_city (str | Unset): Business address city Example: New York.
            business_address_postal_code (str | Unset): Business address postal code Example: 10001.
            business_address_country (str | Unset): Business address country code Example: USA.
            logo_url (str | Unset): URL to company logo Example: https://example.com/logo.png.
            email (str | Unset): Email address of the corporate member Example: contact@acme.com.
            phone_number (str | Unset): Phone number of the corporate member Example: +1-555-123-4567.
            ownership_percentage (float | Unset): Ownership percentage (0-100) Example: 25.5.
            sanctions_status_date (str | Unset): Date of sanctions status determination Example: 2023-08-15T10:30:00Z.
            pep_status_date (str | Unset): Date of PEP status determination Example: 2023-08-15T10:30:00Z.
            adverse_media_status_date (str | Unset): Date of adverse media status determination Example:
                2023-08-15T10:30:00Z.
            corporates (list[str] | Unset): List of corporate client IDs this member is associated with Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
     """

    id: str
    platform_id: str
    created_at: str
    updated_at: str
    member_type: CorporateMemberDtoMemberType
    legal_entity_name: str
    sanctions_status: CorporateMemberDtoSanctionsStatus
    pep_status: CorporateMemberDtoPepStatus
    adverse_media_status: CorporateMemberDtoAdverseMediaStatus
    status: CorporateMemberDtoStatus
    status_date: str
    title: str
    role_type: CorporateMemberDtoRoleType
    reference_id: str | Unset = UNSET
    country_of_incorporation: str | Unset = UNSET
    registration_number: str | Unset = UNSET
    date_of_incorporation: str | Unset = UNSET
    business_address_line_1: str | Unset = UNSET
    business_address_line_2: str | Unset = UNSET
    business_address_city: str | Unset = UNSET
    business_address_postal_code: str | Unset = UNSET
    business_address_country: str | Unset = UNSET
    logo_url: str | Unset = UNSET
    email: str | Unset = UNSET
    phone_number: str | Unset = UNSET
    ownership_percentage: float | Unset = UNSET
    sanctions_status_date: str | Unset = UNSET
    pep_status_date: str | Unset = UNSET
    adverse_media_status_date: str | Unset = UNSET
    corporates: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        platform_id = self.platform_id

        created_at = self.created_at

        updated_at = self.updated_at

        member_type = self.member_type.value

        legal_entity_name = self.legal_entity_name

        sanctions_status = self.sanctions_status.value

        pep_status = self.pep_status.value

        adverse_media_status = self.adverse_media_status.value

        status = self.status.value

        status_date = self.status_date

        title = self.title

        role_type = self.role_type.value

        reference_id = self.reference_id

        country_of_incorporation = self.country_of_incorporation

        registration_number = self.registration_number

        date_of_incorporation = self.date_of_incorporation

        business_address_line_1 = self.business_address_line_1

        business_address_line_2 = self.business_address_line_2

        business_address_city = self.business_address_city

        business_address_postal_code = self.business_address_postal_code

        business_address_country = self.business_address_country

        logo_url = self.logo_url

        email = self.email

        phone_number = self.phone_number

        ownership_percentage = self.ownership_percentage

        sanctions_status_date = self.sanctions_status_date

        pep_status_date = self.pep_status_date

        adverse_media_status_date = self.adverse_media_status_date

        corporates: list[str] | Unset = UNSET
        if not isinstance(self.corporates, Unset):
            corporates = self.corporates




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "platformId": platform_id,
            "createdAt": created_at,
            "updatedAt": updated_at,
            "memberType": member_type,
            "legalEntityName": legal_entity_name,
            "sanctionsStatus": sanctions_status,
            "pepStatus": pep_status,
            "adverseMediaStatus": adverse_media_status,
            "status": status,
            "statusDate": status_date,
            "title": title,
            "roleType": role_type,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if country_of_incorporation is not UNSET:
            field_dict["countryOfIncorporation"] = country_of_incorporation
        if registration_number is not UNSET:
            field_dict["registrationNumber"] = registration_number
        if date_of_incorporation is not UNSET:
            field_dict["dateOfIncorporation"] = date_of_incorporation
        if business_address_line_1 is not UNSET:
            field_dict["businessAddressLine1"] = business_address_line_1
        if business_address_line_2 is not UNSET:
            field_dict["businessAddressLine2"] = business_address_line_2
        if business_address_city is not UNSET:
            field_dict["businessAddressCity"] = business_address_city
        if business_address_postal_code is not UNSET:
            field_dict["businessAddressPostalCode"] = business_address_postal_code
        if business_address_country is not UNSET:
            field_dict["businessAddressCountry"] = business_address_country
        if logo_url is not UNSET:
            field_dict["logoUrl"] = logo_url
        if email is not UNSET:
            field_dict["email"] = email
        if phone_number is not UNSET:
            field_dict["phoneNumber"] = phone_number
        if ownership_percentage is not UNSET:
            field_dict["ownershipPercentage"] = ownership_percentage
        if sanctions_status_date is not UNSET:
            field_dict["sanctionsStatusDate"] = sanctions_status_date
        if pep_status_date is not UNSET:
            field_dict["pepStatusDate"] = pep_status_date
        if adverse_media_status_date is not UNSET:
            field_dict["adverseMediaStatusDate"] = adverse_media_status_date
        if corporates is not UNSET:
            field_dict["corporates"] = corporates

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        platform_id = d.pop("platformId")

        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        member_type = CorporateMemberDtoMemberType(d.pop("memberType"))




        legal_entity_name = d.pop("legalEntityName")

        sanctions_status = CorporateMemberDtoSanctionsStatus(d.pop("sanctionsStatus"))




        pep_status = CorporateMemberDtoPepStatus(d.pop("pepStatus"))




        adverse_media_status = CorporateMemberDtoAdverseMediaStatus(d.pop("adverseMediaStatus"))




        status = CorporateMemberDtoStatus(d.pop("status"))




        status_date = d.pop("statusDate")

        title = d.pop("title")

        role_type = CorporateMemberDtoRoleType(d.pop("roleType"))




        reference_id = d.pop("referenceId", UNSET)

        country_of_incorporation = d.pop("countryOfIncorporation", UNSET)

        registration_number = d.pop("registrationNumber", UNSET)

        date_of_incorporation = d.pop("dateOfIncorporation", UNSET)

        business_address_line_1 = d.pop("businessAddressLine1", UNSET)

        business_address_line_2 = d.pop("businessAddressLine2", UNSET)

        business_address_city = d.pop("businessAddressCity", UNSET)

        business_address_postal_code = d.pop("businessAddressPostalCode", UNSET)

        business_address_country = d.pop("businessAddressCountry", UNSET)

        logo_url = d.pop("logoUrl", UNSET)

        email = d.pop("email", UNSET)

        phone_number = d.pop("phoneNumber", UNSET)

        ownership_percentage = d.pop("ownershipPercentage", UNSET)

        sanctions_status_date = d.pop("sanctionsStatusDate", UNSET)

        pep_status_date = d.pop("pepStatusDate", UNSET)

        adverse_media_status_date = d.pop("adverseMediaStatusDate", UNSET)

        corporates = cast(list[str], d.pop("corporates", UNSET))


        corporate_member_dto = cls(
            id=id,
            platform_id=platform_id,
            created_at=created_at,
            updated_at=updated_at,
            member_type=member_type,
            legal_entity_name=legal_entity_name,
            sanctions_status=sanctions_status,
            pep_status=pep_status,
            adverse_media_status=adverse_media_status,
            status=status,
            status_date=status_date,
            title=title,
            role_type=role_type,
            reference_id=reference_id,
            country_of_incorporation=country_of_incorporation,
            registration_number=registration_number,
            date_of_incorporation=date_of_incorporation,
            business_address_line_1=business_address_line_1,
            business_address_line_2=business_address_line_2,
            business_address_city=business_address_city,
            business_address_postal_code=business_address_postal_code,
            business_address_country=business_address_country,
            logo_url=logo_url,
            email=email,
            phone_number=phone_number,
            ownership_percentage=ownership_percentage,
            sanctions_status_date=sanctions_status_date,
            pep_status_date=pep_status_date,
            adverse_media_status_date=adverse_media_status_date,
            corporates=corporates,
        )


        corporate_member_dto.additional_properties = d
        return corporate_member_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
