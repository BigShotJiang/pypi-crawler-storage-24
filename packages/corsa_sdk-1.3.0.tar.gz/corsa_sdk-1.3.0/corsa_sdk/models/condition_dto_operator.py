from enum import Enum

class ConditionDtoOperator(str, Enum):
    BETWEEN = "between"
    CONTAINS = "contains"
    DOESNOTCONTAIN = "doesNotContain"
    EQUAL = "equal"
    GREATERTHAN = "greaterThan"
    GREATERTHANINCLUSIVE = "greaterThanInclusive"
    IN = "in"
    LESSTHAN = "lessThan"
    LESSTHANINCLUSIVE = "lessThanInclusive"
    NOTEQUAL = "notEqual"
    NOTIN = "notIn"

    def __str__(self) -> str:
        return str(self.value)
