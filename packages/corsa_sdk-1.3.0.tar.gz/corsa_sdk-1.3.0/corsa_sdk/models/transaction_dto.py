from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.transaction_dto_side_in_trade import TransactionDtoSideInTrade
from ..models.transaction_dto_transfer_type import TransactionDtoTransferType
from ..models.transaction_dto_type import TransactionDtoType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.session_summary_dto import SessionSummaryDto
  from ..models.transaction_amount_dto import TransactionAmountDto
  from ..models.transaction_dto_custom_fields import TransactionDtoCustomFields
  from ..models.transaction_integrations_dto import TransactionIntegrationsDto
  from ..models.transaction_source_or_destination_dto import TransactionSourceOrDestinationDto
  from ..models.transaction_status_dto import TransactionStatusDto





T = TypeVar("T", bound="TransactionDto")



@_attrs_define
class TransactionDto:
    """ 
        Attributes:
            id (str): Unique identifier of the transaction Example: 123e4567-e89b-12d3-a456-426614174000.
            type_ (TransactionDtoType): Type of operation Example: DEPOSIT.
            current_status (TransactionStatusDto):
            amount (TransactionAmountDto):
            from_ (TransactionSourceOrDestinationDto):
            created_at (str): Timestamp when the transaction was created Example: 2023-08-15T10:30:00Z.
            updated_at (str): Timestamp when the transaction was last updated Example: 2023-08-15T10:35:00Z.
            initiated_at (str): Timestamp when the transaction was initiated Example: 2023-08-15T10:30:00Z.
            reference_id (str | Unset): External reference ID for the transaction Example: TX-2023-001.
            status_history (list[TransactionStatusDto] | Unset): History of transaction statuses
            converted_amount (TransactionAmountDto | Unset):
            to (TransactionSourceOrDestinationDto | Unset):
            side_in_trade (TransactionDtoSideInTrade | Unset): Side of the trade (buy/sell) Example: BUY.
            payment_method (str | Unset): Method used for payment Example: CRYPTO_TRANSFER.
            payment_rail (str | Unset): Payment network or settlement rail used for the transaction. Predefined values:
                SWIFT, SEPA, Fedwire, ACH, NIP, PIX, MobileMoney, SPEI. Custom values are also accepted. Example: SWIFT.
            transfer_type (TransactionDtoTransferType | Unset): Categorization of the transfer nature Example:
                INTERNATIONAL.
            tx_hash (str | Unset): Blockchain transaction hash Example:
                0x742d35Cc6634C0532925a3b844Bc454e4438f44e123456789abcdef.
            custom_fields (TransactionDtoCustomFields | Unset): Custom fields data
            integrations (TransactionIntegrationsDto | Unset):
            session (SessionSummaryDto | Unset):
     """

    id: str
    type_: TransactionDtoType
    current_status: TransactionStatusDto
    amount: TransactionAmountDto
    from_: TransactionSourceOrDestinationDto
    created_at: str
    updated_at: str
    initiated_at: str
    reference_id: str | Unset = UNSET
    status_history: list[TransactionStatusDto] | Unset = UNSET
    converted_amount: TransactionAmountDto | Unset = UNSET
    to: TransactionSourceOrDestinationDto | Unset = UNSET
    side_in_trade: TransactionDtoSideInTrade | Unset = UNSET
    payment_method: str | Unset = UNSET
    payment_rail: str | Unset = UNSET
    transfer_type: TransactionDtoTransferType | Unset = UNSET
    tx_hash: str | Unset = UNSET
    custom_fields: TransactionDtoCustomFields | Unset = UNSET
    integrations: TransactionIntegrationsDto | Unset = UNSET
    session: SessionSummaryDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.session_summary_dto import SessionSummaryDto
        from ..models.transaction_amount_dto import TransactionAmountDto
        from ..models.transaction_dto_custom_fields import TransactionDtoCustomFields
        from ..models.transaction_integrations_dto import TransactionIntegrationsDto
        from ..models.transaction_source_or_destination_dto import TransactionSourceOrDestinationDto
        from ..models.transaction_status_dto import TransactionStatusDto
        id = self.id

        type_ = self.type_.value

        current_status = self.current_status.to_dict()

        amount = self.amount.to_dict()

        from_ = self.from_.to_dict()

        created_at = self.created_at

        updated_at = self.updated_at

        initiated_at = self.initiated_at

        reference_id = self.reference_id

        status_history: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.status_history, Unset):
            status_history = []
            for status_history_item_data in self.status_history:
                status_history_item = status_history_item_data.to_dict()
                status_history.append(status_history_item)



        converted_amount: dict[str, Any] | Unset = UNSET
        if not isinstance(self.converted_amount, Unset):
            converted_amount = self.converted_amount.to_dict()

        to: dict[str, Any] | Unset = UNSET
        if not isinstance(self.to, Unset):
            to = self.to.to_dict()

        side_in_trade: str | Unset = UNSET
        if not isinstance(self.side_in_trade, Unset):
            side_in_trade = self.side_in_trade.value


        payment_method = self.payment_method

        payment_rail = self.payment_rail

        transfer_type: str | Unset = UNSET
        if not isinstance(self.transfer_type, Unset):
            transfer_type = self.transfer_type.value


        tx_hash = self.tx_hash

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()

        session: dict[str, Any] | Unset = UNSET
        if not isinstance(self.session, Unset):
            session = self.session.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "type": type_,
            "currentStatus": current_status,
            "amount": amount,
            "from": from_,
            "createdAt": created_at,
            "updatedAt": updated_at,
            "initiatedAt": initiated_at,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if status_history is not UNSET:
            field_dict["statusHistory"] = status_history
        if converted_amount is not UNSET:
            field_dict["convertedAmount"] = converted_amount
        if to is not UNSET:
            field_dict["to"] = to
        if side_in_trade is not UNSET:
            field_dict["sideInTrade"] = side_in_trade
        if payment_method is not UNSET:
            field_dict["paymentMethod"] = payment_method
        if payment_rail is not UNSET:
            field_dict["paymentRail"] = payment_rail
        if transfer_type is not UNSET:
            field_dict["transferType"] = transfer_type
        if tx_hash is not UNSET:
            field_dict["txHash"] = tx_hash
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if integrations is not UNSET:
            field_dict["integrations"] = integrations
        if session is not UNSET:
            field_dict["session"] = session

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.session_summary_dto import SessionSummaryDto
        from ..models.transaction_amount_dto import TransactionAmountDto
        from ..models.transaction_dto_custom_fields import TransactionDtoCustomFields
        from ..models.transaction_integrations_dto import TransactionIntegrationsDto
        from ..models.transaction_source_or_destination_dto import TransactionSourceOrDestinationDto
        from ..models.transaction_status_dto import TransactionStatusDto
        d = dict(src_dict)
        id = d.pop("id")

        type_ = TransactionDtoType(d.pop("type"))




        current_status = TransactionStatusDto.from_dict(d.pop("currentStatus"))




        amount = TransactionAmountDto.from_dict(d.pop("amount"))




        from_ = TransactionSourceOrDestinationDto.from_dict(d.pop("from"))




        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        initiated_at = d.pop("initiatedAt")

        reference_id = d.pop("referenceId", UNSET)

        _status_history = d.pop("statusHistory", UNSET)
        status_history: list[TransactionStatusDto] | Unset = UNSET
        if _status_history is not UNSET:
            status_history = []
            for status_history_item_data in _status_history:
                status_history_item = TransactionStatusDto.from_dict(status_history_item_data)



                status_history.append(status_history_item)


        _converted_amount = d.pop("convertedAmount", UNSET)
        converted_amount: TransactionAmountDto | Unset
        if isinstance(_converted_amount,  Unset):
            converted_amount = UNSET
        else:
            converted_amount = TransactionAmountDto.from_dict(_converted_amount)




        _to = d.pop("to", UNSET)
        to: TransactionSourceOrDestinationDto | Unset
        if isinstance(_to,  Unset):
            to = UNSET
        else:
            to = TransactionSourceOrDestinationDto.from_dict(_to)




        _side_in_trade = d.pop("sideInTrade", UNSET)
        side_in_trade: TransactionDtoSideInTrade | Unset
        if isinstance(_side_in_trade,  Unset):
            side_in_trade = UNSET
        else:
            side_in_trade = TransactionDtoSideInTrade(_side_in_trade)




        payment_method = d.pop("paymentMethod", UNSET)

        payment_rail = d.pop("paymentRail", UNSET)

        _transfer_type = d.pop("transferType", UNSET)
        transfer_type: TransactionDtoTransferType | Unset
        if isinstance(_transfer_type,  Unset):
            transfer_type = UNSET
        else:
            transfer_type = TransactionDtoTransferType(_transfer_type)




        tx_hash = d.pop("txHash", UNSET)

        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: TransactionDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = TransactionDtoCustomFields.from_dict(_custom_fields)




        _integrations = d.pop("integrations", UNSET)
        integrations: TransactionIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = TransactionIntegrationsDto.from_dict(_integrations)




        _session = d.pop("session", UNSET)
        session: SessionSummaryDto | Unset
        if isinstance(_session,  Unset):
            session = UNSET
        else:
            session = SessionSummaryDto.from_dict(_session)




        transaction_dto = cls(
            id=id,
            type_=type_,
            current_status=current_status,
            amount=amount,
            from_=from_,
            created_at=created_at,
            updated_at=updated_at,
            initiated_at=initiated_at,
            reference_id=reference_id,
            status_history=status_history,
            converted_amount=converted_amount,
            to=to,
            side_in_trade=side_in_trade,
            payment_method=payment_method,
            payment_rail=payment_rail,
            transfer_type=transfer_type,
            tx_hash=tx_hash,
            custom_fields=custom_fields,
            integrations=integrations,
            session=session,
        )


        transaction_dto.additional_properties = d
        return transaction_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
