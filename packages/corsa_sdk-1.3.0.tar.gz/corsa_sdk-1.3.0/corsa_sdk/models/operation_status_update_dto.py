from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.operation_status_update_dto_status import OperationStatusUpdateDtoStatus
from ..types import UNSET, Unset






T = TypeVar("T", bound="OperationStatusUpdateDto")



@_attrs_define
class OperationStatusUpdateDto:
    """ 
        Attributes:
            status (OperationStatusUpdateDtoStatus): Current status of the trade Example: PENDING.
            timestamp (str | Unset): Timestamp of the status update Example: 2023-08-15T10:30:00Z.
            reason (str | Unset): Reason for the current status Example: Awaiting blockchain confirmation.
            sub_status (str | Unset): Additional status details Example: WAITING_FOR_3_CONFIRMATIONS.
     """

    status: OperationStatusUpdateDtoStatus
    timestamp: str | Unset = UNSET
    reason: str | Unset = UNSET
    sub_status: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        timestamp = self.timestamp

        reason = self.reason

        sub_status = self.sub_status


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
        })
        if timestamp is not UNSET:
            field_dict["timestamp"] = timestamp
        if reason is not UNSET:
            field_dict["reason"] = reason
        if sub_status is not UNSET:
            field_dict["subStatus"] = sub_status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = OperationStatusUpdateDtoStatus(d.pop("status"))




        timestamp = d.pop("timestamp", UNSET)

        reason = d.pop("reason", UNSET)

        sub_status = d.pop("subStatus", UNSET)

        operation_status_update_dto = cls(
            status=status,
            timestamp=timestamp,
            reason=reason,
            sub_status=sub_status,
        )


        operation_status_update_dto.additional_properties = d
        return operation_status_update_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
