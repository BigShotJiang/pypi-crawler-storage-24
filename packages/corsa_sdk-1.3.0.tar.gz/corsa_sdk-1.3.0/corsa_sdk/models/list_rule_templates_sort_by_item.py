from enum import Enum

class ListRuleTemplatesSortByItem(str, Enum):
    CREATEDATASC = "createdAt:ASC"
    CREATEDATDESC = "createdAt:DESC"
    IDASC = "id:ASC"
    IDDESC = "id:DESC"
    NAMEASC = "name:ASC"
    NAMEDESC = "name:DESC"
    UPDATEDATASC = "updatedAt:ASC"
    UPDATEDATDESC = "updatedAt:DESC"

    def __str__(self) -> str:
        return str(self.value)
