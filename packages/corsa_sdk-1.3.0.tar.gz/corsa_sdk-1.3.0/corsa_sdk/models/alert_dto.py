from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.alert_dto_category import AlertDtoCategory
from ..models.alert_dto_pep_tier import AlertDtoPepTier
from ..models.alert_dto_priority import AlertDtoPriority
from ..models.alert_dto_research_risk_level import AlertDtoResearchRiskLevel
from ..models.alert_dto_status import AlertDtoStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.alert_dto_custom_fields import AlertDtoCustomFields
  from ..models.alert_source_dto import AlertSourceDto
  from ..models.alert_status_data import AlertStatusData
  from ..models.associated_case_dto import AssociatedCaseDto
  from ..models.associated_client_dto import AssociatedClientDto
  from ..models.associated_transaction_dto import AssociatedTransactionDto





T = TypeVar("T", bound="AlertDto")



@_attrs_define
class AlertDto:
    """ 
        Attributes:
            id (str): The ID of the alert Example: 123e4567-e89b-12d3-a456-426614174000.
            category (AlertDtoCategory): The category of the alert Example: HIGH_RISK_JURISDICTION.
            priority (AlertDtoPriority): The priority of the alert Example: HIGH.
            status (AlertDtoStatus): The status of the alert Example: OPEN.
            description (str): The description of the alert Example: This is a description of the alert.
            raised_at (str): ISO Date when the alert was raised Example: 2021-01-01T00:00:00.000Z.
            source (AlertSourceDto):
            status_history (list[AlertStatusData]): The status history of the alert Example: [{'status': 'OPEN',
                'evaluatedAt': '2021-01-01T00:00:00.000Z', 'evaluatedBy': '123e4567-e89b-12d3-a456-426614174000'}].
            associated_transactions (list[AssociatedTransactionDto]): The transactions associated with the alert Example:
                [{'id': '123e4567-e89b-12d3-a456-426614174000', 'referenceId': 'TX-123'}].
            associated_clients (list[AssociatedClientDto]): The clients associated with the alert Example: [{'id':
                '123e4567-e89b-12d3-a456-426614174000', 'referenceId': 'CL-123'}].
            associated_cases (list[AssociatedCaseDto]): The cases associated with the alert Example: [{'id':
                '123e4567-e89b-12d3-a456-426614174000', 'referenceId': 'CS-123'}].
            created_at (str): ISO Date when the alert was created Example: 2021-01-01T00:00:00.000Z.
            updated_at (str): ISO Date when the alert was updated Example: 2021-01-01T00:00:00.000Z.
            reference_id (str | Unset): The reference ID of the alert Example: CHAIN-123.
            assignee_id (str | Unset): The ID of the assignee of the alert Example: 123e4567-e89b-12d3-a456-426614174000.
            sub_category (str | Unset): Subcategory of the alert for more granular classification Example: Document
                Verification.
            custom_fields (AlertDtoCustomFields | Unset): Custom fields data
            attachment_ids (list[str] | Unset): The attachment IDs associated with the alert Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
            due_date (str | Unset): ISO Date when the alert is due Example: 2021-01-01T00:00:00.000Z.
            research_risk_level (AlertDtoResearchRiskLevel | Unset):
            research_risk_explanation (str | Unset):
            research_job_id (str | Unset):
            sanction_lists_matched (list[str] | Unset):
            sanction_lists_checked (list[str] | Unset):
            sanction_details (list[str] | Unset):
            pep_tier (AlertDtoPepTier | Unset):
            pep_positions (list[str] | Unset):
            pep_jurisdictions (list[str] | Unset):
            pep_details (str | Unset):
            adverse_media_total_items (float | Unset):
            adverse_media_direct_count (float | Unset):
            adverse_media_indirect_count (float | Unset):
            adverse_media_articles (list[str] | Unset):
            regulatory_actions_count (float | Unset):
            regulatory_active_count (float | Unset):
            regulatory_details (list[str] | Unset):
            associated_person_name (str | Unset):
            associated_person_role (str | Unset):
            associated_person_member_ids (list[str] | Unset):
     """

    id: str
    category: AlertDtoCategory
    priority: AlertDtoPriority
    status: AlertDtoStatus
    description: str
    raised_at: str
    source: AlertSourceDto
    status_history: list[AlertStatusData]
    associated_transactions: list[AssociatedTransactionDto]
    associated_clients: list[AssociatedClientDto]
    associated_cases: list[AssociatedCaseDto]
    created_at: str
    updated_at: str
    reference_id: str | Unset = UNSET
    assignee_id: str | Unset = UNSET
    sub_category: str | Unset = UNSET
    custom_fields: AlertDtoCustomFields | Unset = UNSET
    attachment_ids: list[str] | Unset = UNSET
    due_date: str | Unset = UNSET
    research_risk_level: AlertDtoResearchRiskLevel | Unset = UNSET
    research_risk_explanation: str | Unset = UNSET
    research_job_id: str | Unset = UNSET
    sanction_lists_matched: list[str] | Unset = UNSET
    sanction_lists_checked: list[str] | Unset = UNSET
    sanction_details: list[str] | Unset = UNSET
    pep_tier: AlertDtoPepTier | Unset = UNSET
    pep_positions: list[str] | Unset = UNSET
    pep_jurisdictions: list[str] | Unset = UNSET
    pep_details: str | Unset = UNSET
    adverse_media_total_items: float | Unset = UNSET
    adverse_media_direct_count: float | Unset = UNSET
    adverse_media_indirect_count: float | Unset = UNSET
    adverse_media_articles: list[str] | Unset = UNSET
    regulatory_actions_count: float | Unset = UNSET
    regulatory_active_count: float | Unset = UNSET
    regulatory_details: list[str] | Unset = UNSET
    associated_person_name: str | Unset = UNSET
    associated_person_role: str | Unset = UNSET
    associated_person_member_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.alert_dto_custom_fields import AlertDtoCustomFields
        from ..models.alert_source_dto import AlertSourceDto
        from ..models.alert_status_data import AlertStatusData
        from ..models.associated_case_dto import AssociatedCaseDto
        from ..models.associated_client_dto import AssociatedClientDto
        from ..models.associated_transaction_dto import AssociatedTransactionDto
        id = self.id

        category = self.category.value

        priority = self.priority.value

        status = self.status.value

        description = self.description

        raised_at = self.raised_at

        source = self.source.to_dict()

        status_history = []
        for status_history_item_data in self.status_history:
            status_history_item = status_history_item_data.to_dict()
            status_history.append(status_history_item)



        associated_transactions = []
        for associated_transactions_item_data in self.associated_transactions:
            associated_transactions_item = associated_transactions_item_data.to_dict()
            associated_transactions.append(associated_transactions_item)



        associated_clients = []
        for associated_clients_item_data in self.associated_clients:
            associated_clients_item = associated_clients_item_data.to_dict()
            associated_clients.append(associated_clients_item)



        associated_cases = []
        for associated_cases_item_data in self.associated_cases:
            associated_cases_item = associated_cases_item_data.to_dict()
            associated_cases.append(associated_cases_item)



        created_at = self.created_at

        updated_at = self.updated_at

        reference_id = self.reference_id

        assignee_id = self.assignee_id

        sub_category = self.sub_category

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        attachment_ids: list[str] | Unset = UNSET
        if not isinstance(self.attachment_ids, Unset):
            attachment_ids = self.attachment_ids



        due_date = self.due_date

        research_risk_level: str | Unset = UNSET
        if not isinstance(self.research_risk_level, Unset):
            research_risk_level = self.research_risk_level.value


        research_risk_explanation = self.research_risk_explanation

        research_job_id = self.research_job_id

        sanction_lists_matched: list[str] | Unset = UNSET
        if not isinstance(self.sanction_lists_matched, Unset):
            sanction_lists_matched = self.sanction_lists_matched



        sanction_lists_checked: list[str] | Unset = UNSET
        if not isinstance(self.sanction_lists_checked, Unset):
            sanction_lists_checked = self.sanction_lists_checked



        sanction_details: list[str] | Unset = UNSET
        if not isinstance(self.sanction_details, Unset):
            sanction_details = self.sanction_details



        pep_tier: str | Unset = UNSET
        if not isinstance(self.pep_tier, Unset):
            pep_tier = self.pep_tier.value


        pep_positions: list[str] | Unset = UNSET
        if not isinstance(self.pep_positions, Unset):
            pep_positions = self.pep_positions



        pep_jurisdictions: list[str] | Unset = UNSET
        if not isinstance(self.pep_jurisdictions, Unset):
            pep_jurisdictions = self.pep_jurisdictions



        pep_details = self.pep_details

        adverse_media_total_items = self.adverse_media_total_items

        adverse_media_direct_count = self.adverse_media_direct_count

        adverse_media_indirect_count = self.adverse_media_indirect_count

        adverse_media_articles: list[str] | Unset = UNSET
        if not isinstance(self.adverse_media_articles, Unset):
            adverse_media_articles = self.adverse_media_articles



        regulatory_actions_count = self.regulatory_actions_count

        regulatory_active_count = self.regulatory_active_count

        regulatory_details: list[str] | Unset = UNSET
        if not isinstance(self.regulatory_details, Unset):
            regulatory_details = self.regulatory_details



        associated_person_name = self.associated_person_name

        associated_person_role = self.associated_person_role

        associated_person_member_ids: list[str] | Unset = UNSET
        if not isinstance(self.associated_person_member_ids, Unset):
            associated_person_member_ids = self.associated_person_member_ids




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "category": category,
            "priority": priority,
            "status": status,
            "description": description,
            "raisedAt": raised_at,
            "source": source,
            "statusHistory": status_history,
            "associatedTransactions": associated_transactions,
            "associatedClients": associated_clients,
            "associatedCases": associated_cases,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if assignee_id is not UNSET:
            field_dict["assigneeId"] = assignee_id
        if sub_category is not UNSET:
            field_dict["subCategory"] = sub_category
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if attachment_ids is not UNSET:
            field_dict["attachmentIds"] = attachment_ids
        if due_date is not UNSET:
            field_dict["dueDate"] = due_date
        if research_risk_level is not UNSET:
            field_dict["researchRiskLevel"] = research_risk_level
        if research_risk_explanation is not UNSET:
            field_dict["researchRiskExplanation"] = research_risk_explanation
        if research_job_id is not UNSET:
            field_dict["researchJobId"] = research_job_id
        if sanction_lists_matched is not UNSET:
            field_dict["sanctionListsMatched"] = sanction_lists_matched
        if sanction_lists_checked is not UNSET:
            field_dict["sanctionListsChecked"] = sanction_lists_checked
        if sanction_details is not UNSET:
            field_dict["sanctionDetails"] = sanction_details
        if pep_tier is not UNSET:
            field_dict["pepTier"] = pep_tier
        if pep_positions is not UNSET:
            field_dict["pepPositions"] = pep_positions
        if pep_jurisdictions is not UNSET:
            field_dict["pepJurisdictions"] = pep_jurisdictions
        if pep_details is not UNSET:
            field_dict["pepDetails"] = pep_details
        if adverse_media_total_items is not UNSET:
            field_dict["adverseMediaTotalItems"] = adverse_media_total_items
        if adverse_media_direct_count is not UNSET:
            field_dict["adverseMediaDirectCount"] = adverse_media_direct_count
        if adverse_media_indirect_count is not UNSET:
            field_dict["adverseMediaIndirectCount"] = adverse_media_indirect_count
        if adverse_media_articles is not UNSET:
            field_dict["adverseMediaArticles"] = adverse_media_articles
        if regulatory_actions_count is not UNSET:
            field_dict["regulatoryActionsCount"] = regulatory_actions_count
        if regulatory_active_count is not UNSET:
            field_dict["regulatoryActiveCount"] = regulatory_active_count
        if regulatory_details is not UNSET:
            field_dict["regulatoryDetails"] = regulatory_details
        if associated_person_name is not UNSET:
            field_dict["associatedPersonName"] = associated_person_name
        if associated_person_role is not UNSET:
            field_dict["associatedPersonRole"] = associated_person_role
        if associated_person_member_ids is not UNSET:
            field_dict["associatedPersonMemberIds"] = associated_person_member_ids

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_dto_custom_fields import AlertDtoCustomFields
        from ..models.alert_source_dto import AlertSourceDto
        from ..models.alert_status_data import AlertStatusData
        from ..models.associated_case_dto import AssociatedCaseDto
        from ..models.associated_client_dto import AssociatedClientDto
        from ..models.associated_transaction_dto import AssociatedTransactionDto
        d = dict(src_dict)
        id = d.pop("id")

        category = AlertDtoCategory(d.pop("category"))




        priority = AlertDtoPriority(d.pop("priority"))




        status = AlertDtoStatus(d.pop("status"))




        description = d.pop("description")

        raised_at = d.pop("raisedAt")

        source = AlertSourceDto.from_dict(d.pop("source"))




        status_history = []
        _status_history = d.pop("statusHistory")
        for status_history_item_data in (_status_history):
            status_history_item = AlertStatusData.from_dict(status_history_item_data)



            status_history.append(status_history_item)


        associated_transactions = []
        _associated_transactions = d.pop("associatedTransactions")
        for associated_transactions_item_data in (_associated_transactions):
            associated_transactions_item = AssociatedTransactionDto.from_dict(associated_transactions_item_data)



            associated_transactions.append(associated_transactions_item)


        associated_clients = []
        _associated_clients = d.pop("associatedClients")
        for associated_clients_item_data in (_associated_clients):
            associated_clients_item = AssociatedClientDto.from_dict(associated_clients_item_data)



            associated_clients.append(associated_clients_item)


        associated_cases = []
        _associated_cases = d.pop("associatedCases")
        for associated_cases_item_data in (_associated_cases):
            associated_cases_item = AssociatedCaseDto.from_dict(associated_cases_item_data)



            associated_cases.append(associated_cases_item)


        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        reference_id = d.pop("referenceId", UNSET)

        assignee_id = d.pop("assigneeId", UNSET)

        sub_category = d.pop("subCategory", UNSET)

        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: AlertDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = AlertDtoCustomFields.from_dict(_custom_fields)




        attachment_ids = cast(list[str], d.pop("attachmentIds", UNSET))


        due_date = d.pop("dueDate", UNSET)

        _research_risk_level = d.pop("researchRiskLevel", UNSET)
        research_risk_level: AlertDtoResearchRiskLevel | Unset
        if isinstance(_research_risk_level,  Unset):
            research_risk_level = UNSET
        else:
            research_risk_level = AlertDtoResearchRiskLevel(_research_risk_level)




        research_risk_explanation = d.pop("researchRiskExplanation", UNSET)

        research_job_id = d.pop("researchJobId", UNSET)

        sanction_lists_matched = cast(list[str], d.pop("sanctionListsMatched", UNSET))


        sanction_lists_checked = cast(list[str], d.pop("sanctionListsChecked", UNSET))


        sanction_details = cast(list[str], d.pop("sanctionDetails", UNSET))


        _pep_tier = d.pop("pepTier", UNSET)
        pep_tier: AlertDtoPepTier | Unset
        if isinstance(_pep_tier,  Unset):
            pep_tier = UNSET
        else:
            pep_tier = AlertDtoPepTier(_pep_tier)




        pep_positions = cast(list[str], d.pop("pepPositions", UNSET))


        pep_jurisdictions = cast(list[str], d.pop("pepJurisdictions", UNSET))


        pep_details = d.pop("pepDetails", UNSET)

        adverse_media_total_items = d.pop("adverseMediaTotalItems", UNSET)

        adverse_media_direct_count = d.pop("adverseMediaDirectCount", UNSET)

        adverse_media_indirect_count = d.pop("adverseMediaIndirectCount", UNSET)

        adverse_media_articles = cast(list[str], d.pop("adverseMediaArticles", UNSET))


        regulatory_actions_count = d.pop("regulatoryActionsCount", UNSET)

        regulatory_active_count = d.pop("regulatoryActiveCount", UNSET)

        regulatory_details = cast(list[str], d.pop("regulatoryDetails", UNSET))


        associated_person_name = d.pop("associatedPersonName", UNSET)

        associated_person_role = d.pop("associatedPersonRole", UNSET)

        associated_person_member_ids = cast(list[str], d.pop("associatedPersonMemberIds", UNSET))


        alert_dto = cls(
            id=id,
            category=category,
            priority=priority,
            status=status,
            description=description,
            raised_at=raised_at,
            source=source,
            status_history=status_history,
            associated_transactions=associated_transactions,
            associated_clients=associated_clients,
            associated_cases=associated_cases,
            created_at=created_at,
            updated_at=updated_at,
            reference_id=reference_id,
            assignee_id=assignee_id,
            sub_category=sub_category,
            custom_fields=custom_fields,
            attachment_ids=attachment_ids,
            due_date=due_date,
            research_risk_level=research_risk_level,
            research_risk_explanation=research_risk_explanation,
            research_job_id=research_job_id,
            sanction_lists_matched=sanction_lists_matched,
            sanction_lists_checked=sanction_lists_checked,
            sanction_details=sanction_details,
            pep_tier=pep_tier,
            pep_positions=pep_positions,
            pep_jurisdictions=pep_jurisdictions,
            pep_details=pep_details,
            adverse_media_total_items=adverse_media_total_items,
            adverse_media_direct_count=adverse_media_direct_count,
            adverse_media_indirect_count=adverse_media_indirect_count,
            adverse_media_articles=adverse_media_articles,
            regulatory_actions_count=regulatory_actions_count,
            regulatory_active_count=regulatory_active_count,
            regulatory_details=regulatory_details,
            associated_person_name=associated_person_name,
            associated_person_role=associated_person_role,
            associated_person_member_ids=associated_person_member_ids,
        )


        alert_dto.additional_properties = d
        return alert_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
