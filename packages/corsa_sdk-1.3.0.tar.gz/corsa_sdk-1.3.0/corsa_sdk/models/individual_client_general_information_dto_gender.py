from enum import Enum

class IndividualClientGeneralInformationDtoGender(str, Enum):
    FEMALE = "FEMALE"
    MALE = "MALE"

    def __str__(self) -> str:
        return str(self.value)
