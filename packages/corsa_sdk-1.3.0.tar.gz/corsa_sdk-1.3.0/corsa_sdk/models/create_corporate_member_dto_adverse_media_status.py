from enum import Enum

class CreateCorporateMemberDtoAdverseMediaStatus(str, Enum):
    CLEAR = "CLEAR"
    FLAGGED = "FLAGGED"
    NOT_CHECKED = "NOT_CHECKED"
    UNDER_REVIEW = "UNDER_REVIEW"

    def __str__(self) -> str:
        return str(self.value)
