from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.client_sumsub_dto import ClientSumsubDto
  from ..models.plain_integration_dto import PlainIntegrationDto





T = TypeVar("T", bound="CorporateClientIntegrationsDto")



@_attrs_define
class CorporateClientIntegrationsDto:
    """ 
        Attributes:
            chainalysis_user_id (str | Unset): Chainalysis user ID for the individual client Example: CHAINALYSIS123.
            sumsub (ClientSumsubDto | Unset):
            plain (PlainIntegrationDto | Unset):
     """

    chainalysis_user_id: str | Unset = UNSET
    sumsub: ClientSumsubDto | Unset = UNSET
    plain: PlainIntegrationDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.client_sumsub_dto import ClientSumsubDto
        from ..models.plain_integration_dto import PlainIntegrationDto
        chainalysis_user_id = self.chainalysis_user_id

        sumsub: dict[str, Any] | Unset = UNSET
        if not isinstance(self.sumsub, Unset):
            sumsub = self.sumsub.to_dict()

        plain: dict[str, Any] | Unset = UNSET
        if not isinstance(self.plain, Unset):
            plain = self.plain.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if chainalysis_user_id is not UNSET:
            field_dict["chainalysisUserId"] = chainalysis_user_id
        if sumsub is not UNSET:
            field_dict["sumsub"] = sumsub
        if plain is not UNSET:
            field_dict["plain"] = plain

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.client_sumsub_dto import ClientSumsubDto
        from ..models.plain_integration_dto import PlainIntegrationDto
        d = dict(src_dict)
        chainalysis_user_id = d.pop("chainalysisUserId", UNSET)

        _sumsub = d.pop("sumsub", UNSET)
        sumsub: ClientSumsubDto | Unset
        if isinstance(_sumsub,  Unset):
            sumsub = UNSET
        else:
            sumsub = ClientSumsubDto.from_dict(_sumsub)




        _plain = d.pop("plain", UNSET)
        plain: PlainIntegrationDto | Unset
        if isinstance(_plain,  Unset):
            plain = UNSET
        else:
            plain = PlainIntegrationDto.from_dict(_plain)




        corporate_client_integrations_dto = cls(
            chainalysis_user_id=chainalysis_user_id,
            sumsub=sumsub,
            plain=plain,
        )


        corporate_client_integrations_dto.additional_properties = d
        return corporate_client_integrations_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
