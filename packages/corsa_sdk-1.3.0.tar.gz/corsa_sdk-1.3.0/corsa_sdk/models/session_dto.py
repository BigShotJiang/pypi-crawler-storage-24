from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.device_response_dto import DeviceResponseDto





T = TypeVar("T", bound="SessionDto")



@_attrs_define
class SessionDto:
    """ 
        Attributes:
            id (str): Unique identifier of the session Example: 123e4567-e89b-12d3-a456-426614174000.
            ip_address (str): IP address of the session Example: 203.0.113.42.
            started_at (str): Session start time
            created_at (str): Timestamp when the session was created
            updated_at (str): Timestamp when the session was last updated
            reference_id (str | Unset): External session reference ID Example: sess_abc123.
            geo_country (str | Unset): Geo-resolved country name Example: United States.
            geo_country_code (str | Unset): ISO country code Example: US.
            geo_city (str | Unset): Geo-resolved city Example: New York.
            geo_region (str | Unset): Geo-resolved region/state Example: New York.
            geo_latitude (float | Unset): Latitude Example: 40.7128.
            geo_longitude (float | Unset): Longitude Example: -74.006.
            geo_timezone (str | Unset): Timezone Example: America/New_York.
            isp_name (str | Unset): Internet service provider Example: Comcast.
            is_vpn (bool | Unset): Whether the IP is a VPN
            is_proxy (bool | Unset): Whether the IP is a proxy
            is_tor (bool | Unset): Whether the IP is a Tor exit node
            is_datacenter (bool | Unset): Whether the IP is from a datacenter
            ended_at (str | Unset): Session end time
            device (DeviceResponseDto | Unset):
     """

    id: str
    ip_address: str
    started_at: str
    created_at: str
    updated_at: str
    reference_id: str | Unset = UNSET
    geo_country: str | Unset = UNSET
    geo_country_code: str | Unset = UNSET
    geo_city: str | Unset = UNSET
    geo_region: str | Unset = UNSET
    geo_latitude: float | Unset = UNSET
    geo_longitude: float | Unset = UNSET
    geo_timezone: str | Unset = UNSET
    isp_name: str | Unset = UNSET
    is_vpn: bool | Unset = UNSET
    is_proxy: bool | Unset = UNSET
    is_tor: bool | Unset = UNSET
    is_datacenter: bool | Unset = UNSET
    ended_at: str | Unset = UNSET
    device: DeviceResponseDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.device_response_dto import DeviceResponseDto
        id = self.id

        ip_address = self.ip_address

        started_at = self.started_at

        created_at = self.created_at

        updated_at = self.updated_at

        reference_id = self.reference_id

        geo_country = self.geo_country

        geo_country_code = self.geo_country_code

        geo_city = self.geo_city

        geo_region = self.geo_region

        geo_latitude = self.geo_latitude

        geo_longitude = self.geo_longitude

        geo_timezone = self.geo_timezone

        isp_name = self.isp_name

        is_vpn = self.is_vpn

        is_proxy = self.is_proxy

        is_tor = self.is_tor

        is_datacenter = self.is_datacenter

        ended_at = self.ended_at

        device: dict[str, Any] | Unset = UNSET
        if not isinstance(self.device, Unset):
            device = self.device.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "ipAddress": ip_address,
            "startedAt": started_at,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if geo_country is not UNSET:
            field_dict["geoCountry"] = geo_country
        if geo_country_code is not UNSET:
            field_dict["geoCountryCode"] = geo_country_code
        if geo_city is not UNSET:
            field_dict["geoCity"] = geo_city
        if geo_region is not UNSET:
            field_dict["geoRegion"] = geo_region
        if geo_latitude is not UNSET:
            field_dict["geoLatitude"] = geo_latitude
        if geo_longitude is not UNSET:
            field_dict["geoLongitude"] = geo_longitude
        if geo_timezone is not UNSET:
            field_dict["geoTimezone"] = geo_timezone
        if isp_name is not UNSET:
            field_dict["ispName"] = isp_name
        if is_vpn is not UNSET:
            field_dict["isVpn"] = is_vpn
        if is_proxy is not UNSET:
            field_dict["isProxy"] = is_proxy
        if is_tor is not UNSET:
            field_dict["isTor"] = is_tor
        if is_datacenter is not UNSET:
            field_dict["isDatacenter"] = is_datacenter
        if ended_at is not UNSET:
            field_dict["endedAt"] = ended_at
        if device is not UNSET:
            field_dict["device"] = device

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.device_response_dto import DeviceResponseDto
        d = dict(src_dict)
        id = d.pop("id")

        ip_address = d.pop("ipAddress")

        started_at = d.pop("startedAt")

        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        reference_id = d.pop("referenceId", UNSET)

        geo_country = d.pop("geoCountry", UNSET)

        geo_country_code = d.pop("geoCountryCode", UNSET)

        geo_city = d.pop("geoCity", UNSET)

        geo_region = d.pop("geoRegion", UNSET)

        geo_latitude = d.pop("geoLatitude", UNSET)

        geo_longitude = d.pop("geoLongitude", UNSET)

        geo_timezone = d.pop("geoTimezone", UNSET)

        isp_name = d.pop("ispName", UNSET)

        is_vpn = d.pop("isVpn", UNSET)

        is_proxy = d.pop("isProxy", UNSET)

        is_tor = d.pop("isTor", UNSET)

        is_datacenter = d.pop("isDatacenter", UNSET)

        ended_at = d.pop("endedAt", UNSET)

        _device = d.pop("device", UNSET)
        device: DeviceResponseDto | Unset
        if isinstance(_device,  Unset):
            device = UNSET
        else:
            device = DeviceResponseDto.from_dict(_device)




        session_dto = cls(
            id=id,
            ip_address=ip_address,
            started_at=started_at,
            created_at=created_at,
            updated_at=updated_at,
            reference_id=reference_id,
            geo_country=geo_country,
            geo_country_code=geo_country_code,
            geo_city=geo_city,
            geo_region=geo_region,
            geo_latitude=geo_latitude,
            geo_longitude=geo_longitude,
            geo_timezone=geo_timezone,
            isp_name=isp_name,
            is_vpn=is_vpn,
            is_proxy=is_proxy,
            is_tor=is_tor,
            is_datacenter=is_datacenter,
            ended_at=ended_at,
            device=device,
        )


        session_dto.additional_properties = d
        return session_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
