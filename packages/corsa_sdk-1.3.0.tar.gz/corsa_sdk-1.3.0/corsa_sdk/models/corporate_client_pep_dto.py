from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.corporate_client_pep_dto_pep_tier import CorporateClientPEPDtoPepTier
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CorporateClientPEPDto")



@_attrs_define
class CorporateClientPEPDto:
    """ 
        Attributes:
            is_politically_exposed (bool | Unset): Whether the client is politically exposed
            pep_tier (CorporateClientPEPDtoPepTier | Unset): PEP tier level Example: NO_PEP.
            pep_score (float | Unset): PEP score based on tier (0, 2, 3, 4, or 5)
            pep_details (str | Unset): Details about the PEP status Example: No political exposure identified.
            pep_jurisdiction (list[str] | Unset): Country codes where the political exposure is relevant (maximum 20)
                Example: ['USA', 'GBR'].
     """

    is_politically_exposed: bool | Unset = UNSET
    pep_tier: CorporateClientPEPDtoPepTier | Unset = UNSET
    pep_score: float | Unset = UNSET
    pep_details: str | Unset = UNSET
    pep_jurisdiction: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        is_politically_exposed = self.is_politically_exposed

        pep_tier: str | Unset = UNSET
        if not isinstance(self.pep_tier, Unset):
            pep_tier = self.pep_tier.value


        pep_score = self.pep_score

        pep_details = self.pep_details

        pep_jurisdiction: list[str] | Unset = UNSET
        if not isinstance(self.pep_jurisdiction, Unset):
            pep_jurisdiction = self.pep_jurisdiction




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if is_politically_exposed is not UNSET:
            field_dict["isPoliticallyExposed"] = is_politically_exposed
        if pep_tier is not UNSET:
            field_dict["pepTier"] = pep_tier
        if pep_score is not UNSET:
            field_dict["pepScore"] = pep_score
        if pep_details is not UNSET:
            field_dict["pepDetails"] = pep_details
        if pep_jurisdiction is not UNSET:
            field_dict["pepJurisdiction"] = pep_jurisdiction

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        is_politically_exposed = d.pop("isPoliticallyExposed", UNSET)

        _pep_tier = d.pop("pepTier", UNSET)
        pep_tier: CorporateClientPEPDtoPepTier | Unset
        if isinstance(_pep_tier,  Unset):
            pep_tier = UNSET
        else:
            pep_tier = CorporateClientPEPDtoPepTier(_pep_tier)




        pep_score = d.pop("pepScore", UNSET)

        pep_details = d.pop("pepDetails", UNSET)

        pep_jurisdiction = cast(list[str], d.pop("pepJurisdiction", UNSET))


        corporate_client_pep_dto = cls(
            is_politically_exposed=is_politically_exposed,
            pep_tier=pep_tier,
            pep_score=pep_score,
            pep_details=pep_details,
            pep_jurisdiction=pep_jurisdiction,
        )


        corporate_client_pep_dto.additional_properties = d
        return corporate_client_pep_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
