from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.evaluation_request_dto_transaction_data import EvaluationRequestDtoTransactionData





T = TypeVar("T", bound="EvaluationRequestDto")



@_attrs_define
class EvaluationRequestDto:
    """ 
        Attributes:
            transaction_data (EvaluationRequestDtoTransactionData): Transaction data to evaluate. The 'id' field is optional
                and will be taken from transactionId if provided.
            transaction_id (str | Unset): Optional transaction ID for tracking/correlation. Example: txn_123abc.
     """

    transaction_data: EvaluationRequestDtoTransactionData
    transaction_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.evaluation_request_dto_transaction_data import EvaluationRequestDtoTransactionData
        transaction_data = self.transaction_data.to_dict()

        transaction_id = self.transaction_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "transactionData": transaction_data,
        })
        if transaction_id is not UNSET:
            field_dict["transactionId"] = transaction_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.evaluation_request_dto_transaction_data import EvaluationRequestDtoTransactionData
        d = dict(src_dict)
        transaction_data = EvaluationRequestDtoTransactionData.from_dict(d.pop("transactionData"))




        transaction_id = d.pop("transactionId", UNSET)

        evaluation_request_dto = cls(
            transaction_data=transaction_data,
            transaction_id=transaction_id,
        )


        evaluation_request_dto.additional_properties = d
        return evaluation_request_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
