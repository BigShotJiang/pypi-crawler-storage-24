from enum import Enum

class RuleResponseDtoStatus(str, Enum):
    ACTIVE = "active"
    DISABLED = "disabled"
    DRAFT = "draft"

    def __str__(self) -> str:
        return str(self.value)
