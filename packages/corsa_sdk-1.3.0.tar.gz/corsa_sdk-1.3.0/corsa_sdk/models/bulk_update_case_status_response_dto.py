from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.bulk_failed_case_dto import BulkFailedCaseDto
  from ..models.bulk_updated_case_dto import BulkUpdatedCaseDto





T = TypeVar("T", bound="BulkUpdateCaseStatusResponseDto")



@_attrs_define
class BulkUpdateCaseStatusResponseDto:
    """ 
        Attributes:
            failed_cases (list[BulkFailedCaseDto]): Array of cases that failed to process
            total_processed (float): Total number of cases processed Example: 10.
            success_count (float): Number of cases successfully processed Example: 8.
            failure_count (float): Number of cases that failed to process Example: 2.
            skipped_count (float): Number of cases skipped (already in target state) Example: 1.
            updated_cases (list[BulkUpdatedCaseDto]): Array of successfully updated cases
     """

    failed_cases: list[BulkFailedCaseDto]
    total_processed: float
    success_count: float
    failure_count: float
    skipped_count: float
    updated_cases: list[BulkUpdatedCaseDto]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.bulk_failed_case_dto import BulkFailedCaseDto
        from ..models.bulk_updated_case_dto import BulkUpdatedCaseDto
        failed_cases = []
        for failed_cases_item_data in self.failed_cases:
            failed_cases_item = failed_cases_item_data.to_dict()
            failed_cases.append(failed_cases_item)



        total_processed = self.total_processed

        success_count = self.success_count

        failure_count = self.failure_count

        skipped_count = self.skipped_count

        updated_cases = []
        for updated_cases_item_data in self.updated_cases:
            updated_cases_item = updated_cases_item_data.to_dict()
            updated_cases.append(updated_cases_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "failedCases": failed_cases,
            "totalProcessed": total_processed,
            "successCount": success_count,
            "failureCount": failure_count,
            "skippedCount": skipped_count,
            "updatedCases": updated_cases,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.bulk_failed_case_dto import BulkFailedCaseDto
        from ..models.bulk_updated_case_dto import BulkUpdatedCaseDto
        d = dict(src_dict)
        failed_cases = []
        _failed_cases = d.pop("failedCases")
        for failed_cases_item_data in (_failed_cases):
            failed_cases_item = BulkFailedCaseDto.from_dict(failed_cases_item_data)



            failed_cases.append(failed_cases_item)


        total_processed = d.pop("totalProcessed")

        success_count = d.pop("successCount")

        failure_count = d.pop("failureCount")

        skipped_count = d.pop("skippedCount")

        updated_cases = []
        _updated_cases = d.pop("updatedCases")
        for updated_cases_item_data in (_updated_cases):
            updated_cases_item = BulkUpdatedCaseDto.from_dict(updated_cases_item_data)



            updated_cases.append(updated_cases_item)


        bulk_update_case_status_response_dto = cls(
            failed_cases=failed_cases,
            total_processed=total_processed,
            success_count=success_count,
            failure_count=failure_count,
            skipped_count=skipped_count,
            updated_cases=updated_cases,
        )


        bulk_update_case_status_response_dto.additional_properties = d
        return bulk_update_case_status_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
