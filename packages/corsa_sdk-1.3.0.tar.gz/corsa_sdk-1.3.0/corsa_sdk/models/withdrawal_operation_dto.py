from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.corporate_client_dto import CorporateClientDto
  from ..models.individual_client_dto import IndividualClientDto
  from ..models.transaction_dto import TransactionDto





T = TypeVar("T", bound="WithdrawalOperationDto")



@_attrs_define
class WithdrawalOperationDto:
    """ 
        Attributes:
            id (str): Unique identifier of the withdrawal operation Example: 123e4567-e89b-12d3-a456-426614174000.
            initiated_at (str): ISO timestamp when the withdrawal operation was initiated or reported to the platform
                Example: 2023-08-15T10:30:00Z.
            withdraw_transaction (TransactionDto):
            created_at (str): ISO timestamp when the withdrawal operation was created Example: 2023-08-15T10:30:00Z.
            updated_at (str): ISO timestamp when the withdrawal operation was last updated Example: 2023-08-15T10:35:00Z.
            reference_id (str | Unset): External reference ID for the withdrawal operation Example: WDR-2023-001.
            initiated_by (CorporateClientDto | IndividualClientDto | str | Unset): Identifier of the user who initiated the
                withdrawal Example: 123e4567-e89b-12d3-a456-426614174000.
     """

    id: str
    initiated_at: str
    withdraw_transaction: TransactionDto
    created_at: str
    updated_at: str
    reference_id: str | Unset = UNSET
    initiated_by: CorporateClientDto | IndividualClientDto | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.corporate_client_dto import CorporateClientDto
        from ..models.individual_client_dto import IndividualClientDto
        from ..models.transaction_dto import TransactionDto
        id = self.id

        initiated_at = self.initiated_at

        withdraw_transaction = self.withdraw_transaction.to_dict()

        created_at = self.created_at

        updated_at = self.updated_at

        reference_id = self.reference_id

        initiated_by: dict[str, Any] | str | Unset
        if isinstance(self.initiated_by, Unset):
            initiated_by = UNSET
        elif isinstance(self.initiated_by, CorporateClientDto):
            initiated_by = self.initiated_by.to_dict()
        elif isinstance(self.initiated_by, IndividualClientDto):
            initiated_by = self.initiated_by.to_dict()
        else:
            initiated_by = self.initiated_by


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "initiatedAt": initiated_at,
            "withdrawTransaction": withdraw_transaction,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if initiated_by is not UNSET:
            field_dict["initiatedBy"] = initiated_by

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.corporate_client_dto import CorporateClientDto
        from ..models.individual_client_dto import IndividualClientDto
        from ..models.transaction_dto import TransactionDto
        d = dict(src_dict)
        id = d.pop("id")

        initiated_at = d.pop("initiatedAt")

        withdraw_transaction = TransactionDto.from_dict(d.pop("withdrawTransaction"))




        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        reference_id = d.pop("referenceId", UNSET)

        def _parse_initiated_by(data: object) -> CorporateClientDto | IndividualClientDto | str | Unset:
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                initiated_by_type_0 = CorporateClientDto.from_dict(data)



                return initiated_by_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                initiated_by_type_1 = IndividualClientDto.from_dict(data)



                return initiated_by_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CorporateClientDto | IndividualClientDto | str | Unset, data)

        initiated_by = _parse_initiated_by(d.pop("initiatedBy", UNSET))


        withdrawal_operation_dto = cls(
            id=id,
            initiated_at=initiated_at,
            withdraw_transaction=withdraw_transaction,
            created_at=created_at,
            updated_at=updated_at,
            reference_id=reference_id,
            initiated_by=initiated_by,
        )


        withdrawal_operation_dto.additional_properties = d
        return withdrawal_operation_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
