from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="CorporateClientGeneralDto")



@_attrs_define
class CorporateClientGeneralDto:
    """ 
        Attributes:
            jurisdiction (str | Unset): Jurisdiction country code (ISO 3166-1 alpha-2) Example: US.
            legal_entity_name (str | Unset): Legal registered name of the corporate entity Example: Acme Corporation Ltd.
            date_of_incorporation (str | Unset): Date when the company was incorporated Example: 2020-01-01.
            country_of_incorporation (str | Unset): Country where the company is incorporated Example: USA.
     """

    jurisdiction: str | Unset = UNSET
    legal_entity_name: str | Unset = UNSET
    date_of_incorporation: str | Unset = UNSET
    country_of_incorporation: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        jurisdiction = self.jurisdiction

        legal_entity_name = self.legal_entity_name

        date_of_incorporation = self.date_of_incorporation

        country_of_incorporation = self.country_of_incorporation


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if jurisdiction is not UNSET:
            field_dict["jurisdiction"] = jurisdiction
        if legal_entity_name is not UNSET:
            field_dict["legalEntityName"] = legal_entity_name
        if date_of_incorporation is not UNSET:
            field_dict["dateOfIncorporation"] = date_of_incorporation
        if country_of_incorporation is not UNSET:
            field_dict["countryOfIncorporation"] = country_of_incorporation

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        jurisdiction = d.pop("jurisdiction", UNSET)

        legal_entity_name = d.pop("legalEntityName", UNSET)

        date_of_incorporation = d.pop("dateOfIncorporation", UNSET)

        country_of_incorporation = d.pop("countryOfIncorporation", UNSET)

        corporate_client_general_dto = cls(
            jurisdiction=jurisdiction,
            legal_entity_name=legal_entity_name,
            date_of_incorporation=date_of_incorporation,
            country_of_incorporation=country_of_incorporation,
        )


        corporate_client_general_dto.additional_properties = d
        return corporate_client_general_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
