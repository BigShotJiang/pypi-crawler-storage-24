from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="TransactionIntegrationsDto")



@_attrs_define
class TransactionIntegrationsDto:
    """ 
        Attributes:
            sardine_transaction_id (str | Unset): Sardine transaction ID Example: sardine-transaction-id.
            chainalysis_transaction_id (str | Unset): Chainalysis transaction ID Example: chainalysis-transaction-id.
            trm_transaction_id (str | Unset): Trm transaction ID Example: trm-transaction-id.
            utila_transaction_id (str | Unset): Utila transaction ID Example: utila-transaction-id.
     """

    sardine_transaction_id: str | Unset = UNSET
    chainalysis_transaction_id: str | Unset = UNSET
    trm_transaction_id: str | Unset = UNSET
    utila_transaction_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        sardine_transaction_id = self.sardine_transaction_id

        chainalysis_transaction_id = self.chainalysis_transaction_id

        trm_transaction_id = self.trm_transaction_id

        utila_transaction_id = self.utila_transaction_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if sardine_transaction_id is not UNSET:
            field_dict["sardineTransactionId"] = sardine_transaction_id
        if chainalysis_transaction_id is not UNSET:
            field_dict["chainalysisTransactionId"] = chainalysis_transaction_id
        if trm_transaction_id is not UNSET:
            field_dict["trmTransactionId"] = trm_transaction_id
        if utila_transaction_id is not UNSET:
            field_dict["utilaTransactionId"] = utila_transaction_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        sardine_transaction_id = d.pop("sardineTransactionId", UNSET)

        chainalysis_transaction_id = d.pop("chainalysisTransactionId", UNSET)

        trm_transaction_id = d.pop("trmTransactionId", UNSET)

        utila_transaction_id = d.pop("utilaTransactionId", UNSET)

        transaction_integrations_dto = cls(
            sardine_transaction_id=sardine_transaction_id,
            chainalysis_transaction_id=chainalysis_transaction_id,
            trm_transaction_id=trm_transaction_id,
            utila_transaction_id=utila_transaction_id,
        )


        transaction_integrations_dto.additional_properties = d
        return transaction_integrations_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
