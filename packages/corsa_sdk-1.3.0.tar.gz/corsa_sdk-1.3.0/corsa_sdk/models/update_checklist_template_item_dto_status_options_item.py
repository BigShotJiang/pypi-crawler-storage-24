from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_checklist_template_item_dto_status_options_item_color import UpdateChecklistTemplateItemDtoStatusOptionsItemColor
from ..types import UNSET, Unset






T = TypeVar("T", bound="UpdateChecklistTemplateItemDtoStatusOptionsItem")



@_attrs_define
class UpdateChecklistTemplateItemDtoStatusOptionsItem:
    """ 
        Attributes:
            name (str | Unset):  Example: PENDING.
            color (UpdateChecklistTemplateItemDtoStatusOptionsItemColor | Unset):  Example: yellow.
     """

    name: str | Unset = UNSET
    color: UpdateChecklistTemplateItemDtoStatusOptionsItemColor | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        color: str | Unset = UNSET
        if not isinstance(self.color, Unset):
            color = self.color.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if color is not UNSET:
            field_dict["color"] = color

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        _color = d.pop("color", UNSET)
        color: UpdateChecklistTemplateItemDtoStatusOptionsItemColor | Unset
        if isinstance(_color,  Unset):
            color = UNSET
        else:
            color = UpdateChecklistTemplateItemDtoStatusOptionsItemColor(_color)




        update_checklist_template_item_dto_status_options_item = cls(
            name=name,
            color=color,
        )


        update_checklist_template_item_dto_status_options_item.additional_properties = d
        return update_checklist_template_item_dto_status_options_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
