from enum import Enum

class CreateCorporateClientDtoActivityStatus(str, Enum):
    ACTIVE = "ACTIVE"
    NOT_ACTIVE = "NOT_ACTIVE"

    def __str__(self) -> str:
        return str(self.value)
