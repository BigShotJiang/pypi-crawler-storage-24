from enum import Enum

class TransactionStatusDtoType(str, Enum):
    CANCELLED = "CANCELLED"
    FAILED = "FAILED"
    FROZEN = "FROZEN"
    PENDING = "PENDING"
    SUCCESS = "SUCCESS"

    def __str__(self) -> str:
        return str(self.value)
