from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_checklist_template_item_dto_category import UpdateChecklistTemplateItemDtoCategory
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.update_checklist_template_item_dto_status_options_item import UpdateChecklistTemplateItemDtoStatusOptionsItem





T = TypeVar("T", bound="UpdateChecklistTemplateItemDto")



@_attrs_define
class UpdateChecklistTemplateItemDto:
    """ 
        Attributes:
            name (str | Unset): The name of the checklist item Example: Updated Identity Verification.
            note (str | Unset): Optional note for the checklist item Example: Updated verification note.
            category (UpdateChecklistTemplateItemDtoCategory | Unset): The category of the checklist item Example:
                PERSONAL_IDENTIFICATION.
            status_options (list[UpdateChecklistTemplateItemDtoStatusOptionsItem] | Unset): Custom status options for this
                item Example: [{'name': 'PENDING', 'color': 'yellow'}, {'name': 'COMPLETED', 'color': 'green'}, {'name':
                'REJECTED', 'color': 'red'}].
     """

    name: str | Unset = UNSET
    note: str | Unset = UNSET
    category: UpdateChecklistTemplateItemDtoCategory | Unset = UNSET
    status_options: list[UpdateChecklistTemplateItemDtoStatusOptionsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.update_checklist_template_item_dto_status_options_item import UpdateChecklistTemplateItemDtoStatusOptionsItem
        name = self.name

        note = self.note

        category: str | Unset = UNSET
        if not isinstance(self.category, Unset):
            category = self.category.value


        status_options: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.status_options, Unset):
            status_options = []
            for status_options_item_data in self.status_options:
                status_options_item = status_options_item_data.to_dict()
                status_options.append(status_options_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if note is not UNSET:
            field_dict["note"] = note
        if category is not UNSET:
            field_dict["category"] = category
        if status_options is not UNSET:
            field_dict["statusOptions"] = status_options

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_checklist_template_item_dto_status_options_item import UpdateChecklistTemplateItemDtoStatusOptionsItem
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        note = d.pop("note", UNSET)

        _category = d.pop("category", UNSET)
        category: UpdateChecklistTemplateItemDtoCategory | Unset
        if isinstance(_category,  Unset):
            category = UNSET
        else:
            category = UpdateChecklistTemplateItemDtoCategory(_category)




        _status_options = d.pop("statusOptions", UNSET)
        status_options: list[UpdateChecklistTemplateItemDtoStatusOptionsItem] | Unset = UNSET
        if _status_options is not UNSET:
            status_options = []
            for status_options_item_data in _status_options:
                status_options_item = UpdateChecklistTemplateItemDtoStatusOptionsItem.from_dict(status_options_item_data)



                status_options.append(status_options_item)


        update_checklist_template_item_dto = cls(
            name=name,
            note=note,
            category=category,
            status_options=status_options,
        )


        update_checklist_template_item_dto.additional_properties = d
        return update_checklist_template_item_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
