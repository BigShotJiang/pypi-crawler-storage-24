from enum import Enum

class CorporateClientSourceOfFundsDtoSourceOfFunds(str, Enum):
    CUSTOMER_FUNDS = "CUSTOMER_FUNDS"
    INVESTOR_FUNDS = "INVESTOR_FUNDS"
    OPERATING_FUNDS = "OPERATING_FUNDS"
    OTHER = "OTHER"
    PROPRIETARY_FUNDS = "PROPRIETARY_FUNDS"
    TOKEN_GENERATION_EVENT = "TOKEN_GENERATION_EVENT"

    def __str__(self) -> str:
        return str(self.value)
