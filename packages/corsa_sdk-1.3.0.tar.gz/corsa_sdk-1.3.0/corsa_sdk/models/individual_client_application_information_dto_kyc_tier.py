from enum import Enum

class IndividualClientApplicationInformationDtoKycTier(str, Enum):
    TIER_1 = "TIER_1"
    TIER_2 = "TIER_2"
    TIER_3 = "TIER_3"

    def __str__(self) -> str:
        return str(self.value)
