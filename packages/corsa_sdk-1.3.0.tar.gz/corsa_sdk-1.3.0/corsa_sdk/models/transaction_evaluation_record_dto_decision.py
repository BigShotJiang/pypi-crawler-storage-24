from enum import Enum

class TransactionEvaluationRecordDtoDecision(str, Enum):
    ALLOW = "ALLOW"
    FREEZE = "FREEZE"

    def __str__(self) -> str:
        return str(self.value)
