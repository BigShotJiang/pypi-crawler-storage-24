from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.condition_result_dto_aggregation import ConditionResultDtoAggregation
  from ..models.condition_result_dto_fact_value_type_0 import ConditionResultDtoFactValueType0
  from ..models.condition_result_dto_value import ConditionResultDtoValue





T = TypeVar("T", bound="ConditionResultDto")



@_attrs_define
class ConditionResultDto:
    """ 
        Attributes:
            fact (str): Fact name that was evaluated
            operator (str): Operator used (greaterThan, lessThan, equal, etc.)
            value (ConditionResultDtoValue): Expected value from rule condition
            fact_value (ConditionResultDtoFactValueType0 | None): Actual value of the fact
            result (bool): Whether this condition passed
            fact_label (str | Unset): label for the fact
            aggregation (ConditionResultDtoAggregation | Unset): Aggregation definition when fact is an aggregation (present
                only for agg facts)
     """

    fact: str
    operator: str
    value: ConditionResultDtoValue
    fact_value: ConditionResultDtoFactValueType0 | None
    result: bool
    fact_label: str | Unset = UNSET
    aggregation: ConditionResultDtoAggregation | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.condition_result_dto_aggregation import ConditionResultDtoAggregation
        from ..models.condition_result_dto_fact_value_type_0 import ConditionResultDtoFactValueType0
        from ..models.condition_result_dto_value import ConditionResultDtoValue
        fact = self.fact

        operator = self.operator

        value = self.value.to_dict()

        fact_value: dict[str, Any] | None
        if isinstance(self.fact_value, ConditionResultDtoFactValueType0):
            fact_value = self.fact_value.to_dict()
        else:
            fact_value = self.fact_value

        result = self.result

        fact_label = self.fact_label

        aggregation: dict[str, Any] | Unset = UNSET
        if not isinstance(self.aggregation, Unset):
            aggregation = self.aggregation.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "fact": fact,
            "operator": operator,
            "value": value,
            "factValue": fact_value,
            "result": result,
        })
        if fact_label is not UNSET:
            field_dict["factLabel"] = fact_label
        if aggregation is not UNSET:
            field_dict["aggregation"] = aggregation

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.condition_result_dto_aggregation import ConditionResultDtoAggregation
        from ..models.condition_result_dto_fact_value_type_0 import ConditionResultDtoFactValueType0
        from ..models.condition_result_dto_value import ConditionResultDtoValue
        d = dict(src_dict)
        fact = d.pop("fact")

        operator = d.pop("operator")

        value = ConditionResultDtoValue.from_dict(d.pop("value"))




        def _parse_fact_value(data: object) -> ConditionResultDtoFactValueType0 | None:
            if data is None:
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                fact_value_type_0 = ConditionResultDtoFactValueType0.from_dict(data)



                return fact_value_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ConditionResultDtoFactValueType0 | None, data)

        fact_value = _parse_fact_value(d.pop("factValue"))


        result = d.pop("result")

        fact_label = d.pop("factLabel", UNSET)

        _aggregation = d.pop("aggregation", UNSET)
        aggregation: ConditionResultDtoAggregation | Unset
        if isinstance(_aggregation,  Unset):
            aggregation = UNSET
        else:
            aggregation = ConditionResultDtoAggregation.from_dict(_aggregation)




        condition_result_dto = cls(
            fact=fact,
            operator=operator,
            value=value,
            fact_value=fact_value,
            result=result,
            fact_label=fact_label,
            aggregation=aggregation,
        )


        condition_result_dto.additional_properties = d
        return condition_result_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
