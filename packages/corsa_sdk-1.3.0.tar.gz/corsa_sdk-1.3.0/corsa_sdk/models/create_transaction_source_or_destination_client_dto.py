from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="CreateTransactionSourceOrDestinationClientDto")



@_attrs_define
class CreateTransactionSourceOrDestinationClientDto:
    """ 
        Attributes:
            client (str | Unset): Client UUID associated with the transaction Example: 123e4567-e89b-12d3-a456-426614174000.
            bank_account_number (str | Unset): Bank account number associated with the transaction Example: 1234567890.
            wallet_address (str | Unset): Blockchain wallet address associated with the transaction Example:
                0x742d35Cc6634C0532925a3b844Bc454e4438f44e.
     """

    client: str | Unset = UNSET
    bank_account_number: str | Unset = UNSET
    wallet_address: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        client = self.client

        bank_account_number = self.bank_account_number

        wallet_address = self.wallet_address


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if client is not UNSET:
            field_dict["client"] = client
        if bank_account_number is not UNSET:
            field_dict["bankAccountNumber"] = bank_account_number
        if wallet_address is not UNSET:
            field_dict["walletAddress"] = wallet_address

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        client = d.pop("client", UNSET)

        bank_account_number = d.pop("bankAccountNumber", UNSET)

        wallet_address = d.pop("walletAddress", UNSET)

        create_transaction_source_or_destination_client_dto = cls(
            client=client,
            bank_account_number=bank_account_number,
            wallet_address=wallet_address,
        )


        create_transaction_source_or_destination_client_dto.additional_properties = d
        return create_transaction_source_or_destination_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
