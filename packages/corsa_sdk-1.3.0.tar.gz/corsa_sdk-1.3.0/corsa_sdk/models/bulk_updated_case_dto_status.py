from enum import Enum

class BulkUpdatedCaseDtoStatus(str, Enum):
    CLOSED_DISMISSED = "CLOSED_DISMISSED"
    CLOSED_ESCALATION_TO_SAR = "CLOSED_ESCALATION_TO_SAR"
    NEW = "NEW"
    PENDING_EDD = "PENDING_EDD"
    PENDING_REVIEW = "PENDING_REVIEW"
    PENDING_RFI = "PENDING_RFI"
    UNDER_INVESTIGATION = "UNDER_INVESTIGATION"

    def __str__(self) -> str:
        return str(self.value)
