from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.bank_account_dto_custom_fields import BankAccountDtoCustomFields
  from ..models.client_associated_to_account_dto import ClientAssociatedToAccountDto
  from ..models.risk_dto import RiskDto





T = TypeVar("T", bound="BankAccountDto")



@_attrs_define
class BankAccountDto:
    """ 
        Attributes:
            id (str): Unique identifier for the bank account Example: ba-123e4567-e89b-12d3-a456-426614174000.
            created_at (str): Timestamp when the bank account was created Example: 2024-01-15T10:30:00.000Z.
            updated_at (str): Timestamp when the bank account was last updated Example: 2024-01-15T10:30:00.000Z.
            account_number (str): Bank account number Example: 1234567890.
            risk_history (list[RiskDto]): Historical risk assessments
            reference_id (str | Unset): External reference ID for the bank account Example: REF-BA-001.
            bank_name (str | Unset): Name of the bank Example: Chase Bank.
            routing_number (str | Unset): Bank routing number Example: 021000021.
            account_holder_name (str | Unset): Name of the account holder Example: John Doe.
            account_type (str | Unset): Type of bank account Example: checking.
            currency (str | Unset): Currency of the bank account Example: USD.
            balance_in_currency (float | Unset): Balance in the currency of the bank account Example: 1000.5.
            balance_in_converted_amount (float | Unset): Balance in the converted amount (i.e USD), using preferred currency
                of the platform Example: 1000.5.
            countries (list[str] | Unset): Countries associated with the bank account Example: ['US'].
            associated_clients (list[ClientAssociatedToAccountDto] | Unset): Clients associated with this bank account
            current_risk (RiskDto | Unset):
            custom_fields (BankAccountDtoCustomFields | Unset): Custom fields data
     """

    id: str
    created_at: str
    updated_at: str
    account_number: str
    risk_history: list[RiskDto]
    reference_id: str | Unset = UNSET
    bank_name: str | Unset = UNSET
    routing_number: str | Unset = UNSET
    account_holder_name: str | Unset = UNSET
    account_type: str | Unset = UNSET
    currency: str | Unset = UNSET
    balance_in_currency: float | Unset = UNSET
    balance_in_converted_amount: float | Unset = UNSET
    countries: list[str] | Unset = UNSET
    associated_clients: list[ClientAssociatedToAccountDto] | Unset = UNSET
    current_risk: RiskDto | Unset = UNSET
    custom_fields: BankAccountDtoCustomFields | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.bank_account_dto_custom_fields import BankAccountDtoCustomFields
        from ..models.client_associated_to_account_dto import ClientAssociatedToAccountDto
        from ..models.risk_dto import RiskDto
        id = self.id

        created_at = self.created_at

        updated_at = self.updated_at

        account_number = self.account_number

        risk_history = []
        for risk_history_item_data in self.risk_history:
            risk_history_item = risk_history_item_data.to_dict()
            risk_history.append(risk_history_item)



        reference_id = self.reference_id

        bank_name = self.bank_name

        routing_number = self.routing_number

        account_holder_name = self.account_holder_name

        account_type = self.account_type

        currency = self.currency

        balance_in_currency = self.balance_in_currency

        balance_in_converted_amount = self.balance_in_converted_amount

        countries: list[str] | Unset = UNSET
        if not isinstance(self.countries, Unset):
            countries = self.countries



        associated_clients: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.associated_clients, Unset):
            associated_clients = []
            for associated_clients_item_data in self.associated_clients:
                associated_clients_item = associated_clients_item_data.to_dict()
                associated_clients.append(associated_clients_item)



        current_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.current_risk, Unset):
            current_risk = self.current_risk.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "createdAt": created_at,
            "updatedAt": updated_at,
            "accountNumber": account_number,
            "riskHistory": risk_history,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if bank_name is not UNSET:
            field_dict["bankName"] = bank_name
        if routing_number is not UNSET:
            field_dict["routingNumber"] = routing_number
        if account_holder_name is not UNSET:
            field_dict["accountHolderName"] = account_holder_name
        if account_type is not UNSET:
            field_dict["accountType"] = account_type
        if currency is not UNSET:
            field_dict["currency"] = currency
        if balance_in_currency is not UNSET:
            field_dict["balanceInCurrency"] = balance_in_currency
        if balance_in_converted_amount is not UNSET:
            field_dict["balanceInConvertedAmount"] = balance_in_converted_amount
        if countries is not UNSET:
            field_dict["countries"] = countries
        if associated_clients is not UNSET:
            field_dict["associatedClients"] = associated_clients
        if current_risk is not UNSET:
            field_dict["currentRisk"] = current_risk
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.bank_account_dto_custom_fields import BankAccountDtoCustomFields
        from ..models.client_associated_to_account_dto import ClientAssociatedToAccountDto
        from ..models.risk_dto import RiskDto
        d = dict(src_dict)
        id = d.pop("id")

        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        account_number = d.pop("accountNumber")

        risk_history = []
        _risk_history = d.pop("riskHistory")
        for risk_history_item_data in (_risk_history):
            risk_history_item = RiskDto.from_dict(risk_history_item_data)



            risk_history.append(risk_history_item)


        reference_id = d.pop("referenceId", UNSET)

        bank_name = d.pop("bankName", UNSET)

        routing_number = d.pop("routingNumber", UNSET)

        account_holder_name = d.pop("accountHolderName", UNSET)

        account_type = d.pop("accountType", UNSET)

        currency = d.pop("currency", UNSET)

        balance_in_currency = d.pop("balanceInCurrency", UNSET)

        balance_in_converted_amount = d.pop("balanceInConvertedAmount", UNSET)

        countries = cast(list[str], d.pop("countries", UNSET))


        _associated_clients = d.pop("associatedClients", UNSET)
        associated_clients: list[ClientAssociatedToAccountDto] | Unset = UNSET
        if _associated_clients is not UNSET:
            associated_clients = []
            for associated_clients_item_data in _associated_clients:
                associated_clients_item = ClientAssociatedToAccountDto.from_dict(associated_clients_item_data)



                associated_clients.append(associated_clients_item)


        _current_risk = d.pop("currentRisk", UNSET)
        current_risk: RiskDto | Unset
        if isinstance(_current_risk,  Unset):
            current_risk = UNSET
        else:
            current_risk = RiskDto.from_dict(_current_risk)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: BankAccountDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = BankAccountDtoCustomFields.from_dict(_custom_fields)




        bank_account_dto = cls(
            id=id,
            created_at=created_at,
            updated_at=updated_at,
            account_number=account_number,
            risk_history=risk_history,
            reference_id=reference_id,
            bank_name=bank_name,
            routing_number=routing_number,
            account_holder_name=account_holder_name,
            account_type=account_type,
            currency=currency,
            balance_in_currency=balance_in_currency,
            balance_in_converted_amount=balance_in_converted_amount,
            countries=countries,
            associated_clients=associated_clients,
            current_risk=current_risk,
            custom_fields=custom_fields,
        )


        bank_account_dto.additional_properties = d
        return bank_account_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
