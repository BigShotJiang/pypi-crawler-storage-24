from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.client_bank_account_relation_dto_status import ClientBankAccountRelationDtoStatus
from ..types import UNSET, Unset






T = TypeVar("T", bound="ClientBankAccountRelationDto")



@_attrs_define
class ClientBankAccountRelationDto:
    """ 
        Attributes:
            client_id (str): Client ID or reference ID to associate with the bank account Example: client-123.
            name (str | Unset): Custom name for this client-bank account relationship Example: Primary Business Account.
            status (ClientBankAccountRelationDtoStatus | Unset): Status of the client-bank account relationship Example:
                ACTIVE.
     """

    client_id: str
    name: str | Unset = UNSET
    status: ClientBankAccountRelationDtoStatus | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        client_id = self.client_id

        name = self.name

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "clientId": client_id,
        })
        if name is not UNSET:
            field_dict["name"] = name
        if status is not UNSET:
            field_dict["status"] = status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        client_id = d.pop("clientId")

        name = d.pop("name", UNSET)

        _status = d.pop("status", UNSET)
        status: ClientBankAccountRelationDtoStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = ClientBankAccountRelationDtoStatus(_status)




        client_bank_account_relation_dto = cls(
            client_id=client_id,
            name=name,
            status=status,
        )


        client_bank_account_relation_dto.additional_properties = d
        return client_bank_account_relation_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
