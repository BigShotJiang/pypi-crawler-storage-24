from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_individual_member_dto_adverse_media_status import UpdateIndividualMemberDtoAdverseMediaStatus
from ..models.update_individual_member_dto_liveness_check_status import UpdateIndividualMemberDtoLivenessCheckStatus
from ..models.update_individual_member_dto_pep_status import UpdateIndividualMemberDtoPepStatus
from ..models.update_individual_member_dto_role_type import UpdateIndividualMemberDtoRoleType
from ..models.update_individual_member_dto_sanctions_status import UpdateIndividualMemberDtoSanctionsStatus
from ..models.update_individual_member_dto_status import UpdateIndividualMemberDtoStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_identity_document_dto import CreateIdentityDocumentDto





T = TypeVar("T", bound="UpdateIndividualMemberDto")



@_attrs_define
class UpdateIndividualMemberDto:
    """ 
        Attributes:
            reference_id (str | Unset): External reference ID Example: MEM123.
            first_name (str | Unset): First name of the member Example: John.
            last_name (str | Unset): Last name of the member Example: Doe.
            middle_name (str | Unset): Middle name of the member Example: Michael.
            email (str | Unset): Email address of the member Example: john.doe@example.com.
            phone_number (str | Unset): Phone number of the member Example: +1-555-123-4567.
            residential_address_line_1 (str | Unset): First line of residential address Example: 123 Main Street.
            residential_address_line_2 (str | Unset): Second line of residential address Example: Apt 4B.
            residential_address_city (str | Unset): Residential address city Example: New York.
            residential_address_postal_code (str | Unset): Residential address postal code Example: 10001.
            residential_address_country (str | Unset): Residential address country code Example: USA.
            date_of_birth (str | Unset): Date of birth in ISO format Example: 1990-05-15T00:00:00Z.
            citizenship (str | Unset): Citizenship country code Example: USA.
            personal_id_number (str | Unset): Personal identification number Example: 123-45-6789.
            identity_documents (list[CreateIdentityDocumentDto] | Unset): Array of identity documents to replace existing
                ones (full replacement)
            liveness_check_image_url (str | Unset): URL to liveness check image Example:
                https://example.com/liveness/selfie.jpg.
            liveness_check_date (str | Unset): Date of liveness check Example: 2023-08-15T10:30:00Z.
            liveness_check_status (UpdateIndividualMemberDtoLivenessCheckStatus | Unset): Status of liveness check Example:
                APPROVED.
            ownership_percentage (float | Unset): Ownership percentage (0-100) Example: 25.5.
            sanctions_status (UpdateIndividualMemberDtoSanctionsStatus | Unset): Sanctions screening status Example: CLEAR.
            sanctions_status_date (str | Unset): Date of sanctions status determination Example: 2023-08-15T10:30:00Z.
            pep_status (UpdateIndividualMemberDtoPepStatus | Unset): PEP (Politically Exposed Person) status Example: CLEAR.
            pep_status_date (str | Unset): Date of PEP status determination Example: 2023-08-15T10:30:00Z.
            adverse_media_status (UpdateIndividualMemberDtoAdverseMediaStatus | Unset): Adverse media screening status
                Example: CLEAR.
            adverse_media_status_date (str | Unset): Date of adverse media status determination Example:
                2023-08-15T10:30:00Z.
            status (UpdateIndividualMemberDtoStatus | Unset): Overall member status Example: APPROVED.
            status_date (str | Unset): Date of status determination Example: 2023-08-15T10:30:00Z.
            title (str | Unset): Member's title or position Example: Chief Technology Officer.
            role_type (UpdateIndividualMemberDtoRoleType | Unset): Categorized role type Example: OFFICER.
            corporates (list[str] | Unset): List of corporate client IDs this member is associated with Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
     """

    reference_id: str | Unset = UNSET
    first_name: str | Unset = UNSET
    last_name: str | Unset = UNSET
    middle_name: str | Unset = UNSET
    email: str | Unset = UNSET
    phone_number: str | Unset = UNSET
    residential_address_line_1: str | Unset = UNSET
    residential_address_line_2: str | Unset = UNSET
    residential_address_city: str | Unset = UNSET
    residential_address_postal_code: str | Unset = UNSET
    residential_address_country: str | Unset = UNSET
    date_of_birth: str | Unset = UNSET
    citizenship: str | Unset = UNSET
    personal_id_number: str | Unset = UNSET
    identity_documents: list[CreateIdentityDocumentDto] | Unset = UNSET
    liveness_check_image_url: str | Unset = UNSET
    liveness_check_date: str | Unset = UNSET
    liveness_check_status: UpdateIndividualMemberDtoLivenessCheckStatus | Unset = UNSET
    ownership_percentage: float | Unset = UNSET
    sanctions_status: UpdateIndividualMemberDtoSanctionsStatus | Unset = UNSET
    sanctions_status_date: str | Unset = UNSET
    pep_status: UpdateIndividualMemberDtoPepStatus | Unset = UNSET
    pep_status_date: str | Unset = UNSET
    adverse_media_status: UpdateIndividualMemberDtoAdverseMediaStatus | Unset = UNSET
    adverse_media_status_date: str | Unset = UNSET
    status: UpdateIndividualMemberDtoStatus | Unset = UNSET
    status_date: str | Unset = UNSET
    title: str | Unset = UNSET
    role_type: UpdateIndividualMemberDtoRoleType | Unset = UNSET
    corporates: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_identity_document_dto import CreateIdentityDocumentDto
        reference_id = self.reference_id

        first_name = self.first_name

        last_name = self.last_name

        middle_name = self.middle_name

        email = self.email

        phone_number = self.phone_number

        residential_address_line_1 = self.residential_address_line_1

        residential_address_line_2 = self.residential_address_line_2

        residential_address_city = self.residential_address_city

        residential_address_postal_code = self.residential_address_postal_code

        residential_address_country = self.residential_address_country

        date_of_birth = self.date_of_birth

        citizenship = self.citizenship

        personal_id_number = self.personal_id_number

        identity_documents: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.identity_documents, Unset):
            identity_documents = []
            for identity_documents_item_data in self.identity_documents:
                identity_documents_item = identity_documents_item_data.to_dict()
                identity_documents.append(identity_documents_item)



        liveness_check_image_url = self.liveness_check_image_url

        liveness_check_date = self.liveness_check_date

        liveness_check_status: str | Unset = UNSET
        if not isinstance(self.liveness_check_status, Unset):
            liveness_check_status = self.liveness_check_status.value


        ownership_percentage = self.ownership_percentage

        sanctions_status: str | Unset = UNSET
        if not isinstance(self.sanctions_status, Unset):
            sanctions_status = self.sanctions_status.value


        sanctions_status_date = self.sanctions_status_date

        pep_status: str | Unset = UNSET
        if not isinstance(self.pep_status, Unset):
            pep_status = self.pep_status.value


        pep_status_date = self.pep_status_date

        adverse_media_status: str | Unset = UNSET
        if not isinstance(self.adverse_media_status, Unset):
            adverse_media_status = self.adverse_media_status.value


        adverse_media_status_date = self.adverse_media_status_date

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        status_date = self.status_date

        title = self.title

        role_type: str | Unset = UNSET
        if not isinstance(self.role_type, Unset):
            role_type = self.role_type.value


        corporates: list[str] | Unset = UNSET
        if not isinstance(self.corporates, Unset):
            corporates = self.corporates




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if first_name is not UNSET:
            field_dict["firstName"] = first_name
        if last_name is not UNSET:
            field_dict["lastName"] = last_name
        if middle_name is not UNSET:
            field_dict["middleName"] = middle_name
        if email is not UNSET:
            field_dict["email"] = email
        if phone_number is not UNSET:
            field_dict["phoneNumber"] = phone_number
        if residential_address_line_1 is not UNSET:
            field_dict["residentialAddressLine1"] = residential_address_line_1
        if residential_address_line_2 is not UNSET:
            field_dict["residentialAddressLine2"] = residential_address_line_2
        if residential_address_city is not UNSET:
            field_dict["residentialAddressCity"] = residential_address_city
        if residential_address_postal_code is not UNSET:
            field_dict["residentialAddressPostalCode"] = residential_address_postal_code
        if residential_address_country is not UNSET:
            field_dict["residentialAddressCountry"] = residential_address_country
        if date_of_birth is not UNSET:
            field_dict["dateOfBirth"] = date_of_birth
        if citizenship is not UNSET:
            field_dict["citizenship"] = citizenship
        if personal_id_number is not UNSET:
            field_dict["personalIdNumber"] = personal_id_number
        if identity_documents is not UNSET:
            field_dict["identityDocuments"] = identity_documents
        if liveness_check_image_url is not UNSET:
            field_dict["livenessCheckImageUrl"] = liveness_check_image_url
        if liveness_check_date is not UNSET:
            field_dict["livenessCheckDate"] = liveness_check_date
        if liveness_check_status is not UNSET:
            field_dict["livenessCheckStatus"] = liveness_check_status
        if ownership_percentage is not UNSET:
            field_dict["ownershipPercentage"] = ownership_percentage
        if sanctions_status is not UNSET:
            field_dict["sanctionsStatus"] = sanctions_status
        if sanctions_status_date is not UNSET:
            field_dict["sanctionsStatusDate"] = sanctions_status_date
        if pep_status is not UNSET:
            field_dict["pepStatus"] = pep_status
        if pep_status_date is not UNSET:
            field_dict["pepStatusDate"] = pep_status_date
        if adverse_media_status is not UNSET:
            field_dict["adverseMediaStatus"] = adverse_media_status
        if adverse_media_status_date is not UNSET:
            field_dict["adverseMediaStatusDate"] = adverse_media_status_date
        if status is not UNSET:
            field_dict["status"] = status
        if status_date is not UNSET:
            field_dict["statusDate"] = status_date
        if title is not UNSET:
            field_dict["title"] = title
        if role_type is not UNSET:
            field_dict["roleType"] = role_type
        if corporates is not UNSET:
            field_dict["corporates"] = corporates

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_identity_document_dto import CreateIdentityDocumentDto
        d = dict(src_dict)
        reference_id = d.pop("referenceId", UNSET)

        first_name = d.pop("firstName", UNSET)

        last_name = d.pop("lastName", UNSET)

        middle_name = d.pop("middleName", UNSET)

        email = d.pop("email", UNSET)

        phone_number = d.pop("phoneNumber", UNSET)

        residential_address_line_1 = d.pop("residentialAddressLine1", UNSET)

        residential_address_line_2 = d.pop("residentialAddressLine2", UNSET)

        residential_address_city = d.pop("residentialAddressCity", UNSET)

        residential_address_postal_code = d.pop("residentialAddressPostalCode", UNSET)

        residential_address_country = d.pop("residentialAddressCountry", UNSET)

        date_of_birth = d.pop("dateOfBirth", UNSET)

        citizenship = d.pop("citizenship", UNSET)

        personal_id_number = d.pop("personalIdNumber", UNSET)

        _identity_documents = d.pop("identityDocuments", UNSET)
        identity_documents: list[CreateIdentityDocumentDto] | Unset = UNSET
        if _identity_documents is not UNSET:
            identity_documents = []
            for identity_documents_item_data in _identity_documents:
                identity_documents_item = CreateIdentityDocumentDto.from_dict(identity_documents_item_data)



                identity_documents.append(identity_documents_item)


        liveness_check_image_url = d.pop("livenessCheckImageUrl", UNSET)

        liveness_check_date = d.pop("livenessCheckDate", UNSET)

        _liveness_check_status = d.pop("livenessCheckStatus", UNSET)
        liveness_check_status: UpdateIndividualMemberDtoLivenessCheckStatus | Unset
        if isinstance(_liveness_check_status,  Unset):
            liveness_check_status = UNSET
        else:
            liveness_check_status = UpdateIndividualMemberDtoLivenessCheckStatus(_liveness_check_status)




        ownership_percentage = d.pop("ownershipPercentage", UNSET)

        _sanctions_status = d.pop("sanctionsStatus", UNSET)
        sanctions_status: UpdateIndividualMemberDtoSanctionsStatus | Unset
        if isinstance(_sanctions_status,  Unset):
            sanctions_status = UNSET
        else:
            sanctions_status = UpdateIndividualMemberDtoSanctionsStatus(_sanctions_status)




        sanctions_status_date = d.pop("sanctionsStatusDate", UNSET)

        _pep_status = d.pop("pepStatus", UNSET)
        pep_status: UpdateIndividualMemberDtoPepStatus | Unset
        if isinstance(_pep_status,  Unset):
            pep_status = UNSET
        else:
            pep_status = UpdateIndividualMemberDtoPepStatus(_pep_status)




        pep_status_date = d.pop("pepStatusDate", UNSET)

        _adverse_media_status = d.pop("adverseMediaStatus", UNSET)
        adverse_media_status: UpdateIndividualMemberDtoAdverseMediaStatus | Unset
        if isinstance(_adverse_media_status,  Unset):
            adverse_media_status = UNSET
        else:
            adverse_media_status = UpdateIndividualMemberDtoAdverseMediaStatus(_adverse_media_status)




        adverse_media_status_date = d.pop("adverseMediaStatusDate", UNSET)

        _status = d.pop("status", UNSET)
        status: UpdateIndividualMemberDtoStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = UpdateIndividualMemberDtoStatus(_status)




        status_date = d.pop("statusDate", UNSET)

        title = d.pop("title", UNSET)

        _role_type = d.pop("roleType", UNSET)
        role_type: UpdateIndividualMemberDtoRoleType | Unset
        if isinstance(_role_type,  Unset):
            role_type = UNSET
        else:
            role_type = UpdateIndividualMemberDtoRoleType(_role_type)




        corporates = cast(list[str], d.pop("corporates", UNSET))


        update_individual_member_dto = cls(
            reference_id=reference_id,
            first_name=first_name,
            last_name=last_name,
            middle_name=middle_name,
            email=email,
            phone_number=phone_number,
            residential_address_line_1=residential_address_line_1,
            residential_address_line_2=residential_address_line_2,
            residential_address_city=residential_address_city,
            residential_address_postal_code=residential_address_postal_code,
            residential_address_country=residential_address_country,
            date_of_birth=date_of_birth,
            citizenship=citizenship,
            personal_id_number=personal_id_number,
            identity_documents=identity_documents,
            liveness_check_image_url=liveness_check_image_url,
            liveness_check_date=liveness_check_date,
            liveness_check_status=liveness_check_status,
            ownership_percentage=ownership_percentage,
            sanctions_status=sanctions_status,
            sanctions_status_date=sanctions_status_date,
            pep_status=pep_status,
            pep_status_date=pep_status_date,
            adverse_media_status=adverse_media_status,
            adverse_media_status_date=adverse_media_status_date,
            status=status,
            status_date=status_date,
            title=title,
            role_type=role_type,
            corporates=corporates,
        )


        update_individual_member_dto.additional_properties = d
        return update_individual_member_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
