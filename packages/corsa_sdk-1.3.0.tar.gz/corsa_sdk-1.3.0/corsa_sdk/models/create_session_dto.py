from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.device_dto import DeviceDto





T = TypeVar("T", bound="CreateSessionDto")



@_attrs_define
class CreateSessionDto:
    """ 
        Attributes:
            client_id (str): ID or referenceId of the client who owns this session Example:
                123e4567-e89b-12d3-a456-426614174000.
            ip_address (str): IP address of the session (IPv4 or IPv6) Example: 203.0.113.42.
            device (DeviceDto):
            reference_id (str | Unset): External session reference ID from platform client Example: sess_abc123.
            started_at (str | Unset): Session start time. Defaults to current time if not provided Example:
                2024-01-15T10:30:00Z.
     """

    client_id: str
    ip_address: str
    device: DeviceDto
    reference_id: str | Unset = UNSET
    started_at: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.device_dto import DeviceDto
        client_id = self.client_id

        ip_address = self.ip_address

        device = self.device.to_dict()

        reference_id = self.reference_id

        started_at = self.started_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "clientId": client_id,
            "ipAddress": ip_address,
            "device": device,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if started_at is not UNSET:
            field_dict["startedAt"] = started_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.device_dto import DeviceDto
        d = dict(src_dict)
        client_id = d.pop("clientId")

        ip_address = d.pop("ipAddress")

        device = DeviceDto.from_dict(d.pop("device"))




        reference_id = d.pop("referenceId", UNSET)

        started_at = d.pop("startedAt", UNSET)

        create_session_dto = cls(
            client_id=client_id,
            ip_address=ip_address,
            device=device,
            reference_id=reference_id,
            started_at=started_at,
        )


        create_session_dto.additional_properties = d
        return create_session_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
