from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_case_dto_category import CreateCaseDtoCategory
from ..models.create_case_dto_priority import CreateCaseDtoPriority
from ..models.create_case_dto_status import CreateCaseDtoStatus
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateCaseDto")



@_attrs_define
class CreateCaseDto:
    """ 
        Attributes:
            priority (CreateCaseDtoPriority): Priority of the case Example: HIGH.
            category (CreateCaseDtoCategory): Category of the case Example: KYC.
            reviewers_ids (list[str]): IDs of the reviewers of the case (maximum 50) Example: ['user_12345', 'user_67890'].
            status (CreateCaseDtoStatus): Current status of the case Example: UNDER_INVESTIGATION.
            reference_id (str | Unset): External reference ID for the case Example: REF-2024-001234.
            attachment_ids (list[str] | Unset): Array of attachment IDs associated with the case (maximum 100) Example:
                ['att_file1234', 'att_file5678'].
            sub_category (str | Unset): Subcategory of the case for more granular classification Example: Business
                Registration.
            assignee_id (str | Unset): ID of the user who assigned the case Example: user_12345.
            description (str | Unset): Description of the case Example: KYC review required for high-value client due to
                inconsistencies in provided documentation and elevated risk score..
            due_date (str | Unset): ISO Date when the case is due Example: 2024-01-20T00:00:00.000Z.
            alerts_ids (list[str] | Unset): IDs or Reference IDs of the alerts associated with the case (maximum 100)
                Example: ['alert_12345', 'alert_67890'].
            transactions_ids (list[str] | Unset): IDs or Reference IDs of the transactions associated with the case (maximum
                100) Example: ['transaction_12345', 'transaction_67890'].
            clients_ids (list[str] | Unset): IDs or Reference IDs of the clients associated with the case (maximum 50)
                Example: ['client_12345', 'client_67890'].
     """

    priority: CreateCaseDtoPriority
    category: CreateCaseDtoCategory
    reviewers_ids: list[str]
    status: CreateCaseDtoStatus
    reference_id: str | Unset = UNSET
    attachment_ids: list[str] | Unset = UNSET
    sub_category: str | Unset = UNSET
    assignee_id: str | Unset = UNSET
    description: str | Unset = UNSET
    due_date: str | Unset = UNSET
    alerts_ids: list[str] | Unset = UNSET
    transactions_ids: list[str] | Unset = UNSET
    clients_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        priority = self.priority.value

        category = self.category.value

        reviewers_ids = self.reviewers_ids



        status = self.status.value

        reference_id = self.reference_id

        attachment_ids: list[str] | Unset = UNSET
        if not isinstance(self.attachment_ids, Unset):
            attachment_ids = self.attachment_ids



        sub_category = self.sub_category

        assignee_id = self.assignee_id

        description = self.description

        due_date = self.due_date

        alerts_ids: list[str] | Unset = UNSET
        if not isinstance(self.alerts_ids, Unset):
            alerts_ids = self.alerts_ids



        transactions_ids: list[str] | Unset = UNSET
        if not isinstance(self.transactions_ids, Unset):
            transactions_ids = self.transactions_ids



        clients_ids: list[str] | Unset = UNSET
        if not isinstance(self.clients_ids, Unset):
            clients_ids = self.clients_ids




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "priority": priority,
            "category": category,
            "reviewersIds": reviewers_ids,
            "status": status,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if attachment_ids is not UNSET:
            field_dict["attachmentIds"] = attachment_ids
        if sub_category is not UNSET:
            field_dict["subCategory"] = sub_category
        if assignee_id is not UNSET:
            field_dict["assigneeId"] = assignee_id
        if description is not UNSET:
            field_dict["description"] = description
        if due_date is not UNSET:
            field_dict["dueDate"] = due_date
        if alerts_ids is not UNSET:
            field_dict["alertsIds"] = alerts_ids
        if transactions_ids is not UNSET:
            field_dict["transactionsIds"] = transactions_ids
        if clients_ids is not UNSET:
            field_dict["clientsIds"] = clients_ids

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        priority = CreateCaseDtoPriority(d.pop("priority"))




        category = CreateCaseDtoCategory(d.pop("category"))




        reviewers_ids = cast(list[str], d.pop("reviewersIds"))


        status = CreateCaseDtoStatus(d.pop("status"))




        reference_id = d.pop("referenceId", UNSET)

        attachment_ids = cast(list[str], d.pop("attachmentIds", UNSET))


        sub_category = d.pop("subCategory", UNSET)

        assignee_id = d.pop("assigneeId", UNSET)

        description = d.pop("description", UNSET)

        due_date = d.pop("dueDate", UNSET)

        alerts_ids = cast(list[str], d.pop("alertsIds", UNSET))


        transactions_ids = cast(list[str], d.pop("transactionsIds", UNSET))


        clients_ids = cast(list[str], d.pop("clientsIds", UNSET))


        create_case_dto = cls(
            priority=priority,
            category=category,
            reviewers_ids=reviewers_ids,
            status=status,
            reference_id=reference_id,
            attachment_ids=attachment_ids,
            sub_category=sub_category,
            assignee_id=assignee_id,
            description=description,
            due_date=due_date,
            alerts_ids=alerts_ids,
            transactions_ids=transactions_ids,
            clients_ids=clients_ids,
        )


        create_case_dto.additional_properties = d
        return create_case_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
