from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.risk_dto_level import RiskDtoLevel
from ..types import UNSET, Unset






T = TypeVar("T", bound="RiskDto")



@_attrs_define
class RiskDto:
    """ 
        Attributes:
            score (float): Risk score value for the client. The score is a number between 0 and 100. 0-49 is low, 50-74 is
                medium, 75-100 is high Example: 75.
            calculated_at (str): ISO timestamp when the risk was calculated Example: 2023-08-15T14:30:00Z.
            level (RiskDtoLevel | Unset): Risk level label based on the score. If you don't supply a level, the score will
                be used to calculate the level Example: HIGH.
            reason (str | Unset): Explanation for the assigned risk score Example: Multiple high-value transactions in high-
                risk jurisdictions.
     """

    score: float
    calculated_at: str
    level: RiskDtoLevel | Unset = UNSET
    reason: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        score = self.score

        calculated_at = self.calculated_at

        level: str | Unset = UNSET
        if not isinstance(self.level, Unset):
            level = self.level.value


        reason = self.reason


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "score": score,
            "calculatedAt": calculated_at,
        })
        if level is not UNSET:
            field_dict["level"] = level
        if reason is not UNSET:
            field_dict["reason"] = reason

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        score = d.pop("score")

        calculated_at = d.pop("calculatedAt")

        _level = d.pop("level", UNSET)
        level: RiskDtoLevel | Unset
        if isinstance(_level,  Unset):
            level = UNSET
        else:
            level = RiskDtoLevel(_level)




        reason = d.pop("reason", UNSET)

        risk_dto = cls(
            score=score,
            calculated_at=calculated_at,
            level=level,
            reason=reason,
        )


        risk_dto.additional_properties = d
        return risk_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
