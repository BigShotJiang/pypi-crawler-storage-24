from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.bulk_update_case_reviewers_dto_mode import BulkUpdateCaseReviewersDtoMode
from typing import cast






T = TypeVar("T", bound="BulkUpdateCaseReviewersDto")



@_attrs_define
class BulkUpdateCaseReviewersDto:
    """ 
        Attributes:
            case_ids (list[str]): Array of case IDs or reference IDs (maximum 100) Example:
                ['123e4567-e89b-12d3-a456-426614174000', 'CASE-REF-001'].
            mode (BulkUpdateCaseReviewersDtoMode): The update mode: SET replaces all reviewers, ADD appends to existing,
                REMOVE removes from existing Example: SET.
            reviewers_ids (list[str]): Array of reviewer user IDs. For SET mode, an empty array clears all reviewers. For
                ADD/REMOVE, at least one ID is required. Example: ['user-id-1', 'user-id-2'].
     """

    case_ids: list[str]
    mode: BulkUpdateCaseReviewersDtoMode
    reviewers_ids: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        case_ids = self.case_ids



        mode = self.mode.value

        reviewers_ids = self.reviewers_ids




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "caseIds": case_ids,
            "mode": mode,
            "reviewersIds": reviewers_ids,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        case_ids = cast(list[str], d.pop("caseIds"))


        mode = BulkUpdateCaseReviewersDtoMode(d.pop("mode"))




        reviewers_ids = cast(list[str], d.pop("reviewersIds"))


        bulk_update_case_reviewers_dto = cls(
            case_ids=case_ids,
            mode=mode,
            reviewers_ids=reviewers_ids,
        )


        bulk_update_case_reviewers_dto.additional_properties = d
        return bulk_update_case_reviewers_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
