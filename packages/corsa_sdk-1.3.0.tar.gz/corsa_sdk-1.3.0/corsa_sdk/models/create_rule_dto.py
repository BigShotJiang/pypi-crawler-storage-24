from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.action_config_dto import ActionConfigDto
  from ..models.conditions_dto import ConditionsDto





T = TypeVar("T", bound="CreateRuleDto")



@_attrs_define
class CreateRuleDto:
    """ 
        Attributes:
            name (str): User-facing rule name Example: High-risk withdrawal detection.
            actions (list[ActionConfigDto]): Actions to execute when rule matches Example: [{'type': 'CREATE_ALERT',
                'config': {'category': 'TRANSACTION_MONITORING', 'priority': 'HIGH', 'status': 'NEW'}}].
            conditions (ConditionsDto):
            description (str | Unset): Detailed description of what the rule does Example: Alert when high-risk customers
                make large withdrawals exceeding $50,000 in 24 hours.
     """

    name: str
    actions: list[ActionConfigDto]
    conditions: ConditionsDto
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.action_config_dto import ActionConfigDto
        from ..models.conditions_dto import ConditionsDto
        name = self.name

        actions = []
        for actions_item_data in self.actions:
            actions_item = actions_item_data.to_dict()
            actions.append(actions_item)



        conditions = self.conditions.to_dict()

        description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "actions": actions,
            "conditions": conditions,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_config_dto import ActionConfigDto
        from ..models.conditions_dto import ConditionsDto
        d = dict(src_dict)
        name = d.pop("name")

        actions = []
        _actions = d.pop("actions")
        for actions_item_data in (_actions):
            actions_item = ActionConfigDto.from_dict(actions_item_data)



            actions.append(actions_item)


        conditions = ConditionsDto.from_dict(d.pop("conditions"))




        description = d.pop("description", UNSET)

        create_rule_dto = cls(
            name=name,
            actions=actions,
            conditions=conditions,
            description=description,
        )


        create_rule_dto.additional_properties = d
        return create_rule_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
