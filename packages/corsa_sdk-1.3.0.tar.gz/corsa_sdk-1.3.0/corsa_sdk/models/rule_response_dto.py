from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rule_response_dto_status import RuleResponseDtoStatus
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.rule_response_dto_actions_item import RuleResponseDtoActionsItem
  from ..models.rule_response_dto_jre_rule import RuleResponseDtoJreRule





T = TypeVar("T", bound="RuleResponseDto")



@_attrs_define
class RuleResponseDto:
    """ 
        Attributes:
            id (str):
            version (float):
            status (RuleResponseDtoStatus):
            name (str):
            actions (list[RuleResponseDtoActionsItem]):
            jre_rule (RuleResponseDtoJreRule):
            created_by (str):
            created_at (datetime.datetime):
            description (None | str | Unset):
     """

    id: str
    version: float
    status: RuleResponseDtoStatus
    name: str
    actions: list[RuleResponseDtoActionsItem]
    jre_rule: RuleResponseDtoJreRule
    created_by: str
    created_at: datetime.datetime
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rule_response_dto_actions_item import RuleResponseDtoActionsItem
        from ..models.rule_response_dto_jre_rule import RuleResponseDtoJreRule
        id = self.id

        version = self.version

        status = self.status.value

        name = self.name

        actions = []
        for actions_item_data in self.actions:
            actions_item = actions_item_data.to_dict()
            actions.append(actions_item)



        jre_rule = self.jre_rule.to_dict()

        created_by = self.created_by

        created_at = self.created_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "version": version,
            "status": status,
            "name": name,
            "actions": actions,
            "jreRule": jre_rule,
            "createdBy": created_by,
            "createdAt": created_at,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rule_response_dto_actions_item import RuleResponseDtoActionsItem
        from ..models.rule_response_dto_jre_rule import RuleResponseDtoJreRule
        d = dict(src_dict)
        id = d.pop("id")

        version = d.pop("version")

        status = RuleResponseDtoStatus(d.pop("status"))




        name = d.pop("name")

        actions = []
        _actions = d.pop("actions")
        for actions_item_data in (_actions):
            actions_item = RuleResponseDtoActionsItem.from_dict(actions_item_data)



            actions.append(actions_item)


        jre_rule = RuleResponseDtoJreRule.from_dict(d.pop("jreRule"))




        created_by = d.pop("createdBy")

        created_at = isoparse(d.pop("createdAt"))




        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        rule_response_dto = cls(
            id=id,
            version=version,
            status=status,
            name=name,
            actions=actions,
            jre_rule=jre_rule,
            created_by=created_by,
            created_at=created_at,
            description=description,
        )


        rule_response_dto.additional_properties = d
        return rule_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
