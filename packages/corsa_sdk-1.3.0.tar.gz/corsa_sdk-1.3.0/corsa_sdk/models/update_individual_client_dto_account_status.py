from enum import Enum

class UpdateIndividualClientDtoAccountStatus(str, Enum):
    APPLICATION_IN_PROGRESS = "APPLICATION_IN_PROGRESS"
    APPROVED = "APPROVED"
    CLOSED_BY_CLIENT = "CLOSED_BY_CLIENT"
    FROZEN = "FROZEN"
    IN_REVIEW = "IN_REVIEW"
    OFF_BOARDED = "OFF_BOARDED"
    PENDING_DOCUMENTS = "PENDING_DOCUMENTS"
    REJECTED = "REJECTED"
    WAITING_FOR_REVIEW = "WAITING_FOR_REVIEW"

    def __str__(self) -> str:
        return str(self.value)
