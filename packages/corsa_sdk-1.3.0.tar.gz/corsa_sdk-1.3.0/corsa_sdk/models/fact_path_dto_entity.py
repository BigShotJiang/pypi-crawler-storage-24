from enum import Enum

class FactPathDtoEntity(str, Enum):
    BANKACCOUNT = "bankAccount"
    CUSTOMER = "customer"
    TXN = "txn"
    WALLET = "wallet"

    def __str__(self) -> str:
        return str(self.value)
