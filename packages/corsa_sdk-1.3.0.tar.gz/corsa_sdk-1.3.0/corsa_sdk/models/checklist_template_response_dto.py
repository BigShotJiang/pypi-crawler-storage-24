from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.checklist_template_response_dto_entity_type import ChecklistTemplateResponseDtoEntityType
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.checklist_template_item_response_dto import ChecklistTemplateItemResponseDto





T = TypeVar("T", bound="ChecklistTemplateResponseDto")



@_attrs_define
class ChecklistTemplateResponseDto:
    """ 
        Attributes:
            id (str): The unique identifier of the template Example: template-123.
            platform_id (str): The platform ID Example: platform-123.
            entity_type (ChecklistTemplateResponseDtoEntityType): The type of entity this template is for Example:
                INDIVIDUAL_CLIENT.
            name (str): The name of the template Example: KYC Compliance Template.
            is_active (bool): Whether the template is active Example: True.
            created_at (datetime.datetime): When the template was created Example: 2024-01-01T00:00:00.000Z.
            updated_at (datetime.datetime): When the template was last updated Example: 2024-01-01T00:00:00.000Z.
            items (list[ChecklistTemplateItemResponseDto]): The items in this template
            description (str | Unset): Optional description of the template Example: Standard KYC compliance checklist for
                individual clients.
     """

    id: str
    platform_id: str
    entity_type: ChecklistTemplateResponseDtoEntityType
    name: str
    is_active: bool
    created_at: datetime.datetime
    updated_at: datetime.datetime
    items: list[ChecklistTemplateItemResponseDto]
    description: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.checklist_template_item_response_dto import ChecklistTemplateItemResponseDto
        id = self.id

        platform_id = self.platform_id

        entity_type = self.entity_type.value

        name = self.name

        is_active = self.is_active

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)



        description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "platformId": platform_id,
            "entityType": entity_type,
            "name": name,
            "isActive": is_active,
            "createdAt": created_at,
            "updatedAt": updated_at,
            "items": items,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.checklist_template_item_response_dto import ChecklistTemplateItemResponseDto
        d = dict(src_dict)
        id = d.pop("id")

        platform_id = d.pop("platformId")

        entity_type = ChecklistTemplateResponseDtoEntityType(d.pop("entityType"))




        name = d.pop("name")

        is_active = d.pop("isActive")

        created_at = isoparse(d.pop("createdAt"))




        updated_at = isoparse(d.pop("updatedAt"))




        items = []
        _items = d.pop("items")
        for items_item_data in (_items):
            items_item = ChecklistTemplateItemResponseDto.from_dict(items_item_data)



            items.append(items_item)


        description = d.pop("description", UNSET)

        checklist_template_response_dto = cls(
            id=id,
            platform_id=platform_id,
            entity_type=entity_type,
            name=name,
            is_active=is_active,
            created_at=created_at,
            updated_at=updated_at,
            items=items,
            description=description,
        )


        checklist_template_response_dto.additional_properties = d
        return checklist_template_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
