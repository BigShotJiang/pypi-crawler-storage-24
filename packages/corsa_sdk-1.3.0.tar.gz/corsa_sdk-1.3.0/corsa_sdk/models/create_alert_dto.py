from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_alert_dto_category import CreateAlertDtoCategory
from ..models.create_alert_dto_pep_tier import CreateAlertDtoPepTier
from ..models.create_alert_dto_priority import CreateAlertDtoPriority
from ..models.create_alert_dto_research_risk_level import CreateAlertDtoResearchRiskLevel
from ..models.create_alert_dto_status import CreateAlertDtoStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.alert_decision_dto import AlertDecisionDto
  from ..models.alert_source_dto import AlertSourceDto
  from ..models.create_alert_dto_custom_fields import CreateAlertDtoCustomFields





T = TypeVar("T", bound="CreateAlertDto")



@_attrs_define
class CreateAlertDto:
    """ 
        Attributes:
            category (CreateAlertDtoCategory): Category of the alert Example: KYC.
            description (str): Description of the alert Example: Suspicious pattern detected.
            priority (CreateAlertDtoPriority): Priority level of the alert Example: HIGH.
            status (CreateAlertDtoStatus): Current status of the alert Example: NEW.
            assignee_id (str | Unset): UUID of the user assigned to handle this alert Example:
                123e4567-e89b-12d3-a456-426614174000.
            sub_category (str | Unset): Subcategory of the alert for more granular classification Example: Document
                Verification.
            raised_at (str | Unset): ISO timestamp when the alert was raised Example: 2023-08-15T10:30:00Z.
            reference_id (str | Unset): External reference ID for the alert Example: ALT123.
            source (AlertSourceDto | Unset):
            decision (AlertDecisionDto | Unset):
            associated_clients (list[str] | Unset): List of client IDs associated with this alert (maximum 10) Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
            associated_transactions (list[str] | Unset): List of transaction IDs associated with this alert (maximum 10)
                Example: ['123e4567-e89b-12d3-a456-426614174000'].
            attachment_ids (list[str] | Unset): List of attachment IDs associated with this alert
            custom_fields (CreateAlertDtoCustomFields | Unset): Custom fields data
            due_date (str | Unset): ISO Date when the alert is due Example: 2021-01-01T00:00:00.000Z.
            research_risk_level (CreateAlertDtoResearchRiskLevel | Unset): AI-assessed screening risk level
            research_risk_explanation (str | Unset): AI explanation for the risk assessment
            research_job_id (str | Unset): Deep research job ID that generated this alert
            sanction_lists_matched (list[str] | Unset): Names of matched sanctions lists
            sanction_lists_checked (list[str] | Unset): Names of all sanctions lists checked
            sanction_details (list[str] | Unset): Each element is a JSON-encoded sanction list entry
            pep_tier (CreateAlertDtoPepTier | Unset): PEP tier classification
            pep_positions (list[str] | Unset): Each element is a JSON-encoded PEP position entry
            pep_jurisdictions (list[str] | Unset): PEP jurisdiction country codes
            pep_details (str | Unset): PEP textual details
            adverse_media_total_items (float | Unset): Total adverse media items found
            adverse_media_direct_count (float | Unset): Adverse media items with direct relevance
            adverse_media_indirect_count (float | Unset): Adverse media items with indirect relevance
            adverse_media_articles (list[str] | Unset): Each element is a JSON-encoded adverse media article
            regulatory_actions_count (float | Unset): Total regulatory actions
            regulatory_active_count (float | Unset): Active regulatory actions count
            regulatory_details (list[str] | Unset): Each element is a JSON-encoded regulatory action entry
            associated_person_name (str | Unset): Associated person name (for corporate alerts)
            associated_person_role (str | Unset): Associated person role
            associated_person_member_ids (list[str] | Unset): Associated person member IDs
     """

    category: CreateAlertDtoCategory
    description: str
    priority: CreateAlertDtoPriority
    status: CreateAlertDtoStatus
    assignee_id: str | Unset = UNSET
    sub_category: str | Unset = UNSET
    raised_at: str | Unset = UNSET
    reference_id: str | Unset = UNSET
    source: AlertSourceDto | Unset = UNSET
    decision: AlertDecisionDto | Unset = UNSET
    associated_clients: list[str] | Unset = UNSET
    associated_transactions: list[str] | Unset = UNSET
    attachment_ids: list[str] | Unset = UNSET
    custom_fields: CreateAlertDtoCustomFields | Unset = UNSET
    due_date: str | Unset = UNSET
    research_risk_level: CreateAlertDtoResearchRiskLevel | Unset = UNSET
    research_risk_explanation: str | Unset = UNSET
    research_job_id: str | Unset = UNSET
    sanction_lists_matched: list[str] | Unset = UNSET
    sanction_lists_checked: list[str] | Unset = UNSET
    sanction_details: list[str] | Unset = UNSET
    pep_tier: CreateAlertDtoPepTier | Unset = UNSET
    pep_positions: list[str] | Unset = UNSET
    pep_jurisdictions: list[str] | Unset = UNSET
    pep_details: str | Unset = UNSET
    adverse_media_total_items: float | Unset = UNSET
    adverse_media_direct_count: float | Unset = UNSET
    adverse_media_indirect_count: float | Unset = UNSET
    adverse_media_articles: list[str] | Unset = UNSET
    regulatory_actions_count: float | Unset = UNSET
    regulatory_active_count: float | Unset = UNSET
    regulatory_details: list[str] | Unset = UNSET
    associated_person_name: str | Unset = UNSET
    associated_person_role: str | Unset = UNSET
    associated_person_member_ids: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.alert_decision_dto import AlertDecisionDto
        from ..models.alert_source_dto import AlertSourceDto
        from ..models.create_alert_dto_custom_fields import CreateAlertDtoCustomFields
        category = self.category.value

        description = self.description

        priority = self.priority.value

        status = self.status.value

        assignee_id = self.assignee_id

        sub_category = self.sub_category

        raised_at = self.raised_at

        reference_id = self.reference_id

        source: dict[str, Any] | Unset = UNSET
        if not isinstance(self.source, Unset):
            source = self.source.to_dict()

        decision: dict[str, Any] | Unset = UNSET
        if not isinstance(self.decision, Unset):
            decision = self.decision.to_dict()

        associated_clients: list[str] | Unset = UNSET
        if not isinstance(self.associated_clients, Unset):
            associated_clients = self.associated_clients



        associated_transactions: list[str] | Unset = UNSET
        if not isinstance(self.associated_transactions, Unset):
            associated_transactions = self.associated_transactions



        attachment_ids: list[str] | Unset = UNSET
        if not isinstance(self.attachment_ids, Unset):
            attachment_ids = self.attachment_ids



        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        due_date = self.due_date

        research_risk_level: str | Unset = UNSET
        if not isinstance(self.research_risk_level, Unset):
            research_risk_level = self.research_risk_level.value


        research_risk_explanation = self.research_risk_explanation

        research_job_id = self.research_job_id

        sanction_lists_matched: list[str] | Unset = UNSET
        if not isinstance(self.sanction_lists_matched, Unset):
            sanction_lists_matched = self.sanction_lists_matched



        sanction_lists_checked: list[str] | Unset = UNSET
        if not isinstance(self.sanction_lists_checked, Unset):
            sanction_lists_checked = self.sanction_lists_checked



        sanction_details: list[str] | Unset = UNSET
        if not isinstance(self.sanction_details, Unset):
            sanction_details = self.sanction_details



        pep_tier: str | Unset = UNSET
        if not isinstance(self.pep_tier, Unset):
            pep_tier = self.pep_tier.value


        pep_positions: list[str] | Unset = UNSET
        if not isinstance(self.pep_positions, Unset):
            pep_positions = self.pep_positions



        pep_jurisdictions: list[str] | Unset = UNSET
        if not isinstance(self.pep_jurisdictions, Unset):
            pep_jurisdictions = self.pep_jurisdictions



        pep_details = self.pep_details

        adverse_media_total_items = self.adverse_media_total_items

        adverse_media_direct_count = self.adverse_media_direct_count

        adverse_media_indirect_count = self.adverse_media_indirect_count

        adverse_media_articles: list[str] | Unset = UNSET
        if not isinstance(self.adverse_media_articles, Unset):
            adverse_media_articles = self.adverse_media_articles



        regulatory_actions_count = self.regulatory_actions_count

        regulatory_active_count = self.regulatory_active_count

        regulatory_details: list[str] | Unset = UNSET
        if not isinstance(self.regulatory_details, Unset):
            regulatory_details = self.regulatory_details



        associated_person_name = self.associated_person_name

        associated_person_role = self.associated_person_role

        associated_person_member_ids: list[str] | Unset = UNSET
        if not isinstance(self.associated_person_member_ids, Unset):
            associated_person_member_ids = self.associated_person_member_ids




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "category": category,
            "description": description,
            "priority": priority,
            "status": status,
        })
        if assignee_id is not UNSET:
            field_dict["assigneeId"] = assignee_id
        if sub_category is not UNSET:
            field_dict["subCategory"] = sub_category
        if raised_at is not UNSET:
            field_dict["raisedAt"] = raised_at
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if source is not UNSET:
            field_dict["source"] = source
        if decision is not UNSET:
            field_dict["decision"] = decision
        if associated_clients is not UNSET:
            field_dict["associatedClients"] = associated_clients
        if associated_transactions is not UNSET:
            field_dict["associatedTransactions"] = associated_transactions
        if attachment_ids is not UNSET:
            field_dict["attachmentIds"] = attachment_ids
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if due_date is not UNSET:
            field_dict["dueDate"] = due_date
        if research_risk_level is not UNSET:
            field_dict["researchRiskLevel"] = research_risk_level
        if research_risk_explanation is not UNSET:
            field_dict["researchRiskExplanation"] = research_risk_explanation
        if research_job_id is not UNSET:
            field_dict["researchJobId"] = research_job_id
        if sanction_lists_matched is not UNSET:
            field_dict["sanctionListsMatched"] = sanction_lists_matched
        if sanction_lists_checked is not UNSET:
            field_dict["sanctionListsChecked"] = sanction_lists_checked
        if sanction_details is not UNSET:
            field_dict["sanctionDetails"] = sanction_details
        if pep_tier is not UNSET:
            field_dict["pepTier"] = pep_tier
        if pep_positions is not UNSET:
            field_dict["pepPositions"] = pep_positions
        if pep_jurisdictions is not UNSET:
            field_dict["pepJurisdictions"] = pep_jurisdictions
        if pep_details is not UNSET:
            field_dict["pepDetails"] = pep_details
        if adverse_media_total_items is not UNSET:
            field_dict["adverseMediaTotalItems"] = adverse_media_total_items
        if adverse_media_direct_count is not UNSET:
            field_dict["adverseMediaDirectCount"] = adverse_media_direct_count
        if adverse_media_indirect_count is not UNSET:
            field_dict["adverseMediaIndirectCount"] = adverse_media_indirect_count
        if adverse_media_articles is not UNSET:
            field_dict["adverseMediaArticles"] = adverse_media_articles
        if regulatory_actions_count is not UNSET:
            field_dict["regulatoryActionsCount"] = regulatory_actions_count
        if regulatory_active_count is not UNSET:
            field_dict["regulatoryActiveCount"] = regulatory_active_count
        if regulatory_details is not UNSET:
            field_dict["regulatoryDetails"] = regulatory_details
        if associated_person_name is not UNSET:
            field_dict["associatedPersonName"] = associated_person_name
        if associated_person_role is not UNSET:
            field_dict["associatedPersonRole"] = associated_person_role
        if associated_person_member_ids is not UNSET:
            field_dict["associatedPersonMemberIds"] = associated_person_member_ids

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_decision_dto import AlertDecisionDto
        from ..models.alert_source_dto import AlertSourceDto
        from ..models.create_alert_dto_custom_fields import CreateAlertDtoCustomFields
        d = dict(src_dict)
        category = CreateAlertDtoCategory(d.pop("category"))




        description = d.pop("description")

        priority = CreateAlertDtoPriority(d.pop("priority"))




        status = CreateAlertDtoStatus(d.pop("status"))




        assignee_id = d.pop("assigneeId", UNSET)

        sub_category = d.pop("subCategory", UNSET)

        raised_at = d.pop("raisedAt", UNSET)

        reference_id = d.pop("referenceId", UNSET)

        _source = d.pop("source", UNSET)
        source: AlertSourceDto | Unset
        if isinstance(_source,  Unset):
            source = UNSET
        else:
            source = AlertSourceDto.from_dict(_source)




        _decision = d.pop("decision", UNSET)
        decision: AlertDecisionDto | Unset
        if isinstance(_decision,  Unset):
            decision = UNSET
        else:
            decision = AlertDecisionDto.from_dict(_decision)




        associated_clients = cast(list[str], d.pop("associatedClients", UNSET))


        associated_transactions = cast(list[str], d.pop("associatedTransactions", UNSET))


        attachment_ids = cast(list[str], d.pop("attachmentIds", UNSET))


        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: CreateAlertDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = CreateAlertDtoCustomFields.from_dict(_custom_fields)




        due_date = d.pop("dueDate", UNSET)

        _research_risk_level = d.pop("researchRiskLevel", UNSET)
        research_risk_level: CreateAlertDtoResearchRiskLevel | Unset
        if isinstance(_research_risk_level,  Unset):
            research_risk_level = UNSET
        else:
            research_risk_level = CreateAlertDtoResearchRiskLevel(_research_risk_level)




        research_risk_explanation = d.pop("researchRiskExplanation", UNSET)

        research_job_id = d.pop("researchJobId", UNSET)

        sanction_lists_matched = cast(list[str], d.pop("sanctionListsMatched", UNSET))


        sanction_lists_checked = cast(list[str], d.pop("sanctionListsChecked", UNSET))


        sanction_details = cast(list[str], d.pop("sanctionDetails", UNSET))


        _pep_tier = d.pop("pepTier", UNSET)
        pep_tier: CreateAlertDtoPepTier | Unset
        if isinstance(_pep_tier,  Unset):
            pep_tier = UNSET
        else:
            pep_tier = CreateAlertDtoPepTier(_pep_tier)




        pep_positions = cast(list[str], d.pop("pepPositions", UNSET))


        pep_jurisdictions = cast(list[str], d.pop("pepJurisdictions", UNSET))


        pep_details = d.pop("pepDetails", UNSET)

        adverse_media_total_items = d.pop("adverseMediaTotalItems", UNSET)

        adverse_media_direct_count = d.pop("adverseMediaDirectCount", UNSET)

        adverse_media_indirect_count = d.pop("adverseMediaIndirectCount", UNSET)

        adverse_media_articles = cast(list[str], d.pop("adverseMediaArticles", UNSET))


        regulatory_actions_count = d.pop("regulatoryActionsCount", UNSET)

        regulatory_active_count = d.pop("regulatoryActiveCount", UNSET)

        regulatory_details = cast(list[str], d.pop("regulatoryDetails", UNSET))


        associated_person_name = d.pop("associatedPersonName", UNSET)

        associated_person_role = d.pop("associatedPersonRole", UNSET)

        associated_person_member_ids = cast(list[str], d.pop("associatedPersonMemberIds", UNSET))


        create_alert_dto = cls(
            category=category,
            description=description,
            priority=priority,
            status=status,
            assignee_id=assignee_id,
            sub_category=sub_category,
            raised_at=raised_at,
            reference_id=reference_id,
            source=source,
            decision=decision,
            associated_clients=associated_clients,
            associated_transactions=associated_transactions,
            attachment_ids=attachment_ids,
            custom_fields=custom_fields,
            due_date=due_date,
            research_risk_level=research_risk_level,
            research_risk_explanation=research_risk_explanation,
            research_job_id=research_job_id,
            sanction_lists_matched=sanction_lists_matched,
            sanction_lists_checked=sanction_lists_checked,
            sanction_details=sanction_details,
            pep_tier=pep_tier,
            pep_positions=pep_positions,
            pep_jurisdictions=pep_jurisdictions,
            pep_details=pep_details,
            adverse_media_total_items=adverse_media_total_items,
            adverse_media_direct_count=adverse_media_direct_count,
            adverse_media_indirect_count=adverse_media_indirect_count,
            adverse_media_articles=adverse_media_articles,
            regulatory_actions_count=regulatory_actions_count,
            regulatory_active_count=regulatory_active_count,
            regulatory_details=regulatory_details,
            associated_person_name=associated_person_name,
            associated_person_role=associated_person_role,
            associated_person_member_ids=associated_person_member_ids,
        )


        create_alert_dto.additional_properties = d
        return create_alert_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
