from enum import Enum

class GetCorporateClientIntegrationId(str, Enum):
    CHAINALYSIS = "CHAINALYSIS"
    PLAIN = "PLAIN"
    SUMSUB = "SUMSUB"

    def __str__(self) -> str:
        return str(self.value)
