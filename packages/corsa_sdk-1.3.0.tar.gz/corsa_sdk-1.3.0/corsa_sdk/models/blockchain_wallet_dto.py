from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.blockchain_wallet_dto_custom_fields import BlockchainWalletDtoCustomFields
  from ..models.blockchain_wallet_integrations_dto import BlockchainWalletIntegrationsDto
  from ..models.client_associated_to_blockchain_wallet_dto import ClientAssociatedToBlockchainWalletDto
  from ..models.risk_dto import RiskDto





T = TypeVar("T", bound="BlockchainWalletDto")



@_attrs_define
class BlockchainWalletDto:
    """ 
        Attributes:
            id (str): Unique identifier for the blockchain wallet Example: bw-123e4567-e89b-12d3-a456-426614174000.
            created_at (str): Timestamp when the wallet was created Example: 2024-01-15T10:30:00.000Z.
            updated_at (str): Timestamp when the wallet was last updated Example: 2024-01-15T10:30:00.000Z.
            address (str): Wallet address on the blockchain Example: 0x742d35Cc6634C0532925a3b844Bc454e4438f44e.
            risk_history (list[RiskDto]): Historical risk assessments
            reference_id (str | Unset): External reference ID for the blockchain wallet Example: REF-WALLET-001.
            screening_date (str | Unset): Screening date of the blockchain wallet Example: 2024-01-15T10:30:00.000Z.
            chain (str | Unset): Blockchain network or chain identifier Example: ethereum.
            associated_clients (list[ClientAssociatedToBlockchainWalletDto] | Unset): Clients associated with this
                blockchain wallet
            current_risk (RiskDto | Unset):
            custom_fields (BlockchainWalletDtoCustomFields | Unset): Custom fields data
            integrations (BlockchainWalletIntegrationsDto | Unset):
     """

    id: str
    created_at: str
    updated_at: str
    address: str
    risk_history: list[RiskDto]
    reference_id: str | Unset = UNSET
    screening_date: str | Unset = UNSET
    chain: str | Unset = UNSET
    associated_clients: list[ClientAssociatedToBlockchainWalletDto] | Unset = UNSET
    current_risk: RiskDto | Unset = UNSET
    custom_fields: BlockchainWalletDtoCustomFields | Unset = UNSET
    integrations: BlockchainWalletIntegrationsDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.blockchain_wallet_dto_custom_fields import BlockchainWalletDtoCustomFields
        from ..models.blockchain_wallet_integrations_dto import BlockchainWalletIntegrationsDto
        from ..models.client_associated_to_blockchain_wallet_dto import ClientAssociatedToBlockchainWalletDto
        from ..models.risk_dto import RiskDto
        id = self.id

        created_at = self.created_at

        updated_at = self.updated_at

        address = self.address

        risk_history = []
        for risk_history_item_data in self.risk_history:
            risk_history_item = risk_history_item_data.to_dict()
            risk_history.append(risk_history_item)



        reference_id = self.reference_id

        screening_date = self.screening_date

        chain = self.chain

        associated_clients: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.associated_clients, Unset):
            associated_clients = []
            for associated_clients_item_data in self.associated_clients:
                associated_clients_item = associated_clients_item_data.to_dict()
                associated_clients.append(associated_clients_item)



        current_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.current_risk, Unset):
            current_risk = self.current_risk.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "createdAt": created_at,
            "updatedAt": updated_at,
            "address": address,
            "riskHistory": risk_history,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if screening_date is not UNSET:
            field_dict["screeningDate"] = screening_date
        if chain is not UNSET:
            field_dict["chain"] = chain
        if associated_clients is not UNSET:
            field_dict["associatedClients"] = associated_clients
        if current_risk is not UNSET:
            field_dict["currentRisk"] = current_risk
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if integrations is not UNSET:
            field_dict["integrations"] = integrations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.blockchain_wallet_dto_custom_fields import BlockchainWalletDtoCustomFields
        from ..models.blockchain_wallet_integrations_dto import BlockchainWalletIntegrationsDto
        from ..models.client_associated_to_blockchain_wallet_dto import ClientAssociatedToBlockchainWalletDto
        from ..models.risk_dto import RiskDto
        d = dict(src_dict)
        id = d.pop("id")

        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        address = d.pop("address")

        risk_history = []
        _risk_history = d.pop("riskHistory")
        for risk_history_item_data in (_risk_history):
            risk_history_item = RiskDto.from_dict(risk_history_item_data)



            risk_history.append(risk_history_item)


        reference_id = d.pop("referenceId", UNSET)

        screening_date = d.pop("screeningDate", UNSET)

        chain = d.pop("chain", UNSET)

        _associated_clients = d.pop("associatedClients", UNSET)
        associated_clients: list[ClientAssociatedToBlockchainWalletDto] | Unset = UNSET
        if _associated_clients is not UNSET:
            associated_clients = []
            for associated_clients_item_data in _associated_clients:
                associated_clients_item = ClientAssociatedToBlockchainWalletDto.from_dict(associated_clients_item_data)



                associated_clients.append(associated_clients_item)


        _current_risk = d.pop("currentRisk", UNSET)
        current_risk: RiskDto | Unset
        if isinstance(_current_risk,  Unset):
            current_risk = UNSET
        else:
            current_risk = RiskDto.from_dict(_current_risk)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: BlockchainWalletDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = BlockchainWalletDtoCustomFields.from_dict(_custom_fields)




        _integrations = d.pop("integrations", UNSET)
        integrations: BlockchainWalletIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = BlockchainWalletIntegrationsDto.from_dict(_integrations)




        blockchain_wallet_dto = cls(
            id=id,
            created_at=created_at,
            updated_at=updated_at,
            address=address,
            risk_history=risk_history,
            reference_id=reference_id,
            screening_date=screening_date,
            chain=chain,
            associated_clients=associated_clients,
            current_risk=current_risk,
            custom_fields=custom_fields,
            integrations=integrations,
        )


        blockchain_wallet_dto.additional_properties = d
        return blockchain_wallet_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
