from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="ChecklistItemResponseDtoCustomFields")



@_attrs_define
class ChecklistItemResponseDtoCustomFields:
    """ Additional custom fields for the checklist item

        Example:
            {'priority': {'label': 'Priority Level', 'value': 'high', 'description': 'Urgency level of this item',
                'category': 'workflow', 'possibleValues': ['low', 'medium', 'high', 'critical'], 'immutable': False}, 'tags':
                {'label': 'Tags', 'value': ['urgent', 'review'], 'description': 'Classification tags', 'category':
                'organization', 'immutable': False}}

     """

    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        
        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        checklist_item_response_dto_custom_fields = cls(
        )


        checklist_item_response_dto_custom_fields.additional_properties = d
        return checklist_item_response_dto_custom_fields

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
