from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="CaseInvestigationData")



@_attrs_define
class CaseInvestigationData:
    """ 
        Attributes:
            last_edited_at (datetime.datetime): Timestamp of the last edit Example: 2024-01-15T14:22:30.000Z.
            content (str | Unset): Investigation content and notes Example: Client provided additional KYC documents.
                Verified identity through passport and utility bill. No adverse findings in background check..
            nickname (str | Unset): Nickname or alias for the investigation Example: High-Risk Client Review.
            last_editor_id (str | Unset): ID of the user who last edited the investigation Example: analyst_67890.
     """

    last_edited_at: datetime.datetime
    content: str | Unset = UNSET
    nickname: str | Unset = UNSET
    last_editor_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        last_edited_at = self.last_edited_at.isoformat()

        content = self.content

        nickname = self.nickname

        last_editor_id = self.last_editor_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "lastEditedAt": last_edited_at,
        })
        if content is not UNSET:
            field_dict["content"] = content
        if nickname is not UNSET:
            field_dict["nickname"] = nickname
        if last_editor_id is not UNSET:
            field_dict["lastEditorId"] = last_editor_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        last_edited_at = isoparse(d.pop("lastEditedAt"))




        content = d.pop("content", UNSET)

        nickname = d.pop("nickname", UNSET)

        last_editor_id = d.pop("lastEditorId", UNSET)

        case_investigation_data = cls(
            last_edited_at=last_edited_at,
            content=content,
            nickname=nickname,
            last_editor_id=last_editor_id,
        )


        case_investigation_data.additional_properties = d
        return case_investigation_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
