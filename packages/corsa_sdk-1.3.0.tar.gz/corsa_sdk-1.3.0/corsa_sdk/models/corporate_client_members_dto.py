from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.corporate_member_dto import CorporateMemberDto
  from ..models.individual_member_dto import IndividualMemberDto





T = TypeVar("T", bound="CorporateClientMembersDto")



@_attrs_define
class CorporateClientMembersDto:
    """ 
        Attributes:
            corporate_members (list[CorporateMemberDto] | Unset): List of corporate members (subsidiaries, parent companies,
                etc.)
            individual_members (list[IndividualMemberDto] | Unset): List of individual members (directors, officers,
                beneficial owners, etc.)
     """

    corporate_members: list[CorporateMemberDto] | Unset = UNSET
    individual_members: list[IndividualMemberDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.corporate_member_dto import CorporateMemberDto
        from ..models.individual_member_dto import IndividualMemberDto
        corporate_members: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.corporate_members, Unset):
            corporate_members = []
            for corporate_members_item_data in self.corporate_members:
                corporate_members_item = corporate_members_item_data.to_dict()
                corporate_members.append(corporate_members_item)



        individual_members: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.individual_members, Unset):
            individual_members = []
            for individual_members_item_data in self.individual_members:
                individual_members_item = individual_members_item_data.to_dict()
                individual_members.append(individual_members_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if corporate_members is not UNSET:
            field_dict["corporateMembers"] = corporate_members
        if individual_members is not UNSET:
            field_dict["individualMembers"] = individual_members

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.corporate_member_dto import CorporateMemberDto
        from ..models.individual_member_dto import IndividualMemberDto
        d = dict(src_dict)
        _corporate_members = d.pop("corporateMembers", UNSET)
        corporate_members: list[CorporateMemberDto] | Unset = UNSET
        if _corporate_members is not UNSET:
            corporate_members = []
            for corporate_members_item_data in _corporate_members:
                corporate_members_item = CorporateMemberDto.from_dict(corporate_members_item_data)



                corporate_members.append(corporate_members_item)


        _individual_members = d.pop("individualMembers", UNSET)
        individual_members: list[IndividualMemberDto] | Unset = UNSET
        if _individual_members is not UNSET:
            individual_members = []
            for individual_members_item_data in _individual_members:
                individual_members_item = IndividualMemberDto.from_dict(individual_members_item_data)



                individual_members.append(individual_members_item)


        corporate_client_members_dto = cls(
            corporate_members=corporate_members,
            individual_members=individual_members,
        )


        corporate_client_members_dto.additional_properties = d
        return corporate_client_members_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
