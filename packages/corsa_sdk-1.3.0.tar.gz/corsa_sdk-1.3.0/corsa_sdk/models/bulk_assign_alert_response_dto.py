from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.bulk_assigned_alert_dto import BulkAssignedAlertDto
  from ..models.bulk_failed_alert_dto import BulkFailedAlertDto





T = TypeVar("T", bound="BulkAssignAlertResponseDto")



@_attrs_define
class BulkAssignAlertResponseDto:
    """ 
        Attributes:
            failed_alerts (list[BulkFailedAlertDto]): Array of alerts that failed to process
            total_processed (float): Total number of alerts processed Example: 10.
            success_count (float): Number of alerts successfully processed Example: 8.
            failure_count (float): Number of alerts that failed to process Example: 2.
            skipped_count (float): Number of alerts skipped (already in target state) Example: 1.
            updated_alerts (list[BulkAssignedAlertDto]): Array of successfully updated alerts
     """

    failed_alerts: list[BulkFailedAlertDto]
    total_processed: float
    success_count: float
    failure_count: float
    skipped_count: float
    updated_alerts: list[BulkAssignedAlertDto]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.bulk_assigned_alert_dto import BulkAssignedAlertDto
        from ..models.bulk_failed_alert_dto import BulkFailedAlertDto
        failed_alerts = []
        for failed_alerts_item_data in self.failed_alerts:
            failed_alerts_item = failed_alerts_item_data.to_dict()
            failed_alerts.append(failed_alerts_item)



        total_processed = self.total_processed

        success_count = self.success_count

        failure_count = self.failure_count

        skipped_count = self.skipped_count

        updated_alerts = []
        for updated_alerts_item_data in self.updated_alerts:
            updated_alerts_item = updated_alerts_item_data.to_dict()
            updated_alerts.append(updated_alerts_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "failedAlerts": failed_alerts,
            "totalProcessed": total_processed,
            "successCount": success_count,
            "failureCount": failure_count,
            "skippedCount": skipped_count,
            "updatedAlerts": updated_alerts,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.bulk_assigned_alert_dto import BulkAssignedAlertDto
        from ..models.bulk_failed_alert_dto import BulkFailedAlertDto
        d = dict(src_dict)
        failed_alerts = []
        _failed_alerts = d.pop("failedAlerts")
        for failed_alerts_item_data in (_failed_alerts):
            failed_alerts_item = BulkFailedAlertDto.from_dict(failed_alerts_item_data)



            failed_alerts.append(failed_alerts_item)


        total_processed = d.pop("totalProcessed")

        success_count = d.pop("successCount")

        failure_count = d.pop("failureCount")

        skipped_count = d.pop("skippedCount")

        updated_alerts = []
        _updated_alerts = d.pop("updatedAlerts")
        for updated_alerts_item_data in (_updated_alerts):
            updated_alerts_item = BulkAssignedAlertDto.from_dict(updated_alerts_item_data)



            updated_alerts.append(updated_alerts_item)


        bulk_assign_alert_response_dto = cls(
            failed_alerts=failed_alerts,
            total_processed=total_processed,
            success_count=success_count,
            failure_count=failure_count,
            skipped_count=skipped_count,
            updated_alerts=updated_alerts,
        )


        bulk_assign_alert_response_dto.additional_properties = d
        return bulk_assign_alert_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
