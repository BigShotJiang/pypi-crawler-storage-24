from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.individual_member_dto_adverse_media_status import IndividualMemberDtoAdverseMediaStatus
from ..models.individual_member_dto_liveness_check_status import IndividualMemberDtoLivenessCheckStatus
from ..models.individual_member_dto_member_type import IndividualMemberDtoMemberType
from ..models.individual_member_dto_pep_status import IndividualMemberDtoPepStatus
from ..models.individual_member_dto_role_type import IndividualMemberDtoRoleType
from ..models.individual_member_dto_sanctions_status import IndividualMemberDtoSanctionsStatus
from ..models.individual_member_dto_status import IndividualMemberDtoStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.identity_document_dto import IdentityDocumentDto





T = TypeVar("T", bound="IndividualMemberDto")



@_attrs_define
class IndividualMemberDto:
    """ 
        Attributes:
            id (str): Unique identifier of the member Example: 123e4567-e89b-12d3-a456-426614174000.
            platform_id (str): Platform identifier Example: platform-123.
            created_at (str): ISO timestamp of creation Example: 2023-08-15T10:30:00Z.
            updated_at (str): ISO timestamp of last update Example: 2023-08-20T14:30:00Z.
            member_type (IndividualMemberDtoMemberType): Type of member Example: INDIVIDUAL.
            first_name (str): First name of the member Example: John.
            last_name (str): Last name of the member Example: Doe.
            sanctions_status (IndividualMemberDtoSanctionsStatus): Sanctions screening status Example: CLEAR.
            pep_status (IndividualMemberDtoPepStatus): PEP (Politically Exposed Person) status Example: CLEAR.
            adverse_media_status (IndividualMemberDtoAdverseMediaStatus): Adverse media screening status Example: CLEAR.
            status (IndividualMemberDtoStatus): Overall member status Example: APPROVED.
            status_date (str): Date of status determination Example: 2023-08-15T10:30:00Z.
            title (str): Member's title or position Example: Chief Technology Officer.
            role_type (IndividualMemberDtoRoleType): Categorized role type Example: OFFICER.
            reference_id (str | Unset): External reference ID Example: MEM123.
            middle_name (str | Unset): Middle name of the member Example: Michael.
            email (str | Unset): Email address of the member Example: john.doe@example.com.
            phone_number (str | Unset): Phone number of the member Example: +1-555-123-4567.
            residential_address_line_1 (str | Unset): First line of residential address Example: 123 Main Street.
            residential_address_line_2 (str | Unset): Second line of residential address Example: Apt 4B.
            residential_address_city (str | Unset): Residential address city Example: New York.
            residential_address_postal_code (str | Unset): Residential address postal code Example: 10001.
            residential_address_country (str | Unset): Residential address country code Example: USA.
            date_of_birth (str | Unset): Date of birth in ISO format Example: 1990-05-15T00:00:00Z.
            citizenship (str | Unset): Citizenship country code Example: USA.
            personal_id_number (str | Unset): Personal identification number Example: 123-45-6789.
            identity_documents (list[IdentityDocumentDto] | Unset): Array of identity documents
            liveness_check_image_url (str | Unset): URL to liveness check image Example:
                https://example.com/liveness/selfie.jpg.
            liveness_check_date (str | Unset): Date of liveness check Example: 2023-08-15T10:30:00Z.
            liveness_check_status (IndividualMemberDtoLivenessCheckStatus | Unset): Status of liveness check Example:
                APPROVED.
            ownership_percentage (float | Unset): Ownership percentage (0-100) Example: 25.5.
            sanctions_status_date (str | Unset): Date of sanctions status determination Example: 2023-08-15T10:30:00Z.
            pep_status_date (str | Unset): Date of PEP status determination Example: 2023-08-15T10:30:00Z.
            adverse_media_status_date (str | Unset): Date of adverse media status determination Example:
                2023-08-15T10:30:00Z.
            corporates (list[str] | Unset): List of corporate client IDs this member is associated with Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
     """

    id: str
    platform_id: str
    created_at: str
    updated_at: str
    member_type: IndividualMemberDtoMemberType
    first_name: str
    last_name: str
    sanctions_status: IndividualMemberDtoSanctionsStatus
    pep_status: IndividualMemberDtoPepStatus
    adverse_media_status: IndividualMemberDtoAdverseMediaStatus
    status: IndividualMemberDtoStatus
    status_date: str
    title: str
    role_type: IndividualMemberDtoRoleType
    reference_id: str | Unset = UNSET
    middle_name: str | Unset = UNSET
    email: str | Unset = UNSET
    phone_number: str | Unset = UNSET
    residential_address_line_1: str | Unset = UNSET
    residential_address_line_2: str | Unset = UNSET
    residential_address_city: str | Unset = UNSET
    residential_address_postal_code: str | Unset = UNSET
    residential_address_country: str | Unset = UNSET
    date_of_birth: str | Unset = UNSET
    citizenship: str | Unset = UNSET
    personal_id_number: str | Unset = UNSET
    identity_documents: list[IdentityDocumentDto] | Unset = UNSET
    liveness_check_image_url: str | Unset = UNSET
    liveness_check_date: str | Unset = UNSET
    liveness_check_status: IndividualMemberDtoLivenessCheckStatus | Unset = UNSET
    ownership_percentage: float | Unset = UNSET
    sanctions_status_date: str | Unset = UNSET
    pep_status_date: str | Unset = UNSET
    adverse_media_status_date: str | Unset = UNSET
    corporates: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.identity_document_dto import IdentityDocumentDto
        id = self.id

        platform_id = self.platform_id

        created_at = self.created_at

        updated_at = self.updated_at

        member_type = self.member_type.value

        first_name = self.first_name

        last_name = self.last_name

        sanctions_status = self.sanctions_status.value

        pep_status = self.pep_status.value

        adverse_media_status = self.adverse_media_status.value

        status = self.status.value

        status_date = self.status_date

        title = self.title

        role_type = self.role_type.value

        reference_id = self.reference_id

        middle_name = self.middle_name

        email = self.email

        phone_number = self.phone_number

        residential_address_line_1 = self.residential_address_line_1

        residential_address_line_2 = self.residential_address_line_2

        residential_address_city = self.residential_address_city

        residential_address_postal_code = self.residential_address_postal_code

        residential_address_country = self.residential_address_country

        date_of_birth = self.date_of_birth

        citizenship = self.citizenship

        personal_id_number = self.personal_id_number

        identity_documents: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.identity_documents, Unset):
            identity_documents = []
            for identity_documents_item_data in self.identity_documents:
                identity_documents_item = identity_documents_item_data.to_dict()
                identity_documents.append(identity_documents_item)



        liveness_check_image_url = self.liveness_check_image_url

        liveness_check_date = self.liveness_check_date

        liveness_check_status: str | Unset = UNSET
        if not isinstance(self.liveness_check_status, Unset):
            liveness_check_status = self.liveness_check_status.value


        ownership_percentage = self.ownership_percentage

        sanctions_status_date = self.sanctions_status_date

        pep_status_date = self.pep_status_date

        adverse_media_status_date = self.adverse_media_status_date

        corporates: list[str] | Unset = UNSET
        if not isinstance(self.corporates, Unset):
            corporates = self.corporates




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "platformId": platform_id,
            "createdAt": created_at,
            "updatedAt": updated_at,
            "memberType": member_type,
            "firstName": first_name,
            "lastName": last_name,
            "sanctionsStatus": sanctions_status,
            "pepStatus": pep_status,
            "adverseMediaStatus": adverse_media_status,
            "status": status,
            "statusDate": status_date,
            "title": title,
            "roleType": role_type,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if middle_name is not UNSET:
            field_dict["middleName"] = middle_name
        if email is not UNSET:
            field_dict["email"] = email
        if phone_number is not UNSET:
            field_dict["phoneNumber"] = phone_number
        if residential_address_line_1 is not UNSET:
            field_dict["residentialAddressLine1"] = residential_address_line_1
        if residential_address_line_2 is not UNSET:
            field_dict["residentialAddressLine2"] = residential_address_line_2
        if residential_address_city is not UNSET:
            field_dict["residentialAddressCity"] = residential_address_city
        if residential_address_postal_code is not UNSET:
            field_dict["residentialAddressPostalCode"] = residential_address_postal_code
        if residential_address_country is not UNSET:
            field_dict["residentialAddressCountry"] = residential_address_country
        if date_of_birth is not UNSET:
            field_dict["dateOfBirth"] = date_of_birth
        if citizenship is not UNSET:
            field_dict["citizenship"] = citizenship
        if personal_id_number is not UNSET:
            field_dict["personalIdNumber"] = personal_id_number
        if identity_documents is not UNSET:
            field_dict["identityDocuments"] = identity_documents
        if liveness_check_image_url is not UNSET:
            field_dict["livenessCheckImageUrl"] = liveness_check_image_url
        if liveness_check_date is not UNSET:
            field_dict["livenessCheckDate"] = liveness_check_date
        if liveness_check_status is not UNSET:
            field_dict["livenessCheckStatus"] = liveness_check_status
        if ownership_percentage is not UNSET:
            field_dict["ownershipPercentage"] = ownership_percentage
        if sanctions_status_date is not UNSET:
            field_dict["sanctionsStatusDate"] = sanctions_status_date
        if pep_status_date is not UNSET:
            field_dict["pepStatusDate"] = pep_status_date
        if adverse_media_status_date is not UNSET:
            field_dict["adverseMediaStatusDate"] = adverse_media_status_date
        if corporates is not UNSET:
            field_dict["corporates"] = corporates

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.identity_document_dto import IdentityDocumentDto
        d = dict(src_dict)
        id = d.pop("id")

        platform_id = d.pop("platformId")

        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        member_type = IndividualMemberDtoMemberType(d.pop("memberType"))




        first_name = d.pop("firstName")

        last_name = d.pop("lastName")

        sanctions_status = IndividualMemberDtoSanctionsStatus(d.pop("sanctionsStatus"))




        pep_status = IndividualMemberDtoPepStatus(d.pop("pepStatus"))




        adverse_media_status = IndividualMemberDtoAdverseMediaStatus(d.pop("adverseMediaStatus"))




        status = IndividualMemberDtoStatus(d.pop("status"))




        status_date = d.pop("statusDate")

        title = d.pop("title")

        role_type = IndividualMemberDtoRoleType(d.pop("roleType"))




        reference_id = d.pop("referenceId", UNSET)

        middle_name = d.pop("middleName", UNSET)

        email = d.pop("email", UNSET)

        phone_number = d.pop("phoneNumber", UNSET)

        residential_address_line_1 = d.pop("residentialAddressLine1", UNSET)

        residential_address_line_2 = d.pop("residentialAddressLine2", UNSET)

        residential_address_city = d.pop("residentialAddressCity", UNSET)

        residential_address_postal_code = d.pop("residentialAddressPostalCode", UNSET)

        residential_address_country = d.pop("residentialAddressCountry", UNSET)

        date_of_birth = d.pop("dateOfBirth", UNSET)

        citizenship = d.pop("citizenship", UNSET)

        personal_id_number = d.pop("personalIdNumber", UNSET)

        _identity_documents = d.pop("identityDocuments", UNSET)
        identity_documents: list[IdentityDocumentDto] | Unset = UNSET
        if _identity_documents is not UNSET:
            identity_documents = []
            for identity_documents_item_data in _identity_documents:
                identity_documents_item = IdentityDocumentDto.from_dict(identity_documents_item_data)



                identity_documents.append(identity_documents_item)


        liveness_check_image_url = d.pop("livenessCheckImageUrl", UNSET)

        liveness_check_date = d.pop("livenessCheckDate", UNSET)

        _liveness_check_status = d.pop("livenessCheckStatus", UNSET)
        liveness_check_status: IndividualMemberDtoLivenessCheckStatus | Unset
        if isinstance(_liveness_check_status,  Unset):
            liveness_check_status = UNSET
        else:
            liveness_check_status = IndividualMemberDtoLivenessCheckStatus(_liveness_check_status)




        ownership_percentage = d.pop("ownershipPercentage", UNSET)

        sanctions_status_date = d.pop("sanctionsStatusDate", UNSET)

        pep_status_date = d.pop("pepStatusDate", UNSET)

        adverse_media_status_date = d.pop("adverseMediaStatusDate", UNSET)

        corporates = cast(list[str], d.pop("corporates", UNSET))


        individual_member_dto = cls(
            id=id,
            platform_id=platform_id,
            created_at=created_at,
            updated_at=updated_at,
            member_type=member_type,
            first_name=first_name,
            last_name=last_name,
            sanctions_status=sanctions_status,
            pep_status=pep_status,
            adverse_media_status=adverse_media_status,
            status=status,
            status_date=status_date,
            title=title,
            role_type=role_type,
            reference_id=reference_id,
            middle_name=middle_name,
            email=email,
            phone_number=phone_number,
            residential_address_line_1=residential_address_line_1,
            residential_address_line_2=residential_address_line_2,
            residential_address_city=residential_address_city,
            residential_address_postal_code=residential_address_postal_code,
            residential_address_country=residential_address_country,
            date_of_birth=date_of_birth,
            citizenship=citizenship,
            personal_id_number=personal_id_number,
            identity_documents=identity_documents,
            liveness_check_image_url=liveness_check_image_url,
            liveness_check_date=liveness_check_date,
            liveness_check_status=liveness_check_status,
            ownership_percentage=ownership_percentage,
            sanctions_status_date=sanctions_status_date,
            pep_status_date=pep_status_date,
            adverse_media_status_date=adverse_media_status_date,
            corporates=corporates,
        )


        individual_member_dto.additional_properties = d
        return individual_member_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
