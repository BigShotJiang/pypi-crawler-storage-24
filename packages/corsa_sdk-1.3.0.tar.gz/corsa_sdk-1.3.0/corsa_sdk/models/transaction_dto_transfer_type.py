from enum import Enum

class TransactionDtoTransferType(str, Enum):
    DOMESTIC = "DOMESTIC"
    INTERNAL = "INTERNAL"
    INTERNATIONAL = "INTERNATIONAL"

    def __str__(self) -> str:
        return str(self.value)
