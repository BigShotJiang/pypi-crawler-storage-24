from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="BulkUpdatedCaseReviewersDto")



@_attrs_define
class BulkUpdatedCaseReviewersDto:
    """ 
        Attributes:
            id (str): The ID of the updated case Example: 123e4567-e89b-12d3-a456-426614174000.
            reviewers_ids (list[str]): The updated list of reviewer IDs for the case Example: ['user-id-1', 'user-id-2'].
            reference_id (str | Unset): The reference ID of the updated case Example: CASE-REF-001.
     """

    id: str
    reviewers_ids: list[str]
    reference_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        reviewers_ids = self.reviewers_ids



        reference_id = self.reference_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "reviewersIds": reviewers_ids,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        reviewers_ids = cast(list[str], d.pop("reviewersIds"))


        reference_id = d.pop("referenceId", UNSET)

        bulk_updated_case_reviewers_dto = cls(
            id=id,
            reviewers_ids=reviewers_ids,
            reference_id=reference_id,
        )


        bulk_updated_case_reviewers_dto.additional_properties = d
        return bulk_updated_case_reviewers_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
