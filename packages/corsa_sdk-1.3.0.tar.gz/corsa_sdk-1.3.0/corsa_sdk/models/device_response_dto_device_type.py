from enum import Enum

class DeviceResponseDtoDeviceType(str, Enum):
    DESKTOP = "DESKTOP"
    MOBILE = "MOBILE"
    TABLET = "TABLET"
    UNKNOWN = "UNKNOWN"

    def __str__(self) -> str:
        return str(self.value)
