from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.case_status_data_status import CaseStatusDataStatus
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="CaseStatusData")



@_attrs_define
class CaseStatusData:
    """ 
        Attributes:
            status (CaseStatusDataStatus): Current status of the case Example: UNDER_INVESTIGATION.
            evaluated_at (datetime.datetime): Timestamp when the status was evaluated Example: 2024-01-15T10:30:00.000Z.
            reason (str | Unset): Reason for the status change Example: Additional documentation required from client.
            sub_status (str | Unset): Sub-status providing additional context Example: AWAITING_DOCUMENTS.
            evaluated_by (str | Unset): ID of the user who evaluated the status Example: user_12345.
     """

    status: CaseStatusDataStatus
    evaluated_at: datetime.datetime
    reason: str | Unset = UNSET
    sub_status: str | Unset = UNSET
    evaluated_by: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        evaluated_at = self.evaluated_at.isoformat()

        reason = self.reason

        sub_status = self.sub_status

        evaluated_by = self.evaluated_by


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
            "evaluatedAt": evaluated_at,
        })
        if reason is not UNSET:
            field_dict["reason"] = reason
        if sub_status is not UNSET:
            field_dict["subStatus"] = sub_status
        if evaluated_by is not UNSET:
            field_dict["evaluatedBy"] = evaluated_by

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = CaseStatusDataStatus(d.pop("status"))




        evaluated_at = isoparse(d.pop("evaluatedAt"))




        reason = d.pop("reason", UNSET)

        sub_status = d.pop("subStatus", UNSET)

        evaluated_by = d.pop("evaluatedBy", UNSET)

        case_status_data = cls(
            status=status,
            evaluated_at=evaluated_at,
            reason=reason,
            sub_status=sub_status,
            evaluated_by=evaluated_by,
        )


        case_status_data.additional_properties = d
        return case_status_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
