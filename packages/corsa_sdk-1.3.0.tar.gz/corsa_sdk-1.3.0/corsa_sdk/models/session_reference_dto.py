from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_session_dto import CreateSessionDto





T = TypeVar("T", bound="SessionReferenceDto")



@_attrs_define
class SessionReferenceDto:
    """ 
        Attributes:
            session_id (str | Unset): ID of an existing session to link to this operation Example:
                123e4567-e89b-12d3-a456-426614174000.
            inline_session (CreateSessionDto | Unset):
     """

    session_id: str | Unset = UNSET
    inline_session: CreateSessionDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_session_dto import CreateSessionDto
        session_id = self.session_id

        inline_session: dict[str, Any] | Unset = UNSET
        if not isinstance(self.inline_session, Unset):
            inline_session = self.inline_session.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if session_id is not UNSET:
            field_dict["sessionId"] = session_id
        if inline_session is not UNSET:
            field_dict["inlineSession"] = inline_session

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_session_dto import CreateSessionDto
        d = dict(src_dict)
        session_id = d.pop("sessionId", UNSET)

        _inline_session = d.pop("inlineSession", UNSET)
        inline_session: CreateSessionDto | Unset
        if isinstance(_inline_session,  Unset):
            inline_session = UNSET
        else:
            inline_session = CreateSessionDto.from_dict(_inline_session)




        session_reference_dto = cls(
            session_id=session_id,
            inline_session=inline_session,
        )


        session_reference_dto.additional_properties = d
        return session_reference_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
