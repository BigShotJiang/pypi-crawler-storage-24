from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.relate_attachments_dto_entity_type import RelateAttachmentsDtoEntityType
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="RelateAttachmentsDto")



@_attrs_define
class RelateAttachmentsDto:
    """ 
        Attributes:
            file_ids (list[str]): Array of attachment IDs to relate to the entity (maximum 100) Example:
                ['att_123e4567-e89b-12d3-a456-426614174000', 'att_456e7890-e12b-34c5-d678-901234567890'].
            entity_id (str): ID of the entity to relate attachments to Example: case_123e4567-e89b-12d3-a456-426614174000.
            entity_type (RelateAttachmentsDtoEntityType): Type of entity to relate attachments to Example: case.
            document_mime_type (str | Unset): The MIME type of the document (used when entityType is checklist_item)
                Example: application/pdf.
     """

    file_ids: list[str]
    entity_id: str
    entity_type: RelateAttachmentsDtoEntityType
    document_mime_type: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        file_ids = self.file_ids



        entity_id = self.entity_id

        entity_type = self.entity_type.value

        document_mime_type = self.document_mime_type


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "fileIds": file_ids,
            "entityId": entity_id,
            "entityType": entity_type,
        })
        if document_mime_type is not UNSET:
            field_dict["documentMimeType"] = document_mime_type

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        file_ids = cast(list[str], d.pop("fileIds"))


        entity_id = d.pop("entityId")

        entity_type = RelateAttachmentsDtoEntityType(d.pop("entityType"))




        document_mime_type = d.pop("documentMimeType", UNSET)

        relate_attachments_dto = cls(
            file_ids=file_ids,
            entity_id=entity_id,
            entity_type=entity_type,
            document_mime_type=document_mime_type,
        )


        relate_attachments_dto.additional_properties = d
        return relate_attachments_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
