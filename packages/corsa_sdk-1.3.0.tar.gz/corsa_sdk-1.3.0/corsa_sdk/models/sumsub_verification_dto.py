from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.sumsub_verification_image_dto import SumsubVerificationImageDto





T = TypeVar("T", bound="SumsubVerificationDto")



@_attrs_define
class SumsubVerificationDto:
    """ 
        Attributes:
            title (str | Unset): Title of the verification Example: Identity Verification.
            status (str | Unset): Status of the verification Example: approved.
            country (str | Unset): Country code Example: USA.
            document_type (str | Unset): Type of document Example: passport.
            images (list[SumsubVerificationImageDto] | Unset): Verification images
     """

    title: str | Unset = UNSET
    status: str | Unset = UNSET
    country: str | Unset = UNSET
    document_type: str | Unset = UNSET
    images: list[SumsubVerificationImageDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.sumsub_verification_image_dto import SumsubVerificationImageDto
        title = self.title

        status = self.status

        country = self.country

        document_type = self.document_type

        images: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.images, Unset):
            images = []
            for images_item_data in self.images:
                images_item = images_item_data.to_dict()
                images.append(images_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if title is not UNSET:
            field_dict["title"] = title
        if status is not UNSET:
            field_dict["status"] = status
        if country is not UNSET:
            field_dict["country"] = country
        if document_type is not UNSET:
            field_dict["documentType"] = document_type
        if images is not UNSET:
            field_dict["images"] = images

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.sumsub_verification_image_dto import SumsubVerificationImageDto
        d = dict(src_dict)
        title = d.pop("title", UNSET)

        status = d.pop("status", UNSET)

        country = d.pop("country", UNSET)

        document_type = d.pop("documentType", UNSET)

        _images = d.pop("images", UNSET)
        images: list[SumsubVerificationImageDto] | Unset = UNSET
        if _images is not UNSET:
            images = []
            for images_item_data in _images:
                images_item = SumsubVerificationImageDto.from_dict(images_item_data)



                images.append(images_item)


        sumsub_verification_dto = cls(
            title=title,
            status=status,
            country=country,
            document_type=document_type,
            images=images,
        )


        sumsub_verification_dto.additional_properties = d
        return sumsub_verification_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
