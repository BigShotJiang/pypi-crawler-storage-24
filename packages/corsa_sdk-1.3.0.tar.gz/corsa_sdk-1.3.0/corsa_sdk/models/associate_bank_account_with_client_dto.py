from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.client_bank_account_relation_dto import ClientBankAccountRelationDto





T = TypeVar("T", bound="AssociateBankAccountWithClientDto")



@_attrs_define
class AssociateBankAccountWithClientDto:
    """ 
        Attributes:
            clients (list[ClientBankAccountRelationDto]): List of clients to associate with the bank account (maximum 50)
                Example: [{'clientId': 'client-123', 'name': 'Primary Account'}, {'clientId': 'client-456', 'name': 'Secondary
                Account'}].
     """

    clients: list[ClientBankAccountRelationDto]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.client_bank_account_relation_dto import ClientBankAccountRelationDto
        clients = []
        for clients_item_data in self.clients:
            clients_item = clients_item_data.to_dict()
            clients.append(clients_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "clients": clients,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.client_bank_account_relation_dto import ClientBankAccountRelationDto
        d = dict(src_dict)
        clients = []
        _clients = d.pop("clients")
        for clients_item_data in (_clients):
            clients_item = ClientBankAccountRelationDto.from_dict(clients_item_data)



            clients.append(clients_item)


        associate_bank_account_with_client_dto = cls(
            clients=clients,
        )


        associate_bank_account_with_client_dto.additional_properties = d
        return associate_bank_account_with_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
