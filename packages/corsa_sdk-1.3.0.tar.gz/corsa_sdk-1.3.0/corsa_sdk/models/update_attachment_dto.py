from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_attachment_dto_entity_type import UpdateAttachmentDtoEntityType
from ..models.update_attachment_dto_source import UpdateAttachmentDtoSource
from ..types import UNSET, Unset






T = TypeVar("T", bound="UpdateAttachmentDto")



@_attrs_define
class UpdateAttachmentDto:
    """ 
        Attributes:
            entity_type (UpdateAttachmentDtoEntityType | Unset): Type of entity the attachment is associated with Example:
                case.
            entity_id (str | Unset): ID of the entity the attachment is associated with Example:
                case_123e4567-e89b-12d3-a456-426614174000.
            file_name (str | Unset): New file name for the attachment Example: updated_document.pdf.
            source (UpdateAttachmentDtoSource | Unset): The source of the attachment Example: DOCUMENT_REPOSITORY.
     """

    entity_type: UpdateAttachmentDtoEntityType | Unset = UNSET
    entity_id: str | Unset = UNSET
    file_name: str | Unset = UNSET
    source: UpdateAttachmentDtoSource | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        entity_type: str | Unset = UNSET
        if not isinstance(self.entity_type, Unset):
            entity_type = self.entity_type.value


        entity_id = self.entity_id

        file_name = self.file_name

        source: str | Unset = UNSET
        if not isinstance(self.source, Unset):
            source = self.source.value



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if entity_type is not UNSET:
            field_dict["entityType"] = entity_type
        if entity_id is not UNSET:
            field_dict["entityId"] = entity_id
        if file_name is not UNSET:
            field_dict["fileName"] = file_name
        if source is not UNSET:
            field_dict["source"] = source

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _entity_type = d.pop("entityType", UNSET)
        entity_type: UpdateAttachmentDtoEntityType | Unset
        if isinstance(_entity_type,  Unset):
            entity_type = UNSET
        else:
            entity_type = UpdateAttachmentDtoEntityType(_entity_type)




        entity_id = d.pop("entityId", UNSET)

        file_name = d.pop("fileName", UNSET)

        _source = d.pop("source", UNSET)
        source: UpdateAttachmentDtoSource | Unset
        if isinstance(_source,  Unset):
            source = UNSET
        else:
            source = UpdateAttachmentDtoSource(_source)




        update_attachment_dto = cls(
            entity_type=entity_type,
            entity_id=entity_id,
            file_name=file_name,
            source=source,
        )


        update_attachment_dto.additional_properties = d
        return update_attachment_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
