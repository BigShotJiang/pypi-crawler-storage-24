from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_individual_client_dto_account_status import CreateIndividualClientDtoAccountStatus
from ..models.create_individual_client_dto_activity_status import CreateIndividualClientDtoActivityStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.adverse_media_dto import AdverseMediaDto
  from ..models.create_individual_client_dto_custom_fields import CreateIndividualClientDtoCustomFields
  from ..models.individual_client_address_dto import IndividualClientAddressDto
  from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
  from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
  from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
  from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
  from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
  from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
  from ..models.political_exposure_dto import PoliticalExposureDto
  from ..models.risk_dto import RiskDto
  from ..models.sanctions_dto import SanctionsDto





T = TypeVar("T", bound="CreateIndividualClientDto")



@_attrs_define
class CreateIndividualClientDto:
    """ 
        Attributes:
            reference_id (str | Unset): External reference ID for the individual client Example: IND123.
            activity_status (CreateIndividualClientDtoActivityStatus | Unset): Current activity status of the individual
                client Example: ACTIVE.
            account_status (CreateIndividualClientDtoAccountStatus | Unset): Current account status of the individual client
                Example: APPROVED.
            tags (list[str] | Unset): Tags associated with the individual client (maximum 50) Example: ['high-value', 'vip-
                client'].
            controls (list[str] | Unset): Control measures applied to the individual client (maximum 50) Example:
                ['enhanced-due-diligence', 'quarterly-review'].
            declared_assets (list[str] | Unset): Array of asset symbols the client is expected to trade with (maximum 50)
                Example: ['BTC', 'ETH', 'USDT'].
            address (IndividualClientAddressDto | Unset):
            adverse_media (AdverseMediaDto | Unset):
            application (IndividualClientApplicationInformationDto | Unset):
            risk_history (list[RiskDto] | Unset): Risk history of the individual client
            contact (IndividualClientContactInformationDto | Unset):
            custom_fields (CreateIndividualClientDtoCustomFields | Unset): Custom fields data
            financial (IndividualClientFinancialInformationDto | Unset):
            general (IndividualClientGeneralInformationDto | Unset):
            political_exposure (PoliticalExposureDto | Unset):
            sanctions (SanctionsDto | Unset):
            work (IndividualClientWorkInformationDto | Unset):
            integrations (IndividualClientIntegrationsDto | Unset):
            partner_client_id (str | Unset): ID or referenceId of the partner corporate client Example:
                123e4567-e89b-12d3-a456-426614174000.
     """

    reference_id: str | Unset = UNSET
    activity_status: CreateIndividualClientDtoActivityStatus | Unset = UNSET
    account_status: CreateIndividualClientDtoAccountStatus | Unset = UNSET
    tags: list[str] | Unset = UNSET
    controls: list[str] | Unset = UNSET
    declared_assets: list[str] | Unset = UNSET
    address: IndividualClientAddressDto | Unset = UNSET
    adverse_media: AdverseMediaDto | Unset = UNSET
    application: IndividualClientApplicationInformationDto | Unset = UNSET
    risk_history: list[RiskDto] | Unset = UNSET
    contact: IndividualClientContactInformationDto | Unset = UNSET
    custom_fields: CreateIndividualClientDtoCustomFields | Unset = UNSET
    financial: IndividualClientFinancialInformationDto | Unset = UNSET
    general: IndividualClientGeneralInformationDto | Unset = UNSET
    political_exposure: PoliticalExposureDto | Unset = UNSET
    sanctions: SanctionsDto | Unset = UNSET
    work: IndividualClientWorkInformationDto | Unset = UNSET
    integrations: IndividualClientIntegrationsDto | Unset = UNSET
    partner_client_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.adverse_media_dto import AdverseMediaDto
        from ..models.create_individual_client_dto_custom_fields import CreateIndividualClientDtoCustomFields
        from ..models.individual_client_address_dto import IndividualClientAddressDto
        from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
        from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
        from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
        from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
        from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
        from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
        from ..models.political_exposure_dto import PoliticalExposureDto
        from ..models.risk_dto import RiskDto
        from ..models.sanctions_dto import SanctionsDto
        reference_id = self.reference_id

        activity_status: str | Unset = UNSET
        if not isinstance(self.activity_status, Unset):
            activity_status = self.activity_status.value


        account_status: str | Unset = UNSET
        if not isinstance(self.account_status, Unset):
            account_status = self.account_status.value


        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags



        controls: list[str] | Unset = UNSET
        if not isinstance(self.controls, Unset):
            controls = self.controls



        declared_assets: list[str] | Unset = UNSET
        if not isinstance(self.declared_assets, Unset):
            declared_assets = self.declared_assets



        address: dict[str, Any] | Unset = UNSET
        if not isinstance(self.address, Unset):
            address = self.address.to_dict()

        adverse_media: dict[str, Any] | Unset = UNSET
        if not isinstance(self.adverse_media, Unset):
            adverse_media = self.adverse_media.to_dict()

        application: dict[str, Any] | Unset = UNSET
        if not isinstance(self.application, Unset):
            application = self.application.to_dict()

        risk_history: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.risk_history, Unset):
            risk_history = []
            for risk_history_item_data in self.risk_history:
                risk_history_item = risk_history_item_data.to_dict()
                risk_history.append(risk_history_item)



        contact: dict[str, Any] | Unset = UNSET
        if not isinstance(self.contact, Unset):
            contact = self.contact.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        financial: dict[str, Any] | Unset = UNSET
        if not isinstance(self.financial, Unset):
            financial = self.financial.to_dict()

        general: dict[str, Any] | Unset = UNSET
        if not isinstance(self.general, Unset):
            general = self.general.to_dict()

        political_exposure: dict[str, Any] | Unset = UNSET
        if not isinstance(self.political_exposure, Unset):
            political_exposure = self.political_exposure.to_dict()

        sanctions: dict[str, Any] | Unset = UNSET
        if not isinstance(self.sanctions, Unset):
            sanctions = self.sanctions.to_dict()

        work: dict[str, Any] | Unset = UNSET
        if not isinstance(self.work, Unset):
            work = self.work.to_dict()

        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()

        partner_client_id = self.partner_client_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if activity_status is not UNSET:
            field_dict["activityStatus"] = activity_status
        if account_status is not UNSET:
            field_dict["accountStatus"] = account_status
        if tags is not UNSET:
            field_dict["tags"] = tags
        if controls is not UNSET:
            field_dict["controls"] = controls
        if declared_assets is not UNSET:
            field_dict["declaredAssets"] = declared_assets
        if address is not UNSET:
            field_dict["address"] = address
        if adverse_media is not UNSET:
            field_dict["adverseMedia"] = adverse_media
        if application is not UNSET:
            field_dict["application"] = application
        if risk_history is not UNSET:
            field_dict["riskHistory"] = risk_history
        if contact is not UNSET:
            field_dict["contact"] = contact
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if financial is not UNSET:
            field_dict["financial"] = financial
        if general is not UNSET:
            field_dict["general"] = general
        if political_exposure is not UNSET:
            field_dict["politicalExposure"] = political_exposure
        if sanctions is not UNSET:
            field_dict["sanctions"] = sanctions
        if work is not UNSET:
            field_dict["work"] = work
        if integrations is not UNSET:
            field_dict["integrations"] = integrations
        if partner_client_id is not UNSET:
            field_dict["partnerClientId"] = partner_client_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.adverse_media_dto import AdverseMediaDto
        from ..models.create_individual_client_dto_custom_fields import CreateIndividualClientDtoCustomFields
        from ..models.individual_client_address_dto import IndividualClientAddressDto
        from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
        from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
        from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
        from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
        from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
        from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
        from ..models.political_exposure_dto import PoliticalExposureDto
        from ..models.risk_dto import RiskDto
        from ..models.sanctions_dto import SanctionsDto
        d = dict(src_dict)
        reference_id = d.pop("referenceId", UNSET)

        _activity_status = d.pop("activityStatus", UNSET)
        activity_status: CreateIndividualClientDtoActivityStatus | Unset
        if isinstance(_activity_status,  Unset):
            activity_status = UNSET
        else:
            activity_status = CreateIndividualClientDtoActivityStatus(_activity_status)




        _account_status = d.pop("accountStatus", UNSET)
        account_status: CreateIndividualClientDtoAccountStatus | Unset
        if isinstance(_account_status,  Unset):
            account_status = UNSET
        else:
            account_status = CreateIndividualClientDtoAccountStatus(_account_status)




        tags = cast(list[str], d.pop("tags", UNSET))


        controls = cast(list[str], d.pop("controls", UNSET))


        declared_assets = cast(list[str], d.pop("declaredAssets", UNSET))


        _address = d.pop("address", UNSET)
        address: IndividualClientAddressDto | Unset
        if isinstance(_address,  Unset):
            address = UNSET
        else:
            address = IndividualClientAddressDto.from_dict(_address)




        _adverse_media = d.pop("adverseMedia", UNSET)
        adverse_media: AdverseMediaDto | Unset
        if isinstance(_adverse_media,  Unset):
            adverse_media = UNSET
        else:
            adverse_media = AdverseMediaDto.from_dict(_adverse_media)




        _application = d.pop("application", UNSET)
        application: IndividualClientApplicationInformationDto | Unset
        if isinstance(_application,  Unset):
            application = UNSET
        else:
            application = IndividualClientApplicationInformationDto.from_dict(_application)




        _risk_history = d.pop("riskHistory", UNSET)
        risk_history: list[RiskDto] | Unset = UNSET
        if _risk_history is not UNSET:
            risk_history = []
            for risk_history_item_data in _risk_history:
                risk_history_item = RiskDto.from_dict(risk_history_item_data)



                risk_history.append(risk_history_item)


        _contact = d.pop("contact", UNSET)
        contact: IndividualClientContactInformationDto | Unset
        if isinstance(_contact,  Unset):
            contact = UNSET
        else:
            contact = IndividualClientContactInformationDto.from_dict(_contact)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: CreateIndividualClientDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = CreateIndividualClientDtoCustomFields.from_dict(_custom_fields)




        _financial = d.pop("financial", UNSET)
        financial: IndividualClientFinancialInformationDto | Unset
        if isinstance(_financial,  Unset):
            financial = UNSET
        else:
            financial = IndividualClientFinancialInformationDto.from_dict(_financial)




        _general = d.pop("general", UNSET)
        general: IndividualClientGeneralInformationDto | Unset
        if isinstance(_general,  Unset):
            general = UNSET
        else:
            general = IndividualClientGeneralInformationDto.from_dict(_general)




        _political_exposure = d.pop("politicalExposure", UNSET)
        political_exposure: PoliticalExposureDto | Unset
        if isinstance(_political_exposure,  Unset):
            political_exposure = UNSET
        else:
            political_exposure = PoliticalExposureDto.from_dict(_political_exposure)




        _sanctions = d.pop("sanctions", UNSET)
        sanctions: SanctionsDto | Unset
        if isinstance(_sanctions,  Unset):
            sanctions = UNSET
        else:
            sanctions = SanctionsDto.from_dict(_sanctions)




        _work = d.pop("work", UNSET)
        work: IndividualClientWorkInformationDto | Unset
        if isinstance(_work,  Unset):
            work = UNSET
        else:
            work = IndividualClientWorkInformationDto.from_dict(_work)




        _integrations = d.pop("integrations", UNSET)
        integrations: IndividualClientIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = IndividualClientIntegrationsDto.from_dict(_integrations)




        partner_client_id = d.pop("partnerClientId", UNSET)

        create_individual_client_dto = cls(
            reference_id=reference_id,
            activity_status=activity_status,
            account_status=account_status,
            tags=tags,
            controls=controls,
            declared_assets=declared_assets,
            address=address,
            adverse_media=adverse_media,
            application=application,
            risk_history=risk_history,
            contact=contact,
            custom_fields=custom_fields,
            financial=financial,
            general=general,
            political_exposure=political_exposure,
            sanctions=sanctions,
            work=work,
            integrations=integrations,
            partner_client_id=partner_client_id,
        )


        create_individual_client_dto.additional_properties = d
        return create_individual_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
