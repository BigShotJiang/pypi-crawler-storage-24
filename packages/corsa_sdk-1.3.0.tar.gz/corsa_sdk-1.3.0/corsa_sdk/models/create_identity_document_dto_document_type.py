from enum import Enum

class CreateIdentityDocumentDtoDocumentType(str, Enum):
    BIRTH_CERTIFICATE = "BIRTH_CERTIFICATE"
    DRIVERS_LICENSE = "DRIVERS_LICENSE"
    NATIONAL_ID = "NATIONAL_ID"
    OTHER = "OTHER"
    PASSPORT = "PASSPORT"
    RESIDENCE_PERMIT = "RESIDENCE_PERMIT"

    def __str__(self) -> str:
        return str(self.value)
