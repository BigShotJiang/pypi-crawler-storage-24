from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="CorporateClientScreeningDto")



@_attrs_define
class CorporateClientScreeningDto:
    """ 
        Attributes:
            has_subpoena (bool | Unset): Whether the client has a subpoena
            has_sar (bool | Unset): Whether the client has a Suspicious Activity Report (SAR)
     """

    has_subpoena: bool | Unset = UNSET
    has_sar: bool | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        has_subpoena = self.has_subpoena

        has_sar = self.has_sar


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if has_subpoena is not UNSET:
            field_dict["hasSubpoena"] = has_subpoena
        if has_sar is not UNSET:
            field_dict["hasSAR"] = has_sar

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        has_subpoena = d.pop("hasSubpoena", UNSET)

        has_sar = d.pop("hasSAR", UNSET)

        corporate_client_screening_dto = cls(
            has_subpoena=has_subpoena,
            has_sar=has_sar,
        )


        corporate_client_screening_dto.additional_properties = d
        return corporate_client_screening_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
