from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_identity_document_dto_document_type import CreateIdentityDocumentDtoDocumentType
from ..types import UNSET, Unset






T = TypeVar("T", bound="CreateIdentityDocumentDto")



@_attrs_define
class CreateIdentityDocumentDto:
    """ 
        Attributes:
            document_type (CreateIdentityDocumentDtoDocumentType): Type of identity document
            document_number (str): Document number
            document_issuing_country (str | Unset): Country that issued the document (ISO 3166-1 alpha-3)
            document_expiration_date (str | Unset): Document expiration date
            document_image_url (str | Unset): URL to document image
            document_url_in_vendor (str | Unset): URL to document in vendor system
            document_image_file_id (str | Unset): ID of the uploaded document image file
     """

    document_type: CreateIdentityDocumentDtoDocumentType
    document_number: str
    document_issuing_country: str | Unset = UNSET
    document_expiration_date: str | Unset = UNSET
    document_image_url: str | Unset = UNSET
    document_url_in_vendor: str | Unset = UNSET
    document_image_file_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        document_type = self.document_type.value

        document_number = self.document_number

        document_issuing_country = self.document_issuing_country

        document_expiration_date = self.document_expiration_date

        document_image_url = self.document_image_url

        document_url_in_vendor = self.document_url_in_vendor

        document_image_file_id = self.document_image_file_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "documentType": document_type,
            "documentNumber": document_number,
        })
        if document_issuing_country is not UNSET:
            field_dict["documentIssuingCountry"] = document_issuing_country
        if document_expiration_date is not UNSET:
            field_dict["documentExpirationDate"] = document_expiration_date
        if document_image_url is not UNSET:
            field_dict["documentImageUrl"] = document_image_url
        if document_url_in_vendor is not UNSET:
            field_dict["documentUrlInVendor"] = document_url_in_vendor
        if document_image_file_id is not UNSET:
            field_dict["documentImageFileId"] = document_image_file_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        document_type = CreateIdentityDocumentDtoDocumentType(d.pop("documentType"))




        document_number = d.pop("documentNumber")

        document_issuing_country = d.pop("documentIssuingCountry", UNSET)

        document_expiration_date = d.pop("documentExpirationDate", UNSET)

        document_image_url = d.pop("documentImageUrl", UNSET)

        document_url_in_vendor = d.pop("documentUrlInVendor", UNSET)

        document_image_file_id = d.pop("documentImageFileId", UNSET)

        create_identity_document_dto = cls(
            document_type=document_type,
            document_number=document_number,
            document_issuing_country=document_issuing_country,
            document_expiration_date=document_expiration_date,
            document_image_url=document_image_url,
            document_url_in_vendor=document_url_in_vendor,
            document_image_file_id=document_image_file_id,
        )


        create_identity_document_dto.additional_properties = d
        return create_identity_document_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
