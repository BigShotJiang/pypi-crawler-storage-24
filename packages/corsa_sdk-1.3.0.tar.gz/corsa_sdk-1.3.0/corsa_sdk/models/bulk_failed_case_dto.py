from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="BulkFailedCaseDto")



@_attrs_define
class BulkFailedCaseDto:
    """ 
        Attributes:
            case_id (str): The case ID or reference ID that failed to process Example: 123e4567-e89b-12d3-a456-426614174000.
            error (str): The error message explaining why the operation failed Example: Case not found.
     """

    case_id: str
    error: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        case_id = self.case_id

        error = self.error


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "caseId": case_id,
            "error": error,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        case_id = d.pop("caseId")

        error = d.pop("error")

        bulk_failed_case_dto = cls(
            case_id=case_id,
            error=error,
        )


        bulk_failed_case_dto.additional_properties = d
        return bulk_failed_case_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
