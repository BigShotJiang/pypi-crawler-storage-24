from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.corporate_client_adverse_media_dto_adverse_media_risk_level import CorporateClientAdverseMediaDtoAdverseMediaRiskLevel
from ..types import UNSET, Unset






T = TypeVar("T", bound="CorporateClientAdverseMediaDto")



@_attrs_define
class CorporateClientAdverseMediaDto:
    """ 
        Attributes:
            adverse_media_risk_level (CorporateClientAdverseMediaDtoAdverseMediaRiskLevel | Unset): Adverse media risk level
                Example: LOW.
            adverse_media_score (float | Unset): Adverse media score (0, 2, 3, or 4) Example: 2.
            adverse_media_date (str | Unset): Date when the adverse media was identified Example: 2022-01-15T00:00:00Z.
            adverse_media_resolved (bool | Unset): Whether the adverse media issue is resolved Example: True.
            adverse_media_details (str | Unset): Details about the adverse media findings Example: Negative news coverage
                from 2022, now resolved.
            adverse_media_fines (float | Unset): Fines or penalties associated with adverse media Example: 50000.
     """

    adverse_media_risk_level: CorporateClientAdverseMediaDtoAdverseMediaRiskLevel | Unset = UNSET
    adverse_media_score: float | Unset = UNSET
    adverse_media_date: str | Unset = UNSET
    adverse_media_resolved: bool | Unset = UNSET
    adverse_media_details: str | Unset = UNSET
    adverse_media_fines: float | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        adverse_media_risk_level: str | Unset = UNSET
        if not isinstance(self.adverse_media_risk_level, Unset):
            adverse_media_risk_level = self.adverse_media_risk_level.value


        adverse_media_score = self.adverse_media_score

        adverse_media_date = self.adverse_media_date

        adverse_media_resolved = self.adverse_media_resolved

        adverse_media_details = self.adverse_media_details

        adverse_media_fines = self.adverse_media_fines


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if adverse_media_risk_level is not UNSET:
            field_dict["adverseMediaRiskLevel"] = adverse_media_risk_level
        if adverse_media_score is not UNSET:
            field_dict["adverseMediaScore"] = adverse_media_score
        if adverse_media_date is not UNSET:
            field_dict["adverseMediaDate"] = adverse_media_date
        if adverse_media_resolved is not UNSET:
            field_dict["adverseMediaResolved"] = adverse_media_resolved
        if adverse_media_details is not UNSET:
            field_dict["adverseMediaDetails"] = adverse_media_details
        if adverse_media_fines is not UNSET:
            field_dict["adverseMediaFines"] = adverse_media_fines

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _adverse_media_risk_level = d.pop("adverseMediaRiskLevel", UNSET)
        adverse_media_risk_level: CorporateClientAdverseMediaDtoAdverseMediaRiskLevel | Unset
        if isinstance(_adverse_media_risk_level,  Unset):
            adverse_media_risk_level = UNSET
        else:
            adverse_media_risk_level = CorporateClientAdverseMediaDtoAdverseMediaRiskLevel(_adverse_media_risk_level)




        adverse_media_score = d.pop("adverseMediaScore", UNSET)

        adverse_media_date = d.pop("adverseMediaDate", UNSET)

        adverse_media_resolved = d.pop("adverseMediaResolved", UNSET)

        adverse_media_details = d.pop("adverseMediaDetails", UNSET)

        adverse_media_fines = d.pop("adverseMediaFines", UNSET)

        corporate_client_adverse_media_dto = cls(
            adverse_media_risk_level=adverse_media_risk_level,
            adverse_media_score=adverse_media_score,
            adverse_media_date=adverse_media_date,
            adverse_media_resolved=adverse_media_resolved,
            adverse_media_details=adverse_media_details,
            adverse_media_fines=adverse_media_fines,
        )


        corporate_client_adverse_media_dto.additional_properties = d
        return corporate_client_adverse_media_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
