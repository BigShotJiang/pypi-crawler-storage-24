from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_case_dto_category import UpdateCaseDtoCategory
from ..models.update_case_dto_priority import UpdateCaseDtoPriority
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.update_case_investigation_dto import UpdateCaseInvestigationDto
  from ..models.update_case_status_dto import UpdateCaseStatusDto





T = TypeVar("T", bound="UpdateCaseDto")



@_attrs_define
class UpdateCaseDto:
    """ 
        Attributes:
            reference_id (str | Unset): External reference ID for the case Example: REF-2024-001234.
            attachment_ids (list[str] | Unset): ID of the user who created the case Example: user_12345.
            priority (UpdateCaseDtoPriority | Unset): Priority of the case Example: HIGH.
            category (UpdateCaseDtoCategory | Unset): Category of the case Example: KYC.
            sub_category (str | Unset): Subcategory of the case for more granular classification Example: Enhanced Due
                Diligence.
            reviewers_ids (list[str] | Unset): IDs of the reviewers of the case Example: ['user_12345', 'user_67890'].
            description (str | Unset): Description of the case Example: KYC review required for high-value client due to
                inconsistencies in provided documentation and elevated risk score..
            assignee_id (str | Unset): ID of the user who assigned the case Example: user_12345.
            alerts_ids (list[str] | Unset): IDs or Reference IDs of the alerts associated with the case Example:
                ['alert_12345', 'alert_67890'].
            transactions_ids (list[str] | Unset): IDs or Reference IDs of the transactions associated with the case Example:
                ['transaction_12345', 'transaction_67890'].
            clients_ids (list[str] | Unset): IDs or Reference IDs of the clients associated with the case Example:
                ['client_12345', 'client_67890'].
            status (UpdateCaseStatusDto | Unset):
            investigation (UpdateCaseInvestigationDto | Unset):
            due_date (str | Unset): ISO Date when the case is due Example: 2024-01-20T00:00:00.000Z.
     """

    reference_id: str | Unset = UNSET
    attachment_ids: list[str] | Unset = UNSET
    priority: UpdateCaseDtoPriority | Unset = UNSET
    category: UpdateCaseDtoCategory | Unset = UNSET
    sub_category: str | Unset = UNSET
    reviewers_ids: list[str] | Unset = UNSET
    description: str | Unset = UNSET
    assignee_id: str | Unset = UNSET
    alerts_ids: list[str] | Unset = UNSET
    transactions_ids: list[str] | Unset = UNSET
    clients_ids: list[str] | Unset = UNSET
    status: UpdateCaseStatusDto | Unset = UNSET
    investigation: UpdateCaseInvestigationDto | Unset = UNSET
    due_date: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.update_case_investigation_dto import UpdateCaseInvestigationDto
        from ..models.update_case_status_dto import UpdateCaseStatusDto
        reference_id = self.reference_id

        attachment_ids: list[str] | Unset = UNSET
        if not isinstance(self.attachment_ids, Unset):
            attachment_ids = self.attachment_ids



        priority: str | Unset = UNSET
        if not isinstance(self.priority, Unset):
            priority = self.priority.value


        category: str | Unset = UNSET
        if not isinstance(self.category, Unset):
            category = self.category.value


        sub_category = self.sub_category

        reviewers_ids: list[str] | Unset = UNSET
        if not isinstance(self.reviewers_ids, Unset):
            reviewers_ids = self.reviewers_ids



        description = self.description

        assignee_id = self.assignee_id

        alerts_ids: list[str] | Unset = UNSET
        if not isinstance(self.alerts_ids, Unset):
            alerts_ids = self.alerts_ids



        transactions_ids: list[str] | Unset = UNSET
        if not isinstance(self.transactions_ids, Unset):
            transactions_ids = self.transactions_ids



        clients_ids: list[str] | Unset = UNSET
        if not isinstance(self.clients_ids, Unset):
            clients_ids = self.clients_ids



        status: dict[str, Any] | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.to_dict()

        investigation: dict[str, Any] | Unset = UNSET
        if not isinstance(self.investigation, Unset):
            investigation = self.investigation.to_dict()

        due_date = self.due_date


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if attachment_ids is not UNSET:
            field_dict["attachmentIds"] = attachment_ids
        if priority is not UNSET:
            field_dict["priority"] = priority
        if category is not UNSET:
            field_dict["category"] = category
        if sub_category is not UNSET:
            field_dict["subCategory"] = sub_category
        if reviewers_ids is not UNSET:
            field_dict["reviewersIds"] = reviewers_ids
        if description is not UNSET:
            field_dict["description"] = description
        if assignee_id is not UNSET:
            field_dict["assigneeId"] = assignee_id
        if alerts_ids is not UNSET:
            field_dict["alertsIds"] = alerts_ids
        if transactions_ids is not UNSET:
            field_dict["transactionsIds"] = transactions_ids
        if clients_ids is not UNSET:
            field_dict["clientsIds"] = clients_ids
        if status is not UNSET:
            field_dict["status"] = status
        if investigation is not UNSET:
            field_dict["investigation"] = investigation
        if due_date is not UNSET:
            field_dict["dueDate"] = due_date

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_case_investigation_dto import UpdateCaseInvestigationDto
        from ..models.update_case_status_dto import UpdateCaseStatusDto
        d = dict(src_dict)
        reference_id = d.pop("referenceId", UNSET)

        attachment_ids = cast(list[str], d.pop("attachmentIds", UNSET))


        _priority = d.pop("priority", UNSET)
        priority: UpdateCaseDtoPriority | Unset
        if isinstance(_priority,  Unset):
            priority = UNSET
        else:
            priority = UpdateCaseDtoPriority(_priority)




        _category = d.pop("category", UNSET)
        category: UpdateCaseDtoCategory | Unset
        if isinstance(_category,  Unset):
            category = UNSET
        else:
            category = UpdateCaseDtoCategory(_category)




        sub_category = d.pop("subCategory", UNSET)

        reviewers_ids = cast(list[str], d.pop("reviewersIds", UNSET))


        description = d.pop("description", UNSET)

        assignee_id = d.pop("assigneeId", UNSET)

        alerts_ids = cast(list[str], d.pop("alertsIds", UNSET))


        transactions_ids = cast(list[str], d.pop("transactionsIds", UNSET))


        clients_ids = cast(list[str], d.pop("clientsIds", UNSET))


        _status = d.pop("status", UNSET)
        status: UpdateCaseStatusDto | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = UpdateCaseStatusDto.from_dict(_status)




        _investigation = d.pop("investigation", UNSET)
        investigation: UpdateCaseInvestigationDto | Unset
        if isinstance(_investigation,  Unset):
            investigation = UNSET
        else:
            investigation = UpdateCaseInvestigationDto.from_dict(_investigation)




        due_date = d.pop("dueDate", UNSET)

        update_case_dto = cls(
            reference_id=reference_id,
            attachment_ids=attachment_ids,
            priority=priority,
            category=category,
            sub_category=sub_category,
            reviewers_ids=reviewers_ids,
            description=description,
            assignee_id=assignee_id,
            alerts_ids=alerts_ids,
            transactions_ids=transactions_ids,
            clients_ids=clients_ids,
            status=status,
            investigation=investigation,
            due_date=due_date,
        )


        update_case_dto.additional_properties = d
        return update_case_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
