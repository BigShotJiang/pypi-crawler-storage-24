from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.operation_initiator_dto import OperationInitiatorDto
  from ..models.transaction_dto import TransactionDto





T = TypeVar("T", bound="DepositOperationDto")



@_attrs_define
class DepositOperationDto:
    """ 
        Attributes:
            id (str): Unique identifier of the deposit operation Example: 123e4567-e89b-12d3-a456-426614174000.
            created_at (str): ISO timestamp when the deposit operation was created or reported to the platform Example:
                2023-08-15T10:30:00Z.
            deposit_transaction (TransactionDto):
            initiated_at (str): ISO timestamp when the deposit operation was initiated Example: 2023-08-15T10:30:00Z.
            updated_at (str): ISO timestamp when the deposit operation was last updated Example: 2023-08-15T10:35:00Z.
            initiated_by (OperationInitiatorDto | Unset):
            reference_id (str | Unset): External reference ID for the deposit operation Example: DEP-2023-001.
     """

    id: str
    created_at: str
    deposit_transaction: TransactionDto
    initiated_at: str
    updated_at: str
    initiated_by: OperationInitiatorDto | Unset = UNSET
    reference_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.operation_initiator_dto import OperationInitiatorDto
        from ..models.transaction_dto import TransactionDto
        id = self.id

        created_at = self.created_at

        deposit_transaction = self.deposit_transaction.to_dict()

        initiated_at = self.initiated_at

        updated_at = self.updated_at

        initiated_by: dict[str, Any] | Unset = UNSET
        if not isinstance(self.initiated_by, Unset):
            initiated_by = self.initiated_by.to_dict()

        reference_id = self.reference_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "createdAt": created_at,
            "depositTransaction": deposit_transaction,
            "initiatedAt": initiated_at,
            "updatedAt": updated_at,
        })
        if initiated_by is not UNSET:
            field_dict["initiatedBy"] = initiated_by
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.operation_initiator_dto import OperationInitiatorDto
        from ..models.transaction_dto import TransactionDto
        d = dict(src_dict)
        id = d.pop("id")

        created_at = d.pop("createdAt")

        deposit_transaction = TransactionDto.from_dict(d.pop("depositTransaction"))




        initiated_at = d.pop("initiatedAt")

        updated_at = d.pop("updatedAt")

        _initiated_by = d.pop("initiatedBy", UNSET)
        initiated_by: OperationInitiatorDto | Unset
        if isinstance(_initiated_by,  Unset):
            initiated_by = UNSET
        else:
            initiated_by = OperationInitiatorDto.from_dict(_initiated_by)




        reference_id = d.pop("referenceId", UNSET)

        deposit_operation_dto = cls(
            id=id,
            created_at=created_at,
            deposit_transaction=deposit_transaction,
            initiated_at=initiated_at,
            updated_at=updated_at,
            initiated_by=initiated_by,
            reference_id=reference_id,
        )


        deposit_operation_dto.additional_properties = d
        return deposit_operation_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
