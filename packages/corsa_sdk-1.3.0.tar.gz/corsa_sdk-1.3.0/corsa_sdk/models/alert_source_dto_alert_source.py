from enum import Enum

class AlertSourceDtoAlertSource(str, Enum):
    API = "API"
    CHAINALYSIS = "CHAINALYSIS"
    MANUAL = "MANUAL"
    SARDINE = "SARDINE"
    SUMSUB = "SUMSUB"
    TRANSACTION_MONITORING = "TRANSACTION_MONITORING"
    TRM_LABS = "TRM_LABS"

    def __str__(self) -> str:
        return str(self.value)
