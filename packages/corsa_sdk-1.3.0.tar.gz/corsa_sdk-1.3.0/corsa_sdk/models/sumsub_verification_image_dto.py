from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="SumsubVerificationImageDto")



@_attrs_define
class SumsubVerificationImageDto:
    """ 
        Attributes:
            id (str): Sumsub verification image ID Example: img_123.
            status (str): Status of the verification image Example: approved.
            reject_labels (list[str] | Unset): Reject labels if the image was rejected Example: ['DOCUMENT_PAGE_MISSING',
                'FRONT_SIDE_MISSING'].
            reason (str | Unset): Reason for rejection if applicable Example: Document is expired.
            file_name (str | Unset): File name of the verification image Example: passport_front.jpg.
            file_id (str | Unset): File ID of the verification image Example: file_123456.
     """

    id: str
    status: str
    reject_labels: list[str] | Unset = UNSET
    reason: str | Unset = UNSET
    file_name: str | Unset = UNSET
    file_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        status = self.status

        reject_labels: list[str] | Unset = UNSET
        if not isinstance(self.reject_labels, Unset):
            reject_labels = self.reject_labels



        reason = self.reason

        file_name = self.file_name

        file_id = self.file_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "status": status,
        })
        if reject_labels is not UNSET:
            field_dict["rejectLabels"] = reject_labels
        if reason is not UNSET:
            field_dict["reason"] = reason
        if file_name is not UNSET:
            field_dict["fileName"] = file_name
        if file_id is not UNSET:
            field_dict["fileId"] = file_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        status = d.pop("status")

        reject_labels = cast(list[str], d.pop("rejectLabels", UNSET))


        reason = d.pop("reason", UNSET)

        file_name = d.pop("fileName", UNSET)

        file_id = d.pop("fileId", UNSET)

        sumsub_verification_image_dto = cls(
            id=id,
            status=status,
            reject_labels=reject_labels,
            reason=reason,
            file_name=file_name,
            file_id=file_id,
        )


        sumsub_verification_image_dto.additional_properties = d
        return sumsub_verification_image_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
