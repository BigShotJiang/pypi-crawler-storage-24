from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_checklist_template_dto_entity_type import CreateChecklistTemplateDtoEntityType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_checklist_template_item_dto import CreateChecklistTemplateItemDto





T = TypeVar("T", bound="CreateChecklistTemplateDto")



@_attrs_define
class CreateChecklistTemplateDto:
    """ 
        Attributes:
            entity_type (CreateChecklistTemplateDtoEntityType): The type of entity this template is for Example:
                INDIVIDUAL_CLIENT.
            name (str): The name of the template Example: KYC Compliance Template.
            description (str | Unset): Optional description of the template Example: Standard KYC compliance checklist for
                individual clients.
            is_active (bool | Unset): Whether the template is active Default: True. Example: True.
            items (list[CreateChecklistTemplateItemDto] | Unset): Initial items for the template
     """

    entity_type: CreateChecklistTemplateDtoEntityType
    name: str
    description: str | Unset = UNSET
    is_active: bool | Unset = True
    items: list[CreateChecklistTemplateItemDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_checklist_template_item_dto import CreateChecklistTemplateItemDto
        entity_type = self.entity_type.value

        name = self.name

        description = self.description

        is_active = self.is_active

        items: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.items, Unset):
            items = []
            for items_item_data in self.items:
                items_item = items_item_data.to_dict()
                items.append(items_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "entityType": entity_type,
            "name": name,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if is_active is not UNSET:
            field_dict["isActive"] = is_active
        if items is not UNSET:
            field_dict["items"] = items

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_checklist_template_item_dto import CreateChecklistTemplateItemDto
        d = dict(src_dict)
        entity_type = CreateChecklistTemplateDtoEntityType(d.pop("entityType"))




        name = d.pop("name")

        description = d.pop("description", UNSET)

        is_active = d.pop("isActive", UNSET)

        _items = d.pop("items", UNSET)
        items: list[CreateChecklistTemplateItemDto] | Unset = UNSET
        if _items is not UNSET:
            items = []
            for items_item_data in _items:
                items_item = CreateChecklistTemplateItemDto.from_dict(items_item_data)



                items.append(items_item)


        create_checklist_template_dto = cls(
            entity_type=entity_type,
            name=name,
            description=description,
            is_active=is_active,
            items=items,
        )


        create_checklist_template_dto.additional_properties = d
        return create_checklist_template_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
