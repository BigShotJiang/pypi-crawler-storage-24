from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="CorporateClientApplicationDto")



@_attrs_define
class CorporateClientApplicationDto:
    """ 
        Attributes:
            submitted_at (str | Unset): The date when the client application was submitted Example: 2023-01-01T00:00:00Z.
            onboarded_at (str | Unset): The date when the client was successfully onboarded Example: 2023-01-15T00:00:00Z.
            next_periodic_review (str | Unset): ISO Date of the next scheduled periodic review Example:
                2024-01-15T00:00:00Z.
     """

    submitted_at: str | Unset = UNSET
    onboarded_at: str | Unset = UNSET
    next_periodic_review: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        submitted_at = self.submitted_at

        onboarded_at = self.onboarded_at

        next_periodic_review = self.next_periodic_review


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if submitted_at is not UNSET:
            field_dict["submittedAt"] = submitted_at
        if onboarded_at is not UNSET:
            field_dict["onboardedAt"] = onboarded_at
        if next_periodic_review is not UNSET:
            field_dict["nextPeriodicReview"] = next_periodic_review

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        submitted_at = d.pop("submittedAt", UNSET)

        onboarded_at = d.pop("onboardedAt", UNSET)

        next_periodic_review = d.pop("nextPeriodicReview", UNSET)

        corporate_client_application_dto = cls(
            submitted_at=submitted_at,
            onboarded_at=onboarded_at,
            next_periodic_review=next_periodic_review,
        )


        corporate_client_application_dto.additional_properties = d
        return corporate_client_application_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
