from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.transaction_source_or_destination_client_dto import TransactionSourceOrDestinationClientDto
  from ..models.transaction_source_or_destination_wallet_dto import TransactionSourceOrDestinationWalletDto





T = TypeVar("T", bound="TransactionSourceOrDestinationDto")



@_attrs_define
class TransactionSourceOrDestinationDto:
    """ 
        Attributes:
            client (TransactionSourceOrDestinationClientDto | Unset):
            bank_account_number (str | Unset): The bank account number that the transaction was sent from or to - if the
                bank account doesn't exist in the database, it will be created and associated with the provided client if
                supplied Example: 1234567890.
            wallet_address (str | Unset): The blockchain wallet address that the transaction was sent from or to - if the
                blockchain wallet doesn't exist in the database, it will be created and associated with the provided client if
                supplied Example: 0x742d35Cc6634C0532925a3b844Bc454e4438f44e.
            wallet (TransactionSourceOrDestinationWalletDto | Unset):
     """

    client: TransactionSourceOrDestinationClientDto | Unset = UNSET
    bank_account_number: str | Unset = UNSET
    wallet_address: str | Unset = UNSET
    wallet: TransactionSourceOrDestinationWalletDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.transaction_source_or_destination_client_dto import TransactionSourceOrDestinationClientDto
        from ..models.transaction_source_or_destination_wallet_dto import TransactionSourceOrDestinationWalletDto
        client: dict[str, Any] | Unset = UNSET
        if not isinstance(self.client, Unset):
            client = self.client.to_dict()

        bank_account_number = self.bank_account_number

        wallet_address = self.wallet_address

        wallet: dict[str, Any] | Unset = UNSET
        if not isinstance(self.wallet, Unset):
            wallet = self.wallet.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if client is not UNSET:
            field_dict["client"] = client
        if bank_account_number is not UNSET:
            field_dict["bankAccountNumber"] = bank_account_number
        if wallet_address is not UNSET:
            field_dict["walletAddress"] = wallet_address
        if wallet is not UNSET:
            field_dict["wallet"] = wallet

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.transaction_source_or_destination_client_dto import TransactionSourceOrDestinationClientDto
        from ..models.transaction_source_or_destination_wallet_dto import TransactionSourceOrDestinationWalletDto
        d = dict(src_dict)
        _client = d.pop("client", UNSET)
        client: TransactionSourceOrDestinationClientDto | Unset
        if isinstance(_client,  Unset):
            client = UNSET
        else:
            client = TransactionSourceOrDestinationClientDto.from_dict(_client)




        bank_account_number = d.pop("bankAccountNumber", UNSET)

        wallet_address = d.pop("walletAddress", UNSET)

        _wallet = d.pop("wallet", UNSET)
        wallet: TransactionSourceOrDestinationWalletDto | Unset
        if isinstance(_wallet,  Unset):
            wallet = UNSET
        else:
            wallet = TransactionSourceOrDestinationWalletDto.from_dict(_wallet)




        transaction_source_or_destination_dto = cls(
            client=client,
            bank_account_number=bank_account_number,
            wallet_address=wallet_address,
            wallet=wallet,
        )


        transaction_source_or_destination_dto.additional_properties = d
        return transaction_source_or_destination_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
