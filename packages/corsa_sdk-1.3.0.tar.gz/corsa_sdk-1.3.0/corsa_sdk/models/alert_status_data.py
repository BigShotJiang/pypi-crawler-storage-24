from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.alert_status_data_status import AlertStatusDataStatus






T = TypeVar("T", bound="AlertStatusData")



@_attrs_define
class AlertStatusData:
    """ 
        Attributes:
            status (AlertStatusDataStatus): The status of the alert Example: OPEN.
            evaluated_at (str): ISO Date when the alert was evaluated Example: 2021-01-01T00:00:00.000Z.
            evaluated_by (str): The ID of the user who evaluated the alert Example: 123e4567-e89b-12d3-a456-426614174000.
     """

    status: AlertStatusDataStatus
    evaluated_at: str
    evaluated_by: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        status = self.status.value

        evaluated_at = self.evaluated_at

        evaluated_by = self.evaluated_by


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
            "evaluatedAt": evaluated_at,
            "evaluatedBy": evaluated_by,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        status = AlertStatusDataStatus(d.pop("status"))




        evaluated_at = d.pop("evaluatedAt")

        evaluated_by = d.pop("evaluatedBy")

        alert_status_data = cls(
            status=status,
            evaluated_at=evaluated_at,
            evaluated_by=evaluated_by,
        )


        alert_status_data.additional_properties = d
        return alert_status_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
