from enum import Enum

class UpdateIndividualClientDtoActivityStatus(str, Enum):
    ACTIVE = "ACTIVE"
    NOT_ACTIVE = "NOT_ACTIVE"

    def __str__(self) -> str:
        return str(self.value)
