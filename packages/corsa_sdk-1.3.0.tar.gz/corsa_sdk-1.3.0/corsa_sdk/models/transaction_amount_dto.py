from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="TransactionAmountDto")



@_attrs_define
class TransactionAmountDto:
    """ 
        Attributes:
            amount (float): Amount of the transaction Example: 1.5.
            currency (str): Currency - can be a crypto or fiat (if it's converted amount - should be a fiat - according to
                the platform's preferred currency) Example: USD.
            net_amount (float | Unset): Net amount after fees Example: 1.485.
     """

    amount: float
    currency: str
    net_amount: float | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        amount = self.amount

        currency = self.currency

        net_amount = self.net_amount


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "amount": amount,
            "currency": currency,
        })
        if net_amount is not UNSET:
            field_dict["netAmount"] = net_amount

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        amount = d.pop("amount")

        currency = d.pop("currency")

        net_amount = d.pop("netAmount", UNSET)

        transaction_amount_dto = cls(
            amount=amount,
            currency=currency,
            net_amount=net_amount,
        )


        transaction_amount_dto.additional_properties = d
        return transaction_amount_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
