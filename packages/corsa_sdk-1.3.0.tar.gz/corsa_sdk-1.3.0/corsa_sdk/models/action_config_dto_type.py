from enum import Enum

class ActionConfigDtoType(str, Enum):
    CREATE_ALERT = "CREATE_ALERT"
    HALT_TRANSACTION = "HALT_TRANSACTION"

    def __str__(self) -> str:
        return str(self.value)
