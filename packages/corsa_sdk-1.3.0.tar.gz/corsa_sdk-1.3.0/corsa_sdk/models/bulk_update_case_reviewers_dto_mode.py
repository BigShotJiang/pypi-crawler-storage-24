from enum import Enum

class BulkUpdateCaseReviewersDtoMode(str, Enum):
    ADD = "ADD"
    REMOVE = "REMOVE"
    SET = "SET"

    def __str__(self) -> str:
        return str(self.value)
