from enum import Enum

class GetIndividualClientIntegrationId(str, Enum):
    CHAINALYSIS = "CHAINALYSIS"
    PLAIN = "PLAIN"
    SARDINE = "SARDINE"
    SUMSUB = "SUMSUB"

    def __str__(self) -> str:
        return str(self.value)
