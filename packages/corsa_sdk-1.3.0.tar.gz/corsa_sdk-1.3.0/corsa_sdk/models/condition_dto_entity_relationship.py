from enum import Enum

class ConditionDtoEntityRelationship(str, Enum):
    ALL = "all"
    RECEIVER = "receiver"
    SENDER = "sender"

    def __str__(self) -> str:
        return str(self.value)
