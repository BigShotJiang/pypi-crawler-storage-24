from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_individual_client_dto_account_status import UpdateIndividualClientDtoAccountStatus
from ..models.update_individual_client_dto_activity_status import UpdateIndividualClientDtoActivityStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.adverse_media_dto import AdverseMediaDto
  from ..models.create_or_update_risk_dto import CreateOrUpdateRiskDto
  from ..models.individual_client_address_dto import IndividualClientAddressDto
  from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
  from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
  from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
  from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
  from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
  from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
  from ..models.political_exposure_dto import PoliticalExposureDto
  from ..models.sanctions_dto import SanctionsDto
  from ..models.update_individual_client_dto_custom_fields import UpdateIndividualClientDtoCustomFields





T = TypeVar("T", bound="UpdateIndividualClientDto")



@_attrs_define
class UpdateIndividualClientDto:
    """ 
        Attributes:
            general (IndividualClientGeneralInformationDto | Unset):
            address (IndividualClientAddressDto | Unset):
            contact (IndividualClientContactInformationDto | Unset):
            work (IndividualClientWorkInformationDto | Unset):
            financial (IndividualClientFinancialInformationDto | Unset):
            application (IndividualClientApplicationInformationDto | Unset):
            sanctions (SanctionsDto | Unset):
            political_exposure (PoliticalExposureDto | Unset):
            adverse_media (AdverseMediaDto | Unset):
            custom_fields (UpdateIndividualClientDtoCustomFields | Unset): Custom fields data
            tags_to_add (list[str] | Unset): Tags to add to the individual client (maximum 50)
            tags_to_remove (list[str] | Unset): Tags to remove from the individual client (maximum 50)
            declared_assets (list[str] | Unset): Array of asset symbols the client is expected to trade with (maximum 50).
                This will replace the existing declaredAssets. Example: ['BTC', 'ETH', 'USDT'].
            controls_to_add (list[str] | Unset): Controls to add to the individual client (maximum 50)
            controls_to_remove (list[str] | Unset): Controls to remove from the individual client (maximum 50)
            activity_status (UpdateIndividualClientDtoActivityStatus | Unset): Activity status of the individual client
            account_status (UpdateIndividualClientDtoAccountStatus | Unset): Account status of the individual client
            current_risk (CreateOrUpdateRiskDto | Unset):
            onboarding_risk (CreateOrUpdateRiskDto | Unset):
            integrations (IndividualClientIntegrationsDto | Unset):
            partner_client_id (None | str | Unset): ID or referenceId of the partner corporate client. Set to null to remove
                the partner. Example: 123e4567-e89b-12d3-a456-426614174000.
     """

    general: IndividualClientGeneralInformationDto | Unset = UNSET
    address: IndividualClientAddressDto | Unset = UNSET
    contact: IndividualClientContactInformationDto | Unset = UNSET
    work: IndividualClientWorkInformationDto | Unset = UNSET
    financial: IndividualClientFinancialInformationDto | Unset = UNSET
    application: IndividualClientApplicationInformationDto | Unset = UNSET
    sanctions: SanctionsDto | Unset = UNSET
    political_exposure: PoliticalExposureDto | Unset = UNSET
    adverse_media: AdverseMediaDto | Unset = UNSET
    custom_fields: UpdateIndividualClientDtoCustomFields | Unset = UNSET
    tags_to_add: list[str] | Unset = UNSET
    tags_to_remove: list[str] | Unset = UNSET
    declared_assets: list[str] | Unset = UNSET
    controls_to_add: list[str] | Unset = UNSET
    controls_to_remove: list[str] | Unset = UNSET
    activity_status: UpdateIndividualClientDtoActivityStatus | Unset = UNSET
    account_status: UpdateIndividualClientDtoAccountStatus | Unset = UNSET
    current_risk: CreateOrUpdateRiskDto | Unset = UNSET
    onboarding_risk: CreateOrUpdateRiskDto | Unset = UNSET
    integrations: IndividualClientIntegrationsDto | Unset = UNSET
    partner_client_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.adverse_media_dto import AdverseMediaDto
        from ..models.create_or_update_risk_dto import CreateOrUpdateRiskDto
        from ..models.individual_client_address_dto import IndividualClientAddressDto
        from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
        from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
        from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
        from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
        from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
        from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
        from ..models.political_exposure_dto import PoliticalExposureDto
        from ..models.sanctions_dto import SanctionsDto
        from ..models.update_individual_client_dto_custom_fields import UpdateIndividualClientDtoCustomFields
        general: dict[str, Any] | Unset = UNSET
        if not isinstance(self.general, Unset):
            general = self.general.to_dict()

        address: dict[str, Any] | Unset = UNSET
        if not isinstance(self.address, Unset):
            address = self.address.to_dict()

        contact: dict[str, Any] | Unset = UNSET
        if not isinstance(self.contact, Unset):
            contact = self.contact.to_dict()

        work: dict[str, Any] | Unset = UNSET
        if not isinstance(self.work, Unset):
            work = self.work.to_dict()

        financial: dict[str, Any] | Unset = UNSET
        if not isinstance(self.financial, Unset):
            financial = self.financial.to_dict()

        application: dict[str, Any] | Unset = UNSET
        if not isinstance(self.application, Unset):
            application = self.application.to_dict()

        sanctions: dict[str, Any] | Unset = UNSET
        if not isinstance(self.sanctions, Unset):
            sanctions = self.sanctions.to_dict()

        political_exposure: dict[str, Any] | Unset = UNSET
        if not isinstance(self.political_exposure, Unset):
            political_exposure = self.political_exposure.to_dict()

        adverse_media: dict[str, Any] | Unset = UNSET
        if not isinstance(self.adverse_media, Unset):
            adverse_media = self.adverse_media.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        tags_to_add: list[str] | Unset = UNSET
        if not isinstance(self.tags_to_add, Unset):
            tags_to_add = self.tags_to_add



        tags_to_remove: list[str] | Unset = UNSET
        if not isinstance(self.tags_to_remove, Unset):
            tags_to_remove = self.tags_to_remove



        declared_assets: list[str] | Unset = UNSET
        if not isinstance(self.declared_assets, Unset):
            declared_assets = self.declared_assets



        controls_to_add: list[str] | Unset = UNSET
        if not isinstance(self.controls_to_add, Unset):
            controls_to_add = self.controls_to_add



        controls_to_remove: list[str] | Unset = UNSET
        if not isinstance(self.controls_to_remove, Unset):
            controls_to_remove = self.controls_to_remove



        activity_status: str | Unset = UNSET
        if not isinstance(self.activity_status, Unset):
            activity_status = self.activity_status.value


        account_status: str | Unset = UNSET
        if not isinstance(self.account_status, Unset):
            account_status = self.account_status.value


        current_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.current_risk, Unset):
            current_risk = self.current_risk.to_dict()

        onboarding_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.onboarding_risk, Unset):
            onboarding_risk = self.onboarding_risk.to_dict()

        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()

        partner_client_id: None | str | Unset
        if isinstance(self.partner_client_id, Unset):
            partner_client_id = UNSET
        else:
            partner_client_id = self.partner_client_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if general is not UNSET:
            field_dict["general"] = general
        if address is not UNSET:
            field_dict["address"] = address
        if contact is not UNSET:
            field_dict["contact"] = contact
        if work is not UNSET:
            field_dict["work"] = work
        if financial is not UNSET:
            field_dict["financial"] = financial
        if application is not UNSET:
            field_dict["application"] = application
        if sanctions is not UNSET:
            field_dict["sanctions"] = sanctions
        if political_exposure is not UNSET:
            field_dict["politicalExposure"] = political_exposure
        if adverse_media is not UNSET:
            field_dict["adverseMedia"] = adverse_media
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if tags_to_add is not UNSET:
            field_dict["tagsToAdd"] = tags_to_add
        if tags_to_remove is not UNSET:
            field_dict["tagsToRemove"] = tags_to_remove
        if declared_assets is not UNSET:
            field_dict["declaredAssets"] = declared_assets
        if controls_to_add is not UNSET:
            field_dict["controlsToAdd"] = controls_to_add
        if controls_to_remove is not UNSET:
            field_dict["controlsToRemove"] = controls_to_remove
        if activity_status is not UNSET:
            field_dict["activityStatus"] = activity_status
        if account_status is not UNSET:
            field_dict["accountStatus"] = account_status
        if current_risk is not UNSET:
            field_dict["currentRisk"] = current_risk
        if onboarding_risk is not UNSET:
            field_dict["onboardingRisk"] = onboarding_risk
        if integrations is not UNSET:
            field_dict["integrations"] = integrations
        if partner_client_id is not UNSET:
            field_dict["partnerClientId"] = partner_client_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.adverse_media_dto import AdverseMediaDto
        from ..models.create_or_update_risk_dto import CreateOrUpdateRiskDto
        from ..models.individual_client_address_dto import IndividualClientAddressDto
        from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
        from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
        from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
        from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
        from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
        from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
        from ..models.political_exposure_dto import PoliticalExposureDto
        from ..models.sanctions_dto import SanctionsDto
        from ..models.update_individual_client_dto_custom_fields import UpdateIndividualClientDtoCustomFields
        d = dict(src_dict)
        _general = d.pop("general", UNSET)
        general: IndividualClientGeneralInformationDto | Unset
        if isinstance(_general,  Unset):
            general = UNSET
        else:
            general = IndividualClientGeneralInformationDto.from_dict(_general)




        _address = d.pop("address", UNSET)
        address: IndividualClientAddressDto | Unset
        if isinstance(_address,  Unset):
            address = UNSET
        else:
            address = IndividualClientAddressDto.from_dict(_address)




        _contact = d.pop("contact", UNSET)
        contact: IndividualClientContactInformationDto | Unset
        if isinstance(_contact,  Unset):
            contact = UNSET
        else:
            contact = IndividualClientContactInformationDto.from_dict(_contact)




        _work = d.pop("work", UNSET)
        work: IndividualClientWorkInformationDto | Unset
        if isinstance(_work,  Unset):
            work = UNSET
        else:
            work = IndividualClientWorkInformationDto.from_dict(_work)




        _financial = d.pop("financial", UNSET)
        financial: IndividualClientFinancialInformationDto | Unset
        if isinstance(_financial,  Unset):
            financial = UNSET
        else:
            financial = IndividualClientFinancialInformationDto.from_dict(_financial)




        _application = d.pop("application", UNSET)
        application: IndividualClientApplicationInformationDto | Unset
        if isinstance(_application,  Unset):
            application = UNSET
        else:
            application = IndividualClientApplicationInformationDto.from_dict(_application)




        _sanctions = d.pop("sanctions", UNSET)
        sanctions: SanctionsDto | Unset
        if isinstance(_sanctions,  Unset):
            sanctions = UNSET
        else:
            sanctions = SanctionsDto.from_dict(_sanctions)




        _political_exposure = d.pop("politicalExposure", UNSET)
        political_exposure: PoliticalExposureDto | Unset
        if isinstance(_political_exposure,  Unset):
            political_exposure = UNSET
        else:
            political_exposure = PoliticalExposureDto.from_dict(_political_exposure)




        _adverse_media = d.pop("adverseMedia", UNSET)
        adverse_media: AdverseMediaDto | Unset
        if isinstance(_adverse_media,  Unset):
            adverse_media = UNSET
        else:
            adverse_media = AdverseMediaDto.from_dict(_adverse_media)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: UpdateIndividualClientDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = UpdateIndividualClientDtoCustomFields.from_dict(_custom_fields)




        tags_to_add = cast(list[str], d.pop("tagsToAdd", UNSET))


        tags_to_remove = cast(list[str], d.pop("tagsToRemove", UNSET))


        declared_assets = cast(list[str], d.pop("declaredAssets", UNSET))


        controls_to_add = cast(list[str], d.pop("controlsToAdd", UNSET))


        controls_to_remove = cast(list[str], d.pop("controlsToRemove", UNSET))


        _activity_status = d.pop("activityStatus", UNSET)
        activity_status: UpdateIndividualClientDtoActivityStatus | Unset
        if isinstance(_activity_status,  Unset):
            activity_status = UNSET
        else:
            activity_status = UpdateIndividualClientDtoActivityStatus(_activity_status)




        _account_status = d.pop("accountStatus", UNSET)
        account_status: UpdateIndividualClientDtoAccountStatus | Unset
        if isinstance(_account_status,  Unset):
            account_status = UNSET
        else:
            account_status = UpdateIndividualClientDtoAccountStatus(_account_status)




        _current_risk = d.pop("currentRisk", UNSET)
        current_risk: CreateOrUpdateRiskDto | Unset
        if isinstance(_current_risk,  Unset):
            current_risk = UNSET
        else:
            current_risk = CreateOrUpdateRiskDto.from_dict(_current_risk)




        _onboarding_risk = d.pop("onboardingRisk", UNSET)
        onboarding_risk: CreateOrUpdateRiskDto | Unset
        if isinstance(_onboarding_risk,  Unset):
            onboarding_risk = UNSET
        else:
            onboarding_risk = CreateOrUpdateRiskDto.from_dict(_onboarding_risk)




        _integrations = d.pop("integrations", UNSET)
        integrations: IndividualClientIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = IndividualClientIntegrationsDto.from_dict(_integrations)




        def _parse_partner_client_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        partner_client_id = _parse_partner_client_id(d.pop("partnerClientId", UNSET))


        update_individual_client_dto = cls(
            general=general,
            address=address,
            contact=contact,
            work=work,
            financial=financial,
            application=application,
            sanctions=sanctions,
            political_exposure=political_exposure,
            adverse_media=adverse_media,
            custom_fields=custom_fields,
            tags_to_add=tags_to_add,
            tags_to_remove=tags_to_remove,
            declared_assets=declared_assets,
            controls_to_add=controls_to_add,
            controls_to_remove=controls_to_remove,
            activity_status=activity_status,
            account_status=account_status,
            current_risk=current_risk,
            onboarding_risk=onboarding_risk,
            integrations=integrations,
            partner_client_id=partner_client_id,
        )


        update_individual_client_dto.additional_properties = d
        return update_individual_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
