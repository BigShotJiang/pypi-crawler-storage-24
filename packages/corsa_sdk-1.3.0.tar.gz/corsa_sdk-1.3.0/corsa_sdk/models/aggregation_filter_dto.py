from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.aggregation_filter_dto_operator import AggregationFilterDtoOperator
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.aggregation_filter_dto_value import AggregationFilterDtoValue





T = TypeVar("T", bound="AggregationFilterDto")



@_attrs_define
class AggregationFilterDto:
    """ 
        Attributes:
            property_ (str | Unset):
            operator (AggregationFilterDtoOperator | Unset): Comparison operator for the aggregation filter
            value (AggregationFilterDtoValue | Unset):
     """

    property_: str | Unset = UNSET
    operator: AggregationFilterDtoOperator | Unset = UNSET
    value: AggregationFilterDtoValue | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.aggregation_filter_dto_value import AggregationFilterDtoValue
        property_ = self.property_

        operator: str | Unset = UNSET
        if not isinstance(self.operator, Unset):
            operator = self.operator.value


        value: dict[str, Any] | Unset = UNSET
        if not isinstance(self.value, Unset):
            value = self.value.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if property_ is not UNSET:
            field_dict["property"] = property_
        if operator is not UNSET:
            field_dict["operator"] = operator
        if value is not UNSET:
            field_dict["value"] = value

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.aggregation_filter_dto_value import AggregationFilterDtoValue
        d = dict(src_dict)
        property_ = d.pop("property", UNSET)

        _operator = d.pop("operator", UNSET)
        operator: AggregationFilterDtoOperator | Unset
        if isinstance(_operator,  Unset):
            operator = UNSET
        else:
            operator = AggregationFilterDtoOperator(_operator)




        _value = d.pop("value", UNSET)
        value: AggregationFilterDtoValue | Unset
        if isinstance(_value,  Unset):
            value = UNSET
        else:
            value = AggregationFilterDtoValue.from_dict(_value)




        aggregation_filter_dto = cls(
            property_=property_,
            operator=operator,
            value=value,
        )


        aggregation_filter_dto.additional_properties = d
        return aggregation_filter_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
