from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="CreateExternalDocumentResponseDto")



@_attrs_define
class CreateExternalDocumentResponseDto:
    """ 
        Attributes:
            attachment_id (str): The ID of the created attachment Example: att_123e4567-e89b-12d3-a456-426614174000.
            message (str): Success message Example: External document created successfully.
     """

    attachment_id: str
    message: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        attachment_id = self.attachment_id

        message = self.message


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "attachmentId": attachment_id,
            "message": message,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        attachment_id = d.pop("attachmentId")

        message = d.pop("message")

        create_external_document_response_dto = cls(
            attachment_id=attachment_id,
            message=message,
        )


        create_external_document_response_dto.additional_properties = d
        return create_external_document_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
