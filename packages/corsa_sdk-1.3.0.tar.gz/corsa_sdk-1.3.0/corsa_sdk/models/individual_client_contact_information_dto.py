from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="IndividualClientContactInformationDto")



@_attrs_define
class IndividualClientContactInformationDto:
    """ 
        Attributes:
            email_address (str | Unset): Email address of the client Example: john.doe@example.com.
            phone_number (str | Unset): Phone number of the client
     """

    email_address: str | Unset = UNSET
    phone_number: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        email_address = self.email_address

        phone_number = self.phone_number


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if email_address is not UNSET:
            field_dict["emailAddress"] = email_address
        if phone_number is not UNSET:
            field_dict["phoneNumber"] = phone_number

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email_address = d.pop("emailAddress", UNSET)

        phone_number = d.pop("phoneNumber", UNSET)

        individual_client_contact_information_dto = cls(
            email_address=email_address,
            phone_number=phone_number,
        )


        individual_client_contact_information_dto.additional_properties = d
        return individual_client_contact_information_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
