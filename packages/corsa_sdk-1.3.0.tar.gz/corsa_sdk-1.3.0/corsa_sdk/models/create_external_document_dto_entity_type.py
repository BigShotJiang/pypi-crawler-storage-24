from enum import Enum

class CreateExternalDocumentDtoEntityType(str, Enum):
    ALERT = "alert"
    CASE = "case"
    CHECKLIST_ITEM = "checklist_item"
    CLIENT = "client"
    COMMENT = "comment"
    REPORT = "report"
    TRANSACTION = "transaction"

    def __str__(self) -> str:
        return str(self.value)
