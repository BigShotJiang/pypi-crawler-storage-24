from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.condition_dto import ConditionDto





T = TypeVar("T", bound="ConditionsDto")



@_attrs_define
class ConditionsDto:
    """ 
        Attributes:
            all_ (list[ConditionDto] | Unset): ALL conditions (AND logic) - all must be true Example: [{'entity': 'client',
                'property': 'riskTier', 'operator': 'equal', 'value': 'HIGH'}, {'entity': 'transaction', 'aggregationProperty':
                'amount', 'aggregationOperator': 'sum', 'aggregationTimeType': 'in_the_last', 'aggregationTimeValue': 1,
                'aggregationTimePeriod': 'days', 'operator': 'greaterThanInclusive', 'value': 50000}].
            any_ (list[ConditionDto] | Unset): ANY conditions (OR logic) - at least one must be true Example: [{'entity':
                'transaction', 'property': 'type', 'operator': 'equal', 'value': 'WITHDRAW'}, {'entity': 'transaction',
                'property': 'type', 'operator': 'equal', 'value': 'TRANSFER'}].
     """

    all_: list[ConditionDto] | Unset = UNSET
    any_: list[ConditionDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.condition_dto import ConditionDto
        all_: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.all_, Unset):
            all_ = []
            for all_item_data in self.all_:
                all_item = all_item_data.to_dict()
                all_.append(all_item)



        any_: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.any_, Unset):
            any_ = []
            for any_item_data in self.any_:
                any_item = any_item_data.to_dict()
                any_.append(any_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if all_ is not UNSET:
            field_dict["all"] = all_
        if any_ is not UNSET:
            field_dict["any"] = any_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.condition_dto import ConditionDto
        d = dict(src_dict)
        _all_ = d.pop("all", UNSET)
        all_: list[ConditionDto] | Unset = UNSET
        if _all_ is not UNSET:
            all_ = []
            for all_item_data in _all_:
                all_item = ConditionDto.from_dict(all_item_data)



                all_.append(all_item)


        _any_ = d.pop("any", UNSET)
        any_: list[ConditionDto] | Unset = UNSET
        if _any_ is not UNSET:
            any_ = []
            for any_item_data in _any_:
                any_item = ConditionDto.from_dict(any_item_data)



                any_.append(any_item)


        conditions_dto = cls(
            all_=all_,
            any_=any_,
        )


        conditions_dto.additional_properties = d
        return conditions_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
