from enum import Enum

class OperationStatusUpdateDtoStatus(str, Enum):
    EXPIRED = "EXPIRED"
    FAILED = "FAILED"
    PENDING = "PENDING"
    REJECTED = "REJECTED"
    SUCCESS = "SUCCESS"

    def __str__(self) -> str:
        return str(self.value)
