from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="CorporateClientAddressLineDto")



@_attrs_define
class CorporateClientAddressLineDto:
    """ 
        Attributes:
            country (str | Unset): Country code of the address Example: USA.
            city (str | Unset): City name Example: London.
            postal_code (str | Unset): Postal code Example: SW1A 1AA.
            address_line_1 (str | Unset): First line of the address Example: 123 Main Street.
            address_line_2 (str | Unset): Second line of the address (optional) Example: Westminster.
     """

    country: str | Unset = UNSET
    city: str | Unset = UNSET
    postal_code: str | Unset = UNSET
    address_line_1: str | Unset = UNSET
    address_line_2: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        country = self.country

        city = self.city

        postal_code = self.postal_code

        address_line_1 = self.address_line_1

        address_line_2 = self.address_line_2


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if country is not UNSET:
            field_dict["country"] = country
        if city is not UNSET:
            field_dict["city"] = city
        if postal_code is not UNSET:
            field_dict["postalCode"] = postal_code
        if address_line_1 is not UNSET:
            field_dict["addressLine1"] = address_line_1
        if address_line_2 is not UNSET:
            field_dict["addressLine2"] = address_line_2

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        country = d.pop("country", UNSET)

        city = d.pop("city", UNSET)

        postal_code = d.pop("postalCode", UNSET)

        address_line_1 = d.pop("addressLine1", UNSET)

        address_line_2 = d.pop("addressLine2", UNSET)

        corporate_client_address_line_dto = cls(
            country=country,
            city=city,
            postal_code=postal_code,
            address_line_1=address_line_1,
            address_line_2=address_line_2,
        )


        corporate_client_address_line_dto.additional_properties = d
        return corporate_client_address_line_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
