from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_transaction_dto_transfer_type import CreateTransactionDtoTransferType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_transaction_dto_custom_fields import CreateTransactionDtoCustomFields
  from ..models.create_transaction_source_or_destination_client_dto import CreateTransactionSourceOrDestinationClientDto
  from ..models.transaction_amount_dto import TransactionAmountDto
  from ..models.transaction_integrations_dto import TransactionIntegrationsDto
  from ..models.transaction_status_dto import TransactionStatusDto





T = TypeVar("T", bound="CreateTransactionDto")



@_attrs_define
class CreateTransactionDto:
    """ 
        Attributes:
            amount (TransactionAmountDto):
            reference_id (str | Unset): External reference ID for the transaction Example: TX-2023-001.
            initiated_at (str | Unset): Date and time of the transaction Example: 2023-01-01T00:00:00Z.
            tx_hash (str | Unset): Blockchain transaction hash Example: 0x742d35Cc6634C0532925a3b844Bc454e4438f44e.
            status_history (list[TransactionStatusDto] | Unset): History of transaction statuses
            converted_amount (TransactionAmountDto | Unset):
            from_ (CreateTransactionSourceOrDestinationClientDto | Unset):
            to (CreateTransactionSourceOrDestinationClientDto | Unset):
            blockchain_network_id (str | Unset): Identifier of the blockchain network Example: ethereum-mainnet.
            payment_method (str | Unset): Method used for payment Example: CRYPTO_TRANSFER.
            payment_rail (str | Unset): Payment network or settlement rail used for the transaction. Predefined values:
                SWIFT, SEPA, Fedwire, ACH, NIP, PIX, MobileMoney, SPEI. Custom values are also accepted. Example: SWIFT.
            transfer_type (CreateTransactionDtoTransferType | Unset): Categorization of the transfer nature Example:
                INTERNATIONAL.
            custom_fields (CreateTransactionDtoCustomFields | Unset): Custom fields data
            integrations (TransactionIntegrationsDto | Unset):
     """

    amount: TransactionAmountDto
    reference_id: str | Unset = UNSET
    initiated_at: str | Unset = UNSET
    tx_hash: str | Unset = UNSET
    status_history: list[TransactionStatusDto] | Unset = UNSET
    converted_amount: TransactionAmountDto | Unset = UNSET
    from_: CreateTransactionSourceOrDestinationClientDto | Unset = UNSET
    to: CreateTransactionSourceOrDestinationClientDto | Unset = UNSET
    blockchain_network_id: str | Unset = UNSET
    payment_method: str | Unset = UNSET
    payment_rail: str | Unset = UNSET
    transfer_type: CreateTransactionDtoTransferType | Unset = UNSET
    custom_fields: CreateTransactionDtoCustomFields | Unset = UNSET
    integrations: TransactionIntegrationsDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_transaction_dto_custom_fields import CreateTransactionDtoCustomFields
        from ..models.create_transaction_source_or_destination_client_dto import CreateTransactionSourceOrDestinationClientDto
        from ..models.transaction_amount_dto import TransactionAmountDto
        from ..models.transaction_integrations_dto import TransactionIntegrationsDto
        from ..models.transaction_status_dto import TransactionStatusDto
        amount = self.amount.to_dict()

        reference_id = self.reference_id

        initiated_at = self.initiated_at

        tx_hash = self.tx_hash

        status_history: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.status_history, Unset):
            status_history = []
            for status_history_item_data in self.status_history:
                status_history_item = status_history_item_data.to_dict()
                status_history.append(status_history_item)



        converted_amount: dict[str, Any] | Unset = UNSET
        if not isinstance(self.converted_amount, Unset):
            converted_amount = self.converted_amount.to_dict()

        from_: dict[str, Any] | Unset = UNSET
        if not isinstance(self.from_, Unset):
            from_ = self.from_.to_dict()

        to: dict[str, Any] | Unset = UNSET
        if not isinstance(self.to, Unset):
            to = self.to.to_dict()

        blockchain_network_id = self.blockchain_network_id

        payment_method = self.payment_method

        payment_rail = self.payment_rail

        transfer_type: str | Unset = UNSET
        if not isinstance(self.transfer_type, Unset):
            transfer_type = self.transfer_type.value


        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "amount": amount,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if initiated_at is not UNSET:
            field_dict["initiatedAt"] = initiated_at
        if tx_hash is not UNSET:
            field_dict["txHash"] = tx_hash
        if status_history is not UNSET:
            field_dict["statusHistory"] = status_history
        if converted_amount is not UNSET:
            field_dict["convertedAmount"] = converted_amount
        if from_ is not UNSET:
            field_dict["from"] = from_
        if to is not UNSET:
            field_dict["to"] = to
        if blockchain_network_id is not UNSET:
            field_dict["blockchainNetworkId"] = blockchain_network_id
        if payment_method is not UNSET:
            field_dict["paymentMethod"] = payment_method
        if payment_rail is not UNSET:
            field_dict["paymentRail"] = payment_rail
        if transfer_type is not UNSET:
            field_dict["transferType"] = transfer_type
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if integrations is not UNSET:
            field_dict["integrations"] = integrations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_transaction_dto_custom_fields import CreateTransactionDtoCustomFields
        from ..models.create_transaction_source_or_destination_client_dto import CreateTransactionSourceOrDestinationClientDto
        from ..models.transaction_amount_dto import TransactionAmountDto
        from ..models.transaction_integrations_dto import TransactionIntegrationsDto
        from ..models.transaction_status_dto import TransactionStatusDto
        d = dict(src_dict)
        amount = TransactionAmountDto.from_dict(d.pop("amount"))




        reference_id = d.pop("referenceId", UNSET)

        initiated_at = d.pop("initiatedAt", UNSET)

        tx_hash = d.pop("txHash", UNSET)

        _status_history = d.pop("statusHistory", UNSET)
        status_history: list[TransactionStatusDto] | Unset = UNSET
        if _status_history is not UNSET:
            status_history = []
            for status_history_item_data in _status_history:
                status_history_item = TransactionStatusDto.from_dict(status_history_item_data)



                status_history.append(status_history_item)


        _converted_amount = d.pop("convertedAmount", UNSET)
        converted_amount: TransactionAmountDto | Unset
        if isinstance(_converted_amount,  Unset):
            converted_amount = UNSET
        else:
            converted_amount = TransactionAmountDto.from_dict(_converted_amount)




        _from_ = d.pop("from", UNSET)
        from_: CreateTransactionSourceOrDestinationClientDto | Unset
        if isinstance(_from_,  Unset):
            from_ = UNSET
        else:
            from_ = CreateTransactionSourceOrDestinationClientDto.from_dict(_from_)




        _to = d.pop("to", UNSET)
        to: CreateTransactionSourceOrDestinationClientDto | Unset
        if isinstance(_to,  Unset):
            to = UNSET
        else:
            to = CreateTransactionSourceOrDestinationClientDto.from_dict(_to)




        blockchain_network_id = d.pop("blockchainNetworkId", UNSET)

        payment_method = d.pop("paymentMethod", UNSET)

        payment_rail = d.pop("paymentRail", UNSET)

        _transfer_type = d.pop("transferType", UNSET)
        transfer_type: CreateTransactionDtoTransferType | Unset
        if isinstance(_transfer_type,  Unset):
            transfer_type = UNSET
        else:
            transfer_type = CreateTransactionDtoTransferType(_transfer_type)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: CreateTransactionDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = CreateTransactionDtoCustomFields.from_dict(_custom_fields)




        _integrations = d.pop("integrations", UNSET)
        integrations: TransactionIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = TransactionIntegrationsDto.from_dict(_integrations)




        create_transaction_dto = cls(
            amount=amount,
            reference_id=reference_id,
            initiated_at=initiated_at,
            tx_hash=tx_hash,
            status_history=status_history,
            converted_amount=converted_amount,
            from_=from_,
            to=to,
            blockchain_network_id=blockchain_network_id,
            payment_method=payment_method,
            payment_rail=payment_rail,
            transfer_type=transfer_type,
            custom_fields=custom_fields,
            integrations=integrations,
        )


        create_transaction_dto.additional_properties = d
        return create_transaction_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
