from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="BulkAssignAlertDto")



@_attrs_define
class BulkAssignAlertDto:
    """ 
        Attributes:
            alert_ids (list[str]): Array of alert IDs or reference IDs (maximum 100) Example:
                ['123e4567-e89b-12d3-a456-426614174000', 'ALT-REF-001'].
            assignee_id (None | str | Unset): The user ID to assign the alerts to. If null or omitted, unassigns the alerts.
                Example: 123e4567-e89b-12d3-a456-426614174000.
     """

    alert_ids: list[str]
    assignee_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        alert_ids = self.alert_ids



        assignee_id: None | str | Unset
        if isinstance(self.assignee_id, Unset):
            assignee_id = UNSET
        else:
            assignee_id = self.assignee_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "alertIds": alert_ids,
        })
        if assignee_id is not UNSET:
            field_dict["assigneeId"] = assignee_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        alert_ids = cast(list[str], d.pop("alertIds"))


        def _parse_assignee_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        assignee_id = _parse_assignee_id(d.pop("assigneeId", UNSET))


        bulk_assign_alert_dto = cls(
            alert_ids=alert_ids,
            assignee_id=assignee_id,
        )


        bulk_assign_alert_dto.additional_properties = d
        return bulk_assign_alert_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
