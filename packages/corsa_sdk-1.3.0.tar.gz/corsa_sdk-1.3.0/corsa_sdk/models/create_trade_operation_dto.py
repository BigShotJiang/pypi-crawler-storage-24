from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_trade_operation_dto_status import CreateTradeOperationDtoStatus
from ..models.create_trade_operation_dto_trade_type import CreateTradeOperationDtoTradeType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.create_transaction_dto import CreateTransactionDto
  from ..models.session_reference_dto import SessionReferenceDto





T = TypeVar("T", bound="CreateTradeOperationDto")



@_attrs_define
class CreateTradeOperationDto:
    """ 
        Attributes:
            transactions (list[CreateTransactionDto]): Transactions for the trade
            trade_type (CreateTradeOperationDtoTradeType): Type of the trade Example: BUY.
            price (float): Price of the trade Example: 100.
            quantity (float): Quantity of the trade Example: 100.
            instrument_base_asset (str): Base asset of the trade Example: BTC.
            instrument_quote_asset (str): Quote asset of the trade Example: USD.
            initiated_by (str | Unset): string of the client who initiated this trade Example:
                123e4567-e89b-12d3-a456-426614174000.
            initiated_at (str | Unset): Date and time of the trade operation. Defaults to current date and time if not
                provided Example: 2023-01-01T00:00:00Z.
            reference_id (str | Unset): External reference ID for the trade operation Example: TRADE-2023-001.
            status (CreateTradeOperationDtoStatus | Unset): Status of the trade Example: PENDING.
            session (SessionReferenceDto | Unset):
     """

    transactions: list[CreateTransactionDto]
    trade_type: CreateTradeOperationDtoTradeType
    price: float
    quantity: float
    instrument_base_asset: str
    instrument_quote_asset: str
    initiated_by: str | Unset = UNSET
    initiated_at: str | Unset = UNSET
    reference_id: str | Unset = UNSET
    status: CreateTradeOperationDtoStatus | Unset = UNSET
    session: SessionReferenceDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.create_transaction_dto import CreateTransactionDto
        from ..models.session_reference_dto import SessionReferenceDto
        transactions = []
        for transactions_item_data in self.transactions:
            transactions_item = transactions_item_data.to_dict()
            transactions.append(transactions_item)



        trade_type = self.trade_type.value

        price = self.price

        quantity = self.quantity

        instrument_base_asset = self.instrument_base_asset

        instrument_quote_asset = self.instrument_quote_asset

        initiated_by = self.initiated_by

        initiated_at = self.initiated_at

        reference_id = self.reference_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        session: dict[str, Any] | Unset = UNSET
        if not isinstance(self.session, Unset):
            session = self.session.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "transactions": transactions,
            "tradeType": trade_type,
            "price": price,
            "quantity": quantity,
            "instrumentBaseAsset": instrument_base_asset,
            "instrumentQuoteAsset": instrument_quote_asset,
        })
        if initiated_by is not UNSET:
            field_dict["initiatedBy"] = initiated_by
        if initiated_at is not UNSET:
            field_dict["initiatedAt"] = initiated_at
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if status is not UNSET:
            field_dict["status"] = status
        if session is not UNSET:
            field_dict["session"] = session

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.create_transaction_dto import CreateTransactionDto
        from ..models.session_reference_dto import SessionReferenceDto
        d = dict(src_dict)
        transactions = []
        _transactions = d.pop("transactions")
        for transactions_item_data in (_transactions):
            transactions_item = CreateTransactionDto.from_dict(transactions_item_data)



            transactions.append(transactions_item)


        trade_type = CreateTradeOperationDtoTradeType(d.pop("tradeType"))




        price = d.pop("price")

        quantity = d.pop("quantity")

        instrument_base_asset = d.pop("instrumentBaseAsset")

        instrument_quote_asset = d.pop("instrumentQuoteAsset")

        initiated_by = d.pop("initiatedBy", UNSET)

        initiated_at = d.pop("initiatedAt", UNSET)

        reference_id = d.pop("referenceId", UNSET)

        _status = d.pop("status", UNSET)
        status: CreateTradeOperationDtoStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = CreateTradeOperationDtoStatus(_status)




        _session = d.pop("session", UNSET)
        session: SessionReferenceDto | Unset
        if isinstance(_session,  Unset):
            session = UNSET
        else:
            session = SessionReferenceDto.from_dict(_session)




        create_trade_operation_dto = cls(
            transactions=transactions,
            trade_type=trade_type,
            price=price,
            quantity=quantity,
            instrument_base_asset=instrument_base_asset,
            instrument_quote_asset=instrument_quote_asset,
            initiated_by=initiated_by,
            initiated_at=initiated_at,
            reference_id=reference_id,
            status=status,
            session=session,
        )


        create_trade_operation_dto.additional_properties = d
        return create_trade_operation_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
