from enum import Enum

class CorporateClientBusinessDtoOwnershipType(str, Enum):
    PRIVATELY_HELD = "PRIVATELY_HELD"
    PUBLICLY_TRADED = "PUBLICLY_TRADED"

    def __str__(self) -> str:
        return str(self.value)
