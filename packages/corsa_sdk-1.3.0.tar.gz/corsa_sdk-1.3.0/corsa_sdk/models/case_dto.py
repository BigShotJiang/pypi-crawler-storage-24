from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.case_dto_category import CaseDtoCategory
from ..models.case_dto_priority import CaseDtoPriority
from ..models.case_dto_status import CaseDtoStatus
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.associated_alert_dto import AssociatedAlertDto
  from ..models.associated_client_dto import AssociatedClientDto
  from ..models.associated_transaction_dto import AssociatedTransactionDto
  from ..models.case_investigation_data import CaseInvestigationData
  from ..models.case_status_data import CaseStatusData





T = TypeVar("T", bound="CaseDto")



@_attrs_define
class CaseDto:
    """ 
        Attributes:
            id (str): Unique identifier for the case Example: case_abc123def456.
            created_at (datetime.datetime): Timestamp when the case was created Example: 2024-01-10T09:15:00.000Z.
            updated_at (datetime.datetime): Timestamp when the case was last updated Example: 2024-01-15T16:45:30.000Z.
            priority (CaseDtoPriority): Priority level of the case Example: HIGH.
            category (CaseDtoCategory): Category or type of the case Example: KYC.
            reviewers_ids (list[str]): Array of reviewer user IDs Example: ['reviewer_111', 'reviewer_222',
                'supervisor_333'].
            status (CaseDtoStatus): Current status of the case Example: UNDER_INVESTIGATION.
            status_history (list[CaseStatusData]): Historical record of case status changes Example: [{'status': 'NEW',
                'reason': 'Case created from alert', 'evaluatedAt': '2024-01-10T09:15:00.000Z', 'evaluatedBy': 'system_auto'},
                {'status': 'UNDER_INVESTIGATION', 'reason': 'Assigned to analyst for review', 'evaluatedAt':
                '2024-01-10T10:30:00.000Z', 'evaluatedBy': 'supervisor_123'}].
            alerts (list[AssociatedAlertDto]): Alerts associated with this case Example: [{'id': 'alert_xyz789',
                'referenceId': 'ALT-2024-001', 'createdAt': '2024-01-10T08:00:00.000Z'}].
            transactions (list[AssociatedTransactionDto]): Transactions associated with this case Example: [{'id':
                'txn_abc123', 'referenceId': 'TXN-2024-5678', 'amount': 50000, 'currency': 'USD'}].
            clients (list[AssociatedClientDto]): Clients associated with this case Example: [{'id': 'client_def456',
                'referenceId': 'CLI-2024-9012', 'name': 'John Doe', 'type': 'INDIVIDUAL'}].
            reference_id (str | Unset): External reference ID for the case Example: REF-2024-001234.
            attachment_ids (list[str] | Unset): Array of attachment IDs associated with the case Example: ['att_file1234',
                'att_file5678', 'att_file9012'].
            sub_category (str | Unset): Subcategory of the case for more granular classification Example: Document
                Verification.
            assignee_id (str | Unset): ID of the user assigned to the case Example: analyst_12345.
            description (str | Unset): Description or summary of the case Example: KYC review required for high-value client
                due to inconsistencies in provided documentation and elevated risk score..
            investigation (CaseInvestigationData | Unset):
            due_date (str | Unset): ISO Date when the case is due Example: 2024-01-20T00:00:00.000Z.
     """

    id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    priority: CaseDtoPriority
    category: CaseDtoCategory
    reviewers_ids: list[str]
    status: CaseDtoStatus
    status_history: list[CaseStatusData]
    alerts: list[AssociatedAlertDto]
    transactions: list[AssociatedTransactionDto]
    clients: list[AssociatedClientDto]
    reference_id: str | Unset = UNSET
    attachment_ids: list[str] | Unset = UNSET
    sub_category: str | Unset = UNSET
    assignee_id: str | Unset = UNSET
    description: str | Unset = UNSET
    investigation: CaseInvestigationData | Unset = UNSET
    due_date: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.associated_alert_dto import AssociatedAlertDto
        from ..models.associated_client_dto import AssociatedClientDto
        from ..models.associated_transaction_dto import AssociatedTransactionDto
        from ..models.case_investigation_data import CaseInvestigationData
        from ..models.case_status_data import CaseStatusData
        id = self.id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        priority = self.priority.value

        category = self.category.value

        reviewers_ids = self.reviewers_ids



        status = self.status.value

        status_history = []
        for status_history_item_data in self.status_history:
            status_history_item = status_history_item_data.to_dict()
            status_history.append(status_history_item)



        alerts = []
        for alerts_item_data in self.alerts:
            alerts_item = alerts_item_data.to_dict()
            alerts.append(alerts_item)



        transactions = []
        for transactions_item_data in self.transactions:
            transactions_item = transactions_item_data.to_dict()
            transactions.append(transactions_item)



        clients = []
        for clients_item_data in self.clients:
            clients_item = clients_item_data.to_dict()
            clients.append(clients_item)



        reference_id = self.reference_id

        attachment_ids: list[str] | Unset = UNSET
        if not isinstance(self.attachment_ids, Unset):
            attachment_ids = self.attachment_ids



        sub_category = self.sub_category

        assignee_id = self.assignee_id

        description = self.description

        investigation: dict[str, Any] | Unset = UNSET
        if not isinstance(self.investigation, Unset):
            investigation = self.investigation.to_dict()

        due_date = self.due_date


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "createdAt": created_at,
            "updatedAt": updated_at,
            "priority": priority,
            "category": category,
            "reviewersIds": reviewers_ids,
            "status": status,
            "statusHistory": status_history,
            "alerts": alerts,
            "transactions": transactions,
            "clients": clients,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if attachment_ids is not UNSET:
            field_dict["attachmentIds"] = attachment_ids
        if sub_category is not UNSET:
            field_dict["subCategory"] = sub_category
        if assignee_id is not UNSET:
            field_dict["assigneeId"] = assignee_id
        if description is not UNSET:
            field_dict["description"] = description
        if investigation is not UNSET:
            field_dict["investigation"] = investigation
        if due_date is not UNSET:
            field_dict["dueDate"] = due_date

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.associated_alert_dto import AssociatedAlertDto
        from ..models.associated_client_dto import AssociatedClientDto
        from ..models.associated_transaction_dto import AssociatedTransactionDto
        from ..models.case_investigation_data import CaseInvestigationData
        from ..models.case_status_data import CaseStatusData
        d = dict(src_dict)
        id = d.pop("id")

        created_at = isoparse(d.pop("createdAt"))




        updated_at = isoparse(d.pop("updatedAt"))




        priority = CaseDtoPriority(d.pop("priority"))




        category = CaseDtoCategory(d.pop("category"))




        reviewers_ids = cast(list[str], d.pop("reviewersIds"))


        status = CaseDtoStatus(d.pop("status"))




        status_history = []
        _status_history = d.pop("statusHistory")
        for status_history_item_data in (_status_history):
            status_history_item = CaseStatusData.from_dict(status_history_item_data)



            status_history.append(status_history_item)


        alerts = []
        _alerts = d.pop("alerts")
        for alerts_item_data in (_alerts):
            alerts_item = AssociatedAlertDto.from_dict(alerts_item_data)



            alerts.append(alerts_item)


        transactions = []
        _transactions = d.pop("transactions")
        for transactions_item_data in (_transactions):
            transactions_item = AssociatedTransactionDto.from_dict(transactions_item_data)



            transactions.append(transactions_item)


        clients = []
        _clients = d.pop("clients")
        for clients_item_data in (_clients):
            clients_item = AssociatedClientDto.from_dict(clients_item_data)



            clients.append(clients_item)


        reference_id = d.pop("referenceId", UNSET)

        attachment_ids = cast(list[str], d.pop("attachmentIds", UNSET))


        sub_category = d.pop("subCategory", UNSET)

        assignee_id = d.pop("assigneeId", UNSET)

        description = d.pop("description", UNSET)

        _investigation = d.pop("investigation", UNSET)
        investigation: CaseInvestigationData | Unset
        if isinstance(_investigation,  Unset):
            investigation = UNSET
        else:
            investigation = CaseInvestigationData.from_dict(_investigation)




        due_date = d.pop("dueDate", UNSET)

        case_dto = cls(
            id=id,
            created_at=created_at,
            updated_at=updated_at,
            priority=priority,
            category=category,
            reviewers_ids=reviewers_ids,
            status=status,
            status_history=status_history,
            alerts=alerts,
            transactions=transactions,
            clients=clients,
            reference_id=reference_id,
            attachment_ids=attachment_ids,
            sub_category=sub_category,
            assignee_id=assignee_id,
            description=description,
            investigation=investigation,
            due_date=due_date,
        )


        case_dto.additional_properties = d
        return case_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
