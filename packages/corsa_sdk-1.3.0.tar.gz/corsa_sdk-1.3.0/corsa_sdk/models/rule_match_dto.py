from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rule_match_dto_decision import RuleMatchDtoDecision
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.condition_result_dto import ConditionResultDto
  from ..models.rule_match_dto_actions_item import RuleMatchDtoActionsItem
  from ..models.rule_match_dto_explain import RuleMatchDtoExplain





T = TypeVar("T", bound="RuleMatchDto")



@_attrs_define
class RuleMatchDto:
    """ 
        Attributes:
            id (str):
            version (float):
            rule_name (str):
            decision (RuleMatchDtoDecision): Rule decision: FREEZE if rule has HALT_TRANSACTION action, otherwise ALLOW
            actions (list[RuleMatchDtoActionsItem]):
            explain (RuleMatchDtoExplain): All facts used in evaluation
            condition_results (list[ConditionResultDto] | Unset): Detailed information about which conditions triggered the
                rule
     """

    id: str
    version: float
    rule_name: str
    decision: RuleMatchDtoDecision
    actions: list[RuleMatchDtoActionsItem]
    explain: RuleMatchDtoExplain
    condition_results: list[ConditionResultDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.condition_result_dto import ConditionResultDto
        from ..models.rule_match_dto_actions_item import RuleMatchDtoActionsItem
        from ..models.rule_match_dto_explain import RuleMatchDtoExplain
        id = self.id

        version = self.version

        rule_name = self.rule_name

        decision = self.decision.value

        actions = []
        for actions_item_data in self.actions:
            actions_item = actions_item_data.to_dict()
            actions.append(actions_item)



        explain = self.explain.to_dict()

        condition_results: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.condition_results, Unset):
            condition_results = []
            for condition_results_item_data in self.condition_results:
                condition_results_item = condition_results_item_data.to_dict()
                condition_results.append(condition_results_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "version": version,
            "ruleName": rule_name,
            "decision": decision,
            "actions": actions,
            "explain": explain,
        })
        if condition_results is not UNSET:
            field_dict["conditionResults"] = condition_results

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.condition_result_dto import ConditionResultDto
        from ..models.rule_match_dto_actions_item import RuleMatchDtoActionsItem
        from ..models.rule_match_dto_explain import RuleMatchDtoExplain
        d = dict(src_dict)
        id = d.pop("id")

        version = d.pop("version")

        rule_name = d.pop("ruleName")

        decision = RuleMatchDtoDecision(d.pop("decision"))




        actions = []
        _actions = d.pop("actions")
        for actions_item_data in (_actions):
            actions_item = RuleMatchDtoActionsItem.from_dict(actions_item_data)



            actions.append(actions_item)


        explain = RuleMatchDtoExplain.from_dict(d.pop("explain"))




        _condition_results = d.pop("conditionResults", UNSET)
        condition_results: list[ConditionResultDto] | Unset = UNSET
        if _condition_results is not UNSET:
            condition_results = []
            for condition_results_item_data in _condition_results:
                condition_results_item = ConditionResultDto.from_dict(condition_results_item_data)



                condition_results.append(condition_results_item)


        rule_match_dto = cls(
            id=id,
            version=version,
            rule_name=rule_name,
            decision=decision,
            actions=actions,
            explain=explain,
            condition_results=condition_results,
        )


        rule_match_dto.additional_properties = d
        return rule_match_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
