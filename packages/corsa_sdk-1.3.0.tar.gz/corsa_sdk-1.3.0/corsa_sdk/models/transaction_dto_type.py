from enum import Enum

class TransactionDtoType(str, Enum):
    DEPOSIT = "DEPOSIT"
    TRADE = "TRADE"
    WITHDRAW = "WITHDRAW"

    def __str__(self) -> str:
        return str(self.value)
