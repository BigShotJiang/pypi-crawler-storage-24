from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.update_checklist_item_dto_category import UpdateChecklistItemDtoCategory
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.update_checklist_item_dto_custom_fields import UpdateChecklistItemDtoCustomFields
  from ..models.update_checklist_item_dto_status_options_item import UpdateChecklistItemDtoStatusOptionsItem





T = TypeVar("T", bound="UpdateChecklistItemDto")



@_attrs_define
class UpdateChecklistItemDto:
    """ 
        Attributes:
            name (str | Unset): Name of the checklist item Example: Passport Copy.
            note (str | Unset): Note/description of the checklist item Example: Please provide a clear copy of your
                passport.
            category (UpdateChecklistItemDtoCategory | Unset): Category of the checklist item Example:
                PERSONAL_IDENTIFICATION.
            status (str | Unset): The status of the checklist item (can be default or custom status) Example: APPROVED.
            document_url (str | Unset): URL to the attached document Example: https://example.com/document.pdf.
            attachment_id (str | Unset): Attachment ID from the attachment service Example: attachment-123-uuid.
            document_mime_type (str | Unset): MIME type of the attached document Example: application/pdf.
            document_submission_date (datetime.datetime | Unset): Date when the document was submitted Example:
                2024-01-15T10:30:00Z.
            expiration_date (datetime.datetime | Unset): Expiration date for the checklist item Example:
                2024-12-31T23:59:59Z.
            custom_fields (UpdateChecklistItemDtoCustomFields | Unset): Additional custom fields for the checklist item
                Example: {'priority': {'label': 'Priority Level', 'value': 'high', 'description': 'Urgency level of this item',
                'category': 'workflow', 'possibleValues': ['low', 'medium', 'high', 'critical'], 'immutable': False}, 'tags':
                {'label': 'Tags', 'value': ['urgent', 'review'], 'description': 'Classification tags', 'category':
                'organization', 'immutable': False}}.
            is_archived (bool | Unset): Whether this item is archived
            status_options (list[UpdateChecklistItemDtoStatusOptionsItem] | Unset): Custom status options for this item
                Example: [{'name': 'PENDING', 'color': 'yellow'}, {'name': 'COMPLETED', 'color': 'green'}, {'name': 'REJECTED',
                'color': 'red'}].
     """

    name: str | Unset = UNSET
    note: str | Unset = UNSET
    category: UpdateChecklistItemDtoCategory | Unset = UNSET
    status: str | Unset = UNSET
    document_url: str | Unset = UNSET
    attachment_id: str | Unset = UNSET
    document_mime_type: str | Unset = UNSET
    document_submission_date: datetime.datetime | Unset = UNSET
    expiration_date: datetime.datetime | Unset = UNSET
    custom_fields: UpdateChecklistItemDtoCustomFields | Unset = UNSET
    is_archived: bool | Unset = UNSET
    status_options: list[UpdateChecklistItemDtoStatusOptionsItem] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.update_checklist_item_dto_custom_fields import UpdateChecklistItemDtoCustomFields
        from ..models.update_checklist_item_dto_status_options_item import UpdateChecklistItemDtoStatusOptionsItem
        name = self.name

        note = self.note

        category: str | Unset = UNSET
        if not isinstance(self.category, Unset):
            category = self.category.value


        status = self.status

        document_url = self.document_url

        attachment_id = self.attachment_id

        document_mime_type = self.document_mime_type

        document_submission_date: str | Unset = UNSET
        if not isinstance(self.document_submission_date, Unset):
            document_submission_date = self.document_submission_date.isoformat()

        expiration_date: str | Unset = UNSET
        if not isinstance(self.expiration_date, Unset):
            expiration_date = self.expiration_date.isoformat()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        is_archived = self.is_archived

        status_options: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.status_options, Unset):
            status_options = []
            for status_options_item_data in self.status_options:
                status_options_item = status_options_item_data.to_dict()
                status_options.append(status_options_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if note is not UNSET:
            field_dict["note"] = note
        if category is not UNSET:
            field_dict["category"] = category
        if status is not UNSET:
            field_dict["status"] = status
        if document_url is not UNSET:
            field_dict["documentUrl"] = document_url
        if attachment_id is not UNSET:
            field_dict["attachmentId"] = attachment_id
        if document_mime_type is not UNSET:
            field_dict["documentMimeType"] = document_mime_type
        if document_submission_date is not UNSET:
            field_dict["documentSubmissionDate"] = document_submission_date
        if expiration_date is not UNSET:
            field_dict["expirationDate"] = expiration_date
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if is_archived is not UNSET:
            field_dict["isArchived"] = is_archived
        if status_options is not UNSET:
            field_dict["statusOptions"] = status_options

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.update_checklist_item_dto_custom_fields import UpdateChecklistItemDtoCustomFields
        from ..models.update_checklist_item_dto_status_options_item import UpdateChecklistItemDtoStatusOptionsItem
        d = dict(src_dict)
        name = d.pop("name", UNSET)

        note = d.pop("note", UNSET)

        _category = d.pop("category", UNSET)
        category: UpdateChecklistItemDtoCategory | Unset
        if isinstance(_category,  Unset):
            category = UNSET
        else:
            category = UpdateChecklistItemDtoCategory(_category)




        status = d.pop("status", UNSET)

        document_url = d.pop("documentUrl", UNSET)

        attachment_id = d.pop("attachmentId", UNSET)

        document_mime_type = d.pop("documentMimeType", UNSET)

        _document_submission_date = d.pop("documentSubmissionDate", UNSET)
        document_submission_date: datetime.datetime | Unset
        if isinstance(_document_submission_date,  Unset):
            document_submission_date = UNSET
        else:
            document_submission_date = isoparse(_document_submission_date)




        _expiration_date = d.pop("expirationDate", UNSET)
        expiration_date: datetime.datetime | Unset
        if isinstance(_expiration_date,  Unset):
            expiration_date = UNSET
        else:
            expiration_date = isoparse(_expiration_date)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: UpdateChecklistItemDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = UpdateChecklistItemDtoCustomFields.from_dict(_custom_fields)




        is_archived = d.pop("isArchived", UNSET)

        _status_options = d.pop("statusOptions", UNSET)
        status_options: list[UpdateChecklistItemDtoStatusOptionsItem] | Unset = UNSET
        if _status_options is not UNSET:
            status_options = []
            for status_options_item_data in _status_options:
                status_options_item = UpdateChecklistItemDtoStatusOptionsItem.from_dict(status_options_item_data)



                status_options.append(status_options_item)


        update_checklist_item_dto = cls(
            name=name,
            note=note,
            category=category,
            status=status,
            document_url=document_url,
            attachment_id=attachment_id,
            document_mime_type=document_mime_type,
            document_submission_date=document_submission_date,
            expiration_date=expiration_date,
            custom_fields=custom_fields,
            is_archived=is_archived,
            status_options=status_options,
        )


        update_checklist_item_dto.additional_properties = d
        return update_checklist_item_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
