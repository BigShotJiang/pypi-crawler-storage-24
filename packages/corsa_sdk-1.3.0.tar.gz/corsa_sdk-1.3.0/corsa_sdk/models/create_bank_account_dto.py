from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.create_bank_account_dto_status import CreateBankAccountDtoStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.client_bank_account_relation_dto import ClientBankAccountRelationDto
  from ..models.create_bank_account_dto_custom_fields import CreateBankAccountDtoCustomFields
  from ..models.risk_dto import RiskDto





T = TypeVar("T", bound="CreateBankAccountDto")



@_attrs_define
class CreateBankAccountDto:
    """ 
        Attributes:
            account_number (str): Unique National Bank Account Number Example: 1234567890.
            reference_id (str | Unset): External reference ID for the bank account Example: REF-BA-001.
            status (CreateBankAccountDtoStatus | Unset): Status of the bank account Example: ACTIVE.
            bank_name (str | Unset): Name of the bank Example: Chase Bank.
            routing_number (str | Unset): Bank routing number Example: 021000021.
            account_holder_name (str | Unset): Name of the account holder Example: John Doe.
            account_type (str | Unset): Type of bank account Example: checking.
            currency (str | Unset): Currency of the bank account (ISO 4217 currency code) Example: USD.
            balance_in_currency (float | Unset): Balance in the currency of the bank account Example: 1000.5.
            balance_in_converted_amount (float | Unset): Balance in the converted amount (i.e USD), using preferred currency
                of the platform Example: 1000.5.
            countries (list[str] | Unset): Country codes associated with the bank account (ISO 3166-1 alpha-3, maximum 20)
                Example: ['USA'].
            risk_history (list[RiskDto] | Unset): Historical risk assessments of the bank account
            custom_fields (CreateBankAccountDtoCustomFields | Unset): Custom fields data
            associated_clients (list[ClientBankAccountRelationDto] | Unset): List of clients associated with the bank
                account (maximum 50)
     """

    account_number: str
    reference_id: str | Unset = UNSET
    status: CreateBankAccountDtoStatus | Unset = UNSET
    bank_name: str | Unset = UNSET
    routing_number: str | Unset = UNSET
    account_holder_name: str | Unset = UNSET
    account_type: str | Unset = UNSET
    currency: str | Unset = UNSET
    balance_in_currency: float | Unset = UNSET
    balance_in_converted_amount: float | Unset = UNSET
    countries: list[str] | Unset = UNSET
    risk_history: list[RiskDto] | Unset = UNSET
    custom_fields: CreateBankAccountDtoCustomFields | Unset = UNSET
    associated_clients: list[ClientBankAccountRelationDto] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.client_bank_account_relation_dto import ClientBankAccountRelationDto
        from ..models.create_bank_account_dto_custom_fields import CreateBankAccountDtoCustomFields
        from ..models.risk_dto import RiskDto
        account_number = self.account_number

        reference_id = self.reference_id

        status: str | Unset = UNSET
        if not isinstance(self.status, Unset):
            status = self.status.value


        bank_name = self.bank_name

        routing_number = self.routing_number

        account_holder_name = self.account_holder_name

        account_type = self.account_type

        currency = self.currency

        balance_in_currency = self.balance_in_currency

        balance_in_converted_amount = self.balance_in_converted_amount

        countries: list[str] | Unset = UNSET
        if not isinstance(self.countries, Unset):
            countries = self.countries



        risk_history: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.risk_history, Unset):
            risk_history = []
            for risk_history_item_data in self.risk_history:
                risk_history_item = risk_history_item_data.to_dict()
                risk_history.append(risk_history_item)



        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        associated_clients: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.associated_clients, Unset):
            associated_clients = []
            for associated_clients_item_data in self.associated_clients:
                associated_clients_item = associated_clients_item_data.to_dict()
                associated_clients.append(associated_clients_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "accountNumber": account_number,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if status is not UNSET:
            field_dict["status"] = status
        if bank_name is not UNSET:
            field_dict["bankName"] = bank_name
        if routing_number is not UNSET:
            field_dict["routingNumber"] = routing_number
        if account_holder_name is not UNSET:
            field_dict["accountHolderName"] = account_holder_name
        if account_type is not UNSET:
            field_dict["accountType"] = account_type
        if currency is not UNSET:
            field_dict["currency"] = currency
        if balance_in_currency is not UNSET:
            field_dict["balanceInCurrency"] = balance_in_currency
        if balance_in_converted_amount is not UNSET:
            field_dict["balanceInConvertedAmount"] = balance_in_converted_amount
        if countries is not UNSET:
            field_dict["countries"] = countries
        if risk_history is not UNSET:
            field_dict["riskHistory"] = risk_history
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if associated_clients is not UNSET:
            field_dict["associatedClients"] = associated_clients

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.client_bank_account_relation_dto import ClientBankAccountRelationDto
        from ..models.create_bank_account_dto_custom_fields import CreateBankAccountDtoCustomFields
        from ..models.risk_dto import RiskDto
        d = dict(src_dict)
        account_number = d.pop("accountNumber")

        reference_id = d.pop("referenceId", UNSET)

        _status = d.pop("status", UNSET)
        status: CreateBankAccountDtoStatus | Unset
        if isinstance(_status,  Unset):
            status = UNSET
        else:
            status = CreateBankAccountDtoStatus(_status)




        bank_name = d.pop("bankName", UNSET)

        routing_number = d.pop("routingNumber", UNSET)

        account_holder_name = d.pop("accountHolderName", UNSET)

        account_type = d.pop("accountType", UNSET)

        currency = d.pop("currency", UNSET)

        balance_in_currency = d.pop("balanceInCurrency", UNSET)

        balance_in_converted_amount = d.pop("balanceInConvertedAmount", UNSET)

        countries = cast(list[str], d.pop("countries", UNSET))


        _risk_history = d.pop("riskHistory", UNSET)
        risk_history: list[RiskDto] | Unset = UNSET
        if _risk_history is not UNSET:
            risk_history = []
            for risk_history_item_data in _risk_history:
                risk_history_item = RiskDto.from_dict(risk_history_item_data)



                risk_history.append(risk_history_item)


        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: CreateBankAccountDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = CreateBankAccountDtoCustomFields.from_dict(_custom_fields)




        _associated_clients = d.pop("associatedClients", UNSET)
        associated_clients: list[ClientBankAccountRelationDto] | Unset = UNSET
        if _associated_clients is not UNSET:
            associated_clients = []
            for associated_clients_item_data in _associated_clients:
                associated_clients_item = ClientBankAccountRelationDto.from_dict(associated_clients_item_data)



                associated_clients.append(associated_clients_item)


        create_bank_account_dto = cls(
            account_number=account_number,
            reference_id=reference_id,
            status=status,
            bank_name=bank_name,
            routing_number=routing_number,
            account_holder_name=account_holder_name,
            account_type=account_type,
            currency=currency,
            balance_in_currency=balance_in_currency,
            balance_in_converted_amount=balance_in_converted_amount,
            countries=countries,
            risk_history=risk_history,
            custom_fields=custom_fields,
            associated_clients=associated_clients,
        )


        create_bank_account_dto.additional_properties = d
        return create_bank_account_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
