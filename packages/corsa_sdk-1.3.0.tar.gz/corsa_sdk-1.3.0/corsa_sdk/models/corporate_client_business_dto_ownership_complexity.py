from enum import Enum

class CorporateClientBusinessDtoOwnershipComplexity(str, Enum):
    COMPLEX_OWNERSHIP = "COMPLEX_OWNERSHIP"
    SIMPLE_OWNERSHIP = "SIMPLE_OWNERSHIP"

    def __str__(self) -> str:
        return str(self.value)
