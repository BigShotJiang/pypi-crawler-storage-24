from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.bulk_update_alert_status_dto_status import BulkUpdateAlertStatusDtoStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.alert_decision_dto import AlertDecisionDto





T = TypeVar("T", bound="BulkUpdateAlertStatusDto")



@_attrs_define
class BulkUpdateAlertStatusDto:
    """ 
        Attributes:
            alert_ids (list[str]): Array of alert IDs or reference IDs (maximum 100) Example:
                ['123e4567-e89b-12d3-a456-426614174000', 'ALT-REF-001'].
            status (BulkUpdateAlertStatusDtoStatus): The new status to apply to all specified alerts Example: IN_REVIEW.
            decision (AlertDecisionDto | Unset):
     """

    alert_ids: list[str]
    status: BulkUpdateAlertStatusDtoStatus
    decision: AlertDecisionDto | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.alert_decision_dto import AlertDecisionDto
        alert_ids = self.alert_ids



        status = self.status.value

        decision: dict[str, Any] | Unset = UNSET
        if not isinstance(self.decision, Unset):
            decision = self.decision.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "alertIds": alert_ids,
            "status": status,
        })
        if decision is not UNSET:
            field_dict["decision"] = decision

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_decision_dto import AlertDecisionDto
        d = dict(src_dict)
        alert_ids = cast(list[str], d.pop("alertIds"))


        status = BulkUpdateAlertStatusDtoStatus(d.pop("status"))




        _decision = d.pop("decision", UNSET)
        decision: AlertDecisionDto | Unset
        if isinstance(_decision,  Unset):
            decision = UNSET
        else:
            decision = AlertDecisionDto.from_dict(_decision)




        bulk_update_alert_status_dto = cls(
            alert_ids=alert_ids,
            status=status,
            decision=decision,
        )


        bulk_update_alert_status_dto.additional_properties = d
        return bulk_update_alert_status_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
