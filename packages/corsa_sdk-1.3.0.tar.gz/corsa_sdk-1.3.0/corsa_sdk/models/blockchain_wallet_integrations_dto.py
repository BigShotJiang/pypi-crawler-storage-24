from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.blockchain_wallet_integrations_dto_utila_metadata import BlockchainWalletIntegrationsDtoUtilaMetadata





T = TypeVar("T", bound="BlockchainWalletIntegrationsDto")



@_attrs_define
class BlockchainWalletIntegrationsDto:
    """ 
        Attributes:
            utila_wallet_id (str | Unset): Utila wallet ID for integration with utila Example: utila-wallet-123.
            utila_metadata (BlockchainWalletIntegrationsDtoUtilaMetadata | Unset): Metadata object for integration with
                utila (will be stringified when sent to neo4j-graphql-service) Example: {'key': 'value'}.
     """

    utila_wallet_id: str | Unset = UNSET
    utila_metadata: BlockchainWalletIntegrationsDtoUtilaMetadata | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.blockchain_wallet_integrations_dto_utila_metadata import BlockchainWalletIntegrationsDtoUtilaMetadata
        utila_wallet_id = self.utila_wallet_id

        utila_metadata: dict[str, Any] | Unset = UNSET
        if not isinstance(self.utila_metadata, Unset):
            utila_metadata = self.utila_metadata.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if utila_wallet_id is not UNSET:
            field_dict["utilaWalletId"] = utila_wallet_id
        if utila_metadata is not UNSET:
            field_dict["utilaMetadata"] = utila_metadata

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.blockchain_wallet_integrations_dto_utila_metadata import BlockchainWalletIntegrationsDtoUtilaMetadata
        d = dict(src_dict)
        utila_wallet_id = d.pop("utilaWalletId", UNSET)

        _utila_metadata = d.pop("utilaMetadata", UNSET)
        utila_metadata: BlockchainWalletIntegrationsDtoUtilaMetadata | Unset
        if isinstance(_utila_metadata,  Unset):
            utila_metadata = UNSET
        else:
            utila_metadata = BlockchainWalletIntegrationsDtoUtilaMetadata.from_dict(_utila_metadata)




        blockchain_wallet_integrations_dto = cls(
            utila_wallet_id=utila_wallet_id,
            utila_metadata=utila_metadata,
        )


        blockchain_wallet_integrations_dto.additional_properties = d
        return blockchain_wallet_integrations_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
