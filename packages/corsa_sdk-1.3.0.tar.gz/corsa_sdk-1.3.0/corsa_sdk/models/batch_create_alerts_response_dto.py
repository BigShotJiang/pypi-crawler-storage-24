from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.alert_dto import AlertDto
  from ..models.batch_create_alerts_response_dto_failed_alerts_item import BatchCreateAlertsResponseDtoFailedAlertsItem





T = TypeVar("T", bound="BatchCreateAlertsResponseDto")



@_attrs_define
class BatchCreateAlertsResponseDto:
    """ 
        Attributes:
            created_alerts (list[AlertDto]): Array of successfully created alerts
            failed_alerts (list[BatchCreateAlertsResponseDtoFailedAlertsItem]): Array of alerts that failed to create
                Example: [{'index': 0, 'alert': {}, 'error': 'Validation failed'}].
            total_processed (float): Total number of alerts processed Example: 10.
            success_count (float): Number of alerts successfully created Example: 8.
            failure_count (float): Number of alerts that failed to create Example: 2.
     """

    created_alerts: list[AlertDto]
    failed_alerts: list[BatchCreateAlertsResponseDtoFailedAlertsItem]
    total_processed: float
    success_count: float
    failure_count: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.alert_dto import AlertDto
        from ..models.batch_create_alerts_response_dto_failed_alerts_item import BatchCreateAlertsResponseDtoFailedAlertsItem
        created_alerts = []
        for created_alerts_item_data in self.created_alerts:
            created_alerts_item = created_alerts_item_data.to_dict()
            created_alerts.append(created_alerts_item)



        failed_alerts = []
        for failed_alerts_item_data in self.failed_alerts:
            failed_alerts_item = failed_alerts_item_data.to_dict()
            failed_alerts.append(failed_alerts_item)



        total_processed = self.total_processed

        success_count = self.success_count

        failure_count = self.failure_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "createdAlerts": created_alerts,
            "failedAlerts": failed_alerts,
            "totalProcessed": total_processed,
            "successCount": success_count,
            "failureCount": failure_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.alert_dto import AlertDto
        from ..models.batch_create_alerts_response_dto_failed_alerts_item import BatchCreateAlertsResponseDtoFailedAlertsItem
        d = dict(src_dict)
        created_alerts = []
        _created_alerts = d.pop("createdAlerts")
        for created_alerts_item_data in (_created_alerts):
            created_alerts_item = AlertDto.from_dict(created_alerts_item_data)



            created_alerts.append(created_alerts_item)


        failed_alerts = []
        _failed_alerts = d.pop("failedAlerts")
        for failed_alerts_item_data in (_failed_alerts):
            failed_alerts_item = BatchCreateAlertsResponseDtoFailedAlertsItem.from_dict(failed_alerts_item_data)



            failed_alerts.append(failed_alerts_item)


        total_processed = d.pop("totalProcessed")

        success_count = d.pop("successCount")

        failure_count = d.pop("failureCount")

        batch_create_alerts_response_dto = cls(
            created_alerts=created_alerts,
            failed_alerts=failed_alerts,
            total_processed=total_processed,
            success_count=success_count,
            failure_count=failure_count,
        )


        batch_create_alerts_response_dto.additional_properties = d
        return batch_create_alerts_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
