from enum import Enum

class ConditionDtoAggregationTimeType(str, Enum):
    AFTER = "after"
    ALL_TIME = "all_time"
    BEFORE = "before"
    BETWEEN = "between"
    IN_THE_LAST = "in_the_last"

    def __str__(self) -> str:
        return str(self.value)
