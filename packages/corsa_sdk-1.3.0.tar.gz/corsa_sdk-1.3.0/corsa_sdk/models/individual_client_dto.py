from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.individual_client_dto_account_status import IndividualClientDtoAccountStatus
from ..models.individual_client_dto_activity_status import IndividualClientDtoActivityStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.adverse_media_dto import AdverseMediaDto
  from ..models.individual_client_address_dto import IndividualClientAddressDto
  from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
  from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
  from ..models.individual_client_dto_custom_fields import IndividualClientDtoCustomFields
  from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
  from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
  from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
  from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
  from ..models.political_exposure_dto import PoliticalExposureDto
  from ..models.risk_dto import RiskDto
  from ..models.sanctions_dto import SanctionsDto





T = TypeVar("T", bound="IndividualClientDto")



@_attrs_define
class IndividualClientDto:
    """ 
        Attributes:
            id (str): Unique identifier of the client Example: 123e4567-e89b-12d3-a456-426614174000.
            account_status (IndividualClientDtoAccountStatus): Current account status Example: APPROVED.
            activity_status (IndividualClientDtoActivityStatus): Current activity status Example: ACTIVE.
            address (IndividualClientAddressDto):
            adverse_media (AdverseMediaDto):
            application (IndividualClientApplicationInformationDto):
            general (IndividualClientGeneralInformationDto):
            political_exposure (PoliticalExposureDto):
            risk_history (list[RiskDto]): Historical risk assessments
            sanctions (SanctionsDto):
            tags (list[str]): Tags associated with the client Example: ['high-value', 'vip-client'].
            controls (list[str]): List of control measures applied (DEPRECATED) Example: ['enhanced-due-diligence',
                'quarterly-review'].
            created_at (str): ISO timestamp of creation Example: 2023-08-15T10:30:00Z.
            updated_at (str): ISO timestamp of last update Example: 2023-08-20T14:30:00Z.
            reference_id (str | Unset): External reference ID Example: IND123.
            alerts (list[str] | Unset): List of alert IDs associated with the client Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
            contact (IndividualClientContactInformationDto | Unset):
            current_risk (RiskDto | Unset):
            onboarding_risk (RiskDto | Unset):
            custom_fields (IndividualClientDtoCustomFields | Unset): Custom fields data
            financial (IndividualClientFinancialInformationDto | Unset):
            financial_operations (list[str] | Unset): List of financial operation IDs Example:
                ['123e4567-e89b-12d3-a456-426614174000'].
            declared_assets (list[str] | Unset): Array of asset symbols the client is expected to trade with (maximum 50)
                Example: ['BTC', 'ETH', 'USDT'].
            work (IndividualClientWorkInformationDto | Unset):
            integrations (IndividualClientIntegrationsDto | Unset):
            partner_client_id (str | Unset): ID or referenceId of the partner corporate client Example:
                123e4567-e89b-12d3-a456-426614174000.
     """

    id: str
    account_status: IndividualClientDtoAccountStatus
    activity_status: IndividualClientDtoActivityStatus
    address: IndividualClientAddressDto
    adverse_media: AdverseMediaDto
    application: IndividualClientApplicationInformationDto
    general: IndividualClientGeneralInformationDto
    political_exposure: PoliticalExposureDto
    risk_history: list[RiskDto]
    sanctions: SanctionsDto
    tags: list[str]
    controls: list[str]
    created_at: str
    updated_at: str
    reference_id: str | Unset = UNSET
    alerts: list[str] | Unset = UNSET
    contact: IndividualClientContactInformationDto | Unset = UNSET
    current_risk: RiskDto | Unset = UNSET
    onboarding_risk: RiskDto | Unset = UNSET
    custom_fields: IndividualClientDtoCustomFields | Unset = UNSET
    financial: IndividualClientFinancialInformationDto | Unset = UNSET
    financial_operations: list[str] | Unset = UNSET
    declared_assets: list[str] | Unset = UNSET
    work: IndividualClientWorkInformationDto | Unset = UNSET
    integrations: IndividualClientIntegrationsDto | Unset = UNSET
    partner_client_id: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.adverse_media_dto import AdverseMediaDto
        from ..models.individual_client_address_dto import IndividualClientAddressDto
        from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
        from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
        from ..models.individual_client_dto_custom_fields import IndividualClientDtoCustomFields
        from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
        from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
        from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
        from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
        from ..models.political_exposure_dto import PoliticalExposureDto
        from ..models.risk_dto import RiskDto
        from ..models.sanctions_dto import SanctionsDto
        id = self.id

        account_status = self.account_status.value

        activity_status = self.activity_status.value

        address = self.address.to_dict()

        adverse_media = self.adverse_media.to_dict()

        application = self.application.to_dict()

        general = self.general.to_dict()

        political_exposure = self.political_exposure.to_dict()

        risk_history = []
        for risk_history_item_data in self.risk_history:
            risk_history_item = risk_history_item_data.to_dict()
            risk_history.append(risk_history_item)



        sanctions = self.sanctions.to_dict()

        tags = self.tags



        controls = self.controls



        created_at = self.created_at

        updated_at = self.updated_at

        reference_id = self.reference_id

        alerts: list[str] | Unset = UNSET
        if not isinstance(self.alerts, Unset):
            alerts = self.alerts



        contact: dict[str, Any] | Unset = UNSET
        if not isinstance(self.contact, Unset):
            contact = self.contact.to_dict()

        current_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.current_risk, Unset):
            current_risk = self.current_risk.to_dict()

        onboarding_risk: dict[str, Any] | Unset = UNSET
        if not isinstance(self.onboarding_risk, Unset):
            onboarding_risk = self.onboarding_risk.to_dict()

        custom_fields: dict[str, Any] | Unset = UNSET
        if not isinstance(self.custom_fields, Unset):
            custom_fields = self.custom_fields.to_dict()

        financial: dict[str, Any] | Unset = UNSET
        if not isinstance(self.financial, Unset):
            financial = self.financial.to_dict()

        financial_operations: list[str] | Unset = UNSET
        if not isinstance(self.financial_operations, Unset):
            financial_operations = self.financial_operations



        declared_assets: list[str] | Unset = UNSET
        if not isinstance(self.declared_assets, Unset):
            declared_assets = self.declared_assets



        work: dict[str, Any] | Unset = UNSET
        if not isinstance(self.work, Unset):
            work = self.work.to_dict()

        integrations: dict[str, Any] | Unset = UNSET
        if not isinstance(self.integrations, Unset):
            integrations = self.integrations.to_dict()

        partner_client_id = self.partner_client_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "accountStatus": account_status,
            "activityStatus": activity_status,
            "address": address,
            "adverseMedia": adverse_media,
            "application": application,
            "general": general,
            "politicalExposure": political_exposure,
            "riskHistory": risk_history,
            "sanctions": sanctions,
            "tags": tags,
            "controls": controls,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if alerts is not UNSET:
            field_dict["alerts"] = alerts
        if contact is not UNSET:
            field_dict["contact"] = contact
        if current_risk is not UNSET:
            field_dict["currentRisk"] = current_risk
        if onboarding_risk is not UNSET:
            field_dict["onboardingRisk"] = onboarding_risk
        if custom_fields is not UNSET:
            field_dict["customFields"] = custom_fields
        if financial is not UNSET:
            field_dict["financial"] = financial
        if financial_operations is not UNSET:
            field_dict["financialOperations"] = financial_operations
        if declared_assets is not UNSET:
            field_dict["declaredAssets"] = declared_assets
        if work is not UNSET:
            field_dict["work"] = work
        if integrations is not UNSET:
            field_dict["integrations"] = integrations
        if partner_client_id is not UNSET:
            field_dict["partnerClientId"] = partner_client_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.adverse_media_dto import AdverseMediaDto
        from ..models.individual_client_address_dto import IndividualClientAddressDto
        from ..models.individual_client_application_information_dto import IndividualClientApplicationInformationDto
        from ..models.individual_client_contact_information_dto import IndividualClientContactInformationDto
        from ..models.individual_client_dto_custom_fields import IndividualClientDtoCustomFields
        from ..models.individual_client_financial_information_dto import IndividualClientFinancialInformationDto
        from ..models.individual_client_general_information_dto import IndividualClientGeneralInformationDto
        from ..models.individual_client_integrations_dto import IndividualClientIntegrationsDto
        from ..models.individual_client_work_information_dto import IndividualClientWorkInformationDto
        from ..models.political_exposure_dto import PoliticalExposureDto
        from ..models.risk_dto import RiskDto
        from ..models.sanctions_dto import SanctionsDto
        d = dict(src_dict)
        id = d.pop("id")

        account_status = IndividualClientDtoAccountStatus(d.pop("accountStatus"))




        activity_status = IndividualClientDtoActivityStatus(d.pop("activityStatus"))




        address = IndividualClientAddressDto.from_dict(d.pop("address"))




        adverse_media = AdverseMediaDto.from_dict(d.pop("adverseMedia"))




        application = IndividualClientApplicationInformationDto.from_dict(d.pop("application"))




        general = IndividualClientGeneralInformationDto.from_dict(d.pop("general"))




        political_exposure = PoliticalExposureDto.from_dict(d.pop("politicalExposure"))




        risk_history = []
        _risk_history = d.pop("riskHistory")
        for risk_history_item_data in (_risk_history):
            risk_history_item = RiskDto.from_dict(risk_history_item_data)



            risk_history.append(risk_history_item)


        sanctions = SanctionsDto.from_dict(d.pop("sanctions"))




        tags = cast(list[str], d.pop("tags"))


        controls = cast(list[str], d.pop("controls"))


        created_at = d.pop("createdAt")

        updated_at = d.pop("updatedAt")

        reference_id = d.pop("referenceId", UNSET)

        alerts = cast(list[str], d.pop("alerts", UNSET))


        _contact = d.pop("contact", UNSET)
        contact: IndividualClientContactInformationDto | Unset
        if isinstance(_contact,  Unset):
            contact = UNSET
        else:
            contact = IndividualClientContactInformationDto.from_dict(_contact)




        _current_risk = d.pop("currentRisk", UNSET)
        current_risk: RiskDto | Unset
        if isinstance(_current_risk,  Unset):
            current_risk = UNSET
        else:
            current_risk = RiskDto.from_dict(_current_risk)




        _onboarding_risk = d.pop("onboardingRisk", UNSET)
        onboarding_risk: RiskDto | Unset
        if isinstance(_onboarding_risk,  Unset):
            onboarding_risk = UNSET
        else:
            onboarding_risk = RiskDto.from_dict(_onboarding_risk)




        _custom_fields = d.pop("customFields", UNSET)
        custom_fields: IndividualClientDtoCustomFields | Unset
        if isinstance(_custom_fields,  Unset):
            custom_fields = UNSET
        else:
            custom_fields = IndividualClientDtoCustomFields.from_dict(_custom_fields)




        _financial = d.pop("financial", UNSET)
        financial: IndividualClientFinancialInformationDto | Unset
        if isinstance(_financial,  Unset):
            financial = UNSET
        else:
            financial = IndividualClientFinancialInformationDto.from_dict(_financial)




        financial_operations = cast(list[str], d.pop("financialOperations", UNSET))


        declared_assets = cast(list[str], d.pop("declaredAssets", UNSET))


        _work = d.pop("work", UNSET)
        work: IndividualClientWorkInformationDto | Unset
        if isinstance(_work,  Unset):
            work = UNSET
        else:
            work = IndividualClientWorkInformationDto.from_dict(_work)




        _integrations = d.pop("integrations", UNSET)
        integrations: IndividualClientIntegrationsDto | Unset
        if isinstance(_integrations,  Unset):
            integrations = UNSET
        else:
            integrations = IndividualClientIntegrationsDto.from_dict(_integrations)




        partner_client_id = d.pop("partnerClientId", UNSET)

        individual_client_dto = cls(
            id=id,
            account_status=account_status,
            activity_status=activity_status,
            address=address,
            adverse_media=adverse_media,
            application=application,
            general=general,
            political_exposure=political_exposure,
            risk_history=risk_history,
            sanctions=sanctions,
            tags=tags,
            controls=controls,
            created_at=created_at,
            updated_at=updated_at,
            reference_id=reference_id,
            alerts=alerts,
            contact=contact,
            current_risk=current_risk,
            onboarding_risk=onboarding_risk,
            custom_fields=custom_fields,
            financial=financial,
            financial_operations=financial_operations,
            declared_assets=declared_assets,
            work=work,
            integrations=integrations,
            partner_client_id=partner_client_id,
        )


        individual_client_dto.additional_properties = d
        return individual_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
