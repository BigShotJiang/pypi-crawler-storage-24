from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.client_blockchain_wallet_relation_dto import ClientBlockchainWalletRelationDto





T = TypeVar("T", bound="AssociateBlockchainWalletWithClientDto")



@_attrs_define
class AssociateBlockchainWalletWithClientDto:
    """ 
        Attributes:
            associated_clients (list[ClientBlockchainWalletRelationDto]): List of clients to associate with the blockchain
                wallet (maximum 50) Example: [{'clientId': 'client-123', 'name': 'Primary Wallet'}, {'clientId': 'client-456',
                'name': 'Secondary Wallet'}].
     """

    associated_clients: list[ClientBlockchainWalletRelationDto]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.client_blockchain_wallet_relation_dto import ClientBlockchainWalletRelationDto
        associated_clients = []
        for associated_clients_item_data in self.associated_clients:
            associated_clients_item = associated_clients_item_data.to_dict()
            associated_clients.append(associated_clients_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "associatedClients": associated_clients,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.client_blockchain_wallet_relation_dto import ClientBlockchainWalletRelationDto
        d = dict(src_dict)
        associated_clients = []
        _associated_clients = d.pop("associatedClients")
        for associated_clients_item_data in (_associated_clients):
            associated_clients_item = ClientBlockchainWalletRelationDto.from_dict(associated_clients_item_data)



            associated_clients.append(associated_clients_item)


        associate_blockchain_wallet_with_client_dto = cls(
            associated_clients=associated_clients,
        )


        associate_blockchain_wallet_with_client_dto.additional_properties = d
        return associate_blockchain_wallet_with_client_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
