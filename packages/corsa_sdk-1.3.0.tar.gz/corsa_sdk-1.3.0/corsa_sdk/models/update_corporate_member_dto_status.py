from enum import Enum

class UpdateCorporateMemberDtoStatus(str, Enum):
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    UNDER_REVIEW = "UNDER_REVIEW"

    def __str__(self) -> str:
        return str(self.value)
