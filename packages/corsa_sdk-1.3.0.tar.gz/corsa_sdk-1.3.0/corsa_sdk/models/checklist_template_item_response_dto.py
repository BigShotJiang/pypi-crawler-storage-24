from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.checklist_template_item_response_dto_category import ChecklistTemplateItemResponseDtoCategory
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.checklist_template_item_response_dto_status_options_item import ChecklistTemplateItemResponseDtoStatusOptionsItem





T = TypeVar("T", bound="ChecklistTemplateItemResponseDto")



@_attrs_define
class ChecklistTemplateItemResponseDto:
    """ 
        Attributes:
            id (str): The unique identifier of the item Example: item-123.
            name (str): The name of the item Example: Identity Verification.
            category (ChecklistTemplateItemResponseDtoCategory): The category of the checklist item Example:
                PERSONAL_IDENTIFICATION.
            status_options (list[ChecklistTemplateItemResponseDtoStatusOptionsItem]): Available status options for this item
                Example: [{'name': 'PENDING', 'color': 'yellow'}, {'name': 'COMPLETED', 'color': 'green'}, {'name': 'REJECTED',
                'color': 'red'}].
            created_at (datetime.datetime): When the item was created Example: 2024-01-01T00:00:00.000Z.
            updated_at (datetime.datetime): When the item was last updated Example: 2024-01-01T00:00:00.000Z.
            note (str | Unset): Optional note for the item Example: Verify government-issued ID.
     """

    id: str
    name: str
    category: ChecklistTemplateItemResponseDtoCategory
    status_options: list[ChecklistTemplateItemResponseDtoStatusOptionsItem]
    created_at: datetime.datetime
    updated_at: datetime.datetime
    note: str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.checklist_template_item_response_dto_status_options_item import ChecklistTemplateItemResponseDtoStatusOptionsItem
        id = self.id

        name = self.name

        category = self.category.value

        status_options = []
        for status_options_item_data in self.status_options:
            status_options_item = status_options_item_data.to_dict()
            status_options.append(status_options_item)



        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        note = self.note


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "category": category,
            "statusOptions": status_options,
            "createdAt": created_at,
            "updatedAt": updated_at,
        })
        if note is not UNSET:
            field_dict["note"] = note

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.checklist_template_item_response_dto_status_options_item import ChecklistTemplateItemResponseDtoStatusOptionsItem
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        category = ChecklistTemplateItemResponseDtoCategory(d.pop("category"))




        status_options = []
        _status_options = d.pop("statusOptions")
        for status_options_item_data in (_status_options):
            status_options_item = ChecklistTemplateItemResponseDtoStatusOptionsItem.from_dict(status_options_item_data)



            status_options.append(status_options_item)


        created_at = isoparse(d.pop("createdAt"))




        updated_at = isoparse(d.pop("updatedAt"))




        note = d.pop("note", UNSET)

        checklist_template_item_response_dto = cls(
            id=id,
            name=name,
            category=category,
            status_options=status_options,
            created_at=created_at,
            updated_at=updated_at,
            note=note,
        )


        checklist_template_item_response_dto.additional_properties = d
        return checklist_template_item_response_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
