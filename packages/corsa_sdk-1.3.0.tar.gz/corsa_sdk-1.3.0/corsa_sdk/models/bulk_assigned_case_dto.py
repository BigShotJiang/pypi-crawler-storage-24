from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="BulkAssignedCaseDto")



@_attrs_define
class BulkAssignedCaseDto:
    """ 
        Attributes:
            id (str): The ID of the updated case Example: 123e4567-e89b-12d3-a456-426614174000.
            reference_id (str | Unset): The reference ID of the updated case Example: CASE-REF-001.
            assignee_id (None | str | Unset): The user ID the case is assigned to, or null if unassigned Example:
                123e4567-e89b-12d3-a456-426614174000.
     """

    id: str
    reference_id: str | Unset = UNSET
    assignee_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        reference_id = self.reference_id

        assignee_id: None | str | Unset
        if isinstance(self.assignee_id, Unset):
            assignee_id = UNSET
        else:
            assignee_id = self.assignee_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
        })
        if reference_id is not UNSET:
            field_dict["referenceId"] = reference_id
        if assignee_id is not UNSET:
            field_dict["assigneeId"] = assignee_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        reference_id = d.pop("referenceId", UNSET)

        def _parse_assignee_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        assignee_id = _parse_assignee_id(d.pop("assigneeId", UNSET))


        bulk_assigned_case_dto = cls(
            id=id,
            reference_id=reference_id,
            assignee_id=assignee_id,
        )


        bulk_assigned_case_dto.additional_properties = d
        return bulk_assigned_case_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
