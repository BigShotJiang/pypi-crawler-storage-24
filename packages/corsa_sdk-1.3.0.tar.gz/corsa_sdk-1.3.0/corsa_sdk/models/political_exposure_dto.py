from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="PoliticalExposureDto")



@_attrs_define
class PoliticalExposureDto:
    """ 
        Attributes:
            is_politically_exposed (bool | None): Indicates if the client is politically exposed
     """

    is_politically_exposed: bool | None
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        is_politically_exposed: bool | None
        is_politically_exposed = self.is_politically_exposed


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "isPoliticallyExposed": is_politically_exposed,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_is_politically_exposed(data: object) -> bool | None:
            if data is None:
                return data
            return cast(bool | None, data)

        is_politically_exposed = _parse_is_politically_exposed(d.pop("isPoliticallyExposed"))


        political_exposure_dto = cls(
            is_politically_exposed=is_politically_exposed,
        )


        political_exposure_dto.additional_properties = d
        return political_exposure_dto

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
