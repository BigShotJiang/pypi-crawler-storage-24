from enum import Enum

class CreateAlertDtoPepTier(str, Enum):
    NO_PEP = "NO_PEP"
    TIER_1 = "TIER_1"
    TIER_2 = "TIER_2"
    TIER_3 = "TIER_3"
    TIER_4 = "TIER_4"

    def __str__(self) -> str:
        return str(self.value)
