"""High-level Corsa API client wrapper.

Provides a convenient ``CorsaClient`` / ``AsyncCorsaClient`` that groups
generated API endpoint modules under service-like namespaces.

This file is **not** regenerated and must be updated when new API tags
are added or removed by the generator.
"""

from __future__ import annotations

import importlib
import pkgutil
from types import ModuleType
from typing import Any, Dict, Optional

from corsa_sdk.client import AuthenticatedClient


class _SyncApiNamespace:
    """Wraps a generated API tag module so each endpoint becomes an attribute
    that calls the ``sync`` variant by default."""

    def __init__(self, package: ModuleType, client: AuthenticatedClient) -> None:
        self._client = client
        self._modules: Dict[str, ModuleType] = {}
        if hasattr(package, "__path__"):
            for info in pkgutil.iter_modules(package.__path__):
                mod = importlib.import_module(f"{package.__name__}.{info.name}")
                self._modules[info.name] = mod

    def __getattr__(self, name: str) -> Any:
        mod = self._modules.get(name)
        if mod is None:
            raise AttributeError(f"No endpoint '{name}' in this API namespace")

        def _call(**kwargs: Any) -> Any:
            return mod.sync(client=self._client, **kwargs)  # type: ignore[attr-defined]

        return _call

    def __dir__(self) -> list[str]:
        return list(self._modules.keys())


class _AsyncApiNamespace:
    """Async variant -- each endpoint attribute calls the ``asyncio`` variant."""

    def __init__(self, package: ModuleType, client: AuthenticatedClient) -> None:
        self._client = client
        self._modules: Dict[str, ModuleType] = {}
        if hasattr(package, "__path__"):
            for info in pkgutil.iter_modules(package.__path__):
                mod = importlib.import_module(f"{package.__name__}.{info.name}")
                self._modules[info.name] = mod

    def __getattr__(self, name: str) -> Any:
        mod = self._modules.get(name)
        if mod is None:
            raise AttributeError(f"No endpoint '{name}' in this API namespace")

        async def _call(**kwargs: Any) -> Any:
            return await mod.asyncio(client=self._client, **kwargs)  # type: ignore[attr-defined]

        return _call

    def __dir__(self) -> list[str]:
        return list(self._modules.keys())


def _load_api_namespaces(
    namespace_cls: type,
    client: AuthenticatedClient,
) -> Dict[str, Any]:
    """Discover all API tag packages under ``corsa_sdk.api`` and wrap them."""
    import corsa_sdk.api as api_root

    namespaces: Dict[str, Any] = {}
    if hasattr(api_root, "__path__"):
        for info in pkgutil.iter_modules(api_root.__path__):
            if info.ispkg:
                pkg = importlib.import_module(f"corsa_sdk.api.{info.name}")
                namespaces[info.name] = namespace_cls(pkg, client)
    return namespaces


class CorsaClient:
    """Synchronous Corsa API client.

    Usage::

        from corsa_sdk import CorsaClient
        from corsa_sdk.models import CreateAlertDto

        client = CorsaClient(
            base_url="https://api-gateway.corsa.finance",
            token="your-api-token",
        )
        alert = client.alerts.create_alert(body=CreateAlertDto(...))
        client.close()

    Each API tag (alerts, cases, clients, ...) is exposed as an attribute.
    Endpoint names match the generated module names under ``corsa_sdk/api/<tag>/``.
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        *,
        timeout: Optional[float] = None,
        headers: Optional[Dict[str, str]] = None,
        raise_on_unexpected_status: bool = True,
        httpx_args: Optional[Dict[str, Any]] = None,
    ) -> None:
        import httpx as _httpx

        self._auth_client = AuthenticatedClient(
            base_url=base_url,
            token=token,
            timeout=_httpx.Timeout(timeout) if timeout is not None else None,
            headers=headers or {},
            raise_on_unexpected_status=raise_on_unexpected_status,
            httpx_args=httpx_args or {},
        )
        self._namespaces = _load_api_namespaces(_SyncApiNamespace, self._auth_client)

    @property
    def raw_client(self) -> AuthenticatedClient:
        """Access the underlying ``AuthenticatedClient`` for advanced usage."""
        return self._auth_client

    def __getattr__(self, name: str) -> Any:
        try:
            namespaces = self.__dict__["_namespaces"]
        except KeyError:
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'") from None
        ns = namespaces.get(name)
        if ns is not None:
            return ns
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

    def __dir__(self) -> list[str]:
        namespaces = self.__dict__.get("_namespaces", {})
        return list(namespaces.keys()) + ["raw_client", "close"]

    def close(self) -> None:
        client = self._auth_client.get_httpx_client()
        client.close()

    def __enter__(self) -> "CorsaClient":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class AsyncCorsaClient:
    """Async Corsa API client.

    Usage::

        from corsa_sdk import AsyncCorsaClient
        from corsa_sdk.models import CreateAlertDto

        async with AsyncCorsaClient(
            base_url="https://api-gateway.corsa.finance",
            token="your-api-token",
        ) as client:
            alert = await client.alerts.create_alert(body=CreateAlertDto(...))
    """

    def __init__(
        self,
        base_url: str,
        token: str,
        *,
        timeout: Optional[float] = None,
        headers: Optional[Dict[str, str]] = None,
        raise_on_unexpected_status: bool = True,
        httpx_args: Optional[Dict[str, Any]] = None,
    ) -> None:
        import httpx as _httpx

        self._auth_client = AuthenticatedClient(
            base_url=base_url,
            token=token,
            timeout=_httpx.Timeout(timeout) if timeout is not None else None,
            headers=headers or {},
            raise_on_unexpected_status=raise_on_unexpected_status,
            httpx_args=httpx_args or {},
        )
        self._namespaces = _load_api_namespaces(_AsyncApiNamespace, self._auth_client)

    @property
    def raw_client(self) -> AuthenticatedClient:
        return self._auth_client

    def __getattr__(self, name: str) -> Any:
        try:
            namespaces = self.__dict__["_namespaces"]
        except KeyError:
            raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'") from None
        ns = namespaces.get(name)
        if ns is not None:
            return ns
        raise AttributeError(f"'{type(self).__name__}' has no attribute '{name}'")

    def __dir__(self) -> list[str]:
        namespaces = self.__dict__.get("_namespaces", {})
        return list(namespaces.keys()) + ["raw_client", "close"]

    async def close(self) -> None:
        client = self._auth_client.get_async_httpx_client()
        await client.aclose()

    async def __aenter__(self) -> "AsyncCorsaClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()
