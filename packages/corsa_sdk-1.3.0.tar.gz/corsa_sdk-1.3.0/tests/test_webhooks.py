from corsa_sdk.webhooks import sign_webhook_payload, verify_webhook_signature

import pytest


class TestSignWebhookPayload:
    def test_returns_sha256_prefixed_signature(self) -> None:
        sig = sign_webhook_payload("my-secret", '{"event":"alert.created"}')
        assert sig.startswith("sha256=")
        assert len(sig) == len("sha256=") + 64  # hex SHA-256

    def test_deterministic(self) -> None:
        payload = '{"id":"123"}'
        a = sign_webhook_payload("secret", payload)
        b = sign_webhook_payload("secret", payload)
        assert a == b

    def test_different_secrets_produce_different_sigs(self) -> None:
        payload = '{"id":"123"}'
        a = sign_webhook_payload("secret-a", payload)
        b = sign_webhook_payload("secret-b", payload)
        assert a != b

    def test_raises_on_empty_secret(self) -> None:
        with pytest.raises(TypeError, match="secret & payload required"):
            sign_webhook_payload("", "payload")

    def test_raises_on_empty_payload(self) -> None:
        with pytest.raises(TypeError, match="secret & payload required"):
            sign_webhook_payload("secret", "")


class TestVerifyWebhookSignature:
    def test_valid_signature_returns_true(self) -> None:
        secret = "test-secret"
        payload = '{"event":"alert.created","id":"abc"}'
        sig = sign_webhook_payload(secret, payload)
        assert verify_webhook_signature(secret, payload, sig) is True

    def test_invalid_signature_returns_false(self) -> None:
        secret = "test-secret"
        payload = '{"event":"alert.created"}'
        assert verify_webhook_signature(secret, payload, "sha256=0000bad") is False

    def test_wrong_secret_returns_false(self) -> None:
        payload = '{"event":"alert.created"}'
        sig = sign_webhook_payload("correct-secret", payload)
        assert verify_webhook_signature("wrong-secret", payload, sig) is False

    def test_tampered_payload_returns_false(self) -> None:
        secret = "my-secret"
        sig = sign_webhook_payload(secret, '{"original":true}')
        assert verify_webhook_signature(secret, '{"tampered":true}', sig) is False

    def test_raises_on_missing_args(self) -> None:
        with pytest.raises(TypeError, match="secret, event_payload & signature required"):
            verify_webhook_signature("", "payload", "sig")
        with pytest.raises(TypeError, match="secret, event_payload & signature required"):
            verify_webhook_signature("secret", "", "sig")
        with pytest.raises(TypeError, match="secret, event_payload & signature required"):
            verify_webhook_signature("secret", "payload", "")
