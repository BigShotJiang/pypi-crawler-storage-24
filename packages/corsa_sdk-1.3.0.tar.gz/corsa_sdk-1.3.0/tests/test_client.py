from corsa_sdk import CorsaClient, AsyncCorsaClient, AuthenticatedClient


class TestCorsaClientInit:
    def test_creates_client_with_base_url_and_token(self) -> None:
        client = CorsaClient(
            base_url="https://api-gateway.corsa.finance",
            token="test-token",
        )
        assert client.raw_client is not None
        assert isinstance(client.raw_client, AuthenticatedClient)

    def test_exposes_api_namespaces(self) -> None:
        client = CorsaClient(
            base_url="https://api-gateway.corsa.finance",
            token="test-token",
        )
        attrs = dir(client)
        assert "alerts" in attrs
        assert "cases" in attrs
        assert "clients" in attrs
        assert "transactions" in attrs

    def test_context_manager(self) -> None:
        with CorsaClient(
            base_url="https://api-gateway.corsa.finance",
            token="test-token",
        ) as client:
            assert client.raw_client is not None

    def test_unknown_attribute_raises(self) -> None:
        client = CorsaClient(
            base_url="https://api-gateway.corsa.finance",
            token="test-token",
        )
        try:
            _ = client.nonexistent_service
            assert False, "Should have raised AttributeError"
        except AttributeError:
            pass


class TestAsyncCorsaClientInit:
    def test_creates_async_client(self) -> None:
        client = AsyncCorsaClient(
            base_url="https://api-gateway.corsa.finance",
            token="test-token",
        )
        assert client.raw_client is not None
        assert isinstance(client.raw_client, AuthenticatedClient)

    def test_exposes_api_namespaces(self) -> None:
        client = AsyncCorsaClient(
            base_url="https://api-gateway.corsa.finance",
            token="test-token",
        )
        attrs = dir(client)
        assert "alerts" in attrs
        assert "cases" in attrs


class TestModelsImport:
    def test_can_import_alert_dto(self) -> None:
        from corsa_sdk.models.alert_dto import AlertDto
        assert AlertDto is not None

    def test_can_import_create_alert_dto(self) -> None:
        from corsa_sdk.models.create_alert_dto import CreateAlertDto
        assert CreateAlertDto is not None

    def test_can_import_case_dto(self) -> None:
        from corsa_sdk.models.case_dto import CaseDto
        assert CaseDto is not None
