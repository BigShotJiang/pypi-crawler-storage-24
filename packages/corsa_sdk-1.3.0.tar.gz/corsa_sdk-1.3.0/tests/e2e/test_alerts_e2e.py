"""E2E tests for the Alerts API.

Validates create -> get -> update cycle by making HTTP calls through the
authenticated httpx client and asserting on status codes + JSON payloads.
"""

from __future__ import annotations

import json
from http import HTTPStatus

import pytest

from corsa_sdk import AuthenticatedClient, CorsaClient
from corsa_sdk.api.alerts.create_alert import _get_kwargs as create_alert_kwargs
from corsa_sdk.api.alerts.get_alert import _get_kwargs as get_alert_kwargs
from corsa_sdk.api.alerts.update_alert import _get_kwargs as update_alert_kwargs
from corsa_sdk.models.create_alert_dto import CreateAlertDto
from corsa_sdk.models.create_alert_dto_category import CreateAlertDtoCategory
from corsa_sdk.models.create_alert_dto_priority import CreateAlertDtoPriority
from corsa_sdk.models.create_alert_dto_status import CreateAlertDtoStatus
from corsa_sdk.models.update_alert_dto import UpdateAlertDto
from corsa_sdk.models.update_alert_dto_priority import UpdateAlertDtoPriority


class TestAlertsCRUD:
    def test_create_and_get_alert(self, sync_client: CorsaClient, unique_ref: str) -> None:
        httpx_client = sync_client.raw_client.get_httpx_client()

        body = CreateAlertDto(
            category=CreateAlertDtoCategory.TRANSACTION_MONITORING,
            description=f"Python SDK e2e test alert ({unique_ref})",
            priority=CreateAlertDtoPriority.LOW,
            status=CreateAlertDtoStatus.NEW,
            reference_id=unique_ref,
        )

        resp = httpx_client.request(**create_alert_kwargs(body=body))
        assert resp.status_code == HTTPStatus.CREATED
        data = resp.json()
        alert_id = data["id"]
        assert alert_id

        get_resp = httpx_client.request(**get_alert_kwargs(alert_id=alert_id))
        assert get_resp.status_code == HTTPStatus.OK
        get_data = get_resp.json()
        assert get_data["id"] == alert_id
        assert get_data["referenceId"] == unique_ref

    def test_create_and_update_alert(self, sync_client: CorsaClient, unique_ref: str) -> None:
        httpx_client = sync_client.raw_client.get_httpx_client()

        body = CreateAlertDto(
            category=CreateAlertDtoCategory.KYC,
            description=f"Python SDK e2e update test ({unique_ref})",
            priority=CreateAlertDtoPriority.MEDIUM,
            status=CreateAlertDtoStatus.NEW,
            reference_id=unique_ref,
        )

        create_resp = httpx_client.request(**create_alert_kwargs(body=body))
        assert create_resp.status_code == HTTPStatus.CREATED
        alert_id = create_resp.json()["id"]

        update_body = UpdateAlertDto(priority=UpdateAlertDtoPriority.HIGH)
        update_resp = httpx_client.request(
            **update_alert_kwargs(alert_id=alert_id, body=update_body)
        )
        assert update_resp.status_code == HTTPStatus.OK
        assert update_resp.json()["priority"] == "HIGH"
