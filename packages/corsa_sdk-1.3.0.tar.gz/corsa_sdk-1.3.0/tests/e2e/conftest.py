"""Shared fixtures for e2e tests.

Required environment variables:
    CORSA_API_URL   - Base URL of the Corsa API (e.g. https://api.staging.corsa.finance)
    CORSA_API_TOKEN - Valid API token for the target platform

Run with:
    CORSA_API_URL=https://api.staging.corsa.finance CORSA_API_TOKEN=... pytest tests/e2e/ -v
"""

from __future__ import annotations

import os
import uuid
from typing import Generator

import pytest

from corsa_sdk import AsyncCorsaClient, CorsaClient


def pytest_collection_modifyitems(items: list[pytest.Item]) -> None:
    """Auto-mark all tests in tests/e2e/ with the ``e2e`` marker."""
    for item in items:
        if "/e2e/" in str(item.fspath):
            item.add_marker(pytest.mark.e2e)


def _require_env(name: str) -> str:
    value = os.environ.get(name)
    if not value:
        pytest.skip(f"{name} environment variable not set")
    return value


@pytest.fixture(scope="session")
def api_url() -> str:
    return _require_env("CORSA_API_URL")


@pytest.fixture(scope="session")
def api_token() -> str:
    return _require_env("CORSA_API_TOKEN")


@pytest.fixture(scope="session")
def sync_client(api_url: str, api_token: str) -> Generator[CorsaClient, None, None]:
    client = CorsaClient(
        base_url=api_url,
        token=api_token,
        timeout=30.0,
        raise_on_unexpected_status=True,
    )
    yield client
    client.close()


@pytest.fixture(scope="session")
def async_client(api_url: str, api_token: str) -> AsyncCorsaClient:
    return AsyncCorsaClient(
        base_url=api_url,
        token=api_token,
        timeout=30.0,
        raise_on_unexpected_status=True,
    )


@pytest.fixture()
def unique_ref() -> str:
    """Generate a unique reference ID for test entities to avoid collisions."""
    return f"e2e-py-sdk-{uuid.uuid4().hex[:12]}"
