"""Tests for the event normaliser."""

from __future__ import annotations

import pytest

from vectimus.core.models import ActionType, EventType
from vectimus.core.normaliser import normalise


class TestClaudeCodeNormaliser:
    """Tests for Claude Code payload normalisation."""

    def test_bash_command(self) -> None:
        payload = {
            "tool_name": "Bash",
            "tool_input": {"command": "ls -la"},
            "hook_event_name": "PreToolUse",
            "session_id": "abc-123",
            "cwd": "/home/user/project",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.SHELL_COMMAND
        assert event.action.command == "ls -la"
        assert event.source.tool == "claude-code"
        assert event.context.cwd == "/home/user/project"
        assert event.event_type == EventType.PRE_ACTION

    def test_file_write(self) -> None:
        payload = {
            "tool_name": "Write",
            "tool_input": {"file_path": "src/main.py"},
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.FILE_WRITE
        assert event.action.file_path == "src/main.py"

    def test_terraform_detected_as_infrastructure(self) -> None:
        payload = {
            "tool_name": "Bash",
            "tool_input": {"command": "terraform plan"},
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.INFRASTRUCTURE

    def test_npm_detected_as_package_operation(self) -> None:
        payload = {
            "tool_name": "Bash",
            "tool_input": {"command": "npm install express"},
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.PACKAGE_OPERATION

    def test_git_detected_as_git_operation(self) -> None:
        payload = {
            "tool_name": "Bash",
            "tool_input": {"command": "git push origin main"},
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.GIT_OPERATION

    def test_mcp_tool_detection(self) -> None:
        payload = {
            "tool_name": "mcp__github__create_issue",
            "tool_input": {"title": "Bug report"},
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.MCP_TOOL
        assert event.action.mcp_server == "github"
        assert event.action.mcp_tool == "create_issue"

    def test_post_tool_use(self) -> None:
        payload = {
            "tool_name": "Bash",
            "tool_input": {"command": "echo hello"},
            "hook_event_name": "PostToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.event_type == EventType.POST_ACTION

    def test_agent_spawn(self) -> None:
        payload = {
            "tool_name": "Agent",
            "tool_input": {
                "subagent_type": "general-purpose",
                "mode": "bypassPermissions",
                "max_turns": 100,
                "run_in_background": True,
                "name": "researcher",
                "prompt": "Do something",
            },
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.AGENT_SPAWN
        assert event.action.raw_tool_name == "Agent"
        assert "mode=bypassPermissions" in event.action.command
        assert "EXCESSIVE_TURNS" in event.action.command
        assert "background=true" in event.action.command

    def test_agent_spawn_normal_turns(self) -> None:
        payload = {
            "tool_name": "Agent",
            "tool_input": {
                "subagent_type": "Explore",
                "max_turns": 10,
                "prompt": "Find files",
            },
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.AGENT_SPAWN
        assert "max_turns=10" in event.action.command
        assert "EXCESSIVE_TURNS" not in event.action.command

    def test_send_message(self) -> None:
        payload = {
            "tool_name": "SendMessage",
            "tool_input": {
                "type": "broadcast",
                "content": "Hello everyone",
                "summary": "Greeting",
            },
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.AGENT_MESSAGE
        assert event.action.raw_tool_name == "SendMessage"
        assert "type=broadcast" in event.action.command

    def test_send_message_targeted(self) -> None:
        payload = {
            "tool_name": "SendMessage",
            "tool_input": {
                "type": "message",
                "recipient": "researcher",
                "content": "Check the logs",
            },
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.AGENT_MESSAGE
        assert "type=message" in event.action.command
        assert "recipient=researcher" in event.action.command

    def test_team_create(self) -> None:
        payload = {
            "tool_name": "TeamCreate",
            "tool_input": {
                "team_name": "my-swarm",
                "description": "Build feature X",
            },
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.action.action_type == ActionType.AGENT_SPAWN
        assert event.action.raw_tool_name == "TeamCreate"
        assert "team_create" in event.action.command
        assert "team_name=my-swarm" in event.action.command


class TestCursorNormaliser:
    """Tests for Cursor payload normalisation."""

    def test_shell_execution(self) -> None:
        payload = {
            "conversation_id": "conv-1",
            "generation_id": "gen-1",
            "command": "rm -rf /tmp/build",
            "cwd": "/home/user/project",
            "hook_event_name": "beforeShellExecution",
            "workspace_roots": ["/home/user/project"],
        }
        event = normalise(payload, "cursor")
        assert event.action.action_type == ActionType.SHELL_COMMAND
        assert event.action.command == "rm -rf /tmp/build"
        assert event.source.tool == "cursor"
        assert event.context.repository == "/home/user/project"


class TestCopilotNormaliser:
    """Tests for Copilot / VS Code payload normalisation."""

    def test_bash_command(self) -> None:
        payload = {
            "timestamp": "2026-03-08T14:30:00.000Z",
            "cwd": "/home/user/project",
            "sessionId": "session-1",
            "hookEventName": "PreToolUse",
            "tool_name": "Bash",
            "tool_input": {"command": "rm -rf /tmp/build"},
        }
        event = normalise(payload, "copilot")
        assert event.action.action_type == ActionType.SHELL_COMMAND
        assert event.source.tool == "copilot"


class TestEnrichmentIntegration:
    """Verify normalise() populates enrichment fields."""

    def test_normalise_sets_version(self) -> None:
        payload = {
            "tool_name": "Bash",
            "tool_input": {"command": "echo hello"},
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        assert event.source.version is not None
        assert event.source.version == "0.1.0"

    def test_normalise_sets_hostname(self) -> None:
        payload = {
            "tool_name": "Bash",
            "tool_input": {"command": "echo hello"},
            "hook_event_name": "PreToolUse",
        }
        event = normalise(payload, "claude-code")
        # hostname should be set (or None only if socket.gethostname fails)
        import socket
        try:
            expected = socket.gethostname()
        except OSError:
            expected = None
        assert event.context.hostname == expected


class TestNormaliserErrors:
    """Test error handling."""

    def test_unknown_source_raises(self) -> None:
        with pytest.raises(ValueError, match="No normaliser registered"):
            normalise({}, "unknown-tool")
