"""Vectimus: Deterministic governance for AI coding tools and autonomous agents.

Intercepts agent actions, evaluates them against Cedar policies and returns
allow/deny/escalate decisions before execution.
"""

__version__ = "0.1.0"
