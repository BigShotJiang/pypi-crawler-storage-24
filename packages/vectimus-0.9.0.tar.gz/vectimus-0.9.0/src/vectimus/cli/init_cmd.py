"""``vectimus init`` -- detect installed tools and generate hook configs."""

from __future__ import annotations

import json
import shlex
from pathlib import Path

import click

from vectimus.cli.detect import ToolName, detect_all
from vectimus.core.config import VectimusConfig
from vectimus.core.loader import PolicyLoader

# Maps tool names to display labels and configure functions.
_TOOL_CONFIG: dict[ToolName, tuple[str, str]] = {
    ToolName.CLAUDE_CODE: ("Claude Code", "_configure_claude_code"),
    ToolName.CURSOR: ("Cursor", "_configure_cursor"),
    ToolName.COPILOT: ("VS Code / Copilot", "_configure_copilot"),
}


@click.command("init")
@click.option(
    "--server-url",
    default=None,
    help="Vectimus server URL.  Omit for local-only mode.",
)
@click.option(
    "--policy-dir",
    default=None,
    help="Directory containing Cedar policies.  Defaults to built-in policies.",
)
def init_cmd(server_url: str | None, policy_dir: str | None) -> None:
    """Detect installed AI tools and generate Vectimus hook configurations."""
    click.echo("Vectimus init\n")

    configure_fns = {
        ToolName.CLAUDE_CODE: _configure_claude_code,
        ToolName.CURSOR: _configure_cursor,
        ToolName.COPILOT: _configure_copilot,
    }

    # Prompt for API key when using server mode.
    api_key: str | None = None
    if server_url:
        api_key = click.prompt(
            "API key",
            hide_input=True,
            default="",
            show_default=False,
        ) or None

    report = detect_all()
    tools_configured: list[str] = []

    click.echo("Tool detection:")
    for tool_name in ToolName:
        display_name = _TOOL_CONFIG[tool_name][0]
        result = report.results.get(tool_name)

        if result and result.found:
            configure_fns[tool_name](server_url, api_key)
            tools_configured.append(tool_name.value)
            method_label = f"({result.method.value})" if result.method else ""
            click.echo(f"  [+] {display_name:<18} {method_label:<8} hook config written")
            if result.executable_path:
                click.echo(f"      {result.executable_path}")
            if tool_name == ToolName.COPILOT and result.has_copilot_extension:
                click.echo("      Copilot extension detected")
        else:
            click.echo(f"  [ ] {display_name:<18} not found")

    if not tools_configured:
        click.echo("\n  No supported tools detected.")
        click.echo("  You can configure hooks manually for your tool.")

    # -- Create config file -------------------------------------------------
    config = VectimusConfig.create_default()
    click.echo(f"\n  Config: {config.path}")

    # Ensure the projects directory exists for per-project overrides.
    projects_dir = Path.home() / ".vectimus" / "projects"
    projects_dir.mkdir(parents=True, exist_ok=True)

    # -- Show pack summary --------------------------------------------------
    dirs = [policy_dir] if policy_dir else None
    loader = PolicyLoader(policy_dirs=dirs, config_path=str(config.path))
    packs = loader.list_packs()

    if packs:
        click.echo("\nPolicy packs:")
        for p in packs:
            status = "enabled" if p["enabled"] else "disabled"
            click.echo(f"  [{'+' if p['enabled'] else ' '}] {p['name']:<20} "
                        f"v{p['version']}  {p['rule_count']} rules  ({status})")

    click.echo(f"\nConfigured {len(tools_configured)} tool(s).")
    if server_url:
        click.echo(f"Server URL: {server_url}")
    else:
        click.echo("Mode: local-only (no server)")

    if policy_dir:
        click.echo(f"Policy directory: {policy_dir}")
    else:
        click.echo("Policies: built-in defaults")

    if api_key:
        click.echo(
            "\nWarning: Hook config files contain your API key.\n"
            "Add them to .gitignore to avoid committing secrets."
        )


def _is_vectimus_hook(hook: dict) -> bool:
    """Check if a hook entry was created by Vectimus."""
    if hook.get("type") == "command":
        return "vectimus" in hook.get("command", "")
    if hook.get("type") == "http":
        return "vectimus" in hook.get("url", "").lower()
    return False


def _configure_claude_code(server_url: str | None, api_key: str | None = None) -> None:
    """Write .claude/settings.json with Vectimus hooks, preserving existing hooks."""
    config_dir = Path(".claude")
    config_dir.mkdir(exist_ok=True)
    settings_path = config_dir / "settings.json"

    if server_url:
        headers: dict[str, str] = {"X-Vectimus-Source": "claude-code"}
        if api_key:
            headers["X-Vectimus-API-Key"] = api_key
        vectimus_hook = {
            "type": "http",
            "url": f"{server_url.rstrip('/')}/evaluate",
            "timeout": 10,
            "headers": headers,
        }
    else:
        vectimus_hook = {
            "type": "command",
            "command": "python -m vectimus.shims.claude_code",
        }

    settings: dict = {}
    if settings_path.exists():
        try:
            settings = json.loads(settings_path.read_text())
        except json.JSONDecodeError:
            pass

    settings.setdefault("hooks", {})
    existing_entries: list[dict] = settings["hooks"].get("PreToolUse", [])

    # Merge: remove any previous Vectimus hooks, then prepend ours.
    merged: list[dict] = []
    merged.append({"matcher": "", "hooks": [vectimus_hook]})
    for entry in existing_entries:
        hooks_list = entry.get("hooks", [])
        non_vectimus = [h for h in hooks_list if not _is_vectimus_hook(h)]
        if non_vectimus:
            merged.append({**entry, "hooks": non_vectimus})

    settings["hooks"]["PreToolUse"] = merged

    try:
        settings_path.write_text(json.dumps(settings, indent=2) + "\n")
    except OSError as exc:
        click.echo(f"  Error writing {settings_path}: {exc}", err=True)
        raise SystemExit(1)


def _configure_cursor(server_url: str | None, api_key: str | None = None) -> None:
    """Write .cursor/hooks.json with Vectimus hooks, preserving existing hooks."""
    config_dir = Path(".cursor")
    config_dir.mkdir(exist_ok=True)
    hooks_path = config_dir / "hooks.json"

    if server_url:
        url = f"{server_url.rstrip('/')}/evaluate"
        key_header = f" -H 'X-Vectimus-API-Key: {api_key}'" if api_key else ""
        command = (
            f"curl -s -X POST -H 'Content-Type: application/json'"
            f" -H 'X-Vectimus-Source: cursor'{key_header} -d @- {shlex.quote(url)}"
        )
    else:
        command = "python -m vectimus.shims.cursor"

    existing: dict = {}
    if hooks_path.exists():
        try:
            existing = json.loads(hooks_path.read_text())
        except json.JSONDecodeError:
            pass

    # Merge: set the Vectimus hook, preserve other hook types.
    existing["beforeShellExecution"] = {"command": command}

    try:
        hooks_path.write_text(json.dumps(existing, indent=2) + "\n")
    except OSError as exc:
        click.echo(f"  Error writing {hooks_path}: {exc}", err=True)
        raise SystemExit(1)


def _configure_copilot(server_url: str | None, api_key: str | None = None) -> None:
    """Write .github/hooks/ config for Copilot / VS Code, preserving existing hooks."""
    config_dir = Path(".github") / "hooks"
    config_dir.mkdir(parents=True, exist_ok=True)
    hook_path = config_dir / "vectimus.json"

    if server_url:
        url = f"{server_url.rstrip('/')}/evaluate"
        key_header = f" -H 'X-Vectimus-API-Key: {api_key}'" if api_key else ""
        command = (
            f"curl -s -X POST -H 'Content-Type: application/json'"
            f" -H 'X-Vectimus-Source: copilot'{key_header} -d @- {shlex.quote(url)}"
        )
    else:
        command = "python -m vectimus.shims.copilot"

    existing: dict = {}
    if hook_path.exists():
        try:
            existing = json.loads(hook_path.read_text())
        except json.JSONDecodeError:
            pass

    # Merge: set the Vectimus hook, preserve other hook types.
    existing["PreToolUse"] = {"command": command}

    try:
        hook_path.write_text(json.dumps(existing, indent=2) + "\n")
    except OSError as exc:
        click.echo(f"  Error writing {hook_path}: {exc}", err=True)
        raise SystemExit(1)
