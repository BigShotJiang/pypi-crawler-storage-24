#!/usr/bin/env python3
"""Vectimus command hook for Cursor.

Reads Cursor hook JSON from stdin, normalises and evaluates it.
Returns decision via exit code (0=allow, 2=deny) and stdout JSON.
"""

from __future__ import annotations

import json
import os
import sys

from vectimus.core.evaluator import PolicyEngine
from vectimus.core.loader import PolicyLoader
from vectimus.core.models import DecisionVerdict
from vectimus.core.normaliser import normalise


def _log_stderr(msg: str) -> None:
    """Write diagnostic message to stderr (not visible to agent)."""
    print(f"vectimus: {msg}", file=sys.stderr)


def _post_to_server(payload: dict, server_url: str) -> dict | None:
    """POST to the Vectimus server.  Returns response dict or None."""
    try:
        import urllib.request

        timeout = int(os.environ.get("VECTIMUS_TIMEOUT", "5"))
        url = server_url.rstrip("/") + "/evaluate"
        data = json.dumps(payload).encode()
        headers = {
            "Content-Type": "application/json",
            "X-Vectimus-Source": "cursor",
        }
        api_key = os.environ.get("VECTIMUS_API_KEY")
        if api_key:
            headers["X-Vectimus-API-Key"] = api_key
        req = urllib.request.Request(
            url,
            data=data,
            headers=headers,
        )
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return json.loads(resp.read())
    except Exception:
        _log_stderr(f"Server unreachable ({server_url}), falling back to local evaluation")
        return None


def run() -> None:
    """Entry point for the Cursor command hook."""
    raw = sys.stdin.read()
    if not raw.strip():
        sys.exit(0)

    try:
        payload = json.loads(raw)
    except json.JSONDecodeError:
        sys.exit(0)

    # Try server
    server_url = os.environ.get("VECTIMUS_SERVER_URL")
    if server_url:
        result = _post_to_server(payload, server_url)
        if result is not None:
            if result.get("decision") == DecisionVerdict.DENY:
                print(json.dumps({
                    "decision": "deny",
                    "reason": result.get("reason", "Denied by Vectimus"),
                }))
                sys.exit(2)
            sys.exit(0)

    # Determine project path for per-project overrides.
    from pathlib import Path
    workspace_roots: list[str] = payload.get("workspace_roots", [])
    project_path_str = workspace_roots[0] if workspace_roots else payload.get("cwd") or os.getcwd()
    project_path = Path(project_path_str).resolve()

    # Local evaluation
    try:
        event = normalise(payload, "cursor")
    except Exception as exc:
        _log_stderr(f"Normalisation error: {exc}")
        print(json.dumps({"decision": "deny", "reason": "Normalisation error (fail closed)"}))
        sys.exit(2)

    loader = PolicyLoader(project_path=project_path)
    observe = os.environ.get("VECTIMUS_OBSERVE", "").lower() in ("1", "true", "yes")
    if not observe:
        observe = loader.config.is_observe_mode()
    engine = PolicyEngine(loader=loader, observe=observe)
    decision = engine.evaluate(event)

    if decision.decision == DecisionVerdict.DENY:
        print(json.dumps({
            "decision": "deny",
            "reason": decision.reason or "Denied by Vectimus",
        }))
        for pid in decision.matched_policy_ids:
            _log_stderr(f"To disable for this project: vectimus rule disable {pid}")
            _log_stderr(f"To disable everywhere: vectimus rule disable {pid} --global")
        sys.exit(2)

    sys.exit(0)


if __name__ == "__main__":
    run()
