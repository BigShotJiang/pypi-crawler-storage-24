"""Hook shims that adapt tool-specific protocols to Vectimus evaluation."""
