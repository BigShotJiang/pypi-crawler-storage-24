"""Tool-agnostic event normalisation.

Translates tool-specific JSON payloads (Claude Code, Cursor, Copilot) into
canonical VectimusEvent objects.  New tools are added by registering a
normaliser function with the @register decorator.
"""

from __future__ import annotations

import uuid
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from vectimus.core.enrichment import enrich
from vectimus.core.models import (
    ActionInfo,
    ActionType,
    ContextInfo,
    EventType,
    IdentityInfo,
    SourceInfo,
    VectimusEvent,
)

# ---------------------------------------------------------------------------
# Tool name -> action type mappings
# ---------------------------------------------------------------------------

CLAUDE_CODE_TOOL_MAP: dict[str, str] = {
    "Bash": ActionType.SHELL_COMMAND,
    "Write": ActionType.FILE_WRITE,
    "Edit": ActionType.FILE_WRITE,
    "MultiEdit": ActionType.FILE_WRITE,
    "Read": ActionType.FILE_READ,
    "Grep": ActionType.FILE_READ,
    "Glob": ActionType.FILE_READ,
    "WebFetch": ActionType.WEB_REQUEST,
    "WebSearch": ActionType.WEB_REQUEST,
    "Task": ActionType.AGENT_SPAWN,
    "Agent": ActionType.AGENT_SPAWN,
    "TeamCreate": ActionType.AGENT_SPAWN,
    "SendMessage": ActionType.AGENT_MESSAGE,
}

CURSOR_EVENT_MAP: dict[str, str] = {
    "beforeShellExecution": ActionType.SHELL_COMMAND,
    "beforeMCPExecution": ActionType.MCP_TOOL,
    "beforeReadFile": ActionType.FILE_READ,
    "afterFileEdit": ActionType.FILE_WRITE,
}

# Patterns that refine a shell_command into a more specific action type.
_INFRA_PREFIXES = ("terraform", "kubectl", "docker", "aws", "gcloud", "az")
_PKG_PREFIXES = ("npm", "pip", "cargo", "yarn", "pnpm", "bun")
_GIT_PREFIX = "git"


def _refine_shell_action(command: str) -> str:
    """Detect infrastructure, package and git commands inside shell invocations."""
    stripped = command.strip()
    # Handle sudo prefix
    if stripped.startswith("sudo "):
        stripped = stripped[5:].strip()

    first_word = stripped.split()[0] if stripped.split() else ""

    if first_word in _INFRA_PREFIXES or first_word.startswith("kubectl"):
        return ActionType.INFRASTRUCTURE
    if first_word in _PKG_PREFIXES:
        return ActionType.PACKAGE_OPERATION
    if first_word == _GIT_PREFIX:
        return ActionType.GIT_OPERATION
    return ActionType.SHELL_COMMAND


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

NormaliserFn = Callable[[dict[str, Any]], VectimusEvent]
_REGISTRY: dict[str, NormaliserFn] = {}


def register(source_tool: str) -> Callable[[NormaliserFn], NormaliserFn]:
    """Decorator to register a normaliser function for a source tool."""

    def wrapper(fn: NormaliserFn) -> NormaliserFn:
        _REGISTRY[source_tool] = fn
        return fn

    return wrapper


def normalise(raw_payload: dict[str, Any], source_tool: str) -> VectimusEvent:
    """Normalise a raw tool payload into a VectimusEvent.

    Looks up the registered normaliser for *source_tool* and delegates to it.
    Raises ValueError if no normaliser is registered.
    """
    fn = _REGISTRY.get(source_tool)
    if fn is None:
        raise ValueError(
            f"No normaliser registered for source tool '{source_tool}'.  "
            f"Registered tools: {sorted(_REGISTRY)}"
        )
    event = fn(raw_payload)
    return enrich(event)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _extract_command(tool_input: dict[str, Any]) -> str | None:
    """Pull a command string from tool_input if present."""
    return tool_input.get("command") or tool_input.get("cmd")


def _extract_file_path(tool_input: dict[str, Any]) -> str | None:
    return (
        tool_input.get("file_path")
        or tool_input.get("path")
        or tool_input.get("filePath")
    )


def _extract_url(tool_input: dict[str, Any]) -> str | None:
    return tool_input.get("url") or tool_input.get("uri")


def _hook_event_to_event_type(hook_event: str) -> str:
    """Map hook event names to pre/post action."""
    lower = hook_event.lower()
    if "post" in lower or "after" in lower:
        return EventType.POST_ACTION
    return EventType.PRE_ACTION


_EXCESSIVE_TURNS_THRESHOLD = 50


def _build_agent_spawn_command(tool_name: str, tool_input: dict[str, Any]) -> str:
    """Build a synthetic command string from Agent/TeamCreate tool parameters.

    The resulting string is designed for Cedar ``like`` pattern matching,
    not for human readability.  Field order is deterministic so that policies
    can rely on combined patterns (e.g. ``*background=true*``).
    """
    if tool_name == "TeamCreate":
        parts = ["team_create"]
        if team_name := tool_input.get("team_name"):
            parts.append(f"team_name={team_name}")
        return " ".join(parts)

    parts = ["spawn"]
    if subagent_type := tool_input.get("subagent_type"):
        parts.append(f"subagent_type={subagent_type}")
    if mode := tool_input.get("mode"):
        parts.append(f"mode={mode}")
    max_turns = tool_input.get("max_turns")
    if max_turns is not None:
        parts.append(f"max_turns={max_turns}")
        try:
            if int(max_turns) > _EXCESSIVE_TURNS_THRESHOLD:
                parts.append("EXCESSIVE_TURNS")
        except (TypeError, ValueError):
            pass
    if tool_input.get("run_in_background"):
        parts.append("background=true")
    if name := tool_input.get("name"):
        parts.append(f"name={name}")
    return " ".join(parts)


def _build_agent_message_command(tool_input: dict[str, Any]) -> str:
    """Build a synthetic command string from SendMessage tool parameters."""
    parts = ["message"]
    if msg_type := tool_input.get("type"):
        parts.append(f"type={msg_type}")
    if recipient := tool_input.get("recipient"):
        parts.append(f"recipient={recipient}")
    return " ".join(parts)


# ---------------------------------------------------------------------------
# Claude Code normaliser
# ---------------------------------------------------------------------------

@register("claude-code")
def _normalise_claude_code(payload: dict[str, Any]) -> VectimusEvent:
    """Normalise a Claude Code hook payload."""
    tool_name: str = payload.get("tool_name", "unknown")
    tool_input: dict[str, Any] = payload.get("tool_input", {})
    hook_event: str = payload.get("hook_event_name", "PreToolUse")

    # Determine action type
    if tool_name.startswith("mcp__"):
        action_type = ActionType.MCP_TOOL
    else:
        action_type = CLAUDE_CODE_TOOL_MAP.get(tool_name, ActionType.SHELL_COMMAND)

    command = _extract_command(tool_input)

    # Build synthetic commands for agent operations
    if action_type == ActionType.AGENT_SPAWN and tool_name in ("Agent", "TeamCreate"):
        command = _build_agent_spawn_command(tool_name, tool_input)
    elif action_type == ActionType.AGENT_MESSAGE:
        command = _build_agent_message_command(tool_input)

    # Refine shell commands
    if action_type == ActionType.SHELL_COMMAND and command:
        action_type = _refine_shell_action(command)

    # MCP fields
    mcp_server: str | None = None
    mcp_tool: str | None = None
    if tool_name.startswith("mcp__"):
        parts = tool_name.split("__", 2)
        if len(parts) >= 3:
            mcp_server = parts[1]
            mcp_tool = parts[2]
        elif len(parts) == 2:
            mcp_server = parts[1]

    return VectimusEvent(
        event_id=payload.get("tool_use_id", str(uuid.uuid4())),
        timestamp=_now_iso(),
        event_type=_hook_event_to_event_type(hook_event),
        source=SourceInfo(
            tool="claude-code",
            session_id=payload.get("session_id"),
        ),
        identity=IdentityInfo(
            principal=payload.get("principal", "unknown"),
        ),
        action=ActionInfo(
            action_type=action_type,
            raw_tool_name=tool_name,
            command=command,
            file_path=_extract_file_path(tool_input),
            url=_extract_url(tool_input),
            mcp_server=mcp_server,
            mcp_tool=mcp_tool,
            raw_input=tool_input,
        ),
        context=ContextInfo(
            cwd=payload.get("cwd"),
        ),
    )


# ---------------------------------------------------------------------------
# Cursor normaliser
# ---------------------------------------------------------------------------

@register("cursor")
def _normalise_cursor(payload: dict[str, Any]) -> VectimusEvent:
    """Normalise a Cursor hook payload."""
    hook_event: str = payload.get("hook_event_name", "beforeShellExecution")
    action_type = CURSOR_EVENT_MAP.get(hook_event, ActionType.SHELL_COMMAND)

    command = payload.get("command")
    if action_type == ActionType.SHELL_COMMAND and command:
        action_type = _refine_shell_action(command)

    cwd = payload.get("cwd")
    workspace_roots: list[str] = payload.get("workspace_roots", [])
    repository = workspace_roots[0] if workspace_roots else None

    return VectimusEvent(
        event_id=payload.get("generation_id", str(uuid.uuid4())),
        timestamp=_now_iso(),
        event_type=_hook_event_to_event_type(hook_event),
        source=SourceInfo(
            tool="cursor",
            session_id=payload.get("conversation_id"),
        ),
        identity=IdentityInfo(
            principal=payload.get("principal", "unknown"),
        ),
        action=ActionInfo(
            action_type=action_type,
            raw_tool_name=hook_event,
            command=command,
            file_path=payload.get("file_path"),
            raw_input=payload,
        ),
        context=ContextInfo(
            cwd=cwd,
            repository=repository,
        ),
    )


# ---------------------------------------------------------------------------
# Copilot / VS Code normaliser
# ---------------------------------------------------------------------------

@register("copilot")
def _normalise_copilot(payload: dict[str, Any]) -> VectimusEvent:
    """Normalise a GitHub Copilot / VS Code hook payload."""
    tool_name: str = payload.get("tool_name", "unknown")
    tool_input: dict[str, Any] = payload.get("tool_input", {})
    hook_event: str = payload.get("hookEventName", "PreToolUse")

    if tool_name.startswith("mcp__"):
        action_type = ActionType.MCP_TOOL
    else:
        action_type = CLAUDE_CODE_TOOL_MAP.get(tool_name, ActionType.SHELL_COMMAND)

    command = _extract_command(tool_input)
    if action_type == ActionType.SHELL_COMMAND and command:
        action_type = _refine_shell_action(command)

    timestamp = payload.get("timestamp", _now_iso())

    return VectimusEvent(
        event_id=str(uuid.uuid4()),
        timestamp=timestamp,
        event_type=_hook_event_to_event_type(hook_event),
        source=SourceInfo(
            tool="copilot",
            session_id=payload.get("sessionId"),
        ),
        identity=IdentityInfo(
            principal=payload.get("principal", "unknown"),
        ),
        action=ActionInfo(
            action_type=action_type,
            raw_tool_name=tool_name,
            command=command,
            file_path=_extract_file_path(tool_input),
            url=_extract_url(tool_input),
            raw_input=tool_input,
        ),
        context=ContextInfo(
            cwd=payload.get("cwd"),
        ),
    )
