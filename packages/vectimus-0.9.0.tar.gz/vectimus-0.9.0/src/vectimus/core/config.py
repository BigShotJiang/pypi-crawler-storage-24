"""Manages ~/.vectimus/config.toml read and write operations.

Handles pack enable/disable and rule enable/disable state.  Writes are
atomic (write to temp file then rename) to prevent corruption if the
process is interrupted.
"""

from __future__ import annotations

import os
import tempfile
import tomllib
from pathlib import Path

import structlog
import tomli_w

logger = structlog.get_logger(__name__)


def _default_config_path() -> Path:
    """Return the default config file path."""
    return Path.home() / ".vectimus" / "config.toml"



def project_slug(path: Path) -> str:
    """Convert an absolute project path to a filename-safe slug.

    Replaces path separators with hyphens, removes leading separators,
    lowercases everything and handles Windows drive letters.

    Examples:
        /home/joe/infrastructure -> home-joe-infrastructure
        /Users/joe/projects/my-app -> users-joe-projects-my-app
        C:\\Users\\joe\\app -> c-users-joe-app
    """
    resolved = str(path.resolve())
    # Normalise Windows drive letters (C: -> c).
    if len(resolved) >= 2 and resolved[1] == ":":
        resolved = resolved[0].lower() + resolved[2:]
    # Replace all separators with hyphens.
    slug = resolved.replace("\\", "-").replace("/", "-")
    # Strip leading hyphens.
    slug = slug.lstrip("-")
    return slug.lower()


class VectimusConfig:
    """Manages ~/.vectimus/config.toml read and write operations."""

    def __init__(self, config_path: str | None = None) -> None:
        """Load config from *config_path*.  Defaults to ~/.vectimus/config.toml."""
        self._path = Path(config_path) if config_path else _default_config_path()
        self._data: dict = {}
        self._load()

    @property
    def path(self) -> Path:
        """Return the config file path."""
        return self._path

    @property
    def data(self) -> dict:
        """Return the raw config data."""
        return self._data

    # -- Pack management ----------------------------------------------------

    def is_pack_enabled(self, pack_name: str) -> bool:
        """Check if a pack is enabled.  Default is True if not mentioned."""
        packs = self._data.get("packs", {})
        pack_cfg = packs.get(pack_name, {})
        if isinstance(pack_cfg, dict):
            return pack_cfg.get("enabled", True)
        return True

    def set_pack_enabled(self, pack_name: str, enabled: bool) -> None:
        """Update pack status in config and write to disk."""
        self._data.setdefault("packs", {})
        self._data["packs"][pack_name] = {"enabled": enabled}
        self._write()

    # -- Rule management ----------------------------------------------------

    def is_rule_disabled(
        self, rule_id: str, project_path: Path | None = None
    ) -> bool:
        """Check if a specific rule is disabled globally or for the project."""
        rules = self._data.get("rules", {})
        disabled = rules.get("disabled", [])
        if rule_id in disabled:
            return True
        if project_path is not None:
            return rule_id in self.load_project_overrides(project_path)
        return False

    def disabled_rules(self) -> list[str]:
        """Return the list of disabled rule IDs."""
        rules = self._data.get("rules", {})
        return list(rules.get("disabled", []))

    def disable_rule(self, rule_id: str) -> None:
        """Add rule to disabled list and write to disk."""
        self._data.setdefault("rules", {})
        disabled = self._data["rules"].setdefault("disabled", [])
        if rule_id not in disabled:
            disabled.append(rule_id)
        self._write()

    def enable_rule(self, rule_id: str) -> None:
        """Remove rule from disabled list and write to disk."""
        rules = self._data.get("rules", {})
        disabled = rules.get("disabled", [])
        if rule_id in disabled:
            disabled.remove(rule_id)
            self._data["rules"]["disabled"] = disabled
            self._write()

    # -- Per-project overrides ----------------------------------------------

    def project_config_path(self, project_path: Path) -> Path:
        """Return the path to the project-specific override file."""
        slug = project_slug(project_path)
        return self._path.parent / "projects" / f"{slug}.toml"

    def load_project_overrides(self, project_path: Path) -> set[str]:
        """Load disabled rule IDs from the project override file.

        Returns empty set if no project override exists.
        """
        override_path = self.project_config_path(project_path)
        if not override_path.exists():
            return set()
        try:
            with open(override_path, "rb") as f:
                data = tomllib.load(f)
        except tomllib.TOMLDecodeError as exc:
            logger.warning(
                "project_override_parse_error",
                path=str(override_path),
                error=str(exc),
            )
            return set()
        return set(data.get("rules", {}).get("disabled", []))

    def effective_disabled_rules(
        self, project_path: Path | None = None
    ) -> set[str]:
        """Return the union of globally disabled rules and project-specific disabled rules."""
        global_disabled = set(self.disabled_rules())
        if project_path is None:
            return global_disabled
        project_disabled = self.load_project_overrides(project_path)
        return global_disabled | project_disabled

    def disable_rule_for_project(
        self, rule_id: str, project_path: Path
    ) -> None:
        """Add a rule to the project-specific disabled list.

        Creates the override file if it does not exist.
        """
        override_path = self.project_config_path(project_path)
        override_path.parent.mkdir(parents=True, exist_ok=True)

        data: dict = {}
        if override_path.exists():
            try:
                with open(override_path, "rb") as f:
                    data = tomllib.load(f)
            except tomllib.TOMLDecodeError:
                data = {}

        data.setdefault("project", {})["path"] = str(project_path.resolve())
        data.setdefault("rules", {})
        disabled = data["rules"].setdefault("disabled", [])
        if rule_id not in disabled:
            disabled.append(rule_id)

        self._write_to_path(override_path, data)

    def enable_rule_for_project(
        self, rule_id: str, project_path: Path
    ) -> None:
        """Remove a rule from the project-specific disabled list."""
        override_path = self.project_config_path(project_path)
        if not override_path.exists():
            return

        try:
            with open(override_path, "rb") as f:
                data = tomllib.load(f)
        except tomllib.TOMLDecodeError:
            return

        disabled = data.get("rules", {}).get("disabled", [])
        if rule_id in disabled:
            disabled.remove(rule_id)
            data["rules"]["disabled"] = disabled
            self._write_to_path(override_path, data)

    def list_project_overrides(self, project_path: Path) -> list[str]:
        """List all disabled rules for a specific project."""
        return sorted(self.load_project_overrides(project_path))

    # -- MCP server allowlist ------------------------------------------------

    def mcp_allowed_servers(self) -> list[str]:
        """Return the list of approved MCP server names.

        Reads from config.toml ``[mcp] allowed_servers``.  Can be extended
        via the ``VECTIMUS_MCP_ALLOWED`` environment variable (comma-separated
        server names).  The env var merges with the config file list.
        """
        from_config = list(self._data.get("mcp", {}).get("allowed_servers", []))
        env_val = os.environ.get("VECTIMUS_MCP_ALLOWED", "").strip()
        if env_val:
            from_env = [s.strip() for s in env_val.split(",") if s.strip()]
            # Merge, preserving order, no duplicates.
            seen = set(from_config)
            for s in from_env:
                if s not in seen:
                    from_config.append(s)
                    seen.add(s)
        return from_config

    def mcp_allow_server(self, server: str) -> None:
        """Add an MCP server to the approved list."""
        self._data.setdefault("mcp", {})
        allowed = self._data["mcp"].setdefault("allowed_servers", [])
        if server not in allowed:
            allowed.append(server)
        self._write()

    def mcp_deny_server(self, server: str) -> None:
        """Remove an MCP server from the approved list."""
        mcp = self._data.get("mcp", {})
        allowed = mcp.get("allowed_servers", [])
        if server in allowed:
            allowed.remove(server)
            self._data["mcp"]["allowed_servers"] = allowed
            self._write()

    # -- Observe mode --------------------------------------------------------

    def is_observe_mode(self) -> bool:
        """Check if observe mode is enabled.  Logs decisions but always allows."""
        return bool(self._data.get("mode", {}).get("observe", False))

    def set_observe_mode(self, enabled: bool) -> None:
        """Enable or disable observe mode and write to disk."""
        self._data.setdefault("mode", {})
        self._data["mode"]["observe"] = enabled
        self._write()

    # -- Identity / logging accessors ---------------------------------------

    def get_identity_resolver(self) -> str:
        """Return the identity resolver setting.  Defaults to 'git'."""
        return self._data.get("identity", {}).get("resolver", "git")

    def get_log_dir(self) -> str:
        """Return the logging directory.  Defaults to ~/.vectimus/logs."""
        default = str(Path.home() / ".vectimus" / "logs")
        return self._data.get("logging", {}).get("dir", default)

    # -- Internal -----------------------------------------------------------

    def _load(self) -> None:
        """Read config from disk if it exists."""
        if self._path.exists():
            try:
                with open(self._path, "rb") as f:
                    self._data = tomllib.load(f)
            except tomllib.TOMLDecodeError as exc:
                logger.warning("config_parse_error", path=str(self._path), error=str(exc))
                self._data = {}
        else:
            self._data = {}

    def _write(self) -> None:
        """Atomically write global config to disk."""
        self._write_to_path(self._path, self._data)

    @staticmethod
    def _write_to_path(path: Path, data: dict) -> None:
        """Atomically write data to a TOML file."""
        path.parent.mkdir(parents=True, exist_ok=True)

        # Write to a temp file in the same directory, then rename.
        fd, tmp_path = tempfile.mkstemp(
            dir=path.parent,
            suffix=".tmp",
        )
        try:
            with os.fdopen(fd, "wb") as f:
                tomli_w.dump(data, f)
            # Atomic rename on POSIX.  On Windows, os.replace is atomic.
            os.replace(tmp_path, path)
        except BaseException:
            # Clean up temp file on failure.
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
            raise

    @classmethod
    def create_default(cls, config_path: str | None = None) -> VectimusConfig:
        """Create a config file with sensible defaults if it does not exist.

        Returns the VectimusConfig instance.
        """
        path = Path(config_path) if config_path else _default_config_path()
        if not path.exists():
            path.parent.mkdir(parents=True, exist_ok=True)
            default_data = {
                "packs": {},
                "rules": {"disabled": []},
                "identity": {
                    "resolver": "git",
                    "default_persona": "default",
                },
                "logging": {
                    "dir": str(Path.home() / ".vectimus" / "logs"),
                },
            }
            fd, tmp_path = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
            try:
                with os.fdopen(fd, "wb") as f:
                    tomli_w.dump(default_data, f)
                os.replace(tmp_path, path)
            except BaseException:
                try:
                    os.unlink(tmp_path)
                except OSError:
                    pass
                raise
        return cls(str(path))
