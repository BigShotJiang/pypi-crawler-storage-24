# Synthetic Policy Testing Plan

## Goal

Runnable test files that exercise the Cedar policy evaluator against every rule without executing dangerous commands. All tests construct synthetic events and assert allow/deny outcomes.

## Test Files

### 1. `test_base_pack.py`

Parametrized pytest cases for all 48 base rules. Each test constructs a synthetic event (tool call + context) and asserts the evaluator returns DENY.

Covers Unix, Windows cmd and PowerShell variants for every rule that has cross-platform patterns.

Structure:
```python
@pytest.mark.parametrize("command,expected_rule", [
    ("rm -rf /", "vectimus-base-001"),
    ("rd /s /q C:\\", "vectimus-base-001"),
    ("Remove-Item -Recurse -Force C:\\", "vectimus-base-001"),
    # ... all 48 rules with all OS variants
])
def test_base_deny(engine, command, expected_rule):
    event = make_event(action="shell_command", command=command)
    result = engine.evaluate(event)
    assert result.decision == "deny"
    assert expected_rule in result.matched_rules
```

### 2. `test_owasp_pack.py`

Same pattern for all 29 OWASP Agentic rules. Organised by ASI category (ASI01-ASI10).

### 3. `test_allow_baseline.py`

Asserts safe commands are ALLOWED. Catches false positives from overly broad patterns.

Example safe commands:
- `ls`, `echo hello`, `pwd`, `whoami`
- `git status`, `git log`, `git stash`
- `npm test`, `npm run build`, `pip install requests`
- `terraform plan`, `kubectl get pods`
- `python script.py`, `node app.js`
- Safe file reads: README.md, src/index.ts, package.json
- Safe file writes: src/new-file.ts, tests/test_foo.py

### 4. `test_cross_platform.py`

Specifically tests that every rule with OS-specific patterns blocks the equivalent command on all three platforms (Linux, macOS, Windows).

Groups tests by rule ID and asserts each platform variant is denied:
```python
CROSS_PLATFORM_CASES = {
    "vectimus-base-001": {
        "unix": "rm -rf /",
        "windows_cmd": "rd /s /q C:\\",
        "powershell": "Remove-Item C:\\ -Recurse -Force",
    },
    "vectimus-base-004": {
        "unix": "chmod -R 777 /",
        "windows_cmd": "icacls C:\\ /grant Everyone:F /T",
        "powershell": "icacls C:\\ /grant Everyone:(OI)(CI)F",
    },
    # ... all rules with platform-specific patterns
}
```

### 5. `test_suggested_alternatives.py`

Validates every rule has a non-empty `@suggested_alternative` annotation in the deny response. Ensures users always get actionable guidance when blocked.

### 6. `test_performance.py`

Benchmarks evaluation latency across all rules. Asserts p99 < 50ms for local evaluation. Runs each rule's test case 100 times and reports timing distribution.

## Where These Live

Options:
- **Main repo `tests/`** alongside existing tests (simpler CI, single test run)
- **Separate `vectimus-test` repo** (keeps main repo lean, useful for external validation)

Decision: TBD

## Existing Coverage

The main repo already has 20 test modules (4,671 lines) covering:
- Policy evaluation, loading, enrichment, normalisation
- CLI commands, config, detection
- Server endpoints, session store, benchmarks
- OWASP policies, new critical policies

The synthetic tests above would complement these by providing exhaustive per-rule coverage with cross-platform variants and false-positive regression testing.

## Priority Order

1. `test_base_pack.py` + `test_owasp_pack.py` (core coverage)
2. `test_allow_baseline.py` (false positive regression)
3. `test_cross_platform.py` (validates the Windows/macOS patterns we just added)
4. `test_suggested_alternatives.py` (quick win)
5. `test_performance.py` (already partially covered by test_benchmark.py)
