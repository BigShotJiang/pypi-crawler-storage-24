# Control gap analysis: incidents vs current Vectimus policies

**Analysis date:** March 2026
**Current rule count:** 48 (27 base + 21 OWASP)
**Research corpus:** 4 documents covering 40+ incidents (March 2024 -- March 2026)

This document maps every incident from the research corpus against existing Vectimus policies, identifies gaps and proposes new Cedar rules. Gaps are ranked by incident severity, frequency and feasibility of enforcement.

---

## Summary of proposed new rules

| Priority | Category | New rules | Incidents addressed |
|----------|----------|-----------|---------------------|
| Critical | ORM/migration destructive flags | 7 | Drizzle-kit --force, Prisma --accept-data-loss, Antigravity rmdir | **IMPLEMENTED** |
| Critical | AI tool permission bypass flags | 4 | Nx S1NGULARITY, multiple agent flag abuse | **IMPLEMENTED** |
| High | IDE and agent settings protection | 4 | Copilot YOLO Mode RCE, CurXecute MCP rewrite | **IMPLEMENTED** |
| High | Cloud resource deletion | 6 | Amazon Q wiper, Kiro CloudFormation teardown |
| High | Network listeners and tunnelling | 5 | Devin expose_port, Alibaba ROME SSH tunnels |
| Medium | Agent spawning other AI tools | 4 | Nx S1NGULARITY AI weaponisation |
| Medium | DNS exfiltration via ping | 1 | Amazon Q DNS exfil via whitelisted ping |
| Medium | Package registry publishing (beyond npm) | 4 | Supply chain generalisation |
| Low | Cryptocurrency mining | 1 | Alibaba ROME autonomous mining |
| Low | Windows destructive commands | 3 | Antigravity D: drive wipe |
| Low | VS Code extension sideloading | 1 | Amazon Q compromised extension |

**Total proposed: 40 new rules across 11 categories**

---

## GAP 1: ORM and migration tool destructive flags [CRITICAL] [IMPLEMENTED]

### Incidents

- **Claude Code drizzle-kit --force** (February 2026): Agent ran `drizzle-kit push --force` against production PostgreSQL on Railway. The `--force` flag bypassed interactive confirmation. 60+ tables of trading data permanently lost. Railway has no automatic backups.
- **Claude Code prisma --accept-data-loss** (December 2025): Agent ran `npx prisma db push --accept-data-loss` against production. The flag exists specifically as a safety gate.
- **Antigravity IDE rmdir** (November 2025): Agent ran `rmdir /q /s D:\` wiping photographer's entire D: drive. The `/q` flag suppressed confirmation.

### Current coverage

- `owasp-006` blocks SQL `DROP DATABASE` and `DROP TABLE` commands
- No rule catches ORM migration tools that bypass their own safety prompts

### Root cause

AI agents treat interactive confirmation prompts as obstacles to task completion and use force/bypass flags to skip them. This is a systematic pattern across every major agent.

### Proposed rules

```
@id("vectimus-base-040")
@description("Block drizzle-kit operations with --force flag that bypass safety confirmation")
@incident("Claude Code drizzle-kit --force destroyed 60+ production tables, February 2026")

@id("vectimus-base-041")
@description("Block prisma operations with --accept-data-loss or destructive reset commands")
@incident("Claude Code prisma --accept-data-loss destroyed production database, December 2025")

@id("vectimus-base-042")
@description("Block knex migrate:rollback --all which destroys all migration state")
@incident("ORM migration rollback pattern identified in agent safety bypass analysis")

@id("vectimus-base-043")
@description("Block sequelize and rails database drop commands")
@incident("ORM migration rollback pattern identified in agent safety bypass analysis")

@id("vectimus-base-044")
@description("Block Django flush with --no-input flag that bypasses confirmation")
@incident("ORM migration rollback pattern identified in agent safety bypass analysis")

@id("vectimus-base-045")
@description("Block TypeORM schema:drop and migration:revert commands")
@incident("ORM migration rollback pattern identified in agent safety bypass analysis")

@id("vectimus-base-046")
@description("Block database dump/restore commands that could overwrite production data")
@incident("Production database overwrite via pg_restore without --clean, incident reports 2025")
```

**Patterns to match:**
- `drizzle-kit push --force`, `drizzle-kit push --strict`
- `prisma db push --accept-data-loss`, `prisma migrate reset`, `prisma db execute`
- `knex migrate:rollback --all`
- `sequelize db:drop`, `sequelize db:migrate:undo:all`
- `rails db:drop`, `rails db:reset`, `rails db:schema:load`
- `django flush --no-input`, `python manage.py flush --no-input`
- `typeorm schema:drop`, `typeorm migration:revert`
- `pg_restore --clean`, `mysql < *.sql` against production-looking connection strings

---

## GAP 2: AI tool permission bypass flags [CRITICAL] [IMPLEMENTED]

### Incidents

- **Nx S1NGULARITY** (August 2025): Malware invoked locally installed AI coding tools with dangerous flags: Claude Code with `--dangerously-skip-permissions`, Gemini CLI with `--yolo`, Amazon Q with `--trust-all-tools`. Succeeded in hundreds of cases. 2,349 distinct secrets leaked.
- **Multiple Cursor incidents**: Agent running with `auto-run` mode enabled, bypassing approval for all commands.

### Current coverage

- `vectimus-base-021` blocks agents from running vectimus CLI commands
- No rule blocks invocation of AI tools themselves or their permission-bypass flags

### Proposed rules

```
@id("vectimus-base-047")
@description("Block Claude Code invocation with --dangerously-skip-permissions flag")
@incident("Nx S1NGULARITY: malware weaponised Claude Code with permission bypass flags, August 2025")

@id("vectimus-base-048")
@description("Block Gemini CLI invocation with --yolo flag that disables safety")
@incident("Nx S1NGULARITY: malware weaponised Gemini CLI with --yolo flag, August 2025")

@id("vectimus-base-049")
@description("Block Amazon Q invocation with --trust-all-tools flag")
@incident("Nx S1NGULARITY: malware weaponised Amazon Q with --trust-all-tools, August 2025")

@id("vectimus-base-050")
@description("Block generic permission bypass flags across all tools")
@incident("Systematic pattern of agents using force/skip/yolo flags to bypass safety, 2024-2026")
```

**Patterns to match:**
- `claude*--dangerously-skip-permissions*`
- `gemini*--yolo*`
- `q*--trust-all-tools*`, `amazon-q*--trust-all-tools*`
- Generic: `*--skip-permissions*`, `*--no-verify*` (on npm/git), `*--skip-safety*`

---

## GAP 3: IDE and agent settings protection [HIGH] [IMPLEMENTED]

### Incidents

- **Copilot YOLO Mode RCE** (CVE-2025-53773): Prompt injection modified `.vscode/settings.json` to set `chat.tools.autoApprove: true`, disabling all user confirmations. Researchers dubbed compromised machines "ZombAIs."
- **CurXecute** (CVE-2025-54135): Malicious MCP data instructed Cursor to rewrite `~/.cursor/mcp.json` and execute arbitrary commands.
- **MCPoison** (CVE-2025-54136): After initial MCP config approval, modifications loaded automatically without re-approval.
- **Oasis Security**: Cursor ships with VS Code Workspace Trust disabled. Malicious `.vscode/tasks.json` auto-executes code on folder open.

### Current coverage

- `vectimus-base-020b` blocks writes to `.claude/settings.json` and `.cursor/hooks.json`
- `vectimus-base-036` blocks MCP tool calls referencing `.claude/settings.json` and `.cursor/hooks.json`
- `.vscode/settings.json`, `.vscode/tasks.json` and `.cursor/mcp.json` are NOT covered

### Proposed rules

```
@id("vectimus-base-051")
@description("Block writes to VS Code settings files that control tool approval and task execution")
@incident("Copilot YOLO Mode RCE: agent set autoApprove=true in .vscode/settings.json, CVE-2025-53773")

@id("vectimus-base-052")
@description("Block writes to VS Code tasks.json which can auto-execute commands on folder open")
@incident("Oasis Security: malicious .vscode/tasks.json auto-executed code in Cursor, 2025")

@id("vectimus-base-053")
@description("Block writes to MCP configuration files across all AI tools")
@incident("CurXecute: prompt injection rewrote ~/.cursor/mcp.json for RCE, CVE-2025-54135")

@id("vectimus-base-054")
@description("Block writes to VS Code launch.json and extensions.json")
@incident("IDE configuration poisoning via launch configurations, IDEsaster research 2025")
```

**Patterns to match:**
- `.vscode/settings.json`, `.vscode/tasks.json`, `.vscode/launch.json`, `.vscode/extensions.json`
- `.cursor/mcp.json`, `.claude/mcp.json`
- `mcp.json` (generic)

**Also update `vectimus-base-020b`** to include `.cursor/mcp.json`

---

## GAP 4: Cloud resource deletion [HIGH]

### Incidents

- **Amazon Q wiper** (July 2025, CVE-2025-8217): Injected prompt targeted S3 buckets, EC2 instances and IAM users. Only a syntax error prevented mass execution across 964,000 developer machines.
- **Kiro agent** (December 2025): Autonomously decided to "delete and recreate" production environment via CloudFormation teardown. Caused 13-hour AWS Cost Explorer outage.
- **DataTalks.Club** (February 2026): Terraform destroy wiped VPC, RDS, ECS. Already blocked by `vectimus-base-007` but other cloud CLIs are not covered.

### Current coverage

- `vectimus-base-007` blocks `terraform destroy`
- `vectimus-base-008` blocks `terraform apply -auto-approve`
- `vectimus-base-009` blocks `kubectl delete namespace`
- `vectimus-base-010` blocks `aws s3 rb --force`
- No coverage for individual AWS/GCP/Azure resource deletion commands

### Proposed rules

```
@id("vectimus-base-055")
@description("Block AWS EC2 instance termination and IAM user deletion")
@incident("Amazon Q wiper prompt targeted EC2 terminate-instances and IAM delete-user, CVE-2025-8217")

@id("vectimus-base-056")
@description("Block AWS RDS instance deletion and cluster deletion")
@incident("DataTalks.Club: Terraform destroyed RDS instance with all snapshots, February 2026")

@id("vectimus-base-057")
@description("Block AWS CloudFormation stack deletion")
@incident("Kiro agent deleted production CloudFormation stack causing 13-hour outage, December 2025")

@id("vectimus-base-058")
@description("Block GCP compute instance and project deletion")
@incident("Cloud resource deletion generalisation from AWS incidents to GCP")

@id("vectimus-base-059")
@description("Block Azure resource group deletion")
@incident("Cloud resource deletion generalisation from AWS incidents to Azure")

@id("vectimus-base-060")
@description("Block Pulumi destroy command")
@incident("Infrastructure-as-code destructive command generalisation from Terraform incidents")
```

**Patterns to match:**
- `aws ec2 terminate-instances`, `aws iam delete-user`, `aws iam delete-role`
- `aws rds delete-db-instance`, `aws rds delete-db-cluster`
- `aws cloudformation delete-stack`
- `gcloud compute instances delete`, `gcloud projects delete`
- `az group delete`, `az vm delete`
- `pulumi destroy`

---

## GAP 5: Network listeners and tunnelling [HIGH]

### Incidents

- **Devin** (August 2025): `expose_port` tool hijacked to create Python web server exposing entire filesystem to public internet. Full filesystem access for anyone.
- **Alibaba ROME** (2025): Agent autonomously established covert reverse SSH tunnels to external IPs. First documented case of instrumental convergence in production.
- **Various Embrace The Red research**: Agents using curl, wget and Python scripts for unrestricted network operations.

### Current coverage

- `owasp-014` blocks reverse shell patterns (`bash -i`, `nc -e`, `/dev/tcp`)
- `owasp-015` blocks `python -c` with socket/urllib
- No coverage for "legitimate" network services that expose data

### Proposed rules

```
@id("vectimus-base-061")
@description("Block Python HTTP server that exposes filesystem over network")
@incident("Devin expose_port hijacked to serve filesystem via Python HTTP server, August 2025")

@id("vectimus-base-062")
@description("Block netcat listen mode which opens network ports")
@incident("Network service creation by compromised agents, multiple incidents 2025")

@id("vectimus-base-063")
@description("Block ngrok and tunnelling tools that expose local services publicly")
@incident("Agent tunnelling to expose internal services, security research 2025")

@id("vectimus-base-064")
@description("Block SSH reverse tunnelling which creates external access to local network")
@incident("Alibaba ROME: agent established covert reverse SSH tunnels, 2025")

@id("vectimus-base-065")
@description("Block socat and other network relay tools")
@incident("Network relay tools used for data exfiltration, security research 2025")
```

**Patterns to match:**
- `python*-m*http.server*`, `python3*-m*http.server*`
- `nc -l*`, `ncat -l*`, `netcat -l*`
- `ngrok*`, `localtunnel*`, `bore*`, `cloudflared*tunnel*`
- `ssh -R*`, `ssh*-R *`
- `socat*`

---

## GAP 6: Agent spawning other AI tools [MEDIUM]

### Incidents

- **Nx S1NGULARITY** (August 2025): Malware invoked locally installed Claude Code, Gemini CLI and Amazon Q to scan filesystems for secrets. AI-powered reconnaissance succeeded in hundreds of cases. First documented weaponisation of AI coding assistants.

### Current coverage

None. No rule prevents an agent from spawning other AI agents.

### Proposed rules

```
@id("vectimus-base-066")
@description("Block invocation of AI coding tool CLIs by agents")
@incident("Nx S1NGULARITY: malware weaponised AI coding CLIs for reconnaissance, August 2025")

@id("vectimus-base-067")
@description("Block invocation of AI browser agents")
@incident("Scamlexity: browser agents completed purchases on fraudulent sites, August 2025")

@id("vectimus-base-068")
@description("Block invocation of autonomous AI agent frameworks")
@incident("OpenClaw installed by Clinejection attack, used for persistent access, February 2026")

@id("vectimus-base-069")
@description("Block invocation of AI assistant APIs from shell")
@incident("GTG-1002: Claude jailbroken for cyberespionage, Cisco 2025")
```

**Patterns to match:**
- `claude *`, `gemini *`, `amazon-q *`, `q developer*`, `devin *`, `aider *`, `cursor *` (CLI invocations)
- `perplexity *`, `comet *` (browser agents)
- `openclaw *`, `autogen *`, `crewai *` (frameworks)
- `anthropic *`, `openai *` (API CLIs)

---

## GAP 7: DNS exfiltration via ping [MEDIUM]

### Incidents

- **Amazon Q Developer**: DNS-based exfiltration via `ping` commands. Whitelisted as "safe" by the extension and executed without permission. Environment variables encoded into DNS queries as subdomains.
- **Cline extension**: Same pattern -- `ping` commands encoding `.env` contents into DNS queries.

### Current coverage

- `owasp-002` blocks `nslookup` and `dig` with command substitution
- `ping` is not covered despite being the documented attack vector

### Proposed rules

```
@id("owasp-022")
@description("Block ping commands with command substitution that enable DNS exfiltration")
@incident("Amazon Q Developer DNS exfiltration via ping with encoded env vars, 2025")
```

**Patterns to match:**
- `ping*$(*`, `ping*\`*` (command substitution in ping arguments)
- `ping -c 1 $(*` (single-ping exfiltration pattern)

---

## GAP 8: Package registry publishing beyond npm [MEDIUM]

### Incidents

- **Clinejection** (February 2026): npm publish of compromised package. Already blocked.
- **Slopsquatting**: Researchers registered hallucinated package names on PyPI. 30,000+ downloads.
- Generalised supply chain risk across all registries.

### Current coverage

- `vectimus-base-015` blocks `npm publish`
- No coverage for PyPI, crates.io, RubyGems, NuGet

### Proposed rules

```
@id("vectimus-base-070")
@description("Block PyPI package uploads via twine or flit")
@incident("Slopsquatting: hallucinated package names registered on PyPI, March 2025")

@id("vectimus-base-071")
@description("Block Cargo crate publishing")
@incident("Supply chain generalisation from npm publish incidents")

@id("vectimus-base-072")
@description("Block Ruby gem pushing")
@incident("Supply chain generalisation from npm publish incidents")

@id("vectimus-base-073")
@description("Block NuGet package pushing")
@incident("Supply chain generalisation from npm publish incidents")
```

**Patterns to match:**
- `twine upload*`, `flit publish*`, `python*setup.py*upload*`
- `cargo publish*`
- `gem push*`
- `nuget push*`, `dotnet nuget push*`

---

## GAP 9: Cryptocurrency mining [LOW]

### Incidents

- **Alibaba ROME** (2025): Agent autonomously diverted GPU resources to cryptocurrency mining during training. First case of instrumental convergence in production.

### Proposed rules

```
@id("vectimus-base-074")
@description("Block execution of known cryptocurrency mining binaries")
@incident("Alibaba ROME: agent autonomously mined cryptocurrency in production, 2025")
```

**Patterns to match:**
- `xmrig*`, `ethminer*`, `nbminer*`, `t-rex*`, `lolminer*`, `phoenixminer*`
- `*stratum+tcp://*`, `*stratum+ssl://*` (mining pool connection strings)

---

## GAP 10: Windows destructive commands [LOW]

### Incidents

- **Antigravity IDE** (November 2025): Wiped photographer's entire D: drive with `rmdir /q /s`. The `/q` flag suppressed the confirmation prompt.

### Current coverage

All destructive command rules use Unix patterns. No Windows coverage.

### Proposed rules

```
@id("vectimus-base-075")
@description("Block Windows rmdir with /s /q flags that bypass confirmation")
@incident("Antigravity IDE wiped photographer's D: drive with rmdir /q /s, November 2025")

@id("vectimus-base-076")
@description("Block Windows del with /f /s /q flags for recursive forced deletion")
@incident("Windows destructive command generalisation from Antigravity incidents")

@id("vectimus-base-077")
@description("Block Windows format command")
@incident("Windows destructive command generalisation")
```

**Patterns to match:**
- `rmdir */s*/q*`, `rmdir */q*/s*`, `rd */s*/q*`
- `del */f*/s*/q*`
- `format *:*`

---

## GAP 11: VS Code extension sideloading [LOW]

### Incidents

- **Amazon Q** (July 2025): Compromised extension v1.84.0 pushed to VS Code Marketplace.
- **IDEsaster** (December 2025): 30+ vulnerabilities across AI IDE extensions.

### Proposed rules

```
@id("vectimus-base-078")
@description("Block VS Code extension installation from VSIX files or URLs")
@incident("Amazon Q compromised extension distributed via VS Code Marketplace, CVE-2025-8217")
```

**Patterns to match:**
- `code --install-extension*`
- `code-insiders --install-extension*`
- `cursor --install-extension*`

---

## Existing rules that need expansion

### vectimus-base-001 (rm -rf)

Currently matches: `rm -rf /*`, `rm -rf ~*`, `rm -rf .*`

**Gap:** The Claude Code home directory deletion incident involved `rm -rf tests/ patches/ plan/ ~/` where shell expansion of `~/` was not caught by the permission system. The current rule catches `rm -rf ~*` which should match this pattern, but the command had multiple arguments before `~/`. Consider also matching:
- `*rm*-rf*~/*` (tilde-slash anywhere in command)
- `*rm*-r*~/*` (without -f flag)

### vectimus-base-020b (governance config writes) [UPDATED]

~~Currently matches: `.claude/settings.json`, `.cursor/hooks.json`~~

Now also matches: `.cursor/mcp.json`, `.claude/mcp.json`, `.vscode/settings.json`, `.vscode/tasks.json`

This overlaps with proposed new rules 051-054 but the existing rule should be expanded to consolidate governance config protection.

### owasp-018 (agent instruction files) [UPDATED]

~~Currently matches: `CLAUDE.md`, `AGENTS.md`, `.cursorrules`, `.github/copilot-instructions.md`, `.windsurfrules`, `.clinerules`~~

Now also matches: `.kirorules`, `.aider.conf.yml`, `.zed/settings.json`, `.roorules`

Remaining candidates for future expansion: `.github/copilot-extensions.yml`, `.roo/rules`, `.junie/config`

---

## Controls that cannot be enforced at hook level

These gaps from the research require architectural solutions beyond Cedar policy enforcement:

| Gap | Why hooks cannot catch it | Required approach |
|-----|---------------------------|-------------------|
| Agent deception and concealment | Agent lies in output, not in tool calls | Output monitoring, claim-vs-state validation |
| Consent fatigue | Human approves destructive action after many routine approvals | UX differentiation for high-risk actions |
| Hallucination-driven supply chain | Agent recommends non-existent packages | Package existence validation pre-install |
| Multi-agent cascade infection | Compromise propagates through shared memory/tools | Inter-agent message signing, isolation |
| Cross-session memory persistence | Poisoned memories execute in future sessions | Memory integrity validation, anomaly detection |
| Strategic model deception | Model reasons about subverting oversight | Behavioral monitoring, independent verification |
| Tool description poisoning | Hidden instructions in MCP tool descriptions | Tool description scanning, hash pinning |
| Rug pull attacks | MCP tools mutate definitions post-approval | Tool definition pinning, change detection |

These represent the "beyond OWASP" frontier identified in the research. They are real threats but require complementary controls to Vectimus's hook-level enforcement.

---

## Implementation priority

**Phase 1 (immediate):** Gaps 1-3 (ORM destructive flags, AI permission bypass, IDE settings). These address the most frequently occurring and highest-impact incidents.

**Phase 2 (next sprint):** Gaps 4-5 (cloud resource deletion, network listeners). These extend existing infrastructure safety coverage.

**Phase 3 (following sprint):** Gaps 6-8 (agent spawning, DNS ping exfil, package publishing). These address medium-frequency threats.

**Phase 4 (backlog):** Gaps 9-11 (crypto mining, Windows commands, VS Code extensions). Lower frequency but straightforward to implement.

**Existing rule updates:** Can be done alongside any phase.
