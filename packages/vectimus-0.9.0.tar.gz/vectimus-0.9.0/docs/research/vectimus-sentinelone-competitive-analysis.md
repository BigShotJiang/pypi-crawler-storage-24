# Vectimus Competitive Analysis: SentinelOne / Prompt Security

**Date:** March 2026
**Context:** Assessing overlap and differentiation following SentinelOne's acquisition of Prompt Security (closed late 2025, ~$250-300M valuation).

---

## What SentinelOne / Prompt Security Actually Does

Prompt Security (now a SentinelOne product line) operates across three main surfaces:

1. **Prompt for Employees** — Shadow AI discovery, DLP for AI tool usage, role-based AI usage policies.  Browser extension and endpoint agent detect which AI tools employees are using across the org.  Every prompt and response is captured with full context for audit.  Sensitive data is redacted or tokenised before it reaches the model.

2. **Prompt for AI Code Assistants** — Secures Copilot, Cursor, Claude Code usage.  Prevents secrets and IP leaking into prompts.  Scans AI-generated code for vulnerabilities.  Enforces usage policies in dev environments.

3. **Prompt for Homegrown AI Apps / Agentic AI** — MCP Gateway that sits between AI applications and MCP servers.  Dynamic risk scoring of 13,000+ known MCP servers.  Allow/block/filter/redact actions per user, server or action.  Prompt injection and jailbreak detection.

The key integration is with SentinelOne's Singularity Platform: endpoint telemetry, identity data and cloud security all feed into a unified view.  This means their AI governance sits inside an existing EDR/XDR deployment most enterprises already have.

---

## Where It Overlaps With Vectimus

| Capability | Prompt Security | Vectimus |
|---|---|---|
| Multi-tool governance (Copilot, Cursor, Claude Code) | Yes | Yes |
| Pre-action evaluation | Partial (content inspection, DLP) | Yes (deterministic Cedar policy) |
| MCP tool governance | Yes (MCP Gateway) | Yes (via normalised event schema) |
| Audit logging | Yes (searchable, compliance-ready) | Yes (JSONL, SIEM export) |
| Compliance mapping | Implied (SOC 2, GDPR) | Explicit (Cedar policy → control mapping) |
| Enterprise deployment | Yes (browser ext + endpoint agent) | Yes (Intune, Jamf, GPO) |
| Persona / identity-based policy | Partial (role-based) | Yes (Cedar personas, SSO group mapping) |
| SIEM integration | Native (Singularity platform) | Exporters (Datadog, Splunk, Sentinel, Elastic) |

The overlap is most visible in the code assistant governance space.  Both products want to sit between developers and their AI tools and control what goes in and out.

---

## Where Vectimus Is Genuinely Different

**1. Deterministic pre-action blocking, not content inspection**

This is the core difference.  Prompt Security inspects the *content* of prompts and responses — it catches secrets leaking, PII in prompts and malicious outputs.  Vectimus evaluates the *action itself* — `terraform destroy`, `rm -rf /`, `npm publish` — against deterministic Cedar policies before execution.

Prompt Security would catch a developer pasting a database password into Claude Code.  Vectimus would catch Claude Code attempting to run `terraform destroy -auto-approve` against production.  These are different threat models.

**2. Agent framework middleware (not just MCP)**

Prompt Security's MCP Gateway covers MCP server interactions.  Vectimus plans direct middleware for Claude Agent SDK, LangGraph, Google ADK, AWS Strands — intercepting tool calls at the framework level, not just at the MCP transport layer.  An autonomous LangGraph agent making a shell call doesn't necessarily go through MCP.

**3. Cedar policy language with formal verification**

Vectimus uses Cedar, which gives provable correctness and human-readable policies that security teams can audit.  Prompt Security uses proprietary policy rules configured through a UI.  For regulated industries where auditors need to inspect and verify policy logic, Cedar is a material advantage.

**4. Incident-mapped and compliance-mapped policies**

Every Vectimus rule traces to a specific real-world incident and links to specific compliance controls (SOC 2, EU AI Act, NIST AI RMF).  This makes the compliance story concrete rather than inferred.  Prompt Security has compliance positioning but doesn't appear to do per-rule compliance mapping at that granularity.

**5. Open-source core**

Vectimus ships an open-source core under Apache 2.0.  Prompt Security is fully proprietary SaaS/on-prem.  The open-source strategy creates a different adoption path — developers adopt bottom-up, enterprise buys top-down.

---

## Where Prompt Security Has Clear Advantages Over Vectimus

**1. Installed base and distribution**

SentinelOne has thousands of enterprise customers.  Prompt Security plugs into the Singularity platform they already run.  Zero procurement friction.  Vectimus is pre-launch with no customers.

**2. Shadow AI discovery**

Vectimus doesn't do AI tool discovery at all.  Prompt Security can tell a CISO which AI tools are being used across the org, by whom and how frequently.  This visibility layer is valuable independently of governance.

**3. DLP / content inspection**

Prompt Security catches sensitive data flowing into prompts — PII, secrets, IP.  Vectimus evaluates actions, not prompt content.  A developer pasting customer records into a prompt wouldn't trigger Vectimus policies.

**4. AI-generated code vulnerability scanning**

Prompt Security scans code outputs from AI assistants for vulnerabilities.  Vectimus doesn't inspect output quality — it governs what actions the agent takes, not what code it writes.

**5. Scale of MCP coverage**

Prompt Security dynamically risk-scores 13,000+ MCP servers.  Vectimus treats MCP tool invocations as normalised events against Cedar policies.  The breadth of MCP-specific threat intelligence is wider on the Prompt Security side.

**6. Resources**

SentinelOne is a public company (NYSE: S).  Prompt Security's team and research capacity dwarf what a solo founder can build.

---

## Honest Assessment: Is This a Competitor?

**Partially, but not a direct replacement.**

The overlap is in the "govern AI coding tools in the enterprise" space.  But the threat models are different:

- Prompt Security answers: "What data is flowing into and out of AI tools, and is any of it sensitive or malicious?"
- Vectimus answers: "What actions are AI agents attempting to execute, and should those actions be allowed?"

An enterprise could reasonably deploy both.  Prompt Security catches the data leakage and prompt injection.  Vectimus catches the destructive shell command and the unauthorised infrastructure change.

The risk for Vectimus is that SentinelOne expands Prompt Security's capabilities into action-level governance, which their MCP Gateway is already moving towards.  The window of differentiation is real but not permanent.

---

## Other Competitors to Update in the Business Plan

The competitive landscape section should also cover:

**Snyk + Invariant Labs** (acquired June 2025)
- Invariant Guardrails: transparent security layer at the LLM/agent level
- Policy enforcement engine, runtime monitoring, contextual security rules
- MCP vulnerability scanning (they discovered and named "tool poisoning" and "MCP rug pulls")
- Now part of Snyk's AI Trust Platform alongside AI Bill of Materials
- More research-oriented than Prompt Security but moving toward production tooling

**Proofpoint Secure Agent Gateway** (launched Q1 2026)
- MCP-based gateway for securing data in agentic workflows
- Content inspection, DLP, policy enforcement
- Integrates with their broader data security platform
- Focused on data protection more than action governance

**AgentGateway** (open source)
- Rust-based proxy for MCP and A2A (agent-to-agent) communication
- RBAC, JWT auth, TLS, CEL-based access policies
- Open source, infrastructure-focused
- Closer to Vectimus in philosophy (deterministic policy enforcement) but focused on the gateway layer

**MintMCP**
- Managed MCP Gateway with OAuth, audit logging, tool access control
- Already in your business plan as adjacent — upgrade to direct competitor given their governance framework content and SOC 2 positioning

---

## Features Vectimus Could Add (With Assessment)

### High-value additions that stay on-brand

**1. MCP Server Risk Scoring**
Score known MCP servers against a vulnerability database.  Prompt Security does this at scale (13,000+ servers).  Vectimus could maintain a smaller but open-source dataset focused on the most common enterprise MCP servers.  Cedar policies could reference risk scores: `forbid` MCP tool calls to servers below a threshold score.
*Verdict: Add.  Fits the deterministic governance model and differentiates from competitors who treat MCP risk as a black-box AI classification.*

**2. AI Bill of Materials (AI-BOM)**
Snyk's approach — automatically detect which AI agents, models, MCP servers and frameworks are deployed across a codebase.  Vectimus could generate a policy-aware inventory: here's every agent, here's the policy set governing it, here's the coverage gap.
*Verdict: Add as enterprise feature.  CISOs need this view.  It turns Vectimus from a governance engine into a governance posture tool.*

**3. Shadow Agent Discovery (Lightweight)**
Not full Prompt Security-style shadow AI discovery (that's an endpoint product).  Instead, detect unregistered agents hitting the Vectimus evaluation endpoint or agents operating without a Vectimus hook configured.  Basically: "here are the agents we govern, and here are the ones we've detected that we don't."
*Verdict: Add as enterprise feature.  Low effort, high value for security teams.*

**4. Policy Simulation / Dry-Run Mode**
Evaluate historical or synthetic events against a proposed policy change before deploying it.  Show what would have been blocked, what would have been allowed and what would have escalated.  Security teams need this to avoid breaking developer workflows.
*Verdict: Add to open-source core.  Essential for adoption.  No competitor does this well with Cedar.*

**5. Red Team Event Library**
A curated set of attack event payloads (prompt injection via MCP, credential exfiltration attempts, destructive commands, supply chain patterns) that teams can run against their Vectimus policy set.  Like a penetration test for your governance config.
*Verdict: Add to open-source core.  Strong community value.  Builds credibility.*

### Features that would dilute the positioning

**6. Prompt Content Inspection / DLP**
Inspecting the content of prompts for PII, secrets and sensitive data.  This is Prompt Security's core value proposition.
*Verdict: Don't add.  This pulls Vectimus into a fight it can't win against SentinelOne, Snyk and the DLP vendors.  Stay focused on action governance.  Let others handle data flow; Vectimus handles action flow.*

**7. AI-Generated Code Scanning**
Scanning outputs of AI coding tools for vulnerabilities.
*Verdict: Don't add.  Snyk, SonarQube and the existing SAST/DAST ecosystem already cover this.  Vectimus should integrate with them (trigger a scan as a post-action hook) rather than build it.*

**8. Full Shadow AI Discovery**
Browser extensions, endpoint agents to discover all AI tool usage across an enterprise.
*Verdict: Don't add.  This is an endpoint product.  Building it means competing with SentinelOne on their home turf.  Vectimus should consume this data from existing tools, not generate it.*

---

## Recommended Positioning Update

The business plan's competitive landscape section (8.x) should be updated with SentinelOne/Prompt Security, Snyk/Invariant Labs, Proofpoint Secure Agent Gateway and AgentGateway.  The differentiation narrative should sharpen around this framing:

> "Prompt Security, Snyk and the DLP vendors secure the data layer — what goes into and comes out of AI systems.  Vectimus secures the action layer — what AI systems actually do once they decide to act.  Content inspection catches leaked credentials in a prompt.  Vectimus catches the `terraform destroy` command that follows."

This is a clean positioning line that respects the competition without pretending Vectimus does everything.  It also creates a natural integration story: Vectimus + Prompt Security covers both threat surfaces.

---

*Prepared for internal planning.  Photon Consulting Limited.*
