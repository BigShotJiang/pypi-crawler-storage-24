#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Core REST API — projects, repos, branches, updates."""

import os
import shlex
import subprocess

import threading
from typing import Dict, List, Optional

from .server import route


def _invalidate_dashboard_cache(project_override: Optional[str] = None) -> None:
    """Clear the dashboard summary cache for the active project."""
    from ..commands.projects import get_current_project, _invalidate_summary_cache
    path = project_override or get_current_project()
    if path:
        _invalidate_summary_cache(path)


def _get_defaults_file() -> str:
    """Return the absolute path to .bit.defaults for the current project."""
    from ..commands.projects import get_current_project
    project_path = get_current_project()
    if project_path:
        return os.path.join(project_path, ".bit.defaults")
    return ".bit.defaults"


# ---------- projects ----------

@route("GET", "/api/projects")
def api_projects(handler):
    """All projects with dashboard summaries."""
    from ..commands.projects import load_projects_for_display, gather_all_project_summaries
    from ..commands.ssh_remote import is_remote_project

    projects = load_projects_for_display()
    summaries = gather_all_project_summaries(projects)

    from ..tags import get_effective_tags

    result = []
    for path, pinfo in projects.items():
        s = summaries.get(path, {})
        result.append({
            "path": path,
            "name": pinfo.get("name", os.path.basename(path)),
            "description": pinfo.get("description", ""),
            "persona": pinfo.get("persona") or pinfo.get("remote_persona") or "yocto",
            "tags": list(pinfo.get("tags") or []),
            "remote_tags": list(pinfo.get("remote_tags") or []),
            "hidden_tags": list(pinfo.get("hidden_tags") or []),
            "effective_tags": sorted(get_effective_tags(pinfo)),
            "remote": is_remote_project(pinfo),
            "auto_update": pinfo.get("auto_update", {}),
            "summary": s,
        })
    handler._send_json(result)


@route("GET", "/api/projects/current")
def api_projects_current(handler):
    """Active project."""
    from ..commands.projects import get_current_project
    path = get_current_project()
    handler._send_json({"path": path or ""})


@route("POST", "/api/projects/activate")
def api_projects_activate(handler):
    """Toggle project activation."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "")
    if not path:
        handler._send_error_json(400, "Missing 'path'")
        return
    from ..commands.projects import load_projects, get_current_project, set_current_project
    projects = load_projects()
    if path not in projects:
        handler._send_error_json(404, "Project not found")
        return
    persona = projects[path].get("persona", "yocto")
    current = get_current_project(persona)
    if current == path:
        set_current_project(None, persona_name=persona)
        active = False
    else:
        set_current_project(path)
        active = True
    handler.sse.broadcast("projects_list_changed", {})
    handler._send_json({"ok": True, "active": active, "path": path})


@route("POST", "/api/projects/add")
def api_projects_add(handler):
    """Register a new project (local or remote SSH)."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "").strip()
    name = body.get("name", "")
    if not path:
        handler._send_error_json(400, "Missing 'path'")
        return
    from ..commands.ssh_remote import parse_remote_uri
    parsed = parse_remote_uri(path)
    if not parsed:
        # Normalize local paths (expand ~ and make absolute) like the TUI does
        path = os.path.expanduser(path)
        path = os.path.abspath(path)
    if parsed:
        from ..commands.projects import classify_remote_path, add_remote_project
        user, host, rpath = parsed
        status = classify_remote_path(user, host, rpath)
        if status == "unreachable":
            handler._send_error_json(502, f"Cannot connect to {host} via SSH")
            return
        if status == "empty":
            from ..commands.ssh_remote import ssh_run
            ssh_run(user, host, f"mkdir -p {shlex.quote(rpath)}", timeout=10)
        ok = add_remote_project(path, name=name, skip_path_check=(status == "empty"))
        if not ok:
            handler._send_error_json(400, "Failed to add remote project")
            return
    else:
        from ..commands.projects import classify_project_path, add_project
        status = classify_project_path(path)
        if status == "invalid":
            handler._send_error_json(400, f"Path exists but is not a directory: {path}")
            return
        if status == "empty":
            os.makedirs(path, exist_ok=True)
        ok = add_project(path, name=name)
        if not ok:
            handler._send_error_json(400, f"Failed to add project: {path}")
            return
    handler.sse.broadcast("projects_list_changed", {})
    handler._send_json({"ok": True, "status": status})


@route("POST", "/api/projects/remove")
def api_projects_remove(handler):
    """Unregister a project."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "")
    if not path:
        handler._send_error_json(400, "Missing 'path'")
        return
    from ..commands.projects import remove_project
    remove_project(path)
    handler.sse.broadcast("projects_list_changed", {})
    handler._send_json({"ok": True})


@route("POST", "/api/projects/rename")
def api_projects_rename(handler):
    """Rename a project."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "")
    name = body.get("name", "")
    if not path or not name:
        handler._send_error_json(400, "Missing 'path' or 'name'")
        return
    from ..commands.projects import load_projects, save_projects
    projects = load_projects()
    if path not in projects:
        handler._send_error_json(404, "Project not found")
        return
    projects[path]["name"] = name
    save_projects(projects)
    handler.sse.broadcast("projects_list_changed", {})
    handler._send_json({"ok": True})


@route("POST", "/api/projects/description")
def api_projects_description(handler):
    """Set description on a project."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "")
    desc = body.get("description")
    if not path or desc is None:
        handler._send_error_json(400, "Missing 'path' or 'description'")
        return
    from ..commands.projects import load_projects, save_projects
    projects = load_projects()
    if path not in projects:
        handler._send_error_json(404, "Project not found")
        return
    projects[path]["description"] = desc
    save_projects(projects)
    handler.sse.broadcast("projects_list_changed", {})
    handler._send_json({"ok": True})


# ---------- tags / panes ----------

@route("POST", "/api/projects/tags")
def api_projects_tags(handler):
    """Set tags on a project."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "")
    tags = body.get("tags")
    if not path or tags is None:
        handler._send_error_json(400, "Missing 'path' or 'tags'")
        return
    from ..tags import set_project_tags
    try:
        set_project_tags(path, tags)
    except KeyError:
        handler._send_error_json(404, "Project not found")
        return
    handler.sse.broadcast("projects_list_changed", {})
    handler._send_json({"ok": True})


@route("POST", "/api/projects/hidden_tags")
def api_projects_hidden_tags(handler):
    """Set hidden_tags on a project (suppresses matching remote tags)."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    path = body.get("path", "")
    hidden_tags = body.get("hidden_tags")
    if not path or hidden_tags is None:
        handler._send_error_json(400, "Missing 'path' or 'hidden_tags'")
        return
    from ..tags import set_project_hidden_tags
    try:
        set_project_hidden_tags(path, hidden_tags)
    except KeyError:
        handler._send_error_json(404, "Project not found")
        return
    handler.sse.broadcast("projects_list_changed", {})
    handler._send_json({"ok": True})


@route("GET", "/api/panes")
def api_panes_get(handler):
    """Return panes, active pane, and all known tags."""
    from ..tags import load_panes, get_active_pane, all_tags
    from ..commands.projects import load_projects
    panes = load_panes()
    active = get_active_pane()
    projects = load_projects()
    # Collect tags from both projects and pane definitions
    tags = all_tags(projects)
    for pane in panes:
        tags.update(pane.get("tags") or [])
    handler._send_json({
        "panes": panes,
        "active": active,
        "all_tags": sorted(tags),
    })


@route("POST", "/api/panes")
def api_panes_create(handler):
    """Create or update a pane."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    name = body.get("name", "")
    tags = body.get("tags")
    if not name or tags is None:
        handler._send_error_json(400, "Missing 'name' or 'tags'")
        return
    from ..tags import create_or_update_pane
    panes = create_or_update_pane(name, tags)
    handler._send_json({"ok": True, "panes": panes})


@route("POST", "/api/panes/delete")
def api_panes_delete(handler):
    """Delete a non-builtin pane."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    name = body.get("name", "")
    if not name:
        handler._send_error_json(400, "Missing 'name'")
        return
    from ..tags import delete_pane
    try:
        panes = delete_pane(name)
    except ValueError as e:
        handler._send_error_json(400, str(e))
        return
    handler._send_json({"ok": True, "panes": panes})


@route("POST", "/api/panes/activate")
def api_panes_activate(handler):
    """Set the active pane."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    name = body.get("name", "")
    if not name:
        handler._send_error_json(400, "Missing 'name'")
        return
    from ..tags import set_active_pane
    set_active_pane(name)
    handler._send_json({"ok": True})


# ---------- repos ----------

def _resolve_current_repos(project_override=None, discover=False,
                            include_hidden=False):
    """Resolve repos for a project — delegates to query._resolve_repos.

    Single source of truth for repo discovery, shared with ``bit query``
    CLI and therefore with SSH remote queries.
    """
    from ..commands.query import _resolve_repos
    return _resolve_repos(project_override, discover=discover,
                          include_hidden=include_hidden)


def _project_param(handler):
    """Read optional ?project= query parameter for non-activating context."""
    p = handler._query_param("project", "")
    return p if p else None


def _is_remote_project_path(project_path):
    """Check if a project path corresponds to a remote (SSH) project."""
    from ..commands.projects import load_projects
    from ..commands.ssh_remote import is_remote_project
    projects = load_projects()
    pinfo = projects.get(project_path, {})
    if is_remote_project(pinfo):
        return pinfo
    return None


def _ssh_query(project_path: str, query_path: str,
               timeout: int = 30) -> Optional[dict]:
    """Run ``bit query <path>`` on a remote host and return parsed JSON.

    Returns None if not a remote project.  Uses the deployed ``bit``
    binary on the remote so local and remote use identical Python logic.
    """
    remote_info = _is_remote_project_path(project_path) if project_path else None
    if not remote_info:
        return None
    from ..commands.ssh_remote import ssh_run, ssh_resolve_address, _EXTRA_PATH, _deploy_bit_to_remote
    user = remote_info.get("user", "")
    host = remote_info["host"]
    remote_path = remote_info.get("remote_path", "")
    addr, port = ssh_resolve_address(user, host)
    # Ensure remote has the current bit binary (same as TUI's ssh_dispatch_command)
    _deploy_bit_to_remote(user, addr, port=port)
    cmd = (f'export PATH="{_EXTRA_PATH}:$PATH" && '
           f'bit query {shlex.quote(query_path)} '
           f'--project-path {shlex.quote(remote_path)}')
    try:
        r = ssh_run(user, addr, cmd, timeout=timeout, port=port)
        detail = r.stderr.strip() if r.stderr else ""
        if r.returncode != 0 and not r.stdout.strip():
            msg = f"Remote query failed (exit {r.returncode})"
            if detail:
                # Keep first 200 chars of stderr for diagnosis
                msg += f": {detail[:200]}"
            return {"error": msg}
        if not r.stdout.strip():
            msg = "Remote query returned empty response"
            if detail:
                msg += f": {detail[:200]}"
            return {"error": msg}
        import json as _json
        return _json.loads(r.stdout)
    except subprocess.TimeoutExpired:
        return {"error": f"Remote query timed out after {timeout}s"}
    except (ValueError, Exception) as exc:
        # Include raw output head for diagnosis
        raw = getattr(locals().get('r'), 'stdout', '')
        snippet = (raw[:200] + '...') if raw and len(raw) > 200 else (raw or '')
        return {"error": f"Failed to parse remote query response: {exc}"
                + (f" (raw: {snippet})" if snippet else "")}


def _ssh_query_post(project_path: str, query_path: str,
                    post_data: dict, timeout: int = 60) -> Optional[dict]:
    """Run ``bit query <path> --stdin`` on a remote host, piping JSON via stdin.

    Like ``_ssh_query`` but for mutations that need a POST body — the JSON
    is sent over stdin instead of being crammed into the command line.

    Returns None if not a remote project.
    """
    remote_info = _is_remote_project_path(project_path) if project_path else None
    if not remote_info:
        return None
    from ..commands.ssh_remote import (ssh_resolve_address, _EXTRA_PATH,
                                       _deploy_bit_to_remote, _ssh_mux_opts,
                                       _ssh_no_prompt_env)
    user = remote_info.get("user", "")
    host = remote_info["host"]
    remote_path = remote_info.get("remote_path", "")
    addr, port = ssh_resolve_address(user, host)
    _deploy_bit_to_remote(user, addr, port=port)

    cmd = (f'export PATH="{_EXTRA_PATH}:$PATH" && '
           f'bit query {shlex.quote(query_path)} '
           f'--stdin '
           f'--project-path {shlex.quote(remote_path)}')
    target = f"{user}@{addr}" if user else addr
    mux = _ssh_mux_opts()
    port_args = ["-p", str(port)] if port != 22 else []
    ssh_argv = [
        "ssh", *port_args, *mux,
        "-o", "BatchMode=yes",
        "-o", "ConnectTimeout=5",
        "-o", "StrictHostKeyChecking=accept-new",
        target, cmd,
    ]
    try:
        import json as _json
        r = subprocess.run(
            ssh_argv,
            input=_json.dumps(post_data),
            capture_output=True, text=True,
            timeout=timeout,
            env=_ssh_no_prompt_env(),
        )
        detail = r.stderr.strip() if r.stderr else ""
        if r.returncode != 0 and not r.stdout.strip():
            msg = f"Remote query failed (exit {r.returncode})"
            if detail:
                msg += f": {detail[:200]}"
            return {"error": msg}
        if not r.stdout.strip():
            msg = "Remote query returned empty response"
            if detail:
                msg += f": {detail[:200]}"
            return {"error": msg}
        return _json.loads(r.stdout)
    except subprocess.TimeoutExpired:
        return {"error": f"Remote query timed out after {timeout}s"}
    except (ValueError, Exception) as exc:
        raw = getattr(locals().get('r'), 'stdout', '')
        snippet = (raw[:200] + '...') if raw and len(raw) > 200 else (raw or '')
        return {"error": f"Failed to parse remote query response: {exc}"
                + (f" (raw: {snippet})" if snippet else "")}


@route("GET", "/api/repos")
def api_repos(handler):
    """Repos with branch, commits, dirty, upstream, layers."""
    from ..commands.query import query_repos
    project_override = _project_param(handler)

    # Remote project: run bit query on remote via SSH
    remote_result = _ssh_query(project_override, "repos", timeout=60)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project: use same query function directly
    discover = handler._query_param("discover", "") == "1"
    hidden = handler._query_param("hidden", "") == "1"
    handler._send_json(query_repos(project_override, discover=discover,
                                   include_hidden=hidden))


@route("GET", "/api/repos/branches/union")
def api_repos_branches_union(handler):
    """Union of branches across all repos with counts."""
    from ..commands.query import query_union_branches
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override, "repos/branches/union")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_union_branches(project_override)
    handler._send_json(result)


@route("POST", "/api/repos/branch-all")
def api_repos_branch_all(handler):
    """Switch all repos to the same branch."""
    from ..commands.query import query_branch_all

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    branch = body.get("branch", "")
    if not branch:
        handler._send_error_json(400, "Missing 'branch'")
        return

    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override,
                               f"repos/branch-all/{branch}")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_branch_all(branch, project_override)
    _invalidate_dashboard_cache(project_override)
    handler.sse.broadcast("repo_updated", {"action": "branch-all", "branch": branch})
    handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/commits")
def api_repo_commits(handler, repo_name):
    """Local + upstream commits for a repo."""
    from ..commands.query import query_repo_commits
    project_override = _project_param(handler)
    layer = handler._query_param("layer", "")

    # Remote project: run bit query on remote via SSH
    upstream_limit = int(handler._query_param("upstream_limit", "500"))
    context_limit = int(handler._query_param("context_limit", "20"))
    if layer:
        query_path = f"repos/{repo_name}/commits/layer/{layer}"
    else:
        query_path = f"repos/{repo_name}/commits"
    remote_result = _ssh_query(project_override, query_path, timeout=60)
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project: use same query function directly
    result = query_repo_commits(repo_name, project_override,
                                upstream_limit=upstream_limit,
                                context_limit=context_limit,
                                layer=layer)
    if "error" in result:
        handler._send_error_json(404, result["error"])
    else:
        handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/branches")
def api_repo_branches(handler, repo_name):
    """Branch list for a repo."""
    from ..commands.query import query_repo_branches
    project_override = _project_param(handler)

    # Remote project: run bit query on remote via SSH
    remote_result = _ssh_query(project_override,
                               f"repos/{repo_name}/branches")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_repo_branches(repo_name, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    handler._send_json(result)


@route("POST", "/api/repos/([^/]+)/checkout")
def api_repo_checkout(handler, repo_name):
    """Switch branch."""
    from ..commands.query import query_checkout_branch

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    branch = body.get("branch", "")
    if not branch:
        handler._send_error_json(400, "Missing 'branch'")
        return

    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override,
                               f"repos/{repo_name}/checkout/{branch}",
                               timeout=60)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_checkout_branch(repo_name, branch, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    _invalidate_dashboard_cache(project_override)
    handler.sse.broadcast("repo_updated", {"action": "checkout", "branch": branch})
    handler._send_json(result)


@route("POST", "/api/repos/([^/]+)/fetch")
def api_repo_fetch(handler, repo_name):
    """Fetch upstream for a repo."""
    from ..commands.query import query_fetch_repo

    handler._read_json()  # consume POST body
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override,
                               f"repos/{repo_name}/fetch", timeout=60)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        _invalidate_dashboard_cache(project_override)
        handler.sse.broadcast("repo_updated", {"repo": repo_name, "action": "fetch"})
        handler._send_json(remote_result)
        return

    result = query_fetch_repo(repo_name, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    _invalidate_dashboard_cache(project_override)
    handler.sse.broadcast("repo_updated", {"repo": repo_name, "action": "fetch"})
    handler._send_json(result)


@route("POST", "/api/repos/([^/]+)/update")
def api_repo_update(handler, repo_name):
    """Update (rebase or merge) a repo."""
    from ..commands.query import query_update_repo

    body = handler._read_json() or {}
    action = body.get("action", "")
    project_override = _project_param(handler)

    query_path = f"repos/{repo_name}/update"
    if action:
        query_path += f"/{action}"
    remote_result = _ssh_query(project_override, query_path, timeout=120)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        _invalidate_dashboard_cache(project_override)
        handler.sse.broadcast("repo_updated", {"repo": repo_name, "action": action or "rebase"})
        handler._send_json(remote_result)
        return

    result = query_update_repo(repo_name, action, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    _invalidate_dashboard_cache(project_override)
    handler.sse.broadcast("repo_updated", {"repo": repo_name, "action": action or "rebase"})
    handler._send_json(result)


@route("POST", "/api/refresh")
def api_refresh(handler):
    """Fetch all repos."""
    from ..commands.query import query_refresh_all

    handler._read_json()  # consume POST body
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override, "refresh", timeout=120)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
            return
        _invalidate_dashboard_cache(project_override)
        handler.sse.broadcast("refresh_complete", {})
        handler._send_json(remote_result)
        return

    def _do_refresh():
        query_refresh_all(project_override)
        _invalidate_dashboard_cache(project_override)
        handler.sse.broadcast("refresh_complete", {})

    t = threading.Thread(target=_do_refresh, daemon=True)
    t.start()
    handler._send_json({"ok": True})


@route("GET", "/api/repos/([^/]+)/commits/([^/]+)/show")
def api_repo_commit_show(handler, repo_name, commit_hash):
    """Full git show output for a single commit."""
    from ..commands.query import query_commit_show
    project_override = _project_param(handler)

    # Remote project: run bit query on remote via SSH
    remote_result = _ssh_query(
        project_override,
        f"repos/{repo_name}/commits/{commit_hash}/show", timeout=60)
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project: use same query function directly
    result = query_commit_show(repo_name, commit_hash, project_override)
    if "error" in result:
        handler._send_error_json(404, result["error"])
    else:
        handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/diff")
def api_repo_diff(handler, repo_name):
    """Uncommitted changes."""
    from ..commands.query import query_repo_diff
    project_override = _project_param(handler)

    # Remote project: run bit query on remote via SSH
    remote_result = _ssh_query(project_override, f"repos/{repo_name}/diff", timeout=60)
    if remote_result is not None:
        handler._send_json(remote_result)
        return

    # Local project: use same query function directly
    result = query_repo_diff(repo_name, project_override)
    if "error" in result:
        handler._send_error_json(404, result["error"])
    else:
        handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/log")
def api_repo_log(handler, repo_name):
    """Commit history."""
    from ..commands.query import query_repo_log_by_name
    project_override = _project_param(handler)

    count = handler._query_param("count", "50")
    try:
        count = int(count)
    except ValueError:
        count = 50

    remote_result = _ssh_query(
        project_override,
        f"repos/{repo_name}/log?count={count}")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_repo_log_by_name(repo_name, count, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    handler._send_json(result)


# ---------- config ----------

@route("GET", "/api/config")
def api_config_get(handler):
    """Full config data matching TUI tree layout."""
    from ..commands.projects import (
        get_current_project, load_projects,
        get_directory_browser, get_git_viewer, get_preview_layout,
        get_editor, get_recipe_use_bitbake_layers, get_backup_prune_age,
        get_web_autostart, get_web_open_browser,
        get_host_metrics_refresh,
        get_default_dashboard_command, get_nnn_colors,
        get_graph_renderer, get_explore_load_size,
    )
    from ..tmux import get_tmux_prefix
    from ..commands.common import get_repo_display_info, get_push_target
    from ..core import load_defaults, get_custom_commands

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()

    # Repos with display info and defaults
    repos, defaults, *_ = _resolve_current_repos(project_override)
    repo_list = []
    for repo in repos:
        display_name, is_custom = get_repo_display_info(repo)
        action = defaults.get(repo, "rebase")
        push = get_push_target(defaults, repo)
        custom = get_custom_commands(defaults, repo)
        repo_list.append({
            "path": repo,
            "display_name": display_name,
            "display_name_custom": is_custom,
            "default_action": action,
            "push_target": push,
            "custom_commands": custom,
        })

    # Project info
    projects = load_projects()
    pinfo = projects.get(project_path, {}) if project_path else {}
    project_info = {
        "path": project_path or "",
        "name": pinfo.get("name", os.path.basename(project_path) if project_path else ""),
        "description": pinfo.get("description", ""),
    }

    # Branch filters
    bp_list = defaults.get("__branch_priorities__", [])
    bx_list = defaults.get("__branch_excludes__", [])
    if not isinstance(bp_list, list):
        bp_list = []
    if not isinstance(bx_list, list):
        bx_list = []
    stale_days = defaults.get("__branch_stale_days__", 365)
    try:
        stale_days = int(stale_days)
    except (ValueError, TypeError):
        stale_days = 365

    # Global settings (from projects.json)
    recipe_scan = "bitbake-layers" if get_recipe_use_bitbake_layers() else "file"

    handler._send_json({
        "repos": repo_list,
        "project": project_info,
        "branches": {
            "priorities": bp_list,
            "excludes": bx_list,
            "stale_days": stale_days,
        },
        "settings": {
            "directory_browser": get_directory_browser(),
            "git_viewer": get_git_viewer(),
            "preview_layout": get_preview_layout(),
            "editor": get_editor(),
            "recipe_scan": recipe_scan,
            "backup_prune_age": get_backup_prune_age(),
            "default_dashboard_command": get_default_dashboard_command(),
            "web_autostart": get_web_autostart(),
            "web_open_browser": get_web_open_browser(),
            "host_metrics_refresh": get_host_metrics_refresh(),
            "tmux_prefix": get_tmux_prefix(),
            "nnn_colors": get_nnn_colors(),
            "graph_renderer": get_graph_renderer(),
            "explore_load_size": get_explore_load_size(),
        },
    })


@route("POST", "/api/config")
def api_config_post(handler):
    """Bulk update per-repo default actions."""
    from ..commands.projects import get_current_project
    from ..core import load_defaults, save_defaults

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()
    if not project_path:
        handler._send_error_json(400, "No active project")
        return

    defaults_file = os.path.join(project_path, ".bit.defaults")
    defaults = load_defaults(defaults_file)

    # body is {repo_path: action, ...}
    for repo_path, action in body.items():
        if action in ("rebase", "merge", "skip"):
            defaults[repo_path] = action

    save_defaults(defaults_file, defaults)
    handler._send_json({"ok": True})


@route("POST", "/api/config/repo/([^/]+)")
def api_config_repo_post(handler, repo_name):
    """Update individual repo settings (display name, default, push target)."""
    from ..commands.projects import get_current_project
    from ..commands.common import find_repo_by_identifier
    from ..core import load_defaults, save_defaults

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    project_override = _project_param(handler)
    repos, defaults, *_ = _resolve_current_repos(project_override)
    repo = find_repo_by_identifier(repos, repo_name, defaults)
    if not repo:
        handler._send_error_json(404, f"Repo not found: {repo_name}")
        return

    project_path = project_override or get_current_project()
    if not project_path:
        handler._send_error_json(400, "No active project")
        return

    defaults_file = os.path.join(project_path, ".bit.defaults")
    defaults = load_defaults(defaults_file)

    # Update default action
    if "default_action" in body:
        action = body["default_action"]
        if action in ("rebase", "merge", "skip"):
            defaults[repo] = action

    # Update display name via git config
    if "display_name" in body:
        from ..commands.common import set_repo_display_name
        set_repo_display_name(repo, body["display_name"].strip())

    # Update push target
    if "push_target" in body:
        pt = body["push_target"]
        targets = defaults.setdefault("__push_targets__", {})
        if pt and isinstance(pt, dict):
            targets[repo] = pt
        else:
            targets.pop(repo, None)

    save_defaults(defaults_file, defaults)
    handler._send_json({"ok": True})


@route("GET", "/api/config/project")
def api_config_project_get(handler):
    """Project conf files (bblayers.conf, local.conf) with parsed variables."""
    from ..commands.projects import get_current_project
    from ..commands.config import parse_config_variables

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()
    if not project_path:
        handler._send_json({"conf_dir": "", "files": []})
        return

    # Find bblayers.conf
    bblayers = None
    for cand in ["conf/bblayers.conf", "build/conf/bblayers.conf"]:
        full = os.path.join(project_path, cand)
        if os.path.exists(full):
            bblayers = full
            break

    if not bblayers:
        handler._send_json({"conf_dir": "", "files": []})
        return

    conf_dir = os.path.dirname(bblayers)
    local_conf = os.path.join(conf_dir, "local.conf")

    files = []
    for conf_path, label in [(bblayers, "bblayers.conf"), (local_conf, "local.conf")]:
        if not os.path.isfile(conf_path):
            continue
        variables = parse_config_variables(conf_path)
        files.append({
            "path": conf_path,
            "name": label,
            "variables": [
                {"name": name, "line": line, "value": value}
                for name, line, value in variables
            ],
        })

    handler._send_json({"conf_dir": conf_dir, "files": files})


@route("POST", "/api/config/settings")
def api_config_settings_post(handler):
    """Update global settings (directory_browser, git_viewer, etc.)."""
    from ..commands.projects import (
        set_directory_browser, set_git_viewer, set_preview_layout,
        set_editor, set_recipe_use_bitbake_layers, set_backup_prune_age,
        set_web_autostart, set_web_open_browser,
        set_host_metrics_refresh,
        set_default_dashboard_command, set_nnn_colors,
        set_graph_renderer, set_explore_load_size,
    )
    from ..tmux import set_tmux_prefix

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    _setters = {
        "directory_browser": set_directory_browser,
        "git_viewer": set_git_viewer,
        "preview_layout": set_preview_layout,
        "editor": set_editor,
        "backup_prune_age": set_backup_prune_age,
        "default_dashboard_command": set_default_dashboard_command,
        "web_autostart": set_web_autostart,
        "web_open_browser": set_web_open_browser,
        "host_metrics_refresh": set_host_metrics_refresh,
        "tmux_prefix": set_tmux_prefix,
        "nnn_colors": set_nnn_colors,
        "graph_renderer": set_graph_renderer,
        "explore_load_size": lambda v: set_explore_load_size(int(v)),
    }

    for key, value in body.items():
        if key in _setters:
            _setters[key](value)
        elif key == "recipe_scan":
            set_recipe_use_bitbake_layers(value == "bitbake-layers")

    handler._send_json({"ok": True})


@route("POST", "/api/config/branches")
def api_config_branches_post(handler):
    """Update branch filter settings (priorities, excludes, stale_days)."""
    from ..commands.projects import get_current_project
    from ..core import load_defaults, save_defaults

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()
    if not project_path:
        handler._send_error_json(400, "No active project")
        return

    defaults_file = os.path.join(project_path, ".bit.defaults")
    defaults = load_defaults(defaults_file)

    if "priorities" in body and isinstance(body["priorities"], list):
        defaults["__branch_priorities__"] = body["priorities"]
    if "excludes" in body and isinstance(body["excludes"], list):
        defaults["__branch_excludes__"] = body["excludes"]
    if "stale_days" in body:
        try:
            defaults["__branch_stale_days__"] = int(body["stale_days"])
        except (ValueError, TypeError):
            pass

    save_defaults(defaults_file, defaults)
    handler._send_json({"ok": True})


@route("POST", "/api/config/properties")
def api_config_properties_post(handler):
    """Update project name and description."""
    from ..commands.projects import get_current_project, load_projects, save_projects

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return

    project_override = _project_param(handler)
    project_path = project_override or get_current_project()
    if not project_path:
        handler._send_error_json(400, "No active project")
        return

    projects = load_projects()
    if project_path not in projects:
        handler._send_error_json(404, "Project not found")
        return

    if "name" in body:
        projects[project_path]["name"] = body["name"]
    if "description" in body:
        projects[project_path]["description"] = body["description"]

    save_projects(projects)
    handler._send_json({"ok": True})


# ---------- commit browser actions ----------

@route("POST", "/api/repos/([^/]+)/export-patches")
def api_repo_export_patches(handler, repo_name):
    """Export commits as patch files (git format-patch --stdout)."""
    from ..commands.query import query_export_patches_by_name

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    commits = body.get("commits", [])
    if not commits:
        handler._send_error_json(400, "No commits specified")
        return
    target_dir = body.get("target_dir")

    project_override = _project_param(handler)

    # Remote project: run via SSH
    post_body = {"commits": commits}
    if target_dir:
        post_body["target_dir"] = target_dir
    remote_result = _ssh_query_post(project_override,
                                     f"repos/{repo_name}/export-patches",
                                     post_body)
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project
    result = query_export_patches_by_name(repo_name, commits,
                                          project_override,
                                          target_dir=target_dir)
    if "error" in result:
        handler._send_error_json(404, result["error"])
    else:
        handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/graph")
def api_repo_graph(handler, repo_name):
    """Git log --graph output."""
    from ..commands.query import query_repo_graph_by_name

    project_override = _project_param(handler)

    count = handler._query_param("count", "50")
    try:
        count = int(count)
    except ValueError:
        count = 50

    # Remote project: run via SSH
    remote_result = _ssh_query(project_override,
                               f"repos/{repo_name}/graph?count={count}")
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project
    result = query_repo_graph_by_name(repo_name, count, project_override)
    if "error" in result:
        handler._send_error_json(404, result["error"])
    else:
        handler._send_json(result)


@route("POST", "/api/repos/([^/]+)/drop")
def api_repo_drop(handler, repo_name):
    """Drop commits with backup branch."""
    from ..commands.query import query_drop_commits

    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    commit_shas = body.get("commits", [])
    if not commit_shas:
        handler._send_error_json(400, "No commits specified")
        return

    project_override = _project_param(handler)

    # Remote project: run via SSH
    remote_result = _ssh_query_post(project_override,
                                     f"repos/{repo_name}/drop",
                                     {"commits": commit_shas},
                                     timeout=60)
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            _invalidate_dashboard_cache(project_override)
            handler.sse.broadcast("repo_updated",
                                  {"repo": repo_name, "action": "drop"})
            handler._send_json(remote_result)
        return

    # Local project
    result = query_drop_commits(repo_name, project_override,
                                commit_shas=commit_shas)
    if "error" in result:
        handler._send_error_json(500, result["error"])
    else:
        _invalidate_dashboard_cache(project_override)
        handler.sse.broadcast("repo_updated",
                              {"repo": repo_name, "action": "drop"})
        handler._send_json(result)


@route("POST", "/api/repos/([^/]+)/rebase-prepare")
def api_repo_rebase_prepare(handler, repo_name):
    """Create backup branch for interactive rebase, return base + repo path."""
    from ..commands.query import query_rebase_prepare

    body = handler._read_json() or {}
    project_override = _project_param(handler)
    base_override = body.get("base", "")

    # Remote project: run via SSH (include base in query path if provided)
    query_path = f"repos/{repo_name}/rebase-prepare"
    if base_override:
        query_path += f"/{base_override}"
    remote_result = _ssh_query(project_override, query_path)
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project
    result = query_rebase_prepare(repo_name, project_override,
                                  base_override=base_override)
    if "error" in result:
        handler._send_error_json(500, result["error"])
    else:
        handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/layers")
def api_repo_layers(handler, repo_name):
    """Layers provided by a repo."""
    from ..commands.query import query_repo_layers
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override,
                               f"repos/{repo_name}/layers")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
            return
        handler._send_json(remote_result)
        return

    result = query_repo_layers(repo_name, project_override)
    if isinstance(result, dict) and "error" in result:
        handler._send_error_json(404, result["error"])
        return
    handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/commits/([^/]+)/lore")
def api_repo_commit_lore(handler, repo_name, commit_hash):
    """Search lore.kernel.org for a commit."""
    from ..commands.query import query_commit_lore
    project_override = _project_param(handler)

    # Remote project: run bit query on remote via SSH
    remote_result = _ssh_query(
        project_override,
        f"repos/{repo_name}/commits/{commit_hash}/lore")
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project: use same query function directly
    result = query_commit_lore(repo_name, commit_hash, project_override)
    if "error" in result:
        handler._send_error_json(500, result["error"])
    else:
        handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/tree")
def api_repo_tree(handler, repo_name):
    """File tree for a repo."""
    from ..commands.query import query_file_tree
    project_override = _project_param(handler)
    ref = handler._query_param("ref", "HEAD")

    # Remote project: run bit query on remote via SSH
    remote_result = _ssh_query(
        project_override, f"repos/{repo_name}/tree")
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project: use same query function directly
    result = query_file_tree(repo_name, ref, project_override)
    if "error" in result:
        handler._send_error_json(404, result["error"])
    else:
        handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/files/(.+)/commits")
def api_repo_file_commits(handler, repo_name, filepath):
    """Per-file commit history."""
    from urllib.parse import unquote
    from ..commands.query import query_file_commits
    project_override = _project_param(handler)
    filepath = unquote(filepath)
    ref = handler._query_param("ref", "HEAD")
    limit = int(handler._query_param("limit", "30"))

    # Remote project: run bit query on remote via SSH
    remote_result = _ssh_query(
        project_override, f"repos/{repo_name}/files/{filepath}/commits")
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project: use same query function directly
    result = query_file_commits(repo_name, filepath, ref, limit,
                                project_override)
    if "error" in result:
        handler._send_error_json(404, result["error"])
    else:
        handler._send_json(result)


@route("GET", "/api/repos/([^/]+)/commits/([^/]+)/changed-files")
def api_repo_commit_changed_files(handler, repo_name, commit_hash):
    """Files changed in a commit."""
    from ..commands.query import query_commit_changed_files
    project_override = _project_param(handler)

    # Remote project: run bit query on remote via SSH
    remote_result = _ssh_query(
        project_override,
        f"repos/{repo_name}/commits/{commit_hash}/changed-files")
    if remote_result is not None:
        if "error" in remote_result:
            handler._send_error_json(404, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    # Local project: use same query function directly
    result = query_commit_changed_files(repo_name, commit_hash,
                                        project_override)
    if "error" in result:
        handler._send_error_json(404, result["error"])
    else:
        handler._send_json(result)


# ---------- export (pull request) ----------

@route("GET", "/api/export/preview")
def api_export_preview(handler):
    """Exportable commits per repo."""
    from ..commands.query import query_export_preview
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override, "export/preview", timeout=60)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    handler._send_json(query_export_preview(project_override))


@route("GET", "/api/export/prep-state")
def api_export_prep_state(handler):
    """Load prep state for a project."""
    from ..commands.query import query_prep_state
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override, "export/prep-state")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    handler._send_json(query_prep_state(project_override))


@route("POST", "/api/export/prepare")
def api_export_prepare(handler):
    """Prepare repos for export — reorder commits, create branch."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    from ..commands.query import query_export_prepare
    project_override = _project_param(handler)

    remote_result = _ssh_query_post(project_override, "export/prepare", body,
                                     timeout=120)
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    result = query_export_prepare(
        project_override,
        repo_configs=body.get("repos", []),
        branch_name=body.get("branch_name", ""),
        force_replace=body.get("force_replace", False),
        backup=body.get("backup", True),
    )
    if result.get("status") == "ok":
        _invalidate_dashboard_cache(project_override)
        handler.sse.broadcast("repo_updated", {"action": "export-prepare"})
    handler._send_json(result)


@route("POST", "/api/export/patches")
def api_export_patches(handler):
    """Export commits as patches with subject rewriting."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    from ..commands.query import query_export_patches
    project_override = _project_param(handler)

    result = query_export_patches(
        project_override,
        repo_requests=body.get("repos", []),
        numbering=body.get("numbering", "global"),
        subject_prefix=body.get("subject_prefix", ""),
        series_version=body.get("series_version", 0),
        cover_letter=body.get("cover_letter", True),
        target_dir=body.get("target_dir", ""),
        layout=body.get("layout", "flat"),
        keep_content=body.get("keep_content", False),
    )
    handler._send_json(result)


# ---------- messages ----------

@route("GET", "/api/messages")
def api_messages(handler):
    """Project message log."""
    from ..commands.query import query_messages
    project_override = _project_param(handler)

    remote_result = _ssh_query(project_override, "messages")
    if remote_result is not None:
        if isinstance(remote_result, dict) and "error" in remote_result:
            handler._send_error_json(500, remote_result["error"])
        else:
            handler._send_json(remote_result)
        return

    handler._send_json(query_messages(project_override))


# ---------- pull patches ----------

@route("GET", "/api/pull/remotes")
def api_pull_remotes(handler):
    """List remote projects available for pulling patches."""
    from ..commands.query import query_pull_remotes
    handler._send_json(query_pull_remotes())


@route("POST", "/api/pull/match-repo")
def api_pull_match_repo(handler):
    """Match a local repo name against remote repos via SSH."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    remote_project = body.get("remote_project", "")
    local_repo_name = body.get("local_repo_name", "")
    if not remote_project or not local_repo_name:
        handler._send_error_json(400, "Missing remote_project or local_repo_name")
        return
    from ..commands.query import query_pull_match_repo
    project_override = _project_param(handler)
    result = query_pull_match_repo(remote_project, local_repo_name,
                                   project_override)
    if "error" in result:
        handler._send_error_json(500, result["error"])
    else:
        handler._send_json(result)


@route("POST", "/api/pull/commits")
def api_pull_commits(handler):
    """Get commits remote has that local doesn't."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    remote_project = body.get("remote_project", "")
    remote_repo = body.get("remote_repo", "")
    local_repo_name = body.get("local_repo_name", "")
    if not remote_project or not remote_repo or not local_repo_name:
        handler._send_error_json(400, "Missing required fields")
        return
    from ..commands.query import query_pull_commits
    project_override = _project_param(handler)
    result = query_pull_commits(remote_project, remote_repo,
                                local_repo_name, project_override)
    if "error" in result:
        handler._send_error_json(500, result["error"])
    else:
        handler._send_json(result)


@route("POST", "/api/pull/commit-show")
def api_pull_commit_show(handler):
    """Show commit details from a remote repo."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    remote_project = body.get("remote_project", "")
    remote_repo = body.get("remote_repo", "")
    commit_hash = body.get("commit_hash", "")
    if not remote_project or not remote_repo or not commit_hash:
        handler._send_error_json(400, "Missing required fields")
        return
    from ..commands.projects import load_projects
    from ..commands.ssh_remote import is_remote_project, ssh_resolve_address, ssh_commit_show
    projects = load_projects()
    pinfo = projects.get(remote_project, {})
    if not is_remote_project(pinfo):
        handler._send_error_json(400, "Not a remote project")
        return
    user = pinfo.get("user", "")
    host = pinfo.get("host", "")
    address, port = ssh_resolve_address(user, host)
    result = ssh_commit_show(user, address, remote_repo, commit_hash, port=port)
    if "error" in result:
        handler._send_error_json(500, result["error"])
    else:
        handler._send_json(result)


@route("POST", "/api/pull/apply")
def api_pull_apply(handler):
    """Apply selected commits from remote to local repo."""
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    remote_project = body.get("remote_project", "")
    remote_repo = body.get("remote_repo", "")
    local_repo_name = body.get("local_repo_name", "")
    commits = body.get("commits", [])
    method = body.get("method", "")
    if not remote_project or not remote_repo or not local_repo_name or not commits or not method:
        handler._send_error_json(400, "Missing required fields")
        return
    if method not in ("am", "fetch", "save"):
        handler._send_error_json(400, f"Invalid method: {method}")
        return
    from ..commands.query import query_pull_apply
    project_override = _project_param(handler)
    result = query_pull_apply(remote_project, remote_repo, local_repo_name,
                              commits, method, project_override)
    if result["status"] == "ok":
        _invalidate_dashboard_cache(project_override)
        handler.sse.broadcast("repo_updated", {"action": "pull-patches"})
    handler._send_json(result)


# ---------- host addresses ----------

@route("GET", "/api/hosts/addresses")
def api_hosts_addresses_list(handler):
    """List all hosts with their alternate addresses."""
    from ..commands.ssh_remote import get_host_addresses
    from ..commands.projects import load_projects
    from ..commands.ssh_remote import is_remote_project

    # Gather unique hosts from projects
    projects = load_projects()
    hosts = set()
    for pinfo in projects.values():
        if is_remote_project(pinfo):
            hosts.add(pinfo["host"])

    result = {}
    for host in sorted(hosts):
        result[host] = get_host_addresses(host)
    handler._send_json(result)


@route("GET", "/api/hosts/[^/]+/addresses")
def api_host_addresses_get(handler):
    """Get addresses for a specific host."""
    from ..commands.ssh_remote import get_host_addresses
    # Extract host from path: /api/hosts/<host>/addresses
    parts = handler._url_path.split("/")
    host = parts[3] if len(parts) >= 5 else ""
    if not host:
        handler._send_error_json(400, "Missing host")
        return
    addrs = get_host_addresses(host)
    handler._send_json({"host": host, "addresses": addrs})


@route("POST", "/api/hosts/[^/]+/addresses")
def api_host_addresses_set(handler):
    """Save addresses for a specific host."""
    from ..commands.ssh_remote import set_host_addresses
    parts = handler._url_path.split("/")
    host = parts[3] if len(parts) >= 5 else ""
    if not host:
        handler._send_error_json(400, "Missing host")
        return
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    addresses = body.get("addresses", [])
    # Validate entries
    for a in addresses:
        if not isinstance(a, dict) or "address" not in a:
            handler._send_error_json(400, "Each address must have an 'address' field")
            return
        if "port" not in a:
            a["port"] = 22
    set_host_addresses(host, addresses)
    handler._send_json({"ok": True})


# ---------- host tmux session ----------

@route("GET", "/api/hosts/[^/]+/tmux-session")
def api_host_tmux_session_get(handler):
    """Get custom tmux session name for a host."""
    from ..commands.ssh_remote import get_host_tmux_session
    parts = handler._url_path.split("/")
    host = parts[3] if len(parts) >= 5 else ""
    if not host:
        handler._send_error_json(400, "Missing host")
        return
    session = get_host_tmux_session(host)
    handler._send_json({"host": host, "tmux_session": session})


@route("POST", "/api/hosts/[^/]+/tmux-session")
def api_host_tmux_session_set(handler):
    """Set custom tmux session name for a host."""
    from ..commands.ssh_remote import set_host_tmux_session
    parts = handler._url_path.split("/")
    host = parts[3] if len(parts) >= 5 else ""
    if not host:
        handler._send_error_json(400, "Missing host")
        return
    body = handler._read_json()
    if body is None:
        handler._send_error_json(400, "Invalid JSON")
        return
    session = body.get("tmux_session", "")
    set_host_tmux_session(host, session)
    handler._send_json({"ok": True})


# ---------- host metrics ----------

@route("GET", "/api/hosts/metrics")
def api_hosts_metrics(handler):
    """System metrics for all remote hosts."""
    from ..commands.projects import load_projects_for_display
    from ..commands.ssh_remote import is_remote_project, get_all_host_metrics

    projects = load_projects_for_display()
    all_metrics = get_all_host_metrics(projects)

    # Count projects per host
    host_counts: dict = {}
    host_users: dict = {}
    for _path, pinfo in projects.items():
        if not is_remote_project(pinfo):
            continue
        h = pinfo.get("host", "")
        host_counts[h] = host_counts.get(h, 0) + 1
        if h not in host_users:
            host_users[h] = pinfo.get("user", "")

    result = []
    for host, metrics in all_metrics.items():
        result.append({
            "host": host,
            "user": host_users.get(host, ""),
            "project_count": host_counts.get(host, 0),
            "metrics": metrics,
        })
    handler._send_json({"hosts": result})


# ---------------------------------------------------------------------------
# Daemon API
# ---------------------------------------------------------------------------

@route("GET", "/api/daemon/status")
def api_daemon_status(handler):
    """Daemon health and state."""
    from ..daemon import check_daemon_health, load_state, get_daemon_interval

    health = check_daemon_health()
    state = load_state()
    handler._send_json({
        "health": health,
        "interval_minutes": get_daemon_interval(),
        "paused": state.get("paused", False),
        "projects": state.get("projects", {}),
    })


@route("GET", "/api/daemon/log")
def api_daemon_log(handler):
    """Recent daemon log entries."""
    from ..daemon import load_state

    state = load_state()
    log = state.get("log", [])
    # Return last 50 entries by default
    count = int(handler._query_param("count", "50"))
    handler._send_json({"log": log[-count:]})


@route("POST", "/api/daemon/pause")
def api_daemon_pause(handler):
    """Toggle daemon pause state."""
    from ..daemon import load_state, save_state

    body = handler._read_json() or {}
    pause = body.get("paused", True)

    state = load_state()
    state["paused"] = bool(pause)
    save_state(state)

    # If we have a daemon thread, tell it directly
    daemon_thread = getattr(handler.server, "daemon_thread", None)
    if daemon_thread:
        if pause:
            daemon_thread.pause()
        else:
            daemon_thread.resume()

    handler._send_json({"ok": True, "paused": bool(pause)})


@route("POST", "/api/daemon/project-config")
def api_daemon_project_config(handler):
    """Update per-project auto_update config (interval, fetch_only)."""
    from ..commands.projects import load_projects, save_projects

    body = handler._read_json() or {}
    path = body.get("path", "")
    if not path:
        handler._send_error_json(400, "Missing 'path'")
        return

    projects = load_projects()
    if path not in projects:
        handler._send_error_json(404, "Project not found")
        return

    info = projects[path]
    auto_cfg = info.get("auto_update", {})

    if "interval_minutes" in body:
        try:
            mins = int(body["interval_minutes"])
            if mins >= 1:
                auto_cfg["interval_minutes"] = mins
        except (ValueError, TypeError):
            pass

    if "fetch_only" in body:
        auto_cfg["fetch_only"] = bool(body["fetch_only"])

    info["auto_update"] = auto_cfg
    projects[path] = info
    save_projects(projects)
    _invalidate_dashboard_cache(path)

    handler._send_json({"ok": True, "auto_update": auto_cfg})
