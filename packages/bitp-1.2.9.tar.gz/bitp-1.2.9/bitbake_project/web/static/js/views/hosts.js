/* Hosts view — remote host system metrics */
const HostsView = {
  _nav: KeyboardNav({ skipHidden: true }),

  keyBindings: [
    {key: 'j/k', desc: 'Navigate hosts'},
    {key: 'Enter', desc: 'Shell on host', action: 'Enter'},
    {key: 'r', desc: 'Refresh metrics', action: 'r'},
    {key: '/', desc: 'Filter', action: '/'},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) return;
    if (e.key === 'Enter') {
      e.preventDefault();
      const card = this._nav.activeRow();
      if (card) this._openShell(card);
    }
    if (e.key === 'r') {
      e.preventDefault();
      this._load();
    }
    if (e.key === '/') {
      e.preventDefault();
      var input = document.getElementById('hosts-filter');
      if (input) input.focus();
    }
  },

  async render(container, state) {
    container.innerHTML = `
      <div class="view-header">
        <h2>Hosts</h2>
        <span id="hosts-updated" class="text-muted" style="font-size:var(--font-size-sm);margin-left:12px"></span>
      </div>
      <div id="hosts-content" class="loading">Loading</div>
      <div class="search-bar">
        <input type="text" id="hosts-filter" placeholder="Filter hosts...">
        <button class="btn" id="hosts-refresh">Refresh</button>
      </div>
    `;

    document.getElementById('hosts-refresh').addEventListener('click', () => this._load());
    document.getElementById('hosts-filter').addEventListener('input', () => this._filter());

    this._load();

    // Auto-refresh every 15 seconds while on this view
    this._refreshTimer = setInterval(() => this._load(), 15000);
  },

  destroy() {
    if (this._refreshTimer) {
      clearInterval(this._refreshTimer);
      this._refreshTimer = null;
    }
  },

  async _load() {
    const el = document.getElementById('hosts-content');
    if (!el) return;
    el.className = 'loading';
    el.textContent = 'Loading host metrics...';
    try {
      const data = await API.getHostMetrics();
      this._renderCards(data.hosts || []);
      const ts = document.getElementById('hosts-updated');
      if (ts) ts.textContent = 'Updated ' + new Date().toLocaleTimeString();
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  _renderCards(hosts) {
    const el = document.getElementById('hosts-content');
    if (!el) return;
    el.className = '';

    if (!hosts.length) {
      el.innerHTML = '<div class="empty-state"><h3>No remote hosts</h3><p>Add remote projects to see host metrics.</p></div>';
      return;
    }

    el.innerHTML = '<div class="host-cards">' + hosts.map(h => this._renderCard(h)).join('') + '</div>';
    this._nav.setRows(el.querySelectorAll('.host-card'));
    el.querySelectorAll('.host-card').forEach(card => {
      card.style.cursor = 'pointer';
      card.addEventListener('click', () => this._openShell(card));
    });
  },

  _renderCard(host) {
    const m = host.metrics || {};
    const hasError = m.error;
    const hostname = m.hostname || host.host;
    const os = m.os || '';
    const kernel = m.kernel || '';

    const user = host.user || '';
    if (hasError) {
      return `<div class="host-card host-card-error" data-host="${esc(host.host)}" data-user="${esc(user)}">
        <div class="host-card-header">${esc(hostname)}</div>
        <div class="host-card-body"><span class="text-muted">Unreachable</span></div>
        <div class="host-card-footer">${host.project_count} project${host.project_count !== 1 ? 's' : ''}</div>
      </div>`;
    }

    const uptimeDays = Math.floor((m.uptime_sec || 0) / 86400);
    const uptimeStr = uptimeDays > 0 ? uptimeDays + ' days' : Math.floor((m.uptime_sec || 0) / 3600) + ' hours';
    const memTotal = m.mem_total_kb || 0;
    const memAvail = m.mem_avail_kb || 0;
    const memUsed = memTotal - memAvail;
    const memPct = m.mem_pct || 0;
    const memTotalGB = (memTotal / 1048576).toFixed(1);
    const memUsedGB = (memUsed / 1048576).toFixed(1);
    const load1 = (m.load_1 || 0).toFixed(2);
    const load5 = (m.load_5 || 0).toFixed(2);
    const load15 = (m.load_15 || 0).toFixed(2);
    const cpus = m.cpus || 1;

    const disksHtml = (m.disks || []).map(d => {
      const pct = parseInt(d.pct) || 0;
      return `<div class="host-disk-row">
        <span class="host-disk-mount">${esc(d.mount)}</span>
        <div class="host-metric-bar">${this._bar(pct)}</div>
        <span class="host-disk-detail">${esc(d.avail)} / ${esc(d.size)} free</span>
      </div>`;
    }).join('');

    return `<div class="host-card" data-host="${esc(host.host)}" data-user="${esc(user)}">
      <div class="host-card-header">${esc(hostname)}</div>
      <div class="host-card-subtitle">${esc(os)} &middot; kernel ${esc(kernel)}</div>
      <div class="host-card-subtitle">uptime: ${esc(uptimeStr)}</div>
      <div class="host-card-body">
        <div class="host-metric-row">
          <span class="host-metric-label">Load</span>
          <span>${esc(load1)} / ${esc(load5)} / ${esc(load15)}  (${cpus} cores)</span>
        </div>
        <div class="host-metric-row">
          <span class="host-metric-label">Memory</span>
          <div class="host-metric-bar">${this._bar(memPct)}</div>
          <span>${memPct}%  (${memUsedGB} / ${memTotalGB} GB)</span>
        </div>
        ${disksHtml ? '<div class="host-metric-row"><span class="host-metric-label">Disks</span></div>' + disksHtml : ''}
      </div>
      <div class="host-card-footer">${host.project_count} project${host.project_count !== 1 ? 's' : ''} on this host</div>
    </div>`;
  },

  _bar(pct) {
    const cls = pct > 80 ? 'bar-red' : pct > 60 ? 'bar-yellow' : 'bar-green';
    return `<div class="bar-track"><div class="bar-fill ${cls}" style="width:${pct}%"></div></div>`;
  },

  _openShell(card) {
    if (!window.TerminalManager) {
      App.showToast('Terminal not available', 'error');
      return;
    }
    const host = card.dataset.host;
    const user = card.dataset.user;
    if (!host) return;
    const ssh = user ? user + '@' + host : host;
    const session = 'bit-' + host.replace(/[^a-zA-Z0-9_-]/g, '-');
    TerminalManager.show({ ssh, session, title: 'Shell: ' + host });
  },

  _filter() {
    const q = (document.getElementById('hosts-filter').value || '').toLowerCase();
    document.querySelectorAll('.host-card').forEach(card => {
      card.style.display = !q || (card.dataset.host || '').toLowerCase().includes(q) ? '' : 'none';
    });
  },
};
