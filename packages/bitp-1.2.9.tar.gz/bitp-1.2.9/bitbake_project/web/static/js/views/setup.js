/* Setup view — browse configs, clone repos, apply layers
 * Mirrors TUI: bit setup clone, bit setup apply, bit setup configs, bit setup export
 */
const SetupView = {
  _nav: KeyboardNav({ skipHidden: true }),
  _registryData: [],

  keyBindings: [
    {key: 'j/k', desc: 'Navigate rows'},
    {key: 'Enter', desc: 'Select/expand'},
    {key: 'f', desc: 'Fragments', action: 'f'},
    {key: 'r', desc: 'Refresh', action: 'r'},
  ],

  handleKeyboard(e) {
    if (this._nav.handleBasicKeys(e)) return;
    if (e.key === 'Enter') {
      e.preventDefault();
      const row = this._nav.activeRow();
      if (row) row.click();
    } else if (e.key === 'f') {
      e.preventDefault();
      App.navigate('fragments');
    } else if (e.key === 'r') {
      e.preventDefault();
      this._loadRegistry();
    }
  },

  async render(container) {
    const projName = (App.state.selectedProjectName || App.state.selectedProject || App.state.currentProject || '').split('/').pop();
    const titlePrefix = projName ? projName + ': ' : '';
    container.innerHTML = `
      <div class="view-header">
        <h2>${esc(titlePrefix)}Configs</h2>
      </div>
      <div id="setup-tabs" style="margin-bottom:16px">
        <button class="btn btn-primary" data-tab="configs">Configs</button>
        <button class="btn" data-tab="export">Export</button>
        <button class="btn" data-tab="fragments" title="Browse and toggle OE fragments (f)">Fragments</button>
      </div>
      <div id="setup-content" class="loading">Loading</div>
    `;

    document.querySelectorAll('#setup-tabs button').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.dataset.tab === 'fragments') {
          App.navigate('fragments');
          return;
        }
        document.querySelectorAll('#setup-tabs button').forEach(b => b.classList.remove('btn-primary'));
        btn.classList.add('btn-primary');
        if (btn.dataset.tab === 'configs') this._loadRegistry();
        else if (btn.dataset.tab === 'export') this._showExportForm();
      });
    });

    // Check if we should auto-switch to export tab (e.g. from context menu)
    if (App.state.configsTab === 'export') {
      delete App.state.configsTab;
      document.querySelectorAll('#setup-tabs button').forEach(b => b.classList.remove('btn-primary'));
      document.querySelector('#setup-tabs button[data-tab="export"]').classList.add('btn-primary');
      this._showExportForm();
    } else {
      this._loadRegistry();
    }
  },

  _project() { return App.state.selectedProject || ''; },

  async _loadRegistry() {
    const el = document.getElementById('setup-content');
    el.className = 'loading';
    el.textContent = 'Scanning registries...';
    try {
      const data = await API.getSetupRegistry(this._project());
      this._registryData = data;
      this._renderRegistry(data);
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Error</h3><p>${esc(e.message)}</p></div>`;
    }
  },

  /** Flatten registry entries into one row per configuration, matching TUI `bit setup configs`. */
  _renderRegistry(entries) {
    const el = document.getElementById('setup-content');
    el.className = '';

    // Flatten: one row per configuration (not per file)
    const rows = [];
    if (entries) {
      for (const entry of entries) {
        if (entry.configurations && entry.configurations.length) {
          for (const cfg of entry.configurations) {
            rows.push({ entry, cfg });
          }
        }
      }
    }

    if (!rows.length) {
      el.innerHTML = `<div class="empty-state">
        <h3>No configurations found</h3>
        <p>No .conf.json files found in registries.</p>
        <p style="color:var(--text-muted);font-size:var(--font-size-sm)">
          Expected locations:<br>
          &bull; layers/bitbake/default-registry/<br>
          &bull; ~/.config/bit/registry/
        </p>
        <p style="margin-top:12px">Use <strong>Export</strong> to save the current project state.</p>
      </div>`;
      return;
    }

    let html = '<table class="data-table" id="setup-registry-table"><thead><tr>';
    html += '<th></th><th>Source</th><th>File</th><th>Config</th><th>Description</th><th></th>';
    html += '</tr></thead><tbody>';

    // Pinned Basic Clone row (matches TUI BASIC_CLONE_SENTINEL)
    html += `<tr class="setup-entry setup-basic-row" style="cursor:pointer;background:var(--bg-secondary)">
      <td style="width:2ch"></td>
      <td style="white-space:nowrap"><span class="badge">Basic</span></td>
      <td style="color:var(--cyan)">---</td>
      <td style="color:var(--accent)">basic</td>
      <td>Clone bitbake + oe-core + meta-yocto (no .conf.json)</td>
      <td style="white-space:nowrap">
        <button class="btn btn-sm btn-primary setup-basic-clone-btn">Clone</button>
      </td>
    </tr>`;

    for (let i = 0; i < rows.length; i++) {
      const { entry, cfg } = rows[i];
      const rowId = `setup-row-${i}`;
      // Strip .conf.json suffix for display
      const fname = (entry.filename || '').replace(/\.conf\.json$/, '');
      html += `<tr class="setup-entry" data-idx="${i}" data-path="${esc(entry.path)}" data-config="${esc(cfg.name)}" style="cursor:pointer">
        <td style="width:2ch"><span class="setup-row-toggle">\u25b8</span></td>
        <td style="white-space:nowrap"><span class="badge">${esc(entry.source)}</span></td>
        <td style="color:var(--cyan);white-space:nowrap">${esc(fname)}</td>
        <td style="color:var(--accent);white-space:nowrap">${esc(cfg.name)}</td>
        <td>${esc(cfg.description || entry.description || '')}</td>
        <td style="white-space:nowrap">
          <button class="btn btn-sm setup-clone-btn" data-path="${esc(entry.path)}" data-config="${esc(cfg.name)}">Clone</button>
          <button class="btn btn-sm setup-apply-btn" data-path="${esc(entry.path)}" data-config="${esc(cfg.name)}">Apply</button>
          <button class="btn btn-sm setup-copy-btn" data-path="${esc(entry.path)}" title="Copy to user registry">Copy</button>
          ${entry.source === 'User' ? `
            <button class="btn btn-sm setup-describe-btn" data-path="${esc(entry.path)}" data-desc="${esc(entry.description || '')}">Describe</button>
            <button class="btn btn-sm setup-rename-btn" data-path="${esc(entry.path)}" data-fname="${esc(entry.filename || '')}">Rename</button>
            <button class="btn btn-sm setup-delete-btn" data-path="${esc(entry.path)}" style="color:var(--red)">Delete</button>
          ` : ''}
        </td>
      </tr>`;

      // Expandable detail row (hidden initially)
      html += `<tr class="setup-detail" data-detail="${i}" style="display:none">
        <td colspan="6" style="padding:0">
          <div style="padding:12px 16px;background:var(--bg-secondary)">
            ${this._renderConfigDetail(entry, cfg)}
          </div>
        </td>
      </tr>`;
    }

    html += '</tbody></table>';
    el.innerHTML = html;

    // Row click → toggle detail
    el.querySelectorAll('tr.setup-entry').forEach(row => {
      row.addEventListener('click', (e) => {
        // Don't toggle if clicking action buttons
        if (e.target.closest('.btn')) return;
        const idx = row.dataset.idx;
        const detail = el.querySelector(`tr[data-detail="${idx}"]`);
        if (detail) {
          const visible = detail.style.display !== 'none';
          detail.style.display = visible ? 'none' : '';
          const toggle = row.querySelector('.setup-row-toggle');
          if (toggle) toggle.textContent = visible ? '\u25b8' : '\u25be';
        }
      });
    });

    // Clone buttons
    el.querySelectorAll('.setup-clone-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._doClone(btn.dataset.path, btn.dataset.config);
      });
    });

    // Apply buttons
    el.querySelectorAll('.setup-apply-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._doApply(btn.dataset.path, btn.dataset.config);
      });
    });

    // Copy buttons
    el.querySelectorAll('.setup-copy-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._doCopy(btn.dataset.path);
      });
    });

    // Describe buttons (User configs only)
    el.querySelectorAll('.setup-describe-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._doDescribe(btn.dataset.path, btn.dataset.desc);
      });
    });

    // Rename buttons (User configs only)
    el.querySelectorAll('.setup-rename-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._doRename(btn.dataset.path, btn.dataset.fname);
      });
    });

    // Delete buttons (User configs only)
    el.querySelectorAll('.setup-delete-btn').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        this._doDelete(btn.dataset.path);
      });
    });

    // Basic Clone button
    el.querySelectorAll('.setup-basic-clone-btn').forEach(btn => {
      btn.addEventListener('click', async (e) => {
        e.stopPropagation();
        const dir = await pathBrowser('~', { title: 'Clone Destination', allowNew: true });
        if (!dir) return;
        const branch = await promptModal('Branch:', 'master');
        if (branch === null) return;
        const name = dir.split('/').filter(Boolean).pop() || 'project';
        App.showToast('Cloning core repos...');
        try {
          await API.setupClone({
            basic: true,
            branch: branch || 'master',
            project_dir: dir,
            register_project: true,
            name: name,
          });
          App.showToast('Clone started — project will be registered when done', 'success');
        } catch (err) {
          App.showToast('Clone failed: ' + err.message, 'error');
        }
      });
    });

    this._nav.setRows(el.querySelectorAll('tr.setup-entry'));
  },

  /** Render detail for a single configuration within its parent entry. */
  _renderConfigDetail(entry, cfg) {
    let html = '';

    // Sources (from the parent .conf.json file)
    if (entry.sources && entry.sources.length) {
      html += '<div style="margin-bottom:8px"><strong>Sources</strong> (' + entry.sources.length + ' repos)</div>';
      html += '<table class="data-table" style="margin-bottom:12px"><thead><tr>';
      html += '<th>Name</th><th>URL</th><th>Branch</th>';
      html += '</tr></thead><tbody>';
      for (const src of entry.sources) {
        const url = src.is_local ? '<em>local</em>' : esc(src.git_url);
        html += `<tr>
          <td style="color:var(--cyan)">${esc(src.name)}</td>
          <td style="color:var(--text-muted);font-size:var(--font-size-sm);word-break:break-all">${url}</td>
          <td>${esc(src.branch || '')}</td>
        </tr>`;
      }
      html += '</tbody></table>';
    }

    // Layers
    if (cfg.bb_layers && cfg.bb_layers.length) {
      html += `<div style="margin-bottom:4px"><strong>Layers</strong></div>`;
      html += `<div style="font-size:var(--font-size-sm);margin-bottom:12px">${cfg.bb_layers.map(l => esc(l)).join(', ')}</div>`;
    }

    // Fragments
    if (cfg.oe_fragments && cfg.oe_fragments.length) {
      html += `<div style="margin-bottom:4px"><strong>Fragments</strong></div>`;
      html += `<div style="font-size:var(--font-size-sm);margin-bottom:12px">${cfg.oe_fragments.map(f => esc(f)).join(', ')}</div>`;
    }

    // Fragment choices (one-of)
    if (cfg.oe_fragments_one_of && Object.keys(cfg.oe_fragments_one_of).length) {
      for (const [cat, data] of Object.entries(cfg.oe_fragments_one_of)) {
        const opts = data.options ? data.options.map(o => esc(o.name)).join(', ') : '';
        html += `<div style="font-size:var(--font-size-sm);margin-bottom:4px"><span style="color:var(--text-muted)">${esc(cat)}:</span> ${opts}</div>`;
      }
    }

    return html || '<em>No details available</em>';
  },

  async _doClone(configPath, configName) {
    const projectDir = await pathBrowser('~', { title: 'Clone Destination', allowNew: true });
    if (!projectDir) return;  // cancelled

    const name = projectDir.split('/').filter(Boolean).pop() || 'project';
    App.showToast('Cloning repos...');
    try {
      await API.setupClone({
        config_file: configPath,
        config_name: configName,
        project_dir: projectDir,
        register_project: true,
        name: name,
      });
      App.showToast('Clone started — project will be registered when done', 'success');
    } catch (e) {
      App.showToast('Clone failed: ' + e.message, 'error');
    }
  },

  async _doCopy(configPath) {
    // Pre-fill with current filename minus .conf.json
    const basename = configPath.split('/').pop().replace(/\.conf\.json$/, '');
    const name = await promptModal('Name for registry copy:', basename);
    if (name === null) return;  // cancelled

    App.showToast('Copying to registry...');
    try {
      const result = await API.setupRegistryCopy({
        source_path: configPath,
        target_name: name || basename,
      });
      App.showToast(`Copied to registry: ${result.basename}`, 'success');
      // Refresh to show the new User entry
      this._loadRegistry();
    } catch (e) {
      App.showToast('Copy failed: ' + e.message, 'error');
    }
  },

  async _doApply(configPath, configName) {
    App.showToast('Applying configuration...');
    try {
      const result = await API.setupApply({
        config_file: configPath,
        config_name: configName,
      }, this._project());
      const added = result.added_layers || [];
      App.showToast(`Applied: ${added.length} layers added`, 'success');
    } catch (e) {
      App.showToast('Apply failed: ' + e.message, 'error');
    }
  },

  async _doDescribe(path, currentDesc) {
    const description = await promptModal('Description:', currentDesc || '');
    if (description === null) return;  // cancelled
    try {
      await API.setupDescribe({ path, description });
      App.showToast('Description updated', 'success');
      this._loadRegistry();
    } catch (e) {
      App.showToast('Failed: ' + e.message, 'error');
    }
  },

  async _doRename(path, currentFname) {
    const baseName = (currentFname || '').replace(/\.conf\.json$/, '');
    const newName = await promptModal('New name:', baseName);
    if (newName === null || !newName.trim()) return;
    try {
      await API.setupRename({ path, new_name: newName.trim() });
      App.showToast('Config renamed', 'success');
      this._loadRegistry();
    } catch (e) {
      App.showToast('Rename failed: ' + e.message, 'error');
    }
  },

  async _doDelete(path) {
    const ok = await confirmModal('Delete this configuration? This cannot be undone.');
    if (!ok) return;
    try {
      await API.setupDelete({ path });
      App.showToast('Config deleted', 'success');
      this._loadRegistry();
    } catch (e) {
      App.showToast('Delete failed: ' + e.message, 'error');
    }
  },

  async _showExportForm() {
    const el = document.getElementById('setup-content');
    el.className = 'loading';
    el.textContent = 'Loading export data...';

    let preview;
    try {
      preview = await API.getSetupExportPreview(this._project());
    } catch (e) {
      el.className = '';
      el.innerHTML = `<div class="empty-state"><h3>Cannot export</h3><p>${esc(e.message)}</p></div>`;
      return;
    }

    const nSources = Object.keys(preview.sources || {}).length;
    const nLayers = (preview.relative_layers || []).length;
    const nFragments = (preview.fragments || []).length;
    const summary = `${nSources} repos, ${nLayers} layers, ${nFragments} fragments`;

    let fragmentsHtml;
    if (nFragments > 0) {
      fragmentsHtml = (preview.fragments || []).map(f =>
        `<label style="display:flex;align-items:center;gap:6px;margin-bottom:4px">
          <input type="checkbox" class="export-frag-cb" value="${esc(f)}" checked> ${esc(f)}
        </label>`
      ).join('');
    } else {
      fragmentsHtml = '<span style="color:var(--text-muted)">(no OE fragments configured)</span>';
    }

    el.className = '';
    el.innerHTML = `
      <div style="max-width:600px">
        <h3 style="margin-bottom:8px">Export Configuration</h3>
        <p style="color:var(--text-muted);margin-bottom:16px">${esc(summary)}</p>
        <div class="form-group" style="margin-bottom:12px">
          <label style="display:block;margin-bottom:4px;color:var(--text-muted)">Configuration name</label>
          <input type="text" id="setup-export-name" value="${esc(preview.project_name || 'exported')}" style="width:100%;padding:6px 8px;background:var(--bg-secondary);border:1px solid var(--border);color:var(--text-primary);border-radius:4px">
        </div>
        <div class="form-group" style="margin-bottom:12px">
          <label style="display:block;margin-bottom:4px;color:var(--text-muted)">Description</label>
          <input type="text" id="setup-export-desc" value="" placeholder="Optional description" style="width:100%;padding:6px 8px;background:var(--bg-secondary);border:1px solid var(--border);color:var(--text-primary);border-radius:4px">
        </div>
        <div class="form-group" style="margin-bottom:16px">
          <label style="display:block;margin-bottom:4px;color:var(--text-muted)">Fragments</label>
          ${fragmentsHtml}
        </div>
        <div style="display:flex;gap:8px">
          <button class="btn btn-primary" id="setup-export-file">Export to file</button>
          <button class="btn" id="setup-export-registry">Export to registry</button>
        </div>
      </div>
    `;

    const doExport = async (registry) => {
      const name = document.getElementById('setup-export-name').value.trim() || 'exported';
      const description = document.getElementById('setup-export-desc').value.trim();
      const fragments = Array.from(el.querySelectorAll('.export-frag-cb:checked')).map(cb => cb.value);

      App.showToast('Exporting...');
      try {
        const result = await API.setupExport({ name, description, fragments, registry }, this._project());
        let msg = `Exported to ${result.path}`;
        if (result.registry_path) msg += ' and registry';
        App.showToast(msg, 'success');
      } catch (e) {
        App.showToast('Export failed: ' + e.message, 'error');
      }
    };

    document.getElementById('setup-export-file').addEventListener('click', () => doExport(false));
    document.getElementById('setup-export-registry').addEventListener('click', () => doExport(true));
  },
};
