#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tag and pane helpers for project organisation.

Tags are user-defined labels on projects.  Panes are saved tag filters
that act as switchable views/tabs in the dashboard.
"""

import json
import os
from typing import Dict, List, Optional, Set


# ---------------------------------------------------------------------------
# Effective tags
# ---------------------------------------------------------------------------

def get_effective_tags(info: dict) -> Set[str]:
    """Return effective tags for a project.

    Never stored — always computed at read time so existing projects
    with no tags automatically match their persona pane.

    Effective tags = (remote_tags - hidden_tags) + local tags + persona.
    For local projects without remote fields this reduces to tags + persona.
    """
    remote = set(info.get("remote_tags") or [])
    hidden = set(info.get("hidden_tags") or [])
    local = set(info.get("tags") or [])
    # Persona: prefer local, fall back to remote_persona, then "yocto"
    persona = info.get("persona") or info.get("remote_persona") or "yocto"
    return (remote - hidden) | local | {persona}


def matches_pane(info: dict, pane: dict) -> bool:
    """True when a project should appear in *pane*.

    Empty ``tags`` list on a pane means "show everything" (the All pane).
    Otherwise the project matches if its effective tags **intersect** the
    pane's tags (OR logic).
    """
    pane_tags = pane.get("tags") or []
    if not pane_tags:
        return True  # "All" pane
    return bool(get_effective_tags(info) & set(pane_tags))


def all_tags(projects: Dict[str, dict]) -> Set[str]:
    """Collect every tag across all projects (for autocomplete).

    Includes remote tags even if hidden, so they remain available
    in the tag pool for pane definitions and autocomplete.
    """
    tags: Set[str] = set()
    for info in projects.values():
        tags.update(get_effective_tags(info))
        tags.update(info.get("remote_tags") or [])
    return tags


# ---------------------------------------------------------------------------
# Pane storage  (lives inside projects.json as __panes__ / __active_pane__)
# ---------------------------------------------------------------------------

_DEFAULT_PANES = [
    {"name": "All", "tags": [], "builtin": True},
    {"name": "Yocto", "tags": ["yocto"], "builtin": True},
    {"name": "Generic", "tags": ["generic"], "builtin": True},
]


def _get_projects_file() -> str:
    config_dir = os.path.expanduser("~/.config/bit")
    os.makedirs(config_dir, exist_ok=True)
    return os.path.join(config_dir, "projects.json")


def _read_raw() -> dict:
    path = _get_projects_file()
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}


def _write_raw(data: dict) -> None:
    path = _get_projects_file()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w") as f:
        json.dump(data, f, indent=2)


# ---------------------------------------------------------------------------
# Pane CRUD
# ---------------------------------------------------------------------------

def load_panes() -> List[dict]:
    """Read ``__panes__`` from projects.json, defaulting to built-ins."""
    data = _read_raw()
    panes = data.get("__panes__")
    if panes is None:
        return [dict(p) for p in _DEFAULT_PANES]
    return panes


def save_panes(panes: List[dict]) -> None:
    """Write ``__panes__`` back to projects.json."""
    data = _read_raw()
    data["__panes__"] = panes
    _write_raw(data)


def get_active_pane() -> str:
    """Read ``__active_pane__`` (defaults to ``'All'``)."""
    data = _read_raw()
    return data.get("__active_pane__", "All")


def set_active_pane(name: str) -> None:
    """Write ``__active_pane__``."""
    data = _read_raw()
    data["__active_pane__"] = name
    _write_raw(data)


def find_pane(name: str, panes: Optional[List[dict]] = None) -> Optional[dict]:
    """Look up a pane by name.  Returns ``None`` if not found."""
    if panes is None:
        panes = load_panes()
    for p in panes:
        if p["name"] == name:
            return p
    return None


def create_or_update_pane(name: str, tags: List[str]) -> List[dict]:
    """Create a new pane or update an existing one.  Returns updated list."""
    panes = load_panes()
    for p in panes:
        if p["name"] == name:
            p["tags"] = tags
            save_panes(panes)
            return panes
    panes.append({"name": name, "tags": tags})
    save_panes(panes)
    return panes


def rename_pane(old_name: str, new_name: str) -> List[dict]:
    """Rename a non-builtin pane.  Returns updated list.

    Raises ``ValueError`` if the pane is builtin, not found, or *new_name*
    collides with an existing pane.
    """
    if not new_name or not new_name.strip():
        raise ValueError("Pane name cannot be empty")
    new_name = new_name.strip()
    panes = load_panes()
    target = None
    for p in panes:
        if p["name"] == old_name:
            if p.get("builtin"):
                raise ValueError(f"Cannot rename built-in pane '{old_name}'")
            target = p
        if p["name"] == new_name:
            raise ValueError(f"Pane '{new_name}' already exists")
    if target is None:
        raise ValueError(f"Pane '{old_name}' not found")
    target["name"] = new_name
    save_panes(panes)
    if get_active_pane() == old_name:
        set_active_pane(new_name)
    return panes


def delete_pane(name: str) -> List[dict]:
    """Delete a non-builtin pane.  Returns updated list.

    Raises ``ValueError`` if the pane is builtin or not found.
    """
    panes = load_panes()
    for p in panes:
        if p["name"] == name:
            if p.get("builtin"):
                raise ValueError(f"Cannot delete built-in pane '{name}'")
            panes.remove(p)
            save_panes(panes)
            # Reset active pane to All if the deleted pane was active
            if get_active_pane() == name:
                set_active_pane("All")
            return panes
    raise ValueError(f"Pane '{name}' not found")


# ---------------------------------------------------------------------------
# Project tag CRUD  (convenience wrappers around projects.json)
# ---------------------------------------------------------------------------

def set_project_tags(path: str, tags: List[str]) -> None:
    """Set the explicit tags on a project."""
    data = _read_raw()
    if path not in data:
        raise KeyError(f"Project '{path}' not found")
    data[path]["tags"] = tags
    _write_raw(data)


def get_project_tags(path: str) -> List[str]:
    """Get the explicit tags on a project (empty list if none)."""
    data = _read_raw()
    info = data.get(path, {})
    return list(info.get("tags") or [])


def set_project_hidden_tags(path: str, hidden: List[str]) -> None:
    """Set the hidden_tags on a project (suppresses matching remote tags)."""
    data = _read_raw()
    if path not in data:
        raise KeyError(f"Project '{path}' not found")
    data[path]["hidden_tags"] = hidden
    _write_raw(data)


def get_project_hidden_tags(path: str) -> List[str]:
    """Get the hidden_tags on a project (empty list if none)."""
    data = _read_raw()
    info = data.get(path, {})
    return list(info.get("hidden_tags") or [])


def get_project_remote_tags(path: str) -> List[str]:
    """Get the remote_tags on a project (empty list if none)."""
    data = _read_raw()
    info = data.get(path, {})
    return list(info.get("remote_tags") or [])
