#
# Copyright (C) 2025 Bruce Ashfield <bruce.ashfield@gmail.com>
#
# SPDX-License-Identifier: GPL-2.0-only
#
"""Tests for the auto-update daemon: locking, heartbeat, state, CLI commands."""

import json
import os
import tempfile
import threading
import time
from unittest import mock

import pytest

from bitbake_project.daemon import (
    AutoUpdateDaemon,
    RepoLock,
    _pid_alive,
    _sanitize_path,
    check_daemon_health,
    get_daemon_interval,
    get_lock_holder,
    heartbeat_path,
    load_state,
    read_heartbeat,
    remove_heartbeat,
    save_state,
    set_daemon_interval,
    state_path,
    write_heartbeat,
)


# ---------------------------------------------------------------------------
# RepoLock
# ---------------------------------------------------------------------------

class TestSanitizePath:
    def test_simple(self):
        assert _sanitize_path("/home/user/repo") == "home_user_repo"

    def test_trailing_slash(self):
        assert _sanitize_path("/a/b/c/") == "a_b_c"

    def test_spaces(self):
        assert _sanitize_path("/my path/repo") == "my_path_repo"


class TestRepoLock:
    """Tests for RepoLock acquire/release."""

    def test_acquire_release(self, tmp_path):
        """Basic acquire and release."""
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            lock = RepoLock("/fake/repo", actor="test")
            assert lock.acquire(blocking=False)
            assert lock.is_locked
            lock.release()
            assert not lock.is_locked

    def test_context_manager(self, tmp_path):
        """Lock works as context manager."""
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            with RepoLock("/fake/repo", actor="test") as lock:
                assert lock.is_locked
            assert not lock.is_locked

    def test_nonblocking_conflict(self, tmp_path):
        """Second non-blocking acquire fails when lock is held."""
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            lock1 = RepoLock("/fake/repo", actor="test1")
            lock2 = RepoLock("/fake/repo", actor="test2")

            assert lock1.acquire(blocking=False)
            assert not lock2.acquire(blocking=False)

            lock1.release()
            assert lock2.acquire(blocking=False)
            lock2.release()

    def test_blocking_timeout(self, tmp_path):
        """Blocking acquire with short timeout fails when lock is held."""
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            lock1 = RepoLock("/fake/repo", actor="test1")
            lock2 = RepoLock("/fake/repo", actor="test2")

            assert lock1.acquire(blocking=False)
            start = time.monotonic()
            assert not lock2.acquire(blocking=True, timeout=0.5)
            elapsed = time.monotonic() - start
            assert elapsed >= 0.4  # waited at least close to timeout

            lock1.release()

    def test_lock_info_written(self, tmp_path):
        """Lock file contains PID and actor info."""
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            lock = RepoLock("/fake/repo", actor="daemon")
            lock.acquire(blocking=False)

            lock_file = os.path.join(str(tmp_path), "fake_repo.lock")
            with open(lock_file, "r") as f:
                data = json.load(f)
            assert data["pid"] == os.getpid()
            assert data["actor"] == "daemon"
            assert "started" in data

            lock.release()

    def test_stale_lock_recovery(self, tmp_path):
        """Stale lock (dead PID) is recovered."""
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            # Create a lock file with a dead PID
            lock_file = os.path.join(str(tmp_path), "fake_repo.lock")
            with open(lock_file, "w") as f:
                json.dump({"pid": 999999999, "started": time.time(), "actor": "old"}, f)

            lock = RepoLock("/fake/repo", actor="new")
            assert lock.acquire(blocking=False)
            lock.release()

    def test_concurrent_threads(self, tmp_path):
        """Multiple threads compete for the same lock."""
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            acquired = []
            barrier = threading.Barrier(3)

            def worker(name):
                barrier.wait()
                lock = RepoLock("/fake/repo", actor=name)
                if lock.acquire(blocking=True, timeout=3.0):
                    acquired.append(name)
                    time.sleep(0.1)
                    lock.release()

            threads = [threading.Thread(target=worker, args=(f"t{i}",)) for i in range(3)]
            for t in threads:
                t.start()
            for t in threads:
                t.join(timeout=10)

            # All three should eventually acquire
            assert len(acquired) == 3

    def test_context_manager_timeout_raises(self, tmp_path):
        """Context manager raises TimeoutError when lock can't be acquired."""
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            lock1 = RepoLock("/fake/repo", actor="holder")
            lock1.acquire(blocking=False)

            lock2 = RepoLock("/fake/repo", actor="waiter")
            # Patch acquire to use short timeout
            original_acquire = lock2.acquire
            lock2.acquire = lambda blocking=True, timeout=10.0: original_acquire(blocking, 0.3)

            with pytest.raises(TimeoutError):
                with lock2:
                    pass  # pragma: no cover

            lock1.release()


class TestGetLockHolder:
    def test_no_lock(self, tmp_path):
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            assert get_lock_holder("/nonexistent/repo") is None

    def test_active_lock(self, tmp_path):
        with mock.patch("bitbake_project.daemon._locks_dir", return_value=str(tmp_path)):
            lock = RepoLock("/fake/repo", actor="test")
            lock.acquire(blocking=False)

            holder = get_lock_holder("/fake/repo")
            assert holder is not None
            assert holder["pid"] == os.getpid()
            assert holder["actor"] == "test"

            lock.release()


# ---------------------------------------------------------------------------
# Heartbeat
# ---------------------------------------------------------------------------

class TestHeartbeat:
    def test_write_read(self, tmp_path):
        hb_file = str(tmp_path / "daemon.heartbeat")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file):
            write_heartbeat(projects_checked=5, errors=1)
            data = read_heartbeat()
            assert data is not None
            assert data["pid"] == os.getpid()
            assert data["projects_checked"] == 5
            assert data["errors"] == 1
            assert "timestamp" in data

    def test_read_missing(self, tmp_path):
        hb_file = str(tmp_path / "nonexistent.heartbeat")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file):
            assert read_heartbeat() is None

    def test_remove(self, tmp_path):
        hb_file = str(tmp_path / "daemon.heartbeat")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file):
            write_heartbeat()
            assert os.path.isfile(hb_file)
            remove_heartbeat()
            assert not os.path.isfile(hb_file)


# ---------------------------------------------------------------------------
# State file
# ---------------------------------------------------------------------------

class TestState:
    def test_load_empty(self, tmp_path):
        sf = str(tmp_path / "daemon.state.json")
        with mock.patch("bitbake_project.daemon.state_path", return_value=sf):
            assert load_state() == {}

    def test_save_load(self, tmp_path):
        sf = str(tmp_path / "daemon.state.json")
        with mock.patch("bitbake_project.daemon.state_path", return_value=sf):
            state = {"paused": True, "interval_minutes": 30, "projects": {}, "log": []}
            save_state(state)
            loaded = load_state()
            assert loaded["paused"] is True
            assert loaded["interval_minutes"] == 30


# ---------------------------------------------------------------------------
# check_daemon_health
# ---------------------------------------------------------------------------

class TestDaemonHealth:
    def test_not_configured(self, tmp_path):
        hb_file = str(tmp_path / "nonexistent.heartbeat")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.commands.projects.load_projects", return_value={}):
            health = check_daemon_health()
            assert health["status"] == "not_configured"

    def test_stopped_with_auto_update_projects(self, tmp_path):
        hb_file = str(tmp_path / "nonexistent.heartbeat")
        projects = {"/test": {"tags": ["auto-update"]}}
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.commands.projects.load_projects", return_value=projects), \
             mock.patch("bitbake_project.tags.get_effective_tags", return_value={"auto-update"}):
            health = check_daemon_health()
            assert health["status"] == "stopped"

    def test_running(self, tmp_path):
        hb_file = str(tmp_path / "daemon.heartbeat")
        sf = str(tmp_path / "daemon.state.json")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.daemon.state_path", return_value=sf):
            write_heartbeat(projects_checked=3, errors=0)
            health = check_daemon_health()
            assert health["status"] == "running"

    def test_dead_pid(self, tmp_path):
        hb_file = str(tmp_path / "daemon.heartbeat")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file):
            # Write heartbeat with dead PID
            with open(hb_file, "w") as f:
                json.dump({"pid": 999999999, "timestamp": time.time()}, f)
            health = check_daemon_health()
            assert health["status"] == "dead"

    def test_stale(self, tmp_path):
        hb_file = str(tmp_path / "daemon.heartbeat")
        sf = str(tmp_path / "daemon.state.json")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.daemon.state_path", return_value=sf):
            # Write heartbeat with old timestamp but our PID
            with open(hb_file, "w") as f:
                json.dump({"pid": os.getpid(), "timestamp": time.time() - 300}, f)
            health = check_daemon_health()
            assert health["status"] == "stale"

    def test_paused(self, tmp_path):
        hb_file = str(tmp_path / "daemon.heartbeat")
        sf = str(tmp_path / "daemon.state.json")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.daemon.state_path", return_value=sf):
            write_heartbeat()
            save_state({"paused": True})
            health = check_daemon_health()
            assert health["status"] == "paused"


# ---------------------------------------------------------------------------
# _pid_alive
# ---------------------------------------------------------------------------

class TestPidAlive:
    def test_current_process(self):
        assert _pid_alive(os.getpid()) is True

    def test_dead_pid(self):
        assert _pid_alive(999999999) is False


# ---------------------------------------------------------------------------
# Daemon interval config
# ---------------------------------------------------------------------------

class TestDaemonInterval:
    def test_get_default(self, tmp_path):
        pf = str(tmp_path / "projects.json")
        with open(pf, "w") as f:
            json.dump({}, f)
        with mock.patch("bitbake_project.daemon._config_dir", return_value=str(tmp_path)), \
             mock.patch("bitbake_project.commands.projects._get_projects_file", return_value=pf):
            assert get_daemon_interval() == 60

    def test_set_get(self, tmp_path):
        pf = str(tmp_path / "projects.json")
        with open(pf, "w") as f:
            json.dump({}, f)
        with mock.patch("bitbake_project.commands.projects._get_projects_file", return_value=pf):
            set_daemon_interval(30)
            with open(pf, "r") as f:
                data = json.load(f)
            assert data["__daemon__"]["interval_minutes"] == 30


# ---------------------------------------------------------------------------
# AutoUpdateDaemon (unit-level, no real git)
# ---------------------------------------------------------------------------

class TestAutoUpdateDaemon:
    def test_start_stop(self, tmp_path):
        """Daemon thread starts and stops cleanly."""
        hb_file = str(tmp_path / "daemon.heartbeat")
        sf = str(tmp_path / "daemon.state.json")
        pf = str(tmp_path / "projects.json")
        with open(pf, "w") as f:
            json.dump({}, f)

        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.daemon.state_path", return_value=sf), \
             mock.patch("bitbake_project.daemon._config_dir", return_value=str(tmp_path)), \
             mock.patch("bitbake_project.commands.projects._get_projects_file", return_value=pf):
            daemon = AutoUpdateDaemon(sse_manager=None)
            daemon.start()
            # Wait for at least one heartbeat
            time.sleep(0.5)
            assert daemon.is_alive()
            daemon.stop()
            daemon.join(timeout=5)
            assert not daemon.is_alive()

    def test_pause_resume(self, tmp_path):
        """Daemon can be paused and resumed."""
        hb_file = str(tmp_path / "daemon.heartbeat")
        sf = str(tmp_path / "daemon.state.json")
        pf = str(tmp_path / "projects.json")
        with open(pf, "w") as f:
            json.dump({}, f)

        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.daemon.state_path", return_value=sf), \
             mock.patch("bitbake_project.daemon._config_dir", return_value=str(tmp_path)), \
             mock.patch("bitbake_project.commands.projects._get_projects_file", return_value=pf):
            daemon = AutoUpdateDaemon(sse_manager=None)
            daemon.start()
            time.sleep(0.3)

            daemon.pause()
            state = load_state()
            assert state["paused"] is True

            daemon.resume()
            state = load_state()
            assert state["paused"] is False

            daemon.stop()
            daemon.join(timeout=5)

    def test_tick_no_projects(self, tmp_path):
        """Tick with no auto-update projects is a no-op."""
        hb_file = str(tmp_path / "daemon.heartbeat")
        sf = str(tmp_path / "daemon.state.json")
        pf = str(tmp_path / "projects.json")
        with open(pf, "w") as f:
            json.dump({"/fake/project": {"name": "test", "tags": [], "persona": "generic"}}, f)

        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.daemon.state_path", return_value=sf), \
             mock.patch("bitbake_project.daemon._config_dir", return_value=str(tmp_path)), \
             mock.patch("bitbake_project.commands.projects._get_projects_file", return_value=pf):
            daemon = AutoUpdateDaemon(sse_manager=None)
            daemon._tick()
            state = load_state()
            # No projects should be in state since none have auto-update tag
            assert state.get("projects", {}) == {}


# ---------------------------------------------------------------------------
# CLI commands (daemon_cmd.py)
# ---------------------------------------------------------------------------

class TestDaemonCommands:
    def test_status_not_configured(self, tmp_path, capsys):
        from bitbake_project.commands.daemon_cmd import run_daemon_status
        hb_file = str(tmp_path / "nonexistent.heartbeat")
        with mock.patch("bitbake_project.daemon.heartbeat_path", return_value=hb_file), \
             mock.patch("bitbake_project.commands.projects.load_projects", return_value={}):
            args = mock.Mock()
            ret = run_daemon_status(args)
            assert ret == 0
            out = capsys.readouterr().out
            assert "not_configured" in out

    def test_pause_resume(self, tmp_path, capsys):
        from bitbake_project.commands.daemon_cmd import run_daemon_pause, run_daemon_resume
        sf = str(tmp_path / "daemon.state.json")
        with mock.patch("bitbake_project.daemon.state_path", return_value=sf):
            args = mock.Mock()
            run_daemon_pause(args)
            state = load_state()
            assert state["paused"] is True

            run_daemon_resume(args)
            state = load_state()
            assert state["paused"] is False

    def test_interval_show(self, tmp_path, capsys):
        from bitbake_project.commands.daemon_cmd import run_daemon_interval
        pf = str(tmp_path / "projects.json")
        with open(pf, "w") as f:
            json.dump({"__daemon__": {"interval_minutes": 45}}, f)
        with mock.patch("bitbake_project.commands.projects._get_projects_file", return_value=pf):
            args = mock.Mock(minutes=None)
            ret = run_daemon_interval(args)
            assert ret == 0
            out = capsys.readouterr().out
            assert "45" in out

    def test_interval_set(self, tmp_path, capsys):
        from bitbake_project.commands.daemon_cmd import run_daemon_interval
        pf = str(tmp_path / "projects.json")
        with open(pf, "w") as f:
            json.dump({}, f)
        with mock.patch("bitbake_project.commands.projects._get_projects_file", return_value=pf):
            args = mock.Mock(minutes=15)
            ret = run_daemon_interval(args)
            assert ret == 0
            with open(pf, "r") as f:
                data = json.load(f)
            assert data["__daemon__"]["interval_minutes"] == 15

    def test_log_empty(self, tmp_path, capsys):
        from bitbake_project.commands.daemon_cmd import run_daemon_log
        sf = str(tmp_path / "daemon.state.json")
        with mock.patch("bitbake_project.daemon.state_path", return_value=sf):
            args = mock.Mock(count=20)
            ret = run_daemon_log(args)
            assert ret == 0
            out = capsys.readouterr().out
            assert "No daemon log" in out

    def test_log_with_entries(self, tmp_path, capsys):
        from bitbake_project.commands.daemon_cmd import run_daemon_log
        sf = str(tmp_path / "daemon.state.json")
        with mock.patch("bitbake_project.daemon.state_path", return_value=sf):
            save_state({"log": [
                {"timestamp": "2026-03-19T10:00:00+00:00",
                 "project": "/home/user/yocto",
                 "repo": "poky",
                 "action": "updated",
                 "detail": "rebase 3 commits"},
            ]})
            args = mock.Mock(count=20)
            ret = run_daemon_log(args)
            assert ret == 0
            out = capsys.readouterr().out
            assert "poky" in out
            assert "updated" in out


# ---------------------------------------------------------------------------
# CLI parser integration
# ---------------------------------------------------------------------------

class TestDaemonParser:
    def test_daemon_subcommand_exists(self):
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()
        # Should parse without error
        args = parser.parse_args(["daemon", "status"])
        assert args.command == "daemon"
        assert args.serve_command == "status"

    def test_daemon_pause(self):
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()
        args = parser.parse_args(["daemon", "pause"])
        assert args.serve_command == "pause"

    def test_daemon_interval(self):
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()
        args = parser.parse_args(["daemon", "interval", "30"])
        assert args.serve_command == "interval"
        assert args.minutes == 30

    def test_daemon_log_count(self):
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()
        args = parser.parse_args(["daemon", "log", "-n", "50"])
        assert args.serve_command == "log"
        assert args.count == 50

    def test_serve_no_daemon(self):
        from bitbake_project.cli import build_parser
        parser, _ = build_parser()
        args = parser.parse_args(["serve", "--no-daemon"])
        assert args.no_daemon is True
