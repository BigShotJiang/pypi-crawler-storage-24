#ifndef CPU_DETECT_H
#define CPU_DETECT_H

#ifdef __cplusplus
extern "C" {
#endif

/* CPU feature flags */
#define CPU_FEATURE_SSE2      (1u << 0)
#define CPU_FEATURE_SSE3      (1u << 1)
#define CPU_FEATURE_SSSE3     (1u << 2)
#define CPU_FEATURE_SSE41     (1u << 3)
#define CPU_FEATURE_SSE42     (1u << 4)
#define CPU_FEATURE_AVX       (1u << 5)
#define CPU_FEATURE_AVX2      (1u << 6)
#define CPU_FEATURE_FMA       (1u << 7)
#define CPU_FEATURE_AVX512F   (1u << 8)
#define CPU_FEATURE_NEON      (1u << 16)
#define CPU_FEATURE_NEON_FMA  (1u << 17)

/**
 * Detect available CPU SIMD features.
 * Call once at module initialization.
 *
 * @return Bitmask of CPU_FEATURE_* flags
 */
unsigned int cpu_detect_features(void);

/**
 * Check if a specific feature is available.
 *
 * @param features Bitmask from cpu_detect_features()
 * @param flag CPU_FEATURE_* flag to check
 * @return Non-zero if feature is available
 */
static inline int cpu_has_feature(unsigned int features, unsigned int flag) {
    return (features & flag) != 0;
}

/**
 * Get human-readable string describing detected features.
 *
 * @param features Bitmask from cpu_detect_features()
 * @return Static string (do not free)
 */
const char* cpu_features_string(unsigned int features);

#ifdef __cplusplus
}
#endif

#endif /* CPU_DETECT_H */
