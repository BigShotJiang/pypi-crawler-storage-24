"""
git-treemap: Visualize your codebase as a treemap with per-commit diff overlay.

Each file is a rectangle sized by current LOC. Inside each rectangle, a
proportional green/red fill shows lines added/removed in the diff.

Usage:
    git-treemap                          # diff of HEAD vs HEAD~1
    git-treemap --ref HEAD~5..HEAD       # diff over last 5 commits
    git-treemap --ref main..HEAD         # compare branches
    git-treemap --repo /path/to/repo     # specify repo path
    git-treemap -o treemap.html          # custom output path
"""

from __future__ import annotations

import argparse
import fnmatch
import os
import subprocess
import sys
from pathlib import Path

from diffmap._squarify import normalize_sizes, squarify


# ---------------------------------------------------------------------------
# Git helpers
# ---------------------------------------------------------------------------

def _git(args: list[str], cwd: str) -> str:
    result = subprocess.run(
        ["git"] + args, cwd=cwd, capture_output=True, text=True,
    )
    return result.stdout.strip()


def _tracked_files(repo: str) -> list[str]:
    return [f for f in _git(["ls-files"], cwd=repo).splitlines() if f]


def _is_excluded(filepath: str, patterns: list[str]) -> bool:
    """Match a filepath against gitignore-style patterns."""
    for pat in patterns:
        if pat.endswith("/"):
            # directory pattern — match any path component
            dirname = pat.rstrip("/")
            if dirname in Path(filepath).parts:
                return True
        elif "/" in pat:
            if fnmatch.fnmatch(filepath, pat):
                return True
        else:
            # bare glob — match against the filename or any path component
            if fnmatch.fnmatch(Path(filepath).name, pat):
                return True
            if any(fnmatch.fnmatch(p, pat) for p in Path(filepath).parts):
                return True
    return False


def _count_lines(path: str) -> int:
    try:
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return sum(1 for _ in f)
    except (OSError, IOError):
        return 0


def _diff_stats(repo: str, ref: str) -> dict[str, tuple[int, int]]:
    """Return {filepath: (added, removed)} from git diff --numstat."""
    stats = {}
    for line in _git(["diff", "--numstat", ref], cwd=repo).splitlines():
        parts = line.split("\t", 2)
        if len(parts) != 3:
            continue
        a, r, path = parts
        if a == "-" or r == "-":
            continue
        stats[path] = (int(a), int(r))
    return stats



# ---------------------------------------------------------------------------
# Tree construction
# ---------------------------------------------------------------------------

def _build_tree(files: dict[str, int], diff: dict[str, tuple[int, int]]) -> dict:
    root = {"name": ".", "path": ".", "loc": 0, "added": 0, "removed": 0, "children": []}

    for filepath, loc in files.items():
        added, removed = diff.get(filepath, (0, 0))
        node = root
        for i, part in enumerate(Path(filepath).parts):
            cur_path = str(Path(*Path(filepath).parts[: i + 1]))
            child = next((c for c in node["children"] if c["name"] == part), None)
            if child is None:
                child = {"name": part, "path": cur_path, "loc": 0, "added": 0, "removed": 0, "children": []}
                node["children"].append(child)
            node = child
        node["loc"] = loc
        node["added"] = added
        node["removed"] = removed

    def _propagate(n):
        if not n["children"]:
            return n["loc"], n["added"], n["removed"]
        tl = ta = tr = 0
        for c in n["children"]:
            cl, ca, cr = _propagate(c)
            tl += cl; ta += ca; tr += cr
        n["loc"] = tl; n["added"] = ta; n["removed"] = tr
        return tl, ta, tr

    _propagate(root)
    return root


# ---------------------------------------------------------------------------
# SVG generation
# ---------------------------------------------------------------------------

_FILE_BG = "#1E1E1E"
_BORDER = "#2B2B2B"
_DIR_FILLS = ["#141414", "#161616", "#181818"]


def _svg_escape(s: str) -> str:
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def _auto_font(name: str, w: float, h: float, cap: float = 48, hfrac: float = 0.40) -> float:
    cwr = 0.6
    by_w = (w - 10) / max(len(name) * cwr, 1)
    by_h = h * hfrac
    fs = max(6, min(cap, by_w, by_h))
    if len(name) * cwr * fs > (w - 10):
        fs = (w - 10) / max(len(name) * cwr, 1)
    return max(6, min(cap, fs))


def _render_svg(tree: dict, width: int = 1400, height: int = 900) -> str:
    parts: list[str] = []
    parts.append(
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
        f'width="100%" height="100%" '
        f'style="background:#111111;font-family:Inter,SF Pro,-apple-system,sans-serif">'
    )

    def _node(n, bx, by, bw, bh, depth=0):
        if bw < 2 or bh < 2:
            return

        name = n["name"]
        loc = n["loc"]
        added = n["added"]
        removed = n["removed"]
        is_leaf = not n["children"]

        if is_leaf:
            basis = max(loc + removed, loc, 1)
            af = min(added / basis, 1.0)
            rf = min(removed / basis, 1.0)
            tf = af + rf
            if tf > 1.0:
                af /= tf; rf /= tf

            # Base
            parts.append(
                f'<rect x="{bx:.1f}" y="{by:.1f}" width="{bw:.1f}" height="{bh:.1f}" '
                f'fill="{_FILE_BG}" stroke="{_BORDER}" stroke-width="1.5"/>'
            )
            _MIN_BAR = 3
            # Green from bottom
            if af > 0.005:
                gh = max(bh * af, _MIN_BAR)
                gy = by + bh - gh
                op = min(0.4 + af * 0.5, 0.85)
                parts.append(
                    f'<rect x="{bx+0.75:.1f}" y="{gy:.1f}" width="{bw-1.5:.1f}" height="{gh:.1f}" '
                    f'fill="rgba(74,222,128,{op:.2f})"/>'
                )
            # Red stacked above green
            if rf > 0.005:
                rh = max(bh * rf, _MIN_BAR)
                g_h = max(bh * af, _MIN_BAR) if af > 0.005 else 0
                ry = by + bh - g_h - rh
                op = min(0.4 + rf * 0.5, 0.85)
                parts.append(
                    f'<rect x="{bx+0.75:.1f}" y="{ry:.1f}" width="{bw-1.5:.1f}" height="{rh:.1f}" '
                    f'fill="rgba(248,113,113,{op:.2f})"/>'
                )
            # Label (on top of fills)
            if bw > 20 and bh > 14:
                has_diff = added > 0 or removed > 0
                fs = _auto_font(name, bw, bh)
                ty = by + fs + 4
                stem, dot, ext = name.rpartition(".")
                if has_diff:
                    if dot and stem:
                        label = f'{_svg_escape(stem)}<tspan fill="rgba(255,255,255,0.35)">.{_svg_escape(ext)}</tspan>'
                    else:
                        label = _svg_escape(name)
                    name_fill = "rgba(255,255,255,0.95)"
                else:
                    label = _svg_escape(name)
                    name_fill = "rgba(255,255,255,0.28)"
                # Shadow
                parts.append(
                    f'<text x="{bx+5:.1f}" y="{ty:.1f}" font-size="{fs:.1f}" '
                    f'fill="rgba(0,0,0,0.6)" font-weight="700">{_svg_escape(name)}</text>'
                )
                # Label
                parts.append(
                    f'<text x="{bx+5:.1f}" y="{ty:.1f}" font-size="{fs:.1f}" '
                    f'fill="{name_fill}" font-weight="700">{label}</text>'
                )
                # Stats
                sfs = max(6, min(fs * 0.45, 14))
                sy = ty + sfs + 3
                if sy < by + bh - 3:
                    p = [str(loc)]
                    if added:
                        p.append(f'<tspan fill="rgba(130,230,150,0.9)">+{added}</tspan>')
                    if removed:
                        p.append(f'<tspan fill="rgba(250,140,140,0.9)">-{removed}</tspan>')
                    stat_fill = "rgba(255,255,255,0.5)" if has_diff else "rgba(255,255,255,0.18)"
                    parts.append(
                        f'<text x="{bx+5:.1f}" y="{sy:.1f}" font-size="{sfs:.1f}" '
                        f'fill="{stat_fill}">{" ".join(p)}</text>'
                    )
            # Tooltip
            tip = f"{n['path']} — {loc} LOC"
            if added: tip += f"  +{added}"
            if removed: tip += f"  -{removed}"
            parts.append(
                f'<rect x="{bx:.1f}" y="{by:.1f}" width="{bw:.1f}" height="{bh:.1f}" '
                f'fill="transparent"><title>{_svg_escape(tip)}</title></rect>'
            )
        else:
            # Directory container
            dbw = 2.0 if depth < 2 else 1.0
            dbc = "#2B2B2B" if depth < 2 else "#232323"
            dfill = _DIR_FILLS[min(depth, len(_DIR_FILLS) - 1)]
            parts.append(
                f'<rect x="{bx:.1f}" y="{by:.1f}" width="{bw:.1f}" height="{bh:.1f}" '
                f'fill="{dfill}" stroke="{dbc}" stroke-width="{dbw}"/>'
            )
            # Dir label
            pad_top = 0
            if bw > 30 and bh > 24:
                has_diff = added > 0 or removed > 0
                dfs = _auto_font(name + "/", bw, bh, cap=20, hfrac=0.12)
                dfs = max(7, min(20, dfs))
                pad_top = dfs + 6
                dir_fill = "rgba(255,255,255,0.90)" if has_diff else "rgba(255,255,255,0.28)"
                parts.append(
                    f'<text x="{bx+6:.1f}" y="{by+dfs+3:.1f}" font-size="{dfs:.1f}" '
                    f'fill="{dir_fill}" font-weight="600" '
                    f'letter-spacing="0.5">{_svg_escape(name + "/")}</text>'
                )
            # Children
            pad = max(5, 3 + (2 - depth) * 2) if depth < 3 else 3
            ix, iy = bx + pad, by + pad_top + pad
            iw, ih = bw - 2 * pad, bh - pad_top - 2 * pad
            if iw < 4 or ih < 4:
                return
            children = sorted(n["children"], key=lambda c: -c["loc"])
            vals = [max(c["loc"], 1) for c in children]
            if not vals:
                return
            normed = normalize_sizes(vals, iw, ih)
            rects = squarify(normed, ix, iy, iw, ih)
            for child, rect in zip(children, rects):
                _node(child, rect["x"], rect["y"], rect["dx"], rect["dy"], depth + 1)

    # Top-level layout
    top = sorted(tree["children"], key=lambda c: -c["loc"])
    vals = [max(c["loc"], 1) for c in top]
    if vals:
        normed = normalize_sizes(vals, width, height)
        rects = squarify(normed, 0, 0, width, height)
        for child, rect in zip(top, rects):
            _node(child, rect["x"], rect["y"], rect["dx"], rect["dy"], depth=0)

    parts.append("</svg>")
    return "\n".join(parts)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(
        description="Visualize your codebase as a treemap, with colored diffs.",
    )
    parser.add_argument("--repo", default=".", help="Path to git repository (default: .)")
    parser.add_argument("--ref", default="HEAD~1..HEAD", help="Git ref spec for diff (default: HEAD~1..HEAD)")
    parser.add_argument("-o", "--output", default="treemap.svg", help="Output SVG file (default: treemap.svg)")
    parser.add_argument("-w", "--width", type=int, default=1400, help="SVG width (default: 1400)")
    parser.add_argument("--height", type=int, default=900, help="SVG height (default: 900)")
    parser.add_argument("-e", "--exclude", action="append", default=[],
                        help="Exclude files matching pattern (gitignore-style, repeatable)")
    parser.add_argument("-c", "--changed", action="store_true",
                        help="Only show files that have diffs")
    parser.add_argument("-q", "--quiet", action="store_true", help="Suppress progress output")
    args = parser.parse_args()

    repo = os.path.abspath(args.repo)

    if not os.path.isdir(os.path.join(repo, ".git")):
        print(f"error: {repo} is not a git repository", file=sys.stderr)
        sys.exit(1)

    # Scan
    if not args.quiet:
        print(f"Scanning {repo}...")
    tracked = _tracked_files(repo)
    if args.exclude:
        tracked = [f for f in tracked if not _is_excluded(f, args.exclude)]
    files = {}
    for f in tracked:
        full = os.path.join(repo, f)
        if os.path.isfile(full):
            loc = _count_lines(full)
            if loc > 0:
                files[f] = loc

    total_loc = sum(files.values())
    if not args.quiet:
        print(f"  {len(files)} files, {total_loc:,} lines")

    # Diff
    if not args.quiet:
        print(f"\nDiff: {args.ref}")
    diff = _diff_stats(repo, args.ref)
    if args.exclude:
        diff = {f: v for f, v in diff.items() if not _is_excluded(f, args.exclude)}
    total_add = sum(a for a, _ in diff.values())
    total_rem = sum(r for _, r in diff.values())
    if not args.quiet:
        green = f"\033[32m+{total_add}\033[0m"
        red = f"\033[31m-{total_rem}\033[0m"
        print(f"  {len(diff)} changed, {green} {red}")

    # Include deleted files
    for fp in diff:
        if fp not in files:
            files[fp] = 0

    if args.changed:
        files = {f: loc for f, loc in files.items() if f in diff}

    # Build + render
    tree = _build_tree(files, diff)
    svg = _render_svg(tree, width=args.width, height=args.height)

    with open(args.output, "w") as f:
        f.write(svg)

    if not args.quiet:
        print(f"\nWrote {args.output}")
