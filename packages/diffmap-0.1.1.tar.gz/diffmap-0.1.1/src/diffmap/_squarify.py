"""
Vendored squarify treemap layout algorithm.

Based on squarify by Uri Laserson (MIT License).
https://github.com/laserson/squarify

Implements Bruls, Huizing, van Wijk, "Squarified Treemaps" (2000).
"""


def normalize_sizes(sizes: list[float], dx: float, dy: float) -> list[float]:
    """Normalize values so that sum(sizes) == dx * dy."""
    total_size = sum(sizes)
    total_area = dx * dy
    return [float(s) * total_area / total_size for s in sizes]


def squarify(sizes: list[float], x: float, y: float, dx: float, dy: float) -> list[dict]:
    """Compute treemap rectangles using the squarified algorithm."""
    sizes = list(map(float, sizes))
    if len(sizes) == 0:
        return []
    if len(sizes) == 1:
        return _layout(sizes, x, y, dx, dy)

    i = 1
    while i < len(sizes) and _worst_ratio(sizes[:i], x, y, dx, dy) >= _worst_ratio(
        sizes[: (i + 1)], x, y, dx, dy
    ):
        i += 1
    current = sizes[:i]
    remaining = sizes[i:]

    lx, ly, ldx, ldy = _leftover(current, x, y, dx, dy)
    return _layout(current, x, y, dx, dy) + squarify(remaining, lx, ly, ldx, ldy)


def _layout(sizes, x, y, dx, dy):
    return _layoutrow(sizes, x, y, dx, dy) if dx >= dy else _layoutcol(sizes, x, y, dx, dy)


def _worst_ratio(sizes, x, y, dx, dy):
    return max(
        max(r["dx"] / r["dy"], r["dy"] / r["dx"]) for r in _layout(sizes, x, y, dx, dy)
    )


def _leftover(sizes, x, y, dx, dy):
    return _leftoverrow(sizes, x, y, dx, dy) if dx >= dy else _leftovercol(sizes, x, y, dx, dy)


def _layoutrow(sizes, x, y, dx, dy):
    covered = sum(sizes)
    width = covered / dy
    rects = []
    for size in sizes:
        rects.append({"x": x, "y": y, "dx": width, "dy": size / width})
        y += size / width
    return rects


def _layoutcol(sizes, x, y, dx, dy):
    covered = sum(sizes)
    height = covered / dx
    rects = []
    for size in sizes:
        rects.append({"x": x, "y": y, "dx": size / height, "dy": height})
        x += size / height
    return rects


def _leftoverrow(sizes, x, y, dx, dy):
    covered = sum(sizes)
    width = covered / dy
    return (x + width, y, dx - width, dy)


def _leftovercol(sizes, x, y, dx, dy):
    covered = sum(sizes)
    height = covered / dx
    return (x, y + height, dx, dy - height)
