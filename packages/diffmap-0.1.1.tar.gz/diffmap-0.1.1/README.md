# diffmap

Visualize your codebase as a treemap, with colored diffs.
No install needed, zero-dependency, and language-agnostic. Requires [`uv`](https://docs.astral.sh/uv/) and `git`.

![Example treemap](https://raw.githubusercontent.com/Ulyssean/diffmap/main/example.svg)

## Usage

```bash
uvx diffmap
```

`uvx` runs it directly from PyPI in a temporary environment, nothing to install or clean up.

### Options

```
diffmap                                    # diff HEAD vs HEAD~1
diffmap --ref HEAD~5..HEAD                 # last 5 commits
diffmap --ref main..HEAD                   # compare against main
diffmap --repo /path/to/repo               # different repo
diffmap --output my-treemap.svg            # custom output path
diffmap --exclude "*.lock" -e docs/        # exclude files/folders (gitignore-style)
diffmap --changed                          # only show changed files
diffmap --width 1920 --height 1080         # custom dimensions
diffmap --quiet                            # quiet mode
```

## How it works

1. Lists tracked files via `git ls-files` (respects `.gitignore`)
2. Counts lines per file
3. Gets per-file diff stats via `git diff --numstat`
4. Lays out a hierarchical treemap (directories contain their children)
5. Renders an SVG with proportional green/red fills inside each file rectangle

## License

MIT
