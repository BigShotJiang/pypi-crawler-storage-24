from __future__ import annotations

from openkite.cli import main


def test_check_command(monkeypatch, tmp_path, capsys) -> None:
    monkeypatch.setenv("OPENAI_API_KEY", "sk-test")
    monkeypatch.setenv("FIRECRAWL_API_KEY", "fc-test")
    monkeypatch.setenv("OPENKITE_DB_PATH", str(tmp_path / "chat_history.db"))

    exit_code = main(["check"])

    captured = capsys.readouterr()
    assert exit_code == 0
    assert "Configuration loaded successfully." in captured.out
