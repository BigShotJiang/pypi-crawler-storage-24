from __future__ import annotations

from openkite.ui import TITLE_BANNER_HTML, build_demo


class _StubChatService:
    def history_choices(self) -> list[tuple[str, str]]:
        return []

    def load_history(self, session_id: str) -> list[dict]:
        return []

    async def chat(self, message: str, history: list[dict], session_id: str = ""):
        yield ("", session_id, None)


def test_title_banner_uses_self_contained_logo_image() -> None:
    assert '<img id="title-logo"' in TITLE_BANNER_HTML
    assert "data:image/svg+xml," in TITLE_BANNER_HTML
    assert ".cls-1" not in TITLE_BANNER_HTML
    assert ".cls-2" not in TITLE_BANNER_HTML


def test_build_demo_renders_title_banner_html() -> None:
    app = build_demo(_StubChatService())

    html_values = [
        component.get("props", {}).get("value", "")
        for component in app.config.get("components", [])
        if component.get("type") == "html"
    ]

    assert TITLE_BANNER_HTML in html_values