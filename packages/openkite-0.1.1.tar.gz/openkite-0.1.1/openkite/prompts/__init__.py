"""Prompt resources for OpenKite."""
