from __future__ import annotations

from importlib import resources

from agents import Agent

from .config import Settings
from .mcp_runtime import MCPRuntime
from .tools import screener_get_data


def _load_system_prompt() -> str:
    prompt_file = resources.files("openkite.prompts").joinpath("system_prompt.txt")
    return prompt_file.read_text(encoding="utf-8")


def build_agent(settings: Settings, runtime: MCPRuntime) -> Agent:
    """Create the OpenAI Agent instance for chat runs."""
    return Agent(
        name="Kite Assistant",
        model=settings.model,
        instructions=_load_system_prompt(),
        mcp_servers=runtime.servers,
        tools=[screener_get_data],
    )
