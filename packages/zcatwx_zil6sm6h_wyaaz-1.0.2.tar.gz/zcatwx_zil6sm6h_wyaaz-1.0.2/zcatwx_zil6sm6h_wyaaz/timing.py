from __future__ import annotations


_UNIT = {"us": 1, "s": 1_000_000}


def normalize_time_unit(raw_unit: str | None) -> str:
    return raw_unit if raw_unit in _UNIT else "us"


def parse_time_value(value, time_unit: str = "us", numeric_is_raw: bool = False) -> int:
    """
    统一时间解析入口。

    - 默认内部单位为微秒
    - 支持显式字符串: "3s" / "500ms" / "3000000us"
    - 当 numeric_is_raw=False 时，纯数字按 time_unit 解释
    - 当 numeric_is_raw=True 时，纯数字直接视为微秒原值
    """
    if value is None or value == "" or value == "auto":
        return 0

    normalized_unit = normalize_time_unit(time_unit)
    unit_multiplier = _UNIT[normalized_unit]

    if isinstance(value, str):
        text = value.strip().lower()
        if text.endswith("us"):
            return int(float(text[:-2]))
        if text.endswith("ms"):
            return int(float(text[:-2]) * 1_000)
        if text.endswith("s"):
            return int(float(text[:-1]) * 1_000_000)
        return int(float(text) if numeric_is_raw else float(text) * unit_multiplier)

    if numeric_is_raw:
        return int(value)

    return int(value * unit_multiplier)
