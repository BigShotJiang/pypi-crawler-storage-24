from __future__ import annotations

import uuid


def ensure_tracks(ctx: dict) -> list:
    return ctx.setdefault("tracks", [])


def ensure_refs(ctx: dict) -> dict:
    return ctx.setdefault("refs", {})


def resolve_target_id(ctx: dict, target_key: str):
    refs = ctx.get("refs", {})
    return refs.get(target_key, target_key)


def make_track(track_type: str) -> dict:
    return {
        "type": track_type,
        "id": str(uuid.uuid4()).upper(),
        "clips": [],
    }


def append_track(ctx: dict, track: dict) -> dict:
    ensure_tracks(ctx).append(track)
    return track


def find_tracks(ctx: dict, track_type: str) -> list:
    return [track for track in ctx.get("tracks", []) if track.get("type") == track_type]


def find_or_create_track(ctx: dict, track_type: str, index: int = 0) -> dict:
    tracks = find_tracks(ctx, track_type)
    while len(tracks) <= index:
        tracks.append(append_track(ctx, make_track(track_type)))
    return tracks[index]


def get_last_clip_end(track: dict) -> int:
    last_end = 0
    for clip in track.get("clips", []):
        start = clip.get("start", 0)
        duration = clip.get("duration", 0)
        if isinstance(start, (int, float)) and isinstance(duration, (int, float)):
            last_end = max(last_end, int(start) + int(duration))
    return last_end


def register_ref(ctx: dict, alias: str, clip_id: str):
    ensure_refs(ctx)[alias] = clip_id


def find_clip(ctx: dict, clip_id: str):
    for track in ctx.get("tracks", []):
        for clip in track.get("clips", []):
            if clip.get("id") == clip_id:
                return clip
    return None


def append_keyframe(ctx: dict, clip_id: str, prop_name: str, time_offset, value) -> bool:
    clip = find_clip(ctx, clip_id)
    if not clip:
        return False

    keyframes = clip.setdefault("keyframes", [])
    prop_group = None
    for group in keyframes:
        if group.get("prop") == prop_name:
            prop_group = group
            break

    if not prop_group:
        prop_group = {"prop": prop_name, "data": []}
        keyframes.append(prop_group)

    prop_group["data"].append({
        "time_offset": time_offset,
        "value": value,
    })
    return True
