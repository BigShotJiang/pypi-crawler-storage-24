from __future__ import annotations


def merge_plugin_params(item: dict, plugin_params: dict, plugin_priority: bool, deep_dict_keys=()) -> dict:
    """
    合并 xxx_infos 单条数据与插件层参数。

    - plugin_priority=True  -> 插件层覆盖同名字段
    - plugin_priority=False -> item 覆盖插件层字段
    - deep_dict_keys 中的字段会按字典层级合并，适合 transform 这类结构
    """
    if not plugin_params:
        return item

    pp = dict(plugin_params)
    deep_values = {key: pp.pop(key, None) for key in deep_dict_keys}
    clean_pp = {k: v for k, v in pp.items() if v is not None}

    if plugin_priority:
        merged = {**item, **clean_pp}
    else:
        merged = {**clean_pp, **item}

    for key, plugin_value in deep_values.items():
        if not plugin_value:
            continue
        item_value = merged.get(key, {}) or {}
        if not isinstance(item_value, dict):
            item_value = {}
        if plugin_priority:
            merged[key] = {**item_value, **plugin_value}
        else:
            merged[key] = {**plugin_value, **item_value}

    return merged
