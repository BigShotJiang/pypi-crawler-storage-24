from __future__ import annotations

import base64
import json
import os

from cryptography.hazmat.primitives.ciphers.aead import AESGCM


_KEY = "MySecretKeyForCozeNode20260307!!".encode("utf-8")


class DraftCrypto:
    @classmethod
    def encrypt(cls, plaintext: str) -> str:
        aesgcm = AESGCM(_KEY)
        iv = os.urandom(12)
        ct = aesgcm.encrypt(iv, plaintext.encode("utf-8"), None)
        return base64.b64encode(iv + ct).decode("utf-8")

    @classmethod
    def decrypt(cls, payload: str) -> str:
        try:
            aesgcm = AESGCM(_KEY)
            raw = base64.b64decode(payload.encode("utf-8"))
            return aesgcm.decrypt(raw[:12], raw[12:], None).decode("utf-8")
        except Exception:
            return payload

    @classmethod
    def parse_context(cls, raw_ctx):
        if isinstance(raw_ctx, str):
            decrypted = cls.decrypt(raw_ctx)
            return json.loads(decrypted)
        return raw_ctx or {}

    @classmethod
    def serialize_context(cls, ctx: dict) -> str:
        return cls.encrypt(json.dumps(ctx, ensure_ascii=False))


def looks_like_json(text: str) -> bool:
    s = (text or "").strip()
    if not s:
        return False
    if not (s.startswith("{") or s.startswith("[")):
        return False
    try:
        json.loads(s)
        return True
    except Exception:
        return False


def try_parse_json(text: str):
    try:
        return json.loads(text)
    except Exception:
        return None


def looks_like_final_draft(obj) -> bool:
    return isinstance(obj, dict) and all(k in obj for k in ("canvas_config", "materials", "tracks"))


def looks_like_draft_context(obj) -> bool:
    return isinstance(obj, dict) and "project_info" in obj and "tracks" in obj


def normalize_input_json(raw_input: str):
    """
    尝试把输入识别为:
    1. 完整草稿 JSON
    2. DraftContext JSON
    3. 其他未知格式
    """
    candidates = []
    for candidate in (raw_input, DraftCrypto.decrypt(raw_input)):
        if isinstance(candidate, str) and candidate not in candidates:
            candidates.append(candidate)

    for candidate in candidates:
        obj = try_parse_json(candidate)
        if looks_like_final_draft(obj):
            return "final_draft", candidate, obj
        if looks_like_draft_context(obj):
            return "draft_context", candidate, obj

    return "unknown", raw_input, None
