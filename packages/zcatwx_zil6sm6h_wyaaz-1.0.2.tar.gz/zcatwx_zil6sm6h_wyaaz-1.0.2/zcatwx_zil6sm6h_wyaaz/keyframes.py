from __future__ import annotations

import math


KF_PROP_MAP = {
    "KFTypePositionX": "x",
    "KFTypePositionY": "y",
    "KFTypeScale": "scale",
    "KFTypeScaleX": "scale_x",
    "KFTypeScaleY": "scale_y",
    "KFTypeRotation": "rotation",
    "KFTypeAlpha": "alpha",
    "KFTypeVolume": "volume",
}

KF_CONVERT_POSITION = {"KFTypePositionX", "KFTypePositionY"}
KF_CONVERT_SCALE = {"KFTypeScale", "KFTypeScaleX", "KFTypeScaleY"}
KF_CONVERT_ALPHA = {"KFTypeAlpha"}
KF_CONVERT_VOLUME = {"KFTypeVolume"}


def convert_competitor_property_name(prop_name: str) -> str:
    return KF_PROP_MAP.get(prop_name, prop_name)


def convert_competitor_kf_value(prop_name: str, value, canvas_w: int, canvas_h: int):
    """
    将同行关键帧值转换为内部约定的 UI 值单位。
    """
    try:
        v = float(value)
    except (TypeError, ValueError):
        return value

    if prop_name in KF_CONVERT_POSITION:
        return v * canvas_w if prop_name == "KFTypePositionX" else v * canvas_h
    if prop_name in KF_CONVERT_SCALE:
        return v * 100
    if prop_name in KF_CONVERT_ALPHA:
        return v * 100
    if prop_name in KF_CONVERT_VOLUME:
        if v <= 0:
            return -60.0
        return 20 * math.log10(v)
    return v
