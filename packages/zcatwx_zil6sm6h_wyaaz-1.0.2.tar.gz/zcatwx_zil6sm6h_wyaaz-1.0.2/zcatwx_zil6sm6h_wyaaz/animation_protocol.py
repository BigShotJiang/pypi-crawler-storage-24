from __future__ import annotations

from typing import Any, Mapping


def _ensure_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()


def normalize_animation_target(target: str) -> str:
    normalized = _ensure_text(target).lower()
    return {
        "caption": "text",
        "captions": "text",
        "image": "video",
        "images": "video",
        "shape": "sticker",
    }.get(normalized, normalized or "video")


def normalize_animation_phase(phase: Any, *, target: str | None = None) -> str:
    normalized = _ensure_text(phase).lower()
    normalized = {
        "入场": "in",
        "出场": "out",
        "循环": "loop",
        "组合": "group",
        "ruchang": "in",
        "chuchang": "out",
        "xunhuan": "loop",
    }.get(normalized, normalized)
    if not normalized:
        normalized = "in"
    if target and normalize_animation_target(target) == "video" and normalized == "loop":
        return "group"
    return normalized


def animation_target_defaults(target: str) -> dict[str, str]:
    normalized = normalize_animation_target(target)
    if normalized == "video":
        return {
            "target": "video",
            "material_type": "video",
            "panel": "video",
            "container_type": "video_animation",
        }
    if normalized == "sticker":
        return {
            "target": "sticker",
            "material_type": "sticker",
            "panel": "shape-animation",
            "container_type": "sticker_animation",
        }
    return {
        "target": "text",
        "material_type": "sticker",
        "panel": "",
        "container_type": "sticker_animation",
    }


def default_animation_duration_us(phase: str) -> int:
    return 1_000_000 if phase in {"loop", "group"} else 500_000


def normalize_anim_adjust_params(value: Any) -> dict[str, str] | None:
    if not isinstance(value, Mapping):
        return None
    direction = _ensure_text(value.get("direction") or value.get("animation_adjust_direction"))
    anim_mode = _ensure_text(value.get("anim_mode") or value.get("animation_adjust_content_mode"))
    payload = {k: v for k, v in {"direction": direction, "anim_mode": anim_mode}.items() if v}
    return payload or None


def build_animation_entry(
    *,
    target: str,
    phase: Any,
    resource_id: Any,
    duration_us: Any | None = None,
    clip_duration_us: Any | None = None,
    start_us: Any | None = None,
    effect_id: Any = "",
    name: Any = "",
    panel: Any | None = None,
    material_type: Any | None = None,
    platform: Any = "all",
    path: Any = "",
    request_id: Any = "",
    category_id: Any = "",
    category_name: Any = "",
    anim_adjust_params: Any = None,
) -> dict[str, Any]:
    defaults = animation_target_defaults(target)
    protocol_phase = normalize_animation_phase(phase, target=target)
    duration = int(duration_us if duration_us is not None else default_animation_duration_us(protocol_phase))
    if start_us is None:
        if protocol_phase == "out" and clip_duration_us is not None:
            start = max(0, int(clip_duration_us) - duration)
        else:
            start = 0
    else:
        start = int(start_us)

    resolved_resource_id = _ensure_text(resource_id)
    return {
        "type": protocol_phase,
        "id": resolved_resource_id,
        "resource_id": resolved_resource_id,
        "effect_id": _ensure_text(effect_id) or resolved_resource_id,
        "duration": duration,
        "start": start,
        "name": _ensure_text(name) or "animation",
        "material_type": _ensure_text(material_type) or defaults["material_type"],
        "panel": defaults["panel"] if panel is None else _ensure_text(panel),
        "platform": _ensure_text(platform) or "all",
        "path": _ensure_text(path),
        "request_id": _ensure_text(request_id),
        "category_id": _ensure_text(category_id),
        "category_name": _ensure_text(category_name),
        "anim_adjust_params": normalize_anim_adjust_params(anim_adjust_params),
    }
