"""Tests for certmesh.api.routes.info — server info endpoint."""

from __future__ import annotations

from unittest.mock import MagicMock

from fastapi.testclient import TestClient

from certmesh import __version__


def _make_test_app(oauth2_enabled: bool = False):
    """Create a minimal FastAPI app with the info router."""
    from fastapi import FastAPI

    from certmesh.api.routes.info import router

    app = FastAPI()
    app.include_router(router)

    # Mock OAuth2 config
    oauth2_cfg = MagicMock()
    oauth2_cfg.enabled = oauth2_enabled
    app.state.oauth2_config = oauth2_cfg

    return app


class TestInfoEndpoint:
    def test_returns_version(self):
        app = _make_test_app()
        client = TestClient(app)
        resp = client.get("/api/v1/info")
        assert resp.status_code == 200
        data = resp.json()
        assert data["version"] == __version__

    def test_oauth2_disabled(self):
        app = _make_test_app(oauth2_enabled=False)
        client = TestClient(app)
        resp = client.get("/api/v1/info")
        data = resp.json()
        assert data["oauth2_enabled"] is False

    def test_oauth2_enabled(self):
        app = _make_test_app(oauth2_enabled=True)
        client = TestClient(app)
        resp = client.get("/api/v1/info")
        data = resp.json()
        assert data["oauth2_enabled"] is True

    def test_includes_providers(self):
        app = _make_test_app()
        client = TestClient(app)
        resp = client.get("/api/v1/info")
        data = resp.json()
        assert "venafi" in data["providers"]
        assert "digicert" in data["providers"]

    def test_no_auth_required(self):
        """Info endpoint must be accessible without any authentication."""
        app = _make_test_app()
        client = TestClient(app)
        # No Authorization header — should still work
        resp = client.get("/api/v1/info")
        assert resp.status_code == 200

    def test_api_version(self):
        app = _make_test_app()
        client = TestClient(app)
        resp = client.get("/api/v1/info")
        data = resp.json()
        assert data["api_version"] == "v1"
