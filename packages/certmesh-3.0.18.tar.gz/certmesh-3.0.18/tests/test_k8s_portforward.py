"""Tests for certmesh.k8s_portforward — kubectl port-forward management."""

from __future__ import annotations

import signal
import subprocess
from unittest.mock import MagicMock, patch

import pytest

from certmesh.exceptions import ConfigurationError
from certmesh.k8s_portforward import (
    PortForwardManager,
    _find_free_port,
    parse_k8s_url,
)

# =============================================================================
# URL parsing
# =============================================================================


class TestParseK8sURL:
    def test_basic_url(self):
        ns, svc, port, tls = parse_k8s_url("k8s://certmesh/certmesh-api:8000")
        assert ns == "certmesh"
        assert svc == "certmesh-api"
        assert port == 8000
        assert tls is False

    def test_tls_url(self):
        ns, svc, port, tls = parse_k8s_url("k8s+tls://prod/certmesh-api:8443")
        assert ns == "prod"
        assert svc == "certmesh-api"
        assert port == 8443
        assert tls is True

    def test_invalid_scheme(self):
        with pytest.raises(ConfigurationError, match="Invalid K8s URL scheme"):
            parse_k8s_url("https://example.com")

    def test_missing_port(self):
        with pytest.raises(ConfigurationError, match="Missing port"):
            parse_k8s_url("k8s://namespace/service")

    def test_missing_service(self):
        with pytest.raises(ConfigurationError, match="Invalid K8s URL format"):
            parse_k8s_url("k8s://namespace-only")

    def test_invalid_port(self):
        with pytest.raises(ConfigurationError, match="Invalid port"):
            parse_k8s_url("k8s://ns/svc:abc")

    def test_empty_namespace(self):
        with pytest.raises(ConfigurationError, match="Invalid K8s URL components"):
            parse_k8s_url("k8s:///svc:8000")


# =============================================================================
# Free port discovery
# =============================================================================


class TestFindFreePort:
    def test_returns_positive_int(self):
        port = _find_free_port()
        assert isinstance(port, int)
        assert port > 0


# =============================================================================
# PortForwardManager
# =============================================================================


class TestPortForwardManager:
    def test_init(self):
        pf = PortForwardManager("ns", "svc", 8000)
        assert pf.namespace == "ns"
        assert pf.service == "svc"
        assert pf.remote_port == 8000
        assert pf.use_tls is False

    def test_init_tls(self):
        pf = PortForwardManager("ns", "svc", 8443, use_tls=True)
        assert pf.use_tls is True

    @patch("certmesh.k8s_portforward._check_kubectl", return_value=None)
    def test_start_no_kubectl(self, _):
        pf = PortForwardManager("ns", "svc", 8000)
        with pytest.raises(ConfigurationError, match="kubectl not found"):
            pf.start()

    def test_is_alive_no_process(self):
        pf = PortForwardManager("ns", "svc", 8000)
        assert pf.is_alive() is False

    def test_stop_no_process(self):
        pf = PortForwardManager("ns", "svc", 8000)
        # Should not raise
        pf.stop()

    def test_context_manager(self):
        pf = PortForwardManager("ns", "svc", 8000)
        with patch.object(pf, "start", return_value="http://127.0.0.1:12345"):
            with patch.object(pf, "stop") as mock_stop:
                with pf as manager:
                    assert manager is pf
                mock_stop.assert_called_once()

    @patch("certmesh.k8s_portforward._check_kubectl", return_value="/usr/bin/kubectl")
    @patch("subprocess.Popen")
    @patch("subprocess.run")
    def test_start_success(self, mock_run, mock_popen, mock_kubectl):
        mock_run.return_value = MagicMock(
            returncode=0, stdout='{"clientVersion": {"gitVersion": "v1.32.0"}}'
        )

        mock_proc = MagicMock()
        mock_proc.poll.return_value = None  # Process still running
        mock_proc.stdout.readline.return_value = "Forwarding from 127.0.0.1:54321 -> 8000\n"
        mock_popen.return_value = mock_proc

        # Mock select to indicate stdout is ready
        with patch("select.select", return_value=([mock_proc.stdout], [], [])):
            pf = PortForwardManager("certmesh", "certmesh-api", 8000)
            url = pf.start()
            assert url == "http://127.0.0.1:54321"
            assert pf.local_url == "http://127.0.0.1:54321"

    @patch("certmesh.k8s_portforward._check_kubectl", return_value="/usr/bin/kubectl")
    @patch("subprocess.Popen")
    @patch("subprocess.run")
    def test_start_tls_url(self, mock_run, mock_popen, mock_kubectl):
        mock_run.return_value = MagicMock(returncode=0, stdout="{}")

        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        mock_proc.stdout.readline.return_value = "Forwarding from 127.0.0.1:54321 -> 8443\n"
        mock_popen.return_value = mock_proc

        with patch("select.select", return_value=([mock_proc.stdout], [], [])):
            pf = PortForwardManager("ns", "svc", 8443, use_tls=True)
            url = pf.start()
            assert url.startswith("https://")

    @patch("certmesh.k8s_portforward._check_kubectl", return_value="/usr/bin/kubectl")
    @patch("subprocess.Popen")
    @patch("subprocess.run")
    def test_start_new_session_enabled(self, mock_run, mock_popen, mock_kubectl):
        """Popen should use start_new_session=True for process group isolation."""
        mock_run.return_value = MagicMock(returncode=0, stdout="{}")
        mock_proc = MagicMock()
        mock_proc.poll.return_value = None
        mock_proc.stdout.readline.return_value = "Forwarding from 127.0.0.1:54321 -> 8000\n"
        mock_popen.return_value = mock_proc

        with patch("select.select", return_value=([mock_proc.stdout], [], [])):
            pf = PortForwardManager("ns", "svc", 8000)
            pf.start()
            call_kwargs = mock_popen.call_args.kwargs
            assert call_kwargs.get("start_new_session") is True

    def test_stop_with_timeout_expired(self):
        """If terminate() hangs, kill() should be called."""
        pf = PortForwardManager("ns", "svc", 8000)
        mock_proc = MagicMock()
        mock_proc.wait.side_effect = [subprocess.TimeoutExpired("kubectl", 5), None]
        mock_proc.stdout = None
        mock_proc.stderr = None
        pf._process = mock_proc

        pf.stop()

        mock_proc.terminate.assert_called_once()
        mock_proc.kill.assert_called_once()
        assert pf._process is None

    def test_reconnect_calls_stop_and_start(self):
        """Reconnect should stop, pick new port, and start again."""
        pf = PortForwardManager("ns", "svc", 8000)
        with (
            patch.object(pf, "stop") as mock_stop,
            patch.object(pf, "start", return_value="http://127.0.0.1:55555") as mock_start,
        ):
            url = pf.reconnect()
            mock_stop.assert_called_once()
            mock_start.assert_called_once()
            assert url == "http://127.0.0.1:55555"

    def test_sigint_handler_raises_keyboard_interrupt(self):
        """Signal handler should raise KeyboardInterrupt without deadlock."""
        pf = PortForwardManager("ns", "svc", 8000)
        mock_proc = MagicMock()
        pf._process = mock_proc
        with pytest.raises(KeyboardInterrupt):
            pf._sigint_handler(signal.SIGINT, None)
        mock_proc.terminate.assert_called_once()

    def test_sigint_handler_no_deadlock_when_locked(self):
        """Signal handler should not deadlock if lock is already held."""
        pf = PortForwardManager("ns", "svc", 8000)
        mock_proc = MagicMock()
        pf._process = mock_proc
        pf._lock.acquire()  # Simulate lock held by another thread
        try:
            with pytest.raises(KeyboardInterrupt):
                pf._sigint_handler(signal.SIGINT, None)
            # terminate should NOT be called since lock was held
            mock_proc.terminate.assert_not_called()
        finally:
            pf._lock.release()


# =============================================================================
# Port range validation
# =============================================================================


class TestPortRange:
    def test_port_above_65535_rejected(self):
        with pytest.raises(ConfigurationError, match="Invalid K8s URL components"):
            parse_k8s_url("k8s://ns/svc:99999")

    def test_port_65535_accepted(self):
        _, _, port, _ = parse_k8s_url("k8s://ns/svc:65535")
        assert port == 65535

    def test_port_zero_rejected(self):
        with pytest.raises(ConfigurationError, match="Invalid K8s URL components"):
            parse_k8s_url("k8s://ns/svc:0")
