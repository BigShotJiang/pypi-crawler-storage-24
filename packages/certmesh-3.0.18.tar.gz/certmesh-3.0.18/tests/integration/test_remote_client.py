"""Integration tests for remote client management.

Starts a real certmesh FastAPI server in a background thread and exercises
the remote client against it — version check, auth detection, health
endpoints, and provider endpoint routing.

Run: pytest -m integration tests/integration/test_remote_client.py -v

No external services required — uses the built-in FastAPI test server.
"""

from __future__ import annotations

import socket
import threading
import time

import pytest
import uvicorn

from certmesh import __version__
from certmesh.exceptions import ConfigurationError, RemoteConnectionError
from certmesh.remote_client import CertMeshRemoteClient

pytestmark = pytest.mark.integration


def _find_free_port() -> int:
    """Find an available TCP port on localhost."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _wait_for_server(url: str, timeout: float = 10.0) -> bool:
    """Wait for the server to accept connections."""
    import httpx

    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            resp = httpx.get(f"{url}/healthz", timeout=2.0)
            if resp.status_code == 200:
                return True
        except httpx.RequestError:
            # Ignore transient connection/transport errors while waiting for server startup
            ...
        time.sleep(0.2)
    return False


@pytest.fixture(scope="module")
def live_server():
    """Start a real certmesh API server on a random port.

    The server runs with OAuth2 disabled so no token is needed for
    basic connectivity tests.
    """
    import os

    # Ensure OAuth2 is disabled for integration tests
    os.environ["CM_OAUTH2_ENABLED"] = "false"
    os.environ["CM_DOCS_ENABLED"] = "true"
    os.environ["CM_LOG_FORMAT"] = "text"
    os.environ["CM_LOG_LEVEL"] = "WARNING"

    port = _find_free_port()
    url = f"http://127.0.0.1:{port}"

    from certmesh.api.app import create_app

    app = create_app()

    config = uvicorn.Config(
        app,
        host="127.0.0.1",
        port=port,
        log_level="warning",
    )
    server = uvicorn.Server(config)

    thread = threading.Thread(target=server.run, daemon=True)
    thread.start()

    if not _wait_for_server(url, timeout=15.0):
        pytest.skip("certmesh API server failed to start within 15 seconds")

    yield url

    server.should_exit = True
    thread.join(timeout=5)

    if thread.is_alive():
        import logging

        logging.getLogger(__name__).warning("Live server thread did not exit within 5s")

    # Clean up env vars set for this fixture
    for key in ("CM_OAUTH2_ENABLED", "CM_DOCS_ENABLED", "CM_LOG_FORMAT", "CM_LOG_LEVEL"):
        os.environ.pop(key, None)


# =============================================================================
# Connection & Version Tests
# =============================================================================


class TestLiveConnection:
    """Test remote client against a live certmesh API server."""

    def test_connect_success(self, live_server):
        """Client connects, version matches, no auth required."""
        client = CertMeshRemoteClient(base_url=live_server)
        client.connect()
        assert client.server_version == __version__
        assert client.oauth2_enabled is False
        client.close()

    def test_version_reported_correctly(self, live_server):
        """The /api/v1/info endpoint returns the correct version."""
        import httpx

        resp = httpx.get(f"{live_server}/api/v1/info", timeout=5.0)
        assert resp.status_code == 200
        data = resp.json()
        assert data["version"] == __version__
        assert data["api_version"] == "v1"
        assert isinstance(data["oauth2_enabled"], bool)
        assert isinstance(data["providers"], list)

    def test_token_ignored_when_oauth2_disabled(self, live_server):
        """When OAuth2 is off, a provided token is silently ignored."""
        client = CertMeshRemoteClient(
            base_url=live_server,
            token="unnecessary-token",
        )
        client.connect()
        assert client.token is None  # Token cleared
        assert client.oauth2_enabled is False
        client.close()


# =============================================================================
# Health Endpoint Tests
# =============================================================================


class TestLiveHealth:
    def test_healthz(self, live_server):
        """GET /healthz returns ok with correct version."""
        client = CertMeshRemoteClient(base_url=live_server)
        client.connect()
        result = client.health()
        assert result["status"] == "ok"
        assert result["version"] == __version__
        client.close()

    def test_readyz(self, live_server):
        """GET /readyz returns a status (ok or degraded)."""
        client = CertMeshRemoteClient(base_url=live_server)
        client.connect()
        result = client.readiness()
        assert result["status"] in ("ok", "degraded")
        client.close()


# =============================================================================
# OpenAPI Spec Test
# =============================================================================


class TestLiveOpenAPI:
    def test_openapi_json_accessible(self, live_server):
        """The OpenAPI 3.x spec is served at /openapi.json."""
        import httpx

        resp = httpx.get(f"{live_server}/openapi.json", timeout=5.0)
        assert resp.status_code == 200
        spec = resp.json()
        assert "openapi" in spec
        assert spec["openapi"].startswith("3.")
        assert "paths" in spec
        assert "/api/v1/info" in spec["paths"]
        assert "/healthz" in spec["paths"]


# =============================================================================
# Error Handling Tests
# =============================================================================


class TestLiveErrors:
    def test_connection_refused(self):
        """Connecting to a closed port raises RemoteConnectionError."""
        port = _find_free_port()
        client = CertMeshRemoteClient(base_url=f"http://127.0.0.1:{port}")
        try:
            with pytest.raises(RemoteConnectionError, match="Cannot reach"):
                client.connect()
        finally:
            client.close()

    def test_invalid_endpoint_404(self, live_server):
        """Requesting a non-existent endpoint raises CertMeshError."""
        from certmesh.exceptions import CertMeshError

        client = CertMeshRemoteClient(base_url=live_server)
        client.connect()
        with pytest.raises(CertMeshError, match="404"):
            client._request("GET", "/api/v1/nonexistent")
        client.close()


# =============================================================================
# TLS & Proxy Configuration Tests
# =============================================================================


class TestLiveClientConfig:
    def test_loopback_no_https_warning(self, live_server, capsys):
        """Connecting to loopback with a token does not warn about HTTP."""
        client = CertMeshRemoteClient(
            base_url=live_server,
            token="test-token",
        )
        client.connect()
        captured = capsys.readouterr()
        assert "WARNING" not in captured.err
        client.close()

    def test_timeout_respected(self, live_server):
        """Client timeout is set correctly."""
        client = CertMeshRemoteClient(base_url=live_server, timeout=5)
        client.connect()
        assert client._session is not None
        client.close()


# =============================================================================
# Port-Forward URL Parsing (no kubectl needed)
# =============================================================================


class TestK8sURLParsing:
    """Test k8s:// URL parsing without requiring kubectl."""

    def test_parse_valid_k8s_url(self):
        from certmesh.k8s_portforward import parse_k8s_url

        ns, svc, port, tls = parse_k8s_url("k8s://certmesh/certmesh-api:8000")
        assert ns == "certmesh"
        assert svc == "certmesh-api"
        assert port == 8000
        assert tls is False

    def test_parse_valid_k8s_tls_url(self):
        from certmesh.k8s_portforward import parse_k8s_url

        ns, svc, port, tls = parse_k8s_url("k8s+tls://prod/api-svc:8443")
        assert ns == "prod"
        assert svc == "api-svc"
        assert port == 8443
        assert tls is True

    def test_parse_invalid_scheme_rejected(self):
        from certmesh.k8s_portforward import parse_k8s_url

        with pytest.raises(ConfigurationError):
            parse_k8s_url("https://not-k8s.example.com")
