"""
certmesh
========

Automated TLS certificate lifecycle client for DigiCert CertCentral,
Venafi Trust Protection Platform, HashiCorp Vault PKI, and AWS ACM.

Install
-------
::

    pip install certmesh

CLI entry point
---------------
::

    certmesh --help
    certmesh digicert list
    certmesh vault-pki issue --cn myservice.example.com
    certmesh acm request --cn myapp.example.com
    certmesh config show

Supported providers
-------------------
* DigiCert CertCentral (order, list, search, download)
* Venafi TPP (renew, list, search, download)
* HashiCorp Vault PKI (issue, sign)
* AWS ACM (request public certs, export, private CA issue)
"""

from importlib.metadata import PackageNotFoundError, version
from typing import Any

try:
    __version__ = version("certmesh")
except PackageNotFoundError:
    try:
        from certmesh._version import __version__  # type: ignore[no-redef]
    except ImportError:
        __version__ = "0.0.0.dev0"

JsonDict = dict[str, Any]
"""Alias for JSON-compatible dictionaries used throughout certmesh."""

__all__ = ["JsonDict", "__version__"]
