from .dto import RelatedObj
