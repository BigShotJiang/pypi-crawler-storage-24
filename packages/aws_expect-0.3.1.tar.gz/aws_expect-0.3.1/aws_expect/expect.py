from typing import Any

from aws_expect.dynamodb import DynamoDBItemExpectation, DynamoDBTableExpectation
from aws_expect.s3 import S3ObjectExpectation
from aws_expect.sqs import SQSQueueExpectation


def expect_s3(s3_object: Any) -> S3ObjectExpectation:
    """Create an expectation for an S3 resource Object.

    Args:
        s3_object: A boto3 S3 Object resource
            (``boto3.resource("s3").Object(bucket, key)``).

    Returns:
        An :class:`S3ObjectExpectation` that can be used to wait for
        the object to exist or not exist.

    Example::

        import boto3
        from aws_expect import expect_s3

        s3 = boto3.resource("s3")
        obj = s3.Object("my-bucket", "report.csv")
        metadata = expect_s3(obj).to_exist(timeout=30)
    """
    return S3ObjectExpectation(s3_object)


def expect_dynamodb_item(table: Any) -> DynamoDBItemExpectation:
    """Create an expectation for a DynamoDB Table resource item.

    Args:
        table: A boto3 DynamoDB Table resource
            (``boto3.resource("dynamodb").Table(name)``).

    Returns:
        A :class:`DynamoDBItemExpectation` that can be used to wait for
        an item to exist (with optional entry matching) or not exist.

    Example::

        import boto3
        from aws_expect import expect_dynamodb_item

        dynamodb = boto3.resource("dynamodb")
        table = dynamodb.Table("my-table")
        item = expect_dynamodb_item(table).to_exist(key={"pk": "user-1"}, timeout=30)
    """
    return DynamoDBItemExpectation(table)


def expect_dynamodb_table(
    dynamodb_resource: Any, table_name: str
) -> DynamoDBTableExpectation:
    """Create an expectation for a DynamoDB table.

    Use this to wait for a table to exist (and become ACTIVE) or to be
    deleted.

    Args:
        dynamodb_resource: A boto3 DynamoDB resource
            (``boto3.resource("dynamodb")``).
        table_name: The name of the DynamoDB table to check.

    Returns:
        A :class:`DynamoDBTableExpectation` that can be used to wait for
        the table to exist or not exist.

    Example::

        import boto3
        from aws_expect import expect_dynamodb_table

        dynamodb = boto3.resource("dynamodb")
        description = expect_dynamodb_table(dynamodb, "my-table").to_exist(timeout=60)
    """
    return DynamoDBTableExpectation(dynamodb_resource, table_name)


def expect_sqs(queue: Any) -> SQSQueueExpectation:
    """Create an expectation for a boto3 SQS Queue resource.

    Args:
        queue: A boto3 SQS Queue resource
            (``boto3.resource("sqs").Queue(url)``).

    Returns:
        An :class:`SQSQueueExpectation` that can be used to wait for
        a message to be present or to consume a message.

    Example::

        import boto3
        from aws_expect import expect_sqs

        sqs = boto3.resource("sqs")
        queue = sqs.Queue("https://sqs.us-east-1.amazonaws.com/123/my-queue")
        message = expect_sqs(queue).to_have_message(body="hello", timeout=30)
    """
    return SQSQueueExpectation(queue)
