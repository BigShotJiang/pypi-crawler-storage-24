
class FitterModelCoordinateField(Exception):
    pass
