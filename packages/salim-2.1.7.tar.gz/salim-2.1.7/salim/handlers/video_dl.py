"""
Salim Video Downloader v2 — /yt command
=========================================
Supports 1000+ sites: YouTube, Twitter/X, Instagram, TikTok, Facebook,
Reddit, Twitch, Vimeo, Dailymotion, SoundCloud, Bilibili, Pinterest,
LinkedIn, Snapchat, and everything yt-dlp supports.

Commands:
  /yt <url>                          — interactive format picker
  /yt <url> video [quality]          — best video (720, 1080, 4k, best, worst)
  /yt <url> audio [format]           — audio (mp3, m4a, opus, flac, wav, aac)
  /yt <url> clip <start> <end>       — time segment (1:30-2:45 or 90s-165s)
  /yt <url> info                     — metadata + available formats
  /yt <url> subs [lang]              — subtitles (en, ar, fr, auto)
  /yt <url> thumb                    — thumbnail image
  /yt <url> playlist [start] [end]   — download playlist range
  /yt <url> chapters                 — split by chapters
  /ytbatch <url1> <url2> ...         — batch download multiple URLs
  /ytqueue                           — show download queue
  /ytcancel                          — cancel queued downloads

Size/Upload Strategy (NO effective limit):
  <= 50 MB : Telegram direct send (video/audio/document)
  >  50 MB : Auto-split into 45MB parts, sent sequentially
  Fallback : Saved to ~/Downloads/Salim/ with full path

Bypass Arsenal (7 layers):
  1. Rotating user-agents (Chrome, Firefox, Safari, Android, iOS, TV)
  2. Cookie jar + live browser cookie extraction
  3. IPv4/IPv6 toggle + geo-bypass country spoofing
  4. YouTube player client rotation (web, tv_embedded, android, ios, android_vr)
  5. gallery-dl fallback for social media (Instagram, Pinterest, DeviantArt...)
  6. aria2c parallel downloader for direct links
  7. yt-dlp Python API fallback (bypasses PATH issues)
  + Auto-update yt-dlp before final retry
"""
from __future__ import annotations

import asyncio
import hashlib
import html
import io
import json
import logging
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from collections import deque
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.video_dl")

esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

# ══════════════════════════════════════════════════════════════════════════════
#  CONSTANTS
# ══════════════════════════════════════════════════════════════════════════════

TG_FILE_LIMIT     = 50 * 1024 * 1024      # 50 MB Telegram Bot API hard limit
TG_SPLIT_LIMIT    = 45 * 1024 * 1024      # 45 MB per part (safe margin)
DOWNLOAD_DIR      = Path.home() / "Downloads" / "Salim"
COOKIE_FILE       = Path.home() / ".salim" / "yt_cookies.txt"
PROXY_FILE        = Path.home() / ".salim" / "proxy.txt"
PROGRESS_INTERVAL = 3.0                   # seconds between Telegram progress edits
MAX_RETRIES       = 6                     # total bypass attempts before giving up
ARIA2C_SPLITS     = 8                     # parallel connections for aria2c

_USER_AGENTS = [
    # Desktop Chrome (Windows)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    # Desktop Chrome (Mac)
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    # Firefox (Linux)
    "Mozilla/5.0 (X11; Linux x86_64; rv:126.0) Gecko/20100101 Firefox/126.0",
    # Firefox (Windows)
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) Gecko/20100101 Firefox/126.0",
    # Safari (macOS)
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    # Chrome (Android)
    "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.6422.82 Mobile Safari/537.36",
    # Safari (iPhone)
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
    # Smart TV
    "Mozilla/5.0 (SMART-TV; Linux; Tizen 8.0) AppleWebKit/538.1 (KHTML, like Gecko) Version/8.0 TV Safari/538.1",
]
_ua_idx = 0


def _next_ua() -> str:
    global _ua_idx
    ua = _USER_AGENTS[_ua_idx % len(_USER_AGENTS)]
    _ua_idx += 1
    return ua


# ══════════════════════════════════════════════════════════════════════════════
#  AUTO-INSTALL: ALL TOOLS
# ══════════════════════════════════════════════════════════════════════════════

def _pip(pkg: str) -> bool:
    """Install pip package silently. Returns True on success."""
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet",
             "--disable-pip-version-check", pkg],
            capture_output=True, timeout=180,
        )
        return r.returncode == 0
    except Exception:
        return False


def _can_import(name: str) -> bool:
    try:
        __import__(name)
        return True
    except ImportError:
        return False


def ensure_tools() -> dict[str, bool]:
    """
    Ensure yt-dlp, ffmpeg, aria2c, gallery-dl are available.
    Installs missing tools automatically. Safe to call multiple times.
    """
    status: dict[str, bool] = {}

    # ── yt-dlp ─────────────────────────────────────────────────────────────
    if not shutil.which("yt-dlp"):
        logger.info("Auto-installing yt-dlp…")
        _pip("yt-dlp")
        if not shutil.which("yt-dlp"):
            # Try pipx as fallback
            try:
                subprocess.run(["pipx", "install", "yt-dlp"],
                               capture_output=True, timeout=120)
            except Exception:
                pass
    status["yt-dlp"] = bool(shutil.which("yt-dlp") or _can_import("yt_dlp"))

    # ── ffmpeg (required for merging, transcoding) ─────────────────────────
    status["ffmpeg"] = bool(shutil.which("ffmpeg"))
    if not status["ffmpeg"]:
        # imageio-ffmpeg bundles a static ffmpeg binary
        if _pip("imageio-ffmpeg"):
            try:
                import imageio_ffmpeg
                ffp = imageio_ffmpeg.get_ffmpeg_exe()
                os.environ["PATH"] = (
                    str(Path(ffp).parent) + os.pathsep + os.environ.get("PATH", "")
                )
                status["ffmpeg"] = bool(shutil.which("ffmpeg"))
            except Exception:
                pass
        if not status["ffmpeg"]:
            # static-ffmpeg: downloads a pre-built static binary
            if _pip("static-ffmpeg"):
                try:
                    import static_ffmpeg
                    static_ffmpeg.add_paths()
                    status["ffmpeg"] = bool(shutil.which("ffmpeg"))
                except Exception:
                    pass

    # ── aria2c (parallel downloader for direct links) ──────────────────────
    status["aria2c"] = bool(shutil.which("aria2c"))
    if not status["aria2c"]:
        _pip("aria2p[all]")
        status["aria2c"] = bool(shutil.which("aria2c"))

    # ── gallery-dl (social media / image-board fallback) ──────────────────
    status["gallery-dl"] = bool(
        shutil.which("gallery-dl") or _can_import("gallery_dl")
    )
    if not status["gallery-dl"]:
        if _pip("gallery-dl"):
            status["gallery-dl"] = True

    # ── mutagen (audio metadata tagging) ─────────────────────────────────
    if not _can_import("mutagen"):
        _pip("mutagen")
    status["mutagen"] = _can_import("mutagen")

    return status


def _update_ytdlp() -> str:
    """Upgrade yt-dlp to fix broken extractors. Returns status string."""
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--upgrade", "--quiet",
             "--disable-pip-version-check", "yt-dlp"],
            capture_output=True, text=True, timeout=90,
        )
        if r.returncode == 0:
            return "updated ✓"
        # Fallback: ask yt-dlp to self-update
        subprocess.run(["yt-dlp", "--update"], capture_output=True, timeout=60)
        return "self-updated ✓"
    except Exception as e:
        return f"failed ({e})"


def _ytdlp_version() -> str:
    try:
        r = subprocess.run(["yt-dlp", "--version"],
                           capture_output=True, text=True, timeout=10)
        return r.stdout.strip()
    except Exception:
        return "unknown"


# ══════════════════════════════════════════════════════════════════════════════
#  PROXY & COOKIE HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _get_proxy() -> Optional[str]:
    for env in ("SALIM_PROXY", "HTTPS_PROXY", "https_proxy", "HTTP_PROXY", "http_proxy"):
        v = os.environ.get(env, "")
        if v:
            return v
    if PROXY_FILE.exists():
        lines = [
            l.strip() for l in PROXY_FILE.read_text().splitlines()
            if l.strip() and not l.startswith("#")
        ]
        if lines:
            return lines[0]
    return None


def _cookie_args() -> list[str]:
    if COOKIE_FILE.exists():
        return ["--cookies", str(COOKIE_FILE)]
    return []


def _browser_cookie_args() -> list[str]:
    """Extract live cookies from installed browser."""
    for browser in ("chrome", "chromium", "firefox", "brave", "edge",
                    "safari", "opera", "vivaldi"):
        if shutil.which(browser) or shutil.which(browser.capitalize()):
            return ["--cookies-from-browser", browser]
    return []


# ══════════════════════════════════════════════════════════════════════════════
#  TIME HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _parse_time(s: str) -> Optional[float]:
    """Parse time string → seconds. HH:MM:SS, MM:SS, 90s, 1m30s, 1h2m3s."""
    s = s.strip().lower()
    m = re.match(r"^(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)$", s)
    if m:
        return int(m.group(1) or 0) * 3600 + int(m.group(2)) * 60 + float(m.group(3))
    if re.match(r"^\d+(\.\d+)?$", s):
        return float(s)
    total = 0.0
    for val, unit in re.findall(r"(\d+(?:\.\d+)?)\s*([hms])", s):
        v = float(val)
        if unit == "h":   total += v * 3600
        elif unit == "m": total += v * 60
        elif unit == "s": total += v
    return total if total > 0 else None


def _secs_to_hms(secs: float) -> str:
    secs = int(secs)
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _human_size(n: int) -> str:
    if n < 1024:       return f"{n} B"
    if n < 1024**2:    return f"{n/1024:.1f} KB"
    if n < 1024**3:    return f"{n/1024**2:.1f} MB"
    return f"{n/1024**3:.2f} GB"


# ══════════════════════════════════════════════════════════════════════════════
#  FORMAT SELECTORS
# ══════════════════════════════════════════════════════════════════════════════

def _video_fmt(quality: str) -> list[str]:
    q = quality.lower().strip()
    if q in ("", "best"):
        fmt = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best[ext=mp4]/best"
    elif q == "4k":
        fmt = ("bestvideo[height<=2160][ext=mp4]+bestaudio[ext=m4a]"
               "/bestvideo[height<=2160]+bestaudio/best")
    elif q == "worst":
        fmt = "worstvideo[ext=mp4]+worstaudio/worst"
    else:
        res = re.sub(r"[^\d]", "", q)
        if res:
            fmt = (
                f"bestvideo[height<={res}][ext=mp4]+bestaudio[ext=m4a]"
                f"/bestvideo[height<={res}]+bestaudio"
                f"/best[height<={res}][ext=mp4]/best[height<={res}]"
                f"/bestvideo[ext=mp4]+bestaudio[ext=m4a]/best"
            )
        else:
            fmt = "bestvideo[ext=mp4]+bestaudio[ext=m4a]/bestvideo+bestaudio/best"
    return ["--format", fmt, "--merge-output-format", "mp4"]


def _audio_fmt(fmt: str) -> tuple[list[str], str]:
    """Returns (yt-dlp args, output extension)."""
    fmt = fmt.lower().strip()
    MAP = {
        "mp3":  ("bestaudio/best", "mp3"),
        "m4a":  ("bestaudio[ext=m4a]/bestaudio/best", "m4a"),
        "aac":  ("bestaudio[ext=m4a]/bestaudio/best", "aac"),
        "opus": ("bestaudio[ext=webm][acodec=opus]/bestaudio/best", "opus"),
        "flac": ("bestaudio/best", "flac"),
        "wav":  ("bestaudio/best", "wav"),
        "ogg":  ("bestaudio/best", "vorbis"),
    }
    sel, ext = MAP.get(fmt, ("bestaudio/best", "mp3"))
    args = ["--format", sel, "--extract-audio", "--audio-format", ext, "--audio-quality", "0"]
    if shutil.which("ffmpeg"):
        args += ["--embed-thumbnail", "--add-metadata"]
    return args, ext


# ══════════════════════════════════════════════════════════════════════════════
#  YT-DLP COMMAND BUILDER  — 7 bypass layers
# ══════════════════════════════════════════════════════════════════════════════

def _build_cmd(
    url: str,
    out_tmpl: str,
    fmt_args: list[str],
    attempt: int,
    extra: list[str] | None = None,
) -> list[str]:
    """
    Build complete yt-dlp command for given bypass attempt level.
    attempt 0 : baseline (rotating UA, geo-bypass, concurrent fragments)
    attempt 1 : force IPv4
    attempt 2 : browser cookie extraction
    attempt 3 : YouTube TV embedded client (bypasses age-gate)
    attempt 4 : YouTube Android client (different token endpoint)
    attempt 5 : YouTube iOS client + extra spoofing headers
    attempt 6+ : YouTube android_vr client (last resort)
    """
    proxy = _get_proxy()
    cmd = [
        "yt-dlp",
        "--no-playlist",
        "--geo-bypass",
        "--geo-bypass-country", "US",
        "--user-agent", _next_ua(),
        "--add-header", "Accept-Language:en-US,en;q=0.9",
        "--add-header", "Accept:text/html,application/xhtml+xml,*/*;q=0.8",
        "--add-header", "Accept-Encoding:gzip, deflate, br",
        "--add-header", "DNT:1",
        "--fragment-retries", "15",
        "--retries", "10",
        "--file-access-retries", "5",
        "--retry-sleep", "linear=1::5",
        "--socket-timeout", "30",
        "--extractor-retries", "5",
        "--concurrent-fragments", "4",
        "--buffer-size", "16K",
        "--http-chunk-size", "10M",
        "--no-abort-on-error",
        "--ignore-errors",
        "--no-warnings",
        "--progress",
        "--newline",
        "--output", out_tmpl,
    ]
    cmd += _cookie_args()
    if proxy:
        cmd += ["--proxy", proxy]

    if attempt == 1:
        cmd += ["--force-ipv4"]
    elif attempt == 2:
        cmd += _browser_cookie_args()
    elif attempt == 3:
        cmd += ["--extractor-args", "youtube:player_client=tv_embedded", "--force-ipv4"]
    elif attempt == 4:
        cmd += [
            "--extractor-args", "youtube:player_client=android",
            "--extractor-args", "youtube:include_dash_manifest=False",
        ]
    elif attempt == 5:
        cmd += [
            "--extractor-args", "youtube:player_client=ios",
            "--extractor-args", "youtube:player_skip=webpage,configs",
            "--add-header", "X-Forwarded-For:8.8.8.8",
        ]
    elif attempt >= 6:
        cmd += [
            "--extractor-args", "youtube:player_client=android_vr",
            "--extractor-args", "youtube:player_skip=webpage",
            "--force-ipv4",
        ]

    cmd += fmt_args
    if extra:
        cmd += extra
    cmd.append(url)
    return cmd


# ══════════════════════════════════════════════════════════════════════════════
#  PROGRESS PARSING
# ══════════════════════════════════════════════════════════════════════════════

def _parse_progress(line: str) -> Optional[dict]:
    # Standard progress line
    m = re.search(
        r"\[download\]\s+([\d.]+)%\s+of\s+~?\s*([\d.]+\s*\S+)\s+at\s+([\d.]+\s*\S+)\s+ETA\s+(\S+)",
        line,
    )
    if m:
        return {"pct": float(m.group(1)), "size": m.group(2).strip(),
                "speed": m.group(3).strip(), "eta": m.group(4)}
    # Fragment progress
    mf = re.search(r"\[download\]\s+Downloading fragment\s+(\d+)\s+of\s+(\d+)", line)
    if mf:
        cur, tot = int(mf.group(1)), int(mf.group(2))
        return {"pct": cur / tot * 100 if tot else 0,
                "size": f"{cur}/{tot} fragments", "speed": "", "eta": ""}
    # Merger
    if re.search(r"\[Merger\]|Merging formats", line):
        return {"merging": True}
    return None


def _bar(pct: float, width: int = 14) -> str:
    n = int(width * pct / 100)
    return "█" * n + "░" * (width - n)


# ══════════════════════════════════════════════════════════════════════════════
#  CORE RUNNER  (yt-dlp with live Telegram progress)
# ══════════════════════════════════════════════════════════════════════════════

async def _run(
    cmd: list[str],
    tmpdir: Path,
    status_msg,
    label: str,
) -> Optional[Path]:
    """Execute yt-dlp, stream progress to Telegram. Returns file path or None."""
    last_edit = 0.0
    last_pct  = -1.0

    # Try yt-dlp on PATH; fall back to python -m yt_dlp
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT, cwd=str(tmpdir),
        )
    except FileNotFoundError:
        new_cmd = [sys.executable, "-m", "yt_dlp"] + cmd[1:]
        try:
            proc = await asyncio.create_subprocess_exec(
                *new_cmd, stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.STDOUT, cwd=str(tmpdir),
            )
        except Exception as e:
            logger.error(f"Cannot launch yt-dlp: {e}")
            return None

    async for raw in proc.stdout:
        line = raw.decode("utf-8", errors="replace").rstrip()
        prog = _parse_progress(line)
        if not prog:
            continue
        if prog.get("merging"):
            try:
                await status_msg.edit_text(
                    f"{label}\n\n🔀 <i>Merging video + audio…</i>", parse_mode=H
                )
            except Exception:
                pass
            continue
        pct = prog.get("pct", last_pct)
        now = time.monotonic()
        if pct != last_pct and now - last_edit >= PROGRESS_INTERVAL:
            last_pct  = pct
            last_edit = now
            txt = (
                f"{label}\n\n"
                f"<code>{_bar(pct)}</code> <b>{pct:.1f}%</b>\n"
                f"📦 {esc(prog.get('size', ''))}"
                + (f"  ⚡ {esc(prog['speed'])}" if prog.get("speed") else "")
                + (f"  ⏱ {esc(prog['eta'])}"   if prog.get("eta")   else "")
            )
            try:
                await status_msg.edit_text(txt, parse_mode=H)
            except Exception:
                pass

    await proc.wait()
    if proc.returncode != 0:
        return None

    candidates = sorted(
        [p for p in tmpdir.iterdir()
         if p.is_file() and not p.name.endswith(".part") and p.stat().st_size > 512],
        key=lambda p: p.stat().st_mtime, reverse=True,
    )
    return candidates[0] if candidates else None


# ══════════════════════════════════════════════════════════════════════════════
#  INFO EXTRACTION
# ══════════════════════════════════════════════════════════════════════════════

async def _get_info(url: str) -> Optional[dict]:
    cmd = [
        "yt-dlp", "--dump-json", "--no-playlist",
        "--user-agent", _next_ua(),
        "--geo-bypass", "--geo-bypass-country", "US",
        "--socket-timeout", "20", "--no-warnings",
    ]
    cmd += _cookie_args()
    proxy = _get_proxy()
    if proxy:
        cmd += ["--proxy", proxy]
    cmd.append(url)
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
        )
        stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=35)
        if proc.returncode == 0 and stdout:
            return json.loads(stdout.decode("utf-8", errors="replace").splitlines()[0])
    except Exception as e:
        logger.debug(f"Info extraction failed: {e}")
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  GALLERY-DL FALLBACK
# ══════════════════════════════════════════════════════════════════════════════

async def _try_gallery_dl(url: str, tmpdir: Path) -> Optional[Path]:
    if not (shutil.which("gallery-dl") or _can_import("gallery_dl")):
        return None
    cmd = ["gallery-dl", "--dest", str(tmpdir), "--no-mtime",
           "--user-agent", _next_ua(), url]
    proxy = _get_proxy()
    if proxy:
        cmd += ["--proxy", proxy]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE,
            cwd=str(tmpdir)
        )
        await asyncio.wait_for(proc.communicate(), timeout=120)
        candidates = sorted(
            [p for p in tmpdir.rglob("*")
             if p.is_file() and p.stat().st_size > 512],
            key=lambda p: p.stat().st_mtime, reverse=True
        )
        return candidates[0] if candidates else None
    except Exception as e:
        logger.debug(f"gallery-dl failed: {e}")
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  ARIA2C DIRECT DOWNLOADER
# ══════════════════════════════════════════════════════════════════════════════

async def _try_aria2c(url: str, tmpdir: Path, status_msg, label: str) -> Optional[Path]:
    if not shutil.which("aria2c"):
        return None
    cmd = [
        "aria2c",
        f"--split={ARIA2C_SPLITS}",
        f"--max-connection-per-server={ARIA2C_SPLITS}",
        "--min-split-size=1M",
        "--max-tries=5", "--retry-wait=3", "--timeout=30",
        "--user-agent", _next_ua(),
        "--header", "Accept-Language: en-US,en;q=0.9",
        "--auto-file-renaming=false",
        "--dir", str(tmpdir),
        "--out", "aria2_download",
        "--console-log-level=warn",
        url,
    ]
    proxy = _get_proxy()
    if proxy:
        cmd += [f"--all-proxy={proxy}"]
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT, cwd=str(tmpdir)
        )
        last_edit = 0.0
        async for raw in proc.stdout:
            line = raw.decode("utf-8", errors="replace").rstrip()
            m = re.search(r"\((\d+)%\).*DL:([\d.]+\S+)", line)
            if m:
                now = time.monotonic()
                if now - last_edit >= PROGRESS_INTERVAL:
                    last_edit = now
                    pct = float(m.group(1))
                    try:
                        await status_msg.edit_text(
                            f"{label}\n\n<code>{_bar(pct)}</code> <b>{pct:.0f}%</b>"
                            f"  ⚡ {esc(m.group(2))}",
                            parse_mode=H,
                        )
                    except Exception:
                        pass
        await proc.wait()
        candidates = sorted(
            [p for p in tmpdir.iterdir()
             if p.is_file() and not p.suffix == ".aria2" and p.stat().st_size > 512],
            key=lambda p: p.stat().st_mtime, reverse=True,
        )
        return candidates[0] if candidates else None
    except Exception as e:
        logger.debug(f"aria2c failed: {e}")
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  THUMBNAIL / SUBTITLE DOWNLOADERS
# ══════════════════════════════════════════════════════════════════════════════

async def _dl_thumb(url: str, tmpdir: Path) -> Optional[Path]:
    cmd = [
        "yt-dlp", "--write-thumbnail", "--skip-download",
        "--convert-thumbnails", "jpg",
        "--output", str(tmpdir / "%(title).80s.%(ext)s"),
        "--no-warnings", "--geo-bypass", "--user-agent", _next_ua(), url,
    ]
    cmd += _cookie_args()
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE, cwd=str(tmpdir)
        )
        await asyncio.wait_for(proc.communicate(), timeout=40)
    except Exception:
        pass
    imgs = [p for p in tmpdir.iterdir()
            if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")]
    return imgs[0] if imgs else None


async def _dl_subs(url: str, tmpdir: Path,
                   langs: str = "en,ar,fr,de,es,zh,ja,ko,auto") -> list[Path]:
    cmd = [
        "yt-dlp", "--write-subs", "--write-auto-subs",
        "--sub-langs", langs, "--sub-format", "srt/vtt/best",
        "--skip-download",
        "--output", str(tmpdir / "%(title).80s.%(ext)s"),
        "--no-warnings", "--geo-bypass", "--user-agent", _next_ua(), url,
    ]
    cmd += _cookie_args()
    try:
        proc = await asyncio.create_subprocess_exec(
            *cmd, stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE, cwd=str(tmpdir)
        )
        await asyncio.wait_for(proc.communicate(), timeout=60)
    except Exception:
        pass
    return [p for p in tmpdir.iterdir()
            if p.suffix.lower() in (".srt", ".vtt", ".ass", ".ssa")]


# ══════════════════════════════════════════════════════════════════════════════
#  SMART FILE SENDER  — handles all sizes
# ══════════════════════════════════════════════════════════════════════════════

async def _send_file(
    update: Update,
    filepath: Path,
    caption: str,
    status_msg,
    is_audio: bool = False,
    is_video: bool = True,
    thumb: Optional[Path] = None,
):
    """
    Send file to Telegram regardless of size.
    <= 50 MB  → direct send
    >  50 MB  → split into 45 MB parts and send each
    Fallback  → save locally and report path
    """
    msg  = update.effective_message
    size = filepath.stat().st_size
    ext  = filepath.suffix.lower()

    async def _try_send_buf(buf: io.BytesIO, fname: str, cap: str, sz: int) -> bool:
        """Attempt to send a buffer as the right media type."""
        buf.seek(0)
        kw = dict(caption=cap, parse_mode=H,
                  read_timeout=600, write_timeout=600, connect_timeout=60)
        try:
            if is_audio or fname.lower().endswith(
                    (".mp3", ".m4a", ".opus", ".flac", ".wav", ".aac", ".ogg")):
                await msg.reply_audio(audio=buf, title=filepath.stem, **kw)
            elif is_video or fname.lower().endswith(
                    (".mp4", ".mkv", ".webm", ".mov", ".avi", ".flv")):
                th_io = None
                if thumb and thumb.exists():
                    th_io = io.BytesIO(thumb.read_bytes())
                    th_io.name = thumb.name
                await msg.reply_video(video=buf, supports_streaming=True,
                                      thumbnail=th_io, **kw)
            else:
                await msg.reply_document(document=buf, filename=fname, **kw)
            return True
        except Exception as e:
            logger.warning(f"Send as media failed: {e}. Trying as document…")
            try:
                buf.seek(0)
                await msg.reply_document(document=buf, filename=fname, **kw)
                return True
            except Exception as e2:
                logger.warning(f"Document fallback failed: {e2}")
                return False

    # ── Small file: single send ────────────────────────────────────────────
    if size <= TG_FILE_LIMIT:
        try:
            await status_msg.edit_text(
                f"📤 <b>Uploading</b> {esc(filepath.name[:50])} ({_human_size(size)})…",
                parse_mode=H,
            )
        except Exception:
            pass
        buf = io.BytesIO(filepath.read_bytes())
        buf.name = filepath.name
        if await _try_send_buf(buf, filepath.name, caption, size):
            return

    # ── Large file: split into parts ──────────────────────────────────────
    else:
        n_parts = math.ceil(size / TG_SPLIT_LIMIT)
        stem = filepath.stem[:40]
        try:
            await status_msg.edit_text(
                f"📦 <b>Large file</b> ({_human_size(size)})\n"
                f"Splitting into {n_parts} parts…",
                parse_mode=H,
            )
        except Exception:
            pass
        sent = 0
        with open(filepath, "rb") as fh:
            for part_num in range(1, n_parts + 1):
                chunk = fh.read(TG_SPLIT_LIMIT)
                if not chunk:
                    break
                part_name = f"{stem}.part{part_num:02d}of{n_parts:02d}{ext}"
                part_cap  = f"{caption}\n\n📂 Part {part_num}/{n_parts} ({_human_size(len(chunk))})"
                buf = io.BytesIO(chunk)
                buf.name = part_name
                try:
                    await status_msg.edit_text(
                        f"📤 <b>Uploading part {part_num}/{n_parts}</b> ({_human_size(len(chunk))})…",
                        parse_mode=H,
                    )
                except Exception:
                    pass
                if await _try_send_buf(buf, part_name, part_cap, len(chunk)):
                    sent += 1
                else:
                    break   # If one part fails, fall through to local save
        if sent == n_parts:
            return

    # ── Final fallback: save locally ─────────────────────────────────────
    DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
    dest = DOWNLOAD_DIR / filepath.name
    if dest.exists():
        dest = DOWNLOAD_DIR / f"{filepath.stem}_{int(time.time())}{filepath.suffix}"
    shutil.copy2(str(filepath), str(dest))
    await msg.reply_text(
        f"💾 <b>Saved locally</b> ({_human_size(size)})\n\n"
        f"<code>{esc(str(dest))}</code>\n\n"
        f"{caption}",
        parse_mode=H,
    )


# ══════════════════════════════════════════════════════════════════════════════
#  MAIN DOWNLOAD ORCHESTRATOR
# ══════════════════════════════════════════════════════════════════════════════

async def do_download(
    url: str,
    mode: str,
    quality: str,
    start_sec: Optional[float],
    end_sec:   Optional[float],
    update: Update,
    ctx: ContextTypes.DEFAULT_TYPE,
    langs: str = "en,auto",
):
    msg = update.effective_message

    # Ensure tools available (auto-installs if missing)
    tools = ensure_tools()
    if not tools.get("yt-dlp"):
        await msg.reply_text(
            "⚠️ <b>yt-dlp not available</b>\n"
            "Run: <code>pip install yt-dlp</code>",
            parse_mode=H,
        )
        return

    # Status message anchor
    status = await msg.reply_text(
        f"🔍 <i>Fetching info…</i>\n<code>{esc(url[:80])}</code>",
        parse_mode=H,
    )

    # Fetch metadata
    info         = await _get_info(url)
    title_raw    = (info.get("title") or url)[:80] if info else url[:60]
    title_e      = esc(title_raw)
    uploader_e   = esc(info.get("uploader") or info.get("channel") or "") if info else ""
    dur          = info.get("duration") if info else None
    dur_str      = f"  ⏱ {_secs_to_hms(dur)}" if dur else ""
    views        = info.get("view_count") if info else None

    # ── Info mode ────────────────────────────────────────────────────────
    if mode == "info":
        if not info:
            await status.edit_text(
                f"❌ Could not fetch info.\n<code>{esc(url)}</code>", parse_mode=H
            )
            return
        await _render_info(info, status)
        return

    # ── Picker mode ──────────────────────────────────────────────────────
    if mode == "pick":
        if info:
            await status.delete()
            await _show_picker(update, url, info)
        else:
            await status.edit_text(
                f"⚠️ No metadata — downloading best quality…\n<code>{esc(url[:80])}</code>",
                parse_mode=H,
            )
            mode    = "video"
            quality = "best"
        if mode == "pick":
            return

    # ── Thumbnail mode ───────────────────────────────────────────────────
    if mode == "thumb":
        await status.edit_text("🖼 <i>Downloading thumbnail…</i>", parse_mode=H)
        with tempfile.TemporaryDirectory(prefix="salim_yt_") as td:
            thumb = await _dl_thumb(url, Path(td))
            if thumb:
                cap = (f"🖼 <b>{title_e}</b>"
                       + (f"\n👤 {uploader_e}" if uploader_e else ""))
                await msg.reply_photo(
                    photo=io.BytesIO(thumb.read_bytes()),
                    caption=cap, parse_mode=H,
                )
                try: await status.delete()
                except Exception: pass
            else:
                await status.edit_text("❌ Could not download thumbnail.", parse_mode=H)
        return

    # ── Subtitles mode ───────────────────────────────────────────────────
    if mode == "subs":
        await status.edit_text(
            f"💬 <i>Downloading subtitles [{esc(langs)}]…</i>", parse_mode=H
        )
        with tempfile.TemporaryDirectory(prefix="salim_yt_") as td:
            subs = await _dl_subs(url, Path(td), langs)
            if subs:
                for sf in subs:
                    await msg.reply_document(
                        document=io.BytesIO(sf.read_bytes()),
                        filename=sf.name,
                        caption=f"💬 {esc(sf.name)}",
                    )
                try: await status.delete()
                except Exception: pass
            else:
                await status.edit_text(
                    "❌ No subtitles found.\n"
                    "<i>Try: /yt &lt;url&gt; subs en,auto</i>",
                    parse_mode=H,
                )
        return

    # ── Build progress label ─────────────────────────────────────────────
    if mode == "clip" and start_sec is not None and end_sec is not None:
        clip_dur = end_sec - start_sec
        label = (
            f"✂️ <b>Clip</b> {_secs_to_hms(start_sec)}→{_secs_to_hms(end_sec)}"
            f" ({_secs_to_hms(clip_dur)})\n📹 {title_e}"
        )
    elif mode == "audio":
        label = f"🎵 <b>Audio</b> [{esc(quality or 'mp3')}]\n📹 {title_e}"
    elif mode == "playlist":
        label = f"📋 <b>Playlist</b> [{int(start_sec or 1)}–{int(end_sec or 50)}]\n📹 {title_e}"
    elif mode == "chapters":
        label = f"📑 <b>Chapters</b>\n📹 {title_e}"
    else:
        q_lbl = quality if quality not in ("", "best") else "best"
        label = f"📥 <b>Video [{esc(q_lbl)}]</b>{dur_str}\n📹 {title_e}"
        if uploader_e: label += f"\n👤 {uploader_e}"
        if views:      label += f"\n👁 {views:,}"

    await status.edit_text(f"{label}\n\n<i>Starting…</i>", parse_mode=H)

    # ── Format args & extra flags by mode ────────────────────────────────
    if mode == "clip":
        fmt_args   = _video_fmt("best")
        extra_base = [
            "--download-sections",
            f"*{_secs_to_hms(start_sec)}-{_secs_to_hms(end_sec)}",
            "--force-keyframes-at-cuts",
        ]
    elif mode == "audio":
        fmt_args, _ = _audio_fmt(quality)
        extra_base  = []
    elif mode == "playlist":
        fmt_args   = _video_fmt(quality or "best")
        extra_base = [
            "--yes-playlist",
            "--playlist-start", str(int(start_sec or 1)),
            "--playlist-end",   str(int(end_sec or 50)),
        ]
    elif mode == "chapters":
        fmt_args   = _video_fmt(quality or "best")
        extra_base = ["--split-chapters"]
    else:
        fmt_args   = _video_fmt(quality)
        extra_base = []

    # ── Retry loop ───────────────────────────────────────────────────────
    with tempfile.TemporaryDirectory(prefix="salim_yt_") as td:
        tmpdir   = Path(td)
        out_tmpl = str(tmpdir / "%(title).80s.%(ext)s")
        if mode == "playlist":
            out_tmpl = str(tmpdir / "%(playlist_index)s_%(title).60s.%(ext)s")
        elif mode == "chapters":
            out_tmpl = str(tmpdir / "%(chapter_number)s_%(chapter).60s.%(ext)s")

        result = None

        for attempt in range(MAX_RETRIES + 1):
            if attempt > 0:
                wait = min(2 ** attempt, 30)
                if attempt == MAX_RETRIES - 1:
                    upd = _update_ytdlp()
                    try:
                        await status.edit_text(
                            f"{label}\n\n🔄 Updated yt-dlp ({upd}) — final attempt…",
                            parse_mode=H,
                        )
                    except Exception:
                        pass
                else:
                    try:
                        await status.edit_text(
                            f"{label}\n\n⚠️ Retry {attempt}/{MAX_RETRIES} "
                            f"(bypass layer {attempt})…",
                            parse_mode=H,
                        )
                    except Exception:
                        pass
                await asyncio.sleep(wait)

            cmd    = _build_cmd(url, out_tmpl, fmt_args, attempt, extra_base)
            result = await _run(cmd, tmpdir, status, label)
            if result:
                break

            # gallery-dl fallback at attempt 2
            if attempt == 2:
                gd = await _try_gallery_dl(url, tmpdir)
                if gd:
                    result = gd
                    break

            # aria2c for direct links at attempt 3
            if attempt == 3:
                is_direct = any([
                    url.lower().endswith((".mp4", ".mkv", ".mp3", ".m4a", ".webm",
                                          ".m3u8", ".flv", ".avi")),
                    "cdn." in url.lower(),
                    "/download/" in url.lower(),
                ])
                if is_direct:
                    ar = await _try_aria2c(url, tmpdir, status, label)
                    if ar:
                        result = ar
                        break

        # ── Python API last resort ────────────────────────────────────
        if not result:
            try:
                import yt_dlp
                opts = {
                    "outtmpl": out_tmpl,
                    "format": "bestvideo+bestaudio/best",
                    "merge_output_format": "mp4",
                    "geo_bypass": True,
                    "no_warnings": True,
                    "quiet": True,
                    "ignoreerrors": False,
                    "fragment_retries": 10,
                    "retries": 10,
                }
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None,
                    lambda: yt_dlp.YoutubeDL(opts).__enter__().download([url])
                )
                cands = sorted(
                    [p for p in tmpdir.iterdir()
                     if p.is_file() and not p.name.endswith(".part")
                     and p.stat().st_size > 512],
                    key=lambda p: p.stat().st_mtime, reverse=True,
                )
                result = cands[0] if cands else None
            except Exception as e:
                logger.debug(f"Python API fallback: {e}")

        # ── Complete failure ──────────────────────────────────────────
        if not result:
            v = _ytdlp_version()
            await status.edit_text(
                f"❌ <b>Download failed</b> after {MAX_RETRIES + 1} attempts\n\n"
                f"🔗 <code>{esc(url[:100])}</code>\n\n"
                f"<i>Tried: rotating UAs → IPv4 → browser cookies → "
                f"TV/Android/iOS clients → gallery-dl → aria2c → yt-dlp update (v{esc(v)})</i>\n\n"
                f"💡 <b>Fix:</b>\n"
                f"• Cookies: <code>~/.salim/yt_cookies.txt</code>\n"
                f"• Proxy: <code>~/.salim/proxy.txt</code> or <code>SALIM_PROXY</code>\n"
                f"• DRM / private / deleted content cannot be downloaded",
                parse_mode=H,
            )
            return

        # ── Collect all output files (playlist/chapters may produce many)
        all_files = sorted(
            [p for p in tmpdir.iterdir()
             if p.is_file() and not p.name.endswith(".part") and p.stat().st_size > 512],
            key=lambda p: p.name,
        )

        # ── Thumbnail extraction from video via ffmpeg ────────────────
        thumb_path = None
        thumb_cands = [p for p in tmpdir.iterdir()
                       if p.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")]
        if thumb_cands:
            thumb_path = thumb_cands[0]
        elif mode in ("video", "clip") and shutil.which("ffmpeg") and result:
            t_out = tmpdir / "_thumb.jpg"
            try:
                subprocess.run(
                    ["ffmpeg", "-i", str(result), "-vframes", "1",
                     "-q:v", "2", "-ss", "5", str(t_out), "-y"],
                    capture_output=True, timeout=15,
                )
                if t_out.exists() and t_out.stat().st_size > 0:
                    thumb_path = t_out
            except Exception:
                pass

        # ── Multiple files (playlist / chapters) ─────────────────────
        if mode in ("playlist", "chapters") and len(all_files) > 1:
            await status.edit_text(
                f"📤 <b>Sending {len(all_files)} files…</b>", parse_mode=H
            )
            for i, fp in enumerate(all_files, 1):
                sz  = _human_size(fp.stat().st_size)
                cap = f"{'📑' if mode=='chapters' else '📋'} {esc(fp.stem[:60])}\n💾 {sz}"
                sub_s = await msg.reply_text(
                    f"📤 <i>Uploading {i}/{len(all_files)}…</i>", parse_mode=H
                )
                await _send_file(update, fp, cap, sub_s,
                                 is_audio=False, is_video=True)
                try: await sub_s.delete()
                except Exception: pass
            try: await status.delete()
            except Exception: pass
            return

        # ── Single file ───────────────────────────────────────────────
        fp   = result
        size = fp.stat().st_size

        caption_parts = [f"📹 <b>{title_e}</b>"]
        if uploader_e:   caption_parts.append(f"👤 {uploader_e}")
        if dur:          caption_parts.append(f"⏱ {_secs_to_hms(dur)}")
        if views:        caption_parts.append(f"👁 {views:,}")
        caption_parts.append(f"💾 {_human_size(size)}")
        caption_parts.append(f"🔗 <a href=\"{esc(url)}\">Source</a>")
        caption = "\n".join(caption_parts)

        await _send_file(
            update, fp, caption, status,
            is_audio=(mode == "audio"),
            is_video=(mode != "audio"),
            thumb=thumb_path,
        )
        try: await status.delete()
        except Exception: pass


# ══════════════════════════════════════════════════════════════════════════════
#  FORMAT PICKER (inline keyboard)
# ══════════════════════════════════════════════════════════════════════════════

async def _show_picker(update: Update, url: str, info: dict):
    msg      = update.effective_message
    title    = esc((info.get("title") or url)[:60])
    uploader = esc(info.get("uploader") or info.get("channel") or "")
    dur      = info.get("duration")
    dur_str  = f"  ⏱ {_secs_to_hms(dur)}" if dur else ""

    # Real available resolutions
    fmts    = info.get("formats") or []
    heights = sorted(
        {f.get("height") for f in fmts
         if f.get("vcodec") not in (None, "none") and f.get("height")},
        reverse=True,
    )[:4]

    slot = _store_session(url, info)
    res_row = [
        InlineKeyboardButton(f"📺 {h}p", callback_data=f"yt_dl:{slot}:video:{h}")
        for h in heights
    ]

    keyboard = [
        [
            InlineKeyboardButton("🎬 Best",  callback_data=f"yt_dl:{slot}:video:best"),
            InlineKeyboardButton("📱 720p",  callback_data=f"yt_dl:{slot}:video:720"),
            InlineKeyboardButton("🔮 4K",    callback_data=f"yt_dl:{slot}:video:4k"),
        ],
    ]
    if res_row:
        keyboard.append(res_row)
    keyboard += [
        [
            InlineKeyboardButton("🎵 MP3",   callback_data=f"yt_dl:{slot}:audio:mp3"),
            InlineKeyboardButton("🎧 M4A",   callback_data=f"yt_dl:{slot}:audio:m4a"),
            InlineKeyboardButton("🎼 FLAC",  callback_data=f"yt_dl:{slot}:audio:flac"),
            InlineKeyboardButton("🔊 OPUS",  callback_data=f"yt_dl:{slot}:audio:opus"),
        ],
        [
            InlineKeyboardButton("✂️ Clip…",    callback_data=f"yt_dl:{slot}:clip_prompt:"),
            InlineKeyboardButton("📑 Chapters", callback_data=f"yt_dl:{slot}:chapters:best"),
        ],
        [
            InlineKeyboardButton("🖼 Thumb",    callback_data=f"yt_dl:{slot}:thumb:"),
            InlineKeyboardButton("💬 Subs EN",  callback_data=f"yt_dl:{slot}:subs:en,auto"),
            InlineKeyboardButton("ℹ️ Info",     callback_data=f"yt_dl:{slot}:info:"),
        ],
        [InlineKeyboardButton("❌ Cancel",      callback_data="yt_cancel")],
    ]

    header = (
        f"🎬 <b>{title}</b>\n"
        + (f"👤 {uploader}\n" if uploader else "")
        + dur_str + "\n\n<i>Choose format:</i>"
    )
    await msg.reply_text(
        header, parse_mode=H,
        reply_markup=InlineKeyboardMarkup(keyboard),
    )


# ══════════════════════════════════════════════════════════════════════════════
#  INFO RENDERER
# ══════════════════════════════════════════════════════════════════════════════

async def _render_info(info: dict, status_msg):
    title    = esc((info.get("title") or "Unknown")[:80])
    uploader = esc(info.get("uploader") or info.get("channel") or "Unknown")
    dur      = info.get("duration")
    views    = info.get("view_count")
    likes    = info.get("like_count")
    desc     = (info.get("description") or "")[:400]
    webpage  = info.get("webpage_url") or ""
    upload_d = info.get("upload_date") or ""

    lines = [f"🎬 <b>{title}</b>", f"👤 {uploader}"]
    if len(upload_d) == 8:
        lines.append(f"📅 {upload_d[:4]}-{upload_d[4:6]}-{upload_d[6:]}")
    if dur:   lines.append(f"⏱ {_secs_to_hms(dur)}")
    if views: lines.append(f"👁 {views:,} views")
    if likes: lines.append(f"👍 {likes:,} likes")

    fmts    = info.get("formats") or []
    heights = sorted(
        {f.get("height") for f in fmts
         if f.get("vcodec") not in (None, "none") and f.get("height")},
        reverse=True,
    )
    if heights:
        lines.append(f"🎞 Video: {', '.join(str(h)+'p' for h in heights[:8])}")

    audio_exts = sorted({
        f.get("ext") for f in fmts
        if f.get("acodec") not in (None, "none") and f.get("vcodec") in (None, "none") and f.get("ext")
    })
    if audio_exts:
        lines.append(f"🎵 Audio: {', '.join(list(audio_exts)[:6])}")

    if desc:
        lines.append(f"\n📝 <i>{esc(desc[:350])}{'…' if len(desc) > 350 else ''}</i>")

    chapters = info.get("chapters") or []
    if chapters:
        lines.append(f"\n📑 {len(chapters)} chapters:")
        for ch in chapters[:5]:
            lines.append(f"  • {_secs_to_hms(ch.get('start_time', 0))} — {esc(ch.get('title','')[:50])}")
        if len(chapters) > 5:
            lines.append(f"  … +{len(chapters)-5} more")

    if webpage:
        lines.append(f"\n🔗 <a href=\"{esc(webpage)}\">Open URL</a>")

    await status_msg.edit_text(
        "\n".join(lines), parse_mode=H, disable_web_page_preview=True
    )


# ══════════════════════════════════════════════════════════════════════════════
#  SESSION STORE
# ══════════════════════════════════════════════════════════════════════════════

_sessions: dict[str, dict] = {}
_SESSION_TTL = 1800  # 30 minutes


def _store_session(url: str, info: dict) -> str:
    slot = hashlib.md5(f"{url}{time.time()}".encode()).hexdigest()[:12]
    _sessions[slot] = {"url": url, "info": info, "ts": time.time()}
    cutoff = time.time() - _SESSION_TTL
    for k in list(_sessions):
        if _sessions[k]["ts"] < cutoff:
            del _sessions[k]
    return slot


def _get_session(slot: str) -> Optional[dict]:
    s = _sessions.get(slot)
    if s and time.time() - s["ts"] < _SESSION_TTL:
        return s
    return None


# ══════════════════════════════════════════════════════════════════════════════
#  DOWNLOAD QUEUE
# ══════════════════════════════════════════════════════════════════════════════

@dataclass
class _QItem:
    url:       str
    mode:      str
    quality:   str
    start_sec: Optional[float]
    end_sec:   Optional[float]
    update:    Any
    ctx:       Any


_dl_queue:   deque[_QItem] = deque()
_queue_task: Optional[asyncio.Task] = None
_current_dl: Optional[str] = None


async def _queue_worker():
    global _current_dl
    while _dl_queue:
        item = _dl_queue.popleft()
        _current_dl = item.url
        try:
            await do_download(item.url, item.mode, item.quality,
                              item.start_sec, item.end_sec, item.update, item.ctx)
        except Exception as e:
            logger.error(f"Queue error: {e}")
        finally:
            _current_dl = None
        await asyncio.sleep(1)


def _enqueue(item: _QItem):
    global _queue_task
    _dl_queue.append(item)
    if _queue_task is None or _queue_task.done():
        _queue_task = asyncio.create_task(_queue_worker())


# ══════════════════════════════════════════════════════════════════════════════
#  ARG PARSER
# ══════════════════════════════════════════════════════════════════════════════

def _parse_args(
    args: list[str],
) -> tuple[str, str, str, Optional[float], Optional[float]]:
    if not args:
        return "", "pick", "", None, None

    url = args[0]
    if not (url.startswith("http://") or url.startswith("https://") or url.startswith("www.")):
        url = ""

    rest = args[1:] if url else args
    mode    = "pick"
    quality = ""
    start   = None
    end     = None

    if not rest:
        return url, "pick", "", None, None

    kw = rest[0].lower()

    if kw in ("video", "vid", "v", "mp4"):
        mode    = "video"
        quality = rest[1] if len(rest) > 1 else "best"
    elif kw in ("audio", "aud", "a", "mp3", "music", "sound"):
        mode    = "audio"
        quality = rest[1] if len(rest) > 1 else "mp3"
    elif kw in ("clip", "cut", "trim", "segment"):
        mode = "clip"
        if len(rest) >= 3:
            start = _parse_time(rest[1])
            end   = _parse_time(rest[2])
        elif len(rest) == 2:
            m = re.match(r"(.+?)[-–—](.+)", rest[1])
            if m:
                start = _parse_time(m.group(1))
                end   = _parse_time(m.group(2))
    elif kw in ("info", "details", "meta", "i"):
        mode = "info"
    elif kw in ("subs", "subtitles", "sub", "captions", "cc"):
        mode    = "subs"
        quality = rest[1] if len(rest) > 1 else "en,auto"
    elif kw in ("thumb", "thumbnail", "cover", "poster"):
        mode = "thumb"
    elif kw in ("playlist", "pl", "list"):
        mode    = "playlist"
        start   = float(rest[1]) if len(rest) > 1 and rest[1].isdigit() else 1.0
        end     = float(rest[2]) if len(rest) > 2 and rest[2].isdigit() else 50.0
        quality = "best"
    elif kw in ("chapters", "chapter", "chap"):
        mode    = "chapters"
        quality = "best"
    elif re.match(r"^\d+p?$", kw):
        mode    = "video"
        quality = kw
    else:
        mode = "pick"

    return url, mode, quality, start, end


# ══════════════════════════════════════════════════════════════════════════════
#  HANDLER CLASS (mixin for SalimBot)
# ══════════════════════════════════════════════════════════════════════════════

class VideoDownloadHandlers:
    """Mixin — adds /yt /ytdl /dl /ytbatch /ytqueue /ytcancel"""

    @require_auth
    async def cmd_yt(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """
        /yt <url> [video|audio|clip|info|subs|thumb|playlist|chapters] [options]

        /yt https://youtu.be/abc               — picker
        /yt https://youtu.be/abc video 1080    — 1080p MP4
        /yt https://youtu.be/abc audio flac    — lossless FLAC
        /yt https://youtu.be/abc clip 1:30 3:00
        /yt https://youtu.be/abc playlist 1 20
        /yt https://instagram.com/p/abc video
        /yt https://twitter.com/i/status/123
        """
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "📥 <b>Salim Video Downloader v2</b>\n\n"
                "<b>Basic:</b>\n"
                "  <code>/yt &lt;url&gt;</code>                     — interactive picker\n"
                "  <code>/yt &lt;url&gt; video [720|1080|4k|best]</code>\n"
                "  <code>/yt &lt;url&gt; audio [mp3|m4a|flac|opus|wav]</code>\n\n"
                "<b>Advanced:</b>\n"
                "  <code>/yt &lt;url&gt; clip 1:30 2:45</code>      — extract clip\n"
                "  <code>/yt &lt;url&gt; playlist 1 20</code>       — playlist range\n"
                "  <code>/yt &lt;url&gt; chapters</code>            — split by chapters\n"
                "  <code>/yt &lt;url&gt; info</code>                — metadata only\n"
                "  <code>/yt &lt;url&gt; subs [en,ar,auto]</code>   — subtitles\n"
                "  <code>/yt &lt;url&gt; thumb</code>               — thumbnail\n\n"
                "  <code>/ytbatch &lt;url1&gt; &lt;url2&gt;…</code>  — batch queue\n"
                "  <code>/ytqueue</code>  •  <code>/ytcancel</code>\n\n"
                "🌍 <b>1000+ sites:</b> YouTube · Instagram · Twitter/X · TikTok"
                " · Facebook · Reddit · Twitch · Vimeo · SoundCloud · Bilibili + more\n\n"
                "🛡 <b>7 bypass layers</b> — geo-restriction, age-gate, bot-detection\n"
                "📦 <b>Any size</b> — large files split into parts automatically\n\n"
                "🍪 Cookies → <code>~/.salim/yt_cookies.txt</code>\n"
                "🌐 Proxy → <code>~/.salim/proxy.txt</code>",
                parse_mode=H,
            )
            return

        url, mode, quality, start_sec, end_sec = _parse_args(args)

        if not url:
            await msg.reply_text(
                "❌ No URL provided.\n<code>/yt &lt;url&gt; [options]</code>",
                parse_mode=H,
            )
            return

        if mode == "clip" and (start_sec is None or end_sec is None):
            await msg.reply_text(
                "❌ Invalid clip times.\n"
                "Example: <code>/yt &lt;url&gt; clip 1:30 2:45</code>",
                parse_mode=H,
            )
            return

        langs = quality if mode == "subs" else "en,auto"
        await do_download(url, mode, quality, start_sec, end_sec, update, ctx, langs)

    async def cmd_ytdl(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        await self.cmd_yt(update, ctx)

    @require_auth
    async def cmd_ytbatch(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/ytbatch <url1> <url2> … — queue multiple downloads"""
        msg  = update.effective_message
        args = ctx.args or []
        urls = [a for a in args if a.startswith("http")]

        if not urls:
            await msg.reply_text(
                "Usage: <code>/ytbatch &lt;url1&gt; &lt;url2&gt; …</code>",
                parse_mode=H,
            )
            return

        for url in urls:
            _enqueue(_QItem(url=url, mode="video", quality="best",
                            start_sec=None, end_sec=None,
                            update=update, ctx=ctx))

        await msg.reply_text(
            f"📋 <b>Queued {len(urls)} download(s)</b>\n\n"
            + "\n".join(f"• <code>{esc(u[:80])}</code>" for u in urls),
            parse_mode=H,
        )

    @require_auth
    async def cmd_ytqueue(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Show download queue."""
        msg = update.effective_message
        if not _dl_queue and not _current_dl:
            await msg.reply_text("📋 Queue is empty.", parse_mode=H)
            return
        lines = []
        if _current_dl:
            lines.append(f"⏳ <b>Downloading:</b>\n<code>{esc(_current_dl[:80])}</code>")
        if _dl_queue:
            lines.append(f"\n📋 <b>Queued ({len(_dl_queue)}):</b>")
            for i, item in enumerate(list(_dl_queue)[:10], 1):
                lines.append(f"  {i}. <code>{esc(item.url[:70])}</code>")
        await msg.reply_text("\n".join(lines), parse_mode=H)

    @require_auth
    async def cmd_ytcancel(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Cancel all queued downloads."""
        msg = update.effective_message
        n   = len(_dl_queue)
        _dl_queue.clear()
        await msg.reply_text(
            f"🛑 Cleared {n} queued download(s).\n"
            "<i>Active download will finish naturally.</i>",
            parse_mode=H,
        )

    async def handle_yt_callback(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """Handle inline keyboard from format picker."""
        query = update.callback_query
        data  = query.data or ""

        if data == "yt_cancel":
            try: await query.edit_message_text("❌ Cancelled.")
            except Exception: pass
            return

        if not data.startswith("yt_dl:"):
            return

        parts = data.split(":", 3)
        if len(parts) < 4:
            await query.edit_message_text("⚠️ Invalid callback.")
            return

        _, slot, mode, quality = parts
        session = _get_session(slot)
        if not session:
            await query.edit_message_text(
                "⚠️ Session expired — please send /yt again."
            )
            return

        url  = session["url"]
        info = session["info"]
        title = esc((info.get("title") or url)[:60]) if info else esc(url[:60])

        if mode == "clip_prompt":
            await query.edit_message_text(
                f"✂️ <b>Clip:</b> {title}\n\n"
                f"Send clip command:\n"
                f"<code>/yt {esc(url[:60])} clip 1:30 3:00</code>\n\n"
                f"<i>Time formats: 1:30, 1:30:00, 90s, 1m30s</i>",
                parse_mode=H,
            )
            return

        if mode == "info":
            await _render_info(info, query.message)
            return

        await query.edit_message_text(
            f"⏳ <b>Starting download…</b>\n📹 {title}", parse_mode=H
        )

        langs = quality if mode == "subs" else "en,auto"
        await do_download(url, mode, quality, None, None, update, ctx, langs=langs)
