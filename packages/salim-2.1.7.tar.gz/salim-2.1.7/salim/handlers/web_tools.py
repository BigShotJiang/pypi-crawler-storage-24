"""
Salim Web Tools — /wget /scrape /translate /weather /currency /ip /whois /ping /headers

New commands:
  /wget <url>            — download any file via URL and send to Telegram
  /scrape <url>          — extract clean text/links from a webpage
  /translate <text> [lang]  — translate text (auto-detect → target lang)
  /weather [city]        — current weather + 3-day forecast
  /currency <amount> <from> <to>  — live currency conversion
  /ip [address]          — IP geolocation (own IP if no arg)
  /whois <domain>        — domain WHOIS lookup
  /ping <host>           — ping a host and show latency
  /headers <url>         — show HTTP response headers
  /urlshort <url>        — shorten a URL (TinyURL)
  /pastebin <text>       — create a pastebin and share link
  /hash <text>           — MD5/SHA1/SHA256 hashes
"""
from __future__ import annotations

import asyncio
import hashlib
import html
import io
import json
import logging
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Optional

from telegram import Update
from telegram.ext import ContextTypes

from salim.auth import require_auth

logger = logging.getLogger("salim.web_tools")
esc = lambda v: html.escape(str(v), quote=False)
H = "HTML"

DOWNLOAD_DIR = Path.home() / "Downloads" / "Salim"
TG_FILE_LIMIT = 49 * 1024 * 1024

# ══════════════════════════════════════════════════════════════════════════════
#  AUTO-INSTALL
# ══════════════════════════════════════════════════════════════════════════════

def _pip(pkg: str) -> bool:
    try:
        r = subprocess.run(
            [sys.executable, "-m", "pip", "install", "--quiet",
             "--disable-pip-version-check", pkg],
            capture_output=True, timeout=120,
        )
        return r.returncode == 0
    except Exception:
        return False


def _can_import(name: str) -> bool:
    try:
        __import__(name)
        return True
    except ImportError:
        return False


def _ensure_deps():
    """Auto-install httpx, beautifulsoup4, deep_translator, python-whois."""
    for mod, pkg in [
        ("httpx",              "httpx[http2]>=0.25"),
        ("bs4",                "beautifulsoup4>=4.12"),
        ("deep_translator",    "deep-translator>=1.11"),
        ("whois",              "python-whois>=0.9"),
        ("lxml",               "lxml>=5.0"),
    ]:
        if not _can_import(mod):
            _pip(pkg)


# ══════════════════════════════════════════════════════════════════════════════
#  HELPERS
# ══════════════════════════════════════════════════════════════════════════════

def _human_size(n: int) -> str:
    if n < 1024:    return f"{n} B"
    if n < 2**20:   return f"{n/1024:.1f} KB"
    if n < 2**30:   return f"{n/2**20:.1f} MB"
    return f"{n/2**30:.2f} GB"


async def _http_get(url: str, headers: dict | None = None,
                    timeout: int = 20) -> tuple[int, bytes, dict]:
    """Async HTTP GET. Returns (status, body, headers)."""
    try:
        import httpx
        h = {"User-Agent": "Mozilla/5.0 (Salim-Bot/2.0)", **(headers or {})}
        async with httpx.AsyncClient(follow_redirects=True, timeout=timeout,
                                     verify=False) as client:
            r = await client.get(url, headers=h)
            return r.status_code, r.content, dict(r.headers)
    except ImportError:
        # Fallback: urllib
        req = urllib.request.Request(url, headers={"User-Agent": "Salim-Bot/2.0"})
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.status, resp.read(), dict(resp.headers)
        except Exception as e:
            return 0, b"", {}
    except Exception as e:
        return 0, b"", {}


# ══════════════════════════════════════════════════════════════════════════════
#  /wget — download any file from URL
# ══════════════════════════════════════════════════════════════════════════════

class WebToolsHandlers:
    """Mixin for SalimBot — web utilities"""

    @require_auth
    async def cmd_wget(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/wget <url> — download file from URL and send to Telegram"""
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "Usage: <code>/wget &lt;url&gt;</code>\n"
                "Downloads any file from URL and sends it here.",
                parse_mode=H,
            )
            return

        url = args[0]
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        status = await msg.reply_text(
            f"⬇️ <i>Downloading…</i>\n<code>{esc(url[:80])}</code>",
            parse_mode=H,
        )

        try:
            # Use aria2c if available for speed
            if shutil.which("aria2c"):
                DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
                fname = url.split("/")[-1].split("?")[0] or "download"
                dest  = DOWNLOAD_DIR / fname

                proc = await asyncio.create_subprocess_exec(
                    "aria2c", "--dir", str(DOWNLOAD_DIR), "--out", fname,
                    "--max-tries=3", "--timeout=30",
                    "--user-agent", "Mozilla/5.0 (Salim-Bot/2.0)",
                    "--console-log-level=warn", url,
                    stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
                )
                await asyncio.wait_for(proc.communicate(), timeout=300)

                if dest.exists() and dest.stat().st_size > 0:
                    await _send_wget_file(update, dest, status, url)
                    return

            # Fallback: httpx streaming download
            import httpx
            fname = url.split("/")[-1].split("?")[0] or "download"
            DOWNLOAD_DIR.mkdir(parents=True, exist_ok=True)
            dest  = DOWNLOAD_DIR / fname

            total = 0
            last_edit = 0.0
            with open(dest, "wb") as fh:
                async with httpx.AsyncClient(follow_redirects=True, timeout=300,
                                             verify=False) as client:
                    async with client.stream("GET", url,
                                             headers={"User-Agent": "Mozilla/5.0"}) as r:
                        clen = int(r.headers.get("content-length", 0))
                        async for chunk in r.aiter_bytes(65536):
                            fh.write(chunk)
                            total += len(chunk)
                            now = time.monotonic()
                            if now - last_edit > 3.0 and clen > 0:
                                last_edit = now
                                pct = total / clen * 100
                                try:
                                    await status.edit_text(
                                        f"⬇️ Downloading… {pct:.0f}%\n"
                                        f"({_human_size(total)} / {_human_size(clen)})",
                                        parse_mode=H,
                                    )
                                except Exception:
                                    pass

            if dest.exists() and dest.stat().st_size > 0:
                await _send_wget_file(update, dest, status, url)
            else:
                await status.edit_text("❌ Download failed — empty file.", parse_mode=H)

        except Exception as e:
            await status.edit_text(
                f"❌ Download failed: <code>{esc(str(e)[:200])}</code>",
                parse_mode=H,
            )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_scrape(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/scrape <url> — extract clean text and links from webpage"""
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "Usage: <code>/scrape &lt;url&gt;</code>",
                parse_mode=H,
            )
            return

        _ensure_deps()
        url = args[0]
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        status = await msg.reply_text(
            f"🕷 <i>Scraping…</i>\n<code>{esc(url[:80])}</code>",
            parse_mode=H,
        )

        code, body, hdrs = await _http_get(url, timeout=20)
        if code == 0 or not body:
            await status.edit_text(
                f"❌ Could not fetch page (HTTP {code}).", parse_mode=H
            )
            return

        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(body, "lxml")

            # Remove clutter
            for tag in soup(["script", "style", "nav", "footer",
                              "header", "aside", "iframe", "noscript"]):
                tag.decompose()

            # Title
            title = soup.title.string.strip() if soup.title else "No title"

            # Meta description
            meta = soup.find("meta", attrs={"name": re.compile("description", re.I)})
            desc = meta.get("content", "")[:300] if meta else ""

            # Clean body text
            text = re.sub(r"\s+", " ", soup.get_text(separator=" ")).strip()[:3000]

            # Links (unique, absolute)
            base = "/".join(url.split("/")[:3])
            links = []
            for a in soup.find_all("a", href=True)[:20]:
                href = a["href"].strip()
                if href.startswith("http"):
                    links.append(href[:100])
                elif href.startswith("/"):
                    links.append(base + href[:80])

            reply = (
                f"🕷 <b>{esc(title[:80])}</b>\n"
                f"🔗 <code>{esc(url[:80])}</code>\n"
                f"📊 HTTP {code}\n\n"
            )
            if desc:
                reply += f"📋 <i>{esc(desc)}</i>\n\n"
            reply += f"📄 <b>Content preview:</b>\n{esc(text[:1500])}…\n\n"
            if links:
                reply += f"🔗 <b>Links ({len(links)}):</b>\n"
                reply += "\n".join(f"• <code>{esc(l)}</code>" for l in links[:10])

            await status.edit_text(reply[:4000], parse_mode=H,
                                   disable_web_page_preview=True)

        except Exception as e:
            # Fallback: plain text
            text = body.decode("utf-8", errors="replace")
            text = re.sub(r"<[^>]+>", " ", text)
            text = re.sub(r"\s+", " ", text).strip()[:2000]
            await status.edit_text(
                f"🔗 <code>{esc(url[:80])}</code>\n\n{esc(text[:3000])}",
                parse_mode=H,
            )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_translate(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/translate <text> [target_lang] — translate text"""
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "Usage: <code>/translate &lt;text&gt; [lang]</code>\n"
                "Default target: English\n"
                "Examples:\n"
                "  <code>/translate Bonjour le monde</code>\n"
                "  <code>/translate Hello world ar</code>\n"
                "  <code>/translate مرحبا en</code>",
                parse_mode=H,
            )
            return

        _ensure_deps()

        # Last arg might be a language code
        LANG_CODES = {
            "en", "ar", "fr", "de", "es", "it", "pt", "ru", "zh", "ja", "ko",
            "tr", "nl", "pl", "sv", "fi", "no", "da", "hi", "id", "ms", "th",
            "vi", "uk", "cs", "ro", "hu", "bg", "hr", "sk", "sl", "el", "he",
        }
        target = "en"
        text   = " ".join(args)

        if args and args[-1].lower() in LANG_CODES:
            target = args[-1].lower()
            text   = " ".join(args[:-1])

        if not text.strip():
            await msg.reply_text("❌ No text to translate.", parse_mode=H)
            return

        status = await msg.reply_text("🌐 <i>Translating…</i>", parse_mode=H)

        try:
            from deep_translator import GoogleTranslator
            translator = GoogleTranslator(source="auto", target=target)
            result = translator.translate(text)
            flag_map = {
                "en": "🇬🇧", "ar": "🇸🇦", "fr": "🇫🇷", "de": "🇩🇪",
                "es": "🇪🇸", "it": "🇮🇹", "pt": "🇧🇷", "ru": "🇷🇺",
                "zh": "🇨🇳", "ja": "🇯🇵", "ko": "🇰🇷", "tr": "🇹🇷",
                "hi": "🇮🇳", "nl": "🇳🇱",
            }
            flag = flag_map.get(target, "🌐")
            await status.edit_text(
                f"🌐 <b>Translation</b> → {flag} {target.upper()}\n\n"
                f"<b>Original:</b> {esc(text[:500])}\n\n"
                f"<b>Translated:</b> {esc(result[:1000])}",
                parse_mode=H,
            )
        except Exception as e:
            # Fallback: MyMemory free API
            try:
                encoded = urllib.parse.quote(text[:500])
                api_url = f"https://api.mymemory.translated.net/get?q={encoded}&langpair=auto|{target}"
                code, body, _ = await _http_get(api_url)
                data = json.loads(body)
                translated = data["responseData"]["translatedText"]
                await status.edit_text(
                    f"🌐 <b>Translation</b> → {target.upper()}\n\n"
                    f"<b>Original:</b> {esc(text[:500])}\n\n"
                    f"<b>Translated:</b> {esc(translated[:1000])}",
                    parse_mode=H,
                )
            except Exception as e2:
                await status.edit_text(
                    f"❌ Translation failed: {esc(str(e2)[:200])}",
                    parse_mode=H,
                )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_weather(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/weather [city] — current weather + forecast"""
        msg  = update.effective_message
        args = ctx.args or []
        city = " ".join(args) if args else "auto"

        status = await msg.reply_text(
            f"🌤 <i>Fetching weather{' for ' + esc(city) if city != 'auto' else ''}…</i>",
            parse_mode=H,
        )

        try:
            # wttr.in: free, no API key, JSON output
            if city == "auto":
                location = ""
            else:
                location = urllib.parse.quote(city)

            url  = f"https://wttr.in/{location}?format=j1"
            code, body, _ = await _http_get(url, timeout=15)
            if code != 200 or not body:
                raise ValueError(f"HTTP {code}")

            data = json.loads(body)
            curr = data["current_condition"][0]
            loc  = data["nearest_area"][0]
            area = loc["areaName"][0]["value"]
            country = loc["country"][0]["value"]

            temp_c  = curr["temp_C"]
            temp_f  = curr["temp_F"]
            feels_c = curr["FeelsLikeC"]
            humidity = curr["humidity"]
            wind_kmh = curr["windspeedKmph"]
            wind_dir = curr["winddir16Point"]
            desc    = curr["weatherDesc"][0]["value"]
            uv      = curr.get("uvIndex", "?")
            vis     = curr.get("visibility", "?")

            # Weather icon map
            ICONS = {
                "Sunny": "☀️", "Clear": "🌙", "Partly cloudy": "⛅",
                "Cloudy": "☁️", "Overcast": "☁️", "Mist": "🌫",
                "Rain": "🌧", "Snow": "❄️", "Thunder": "⛈",
                "Fog": "🌫", "Blizzard": "❄️", "Sleet": "🌨",
            }
            icon = next((v for k, v in ICONS.items() if k.lower() in desc.lower()), "🌡")

            # 3-day forecast
            forecast_lines = []
            for day in data["weather"][:3]:
                date = day["date"]
                max_c = day["maxtempC"]
                min_c = day["mintempC"]
                day_desc = day["hourly"][4]["weatherDesc"][0]["value"][:20]
                forecast_lines.append(
                    f"  {date}: {day_desc} {min_c}°→{max_c}°C"
                )

            reply = (
                f"{icon} <b>Weather in {esc(area)}, {esc(country)}</b>\n\n"
                f"🌡 <b>{temp_c}°C / {temp_f}°F</b> — {esc(desc)}\n"
                f"🤔 Feels like: {feels_c}°C\n"
                f"💧 Humidity: {humidity}%\n"
                f"🌬 Wind: {wind_kmh} km/h {wind_dir}\n"
                f"☀️ UV Index: {uv}   👁 Visibility: {vis} km\n\n"
                f"📅 <b>3-Day Forecast:</b>\n"
                + "\n".join(forecast_lines)
            )
            await status.edit_text(reply, parse_mode=H)

        except Exception as e:
            await status.edit_text(
                f"❌ Weather lookup failed: {esc(str(e)[:200])}\n\n"
                f"<i>Try: /weather London</i>",
                parse_mode=H,
            )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_currency(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/currency <amount> <from> <to> — live exchange rate"""
        msg  = update.effective_message
        args = ctx.args or []

        if len(args) < 3:
            await msg.reply_text(
                "Usage: <code>/currency &lt;amount&gt; &lt;FROM&gt; &lt;TO&gt;</code>\n"
                "Example: <code>/currency 100 USD EUR</code>",
                parse_mode=H,
            )
            return

        try:
            amount = float(args[0].replace(",", ""))
            frm    = args[1].upper()
            to     = args[2].upper()
        except ValueError:
            await msg.reply_text(
                "❌ Invalid amount. Example: <code>/currency 100 USD EUR</code>",
                parse_mode=H,
            )
            return

        status = await msg.reply_text(
            f"💱 <i>Converting {amount} {frm} → {to}…</i>", parse_mode=H
        )

        try:
            # Frankfurter API: free, no key needed
            url = f"https://api.frankfurter.app/latest?from={frm}&to={to}"
            code, body, _ = await _http_get(url, timeout=10)
            data = json.loads(body)

            if "rates" not in data or to not in data["rates"]:
                raise ValueError("Currency not found")

            rate   = data["rates"][to]
            result = amount * rate
            date   = data.get("date", "today")

            await status.edit_text(
                f"💱 <b>Currency Conversion</b>\n\n"
                f"<b>{amount:,.2f} {frm}</b> = <b>{result:,.4f} {to}</b>\n\n"
                f"📊 Rate: 1 {frm} = {rate:.6f} {to}\n"
                f"📅 Date: {date}\n\n"
                f"<i>Source: Frankfurter / ECB</i>",
                parse_mode=H,
            )
        except Exception as e:
            await status.edit_text(
                f"❌ Conversion failed: {esc(str(e)[:200])}",
                parse_mode=H,
            )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_ip(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/ip [address] — IP geolocation (own IP if blank)"""
        msg  = update.effective_message
        args = ctx.args or []
        ip   = args[0] if args else ""

        status = await msg.reply_text("🌐 <i>Looking up IP…</i>", parse_mode=H)

        try:
            url  = f"https://ipwho.is/{ip}"
            code, body, _ = await _http_get(url, timeout=10)
            data = json.loads(body)

            if not data.get("success"):
                raise ValueError(data.get("message", "Lookup failed"))

            flag = data.get("flag", {}).get("emoji", "")
            lines = [
                f"🌐 <b>IP Lookup: {esc(data.get('ip', ip))}</b>",
                f"{flag} {esc(data.get('country', ''))} / {esc(data.get('region', ''))} / {esc(data.get('city', ''))}",
                f"🏢 ISP: {esc(data.get('connection', {}).get('isp', 'Unknown'))}",
                f"🌍 Coords: {data.get('latitude', '?')}, {data.get('longitude', '?')}",
                f"🕐 Timezone: {esc(data.get('timezone', {}).get('id', '?'))}",
                f"📮 Postal: {esc(data.get('postal', '?'))}",
            ]
            if data.get("type"):
                lines.append(f"🔌 Type: {esc(data['type'])}")

            await status.edit_text("\n".join(lines), parse_mode=H)

        except Exception as e:
            await status.edit_text(
                f"❌ IP lookup failed: {esc(str(e)[:200])}", parse_mode=H
            )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_whois(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/whois <domain> — domain WHOIS lookup"""
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "Usage: <code>/whois &lt;domain&gt;</code>\n"
                "Example: <code>/whois google.com</code>",
                parse_mode=H,
            )
            return

        domain = args[0].lower().strip()
        status = await msg.reply_text(
            f"🔍 <i>WHOIS for {esc(domain)}…</i>", parse_mode=H
        )

        try:
            _ensure_deps()
            import whois as pywhois
            w = await asyncio.get_event_loop().run_in_executor(
                None, lambda: pywhois.whois(domain)
            )

            def _fmt(v):
                if isinstance(v, list):
                    v = v[0]
                if hasattr(v, "strftime"):
                    return v.strftime("%Y-%m-%d")
                return str(v) if v else "?"

            lines = [f"🌐 <b>WHOIS: {esc(domain)}</b>\n"]
            if w.registrar:
                lines.append(f"🏢 Registrar: {esc(str(w.registrar)[:80])}")
            if w.creation_date:
                lines.append(f"📅 Created: {_fmt(w.creation_date)}")
            if w.expiration_date:
                lines.append(f"⏰ Expires: {_fmt(w.expiration_date)}")
            if w.updated_date:
                lines.append(f"🔄 Updated: {_fmt(w.updated_date)}")
            if w.name_servers:
                ns = w.name_servers if isinstance(w.name_servers, list) else [w.name_servers]
                lines.append(f"🖥 Name servers: {', '.join(str(s).lower() for s in ns[:4])}")
            if w.status:
                st = w.status if isinstance(w.status, list) else [w.status]
                lines.append(f"✅ Status: {', '.join(str(s).split()[0] for s in st[:3])}")
            if w.country:
                lines.append(f"🌍 Country: {esc(str(w.country))}")
            if w.emails:
                em = w.emails if isinstance(w.emails, list) else [w.emails]
                lines.append(f"📧 Contact: {esc(str(em[0])[:60])}")

            await status.edit_text("\n".join(lines), parse_mode=H)

        except Exception as e:
            # Fallback: rdap.org
            try:
                url  = f"https://rdap.org/domain/{domain}"
                code, body, _ = await _http_get(url, timeout=15)
                data = json.loads(body)

                lines = [f"🌐 <b>WHOIS (RDAP): {esc(domain)}</b>\n"]
                for ev in data.get("events", []):
                    etype = ev.get("eventAction", "")
                    edate = ev.get("eventDate", "")[:10]
                    if etype == "registration":
                        lines.append(f"📅 Created: {edate}")
                    elif etype == "expiration":
                        lines.append(f"⏰ Expires: {edate}")
                for ns_obj in data.get("nameservers", [])[:4]:
                    lines.append(f"🖥 NS: {esc(ns_obj.get('ldhName', ''))}")
                for ent in data.get("entities", [])[:2]:
                    vcard = ent.get("vcardArray", [])
                    if vcard and len(vcard) > 1:
                        for field in vcard[1]:
                            if field[0] == "fn":
                                lines.append(f"🏢 {esc(field[3][:80])}")

                await status.edit_text("\n".join(lines), parse_mode=H)
            except Exception as e2:
                await status.edit_text(
                    f"❌ WHOIS failed: {esc(str(e2)[:200])}", parse_mode=H
                )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_ping(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/ping <host> — ping a host"""
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "Usage: <code>/ping &lt;host&gt;</code>\n"
                "Example: <code>/ping google.com</code>",
                parse_mode=H,
            )
            return

        host   = args[0]
        count  = int(args[1]) if len(args) > 1 and args[1].isdigit() else 4
        count  = min(count, 10)  # max 10 pings

        status = await msg.reply_text(
            f"🏓 <i>Pinging {esc(host)} × {count}…</i>", parse_mode=H
        )

        try:
            import platform
            flag = "-n" if platform.system().lower() == "windows" else "-c"
            proc = await asyncio.create_subprocess_exec(
                "ping", flag, str(count), "-W", "5", host,
                stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=60)
            output = stdout.decode("utf-8", errors="replace")

            # Parse results
            times = re.findall(r"time[=<]([\d.]+)\s*ms", output)
            loss  = re.search(r"([\d]+)% packet loss", output)
            stats = re.search(r"min/avg/max[^=]*= ([\d.]+)/([\d.]+)/([\d.]+)", output)

            reply = f"🏓 <b>Ping: {esc(host)}</b>\n\n"
            if times:
                reply += f"⏱ Times: {', '.join(times[:count])} ms\n"
            if stats:
                reply += f"📊 Min: {stats.group(1)}ms  Avg: {stats.group(2)}ms  Max: {stats.group(3)}ms\n"
            if loss:
                pct = int(loss.group(1))
                icon = "✅" if pct == 0 else "⚠️" if pct < 50 else "❌"
                reply += f"{icon} Packet loss: {pct}%\n"
            reply += f"\n<pre>{esc(output[-600:])}</pre>"
            await status.edit_text(reply[:4000], parse_mode=H)

        except asyncio.TimeoutError:
            await status.edit_text(f"⏰ Ping timed out for {esc(host)}", parse_mode=H)
        except Exception as e:
            # Fallback: pure Python TCP ping
            try:
                t0   = time.monotonic()
                sock = socket.create_connection((host, 80), timeout=5)
                sock.close()
                ms   = (time.monotonic() - t0) * 1000
                await status.edit_text(
                    f"🏓 <b>TCP ping: {esc(host)}</b>\n\n"
                    f"✅ Reachable: {ms:.1f} ms (TCP:80)",
                    parse_mode=H,
                )
            except Exception as e2:
                await status.edit_text(
                    f"❌ {esc(host)} unreachable: {esc(str(e2)[:200])}",
                    parse_mode=H,
                )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_headers(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/headers <url> — show HTTP response headers"""
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "Usage: <code>/headers &lt;url&gt;</code>",
                parse_mode=H,
            )
            return

        url = args[0]
        if not url.startswith(("http://", "https://")):
            url = "https://" + url

        status = await msg.reply_text(
            f"📋 <i>Fetching headers…</i>\n<code>{esc(url[:80])}</code>",
            parse_mode=H,
        )

        try:
            code, _, hdrs = await _http_get(url, timeout=15)
            lines = [
                f"📋 <b>HTTP Headers: {esc(url[:60])}</b>\n",
                f"Status: <b>{code}</b>\n",
            ]
            for k, v in list(hdrs.items())[:25]:
                lines.append(f"<code>{esc(k)}: {esc(str(v)[:120])}</code>")
            await status.edit_text("\n".join(lines)[:4000], parse_mode=H)
        except Exception as e:
            await status.edit_text(
                f"❌ Failed: {esc(str(e)[:200])}", parse_mode=H
            )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_urlshort(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/urlshort <url> — shorten URL via TinyURL"""
        msg  = update.effective_message
        args = ctx.args or []

        if not args:
            await msg.reply_text(
                "Usage: <code>/urlshort &lt;url&gt;</code>",
                parse_mode=H,
            )
            return

        url    = args[0]
        status = await msg.reply_text("🔗 <i>Shortening URL…</i>", parse_mode=H)

        try:
            encoded = urllib.parse.quote(url, safe="")
            api     = f"https://tinyurl.com/api-create.php?url={encoded}"
            code, body, _ = await _http_get(api, timeout=10)
            short = body.decode("utf-8", errors="replace").strip()

            if short.startswith("https://tinyurl.com"):
                await status.edit_text(
                    f"🔗 <b>Short URL</b>\n\n"
                    f"Original: <code>{esc(url[:100])}</code>\n"
                    f"Short: <code>{esc(short)}</code>",
                    parse_mode=H,
                )
            else:
                raise ValueError("Unexpected response")
        except Exception as e:
            await status.edit_text(
                f"❌ URL shortening failed: {esc(str(e)[:200])}",
                parse_mode=H,
            )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_pastebin(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/pastebin <text> — create a pastebin (dpaste.com, free)"""
        msg  = update.effective_message
        args = ctx.args or []

        # Also handle reply
        text = " ".join(args)
        if not text and update.effective_message.reply_to_message:
            text = update.effective_message.reply_to_message.text or ""

        if not text:
            await msg.reply_text(
                "Usage: <code>/pastebin &lt;text&gt;</code>\n"
                "Or reply to a message with <code>/pastebin</code>",
                parse_mode=H,
            )
            return

        status = await msg.reply_text("📋 <i>Creating paste…</i>", parse_mode=H)

        try:
            # dpaste.com: free, no auth
            import urllib.request as _ur
            data = urllib.parse.urlencode({
                "content": text[:50000],
                "syntax":  "text",
                "expiry_days": "30",
            }).encode()
            req  = _ur.Request(
                "https://dpaste.com/api/v2/",
                data=data,
                headers={"User-Agent": "Salim-Bot/2.0", "Accept": "text/plain"},
                method="POST",
            )
            with _ur.urlopen(req, timeout=15) as resp:
                url = resp.read().decode().strip()

            await status.edit_text(
                f"📋 <b>Paste created</b>\n\n"
                f"🔗 <code>{esc(url)}</code>\n\n"
                f"<i>Expires in 30 days</i>",
                parse_mode=H,
            )
        except Exception as e:
            await status.edit_text(
                f"❌ Pastebin failed: {esc(str(e)[:200])}",
                parse_mode=H,
            )

    # ─────────────────────────────────────────────────────────────────────
    @require_auth
    async def cmd_hash(self, update: Update, ctx: ContextTypes.DEFAULT_TYPE):
        """/hash <text> — compute MD5, SHA1, SHA256, SHA512"""
        msg  = update.effective_message
        args = ctx.args or []

        text = " ".join(args)
        if not text and update.effective_message.reply_to_message:
            text = update.effective_message.reply_to_message.text or ""

        if not text:
            await msg.reply_text(
                "Usage: <code>/hash &lt;text&gt;</code>",
                parse_mode=H,
            )
            return

        data = text.encode("utf-8")
        await msg.reply_text(
            f"🔐 <b>Hash: </b><code>{esc(text[:60])}{'…' if len(text) > 60 else ''}</code>\n\n"
            f"MD5:    <code>{hashlib.md5(data).hexdigest()}</code>\n"
            f"SHA1:   <code>{hashlib.sha1(data).hexdigest()}</code>\n"
            f"SHA256: <code>{hashlib.sha256(data).hexdigest()}</code>\n"
            f"SHA512: <code>{hashlib.sha512(data).hexdigest()}</code>",
            parse_mode=H,
        )


# ══════════════════════════════════════════════════════════════════════════════
#  SEND WGET FILE HELPER
# ══════════════════════════════════════════════════════════════════════════════

async def _send_wget_file(update: Update, filepath: Path, status_msg, url: str):
    msg  = update.effective_message
    size = filepath.stat().st_size
    sz   = _human_size(size)

    try:
        await status_msg.edit_text(
            f"📤 <b>Uploading</b> {esc(filepath.name[:60])} ({sz})…",
            parse_mode=H,
        )
    except Exception:
        pass

    caption = (
        f"📥 <b>{esc(filepath.name[:80])}</b>\n"
        f"💾 {sz}\n"
        f"🔗 <code>{esc(url[:100])}</code>"
    )

    if size <= TG_FILE_LIMIT:
        try:
            await msg.reply_document(
                document=io.BytesIO(filepath.read_bytes()),
                filename=filepath.name,
                caption=caption,
                parse_mode=H,
                read_timeout=300, write_timeout=300, connect_timeout=30,
            )
            try: await status_msg.delete()
            except Exception: pass
            return
        except Exception as e:
            logger.warning(f"Telegram upload failed: {e}")

    # Large file → report local path
    await status_msg.edit_text(
        f"💾 <b>Saved locally</b> ({sz})\n\n"
        f"<code>{esc(str(filepath))}</code>\n\n"
        f"{caption}",
        parse_mode=H,
    )
