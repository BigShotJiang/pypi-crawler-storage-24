<a name="readme-top"></a>

<p align="right">
  <a href="./README.md"><b>English</b></a> | <a href="./README_zh.md">中文</a>
</p>

<div align="center">

# CoWorker Protocol

**Peer-to-peer AI agent collaboration over XMTP**

<br/>

<a href="https://pypi.org/project/agent-coworker/"><img src="https://img.shields.io/pypi/v/agent-coworker?style=for-the-badge&color=000000" alt="PyPI"></a>
&nbsp;
<a href="https://www.python.org/downloads/"><img src="https://img.shields.io/badge/python-3.10+-000000?style=for-the-badge" alt="Python 3.10+"></a>
&nbsp;
<img src="https://img.shields.io/badge/deps-zero-000000?style=for-the-badge" alt="Zero deps">
&nbsp;
<a href="./LICENSE"><img src="https://img.shields.io/badge/license-MIT-000000?style=for-the-badge" alt="MIT"></a>

<br/><br/>

MCP connects agents to tools. A2A connects agents in enterprises.<br/>
**CoWorker connects agents across the open internet** — peer-to-peer, E2E encrypted, zero cost.

<hr/>
</div>

## Who is this for?

You already have an agent — Claude Code, Cursor, a custom bot, a CrewAI pipeline. Now you want to **collaborate with someone else's agent** to get something done together. But:

- You don't know how to **decompose the goal** across two agents
- You can't **see what's happening** during the collaboration
- You don't want to **expose your prompts, code, or data** to do it
- You don't have a **shared server** and don't want to set one up

**CoWorker handles all of this.** Any Python agent becomes a collaboration node in one line. Goals auto-decompose. A dashboard shows everything. Skills stay private. No server needed.

## Why CoWorker?

Existing agent protocols force you into a single process, a shared network, or a central broker. CoWorker is different — **three design choices** set it apart:

### 1. Group Trust Collaboration

Multiple humans and AI agents work together in one encrypted group — with trust tiers visible to everyone.

```python
# Create a group with humans and bots
group = agent.create_group(
    name="Research Sprint",
    members=["alice_invite_code", "bob_invite_code"]
)

# Everyone sees all messages — trust badges show each member's tier
group.send("Let's start the research on quantum computing")
```

The built-in dashboard shows the full interaction: who said what, which skills were called, each member's trust level — all in one view.

<table>
  <tr>
    <td><img src="./docs/assets/screenshot-chat.png" alt="Group chat with trust badges" width="400" /></td>
    <td><img src="./docs/assets/screenshot-team.png" alt="Trust tier management" width="400" /></td>
  </tr>
  <tr>
    <td align="center"><sub>Group chat — humans + bots, trust badges visible</sub></td>
    <td align="center"><sub>Per-peer trust tier management</sub></td>
  </tr>
</table>

### 2. Skill-as-API with Auto Trust Downgrade

Share what your agent can **do**, not **how** it does it. Peers only see input/output schema — never your code, prompts, or logic.

```python
@agent.skill("translate",
             description="Translate text between languages",
             input_schema={"text": "str", "to_lang": "str"},
             output_schema={"translated": "str"},
             min_trust_tier=1)  # Only KNOWN+ peers can see this skill
def translate(text: str, to_lang: str) -> dict:
    # Your proprietary implementation stays private
    # Peers only know: "translate" takes text+lang, returns translated text
    return {"translated": do_translate(text, to_lang)}
```

**Trust is temporary by design.** When a collaboration goal (OKR) completes, the peer's trust automatically steps down:

```
Before collaboration:  PRIVILEGED (3) — full skill access
OKR completed:         → INTERNAL (2) — auto-downgraded
Next OKR completed:    → KNOWN (1)    — further downgraded
```

**Skill Visibility Control:** You choose which skills to expose. Hidden skills are invisible to peers — they can't even tell they exist.

```bash
coworker skills configure          # interactive toggle
coworker skills expose translate   # expose one skill
coworker skills hide admin         # hide one skill
coworker skills preview --peer-tier known  # preview what peers see
```

### 3. Peer-to-Peer, No Server, Zero Cost

There is no CoWorker server. Each agent runs independently. Communication happens directly over XMTP — E2E encrypted, NAT-traversing, works across any network.

```
Your machine                          Collaborator's machine
┌──────────────────┐                 ┌──────────────────┐
│  Python Agent    │                 │  Python Agent    │
│  + Dashboard     │                 │  + Dashboard     │
│  + XMTP Bridge   │                 │  + XMTP Bridge   │
└────────┬─────────┘                 └────────┬─────────┘
         │                                     │
         └─────── XMTP Network ───────────────┘
              E2E encrypted, NAT traversal
              No central server, no API keys
              No cost, no rate limits
```

- **No registration** — `pip install` and go
- **No API keys** — cryptographic identity, keys never leave your machine
- **No server costs** — run on your laptop, your Raspberry Pi, anywhere
- **No port forwarding** — XMTP handles NAT traversal
- **Privacy by default** — invite codes contain no sensitive addresses

---

## Quick Start

```bash
pip install agent-coworker
coworker init --name my-agent    # generates identity + installs XMTP bridge
coworker bridge start            # connect to XMTP network
coworker demo                    # connect to our demo bot & test skills
```

<details>
<summary>China mainland</summary>

```bash
pip install agent-coworker -i https://pypi.tuna.tsinghua.edu.cn/simple
```
</details>

### Try the Demo Bot

The fastest way to experience CoWorker — connect to `icy`, our always-online demo bot:

```bash
coworker demo

# → Discovers icy's skills: about, translate, search, ping
# → Calls icy.about('general') — E2E encrypted
# → Calls icy.translate('Hello world', to_lang='zh')
# → Calls icy.search('coworker protocol')
# → All without seeing icy's source code!
```

### Create an Agent with Skills

```python
from agent_coworker import Agent

agent = Agent("my-bot")

@agent.skill("summarize", description="Summarize text",
             input_schema={"text": "str"},
             output_schema={"summary": "str"})
def summarize(text: str) -> dict:
    return {"summary": text[:200]}

agent.serve()  # XMTP listener + dashboard on :8090
```

### Share Your Invite Code

```bash
coworker invite
#   Agent:  my-bot
#
#   Invite code:  eyJuIjoibXktYm90Ii...
#   Short ID:     my-bot-b36cd7f6
#
#   Your collaborator runs:
#     coworker connect eyJuIjoibXktYm90Ii...
```

Invite codes are privacy-preserving — they contain only your agent name and an XMTP routing ID. No sensitive addresses exposed.

### Connect and Collaborate

```python
agent2 = Agent("caller")

# Connect using invite code
peer = agent2.connect("eyJuIjoibXktYm90Ii...")
print(peer["skills"])  # Only shows skills you're trusted to see

# Call a remote skill — E2E encrypted
result = agent2.call("eyJuIjoibXktYm90Ii...", "summarize", {"text": "Hello!"})

# Or set a goal and let agents coordinate
agent2.collaborate("eyJuIjoibXktYm90Ii...", "Research AI agents and write a report")
# → discovers skills, builds OKR, executes steps, auto-downgrades trust when done
```

---

## Monitor Dashboard

`agent.serve()` launches a React dashboard at `http://localhost:8090`.

<table>
  <tr>
    <td><img src="./docs/assets/screenshot-home.png" alt="Activity feed" width="400" /></td>
    <td><img src="./docs/assets/screenshot-goals.png" alt="OKR tracking" width="400" /></td>
  </tr>
  <tr>
    <td align="center"><sub>Live activity feed & real-time stats</sub></td>
    <td align="center"><sub>Cross-network OKR tracking</sub></td>
  </tr>
</table>

Activity feed, team/peer management, OKR tracking, workflow insights, group chat, skill visibility toggle, metering & receipts. Auto-detects browser language (Chinese / English).

## Comparison

| | CoWorker | MCP | A2A | CrewAI / AutoGen |
|---|---|---|---|---|
| **Connects** | Agent ↔ Agent | Agent ↔ Tool | Agent ↔ Agent | Agent ↔ Agent |
| **Network** | Open internet | Local | Enterprise HTTP | Single process |
| **Encryption** | E2E (XMTP MLS) | Transport-only | Enterprise TLS | None |
| **NAT traversal** | Yes | No | Infra-dependent | No |
| **Central server** | None | MCP server | Discovery service | Runtime host |
| **Skill privacy** | Input/output only | Full exposure | Schema-based | Full exposure |
| **Skill visibility** | Owner-controlled toggle | None | None | None |
| **Trust management** | 4-tier + auto-downgrade | None | Enterprise IAM | None |
| **Cost** | Zero | Server costs | Infra costs | Compute costs |
| **Dependencies** | Zero (stdlib) | Varies | HTTP stack | Heavy |

## Privacy & Trust

```
UNTRUSTED (0)  → Can ping, sees NO skills
KNOWN (1)      → Can see/call exposed skills, propose plans
INTERNAL (2)   → Context queries, deep collaboration
PRIVILEGED (3) → Full access — must be granted manually

Default: UNTRUSTED (deny by default)
After OKR: auto-downgrade (PRIVILEGED → INTERNAL → KNOWN)
Transport: E2E encrypted (XMTP MLS, forward secrecy)
Identity: cryptographic, locally generated, never transmitted
Invite codes: contain routing ID only, no sensitive addresses
```

## CLI

```bash
coworker init --name my-agent    # generate identity + install bridge
coworker bridge start            # start XMTP bridge
coworker bridge stop             # stop bridge
coworker demo                    # connect to demo bot & test skills
coworker invite                  # generate privacy-preserving invite code
coworker connect <invite-code>   # connect to a peer
coworker status                  # show agent status
coworker skills list             # show skill visibility
coworker skills configure        # toggle which skills peers can see
coworker trust list              # show trust overrides
coworker trust set <peer> known  # grant trust
```

## Examples

```
examples/
├── 01_minimal.py           # Bare-bones agent
├── 02_collaboration.py     # In-process collaboration
├── 03_discover_skills.py   # Discover a peer's skills
├── 04_remote_skill_call.py # Call a remote skill
├── 05_collaborate.py       # Goal-based collaboration
├── 06_serve_with_dashboard.py  # Agent with monitoring dashboard
├── 07_nanobot_adapter.py   # Bridge Nanobot skills
├── 08_openclaw_adapter.py  # Bridge OpenClaw skills
└── icy_demo_bot.py         # Demo bot source code
```

## Cross-Network Proof

Tested between two independent agents on different continents:

| Agent | Location | Network |
|-------|----------|---------|
| ziway | Beijing, China | China Telecom |
| icy | San Francisco, USA | Alibaba Cloud |

**discover, about, translate, search** — all skills called successfully via XMTP E2E encrypted messaging. No IP addresses, no port forwarding, no shared server.

## Roadmap

- [x] Skill Visibility Control — owner chooses which skills to expose
- [x] Privacy-preserving invite codes — no addresses in invite codes
- [x] Demo bot — `coworker demo` for instant onboarding
- [ ] MCP bridge — expose CoWorker skills as MCP tools
- [ ] TypeScript SDK
- [ ] On-chain agent registry (ERC-8004)
- [ ] Gossip-based peer discovery
- [ ] XMTP production network

## Contributing

See [CONTRIBUTING.md](./CONTRIBUTING.md).

## Citation

```bibtex
@software{coworker_protocol,
  title  = {CoWorker Protocol: Peer-to-Peer Agent Collaboration over XMTP},
  author = {Zhao, Ziway and Liu, Dantong and Ding, Xizhi},
  year   = {2026},
  url    = {https://github.com/ZiwayZhao/agent-coworker}
}
```

## License

[MIT](./LICENSE)

---

<p align="center">
  <sub>Built with <a href="https://xmtp.org">XMTP</a> for the open agent internet.</sub>
  <br/>
  <a href="#readme-top">Back to top ↑</a>
</p>
