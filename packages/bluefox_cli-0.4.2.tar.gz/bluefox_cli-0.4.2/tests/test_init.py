"""Tests for the bfx init command."""

import os

from typer.testing import CliRunner

from bluefox_cli.main import cli


def _invoke_init(runner, tmp_path, project_name="myapp"):
    """Run bfx init with non-interactive flags."""
    os.chdir(tmp_path)
    return runner.invoke(
        cli,
        ["init", project_name, "--name", project_name, "--port", "8000", "--data", "--redis"],
    )


def test_init_creates_project(tmp_path):
    runner = CliRunner()
    _invoke_init(runner, tmp_path)
    assert (tmp_path / "myapp").exists()


def test_init_creates_all_expected_files(tmp_path):
    """Verify core files are generated."""
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    project_dir = tmp_path / "myapp"
    expected = [
        "bluefox.yml",
        "Dockerfile",
        "pyproject.toml",
        "app/__init__.py",
        "app/config.py",
        "app/database.py",
        "app/health/router.py",
        "alembic.ini",
        "migrations/env.py",
        ".gitignore",
        ".bluefox",
    ]
    for f in expected:
        assert (project_dir / f).exists(), f"Missing: {f}"


def test_init_aborts_if_directory_exists(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    (tmp_path / "myapp").mkdir()

    result = runner.invoke(cli, ["init", "myapp", "--name", "myapp", "--port", "8000", "--data"])
    assert result.exit_code != 0
    assert "already exists" in result.output


def test_init_app_init_py_content(tmp_path):
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    content = (tmp_path / "myapp" / "app" / "__init__.py").read_text()
    assert "from fastapi import FastAPI" in content
    assert "bluefox:framework-imports" in content
    assert "bluefox:routers" in content
    assert "health_router" in content
    assert 'title="myapp"' in content


def test_init_config_py_content(tmp_path):
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    content = (tmp_path / "myapp" / "app" / "config.py").read_text()
    assert "bluefox:settings" in content
    assert "DATABASE_URL" in content
    assert "REDIS_URL" in content
    assert "SECRET_KEY" in content


def test_init_config_no_redis(tmp_path):
    """Config should not have REDIS_URL when --no-redis."""
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp", "--name", "myapp", "--port", "8000", "--data", "--no-redis"])

    content = (tmp_path / "myapp" / "app" / "config.py").read_text()
    assert "DATABASE_URL" in content
    assert "REDIS_URL" not in content


def test_init_no_data_skips_db_files(tmp_path):
    """Without --data, database files should not be generated."""
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp", "--name", "myapp", "--port", "8000", "--no-data"])

    project_dir = tmp_path / "myapp"
    assert not (project_dir / "app" / "database.py").exists()
    assert not (project_dir / "alembic.ini").exists()
    assert not (project_dir / "migrations" / "env.py").exists()
    # But config should still exist
    assert (project_dir / "app" / "config.py").exists()


def test_init_dockerfile_content(tmp_path):
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    content = (tmp_path / "myapp" / "Dockerfile").read_text()
    assert "FROM python:3.12-slim" in content
    assert "EXPOSE 8000" in content
    assert "uvicorn" in content
    # No entrypoint for single-process
    assert "entrypoint.sh" not in content


def test_init_dockerfile_with_worker(tmp_path):
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "myapp", "--name", "myapp", "--port", "8000", "--data", "--worker"])

    content = (tmp_path / "myapp" / "Dockerfile").read_text()
    assert "entrypoint.sh" in content

    entrypoint = (tmp_path / "myapp" / "entrypoint.sh").read_text()
    assert "worker)" in entrypoint


def test_init_bluefox_yml_content(tmp_path):
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    content = (tmp_path / "myapp" / "bluefox.yml").read_text()
    assert "name: myapp" in content
    assert "port: 8000" in content
    assert "engine: postgres" in content


def test_init_bluefox_yml_validates(tmp_path):
    """Generated bluefox.yml should pass load_manifest."""
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    from bluefox_yml import load_manifest

    manifest = load_manifest(tmp_path / "myapp" / "bluefox.yml")
    assert manifest.name == "myapp"


def test_init_dotfile_created(tmp_path):
    """A .bluefox tracking file should be created."""
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    from bluefox_upgrade import load_dotfile

    dotfile = load_dotfile(tmp_path / "myapp")
    from bluefox_cli import __version__
    assert dotfile.cli_version == __version__
    assert "Dockerfile" in dotfile.files
    assert "app/__init__.py" in dotfile.files


def test_init_alembic_config(tmp_path):
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    ini = (tmp_path / "myapp" / "alembic.ini").read_text()
    assert "script_location = migrations" in ini
    assert "prepend_sys_path = ." in ini

    env_py = (tmp_path / "myapp" / "migrations" / "env.py").read_text()
    assert "SQLModel" in env_py
    assert "run_migrations_online" in env_py


def test_init_pyproject_toml_content(tmp_path):
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    content = (tmp_path / "myapp" / "pyproject.toml").read_text()
    assert 'name = "myapp"' in content
    assert "fastapi" in content
    assert "psycopg2-binary" in content


def test_init_health_router(tmp_path):
    runner = CliRunner()
    _invoke_init(runner, tmp_path)

    content = (tmp_path / "myapp" / "app" / "health" / "router.py").read_text()
    assert "/health" in content
    assert "status" in content


def test_init_project_name_in_config(tmp_path):
    """Project name should appear in config defaults."""
    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "cool-project", "--name", "cool-project", "--port", "3000", "--data"])

    config = (tmp_path / "cool-project" / "app" / "config.py").read_text()
    assert "cool_project" in config  # hyphens replaced with underscores


def test_init_no_args_shows_help():
    """Running without arguments should show usage info."""
    runner = CliRunner()
    result = runner.invoke(cli, ["--help"])
    assert result.exit_code == 0
    assert "Bluefox" in result.output


def test_init_missing_project_name():
    """Running init without a project name should fail."""
    runner = CliRunner()
    result = runner.invoke(cli, ["init"])
    assert result.exit_code != 0


def test_init_dot_uses_current_directory(tmp_path):
    """bfx init . should scaffold into the current directory."""
    project_dir = tmp_path / "my_app"
    project_dir.mkdir()
    runner = CliRunner()
    os.chdir(project_dir)
    runner.invoke(cli, ["init", ".", "--name", "my_app", "--port", "8000", "--data"])

    assert (project_dir / "app" / "__init__.py").exists()
    assert (project_dir / "Dockerfile").exists()
    assert (project_dir / ".bluefox").exists()


def test_init_dot_no_cd_in_next_steps(tmp_path):
    """bfx init . should not show 'cd' in next steps."""
    project_dir = tmp_path / "myapp"
    project_dir.mkdir()
    runner = CliRunner()
    os.chdir(project_dir)
    result = runner.invoke(cli, ["init", ".", "--name", "myapp", "--port", "8000", "--data"])

    assert "cd " not in result.output


def test_init_dot_aborts_if_project_files_exist(tmp_path):
    """bfx init . should abort if the directory already has project files."""
    project_dir = tmp_path / "existing"
    project_dir.mkdir()
    (project_dir / "app").mkdir()
    runner = CliRunner()
    os.chdir(project_dir)
    result = runner.invoke(cli, ["init", ".", "--name", "existing", "--port", "8000", "--data"])

    assert result.exit_code != 0
    assert "already contains project files" in result.output
