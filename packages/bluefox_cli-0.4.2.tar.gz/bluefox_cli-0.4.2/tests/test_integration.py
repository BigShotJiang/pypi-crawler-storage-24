"""Integration tests: init → validate → upgrade lifecycle."""

import os

from typer.testing import CliRunner

from bluefox_cli.main import cli


def _init_project(runner, tmp_path, name="testapp", extra_flags=None):
    """Helper to init a project with non-interactive flags."""
    os.chdir(tmp_path)
    flags = ["init", name, "--name", name, "--port", "8000", "--data", "--redis"]
    if extra_flags:
        flags.extend(extra_flags)
    result = runner.invoke(cli, flags)
    assert result.exit_code == 0, f"init failed: {result.output}"
    return tmp_path / name


# --- Step 24: init → validate cycle ---


def test_init_then_validate(tmp_path):
    """bfx init → bfx validate should pass."""
    runner = CliRunner()
    project_dir = _init_project(runner, tmp_path)

    os.chdir(project_dir)
    result = runner.invoke(cli, ["validate"])
    assert result.exit_code == 0
    assert "testapp" in result.output
    assert "✓" in result.output


def test_init_then_validate_shows_data(tmp_path):
    """Validate should show data primitives."""
    runner = CliRunner()
    project_dir = _init_project(runner, tmp_path)

    os.chdir(project_dir)
    result = runner.invoke(cli, ["validate"])
    assert "postgres" in result.output
    assert "redis" in result.output


def test_init_dotfile_has_correct_tracking(tmp_path):
    """After init, .bluefox should track the right files."""
    from bluefox_upgrade import load_dotfile

    runner = CliRunner()
    project_dir = _init_project(runner, tmp_path)

    dotfile = load_dotfile(project_dir)
    assert "Dockerfile" in dotfile.files
    assert "app/__init__.py" in dotfile.files
    assert "app/config.py" in dotfile.files
    assert "app/database.py" in dotfile.files
    assert "alembic.ini" in dotfile.files

    # Untracked files should NOT be in dotfile
    assert "bluefox.yml" not in dotfile.files


def test_init_no_data_dotfile_excludes_db_files(tmp_path):
    """Without data, dotfile should not track database files."""
    from bluefox_upgrade import load_dotfile

    runner = CliRunner()
    os.chdir(tmp_path)
    runner.invoke(cli, ["init", "nodata", "--name", "nodata", "--port", "8000", "--no-data"])

    dotfile = load_dotfile(tmp_path / "nodata")
    assert "app/database.py" not in dotfile.files
    assert "alembic.ini" not in dotfile.files
    assert "Dockerfile" in dotfile.files


def test_init_manifest_validates_with_bluefox_yml(tmp_path):
    """Generated bluefox.yml should be valid per bluefox-yml."""
    from bluefox_yml import load_manifest

    runner = CliRunner()
    project_dir = _init_project(runner, tmp_path)

    manifest = load_manifest(project_dir / "bluefox.yml")
    assert manifest.name == "testapp"
    assert "app" in manifest.compute
    assert manifest.data is not None
    assert manifest.data.engine == "postgres"
    assert manifest.in_memory is not None
    assert manifest.in_memory.engine == "redis"


# --- Step 25: init → upgrade cycle ---


def test_upgrade_up_to_date(tmp_path):
    """Freshly initialized project should be up to date."""
    runner = CliRunner()
    project_dir = _init_project(runner, tmp_path)

    os.chdir(project_dir)
    result = runner.invoke(cli, ["upgrade"])
    assert result.exit_code == 0
    assert "Up to date" in result.output


def test_upgrade_check_up_to_date(tmp_path):
    """--check should exit 0 when up to date."""
    runner = CliRunner()
    project_dir = _init_project(runner, tmp_path)

    os.chdir(project_dir)
    result = runner.invoke(cli, ["upgrade", "--check"])
    assert result.exit_code == 0


def test_upgrade_no_dotfile_errors(tmp_path):
    """bfx upgrade without .bluefox should error."""
    runner = CliRunner()
    os.chdir(tmp_path)

    result = runner.invoke(cli, ["upgrade"])
    assert result.exit_code == 1
    assert ".bluefox" in result.output


# --- Step 26: validate with invalid manifests ---


def test_validate_no_manifest(tmp_path):
    """bfx validate with no bluefox.yml should fail."""
    runner = CliRunner()
    os.chdir(tmp_path)

    result = runner.invoke(cli, ["validate"])
    assert result.exit_code == 1
    assert "bluefox.yml" in result.output


def test_validate_invalid_manifest(tmp_path):
    """bfx validate with invalid bluefox.yml should fail with clear error."""
    runner = CliRunner()
    os.chdir(tmp_path)

    (tmp_path / "bluefox.yml").write_text("invalid: true\n")
    result = runner.invoke(cli, ["validate"])
    assert result.exit_code == 1


def test_validate_corrupt_manifest(tmp_path):
    """bfx validate with a corrupt manifest should report missing fields."""
    runner = CliRunner()
    os.chdir(tmp_path)

    (tmp_path / "bluefox.yml").write_text("version: 1\nname: test\n")
    result = runner.invoke(cli, ["validate"])
    assert result.exit_code == 1
    assert "compute" in result.output.lower()
