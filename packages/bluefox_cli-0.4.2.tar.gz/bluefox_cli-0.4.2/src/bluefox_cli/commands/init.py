"""bfx init — create a new Bluefox project."""

from pathlib import Path

import typer
from rich import print as rprint

from bluefox_cli.init_manifest import UNTRACKED_FILES, get_tracked_files
from bluefox_cli.rendering import create_renderer
from bluefox_upgrade import create_dotfile


def build_context(
    *,
    app_name: str,
    port: int,
    has_data: bool,
    data_engine: str,
    data_version: int,
    has_migrate: bool,
    migrate_command: str,
    has_in_memory: bool,
    in_memory_engine: str,
    in_memory_version: int,
    has_worker: bool,
    compute_processes: dict,
) -> dict:
    """Build the template context dict from user inputs."""
    return {
        "app_name": app_name,
        "port": port,
        "has_data": has_data,
        "data_engine": data_engine,
        "data_version": data_version,
        "has_migrate": has_migrate,
        "migrate_command": migrate_command,
        "has_in_memory": has_in_memory,
        "in_memory_engine": in_memory_engine,
        "in_memory_version": in_memory_version,
        "has_worker": has_worker,
        "compute_processes": compute_processes,
    }


def build_context_from_manifest(manifest) -> dict:
    """Build a template context from a loaded Manifest (for upgrades)."""
    routable = manifest.routable_process()
    port = routable[1].port if routable else 8000

    has_data = manifest.data is not None
    has_in_memory = manifest.in_memory is not None
    has_worker = len(manifest.compute) > 1

    compute_processes = {}
    for name, proc in manifest.compute.items():
        compute_processes[name] = {"port": proc.port} if proc.port else {}

    return build_context(
        app_name=manifest.name,
        port=port,
        has_data=has_data,
        data_engine=manifest.data.engine if has_data else "postgres",
        data_version=manifest.data.version if has_data else 17,
        has_migrate=bool(manifest.data.migrate) if has_data else False,
        migrate_command=manifest.data.migrate if has_data and manifest.data.migrate else "",
        has_in_memory=has_in_memory,
        in_memory_engine=manifest.in_memory.engine if has_in_memory else "redis",
        in_memory_version=manifest.in_memory.version if has_in_memory else 7,
        has_worker=has_worker,
        compute_processes=compute_processes,
    )


def prompt_for_context(default_name: str) -> dict:
    """Interactively collect project configuration."""
    app_name = typer.prompt("App name", default=default_name)
    port = typer.prompt("Port", default=8000, type=int)

    has_data = typer.confirm("Need a database?", default=True)
    data_engine = "postgres"
    data_version = 17
    has_migrate = False
    migrate_command = ""
    if has_data:
        data_engine = typer.prompt("  Engine", default="postgres")
        data_version = typer.prompt("  Version", default=17, type=int)
        migrate_cmd = typer.prompt("  Migration command (blank to skip)", default="uv run alembic upgrade head")
        if migrate_cmd:
            has_migrate = True
            migrate_command = migrate_cmd

    has_in_memory = typer.confirm("Need Redis?", default=False)
    in_memory_engine = "redis"
    in_memory_version = 7
    if has_in_memory:
        in_memory_engine = typer.prompt("  Engine", default="redis")
        in_memory_version = typer.prompt("  Version", default=7, type=int)

    has_worker = typer.confirm("Add a background worker?", default=False)

    compute_processes: dict = {"app": {"port": port}}
    if has_worker:
        compute_processes["worker"] = {}

    return build_context(
        app_name=app_name,
        port=port,
        has_data=has_data,
        data_engine=data_engine,
        data_version=data_version,
        has_migrate=has_migrate,
        migrate_command=migrate_command,
        has_in_memory=has_in_memory,
        in_memory_engine=in_memory_engine,
        in_memory_version=in_memory_version,
        has_worker=has_worker,
        compute_processes=compute_processes,
    )


# Template name → output path mapping
TEMPLATE_TO_PATH = {
    "bluefox.yml": "bluefox.yml",
    "dockerfile": "Dockerfile",
    "pyproject.toml": "pyproject.toml",
    "app_init.py": "app/__init__.py",
    "app_config.py": "app/config.py",
    "app_database.py": "app/database.py",
    "app_health_router.py": "app/health/router.py",
    "alembic_ini": "alembic.ini",
    "migrations_env.py": "migrations/env.py",
    "entrypoint.sh": "entrypoint.sh",
    "gitignore": ".gitignore",
}


def generate_project(project_dir: Path, context: dict) -> list[str]:
    """Generate all project files from templates and create .bluefox tracking.

    Returns list of generated file paths (relative).
    """
    render = create_renderer(context)
    has_data = context["has_data"]
    has_in_memory = context["has_in_memory"]
    has_worker = context["has_worker"]

    # Determine which templates to render
    skip_templates = set()
    if not has_data:
        skip_templates.update(["app_database.py", "alembic_ini", "migrations_env.py"])
    if not has_worker:
        skip_templates.add("entrypoint.sh")

    generated: list[str] = []

    # Render templates
    for template_name, rel_path in TEMPLATE_TO_PATH.items():
        if template_name in skip_templates:
            continue
        file_path = project_dir / rel_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(render(template_name))
        generated.append(rel_path)

    # Create untracked files
    for untracked in UNTRACKED_FILES:
        file_path = project_dir / untracked
        file_path.parent.mkdir(parents=True, exist_ok=True)
        if not file_path.exists():
            file_path.write_text("")
            generated.append(untracked)

    # Create .bluefox dotfile for upgrade tracking
    tracked_files = get_tracked_files(
        has_data=has_data,
        has_in_memory=has_in_memory,
        has_worker=has_worker,
    )
    from bluefox_cli import __version__

    create_dotfile(project_dir, cli_version=__version__, tracked_files=tracked_files)
    generated.append(".bluefox")

    return generated


def validate_generated_manifest(project_dir: Path, *, allow_reserved: bool = False) -> None:
    """Validate the generated bluefox.yml as a sanity check.

    Args:
        allow_reserved: If True, suppress warnings about reserved 'bluefox-' prefix.
            Used for platform projects (e.g. bluefox-cloud).
    """
    from bluefox_yml import ManifestError, load_manifest

    try:
        load_manifest(project_dir / "bluefox.yml")
    except ManifestError as e:
        if allow_reserved and "reserved" in str(e):
            return
        rprint(f"[yellow]Warning:[/yellow] generated bluefox.yml failed validation: {e}")
