"""bfx dev — start the dev environment."""

import subprocess
from pathlib import Path

import typer
from rich import print as rprint

COMPOSE_DEV = ["docker", "compose", "-f", "docker-compose.yml", "-f", "docker-compose.dev.yml"]


def require_project() -> None:
    """Abort if not inside a Bluefox project."""
    if not (Path.cwd() / "docker-compose.dev.yml").exists():
        rprint("[red]Error:[/red] not inside a Bluefox project (no docker-compose.dev.yml found).")
        raise typer.Exit(1)


def run_dev() -> None:
    """Start the dev environment (Postgres + Redis + app with hot reload)."""
    require_project()
    subprocess.run([*COMPOSE_DEV, "up", "--build"])
