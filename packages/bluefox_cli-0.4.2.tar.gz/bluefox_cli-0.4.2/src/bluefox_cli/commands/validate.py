"""bfx validate — validate bluefox.yml in the current directory."""

from rich import print as rprint

from bluefox_cli.manifest import require_manifest


def run_validate() -> None:
    """Validate bluefox.yml in the current directory."""
    manifest = require_manifest()

    rprint(f"[green]✓[/green] {manifest.name} — valid bluefox.yml")
    rprint(f"  Compute: {', '.join(manifest.compute.keys())}")

    routable = manifest.routable_process()
    if routable:
        name, proc = routable
        rprint(f"  Route: {name} on port {proc.port}")

    if manifest.data:
        rprint(f"  Data: {manifest.data.engine} {manifest.data.version}")

    if manifest.in_memory:
        rprint(f"  In-memory: {manifest.in_memory.engine} {manifest.in_memory.version}")
