"""bfx db — database commands."""

import os
import re
import subprocess
import time
from pathlib import Path

import typer
from rich import print as rprint

from bluefox_cli.commands.dev import COMPOSE_DEV, require_project


def run_migrate(name: str) -> None:
    """Generate a new migration (auto-detects model changes)."""
    require_project()

    db_url = _get_dev_db_url()

    rprint("Starting database...")
    subprocess.run([*COMPOSE_DEV, "up", "db", "-d"], capture_output=True)

    # Wait for DB to be healthy (use the compose healthcheck)
    for _ in range(30):
        result = subprocess.run(
            [*COMPOSE_DEV, "ps", "db", "--format", "{{.Health}}"],
            capture_output=True,
            text=True,
        )
        if "healthy" in result.stdout:
            break
        time.sleep(1)
    else:
        rprint("[red]Error:[/red] database did not become ready.")
        subprocess.run([*COMPOSE_DEV, "stop", "db"], capture_output=True)
        raise typer.Exit(1)

    rprint(f"Generating migration '{name}'...")
    env = {**os.environ, "DATABASE_URL": db_url}
    result = subprocess.run(
        ["uv", "run", "alembic", "revision", "--autogenerate", "-m", name],
        env=env,
    )

    # Stop the temporary DB
    rprint("Stopping database...")
    subprocess.run([*COMPOSE_DEV, "stop", "db"], capture_output=True)

    if result.returncode != 0:
        raise typer.Exit(result.returncode)

    rprint("Done! Run 'bfx dev' to apply the migration.")


def _get_dev_db_url() -> str:
    """Extract DATABASE_URL from docker-compose.dev.yml, rewritten for localhost."""
    compose_path = Path.cwd() / "docker-compose.dev.yml"
    content = compose_path.read_text()
    match = re.search(r"DATABASE_URL=(\S+)", content)
    if match:
        return match.group(1).replace("@db:", "@localhost:")
    rprint("[red]Error:[/red] DATABASE_URL not found in docker-compose.dev.yml.")
    raise typer.Exit(1)
