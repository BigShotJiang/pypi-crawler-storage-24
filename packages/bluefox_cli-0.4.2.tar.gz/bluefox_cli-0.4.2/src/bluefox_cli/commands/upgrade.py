"""bfx upgrade — upgrade framework files to the latest CLI version."""

from pathlib import Path

import typer
from rich import print as rprint

from bluefox_upgrade import (
    check_conflicts,
    execute_upgrade,
    load_dotfile,
    plan_upgrade,
    save_dotfile,
)
from bluefox_yml import ManifestError

from bluefox_cli import __version__
from bluefox_cli.commands.init import build_context_from_manifest
from bluefox_cli.manifest import require_manifest
from bluefox_cli.rendering import create_renderer
from bluefox_cli.upgrades.registry import UPGRADES


def run_upgrade(
    skip_conflicts: bool = False,
    force: bool = False,
    dry_run: bool = False,
    check: bool = False,
) -> None:
    """Upgrade framework files to the latest CLI version."""
    project_dir = Path.cwd()

    # Load .bluefox
    dotfile_path = project_dir / ".bluefox"
    if not dotfile_path.exists():
        rprint("[red]Error:[/red] no .bluefox file found. Is this a Bluefox project?")
        raise typer.Exit(1)

    dotfile = load_dotfile(project_dir)

    # Plan upgrade
    plan = plan_upgrade(dotfile, UPGRADES, target_version=__version__)

    if not plan.operations:
        if not check:
            rprint(f"[green]✓[/green] Up to date (v{dotfile.cli_version}).")
        raise typer.Exit(0)

    # --check mode: just exit 1 if upgrades available
    if check:
        raise typer.Exit(1)

    rprint(f"Upgrade: v{plan.current_version} → v{plan.target_version}")
    rprint("")
    for upgrade in plan.upgrades:
        rprint(f"  [bold]{upgrade.description}[/bold]")
        for op in upgrade.operations:
            rprint(f"    • {op.description}")
    rprint("")

    # Check conflicts
    conflicts = check_conflicts(plan, project_dir, dotfile)
    if conflicts and not skip_conflicts and not force:
        rprint("[yellow]Conflicts detected:[/yellow]")
        for conflict in conflicts:
            rprint(f"  {conflict.path}: {conflict.reason}")
        rprint("")
        rprint("Use --skip-conflicts to skip these files, or --force to backup and overwrite.")
        raise typer.Exit(1)

    # Dry run: show plan without applying
    if dry_run:
        rprint("[dim]Dry run — no changes applied.[/dim]")
        raise typer.Exit(0)

    # Build render function from manifest
    manifest_path = project_dir / "bluefox.yml"
    if not manifest_path.exists():
        rprint("[red]Error:[/red] bluefox.yml not found. Cannot render templates for upgrade.")
        raise typer.Exit(1)

    try:
        manifest = require_manifest(manifest_path)
        context = build_context_from_manifest(manifest)
    except (typer.Exit, ManifestError):
        rprint("[red]Error:[/red] invalid bluefox.yml. Fix it before upgrading.")
        raise typer.Exit(1)

    render = create_renderer(context)

    # Execute
    result = execute_upgrade(
        plan, project_dir, dotfile, render,
        skip_conflicts=skip_conflicts,
        force=force,
    )

    # Save updated dotfile
    save_dotfile(project_dir, dotfile)

    rprint(f"[green]✓[/green] Upgraded to v{plan.target_version}")
    if result.applied:
        rprint(f"  Applied: {len(result.applied)} operations")
    if result.skipped:
        rprint(f"  Skipped: {len(result.skipped)} (conflicts)")
    if result.backed_up:
        rprint(f"  Backed up: {len(result.backed_up)} files")
