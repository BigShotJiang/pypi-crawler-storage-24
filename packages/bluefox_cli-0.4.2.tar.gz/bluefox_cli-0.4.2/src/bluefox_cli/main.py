import subprocess
from pathlib import Path
from typing import Optional

import typer
from rich import print as rprint

from bluefox_cli.commands.db import run_migrate
from bluefox_cli.commands.dev import run_dev
from bluefox_cli.commands.init import (
    build_context,
    generate_project,
    prompt_for_context,
    validate_generated_manifest,
)
from bluefox_cli.commands.upgrade import run_upgrade
from bluefox_cli.commands.validate import run_validate

cli = typer.Typer(help="Bluefox Stack CLI.")
db_app = typer.Typer(help="Database commands.")
cli.add_typer(db_app, name="db")


@cli.command()
def init(
    project_name: str = typer.Argument(help="Project name, or '.' to use current directory"),
    name: Optional[str] = typer.Option(None, "--name", help="App name (skip prompt)"),
    port: Optional[int] = typer.Option(None, "--port", help="Port (skip prompt)"),
    data: Optional[bool] = typer.Option(None, "--data/--no-data", help="Include database"),
    data_version: int = typer.Option(17, "--data-version", help="Database version"),
    redis: Optional[bool] = typer.Option(None, "--redis/--no-redis", help="Include Redis"),
    worker: bool = typer.Option(False, "--worker", help="Add background worker"),
    migrate: str = typer.Option("uv run alembic upgrade head", "--migrate", help="Migration command"),
):
    """Create a new Bluefox project.

    Pass a name to create a new directory, or '.' to use the current directory.
    Use --name and --port flags for non-interactive mode.
    """
    if project_name == ".":
        project_dir = Path.cwd()
        default_name = project_dir.name
        conflicts = [f for f in ["app", "pyproject.toml", "bluefox.yml"] if (project_dir / f).exists()]
        if conflicts:
            rprint(f"[red]Error:[/red] directory already contains project files ({', '.join(conflicts)}).")
            raise typer.Exit(1)
    else:
        project_dir = Path.cwd() / project_name
        default_name = project_name
        if project_dir.exists():
            rprint(f"[red]Error:[/red] directory '{project_name}' already exists.")
            raise typer.Exit(1)
        project_dir.mkdir()

    # If all required flags are provided, skip prompts
    if name is not None and port is not None and data is not None:
        has_data = data
        has_in_memory = redis if redis is not None else False
        has_migrate = bool(migrate) and has_data
        compute_processes: dict = {"app": {"port": port}}
        if worker:
            compute_processes["worker"] = {}

        context = build_context(
            app_name=name,
            port=port,
            has_data=has_data,
            data_engine="postgres",
            data_version=data_version,
            has_migrate=has_migrate,
            migrate_command=migrate if has_migrate else "",
            has_in_memory=has_in_memory,
            in_memory_engine="redis",
            in_memory_version=7,
            has_worker=worker,
            compute_processes=compute_processes,
        )
    else:
        context = prompt_for_context(default_name)

    app_name = context["app_name"]
    rprint(f"Creating project '{app_name}'...")

    generated = generate_project(project_dir, context)
    validate_generated_manifest(project_dir, allow_reserved=app_name.startswith("bluefox-"))

    # Run uv sync to create lockfile
    _run(["uv", "sync"], cwd=project_dir)

    rprint("")
    rprint(f"[green]Created {app_name}/[/green]")
    for path in sorted(generated):
        rprint(f"    {path}")
    rprint("")
    rprint("Next steps:")
    if project_dir != Path.cwd():
        rprint(f"  cd {project_name}")
    rprint("  uv sync")
    rprint("  uvicorn app:create_app --factory")


@cli.command()
def validate():
    """Validate bluefox.yml in the current directory."""
    run_validate()


@cli.command()
def upgrade(
    skip_conflicts: bool = typer.Option(False, "--skip-conflicts", help="Skip conflicting files"),
    force: bool = typer.Option(False, "--force", help="Backup and overwrite conflicts"),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show plan without applying"),
    check: bool = typer.Option(False, "--check", help="Exit 1 if upgrades available (for CI)"),
):
    """Upgrade framework files to the latest CLI version."""
    run_upgrade(skip_conflicts=skip_conflicts, force=force, dry_run=dry_run, check=check)


@cli.command()
def dev():
    """Start the dev environment (Postgres + Redis + app with hot reload)."""
    run_dev()


@db_app.command()
def migrate(name: str = typer.Argument(help="Migration name")):
    """Generate a new migration (auto-detects model changes)."""
    run_migrate(name)


def _run(cmd: list[str], cwd: Path) -> None:
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        rprint(f"[red]Error running {' '.join(cmd)}:[/red]")
        rprint(result.stderr)
        raise typer.Exit(1)
