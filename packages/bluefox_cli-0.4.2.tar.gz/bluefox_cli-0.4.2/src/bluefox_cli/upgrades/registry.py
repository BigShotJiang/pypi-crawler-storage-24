"""Version-to-version upgrade definitions.

Each Upgrade entry describes what changed between CLI versions
and how to apply those changes to existing projects.
"""

from bluefox_upgrade import (
    AddDependency,
    BumpDependency,
    CreateFile,
    RemoveDependency,
    RemoveFile,
    ReplaceFile,
    UpdateSection,
    Upgrade,
)

UPGRADES: list[Upgrade] = [
    # Upgrades will be added here as the CLI evolves.
    # Example:
    # Upgrade(
    #     from_version="0.3.6",
    #     to_version="0.4.0",
    #     description="Updated Dockerfile base image",
    #     operations=[
    #         ReplaceFile("Dockerfile", template="dockerfile",
    #                     description="Updated base image to python:3.13-slim"),
    #     ],
    # ),
]
