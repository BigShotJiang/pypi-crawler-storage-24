"""Shared manifest helper for CLI commands."""

from pathlib import Path

import typer
from rich import print as rprint

from bluefox_yml import ManifestError, Manifest, load_manifest


def require_manifest(path: Path | None = None) -> Manifest:
    """Load and validate bluefox.yml. Exit with error if invalid."""
    if path is None:
        path = Path.cwd() / "bluefox.yml"

    if not path.exists():
        rprint("[red]Error:[/red] no bluefox.yml found.")
        raise typer.Exit(1)

    try:
        return load_manifest(path)
    except ManifestError as e:
        rprint(f"[red]✗[/red] {e}")
        raise typer.Exit(1)
