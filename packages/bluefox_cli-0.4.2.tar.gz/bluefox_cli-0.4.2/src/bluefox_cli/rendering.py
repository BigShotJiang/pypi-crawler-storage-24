"""Jinja2 template renderer for generated project files."""

from collections.abc import Callable
from jinja2 import Environment, PackageLoader


def create_renderer(context: dict) -> Callable[[str], str]:
    """Create a render function bound to a template context.

    Returns a callable: render(template_name) → str

    This is what gets passed to bluefox-upgrade's executor
    as the render_template argument.
    """
    env = Environment(
        loader=PackageLoader("bluefox_cli", "templates"),
        keep_trailing_newline=True,
    )

    def render(template_name: str) -> str:
        template = env.get_template(f"{template_name}.jinja2")
        return template.render(**context)

    return render
