"""
passmeter – offline ML-powered password strength evaluation.

Quick start
-----------
>>> from passmeter import evaluate_password
>>> result = evaluate_password("Monkey2024!")
>>> print(result["label"])
'Medium'
"""

from .core import evaluate_password
from .features import extract_features

__all__ = ["evaluate_password", "extract_features"]
__version__ = "0.1.1"
