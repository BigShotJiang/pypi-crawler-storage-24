"""Transient Table Mixin for routing ephemeral pipeline data to dedicated transient resources."""

import os
from typing import Optional
from aws_lambda_powertools import Logger

logger = Logger(__name__)

DEFAULT_TTL_SECONDS = 1_209_600  # 14 days


class TransientTableMixin:
    """Mixin for services that route data to dedicated transient resources.

    Provides static utility methods for resolving the transient DynamoDB table
    name, the transient S3 bucket, and reading the configurable TTL duration
    from environment variables.
    """

    @staticmethod
    def resolve_transient_table_name(
        fallback_table_name: Optional[str] = None,
    ) -> str:
        """Resolve the transient table name from environment.

        Resolution order:
        1. ``DYNAMODB_TRANSIENT_TABLE_NAME`` environment variable
        2. ``fallback_table_name`` parameter (typically the main table name)
        3. ``DYNAMODB_TABLE_NAME`` or ``TABLE_NAME`` environment variable

        Args:
            fallback_table_name: Optional table name to use when the transient
                env var is not set (usually the main table name).

        Returns:
            The resolved table name.

        Raises:
            ValueError: If no table name can be resolved from any source.
        """
        transient = os.getenv("DYNAMODB_TRANSIENT_TABLE_NAME")
        if transient:
            return transient

        if fallback_table_name:
            logger.warning(
                "DYNAMODB_TRANSIENT_TABLE_NAME not set, falling back to main table"
            )
            return fallback_table_name

        main = os.getenv("DYNAMODB_TABLE_NAME") or os.getenv("TABLE_NAME")
        if main:
            logger.warning(
                "DYNAMODB_TRANSIENT_TABLE_NAME not set, falling back to DYNAMODB_TABLE_NAME"
            )
            return main

        raise ValueError(
            "No table name available. Set DYNAMODB_TRANSIENT_TABLE_NAME or DYNAMODB_TABLE_NAME."
        )

    @staticmethod
    def get_ttl_duration() -> int:
        """Get TTL duration in seconds from environment or use the default.

        Reads ``TRANSIENT_DATA_TTL_SECONDS`` environment variable. Falls back
        to :data:`DEFAULT_TTL_SECONDS` (14 days) when not set.

        Returns:
            TTL duration in seconds.
        """
        raw = os.getenv("TRANSIENT_DATA_TTL_SECONDS")
        if raw:
            return int(raw)
        return DEFAULT_TTL_SECONDS

    @staticmethod
    def resolve_transient_bucket(fallback_bucket: Optional[str] = None) -> str:
        """Resolve the transient S3 bucket name from environment.

        Used by handlers that read/write intermediate pipeline files
        (output batch partials, per-profile calculation JSONs, batch warnings).

        Resolution order:
        1. ``S3_TRANSIENT_BUCKET`` environment variable
        2. ``fallback_bucket`` parameter (typically the workload bucket)
        3. ``S3_BUCKET`` or ``FILE_SYSTEM_BUCKET`` environment variable

        Args:
            fallback_bucket: Optional bucket name to use when the transient
                env var is not set (usually the workload bucket name).

        Returns:
            The resolved bucket name.
        """
        transient = os.getenv("S3_TRANSIENT_BUCKET")
        if transient:
            return transient

        if fallback_bucket:
            return fallback_bucket

        workload = os.getenv("S3_BUCKET") or os.getenv("FILE_SYSTEM_BUCKET")
        if workload:
            return workload

        return ""
