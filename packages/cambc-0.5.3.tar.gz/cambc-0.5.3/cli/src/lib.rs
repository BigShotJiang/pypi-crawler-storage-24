use pyo3::prelude::*;
use battlecode_titan::cli::Args;
use std::path::PathBuf;

#[pyfunction]
#[pyo3(signature = (player_a, player_b, engine_root, map_path, replay="replay.replay26", seed=1))]
fn run_game(
    player_a: &str,
    player_b: &str,
    engine_root: &str,
    map_path: &str,
    replay: &str,
    seed: u64,
) -> PyResult<String> {
    let args = Args {
        player_a: player_a.to_string(),
        player_b: player_b.to_string(),
        replay: replay.to_string(),
        map: map_path.to_string(),
        turn_timeout_ms: 5,
        seed,
        sandboxed: false,
        suppress_indicators: false,
        engine_root: PathBuf::from(engine_root),
    };
    battlecode_titan::runner::run(args)?;
    Ok(replay.to_string())
}

#[pymodule]
fn cambc_engine(m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_function(wrap_pyfunction!(run_game, m)?)?;
    Ok(())
}
