from __future__ import annotations

from typing import Any, Dict, Optional, TypedDict


class TransparencyMetadata(TypedDict, total=False):
    is_ai_generated: bool
    disclosure: str
    article: str
    injection_mode: str


class GuardResponse(TypedDict, total=False):
    allowed: bool
    reason: str
    detected_pii: bool
    transformed_input: str
    fail_open: bool
    guard_event_id: str
    client_event_id: str
    guard_latency_ms: int
    shadow_mode: bool
    simulated_decision: str
    shadow_blocked: bool
    policy_pack_matcher_backend: str
    policy_pack_scan_profile: str
    policy_pack_scan_mode: str
    exotic_language_detected: bool
    langid_primary: str
    langid_confidence: str
    langid_secondary: list[str]
    langid_mixed: bool
    langid_source: str
    transparency: TransparencyMetadata


class GuardParams(TypedDict, total=False):
    input: str
    system_id: str
    model: str
    user_id: str
    client_event_id: str
    expected_languages: list[str]
    request_identity: Dict[str, Any]
    client_capabilities: Dict[str, Any]


class LogParams(TypedDict, total=False):
    event_id: str
    system_id: str
    input: str
    output: str
    model: str
    usage: Dict[str, Any]
    tokens: Dict[str, Any]
    latency: int
    user_id: str
    request_identity: Dict[str, Any]
    metadata: Dict[str, Any]
    event_type: str
    severity: str
    timestamp: str
    client_capabilities: Dict[str, Any]
