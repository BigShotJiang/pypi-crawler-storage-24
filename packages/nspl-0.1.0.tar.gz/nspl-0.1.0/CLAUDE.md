# NSPL - Non-Stochastic Protection Layer

## What This Is
Python framework for LLM safety: prompt injection detection, verified tool execution, PII filtering, confidence-gated reasoning pipelines. `pip install nspl`.

## Project Structure
```
src/nspl/
  core/              # Logic gates (AND/OR/NOT/XOR/IMPLIES), UncertainValue, distributions
  actions/           # @action decorator, preconditions/postconditions/safety, composition
  guards/            # Prompt injection, PII, content policy, classifier, ensemble, canary
    detectors.py     # Regex patterns (7 categories, ~100 patterns, German + English)
    classifier.py    # Fine-tuned DeBERTa (86M params, 92% F1 on benchmark)
    ensemble.py      # Union of all detectors
    normalize.py     # Unicode normalization (homoglyph, leetspeak, zero-width defense)
    compound.py      # Pretext+payload combination detection
    decoders.py      # Hex/base64/rot13 decode-and-rescan
    canary.py        # Canary tokens for system prompt leakage detection
    semantic.py      # Tiered detection (structural -> classifier -> LLM-as-judge)
    input_guard.py   # InputGuard (compose all detectors)
    output_guard.py  # OutputGuard (content, PII, leakage, echo)
    pipeline.py      # GuardedLLM (input -> LLM -> output)
  reasoning/         # run_pipeline, async_run_pipeline, async_parallel_stages
  integrations/      # Claude, OpenAI, Google ADK, LangChain, DSPy, MCP server
  llm/               # Unified LLM client (SDK + CLI fallback)
tests/               # 274 tests (pytest)
experiments/         # 7 experiments with JSON results
  exp1_gate_accuracy/    # 10K boolean expressions
  exp3_action_safety/    # 1K action invocations
  exp4_fuzzy_safety/     # Continuous safety (honest negative result)
  exp5_classifier/       # Classifier vs regex vs tiered
  exp6_benchmarks/       # deepset + jailbreak + fine-tuning
  exp7_full_benchmarks/  # 5-dataset cross-validation (4,239 samples)
paper/               # 8-page LaTeX paper with all results
examples/            # 6 runnable demos
docs/                # Quickstart, FAQ, API reference (21 modules), comparisons
deploy/              # MCP install script, drop-in integration script
```

## Key Commands
```bash
uv pip install -e ".[dev]"           # install
pytest                                # 274 tests
ruff check src/ tests/                # lint
mypy src/                             # type check
python examples/guarded_llm.py        # demo guards
python examples/customer_service.py   # demo actions
python -m nspl.integrations.mcp_server  # MCP server
```

## Benchmark Results
| Metric | Value |
|--------|-------|
| Gate accuracy | 100% at 0.006ms (vs Claude 84% at 9s) |
| Action safety TPR/FPR | 100%/0% at 0.013ms |
| Injection F1 (deepset) | 92.2% |
| Jailbreak recall | 100% (79/79) |
| Cross-dataset recall | 77-100% (5 datasets, 4,239 samples) |
| Fuzzy safety | 66-80% (honest negative: use thresholds) |

## Design Principles
1. **Deterministic safety**: No LLM in the safety loop (core checks)
2. **Provider-agnostic**: Thin adapters, no core dependency on any SDK
3. **Honest reporting**: Negative results (Exp 3, 4) published alongside positive
4. **Explicit thresholds**: Lesson from Exp 4 -- fuzzy gates fail on continuous values
5. **Layered defense**: Regex -> compound -> decoder -> classifier -> LLM judge
