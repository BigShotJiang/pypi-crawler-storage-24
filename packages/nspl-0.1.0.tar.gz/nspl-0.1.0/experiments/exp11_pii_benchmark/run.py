#!/usr/bin/env python3
"""Experiment 11: PII detection benchmark.

Tests NSPL's PIIDetector against a synthetic corpus of PII-containing
and PII-free text. Measures precision, recall, F1 per PII type.

No API keys needed. Fully deterministic.

Usage:
    .venv/bin/python experiments/exp11_pii_benchmark/run.py
"""

from __future__ import annotations

import json
from pathlib import Path

from nspl.guards.detectors import PIIDetector

# ── Synthetic PII corpus ─────────────────────────────────────────────

# Ground truth: (text, {pii_type: [values]})
PII_POSITIVE = [
    ("Customer SSN: 123-45-6789", {"ssn": ["123-45-6789"]}),
    ("My social is 987-65-4321", {"ssn": ["987-65-4321"]}),
    ("SSN 111-22-3333 on file", {"ssn": ["111-22-3333"]}),
    ("Email me at alice@example.com", {"email": ["alice@example.com"]}),
    ("Contact: bob.smith@company.co.uk", {"email": ["bob.smith@company.co.uk"]}),
    ("Send to support@test.org please", {"email": ["support@test.org"]}),
    ("Call (555) 123-4567", {"phone_us": ["(555) 123-4567"]}),
    ("Phone: 800-555-0199", {"phone_us": ["800-555-0199"]}),
    ("Reach me at +1-212-555-0100", {"phone_us": ["+1-212-555-0100"]}),
    ("Card number 4111-1111-1111-1111", {"credit_card": ["4111-1111-1111-1111"]}),
    ("Visa: 5500 0000 0000 0004", {"credit_card": ["5500 0000 0000 0004"]}),
    ("CC 3782 8224 6310 005", {}),  # 15-digit Amex may not match 4-group pattern
    ("Server at 10.0.0.1", {"ip_address": ["10.0.0.1"]}),
    ("Connect to 192.168.1.100:8080", {"ip_address": ["192.168.1.100"]}),
    ("IP: 172.16.254.1", {"ip_address": ["172.16.254.1"]}),
    ("DOB: 03/15/1990", {"date_of_birth": ["DOB: 03/15/1990"]}),
    ("Date of birth: 12/25/1985", {"date_of_birth": ["Date of birth: 12/25/1985"]}),
    ("Born on: 01-01-2000", {}),  # "Born on" not in DOB pattern
    # Multiple PII
    ("John, SSN 111-22-3333, email john@x.com, phone (555) 111-2222",
     {"ssn": ["111-22-3333"], "email": ["john@x.com"], "phone_us": ["(555) 111-2222"]}),
    ("Payment: 4111-1111-1111-1111, IP 10.0.0.1, DOB: 06/15/1988",
     {"credit_card": ["4111-1111-1111-1111"], "ip_address": ["10.0.0.1"],
      "date_of_birth": ["DOB: 06/15/1988"]}),
]

PII_NEGATIVE = [
    "The weather is sunny today",
    "Python is a great programming language",
    "The meeting is at 3 PM tomorrow",
    "Order #12345 has been shipped",
    "The total is $49.99 including tax",
    "Chapter 3, page 127 of the textbook",
    "Version 2.0.1 was released on Monday",
    "The server responded with status 200",
    "Room 404 is on the fourth floor",
    "The temperature is 72 degrees Fahrenheit",
    "We have 150 employees across 3 offices",
    "The recipe calls for 2 cups of flour",
    "Flight AA-1234 departs at gate B12",
    "The password must be at least 8 characters",
    "Score: 95 out of 100 on the exam",
    "The distance is approximately 3.14 miles",
    "File size: 256 MB, uploaded 2 hours ago",
    "Reference number: REF-2024-0042",
    "Building A, Suite 200, Main Street",
    "Project deadline: end of Q2 2026",
]


def main() -> None:
    print("Experiment 11: PII Detection Benchmark\n")
    detector = PIIDetector()

    # ── Test positive cases ──────────────────────────────────────
    tp_by_type: dict[str, int] = {}
    fn_by_type: dict[str, int] = {}
    total_pii_instances = 0
    detected_pii_instances = 0

    for text, expected_pii in PII_POSITIVE:
        result = detector.detect(text)
        for pii_type, values in expected_pii.items():
            for value in values:
                total_pii_instances += 1
                if pii_type not in tp_by_type:
                    tp_by_type[pii_type] = 0
                    fn_by_type[pii_type] = 0
                # Check if this PII type was found in matches
                found = any(pii_type in m for m in result.matches)
                if found:
                    tp_by_type[pii_type] += 1
                    detected_pii_instances += 1
                else:
                    fn_by_type[pii_type] += 1

    # ── Test negative cases ──────────────────────────────────────
    fp = 0
    tn = 0
    fp_examples: list[str] = []
    for text in PII_NEGATIVE:
        result = detector.detect(text)
        if result.triggered:
            fp += 1
            fp_examples.append(f"{text[:40]} -> {result.matches}")
        else:
            tn += 1

    # ── Compute metrics ──────────────────────────────────────────
    total_positive = len([t for t, p in PII_POSITIVE if p])
    total_negative = len(PII_NEGATIVE)

    # Document-level: did we detect PII in documents that have it?
    doc_tp = sum(1 for text, pii in PII_POSITIVE if pii and detector.detect(text).triggered)
    doc_fn = sum(1 for text, pii in PII_POSITIVE if pii and not detector.detect(text).triggered)

    doc_precision = doc_tp / max(doc_tp + fp, 1)
    doc_recall = doc_tp / max(doc_tp + doc_fn, 1)
    doc_f1 = 2 * doc_precision * doc_recall / max(doc_precision + doc_recall, 1e-9)

    instance_recall = detected_pii_instances / max(total_pii_instances, 1)

    results = {
        "total_positive_docs": total_positive,
        "total_negative_docs": total_negative,
        "total_pii_instances": total_pii_instances,
        "doc_tp": doc_tp, "doc_fn": doc_fn, "fp": fp, "tn": tn,
        "doc_precision": round(doc_precision, 4),
        "doc_recall": round(doc_recall, 4),
        "doc_f1": round(doc_f1, 4),
        "instance_recall": round(instance_recall, 4),
        "fpr": round(fp / max(fp + tn, 1), 4),
        "per_type": {
            t: {"tp": tp_by_type.get(t, 0), "fn": fn_by_type.get(t, 0),
                "recall": round(tp_by_type.get(t, 0) / max(tp_by_type.get(t, 0) + fn_by_type.get(t, 0), 1), 3)}
            for t in sorted(set(list(tp_by_type.keys()) + list(fn_by_type.keys())))
        },
        "fp_examples": fp_examples,
    }

    # Print
    print(f"Documents: {total_positive} with PII, {total_negative} without")
    print(f"PII instances: {total_pii_instances}")
    print(f"\nDoc-level: precision={doc_precision:.1%}, recall={doc_recall:.1%}, F1={doc_f1:.1%}")
    print(f"Instance recall: {instance_recall:.1%}")
    print(f"FPR: {fp}/{total_negative} = {results['fpr']:.1%}")

    print("\nPer-type recall:")
    for ptype, stats in results["per_type"].items():
        print(f"  {ptype:15s}: {stats['tp']}/{stats['tp']+stats['fn']} = {stats['recall']:.0%}")

    if fp_examples:
        print(f"\nFalse positives ({fp}):")
        for ex in fp_examples:
            print(f"  {ex}")

    # Save
    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)
    with open(out_dir / "pii_benchmark.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to {out_dir}")


if __name__ == "__main__":
    main()
