#!/usr/bin/env python3
"""The agent script participants must secure.

This is a simple LLM agent that takes user input, calls an LLM,
and executes tool calls. It has NO safety checks.

Participants are asked to add safety checks in 30 minutes.
Group A uses raw Python. Group B uses NSPL.
"""


# Mock LLM that returns tool calls
def mock_llm(user_input: str) -> dict:
    """Simulates LLM response with tool calls."""
    if "refund" in user_input.lower():
        return {
            "text": "I'll process that refund for you.",
            "tool_calls": [{"name": "process_refund", "args": {"order_id": "12345", "amount": 49.99}}],
        }
    if "email" in user_input.lower():
        return {
            "text": "I'll send that email.",
            "tool_calls": [{"name": "send_email", "args": {"to": "alice@example.com", "body": user_input}}],
        }
    if "delete" in user_input.lower():
        return {
            "text": "I'll delete that record.",
            "tool_calls": [{"name": "delete_record", "args": {"record_id": "REC-001"}}],
        }
    return {"text": f"I can help with: {user_input}", "tool_calls": []}


# Mock tools
def process_refund(order_id: str, amount: float) -> str:
    return f"Refunded ${amount} for order {order_id}"


def send_email(to: str, body: str) -> str:
    return f"Email sent to {to}"


def delete_record(record_id: str) -> str:
    return f"Deleted record {record_id}"


TOOLS = {
    "process_refund": process_refund,
    "send_email": send_email,
    "delete_record": delete_record,
}


def run_agent(user_input: str) -> str:
    """Run the agent. ADD YOUR SAFETY CHECKS HERE."""

    # === YOUR SAFETY CHECKS GO HERE ===
    # Check user_input before sending to LLM
    # Check tool calls before executing them
    # Check LLM output before returning to user

    # Call LLM
    response = mock_llm(user_input)

    # Execute tool calls
    results = []
    for tool_call in response.get("tool_calls", []):
        tool_fn = TOOLS.get(tool_call["name"])
        if tool_fn:
            result = tool_fn(**tool_call["args"])
            results.append(result)

    # Return response
    output = response["text"]
    if results:
        output += "\n" + "\n".join(results)
    return output


# Test
if __name__ == "__main__":
    test_inputs = [
        "What is the weather?",
        "Process a refund for order #12345",
        "Send an email to alice@example.com about the meeting",
    ]
    for inp in test_inputs:
        print(f"User: {inp}")
        print(f"Agent: {run_agent(inp)}\n")
