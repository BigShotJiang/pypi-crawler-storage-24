#!/usr/bin/env python3
"""Experiment 7: Comprehensive multi-dataset benchmark.

Datasets:
  1. deepset/prompt-injections (662, labeled)
  2. rubend18/ChatGPT-Jailbreak-Prompts (79, all jailbreak)
  3. jackhhao/jailbreak-classification (1044, labeled benign/jailbreak)
  4. xTRam1/safe-guard-prompt-injection (8236, labeled 0/1)
  5. Lakera/mosscap_prompt_injection (sample of 1000, CTF injection game)

Detectors tested:
  - Regex (medium)
  - InputGuard (full stack)
  - Classifier (pretrained)
  - Classifier (fine-tuned on deepset)
  - Ensemble+FT

Usage:
    .venv/bin/python experiments/exp7_full_benchmarks/run.py
"""

from __future__ import annotations

import json
import time
from pathlib import Path

from datasets import load_dataset

from nspl.guards.classifier import ClassifierDetector
from nspl.guards.compound import CompoundDetector
from nspl.guards.detectors import PromptInjectionDetector
from nspl.guards.ensemble import EnsembleDetector
from nspl.guards.input_guard import InputGuard

FT_MODEL = str(Path(__file__).parent.parent / "exp6_benchmarks" / "finetuned_model")


def _is_triggered(r: object) -> bool:
    if hasattr(r, "triggered"):
        return r.triggered  # type: ignore[union-attr]
    if hasattr(r, "allowed"):
        return not r.allowed  # type: ignore[union-attr]
    return False


def bench(name: str, fn: object, texts: list[str], labels: list[int]) -> dict:
    tp = fp = tn = fn_count = 0
    lats: list[float] = []
    for text, label in zip(texts, labels):
        t0 = time.perf_counter()
        r = fn(text)  # type: ignore[operator]
        lats.append((time.perf_counter() - t0) * 1000)
        pred = _is_triggered(r)
        actual = label == 1
        if pred and actual: tp += 1
        elif pred and not actual: fp += 1
        elif not pred and actual: fn_count += 1
        else: tn += 1
    total = tp + fp + tn + fn_count
    prec = tp / max(tp + fp, 1)
    rec = tp / max(tp + fn_count, 1)
    lats.sort()
    n = len(lats)
    return {
        "name": name, "n": total,
        "accuracy": round((tp + tn) / max(total, 1), 4),
        "precision": round(prec, 4),
        "recall": round(rec, 4),
        "f1": round(2 * prec * rec / max(prec + rec, 1e-9), 4),
        "fpr": round(fp / max(fp + tn, 1), 4),
        "tp": tp, "fp": fp, "tn": tn, "fn": fn_count,
        "latency_p50": round(lats[n // 2], 2) if lats else 0,
    }


def main() -> None:
    print("Experiment 7: Comprehensive Multi-Dataset Benchmark\n")

    # ── Load datasets ────────────────────────────────────────────
    print("Loading datasets...")

    # 1. deepset (test)
    ds1 = load_dataset("deepset/prompt-injections", split="test")
    d1_texts = list(ds1["text"])
    d1_labels = list(ds1["label"])

    # 2. jailbreak prompts
    ds2 = load_dataset("rubend18/ChatGPT-Jailbreak-Prompts", split="train")
    d2_texts = [p["Prompt"] for p in ds2 if p["Prompt"]]
    d2_labels = [1] * len(d2_texts)

    # 3. jackhhao jailbreak classification
    ds3 = load_dataset("jackhhao/jailbreak-classification", split="train")
    d3_texts = list(ds3["prompt"])
    d3_labels = [1 if t == "jailbreak" else 0 for t in ds3["type"]]

    # 4. xTRam1 (sample 2000 for speed)
    ds4 = load_dataset("xTRam1/safe-guard-prompt-injection", split="train")
    import random
    rng = random.Random(42)
    indices = rng.sample(range(len(ds4)), min(2000, len(ds4)))
    d4_texts = [ds4[i]["text"] for i in indices]
    d4_labels = [ds4[i]["label"] for i in indices]

    # 5. Lakera mosscap (sample 1000, all are injection attempts)
    ds5 = load_dataset("Lakera/mosscap_prompt_injection", split="train")
    indices5 = rng.sample(range(len(ds5)), 1000)
    d5_texts = [ds5[i]["prompt"] for i in indices5]
    d5_labels = [1] * len(d5_texts)  # all are injection attempts

    datasets = [
        ("deepset_test", d1_texts, d1_labels, f"n={len(d1_texts)}"),
        ("jailbreak_prompts", d2_texts, d2_labels, f"n={len(d2_texts)}, all injection"),
        ("jackhhao_classification", d3_texts, d3_labels,
         f"n={len(d3_texts)}, {sum(d3_labels)} inj / {len(d3_labels)-sum(d3_labels)} safe"),
        ("xTRam1_safeguard", d4_texts, d4_labels,
         f"n={len(d4_texts)} (sampled), {sum(d4_labels)} inj / {len(d4_labels)-sum(d4_labels)} safe"),
        ("lakera_mosscap", d5_texts, d5_labels, f"n={len(d5_texts)}, all injection (CTF)"),
    ]

    for dname, _, _, desc in datasets:
        print(f"  {dname}: {desc}")

    # ── Detectors ────────────────────────────────────────────────
    detectors = [
        ("Regex", PromptInjectionDetector("medium").detect),
        ("InputGuard", InputGuard(injection_sensitivity="medium").check),
        ("Classifier_PT", ClassifierDetector(threshold=0.5).detect),
        ("Classifier_FT", ClassifierDetector(model_name=FT_MODEL, threshold=0.5).detect),
        ("Ensemble_FT", EnsembleDetector(
            detectors=[
                ("regex", PromptInjectionDetector("medium"), 1.0),
                ("compound", CompoundDetector(), 1.0),
                ("clf_ft", ClassifierDetector(model_name=FT_MODEL, threshold=0.5), 1.5),
            ], strategy="any",
        ).detect),
    ]

    # ── Run ──────────────────────────────────────────────────────
    all_results: dict[str, list[dict]] = {}

    for dname, texts, labels, desc in datasets:
        print(f"\n=== {dname} ({desc}) ===")
        results = []
        for det_name, det_fn in detectors:
            print(f"  [{det_name}]...", end=" ", flush=True)
            r = bench(det_name, det_fn, texts, labels)
            results.append(r)
            print(f"Acc={r['accuracy']*100:.1f}% Rec={r['recall']*100:.1f}% "
                  f"F1={r['f1']*100:.1f}% FPR={r['fpr']*100:.1f}%")
        all_results[dname] = results

    # ── Save ─────────────────────────────────────────────────────
    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)
    with open(out_dir / "full_benchmark.json", "w") as f:
        json.dump(all_results, f, indent=2)

    # ── Report ───────────────────────────────────────────────────
    report = ["# Experiment 7: Comprehensive Multi-Dataset Benchmark\n"]
    for dname, results in all_results.items():
        desc = [d for d in datasets if d[0] == dname][0][3]
        report.append(f"\n## {dname} ({desc})\n")
        report.append("| Detector | Acc | Prec | Rec | F1 | FPR | p50 ms |")
        report.append("|----------|-----|------|-----|-----|-----|--------|")
        for r in results:
            report.append(
                f"| {r['name']} | {r['accuracy']*100:.1f}% "
                f"| {r['precision']*100:.1f}% | {r['recall']*100:.1f}% "
                f"| {r['f1']*100:.1f}% | {r['fpr']*100:.1f}% "
                f"| {r['latency_p50']} |"
            )

    # Cross-dataset summary
    report.append("\n## Cross-Dataset Summary (Ensemble+FT)\n")
    report.append("| Dataset | n | Accuracy | Recall | F1 | FPR |")
    report.append("|---------|---|----------|--------|-----|-----|")
    for dname, results in all_results.items():
        ens = [r for r in results if r["name"] == "Ensemble_FT"][0]
        report.append(
            f"| {dname} | {ens['n']} "
            f"| {ens['accuracy']*100:.1f}% | {ens['recall']*100:.1f}% "
            f"| {ens['f1']*100:.1f}% | {ens['fpr']*100:.1f}% |"
        )

    report_text = "\n".join(report)
    with open(out_dir / "exp7_report.md", "w") as f:
        f.write(report_text)

    print(f"\n{report_text}")


if __name__ == "__main__":
    main()
