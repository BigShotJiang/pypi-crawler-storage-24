#!/usr/bin/env python3
"""Experiment 1 — LLM comparison arm.

Evaluates boolean expressions via LLM SDKs (Claude, Gemini, OpenAI)
and compares accuracy to NSPL gates (100% baseline from run.py).

Usage:
    .venv/bin/python experiments/exp1_gate_accuracy/run_llm.py \
        --providers claude gemini openai --n 100 --seed 42
"""

from __future__ import annotations

import argparse
import json
import random
import sys
from pathlib import Path
from typing import Any

# Fix import path
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from experiments.exp1_gate_accuracy.run import expr_to_python, gen_expr
from nspl.llm import LLMClient, LLMResponse


def _format_prompt(py_expr: str, assignment: dict[str, bool]) -> str:
    var_str = ", ".join(f"{k} = {v}" for k, v in sorted(assignment.items()))
    return (
        f"Evaluate this boolean expression and reply with ONLY 'True' or 'False'.\n\n"
        f"Expression: {py_expr}\n"
        f"{var_str}\n\n"
        f"Answer:"
    )


def _parse_answer(text: str) -> bool | None:
    t = text.strip().split("\n")[0].strip().rstrip(".").strip().lower()
    if t in ("true", "yes", "1"):
        return True
    if t in ("false", "no", "0"):
        return False
    if len(t) < 50:
        if "true" in t and "false" not in t:
            return True
        if "false" in t and "true" not in t:
            return False
    return None


def run(providers: list[str], n: int = 100, seed: int = 42) -> dict[str, Any]:
    rng = random.Random(seed)
    var_names = ["A", "B", "C", "D", "E", "F"]
    per_depth = max(n // 5, 1)

    # Generate expressions
    expressions: list[dict[str, Any]] = []
    for depth in range(1, 6):
        for _ in range(per_depth):
            n_vars = min(depth + 1, len(var_names))
            used_vars = var_names[:n_vars]
            assignment = {v: rng.choice([True, False]) for v in used_vars}
            expr = gen_expr(depth, used_vars, rng)
            py_str = expr_to_python(expr)
            ground_truth = bool(eval(py_str, {}, assignment))  # noqa: S307
            expressions.append({
                "depth": depth, "py_expr": py_str,
                "assignment": assignment, "ground_truth": ground_truth,
            })

    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)
    all_results: dict[str, list[dict[str, Any]]] = {}

    for provider in providers:
        print(f"\n  [{provider}] Evaluating {len(expressions)} expressions...")
        client = LLMClient(provider=provider, max_tokens=16, temperature=0.0)
        results: list[dict[str, Any]] = []

        for i, ed in enumerate(expressions):
            prompt = _format_prompt(ed["py_expr"], ed["assignment"])
            resp: LLMResponse = client.query(prompt)
            parsed = _parse_answer(resp.text) if resp.success else None

            results.append({
                "depth": ed["depth"],
                "ground_truth": ed["ground_truth"],
                "llm_answer": parsed,
                "llm_raw": resp.text[:200],
                "correct": parsed == ed["ground_truth"] if parsed is not None else False,
                "parseable": parsed is not None,
                "latency_ms": round(resp.latency_ms, 1),
                "success": resp.success,
                "error": resp.error,
            })

            if (i + 1) % 20 == 0:
                acc = sum(r["correct"] for r in results) / len(results)
                print(f"    {i+1}/{len(expressions)} — acc: {acc*100:.1f}%")

        all_results[provider] = results

        # Save incremental
        with open(out_dir / "llm_comparison.json", "w") as f:
            json.dump(all_results, f, indent=2, default=str)

    # Summary
    summary: dict[str, Any] = {"n": len(expressions), "seed": seed, "providers": {}}
    for prov, pr in all_results.items():
        parseable = [r for r in pr if r["parseable"]]
        lats = sorted(r["latency_ms"] for r in pr if r["success"])
        summary["providers"][prov] = {
            "accuracy": sum(r["correct"] for r in parseable) / max(len(parseable), 1),
            "parse_rate": len(parseable) / len(pr),
            "latency_p50_ms": round(lats[len(lats) // 2], 0) if lats else 0,
            "latency_p95_ms": round(lats[int(len(lats) * 0.95)], 0) if lats else 0,
            "n_correct": sum(r["correct"] for r in pr),
            "n_total": len(pr),
        }

    # Report
    lines = [
        "# Experiment 1: LLM Boolean Evaluation\n",
        f"n={len(expressions)}, seed={seed}\n",
        "| Provider | Accuracy | Parse Rate | p50 | p95 |",
        "|----------|----------|------------|-----|-----|",
        "| NSPL hard | 100.0% | 100% | 0.004ms | 0.017ms |",
        "| NSPL soft | 100.0% | 100% | 0.006ms | 0.028ms |",
    ]
    for prov, s in summary["providers"].items():
        lines.append(
            f"| {prov} | {s['accuracy']*100:.1f}% | {s['parse_rate']*100:.0f}% "
            f"| {s['latency_p50_ms']:.0f}ms | {s['latency_p95_ms']:.0f}ms |"
        )

    report = "\n".join(lines)
    with open(out_dir / "exp1_llm_report.md", "w") as f:
        f.write(report)

    print("\n" + report)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--providers", nargs="+", default=["claude", "gemini"],
                        choices=["claude", "gemini", "openai"])
    parser.add_argument("--n", type=int, default=100)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    run(args.providers, args.n, args.seed)


if __name__ == "__main__":
    main()
