#!/usr/bin/env python3
"""Experiment 1: Logic gate accuracy benchmark.

Generates 10,000 random boolean expressions (depth 1-5), evaluates via:
  - Python eval (ground truth)
  - NSPL hard mode
  - NSPL soft mode

Reports accuracy, mean absolute error, and timing.

Usage:
    python experiments/exp1_gate_accuracy/run.py [--n 10000] [--seed 42]
"""

from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path
from typing import Any

from nspl.core.logic_gates import AND, IMPLIES, NOT, OR, XOR

# ── Expression generation ────────────────────────────────────────────

BINARY_OPS = ["AND", "OR", "XOR", "IMPLIES"]
UNARY_OPS = ["NOT"]


def gen_expr(depth: int, var_names: list[str], rng: random.Random) -> dict[str, Any]:
    """Generate a random boolean expression tree."""
    if depth <= 0 or (depth == 1 and rng.random() < 0.7):
        var = rng.choice(var_names)
        return {"type": "var", "name": var}

    if rng.random() < 0.2:
        child = gen_expr(depth - 1, var_names, rng)
        return {"type": "NOT", "child": child}

    op = rng.choice(BINARY_OPS)
    left = gen_expr(depth - 1, var_names, rng)
    right = gen_expr(depth - 1, var_names, rng)
    return {"type": op, "left": left, "right": right}


def expr_to_python(node: dict[str, Any]) -> str:
    """Convert expression tree to Python boolean expression string."""
    if node["type"] == "var":
        return node["name"]
    if node["type"] == "NOT":
        return f"(not {expr_to_python(node['child'])})"
    left = expr_to_python(node["left"])
    right = expr_to_python(node["right"])
    if node["type"] == "AND":
        return f"({left} and {right})"
    if node["type"] == "OR":
        return f"({left} or {right})"
    if node["type"] == "XOR":
        return f"({left} ^ {right})"
    if node["type"] == "IMPLIES":
        return f"((not {left}) or {right})"
    raise ValueError(f"Unknown op: {node['type']}")


def eval_nspl(node: dict[str, Any], assignment: dict[str, bool], mode: str) -> float:
    """Evaluate expression tree using NSPL gates."""
    if node["type"] == "var":
        v = assignment[node["name"]]
        return 1.0 if v else 0.0
    if node["type"] == "NOT":
        child_val = eval_nspl(node["child"], assignment, mode)
        return NOT(child_val, mode=mode)
    left_val = eval_nspl(node["left"], assignment, mode)
    right_val = eval_nspl(node["right"], assignment, mode)
    if node["type"] == "AND":
        return AND(left_val, right_val, mode=mode)
    if node["type"] == "OR":
        return OR(left_val, right_val, mode=mode)
    if node["type"] == "XOR":
        return XOR(left_val, right_val, mode=mode)
    if node["type"] == "IMPLIES":
        return IMPLIES(left_val, right_val, mode=mode)
    raise ValueError(f"Unknown op: {node['type']}")


# ── Main benchmark ───────────────────────────────────────────────────


def run_benchmark(n: int = 10000, seed: int = 42) -> dict[str, Any]:
    rng = random.Random(seed)
    var_names = ["A", "B", "C", "D", "E", "F"]
    results: list[dict[str, Any]] = []

    for i in range(n):
        depth = (i % 5) + 1  # distribute evenly across depths 1-5
        n_vars = min(depth + 1, len(var_names))
        used_vars = var_names[:n_vars]
        assignment = {v: rng.choice([True, False]) for v in used_vars}

        expr = gen_expr(depth, used_vars, rng)
        py_str = expr_to_python(expr)

        # Ground truth: Python eval
        ground_truth = bool(eval(py_str, {}, assignment))  # noqa: S307

        # NSPL hard mode
        t0 = time.perf_counter()
        nspl_hard = eval_nspl(expr, assignment, "hard")
        t_hard = (time.perf_counter() - t0) * 1000

        # NSPL soft mode
        t0 = time.perf_counter()
        nspl_soft_raw = eval_nspl(expr, assignment, "soft")
        t_soft = (time.perf_counter() - t0) * 1000

        nspl_hard_bool = nspl_hard >= 0.5
        nspl_soft_bool = nspl_soft_raw >= 0.5

        results.append({
            "depth": depth,
            "ground_truth": ground_truth,
            "nspl_hard": nspl_hard_bool,
            "nspl_soft": nspl_soft_bool,
            "nspl_soft_raw": round(nspl_soft_raw, 6),
            "hard_correct": nspl_hard_bool == ground_truth,
            "soft_correct": nspl_soft_bool == ground_truth,
            "hard_ms": round(t_hard, 4),
            "soft_ms": round(t_soft, 4),
        })

    # ── Aggregate metrics ────────────────────────────────────────
    hard_accuracy = sum(r["hard_correct"] for r in results) / n
    soft_accuracy = sum(r["soft_correct"] for r in results) / n

    soft_mae = sum(
        abs(r["nspl_soft_raw"] - (1.0 if r["ground_truth"] else 0.0))
        for r in results
    ) / n

    hard_latencies = [r["hard_ms"] for r in results]
    soft_latencies = [r["soft_ms"] for r in results]

    # By depth
    depth_stats: dict[int, dict[str, float]] = {}
    for d in range(1, 6):
        d_results = [r for r in results if r["depth"] == d]
        if d_results:
            depth_stats[d] = {
                "n": len(d_results),
                "hard_accuracy": sum(r["hard_correct"] for r in d_results) / len(d_results),
                "soft_accuracy": sum(r["soft_correct"] for r in d_results) / len(d_results),
            }

    summary = {
        "n": n,
        "seed": seed,
        "hard_accuracy": round(hard_accuracy, 6),
        "soft_accuracy": round(soft_accuracy, 6),
        "soft_mae": round(soft_mae, 6),
        "hard_latency_p50_ms": round(sorted(hard_latencies)[n // 2], 4),
        "soft_latency_p50_ms": round(sorted(soft_latencies)[n // 2], 4),
        "hard_latency_p95_ms": round(sorted(hard_latencies)[int(n * 0.95)], 4),
        "soft_latency_p95_ms": round(sorted(soft_latencies)[int(n * 0.95)], 4),
        "by_depth": depth_stats,
    }

    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Experiment 1: Gate accuracy")
    parser.add_argument("--n", type=int, default=10000)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    print(f"Running gate accuracy benchmark: n={args.n}, seed={args.seed}")
    summary = run_benchmark(args.n, args.seed)

    # Save results
    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)

    with open(out_dir / "gate_accuracy.json", "w") as f:
        json.dump(summary, f, indent=2)

    # Generate report
    report = f"""# Experiment 1: Logic Gate Accuracy

## Configuration
- Expressions: {summary['n']}
- Random seed: {summary['seed']}
- Depth range: 1-5
- Variables: A-F

## Results

| Method | Accuracy | Latency (p50) | Latency (p95) |
|--------|----------|---------------|---------------|
| Python eval | 100.000% | <0.001ms | <0.001ms |
| NSPL hard | {summary['hard_accuracy']*100:.3f}% | {summary['hard_latency_p50_ms']}ms | {summary['hard_latency_p95_ms']}ms |
| NSPL soft | {summary['soft_accuracy']*100:.3f}% | {summary['soft_latency_p50_ms']}ms | {summary['soft_latency_p95_ms']}ms |

Soft mode MAE: {summary['soft_mae']:.6f}

## Accuracy by Depth

| Depth | Hard | Soft |
|-------|------|------|
"""
    for d in range(1, 6):
        ds = summary["by_depth"].get(d, {})
        report += f"| {d} | {ds.get('hard_accuracy', 0)*100:.1f}% | {ds.get('soft_accuracy', 0)*100:.1f}% |\n"

    with open(out_dir / "exp1_report.md", "w") as f:
        f.write(report)

    # Print summary
    print(f"\nHard mode accuracy: {summary['hard_accuracy']*100:.3f}%")
    print(f"Soft mode accuracy: {summary['soft_accuracy']*100:.3f}%")
    print(f"Soft mode MAE:      {summary['soft_mae']:.6f}")
    print(f"\nResults saved to {out_dir}")


if __name__ == "__main__":
    main()
