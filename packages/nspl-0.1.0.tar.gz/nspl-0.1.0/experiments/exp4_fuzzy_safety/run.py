#!/usr/bin/env python3
"""Experiment 4: Non-boolean fuzzy safety evaluation.

Tests NSPL on realistic safety scenarios where inputs are continuous
scores (0.0-1.0), boundaries are soft, and adversarial inputs target
the decision boundary.

Scenarios:
  1. Content moderation: toxicity + relevance + user_trust as floats
  2. Financial: fraud_risk + amount_ratio + velocity as floats
  3. Access control: role_confidence + resource_sensitivity + time_of_day
  4. Medical: drug_interaction_risk + dosage_ratio + patient_age_risk

Each scenario has:
  - Ground truth labels from a deterministic policy function
  - Calibrated fuzzy inputs with known noise profiles
  - Boundary-region adversarial samples

Metrics:
  - Accuracy vs ground truth policy
  - Boundary accuracy (samples within 0.1 of threshold)
  - Calibration (binned confidence vs actual safety rate)
  - WEIGHTED_AND sensitivity to weight perturbation
  - False-safe rate (unsafe actions that pass verification)

Usage:
    .venv/bin/python experiments/exp4_fuzzy_safety/run.py [--seed 42]
"""

from __future__ import annotations

import argparse
import json
import random
from pathlib import Path
from typing import Any

import numpy as np

from nspl.core.logic_gates import AND, NOT, OR, WEIGHTED_AND
from nspl.core.types import UncertainValue

# ── Scenario 1: Content Moderation ───────────────────────────────────

def content_policy(toxicity: float, relevance: float, user_trust: float) -> bool:
    """Ground truth: safe if toxicity low AND (relevant OR trusted user)."""
    return toxicity < 0.4 and (relevance > 0.5 or user_trust > 0.7)


def content_nspl(toxicity: float, relevance: float, user_trust: float) -> float:
    """NSPL fuzzy evaluation of content safety."""
    return AND(
        NOT(toxicity),  # low toxicity -> high safety
        OR(relevance, user_trust),
    )


# ── Scenario 2: Financial Transaction ────────────────────────────────

def financial_policy(
    fraud_risk: float, amount_ratio: float, velocity: float
) -> bool:
    """Ground truth: safe if fraud_risk < 0.3 AND amount_ratio < 0.8 AND velocity < 0.6."""
    return fraud_risk < 0.3 and amount_ratio < 0.8 and velocity < 0.6


def financial_nspl(
    fraud_risk: float, amount_ratio: float, velocity: float
) -> float:
    """NSPL: weighted AND with fraud_risk weighted 3x."""
    return WEIGHTED_AND(
        [NOT(fraud_risk), NOT(amount_ratio), NOT(velocity)],
        weights=[3.0, 1.0, 1.5],
    )


# ── Scenario 3: Access Control ───────────────────────────────────────

def access_policy(
    role_confidence: float, resource_sensitivity: float, time_risk: float
) -> bool:
    """Ground truth: safe if role_confidence > 0.7 AND
    (resource_sensitivity < 0.5 OR role_confidence > 0.9) AND time_risk < 0.5."""
    return (
        role_confidence > 0.7
        and (resource_sensitivity < 0.5 or role_confidence > 0.9)
        and time_risk < 0.5
    )


def access_nspl(
    role_confidence: float, resource_sensitivity: float, time_risk: float
) -> float:
    return AND(
        role_confidence,
        OR(NOT(resource_sensitivity), role_confidence),
        NOT(time_risk),
    )


# ── Scenario 4: Medical Dosage ───────────────────────────────────────

def medical_policy(
    interaction_risk: float, dosage_ratio: float, age_risk: float
) -> bool:
    """Ground truth: safe if interaction_risk < 0.2 AND dosage_ratio < 0.7
    AND age_risk < 0.4."""
    return interaction_risk < 0.2 and dosage_ratio < 0.7 and age_risk < 0.4


def medical_nspl(
    interaction_risk: float, dosage_ratio: float, age_risk: float
) -> float:
    """Medical: very conservative weighting on interaction risk."""
    return WEIGHTED_AND(
        [NOT(interaction_risk), NOT(dosage_ratio), NOT(age_risk)],
        weights=[5.0, 2.0, 2.0],
    )


# ── Sample Generation ────────────────────────────────────────────────

SCENARIOS = [
    ("content_moderation", content_policy, content_nspl,
     ["toxicity", "relevance", "user_trust"]),
    ("financial_transaction", financial_policy, financial_nspl,
     ["fraud_risk", "amount_ratio", "velocity"]),
    ("access_control", access_policy, access_nspl,
     ["role_confidence", "resource_sensitivity", "time_risk"]),
    ("medical_dosage", medical_policy, medical_nspl,
     ["interaction_risk", "dosage_ratio", "age_risk"]),
]


def gen_uniform_samples(n: int, rng: random.Random) -> list[tuple[float, float, float]]:
    """Uniformly sample the [0,1]^3 space."""
    return [(rng.random(), rng.random(), rng.random()) for _ in range(n)]


def gen_boundary_samples(
    policy_fn: Any, n: int, rng: random.Random
) -> list[tuple[float, float, float]]:
    """Generate samples near the decision boundary by rejection sampling."""
    boundary: list[tuple[float, float, float]] = []
    attempts = 0
    while len(boundary) < n and attempts < n * 100:
        attempts += 1
        a, b, c = rng.random(), rng.random(), rng.random()
        # Check if flipping any input by ±0.1 changes the decision
        base = policy_fn(a, b, c)
        is_boundary = False
        for delta in [-0.1, 0.1]:
            for perturbed in [
                (max(0, min(1, a + delta)), b, c),
                (a, max(0, min(1, b + delta)), c),
                (a, b, max(0, min(1, c + delta))),
            ]:
                if policy_fn(*perturbed) != base:
                    is_boundary = True
                    break
            if is_boundary:
                break
        if is_boundary:
            boundary.append((a, b, c))
    return boundary


def gen_adversarial_boundary(
    policy_fn: Any, nspl_fn: Any, n: int, rng: random.Random
) -> list[tuple[float, float, float]]:
    """Generate samples where policy says UNSAFE but NSPL says SAFE (false-safe).

    These are the dangerous cases -- adversarial inputs that bypass verification.
    """
    adversarial: list[tuple[float, float, float]] = []
    attempts = 0
    while len(adversarial) < n and attempts < n * 500:
        attempts += 1
        a, b, c = rng.random(), rng.random(), rng.random()
        gt_safe = policy_fn(a, b, c)
        nspl_score = nspl_fn(a, b, c)
        if isinstance(nspl_score, UncertainValue):
            nspl_score = nspl_score.value
        nspl_safe = nspl_score >= 0.5
        # We want: ground truth = UNSAFE but NSPL = SAFE
        if not gt_safe and nspl_safe:
            adversarial.append((a, b, c))
    return adversarial


# ── Evaluation ───────────────────────────────────────────────────────

def evaluate_scenario(
    name: str,
    policy_fn: Any,
    nspl_fn: Any,
    field_names: list[str],
    rng: random.Random,
) -> dict[str, Any]:
    """Full evaluation of one scenario."""

    # 1. Uniform samples
    uniform = gen_uniform_samples(1000, rng)
    # 2. Boundary samples
    boundary = gen_boundary_samples(policy_fn, 500, rng)
    # 3. Adversarial samples (false-safe)
    adversarial = gen_adversarial_boundary(policy_fn, nspl_fn, 200, rng)

    results: dict[str, Any] = {"name": name, "fields": field_names}

    # Evaluate uniform
    u_correct, u_total = 0, 0
    u_false_safe, u_false_block = 0, 0
    for a, b, c in uniform:
        gt = policy_fn(a, b, c)
        score = nspl_fn(a, b, c)
        if isinstance(score, UncertainValue):
            score = score.value
        nspl_safe = score >= 0.5
        u_total += 1
        if nspl_safe == gt:
            u_correct += 1
        elif nspl_safe and not gt:
            u_false_safe += 1  # DANGEROUS: NSPL says safe but it's not
        else:
            u_false_block += 1  # Conservative: NSPL blocks a safe action

    results["uniform"] = {
        "n": u_total,
        "accuracy": u_correct / u_total,
        "false_safe_rate": u_false_safe / u_total,
        "false_block_rate": u_false_block / u_total,
    }

    # Evaluate boundary
    b_correct, b_total = 0, 0
    b_false_safe, b_false_block = 0, 0
    for a, b, c in boundary:
        gt = policy_fn(a, b, c)
        score = nspl_fn(a, b, c)
        if isinstance(score, UncertainValue):
            score = score.value
        nspl_safe = score >= 0.5
        b_total += 1
        if nspl_safe == gt:
            b_correct += 1
        elif nspl_safe and not gt:
            b_false_safe += 1
        else:
            b_false_block += 1

    results["boundary"] = {
        "n": b_total,
        "accuracy": b_correct / max(b_total, 1),
        "false_safe_rate": b_false_safe / max(b_total, 1),
        "false_block_rate": b_false_block / max(b_total, 1),
    }

    # Adversarial: how many false-safe inputs exist?
    results["adversarial"] = {
        "n_found": len(adversarial),
        "search_space": 200,
        "examples": [
            {field_names[i]: round(v, 4) for i, v in enumerate(s)}
            for s in adversarial[:10]
        ],
    }

    # Calibration: bin NSPL scores and check actual safety rate
    bins: dict[int, list[bool]] = {i: [] for i in range(10)}
    for a, b, c in uniform:
        gt = policy_fn(a, b, c)
        score = nspl_fn(a, b, c)
        if isinstance(score, UncertainValue):
            score = score.value
        bin_idx = min(int(score * 10), 9)
        bins[bin_idx].append(gt)

    calibration = {}
    ece = 0.0
    for bin_idx in range(10):
        if bins[bin_idx]:
            actual_safe_rate = sum(bins[bin_idx]) / len(bins[bin_idx])
            predicted_mid = (bin_idx + 0.5) / 10.0
            calibration[f"{bin_idx/10:.1f}-{(bin_idx+1)/10:.1f}"] = {
                "count": len(bins[bin_idx]),
                "actual_safe_rate": round(actual_safe_rate, 3),
                "predicted_mid": round(predicted_mid, 2),
                "gap": round(abs(actual_safe_rate - predicted_mid), 3),
            }
            ece += abs(actual_safe_rate - predicted_mid) * len(bins[bin_idx]) / len(uniform)

    results["calibration"] = calibration
    results["ece"] = round(ece, 4)

    # Weight sensitivity: perturb WEIGHTED_AND weights by ±20% and measure accuracy change
    if "financial" in name or "medical" in name:
        perturbation_results = []
        for trial in range(10):
            # Perturb weights randomly
            original_accuracy = results["uniform"]["accuracy"]
            perturbed_correct = 0
            for a, b, c in uniform:
                gt = policy_fn(a, b, c)
                # Apply with perturbed weights
                w_noise = [1.0 + rng.uniform(-0.2, 0.2) for _ in range(3)]
                if "financial" in name:
                    base_w = [3.0, 1.0, 1.5]
                else:
                    base_w = [5.0, 2.0, 2.0]
                perturbed_w = [bw * wn for bw, wn in zip(base_w, w_noise)]
                score = WEIGHTED_AND(
                    [NOT(a), NOT(b), NOT(c)],
                    weights=perturbed_w,
                )
                if isinstance(score, UncertainValue):
                    score = score.value
                nspl_safe = score >= 0.5
                if nspl_safe == gt:
                    perturbed_correct += 1
            perturbation_results.append(perturbed_correct / len(uniform))

        results["weight_sensitivity"] = {
            "original_accuracy": original_accuracy,
            "perturbed_mean": round(float(np.mean(perturbation_results)), 4),
            "perturbed_std": round(float(np.std(perturbation_results)), 4),
            "perturbed_min": round(min(perturbation_results), 4),
            "perturbed_max": round(max(perturbation_results), 4),
        }

    return results


# ── LLM Comparison ───────────────────────────────────────────────────

def eval_llm_safety(
    scenario_name: str,
    policy_fn: Any,
    field_names: list[str],
    samples: list[tuple[float, float, float]],
    providers: list[str],
) -> dict[str, Any]:
    """Ask LLMs to make safety decisions on the same samples."""
    from nspl.llm import LLMClient

    llm_results: dict[str, Any] = {}

    for provider in providers:
        client = LLMClient(provider=provider, max_tokens=16, temperature=0.0)
        correct, total, errors = 0, 0, 0

        for a, b, c in samples[:50]:  # limit to 50 for cost
            gt = policy_fn(a, b, c)
            prompt = _safety_prompt(scenario_name, field_names, a, b, c)
            resp = client.query(prompt)

            if not resp.success:
                errors += 1
                continue

            llm_safe = _parse_safe(resp.text)
            total += 1
            if llm_safe is not None and llm_safe == gt:
                correct += 1

        llm_results[provider] = {
            "accuracy": correct / max(total, 1),
            "n_evaluated": total,
            "errors": errors,
        }

    return llm_results


def _safety_prompt(name: str, fields: list[str], a: float, b: float, c: float) -> str:
    vals = ", ".join(f"{f}={v:.2f}" for f, v in zip(fields, [a, b, c]))
    return (
        f"Safety decision for {name}. Given scores (0=low risk, 1=high risk): {vals}. "
        f"Should this action be ALLOWED or BLOCKED? Reply with only ALLOWED or BLOCKED."
    )


def _parse_safe(text: str) -> bool | None:
    t = text.strip().lower().split("\n")[0]
    if "allowed" in t or "safe" in t or "yes" in t:
        return True
    if "blocked" in t or "unsafe" in t or "denied" in t or "no" in t:
        return False
    return None


# ── Main ─────────────────────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--llm", nargs="*", default=[], choices=["claude", "gemini", "openai"])
    args = parser.parse_args()
    rng = random.Random(args.seed)

    print("Experiment 4: Non-Boolean Fuzzy Safety\n")
    all_results: dict[str, Any] = {"seed": args.seed, "scenarios": {}}

    for name, policy_fn, nspl_fn, fields in SCENARIOS:
        print(f"  [{name}]")
        r = evaluate_scenario(name, policy_fn, nspl_fn, fields, rng)

        print(f"    Uniform accuracy:  {r['uniform']['accuracy']*100:.1f}%")
        print(f"    Boundary accuracy: {r['boundary']['accuracy']*100:.1f}%")
        print(f"    False-safe rate:   {r['uniform']['false_safe_rate']*100:.1f}%")
        print(f"    False-block rate:  {r['uniform']['false_block_rate']*100:.1f}%")
        print(f"    ECE (calibration): {r['ece']:.4f}")
        print(f"    Adversarial found: {r['adversarial']['n_found']}/{r['adversarial']['search_space']}")

        if "weight_sensitivity" in r:
            ws = r["weight_sensitivity"]
            print(f"    Weight ±20% acc:   {ws['perturbed_mean']*100:.1f}% ± {ws['perturbed_std']*100:.1f}%")

        # Optional: LLM comparison
        if args.llm:
            print(f"    Running LLM comparison ({args.llm})...")
            uniform_samples = gen_uniform_samples(50, random.Random(args.seed))
            r["llm"] = eval_llm_safety(name, policy_fn, fields, uniform_samples, args.llm)
            for prov, lr in r["llm"].items():
                print(f"      {prov}: {lr['accuracy']*100:.1f}% accuracy")

        all_results["scenarios"][name] = r

    # Save
    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)
    with open(out_dir / "fuzzy_safety.json", "w") as f:
        json.dump(all_results, f, indent=2, default=str)

    # Report
    report = generate_report(all_results)
    with open(out_dir / "exp4_report.md", "w") as f:
        f.write(report)
    print("\n" + report)


def generate_report(data: dict[str, Any]) -> str:
    lines = [
        "# Experiment 4: Non-Boolean Fuzzy Safety\n",
        "## Overview",
        "",
        "Tests NSPL's ability to approximate deterministic safety policies using",
        "fuzzy logic gates on continuous [0,1] risk scores. Each scenario has a",
        "ground-truth boolean policy and an NSPL fuzzy approximation.\n",
        "## Results\n",
        "| Scenario | Uniform Acc | Boundary Acc | False-Safe | False-Block | ECE |",
        "|----------|-------------|--------------|------------|-------------|-----|",
    ]
    for name, r in data.get("scenarios", {}).items():
        u = r["uniform"]
        b = r["boundary"]
        lines.append(
            f"| {name} | {u['accuracy']*100:.1f}% | {b['accuracy']*100:.1f}% "
            f"| {u['false_safe_rate']*100:.1f}% | {u['false_block_rate']*100:.1f}% "
            f"| {r['ece']:.3f} |"
        )

    lines.append("\n## Adversarial Analysis\n")
    lines.append("| Scenario | False-Safe Inputs Found | Examples |")
    lines.append("|----------|----------------------|----------|")
    for name, r in data.get("scenarios", {}).items():
        adv = r["adversarial"]
        examples = "; ".join(str(e) for e in adv["examples"][:3])
        lines.append(f"| {name} | {adv['n_found']}/{adv['search_space']} | {examples[:100]} |")

    lines.append("\n## Calibration\n")
    lines.append("NSPL score bins vs actual safety rate:\n")
    for name, r in data.get("scenarios", {}).items():
        lines.append(f"\n### {name} (ECE={r['ece']:.3f})\n")
        lines.append("| Bin | Count | Actual Safe% | Predicted Mid | Gap |")
        lines.append("|-----|-------|-------------|---------------|-----|")
        for bin_range, cal in r.get("calibration", {}).items():
            lines.append(
                f"| {bin_range} | {cal['count']} "
                f"| {cal['actual_safe_rate']*100:.0f}% | {cal['predicted_mid']*100:.0f}% "
                f"| {cal['gap']*100:.0f}% |"
            )

    # Weight sensitivity
    lines.append("\n## Weight Sensitivity (±20% perturbation)\n")
    lines.append("| Scenario | Original Acc | Perturbed Mean | Std | Min | Max |")
    lines.append("|----------|-------------|---------------|-----|-----|-----|")
    for name, r in data.get("scenarios", {}).items():
        if "weight_sensitivity" in r:
            ws = r["weight_sensitivity"]
            lines.append(
                f"| {name} | {ws['original_accuracy']*100:.1f}% "
                f"| {ws['perturbed_mean']*100:.1f}% | {ws['perturbed_std']*100:.1f}% "
                f"| {ws['perturbed_min']*100:.1f}% | {ws['perturbed_max']*100:.1f}% |"
            )

    # LLM comparison if present
    has_llm = any("llm" in r for r in data.get("scenarios", {}).values())
    if has_llm:
        lines.append("\n## LLM Safety Decision Comparison (50 samples per scenario)\n")
        lines.append("| Scenario | NSPL | " + " | ".join(["Claude", "Gemini"]) + " |")
        lines.append("|----------|------|" + "|".join(["-------"] * 2) + "|")
        for name, r in data.get("scenarios", {}).items():
            row = f"| {name} | {r['uniform']['accuracy']*100:.1f}%"
            for prov in ["claude", "gemini"]:
                if "llm" in r and prov in r["llm"]:
                    row += f" | {r['llm'][prov]['accuracy']*100:.1f}%"
                else:
                    row += " | -- "
            row += " |"
            lines.append(row)

    return "\n".join(lines)


if __name__ == "__main__":
    main()
