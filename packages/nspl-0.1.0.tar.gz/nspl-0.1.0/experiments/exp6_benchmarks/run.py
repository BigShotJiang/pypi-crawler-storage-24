#!/usr/bin/env python3
"""Experiment 6: Standard benchmark evaluation.

Tests NSPL detectors against published prompt injection datasets:
  1. deepset/prompt-injections (662 samples: 546 train + 116 test)
  2. rubend18/ChatGPT-Jailbreak-Prompts (79 jailbreak prompts)

Reports: accuracy, precision, recall, F1, FPR on held-out test set.

Usage:
    .venv/bin/python experiments/exp6_benchmarks/run.py
"""

from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any

from datasets import load_dataset

from nspl.guards.classifier import ClassifierDetector
from nspl.guards.compound import CompoundDetector
from nspl.guards.detectors import PromptInjectionDetector
from nspl.guards.input_guard import InputGuard


def _is_triggered(r: object) -> bool:
    if hasattr(r, "triggered"):
        return r.triggered  # type: ignore[union-attr]
    if hasattr(r, "allowed"):
        return not r.allowed  # type: ignore[union-attr]
    return False


def benchmark(
    name: str,
    detect_fn: Any,
    texts: list[str],
    labels: list[int],
) -> dict[str, Any]:
    """Run a detector against labeled data. label=1 means injection."""
    tp, fp, tn, fn = 0, 0, 0, 0
    latencies: list[float] = []

    for text, label in zip(texts, labels):
        t0 = time.perf_counter()
        r = detect_fn(text)
        latencies.append((time.perf_counter() - t0) * 1000)

        predicted = _is_triggered(r)
        actual = label == 1

        if predicted and actual:
            tp += 1
        elif predicted and not actual:
            fp += 1
        elif not predicted and actual:
            fn += 1
        else:
            tn += 1

    total = tp + fp + tn + fn
    latencies.sort()
    n = len(latencies)

    precision = tp / max(tp + fp, 1)
    recall = tp / max(tp + fn, 1)

    return {
        "name": name,
        "tp": tp, "fp": fp, "tn": tn, "fn": fn,
        "accuracy": round((tp + tn) / max(total, 1), 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
        "f1": round(2 * precision * recall / max(precision + recall, 1e-9), 4),
        "fpr": round(fp / max(fp + tn, 1), 4),
        "latency_p50_ms": round(latencies[n // 2], 2) if latencies else 0,
        "latency_p95_ms": round(latencies[int(n * 0.95)], 2) if latencies else 0,
        "n_total": total,
    }


def main() -> None:
    print("Experiment 6: Standard Benchmark Evaluation\n")

    # ── Load datasets ────────────────────────────────────────────
    print("Loading datasets...")
    ds_test = load_dataset("deepset/prompt-injections", split="test")
    ds_train = load_dataset("deepset/prompt-injections", split="train")
    jailbreaks = load_dataset("rubend18/ChatGPT-Jailbreak-Prompts", split="train")

    # deepset test set
    test_texts = ds_test["text"]
    test_labels = ds_test["label"]
    print(f"  deepset test: {len(test_texts)} samples "
          f"({sum(test_labels)} injections, {len(test_labels) - sum(test_labels)} safe)")

    # Full deepset (train + test)
    full_texts = list(ds_train["text"]) + list(ds_test["text"])
    full_labels = list(ds_train["label"]) + list(ds_test["label"])
    print(f"  deepset full: {len(full_texts)} samples")

    # Jailbreaks (all are injections, label=1)
    jb_texts = [p["Prompt"] for p in jailbreaks if p["Prompt"]]
    jb_labels = [1] * len(jb_texts)
    print(f"  jailbreaks: {len(jb_texts)} prompts (all injection)\n")

    # ── Define detectors ─────────────────────────────────────────
    from nspl.guards.ensemble import EnsembleDetector

    ft_model = str(Path(__file__).parent / "finetuned_model")

    detectors = [
        ("Regex (medium)", PromptInjectionDetector("medium").detect),
        ("InputGuard (full)", InputGuard(injection_sensitivity="medium").check),
        ("Classifier (pretrained)", ClassifierDetector(threshold=0.5).detect),
        ("Classifier (finetuned)", ClassifierDetector(
            model_name=ft_model, threshold=0.5,
        ).detect),
        ("Ensemble (any)", EnsembleDetector.default(enable_classifier=True).detect),
        ("Ensemble+FT", EnsembleDetector(
            detectors=[
                ("regex", PromptInjectionDetector("medium"), 1.0),
                ("compound", CompoundDetector(), 1.0),
                ("classifier_ft", ClassifierDetector(
                    model_name=ft_model, threshold=0.5,
                ), 1.5),
            ],
            strategy="any",
        ).detect),
    ]

    # ── Run on deepset test set ──────────────────────────────────
    print("=== deepset/prompt-injections (test set, n=116) ===\n")
    test_results = []
    for name, fn in detectors:
        print(f"  [{name}]...", end=" ", flush=True)
        r = benchmark(name, fn, test_texts, test_labels)
        test_results.append(r)
        print(f"Acc={r['accuracy']*100:.1f}% F1={r['f1']*100:.1f}% "
              f"Rec={r['recall']*100:.1f}% FPR={r['fpr']*100:.1f}%")

    # ── Run on full deepset ──────────────────────────────────────
    print(f"\n=== deepset/prompt-injections (full, n={len(full_texts)}) ===\n")
    full_results = []
    for name, fn in detectors:
        print(f"  [{name}]...", end=" ", flush=True)
        r = benchmark(name, fn, full_texts, full_labels)
        full_results.append(r)
        print(f"Acc={r['accuracy']*100:.1f}% F1={r['f1']*100:.1f}% "
              f"Rec={r['recall']*100:.1f}% FPR={r['fpr']*100:.1f}%")

    # ── Run on jailbreaks (recall-only, all are injections) ──────
    print(f"\n=== Jailbreak Prompts (n={len(jb_texts)}, recall only) ===\n")
    jb_results = []
    for name, fn in detectors:
        print(f"  [{name}]...", end=" ", flush=True)
        r = benchmark(name, fn, jb_texts, jb_labels)
        jb_results.append(r)
        print(f"Recall={r['recall']*100:.1f}% ({r['tp']}/{r['tp']+r['fn']} caught)")

    # ── Save results ─────────────────────────────────────────────
    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)

    all_data = {
        "deepset_test": test_results,
        "deepset_full": full_results,
        "jailbreaks": jb_results,
    }
    with open(out_dir / "benchmark_results.json", "w") as f:
        json.dump(all_data, f, indent=2)

    # ── Generate report ──────────────────────────────────────────
    report = [
        "# Experiment 6: Standard Benchmark Results\n",
        "## Datasets",
        f"- **deepset/prompt-injections** test: {len(test_texts)} samples",
        f"- **deepset/prompt-injections** full: {len(full_texts)} samples",
        f"- **rubend18/ChatGPT-Jailbreak-Prompts**: {len(jb_texts)} prompts\n",
    ]

    for section, results, desc in [
        ("deepset test (n=116)", test_results, "Held-out test set"),
        (f"deepset full (n={len(full_texts)})", full_results, "Train + test"),
        (f"Jailbreak recall (n={len(jb_texts)})", jb_results, "All injections"),
    ]:
        report.append(f"\n## {section}\n{desc}\n")
        report.append("| Detector | Acc | Prec | Rec | F1 | FPR | p50 ms |")
        report.append("|----------|-----|------|-----|-----|-----|--------|")
        for r in results:
            report.append(
                f"| {r['name']} | {r['accuracy']*100:.1f}% "
                f"| {r['precision']*100:.1f}% | {r['recall']*100:.1f}% "
                f"| {r['f1']*100:.1f}% | {r['fpr']*100:.1f}% "
                f"| {r['latency_p50_ms']} |"
            )

    report_text = "\n".join(report)
    with open(out_dir / "exp6_report.md", "w") as f:
        f.write(report_text)

    print(f"\n{report_text}")
    print(f"\nSaved to {out_dir}")


if __name__ == "__main__":
    main()
