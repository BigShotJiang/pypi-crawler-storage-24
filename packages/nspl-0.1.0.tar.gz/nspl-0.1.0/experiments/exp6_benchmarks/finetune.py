#!/usr/bin/env python3
"""Fine-tune the prompt injection classifier on deepset/prompt-injections.

Takes the pretrained protectai/deberta-v3-base-prompt-injection-v2 and
fine-tunes it on the deepset train split (546 samples) for 3 epochs.

Saves the fine-tuned model to experiments/exp6_benchmarks/finetuned_model/

Usage:
    .venv/bin/python experiments/exp6_benchmarks/finetune.py
"""

from __future__ import annotations

from pathlib import Path

from datasets import load_dataset
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    Trainer,
    TrainingArguments,
)


def main() -> None:
    model_name = "protectai/deberta-v3-base-prompt-injection-v2"
    output_dir = Path(__file__).parent / "finetuned_model"
    output_dir.mkdir(exist_ok=True)

    print("Loading dataset...")
    ds = load_dataset("deepset/prompt-injections")
    train_ds = ds["train"]
    test_ds = ds["test"]
    print(f"  Train: {len(train_ds)}, Test: {len(test_ds)}")

    print(f"Loading model: {model_name}")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name, num_labels=2,
    )

    def tokenize(examples: dict) -> dict:
        return tokenizer(
            examples["text"], truncation=True, padding="max_length", max_length=512,
        )

    print("Tokenizing...")
    train_tok = train_ds.map(tokenize, batched=True)
    test_tok = test_ds.map(tokenize, batched=True)

    # Set format for pytorch
    train_tok.set_format("torch", columns=["input_ids", "attention_mask", "label"])
    test_tok.set_format("torch", columns=["input_ids", "attention_mask", "label"])

    training_args = TrainingArguments(
        output_dir=str(output_dir / "checkpoints"),
        num_train_epochs=3,
        per_device_train_batch_size=16,
        per_device_eval_batch_size=32,
        eval_strategy="epoch",
        save_strategy="epoch",
        learning_rate=2e-5,
        weight_decay=0.01,
        load_best_model_at_end=True,
        metric_for_best_model="eval_loss",
        seed=42,
        logging_steps=10,
        report_to="none",
    )

    def compute_metrics(eval_pred: tuple) -> dict:
        import numpy as np
        logits, labels = eval_pred
        preds = np.argmax(logits, axis=-1)
        tp = int(((preds == 1) & (labels == 1)).sum())
        fp = int(((preds == 1) & (labels == 0)).sum())
        fn = int(((preds == 0) & (labels == 1)).sum())
        tn = int(((preds == 0) & (labels == 0)).sum())
        precision = tp / max(tp + fp, 1)
        recall = tp / max(tp + fn, 1)
        f1 = 2 * precision * recall / max(precision + recall, 1e-9)
        return {
            "accuracy": (tp + tn) / max(tp + fp + tn + fn, 1),
            "precision": precision,
            "recall": recall,
            "f1": f1,
        }

    print("Training...")
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=train_tok,
        eval_dataset=test_tok,
        compute_metrics=compute_metrics,
    )
    trainer.train()

    # Evaluate
    print("\nEval on test set:")
    metrics = trainer.evaluate()
    for k, v in metrics.items():
        if isinstance(v, float):
            print(f"  {k}: {v:.4f}")

    # Save
    print(f"\nSaving to {output_dir}")
    model.save_pretrained(str(output_dir))
    tokenizer.save_pretrained(str(output_dir))

    # Save metrics
    import json
    with open(output_dir / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=2)

    print("Done.")


if __name__ == "__main__":
    main()
