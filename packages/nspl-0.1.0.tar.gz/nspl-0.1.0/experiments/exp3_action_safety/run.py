#!/usr/bin/env python3
"""Experiment 3: Action safety catch rate.

Defines 10 action classes with known safety boundaries.
Generates 1000 invocations (500 valid, 500 adversarial).
Measures TPR, FPR, and latency.

Usage:
    python experiments/exp3_action_safety/run.py [--seed 42]
"""

from __future__ import annotations

import argparse
import json
import random
import time
from pathlib import Path
from typing import Any

from nspl.actions import action, postconditions, preconditions, safety_checks
from nspl.core.logic_gates import AND

# ── Action definitions with known safety boundaries ──────────────────


class MockCtx:
    """Mock context with configurable service responses."""

    def __init__(self, config: dict[str, Any]) -> None:
        self._config = config

    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            return super().__getattribute__(name)
        val = self._config.get(name)
        if val is not None:
            if callable(val):
                return val
            return lambda *a, **kw: val
        return lambda *a, **kw: True


def _make_action(
    name: str,
    precondition_fields: list[str],
    safety_fields: list[str],
) -> type:
    """Factory: creates an @action class with configurable checks."""

    @action
    class DynamicAction:
        def __init__(self, **kwargs: Any) -> None:
            self.params = kwargs
            self.__class__.__name__ = name

        @preconditions
        def check(self, ctx: MockCtx) -> float:
            values = [float(ctx.__getattr__(f)()) for f in precondition_fields]
            if not values:
                return 1.0
            return AND(*values, mode="hard")

        @safety_checks
        def safety(self, ctx: MockCtx) -> float:
            values = [float(ctx.__getattr__(f)()) for f in safety_fields]
            if not values:
                return 1.0
            return AND(*values, mode="hard")

        def execute(self, ctx: MockCtx) -> dict[str, Any]:
            return {"executed": True, "action": name}

        @postconditions
        def verify(self, ctx: MockCtx, result: dict[str, Any]) -> bool:
            return result.get("executed", False)

    DynamicAction.__name__ = name
    DynamicAction.__qualname__ = name
    return DynamicAction


# 10 action classes with different check profiles
ACTION_SPECS = [
    ("ProcessRefund", ["order_exists", "owns_order"], ["under_limit", "no_fraud"]),
    ("SendEmail", ["valid_recipient", "has_content"], ["not_spam", "rate_ok"]),
    ("DeleteRecord", ["record_exists", "is_owner"], ["is_admin", "has_backup"]),
    ("TransferFunds", ["account_exists", "has_balance"], ["under_limit", "dest_valid"]),
    ("UpdatePermissions", ["user_exists", "valid_perms"], ["is_admin", "no_self_escalate"]),
    ("CreateAccount", ["unique_email", "valid_data"], ["rate_ok", "not_banned"]),
    ("CancelOrder", ["order_exists", "is_cancelable"], ["is_owner", "within_window"]),
    ("ExportData", ["data_exists", "authorized"], ["classification_ok", "audit_logged"]),
    ("ScheduleAction", ["valid_time", "no_conflicts"], ["has_permission", "within_quota"]),
    ("ModifyConfig", ["config_exists", "valid_values"], ["is_admin", "rollback_available"]),
]

ACTIONS = [_make_action(name, pre, safe) for name, pre, safe in ACTION_SPECS]


# ── Test case generation ─────────────────────────────────────────────


def gen_valid_ctx(spec: tuple[str, list[str], list[str]], rng: random.Random) -> MockCtx:
    """Generate a context where all checks pass."""
    _, pre_fields, safety_fields = spec
    config: dict[str, Any] = {}
    for f in pre_fields + safety_fields:
        config[f] = True
    return MockCtx(config)


def gen_adversarial_ctx(
    spec: tuple[str, list[str], list[str]], rng: random.Random
) -> tuple[MockCtx, str]:
    """Generate a context where exactly ONE check fails. Returns (ctx, which_field_fails)."""
    _, pre_fields, safety_fields = spec
    all_fields = pre_fields + safety_fields
    fail_field = rng.choice(all_fields)

    config: dict[str, Any] = {}
    for f in all_fields:
        config[f] = f != fail_field
    return MockCtx(config), fail_field


# ── Benchmark ────────────────────────────────────────────────────────


def run_benchmark(seed: int = 42) -> dict[str, Any]:
    rng = random.Random(seed)
    results: list[dict[str, Any]] = []

    # 50 valid + 50 adversarial per action = 500 + 500 = 1000 total
    for action_cls, spec in zip(ACTIONS, ACTION_SPECS):
        action_name = spec[0]

        # Valid invocations
        for _ in range(50):
            ctx = gen_valid_ctx(spec, rng)
            t0 = time.perf_counter()
            result = action_cls().safe_execute(ctx)
            elapsed = (time.perf_counter() - t0) * 1000

            results.append({
                "action": action_name,
                "is_adversarial": False,
                "expected_pass": True,
                "actual_pass": result.success,
                "correct": result.success is True,
                "latency_ms": round(elapsed, 4),
                "fail_field": None,
            })

        # Adversarial invocations
        for _ in range(50):
            ctx, fail_field = gen_adversarial_ctx(spec, rng)
            t0 = time.perf_counter()
            result = action_cls().safe_execute(ctx)
            elapsed = (time.perf_counter() - t0) * 1000

            results.append({
                "action": action_name,
                "is_adversarial": True,
                "expected_pass": False,
                "actual_pass": result.success,
                "correct": result.success is False,  # should be blocked
                "latency_ms": round(elapsed, 4),
                "fail_field": fail_field,
            })

    # ── Aggregate ────────────────────────────────────────────────
    valid = [r for r in results if not r["is_adversarial"]]
    adversarial = [r for r in results if r["is_adversarial"]]

    tpr = sum(r["correct"] for r in adversarial) / len(adversarial)  # true positive: correctly blocked
    fpr = sum(not r["correct"] for r in valid) / len(valid)  # false positive: incorrectly blocked
    overall_accuracy = sum(r["correct"] for r in results) / len(results)

    latencies = [r["latency_ms"] for r in results]
    latencies.sort()
    n = len(latencies)

    # Per-action breakdown
    per_action: dict[str, dict[str, Any]] = {}
    for spec in ACTION_SPECS:
        aname = spec[0]
        a_results = [r for r in results if r["action"] == aname]
        a_valid = [r for r in a_results if not r["is_adversarial"]]
        a_adv = [r for r in a_results if r["is_adversarial"]]
        per_action[aname] = {
            "tpr": sum(r["correct"] for r in a_adv) / max(len(a_adv), 1),
            "fpr": sum(not r["correct"] for r in a_valid) / max(len(a_valid), 1),
        }

    # Per violation type
    violation_types: dict[str, dict[str, int]] = {}
    for r in adversarial:
        ff = r["fail_field"] or "unknown"
        if ff not in violation_types:
            violation_types[ff] = {"caught": 0, "missed": 0}
        if r["correct"]:
            violation_types[ff]["caught"] += 1
        else:
            violation_types[ff]["missed"] += 1

    summary = {
        "total_invocations": len(results),
        "valid_invocations": len(valid),
        "adversarial_invocations": len(adversarial),
        "tpr": round(tpr, 6),
        "fpr": round(fpr, 6),
        "overall_accuracy": round(overall_accuracy, 6),
        "latency_p50_ms": round(latencies[n // 2], 4),
        "latency_p95_ms": round(latencies[int(n * 0.95)], 4),
        "latency_p99_ms": round(latencies[int(n * 0.99)], 4),
        "latency_mean_ms": round(sum(latencies) / n, 4),
        "per_action": per_action,
        "per_violation_type": violation_types,
        "seed": seed,
    }
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Experiment 3: Safety catch rate")
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()

    print(f"Running action safety benchmark: seed={args.seed}")
    summary = run_benchmark(args.seed)

    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)

    with open(out_dir / "safety_catch_rate.json", "w") as f:
        json.dump(summary, f, indent=2)

    # Generate report
    report = f"""# Experiment 3: Action Safety Catch Rate

## Configuration
- Actions: 10 distinct action types
- Valid invocations: {summary['valid_invocations']}
- Adversarial invocations: {summary['adversarial_invocations']}
- Total: {summary['total_invocations']}
- Seed: {summary['seed']}

## Overall Results

| Metric | Value |
|--------|-------|
| True Positive Rate (adversarial correctly blocked) | {summary['tpr']*100:.1f}% |
| False Positive Rate (valid incorrectly blocked) | {summary['fpr']*100:.1f}% |
| Overall Accuracy | {summary['overall_accuracy']*100:.1f}% |
| Latency p50 | {summary['latency_p50_ms']}ms |
| Latency p95 | {summary['latency_p95_ms']}ms |
| Latency p99 | {summary['latency_p99_ms']}ms |
| Latency mean | {summary['latency_mean_ms']}ms |

## Per-Action Results

| Action | TPR | FPR |
|--------|-----|-----|
"""
    for aname, astats in summary["per_action"].items():
        report += f"| {aname} | {astats['tpr']*100:.0f}% | {astats['fpr']*100:.0f}% |\n"

    report += """
## Per-Violation-Type Catch Rate

| Violation Field | Caught | Missed | Rate |
|----------------|--------|--------|------|
"""
    for vtype, vstats in sorted(summary["per_violation_type"].items()):
        total = vstats["caught"] + vstats["missed"]
        rate = vstats["caught"] / total if total > 0 else 0
        report += f"| {vtype} | {vstats['caught']} | {vstats['missed']} | {rate*100:.0f}% |\n"

    with open(out_dir / "exp3_report.md", "w") as f:
        f.write(report)

    print(f"\nTPR (adversarial blocked): {summary['tpr']*100:.1f}%")
    print(f"FPR (valid blocked):       {summary['fpr']*100:.1f}%")
    print(f"Latency p50:               {summary['latency_p50_ms']}ms")
    print(f"Latency p95:               {summary['latency_p95_ms']}ms")
    print(f"\nResults saved to {out_dir}")


if __name__ == "__main__":
    main()
