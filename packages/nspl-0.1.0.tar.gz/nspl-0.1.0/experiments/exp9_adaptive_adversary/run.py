#!/usr/bin/env python3
"""Run NSPL detectors against the adversarial dataset.

Measures evasion rate per strategy per detector.

Usage:
    .venv/bin/python experiments/exp9_adaptive_adversary/run.py
"""

from __future__ import annotations

import json
from pathlib import Path

from nspl.guards.classifier import ClassifierDetector
from nspl.guards.compound import CompoundDetector
from nspl.guards.detectors import PromptInjectionDetector
from nspl.guards.ensemble import EnsembleDetector
from nspl.guards.input_guard import InputGuard

FT_MODEL = str(Path(__file__).parent.parent / "exp6_benchmarks" / "finetuned_model")


def _is_triggered(r: object) -> bool:
    if hasattr(r, "triggered"):
        return r.triggered  # type: ignore[union-attr]
    if hasattr(r, "allowed"):
        return not r.allowed  # type: ignore[union-attr]
    return False


def main() -> None:
    dataset_path = Path(__file__).parent / "adversarial_dataset.json"
    if not dataset_path.exists():
        print("No adversarial dataset found. Run generate.py --generate first.")
        return

    with open(dataset_path) as f:
        samples = json.load(f)

    print(f"Loaded {len(samples)} adversarial samples\n")

    detectors = [
        ("Regex", PromptInjectionDetector("medium").detect),
        ("InputGuard", InputGuard().check),
        ("Classifier_PT", ClassifierDetector(threshold=0.5).detect),
        ("Classifier_FT", ClassifierDetector(model_name=FT_MODEL, threshold=0.5).detect),
        ("Ensemble_FT", EnsembleDetector(
            detectors=[
                ("regex", PromptInjectionDetector("medium"), 1.0),
                ("compound", CompoundDetector(), 1.0),
                ("clf_ft", ClassifierDetector(model_name=FT_MODEL, threshold=0.5), 1.5),
            ], strategy="any",
        ).detect),
    ]

    # Results by strategy x detector
    results: dict[str, dict[str, dict]] = {}

    for sample in samples:
        strategy = sample["strategy"]
        text = sample["adversarial_text"]

        if strategy not in results:
            results[strategy] = {}

        for det_name, det_fn in detectors:
            if det_name not in results[strategy]:
                results[strategy][det_name] = {"caught": 0, "evaded": 0, "total": 0}

            r = det_fn(text)
            caught = _is_triggered(r)
            results[strategy][det_name]["total"] += 1
            if caught:
                results[strategy][det_name]["caught"] += 1
            else:
                results[strategy][det_name]["evaded"] += 1

    # Print results
    print("Evasion Rate by Strategy x Detector")
    print("(Lower = NSPL catches more, Higher = attacker succeeds)\n")

    strategies = sorted(results.keys())
    det_names = [d[0] for d in detectors]

    header = f"| {'Strategy':<25} | " + " | ".join(f"{d:<15}" for d in det_names) + " |"
    sep = "|" + "-" * 27 + "|" + "|".join("-" * 17 for _ in det_names) + "|"
    print(header)
    print(sep)

    for strategy in strategies:
        row = f"| {strategy:<25} |"
        for det_name in det_names:
            stats = results[strategy].get(det_name, {"evaded": 0, "total": 1})
            evasion_rate = stats["evaded"] / max(stats["total"], 1)
            row += f" {evasion_rate*100:>5.1f}% evaded |"
        print(row)

    # Overall
    print(sep)
    row = f"| {'OVERALL':<25} |"
    for det_name in det_names:
        total_evaded = sum(results[s].get(det_name, {}).get("evaded", 0) for s in strategies)
        total_total = sum(results[s].get(det_name, {}).get("total", 0) for s in strategies)
        evasion_rate = total_evaded / max(total_total, 1)
        row += f" {evasion_rate*100:>5.1f}% evaded |"
    print(row)

    # Save
    out_dir = Path(__file__).parent / "results"
    out_dir.mkdir(exist_ok=True)
    with open(out_dir / "adversary_results.json", "w") as f:
        json.dump(results, f, indent=2)
    print(f"\nSaved to {out_dir}")


if __name__ == "__main__":
    main()
