# NSPL Backlog

Ideas that came up during execution but are out of scope for v0.1.0. Do not work on these until TASKS.md is complete.

## Deferred Integrations
- [ ] LMQL integration (constrained decoding + NSPL guards)
- [ ] Toon integration
- [ ] CrewAI integration
- [ ] AutoGen integration
- [ ] Semantic Kernel integration

## Deferred Features
- [ ] MCP server integration (expose NSPL actions as MCP tools)
- [ ] Google ADK integration
- [ ] LangChain Tool adapter
- [ ] Async pipeline execution
- [ ] Trainable logic gate optimization loop (train gates on labeled data)
- [ ] Concept embedding auto-generation (sentence-transformers / OpenAI)
- [ ] symbolize() / neuralize() round-trip with real embeddings
- [ ] Action composition (sequence, conditional, parallel)
- [ ] Pipeline branching (non-linear stage graphs)
- [ ] Web dashboard for audit trail visualization
- [ ] DSPy interop (use NSPL actions as DSPy modules)

## Deferred Experiments
- [ ] Exp 6: Gate training -- can gates learn safety boundaries from labeled data?
- [ ] Exp 7: Multi-model comparison -- does NSPL benefit GPT-4o differently than Claude?
- [ ] Exp 8: Adversarial robustness -- can prompt injection bypass NSPL checks?
- [ ] Exp 9: User study -- developer experience with NSPL vs. raw safety checks
