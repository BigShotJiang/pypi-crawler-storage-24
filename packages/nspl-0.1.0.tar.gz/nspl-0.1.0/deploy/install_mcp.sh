#!/bin/bash
# Install NSPL as an MCP server for Claude Code
# Run: bash deploy/install_mcp.sh

set -e

NSPL_DIR="/mnt/projects/nspl"
VENV="$NSPL_DIR/.venv"

echo "Installing NSPL MCP server..."

# Ensure venv exists
if [ ! -d "$VENV" ]; then
    python3 -m venv "$VENV"
    "$VENV/bin/pip" install -e "$NSPL_DIR"
fi

# Add to Claude Code settings
python3 - <<'PYTHON'
import json
from pathlib import Path

settings_path = Path.home() / ".claude" / "settings.json"
settings = json.loads(settings_path.read_text()) if settings_path.exists() else {}

if "mcpServers" not in settings:
    settings["mcpServers"] = {}

settings["mcpServers"]["nspl"] = {
    "command": "/mnt/projects/nspl/.venv/bin/python",
    "args": ["-m", "nspl.integrations.mcp_server"],
}

settings_path.write_text(json.dumps(settings, indent=2))
print(f"Added NSPL MCP server to {settings_path}")
print("Restart Claude Code to activate.")
PYTHON

echo "Done. Tools available: guard_input, guard_output, detect_pii, evaluate_logic"
