#!/usr/bin/env python3
"""Upload fine-tuned model to HuggingFace Hub.

Usage:
    # First login:
    huggingface-cli login

    # Then upload:
    python deploy/upload_model.py
"""

from pathlib import Path

from huggingface_hub import HfApi

REPO_ID = "astoreyai/nspl-deberta-injection-v1"
MODEL_DIR = Path(__file__).parent.parent / "experiments" / "exp6_benchmarks" / "finetuned_model"

# Files to upload (skip checkpoints dir)
FILES = [
    "config.json",
    "model.safetensors",
    "tokenizer.json",
    "tokenizer_config.json",
    "spm.model",
    "special_tokens_map.json",
    "added_tokens.json",
    "metrics.json",
    "README.md",
]


def main() -> None:
    api = HfApi()

    # Create repo if it doesn't exist
    api.create_repo(repo_id=REPO_ID, exist_ok=True, repo_type="model")
    print(f"Repo: https://huggingface.co/{REPO_ID}")

    # Upload each file
    for fname in FILES:
        fpath = MODEL_DIR / fname
        if not fpath.exists():
            print(f"  SKIP {fname} (not found)")
            continue
        size_mb = fpath.stat().st_size / 1024 / 1024
        print(f"  Uploading {fname} ({size_mb:.1f} MB)...", end=" ", flush=True)
        api.upload_file(
            path_or_fileobj=str(fpath),
            path_in_repo=fname,
            repo_id=REPO_ID,
            repo_type="model",
        )
        print("done")

    print(f"\nModel available at: https://huggingface.co/{REPO_ID}")
    print("Use with NSPL:")
    print(f'  ClassifierDetector(model_name="{REPO_ID}")')


if __name__ == "__main__":
    main()
