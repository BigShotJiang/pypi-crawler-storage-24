#!/usr/bin/env python3
"""Generate API reference markdown from module docstrings and signatures."""

from __future__ import annotations

import inspect
from pathlib import Path
from typing import Any


def _format_sig(obj: Any) -> str:
    try:
        sig = inspect.signature(obj)
        return f"`{obj.__name__}{sig}`"
    except (ValueError, TypeError):
        return f"`{obj.__name__}()`"


def _doc_module(module_path: str, title: str) -> str:
    """Import a module and document its public members."""
    import importlib
    mod = importlib.import_module(module_path)
    lines = [f"# {title}\n", f"`{module_path}`\n"]

    if mod.__doc__:
        lines.append(f"{mod.__doc__.strip()}\n")

    all_names = getattr(mod, "__all__", None)
    if all_names is None:
        all_names = [n for n in dir(mod) if not n.startswith("_")]

    for name in sorted(all_names):
        obj = getattr(mod, name, None)
        if obj is None:
            continue

        if inspect.isclass(obj):
            lines.append(f"\n## class `{name}`\n")
            if obj.__doc__:
                lines.append(f"{obj.__doc__.strip()}\n")
            # Document methods
            for mname in sorted(dir(obj)):
                if mname.startswith("_"):
                    continue
                mobj = getattr(obj, mname, None)
                if mobj and callable(mobj) and hasattr(mobj, "__doc__") and mobj.__doc__:
                    lines.append(f"\n### `{mname}()`\n")
                    lines.append(f"{mobj.__doc__.strip()}\n")
        elif callable(obj):
            lines.append(f"\n## {_format_sig(obj)}\n")
            if obj.__doc__:
                lines.append(f"{obj.__doc__.strip()}\n")

    return "\n".join(lines)


def main() -> None:
    out_dir = Path(__file__).parent.parent / "docs" / "api"
    out_dir.mkdir(parents=True, exist_ok=True)

    modules = [
        ("nspl.core", "Core: Logic Gates, Types, Uncertainty"),
        ("nspl.core.logic_gates", "Logic Gates"),
        ("nspl.core.types", "Types"),
        ("nspl.core.uncertainty", "Uncertainty & Distributions"),
        ("nspl.actions", "Action Verification & Composition"),
        ("nspl.actions.composition", "Action Composition"),
        ("nspl.guards", "Guards: Input/Output Protection"),
        ("nspl.guards.detectors", "Detectors: Injection, PII, Content"),
        ("nspl.guards.classifier", "Classifier: DeBERTa Injection Detection"),
        ("nspl.guards.ensemble", "Ensemble Detector"),
        ("nspl.guards.normalize", "Unicode Normalization"),
        ("nspl.guards.canary", "Canary Tokens"),
        ("nspl.guards.compound", "Compound Pattern Detection"),
        ("nspl.reasoning", "Reasoning Pipelines"),
        ("nspl.reasoning.async_pipeline", "Async Pipelines"),
        ("nspl.integrations.base", "Integration Base"),
        ("nspl.integrations.anthropic", "Anthropic Claude Integration"),
        ("nspl.integrations.openai", "OpenAI Integration"),
        ("nspl.integrations.google_adk", "Google ADK Integration"),
        ("nspl.integrations.langchain", "LangChain Integration"),
        ("nspl.integrations.dspy", "DSPy Integration"),
    ]

    index_lines = ["# NSPL API Reference\n"]

    for module_path, title in modules:
        try:
            doc = _doc_module(module_path, title)
            fname = module_path.replace(".", "_") + ".md"
            (out_dir / fname).write_text(doc)
            index_lines.append(f"- [{title}]({fname})")
            print(f"  Generated: {fname}")
        except Exception as e:
            print(f"  SKIP {module_path}: {e}")

    (out_dir / "index.md").write_text("\n".join(index_lines) + "\n")
    print(f"\nAPI docs written to {out_dir}")


if __name__ == "__main__":
    main()
