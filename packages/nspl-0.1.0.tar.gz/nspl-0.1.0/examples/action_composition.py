#!/usr/bin/env python3
"""Demo: Action composition -- sequence, conditional, parallel.

Shows how to chain verified actions into complex workflows
with automatic rollback on failure.

Usage:
    python examples/action_composition.py
"""

from __future__ import annotations

from unittest.mock import MagicMock

from nspl.actions import action, preconditions, safety_checks
from nspl.actions.composition import conditional, parallel, sequence

# ── Actions ──────────────────────────────────────────────────────────


@action
class ValidateOrder:
    """Check if order is valid for processing."""

    def __init__(self, order_id: str) -> None:
        self.order_id = order_id

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return bool(ctx.orders.get(self.order_id))

    def execute(self, ctx: MagicMock) -> dict:
        return ctx.orders.get(self.order_id)


@action
class ChargePayment:
    """Process payment for an order."""

    def __init__(self, order_id: str, amount: float) -> None:
        self.order_id = order_id
        self.amount = amount

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    @safety_checks
    def safety(self, ctx: MagicMock) -> bool:
        return self.amount < 10000

    def execute(self, ctx: MagicMock) -> dict:
        ctx.payments_charged.append(self.order_id)
        return {"charged": True, "amount": self.amount}


@action
class SendReceipt:
    """Email receipt to customer."""

    def __init__(self, order_id: str) -> None:
        self.order_id = order_id

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> str:
        ctx.emails_sent.append(f"Receipt for {self.order_id}")
        return f"Receipt sent for {self.order_id}"


@action
class CheckStock:
    """Check if item is in stock. Returns True/False."""

    def __init__(self, item: str) -> None:
        self.item = item

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> bool:
        return self.item in ctx.in_stock


@action
class ShipItem:
    """Ship an item."""

    def __init__(self, item: str) -> None:
        self.item = item

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> str:
        ctx.shipped.append(self.item)
        return f"Shipped: {self.item}"


@action
class BackorderNotify:
    """Notify customer of backorder."""

    def __init__(self, item: str) -> None:
        self.item = item

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> str:
        ctx.backorders.append(self.item)
        return f"Backordered: {self.item}"


@action
class LogEvent:
    """Log an audit event."""

    def __init__(self, event: str) -> None:
        self.event = event

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> str:
        ctx.log.append(self.event)
        return f"Logged: {self.event}"


# ── Demo ─────────────────────────────────────────────────────────────


def make_ctx() -> MagicMock:
    ctx = MagicMock()
    ctx.orders.get.return_value = {"id": "ORD-1", "total": 99.99}
    ctx.payments_charged = []
    ctx.emails_sent = []
    ctx.shipped = []
    ctx.backorders = []
    ctx.log = []
    ctx.in_stock = {"widget", "gadget"}
    return ctx


def main() -> None:
    print("=" * 60)
    print("NSPL Action Composition Demo")
    print("=" * 60)

    # ── 1. Sequence ──────────────────────────────────────────────
    print("\n--- Sequence: Validate -> Charge -> Receipt ---")
    ctx = make_ctx()
    chain = sequence([
        ValidateOrder("ORD-1"),
        ChargePayment("ORD-1", 99.99),
        SendReceipt("ORD-1"),
    ])
    result = chain.execute(ctx)
    print(f"  Success: {result.success}")
    print(f"  Steps completed: {len(result.results)}")
    print(f"  Payments: {ctx.payments_charged}")
    print(f"  Emails: {ctx.emails_sent}")
    print(f"  Audit entries: {len(result.audit_trail)}")

    # ── 2. Sequence with failure ─────────────────────────────────
    print("\n--- Sequence with failure (over safety limit) ---")
    ctx = make_ctx()
    chain = sequence([
        ValidateOrder("ORD-1"),
        ChargePayment("ORD-1", 50000.0),  # over $10K limit
        SendReceipt("ORD-1"),             # should not execute
    ])
    result = chain.execute(ctx)
    print(f"  Success: {result.success}")
    print(f"  Error: {result.error}")
    print(f"  Payments: {ctx.payments_charged}")  # empty
    print(f"  Emails: {ctx.emails_sent}")          # empty

    # ── 3. Conditional ───────────────────────────────────────────
    print("\n--- Conditional: Ship if in stock, else backorder ---")
    ctx = make_ctx()

    # Item in stock
    flow = conditional(
        CheckStock("widget"),
        on_true=ShipItem("widget"),
        on_false=BackorderNotify("widget"),
    )
    result = flow.execute(ctx)
    print(f"  Widget: shipped={ctx.shipped}, backordered={ctx.backorders}")

    # Item NOT in stock
    flow2 = conditional(
        CheckStock("unobtanium"),
        on_true=ShipItem("unobtanium"),
        on_false=BackorderNotify("unobtanium"),
    )
    flow2.execute(ctx)
    print(f"  Unobtanium: shipped={ctx.shipped}, backordered={ctx.backorders}")

    # ── 4. Parallel ──────────────────────────────────────────────
    print("\n--- Parallel: Log + Email + Ship simultaneously ---")
    ctx = make_ctx()
    group = parallel([
        LogEvent("order_completed"),
        SendReceipt("ORD-1"),
        ShipItem("gadget"),
    ])
    result = group.execute(ctx)
    print(f"  Success: {result.success}")
    print(f"  Log: {ctx.log}")
    print(f"  Emails: {ctx.emails_sent}")
    print(f"  Shipped: {ctx.shipped}")
    print(f"  All ran: {len(result.results)} actions")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
