#!/usr/bin/env python3
"""Demo: Multi-stage reasoning pipeline with confidence gating.

Shows how NSPL reasoning pipelines chain stages with uncertainty
propagation and automatic abort on low confidence.

Usage:
    python examples/reasoning_pipeline.py
"""

from __future__ import annotations

from nspl.core.types import UncertainValue
from nspl.reasoning import PipelineConfig, run_pipeline


def main() -> None:
    print("=" * 60)
    print("NSPL Reasoning Pipeline Demo")
    print("=" * 60)

    # ── Pipeline 1: Math problem with high confidence ────────────
    print("\n--- Pipeline 1: Confident math reasoning ---")

    def plan(question: str) -> dict:
        return {
            "steps": ["parse numbers", "identify operation", "compute"],
            "question": question,
        }

    def execute(plan: dict) -> UncertainValue:
        # Simulate solving "What is 15 + 27?"
        return UncertainValue(value=42, confidence=0.95)

    def reflect(result: UncertainValue) -> dict:
        return {
            "answer": result.value,
            "confidence": result.confidence,
            "verified": result.confidence > 0.8,
        }

    result = run_pipeline(
        [("plan", plan), ("execute", execute), ("reflect", reflect)],
        initial_input="What is 15 + 27?",
    )
    print(f"Output: {result.output}")
    print(f"Stages completed: {result.completed_stages}")
    print(f"Duration: {result.total_duration_ms:.2f}ms")
    for s in result.trace.stages:
        conf_str = f" (confidence={s.confidence:.2f})" if s.confidence else ""
        print(f"  Stage '{s.name}': {s.duration_ms:.2f}ms{conf_str}")

    # ── Pipeline 2: Aborted due to low confidence ────────────────
    print("\n--- Pipeline 2: Low confidence -> abort ---")

    def uncertain_plan(question: str) -> UncertainValue:
        return UncertainValue(
            value={"steps": ["not sure how to approach this"]},
            confidence=0.2,
        )

    def should_not_run(plan: UncertainValue) -> str:
        return "This should never execute"

    result2 = run_pipeline(
        [("plan", uncertain_plan), ("execute", should_not_run)],
        initial_input="Prove P=NP",
        config=PipelineConfig(stage_threshold=0.5),
    )
    print(f"Aborted: {result2.aborted}")
    print(f"Reason: {result2.abort_reason}")
    print(f"Completed: {result2.completed_stages}")

    # ── Pipeline 3: Retry on transient failure ───────────────────
    print("\n--- Pipeline 3: Retry on transient failure ---")
    attempt = {"n": 0}

    def flaky_stage(x: str) -> str:
        attempt["n"] += 1
        if attempt["n"] < 3:
            raise ConnectionError("API timeout")
        return f"Resolved: {x}"

    result3 = run_pipeline(
        [("fetch", flaky_stage)],
        initial_input="data",
        config=PipelineConfig(max_retries=3),
    )
    print(f"Success: {not result3.aborted}")
    print(f"Output: {result3.output}")
    print(f"Attempts needed: {attempt['n']}")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
