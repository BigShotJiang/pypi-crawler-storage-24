#!/usr/bin/env python3
"""Demo: Using NSPL as LLM guardrails and priority enforcement.

Shows how to use NSPL logic gates + actions to enforce:
1. Content safety guardrails (pre-execution)
2. Output validation (post-execution)
3. Priority/routing rules
4. Rate limiting and access control
5. Confidence-gated responses

No API keys needed -- uses mock LLM responses.

Usage:
    python examples/llm_guardrails.py
"""

from __future__ import annotations

from nspl.actions import action, postconditions, preconditions, safety_checks
from nspl.core.logic_gates import AND, NOT, WEIGHTED_AND
from nspl.core.types import UncertainValue
from nspl.reasoning import PipelineConfig, run_pipeline

# ── Mock LLM and content services ────────────────────────────────────


class MockContentFilter:
    """Simulates content safety classification."""

    TOXIC_KEYWORDS = {"hack", "exploit", "steal", "bomb"}

    def is_toxic(self, text: str) -> bool:
        return any(kw in text.lower() for kw in self.TOXIC_KEYWORDS)

    def toxicity_score(self, text: str) -> float:
        """0.0 = safe, 1.0 = toxic."""
        count = sum(1 for kw in self.TOXIC_KEYWORDS if kw in text.lower())
        return min(count / 2.0, 1.0)

    def contains_pii(self, text: str) -> bool:
        """Check for SSN, email patterns."""
        import re
        return bool(re.search(r'\d{3}-\d{2}-\d{4}', text))

    def on_topic(self, text: str, allowed_topics: list[str]) -> float:
        """Fuzzy topic relevance score."""
        text_lower = text.lower()
        # Check if any topic keyword appears in the text
        matches = sum(1 for t in allowed_topics if t.lower() in text_lower)
        if matches > 0:
            return 1.0
        # Partial match: check word overlap
        text_words = set(text_lower.split())
        topic_words = {t.lower() for t in allowed_topics}
        overlap = len(text_words & topic_words)
        return min(overlap / max(len(topic_words), 1), 1.0)


class MockRateLimiter:
    def __init__(self, limit: int = 10) -> None:
        self._calls: dict[str, int] = {}
        self._limit = limit

    def check(self, user_id: str) -> bool:
        count = self._calls.get(user_id, 0)
        return count < self._limit

    def record(self, user_id: str) -> None:
        self._calls[user_id] = self._calls.get(user_id, 0) + 1


class GuardrailContext:
    def __init__(self) -> None:
        self.filter = MockContentFilter()
        self.rate_limiter = MockRateLimiter(limit=5)
        self.allowed_topics = ["weather", "cooking", "cook", "science", "physics", "math"]
        self.user_tier = "free"  # "free" or "premium"


# ── Guardrail 1: Input validation action ─────────────────────────────


@action
class ValidateInput:
    """Validate user input before sending to LLM."""

    def __init__(self, user_id: str, message: str) -> None:
        self.user_id = user_id
        self.message = message

    @preconditions
    def check_rate(self, ctx: GuardrailContext) -> bool:
        return ctx.rate_limiter.check(self.user_id)

    @safety_checks
    def content_safety(self, ctx: GuardrailContext) -> float:
        """Multi-signal safety check using weighted AND."""
        not_toxic = NOT(ctx.filter.toxicity_score(self.message))
        no_pii = NOT(ctx.filter.contains_pii(self.message))
        on_topic = ctx.filter.on_topic(self.message, ctx.allowed_topics)

        # Weight: toxicity matters most, PII next, topic least
        return WEIGHTED_AND(
            [not_toxic, float(no_pii), on_topic],
            weights=[3.0, 2.0, 1.0],
        )

    def execute(self, ctx: GuardrailContext) -> dict:
        ctx.rate_limiter.record(self.user_id)
        return {"validated": True, "message": self.message}


# ── Guardrail 2: Output validation action ────────────────────────────


@action
class ValidateOutput:
    """Validate LLM response before returning to user."""

    def __init__(self, response: str) -> None:
        self.response = response

    @preconditions
    def check(self, ctx: GuardrailContext) -> bool:
        return len(self.response) > 0

    @safety_checks
    def output_safety(self, ctx: GuardrailContext) -> float:
        return AND(
            NOT(ctx.filter.toxicity_score(self.response)),
            NOT(ctx.filter.contains_pii(self.response)),
        )

    def execute(self, ctx: GuardrailContext) -> str:
        return self.response

    @postconditions
    def verify(self, ctx: GuardrailContext, result: str) -> bool:
        return len(result) > 0 and not ctx.filter.is_toxic(result)


# ── Priority routing with confidence gating ──────────────────────────


def route_with_priorities(
    question: str,
    ctx: GuardrailContext,
) -> dict:
    """Route a question through a guardrailed pipeline with priorities."""

    def validate_input(q: str) -> UncertainValue:
        result = ValidateInput("user_1", q).safe_execute(ctx)
        if result.success:
            # Confidence based on safety score
            safety = float(ctx.filter.on_topic(q, ctx.allowed_topics))
            return UncertainValue(value=q, confidence=max(safety, 0.6))
        return UncertainValue(value=q, confidence=0.0)

    def generate_response(validated: UncertainValue) -> UncertainValue:
        # Mock LLM response
        q = validated.value if hasattr(validated, 'value') else validated
        response = f"Here's information about: {q}"
        return UncertainValue(value=response, confidence=0.9)

    def validate_output(response: UncertainValue) -> dict:
        text = response.value if hasattr(response, 'value') else str(response)
        result = ValidateOutput(text).safe_execute(ctx)
        return {
            "response": text if result.success else "[Response blocked by guardrails]",
            "safe": result.success,
            "audit": [
                f"[{'PASS' if e.passed else 'FAIL'}] {e.stage}: {e.check_name}"
                for e in result.audit_trail
            ],
        }

    result = run_pipeline(
        [
            ("input_validation", validate_input),
            ("generation", generate_response),
            ("output_validation", validate_output),
        ],
        initial_input=question,
        config=PipelineConfig(stage_threshold=0.1),
    )
    if result.aborted or result.output is None:
        return {"response": "[Pipeline aborted]", "reason": result.abort_reason}
    if isinstance(result.output, dict):
        return result.output
    return {"response": str(result.output)}


# ── Demo ─────────────────────────────────────────────────────────────


def main() -> None:
    ctx = GuardrailContext()

    print("=" * 60)
    print("NSPL LLM Guardrails Demo")
    print("=" * 60)

    # Test 1: Safe, on-topic question
    print("\n--- Test 1: Safe question ---")
    result = route_with_priorities("What's the weather like today?", ctx)
    print(f"Response: {result.get('response', result)}")
    if 'audit' in result:
        for a in result['audit']:
            print(f"  {a}")

    # Test 2: Toxic input blocked
    print("\n--- Test 2: Toxic input ---")
    result = route_with_priorities("How to hack into a system", ctx)
    print(f"Response: {result.get('response', result)}")

    # Test 3: PII in input blocked
    print("\n--- Test 3: PII in input ---")
    result = route_with_priorities("My SSN is 123-45-6789, check my account", ctx)
    print(f"Response: {result.get('response', result)}")

    # Test 4: Priority routing -- direct logic gate evaluation
    print("\n--- Test 4: Priority scoring ---")
    questions = [
        "How do I cook pasta?",
        "What is quantum physics?",
        "Tell me a joke about cats",
        "How to steal credit cards",
    ]
    for q in questions:
        safety = NOT(ctx.filter.toxicity_score(q))
        relevance = ctx.filter.on_topic(q, ctx.allowed_topics)
        priority = WEIGHTED_AND(
            [safety, relevance],
            weights=[2.0, 1.0],
        )
        print(f"  [{priority:.3f}] {q}")

    # Test 5: Rate limiting (fresh context to reset counters)
    print("\n--- Test 5: Rate limiting (limit=5) ---")
    fresh_ctx = GuardrailContext()
    for i in range(7):
        msg = f"Question about weather {i}"
        result = ValidateInput("user_rate_test", msg).safe_execute(fresh_ctx)
        status = "ALLOWED" if result.success else "BLOCKED"
        print(f"  Request {i+1}: {status}")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
