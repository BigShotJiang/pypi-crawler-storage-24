#!/usr/bin/env python3
"""Example: Uncertainty propagation and confidence-gated pipelines.

Shows UncertainValue flowing through logic gates and pipelines.
Pipeline aborts when confidence drops below threshold. No API keys needed.

Usage:
    python examples/uncertainty_pipeline.py
"""

from nspl.core.logic_gates import AND, NOT, OR
from nspl.core.types import UncertainValue
from nspl.core.uncertainty import Normal, propagate
from nspl.reasoning import PipelineConfig, run_pipeline

print("NSPL Uncertainty & Confidence Demo\n")

# ── UncertainValue through logic gates ───────────────────────────────
print("--- Logic Gates with Uncertainty ---")
sensor_a = UncertainValue(value=0.9, confidence=0.8)
sensor_b = UncertainValue(value=0.7, confidence=0.6)

result = AND(sensor_a, sensor_b)
print(f"AND(a={sensor_a}, b={sensor_b})")
print(f"  -> value={result.value:.3f}, confidence={result.confidence} (min)")

result = OR(sensor_a, sensor_b)
print(f"OR(a, b) -> value={result.value:.3f}, confidence={result.confidence} (max)")

result = NOT(sensor_a)
print(f"NOT(a)   -> value={result.value:.3f}, confidence={result.confidence} (preserved)")

# ── UncertainValue.map and flat_map ──────────────────────────────────
print("\n--- Map and FlatMap ---")
temp = UncertainValue(value=22.5, confidence=0.9)
fahrenheit = temp.map(lambda c: c * 9 / 5 + 32)
print(f"22.5°C -> {fahrenheit.value:.1f}°F (confidence preserved: {fahrenheit.confidence})")

doubled = temp.flat_map(lambda v: UncertainValue(value=v * 2, confidence=0.8))
print(f"flat_map: confidence composed: {doubled.confidence} (0.9 * 0.8 = 0.72)")

# ── Monte Carlo Propagation ──────────────────────────────────────────
print("\n--- Monte Carlo Uncertainty Propagation ---")
dist = Normal(mean=100.0, std=5.0)
result_dist = propagate(lambda x: x**2, dist, n_samples=10000)
print("X ~ Normal(100, 5)")
print(f"X² ~ Empirical(mean={result_dist.mean():.1f}, std={result_dist.std():.1f})")

# ── Confidence-Gated Pipeline ────────────────────────────────────────
print("\n--- Confidence-Gated Pipeline ---")

def confident_step(x: str) -> UncertainValue:
    return UncertainValue(value=f"processed: {x}", confidence=0.9)

def uncertain_step(x: UncertainValue) -> UncertainValue:
    return UncertainValue(value=f"uncertain: {x.value}", confidence=0.3)

# Pipeline with high threshold -- aborts at uncertain step
result = run_pipeline(
    [("step1", confident_step), ("step2", uncertain_step)],
    initial_input="query",
    config=PipelineConfig(stage_threshold=0.5),
)
print(f"Pipeline aborted: {result.aborted}")
print(f"Completed: {result.completed_stages}")
print(f"Reason: {result.abort_reason}")

# Pipeline with low threshold -- completes
result2 = run_pipeline(
    [("step1", confident_step), ("step2", uncertain_step)],
    initial_input="query",
    config=PipelineConfig(stage_threshold=0.1),
)
print(f"\nWith low threshold: completed={result2.completed_stages}")
print(f"Output: {result2.output}")
