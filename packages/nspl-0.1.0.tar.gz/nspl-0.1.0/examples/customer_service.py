#!/usr/bin/env python3
"""Demo: Customer service agent with verified refund actions.

Shows NSPL's action verification pipeline with logic-gated preconditions,
safety checks, and postconditions. No API keys needed -- uses mock services.

Usage:
    python examples/customer_service.py
"""

from __future__ import annotations

from dataclasses import dataclass, field

from nspl.actions import action, postconditions, preconditions, safety_checks
from nspl.core.logic_gates import AND, NOT

# ── Mock services ────────────────────────────────────────────────────


@dataclass
class Order:
    order_id: str
    customer_id: str
    total: float
    status: str = "completed"


@dataclass
class MockServices:
    """Simulates order, payment, and fraud services."""

    orders: dict[str, Order] = field(default_factory=dict)
    refund_log: list[str] = field(default_factory=list)

    def seed(self) -> None:
        self.orders = {
            "ORD-001": Order("ORD-001", "CUST-A", 89.99),
            "ORD-002": Order("ORD-002", "CUST-B", 1499.99),
            "ORD-003": Order("ORD-003", "CUST-A", 29.99),
        }


class OrderService:
    def __init__(self, svc: MockServices) -> None:
        self._svc = svc

    def exists(self, order_id: str) -> bool:
        return order_id in self._svc.orders

    def total(self, order_id: str) -> float:
        return self._svc.orders[order_id].total

    def owns(self, customer_id: str, order_id: str) -> bool:
        o = self._svc.orders.get(order_id)
        return o is not None and o.customer_id == customer_id

    def status(self, order_id: str) -> str:
        return self._svc.orders[order_id].status


class PaymentService:
    def __init__(self, svc: MockServices) -> None:
        self._svc = svc

    def refund(self, order_id: str, amount: float) -> RefundResult:
        self._svc.refund_log.append(f"Refunded ${amount:.2f} for {order_id}")
        self._svc.orders[order_id].status = "refunded"
        return RefundResult(success=True, transaction_id=f"TXN-{order_id}")


@dataclass
class RefundResult:
    success: bool
    transaction_id: str


class FraudService:
    def recent_refunds(self, customer_id: str, count: int = 3) -> bool:  # noqa: ARG002
        return False  # No fraud in demo


class Context:
    """Bundles all services for action methods."""

    def __init__(self, svc: MockServices, customer_id: str) -> None:
        self.orders = OrderService(svc)
        self.payments = PaymentService(svc)
        self.fraud = FraudService()
        self.customer_id = customer_id

    def has_approval(self) -> bool:
        return False  # No manager present in demo


# ── NSPL Actions ─────────────────────────────────────────────────────


@action
class ProcessRefund:
    """Process a customer refund with full verification."""

    def __init__(self, order_id: str, amount: float) -> None:
        self.order_id = order_id
        self.amount = amount

    @preconditions
    def check(self, ctx: Context) -> float:
        if not ctx.orders.exists(self.order_id):
            return 0.0
        return AND(
            float(self.amount <= ctx.orders.total(self.order_id)),
            ctx.orders.owns(ctx.customer_id, self.order_id),
        )

    @safety_checks
    def safety(self, ctx: Context) -> float:
        return AND(
            float(self.amount < 1000 or ctx.has_approval()),
            NOT(ctx.fraud.recent_refunds(ctx.customer_id, count=3)),
        )

    def execute(self, ctx: Context) -> RefundResult:
        return ctx.payments.refund(self.order_id, self.amount)

    @postconditions
    def verify(self, ctx: Context, result: RefundResult) -> bool:
        return result.success and ctx.orders.status(self.order_id) == "refunded"


# ── Demo ─────────────────────────────────────────────────────────────


def main() -> None:
    svc = MockServices()
    svc.seed()

    print("=" * 60)
    print("NSPL Customer Service Demo")
    print("=" * 60)

    # Scenario 1: Valid refund
    print("\n--- Scenario 1: Valid $29.99 refund ---")
    ctx = Context(svc, "CUST-A")
    result = ProcessRefund("ORD-003", 29.99).safe_execute(ctx)
    print(f"Success: {result.success}")
    print(f"Duration: {result.duration_ms:.2f}ms")
    print("Audit trail:")
    for entry in result.audit_trail:
        status = "PASS" if entry.passed else "FAIL"
        print(f"  [{status}] {entry.stage}: {entry.check_name}")

    # Scenario 2: Order not found
    print("\n--- Scenario 2: Non-existent order ---")
    result = ProcessRefund("ORD-999", 10.0).safe_execute(ctx)
    print(f"Success: {result.success}")
    print(f"Error: {result.error}")

    # Scenario 3: Over $1000 without approval
    print("\n--- Scenario 3: $1499.99 refund (over limit) ---")
    ctx_b = Context(svc, "CUST-B")
    result = ProcessRefund("ORD-002", 1499.99).safe_execute(ctx_b)
    print(f"Success: {result.success}")
    print(f"Error: {result.error}")
    print("Audit trail:")
    for entry in result.audit_trail:
        status = "PASS" if entry.passed else "FAIL"
        print(f"  [{status}] {entry.stage}: {entry.check_name}")

    # Scenario 4: Dry run
    print("\n--- Scenario 4: Dry run (no execution) ---")
    ctx = Context(svc, "CUST-A")
    dry = ProcessRefund("ORD-001", 50.0).dry_run(ctx)
    print(f"Would execute: {dry.would_execute}")
    print(f"Payment called: {len(svc.refund_log)} times total")

    print("\n" + "=" * 60)
    print(f"Refund log: {svc.refund_log}")


if __name__ == "__main__":
    main()
