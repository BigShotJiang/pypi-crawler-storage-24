#!/usr/bin/env python3
"""Example: PII detection and redaction.

Scans text for SSN, email, phone, credit card, IP, DOB.
Optionally redacts before passing to LLM. No API keys needed.

Usage:
    python examples/pii_redaction.py
"""

from nspl.guards import InputGuard, PIIDetector

print("NSPL PII Detection & Redaction Demo\n")

# Standalone PII detection
detector = PIIDetector()

texts = [
    "Customer John Smith, SSN 123-45-6789, email john@example.com",
    "Call us at (555) 123-4567 or visit 192.168.1.100",
    "Card: 4111-1111-1111-1111, DOB: 01/15/1990",
    "The weather is nice today",
]

print("--- Standalone Detection ---")
for text in texts:
    r = detector.detect(text)
    if r.triggered:
        print(f"  FOUND {len(r.matches)} PII in: {text[:50]}")
        for m in r.matches:
            print(f"    - {m}")
    else:
        print(f"  CLEAN: {text[:50]}")

# InputGuard with redaction mode
print("\n--- Redaction Mode ---")
guard = InputGuard(block_pii=False, redact_pii=True)

for text in texts:
    v = guard.check(text)
    if v.sanitized_text != text:
        print(f"  Original: {text[:60]}")
        print(f"  Redacted: {v.sanitized_text[:60]}")
    else:
        print(f"  Unchanged: {text[:60]}")
