#!/usr/bin/env python3
"""Demo: Logic gates with fuzzy values and uncertainty.

Shows NSPL's differentiable logic gates operating on booleans,
fuzzy floats, and UncertainValues.

Usage:
    python examples/logic_gates_demo.py
"""

from __future__ import annotations

from nspl.core.logic_gates import AND, IMPLIES, NOT, OR, WEIGHTED_AND, XOR
from nspl.core.types import UncertainValue


def main() -> None:
    print("=" * 60)
    print("NSPL Logic Gates Demo")
    print("=" * 60)

    # ── Boolean mode ─────────────────────────────────────────────
    print("\n--- Hard mode (exact boolean) ---")
    print(f"AND(True, True)  = {AND(True, True, mode='hard')}")
    print(f"AND(True, False) = {AND(True, False, mode='hard')}")
    print(f"OR(False, True)  = {OR(False, True, mode='hard')}")
    print(f"NOT(True)        = {NOT(True, mode='hard')}")
    print(f"XOR(True, True)  = {XOR(True, True, mode='hard')}")
    print(f"IMPLIES(T, F)    = {IMPLIES(True, False, mode='hard')}")

    # ── Fuzzy mode ───────────────────────────────────────────────
    print("\n--- Soft mode (fuzzy [0,1]) ---")
    print(f"AND(0.9, 0.8) = {AND(0.9, 0.8):.4f}")
    print(f"AND(0.2, 0.9) = {AND(0.2, 0.9):.4f}  (one low -> low)")
    print(f"OR(0.2, 0.9)  = {OR(0.2, 0.9):.4f}  (one high -> high)")
    print(f"NOT(0.8)       = {NOT(0.8):.4f}")

    # ── Weighted AND ─────────────────────────────────────────────
    print("\n--- Weighted AND ---")
    print("  Scenario: 90% code quality, 30% test coverage")
    print(f"  Equal weights:     {WEIGHTED_AND([0.9, 0.3], [1.0, 1.0]):.4f}")
    print(f"  Quality-heavy:     {WEIGHTED_AND([0.9, 0.3], [3.0, 1.0]):.4f}")
    print(f"  Coverage-heavy:    {WEIGHTED_AND([0.9, 0.3], [1.0, 3.0]):.4f}")

    # ── With UncertainValue ──────────────────────────────────────
    print("\n--- Uncertain inputs ---")
    sensor_a = UncertainValue(value=0.9, confidence=0.7)
    sensor_b = UncertainValue(value=0.8, confidence=0.95)
    print(f"  Sensor A: value={sensor_a.value}, confidence={sensor_a.confidence}")
    print(f"  Sensor B: value={sensor_b.value}, confidence={sensor_b.confidence}")

    result_and = AND(sensor_a, sensor_b)
    print(f"  AND(A, B): value={result_and.value:.4f}, confidence={result_and.confidence}")
    print("    (confidence = min(0.7, 0.95) = 0.7)")

    result_or = OR(sensor_a, sensor_b)
    print(f"  OR(A, B):  value={result_or.value:.4f}, confidence={result_or.confidence}")
    print("    (confidence = max(0.7, 0.95) = 0.95)")

    result_not = NOT(sensor_a)
    print(f"  NOT(A):    value={result_not.value:.4f}, confidence={result_not.confidence}")

    # ── Mixed: uncertain + plain ─────────────────────────────────
    print("\n--- Mixed: uncertain + plain float ---")
    mixed = AND(sensor_a, 0.5)
    print(f"  AND(uncertain, plain): {mixed}")

    plain = AND(0.9, 0.8)
    print(f"  AND(plain, plain):     {plain:.4f}  (stays float)")

    print("\n" + "=" * 60)


if __name__ == "__main__":
    main()
