"""Uncertainty propagation: distributions and Monte Carlo propagation."""

from __future__ import annotations

from abc import ABC, abstractmethod
from collections.abc import Callable
from typing import Any

import numpy as np
import numpy.typing as npt
from scipy import stats as sp_stats


class Distribution(ABC):
    """Abstract probability distribution."""

    @abstractmethod
    def sample(self, n: int = 1000, seed: int | None = None) -> npt.NDArray[Any]:
        """Draw n samples."""
        ...

    @abstractmethod
    def mean(self) -> float:
        """Expected value."""
        ...

    @abstractmethod
    def std(self) -> float:
        """Standard deviation."""
        ...


class Normal(Distribution):
    """Gaussian distribution."""

    def __init__(self, mean: float, std: float) -> None:
        if std < 0:
            raise ValueError("std must be non-negative")
        self._mean = mean
        self._std = std

    def sample(self, n: int = 1000, seed: int | None = None) -> npt.NDArray[Any]:
        rng = np.random.default_rng(seed)
        return rng.normal(self._mean, self._std, size=n)

    def mean(self) -> float:
        return self._mean

    def std(self) -> float:
        return self._std

    def pdf(self, x: float) -> float:
        """Evaluate the probability density function at x."""
        return float(sp_stats.norm.pdf(x, self._mean, self._std))

    def __repr__(self) -> str:
        return f"Normal(mean={self._mean}, std={self._std})"


class Uniform(Distribution):
    """Uniform distribution over [low, high]."""

    def __init__(self, low: float, high: float) -> None:
        if low > high:
            raise ValueError("low must be <= high")
        self._low = low
        self._high = high

    def sample(self, n: int = 1000, seed: int | None = None) -> npt.NDArray[Any]:
        rng = np.random.default_rng(seed)
        return rng.uniform(self._low, self._high, size=n)

    def mean(self) -> float:
        return (self._low + self._high) / 2.0

    def std(self) -> float:
        r: float = (self._high - self._low) / (12.0**0.5)
        return r

    def __repr__(self) -> str:
        return f"Uniform(low={self._low}, high={self._high})"


class Categorical(Distribution):
    """Categorical distribution over labeled categories."""

    def __init__(self, categories: dict[str, float]) -> None:
        if not categories:
            raise ValueError("categories must not be empty")
        total = sum(categories.values())
        if abs(total - 1.0) > 0.05:
            raise ValueError(f"probabilities must sum to ~1.0, got {total}")
        self._categories = categories
        self._labels = list(categories.keys())
        self._probs = np.array([categories[k] for k in self._labels])
        self._probs = self._probs / self._probs.sum()  # normalize

    def sample(self, n: int = 1000, seed: int | None = None) -> npt.NDArray[Any]:
        rng = np.random.default_rng(seed)
        indices = rng.choice(len(self._labels), size=n, p=self._probs)
        return np.array([self._labels[i] for i in indices])

    def mean(self) -> float:
        raise TypeError("Categorical distribution has no numeric mean; use .mode()")

    def std(self) -> float:
        raise TypeError("Categorical distribution has no numeric std")

    def mode(self) -> str:
        """Return the category with the highest probability."""
        return self._labels[int(np.argmax(self._probs))]

    def prob(self, label: str) -> float:
        """Return the probability of the given category label."""
        if label not in self._categories:
            return 0.0
        idx = self._labels.index(label)
        return float(self._probs[idx])

    def __repr__(self) -> str:
        return f"Categorical({self._categories})"


class Empirical(Distribution):
    """Non-parametric distribution from observed samples."""

    def __init__(self, samples: npt.NDArray[Any]) -> None:
        if len(samples) == 0:
            raise ValueError("samples must not be empty")
        self._samples = np.asarray(samples, dtype=float)

    def sample(self, n: int = 1000, seed: int | None = None) -> npt.NDArray[Any]:
        rng = np.random.default_rng(seed)
        return rng.choice(self._samples, size=n, replace=True)

    def mean(self) -> float:
        return float(np.mean(self._samples))

    def std(self) -> float:
        return float(np.std(self._samples, ddof=1))

    def __repr__(self) -> str:
        return f"Empirical(n={len(self._samples)}, mean={self.mean():.4f})"


def propagate(
    fn: Callable[..., Any],
    dist: Distribution,
    n_samples: int = 1000,
    seed: int = 42,
) -> Empirical:
    """Propagate uncertainty through a function via Monte Carlo.

    Draws n_samples from dist, applies fn to each, returns Empirical distribution.
    """
    samples = dist.sample(n_samples, seed=seed)
    results = np.array([fn(s) for s in samples], dtype=float)
    return Empirical(results)
