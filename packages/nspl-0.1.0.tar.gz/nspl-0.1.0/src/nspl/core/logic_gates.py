"""Differentiable logic gates operating on booleans, fuzzy floats [0,1], and UncertainValues."""

from __future__ import annotations

import math
from typing import Any, Literal

# Default sigmoid steepness. Higher = sharper transition, closer to hard boolean.
# k=12 gives ~99.7% accuracy on boolean inputs in soft mode.
_DEFAULT_K = 12.0

# Lazy import to avoid circular dependency
_UncertainValue: type | None = None


def _get_uncertain_type() -> type:
    global _UncertainValue  # noqa: PLW0603
    if _UncertainValue is None:
        from nspl.core.types import UncertainValue
        _UncertainValue = UncertainValue
    return _UncertainValue


def _is_uncertain(v: Any) -> bool:
    return isinstance(v, _get_uncertain_type())


def _extract(v: Any) -> tuple[float, float | None]:
    """Extract (float_value, confidence_or_None) from input."""
    if _is_uncertain(v):
        return _to_float(v.value), v.confidence
    return _to_float(v), None


def _wrap_if_uncertain(
    result: float, confidences: list[float | None], rule: str = "min"
) -> float | Any:
    """If any input was UncertainValue, wrap result in UncertainValue."""
    actual = [c for c in confidences if c is not None]
    if not actual:
        return result
    uv_cls = _get_uncertain_type()
    if rule == "min":
        conf = min(actual)
    elif rule == "max":
        conf = max(actual)
    else:
        conf = min(actual)
    return uv_cls(value=result, confidence=conf)


def _sigmoid(x: float, k: float = _DEFAULT_K) -> float:
    """Numerically stable sigmoid."""
    if k * x > 500:
        return 1.0
    if k * x < -500:
        return 0.0
    return 1.0 / (1.0 + math.exp(-k * x))


def _to_float(v: float | bool) -> float:
    if isinstance(v, bool):
        return 1.0 if v else 0.0
    f = float(v)
    if math.isnan(f):
        raise ValueError("NaN is not a valid logic gate input")
    return f


def AND(
    *inputs: Any,
    threshold: float = 0.5,
    weights: list[float] | None = None,
    mode: Literal["soft", "hard"] = "soft",
) -> Any:
    """Conjunction gate. Returns value in [0,1], or UncertainValue if any input is uncertain.

    In hard mode: 1.0 if all inputs >= threshold, else 0.0.
    In soft mode: product t-norm (weighted geometric-like). This is the standard
    fuzzy AND — all inputs must be high for the output to be high.
    Confidence rule: min of input confidences.
    """
    if len(inputs) == 0:
        raise ValueError("AND requires at least one input")
    extracted = [_extract(v) for v in inputs]
    vals = [e[0] for e in extracted]
    confs = [e[1] for e in extracted]
    n = len(vals)

    if mode == "hard":
        r = 1.0 if all(v >= threshold for v in vals) else 0.0
        return _wrap_if_uncertain(r, confs, "min")

    w = weights if weights is not None else [1.0] * n
    if len(w) != n:
        raise ValueError(f"Expected {n} weights, got {len(w)}")

    # Weighted product t-norm: each input raised to its normalized weight
    total_w = sum(abs(wi) for wi in w)
    if total_w == 0:
        return _wrap_if_uncertain(0.5, confs, "min")
    result = 1.0
    for vi, wi in zip(vals, w):
        nw = abs(wi) / total_w
        # Clamp to avoid log(0)
        clamped = max(vi, 1e-10)
        result *= clamped ** nw
    return _wrap_if_uncertain(result, confs, "min")


def OR(
    *inputs: Any,
    threshold: float = 0.5,
    weights: list[float] | None = None,
    mode: Literal["soft", "hard"] = "soft",
) -> Any:
    """Disjunction gate. Confidence rule: max of input confidences."""
    if len(inputs) == 0:
        raise ValueError("OR requires at least one input")
    extracted = [_extract(v) for v in inputs]
    vals = [e[0] for e in extracted]
    confs = [e[1] for e in extracted]

    if mode == "hard":
        r = 1.0 if any(v >= threshold for v in vals) else 0.0
        return _wrap_if_uncertain(r, confs, "max")

    # De Morgan via product t-norm: OR = 1 - AND(1-x_i)
    negated = tuple(1.0 - v for v in vals)
    raw_and = AND(*negated, weights=weights, mode="soft")
    # AND may return UncertainValue if inputs had uncertainty, but here we're
    # working with plain floats extracted above, so raw_and is float
    r = 1.0 - (raw_and.value if _is_uncertain(raw_and) else raw_and)
    return _wrap_if_uncertain(r, confs, "max")


def NOT(
    value: Any,
    threshold: float = 0.5,  # noqa: ARG001 — kept for API symmetry
    mode: Literal["soft", "hard"] = "soft",
) -> Any:
    """Negation gate. Confidence preserved from input."""
    v, conf = _extract(value)
    if mode == "hard":
        r = 1.0 if v < threshold else 0.0
        return _wrap_if_uncertain(r, [conf])
    r = 1.0 - v
    return _wrap_if_uncertain(r, [conf])


def XOR(
    *inputs: Any,
    mode: Literal["soft", "hard"] = "soft",
) -> Any:
    """Exclusive-or gate. Confidence rule: min of input confidences."""
    if len(inputs) == 0:
        raise ValueError("XOR requires at least one input")
    extracted = [_extract(v) for v in inputs]
    vals = [e[0] for e in extracted]
    confs = [e[1] for e in extracted]

    if mode == "hard":
        count = sum(1 for v in vals if v >= 0.5)
        r = 1.0 if count % 2 == 1 else 0.0
        return _wrap_if_uncertain(r, confs, "min")

    # Soft parity via iterative XOR: XOR(a,b) = a + b - 2*a*b
    result = vals[0]
    for v in vals[1:]:
        result = result + v - 2.0 * result * v
    r = max(0.0, min(1.0, result))
    return _wrap_if_uncertain(r, confs, "min")


def IMPLIES(
    a: Any,
    b: Any,
    mode: Literal["soft", "hard"] = "soft",
) -> Any:
    """Material implication: A -> B. Confidence: min of inputs."""
    va, ca = _extract(a)
    vb, cb = _extract(b)

    if mode == "hard":
        r = 0.0 if va >= 0.5 and vb < 0.5 else 1.0
        return _wrap_if_uncertain(r, [ca, cb], "min")

    # Probabilistic sum: 1 - va*(1-vb)
    r = 1.0 - AND(va, 1.0 - vb, mode="soft")
    if _is_uncertain(r):
        r = r.value
    return _wrap_if_uncertain(r, [ca, cb], "min")


def WEIGHTED_AND(
    inputs: list[Any],
    weights: list[float],
    threshold: float = 0.5,
    mode: Literal["soft", "hard"] = "soft",
) -> Any:
    """Weighted conjunction. Confidence rule: min of input confidences."""
    if len(inputs) == 0:
        raise ValueError("WEIGHTED_AND requires at least one input")
    if len(inputs) != len(weights):
        raise ValueError(f"Expected {len(inputs)} weights, got {len(weights)}")

    extracted = [_extract(v) for v in inputs]
    vals = [e[0] for e in extracted]
    confs = [e[1] for e in extracted]
    total_w = sum(abs(w) for w in weights)

    if total_w == 0:
        return _wrap_if_uncertain(0.5, confs, "min")

    if mode == "hard":
        weighted_avg = sum(w * v for w, v in zip(weights, vals)) / total_w
        r = 1.0 if weighted_avg >= threshold else 0.0
        return _wrap_if_uncertain(r, confs, "min")

    raw = AND(*vals, weights=weights, mode="soft")
    r = raw.value if _is_uncertain(raw) else raw
    return _wrap_if_uncertain(r, confs, "min")
