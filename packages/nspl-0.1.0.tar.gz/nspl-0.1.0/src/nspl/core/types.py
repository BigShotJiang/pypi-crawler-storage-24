"""Hybrid type system: UncertainValue and Concept types."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, Field

T = TypeVar("T")
U = TypeVar("U")


class UncertainValue(BaseModel, Generic[T]):
    """A value with associated confidence and optional distribution.

    Confidence is in [0, 1] where 1.0 means full certainty.
    """

    value: Any  # Using Any because Pydantic generics + arbitrary T is fragile
    confidence: float = Field(ge=0.0, le=1.0, default=1.0)

    model_config = {"arbitrary_types_allowed": True}

    def map(self, fn: Callable[..., Any]) -> UncertainValue[Any]:
        """Apply fn to value, preserving confidence."""
        return UncertainValue(value=fn(self.value), confidence=self.confidence)

    def flat_map(self, fn: Callable[..., Any]) -> UncertainValue[Any]:
        """Apply fn that returns UncertainValue, compose confidences multiplicatively."""
        result = fn(self.value)
        if isinstance(result, UncertainValue):
            return UncertainValue(
                value=result.value,
                confidence=self.confidence * result.confidence,
            )
        return UncertainValue(value=result, confidence=self.confidence)

    def require(self, threshold: float, fallback: Callable[[], Any]) -> Any:
        """Return value if confidence >= threshold, else call fallback."""
        if self.confidence >= threshold:
            return self.value
        return fallback()

    def __bool__(self) -> bool:
        """Truthiness based on value, not confidence."""
        return bool(self.value)

    def __repr__(self) -> str:
        return f"UncertainValue(value={self.value!r}, confidence={self.confidence})"
