"""Text normalization: defeats unicode tricks, homoglyphs, and encoding evasion.

Attacks this layer stops:
  - Zero-width character injection (U+200B, U+FEFF, etc.)
  - Homoglyph substitution (Cyrillic а for Latin a, etc.)
  - Combining character abuse (diacritics to obfuscate keywords)
  - Whitespace manipulation (tabs, non-breaking spaces, etc.)
  - Mixed-script obfuscation (Latin + Cyrillic + Greek in one word)
  - Leetspeak / character substitution (1gn0re → ignore)
  - Unicode math/fullwidth character abuse (𝐢𝐠𝐧𝐨𝐫𝐞 → ignore)
"""

from __future__ import annotations

import re
import unicodedata

# ── Zero-width and invisible characters ──────────────────────────────

_INVISIBLE_CHARS = set(
    "\u200b"  # zero-width space
    "\u200c"  # zero-width non-joiner
    "\u200d"  # zero-width joiner
    "\u200e"  # left-to-right mark
    "\u200f"  # right-to-left mark
    "\u2060"  # word joiner
    "\u2061"  # function application
    "\u2062"  # invisible times
    "\u2063"  # invisible separator
    "\u2064"  # invisible plus
    "\ufeff"  # BOM / zero-width no-break space
    "\u00ad"  # soft hyphen
    "\u034f"  # combining grapheme joiner
    "\u061c"  # Arabic letter mark
    "\u180e"  # Mongolian vowel separator
)


def strip_invisible(text: str) -> str:
    """Remove all zero-width and invisible Unicode characters."""
    return "".join(c for c in text if c not in _INVISIBLE_CHARS)


# ── Homoglyph mapping ────────────────────────────────────────────────

# Maps visually similar non-Latin characters to their Latin equivalents.
# Covers Cyrillic, Greek, and common mathematical/fullwidth variants.
_HOMOGLYPH_MAP: dict[str, str] = {
    # Cyrillic -> Latin
    "\u0430": "a", "\u0435": "e", "\u043e": "o", "\u0440": "p",
    "\u0441": "c", "\u0443": "y", "\u0445": "x", "\u0456": "i",
    "\u0458": "j", "\u04bb": "h", "\u0412": "B", "\u041d": "H",
    "\u041c": "M", "\u0422": "T", "\u0410": "A", "\u0415": "E",
    "\u041e": "O", "\u0420": "P", "\u0421": "C", "\u0423": "Y",
    "\u0425": "X", "\u0406": "I",
    # Greek -> Latin
    "\u03b1": "a", "\u03b5": "e", "\u03b9": "i", "\u03bf": "o",
    "\u03c1": "p", "\u0391": "A", "\u0395": "E", "\u0397": "H",
    "\u0399": "I", "\u039f": "O", "\u03a1": "P", "\u03a4": "T",
    "\u039c": "M", "\u039a": "K", "\u0396": "Z", "\u039d": "N",
}

# Leetspeak / common substitutions
_LEET_MAP: dict[str, str] = {
    "0": "o", "1": "i", "3": "e", "4": "a", "5": "s",
    "7": "t", "@": "a", "$": "s", "!": "i", "|": "l",
}


def replace_homoglyphs(text: str) -> str:
    """Replace visually similar non-Latin characters with Latin equivalents."""
    return "".join(_HOMOGLYPH_MAP.get(c, c) for c in text)


def replace_leet(text: str) -> str:
    """Reverse common leetspeak substitutions."""
    return "".join(_LEET_MAP.get(c, c) for c in text)


# ── Unicode normalization ────────────────────────────────────────────

def normalize_unicode(text: str) -> str:
    """NFKD normalize: decomposes ligatures, fullwidth chars, math symbols.

    Examples:
      ﬁ -> fi
      ｉｇｎｏｒｅ -> ignore
      𝐢𝐠𝐧𝐨𝐫𝐞 -> ignore
    """
    return unicodedata.normalize("NFKD", text)


# ── Whitespace normalization ─────────────────────────────────────────

def normalize_whitespace(text: str) -> str:
    """Collapse all Unicode whitespace variants to plain spaces."""
    # Replace various Unicode spaces with regular space
    text = re.sub(r"[\u00a0\u1680\u2000-\u200a\u202f\u205f\u3000]", " ", text)
    # Collapse multiple spaces
    text = re.sub(r" {2,}", " ", text)
    # Replace tabs with spaces
    text = text.replace("\t", " ")
    return text.strip()


# ── Combined normalization pipeline ──────────────────────────────────

def normalize(text: str) -> str:
    """Full normalization pipeline. Apply before pattern matching.

    Order matters:
      1. Strip invisible characters (defeats zero-width injection)
      2. Unicode NFKD (defeats fullwidth/math char abuse)
      3. Replace homoglyphs (defeats Cyrillic/Greek substitution)
      4. Normalize whitespace (defeats space manipulation)
      5. Reverse leetspeak (defeats character substitution)
    """
    text = strip_invisible(text)
    text = normalize_unicode(text)
    text = replace_homoglyphs(text)
    text = normalize_whitespace(text)
    text = replace_leet(text)
    return text


def has_mixed_scripts(text: str) -> bool:
    """Detect mixed-script text (e.g., Latin + Cyrillic in same word).

    This is a strong signal of homoglyph attack -- legitimate text
    rarely mixes scripts within a single word.
    """
    words = text.split()
    for word in words:
        if len(word) < 3:
            continue
        scripts: set[str] = set()
        for char in word:
            cat = unicodedata.category(char)
            if cat.startswith("L"):  # Letter category
                try:
                    name = unicodedata.name(char, "")
                    for script in ["LATIN", "CYRILLIC", "GREEK", "ARABIC", "CJK"]:
                        if script in name:
                            scripts.add(script)
                            break
                except ValueError:
                    pass
        if len(scripts) > 1:
            return True
    return False


def char_entropy(text: str) -> float:
    """Compute character-level Shannon entropy.

    High entropy in short text is suspicious -- may indicate
    encoded payloads or obfuscated injection attempts.
    Normal English prose: ~4.0-4.5 bits/char
    Random/encoded text: >5.5 bits/char
    """
    import math
    if not text:
        return 0.0
    freq: dict[str, int] = {}
    for c in text:
        freq[c] = freq.get(c, 0) + 1
    n = len(text)
    return -sum((count / n) * math.log2(count / n) for count in freq.values())
