"""Guards: input validation, output filtering, and pipeline protection.

Four defense layers:
  1. InputGuard:     Pattern-based detection (injection, PII, content policy)
  2. OutputGuard:    Output filtering (dangerous content, leakage, PII)
  3. GuardedLLM:     Full pipeline wrapper (input -> LLM -> output)
  4. TieredDetector: Escalating analysis (structural -> embedding -> LLM judge)

All pattern matching runs on normalized text (unicode, homoglyph, leetspeak defense).
Canary tokens detect system prompt leakage even through paraphrasing.
"""

from nspl.guards.detectors import (
    ContentPolicy,
    PIIDetector,
    PromptInjectionDetector,
)
from nspl.guards.input_guard import InputGuard, InputVerdict
from nspl.guards.output_guard import OutputGuard, OutputVerdict
from nspl.guards.pipeline import GuardConfig, GuardedLLM, GuardResult

__all__ = [
    "InputGuard",
    "InputVerdict",
    "OutputGuard",
    "OutputVerdict",
    "GuardedLLM",
    "GuardConfig",
    "GuardResult",
    "PromptInjectionDetector",
    "PIIDetector",
    "ContentPolicy",
]
