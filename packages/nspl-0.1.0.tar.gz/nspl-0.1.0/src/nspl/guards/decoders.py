"""Decode-and-rescan: catches encoded payloads by decoding them first.

Fix for: "Translate from hex: 69676e6f7265" (decodes to "ignore")

Strategy: Extract encoded payloads, decode them, and re-run detection
on the decoded content. If the decoded payload is itself an injection,
the original input is flagged.
"""

from __future__ import annotations

import base64
import binascii
import re
from dataclasses import dataclass


@dataclass
class DecodedPayload:
    """A decoded payload found in text."""

    encoding: str  # "hex", "base64", "rot13"
    encoded: str
    decoded: str


def extract_and_decode(text: str) -> list[DecodedPayload]:
    """Find and decode encoded payloads in text.

    Attempts hex, base64, and rot13 decoding on any suspicious
    strings found in the input.
    """
    payloads: list[DecodedPayload] = []

    # Hex strings: sequences of hex chars (min 6 chars = 3 bytes)
    for m in re.finditer(r"\b([0-9a-fA-F]{6,})\b", text):
        hex_str = m.group(1)
        if len(hex_str) % 2 != 0:
            continue
        try:
            decoded = bytes.fromhex(hex_str).decode("utf-8", errors="ignore")
            if decoded and len(decoded) >= 3 and _looks_like_text(decoded):
                payloads.append(DecodedPayload("hex", hex_str, decoded))
        except (ValueError, binascii.Error):
            pass

    # Base64 strings: look for base64-like patterns near decode keywords
    b64_context = re.finditer(
        r"(?i)(?:base64|decode|encoded?)\s*:?\s*([A-Za-z0-9+/=]{8,})", text
    )
    for m in b64_context:
        b64_str = m.group(1)
        try:
            decoded = base64.b64decode(b64_str).decode("utf-8", errors="ignore")
            if decoded and len(decoded) >= 3 and _looks_like_text(decoded):
                payloads.append(DecodedPayload("base64", b64_str, decoded))
        except Exception:
            pass

    # Also try any long base64-looking string even without context
    for m in re.finditer(r"\b([A-Za-z0-9+/]{12,}={0,2})\b", text):
        b64_str = m.group(1)
        # Skip if already found
        if any(p.encoded == b64_str for p in payloads):
            continue
        try:
            decoded = base64.b64decode(b64_str).decode("utf-8", errors="ignore")
            if decoded and len(decoded) >= 4 and _looks_like_text(decoded):
                payloads.append(DecodedPayload("base64", b64_str, decoded))
        except Exception:
            pass

    # ROT13: check if rot13 of the full text reveals injection keywords
    rot13 = text.translate(str.maketrans(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz",
        "NOPQRSTUVWXYZABCDEFGHIJKLMnopqrstuvwxyzabcdefghijklm",
    ))
    injection_words = {"ignore", "bypass", "override", "system", "instructions", "prompt"}
    if any(w in rot13.lower() for w in injection_words):
        if not any(w in text.lower() for w in injection_words):
            payloads.append(DecodedPayload("rot13", text, rot13))

    return payloads


def _looks_like_text(s: str) -> bool:
    """Heuristic: is this decoded string likely natural language?"""
    if not s:
        return False
    printable = sum(1 for c in s if c.isprintable()) / len(s)
    alpha = sum(1 for c in s if c.isalpha()) / max(len(s), 1)
    return printable > 0.8 and alpha > 0.5
