"""Output guard: validates LLM responses before returning to user."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from nspl.guards.detectors import (
    ContentPolicy,
    DetectorResult,
    PIIDetector,
)


@dataclass
class OutputVerdict:
    """Result of output guard evaluation."""

    allowed: bool
    filtered_text: str | None = None  # cleaned text if allowed
    detections: list[DetectorResult] = field(default_factory=list)
    reason: str = ""
    risk_score: float = 0.0


class OutputGuard:
    """Validates LLM output for dangerous content, PII leakage, and policy violations.

    Additional output-specific checks:
      1. Refusal bypass detection (LLM was tricked into complying)
      2. System prompt leakage
      3. Hallucination indicators (confidence markers without substance)
      4. Instruction echoing (LLM repeated injected instructions)
    """

    def __init__(
        self,
        block_pii: bool = True,
        redact_pii: bool = True,
        content_categories: list[str] | None = None,
        max_length: int | None = None,
        custom_detectors: list[Any] | None = None,
    ) -> None:
        self._pii = PIIDetector()
        self._content = ContentPolicy(enabled_categories=content_categories)
        self._block_pii = block_pii
        self._redact_pii = redact_pii
        self._max_length = max_length
        self._custom = custom_detectors or []

    def check(self, text: str, original_prompt: str | None = None) -> OutputVerdict:
        """Evaluate LLM output against all checks."""
        detections: list[DetectorResult] = []

        # 1. Content policy (dangerous output)
        content = self._content.detect(text)
        detections.append(content)
        if content.triggered:
            return OutputVerdict(
                allowed=False,
                detections=detections,
                reason=f"Dangerous output: {content.detail}",
                risk_score=content.score,
            )

        # 2. System prompt leakage
        if original_prompt:
            leakage = _detect_prompt_leakage(text, original_prompt)
            detections.append(leakage)
            if leakage.triggered:
                return OutputVerdict(
                    allowed=False,
                    detections=detections,
                    reason=f"System prompt leakage: {leakage.detail}",
                    risk_score=leakage.score,
                )

        # 3. Instruction echoing (sign of successful injection)
        echo = _detect_instruction_echo(text)
        detections.append(echo)
        if echo.triggered:
            return OutputVerdict(
                allowed=False,
                detections=detections,
                reason=f"Instruction echoing detected: {echo.detail}",
                risk_score=echo.score,
            )

        # 4. PII leakage in output
        pii = self._pii.detect(text)
        detections.append(pii)
        if pii.triggered:
            if self._redact_pii:
                filtered = _redact_output_pii(text, pii)
                return OutputVerdict(
                    allowed=True,
                    filtered_text=filtered,
                    detections=detections,
                    reason="PII redacted from output",
                    risk_score=pii.score * 0.3,
                )
            if self._block_pii:
                return OutputVerdict(
                    allowed=False,
                    detections=detections,
                    reason=f"PII in output: {pii.detail}",
                    risk_score=pii.score,
                )

        # 5. Length check
        if self._max_length and len(text) > self._max_length:
            detections.append(DetectorResult(
                triggered=True,
                detector_name="length",
                detail=f"Output too long: {len(text)} > {self._max_length}",
            ))
            return OutputVerdict(
                allowed=True,
                filtered_text=text[:self._max_length] + "\n[TRUNCATED]",
                detections=detections,
                reason="Output truncated",
            )

        # 6. Custom detectors
        for detector in self._custom:
            result = detector.detect(text)
            detections.append(result)
            if result.triggered:
                return OutputVerdict(
                    allowed=False,
                    detections=detections,
                    reason=f"Custom: {result.detail}",
                    risk_score=result.score,
                )

        return OutputVerdict(
            allowed=True,
            filtered_text=text,
            detections=detections,
            reason="All checks passed",
        )


def _detect_prompt_leakage(output: str, system_prompt: str) -> DetectorResult:
    """Check if the LLM leaked significant portions of the system prompt."""
    # Split system prompt into phrases and check for matches
    if len(system_prompt) < 20:
        return DetectorResult(triggered=False, detector_name="prompt_leakage")

    # Check 5-word windows from system prompt appearing in output
    sys_words = system_prompt.lower().split()
    out_lower = output.lower()
    window_size = 5
    leaked_phrases: list[str] = []

    for i in range(len(sys_words) - window_size + 1):
        phrase = " ".join(sys_words[i : i + window_size])
        if phrase in out_lower:
            leaked_phrases.append(phrase)

    if len(leaked_phrases) >= 3:
        return DetectorResult(
            triggered=True,
            detector_name="prompt_leakage",
            detail=f"Found {len(leaked_phrases)} matching 5-word phrases from system prompt",
            score=min(len(leaked_phrases) / 5.0, 1.0),
            matches=leaked_phrases[:5],
        )
    return DetectorResult(triggered=False, detector_name="prompt_leakage")


def _detect_instruction_echo(text: str) -> DetectorResult:
    """Detect if LLM is echoing injected instructions (sign of successful attack)."""
    patterns = [
        r"(?i)(ok|sure|certainly|of\s+course)[,.]?\s*(here|i\s+will|let\s+me)\s+(ignore|override|bypass|disable)",
        r"(?i)(ok|sure)[,.]?\s*i\s+(am\s+now|will\s+now)\s+(acting|pretending|operating|ignor)",
        r"(?i)(entering|switching\s+to|activating)\s+(DAN|developer|unrestricted|jailbreak)\s+mode",
        r"(?i)i\s+will\s+now\s+(ignore|override|bypass|disable|remove)\s+(all\s+)?(safety|content|guard|filter)",
        r"(?i)my\s+(new\s+)?(instructions?|rules?|persona|identity)\s+(are|is)\s*:",
    ]
    for pattern in patterns:
        m = re.search(pattern, text)
        if m:
            return DetectorResult(
                triggered=True,
                detector_name="instruction_echo",
                detail=f"LLM appears to comply with injection: {m.group()[:100]}",
                score=0.9,
                matches=[m.group()],
            )
    return DetectorResult(triggered=False, detector_name="instruction_echo")


def _redact_output_pii(text: str, pii_result: DetectorResult) -> str:
    result = text
    for match_str in pii_result.matches:
        parts = match_str.split(": ", 1)
        if len(parts) == 2:
            pii_type, value = parts
            result = result.replace(value, f"[REDACTED_{pii_type.upper()}]")
    return result
