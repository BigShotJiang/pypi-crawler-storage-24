"""Small classifier tier: local prompt injection detection via fine-tuned model.

Uses a HuggingFace prompt injection classifier (~86M params) that runs
locally with no API calls. Fills the gap between regex (Tier 1) and
LLM-as-judge (Tier 3).

Default model: protectai/deberta-v3-base-prompt-injection-v2
  - 96% F1 on prompt injection benchmarks
  - ~250MB download on first use
  - ~5ms inference on CPU, <1ms on GPU

Install: pip install nspl[classifier]
Requires: transformers, torch

Usage:
    from nspl.guards.classifier import ClassifierDetector

    det = ClassifierDetector()
    result = det.detect("Ignore all previous instructions")
    print(result.triggered)  # True
    print(result.score)      # 0.98
"""

from __future__ import annotations

from typing import Any

from nspl.guards.detectors import DetectorResult
from nspl.guards.normalize import normalize

# Default model: protectai's pretrained detector (best FPR: 0.4%)
_DEFAULT_MODEL = "protectai/deberta-v3-base-prompt-injection-v2"

# Fine-tuned model: higher recall (82%) but higher FPR on OOD data
# Upload with: python deploy/upload_model.py
FINETUNED_MODEL = "astoreyai/nspl-deberta-injection-v1"

# Label mapping for the default model
# The model outputs: LABEL_0 = safe, LABEL_1 = injection
_LABEL_MAP = {
    "INJECTION": True,
    "SAFE": False,
    "LABEL_1": True,  # fallback numeric labels
    "LABEL_0": False,
}


class ClassifierDetector:
    """Local prompt injection classifier using a fine-tuned transformer.

    Loads lazily on first detect() call. Model is cached after first download.

    Args:
        model_name: HuggingFace model ID. Default: protectai/deberta-v3-base-prompt-injection-v2
        threshold: Confidence threshold for triggering. Default: 0.85
        device: "cpu", "cuda", or "auto". Default: "cpu"
        normalize_input: Apply NSPL normalization before classification. Default: True
    """

    def __init__(
        self,
        model_name: str = _DEFAULT_MODEL,
        threshold: float = 0.85,
        device: str = "cpu",
        normalize_input: bool = True,
    ) -> None:
        self._model_name = model_name
        self._threshold = threshold
        self._device = device
        self._normalize = normalize_input
        self._pipeline: Any = None
        self._available: bool | None = None

    def _load(self) -> bool:
        """Lazy-load the classifier pipeline."""
        if self._available is not None:
            return self._available
        try:
            from transformers import pipeline as hf_pipeline

            self._pipeline = hf_pipeline(
                "text-classification",
                model=self._model_name,
                device=self._device if self._device != "auto" else -1,
                truncation=True,
                max_length=512,
            )
            self._available = True
            return True
        except ImportError:
            self._available = False
            return False
        except Exception as e:
            self._available = False
            self._load_error = str(e)
            return False

    def detect(self, text: str) -> DetectorResult:
        """Classify text as safe or prompt injection.

        Returns DetectorResult with:
          - triggered: True if classified as injection above threshold
          - score: Model confidence (0.0-1.0)
          - detail: Model label and confidence
        """
        if not self._load():
            return DetectorResult(
                triggered=False,
                detector_name="classifier",
                detail="transformers not installed; pip install nspl[classifier]",
                score=0.0,
            )

        # Normalize input to defeat unicode evasion
        input_text = normalize(text) if self._normalize else text

        # Truncate to model's max length
        input_text = input_text[:2048]

        try:
            results = self._pipeline(input_text)
            if not results:
                return DetectorResult(
                    triggered=False,
                    detector_name="classifier",
                    detail="No classification result",
                    score=0.0,
                )

            # results is a list of dicts: [{"label": "INJECTION", "score": 0.98}]
            top = results[0]
            label = top["label"]
            score = float(top["score"])

            # Map label to boolean
            is_injection = _LABEL_MAP.get(label, "injection" in label.lower())

            # If the model says "safe" with high confidence, invert the score
            if not is_injection:
                effective_score = 1.0 - score
            else:
                effective_score = score

            triggered = is_injection and score >= self._threshold

            return DetectorResult(
                triggered=triggered,
                detector_name="classifier",
                detail=f"label={label}, confidence={score:.3f}, threshold={self._threshold}",
                score=effective_score,
                matches=[label] if triggered else [],
            )

        except Exception as e:
            return DetectorResult(
                triggered=False,
                detector_name="classifier",
                detail=f"Classification error: {type(e).__name__}: {str(e)[:200]}",
                score=0.0,
            )


class MultiClassifierDetector:
    """Ensemble of multiple classifiers for higher accuracy.

    Runs multiple models and uses majority vote or max-score.
    Useful when a single model's blind spots matter.

    Args:
        models: List of HuggingFace model IDs
        strategy: "majority" (vote) or "max_score" (highest injection score wins)
        threshold: Per-model confidence threshold
    """

    def __init__(
        self,
        models: list[str] | None = None,
        strategy: str = "max_score",
        threshold: float = 0.85,
    ) -> None:
        self._models = models or [_DEFAULT_MODEL]
        self._strategy = strategy
        self._detectors = [ClassifierDetector(m, threshold) for m in self._models]

    def detect(self, text: str) -> DetectorResult:
        """Run all classifiers and combine results using the configured strategy."""
        results = [d.detect(text) for d in self._detectors]
        available = [r for r in results if "not installed" not in r.detail]

        if not available:
            return results[0]  # return the "not installed" message

        if self._strategy == "majority":
            votes = sum(1 for r in available if r.triggered)
            triggered = votes > len(available) / 2
            max_result = max(available, key=lambda r: r.score)
            return DetectorResult(
                triggered=triggered,
                detector_name="classifier_ensemble",
                detail=f"votes={votes}/{len(available)}, {max_result.detail}",
                score=max_result.score,
                matches=max_result.matches,
            )
        else:  # max_score
            best = max(available, key=lambda r: r.score)
            return DetectorResult(
                triggered=best.triggered,
                detector_name="classifier_ensemble",
                detail=f"best_of_{len(available)}: {best.detail}",
                score=best.score,
                matches=best.matches,
            )
