"""Ensemble detector: combines all detection strategies with OR logic.

Union approach: if ANY detector triggers, the input is blocked.
This maximizes recall at the cost of slightly higher FPR.

Optionally weighted: each detector gets a vote weight, and the
ensemble triggers if weighted vote sum exceeds a threshold.
"""

from __future__ import annotations

from typing import Any

from nspl.guards.detectors import DetectorResult, PromptInjectionDetector


class EnsembleDetector:
    """Combines multiple detectors with configurable strategy.

    Strategies:
      - "any" (default): triggers if ANY detector triggers (max recall)
      - "majority": triggers if majority of detectors trigger
      - "weighted": triggers if weighted score exceeds threshold

    Usage:
        ensemble = EnsembleDetector.default()
        result = ensemble.detect("Ignore all instructions")
    """

    def __init__(
        self,
        detectors: list[tuple[str, Any, float]],
        strategy: str = "any",
        threshold: float = 0.5,
    ) -> None:
        """
        Args:
            detectors: List of (name, detector, weight) tuples.
                       Each detector must have a .detect(text) method.
            strategy: "any", "majority", or "weighted"
            threshold: For weighted strategy, minimum score to trigger
        """
        self._detectors = detectors
        self._strategy = strategy
        self._threshold = threshold

    @classmethod
    def default(cls, enable_classifier: bool = True) -> EnsembleDetector:
        """Create ensemble with all available detectors."""
        from nspl.guards.compound import CompoundDetector
        from nspl.guards.semantic import StructuralDetector

        detectors: list[tuple[str, Any, float]] = [
            ("regex", PromptInjectionDetector("medium"), 1.0),
            ("regex_high", PromptInjectionDetector("high"), 0.5),
            ("compound", CompoundDetector(), 1.0),
            ("structural", StructuralDetector(threshold=0.3), 0.5),
        ]

        if enable_classifier:
            try:
                from nspl.guards.classifier import ClassifierDetector
                detectors.append(("classifier", ClassifierDetector(threshold=0.5), 1.5))
            except Exception:
                pass

        return cls(detectors, strategy="any")

    def detect(self, text: str) -> DetectorResult:
        """Run all detectors and combine results."""
        results: list[tuple[str, DetectorResult, float]] = []

        for name, detector, weight in self._detectors:
            try:
                r = detector.detect(text)
                results.append((name, r, weight))
            except Exception:
                continue

        if not results:
            return DetectorResult(
                triggered=False, detector_name="ensemble",
                detail="No detectors available", score=0.0,
            )

        triggered_names = [name for name, r, _ in results if r.triggered]

        if self._strategy == "any":
            triggered = len(triggered_names) > 0
        elif self._strategy == "majority":
            triggered = len(triggered_names) > len(results) / 2
        elif self._strategy == "weighted":
            weighted_score = sum(
                r.score * w for _, r, w in results
            ) / sum(w for _, _, w in results)
            triggered = weighted_score >= self._threshold
        else:
            triggered = len(triggered_names) > 0

        # Aggregate score: max of individual scores
        max_score = max(r.score for _, r, _ in results)
        best = max(results, key=lambda x: x[1].score)

        detail_parts = []
        for name, r, _ in results:
            status = "HIT" if r.triggered else "---"
            detail_parts.append(f"{name}:{status}")

        return DetectorResult(
            triggered=triggered,
            detector_name="ensemble",
            detail=f"[{', '.join(detail_parts)}] best={best[0]}",
            score=max_score,
            matches=best[1].matches if best[1].triggered else [],
        )
