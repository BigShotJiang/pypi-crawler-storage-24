"""Signal detectors: prompt injection, PII, content policy.

Each detector produces a boolean or score. These are composed via
logic gates in InputGuard/OutputGuard. Detectors are deterministic
(no LLM calls) -- fast and auditable.

Design: Use explicit thresholds internally (lesson from Experiment 4).
Return booleans to the guard layer, not raw fuzzy scores.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class DetectorResult:
    """Result from a single detector."""

    triggered: bool
    detector_name: str
    detail: str = ""
    score: float = 0.0  # raw score before threshold
    matches: list[str] = field(default_factory=list)


class PromptInjectionDetector:
    """Multi-pattern prompt injection and jailbreak detector.

    Strategies:
      1. Known injection patterns (regex)
      2. Role-override attempts
      3. Instruction delimiter attacks
      4. Encoding/obfuscation attacks
      5. Context window manipulation
    """

    # ── Pattern categories ────────────────────────────────────────

    ROLE_OVERRIDE_PATTERNS: list[str] = [
        r"(?i)ignore\s+(all\s+)?(previous|prior|above|earlier)\s+(instructions?|rules?|prompts?|guidelines?)",
        r"(?i)disregard\s+(all\s+)?(previous|prior|above)\s+(instructions?|rules?)",
        r"(?i)forget\s+(everything|all|your)\s+(previous|prior|above)?",
        r"(?i)you\s+are\s+now\s+(a|an|the)\s+",
        r"(?i)act\s+as\s+(if\s+you\s+are|a|an)\s+",
        r"(?i)pretend\s+(you\s+are|to\s+be)\s+",
        r"(?i)from\s+now\s+on\s+(you|your)\s+(are|will|should|must)",
        r"(?i)new\s+(instruction|rule|mode|persona|identity)\s*:",
        r"(?i)system\s*:\s*you\s+are",
        r"(?i)override\s+(safety|content|guard|filter|policy)",
    ]

    DELIMITER_ATTACK_PATTERNS: list[str] = [
        r"(?i)\[system\]",
        r"(?i)\[INST\]",
        r"(?i)<<\s*SYS\s*>>",
        r"(?i)<\|im_start\|>\s*system",
        r"(?i)###\s*(system|instruction|human|assistant)\s*(message|prompt)?",
        r"(?i)---\s*BEGIN\s*(SYSTEM|HIDDEN|INTERNAL|SECRET)",
        r"(?i)```\s*(system|hidden|internal)\s*(prompt|instruction|message)",
    ]

    EXFILTRATION_PATTERNS: list[str] = [
        r"(?i)repeat\s+(the|your)\s+(system|initial|original|hidden)\s+(prompt|instructions?|message)",
        r"(?i)what\s+(are|were)\s+your\s+(system|initial|original)\s+(instructions?|prompt|rules?)",
        r"(?i)show\s+me\s+(your|the)\s+(system|hidden|initial)\s+(prompt|message|instructions?)",
        r"(?i)output\s+(your|the)\s+(system|initial|full)\s+(prompt|instructions?)",
        r"(?i)print\s+(your|the)\s+(instructions?|prompt|rules?|system)",
        r"(?i)tell\s+me\s+(your|the)\s+(system|secret|hidden)\s+(prompt|rules?|instructions?)",
    ]

    ENCODING_PATTERNS: list[str] = [
        r"(?i)base64\s*(decode|encode|:)",
        r"(?i)hex\s*(decode|encode|:)",
        r"(?i)rot13",
        r"(?i)morse\s*code",
        r"(?i)unicode\s*(escape|encode)",
        r"(?i)translate\s+(from|to)\s+(binary|hex|base64|ascii)",
    ]

    JAILBREAK_PATTERNS: list[str] = [
        r"(?i)DAN\s*(mode)?",
        r"(?i)do\s+anything\s+now",
        r"(?i)developer\s+mode",
        r"(?i)jailbreak",
        r"(?i)no\s+(restrictions?|limits?|rules?|filters?|censorship)",
        r"(?i)unrestricted\s+(mode|access|output)",
        r"(?i)bypass\s+(the\s+)?(safety|content|guard|filter|restrictions?)",
        r"(?i)turn\s+off\s+(the\s+)?(safety|content|guard|filter)",
        r"(?i)disable\s+(the\s+)?(safety|content|guard|filter)",
    ]

    MANIPULATION_PATTERNS: list[str] = [
        r"(?i)this\s+is\s+a\s+(test|hypothetical|fictional|roleplay|thought\s+experiment)",
        r"(?i)for\s+(educational|research|academic|testing)\s+purposes?\s+only",
        r"(?i)in\s+a\s+(fictional|hypothetical|imaginary)\s+(world|scenario|context)",
        r"(?i)write\s+a\s+(story|fiction|script)\s+(where|about|in\s+which)",
    ]

    # German language injection patterns (deepset benchmark is bilingual)
    GERMAN_PATTERNS: list[str] = [
        r"(?i)vergiss\s+(alles|alles\s+davor|alles\s+bisherige)",
        r"(?i)ignoriere?\s+(alle|die|bisherige)?\s*(anweisungen|regeln|instruktionen)",
        r"(?i)neue\s+(aufgabe|anweisung|instruktion)",
        r"(?i)vergessen\s+sie\s+(alles|die|alle)",
        r"(?i)ab\s+jetzt\s+(bist\s+du|sind\s+sie|gelten)",
        r"(?i)m[öo]chte.*dass\s+sie\s+als\s+",
        r"(?i)agieren\s+sie\s+als",
        r"(?i)jetzt\s+kommen\s+neue",
    ]

    # Indirect / context-switch patterns from benchmark analysis
    CONTEXT_SWITCH_PATTERNS: list[str] = [
        r"(?i)(well\s+done|great|super|good\s+job)[.!]?\s*(now|but\s+now|here\s+comes)",
        r"(?i)you\s+have\s+passed.*test.*now",
        r"(?i)here\s+comes\s+(the\s+)?(second|next|new|real)\s+(test|task|instruction)",
        r"(?i)now\s+(comes?|forget|ignore|here)",
        r"(?i)======\s*END",
        r"(?i)spell.?check.*print.*prompt",
        r"(?i)print\s+(the\s+)?(above|previous)\s+(prompt|text|input|instructions?)",
    ]

    def __init__(self, sensitivity: str = "medium") -> None:
        """sensitivity: 'low', 'medium', or 'high'."""
        self._sensitivity = sensitivity
        self._all_patterns: list[tuple[str, list[str]]] = [
            ("role_override", self.ROLE_OVERRIDE_PATTERNS),
            ("delimiter_attack", self.DELIMITER_ATTACK_PATTERNS),
            ("exfiltration", self.EXFILTRATION_PATTERNS),
            ("encoding_attack", self.ENCODING_PATTERNS),
            ("jailbreak", self.JAILBREAK_PATTERNS),
            ("german", self.GERMAN_PATTERNS),
            ("context_switch", self.CONTEXT_SWITCH_PATTERNS),
        ]
        if sensitivity == "high":
            self._all_patterns.append(("manipulation", self.MANIPULATION_PATTERNS))

        # Minimum pattern categories that must match to trigger
        self._min_categories = {"low": 2, "medium": 1, "high": 1}[sensitivity]

    def detect(self, text: str) -> DetectorResult:
        """Scan text for prompt injection patterns.

        Runs pattern matching on BOTH original and normalized text
        to catch unicode evasion, homoglyphs, and leetspeak.
        """
        from nspl.guards.normalize import normalize

        texts_to_check = [text, normalize(text)]
        triggered_categories: list[str] = []
        all_matches: list[str] = []

        for check_text in texts_to_check:
            for category, patterns in self._all_patterns:
                if category in triggered_categories:
                    continue  # already triggered
                for pattern in patterns:
                    m = re.search(pattern, check_text)
                    if m:
                        if category not in triggered_categories:
                            triggered_categories.append(category)
                        all_matches.append(f"{category}: {m.group()}")
                        break  # one match per category is enough

        triggered = len(triggered_categories) >= self._min_categories
        score = len(triggered_categories) / len(self._all_patterns)

        return DetectorResult(
            triggered=triggered,
            detector_name="prompt_injection",
            detail=f"Categories: {', '.join(triggered_categories)}" if triggered else "Clean",
            score=score,
            matches=all_matches,
        )


class PIIDetector:
    """Detects personally identifiable information in text.

    Covers: SSN, email, phone, credit card, IP address, date of birth patterns.
    """

    PATTERNS: dict[str, str] = {
        "ssn": r"\b\d{3}-\d{2}-\d{4}\b",
        "email": r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b",
        "phone_us": r"\b(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}\b",
        "credit_card": r"\b(?:\d{4}[-\s]?){3}\d{4}\b",
        "ip_address": r"\b(?:\d{1,3}\.){3}\d{1,3}\b",
        "date_of_birth": (
            r"(?i)\b(?:dob|date\s+of\s+birth|born\s+on)"
            r"\s*:?\s*\d{1,2}[/\-]\d{1,2}[/\-]\d{2,4}\b"
        ),
    }

    def detect(self, text: str) -> DetectorResult:
        matches: list[str] = []
        for pii_type, pattern in self.PATTERNS.items():
            for m in re.finditer(pattern, text):
                matches.append(f"{pii_type}: {m.group()}")

        return DetectorResult(
            triggered=len(matches) > 0,
            detector_name="pii",
            detail=f"Found {len(matches)} PII instance(s)" if matches else "Clean",
            score=min(len(matches) / 3.0, 1.0),
            matches=matches,
        )


class ContentPolicy:
    """Detects dangerous, harmful, or policy-violating content.

    Categories: violence, weapons, illegal activity, self-harm,
    sexual content, hate speech indicators.
    """

    CATEGORIES: dict[str, list[str]] = {
        "weapons_instructions": [
            r"(?i)how\s+to\s+(make|build|create|assemble|construct)\s+(a\s+)?(bomb|explosive|weapon|gun|firearm)",
            r"(?i)instructions?\s+(for|to)\s+(making|building|creating)\s+(a\s+)?(bomb|explosive|weapon)",
            r"(?i)synthesize\s+(poison|toxin|nerve\s+agent|chemical\s+weapon)",
        ],
        "illegal_activity": [
            r"(?i)how\s+to\s+(hack|break\s+into|exploit|crack)\s+(into\s+)?(a\s+)?(system|server|account|network|password|someone)",
            r"(?i)how\s+to\s+(steal|forge|counterfeit|launder)",
            r"(?i)how\s+to\s+(pick\s+a\s+lock|hotwire|hijack)",
        ],
        "self_harm": [
            r"(?i)how\s+to\s+(kill|harm|hurt|end)\s+(yourself|myself|oneself)",
            r"(?i)(best|easiest|most\s+effective)\s+(way|method)\s+to\s+(die|kill\s+yourself)",
            r"(?i)(way|method|how)\s+to\s+(commit\s+)?suicide",
        ],
        "malware": [
            r"(?i)write\s+(a|me\s+a)?\s*(virus|malware|ransomware|trojan|keylogger|rootkit)",
            r"(?i)create\s+(a\s+)?(phishing|spear\s*phishing)\s+(email|page|site|campaign)",
            r"(?i)code\s+(for|to)\s+(ddos|denial\s+of\s+service|brute\s*force)",
        ],
    }

    def __init__(self, enabled_categories: list[str] | None = None) -> None:
        if enabled_categories:
            self._categories = {
                k: v for k, v in self.CATEGORIES.items() if k in enabled_categories
            }
        else:
            self._categories = dict(self.CATEGORIES)

    def detect(self, text: str) -> DetectorResult:
        matches: list[str] = []
        triggered_categories: list[str] = []

        for category, patterns in self._categories.items():
            for pattern in patterns:
                m = re.search(pattern, text)
                if m:
                    matches.append(f"{category}: {m.group()}")
                    if category not in triggered_categories:
                        triggered_categories.append(category)
                    break

        return DetectorResult(
            triggered=len(triggered_categories) > 0,
            detector_name="content_policy",
            detail=f"Violations: {', '.join(triggered_categories)}" if matches else "Clean",
            score=min(len(triggered_categories) / len(self._categories), 1.0),
            matches=matches,
        )
