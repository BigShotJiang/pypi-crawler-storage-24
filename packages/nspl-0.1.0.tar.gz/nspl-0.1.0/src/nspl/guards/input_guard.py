"""Input guard: validates user prompts before they reach the LLM."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from nspl.guards.detectors import (
    ContentPolicy,
    DetectorResult,
    PIIDetector,
    PromptInjectionDetector,
)


@dataclass
class InputVerdict:
    """Result of input guard evaluation."""

    allowed: bool
    sanitized_text: str | None = None  # cleaned text if allowed, None if blocked
    detections: list[DetectorResult] = field(default_factory=list)
    reason: str = ""
    risk_score: float = 0.0  # 0=safe, 1=dangerous


class InputGuard:
    """Composes multiple detectors to validate LLM input.

    Default pipeline:
      1. Prompt injection detection (regex on normalized text)
      2. Compound pattern detection (pretext + payload combinations)
      3. Encoded payload detection (decode hex/base64/rot13, rescan)
      4. Content policy check
      5. PII detection (optionally redact instead of block)

    Composition: blocked if ANY detector triggers (OR logic on threats).
    """

    def __init__(
        self,
        injection_sensitivity: str = "medium",
        block_pii: bool = True,
        redact_pii: bool = False,
        content_categories: list[str] | None = None,
        enable_compound: bool = True,
        enable_decoder: bool = True,
        custom_detectors: list[Any] | None = None,
    ) -> None:
        self._injection = PromptInjectionDetector(sensitivity=injection_sensitivity)
        self._pii = PIIDetector()
        self._content = ContentPolicy(enabled_categories=content_categories)
        self._block_pii = block_pii
        self._redact_pii = redact_pii
        self._enable_compound = enable_compound
        self._enable_decoder = enable_decoder
        self._custom = custom_detectors or []

    def check(self, text: str) -> InputVerdict:
        """Evaluate input text against all detectors."""
        detections: list[DetectorResult] = []

        # 1. Prompt injection (regex on normalized text)
        inj = self._injection.detect(text)
        detections.append(inj)
        if inj.triggered:
            return InputVerdict(
                allowed=False,
                detections=detections,
                reason=f"Prompt injection detected: {inj.detail}",
                risk_score=inj.score,
            )

        # 2. Compound pattern detection (pretext + payload)
        if self._enable_compound:
            from nspl.guards.compound import CompoundDetector
            compound = CompoundDetector().detect(text)
            detections.append(compound)
            if compound.triggered:
                return InputVerdict(
                    allowed=False,
                    detections=detections,
                    reason=f"Compound injection: {compound.detail}",
                    risk_score=compound.score,
                )

        # 3. Encoded payload detection (decode and rescan)
        if self._enable_decoder:
            from nspl.guards.decoders import extract_and_decode
            payloads = extract_and_decode(text)
            for p in payloads:
                # Re-run injection detection on decoded content
                decoded_check = self._injection.detect(p.decoded)
                # Also flag if decoded content contains injection keywords
                _injection_keywords = {
                    "ignore", "bypass", "override", "disregard",
                    "forget", "system", "prompt", "instructions",
                    "jailbreak", "unrestricted", "hack", "exploit",
                }
                keyword_hit = any(
                    kw in p.decoded.lower() for kw in _injection_keywords
                )
                if decoded_check.triggered or keyword_hit:
                    hit_detail = (
                        decoded_check.detail if decoded_check.triggered
                        else f"decoded keyword: '{p.decoded}'"
                    )
                    detections.append(decoded_check)
                    return InputVerdict(
                        allowed=False,
                        detections=detections,
                        reason=(
                            f"Encoded injection ({p.encoding}): "
                            f"decoded '{p.decoded[:50]}' -> {hit_detail}"
                        ),
                        risk_score=max(decoded_check.score, 0.7),
                    )

        # 4. Content policy
        content = self._content.detect(text)
        detections.append(content)
        if content.triggered:
            return InputVerdict(
                allowed=False,
                detections=detections,
                reason=f"Content policy violation: {content.detail}",
                risk_score=content.score,
            )

        # 5. PII
        pii = self._pii.detect(text)
        detections.append(pii)
        if pii.triggered:
            if self._block_pii and not self._redact_pii:
                return InputVerdict(
                    allowed=False,
                    detections=detections,
                    reason=f"PII detected: {pii.detail}",
                    risk_score=pii.score,
                )
            if self._redact_pii:
                sanitized = _redact_pii_from_text(text, pii)
                return InputVerdict(
                    allowed=True,
                    sanitized_text=sanitized,
                    detections=detections,
                    reason="PII redacted",
                    risk_score=pii.score * 0.3,  # reduced risk after redaction
                )

        # 4. Custom detectors
        for detector in self._custom:
            result = detector.detect(text)
            detections.append(result)
            if result.triggered:
                return InputVerdict(
                    allowed=False,
                    detections=detections,
                    reason=f"Custom detector: {result.detail}",
                    risk_score=result.score,
                )

        return InputVerdict(
            allowed=True,
            sanitized_text=text,
            detections=detections,
            reason="All checks passed",
            risk_score=0.0,
        )


def _redact_pii_from_text(text: str, pii_result: DetectorResult) -> str:
    """Replace detected PII with [REDACTED] markers."""

    result = text
    for match_str in pii_result.matches:
        # match_str format: "type: actual_value"
        parts = match_str.split(": ", 1)
        if len(parts) == 2:
            pii_type, value = parts
            result = result.replace(value, f"[REDACTED_{pii_type.upper()}]")
    return result
