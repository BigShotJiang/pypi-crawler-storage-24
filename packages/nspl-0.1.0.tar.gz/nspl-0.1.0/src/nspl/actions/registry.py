"""Action registry for agent framework discovery."""

from __future__ import annotations

import inspect
from typing import Any


class ActionRegistry:
    """Registry of NSPL actions. Converts to tool schemas for agent frameworks."""

    def __init__(self) -> None:
        self._actions: dict[str, type] = {}

    def register(self, name: str, action_cls: type) -> None:
        """Register an action class by name."""
        self._actions[name] = action_cls

    def get(self, name: str) -> type:
        """Get an action class by name."""
        if name not in self._actions:
            raise KeyError(f"Action not found: {name}")
        return self._actions[name]

    def list_actions(self) -> list[str]:
        """List all registered action names."""
        return list(self._actions.keys())

    def to_tool_schemas(self) -> list[dict[str, Any]]:
        """Generate JSON-schema tool definitions for all registered actions.

        Returns a provider-agnostic list of tool schemas. Each integration
        adapter converts these to its provider-specific format.
        """
        schemas: list[dict[str, Any]] = []
        for name, cls in self._actions.items():
            params = _extract_params(cls)
            schemas.append({
                "name": name,
                "description": inspect.getdoc(cls) or f"Action: {name}",
                "parameters": {
                    "type": "object",
                    "properties": params,
                    "required": [k for k, v in params.items() if "default" not in v],
                },
            })
        return schemas


def _extract_params(cls: type) -> dict[str, Any]:
    """Extract parameter schema from class __init__ annotations."""
    hints = {}
    # Check __init__ signature
    sig = inspect.signature(cls) if hasattr(cls, "__init__") else None
    if sig:
        for pname, param in sig.parameters.items():
            if pname in ("self", "ctx"):
                continue
            ptype = "string"
            if param.annotation is not inspect.Parameter.empty:
                ann = param.annotation
                if ann in (int, "int"):
                    ptype = "integer"
                elif ann in (float, "float"):
                    ptype = "number"
                elif ann in (bool, "bool"):
                    ptype = "boolean"
            entry: dict[str, Any] = {"type": ptype}
            if param.default is not inspect.Parameter.empty:
                entry["default"] = param.default
            hints[pname] = entry

    # Fallback: check class-level annotations
    if not hints and hasattr(cls, "__annotations__"):
        for attr, ann in cls.__annotations__.items():
            ptype = "string"
            if ann in (int, "int"):
                ptype = "integer"
            elif ann in (float, "float"):
                ptype = "number"
            elif ann in (bool, "bool"):
                ptype = "boolean"
            hints[attr] = {"type": ptype}

    return hints


# Global default registry
default_registry = ActionRegistry()
