"""Action verification: preconditions, postconditions, safety checks."""

from nspl.actions.action import (
    ActionResult,
    AuditEntry,
    DryRunResult,
    action,
    postconditions,
    preconditions,
    safety_checks,
)
from nspl.actions.composition import (
    Conditional,
    Parallel,
    Sequence,
    conditional,
    parallel,
    sequence,
)
from nspl.actions.exceptions import (
    NSPLVerificationError,
    PostconditionError,
    PreconditionError,
    SafetyViolationError,
)
from nspl.actions.registry import ActionRegistry, default_registry

__all__ = [
    "action",
    "preconditions",
    "postconditions",
    "safety_checks",
    "ActionResult",
    "AuditEntry",
    "DryRunResult",
    "ActionRegistry",
    "default_registry",
    "NSPLVerificationError",
    "PreconditionError",
    "SafetyViolationError",
    "PostconditionError",
    "Sequence",
    "Conditional",
    "Parallel",
    "sequence",
    "conditional",
    "parallel",
]
