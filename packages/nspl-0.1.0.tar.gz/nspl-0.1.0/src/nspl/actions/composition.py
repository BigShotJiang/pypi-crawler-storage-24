"""Action composition: sequence, conditional, parallel, and rollback.

Compose multiple verified actions into chains that execute atomically
with full audit trails.

Usage:
    from nspl.actions.composition import sequence, conditional, parallel

    # Sequential: each action's result feeds the next
    chain = sequence([ValidateInput, ProcessRefund, SendConfirmation])
    result = chain.execute(ctx)

    # Conditional: run action B only if action A succeeds with condition
    chain = conditional(
        CheckInventory,
        on_true=ShipOrder,
        on_false=BackorderNotification,
    )

    # Parallel: run independent actions concurrently
    chain = parallel([SendEmail, UpdateDatabase, LogAudit])
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from nspl.actions.action import ActionResult, AuditEntry


@dataclass
class CompositionResult:
    """Result of a composed action chain."""

    success: bool
    results: list[ActionResult] = field(default_factory=list)
    error: str | None = None
    rolled_back: bool = False
    audit_trail: list[AuditEntry] = field(default_factory=list)


class Sequence:
    """Execute actions in order. Stop on first failure.

    Each action receives (ctx, previous_result) via ctx._chain_result.
    If any action fails, the chain stops and returns the failure.
    Optional rollback functions run on failure.
    """

    def __init__(
        self,
        actions: list[Any],
        rollback_fns: list[Any] | None = None,
    ) -> None:
        self._actions = actions
        self._rollbacks = rollback_fns or []

    def execute(self, ctx: Any) -> CompositionResult:
        """Run actions sequentially, stopping and rolling back on first failure."""
        results: list[ActionResult] = []
        all_audit: list[AuditEntry] = []
        prev_result: Any = None

        for i, action_instance in enumerate(self._actions):
            # Pass previous result via context
            ctx._chain_result = prev_result
            ctx._chain_index = i

            result = action_instance.safe_execute(ctx)
            results.append(result)
            all_audit.extend(result.audit_trail)

            if not result.success:
                # Rollback previously successful actions
                rolled_back = self._rollback(ctx, results[:i])
                return CompositionResult(
                    success=False,
                    results=results,
                    error=f"Step {i} failed: {result.error}",
                    rolled_back=rolled_back,
                    audit_trail=all_audit,
                )
            prev_result = result.result

        return CompositionResult(
            success=True,
            results=results,
            audit_trail=all_audit,
        )

    def _rollback(self, ctx: Any, completed: list[ActionResult]) -> bool:
        if not self._rollbacks:
            return False
        for i in range(len(completed) - 1, -1, -1):
            if i < len(self._rollbacks) and self._rollbacks[i]:
                try:
                    self._rollbacks[i](ctx, completed[i])
                except Exception:
                    pass  # best-effort rollback
        return True


class Conditional:
    """Execute one of two actions based on a condition action's result.

    condition_action runs first. If it succeeds and result is truthy,
    on_true runs. Otherwise on_false runs.
    """

    def __init__(
        self,
        condition: Any,
        on_true: Any,
        on_false: Any | None = None,
    ) -> None:
        self._condition = condition
        self._on_true = on_true
        self._on_false = on_false

    def execute(self, ctx: Any) -> CompositionResult:
        """Evaluate the condition and execute the matching branch."""
        # Run condition
        cond_result = self._condition.safe_execute(ctx)
        results = [cond_result]
        audit = list(cond_result.audit_trail)

        if not cond_result.success:
            return CompositionResult(
                success=False,
                results=results,
                error=f"Condition failed: {cond_result.error}",
                audit_trail=audit,
            )

        # Branch
        branch = self._on_true if cond_result.result else self._on_false
        if branch is None:
            return CompositionResult(
                success=True,
                results=results,
                audit_trail=audit,
            )

        branch_result = branch.safe_execute(ctx)
        results.append(branch_result)
        audit.extend(branch_result.audit_trail)

        return CompositionResult(
            success=branch_result.success,
            results=results,
            error=branch_result.error,
            audit_trail=audit,
        )


class Parallel:
    """Execute independent actions, collect all results.

    All actions run regardless of individual failures.
    Overall success = all actions succeeded.
    """

    def __init__(self, actions: list[Any]) -> None:
        self._actions = actions

    def execute(self, ctx: Any) -> CompositionResult:
        """Run all actions and collect results, regardless of individual failures."""
        results: list[ActionResult] = []
        audit: list[AuditEntry] = []
        errors: list[str] = []

        for action_instance in self._actions:
            result = action_instance.safe_execute(ctx)
            results.append(result)
            audit.extend(result.audit_trail)
            if not result.success:
                errors.append(result.error or "unknown error")

        return CompositionResult(
            success=len(errors) == 0,
            results=results,
            error="; ".join(errors) if errors else None,
            audit_trail=audit,
        )


# Convenience constructors
def sequence(actions: list[Any], rollback_fns: list[Any] | None = None) -> Sequence:
    """Create a sequential action chain."""
    return Sequence(actions, rollback_fns)


def conditional(condition: Any, on_true: Any, on_false: Any | None = None) -> Conditional:
    """Create a conditional action branch."""
    return Conditional(condition, on_true, on_false)


def parallel(actions: list[Any]) -> Parallel:
    """Create a parallel action group."""
    return Parallel(actions)
