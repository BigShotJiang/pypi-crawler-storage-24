"""Typed exceptions for action verification failures."""

from __future__ import annotations

from typing import Any


class NSPLVerificationError(Exception):
    """Base exception for all NSPL verification failures."""

    def __init__(self, message: str, audit_trail: list[Any] | None = None) -> None:
        super().__init__(message)
        self.audit_trail = audit_trail or []


class PreconditionError(NSPLVerificationError):
    """Raised when an action's preconditions are not met."""


class SafetyViolationError(NSPLVerificationError):
    """Raised when an action's safety checks fail."""


class PostconditionError(NSPLVerificationError):
    """Raised when an action's postconditions are not satisfied after execution."""
