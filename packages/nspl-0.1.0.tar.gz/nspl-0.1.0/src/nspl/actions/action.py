"""Action decorator and verification pipeline."""

from __future__ import annotations

import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

from nspl.core.types import UncertainValue

# Sentinel for decorator registration
_NSPL_PRECONDITION = "_nspl_precondition"
_NSPL_POSTCONDITION = "_nspl_postcondition"
_NSPL_SAFETY_CHECK = "_nspl_safety_check"


class AuditEntry(BaseModel):
    """Single entry in the verification audit trail."""

    timestamp: str
    stage: Literal["precondition", "safety", "execution", "postcondition"]
    check_name: str
    passed: bool
    value: Any = None
    detail: str = ""

    model_config = {"arbitrary_types_allowed": True}


class ActionResult(BaseModel):
    """Result of a verified action execution."""

    success: bool
    result: Any = None
    error: str | None = None
    audit_trail: list[AuditEntry] = Field(default_factory=list)
    duration_ms: float = 0.0

    model_config = {"arbitrary_types_allowed": True}


class DryRunResult(BaseModel):
    """Result of a dry run (checks only, no execution)."""

    would_execute: bool
    audit_trail: list[AuditEntry] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _check_result(result: Any, threshold: float = 0.9) -> tuple[bool, Any]:
    """Evaluate a check result. Returns (passed, raw_value).

    - bool: direct truth test
    - float in [0,1]: treated as fuzzy truth value, must be >= 0.5
    - UncertainValue: confidence must meet threshold AND value must be truthy/>=0.5
    """
    if isinstance(result, UncertainValue):
        val = result.value
        if isinstance(val, float):
            val_ok = val >= 0.5
        else:
            val_ok = bool(val)
        return result.confidence >= threshold and val_ok, result
    if isinstance(result, float):
        return result >= 0.5, result
    return bool(result), result


def preconditions(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Mark a method as a precondition check."""
    setattr(fn, _NSPL_PRECONDITION, True)
    return fn


def postconditions(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Mark a method as a postcondition check."""
    setattr(fn, _NSPL_POSTCONDITION, True)
    return fn


def safety_checks(fn: Callable[..., Any]) -> Callable[..., Any]:
    """Mark a method as a safety check."""
    setattr(fn, _NSPL_SAFETY_CHECK, True)
    return fn


def action(cls: type) -> type:
    """Decorator that adds verified execution to a class.

    Scans for @preconditions, @postconditions, @safety_checks methods
    and adds safe_execute() and dry_run() methods.
    """
    # Collect decorated methods
    pre_methods: list[str] = []
    post_methods: list[str] = []
    safety_methods: list[str] = []

    for name in dir(cls):
        obj = getattr(cls, name, None)
        if obj is None:
            continue
        if getattr(obj, _NSPL_PRECONDITION, False):
            pre_methods.append(name)
        if getattr(obj, _NSPL_POSTCONDITION, False):
            post_methods.append(name)
        if getattr(obj, _NSPL_SAFETY_CHECK, False):
            safety_methods.append(name)

    cls._nspl_pre_methods = pre_methods  # type: ignore[attr-defined]
    cls._nspl_post_methods = post_methods  # type: ignore[attr-defined]
    cls._nspl_safety_methods = safety_methods  # type: ignore[attr-defined]

    # Wrap execute() to prevent direct bypass
    if hasattr(cls, "execute"):
        _original_execute = cls.execute

        def _guarded_execute(self: Any, *args: Any, **kwargs: Any) -> Any:
            if not getattr(self, "_nspl_verified", False):
                raise RuntimeError(
                    "Direct execute() call blocked. "
                    "Use safe_execute() to run with verification, "
                    "or dry_run() to test checks without executing."
                )
            return _original_execute(self, *args, **kwargs)

        cls.execute = _guarded_execute
        cls._nspl_original_execute = _original_execute  # type: ignore[attr-defined]

    def safe_execute(
        self: Any,
        ctx: Any,
        precondition_threshold: float = 0.9,
        safety_threshold: float = 0.95,
        postcondition_threshold: float = 0.9,
    ) -> ActionResult:
        """Execute action through full verification pipeline."""
        trail: list[AuditEntry] = []
        start = time.monotonic()

        # 1. Preconditions
        for method_name in self._nspl_pre_methods:
            method = getattr(self, method_name)
            result = method(ctx)
            passed, raw = _check_result(result, precondition_threshold)
            trail.append(AuditEntry(
                timestamp=_now_iso(),
                stage="precondition",
                check_name=method_name,
                passed=passed,
                value=str(raw),
            ))
            if not passed:
                return ActionResult(
                    success=False,
                    error=f"Precondition failed: {method_name}",
                    audit_trail=trail,
                    duration_ms=(time.monotonic() - start) * 1000,
                )

        # 2. Safety checks
        for method_name in self._nspl_safety_methods:
            method = getattr(self, method_name)
            result = method(ctx)
            passed, raw = _check_result(result, safety_threshold)
            trail.append(AuditEntry(
                timestamp=_now_iso(),
                stage="safety",
                check_name=method_name,
                passed=passed,
                value=str(raw),
            ))
            if not passed:
                return ActionResult(
                    success=False,
                    error=f"Safety check failed: {method_name}",
                    audit_trail=trail,
                    duration_ms=(time.monotonic() - start) * 1000,
                )

        # 3. Execute (set verified flag to allow guarded execute)
        self._nspl_verified = True
        try:
            exec_result = self.execute(ctx)
            trail.append(AuditEntry(
                timestamp=_now_iso(),
                stage="execution",
                check_name="execute",
                passed=True,
            ))
        except RuntimeError:
            self._nspl_verified = False
            raise  # re-raise guard errors
        except Exception as e:
            self._nspl_verified = False
            safe_detail = f"{type(e).__name__}: {str(e)[:200]}"
            trail.append(AuditEntry(
                timestamp=_now_iso(),
                stage="execution",
                check_name="execute",
                passed=False,
                detail=safe_detail,
            ))
            return ActionResult(
                success=False,
                error=f"Execution failed: {type(e).__name__}",
                audit_trail=trail,
                duration_ms=(time.monotonic() - start) * 1000,
            )
        self._nspl_verified = False

        # 4. Postconditions
        for method_name in self._nspl_post_methods:
            method = getattr(self, method_name)
            result = method(ctx, exec_result)
            passed, raw = _check_result(result, postcondition_threshold)
            trail.append(AuditEntry(
                timestamp=_now_iso(),
                stage="postcondition",
                check_name=method_name,
                passed=passed,
                value=str(raw),
            ))
            if not passed:
                return ActionResult(
                    success=False,
                    result=exec_result,
                    error=f"Postcondition failed: {method_name}",
                    audit_trail=trail,
                    duration_ms=(time.monotonic() - start) * 1000,
                )

        return ActionResult(
            success=True,
            result=exec_result,
            audit_trail=trail,
            duration_ms=(time.monotonic() - start) * 1000,
        )

    def dry_run(
        self: Any,
        ctx: Any,
        precondition_threshold: float = 0.9,
        safety_threshold: float = 0.95,
    ) -> DryRunResult:
        """Run preconditions + safety checks without executing."""
        trail: list[AuditEntry] = []
        would_execute = True

        for method_name in self._nspl_pre_methods:
            method = getattr(self, method_name)
            result = method(ctx)
            passed, raw = _check_result(result, precondition_threshold)
            trail.append(AuditEntry(
                timestamp=_now_iso(),
                stage="precondition",
                check_name=method_name,
                passed=passed,
                value=str(raw),
            ))
            if not passed:
                would_execute = False

        for method_name in self._nspl_safety_methods:
            method = getattr(self, method_name)
            result = method(ctx)
            passed, raw = _check_result(result, safety_threshold)
            trail.append(AuditEntry(
                timestamp=_now_iso(),
                stage="safety",
                check_name=method_name,
                passed=passed,
                value=str(raw),
            ))
            if not passed:
                would_execute = False

        return DryRunResult(would_execute=would_execute, audit_trail=trail)

    cls.safe_execute = safe_execute  # type: ignore[attr-defined]
    cls.dry_run = dry_run  # type: ignore[attr-defined]
    return cls
