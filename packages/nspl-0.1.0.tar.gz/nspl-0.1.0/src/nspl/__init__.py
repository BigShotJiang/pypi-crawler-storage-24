"""NSPL: Non-Stochastic Protection Layer for verified agentic AI."""

__version__ = "0.1.0"
