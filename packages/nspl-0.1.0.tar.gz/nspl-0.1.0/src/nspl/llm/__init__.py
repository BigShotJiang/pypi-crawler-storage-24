"""LLM CLI wrapper: unified interface over gemini, codex, and claude CLIs."""

from nspl.llm.client import LLMClient, LLMResponse, query_llm

__all__ = ["LLMClient", "LLMResponse", "query_llm"]
