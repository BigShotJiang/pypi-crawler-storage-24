"""Unified LLM client wrapping gemini, codex, and claude CLIs.

Uses the user's existing CLI subscriptions. Each CLI handles its own auth.
SDK mode is available as fallback when API keys are set in environment.

Usage:
    from nspl.llm import LLMClient
    client = LLMClient(provider="claude")
    response = client.query("What is 2+2?")
"""

from __future__ import annotations

import os
import subprocess
import time
from dataclasses import dataclass
from typing import Any, Literal

Provider = Literal["claude", "gemini", "openai"]

# CLI commands for headless mode
_CLI_COMMANDS: dict[Provider, list[str]] = {
    "claude": ["claude", "-p", "--output-format", "text"],
    "gemini": ["gemini", "-p"],
    "openai": ["codex", "exec"],
}

_SDK_ENV_KEYS: dict[Provider, str] = {
    "claude": "ANTHROPIC_API_KEY",
    "gemini": "GOOGLE_API_KEY",
    "openai": "OPENAI_API_KEY",
}

_DEFAULT_MODELS: dict[Provider, str] = {
    "claude": "claude-sonnet-4-20250514",
    "gemini": "gemini-2.5-flash",
    "openai": "gpt-4o-mini",
}


@dataclass
class LLMResponse:
    """Response from an LLM call."""

    text: str
    provider: str
    model: str
    latency_ms: float
    success: bool
    error: str | None = None
    mode: str = "cli"  # "cli" or "sdk"


@dataclass
class LLMClient:
    """Unified client: tries SDK first (if API key set), falls back to CLI.

    Auth:
      - CLI mode: uses gemini/codex/claude CLI with cached browser login
      - SDK mode: uses ANTHROPIC_API_KEY / GOOGLE_API_KEY / OPENAI_API_KEY
    """

    provider: Provider = "claude"
    model: str | None = None
    max_tokens: int = 64
    temperature: float = 0.0
    timeout_s: float = 30.0
    prefer_sdk: bool = True  # try SDK first if API key available

    def _get_model(self) -> str:
        return self.model or _DEFAULT_MODELS[self.provider]

    def _has_api_key(self) -> bool:
        return bool(os.environ.get(_SDK_ENV_KEYS.get(self.provider, "")))

    def query(self, prompt: str) -> LLMResponse:
        """Query the LLM. Uses SDK if key available, else CLI."""
        if self.prefer_sdk and self._has_api_key():
            return self._query_sdk(prompt)
        return self._query_cli(prompt)

    def batch(self, prompts: list[str]) -> list[LLMResponse]:
        """Query the LLM with multiple prompts and return all responses."""
        return [self.query(p) for p in prompts]

    # ── CLI mode ─────────────────────────────────────────────────

    def _query_cli(self, prompt: str) -> LLMResponse:
        model = self._get_model()
        cmd = list(_CLI_COMMANDS[self.provider])
        cmd.append(prompt)
        t0 = time.monotonic()

        try:
            result = subprocess.run(
                cmd, capture_output=True, text=True,
                timeout=self.timeout_s, stdin=subprocess.DEVNULL,
            )
            latency = (time.monotonic() - t0) * 1000
            text = _strip_cli_noise(result.stdout.strip())

            if result.returncode != 0 and not text:
                return LLMResponse(
                    text="", provider=self.provider, model=model,
                    latency_ms=latency, success=False, mode="cli",
                    error=f"Exit {result.returncode}: {result.stderr[:300]}",
                )
            return LLMResponse(
                text=text, provider=self.provider, model=model,
                latency_ms=latency, success=True, mode="cli",
            )
        except subprocess.TimeoutExpired:
            return LLMResponse(
                text="", provider=self.provider, model=model,
                latency_ms=(time.monotonic() - t0) * 1000,
                success=False, mode="cli", error=f"Timeout after {self.timeout_s}s",
            )
        except FileNotFoundError:
            return LLMResponse(
                text="", provider=self.provider, model=model,
                latency_ms=0, success=False, mode="cli",
                error=f"CLI not found: {cmd[0]}",
            )

    # ── SDK mode ─────────────────────────────────────────────────

    def _query_sdk(self, prompt: str) -> LLMResponse:
        model = self._get_model()
        t0 = time.monotonic()
        try:
            if self.provider == "claude":
                return self._sdk_claude(prompt, model, t0)
            elif self.provider == "gemini":
                return self._sdk_gemini(prompt, model, t0)
            elif self.provider == "openai":
                return self._sdk_openai(prompt, model, t0)
            return LLMResponse(
                text="", provider=self.provider, model=model,
                latency_ms=0, success=False, mode="sdk",
                error=f"Unknown provider: {self.provider}",
            )
        except Exception as e:
            return LLMResponse(
                text="", provider=self.provider, model=model,
                latency_ms=(time.monotonic() - t0) * 1000,
                success=False, mode="sdk",
                error=f"{type(e).__name__}: {str(e)[:300]}",
            )

    def _sdk_claude(self, prompt: str, model: str, t0: float) -> LLMResponse:
        import anthropic
        msg = anthropic.Anthropic().messages.create(
            model=model, max_tokens=self.max_tokens,
            temperature=self.temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        text = msg.content[0].text if msg.content else ""  # type: ignore[union-attr]
        return LLMResponse(
            text=text, provider="claude", model=model,
            latency_ms=(time.monotonic() - t0) * 1000,
            success=True, mode="sdk",
        )

    def _sdk_gemini(self, prompt: str, model: str, t0: float) -> LLMResponse:
        from google import genai
        resp = genai.Client().models.generate_content(
            model=model, contents=prompt,
            config=genai.types.GenerateContentConfig(
                temperature=self.temperature,
                max_output_tokens=self.max_tokens,
            ),
        )
        return LLMResponse(
            text=resp.text or "", provider="gemini", model=model,
            latency_ms=(time.monotonic() - t0) * 1000,
            success=True, mode="sdk",
        )

    def _sdk_openai(self, prompt: str, model: str, t0: float) -> LLMResponse:
        import openai
        resp = openai.OpenAI().chat.completions.create(
            model=model, max_tokens=self.max_tokens,
            temperature=self.temperature,
            messages=[{"role": "user", "content": prompt}],
        )
        text = resp.choices[0].message.content or "" if resp.choices else ""
        return LLMResponse(
            text=text, provider="openai", model=model,
            latency_ms=(time.monotonic() - t0) * 1000,
            success=True, mode="sdk",
        )


def query_llm(prompt: str, provider: Provider = "claude", **kwargs: Any) -> LLMResponse:
    """Convenience: single query to any provider."""
    return LLMClient(provider=provider, **kwargs).query(prompt)


def _strip_cli_noise(text: str) -> str:
    lines = text.split("\n")
    skip = [
        "Loaded cached credentials", "Session cleanup disabled",
        "Warning: no stdin", "SessionEnd hook", "SessionStart hook",
        "hook failed", "Hook cancelled", "Remainder of file",
    ]
    return "\n".join(ln for ln in lines if not any(p in ln for p in skip)).strip()
