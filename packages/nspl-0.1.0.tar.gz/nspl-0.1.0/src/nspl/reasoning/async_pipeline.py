"""Async reasoning pipeline: async/await support for LLM-backed stages."""

from __future__ import annotations

import asyncio
import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from nspl.core.types import UncertainValue
from nspl.reasoning.pipeline import PipelineConfig, PipelineResult, PipelineTrace, StageTrace


async def async_run_pipeline(
    stages: list[tuple[str, Callable[..., Any]]],
    initial_input: Any = None,
    config: PipelineConfig | None = None,
) -> PipelineResult:
    """Async version of run_pipeline. Stages can be sync or async callables.

    Usage:
        result = await async_run_pipeline([
            ("plan", async_plan_fn),
            ("execute", sync_execute_fn),   # sync stages work too
            ("reflect", async_reflect_fn),
        ], initial_input="query")
    """
    cfg = config or PipelineConfig()
    trace = PipelineTrace(started_at=datetime.now(UTC).isoformat())
    completed: list[str] = []
    start = time.monotonic()
    current_output = initial_input

    if not stages:
        return PipelineResult(
            output=None, trace=trace, aborted=True,
            abort_reason="No stages provided", total_duration_ms=0.0,
        )

    for stage_name, stage_fn in stages:
        stage_start = time.monotonic()
        last_error: Exception | None = None

        for attempt in range(cfg.max_retries + 1):
            try:
                if asyncio.iscoroutinefunction(stage_fn):
                    result = await asyncio.wait_for(
                        stage_fn(current_output),
                        timeout=cfg.stage_timeout_s,
                    )
                else:
                    result = stage_fn(current_output)
                last_error = None
                break
            except TimeoutError:
                last_error = TimeoutError(
                    f"Stage '{stage_name}' timed out after {cfg.stage_timeout_s}s"
                )
            except Exception as e:
                last_error = e
                if attempt < cfg.max_retries:
                    continue

        stage_dur = (time.monotonic() - stage_start) * 1000

        if last_error is not None:
            trace.stages.append(StageTrace(
                name=stage_name, stage_type="async",
                duration_ms=stage_dur,
                output_preview=f"ERROR: {last_error}",
                passed_gate=False,
            ))
            trace.finished_at = datetime.now(UTC).isoformat()
            return PipelineResult(
                output=None, trace=trace,
                completed_stages=completed, aborted=True,
                abort_reason=f"Stage '{stage_name}' failed: {last_error}",
                total_duration_ms=(time.monotonic() - start) * 1000,
            )

        # Confidence gating
        confidence: float | None = None
        passed_gate = True
        if isinstance(result, UncertainValue):
            confidence = result.confidence
            if confidence < cfg.stage_threshold:
                passed_gate = False

        trace.stages.append(StageTrace(
            name=stage_name, stage_type="async",
            duration_ms=stage_dur,
            output_preview=str(result)[:200] if result is not None else "",
            confidence=confidence, passed_gate=passed_gate,
        ))

        if not passed_gate:
            trace.finished_at = datetime.now(UTC).isoformat()
            return PipelineResult(
                output=result, trace=trace,
                completed_stages=completed, aborted=True,
                abort_reason=(
                    f"Stage '{stage_name}' below confidence threshold"
                    f" ({confidence:.2f} < {cfg.stage_threshold})"
                ),
                total_duration_ms=(time.monotonic() - start) * 1000,
            )

        current_output = result
        completed.append(stage_name)

    trace.finished_at = datetime.now(UTC).isoformat()
    return PipelineResult(
        output=current_output, trace=trace,
        completed_stages=completed,
        total_duration_ms=(time.monotonic() - start) * 1000,
    )


async def async_parallel_stages(
    stages: list[tuple[str, Callable[..., Any]]],
    input_data: Any,
    timeout_s: float = 30.0,
) -> dict[str, Any]:
    """Run multiple stages in parallel, return dict of {name: result}.

    Useful for exploration stage where multiple paths are evaluated concurrently.
    """
    async def _run_one(name: str, fn: Callable[..., Any]) -> tuple[str, Any]:
        if asyncio.iscoroutinefunction(fn):
            result = await fn(input_data)
        else:
            result = fn(input_data)
        return name, result

    tasks = [_run_one(name, fn) for name, fn in stages]
    results = await asyncio.wait_for(
        asyncio.gather(*tasks, return_exceptions=True),
        timeout=timeout_s,
    )
    out: dict[str, Any] = {}
    for item in results:
        if isinstance(item, BaseException):
            continue
        name, result = item
        out[name] = result
    return out
