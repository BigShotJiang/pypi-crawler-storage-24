"""Reasoning pipeline: multi-stage execution with confidence gating and tracing."""

from __future__ import annotations

import time
from collections.abc import Callable
from datetime import UTC, datetime
from typing import Any

from pydantic import BaseModel, Field

from nspl.core.types import UncertainValue
from nspl.reasoning.stages import _STAGE_ORDER


class StageTrace(BaseModel):
    """Trace of a single stage execution."""

    name: str
    stage_type: str
    duration_ms: float
    output_preview: str = ""
    confidence: float | None = None
    passed_gate: bool = True

    model_config = {"arbitrary_types_allowed": True}


class PipelineTrace(BaseModel):
    """Full trace of pipeline execution."""

    stages: list[StageTrace] = Field(default_factory=list)
    started_at: str = ""
    finished_at: str = ""


class PipelineResult(BaseModel):
    """Result of a pipeline execution."""

    output: Any = None
    trace: PipelineTrace = Field(default_factory=PipelineTrace)
    completed_stages: list[str] = Field(default_factory=list)
    aborted: bool = False
    abort_reason: str | None = None
    total_duration_ms: float = 0.0

    model_config = {"arbitrary_types_allowed": True}


class PipelineConfig(BaseModel):
    """Configuration for pipeline execution."""

    stage_threshold: float = 0.5
    stage_timeout_s: float = 30.0
    max_retries: int = 0
    trace_enabled: bool = True


def pipeline(fn: Callable[..., Any]) -> Callable[..., PipelineResult]:
    """Decorator that wraps a function containing stage-decorated inner functions.

    The decorated function should define inner functions with @planning, @exploration,
    @execution, @reflection decorators. The pipeline executes them in order, passing
    each stage's output to the next.
    """

    def wrapper(*args: Any, config: PipelineConfig | None = None, **kwargs: Any) -> PipelineResult:
        cfg = config or PipelineConfig()
        trace = PipelineTrace(started_at=datetime.now(UTC).isoformat())
        completed: list[str] = []
        start = time.monotonic()

        # Collect stages from closure by calling the function and intercepting
        # We use a stage collector pattern
        stages: list[tuple[str, str, Callable[..., Any]]] = []
        collector = _StageCollector()

        # Execute the function body to collect registered stages
        fn(*args, _nspl_collector=collector, **kwargs)
        stages = collector.stages

        if not stages:
            trace.finished_at = datetime.now(UTC).isoformat()
            return PipelineResult(
                output=None,
                trace=trace,
                completed_stages=[],
                aborted=True,
                abort_reason="No stages defined",
                total_duration_ms=(time.monotonic() - start) * 1000,
            )

        # Sort by stage order
        stages.sort(key=lambda s: _STAGE_ORDER.get(s[1], 99))

        current_output: Any = args[0] if args else None

        for stage_name, stage_type, stage_fn in stages:
            stage_start = time.monotonic()

            # Retry loop
            last_error: Exception | None = None
            for attempt in range(cfg.max_retries + 1):
                try:
                    result = stage_fn(current_output)
                    last_error = None
                    break
                except Exception as e:
                    last_error = e
                    if attempt < cfg.max_retries:
                        continue

            if last_error is not None:
                stage_dur = (time.monotonic() - stage_start) * 1000
                trace.stages.append(StageTrace(
                    name=stage_name,
                    stage_type=stage_type,
                    duration_ms=stage_dur,
                    output_preview=f"ERROR: {last_error}",
                    passed_gate=False,
                ))
                trace.finished_at = datetime.now(UTC).isoformat()
                return PipelineResult(
                    output=None,
                    trace=trace,
                    completed_stages=completed,
                    aborted=True,
                    abort_reason=f"Stage '{stage_name}' failed: {last_error}",
                    total_duration_ms=(time.monotonic() - start) * 1000,
                )

            # Check confidence gating
            confidence: float | None = None
            passed_gate = True
            if isinstance(result, UncertainValue):
                confidence = result.confidence
                if confidence < cfg.stage_threshold:
                    passed_gate = False

            stage_dur = (time.monotonic() - stage_start) * 1000
            preview = str(result)[:200] if result is not None else ""
            trace.stages.append(StageTrace(
                name=stage_name,
                stage_type=stage_type,
                duration_ms=stage_dur,
                output_preview=preview,
                confidence=confidence,
                passed_gate=passed_gate,
            ))

            if not passed_gate:
                trace.finished_at = datetime.now(UTC).isoformat()
                return PipelineResult(
                    output=result,
                    trace=trace,
                    completed_stages=completed,
                    aborted=True,
                    abort_reason=(
                        f"Stage '{stage_name}' below confidence threshold"
                        f" ({confidence:.2f} < {cfg.stage_threshold})"
                    ),
                    total_duration_ms=(time.monotonic() - start) * 1000,
                )

            current_output = result
            completed.append(stage_name)

        trace.finished_at = datetime.now(UTC).isoformat()
        return PipelineResult(
            output=current_output,
            trace=trace,
            completed_stages=completed,
            total_duration_ms=(time.monotonic() - start) * 1000,
        )

    wrapper._nspl_pipeline = True  # type: ignore[attr-defined]
    return wrapper


class _StageCollector:
    """Collects stage functions during pipeline body execution."""

    def __init__(self) -> None:
        self.stages: list[tuple[str, str, Callable[..., Any]]] = []

    def add(self, name: str, stage_type: str, fn: Callable[..., Any]) -> None:
        self.stages.append((name, stage_type, fn))


def run_pipeline(
    stages: list[tuple[str, Callable[..., Any]]],
    initial_input: Any = None,
    config: PipelineConfig | None = None,
) -> PipelineResult:
    """Imperative pipeline execution -- provide a list of (name, callable) stages.

    This is the simpler alternative to the @pipeline decorator.

    Example:
        result = run_pipeline([
            ("plan", lambda q: plan_fn(q)),
            ("execute", lambda plan: exec_fn(plan)),
            ("reflect", lambda result: reflect_fn(result)),
        ], initial_input="What is 2+2?")
    """
    cfg = config or PipelineConfig()
    trace = PipelineTrace(started_at=datetime.now(UTC).isoformat())
    completed: list[str] = []
    start = time.monotonic()
    current_output = initial_input

    if not stages:
        return PipelineResult(
            output=None, trace=trace, aborted=True,
            abort_reason="No stages provided",
            total_duration_ms=0.0,
        )

    for stage_name, stage_fn in stages:
        stage_start = time.monotonic()

        last_error: Exception | None = None
        for attempt in range(cfg.max_retries + 1):
            try:
                result = stage_fn(current_output)
                last_error = None
                break
            except Exception as e:
                last_error = e
                if attempt < cfg.max_retries:
                    continue

        if last_error is not None:
            stage_dur = (time.monotonic() - stage_start) * 1000
            trace.stages.append(StageTrace(
                name=stage_name, stage_type="custom",
                duration_ms=stage_dur,
                output_preview=f"ERROR: {last_error}",
                passed_gate=False,
            ))
            trace.finished_at = datetime.now(UTC).isoformat()
            return PipelineResult(
                output=None, trace=trace,
                completed_stages=completed, aborted=True,
                abort_reason=f"Stage '{stage_name}' failed: {last_error}",
                total_duration_ms=(time.monotonic() - start) * 1000,
            )

        confidence: float | None = None
        passed_gate = True
        if isinstance(result, UncertainValue):
            confidence = result.confidence
            if confidence < cfg.stage_threshold:
                passed_gate = False

        stage_dur = (time.monotonic() - stage_start) * 1000
        trace.stages.append(StageTrace(
            name=stage_name, stage_type="custom",
            duration_ms=stage_dur,
            output_preview=str(result)[:200] if result is not None else "",
            confidence=confidence, passed_gate=passed_gate,
        ))

        if not passed_gate:
            trace.finished_at = datetime.now(UTC).isoformat()
            return PipelineResult(
                output=result, trace=trace,
                completed_stages=completed, aborted=True,
                abort_reason=(
                    f"Stage '{stage_name}' below confidence threshold"
                    f" ({confidence:.2f} < {cfg.stage_threshold})"
                ),
                total_duration_ms=(time.monotonic() - start) * 1000,
            )

        current_output = result
        completed.append(stage_name)

    trace.finished_at = datetime.now(UTC).isoformat()
    return PipelineResult(
        output=current_output, trace=trace,
        completed_stages=completed,
        total_duration_ms=(time.monotonic() - start) * 1000,
    )
