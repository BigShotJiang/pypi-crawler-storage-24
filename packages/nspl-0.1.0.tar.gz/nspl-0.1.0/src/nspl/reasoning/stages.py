"""Stage decorators for reasoning pipelines."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

_STAGE_ORDER = {"planning": 0, "exploration": 1, "execution": 2, "reflection": 3}
_NSPL_STAGE = "_nspl_stage"


def _stage_decorator(stage_name: str) -> Callable[..., Any]:
    def decorator(fn: Callable[..., Any]) -> Callable[..., Any]:
        setattr(fn, _NSPL_STAGE, stage_name)
        return fn
    return decorator


planning = _stage_decorator("planning")
exploration = _stage_decorator("exploration")
execution = _stage_decorator("execution")
reflection = _stage_decorator("reflection")
