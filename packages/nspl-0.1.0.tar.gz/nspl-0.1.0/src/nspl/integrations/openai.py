"""OpenAI function calling integration.

Requires: pip install nspl[openai]
"""

from __future__ import annotations

from typing import Any

from nspl.actions.registry import ActionRegistry
from nspl.integrations.base import ToolAdapter


class OpenAIAdapter(ToolAdapter):
    """Converts NSPL actions to OpenAI function calling format."""

    def to_tool_definitions(self, registry: Any) -> list[dict[str, Any]]:
        """Convert to OpenAI tools format: {type: 'function', function: {...}}."""
        if not isinstance(registry, ActionRegistry):
            raise TypeError("Expected ActionRegistry")
        schemas = registry.to_tool_schemas()
        tools = []
        for s in schemas:
            tools.append({
                "type": "function",
                "function": {
                    "name": s["name"],
                    "description": s["description"],
                    "parameters": s["parameters"],
                },
            })
        return tools

    def parse_tool_call(self, raw: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        """Parse OpenAI tool_call: {function: {name, arguments}}."""
        import json
        func = raw.get("function", raw)
        args = func.get("arguments", "{}")
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except json.JSONDecodeError as e:
                raise ValueError(f"Malformed JSON in tool arguments: {e}") from e
        return func["name"], args

    def format_tool_result(self, action_name: str, result: Any) -> dict[str, Any]:
        """Format as OpenAI tool message content."""
        if hasattr(result, "success"):
            return {
                "role": "tool",
                "tool_call_id": "",  # caller must set this
                "content": str(result.result) if result.success else str(result.error),
            }
        return {
            "role": "tool",
            "tool_call_id": "",
            "content": str(result),
        }


def nspl_tools(
    action_classes: list[type], registry: ActionRegistry | None = None,
) -> list[dict[str, Any]]:
    """Convenience: register actions and return OpenAI-formatted tool definitions."""
    reg = registry or ActionRegistry()
    for cls in action_classes:
        name = getattr(cls, "__name__", str(cls)).lower()
        reg.register(name, cls)
    return OpenAIAdapter().to_tool_definitions(reg)
