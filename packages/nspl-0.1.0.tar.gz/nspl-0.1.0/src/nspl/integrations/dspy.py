"""DSPy integration: use NSPL guards and actions as DSPy modules.

Provides:
  - NSPLGuardModule: DSPy module that guards input/output of any DSPy program
  - NSPLActionModule: DSPy module that wraps a verified NSPL action
  - GuardedChainOfThought: ChainOfThought with NSPL input/output guards

Requires: pip install dspy-ai
"""

from __future__ import annotations

from typing import Any


class NSPLGuardModule:
    """DSPy module that wraps another module with NSPL input/output guards.

    Usage:
        import dspy
        from nspl.integrations.dspy import NSPLGuardModule

        cot = dspy.ChainOfThought("question -> answer")
        guarded_cot = NSPLGuardModule(cot)
        result = guarded_cot(question="What is 2+2?")
    """

    def __init__(
        self,
        module: Any,
        injection_sensitivity: str = "medium",
        guard_output: bool = True,
    ) -> None:
        self._module = module
        self._injection_sensitivity = injection_sensitivity
        self._guard_output = guard_output

    def __call__(self, **kwargs: Any) -> Any:
        from nspl.guards import InputGuard, OutputGuard

        input_guard = InputGuard(injection_sensitivity=self._injection_sensitivity)

        # Guard all string inputs
        for key, value in kwargs.items():
            if isinstance(value, str):
                verdict = input_guard.check(value)
                if not verdict.allowed:
                    raise ValueError(
                        f"Input guard blocked field '{key}': {verdict.reason}"
                    )
                kwargs[key] = verdict.sanitized_text or value

        # Run the wrapped module
        result = self._module(**kwargs)

        # Guard string outputs
        if self._guard_output:
            output_guard = OutputGuard(redact_pii=True)
            if hasattr(result, "__dict__"):
                for key, value in vars(result).items():
                    if isinstance(value, str):
                        verdict = output_guard.check(value)
                        if not verdict.allowed:
                            setattr(result, key, f"[BLOCKED: {verdict.reason}]")
                        elif verdict.filtered_text != value:
                            setattr(result, key, verdict.filtered_text)

        return result


class NSPLActionModule:
    """DSPy module wrapping a verified NSPL action.

    Exposes the action as a callable DSPy module. The LLM provides
    parameters, NSPL verifies them, and the action executes.

    Usage:
        refund_module = NSPLActionModule(ProcessRefund, ctx)
        result = refund_module(order_id="123", amount=49.99)
    """

    def __init__(self, action_cls: type, ctx: Any) -> None:
        self._action_cls = action_cls
        self._ctx = ctx

    def __call__(self, **kwargs: Any) -> dict[str, Any]:
        instance = self._action_cls(**kwargs)
        result = instance.safe_execute(self._ctx)
        return {
            "success": result.success,
            "result": result.result,
            "error": result.error,
            "audit": [
                {"stage": e.stage, "check": e.check_name, "passed": e.passed}
                for e in result.audit_trail
            ],
        }


class GuardedPredict:
    """Drop-in replacement for dspy.Predict with NSPL guards.

    Usage:
        # Instead of: predict = dspy.Predict("question -> answer")
        predict = GuardedPredict("question -> answer")
        result = predict(question="What is 2+2?")
    """

    def __init__(self, signature: str, **kwargs: Any) -> None:
        self._signature = signature
        self._kwargs = kwargs
        self._predict: Any = None
        self._input_guard: Any = None
        self._output_guard: Any = None

    def _ensure_loaded(self) -> None:
        if self._predict is None:
            try:
                import dspy
                self._predict = dspy.Predict(self._signature, **self._kwargs)
            except ImportError:
                raise ImportError("dspy not installed: pip install dspy-ai") from None
            from nspl.guards import InputGuard, OutputGuard
            self._input_guard = InputGuard()
            self._output_guard = OutputGuard(redact_pii=True)

    def __call__(self, **kwargs: Any) -> Any:
        self._ensure_loaded()

        # Guard inputs
        for key, value in kwargs.items():
            if isinstance(value, str):
                verdict = self._input_guard.check(value)
                if not verdict.allowed:
                    raise ValueError(
                        f"NSPL guard blocked input '{key}': {verdict.reason}"
                    )
                kwargs[key] = verdict.sanitized_text or value

        # Run prediction
        result = self._predict(**kwargs)

        # Guard outputs
        if hasattr(result, "__dict__"):
            for key, value in vars(result).items():
                if isinstance(value, str) and not key.startswith("_"):
                    verdict = self._output_guard.check(value)
                    if not verdict.allowed:
                        setattr(result, key, f"[BLOCKED: {verdict.reason}]")
                    elif verdict.filtered_text and verdict.filtered_text != value:
                        setattr(result, key, verdict.filtered_text)

        return result
