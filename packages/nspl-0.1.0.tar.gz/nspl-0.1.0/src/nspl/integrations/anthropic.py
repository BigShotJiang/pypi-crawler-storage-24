"""Anthropic Claude tool_use integration.

Requires: pip install nspl[anthropic]
"""

from __future__ import annotations

from typing import Any

from nspl.actions.registry import ActionRegistry
from nspl.integrations.base import ToolAdapter


class AnthropicAdapter(ToolAdapter):
    """Converts NSPL actions to Anthropic tool_use format."""

    def to_tool_definitions(self, registry: Any) -> list[dict[str, Any]]:
        """Convert to Anthropic tool format: {name, description, input_schema}."""
        if not isinstance(registry, ActionRegistry):
            raise TypeError("Expected ActionRegistry")
        schemas = registry.to_tool_schemas()
        tools = []
        for s in schemas:
            tools.append({
                "name": s["name"],
                "description": s["description"],
                "input_schema": s["parameters"],
            })
        return tools

    def parse_tool_call(self, raw: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        """Parse Anthropic tool_use block: {type: 'tool_use', name, input}."""
        return raw["name"], raw.get("input", {})

    def format_tool_result(self, action_name: str, result: Any) -> dict[str, Any]:
        """Format as Anthropic tool_result content block."""
        if hasattr(result, "success"):
            return {
                "type": "tool_result",
                "tool_use_id": "",  # caller must set this
                "content": str(result.result) if result.success else str(result.error),
                "is_error": not result.success,
            }
        return {
            "type": "tool_result",
            "tool_use_id": "",
            "content": str(result),
        }


def nspl_tools(
    action_classes: list[type], registry: ActionRegistry | None = None,
) -> list[dict[str, Any]]:
    """Convenience: register actions and return Anthropic-formatted tool definitions."""
    reg = registry or ActionRegistry()
    for cls in action_classes:
        name = getattr(cls, "__name__", str(cls)).lower()
        reg.register(name, cls)
    return AnthropicAdapter().to_tool_definitions(reg)


def handle_tool_use(
    tool_use_block: dict[str, Any],
    registry: ActionRegistry,
    ctx: Any,
) -> Any:
    """Execute NSPL-verified action from a Claude tool_use block.

    Validates parameter names against the action's __init__ signature
    before instantiation to prevent unexpected keyword injection.
    """
    import inspect

    adapter = AnthropicAdapter()
    action_name, params = adapter.parse_tool_call(tool_use_block)
    action_cls = registry.get(action_name)

    # Validate params against expected signature
    try:
        sig = inspect.signature(action_cls)
        valid_params = set(sig.parameters.keys()) - {"self"}
        unknown = set(params.keys()) - valid_params
        if unknown:
            from nspl.actions.exceptions import PreconditionError
            raise PreconditionError(
                f"Unknown parameters for {action_name}: {unknown}"
            )
    except (ValueError, TypeError):
        pass  # can't inspect signature, allow through

    instance = action_cls(**params)
    return instance.safe_execute(ctx)
