"""Provider-agnostic agent framework integrations.

Each provider is an optional submodule:
  nspl.integrations.anthropic  -- Claude tool_use
  nspl.integrations.openai     -- OpenAI function calling
  nspl.integrations.google_adk -- Google ADK
  nspl.integrations.mcp        -- Model Context Protocol

Core actions and reasoning pipelines have ZERO provider dependencies.
Integrations are thin adapters that convert NSPL actions into
provider-specific tool schemas and handle provider-specific response formats.
"""
