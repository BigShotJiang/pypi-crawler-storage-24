"""LangChain Tool integration.

Wraps NSPL actions as LangChain-compatible Tool objects.
Also provides a GuardedLLM as a LangChain-compatible LLM wrapper.

Requires: pip install langchain-core
"""

from __future__ import annotations

from typing import Any


class NSPLTool:
    """LangChain-compatible Tool wrapping an NSPL verified action.

    Implements the LangChain Tool interface:
      - name: str
      - description: str
      - func: Callable[[str], str]
      - args_schema: dict (JSON schema)

    Usage with LangChain:
        from nspl.integrations.langchain import nspl_langchain_tools
        tools = nspl_langchain_tools([ProcessRefund], ctx)
        agent = initialize_agent(tools, llm, agent="zero-shot-react-description")
    """

    def __init__(self, name: str, action_cls: type, ctx: Any) -> None:
        self.name = name
        self.description = action_cls.__doc__ or f"Execute {name}"
        self._action_cls = action_cls
        self._ctx = ctx
        self.args_schema = _extract_schema(action_cls)

    def __call__(self, **kwargs: Any) -> str:
        """Execute the verified action. Called by LangChain agent."""
        return self.run(**kwargs)

    def run(self, **kwargs: Any) -> str:
        """Execute with verification."""
        import json
        instance = self._action_cls(**kwargs)
        result = instance.safe_execute(self._ctx)
        return json.dumps({
            "success": result.success,
            "result": str(result.result) if result.success else None,
            "error": result.error,
        })

    @property
    def is_single_input(self) -> bool:
        return False

    def _run(self, tool_input: str, **kwargs: Any) -> str:
        """LangChain StructuredTool compatibility."""
        import json
        try:
            params = json.loads(tool_input) if isinstance(tool_input, str) else tool_input
        except json.JSONDecodeError:
            params = {"input": tool_input}
        return self.run(**params)


def _extract_schema(cls: type) -> dict[str, Any]:
    """Extract JSON schema from action class."""
    import inspect
    properties: dict[str, Any] = {}
    try:
        sig = inspect.signature(cls)
        for pname, param in sig.parameters.items():
            if pname == "self":
                continue
            ptype = "string"
            if param.annotation in (int, "int"):
                ptype = "integer"
            elif param.annotation in (float, "float"):
                ptype = "number"
            elif param.annotation in (bool, "bool"):
                ptype = "boolean"
            properties[pname] = {"type": ptype, "description": pname}
    except (ValueError, TypeError):
        pass
    return {
        "type": "object",
        "properties": properties,
        "required": list(properties.keys()),
    }


def nspl_langchain_tools(
    action_classes: list[type], ctx: Any,
) -> list[NSPLTool]:
    """Create LangChain-compatible tools from NSPL action classes."""
    tools = []
    for cls in action_classes:
        name = getattr(cls, "__name__", str(cls)).lower()
        tools.append(NSPLTool(name, cls, ctx))
    return tools
