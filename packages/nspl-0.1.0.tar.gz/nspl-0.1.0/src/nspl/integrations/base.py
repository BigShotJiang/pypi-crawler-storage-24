"""Base adapter interface for provider integrations.

All provider submodules (anthropic, openai, google_adk, mcp) implement
this interface. Application code can program against the base interface
and swap providers without changing business logic.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class ToolAdapter(ABC):
    """Converts NSPL actions into provider-specific tool definitions."""

    @abstractmethod
    def to_tool_definitions(self, registry: Any) -> list[dict[str, Any]]:
        """Convert registered actions to provider-specific tool schema format."""
        ...

    @abstractmethod
    def parse_tool_call(self, raw: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        """Parse a provider-specific tool call into (action_name, params)."""
        ...

    @abstractmethod
    def format_tool_result(self, action_name: str, result: Any) -> dict[str, Any]:
        """Format an action result into provider-specific response format."""
        ...
