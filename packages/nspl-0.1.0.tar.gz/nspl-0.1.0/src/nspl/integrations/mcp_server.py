"""MCP tool server: expose NSPL guards and actions over Model Context Protocol.

Any MCP-compatible agent (Claude Code, Gemini CLI, Codex) can connect
to this server and get input/output guards + verified action execution.

Usage (stdio):
    python -m nspl.integrations.mcp_server

Usage (in MCP config):
    {
      "mcpServers": {
        "nspl": {
          "command": "python",
          "args": ["-m", "nspl.integrations.mcp_server"]
        }
      }
    }

Requires: pip install nspl[mcp]  (mcp>=1.0)
"""

from __future__ import annotations

import json
from typing import Any

# Guard defaults
_input_guard = None
_output_guard = None
_action_registry = None


def _get_input_guard() -> Any:
    global _input_guard  # noqa: PLW0603
    if _input_guard is None:
        from nspl.guards import InputGuard
        _input_guard = InputGuard(injection_sensitivity="medium")
    return _input_guard


def _get_output_guard() -> Any:
    global _output_guard  # noqa: PLW0603
    if _output_guard is None:
        from nspl.guards import OutputGuard
        _output_guard = OutputGuard(redact_pii=True)
    return _output_guard


def _get_registry() -> Any:
    global _action_registry  # noqa: PLW0603
    if _action_registry is None:
        from nspl.actions import ActionRegistry
        _action_registry = ActionRegistry()
    return _action_registry


def create_server() -> Any:
    """Create and configure the MCP server with NSPL tools."""
    try:
        from mcp.server.fastmcp import FastMCP
    except ImportError:
        raise ImportError(
            "MCP server requires the 'mcp' package. "
            "Install with: pip install nspl[mcp]"
        ) from None

    mcp = FastMCP("nspl")

    @mcp.tool()
    def guard_input(text: str, sensitivity: str = "medium") -> str:
        """Check user input for prompt injections, PII, and dangerous content.

        Returns JSON with: allowed (bool), reason, risk_score, detections.
        Run this BEFORE sending user input to an LLM.

        Args:
            text: The user input to check
            sensitivity: Detection sensitivity - "low", "medium", or "high"
        """
        from nspl.guards import InputGuard

        guard = InputGuard(injection_sensitivity=sensitivity)
        verdict = guard.check(text)
        return json.dumps({
            "allowed": verdict.allowed,
            "reason": verdict.reason,
            "risk_score": verdict.risk_score,
            "sanitized_text": verdict.sanitized_text,
            "detections": [
                {
                    "name": d.detector_name,
                    "triggered": d.triggered,
                    "detail": d.detail,
                }
                for d in verdict.detections
            ],
        }, indent=2)

    @mcp.tool()
    def guard_output(
        text: str, system_prompt: str | None = None
    ) -> str:
        """Check LLM output for dangerous content, PII leakage, and prompt leakage.

        Returns JSON with: allowed (bool), filtered_text, reason, detections.
        Run this AFTER receiving LLM output, BEFORE returning to user.

        Args:
            text: The LLM output to check
            system_prompt: Optional system prompt to check for leakage
        """
        guard = _get_output_guard()
        verdict = guard.check(text, original_prompt=system_prompt)
        return json.dumps({
            "allowed": verdict.allowed,
            "filtered_text": verdict.filtered_text,
            "reason": verdict.reason,
            "risk_score": verdict.risk_score,
            "detections": [
                {
                    "name": d.detector_name,
                    "triggered": d.triggered,
                    "detail": d.detail,
                }
                for d in verdict.detections
            ],
        }, indent=2)

    @mcp.tool()
    def detect_pii(text: str) -> str:
        """Detect personally identifiable information in text.

        Returns JSON with: found (bool), matches (list of {type, value}).
        Detects: SSN, email, phone, credit card, IP address, date of birth.

        Args:
            text: Text to scan for PII
        """
        from nspl.guards import PIIDetector

        result = PIIDetector().detect(text)
        return json.dumps({
            "found": result.triggered,
            "count": len(result.matches),
            "matches": result.matches,
            "detail": result.detail,
        }, indent=2)

    @mcp.tool()
    def evaluate_logic(expression: str, mode: str = "hard") -> str:
        """Evaluate a boolean/fuzzy logic expression using NSPL gates.

        Supports: AND, OR, NOT, XOR, IMPLIES with boolean or float [0,1] inputs.
        Mode "hard" gives exact boolean; "soft" gives fuzzy [0,1] output.

        Args:
            expression: Logic expression, e.g. "AND(True, OR(False, True))"
            mode: "hard" (exact boolean) or "soft" (fuzzy)
        """
        from nspl.core.logic_gates import AND, IMPLIES, NOT, OR, XOR

        gate_mode = "hard" if mode == "hard" else "soft"
        # Safe evaluation with only gate functions available
        safe_ns: dict[str, Any] = {
            "AND": lambda *a: AND(*a, mode=gate_mode),  # type: ignore[arg-type]
            "OR": lambda *a: OR(*a, mode=gate_mode),  # type: ignore[arg-type]
            "NOT": lambda a: NOT(a, mode=gate_mode),  # type: ignore[arg-type]
            "XOR": lambda *a: XOR(*a, mode=gate_mode),  # type: ignore[arg-type]
            "IMPLIES": lambda a, b: IMPLIES(a, b, mode=gate_mode),  # type: ignore[arg-type]
            "True": True, "False": False,
        }
        try:
            result = eval(expression, {"__builtins__": {}}, safe_ns)  # noqa: S307
            return json.dumps({"result": result, "expression": expression, "mode": mode})
        except Exception as e:
            return json.dumps({"error": str(e), "expression": expression})

    return mcp


def main() -> None:
    """Run the MCP server (stdio transport)."""
    server = create_server()
    server.run()


if __name__ == "__main__":
    main()
