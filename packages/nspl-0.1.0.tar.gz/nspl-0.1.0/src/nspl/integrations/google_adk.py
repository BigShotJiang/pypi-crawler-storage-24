"""Google Agent Development Kit (ADK) integration.

Wraps NSPL actions as ADK-compatible tool definitions.

Requires: pip install nspl[google-adk]  (google-cloud-aiplatform)
"""

from __future__ import annotations

from typing import Any

from nspl.actions.registry import ActionRegistry
from nspl.integrations.base import ToolAdapter


class GoogleADKAdapter(ToolAdapter):
    """Converts NSPL actions to Google ADK function declarations."""

    def to_tool_definitions(self, registry: Any) -> list[dict[str, Any]]:
        """Convert to ADK FunctionDeclaration format."""
        if not isinstance(registry, ActionRegistry):
            raise TypeError("Expected ActionRegistry")
        schemas = registry.to_tool_schemas()
        tools = []
        for s in schemas:
            tools.append({
                "name": s["name"],
                "description": s["description"],
                "parameters": {
                    "type": "OBJECT",
                    "properties": {
                        k: {"type": _to_adk_type(v.get("type", "STRING"))}
                        for k, v in s["parameters"].get("properties", {}).items()
                    },
                    "required": s["parameters"].get("required", []),
                },
            })
        return tools

    def parse_tool_call(self, raw: dict[str, Any]) -> tuple[str, dict[str, Any]]:
        """Parse ADK function call response."""
        # ADK format: {"name": "fn_name", "args": {...}}
        return raw.get("name", ""), raw.get("args", {})

    def format_tool_result(self, action_name: str, result: Any) -> dict[str, Any]:
        """Format as ADK function response."""
        if hasattr(result, "success"):
            return {
                "name": action_name,
                "response": {
                    "result": str(result.result) if result.success else str(result.error),
                },
            }
        return {"name": action_name, "response": {"result": str(result)}}


def _to_adk_type(json_type: str) -> str:
    """Map JSON schema type to ADK parameter type."""
    return {
        "string": "STRING",
        "integer": "INTEGER",
        "number": "NUMBER",
        "boolean": "BOOLEAN",
        "array": "ARRAY",
        "object": "OBJECT",
    }.get(json_type, "STRING")


def nspl_tools(
    action_classes: list[type], registry: ActionRegistry | None = None,
) -> list[dict[str, Any]]:
    """Convenience: register actions and return ADK tool definitions."""
    reg = registry or ActionRegistry()
    for cls in action_classes:
        name = getattr(cls, "__name__", str(cls)).lower()
        reg.register(name, cls)
    return GoogleADKAdapter().to_tool_definitions(reg)
