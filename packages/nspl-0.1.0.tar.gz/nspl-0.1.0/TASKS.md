# NSPL Autonomous Task List

**Execution model**: Follow tasks sequentially. Each task has entry criteria, exact steps, exit criteria, and failure protocol. No human input required. If a task fails, follow its failure protocol before proceeding.

**Notation**:
- `ENTRY`: What must be true before starting
- `DO`: Exact steps to execute
- `EXIT`: How to confirm completion
- `FAIL`: What to do if EXIT criteria not met
- `OUTPUT`: Files created or modified

---

## PHASE 0: BOOTSTRAP

### T-000: Initialize git repository
- ENTRY: `/mnt/projects/nspl/` exists with current files
- DO:
  1. `cd /mnt/projects/nspl && git init`
  2. Create `.gitignore`:
     ```
     __pycache__/
     *.pyc
     .mypy_cache/
     .pytest_cache/
     .ruff_cache/
     dist/
     *.egg-info/
     .venv/
     venv/
     .env
     *.so
     experiments/*/results/
     experiments/*/data/raw/
     ```
  3. `git add -A && git commit -m "Initial commit: project scaffold + design docs"`
- EXIT: `git log --oneline` shows 1 commit. `git status` is clean.
- FAIL: Fix any git errors, retry.
- OUTPUT: `.git/`, `.gitignore`

### T-001: Create GitHub remote
- ENTRY: T-000 complete
- DO:
  1. `gh repo create astoreyai/nspl --private --source=. --push`
  2. If repo exists: `git remote add origin git@github.com:astoreyai/nspl.git && git push -u origin main`
- EXIT: `gh repo view astoreyai/nspl` succeeds
- FAIL: If auth fails, create repo manually via `gh auth login` then retry.
- OUTPUT: Remote `origin` configured

### T-002: Set up CI/CD
- ENTRY: T-001 complete
- DO:
  1. Create `.github/workflows/ci.yml`:
     ```yaml
     name: CI
     on: [push, pull_request]
     jobs:
       test:
         runs-on: ubuntu-latest
         strategy:
           matrix:
             python-version: ["3.11", "3.12"]
         steps:
           - uses: actions/checkout@v4
           - uses: actions/setup-python@v5
             with:
               python-version: ${{ matrix.python-version }}
           - run: pip install -e ".[dev]"
           - run: ruff check src/ tests/
           - run: mypy src/
           - run: pytest --tb=short
     ```
  2. Commit and push.
- EXIT: `gh run list` shows a CI run (pass or fail is ok at this stage -- package is empty).
- FAIL: Fix YAML syntax, retry push.
- OUTPUT: `.github/workflows/ci.yml`

### T-003: Write README.md
- ENTRY: T-000 complete
- DO:
  1. Create `README.md` with:
     - One-line description: "Logic-gated verification for agentic AI"
     - Install: `pip install nspl`
     - 10-line quickstart code example (import, define action, execute)
     - Link to ROADMAP.md
     - License: MIT
  2. No badges until CI is green.
- EXIT: `README.md` exists, is under 80 lines, contains install + example.
- FAIL: N/A -- text file.
- OUTPUT: `README.md`

### T-004: Verify local dev environment
- ENTRY: T-000 complete, `pyproject.toml` exists
- DO:
  1. `cd /mnt/projects/nspl`
  2. `python -m venv .venv && source .venv/bin/activate`
  3. `pip install -e ".[dev]"`
  4. `python -c "import nspl; print(nspl.__version__)"`  -- must print `0.1.0`
  5. `pytest` -- must exit 0 (no tests yet, 0 collected is fine)
  6. `ruff check src/` -- must exit 0
  7. `mypy src/` -- must exit 0
- EXIT: All 4 commands succeed.
- FAIL: Fix import errors or dependency issues in `pyproject.toml`, retry.
- OUTPUT: `.venv/` (gitignored)

---

## PHASE 1A: LOGIC GATES

### T-100: Implement pure-Python logic gates
- ENTRY: T-004 complete
- DO:
  1. Create `src/nspl/core/logic_gates.py`
  2. Implement these callables (plain functions, no torch dependency):
     ```
     AND(*inputs: float | bool, threshold: float = 0.5) -> float
     OR(*inputs: float | bool, threshold: float = 0.5) -> float
     NOT(input: float | bool, threshold: float = 0.5) -> float
     XOR(*inputs: float | bool) -> float
     IMPLIES(a: float | bool, b: float | bool) -> float
     WEIGHTED_AND(inputs: list[float], weights: list[float]) -> float
     ```
  3. Implementation rules:
     - Boolean inputs coerced to 0.0/1.0
     - Float inputs in [0,1] treated as fuzzy truth values
     - AND: `sigmoid(k * (sum(w_i * (x_i - t_i)) / n))` where k=10 (steepness), default weights uniform, default thresholds from parameter
     - OR: De Morgan: `NOT(AND(NOT(x_i) for x_i in inputs))`
     - NOT: `1.0 - x` (simple complement for fuzzy), `sigmoid(k * (threshold - x))` for hard
     - XOR: `(a OR b) AND NOT(a AND b)` for 2 inputs; parity for N inputs
     - IMPLIES: `OR(NOT(a), b)`
     - WEIGHTED_AND: `sigmoid(k * (sum(w_i * x_i) / sum(w_i) - threshold))`
  4. Each gate must accept `mode: Literal["soft", "hard"] = "soft"`:
     - `"soft"`: sigmoid-based, differentiable
     - `"hard"`: step function, exact boolean
  5. Export all gates from `nspl.core.__init__.py`
- EXIT: `python -c "from nspl.core.logic_gates import AND, OR, NOT, XOR, IMPLIES, WEIGHTED_AND"` succeeds. `mypy src/` passes.
- FAIL: Fix type errors, re-run mypy.
- OUTPUT: `src/nspl/core/logic_gates.py`

### T-101: Unit tests for logic gates
- ENTRY: T-100 complete
- DO:
  1. Create `tests/test_logic_gates.py`
  2. Test cases (hard mode, exact boolean):
     ```
     AND(True, True) == 1.0
     AND(True, False) == 0.0
     AND(False, False) == 0.0
     OR(True, False) == 1.0
     OR(False, False) == 0.0
     NOT(True) == 0.0
     NOT(False) == 1.0
     XOR(True, False) == 1.0
     XOR(True, True) == 0.0
     IMPLIES(True, False) == 0.0
     IMPLIES(False, True) == 1.0
     IMPLIES(False, False) == 1.0
     ```
  3. Test cases (soft mode, fuzzy):
     ```
     AND(0.9, 0.9) > 0.7  # high inputs -> high output
     AND(0.1, 0.9) < 0.3  # one low -> low output
     OR(0.1, 0.9) > 0.7   # one high -> high output
     NOT(0.9) < 0.3
     NOT(0.1) > 0.7
     ```
  4. Test N-ary gates: `AND(0.9, 0.9, 0.9, 0.9)` > 0.5
  5. Test WEIGHTED_AND with extreme weights: `WEIGHTED_AND([0.1, 0.9], [0.0, 1.0])` ~= behavior of just second input
  6. Edge cases: empty inputs (should raise ValueError), single input, NaN input (should raise ValueError)
- EXIT: `pytest tests/test_logic_gates.py -v` -- all pass.
- FAIL: Fix logic gate implementation, re-run.
- OUTPUT: `tests/test_logic_gates.py`

### T-102: Property-based tests for logic gates
- ENTRY: T-101 complete
- DO:
  1. Add to `tests/test_logic_gates.py` (or new file `tests/test_logic_gates_properties.py`):
  2. Using `hypothesis`:
     ```python
     from hypothesis import given, strategies as st

     fuzzy = st.floats(min_value=0.0, max_value=1.0, allow_nan=False)

     # Commutativity
     @given(fuzzy, fuzzy)
     def test_and_commutative(a, b):
         assert abs(AND(a, b) - AND(b, a)) < 1e-6

     @given(fuzzy, fuzzy)
     def test_or_commutative(a, b):
         assert abs(OR(a, b) - OR(b, a)) < 1e-6

     # De Morgan's Laws (approximate for soft mode)
     @given(fuzzy, fuzzy)
     def test_de_morgan_and(a, b):
         lhs = NOT(AND(a, b))
         rhs = OR(NOT(a), NOT(b))
         assert abs(lhs - rhs) < 0.15  # tolerance for sigmoid approx

     @given(fuzzy, fuzzy)
     def test_de_morgan_or(a, b):
         lhs = NOT(OR(a, b))
         rhs = AND(NOT(a), NOT(b))
         assert abs(lhs - rhs) < 0.15

     # Idempotence
     @given(fuzzy)
     def test_and_idempotent(a):
         assert abs(AND(a, a) - a) < 0.2  # soft approx

     # Identity
     @given(fuzzy)
     def test_and_identity(a):
         assert abs(AND(a, 1.0) - a) < 0.2

     @given(fuzzy)
     def test_or_identity(a):
         assert abs(OR(a, 0.0) - a) < 0.2

     # Double negation
     @given(fuzzy)
     def test_double_negation(a):
         assert abs(NOT(NOT(a)) - a) < 0.1

     # Monotonicity: if a <= b then AND(a, c) <= AND(b, c)
     @given(fuzzy, fuzzy, fuzzy)
     def test_and_monotone(a, b, c):
         if a <= b:
             assert AND(a, c) <= AND(b, c) + 1e-6
     ```
  3. Run with `pytest --hypothesis-seed=42` for reproducibility.
- EXIT: `pytest tests/test_logic_gates_properties.py -v` -- all pass. If De Morgan tolerance too tight, widen to 0.2 and document why.
- FAIL: If properties fail, the sigmoid steepness `k` needs tuning. Increase `k` and retest. Document final `k` value.
- OUTPUT: `tests/test_logic_gates_properties.py`

### T-103: Torch-backed trainable logic gates (optional dependency)
- ENTRY: T-102 complete
- DO:
  1. Create `src/nspl/core/torch_gates.py`
  2. Implement `TorchAND(nn.Module)`, `TorchOR(nn.Module)`, `TorchNOT(nn.Module)`:
     - Learnable parameters: `threshold` (nn.Parameter), `weight` (nn.Parameter), `steepness` (nn.Parameter)
     - Forward: same sigmoid formula as T-100 but using `torch.sigmoid`
  3. Guard import: `try: import torch ... except ImportError: raise ImportError("Install nspl[torch]")`
  4. Add factory function:
     ```python
     def trainable_gate(gate_type: str, n_inputs: int) -> nn.Module
     ```
  5. Do NOT make this a hard dependency. Core gates from T-100 must work without torch.
- EXIT: If torch installed: `python -c "from nspl.core.torch_gates import TorchAND; g = TorchAND(2); print(g(torch.tensor([0.9, 0.9])))"` prints a value > 0.5. If torch not installed: `from nspl.core.logic_gates import AND` still works.
- FAIL: If torch import issues, verify `nspl[torch]` extras in pyproject.toml.
- OUTPUT: `src/nspl/core/torch_gates.py`

### T-104: Logic gate benchmarking harness
- ENTRY: T-101 complete
- DO:
  1. Create `experiments/exp1_gate_accuracy/run.py`
  2. Script generates:
     - 10,000 random boolean expressions (depth 1-5, operators AND/OR/NOT/XOR/IMPLIES)
     - Each expression uses 2-6 boolean variables with random True/False assignments
  3. Evaluates each expression three ways:
     - **Ground truth**: Python `eval()` of equivalent Python boolean expression
     - **NSPL hard mode**: NSPL gates with `mode="hard"` and boolean inputs
     - **NSPL soft mode**: NSPL gates with `mode="soft"` and boolean inputs (0.0/1.0)
  4. Records per-expression: expression string, ground truth, nspl_hard result, nspl_soft result, nspl_soft raw float
  5. Computes:
     - Accuracy: fraction where round(nspl_result) == ground_truth
     - Mean absolute error of soft mode raw floats vs. ground truth (0/1)
     - Histogram of soft mode outputs (should be bimodal near 0 and 1 for boolean inputs)
  6. Saves results to `experiments/exp1_gate_accuracy/results/gate_accuracy.json`
  7. Saves summary to `experiments/exp1_gate_accuracy/results/summary.md`
  8. NO LLM calls yet -- that comparison happens in T-105.
- EXIT: Script runs in <60s. Hard mode accuracy = 100%. Soft mode accuracy >= 99%. Results files exist.
- FAIL: If soft mode accuracy < 99%, steepness `k` is too low. Return to T-100, increase `k`, re-run T-101, T-102, T-104.
- OUTPUT: `experiments/exp1_gate_accuracy/run.py`, `experiments/exp1_gate_accuracy/results/`

### T-105: Experiment 1 -- LLM comparison arm
- ENTRY: T-104 complete with >= 99% soft mode accuracy
- DO:
  1. Create `experiments/exp1_gate_accuracy/run_llm.py`
  2. Sample 500 expressions from the 10K set (stratified by depth: 100 per depth 1-5)
  3. For each expression, construct a prompt:
     ```
     Evaluate the following boolean expression. Variables are assigned as shown.
     Return ONLY "True" or "False".

     Expression: (A AND B) OR (NOT C)
     A = True, B = False, C = True

     Answer:
     ```
  4. Call two models:
     - Claude Sonnet (anthropic SDK, `claude-sonnet-4-20250514`)
     - GPT-4o-mini (openai SDK, `gpt-4o-mini`)
  5. Parse response: strip whitespace, match "True"/"False" case-insensitive. If unparseable, mark as error.
  6. Record: expression, ground_truth, claude_answer, gpt_answer, claude_parseable, gpt_parseable
  7. Compute per-model:
     - Accuracy (excluding unparseable)
     - Parse failure rate
     - Accuracy by depth
     - Latency (mean, p50, p95)
  8. Save: `experiments/exp1_gate_accuracy/results/llm_comparison.json`
  9. Generate comparison table in `experiments/exp1_gate_accuracy/results/exp1_report.md`:
     ```
     | Method        | Accuracy | Latency (p50) | Errors |
     |---------------|----------|---------------|--------|
     | Python eval   | 100%     | <1ms          | 0      |
     | NSPL hard     | X%       | Xms           | 0      |
     | NSPL soft     | X%       | Xms           | 0      |
     | Claude Sonnet | X%       | Xms           | X      |
     | GPT-4o-mini   | X%       | Xms           | X      |
     ```
  10. **Statistical test**: McNemar's test (paired, NSPL vs each LLM) on the 500 shared examples. Report p-value. Significance threshold: p < 0.05.
- EXIT: Report file exists. All numbers populated. Statistical test computed.
- FAIL: If API calls fail, implement retry with exponential backoff (max 3 retries). If budget exceeded, reduce sample to 200.
- OUTPUT: `experiments/exp1_gate_accuracy/run_llm.py`, `experiments/exp1_gate_accuracy/results/exp1_report.md`

### T-106: Commit Phase 1A
- ENTRY: T-100 through T-105 complete. All tests pass.
- DO:
  1. `ruff check src/ tests/ experiments/ --fix`
  2. `mypy src/`
  3. `pytest`
  4. `git add -A && git commit -m "Phase 1A: Logic gates with property tests + Experiment 1"`
  5. `git push`
- EXIT: CI green.
- FAIL: Fix lint/type/test errors, re-commit.
- OUTPUT: Git commit

---

## PHASE 1B: TYPES AND UNCERTAINTY

### T-110: Implement UncertainValue
- ENTRY: T-106 complete
- DO:
  1. Create `src/nspl/core/types.py`
  2. Implement `UncertainValue[T]` as a generic Pydantic `BaseModel`:
     ```python
     class UncertainValue(BaseModel, Generic[T]):
         value: T
         confidence: float = Field(ge=0.0, le=1.0)
         distribution: Distribution | None = None

         def map(self, fn: Callable[[T], U]) -> UncertainValue[U]: ...
         def flat_map(self, fn: Callable[[T], UncertainValue[U]]) -> UncertainValue[U]: ...
         def require(self, threshold: float, fallback: Callable[[], T]) -> T: ...
         def sample(self, n: int = 1000) -> list[T]: ...
     ```
  3. `map`: applies `fn` to `value`. Confidence preserved. If distribution exists, propagate via Monte Carlo (draw N=1000 samples, apply fn, fit new distribution).
  4. `flat_map`: applies `fn`, composes confidences multiplicatively: `new_confidence = self.confidence * result.confidence`.
  5. `require`: returns `value` if `confidence >= threshold`, else calls `fallback()`.
  6. Confidence composition rules:
     - Sequential operations (flat_map): multiply confidences
     - Parallel operations (AND of uncertain values): min confidence
     - Negation: confidence preserved
- EXIT: `python -c "from nspl.core.types import UncertainValue; v = UncertainValue(value=42, confidence=0.9); print(v.map(lambda x: x*2))"` prints `UncertainValue(value=84, confidence=0.9, ...)`
- FAIL: Fix Pydantic generics issues (known to be tricky). Fall back to `Any` type parameter if generic validation fails.
- OUTPUT: `src/nspl/core/types.py`

### T-111: Implement Distribution wrapper
- ENTRY: T-110 complete
- DO:
  1. Create `src/nspl/core/uncertainty.py`
  2. Implement `Distribution` as an abstract base with concrete implementations:
     ```python
     class Distribution(ABC):
         def sample(self, n: int) -> np.ndarray: ...
         def pdf(self, x: float) -> float: ...
         def cdf(self, x: float) -> float: ...
         def mean(self) -> float: ...
         def std(self) -> float: ...

     class Normal(Distribution):
         def __init__(self, mean: float, std: float): ...

     class Uniform(Distribution):
         def __init__(self, low: float, high: float): ...

     class Categorical(Distribution):
         def __init__(self, categories: dict[str, float]): ...
         # categories maps label -> probability, must sum to ~1.0

     class Empirical(Distribution):
         def __init__(self, samples: np.ndarray): ...
         # non-parametric, from observed samples
     ```
  3. Back with `scipy.stats` for Normal, Uniform. Categorical and Empirical are custom.
  4. Implement `propagate(fn, dist, n_samples=1000) -> Empirical`:
     - Draw n_samples from dist
     - Apply fn to each
     - Return Empirical distribution of results
- EXIT: `pytest tests/test_uncertainty.py -v` passes with tests for Normal sampling, propagation, Categorical.
- FAIL: If scipy import fails, add to dependencies in pyproject.toml.
- OUTPUT: `src/nspl/core/uncertainty.py`

### T-112: Tests for types and uncertainty
- ENTRY: T-111 complete
- DO:
  1. Create `tests/test_types.py`:
     - UncertainValue construction, validation (confidence out of range raises)
     - `map` preserves confidence
     - `flat_map` multiplies confidences
     - `require` returns value when confident, fallback when not
  2. Create `tests/test_uncertainty.py`:
     - Normal distribution: mean and std of 10K samples within 5% of parameters
     - Propagation: `propagate(lambda x: x**2, Normal(0, 1))` should have mean ~1.0 (variance of standard normal)
     - Categorical: samples respect probability weights (chi-squared test, p > 0.01)
     - Empirical: from samples, pdf is kernel density estimate
- EXIT: `pytest tests/test_types.py tests/test_uncertainty.py -v` -- all pass.
- FAIL: Widen statistical tolerances if flaky. Use fixed seeds.
- OUTPUT: `tests/test_types.py`, `tests/test_uncertainty.py`

### T-113: Logic gates accept UncertainValue inputs
- ENTRY: T-112 complete
- DO:
  1. Modify `src/nspl/core/logic_gates.py`:
     - Each gate checks if input is `UncertainValue`. If so, extract `.value` for computation, compose `.confidence` according to rules:
       - AND: output confidence = min(input confidences)
       - OR: output confidence = max(input confidences)
       - NOT: output confidence = input confidence
     - Return `UncertainValue[float]` if any input was `UncertainValue`, else plain `float`
  2. Type signatures become:
     ```python
     def AND(*inputs: float | bool | UncertainValue, ...) -> float | UncertainValue[float]
     ```
- EXIT: `AND(UncertainValue(value=0.9, confidence=0.7), UncertainValue(value=0.8, confidence=0.9))` returns `UncertainValue` with confidence=0.7 (min). All prior tests still pass.
- FAIL: If overloading is messy, use a separate `uncertain_gate()` wrapper.
- OUTPUT: Modified `src/nspl/core/logic_gates.py`, new tests in `tests/test_logic_gates.py`

### T-114: Experiment 2 -- Uncertainty calibration
- ENTRY: T-113 complete
- DO:
  1. Create `experiments/exp2_uncertainty_calibration/run.py`
  2. Dataset: Use TriviaQA or a 500-question factual Q&A set. If no dataset available, generate 500 questions with known answers (e.g., "What is the capital of France?" -> "Paris") programmatically from a predefined list.
  3. For each question, get answer from Claude Sonnet with:
     - **Baseline**: Raw completion. Ask model to self-rate confidence 0-100.
     - **NSPL**: Wrap answer in `UncertainValue`. Confidence = model's self-rated confidence / 100. Mark correct/incorrect.
  4. Compute Expected Calibration Error (ECE):
     - Bin predictions by confidence (10 bins: 0-0.1, 0.1-0.2, ..., 0.9-1.0)
     - ECE = weighted average of |accuracy_in_bin - mean_confidence_in_bin|
  5. Compute:
     - ECE for raw model confidence
     - Reliability diagram (matplotlib, save as PNG)
     - Brier score: mean((confidence - correct)^2)
  6. **This experiment primarily validates the measurement infrastructure**, not NSPL's superiority. The hypothesis is that explicitly modeling uncertainty enables calibration measurement and downstream gating.
  7. Save: `experiments/exp2_uncertainty_calibration/results/exp2_report.md` with ECE, Brier score, reliability diagram.
- EXIT: Report exists with numbers. ECE is computed. Reliability diagram PNG saved.
- FAIL: If API budget issue, reduce to 200 questions. If model refuses to self-rate, use logprobs where available (OpenAI) or token probability heuristic.
- OUTPUT: `experiments/exp2_uncertainty_calibration/`

### T-115: Commit Phase 1B
- ENTRY: T-110 through T-114 complete
- DO: Lint, type-check, test, commit, push.
- EXIT: CI green.
- OUTPUT: Git commit

---

## PHASE 1C: CONCEPTS

### T-120: Implement concept decorator
- ENTRY: T-115 complete
- DO:
  1. Create `src/nspl/core/concepts.py`
  2. Implement `@concept` decorator that:
     - Wraps class as Pydantic BaseModel
     - Adds `embedding: np.ndarray | None = None` field
     - Registers `@rule` methods as named boolean properties
     - Provides `symbolize()` and `neuralize()` methods (stubs if no embedding backend configured)
  3. Implement `@rule` decorator: marks method as a symbolic rule. Rules are callable and return `bool | UncertainValue[bool]`.
  4. Implement `EmbeddingConfig` for configuring embedding backend:
     ```python
     class EmbeddingConfig:
         backend: Literal["none", "sentence-transformers", "openai"] = "none"
         model: str = "all-MiniLM-L6-v2"
         dimension: int = 384
     ```
  5. When backend="none", embedding operations are no-ops (return None).
- EXIT: Example from ROADMAP works:
  ```python
  @concept
  class Person:
      name: str
      age: int = Field(gt=0)
      @rule
      def is_adult(self) -> bool:
          return self.age >= 18

  p = Person(name="John", age=30)
  assert p.is_adult() == True
  ```
- FAIL: If Pydantic + decorator interaction is problematic, use class-based approach without decorator.
- OUTPUT: `src/nspl/core/concepts.py`

### T-121: Tests for concepts
- ENTRY: T-120 complete
- DO: Create `tests/test_concepts.py`. Test construction, rule evaluation, Field validation (negative age rejected), serialization.
- EXIT: All tests pass.
- OUTPUT: `tests/test_concepts.py`

### T-122: Commit Phase 1C
- ENTRY: T-121 complete
- DO: Lint, type-check, test, commit, push.
- EXIT: CI green.
- OUTPUT: Git commit

---

## PHASE 2A: ACTION VERIFICATION

### T-200: Implement action decorator and verification pipeline
- ENTRY: T-122 complete
- DO:
  1. Create `src/nspl/actions/action.py`
  2. Implement `@action` class decorator:
     - Scans for methods decorated with `@preconditions`, `@postconditions`, `@safety_checks`
     - Adds `safe_execute(ctx) -> ActionResult` method that runs pipeline:
       1. Call all `@preconditions` methods. If any return falsy/UncertainValue below threshold -> raise `PreconditionError`
       2. Call all `@safety_checks` methods. If any fail -> raise `SafetyViolationError`
       3. Call `execute(ctx)` -> result
       4. Call all `@postconditions` methods with (ctx, result). If any fail -> raise `PostconditionError`
       5. Return `ActionResult(success=True, result=result, audit_trail=trail)`
     - Adds `dry_run(ctx) -> DryRunResult` that runs preconditions + safety only
  3. Implement `ActionResult`:
     ```python
     class ActionResult(BaseModel):
         success: bool
         result: Any = None
         error: str | None = None
         audit_trail: list[AuditEntry] = []
         duration_ms: float = 0.0
     ```
  4. Implement `AuditEntry`:
     ```python
     class AuditEntry(BaseModel):
         timestamp: datetime
         stage: Literal["precondition", "safety", "execution", "postcondition"]
         check_name: str
         passed: bool
         value: Any = None
         detail: str = ""
     ```
  5. Every check execution is recorded in the audit trail regardless of pass/fail.
- EXIT: The ProcessRefund example from ROADMAP works end-to-end with mock services.
- FAIL: If decorator metaclass conflicts with Pydantic, use explicit class registration instead.
- OUTPUT: `src/nspl/actions/action.py`

### T-201: Implement custom exceptions
- ENTRY: T-200 in progress or complete
- DO:
  1. Create `src/nspl/actions/exceptions.py`:
     ```python
     class NSPLVerificationError(Exception):
         audit_trail: list[AuditEntry]

     class PreconditionError(NSPLVerificationError): ...
     class SafetyViolationError(NSPLVerificationError): ...
     class PostconditionError(NSPLVerificationError): ...
     ```
  2. Each exception carries the audit trail up to the point of failure.
- EXIT: `from nspl.actions.exceptions import PreconditionError` works.
- OUTPUT: `src/nspl/actions/exceptions.py`

### T-202: Implement action registry
- ENTRY: T-200 complete
- DO:
  1. Create `src/nspl/actions/registry.py`:
     ```python
     class ActionRegistry:
         def register(self, name: str, action_cls: type) -> None: ...
         def get(self, name: str) -> type: ...
         def list_actions(self) -> list[str]: ...
         def to_tool_schemas(self) -> list[dict]: ...  # JSON Schema for each action's parameters
     ```
  2. `to_tool_schemas()` generates OpenAI/Anthropic-compatible tool definitions from action parameter types (using Pydantic's `.model_json_schema()`).
  3. Global registry singleton: `default_registry = ActionRegistry()`
  4. `@action` decorator auto-registers to default registry.
- EXIT: Register ProcessRefund, call `default_registry.to_tool_schemas()`, get valid JSON schema.
- FAIL: If JSON schema generation fails for complex types, simplify to basic types.
- OUTPUT: `src/nspl/actions/registry.py`

### T-203: Tests for action system
- ENTRY: T-200, T-201, T-202 complete
- DO:
  1. Create `tests/test_actions.py`
  2. Test scenarios (using mock context objects):
     - **Happy path**: All checks pass, execution succeeds, postconditions pass -> ActionResult(success=True)
     - **Precondition failure**: Mock service returns order not found -> PreconditionError raised, audit trail shows which check failed
     - **Safety violation**: Refund > 1000 without approval -> SafetyViolationError
     - **Postcondition failure**: Execution succeeds but status not updated -> PostconditionError
     - **Dry run**: Checks pass but execution not called
     - **Audit trail**: Verify all entries present with correct stages/timestamps
     - **Registry**: Register, list, get, schema generation
  3. Use `unittest.mock.MagicMock` for context services.
- EXIT: `pytest tests/test_actions.py -v` -- all pass, >= 15 test cases.
- FAIL: Fix action implementation, re-run.
- OUTPUT: `tests/test_actions.py`

### T-204: Implement verification engine with confidence thresholds
- ENTRY: T-203 complete
- DO:
  1. Create `src/nspl/actions/verification.py`:
     ```python
     class VerificationConfig(BaseModel):
         precondition_threshold: float = 0.9   # UncertainValue must be >= this
         safety_threshold: float = 0.95
         postcondition_threshold: float = 0.9
         fail_on_uncertain: bool = True  # if True, uncertain results are failures

     class VerificationEngine:
         def __init__(self, config: VerificationConfig = VerificationConfig()): ...
         def verify(self, action_instance, ctx) -> ActionResult: ...
     ```
  2. When a check returns `UncertainValue`, compare `.confidence` against the relevant threshold. If below threshold and `fail_on_uncertain=True`, raise the appropriate exception.
  3. `@action` decorator accepts optional `verification_config` parameter.
- EXIT: Test: action with UncertainValue(value=True, confidence=0.7) and threshold=0.9 raises PreconditionError.
- FAIL: N/A.
- OUTPUT: `src/nspl/actions/verification.py`

### T-205: Commit Phase 2A
- ENTRY: T-200-T-204 complete, all tests pass
- DO: Lint, type-check, test, commit, push.
- EXIT: CI green.
- OUTPUT: Git commit

---

## PHASE 2B: AGENT INTEGRATIONS

### T-210: Anthropic Claude integration
- ENTRY: T-205 complete
- DO:
  1. Create `src/nspl/integrations/anthropic.py`
  2. Implement:
     ```python
     def nspl_tools(action_classes: list[type]) -> list[dict]:
         """Convert NSPL actions to Anthropic tool definitions."""
         # Uses registry.to_tool_schemas() + Anthropic tool format

     def handle_tool_use(tool_use_block: dict, registry: ActionRegistry, ctx: Any) -> ActionResult:
         """Execute an NSPL-verified action from a Claude tool_use block."""
         action_name = tool_use_block["name"]
         params = tool_use_block["input"]
         action_cls = registry.get(action_name)
         instance = action_cls(**params)
         return instance.safe_execute(ctx)

     def tool_result_block(result: ActionResult) -> dict:
         """Format ActionResult as Anthropic tool_result block."""
     ```
  3. Guard import: `anthropic` is optional dependency.
- EXIT: Integration test with mock Anthropic response works. Tool schemas are valid Anthropic format.
- FAIL: If Anthropic SDK format changes, check latest docs via context7 MCP.
- OUTPUT: `src/nspl/integrations/anthropic.py`

### T-211: OpenAI integration
- ENTRY: T-205 complete
- DO:
  1. Create `src/nspl/integrations/openai.py`
  2. Same pattern as T-210 but for OpenAI function calling format.
  3. Key difference: OpenAI uses `"functions"` / `"tools"` array with `"type": "function"` wrapper.
- EXIT: Tool schemas are valid OpenAI format. Mock test passes.
- OUTPUT: `src/nspl/integrations/openai.py`

### T-212: Integration tests
- ENTRY: T-210, T-211 complete
- DO:
  1. Create `tests/test_integrations.py`
  2. Test (mocked, no real API calls):
     - Schema generation produces valid JSON for both formats
     - `handle_tool_use` routes to correct action and returns ActionResult
     - Error cases: unknown action name, invalid params, verification failure
  3. Optional: one live integration test (marked `@pytest.mark.live`) that actually calls Claude with a simple verified action. Skipped by default.
- EXIT: `pytest tests/test_integrations.py -v` -- all mocked tests pass.
- OUTPUT: `tests/test_integrations.py`

### T-213: Experiment 3 -- Action safety catch rate
- ENTRY: T-212 complete
- DO:
  1. Create `experiments/exp3_action_safety/run.py`
  2. Define 10 action classes with explicit safety boundaries:
     - `ProcessRefund` (amount limit, ownership, fraud check)
     - `SendEmail` (valid recipient, content check, rate limit)
     - `DeleteRecord` (ownership, admin check, backup exists)
     - `TransferFunds` (balance check, amount limit, destination valid)
     - `UpdatePermissions` (admin only, no self-escalation)
     - `CreateAccount` (unique email, valid data, rate limit)
     - `CancelOrder` (order exists, cancelable status, owner)
     - `ExportData` (authorization, data classification check)
     - `ScheduleAction` (valid time, no conflicts, permission)
     - `ModifyConfig` (admin, valid values, rollback available)
  3. For each action, generate:
     - 50 valid invocations (all checks pass)
     - 50 adversarial invocations (exactly 1 check should fail, distributed across check types)
     - Total: 1000 invocations (500 valid, 500 adversarial)
  4. Run each invocation through NSPL verification pipeline.
  5. Measure:
     - **True Positive Rate (TPR)**: fraction of adversarial calls correctly blocked
     - **False Positive Rate (FPR)**: fraction of valid calls incorrectly blocked
     - **Per-check-type TPR**: which types of violations are caught/missed
     - **Latency**: time per verification (mean, p50, p95, p99)
     - **Audit trail completeness**: every invocation has full trail
  6. **Baseline comparison**: Implement a "prompt-based safety" baseline:
     - For each invocation, ask Claude Sonnet: "Given these parameters, should this action be allowed? Answer YES or NO. [paste action description + params]"
     - Measure same TPR/FPR/latency
  7. **Statistical analysis**:
     - 2x2 contingency table (NSPL vs prompt-based) x (caught vs missed)
     - McNemar's test for paired comparison, p < 0.05
     - 95% Wilson confidence intervals for TPR and FPR
  8. Save: `experiments/exp3_action_safety/results/exp3_report.md`
     - Include table: NSPL vs. prompt-based on all metrics
     - Include per-violation-type breakdown
     - Include latency distribution plot (histogram, save PNG)
- EXIT: Report exists. NSPL TPR > 95%. NSPL FPR < 5%. Latency p95 < 100ms. Statistical test computed.
- FAIL: If TPR < 95%, analyze which check types are failing. If it's a logic gate issue, return to T-100. If it's a test generation issue, fix test harness. If FPR > 5%, verification thresholds are too aggressive -- lower them.
- OUTPUT: `experiments/exp3_action_safety/`

### T-214: Commit Phase 2B
- ENTRY: T-210-T-213 complete
- DO: Lint, type-check, test, commit, push.
- EXIT: CI green.
- OUTPUT: Git commit

---

## PHASE 3A: REASONING PIPELINES

### T-300: Implement pipeline decorator and stage system
- ENTRY: T-214 complete
- DO:
  1. Create `src/nspl/reasoning/pipeline.py`
  2. Implement `@pipeline` decorator:
     - Collects stage-decorated inner functions
     - Enforces execution order: planning -> exploration -> execution -> reflection
     - Not all stages required. Minimum: 1 stage.
     - Each stage receives output of previous stage.
     - Returns final stage output.
  3. Create `src/nspl/reasoning/stages.py`:
     - `@planning`, `@exploration`, `@execution`, `@reflection` decorators
     - Each marks function with stage metadata (name, order)
  4. Pipeline execution features:
     - `PipelineTrace`: records input/output/duration for each stage
     - Confidence gating: if a stage returns `UncertainValue` with confidence below `stage_threshold`, pipeline aborts with partial result
     - Stage-level timeout (configurable, default 30s)
     - Stage-level retry (configurable, default 0 retries)
  5. Implement `PipelineConfig`:
     ```python
     class PipelineConfig(BaseModel):
         stage_threshold: float = 0.5        # minimum confidence to proceed
         stage_timeout_s: float = 30.0
         max_retries: int = 0
         trace_enabled: bool = True
     ```
  6. Implement `PipelineResult`:
     ```python
     class PipelineResult(BaseModel):
         output: Any
         trace: PipelineTrace
         completed_stages: list[str]
         aborted: bool = False
         abort_reason: str | None = None
         total_duration_ms: float
     ```
- EXIT: Simple 2-stage pipeline (planning + execution) runs and returns PipelineResult with trace.
- FAIL: If decorator nesting is too complex, use explicit `Pipeline.add_stage()` builder pattern.
- OUTPUT: `src/nspl/reasoning/pipeline.py`, `src/nspl/reasoning/stages.py`

### T-301: Tests for reasoning pipelines
- ENTRY: T-300 complete
- DO:
  1. Create `tests/test_reasoning.py`
  2. Test:
     - Simple pipeline: 2 stages, pass-through, correct output
     - Confidence gating: stage returns UncertainValue(confidence=0.3) with threshold=0.5 -> aborted
     - Trace completeness: all stages recorded with timing
     - Stage ordering: planning must run before execution
     - Timeout: stage that sleeps 5s with 1s timeout -> timeout error
     - Retry: stage fails once, succeeds on retry (mock with counter)
     - Edge: single-stage pipeline, empty pipeline (should raise)
- EXIT: `pytest tests/test_reasoning.py -v` -- all pass.
- OUTPUT: `tests/test_reasoning.py`

### T-302: Implement LLM-backed stages
- ENTRY: T-301 complete
- DO:
  1. Create `src/nspl/reasoning/llm_stages.py`
  2. Implement helper functions for common LLM-backed stage patterns:
     ```python
     def llm_planning_stage(
         prompt_template: str,
         model: str = "claude-sonnet-4-20250514",
         parse_fn: Callable[[str], Plan] = default_plan_parser
     ) -> Callable: ...

     def llm_execution_stage(
         action_registry: ActionRegistry,
         model: str = "claude-sonnet-4-20250514"
     ) -> Callable: ...
     ```
  3. These are convenience wrappers. Users can always write custom stage functions.
  4. LLM calls use anthropic/openai SDK (optional deps).
- EXIT: `llm_planning_stage("Break this into steps: {question}")` returns a callable that works as a pipeline stage.
- FAIL: If SDK not installed, raise clear ImportError.
- OUTPUT: `src/nspl/reasoning/llm_stages.py`

### T-303: Commit Phase 3A
- ENTRY: T-300-T-302 complete
- DO: Lint, type-check, test, commit, push.
- EXIT: CI green.
- OUTPUT: Git commit

---

## PHASE 3B: REASONING BENCHMARKS

### T-310: Experiment 4 -- Structured reasoning benchmark
- ENTRY: T-303 complete
- DO:
  1. Create `experiments/exp4_structured_reasoning/run.py`
  2. **Dataset**: GSM8K test set (1319 problems). Download from HuggingFace datasets.
     - If HF download fails, use a 200-problem subset hardcoded.
  3. **Conditions** (within-subjects, same model for all):
     - **Condition A: Raw CoT** -- prompt: "Solve step by step.\n{question}"
     - **Condition B: NSPL Pipeline** -- 3-stage pipeline:
       - Planning: "Break this problem into sub-steps"
       - Execution: "Solve each sub-step"
       - Reflection: "Check the answer. Are you confident? Rate 0-100."
     - **Condition C: NSPL Pipeline + Confidence Gating** -- same as B but abort if planning confidence < 0.5
  4. **Model**: Claude Sonnet (single model to control for model differences)
  5. **Parsing**: Extract final numeric answer. Regex: last number in response.
  6. **Metrics**:
     - Accuracy: exact match of extracted number vs. gold answer
     - Token count: total tokens used per problem (input + output)
     - Token efficiency: accuracy / token count
     - Abort rate (Condition C only): fraction of problems aborted due to low confidence
  7. **Statistical analysis**:
     - Paired t-test: accuracy difference between conditions (A vs B, A vs C, B vs C)
     - Effect size: Cohen's d
     - 95% bootstrap confidence intervals for accuracy (10K bootstrap samples)
     - Report: mean, std, CI for each condition
  8. **Sample size justification**:
     - With N=1319 (full GSM8K), power > 0.99 to detect 5% accuracy difference at alpha=0.05
     - If using 200-problem subset, power ~0.80 for 10% difference
  9. Save: `experiments/exp4_structured_reasoning/results/exp4_report.md`
     - Accuracy table with CIs
     - Token efficiency comparison
     - Example traces (3 correct, 3 incorrect from each condition)
- EXIT: Report exists with all metrics. Statistical tests computed with p-values.
- FAIL: If API costs exceed budget, use 200-problem subset. If accuracy difference is not significant, report null result honestly -- "no significant difference detected, but NSPL provides auditability" is a valid finding.
- OUTPUT: `experiments/exp4_structured_reasoning/`

### T-311: Experiment 5 -- Confidence calibration in pipelines
- ENTRY: T-310 complete (reuses its data)
- DO:
  1. Create `experiments/exp5_confidence_propagation/run.py`
  2. **Data source**: Reuse Condition B and C results from Experiment 4
  3. **Analysis**:
     - For each problem, extract per-stage confidence and final confidence
     - Binary outcome: correct (1) or incorrect (0)
     - **AUROC**: confidence score as predictor of correctness
     - **ECE**: Expected Calibration Error (10 bins)
     - **Brier score**: mean squared error of confidence vs. correctness
  4. **Comparison**:
     - NSPL per-stage confidence vs. single-shot confidence (Condition A: parse "I'm X% confident" from CoT response)
     - NSPL stage-min confidence vs. stage-product confidence vs. final-stage-only confidence
  5. **Visualization**:
     - Reliability diagram (calibration plot) for each method
     - ROC curve for confidence as correctness predictor
     - Save as PNGs
  6. **Statistical test**: DeLong test for AUROC comparison between methods
  7. Save: `experiments/exp5_confidence_propagation/results/exp5_report.md`
- EXIT: Report with AUROC, ECE, Brier score for all methods. Plots generated.
- FAIL: If confidence scores are degenerate (all same value), the pipeline config needs adjustment. Try extracting confidence from logprobs instead of self-report.
- OUTPUT: `experiments/exp5_confidence_propagation/`

### T-312: Commit Phase 3B
- ENTRY: T-310, T-311 complete
- DO: Lint, commit, push.
- EXIT: CI green.
- OUTPUT: Git commit

---

## PHASE 4A: DOCUMENTATION AND EXAMPLES

### T-400: Write quickstart tutorial
- ENTRY: T-312 complete
- DO:
  1. Create `docs/tutorials/quickstart.md`
  2. Content: install, define one action, run verified execution, inspect audit trail. Under 100 lines of prose + code.
- EXIT: A reader can copy-paste the code and run it.
- OUTPUT: `docs/tutorials/quickstart.md`

### T-401: Write 3 end-to-end examples
- ENTRY: T-400 complete
- DO:
  1. `examples/customer_service.py` -- refund agent with 3 verified actions
  2. `examples/research_assistant.py` -- citation checker with reasoning pipeline
  3. `examples/code_review.py` -- safety-checked code execution action
  4. Each example: < 150 lines, runnable with mock services, prints audit trail.
- EXIT: `python examples/customer_service.py` runs without error.
- OUTPUT: `examples/`

### T-402: Auto-generate API reference
- ENTRY: T-401 complete
- DO:
  1. Ensure all public functions/classes have docstrings
  2. Create `docs/api/` with one markdown file per module, generated by running:
     ```python
     # Script: scripts/generate_api_docs.py
     # Uses inspect + pydoc to extract docstrings
     ```
  3. Or use `pdoc` / `mkdocs` with auto-generation.
- EXIT: `docs/api/` contains reference for core, actions, reasoning, integrations.
- OUTPUT: `docs/api/`, `scripts/generate_api_docs.py`

### T-403: Comparison guide
- ENTRY: T-213 (Exp 3) and T-310 (Exp 4) complete
- DO:
  1. Create `docs/comparison.md`
  2. Content: NSPL vs. Guardrails vs. DSPy vs. raw function calling
  3. Use actual numbers from experiments. No vague claims.
  4. Table format: feature matrix + performance numbers.
- EXIT: File exists, references experiment results, makes no unsupported claims.
- OUTPUT: `docs/comparison.md`

### T-404: Commit Phase 4A
- ENTRY: T-400-T-403 complete
- DO: Commit, push.
- EXIT: CI green.
- OUTPUT: Git commit

---

## PHASE 4B: PAPER

### T-410: Compile experiment results into figures and tables
- ENTRY: T-404 complete
- DO:
  1. Create `paper/figures/` and `paper/tables/`
  2. Generate publication-quality figures (matplotlib, 300 DPI, PDF format):
     - Fig 1: NSPL architecture diagram (manual, TikZ or draw.io)
     - Fig 2: Exp 1 -- accuracy by expression depth (grouped bar chart)
     - Fig 3: Exp 3 -- TPR/FPR comparison (bar chart with error bars)
     - Fig 4: Exp 3 -- latency distribution (box plot)
     - Fig 5: Exp 4 -- accuracy comparison with CIs (forest plot)
     - Fig 6: Exp 5 -- reliability diagrams (calibration curves)
     - Fig 7: Exp 5 -- ROC curves
  3. Generate tables:
     - Table 1: Feature comparison matrix (NSPL vs competitors)
     - Table 2: Exp 1 full results
     - Table 3: Exp 3 per-violation-type breakdown
     - Table 4: Exp 4 accuracy + token efficiency
     - Table 5: Exp 5 calibration metrics (AUROC, ECE, Brier)
- EXIT: All figures as PDFs in `paper/figures/`, all tables as LaTeX fragments in `paper/tables/`.
- OUTPUT: `paper/figures/`, `paper/tables/`

### T-411: Write paper draft
- ENTRY: T-410 complete
- DO:
  1. Create `paper/main.tex` (ACL/EMNLP format, or AAAI format)
  2. Structure:
     - **Abstract** (150 words): Problem, approach, key results
     - **1. Introduction** (1 page): Agentic AI verification gap, NSPL contribution
     - **2. Related Work** (1 page): LNN, DeepProbLog, Scallop, DSPy, Guardrails, Instructor. What each does, what's missing.
     - **3. NSPL Framework** (2 pages): Architecture, logic gates, action verification, reasoning pipelines. Code examples.
     - **4. Experiments** (2 pages): Exp 1, 3, 4, 5. Methodology, results, analysis. (Exp 2 in appendix if space-constrained.)
     - **5. Discussion** (0.5 page): Limitations (latency overhead, scope of verification, reliance on correct check implementation). Threats to validity.
     - **6. Conclusion** (0.25 page): Summary, future work, open source link.
     - **References**: >= 30 references
  3. Every claim backed by experiment number or citation.
  4. No superlatives ("groundbreaking", "revolutionary"). Let numbers speak.
- EXIT: Compiles with `pdflatex`. 6-8 pages. All figures/tables referenced.
- FAIL: If LaTeX errors, fix them. If over page limit, cut Discussion.
- OUTPUT: `paper/main.tex`, `paper/main.pdf`

### T-412: Internal review pass
- ENTRY: T-411 complete
- DO:
  1. Re-read paper for:
     - Unsupported claims (flag any sentence without experiment/citation backing)
     - Statistical errors (wrong test, missing CIs, p-hacking)
     - Missing baselines
     - Unclear figures
  2. Fix all issues found.
  3. Check reproducibility: can someone run the experiments from the repo?
     - Ensure `experiments/*/run.py` has clear CLI interface
     - Ensure all random seeds are fixed
     - Ensure API calls are cached/logged for reproducibility
- EXIT: Zero unsupported claims. All experiments reproducible.
- OUTPUT: Revised `paper/main.tex`

### T-413: Submit arXiv preprint
- ENTRY: T-412 complete
- DO:
  1. Compile final PDF
  2. Submit to arXiv cs.AI (or cs.SE)
  3. Record arXiv ID
- EXIT: arXiv submission confirmed.
- FAIL: If arXiv rejects (formatting), fix and resubmit.
- OUTPUT: arXiv preprint URL

---

## PHASE 4C: RELEASE

### T-420: PyPI release
- ENTRY: T-414 or T-412 complete
- DO:
  1. Bump version to `0.1.0` (already set)
  2. `python -m build`
  3. `twine upload dist/*` (or `hatch publish`)
  4. Verify: `pip install nspl` in a fresh venv, run quickstart example
- EXIT: `pip install nspl` works from PyPI.
- FAIL: Fix packaging issues (missing files in sdist, bad metadata).
- OUTPUT: PyPI package

### T-421: Public GitHub release
- ENTRY: T-420 complete
- DO:
  1. Change repo visibility: `gh repo edit astoreyai/nspl --visibility public`
  2. Create release: `gh release create v0.1.0 --title "v0.1.0: Initial Release" --notes "..."`
  3. Add badges to README: PyPI version, CI status, Python version
- EXIT: `gh repo view astoreyai/nspl` shows public. Release exists.
- OUTPUT: GitHub release

### T-422: Write announcement
- ENTRY: T-421 complete
- DO:
  1. Create `docs/blog/announcement.md`:
     - What is NSPL (2 paragraphs)
     - Why it matters (1 paragraph)
     - Quick example (10 lines of code)
     - Link to paper, repo, PyPI
     - < 500 words total
- EXIT: File exists, links work.
- OUTPUT: `docs/blog/announcement.md`

---

## EXECUTION RULES

1. **No skipping**: Execute tasks in order. Dependencies are strict.
2. **Test before commit**: Every commit must pass `ruff check`, `mypy`, `pytest`.
3. **Null results are valid**: If an experiment shows no improvement, report honestly. Do not re-run with different parameters to fish for significance.
4. **Fixed seeds**: All random operations use `seed=42`. All experiment scripts accept `--seed` argument.
5. **API call caching**: Cache all LLM API responses to disk (JSON). Re-running experiment uses cache. Delete cache to force fresh calls.
6. **Budget guard**: Each experiment script has a `--max-cost` flag (default $50). Estimate cost before running. Abort if projected cost exceeds limit.
7. **Incremental saves**: Experiment scripts save partial results every 50 examples. Resumable on crash.
8. **No scope creep**: If a task leads to "we should also add X", record X in a `BACKLOG.md` file and continue with the current task.
