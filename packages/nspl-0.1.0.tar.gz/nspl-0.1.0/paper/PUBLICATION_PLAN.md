# NSPL Publication Plan

**Target**: Strong accept at EMNLP 2026 Demo or NeSy 2026
**Fallback**: ICSE 2027 NIER (4 pages)
**Immediate**: arXiv preprint (priority claim)

---

## Phase 0: arXiv Preprint (Day 1)

### Tasks
- [ ] P0.1: Add 15 missing references (see list below)
- [ ] P0.2: Add OWASP LLM Top 10 paragraph to Related Work
- [ ] P0.3: Spell check, grammar pass
- [ ] P0.4: Submit to arXiv cs.CR (primary) + cs.AI + cs.SE

### Deliverables
- arXiv ID
- PDF on Google Drive

### Quality Gate
- At least 25 references
- No undefined citations
- Compiles clean (0 warnings)

### Handoff
arXiv link goes into README, CLAUDE.md, and all venue submissions

---

## Phase 1: Baseline Comparison Experiments (Week 1)

The biggest reviewer complaint will be: "How does this compare to existing guardrail tools on the same data?"

### Tasks

#### P1.1: Benchmark Guardrails AI on deepset + jackhhao + Lakera

```python
# experiments/exp8_baseline_comparison/run_guardrails.py
# Install: pip install guardrails-ai
# Run their content validator on same 5 datasets
# Record: accuracy, recall, F1, FPR, latency
```

**Hypothesis**: Guardrails AI is output-focused and will score near 0% on prompt injection detection (it validates format, not intent).

**Exit criterion**: Table comparing NSPL vs Guardrails AI vs NeMo on all 5 datasets.

#### P1.2: Benchmark LLM-as-Judge on deepset + jackhhao

```python
# experiments/exp8_baseline_comparison/run_llm_judge.py
# Send each sample to Claude/Gemini: "Is this a prompt injection? SAFE/UNSAFE"
# Record: accuracy, recall, F1, FPR, latency, cost
```

**Hypothesis**: LLM-as-judge will have higher recall on CTF prompts but 100-1000x higher latency and non-zero cost.

**Exit criterion**: Table with NSPL vs LLM-as-judge on same data, including latency and cost-per-query.

#### P1.3: Benchmark simple keyword blacklist

```python
# experiments/exp8_baseline_comparison/run_keyword.py
# Naive approach: block if any of 50 keywords appear
# Represents "what people do today without a framework"
```

**Hypothesis**: Keyword blacklist will have very high FPR (blocks "ignore" in legitimate contexts) and low recall on indirect attacks.

**Exit criterion**: Demonstrates NSPL adds value over naive approaches.

### Deliverables
- `experiments/exp8_baseline_comparison/` with 3 scripts + results
- New paper table: "Table 6: Comparison with existing tools"
- Updated Related Work paragraphs with empirical claims

### Quality Gate
- All baselines run on identical data splits
- Statistical tests: McNemar's for paired comparison
- Cost analysis: $/query for each approach
- Reviewer question answered: "Why not just use Guardrails AI / an LLM?"

### Handoff
Results feed into paper Section 4 and comparison docs

---

## Phase 2: Adaptive Adversary Experiment (Week 2)

Reviewers at security-adjacent venues will ask: "What happens when the attacker knows about NSPL and adapts?"

### Tasks

#### P2.1: Design attack taxonomy

Define 5 attack strategies an informed adversary would use:
1. **Pattern evasion**: Rewrite known injections to avoid regex patterns
2. **Classifier evasion**: Adversarial examples that fool DeBERTa
3. **Normalization bypass**: Unicode sequences that survive normalization
4. **Compound evasion**: Split pretext and payload across multiple messages
5. **Indirect injection**: Injection via tool output, not user input

#### P2.2: Generate adversarial dataset

```python
# experiments/exp9_adaptive_adversary/generate.py
# For each of the 5 strategies:
#   - Take 20 known-detected injections
#   - Manually rewrite to evade detection (100 samples total)
#   - Label: injection=1, variant_of=original_id, strategy=name
```

This is manual work -- LLM-assisted but human-verified. Budget: 4 hours.

#### P2.3: Run NSPL against adversarial dataset

```python
# experiments/exp9_adaptive_adversary/run.py
# Test all 5 detectors on the 100 adversarial samples
# Compute: evasion rate per strategy per detector
```

**Expected result**: Some strategies will succeed (especially indirect injection). Report honestly.

#### P2.4: Iterate defenses

For each evasion that succeeds:
- Add detection pattern or rule
- Re-run benchmark
- Document: original evasion rate -> post-fix evasion rate

This creates a "defense iteration" narrative that reviewers value.

### Deliverables
- Adversarial dataset (100 samples, labeled, reusable)
- Table: "Evasion rate by attack strategy before/after defense iteration"
- New paper subsection: "Experiment 6: Adaptive Adversary"

### Quality Gate
- At least 2 strategies have >50% initial evasion rate (honest difficulty)
- At least 1 strategy remains partially effective after iteration (no overclaiming)
- All generated samples are human-verified as actual injections

### Handoff
Dataset released with paper. Defense iterations committed to codebase.

---

## Phase 3: Paper Revision (Week 3)

### Tasks

#### P4.1: Venue template conversion

- EMNLP Demo: 4 pages + references (ACL format)
- NeSy: 8-10 pages (their format)
- ICSE NIER: 4 pages (IEEE format)

Pick primary venue based on deadlines. Adapt paper length.

#### P4.2: Add missing references

Required additions (15 minimum):

**Prompt injection**:
- Perez & Ribeiro (2022) "Ignore This Title and HackAPrompt"
- Greshake et al. (2023) "Not what you've signed up for: Compromising Real-World LLM-Integrated Applications with Indirect Prompt Injection"
- Liu et al. (2023) "Prompt Injection attack against LLM-integrated Applications"
- OWASP (2025) "OWASP Top 10 for LLM Applications"

**Guardrails & safety**:
- Inan et al. (2023) "Llama Guard"
- Dong et al. (2024) "Building Guardrails for Large Language Models"
- Anthropic (2023) "Constitutional AI"

**Agent safety**:
- Ruan et al. (2024) "Identifying the Risks of LM Agents with an LM-Emulated Sandbox"
- Mialon et al. (2023) "Augmented Language Models: a Survey"

**Neurosymbolic**:
- Hitzler et al. (2022) "Neuro-Symbolic Approaches in Artificial Intelligence"
- Sarker et al. (2021) "Neuro-Symbolic Artificial Intelligence: The State of the Art"

**Fuzzy logic**:
- Hajek (1998) "Metamathematics of Fuzzy Logic"
- Klement et al. (2000) "Triangular Norms"

#### P4.3: Self-review checklist

Before submission, verify:
- [ ] Every claim is backed by an experiment number or citation
- [ ] All tables have captions and are referenced in text
- [ ] All experiments have seed, n, and dataset name
- [ ] Negative results are in the abstract (not hidden)
- [ ] Threats to validity covers all known weaknesses
- [ ] Code availability URL is correct
- [ ] Author info matches IEEE/ACL profile
- [ ] No orphan figures/tables at page boundaries
- [ ] References are complete (no "et al." for <=3 authors in some styles)

#### P4.4: Internal review

Send to:
1. CITeR advisor (1 week turnaround)
2. 1-2 lab colleagues for feedback
3. Run through Grammarly/LanguageTool for English issues

### Deliverables
- Venue-formatted paper
- Cover letter (if required)
- Supplementary materials: code repo link, experiment scripts, adversarial dataset

### Quality Gate
- Advisor has read and approved
- All checklist items verified
- Paper compiles in venue template with 0 errors

---

## Phase 5: Submission + Iteration (Week 5+)

### Tasks
- [ ] P5.1: Submit to primary venue
- [ ] P5.2: If rejected, read reviews, address all points
- [ ] P5.3: Submit to fallback venue with improvements
- [ ] P5.4: Regardless of outcome, keep arXiv updated

---

## Experiment Setup Scripts

All new experiments should be ready to run before Phase 1 starts.

### exp8: Baseline Comparison
```
experiments/exp8_baseline_comparison/
  run_guardrails.py    # Guardrails AI on 5 datasets
  run_llm_judge.py     # Claude/Gemini as safety judge
  run_keyword.py       # Naive keyword blacklist
  run_all.py           # Orchestrate all baselines + NSPL
  results/
```

### exp9: Adaptive Adversary
```
experiments/exp9_adaptive_adversary/
  taxonomy.md          # 5 attack strategies documented
  generate.py          # LLM-assisted sample generation
  adversarial_dataset.json  # 100 labeled samples
  run.py               # Test all detectors
  iterate.py           # Apply fixes, re-test
  results/
```

### exp10: Developer Study
```
experiments/exp10_user_study/
  protocol.md          # IRB-ready study protocol
  agent_script.py      # The 50-line agent task
  attack_scenarios.json # 10 test prompts
  questionnaire.md     # SUS + custom questions
  consent_form.md      # Participant consent
  analyze.py           # Analysis script
  results/
```

---

## Timeline

| Week | Phase | Key Deliverable | Gate |
|------|-------|----------------|------|
| 0 (now) | P0: arXiv | Preprint submitted | 25+ refs, clean compile |
| 1 | P1: Baselines | 3 comparison experiments | NSPL vs Guardrails/LLM table |
| 2 | P2: Adversary | 100-sample adversarial dataset | Honest evasion rates |
| 3 | P3: User study | 8+ participant results | Effect size reported |
| 4 | P4: Revision | Venue-formatted paper | Advisor approved |
| 5 | P5: Submit | Conference submission | All gates passed |

---

## Reflection Checkpoints

After each phase, answer honestly:

### Phase 0 Reflection
- Is the framing clear? Can a reviewer tell in 30 seconds what NSPL does?
- Are the negative results prominent enough? (Abstract + Discussion)
- Would I cite this paper if I found it?

### Phase 1 Reflection
- Did any baseline outperform NSPL on any metric?
- If yes: is our positioning still valid? What changes?
- Is the cost analysis compelling? (NSPL: $0/query vs LLM: $0.01/query)

### Phase 2 Reflection
- How many attack strategies evaded NSPL completely?
- Did the defense iteration actually improve things, or is it cosmetic?
- Are we overclaiming security? Revise abstract if needed.

### Phase 3 Reflection
- Did developers actually find NSPL easier?
- What confused them? Does that indicate a design flaw?
- Is the sample size sufficient for claims being made?

### Phase 4 Reflection
- Read the paper as a hostile reviewer. What's the weakest paragraph?
- Does the paper tell a coherent story or is it a feature list?
- Would removing any section improve the paper? (If yes, remove it.)

---

## Risk Register

| Risk | Impact | Mitigation |
|------|--------|------------|
| Guardrails AI outperforms on some metric | High | Reframe: NSPL is pre-execution, Guardrails is post-generation. Different jobs. |
| User study shows no significant difference | High | Report null result honestly. Pivot to "same correctness, better auditability." |
| Adaptive adversary breaks everything | Medium | Expected for security tools. Report honestly. The iteration narrative is the contribution. |
| Venue deadline before Phase 3 | Medium | Submit to Demo track (no user study required) or arXiv-first strategy. |
| Advisor feedback requires major changes | Low | Start advisor review in Phase 2 to give 2 weeks buffer. |
| Cannot recruit 8 participants | Medium | Fall back to 5 + report as pilot study. Or skip and submit to NeSy (no user study expected). |
