# NSPL Input/Output Reference

Complete reference for every public function's inputs and outputs.

---

## Core: Logic Gates (`nspl.core.logic_gates`)

### `AND(*inputs, threshold=0.5, weights=None, mode="soft")`
- **Inputs**: `float | bool | UncertainValue` (variadic), `threshold: float`, `weights: list[float] | None`, `mode: "soft" | "hard"`
- **Output**: `float` (plain inputs) or `UncertainValue[float]` (if any input is UncertainValue)
- **Confidence rule**: min of input confidences

### `OR(*inputs, threshold=0.5, weights=None, mode="soft")`
- **Inputs/Output**: Same as AND
- **Confidence rule**: max of input confidences

### `NOT(value, threshold=0.5, mode="soft")`
- **Input**: `float | bool | UncertainValue`
- **Output**: `float` or `UncertainValue[float]`
- **Confidence rule**: preserved from input

### `XOR(*inputs, mode="soft")`
- **Inputs**: `float | bool | UncertainValue` (variadic)
- **Output**: `float` or `UncertainValue[float]`
- **Confidence rule**: min

### `IMPLIES(a, b, mode="soft")`
- **Inputs**: two `float | bool | UncertainValue`
- **Output**: `float` or `UncertainValue[float]`
- **Confidence rule**: min

### `WEIGHTED_AND(inputs, weights, threshold=0.5, mode="soft")`
- **Inputs**: `list[float | bool | UncertainValue]`, `weights: list[float]`
- **Output**: `float` or `UncertainValue[float]`
- **Confidence rule**: min

---

## Core: Types (`nspl.core.types`)

### `UncertainValue(value, confidence=1.0)`
- **Fields**: `value: Any`, `confidence: float [0,1]`
- **Methods**:
  - `map(fn) -> UncertainValue` — apply fn to value, preserve confidence
  - `flat_map(fn) -> UncertainValue` — apply fn returning UncertainValue, multiply confidences
  - `require(threshold, fallback) -> Any` — return value if confident, else fallback()
  - `bool(uv)` — truthiness of value, ignores confidence

---

## Core: Uncertainty (`nspl.core.uncertainty`)

### `Normal(mean, std)` / `Uniform(low, high)` / `Categorical(categories)` / `Empirical(samples)`
- **Input**: Distribution parameters
- **Output**: Distribution objects with `sample(n, seed)`, `mean()`, `std()`

### `propagate(fn, dist, n_samples=1000, seed=42) -> Empirical`
- **Input**: callable, Distribution
- **Output**: Empirical distribution of fn applied to samples

---

## Actions (`nspl.actions`)

### `@action` (class decorator)
- **Input**: Class with `execute(self, ctx)` method + optional `@preconditions`, `@postconditions`, `@safety_checks` methods
- **Output**: Class with added `safe_execute(ctx) -> ActionResult` and `dry_run(ctx) -> DryRunResult`

### `ActionResult`
```
success: bool
result: Any            # return value of execute() if successful
error: str | None      # description if failed
audit_trail: list[AuditEntry]
duration_ms: float
```

### `AuditEntry`
```
timestamp: str         # ISO 8601
stage: "precondition" | "safety" | "execution" | "postcondition"
check_name: str
passed: bool
value: Any
detail: str
```

### `DryRunResult`
```
would_execute: bool
audit_trail: list[AuditEntry]
```

### `sequence(actions, rollback_fns=None) -> Sequence`
- **Input**: list of action instances, optional rollback callables
- **Output**: `CompositionResult` with `success`, `results: list[ActionResult]`, `rolled_back`, `audit_trail`

### `conditional(condition, on_true, on_false=None) -> Conditional`
- **Input**: condition action, true-branch action, optional false-branch
- **Output**: `CompositionResult`

### `parallel(actions) -> Parallel`
- **Input**: list of action instances
- **Output**: `CompositionResult` (all run regardless of individual failures)

---

## Guards (`nspl.guards`)

### `InputGuard(injection_sensitivity="medium", block_pii=True, ...)`
- **Input**: Configuration options
- **Method**: `check(text: str) -> InputVerdict`

### `InputVerdict`
```
allowed: bool
sanitized_text: str | None    # cleaned text if allowed, None if blocked
detections: list[DetectorResult]
reason: str
risk_score: float             # 0.0 (safe) to 1.0 (dangerous)
```

### `OutputGuard(block_pii=True, redact_pii=True, ...)`
- **Method**: `check(text, original_prompt=None) -> OutputVerdict`

### `OutputVerdict`
```
allowed: bool
filtered_text: str | None
detections: list[DetectorResult]
reason: str
risk_score: float
```

### `GuardedLLM(llm_fn, config=None)`
- **Input**: `llm_fn: Callable[[str], str]`, `GuardConfig`
- **Method**: `call(prompt: str) -> GuardResult`

### `GuardResult`
```
output: str | None       # final safe output, or None if blocked
input_allowed: bool
output_allowed: bool
input_verdict: InputVerdict | None
output_verdict: OutputVerdict | None
raw_response: str | None # LLM response before output filtering
error: str | None
```

### `DetectorResult`
```
triggered: bool
detector_name: str
detail: str
score: float             # 0.0 to 1.0
matches: list[str]
```

### Individual Detectors
| Detector | Input | Output |
|----------|-------|--------|
| `PromptInjectionDetector(sensitivity).detect(text)` | `str` | `DetectorResult` |
| `PIIDetector().detect(text)` | `str` | `DetectorResult` |
| `ContentPolicy(categories).detect(text)` | `str` | `DetectorResult` |
| `ClassifierDetector(model, threshold).detect(text)` | `str` | `DetectorResult` |
| `CompoundDetector().detect(text)` | `str` | `DetectorResult` |
| `EnsembleDetector(detectors, strategy).detect(text)` | `str` | `DetectorResult` |
| `StructuralDetector(threshold).detect(text)` | `str` | `DetectorResult` |
| `TieredDetector(...).detect(text)` | `str` | `DetectorResult` |

---

## Reasoning (`nspl.reasoning`)

### `run_pipeline(stages, initial_input=None, config=None) -> PipelineResult`
- **Input**: `list[tuple[str, Callable]]`, initial data, `PipelineConfig`
- **Output**: `PipelineResult`

### `async_run_pipeline(stages, initial_input=None, config=None) -> PipelineResult`
- Same as above but async. Stages can be sync or async callables.

### `async_parallel_stages(stages, input_data, timeout_s=30) -> dict[str, Any]`
- **Input**: list of `(name, callable)`, shared input
- **Output**: `dict` mapping stage name to result

### `PipelineConfig`
```
stage_threshold: float = 0.5    # min confidence to proceed
stage_timeout_s: float = 30.0
max_retries: int = 0
trace_enabled: bool = True
```

### `PipelineResult`
```
output: Any
trace: PipelineTrace
completed_stages: list[str]
aborted: bool
abort_reason: str | None
total_duration_ms: float
```

---

## Integrations

All adapters implement `ToolAdapter` with three methods:

| Method | Input | Output |
|--------|-------|--------|
| `to_tool_definitions(registry)` | `ActionRegistry` | `list[dict]` (provider format) |
| `parse_tool_call(raw)` | `dict` (provider format) | `tuple[str, dict]` (name, params) |
| `format_tool_result(name, result)` | action name, result | `dict` (provider format) |

### Convenience functions
| Function | Provider | Returns |
|----------|----------|---------|
| `nspl.integrations.anthropic.nspl_tools(classes)` | Claude | `list[dict]` |
| `nspl.integrations.openai.nspl_tools(classes)` | OpenAI | `list[dict]` |
| `nspl.integrations.google_adk.nspl_tools(classes)` | Google ADK | `list[dict]` |
| `nspl.integrations.langchain.nspl_langchain_tools(classes, ctx)` | LangChain | `list[NSPLTool]` |

### MCP Server (`python -m nspl.integrations.mcp_server`)
| Tool | Input | Output |
|------|-------|--------|
| `guard_input` | `text: str, sensitivity: str` | JSON: `{allowed, reason, risk_score, detections}` |
| `guard_output` | `text: str, system_prompt: str?` | JSON: `{allowed, filtered_text, reason, detections}` |
| `detect_pii` | `text: str` | JSON: `{found, count, matches}` |
| `evaluate_logic` | `expression: str, mode: str` | JSON: `{result, expression, mode}` |

---

## LLM Client (`nspl.llm`)

### `LLMClient(provider, model=None, max_tokens=64, temperature=0.0)`
- **Providers**: `"claude"`, `"gemini"`, `"openai"`
- **Auth**: SDK (env var API keys) or CLI fallback (browser login)
- **Method**: `query(prompt: str) -> LLMResponse`

### `LLMResponse`
```
text: str
provider: str
model: str
latency_ms: float
success: bool
error: str | None
mode: "cli" | "sdk"
```
