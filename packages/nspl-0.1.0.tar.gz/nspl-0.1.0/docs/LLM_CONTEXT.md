# NSPL: LLM-Parseable Context Document

This document is designed for LLM ingestion. It contains everything an AI agent needs to understand and use NSPL.

## What is NSPL?

NSPL (Non-Stochastic Protection Layer) is a Python package that provides deterministic safety verification for LLM agents. Install with `pip install nspl`. No API keys needed for core features.

## Core Concepts

### 1. Logic Gates
Deterministic boolean/fuzzy logic. Import: `from nspl.core.logic_gates import AND, OR, NOT, XOR, IMPLIES, WEIGHTED_AND`

```python
AND(True, True, mode="hard")       # 1.0
AND(0.9, 0.8, mode="soft")         # 0.849 (product t-norm)
OR(0.2, 0.9)                       # 0.717
NOT(0.7)                           # 0.3
WEIGHTED_AND([0.9, 0.3], [3.0, 1.0])  # weighted conjunction
```

### 2. UncertainValue
Values with confidence scores. Import: `from nspl.core.types import UncertainValue`

```python
v = UncertainValue(value=42, confidence=0.9)
v.map(lambda x: x * 2)       # UncertainValue(84, confidence=0.9)
v.flat_map(fn_returning_uv)  # composes confidence multiplicatively
v.require(0.8, fallback_fn)  # returns value if confident, else fallback
```

Gates accept UncertainValue: `AND(uv1, uv2)` returns UncertainValue with composed confidence.

### 3. Verified Actions
Wrap tool calls with formal checks. Import: `from nspl.actions import action, preconditions, safety_checks, postconditions`

```python
@action
class MyAction:
    def __init__(self, param: str): self.param = param

    @preconditions
    def check(self, ctx): return AND(ctx.valid(self.param), ...)

    @safety_checks
    def safety(self, ctx): return NOT(ctx.is_dangerous(self.param))

    def execute(self, ctx): return ctx.do_thing(self.param)

    @postconditions
    def verify(self, ctx, result): return result.success

result = MyAction("x").safe_execute(ctx)  # runs: pre -> safety -> exec -> post
# result.success, result.result, result.error, result.audit_trail
```

Direct `execute()` calls are blocked with RuntimeError. Must use `safe_execute()`.

### 4. Action Composition
Import: `from nspl.actions import sequence, conditional, parallel`

```python
sequence([action1, action2, action3])      # stops on failure, optional rollback
conditional(check_action, on_true=a, on_false=b)  # branch
parallel([action1, action2, action3])      # all run, collect results
```

### 5. Guards
Import: `from nspl.guards import GuardedLLM, GuardConfig, InputGuard, OutputGuard`

```python
# Wrap any LLM function
guarded = GuardedLLM(
    llm_fn=lambda prompt: my_llm(prompt),
    config=GuardConfig(injection_sensitivity="medium", redact_pii_output=True)
)
result = guarded.call(user_input)
# result.output (safe text or None), result.input_allowed, result.output_allowed
```

InputGuard checks: regex (7 categories), compound patterns, encoded payload decoding, PII, content policy. All deterministic, <1ms.

OutputGuard checks: content policy, PII redaction, system prompt leakage, instruction echo detection.

### 6. Reasoning Pipelines
Import: `from nspl.reasoning import run_pipeline, PipelineConfig`

```python
result = run_pipeline([
    ("plan", plan_fn),
    ("execute", exec_fn),
    ("reflect", reflect_fn),
], initial_input=query, config=PipelineConfig(stage_threshold=0.5, max_retries=2))
# result.output, result.completed_stages, result.trace, result.aborted
```

Async: `from nspl.reasoning import async_run_pipeline`

### 7. Provider Integrations

```python
# Anthropic
from nspl.integrations.anthropic import nspl_tools
tools = nspl_tools([MyAction])  # Anthropic tool_use format

# OpenAI
from nspl.integrations.openai import nspl_tools

# Google ADK
from nspl.integrations.google_adk import nspl_tools

# LangChain
from nspl.integrations.langchain import nspl_langchain_tools
tools = nspl_langchain_tools([MyAction], ctx)

# DSPy
from nspl.integrations.dspy import NSPLGuardModule
guarded = NSPLGuardModule(any_dspy_module)

# MCP Server
# python -m nspl.integrations.mcp_server
# Tools: guard_input, guard_output, detect_pii, evaluate_logic
```

## Key Return Types

- `ActionResult`: success, result, error, audit_trail, duration_ms
- `InputVerdict`: allowed, sanitized_text, detections, reason, risk_score
- `OutputVerdict`: allowed, filtered_text, detections, reason, risk_score
- `GuardResult`: output, input_allowed, output_allowed, input_verdict, output_verdict
- `PipelineResult`: output, trace, completed_stages, aborted, abort_reason
- `UncertainValue`: value, confidence (0-1)
- `DetectorResult`: triggered, detector_name, detail, score, matches

## What Needs No API Keys

Everything except: `nspl.llm` (LLM client), experiments that call LLMs, and `nspl[classifier]` which downloads a model (no key needed, just network).

## Benchmark Results

- Logic gates: 100% accuracy, 0.006ms
- Action safety: 100% TPR, 0% FPR, 0.013ms
- Prompt injection: 92.2% F1, 100% jailbreak recall
- Cross-dataset: 77-100% recall on 5 datasets (4,239 samples)
- PII detection: 100% precision/recall across 6 types
- vs LLM judge: NSPL 88% recall at 33ms vs Gemini 58% at 14,318ms
