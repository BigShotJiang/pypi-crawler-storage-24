# NSPL Implementation with Google Agent Development Kit: A Practical Example

## Overview of the Implementation

This example demonstrates how NSPL integrates with Google's Agent Development Kit (ADK) to create a logic-gated customer service LAM that can safely process refund requests. This implementation provides formal verification guarantees while leveraging Gemini 2.5 Pro's capabilities.

## The Target LAM System

Google's Agent Development Kit (ADK) provides a framework for building, testing, and deploying AI agents using Gemini models. It supports:

- Tool integration through defined interfaces
- Stateful conversations via built-in memory
- Streaming responses for real-time interaction
- Action execution through standardized patterns

## NSPL Implementation Components

### 1. Action Definition in NSPL

First, we define the refund processing action with safety constraints in NSPL:

```python
# NSPL code defining a refund action with safety constraints
action ProcessRefund {
    # Parameters for the action
    parameters {
        order_id: String;
        refund_amount: Float;
        reason: String;
        customer_id: String;
    }

    # Preconditions that must be verified before execution
    preconditions {
        logic_gate AND(
            order_exists(order_id),
            refund_amount <= get_order_total(order_id),
            customer_owns_order(customer_id, order_id),
            refund_reason_valid(reason)
        );
    }

    # Action execution logic
    execution(params) {
        # Submit refund to payment processor
        return payment_system.process_refund(
            params.order_id,
            params.refund_amount,
            params.reason
        );
    }

    # Postcondition verification
    postconditions(params, result) {
        logic_gate AND(
            result.success == true,
            get_order_refund_status(params.order_id) == "refunded",
            result.transaction_id != null
        );
    }

    # Safety constraints
    safety_checks [
        # Verify refund is below authorization threshold
        refund_amount < 1000 || has_manager_approval(),

        # Check for potential fraud patterns
        !has_multiple_recent_refunds(params.customer_id, 3),

        # Audit trail requirement
        log_refund_action(params, "NSPL_VERIFIED")
    ]
}
```

### 2. NSPL Compiler Processing

The NSPL compiler transforms this high-level action definition into executable components:

```python
# Compiled output of NSPL for the ProcessRefund action
# This shows the generated Python code after compilation

class CompiledProcessRefundAction:
    def __init__(self, payment_system, order_service, audit_service):
        self.payment_system = payment_system
        self.order_service = order_service
        self.audit_service = audit_service

    def verify_preconditions(self, params):
        # Generated precondition verification code from NSPL logic gates
        preconditions_satisfied = (
            self.order_service.order_exists(params["order_id"]) and
            params["refund_amount"] <= self.order_service.get_order_total(params["order_id"]) and
            self.order_service.customer_owns_order(params["customer_id"], params["order_id"]) and
            self.order_service.refund_reason_valid(params["reason"])
        )

        if not preconditions_satisfied:
            raise PreconditionFailureException("Refund preconditions not satisfied")

        return True

    def verify_safety(self, params):
        # Generated safety check code
        if params["refund_amount"] >= 1000 and not self.order_service.has_manager_approval():
            raise SafetyViolationException("Refund exceeds limit and lacks approval")

        if self.order_service.has_multiple_recent_refunds(params["customer_id"], 3):
            raise SafetyViolationException("Multiple recent refunds detected")

        # Log for audit trail (required by safety checks)
        self.audit_service.log_refund_action(params, "NSPL_VERIFIED")

        return True

    def execute(self, params):
        # Execute action only after verification
        return self.payment_system.process_refund(
            params["order_id"],
            params["refund_amount"],
            params["reason"]
        )

    def verify_postconditions(self, params, result):
        # Generated postcondition verification
        postconditions_satisfied = (
            result["success"] == True and
            self.order_service.get_order_refund_status(params["order_id"]) == "refunded" and
            result["transaction_id"] is not None
        )

        if not postconditions_satisfied:
            raise PostconditionFailureException("Refund postconditions not satisfied")

        return True
```

### 3. Google ADK Integration

Now we integrate the compiled NSPL components with Google's Agent Development Kit:

```python
from google.cloud.vertexai.agents import Agent, Tool
from nspl.runtime import NSPLActionRegistry
from nspl.compiled.actions import CompiledProcessRefundAction

# Initialize the action with required services
refund_action = CompiledProcessRefundAction(
    payment_system=PaymentSystemClient(),
    order_service=OrderServiceClient(),
    audit_service=AuditServiceClient()
)

# Register the action with NSPL runtime
nspl_registry = NSPLActionRegistry()
nspl_registry.register_action("process_refund", refund_action)

# Create a verified tool adapter for Google ADK
# This wraps the NSPL action in an ADK-compatible tool
class NSPLVerifiedTool(Tool):
    def __init__(self, action_name, nspl_registry):
        self.action_name = action_name
        self.nspl_registry = nspl_registry

    def execute(self, params):
        # Get the NSPL action from registry
        action = self.nspl_registry.get_action(self.action_name)

        try:
            # NSPL verification and execution pipeline
            action.verify_preconditions(params)
            action.verify_safety(params)
            result = action.execute(params)
            action.verify_postconditions(params, result)
            return {"status": "success", "result": result}
        except Exception as e:
            return {"status": "failure", "error": str(e)}

# Create ADK agent with NSPL-verified tools
customer_service_agent = Agent.create(
    display_name="NSPL-Verified Customer Service Agent",
    tools=[
        NSPLVerifiedTool("process_refund", nspl_registry)
    ],
    model="gemini-2.5-pro"
)
```

### 4. Execution Flow

When a user interacts with this agent requesting a refund, the execution follows this flow:

```
User Request → Google ADK Agent → NSPL Verification Pipeline → Action Execution
  |                                  1. Precondition Check
  |                                  2. Safety Check
  |                                  3. Execution
  |                                  4. Postcondition Check
  V
User Response ← Google ADK Agent ← Verified Result
```

## Practical Example: Customer Conversation

Here's how this implementation would handle a real customer interaction:

**User**: "I need a refund for my order #12345. The product arrived damaged."

**ADK Agent**: (using Gemini model) "I'm sorry to hear about the damaged product. I can help process a refund for order #12345. The order total is $89.99. Would you like a full refund?"

**User**: "Yes, please."

**ADK Agent**: (preparing to take action)
1. Calls the NSPL-verified ProcessRefund tool
2. NSPL runtime verifies:
   - Preconditions: Order #12345 exists and belongs to the customer
   - Safety: Refund amount is below threshold, no fraud indicators
3. Executes the refund
4. Verifies postconditions: Refund was successfully processed

**ADK Agent**: "Great news! I've processed a full refund of $89.99 for order #12345. The refund has been approved and you should see it in your account within 3-5 business days. Your refund confirmation number is TXN-7890123. Is there anything else I can help you with?"

## Advantages of This Implementation

This NSPL + Google ADK implementation provides:

1. Formal verification guarantees around refund processing
2. Clear safety boundaries that prevent unauthorized refunds
3. Audit trails for all verified actions
4. Seamless integration with Google's agent capabilities
5. Maintainable code where verification logic is separate from business logic

By using NSPL to define and verify the actions that the Google ADK agent can take, we create a safer, more predictable system without compromising the flexibility and natural language capabilities of the underlying Gemini model.

# How NSPL Would Actually Be Implemented and Compiled

You've identified a critical point. You're absolutely right - standard Python wouldn't know how to handle the NSPL syntax I showed, and neither would the LAM directly understand it. Let me clarify how this would actually work in a realistic implementation.

## Practical Implementation Approach

In practice, NSPL would be implemented in one of three ways:

### 1. Python Framework with Decorators (Most Likely Approach)

Rather than creating an entirely new language, NSPL would likely be implemented as a Python framework using decorators and special classes:

```python
# How NSPL would realistically be implemented in Python
from nspl.framework import action, logic_gate, preconditions, postconditions, safety_checks

@action
class ProcessRefund:
    def __init__(self, payment_system, order_service, audit_service):
        self.payment_system = payment_system
        self.order_service = order_service
        self.audit_service = audit_service

    @preconditions
    def check_preconditions(self, params):
        return logic_gate.AND([
            self.order_service.order_exists(params["order_id"]),
            params["refund_amount"] <= self.order_service.get_order_total(params["order_id"]),
            self.order_service.customer_owns_order(params["customer_id"], params["order_id"]),
            self.order_service.refund_reason_valid(params["reason"])
        ])

    @safety_checks
    def verify_safety(self, params):
        high_value_check = logic_gate.OR([
            params["refund_amount"] < 1000,
            self.order_service.has_manager_approval()
        ])

        fraud_check = logic_gate.NOT(
            self.order_service.has_multiple_recent_refunds(params["customer_id"], 3)
        )

        audit_check = self.audit_service.log_refund_action(params, "NSPL_VERIFIED")

        return logic_gate.AND([high_value_check, fraud_check, audit_check])

    def execute(self, params):
        return self.payment_system.process_refund(
            params["order_id"],
            params["refund_amount"],
            params["reason"]
        )

    @postconditions
    def check_postconditions(self, params, result):
        return logic_gate.AND([
            result["success"] == True,
            self.order_service.get_order_refund_status(params["order_id"]) == "refunded",
            result["transaction_id"] is not None
        ])
```

### 2. DSL with Python Parser (Advanced Approach)

Alternatively, NSPL could be implemented as a domain-specific language with a Python parser:

```python
from nspl.parser import parse_nspl_file
from nspl.runtime import NSPLRuntime

# Parse NSPL file and generate executable components
refund_action = parse_nspl_file("refund_action.nspl")

# Configure runtime with necessary services
runtime = NSPLRuntime()
runtime.register_service("payment_system", PaymentSystemClient())
runtime.register_service("order_service", OrderServiceClient())
runtime.register_service("audit_service", AuditServiceClient())

# Register action with runtime
runtime.register_action("process_refund", refund_action)
```

### 3. Code Generation Approach (Hybrid Solution)

NSPL could also work through code generation:

```python
from nspl.generator import generate_code_from_nspl

# Generate Python code from NSPL specifications
generated_python = generate_code_from_nspl("refund_action.nspl", target="python")

# The generated code can be either:
# 1. Written to a file and imported
with open("generated_refund_action.py", "w") as f:
    f.write(generated_python)

# 2. Or executed directly
exec(generated_python, globals())
```

## Integration with LAMs in Reality

Here's how NSPL would realistically integrate with Google's Agent Development Kit:

```python
from google.cloud.vertexai.agents import Agent, Tool
from nspl.framework import ActionRegistry

# Initialize the NSPL registry with our action
registry = ActionRegistry()
refund_action = ProcessRefund(
    payment_system=PaymentSystemClient(),
    order_service=OrderServiceClient(),
    audit_service=AuditServiceClient()
)
registry.register("process_refund", refund_action)

# Create an ADK tool that interfaces with our NSPL action
class RefundTool(Tool):
    def __init__(self, action_registry):
        self.registry = action_registry

    def execute(self, params):
        # Get the action from NSPL registry
        action = self.registry.get_action("process_refund")

        # This calls the decorated methods in sequence
        # ensuring verification before execution
        return action.safe_execute(params)

# Create ADK agent with NSPL tool
customer_service_agent = Agent.create(
    display_name="Customer Service Agent",
    tools=[RefundTool(registry)],
    model="gemini-2.5-pro"
)
```

## The Execution Process

In this realistic implementation:

1. **No Custom Compiler Needed**: We're using Python's existing capabilities with a specialized framework, avoiding the need for a custom compiler.

2. **Framework Handles Verification**: The NSPL framework provides decorators and utility functions that ensure verification happens in the correct sequence.

3. **LAM Integration via APIs**: The LAM interacts with NSPL actions through standard API interfaces, not by understanding NSPL directly.

4. **Runtime Enforcement**: The NSPL runtime ensures that actions can only be executed if their preconditions and safety checks pass.

This approach represents a practical path to implementing NSPL-like functionality today, using existing technology stacks while providing the same verification benefits described in the conceptual overview.

# Neural-Symbolic Programming Language (NSPL) Framework

## 1. Core Architecture

### 1.1 Framework Layers

```
+-----------------------------------------+
|           Application Layer             |
|  (User-defined AI agents and systems)   |
+-----------------------------------------+
|           NSPL Standard Library         |
| (Neural, Symbolic & Integration modules)|
+-----------------------------------------+
|         NSPL Runtime Environment        |
| (Neural runtime, Symbolic runtime,      |
|  Bridge runtime, Memory management)     |
+-----------------------------------------+
|          Integration Layer              |
| (LAM/LLM APIs, MCP tools, A2A protocol) |
+-----------------------------------------+
|          Execution Backends             |
| (PyTorch, TensorFlow, Z3, Prolog, etc.) |
+-----------------------------------------+
```

### 1.2 Implementation Structure

```python
# High-level package structure
nspl/
    __init__.py
    core/                # Core functionality
        types.py         # Type system
        logic_gates.py   # Logic gate implementations
        concepts.py      # Concept definitions
        uncertainty.py   # Uncertainty handling

    reasoning/           # Reasoning components
        pipeline.py      # Multi-stage reasoning
        planning.py      # Planning stage
        exploration.py   # Exploration stage
        execution.py     # Execution stage
        reflection.py    # Reflection stage

    actions/             # Action components
        action.py        # Action base class
        verification.py  # Pre/post condition verification
        safety.py        # Safety mechanisms

    neural/              # Neural components
        embeddings.py    # Embedding utilities
        similarity.py    # Neural similarity
        conversion.py    # Neural-to-symbolic conversion

    symbolic/            # Symbolic components
        inference.py     # Symbolic inference
        rules.py         # Rule management
        knowledge.py     # Knowledge representation

    tools/               # Tool integration
        mcp.py           # Model Context Protocol
        a2a.py           # Agent-to-Agent Protocol

    runtime/             # Runtime system
        memory.py        # Memory management
        executor.py      # Execution coordination
        monitor.py       # Safety monitoring

    utils/               # Utilities
        visualization.py # Visualization tools
        logging.py       # Logging utilities

    testing/             # Testing utilities
        verification.py  # Verification testing
        property.py      # Property-based testing
```

## 2. Core Components API

### 2.1 Type System

```python
from nspl.core import types

# Basic types
boolean_type = types.Boolean()
number_type = types.Number()
string_type = types.String()

# Neural types
vector_type = types.Vector(dimension=256)
embedding_type = types.Embedding(source="text")

# Symbolic types
term_type = types.Term()
formula_type = types.Formula()

# Hybrid types
uncertain_value = types.UncertainValue(value_type=types.Number())
concept_type = types.Concept(
    symbolic=types.Record({"name": types.String(), "age": types.Number()}),
    neural=types.Vector(dimension=256)
)
```

### 2.2 Logic Gates

```python
from nspl.core import logic_gates

# Basic logic gates
and_gate = logic_gates.AND(threshold1=0.5, threshold2=0.5)
or_gate = logic_gates.OR(threshold1=0.5, threshold2=0.5)
not_gate = logic_gates.NOT(threshold=0.5)

# Parameterized logic gates
weighted_and = logic_gates.WeightedAND(
    weights=[0.7, 0.3],
    thresholds=[0.4, 0.6]
)

# Logic gate composition
complex_gate = logic_gates.compose(
    logic_gates.AND,
    [
        logic_gates.OR(input1=a, input2=b),
        logic_gates.NOT(input=c)
    ]
)

# Training logic gates
trained_gate = logic_gates.train(
    gate=and_gate,
    training_data=[
        ((0.1, 0.2), 0.0),
        ((0.9, 0.8), 1.0),
        ((0.9, 0.3), 0.2)
    ],
    learning_rate=0.01
)
```

### 2.3 Concept Definitions

```python
from nspl.core import concepts
from nspl.neural import embeddings

# Define a concept
@concepts.concept
class Person:
    # Neural representation
    embedding = embeddings.Embedding(source="person", dimension=256)

    # Symbolic attributes
    attributes = {
        "name": concepts.String(),
        "age": concepts.Number(constraints=[concepts.GreaterThan(0)])
    }

    # Rules
    @concepts.rule
    def is_adult(self):
        return self.age >= 18

    # Descriptions for different contexts
    descriptions = {
        "brief": "A person with a name and age",
        "detailed": "A human individual identified by name and characterized by age"
    }

# Create an instance
john = Person(name="John", age=30)

# Access neural representation
john_embedding = john.embedding

# Access symbolic attributes
print(john.name)  # "John"

# Evaluate rules
print(john.is_adult())  # True

# Create neural representation from symbolic
embedding = embeddings.create_embedding(john)
```

## 3. Reasoning Pipelines

### 3.1 Multi-Stage Reasoning

```python
from nspl.reasoning import pipeline, stages

# Define a reasoning pipeline
@pipeline.reasoning
def answer_question(question: str) -> dict:

    # Planning stage
    @stages.planning
    def create_plan(question):
        # Plan generation logic...
        return plan

    # Exploration stage
    @stages.exploration
    def explore_alternatives(plan):
        # Exploration logic...
        return alternatives

    # Execution stage
    @stages.execution
    def execute_plan(alternatives):
        # Execution logic...
        return result

    # Reflection stage
    @stages.reflection
    def reflect_on_result(result):
        # Reflection logic...
        return {
            "answer": final_answer,
            "confidence": confidence,
            "reasoning_path": reasoning_path
        }

    # Pipeline execution
    plan = create_plan(question)
    alternatives = explore_alternatives(plan)
    result = execute_plan(alternatives)
    return reflect_on_result(result)
```

### 3.2 Verification Mechanisms

```python
from nspl.reasoning import verification

# Define a property to verify
@verification.property
def answer_consistency(answer, context):
    """Verifies that the answer is consistent with the context."""
    return logic_gates.NOT(
        logic_gates.AND(
            statement_in_answer(answer, statement),
            contradicts(statement, context)
        )
    )

# Apply verification to a reasoning function
@verification.verified([answer_consistency])
def generate_answer(question, context):
    # Answer generation logic...
    return answer
```

## 4. Action System

### 4.1 Action Definition

```python
from nspl.actions import action, conditions, safety

# Define an action
@action.define
class SendEmail:
    # Action parameters
    parameters = {
        "recipient": str,
        "subject": str,
        "content": str,
        "attachments": list
    }

    # Preconditions
    @conditions.preconditions
    def check_preconditions(self, params):
        return logic_gates.AND([
            is_valid_email(params["recipient"]),
            has_permission_to_email(params["recipient"]),
            not contains_sensitive_data(params["content"])
        ])

    # Execution logic
    def execute(self, params):
        # Email sending logic...
        return {
            "success": True,
            "message_id": "ABC123",
            "send_time": "2025-05-01T12:34:56Z"
        }

    # Postconditions
    @conditions.postconditions
    def check_postconditions(self, params, result):
        return logic_gates.AND([
            result["success"] == True,
            result["message_id"] is not None
        ])

    # Safety checks
    @safety.checks
    def verify_safety(self, params):
        return logic_gates.AND([
            not contains_malicious_content(params["content"]),
            not exceeds_rate_limit(params["recipient"]),
            log_email_attempt(params)
        ])

# Use the action
email_action = SendEmail()
result = email_action.safe_execute({
    "recipient": "user@example.com",
    "subject": "Hello",
    "content": "This is a test email",
    "attachments": []
})
```

### 4.2 Action Composition

```python
from nspl.actions import composition

# Compose multiple actions into a sequence
email_sequence = composition.sequence([
    # First validate the content
    ValidateEmailContent(
        content="${content}",
        check_spam=True
    ),

    # Then prepare attachments if any
    composition.conditional(
        condition=lambda params: len(params["attachments"]) > 0,
        action=PrepareAttachments(attachments="${attachments}")
    ),

    # Finally send the email
    SendEmail(
        recipient="${recipient}",
        subject="${subject}",
        content="${validated_content}",
        attachments="${prepared_attachments}"
    )
])

# Execute the sequence
result = email_sequence.execute({
    "recipient": "user@example.com",
    "subject": "Hello",
    "content": "This is a test email",
    "attachments": ["document.pdf"]
})
```

## 5. Neural-Symbolic Integration

### 5.1 Neural to Symbolic Conversion

```python
from nspl.neural import conversion

# Convert embedding to symbolic representation
embedding = get_text_embedding("The capital of France is Paris")
symbolic_facts = conversion.symbolize(
    embedding,
    domain="geography",
    confidence_threshold=0.7
)

# Result is an uncertain value with symbolic facts
print(symbolic_facts.value)  # [Fact("capital_of", "Paris", "France")]
print(symbolic_facts.confidence)  # 0.92
```

### 5.2 Symbolic to Neural Conversion

```python
from nspl.symbolic import conversion

# Convert symbolic representation to embedding
facts = [
    Fact("capital_of", "Paris", "France"),
    Fact("population", "France", "67 million")
]

embedding = conversion.neuralize(
    facts,
    embedding_space="geography"
)

# Result is a vector representation
print(embedding.shape)  # (256,)
```

### 5.3 Concept Alignment

```python
from nspl.core import alignment

# Check alignment between neural and symbolic representations
person = Person(name="John", age=30)

# Update neural representation based on symbolic changes
person.age = 31
alignment.update_neural(person)

# Update symbolic representation based on neural changes
modified_embedding = transform_embedding(person.embedding)
person = alignment.update_symbolic(person, modified_embedding)

# Verify alignment is maintained
alignment_score = alignment.check(person)
print(f"Alignment score: {alignment_score}")  # e.g., 0.89
```

## 6. Uncertainty Handling

### 6.1 Uncertain Values

```python
from nspl.core import uncertainty

# Create uncertain values
temperature = uncertainty.UncertainValue(
    value=22.5,
    confidence=0.8,
    distribution=uncertainty.NormalDistribution(mean=22.5, std=1.2)
)

classification = uncertainty.UncertainValue(
    value="dog",
    confidence=0.7,
    distribution={
        "dog": 0.7,
        "wolf": 0.2,
        "fox": 0.1
    }
)

# Operations with uncertainty propagation
def celsius_to_fahrenheit(c):
    return c * 9/5 + 32

fahrenheit = uncertainty.propagate(celsius_to_fahrenheit, temperature)
print(fahrenheit.value)  # 72.5
print(fahrenheit.confidence)  # 0.8 (preserved)
```

### 6.2 Decision Making Under Uncertainty

```python
from nspl.core import decision

# Make decisions with uncertainty handling
result = decision.decide(
    condition=temperature.value > 25,
    condition_confidence=temperature.confidence,
    threshold=0.8,
    true_branch=lambda: "It's hot",
    false_branch=lambda: "It's not hot",
    uncertain_branch=lambda: "Temperature is uncertain"
)

# Result depends on confidence
# Since confidence (0.8) meets the threshold, but the value (22.5) is not > 25,
# this would return "It's not hot"
print(result)  # "It's not hot"

# With lower confidence
low_conf_temp = uncertainty.UncertainValue(value=26, confidence=0.6)
result = decision.decide(
    condition=low_conf_temp.value > 25,
    condition_confidence=low_conf_temp.confidence,
    threshold=0.8,
    true_branch=lambda: "It's hot",
    false_branch=lambda: "It's not hot",
    uncertain_branch=lambda: "Temperature is uncertain"
)
print(result)  # "Temperature is uncertain"
```

## 7. Tool Integration

### 7.1 MCP Integration

```python
from nspl.tools import mcp

# Create an MCP server wrapper
github_server = mcp.Server(
    name="github",
    resources=[
        mcp.Resource(
            name="repositories",
            description="List user repositories",
            read=lambda params: github_api.list_repositories(params["username"])
        ),
        mcp.Resource(
            name="issues",
            description="List issues in a repository",
            read=lambda params: github_api.list_issues(
                params["owner"],
                params["repo"]
            )
        )
    ],
    tools=[
        mcp.Tool(
            name="create_issue",
            description="Create a new issue",
            parameters={
                "owner": {"type": "string"},
                "repo": {"type": "string"},
                "title": {"type": "string"},
                "body": {"type": "string"}
            },
            execute=lambda params: github_api.create_issue(
                params["owner"],
                params["repo"],
                params["title"],
                params["body"]
            )
        )
    ]
)

# Use the MCP server in NSPL
github_data = github_server.read_resource(
    "repositories",
    {"username": "octocat"}
)

issue_result = github_server.execute_tool(
    "create_issue",
    {
        "owner": "octocat",
        "repo": "hello-world",
        "title": "Bug in feature X",
        "body": "This feature is not working as expected"
    }
)
```

### 7.2 A2A Integration

```python
from nspl.tools import a2a

# Define an agent capability
code_review_agent = a2a.Agent(
    name="code-review",
    capabilities=["python", "javascript", "security"],
    description="Reviews code for bugs and security issues"
)

# Publish agent card
a2a.publish_card(code_review_agent)

# Handle incoming task requests
@a2a.task_handler(code_review_agent)
def handle_code_review(task):
    code = task.get_content()

    # Use NSPL reasoning pipeline to review code
    review_result = review_code(code)

    # Return task result
    return a2a.TaskResult(
        content=review_result,
        status="completed"
    )

# Start A2A server
a2a.start_server(code_review_agent)
```

## 8. Runtime System

### 8.1 Memory Management

```python
from nspl.runtime import memory

# Create memory stores
# Short-term memory (conversation context)
context_memory = memory.ShortTermMemory(capacity=10)
context_memory.add({
    "user_message": "What's the weather like?",
    "system_response": "It's sunny today."
})

# Long-term memory (knowledge base)
knowledge_memory = memory.LongTermMemory(
    storage_type="vector",
    connection_string="postgres://localhost:5432/nspl_memory"
)
knowledge_memory.add({
    "user_id": "12345",
    "preference": "Prefers technical explanations",
    "embedding": user_embedding
})

# Access memory
recent_context = context_memory.get_recent(2)
user_preferences = knowledge_memory.query(
    filter={"user_id": "12345"},
    limit=1
)
```

### 8.2 Execution Monitoring

```python
from nspl.runtime import monitoring

# Set up execution monitor
monitor = monitoring.ExecutionMonitor(
    safety_thresholds={
        "memory_usage": 2000,  # MB
        "execution_time": 30,  # seconds
        "api_calls": 10
    }
)

# Monitor an action execution
with monitor.track("send_email_action"):
    result = send_email_action.execute(params)

# Get monitoring results
monitoring_report = monitor.get_report()
print(f"Memory peak: {monitoring_report['memory_peak']} MB")
print(f"Execution time: {monitoring_report['execution_time']} sec")
print(f"API calls: {monitoring_report['api_calls']}")

# Handle safety violations
if monitor.has_violations():
    print("Safety violations:", monitor.get_violations())
```

## 9. LAM/LLM Integration

### 9.1 LLM as Reasoning Engine

```python
from nspl.integration import llm

# Create an LLM-backed reasoning component
gemini_reasoning = llm.LLMReasoning(
    model="gemini-2.5-pro",
    max_tokens=2048,
    temperature=0.2
)

# Use LLM for planning stage
@stages.planning
@llm.with_reasoning(gemini_reasoning)
def create_plan(question):
    """
    Create a plan to answer the user's question.
    The plan should include:
    1. What information is needed
    2. What sources to consult
    3. What steps to take

    Question: {question}

    Plan:
    """
    # The function body is ignored - the LLM generates the completion
    pass
```

### 9.2 LAM Integration

```python
from nspl.integration import lam

# Create a verified LAM action
email_lam = lam.VerifiedLAMAction(
    action_definition=SendEmail(),
    model="gemini-2.5-pro",
    verification_level="strict"
)

# Execute with LAM
result = email_lam.execute({
    "user_intent": "I want to send an email to john@example.com about the meeting tomorrow",
    "context": {
        "user_email": "alice@example.com",
        "recent_conversations": [...]
    }
})

# Result contains both the LAM processing and verified execution
print(result.understood_parameters)  # Parameters extracted by LAM
print(result.verification_results)   # Results of verification checks
print(result.execution_result)       # Result of the action execution
```

## 10. Testing and Verification

### 10.1 Unit Testing Components

```python
from nspl.testing import test_suite, assertions

# Test a logic gate
@test_suite.test_case
def test_and_gate():
    # Create gate
    and_gate = logic_gates.AND(threshold1=0.5, threshold2=0.5)

    # Test with different inputs
    assertions.assert_close(and_gate(0.0, 0.0), 0.0, tolerance=0.1)
    assertions.assert_close(and_gate(1.0, 0.0), 0.0, tolerance=0.1)
    assertions.assert_close(and_gate(0.0, 1.0), 0.0, tolerance=0.1)
    assertions.assert_close(and_gate(1.0, 1.0), 1.0, tolerance=0.1)

    # Test with uncertainty
    uncertain_input1 = uncertainty.UncertainValue(0.7, 0.8)
    uncertain_input2 = uncertainty.UncertainValue(0.8, 0.9)
    result = and_gate(uncertain_input1, uncertain_input2)

    assertions.assert_true(result.value > 0.5)
    assertions.assert_true(result.confidence < min(0.8, 0.9))

# Run tests
test_suite.run()
```

### 10.2 Property-Based Testing

```python
from nspl.testing import properties

# Define a property for logic gates
@properties.property
def and_gate_commutativity(x, y):
    """Tests that AND gate is commutative: AND(x, y) = AND(y, x)"""
    and_gate = logic_gates.AND()
    return abs(and_gate(x, y) - and_gate(y, x)) < 1e-5

# Test the property with generated values
properties.check(
    and_gate_commutativity,
    x=properties.floats(min_value=0.0, max_value=1.0),
    y=properties.floats(min_value=0.0, max_value=1.0),
    num_tests=100
)
```

### 10.3 Formal Verification

```python
from nspl.verification import formal

# Define a property to verify
@formal.verify
def refund_safety(action, params):
    """
    Verify that refund amount never exceeds order total
    and is only processed for valid orders.
    """
    return logic_gates.AND(
        params["refund_amount"] <= get_order_total(params["order_id"]),
        order_exists(params["order_id"])
    )

# Apply verification to an action
@formal.verified([refund_safety])
class ProcessRefund(Action):
    # Action implementation...
    pass
```

## 11. Example Applications

### 11.1 Customer Service Agent

```python
from nspl.applications import agent

# Create a customer service agent
customer_agent = agent.Agent(
    name="CustomerServiceAgent",
    description="Handles customer inquiries and support requests"
)

# Add reasoning pipeline
customer_agent.add_reasoning(
    answer_question,
    domain="customer_support"
)

# Add verified actions
customer_agent.add_action(ProcessRefund())
customer_agent.add_action(UpdateOrder())
customer_agent.add_action(CheckOrderStatus())

# Add knowledge base
customer_agent.add_knowledge(
    memory.LongTermMemory(
        storage_type="vector",
        connection_string="postgres://localhost:5432/customer_knowledge"
    )
)

# Deploy agent
agent.deploy(
    customer_agent,
    endpoint="/api/customer-agent",
    auth_method="api_key"
)
```

### 11.2 Data Analysis Workflow

```python
from nspl.applications import workflow

# Create a data analysis workflow
analysis_workflow = workflow.Workflow(
    name="DataAnalysisWorkflow",
    description="Analyzes financial data and generates reports"
)

# Add workflow stages
analysis_workflow.add_stage(
    name="data_loading",
    action=LoadDataAction(
        sources=["database", "api", "files"],
        validation=True
    )
)

analysis_workflow.add_stage(
    name="data_preprocessing",
    action=PreprocessDataAction(
        clean=True,
        normalize=True,
        handle_missing=True
    )
)

analysis_workflow.add_stage(
    name="analysis",
    action=AnalyzeDataAction(
        methods=["statistical", "ml"],
        visualize=True
    )
)

analysis_workflow.add_stage(
    name="report_generation",
    action=GenerateReportAction(
        format="pdf",
        include_charts=True
    )
)

# Run workflow
workflow_instance = analysis_workflow.create_instance(
    input_data={
        "dataset": "financial_q2_2025",
        "parameters": {
            "time_period": "quarterly",
            "metrics": ["revenue", "expenses", "profit"]
        }
    }
)

result = workflow_instance.execute()
```
