# Artifact 3: NSPL Language Specification

## 1. Language Overview

The Neural-Symbolic Programming Language (NSPL) is designed to bridge neural network capabilities with symbolic reasoning through a unified programming framework. This specification defines the complete syntax and semantics of NSPL, building on the mathematical foundations established in the previous artifact.

### 1.1 Design Philosophy

NSPL is guided by the following design principles:

1. **Dual Representation**: Native support for both neural and symbolic representations
2. **First-Class Logic**: Logical operations as fundamental language constructs
3. **Explicit Uncertainty**: Built-in mechanisms for representing and reasoning with uncertainty
4. **Verifiability**: Support for formal verification of program properties
5. **Natural Language Integration**: Seamless transitions between natural and formal language
6. **Action-Oriented**: Native support for specifying and executing actions

### 1.2 Key Features

NSPL provides the following key features:

- **Neural-Symbolic Types**: A rich type system supporting both neural and symbolic representations
- **Logic Gates**: First-class logic gates that operate on both symbolic values and neural representations
- **Multi-Stage Reasoning**: Explicit structures for planning, exploration, execution, and reflection
- **Action Specification**: Built-in constructs for specifying, verifying, and executing actions
- **Uncertainty Handling**: Pervasive support for uncertainty throughout the language
- **Verification Mechanisms**: Built-in support for verifying program properties

## 2. Syntax Specification

### 2.1 Lexical Structure

NSPL uses a modern lexical structure similar to languages like Python and Rust:

```
letter    ::= 'a' | 'b' | ... | 'z' | 'A' | 'B' | ... | 'Z'
digit     ::= '0' | '1' | ... | '9'
identifier ::= letter (letter | digit | '_')*
number    ::= digit+ ['.' digit+] [('e' | 'E') ['+' | '-'] digit+]
string    ::= '"' char* '"'
```

### 2.2 Type Declarations

```
type-decl ::= 'type' identifier type-params? type-def
type-params ::= '<' identifier (',' identifier)* '>'
type-def ::= basic-type | struct-type | enum-type | alias-type

basic-type ::= 'Boolean' | 'Number' | 'String' | 'Vector' '<' expr '>' 
             | 'Tensor' '<' expr (',' expr)* '>' | 'Distribution' '<' type '>'
             | 'Embedding' '<' string '>'

struct-type ::= '{' field-decl* '}'
field-decl ::= identifier ':' type ';'

enum-type ::= '|' variant-decl ('|' variant-decl)*
variant-decl ::= identifier ['(' type ')']

alias-type ::= '=' type
```

### 2.3 Concept Declarations

```
concept-decl ::= 'concept' identifier type-params? '{' concept-body '}'
concept-body ::= embedding-decl? attributes-decl? rules-decl? descriptions-decl?

embedding-decl ::= 'embedding' ':' embedding-expr ';'
embedding-expr ::= 'Embedding' '<' string '>' | expr

attributes-decl ::= 'attributes' '{' field-decl* '}'

rules-decl ::= 'rules' '{' rule-decl* '}'
rule-decl ::= identifier ':=' logical-expr ';'

descriptions-decl ::= 'descriptions' '{' description-decl* '}'
description-decl ::= string ':' string ';'
```

### 2.4 Logic Gate Declarations

```
logic-gate-decl ::= 'logic_gate' identifier type-params? '(' param-list ')' '->' type gate-body
param-list ::= param (',' param)*
param ::= identifier ':' type ['=' expr]
gate-body ::= '{' stmt* '}'
```

### 2.5 Function Declarations

```
function-decl ::= 'function' identifier type-params? '(' param-list ')' '->' type function-body
function-body ::= '{' stmt* '}'
```

### 2.6 Action Declarations

```
action-decl ::= 'action' identifier type-params? '{' action-body '}'
action-body ::= preconditions-decl? parameters-decl? execution-decl? postconditions-decl? 
               safety-checks-decl? permissions-decl?

preconditions-decl ::= 'preconditions' '{' logical-expr '}'

parameters-decl ::= 'parameters' '{' field-decl* '}'

execution-decl ::= 'execution' '(' param-name ')' '{' stmt* '}'
param-name ::= identifier

postconditions-decl ::= 'postconditions' '(' param-name ',' result-name ')' '{' logical-expr '}'
result-name ::= identifier

safety-checks-decl ::= 'safety_checks' '[' safety-check (',' safety-check)* ']'
safety-check ::= expr

permissions-decl ::= 'permissions' '[' permission (',' permission)* ']'
permission ::= expr
```

### 2.7 Reasoning Pipeline Declarations

```
reasoning-decl ::= 'reasoning' identifier type-params? '(' param-list ')' '->' type '{' reasoning-body '}'
reasoning-body ::= input-decl? stage-decl+ output-decl?

input-decl ::= 'input' ':' expr ';'

stage-decl ::= 'stage' identifier ['(' param-list ')'] '{' stmt* '}'

output-decl ::= 'output' ':' expr ';'
```

### 2.8 Expressions

```
expr ::= literal | identifier | unary-expr | binary-expr | call-expr | index-expr 
       | field-expr | logic-expr | decision-expr | natural-language-expr

literal ::= number | string | boolean | 'null'
boolean ::= 'true' | 'false'

unary-expr ::= unary-op expr
unary-op ::= '+' | '-' | '!' | '~'

binary-expr ::= expr binary-op expr
binary-op ::= '+' | '-' | '*' | '/' | '%' | '==' | '!=' | '<' | '<=' | '>' | '>=' | '&&' | '||'

call-expr ::= expr '(' expr-list? ')'
expr-list ::= expr (',' expr)*

index-expr ::= expr '[' expr ']'

field-expr ::= expr '.' identifier

logic-expr ::= logic-gate '(' expr-list ')'
             | expr 'and' expr | expr 'or' expr | 'not' expr
             | 'forall' identifier 'in' expr ':' expr
             | 'exists' identifier 'in' expr ':' expr

decision-expr ::= 'decide' '(' expr ',' expr ',' expr ',' expr [',' expr] ')'

natural-language-expr ::= '@natural_language' '(' string ')'
```

### 2.9 Statements

```
stmt ::= var-decl | assign-stmt | if-stmt | for-stmt | while-stmt | return-stmt
       | verify-stmt | assert-stmt | execute-stmt

var-decl ::= ['let' | 'const'] identifier [':' type] '=' expr ';'

assign-stmt ::= expr '=' expr ';'

if-stmt ::= 'if' '(' expr ')' block ['else' (if-stmt | block)]
block ::= '{' stmt* '}'

for-stmt ::= 'for' '(' [var-decl] ';' expr ';' expr ')' block
           | 'for' identifier 'in' expr block

while-stmt ::= 'while' '(' expr ')' block

return-stmt ::= 'return' expr? ';'

verify-stmt ::= 'verify' expr 'satisfies' expr ';'

assert-stmt ::= 'assert' expr ';'

execute-stmt ::= 'execute' expr ';'
```

## 3. Semantic Specification

### 3.1 Type System Semantics

The NSPL type system includes both standard programming language types and specialized neural-symbolic types:

1. **Basic Types**:
   - `Boolean`: Truth values (true or false)
   - `Number`: Numeric values (integers and floating-point)
   - `String`: Text values

2. **Neural Types**:
   - `Vector<n>`: n-dimensional vector, typically representing neural embeddings
   - `Tensor<d1, d2, ..., dn>`: Multi-dimensional tensor
   - `Embedding<source>`: Neural embedding with explicit source information

3. **Uncertainty Types**:
   - `Distribution<T>`: Probability distribution over values of type T
   - `UncertainValue<T>`: Value of type T with associated confidence and distribution

4. **Hybrid Types**:
   - `Concept<T>`: Dual representation with both neural and symbolic components

Types can be composed using:
- Function types: `T1 -> T2`
- Product types: `T1 × T2 × ... × Tn`
- Sum types: `T1 | T2 | ... | Tn`
- Generic types: `Container<T>`

### 3.2 Logic Gate Semantics

Logic gates in NSPL have the following semantics:

1. **Basic Logic Gates**:
   - `AND`: Outputs true if all inputs exceed their thresholds
   - `OR`: Outputs true if any input exceeds its threshold
   - `NOT`: Outputs true if the input is below its threshold
   - `XOR`: Outputs true if an odd number of inputs exceed their thresholds

2. **Parameterization**:
   - Gates can have threshold parameters for each input
   - Gates can have weights for inputs
   - Parameters can be learned through training

3. **Differentiability**:
   - All gates are differentiable for gradient-based learning
   - Smooth approximations are used for logical operations

4. **Typed Logic Gates**:
   - Gates can operate on various input types
   - Type conversion is handled automatically for compatible types

### 3.3 Action Semantics

Actions in NSPL have the following semantics:

1. **Preconditions**:
   - Logical expressions that must be satisfied before execution
   - Can access parameters and external state
   - Failure to meet preconditions prevents execution

2. **Execution**:
   - Performs the action, potentially modifying state
   - Has access to parameters and external resources
   - Can produce output values and side effects

3. **Postconditions**:
   - Logical expressions that must be satisfied after execution
   - Verify the correctness of the action's effects
   - Failure indicates potential bugs or unexpected behavior

4. **Safety Checks**:
   - Additional verification beyond preconditions
   - May involve specialized safety mechanisms
   - Can include intent verification and outcome simulation

5. **Permissions**:
   - Access control specifications
   - Determine what resources the action can use
   - Enforce least privilege principle

### 3.4 Reasoning Pipeline Semantics

Reasoning pipelines in NSPL have the following semantics:

1. **Input Processing**:
   - Converts external inputs to internal representations
   - Can include natural language understanding
   - May extract relevant features and context

2. **Stage Execution**:
   - Stages are executed sequentially by default
   - Each stage receives input from previous stages
   - Stages can have internal state and access shared context

3. **Planning Stage**:
   - Generates plans to achieve goals
   - Considers constraints and resources
   - Produces structured plan representations

4. **Exploration Stage**:
   - Investigates alternative plans and approaches
   - Evaluates options based on criteria
   - Selects promising paths for execution

5. **Execution Stage**:
   - Carries out selected plans
   - Monitors progress and handles errors
   - Produces results and side effects

6. **Reflection Stage**:
   - Analyzes results and process
   - Identifies areas for improvement
   - Updates knowledge and strategies

### 3.5 Decision Making Semantics

Decision expressions in NSPL have the following semantics:

1. **Condition Evaluation**:
   - Evaluates the condition expression
   - Extracts the value and confidence
   - Compares confidence against the threshold

2. **Branch Selection**:
   - If confidence exceeds threshold, executes true branch
   - If confidence is below threshold, executes false branch
   - If uncertain branch is provided and confidence is marginal, executes uncertain branch

3. **Result Confidence**:
   - The confidence in the result depends on:
     - The confidence in the condition
     - The branch taken
     - The confidence in the branch result

### 3.6 Natural Language Integration Semantics

Natural language expressions in NSPL have the following semantics:

1. **Text Processing**:
   - Processes natural language text
   - Converts to internal representations
   - May include parsing, semantic analysis, etc.

2. **Context Integration**:
   - Integrates with surrounding code context
   - May access variables and functions
   - Respects scope and visibility rules

3. **Output Generation**:
   - Can generate natural language from program state
   - Maintains coherence and relevance
   - Supports various styles and formats

## 4. Standard Library

### 4.1 Core Module

The core module provides fundamental operations for neural-symbolic integration:

```
module core {
    // Neural-Symbolic Conversion
    function symbolize<T>(embedding: Vector, domain: Domain, confidence_threshold: Float = 0.8): UncertainValue<T>
    function neuralize<T>(value: T, embedding_space: EmbeddingSpace): Vector
    
    // Logic Gates
    logic_gate AND<T, U>(input1: T, input2: U, threshold1: Float = 0.5, threshold2: Float = 0.5): Boolean
    logic_gate OR<T, U>(input1: T, input2: U, threshold1: Float = 0.5, threshold2: Float = 0.5): Boolean
    logic_gate NOT<T>(input: T, threshold: Float = 0.5): Boolean
    logic_gate XOR<T, U>(input1: T, input2: U, threshold1: Float = 0.5, threshold2: Float = 0.5): Boolean
    
    // Uncertainty Handling
    function confidence<T>(value: UncertainValue<T>): Float
    function distribution<T>(value: UncertainValue<T>): Distribution<T>
    function require_confidence<T>(value: UncertainValue<T>, threshold: Float, fallback: () -> T): T
    
    // Verification
    function verify<T>(value: T, property: Property): VerificationResult
    function assert_property<T>(value: T, property: Property): void
}
```

### 4.2 Neural Module

The neural module provides operations for neural network components:

```
module neural {
    // Vector Operations
    function similarity(a: Vector, b: Vector): Float
    function distance(a: Vector, b: Vector): Float
    function normalize(v: Vector): Vector
    
    // Embedding Operations
    function embed(text: String, model: EmbeddingModel): Vector
    function embed_batch(texts: String[], model: EmbeddingModel): Vector[]
    
    // Neural Network Operations
    function forward(inputs: Tensor, model: NeuralModel): Tensor
    function gradient(loss: Tensor, parameters: Tensor[]): Tensor[]
    function update(parameters: Tensor[], gradients: Tensor[], learning_rate: Float): Tensor[]
}
```

### 4.3 Symbolic Module

The symbolic module provides operations for symbolic reasoning:

```
module symbolic {
    // Logical Inference
    function infer(knowledge: KnowledgeBase, query: Query): InferenceResult
    function prove(knowledge: KnowledgeBase, theorem: Formula): ProofResult
    
    // Knowledge Base Operations
    function add_fact(knowledge: KnowledgeBase, fact: Formula): KnowledgeBase
    function add_rule(knowledge: KnowledgeBase, rule: Rule): KnowledgeBase
    function retract(knowledge: KnowledgeBase, formula: Formula): KnowledgeBase
    
    // Formula Operations
    function simplify(formula: Formula): Formula
    function substitute(formula: Formula, substitution: Substitution): Formula
    function variables(formula: Formula): Set<Variable>
}
```

### 4.4 Reasoning Module

The reasoning module provides operations for complex reasoning:

```
module reasoning {
    // Planning
    function generate_plan(goal: Goal, knowledge: KnowledgeBase): Plan
    function validate_plan(plan: Plan, knowledge: KnowledgeBase): ValidationResult
    
    // Exploration
    function explore_alternatives(plan: Plan, knowledge: KnowledgeBase, max_alternatives: Int = 5): Plan[]
    function rank_alternatives(alternatives: Plan[], criteria: Criterion[]): Plan[]
    
    // Execution
    function execute_plan(plan: Plan, context: ExecutionContext): ExecutionResult
    function monitor_execution(execution: Execution): MonitoringResult
    
    // Reflection
    function evaluate(result: Any, goal: Goal): EvaluationResult
    function identify_improvements(execution: Execution, result: Any, goal: Goal): ImprovementSuggestions
}
```

### 4.5 Action Module

The action module provides operations for action execution:

```
module action {
    // Action Execution
    function execute<T, U>(action: Action<T, U>, parameters: T): ActionResult<U>
    function verify_preconditions<T>(action: Action<T, U>, parameters: T): VerificationResult
    function verify_postconditions<T, U>(action: Action<T, U>, parameters: T, result: U): VerificationResult
    
    // Safety
    function verify_intent(action: Action<T, U>, intent: Intent): VerificationResult
    function simulate_outcome<T, U>(action: Action<T, U>, parameters: T): SimulationResult<U>
    
    // Permissions
    function check_permissions(action: Action<T, U>, context: SecurityContext): PermissionResult
    function request_permission(action: Action<T, U>, reason: String): PermissionRequest
}
```

### 4.6 Natural Language Module

The natural language module provides operations for natural language integration:

```
module natural_language {
    // Text Processing
    function parse(text: String): ParseResult
    function generate(meaning: Meaning, constraints: Constraints = {}): String
    
    // Semantic Operations
    function extract_entities(text: String): Entity[]
    function extract_relations(text: String): Relation[]
    function extract_intent(text: String): Intent
    
    // Integration
    function nl_to_code(text: String, context: CodeContext): CodeFragment
    function code_to_nl(code: CodeFragment): String
}
```

## 5. Program Structure

### 5.1 Module System

NSPL programs are organized into modules:

```
module ModuleName {
    // Imports
    import ExternalModule;
    
    // Public interface
    public {
        // Exposed functions, types, and concepts
        function function_name(): ReturnType;
        type TypeName;
        concept ConceptName;
    }
    
    // Private implementation
    private {
        // Internal implementation details
    }
    
    // Neural components
    neural {
        // Neural network definitions and operations
    }
    
    // Symbolic components
    symbolic {
        // Symbolic reasoning and logic
    }
    
    // Integration between neural and symbolic
    integration {
        // Conversion and hybrid operations
    }
}
```

Modules can be nested and imported:

```
import module1;
import module2.submodule;
import module3 as alias;
```

### 5.2 Program Entry Point

A complete NSPL program has a main entry point:

```
program ProgramName {
    // Configuration
    config: ProgramConfig;
    
    // Main entry point
    main(args: String[]): void {
        // Program implementation
    }
}
```

The configuration specifies various program parameters:

```
config ProgramConfig {
    // Neural backends
    neural_backend: NeuralBackend;
    
    // Symbolic backends
    symbolic_backend: SymbolicBackend;
    
    // Resource limits
    memory_limit: Size;
    time_limit: Duration;
    
    // Logging and monitoring
    logging_level: LogLevel;
    monitoring: MonitoringConfig;
}
```

## 6. Example Programs

### 6.1 Simple Neural-Symbolic Integration

```
// A simple program demonstrating neural-symbolic integration
program SimpleIntegration {
    // Define a concept with both neural and symbolic representations
    concept Person {
        // Neural embedding
        embedding: Embedding<"person">;
        
        // Symbolic attributes
        attributes {
            name: String;
            age: Number with constraint > 0;
        }
        
        // Logical rules
        rules {
            isAdult := age >= 18;
        }
    }
    
    // Function using both neural and symbolic aspects
    function find_similar_adults(
        person: Person,
        candidates: Person[],
        similarity_threshold: Float = 0.8
    ): Person[] {
        // Use neural similarity
        let similar = neural_foreach(candidates, candidate => {
            let similarity = neural.similarity(
                person.embedding,
                candidate.embedding
            );
            return {candidate, similarity};
        });
        
        // Filter with symbolic logic
        return filter_map(
            similar,
            item => logic_gate AND(
                item.candidate.rules.isAdult,
                item.similarity >= similarity_threshold
            ),
            item => item.candidate
        );
    }
    
    // Main entry point
    main(args: String[]): void {
        // Implementation
    }
}
```

### 6.2 Multi-Stage Reasoning Example

```
// An example of multi-stage reasoning
program ReasoningExample {
    // Define a reasoning pipeline
    reasoning answer_question(question: String): Answer {
        // Input from natural language
        input: @natural_language(question);
        
        // Planning stage
        stage Planning {
            plan = @generate("Create a plan to answer the question")
                with constraint PlanFeasibility;
            
            verify plan satisfies SafetyRules;
            
            return plan;
        }
        
        // Exploration stage
        stage Exploration(plan) {
            alternatives = @explore_paths(plan, max_branches=5);
            
            ranked_paths = @rank(alternatives, criteria=[
                Relevance, Accuracy, Completeness
            ]);
            
            return ranked_paths[0];
        }
        
        // Execution stage
        stage Execution(path) {
            result = null;
            
            for step in path {
                assert step.preconditions;
                
                step_result = execute step.action;
                
                verify step.postconditions(step_result);
                
                result = step_result;
            }
            
            return result;
        }
        
        // Reflection stage
        stage Reflection(result) {
            confidence = @evaluate_confidence(result);
            
            if confidence < 0.8 {
                @identify_uncertainty_sources(result);
                result = @add_uncertainty_disclaimers(result);
            }
            
            return {
                answer: result,
                confidence: confidence,
                reasoning_path: path
            };
        }
    }
    
    // Main entry point
    main(args: String[]): void {
        let question = args[0];
        let answer = answer_question(question);
        
        console.log("Answer:", answer.answer);
        console.log("Confidence:", answer.confidence);
    }
}
```

### 6.3 Action Specification Example

```
// An example of action specification
program ActionExample {
    // Define an action for sending emails
    action SendEmail<EmailContent> {
        // Preconditions
        preconditions {
            @logic_gate(AND, [
                contents.well_formed,
                recipient.valid_email,
                not contains_sensitive_data(contents)
            ]);
        }
        
        // Action parameters
        parameters {
            recipient: String;
            subject: String;
            contents: EmailContent;
            attachments: File[]?;
        }
        
        // Execution
        execution(params) {
            // Send email implementation
            return email_service.send(params);
        }
        
        // Postconditions
        postconditions(params, result) {
            @logic_gate(AND, [
                result.success,
                result.delivery_status != "failed"
            ]);
        }
        
        // Safety checks
        safety_checks [
            // Intent verification
            verify_intent(
                user_intent,
                "send email to recipient",
                confidence_threshold=0.95
            ),
            
            // Content verification
            verify_content(
                params.contents,
                prohibited_content_types=[
                    ContentType.HARMFUL,
                    ContentType.MISLEADING
                ]
            ),
            
            // Outcome simulation
            simulate_outcome(
                "email sending",
                params,
                simulation_count=5
            )
        ]
        
        // Permissions
        permissions [
            "email:send",
            "network:access"
        ]
    }
    
    // Main entry point
    main(args: String[]): void {
        // Create email content
        let content = {
            body: "Hello, this is a test email.",
            format: "text"
        };
        
        // Execute the action
        let result = execute SendEmail({
            recipient: "recipient@example.com",
            subject: "Test Email",
            contents: content,
            attachments: null
        });
        
        // Check result
        if (result.success) {
            console.log("Email sent successfully");
        } else {
            console.log("Failed to send email:", result.error);
        }
    }
}
```

## 7. Integration with External Systems

### 7.1 Neural Backend Integration

NSPL provides integration with standard neural network backends:

```
// Integration with PyTorch
neural_backend PyTorch {
    // Import model
    function import_model(path: String): NeuralModel;
    
    // Export model
    function export_model(model: NeuralModel, path: String): void;
    
    // Create tensor
    function tensor(data: Any, dtype: DataType = DataType.FLOAT32): Tensor;
    
    // Compute forward pass
    function forward(model: NeuralModel, inputs: Tensor): Tensor;
    
    // Compute gradients
    function backward(loss: Tensor): void;
    
    // Update parameters
    function step(optimizer: Optimizer): void;
}
```

### 7.2 Symbolic Backend Integration

NSPL provides integration with standard symbolic reasoning engines:

```
// Integration with Prolog
symbolic_backend Prolog {
    // Import knowledge base
    function import_knowledge(path: String): KnowledgeBase;
    
    // Export knowledge base
    function export_knowledge(kb: KnowledgeBase, path: String): void;
    
    // Add fact
    function assert_fact(kb: KnowledgeBase, fact: String): void;
    
    // Add rule
    function assert_rule(kb: KnowledgeBase, rule: String): void;
    
    // Query
    function query(kb: KnowledgeBase, query: String): QueryResult;
    
    // Execute goal
    function execute(kb: KnowledgeBase, goal: String): ExecutionResult;
}
```

### 7.3 Large Language Model Integration

NSPL provides integration with large language models:

```
// Integration with LLM
llm_backend GPT {
    // Generate text
    function generate(prompt: String, parameters: GenerationParameters = {}): String;
    
    // Extract information
    function extract<T>(text: String, schema: Schema<T>): UncertainValue<T>;
    
    // Answer question
    function answer_question(question: String, context: String): UncertainValue<String>;
    
    // Generate code
    function generate_code(specification: String, language: String): String;
}
```

## 8. Conclusion

This specification defines the syntax and semantics of the Neural-Symbolic Programming Language (NSPL). It provides a comprehensive language design that addresses the challenges of integrating neural network capabilities with symbolic reasoning. The language includes features for dual representation, logic gates, multi-stage reasoning, action specification, uncertainty handling, and verification.

In the subsequent artifacts, we will build on this specification to develop the compiler design, training methodologies, and best practices for NSPL.

## References

1. d'Avila Garcez, A. S., Lamb, L. C., & Gabbay, D. M. (2009). Neural-symbolic cognitive reasoning. Springer Science & Business Media.

2. Besold, T. R., Garcez, A. D., Bader, S., Bowman, H., Domingos, P., Hitzler, P., ... & Zaverucha, G. (2017). Neural-symbolic learning and reasoning: A survey and interpretation. arXiv preprint arXiv:1711.03902.

3. Pierce, B. C. (2002). Types and programming languages. MIT press.

4. Harper, R. (2016). Practical foundations for programming languages. Cambridge University Press.

5. Manhaeve, R., Dumancic, S., Kimmig, A., Demeester, T., & De Raedt, L. (2018). DeepProbLog: Neural probabilistic logic programming. Advances in Neural Information Processing Systems, 31.

6. Badreddine, S., d'Avila Garcez, A., Serafini, L., & Spranger, M. (2022). Logic tensor networks. Artificial Intelligence, 303, 103649.

7. Riegel, R., Gray, A., Luus, F., Khan, N., Makondo, N., Akhalwaya, I. Y., ... & Faruque, S. (2020). Logical neural networks. arXiv preprint arXiv:2006.13155.

8. Wei, J., Wang, X., Schuurmans, D., Bosma, M., Ichter, B., Xia, F., ... & Zhou, D. (2022). Chain of thought prompting elicits reasoning in large language models. arXiv preprint arXiv:2201.11903.