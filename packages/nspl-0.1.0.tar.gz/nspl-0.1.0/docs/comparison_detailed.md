# NSPL vs LMQL vs DSPy vs LangChain

## What Each Tool Actually Does

| | NSPL | LMQL | DSPy | LangChain |
|---|---|---|---|---|
| **Core idea** | Verification layer between LLM and tools/users | Constrained query language for LLMs | Declarative LM programming with auto-optimization | Agent orchestration framework |
| **Primary job** | "Should this happen?" | "How to query the LLM?" | "How to optimize prompts?" | "How to wire components?" |
| **Runs LLM for safety?** | No (deterministic) | Yes (constraints are LLM-evaluated) | Yes (optimizer calls LLM) | Yes (agents reason about safety) |
| **Latency overhead** | 0.01-30ms | Adds to LLM call | Adds to LLM call | Adds to LLM call |

## Detailed Comparison

### LMQL
**What it is**: A query language that constrains LLM output during generation (e.g., "output must be valid JSON", "response must not contain X").

**How it works**: Embeds constraints into the decoding process. The LLM generates tokens, and LMQL masks/rejects tokens that violate constraints in real-time.

**Where NSPL differs**:
- LMQL constrains *generation*. NSPL validates *before and after* generation.
- LMQL requires modifying how you call the LLM. NSPL wraps any existing LLM call.
- LMQL's constraints are checked during token generation (tight coupling). NSPL's checks are independent of the LLM (loose coupling).
- LMQL can't check tool call parameters. NSPL's `@action` decorator verifies preconditions/postconditions on tool execution.
- LMQL has no prompt injection detection. NSPL has 5 detection layers.

**Complementary use**: LMQL constrains output format. NSPL verifies safety. Use both.

### DSPy
**What it is**: A framework for writing LLM programs as "signatures" (input -> output), then automatically optimizing the prompts/examples.

**How it works**: You define `dspy.Predict("question -> answer")`, provide training examples, and DSPy optimizes the prompt/few-shot examples to maximize accuracy.

**Where NSPL differs**:
- DSPy optimizes *accuracy*. NSPL enforces *safety*.
- DSPy has no built-in safety checks, prompt injection detection, or PII filtering.
- DSPy programs trust their inputs. NSPL guards validate inputs before they reach any module.
- DSPy's `Assertions` feature is the closest analog to NSPL's checks, but assertions are evaluated by the LLM (expensive, non-deterministic). NSPL's checks are deterministic.

**Complementary use**: `NSPLGuardModule(dspy.ChainOfThought(...))` wraps any DSPy module with input/output guards. DSPy optimizes the reasoning; NSPL ensures the I/O is safe.

### LangChain
**What it is**: An orchestration framework for building LLM applications. Agents, chains, tools, memory, retrieval.

**How it works**: You compose components (LLMs, tools, retrievers) into chains or agents that reason about which tools to use.

**Where NSPL differs**:
- LangChain orchestrates *what to do*. NSPL verifies *whether to do it*.
- LangChain's tool use has no formal preconditions/postconditions. Any tool the agent selects gets called. NSPL blocks unsafe tool calls before execution.
- LangChain has community guardrails (NeMo, Guardrails AI) but they're output validators. NSPL adds input guards + action verification.
- LangChain agents can be prompt-injected via tool outputs. NSPL's output guard catches this.

**Complementary use**: `nspl_langchain_tools([...], ctx)` wraps NSPL actions as LangChain tools. The agent orchestrates; NSPL verifies every tool invocation.

## The Key Difference

All these tools assume the LLM is *trustworthy enough* to make safety decisions. NSPL assumes it is not.

| Approach | Who decides safety? | Latency | Deterministic? |
|----------|-------------------|---------|---------------|
| Raw LLM | The LLM itself | 0ms extra | No |
| LMQL | LLM + decoder constraints | +10-50ms | Partially |
| DSPy assertions | The LLM (re-evaluates) | +500-5000ms | No |
| LangChain guardrails | The LLM or a classifier | +100-2000ms | Depends |
| Guardrails AI | Output validators | +10-100ms | Mostly |
| **NSPL** | **Deterministic logic + optional classifier** | **+0.01-30ms** | **Yes (core), mostly (classifier)** |

## When to Use What

| You need... | Use |
|-------------|-----|
| Prompt format constraints | LMQL |
| Automatic prompt optimization | DSPy |
| Agent orchestration | LangChain |
| Output schema validation | Guardrails AI / Instructor |
| **Prompt injection detection** | **NSPL** |
| **PII detection/redaction** | **NSPL** |
| **Tool call verification** | **NSPL** |
| **Audit trail** | **NSPL** |
| **Deterministic safety checks** | **NSPL** |

## Architecture: NSPL in the Stack

```
User Input
    │
    ├── NSPL InputGuard (injection, PII, content)     ← deterministic, <1ms
    │
    ├── LMQL (format constraints during generation)    ← during LLM call
    │
    ├── DSPy (optimized prompt/few-shot)               ← prompt engineering
    │
    ├── LangChain (agent decides which tool)           ← orchestration
    │
    ├── NSPL ActionGuard (preconditions, safety)       ← before tool execution
    │
    ├── Tool Execution                                  ← the actual work
    │
    ├── NSPL OutputGuard (dangerous content, leakage)  ← after LLM responds
    │
    └── Guardrails AI (schema validation)              ← output format
```

NSPL doesn't replace any of these tools. It fills gaps none of them cover.
