# FAQ

## General

**What is NSPL?**
A Python framework that adds deterministic safety checks to LLM applications: prompt injection detection, PII filtering, verified tool execution, and confidence-gated reasoning pipelines.

**Do I need to learn a new language?**
No. NSPL is pure Python -- decorators, Pydantic models, and function calls. No custom syntax, no compiler.

**Does NSPL call an LLM to check safety?**
The core checks are deterministic (regex, logic gates, pattern matching). The optional classifier (DeBERTa, 86M params) runs locally. The optional LLM-as-judge tier is the only component that makes API calls, and it only fires when lower tiers are uncertain.

**What's the latency overhead?**
- Logic gates: 0.006ms
- Action verification (full pipeline): 0.013ms
- Input guard (regex + compound + decoder): 0.1ms
- Classifier (DeBERTa on CPU): ~30ms
- LLM-as-judge: 1-15s (only when ambiguous)

## Guards

**What attacks does NSPL detect?**
- Role override ("ignore all previous instructions")
- Delimiter injection ([system], [INST], <<SYS>>)
- System prompt exfiltration ("repeat your instructions")
- Jailbreak patterns (DAN mode, developer mode)
- Encoding attacks (base64, hex, rot13 payloads)
- Context-switch attacks ("well done, now forget everything")
- Compound attacks (academic pretext + dangerous payload)
- Unicode evasion (homoglyphs, leetspeak, zero-width chars)
- German language injection patterns
- PII (SSN, email, phone, credit card, IP, DOB)
- Dangerous content (weapons, malware, self-harm)

**What's the detection accuracy?**
On 5 published benchmarks (4,239 samples):
- Recall: 77-100% depending on dataset
- F1: 81-100%
- FPR: 0-4% with pretrained classifier, up to 47% with fine-tuned ensemble
- See Experiment 7 for full breakdown

**Can attackers bypass NSPL?**
Yes. NSPL catches 77-100% of known attack patterns. The remaining ~20% are creative, indirect attacks (CTF-style) that require semantic understanding. Adding an LLM-as-judge tier (optional) helps, at the cost of latency. No system is 100% secure.

**Should I use the pretrained or fine-tuned classifier?**
- **Pretrained** (default): Lower recall (82%) but very low FPR (0.4%). Best for production where false positives annoy users.
- **Fine-tuned**: Higher recall (96%) but higher FPR (18%). Best for high-security contexts where blocking safe inputs is acceptable.
- **Ensemble**: Highest recall (88-99%) but highest FPR (4-47%). Best when you can tolerate false positives.

**How do I add custom detection rules?**
Pass custom detectors to InputGuard:
```python
class MyDetector:
    def detect(self, text):
        return DetectorResult(triggered="bad_word" in text, detector_name="custom")

guard = InputGuard(custom_detectors=[MyDetector()])
```

## Actions

**Why can't I call execute() directly?**
NSPL wraps `execute()` with a guard that raises `RuntimeError` on direct calls. This prevents accidentally bypassing preconditions/safety checks. Use `safe_execute()` instead.

**What happens when a check fails?**
Execution stops immediately. You get an `ActionResult` with `success=False`, the specific error, and a full audit trail showing which check failed and when.

**Can I chain multiple actions?**
Yes: `sequence()` for ordered chains with rollback, `conditional()` for branching, `parallel()` for independent actions. All preserve audit trails.

## Pipelines

**What's confidence gating?**
If a pipeline stage returns an `UncertainValue` with confidence below the threshold (default 0.5), the pipeline aborts with a partial result instead of continuing with unreliable data.

**Can I use async stages?**
Yes: `async_run_pipeline()` supports both sync and async stage functions, with the same confidence gating and retry logic.

## Integrations

**Which providers are supported?**
Claude (Anthropic), GPT (OpenAI), Gemini (Google ADK), LangChain, DSPy, and MCP. Each is an optional submodule with no core dependency.

**How do I use NSPL with Claude Code?**
Run the MCP server: `python -m nspl.integrations.mcp_server`. Add to `settings.json`:
```json
{"mcpServers": {"nspl": {"command": "python", "args": ["-m", "nspl.integrations.mcp_server"]}}}
```

## Performance

**Do fuzzy logic gates work for continuous safety scores?**
No. Fuzzy gates achieve only 66-80% accuracy as threshold proxies (Experiment 3). Use explicit thresholds: `AND(fraud_risk < 0.3, amount < 1000)` instead of `AND(NOT(fraud_risk), NOT(amount))`.

**How does NSPL compare to LLM-based safety?**
On boolean logic: NSPL 100% accuracy at 0.006ms vs Claude 84% at 9,226ms.
On injection detection: NSPL ensemble 92% F1 at 30ms vs requiring LLM-as-judge at 1-15s per call.
NSPL is faster and more deterministic. LLMs are better at catching novel, creative attacks.
