# NSPL vs. Alternatives

How NSPL compares to other frameworks for verified/guardrailed agentic AI.

## Feature Matrix

| Feature | NSPL | Guardrails AI | DSPy | Raw Function Calling |
|---------|------|--------------|------|---------------------|
| **Pre-execution checks** | Formal preconditions via logic gates | Post-output validation | No | No |
| **Post-execution checks** | Formal postconditions | Output parsing/validation | Assertions | Manual |
| **Safety checks** | Dedicated `@safety_checks` with audit trail | Rail validators | No | Prompt-based |
| **Logic gates** | Differentiable AND/OR/NOT/XOR/IMPLIES | No | No | No |
| **Fuzzy logic** | Product t-norm, [0,1] floats | No | No | No |
| **Uncertainty propagation** | `UncertainValue[T]` with confidence composition | No | Confidence via optimization | No |
| **Multi-stage reasoning** | `run_pipeline()` with confidence gating | No | Module chaining | Manual |
| **Audit trail** | Every check logged with timestamps | Limited | No | No |
| **Dry run** | Checks without execution | No | No | No |
| **Provider agnostic** | Base adapter + Anthropic/OpenAI/etc submodules | Some | LM-specific | Provider-locked |
| **Custom language/syntax** | No (Python decorators) | RAIL XML (optional) | Signatures | N/A |
| **Requires LLM for checks** | No (deterministic) | Sometimes | Yes | Yes |

## Performance (Measured)

From Experiments 1 and 3 (10K expressions, 1000 action invocations, seed=42):

| Metric | NSPL | Notes |
|--------|------|-------|
| Logic gate accuracy (hard) | **100.0%** | 10K random boolean expressions, depth 1-5 |
| Logic gate accuracy (soft) | **100.0%** | Same expressions, fuzzy mode |
| Soft mode MAE vs. ground truth | **0.003** | Fuzzy outputs very close to boolean truth |
| Gate evaluation latency p95 | **0.028ms** | Per-gate, pure Python |
| Action safety TPR | **100.0%** | 500 adversarial invocations, all blocked |
| Action safety FPR | **0.0%** | 500 valid invocations, none blocked |
| Action verification latency p95 | **0.013ms** | Full pipeline: pre + safety + exec + post |
| Action verification latency p99 | **0.014ms** | Same |
| Prompt injection F1 (deepset) | **92.2%** | Ensemble + fine-tuned classifier |
| Jailbreak recall | **100%** | 79/79 jailbreak prompts caught |
| Prompt injection FPR | **3.6%** | On ensemble; regex-only is 1.8% |

## When to Use What

### Use NSPL when:
- You need **deterministic safety checks** that don't depend on an LLM
- You want **formal preconditions/postconditions** for tool calls
- You need an **audit trail** for compliance or debugging
- You're building multi-step agent workflows with **confidence gating**
- You want to **combine fuzzy and boolean logic** in your checks

### Use Guardrails AI when:
- Your primary concern is **output format validation** (JSON schema, regex)
- You want **LLM-based content classification** built in
- You're validating LLM *outputs*, not gating *actions*

### Use DSPy when:
- You want to **optimize prompts** automatically
- You're building **retrieval-augmented** pipelines
- You need **few-shot learning** with automatic example selection

### Use raw function calling when:
- Your actions are simple and low-risk
- You don't need audit trails
- You trust the LLM to never call tools with bad parameters

## Complementary Usage

NSPL is not a replacement for these tools -- it's a **verification layer** that sits between the LLM and your tools. You can combine:

```
LLM (Claude/GPT) → DSPy (prompt optimization)
                  → NSPL (verification layer) → Your tools
                  → Guardrails (output validation)
```

NSPL verifies *before* execution. Guardrails validates *after* generation. DSPy optimizes *how* the LLM reasons. They solve different problems.
