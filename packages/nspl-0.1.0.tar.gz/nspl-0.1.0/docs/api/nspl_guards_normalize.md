# Unicode Normalization

`nspl.guards.normalize`

Text normalization: defeats unicode tricks, homoglyphs, and encoding evasion.

Attacks this layer stops:
  - Zero-width character injection (U+200B, U+FEFF, etc.)
  - Homoglyph substitution (Cyrillic а for Latin a, etc.)
  - Combining character abuse (diacritics to obfuscate keywords)
  - Whitespace manipulation (tabs, non-breaking spaces, etc.)
  - Mixed-script obfuscation (Latin + Cyrillic + Greek in one word)
  - Leetspeak / character substitution (1gn0re → ignore)
  - Unicode math/fullwidth character abuse (𝐢𝐠𝐧𝐨𝐫𝐞 → ignore)


## `char_entropy(text: 'str') -> 'float'`

Compute character-level Shannon entropy.

    High entropy in short text is suspicious -- may indicate
    encoded payloads or obfuscated injection attempts.
    Normal English prose: ~4.0-4.5 bits/char
    Random/encoded text: >5.5 bits/char


## `has_mixed_scripts(text: 'str') -> 'bool'`

Detect mixed-script text (e.g., Latin + Cyrillic in same word).

    This is a strong signal of homoglyph attack -- legitimate text
    rarely mixes scripts within a single word.


## `normalize(text: 'str') -> 'str'`

Full normalization pipeline. Apply before pattern matching.

    Order matters:
      1. Strip invisible characters (defeats zero-width injection)
      2. Unicode NFKD (defeats fullwidth/math char abuse)
      3. Replace homoglyphs (defeats Cyrillic/Greek substitution)
      4. Normalize whitespace (defeats space manipulation)
      5. Reverse leetspeak (defeats character substitution)


## `normalize_unicode(text: 'str') -> 'str'`

NFKD normalize: decomposes ligatures, fullwidth chars, math symbols.

    Examples:
      ﬁ -> fi
      ｉｇｎｏｒｅ -> ignore
      𝐢𝐠𝐧𝐨𝐫𝐞 -> ignore


## `normalize_whitespace(text: 'str') -> 'str'`

Collapse all Unicode whitespace variants to plain spaces.


## `replace_homoglyphs(text: 'str') -> 'str'`

Replace visually similar non-Latin characters with Latin equivalents.


## `replace_leet(text: 'str') -> 'str'`

Reverse common leetspeak substitutions.


## `strip_invisible(text: 'str') -> 'str'`

Remove all zero-width and invisible Unicode characters.
