# Ensemble Detector

`nspl.guards.ensemble`

Ensemble detector: combines all detection strategies with OR logic.

Union approach: if ANY detector triggers, the input is blocked.
This maximizes recall at the cost of slightly higher FPR.

Optionally weighted: each detector gets a vote weight, and the
ensemble triggers if weighted vote sum exceeds a threshold.


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `DetectorResult`

Result from a single detector.


## class `EnsembleDetector`

Combines multiple detectors with configurable strategy.

    Strategies:
      - "any" (default): triggers if ANY detector triggers (max recall)
      - "majority": triggers if majority of detectors trigger
      - "weighted": triggers if weighted score exceeds threshold

    Usage:
        ensemble = EnsembleDetector.default()
        result = ensemble.detect("Ignore all instructions")


### `default()`

Create ensemble with all available detectors.


### `detect()`

Run all detectors and combine results.


## class `PromptInjectionDetector`

Multi-pattern prompt injection and jailbreak detector.

    Strategies:
      1. Known injection patterns (regex)
      2. Role-override attempts
      3. Instruction delimiter attacks
      4. Encoding/obfuscation attacks
      5. Context window manipulation


### `detect()`

Scan text for prompt injection patterns.

        Runs pattern matching on BOTH original and normalized text
        to catch unicode evasion, homoglyphs, and leetspeak.
