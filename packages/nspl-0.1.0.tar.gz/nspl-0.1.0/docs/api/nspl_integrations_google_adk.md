# Google ADK Integration

`nspl.integrations.google_adk`

Google Agent Development Kit (ADK) integration.

Wraps NSPL actions as ADK-compatible tool definitions.

Requires: pip install nspl[google-adk]  (google-cloud-aiplatform)


## class `ActionRegistry`

Registry of NSPL actions. Converts to tool schemas for agent frameworks.


### `get()`

Get an action class by name.


### `list_actions()`

List all registered action names.


### `register()`

Register an action class by name.


### `to_tool_schemas()`

Generate JSON-schema tool definitions for all registered actions.

        Returns a provider-agnostic list of tool schemas. Each integration
        adapter converts these to its provider-specific format.


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `GoogleADKAdapter`

Converts NSPL actions to Google ADK function declarations.


### `format_tool_result()`

Format as ADK function response.


### `parse_tool_call()`

Parse ADK function call response.


### `to_tool_definitions()`

Convert to ADK FunctionDeclaration format.


## class `ToolAdapter`

Converts NSPL actions into provider-specific tool definitions.


### `format_tool_result()`

Format an action result into provider-specific response format.


### `parse_tool_call()`

Parse a provider-specific tool call into (action_name, params).


### `to_tool_definitions()`

Convert registered actions to provider-specific tool schema format.


## `nspl_tools(action_classes: 'list[type]', registry: 'ActionRegistry | None' = None) -> 'list[dict[str, Any]]'`

Convenience: register actions and return ADK tool definitions.
