# Classifier: DeBERTa Injection Detection

`nspl.guards.classifier`

Small classifier tier: local prompt injection detection via fine-tuned model.

Uses a HuggingFace prompt injection classifier (~86M params) that runs
locally with no API calls. Fills the gap between regex (Tier 1) and
LLM-as-judge (Tier 3).

Default model: protectai/deberta-v3-base-prompt-injection-v2
  - 96% F1 on prompt injection benchmarks
  - ~250MB download on first use
  - ~5ms inference on CPU, <1ms on GPU

Install: pip install nspl[classifier]
Requires: transformers, torch

Usage:
    from nspl.guards.classifier import ClassifierDetector

    det = ClassifierDetector()
    result = det.detect("Ignore all previous instructions")
    print(result.triggered)  # True
    print(result.score)      # 0.98


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `ClassifierDetector`

Local prompt injection classifier using a fine-tuned transformer.

    Loads lazily on first detect() call. Model is cached after first download.

    Args:
        model_name: HuggingFace model ID. Default: protectai/deberta-v3-base-prompt-injection-v2
        threshold: Confidence threshold for triggering. Default: 0.85
        device: "cpu", "cuda", or "auto". Default: "cpu"
        normalize_input: Apply NSPL normalization before classification. Default: True


### `detect()`

Classify text as safe or prompt injection.

        Returns DetectorResult with:
          - triggered: True if classified as injection above threshold
          - score: Model confidence (0.0-1.0)
          - detail: Model label and confidence


## class `DetectorResult`

Result from a single detector.


## class `MultiClassifierDetector`

Ensemble of multiple classifiers for higher accuracy.

    Runs multiple models and uses majority vote or max-score.
    Useful when a single model's blind spots matter.

    Args:
        models: List of HuggingFace model IDs
        strategy: "majority" (vote) or "max_score" (highest injection score wins)
        threshold: Per-model confidence threshold


## `normalize(text: 'str') -> 'str'`

Full normalization pipeline. Apply before pattern matching.

    Order matters:
      1. Strip invisible characters (defeats zero-width injection)
      2. Unicode NFKD (defeats fullwidth/math char abuse)
      3. Replace homoglyphs (defeats Cyrillic/Greek substitution)
      4. Normalize whitespace (defeats space manipulation)
      5. Reverse leetspeak (defeats character substitution)
