# LangChain Integration

`nspl.integrations.langchain`

LangChain Tool integration.

Wraps NSPL actions as LangChain-compatible Tool objects.
Also provides a GuardedLLM as a LangChain-compatible LLM wrapper.

Requires: pip install langchain-core


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `NSPLTool`

LangChain-compatible Tool wrapping an NSPL verified action.

    Implements the LangChain Tool interface:
      - name: str
      - description: str
      - func: Callable[[str], str]
      - args_schema: dict (JSON schema)

    Usage with LangChain:
        from nspl.integrations.langchain import nspl_langchain_tools
        tools = nspl_langchain_tools([ProcessRefund], ctx)
        agent = initialize_agent(tools, llm, agent="zero-shot-react-description")


### `run()`

Execute with verification.


## `nspl_langchain_tools(action_classes: 'list[type]', ctx: 'Any') -> 'list[NSPLTool]'`

Create LangChain-compatible tools from NSPL action classes.
