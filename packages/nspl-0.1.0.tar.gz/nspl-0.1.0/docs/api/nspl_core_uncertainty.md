# Uncertainty & Distributions

`nspl.core.uncertainty`

Uncertainty propagation: distributions and Monte Carlo propagation.


## class `ABC`

Helper class that provides a standard way to create an ABC using
    inheritance.


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `Callable`


## class `Categorical`

Categorical distribution over labeled categories.


## class `Distribution`

Abstract probability distribution.


### `mean()`

Expected value.


### `sample()`

Draw n samples.


### `std()`

Standard deviation.


## class `Empirical`

Non-parametric distribution from observed samples.


## class `Normal`

Gaussian distribution.


## class `Uniform`

Uniform distribution over [low, high].


## `abstractmethod(funcobj)`

A decorator indicating abstract methods.

    Requires that the metaclass is ABCMeta or derived from it.  A
    class that has a metaclass derived from ABCMeta cannot be
    instantiated unless all of its abstract methods are overridden.
    The abstract methods can be called using any of the normal
    'super' call mechanisms.  abstractmethod() may be used to declare
    abstract methods for properties and descriptors.

    Usage:

        class C(metaclass=ABCMeta):
            @abstractmethod
            def my_abstract_method(self, ...):
                ...


## `propagate(fn: 'Callable[..., Any]', dist: 'Distribution', n_samples: 'int' = 1000, seed: 'int' = 42) -> 'Empirical'`

Propagate uncertainty through a function via Monte Carlo.

    Draws n_samples from dist, applies fn to each, returns Empirical distribution.
