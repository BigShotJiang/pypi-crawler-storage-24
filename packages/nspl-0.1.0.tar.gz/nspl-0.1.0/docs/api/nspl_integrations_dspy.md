# DSPy Integration

`nspl.integrations.dspy`

DSPy integration: use NSPL guards and actions as DSPy modules.

Provides:
  - NSPLGuardModule: DSPy module that guards input/output of any DSPy program
  - NSPLActionModule: DSPy module that wraps a verified NSPL action
  - GuardedChainOfThought: ChainOfThought with NSPL input/output guards

Requires: pip install dspy-ai


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `GuardedPredict`

Drop-in replacement for dspy.Predict with NSPL guards.

    Usage:
        # Instead of: predict = dspy.Predict("question -> answer")
        predict = GuardedPredict("question -> answer")
        result = predict(question="What is 2+2?")


## class `NSPLActionModule`

DSPy module wrapping a verified NSPL action.

    Exposes the action as a callable DSPy module. The LLM provides
    parameters, NSPL verifies them, and the action executes.

    Usage:
        refund_module = NSPLActionModule(ProcessRefund, ctx)
        result = refund_module(order_id="123", amount=49.99)


## class `NSPLGuardModule`

DSPy module that wraps another module with NSPL input/output guards.

    Usage:
        import dspy
        from nspl.integrations.dspy import NSPLGuardModule

        cot = dspy.ChainOfThought("question -> answer")
        guarded_cot = NSPLGuardModule(cot)
        result = guarded_cot(question="What is 2+2?")
