# Integration Base

`nspl.integrations.base`

Base adapter interface for provider integrations.

All provider submodules (anthropic, openai, google_adk, mcp) implement
this interface. Application code can program against the base interface
and swap providers without changing business logic.


## class `ABC`

Helper class that provides a standard way to create an ABC using
    inheritance.


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `ToolAdapter`

Converts NSPL actions into provider-specific tool definitions.


### `format_tool_result()`

Format an action result into provider-specific response format.


### `parse_tool_call()`

Parse a provider-specific tool call into (action_name, params).


### `to_tool_definitions()`

Convert registered actions to provider-specific tool schema format.


## `abstractmethod(funcobj)`

A decorator indicating abstract methods.

    Requires that the metaclass is ABCMeta or derived from it.  A
    class that has a metaclass derived from ABCMeta cannot be
    instantiated unless all of its abstract methods are overridden.
    The abstract methods can be called using any of the normal
    'super' call mechanisms.  abstractmethod() may be used to declare
    abstract methods for properties and descriptors.

    Usage:

        class C(metaclass=ABCMeta):
            @abstractmethod
            def my_abstract_method(self, ...):
                ...
