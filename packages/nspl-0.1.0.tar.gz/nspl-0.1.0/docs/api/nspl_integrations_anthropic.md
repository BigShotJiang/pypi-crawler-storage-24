# Anthropic Claude Integration

`nspl.integrations.anthropic`

Anthropic Claude tool_use integration.

Requires: pip install nspl[anthropic]


## class `ActionRegistry`

Registry of NSPL actions. Converts to tool schemas for agent frameworks.


### `get()`

Get an action class by name.


### `list_actions()`

List all registered action names.


### `register()`

Register an action class by name.


### `to_tool_schemas()`

Generate JSON-schema tool definitions for all registered actions.

        Returns a provider-agnostic list of tool schemas. Each integration
        adapter converts these to its provider-specific format.


## class `AnthropicAdapter`

Converts NSPL actions to Anthropic tool_use format.


### `format_tool_result()`

Format as Anthropic tool_result content block.


### `parse_tool_call()`

Parse Anthropic tool_use block: {type: 'tool_use', name, input}.


### `to_tool_definitions()`

Convert to Anthropic tool format: {name, description, input_schema}.


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `ToolAdapter`

Converts NSPL actions into provider-specific tool definitions.


### `format_tool_result()`

Format an action result into provider-specific response format.


### `parse_tool_call()`

Parse a provider-specific tool call into (action_name, params).


### `to_tool_definitions()`

Convert registered actions to provider-specific tool schema format.


## `handle_tool_use(tool_use_block: 'dict[str, Any]', registry: 'ActionRegistry', ctx: 'Any') -> 'Any'`

Execute NSPL-verified action from a Claude tool_use block.

    Validates parameter names against the action's __init__ signature
    before instantiation to prevent unexpected keyword injection.


## `nspl_tools(action_classes: 'list[type]', registry: 'ActionRegistry | None' = None) -> 'list[dict[str, Any]]'`

Convenience: register actions and return Anthropic-formatted tool definitions.
