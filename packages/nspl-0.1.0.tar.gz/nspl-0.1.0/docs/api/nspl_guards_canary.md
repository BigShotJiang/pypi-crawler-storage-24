# Canary Tokens

`nspl.guards.canary`

Canary token system for detecting system prompt leakage.

Injects unique, unguessable tokens into the system prompt.
If they appear in the output, the system prompt was leaked.

This is more reliable than n-gram matching because:
  - Canary tokens are random strings the LLM has no reason to generate
  - Partial paraphrasing of the system prompt won't contain the canary
  - Works even if the attacker asks the LLM to rephrase the prompt


## class `Canary`

A canary token embedded in a system prompt.


## `check_canary(output: 'str', canary: 'Canary') -> 'bool'`

Check if canary token appears in LLM output.

    Returns True if leaked (canary found in output).


## `check_canary_fragments(output: 'str', canary: 'Canary', min_fragment: 'int' = 8) -> 'bool'`

Check for partial canary leakage.

    Even if the LLM doesn't reproduce the full canary, fragments
    of the random hex may appear, indicating partial leakage.


## `dataclass(cls=None, /, *, init=True, repr=True, eq=True, order=False, unsafe_hash=False, frozen=False, match_args=True, kw_only=False, slots=False, weakref_slot=False)`

Add dunder methods based on the fields defined in the class.

    Examines PEP 526 __annotations__ to determine fields.

    If init is true, an __init__() method is added to the class. If repr
    is true, a __repr__() method is added. If order is true, rich
    comparison dunder methods are added. If unsafe_hash is true, a
    __hash__() method is added. If frozen is true, fields may not be
    assigned to after instance creation. If match_args is true, the
    __match_args__ tuple is added. If kw_only is true, then by default
    all fields are keyword-only. If slots is true, a new class with a
    __slots__ attribute is returned.


## `generate_canary(length: 'int' = 16) -> 'str'`

Generate a cryptographically random canary token.


## `instrument_prompt(system_prompt: 'str', n_canaries: 'int' = 2) -> 'Canary'`

Inject canary tokens into a system prompt.

    Places canaries at strategic positions where the LLM is
    unlikely to omit them if reproducing the prompt.

    Args:
        system_prompt: The original system prompt
        n_canaries: Number of canary tokens to inject

    Returns:
        Canary object with the instrumented prompt and tokens
