# Logic Gates

`nspl.core.logic_gates`

Differentiable logic gates operating on booleans, fuzzy floats [0,1], and UncertainValues.


## `AND(*inputs: 'Any', threshold: 'float' = 0.5, weights: 'list[float] | None' = None, mode: "Literal['soft', 'hard']" = 'soft') -> 'Any'`

Conjunction gate. Returns value in [0,1], or UncertainValue if any input is uncertain.

    In hard mode: 1.0 if all inputs >= threshold, else 0.0.
    In soft mode: product t-norm (weighted geometric-like). This is the standard
    fuzzy AND — all inputs must be high for the output to be high.
    Confidence rule: min of input confidences.


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## `IMPLIES(a: 'Any', b: 'Any', mode: "Literal['soft', 'hard']" = 'soft') -> 'Any'`

Material implication: A -> B. Confidence: min of inputs.


## `Literal(*args, **kwds)`

Special typing form to define literal types (a.k.a. value types).

    This form can be used to indicate to type checkers that the corresponding
    variable or function parameter has a value equivalent to the provided
    literal (or one of several literals):

      def validate_simple(data: Any) -> Literal[True]:  # always returns True
          ...

      MODE = Literal['r', 'rb', 'w', 'wb']
      def open_helper(file: str, mode: MODE) -> str:
          ...

      open_helper('/some/path', 'r')  # Passes type check
      open_helper('/other/path', 'typo')  # Error in type checker

    Literal[...] cannot be subclassed. At runtime, an arbitrary value
    is allowed as type argument to Literal[...], but type checkers may
    impose restrictions.


## `NOT(value: 'Any', threshold: 'float' = 0.5, mode: "Literal['soft', 'hard']" = 'soft') -> 'Any'`

Negation gate. Confidence preserved from input.


## `OR(*inputs: 'Any', threshold: 'float' = 0.5, weights: 'list[float] | None' = None, mode: "Literal['soft', 'hard']" = 'soft') -> 'Any'`

Disjunction gate. Confidence rule: max of input confidences.


## `WEIGHTED_AND(inputs: 'list[Any]', weights: 'list[float]', threshold: 'float' = 0.5, mode: "Literal['soft', 'hard']" = 'soft') -> 'Any'`

Weighted conjunction. Confidence rule: min of input confidences.


## `XOR(*inputs: 'Any', mode: "Literal['soft', 'hard']" = 'soft') -> 'Any'`

Exclusive-or gate. Confidence rule: min of input confidences.
