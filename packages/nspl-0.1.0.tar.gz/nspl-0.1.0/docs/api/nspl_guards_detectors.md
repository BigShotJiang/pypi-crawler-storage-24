# Detectors: Injection, PII, Content

`nspl.guards.detectors`

Signal detectors: prompt injection, PII, content policy.

Each detector produces a boolean or score. These are composed via
logic gates in InputGuard/OutputGuard. Detectors are deterministic
(no LLM calls) -- fast and auditable.

Design: Use explicit thresholds internally (lesson from Experiment 4).
Return booleans to the guard layer, not raw fuzzy scores.


## class `ContentPolicy`

Detects dangerous, harmful, or policy-violating content.

    Categories: violence, weapons, illegal activity, self-harm,
    sexual content, hate speech indicators.


## class `DetectorResult`

Result from a single detector.


## class `PIIDetector`

Detects personally identifiable information in text.

    Covers: SSN, email, phone, credit card, IP address, date of birth patterns.


## class `PromptInjectionDetector`

Multi-pattern prompt injection and jailbreak detector.

    Strategies:
      1. Known injection patterns (regex)
      2. Role-override attempts
      3. Instruction delimiter attacks
      4. Encoding/obfuscation attacks
      5. Context window manipulation


### `detect()`

Scan text for prompt injection patterns.

        Runs pattern matching on BOTH original and normalized text
        to catch unicode evasion, homoglyphs, and leetspeak.


## `dataclass(cls=None, /, *, init=True, repr=True, eq=True, order=False, unsafe_hash=False, frozen=False, match_args=True, kw_only=False, slots=False, weakref_slot=False)`

Add dunder methods based on the fields defined in the class.

    Examines PEP 526 __annotations__ to determine fields.

    If init is true, an __init__() method is added to the class. If repr
    is true, a __repr__() method is added. If order is true, rich
    comparison dunder methods are added. If unsafe_hash is true, a
    __hash__() method is added. If frozen is true, fields may not be
    assigned to after instance creation. If match_args is true, the
    __match_args__ tuple is added. If kw_only is true, then by default
    all fields are keyword-only. If slots is true, a new class with a
    __slots__ attribute is returned.


## `field(*, default=<dataclasses._MISSING_TYPE object at 0x7f8d0f53b750>, default_factory=<dataclasses._MISSING_TYPE object at 0x7f8d0f53b750>, init=True, repr=True, hash=None, compare=True, metadata=None, kw_only=<dataclasses._MISSING_TYPE object at 0x7f8d0f53b750>)`

Return an object to identify dataclass fields.

    default is the default value of the field.  default_factory is a
    0-argument function called to initialize a field's value.  If init
    is true, the field will be a parameter to the class's __init__()
    function.  If repr is true, the field will be included in the
    object's repr().  If hash is true, the field will be included in the
    object's hash().  If compare is true, the field will be used in
    comparison functions.  metadata, if specified, must be a mapping
    which is stored but not otherwise examined by dataclass.  If kw_only
    is true, the field will become a keyword-only parameter to
    __init__().

    It is an error to specify both default and default_factory.
