# OpenAI Integration

`nspl.integrations.openai`

OpenAI function calling integration.

Requires: pip install nspl[openai]


## class `ActionRegistry`

Registry of NSPL actions. Converts to tool schemas for agent frameworks.


### `get()`

Get an action class by name.


### `list_actions()`

List all registered action names.


### `register()`

Register an action class by name.


### `to_tool_schemas()`

Generate JSON-schema tool definitions for all registered actions.

        Returns a provider-agnostic list of tool schemas. Each integration
        adapter converts these to its provider-specific format.


## class `Any`

Special type indicating an unconstrained type.

    - Any is compatible with every type.
    - Any assumed to have all methods.
    - All values assumed to be instances of Any.

    Note that all the above statements are true from the point of view of
    static type checkers. At runtime, Any should not be used with instance
    checks.


## class `OpenAIAdapter`

Converts NSPL actions to OpenAI function calling format.


### `format_tool_result()`

Format as OpenAI tool message content.


### `parse_tool_call()`

Parse OpenAI tool_call: {function: {name, arguments}}.


### `to_tool_definitions()`

Convert to OpenAI tools format: {type: 'function', function: {...}}.


## class `ToolAdapter`

Converts NSPL actions into provider-specific tool definitions.


### `format_tool_result()`

Format an action result into provider-specific response format.


### `parse_tool_call()`

Parse a provider-specific tool call into (action_name, params).


### `to_tool_definitions()`

Convert registered actions to provider-specific tool schema format.


## `nspl_tools(action_classes: 'list[type]', registry: 'ActionRegistry | None' = None) -> 'list[dict[str, Any]]'`

Convenience: register actions and return OpenAI-formatted tool definitions.
