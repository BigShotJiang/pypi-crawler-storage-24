# NSPL Tutorial Notebooks

15 self-contained lessons covering every NSPL feature. Each notebook runs in Google Colab with one click -- no local setup needed.

## Curriculum

### Foundations (Lessons 1-4)

| # | Lesson | Colab | Topics |
|---|--------|-------|--------|
| 01 | [Logic Gates](01_logic_gates.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/01_logic_gates.ipynb) | AND, OR, NOT, XOR, IMPLIES, WEIGHTED_AND, hard/soft modes |
| 02 | [Uncertainty Propagation](02_uncertain_values.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/02_uncertain_values.ipynb) | UncertainValue, map, flat_map, require, Monte Carlo |
| 03 | [Verified Tool Execution](03_action_verification.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/03_action_verification.ipynb) | @action, preconditions, safety checks, audit trail, dry run |
| 04 | [Action Chains](04_action_composition.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/04_action_composition.ipynb) | sequence, conditional, parallel, rollback |

### Guards (Lessons 5-10)

| # | Lesson | Colab | Topics |
|---|--------|-------|--------|
| 05 | [Prompt Injection Detection](05_input_guard.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/05_input_guard.ipynb) | InputGuard, regex patterns, 7 attack categories |
| 06 | [Output Filtering](06_output_guard.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/06_output_guard.ipynb) | OutputGuard, PII redaction, leakage, echo detection |
| 07 | [GuardedLLM Pipeline](07_guarded_llm.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/07_guarded_llm.ipynb) | Full input→LLM→output pipeline, GuardConfig |
| 08 | [PII Detection](08_pii_detection.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/08_pii_detection.ipynb) | SSN, email, phone, credit card, IP, DOB detection + redaction |
| 09 | [Reasoning Pipelines](09_reasoning_pipelines.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/09_reasoning_pipelines.ipynb) | run_pipeline, confidence gating, retry, traces |
| 10 | [Unicode Defense](10_unicode_defense.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/10_unicode_defense.ipynb) | Homoglyphs, leetspeak, zero-width chars, normalization |

### Advanced (Lessons 11-15)

| # | Lesson | Colab | Topics |
|---|--------|-------|--------|
| 11 | [Compound Attacks](11_compound_patterns.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/11_compound_patterns.ipynb) | Pretext+payload detection, social engineering |
| 12 | [Canary Tokens](12_canary_tokens.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/12_canary_tokens.ipynb) | System prompt leakage detection via canaries |
| 13 | [Ensemble Detection](13_ensemble_detection.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/13_ensemble_detection.ipynb) | Combining detectors: any, majority, weighted strategies |
| 14 | [Classifier](14_classifier_detector.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/14_classifier_detector.ipynb) | DeBERTa fine-tuned model, threshold tuning |
| 15 | [Provider Integrations](15_provider_integrations.ipynb) | [![Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/astoreyai/nspl/blob/main/docs/notebooks/15_provider_integrations.ipynb) | Claude, OpenAI, Google ADK, LangChain, DSPy, MCP |

## Requirements

- **Lessons 1-13, 15**: `pip install nspl` (no API keys, no downloads)
- **Lesson 14**: `pip install nspl[classifier]` (downloads ~250MB DeBERTa model)
- **All lessons run in Google Colab** with zero local setup
