# NSPL (Non-Stochastic Protection Layer) Roadmap

**Goal**: Ship `nspl` as a Python framework (pip-installable) that gives agentic AI systems formal verification guarantees -- logic-gated actions, structured reasoning pipelines, and uncertainty-aware decision making.

**Not a PhD thesis.** A tool people can use.

---

## Architecture Decision: Python Framework

The custom-language path (new syntax, parser, compiler) is a multi-year dead end for a solo developer. NSPL ships as a **Python package** using decorators, dataclasses, and Pydantic -- the approach already validated in `nspl.possible.md`.

```
nspl/                          # pip install nspl
  core/
    types.py                   # Hybrid type system (UncertainValue, Concept, etc.)
    logic_gates.py             # Differentiable logic gates (AND, OR, NOT, WEIGHTED_AND)
    uncertainty.py             # Uncertainty propagation engine
  actions/
    action.py                  # @action decorator, pre/postconditions, safety checks
    registry.py                # Action registry for agent frameworks
    verification.py            # Runtime verification engine
  reasoning/
    pipeline.py                # @reasoning decorator, multi-stage pipelines
    stages.py                  # Planning, Exploration, Execution, Reflection
  integrations/
    openai.py                  # OpenAI function calling wrapper
    anthropic.py               # Claude tool_use wrapper
    google_adk.py              # Google ADK integration
    mcp.py                     # MCP server/client bridge
  testing/
    property_tests.py          # Property-based testing for logic gates
    verification_tests.py      # Verification test harness
```

---

## Phase 0: Project Bootstrap (Week 1-2)

### Deliverables
- [ ] `pyproject.toml` with uv/hatch, Python 3.11+
- [ ] CI/CD (GitHub Actions: lint, test, type-check)
- [ ] Basic README with "what is this" and install instructions
- [ ] Empty package structure with `__init__.py` stubs
- [ ] Move existing 8 design docs to `docs/design/`

### Dependencies
None. Starting clean.

---

## Phase 1: Core Engine (Week 3-8)

The foundation everything else builds on.

### 1A. Logic Gates (Week 3-4)

**Deliverable**: `nspl.core.logic_gates`

Differentiable logic gates that operate on floats [0,1], booleans, and `UncertainValue` objects. Must support gradient flow for training gate parameters.

| Gate | Inputs | Behavior |
|------|--------|----------|
| `AND(*inputs, thresholds, weights)` | N inputs | Weighted conjunction |
| `OR(*inputs, thresholds, weights)` | N inputs | Weighted disjunction |
| `NOT(input, threshold)` | 1 input | Negation |
| `XOR(*inputs)` | N inputs | Exclusive or |
| `IMPLIES(a, b)` | 2 inputs | Material implication |
| `WEIGHTED_AND(*inputs, weights)` | N inputs + weights | Soft conjunction |

**Implementation**: Use `torch.nn.Module` so gates are trainable. Smooth approximations (sigmoid-based) for differentiability. Fall back to pure Python when torch unavailable.

**Experiment 1**: _Logic gate accuracy_
- Generate 10K random boolean expressions (depth 1-5)
- Compare: raw Python eval vs. NSPL gates vs. LLM-as-judge (GPT-4o, Claude Sonnet)
- Metric: accuracy, calibration of confidence scores
- **Hypothesis**: NSPL gates match Python exactness while providing confidence scores LLMs cannot

**Test**: Property-based tests (commutativity, associativity, De Morgan's laws, idempotence)

### 1B. Type System + Uncertainty (Week 5-6)

**Deliverable**: `nspl.core.types`, `nspl.core.uncertainty`

```python
from nspl.core import UncertainValue, Concept, Distribution

temp = UncertainValue(value=22.5, confidence=0.8, distribution=Normal(22.5, 1.2))
result = temp.map(lambda c: c * 9/5 + 32)  # Propagates uncertainty
assert result.confidence == 0.8
assert isinstance(result.distribution, Normal)
```

Key classes:
- `UncertainValue[T]` -- value + confidence + optional distribution
- `Concept` -- dual neural/symbolic representation with alignment score
- `Distribution` -- wrapper over scipy.stats / torch.distributions

**Uncertainty propagation**: Monte Carlo (default) and analytical (for known distributions).

**Experiment 2**: _Uncertainty calibration_
- Take 1000 factual questions with known answers
- Have Claude/GPT answer with NSPL uncertainty wrappers vs. raw logprob extraction
- Compare calibration curves (ECE metric)
- **Hypothesis**: Explicit uncertainty propagation produces better-calibrated confidence than raw logprobs

### 1C. Concept / Knowledge Types (Week 7-8)

**Deliverable**: `nspl.core.concepts`

```python
@concept
class Person:
    embedding: Embedding(source="person", dim=256)
    name: str
    age: int = Field(gt=0)

    @rule
    def is_adult(self) -> bool:
        return self.age >= 18
```

Built on Pydantic for validation. Embedding field auto-generates via configurable backend (OpenAI, sentence-transformers, etc.).

**Test**: Round-trip tests -- symbolize(neuralize(x)) ~= x within tolerance.

---

## Phase 2: Action Verification (Week 9-14)

The highest-value piece. This is what people will actually use.

### 2A. Action Decorator System (Week 9-11)

**Deliverable**: `nspl.actions`

```python
from nspl.actions import action, preconditions, postconditions, safety_checks
from nspl.core.logic_gates import AND, NOT

@action
class ProcessRefund:
    order_id: str
    amount: float
    customer_id: str

    @preconditions
    def check(self, ctx):
        return AND(
            ctx.order_service.exists(self.order_id),
            self.amount <= ctx.order_service.total(self.order_id),
            ctx.order_service.owns(self.customer_id, self.order_id),
        )

    @safety_checks
    def safety(self, ctx):
        return AND(
            self.amount < 1000 or ctx.has_approval(),
            NOT(ctx.fraud.recent_refunds(self.customer_id, count=3)),
        )

    def execute(self, ctx):
        return ctx.payment.refund(self.order_id, self.amount)

    @postconditions
    def verify(self, ctx, result):
        return AND(
            result.success,
            ctx.order_service.status(self.order_id) == "refunded",
        )
```

**Key features**:
- Automatic verification pipeline: preconditions -> safety -> execute -> postconditions
- `safe_execute()` runs the full pipeline, raises typed exceptions on failure
- Action registry for discovery by agent frameworks
- Audit trail logging (every check, every result, timestamps)
- Dry-run mode (runs checks without executing)

### 2B. Agent Framework Integration (Week 12-14)

**Deliverable**: `nspl.integrations`

Wrap NSPL actions as tool definitions for:

| Framework | Integration Point | Priority |
|-----------|------------------|----------|
| Claude (Anthropic SDK) | `tool_use` blocks | P0 |
| OpenAI | Function calling | P0 |
| Google ADK | Tool interface | P1 |
| MCP | Tool server | P1 |
| LangChain | Tool class | P2 |

```python
from nspl.integrations.anthropic import nspl_tools

client = anthropic.Anthropic()
tools = nspl_tools([ProcessRefund, UpdateOrder, CheckStatus])

response = client.messages.create(
    model="claude-sonnet-4-20250514",
    tools=tools,  # NSPL-verified tool definitions
    messages=[{"role": "user", "content": "Refund order #123"}]
)
```

**Experiment 3**: _Action safety catch rate_
- Define 20 actions with known safety boundaries
- Generate 1000 tool calls (500 valid, 500 adversarial/boundary violations)
- Compare: NSPL-verified vs. raw function calling vs. Guardrails AI vs. prompt-based safety
- Metrics: true positive rate, false positive rate, latency overhead
- **Hypothesis**: NSPL catches >95% of violations with <50ms overhead

---

## Phase 3: Reasoning Pipelines (Week 15-20)

### 3A. Pipeline Engine (Week 15-17)

**Deliverable**: `nspl.reasoning`

```python
from nspl.reasoning import pipeline, planning, exploration, execution, reflection

@pipeline
def answer_question(question: str) -> dict:

    @planning
    def plan(q: str) -> Plan:
        return llm.generate(f"Break this into steps: {q}")

    @exploration
    def explore(plan: Plan) -> list[Path]:
        return [evaluate_path(p) for p in plan.alternatives(max=5)]

    @execution
    def execute(path: Path) -> Result:
        for step in path:
            step.verify_preconditions()
            result = step.run()
            step.verify_postconditions(result)
        return result

    @reflection
    def reflect(result: Result) -> dict:
        confidence = evaluate_confidence(result)
        return {"answer": result, "confidence": confidence, "path": path}
```

**Features**:
- Stage-level retry with backoff
- Confidence gating between stages (don't proceed if confidence < threshold)
- Full trace logging for debugging
- Async support for parallel exploration

### 3B. Structured Reasoning Benchmarks (Week 18-20)

**Experiment 4**: _Structured vs. unstructured reasoning_
- Tasks: GSM8K (math), StrategyQA (multi-hop), HotpotQA (retrieval reasoning)
- Compare: NSPL pipeline vs. raw CoT vs. DSPy vs. ReAct
- Metrics: accuracy, reasoning trace quality (human eval), token efficiency
- **Hypothesis**: NSPL pipelines match or exceed CoT accuracy while producing auditable traces

**Experiment 5**: _Confidence calibration in pipelines_
- Same tasks as Experiment 4
- Measure: does NSPL's per-stage confidence propagation predict answer correctness?
- Metric: AUROC of confidence score as correctness predictor
- **Hypothesis**: Stage-wise uncertainty propagation outperforms single-shot confidence

---

## Phase 4: Polish + Paper (Week 21-26)

### 4A. Documentation + Examples (Week 21-22)
- [ ] Quickstart tutorial (5 min to first verified action)
- [ ] Full API reference (auto-generated from docstrings)
- [ ] 3 end-to-end examples:
  - Customer service agent with verified refunds
  - Research assistant with verified citations
  - Code review agent with verified safety checks
- [ ] Comparison guide: NSPL vs. Guardrails vs. DSPy vs. raw function calling

### 4B. Paper Writing (Week 23-26)

**Target venues** (pick 1-2):

| Venue | Type | Deadline | Fit |
|-------|------|----------|-----|
| **NeSy 2026** | Workshop/Conference | ~Jun 2026 | Core neurosymbolic audience |
| **EMNLP 2026 Demo** | Demo track | ~Jun 2026 | Tool paper, practical focus |
| **ICSE 2027 NIER** | New Ideas | ~Oct 2026 | SE + verification angle |
| **AAAI 2027** | Main conference | ~Aug 2026 | Broader AI audience |
| **arXiv preprint** | Preprint | Anytime | Establish priority, get citations |

**Paper structure**:
1. Problem: Agentic AI lacks formal verification for tool use
2. NSPL: Logic-gated actions + uncertainty-aware reasoning pipelines
3. Experiments 1-5 (selected subset)
4. Results: Safety catch rate, calibration, reasoning quality
5. Related work: LNN, DeepProbLog, Scallop, DSPy, Guardrails
6. Open source: pip install nspl

### 4C. Release (Week 26)
- [ ] PyPI release: `pip install nspl`
- [ ] GitHub repo: MIT license
- [ ] Blog post / Twitter thread
- [ ] Submit to Hacker News / r/MachineLearning

---

## Dependency Graph

```
Phase 0: Bootstrap
    |
    v
Phase 1A: Logic Gates -----> Phase 1B: Types/Uncertainty
    |                              |
    |                              v
    |                         Phase 1C: Concepts
    |                              |
    v                              v
Phase 2A: Action Verification <----+
    |
    v
Phase 2B: Agent Integrations
    |
    v
Phase 3A: Reasoning Pipelines
    |
    v
Phase 3B: Benchmarks
    |
    v
Phase 4: Paper + Release
```

**Critical path**: 0 -> 1A -> 2A -> 2B -> 3A -> 4B

Phases 1B and 1C can run in parallel with 1A. Phase 3B can overlap with 4A.

---

## Experiments Summary

| # | Name | Phase | Key Metric | Baseline |
|---|------|-------|------------|----------|
| 1 | Logic gate accuracy | 1A | Accuracy + calibration | Python eval, LLM-as-judge |
| 2 | Uncertainty calibration | 1B | ECE (Expected Calibration Error) | Raw logprobs |
| 3 | Action safety catch rate | 2B | TPR/FPR + latency | Guardrails, prompt-based |
| 4 | Structured reasoning | 3B | Accuracy on GSM8K/StrategyQA | CoT, DSPy, ReAct |
| 5 | Confidence propagation | 3B | AUROC (confidence vs. correctness) | Single-shot confidence |

---

## Competitive Landscape

| Tool | What it does | NSPL differentiator |
|------|-------------|-------------------|
| **DSPy** | Declarative LM programs, optimizer | NSPL adds formal verification + logic gates; DSPy optimizes prompts |
| **Guardrails AI** | Output validation/guardrails | NSPL is pre-execution (preconditions), Guardrails is post-execution |
| **LangChain** | Agent orchestration | NSPL is verification layer, not orchestration; complementary |
| **Instructor** | Structured output extraction | NSPL goes beyond extraction to verified action execution |
| **LNN (IBM)** | Logical Neural Networks | Research-only, no agent integration; NSPL is practical framework |
| **DeepProbLog** | Probabilistic logic + neural | Academic, Prolog-based; NSPL is Python-native |
| **Scallop** | Differentiable Datalog | Research language; NSPL targets agentic AI specifically |

**NSPL's unique position**: The only framework that combines (1) differentiable logic gates, (2) pre/postcondition verification for agent tool calls, and (3) uncertainty-aware reasoning pipelines in a single pip-installable package.

---

## Resource Requirements

| Resource | Details |
|----------|---------|
| **Compute** | Local dev + small GPU for gate training; API credits for LLM experiments |
| **API costs** | ~$200-500 for experiments (Claude/GPT calls for benchmarks) |
| **Time** | 26 weeks (~6 months) at 10-15 hrs/week = 260-390 hours |
| **Dependencies** | PyTorch (optional), Pydantic, anthropic/openai SDKs, scipy |

---

## Risk Register

| Risk | Impact | Mitigation |
|------|--------|------------|
| Logic gates add latency that makes framework impractical | High | Profile early (Phase 1A). Target <10ms per gate evaluation. Pure Python fallback. |
| Experiments show no improvement over baselines | High | Pivot narrative to "same accuracy + auditability" -- the trace is the value. |
| Agent framework APIs change | Medium | Thin adapter layer. Pin SDK versions. |
| Scope creep into compiler/language design | Medium | Hard rule: Python decorators only. No parser. No custom syntax. |
| Someone ships a competing tool | Medium | Move fast. Publish arXiv preprint after Phase 2. |

---

## File Organization (Final State)

```
nspl/
  docs/
    design/                    # Original 8 design documents (archived)
    api/                       # Auto-generated API reference
    tutorials/                 # Quickstart, examples
  src/
    nspl/                      # The pip package
      core/
      actions/
      reasoning/
      integrations/
      testing/
  tests/
    test_logic_gates.py
    test_uncertainty.py
    test_actions.py
    test_reasoning.py
    test_integrations.py
  experiments/
    exp1_gate_accuracy/
    exp2_uncertainty_calibration/
    exp3_action_safety/
    exp4_structured_reasoning/
    exp5_confidence_propagation/
  paper/
    main.tex
    figures/
    tables/
  ROADMAP.md                   # This file
  CLAUDE.md                    # Project instructions
  pyproject.toml
  README.md
```
