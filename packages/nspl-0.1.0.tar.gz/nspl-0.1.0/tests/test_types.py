"""Tests for UncertainValue type."""

import pytest

from nspl.core.types import UncertainValue


class TestConstruction:
    def test_basic(self) -> None:
        v = UncertainValue(value=42, confidence=0.9)
        assert v.value == 42
        assert v.confidence == 0.9

    def test_default_confidence(self) -> None:
        v = UncertainValue(value="hello")
        assert v.confidence == 1.0

    def test_confidence_out_of_range_high(self) -> None:
        with pytest.raises(Exception):  # noqa: B017
            UncertainValue(value=1, confidence=1.5)

    def test_confidence_out_of_range_low(self) -> None:
        with pytest.raises(Exception):  # noqa: B017
            UncertainValue(value=1, confidence=-0.1)

    def test_confidence_boundary(self) -> None:
        v0 = UncertainValue(value=1, confidence=0.0)
        v1 = UncertainValue(value=1, confidence=1.0)
        assert v0.confidence == 0.0
        assert v1.confidence == 1.0


class TestMap:
    def test_preserves_confidence(self) -> None:
        v = UncertainValue(value=10, confidence=0.7)
        result = v.map(lambda x: x * 2)
        assert result.value == 20
        assert result.confidence == 0.7

    def test_string_map(self) -> None:
        v = UncertainValue(value="hello", confidence=0.9)
        result = v.map(lambda x: x.upper())
        assert result.value == "HELLO"
        assert result.confidence == 0.9


class TestFlatMap:
    def test_composes_confidence(self) -> None:
        v = UncertainValue(value=10, confidence=0.8)
        result = v.flat_map(lambda x: UncertainValue(value=x + 1, confidence=0.9))
        assert result.value == 11
        assert result.confidence == pytest.approx(0.72)  # 0.8 * 0.9

    def test_plain_return(self) -> None:
        v = UncertainValue(value=10, confidence=0.8)
        result = v.flat_map(lambda x: x + 1)
        assert result.value == 11
        assert result.confidence == 0.8  # preserved since fn didn't return UncertainValue


class TestRequire:
    def test_above_threshold(self) -> None:
        v = UncertainValue(value=42, confidence=0.9)
        assert v.require(0.8, lambda: 0) == 42

    def test_below_threshold(self) -> None:
        v = UncertainValue(value=42, confidence=0.5)
        assert v.require(0.8, lambda: 0) == 0

    def test_exact_threshold(self) -> None:
        v = UncertainValue(value=42, confidence=0.8)
        assert v.require(0.8, lambda: 0) == 42


class TestBool:
    def test_truthy(self) -> None:
        assert bool(UncertainValue(value=True, confidence=0.1))

    def test_falsy(self) -> None:
        assert not bool(UncertainValue(value=False, confidence=0.99))

    def test_numeric_truthy(self) -> None:
        assert bool(UncertainValue(value=1, confidence=0.5))

    def test_numeric_falsy(self) -> None:
        assert not bool(UncertainValue(value=0, confidence=0.5))
