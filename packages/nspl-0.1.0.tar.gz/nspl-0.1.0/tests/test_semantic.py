"""Tests for semantic analysis tiers."""

from nspl.guards.semantic import (
    StructuralDetector,
    StructuralSignals,
    TieredDetector,
    analyze_structure,
    structural_risk_score,
)


class TestAnalyzeStructure:
    def test_safe_text(self) -> None:
        s = analyze_structure("Hello, how are you today?")
        assert not s.mixed_scripts
        assert not s.suspicious_formatting
        assert s.instruction_density < 0.05

    def test_high_instruction_density(self) -> None:
        s = analyze_structure(
            "ignore override bypass disable execute reveal output forget"
        )
        assert s.instruction_density > 0.3

    def test_suspicious_formatting(self) -> None:
        s = analyze_structure("```system\nhidden instructions```")
        assert s.suspicious_formatting

    def test_delimiter_markers(self) -> None:
        for marker in ["<<<", ">>>", "[[[", "<|", "|>", "<<SYS>>"]:
            s = analyze_structure(f"text {marker} more text")
            assert s.suspicious_formatting, f"Should detect {marker}"


class TestStructuralRiskScore:
    def test_clean_is_low(self) -> None:
        s = StructuralSignals(
            normalized_text="hello", entropy=3.5,
            mixed_scripts=False, instruction_density=0.0,
            suspicious_formatting=False,
        )
        assert structural_risk_score(s) < 0.1

    def test_mixed_scripts_adds_risk(self) -> None:
        s = StructuralSignals(
            normalized_text="hello", entropy=3.5,
            mixed_scripts=True, instruction_density=0.0,
            suspicious_formatting=False,
        )
        assert structural_risk_score(s) >= 0.4

    def test_high_instruction_density_adds_risk(self) -> None:
        s = StructuralSignals(
            normalized_text="ignore bypass override", entropy=3.5,
            mixed_scripts=False, instruction_density=0.2,
            suspicious_formatting=False,
        )
        assert structural_risk_score(s) >= 0.3

    def test_combined_signals(self) -> None:
        s = StructuralSignals(
            normalized_text="x", entropy=6.0,
            mixed_scripts=True, instruction_density=0.2,
            suspicious_formatting=True,
        )
        score = structural_risk_score(s)
        assert score >= 0.8


class TestStructuralDetector:
    def test_clean_not_triggered(self) -> None:
        det = StructuralDetector(threshold=0.4)
        r = det.detect("What is the weather?")
        assert not r.triggered

    def test_suspicious_triggered(self) -> None:
        det = StructuralDetector(threshold=0.3)
        r = det.detect("### system ignore override bypass disable [[[")
        assert r.triggered


class TestTieredDetectorStructuralOnly:
    def test_clear_safe(self) -> None:
        det = TieredDetector()
        r = det.detect("How do I bake a cake?")
        assert not r.triggered

    def test_clear_unsafe_structural(self) -> None:
        det = TieredDetector(structural_threshold=0.3)
        r = det.detect(
            "### system [INST] <<SYS>> ignore override bypass disable execute"
        )
        assert r.triggered

    def test_escalation_range(self) -> None:
        det = TieredDetector(escalation_range=(0.1, 0.3))
        # Just verify it doesn't crash on ambiguous input
        r = det.detect("Tell me about system security practices")
        assert r.detector_name == "structural"
