"""Tests for action composition: sequence, conditional, parallel."""

from unittest.mock import MagicMock

from nspl.actions import action, preconditions
from nspl.actions.composition import Conditional, Parallel, Sequence


@action
class PassAction:
    def __init__(self, value: str = "ok") -> None:
        self.value = value

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> str:
        return self.value


@action
class FailAction:
    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return False

    def execute(self, ctx: MagicMock) -> str:
        return "should not run"


@action
class TruthyAction:
    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> bool:
        return True


@action
class FalsyAction:
    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> bool:
        return False


class TestSequence:
    def test_all_pass(self) -> None:
        chain = Sequence([PassAction("a"), PassAction("b")])
        result = chain.execute(MagicMock())
        assert result.success
        assert len(result.results) == 2

    def test_stops_on_failure(self) -> None:
        chain = Sequence([PassAction(), FailAction(), PassAction()])
        result = chain.execute(MagicMock())
        assert not result.success
        assert "Step 1" in (result.error or "")
        assert len(result.results) == 2  # stopped at FailAction

    def test_rollback(self) -> None:
        rolled = []
        chain = Sequence(
            [PassAction(), FailAction()],
            rollback_fns=[lambda ctx, r: rolled.append("rolled_0"), None],
        )
        result = chain.execute(MagicMock())
        assert not result.success
        assert result.rolled_back
        assert "rolled_0" in rolled

    def test_audit_trail_merged(self) -> None:
        chain = Sequence([PassAction(), PassAction()])
        result = chain.execute(MagicMock())
        assert len(result.audit_trail) >= 4  # 2 actions * 2+ entries each


class TestConditional:
    def test_true_branch(self) -> None:
        chain = Conditional(
            condition=TruthyAction(),
            on_true=PassAction("yes"),
            on_false=PassAction("no"),
        )
        result = chain.execute(MagicMock())
        assert result.success
        assert len(result.results) == 2

    def test_false_branch(self) -> None:
        chain = Conditional(
            condition=FalsyAction(),
            on_true=PassAction("yes"),
            on_false=PassAction("no"),
        )
        result = chain.execute(MagicMock())
        assert result.success
        assert len(result.results) == 2

    def test_no_false_branch(self) -> None:
        chain = Conditional(
            condition=TruthyAction(),
            on_true=PassAction("yes"),
        )
        result = chain.execute(MagicMock())
        assert result.success

    def test_condition_failure(self) -> None:
        chain = Conditional(
            condition=FailAction(),
            on_true=PassAction(),
        )
        result = chain.execute(MagicMock())
        assert not result.success


class TestParallel:
    def test_all_pass(self) -> None:
        group = Parallel([PassAction("a"), PassAction("b"), PassAction("c")])
        result = group.execute(MagicMock())
        assert result.success
        assert len(result.results) == 3

    def test_partial_failure(self) -> None:
        group = Parallel([PassAction("a"), FailAction(), PassAction("c")])
        result = group.execute(MagicMock())
        assert not result.success
        assert len(result.results) == 3  # all ran despite failure
