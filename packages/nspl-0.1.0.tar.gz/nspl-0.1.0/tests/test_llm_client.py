"""Tests for LLM client with mocked subprocess/SDK calls."""

from unittest.mock import MagicMock, patch

from nspl.llm.client import LLMClient, _strip_cli_noise, query_llm


class TestStripNoise:
    def test_strips_warnings(self) -> None:
        text = "Loaded cached credentials\nHello world\nHook cancelled"
        assert _strip_cli_noise(text) == "Hello world"

    def test_clean_text_unchanged(self) -> None:
        assert _strip_cli_noise("Hello world") == "Hello world"

    def test_empty(self) -> None:
        assert _strip_cli_noise("") == ""

    def test_all_noise(self) -> None:
        assert _strip_cli_noise("Loaded cached credentials\nHook cancelled") == ""


class TestLLMClientCLI:
    @patch("nspl.llm.client.subprocess.run")
    def test_successful_query(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(
            returncode=0, stdout="The answer is 42\n", stderr=""
        )
        client = LLMClient(provider="claude", prefer_sdk=False)
        resp = client.query("What is 6*7?")
        assert resp.success
        assert "42" in resp.text
        assert resp.mode == "cli"

    @patch("nspl.llm.client.subprocess.run")
    def test_cli_error(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(
            returncode=1, stdout="", stderr="Auth failed"
        )
        client = LLMClient(provider="claude", prefer_sdk=False)
        resp = client.query("test")
        assert not resp.success
        assert "Auth" in (resp.error or "")

    @patch("nspl.llm.client.subprocess.run")
    def test_timeout(self, mock_run: MagicMock) -> None:
        import subprocess
        mock_run.side_effect = subprocess.TimeoutExpired(cmd="claude", timeout=5)
        client = LLMClient(provider="claude", prefer_sdk=False, timeout_s=5)
        resp = client.query("test")
        assert not resp.success
        assert "Timeout" in (resp.error or "")

    @patch("nspl.llm.client.subprocess.run")
    def test_cli_not_found(self, mock_run: MagicMock) -> None:
        mock_run.side_effect = FileNotFoundError()
        client = LLMClient(provider="claude", prefer_sdk=False)
        resp = client.query("test")
        assert not resp.success
        assert "not found" in (resp.error or "").lower()

    @patch("nspl.llm.client.subprocess.run")
    def test_batch(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(returncode=0, stdout="ok", stderr="")
        client = LLMClient(provider="claude", prefer_sdk=False)
        results = client.batch(["a", "b"])
        assert len(results) == 2
        assert all(r.success for r in results)

    @patch("nspl.llm.client.subprocess.run")
    def test_gemini_provider(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(returncode=0, stdout="response", stderr="")
        client = LLMClient(provider="gemini", prefer_sdk=False)
        resp = client.query("test")
        assert resp.provider == "gemini"

    @patch("nspl.llm.client.subprocess.run")
    def test_openai_provider(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(returncode=0, stdout="response", stderr="")
        client = LLMClient(provider="openai", prefer_sdk=False)
        resp = client.query("test")
        assert resp.provider == "openai"


class TestQueryLLMConvenience:
    @patch("nspl.llm.client.subprocess.run")
    def test_convenience(self, mock_run: MagicMock) -> None:
        mock_run.return_value = MagicMock(returncode=0, stdout="hello", stderr="")
        resp = query_llm("test", provider="claude")
        assert resp.success


class TestLLMClientSDK:
    def test_no_api_key_uses_cli(self) -> None:
        client = LLMClient(provider="claude")
        assert not client._has_api_key()

    def test_get_default_model(self) -> None:
        client = LLMClient(provider="claude")
        assert "claude" in client._get_model()

    def test_custom_model(self) -> None:
        client = LLMClient(provider="claude", model="custom-model")
        assert client._get_model() == "custom-model"
