"""Tests for async pipeline execution."""

import asyncio

import pytest

from nspl.core.types import UncertainValue
from nspl.reasoning.async_pipeline import async_parallel_stages, async_run_pipeline
from nspl.reasoning.pipeline import PipelineConfig


@pytest.fixture
def event_loop():
    loop = asyncio.new_event_loop()
    yield loop
    loop.close()


class TestAsyncPipeline:
    def test_sync_stages(self) -> None:
        """Sync functions work in async pipeline."""
        result = asyncio.run(async_run_pipeline([
            ("double", lambda x: x * 2),
            ("add", lambda x: x + 1),
        ], initial_input=5))
        assert result.output == 11
        assert not result.aborted

    def test_async_stages(self) -> None:
        """Async functions work."""
        async def async_double(x: int) -> int:
            await asyncio.sleep(0.001)
            return x * 2

        result = asyncio.run(async_run_pipeline([
            ("double", async_double),
        ], initial_input=5))
        assert result.output == 10

    def test_mixed_stages(self) -> None:
        """Mix of sync and async stages."""
        async def async_add(x: int) -> int:
            return x + 1

        result = asyncio.run(async_run_pipeline([
            ("double", lambda x: x * 2),
            ("add", async_add),
        ], initial_input=5))
        assert result.output == 11

    def test_confidence_gating(self) -> None:
        async def uncertain(x: int) -> UncertainValue:
            return UncertainValue(value=x, confidence=0.2)

        result = asyncio.run(async_run_pipeline(
            [("uncertain", uncertain)],
            initial_input=1,
            config=PipelineConfig(stage_threshold=0.5),
        ))
        assert result.aborted
        assert "confidence" in (result.abort_reason or "").lower()

    def test_retry(self) -> None:
        attempts = {"n": 0}

        async def flaky(x: int) -> int:
            attempts["n"] += 1
            if attempts["n"] < 2:
                raise RuntimeError("fail")
            return x

        result = asyncio.run(async_run_pipeline(
            [("flaky", flaky)],
            initial_input=42,
            config=PipelineConfig(max_retries=2),
        ))
        assert not result.aborted
        assert result.output == 42

    def test_empty(self) -> None:
        result = asyncio.run(async_run_pipeline([]))
        assert result.aborted


class TestParallelStages:
    def test_parallel(self) -> None:
        async def double(x: int) -> int:
            return x * 2

        async def triple(x: int) -> int:
            return x * 3

        results = asyncio.run(async_parallel_stages([
            ("double", double),
            ("triple", triple),
        ], input_data=5))
        assert results["double"] == 10
        assert results["triple"] == 15

    def test_sync_in_parallel(self) -> None:
        results = asyncio.run(async_parallel_stages([
            ("a", lambda x: x + 1),
            ("b", lambda x: x + 2),
        ], input_data=10))
        assert results["a"] == 11
        assert results["b"] == 12
