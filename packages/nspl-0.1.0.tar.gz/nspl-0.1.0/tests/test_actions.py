"""Tests for the action verification pipeline."""

from unittest.mock import MagicMock

from nspl.actions import (
    ActionRegistry,
    ActionResult,
    DryRunResult,
    action,
    postconditions,
    preconditions,
    safety_checks,
)
from nspl.core.logic_gates import AND, NOT
from nspl.core.types import UncertainValue

# ── Fixtures: mock context and sample actions ────────────────────────


def _make_ctx(
    order_exists: bool = True,
    order_total: float = 100.0,
    owns_order: bool = True,
    has_approval: bool = False,
    recent_refunds: bool = False,
    refund_success: bool = True,
    status_after: str = "refunded",
) -> MagicMock:
    ctx = MagicMock()
    ctx.orders.exists.return_value = order_exists
    ctx.orders.total.return_value = order_total
    ctx.orders.owns.return_value = owns_order
    ctx.orders.status.return_value = status_after
    ctx.has_approval.return_value = has_approval
    ctx.fraud.recent_refunds.return_value = recent_refunds
    ctx.payments.refund.return_value = MagicMock(success=refund_success)
    return ctx


@action
class ProcessRefund:
    def __init__(self, order_id: str, amount: float) -> None:
        self.order_id = order_id
        self.amount = amount

    @preconditions
    def check(self, ctx: MagicMock) -> float:
        return AND(
            ctx.orders.exists(self.order_id),
            self.amount <= ctx.orders.total(self.order_id),
            ctx.orders.owns("customer_1", self.order_id),
        )

    @safety_checks
    def safety(self, ctx: MagicMock) -> float:
        return AND(
            float(self.amount < 1000 or ctx.has_approval()),
            NOT(ctx.fraud.recent_refunds(self.order_id, count=3)),
        )

    def execute(self, ctx: MagicMock) -> MagicMock:
        return ctx.payments.refund(self.order_id, self.amount)

    @postconditions
    def verify(self, ctx: MagicMock, result: MagicMock) -> bool:
        return bool(result.success) and ctx.orders.status(self.order_id) == "refunded"


# ── Tests ────────────────────────────────────────────────────────────


class TestHappyPath:
    def test_success(self) -> None:
        ctx = _make_ctx()
        refund = ProcessRefund("order_123", 49.99)
        result: ActionResult = refund.safe_execute(ctx)
        assert result.success is True
        assert result.error is None
        assert len(result.audit_trail) >= 3  # pre + safety + exec + post

    def test_audit_trail_stages(self) -> None:
        ctx = _make_ctx()
        result: ActionResult = ProcessRefund("o1", 10.0).safe_execute(ctx)
        stages = [e.stage for e in result.audit_trail]
        assert "precondition" in stages
        assert "safety" in stages
        assert "execution" in stages
        assert "postcondition" in stages

    def test_duration_recorded(self) -> None:
        ctx = _make_ctx()
        result: ActionResult = ProcessRefund("o1", 10.0).safe_execute(ctx)
        assert result.duration_ms > 0


class TestPreconditionFailure:
    def test_order_not_found(self) -> None:
        ctx = _make_ctx(order_exists=False)
        result: ActionResult = ProcessRefund("bad_order", 10.0).safe_execute(ctx)
        assert result.success is False
        assert "Precondition" in (result.error or "")

    def test_amount_exceeds_total(self) -> None:
        ctx = _make_ctx(order_total=20.0)
        result: ActionResult = ProcessRefund("o1", 50.0).safe_execute(ctx)
        assert result.success is False
        assert "Precondition" in (result.error or "")

    def test_not_owner(self) -> None:
        ctx = _make_ctx(owns_order=False)
        result: ActionResult = ProcessRefund("o1", 10.0).safe_execute(ctx)
        assert result.success is False

    def test_execution_not_called(self) -> None:
        ctx = _make_ctx(order_exists=False)
        ProcessRefund("o1", 10.0).safe_execute(ctx)
        ctx.payments.refund.assert_not_called()


class TestSafetyFailure:
    def test_over_limit_no_approval(self) -> None:
        ctx = _make_ctx(has_approval=False, order_total=2000.0)
        result: ActionResult = ProcessRefund("o1", 1500.0).safe_execute(ctx)
        assert result.success is False
        assert "Safety" in (result.error or "")

    def test_recent_fraud(self) -> None:
        ctx = _make_ctx(recent_refunds=True)
        result: ActionResult = ProcessRefund("o1", 10.0).safe_execute(ctx)
        assert result.success is False
        assert "Safety" in (result.error or "")


class TestPostconditionFailure:
    def test_refund_failed(self) -> None:
        ctx = _make_ctx(refund_success=False)
        result: ActionResult = ProcessRefund("o1", 10.0).safe_execute(ctx)
        assert result.success is False
        assert "Postcondition" in (result.error or "")

    def test_status_not_updated(self) -> None:
        ctx = _make_ctx(status_after="pending")
        result: ActionResult = ProcessRefund("o1", 10.0).safe_execute(ctx)
        assert result.success is False


class TestDryRun:
    def test_would_execute(self) -> None:
        ctx = _make_ctx()
        result: DryRunResult = ProcessRefund("o1", 10.0).dry_run(ctx)
        assert result.would_execute is True
        ctx.payments.refund.assert_not_called()

    def test_would_not_execute(self) -> None:
        ctx = _make_ctx(order_exists=False)
        result: DryRunResult = ProcessRefund("o1", 10.0).dry_run(ctx)
        assert result.would_execute is False

    def test_trail_present(self) -> None:
        ctx = _make_ctx()
        result: DryRunResult = ProcessRefund("o1", 10.0).dry_run(ctx)
        assert len(result.audit_trail) >= 2


class TestUncertaintyThresholds:
    def test_low_confidence_fails(self) -> None:
        @action
        class UncertainAction:
            @preconditions
            def check(self, ctx: MagicMock) -> UncertainValue:
                return UncertainValue(value=True, confidence=0.5)

            def execute(self, ctx: MagicMock) -> str:
                return "done"

        ctx = MagicMock()
        result: ActionResult = UncertainAction().safe_execute(ctx, precondition_threshold=0.9)
        assert result.success is False

    def test_high_confidence_passes(self) -> None:
        @action
        class ConfidentAction:
            @preconditions
            def check(self, ctx: MagicMock) -> UncertainValue:
                return UncertainValue(value=True, confidence=0.95)

            def execute(self, ctx: MagicMock) -> str:
                return "done"

        ctx = MagicMock()
        result: ActionResult = ConfidentAction().safe_execute(ctx, precondition_threshold=0.9)
        assert result.success is True


class TestRegistry:
    def test_register_and_get(self) -> None:
        reg = ActionRegistry()
        reg.register("refund", ProcessRefund)
        assert reg.get("refund") is ProcessRefund

    def test_list_actions(self) -> None:
        reg = ActionRegistry()
        reg.register("refund", ProcessRefund)
        reg.register("cancel", ProcessRefund)
        assert set(reg.list_actions()) == {"refund", "cancel"}

    def test_schema_generation(self) -> None:
        reg = ActionRegistry()
        reg.register("refund", ProcessRefund)
        schemas = reg.to_tool_schemas()
        assert len(schemas) == 1
        assert schemas[0]["name"] == "refund"
        assert "parameters" in schemas[0]

    def test_unknown_action(self) -> None:
        reg = ActionRegistry()
        try:
            reg.get("nonexistent")
            assert False, "Should have raised"
        except KeyError:
            pass
