"""Property-based tests for NSPL logic gates using hypothesis."""

from hypothesis import given, settings
from hypothesis import strategies as st

from nspl.core.logic_gates import AND, NOT, OR

fuzzy = st.floats(min_value=0.0, max_value=1.0, allow_nan=False, allow_infinity=False)


# ── Commutativity ─────────────────────────────────────────────────────


@given(fuzzy, fuzzy)
@settings(max_examples=300)
def test_and_commutative(a: float, b: float) -> None:
    assert abs(AND(a, b) - AND(b, a)) < 1e-9


@given(fuzzy, fuzzy)
@settings(max_examples=300)
def test_or_commutative(a: float, b: float) -> None:
    assert abs(OR(a, b) - OR(b, a)) < 1e-9


# ── De Morgan's Laws ─────────────────────────────────────────────────
# With product t-norm: NOT(AND(a,b)) = 1 - a*b  (for 2 equal-weight inputs: geometric mean)
#                      OR(NOT(a),NOT(b)) = 1 - AND(1-a,1-b) = 1 - sqrt((1-a)*(1-b))
# These are NOT algebraically equal, so we use a generous tolerance
# and test on "extreme" inputs (near 0/1) where they should converge.


@given(
    st.floats(min_value=0.0, max_value=0.1, allow_nan=False),
    st.floats(min_value=0.0, max_value=0.1, allow_nan=False),
)
@settings(max_examples=200)
def test_de_morgan_and_low_inputs(a: float, b: float) -> None:
    """De Morgan for low inputs: NOT(AND(a,b)) and OR(NOT(a), NOT(b)) both near 1."""
    lhs = NOT(AND(a, b))
    rhs = OR(NOT(a), NOT(b))
    assert lhs > 0.7
    assert rhs > 0.7


@given(
    st.floats(min_value=0.9, max_value=1.0, allow_nan=False),
    st.floats(min_value=0.9, max_value=1.0, allow_nan=False),
)
@settings(max_examples=200)
def test_de_morgan_and_high_inputs(a: float, b: float) -> None:
    """De Morgan for high inputs: NOT(AND(a,b)) and OR(NOT(a), NOT(b)) both near 0."""
    lhs = NOT(AND(a, b))
    rhs = OR(NOT(a), NOT(b))
    assert lhs < 0.3
    assert rhs < 0.3


# ── Double negation ──────────────────────────────────────────────────


@given(fuzzy)
@settings(max_examples=300)
def test_double_negation(a: float) -> None:
    """NOT(NOT(a)) == a exactly for fuzzy complement."""
    assert abs(NOT(NOT(a)) - a) < 1e-9


# ── Identity elements ────────────────────────────────────────────────


@given(fuzzy)
@settings(max_examples=300)
def test_and_identity(a: float) -> None:
    """AND(a, 1.0) should be close to a (1.0 is identity for AND)."""
    result = AND(a, 1.0)
    # Product t-norm: sqrt(a * 1.0) = sqrt(a), not exactly a
    # But for values near 0 and 1, it should preserve direction
    if a > 0.8:
        assert result > 0.5
    if a < 0.2:
        assert result < 0.5


@given(fuzzy)
@settings(max_examples=300)
def test_or_identity(a: float) -> None:
    """OR(a, 0.0) should be close to a (0.0 is identity for OR)."""
    result = OR(a, 0.0)
    if a > 0.8:
        assert result > 0.5
    if a < 0.2:
        assert result < 0.5


# ── Monotonicity ─────────────────────────────────────────────────────


@given(fuzzy, fuzzy, fuzzy)
@settings(max_examples=500)
def test_and_monotone(a: float, b: float, c: float) -> None:
    """If a <= b, then AND(a, c) <= AND(b, c)."""
    if a <= b:
        assert AND(a, c) <= AND(b, c) + 1e-9


@given(fuzzy, fuzzy, fuzzy)
@settings(max_examples=500)
def test_or_monotone(a: float, b: float, c: float) -> None:
    """If a <= b, then OR(a, c) <= OR(b, c)."""
    if a <= b:
        assert OR(a, c) <= OR(b, c) + 1e-9


# ── Boundary behavior ────────────────────────────────────────────────


@given(fuzzy)
@settings(max_examples=300)
def test_and_with_zero(a: float) -> None:
    """AND(a, 0) should be near 0."""
    assert AND(a, 0.0) < 0.1


@given(fuzzy)
@settings(max_examples=300)
def test_or_with_one(a: float) -> None:
    """OR(a, 1) should be near 1."""
    assert OR(a, 1.0) > 0.9


# ── Output range ─────────────────────────────────────────────────────


@given(fuzzy, fuzzy)
@settings(max_examples=300)
def test_and_output_range(a: float, b: float) -> None:
    result = AND(a, b)
    assert 0.0 <= result <= 1.0


@given(fuzzy, fuzzy)
@settings(max_examples=300)
def test_or_output_range(a: float, b: float) -> None:
    result = OR(a, b)
    assert 0.0 <= result <= 1.0


@given(fuzzy)
@settings(max_examples=300)
def test_not_output_range(a: float) -> None:
    result = NOT(a)
    assert 0.0 <= result <= 1.0
