"""Tests for distribution and uncertainty propagation."""

import numpy as np
import pytest

from nspl.core.uncertainty import Categorical, Empirical, Normal, Uniform, propagate


class TestNormal:
    def test_sample_stats(self) -> None:
        d = Normal(mean=10.0, std=2.0)
        samples = d.sample(10000, seed=42)
        assert abs(np.mean(samples) - 10.0) < 0.1
        assert abs(np.std(samples) - 2.0) < 0.1

    def test_mean_std(self) -> None:
        d = Normal(mean=5.0, std=1.5)
        assert d.mean() == 5.0
        assert d.std() == 1.5

    def test_pdf(self) -> None:
        d = Normal(mean=0.0, std=1.0)
        # PDF at 0 for standard normal ≈ 0.3989
        assert abs(d.pdf(0.0) - 0.3989) < 0.001

    def test_negative_std(self) -> None:
        with pytest.raises(ValueError, match="non-negative"):
            Normal(mean=0, std=-1)


class TestUniform:
    def test_sample_range(self) -> None:
        d = Uniform(low=2.0, high=5.0)
        samples = d.sample(1000, seed=42)
        assert np.min(samples) >= 2.0
        assert np.max(samples) <= 5.0

    def test_mean_std(self) -> None:
        d = Uniform(low=0.0, high=10.0)
        assert d.mean() == 5.0
        assert abs(d.std() - 2.887) < 0.01

    def test_invalid_range(self) -> None:
        with pytest.raises(ValueError, match="low must be"):
            Uniform(low=5.0, high=2.0)


class TestCategorical:
    def test_mode(self) -> None:
        d = Categorical({"dog": 0.7, "cat": 0.2, "fish": 0.1})
        assert d.mode() == "dog"

    def test_prob(self) -> None:
        d = Categorical({"a": 0.6, "b": 0.4})
        assert abs(d.prob("a") - 0.6) < 0.01
        assert d.prob("z") == 0.0

    def test_sample_proportions(self) -> None:
        d = Categorical({"a": 0.8, "b": 0.2})
        samples = d.sample(10000, seed=42)
        a_frac = np.sum(samples == "a") / len(samples)
        assert abs(a_frac - 0.8) < 0.03

    def test_no_numeric_mean(self) -> None:
        d = Categorical({"a": 0.5, "b": 0.5})
        with pytest.raises(TypeError):
            d.mean()

    def test_empty(self) -> None:
        with pytest.raises(ValueError, match="not be empty"):
            Categorical({})

    def test_bad_sum(self) -> None:
        with pytest.raises(ValueError, match="sum to"):
            Categorical({"a": 0.1, "b": 0.1})


class TestEmpirical:
    def test_from_samples(self) -> None:
        data = np.array([1.0, 2.0, 3.0, 4.0, 5.0])
        d = Empirical(data)
        assert d.mean() == 3.0

    def test_resample(self) -> None:
        data = np.array([1.0, 2.0, 3.0])
        d = Empirical(data)
        samples = d.sample(10000, seed=42)
        # All samples should be from original data
        assert set(np.unique(samples)).issubset({1.0, 2.0, 3.0})

    def test_empty(self) -> None:
        with pytest.raises(ValueError, match="not be empty"):
            Empirical(np.array([]))


class TestPropagate:
    def test_square_normal(self) -> None:
        """Propagate x^2 through N(0,1). E[X^2] = Var(X) = 1.0 for standard normal."""
        d = Normal(mean=0.0, std=1.0)
        result = propagate(lambda x: x**2, d, n_samples=50000, seed=42)
        assert abs(result.mean() - 1.0) < 0.05

    def test_linear_preserves_mean(self) -> None:
        """Propagate 2x+3 through N(5, 1). E[2X+3] = 13."""
        d = Normal(mean=5.0, std=1.0)
        result = propagate(lambda x: 2 * x + 3, d, n_samples=10000, seed=42)
        assert abs(result.mean() - 13.0) < 0.1

    def test_returns_empirical(self) -> None:
        d = Uniform(low=0.0, high=1.0)
        result = propagate(lambda x: x, d, n_samples=100)
        assert isinstance(result, Empirical)
