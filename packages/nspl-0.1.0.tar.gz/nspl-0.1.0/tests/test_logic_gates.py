"""Unit tests for NSPL logic gates."""

import pytest

from nspl.core.logic_gates import AND, IMPLIES, NOT, OR, WEIGHTED_AND, XOR

# ── Hard mode: exact boolean ──────────────────────────────────────────


class TestANDHard:
    def test_tt(self) -> None:
        assert AND(True, True, mode="hard") == 1.0

    def test_tf(self) -> None:
        assert AND(True, False, mode="hard") == 0.0

    def test_ff(self) -> None:
        assert AND(False, False, mode="hard") == 0.0

    def test_nary(self) -> None:
        assert AND(True, True, True, True, mode="hard") == 1.0
        assert AND(True, True, False, True, mode="hard") == 0.0


class TestORHard:
    def test_tf(self) -> None:
        assert OR(True, False, mode="hard") == 1.0

    def test_ff(self) -> None:
        assert OR(False, False, mode="hard") == 0.0

    def test_tt(self) -> None:
        assert OR(True, True, mode="hard") == 1.0

    def test_nary(self) -> None:
        assert OR(False, False, False, True, mode="hard") == 1.0
        assert OR(False, False, False, False, mode="hard") == 0.0


class TestNOTHard:
    def test_true(self) -> None:
        assert NOT(True, mode="hard") == 0.0

    def test_false(self) -> None:
        assert NOT(False, mode="hard") == 1.0


class TestXORHard:
    def test_tf(self) -> None:
        assert XOR(True, False, mode="hard") == 1.0

    def test_tt(self) -> None:
        assert XOR(True, True, mode="hard") == 0.0

    def test_ff(self) -> None:
        assert XOR(False, False, mode="hard") == 0.0

    def test_parity(self) -> None:
        assert XOR(True, True, True, mode="hard") == 1.0  # odd count
        assert XOR(True, True, False, mode="hard") == 0.0  # even count


class TestIMPLIESHard:
    def test_tf(self) -> None:
        assert IMPLIES(True, False, mode="hard") == 0.0

    def test_ft(self) -> None:
        assert IMPLIES(False, True, mode="hard") == 1.0

    def test_ff(self) -> None:
        assert IMPLIES(False, False, mode="hard") == 1.0

    def test_tt(self) -> None:
        assert IMPLIES(True, True, mode="hard") == 1.0


# ── Soft mode: fuzzy values ───────────────────────────────────────────


class TestANDSoft:
    def test_high_inputs(self) -> None:
        assert AND(0.9, 0.9) > 0.7

    def test_one_low(self) -> None:
        assert AND(0.1, 0.9) <= 0.35  # product t-norm: sqrt(0.1*0.9) ≈ 0.3

    def test_both_low(self) -> None:
        assert AND(0.1, 0.1) < 0.2

    def test_nary_high(self) -> None:
        assert AND(0.9, 0.9, 0.9, 0.9) > 0.5


class TestORSoft:
    def test_one_high(self) -> None:
        assert OR(0.1, 0.9) > 0.7

    def test_both_low(self) -> None:
        assert OR(0.1, 0.1) < 0.5

    def test_both_high(self) -> None:
        assert OR(0.9, 0.9) > 0.7


class TestNOTSoft:
    def test_high(self) -> None:
        assert NOT(0.9) < 0.2

    def test_low(self) -> None:
        assert NOT(0.1) > 0.8

    def test_exact_complement(self) -> None:
        assert NOT(0.7) == pytest.approx(0.3)


class TestXORSoft:
    def test_different(self) -> None:
        # One high, one low -> high XOR
        assert XOR(0.9, 0.1) > 0.5

    def test_same_high(self) -> None:
        # Both high -> low XOR
        assert XOR(0.9, 0.9) < 0.3

    def test_same_low(self) -> None:
        assert XOR(0.1, 0.1) < 0.3


# ── WEIGHTED_AND ──────────────────────────────────────────────────────


class TestWEIGHTEDAND:
    def test_equal_weights(self) -> None:
        r = WEIGHTED_AND([0.9, 0.9], [1.0, 1.0])
        assert r > 0.7

    def test_extreme_weights(self) -> None:
        # Weight only the second input
        r1 = WEIGHTED_AND([0.1, 0.9], [0.0, 1.0])
        r2 = WEIGHTED_AND([0.9, 0.1], [0.0, 1.0])
        # Second input dominates
        assert r1 > r2

    def test_hard_mode(self) -> None:
        assert WEIGHTED_AND([0.8, 0.8], [1.0, 1.0], mode="hard") == 1.0
        assert WEIGHTED_AND([0.2, 0.2], [1.0, 1.0], mode="hard") == 0.0


# ── Edge cases ────────────────────────────────────────────────────────


class TestEdgeCases:
    def test_empty_and(self) -> None:
        with pytest.raises(ValueError, match="at least one input"):
            AND()

    def test_empty_or(self) -> None:
        with pytest.raises(ValueError, match="at least one input"):
            OR()

    def test_empty_xor(self) -> None:
        with pytest.raises(ValueError, match="at least one input"):
            XOR()

    def test_empty_weighted(self) -> None:
        with pytest.raises(ValueError, match="at least one input"):
            WEIGHTED_AND([], [])

    def test_nan_input(self) -> None:
        with pytest.raises(ValueError, match="NaN"):
            AND(float("nan"), 0.5)

    def test_single_input_and(self) -> None:
        assert AND(True, mode="hard") == 1.0
        assert AND(0.9) > 0.5

    def test_weight_length_mismatch(self) -> None:
        with pytest.raises(ValueError, match="weights"):
            AND(0.5, 0.5, weights=[1.0])

    def test_weighted_and_length_mismatch(self) -> None:
        with pytest.raises(ValueError, match="weights"):
            WEIGHTED_AND([0.5, 0.5], [1.0])
