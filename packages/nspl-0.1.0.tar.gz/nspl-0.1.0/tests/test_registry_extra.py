"""Extra registry tests for schema extraction coverage."""

from nspl.actions import ActionRegistry, action, preconditions


@action
class TypedAction:
    """Action with typed init params."""

    def __init__(self, name: str, count: int, ratio: float, flag: bool) -> None:
        self.name = name
        self.count = count
        self.ratio = ratio
        self.flag = flag

    @preconditions
    def check(self, ctx: object) -> bool:
        return True

    def execute(self, ctx: object) -> str:
        return "done"


@action
class AnnotatedAction:
    """Action with class-level annotations (no __init__)."""

    name: str
    value: int

    @preconditions
    def check(self, ctx: object) -> bool:
        return True

    def execute(self, ctx: object) -> str:
        return "done"


class TestSchemaExtraction:
    def test_typed_params(self) -> None:
        reg = ActionRegistry()
        reg.register("typed", TypedAction)
        schemas = reg.to_tool_schemas()
        assert len(schemas) == 1
        props = schemas[0]["parameters"]["properties"]
        assert props["name"]["type"] == "string"
        assert props["count"]["type"] == "integer"
        assert props["ratio"]["type"] == "number"
        assert props["flag"]["type"] == "boolean"

    def test_annotation_fallback(self) -> None:
        reg = ActionRegistry()
        reg.register("annotated", AnnotatedAction)
        schemas = reg.to_tool_schemas()
        props = schemas[0]["parameters"]["properties"]
        assert "name" in props
        assert "value" in props

    def test_multiple_actions(self) -> None:
        reg = ActionRegistry()
        reg.register("a", TypedAction)
        reg.register("b", AnnotatedAction)
        assert len(reg.to_tool_schemas()) == 2
        assert set(reg.list_actions()) == {"a", "b"}

    def test_description_from_docstring(self) -> None:
        reg = ActionRegistry()
        reg.register("typed", TypedAction)
        schemas = reg.to_tool_schemas()
        assert "typed" in schemas[0]["description"].lower() or "Action" in schemas[0]["description"]


class TestEnsembleWeighted:
    def test_weighted_strategy(self) -> None:
        from nspl.guards.detectors import DetectorResult
        from nspl.guards.ensemble import EnsembleDetector

        class HighScore:
            def detect(self, text: str) -> DetectorResult:
                return DetectorResult(triggered=False, detector_name="high", score=0.8)

        class LowScore:
            def detect(self, text: str) -> DetectorResult:
                return DetectorResult(triggered=False, detector_name="low", score=0.2)

        e = EnsembleDetector(
            [("high", HighScore(), 2.0), ("low", LowScore(), 1.0)],
            strategy="weighted",
            threshold=0.5,
        )
        r = e.detect("test")
        assert r.triggered  # weighted avg = (0.8*2 + 0.2*1)/3 = 0.6 > 0.5

    def test_empty_detectors(self) -> None:
        from nspl.guards.ensemble import EnsembleDetector

        e = EnsembleDetector([], strategy="any")
        r = e.detect("test")
        assert not r.triggered
        assert "No detectors" in r.detail
