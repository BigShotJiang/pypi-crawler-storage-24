"""Extra LangChain adapter tests."""

import json
from unittest.mock import MagicMock

from nspl.actions import action, preconditions
from nspl.integrations.langchain import NSPLTool


@action
class LCAction:
    """LangChain test action."""

    def __init__(self, msg: str) -> None:
        self.msg = msg

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> str:
        return f"result: {self.msg}"


class TestNSPLToolRun:
    def test_run_with_kwargs(self) -> None:
        ctx = MagicMock()
        tool = NSPLTool("test", LCAction, ctx)
        result = tool.run(msg="hello")
        data = json.loads(result)
        assert data["success"] is True

    def test_call_delegates_to_run(self) -> None:
        ctx = MagicMock()
        tool = NSPLTool("test", LCAction, ctx)
        result = tool(msg="world")
        data = json.loads(result)
        assert data["success"] is True

    def test_structured_tool_run(self) -> None:
        ctx = MagicMock()
        tool = NSPLTool("test", LCAction, ctx)
        result = tool._run('{"msg": "json input"}')
        data = json.loads(result)
        assert data["success"] is True

    def test_structured_tool_plain_string(self) -> None:
        ctx = MagicMock()
        tool = NSPLTool("test", LCAction, ctx)
        # Non-JSON string falls back to {"input": value} which fails on LCAction
        # but the _run method itself handles it
        try:
            tool._run("not json")
        except TypeError:
            pass  # expected: LCAction doesn't accept 'input' kwarg

    def test_is_single_input(self) -> None:
        ctx = MagicMock()
        tool = NSPLTool("test", LCAction, ctx)
        assert not tool.is_single_input

    def test_schema_has_required(self) -> None:
        ctx = MagicMock()
        tool = NSPLTool("test", LCAction, ctx)
        assert "required" in tool.args_schema
        assert "msg" in tool.args_schema["required"]
