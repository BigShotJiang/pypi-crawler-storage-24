"""Additional tests for reasoning pipeline to increase coverage."""

from nspl.reasoning.pipeline import PipelineConfig, run_pipeline


class TestPipelineEdgeCases:
    def test_stage_error_message(self) -> None:
        def bad(x: int) -> int:
            raise ValueError("test error")

        r = run_pipeline([("bad", bad)], initial_input=1)
        assert r.aborted
        assert "test error" in (r.abort_reason or "")

    def test_three_stages(self) -> None:
        r = run_pipeline([
            ("a", lambda x: x + 1),
            ("b", lambda x: x * 2),
            ("c", lambda x: x - 3),
        ], initial_input=5)
        assert r.output == 9  # (5+1)*2 - 3
        assert len(r.completed_stages) == 3

    def test_trace_has_timestamps(self) -> None:
        r = run_pipeline([("a", lambda x: x)], initial_input=1)
        assert r.trace.started_at
        assert r.trace.finished_at

    def test_none_initial_input(self) -> None:
        r = run_pipeline([("a", lambda x: "got none" if x is None else "got value")])
        assert r.output == "got none"

    def test_stage_output_preview_in_trace(self) -> None:
        r = run_pipeline([("echo", lambda x: "hello world")], initial_input=None)
        assert "hello" in r.trace.stages[0].output_preview

    def test_retry_then_fail(self) -> None:
        r = run_pipeline(
            [("fail", lambda x: (_ for _ in ()).throw(RuntimeError("always")))],
            initial_input=1,
            config=PipelineConfig(max_retries=1),
        )
        assert r.aborted

    def test_total_duration(self) -> None:
        r = run_pipeline([("a", lambda x: x)], initial_input=1)
        assert r.total_duration_ms >= 0

    def test_multiple_retries_succeed(self) -> None:
        state = {"calls": 0}

        def flaky(x: int) -> int:
            state["calls"] += 1
            if state["calls"] < 3:
                raise RuntimeError("not yet")
            return x * 10

        r = run_pipeline(
            [("flaky", flaky)],
            initial_input=5,
            config=PipelineConfig(max_retries=5),
        )
        assert r.output == 50


class TestPipelineIntegration:
    def test_anthropic_handle_tool_use(self) -> None:
        """Test anthropic handle_tool_use with mock."""
        from unittest.mock import MagicMock

        from nspl.actions import ActionRegistry, action, preconditions

        @action
        class TestAction:
            def __init__(self, msg: str = "hi") -> None:
                self.msg = msg

            @preconditions
            def check(self, ctx: MagicMock) -> bool:
                return True

            def execute(self, ctx: MagicMock) -> str:
                return f"done: {self.msg}"

        from nspl.integrations.anthropic import handle_tool_use

        reg = ActionRegistry()
        reg.register("testaction", TestAction)
        result = handle_tool_use(
            {"name": "testaction", "input": {"msg": "hello"}},
            reg, MagicMock(),
        )
        assert result.success
