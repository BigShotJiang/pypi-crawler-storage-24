"""Test MCP server helper functions directly."""


from nspl.integrations.mcp_server import _get_input_guard, _get_output_guard, _get_registry


class TestMCPHelpers:
    def test_get_input_guard(self) -> None:
        guard = _get_input_guard()
        assert guard is not None
        v = guard.check("Hello")
        assert v.allowed

    def test_get_output_guard(self) -> None:
        guard = _get_output_guard()
        assert guard is not None
        v = guard.check("Safe text")
        assert v.allowed

    def test_get_registry(self) -> None:
        reg = _get_registry()
        assert reg is not None
        assert hasattr(reg, "register")

    def test_input_guard_cached(self) -> None:
        g1 = _get_input_guard()
        g2 = _get_input_guard()
        assert g1 is g2

    def test_output_guard_cached(self) -> None:
        g1 = _get_output_guard()
        g2 = _get_output_guard()
        assert g1 is g2
