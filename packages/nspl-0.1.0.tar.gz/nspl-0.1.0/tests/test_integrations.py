"""Tests for provider integrations (mocked, no API calls)."""

from unittest.mock import MagicMock

from nspl.actions import ActionRegistry, action, preconditions
from nspl.integrations.anthropic import AnthropicAdapter
from nspl.integrations.anthropic import nspl_tools as anthropic_tools
from nspl.integrations.openai import OpenAIAdapter
from nspl.integrations.openai import nspl_tools as openai_tools


@action
class SimpleAction:
    """A simple test action."""

    def __init__(self, message: str) -> None:
        self.message = message

    @preconditions
    def check(self, ctx: MagicMock) -> bool:
        return True

    def execute(self, ctx: MagicMock) -> str:
        return f"executed: {self.message}"


class TestAnthropicAdapter:
    def test_schema_format(self) -> None:
        tools = anthropic_tools([SimpleAction])
        assert len(tools) == 1
        t = tools[0]
        assert "name" in t
        assert "description" in t
        assert "input_schema" in t
        assert t["input_schema"]["type"] == "object"

    def test_parse_tool_call(self) -> None:
        adapter = AnthropicAdapter()
        name, params = adapter.parse_tool_call({
            "type": "tool_use",
            "name": "simpleaction",
            "input": {"message": "hello"},
        })
        assert name == "simpleaction"
        assert params == {"message": "hello"}

    def test_format_success(self) -> None:
        adapter = AnthropicAdapter()
        mock_result = MagicMock(success=True, result="done")
        fmt = adapter.format_tool_result("test", mock_result)
        assert fmt["is_error"] is False

    def test_format_error(self) -> None:
        adapter = AnthropicAdapter()
        mock_result = MagicMock(success=False, error="bad input")
        fmt = adapter.format_tool_result("test", mock_result)
        assert fmt["is_error"] is True


class TestOpenAIAdapter:
    def test_schema_format(self) -> None:
        tools = openai_tools([SimpleAction])
        assert len(tools) == 1
        t = tools[0]
        assert t["type"] == "function"
        assert "function" in t
        assert "name" in t["function"]
        assert "parameters" in t["function"]

    def test_parse_tool_call(self) -> None:
        adapter = OpenAIAdapter()
        name, params = adapter.parse_tool_call({
            "function": {"name": "simpleaction", "arguments": '{"message": "hi"}'},
        })
        assert name == "simpleaction"
        assert params == {"message": "hi"}

    def test_format_result(self) -> None:
        adapter = OpenAIAdapter()
        mock_result = MagicMock(success=True, result="ok")
        fmt = adapter.format_tool_result("test", mock_result)
        assert fmt["role"] == "tool"


class TestEndToEnd:
    def test_anthropic_roundtrip(self) -> None:
        reg = ActionRegistry()
        reg.register("simpleaction", SimpleAction)
        tools = AnthropicAdapter().to_tool_definitions(reg)
        assert len(tools) == 1

        # Simulate tool call
        adapter = AnthropicAdapter()
        name, params = adapter.parse_tool_call({
            "name": "simpleaction",
            "input": {"message": "test"},
        })
        cls = reg.get(name)
        instance = cls(**params)
        result = instance.safe_execute(MagicMock())
        assert result.success is True
