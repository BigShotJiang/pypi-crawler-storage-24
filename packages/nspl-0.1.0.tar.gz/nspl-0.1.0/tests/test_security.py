"""Security tests: verify bypass prevention and input validation."""

import json

import pytest

from nspl.actions import action, preconditions, safety_checks
from nspl.integrations.openai import OpenAIAdapter

# ── Bypass prevention ────────────────────────────────────────────────


@action
class GuardedAction:
    """Action with guarded execute."""

    def __init__(self, value: str = "test") -> None:
        self.value = value

    @preconditions
    def check(self, ctx: object) -> bool:
        return True

    @safety_checks
    def safety(self, ctx: object) -> bool:
        return True

    def execute(self, ctx: object) -> str:
        return f"executed: {self.value}"


class TestBypassPrevention:
    def test_direct_execute_blocked(self) -> None:
        """Calling execute() directly must raise RuntimeError."""
        a = GuardedAction("secret")
        with pytest.raises(RuntimeError, match="Direct execute"):
            a.execute(None)

    def test_safe_execute_works(self) -> None:
        """safe_execute() must still work normally."""
        a = GuardedAction("hello")
        result = a.safe_execute(None)
        assert result.success is True
        assert result.result == "executed: hello"

    def test_verified_flag_reset_after_success(self) -> None:
        """_nspl_verified must be False after safe_execute completes."""
        a = GuardedAction("test")
        a.safe_execute(None)
        assert not getattr(a, "_nspl_verified", True)

    def test_verified_flag_reset_after_failure(self) -> None:
        """_nspl_verified must be False even if execute raises."""

        @action
        class FailAction:
            @preconditions
            def check(self, ctx: object) -> bool:
                return True

            def execute(self, ctx: object) -> str:
                raise ValueError("boom")

        a = FailAction()
        result = a.safe_execute(None)
        assert result.success is False
        assert not getattr(a, "_nspl_verified", True)


# ── Input validation ─────────────────────────────────────────────────


class TestOpenAIMalformedJSON:
    def test_malformed_json_raises(self) -> None:
        """Malformed JSON in OpenAI arguments must raise ValueError."""
        adapter = OpenAIAdapter()
        with pytest.raises(ValueError, match="Malformed JSON"):
            adapter.parse_tool_call({
                "function": {"name": "test", "arguments": "{invalid json}"},
            })

    def test_valid_json_works(self) -> None:
        adapter = OpenAIAdapter()
        name, params = adapter.parse_tool_call({
            "function": {
                "name": "test",
                "arguments": json.dumps({"key": "value"}),
            },
        })
        assert name == "test"
        assert params == {"key": "value"}


# ── Audit trail sanitization ─────────────────────────────────────────


class TestAuditSanitization:
    def test_exception_detail_truncated(self) -> None:
        """Long exception messages must be truncated in audit trail."""

        @action
        class LongErrorAction:
            @preconditions
            def check(self, ctx: object) -> bool:
                return True

            def execute(self, ctx: object) -> str:
                raise ValueError("x" * 500)

        a = LongErrorAction()
        result = a.safe_execute(None)
        assert result.success is False
        # Find the execution audit entry
        exec_entries = [e for e in result.audit_trail if e.stage == "execution"]
        assert len(exec_entries) == 1
        # Detail should be truncated
        assert len(exec_entries[0].detail) <= 220  # type + ": " + 200 chars
