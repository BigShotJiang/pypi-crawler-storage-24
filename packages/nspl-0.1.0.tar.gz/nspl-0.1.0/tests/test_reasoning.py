"""Tests for reasoning pipelines."""

from nspl.core.types import UncertainValue
from nspl.reasoning import PipelineConfig, PipelineResult, run_pipeline


class TestSimplePipeline:
    def test_two_stages(self) -> None:
        result: PipelineResult = run_pipeline([
            ("double", lambda x: x * 2),
            ("add_one", lambda x: x + 1),
        ], initial_input=5)
        assert result.output == 11
        assert result.aborted is False
        assert result.completed_stages == ["double", "add_one"]

    def test_single_stage(self) -> None:
        result = run_pipeline([("echo", lambda x: x)], initial_input="hello")
        assert result.output == "hello"
        assert len(result.completed_stages) == 1

    def test_empty_pipeline(self) -> None:
        result = run_pipeline([], initial_input=None)
        assert result.aborted is True
        assert "No stages" in (result.abort_reason or "")


class TestTrace:
    def test_trace_completeness(self) -> None:
        result = run_pipeline([
            ("a", lambda x: x),
            ("b", lambda x: x),
        ], initial_input=1)
        assert len(result.trace.stages) == 2
        assert result.trace.stages[0].name == "a"
        assert result.trace.stages[1].name == "b"

    def test_timing_recorded(self) -> None:
        result = run_pipeline([("slow", lambda x: x)], initial_input=1)
        assert result.total_duration_ms > 0
        assert result.trace.stages[0].duration_ms >= 0

    def test_timestamps(self) -> None:
        result = run_pipeline([("a", lambda x: x)], initial_input=1)
        assert result.trace.started_at != ""
        assert result.trace.finished_at != ""


class TestConfidenceGating:
    def test_low_confidence_aborts(self) -> None:
        def low_conf(x: int) -> UncertainValue:
            return UncertainValue(value=x, confidence=0.3)

        result = run_pipeline(
            [("uncertain", low_conf)],
            initial_input=42,
            config=PipelineConfig(stage_threshold=0.5),
        )
        assert result.aborted is True
        assert "below confidence" in (result.abort_reason or "")
        assert result.output is not None  # partial result available

    def test_high_confidence_continues(self) -> None:
        def high_conf(x: int) -> UncertainValue:
            return UncertainValue(value=x * 2, confidence=0.9)

        result = run_pipeline(
            [("confident", high_conf), ("next", lambda x: x)],
            initial_input=5,
            config=PipelineConfig(stage_threshold=0.5),
        )
        assert result.aborted is False
        # The UncertainValue is passed to next stage
        assert len(result.completed_stages) == 2

    def test_gate_records_confidence(self) -> None:
        def with_conf(x: int) -> UncertainValue:
            return UncertainValue(value=x, confidence=0.7)

        result = run_pipeline(
            [("stage", with_conf)],
            initial_input=1,
            config=PipelineConfig(stage_threshold=0.5),
        )
        assert result.trace.stages[0].confidence == 0.7


class TestErrorHandling:
    def test_stage_failure(self) -> None:
        def fail(x: int) -> int:
            raise RuntimeError("boom")

        result = run_pipeline([("bad", fail)], initial_input=1)
        assert result.aborted is True
        assert "boom" in (result.abort_reason or "")

    def test_failure_after_success(self) -> None:
        call_count = 0

        def fail_second(x: int) -> int:
            nonlocal call_count
            call_count += 1
            if call_count > 1:
                raise RuntimeError("second fails")
            return x

        run_pipeline([
            ("ok", lambda x: x),
            ("fail", fail_second),
        ], initial_input=1)
        # First stage passes since fail_second is called second
        # Actually both use different functions
        result2 = run_pipeline([
            ("ok", lambda x: x + 1),
            ("boom", lambda x: 1 / 0),
        ], initial_input=1)
        assert result2.aborted is True
        assert result2.completed_stages == ["ok"]


class TestRetry:
    def test_retry_succeeds(self) -> None:
        attempts = {"count": 0}

        def flaky(x: int) -> int:
            attempts["count"] += 1
            if attempts["count"] < 2:
                raise RuntimeError("transient")
            return x * 2

        result = run_pipeline(
            [("flaky", flaky)],
            initial_input=5,
            config=PipelineConfig(max_retries=2),
        )
        assert result.aborted is False
        assert result.output == 10

    def test_retry_exhausted(self) -> None:
        def always_fail(x: int) -> int:
            raise RuntimeError("permanent")

        result = run_pipeline(
            [("fail", always_fail)],
            initial_input=1,
            config=PipelineConfig(max_retries=2),
        )
        assert result.aborted is True
