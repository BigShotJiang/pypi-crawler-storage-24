from nexo.schemas.resource import Resource, ResourceIdentifier


PRINCIPAL_ORGANIZATION_ROLE_RESOURCE = Resource(
    identifiers=[
        ResourceIdentifier(
            key="principal_organization_role",
            name="Principal Organization Role",
            slug="principal_organization_roles",
        )
    ],
    details=None,
)
