import json
from pydantic import BaseModel, Field, model_validator
from typing import Annotated, Generic, Self, TypeVar
from nexo.enums.organization import (
    OrganizationRelation,
    SimpleOrganizationRelationMixin,
)
from nexo.enums.status import DataStatus as DataStatusEnum, SimpleDataStatusMixin
from nexo.enums.user import UserType
from nexo.schemas.mixins.identity import (
    DataIdentifier,
    IntOrganizationId,
    IntPrincipalId,
    IntUserId,
    BirthDate,
)
from nexo.schemas.mixins.timestamp import ActivationTimestamp
from nexo.schemas.security.enums import DomainMixin, Domain
from nexo.types.datetime import OptDate
from nexo.types.string import OptStr, ManyStrs
from ..enums.api_key import IdentifierType as APIKeyIdentifierType
from ..enums.organization_registration_code import (
    IdentifierType as OrganizationRegistrationCodeIdentifierType,
)
from ..enums.organization_relation import (
    IdentifierType as OrganizationRelationIdentifierType,
)
from ..enums.organization import IdentifierType as OrganizationIdentifierType
from ..enums.user_profile import IdentifierType as UserProfileIdentifierType
from ..enums.user import IdentifierType as UserIdentifierType
from ..mixins.common import IdCard, FullName, BirthPlace
from ..mixins.api_key import APIKey
from ..mixins.organization_registration_code import Code, CurrentUses
from ..mixins.organization_relation import IsBidirectional, Meta
from ..mixins.organization import Key as OrganizationKey, Name as OrganizationName
from ..mixins.user_profile import (
    LeadingTitle,
    FirstName,
    MiddleName,
    LastName,
    EndingTitle,
    AvatarName,
    AvatarUrl,
)
from ..mixins.user import Username, Email, Phone, Password
from ..types.api_key import IdentifierValueType as APIKeyIdentifierValueType
from ..types.organization_registration_code import (
    IdentifierValueType as OrganizationRegistrationCodeIdentifierValueType,
)
from ..types.organization_relation import (
    IdentifierValueType as OrganizationRelationIdentifierValueType,
)
from ..types.organization import IdentifierValueType as OrganizationIdentifierValueType
from ..types.user_profile import IdentifierValueType as UserProfileIdentifierValueType
from ..types.user import IdentifierValueType as UserIdentifierValueType
from .blood_type import (
    OptStandardBloodTypeSchema,
    FullBloodTypeMixin,
)
from .gender import (
    OptStandardGenderSchema,
    FullGenderMixin,
)
from .medical_role import (
    StandardMedicalRoleSchema,
    FullMedicalRoleMixin,
)
from .organization_role import (
    StandardOrganizationRoleSchema,
    FullOrganizationRoleMixin,
)
from .organization_type import (
    StandardOrganizationTypeSchema,
    FullOrganizationTypeMixin,
)
from .system_role import (
    StandardSystemRoleSchema,
    FullSystemRoleMixin,
)
from .user_type import (
    StandardUserTypeSchema,
    FullUserTypeMixin,
)


class APIKeySchema(
    APIKey,
    IntPrincipalId[int],
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    @property
    def _identifiers(
        self,
    ) -> tuple[tuple[APIKeyIdentifierType, APIKeyIdentifierValueType], ...]:
        return (
            (APIKeyIdentifierType.ID, self.id),
            (APIKeyIdentifierType.UUID, str(self.uuid)),
            (APIKeyIdentifierType.PRINCIPAL_ID, self.principal_id),
            (APIKeyIdentifierType.API_KEY, self.api_key),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )


class OrganizationRegistrationCodeSchema(
    CurrentUses,
    Code[str],
    IntOrganizationId[int],
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    @property
    def _identifiers(
        self,
    ) -> tuple[
        tuple[
            OrganizationRegistrationCodeIdentifierType,
            OrganizationRegistrationCodeIdentifierValueType,
        ],
        ...,
    ]:
        return (
            (OrganizationRegistrationCodeIdentifierType.ID, self.id),
            (OrganizationRegistrationCodeIdentifierType.UUID, str(self.uuid)),
            (
                OrganizationRegistrationCodeIdentifierType.ORGANIZATION_ID,
                self.organization_id,
            ),
            (OrganizationRegistrationCodeIdentifierType.CODE, self.code),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )


OptOrganizationRegistrationCodeSchema = OrganizationRegistrationCodeSchema | None


class OrganizationRegistrationCodeSchemaMixin(BaseModel):
    registration_code: Annotated[
        OptOrganizationRegistrationCodeSchema,
        Field(None, description="Organization's registration code"),
    ] = None


class OrganizationSchema(
    OrganizationName[str],
    OrganizationKey[str],
    FullOrganizationTypeMixin[StandardOrganizationTypeSchema],
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    @property
    def _identifiers(
        self,
    ) -> tuple[tuple[OrganizationIdentifierType, OrganizationIdentifierValueType], ...]:
        return (
            (OrganizationIdentifierType.ID, self.id),
            (OrganizationIdentifierType.UUID, str(self.uuid)),
            (OrganizationIdentifierType.KEY, self.key),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )


OptOrganizationSchema = OrganizationSchema | None
OptOrganizationSchemaT = TypeVar("OptOrganizationSchemaT", bound=OptOrganizationSchema)


class OrganizationSchemaMixin(BaseModel, Generic[OptOrganizationSchemaT]):
    organization: Annotated[
        OptOrganizationSchemaT, Field(..., description="Organization")
    ]


class SourceOrganizationSchemaMixin(BaseModel):
    source: Annotated[OrganizationSchema, Field(..., description="Source organization")]


class SourceOrganizationRelationSchema(
    Meta,
    IsBidirectional[bool],
    SimpleOrganizationRelationMixin[OrganizationRelation],
    SourceOrganizationSchemaMixin,
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    pass


class SourceOrganizationRelationsSchemaMixin(BaseModel):
    sources: Annotated[
        list[SourceOrganizationRelationSchema],
        Field(list[SourceOrganizationRelationSchema](), description="Sources"),
    ] = list[SourceOrganizationRelationSchema]()


class TargetOrganizationSchemaMixin(BaseModel):
    target: Annotated[OrganizationSchema, Field(..., description="Target organization")]


class TargetOrganizationRelationSchema(
    Meta,
    IsBidirectional[bool],
    SimpleOrganizationRelationMixin[OrganizationRelation],
    TargetOrganizationSchemaMixin,
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    pass


class TargetOrganizationRelationsSchemaMixin(BaseModel):
    targets: Annotated[
        list[TargetOrganizationRelationSchema],
        Field(list[TargetOrganizationRelationSchema](), description="Targets"),
    ] = list[TargetOrganizationRelationSchema]()


class OrganizationRelationSchema(
    Meta,
    IsBidirectional[bool],
    SimpleOrganizationRelationMixin[OrganizationRelation],
    TargetOrganizationSchemaMixin,
    SourceOrganizationSchemaMixin,
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    @property
    def _identifiers(
        self,
    ) -> tuple[
        tuple[
            OrganizationRelationIdentifierType,
            OrganizationRelationIdentifierValueType | str,
        ],
        ...,
    ]:
        return (
            (OrganizationRelationIdentifierType.ID, self.id),
            (OrganizationRelationIdentifierType.UUID, str(self.uuid)),
            (
                OrganizationRelationIdentifierType.COMPOSITE,
                (self.target.id, self.source.id, self.relation),
            ),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )


class UserProfileSchema(
    AvatarUrl[OptStr],
    AvatarName[str],
    FullBloodTypeMixin[OptStandardBloodTypeSchema],
    FullGenderMixin[OptStandardGenderSchema],
    BirthDate[OptDate],
    BirthPlace[OptStr],
    FullName[str],
    EndingTitle[OptStr],
    LastName[str],
    MiddleName[OptStr],
    FirstName[str],
    LeadingTitle[OptStr],
    IdCard[OptStr],
    IntUserId[int],
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    avatar_url: Annotated[OptStr, Field(None, description="Avatar URL")]

    @property
    def _identifiers(
        self,
    ) -> tuple[
        tuple[
            UserProfileIdentifierType,
            UserProfileIdentifierValueType,
        ],
        ...,
    ]:
        return (
            (UserProfileIdentifierType.ID, self.id),
            (UserProfileIdentifierType.UUID, str(self.uuid)),
            (UserProfileIdentifierType.USER_ID, self.user_id),
            (UserProfileIdentifierType.ID_CARD, self.id_card or ""),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )


OptUserProfileSchema = UserProfileSchema | None


class UserProfileSchemaMixin(BaseModel):
    profile: Annotated[
        OptUserProfileSchema, Field(None, description="User's Profile")
    ] = None


class UserSchema(
    UserProfileSchemaMixin,
    Phone[str],
    Email[str],
    Username[str],
    FullUserTypeMixin[StandardUserTypeSchema],
    SimpleDataStatusMixin[DataStatusEnum],
    ActivationTimestamp,
    DataIdentifier,
):
    @property
    def _identifiers(
        self,
    ) -> tuple[tuple[UserIdentifierType, UserIdentifierValueType], ...]:
        return (
            (UserIdentifierType.ID, self.id),
            (UserIdentifierType.UUID, str(self.uuid)),
            (UserIdentifierType.EMAIL, self.email),
            (UserIdentifierType.USERNAME, self.username),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )


class UserSchemaV0(
    UserProfileSchemaMixin,
    Phone[str],
    Email[str],
    Username[str],
    FullUserTypeMixin[UserType],
    SimpleDataStatusMixin[DataStatusEnum],
    ActivationTimestamp,
    DataIdentifier,
):
    @classmethod
    def from_user_schema(cls, schema: UserSchema) -> Self:
        user_type = UserType(schema.user_type.key)
        dump = schema.model_dump()
        dump["user_type"] = user_type
        return cls.model_validate(dump)

    @property
    def _identifiers(
        self,
    ) -> tuple[tuple[UserIdentifierType, UserIdentifierValueType], ...]:
        return (
            (UserIdentifierType.ID, self.id),
            (UserIdentifierType.UUID, str(self.uuid)),
            (UserIdentifierType.EMAIL, self.email),
            (UserIdentifierType.USERNAME, self.username),
        )

    @property
    def cache_key_identifiers(self) -> ManyStrs:
        return tuple(
            '"identifier": '
            + json.dumps(
                {
                    "type": type.value,
                    "value": value,
                }
            )
            for type, value in self._identifiers
        )


class UserSchemaMixin(BaseModel):
    user: Annotated[UserSchema, Field(..., description="User")]


class UserPasswordSchema(
    Password,
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    pass


class VerifyPasswordSchema(BaseModel):
    is_valid: Annotated[bool, Field(..., description="Whether password is valid")]


class PrincipalMedicalRoleSchema(
    FullMedicalRoleMixin[StandardMedicalRoleSchema],
    IntPrincipalId[int],
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    pass


ListOfPrincipalMedicalRoleSchemas = list[PrincipalMedicalRoleSchema]
OptListOfPrincipalMedicalRoleSchemas = ListOfPrincipalMedicalRoleSchemas | None
OptListOfPrincipalMedicalRoleSchemasT = TypeVar(
    "OptListOfPrincipalMedicalRoleSchemasT", bound=OptListOfPrincipalMedicalRoleSchemas
)


class PrincipalMedicalRolesSchemaMixin(
    BaseModel, Generic[OptListOfPrincipalMedicalRoleSchemasT]
):
    medical_roles: Annotated[
        list[PrincipalMedicalRoleSchema],
        Field(list[PrincipalMedicalRoleSchema](), description="Medical Roles"),
    ] = list[PrincipalMedicalRoleSchema]()


class PrincipalOrganizationRoleSchema(
    FullOrganizationRoleMixin[StandardOrganizationRoleSchema],
    IntPrincipalId[int],
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    pass


class PrincipalOrganizationRolesSchemaMixin(BaseModel):
    organization_roles: Annotated[
        list[PrincipalOrganizationRoleSchema],
        Field(
            list[PrincipalOrganizationRoleSchema](), description="Organization Roles"
        ),
    ] = list[PrincipalOrganizationRoleSchema]()


class PrincipalSystemRoleSchema(
    FullSystemRoleMixin[StandardSystemRoleSchema],
    IntPrincipalId[int],
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    pass


class PrincipalSystemRolesSchemaMixin(BaseModel):
    system_roles: Annotated[
        list[PrincipalSystemRoleSchema],
        Field(list[PrincipalSystemRoleSchema](), description="System Roles"),
    ] = list[PrincipalSystemRoleSchema]()


class PrincipalSchema(
    PrincipalSystemRolesSchemaMixin,
    PrincipalOrganizationRolesSchemaMixin,
    PrincipalMedicalRolesSchemaMixin,
    OrganizationSchemaMixin[OptOrganizationSchema],
    UserSchemaMixin,
    DomainMixin[Domain],
    SimpleDataStatusMixin[DataStatusEnum],
    DataIdentifier,
):
    @model_validator(mode="after")
    def validate_elements(self) -> Self:
        if self.domain is Domain.TENANT:
            if self.organization is None:
                raise ValueError("Organization can not be None for Tenant Principal")
            if not self.organization_roles:
                raise ValueError("Organization Roles must exist for Tenant Principal")
            if len(self.system_roles) > 0:
                raise ValueError("System Roles must be empty for Tenant Principal")
        elif self.domain is Domain.PERSONAL:
            if self.organization is not None:
                raise ValueError("Organization must be None for Personal Principal")
            if len(self.organization_roles) > 0:
                raise ValueError(
                    "Organization Roles must be empty for Personal Principal"
                )
            if len(self.system_roles) > 0:
                raise ValueError("System Roles must be empty for Personal Principal")
        elif self.domain is Domain.SYSTEM:
            if self.organization is not None:
                raise ValueError(
                    "Organization must be None for Personal or System Principal"
                )
            if len(self.organization_roles) > 0:
                raise ValueError(
                    "Organization Roles must be empty for System Principal"
                )
            if not self.system_roles:
                raise ValueError("System Roles must exist for System Principal")
        return self
