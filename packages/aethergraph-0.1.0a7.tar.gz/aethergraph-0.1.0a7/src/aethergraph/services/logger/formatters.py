from __future__ import annotations

import json
import logging
import sys
import time
from typing import Any

from aethergraph.core.graph.graph_refs import GRAPH_INPUTS_NODE_ID


class SafeFormatter(logging.Formatter):
    """
    Text formatter that won't explode if `extra` keys are missing.
    Use %(run_id)s etc. in format strings without having to always bind them.
    """

    def format(self, record: logging.LogRecord) -> str:
        # Provide default values for our known keys so %()s doesn't KeyError
        for k in (
            "run_id",
            "session_id",
            "node_id",
            "graph_id",
            "agent_id",
            "app_id",
            "trace_id",
            "span_id",
            "user_id",
            "org_id",
            "client_id",
        ):
            if not hasattr(record, k):
                setattr(record, k, "-")

        # Collapse noisy sentinel for graph inputs
        if getattr(record, "node_id", None) == GRAPH_INPUTS_NODE_ID:
            record.node_id = "-"

        # First do the normal formatting
        s = super().format(record)

        # Then strip any "field=-" tokens for missing context,
        # assuming your patterns use "run=%(run_id)s", "node=%(node_id)s", etc.
        for prefix, attr in (
            ("run", "run_id"),
            ("node", "node_id"),
            ("graph", "graph_id"),
            ("agent", "agent_id"),
        ):
            val = getattr(record, attr, None)
            if not val or val == "-":
                token = f" {prefix}=-"
                s = s.replace(token, "")

        return s


class JsonFormatter(logging.Formatter):
    """
    Structured JSON logs; safe for missing extras.
    """

    def __init__(self, *, include_timestamp: bool = True):
        super().__init__()
        self.include_timestamp = include_timestamp

    def format(self, record: logging.LogRecord) -> str:
        payload: dict[str, Any] = {
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if self.include_timestamp:
            payload["time"] = time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(record.created))
        # standard attrs we care about
        payload.update(
            {
                "run_id": getattr(record, "run_id", None),
                "node_id": getattr(record, "node_id", None),
                "graph_id": getattr(record, "graph_id", None),
                "agent_id": getattr(record, "agent_id", None),
                "session_id": getattr(record, "session_id", None),
                "app_id": getattr(record, "app_id", None),
                "trace_id": getattr(record, "trace_id", None),
                "span_id": getattr(record, "span_id", None),
                "user_id": getattr(record, "user_id", None),
                "org_id": getattr(record, "org_id", None),
                "client_id": getattr(record, "client_id", None),
            }
        )
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps({k: v for k, v in payload.items() if v is not None}, ensure_ascii=False)


class ColorFormatter(SafeFormatter):
    """
    Console/file formatter that adds ANSI color only to:
      - level name (INFO/WARNING/ERROR/...)
      - run_id / node_id / graph_id tokens

    Everything else stays uncolored.
    """

    RESET = "\033[0m"
    LEVEL_COLORS = {
        "DEBUG": "\033[36m",  # cyan
        "INFO": "\033[32m",  # green
        "WARNING": "\033[33m",  # yellow
        "ERROR": "\033[31m",  # red
        "CRITICAL": "\033[41m",  # red background
    }

    ID_COLOR = "\033[35m"  # magenta for IDs

    def __init__(self, fmt: str, datefmt: str | None = None, use_color: bool | None = None):
        super().__init__(fmt, datefmt=datefmt)
        # auto-disable color if not a TTY unless explicitly forced
        if use_color is None:
            use_color = sys.stderr.isatty()
        self.use_color = use_color

    def format(self, record: logging.LogRecord) -> str:
        # First let SafeFormatter fill in missing run_id/node_id/etc
        base = super().format(record)

        if not self.use_color:
            return base

        reset = self.RESET
        level = record.levelname
        level_color = self.LEVEL_COLORS.get(level, "")

        # 1) Color only the level name token (first occurrence)
        if level_color:
            base = base.replace(level, f"{level_color}{level}{reset}", 1)

        # 2) Color run_id / node_id / graph_id tokens like `run=...`, `node=...`, `graph=...`
        id_color = self.ID_COLOR
        for key in ("run_id", "node_id", "graph_id"):
            val = getattr(record, key, None)
            if val and val != "-":
                token = f"{key}={val}"
                colored = f"{id_color}{token}{reset}"
                base = base.replace(token, colored)

        return base
