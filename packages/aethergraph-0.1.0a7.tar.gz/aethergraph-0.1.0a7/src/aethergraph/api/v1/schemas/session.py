from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field  # type: ignore

from aethergraph.core.runtime.run_types import SessionKind

from .runs import RunSummary


class Session(BaseModel):
    session_id: str
    kind: SessionKind
    title: str | None = None
    user_id: str | None = None
    org_id: str | None = None
    source: str = "webui"
    external_ref: str | None = None
    created_at: datetime
    updated_at: datetime
    artifact_count: int = 0
    last_artifact_at: datetime | None = None


class SessionCreateRequest(BaseModel):
    kind: SessionKind
    title: str | None = None
    external_ref: str | None = None


class SessionListResponse(BaseModel):
    items: list[Session]
    next_cursor: str | None = None


class SessionRunsResponse(BaseModel):
    items: list[RunSummary]


class SessionChatFile(BaseModel):
    artifact_id: str | None = None
    id: str | None = None
    url: str | None = None
    name: str | None = None
    mimetype: str | None = None
    size: int | None = None
    uri: str | None = None
    renderer: Literal["image", "download", "vega", "plotly"] | None = None

    class Config:
        extra = "allow"


class SessionChatEvent(BaseModel):
    id: str
    session_id: str
    type: str
    text: str | None
    buttons: list[dict[str, Any]] = Field(default_factory=list)
    file: SessionChatFile | None = None
    files: list[SessionChatFile] | None = None
    attachments: list[SessionChatFile] | None = None
    meta: dict[str, Any] = Field(default_factory=dict)
    ts: float
    agent_id: str | None = None
    upsert_key: str | None = None
    rich: dict[str, Any] | None = None


class SessionUpdateRequest(BaseModel):
    title: str | None = None
    external_ref: str | None = None
