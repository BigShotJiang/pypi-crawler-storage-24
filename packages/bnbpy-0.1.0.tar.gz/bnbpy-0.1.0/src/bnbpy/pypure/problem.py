import copy
from typing import Optional, Union

from bnbpy.pypure.solution import Solution
from bnbpy.pypure.status import OptStatus


class Problem:
    """Abstraction for an optimization problem"""

    solution: Solution
    """Solution of the (sub)problem (if any)"""

    def __init__(self) -> None:
        self.solution = Solution()

    def __del__(self) -> None:
        self.cleanup()

    def cleanup(self) -> None:
        self.solution = None  # type: ignore

    def calc_bound(self) -> Union[int, float]:
        """Returns a lower bound of the (sub)problem."""
        raise NotImplementedError('Must implement `calc_bound` method')

    def is_feasible(self) -> bool:
        """
        Returns `True` if the problem in its complete
        form has a feasible solution.
        """
        raise NotImplementedError('Must implement `is_feasible` method')

    def branch(self) -> list['Problem']:
        """Generates child nodes (problems) by branching."""
        raise NotImplementedError('Must implement `branch` method')

    @property
    def lb(self) -> Union[int, float]:
        return self.get_lb()

    def get_lb(self) -> Union[int, float]:
        """Get lower bound from solution."""
        return self.solution.lb

    def compute_bound(self) -> None:
        """
        Computes the lower bound of the (sub)problem via `calc_bound`
        and sets it as the value of the attribute `lb`
        of the instance and solution.
        """
        lb = self.calc_bound()
        self.solution.set_lb(lb)

    def check_feasible(self) -> bool:
        """
        Verifies is the (sub)problem is feasible considering the
        complete formulation by calling `is_feasible` and uses the
        result to set the status of the solution.

        Returns
        -------
        bool
            Feasibility check
        """
        feas = self.is_feasible()
        if feas:
            self.solution.set_feasible()
        else:
            self.solution.set_infeasible()
        return feas

    def set_solution(self, solution: Solution) -> None:
        """Overwrites problem solution and computes lower bound in case
        if is not yet solved

        Parameters
        ----------
        solution : Solution
            New solution to overwrite current
        """
        self.solution = solution
        if self.solution.status == OptStatus.NO_SOLUTION:
            self.compute_bound()

    def warmstart(self) -> Optional['Problem']:  # noqa: PLR6301
        """This is a white label for warmstart
        If the problem has a warmstart function that returns a valid
        solution, it will be used at the begining of the search tree.

        Returns
        -------
        Optional[Problem]
            Problem with solution, or None (in case not implemented)
        """
        return None

    def copy(self, deep: bool = True) -> 'Problem':
        if deep:
            return copy.deepcopy(self)
        return copy.copy(self)
