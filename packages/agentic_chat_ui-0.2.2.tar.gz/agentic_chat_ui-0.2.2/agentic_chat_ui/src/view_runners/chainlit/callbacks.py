from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Dict, Generic, Optional

import chainlit as cl
from agentic_chat_ui.src.constants import TCChainlitCallBackRegistrar
from agentic_chat_ui.src.settings import AuthChainlitCallBackRegistrarSettings
from agentic_chat_ui.src.utils import hash_password

if TYPE_CHECKING:
    from agentic_chat_ui.src.view_runners.chainlit.runner import ChainlitViewRunner

logger = logging.getLogger(__name__)


class ChainlitCallBackRegistrar(ABC, Generic[TCChainlitCallBackRegistrar]):

    def __init__(self, config: TCChainlitCallBackRegistrar, chainlit_api: ChainlitViewRunner):
        self.config = config
        self.chainlit_api = chainlit_api

    @abstractmethod
    def register(self) -> None:
        raise NotImplementedError()


class AuthChainlitCallBackRegistrar(ChainlitCallBackRegistrar[AuthChainlitCallBackRegistrarSettings]):
    def __init__(self, config: AuthChainlitCallBackRegistrarSettings, chainlit_api: ChainlitViewRunner):
        super().__init__(config, chainlit_api)
        self.users = self._load_users_from_config()

    def _load_users_from_config(self) -> Dict[str, Dict[str, str]]:
        """
        Load users from config.
        Returns:
            {
                "admin": {"password_hash": "...", "role": "user"}
            }
        """
        raw = self.config.users.get_secret_value()
        users: Dict[str, Dict[str, str]] = {}
        if not raw:
            logger.warning("CHAINLIT_USERS is not set")
            return users
        for entry in raw.split(","):
            try:
                username, password = entry.split(":", 1)
                users[username] = {
                    "password_hash": hash_password(password),
                    "role": "user",
                }
            except ValueError:
                logger.error("Invalid CHAINLIT_USERS entry: '%s'", entry)
        return users

    def register(self) -> None:
        @cl.password_auth_callback
        async def password_auth(
            username: str,
            password: str,
        ) -> Optional[cl.User]:
            user = self.users.get(username)
            if not user:
                return None
            if hash_password(password) != user["password_hash"]:
                return None
            return cl.User(
                identifier=username,
                metadata={
                    "role": user["role"],
                    "provider": "password",
                },
            )

        logger.info("Password auth callback registered")
