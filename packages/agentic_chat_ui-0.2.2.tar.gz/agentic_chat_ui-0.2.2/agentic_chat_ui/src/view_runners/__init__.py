# agentic_chat_ui/views/base.py
import logging
from abc import ABC, abstractmethod
from typing import Any, Generic

from agentic_chat_ui.src.constants import TCViewRunner
from agentic_chat_ui.src.controllers import Controller
from agentic_chat_ui.src.mixins import FromConfigMixin
from agentic_chat_ui.src.utils import load_class

_logger = logging.getLogger(__name__)


class ViewRunner(FromConfigMixin[TCViewRunner], ABC, Generic[TCViewRunner]):
    def __init__(self, config: TCViewRunner) -> None:
        self.config = config
        _logger.info(
            f"Initializing View Runner | class={self.__class__.__name__} | "
            f"controller={config.controller.module_path}"
        )

        self.controller: Controller[Any] = load_class(self.config.controller.module_path).from_config(
            self.config.controller
        )

        _logger.info(
            f"View Runner initialized | class={self.__class__.__name__} | "
            f"controller={type(self.controller).__name__}"
        )

    @abstractmethod
    def run(self) -> None:
        raise NotImplementedError
