from typing import Optional


class AgenticChatUIError(Exception):
    """
    Base exception for all agentic-chat-ui errors.

    All custom exceptions in the project should inherit from this.
    """

    def __init__(self, message: str, *, cause: Optional[Exception] = None) -> None:
        super().__init__(message)
        self.cause = cause


class AgenticChatUIStreamingError(AgenticChatUIError):
    """
    Raised when token streaming fails (agent, API, or transport).
    """
