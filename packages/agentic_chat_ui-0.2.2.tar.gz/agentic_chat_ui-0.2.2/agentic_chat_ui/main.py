import logging

from agentic_chat_ui.src.utils import get_view

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(name)s - %(message)s",
)
logger = logging.getLogger()


if __name__ == "__main__":
    get_view().run()
