from enum import Enum


class CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider(str, Enum):
    AZURE = "azure"
    OPENAI = "openai"

    def __str__(self) -> str:
        return str(self.value)
