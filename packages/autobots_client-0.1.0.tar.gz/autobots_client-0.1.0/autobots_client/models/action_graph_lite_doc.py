from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="ActionGraphLiteDoc")


@_attrs_define
class ActionGraphLiteDoc:
    """
    Attributes:
        field_id (str):
        name (str):
        user_id (str):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        version (float | Unset):  Default: 0.0.
        description (str | Unset):  Default: ''.
        user_manual (str | Unset):  Default: ''.
        is_saved (bool | Unset):  Default: False.
        is_published (bool | Unset):  Default: False.
        shared_with (list[str] | Unset):
        time_saved_per_file (float | None | Unset):  Default: 0.1.
        dollar_cost_per_hour (float | None | Unset):  Default: 50.0.
    """

    field_id: str
    name: str
    user_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    version: float | Unset = 0.0
    description: str | Unset = ""
    user_manual: str | Unset = ""
    is_saved: bool | Unset = False
    is_published: bool | Unset = False
    shared_with: list[str] | Unset = UNSET
    time_saved_per_file: float | None | Unset = 0.1
    dollar_cost_per_hour: float | None | Unset = 50.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        field_id = self.field_id

        name = self.name

        user_id = self.user_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        version = self.version

        description = self.description

        user_manual = self.user_manual

        is_saved = self.is_saved

        is_published = self.is_published

        shared_with: list[str] | Unset = UNSET
        if not isinstance(self.shared_with, Unset):
            shared_with = self.shared_with

        time_saved_per_file: float | None | Unset
        if isinstance(self.time_saved_per_file, Unset):
            time_saved_per_file = UNSET
        else:
            time_saved_per_file = self.time_saved_per_file

        dollar_cost_per_hour: float | None | Unset
        if isinstance(self.dollar_cost_per_hour, Unset):
            dollar_cost_per_hour = UNSET
        else:
            dollar_cost_per_hour = self.dollar_cost_per_hour

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "_id": field_id,
                "name": name,
                "user_id": user_id,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if version is not UNSET:
            field_dict["version"] = version
        if description is not UNSET:
            field_dict["description"] = description
        if user_manual is not UNSET:
            field_dict["user_manual"] = user_manual
        if is_saved is not UNSET:
            field_dict["is_saved"] = is_saved
        if is_published is not UNSET:
            field_dict["is_published"] = is_published
        if shared_with is not UNSET:
            field_dict["shared_with"] = shared_with
        if time_saved_per_file is not UNSET:
            field_dict["time_saved_per_file"] = time_saved_per_file
        if dollar_cost_per_hour is not UNSET:
            field_dict["dollar_cost_per_hour"] = dollar_cost_per_hour

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        field_id = d.pop("_id")

        name = d.pop("name")

        user_id = d.pop("user_id")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        version = d.pop("version", UNSET)

        description = d.pop("description", UNSET)

        user_manual = d.pop("user_manual", UNSET)

        is_saved = d.pop("is_saved", UNSET)

        is_published = d.pop("is_published", UNSET)

        shared_with = cast(list[str], d.pop("shared_with", UNSET))

        def _parse_time_saved_per_file(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        time_saved_per_file = _parse_time_saved_per_file(d.pop("time_saved_per_file", UNSET))

        def _parse_dollar_cost_per_hour(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        dollar_cost_per_hour = _parse_dollar_cost_per_hour(d.pop("dollar_cost_per_hour", UNSET))

        action_graph_lite_doc = cls(
            field_id=field_id,
            name=name,
            user_id=user_id,
            created_at=created_at,
            updated_at=updated_at,
            version=version,
            description=description,
            user_manual=user_manual,
            is_saved=is_saved,
            is_published=is_published,
            shared_with=shared_with,
            time_saved_per_file=time_saved_per_file,
            dollar_cost_per_hour=dollar_cost_per_hour,
        )

        action_graph_lite_doc.additional_properties = d
        return action_graph_lite_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
