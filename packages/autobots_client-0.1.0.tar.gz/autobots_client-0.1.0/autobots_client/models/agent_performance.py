from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="AgentPerformance")


@_attrs_define
class AgentPerformance:
    """Agent performance metrics

    Attributes:
        agent_id (str):
        agent_name (str):
        percentage (float):
        change (float):
        rank (int):
    """

    agent_id: str
    agent_name: str
    percentage: float
    change: float
    rank: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        agent_id = self.agent_id

        agent_name = self.agent_name

        percentage = self.percentage

        change = self.change

        rank = self.rank

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "agent_id": agent_id,
                "agent_name": agent_name,
                "percentage": percentage,
                "change": change,
                "rank": rank,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        agent_id = d.pop("agent_id")

        agent_name = d.pop("agent_name")

        percentage = d.pop("percentage")

        change = d.pop("change")

        rank = d.pop("rank")

        agent_performance = cls(
            agent_id=agent_id,
            agent_name=agent_name,
            percentage=percentage,
            change=change,
            rank=rank,
        )

        agent_performance.additional_properties = d
        return agent_performance

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
