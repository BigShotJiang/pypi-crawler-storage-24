from enum import Enum


class DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider(str, Enum):
    AZURE = "azure"
    OPENAI = "openai"

    def __str__(self) -> str:
        return str(self.value)
