from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="DatastoreMetaDoc")


@_attrs_define
class DatastoreMetaDoc:
    """
    Attributes:
        name (str):
        datastore_id (str):
        user_id (str):
        field_id (str):
        created_at (datetime.datetime | Unset):  Default: isoparse('2026-03-12T15:04:00.855693').
    """

    name: str
    datastore_id: str
    user_id: str
    field_id: str
    created_at: datetime.datetime | Unset = isoparse("2026-03-12T15:04:00.855693")
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        datastore_id = self.datastore_id

        user_id = self.user_id

        field_id = self.field_id

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "datastore_id": datastore_id,
                "user_id": user_id,
                "_id": field_id,
            }
        )
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        datastore_id = d.pop("datastore_id")

        user_id = d.pop("user_id")

        field_id = d.pop("_id")

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        datastore_meta_doc = cls(
            name=name,
            datastore_id=datastore_id,
            user_id=user_id,
            field_id=field_id,
            created_at=created_at,
        )

        datastore_meta_doc.additional_properties = d
        return datastore_meta_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
