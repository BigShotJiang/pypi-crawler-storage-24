from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.file_and_processing_params import FileAndProcessingParams


T = TypeVar("T", bound="FilesAndProcessingParams")


@_attrs_define
class FilesAndProcessingParams:
    """
    Attributes:
        files_and_params (list[FileAndProcessingParams]):
    """

    files_and_params: list[FileAndProcessingParams]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        files_and_params = []
        for files_and_params_item_data in self.files_and_params:
            files_and_params_item = files_and_params_item_data.to_dict()
            files_and_params.append(files_and_params_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "files_and_params": files_and_params,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_and_processing_params import FileAndProcessingParams

        d = dict(src_dict)
        files_and_params = []
        _files_and_params = d.pop("files_and_params")
        for files_and_params_item_data in _files_and_params:
            files_and_params_item = FileAndProcessingParams.from_dict(files_and_params_item_data)

            files_and_params.append(files_and_params_item)

        files_and_processing_params = cls(
            files_and_params=files_and_params,
        )

        files_and_processing_params.additional_properties = d
        return files_and_processing_params

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
