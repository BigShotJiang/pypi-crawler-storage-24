from enum import Enum


class FileObjectPurpose(str, Enum):
    ASSISTANTS = "assistants"
    ASSISTANTS_OUTPUT = "assistants_output"
    BATCH = "batch"
    BATCH_OUTPUT = "batch_output"
    FINE_TUNE = "fine-tune"
    FINE_TUNE_RESULTS = "fine-tune-results"
    USER_DATA = "user_data"
    VISION = "vision"

    def __str__(self) -> str:
        return str(self.value)
