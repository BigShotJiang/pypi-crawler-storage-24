from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.job_status_schema import JobStatusSchema


T = TypeVar("T", bound="FileListResponseSchema")


@_attrs_define
class FileListResponseSchema:
    """
    Attributes:
        total (int):
        limit (int):
        offset (int):
        files (list[JobStatusSchema]):
    """

    total: int
    limit: int
    offset: int
    files: list[JobStatusSchema]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total = self.total

        limit = self.limit

        offset = self.offset

        files = []
        for files_item_data in self.files:
            files_item = files_item_data.to_dict()
            files.append(files_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total": total,
                "limit": limit,
                "offset": offset,
                "files": files,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.job_status_schema import JobStatusSchema

        d = dict(src_dict)
        total = d.pop("total")

        limit = d.pop("limit")

        offset = d.pop("offset")

        files = []
        _files = d.pop("files")
        for files_item_data in _files:
            files_item = JobStatusSchema.from_dict(files_item_data)

            files.append(files_item)

        file_list_response_schema = cls(
            total=total,
            limit=limit,
            offset=offset,
            files=files,
        )

        file_list_response_schema.additional_properties = d
        return file_list_response_schema

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
