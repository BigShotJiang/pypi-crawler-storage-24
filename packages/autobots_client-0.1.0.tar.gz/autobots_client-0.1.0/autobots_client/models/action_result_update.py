from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.event_result_status import EventResultStatus
from ..models.event_type import EventType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.action_doc import ActionDoc
    from ..models.text_obj import TextObj


T = TypeVar("T", bound="ActionResultUpdate")


@_attrs_define
class ActionResultUpdate:
    """Input from User to update Action Result

    Attributes:
        name (None | str | Unset):
        type_ (EventType | None | Unset):
        status (EventResultStatus | None | Unset):
        error_message (None | TextObj | Unset):
        is_saved (bool | None | Unset):
        result (ActionDoc | None | Unset):
        file_url (None | str | Unset):
    """

    name: None | str | Unset = UNSET
    type_: EventType | None | Unset = UNSET
    status: EventResultStatus | None | Unset = UNSET
    error_message: None | TextObj | Unset = UNSET
    is_saved: bool | None | Unset = UNSET
    result: ActionDoc | None | Unset = UNSET
    file_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.action_doc import ActionDoc
        from ..models.text_obj import TextObj

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        type_: None | str | Unset
        if isinstance(self.type_, Unset):
            type_ = UNSET
        elif isinstance(self.type_, EventType):
            type_ = self.type_.value
        else:
            type_ = self.type_

        status: None | str | Unset
        if isinstance(self.status, Unset):
            status = UNSET
        elif isinstance(self.status, EventResultStatus):
            status = self.status.value
        else:
            status = self.status

        error_message: dict[str, Any] | None | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        elif isinstance(self.error_message, TextObj):
            error_message = self.error_message.to_dict()
        else:
            error_message = self.error_message

        is_saved: bool | None | Unset
        if isinstance(self.is_saved, Unset):
            is_saved = UNSET
        else:
            is_saved = self.is_saved

        result: dict[str, Any] | None | Unset
        if isinstance(self.result, Unset):
            result = UNSET
        elif isinstance(self.result, ActionDoc):
            result = self.result.to_dict()
        else:
            result = self.result

        file_url: None | str | Unset
        if isinstance(self.file_url, Unset):
            file_url = UNSET
        else:
            file_url = self.file_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if type_ is not UNSET:
            field_dict["type"] = type_
        if status is not UNSET:
            field_dict["status"] = status
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if is_saved is not UNSET:
            field_dict["is_saved"] = is_saved
        if result is not UNSET:
            field_dict["result"] = result
        if file_url is not UNSET:
            field_dict["file_url"] = file_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_doc import ActionDoc
        from ..models.text_obj import TextObj

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_type_(data: object) -> EventType | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                type_type_0 = EventType(data)

                return type_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EventType | None | Unset, data)

        type_ = _parse_type_(d.pop("type", UNSET))

        def _parse_status(data: object) -> EventResultStatus | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                status_type_0 = EventResultStatus(data)

                return status_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EventResultStatus | None | Unset, data)

        status = _parse_status(d.pop("status", UNSET))

        def _parse_error_message(data: object) -> None | TextObj | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                error_message_type_0 = TextObj.from_dict(data)

                return error_message_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TextObj | Unset, data)

        error_message = _parse_error_message(d.pop("error_message", UNSET))

        def _parse_is_saved(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_saved = _parse_is_saved(d.pop("is_saved", UNSET))

        def _parse_result(data: object) -> ActionDoc | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                result_type_0 = ActionDoc.from_dict(data)

                return result_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ActionDoc | None | Unset, data)

        result = _parse_result(d.pop("result", UNSET))

        def _parse_file_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_url = _parse_file_url(d.pop("file_url", UNSET))

        action_result_update = cls(
            name=name,
            type_=type_,
            status=status,
            error_message=error_message,
            is_saved=is_saved,
            result=result,
            file_url=file_url,
        )

        action_result_update.additional_properties = d
        return action_result_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
