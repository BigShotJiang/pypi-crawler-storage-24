from enum import Enum


class CostConfigType(str, Enum):
    HOURLY_RATE = "hourly_rate"
    INITIAL_INVESTMENT = "initial_investment"
    REVENUE_CONVERSION_RATE = "revenue_conversion_rate"
    TIME_SAVED_RANGES = "time_saved_ranges"

    def __str__(self) -> str:
        return str(self.value)
