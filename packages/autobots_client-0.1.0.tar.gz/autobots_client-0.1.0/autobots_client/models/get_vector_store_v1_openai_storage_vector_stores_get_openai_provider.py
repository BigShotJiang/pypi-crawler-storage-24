from enum import Enum


class GetVectorStoreV1OpenaiStorageVectorStoresGetOpenaiProvider(str, Enum):
    AZURE = "azure"
    OPENAI = "openai"

    def __str__(self) -> str:
        return str(self.value)
