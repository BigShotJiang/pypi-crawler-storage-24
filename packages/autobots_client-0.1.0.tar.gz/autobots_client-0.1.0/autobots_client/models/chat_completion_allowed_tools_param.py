from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.chat_completion_allowed_tools_param_mode import ChatCompletionAllowedToolsParamMode

if TYPE_CHECKING:
    from ..models.chat_completion_allowed_tools_param_tools_item import ChatCompletionAllowedToolsParamToolsItem


T = TypeVar("T", bound="ChatCompletionAllowedToolsParam")


@_attrs_define
class ChatCompletionAllowedToolsParam:
    """Constrains the tools available to the model to a pre-defined set.

    Attributes:
        mode (ChatCompletionAllowedToolsParamMode):
        tools (list[ChatCompletionAllowedToolsParamToolsItem]):
    """

    mode: ChatCompletionAllowedToolsParamMode
    tools: list[ChatCompletionAllowedToolsParamToolsItem]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        mode = self.mode.value

        tools = []
        for tools_item_data in self.tools:
            tools_item = tools_item_data.to_dict()
            tools.append(tools_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "mode": mode,
                "tools": tools,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chat_completion_allowed_tools_param_tools_item import ChatCompletionAllowedToolsParamToolsItem

        d = dict(src_dict)
        mode = ChatCompletionAllowedToolsParamMode(d.pop("mode"))

        tools = []
        _tools = d.pop("tools")
        for tools_item_data in _tools:
            tools_item = ChatCompletionAllowedToolsParamToolsItem.from_dict(tools_item_data)

            tools.append(tools_item)

        chat_completion_allowed_tools_param = cls(
            mode=mode,
            tools=tools,
        )

        chat_completion_allowed_tools_param.additional_properties = d
        return chat_completion_allowed_tools_param

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
