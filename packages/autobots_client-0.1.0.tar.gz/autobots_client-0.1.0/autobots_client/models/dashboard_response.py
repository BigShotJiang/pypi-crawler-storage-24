from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

if TYPE_CHECKING:
    from ..models.agent_performance import AgentPerformance
    from ..models.chart_data import ChartData
    from ..models.dashboard_summary import DashboardSummary
    from ..models.department_metrics import DepartmentMetrics
    from ..models.workflow_performance import WorkflowPerformance


T = TypeVar("T", bound="DashboardResponse")


@_attrs_define
class DashboardResponse:
    """Complete dashboard response

    Attributes:
        summary (DashboardSummary): Main dashboard summary
        time_saved_chart (ChartData): Chart data structure
        dollars_saved_chart (ChartData): Chart data structure
        roi_chart (ChartData): Chart data structure
        revenue_chart (ChartData): Chart data structure
        top_agents (list[AgentPerformance]):
        top_workflows (list[WorkflowPerformance]):
        department_metrics (list[DepartmentMetrics]):
        generated_at (datetime.datetime):
    """

    summary: DashboardSummary
    time_saved_chart: ChartData
    dollars_saved_chart: ChartData
    roi_chart: ChartData
    revenue_chart: ChartData
    top_agents: list[AgentPerformance]
    top_workflows: list[WorkflowPerformance]
    department_metrics: list[DepartmentMetrics]
    generated_at: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        summary = self.summary.to_dict()

        time_saved_chart = self.time_saved_chart.to_dict()

        dollars_saved_chart = self.dollars_saved_chart.to_dict()

        roi_chart = self.roi_chart.to_dict()

        revenue_chart = self.revenue_chart.to_dict()

        top_agents = []
        for top_agents_item_data in self.top_agents:
            top_agents_item = top_agents_item_data.to_dict()
            top_agents.append(top_agents_item)

        top_workflows = []
        for top_workflows_item_data in self.top_workflows:
            top_workflows_item = top_workflows_item_data.to_dict()
            top_workflows.append(top_workflows_item)

        department_metrics = []
        for department_metrics_item_data in self.department_metrics:
            department_metrics_item = department_metrics_item_data.to_dict()
            department_metrics.append(department_metrics_item)

        generated_at = self.generated_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "summary": summary,
                "time_saved_chart": time_saved_chart,
                "dollars_saved_chart": dollars_saved_chart,
                "roi_chart": roi_chart,
                "revenue_chart": revenue_chart,
                "top_agents": top_agents,
                "top_workflows": top_workflows,
                "department_metrics": department_metrics,
                "generated_at": generated_at,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agent_performance import AgentPerformance
        from ..models.chart_data import ChartData
        from ..models.dashboard_summary import DashboardSummary
        from ..models.department_metrics import DepartmentMetrics
        from ..models.workflow_performance import WorkflowPerformance

        d = dict(src_dict)
        summary = DashboardSummary.from_dict(d.pop("summary"))

        time_saved_chart = ChartData.from_dict(d.pop("time_saved_chart"))

        dollars_saved_chart = ChartData.from_dict(d.pop("dollars_saved_chart"))

        roi_chart = ChartData.from_dict(d.pop("roi_chart"))

        revenue_chart = ChartData.from_dict(d.pop("revenue_chart"))

        top_agents = []
        _top_agents = d.pop("top_agents")
        for top_agents_item_data in _top_agents:
            top_agents_item = AgentPerformance.from_dict(top_agents_item_data)

            top_agents.append(top_agents_item)

        top_workflows = []
        _top_workflows = d.pop("top_workflows")
        for top_workflows_item_data in _top_workflows:
            top_workflows_item = WorkflowPerformance.from_dict(top_workflows_item_data)

            top_workflows.append(top_workflows_item)

        department_metrics = []
        _department_metrics = d.pop("department_metrics")
        for department_metrics_item_data in _department_metrics:
            department_metrics_item = DepartmentMetrics.from_dict(department_metrics_item_data)

            department_metrics.append(department_metrics_item)

        generated_at = isoparse(d.pop("generated_at"))

        dashboard_response = cls(
            summary=summary,
            time_saved_chart=time_saved_chart,
            dollars_saved_chart=dollars_saved_chart,
            roi_chart=roi_chart,
            revenue_chart=revenue_chart,
            top_agents=top_agents,
            top_workflows=top_workflows,
            department_metrics=department_metrics,
            generated_at=generated_at,
        )

        dashboard_response.additional_properties = d
        return dashboard_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
