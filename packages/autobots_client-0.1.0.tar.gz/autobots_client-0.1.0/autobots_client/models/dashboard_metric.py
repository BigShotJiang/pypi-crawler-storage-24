from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.metric_type import MetricType
from ..types import UNSET, Unset

T = TypeVar("T", bound="DashboardMetric")


@_attrs_define
class DashboardMetric:
    """Individual metric data point

    Attributes:
        metric_type (MetricType):
        value (float):
        unit (str | Unset):  Default: ''.
        percentage_change (float | None | Unset):
        trend (None | str | Unset):
    """

    metric_type: MetricType
    value: float
    unit: str | Unset = ""
    percentage_change: float | None | Unset = UNSET
    trend: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        metric_type = self.metric_type.value

        value = self.value

        unit = self.unit

        percentage_change: float | None | Unset
        if isinstance(self.percentage_change, Unset):
            percentage_change = UNSET
        else:
            percentage_change = self.percentage_change

        trend: None | str | Unset
        if isinstance(self.trend, Unset):
            trend = UNSET
        else:
            trend = self.trend

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "metric_type": metric_type,
                "value": value,
            }
        )
        if unit is not UNSET:
            field_dict["unit"] = unit
        if percentage_change is not UNSET:
            field_dict["percentage_change"] = percentage_change
        if trend is not UNSET:
            field_dict["trend"] = trend

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        metric_type = MetricType(d.pop("metric_type"))

        value = d.pop("value")

        unit = d.pop("unit", UNSET)

        def _parse_percentage_change(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        percentage_change = _parse_percentage_change(d.pop("percentage_change", UNSET))

        def _parse_trend(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        trend = _parse_trend(d.pop("trend", UNSET))

        dashboard_metric = cls(
            metric_type=metric_type,
            value=value,
            unit=unit,
            percentage_change=percentage_change,
            trend=trend,
        )

        dashboard_metric.additional_properties = d
        return dashboard_metric

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
