from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.event_result_status import EventResultStatus
from ..models.event_type import EventType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.action_graph_lite_doc import ActionGraphLiteDoc
    from ..models.text_obj import TextObj


T = TypeVar("T", bound="ActionGraphResultLiteDoc")


@_attrs_define
class ActionGraphResultLiteDoc:
    """
    Attributes:
        field_id (str):
        user_id (str):
        type_ (EventType):
        status (EventResultStatus):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        name (str | Unset):  Default: ''.
        error_message (None | TextObj | Unset):
        is_saved (bool | Unset):  Default: False.
        result (ActionGraphLiteDoc | None | Unset):
        file_url (None | str | Unset):
    """

    field_id: str
    user_id: str
    type_: EventType
    status: EventResultStatus
    created_at: datetime.datetime
    updated_at: datetime.datetime
    name: str | Unset = ""
    error_message: None | TextObj | Unset = UNSET
    is_saved: bool | Unset = False
    result: ActionGraphLiteDoc | None | Unset = UNSET
    file_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.action_graph_lite_doc import ActionGraphLiteDoc
        from ..models.text_obj import TextObj

        field_id = self.field_id

        user_id = self.user_id

        type_ = self.type_.value

        status = self.status.value

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        name = self.name

        error_message: dict[str, Any] | None | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        elif isinstance(self.error_message, TextObj):
            error_message = self.error_message.to_dict()
        else:
            error_message = self.error_message

        is_saved = self.is_saved

        result: dict[str, Any] | None | Unset
        if isinstance(self.result, Unset):
            result = UNSET
        elif isinstance(self.result, ActionGraphLiteDoc):
            result = self.result.to_dict()
        else:
            result = self.result

        file_url: None | str | Unset
        if isinstance(self.file_url, Unset):
            file_url = UNSET
        else:
            file_url = self.file_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "_id": field_id,
                "user_id": user_id,
                "type": type_,
                "status": status,
                "created_at": created_at,
                "updated_at": updated_at,
            }
        )
        if name is not UNSET:
            field_dict["name"] = name
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if is_saved is not UNSET:
            field_dict["is_saved"] = is_saved
        if result is not UNSET:
            field_dict["result"] = result
        if file_url is not UNSET:
            field_dict["file_url"] = file_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_graph_lite_doc import ActionGraphLiteDoc
        from ..models.text_obj import TextObj

        d = dict(src_dict)
        field_id = d.pop("_id")

        user_id = d.pop("user_id")

        type_ = EventType(d.pop("type"))

        status = EventResultStatus(d.pop("status"))

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        name = d.pop("name", UNSET)

        def _parse_error_message(data: object) -> None | TextObj | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                error_message_type_0 = TextObj.from_dict(data)

                return error_message_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TextObj | Unset, data)

        error_message = _parse_error_message(d.pop("error_message", UNSET))

        is_saved = d.pop("is_saved", UNSET)

        def _parse_result(data: object) -> ActionGraphLiteDoc | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                result_type_0 = ActionGraphLiteDoc.from_dict(data)

                return result_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ActionGraphLiteDoc | None | Unset, data)

        result = _parse_result(d.pop("result", UNSET))

        def _parse_file_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_url = _parse_file_url(d.pop("file_url", UNSET))

        action_graph_result_lite_doc = cls(
            field_id=field_id,
            user_id=user_id,
            type_=type_,
            status=status,
            created_at=created_at,
            updated_at=updated_at,
            name=name,
            error_message=error_message,
            is_saved=is_saved,
            result=result,
            file_url=file_url,
        )

        action_graph_result_lite_doc.additional_properties = d
        return action_graph_result_lite_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
