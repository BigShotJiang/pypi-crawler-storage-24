from enum import Enum


class DataFlowType(str, Enum):
    AS_IS_LAST_OUTPUT = "as_is_last_output"
    BOTH_INPUT_OUTPUT = "both_input_output"
    ONLY_OUTPUT = "only_output"

    def __str__(self) -> str:
        return str(self.value)
