from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.database_enum import DatabaseEnum
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.database_creds_model_credentials_info_type_0 import DatabaseCredsModelCredentialsInfoType0


T = TypeVar("T", bound="DatabaseCredsModel")


@_attrs_define
class DatabaseCredsModel:
    """Credentials model for database connections

    Attributes:
        database_type (DatabaseEnum):
        host (None | str | Unset):
        port (int | None | Unset):
        database (None | str | Unset):
        username (None | str | Unset):
        password (None | str | Unset):
        name (None | str | Unset):
        project_id (None | str | Unset):
        dataset (None | str | Unset):
        credentials_info (DatabaseCredsModelCredentialsInfoType0 | None | Unset):
        cloud_sql_instance_connection_name (None | str | Unset):
        cloud_sql_use_private_ip (bool | Unset):  Default: False.
        cloud_sql_enable_iam_auth (bool | Unset):  Default: False.
    """

    database_type: DatabaseEnum
    host: None | str | Unset = UNSET
    port: int | None | Unset = UNSET
    database: None | str | Unset = UNSET
    username: None | str | Unset = UNSET
    password: None | str | Unset = UNSET
    name: None | str | Unset = UNSET
    project_id: None | str | Unset = UNSET
    dataset: None | str | Unset = UNSET
    credentials_info: DatabaseCredsModelCredentialsInfoType0 | None | Unset = UNSET
    cloud_sql_instance_connection_name: None | str | Unset = UNSET
    cloud_sql_use_private_ip: bool | Unset = False
    cloud_sql_enable_iam_auth: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.database_creds_model_credentials_info_type_0 import DatabaseCredsModelCredentialsInfoType0

        database_type = self.database_type.value

        host: None | str | Unset
        if isinstance(self.host, Unset):
            host = UNSET
        else:
            host = self.host

        port: int | None | Unset
        if isinstance(self.port, Unset):
            port = UNSET
        else:
            port = self.port

        database: None | str | Unset
        if isinstance(self.database, Unset):
            database = UNSET
        else:
            database = self.database

        username: None | str | Unset
        if isinstance(self.username, Unset):
            username = UNSET
        else:
            username = self.username

        password: None | str | Unset
        if isinstance(self.password, Unset):
            password = UNSET
        else:
            password = self.password

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        project_id: None | str | Unset
        if isinstance(self.project_id, Unset):
            project_id = UNSET
        else:
            project_id = self.project_id

        dataset: None | str | Unset
        if isinstance(self.dataset, Unset):
            dataset = UNSET
        else:
            dataset = self.dataset

        credentials_info: dict[str, Any] | None | Unset
        if isinstance(self.credentials_info, Unset):
            credentials_info = UNSET
        elif isinstance(self.credentials_info, DatabaseCredsModelCredentialsInfoType0):
            credentials_info = self.credentials_info.to_dict()
        else:
            credentials_info = self.credentials_info

        cloud_sql_instance_connection_name: None | str | Unset
        if isinstance(self.cloud_sql_instance_connection_name, Unset):
            cloud_sql_instance_connection_name = UNSET
        else:
            cloud_sql_instance_connection_name = self.cloud_sql_instance_connection_name

        cloud_sql_use_private_ip = self.cloud_sql_use_private_ip

        cloud_sql_enable_iam_auth = self.cloud_sql_enable_iam_auth

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "database_type": database_type,
            }
        )
        if host is not UNSET:
            field_dict["host"] = host
        if port is not UNSET:
            field_dict["port"] = port
        if database is not UNSET:
            field_dict["database"] = database
        if username is not UNSET:
            field_dict["username"] = username
        if password is not UNSET:
            field_dict["password"] = password
        if name is not UNSET:
            field_dict["name"] = name
        if project_id is not UNSET:
            field_dict["project_id"] = project_id
        if dataset is not UNSET:
            field_dict["dataset"] = dataset
        if credentials_info is not UNSET:
            field_dict["credentials_info"] = credentials_info
        if cloud_sql_instance_connection_name is not UNSET:
            field_dict["cloud_sql_instance_connection_name"] = cloud_sql_instance_connection_name
        if cloud_sql_use_private_ip is not UNSET:
            field_dict["cloud_sql_use_private_ip"] = cloud_sql_use_private_ip
        if cloud_sql_enable_iam_auth is not UNSET:
            field_dict["cloud_sql_enable_iam_auth"] = cloud_sql_enable_iam_auth

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.database_creds_model_credentials_info_type_0 import DatabaseCredsModelCredentialsInfoType0

        d = dict(src_dict)
        database_type = DatabaseEnum(d.pop("database_type"))

        def _parse_host(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        host = _parse_host(d.pop("host", UNSET))

        def _parse_port(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        port = _parse_port(d.pop("port", UNSET))

        def _parse_database(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        database = _parse_database(d.pop("database", UNSET))

        def _parse_username(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        username = _parse_username(d.pop("username", UNSET))

        def _parse_password(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        password = _parse_password(d.pop("password", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_project_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        project_id = _parse_project_id(d.pop("project_id", UNSET))

        def _parse_dataset(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        dataset = _parse_dataset(d.pop("dataset", UNSET))

        def _parse_credentials_info(data: object) -> DatabaseCredsModelCredentialsInfoType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                credentials_info_type_0 = DatabaseCredsModelCredentialsInfoType0.from_dict(data)

                return credentials_info_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DatabaseCredsModelCredentialsInfoType0 | None | Unset, data)

        credentials_info = _parse_credentials_info(d.pop("credentials_info", UNSET))

        def _parse_cloud_sql_instance_connection_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        cloud_sql_instance_connection_name = _parse_cloud_sql_instance_connection_name(
            d.pop("cloud_sql_instance_connection_name", UNSET)
        )

        cloud_sql_use_private_ip = d.pop("cloud_sql_use_private_ip", UNSET)

        cloud_sql_enable_iam_auth = d.pop("cloud_sql_enable_iam_auth", UNSET)

        database_creds_model = cls(
            database_type=database_type,
            host=host,
            port=port,
            database=database,
            username=username,
            password=password,
            name=name,
            project_id=project_id,
            dataset=dataset,
            credentials_info=credentials_info,
            cloud_sql_instance_connection_name=cloud_sql_instance_connection_name,
            cloud_sql_use_private_ip=cloud_sql_use_private_ip,
            cloud_sql_enable_iam_auth=cloud_sql_enable_iam_auth,
        )

        database_creds_model.additional_properties = d
        return database_creds_model

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
