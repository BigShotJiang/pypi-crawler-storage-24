from enum import Enum


class DatabaseEnum(str, Enum):
    BIGQUERY = "bigquery"
    MYSQL = "mysql"
    ORACLE = "oracle"
    POSTGRES = "postgres"
    SQLITE = "sqlite"

    def __str__(self) -> str:
        return str(self.value)
