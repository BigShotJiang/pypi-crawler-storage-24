from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.cost_config_type import CostConfigType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.time_range_config import TimeRangeConfig


T = TypeVar("T", bound="CostConfigResponse")


@_attrs_define
class CostConfigResponse:
    """Response model for cost configuration

    Attributes:
        id (str):
        config_type (CostConfigType): Types of cost configurations
        value (float):
        created_at (datetime.datetime):
        updated_at (datetime.datetime):
        created_by (str):
        updated_by (str):
        description (None | str | Unset):
        time_ranges (None | TimeRangeConfig | Unset):
    """

    id: str
    config_type: CostConfigType
    value: float
    created_at: datetime.datetime
    updated_at: datetime.datetime
    created_by: str
    updated_by: str
    description: None | str | Unset = UNSET
    time_ranges: None | TimeRangeConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.time_range_config import TimeRangeConfig

        id = self.id

        config_type = self.config_type.value

        value = self.value

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        created_by = self.created_by

        updated_by = self.updated_by

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        time_ranges: dict[str, Any] | None | Unset
        if isinstance(self.time_ranges, Unset):
            time_ranges = UNSET
        elif isinstance(self.time_ranges, TimeRangeConfig):
            time_ranges = self.time_ranges.to_dict()
        else:
            time_ranges = self.time_ranges

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "id": id,
                "config_type": config_type,
                "value": value,
                "created_at": created_at,
                "updated_at": updated_at,
                "created_by": created_by,
                "updated_by": updated_by,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if time_ranges is not UNSET:
            field_dict["time_ranges"] = time_ranges

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.time_range_config import TimeRangeConfig

        d = dict(src_dict)
        id = d.pop("id")

        config_type = CostConfigType(d.pop("config_type"))

        value = d.pop("value")

        created_at = isoparse(d.pop("created_at"))

        updated_at = isoparse(d.pop("updated_at"))

        created_by = d.pop("created_by")

        updated_by = d.pop("updated_by")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_time_ranges(data: object) -> None | TimeRangeConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                time_ranges_type_0 = TimeRangeConfig.from_dict(data)

                return time_ranges_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TimeRangeConfig | Unset, data)

        time_ranges = _parse_time_ranges(d.pop("time_ranges", UNSET))

        cost_config_response = cls(
            id=id,
            config_type=config_type,
            value=value,
            created_at=created_at,
            updated_at=updated_at,
            created_by=created_by,
            updated_by=updated_by,
            description=description,
            time_ranges=time_ranges,
        )

        cost_config_response.additional_properties = d
        return cost_config_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
