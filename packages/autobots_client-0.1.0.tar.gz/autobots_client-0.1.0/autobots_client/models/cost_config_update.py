from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.time_range_config import TimeRangeConfig


T = TypeVar("T", bound="CostConfigUpdate")


@_attrs_define
class CostConfigUpdate:
    """Model for updating cost configuration

    Attributes:
        value (float | None | Unset): The configuration value
        description (None | str | Unset): Description of this configuration
        time_ranges (None | TimeRangeConfig | Unset): Time range configuration for time saved calculations
    """

    value: float | None | Unset = UNSET
    description: None | str | Unset = UNSET
    time_ranges: None | TimeRangeConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.time_range_config import TimeRangeConfig

        value: float | None | Unset
        if isinstance(self.value, Unset):
            value = UNSET
        else:
            value = self.value

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        time_ranges: dict[str, Any] | None | Unset
        if isinstance(self.time_ranges, Unset):
            time_ranges = UNSET
        elif isinstance(self.time_ranges, TimeRangeConfig):
            time_ranges = self.time_ranges.to_dict()
        else:
            time_ranges = self.time_ranges

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if value is not UNSET:
            field_dict["value"] = value
        if description is not UNSET:
            field_dict["description"] = description
        if time_ranges is not UNSET:
            field_dict["time_ranges"] = time_ranges

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.time_range_config import TimeRangeConfig

        d = dict(src_dict)

        def _parse_value(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        value = _parse_value(d.pop("value", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_time_ranges(data: object) -> None | TimeRangeConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                time_ranges_type_0 = TimeRangeConfig.from_dict(data)

                return time_ranges_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TimeRangeConfig | Unset, data)

        time_ranges = _parse_time_ranges(d.pop("time_ranges", UNSET))

        cost_config_update = cls(
            value=value,
            description=description,
            time_ranges=time_ranges,
        )

        cost_config_update.additional_properties = d
        return cost_config_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
