from enum import Enum


class DalleOpenaiConfigQuality(str, Enum):
    HD = "hd"
    STANDARD = "standard"

    def __str__(self) -> str:
        return str(self.value)
