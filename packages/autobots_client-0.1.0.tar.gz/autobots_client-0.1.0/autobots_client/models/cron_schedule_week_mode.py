from enum import Enum


class CronScheduleWeekMode(str, Enum):
    AT = "at"
    EVERY = "every"

    def __str__(self) -> str:
        return str(self.value)
