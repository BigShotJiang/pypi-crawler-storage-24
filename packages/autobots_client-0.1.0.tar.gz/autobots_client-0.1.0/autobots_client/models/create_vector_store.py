from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.auto_file_chunking_strategy_param import AutoFileChunkingStrategyParam
    from ..models.create_vector_store_metadata_type_0 import CreateVectorStoreMetadataType0
    from ..models.expires_after import ExpiresAfter
    from ..models.static_file_chunking_strategy_object_param import StaticFileChunkingStrategyObjectParam


T = TypeVar("T", bound="CreateVectorStore")


@_attrs_define
class CreateVectorStore:
    """
    Attributes:
        chunking_strategy (AutoFileChunkingStrategyParam | None | StaticFileChunkingStrategyObjectParam | Unset):
        expires_after (ExpiresAfter | None | Unset):
        file_ids (list[str] | None | Unset):
        metadata (CreateVectorStoreMetadataType0 | None | Unset):
        name (None | str | Unset):
    """

    chunking_strategy: AutoFileChunkingStrategyParam | None | StaticFileChunkingStrategyObjectParam | Unset = UNSET
    expires_after: ExpiresAfter | None | Unset = UNSET
    file_ids: list[str] | None | Unset = UNSET
    metadata: CreateVectorStoreMetadataType0 | None | Unset = UNSET
    name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.auto_file_chunking_strategy_param import AutoFileChunkingStrategyParam
        from ..models.create_vector_store_metadata_type_0 import CreateVectorStoreMetadataType0
        from ..models.expires_after import ExpiresAfter
        from ..models.static_file_chunking_strategy_object_param import StaticFileChunkingStrategyObjectParam

        chunking_strategy: dict[str, Any] | None | Unset
        if isinstance(self.chunking_strategy, Unset):
            chunking_strategy = UNSET
        elif isinstance(self.chunking_strategy, AutoFileChunkingStrategyParam):
            chunking_strategy = self.chunking_strategy.to_dict()
        elif isinstance(self.chunking_strategy, StaticFileChunkingStrategyObjectParam):
            chunking_strategy = self.chunking_strategy.to_dict()
        else:
            chunking_strategy = self.chunking_strategy

        expires_after: dict[str, Any] | None | Unset
        if isinstance(self.expires_after, Unset):
            expires_after = UNSET
        elif isinstance(self.expires_after, ExpiresAfter):
            expires_after = self.expires_after.to_dict()
        else:
            expires_after = self.expires_after

        file_ids: list[str] | None | Unset
        if isinstance(self.file_ids, Unset):
            file_ids = UNSET
        elif isinstance(self.file_ids, list):
            file_ids = self.file_ids

        else:
            file_ids = self.file_ids

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, CreateVectorStoreMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if chunking_strategy is not UNSET:
            field_dict["chunking_strategy"] = chunking_strategy
        if expires_after is not UNSET:
            field_dict["expires_after"] = expires_after
        if file_ids is not UNSET:
            field_dict["file_ids"] = file_ids
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if name is not UNSET:
            field_dict["name"] = name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.auto_file_chunking_strategy_param import AutoFileChunkingStrategyParam
        from ..models.create_vector_store_metadata_type_0 import CreateVectorStoreMetadataType0
        from ..models.expires_after import ExpiresAfter
        from ..models.static_file_chunking_strategy_object_param import StaticFileChunkingStrategyObjectParam

        d = dict(src_dict)

        def _parse_chunking_strategy(
            data: object,
        ) -> AutoFileChunkingStrategyParam | None | StaticFileChunkingStrategyObjectParam | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chunking_strategy_type_0 = AutoFileChunkingStrategyParam.from_dict(data)

                return chunking_strategy_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                chunking_strategy_type_1 = StaticFileChunkingStrategyObjectParam.from_dict(data)

                return chunking_strategy_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AutoFileChunkingStrategyParam | None | StaticFileChunkingStrategyObjectParam | Unset, data)

        chunking_strategy = _parse_chunking_strategy(d.pop("chunking_strategy", UNSET))

        def _parse_expires_after(data: object) -> ExpiresAfter | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                expires_after_type_0 = ExpiresAfter.from_dict(data)

                return expires_after_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ExpiresAfter | None | Unset, data)

        expires_after = _parse_expires_after(d.pop("expires_after", UNSET))

        def _parse_file_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                file_ids_type_0 = cast(list[str], data)

                return file_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        file_ids = _parse_file_ids(d.pop("file_ids", UNSET))

        def _parse_metadata(data: object) -> CreateVectorStoreMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = CreateVectorStoreMetadataType0.from_dict(data)

                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(CreateVectorStoreMetadataType0 | None | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        create_vector_store = cls(
            chunking_strategy=chunking_strategy,
            expires_after=expires_after,
            file_ids=file_ids,
            metadata=metadata,
            name=name,
        )

        create_vector_store.additional_properties = d
        return create_vector_store

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
