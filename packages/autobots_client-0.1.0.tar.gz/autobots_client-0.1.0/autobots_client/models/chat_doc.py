from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.chat_doc_openai_provider import ChatDocOpenaiProvider
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.action_doc import ActionDoc
    from ..models.message import Message


T = TypeVar("T", bound="ChatDoc")


@_attrs_define
class ChatDoc:
    """
    Attributes:
        action (ActionDoc):
        messages (list[Message]):
        openai_provider (ChatDocOpenaiProvider):
        title (None | str):
        user_id (str):
        field_id (str):
        updated_at (datetime.datetime | Unset):
        created_at (datetime.datetime | Unset):  Default: isoparse('2026-03-12T15:04:00.062144').
    """

    action: ActionDoc
    messages: list[Message]
    openai_provider: ChatDocOpenaiProvider
    title: None | str
    user_id: str
    field_id: str
    updated_at: datetime.datetime | Unset = UNSET
    created_at: datetime.datetime | Unset = isoparse("2026-03-12T15:04:00.062144")
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        action = self.action.to_dict()

        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)

        openai_provider = self.openai_provider.value

        title: None | str
        title = self.title

        user_id = self.user_id

        field_id = self.field_id

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "action": action,
                "messages": messages,
                "openai_provider": openai_provider,
                "title": title,
                "user_id": user_id,
                "_id": field_id,
            }
        )
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_doc import ActionDoc
        from ..models.message import Message

        d = dict(src_dict)
        action = ActionDoc.from_dict(d.pop("action"))

        messages = []
        _messages = d.pop("messages")
        for messages_item_data in _messages:
            messages_item = Message.from_dict(messages_item_data)

            messages.append(messages_item)

        openai_provider = ChatDocOpenaiProvider(d.pop("openai_provider"))

        def _parse_title(data: object) -> None | str:
            if data is None:
                return data
            return cast(None | str, data)

        title = _parse_title(d.pop("title"))

        user_id = d.pop("user_id")

        field_id = d.pop("_id")

        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        chat_doc = cls(
            action=action,
            messages=messages,
            openai_provider=openai_provider,
            title=title,
            user_id=user_id,
            field_id=field_id,
            updated_at=updated_at,
            created_at=created_at,
        )

        chat_doc.additional_properties = d
        return chat_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
