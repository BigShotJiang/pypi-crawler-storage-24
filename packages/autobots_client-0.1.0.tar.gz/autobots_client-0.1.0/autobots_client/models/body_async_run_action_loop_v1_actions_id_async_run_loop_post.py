from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.body_async_run_action_loop_v1_actions_id_async_run_loop_post_input_item import (
        BodyAsyncRunActionLoopV1ActionsIdAsyncRunLoopPostInputItem,
    )
    from ..models.webhook import Webhook


T = TypeVar("T", bound="BodyAsyncRunActionLoopV1ActionsIdAsyncRunLoopPost")


@_attrs_define
class BodyAsyncRunActionLoopV1ActionsIdAsyncRunLoopPost:
    """
    Attributes:
        input_ (list[BodyAsyncRunActionLoopV1ActionsIdAsyncRunLoopPostInputItem]):
        webhook (None | Unset | Webhook):
    """

    input_: list[BodyAsyncRunActionLoopV1ActionsIdAsyncRunLoopPostInputItem]
    webhook: None | Unset | Webhook = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.webhook import Webhook

        input_ = []
        for input_item_data in self.input_:
            input_item = input_item_data.to_dict()
            input_.append(input_item)

        webhook: dict[str, Any] | None | Unset
        if isinstance(self.webhook, Unset):
            webhook = UNSET
        elif isinstance(self.webhook, Webhook):
            webhook = self.webhook.to_dict()
        else:
            webhook = self.webhook

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "input": input_,
            }
        )
        if webhook is not UNSET:
            field_dict["webhook"] = webhook

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.body_async_run_action_loop_v1_actions_id_async_run_loop_post_input_item import (
            BodyAsyncRunActionLoopV1ActionsIdAsyncRunLoopPostInputItem,
        )
        from ..models.webhook import Webhook

        d = dict(src_dict)
        input_ = []
        _input_ = d.pop("input")
        for input_item_data in _input_:
            input_item = BodyAsyncRunActionLoopV1ActionsIdAsyncRunLoopPostInputItem.from_dict(input_item_data)

            input_.append(input_item)

        def _parse_webhook(data: object) -> None | Unset | Webhook:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                webhook_type_0 = Webhook.from_dict(data)

                return webhook_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | Webhook, data)

        webhook = _parse_webhook(d.pop("webhook", UNSET))

        body_async_run_action_loop_v1_actions_id_async_run_loop_post = cls(
            input_=input_,
            webhook=webhook,
        )

        body_async_run_action_loop_v1_actions_id_async_run_loop_post.additional_properties = d
        return body_async_run_action_loop_v1_actions_id_async_run_loop_post

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
