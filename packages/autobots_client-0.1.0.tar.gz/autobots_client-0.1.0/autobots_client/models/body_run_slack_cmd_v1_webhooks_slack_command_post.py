from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="BodyRunSlackCmdV1WebhooksSlackCommandPost")


@_attrs_define
class BodyRunSlackCmdV1WebhooksSlackCommandPost:
    """
    Attributes:
        token (str):
        command (str):
        text (str):
        response_url (str):
        trigger_id (str):
        user_id (str):
        team_id (str):
        team_domain (str):
        channel_id (str):
        channel_name (str):
        api_app_id (str):
    """

    token: str
    command: str
    text: str
    response_url: str
    trigger_id: str
    user_id: str
    team_id: str
    team_domain: str
    channel_id: str
    channel_name: str
    api_app_id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        token = self.token

        command = self.command

        text = self.text

        response_url = self.response_url

        trigger_id = self.trigger_id

        user_id = self.user_id

        team_id = self.team_id

        team_domain = self.team_domain

        channel_id = self.channel_id

        channel_name = self.channel_name

        api_app_id = self.api_app_id

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "token": token,
                "command": command,
                "text": text,
                "response_url": response_url,
                "trigger_id": trigger_id,
                "user_id": user_id,
                "team_id": team_id,
                "team_domain": team_domain,
                "channel_id": channel_id,
                "channel_name": channel_name,
                "api_app_id": api_app_id,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        token = d.pop("token")

        command = d.pop("command")

        text = d.pop("text")

        response_url = d.pop("response_url")

        trigger_id = d.pop("trigger_id")

        user_id = d.pop("user_id")

        team_id = d.pop("team_id")

        team_domain = d.pop("team_domain")

        channel_id = d.pop("channel_id")

        channel_name = d.pop("channel_name")

        api_app_id = d.pop("api_app_id")

        body_run_slack_cmd_v1_webhooks_slack_command_post = cls(
            token=token,
            command=command,
            text=text,
            response_url=response_url,
            trigger_id=trigger_id,
            user_id=user_id,
            team_id=team_id,
            team_domain=team_domain,
            channel_id=channel_id,
            channel_name=channel_name,
            api_app_id=api_app_id,
        )

        body_run_slack_cmd_v1_webhooks_slack_command_post.additional_properties = d
        return body_run_slack_cmd_v1_webhooks_slack_command_post

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
