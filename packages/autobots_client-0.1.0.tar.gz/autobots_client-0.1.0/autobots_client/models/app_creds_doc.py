from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.app_types import AppTypes
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.app_creds_doc_creds import AppCredsDocCreds


T = TypeVar("T", bound="AppCredsDoc")


@_attrs_define
class AppCredsDoc:
    """
    Attributes:
        app_name (AppTypes | str):
        creds (AppCredsDocCreds):
        user_id (str):
        field_id (str):
        updated_at (datetime.datetime | Unset):
        created_at (datetime.datetime | Unset):
    """

    app_name: AppTypes | str
    creds: AppCredsDocCreds
    user_id: str
    field_id: str
    updated_at: datetime.datetime | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        app_name: str
        if isinstance(self.app_name, AppTypes):
            app_name = self.app_name.value
        else:
            app_name = self.app_name

        creds = self.creds.to_dict()

        user_id = self.user_id

        field_id = self.field_id

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "app_name": app_name,
                "creds": creds,
                "user_id": user_id,
                "_id": field_id,
            }
        )
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if created_at is not UNSET:
            field_dict["created_at"] = created_at

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.app_creds_doc_creds import AppCredsDocCreds

        d = dict(src_dict)

        def _parse_app_name(data: object) -> AppTypes | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                app_name_type_1 = AppTypes(data)

                return app_name_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AppTypes | str, data)

        app_name = _parse_app_name(d.pop("app_name"))

        creds = AppCredsDocCreds.from_dict(d.pop("creds"))

        user_id = d.pop("user_id")

        field_id = d.pop("_id")

        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        app_creds_doc = cls(
            app_name=app_name,
            creds=creds,
            user_id=user_id,
            field_id=field_id,
            updated_at=updated_at,
            created_at=created_at,
        )

        app_creds_doc.additional_properties = d
        return app_creds_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
