from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.chat_completion_audio_param_format import ChatCompletionAudioParamFormat
from ..models.chat_completion_audio_param_voice_type_1 import ChatCompletionAudioParamVoiceType1

T = TypeVar("T", bound="ChatCompletionAudioParam")


@_attrs_define
class ChatCompletionAudioParam:
    """Parameters for audio output.

    Required when audio output is requested with
    `modalities: ["audio"]`. [Learn more](https://platform.openai.com/docs/guides/audio).

        Attributes:
            format_ (ChatCompletionAudioParamFormat):
            voice (ChatCompletionAudioParamVoiceType1 | str):
    """

    format_: ChatCompletionAudioParamFormat
    voice: ChatCompletionAudioParamVoiceType1 | str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        format_ = self.format_.value

        voice: str
        if isinstance(self.voice, ChatCompletionAudioParamVoiceType1):
            voice = self.voice.value
        else:
            voice = self.voice

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "format": format_,
                "voice": voice,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        format_ = ChatCompletionAudioParamFormat(d.pop("format"))

        def _parse_voice(data: object) -> ChatCompletionAudioParamVoiceType1 | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                voice_type_1 = ChatCompletionAudioParamVoiceType1(data)

                return voice_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ChatCompletionAudioParamVoiceType1 | str, data)

        voice = _parse_voice(d.pop("voice"))

        chat_completion_audio_param = cls(
            format_=format_,
            voice=voice,
        )

        chat_completion_audio_param.additional_properties = d
        return chat_completion_audio_param

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
