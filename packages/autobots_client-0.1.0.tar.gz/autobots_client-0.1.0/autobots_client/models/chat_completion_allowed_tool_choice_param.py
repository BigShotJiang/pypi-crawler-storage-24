from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.chat_completion_allowed_tools_param import ChatCompletionAllowedToolsParam


T = TypeVar("T", bound="ChatCompletionAllowedToolChoiceParam")


@_attrs_define
class ChatCompletionAllowedToolChoiceParam:
    """Constrains the tools available to the model to a pre-defined set.

    Attributes:
        allowed_tools (ChatCompletionAllowedToolsParam): Constrains the tools available to the model to a pre-defined
            set.
        type_ (Literal['allowed_tools']):
    """

    allowed_tools: ChatCompletionAllowedToolsParam
    type_: Literal["allowed_tools"]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        allowed_tools = self.allowed_tools.to_dict()

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "allowed_tools": allowed_tools,
                "type": type_,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chat_completion_allowed_tools_param import ChatCompletionAllowedToolsParam

        d = dict(src_dict)
        allowed_tools = ChatCompletionAllowedToolsParam.from_dict(d.pop("allowed_tools"))

        type_ = cast(Literal["allowed_tools"], d.pop("type"))
        if type_ != "allowed_tools":
            raise ValueError(f"type must match const 'allowed_tools', got '{type_}'")

        chat_completion_allowed_tool_choice_param = cls(
            allowed_tools=allowed_tools,
            type_=type_,
        )

        chat_completion_allowed_tool_choice_param.additional_properties = d
        return chat_completion_allowed_tool_choice_param

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
