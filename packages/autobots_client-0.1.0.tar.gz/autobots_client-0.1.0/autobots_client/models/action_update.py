from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.action_update_config_type_0 import ActionUpdateConfigType0


T = TypeVar("T", bound="ActionUpdate")


@_attrs_define
class ActionUpdate:
    """
    Attributes:
        name (None | str | Unset):
        version (float | None | Unset):
        description (None | str | Unset):
        user_manual (None | str | Unset):
        config (ActionUpdateConfigType0 | None | Unset):
        is_saved (bool | None | Unset):
        is_published (bool | None | Unset):
        shared_with (list[str] | None | Unset):
        time_saved_per_run (float | None | Unset): Time saved per run in hours for dashboard agent calculations
        dollar_cost_per_hour (float | None | Unset): Dollar cost per hour for dashboard agent calculations
    """

    name: None | str | Unset = UNSET
    version: float | None | Unset = UNSET
    description: None | str | Unset = UNSET
    user_manual: None | str | Unset = UNSET
    config: ActionUpdateConfigType0 | None | Unset = UNSET
    is_saved: bool | None | Unset = UNSET
    is_published: bool | None | Unset = UNSET
    shared_with: list[str] | None | Unset = UNSET
    time_saved_per_run: float | None | Unset = UNSET
    dollar_cost_per_hour: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.action_update_config_type_0 import ActionUpdateConfigType0

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        version: float | None | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        user_manual: None | str | Unset
        if isinstance(self.user_manual, Unset):
            user_manual = UNSET
        else:
            user_manual = self.user_manual

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, ActionUpdateConfigType0):
            config = self.config.to_dict()
        else:
            config = self.config

        is_saved: bool | None | Unset
        if isinstance(self.is_saved, Unset):
            is_saved = UNSET
        else:
            is_saved = self.is_saved

        is_published: bool | None | Unset
        if isinstance(self.is_published, Unset):
            is_published = UNSET
        else:
            is_published = self.is_published

        shared_with: list[str] | None | Unset
        if isinstance(self.shared_with, Unset):
            shared_with = UNSET
        elif isinstance(self.shared_with, list):
            shared_with = self.shared_with

        else:
            shared_with = self.shared_with

        time_saved_per_run: float | None | Unset
        if isinstance(self.time_saved_per_run, Unset):
            time_saved_per_run = UNSET
        else:
            time_saved_per_run = self.time_saved_per_run

        dollar_cost_per_hour: float | None | Unset
        if isinstance(self.dollar_cost_per_hour, Unset):
            dollar_cost_per_hour = UNSET
        else:
            dollar_cost_per_hour = self.dollar_cost_per_hour

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if version is not UNSET:
            field_dict["version"] = version
        if description is not UNSET:
            field_dict["description"] = description
        if user_manual is not UNSET:
            field_dict["user_manual"] = user_manual
        if config is not UNSET:
            field_dict["config"] = config
        if is_saved is not UNSET:
            field_dict["is_saved"] = is_saved
        if is_published is not UNSET:
            field_dict["is_published"] = is_published
        if shared_with is not UNSET:
            field_dict["shared_with"] = shared_with
        if time_saved_per_run is not UNSET:
            field_dict["time_saved_per_run"] = time_saved_per_run
        if dollar_cost_per_hour is not UNSET:
            field_dict["dollar_cost_per_hour"] = dollar_cost_per_hour

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_update_config_type_0 import ActionUpdateConfigType0

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_version(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        version = _parse_version(d.pop("version", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_user_manual(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_manual = _parse_user_manual(d.pop("user_manual", UNSET))

        def _parse_config(data: object) -> ActionUpdateConfigType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = ActionUpdateConfigType0.from_dict(data)

                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ActionUpdateConfigType0 | None | Unset, data)

        config = _parse_config(d.pop("config", UNSET))

        def _parse_is_saved(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_saved = _parse_is_saved(d.pop("is_saved", UNSET))

        def _parse_is_published(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_published = _parse_is_published(d.pop("is_published", UNSET))

        def _parse_shared_with(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                shared_with_type_0 = cast(list[str], data)

                return shared_with_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        shared_with = _parse_shared_with(d.pop("shared_with", UNSET))

        def _parse_time_saved_per_run(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        time_saved_per_run = _parse_time_saved_per_run(d.pop("time_saved_per_run", UNSET))

        def _parse_dollar_cost_per_hour(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        dollar_cost_per_hour = _parse_dollar_cost_per_hour(d.pop("dollar_cost_per_hour", UNSET))

        action_update = cls(
            name=name,
            version=version,
            description=description,
            user_manual=user_manual,
            config=config,
            is_saved=is_saved,
            is_published=is_published,
            shared_with=shared_with,
            time_saved_per_run=time_saved_per_run,
            dollar_cost_per_hour=dollar_cost_per_hour,
        )

        action_update.additional_properties = d
        return action_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
