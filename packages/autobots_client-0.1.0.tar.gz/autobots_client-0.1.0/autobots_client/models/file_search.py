from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.file_search_ranking_options import FileSearchRankingOptions


T = TypeVar("T", bound="FileSearch")


@_attrs_define
class FileSearch:
    """Overrides for the file search tool.

    Attributes:
        max_num_results (int | None | Unset):
        ranking_options (FileSearchRankingOptions | None | Unset):
    """

    max_num_results: int | None | Unset = UNSET
    ranking_options: FileSearchRankingOptions | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.file_search_ranking_options import FileSearchRankingOptions

        max_num_results: int | None | Unset
        if isinstance(self.max_num_results, Unset):
            max_num_results = UNSET
        else:
            max_num_results = self.max_num_results

        ranking_options: dict[str, Any] | None | Unset
        if isinstance(self.ranking_options, Unset):
            ranking_options = UNSET
        elif isinstance(self.ranking_options, FileSearchRankingOptions):
            ranking_options = self.ranking_options.to_dict()
        else:
            ranking_options = self.ranking_options

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if max_num_results is not UNSET:
            field_dict["max_num_results"] = max_num_results
        if ranking_options is not UNSET:
            field_dict["ranking_options"] = ranking_options

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.file_search_ranking_options import FileSearchRankingOptions

        d = dict(src_dict)

        def _parse_max_num_results(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_num_results = _parse_max_num_results(d.pop("max_num_results", UNSET))

        def _parse_ranking_options(data: object) -> FileSearchRankingOptions | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                ranking_options_type_0 = FileSearchRankingOptions.from_dict(data)

                return ranking_options_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FileSearchRankingOptions | None | Unset, data)

        ranking_options = _parse_ranking_options(d.pop("ranking_options", UNSET))

        file_search = cls(
            max_num_results=max_num_results,
            ranking_options=ranking_options,
        )

        file_search.additional_properties = d
        return file_search

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
