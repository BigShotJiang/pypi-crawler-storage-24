from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.event_result_status import EventResultStatus
from ..models.event_type import EventType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.action_doc import ActionDoc
    from ..models.text_obj import TextObj


T = TypeVar("T", bound="ActionResultDoc")


@_attrs_define
class ActionResultDoc:
    """
    Attributes:
        type_ (EventType):
        status (EventResultStatus):
        result (ActionDoc):
        user_id (str):
        field_id (str):
        updated_at (datetime.datetime | Unset):
        name (str | Unset):  Default: ''.
        error_message (None | TextObj | Unset):
        is_saved (bool | Unset):  Default: False.
        created_at (datetime.datetime | Unset):  Default: isoparse('2026-03-12T15:03:48.682683').
        file_url (None | str | Unset):
    """

    type_: EventType
    status: EventResultStatus
    result: ActionDoc
    user_id: str
    field_id: str
    updated_at: datetime.datetime | Unset = UNSET
    name: str | Unset = ""
    error_message: None | TextObj | Unset = UNSET
    is_saved: bool | Unset = False
    created_at: datetime.datetime | Unset = isoparse("2026-03-12T15:03:48.682683")
    file_url: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.text_obj import TextObj

        type_ = self.type_.value

        status = self.status.value

        result = self.result.to_dict()

        user_id = self.user_id

        field_id = self.field_id

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        name = self.name

        error_message: dict[str, Any] | None | Unset
        if isinstance(self.error_message, Unset):
            error_message = UNSET
        elif isinstance(self.error_message, TextObj):
            error_message = self.error_message.to_dict()
        else:
            error_message = self.error_message

        is_saved = self.is_saved

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        file_url: None | str | Unset
        if isinstance(self.file_url, Unset):
            file_url = UNSET
        else:
            file_url = self.file_url

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "type": type_,
                "status": status,
                "result": result,
                "user_id": user_id,
                "_id": field_id,
            }
        )
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if name is not UNSET:
            field_dict["name"] = name
        if error_message is not UNSET:
            field_dict["error_message"] = error_message
        if is_saved is not UNSET:
            field_dict["is_saved"] = is_saved
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if file_url is not UNSET:
            field_dict["file_url"] = file_url

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_doc import ActionDoc
        from ..models.text_obj import TextObj

        d = dict(src_dict)
        type_ = EventType(d.pop("type"))

        status = EventResultStatus(d.pop("status"))

        result = ActionDoc.from_dict(d.pop("result"))

        user_id = d.pop("user_id")

        field_id = d.pop("_id")

        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        name = d.pop("name", UNSET)

        def _parse_error_message(data: object) -> None | TextObj | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                error_message_type_0 = TextObj.from_dict(data)

                return error_message_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TextObj | Unset, data)

        error_message = _parse_error_message(d.pop("error_message", UNSET))

        is_saved = d.pop("is_saved", UNSET)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        def _parse_file_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        file_url = _parse_file_url(d.pop("file_url", UNSET))

        action_result_doc = cls(
            type_=type_,
            status=status,
            result=result,
            user_id=user_id,
            field_id=field_id,
            updated_at=updated_at,
            name=name,
            error_message=error_message,
            is_saved=is_saved,
            created_at=created_at,
            file_url=file_url,
        )

        action_result_doc.additional_properties = d
        return action_result_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
