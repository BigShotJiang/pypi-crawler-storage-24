from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.metric_type import MetricType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.time_series_data_point import TimeSeriesDataPoint


T = TypeVar("T", bound="ChartData")


@_attrs_define
class ChartData:
    """Chart data structure

    Attributes:
        title (str):
        data_points (list[TimeSeriesDataPoint]):
        metric_type (MetricType):
        unit (str | Unset):  Default: ''.
    """

    title: str
    data_points: list[TimeSeriesDataPoint]
    metric_type: MetricType
    unit: str | Unset = ""
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        title = self.title

        data_points = []
        for data_points_item_data in self.data_points:
            data_points_item = data_points_item_data.to_dict()
            data_points.append(data_points_item)

        metric_type = self.metric_type.value

        unit = self.unit

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "title": title,
                "data_points": data_points,
                "metric_type": metric_type,
            }
        )
        if unit is not UNSET:
            field_dict["unit"] = unit

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.time_series_data_point import TimeSeriesDataPoint

        d = dict(src_dict)
        title = d.pop("title")

        data_points = []
        _data_points = d.pop("data_points")
        for data_points_item_data in _data_points:
            data_points_item = TimeSeriesDataPoint.from_dict(data_points_item_data)

            data_points.append(data_points_item)

        metric_type = MetricType(d.pop("metric_type"))

        unit = d.pop("unit", UNSET)

        chart_data = cls(
            title=title,
            data_points=data_points,
            metric_type=metric_type,
            unit=unit,
        )

        chart_data.additional_properties = d
        return chart_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
