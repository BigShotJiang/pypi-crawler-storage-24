from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="CharacterLiteDoc")


@_attrs_define
class CharacterLiteDoc:
    """
    Attributes:
        name (str):
        user_id (str):
        field_id (str):
        updated_at (datetime.datetime | Unset):
        created_at (datetime.datetime | Unset):
        tags (list[str] | Unset):
        is_published (bool | Unset):  Default: False.
    """

    name: str
    user_id: str
    field_id: str
    updated_at: datetime.datetime | Unset = UNSET
    created_at: datetime.datetime | Unset = UNSET
    tags: list[str] | Unset = UNSET
    is_published: bool | Unset = False
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        name = self.name

        user_id = self.user_id

        field_id = self.field_id

        updated_at: str | Unset = UNSET
        if not isinstance(self.updated_at, Unset):
            updated_at = self.updated_at.isoformat()

        created_at: str | Unset = UNSET
        if not isinstance(self.created_at, Unset):
            created_at = self.created_at.isoformat()

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags

        is_published = self.is_published

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "user_id": user_id,
                "_id": field_id,
            }
        )
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if created_at is not UNSET:
            field_dict["created_at"] = created_at
        if tags is not UNSET:
            field_dict["tags"] = tags
        if is_published is not UNSET:
            field_dict["is_published"] = is_published

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        user_id = d.pop("user_id")

        field_id = d.pop("_id")

        _updated_at = d.pop("updated_at", UNSET)
        updated_at: datetime.datetime | Unset
        if isinstance(_updated_at, Unset):
            updated_at = UNSET
        else:
            updated_at = isoparse(_updated_at)

        _created_at = d.pop("created_at", UNSET)
        created_at: datetime.datetime | Unset
        if isinstance(_created_at, Unset):
            created_at = UNSET
        else:
            created_at = isoparse(_created_at)

        tags = cast(list[str], d.pop("tags", UNSET))

        is_published = d.pop("is_published", UNSET)

        character_lite_doc = cls(
            name=name,
            user_id=user_id,
            field_id=field_id,
            updated_at=updated_at,
            created_at=created_at,
            tags=tags,
            is_published=is_published,
        )

        character_lite_doc.additional_properties = d
        return character_lite_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
