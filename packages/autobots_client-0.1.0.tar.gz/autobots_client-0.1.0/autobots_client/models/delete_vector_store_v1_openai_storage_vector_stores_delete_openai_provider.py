from enum import Enum


class DeleteVectorStoreV1OpenaiStorageVectorStoresDeleteOpenaiProvider(str, Enum):
    AZURE = "azure"
    OPENAI = "openai"

    def __str__(self) -> str:
        return str(self.value)
