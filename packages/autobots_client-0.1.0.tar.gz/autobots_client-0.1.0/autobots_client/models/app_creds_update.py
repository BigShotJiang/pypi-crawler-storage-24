from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.app_types import AppTypes

if TYPE_CHECKING:
    from ..models.app_creds_update_creds import AppCredsUpdateCreds


T = TypeVar("T", bound="AppCredsUpdate")


@_attrs_define
class AppCredsUpdate:
    """
    Attributes:
        app_name (AppTypes | str):
        creds (AppCredsUpdateCreds):
    """

    app_name: AppTypes | str
    creds: AppCredsUpdateCreds
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        app_name: str
        if isinstance(self.app_name, AppTypes):
            app_name = self.app_name.value
        else:
            app_name = self.app_name

        creds = self.creds.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "app_name": app_name,
                "creds": creds,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.app_creds_update_creds import AppCredsUpdateCreds

        d = dict(src_dict)

        def _parse_app_name(data: object) -> AppTypes | str:
            try:
                if not isinstance(data, str):
                    raise TypeError()
                app_name_type_1 = AppTypes(data)

                return app_name_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AppTypes | str, data)

        app_name = _parse_app_name(d.pop("app_name"))

        creds = AppCredsUpdateCreds.from_dict(d.pop("creds"))

        app_creds_update = cls(
            app_name=app_name,
            creds=creds,
        )

        app_creds_update.additional_properties = d
        return app_creds_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
