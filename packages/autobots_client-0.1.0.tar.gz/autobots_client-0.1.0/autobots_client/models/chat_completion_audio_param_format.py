from enum import Enum


class ChatCompletionAudioParamFormat(str, Enum):
    AAC = "aac"
    FLAC = "flac"
    MP3 = "mp3"
    OPUS = "opus"
    PCM16 = "pcm16"
    WAV = "wav"

    def __str__(self) -> str:
        return str(self.value)
