from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.agent_data_openai_provider import AgentDataOpenaiProvider
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.chat_completion_assistant_message_param import ChatCompletionAssistantMessageParam
    from ..models.chat_completion_developer_message_param import ChatCompletionDeveloperMessageParam
    from ..models.chat_completion_function_message_param import ChatCompletionFunctionMessageParam
    from ..models.chat_completion_system_message_param import ChatCompletionSystemMessageParam
    from ..models.chat_completion_tool_message_param import ChatCompletionToolMessageParam
    from ..models.chat_completion_user_message_param import ChatCompletionUserMessageParam


T = TypeVar("T", bound="AgentData")


@_attrs_define
class AgentData:
    """
    Attributes:
        openai_provider (AgentDataOpenaiProvider):
        goal (str):
        context (list[ChatCompletionAssistantMessageParam | ChatCompletionDeveloperMessageParam |
            ChatCompletionFunctionMessageParam | ChatCompletionSystemMessageParam | ChatCompletionToolMessageParam |
            ChatCompletionUserMessageParam] | Unset):
    """

    openai_provider: AgentDataOpenaiProvider
    goal: str
    context: (
        list[
            ChatCompletionAssistantMessageParam
            | ChatCompletionDeveloperMessageParam
            | ChatCompletionFunctionMessageParam
            | ChatCompletionSystemMessageParam
            | ChatCompletionToolMessageParam
            | ChatCompletionUserMessageParam
        ]
        | Unset
    ) = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.chat_completion_assistant_message_param import ChatCompletionAssistantMessageParam
        from ..models.chat_completion_developer_message_param import ChatCompletionDeveloperMessageParam
        from ..models.chat_completion_system_message_param import ChatCompletionSystemMessageParam
        from ..models.chat_completion_tool_message_param import ChatCompletionToolMessageParam
        from ..models.chat_completion_user_message_param import ChatCompletionUserMessageParam

        openai_provider = self.openai_provider.value

        goal = self.goal

        context: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.context, Unset):
            context = []
            for context_item_data in self.context:
                context_item: dict[str, Any]
                if isinstance(context_item_data, ChatCompletionDeveloperMessageParam):
                    context_item = context_item_data.to_dict()
                elif isinstance(context_item_data, ChatCompletionSystemMessageParam):
                    context_item = context_item_data.to_dict()
                elif isinstance(context_item_data, ChatCompletionUserMessageParam):
                    context_item = context_item_data.to_dict()
                elif isinstance(context_item_data, ChatCompletionAssistantMessageParam):
                    context_item = context_item_data.to_dict()
                elif isinstance(context_item_data, ChatCompletionToolMessageParam):
                    context_item = context_item_data.to_dict()
                else:
                    context_item = context_item_data.to_dict()

                context.append(context_item)

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "openai_provider": openai_provider,
                "goal": goal,
            }
        )
        if context is not UNSET:
            field_dict["context"] = context

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chat_completion_assistant_message_param import ChatCompletionAssistantMessageParam
        from ..models.chat_completion_developer_message_param import ChatCompletionDeveloperMessageParam
        from ..models.chat_completion_function_message_param import ChatCompletionFunctionMessageParam
        from ..models.chat_completion_system_message_param import ChatCompletionSystemMessageParam
        from ..models.chat_completion_tool_message_param import ChatCompletionToolMessageParam
        from ..models.chat_completion_user_message_param import ChatCompletionUserMessageParam

        d = dict(src_dict)
        openai_provider = AgentDataOpenaiProvider(d.pop("openai_provider"))

        goal = d.pop("goal")

        _context = d.pop("context", UNSET)
        context: (
            list[
                ChatCompletionAssistantMessageParam
                | ChatCompletionDeveloperMessageParam
                | ChatCompletionFunctionMessageParam
                | ChatCompletionSystemMessageParam
                | ChatCompletionToolMessageParam
                | ChatCompletionUserMessageParam
            ]
            | Unset
        ) = UNSET
        if _context is not UNSET:
            context = []
            for context_item_data in _context:

                def _parse_context_item(
                    data: object,
                ) -> (
                    ChatCompletionAssistantMessageParam
                    | ChatCompletionDeveloperMessageParam
                    | ChatCompletionFunctionMessageParam
                    | ChatCompletionSystemMessageParam
                    | ChatCompletionToolMessageParam
                    | ChatCompletionUserMessageParam
                ):
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        context_item_type_0 = ChatCompletionDeveloperMessageParam.from_dict(data)

                        return context_item_type_0
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        context_item_type_1 = ChatCompletionSystemMessageParam.from_dict(data)

                        return context_item_type_1
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        context_item_type_2 = ChatCompletionUserMessageParam.from_dict(data)

                        return context_item_type_2
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        context_item_type_3 = ChatCompletionAssistantMessageParam.from_dict(data)

                        return context_item_type_3
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    try:
                        if not isinstance(data, dict):
                            raise TypeError()
                        context_item_type_4 = ChatCompletionToolMessageParam.from_dict(data)

                        return context_item_type_4
                    except (TypeError, ValueError, AttributeError, KeyError):
                        pass
                    if not isinstance(data, dict):
                        raise TypeError()
                    context_item_type_5 = ChatCompletionFunctionMessageParam.from_dict(data)

                    return context_item_type_5

                context_item = _parse_context_item(context_item_data)

                context.append(context_item)

        agent_data = cls(
            openai_provider=openai_provider,
            goal=goal,
            context=context,
        )

        agent_data.additional_properties = d
        return agent_data

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
