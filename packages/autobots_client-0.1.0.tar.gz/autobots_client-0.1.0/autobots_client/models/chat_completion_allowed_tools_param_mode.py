from enum import Enum


class ChatCompletionAllowedToolsParamMode(str, Enum):
    AUTO = "auto"
    REQUIRED = "required"

    def __str__(self) -> str:
        return str(self.value)
