from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.filter_by import FilterBy
from ..models.time_range import TimeRange
from ..types import UNSET, Unset

T = TypeVar("T", bound="DashboardRequest")


@_attrs_define
class DashboardRequest:
    """Request model for dashboard data

    Attributes:
        time_range (TimeRange | Unset):
        start_date (datetime.datetime | None | Unset):
        end_date (datetime.datetime | None | Unset):
        filter_by (FilterBy | None | Unset):
        filter_value (None | str | Unset):
    """

    time_range: TimeRange | Unset = UNSET
    start_date: datetime.datetime | None | Unset = UNSET
    end_date: datetime.datetime | None | Unset = UNSET
    filter_by: FilterBy | None | Unset = UNSET
    filter_value: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        time_range: str | Unset = UNSET
        if not isinstance(self.time_range, Unset):
            time_range = self.time_range.value

        start_date: None | str | Unset
        if isinstance(self.start_date, Unset):
            start_date = UNSET
        elif isinstance(self.start_date, datetime.datetime):
            start_date = self.start_date.isoformat()
        else:
            start_date = self.start_date

        end_date: None | str | Unset
        if isinstance(self.end_date, Unset):
            end_date = UNSET
        elif isinstance(self.end_date, datetime.datetime):
            end_date = self.end_date.isoformat()
        else:
            end_date = self.end_date

        filter_by: None | str | Unset
        if isinstance(self.filter_by, Unset):
            filter_by = UNSET
        elif isinstance(self.filter_by, FilterBy):
            filter_by = self.filter_by.value
        else:
            filter_by = self.filter_by

        filter_value: None | str | Unset
        if isinstance(self.filter_value, Unset):
            filter_value = UNSET
        else:
            filter_value = self.filter_value

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if time_range is not UNSET:
            field_dict["time_range"] = time_range
        if start_date is not UNSET:
            field_dict["start_date"] = start_date
        if end_date is not UNSET:
            field_dict["end_date"] = end_date
        if filter_by is not UNSET:
            field_dict["filter_by"] = filter_by
        if filter_value is not UNSET:
            field_dict["filter_value"] = filter_value

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        _time_range = d.pop("time_range", UNSET)
        time_range: TimeRange | Unset
        if isinstance(_time_range, Unset):
            time_range = UNSET
        else:
            time_range = TimeRange(_time_range)

        def _parse_start_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                start_date_type_0 = isoparse(data)

                return start_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        start_date = _parse_start_date(d.pop("start_date", UNSET))

        def _parse_end_date(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                end_date_type_0 = isoparse(data)

                return end_date_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        end_date = _parse_end_date(d.pop("end_date", UNSET))

        def _parse_filter_by(data: object) -> FilterBy | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                filter_by_type_0 = FilterBy(data)

                return filter_by_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FilterBy | None | Unset, data)

        filter_by = _parse_filter_by(d.pop("filter_by", UNSET))

        def _parse_filter_value(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        filter_value = _parse_filter_value(d.pop("filter_value", UNSET))

        dashboard_request = cls(
            time_range=time_range,
            start_date=start_date,
            end_date=end_date,
            filter_by=filter_by,
            filter_value=filter_value,
        )

        dashboard_request.additional_properties = d
        return dashboard_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
