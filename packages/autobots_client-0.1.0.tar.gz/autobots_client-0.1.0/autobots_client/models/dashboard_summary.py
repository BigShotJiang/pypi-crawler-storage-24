from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

if TYPE_CHECKING:
    from ..models.dashboard_metric import DashboardMetric


T = TypeVar("T", bound="DashboardSummary")


@_attrs_define
class DashboardSummary:
    """Main dashboard summary

    Attributes:
        total_agents (DashboardMetric): Individual metric data point
        active_workflows (DashboardMetric): Individual metric data point
        scheduled_jobs (DashboardMetric): Individual metric data point
        total_workflow_runs (DashboardMetric): Individual metric data point
        time_saved (DashboardMetric): Individual metric data point
        dollars_saved (DashboardMetric): Individual metric data point
        roi_percentage (DashboardMetric): Individual metric data point
        additional_revenue (DashboardMetric): Individual metric data point
        last_updated (datetime.datetime):
    """

    total_agents: DashboardMetric
    active_workflows: DashboardMetric
    scheduled_jobs: DashboardMetric
    total_workflow_runs: DashboardMetric
    time_saved: DashboardMetric
    dollars_saved: DashboardMetric
    roi_percentage: DashboardMetric
    additional_revenue: DashboardMetric
    last_updated: datetime.datetime
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_agents = self.total_agents.to_dict()

        active_workflows = self.active_workflows.to_dict()

        scheduled_jobs = self.scheduled_jobs.to_dict()

        total_workflow_runs = self.total_workflow_runs.to_dict()

        time_saved = self.time_saved.to_dict()

        dollars_saved = self.dollars_saved.to_dict()

        roi_percentage = self.roi_percentage.to_dict()

        additional_revenue = self.additional_revenue.to_dict()

        last_updated = self.last_updated.isoformat()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total_agents": total_agents,
                "active_workflows": active_workflows,
                "scheduled_jobs": scheduled_jobs,
                "total_workflow_runs": total_workflow_runs,
                "time_saved": time_saved,
                "dollars_saved": dollars_saved,
                "roi_percentage": roi_percentage,
                "additional_revenue": additional_revenue,
                "last_updated": last_updated,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dashboard_metric import DashboardMetric

        d = dict(src_dict)
        total_agents = DashboardMetric.from_dict(d.pop("total_agents"))

        active_workflows = DashboardMetric.from_dict(d.pop("active_workflows"))

        scheduled_jobs = DashboardMetric.from_dict(d.pop("scheduled_jobs"))

        total_workflow_runs = DashboardMetric.from_dict(d.pop("total_workflow_runs"))

        time_saved = DashboardMetric.from_dict(d.pop("time_saved"))

        dollars_saved = DashboardMetric.from_dict(d.pop("dollars_saved"))

        roi_percentage = DashboardMetric.from_dict(d.pop("roi_percentage"))

        additional_revenue = DashboardMetric.from_dict(d.pop("additional_revenue"))

        last_updated = isoparse(d.pop("last_updated"))

        dashboard_summary = cls(
            total_agents=total_agents,
            active_workflows=active_workflows,
            scheduled_jobs=scheduled_jobs,
            total_workflow_runs=total_workflow_runs,
            time_saved=time_saved,
            dollars_saved=dollars_saved,
            roi_percentage=roi_percentage,
            additional_revenue=additional_revenue,
            last_updated=last_updated,
        )

        dashboard_summary.additional_properties = d
        return dashboard_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
