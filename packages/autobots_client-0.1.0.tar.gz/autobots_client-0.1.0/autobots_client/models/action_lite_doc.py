from __future__ import annotations

import datetime
from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..models.action_type import ActionType
from ..types import UNSET, Unset

T = TypeVar("T", bound="ActionLiteDoc")


@_attrs_define
class ActionLiteDoc:
    """
    Attributes:
        field_id (str):
        type_ (ActionType):
        name (str):
        user_id (str):
        created_at (datetime.datetime):
        version (float | Unset):  Default: 0.0.
        user_manual (str | Unset):  Default: ''.
        description (str | Unset):  Default: ''.
        is_saved (bool | Unset):  Default: False.
        is_published (bool | Unset):  Default: False.
        shared_with (list[str] | None | Unset):
        updated_at (datetime.datetime | None | Unset):
        time_saved_per_run (float | None | Unset):  Default: 0.5.
        dollar_cost_per_hour (float | None | Unset):  Default: 50.0.
    """

    field_id: str
    type_: ActionType
    name: str
    user_id: str
    created_at: datetime.datetime
    version: float | Unset = 0.0
    user_manual: str | Unset = ""
    description: str | Unset = ""
    is_saved: bool | Unset = False
    is_published: bool | Unset = False
    shared_with: list[str] | None | Unset = UNSET
    updated_at: datetime.datetime | None | Unset = UNSET
    time_saved_per_run: float | None | Unset = 0.5
    dollar_cost_per_hour: float | None | Unset = 50.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        field_id = self.field_id

        type_ = self.type_.value

        name = self.name

        user_id = self.user_id

        created_at = self.created_at.isoformat()

        version = self.version

        user_manual = self.user_manual

        description = self.description

        is_saved = self.is_saved

        is_published = self.is_published

        shared_with: list[str] | None | Unset
        if isinstance(self.shared_with, Unset):
            shared_with = UNSET
        elif isinstance(self.shared_with, list):
            shared_with = self.shared_with

        else:
            shared_with = self.shared_with

        updated_at: None | str | Unset
        if isinstance(self.updated_at, Unset):
            updated_at = UNSET
        elif isinstance(self.updated_at, datetime.datetime):
            updated_at = self.updated_at.isoformat()
        else:
            updated_at = self.updated_at

        time_saved_per_run: float | None | Unset
        if isinstance(self.time_saved_per_run, Unset):
            time_saved_per_run = UNSET
        else:
            time_saved_per_run = self.time_saved_per_run

        dollar_cost_per_hour: float | None | Unset
        if isinstance(self.dollar_cost_per_hour, Unset):
            dollar_cost_per_hour = UNSET
        else:
            dollar_cost_per_hour = self.dollar_cost_per_hour

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "_id": field_id,
                "type": type_,
                "name": name,
                "user_id": user_id,
                "created_at": created_at,
            }
        )
        if version is not UNSET:
            field_dict["version"] = version
        if user_manual is not UNSET:
            field_dict["user_manual"] = user_manual
        if description is not UNSET:
            field_dict["description"] = description
        if is_saved is not UNSET:
            field_dict["is_saved"] = is_saved
        if is_published is not UNSET:
            field_dict["is_published"] = is_published
        if shared_with is not UNSET:
            field_dict["shared_with"] = shared_with
        if updated_at is not UNSET:
            field_dict["updated_at"] = updated_at
        if time_saved_per_run is not UNSET:
            field_dict["time_saved_per_run"] = time_saved_per_run
        if dollar_cost_per_hour is not UNSET:
            field_dict["dollar_cost_per_hour"] = dollar_cost_per_hour

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        field_id = d.pop("_id")

        type_ = ActionType(d.pop("type"))

        name = d.pop("name")

        user_id = d.pop("user_id")

        created_at = isoparse(d.pop("created_at"))

        version = d.pop("version", UNSET)

        user_manual = d.pop("user_manual", UNSET)

        description = d.pop("description", UNSET)

        is_saved = d.pop("is_saved", UNSET)

        is_published = d.pop("is_published", UNSET)

        def _parse_shared_with(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                shared_with_type_0 = cast(list[str], data)

                return shared_with_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        shared_with = _parse_shared_with(d.pop("shared_with", UNSET))

        def _parse_updated_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                updated_at_type_0 = isoparse(data)

                return updated_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        updated_at = _parse_updated_at(d.pop("updated_at", UNSET))

        def _parse_time_saved_per_run(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        time_saved_per_run = _parse_time_saved_per_run(d.pop("time_saved_per_run", UNSET))

        def _parse_dollar_cost_per_hour(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        dollar_cost_per_hour = _parse_dollar_cost_per_hour(d.pop("dollar_cost_per_hour", UNSET))

        action_lite_doc = cls(
            field_id=field_id,
            type_=type_,
            name=name,
            user_id=user_id,
            created_at=created_at,
            version=version,
            user_manual=user_manual,
            description=description,
            is_saved=is_saved,
            is_published=is_published,
            shared_with=shared_with,
            updated_at=updated_at,
            time_saved_per_run=time_saved_per_run,
            dollar_cost_per_hour=dollar_cost_per_hour,
        )

        action_lite_doc.additional_properties = d
        return action_lite_doc

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
