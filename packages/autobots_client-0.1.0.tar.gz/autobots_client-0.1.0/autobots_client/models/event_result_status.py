from enum import Enum


class EventResultStatus(str, Enum):
    ERROR = "error"
    PROCESSING = "processing"
    STUCK = "stuck"
    SUCCESS = "success"
    WAITING = "waiting"

    def __str__(self) -> str:
        return str(self.value)
