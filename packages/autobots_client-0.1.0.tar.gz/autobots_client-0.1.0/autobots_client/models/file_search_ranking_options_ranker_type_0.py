from enum import Enum


class FileSearchRankingOptionsRankerType0(str, Enum):
    AUTO = "auto"
    DEFAULT_2024_08_21 = "default_2024_08_21"

    def __str__(self) -> str:
        return str(self.value)
