from enum import Enum


class FileObjectStatus(str, Enum):
    ERROR = "error"
    PROCESSED = "processed"
    UPLOADED = "uploaded"

    def __str__(self) -> str:
        return str(self.value)
