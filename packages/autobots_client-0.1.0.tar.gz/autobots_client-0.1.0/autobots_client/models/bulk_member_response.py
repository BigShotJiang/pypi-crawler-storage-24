from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="BulkMemberResponse")


@_attrs_define
class BulkMemberResponse:
    """
    Attributes:
        total_requested (int):
        inserted_count (int):
        updated_count (int):
        matched_count (int):
        invalid_emails (list[str] | Unset):
        not_found_emails (list[str] | Unset):
        skipped_owner_emails (list[str] | Unset):
        skipped_legacy_users (list[str] | Unset):
    """

    total_requested: int
    inserted_count: int
    updated_count: int
    matched_count: int
    invalid_emails: list[str] | Unset = UNSET
    not_found_emails: list[str] | Unset = UNSET
    skipped_owner_emails: list[str] | Unset = UNSET
    skipped_legacy_users: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        total_requested = self.total_requested

        inserted_count = self.inserted_count

        updated_count = self.updated_count

        matched_count = self.matched_count

        invalid_emails: list[str] | Unset = UNSET
        if not isinstance(self.invalid_emails, Unset):
            invalid_emails = self.invalid_emails

        not_found_emails: list[str] | Unset = UNSET
        if not isinstance(self.not_found_emails, Unset):
            not_found_emails = self.not_found_emails

        skipped_owner_emails: list[str] | Unset = UNSET
        if not isinstance(self.skipped_owner_emails, Unset):
            skipped_owner_emails = self.skipped_owner_emails

        skipped_legacy_users: list[str] | Unset = UNSET
        if not isinstance(self.skipped_legacy_users, Unset):
            skipped_legacy_users = self.skipped_legacy_users

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "total_requested": total_requested,
                "inserted_count": inserted_count,
                "updated_count": updated_count,
                "matched_count": matched_count,
            }
        )
        if invalid_emails is not UNSET:
            field_dict["invalid_emails"] = invalid_emails
        if not_found_emails is not UNSET:
            field_dict["not_found_emails"] = not_found_emails
        if skipped_owner_emails is not UNSET:
            field_dict["skipped_owner_emails"] = skipped_owner_emails
        if skipped_legacy_users is not UNSET:
            field_dict["skipped_legacy_users"] = skipped_legacy_users

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        total_requested = d.pop("total_requested")

        inserted_count = d.pop("inserted_count")

        updated_count = d.pop("updated_count")

        matched_count = d.pop("matched_count")

        invalid_emails = cast(list[str], d.pop("invalid_emails", UNSET))

        not_found_emails = cast(list[str], d.pop("not_found_emails", UNSET))

        skipped_owner_emails = cast(list[str], d.pop("skipped_owner_emails", UNSET))

        skipped_legacy_users = cast(list[str], d.pop("skipped_legacy_users", UNSET))

        bulk_member_response = cls(
            total_requested=total_requested,
            inserted_count=inserted_count,
            updated_count=updated_count,
            matched_count=matched_count,
            invalid_emails=invalid_emails,
            not_found_emails=not_found_emails,
            skipped_owner_emails=skipped_owner_emails,
            skipped_legacy_users=skipped_legacy_users,
        )

        bulk_member_response.additional_properties = d
        return bulk_member_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
