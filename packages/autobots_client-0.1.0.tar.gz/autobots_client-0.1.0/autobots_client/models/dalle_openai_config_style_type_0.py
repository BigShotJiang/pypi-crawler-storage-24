from enum import Enum


class DalleOpenaiConfigStyleType0(str, Enum):
    NATURAL = "natural"
    VIVID = "vivid"

    def __str__(self) -> str:
        return str(self.value)
