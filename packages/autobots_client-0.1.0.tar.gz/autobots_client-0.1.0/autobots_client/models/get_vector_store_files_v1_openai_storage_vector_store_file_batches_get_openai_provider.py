from enum import Enum


class GetVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesGetOpenaiProvider(str, Enum):
    AZURE = "azure"
    OPENAI = "openai"

    def __str__(self) -> str:
        return str(self.value)
