from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.function_definition_parameters_type_0 import FunctionDefinitionParametersType0


T = TypeVar("T", bound="FunctionDefinition")


@_attrs_define
class FunctionDefinition:
    """
    Attributes:
        name (str):
        description (None | str | Unset):
        parameters (FunctionDefinitionParametersType0 | None | Unset):
        strict (bool | None | Unset):
    """

    name: str
    description: None | str | Unset = UNSET
    parameters: FunctionDefinitionParametersType0 | None | Unset = UNSET
    strict: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.function_definition_parameters_type_0 import FunctionDefinitionParametersType0

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        parameters: dict[str, Any] | None | Unset
        if isinstance(self.parameters, Unset):
            parameters = UNSET
        elif isinstance(self.parameters, FunctionDefinitionParametersType0):
            parameters = self.parameters.to_dict()
        else:
            parameters = self.parameters

        strict: bool | None | Unset
        if isinstance(self.strict, Unset):
            strict = UNSET
        else:
            strict = self.strict

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
            }
        )
        if description is not UNSET:
            field_dict["description"] = description
        if parameters is not UNSET:
            field_dict["parameters"] = parameters
        if strict is not UNSET:
            field_dict["strict"] = strict

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.function_definition_parameters_type_0 import FunctionDefinitionParametersType0

        d = dict(src_dict)
        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_parameters(data: object) -> FunctionDefinitionParametersType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                parameters_type_0 = FunctionDefinitionParametersType0.from_dict(data)

                return parameters_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FunctionDefinitionParametersType0 | None | Unset, data)

        parameters = _parse_parameters(d.pop("parameters", UNSET))

        def _parse_strict(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        strict = _parse_strict(d.pop("strict", UNSET))

        function_definition = cls(
            name=name,
            description=description,
            parameters=parameters,
            strict=strict,
        )

        function_definition.additional_properties = d
        return function_definition

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
