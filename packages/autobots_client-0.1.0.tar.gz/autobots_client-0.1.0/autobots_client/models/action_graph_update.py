from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.action_graph_update_graph_type_0 import ActionGraphUpdateGraphType0
    from ..models.action_graph_update_node_details_type_0 import ActionGraphUpdateNodeDetailsType0
    from ..models.action_graph_update_nodes_type_0 import ActionGraphUpdateNodesType0
    from ..models.action_graph_update_output_type_0 import ActionGraphUpdateOutputType0
    from ..models.text_obj import TextObj


T = TypeVar("T", bound="ActionGraphUpdate")


@_attrs_define
class ActionGraphUpdate:
    """
    Attributes:
        name (None | str | Unset):
        version (float | None | Unset):
        description (None | str | Unset):
        user_manual (None | str | Unset):
        nodes (ActionGraphUpdateNodesType0 | None | Unset): map of node to action
        node_details (ActionGraphUpdateNodeDetailsType0 | None | Unset): map of nodeId to Node
        graph (ActionGraphUpdateGraphType0 | None | Unset): map of node to nodes
        start_node_id (None | str | Unset):
        input_ (None | TextObj | Unset):
        output (ActionGraphUpdateOutputType0 | None | Unset):
        is_saved (bool | None | Unset):
        is_published (bool | None | Unset):
        shared_with (list[str] | None | Unset):
        time_saved_per_file (float | None | Unset): Time saved per file in hours for dashboard workflow calculations
            Default: 0.1.
        dollar_cost_per_hour (float | None | Unset): Dollar cost per hour for dashboard workflow calculations Default:
            50.0.
    """

    name: None | str | Unset = UNSET
    version: float | None | Unset = UNSET
    description: None | str | Unset = UNSET
    user_manual: None | str | Unset = UNSET
    nodes: ActionGraphUpdateNodesType0 | None | Unset = UNSET
    node_details: ActionGraphUpdateNodeDetailsType0 | None | Unset = UNSET
    graph: ActionGraphUpdateGraphType0 | None | Unset = UNSET
    start_node_id: None | str | Unset = UNSET
    input_: None | TextObj | Unset = UNSET
    output: ActionGraphUpdateOutputType0 | None | Unset = UNSET
    is_saved: bool | None | Unset = UNSET
    is_published: bool | None | Unset = UNSET
    shared_with: list[str] | None | Unset = UNSET
    time_saved_per_file: float | None | Unset = 0.1
    dollar_cost_per_hour: float | None | Unset = 50.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.action_graph_update_graph_type_0 import ActionGraphUpdateGraphType0
        from ..models.action_graph_update_node_details_type_0 import ActionGraphUpdateNodeDetailsType0
        from ..models.action_graph_update_nodes_type_0 import ActionGraphUpdateNodesType0
        from ..models.action_graph_update_output_type_0 import ActionGraphUpdateOutputType0
        from ..models.text_obj import TextObj

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        version: float | None | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        user_manual: None | str | Unset
        if isinstance(self.user_manual, Unset):
            user_manual = UNSET
        else:
            user_manual = self.user_manual

        nodes: dict[str, Any] | None | Unset
        if isinstance(self.nodes, Unset):
            nodes = UNSET
        elif isinstance(self.nodes, ActionGraphUpdateNodesType0):
            nodes = self.nodes.to_dict()
        else:
            nodes = self.nodes

        node_details: dict[str, Any] | None | Unset
        if isinstance(self.node_details, Unset):
            node_details = UNSET
        elif isinstance(self.node_details, ActionGraphUpdateNodeDetailsType0):
            node_details = self.node_details.to_dict()
        else:
            node_details = self.node_details

        graph: dict[str, Any] | None | Unset
        if isinstance(self.graph, Unset):
            graph = UNSET
        elif isinstance(self.graph, ActionGraphUpdateGraphType0):
            graph = self.graph.to_dict()
        else:
            graph = self.graph

        start_node_id: None | str | Unset
        if isinstance(self.start_node_id, Unset):
            start_node_id = UNSET
        else:
            start_node_id = self.start_node_id

        input_: dict[str, Any] | None | Unset
        if isinstance(self.input_, Unset):
            input_ = UNSET
        elif isinstance(self.input_, TextObj):
            input_ = self.input_.to_dict()
        else:
            input_ = self.input_

        output: dict[str, Any] | None | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        elif isinstance(self.output, ActionGraphUpdateOutputType0):
            output = self.output.to_dict()
        else:
            output = self.output

        is_saved: bool | None | Unset
        if isinstance(self.is_saved, Unset):
            is_saved = UNSET
        else:
            is_saved = self.is_saved

        is_published: bool | None | Unset
        if isinstance(self.is_published, Unset):
            is_published = UNSET
        else:
            is_published = self.is_published

        shared_with: list[str] | None | Unset
        if isinstance(self.shared_with, Unset):
            shared_with = UNSET
        elif isinstance(self.shared_with, list):
            shared_with = self.shared_with

        else:
            shared_with = self.shared_with

        time_saved_per_file: float | None | Unset
        if isinstance(self.time_saved_per_file, Unset):
            time_saved_per_file = UNSET
        else:
            time_saved_per_file = self.time_saved_per_file

        dollar_cost_per_hour: float | None | Unset
        if isinstance(self.dollar_cost_per_hour, Unset):
            dollar_cost_per_hour = UNSET
        else:
            dollar_cost_per_hour = self.dollar_cost_per_hour

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if name is not UNSET:
            field_dict["name"] = name
        if version is not UNSET:
            field_dict["version"] = version
        if description is not UNSET:
            field_dict["description"] = description
        if user_manual is not UNSET:
            field_dict["user_manual"] = user_manual
        if nodes is not UNSET:
            field_dict["nodes"] = nodes
        if node_details is not UNSET:
            field_dict["node_details"] = node_details
        if graph is not UNSET:
            field_dict["graph"] = graph
        if start_node_id is not UNSET:
            field_dict["start_node_id"] = start_node_id
        if input_ is not UNSET:
            field_dict["input"] = input_
        if output is not UNSET:
            field_dict["output"] = output
        if is_saved is not UNSET:
            field_dict["is_saved"] = is_saved
        if is_published is not UNSET:
            field_dict["is_published"] = is_published
        if shared_with is not UNSET:
            field_dict["shared_with"] = shared_with
        if time_saved_per_file is not UNSET:
            field_dict["time_saved_per_file"] = time_saved_per_file
        if dollar_cost_per_hour is not UNSET:
            field_dict["dollar_cost_per_hour"] = dollar_cost_per_hour

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_graph_update_graph_type_0 import ActionGraphUpdateGraphType0
        from ..models.action_graph_update_node_details_type_0 import ActionGraphUpdateNodeDetailsType0
        from ..models.action_graph_update_nodes_type_0 import ActionGraphUpdateNodesType0
        from ..models.action_graph_update_output_type_0 import ActionGraphUpdateOutputType0
        from ..models.text_obj import TextObj

        d = dict(src_dict)

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))

        def _parse_version(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        version = _parse_version(d.pop("version", UNSET))

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))

        def _parse_user_manual(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_manual = _parse_user_manual(d.pop("user_manual", UNSET))

        def _parse_nodes(data: object) -> ActionGraphUpdateNodesType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                nodes_type_0 = ActionGraphUpdateNodesType0.from_dict(data)

                return nodes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ActionGraphUpdateNodesType0 | None | Unset, data)

        nodes = _parse_nodes(d.pop("nodes", UNSET))

        def _parse_node_details(data: object) -> ActionGraphUpdateNodeDetailsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                node_details_type_0 = ActionGraphUpdateNodeDetailsType0.from_dict(data)

                return node_details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ActionGraphUpdateNodeDetailsType0 | None | Unset, data)

        node_details = _parse_node_details(d.pop("node_details", UNSET))

        def _parse_graph(data: object) -> ActionGraphUpdateGraphType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                graph_type_0 = ActionGraphUpdateGraphType0.from_dict(data)

                return graph_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ActionGraphUpdateGraphType0 | None | Unset, data)

        graph = _parse_graph(d.pop("graph", UNSET))

        def _parse_start_node_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        start_node_id = _parse_start_node_id(d.pop("start_node_id", UNSET))

        def _parse_input_(data: object) -> None | TextObj | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                input_type_0 = TextObj.from_dict(data)

                return input_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TextObj | Unset, data)

        input_ = _parse_input_(d.pop("input", UNSET))

        def _parse_output(data: object) -> ActionGraphUpdateOutputType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_type_0 = ActionGraphUpdateOutputType0.from_dict(data)

                return output_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ActionGraphUpdateOutputType0 | None | Unset, data)

        output = _parse_output(d.pop("output", UNSET))

        def _parse_is_saved(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_saved = _parse_is_saved(d.pop("is_saved", UNSET))

        def _parse_is_published(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_published = _parse_is_published(d.pop("is_published", UNSET))

        def _parse_shared_with(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                shared_with_type_0 = cast(list[str], data)

                return shared_with_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        shared_with = _parse_shared_with(d.pop("shared_with", UNSET))

        def _parse_time_saved_per_file(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        time_saved_per_file = _parse_time_saved_per_file(d.pop("time_saved_per_file", UNSET))

        def _parse_dollar_cost_per_hour(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        dollar_cost_per_hour = _parse_dollar_cost_per_hour(d.pop("dollar_cost_per_hour", UNSET))

        action_graph_update = cls(
            name=name,
            version=version,
            description=description,
            user_manual=user_manual,
            nodes=nodes,
            node_details=node_details,
            graph=graph,
            start_node_id=start_node_id,
            input_=input_,
            output=output,
            is_saved=is_saved,
            is_published=is_published,
            shared_with=shared_with,
            time_saved_per_file=time_saved_per_file,
            dollar_cost_per_hour=dollar_cost_per_hour,
        )

        action_graph_update.additional_properties = d
        return action_graph_update

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
