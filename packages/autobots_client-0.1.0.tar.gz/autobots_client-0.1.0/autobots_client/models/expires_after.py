from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="ExpiresAfter")


@_attrs_define
class ExpiresAfter:
    """The expiration policy for a vector store.

    Attributes:
        anchor (Literal['last_active_at']):
        days (int):
    """

    anchor: Literal["last_active_at"]
    days: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        anchor = self.anchor

        days = self.days

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "anchor": anchor,
                "days": days,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        anchor = cast(Literal["last_active_at"], d.pop("anchor"))
        if anchor != "last_active_at":
            raise ValueError(f"anchor must match const 'last_active_at', got '{anchor}'")

        days = d.pop("days")

        expires_after = cls(
            anchor=anchor,
            days=days,
        )

        expires_after.additional_properties = d
        return expires_after

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
