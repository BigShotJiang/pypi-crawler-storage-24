from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.app_types import AppTypes
from ..types import UNSET, Unset

T = TypeVar("T", bound="AppAuthRead")


@_attrs_define
class AppAuthRead:
    """
    Attributes:
        id (None | str | Unset):
        app_name (AppTypes | None | Unset):
    """

    id: None | str | Unset = UNSET
    app_name: AppTypes | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        id: None | str | Unset
        if isinstance(self.id, Unset):
            id = UNSET
        else:
            id = self.id

        app_name: None | str | Unset
        if isinstance(self.app_name, Unset):
            app_name = UNSET
        elif isinstance(self.app_name, AppTypes):
            app_name = self.app_name.value
        else:
            app_name = self.app_name

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if id is not UNSET:
            field_dict["id"] = id
        if app_name is not UNSET:
            field_dict["app_name"] = app_name

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)

        def _parse_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        id = _parse_id(d.pop("id", UNSET))

        def _parse_app_name(data: object) -> AppTypes | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                app_name_type_0 = AppTypes(data)

                return app_name_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AppTypes | None | Unset, data)

        app_name = _parse_app_name(d.pop("app_name", UNSET))

        app_auth_read = cls(
            id=id,
            app_name=app_name,
        )

        app_auth_read.additional_properties = d
        return app_auth_read

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
