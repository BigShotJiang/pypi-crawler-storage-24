from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.clone_action_result import CloneActionResult


T = TypeVar("T", bound="CloneActionV1ActionsClonePostResponseCloneActionV1ActionsClonePost")


@_attrs_define
class CloneActionV1ActionsClonePostResponseCloneActionV1ActionsClonePost:
    """ """

    additional_properties: dict[str, list[CloneActionResult]] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:

        field_dict: dict[str, Any] = {}
        for prop_name, prop in self.additional_properties.items():
            field_dict[prop_name] = []
            for additional_property_item_data in prop:
                additional_property_item = additional_property_item_data.to_dict()
                field_dict[prop_name].append(additional_property_item)

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.clone_action_result import CloneActionResult

        d = dict(src_dict)
        clone_action_v1_actions_clone_post_response_clone_action_v1_actions_clone_post = cls()

        additional_properties = {}
        for prop_name, prop_dict in d.items():
            additional_property = []
            _additional_property = prop_dict
            for additional_property_item_data in _additional_property:
                additional_property_item = CloneActionResult.from_dict(additional_property_item_data)

                additional_property.append(additional_property_item)

            additional_properties[prop_name] = additional_property

        clone_action_v1_actions_clone_post_response_clone_action_v1_actions_clone_post.additional_properties = (
            additional_properties
        )
        return clone_action_v1_actions_clone_post_response_clone_action_v1_actions_clone_post

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> list[CloneActionResult]:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: list[CloneActionResult]) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
