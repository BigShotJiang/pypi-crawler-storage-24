from enum import Enum


class ChatCompletionAudioParamVoiceType1(str, Enum):
    ALLOY = "alloy"
    ASH = "ash"
    BALLAD = "ballad"
    CEDAR = "cedar"
    CORAL = "coral"
    ECHO = "echo"
    MARIN = "marin"
    SAGE = "sage"
    SHIMMER = "shimmer"
    VERSE = "verse"

    def __str__(self) -> str:
        return str(self.value)
