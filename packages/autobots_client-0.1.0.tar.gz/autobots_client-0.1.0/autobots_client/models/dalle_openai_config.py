from __future__ import annotations

from collections.abc import Mapping
from typing import Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.dalle_openai_config_provider import DalleOpenaiConfigProvider
from ..models.dalle_openai_config_quality import DalleOpenaiConfigQuality
from ..models.dalle_openai_config_response_format_type_0 import DalleOpenaiConfigResponseFormatType0
from ..models.dalle_openai_config_size_type_0 import DalleOpenaiConfigSizeType0
from ..models.dalle_openai_config_style_type_0 import DalleOpenaiConfigStyleType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="DalleOpenaiConfig")


@_attrs_define
class DalleOpenaiConfig:
    """
    Attributes:
        prompt (str):
        provider (DalleOpenaiConfigProvider):
        model (Literal['dall-e-3'] | Unset):  Default: 'dall-e-3'.
        n (int | None | Unset):  Default: 1.
        quality (DalleOpenaiConfigQuality | Unset):  Default: DalleOpenaiConfigQuality.STANDARD.
        response_format (DalleOpenaiConfigResponseFormatType0 | None | Unset):  Default:
            DalleOpenaiConfigResponseFormatType0.URL.
        size (DalleOpenaiConfigSizeType0 | None | Unset):  Default: DalleOpenaiConfigSizeType0.VALUE_2.
        style (DalleOpenaiConfigStyleType0 | None | Unset):  Default: DalleOpenaiConfigStyleType0.NATURAL.
        user (str | Unset):  Default: ''.
    """

    prompt: str
    provider: DalleOpenaiConfigProvider
    model: Literal["dall-e-3"] | Unset = "dall-e-3"
    n: int | None | Unset = 1
    quality: DalleOpenaiConfigQuality | Unset = DalleOpenaiConfigQuality.STANDARD
    response_format: DalleOpenaiConfigResponseFormatType0 | None | Unset = DalleOpenaiConfigResponseFormatType0.URL
    size: DalleOpenaiConfigSizeType0 | None | Unset = DalleOpenaiConfigSizeType0.VALUE_2
    style: DalleOpenaiConfigStyleType0 | None | Unset = DalleOpenaiConfigStyleType0.NATURAL
    user: str | Unset = ""
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        prompt = self.prompt

        provider = self.provider.value

        model = self.model

        n: int | None | Unset
        if isinstance(self.n, Unset):
            n = UNSET
        else:
            n = self.n

        quality: str | Unset = UNSET
        if not isinstance(self.quality, Unset):
            quality = self.quality.value

        response_format: None | str | Unset
        if isinstance(self.response_format, Unset):
            response_format = UNSET
        elif isinstance(self.response_format, DalleOpenaiConfigResponseFormatType0):
            response_format = self.response_format.value
        else:
            response_format = self.response_format

        size: None | str | Unset
        if isinstance(self.size, Unset):
            size = UNSET
        elif isinstance(self.size, DalleOpenaiConfigSizeType0):
            size = self.size.value
        else:
            size = self.size

        style: None | str | Unset
        if isinstance(self.style, Unset):
            style = UNSET
        elif isinstance(self.style, DalleOpenaiConfigStyleType0):
            style = self.style.value
        else:
            style = self.style

        user = self.user

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "prompt": prompt,
                "provider": provider,
            }
        )
        if model is not UNSET:
            field_dict["model"] = model
        if n is not UNSET:
            field_dict["n"] = n
        if quality is not UNSET:
            field_dict["quality"] = quality
        if response_format is not UNSET:
            field_dict["response_format"] = response_format
        if size is not UNSET:
            field_dict["size"] = size
        if style is not UNSET:
            field_dict["style"] = style
        if user is not UNSET:
            field_dict["user"] = user

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        prompt = d.pop("prompt")

        provider = DalleOpenaiConfigProvider(d.pop("provider"))

        model = cast(Literal["dall-e-3"] | Unset, d.pop("model", UNSET))
        if model != "dall-e-3" and not isinstance(model, Unset):
            raise ValueError(f"model must match const 'dall-e-3', got '{model}'")

        def _parse_n(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        n = _parse_n(d.pop("n", UNSET))

        _quality = d.pop("quality", UNSET)
        quality: DalleOpenaiConfigQuality | Unset
        if isinstance(_quality, Unset):
            quality = UNSET
        else:
            quality = DalleOpenaiConfigQuality(_quality)

        def _parse_response_format(data: object) -> DalleOpenaiConfigResponseFormatType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                response_format_type_0 = DalleOpenaiConfigResponseFormatType0(data)

                return response_format_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DalleOpenaiConfigResponseFormatType0 | None | Unset, data)

        response_format = _parse_response_format(d.pop("response_format", UNSET))

        def _parse_size(data: object) -> DalleOpenaiConfigSizeType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                size_type_0 = DalleOpenaiConfigSizeType0(data)

                return size_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DalleOpenaiConfigSizeType0 | None | Unset, data)

        size = _parse_size(d.pop("size", UNSET))

        def _parse_style(data: object) -> DalleOpenaiConfigStyleType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                style_type_0 = DalleOpenaiConfigStyleType0(data)

                return style_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DalleOpenaiConfigStyleType0 | None | Unset, data)

        style = _parse_style(d.pop("style", UNSET))

        user = d.pop("user", UNSET)

        dalle_openai_config = cls(
            prompt=prompt,
            provider=provider,
            model=model,
            n=n,
            quality=quality,
            response_format=response_format,
            size=size,
            style=style,
            user=user,
        )

        dalle_openai_config.additional_properties = d
        return dalle_openai_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
