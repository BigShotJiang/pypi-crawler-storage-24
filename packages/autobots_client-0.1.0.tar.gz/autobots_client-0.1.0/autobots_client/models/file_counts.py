from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="FileCounts")


@_attrs_define
class FileCounts:
    """
    Attributes:
        cancelled (int):
        completed (int):
        failed (int):
        in_progress (int):
        total (int):
    """

    cancelled: int
    completed: int
    failed: int
    in_progress: int
    total: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        cancelled = self.cancelled

        completed = self.completed

        failed = self.failed

        in_progress = self.in_progress

        total = self.total

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "cancelled": cancelled,
                "completed": completed,
                "failed": failed,
                "in_progress": in_progress,
                "total": total,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        cancelled = d.pop("cancelled")

        completed = d.pop("completed")

        failed = d.pop("failed")

        in_progress = d.pop("in_progress")

        total = d.pop("total")

        file_counts = cls(
            cancelled=cancelled,
            completed=completed,
            failed=failed,
            in_progress=in_progress,
            total=total,
        )

        file_counts.additional_properties = d
        return file_counts

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
