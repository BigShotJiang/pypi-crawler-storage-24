from enum import Enum


class CronScheduleMonthMode(str, Enum):
    AT = "at"
    EVERY = "every"

    def __str__(self) -> str:
        return str(self.value)
