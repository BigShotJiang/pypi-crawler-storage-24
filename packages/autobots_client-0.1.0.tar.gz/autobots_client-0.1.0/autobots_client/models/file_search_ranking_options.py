from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.file_search_ranking_options_ranker_type_0 import FileSearchRankingOptionsRankerType0
from ..types import UNSET, Unset

T = TypeVar("T", bound="FileSearchRankingOptions")


@_attrs_define
class FileSearchRankingOptions:
    """The ranking options for the file search.

    If not specified, the file search tool will use the `auto` ranker and a score_threshold of 0.

    See the [file search tool documentation](https://platform.openai.com/docs/assistants/tools/file-search#customizing-
    file-search-settings) for more information.

        Attributes:
            score_threshold (float):
            ranker (FileSearchRankingOptionsRankerType0 | None | Unset):
    """

    score_threshold: float
    ranker: FileSearchRankingOptionsRankerType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        score_threshold = self.score_threshold

        ranker: None | str | Unset
        if isinstance(self.ranker, Unset):
            ranker = UNSET
        elif isinstance(self.ranker, FileSearchRankingOptionsRankerType0):
            ranker = self.ranker.value
        else:
            ranker = self.ranker

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "score_threshold": score_threshold,
            }
        )
        if ranker is not UNSET:
            field_dict["ranker"] = ranker

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        score_threshold = d.pop("score_threshold")

        def _parse_ranker(data: object) -> FileSearchRankingOptionsRankerType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                ranker_type_0 = FileSearchRankingOptionsRankerType0(data)

                return ranker_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(FileSearchRankingOptionsRankerType0 | None | Unset, data)

        ranker = _parse_ranker(d.pop("ranker", UNSET))

        file_search_ranking_options = cls(
            score_threshold=score_threshold,
            ranker=ranker,
        )

        file_search_ranking_options.additional_properties = d
        return file_search_ranking_options

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
