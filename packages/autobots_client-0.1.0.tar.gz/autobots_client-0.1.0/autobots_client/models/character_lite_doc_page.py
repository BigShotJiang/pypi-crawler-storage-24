from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.character_lite_doc import CharacterLiteDoc


T = TypeVar("T", bound="CharacterLiteDocPage")


@_attrs_define
class CharacterLiteDocPage:
    """
    Attributes:
        docs (list[CharacterLiteDoc]):
        total_count (int):
        limit (int):
        offset (int):
    """

    docs: list[CharacterLiteDoc]
    total_count: int
    limit: int
    offset: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        docs = []
        for docs_item_data in self.docs:
            docs_item = docs_item_data.to_dict()
            docs.append(docs_item)

        total_count = self.total_count

        limit = self.limit

        offset = self.offset

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "docs": docs,
                "total_count": total_count,
                "limit": limit,
                "offset": offset,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.character_lite_doc import CharacterLiteDoc

        d = dict(src_dict)
        docs = []
        _docs = d.pop("docs")
        for docs_item_data in _docs:
            docs_item = CharacterLiteDoc.from_dict(docs_item_data)

            docs.append(docs_item)

        total_count = d.pop("total_count")

        limit = d.pop("limit")

        offset = d.pop("offset")

        character_lite_doc_page = cls(
            docs=docs,
            total_count=total_count,
            limit=limit,
            offset=offset,
        )

        character_lite_doc_page.additional_properties = d
        return character_lite_doc_page

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
