from enum import Enum


class CreateVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesPostOpenaiProvider(str, Enum):
    AZURE = "azure"
    OPENAI = "openai"

    def __str__(self) -> str:
        return str(self.value)
