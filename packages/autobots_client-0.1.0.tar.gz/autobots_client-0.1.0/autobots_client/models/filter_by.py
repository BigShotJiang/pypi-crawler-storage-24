from enum import Enum


class FilterBy(str, Enum):
    AGENT = "agent"
    DEPARTMENT = "department"
    WORKFLOW = "workflow"

    def __str__(self) -> str:
        return str(self.value)
