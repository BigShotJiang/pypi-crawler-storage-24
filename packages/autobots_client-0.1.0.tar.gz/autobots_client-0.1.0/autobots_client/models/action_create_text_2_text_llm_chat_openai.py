from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.action_type import ActionType
from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.action_result import ActionResult
    from ..models.llm_chat_openai_config import LlmChatOpenaiConfig
    from ..models.text_obj import TextObj
    from ..models.text_objs import TextObjs


T = TypeVar("T", bound="ActionCreateText2TextLlmChatOpenai")


@_attrs_define
class ActionCreateText2TextLlmChatOpenai:
    """
    Attributes:
        name (str):
        config (LlmChatOpenaiConfig):
        version (float | Unset):  Default: 0.0.
        description (str | Unset):  Default: ''.
        user_manual (str | Unset):  Default: ''.
        type_ (ActionType | Unset):
        is_saved (bool | Unset):  Default: False.
        results (list[ActionResult] | None | Unset):
        input_ (None | TextObj | Unset):
        output (None | TextObjs | Unset):
        is_published (bool | Unset):  Default: False.
        shared_with (list[str] | Unset):
        time_saved_per_run (float | None | Unset): Time saved per run in hours for dashboard agent calculations Default:
            0.5.
        dollar_cost_per_hour (float | None | Unset): Dollar cost per hour for dashboard agent calculations Default:
            50.0.
    """

    name: str
    config: LlmChatOpenaiConfig
    version: float | Unset = 0.0
    description: str | Unset = ""
    user_manual: str | Unset = ""
    type_: ActionType | Unset = UNSET
    is_saved: bool | Unset = False
    results: list[ActionResult] | None | Unset = UNSET
    input_: None | TextObj | Unset = UNSET
    output: None | TextObjs | Unset = UNSET
    is_published: bool | Unset = False
    shared_with: list[str] | Unset = UNSET
    time_saved_per_run: float | None | Unset = 0.5
    dollar_cost_per_hour: float | None | Unset = 50.0
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        from ..models.text_obj import TextObj
        from ..models.text_objs import TextObjs

        name = self.name

        config = self.config.to_dict()

        version = self.version

        description = self.description

        user_manual = self.user_manual

        type_: str | Unset = UNSET
        if not isinstance(self.type_, Unset):
            type_ = self.type_.value

        is_saved = self.is_saved

        results: list[dict[str, Any]] | None | Unset
        if isinstance(self.results, Unset):
            results = UNSET
        elif isinstance(self.results, list):
            results = []
            for results_type_0_item_data in self.results:
                results_type_0_item = results_type_0_item_data.to_dict()
                results.append(results_type_0_item)

        else:
            results = self.results

        input_: dict[str, Any] | None | Unset
        if isinstance(self.input_, Unset):
            input_ = UNSET
        elif isinstance(self.input_, TextObj):
            input_ = self.input_.to_dict()
        else:
            input_ = self.input_

        output: dict[str, Any] | None | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        elif isinstance(self.output, TextObjs):
            output = self.output.to_dict()
        else:
            output = self.output

        is_published = self.is_published

        shared_with: list[str] | Unset = UNSET
        if not isinstance(self.shared_with, Unset):
            shared_with = self.shared_with

        time_saved_per_run: float | None | Unset
        if isinstance(self.time_saved_per_run, Unset):
            time_saved_per_run = UNSET
        else:
            time_saved_per_run = self.time_saved_per_run

        dollar_cost_per_hour: float | None | Unset
        if isinstance(self.dollar_cost_per_hour, Unset):
            dollar_cost_per_hour = UNSET
        else:
            dollar_cost_per_hour = self.dollar_cost_per_hour

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "name": name,
                "config": config,
            }
        )
        if version is not UNSET:
            field_dict["version"] = version
        if description is not UNSET:
            field_dict["description"] = description
        if user_manual is not UNSET:
            field_dict["user_manual"] = user_manual
        if type_ is not UNSET:
            field_dict["type"] = type_
        if is_saved is not UNSET:
            field_dict["is_saved"] = is_saved
        if results is not UNSET:
            field_dict["results"] = results
        if input_ is not UNSET:
            field_dict["input"] = input_
        if output is not UNSET:
            field_dict["output"] = output
        if is_published is not UNSET:
            field_dict["is_published"] = is_published
        if shared_with is not UNSET:
            field_dict["shared_with"] = shared_with
        if time_saved_per_run is not UNSET:
            field_dict["time_saved_per_run"] = time_saved_per_run
        if dollar_cost_per_hour is not UNSET:
            field_dict["dollar_cost_per_hour"] = dollar_cost_per_hour

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.action_result import ActionResult
        from ..models.llm_chat_openai_config import LlmChatOpenaiConfig
        from ..models.text_obj import TextObj
        from ..models.text_objs import TextObjs

        d = dict(src_dict)
        name = d.pop("name")

        config = LlmChatOpenaiConfig.from_dict(d.pop("config"))

        version = d.pop("version", UNSET)

        description = d.pop("description", UNSET)

        user_manual = d.pop("user_manual", UNSET)

        _type_ = d.pop("type", UNSET)
        type_: ActionType | Unset
        if isinstance(_type_, Unset):
            type_ = UNSET
        else:
            type_ = ActionType(_type_)

        is_saved = d.pop("is_saved", UNSET)

        def _parse_results(data: object) -> list[ActionResult] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                results_type_0 = []
                _results_type_0 = data
                for results_type_0_item_data in _results_type_0:
                    results_type_0_item = ActionResult.from_dict(results_type_0_item_data)

                    results_type_0.append(results_type_0_item)

                return results_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ActionResult] | None | Unset, data)

        results = _parse_results(d.pop("results", UNSET))

        def _parse_input_(data: object) -> None | TextObj | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                input_type_0 = TextObj.from_dict(data)

                return input_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TextObj | Unset, data)

        input_ = _parse_input_(d.pop("input", UNSET))

        def _parse_output(data: object) -> None | TextObjs | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_type_0 = TextObjs.from_dict(data)

                return output_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TextObjs | Unset, data)

        output = _parse_output(d.pop("output", UNSET))

        is_published = d.pop("is_published", UNSET)

        shared_with = cast(list[str], d.pop("shared_with", UNSET))

        def _parse_time_saved_per_run(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        time_saved_per_run = _parse_time_saved_per_run(d.pop("time_saved_per_run", UNSET))

        def _parse_dollar_cost_per_hour(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        dollar_cost_per_hour = _parse_dollar_cost_per_hour(d.pop("dollar_cost_per_hour", UNSET))

        action_create_text_2_text_llm_chat_openai = cls(
            name=name,
            config=config,
            version=version,
            description=description,
            user_manual=user_manual,
            type_=type_,
            is_saved=is_saved,
            results=results,
            input_=input_,
            output=output,
            is_published=is_published,
            shared_with=shared_with,
            time_saved_per_run=time_saved_per_run,
            dollar_cost_per_hour=dollar_cost_per_hour,
        )

        action_create_text_2_text_llm_chat_openai.additional_properties = d
        return action_create_text_2_text_llm_chat_openai

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
