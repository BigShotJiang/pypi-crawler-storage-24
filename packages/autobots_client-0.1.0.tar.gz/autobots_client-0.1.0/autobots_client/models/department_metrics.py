from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

T = TypeVar("T", bound="DepartmentMetrics")


@_attrs_define
class DepartmentMetrics:
    """Department-wise metrics

    Attributes:
        department_name (str):
        total_agents (int):
        active_workflows (int):
        time_saved_hours (float):
        dollars_saved (float):
        roi_percentage (float):
    """

    department_name: str
    total_agents: int
    active_workflows: int
    time_saved_hours: float
    dollars_saved: float
    roi_percentage: float
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        department_name = self.department_name

        total_agents = self.total_agents

        active_workflows = self.active_workflows

        time_saved_hours = self.time_saved_hours

        dollars_saved = self.dollars_saved

        roi_percentage = self.roi_percentage

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "department_name": department_name,
                "total_agents": total_agents,
                "active_workflows": active_workflows,
                "time_saved_hours": time_saved_hours,
                "dollars_saved": dollars_saved,
                "roi_percentage": roi_percentage,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        department_name = d.pop("department_name")

        total_agents = d.pop("total_agents")

        active_workflows = d.pop("active_workflows")

        time_saved_hours = d.pop("time_saved_hours")

        dollars_saved = d.pop("dollars_saved")

        roi_percentage = d.pop("roi_percentage")

        department_metrics = cls(
            department_name=department_name,
            total_agents=total_agents,
            active_workflows=active_workflows,
            time_saved_hours=time_saved_hours,
            dollars_saved=dollars_saved,
            roi_percentage=roi_percentage,
        )

        department_metrics.additional_properties = d
        return department_metrics

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
