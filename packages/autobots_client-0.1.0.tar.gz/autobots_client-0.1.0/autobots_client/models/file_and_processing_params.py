from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.partition_parameters_params import PartitionParametersParams


T = TypeVar("T", bound="FileAndProcessingParams")


@_attrs_define
class FileAndProcessingParams:
    """
    Attributes:
        filename (str):
        processing_params (PartitionParametersParams):
    """

    filename: str
    processing_params: PartitionParametersParams
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        filename = self.filename

        processing_params = self.processing_params.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "filename": filename,
                "processing_params": processing_params,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.partition_parameters_params import PartitionParametersParams

        d = dict(src_dict)
        filename = d.pop("filename")

        processing_params = PartitionParametersParams.from_dict(d.pop("processing_params"))

        file_and_processing_params = cls(
            filename=filename,
            processing_params=processing_params,
        )

        file_and_processing_params.additional_properties = d
        return file_and_processing_params

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
