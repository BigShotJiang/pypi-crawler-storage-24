from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

if TYPE_CHECKING:
    from ..models.chat_completion_content_part_text_param import ChatCompletionContentPartTextParam


T = TypeVar("T", bound="ChatCompletionPredictionContentParam")


@_attrs_define
class ChatCompletionPredictionContentParam:
    """Static predicted output content, such as the content of a text file that is
    being regenerated.

        Attributes:
            content (list[ChatCompletionContentPartTextParam] | str):
            type_ (Literal['content']):
    """

    content: list[ChatCompletionContentPartTextParam] | str
    type_: Literal["content"]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        content: list[dict[str, Any]] | str
        if isinstance(self.content, list):
            content = []
            for content_type_1_item_data in self.content:
                content_type_1_item = content_type_1_item_data.to_dict()
                content.append(content_type_1_item)

        else:
            content = self.content

        type_ = self.type_

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "content": content,
                "type": type_,
            }
        )

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.chat_completion_content_part_text_param import ChatCompletionContentPartTextParam

        d = dict(src_dict)

        def _parse_content(data: object) -> list[ChatCompletionContentPartTextParam] | str:
            try:
                if not isinstance(data, list):
                    raise TypeError()
                content_type_1 = []
                _content_type_1 = data
                for content_type_1_item_data in _content_type_1:
                    content_type_1_item = ChatCompletionContentPartTextParam.from_dict(content_type_1_item_data)

                    content_type_1.append(content_type_1_item)

                return content_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ChatCompletionContentPartTextParam] | str, data)

        content = _parse_content(d.pop("content"))

        type_ = cast(Literal["content"], d.pop("type"))
        if type_ != "content":
            raise ValueError(f"type must match const 'content', got '{type_}'")

        chat_completion_prediction_content_param = cls(
            content=content,
            type_=type_,
        )

        chat_completion_prediction_content_param.additional_properties = d
        return chat_completion_prediction_content_param

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
