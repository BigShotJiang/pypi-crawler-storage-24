from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ADPClientCredentialsRequest")


@_attrs_define
class ADPClientCredentialsRequest:
    r""" Request model for ADP client credentials authentication.

    ADP requires Mutual SSL (mTLS) Authentication:
    - client_id: Your ADP client ID from ADP Developer Portal
    - client_secret: Your ADP client secret
    - ssl_cert_path: Path to SSL certificate file (PEM or PFX format)
    - ssl_key_path: Path to private key file (optional if embedded in cert)

    Supported path formats for certificates:
    - Local file path: /path/to/cert.pem
    - S3 URI: s3://bucket-name/path/to/cert.pem
    - S3 HTTPS URL: https://bucket-name.s3.region.amazonaws.com/path/to/cert.pem

    Certificate Setup:
    1. Obtain SSL certificate and private key from:
       - ADP Partners: Developer Self-Service Portal (automated)
       - ADP Clients: ADP Certificate Signing Tool (manual CSR)
       - API Central Users: API Central (automated)

    2. Upload certificates to S3 (recommended) or provide local paths:
       s3://your-bucket/adp/cert.pem
       s3://your-bucket/adp/key.key

    3. Optionally combine into single PFX file:
       openssl pkcs12 -export -out adp.pfx -name "OrgName Mutual SSL" \
           -inkey private-key.key -in public-certificate.pem

    Note: Certificates are valid for 2 years. ADP sends renewal notices
    60 days before expiration.

        Attributes:
            client_id (str):
            client_secret (str):
            ssl_cert_path (str):
            ssl_key_path (None | str | Unset):
     """

    client_id: str
    client_secret: str
    ssl_cert_path: str
    ssl_key_path: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        client_id = self.client_id

        client_secret = self.client_secret

        ssl_cert_path = self.ssl_cert_path

        ssl_key_path: None | str | Unset
        if isinstance(self.ssl_key_path, Unset):
            ssl_key_path = UNSET
        else:
            ssl_key_path = self.ssl_key_path

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update(
            {
                "client_id": client_id,
                "client_secret": client_secret,
                "ssl_cert_path": ssl_cert_path,
            }
        )
        if ssl_key_path is not UNSET:
            field_dict["ssl_key_path"] = ssl_key_path

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        client_id = d.pop("client_id")

        client_secret = d.pop("client_secret")

        ssl_cert_path = d.pop("ssl_cert_path")

        def _parse_ssl_key_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        ssl_key_path = _parse_ssl_key_path(d.pop("ssl_key_path", UNSET))

        adp_client_credentials_request = cls(
            client_id=client_id,
            client_secret=client_secret,
            ssl_cert_path=ssl_cert_path,
            ssl_key_path=ssl_key_path,
        )

        adp_client_credentials_request.additional_properties = d
        return adp_client_credentials_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
