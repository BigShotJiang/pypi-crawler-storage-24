from enum import Enum


class EventType(str, Enum):
    ACTION_GRAPH_RUN = "action_graph_run"
    ACTION_RUN = "action_run"
    DATASTORE_PUT = "datastore_put"

    def __str__(self) -> str:
        return str(self.value)
