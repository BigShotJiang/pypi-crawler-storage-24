from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.list_vector_stores_v1_openai_storage_vector_stores_list_get_openai_provider import (
    ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider,
)
from ...models.list_vector_stores_v1_openai_storage_vector_stores_list_get_order import (
    ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    openai_provider: ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider,
    limit: int | Unset = 10,
    order: ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder
    | Unset = ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_openai_provider = openai_provider.value
    params["openai_provider"] = json_openai_provider

    params["limit"] = limit

    json_order: str | Unset = UNSET
    if not isinstance(order, Unset):
        json_order = order.value

    params["order"] = json_order

    json_after: None | str | Unset
    if isinstance(after, Unset):
        json_after = UNSET
    else:
        json_after = after
    params["after"] = json_after

    json_before: None | str | Unset
    if isinstance(before, Unset):
        json_before = UNSET
    else:
        json_before = before
    params["before"] = json_before

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/openai_storage/vector_stores/list",
        "params": params,
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | None:
    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    openai_provider: ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider,
    limit: int | Unset = 10,
    order: ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder
    | Unset = ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
) -> Response[HTTPValidationError]:
    """List Vector Stores

    Args:
        openai_provider (ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider):
        limit (int | Unset):  Default: 10.
        order (ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder | Unset):  Default:
            ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC.
        after (None | str | Unset):
        before (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError]
    """

    kwargs = _get_kwargs(
        openai_provider=openai_provider,
        limit=limit,
        order=order,
        after=after,
        before=before,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    openai_provider: ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider,
    limit: int | Unset = 10,
    order: ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder
    | Unset = ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
) -> HTTPValidationError | None:
    """List Vector Stores

    Args:
        openai_provider (ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider):
        limit (int | Unset):  Default: 10.
        order (ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder | Unset):  Default:
            ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC.
        after (None | str | Unset):
        before (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError
    """

    return sync_detailed(
        client=client,
        openai_provider=openai_provider,
        limit=limit,
        order=order,
        after=after,
        before=before,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    openai_provider: ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider,
    limit: int | Unset = 10,
    order: ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder
    | Unset = ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
) -> Response[HTTPValidationError]:
    """List Vector Stores

    Args:
        openai_provider (ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider):
        limit (int | Unset):  Default: 10.
        order (ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder | Unset):  Default:
            ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC.
        after (None | str | Unset):
        before (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError]
    """

    kwargs = _get_kwargs(
        openai_provider=openai_provider,
        limit=limit,
        order=order,
        after=after,
        before=before,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    openai_provider: ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider,
    limit: int | Unset = 10,
    order: ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder
    | Unset = ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
) -> HTTPValidationError | None:
    """List Vector Stores

    Args:
        openai_provider (ListVectorStoresV1OpenaiStorageVectorStoresListGetOpenaiProvider):
        limit (int | Unset):  Default: 10.
        order (ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder | Unset):  Default:
            ListVectorStoresV1OpenaiStorageVectorStoresListGetOrder.DESC.
        after (None | str | Unset):
        before (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            openai_provider=openai_provider,
            limit=limit,
            order=order,
            after=after,
            before=before,
        )
    ).parsed
