from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.delete_vector_store_file import DeleteVectorStoreFile
from ...models.delete_vector_store_files_v1_openai_storage_vector_store_file_batches_delete_openai_provider import (
    DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider,
)
from ...models.http_validation_error import HTTPValidationError
from ...models.vector_store_file_deleted import VectorStoreFileDeleted
from ...types import UNSET, Response


def _get_kwargs(
    *,
    body: DeleteVectorStoreFile,
    openai_provider: DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_openai_provider = openai_provider.value
    params["openai_provider"] = json_openai_provider

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/openai_storage/vector_store_file_batches/",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | VectorStoreFileDeleted | None:
    if response.status_code == 200:
        response_200 = VectorStoreFileDeleted.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | VectorStoreFileDeleted]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: DeleteVectorStoreFile,
    openai_provider: DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider,
) -> Response[HTTPValidationError | VectorStoreFileDeleted]:
    """Delete Vector Store Files

    Args:
        openai_provider
            (DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider):
        body (DeleteVectorStoreFile):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VectorStoreFileDeleted]
    """

    kwargs = _get_kwargs(
        body=body,
        openai_provider=openai_provider,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: DeleteVectorStoreFile,
    openai_provider: DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider,
) -> HTTPValidationError | VectorStoreFileDeleted | None:
    """Delete Vector Store Files

    Args:
        openai_provider
            (DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider):
        body (DeleteVectorStoreFile):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VectorStoreFileDeleted
    """

    return sync_detailed(
        client=client,
        body=body,
        openai_provider=openai_provider,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: DeleteVectorStoreFile,
    openai_provider: DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider,
) -> Response[HTTPValidationError | VectorStoreFileDeleted]:
    """Delete Vector Store Files

    Args:
        openai_provider
            (DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider):
        body (DeleteVectorStoreFile):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | VectorStoreFileDeleted]
    """

    kwargs = _get_kwargs(
        body=body,
        openai_provider=openai_provider,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: DeleteVectorStoreFile,
    openai_provider: DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider,
) -> HTTPValidationError | VectorStoreFileDeleted | None:
    """Delete Vector Store Files

    Args:
        openai_provider
            (DeleteVectorStoreFilesV1OpenaiStorageVectorStoreFileBatchesDeleteOpenaiProvider):
        body (DeleteVectorStoreFile):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | VectorStoreFileDeleted
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            openai_provider=openai_provider,
        )
    ).parsed
