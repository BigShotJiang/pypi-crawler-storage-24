from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.create_vector_store import CreateVectorStore
from ...models.create_vector_store_v1_openai_storage_vector_stores_post_openai_provider import (
    CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    *,
    body: CreateVectorStore,
    openai_provider: CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    json_openai_provider = openai_provider.value
    params["openai_provider"] = json_openai_provider

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/openai_storage/vector_stores/",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> HTTPValidationError | None:
    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateVectorStore,
    openai_provider: CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider,
) -> Response[HTTPValidationError]:
    """Create Vector Store

    Args:
        openai_provider (CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider):
        body (CreateVectorStore):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        openai_provider=openai_provider,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: CreateVectorStore,
    openai_provider: CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider,
) -> HTTPValidationError | None:
    """Create Vector Store

    Args:
        openai_provider (CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider):
        body (CreateVectorStore):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
        openai_provider=openai_provider,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: CreateVectorStore,
    openai_provider: CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider,
) -> Response[HTTPValidationError]:
    """Create Vector Store

    Args:
        openai_provider (CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider):
        body (CreateVectorStore):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        openai_provider=openai_provider,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: CreateVectorStore,
    openai_provider: CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider,
) -> HTTPValidationError | None:
    """Create Vector Store

    Args:
        openai_provider (CreateVectorStoreV1OpenaiStorageVectorStoresPostOpenaiProvider):
        body (CreateVectorStore):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            openai_provider=openai_provider,
        )
    ).parsed
