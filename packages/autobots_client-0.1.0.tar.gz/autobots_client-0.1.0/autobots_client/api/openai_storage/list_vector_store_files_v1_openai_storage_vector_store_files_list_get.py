from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.list_vector_store_files_v1_openai_storage_vector_store_files_list_get_filter_type_0 import (
    ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0,
)
from ...models.list_vector_store_files_v1_openai_storage_vector_store_files_list_get_openai_provider import (
    ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider,
)
from ...models.list_vector_store_files_v1_openai_storage_vector_store_files_list_get_order_type_0 import (
    ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0,
)
from ...models.vector_store_file import VectorStoreFile
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    openai_provider: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider,
    vector_store_id: str,
    limit: int | None | Unset = 10,
    order: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0
    | None
    | Unset = ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
    filter_: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_openai_provider = openai_provider.value
    params["openai_provider"] = json_openai_provider

    params["vector_store_id"] = vector_store_id

    json_limit: int | None | Unset
    if isinstance(limit, Unset):
        json_limit = UNSET
    else:
        json_limit = limit
    params["limit"] = json_limit

    json_order: None | str | Unset
    if isinstance(order, Unset):
        json_order = UNSET
    elif isinstance(order, ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0):
        json_order = order.value
    else:
        json_order = order
    params["order"] = json_order

    json_after: None | str | Unset
    if isinstance(after, Unset):
        json_after = UNSET
    else:
        json_after = after
    params["after"] = json_after

    json_before: None | str | Unset
    if isinstance(before, Unset):
        json_before = UNSET
    else:
        json_before = before
    params["before"] = json_before

    json_filter_: None | str | Unset
    if isinstance(filter_, Unset):
        json_filter_ = UNSET
    elif isinstance(filter_, ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0):
        json_filter_ = filter_.value
    else:
        json_filter_ = filter_
    params["filter"] = json_filter_

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/openai_storage/vector_store_files/list",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[VectorStoreFile] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = VectorStoreFile.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[VectorStoreFile]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    openai_provider: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider,
    vector_store_id: str,
    limit: int | None | Unset = 10,
    order: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0
    | None
    | Unset = ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
    filter_: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None | Unset = UNSET,
) -> Response[HTTPValidationError | list[VectorStoreFile]]:
    """List Vector Store Files

    Args:
        openai_provider
            (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider):
        vector_store_id (str):
        limit (int | None | Unset):  Default: 10.
        order (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0 | None |
            Unset):  Default:
            ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC.
        after (None | str | Unset):
        before (None | str | Unset):
        filter_ (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None |
            Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[VectorStoreFile]]
    """

    kwargs = _get_kwargs(
        openai_provider=openai_provider,
        vector_store_id=vector_store_id,
        limit=limit,
        order=order,
        after=after,
        before=before,
        filter_=filter_,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    openai_provider: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider,
    vector_store_id: str,
    limit: int | None | Unset = 10,
    order: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0
    | None
    | Unset = ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
    filter_: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None | Unset = UNSET,
) -> HTTPValidationError | list[VectorStoreFile] | None:
    """List Vector Store Files

    Args:
        openai_provider
            (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider):
        vector_store_id (str):
        limit (int | None | Unset):  Default: 10.
        order (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0 | None |
            Unset):  Default:
            ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC.
        after (None | str | Unset):
        before (None | str | Unset):
        filter_ (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None |
            Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[VectorStoreFile]
    """

    return sync_detailed(
        client=client,
        openai_provider=openai_provider,
        vector_store_id=vector_store_id,
        limit=limit,
        order=order,
        after=after,
        before=before,
        filter_=filter_,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    openai_provider: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider,
    vector_store_id: str,
    limit: int | None | Unset = 10,
    order: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0
    | None
    | Unset = ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
    filter_: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None | Unset = UNSET,
) -> Response[HTTPValidationError | list[VectorStoreFile]]:
    """List Vector Store Files

    Args:
        openai_provider
            (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider):
        vector_store_id (str):
        limit (int | None | Unset):  Default: 10.
        order (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0 | None |
            Unset):  Default:
            ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC.
        after (None | str | Unset):
        before (None | str | Unset):
        filter_ (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None |
            Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[VectorStoreFile]]
    """

    kwargs = _get_kwargs(
        openai_provider=openai_provider,
        vector_store_id=vector_store_id,
        limit=limit,
        order=order,
        after=after,
        before=before,
        filter_=filter_,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    openai_provider: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider,
    vector_store_id: str,
    limit: int | None | Unset = 10,
    order: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0
    | None
    | Unset = ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC,
    after: None | str | Unset = UNSET,
    before: None | str | Unset = UNSET,
    filter_: ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None | Unset = UNSET,
) -> HTTPValidationError | list[VectorStoreFile] | None:
    """List Vector Store Files

    Args:
        openai_provider
            (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOpenaiProvider):
        vector_store_id (str):
        limit (int | None | Unset):  Default: 10.
        order (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0 | None |
            Unset):  Default:
            ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetOrderType0.DESC.
        after (None | str | Unset):
        before (None | str | Unset):
        filter_ (ListVectorStoreFilesV1OpenaiStorageVectorStoreFilesListGetFilterType0 | None |
            Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[VectorStoreFile]
    """

    return (
        await asyncio_detailed(
            client=client,
            openai_provider=openai_provider,
            vector_store_id=vector_store_id,
            limit=limit,
            order=order,
            after=after,
            before=before,
            filter_=filter_,
        )
    ).parsed
