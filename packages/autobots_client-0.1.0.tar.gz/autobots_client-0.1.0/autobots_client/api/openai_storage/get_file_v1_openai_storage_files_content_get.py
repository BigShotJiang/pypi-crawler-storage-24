from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.get_file_v1_openai_storage_files_content_get_openai_provider import (
    GetFileV1OpenaiStorageFilesContentGetOpenaiProvider,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    *,
    openai_provider: GetFileV1OpenaiStorageFilesContentGetOpenaiProvider,
    file_id: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_openai_provider = openai_provider.value
    params["openai_provider"] = json_openai_provider

    params["file_id"] = file_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/openai_storage/files/content",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | str | None:
    if response.status_code == 200:
        response_200 = cast(str, response.json())
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | str]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    openai_provider: GetFileV1OpenaiStorageFilesContentGetOpenaiProvider,
    file_id: str,
) -> Response[HTTPValidationError | str]:
    """Get File

    Args:
        openai_provider (GetFileV1OpenaiStorageFilesContentGetOpenaiProvider):
        file_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | str]
    """

    kwargs = _get_kwargs(
        openai_provider=openai_provider,
        file_id=file_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    openai_provider: GetFileV1OpenaiStorageFilesContentGetOpenaiProvider,
    file_id: str,
) -> HTTPValidationError | str | None:
    """Get File

    Args:
        openai_provider (GetFileV1OpenaiStorageFilesContentGetOpenaiProvider):
        file_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | str
    """

    return sync_detailed(
        client=client,
        openai_provider=openai_provider,
        file_id=file_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    openai_provider: GetFileV1OpenaiStorageFilesContentGetOpenaiProvider,
    file_id: str,
) -> Response[HTTPValidationError | str]:
    """Get File

    Args:
        openai_provider (GetFileV1OpenaiStorageFilesContentGetOpenaiProvider):
        file_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | str]
    """

    kwargs = _get_kwargs(
        openai_provider=openai_provider,
        file_id=file_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    openai_provider: GetFileV1OpenaiStorageFilesContentGetOpenaiProvider,
    file_id: str,
) -> HTTPValidationError | str | None:
    """Get File

    Args:
        openai_provider (GetFileV1OpenaiStorageFilesContentGetOpenaiProvider):
        file_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | str
    """

    return (
        await asyncio_detailed(
            client=client,
            openai_provider=openai_provider,
            file_id=file_id,
        )
    ).parsed
