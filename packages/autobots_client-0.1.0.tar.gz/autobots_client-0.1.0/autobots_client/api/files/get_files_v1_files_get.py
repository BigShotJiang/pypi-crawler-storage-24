from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.file_meta import FileMeta
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    filename: None | str | Unset = UNSET,
    is_public: bool | None | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_filename: None | str | Unset
    if isinstance(filename, Unset):
        json_filename = UNSET
    else:
        json_filename = filename
    params["filename"] = json_filename

    json_is_public: bool | None | Unset
    if isinstance(is_public, Unset):
        json_is_public = UNSET
    else:
        json_is_public = is_public
    params["is_public"] = json_is_public

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/files/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[FileMeta] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = FileMeta.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[FileMeta]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    filename: None | str | Unset = UNSET,
    is_public: bool | None | Unset = False,
) -> Response[HTTPValidationError | list[FileMeta]]:
    """Get Files

    Args:
        filename (None | str | Unset):
        is_public (bool | None | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[FileMeta]]
    """

    kwargs = _get_kwargs(
        filename=filename,
        is_public=is_public,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    filename: None | str | Unset = UNSET,
    is_public: bool | None | Unset = False,
) -> HTTPValidationError | list[FileMeta] | None:
    """Get Files

    Args:
        filename (None | str | Unset):
        is_public (bool | None | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[FileMeta]
    """

    return sync_detailed(
        client=client,
        filename=filename,
        is_public=is_public,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    filename: None | str | Unset = UNSET,
    is_public: bool | None | Unset = False,
) -> Response[HTTPValidationError | list[FileMeta]]:
    """Get Files

    Args:
        filename (None | str | Unset):
        is_public (bool | None | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[FileMeta]]
    """

    kwargs = _get_kwargs(
        filename=filename,
        is_public=is_public,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    filename: None | str | Unset = UNSET,
    is_public: bool | None | Unset = False,
) -> HTTPValidationError | list[FileMeta] | None:
    """Get Files

    Args:
        filename (None | str | Unset):
        is_public (bool | None | Unset):  Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[FileMeta]
    """

    return (
        await asyncio_detailed(
            client=client,
            filename=filename,
            is_public=is_public,
        )
    ).parsed
