from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.search_result import SearchResult
from ...models.text_obj import TextObj
from ...types import UNSET, Response, Unset


def _get_kwargs(
    collection_name: str,
    *,
    body: TextObj,
    top_k: int | Unset = 10,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["top_k"] = top_k

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/vectorstore/v2/collections/{collection_name}/search".format(
            collection_name=quote(str(collection_name), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[SearchResult] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = SearchResult.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[SearchResult]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    collection_name: str,
    *,
    client: AuthenticatedClient,
    body: TextObj,
    top_k: int | Unset = 10,
) -> Response[HTTPValidationError | list[SearchResult]]:
    """V2 Search Collection

     Search a Weaviate-backed collection

    Args:
        collection_name (str):
        top_k (int | Unset):  Default: 10.
        body (TextObj):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[SearchResult]]
    """

    kwargs = _get_kwargs(
        collection_name=collection_name,
        body=body,
        top_k=top_k,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    collection_name: str,
    *,
    client: AuthenticatedClient,
    body: TextObj,
    top_k: int | Unset = 10,
) -> HTTPValidationError | list[SearchResult] | None:
    """V2 Search Collection

     Search a Weaviate-backed collection

    Args:
        collection_name (str):
        top_k (int | Unset):  Default: 10.
        body (TextObj):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[SearchResult]
    """

    return sync_detailed(
        collection_name=collection_name,
        client=client,
        body=body,
        top_k=top_k,
    ).parsed


async def asyncio_detailed(
    collection_name: str,
    *,
    client: AuthenticatedClient,
    body: TextObj,
    top_k: int | Unset = 10,
) -> Response[HTTPValidationError | list[SearchResult]]:
    """V2 Search Collection

     Search a Weaviate-backed collection

    Args:
        collection_name (str):
        top_k (int | Unset):  Default: 10.
        body (TextObj):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[SearchResult]]
    """

    kwargs = _get_kwargs(
        collection_name=collection_name,
        body=body,
        top_k=top_k,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    collection_name: str,
    *,
    client: AuthenticatedClient,
    body: TextObj,
    top_k: int | Unset = 10,
) -> HTTPValidationError | list[SearchResult] | None:
    """V2 Search Collection

     Search a Weaviate-backed collection

    Args:
        collection_name (str):
        top_k (int | Unset):  Default: 10.
        body (TextObj):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[SearchResult]
    """

    return (
        await asyncio_detailed(
            collection_name=collection_name,
            client=client,
            body=body,
            top_k=top_k,
        )
    ).parsed
