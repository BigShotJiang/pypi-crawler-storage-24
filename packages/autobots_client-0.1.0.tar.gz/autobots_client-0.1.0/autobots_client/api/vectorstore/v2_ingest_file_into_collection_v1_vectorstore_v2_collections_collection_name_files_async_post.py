from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.body_v2_ingest_file_into_collection_v1_vectorstore_v2_collections_collection_name_files_async_post import (
    BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    collection_name: str,
    *,
    body: BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/vectorstore/v2/collections/{collection_name}/files/async".format(
            collection_name=quote(str(collection_name), safe=""),
        ),
    }

    _kwargs["files"] = body.to_multipart()

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    collection_name: str,
    *,
    client: AuthenticatedClient,
    body: BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost,
) -> Response[Any | HTTPValidationError]:
    """V2 Ingest File Into Collection

     Ingest a file into a Weaviate collection

    Args:
        collection_name (str):
        body
            (BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        collection_name=collection_name,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    collection_name: str,
    *,
    client: AuthenticatedClient,
    body: BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost,
) -> Any | HTTPValidationError | None:
    """V2 Ingest File Into Collection

     Ingest a file into a Weaviate collection

    Args:
        collection_name (str):
        body
            (BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        collection_name=collection_name,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    collection_name: str,
    *,
    client: AuthenticatedClient,
    body: BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost,
) -> Response[Any | HTTPValidationError]:
    """V2 Ingest File Into Collection

     Ingest a file into a Weaviate collection

    Args:
        collection_name (str):
        body
            (BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        collection_name=collection_name,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    collection_name: str,
    *,
    client: AuthenticatedClient,
    body: BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost,
) -> Any | HTTPValidationError | None:
    """V2 Ingest File Into Collection

     Ingest a file into a Weaviate collection

    Args:
        collection_name (str):
        body
            (BodyV2IngestFileIntoCollectionV1VectorstoreV2CollectionsCollectionNameFilesAsyncPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            collection_name=collection_name,
            client=client,
            body=body,
        )
    ).parsed
