from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.v2_delete_collection_v1_vectorstore_v2_collections_collection_name_delete_response_v2_delete_collection_v1_vectorstore_v2_collections_collection_name_delete import (
    V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete,
)
from ...types import Response


def _get_kwargs(
    collection_name: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/vectorstore/v2/collections/{collection_name}".format(
            collection_name=quote(str(collection_name), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    HTTPValidationError
    | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete
    | None
):
    if response.status_code == 200:
        response_200 = V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    HTTPValidationError
    | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    collection_name: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    HTTPValidationError
    | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete
]:
    """V2 Delete Collection

     Delete a Weaviate-backed collection

    Args:
        collection_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete]
    """

    kwargs = _get_kwargs(
        collection_name=collection_name,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    collection_name: str,
    *,
    client: AuthenticatedClient,
) -> (
    HTTPValidationError
    | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete
    | None
):
    """V2 Delete Collection

     Delete a Weaviate-backed collection

    Args:
        collection_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete
    """

    return sync_detailed(
        collection_name=collection_name,
        client=client,
    ).parsed


async def asyncio_detailed(
    collection_name: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    HTTPValidationError
    | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete
]:
    """V2 Delete Collection

     Delete a Weaviate-backed collection

    Args:
        collection_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete]
    """

    kwargs = _get_kwargs(
        collection_name=collection_name,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    collection_name: str,
    *,
    client: AuthenticatedClient,
) -> (
    HTTPValidationError
    | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete
    | None
):
    """V2 Delete Collection

     Delete a Weaviate-backed collection

    Args:
        collection_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | V2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDeleteResponseV2DeleteCollectionV1VectorstoreV2CollectionsCollectionNameDelete
    """

    return (
        await asyncio_detailed(
            collection_name=collection_name,
            client=client,
        )
    ).parsed
