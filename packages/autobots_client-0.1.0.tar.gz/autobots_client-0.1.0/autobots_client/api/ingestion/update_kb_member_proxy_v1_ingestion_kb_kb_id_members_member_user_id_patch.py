from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.knowledge_base_member_update_request import KnowledgeBaseMemberUpdateRequest
from ...models.knowledge_base_membership_response import KnowledgeBaseMembershipResponse
from ...types import Response


def _get_kwargs(
    kb_id: str,
    member_user_id: str,
    *,
    body: KnowledgeBaseMemberUpdateRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "patch",
        "url": "/v1/ingestion/kb/{kb_id}/members/{member_user_id}".format(
            kb_id=quote(str(kb_id), safe=""),
            member_user_id=quote(str(member_user_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | KnowledgeBaseMembershipResponse | None:
    if response.status_code == 200:
        response_200 = KnowledgeBaseMembershipResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | KnowledgeBaseMembershipResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    kb_id: str,
    member_user_id: str,
    *,
    client: AuthenticatedClient,
    body: KnowledgeBaseMemberUpdateRequest,
) -> Response[HTTPValidationError | KnowledgeBaseMembershipResponse]:
    """Update Kb Member Proxy

     Update a member's role.

    Args:
        kb_id (str):
        member_user_id (str):
        body (KnowledgeBaseMemberUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | KnowledgeBaseMembershipResponse]
    """

    kwargs = _get_kwargs(
        kb_id=kb_id,
        member_user_id=member_user_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    kb_id: str,
    member_user_id: str,
    *,
    client: AuthenticatedClient,
    body: KnowledgeBaseMemberUpdateRequest,
) -> HTTPValidationError | KnowledgeBaseMembershipResponse | None:
    """Update Kb Member Proxy

     Update a member's role.

    Args:
        kb_id (str):
        member_user_id (str):
        body (KnowledgeBaseMemberUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | KnowledgeBaseMembershipResponse
    """

    return sync_detailed(
        kb_id=kb_id,
        member_user_id=member_user_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    kb_id: str,
    member_user_id: str,
    *,
    client: AuthenticatedClient,
    body: KnowledgeBaseMemberUpdateRequest,
) -> Response[HTTPValidationError | KnowledgeBaseMembershipResponse]:
    """Update Kb Member Proxy

     Update a member's role.

    Args:
        kb_id (str):
        member_user_id (str):
        body (KnowledgeBaseMemberUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | KnowledgeBaseMembershipResponse]
    """

    kwargs = _get_kwargs(
        kb_id=kb_id,
        member_user_id=member_user_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    kb_id: str,
    member_user_id: str,
    *,
    client: AuthenticatedClient,
    body: KnowledgeBaseMemberUpdateRequest,
) -> HTTPValidationError | KnowledgeBaseMembershipResponse | None:
    """Update Kb Member Proxy

     Update a member's role.

    Args:
        kb_id (str):
        member_user_id (str):
        body (KnowledgeBaseMemberUpdateRequest):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | KnowledgeBaseMembershipResponse
    """

    return (
        await asyncio_detailed(
            kb_id=kb_id,
            member_user_id=member_user_id,
            client=client,
            body=body,
        )
    ).parsed
