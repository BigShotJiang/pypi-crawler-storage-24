from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.file_list_response_schema import FileListResponseSchema
from ...models.http_validation_error import HTTPValidationError
from ...models.list_ingested_files_proxy_v1_ingestion_files_get_scope_type_0 import (
    ListIngestedFilesProxyV1IngestionFilesGetScopeType0,
)
from ...models.list_ingested_files_proxy_v1_ingestion_files_get_sort_by import (
    ListIngestedFilesProxyV1IngestionFilesGetSortBy,
)
from ...models.list_ingested_files_proxy_v1_ingestion_files_get_sort_order import (
    ListIngestedFilesProxyV1IngestionFilesGetSortOrder,
)
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    filename_contains: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    weaviate_status: None | str | Unset = UNSET,
    graphrag_status: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    sort_by: ListIngestedFilesProxyV1IngestionFilesGetSortBy
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT,
    sort_order: ListIngestedFilesProxyV1IngestionFilesGetSortOrder
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    kb_id: None | str | Unset = UNSET,
    kb_name: None | str | Unset = UNSET,
    scope: ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_filename_contains: None | str | Unset
    if isinstance(filename_contains, Unset):
        json_filename_contains = UNSET
    else:
        json_filename_contains = filename_contains
    params["filename_contains"] = json_filename_contains

    json_status: None | str | Unset
    if isinstance(status, Unset):
        json_status = UNSET
    else:
        json_status = status
    params["status"] = json_status

    json_weaviate_status: None | str | Unset
    if isinstance(weaviate_status, Unset):
        json_weaviate_status = UNSET
    else:
        json_weaviate_status = weaviate_status
    params["weaviate_status"] = json_weaviate_status

    json_graphrag_status: None | str | Unset
    if isinstance(graphrag_status, Unset):
        json_graphrag_status = UNSET
    else:
        json_graphrag_status = graphrag_status
    params["graphrag_status"] = json_graphrag_status

    json_start_date: None | str | Unset
    if isinstance(start_date, Unset):
        json_start_date = UNSET
    else:
        json_start_date = start_date
    params["start_date"] = json_start_date

    json_end_date: None | str | Unset
    if isinstance(end_date, Unset):
        json_end_date = UNSET
    else:
        json_end_date = end_date
    params["end_date"] = json_end_date

    json_sort_by: str | Unset = UNSET
    if not isinstance(sort_by, Unset):
        json_sort_by = sort_by.value

    params["sort_by"] = json_sort_by

    json_sort_order: str | Unset = UNSET
    if not isinstance(sort_order, Unset):
        json_sort_order = sort_order.value

    params["sort_order"] = json_sort_order

    params["limit"] = limit

    params["offset"] = offset

    json_kb_id: None | str | Unset
    if isinstance(kb_id, Unset):
        json_kb_id = UNSET
    else:
        json_kb_id = kb_id
    params["kb_id"] = json_kb_id

    json_kb_name: None | str | Unset
    if isinstance(kb_name, Unset):
        json_kb_name = UNSET
    else:
        json_kb_name = kb_name
    params["kb_name"] = json_kb_name

    json_scope: None | str | Unset
    if isinstance(scope, Unset):
        json_scope = UNSET
    elif isinstance(scope, ListIngestedFilesProxyV1IngestionFilesGetScopeType0):
        json_scope = scope.value
    else:
        json_scope = scope
    params["scope"] = json_scope

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/ingestion/files",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> FileListResponseSchema | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = FileListResponseSchema.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[FileListResponseSchema | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    filename_contains: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    weaviate_status: None | str | Unset = UNSET,
    graphrag_status: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    sort_by: ListIngestedFilesProxyV1IngestionFilesGetSortBy
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT,
    sort_order: ListIngestedFilesProxyV1IngestionFilesGetSortOrder
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    kb_id: None | str | Unset = UNSET,
    kb_name: None | str | Unset = UNSET,
    scope: ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset = UNSET,
) -> Response[FileListResponseSchema | HTTPValidationError]:
    """List ingested files

     [Proxy] Forwards the request to the Ingestion Worker Service.

    Args:
        filename_contains (None | str | Unset): Search filename.
        status (None | str | Unset): Filter by status.
        weaviate_status (None | str | Unset):
        graphrag_status (None | str | Unset):
        start_date (None | str | Unset):
        end_date (None | str | Unset):
        sort_by (ListIngestedFilesProxyV1IngestionFilesGetSortBy | Unset):  Default:
            ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT.
        sort_order (ListIngestedFilesProxyV1IngestionFilesGetSortOrder | Unset):  Default:
            ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC.
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        kb_id (None | str | Unset): Optional KB filter. If provided, lists files for that KB.
        kb_name (None | str | Unset): Optional KB name filter. Server resolves to kb_id if unique.
        scope (ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset): Filter scope:
            'personal', 'kb', 'all'. Default: 'all' (My Uploads).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileListResponseSchema | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        filename_contains=filename_contains,
        status=status,
        weaviate_status=weaviate_status,
        graphrag_status=graphrag_status,
        start_date=start_date,
        end_date=end_date,
        sort_by=sort_by,
        sort_order=sort_order,
        limit=limit,
        offset=offset,
        kb_id=kb_id,
        kb_name=kb_name,
        scope=scope,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    filename_contains: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    weaviate_status: None | str | Unset = UNSET,
    graphrag_status: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    sort_by: ListIngestedFilesProxyV1IngestionFilesGetSortBy
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT,
    sort_order: ListIngestedFilesProxyV1IngestionFilesGetSortOrder
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    kb_id: None | str | Unset = UNSET,
    kb_name: None | str | Unset = UNSET,
    scope: ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset = UNSET,
) -> FileListResponseSchema | HTTPValidationError | None:
    """List ingested files

     [Proxy] Forwards the request to the Ingestion Worker Service.

    Args:
        filename_contains (None | str | Unset): Search filename.
        status (None | str | Unset): Filter by status.
        weaviate_status (None | str | Unset):
        graphrag_status (None | str | Unset):
        start_date (None | str | Unset):
        end_date (None | str | Unset):
        sort_by (ListIngestedFilesProxyV1IngestionFilesGetSortBy | Unset):  Default:
            ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT.
        sort_order (ListIngestedFilesProxyV1IngestionFilesGetSortOrder | Unset):  Default:
            ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC.
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        kb_id (None | str | Unset): Optional KB filter. If provided, lists files for that KB.
        kb_name (None | str | Unset): Optional KB name filter. Server resolves to kb_id if unique.
        scope (ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset): Filter scope:
            'personal', 'kb', 'all'. Default: 'all' (My Uploads).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileListResponseSchema | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        filename_contains=filename_contains,
        status=status,
        weaviate_status=weaviate_status,
        graphrag_status=graphrag_status,
        start_date=start_date,
        end_date=end_date,
        sort_by=sort_by,
        sort_order=sort_order,
        limit=limit,
        offset=offset,
        kb_id=kb_id,
        kb_name=kb_name,
        scope=scope,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    filename_contains: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    weaviate_status: None | str | Unset = UNSET,
    graphrag_status: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    sort_by: ListIngestedFilesProxyV1IngestionFilesGetSortBy
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT,
    sort_order: ListIngestedFilesProxyV1IngestionFilesGetSortOrder
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    kb_id: None | str | Unset = UNSET,
    kb_name: None | str | Unset = UNSET,
    scope: ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset = UNSET,
) -> Response[FileListResponseSchema | HTTPValidationError]:
    """List ingested files

     [Proxy] Forwards the request to the Ingestion Worker Service.

    Args:
        filename_contains (None | str | Unset): Search filename.
        status (None | str | Unset): Filter by status.
        weaviate_status (None | str | Unset):
        graphrag_status (None | str | Unset):
        start_date (None | str | Unset):
        end_date (None | str | Unset):
        sort_by (ListIngestedFilesProxyV1IngestionFilesGetSortBy | Unset):  Default:
            ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT.
        sort_order (ListIngestedFilesProxyV1IngestionFilesGetSortOrder | Unset):  Default:
            ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC.
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        kb_id (None | str | Unset): Optional KB filter. If provided, lists files for that KB.
        kb_name (None | str | Unset): Optional KB name filter. Server resolves to kb_id if unique.
        scope (ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset): Filter scope:
            'personal', 'kb', 'all'. Default: 'all' (My Uploads).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[FileListResponseSchema | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        filename_contains=filename_contains,
        status=status,
        weaviate_status=weaviate_status,
        graphrag_status=graphrag_status,
        start_date=start_date,
        end_date=end_date,
        sort_by=sort_by,
        sort_order=sort_order,
        limit=limit,
        offset=offset,
        kb_id=kb_id,
        kb_name=kb_name,
        scope=scope,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    filename_contains: None | str | Unset = UNSET,
    status: None | str | Unset = UNSET,
    weaviate_status: None | str | Unset = UNSET,
    graphrag_status: None | str | Unset = UNSET,
    start_date: None | str | Unset = UNSET,
    end_date: None | str | Unset = UNSET,
    sort_by: ListIngestedFilesProxyV1IngestionFilesGetSortBy
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT,
    sort_order: ListIngestedFilesProxyV1IngestionFilesGetSortOrder
    | Unset = ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC,
    limit: int | Unset = 50,
    offset: int | Unset = 0,
    kb_id: None | str | Unset = UNSET,
    kb_name: None | str | Unset = UNSET,
    scope: ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset = UNSET,
) -> FileListResponseSchema | HTTPValidationError | None:
    """List ingested files

     [Proxy] Forwards the request to the Ingestion Worker Service.

    Args:
        filename_contains (None | str | Unset): Search filename.
        status (None | str | Unset): Filter by status.
        weaviate_status (None | str | Unset):
        graphrag_status (None | str | Unset):
        start_date (None | str | Unset):
        end_date (None | str | Unset):
        sort_by (ListIngestedFilesProxyV1IngestionFilesGetSortBy | Unset):  Default:
            ListIngestedFilesProxyV1IngestionFilesGetSortBy.CREATED_AT.
        sort_order (ListIngestedFilesProxyV1IngestionFilesGetSortOrder | Unset):  Default:
            ListIngestedFilesProxyV1IngestionFilesGetSortOrder.DESC.
        limit (int | Unset):  Default: 50.
        offset (int | Unset):  Default: 0.
        kb_id (None | str | Unset): Optional KB filter. If provided, lists files for that KB.
        kb_name (None | str | Unset): Optional KB name filter. Server resolves to kb_id if unique.
        scope (ListIngestedFilesProxyV1IngestionFilesGetScopeType0 | None | Unset): Filter scope:
            'personal', 'kb', 'all'. Default: 'all' (My Uploads).

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        FileListResponseSchema | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            filename_contains=filename_contains,
            status=status,
            weaviate_status=weaviate_status,
            graphrag_status=graphrag_status,
            start_date=start_date,
            end_date=end_date,
            sort_by=sort_by,
            sort_order=sort_order,
            limit=limit,
            offset=offset,
            kb_id=kb_id,
            kb_name=kb_name,
            scope=scope,
        )
    ).parsed
