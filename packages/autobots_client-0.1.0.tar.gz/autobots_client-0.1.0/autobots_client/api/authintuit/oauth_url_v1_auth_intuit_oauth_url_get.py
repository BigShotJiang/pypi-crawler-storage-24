from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    redirect_uri: str
    | Unset = "https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-redirect/",
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["redirect_uri"] = redirect_uri

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/auth/intuit/oauth-url",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    redirect_uri: str
    | Unset = "https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-redirect/",
) -> Response[Any | HTTPValidationError]:
    """Oauth Url

    Args:
        redirect_uri (str | Unset):  Default:
            'https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-
            redirect/'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        redirect_uri=redirect_uri,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    redirect_uri: str
    | Unset = "https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-redirect/",
) -> Any | HTTPValidationError | None:
    """Oauth Url

    Args:
        redirect_uri (str | Unset):  Default:
            'https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-
            redirect/'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        redirect_uri=redirect_uri,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    redirect_uri: str
    | Unset = "https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-redirect/",
) -> Response[Any | HTTPValidationError]:
    """Oauth Url

    Args:
        redirect_uri (str | Unset):  Default:
            'https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-
            redirect/'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        redirect_uri=redirect_uri,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    redirect_uri: str
    | Unset = "https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-redirect/",
) -> Any | HTTPValidationError | None:
    """Oauth Url

    Args:
        redirect_uri (str | Unset):  Default:
            'https://2af8-2601-647-4000-7830-c019-fad9-7e16-866.ngrok-free.app/v1/auth/intuit/oauth-
            redirect/'.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            redirect_uri=redirect_uri,
        )
    ).parsed
