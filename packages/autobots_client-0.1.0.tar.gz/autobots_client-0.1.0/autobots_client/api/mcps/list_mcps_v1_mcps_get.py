from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.list_mcps_v1_mcps_get_request_headers import ListMcpsV1McpsGetRequestHeaders
from ...models.list_mcps_v1_mcps_get_server_type import ListMcpsV1McpsGetServerType
from ...models.mcp_docs_found import MCPDocsFound
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: ListMcpsV1McpsGetRequestHeaders | Unset = UNSET,
    server_name: str | Unset = UNSET,
    server_type: ListMcpsV1McpsGetServerType | Unset = UNSET,
    server_url: str | Unset = UNSET,
    description: str | Unset = UNSET,
    oauth_token: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["server_name"] = server_name

    json_server_type: str | Unset = UNSET
    if not isinstance(server_type, Unset):
        json_server_type = server_type.value

    params["server_type"] = json_server_type

    params["server_url"] = server_url

    params["description"] = description

    params["oauth_token"] = oauth_token

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/mcps/",
        "params": params,
    }

    if not isinstance(body, Unset):
        _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | MCPDocsFound | None:
    if response.status_code == 200:
        response_200 = MCPDocsFound.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | MCPDocsFound]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ListMcpsV1McpsGetRequestHeaders | Unset = UNSET,
    server_name: str | Unset = UNSET,
    server_type: ListMcpsV1McpsGetServerType | Unset = UNSET,
    server_url: str | Unset = UNSET,
    description: str | Unset = UNSET,
    oauth_token: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[HTTPValidationError | MCPDocsFound]:
    """List Mcps

    Args:
        server_name (str | Unset):
        server_type (ListMcpsV1McpsGetServerType | Unset):
        server_url (str | Unset):
        description (str | Unset):
        oauth_token (str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        body (ListMcpsV1McpsGetRequestHeaders | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MCPDocsFound]
    """

    kwargs = _get_kwargs(
        body=body,
        server_name=server_name,
        server_type=server_type,
        server_url=server_url,
        description=description,
        oauth_token=oauth_token,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ListMcpsV1McpsGetRequestHeaders | Unset = UNSET,
    server_name: str | Unset = UNSET,
    server_type: ListMcpsV1McpsGetServerType | Unset = UNSET,
    server_url: str | Unset = UNSET,
    description: str | Unset = UNSET,
    oauth_token: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> HTTPValidationError | MCPDocsFound | None:
    """List Mcps

    Args:
        server_name (str | Unset):
        server_type (ListMcpsV1McpsGetServerType | Unset):
        server_url (str | Unset):
        description (str | Unset):
        oauth_token (str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        body (ListMcpsV1McpsGetRequestHeaders | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MCPDocsFound
    """

    return sync_detailed(
        client=client,
        body=body,
        server_name=server_name,
        server_type=server_type,
        server_url=server_url,
        description=description,
        oauth_token=oauth_token,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ListMcpsV1McpsGetRequestHeaders | Unset = UNSET,
    server_name: str | Unset = UNSET,
    server_type: ListMcpsV1McpsGetServerType | Unset = UNSET,
    server_url: str | Unset = UNSET,
    description: str | Unset = UNSET,
    oauth_token: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[HTTPValidationError | MCPDocsFound]:
    """List Mcps

    Args:
        server_name (str | Unset):
        server_type (ListMcpsV1McpsGetServerType | Unset):
        server_url (str | Unset):
        description (str | Unset):
        oauth_token (str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        body (ListMcpsV1McpsGetRequestHeaders | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MCPDocsFound]
    """

    kwargs = _get_kwargs(
        body=body,
        server_name=server_name,
        server_type=server_type,
        server_url=server_url,
        description=description,
        oauth_token=oauth_token,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ListMcpsV1McpsGetRequestHeaders | Unset = UNSET,
    server_name: str | Unset = UNSET,
    server_type: ListMcpsV1McpsGetServerType | Unset = UNSET,
    server_url: str | Unset = UNSET,
    description: str | Unset = UNSET,
    oauth_token: str | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> HTTPValidationError | MCPDocsFound | None:
    """List Mcps

    Args:
        server_name (str | Unset):
        server_type (ListMcpsV1McpsGetServerType | Unset):
        server_url (str | Unset):
        description (str | Unset):
        oauth_token (str | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.
        body (ListMcpsV1McpsGetRequestHeaders | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MCPDocsFound
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            server_name=server_name,
            server_type=server_type,
            server_url=server_url,
            description=description,
            oauth_token=oauth_token,
            limit=limit,
            offset=offset,
        )
    ).parsed
