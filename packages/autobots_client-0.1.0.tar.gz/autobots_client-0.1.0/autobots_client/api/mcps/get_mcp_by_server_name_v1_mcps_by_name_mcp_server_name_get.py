from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.mcp_doc import MCPDoc
from ...types import Response


def _get_kwargs(
    mcp_server_name: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/mcps/by_name/{mcp_server_name}".format(
            mcp_server_name=quote(str(mcp_server_name), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | MCPDoc | None:
    if response.status_code == 200:
        response_200 = MCPDoc.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | MCPDoc]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    mcp_server_name: str,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | MCPDoc]:
    """Get Mcp By Server Name

    Args:
        mcp_server_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MCPDoc]
    """

    kwargs = _get_kwargs(
        mcp_server_name=mcp_server_name,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    mcp_server_name: str,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | MCPDoc | None:
    """Get Mcp By Server Name

    Args:
        mcp_server_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MCPDoc
    """

    return sync_detailed(
        mcp_server_name=mcp_server_name,
        client=client,
    ).parsed


async def asyncio_detailed(
    mcp_server_name: str,
    *,
    client: AuthenticatedClient,
) -> Response[HTTPValidationError | MCPDoc]:
    """Get Mcp By Server Name

    Args:
        mcp_server_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MCPDoc]
    """

    kwargs = _get_kwargs(
        mcp_server_name=mcp_server_name,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    mcp_server_name: str,
    *,
    client: AuthenticatedClient,
) -> HTTPValidationError | MCPDoc | None:
    """Get Mcp By Server Name

    Args:
        mcp_server_name (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MCPDoc
    """

    return (
        await asyncio_detailed(
            mcp_server_name=mcp_server_name,
            client=client,
        )
    ).parsed
