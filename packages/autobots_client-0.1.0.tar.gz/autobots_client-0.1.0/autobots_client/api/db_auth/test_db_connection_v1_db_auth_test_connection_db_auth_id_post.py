from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.test_db_connection_v1_db_auth_test_connection_db_auth_id_post_response_test_db_connection_v1_db_auth_test_connection_db_auth_id_post import (
    TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost,
)
from ...types import Response


def _get_kwargs(
    db_auth_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/db-auth/test-connection/{db_auth_id}".format(
            db_auth_id=quote(str(db_auth_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    HTTPValidationError
    | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost
    | None
):
    if response.status_code == 200:
        response_200 = TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    HTTPValidationError
    | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    db_auth_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    HTTPValidationError
    | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost
]:
    """Test Db Connection

     Test a database connection.

    Args:
        db_auth_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost]
    """

    kwargs = _get_kwargs(
        db_auth_id=db_auth_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    db_auth_id: str,
    *,
    client: AuthenticatedClient,
) -> (
    HTTPValidationError
    | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost
    | None
):
    """Test Db Connection

     Test a database connection.

    Args:
        db_auth_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost
    """

    return sync_detailed(
        db_auth_id=db_auth_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    db_auth_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[
    HTTPValidationError
    | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost
]:
    """Test Db Connection

     Test a database connection.

    Args:
        db_auth_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost]
    """

    kwargs = _get_kwargs(
        db_auth_id=db_auth_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    db_auth_id: str,
    *,
    client: AuthenticatedClient,
) -> (
    HTTPValidationError
    | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost
    | None
):
    """Test Db Connection

     Test a database connection.

    Args:
        db_auth_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | TestDbConnectionV1DbAuthTestConnectionDbAuthIdPostResponseTestDbConnectionV1DbAuthTestConnectionDbAuthIdPost
    """

    return (
        await asyncio_detailed(
            db_auth_id=db_auth_id,
            client=client,
        )
    ).parsed
