from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.cost_config_type import CostConfigType
from ...models.delete_cost_config_v1_dashboard_cost_config_config_type_delete_response_delete_cost_config_v1_dashboard_cost_config_config_type_delete import (
    DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    config_type: CostConfigType,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "delete",
        "url": "/v1/dashboard/cost-config/{config_type}".format(
            config_type=quote(str(config_type), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete
    | HTTPValidationError
    | None
):
    if response.status_code == 200:
        response_200 = DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete
    | HTTPValidationError
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    config_type: CostConfigType,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete
    | HTTPValidationError
]:
    """Delete Cost Config

     Delete a cost configuration.

    Only admin users can delete cost configurations.

    Args:
        config_type (CostConfigType): Types of cost configurations

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        config_type=config_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    config_type: CostConfigType,
    *,
    client: AuthenticatedClient,
) -> (
    DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete
    | HTTPValidationError
    | None
):
    """Delete Cost Config

     Delete a cost configuration.

    Only admin users can delete cost configurations.

    Args:
        config_type (CostConfigType): Types of cost configurations

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete | HTTPValidationError
    """

    return sync_detailed(
        config_type=config_type,
        client=client,
    ).parsed


async def asyncio_detailed(
    config_type: CostConfigType,
    *,
    client: AuthenticatedClient,
) -> Response[
    DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete
    | HTTPValidationError
]:
    """Delete Cost Config

     Delete a cost configuration.

    Only admin users can delete cost configurations.

    Args:
        config_type (CostConfigType): Types of cost configurations

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        config_type=config_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    config_type: CostConfigType,
    *,
    client: AuthenticatedClient,
) -> (
    DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete
    | HTTPValidationError
    | None
):
    """Delete Cost Config

     Delete a cost configuration.

    Only admin users can delete cost configurations.

    Args:
        config_type (CostConfigType): Types of cost configurations

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DeleteCostConfigV1DashboardCostConfigConfigTypeDeleteResponseDeleteCostConfigV1DashboardCostConfigConfigTypeDelete | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            config_type=config_type,
            client=client,
        )
    ).parsed
