from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.initialize_default_configs_v1_dashboard_cost_config_initialize_post_response_initialize_default_configs_v1_dashboard_cost_config_initialize_post import (
    InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost,
)
from ...types import Response


def _get_kwargs() -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/dashboard/cost-config/initialize",
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> (
    InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost
    | None
):
    if response.status_code == 200:
        response_200 = InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost.from_dict(
            response.json()
        )

        return response_200

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[
    InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost
]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[
    InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost
]:
    """Initialize Default Configs

     Initialize default cost configurations.

    This will create default configurations for any missing types.
    Only admin users can initialize configurations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost]
    """

    kwargs = _get_kwargs()

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
) -> (
    InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost
    | None
):
    """Initialize Default Configs

     Initialize default cost configurations.

    This will create default configurations for any missing types.
    Only admin users can initialize configurations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost
    """

    return sync_detailed(
        client=client,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
) -> Response[
    InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost
]:
    """Initialize Default Configs

     Initialize default cost configurations.

    This will create default configurations for any missing types.
    Only admin users can initialize configurations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost]
    """

    kwargs = _get_kwargs()

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
) -> (
    InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost
    | None
):
    """Initialize Default Configs

     Initialize default cost configurations.

    This will create default configurations for any missing types.
    Only admin users can initialize configurations.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        InitializeDefaultConfigsV1DashboardCostConfigInitializePostResponseInitializeDefaultConfigsV1DashboardCostConfigInitializePost
    """

    return (
        await asyncio_detailed(
            client=client,
        )
    ).parsed
