from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.dashboard_request import DashboardRequest
from ...models.dashboard_response import DashboardResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    body: DashboardRequest,
    force_refresh: bool | Unset = False,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["force_refresh"] = force_refresh

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/dashboard/",
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DashboardResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DashboardResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DashboardResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: DashboardRequest,
    force_refresh: bool | Unset = False,
) -> Response[DashboardResponse | HTTPValidationError]:
    """Get Dashboard With Custom Filters

     Get dashboard data with custom filters and date ranges.

    Allows for more complex filtering including custom date ranges.
    Data is served from MongoDB cache for faster response times.

    Args:
        force_refresh (bool | Unset): Force refresh cache Default: False.
        body (DashboardRequest): Request model for dashboard data

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        force_refresh=force_refresh,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: DashboardRequest,
    force_refresh: bool | Unset = False,
) -> DashboardResponse | HTTPValidationError | None:
    """Get Dashboard With Custom Filters

     Get dashboard data with custom filters and date ranges.

    Allows for more complex filtering including custom date ranges.
    Data is served from MongoDB cache for faster response times.

    Args:
        force_refresh (bool | Unset): Force refresh cache Default: False.
        body (DashboardRequest): Request model for dashboard data

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
        force_refresh=force_refresh,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: DashboardRequest,
    force_refresh: bool | Unset = False,
) -> Response[DashboardResponse | HTTPValidationError]:
    """Get Dashboard With Custom Filters

     Get dashboard data with custom filters and date ranges.

    Allows for more complex filtering including custom date ranges.
    Data is served from MongoDB cache for faster response times.

    Args:
        force_refresh (bool | Unset): Force refresh cache Default: False.
        body (DashboardRequest): Request model for dashboard data

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
        force_refresh=force_refresh,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: DashboardRequest,
    force_refresh: bool | Unset = False,
) -> DashboardResponse | HTTPValidationError | None:
    """Get Dashboard With Custom Filters

     Get dashboard data with custom filters and date ranges.

    Allows for more complex filtering including custom date ranges.
    Data is served from MongoDB cache for faster response times.

    Args:
        force_refresh (bool | Unset): Force refresh cache Default: False.
        body (DashboardRequest): Request model for dashboard data

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
            force_refresh=force_refresh,
        )
    ).parsed
