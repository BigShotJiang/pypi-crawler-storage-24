from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.time_range import TimeRange
from ...models.workflow_performance import WorkflowPerformance
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    time_range: TimeRange | Unset = UNSET,
    limit: int | Unset = 10,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_time_range: str | Unset = UNSET
    if not isinstance(time_range, Unset):
        json_time_range = time_range.value

    params["time_range"] = json_time_range

    params["limit"] = limit

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/dashboard/workflows/performance",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[WorkflowPerformance] | None:
    if response.status_code == 200:
        response_200 = []
        _response_200 = response.json()
        for response_200_item_data in _response_200:
            response_200_item = WorkflowPerformance.from_dict(response_200_item_data)

            response_200.append(response_200_item)

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[WorkflowPerformance]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    limit: int | Unset = 10,
) -> Response[HTTPValidationError | list[WorkflowPerformance]]:
    """Get Workflow Performance

     Get top performing workflows based on ROI and efficiency metrics.

    Args:
        time_range (TimeRange | Unset):
        limit (int | Unset): Number of top workflows to return Default: 10.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[WorkflowPerformance]]
    """

    kwargs = _get_kwargs(
        time_range=time_range,
        limit=limit,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    limit: int | Unset = 10,
) -> HTTPValidationError | list[WorkflowPerformance] | None:
    """Get Workflow Performance

     Get top performing workflows based on ROI and efficiency metrics.

    Args:
        time_range (TimeRange | Unset):
        limit (int | Unset): Number of top workflows to return Default: 10.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[WorkflowPerformance]
    """

    return sync_detailed(
        client=client,
        time_range=time_range,
        limit=limit,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    limit: int | Unset = 10,
) -> Response[HTTPValidationError | list[WorkflowPerformance]]:
    """Get Workflow Performance

     Get top performing workflows based on ROI and efficiency metrics.

    Args:
        time_range (TimeRange | Unset):
        limit (int | Unset): Number of top workflows to return Default: 10.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[WorkflowPerformance]]
    """

    kwargs = _get_kwargs(
        time_range=time_range,
        limit=limit,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    limit: int | Unset = 10,
) -> HTTPValidationError | list[WorkflowPerformance] | None:
    """Get Workflow Performance

     Get top performing workflows based on ROI and efficiency metrics.

    Args:
        time_range (TimeRange | Unset):
        limit (int | Unset): Number of top workflows to return Default: 10.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[WorkflowPerformance]
    """

    return (
        await asyncio_detailed(
            client=client,
            time_range=time_range,
            limit=limit,
        )
    ).parsed
