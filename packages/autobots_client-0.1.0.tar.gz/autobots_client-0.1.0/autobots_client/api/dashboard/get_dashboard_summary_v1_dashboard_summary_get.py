from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.time_range import TimeRange
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    time_range: TimeRange | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_time_range: str | Unset = UNSET
    if not isinstance(time_range, Unset):
        json_time_range = time_range.value

    params["time_range"] = json_time_range

    params["force_refresh"] = force_refresh

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/dashboard/summary",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> Response[Any | HTTPValidationError]:
    """Get Dashboard Summary

     Get just the summary metrics without charts and detailed data.

    Useful for quick overview widgets or mobile views.
    Data is served from MongoDB cache for faster response times.

    Args:
        time_range (TimeRange | Unset):
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        time_range=time_range,
        force_refresh=force_refresh,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> Any | HTTPValidationError | None:
    """Get Dashboard Summary

     Get just the summary metrics without charts and detailed data.

    Useful for quick overview widgets or mobile views.
    Data is served from MongoDB cache for faster response times.

    Args:
        time_range (TimeRange | Unset):
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        time_range=time_range,
        force_refresh=force_refresh,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> Response[Any | HTTPValidationError]:
    """Get Dashboard Summary

     Get just the summary metrics without charts and detailed data.

    Useful for quick overview widgets or mobile views.
    Data is served from MongoDB cache for faster response times.

    Args:
        time_range (TimeRange | Unset):
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        time_range=time_range,
        force_refresh=force_refresh,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> Any | HTTPValidationError | None:
    """Get Dashboard Summary

     Get just the summary metrics without charts and detailed data.

    Useful for quick overview widgets or mobile views.
    Data is served from MongoDB cache for faster response times.

    Args:
        time_range (TimeRange | Unset):
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            time_range=time_range,
            force_refresh=force_refresh,
        )
    ).parsed
