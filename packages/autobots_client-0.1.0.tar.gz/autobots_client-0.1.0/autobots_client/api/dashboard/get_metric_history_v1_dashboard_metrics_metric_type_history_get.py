from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.metric_history_response import MetricHistoryResponse
from ...models.metric_type import MetricType
from ...models.time_range import TimeRange
from ...types import UNSET, Response, Unset


def _get_kwargs(
    metric_type: MetricType,
    *,
    time_range: TimeRange | Unset = UNSET,
    granularity: str | Unset = "daily",
    force_refresh: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_time_range: str | Unset = UNSET
    if not isinstance(time_range, Unset):
        json_time_range = time_range.value

    params["time_range"] = json_time_range

    params["granularity"] = granularity

    params["force_refresh"] = force_refresh

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/dashboard/metrics/{metric_type}/history".format(
            metric_type=quote(str(metric_type), safe=""),
        ),
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | MetricHistoryResponse | None:
    if response.status_code == 200:
        response_200 = MetricHistoryResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | MetricHistoryResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    metric_type: MetricType,
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    granularity: str | Unset = "daily",
    force_refresh: bool | Unset = False,
) -> Response[HTTPValidationError | MetricHistoryResponse]:
    """Get Metric History

     Get historical data for a specific metric.

    Useful for detailed analysis of individual metrics over time.
    Data is served from MongoDB cache for faster response times.

    Args:
        metric_type (MetricType):
        time_range (TimeRange | Unset):
        granularity (str | Unset): Data granularity: daily, weekly, monthly Default: 'daily'.
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MetricHistoryResponse]
    """

    kwargs = _get_kwargs(
        metric_type=metric_type,
        time_range=time_range,
        granularity=granularity,
        force_refresh=force_refresh,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    metric_type: MetricType,
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    granularity: str | Unset = "daily",
    force_refresh: bool | Unset = False,
) -> HTTPValidationError | MetricHistoryResponse | None:
    """Get Metric History

     Get historical data for a specific metric.

    Useful for detailed analysis of individual metrics over time.
    Data is served from MongoDB cache for faster response times.

    Args:
        metric_type (MetricType):
        time_range (TimeRange | Unset):
        granularity (str | Unset): Data granularity: daily, weekly, monthly Default: 'daily'.
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MetricHistoryResponse
    """

    return sync_detailed(
        metric_type=metric_type,
        client=client,
        time_range=time_range,
        granularity=granularity,
        force_refresh=force_refresh,
    ).parsed


async def asyncio_detailed(
    metric_type: MetricType,
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    granularity: str | Unset = "daily",
    force_refresh: bool | Unset = False,
) -> Response[HTTPValidationError | MetricHistoryResponse]:
    """Get Metric History

     Get historical data for a specific metric.

    Useful for detailed analysis of individual metrics over time.
    Data is served from MongoDB cache for faster response times.

    Args:
        metric_type (MetricType):
        time_range (TimeRange | Unset):
        granularity (str | Unset): Data granularity: daily, weekly, monthly Default: 'daily'.
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | MetricHistoryResponse]
    """

    kwargs = _get_kwargs(
        metric_type=metric_type,
        time_range=time_range,
        granularity=granularity,
        force_refresh=force_refresh,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    metric_type: MetricType,
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    granularity: str | Unset = "daily",
    force_refresh: bool | Unset = False,
) -> HTTPValidationError | MetricHistoryResponse | None:
    """Get Metric History

     Get historical data for a specific metric.

    Useful for detailed analysis of individual metrics over time.
    Data is served from MongoDB cache for faster response times.

    Args:
        metric_type (MetricType):
        time_range (TimeRange | Unset):
        granularity (str | Unset): Data granularity: daily, weekly, monthly Default: 'daily'.
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | MetricHistoryResponse
    """

    return (
        await asyncio_detailed(
            metric_type=metric_type,
            client=client,
            time_range=time_range,
            granularity=granularity,
            force_refresh=force_refresh,
        )
    ).parsed
