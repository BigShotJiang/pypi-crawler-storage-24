from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.dashboard_response import DashboardResponse
from ...models.filter_by import FilterBy
from ...models.http_validation_error import HTTPValidationError
from ...models.time_range import TimeRange
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    time_range: TimeRange | Unset = UNSET,
    filter_by: FilterBy | None | Unset = UNSET,
    filter_value: None | str | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_time_range: str | Unset = UNSET
    if not isinstance(time_range, Unset):
        json_time_range = time_range.value

    params["time_range"] = json_time_range

    json_filter_by: None | str | Unset
    if isinstance(filter_by, Unset):
        json_filter_by = UNSET
    elif isinstance(filter_by, FilterBy):
        json_filter_by = filter_by.value
    else:
        json_filter_by = filter_by
    params["filter_by"] = json_filter_by

    json_filter_value: None | str | Unset
    if isinstance(filter_value, Unset):
        json_filter_value = UNSET
    else:
        json_filter_value = filter_value
    params["filter_value"] = json_filter_value

    params["force_refresh"] = force_refresh

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/dashboard/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DashboardResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DashboardResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DashboardResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    filter_by: FilterBy | None | Unset = UNSET,
    filter_value: None | str | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> Response[DashboardResponse | HTTPValidationError]:
    """Get Dashboard

     Get complete dashboard data including summary metrics, charts, and performance data.

    This endpoint provides all the data needed for the Cost Benefit Analysis dashboard:
    - Summary metrics (agents, workflows, jobs, runs, time saved, dollars saved, ROI, revenue)
    - Time series charts for key metrics
    - Top performing agents and workflows
    - Department-wise metrics

    Data is served from MongoDB cache for faster response times.

    Args:
        time_range (TimeRange | Unset):
        filter_by (FilterBy | None | Unset): Filter dashboard data by
        filter_value (None | str | Unset): Value to filter by
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        time_range=time_range,
        filter_by=filter_by,
        filter_value=filter_value,
        force_refresh=force_refresh,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    filter_by: FilterBy | None | Unset = UNSET,
    filter_value: None | str | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> DashboardResponse | HTTPValidationError | None:
    """Get Dashboard

     Get complete dashboard data including summary metrics, charts, and performance data.

    This endpoint provides all the data needed for the Cost Benefit Analysis dashboard:
    - Summary metrics (agents, workflows, jobs, runs, time saved, dollars saved, ROI, revenue)
    - Time series charts for key metrics
    - Top performing agents and workflows
    - Department-wise metrics

    Data is served from MongoDB cache for faster response times.

    Args:
        time_range (TimeRange | Unset):
        filter_by (FilterBy | None | Unset): Filter dashboard data by
        filter_value (None | str | Unset): Value to filter by
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        time_range=time_range,
        filter_by=filter_by,
        filter_value=filter_value,
        force_refresh=force_refresh,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    filter_by: FilterBy | None | Unset = UNSET,
    filter_value: None | str | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> Response[DashboardResponse | HTTPValidationError]:
    """Get Dashboard

     Get complete dashboard data including summary metrics, charts, and performance data.

    This endpoint provides all the data needed for the Cost Benefit Analysis dashboard:
    - Summary metrics (agents, workflows, jobs, runs, time saved, dollars saved, ROI, revenue)
    - Time series charts for key metrics
    - Top performing agents and workflows
    - Department-wise metrics

    Data is served from MongoDB cache for faster response times.

    Args:
        time_range (TimeRange | Unset):
        filter_by (FilterBy | None | Unset): Filter dashboard data by
        filter_value (None | str | Unset): Value to filter by
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DashboardResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        time_range=time_range,
        filter_by=filter_by,
        filter_value=filter_value,
        force_refresh=force_refresh,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    time_range: TimeRange | Unset = UNSET,
    filter_by: FilterBy | None | Unset = UNSET,
    filter_value: None | str | Unset = UNSET,
    force_refresh: bool | Unset = False,
) -> DashboardResponse | HTTPValidationError | None:
    """Get Dashboard

     Get complete dashboard data including summary metrics, charts, and performance data.

    This endpoint provides all the data needed for the Cost Benefit Analysis dashboard:
    - Summary metrics (agents, workflows, jobs, runs, time saved, dollars saved, ROI, revenue)
    - Time series charts for key metrics
    - Top performing agents and workflows
    - Department-wise metrics

    Data is served from MongoDB cache for faster response times.

    Args:
        time_range (TimeRange | Unset):
        filter_by (FilterBy | None | Unset): Filter dashboard data by
        filter_value (None | str | Unset): Value to filter by
        force_refresh (bool | Unset): Force refresh cache Default: False.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DashboardResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            time_range=time_range,
            filter_by=filter_by,
            filter_value=filter_value,
            force_refresh=force_refresh,
        )
    ).parsed
