from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.chat_doc import ChatDoc
from ...models.create_chat_v1_action_chats_post_openai_provider import CreateChatV1ActionChatsPostOpenaiProvider
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    *,
    action_id: str,
    openai_provider: CreateChatV1ActionChatsPostOpenaiProvider,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["action_id"] = action_id

    json_openai_provider = openai_provider.value
    params["openai_provider"] = json_openai_provider

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/action_chats/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ChatDoc | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ChatDoc.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ChatDoc | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    action_id: str,
    openai_provider: CreateChatV1ActionChatsPostOpenaiProvider,
) -> Response[ChatDoc | HTTPValidationError]:
    """Create Chat

    Args:
        action_id (str):
        openai_provider (CreateChatV1ActionChatsPostOpenaiProvider):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChatDoc | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        action_id=action_id,
        openai_provider=openai_provider,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    action_id: str,
    openai_provider: CreateChatV1ActionChatsPostOpenaiProvider,
) -> ChatDoc | HTTPValidationError | None:
    """Create Chat

    Args:
        action_id (str):
        openai_provider (CreateChatV1ActionChatsPostOpenaiProvider):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChatDoc | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        action_id=action_id,
        openai_provider=openai_provider,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    action_id: str,
    openai_provider: CreateChatV1ActionChatsPostOpenaiProvider,
) -> Response[ChatDoc | HTTPValidationError]:
    """Create Chat

    Args:
        action_id (str):
        openai_provider (CreateChatV1ActionChatsPostOpenaiProvider):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ChatDoc | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        action_id=action_id,
        openai_provider=openai_provider,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    action_id: str,
    openai_provider: CreateChatV1ActionChatsPostOpenaiProvider,
) -> ChatDoc | HTTPValidationError | None:
    """Create Chat

    Args:
        action_id (str):
        openai_provider (CreateChatV1ActionChatsPostOpenaiProvider):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ChatDoc | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            action_id=action_id,
            openai_provider=openai_provider,
        )
    ).parsed
