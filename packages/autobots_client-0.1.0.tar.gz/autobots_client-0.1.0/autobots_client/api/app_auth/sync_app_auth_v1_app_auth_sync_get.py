from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.app_types import AppTypes
from ...models.http_validation_error import HTTPValidationError
from ...models.sync_app_auth_v1_app_auth_sync_get_response_sync_app_auth_v1_app_auth_sync_get import (
    SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet,
)
from ...types import UNSET, Response


def _get_kwargs(
    *,
    app: AppTypes,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_app = app.value
    params["app"] = json_app

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/app-auth/sync",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet | None:
    if response.status_code == 200:
        response_200 = SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    app: AppTypes,
) -> Response[HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet]:
    """Sync App Auth

    Args:
        app (AppTypes):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet]
    """

    kwargs = _get_kwargs(
        app=app,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    app: AppTypes,
) -> HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet | None:
    """Sync App Auth

    Args:
        app (AppTypes):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet
    """

    return sync_detailed(
        client=client,
        app=app,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    app: AppTypes,
) -> Response[HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet]:
    """Sync App Auth

    Args:
        app (AppTypes):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet]
    """

    kwargs = _get_kwargs(
        app=app,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    app: AppTypes,
) -> HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet | None:
    """Sync App Auth

    Args:
        app (AppTypes):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | SyncAppAuthV1AppAuthSyncGetResponseSyncAppAuthV1AppAuthSyncGet
    """

    return (
        await asyncio_detailed(
            client=client,
            app=app,
        )
    ).parsed
