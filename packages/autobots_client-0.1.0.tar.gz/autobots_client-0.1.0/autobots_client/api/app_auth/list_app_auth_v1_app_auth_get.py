from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.app_auth_lite_doc_page import AppAuthLiteDocPage
from ...models.app_types import AppTypes
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    id: str | Unset = UNSET,
    app: AppTypes | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["id"] = id

    json_app: str | Unset = UNSET
    if not isinstance(app, Unset):
        json_app = app.value

    params["app"] = json_app

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/app-auth/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AppAuthLiteDocPage | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AppAuthLiteDocPage.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AppAuthLiteDocPage | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    app: AppTypes | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[AppAuthLiteDocPage | HTTPValidationError]:
    """List App Auth

    Args:
        id (str | Unset):
        app (AppTypes | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppAuthLiteDocPage | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        id=id,
        app=app,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    app: AppTypes | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> AppAuthLiteDocPage | HTTPValidationError | None:
    """List App Auth

    Args:
        id (str | Unset):
        app (AppTypes | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppAuthLiteDocPage | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        id=id,
        app=app,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    app: AppTypes | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[AppAuthLiteDocPage | HTTPValidationError]:
    """List App Auth

    Args:
        id (str | Unset):
        app (AppTypes | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AppAuthLiteDocPage | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        id=id,
        app=app,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    app: AppTypes | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> AppAuthLiteDocPage | HTTPValidationError | None:
    """List App Auth

    Args:
        id (str | Unset):
        app (AppTypes | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AppAuthLiteDocPage | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            id=id,
            app=app,
            limit=limit,
            offset=offset,
        )
    ).parsed
