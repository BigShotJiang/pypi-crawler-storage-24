from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.app_types import AppTypes
from ...models.get_creds_types_v1_app_creds_types_app_get_response_get_creds_types_v1_app_creds_types_app_get import (
    GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet,
)
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    app: AppTypes,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/app-creds/types/{app}".format(
            app=quote(str(app), safe=""),
        ),
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet.from_dict(
            response.json()
        )

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    app: AppTypes,
    *,
    client: AuthenticatedClient,
) -> Response[GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError]:
    """Get Creds Types

    Args:
        app (AppTypes):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app=app,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    app: AppTypes,
    *,
    client: AuthenticatedClient,
) -> GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError | None:
    """Get Creds Types

    Args:
        app (AppTypes):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError
    """

    return sync_detailed(
        app=app,
        client=client,
    ).parsed


async def asyncio_detailed(
    app: AppTypes,
    *,
    client: AuthenticatedClient,
) -> Response[GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError]:
    """Get Creds Types

    Args:
        app (AppTypes):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        app=app,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    app: AppTypes,
    *,
    client: AuthenticatedClient,
) -> GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError | None:
    """Get Creds Types

    Args:
        app (AppTypes):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        GetCredsTypesV1AppCredsTypesAppGetResponseGetCredsTypesV1AppCredsTypesAppGet | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            app=app,
            client=client,
        )
    ).parsed
