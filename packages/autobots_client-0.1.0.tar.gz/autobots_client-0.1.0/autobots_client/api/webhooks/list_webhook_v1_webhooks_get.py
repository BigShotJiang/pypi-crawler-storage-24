from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.doc_find_page import DocFindPage
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    webhook_id: None | str | Unset = UNSET,
    runnable_id: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_webhook_id: None | str | Unset
    if isinstance(webhook_id, Unset):
        json_webhook_id = UNSET
    else:
        json_webhook_id = webhook_id
    params["webhook_id"] = json_webhook_id

    json_runnable_id: None | str | Unset
    if isinstance(runnable_id, Unset):
        json_runnable_id = UNSET
    else:
        json_runnable_id = runnable_id
    params["runnable_id"] = json_runnable_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/webhooks/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> DocFindPage | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = DocFindPage.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[DocFindPage | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    webhook_id: None | str | Unset = UNSET,
    runnable_id: None | str | Unset = UNSET,
) -> Response[DocFindPage | HTTPValidationError]:
    """List Webhook

    Args:
        webhook_id (None | str | Unset):
        runnable_id (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DocFindPage | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        webhook_id=webhook_id,
        runnable_id=runnable_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    webhook_id: None | str | Unset = UNSET,
    runnable_id: None | str | Unset = UNSET,
) -> DocFindPage | HTTPValidationError | None:
    """List Webhook

    Args:
        webhook_id (None | str | Unset):
        runnable_id (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DocFindPage | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        webhook_id=webhook_id,
        runnable_id=runnable_id,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    webhook_id: None | str | Unset = UNSET,
    runnable_id: None | str | Unset = UNSET,
) -> Response[DocFindPage | HTTPValidationError]:
    """List Webhook

    Args:
        webhook_id (None | str | Unset):
        runnable_id (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[DocFindPage | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        webhook_id=webhook_id,
        runnable_id=runnable_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    webhook_id: None | str | Unset = UNSET,
    runnable_id: None | str | Unset = UNSET,
) -> DocFindPage | HTTPValidationError | None:
    """List Webhook

    Args:
        webhook_id (None | str | Unset):
        runnable_id (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        DocFindPage | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            webhook_id=webhook_id,
            runnable_id=runnable_id,
        )
    ).parsed
