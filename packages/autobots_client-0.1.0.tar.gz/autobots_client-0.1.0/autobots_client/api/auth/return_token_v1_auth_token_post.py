from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.bearer_access_token import BearerAccessToken
from ...models.body_return_token_v1_auth_token_post import BodyReturnTokenV1AuthTokenPost
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: BodyReturnTokenV1AuthTokenPost,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/token",
    }

    _kwargs["data"] = body.to_dict()

    headers["Content-Type"] = "application/x-www-form-urlencoded"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> BearerAccessToken | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = BearerAccessToken.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[BearerAccessToken | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BodyReturnTokenV1AuthTokenPost,
) -> Response[BearerAccessToken | HTTPValidationError]:
    """Return Token

     OAuth2 endpoint
    signs in user(username/password) and returns JWT token
    :return: BearerToken

    Args:
        body (BodyReturnTokenV1AuthTokenPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BearerAccessToken | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    body: BodyReturnTokenV1AuthTokenPost,
) -> BearerAccessToken | HTTPValidationError | None:
    """Return Token

     OAuth2 endpoint
    signs in user(username/password) and returns JWT token
    :return: BearerToken

    Args:
        body (BodyReturnTokenV1AuthTokenPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BearerAccessToken | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    body: BodyReturnTokenV1AuthTokenPost,
) -> Response[BearerAccessToken | HTTPValidationError]:
    """Return Token

     OAuth2 endpoint
    signs in user(username/password) and returns JWT token
    :return: BearerToken

    Args:
        body (BodyReturnTokenV1AuthTokenPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[BearerAccessToken | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    body: BodyReturnTokenV1AuthTokenPost,
) -> BearerAccessToken | HTTPValidationError | None:
    """Return Token

     OAuth2 endpoint
    signs in user(username/password) and returns JWT token
    :return: BearerToken

    Args:
        body (BodyReturnTokenV1AuthTokenPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        BearerAccessToken | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
