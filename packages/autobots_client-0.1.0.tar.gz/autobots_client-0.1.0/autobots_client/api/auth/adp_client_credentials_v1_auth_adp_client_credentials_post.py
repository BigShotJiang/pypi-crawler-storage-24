from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.adp_client_credentials_request import ADPClientCredentialsRequest
from ...models.http_validation_error import HTTPValidationError
from ...types import Response


def _get_kwargs(
    *,
    body: ADPClientCredentialsRequest,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/adp/client-credentials",
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Any | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = response.json()
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[Any | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    body: ADPClientCredentialsRequest,
) -> Response[Any | HTTPValidationError]:
    r""" Adp Client Credentials

     Authenticate using ADP client credentials flow with Mutual SSL.

    ADP mandates mTLS where both client and server verify each other's
    identity through SSL certificates.

    Certificate paths can be:
    - Local file paths: /path/to/cert.pem
    - S3 URLs: s3://bucket/path/cert.pem or https://bucket.s3.region.amazonaws.com/path/cert.pem

    S3 certificates will be automatically downloaded to temporary files,
    used for authentication, then securely deleted.

    Args:
        body (ADPClientCredentialsRequest): Request model for ADP client credentials
            authentication.

            ADP requires Mutual SSL (mTLS) Authentication:
            - client_id: Your ADP client ID from ADP Developer Portal
            - client_secret: Your ADP client secret
            - ssl_cert_path: Path to SSL certificate file (PEM or PFX format)
            - ssl_key_path: Path to private key file (optional if embedded in cert)

            Supported path formats for certificates:
            - Local file path: /path/to/cert.pem
            - S3 URI: s3://bucket-name/path/to/cert.pem
            - S3 HTTPS URL: https://bucket-name.s3.region.amazonaws.com/path/to/cert.pem

            Certificate Setup:
            1. Obtain SSL certificate and private key from:
               - ADP Partners: Developer Self-Service Portal (automated)
               - ADP Clients: ADP Certificate Signing Tool (manual CSR)
               - API Central Users: API Central (automated)

            2. Upload certificates to S3 (recommended) or provide local paths:
               s3://your-bucket/adp/cert.pem
               s3://your-bucket/adp/key.key

            3. Optionally combine into single PFX file:
               openssl pkcs12 -export -out adp.pfx -name "OrgName Mutual SSL" \
                   -inkey private-key.key -in public-certificate.pem

            Note: Certificates are valid for 2 years. ADP sends renewal notices
            60 days before expiration.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
     """

    kwargs = _get_kwargs(
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    body: ADPClientCredentialsRequest,
) -> Any | HTTPValidationError | None:
    r""" Adp Client Credentials

     Authenticate using ADP client credentials flow with Mutual SSL.

    ADP mandates mTLS where both client and server verify each other's
    identity through SSL certificates.

    Certificate paths can be:
    - Local file paths: /path/to/cert.pem
    - S3 URLs: s3://bucket/path/cert.pem or https://bucket.s3.region.amazonaws.com/path/cert.pem

    S3 certificates will be automatically downloaded to temporary files,
    used for authentication, then securely deleted.

    Args:
        body (ADPClientCredentialsRequest): Request model for ADP client credentials
            authentication.

            ADP requires Mutual SSL (mTLS) Authentication:
            - client_id: Your ADP client ID from ADP Developer Portal
            - client_secret: Your ADP client secret
            - ssl_cert_path: Path to SSL certificate file (PEM or PFX format)
            - ssl_key_path: Path to private key file (optional if embedded in cert)

            Supported path formats for certificates:
            - Local file path: /path/to/cert.pem
            - S3 URI: s3://bucket-name/path/to/cert.pem
            - S3 HTTPS URL: https://bucket-name.s3.region.amazonaws.com/path/to/cert.pem

            Certificate Setup:
            1. Obtain SSL certificate and private key from:
               - ADP Partners: Developer Self-Service Portal (automated)
               - ADP Clients: ADP Certificate Signing Tool (manual CSR)
               - API Central Users: API Central (automated)

            2. Upload certificates to S3 (recommended) or provide local paths:
               s3://your-bucket/adp/cert.pem
               s3://your-bucket/adp/key.key

            3. Optionally combine into single PFX file:
               openssl pkcs12 -export -out adp.pfx -name "OrgName Mutual SSL" \
                   -inkey private-key.key -in public-certificate.pem

            Note: Certificates are valid for 2 years. ADP sends renewal notices
            60 days before expiration.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
     """

    return sync_detailed(
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    body: ADPClientCredentialsRequest,
) -> Response[Any | HTTPValidationError]:
    r""" Adp Client Credentials

     Authenticate using ADP client credentials flow with Mutual SSL.

    ADP mandates mTLS where both client and server verify each other's
    identity through SSL certificates.

    Certificate paths can be:
    - Local file paths: /path/to/cert.pem
    - S3 URLs: s3://bucket/path/cert.pem or https://bucket.s3.region.amazonaws.com/path/cert.pem

    S3 certificates will be automatically downloaded to temporary files,
    used for authentication, then securely deleted.

    Args:
        body (ADPClientCredentialsRequest): Request model for ADP client credentials
            authentication.

            ADP requires Mutual SSL (mTLS) Authentication:
            - client_id: Your ADP client ID from ADP Developer Portal
            - client_secret: Your ADP client secret
            - ssl_cert_path: Path to SSL certificate file (PEM or PFX format)
            - ssl_key_path: Path to private key file (optional if embedded in cert)

            Supported path formats for certificates:
            - Local file path: /path/to/cert.pem
            - S3 URI: s3://bucket-name/path/to/cert.pem
            - S3 HTTPS URL: https://bucket-name.s3.region.amazonaws.com/path/to/cert.pem

            Certificate Setup:
            1. Obtain SSL certificate and private key from:
               - ADP Partners: Developer Self-Service Portal (automated)
               - ADP Clients: ADP Certificate Signing Tool (manual CSR)
               - API Central Users: API Central (automated)

            2. Upload certificates to S3 (recommended) or provide local paths:
               s3://your-bucket/adp/cert.pem
               s3://your-bucket/adp/key.key

            3. Optionally combine into single PFX file:
               openssl pkcs12 -export -out adp.pfx -name "OrgName Mutual SSL" \
                   -inkey private-key.key -in public-certificate.pem

            Note: Certificates are valid for 2 years. ADP sends renewal notices
            60 days before expiration.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | HTTPValidationError]
     """

    kwargs = _get_kwargs(
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    body: ADPClientCredentialsRequest,
) -> Any | HTTPValidationError | None:
    r""" Adp Client Credentials

     Authenticate using ADP client credentials flow with Mutual SSL.

    ADP mandates mTLS where both client and server verify each other's
    identity through SSL certificates.

    Certificate paths can be:
    - Local file paths: /path/to/cert.pem
    - S3 URLs: s3://bucket/path/cert.pem or https://bucket.s3.region.amazonaws.com/path/cert.pem

    S3 certificates will be automatically downloaded to temporary files,
    used for authentication, then securely deleted.

    Args:
        body (ADPClientCredentialsRequest): Request model for ADP client credentials
            authentication.

            ADP requires Mutual SSL (mTLS) Authentication:
            - client_id: Your ADP client ID from ADP Developer Portal
            - client_secret: Your ADP client secret
            - ssl_cert_path: Path to SSL certificate file (PEM or PFX format)
            - ssl_key_path: Path to private key file (optional if embedded in cert)

            Supported path formats for certificates:
            - Local file path: /path/to/cert.pem
            - S3 URI: s3://bucket-name/path/to/cert.pem
            - S3 HTTPS URL: https://bucket-name.s3.region.amazonaws.com/path/to/cert.pem

            Certificate Setup:
            1. Obtain SSL certificate and private key from:
               - ADP Partners: Developer Self-Service Portal (automated)
               - ADP Clients: ADP Certificate Signing Tool (manual CSR)
               - API Central Users: API Central (automated)

            2. Upload certificates to S3 (recommended) or provide local paths:
               s3://your-bucket/adp/cert.pem
               s3://your-bucket/adp/key.key

            3. Optionally combine into single PFX file:
               openssl pkcs12 -export -out adp.pfx -name "OrgName Mutual SSL" \
                   -inkey private-key.key -in public-certificate.pem

            Note: Certificates are valid for 2 years. ADP sends renewal notices
            60 days before expiration.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | HTTPValidationError
     """

    return (
        await asyncio_detailed(
            client=client,
            body=body,
        )
    ).parsed
