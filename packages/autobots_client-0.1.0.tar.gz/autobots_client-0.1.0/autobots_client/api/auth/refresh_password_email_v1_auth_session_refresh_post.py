from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.auth_response import AuthResponse
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response


def _get_kwargs(
    *,
    refresh_token: str,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["refresh_token"] = refresh_token

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/session/refresh",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> AuthResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = AuthResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[AuthResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    refresh_token: str,
) -> Response[AuthResponse | HTTPValidationError]:
    """Refresh Password Email

    Args:
        refresh_token (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AuthResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        refresh_token=refresh_token,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    refresh_token: str,
) -> AuthResponse | HTTPValidationError | None:
    """Refresh Password Email

    Args:
        refresh_token (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AuthResponse | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        refresh_token=refresh_token,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    refresh_token: str,
) -> Response[AuthResponse | HTTPValidationError]:
    """Refresh Password Email

    Args:
        refresh_token (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[AuthResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        refresh_token=refresh_token,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    refresh_token: str,
) -> AuthResponse | HTTPValidationError | None:
    """Refresh Password Email

    Args:
        refresh_token (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        AuthResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            refresh_token=refresh_token,
        )
    ).parsed
