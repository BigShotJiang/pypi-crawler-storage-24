from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    email: str,
    redirect_to: None | str | Unset = UNSET,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["email"] = email

    json_redirect_to: None | str | Unset
    if isinstance(redirect_to, Unset):
        json_redirect_to = UNSET
    else:
        json_redirect_to = redirect_to
    params["redirect_to"] = json_redirect_to

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/auth/password/reset",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | bool | None:
    if response.status_code == 200:
        response_200 = cast(bool, response.json())
        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | bool]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient | Client,
    email: str,
    redirect_to: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | bool]:
    """Reset Password Email

    Args:
        email (str):
        redirect_to (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | bool]
    """

    kwargs = _get_kwargs(
        email=email,
        redirect_to=redirect_to,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient | Client,
    email: str,
    redirect_to: None | str | Unset = UNSET,
) -> HTTPValidationError | bool | None:
    """Reset Password Email

    Args:
        email (str):
        redirect_to (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | bool
    """

    return sync_detailed(
        client=client,
        email=email,
        redirect_to=redirect_to,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient | Client,
    email: str,
    redirect_to: None | str | Unset = UNSET,
) -> Response[HTTPValidationError | bool]:
    """Reset Password Email

    Args:
        email (str):
        redirect_to (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | bool]
    """

    kwargs = _get_kwargs(
        email=email,
        redirect_to=redirect_to,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient | Client,
    email: str,
    redirect_to: None | str | Unset = UNSET,
) -> HTTPValidationError | bool | None:
    """Reset Password Email

    Args:
        email (str):
        redirect_to (None | str | Unset):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | bool
    """

    return (
        await asyncio_detailed(
            client=client,
            email=email,
            redirect_to=redirect_to,
        )
    ).parsed
