from http import HTTPStatus
from typing import Any, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.list_action_tools_v1_actions_tools_get_llm_type import ListActionToolsV1ActionsToolsGetLlmType
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    llm_type: ListActionToolsV1ActionsToolsGetLlmType | Unset = ListActionToolsV1ActionsToolsGetLlmType.VALUE_0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    json_llm_type: str | Unset = UNSET
    if not isinstance(llm_type, Unset):
        json_llm_type = llm_type.value

    params["llm_type"] = json_llm_type

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/actions/tools",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> HTTPValidationError | list[str] | None:
    if response.status_code == 200:
        response_200 = cast(list[str], response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[HTTPValidationError | list[str]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    llm_type: ListActionToolsV1ActionsToolsGetLlmType | Unset = ListActionToolsV1ActionsToolsGetLlmType.VALUE_0,
) -> Response[HTTPValidationError | list[str]]:
    """List Action Tools

    Args:
        llm_type (ListActionToolsV1ActionsToolsGetLlmType | Unset):  Default:
            ListActionToolsV1ActionsToolsGetLlmType.VALUE_0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[str]]
    """

    kwargs = _get_kwargs(
        llm_type=llm_type,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    llm_type: ListActionToolsV1ActionsToolsGetLlmType | Unset = ListActionToolsV1ActionsToolsGetLlmType.VALUE_0,
) -> HTTPValidationError | list[str] | None:
    """List Action Tools

    Args:
        llm_type (ListActionToolsV1ActionsToolsGetLlmType | Unset):  Default:
            ListActionToolsV1ActionsToolsGetLlmType.VALUE_0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[str]
    """

    return sync_detailed(
        client=client,
        llm_type=llm_type,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    llm_type: ListActionToolsV1ActionsToolsGetLlmType | Unset = ListActionToolsV1ActionsToolsGetLlmType.VALUE_0,
) -> Response[HTTPValidationError | list[str]]:
    """List Action Tools

    Args:
        llm_type (ListActionToolsV1ActionsToolsGetLlmType | Unset):  Default:
            ListActionToolsV1ActionsToolsGetLlmType.VALUE_0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[HTTPValidationError | list[str]]
    """

    kwargs = _get_kwargs(
        llm_type=llm_type,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    llm_type: ListActionToolsV1ActionsToolsGetLlmType | Unset = ListActionToolsV1ActionsToolsGetLlmType.VALUE_0,
) -> HTTPValidationError | list[str] | None:
    """List Action Tools

    Args:
        llm_type (ListActionToolsV1ActionsToolsGetLlmType | Unset):  Default:
            ListActionToolsV1ActionsToolsGetLlmType.VALUE_0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        HTTPValidationError | list[str]
    """

    return (
        await asyncio_detailed(
            client=client,
            llm_type=llm_type,
        )
    ).parsed
