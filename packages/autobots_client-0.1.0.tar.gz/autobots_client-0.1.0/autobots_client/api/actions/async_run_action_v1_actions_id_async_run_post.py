from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.action_result_doc import ActionResultDoc
from ...models.body_async_run_action_v1_actions_id_async_run_post import BodyAsyncRunActionV1ActionsIdAsyncRunPost
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    id: str,
    *,
    body: BodyAsyncRunActionV1ActionsIdAsyncRunPost,
    action_result_id: str | Unset = UNSET,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["action_result_id"] = action_result_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/actions/{id}/async_run".format(
            id=quote(str(id), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ActionResultDoc | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ActionResultDoc.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ActionResultDoc | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    body: BodyAsyncRunActionV1ActionsIdAsyncRunPost,
    action_result_id: str | Unset = UNSET,
) -> Response[ActionResultDoc | HTTPValidationError]:
    """Async Run Action

    Args:
        id (str):
        action_result_id (str | Unset):
        body (BodyAsyncRunActionV1ActionsIdAsyncRunPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ActionResultDoc | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
        action_result_id=action_result_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    id: str,
    *,
    client: AuthenticatedClient,
    body: BodyAsyncRunActionV1ActionsIdAsyncRunPost,
    action_result_id: str | Unset = UNSET,
) -> ActionResultDoc | HTTPValidationError | None:
    """Async Run Action

    Args:
        id (str):
        action_result_id (str | Unset):
        body (BodyAsyncRunActionV1ActionsIdAsyncRunPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ActionResultDoc | HTTPValidationError
    """

    return sync_detailed(
        id=id,
        client=client,
        body=body,
        action_result_id=action_result_id,
    ).parsed


async def asyncio_detailed(
    id: str,
    *,
    client: AuthenticatedClient,
    body: BodyAsyncRunActionV1ActionsIdAsyncRunPost,
    action_result_id: str | Unset = UNSET,
) -> Response[ActionResultDoc | HTTPValidationError]:
    """Async Run Action

    Args:
        id (str):
        action_result_id (str | Unset):
        body (BodyAsyncRunActionV1ActionsIdAsyncRunPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ActionResultDoc | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        id=id,
        body=body,
        action_result_id=action_result_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    id: str,
    *,
    client: AuthenticatedClient,
    body: BodyAsyncRunActionV1ActionsIdAsyncRunPost,
    action_result_id: str | Unset = UNSET,
) -> ActionResultDoc | HTTPValidationError | None:
    """Async Run Action

    Args:
        id (str):
        action_result_id (str | Unset):
        body (BodyAsyncRunActionV1ActionsIdAsyncRunPost):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ActionResultDoc | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            id=id,
            client=client,
            body=body,
            action_result_id=action_result_id,
        )
    ).parsed
