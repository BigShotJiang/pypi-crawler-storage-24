from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.action_graph_result_docs_found import ActionGraphResultDocsFound
from ...models.event_result_status import EventResultStatus
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    id: str | Unset = UNSET,
    status: EventResultStatus | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    action_graph_id: str | Unset = UNSET,
    action_graph_name: str | Unset = UNSET,
    action_graph_version: float | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["id"] = id

    json_status: str | Unset = UNSET
    if not isinstance(status, Unset):
        json_status = status.value

    params["status"] = json_status

    params["is_saved"] = is_saved

    params["action_graph_id"] = action_graph_id

    params["action_graph_name"] = action_graph_name

    params["action_graph_version"] = action_graph_version

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/action_graphs_results/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ActionGraphResultDocsFound | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ActionGraphResultDocsFound.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ActionGraphResultDocsFound | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    status: EventResultStatus | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    action_graph_id: str | Unset = UNSET,
    action_graph_name: str | Unset = UNSET,
    action_graph_version: float | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> Response[ActionGraphResultDocsFound | HTTPValidationError]:
    """List Action Graph Result

    Args:
        id (str | Unset):
        status (EventResultStatus | Unset):
        is_saved (bool | Unset):
        action_graph_id (str | Unset):
        action_graph_name (str | Unset):
        action_graph_version (float | Unset):
        limit (int | Unset):  Default: 20.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ActionGraphResultDocsFound | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        id=id,
        status=status,
        is_saved=is_saved,
        action_graph_id=action_graph_id,
        action_graph_name=action_graph_name,
        action_graph_version=action_graph_version,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    status: EventResultStatus | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    action_graph_id: str | Unset = UNSET,
    action_graph_name: str | Unset = UNSET,
    action_graph_version: float | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> ActionGraphResultDocsFound | HTTPValidationError | None:
    """List Action Graph Result

    Args:
        id (str | Unset):
        status (EventResultStatus | Unset):
        is_saved (bool | Unset):
        action_graph_id (str | Unset):
        action_graph_name (str | Unset):
        action_graph_version (float | Unset):
        limit (int | Unset):  Default: 20.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ActionGraphResultDocsFound | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        id=id,
        status=status,
        is_saved=is_saved,
        action_graph_id=action_graph_id,
        action_graph_name=action_graph_name,
        action_graph_version=action_graph_version,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    status: EventResultStatus | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    action_graph_id: str | Unset = UNSET,
    action_graph_name: str | Unset = UNSET,
    action_graph_version: float | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> Response[ActionGraphResultDocsFound | HTTPValidationError]:
    """List Action Graph Result

    Args:
        id (str | Unset):
        status (EventResultStatus | Unset):
        is_saved (bool | Unset):
        action_graph_id (str | Unset):
        action_graph_name (str | Unset):
        action_graph_version (float | Unset):
        limit (int | Unset):  Default: 20.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ActionGraphResultDocsFound | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        id=id,
        status=status,
        is_saved=is_saved,
        action_graph_id=action_graph_id,
        action_graph_name=action_graph_name,
        action_graph_version=action_graph_version,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    status: EventResultStatus | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    action_graph_id: str | Unset = UNSET,
    action_graph_name: str | Unset = UNSET,
    action_graph_version: float | Unset = UNSET,
    limit: int | Unset = 20,
    offset: int | Unset = 0,
) -> ActionGraphResultDocsFound | HTTPValidationError | None:
    """List Action Graph Result

    Args:
        id (str | Unset):
        status (EventResultStatus | Unset):
        is_saved (bool | Unset):
        action_graph_id (str | Unset):
        action_graph_name (str | Unset):
        action_graph_version (float | Unset):
        limit (int | Unset):  Default: 20.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ActionGraphResultDocsFound | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            id=id,
            status=status,
            is_saved=is_saved,
            action_graph_id=action_graph_id,
            action_graph_name=action_graph_name,
            action_graph_version=action_graph_version,
            limit=limit,
            offset=offset,
        )
    ).parsed
