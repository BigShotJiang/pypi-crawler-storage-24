from http import HTTPStatus
from typing import Any

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.action_graph_docs_found import ActionGraphDocsFound
from ...models.http_validation_error import HTTPValidationError
from ...types import UNSET, Response, Unset


def _get_kwargs(
    *,
    id: str | Unset = UNSET,
    name: str | Unset = UNSET,
    version: float | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    is_published: bool | Unset = UNSET,
    is_published_by_others: bool | Unset = UNSET,
    is_shared: bool | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> dict[str, Any]:

    params: dict[str, Any] = {}

    params["id"] = id

    params["name"] = name

    params["version"] = version

    params["is_saved"] = is_saved

    params["is_published"] = is_published

    params["is_published_by_others"] = is_published_by_others

    params["is_shared"] = is_shared

    params["limit"] = limit

    params["offset"] = offset

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "get",
        "url": "/v1/action_graphs/",
        "params": params,
    }

    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ActionGraphDocsFound | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = ActionGraphDocsFound.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ActionGraphDocsFound | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    name: str | Unset = UNSET,
    version: float | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    is_published: bool | Unset = UNSET,
    is_published_by_others: bool | Unset = UNSET,
    is_shared: bool | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[ActionGraphDocsFound | HTTPValidationError]:
    """List Action Graphs

    Args:
        id (str | Unset):
        name (str | Unset):
        version (float | Unset):
        is_saved (bool | Unset):
        is_published (bool | Unset):
        is_published_by_others (bool | Unset):
        is_shared (bool | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ActionGraphDocsFound | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        id=id,
        name=name,
        version=version,
        is_saved=is_saved,
        is_published=is_published,
        is_published_by_others=is_published_by_others,
        is_shared=is_shared,
        limit=limit,
        offset=offset,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    name: str | Unset = UNSET,
    version: float | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    is_published: bool | Unset = UNSET,
    is_published_by_others: bool | Unset = UNSET,
    is_shared: bool | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> ActionGraphDocsFound | HTTPValidationError | None:
    """List Action Graphs

    Args:
        id (str | Unset):
        name (str | Unset):
        version (float | Unset):
        is_saved (bool | Unset):
        is_published (bool | Unset):
        is_published_by_others (bool | Unset):
        is_shared (bool | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ActionGraphDocsFound | HTTPValidationError
    """

    return sync_detailed(
        client=client,
        id=id,
        name=name,
        version=version,
        is_saved=is_saved,
        is_published=is_published,
        is_published_by_others=is_published_by_others,
        is_shared=is_shared,
        limit=limit,
        offset=offset,
    ).parsed


async def asyncio_detailed(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    name: str | Unset = UNSET,
    version: float | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    is_published: bool | Unset = UNSET,
    is_published_by_others: bool | Unset = UNSET,
    is_shared: bool | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> Response[ActionGraphDocsFound | HTTPValidationError]:
    """List Action Graphs

    Args:
        id (str | Unset):
        name (str | Unset):
        version (float | Unset):
        is_saved (bool | Unset):
        is_published (bool | Unset):
        is_published_by_others (bool | Unset):
        is_shared (bool | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ActionGraphDocsFound | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        id=id,
        name=name,
        version=version,
        is_saved=is_saved,
        is_published=is_published,
        is_published_by_others=is_published_by_others,
        is_shared=is_shared,
        limit=limit,
        offset=offset,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    *,
    client: AuthenticatedClient,
    id: str | Unset = UNSET,
    name: str | Unset = UNSET,
    version: float | Unset = UNSET,
    is_saved: bool | Unset = UNSET,
    is_published: bool | Unset = UNSET,
    is_published_by_others: bool | Unset = UNSET,
    is_shared: bool | Unset = UNSET,
    limit: int | Unset = 100,
    offset: int | Unset = 0,
) -> ActionGraphDocsFound | HTTPValidationError | None:
    """List Action Graphs

    Args:
        id (str | Unset):
        name (str | Unset):
        version (float | Unset):
        is_saved (bool | Unset):
        is_published (bool | Unset):
        is_published_by_others (bool | Unset):
        is_shared (bool | Unset):
        limit (int | Unset):  Default: 100.
        offset (int | Unset):  Default: 0.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ActionGraphDocsFound | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            client=client,
            id=id,
            name=name,
            version=version,
            is_saved=is_saved,
            is_published=is_published,
            is_published_by_others=is_published_by_others,
            is_shared=is_shared,
            limit=limit,
            offset=offset,
        )
    ).parsed
