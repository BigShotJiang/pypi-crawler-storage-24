"""Database utilities for physio_std persistence."""

from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Optional


class SQLiteDatabase:
    """Lightweight SQLite helper for physio_std persistence."""

    def __init__(self, db_path: str):
        self.db_path = Path(db_path).expanduser()
        self.db_path.parent.mkdir(parents=True, exist_ok=True)

        self.conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._configure()

    def _configure(self) -> None:
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        self.conn.execute("PRAGMA foreign_keys=ON")

    def init_schema(self, schema_path: Optional[Path] = None) -> None:
        """Initialize database schema from SQL script."""
        if schema_path is None:
            schema_path = Path(__file__).parent / "schema.sql"

        schema_sql = schema_path.read_text(encoding="utf-8")
        with self.conn:
            self.conn.executescript(schema_sql)

    def close(self) -> None:
        """Close database connection."""
        self.conn.close()
