-- physio_std SQL schema (v1)

CREATE TABLE IF NOT EXISTS physio_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    device_id TEXT NOT NULL,
    source_device TEXT NOT NULL,
    data_type TEXT NOT NULL,
    timestamp_utc TEXT NOT NULL,
    value REAL NOT NULL,
    unit TEXT NOT NULL,
    confidence REAL NOT NULL CHECK (confidence >= 0.0 AND confidence <= 1.0),
    ingest_run_id TEXT,
    created_at_utc TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, device_id, timestamp_utc, data_type)
);

CREATE INDEX IF NOT EXISTS idx_physio_user_time
    ON physio_records (user_id, timestamp_utc);

CREATE INDEX IF NOT EXISTS idx_physio_device_time
    ON physio_records (device_id, timestamp_utc);

CREATE INDEX IF NOT EXISTS idx_physio_type_time
    ON physio_records (data_type, timestamp_utc);

CREATE TABLE IF NOT EXISTS unified_minute_features (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    device_type TEXT NOT NULL,
    timestamp_utc TEXT NOT NULL,
    hr_raw REAL,
    hr_norm REAL,
    stress_z_score REAL,
    spo2_clean REAL,
    resp_rate REAL,
    skin_temp REAL,
    has_skin_temp INTEGER NOT NULL DEFAULT 0,
    sleep_stage TEXT,
    sqi_daily REAL,
    ingest_run_id TEXT,
    created_at_utc TEXT NOT NULL DEFAULT (datetime('now')),
    UNIQUE (user_id, device_type, timestamp_utc)
);

CREATE INDEX IF NOT EXISTS idx_unified_user_time
    ON unified_minute_features (user_id, timestamp_utc);

CREATE TABLE IF NOT EXISTS ingestion_runs (
    run_id TEXT PRIMARY KEY,
    user_id TEXT,
    device_id TEXT,
    provider_type TEXT,
    mode TEXT NOT NULL,
    start_time_utc TEXT,
    end_time_utc TEXT,
    fetched_count INTEGER NOT NULL DEFAULT 0,
    inserted_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL,
    error_message TEXT,
    created_at_utc TEXT NOT NULL DEFAULT (datetime('now')),
    completed_at_utc TEXT
);
