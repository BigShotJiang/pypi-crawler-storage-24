"""SQL persistence repository for Module 1.2 physiological data."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import List, Optional, Sequence

import pandas as pd

from ..protocols import DataType, PhysioRecord
from .db import SQLiteDatabase


class SQLitePhysioRepository:
    """Persist and query standardized physiological data in SQLite."""

    def __init__(self, db_path: str):
        self.logger = logging.getLogger("physio_std.SQLitePhysioRepository")
        self.db = SQLiteDatabase(db_path)
        self.db.init_schema()

    def save_records(
        self,
        *,
        user_id: str,
        device_id: str,
        records: Sequence[PhysioRecord],
        ingest_run_id: Optional[str] = None,
    ) -> int:
        """Upsert PhysioRecord rows. Returns number of processed rows."""
        if not records:
            return 0

        rows = []
        for r in records:
            rows.append(
                (
                    user_id,
                    device_id,
                    r.source_device,
                    r.data_type.value,
                    self._ts(r.timestamp_utc),
                    float(r.value),
                    str(r.unit),
                    float(r.confidence),
                    ingest_run_id,
                )
            )

        sql = """
            INSERT INTO physio_records (
                user_id, device_id, source_device, data_type, timestamp_utc,
                value, unit, confidence, ingest_run_id
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (user_id, device_id, timestamp_utc, data_type)
            DO UPDATE SET
                source_device = excluded.source_device,
                value = excluded.value,
                unit = excluded.unit,
                confidence = excluded.confidence,
                ingest_run_id = COALESCE(excluded.ingest_run_id, physio_records.ingest_run_id)
        """

        with self.db.conn:
            self.db.conn.executemany(sql, rows)

        return len(rows)

    def load_records(
        self,
        *,
        user_id: str,
        start_time: datetime,
        end_time: datetime,
        device_id: Optional[str] = None,
        data_types: Optional[Sequence[DataType]] = None,
    ) -> List[PhysioRecord]:
        """Load records in a time window and convert to PhysioRecord."""
        sql = """
            SELECT source_device, data_type, timestamp_utc, value, unit, confidence
            FROM physio_records
            WHERE user_id = ?
              AND timestamp_utc >= ?
              AND timestamp_utc <= ?
        """
        params: List = [user_id, self._ts(start_time), self._ts(end_time)]

        if device_id:
            sql += " AND device_id = ?"
            params.append(device_id)

        if data_types:
            placeholders = ",".join(["?"] * len(data_types))
            sql += f" AND data_type IN ({placeholders})"
            params.extend([d.value for d in data_types])

        sql += " ORDER BY timestamp_utc ASC"

        cur = self.db.conn.execute(sql, params)
        out: List[PhysioRecord] = []

        for row in cur.fetchall():
            try:
                out.append(
                    PhysioRecord(
                        timestamp_utc=self._from_ts(row["timestamp_utc"]),
                        source_device=row["source_device"],
                        data_type=DataType(row["data_type"]),
                        value=float(row["value"]),
                        unit=row["unit"],
                        confidence=float(row["confidence"]),
                    )
                )
            except Exception as e:
                self.logger.warning("Skipping invalid DB row: %s", e)

        return out

    def save_unified_dataframe(
        self,
        *,
        user_id: str,
        device_type: str,
        df: pd.DataFrame,
        ingest_run_id: Optional[str] = None,
    ) -> int:
        """Upsert unified minute-level DataFrame rows."""
        if df is None or len(df) == 0:
            return 0

        rows = []
        for _, row in df.iterrows():
            ts = pd.Timestamp(row["timestamp"]).to_pydatetime()
            rows.append(
                (
                    user_id,
                    device_type,
                    self._ts(ts),
                    self._to_float(row.get("hr_raw")),
                    self._to_float(row.get("hr_norm")),
                    self._to_float(row.get("stress_z_score")),
                    self._to_float(row.get("spo2_clean")),
                    self._to_float(row.get("resp_rate")),
                    self._to_float(row.get("skin_temp")),
                    int(row.get("has_skin_temp", 0) or 0),
                    self._to_str_or_none(row.get("sleep_stage")),
                    self._to_float(row.get("sqi_daily")),
                    ingest_run_id,
                )
            )

        sql = """
            INSERT INTO unified_minute_features (
                user_id, device_type, timestamp_utc,
                hr_raw, hr_norm, stress_z_score, spo2_clean,
                resp_rate, skin_temp, has_skin_temp,
                sleep_stage, sqi_daily, ingest_run_id
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (user_id, device_type, timestamp_utc)
            DO UPDATE SET
                hr_raw = excluded.hr_raw,
                hr_norm = excluded.hr_norm,
                stress_z_score = excluded.stress_z_score,
                spo2_clean = excluded.spo2_clean,
                resp_rate = excluded.resp_rate,
                skin_temp = excluded.skin_temp,
                has_skin_temp = excluded.has_skin_temp,
                sleep_stage = excluded.sleep_stage,
                sqi_daily = excluded.sqi_daily,
                ingest_run_id = COALESCE(excluded.ingest_run_id, unified_minute_features.ingest_run_id)
        """

        with self.db.conn:
            self.db.conn.executemany(sql, rows)

        return len(rows)

    def count_records(
        self,
        *,
        user_id: Optional[str] = None,
        device_id: Optional[str] = None,
    ) -> int:
        """Count persisted raw physio records with optional filters."""
        sql = "SELECT COUNT(*) AS n FROM physio_records WHERE 1=1"
        params: List = []

        if user_id:
            sql += " AND user_id = ?"
            params.append(user_id)
        if device_id:
            sql += " AND device_id = ?"
            params.append(device_id)

        cur = self.db.conn.execute(sql, params)
        row = cur.fetchone()
        return int(row["n"]) if row else 0

    def close(self) -> None:
        self.db.close()

    @staticmethod
    def _ts(dt: datetime) -> str:
        return dt.replace(tzinfo=None).isoformat(sep=" ", timespec="seconds")

    @staticmethod
    def _from_ts(raw: str) -> datetime:
        return datetime.fromisoformat(str(raw).replace("T", " "))

    @staticmethod
    def _to_float(v):
        if v is None or pd.isna(v):
            return None
        return float(v)

    @staticmethod
    def _to_str_or_none(v):
        if v is None or pd.isna(v):
            return None
        return str(v)
