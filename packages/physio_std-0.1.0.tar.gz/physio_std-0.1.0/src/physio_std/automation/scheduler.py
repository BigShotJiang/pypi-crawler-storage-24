"""
Automated scheduler for physiological data synchronization.

Provides:
- Scheduled daily data sync from all configured devices
- Automatic file cleanup based on retention policy
- Configurable sync times and output directories
- Comprehensive logging
"""

import logging
import time
from datetime import datetime, timedelta, time as time_obj
from pathlib import Path
from typing import Optional
import schedule

from ..config import PhysioConfig
from ..manager import PhysioDeviceManager
from ..core import PhysioStandardizer


class PhysioScheduler:
    """
    Automated scheduler for daily physiological data sync.

    Features:
    - Configurable daily sync time
    - Automatic device connection and disconnection
    - Data export to Excel with timestamped filenames
    - Retention policy for automatic cleanup of old files
    - Error handling and logging

    Example:
        >>> config = PhysioConfig()
        >>> scheduler = PhysioScheduler(config)
        >>> scheduler.start()  # Runs forever (blocking)
    """

    def __init__(self, config: PhysioConfig):
        """
        Initialize scheduler with configuration.

        Args:
            config: PhysioConfig instance with automation settings
        """
        self.config = config
        self.logger = logging.getLogger("physio_std.PhysioScheduler")

        # Initialize components
        self.manager = PhysioDeviceManager(config)
        self.standardizer = PhysioStandardizer()

        # Get automation settings
        self.automation = config.automation
        self.sync_time = self.automation.get('sync_time', '08:00')
        self.data_retention_days = self.automation.get('data_retention_days', 90)
        self.output_dir = Path(self.automation.get('output_directory', '~/physio_data/')).expanduser()

        # Ensure output directory exists
        self.output_dir.mkdir(parents=True, exist_ok=True)

        self.logger.info(f"Scheduler initialized")
        self.logger.info(f"  Sync time: {self.sync_time}")
        self.logger.info(f"  Output directory: {self.output_dir}")
        self.logger.info(f"  Retention: {self.data_retention_days} days")

    def run_daily_sync(self):
        """
        Execute daily synchronization of all devices.

        This method:
        1. Connects to all configured devices
        2. Fetches yesterday's complete data
        3. Exports to timestamped Excel file
        4. Disconnects from all devices
        5. Cleans up old files based on retention policy

        Called automatically by the scheduler at the configured time.
        """
        self.logger.info("=" * 70)
        self.logger.info("Starting scheduled daily sync")
        self.logger.info("=" * 70)

        start_timestamp = datetime.now()

        try:
            # Step 1: Connect to devices
            self.logger.info("Connecting to devices...")
            connection_results = self.manager.connect_all()

            connected_count = sum(1 for status in connection_results.values() if status == 'connected')
            self.logger.info(f"Connected to {connected_count}/{len(connection_results)} devices")

            for device_id, status in connection_results.items():
                if status == 'connected':
                    self.logger.info(f"  ✓ {device_id}: {status}")
                else:
                    self.logger.warning(f"  ✗ {device_id}: {status}")

            if connected_count == 0:
                self.logger.error("No devices connected. Aborting sync.")
                return

            # Step 2: Fetch yesterday's data
            # Using yesterday to ensure complete data (today is still in progress)
            today = datetime.now().date()
            yesterday = today - timedelta(days=1)

            start_time = datetime.combine(yesterday, time_obj.min)
            end_time = datetime.combine(yesterday, time_obj.max)

            self.logger.info(f"Fetching data for: {yesterday.strftime('%Y-%m-%d')}")
            self.logger.info(f"  Time range: {start_time} to {end_time}")

            records = self.manager.fetch_all_data(start_time, end_time)

            self.logger.info(f"Fetched {len(records)} total records")

            if len(records) == 0:
                self.logger.warning("No records fetched. Check device sync status.")
                # Still continue to disconnect
            else:
                # Show breakdown by device and type
                from collections import defaultdict
                by_device = defaultdict(int)
                by_type = defaultdict(int)

                for record in records:
                    by_device[record.source_device] += 1
                    by_type[record.data_type.value] += 1

                self.logger.info("Records by device:")
                for device, count in by_device.items():
                    self.logger.info(f"  - {device}: {count}")

                self.logger.info("Records by data type:")
                for data_type, count in by_type.items():
                    self.logger.info(f"  - {data_type}: {count}")

            # Step 3: Export to Excel
            if records:
                filename = f"physio_data_{yesterday.strftime('%Y%m%d')}.xlsx"
                output_path = self.output_dir / filename

                self.logger.info(f"Exporting to: {output_path}")
                self.standardizer.to_excel(records, str(output_path))
                self.logger.info(f"✓ Export successful")

            # Step 4: Disconnect
            self.logger.info("Disconnecting from devices...")
            self.manager.disconnect_all()
            self.logger.info("✓ Disconnected")

            # Step 5: Cleanup old files
            self.logger.info("Running file cleanup...")
            deleted_count = self._cleanup_old_files()
            if deleted_count > 0:
                self.logger.info(f"✓ Deleted {deleted_count} old file(s)")
            else:
                self.logger.info("✓ No old files to delete")

            # Success summary
            duration = (datetime.now() - start_timestamp).total_seconds()
            self.logger.info("=" * 70)
            self.logger.info(f"Daily sync completed successfully in {duration:.1f}s")
            self.logger.info(f"Records: {len(records)}, Exported: {len(records) > 0}")
            self.logger.info("=" * 70)

        except Exception as e:
            self.logger.error(f"Daily sync failed: {e}", exc_info=True)
            # Always try to disconnect even if there was an error
            try:
                self.manager.disconnect_all()
            except Exception as disconnect_error:
                self.logger.error(f"Error during cleanup disconnect: {disconnect_error}")

    def _cleanup_old_files(self) -> int:
        """
        Delete data files older than retention period.

        Returns:
            Number of files deleted

        Files matching pattern: physio_data_YYYYMMDD.xlsx
        Files older than data_retention_days are deleted.
        """
        if self.data_retention_days <= 0:
            self.logger.debug("File cleanup disabled (retention_days <= 0)")
            return 0

        cutoff_date = datetime.now() - timedelta(days=self.data_retention_days)
        deleted_count = 0

        # Find all physio data files
        pattern = "physio_data_*.xlsx"
        files = list(self.output_dir.glob(pattern))

        self.logger.debug(f"Checking {len(files)} file(s) for cleanup")

        for file_path in files:
            try:
                # Extract date from filename: physio_data_YYYYMMDD.xlsx
                date_str = file_path.stem.split('_')[-1]  # Get YYYYMMDD part

                if len(date_str) == 8 and date_str.isdigit():
                    file_date = datetime.strptime(date_str, '%Y%m%d')

                    if file_date < cutoff_date:
                        self.logger.debug(f"Deleting old file: {file_path.name} (from {file_date.date()})")
                        file_path.unlink()
                        deleted_count += 1
                else:
                    self.logger.debug(f"Skipping file with non-standard name: {file_path.name}")

            except (ValueError, IndexError) as e:
                self.logger.warning(f"Could not parse date from {file_path.name}: {e}")
            except Exception as e:
                self.logger.error(f"Error deleting {file_path.name}: {e}")

        return deleted_count

    def setup_schedule(self):
        """
        Configure the daily sync schedule.

        Sets up the schedule job based on config.automation.sync_time.
        The job will run every day at the specified time.
        """
        self.logger.info(f"Setting up daily sync at {self.sync_time}")

        # Clear any existing jobs
        schedule.clear()

        # Schedule daily sync
        schedule.every().day.at(self.sync_time).do(self.run_daily_sync)

        self.logger.info("✓ Schedule configured")

    def run_once(self):
        """
        Run sync immediately (one-time execution).

        Useful for:
        - Testing the sync process
        - Manual sync trigger
        - Initial sync before starting scheduler
        """
        self.logger.info("Running one-time sync")
        self.run_daily_sync()

    def start(self):
        """
        Start the scheduler (blocking).

        This method runs forever, checking every minute if any scheduled
        jobs need to run. Use Ctrl+C to stop.

        Example:
            >>> scheduler = PhysioScheduler(config)
            >>> scheduler.start()  # Blocks here
        """
        self.setup_schedule()

        self.logger.info("=" * 70)
        self.logger.info("Scheduler started")
        self.logger.info(f"Next sync: {schedule.next_run()}")
        self.logger.info("Press Ctrl+C to stop")
        self.logger.info("=" * 70)

        try:
            while True:
                schedule.run_pending()
                time.sleep(60)  # Check every minute

        except KeyboardInterrupt:
            self.logger.info("\nScheduler stopped by user")

    def get_next_run_time(self) -> Optional[datetime]:
        """
        Get the next scheduled run time.

        Returns:
            Next scheduled run time, or None if no jobs scheduled
        """
        next_run = schedule.next_run()
        return next_run

    def get_status(self) -> dict:
        """
        Get scheduler status information.

        Returns:
            Dictionary with status information including:
            - enabled: Whether automation is enabled
            - sync_time: Configured sync time
            - next_run: Next scheduled run time
            - output_dir: Output directory path
            - retention_days: File retention period
            - connected_devices: Number of available devices
        """
        return {
            'enabled': self.automation.get('enabled', False),
            'sync_time': self.sync_time,
            'next_run': self.get_next_run_time(),
            'output_dir': str(self.output_dir),
            'retention_days': self.data_retention_days,
            'connected_devices': len(self.manager.providers)
        }


def main():
    """
    Main entry point for running the scheduler as a standalone service.

    Usage:
        python -m src.physio_std.automation.scheduler
    """
    # Set up logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler(Path.home() / '.physio_std' / 'scheduler.log')
        ]
    )

    logger = logging.getLogger("physio_std")
    logger.info("Starting PhysioScheduler service")

    try:
        # Load configuration
        config = PhysioConfig()

        # Check if automation is enabled
        if not config.automation.get('enabled', False):
            logger.warning("Automation is disabled in config")
            logger.warning("Enable it with: config.update_automation(enabled=True)")
            return

        # Create and start scheduler
        scheduler = PhysioScheduler(config)
        scheduler.start()

    except KeyboardInterrupt:
        logger.info("Service stopped")
    except Exception as e:
        logger.error(f"Service error: {e}", exc_info=True)
        raise


if __name__ == "__main__":
    main()
