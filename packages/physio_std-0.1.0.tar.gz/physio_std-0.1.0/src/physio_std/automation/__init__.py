"""
Automation module for physio_std.

Provides scheduled data synchronization and cleanup services.
"""

from .scheduler import PhysioScheduler

__all__ = ['PhysioScheduler']
