"""
Command-line interface for physio_std.

Provides commands for:
- Manual data synchronization
- Device management (add, remove, enable, disable)
- Configuration viewing
- Scheduler control
"""

import sys
from pathlib import Path

import click
from datetime import datetime, timedelta
import logging
import pandas as pd

from .config import PhysioConfig
from .manager import PhysioDeviceManager
from .automation.scheduler import PhysioScheduler
from .core import PhysioStandardizer


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(levelname)s: %(message)s'
)


def _analyze_records_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    """Compute daily longitudinal stats from standardized record dataframe."""
    if df is None or df.empty:
        return pd.DataFrame()

    work = df.copy()
    work['timestamp_utc'] = pd.to_datetime(work['timestamp_utc'], utc=False, errors='coerce')
    work = work.dropna(subset=['timestamp_utc'])
    if work.empty:
        return pd.DataFrame()

    work['date'] = work['timestamp_utc'].dt.date

    def _daily_metric(data_type: str, agg: str, col_name: str) -> pd.DataFrame:
        sub = work[work['data_type'] == data_type]
        if sub.empty:
            return pd.DataFrame(columns=['date', col_name])
        grouped = sub.groupby('date', as_index=False)['value'].agg(agg)
        grouped = grouped.rename(columns={'value': col_name})
        return grouped

    hr_mean = _daily_metric('heart_rate', 'mean', 'hr_mean')
    hrv_median = _daily_metric('hrv', 'median', 'hrv_rmssd_proxy_median')
    stress_mean = _daily_metric('stress_score', 'mean', 'stress_mean')
    stress_std = _daily_metric('stress_score', 'std', 'stress_std')
    spo2_mean = _daily_metric('spo2', 'mean', 'spo2_mean')

    daily_records = work.groupby('date', as_index=False).size().rename(columns={'size': 'records_count'})

    sleep = work[work['data_type'] == 'sleep_stage'][['date', 'unit']].copy()
    if sleep.empty:
        sleep_mode = pd.DataFrame(columns=['date', 'sleep_stage_mode'])
    else:
        sleep = sleep.rename(columns={'unit': 'sleep_stage'})
        sleep_mode = (
            sleep.groupby(['date', 'sleep_stage']).size().reset_index(name='n')
            .sort_values(['date', 'n'], ascending=[True, False])
            .drop_duplicates(subset=['date'])[['date', 'sleep_stage']]
            .rename(columns={'sleep_stage': 'sleep_stage_mode'})
        )

    merged = daily_records
    for part in [hr_mean, hrv_median, stress_mean, stress_std, spo2_mean, sleep_mode]:
        merged = merged.merge(part, on='date', how='left')

    merged = merged.sort_values('date').reset_index(drop=True)

    # Rolling trend features
    for c in ['hr_mean', 'hrv_rmssd_proxy_median', 'stress_mean', 'spo2_mean']:
        if c in merged.columns:
            merged[f'{c}_ma7'] = merged[c].rolling(window=7, min_periods=1).mean()
            merged[f'{c}_ma30'] = merged[c].rolling(window=30, min_periods=1).mean()

    # Baseline z-scores (whole-window baseline)
    for c in ['hr_mean', 'hrv_rmssd_proxy_median', 'stress_mean', 'spo2_mean']:
        if c in merged.columns:
            mu = merged[c].mean(skipna=True)
            sigma = merged[c].std(skipna=True)
            if sigma and sigma > 0:
                merged[f'{c}_z'] = (merged[c] - mu) / sigma
            else:
                merged[f'{c}_z'] = pd.NA

    return merged


@click.group()
@click.version_option(version='0.1.0', prog_name='physio-std')
def cli():
    """
    physio-std: Physiological data management CLI.

    Extract and standardize health data from multiple wearable devices.
    Supports Garmin, Huawei, and Lifesense Ring.
    """
    pass


@cli.command()
@click.option('--device-id', help='Specific device to sync (default: all enabled devices)')
@click.option('--days', default=1, type=int, help='Number of days to fetch (default: 1)')
@click.option('--output', '-o', help='Output file path (default: auto-generated)')
@click.option('--format', type=click.Choice(['excel', 'csv']), default='excel', help='Output format')
@click.option('--persist-db/--no-persist-db', default=None, help='Enable/disable SQL persistence for this run')
@click.option('--db-path', help='SQLite database path override for this run')
@click.option('--unified', is_flag=True, help='Export 1-minute aligned wide table (Garmin/Huawei only)')
@click.option('--user-id', default='default_user', show_default=True, help='User identifier for unified export')
@click.option('--hr-rest', default=60.0, type=float, show_default=True, help='Resting HR for HRR normalization')
@click.option('--hr-max', default=190.0, type=float, show_default=True, help='Max HR for HRR normalization')
def sync(device_id, days, output, format, persist_db, db_path, unified, user_id, hr_rest, hr_max):
    """
    Manually trigger data synchronization.

    Fetches data from configured devices and exports to file.

    Examples:
        physio-std sync                    # Sync all devices, last 24h
        physio-std sync --days 7           # Sync last 7 days
        physio-std sync --device-id my_garmin  # Sync specific device
        physio-std sync -o custom.xlsx     # Custom output file
        physio-std sync --unified --device-id my_garmin --days 3
    """
    try:
        config = PhysioConfig()
        persistence_override = {}
        if persist_db is not None:
            persistence_override['enabled'] = bool(persist_db)
            if persist_db:
                persistence_override['backend'] = 'sqlite'
        if db_path:
            persistence_override['backend'] = 'sqlite'
            persistence_override['db_path'] = db_path

        manager = PhysioDeviceManager(
            config,
            persistence_override=persistence_override or None,
        )

        # Show configured devices
        if device_id:
            devices_to_sync = [device_id]
            click.echo(f"Syncing device: {device_id}")
        else:
            devices_to_sync = None
            click.echo(f"Syncing all enabled devices ({len(manager.providers)} device(s))")

        # Connect to devices
        click.echo("\nConnecting to devices...")
        with click.progressbar(length=100, label='Connecting') as bar:
            results = manager.connect_all(devices=devices_to_sync)
            bar.update(100)

        # Show connection results
        connected_devices = []
        for dev_id, status in results.items():
            symbol = "✓" if status == "connected" else "✗"
            color = "green" if status == "connected" else "red"
            click.echo(f"  {symbol} ", nl=False)
            click.secho(f"{dev_id}: {status}", fg=color)

            if status == "connected":
                connected_devices.append(dev_id)

        if not connected_devices:
            click.secho("\n✗ No devices connected. Check your configuration.", fg='red')
            sys.exit(1)

        # Fetch data
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)

        click.echo(f"\nFetching data:")
        click.echo(f"  Time range: {start_time.date()} to {end_time.date()}")
        click.echo(f"  Devices: {', '.join(connected_devices)}")
        click.echo()

        if unified:
            import pandas as pd

            click.echo("\nUsing unified 1-minute alignment pipeline...")
            unified_frames = []

            with click.progressbar(length=len(connected_devices), label='Aligning data') as bar:
                for dev_id in connected_devices:
                    try:
                        df_u = manager.fetch_unified_dataframe(
                            user_id=user_id,
                            device_id=dev_id,
                            start_time=start_time,
                            end_time=end_time,
                            hr_rest=hr_rest,
                            hr_max=hr_max,
                        )
                        if not df_u.empty:
                            unified_frames.append(df_u)
                    except ValueError as e:
                        click.secho(f"  ⚠ Skipping {dev_id}: {e}", fg='yellow')
                    bar.update(1)

            if not unified_frames:
                click.secho("\n⚠ No unified-compatible data found (requires Garmin/Huawei)", fg='yellow')
                manager.disconnect_all()
                return

            unified_df = pd.concat(unified_frames, axis=0, ignore_index=False)
            unified_df = unified_df.sort_values(by=['timestamp', 'device_type'])

            click.secho(f"\n✓ Unified rows: {len(unified_df)}", fg='green')

            click.echo("\nUnified data breakdown:")
            for device_type, count in unified_df['device_type'].value_counts().items():
                click.echo(f"  - {device_type}: {count} rows")
        else:
            with click.progressbar(length=100, label='Fetching data') as bar:
                records = manager.fetch_all_data(start_time, end_time, devices=devices_to_sync)
                bar.update(100)

            click.secho(f"\n✓ Fetched {len(records)} records", fg='green')

            if not records:
                click.secho("\n⚠ No data found in the specified time range", fg='yellow')
                click.echo("\nTips:")
                click.echo("  - Ensure devices have synced recently")
                click.echo("  - Try a wider date range (e.g., --days 7)")
                click.echo("  - Check device data at respective web portals")
                manager.disconnect_all()
                return

            # Show breakdown
            from collections import defaultdict
            by_device = defaultdict(int)
            by_type = defaultdict(int)

            for record in records:
                by_device[record.source_device] += 1
                by_type[record.data_type.value] += 1

            click.echo("\nData breakdown:")
            click.echo("  By device:")
            for device, count in sorted(by_device.items()):
                click.echo(f"    - {device}: {count} records")

            click.echo("  By data type:")
            for data_type, count in sorted(by_type.items()):
                click.echo(f"    - {data_type}: {count} records")

        # Export to file
        if not output:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            export_dir = Path("data/physio_exports")
            export_dir.mkdir(parents=True, exist_ok=True)
            output = str(
                export_dir / f"physio_data_{days}days_{timestamp}.{format if format == 'csv' else 'xlsx'}"
            )

        click.echo(f"\nExporting to: {output}")

        if unified:
            if format == 'excel':
                unified_df.to_excel(output, index=False)
            else:
                unified_df.to_csv(output, index=False)
        else:
            standardizer = PhysioStandardizer()

            if format == 'excel':
                standardizer.to_excel(records, output)
            else:  # csv
                df = standardizer.to_dataframe(records)
                df.to_csv(output, index=False)

        click.secho(f"✓ Exported successfully!", fg='green')

        # Cleanup
        manager.disconnect_all()

        click.echo(f"\n📊 Health data saved to: {output}")

    except KeyError as e:
        click.secho(f"\n✗ Device not found: {e}", fg='red')
        click.echo("Run 'physio-std devices' to see configured devices")
        sys.exit(1)
    except Exception as e:
        click.secho(f"\n✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command('init-db')
@click.option('--db-path', help='SQLite database path (default from config persistence.db_path)')
def init_db(db_path):
    """Initialize SQL persistence database schema for physio_std."""
    try:
        config = PhysioConfig()
        target_path = db_path or str(config.persistence.get('db_path', '~/.physio_std/physio.db'))

        from .storage.repository import SQLitePhysioRepository

        repo = SQLitePhysioRepository(target_path)
        repo.close()
        click.secho(f"✓ SQL schema initialized at: {Path(target_path).expanduser()}", fg='green')
    except Exception as e:
        click.secho(f"✗ Failed to initialize database: {e}", fg='red')
        sys.exit(1)


@cli.command('db-status')
@click.option('--db-path', help='SQLite database path override')
def db_status(db_path):
    """Show SQL persistence status and high-level record counts."""
    try:
        config = PhysioConfig()
        persistence_override = None
        if db_path:
            persistence_override = {
                'enabled': True,
                'backend': 'sqlite',
                'db_path': db_path,
            }

        manager = PhysioDeviceManager(config, persistence_override=persistence_override)
        status = manager.get_persistence_status()

        click.echo("\nSQL persistence status:")
        click.echo(f"  Enabled: {status.get('enabled')}")
        click.echo(f"  Backend: {status.get('backend')}")
        click.echo(f"  DB path: {status.get('db_path')}")
        click.echo(f"  Repository ready: {status.get('repository_ready')}")
        if status.get('repository_ready'):
            click.echo(f"  Persisted records: {status.get('record_count', 0)}")

        manager.disconnect_all()
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command('db-export')
@click.option('--user-id', required=True, help='Logical user ID for record selection')
@click.option('--days', default=7, type=int, show_default=True, help='Lookback window in days')
@click.option('--device-id', default=None, help='Filter by device ID')
@click.option('--format', type=click.Choice(['excel', 'csv']), default='csv', show_default=True)
@click.option('--output', '-o', default=None, help='Output file path')
@click.option('--db-path', help='SQLite database path override')
def db_export(user_id, days, device_id, format, output, db_path):
    """Export persisted SQL records to CSV/XLSX for long-term analysis."""
    try:
        config = PhysioConfig()
        persistence_override = {
            'enabled': True,
            'backend': 'sqlite',
        }
        if db_path:
            persistence_override['db_path'] = db_path

        manager = PhysioDeviceManager(config, persistence_override=persistence_override)
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)

        records = manager.load_persisted_data(
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            device_id=device_id,
        )

        if not records:
            click.secho("No persisted records found for the query window.", fg='yellow')
            manager.disconnect_all()
            return

        if not output:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            export_dir = Path("data/physio_exports")
            export_dir.mkdir(parents=True, exist_ok=True)
            suffix = 'xlsx' if format == 'excel' else 'csv'
            dev_tag = f"_{device_id}" if device_id else ""
            output = str(export_dir / f"physio_db_{user_id}{dev_tag}_{days}days_{timestamp}.{suffix}")

        standardizer = PhysioStandardizer()
        if format == 'excel':
            standardizer.to_excel(records, output)
        else:
            df = standardizer.to_dataframe(records)
            df.to_csv(output, index=False)

        click.secho(f"✓ Exported {len(records)} persisted records to: {output}", fg='green')
        manager.disconnect_all()
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command('db-analyze')
@click.option('--user-id', required=True, help='Logical user ID for analysis')
@click.option('--days', default=30, type=int, show_default=True, help='Lookback window in days')
@click.option('--device-id', default=None, help='Filter by device ID')
@click.option('--output', '-o', default=None, help='Output CSV file path for daily analytics')
@click.option('--db-path', help='SQLite database path override')
def db_analyze(user_id, days, device_id, output, db_path):
    """Analyze persisted SQL records and export daily trend metrics."""
    try:
        config = PhysioConfig()
        persistence_override = {
            'enabled': True,
            'backend': 'sqlite',
        }
        if db_path:
            persistence_override['db_path'] = db_path

        manager = PhysioDeviceManager(config, persistence_override=persistence_override)
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)

        records = manager.load_persisted_data(
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            device_id=device_id,
        )

        if not records:
            click.secho("No persisted records found for analysis window.", fg='yellow')
            manager.disconnect_all()
            return

        standardizer = PhysioStandardizer()
        df = standardizer.to_dataframe(records)
        daily = _analyze_records_dataframe(df)
        if daily.empty:
            click.secho("No analyzable data found after preprocessing.", fg='yellow')
            manager.disconnect_all()
            return

        if not output:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            export_dir = Path("data/physio_exports")
            export_dir.mkdir(parents=True, exist_ok=True)
            dev_tag = f"_{device_id}" if device_id else ""
            output = str(export_dir / f"physio_analysis_{user_id}{dev_tag}_{days}days_{timestamp}.csv")

        daily.to_csv(output, index=False)

        click.secho(f"✓ Daily analytics exported: {output}", fg='green')
        click.echo(f"  Days analyzed: {len(daily)}")

        last = daily.iloc[-1]
        click.echo("\nLatest day snapshot:")
        click.echo(f"  Date: {last.get('date')}")
        click.echo(f"  HR mean: {last.get('hr_mean')}")
        click.echo(f"  HRV median proxy: {last.get('hrv_rmssd_proxy_median')}")
        click.echo(f"  Stress mean/std: {last.get('stress_mean')} / {last.get('stress_std')}")
        click.echo(f"  SpO2 mean: {last.get('spo2_mean')}")
        click.echo(f"  Sleep stage mode: {last.get('sleep_stage_mode')}")

        manager.disconnect_all()
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command('add-device')
@click.argument('device_id')
@click.option('--type', 'device_type', type=click.Choice(['garmin', 'huawei', 'lifesense_ring', 'mock']),
              prompt='Device type', help='Type of device')
def add_device(device_id, device_type):
    """
    Add a new device configuration.

    DEVICE_ID: Unique identifier for the device (e.g., my_garmin)

    Examples:
        physio-std add-device my_garmin --type garmin
        physio-std add-device my_watch  # Interactive prompt for type
    """
    try:
        config = PhysioConfig()

        click.echo(f"\nAdding device: {device_id} ({device_type})")
        click.echo()

        # Collect credentials based on device type
        credentials = {}

        if device_type == 'garmin':
            click.echo("Garmin Connect credentials:")
            region = click.prompt(
                '  Server region',
                type=click.Choice(['global', 'cn']),
                default='global'
            )
            credentials['email'] = click.prompt('  Email')
            credentials['password'] = click.prompt('  Password', hide_input=True)
            credentials['is_cn'] = (region == 'cn')
            credentials['region'] = region

        elif device_type == 'huawei':
            mode = click.prompt(
                '  Mode',
                type=click.Choice(['gdpr', 'api']),
                default='gdpr'
            )

            if mode == 'gdpr':
                gdpr_export_path = click.prompt('  GDPR export folder path')
            else:
                click.echo("\nHuawei Health Kit API credentials:")
                credentials['client_id'] = click.prompt('  Client ID')
                credentials['client_secret'] = click.prompt('  Client Secret', hide_input=True)
                credentials['access_token'] = click.prompt('  Access Token', hide_input=True)
                credentials['refresh_token'] = click.prompt('  Refresh Token', hide_input=True)

        elif device_type == 'lifesense_ring':
            click.echo("Lifesense Ring BLE settings:")
            credentials['device_mac'] = click.prompt('  Device MAC address (optional)', default='', show_default=False)
            credentials['device_name'] = click.prompt('  Device name', default='Ring')

        elif device_type == 'mock':
            mode = click.prompt(
                '  Mode',
                type=click.Choice(['synthetic', 'csv']),
                default='synthetic'
            )
            credentials['mode'] = mode
            if mode == 'csv':
                credentials['data_file'] = click.prompt('  CSV file path')

        # Add device
        if device_type == 'huawei' and mode == 'gdpr':
            config.add_device(
                device_id,
                device_type,
                {},
                enabled=True,
                fallback='gdpr_export',
                gdpr_export_path=gdpr_export_path
            )
        else:
            config.add_device(device_id, device_type, credentials, enabled=True)

        click.secho(f"\n✓ Device '{device_id}' added successfully!", fg='green')
        click.echo(f"\nConfiguration saved to: {config.config_path}")
        click.echo("\nNext steps:")
        click.echo(f"  1. Test the device: physio-std sync --device-id {device_id}")
        click.echo("  2. View all devices: physio-std devices")

    except ValueError as e:
        click.secho(f"\n✗ Invalid device type: {e}", fg='red')
        sys.exit(1)
    except Exception as e:
        click.secho(f"\n✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command('devices')
@click.option('--verbose', '-v', is_flag=True, help='Show detailed information')
def list_devices(verbose):
    """
    List all configured devices.

    Shows device ID, type, and status.

    Examples:
        physio-std devices          # Basic list
        physio-std devices -v       # Detailed information
    """
    try:
        config = PhysioConfig()
        devices = config.list_devices()

        if not devices:
            click.echo("No devices configured.")
            click.echo("\nAdd a device with: physio-std add-device <device_id> --type <type>")
            return

        click.echo(f"\nConfigured devices ({len(devices)} total):\n")

        for device_id, device_config in devices.items():
            status_symbol = "✓" if device_config.get('enabled') else "✗"
            status_text = "enabled" if device_config.get('enabled') else "disabled"
            status_color = "green" if device_config.get('enabled') else "yellow"

            click.echo(f"{status_symbol} ", nl=False)
            click.secho(f"{device_id}", fg='cyan', bold=True, nl=False)
            click.echo(f" ({device_config['type']}) - ", nl=False)
            click.secho(status_text, fg=status_color)

            if verbose:
                click.echo(f"  Credentials: {', '.join(device_config['credentials'].keys())}")

        if not verbose:
            click.echo("\nUse -v flag for detailed information")

        click.echo(f"\nConfiguration file: {config.config_path}")

    except Exception as e:
        click.secho(f"\n✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command()
@click.argument('device_id')
def enable(device_id):
    """
    Enable a device for synchronization.

    DEVICE_ID: Device identifier to enable

    Example:
        physio-std enable my_garmin
    """
    try:
        config = PhysioConfig()
        config.enable_device(device_id)
        click.secho(f"✓ Device '{device_id}' enabled", fg='green')
    except KeyError:
        click.secho(f"✗ Device '{device_id}' not found", fg='red')
        sys.exit(1)
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command()
@click.argument('device_id')
def disable(device_id):
    """
    Disable a device (exclude from synchronization).

    DEVICE_ID: Device identifier to disable

    Example:
        physio-std disable my_garmin
    """
    try:
        config = PhysioConfig()
        config.disable_device(device_id)
        click.secho(f"✓ Device '{device_id}' disabled", fg='green')
    except KeyError:
        click.secho(f"✗ Device '{device_id}' not found", fg='red')
        sys.exit(1)
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command()
@click.argument('device_id')
@click.option('--force', is_flag=True, help='Skip confirmation')
def remove(device_id, force):
    """
    Remove a device from configuration.

    DEVICE_ID: Device identifier to remove

    Example:
        physio-std remove my_old_device
        physio-std remove my_old_device --force  # Skip confirmation
    """
    try:
        config = PhysioConfig()

        if not force:
            if not click.confirm(f"Remove device '{device_id}'?"):
                click.echo("Cancelled")
                return

        config.remove_device(device_id)
        click.secho(f"✓ Device '{device_id}' removed", fg='green')

    except KeyError:
        click.secho(f"✗ Device '{device_id}' not found", fg='red')
        sys.exit(1)
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command()
def status():
    """
    Show system status and configuration.

    Displays:
    - Configured devices and their status
    - Automation settings
    - Next scheduled sync (if enabled)
    - Output directory
    """
    try:
        config = PhysioConfig()

        click.echo("\n" + "=" * 60)
        click.echo("  PHYSIO-STD STATUS")
        click.echo("=" * 60)

        # Devices
        devices = config.list_devices()
        enabled_count = sum(1 for d in devices.values() if d.get('enabled'))

        click.echo(f"\nDevices: {len(devices)} configured, {enabled_count} enabled")
        for device_id, device_config in devices.items():
            status_symbol = "✓" if device_config.get('enabled') else "✗"
            click.echo(f"  {status_symbol} {device_id} ({device_config['type']})")

        # Automation
        automation = config.automation
        auto_enabled = automation.get('enabled', False)

        click.echo(f"\nAutomation: ", nl=False)
        if auto_enabled:
            click.secho("enabled", fg='green')

            # Try to get next run time
            try:
                scheduler = PhysioScheduler(config)
                scheduler.setup_schedule()
                next_run = scheduler.get_next_run_time()
                if next_run:
                    click.echo(f"  Next sync: {next_run.strftime('%Y-%m-%d %H:%M:%S')}")
            except Exception:
                pass

            click.echo(f"  Sync time: {automation.get('sync_time')}")
            click.echo(f"  Retention: {automation.get('data_retention_days')} days")
            click.echo(f"  Output: {automation.get('output_directory')}")
        else:
            click.secho("disabled", fg='yellow')
            click.echo(f"  Enable with: physio-std scheduler-enable")

        # Config file
        click.echo(f"\nConfiguration: {config.config_path}")
        click.echo(f"Encryption key: {config.key_file}")

        click.echo("\n" + "=" * 60)

    except Exception as e:
        click.secho(f"\n✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command('scheduler-start')
@click.option('--sync-time', help='Daily sync time (HH:MM format)')
@click.option('--retention-days', type=int, help='Data retention period in days')
@click.option('--run-now', is_flag=True, help='Run sync immediately before starting scheduler')
def start_scheduler(sync_time, retention_days, run_now):
    """
    Start the automated daily sync scheduler (blocking).

    The scheduler will run continuously in the foreground.
    Use Ctrl+C to stop, or run as a system service.

    Examples:
        physio-std scheduler-start                    # Use config settings
        physio-std scheduler-start --sync-time 08:00  # Custom sync time
        physio-std scheduler-start --run-now          # Sync immediately first
    """
    try:
        config = PhysioConfig()

        # Update settings if provided
        updates = {}
        if sync_time:
            updates['sync_time'] = sync_time
        if retention_days is not None:
            updates['data_retention_days'] = retention_days

        if updates:
            config.update_automation(**updates)
            click.echo(f"✓ Updated automation settings")

        # Enable automation
        if not config.automation.get('enabled'):
            config.update_automation(enabled=True)
            click.echo(f"✓ Automation enabled")

        # Create scheduler
        scheduler = PhysioScheduler(config)

        # Run now if requested
        if run_now:
            click.echo("\nRunning initial sync...")
            scheduler.run_once()

        # Start scheduler
        click.echo("\n" + "=" * 60)
        click.secho("Starting scheduler...", fg='green', bold=True)
        click.echo("=" * 60)
        click.echo(f"\nDaily sync at: {config.automation['sync_time']}")
        click.echo(f"Output directory: {config.automation['output_directory']}")
        click.echo(f"Data retention: {config.automation['data_retention_days']} days")
        click.echo("\nPress Ctrl+C to stop\n")

        scheduler.start()  # Blocking

    except KeyboardInterrupt:
        click.echo("\n\nScheduler stopped")
    except Exception as e:
        click.secho(f"\n✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command('scheduler-enable')
def enable_scheduler():
    """
    Enable automated daily sync.

    Note: This only enables automation in config.
    To start the scheduler, run: physio-std scheduler-start
    """
    try:
        config = PhysioConfig()
        config.update_automation(enabled=True)
        click.secho("✓ Automation enabled", fg='green')
        click.echo("\nTo start the scheduler:")
        click.echo("  physio-std scheduler-start")
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg='red')
        sys.exit(1)


@cli.command('scheduler-disable')
def disable_scheduler():
    """
    Disable automated daily sync.

    Note: This only disables automation in config.
    If the scheduler is running, stop it with Ctrl+C.
    """
    try:
        config = PhysioConfig()
        config.update_automation(enabled=False)
        click.secho("✓ Automation disabled", fg='green')
    except Exception as e:
        click.secho(f"✗ Error: {e}", fg='red')
        sys.exit(1)


if __name__ == '__main__':
    cli()
