"""
Multi-device manager for physiological data providers.

Orchestrates multiple device providers (Garmin, Huawei, Lifesense Ring) to
aggregate data from all sources. Handles connection management, data fetching,
deduplication, and partial failures.
"""

import logging
from datetime import datetime
from typing import List, Optional, Dict, Any
import pandas as pd

from .config import PhysioConfig
from .protocols import PhysioRecord, DataType
from .providers.garmin_provider import GarminProvider
from .providers.huawei_provider import HuaweiHealthKitProvider
from .providers.lifesense_ring_provider import LifesenseRingProvider
from .providers.mock_provider import MockPhysioProvider


class PhysioDeviceManager:
    """
    Manage multiple physiological data providers.

    Orchestrates connection, data fetching, and aggregation from multiple devices.
    Supports partial failures - if one device fails, others continue working.

    Features:
    - Automatic provider initialization from config
    - Parallel connection attempts
    - Data aggregation and deduplication
    - Source device tagging
    - Partial failure tolerance
    - Connection state management

    Example:
        >>> config = PhysioConfig()
        >>> manager = PhysioDeviceManager(config)
        >>> results = manager.connect_all()
        >>> records = manager.fetch_all_data(start_time, end_time)
        >>> manager.disconnect_all()
    """

    # Provider class mapping
    PROVIDER_CLASSES = {
        'garmin': GarminProvider,
        'huawei': HuaweiHealthKitProvider,
        'lifesense_ring': LifesenseRingProvider,
        'mock': MockPhysioProvider,
    }

    def __init__(self, config: PhysioConfig, persistence_override: Optional[Dict[str, Any]] = None):
        """
        Initialize device manager with configuration.

        Args:
            config: PhysioConfig instance with device configurations
            persistence_override: Optional runtime persistence override dictionary
        """
        self.config = config
        self.logger = logging.getLogger("physio_std.PhysioDeviceManager")
        self.providers: Dict[str, Any] = {}
        self.persistence = self._resolve_persistence(persistence_override)
        self.repository = self._init_repository()
        self._init_providers()

    def _resolve_persistence(self, override: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Merge persistence settings from config with optional runtime override."""
        base = {
            'enabled': False,
            'backend': 'none',
            'db_path': '~/.physio_std/physio.db',
            'user_id': 'default_user',
            'persist_unified_table': False,
        }
        config_persistence = getattr(self.config, 'persistence', {}) or {}
        merged = {**base, **config_persistence}
        if override:
            merged.update(override)
        return merged

    def _init_repository(self):
        """Initialize persistence repository if enabled."""
        if not self.persistence.get('enabled', False):
            return None

        backend = str(self.persistence.get('backend', 'none')).lower().strip()
        if backend not in {'sqlite'}:
            self.logger.warning(
                "Persistence enabled with unsupported backend '%s'. Supported: sqlite. Disabling persistence.",
                backend,
            )
            return None

        try:
            from .storage.repository import SQLitePhysioRepository

            db_path = str(self.persistence.get('db_path', '~/.physio_std/physio.db'))
            repo = SQLitePhysioRepository(db_path)
            self.logger.info("Persistence enabled: sqlite (%s)", db_path)
            return repo
        except Exception as e:
            self.logger.error("Failed to initialize SQL persistence: %s", e)
            return None

    def _resolve_user_id(self, device_id: str) -> str:
        """Resolve logical user_id for persistence for a given device."""
        device_cfg = self.config.devices.get(device_id, {}) if hasattr(self.config, 'devices') else {}
        return str(device_cfg.get('user_id') or self.persistence.get('user_id') or 'default_user')

    def _init_providers(self):
        """
        Initialize all configured and enabled providers.

        Only initializes providers that are:
        1. Configured in the config file
        2. Enabled (enabled: true)
        3. Have a valid provider type
        """
        for device_id, device_config in self.config.devices.items():
            if not device_config.get('enabled', True):
                self.logger.info(f"Skipping disabled device: {device_id}")
                continue

            device_type = device_config.get('type')
            if device_type not in self.PROVIDER_CLASSES:
                self.logger.warning(
                    f"Unknown device type '{device_type}' for {device_id}. "
                    f"Valid types: {list(self.PROVIDER_CLASSES.keys())}"
                )
                continue

            try:
                # Get decrypted config
                full_config = self.config.get_device_config(device_id)

                # Initialize provider
                provider_class = self.PROVIDER_CLASSES[device_type]
                provider = provider_class(full_config)

                self.providers[device_id] = provider
                self.logger.info(f"Initialized provider: {device_id} ({device_type})")
            except Exception as e:
                self.logger.error(f"Failed to initialize {device_id}: {e}")

        if not self.providers:
            self.logger.warning("No providers initialized")
        else:
            self.logger.info(f"Initialized {len(self.providers)} provider(s)")

    def connect_all(self, devices: Optional[List[str]] = None) -> Dict[str, str]:
        """
        Connect to all (or specified) devices.

        Attempts to connect to all providers. Failures are logged but don't
        prevent other connections.

        Args:
            devices: List of device IDs to connect. If None, connects to all.

        Returns:
            Dictionary mapping device_id to connection status:
            - 'connected': Successfully connected
            - 'failed': Connection failed
            - 'error: <message>': Exception occurred

        Example:
            >>> results = manager.connect_all()
            >>> print(results)
            {'garmin_watch': 'connected', 'huawei_band': 'failed'}
        """
        results = {}
        device_list = devices if devices else list(self.providers.keys())

        for device_id in device_list:
            if device_id not in self.providers:
                results[device_id] = 'error: device not found'
                continue

            provider = self.providers[device_id]

            try:
                self.logger.info(f"Connecting to {device_id}...")
                success = provider.connect()

                if success:
                    results[device_id] = 'connected'
                    self.logger.info(f"✓ Connected to {device_id}")
                else:
                    results[device_id] = 'failed'
                    self.logger.warning(f"✗ Failed to connect to {device_id}")

            except Exception as e:
                results[device_id] = f'error: {str(e)}'
                self.logger.error(f"✗ Error connecting to {device_id}: {e}")

        # Summary
        connected_count = sum(1 for status in results.values() if status == 'connected')
        self.logger.info(f"Connection summary: {connected_count}/{len(results)} successful")

        return results

    def fetch_all_data(
        self,
        start_time: datetime,
        end_time: datetime,
        devices: Optional[List[str]] = None
    ) -> List[PhysioRecord]:
        """
        Fetch data from all (or specified) devices and aggregate.

        Fetches data from all connected devices in parallel. Partial failures
        are tolerated - data from successful devices is still returned.

        Args:
            start_time: Start of time range (UTC)
            end_time: End of time range (UTC)
            devices: List of device IDs to fetch from. If None, fetches from all.

        Returns:
            Aggregated list of PhysioRecord objects, sorted by timestamp.
            Records are deduplicated (same timestamp + data type keeps highest confidence).

        Raises:
            ValueError: If no devices are connected

        Example:
            >>> records = manager.fetch_all_data(
            ...     start_time=datetime(2024, 1, 1),
            ...     end_time=datetime(2024, 1, 2)
            ... )
            >>> print(f"Fetched {len(records)} total records")
        """
        device_list = devices if devices else list(self.providers.keys())

        # Check if any devices are connected
        connected_devices = [
            d for d in device_list
            if d in self.providers and self.providers[d].connected
        ]

        if not connected_devices:
            raise ValueError(
                "No devices connected. Call connect_all() first or check connection status."
            )

        self.logger.info(
            f"Fetching data from {len(connected_devices)} device(s) "
            f"for {start_time} to {end_time}"
        )

        all_records = []

        for device_id in connected_devices:
            provider = self.providers[device_id]

            try:
                self.logger.info(f"Fetching from {device_id}...")
                records = provider.fetch_data(start_time, end_time)

                all_records.extend(records)

                if self.repository is not None and records:
                    try:
                        user_id = self._resolve_user_id(device_id)
                        self.repository.save_records(
                            user_id=user_id,
                            device_id=device_id,
                            records=records,
                        )
                    except Exception as e:
                        self.logger.warning("Failed to persist records for %s: %s", device_id, e)

                self.logger.info(
                    f"✓ Fetched {len(records)} records from {device_id}"
                )

            except Exception as e:
                self.logger.error(f"✗ Failed to fetch from {device_id}: {e}")
                # Continue with other devices

        # Sort by timestamp
        all_records.sort(key=lambda r: r.timestamp_utc)

        # Deduplicate
        deduplicated = self._deduplicate_records(all_records)

        self.logger.info(
            f"Aggregated {len(all_records)} records, "
            f"{len(deduplicated)} after deduplication"
        )

        return deduplicated

    def _deduplicate_records(self, records: List[PhysioRecord]) -> List[PhysioRecord]:
        """
        Remove duplicate records, keeping highest confidence.

        Duplicates are defined as records with:
        - Same timestamp (to the second)
        - Same data_type
        - Different source_device

        Strategy: Keep the record with highest confidence score.
        This handles cases where multiple devices measure the same thing.

        Args:
            records: List of potentially duplicate records

        Returns:
            Deduplicated list of records
        """
        if not records:
            return []

        # Group by (timestamp, data_type)
        unique_map: Dict[tuple, PhysioRecord] = {}

        for record in records:
            # Key: timestamp rounded to second + data type
            key = (
                record.timestamp_utc.replace(microsecond=0),
                record.data_type
            )

            # Keep record with highest confidence
            if key not in unique_map or record.confidence > unique_map[key].confidence:
                unique_map[key] = record

        deduplicated = list(unique_map.values())

        # Sort by timestamp again after deduplication
        deduplicated.sort(key=lambda r: r.timestamp_utc)

        # Log deduplication stats if any duplicates were found
        if len(deduplicated) < len(records):
            removed = len(records) - len(deduplicated)
            self.logger.debug(f"Removed {removed} duplicate records")

        return deduplicated

    def fetch_unified_dataframe(
        self,
        user_id: str,
        device_id: str,
        start_time: datetime,
        end_time: datetime,
        hr_rest: float = 60.0,
        hr_max: float = 190.0,
    ) -> pd.DataFrame:
        """
        Fetch records for one device and return a 1-minute aligned wide DataFrame.

        This is a convenience integration point for the new UnifiedPhysioProcessor
        without changing existing fetch/export behavior.
        """
        if device_id not in self.providers:
            raise KeyError(f"Unknown device_id: {device_id}")

        provider = self.providers[device_id]
        if not provider.connected:
            raise ValueError(f"Device '{device_id}' is not connected")

        records = provider.fetch_data(start_time, end_time)
        device_type = str(provider.config.get('type', '')).lower().strip()

        if device_type == 'garmin':
            unified_device = 'Garmin'
        elif device_type == 'huawei':
            unified_device = 'Huawei'
        else:
            raise ValueError(
                f"Unified dataframe currently supports garmin/huawei only, got: {device_type}"
            )

        from .unified_processor import UnifiedPhysioProcessor

        processor = UnifiedPhysioProcessor()
        df = processor.process_physio_records(
            user_id=user_id,
            device_type=unified_device,
            records=records,
            hr_rest=hr_rest,
            hr_max=hr_max,
        )

        if self.repository is not None and self.persistence.get('persist_unified_table', False):
            try:
                self.repository.save_unified_dataframe(
                    user_id=user_id,
                    device_type=unified_device,
                    df=df,
                )
            except Exception as e:
                self.logger.warning("Failed to persist unified dataframe for %s: %s", device_id, e)

        return df

    def disconnect_all(self, devices: Optional[List[str]] = None):
        """
        Disconnect from all (or specified) devices.

        Safely disconnects from all devices. Errors during disconnection
        are logged but don't prevent other disconnections.

        Args:
            devices: List of device IDs to disconnect. If None, disconnects all.
        """
        device_list = devices if devices else list(self.providers.keys())

        for device_id in device_list:
            if device_id not in self.providers:
                continue

            provider = self.providers[device_id]

            try:
                if provider.connected:
                    provider.disconnect()
                    self.logger.info(f"Disconnected from {device_id}")
            except Exception as e:
                self.logger.warning(f"Error disconnecting from {device_id}: {e}")

        if self.repository is not None:
            try:
                self.repository.close()
            except Exception as e:
                self.logger.warning(f"Error closing persistence repository: {e}")

    def load_persisted_data(
        self,
        *,
        user_id: str,
        start_time: datetime,
        end_time: datetime,
        device_id: Optional[str] = None,
        data_types: Optional[List[DataType]] = None,
    ) -> List[PhysioRecord]:
        """Load standardized records from SQL persistence backend."""
        if self.repository is None:
            raise RuntimeError("SQL persistence is not enabled for this manager")

        return self.repository.load_records(
            user_id=user_id,
            start_time=start_time,
            end_time=end_time,
            device_id=device_id,
            data_types=data_types,
        )

    def get_persistence_status(self) -> Dict[str, Any]:
        """Return persistence configuration and current status."""
        status: Dict[str, Any] = {
            'enabled': bool(self.persistence.get('enabled', False)),
            'backend': self.persistence.get('backend', 'none'),
            'db_path': self.persistence.get('db_path'),
            'repository_ready': self.repository is not None,
        }

        if self.repository is not None:
            try:
                status['record_count'] = self.repository.count_records()
            except Exception:
                status['record_count'] = None

        return status

    def get_connection_status(self) -> Dict[str, bool]:
        """
        Get connection status for all providers.

        Returns:
            Dictionary mapping device_id to connection status (bool)

        Example:
            >>> status = manager.get_connection_status()
            >>> print(status)
            {'garmin_watch': True, 'huawei_band': False}
        """
        return {
            device_id: provider.connected
            for device_id, provider in self.providers.items()
        }

    def get_provider_summary(self) -> Dict[str, Dict[str, Any]]:
        """
        Get summary information about all providers.

        Returns:
            Dictionary with provider details including type, status, and config

        Example:
            >>> summary = manager.get_provider_summary()
            >>> for device_id, info in summary.items():
            ...     print(f"{device_id}: {info['type']} - {info['status']}")
        """
        summary = {}

        for device_id, provider in self.providers.items():
            summary[device_id] = {
                'type': provider.config.get('type'),
                'connected': provider.connected,
                'class': provider.__class__.__name__
            }

        return summary

    def __enter__(self):
        """Context manager entry - connect to all devices."""
        self.connect_all()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit - disconnect from all devices."""
        self.disconnect_all()

    def __repr__(self) -> str:
        """String representation."""
        connected = sum(1 for p in self.providers.values() if p.connected)
        total = len(self.providers)
        return f"<PhysioDeviceManager: {connected}/{total} connected>"


def create_sample_config() -> PhysioConfig:
    """
    Create a sample configuration for testing.

    Returns:
        PhysioConfig with mock device configured

    Example:
        >>> config = create_sample_config()
        >>> manager = PhysioDeviceManager(config)
    """
    import tempfile
    from pathlib import Path

    # Create temp config directory
    temp_dir = Path(tempfile.mkdtemp())
    config_path = temp_dir / "config.yaml"
    key_file = temp_dir / ".key"

    # Temporarily set paths
    PhysioConfig.DEFAULT_CONFIG_PATH = str(config_path)
    PhysioConfig.KEY_FILE = str(key_file)

    config = PhysioConfig(config_path=str(config_path))

    # Add mock device for testing
    config.add_device(
        'mock_device',
        'mock',
        {'mode': 'synthetic'},
        enabled=True
    )

    return config
