"""
Unified physiological preprocessing and cross-source alignment (Module 1.2).

This module provides `UnifiedPhysioProcessor`, a single place to:
1) Parse Garmin/Huawei raw structures
2) Denoise and normalize key physiological channels
3) Align all signals to a strict 1-minute timeline
4) Emit a wide, model-friendly DataFrame for downstream cognitive modules

Design goals:
- Keep provider adapters unchanged (backward compatible)
- Add a deterministic, testable preprocessing layer
- Make missing-channel behavior explicit via device masks
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy.signal import medfilt

from .protocols import DataType, PhysioRecord


@dataclass
class BaselineStats:
    """Optional baseline statistics for stress z-score calculation."""

    mean: float
    std: float


class UnifiedPhysioProcessor:
    """
    Cross-source alignment processor for Garmin + Huawei physiological data.

    The output is always a 1-minute indexed wide DataFrame with this schema:
    - user_id
    - device_type ("Garmin" | "Huawei")
    - timestamp
    - hr_raw
    - hr_norm
    - stress_z_score
    - spo2_clean
    - resp_rate
    - skin_temp
    - has_skin_temp
    - sleep_stage
    - sqi_daily
    """

    def __init__(
        self,
        empirical_k: float = 2.5,
        hold_limit_minutes: int = 30,
        spo2_lower_bound: float = 88.0,
        sqi_weights: Tuple[float, float, float] = (0.5, 0.3, 0.2),
    ) -> None:
        self.empirical_k = empirical_k
        self.hold_limit_minutes = hold_limit_minutes
        self.spo2_lower_bound = spo2_lower_bound
        self.sqi_weights = sqi_weights

    # ---------------------------------------------------------------------
    # Public API
    # ---------------------------------------------------------------------

    def process_garmin_raw(
        self,
        *,
        user_id: str,
        garmin_data: Dict[str, Sequence],
        hr_rest: float,
        hr_max: float,
        baseline_stats: Optional[BaselineStats] = None,
    ) -> pd.DataFrame:
        """Process Garmin raw structures into a unified 1-minute DataFrame."""
        return self._process_raw(
            user_id=user_id,
            device_type="Garmin",
            raw=garmin_data,
            hr_rest=hr_rest,
            hr_max=hr_max,
            baseline_stats=baseline_stats,
        )

    def process_huawei_raw(
        self,
        *,
        user_id: str,
        huawei_data: Dict[str, Sequence],
        hr_rest: float,
        hr_max: float,
        baseline_stats: Optional[BaselineStats] = None,
    ) -> pd.DataFrame:
        """Process Huawei raw structures into a unified 1-minute DataFrame."""
        return self._process_raw(
            user_id=user_id,
            device_type="Huawei",
            raw=huawei_data,
            hr_rest=hr_rest,
            hr_max=hr_max,
            baseline_stats=baseline_stats,
        )

    def process_physio_records(
        self,
        *,
        user_id: str,
        device_type: str,
        records: List[PhysioRecord],
        hr_rest: float,
        hr_max: float,
        baseline_stats: Optional[BaselineStats] = None,
    ) -> pd.DataFrame:
        """
        Integration path for existing Module 1.2 providers.

        Converts `PhysioRecord` lists from the current manager/providers into the
        raw dict shape used by this processor, then runs the same alignment path.
        """
        raw: Dict[str, List] = {
            "hr": [],
            "hrv": [],
            "stress": [],
            "spo2": [],
            "resp_rate": [],
            "skin_temp": [],
            "sleep": [],
        }

        for r in records:
            ts = pd.Timestamp(r.timestamp_utc)
            if r.data_type == DataType.HR:
                raw["hr"].append((ts, float(r.value)))
            elif r.data_type == DataType.HRV:
                raw["hrv"].append((ts, float(r.value)))
            elif r.data_type == DataType.STRESS_SCORE:
                raw["stress"].append((ts, float(r.value)))
            elif r.data_type == DataType.SPO2:
                raw["spo2"].append((ts, float(r.value)))
            elif r.data_type == DataType.RESPIRATORY_RATE:
                raw["resp_rate"].append((ts, float(r.value)))
            elif r.data_type == DataType.TEMPERATURE:
                raw["skin_temp"].append((ts, float(r.value)))
            elif r.data_type == DataType.SLEEP_STAGE:
                stage = str(r.unit) if r.unit else "Awake"
                # Current providers emit point-level sleep labels, so map as 1-minute interval.
                raw["sleep"].append((ts, ts + pd.Timedelta(minutes=1), stage))

        normalized_device = device_type.strip().capitalize()
        if normalized_device not in {"Garmin", "Huawei"}:
            raise ValueError("device_type must be 'Garmin' or 'Huawei'")

        return self._process_raw(
            user_id=user_id,
            device_type=normalized_device,
            raw=raw,
            hr_rest=hr_rest,
            hr_max=hr_max,
            baseline_stats=baseline_stats,
        )

    # ---------------------------------------------------------------------
    # Core pipeline
    # ---------------------------------------------------------------------

    def _process_raw(
        self,
        *,
        user_id: str,
        device_type: str,
        raw: Dict[str, Sequence],
        hr_rest: float,
        hr_max: float,
        baseline_stats: Optional[BaselineStats],
    ) -> pd.DataFrame:
        idx = self._build_minute_index(raw)
        if idx.empty:
            return self._empty_output()

        hr_raw = self._build_hr_series(raw.get("hr", []), idx)
        hr_norm = self._normalize_hr(hr_raw, hr_rest=hr_rest, hr_max=hr_max)

        stress_z = self._build_stress_z(
            device_type=device_type,
            hrv_raw=raw.get("hrv", []),
            stress_raw=raw.get("stress", []),
            idx=idx,
            baseline_stats=baseline_stats,
        )

        spo2_clean = self._build_spo2_series(raw.get("spo2", []), idx)
        sleep_stage = self._build_sleep_series(raw.get("sleep", []), idx)
        sqi_daily = self._compute_sqi_daily(sleep_stage)

        # Device masking behavior requested in spec.
        if device_type == "Garmin":
            resp_rate = self._build_step_hold_series(raw.get("resp_rate", []), idx)
            skin_temp = pd.Series(np.nan, index=idx, dtype=float)
            has_skin_temp = pd.Series(0, index=idx, dtype=int)
        else:
            resp_rate = pd.Series(np.nan, index=idx, dtype=float)
            skin_temp = self._build_step_hold_series(raw.get("skin_temp", []), idx)
            has_skin_temp = pd.Series(
                np.where(skin_temp.notna(), 1, 0),
                index=idx,
                dtype=int,
            )

        out = pd.DataFrame(index=idx)
        out["user_id"] = user_id
        out["device_type"] = device_type
        out["timestamp"] = out.index
        out["hr_raw"] = hr_raw.astype(float)
        out["hr_norm"] = hr_norm.astype(float)
        out["stress_z_score"] = stress_z.astype(float)
        out["spo2_clean"] = spo2_clean.astype(float)
        out["resp_rate"] = resp_rate.astype(float)
        out["skin_temp"] = skin_temp.astype(float)
        out["has_skin_temp"] = has_skin_temp.astype(int)
        out["sleep_stage"] = sleep_stage.astype(str)
        out["sqi_daily"] = sqi_daily.astype(float)

        ordered = [
            "user_id",
            "device_type",
            "timestamp",
            "hr_raw",
            "hr_norm",
            "stress_z_score",
            "spo2_clean",
            "resp_rate",
            "skin_temp",
            "has_skin_temp",
            "sleep_stage",
            "sqi_daily",
        ]
        return out[ordered]

    # ---------------------------------------------------------------------
    # Channel builders
    # ---------------------------------------------------------------------

    def _build_hr_series(self, hr_points: Sequence, idx: pd.DatetimeIndex) -> pd.Series:
        sec = self._points_to_series(hr_points)
        if sec.empty:
            return pd.Series(np.nan, index=idx, dtype=float)

        # Sliding-median denoising (~5-second window in point domain).
        # Kernel size must be odd for scipy.signal.medfilt.
        k = 5 if len(sec) >= 5 else (3 if len(sec) >= 3 else 1)
        median_vals = medfilt(sec.to_numpy(dtype=float), kernel_size=k)
        denoised = sec.copy()

        jumps = denoised.diff().abs() > 30.0
        denoised.loc[jumps.fillna(False)] = median_vals[jumps.fillna(False)]

        # Strict 1-minute bucket with mean downsampling.
        minute = denoised.resample("1min").mean()
        minute = minute.reindex(idx)
        return minute

    def _normalize_hr(self, hr_raw: pd.Series, *, hr_rest: float, hr_max: float) -> pd.Series:
        denom = hr_max - hr_rest
        if denom <= 0:
            return pd.Series(np.nan, index=hr_raw.index, dtype=float)
        norm = (hr_raw - hr_rest) / denom
        return norm.clip(lower=0.0, upper=1.0)

    def _build_stress_z(
        self,
        *,
        device_type: str,
        hrv_raw: Sequence,
        stress_raw: Sequence,
        idx: pd.DatetimeIndex,
        baseline_stats: Optional[BaselineStats],
    ) -> pd.Series:
        if device_type == "Garmin":
            hrv_series = self._interval_or_points_to_series(hrv_raw)
            hrv_1m = self._step_hold_to_minute(hrv_series, idx)
            stress_like = self._rmssd_to_stress(hrv_1m)
        else:
            stress_series = self._points_to_series(stress_raw)
            stress_like = self._step_hold_to_minute(stress_series, idx)

        return self._zscore(stress_like, baseline_stats)

    def _build_spo2_series(self, spo2_points: Sequence, idx: pd.DatetimeIndex) -> pd.Series:
        base = self._points_to_series(spo2_points)
        minute = self._step_hold_to_minute(base, idx)

        # Isolated low-value artifact replacement by local interpolation.
        vals = minute.copy()
        for i in range(1, len(vals) - 1):
            cur = vals.iloc[i]
            prv = vals.iloc[i - 1]
            nxt = vals.iloc[i + 1]
            if (
                pd.notna(cur)
                and pd.notna(prv)
                and pd.notna(nxt)
                and cur < self.spo2_lower_bound
                and prv >= self.spo2_lower_bound
                and nxt >= self.spo2_lower_bound
            ):
                vals.iloc[i] = (prv + nxt) / 2.0
        return vals

    def _build_sleep_series(self, sleep_intervals: Sequence, idx: pd.DatetimeIndex) -> pd.Series:
        if len(idx) == 0:
            return pd.Series(dtype="object")

        stage = pd.Series("Awake", index=idx, dtype="object")

        for item in sleep_intervals:
            if len(item) < 3:
                continue
            start, end, label = item[0], item[1], item[2]
            s = self._to_timestamp(start).floor("min")
            e = self._to_timestamp(end).ceil("min")
            if e < s:
                s, e = e, s
            normalized = self._normalize_sleep_label(str(label))
            mask = (stage.index >= s) & (stage.index < e)
            stage.loc[mask] = normalized

        # Sleep logic repair: Deep -> Awake(<3m) -> Deep
        vals = stage.to_list()
        n = len(vals)
        i = 1
        while i < n - 1:
            if vals[i] == "Awake" and vals[i - 1] == "Deep":
                j = i
                while j < n and vals[j] == "Awake":
                    j += 1
                if j < n and vals[j] == "Deep" and (j - i) < 3:
                    for k in range(i, j):
                        vals[k] = "Deep"
                i = j
            else:
                i += 1

        return pd.Series(vals, index=idx, dtype="object")

    def _compute_sqi_daily(self, sleep_stage: pd.Series) -> pd.Series:
        if sleep_stage.empty:
            return pd.Series(dtype=float)

        w1, w2, w3 = self.sqi_weights
        sqi_by_date: Dict[pd.Timestamp, float] = {}

        grouped = sleep_stage.groupby(sleep_stage.index.date)
        for d, s in grouped:
            arr = s.to_numpy()
            total = len(arr)
            if total == 0:
                sqi_by_date[pd.Timestamp(d)] = np.nan
                continue

            deep = float(np.sum(arr == "Deep"))
            rem = float(np.sum(arr == "REM"))

            # Continuity proxy: fewer transitions => higher continuity.
            transitions = float(np.sum(arr[1:] != arr[:-1])) if total > 1 else 0.0
            continuity = max(0.0, 1.0 - transitions / max(1.0, total - 1.0))

            sqi = w1 * (deep / total) + w2 * (rem / total) + w3 * continuity
            sqi_by_date[pd.Timestamp(d)] = float(np.clip(sqi, 0.0, 1.0))

        out = pd.Series(index=sleep_stage.index, dtype=float)
        for ts in out.index:
            out.loc[ts] = sqi_by_date.get(pd.Timestamp(ts.date()), np.nan)
        return out

    # ---------------------------------------------------------------------
    # Utility transforms
    # ---------------------------------------------------------------------

    def _step_hold_to_minute(self, series: pd.Series, idx: pd.DatetimeIndex) -> pd.Series:
        if series.empty:
            return pd.Series(np.nan, index=idx, dtype=float)

        aligned = series.sort_index().reindex(idx).ffill(limit=self.hold_limit_minutes)
        return aligned.astype(float)

    def _build_step_hold_series(self, points: Sequence, idx: pd.DatetimeIndex) -> pd.Series:
        series = self._points_to_series(points)
        return self._step_hold_to_minute(series, idx)

    def _points_to_series(self, points: Sequence) -> pd.Series:
        if not points:
            return pd.Series(dtype=float)

        ts = []
        vals = []
        for p in points:
            if len(p) < 2:
                continue
            ts.append(self._to_timestamp(p[0]))
            vals.append(float(p[1]))

        if not ts:
            return pd.Series(dtype=float)

        s = pd.Series(vals, index=pd.DatetimeIndex(ts)).sort_index()
        s = s[~s.index.duplicated(keep="last")]
        return s

    def _interval_or_points_to_series(self, seq: Sequence) -> pd.Series:
        """
        Accept mixed representations:
        - Point tuples: (timestamp, value)
        - Interval tuples: (start, end, value)
        """
        if not seq:
            return pd.Series(dtype=float)

        rows_ts: List[pd.Timestamp] = []
        rows_val: List[float] = []

        for item in seq:
            if len(item) >= 3:
                s = self._to_timestamp(item[0]).floor("min")
                e = self._to_timestamp(item[1]).floor("min")
                v = float(item[2])
                if e < s:
                    s, e = e, s
                rng = pd.date_range(start=s, end=e, freq="1min")
                rows_ts.extend(list(rng))
                rows_val.extend([v] * len(rng))
            elif len(item) >= 2:
                rows_ts.append(self._to_timestamp(item[0]))
                rows_val.append(float(item[1]))

        if not rows_ts:
            return pd.Series(dtype=float)

        s = pd.Series(rows_val, index=pd.DatetimeIndex(rows_ts)).sort_index()
        # Keep most recent assignment if duplicates occur.
        s = s.groupby(level=0).last()
        return s

    def _rmssd_to_stress(self, rmssd: pd.Series) -> pd.Series:
        safe = rmssd.copy()
        safe[safe <= 0] = np.nan
        return 100.0 - (20.0 * np.log(safe) / self.empirical_k)

    def _zscore(self, values: pd.Series, baseline_stats: Optional[BaselineStats]) -> pd.Series:
        if values.empty:
            return values.astype(float)

        if baseline_stats is not None and baseline_stats.std > 0:
            return (values - baseline_stats.mean) / baseline_stats.std

        # 7-day rolling baseline on 1-minute timeline.
        win = 7 * 24 * 60
        mean = values.rolling(window=win, min_periods=60).mean()
        std = values.rolling(window=win, min_periods=60).std()
        z = (values - mean) / std
        z = z.replace([np.inf, -np.inf], np.nan)
        return z

    def _build_minute_index(self, raw: Dict[str, Sequence]) -> pd.DatetimeIndex:
        stamps: List[pd.Timestamp] = []

        for key, items in raw.items():
            for item in items:
                if len(item) >= 1:
                    stamps.append(self._to_timestamp(item[0]))
                if key == "sleep" and len(item) >= 2:
                    stamps.append(self._to_timestamp(item[1]))
                if key == "hrv" and len(item) >= 2 and len(item) >= 3:
                    # interval-format hrv: include end boundary for index coverage
                    stamps.append(self._to_timestamp(item[1]))

        if not stamps:
            return pd.DatetimeIndex([], freq="1min")

        start = min(stamps).floor("min")
        end = max(stamps).ceil("min")
        if end < start:
            end = start
        return pd.date_range(start=start, end=end, freq="1min")

    def _normalize_sleep_label(self, label: str) -> str:
        x = label.strip().lower()
        mapping = {
            "light": "Light",
            "deep": "Deep",
            "rem": "REM",
            "awake": "Awake",
        }
        return mapping.get(x, "Awake")

    def _to_timestamp(self, x: object) -> pd.Timestamp:
        if isinstance(x, pd.Timestamp):
            ts = x
        elif isinstance(x, datetime):
            ts = pd.Timestamp(x)
        else:
            ts = pd.Timestamp(str(x))

        # Normalize timezone handling to UTC-naive for stable cross-provider merge.
        if ts.tzinfo is not None:
            ts = ts.tz_convert("UTC").tz_localize(None)
        return ts

    def _empty_output(self) -> pd.DataFrame:
        return pd.DataFrame(
            columns=[
                "user_id",
                "device_type",
                "timestamp",
                "hr_raw",
                "hr_norm",
                "stress_z_score",
                "spo2_clean",
                "resp_rate",
                "skin_temp",
                "has_skin_temp",
                "sleep_stage",
                "sqi_daily",
            ]
        )
