"""
Configuration management for physio_std library.

Handles device credentials, automation settings, and secure storage.
Configuration stored at ~/.physio_std/config.yaml with encrypted credentials.
"""

import logging
import os
import yaml
from pathlib import Path
from typing import Dict, Any, Optional
from cryptography.fernet import Fernet


class PhysioConfig:
    """
    Configuration manager with credential encryption.

    Manages device configurations, credentials, and automation settings.
    Credentials are encrypted using Fernet symmetric encryption.

    Configuration Schema:
        devices:
            <device_id>:
                type: huawei | garmin | lifesense_ring
                enabled: bool
                credentials: dict (encrypted)
                [additional device-specific settings]
        automation:
            enabled: bool
            sync_time: str (HH:MM format)
            timezone: str
            data_retention_days: int
            output_directory: str
    """

    DEFAULT_CONFIG_PATH = "~/.physio_std/config.yaml"
    KEY_FILE = "~/.physio_std/.key"

    def __init__(self, config_path: Optional[str] = None):
        """
        Initialize configuration manager.

        Args:
            config_path: Path to config file. If None, uses DEFAULT_CONFIG_PATH.
        """
        self.logger = logging.getLogger("physio_std.config")
        self.config_path = Path(config_path or self.DEFAULT_CONFIG_PATH).expanduser()
        self.key_file = Path(self.KEY_FILE).expanduser()

        # Initialize encryption
        self._cipher = self._load_or_create_key()

        # Load or create config
        self.devices: Dict[str, Dict[str, Any]] = {}
        self.automation: Dict[str, Any] = {}
        self.persistence: Dict[str, Any] = {}
        self._load_config()

    @staticmethod
    def _default_persistence() -> Dict[str, Any]:
        """Default persistence settings."""
        return {
            'enabled': False,
            'backend': 'none',
            'db_path': '~/.physio_std/physio.db',
            'user_id': 'default_user',
            'persist_unified_table': False,
        }

    def _load_or_create_key(self) -> Fernet:
        """Load encryption key or create new one."""
        self.key_file.parent.mkdir(parents=True, exist_ok=True)

        if self.key_file.exists():
            with open(self.key_file, 'rb') as f:
                key = f.read()
        else:
            key = Fernet.generate_key()
            with open(self.key_file, 'wb') as f:
                f.write(key)
            # Secure file permissions (owner read/write only)
            os.chmod(self.key_file, 0o600)
            self.logger.info("Created new encryption key")

        return Fernet(key)

    def _encrypt_credentials(self, credentials: dict) -> dict:
        """
        Encrypt sensitive credential values.

        Args:
            credentials: Raw credentials dictionary

        Returns:
            Dictionary with encrypted values
        """
        encrypted = {}
        for key, value in credentials.items():
            if isinstance(value, str):
                encrypted[key] = self._cipher.encrypt(value.encode()).decode()
            else:
                # Non-string values (e.g., integers) stored as-is
                encrypted[key] = value
        return encrypted

    def _decrypt_credentials(self, encrypted_credentials: dict) -> dict:
        """
        Decrypt credential values.

        Args:
            encrypted_credentials: Dictionary with encrypted values

        Returns:
            Dictionary with decrypted values
        """
        decrypted = {}
        for key, value in encrypted_credentials.items():
            if isinstance(value, str):
                try:
                    decrypted[key] = self._cipher.decrypt(value.encode()).decode()
                except Exception as e:
                    self.logger.warning(f"Failed to decrypt {key}: {e}")
                    decrypted[key] = value  # Fallback to raw value
            else:
                decrypted[key] = value
        return decrypted

    def _load_config(self):
        """Load configuration from YAML file."""
        if not self.config_path.exists():
            self.logger.info(f"Config file not found, creating default: {self.config_path}")
            self._create_default_config()
            return

        try:
            with open(self.config_path) as f:
                config_data = yaml.safe_load(f) or {}

            self.devices = config_data.get('devices', {})
            self.automation = config_data.get('automation', {})
            persistence_data = config_data.get('persistence', {})
            if not isinstance(persistence_data, dict):
                persistence_data = {}
            self.persistence = {
                **self._default_persistence(),
                **persistence_data,
            }

            self.logger.info(f"Loaded config from {self.config_path}")
        except Exception as e:
            self.logger.error(f"Failed to load config: {e}")
            self._create_default_config()

    def _create_default_config(self):
        """Create default configuration file."""
        self.config_path.parent.mkdir(parents=True, exist_ok=True)

        default_config = {
            'devices': {},
            'automation': {
                'enabled': False,
                'sync_time': '08:00',
                'timezone': 'UTC',
                'data_retention_days': 90,
                'output_directory': '~/physio_data/'
            },
            'persistence': self._default_persistence(),
        }

        self.devices = default_config['devices']
        self.automation = default_config['automation']
        self.persistence = default_config['persistence']
        self._save_config()

        # Secure file permissions
        os.chmod(self.config_path, 0o600)
        self.logger.info(f"Created default config at {self.config_path}")

    def _save_config(self):
        """Save configuration to YAML file."""
        config_data = {
            'devices': self.devices,
            'automation': self.automation,
            'persistence': self.persistence,
        }

        try:
            with open(self.config_path, 'w') as f:
                yaml.dump(config_data, f, default_flow_style=False, sort_keys=False)

            # Ensure secure permissions
            os.chmod(self.config_path, 0o600)
            self.logger.debug("Config saved")
        except Exception as e:
            self.logger.error(f"Failed to save config: {e}")
            raise

    def add_device(self, device_id: str, device_type: str, credentials: dict, **kwargs):
        """
        Add or update device configuration.

        Args:
            device_id: Unique device identifier
            device_type: Device type ('huawei', 'garmin', 'lifesense_ring')
            credentials: Device credentials (will be encrypted)
            **kwargs: Additional device-specific settings

        Raises:
            ValueError: If device_type is invalid
        """
        valid_types = ['huawei', 'garmin', 'lifesense_ring', 'mock']
        if device_type not in valid_types:
            raise ValueError(f"Invalid device_type. Must be one of: {valid_types}")

        self.devices[device_id] = {
            'type': device_type,
            'enabled': kwargs.get('enabled', True),
            'credentials': self._encrypt_credentials(credentials),
            **{k: v for k, v in kwargs.items() if k != 'enabled'}
        }

        self._save_config()
        self.logger.info(f"Added device: {device_id} ({device_type})")

    def remove_device(self, device_id: str):
        """
        Remove device from configuration.

        Args:
            device_id: Device identifier to remove

        Raises:
            KeyError: If device_id not found
        """
        if device_id not in self.devices:
            raise KeyError(f"Device not found: {device_id}")

        del self.devices[device_id]
        self._save_config()
        self.logger.info(f"Removed device: {device_id}")

    def get_device_config(self, device_id: str) -> dict:
        """
        Get device configuration with decrypted credentials.

        Args:
            device_id: Device identifier

        Returns:
            Device configuration with decrypted credentials

        Raises:
            KeyError: If device_id not found
        """
        if device_id not in self.devices:
            raise KeyError(f"Device not found: {device_id}")

        config = self.devices[device_id].copy()
        config['credentials'] = self._decrypt_credentials(config['credentials'])
        return config

    def enable_device(self, device_id: str):
        """Enable device for data sync."""
        if device_id not in self.devices:
            raise KeyError(f"Device not found: {device_id}")

        self.devices[device_id]['enabled'] = True
        self._save_config()
        self.logger.info(f"Enabled device: {device_id}")

    def disable_device(self, device_id: str):
        """Disable device (excluded from sync)."""
        if device_id not in self.devices:
            raise KeyError(f"Device not found: {device_id}")

        self.devices[device_id]['enabled'] = False
        self._save_config()
        self.logger.info(f"Disabled device: {device_id}")

    def update_automation(self, **kwargs):
        """
        Update automation settings.

        Args:
            **kwargs: Automation settings (enabled, sync_time, timezone,
                      data_retention_days, output_directory)
        """
        for key, value in kwargs.items():
            if key in ['enabled', 'sync_time', 'timezone', 'data_retention_days', 'output_directory']:
                self.automation[key] = value
            else:
                self.logger.warning(f"Unknown automation setting: {key}")

        self._save_config()
        self.logger.info("Updated automation settings")

    def update_persistence(self, **kwargs):
        """
        Update persistence settings.

        Args:
            **kwargs: Persistence settings (enabled, backend, db_path, user_id,
                      persist_unified_table)
        """
        allowed = ['enabled', 'backend', 'db_path', 'user_id', 'persist_unified_table']
        for key, value in kwargs.items():
            if key in allowed:
                self.persistence[key] = value
            else:
                self.logger.warning(f"Unknown persistence setting: {key}")

        self._save_config()
        self.logger.info("Updated persistence settings")

    def list_devices(self) -> Dict[str, dict]:
        """
        Get all device configurations (without decrypted credentials).

        Returns:
            Dictionary of device configs with credentials marked as '***'
        """
        devices = {}
        for device_id, config in self.devices.items():
            safe_config = config.copy()
            safe_config['credentials'] = {k: '***' for k in config['credentials'].keys()}
            devices[device_id] = safe_config
        return devices

    def validate(self) -> bool:
        """
        Validate configuration integrity.

        Returns:
            True if configuration is valid

        Raises:
            ValueError: If configuration is invalid
        """
        # Validate devices
        for device_id, config in self.devices.items():
            if 'type' not in config:
                raise ValueError(f"Device {device_id} missing 'type'")
            if 'credentials' not in config:
                raise ValueError(f"Device {device_id} missing 'credentials'")
            if config['type'] not in ['huawei', 'garmin', 'lifesense_ring', 'mock']:
                raise ValueError(f"Device {device_id} has invalid type: {config['type']}")

        # Validate automation
        required_automation = ['enabled', 'sync_time', 'timezone', 'data_retention_days', 'output_directory']
        for key in required_automation:
            if key not in self.automation:
                raise ValueError(f"Automation missing required key: {key}")

        required_persistence = ['enabled', 'backend', 'db_path', 'user_id', 'persist_unified_table']
        for key in required_persistence:
            if key not in self.persistence:
                raise ValueError(f"Persistence missing required key: {key}")

        self.logger.info("Configuration validated successfully")
        return True
