"""
Core standardization logic for physio_std library.

Converts device-specific data to PhysioRecord format and exports to
DataFrame/Excel for downstream analysis.
"""

import logging
from datetime import datetime
from typing import List
import pandas as pd

from .protocols import DataType, PhysioRecord

log = logging.getLogger(__name__)


class PhysioStandardizer:
    """
    Standardizes physiological data to PhysioRecord format.

    Usage:
        standardizer = PhysioStandardizer()
        records = standardizer.standardize(raw_data)
        df = standardizer.to_dataframe(records)
        standardizer.to_excel(records, "output.xlsx")
    """

    def standardize(self, raw_data: List[dict]) -> List[PhysioRecord]:
        """
        Convert device-specific data to PhysioRecord format.

        Expected raw_data format (device-agnostic dict structure):
        {
            'timestamp_utc': int (Unix timestamp) or datetime,
            'source_device': str,
            'data_type': str (e.g., 'heart_rate', 'hrv'),
            'value': float,
            'unit': str,
            'confidence': float (optional, defaults to 1.0)
        }

        Args:
            raw_data: List of device-native dictionaries

        Returns:
            List of standardized PhysioRecord objects

        Raises:
            ValueError: If raw_data format invalid or missing required fields
        """
        if not raw_data:
            raise ValueError("raw_data cannot be empty")

        records = []
        for i, item in enumerate(raw_data):
            try:
                # Parse timestamp
                timestamp_raw = item.get('timestamp_utc')
                if timestamp_raw is None:
                    raise ValueError(f"Missing timestamp_utc in record {i}")

                if isinstance(timestamp_raw, int):
                    timestamp = datetime.utcfromtimestamp(timestamp_raw)
                elif isinstance(timestamp_raw, datetime):
                    timestamp = timestamp_raw
                else:
                    raise ValueError(f"Invalid timestamp_utc type: {type(timestamp_raw)}")

                # Parse data type
                data_type_str = item.get('data_type', '').lower()
                data_type = self._map_data_type(data_type_str)

                # Build record
                record = PhysioRecord(
                    timestamp_utc=timestamp,
                    source_device=str(item.get('source_device', 'Unknown')),
                    data_type=data_type,
                    value=float(item.get('value', 0.0)),
                    unit=str(item.get('unit', '')),
                    confidence=float(item.get('confidence', 1.0))
                )
                records.append(record)

            except Exception as e:
                log.warning(f"Failed to standardize record {i}: {e}")
                continue

        if not records:
            raise ValueError("No valid records produced from raw_data")

        log.info(f"Standardized {len(records)} records from {len(raw_data)} raw entries")
        return records

    def _map_data_type(self, data_type_str: str) -> DataType:
        """Map device-specific data type string to DataType enum."""
        mapping = {
            'heart_rate': DataType.HR,
            'hr': DataType.HR,
            'hrv': DataType.HRV,
            'sleep_stage': DataType.SLEEP_STAGE,
            'stress_score': DataType.STRESS_SCORE,
            'stress': DataType.STRESS_SCORE,
            'steps': DataType.STEPS,
            'temperature': DataType.TEMPERATURE,
            'temp': DataType.TEMPERATURE,
            'spo2': DataType.SPO2,
            'respiratory_rate': DataType.RESPIRATORY_RATE,
            'blood_pressure_systolic': DataType.BLOOD_PRESSURE_SYS,
            'blood_pressure_diastolic': DataType.BLOOD_PRESSURE_DIA,
            'energy': DataType.ENERGY,
            'calories': DataType.ENERGY,
            'activity_type': DataType.ACTIVITY_TYPE,
        }
        data_type = mapping.get(data_type_str)
        if data_type is None:
            log.warning(f"Unknown data_type '{data_type_str}', defaulting to HR")
            data_type = DataType.HR
        return data_type

    def to_dataframe(self, records: List[PhysioRecord]) -> pd.DataFrame:
        """
        Convert PhysioRecords to Pandas DataFrame.

        Args:
            records: List of PhysioRecord objects

        Returns:
            DataFrame with columns: timestamp_utc, source_device, data_type,
            value, unit, confidence
        """
        if not records:
            # Return empty DataFrame with correct schema
            return pd.DataFrame(columns=[
                'timestamp_utc', 'source_device', 'data_type',
                'value', 'unit', 'confidence'
            ])

        data = []
        for record in records:
            data.append({
                'timestamp_utc': record.timestamp_utc,
                'source_device': record.source_device,
                'data_type': record.data_type.value,  # Store enum value
                'value': record.value,
                'unit': record.unit,
                'confidence': record.confidence,
            })

        df = pd.DataFrame(data)
        log.info(f"Created DataFrame with {len(df)} rows")
        return df

    def to_excel(self, records: List[PhysioRecord], filepath: str) -> None:
        """
        Export PhysioRecords to Excel file.

        Args:
            filepath: Output file path (.xlsx)
            records: List of PhysioRecord objects

        Raises:
            IOError: If file write fails
        """
        try:
            df = self.to_dataframe(records)
            df.to_excel(filepath, index=False, engine='openpyxl')
            log.info(f"Exported {len(records)} records to {filepath}")
        except Exception as e:
            raise IOError(f"Failed to write Excel file: {e}")
