"""
Lifesense Smart Ring BLE provider for physiological data.

Uses async BLE operations to connect to Lifesense Smart Ring and fetch health data.
Based on the Lifesense BLE protocol (戒指BLE通信协议).

Supports: Heart Rate, HRV, Temperature, Steps, Sleep, SpO2, Stress.

NOTE: This provider wraps the existing ring BLE client and converts data to
PhysioRecord format. The actual BLE communication logic is in lexin_ring/smart_ring_ble.py.
You can update that module when working with Lifesense technicians for improved data fetching.
"""

import asyncio
import logging
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any

try:
    # Preferred import if packaged as module dependency.
    from lexin_ring.smart_ring_ble import RingBLEClient, SyncType  # type: ignore
except ImportError:
    try:
        # Backward-compatible fallback for local script/module usage.
        from smart_ring_ble import RingBLEClient, SyncType  # type: ignore
    except ImportError:
        RingBLEClient = None
        SyncType = None
        logging.warning("RingBLEClient not available. Install bleak and ring client support.")

from ..protocols import PhysioRecord, DataType
from .base_provider import BasePhysioProvider


class LifesenseRingProvider(BasePhysioProvider):
    """
    Lifesense Smart Ring BLE provider.

    Connects to Lifesense Smart Ring via Bluetooth Low Energy (BLE) and syncs
    physiological data. This provider wraps the existing RingBLEClient and
    converts ring data format to standardized PhysioRecord format.

    Supported Data Types:
    - Heart Rate (HR)
    - Heart Rate Variability (HRV)
    - Temperature
    - Steps
    - Sleep stages (from daily/hourly data)
    - SpO2 (if available from ring)
    - Stress (if available from ring)

    Configuration:
        credentials:
            device_mac: MAC address of the ring (optional, can scan)
            device_name: Device name prefix for scanning (default: "Ring")
            scan_timeout: BLE scan timeout in seconds (default: 15)
            sync_timeout: Data sync timeout in seconds (default: 120)

    NOTE: The actual BLE communication is handled by lexin_ring/smart_ring_ble.py.
    Work with Lifesense technicians to update that module for improved data fetching.
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Lifesense Ring provider.

        Args:
            config: Provider configuration with credentials
        """
        super().__init__(config)

        if RingBLEClient is None:
            raise ImportError(
                "RingBLEClient not available. Install bleak: pip install bleak"
            )

        creds = self.config['credentials']
        self.device_mac = creds.get('device_mac')
        self.device_name = creds.get('device_name', 'Ring')
        self.scan_timeout = creds.get('scan_timeout', 15)
        self.sync_timeout = creds.get('sync_timeout', 120)

        self.ble_client: Optional[RingBLEClient] = None
        self._event_loop: Optional[asyncio.AbstractEventLoop] = None

    def connect(self) -> bool:
        """
        Connect to Lifesense Ring via BLE.

        Scans for the ring device and establishes BLE connection.
        Also performs device binding if needed.

        Returns:
            True if connection successful, False otherwise
        """
        try:
            self.logger.info("Connecting to Lifesense Ring...")

            # Create or get event loop
            try:
                self._event_loop = asyncio.get_event_loop()
                if self._event_loop.is_closed():
                    self._event_loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(self._event_loop)
            except RuntimeError:
                self._event_loop = asyncio.new_event_loop()
                asyncio.set_event_loop(self._event_loop)

            # Initialize BLE client
            self.ble_client = RingBLEClient()

            # Scan for device
            self.logger.info(f"Scanning for device: {self.device_name}")
            device = self._event_loop.run_until_complete(
                self.ble_client.scan(
                    name_prefix=self.device_name,
                    timeout=self.scan_timeout
                )
            )

            if device is None:
                self.logger.error("Ring device not found during scan")
                return False

            self.logger.info(f"Found device: {device.name} ({device.address})")

            # Connect to device
            self._event_loop.run_until_complete(self.ble_client.connect())

            # Wait for login (device-initiated)
            self.logger.info("Waiting for device login...")
            login_success = self._event_loop.run_until_complete(
                asyncio.wait_for(
                    self.ble_client.login_event.wait(),
                    timeout=30
                )
            )

            if not login_success:
                self.logger.error("Device login failed")
                return False

            self.logger.info("Ring connection successful")
            self.connected = True
            return True

        except asyncio.TimeoutError:
            self.logger.error("Connection timeout")
            self.connected = False
            return False
        except Exception as e:
            self.logger.error(f"Ring connection failed: {e}")
            self.connected = False
            return False

    def fetch_data(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[PhysioRecord]:
        """
        Fetch physiological data from Lifesense Ring.

        Triggers data sync and converts ring data format to PhysioRecord format.

        Args:
            start_time: Start of time range (UTC). If None, fetches all available data.
            end_time: End of time range (UTC). If None, uses current time.

        Returns:
            List of PhysioRecord objects

        Raises:
            ConnectionError: If not connected to ring
            ValueError: If time range invalid

        NOTE: The ring may return all available data regardless of time range.
        Filtering by time range is done in post-processing.
        """
        self._ensure_connected()
        self._validate_time_range(start_time, end_time)

        # Default to current time if not specified
        if end_time is None:
            end_time = datetime.utcnow()
        if start_time is None:
            start_time = end_time - timedelta(days=7)

        self.logger.info(f"Fetching ring data from {start_time} to {end_time}")

        try:
            # Request data sync from ring
            # NOTE: The ring protocol may return all available data.
            # You can modify smart_ring_ble.py to add time range filtering
            # when working with Lifesense technicians.
            self._event_loop.run_until_complete(
                self.ble_client.request_data_sync(SyncType.ALL_MEASUREMENT)
            )

            # Wait for sync to complete
            self.logger.info("Waiting for data sync to complete...")
            self._event_loop.run_until_complete(
                asyncio.wait_for(
                    self.ble_client.sync_done_event.wait(),
                    timeout=self.sync_timeout
                )
            )

            self.logger.info("Data sync completed")

            # Convert ring data format to PhysioRecord format
            records = self._convert_ring_data(start_time, end_time)

            self.logger.info(f"Fetched {len(records)} records from ring")
            return records

        except asyncio.TimeoutError:
            self.logger.error("Data sync timeout")
            raise ConnectionError("Ring data sync timeout")
        except Exception as e:
            self.logger.error(f"Data fetch failed: {e}")
            raise

    def _convert_ring_data(
        self,
        start_time: datetime,
        end_time: datetime
    ) -> List[PhysioRecord]:
        """
        Convert ring data format to PhysioRecord format.

        The ring stores data in self.ble_client.health_data dictionary with keys:
        - 'heart_rate': List of {'utc': int, 'heart_rate_bpm': int}
        - 'temperature': List of {'utc': int, 'temperature_c': float}
        - 'hrv': List of {'utc': int, 'hrv_ms': int}
        - 'daily': List of daily summaries with steps, calories, etc.
        - 'hourly': List of hourly summaries

        Args:
            start_time: Start time for filtering (UTC)
            end_time: End time for filtering (UTC)

        Returns:
            List of PhysioRecord objects
        """
        records = []

        health_data = self.ble_client.health_data

        # Convert heart rate data
        for entry in health_data.get('heart_rate', []):
            try:
                timestamp = datetime.utcfromtimestamp(entry['utc'])
                hr_value = entry.get('heart_rate_bpm', 0)

                # Filter by time range and validate value
                if not (start_time <= timestamp <= end_time):
                    continue
                if hr_value <= 0:
                    continue

                records.append(PhysioRecord(
                    timestamp_utc=timestamp,
                    source_device="Lifesense_Ring",
                    data_type=DataType.HR,
                    value=float(hr_value),
                    unit='bpm',
                    confidence=1.0
                ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid HR entry: {e}")

        # Convert temperature data
        for entry in health_data.get('temperature', []):
            try:
                timestamp = datetime.utcfromtimestamp(entry['utc'])
                temp_value = entry.get('temperature_c', 0.0)

                if not (start_time <= timestamp <= end_time):
                    continue
                if temp_value <= 0:
                    continue

                records.append(PhysioRecord(
                    timestamp_utc=timestamp,
                    source_device="Lifesense_Ring",
                    data_type=DataType.TEMPERATURE,
                    value=float(temp_value),
                    unit='°C',
                    confidence=1.0
                ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid temperature entry: {e}")

        # Convert HRV data
        for entry in health_data.get('hrv', []):
            try:
                timestamp = datetime.utcfromtimestamp(entry['utc'])
                hrv_value = entry.get('hrv_ms', 0)

                if not (start_time <= timestamp <= end_time):
                    continue
                if hrv_value <= 0:
                    continue

                records.append(PhysioRecord(
                    timestamp_utc=timestamp,
                    source_device="Lifesense_Ring",
                    data_type=DataType.HRV,
                    value=float(hrv_value),
                    unit='ms',
                    confidence=1.0
                ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid HRV entry: {e}")

        # Convert daily step data
        for entry in health_data.get('daily', []):
            try:
                timestamp = datetime.utcfromtimestamp(entry['utc'])
                steps = entry.get('steps', 0)

                if not (start_time <= timestamp <= end_time):
                    continue
                if steps <= 0:
                    continue

                records.append(PhysioRecord(
                    timestamp_utc=timestamp,
                    source_device="Lifesense_Ring",
                    data_type=DataType.STEPS,
                    value=float(steps),
                    unit='steps',
                    confidence=1.0
                ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid daily entry: {e}")

        # NOTE: Additional data types can be added here when available from ring:
        # - SpO2: DataType.SPO2
        # - Stress: DataType.STRESS_SCORE
        # - Sleep stages: DataType.SLEEP_STAGE
        # Work with Lifesense technicians to identify the data structure
        # for these measurements in the ring protocol.

        return records

    def disconnect(self) -> None:
        """Close BLE connection to ring."""
        if self.ble_client and self.ble_client.client:
            try:
                self._event_loop.run_until_complete(
                    self.ble_client.client.disconnect()
                )
            except Exception as e:
                self.logger.warning(f"Disconnect error: {e}")

        self.ble_client = None
        self.connected = False
        self.logger.info("Disconnected from Lifesense Ring")

    def __del__(self):
        """Cleanup on deletion."""
        if self.connected:
            self.disconnect()


# Helper function for testing/development
def create_mock_ring_data() -> Dict[str, List[Dict]]:
    """
    Create mock ring data for testing purposes.

    This function generates synthetic data in the same format as the ring BLE client.
    Useful for testing the data conversion logic without a physical ring.

    Returns:
        Dictionary with mock health data
    """
    base_time = int(datetime.utcnow().timestamp()) - 86400  # 24 hours ago

    return {
        'heart_rate': [
            {
                'utc': base_time + i * 60,
                'time': datetime.utcfromtimestamp(base_time + i * 60).strftime('%Y-%m-%d %H:%M:%S'),
                'heart_rate_bpm': 60 + (i % 20)
            }
            for i in range(100)
        ],
        'temperature': [
            {
                'utc': base_time + i * 300,
                'time': datetime.utcfromtimestamp(base_time + i * 300).strftime('%Y-%m-%d %H:%M:%S'),
                'temperature_c': 36.5 + (i % 10) * 0.1
            }
            for i in range(50)
        ],
        'hrv': [
            {
                'utc': base_time + i * 3600,
                'time': datetime.utcfromtimestamp(base_time + i * 3600).strftime('%Y-%m-%d %H:%M:%S'),
                'hrv_ms': 40 + (i % 20)
            }
            for i in range(24)
        ],
        'daily': [
            {
                'utc': base_time + i * 3600,
                'time': datetime.utcfromtimestamp(base_time + i * 3600).strftime('%Y-%m-%d %H:%M:%S'),
                'steps': 1000 + i * 100,
                'calories_kcal': 50.0 + i * 10,
                'distance_m': 800 + i * 100,
                'battery_level': 80
            }
            for i in range(24)
        ],
        'hourly': []
    }
