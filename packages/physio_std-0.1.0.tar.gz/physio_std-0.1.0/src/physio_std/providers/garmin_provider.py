"""
Garmin Connect provider for physiological data.

Uses the garminconnect library to fetch data from Garmin Connect API.
Supports: Heart Rate, HRV, Stress, Sleep, SpO2, Steps.
"""

import time
import logging
from datetime import datetime, timedelta, time as dt_time
from typing import List, Optional, Dict, Any

try:
    from garminconnect import (
        Garmin,
        GarminConnectAuthenticationError,
        GarminConnectConnectionError,
        GarminConnectTooManyRequestsError,
    )
except ImportError:
    Garmin = None  # type: ignore[assignment]

    class GarminConnectAuthenticationError(Exception):
        pass

    class GarminConnectConnectionError(Exception):
        pass

    class GarminConnectTooManyRequestsError(Exception):
        pass

from ..protocols import PhysioRecord, DataType
from .base_provider import BasePhysioProvider


class GarminProvider(BasePhysioProvider):
    """
    Garmin Connect provider using garminconnect library.

    Fetches historical physiological data from Garmin Connect cloud service.
    Uses Garth library under the hood for OAuth2 authentication.

    Supported Data Types:
    - Heart Rate (HR)
    - Heart Rate Variability (HRV)
    - Stress Score
    - Sleep Stages
    - SpO2
    - Steps

    Configuration:
        credentials:
            email: Garmin Connect email
            password: Garmin Connect password
            is_cn: bool (optional, use Garmin China server connect.garmin.cn)

    Note: Tokens are automatically stored in ~/.garminconnect
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Garmin provider.

        Args:
            config: Provider configuration with credentials
        """
        super().__init__(config)
        if Garmin is None:
            raise ImportError(
                "garminconnect library not installed. "
                "Install with: pip install physio-std[garmin]"
            )

        self.email = self.config['credentials'].get('email')
        self.password = self.config['credentials'].get('password')

        # Region support: Garmin Global vs Garmin China
        creds = self.config.get('credentials', {})
        region = str(self.config.get('region', creds.get('region', 'global'))).lower().strip()
        self.is_cn = bool(self.config.get('is_cn', creds.get('is_cn', region == 'cn')))

        self.client: Optional[Garmin] = None
        self._device_model = None

        if not self.email or not self.password:
            raise ValueError("Garmin provider requires 'email' and 'password' credentials")

    def connect(self) -> bool:
        """
        Connect to Garmin Connect.

        Uses cached tokens from ~/.garminconnect if available.

        Returns:
            True if connection successful, False otherwise
        """
        try:
            self.logger.info("Connecting to Garmin Connect...")
            self.client = Garmin(self.email, self.password, is_cn=self.is_cn)
            self.client.login()

            if self.is_cn:
                self.logger.info("Using Garmin China server (connect.garmin.cn)")
            else:
                self.logger.info("Using Garmin Global server (connect.garmin.com)")

            # Get device info for source tagging
            try:
                devices = self.client.get_devices()
                if devices:
                    # Use first device (usually primary watch)
                    self._device_model = devices[0].get('productDisplayName', 'Unknown')
                    self.logger.info(f"Connected to Garmin device: {self._device_model}")
            except Exception as e:
                self.logger.warning(f"Could not fetch device info: {e}")
                self._device_model = "Unknown"

            self.connected = True
            self.logger.info("Garmin Connect connection successful")
            return True

        except GarminConnectAuthenticationError as e:
            self.logger.error(f"Garmin authentication failed: {e}")
            self.connected = False
            return False
        except GarminConnectConnectionError as e:
            self.logger.error(f"Garmin connection error: {e}")
            self.connected = False
            return False
        except Exception as e:
            self.logger.error(f"Unexpected error connecting to Garmin: {e}")
            self.connected = False
            return False

    def fetch_data(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[PhysioRecord]:
        """
        Fetch physiological data from Garmin Connect.

        Args:
            start_time: Start of time range (UTC). If None, fetches last 7 days.
            end_time: End of time range (UTC). If None, uses current time.

        Returns:
            List of PhysioRecord objects

        Raises:
            ConnectionError: If not connected to Garmin
            ValueError: If time range invalid
        """
        self._ensure_connected()
        self._validate_time_range(start_time, end_time)

        # Default to last 7 days if not specified
        if end_time is None:
            end_time = datetime.utcnow()
        if start_time is None:
            start_time = end_time - timedelta(days=7)

        self.logger.info(f"Fetching Garmin data from {start_time} to {end_time}")

        records = []
        current_date = start_time.date()
        end_date = end_time.date()

        # Fetch data day by day (Garmin API limitation)
        while current_date <= end_date:
            date_str = current_date.strftime("%Y-%m-%d")
            self.logger.debug(f"Fetching data for {date_str}")

            try:
                # Fetch all data types for this date
                records.extend(self._fetch_heart_rate(date_str))
                records.extend(self._fetch_hrv(date_str))
                records.extend(self._fetch_stress(date_str))
                records.extend(self._fetch_sleep(date_str))
                records.extend(self._fetch_spo2(date_str))
                records.extend(self._fetch_steps(date_str))

            except GarminConnectTooManyRequestsError:
                self.logger.warning("Rate limited by Garmin API, waiting 60s...")
                time.sleep(60)
                continue  # Retry same date
            except Exception as e:
                self.logger.error(f"Error fetching data for {date_str}: {e}")

            current_date += timedelta(days=1)

        # Filter by exact time range
        records = [
            r for r in records
            if start_time <= r.timestamp_utc <= end_time
        ]

        self.logger.info(f"Fetched {len(records)} records from Garmin")
        return records

    def _fetch_heart_rate(self, date_str: str) -> List[PhysioRecord]:
        """Fetch heart rate data for a specific date."""
        records = []
        try:
            data = self.client.get_heart_rates(date_str)
            if not data:
                return records

            for entry in data.get('heartRateValues', []):
                try:
                    # Parse Garmin timestamp format
                    timestamp_ms = entry[0]  # Milliseconds since epoch
                    hr_value = entry[1]  # Heart rate in bpm

                    if hr_value is None or hr_value <= 0:
                        continue

                    timestamp = datetime.utcfromtimestamp(timestamp_ms / 1000.0)

                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device=f"Garmin_{self._device_model}",
                        data_type=DataType.HR,
                        value=float(hr_value),
                        unit='bpm',
                        confidence=1.0  # Garmin data assumed high quality
                    ))
                except Exception as e:
                    self.logger.debug(f"Skipped invalid HR entry: {e}")

        except GarminConnectTooManyRequestsError:
            # Re-raise rate limiting exception for handling at higher level
            raise
        except Exception as e:
            self.logger.debug(f"No HR data for {date_str}: {e}")

        return records

    def _fetch_hrv(self, date_str: str) -> List[PhysioRecord]:
        """Fetch HRV data for a specific date."""
        records = []
        try:
            data = self.client.get_hrv_data(date_str)
            if not data:
                return records

            # Garmin HRV is usually a daily summary (overnight measurement)
            hrv_value = data.get('lastNightAvg')
            if hrv_value and hrv_value > 0:
                # Use midnight of the date as timestamp
                timestamp = datetime.strptime(date_str, "%Y-%m-%d")

                records.append(PhysioRecord(
                    timestamp_utc=timestamp,
                    source_device=f"Garmin_{self._device_model}",
                    data_type=DataType.HRV,
                    value=float(hrv_value),
                    unit='ms',
                    confidence=1.0
                ))

        except Exception as e:
            self.logger.debug(f"No HRV data for {date_str}: {e}")

        return records

    def _fetch_stress(self, date_str: str) -> List[PhysioRecord]:
        """Fetch stress data for a specific date."""
        records = []
        try:
            data = self.client.get_stress_data(date_str)
            if not data:
                return records

            for entry in data.get('stressValuesArray', []):
                try:
                    timestamp_ms = entry[0]
                    stress_value = entry[1]

                    if stress_value is None or stress_value < 0:
                        continue

                    timestamp = datetime.utcfromtimestamp(timestamp_ms / 1000.0)

                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device=f"Garmin_{self._device_model}",
                        data_type=DataType.STRESS_SCORE,
                        value=float(stress_value),
                        unit='score',
                        confidence=1.0
                    ))
                except Exception as e:
                    self.logger.debug(f"Skipped invalid stress entry: {e}")

        except Exception as e:
            self.logger.debug(f"No stress data for {date_str}: {e}")

        return records

    def _fetch_sleep(self, date_str: str) -> List[PhysioRecord]:
        """Fetch sleep data for a specific date."""
        records = []
        try:
            data = self.client.get_sleep_data(date_str)
            if not data or 'sleepLevels' not in data:
                return records

            for level in data['sleepLevels']:
                try:
                    start_ms = level['startGMT']
                    end_ms = level['endGMT']
                    stage = level.get('activityLevel', 'unknown')

                    # Map Garmin stages to standard
                    stage_mapping = {
                        'deep': 'deep',
                        'light': 'light',
                        'rem': 'REM',
                        'awake': 'awake'
                    }
                    stage_name = stage_mapping.get(stage.lower(), stage)

                    # Create record at midpoint of stage
                    midpoint_ms = (start_ms + end_ms) / 2
                    timestamp = datetime.utcfromtimestamp(midpoint_ms / 1000.0)

                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device=f"Garmin_{self._device_model}",
                        data_type=DataType.SLEEP_STAGE,
                        value=0.0,  # Categorical data, value not meaningful
                        unit=stage_name,
                        confidence=1.0
                    ))
                except Exception as e:
                    self.logger.debug(f"Skipped invalid sleep entry: {e}")

        except Exception as e:
            self.logger.debug(f"No sleep data for {date_str}: {e}")

        return records

    def _fetch_spo2(self, date_str: str) -> List[PhysioRecord]:
        """Fetch SpO2 data for a specific date."""
        records = []
        try:
            data = self.client.get_spo2_data(date_str)
            if not data:
                return records

            for entry in data.get('allDaySpO2', []):
                try:
                    timestamp_ms = entry[0]
                    spo2_value = entry[1]

                    if spo2_value is None or spo2_value <= 0 or spo2_value > 100:
                        continue

                    timestamp = datetime.utcfromtimestamp(timestamp_ms / 1000.0)

                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device=f"Garmin_{self._device_model}",
                        data_type=DataType.SPO2,
                        value=float(spo2_value),
                        unit='%',
                        confidence=1.0
                    ))
                except Exception as e:
                    self.logger.debug(f"Skipped invalid SpO2 entry: {e}")

        except Exception as e:
            self.logger.debug(f"No SpO2 data for {date_str}: {e}")

        return records

    def _fetch_steps(self, date_str: str) -> List[PhysioRecord]:
        """Fetch step count data for a specific date."""
        records = []
        try:
            data = self.client.get_steps_data(date_str)
            if not data:
                return records

            # Get daily summary
            total_steps = data.get('totalSteps')
            if total_steps and total_steps > 0:
                # Use noon as representative timestamp
                timestamp = datetime.strptime(date_str, "%Y-%m-%d")
                timestamp = timestamp.replace(hour=12, minute=0, second=0)

                records.append(PhysioRecord(
                    timestamp_utc=timestamp,
                    source_device=f"Garmin_{self._device_model}",
                    data_type=DataType.STEPS,
                    value=float(total_steps),
                    unit='steps',
                    confidence=1.0
                ))

        except Exception as e:
            self.logger.debug(f"No steps data for {date_str}: {e}")

        return records

    def disconnect(self) -> None:
        """Close Garmin Connect session."""
        if self.client:
            # Garminconnect doesn't have explicit disconnect
            self.client = None
        self.connected = False
        self.logger.info("Disconnected from Garmin Connect")
