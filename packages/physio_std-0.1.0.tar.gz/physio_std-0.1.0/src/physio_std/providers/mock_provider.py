"""
Mock physiological data provider for testing.

Supports:
- Synthetic sine-wave HR/HRV generation
- Loading from CSV fixtures
- Simulating connection failures
"""

import logging
import math
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional
import pandas as pd

from ..protocols import DataType, PhysioRecord

log = logging.getLogger(__name__)


class MockPhysioProvider:
    """
    Mock physio provider for testing without hardware.

    Modes:
    - 'synthetic': Generate sine-wave HR/HRV data
    - 'csv': Load data from fixture CSV file
    - 'failure': Simulate connection/fetch failures

    Usage:
        provider = MockPhysioProvider(mode='synthetic')
        provider.connect()
        records = provider.fetch_data()
    """

    def __init__(
        self,
        config: Optional[dict] = None,
        mode: str = 'synthetic',
        data_file: Optional[Path] = None
    ):
        """
        Initialize mock provider.

        Args:
            config: Configuration dict (for compatibility with other providers)
            mode: 'synthetic', 'csv', or 'failure'
            data_file: Path to CSV file (required if mode='csv')
        """
        # Support both config dict and direct parameters
        if config is not None:
            self.config = config
            self.mode = config.get('credentials', {}).get('mode', mode)
            self.data_file = config.get('credentials', {}).get('data_file', data_file)
        else:
            self.config = {'type': 'mock', 'credentials': {'mode': mode}}
            self.mode = mode
            self.data_file = data_file

        self.connected = False

        if mode == 'csv' and data_file is None:
            raise ValueError("data_file required when mode='csv'")

    def connect(self) -> bool:
        """
        Simulate connection to device.

        Returns:
            True if connection successful, False if mode='failure'
        """
        if self.mode == 'failure':
            log.warning("Mock provider in failure mode, connection failed")
            self.connected = False
            return False

        log.info(f"Mock provider connected (mode={self.mode})")
        self.connected = True
        return True

    def fetch_data(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[PhysioRecord]:
        """
        Fetch physiological data.

        Args:
            start_time: Start of time range (UTC)
            end_time: End of time range (UTC)

        Returns:
            List of PhysioRecord objects

        Raises:
            ConnectionError: If not connected
            ValueError: If time range invalid
        """
        if not self.connected:
            raise ConnectionError("Not connected to device")

        if start_time and end_time and start_time >= end_time:
            raise ValueError("start_time must be before end_time")

        if self.mode == 'synthetic':
            return self._generate_synthetic(start_time, end_time)
        elif self.mode == 'csv':
            return self._load_csv(start_time, end_time)
        else:
            return []

    def disconnect(self) -> None:
        """Close connection to device."""
        self.connected = False
        log.info("Mock provider disconnected")

    def _generate_synthetic(
        self,
        start_time: Optional[datetime],
        end_time: Optional[datetime]
    ) -> List[PhysioRecord]:
        """
        Generate synthetic sine-wave physiological data.

        Simulates:
        - Heart rate: 60-80 bpm baseline with sine wave
        - HRV: 40-60 ms baseline with inverse sine wave
        """
        if start_time is None:
            start_time = datetime.utcnow() - timedelta(hours=1)
        if end_time is None:
            end_time = datetime.utcnow()

        records = []
        current_time = start_time
        interval = timedelta(minutes=1)  # 1-minute intervals

        i = 0
        while current_time <= end_time:
            # Heart rate: 70 ± 10 * sin(t)
            hr_value = 70.0 + 10.0 * math.sin(i * 0.1)

            # HRV: 50 ± 10 * cos(t) (inverse relationship with HR)
            hrv_value = 50.0 + 10.0 * math.cos(i * 0.1)

            # HR record
            records.append(PhysioRecord(
                timestamp_utc=current_time,
                source_device="Mock_Device",
                data_type=DataType.HR,
                value=hr_value,
                unit="bpm",
                confidence=1.0
            ))

            # HRV record
            records.append(PhysioRecord(
                timestamp_utc=current_time,
                source_device="Mock_Device",
                data_type=DataType.HRV,
                value=hrv_value,
                unit="ms",
                confidence=1.0
            ))

            current_time += interval
            i += 1

        log.info(f"Generated {len(records)} synthetic records")
        return records

    def _load_csv(
        self,
        start_time: Optional[datetime],
        end_time: Optional[datetime]
    ) -> List[PhysioRecord]:
        """
        Load physiological data from CSV file.

        Expected CSV format:
        timestamp_utc,source_device,data_type,value,unit,confidence
        2024-01-01T10:00:00Z,Device,HR,75.0,bpm,1.0
        """
        if self.data_file is None or not self.data_file.exists():
            raise FileNotFoundError(f"CSV file not found: {self.data_file}")

        try:
            df = pd.read_csv(self.data_file)
            df['timestamp_utc'] = pd.to_datetime(df['timestamp_utc'])

            # Filter by time range if specified
            if start_time:
                df = df[df['timestamp_utc'] >= start_time]
            if end_time:
                df = df[df['timestamp_utc'] <= end_time]

            records = []
            for _, row in df.iterrows():
                # Map data_type string to enum
                data_type_map = {
                    'HR': DataType.HR,
                    'HRV': DataType.HRV,
                    'SLEEP_STAGE': DataType.SLEEP_STAGE,
                    'STRESS_SCORE': DataType.STRESS_SCORE,
                    'STEPS': DataType.STEPS,
                    'TEMPERATURE': DataType.TEMPERATURE,
                    'SPO2': DataType.SPO2,
                }
                data_type = data_type_map.get(row['data_type'], DataType.HR)

                records.append(PhysioRecord(
                    timestamp_utc=row['timestamp_utc'].to_pydatetime(),
                    source_device=str(row['source_device']),
                    data_type=data_type,
                    value=float(row['value']),
                    unit=str(row['unit']),
                    confidence=float(row.get('confidence', 1.0))
                ))

            log.info(f"Loaded {len(records)} records from {self.data_file}")
            return records

        except Exception as e:
            raise ValueError(f"Failed to load CSV: {e}")
