"""Provider decorator that persists fetched PhysioRecord data to SQLite."""

from __future__ import annotations

import logging
from datetime import datetime
from typing import List, Optional

from ..protocols import PhysioProviderProtocol, PhysioRecord
from ..storage.repository import SQLitePhysioRepository


class PersistingPhysioProvider(PhysioProviderProtocol):
    """Wrap a provider to persist fetched records while preserving provider interface."""

    def __init__(
        self,
        provider: PhysioProviderProtocol,
        *,
        repository: SQLitePhysioRepository,
        user_id: str,
        device_id: str,
    ):
        self.provider = provider
        self.repository = repository
        self.user_id = user_id
        self.device_id = device_id
        self.logger = logging.getLogger("physio_std.PersistingPhysioProvider")

    @property
    def connected(self) -> bool:
        return bool(getattr(self.provider, "connected", False))

    @connected.setter
    def connected(self, value: bool) -> None:
        setattr(self.provider, "connected", value)

    @property
    def config(self):
        return getattr(self.provider, "config", {})

    def connect(self) -> bool:
        return self.provider.connect()

    def fetch_data(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> List[PhysioRecord]:
        records = self.provider.fetch_data(start_time, end_time)

        if records:
            try:
                self.repository.save_records(
                    user_id=self.user_id,
                    device_id=self.device_id,
                    records=records,
                )
            except Exception as e:
                self.logger.warning("Failed to persist fetched records: %s", e)

        return records

    def disconnect(self) -> None:
        try:
            self.provider.disconnect()
        finally:
            try:
                self.repository.close()
            except Exception as e:
                self.logger.warning("Failed closing repository: %s", e)
