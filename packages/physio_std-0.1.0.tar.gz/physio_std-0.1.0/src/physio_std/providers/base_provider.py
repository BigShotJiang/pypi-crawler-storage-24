"""
Base provider class for physiological data sources.

Provides common functionality shared across all device providers
(Garmin, Huawei, Lifesense Ring, etc.).
"""

import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional, Dict, Any

from ..protocols import PhysioProviderProtocol, PhysioRecord


class BasePhysioProvider(ABC, PhysioProviderProtocol):
    """
    Abstract base class for all physiological data providers.

    Provides shared functionality:
    - Configuration validation
    - Logging setup
    - Standard confidence calculation
    - Connection state management

    Subclasses must implement:
    - connect()
    - fetch_data()
    - disconnect()
    """

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize provider with configuration.

        Args:
            config: Provider configuration including credentials

        Raises:
            ValueError: If configuration is invalid
        """
        self.config = config
        self.logger = logging.getLogger(f"physio_std.{self.__class__.__name__}")
        self.connected = False
        self._validate_config()

    def _validate_config(self):
        """
        Validate provider configuration.

        Subclasses can override to add device-specific validation.

        Raises:
            ValueError: If configuration is invalid
        """
        if 'credentials' not in self.config:
            raise ValueError(f"{self.__class__.__name__}: 'credentials' missing from config")

        if 'type' not in self.config:
            raise ValueError(f"{self.__class__.__name__}: 'type' missing from config")

        self.logger.debug("Configuration validated")

    def _calculate_confidence(
        self,
        battery_level: Optional[float] = None,
        signal_quality: Optional[float] = None,
        device_status: Optional[str] = None
    ) -> float:
        """
        Calculate data confidence score based on device state.

        Standard formula: confidence = (battery * 0.4) + (signal * 0.6)

        Args:
            battery_level: Battery level (0.0-1.0). If None, assumed 1.0
            signal_quality: Signal quality (0.0-1.0). If None, assumed 1.0
            device_status: Device status string (e.g., 'ok', 'warning', 'error')

        Returns:
            Confidence score (0.0-1.0)
        """
        # Default values (assume good conditions)
        battery = battery_level if battery_level is not None else 1.0
        signal = signal_quality if signal_quality is not None else 1.0

        # Adjust for device status
        if device_status:
            status_multiplier = {
                'ok': 1.0,
                'warning': 0.8,
                'error': 0.5,
                'disconnected': 0.0
            }.get(device_status.lower(), 1.0)
        else:
            status_multiplier = 1.0

        # Calculate weighted confidence
        confidence = (battery * 0.4 + signal * 0.6) * status_multiplier

        # Clamp to valid range
        return max(0.0, min(1.0, confidence))

    def _validate_time_range(
        self,
        start_time: Optional[datetime],
        end_time: Optional[datetime]
    ):
        """
        Validate time range for data fetch.

        Args:
            start_time: Start of time range
            end_time: End of time range

        Raises:
            ValueError: If time range is invalid
        """
        if start_time and end_time:
            if start_time > end_time:
                raise ValueError(f"start_time ({start_time}) must be <= end_time ({end_time})")

            # Check for unreasonable time ranges (> 1 year)
            delta = end_time - start_time
            if delta.days > 365:
                self.logger.warning(
                    f"Large time range requested: {delta.days} days. "
                    "This may take significant time or fail due to API limits."
                )

    def _ensure_connected(self):
        """
        Ensure provider is connected before operations.

        Raises:
            ConnectionError: If not connected
        """
        if not self.connected:
            raise ConnectionError(
                f"{self.__class__.__name__} not connected. Call connect() first."
            )

    @abstractmethod
    def connect(self) -> bool:
        """
        Establish connection to device/API.

        Must be implemented by subclasses.

        Returns:
            True if connection successful, False otherwise
        """
        pass

    @abstractmethod
    def fetch_data(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[PhysioRecord]:
        """
        Fetch physiological data from device.

        Must be implemented by subclasses.

        Args:
            start_time: Start of time range (UTC)
            end_time: End of time range (UTC)

        Returns:
            List of PhysioRecord objects

        Raises:
            ConnectionError: If device not connected
            ValueError: If time range invalid
        """
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """
        Close connection to device/API.

        Must be implemented by subclasses.
        Should release all resources (BLE connections, HTTP sessions, etc.)
        """
        pass

    def __enter__(self):
        """Context manager entry."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.disconnect()

    def __repr__(self) -> str:
        """String representation."""
        status = "connected" if self.connected else "disconnected"
        device_type = self.config.get('type', 'unknown')
        return f"<{self.__class__.__name__} ({device_type}) - {status}>"
