"""
Huawei Health Kit provider for physiological data.

Primary path: REST API with OAuth2 authentication
Fallback path: GDPR data export parser

Supports: Heart Rate, HRV, Stress, Sleep, SpO2, Steps, Blood Pressure.
"""

import logging
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import List, Optional, Dict, Any

import requests
from requests_oauthlib import OAuth2Session

from ..protocols import PhysioRecord, DataType
from .base_provider import BasePhysioProvider


class HuaweiHealthKitProvider(BasePhysioProvider):
    """
    Huawei Health Kit REST API provider.

    Uses OAuth2 for authentication and queries the Huawei Health Kit API
    for historical physiological data.

    Supported Data Types:
    - Heart Rate (HR)
    - Heart Rate Variability (HRV)
    - Stress Score
    - Sleep Stages
    - SpO2
    - Steps
    - Blood Pressure

    Configuration:
        credentials:
            client_id: Huawei Health Kit client ID
            client_secret: Huawei Health Kit client secret
            access_token: OAuth2 access token (optional, will be refreshed)
            refresh_token: OAuth2 refresh token
        fallback: 'gdpr_export' (optional)
        gdpr_export_path: Path to GDPR export directory (if fallback enabled)
    """

    API_BASE = "https://health-api.cloud.huawei.com/healthkit/v1"
    TOKEN_URL = "https://oauth-login.cloud.huawei.com/oauth2/v3/token"

    # Huawei Health Kit data type identifiers
    DATA_TYPE_MAPPING = {
        'heart_rate': 'DT_INSTANTANEOUS_HEART_RATE',
        'hrv': 'DT_HEART_RATE_VARIABILITY_SDNN',
        'stress': 'DT_STRESS_SCORE',
        'sleep': 'DT_SLEEP',
        'spo2': 'DT_SPO2',
        'steps': 'DT_CONTINUOUS_STEPS_DELTA',
        'blood_pressure': 'DT_INSTANTANEOUS_BLOOD_PRESSURE',
    }

    def __init__(self, config: Dict[str, Any]):
        """
        Initialize Huawei provider.

        Args:
            config: Provider configuration with credentials
        """
        super().__init__(config)

        creds = self.config['credentials']
        self.client_id = creds.get('client_id')
        self.client_secret = creds.get('client_secret')
        self.access_token = creds.get('access_token')
        self.refresh_token = creds.get('refresh_token')

        self.session: Optional[requests.Session] = None
        self._device_model = None

        # Fallback configuration
        self.use_fallback = self.config.get('fallback') == 'gdpr_export'
        self.gdpr_export_path = self.config.get('gdpr_export_path') or creds.get('gdpr_export_path')

        has_any_api_cred = bool(self.client_id or self.client_secret or self.access_token or self.refresh_token)
        has_api_creds = bool(self.client_id and self.client_secret)
        has_gdpr_fallback = bool(self.gdpr_export_path)

        # Preserve explicit validation for API configurations.
        if has_any_api_cred and not has_api_creds:
            raise ValueError("Huawei provider requires 'client_id' and 'client_secret'")

        if has_api_creds and not self.refresh_token and not has_gdpr_fallback:
            raise ValueError("Huawei provider requires 'refresh_token' or fallback configuration")

        if not has_api_creds and not has_gdpr_fallback:
            raise ValueError(
                "Huawei provider requires either API credentials ('client_id' + 'client_secret') "
                "or GDPR export path ('gdpr_export_path')"
            )

        # Explicit mode used by real-device scripts and runtime logic
        if has_api_creds and has_gdpr_fallback:
            self.mode = 'hybrid'  # API first, fallback to GDPR
            self.use_fallback = True
        elif has_api_creds:
            self.mode = 'api'
        else:
            self.mode = 'gdpr'
            self.use_fallback = True

    def connect(self) -> bool:
        """
        Connect to Huawei Health Kit API.

        Returns:
            True if connection successful, False otherwise
        """
        try:
            # GDPR-only mode does not require network authentication.
            if self.mode == 'gdpr':
                export_path = Path(self.gdpr_export_path).expanduser()
                if not export_path.exists():
                    self.logger.error(f"GDPR export path does not exist: {export_path}")
                    self.connected = False
                    return False

                self.connected = True
                self.logger.info(f"Huawei GDPR mode ready: {export_path}")
                return True

            self.logger.info("Connecting to Huawei Health Kit API...")

            # Initialize session
            self.session = requests.Session()

            # Verify or refresh access token
            if self.access_token and self._verify_token():
                self.connected = True
                self.logger.info("Using existing Huawei access token")
                return True

            # Refresh access token
            if self.refresh_token and self._refresh_access_token():
                self.connected = True
                self.logger.info("Huawei Health Kit connection successful")
                return True

            # In hybrid mode, fail over to GDPR export when API auth fails.
            if self.mode == 'hybrid' and self.use_fallback and self.gdpr_export_path:
                export_path = Path(self.gdpr_export_path).expanduser()
                if export_path.exists():
                    self.connected = True
                    self.logger.warning(
                        "Huawei API authentication failed; falling back to GDPR export mode"
                    )
                    return True

            self.logger.error("Failed to obtain valid access token")
            return False

        except Exception as e:
            self.logger.error(f"Huawei connection failed: {e}")
            self.connected = False
            return False

    def _verify_token(self) -> bool:
        """
        Verify that access token is valid.

        Returns:
            True if token is valid
        """
        try:
            # Test token with a simple API call
            headers = {'Authorization': f'Bearer {self.access_token}'}
            response = self.session.get(
                f"{self.API_BASE}/user/profile",
                headers=headers,
                timeout=10
            )
            return response.status_code == 200
        except Exception as e:
            self.logger.debug(f"Token verification failed: {e}")
            return False

    def _refresh_access_token(self) -> bool:
        """
        Refresh OAuth2 access token using refresh token.

        Returns:
            True if refresh successful
        """
        try:
            data = {
                'grant_type': 'refresh_token',
                'client_id': self.client_id,
                'client_secret': self.client_secret,
                'refresh_token': self.refresh_token
            }

            response = requests.post(self.TOKEN_URL, data=data, timeout=10)

            if response.status_code == 200:
                token_data = response.json()
                self.access_token = token_data.get('access_token')

                # Update refresh token if provided
                if 'refresh_token' in token_data:
                    self.refresh_token = token_data['refresh_token']

                self.logger.info("Access token refreshed successfully")
                return True
            else:
                self.logger.error(f"Token refresh failed: {response.status_code} - {response.text}")
                return False

        except Exception as e:
            self.logger.error(f"Token refresh error: {e}")
            return False

    def fetch_data(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[PhysioRecord]:
        """
        Fetch physiological data from Huawei Health Kit.

        Args:
            start_time: Start of time range (UTC). If None, fetches last 7 days.
            end_time: End of time range (UTC). If None, uses current time.

        Returns:
            List of PhysioRecord objects

        Raises:
            ConnectionError: If not connected to Huawei
            ValueError: If time range invalid
        """
        # GDPR-only mode always reads from export files.
        if self.mode == 'gdpr':
            return self._fetch_from_gdpr_export(start_time, end_time)

        # Backward-compatible fallback behavior for hybrid configs.
        if not self.connected and self.use_fallback:
            return self._fetch_from_gdpr_export(start_time, end_time)

        self._ensure_connected()
        self._validate_time_range(start_time, end_time)

        # Default to last 7 days if not specified
        if end_time is None:
            end_time = datetime.utcnow()
        if start_time is None:
            start_time = end_time - timedelta(days=7)

        self.logger.info(f"Fetching Huawei data from {start_time} to {end_time}")

        records = []
        data_types = ['heart_rate', 'hrv', 'stress', 'sleep', 'spo2', 'steps', 'blood_pressure']

        try:
            for data_type in data_types:
                try:
                    raw_data = self._fetch_data_type(data_type, start_time, end_time)
                    records.extend(self._parse_huawei_data(raw_data, data_type))
                except Exception as e:
                    self.logger.error(f"Error fetching {data_type}: {e}")
        except Exception as e:
            if self.mode == 'hybrid' and self.use_fallback:
                self.logger.warning(
                    f"Huawei API fetch failed ({e}); switching to GDPR export fallback"
                )
                return self._fetch_from_gdpr_export(start_time, end_time)
            raise

        # Hybrid fallback if API returned nothing in-range.
        if not records and self.mode == 'hybrid' and self.use_fallback:
            self.logger.info("No Huawei API records found; trying GDPR export fallback")
            return self._fetch_from_gdpr_export(start_time, end_time)

        self.logger.info(f"Fetched {len(records)} records from Huawei")
        return records

    def _fetch_data_type(
        self,
        data_type: str,
        start_time: datetime,
        end_time: datetime
    ) -> Dict:
        """
        Query specific data type from Huawei Health Kit API.

        Args:
            data_type: Data type key (e.g., 'heart_rate')
            start_time: Start time (UTC)
            end_time: End time (UTC)

        Returns:
            API response data
        """
        huawei_data_type = self.DATA_TYPE_MAPPING.get(data_type)
        if not huawei_data_type:
            raise ValueError(f"Unknown data type: {data_type}")

        headers = {'Authorization': f'Bearer {self.access_token}'}

        # Huawei API expects milliseconds since epoch
        start_ms = int(start_time.timestamp() * 1000)
        end_ms = int(end_time.timestamp() * 1000)

        payload = {
            'dataType': huawei_data_type,
            'startTime': start_ms,
            'endTime': end_ms
        }

        response = self.session.post(
            f"{self.API_BASE}/sampleSet/query",
            headers=headers,
            json=payload,
            timeout=30
        )

        if response.status_code == 401:
            # Token expired, try to refresh
            if self._refresh_access_token():
                # Retry with new token
                return self._fetch_data_type(data_type, start_time, end_time)
            raise ConnectionError("Authentication failed")

        if response.status_code != 200:
            raise Exception(f"API error: {response.status_code} - {response.text}")

        return response.json()

    def _parse_huawei_data(self, raw_data: Dict, data_type: str) -> List[PhysioRecord]:
        """
        Parse Huawei API response into PhysioRecords.

        Args:
            raw_data: Raw API response
            data_type: Data type key

        Returns:
            List of PhysioRecord objects
        """
        records = []

        if not raw_data or 'sampleSet' not in raw_data:
            return records

        for sample in raw_data['sampleSet']:
            try:
                # Extract timestamp (milliseconds)
                start_ms = sample.get('startTime')
                if not start_ms:
                    continue

                timestamp = datetime.utcfromtimestamp(start_ms / 1000.0)

                # Parse based on data type
                if data_type == 'heart_rate':
                    value = sample.get('heartRate', {}).get('value')
                    if value and value > 0:
                        records.append(PhysioRecord(
                            timestamp_utc=timestamp,
                            source_device="Huawei_Watch",
                            data_type=DataType.HR,
                            value=float(value),
                            unit='bpm',
                            confidence=1.0
                        ))

                elif data_type == 'hrv':
                    value = sample.get('hrv', {}).get('value')
                    if value and value > 0:
                        records.append(PhysioRecord(
                            timestamp_utc=timestamp,
                            source_device="Huawei_Watch",
                            data_type=DataType.HRV,
                            value=float(value),
                            unit='ms',
                            confidence=1.0
                        ))

                elif data_type == 'stress':
                    value = sample.get('stress', {}).get('score')
                    if value is not None and value >= 0:
                        records.append(PhysioRecord(
                            timestamp_utc=timestamp,
                            source_device="Huawei_Watch",
                            data_type=DataType.STRESS_SCORE,
                            value=float(value),
                            unit='score',
                            confidence=1.0
                        ))

                elif data_type == 'sleep':
                    stage = sample.get('sleep', {}).get('stage')
                    if stage:
                        # Map Huawei stages to standard
                        stage_mapping = {
                            1: 'awake',
                            2: 'light',
                            3: 'deep',
                            4: 'REM'
                        }
                        stage_name = stage_mapping.get(stage, 'unknown')

                        records.append(PhysioRecord(
                            timestamp_utc=timestamp,
                            source_device="Huawei_Watch",
                            data_type=DataType.SLEEP_STAGE,
                            value=0.0,
                            unit=stage_name,
                            confidence=1.0
                        ))

                elif data_type == 'spo2':
                    value = sample.get('spo2', {}).get('value')
                    if value and 0 < value <= 100:
                        records.append(PhysioRecord(
                            timestamp_utc=timestamp,
                            source_device="Huawei_Watch",
                            data_type=DataType.SPO2,
                            value=float(value),
                            unit='%',
                            confidence=1.0
                        ))

                elif data_type == 'steps':
                    value = sample.get('steps', {}).get('delta')
                    if value and value > 0:
                        records.append(PhysioRecord(
                            timestamp_utc=timestamp,
                            source_device="Huawei_Watch",
                            data_type=DataType.STEPS,
                            value=float(value),
                            unit='steps',
                            confidence=1.0
                        ))

                elif data_type == 'blood_pressure':
                    systolic = sample.get('bloodPressure', {}).get('systolic')
                    diastolic = sample.get('bloodPressure', {}).get('diastolic')

                    if systolic and systolic > 0:
                        records.append(PhysioRecord(
                            timestamp_utc=timestamp,
                            source_device="Huawei_Watch",
                            data_type=DataType.BLOOD_PRESSURE_SYS,
                            value=float(systolic),
                            unit='mmHg',
                            confidence=1.0
                        ))

                    if diastolic and diastolic > 0:
                        records.append(PhysioRecord(
                            timestamp_utc=timestamp,
                            source_device="Huawei_Watch",
                            data_type=DataType.BLOOD_PRESSURE_DIA,
                            value=float(diastolic),
                            unit='mmHg',
                            confidence=1.0
                        ))

            except Exception as e:
                self.logger.debug(f"Skipped invalid {data_type} sample: {e}")

        return records

    def _fetch_from_gdpr_export(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None
    ) -> List[PhysioRecord]:
        """
        Fetch data from GDPR export as fallback.

        Args:
            start_time: Start of time range (UTC)
            end_time: End of time range (UTC)

        Returns:
            List of PhysioRecord objects
        """
        if not self.gdpr_export_path:
            raise ValueError("GDPR export path not configured")

        self.logger.info(f"Fetching from GDPR export: {self.gdpr_export_path}")

        parser = HuaweiGDPRParser()
        all_records = parser.parse_export(Path(self.gdpr_export_path))

        # Filter by time range if specified
        if start_time or end_time:
            filtered = []
            for record in all_records:
                # Ensure naive datetime comparison
                record_time = record.timestamp_utc.replace(tzinfo=None) if record.timestamp_utc.tzinfo else record.timestamp_utc
                start = start_time.replace(tzinfo=None) if start_time and start_time.tzinfo else start_time
                end = end_time.replace(tzinfo=None) if end_time and end_time.tzinfo else end_time

                if start and record_time < start:
                    continue
                if end and record_time > end:
                    continue
                filtered.append(record)
            return filtered

        return all_records

    def disconnect(self) -> None:
        """Close Huawei Health Kit session."""
        if self.session:
            self.session.close()
            self.session = None
        self.connected = False
        self.logger.info("Disconnected from Huawei Health Kit")


class HuaweiGDPRParser:
    """
    Parser for Huawei GDPR data export.

    Huawei allows users to export their health data through GDPR requests.
    This parser extracts data from the export JSON files.
    """

    def __init__(self):
        self.logger = logging.getLogger("physio_std.HuaweiGDPRParser")

    def parse_export(self, export_path: Path) -> List[PhysioRecord]:
        """
        Parse GDPR export directory.

        Args:
            export_path: Path to export directory

        Returns:
            List of PhysioRecord objects
        """
        if not export_path.exists():
            raise ValueError(f"Export path does not exist: {export_path}")

        records = []

        # Look for JSON files in export
        for json_file in export_path.rglob("*.json"):
            try:
                with open(json_file) as f:
                    data = json.load(f)

                # Determine file type and parse accordingly
                if 'heart_rate' in json_file.name.lower():
                    records.extend(self._parse_heart_rate(data))
                elif 'hrv' in json_file.name.lower():
                    records.extend(self._parse_hrv(data))
                elif 'stress' in json_file.name.lower():
                    records.extend(self._parse_stress(data))
                elif 'sleep' in json_file.name.lower():
                    records.extend(self._parse_sleep(data))
                elif 'spo2' in json_file.name.lower():
                    records.extend(self._parse_spo2(data))
                elif 'step' in json_file.name.lower():
                    records.extend(self._parse_steps(data))

            except Exception as e:
                self.logger.warning(f"Failed to parse {json_file.name}: {e}")

        self.logger.info(f"Parsed {len(records)} records from GDPR export")
        return records

    def _parse_heart_rate(self, data: Dict) -> List[PhysioRecord]:
        """Parse heart rate data from GDPR export."""
        records = []
        for entry in data.get('data', []):
            try:
                timestamp = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
                value = entry.get('value')

                if value and value > 0:
                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device="Huawei_GDPR",
                        data_type=DataType.HR,
                        value=float(value),
                        unit='bpm',
                        confidence=0.9  # Slightly lower confidence for export data
                    ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid HR entry: {e}")
        return records

    def _parse_hrv(self, data: Dict) -> List[PhysioRecord]:
        """Parse HRV data from GDPR export."""
        records = []
        for entry in data.get('data', []):
            try:
                timestamp = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
                value = entry.get('value')

                if value and value > 0:
                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device="Huawei_GDPR",
                        data_type=DataType.HRV,
                        value=float(value),
                        unit='ms',
                        confidence=0.9
                    ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid HRV entry: {e}")
        return records

    def _parse_stress(self, data: Dict) -> List[PhysioRecord]:
        """Parse stress data from GDPR export."""
        records = []
        for entry in data.get('data', []):
            try:
                timestamp = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
                value = entry.get('score')

                if value is not None and value >= 0:
                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device="Huawei_GDPR",
                        data_type=DataType.STRESS_SCORE,
                        value=float(value),
                        unit='score',
                        confidence=0.9
                    ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid stress entry: {e}")
        return records

    def _parse_sleep(self, data: Dict) -> List[PhysioRecord]:
        """Parse sleep data from GDPR export."""
        records = []
        for entry in data.get('data', []):
            try:
                timestamp = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
                stage = entry.get('stage')

                if stage:
                    stage_mapping = {
                        'awake': 'awake',
                        'light': 'light',
                        'deep': 'deep',
                        'rem': 'REM'
                    }
                    stage_name = stage_mapping.get(stage.lower(), stage)

                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device="Huawei_GDPR",
                        data_type=DataType.SLEEP_STAGE,
                        value=0.0,
                        unit=stage_name,
                        confidence=0.9
                    ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid sleep entry: {e}")
        return records

    def _parse_spo2(self, data: Dict) -> List[PhysioRecord]:
        """Parse SpO2 data from GDPR export."""
        records = []
        for entry in data.get('data', []):
            try:
                timestamp = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
                value = entry.get('value')

                if value and 0 < value <= 100:
                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device="Huawei_GDPR",
                        data_type=DataType.SPO2,
                        value=float(value),
                        unit='%',
                        confidence=0.9
                    ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid SpO2 entry: {e}")
        return records

    def _parse_steps(self, data: Dict) -> List[PhysioRecord]:
        """Parse steps data from GDPR export."""
        records = []
        for entry in data.get('data', []):
            try:
                timestamp = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
                value = entry.get('count')

                if value and value > 0:
                    records.append(PhysioRecord(
                        timestamp_utc=timestamp,
                        source_device="Huawei_GDPR",
                        data_type=DataType.STEPS,
                        value=float(value),
                        unit='steps',
                        confidence=0.9
                    ))
            except Exception as e:
                self.logger.debug(f"Skipped invalid steps entry: {e}")
        return records
