"""Core protocol and schema types for physio_std standalone library."""

from dataclasses import dataclass
from datetime import datetime
from enum import Enum
from typing import List, Optional, Protocol
import pandas as pd


class DataType(Enum):
    """Standardized physiological data types."""

    HR = "heart_rate"
    HRV = "hrv"
    SLEEP_STAGE = "sleep_stage"
    STRESS_SCORE = "stress_score"
    STEPS = "steps"
    TEMPERATURE = "temperature"
    SPO2 = "spo2"
    RESPIRATORY_RATE = "respiratory_rate"
    BLOOD_PRESSURE_SYS = "blood_pressure_systolic"
    BLOOD_PRESSURE_DIA = "blood_pressure_diastolic"
    ENERGY = "energy"
    ACTIVITY_TYPE = "activity_type"


@dataclass
class PhysioRecord:
    """Standardized physiological data record."""

    timestamp_utc: datetime
    source_device: str
    data_type: DataType
    value: float
    unit: str
    confidence: float

    def __post_init__(self):
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError(f"Confidence must be 0.0-1.0, got {self.confidence}")
        if not isinstance(self.data_type, DataType):
            raise TypeError(f"data_type must be DataType enum, got {type(self.data_type)}")


class PhysioProviderProtocol(Protocol):
    """Protocol for physiological data providers."""

    def connect(self) -> bool:
        ...

    def fetch_data(
        self,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ) -> List[PhysioRecord]:
        ...

    def disconnect(self) -> None:
        ...


class PhysioStandardizerProtocol(Protocol):
    """Protocol for PhysioRecord standardization and export."""

    def standardize(self, raw_data: List[dict]) -> List[PhysioRecord]:
        ...

    def to_dataframe(self, records: List[PhysioRecord]) -> pd.DataFrame:
        ...

    def to_excel(self, records: List[PhysioRecord], filepath: str) -> None:
        ...
