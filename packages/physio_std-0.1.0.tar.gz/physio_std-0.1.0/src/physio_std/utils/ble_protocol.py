"""
BLE packet framing utilities for Lifesense devices.

Handles 20-byte frame construction/parsing with CRC32 verification.
Reusable for any Lifesense BLE device (smart ring, watch, etc.).
"""

import struct
import logging
from typing import List, Optional

from .crc import ls_crc32

log = logging.getLogger(__name__)

MAX_FRAME_SIZE = 20  # BLE ATT MTU payload


def build_app_packet(payload: bytes, seq: int = 0x8000) -> List[bytes]:
    """
    Build framed BLE packet(s) from a payload.

    Args:
        payload: Command data (command_version + command_data, without CRC)
        seq: Packet sequence number (default: 0x8000, bit15=1 for new packet)

    Returns:
        List of 20-byte frames ready to write via BLE

    Frame structure:
    - First frame: seq(2) + length(1) + frame_no(1) + data[0:16]
    - Subsequent frames: frame_no(1) + data[n:n+19]
    """
    # Append CRC32 to payload
    full = payload + struct.pack('>I', ls_crc32(payload))
    data_len = len(full)

    frames = []

    # First frame: seq(2) + length(1) + frame_no(1) + up to 16 bytes data
    frame1 = struct.pack('>HBB', seq | 0x8000, data_len, 1) + full[:16]
    frame1 = frame1.ljust(MAX_FRAME_SIZE, b'\x00')
    frames.append(frame1[:MAX_FRAME_SIZE])

    offset = 16
    frame_no = 2
    while offset < len(full):
        chunk = full[offset:offset + 19]
        frame = struct.pack('B', frame_no) + chunk
        frame = frame.ljust(MAX_FRAME_SIZE, b'\x00')
        frames.append(frame[:MAX_FRAME_SIZE])
        offset += 19
        frame_no += 1

    return frames


def parse_incoming_frames(frames: List[bytes]) -> Optional[bytes]:
    """
    Reassemble incoming frames into raw payload.

    Args:
        frames: List of 20-byte frames received from device

    Returns:
        Complete payload (cmd_version + data + crc32) or None if incomplete

    Raises:
        ValueError: If frame format invalid
    """
    if not frames:
        return None

    first = frames[0]
    if len(first) < 4:
        raise ValueError(f"Invalid first frame length: {len(first)}")

    seq = struct.unpack('>H', first[0:2])[0]
    if not (seq & 0x8000):
        log.debug(f"Invalid seq (bit15 not set): 0x{seq:04X}")
        return None

    pkt_len = first[2]
    # frame_no = first[3]  # should be 1
    buf = bytearray(first[4:])

    for f in frames[1:]:
        # f[0] is frame_no
        buf.extend(f[1:])

    # Check if we have collected enough bytes
    if len(buf) < pkt_len:
        log.debug(f"Incomplete packet: have {len(buf)} bytes, need {pkt_len} bytes")
        return None

    payload = bytes(buf[:pkt_len])
    return payload


def verify_packet(payload: bytes) -> bool:
    """
    Verify CRC32 of a reassembled payload.

    Args:
        payload: Complete payload (cmd_version + data + crc32)

    Returns:
        True if CRC valid, False otherwise
    """
    if len(payload) < 6:  # minimum: 2 cmd_ver + 1 byte data + 4 CRC
        log.warning(f"Payload too short for CRC check: {len(payload)} bytes")
        return False

    data_part = payload[:-4]
    expected_crc = struct.unpack('>I', payload[-4:])[0]
    computed_crc = ls_crc32(data_part)
    is_valid = computed_crc == expected_crc

    if not is_valid:
        log.warning(f"CRC mismatch: expected 0x{expected_crc:08X}, computed 0x{computed_crc:08X}")

    return is_valid
