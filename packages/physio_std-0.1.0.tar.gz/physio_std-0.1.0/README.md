# physio-std (Module 1.2)

Standalone Python library for wearable physiological data ingestion, normalization, and alignment.

## Features

- Multi-provider support: Garmin, Huawei, Lifesense Ring, Mock provider
- Standard schema (`PhysioRecord`, `DataType`)
- 1-minute unified alignment for Garmin/Huawei (`UnifiedPhysioProcessor`)
- CSV/XLSX export
- Optional SQLite persistence and long-term analytics commands

## Install / Build (standalone)

### Option A: Build isolated standalone workspace (recommended)

```bash
python scripts/build_physio_std_package.py
python scripts/verify_physio_std_standalone.py
cd .build/physio_std_pkg
python -m build
```

Artifacts will be generated under `.build/physio_std_pkg/dist/`.

### Option B: Build via setup script in monorepo root

```bash
python setup_physio_std.py sdist bdist_wheel
```

### Local editable install (for development)

```bash
pip install -e .
```

## CLI

```bash
physio-std --help
physio-std add-device <device_id>
physio-std sync --unified --days 1
physio-std init-db
physio-std db-status
physio-std db-export --user-id <user_id>
physio-std db-analyze --user-id <user_id>
```

## Standalone smoke checks

After installing built wheel in a clean environment:

```bash
physio-std --help
physio-std init-db
physio-std db-status
```

## Standalone migration notes

Canonical protocol types live in `physio_std.protocols`.
The legacy `src.interfaces.physio_protocol` now re-exports these types for compatibility.
