"""
pg2md — Page to Markdown converter with JS rendering support.

A fast, clean HTML-to-Markdown converter that uses Playwright for
JavaScript rendering and html-to-markdown (Rust-based) for conversion.

Example:
    from pg2md import PageParser, BrowserConfig, ProxyConfig, UserAgents

    parser = PageParser(with_image=False, with_link=True)
    markdown = parser.parse("https://example.com")
    print(markdown)

    # With proxy
    proxy = ProxyConfig(server="socks5://1.2.3.4:1080")
    markdown = parser.parse("https://example.com", proxy=proxy)
"""

from pg2md.parser import (
    PageParser,
    BrowserConfig,
    ProxyConfig,
    UserAgents,
    HtmlCleaner,
    MarkdownCleaner,
)

__version__ = "1.0.0"
__author__ = "Your Name"
__all__ = [
    "PageParser",
    "BrowserConfig",
    "ProxyConfig",
    "UserAgents",
    "HtmlCleaner",
    "MarkdownCleaner",
    "__version__",
]
