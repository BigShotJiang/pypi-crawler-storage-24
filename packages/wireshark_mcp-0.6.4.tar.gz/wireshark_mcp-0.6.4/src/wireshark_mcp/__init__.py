"""
Wireshark MCP - A Model Context Protocol server for Wireshark.
"""

__version__ = "0.6.4"
