# Project Export Feature

## Overview
Added the ability to export complete project data including tickets and optionally job execution logs through a simple export button in each project card.

## Implementation Details

### Backend Changes
- **New API Endpoint**: `GET /dashboard/projects/{project_id}/export`
  - Exports project details, all associated tickets, and optionally job logs
  - Query parameter: `include_logs` (default: true)
  - Returns structured JSON with project data, tickets array, and metadata

### Frontend Changes
- **New Component**: `ProjectExport.jsx` in `src/proxym/dashboard/components/shared/`
  - Provides export button with dropdown menu
  - Options: Download JSON, Copy to Clipboard
  - Toggle for including/excluding job logs
  - Shows loading state during export

- **Updated Component**: `projects.jsx`
  - Added ProjectExport button to each project card
  - Positioned next to the "Show/Hide tickets" button

- **Updated HTML**: `frontend/dashboard.html`
  - Added script tag to load the new ProjectExport component

## Usage
1. Navigate to the Projects tab in the dashboard
2. Each project card now has an "Export" button 📦
3. Click the button to open the export menu
4. Choose whether to include job logs (checkbox)
5. Click "Download JSON" or "Copy to Clipboard"

## Export Data Structure
```json
{
  "project": { ... },           // Full project details
  "tickets": [                  // Array of all tickets in the project
    {
      ...ticket fields...,
      "jobs": [...]             // Job execution logs (if included)
    }
  ],
  "exported_at": "ISO timestamp",
  "include_logs": true,
  "ticket_count": 0
}
```

## Benefits
- Quick backup of project data
- Easy sharing of project state
- Debugging tool for reviewing ticket history
- Offline analysis capability
