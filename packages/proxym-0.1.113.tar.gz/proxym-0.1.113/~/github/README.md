# Simple Calculator

This project is a simple calculator that can perform basic arithmetic operations: addition, subtraction, multiplication, and division.

## Features

- `add(a, b)`: Returns the sum of a and b.
- `subtract(a, b)`: Returns the difference of a and b.
- `multiply(a, b)`: Returns the product of a and b.
- `divide(a, b)`: Returns the quotient of a and b. Raises ValueError on division by zero.

## Testing

To run the tests, use the following command:

