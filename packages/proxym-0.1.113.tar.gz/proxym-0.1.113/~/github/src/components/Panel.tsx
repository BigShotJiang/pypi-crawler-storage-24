import React from 'react';

interface PanelProps {
  title: string;
  content: React.ReactNode;
  onClose: () => void;
}

const Panel: React.FC<PanelProps> = ({ title, content, onClose }) => {
  return (
    <div className="panel">
      <div className="panel-header">
        <h2>{title}</h2>
        <button onClick={onClose} className="close-button">
          &times;
        </button>
      </div>
      <div className="panel-content">
        {content}
      </div>
    </div>
  );
};

export default Panel;
