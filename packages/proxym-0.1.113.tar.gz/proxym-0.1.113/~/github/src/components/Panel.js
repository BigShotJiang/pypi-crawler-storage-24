import React from 'react';
import './Panel.css';

const PanelTitle = ({ title }) => {
    return <h2 className="panel-title">{title}</h2>;
};

const PanelContent = ({ content }) => {
    return <div className="panel-content">{content}</div>;
};

const Panel = ({ title, content }) => {
    return (
        <div className="panel">
            <PanelTitle title={title} />
            <PanelContent content={content} />
        </div>
    );
};

export default Panel;
