import React from 'react';
import { render, screen } from '@testing-library/react';
import Panel from './Panel';

test('renders panel with title and content', () => {
    render(<Panel title="Test Title" content="This is the content." />);
    const titleElement = screen.getByText(/Test Title/i);
    const contentElement = screen.getByText(/This is the content./i);
    expect(titleElement).toBeInTheDocument();
    expect(contentElement).toBeInTheDocument();
});
