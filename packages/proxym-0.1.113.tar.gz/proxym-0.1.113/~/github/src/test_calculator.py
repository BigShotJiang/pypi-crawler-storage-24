import unittest
from calculator import add, subtract, multiply, divide, calculate

class TestCalculator(unittest.TestCase):

    def test_add(self):
        self.assertEqual(add(1, 2), 3)

    def test_subtract(self):
        self.assertEqual(subtract(5, 3), 2)

    def test_multiply(self):
        self.assertEqual(multiply(3, 4), 12)

    def test_divide(self):
        self.assertEqual(divide(10, 2), 5)
        with self.assertRaises(ValueError):
            divide(10, 0)

    def test_calculate(self):
        self.assertEqual(calculate('add', 1, 2), 3)
        self.assertEqual(calculate('subtract', 5, 3), 2)
        self.assertEqual(calculate('multiply', 3, 4), 12)
        self.assertEqual(calculate('divide', 10, 2), 5)
        with self.assertRaises(ValueError):
            calculate('divide', 10, 0)
        with self.assertRaises(ValueError):
            calculate('unknown', 10, 2)

if __name__ == '__main__':
    unittest.main()
