# Proxym Example: Simple 3-Ticket Workflow

The simplest possible proxym example — create 3 tickets, dispatch each to an
AI tool, and analyze the results sequentially.

No scaffolding, no templates — just pure CLI commands.

## Quick Start

```bash
# 1. Start proxym
proxym serve &

# 2. Run the example
bash examples/simple-3-tickets/run.sh

# 3. Check results
proxym board
proxym analyze <TKT-ID>
```

## What It Does

1. Registers an existing project directory
2. Creates 3 tickets (one at a time):
   - **Ticket 1**: Create a Python utility module
   - **Ticket 2**: Add unit tests for the module
   - **Ticket 3**: Add a CLI entry point
3. Dispatches each ticket to an AI tool
4. After each dispatch, runs `proxym analyze` to verify completion
5. Shows the final board

## CLI Commands Used

```bash
proxym status                              # check server
proxym project add <path> --name X         # register project
proxym ticket add "task" -p X -t tool      # create ticket
proxym tools dispatch --ticket T --tool Y  # dispatch
proxym analyze <TKT-ID>                    # check result
proxym board                               # kanban view
```

## Options

```bash
bash examples/simple-3-tickets/run.sh [OPTIONS]

  --project-dir PATH   Project directory (default: ~/projects/simple-demo)
  --tool NAME          AI tool (default: aider)
  --proxy URL          Proxym URL (default: http://localhost:4000)
  --dry-run            Show plan only
```

## Manual Walkthrough

You can run the same steps manually in your terminal:

```bash
# Setup
proxym serve &
mkdir -p ~/projects/simple-demo
proxym project add ~/projects/simple-demo --name simple-demo --tool aider

# Ticket 1: utility module
proxym ticket add "Create utils.py with string helpers: slugify, truncate, snake_case" \
  -p simple-demo -t aider --priority high --type feature

# Ticket 2: tests
proxym ticket add "Write tests for utils.py using pytest" \
  -p simple-demo -t aider --priority high --type test

# Ticket 3: CLI
proxym ticket add "Add cli.py entry point using argparse that exposes utils functions" \
  -p simple-demo -t aider --priority medium --type feature

# Check what we created
proxym board

# Dispatch ticket 1 and analyze
proxym tools dispatch --ticket TKT-XXXXXX --tool aider
# ... wait for completion ...
proxym analyze TKT-XXXXXX

# Repeat for tickets 2 and 3
```
