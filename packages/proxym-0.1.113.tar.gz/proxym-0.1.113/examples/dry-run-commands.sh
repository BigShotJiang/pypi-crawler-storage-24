#!/usr/bin/env bash
###############################################################################
# dry-run-commands.sh — Comprehensive CLI Dry-Run Verification
#
# Tests individual proxym CLI commands that are used across all examples
# to ensure the CLI interface works correctly.
#
# Usage:
#   bash examples/dry-run-commands.sh           # test all commands
#   bash examples/dry-run-commands.sh --list  # list commands only
###############################################################################
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROXYM_URL="${PROXYM_URL:-http://localhost:4000}"
CLI="proxym --proxy $PROXYM_URL"
LIST_ONLY=false
FAILED=0
PASSED=0

# ── Colors ─────────────────────────────────────────────────────────────────
GREEN='\033[0;32m'; RED='\033[0;31m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; DIM='\033[2m'; RESET='\033[0m'

_ok()   { echo -e "${GREEN}✓${RESET} $1"; }
_fail() { echo -e "${RED}✗${RESET} $1"; }
_info() { echo -e "${DIM}$1${RESET}"; }

# ── Parse arguments ────────────────────────────────────────────────────────

while [[ $# -gt 0 ]]; do
  case "$1" in
    --list|-l)     LIST_ONLY=true; shift ;;
    --help|-h)     sed -n '2,/^###/p' "$0" | head -n -1 | sed 's/^# \?//'; exit 0 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
done

# ── Commands used in examples ─────────────────────────────────────────────

declare -a COMMANDS=(
  # Basic status/info commands
  "status|Check server status|simple-3-tickets,multi-project,todo-app-ts"
  "tools list|List available tools|simple-3-tickets,multi-project,todo-app-ts"

  # Project management
  "project list|List registered projects|simple-3-tickets,multi-project,todo-app-ts"
  "project show <name>|Show project details|multi-project,todo-app-ts"

  # Ticket management
  "ticket list|List all tickets|simple-3-tickets,multi-project,todo-app-ts"
  "ticket list --project <name>|List project tickets|multi-project,todo-app-ts"
  "ticket show <id>|Show ticket details|simple-3-tickets,multi-project,todo-app-ts"
  "ticket add 'test' -p <name> -t aider|Create ticket (dry-run would skip)|all"

  # Sprint management
  "sprint list|List all sprints|multi-project,todo-app-ts"
  "sprint show <id>|Show sprint details|multi-project"

  # Job queue
  "q|Quick queue status|simple-3-tickets,multi-project,todo-app-ts"
  "jobs|List job history|todo-app-ts"

  # Board view
  "board|Kanban board view|simple-3-tickets,multi-project,todo-app-ts"
)

# ── List mode ──────────────────────────────────────────────────────────────

if $LIST_ONLY; then
  echo -e "${BOLD}${CYAN}Commands Used Across Examples${RESET}\n"
  echo "The following proxym CLI commands are exercised by the examples:"
  echo ""

  for entry in "${COMMANDS[@]}"; do
    IFS='|' read -r cmd desc examples <<< "$entry"
    echo -e "  ${BOLD}$cmd${RESET}"
    echo -e "    ${DIM}Description:${RESET} $desc"
    echo -e "    ${DIM}Examples:${RESET} $examples"
    echo ""
  done

  echo -e "${DIM}Run without --list to test these commands against a running server${RESET}"
  exit 0
fi

# ── Test commands ──────────────────────────────────────────────────────────

echo -e "${BOLD}${CYAN}Testing proxym CLI Commands${RESET}"
echo ""

test_command() {
  local cmd="$1"
  local desc="$2"

  # Skip commands that require IDs/arguments we don't have
  if [[ "$cmd" == *"<"* ]]; then
    _info "[SKIP] $cmd (requires arguments)"
    return 0
  fi

  printf "  Testing %-40s " "$cmd"
  if $CLI $cmd >/dev/null 2>&1; then
    echo -e "${GREEN}✓${RESET}"
    ((PASSED++))
  else
    echo -e "${RED}✗${RESET}"
    ((FAILED++))
  fi
}

echo "Server Commands:"
test_command "status" "Check server status"
test_command "version" "Show version"

echo ""
echo "Tool Commands:"
test_command "tools list" "List tools"

echo ""
echo "Project Commands:"
test_command "project list" "List projects"

echo ""
echo "Ticket Commands:"
test_command "ticket list" "List tickets"
test_command "board" "Show kanban board"
test_command "q" "Show queue status"
test_command "jobs" "Show jobs"

echo ""
echo "Sprint Commands:"
test_command "sprint list" "List sprints"

# ── Summary ─────────────────────────────────────────────────────────────────

echo ""
echo -e "${BOLD}╔════════════════════════════════════════════════════════════╗${RESET}"
echo -e "${BOLD}║              CLI Command Test Summary                       ║${RESET}"
echo -e "${BOLD}╠════════════════════════════════════════════════════════════╣${RESET}"
echo -e "${BOLD}║${RESET}  Commands tested: $((PASSED + FAILED))"
echo -e "${BOLD}║${RESET}  ${GREEN}Passed: $PASSED${RESET}"
if [[ $FAILED -gt 0 ]]; then
  echo -e "${BOLD}║${RESET}  ${RED}Failed: $FAILED${RESET}"
fi
echo -e "${BOLD}╚════════════════════════════════════════════════════════════╝${RESET}"

if [[ $FAILED -eq 0 ]]; then
  echo ""
  _ok "All CLI commands working!"
  exit 0
else
  echo ""
  _fail "$FAILED command(s) failed"
  exit 1
fi
