# Proxym Example: Multi-Project with Sprints

Manages **2 projects simultaneously**, each with its own sprint and 2 tickets.
Generated code lands in `examples/multi-project/src/<project>/`.

## Projects

| Project | Sprint | Tickets | Description |
|---------|--------|---------|-------------|
| calculator | Calculator MVP | 2 | Python calculator module + tests |
| greeter | Greeter MVP | 2 | Python greeter class + tests |

## Quick Start

```bash
# 1. Start proxym
proxym serve &

# 2. Run the example
bash examples/multi-project/run.sh

# 3. Check results per project
proxym ticket list --project calculator
proxym ticket list --project greeter
proxym sprint list
```

## What It Does

1. **Register** 2 projects with dirs inside `src/calculator/` and `src/greeter/`
2. **Create sprints** — one per project with goals
3. **Create tickets** — 2 per project (implementation + tests), assigned to sprints
4. **Dispatch** each ticket to an AI tool sequentially
5. **Analyze** each ticket after dispatch to verify completion
6. **Verify isolation** — `ticket list --project` filters correctly
7. **Show sprint status** — ticket counts, tools, progress

## Options

```bash
bash examples/multi-project/run.sh [OPTIONS]

  --tool NAME    AI tool (default: aider)
  --proxy URL    Proxym URL (default: http://localhost:4000)
  --dry-run      Show plan only
  --clean        Remove generated files from src/
```

## Generated File Structure

```text
examples/multi-project/
├── run.sh
├── README.md
└── src/
    ├── calculator/
    │   ├── calculator.py       # AI-generated
    │   └── test_calculator.py  # AI-generated
    └── greeter/
        ├── greeter.py          # AI-generated
        └── test_greeter.py     # AI-generated
```

## CLI Commands Used

```bash
proxym status                                  # check server
proxym project add <path> --name X --tool Y    # register project
proxym sprint create --name "..." --goal "..."  # create sprint
proxym ticket add "task" -p X -t Y --sprint S  # create ticket in sprint
proxym tools dispatch --ticket T --tool Y --project-dir D  # dispatch
proxym analyze <TKT-ID>                        # check result
proxym ticket list --project X                 # filter by project
proxym sprint list                             # all sprints
proxym sprint show <SPR-ID>                    # sprint details
proxym board                                   # kanban view
```
