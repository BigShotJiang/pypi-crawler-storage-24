# Greeter Module

This module provides a simple Greeter class that can greet users.

## Greeter Class

### Methods

- `hello()`: Returns a greeting message.
- `goodbye()`: Returns a farewell message.

### Usage

