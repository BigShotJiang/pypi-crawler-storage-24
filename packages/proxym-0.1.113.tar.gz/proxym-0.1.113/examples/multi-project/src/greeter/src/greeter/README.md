# Greeter Module

This module provides a simple Greeter class that can greet users.

## Greeter Class

### Methods

- `__init__(name: str)`: Initializes the Greeter with a name.
- `hello() -> str`: Returns a greeting message.
- `goodbye() -> str`: Returns a farewell message.

## Usage

