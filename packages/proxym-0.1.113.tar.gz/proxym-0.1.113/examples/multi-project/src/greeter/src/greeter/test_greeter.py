import unittest
from greeter import Greeter

class TestGreeter(unittest.TestCase):
    def setUp(self):
        self.greeter = Greeter("World")

    def test_hello(self):
        self.assertEqual(self.greeter.hello(), "Hello, World!")

    def test_goodbye(self):
        self.assertEqual(self.greeter.goodbye(), "Goodbye, World!")

if __name__ == '__main__':
    unittest.main()
