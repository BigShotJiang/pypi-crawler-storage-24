import pytest
from greeter import Greeter

def test_greeter_initialization():
    greeter = Greeter("Alice")
    assert greeter.name == "Alice"

def test_greeter_greet():
    greeter = Greeter("Bob")
    assert greeter.greet() == "Hello, Bob!"

def test_greeter_empty_name():
    greeter = Greeter("")
    assert greeter.greet() == "Hello, !"

def test_greeter_none_name():
    greeter = Greeter(None)
    assert greeter.greet() == "Hello, None!"

def test_greeter_numeric_name():
    greeter = Greeter(123)
    assert greeter.greet() == "Hello, 123!"

def test_greeter_special_characters():
    greeter = Greeter("@l!ce")
    assert greeter.greet() == "Hello, @l!ce!"

def test_greeter_long_name():
    long_name = "A" * 1000
    greeter = Greeter(long_name)
    assert greeter.greet() == f"Hello, {long_name}!"
