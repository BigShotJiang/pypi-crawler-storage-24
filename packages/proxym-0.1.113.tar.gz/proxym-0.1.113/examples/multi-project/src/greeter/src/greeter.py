class Greeter:
    def __init__(self, name: str):
        self.name = name

    def hello(self) -> str:
        return f"Hello, {self.name}!"

    def goodbye(self) -> str:
        return f"Goodbye, {self.name}!"
