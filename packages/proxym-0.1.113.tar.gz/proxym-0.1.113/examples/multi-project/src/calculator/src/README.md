# Calculator Module

This module provides basic arithmetic operations.

## Functions

- `add(a, b)`: Returns the sum of a and b.
- `subtract(a, b)`: Returns the difference of a and b.
- `multiply(a, b)`: Returns the product of a and b.
- `divide(a, b)`: Returns the quotient of a and b. Raises ValueError on division by zero.

## Testing

To run tests, use the following command:

