# Chat NLP Test Example

Demonstrates proxym's natural language processing (NLP) capabilities for CLI command generation.

## Features Tested

- **CLI Command Generation**: Convert natural language queries to proxym CLI commands
- **Interactive Chat Mode**: Chat with the system using natural language
- **Safe Execution**: Commands require confirmation before execution

## Usage

```bash
# Dry run - show what would be tested
bash examples/chat-nlp-test/run.sh --dry-run

# Full test with server
bash examples/chat-nlp-test/run.sh --proxy http://localhost:5001

# Interactive mode
bash examples/chat-nlp-test/run.sh --interactive
```

## Test Queries

The test suite includes queries like:
- `show system status` → generates `proxym status`
- `list all tickets` → generates `proxym ticket list`
- `show kanban board` → generates `proxym board`
- `create a ticket for fixing the bug` → generates `proxym ticket add "fixing the bug"`
- `dispatch ticket TKT-123 to aider` → generates `proxym dispatch TKT-123`

## How It Works

1. **Schema Generation**: `src/proxym/cli/_cli_schema.py` extracts all CLI commands
2. **NLP Processing**: LLM matches natural language to available commands
3. **Command Generation**: Returns the best matching CLI command with confidence score
4. **Safe Execution**: User confirmation before executing generated commands

## Files

- `run.sh` — Main test script
- `README.md` — This file
