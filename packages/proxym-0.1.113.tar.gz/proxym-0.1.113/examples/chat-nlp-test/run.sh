#!/usr/bin/env bash
#===============================================================================
# run.sh — Chat NLP Test Suite
# 
# Demonstrates proxym's natural language processing capabilities:
#   - CLI command generation from natural language
#   - Interactive chat mode with CLI assistance
#   - Safe command execution with confirmation
#
# Usage:
#   bash examples/chat-nlp-test/run.sh                    # full test
#   bash examples/chat-nlp-test/run.sh --dry-run        # plan only
#   bash examples/chat-nlp-test/run.sh --interactive    # interactive mode
#===============================================================================

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROXYM_URL="${PROXYM_URL:-${DEFAULT_PROXY_URL:-http://localhost:4000}}"
DRY_RUN=false
INTERACTIVE=false

# Colors
GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; BOLD='\033[1m'; RESET='\033[0m'

_hdr() { echo -e "\n${BOLD}${CYAN}═══ $1 ═══${RESET}"; }
_ok() { echo -e "  ${GREEN}✓${RESET} $1"; }
_warn() { echo -e "  ${YELLOW}⚠${RESET} $1"; }

# Parse arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        --dry-run) DRY_RUN=true; shift ;;
        --interactive) INTERACTIVE=true; shift ;;
        --proxy) PROXYM_URL="$2"; shift 2 ;;
        *) echo "Unknown option: $1"; exit 1 ;;
    esac
done

CLI="proxym --proxy $PROXYM_URL"

echo -e "${BOLD}🧪 Chat NLP Test Suite${RESET}"
echo "   Server: ${PROXYM_URL}"
echo ""

# Check server
_hdr "Step 1: Prerequisites"
if $DRY_RUN; then
    _ok "[dry-run] Would check server status"
else
    if ! $CLI status >/dev/null 2>&1; then
        _warn "Proxym server not reachable"
        exit 1
    fi
    _ok "Server is running"
fi

# Test 1: Simple CLI command generation
_hdr "Step 2: Test CLI Command Generation"

test_queries=(
    "show system status"
    "list all tickets"
    "show kanban board"
    "create a ticket for fixing the bug"
    "dispatch ticket TKT-123 to aider"
    "analyze my last ticket"
)

for query in "${test_queries[@]}"; do
    echo ""
    echo "  Query: \"$query\""
    if $DRY_RUN; then
        _ok "[dry-run] Would generate CLI command"
    else
        # Run with timeout and show result
        result=$(timeout 15 $CLI chat "$query" --cli-mode 2>&1 || true)
        if echo "$result" | grep -q "Generated Command"; then
            cmd=$(echo "$result" | grep -A1 "Generated Command" | tail -1)
            _ok "→ $cmd"
        elif echo "$result" | grep -q "I couldn't generate"; then
            _warn "No matching command found"
        else
            _warn "Timeout or error"
        fi
    fi
done

# Test 2: Interactive mode
if $INTERACTIVE; then
    _hdr "Step 3: Interactive Mode"
    echo "  Starting interactive chat session..."
    echo "  Type 'exit' to quit, 'cli:' prefix to generate commands"
    echo ""
    $CLI chat --cli-mode || true
fi

# Summary
_hdr "Test Complete"
echo ""
echo "  Tested ${#test_queries[@]} NLP queries"
echo ""
echo "  Next steps:"
echo "    - Try: proxym chat \"your question\" --cli-mode"
echo "    - Try: proxym chat --cli-mode  (interactive)"
echo ""
_ok "Done!"
