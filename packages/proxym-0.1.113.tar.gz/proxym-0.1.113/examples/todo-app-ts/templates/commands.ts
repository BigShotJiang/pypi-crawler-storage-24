/**
 * CLI Command handlers — business logic for each CLI action.
 *
 * Each exported function corresponds to a CLI command:
 *   addCommand, listCommand, showCommand, doneCommand,
 *   undoneCommand, editCommand, removeCommand, statsCommand, clearCommand
 *
 * @see spec.md for full requirements
 */
import { TodoStore } from './store.js';

// TODO: Implement command handlers
// This file will be completed by an AI tool via proxym ticket dispatch.

const store = new TodoStore();

export async function addCommand(title: string, opts: { priority?: string; description?: string }): Promise<void> {
  await store.load();
  store.create({ title, priority: (opts.priority as any) || 'medium', description: opts.description });
  await store.save();
  console.log(`Added: ${title}`);
}

export async function listCommand(): Promise<void> {
  await store.load();
  const todos = store.list();
  if (todos.length === 0) { console.log('No todos.'); return; }
  for (const t of todos) {
    console.log(`  ${t.done ? '✓' : '○'} [${t.priority}] ${t.title} (${t.id.slice(0, 8)})`);
  }
}

export async function statsCommand(): Promise<void> {
  await store.load();
  const s = store.stats();
  console.log(`Total: ${s.total}  Done: ${s.done}  Pending: ${s.pending}`);
}
