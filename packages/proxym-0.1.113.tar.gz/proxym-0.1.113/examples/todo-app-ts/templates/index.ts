/**
 * CLI entry point — Commander.js setup.
 *
 * Registers all commands: add, list, show, done, undone, edit, remove, stats, clear
 * Uses commander for argument parsing.
 *
 * @see spec.md for full requirements
 */

// TODO: Implement CLI entry point with Commander.js
// This file will be completed by an AI tool via proxym ticket dispatch.

import { Command } from 'commander';
import { addCommand, listCommand, statsCommand } from './commands.js';

const program = new Command();
program.name('todo').description('CLI TODO app').version('0.1.0');

program.command('add').description('Add a new todo').argument('<title>', 'Todo title')
  .option('-p, --priority <priority>', 'Priority (low/medium/high)', 'medium')
  .option('-d, --description <desc>', 'Description')
  .action(async (title: string, opts: any) => { await addCommand(title, opts); });

program.command('list').description('List all todos')
  .action(async () => { await listCommand(); });

program.command('stats').description('Show statistics')
  .action(async () => { await statsCommand(); });

program.parse();
