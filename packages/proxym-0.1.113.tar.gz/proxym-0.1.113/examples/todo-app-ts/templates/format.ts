/**
 * Output formatting helpers — colored terminal output.
 *
 * Functions:
 *   formatTodoRow(todo)   — single-line table row
 *   formatTodoDetail(todo) — multi-line detail view
 *   formatStats(stats)    — statistics summary
 *   colorPriority(p)      — color code for priority
 *   shortId(id)           — first 8 chars of UUID
 *
 * @see spec.md for full requirements
 */
import { Todo, TodoStats, Priority } from './types.js';

// TODO: Implement formatting functions
// This file will be completed by an AI tool via proxym ticket dispatch.

export function shortId(id: string): string { return id.slice(0, 8); }

export function colorPriority(p: Priority): string {
  const colors: Record<Priority, string> = { high: '\x1b[31m', medium: '\x1b[33m', low: '\x1b[32m' };
  return `${colors[p] || ''}${p}\x1b[0m`;
}

export function formatTodoRow(todo: Todo): string {
  const check = todo.done ? '✓' : '○';
  return `  ${check} [${colorPriority(todo.priority)}] ${todo.title} (${shortId(todo.id)})`;
}

export function formatStats(stats: TodoStats): string {
  return `Total: ${stats.total}  Done: ${stats.done}  Pending: ${stats.pending}`;
}
