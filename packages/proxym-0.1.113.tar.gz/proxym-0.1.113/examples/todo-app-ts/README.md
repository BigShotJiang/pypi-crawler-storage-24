# Proxym Example: TypeScript TODO App

End-to-end demonstration of automatic project generation using `proxym` CLI.
Creates a real TypeScript CLI application on disk, driven by proxym tickets
and AI tools.

## Quick Start

```bash
# 1. Start proxym server
proxym serve &

# 2. Run the example
bash examples/todo-app-ts/run.sh

# 3. Inspect results
proxym board                          # kanban board
proxym analyze <TKT-ID>              # check if ticket completed correctly
cd ~/projects/todo-app-ts && npm test # run the generated project
```

## What the Script Does

```
Phase 1 · Scaffold     → creates ~/projects/todo-app-ts/ with TypeScript stubs
Phase 2 · Register     → proxym project add (registers project in proxym)
Phase 3 · Tickets      → proxym sprint create + 7x proxym ticket add
Phase 4 · Dispatch     → proxym tools dispatch (sends each ticket to AI tool)
Phase 5 · Analyze      → proxym analyze (checks each ticket's result)
Phase 6 · Verify       → npm install, tsc, npm test, smoke test
```

## CLI Commands Used

The script uses **only `proxym` CLI** — no raw API calls:

```bash
proxym status                          # check server is running
proxym project add <path> --name X     # register project
proxym sprint create --name "..."      # create sprint
proxym ticket add "task" -p X -t tool  # create ticket with tool
proxym tools dispatch --ticket T --tool Y  # dispatch to AI
proxym analyze <TKT-ID>               # analyze ticket result
proxym board                           # kanban board view
proxym q                               # quick queue status
```

## Options

```bash
bash examples/todo-app-ts/run.sh [OPTIONS]

  --project-dir PATH   Where to create the project (default: ~/projects/todo-app-ts)
  --tool NAME          AI tool: aider, claude-code (default: aider)
  --proxy URL          Proxym server URL (default: http://localhost:4000)
  --dry-run            Show plan without executing
  --skip-dispatch      Create project & tickets, don't dispatch
  --clean              Remove existing project and start fresh
```

## Tickets Created

| # | Ticket | Type | Priority |
|---|--------|------|----------|
| 1 | Implement TodoStore (store.ts) | feature | high |
| 2 | Implement formatters (format.ts) | feature | medium |
| 3 | Implement CLI commands (commands.ts) | feature | high |
| 4 | Implement CLI entry (index.ts) | feature | high |
| 5 | Write store unit tests | test | high |
| 6 | Write integration tests | test | medium |
| 7 | Build & verify | task | critical |

## After the Run

```bash
# The project is a standalone Node.js app — works without proxym:
cd ~/projects/todo-app-ts
npm install && npm run build
node dist/index.js add "Hello world" --priority high
node dist/index.js list
node dist/index.js stats

# Check results in proxym:
proxym board                           # kanban board
proxym ticket list --project todo-app-ts  # all tickets
proxym analyze TKT-XXXXXX             # detailed result for one ticket
proxym jobs                            # job history
```

## Troubleshooting

```bash
# Server not running?
proxym serve &

# Tool not found? Falls back to LLM mode. Or install:
pip install aider-chat
npm install -g @anthropic/claude-code

# TypeScript errors? Check and fix:
proxym ticket list --status todo
proxym analyze TKT-XXXXXX
```

## Files

| File | Purpose |
|------|---------|
| `run.sh` | Main script (~350 lines, uses proxym CLI) |
| `spec.md` | Project specification for AI |
| `tickets.json` | Ticket definitions |
| `templates/` | TypeScript project template files |
| `verify.sh` | Standalone build verification |