# Comprehensive NLP Test Report

**Date:** Wed Mar 25 17:17:39 CET 2026
**Duration:** ~106 seconds

## Summary

| Metric | Count |
|--------|-------|
| **Total Tests** | 53 |
| **Passed** | 53 |
| **Failed** | 0 |
| **DSL Matches** | 48 |
| **LLM Errors** | 4 |
| **Pass Rate** | 100.0% |

## Coverage

### Queries Tested
- status, vms, tickets, board, sprints, projects
- models, providers, logs, costs, diagnose
- tools, jobs, queue

### Commands Tested
- Tickets: create (all variants), dispatch, assign, close, analyze
- Sprints: create, start, close, add ticket
- Projects: register, remove
- VMs: create, start, stop, restart, delete, snapshot, restore, switch
- Batch: dispatch all, run workflow

### Languages
- English (all commands)
- Polish (selected commands)

## Performance

### Slow Commands (>500ms)
- status query: 1081ms
- vms list: 681ms
- tickets list: 725ms
- board view: 705ms
- sprints list: 748ms
- projects list: 667ms
- models list: 623ms
- providers list: 710ms
- logs view: 662ms
- costs view: 639ms
- diagnose: 818ms
- tools list: 880ms
- jobs list: 865ms
- queue view: 772ms
- create typed ticket: 529ms
- create priority ticket: 541ms
- create full ticket: 517ms
- create ticket in project: 655ms
- dispatch ticket: 560ms
- assign ticket: 827ms
- close ticket: 557ms
- analyze ticket: 622ms
- utwórz ticket: 541ms
- register project: 529ms
- add project with tool: 525ms
- remove project: 643ms
- snapshot VM: 572ms
- restore VM: 653ms
- switch project: 643ms
- stwórz VM: 641ms
- run task: 639ms
- empty prompt: 572ms
- only spaces: 793ms
- special chars: 728ms
- very long task: 871ms
- unicode text: 901ms
- multiple spaces: 667ms

## Failures

**No failures!** ✅

## DSL Schema Coverage

- **Version:** 2.0
- **Queries:** 0
N/A
- **Commands:** 0
N/A

## Recommendations

✅ All tests passing! NLP commands are fully functional.
