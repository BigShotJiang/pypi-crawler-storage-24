#!/usr/bin/env python3
"""
NLP Performance Benchmark
Measures DSL matching speed and generates optimization recommendations.
"""

import time
import subprocess
import statistics
from typing import List, Tuple


def run_benchmark(commands: List[str], iterations: int = 5) -> List[Tuple[str, float]]:
    """Benchmark NLP command generation speed."""
    results = []
    
    for cmd in commands:
        times = []
        for _ in range(iterations):
            start = time.time()
            result = subprocess.run(
                ["proxym", "chat", cmd, "--cli-mode"],
                capture_output=True,
                text=True,
                timeout=30
            )
            duration = (time.time() - start) * 1000
            times.append(duration)
        
        avg_time = statistics.mean(times)
        results.append((cmd, avg_time))
        
    return results


def main():
    print("=" * 70)
    print("NLP Performance Benchmark")
    print("=" * 70)
    
    # Test commands covering all major categories
    test_commands = [
        # Tickets
        ("create ticket for test", "Ticket Create"),
        ("create high priority feature ticket for implement API", "Ticket Full"),
        ("dispatch TKT-12345", "Ticket Dispatch"),
        ("close TKT-12345", "Ticket Close"),
        
        # Projects
        ("register project test at /tmp/test", "Project Register"),
        ("create project test using aider at /tmp/test", "Project with Tool"),
        
        # Sprints
        ("create sprint MVP", "Sprint Create"),
        ("start sprint MVP", "Sprint Start"),
        
        # VMs
        ("create vm aider for myproject", "VM Create"),
        ("start vm-12345", "VM Start"),
        
        # Batch
        ("dispatch all tickets for myproject", "Batch Dispatch"),
        ("run fix bug on myproject", "Run Task"),
        
        # Queries
        ("show status", "Query Status"),
        ("list tickets", "Query Tickets"),
        ("kanban", "Query Board"),
        
        # Polish
        ("utwórz ticket dla test", "Polish Ticket"),
        ("zarejestruj projekt test w /tmp/test", "Polish Project"),
    ]
    
    commands = [c[0] for c in test_commands]
    labels = [c[1] for c in test_commands]
    
    print(f"\nRunning {len(commands)} commands x 5 iterations each...")
    print("-" * 70)
    
    results = run_benchmark(commands, iterations=5)
    
    # Sort by speed
    results_sorted = sorted(results, key=lambda x: x[1])
    
    print("\nResults (sorted by speed):")
    print(f"{'Command':<45} {'Avg Time':>12} {'Rating'}")
    print("-" * 70)
    
    fast = 0
    medium = 0
    slow = 0
    
    for (cmd, avg_time), label in zip(results, labels):
        if avg_time < 500:
            rating = "✓ FAST"
            fast += 1
        elif avg_time < 1000:
            rating = "~ OK"
            medium += 1
        else:
            rating = "✗ SLOW"
            slow += 1
            
        print(f"{label:<45} {avg_time:>10.1f}ms  {rating}")
    
    print("-" * 70)
    
    all_times = [r[1] for r in results]
    avg = statistics.mean(all_times)
    median = statistics.median(all_times)
    max_time = max(all_times)
    min_time = min(all_times)
    
    print(f"\nStatistics:")
    print(f"  Average: {avg:.1f}ms")
    print(f"  Median:  {median:.1f}ms")
    print(f"  Min:     {min_time:.1f}ms")
    print(f"  Max:     {max_time:.1f}ms")
    
    print(f"\nDistribution:")
    print(f"  FAST (<500ms):  {fast}")
    print(f"  OK (500-1000ms): {medium}")
    print(f"  SLOW (>1000ms): {slow}")
    
    print("\n" + "=" * 70)
    print("DSL Schema Coverage: 48+ patterns")
    print("Languages: English + Polish")
    print("Optimization: Regex-based matching (no LLM required)")
    print("=" * 70)


if __name__ == "__main__":
    main()
