#!/usr/bin/env bash
###############################################################################
# cli_shell_scenario.sh — Quick CLI walkthrough
#
# Demonstrates the main proxym CLI workflow in a single script:
#   status → project add → ticket add → board → dispatch → queue → analyze
#
# Usage:
#   bash examples/cli_shell_scenario.sh
#   PROXYM_URL=http://localhost:4000 bash examples/cli_shell_scenario.sh
###############################################################################
set -e

PROXYM_URL="${PROXYM_URL:-${DEFAULT_PROXY_URL:-http://localhost:4000}}"
CLI="proxym --proxy $PROXYM_URL"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="${SCRIPT_DIR}/todo_list_project"

echo "=== Proxym CLI Shell Scenario ==="
echo "    Server: ${PROXYM_URL}"
echo ""

echo "1. Checking server status..."
$CLI status

echo ""
echo "2. Creating project directory on host..."
mkdir -p "${PROJECT_DIR}"

echo ""
echo "3. Registering project in Proxym..."
$CLI project add "${PROJECT_DIR}" --name "todo-app" --tool "claude-code" \
  || echo "   (project may already exist)"

echo ""
echo "4. Creating initial setup ticket..."
$CLI ticket add \
  "Initialize a basic Node.js TypeScript testing environment with package.json, jest, and tsconfig.json." \
  -p "todo-app" -t "claude-code" --priority "high" --type "feature"

echo ""
echo "5. Creating implementation ticket..."
$CLI ticket add \
  "Implement a simple TodoList class in TypeScript with add, remove, and list methods. Add Jest tests for it." \
  -p "todo-app" -t "claude-code" --priority "medium" --type "feature"

echo ""
echo "6. Checking board..."
$CLI board

echo ""
echo "7. Checking job queue status..."
$CLI q
$CLI tools jobs --limit 5

echo ""
echo "8. Analyzing tickets..."
echo "   Use: proxym analyze <TKT-ID> to check each ticket's result"
echo "   Use: proxym ticket list --project todo-app to see project tickets"

echo ""
echo "=== Scenario Complete ==="
echo "Next steps:"
echo "  proxym tools dispatch --ticket <TKT-ID> --tool claude-code --project-dir ${PROJECT_DIR}"
echo "  proxym analyze <TKT-ID>"
