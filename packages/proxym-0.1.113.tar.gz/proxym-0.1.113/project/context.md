# System Architecture Analysis

## Overview

- **Project**: /home/tom/github/wronai/proxy
- **Primary Language**: python
- **Languages**: python: 211, javascript: 85, shell: 16, typescript: 5
- **Analysis Mode**: static
- **Total Functions**: 2480
- **Total Classes**: 256
- **Modules**: 317
- **Entry Points**: 1958

## Architecture by Module

### src.proxym.dashboard.components.tasks
- **Functions**: 131
- **File**: `tasks.jsx`

### src.proxym.dashboard.components.tickets
- **Functions**: 110
- **File**: `tickets.jsx`

### src.proxym.dashboard.components.projects
- **Functions**: 83
- **File**: `projects.jsx`

### src.proxym.dashboard.hooks.useDashboardData
- **Functions**: 79
- **File**: `useDashboardData.js`

### htmlcov.coverage_html_cb_dd2e7eb5
- **Functions**: 77
- **File**: `coverage_html_cb_dd2e7eb5.js`

### src.proxym.dashboard.components.integrations
- **Functions**: 56
- **File**: `integrations.jsx`

### src.proxym.dashboard.components.home
- **Functions**: 41
- **File**: `home.jsx`

### src.proxym.external.providers
- **Functions**: 40
- **Classes**: 6
- **File**: `providers.py`

### src.proxym.dashboard.components.tickets.TicketsPanelRefactored
- **Functions**: 39
- **File**: `TicketsPanelRefactored.jsx`

### src.proxym.dashboard.users._git_support
- **Functions**: 35
- **Classes**: 1
- **File**: `_git_support.py`

### src.proxym.dashboard.components.vms
- **Functions**: 35
- **File**: `vms.jsx`

### src.proxym.dashboard.components.setup
- **Functions**: 35
- **File**: `setup.jsx`

### src.proxym.dashboard.tickets._manager
- **Functions**: 34
- **Classes**: 1
- **File**: `_manager.py`

### src.proxym.dashboard._environments_api
- **Functions**: 33
- **Classes**: 6
- **File**: `_environments_api.py`

### src.proxym.dashboard.components.voice_engine
- **Functions**: 31
- **File**: `voice_engine.jsx`

### src.proxym.dashboard.components.environments
- **Functions**: 31
- **File**: `environments.jsx`

### src.proxym.dashboard.components.voice
- **Functions**: 30
- **File**: `voice.jsx`

### src.proxym.dashboard.tickets.TicketManagerRefactored
- **Functions**: 26
- **Classes**: 4
- **File**: `TicketManagerRefactored.py`

### src.proxym.ctl
- **Functions**: 25
- **File**: `ctl.py`

### examples.todo-app-ts.verify
- **Functions**: 25
- **File**: `verify.sh`

## Key Entry Points

Main execution flows into the system:

### src.proxym.api.diagnostics.run_all_tests
> Run all diagnostic tests and return comprehensive status.
- **Calls**: router.get, enumerate, sum, src.proxym.api._diag_vscode.check_vscode_status, src.proxym.api._diag_proxy.check_llm_proxy, src.proxym.api._diag_roo.check_roo_cline_config, src.proxym.api._diag_vscode.check_extensions, src.proxym.api._diag_providers.check_providers_config

### src.proxym.cli.chat.cmd_chat
> Interactive chat with proxym — DSL first, LLM fallback, CLI generation.
- **Calls**: src.proxym.config.get_settings, getattr, getattr, getattr, getattr, getattr, DSLParser, src.proxym.cli.chat._init_voice

### src.proxym.cli._groups.multi_ctl.compare_cmd
> A/B test: send same task to multiple tools and compare results.


Examples:
  proxym compare "add cache to API" --on my-project --tools aider,claude-
- **Calls**: click.command, click.argument, click.option, click.option, click.option, click.option, click.option, src.proxym.cli._client.make_client

### src.proxym.dashboard.components.tickets.TicketsPanel
- **Calls**: src.proxym.dashboard.components.tickets.useTickets, src.proxym.dashboard.components.tickets.useState, src.proxym.dashboard.components.tickets.Set, src.proxym.dashboard.components.tickets.useCallback, src.proxym.dashboard.components.tickets.setSelectedTicketDetails, src.proxym.dashboard.components.tickets.setSelectedTicketError, src.proxym.dashboard.components.tickets.setSelectedTicketLoading, src.proxym.dashboard.components.tickets.get

### src.proxym.cli._groups.multi_ctl.batch_cmd
> Execute multiple tasks from a YAML file.


YAML format:
  - task: "Create calculator.py"
    project: calculator
    tool: aider
    type: feature
  
- **Calls**: click.command, click.argument, click.option, click.option, click.option, click.option, src.proxym.cli._client.make_client, click.echo

### src.proxym.cli._groups.tools_ctl.tools_dispatch
> Dispatch a tool to work on a ticket.


Tool and project-dir are auto-resolved from ticket/project if omitted.
Examples:
  proxym tools dispatch TKT-X
- **Calls**: tools.command, click.argument, click.option, click.option, click.option, click.option, click.option, click.option

### src.proxym.dashboard.hooks.useDashboardData.useDashboardData
- **Calls**: src.proxym.dashboard.hooks.useDashboardData.replace, src.proxym.dashboard.hooks.useDashboardData.normalizeDashboardTab, src.proxym.dashboard.hooks.useDashboardData.getInitialRoute, src.proxym.dashboard.hooks.useDashboardData.getUrlParams, src.proxym.dashboard.hooks.useDashboardData.useState, src.proxym.dashboard.hooks.useDashboardData.normalizeDashboardAction, src.proxym.dashboard.hooks.useDashboardData.normalizeDashboardContext, src.proxym.dashboard.hooks.useDashboardData.useRef

### src.proxym.cli._groups.external_ctl.external_issue_sync
> Sync a proxym ticket to external provider as an issue.
- **Calls**: external_issue.command, click.argument, click.argument, click.option, click.option, click.option, src.proxym.ctl._make_args, src.proxym.external.config.get_config_manager

### src.proxym.dashboard.components.tasks.TasksPanel
- **Calls**: src.proxym.dashboard.components.tasks.useTasksData, src.proxym.dashboard.components.tasks.useState, src.proxym.dashboard.components.tasks.Set, src.proxym.dashboard.components.tasks.useMemo, src.proxym.dashboard.components.tasks.filter, src.proxym.dashboard.components.tasks._isHumanTicket, src.proxym.dashboard.components.tasks.trim, src.proxym.dashboard.components.tasks.toLowerCase

### src.proxym.cli._groups.do_ctl.do_cmd
> One command to rule them all.


Examples:
  proxym do "fix crash in /health endpoint"
  proxym do "refactor panel.jsx" --on proxym --with claude-code
- **Calls**: click.command, click.argument, click.option, click.option, click.option, click.option, click.option, click.option

### src.proxym.dashboard.components.environments.EnvironmentsPanel
- **Calls**: src.proxym.dashboard.components.environments.useState, src.proxym.dashboard.components.environments.useMemo, src.proxym.dashboard.components.environments.fromEntries, src.proxym.dashboard.components.environments.map, src.proxym.dashboard.components.environments.useCallback, src.proxym.dashboard.components.environments.setLoading, src.proxym.dashboard.components.environments.setError, src.proxym.dashboard.components.environments.all

### src.proxym.ctl.autofix_cmd
> Create a fix ticket from a failed job's error output and dispatch it.


Reads the error from the last execution, creates a new ticket with
the origin
- **Calls**: cli.command, click.argument, click.option, click.option, src.proxym.ctl._make_args, src.proxym.cli._client.make_client, last_exec.get, last_exec.get

### src.proxym.api.completions.chat_completions
> OpenAI-compatible chat completions with intelligent routing.

Extra headers:
  X-Task-Tier: trivial|operational|standard|complex|deep
  X-Inject-Conte
- **Calls**: router.post, src.proxym.observability.log_call, Header, src.proxym.api.completions._route_to_model, src.proxym.api.completions._analyze_request, isinstance, src.proxym.api.completions._inject_provider_key, src.proxym.config.get_settings

### src.proxym.dashboard.components.setup.SetupPanel
- **Calls**: src.proxym.dashboard.components.setup.useState, src.proxym.dashboard.components.setup._setupInitialValues, src.proxym.dashboard.components.setup.useCallback, src.proxym.dashboard.components.setup.setCompleted, src.proxym.dashboard.components.setup._setupCompletedMap, src.proxym.dashboard.components.setup.setLastUpdated, src.proxym.dashboard.components.setup.Date, src.proxym.dashboard.components.setup.setSyncing

### src.proxym.cli._groups.tools_ctl.tools_status
> Combined tool dashboard: availability, model, job stats.


Shows a single table with each tool's status, default model,
job count, success rate, and 
- **Calls**: tools.command, src.proxym.ctl._make_args, src.proxym.cli._client.make_client, click.echo, click.echo, click.echo, c.get, None.get

### src.proxym.cli._groups.tickets_ctl.ticket_list
> List tickets.
- **Calls**: ticket.command, click.option, click.option, click.option, click.option, click.option, click.option, src.proxym.ctl._make_args

### examples.multi-project-nlp.benchmark.main
- **Calls**: services.vscode.entrypoint.print, services.vscode.entrypoint.print, services.vscode.entrypoint.print, services.vscode.entrypoint.print, services.vscode.entrypoint.print, examples.multi-project-nlp.benchmark.run_benchmark, src.proxym.dashboard.components.vms.sorted, services.vscode.entrypoint.print

### src.proxym.cache.DeltaBuffer.compute_delta
> Compare current files against last-sent snapshots, return delta.
- **Calls**: self.scan, self._classify_changes, max, self._build_diff_text, self._estimate_tokens, logger.info, DeltaPayload, self._make_full_payload

### src.proxym.dashboard.components.voice.VoiceChat
- **Calls**: src.proxym.dashboard.components.voice.setVoiceCredentials, src.proxym.dashboard.components.voice.useState, src.proxym.dashboard.components.voice.useRef, src.proxym.dashboard.components.voice.setHistory, src.proxym.dashboard.components.voice.slice, src.proxym.dashboard.components.voice.setState, src.proxym.dashboard.components.voice._speakTTS, src.proxym.dashboard.components.voice.trim

### src.proxym.dashboard.components.projects.ProjectFormUnified
- **Calls**: src.proxym.dashboard.components.projects.useState, src.proxym.dashboard.components.projects.changes, src.proxym.dashboard.components.projects.useEffect, src.proxym.dashboard.components.projects.setMode, src.proxym.dashboard.components.projects.map, src.proxym.dashboard.components.projects.filter, src.proxym.dashboard.components.projects.setName, src.proxym.dashboard.components.projects.setDescription

### src.proxym.main.lifespan
- **Calls**: src.proxym.config.get_settings, bool, settings.available_providers, logger.info, _env_keys.items, ToolExecutor.get, tool_executor.start, ToolStartupOrchestrator

### src.proxym.accounts.AccountManager._load
- **Calls**: src.proxym.storage.is_sqlite_database, json.loads, logger.info, self.config_path.exists, data.values, logger.info, json.loads, logger.info

### src.proxym.dashboard.components.diagnostics.DiagnosticsPanel
- **Calls**: src.proxym.dashboard.components.diagnostics.useState, src.proxym.dashboard.components.diagnostics.useCallback, src.proxym.dashboard.components.diagnostics.setLoading, src.proxym.dashboard.components.diagnostics.setError, src.proxym.dashboard.components.diagnostics.fetch, src.proxym.dashboard.components.diagnostics._api, src.proxym.dashboard.components.diagnostics._headers, src.proxym.dashboard.components.diagnostics.Error

### scripts.seed_sprint8.main
- **Calls**: argparse.ArgumentParser, parser.add_argument, parser.add_argument, parser.add_argument, parser.parse_args, args.base.rstrip, httpx.post, services.vscode.entrypoint.print

### src.proxym.dashboard._tickets_api.update_ticket
> Update a ticket's fields.
- **Calls**: router.put, Body, Body, Body, Body, Body, Body, Body

### src.proxym.cli._groups.keys_ctl.init_cmd
> Initialize development environment with valid local API key.
- **Calls**: keys.command, click.option, click.echo, click.echo, env_file.read_text, content.split, click.echo, click.echo

### src.proxym.dashboard.components.tickets.TicketsPanelRefactored.TicketsPanelRefactored
- **Calls**: src.proxym.dashboard.components.tickets.TicketsPanelRefactored.useTicketsData, src.proxym.dashboard.components.tickets.TicketsPanelRefactored.useState, src.proxym.dashboard.components.tickets.TicketsPanelRefactored.Set, src.proxym.dashboard.components.tickets.TicketsPanelRefactored.useTicketReviewDetail, src.proxym.dashboard.components.tickets.TicketsPanelRefactored.useTicketFilters, src.proxym.dashboard.components.tickets.TicketsPanelRefactored.useTicketStats, src.proxym.dashboard.components.tickets.TicketsPanelRefactored.useCallback, src.proxym.dashboard.components.tickets.TicketsPanelRefactored.refresh

### src.proxym.cli.tickets.cmd_ticket_show
> Show ticket details.
- **Calls**: services.vscode.entrypoint.print, services.vscode.entrypoint.print, data.get, data.get, data.get, data.get, data.get, data.get

### src.proxym.domain.handlers.project_handler.ProjectCommandHandler._handle_add
> Add a project — unified logic for all source types.
- **Calls**: self._event_store.append, str, Project, src.proxym.domain.handlers.project_handler.enrich_project, ProjectCreated, None.resolve, reg.add, src.proxym.config.get_settings

### src.proxym.dashboard.tools._dispatch.dispatch_job
> Dispatch a tool to work on a ticket. Enqueues a job.
- **Calls**: router.post, None.get_tool, src.proxym.dashboard.tools._helpers._get_ticket, ToolExecutor.get, executor.get_jobs_for_ticket, src.proxym.dashboard._environments_api.get_tool_environment_snapshot, executor.start, src.proxym.tools.adapters._base._resolve_model_for_tool

## Process Flows

Key execution flows identified:

### Flow 1: run_all_tests
```
run_all_tests [src.proxym.api.diagnostics]
  └─ →> check_vscode_status
      └─ →> get_settings
          └─ →> get_singleton
      └─ →> _probe_first_ok
  └─ →> check_llm_proxy
      └─ →> get_settings
          └─ →> get_singleton
```

### Flow 2: cmd_chat
```
cmd_chat [src.proxym.cli.chat]
  └─ →> get_settings
      └─ →> get_singleton
```

### Flow 3: compare_cmd
```
compare_cmd [src.proxym.cli._groups.multi_ctl]
```

### Flow 4: TicketsPanel
```
TicketsPanel [src.proxym.dashboard.components.tickets]
  └─> useTickets
```

### Flow 5: batch_cmd
```
batch_cmd [src.proxym.cli._groups.multi_ctl]
```

### Flow 6: tools_dispatch
```
tools_dispatch [src.proxym.cli._groups.tools_ctl]
```

### Flow 7: useDashboardData
```
useDashboardData [src.proxym.dashboard.hooks.useDashboardData]
  └─> normalizeDashboardTab
```

### Flow 8: external_issue_sync
```
external_issue_sync [src.proxym.cli._groups.external_ctl]
```

### Flow 9: TasksPanel
```
TasksPanel [src.proxym.dashboard.components.tasks]
  └─> useTasksData
```

### Flow 10: do_cmd
```
do_cmd [src.proxym.cli._groups.do_ctl]
```

## Key Classes

### src.proxym.dashboard.users._git_support.GitUserIdentityMixin
> Git identity and repository discovery helpers for UserManager.
- **Methods**: 35
- **Key Methods**: src.proxym.dashboard.users._git_support.GitUserIdentityMixin._candidate_git_repo_paths, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._is_existing_directory, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._resolve_git_root_candidate, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._read_git_identity_from_cli, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._read_git_identity, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._read_git_identity_from_repo, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._upsert_git_identity, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._read_git_ref_from_file, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._resolve_git_ref_content, src.proxym.dashboard.users._git_support.GitUserIdentityMixin._parse_packed_git_ref_line

### src.proxym.dashboard.tickets._manager.TicketManager
> In-memory ticket & sprint store with optional JSON persistence.
- **Methods**: 34
- **Key Methods**: src.proxym.dashboard.tickets._manager.TicketManager.__init__, src.proxym.dashboard.tickets._manager.TicketManager.create_ticket, src.proxym.dashboard.tickets._manager.TicketManager.get_ticket, src.proxym.dashboard.tickets._manager.TicketManager.list_tickets, src.proxym.dashboard.tickets._manager.TicketManager._apply_filters, src.proxym.dashboard.tickets._manager.TicketManager._sort_tickets, src.proxym.dashboard.tickets._manager.TicketManager.update_ticket, src.proxym.dashboard.tickets._manager.TicketManager.delete_ticket, src.proxym.dashboard.tickets._manager.TicketManager.add_comment, src.proxym.dashboard.tickets._manager.TicketManager.assign_tool

### src.proxym.tools.executor.ToolExecutor
> Async executor for tool jobs with a bounded queue.
- **Methods**: 21
- **Key Methods**: src.proxym.tools.executor.ToolExecutor.__init__, src.proxym.tools.executor.ToolExecutor._init_store, src.proxym.tools.executor.ToolExecutor._load_jobs, src.proxym.tools.executor.ToolExecutor._persist_job, src.proxym.tools.executor.ToolExecutor.get, src.proxym.tools.executor.ToolExecutor.start, src.proxym.tools.executor.ToolExecutor.stop, src.proxym.tools.executor.ToolExecutor.enqueue, src.proxym.tools.executor.ToolExecutor.get_job, src.proxym.tools.executor.ToolExecutor.get_jobs_for_ticket

### src.proxym.dashboard._environments_api.EnvironmentRegistry
- **Methods**: 18
- **Key Methods**: src.proxym.dashboard._environments_api.EnvironmentRegistry.__init__, src.proxym.dashboard._environments_api.EnvironmentRegistry._load, src.proxym.dashboard._environments_api.EnvironmentRegistry._save, src.proxym.dashboard._environments_api.EnvironmentRegistry._tools_by_environment, src.proxym.dashboard._environments_api.EnvironmentRegistry._resolve_tool_instance_name, src.proxym.dashboard._environments_api.EnvironmentRegistry.list_environments, src.proxym.dashboard._environments_api.EnvironmentRegistry.list_payloads, src.proxym.dashboard._environments_api.EnvironmentRegistry.get, src.proxym.dashboard._environments_api.EnvironmentRegistry.create, src.proxym.dashboard._environments_api.EnvironmentRegistry.update

### src.proxym.virt.clonebox_adapter.CloneBoxAdapter
> Adapter wrapping the clonebox CLI for VM operations.

All operations use `--user` flag for rootless/
- **Methods**: 17
- **Key Methods**: src.proxym.virt.clonebox_adapter.CloneBoxAdapter.__init__, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.is_available, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.version, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.create_vm, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.start_vm, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.stop_vm, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.snapshot, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.restore_snapshot, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.health, src.proxym.virt.clonebox_adapter.CloneBoxAdapter.delete_vm

### examples.todo-app-ts.templates.store.TodoStore
- **Methods**: 16
- **Key Methods**: examples.todo-app-ts.templates.store.TodoStore.load, examples.todo-app-ts.templates.store.TodoStore.fs, examples.todo-app-ts.templates.store.TodoStore.data, examples.todo-app-ts.templates.store.TodoStore.save, examples.todo-app-ts.templates.store.TodoStore.fs, examples.todo-app-ts.templates.store.TodoStore.path, examples.todo-app-ts.templates.store.TodoStore.create, examples.todo-app-ts.templates.store.TodoStore.list, examples.todo-app-ts.templates.store.TodoStore.get, examples.todo-app-ts.templates.store.TodoStore.update

### frontend.dashboard-sse-service.SSEService
- **Methods**: 16
- **Key Methods**: frontend.dashboard-sse-service.SSEService.subscribe, frontend.dashboard-sse-service.SSEService.setTimeout, frontend.dashboard-sse-service.SSEService.setTimeout, frontend.dashboard-sse-service.SSEService.connect, frontend.dashboard-sse-service.SSEService.configReady, frontend.dashboard-sse-service.SSEService._doConnect, frontend.dashboard-sse-service.SSEService.apiUrl, frontend.dashboard-sse-service.SSEService.apiKey, frontend.dashboard-sse-service.SSEService.sseUrl, frontend.dashboard-sse-service.SSEService.event

### src.proxym.accounts.AccountManager
> Central account registry.

Persists to a JSON file, with live metrics in memory (optionally Redis).
- **Methods**: 15
- **Key Methods**: src.proxym.accounts.AccountManager.__init__, src.proxym.accounts.AccountManager._load, src.proxym.accounts.AccountManager._save, src.proxym.accounts.AccountManager.add_account, src.proxym.accounts.AccountManager.remove_account, src.proxym.accounts.AccountManager.get_account, src.proxym.accounts.AccountManager.list_accounts, src.proxym.accounts.AccountManager.find_cheapest_active, src.proxym.accounts.AccountManager.record_usage, src.proxym.accounts.AccountManager.bind_tool

### src.proxym.projects.ProjectRegistry
> Rejestr projektów z persystencją JSON.
- **Methods**: 14
- **Key Methods**: src.proxym.projects.ProjectRegistry.__init__, src.proxym.projects.ProjectRegistry.add, src.proxym.projects.ProjectRegistry.get, src.proxym.projects.ProjectRegistry.find_by_name, src.proxym.projects.ProjectRegistry.find_by_path, src.proxym.projects.ProjectRegistry.list_projects, src.proxym.projects.ProjectRegistry.update, src.proxym.projects.ProjectRegistry.remove, src.proxym.projects.ProjectRegistry.scan_directory, src.proxym.projects.ProjectRegistry.add_git_repo

### src.proxym.dashboard.orchestrator.TicketOrchestrator
> Orchestrates ticket status transitions based on job events.
- **Methods**: 13
- **Key Methods**: src.proxym.dashboard.orchestrator.TicketOrchestrator.__init__, src.proxym.dashboard.orchestrator.TicketOrchestrator._event_loop, src.proxym.dashboard.orchestrator.TicketOrchestrator._handle_job_event, src.proxym.dashboard.orchestrator.TicketOrchestrator._handle_completed_job, src.proxym.dashboard.orchestrator.TicketOrchestrator._handle_failed_job, src.proxym.dashboard.orchestrator.TicketOrchestrator._review_job, src.proxym.dashboard.orchestrator.TicketOrchestrator._review_model, src.proxym.dashboard.orchestrator.TicketOrchestrator._temporary_error, src.proxym.dashboard.orchestrator.TicketOrchestrator._build_review_prompt, src.proxym.dashboard.orchestrator.TicketOrchestrator._normalise_review_payload
- **Inherits**: LifecycleMixin

### src.proxym.observability.watchdog.HealthWatchdog
> Daemon sprawdzający zdrowie systemu w pętli.

Checks:
  - proxy /health
  - provider connectivity (n
- **Methods**: 13
- **Key Methods**: src.proxym.observability.watchdog.HealthWatchdog.__init__, src.proxym.observability.watchdog.HealthWatchdog.start, src.proxym.observability.watchdog.HealthWatchdog.stop, src.proxym.observability.watchdog.HealthWatchdog._loop, src.proxym.observability.watchdog.HealthWatchdog._run_checks, src.proxym.observability.watchdog.HealthWatchdog._check_proxy_health, src.proxym.observability.watchdog.HealthWatchdog._check_providers, src.proxym.observability.watchdog.HealthWatchdog._check_vscode, src.proxym.observability.watchdog.HealthWatchdog._check_budget, src.proxym.observability.watchdog.HealthWatchdog._check_error_rate

### src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored
> Refactored ticket & sprint store with separated concerns.
- **Methods**: 13
- **Key Methods**: src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.__init__, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.create_ticket, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.get_ticket, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.list_tickets, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.update_ticket, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.delete_ticket, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.create_sprint, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.list_sprints, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.create_milestone, src.proxym.dashboard.tickets.TicketManagerRefactored.TicketManagerRefactored.list_milestones

### src.proxym.dashboard.users._manager.UserManager
> In-memory user store with SQLite persistence and git integration.
- **Methods**: 13
- **Key Methods**: src.proxym.dashboard.users._manager.UserManager.get, src.proxym.dashboard.users._manager.UserManager.reset, src.proxym.dashboard.users._manager.UserManager.__init__, src.proxym.dashboard.users._manager.UserManager.create_user, src.proxym.dashboard.users._manager.UserManager.get_user, src.proxym.dashboard.users._manager.UserManager.find_by_email, src.proxym.dashboard.users._manager.UserManager.find_by_username, src.proxym.dashboard.users._manager.UserManager.list_users, src.proxym.dashboard.users._manager.UserManager.get_default_user, src.proxym.dashboard.users._manager.UserManager.update_user
- **Inherits**: GitSyncMixin, GitUserIdentityMixin

### src.proxym.tools._registry.ToolRegistry
> Singleton registry of available development tools.
- **Methods**: 12
- **Key Methods**: src.proxym.tools._registry.ToolRegistry.__init__, src.proxym.tools._registry.ToolRegistry._apply_env_overrides, src.proxym.tools._registry.ToolRegistry.get, src.proxym.tools._registry.ToolRegistry.register, src.proxym.tools._registry.ToolRegistry.unregister, src.proxym.tools._registry.ToolRegistry.get_tool, src.proxym.tools._registry.ToolRegistry.list_tools, src.proxym.tools._registry.ToolRegistry.update_tool, src.proxym.tools._registry.ToolRegistry._load_overrides, src.proxym.tools._registry.ToolRegistry._save_overrides

### src.proxym.api._pipeline.CompletionPipeline
> Structured pipeline for processing a chat completion request.

Stages:
  1. build_context  — inject 
- **Methods**: 12
- **Key Methods**: src.proxym.api._pipeline.CompletionPipeline.__init__, src.proxym.api._pipeline.CompletionPipeline.execute, src.proxym.api._pipeline.CompletionPipeline._build_context, src.proxym.api._pipeline.CompletionPipeline._route, src.proxym.api._pipeline.CompletionPipeline._inject_tools, src.proxym.api._pipeline.CompletionPipeline._touch_session, src.proxym.api._pipeline.CompletionPipeline._run, src.proxym.api._pipeline.CompletionPipeline._build_kwargs, src.proxym.api._pipeline.CompletionPipeline._execute_with_fallbacks, src.proxym.api._pipeline.CompletionPipeline._make_stream_response

### src.proxym.cli.config_validate.ConfigValidator
> Validates Proxym configuration from .env file.
- **Methods**: 11
- **Key Methods**: src.proxym.cli.config_validate.ConfigValidator.__init__, src.proxym.cli.config_validate.ConfigValidator.load_env, src.proxym.cli.config_validate.ConfigValidator.validate, src.proxym.cli.config_validate.ConfigValidator._check_required_keys, src.proxym.cli.config_validate.ConfigValidator._check_llm_providers, src.proxym.cli.config_validate.ConfigValidator._check_proxy_url, src.proxym.cli.config_validate.ConfigValidator._check_ollama, src.proxym.cli.config_validate.ConfigValidator._check_master_key_format, src.proxym.cli.config_validate.ConfigValidator.has_errors, src.proxym.cli.config_validate.ConfigValidator.has_warnings

### src.proxym.virt._lifecycle._LifecycleMixin
> VM creation, start, stop, pause, resume.
- **Methods**: 11
- **Key Methods**: src.proxym.virt._lifecycle._LifecycleMixin.create_vm, src.proxym.virt._lifecycle._LifecycleMixin._prepare_clonebox_args, src.proxym.virt._lifecycle._LifecycleMixin._write_cloud_init_file, src.proxym.virt._lifecycle._LifecycleMixin._create_vm_clonebox, src.proxym.virt._lifecycle._LifecycleMixin._create_vm_virsh, src.proxym.virt._lifecycle._LifecycleMixin.start_vm, src.proxym.virt._lifecycle._LifecycleMixin._start_vm_clonebox, src.proxym.virt._lifecycle._LifecycleMixin.stop_vm, src.proxym.virt._lifecycle._LifecycleMixin._stop_vm_clonebox, src.proxym.virt._lifecycle._LifecycleMixin.pause_vm

### src.proxym.domain.events.EventStore
> Append-only event store with optional SQLite persistence.

The store keeps events in memory and opti
- **Methods**: 11
- **Key Methods**: src.proxym.domain.events.EventStore.__init__, src.proxym.domain.events.EventStore.append, src.proxym.domain.events.EventStore.subscribe, src.proxym.domain.events.EventStore.events_for, src.proxym.domain.events.EventStore.all_events, src.proxym.domain.events.EventStore.get_events, src.proxym.domain.events.EventStore.mark_processed, src.proxym.domain.events.EventStore._processed_marker, src.proxym.domain.events.EventStore.count, src.proxym.domain.events.EventStore._persist_event

### src.proxym.router.strategy.CostLedger
> In-memory cost ledger with Redis persistence.

Tracks spend per day and month.  Call ``record()`` af
- **Methods**: 11
- **Key Methods**: src.proxym.router.strategy.CostLedger.__init__, src.proxym.router.strategy.CostLedger._connect_redis, src.proxym.router.strategy.CostLedger._redis_day_key, src.proxym.router.strategy.CostLedger._redis_month_key, src.proxym.router.strategy.CostLedger._load_from_redis, src.proxym.router.strategy.CostLedger._save_to_redis, src.proxym.router.strategy.CostLedger._rotate_keys, src.proxym.router.strategy.CostLedger.can_spend, src.proxym.router.strategy.CostLedger.record, src.proxym.router.strategy.CostLedger.daily_remaining

### src.proxym.external.providers.BaseExternalProvider
> Base class for external provider integrations.
- **Methods**: 11
- **Key Methods**: src.proxym.external.providers.BaseExternalProvider.__init__, src.proxym.external.providers.BaseExternalProvider.__aenter__, src.proxym.external.providers.BaseExternalProvider.__aexit__, src.proxym.external.providers.BaseExternalProvider._get_headers, src.proxym.external.providers.BaseExternalProvider.get_name, src.proxym.external.providers.BaseExternalProvider.validate_credentials, src.proxym.external.providers.BaseExternalProvider.list_projects, src.proxym.external.providers.BaseExternalProvider.create_project, src.proxym.external.providers.BaseExternalProvider.create_issue, src.proxym.external.providers.BaseExternalProvider.update_issue_status
- **Inherits**: ABC

## Data Transformation Functions

Key functions that process and transform data:

### src.proxym.project_config._parse
> Parse a YAML file into *ProjectConfig*.
- **Output to**: ProjectConfig, isinstance, ProjectConfig, ProjectConfig, yaml.safe_load

### src.proxym.dashboard.webhooks.WebhookManager._transform_for_github
> Transform payload for GitHub.
- **Output to**: status_map.get, payload.get, payload.get, isinstance, comment.get

### src.proxym.dashboard.webhooks.WebhookManager._transform_for_gitlab
> Transform payload for GitLab.
- **Output to**: payload.get, isinstance, comment.get, self._extract_issue_number, status_map.get

### src.proxym.dashboard.webhooks.WebhookManager._transform_for_jira
> Transform payload for Jira.
- **Output to**: payload.get, isinstance, comment.get, status_map.get, comment.get

### src.proxym.cli.system._format_status_data
> Transform raw API responses into a structured status dict.
- **Output to**: health.get, round, round, round, round

### src.proxym.cli._cli_schema.format_schema_for_llm
> Format CLI schema as string for LLM prompt.
- **Output to**: schema.get, schema.get, lines.extend, None.join, src.proxym.cli._cli_schema._format_command

### src.proxym.cli._cli_schema._format_command
> Helper to format command data.
- **Output to**: cmd_data.get, cmd_data.get, None.split, lines.append, lines.append

### src.proxym.cli.observability._format_entry
> Format a structured observability entry for CLI display.
- **Output to**: entry.get, isinstance, None.upper, src.proxym.cli.observability._short_value, src.proxym.cli.observability._short_value

### src.proxym.cli.config_validate.ConfigValidator.validate
> Run all validation checks.
- **Output to**: self._check_required_keys, self._check_llm_providers, self._check_proxy_url, self._check_ollama, self._check_master_key_format

### src.proxym.cli.config_validate.ConfigValidator._check_master_key_format
> Check master key format.
- **Output to**: self.env_vars.get, key.startswith, self.issues.append, ConfigIssue, self.issues.append

### src.proxym.cli.config_validate.validate_before_llm
> Validate configuration before using LLM features.

If interactive=True, prompts user to fix issues.

- **Output to**: ConfigValidator, validator.validate, validator.print_report, sys.stdin.isatty, src.proxym.cli.config_validate.prompt_user_for_fix

### src.proxym.cli.chat._format_result
> Format API response for human-readable chat output.
- **Output to**: _FORMATTERS.get, json.dumps, fmt

### src.proxym.cli.chat._process_input
> Route text through DSL or LLM and return formatted response.
- **Output to**: dsl.parse, src.proxym.cli.chat._ask_proxym_llm, dsl.execute, src.proxym.cli.chat._format_result

### src.proxym.cli.tts.TTSEngine._validate
> Check that the chosen backend is available.
- **Output to**: shutil.which, logger.warning, shutil.which, logger.warning

### src.proxym.cli.dsl.DSLParser.parse
> Try to match *text* against DSL patterns.

Returns ``None`` if no pattern matches — caller should fo
- **Output to**: text.strip, regex.fullmatch, regex.match, spec.get, None.items

### src.proxym.mcp.client.MCPClient._parse_response
> Parse a successful JSON-RPC response into MCPToolResult.
- **Output to**: data.get, isinstance, MCPToolResult, result.get, isinstance

### src.proxym.domain.events.EventStore.mark_processed
> Mark events as processed by a specific processor.
- **Output to**: self._processed_marker, object.__setattr__

### src.proxym.domain.events.EventStore._processed_marker
- **Output to**: None.replace, None.lower, None.strip

### src.proxym.mcp._tools_vallm._validate_single
> Run a single vallm validator and return the result dict.
- **Output to**: src.proxym.mcp._tools_vallm._try_import_vallm, importlib.import_module, getattr, validator_cls, src.proxym.mcp._tools_vallm._make_proposal

### src.proxym.mcp._tools_vallm.tool_validate_syntax
> Validate code syntax using vallm SyntaxValidator.
- **Output to**: router.post, src.proxym.mcp._tools_vallm._validate_single

### src.proxym.mcp._tools_vallm.tool_validate_imports
> Validate code imports using vallm ImportValidator.
- **Output to**: router.post, src.proxym.mcp._tools_vallm._validate_single

### src.proxym.mcp._tools_vallm.tool_validate_security
> Validate code security using vallm SecurityValidator.
- **Output to**: router.post, src.proxym.mcp._tools_vallm._validate_single

### src.proxym.mcp._tools_vallm.tool_validate_code
> Full code validation pipeline using multiple vallm validators.

Runs the requested validators in seq
- **Output to**: router.post, src.proxym.mcp._tools_vallm._try_import_vallm, src.proxym.mcp._tools_vallm._make_proposal, src.proxym.mcp._tools_vallm._get_validator_map, src.proxym.mcp._tools_vallm._emit_validation_event

### src.proxym.external.providers.BaseExternalProvider.validate_credentials
> Validate that the API key works.

### src.proxym.external.providers.GitHubProvider.validate_credentials
- **Output to**: RuntimeError, self._client.get

## Behavioral Patterns

### recursion_scan_command_group
- **Type**: recursion
- **Confidence**: 0.90
- **Functions**: src.proxym.cli._cli_schema.scan_command_group

### recursion__format_command
- **Type**: recursion
- **Confidence**: 0.90
- **Functions**: src.proxym.cli._cli_schema._format_command

### recursion__interactive_api_key_setup
- **Type**: recursion
- **Confidence**: 0.90
- **Functions**: src.proxym.cli.chat._interactive_api_key_setup

### recursion_delete_vm
- **Type**: recursion
- **Confidence**: 0.90
- **Functions**: src.proxym.dashboard._vms.delete_vm

### recursion_merge_profiles
- **Type**: recursion
- **Confidence**: 0.90
- **Functions**: src.proxym.virt.profiles.merge_profiles

### state_machine__StateMixin
- **Type**: state_machine
- **Confidence**: 0.70
- **Functions**: src.proxym.virt._state._StateMixin.get_status, src.proxym.virt._state._StateMixin._refresh_state_clonebox, src.proxym.virt._state._StateMixin._refresh_state_virsh, src.proxym.virt._state._StateMixin._get_vm_ip, src.proxym.virt._state._StateMixin.list_vms

### state_machine_BaseExternalProvider
- **Type**: state_machine
- **Confidence**: 0.70
- **Functions**: src.proxym.external.providers.BaseExternalProvider.__init__, src.proxym.external.providers.BaseExternalProvider.__aenter__, src.proxym.external.providers.BaseExternalProvider.__aexit__, src.proxym.external.providers.BaseExternalProvider._get_headers, src.proxym.external.providers.BaseExternalProvider.get_name

### state_machine_SSEService
- **Type**: state_machine
- **Confidence**: 0.70
- **Functions**: frontend.dashboard-sse-service.SSEService.subscribe, frontend.dashboard-sse-service.SSEService.setTimeout, frontend.dashboard-sse-service.SSEService.setTimeout, frontend.dashboard-sse-service.SSEService.connect, frontend.dashboard-sse-service.SSEService.configReady

## Public API Surface

Functions exposed as public API (no underscore prefix):

- `src.proxym.api.diagnostics.run_all_tests` - 111 calls
- `src.proxym.cli.chat.cmd_chat` - 69 calls
- `src.proxym.cli.tickets.cmd_ticket_analyze` - 65 calls
- `src.proxym.cli._groups.multi_ctl.compare_cmd` - 57 calls
- `src.proxym.dashboard.components.tickets.TicketsPanel` - 56 calls
- `src.proxym.cli._groups.multi_ctl.batch_cmd` - 52 calls
- `src.proxym.cli._groups.tools_ctl.tools_dispatch` - 51 calls
- `src.proxym.dashboard.hooks.useDashboardData.useDashboardData` - 50 calls
- `src.proxym.cli._groups.external_ctl.external_issue_sync` - 47 calls
- `src.proxym.dashboard.components.tasks.TasksPanel` - 46 calls
- `src.proxym.cli._groups.do_ctl.do_cmd` - 43 calls
- `src.proxym.dashboard.components.environments.EnvironmentsPanel` - 42 calls
- `src.proxym.observability.log_call` - 41 calls
- `src.proxym.ctl.autofix_cmd` - 40 calls
- `src.proxym.dashboard._tickets_api.create_ticket` - 39 calls
- `src.proxym.api.completions.chat_completions` - 38 calls
- `src.proxym.dashboard.components.setup.SetupPanel` - 36 calls
- `src.proxym.cli.tickets.cmd_ticket_dedup` - 35 calls
- `src.proxym.cli._groups.tools_ctl.tools_status` - 35 calls
- `src.proxym.cli._groups.tickets_ctl.ticket_list` - 34 calls
- `examples.multi-project-nlp.benchmark.main` - 32 calls
- `src.proxym.cache.DeltaBuffer.compute_delta` - 31 calls
- `src.proxym.dashboard.components.voice.VoiceChat` - 31 calls
- `src.proxym.dashboard.components.projects.ProjectFormUnified` - 31 calls
- `src.proxym.main.lifespan` - 31 calls
- `src.proxym.api._diag_agent.check_agent_setup` - 30 calls
- `src.proxym.dashboard.components.diagnostics.DiagnosticsPanel` - 30 calls
- `scripts.seed_sprint8.main` - 29 calls
- `src.proxym.dashboard._tickets_api.update_ticket` - 29 calls
- `src.proxym.domain.handlers.project_handler.enrich_project` - 28 calls
- `src.proxym.cli._groups.keys_ctl.init_cmd` - 28 calls
- `src.proxym.dashboard.components.tickets.TicketsPanelRefactored.TicketsPanelRefactored` - 28 calls
- `src.proxym.cli.tickets.cmd_ticket_show` - 27 calls
- `src.proxym.dashboard.tools._dispatch.dispatch_job` - 27 calls
- `src.proxym.dashboard.components.tasks.QuickTaskCreator` - 27 calls
- `src.proxym.dashboard.components.integrations.useWebhookIntegrations` - 27 calls
- `src.proxym.dashboard.components.tools.ToolHealthPanelRefactored.ToolHealthPanelRefactored` - 27 calls
- `src.proxym.ctl.retry_cmd` - 26 calls
- `src.proxym.cli._groups.tickets_ctl.ticket_add` - 26 calls
- `src.proxym.tools.adapters._base.BaseAdapter.run` - 26 calls

## System Interactions

How components interact:

```mermaid
graph TD
    run_all_tests --> get
    run_all_tests --> enumerate
    run_all_tests --> sum
    run_all_tests --> check_vscode_status
    run_all_tests --> check_llm_proxy
    cmd_chat --> get_settings
    cmd_chat --> getattr
    compare_cmd --> command
    compare_cmd --> argument
    compare_cmd --> option
    TicketsPanel --> useTickets
    TicketsPanel --> useState
    TicketsPanel --> Set
    TicketsPanel --> useCallback
    TicketsPanel --> setSelectedTicketDet
    batch_cmd --> command
    batch_cmd --> argument
    batch_cmd --> option
    tools_dispatch --> command
    tools_dispatch --> argument
    tools_dispatch --> option
    useDashboardData --> replace
    useDashboardData --> normalizeDashboardTa
    useDashboardData --> getInitialRoute
    useDashboardData --> getUrlParams
    useDashboardData --> useState
    external_issue_sync --> command
    external_issue_sync --> argument
    external_issue_sync --> option
    TasksPanel --> useTasksData
```

## Reverse Engineering Guidelines

1. **Entry Points**: Start analysis from the entry points listed above
2. **Core Logic**: Focus on classes with many methods
3. **Data Flow**: Follow data transformation functions
4. **Process Flows**: Use the flow diagrams for execution paths
5. **API Surface**: Public API functions reveal the interface

## Context for LLM

Maintain the identified architectural patterns and public API surface when suggesting changes.