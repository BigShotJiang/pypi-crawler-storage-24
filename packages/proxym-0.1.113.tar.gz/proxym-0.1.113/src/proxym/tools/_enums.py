"""Tool enums — categories and capabilities."""

from __future__ import annotations

from enum import Enum


class ToolCategory(str, Enum):
    """High-level tool categories."""
    IDE = "ide"
    AGENT_CLI = "agent_cli"
    BROWSER = "browser"
    CUSTOM = "custom"
    HUMAN = "human"


class ToolCapability(str, Enum):
    """Capabilities a tool can advertise."""
    CODE_EDIT = "code_edit"
    CODE_REVIEW = "code_review"
    TEST_RUN = "test_run"
    CHAT = "chat"
    FILE_CREATE = "file_create"
    REFACTOR = "refactor"
    DEBUG = "debug"
    ARCHITECT = "architect"
    MANUAL = "manual"
