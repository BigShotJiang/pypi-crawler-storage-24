"""Tool registry — manage AI development tools (aider, claude-code, windsurf, etc.).

Each tool is described by a ToolDefinition and can be discovered, configured,
and dispatched to via the ToolRegistry singleton.

Submodules
----------
- ``_enums``      – ToolCategory, ToolCapability enums
- ``_instance``   – ToolInstance dataclass
- ``_definition`` – ToolDefinition dataclass
- ``_builtins``   – built-in tool definitions list
- ``_registry``   – ToolRegistry singleton
"""

from proxym.tools._enums import ToolCapability, ToolCategory
from proxym.tools._instance import ToolInstance
from proxym.tools._definition import ToolDefinition
from proxym.tools._builtins import BUILTINS
from proxym.tools._registry import ToolRegistry

__all__ = [
    "ToolCapability",
    "ToolCategory",
    "ToolDefinition",
    "ToolInstance",
    "ToolRegistry",
    "BUILTINS",
]
