"""Built-in tool definitions for proxym."""

from __future__ import annotations

from proxym.tools._enums import ToolCapability, ToolCategory
from proxym.tools._definition import ToolDefinition
from proxym.tools._instance import ToolInstance


def _host_instance(binary: str, description: str) -> ToolInstance:
    return ToolInstance(
        name="host",
        kind="host",
        command=[binary] if binary else [],
        description=description,
    )


def _docker_instance(
    *,
    service: str,
    profile: str,
    command: list[str],
    description: str,
    container_name: str = "",
    notes: str = "",
) -> ToolInstance:
    return ToolInstance(
        name="docker",
        kind="docker",
        command=command,
        service=service,
        profile=profile,
        container_name=container_name,
        description=description,
        notes=notes,
    )

def _kvm_instance(
    *,
    vm_name: str = "",
    vm_host: str = "",
    vm_user: str = "",
    vm_ssh_port: int = 22,
    command: list[str] | None = None,
    description: str = "",
    notes: str = "",
) -> ToolInstance:
    return ToolInstance(
        name="kvm",
        kind="kvm",
        command=command or [],
        vm_name=vm_name,
        vm_host=vm_host,
        vm_user=vm_user,
        vm_ssh_port=vm_ssh_port,
        description=description,
        notes=notes,
    )

BUILTINS: list[ToolDefinition] = [
    ToolDefinition(
        name="aider",
        category=ToolCategory.AGENT_CLI,
        binary="aider",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.REFACTOR,
            ToolCapability.TEST_RUN, ToolCapability.CHAT,
        ],
        default_model="balanced",
        modes=["code", "architect", "ask"],
        instances=[
            _host_instance("aider", "Run the aider CLI directly on the host."),
            _docker_instance(
                service="aider",
                profile="tools",
                command=["docker", "compose", "--profile", "tools", "run", "--rm", "aider"],
                container_name="proxym-aider",
                description="Run aider as a docker-backed service instance.",
                notes="Compose service placeholder: add a matching 'aider' service/image when you want container execution.",
            ),
        ],
        description="AI pair programming in the terminal",
    ),
    ToolDefinition(
        name="claude-code",
        category=ToolCategory.AGENT_CLI,
        binary="claude",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.REFACTOR,
            ToolCapability.FILE_CREATE, ToolCapability.CHAT,
            ToolCapability.DEBUG, ToolCapability.ARCHITECT,
        ],
        default_model="balanced",
        modes=["code", "architect", "debug", "ask"],
        instances=[
            _host_instance("claude", "Run the Claude Code CLI directly on the host."),
            _docker_instance(
                service="claude-code",
                profile="tools",
                command=["docker", "compose", "--profile", "tools", "run", "--rm", "claude-code"],
                container_name="proxym-claude-code",
                description="Run Claude Code as a docker-backed service instance.",
                notes="Compose service placeholder: add a matching 'claude-code' service/image when you want container execution.",
            ),
        ],
        description="Anthropic Claude Code CLI agent",
    ),
    ToolDefinition(
        name="windsurf",
        category=ToolCategory.IDE,
        binary="windsurf",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.REFACTOR,
            ToolCapability.FILE_CREATE, ToolCapability.CHAT,
        ],
        default_model="balanced",
        modes=["code", "architect"],
        instances=[
            _host_instance("windsurf", "Launch the Windsurf desktop app on the host."),
            _docker_instance(
                service="windsurf",
                profile="tools",
                command=["docker", "compose", "--profile", "tools", "run", "--rm", "windsurf"],
                container_name="proxym-windsurf",
                description="Docker service descriptor for a Windsurf-compatible instance.",
                notes="Placeholder command for a future Windsurf service image or wrapper container.",
            ),
        ],
        description="Codeium Windsurf IDE with Cascade agent",
    ),
    ToolDefinition(
        name="cursor",
        category=ToolCategory.IDE,
        binary="cursor",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.REFACTOR,
            ToolCapability.FILE_CREATE, ToolCapability.CHAT,
        ],
        default_model="balanced",
        modes=["code", "architect"],
        instances=[
            _host_instance("cursor", "Launch the Cursor desktop app on the host."),
            _docker_instance(
                service="cursor",
                profile="tools",
                command=["docker", "compose", "--profile", "tools", "run", "--rm", "cursor"],
                container_name="proxym-cursor",
                description="Docker service descriptor for a Cursor-compatible instance.",
                notes="Placeholder command for a future Cursor service image or wrapper container.",
            ),
        ],
        description="Cursor IDE with Composer agent",
    ),
    ToolDefinition(
        name="vscode",
        category=ToolCategory.IDE,
        binary="code",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.CHAT,
        ],
        default_model="balanced",
        modes=["code"],
        default_instance="docker",
        instances=[
            _host_instance("code", "Open VS Code on the host."),
            _docker_instance(
                service="vscode",
                profile="vscode",
                command=["docker", "compose", "--profile", "vscode", "up", "-d", "vscode"],
                container_name="proxym-vscode",
                description="VS Code Web running as the proxym Docker service.",
                notes="This is the primary container-backed instance used by Roo Code and Cline.",
            ),
        ],
        description="VS Code with Roo Code / Continue extension",
    ),
    ToolDefinition(
        name="roo-code",
        category=ToolCategory.IDE,
        binary="code",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.REFACTOR,
            ToolCapability.CHAT, ToolCapability.DEBUG,
        ],
        default_model="balanced",
        modes=["code", "architect", "debug", "ask"],
        default_instance="docker",
        instances=[
            _host_instance("code", "Use the local VS Code binary if available."),
            _docker_instance(
                service="vscode",
                profile="vscode",
                command=["docker", "compose", "--profile", "vscode", "up", "-d", "vscode"],
                container_name="proxym-vscode",
                description="Roo Code running inside the proxym VS Code Web container.",
                notes="Shares the same docker service as the main VS Code instance.",
            ),
        ],
        description="Roo Code extension in VS Code Web",
    ),
    ToolDefinition(
        name="cline",
        category=ToolCategory.IDE,
        binary="code",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.CHAT,
        ],
        default_model="balanced",
        modes=["code"],
        default_instance="docker",
        instances=[
            _host_instance("code", "Use the local VS Code binary if available."),
            _docker_instance(
                service="vscode",
                profile="vscode",
                command=["docker", "compose", "--profile", "vscode", "up", "-d", "vscode"],
                container_name="proxym-vscode",
                description="Cline running inside the proxym VS Code Web container.",
                notes="Shares the same docker service as the main VS Code instance.",
            ),
        ],
        description="Cline extension in VS Code",
    ),
    ToolDefinition(
        name="browser",
        category=ToolCategory.BROWSER,
        binary="",
        capabilities=[ToolCapability.CHAT],
        default_model="balanced",
        modes=[],
        default_instance="docker",
        instances=[
            _docker_instance(
                service="open-webui",
                profile="webui",
                command=["docker", "compose", "--profile", "webui", "up", "-d", "open-webui"],
                container_name="proxym-open-webui",
                description="Browser-based chat service backed by Open WebUI.",
                notes="This is the docker-native browser/chat instance shipped with proxym.",
            ),
        ],
        description="Browser-based chat (Open WebUI, ChatGPT, etc.)",
    ),
    ToolDefinition(
        name="codex",
        category=ToolCategory.AGENT_CLI,
        binary="codex",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.REFACTOR,
            ToolCapability.FILE_CREATE, ToolCapability.CHAT,
        ],
        default_model="balanced",
        modes=["code", "ask"],
        instances=[
            _host_instance("codex", "Run the OpenAI Codex CLI directly on the host."),
        ],
        description="OpenAI Codex CLI — agentive terminal assistant",
    ),
    ToolDefinition(
        name="goose",
        category=ToolCategory.AGENT_CLI,
        binary="goose",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.FILE_CREATE,
            ToolCapability.REFACTOR, ToolCapability.CHAT,
        ],
        default_model="balanced",
        modes=["code", "ask"],
        instances=[
            _host_instance("goose", "Run Goose CLI directly on the host."),
        ],
        description="Goose — autonomous coding assistant by Block",
    ),
    ToolDefinition(
        name="open-interpreter",
        category=ToolCategory.AGENT_CLI,
        binary="interpreter",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.FILE_CREATE,
            ToolCapability.TEST_RUN, ToolCapability.CHAT,
        ],
        default_model="balanced",
        modes=["code", "ask"],
        instances=[
            _host_instance("interpreter", "Run Open Interpreter CLI on the host."),
        ],
        description="Open Interpreter — agent executing code and shell commands",
    ),
    ToolDefinition(
        name="plandex",
        category=ToolCategory.AGENT_CLI,
        binary="plandex",
        capabilities=[
            ToolCapability.CODE_EDIT, ToolCapability.FILE_CREATE,
            ToolCapability.ARCHITECT, ToolCapability.REFACTOR,
        ],
        default_model="balanced",
        modes=["code", "architect"],
        instances=[
            _host_instance("plandex", "Run Plandex CLI on the host."),
        ],
        description="Plandex — multi-file planning and coding agent",
    ),
    ToolDefinition(
        name="llm-cli",
        category=ToolCategory.AGENT_CLI,
        binary="llm",
        capabilities=[
            ToolCapability.CHAT, ToolCapability.CODE_REVIEW,
        ],
        default_model="anthropic/haiku-4.5",
        modes=["ask"],
        instances=[
            _host_instance("llm", "Run llm CLI (Simon Willison) on the host."),
        ],
        description="llm CLI — universal LLM client, pipe-friendly",
    ),
    ToolDefinition(
        name="human",
        category=ToolCategory.HUMAN,
        binary="",
        capabilities=[ToolCapability.MANUAL],
        default_instance="manual",
        force_available=True,
        description="Human-in-the-loop collaborator for tokens, installs, approvals, clicking, and onboarding steps",
    ),
]
