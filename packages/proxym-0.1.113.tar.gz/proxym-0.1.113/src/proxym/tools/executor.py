"""Task executor — async queue for dispatching tool jobs.

Manages a queue of ToolJob instances, runs them sequentially or with
configurable concurrency, and tracks results.
"""

from __future__ import annotations

import asyncio
import time
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import structlog

from proxym.dashboard.tickets import Ticket, TicketStatus
from proxym.tools import ToolDefinition, ToolRegistry
from proxym.observability import log_call
from proxym.tools.adapters import get_adapter
from proxym.tools.adapters._base import _resolve_model_for_tool
from proxym.tools.prompt_builder import build_prompt

logger = structlog.get_logger()


class JobStatus(str, Enum):
    QUEUED = "queued"
    RUNNING = "running"
    DONE = "done"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass
class ToolJob:
    """A single tool execution job."""
    id: str = field(default_factory=lambda: str(uuid.uuid4())[:8])
    ticket_id: str = ""
    tool_name: str = ""
    mode: str = ""
    model: str = ""
    project_dir: str = ""
    prompt: str = ""
    environment: dict[str, Any] = field(default_factory=dict)
    status: JobStatus = JobStatus.QUEUED
    result: ToolResult | None = None
    created_at: float = field(default_factory=time.time)
    started_at: float = 0
    finished_at: float = 0
    error: str = ""

    def summary(self) -> dict[str, Any]:
        prompt_excerpt = self.prompt[:400].strip()
        return {
            "id": self.id,
            "ticket_id": self.ticket_id,
            "tool": self.tool_name,
            "mode": self.mode,
            "model": self.model,
            "project_dir": self.project_dir,
            "environment": self.environment or None,
            "prompt_length": len(self.prompt),
            "prompt_excerpt": prompt_excerpt,
            "status": self.status.value,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "finished_at": self.finished_at,
            "duration_s": round(self.finished_at - self.started_at, 2) if self.started_at else 0,
            "result": self.result.summary() if self.result else None,
            "error": self.error,
        }


_JOBS_NAMESPACE = "tool_jobs"


class ToolExecutor:
    """Async executor for tool jobs with a bounded queue."""

    _instance: ToolExecutor | None = None

    def __init__(self, max_concurrent: int = 1) -> None:
        self._queue: asyncio.Queue[ToolJob] = asyncio.Queue(maxsize=100)
        self._jobs: dict[str, ToolJob] = {}
        self._max_concurrent = max_concurrent
        self._running = False
        self._worker_task: asyncio.Task | None = None
        self._store: Any = None
        self._init_store()
        self._load_jobs()
        logger.info("tool_executor_init", max_concurrent=max_concurrent,
                    restored_jobs=len(self._jobs))

    def _init_store(self) -> None:
        try:
            from proxym.storage import DEFAULT_SQLITE_PATH, SQLiteNamespaceStore
            self._store = SQLiteNamespaceStore(DEFAULT_SQLITE_PATH)
        except Exception:
            self._store = None

    def _load_jobs(self) -> None:
        """Load completed/failed jobs from SQLite (history only, not re-queued)."""
        if self._store is None:
            return
        try:
            data = self._store.load_namespace(_JOBS_NAMESPACE)
            for job_id, payload in data.items():
                if not isinstance(payload, dict):
                    continue
                result_data = payload.pop("result", None)
                result = None
                if result_data and isinstance(result_data, dict):
                    result = ToolResult(**{k: v for k, v in result_data.items()
                                          if k in ToolResult.__dataclass_fields__})
                status_str = payload.pop("status", "done")
                job = ToolJob(
                    **{k: v for k, v in payload.items()
                       if k in ToolJob.__dataclass_fields__ and k != "status"},
                    status=JobStatus(status_str),
                )
                job.result = result
                self._jobs[job.id] = job
        except Exception as exc:
            logger.debug("jobs_load_failed", error=str(exc))

    def _persist_job(self, job: ToolJob) -> None:
        """Save a finished job to SQLite."""
        if self._store is None or job.status not in (JobStatus.DONE, JobStatus.FAILED, JobStatus.CANCELLED):
            return
        try:
            # Keep only last 200 jobs
            all_finished = {jid: j for jid, j in self._jobs.items()
                           if j.status in (JobStatus.DONE, JobStatus.FAILED, JobStatus.CANCELLED)}
            if len(all_finished) > 200:
                oldest = sorted(all_finished.values(), key=lambda j: j.created_at)[:len(all_finished) - 200]
                for old in oldest:
                    self._jobs.pop(old.id, None)
                    all_finished.pop(old.id, None)
            items = {jid: j.summary() for jid, j in all_finished.items()}
            self._store.save_namespace(_JOBS_NAMESPACE, items)
        except Exception as exc:
            logger.debug("job_persist_failed", job_id=job.id, error=str(exc))

    @classmethod
    def get(cls) -> ToolExecutor:
        if cls._instance is None:
            cls._instance = cls()
        return cls._instance

    def start(self) -> None:
        """Start the executor worker loop."""
        if self._running:
            return
        self._running = True
        self._worker_task = asyncio.create_task(self._worker_loop())
        logger.info("tool_executor_started")

    async def stop(self, timeout: float = 60) -> None:
        """Stop the worker loop gracefully, waiting for the current job."""
        self._running = False
        if self._worker_task:
            # Give the current job time to finish before cancelling
            try:
                await asyncio.wait_for(
                    asyncio.shield(self._worker_task), timeout=timeout,
                )
            except (asyncio.TimeoutError, asyncio.CancelledError):
                self._worker_task.cancel()
                try:
                    await self._worker_task
                except (asyncio.CancelledError, RuntimeError):
                    pass
            except RuntimeError:
                # Task is from a different event loop (test cleanup)
                pass
        logger.info("tool_executor_stopped")

    def enqueue(
        self,
        ticket: Ticket,
        tool: ToolDefinition,
        project_dir: str,
        mode: str = "",
        model: str = "",
        environment: dict[str, Any] | None = None,
    ) -> ToolJob:
        """Create and enqueue a new job. Returns the job (status=queued)."""
        prompt = build_prompt(ticket, tool, mode, project_dir=project_dir)
        job = ToolJob(
            ticket_id=ticket.id,
            tool_name=tool.name,
            mode=mode or (tool.modes[0] if tool.modes else "code"),
            model=_resolve_model_for_tool(model or tool.default_model, tool.name),
            project_dir=project_dir,
            prompt=prompt,
            environment=dict(environment or {}),
        )
        self._jobs[job.id] = job
        try:
            self._queue.put_nowait(job)
        except asyncio.QueueFull:
            job.status = JobStatus.FAILED
            job.error = "Queue full"
        logger.info("tool_job_enqueued", job_id=job.id, tool=tool.name, ticket=ticket.id)
        return job

    def get_job(self, job_id: str) -> ToolJob | None:
        return self._jobs.get(job_id)

    def get_jobs_for_ticket(self, ticket_id: str) -> list[ToolJob]:
        """Return all jobs for a ticket, most recent first."""
        jobs = [j for j in self._jobs.values() if j.ticket_id == ticket_id]
        jobs.sort(key=lambda j: j.created_at, reverse=True)
        return jobs

    def list_jobs(
        self, status: JobStatus | None = None, limit: int = 50,
    ) -> list[ToolJob]:
        jobs = list(self._jobs.values())
        if status:
            jobs = [j for j in jobs if j.status == status]
        jobs.sort(key=lambda j: j.created_at, reverse=True)
        return jobs[:limit]

    def cancel_job(self, job_id: str) -> bool:
        """Cancel a queued job. Returns False if not found or already running."""
        job = self._jobs.get(job_id)
        if not job or job.status != JobStatus.QUEUED:
            return False
        job.status = JobStatus.CANCELLED
        job.finished_at = time.time()
        return True

    def queue_summary(self) -> dict[str, Any]:
        """Summary stats for the queue."""
        jobs = list(self._jobs.values())
        by_status = {}
        for j in jobs:
            by_status[j.status.value] = by_status.get(j.status.value, 0) + 1
        return {
            "total_jobs": len(jobs),
            "by_status": by_status,
            "queue_size": self._queue.qsize(),
            "running": self._running,
            "max_concurrent": self._max_concurrent,
        }

    async def _worker_loop(self) -> None:
        """Main worker loop — pulls jobs from queue and executes them."""
        sem = asyncio.Semaphore(self._max_concurrent)
        while self._running:
            try:
                async with asyncio.timeout(1.0):
                    job = await self._queue.get()
            except (asyncio.TimeoutError, asyncio.CancelledError):
                continue

            if job.status == JobStatus.CANCELLED:
                continue

            async with sem:
                await self._execute_job(job)

    @log_call(level="info", slow_threshold_ms=60000)
    async def _execute_job(self, job: ToolJob) -> None:
        """Execute a single job."""
        job.status = JobStatus.RUNNING
        job.started_at = time.time()
        logger.info("tool_job_started", job_id=job.id, tool=job.tool_name)
        self._sync_ticket_execution(job)

        adapter = get_adapter(job.tool_name)
        if not adapter:
            job.status = JobStatus.FAILED
            job.error = f"No adapter for tool '{job.tool_name}'"
            job.finished_at = time.time()
            logger.warning("tool_job_no_adapter", job_id=job.id, tool=job.tool_name)
            self._sync_ticket_execution(job)
            return

        try:
            # Get files from ticket
            files = []
            if job.ticket_id:
                from proxym.dashboard._tickets_api import _tickets
                mgr = _tickets()
                ticket = mgr.get_ticket(job.ticket_id)
                if ticket:
                    # Use context_files as the files to edit
                    files = ticket.context_files or []
            
            result = await adapter.run(
                prompt=job.prompt,
                project_dir=job.project_dir,
                ticket_id=job.ticket_id,
                mode=job.mode,
                model=job.model,
                files=files,
            )
            job.result = result
            job.status = JobStatus.DONE if result.success else JobStatus.FAILED
            if not result.success:
                job.error = result.stderr[:500]
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            job.status = JobStatus.FAILED
            job.error = str(exc)
        finally:
            job.finished_at = time.time()
            # Ensure status is never left as RUNNING
            if job.status == JobStatus.RUNNING:
                job.status = JobStatus.FAILED
                job.error = job.error or "Job interrupted unexpectedly"
            logger.info("tool_job_finished", job_id=job.id, status=job.status.value,
                       duration=f"{job.finished_at - job.started_at:.1f}s")
            self._sync_ticket_execution(job)
            self._persist_job(job)
            self._emit_job_event(job)

    def _emit_job_event(self, job: ToolJob) -> None:
        """Emit a domain event when a job finishes (best-effort)."""
        try:
            from proxym.domain.setup import get_event_store
            from proxym.domain.events import JobCompleted, JobFailed

            store = get_event_store()
            event_cls = JobCompleted if job.status == JobStatus.DONE else JobFailed
            store.append(event_cls(
                aggregate_id=job.id,
                actor="executor",
                data={
                    "ticket_id": job.ticket_id,
                    "tool": job.tool_name,
                    "status": job.status.value,
                    "duration_s": round(job.finished_at - job.started_at, 2) if job.started_at else 0,
                    "error": job.error[:300] if job.error else "",
                },
            ))
        except Exception:
            pass

    def _sync_ticket_execution(self, job: ToolJob) -> None:
        """Write job status back to the ticket's last_execution field."""
        if not job.ticket_id:
            return
        try:
            from proxym.dashboard._tickets_api import _tickets
            mgr = _tickets()
            execution = self._build_execution(job)
            updates: dict[str, Any] = {"last_execution": execution}
            ticket = mgr.get_ticket(job.ticket_id)
            if ticket is not None:
                # Update ticket status based on job result
                if job.status == JobStatus.DONE:
                    self._handle_job_success(ticket, updates)
                elif job.status == JobStatus.FAILED:
                    self._handle_job_failure(job, ticket, mgr)
                
                # Trigger orchestrator processing
                self._trigger_orchestrator(ticket, job)
            mgr.update_ticket(job.ticket_id, updates)
        except Exception as exc:
            logger.debug("sync_ticket_exec_failed", job_id=job.id, error=str(exc))
    
    def _trigger_orchestrator(self, ticket: "Ticket", job: ToolJob) -> None:
        """Trigger the TicketOrchestrator to process the job completion."""
        try:
            import os

            if os.environ.get("PYTEST_CURRENT_TEST"):
                return
            from proxym.dashboard.orchestrator import TicketOrchestrator
            orchestrator = TicketOrchestrator.get()
            # The orchestrator will pick up the event via the event store
            # This is just to ensure it's running
            if not orchestrator._running:
                orchestrator.start()
        except Exception as exc:
            logger.debug("trigger_orchestrator_failed", error=str(exc))

    @staticmethod
    def _build_execution(job: ToolJob) -> "JobExecution":
        """Build a JobExecution record from a ToolJob."""
        from proxym.dashboard.tickets import JobExecution

        files: list[str] = []
        stdout_tail = ""
        stderr_tail = ""
        stdout_lines = 0
        stderr_lines = 0
        success: bool | None = None
        exit_code: int | None = None
        execution_metadata: dict[str, Any] = {}

        # Extract environment info
        environment_snapshot = job.environment or {}
        environment_tool_instance = environment_snapshot.get("tool_instance") if isinstance(environment_snapshot, dict) else None
        environment_tool_instance_name = environment_snapshot.get("tool_instance_name", "") if isinstance(environment_snapshot, dict) else ""
        if not environment_tool_instance_name and isinstance(environment_tool_instance, dict):
            environment_tool_instance_name = str(environment_tool_instance.get("name", ""))
        environment_tool_instance_payload = environment_tool_instance if isinstance(environment_tool_instance, dict) else {}

        # Extract result data
        if job.result:
            files = getattr(job.result, "files_changed", []) or []
            stdout = getattr(job.result, "stdout", "") or ""
            stderr = getattr(job.result, "stderr", "") or ""
            stdout_tail = stdout[-500:]
            stderr_tail = stderr[-500:]
            stdout_lines = len(stdout.splitlines())
            stderr_lines = len(stderr.splitlines())
            success = bool(getattr(job.result, "success", False))
            exit_code = int(getattr(job.result, "exit_code", -1))
            execution_metadata = dict(getattr(job.result, "execution_metadata", {}) or {})

        if job.environment:
            execution_metadata.setdefault("environment", job.environment)

        # Only override success/exit_code when no result exists (e.g. queue full, cancelled)
        if not job.result:
            if job.status == JobStatus.DONE:
                success = True
                exit_code = 0
            elif job.status == JobStatus.FAILED:
                success = False
                exit_code = exit_code if exit_code is not None else -1

        return JobExecution(
            job_id=job.id,
            tool=job.tool_name,
            mode=job.mode,
            model=job.model,
            project_dir=job.project_dir,
            prompt_excerpt=job.prompt[:400].strip(),
            prompt_length=len(job.prompt),
            status=job.status.value,
            success=success,
            exit_code=exit_code,
            environment_tool_instance_name=environment_tool_instance_name,
            environment_tool_instance=environment_tool_instance_payload,
            started_at=job.started_at,
            finished_at=job.finished_at,
            duration_s=round(job.finished_at - job.started_at, 2) if job.finished_at else None,
            error=job.error,
            files_changed=files,
            stdout_tail=stdout_tail,
            stderr_tail=stderr_tail,
            stdout_lines=stdout_lines,
            stderr_lines=stderr_lines,
            execution_metadata=execution_metadata,
        )

    @staticmethod
    def _handle_job_success(ticket: "Ticket", updates: dict[str, Any]) -> None:
        """Transition ticket to IN_REVIEW on successful job completion."""
        if ticket.status in {
            TicketStatus.BACKLOG,
            TicketStatus.TODO,
            TicketStatus.IN_PROGRESS,
        }:
            updates["status"] = TicketStatus.IN_REVIEW.value

    @staticmethod
    def _handle_job_failure(job: ToolJob, ticket: "Ticket", mgr: Any) -> None:
        """Create a human intervention ticket when a non-human job fails."""
        if getattr(ticket, "tool", "") == "human":
            return
        new_ticket_title = getattr(ticket, "title", "") or getattr(ticket, "task", "")[:50]
        human_payload = {
            "title": f"[Manual Intervention Required] {new_ticket_title}",
            "task": (
                f"Automated job {job.id} for ticket {job.ticket_id} failed.\n\n"
                f"Error: {job.error}\n\n"
                f"Please fix the issue manually or adjust the code."
            ),
            "project_id": getattr(ticket, "project_id", ""),
            "type": "bug",
            "priority": "high",
            "tool": "human",
        }
        try:
            mgr.create_ticket(human_payload)
        except Exception as hexc:
            logger.debug("create_human_ticket_failed", error=str(hexc))
