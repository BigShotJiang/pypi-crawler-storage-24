"""User models for the dashboard user store."""

from __future__ import annotations

import time
import uuid
from typing import Any

from pydantic import BaseModel, Field


class UserRole(str):
    """User roles in the system."""

    ADMIN = "admin"
    DEVELOPER = "developer"
    VIEWER = "viewer"


class User(BaseModel):
    """A user in the system, identified by git configuration."""

    id: str = Field(default_factory=lambda: f"USR-{uuid.uuid4().hex[:6].upper()}")
    name: str = ""  # Git user.name
    email: str = ""  # Git user.email
    username: str = ""  # GitHub/GitLab username or system username
    role: str = "developer"
    is_default: bool = False  # Is this the default/delegated user?
    is_active: bool = True
    git_configured: bool = False  # Was this user auto-discovered from git?
    # Metadata
    created_at: float = Field(default_factory=time.time)
    updated_at: float = Field(default_factory=time.time)
    last_seen_at: float = 0
    # Project associations
    projects: list[str] = Field(default_factory=list)  # Project IDs this user works on
    # Stats
    tickets_assigned: int = 0
    tickets_completed: int = 0

    def summary(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "username": self.username,
            "role": self.role,
            "is_default": self.is_default,
            "is_active": self.is_active,
            "git_configured": self.git_configured,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "last_seen_at": self.last_seen_at,
            "projects": self.projects,
            "tickets_assigned": self.tickets_assigned,
            "tickets_completed": self.tickets_completed,
        }


__all__ = ["User", "UserRole"]
