"""Pydantic request models for the dashboard users API."""

from __future__ import annotations

from pydantic import BaseModel, Field


class CreateUserRequest(BaseModel):
    name: str = Field(..., description="User display name")
    email: str = Field(..., description="User email address")
    username: str = Field("", description="Username/login")
    role: str = Field("developer", description="User role: admin, developer, viewer")
    is_default: bool = Field(False, description="Set as default/delegated user")


class UpdateUserRequest(BaseModel):
    name: str | None = Field(None, description="User display name")
    email: str | None = Field(None, description="User email address")
    username: str | None = Field(None, description="Username/login")
    role: str | None = Field(None, description="User role")
    is_default: bool | None = Field(None, description="Set as default user")
    is_active: bool | None = Field(None, description="Active status")


__all__ = ["CreateUserRequest", "UpdateUserRequest"]
