"""Users — git-based user management for the dashboard.

Enables tracking users who work with the system, with git integration
for automatic user discovery from commit history.
"""

from __future__ import annotations

import shutil  # noqa: F401 — kept for monkeypatch-based tests

from proxym.dashboard.users._models import User, UserRole
from proxym.dashboard.users._manager import UserManager

__all__ = ["User", "UserManager", "UserRole"]
