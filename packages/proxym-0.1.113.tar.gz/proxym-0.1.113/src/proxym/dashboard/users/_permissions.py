"""Default-user and permission helpers for the user store."""

from __future__ import annotations

from typing import Any

from proxym.dashboard.users._models import User


def ensure_single_default(users: dict[str, User], new_default_id: str) -> None:
    """Unset is_default on every user except *new_default_id*."""
    for u in users.values():
        if u.is_default and u.id != new_default_id:
            u.is_default = False


def resolve_default_user(users: dict[str, User]) -> dict[str, Any] | None:
    """Return the summary of the default active user, with first-active fallback."""
    for user in users.values():
        if user.is_default and user.is_active:
            return user.summary()
    # Fallback: return first active user
    for user in users.values():
        if user.is_active:
            return user.summary()
    return None


__all__ = ["ensure_single_default", "resolve_default_user"]
