// JobRow — single table row for a job entry
import React from 'react';
import JobStatusBadge from './JobStatusBadge';
import { formatDuration } from './jobFormatters';

function JobRow({ job }) {
  return (
    <tr className="border-b border-gray-100 hover:bg-gray-50">
      <td className="py-1.5 px-3 text-xs font-mono text-gray-400">{job.id?.slice(0, 10)}</td>
      <td className="py-1.5 px-3 text-xs font-mono text-gray-500">{job.ticket_id?.slice(0, 12)}</td>
      <td className="py-1.5 px-3 text-xs font-medium">{job.tool}</td>
      <td className="py-1.5 px-3"><JobStatusBadge status={job.status} /></td>
      <td className="py-1.5 px-3 text-xs text-gray-400">{formatDuration(job.duration_s)}</td>
      <td className="py-1.5 px-3 text-xs text-red-400 truncate max-w-[200px]">{job.error || ""}</td>
    </tr>
  );
}

export default JobRow;
