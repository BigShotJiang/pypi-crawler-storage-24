// jobFormatters — lookup objects and data mappers for job display

export const JOB_STATUS_COLORS = {
  pending: "bg-gray-100 text-gray-700",
  running: "bg-blue-100 text-blue-700",
  completed: "bg-emerald-100 text-emerald-700",
  failed: "bg-red-100 text-red-700",
  cancelled: "bg-amber-100 text-amber-700",
};

export function jobToExportRow(job) {
  return {
    id: job.id,
    ticket: job.ticket_id,
    ticket_title: job.ticket?.title || job.ticket?.task || '',
    ticket_status: job.ticket?.status || '',
    ticket_priority: job.ticket?.priority || '',
    ticket_type: job.ticket?.type || '',
    ticket_project_id: job.ticket?.project_id || '',
    ticket_assigned_tool: job.ticket?.assigned_tool?.tool || '',
    tool: job.tool,
    mode: job.mode || '',
    status: job.status,
    duration: job.duration_s > 0 ? `${job.duration_s}s` : '—',
    exit_code: job.result?.exit_code ?? '',
    stdout_lines: job.result?.stdout_lines ?? 0,
    stderr_lines: job.result?.stderr_lines ?? 0,
    stdout: job.result?.stdout || '',
    stderr: job.result?.stderr || '',
    files_changed: Array.isArray(job.result?.files_changed) ? job.result.files_changed.join(', ') : '',
    error: job.error || '',
  };
}

export function formatDuration(durationSec) {
  return durationSec > 0 ? `${durationSec}s` : "—";
}
