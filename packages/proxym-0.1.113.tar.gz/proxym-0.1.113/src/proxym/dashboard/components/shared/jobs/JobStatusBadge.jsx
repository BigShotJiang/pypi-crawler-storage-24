// JobStatusBadge — small status pill for job rows
import React from 'react';
import { JOB_STATUS_COLORS } from './jobFormatters';

function JobStatusBadge({ status }) {
  const color = JOB_STATUS_COLORS[status] || "bg-gray-100";
  return (
    <span className={`text-[11px] px-1.5 py-0.5 rounded-full ${color}`}>{status}</span>
  );
}

export default JobStatusBadge;
