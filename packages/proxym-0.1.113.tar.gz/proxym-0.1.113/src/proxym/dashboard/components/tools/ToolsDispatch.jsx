// ToolsDispatch - Component for tool dispatch functionality
import React from 'react';
import Card from '../Card';
import TicketDispatchTableRefactored from './TicketDispatchTableRefactored';

function ToolsDispatch({ tools, onRefresh }) {
  return (
    <Card title="Dispatch">
      <TicketDispatchTableRefactored tools={tools} onDispatch={onRefresh} />
    </Card>
  );
}

export default ToolsDispatch;
