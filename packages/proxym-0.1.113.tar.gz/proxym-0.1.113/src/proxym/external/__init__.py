"""External integrations module for GitHub, GitLab, and Jira."""
from __future__ import annotations

from proxym.external.config import (
    get_config_manager,
    ProviderConfig,
    ExternalConfigManager,
)
from proxym.external.providers import (
    get_provider,
    BaseExternalProvider,
    GitHubProvider,
    GitLabProvider,
    JiraProvider,
    ExternalProject,
    ExternalIssue,
)

__all__ = [
    "get_config_manager",
    "ProviderConfig",
    "ExternalConfigManager",
    "get_provider",
    "BaseExternalProvider",
    "GitHubProvider",
    "GitLabProvider",
    "JiraProvider",
    "ExternalProject",
    "ExternalIssue",
]
