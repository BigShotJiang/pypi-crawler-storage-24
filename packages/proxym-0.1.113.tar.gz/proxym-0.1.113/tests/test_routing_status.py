from __future__ import annotations


def test_routing_test_endpoint_status_only(authed_client):
    r = authed_client.get("/api/v1/routing/test")
    assert r.status_code == 200
    data = r.json()

    assert "routing" in data
    assert isinstance(data["routing"], dict)

    # Should include registry model IDs (no aliases)
    assert len(data["routing"]) > 0
    for model_id, entry in data["routing"].items():
        assert "model" in entry
        assert "provider" in entry
        assert entry["status"] in ("ok", "no_key")
        assert "model_id" in entry

    assert "providers" in data
    assert "ollama_base_url" in data["providers"]
    assert "configured" in data["providers"]
    assert isinstance(data["providers"]["configured"], list)
