# tinker-host-agent 发布流程

## 前置条件

- Python 3.11+
- [uv](https://docs.astral.sh/uv/) 已安装
- PyPI API Token（在 https://pypi.org/manage/account/token/ 创建）

## 发布步骤

### 1. 更新版本号

同步修改两处：

```bash
# pyproject.toml
version = "0.x.x"

# src/tinker_host/__init__.py
__version__ = "0.x.x"
```

### 2. 构建

```bash
cd packages/tinker-host-agent
rm -rf dist/
uv build
```

产物在 `dist/`：
- `tinker_host_agent-x.x.x-py3-none-any.whl`
- `tinker_host_agent-x.x.x.tar.gz`

### 3. 本地验证

```bash
# 验证 wheel 内容
python3 -m zipfile -l dist/tinker_host_agent-*.whl

# 试运行
uv tool install ./dist/tinker_host_agent-*.whl --force
tinker-host-agent --help
```

### 4. 发布到 PyPI

```bash
uv publish --token pypi-YOUR_TOKEN
```

### 5. 验证发布

```bash
# 等待 ~10s 索引同步
uvx --refresh tinker-host-agent --help
```

## 用户安装方式

```bash
# 零安装一键运行（推荐）
uvx tinker-host-agent

# 带 GUI 能力
uvx --with pillow tinker-host-agent

# 永久安装
pip install tinker-host-agent
pip install tinker-host-agent[gui]
```

## 版本策略

- **Patch (0.1.x)**: Bug 修复、文案调整
- **Minor (0.x.0)**: 新增 capability、新增 action
- **Major (x.0.0)**: 协议破坏性变更

## CI 自动发布（TODO）

未来可通过 GitHub Actions + trusted publishing 实现 tag 触发自动发布：
```yaml
on:
  push:
    tags: ["tinker-host-agent-v*"]
```
