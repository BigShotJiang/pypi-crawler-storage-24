"""Tinker Host Agent — main entry point.

Connects to Tinker backend via WebSocket using the Device Agent Protocol (DAP).
Exposes host machine capabilities (shell, fs, gui, app, clipboard) as
controllable actions.

Usage:
    tinker-host-agent                              # Connect to localhost
    tinker-host-agent --url ws://tinker:8000/ws/device-agent
    tinker-host-agent --url wss://tinker.example.com/ws/device-agent --mode remote
    TINKER_HOST_SERVER_URL=ws://... tinker-host-agent
"""

from __future__ import annotations

import argparse
import asyncio
import json
import logging
import platform
import signal
import sys
import time
from pathlib import Path

import websockets
from websockets.asyncio.client import connect

from .config import HostAgentSettings

logger = logging.getLogger("tinker_host")


class HostAgent:
    """DAP WebSocket client that exposes host capabilities to Tinker."""

    def __init__(self, settings: HostAgentSettings) -> None:
        self.settings = settings
        self._handlers: dict[str, object] = {}  # namespace → handler
        self._running = True
        self._reconnect_delay = settings.reconnect_delay

        self._init_capabilities()

    def _init_capabilities(self) -> None:
        """Initialize enabled capability handlers."""
        s = self.settings

        if s.enable_shell:
            from .capabilities.shell import ShellCapability

            blocked = [b.strip() for b in s.blocked_commands.split(",") if b.strip()]
            self._handlers["shell"] = ShellCapability(blocked_commands=blocked)

        if s.enable_fs:
            from .capabilities.fs import FSCapability

            allowed = self._parse_paths(s.allowed_paths) if s.allowed_paths else None
            blocked = self._parse_paths(s.blocked_paths) if s.blocked_paths else None
            self._handlers["fs"] = FSCapability(allowed_paths=allowed, blocked_paths=blocked)

        if s.enable_gui:
            from .capabilities.gui import GUICapability

            self._handlers["gui"] = GUICapability()

        if s.enable_app:
            from .capabilities.app import AppCapability

            self._handlers["app"] = AppCapability()

        if s.enable_clipboard:
            from .capabilities.clipboard import ClipboardCapability

            self._handlers["clipboard"] = ClipboardCapability()

        if s.enable_network:
            from .capabilities.network import NetworkCapability

            self._handlers["network"] = NetworkCapability()

        if s.enable_system:
            from .capabilities.system import SystemCapability

            self._handlers["system"] = SystemCapability()

        if s.enable_notification:
            from .capabilities.notification import NotificationCapability

            self._handlers["notification"] = NotificationCapability()

        if s.enable_browser:
            from .capabilities.browser import BrowserCapability

            self._handlers["browser"] = BrowserCapability()

        # Load plugins
        if s.plugin_dir:
            from .plugins import PluginRegistry

            registry = PluginRegistry()
            plugins = registry.discover(s.plugin_dir)
            for ns, plugin in plugins.items():
                if ns in self._handlers:
                    logger.warning("Plugin '%s' conflicts with built-in capability, skipping", ns)
                else:
                    self._handlers[ns] = plugin

        logger.info("Capabilities: %s", list(self._handlers.keys()))

    def _parse_paths(self, paths_str: str) -> list[Path]:
        return [Path(p.strip()).expanduser() for p in paths_str.split(",") if p.strip()]

    def _build_hello(self) -> dict:
        """Build the hello handshake message."""
        capabilities = []
        for ns, handler in self._handlers.items():
            capabilities.append(
                {
                    "namespace": ns,
                    "actions": handler.actions,
                    "description": getattr(handler, "description", ""),
                }
            )

        return {
            "type": "hello",
            "version": "1.0",
            "agent_id": self.settings.get_agent_id(),
            "agent_type": self.settings.agent_type,
            "agent_name": self.settings.get_agent_name(),
            "platform": {
                "os": platform.system().lower(),
                "arch": platform.machine(),
                "hostname": platform.node(),
                "python": platform.python_version(),
            },
            "capabilities": capabilities,
            "plugins": [],
            "auth_token": self.settings.auth_token,
        }

    async def run(self) -> None:
        """Main loop — connect and reconnect on failure."""
        logger.info("Starting Tinker Host Agent")
        logger.info("  Server: %s", self.settings.server_url)
        logger.info("  Agent ID: %s", self.settings.get_agent_id())
        logger.info("  Agent Type: %s", self.settings.agent_type)
        logger.info("  Platform: %s %s", platform.system(), platform.machine())

        while self._running:
            try:
                await self._connect_and_serve()
            except Exception as e:
                if not self._running:
                    break
                logger.warning("Connection lost: %s", e)
                logger.info("Reconnecting in %.1fs...", self._reconnect_delay)
                await asyncio.sleep(self._reconnect_delay)
                # Exponential backoff
                self._reconnect_delay = min(
                    self._reconnect_delay * 2, self.settings.reconnect_max_delay
                )

        logger.info("Host Agent stopped")

    async def _connect_and_serve(self) -> None:
        """Connect to server and handle messages."""
        url = self.settings.server_url
        logger.info("Connecting to %s ...", url)

        async with connect(url, max_size=50 * 1024 * 1024) as ws:
            # Send hello
            hello = self._build_hello()
            await ws.send(json.dumps(hello))

            # Wait for welcome
            raw = await asyncio.wait_for(ws.recv(), timeout=15)
            welcome = json.loads(raw)

            if welcome.get("type") != "welcome":
                logger.error("Unexpected response: %s", welcome)
                return

            session_id = welcome.get("session_id", "?")
            approved = welcome.get("approved_capabilities", [])
            denied = welcome.get("denied_capabilities", [])

            logger.info("Connected! session=%s", session_id)
            logger.info("  Approved: %s", approved)
            if denied:
                logger.warning("  Denied: %s", denied)

            # Reset reconnect delay on success
            self._reconnect_delay = self.settings.reconnect_delay

            # Handle messages
            async for raw_msg in ws:
                if not self._running:
                    break
                try:
                    msg = json.loads(raw_msg)
                    await self._handle_message(ws, msg)
                except json.JSONDecodeError:
                    logger.warning("Invalid JSON: %s", raw_msg[:200])
                except Exception as e:
                    logger.error("Error handling message: %s", e, exc_info=True)

    async def _handle_message(self, ws, msg: dict) -> None:
        """Handle an incoming message from the server."""
        msg_type = msg.get("type")

        # Ping → Pong
        if msg_type == "ping":
            await ws.send(json.dumps({"type": "pong", "ts": msg.get("ts", 0)}))
            return

        # Command request
        request_id = msg.get("id")
        if request_id:
            namespace = msg.get("namespace", "")
            action = msg.get("action", "")
            params = msg.get("params", {})

            logger.info("Command: %s.%s (id=%s)", namespace, action, request_id[:8])

            result = await self._execute_command(namespace, action, params)

            # Send response
            status = "error" if "error" in result else "success"
            response = {
                "id": request_id,
                "status": status,
                "result": result,
            }
            await ws.send(json.dumps(response))

    async def _execute_command(self, namespace: str, action: str, params: dict) -> dict:
        """Execute a command by routing to the appropriate capability handler."""
        handler = self._handlers.get(namespace)
        if not handler:
            return {"error": f"Unknown capability: {namespace}"}

        if action not in handler.actions:
            return {"error": f"Unknown action: {namespace}.{action}"}

        try:
            return await handler.handle(action, params)
        except Exception as e:
            logger.error("Command %s.%s failed: %s", namespace, action, e, exc_info=True)
            return {"error": f"Command failed: {e}"}

    def stop(self) -> None:
        """Signal the agent to stop."""
        self._running = False


def main() -> None:
    """CLI entry point."""
    parser = argparse.ArgumentParser(
        description="Tinker Host Agent — connect your machine to Tinker",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  tinker-host-agent                                    # Default (ws://localhost:3000)
  tinker-host-agent --url ws://tinker:8000/ws/device-agent
  tinker-host-agent --url wss://tinker.example.com/ws/device-agent --mode remote
  TINKER_HOST_SERVER_URL=ws://... tinker-host-agent    # Via env var
        """,
    )
    parser.add_argument("--url", help="Tinker server WebSocket URL")
    parser.add_argument("--token", help="Authentication token")
    parser.add_argument("--name", help="Agent display name")
    parser.add_argument("--id", help="Agent ID (auto-generated if omitted)")
    parser.add_argument("--mode", choices=["host", "remote"], default=None, help="Agent type")
    parser.add_argument("--no-gui", action="store_true", help="Disable GUI capability")
    parser.add_argument("--no-shell", action="store_true", help="Disable shell capability")
    parser.add_argument("-v", "--verbose", action="store_true", help="Verbose logging")

    args = parser.parse_args()

    # Configure logging
    level = logging.DEBUG if args.verbose else logging.INFO
    logging.basicConfig(
        format="%(asctime)s %(levelname)-7s %(name)s — %(message)s",
        datefmt="%H:%M:%S",
        level=level,
    )

    # Build settings from env + args
    settings = HostAgentSettings()
    if args.url:
        settings.server_url = args.url
    if args.token:
        settings.auth_token = args.token
    if args.name:
        settings.agent_name = args.name
    if args.id:
        settings.agent_id = args.id
    if args.mode:
        settings.agent_type = args.mode
    if args.no_gui:
        settings.enable_gui = False
    if args.no_shell:
        settings.enable_shell = False

    # Create and run agent
    agent = HostAgent(settings)

    # Handle graceful shutdown
    def _signal_handler(sig, frame):
        logger.info("Shutting down...")
        agent.stop()

    signal.signal(signal.SIGINT, _signal_handler)
    signal.signal(signal.SIGTERM, _signal_handler)

    try:
        asyncio.run(agent.run())
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
