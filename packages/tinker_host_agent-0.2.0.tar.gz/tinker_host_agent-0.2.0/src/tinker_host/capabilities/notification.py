"""System notification capability."""

from __future__ import annotations

import asyncio
import logging
import platform

logger = logging.getLogger(__name__)

_SYSTEM = platform.system()


class NotificationCapability:
    namespace = "notification"
    actions = ["send"]
    description = "Send system notifications"

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "send":
                return await self._send(params)
            case _:
                return {"error": f"Unknown notification action: {action}"}

    async def _send(self, params: dict) -> dict:
        title = params.get("title", "")
        body = params.get("body", "")
        subtitle = params.get("subtitle", "")
        sound = params.get("sound", True)

        if not title:
            return {"error": "No title provided"}
        if not body:
            return {"error": "No body provided"}

        try:
            if _SYSTEM == "Darwin":
                # Build osascript notification command
                parts = [f'display notification "{_escape_applescript(body)}"']
                parts.append(f'with title "{_escape_applescript(title)}"')
                if subtitle:
                    parts.append(f'subtitle "{_escape_applescript(subtitle)}"')
                if sound:
                    parts.append('sound name "default"')

                script = " ".join(parts)
                proc = await asyncio.create_subprocess_exec(
                    "osascript",
                    "-e",
                    script,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
                if proc.returncode != 0:
                    return {"error": f"osascript failed: {stderr.decode(errors='replace')}"}

            elif _SYSTEM == "Linux":
                cmd = ["notify-send", title, body]
                proc = await asyncio.create_subprocess_exec(
                    *cmd,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
                if proc.returncode != 0:
                    return {"error": f"notify-send failed: {stderr.decode(errors='replace')}"}

            else:
                return {"error": f"Notifications not supported on {_SYSTEM}"}

            return {"message": "Notification sent"}
        except Exception as e:
            return {"error": f"Failed to send notification: {e}"}


def _escape_applescript(text: str) -> str:
    """Escape special characters for AppleScript strings."""
    return text.replace("\\", "\\\\").replace('"', '\\"')
