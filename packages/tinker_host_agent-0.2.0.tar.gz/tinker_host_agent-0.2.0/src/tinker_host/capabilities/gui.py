"""GUI automation capability — screenshot + input injection.

Platform support:
- macOS: screencapture + cliclick (via AppleScript fallback)
- Linux: scrot + xdotool
"""

from __future__ import annotations

import asyncio
import base64
import logging
import platform
import subprocess
import tempfile
from pathlib import Path

logger = logging.getLogger(__name__)

_SYSTEM = platform.system()


class GUICapability:
    namespace = "gui"
    actions = [
        "screenshot", "screenshot_region", "click", "double_click", "right_click",
        "type", "key", "scroll", "drag", "window_list", "focus_window",
        "move_window", "resize_window",
    ]
    description = "GUI automation (screen capture + input injection)"

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "screenshot":
                return await self._screenshot(params)
            case "screenshot_region":
                return await self._screenshot_region(params)
            case "click":
                return await self._click(params)
            case "double_click":
                return await self._double_click(params)
            case "right_click":
                return await self._right_click(params)
            case "type":
                return await self._type(params)
            case "key":
                return await self._key(params)
            case "scroll":
                return await self._scroll(params)
            case "drag":
                return await self._drag(params)
            case "window_list":
                return await self._window_list()
            case "focus_window":
                return await self._focus_window(params)
            case "move_window":
                return await self._move_window(params)
            case "resize_window":
                return await self._resize_window(params)
            case _:
                return {"error": f"Unknown gui action: {action}"}

    async def _screenshot(self, params: dict) -> dict:
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            tmp_path = f.name

        try:
            if _SYSTEM == "Darwin":
                proc = await asyncio.create_subprocess_exec(
                    "screencapture", "-x", tmp_path,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await asyncio.wait_for(proc.communicate(), timeout=10)
            elif _SYSTEM == "Linux":
                # Try scrot first, fallback to gnome-screenshot
                for cmd in [["scrot", tmp_path], ["gnome-screenshot", "-f", tmp_path]]:
                    try:
                        proc = await asyncio.create_subprocess_exec(
                            *cmd,
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE,
                        )
                        await asyncio.wait_for(proc.communicate(), timeout=10)
                        if proc.returncode == 0:
                            break
                    except FileNotFoundError:
                        continue
            else:
                return {"error": f"Screenshot not supported on {_SYSTEM}"}

            path = Path(tmp_path)
            if not path.exists() or path.stat().st_size == 0:
                return {"error": "Screenshot capture failed (empty file)"}

            b64 = base64.b64encode(path.read_bytes()).decode()

            # Try to get dimensions
            width, height = 0, 0
            try:
                from PIL import Image

                with Image.open(tmp_path) as img:
                    width, height = img.size
            except ImportError:
                # Fallback: use sips on macOS
                if _SYSTEM == "Darwin":
                    try:
                        sips = subprocess.run(
                            ["sips", "-g", "pixelWidth", "-g", "pixelHeight", tmp_path],
                            capture_output=True,
                            text=True,
                            timeout=5,
                        )
                        for line in sips.stdout.splitlines():
                            if "pixelWidth" in line:
                                width = int(line.split(":")[-1].strip())
                            elif "pixelHeight" in line:
                                height = int(line.split(":")[-1].strip())
                    except Exception:
                        pass

            return {
                "image_base64": b64,
                "format": "png",
                "width": width,
                "height": height,
            }
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def _click(self, params: dict) -> dict:
        x, y = params.get("x", 0), params.get("y", 0)
        button = params.get("button", "left")

        try:
            if _SYSTEM == "Darwin":
                # Try cliclick first, fallback to AppleScript
                try:
                    proc = await asyncio.create_subprocess_exec(
                        "cliclick", f"c:{x},{y}",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
                except FileNotFoundError:
                    # AppleScript fallback
                    script = (
                        f'tell application "System Events" to '
                        f"click at {{{x}, {y}}}"
                    )
                    proc = await asyncio.create_subprocess_exec(
                        "osascript", "-e", script,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
            elif _SYSTEM == "Linux":
                btn_flag = {"left": "1", "middle": "2", "right": "3"}.get(button, "1")
                proc = await asyncio.create_subprocess_exec(
                    "xdotool", "mousemove", str(x), str(y), "click", btn_flag,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
            else:
                return {"error": f"Click not supported on {_SYSTEM}"}

            return {"message": f"Clicked at ({x}, {y})", "x": x, "y": y}
        except Exception as e:
            return {"error": f"Click failed: {e}"}

    async def _type(self, params: dict) -> dict:
        text = params.get("text", "")
        if not text:
            return {"error": "No text provided"}

        try:
            if _SYSTEM == "Darwin":
                try:
                    proc = await asyncio.create_subprocess_exec(
                        "cliclick", f"t:{text}",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
                except FileNotFoundError:
                    script = (
                        f'tell application "System Events" to '
                        f'keystroke "{text}"'
                    )
                    proc = await asyncio.create_subprocess_exec(
                        "osascript", "-e", script,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "xdotool", "type", "--clearmodifiers", text,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
            else:
                return {"error": f"Type not supported on {_SYSTEM}"}

            return {"message": f"Typed {len(text)} characters"}
        except Exception as e:
            return {"error": f"Type failed: {e}"}

    async def _key(self, params: dict) -> dict:
        key = params.get("key", "")
        if not key:
            return {"error": "No key provided"}

        try:
            if _SYSTEM == "Darwin":
                # Map common keys to osascript format
                key_map = {
                    "enter": "return",
                    "tab": "tab",
                    "escape": "escape",
                    "space": "space",
                    "delete": "delete",
                    "backspace": "delete",
                }

                if "+" in key:
                    # Key combination like cmd+c
                    parts = key.lower().split("+")
                    modifiers = []
                    actual_key = parts[-1]

                    for mod in parts[:-1]:
                        mod_map = {
                            "cmd": "command down",
                            "command": "command down",
                            "ctrl": "control down",
                            "control": "control down",
                            "alt": "option down",
                            "option": "option down",
                            "shift": "shift down",
                        }
                        if mod in mod_map:
                            modifiers.append(mod_map[mod])

                    mod_str = ", ".join(modifiers)
                    script = (
                        f'tell application "System Events" to '
                        f'keystroke "{actual_key}" using {{{mod_str}}}'
                    )
                else:
                    mapped = key_map.get(key.lower(), key)
                    if len(mapped) == 1:
                        script = (
                            f'tell application "System Events" to '
                            f'keystroke "{mapped}"'
                        )
                    else:
                        script = (
                            f'tell application "System Events" to '
                            f"key code {_get_key_code(mapped)}"
                        )

                proc = await asyncio.create_subprocess_exec(
                    "osascript", "-e", script,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
            elif _SYSTEM == "Linux":
                # xdotool format: ctrl+c → "ctrl+c"
                proc = await asyncio.create_subprocess_exec(
                    "xdotool", "key", key,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
            else:
                return {"error": f"Key not supported on {_SYSTEM}"}

            return {"message": f"Pressed: {key}"}
        except Exception as e:
            return {"error": f"Key failed: {e}"}

    async def _scroll(self, params: dict) -> dict:
        dx = params.get("dx", 0)
        dy = params.get("dy", 0)  # positive = down

        try:
            if _SYSTEM == "Darwin":
                try:
                    direction = "du" if dy < 0 else "dd"
                    amount = abs(dy) if dy else abs(dx)
                    proc = await asyncio.create_subprocess_exec(
                        "cliclick", f"{direction}:{amount}",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
                except FileNotFoundError:
                    return {"error": "cliclick not installed (brew install cliclick)"}
            elif _SYSTEM == "Linux":
                button = "5" if dy > 0 else "4"
                clicks = str(max(abs(dy) // 3, 1))
                proc = await asyncio.create_subprocess_exec(
                    "xdotool", "click", "--repeat", clicks, button,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
            return {"message": f"Scrolled dx={dx} dy={dy}"}
        except Exception as e:
            return {"error": f"Scroll failed: {e}"}

    async def _screenshot_region(self, params: dict) -> dict:
        x = params.get("x", 0)
        y = params.get("y", 0)
        width = params.get("width", 100)
        height = params.get("height", 100)

        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as f:
            tmp_path = f.name

        try:
            if _SYSTEM == "Darwin":
                proc = await asyncio.create_subprocess_exec(
                    "screencapture", "-x", "-R", f"{x},{y},{width},{height}", tmp_path,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await asyncio.wait_for(proc.communicate(), timeout=10)
            elif _SYSTEM == "Linux":
                # scrot -a x,y,width,height
                proc = await asyncio.create_subprocess_exec(
                    "scrot", "-a", f"{x},{y},{width},{height}", tmp_path,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await asyncio.wait_for(proc.communicate(), timeout=10)
            else:
                return {"error": f"Screenshot region not supported on {_SYSTEM}"}

            path = Path(tmp_path)
            if not path.exists() or path.stat().st_size == 0:
                return {"error": "Screenshot region capture failed (empty file)"}

            b64 = base64.b64encode(path.read_bytes()).decode()

            # Try to get dimensions
            img_width, img_height = 0, 0
            try:
                from PIL import Image

                with Image.open(tmp_path) as img:
                    img_width, img_height = img.size
            except ImportError:
                if _SYSTEM == "Darwin":
                    try:
                        sips = subprocess.run(
                            ["sips", "-g", "pixelWidth", "-g", "pixelHeight", tmp_path],
                            capture_output=True,
                            text=True,
                            timeout=5,
                        )
                        for line in sips.stdout.splitlines():
                            if "pixelWidth" in line:
                                img_width = int(line.split(":")[-1].strip())
                            elif "pixelHeight" in line:
                                img_height = int(line.split(":")[-1].strip())
                    except Exception:
                        pass

            return {
                "image_base64": b64,
                "format": "png",
                "width": img_width,
                "height": img_height,
                "region": {"x": x, "y": y, "width": width, "height": height},
            }
        finally:
            Path(tmp_path).unlink(missing_ok=True)

    async def _double_click(self, params: dict) -> dict:
        x, y = params.get("x", 0), params.get("y", 0)

        try:
            if _SYSTEM == "Darwin":
                try:
                    proc = await asyncio.create_subprocess_exec(
                        "cliclick", f"dc:{x},{y}",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
                except FileNotFoundError:
                    script = (
                        f'tell application "System Events" to '
                        f"click at {{{x}, {y}}}"
                    )
                    for _ in range(2):
                        proc = await asyncio.create_subprocess_exec(
                            "osascript", "-e", script,
                            stdout=asyncio.subprocess.PIPE,
                            stderr=asyncio.subprocess.PIPE,
                        )
                        await proc.communicate()
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "xdotool", "mousemove", str(x), str(y),
                    "click", "--repeat", "2", "1",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
            else:
                return {"error": f"Double click not supported on {_SYSTEM}"}

            return {"message": f"Double-clicked at ({x}, {y})", "x": x, "y": y}
        except Exception as e:
            return {"error": f"Double click failed: {e}"}

    async def _right_click(self, params: dict) -> dict:
        x, y = params.get("x", 0), params.get("y", 0)

        try:
            if _SYSTEM == "Darwin":
                try:
                    proc = await asyncio.create_subprocess_exec(
                        "cliclick", f"rc:{x},{y}",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
                except FileNotFoundError:
                    script = (
                        f'tell application "System Events" to '
                        f"click at {{{x}, {y}}} using {{control down}}"
                    )
                    proc = await asyncio.create_subprocess_exec(
                        "osascript", "-e", script,
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "xdotool", "mousemove", str(x), str(y), "click", "3",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
            else:
                return {"error": f"Right click not supported on {_SYSTEM}"}

            return {"message": f"Right-clicked at ({x}, {y})", "x": x, "y": y}
        except Exception as e:
            return {"error": f"Right click failed: {e}"}

    async def _drag(self, params: dict) -> dict:
        from_x = params.get("from_x", 0)
        from_y = params.get("from_y", 0)
        to_x = params.get("to_x", 0)
        to_y = params.get("to_y", 0)

        try:
            if _SYSTEM == "Darwin":
                try:
                    proc = await asyncio.create_subprocess_exec(
                        "cliclick", f"dd:{from_x},{from_y}", f"du:{to_x},{to_y}",
                        stdout=asyncio.subprocess.PIPE,
                        stderr=asyncio.subprocess.PIPE,
                    )
                    await proc.communicate()
                except FileNotFoundError:
                    return {"error": "cliclick not installed (brew install cliclick)"}
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "xdotool",
                    "mousemove", str(from_x), str(from_y),
                    "mousedown", "1",
                    "mousemove", "--sync", str(to_x), str(to_y),
                    "mouseup", "1",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                await proc.communicate()
            else:
                return {"error": f"Drag not supported on {_SYSTEM}"}

            return {
                "message": f"Dragged from ({from_x}, {from_y}) to ({to_x}, {to_y})",
                "from_x": from_x,
                "from_y": from_y,
                "to_x": to_x,
                "to_y": to_y,
            }
        except Exception as e:
            return {"error": f"Drag failed: {e}"}

    async def _focus_window(self, params: dict) -> dict:
        app_name = params.get("app_name", "")
        if not app_name:
            return {"error": "No app_name provided"}

        try:
            if _SYSTEM == "Darwin":
                script = f'tell application "{app_name}" to activate'
                proc = await asyncio.create_subprocess_exec(
                    "osascript", "-e", script,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await proc.communicate()
                if proc.returncode != 0:
                    return {"error": f"Focus failed: {stderr.decode().strip()}"}
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "wmctrl", "-a", app_name,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await proc.communicate()
                if proc.returncode != 0:
                    return {"error": f"Focus failed: {stderr.decode().strip()}"}
            else:
                return {"error": f"Focus window not supported on {_SYSTEM}"}

            return {"message": f"Focused window: {app_name}"}
        except Exception as e:
            return {"error": f"Focus window failed: {e}"}

    async def _move_window(self, params: dict) -> dict:
        x, y = params.get("x", 0), params.get("y", 0)
        app_name = params.get("app_name", "")

        try:
            if _SYSTEM == "Darwin":
                if app_name:
                    script = (
                        f'tell application "System Events" to '
                        f'tell process "{app_name}" to '
                        f"set position of front window to {{{x}, {y}}}"
                    )
                else:
                    script = (
                        f'tell application "System Events" to '
                        f"tell (first process whose frontmost is true) to "
                        f"set position of front window to {{{x}, {y}}}"
                    )
                proc = await asyncio.create_subprocess_exec(
                    "osascript", "-e", script,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await proc.communicate()
                if proc.returncode != 0:
                    return {"error": f"Move window failed: {stderr.decode().strip()}"}
            elif _SYSTEM == "Linux":
                target = app_name if app_name else ":ACTIVE:"
                proc = await asyncio.create_subprocess_exec(
                    "wmctrl", "-r", target, "-e", f"0,{x},{y},-1,-1",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await proc.communicate()
                if proc.returncode != 0:
                    return {"error": f"Move window failed: {stderr.decode().strip()}"}
            else:
                return {"error": f"Move window not supported on {_SYSTEM}"}

            return {"message": f"Moved window to ({x}, {y})", "x": x, "y": y}
        except Exception as e:
            return {"error": f"Move window failed: {e}"}

    async def _resize_window(self, params: dict) -> dict:
        width = params.get("width", 800)
        height = params.get("height", 600)
        app_name = params.get("app_name", "")

        try:
            if _SYSTEM == "Darwin":
                if app_name:
                    script = (
                        f'tell application "System Events" to '
                        f'tell process "{app_name}" to '
                        f"set size of front window to {{{width}, {height}}}"
                    )
                else:
                    script = (
                        f'tell application "System Events" to '
                        f"tell (first process whose frontmost is true) to "
                        f"set size of front window to {{{width}, {height}}}"
                    )
                proc = await asyncio.create_subprocess_exec(
                    "osascript", "-e", script,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await proc.communicate()
                if proc.returncode != 0:
                    return {"error": f"Resize window failed: {stderr.decode().strip()}"}
            elif _SYSTEM == "Linux":
                target = app_name if app_name else ":ACTIVE:"
                proc = await asyncio.create_subprocess_exec(
                    "wmctrl", "-r", target, "-e", f"0,-1,-1,{width},{height}",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                _, stderr = await proc.communicate()
                if proc.returncode != 0:
                    return {"error": f"Resize window failed: {stderr.decode().strip()}"}
            else:
                return {"error": f"Resize window not supported on {_SYSTEM}"}

            return {
                "message": f"Resized window to {width}x{height}",
                "width": width,
                "height": height,
            }
        except Exception as e:
            return {"error": f"Resize window failed: {e}"}

    async def _window_list(self) -> dict:
        try:
            if _SYSTEM == "Darwin":
                script = (
                    'tell application "System Events" to '
                    "get name of every process whose visible is true"
                )
                proc = await asyncio.create_subprocess_exec(
                    "osascript", "-e", script,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await proc.communicate()
                apps = [a.strip() for a in stdout.decode().split(",") if a.strip()]
                return {"windows": apps, "count": len(apps)}
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "wmctrl", "-l",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await proc.communicate()
                lines = stdout.decode().strip().split("\n")
                return {"windows": lines, "count": len(lines)}
            return {"error": f"Window list not supported on {_SYSTEM}"}
        except Exception as e:
            return {"error": f"Window list failed: {e}"}


def _get_key_code(key_name: str) -> int:
    """Map key name to macOS virtual key code."""
    codes = {
        "return": 36, "tab": 48, "space": 49, "delete": 51,
        "escape": 53, "f1": 122, "f2": 120, "f3": 99,
        "up": 126, "down": 125, "left": 123, "right": 124,
    }
    return codes.get(key_name.lower(), 0)
