"""System information and process management capability."""

from __future__ import annotations

import asyncio
import logging
import os
import platform
import shutil

logger = logging.getLogger(__name__)

_SYSTEM = platform.system()

_SENSITIVE_KEYWORDS = {"KEY", "SECRET", "TOKEN", "PASSWORD", "CREDENTIAL", "PRIVATE"}


class SystemCapability:
    namespace = "system"
    actions = ["info", "processes", "kill_process", "env", "disk_usage"]
    description = "System information, process management, and resource monitoring"

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "info":
                return await self._info()
            case "processes":
                return await self._processes()
            case "kill_process":
                return await self._kill_process(params)
            case "env":
                return self._env()
            case "disk_usage":
                return self._disk_usage()
            case _:
                return {"error": f"Unknown system action: {action}"}

    async def _info(self) -> dict:
        info: dict = {
            "os": platform.system(),
            "arch": platform.machine(),
            "hostname": platform.node(),
            "python_version": platform.python_version(),
            "cpu_count": os.cpu_count() or 0,
        }

        # Total memory
        total_memory = await self._get_total_memory()
        if total_memory:
            info["total_memory_bytes"] = total_memory
            info["total_memory_gb"] = round(total_memory / (1024**3), 2)

        # Total disk
        try:
            usage = shutil.disk_usage("/")
            info["total_disk_bytes"] = usage.total
            info["total_disk_gb"] = round(usage.total / (1024**3), 2)
        except Exception as e:
            logger.warning("Failed to get disk usage: %s", e)

        return info

    async def _get_total_memory(self) -> int | None:
        try:
            if _SYSTEM == "Darwin":
                proc = await asyncio.create_subprocess_exec(
                    "sysctl",
                    "hw.memsize",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
                # Output: "hw.memsize: 17179869184"
                line = stdout.decode().strip()
                return int(line.split(":")[-1].strip())
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "cat",
                    "/proc/meminfo",
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
                stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=5)
                for line in stdout.decode().splitlines():
                    if line.startswith("MemTotal:"):
                        # "MemTotal:       16384000 kB"
                        parts = line.split()
                        return int(parts[1]) * 1024  # kB → bytes
        except Exception as e:
            logger.warning("Failed to get total memory: %s", e)
        return None

    async def _processes(self) -> dict:
        try:
            if _SYSTEM == "Darwin":
                cmd = ["ps", "aux", "-r"]  # macOS: -r sorts by CPU descending
            else:
                cmd = ["ps", "aux", "--sort=-pcpu"]

            proc = await asyncio.create_subprocess_exec(
                *cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout, _ = await asyncio.wait_for(proc.communicate(), timeout=10)

            lines = stdout.decode(errors="replace").strip().splitlines()
            processes = []
            # Skip header line
            for line in lines[1:21]:  # Top 20
                parts = line.split(None, 10)
                if len(parts) >= 11:
                    processes.append(
                        {
                            "pid": int(parts[1]),
                            "name": parts[10].split()[0] if parts[10] else parts[10],
                            "cpu": float(parts[2]),
                            "memory": float(parts[3]),
                            "command": parts[10],
                        }
                    )

            return {"processes": processes, "count": len(processes)}
        except Exception as e:
            return {"error": f"Failed to list processes: {e}"}

    async def _kill_process(self, params: dict) -> dict:
        pid = params.get("pid")
        if pid is None:
            return {"error": "No pid provided"}

        try:
            pid = int(pid)
        except (TypeError, ValueError):
            return {"error": f"Invalid pid: {pid} (must be an integer)"}

        try:
            import signal as sig

            os.kill(pid, sig.SIGTERM)
            return {"message": f"Sent SIGTERM to pid {pid}"}
        except ProcessLookupError:
            return {"error": f"Process {pid} not found"}
        except PermissionError:
            return {"error": f"Permission denied to kill process {pid}"}
        except Exception as e:
            return {"error": f"Failed to kill process {pid}: {e}"}

    def _env(self) -> dict:
        filtered = {}
        for key, value in os.environ.items():
            upper_key = key.upper()
            if any(kw in upper_key for kw in _SENSITIVE_KEYWORDS):
                continue
            filtered[key] = value
        return {"environment": filtered, "count": len(filtered)}

    def _disk_usage(self) -> dict:
        try:
            usage = shutil.disk_usage("/")
            percent = round(usage.used / usage.total * 100, 1) if usage.total else 0
            return {
                "total_bytes": usage.total,
                "used_bytes": usage.used,
                "free_bytes": usage.free,
                "total_gb": round(usage.total / (1024**3), 2),
                "used_gb": round(usage.used / (1024**3), 2),
                "free_gb": round(usage.free / (1024**3), 2),
                "percent_used": percent,
            }
        except Exception as e:
            return {"error": f"Failed to get disk usage: {e}"}
