"""Browser URL opening capability."""

from __future__ import annotations

import asyncio
import logging
import platform
from urllib.parse import urlparse

logger = logging.getLogger(__name__)

_SYSTEM = platform.system()

_ALLOWED_SCHEMES = {"http", "https"}


class BrowserCapability:
    namespace = "browser"
    actions = ["open_url"]
    description = "Open URLs in the default browser"

    async def handle(self, action: str, params: dict) -> dict:
        match action:
            case "open_url":
                return await self._open_url(params)
            case _:
                return {"error": f"Unknown browser action: {action}"}

    async def _open_url(self, params: dict) -> dict:
        url = params.get("url", "")
        if not url:
            return {"error": "No url provided"}

        # Validate scheme
        try:
            parsed = urlparse(url)
        except Exception:
            return {"error": f"Invalid URL: {url}"}

        if parsed.scheme not in _ALLOWED_SCHEMES:
            return {
                "error": f"Unsupported URL scheme: {parsed.scheme!r}. "
                f"Only http and https are allowed."
            }

        try:
            if _SYSTEM == "Darwin":
                proc = await asyncio.create_subprocess_exec(
                    "open",
                    url,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
            elif _SYSTEM == "Linux":
                proc = await asyncio.create_subprocess_exec(
                    "xdg-open",
                    url,
                    stdout=asyncio.subprocess.PIPE,
                    stderr=asyncio.subprocess.PIPE,
                )
            else:
                return {"error": f"Browser opening not supported on {_SYSTEM}"}

            _, stderr = await asyncio.wait_for(proc.communicate(), timeout=10)
            if proc.returncode != 0:
                return {"error": f"Failed to open URL: {stderr.decode(errors='replace')}"}

            return {"message": f"Opened: {url}"}
        except Exception as e:
            return {"error": f"Failed to open URL: {e}"}
