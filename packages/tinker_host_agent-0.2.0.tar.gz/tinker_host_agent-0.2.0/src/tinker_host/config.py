"""Host Agent configuration via pydantic-settings."""

from __future__ import annotations

import platform
import socket
import uuid

from pydantic_settings import BaseSettings


def _default_agent_id() -> str:
    hostname = socket.gethostname().lower().replace(" ", "-")[:20]
    short = uuid.uuid4().hex[:6]
    return f"host-{hostname}-{short}"


def _default_agent_name() -> str:
    return f"{platform.node()} ({platform.system()})"


class HostAgentSettings(BaseSettings):
    model_config = {
        "env_prefix": "TINKER_HOST_",
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "extra": "ignore",
    }

    # Connection
    server_url: str = "ws://localhost:3000/ws/device-agent"
    auth_token: str = ""
    agent_id: str = ""
    agent_name: str = ""
    agent_type: str = "host"  # "host" or "remote"

    # Reconnection
    reconnect_delay: float = 1.0
    reconnect_max_delay: float = 30.0

    # Security
    allowed_paths: str = ""  # comma-separated, empty = home dir
    blocked_paths: str = "~/.ssh,~/.gnupg,~/.aws,~/.config/gcloud"
    blocked_commands: str = "rm -rf /,mkfs,dd if=/dev"

    # Capabilities
    enable_shell: bool = True
    enable_fs: bool = True
    enable_gui: bool = True
    enable_app: bool = True
    enable_clipboard: bool = True
    enable_network: bool = True
    enable_system: bool = True
    enable_notification: bool = True
    enable_browser: bool = True

    # Plugin directory
    plugin_dir: str = ""

    def get_agent_id(self) -> str:
        return self.agent_id or _default_agent_id()

    def get_agent_name(self) -> str:
        return self.agent_name or _default_agent_name()
