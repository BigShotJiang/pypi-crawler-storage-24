from pydantic import BaseModel
from typing import Optional, Any, Dict, List
from datetime import datetime


class UserData(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    problem_summary: Optional[str] = None
    preferences: Optional[str] = None


class User(BaseModel):
    id: int
    unit_id: int
    external_id: str
    content: UserData
    timestamp: datetime


class Message(BaseModel):
    id: int
    user_id: Optional[int] = None
    content: Dict[str, Any]
    timestamp: datetime


class Agent(BaseModel):
    id: int
    prompt: str
    model: str
    chat_limit: int
    timestamp: datetime


class Unit(BaseModel):
    id: int
    agent_id: Optional[int] = None
    ip: Optional[str] = None
    token: str
    is_admin: bool = False
    timestamp: datetime


class RAG(BaseModel):
    id: int
    agent_id: int
    content: Optional[str] = None
    embedding: Optional[List[float]] = None
    metadata: Dict[str, Any] = {}
    timestamp: datetime


class AgentCreate(BaseModel):
    prompt: str
    model: str


class AgentUpdate(BaseModel):
    prompt: Optional[str] = None
    model: Optional[str] = None


class UnitCreate(BaseModel):
    agent_id: Optional[int] = None
    ip: Optional[str] = None


class UnitUpdate(BaseModel):
    agent_id: Optional[int] = None
    ip: Optional[str] = None


class UserCreate(BaseModel):
    external_id: str


class MessageRequest(BaseModel):
    user_id: str
    request: str


class MessageResponse(BaseModel):
    response: str
    user: User


class UserUpdate(BaseModel):
    external_id: Optional[str] = None
    content: Optional[UserData] = None


class RAGCreate(BaseModel):
    content: str
    embedding_content: Optional[str] = None
    metadata: Optional[dict] = None


class RAGUpdate(BaseModel):
    content: str
    embedding_content: Optional[str] = None
    metadata: Optional[dict] = None
