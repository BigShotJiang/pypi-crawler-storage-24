"""COMBO — Universal Dependencies parser with composable NLP pipelines."""

__version__ = "4.0.5"

from .api import COMBO
from .data.conllu_reader import Document, Sentence, Token
from .languages import Language, SplitLevel
from .pipeline import Pipeline

__all__ = [
    "COMBO",
    "Language",
    "SplitLevel",
    "Pipeline",
    "Document",
    "Sentence",
    "Token",
]
