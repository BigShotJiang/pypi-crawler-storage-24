from .forecaster import XceptionMultiHorizon
