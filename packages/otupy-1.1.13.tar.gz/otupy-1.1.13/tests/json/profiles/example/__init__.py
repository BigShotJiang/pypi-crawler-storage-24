import example.args
