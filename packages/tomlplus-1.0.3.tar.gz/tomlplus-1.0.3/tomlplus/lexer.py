"""
tomlplus.lexer — Low-level line preprocessor and tokenizer.

Responsibilities:
  - Strip inline comments (respecting string literals)
  - Classify each non-blank line into a LineToken
  - Expose the raw line stream to the parser
"""

from __future__ import annotations
import re
from dataclasses import dataclass
from enum import Enum, auto

__all__ = ["LineKind", "LineToken", "tokenize_lines"]


class LineKind(Enum):
    BLANK      = auto()   # empty / whitespace-only / comment-only
    SECTION    = auto()   # [section]
    VARS       = auto()   # [vars]
    ANNOTATION = auto()   # @name ...
    KV         = auto()   # key = value
    BLOCK_OPEN = auto()   # key = #{
    BLOCK_CLOSE= auto()   # }#


@dataclass
class LineToken:
    kind:    LineKind
    raw:     str          # original text
    content: str          # stripped & comment-removed
    lineno:  int
    # For KV / BLOCK_OPEN
    key:     str  = ""
    value:   str  = ""    # rhs (empty for BLOCK_OPEN)
    # For SECTION
    section: str  = ""
    # For ANNOTATION
    annotation_text: str = ""


_SECTION_RE = re.compile(r"^\[([^\[\]]+)\]$")
_KV_RE      = re.compile(r"^([a-zA-Z0-9_\-]+)\s*=\s*(.+)$")


def _strip_comment(line: str) -> str:
    """Remove trailing # comment, ignoring # inside quoted strings and dict delimiters."""
    in_str = False
    esc    = False
    for i, ch in enumerate(line):
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if ch == "#" and not in_str:
            # #{ is a block-dict open delimiter — not a comment
            if i + 1 < len(line) and line[i + 1] == "{":
                continue
            # }# is a block-dict close delimiter — the # here closes the token;
            # check if the preceding non-space char is }
            preceding = line[:i].rstrip()
            if preceding.endswith("}"):
                continue
            return line[:i].rstrip()
    return line


def tokenize_lines(source: str) -> list[LineToken]:
    tokens: list[LineToken] = []

    for lineno, raw in enumerate(source.splitlines(), 1):
        content = _strip_comment(raw).strip()

        if not content:
            tokens.append(LineToken(LineKind.BLANK, raw, content, lineno))
            continue

        # [vars] special section
        if content == "[vars]":
            tokens.append(LineToken(LineKind.VARS, raw, content, lineno))
            continue

        # Section header
        m = _SECTION_RE.match(content)
        if m:
            tok = LineToken(LineKind.SECTION, raw, content, lineno)
            tok.section = m.group(1)
            tokens.append(tok)
            continue

        # Annotation
        if content.startswith("@"):
            tok = LineToken(LineKind.ANNOTATION, raw, content, lineno)
            tok.annotation_text = content
            tokens.append(tok)
            continue

        # Block dict close
        if content == "}#":
            tokens.append(LineToken(LineKind.BLOCK_CLOSE, raw, content, lineno))
            continue

        # Key = value (or key = #{)
        m = _KV_RE.match(content)
        if m:
            key = m.group(1)
            rhs = m.group(2).strip()
            if rhs == "#{":
                tok = LineToken(LineKind.BLOCK_OPEN, raw, content, lineno, key=key)
            else:
                tok = LineToken(LineKind.KV, raw, content, lineno, key=key, value=rhs)
            tokens.append(tok)
            continue

        # Fall-through: treat as blank (or raise in strict mode)
        tokens.append(LineToken(LineKind.BLANK, raw, content, lineno))

    return tokens
