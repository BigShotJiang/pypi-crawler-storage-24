"""
tomlplus.errors — Exception hierarchy
"""

__all__ = ["TOMLPlusError", "ParseError", "ValidationError", "VariableError"]


class TOMLPlusError(Exception):
    """Base class for all TOML+ errors."""


class ParseError(TOMLPlusError):
    """Raised when the source cannot be parsed."""

    def __init__(self, message: str, line: int | None = None, col: int | None = None):
        self.line    = line
        self.col     = col
        location     = ""
        if line is not None:
            location = f" (line {line}" + (f", col {col}" if col is not None else "") + ")"
        super().__init__(f"{message}{location}")


class ValidationError(TOMLPlusError):
    """Raised when a value fails an annotation constraint."""

    def __init__(self, message: str, key: str | None = None):
        self.key = key
        prefix   = f"[{key}] " if key else ""
        super().__init__(f"{prefix}{message}")


class VariableError(TOMLPlusError):
    """Raised when a variable reference cannot be resolved."""

    def __init__(self, message: str, variable: str | None = None, line: int | None = None):
        self.variable = variable
        self.line     = line
        location      = f" (line {line})" if line is not None else ""
        super().__init__(f"{message}{location}")
