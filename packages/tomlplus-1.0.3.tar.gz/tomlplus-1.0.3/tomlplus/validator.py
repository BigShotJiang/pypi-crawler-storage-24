"""
tomlplus.validator — Validate a parsed document against its annotations.
"""

from __future__ import annotations
import re
from typing import Any

from .errors import ValidationError
from .models import Annotation, TOMLPlusDocument

__all__ = ["validate", "validate_all"]


# ─── Type checkers ────────────────────────────────────────────────────────────

def _check_type(value: Any, type_name: str) -> bool:
    checks: dict[str, Any] = {
        "string":      lambda v: isinstance(v, str),
        "int":         lambda v: isinstance(v, int) and not isinstance(v, bool),
        "float":       lambda v: isinstance(v, (int, float)) and not isinstance(v, bool),
        "bool":        lambda v: isinstance(v, bool),
        "dict":        lambda v: isinstance(v, dict),
        "list":        lambda v: isinstance(v, list),
        "list[string]":lambda v: isinstance(v, list) and all(isinstance(i, str)  for i in v),
        "list[int]":   lambda v: isinstance(v, list) and all(isinstance(i, int) and not isinstance(i, bool) for i in v),
        "list[float]": lambda v: isinstance(v, list) and all(isinstance(i, (int, float)) for i in v),
        "list[bool]":  lambda v: isinstance(v, list) and all(isinstance(i, bool) for i in v),
        "url":         lambda v: isinstance(v, str) and re.match(r"^https?://\S+", v) is not None,
        "email":       lambda v: isinstance(v, str) and re.match(r"^[^@\s]+@[^@\s]+\.[^@\s]+$", v) is not None,
        "path":        lambda v: isinstance(v, str),   # existence not checked
        "duration":    lambda v: isinstance(v, str) and re.match(r"^\d+[smhd]$", v) is not None,
    }
    fn = checks.get(type_name)
    return fn(value) if fn else True   # unknown type names pass silently


# ─── Single-key validation ────────────────────────────────────────────────────

def _validate_key(key: str, value: Any, annotations: list[Annotation]) -> None:
    """
    Run all annotation constraints for one key.

    Raises :class:`ValidationError` on the *first* failing constraint.
    """
    # Index annotations by name for fast lookup
    ann_map: dict[str, list[Annotation]] = {}
    for ann in annotations:
        ann_map.setdefault(ann.name, []).append(ann)

    # @required
    if "required" in ann_map:
        if value is None or value == "" or value == [] or value == {}:
            raise ValidationError("value is @required but is empty or null", key)

    # @type
    if "type" in ann_map:
        t = ann_map["type"][0].arg
        if t and not _check_type(value, t):
            raise ValidationError(
                f"expected @type: {t}, got {type(value).__name__}", key
            )

    # @min
    if "min" in ann_map:
        n = ann_map["min"][0].arg
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value < n:
            raise ValidationError(f"value {value} is below @min: {n}", key)

    # @max
    if "max" in ann_map:
        n = ann_map["max"][0].arg
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value > n:
            raise ValidationError(f"value {value} exceeds @max: {n}", key)

    # @minlen
    if "minlen" in ann_map:
        n = ann_map["minlen"][0].arg
        if hasattr(value, "__len__") and len(value) < n:
            raise ValidationError(
                f"length {len(value)} is below @minlen: {n}", key
            )

    # @maxlen
    if "maxlen" in ann_map:
        n = ann_map["maxlen"][0].arg
        if hasattr(value, "__len__") and len(value) > n:
            raise ValidationError(
                f"length {len(value)} exceeds @maxlen: {n}", key
            )

    # @pattern
    if "pattern" in ann_map:
        pat = ann_map["pattern"][0].arg
        if isinstance(value, str) and pat and not re.fullmatch(pat, value):
            raise ValidationError(
                f"value {value!r} does not match @pattern: {pat!r}", key
            )

    # @enum
    if "enum" in ann_map:
        choices = ann_map["enum"][0].arg
        if isinstance(choices, list) and value not in choices:
            raise ValidationError(
                f"value {value!r} not in @enum: [{', '.join(str(c) for c in choices)}]",
                key,
            )

    # @positive
    if "positive" in ann_map:
        if isinstance(value, (int, float)) and not isinstance(value, bool) and value <= 0:
            raise ValidationError(f"value {value} must be @positive (> 0)", key)

    # @nonzero
    if "nonzero" in ann_map:
        if value == 0:
            raise ValidationError("value must be @nonzero", key)

    # @nonempty
    if "nonempty" in ann_map:
        if not value:
            raise ValidationError("value must be @nonempty", key)


# ─── Document-level validators ────────────────────────────────────────────────

def validate(doc: TOMLPlusDocument) -> None:
    """
    Validate all annotated keys in *doc*.

    Raises :class:`ValidationError` on the first constraint that is violated.

    Parameters
    ----------
    doc : TOMLPlusDocument
        The parsed document returned by :func:`tomlplus.loads`.

    Raises
    ------
    ValidationError
    """
    for fqkey, annotations in doc.meta.items():
        value = doc.resolve(fqkey)
        _validate_key(fqkey, value, annotations)


def validate_all(doc: TOMLPlusDocument) -> list[ValidationError]:
    """
    Like :func:`validate` but collects *all* errors instead of stopping
    at the first one.

    Returns
    -------
    list[ValidationError]
        Empty list if the document is valid.
    """
    errors: list[ValidationError] = []
    for fqkey, annotations in doc.meta.items():
        value = doc.resolve(fqkey)
        try:
            _validate_key(fqkey, value, annotations)
        except ValidationError as exc:
            errors.append(exc)
    return errors
