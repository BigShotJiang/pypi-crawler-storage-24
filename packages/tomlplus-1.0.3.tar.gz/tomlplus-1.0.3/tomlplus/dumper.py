"""
tomlplus.dumper — Serialize a config dict (or TOMLPlusDocument) back to TOML+ text.

This is a best-effort round-trip serializer.  Annotation metadata is
preserved when a ``TOMLPlusDocument`` is passed.
"""

from __future__ import annotations
from typing import Any

from .models import TOMLPlusDocument, Annotation

__all__ = ["dumps"]


def dumps(data: dict | TOMLPlusDocument) -> str:
    """
    Serialize *data* to a TOML+ formatted string.

    Parameters
    ----------
    data : dict or TOMLPlusDocument
        The configuration to serialize.  If a :class:`TOMLPlusDocument`
        is passed, annotation metadata is included in the output.

    Returns
    -------
    str
    """
    if isinstance(data, TOMLPlusDocument):
        config = data.config
        meta   = data.meta
        vars_  = data.vars
    else:
        config = data
        meta   = {}
        vars_  = {}

    lines: list[str] = []

    # ── [vars] ────────────────────────────────────────────────────────────────
    if vars_:
        lines.append("[vars]")
        for k, v in vars_.items():
            lines.append(f"{k} = {_format_value(v)}")
        lines.append("")

    # ── Top-level keys ────────────────────────────────────────────────────────
    top_keys = {k: v for k, v in config.items() if not isinstance(v, dict)}
    if top_keys:
        for k, v in top_keys.items():
            fqk = k
            _append_annotations(lines, meta.get(fqk, []))
            lines.append(f"{k} = {_format_value(v)}")
        lines.append("")

    # ── Sections ──────────────────────────────────────────────────────────────
    sections = {k: v for k, v in config.items() if isinstance(v, dict)}
    for section, contents in sections.items():
        sec_anns = meta.get(section, [])
        _append_annotations(lines, sec_anns)
        lines.append(f"[{section}]")

        for k, v in contents.items():
            fqk = f"{section}.{k}"
            key_anns = meta.get(fqk, [])
            _append_annotations(lines, key_anns)

            if isinstance(v, dict):
                lines.append(f"{k} = {{#")
                for dk, dv in v.items():
                    dfqk = f"{fqk}.{dk}"
                    _append_annotations(lines, meta.get(dfqk, []), indent="  ")
                    lines.append(f"  {dk} = {_format_value(dv)}")
                lines.append("}#")
            else:
                lines.append(f"{k} = {_format_value(v)}")

        lines.append("")

    return "\n".join(lines).rstrip() + "\n"


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _append_annotations(
    lines: list[str],
    annotations: list[Annotation],
    indent: str = "",
) -> None:
    for ann in annotations:
        lines.append(f"{indent}{ann}")


def _format_value(v: Any) -> str:
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "true" if v else "false"
    if isinstance(v, int):
        return str(v)
    if isinstance(v, float):
        return repr(v)
    if isinstance(v, str):
        escaped = v.replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n").replace("\t", "\\t")
        return f'"{escaped}"'
    if isinstance(v, list):
        items = ", ".join(_format_value(i) for i in v)
        return f"[{items}]"
    if isinstance(v, dict):
        pairs = ", ".join(f"{k} = {_format_value(val)}" for k, val in v.items())
        return "#{ " + pairs + " }"
    return str(v)
