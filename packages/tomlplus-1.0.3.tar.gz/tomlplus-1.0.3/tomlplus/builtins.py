"""
tomlplus.builtins — Built-in variable constants ($NOW, $HOSTNAME, etc.)
"""

import os
import socket
import platform
from datetime import datetime, timezone

__all__ = ["get_builtins"]

_STATIC: dict | None = None   # lazily populated once per process


def get_builtins(*, fresh: bool = False) -> dict:
    """
    Return the dict of built-in constants.

    By default the result is cached for the process lifetime so that
    $NOW and $TODAY remain stable within a single parse.  Pass
    ``fresh=True`` to regenerate (useful in long-running processes).
    """
    global _STATIC
    if _STATIC is None or fresh:
        now     = datetime.now(timezone.utc)
        _STATIC = {
            "NOW":      now.isoformat(),
            "TODAY":    now.strftime("%Y-%m-%d"),
            "TRUE":     True,
            "FALSE":    False,
            "NULL":     None,
            "PID":      os.getpid(),
            "HOSTNAME": _safe(socket.gethostname, "unknown"),
            "PLATFORM": platform.system().lower(),
            "CWD":      os.getcwd(),
        }
    return _STATIC


def _safe(fn, fallback):
    try:
        return fn()
    except Exception:
        return fallback
