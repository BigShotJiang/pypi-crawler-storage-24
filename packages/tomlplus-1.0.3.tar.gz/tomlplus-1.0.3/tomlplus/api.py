"""
tomlplus.api — Top-level convenience functions (load / loads / dumps).
"""

from __future__ import annotations
from pathlib import Path
from typing import Any

from .parser    import TOMLPlusParser
from .validator import validate
from .dumper    import dumps as _dumps
from .models    import TOMLPlusDocument

__all__ = ["load", "loads", "load_validated", "loads_validated", "dumps"]


def loads(source: str) -> TOMLPlusDocument:
    """
    Parse a TOML+ string and return a :class:`~tomlplus.TOMLPlusDocument`.

    Parameters
    ----------
    source : str
        Raw TOML+ source text.

    Returns
    -------
    TOMLPlusDocument

    Raises
    ------
    ParseError
        If the source is syntactically invalid.
    VariableError
        If an undefined variable is referenced.

    Examples
    --------
    >>> import tomlplus
    >>> doc = tomlplus.loads('''
    ... [server]
    ... port = 8080
    ... ''')
    >>> doc["server"]["port"]
    8080
    """
    return TOMLPlusParser().parse(source)


def load(path: str | Path) -> TOMLPlusDocument:
    """
    Parse a ``.tomlp`` file and return a :class:`~tomlplus.TOMLPlusDocument`.

    Parameters
    ----------
    path : str or Path
        Path to the ``.tomlp`` file.

    Returns
    -------
    TOMLPlusDocument

    Raises
    ------
    FileNotFoundError
        If the file does not exist.
    ParseError / VariableError
        On parse failure.

    Examples
    --------
    >>> doc = tomlplus.load("config.tomlp")
    >>> doc.resolve("database.host")
    'localhost'
    """
    path = Path(path)
    return loads(path.read_text(encoding="utf-8"))


def loads_validated(source: str) -> TOMLPlusDocument:
    """
    Parse *and* validate a TOML+ string.

    Equivalent to calling :func:`loads` followed by
    :func:`~tomlplus.validate`.

    Returns
    -------
    TOMLPlusDocument

    Raises
    ------
    ParseError, VariableError, ValidationError
    """
    doc = loads(source)
    validate(doc)
    return doc


def load_validated(path: str | Path) -> TOMLPlusDocument:
    """
    Parse *and* validate a ``.tomlp`` file.

    Returns
    -------
    TOMLPlusDocument

    Raises
    ------
    FileNotFoundError, ParseError, VariableError, ValidationError
    """
    doc = load(path)
    validate(doc)
    return doc


def dumps(data: dict | TOMLPlusDocument) -> str:
    """
    Serialize *data* to a TOML+ formatted string.

    Parameters
    ----------
    data : dict or TOMLPlusDocument
        Configuration to serialize.  Passing a :class:`TOMLPlusDocument`
        preserves annotation metadata in the output.

    Returns
    -------
    str

    Examples
    --------
    >>> tomlplus.dumps({"server": {"port": 8080}})
    '[server]\\nport = 8080\\n'
    """
    return _dumps(data)
