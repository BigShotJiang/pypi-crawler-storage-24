"""
tomlplus — TOML+ configuration format library
"""

from .parser   import TOMLPlusParser
from .validator import validate, validate_all
from .errors   import TOMLPlusError, ParseError, ValidationError, VariableError
from .models   import Annotation, TOMLPlusDocument
from .api      import load, loads, load_validated, loads_validated, dumps

__version__ = "1.0.0"
__all__ = [
    # Main API
    "load",
    "loads",
    "load_validated",
    "loads_validated",
    "dumps",
    # Classes
    "TOMLPlusDocument",
    "Annotation",
    "TOMLPlusParser",
    # Validation
    "validate",
    "validate_all",
    # Errors
    "TOMLPlusError",
    "ParseError",
    "ValidationError",
    "VariableError",
]
