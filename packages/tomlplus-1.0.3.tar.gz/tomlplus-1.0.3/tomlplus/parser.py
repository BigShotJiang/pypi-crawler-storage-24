"""
tomlplus.parser — Two-pass TOML+ parser.

Pass 1 — collect ``[vars]`` and resolve user-defined variables.
Pass 2 — parse the full document (sections, keys, block dicts, annotations).
"""

from __future__ import annotations
from typing import Any

from .errors      import ParseError
from .models      import Annotation, TOMLPlusDocument
from .builtins    import get_builtins
from .lexer       import tokenize_lines, LineKind, LineToken
from .values      import ValueParser
from .annotations import parse_annotation

__all__ = ["TOMLPlusParser"]


class TOMLPlusParser:
    """
    Stateful parser.  Create a new instance for each document.

    Usage
    -----
    parser = TOMLPlusParser()
    doc    = parser.parse(source_string)
    """

    def __init__(self):
        self._user_vars: dict           = {}
        self._config:    dict           = {}
        self._meta:      dict[str, list[Annotation]] = {}

        self._pending_ann:  list[Annotation] = []
        self._current_section: str | None    = None

        # Block-dict accumulation state
        self._in_block    = False
        self._block_key   = ""
        self._block_data: dict = {}
        self._block_pending: list[Annotation] = []

    # ── Public ────────────────────────────────────────────────────────────────

    def parse(self, source: str) -> TOMLPlusDocument:
        tokens = tokenize_lines(source)
        self._pass1_vars(tokens)
        vp = ValueParser(variables=dict(self._user_vars), line_no=0)
        self._pass2_main(tokens, vp)
        return TOMLPlusDocument(
            config=self._config,
            meta=self._meta,
            vars_=dict(self._user_vars),
        )

    # ── Pass 1: resolve [vars] ────────────────────────────────────────────────

    def _pass1_vars(self, tokens: list[LineToken]) -> None:
        builtins = get_builtins()
        vp       = ValueParser(variables={}, line_no=0)
        in_vars  = False

        for tok in tokens:
            if tok.kind == LineKind.VARS:
                in_vars = True
                continue
            if tok.kind == LineKind.SECTION:
                in_vars = False
                continue
            if not in_vars:
                continue
            if tok.kind == LineKind.KV:
                vp.line_no = tok.lineno
                # user vars can reference builtins and earlier user vars
                vp._vars = {**builtins, **self._user_vars}
                val = vp.parse(tok.value)
                self._user_vars[tok.key] = val

    # ── Pass 2: main document ─────────────────────────────────────────────────

    def _pass2_main(self, tokens: list[LineToken], vp: ValueParser) -> None:
        # Merged variable scope for value parsing
        merged = {**get_builtins(), **self._user_vars}
        vp._vars = merged

        in_vars = False

        for tok in tokens:
            vp.line_no = tok.lineno

            # ── Block dict accumulation ───────────────────────────────────
            if self._in_block:
                self._handle_block_token(tok, vp)
                continue

            # ── [vars] skip ───────────────────────────────────────────────
            if tok.kind == LineKind.VARS:
                in_vars = True
                continue

            if tok.kind in (LineKind.SECTION, LineKind.BLOCK_OPEN,
                            LineKind.KV, LineKind.ANNOTATION):
                if tok.kind != LineKind.SECTION and in_vars:
                    continue  # still inside [vars]

            if tok.kind == LineKind.SECTION:
                in_vars = False

            # ── Blank ─────────────────────────────────────────────────────
            if tok.kind == LineKind.BLANK:
                continue

            # ── Annotation ───────────────────────────────────────────────
            if tok.kind == LineKind.ANNOTATION:
                if in_vars:
                    continue
                self._pending_ann.append(
                    parse_annotation(tok.annotation_text, tok.lineno)
                )
                continue

            # ── Section header ────────────────────────────────────────────
            if tok.kind == LineKind.SECTION:
                self._current_section = tok.section
                self._config.setdefault(self._current_section, {})
                if self._pending_ann:
                    self._meta[self._current_section] = self._pending_ann[:]
                    self._pending_ann = []
                continue

            # ── Block dict open ───────────────────────────────────────────
            if tok.kind == LineKind.BLOCK_OPEN:
                self._in_block    = True
                self._block_key   = tok.key
                self._block_data  = {}
                self._block_pending = []
                # Consume section-level pending annotations for the dict itself
                self._block_ann_snapshot = self._pending_ann[:]
                self._pending_ann = []
                continue

            # ── Key = value ───────────────────────────────────────────────
            if tok.kind == LineKind.KV:
                val = vp.parse(tok.value)
                self._store(tok.key, val, self._pending_ann, tok.lineno)
                self._pending_ann = []
                continue

    def _handle_block_token(self, tok: LineToken, vp: ValueParser) -> None:
        if tok.kind == LineKind.BLOCK_CLOSE:
            self._store(self._block_key, self._block_data,
                        getattr(self, "_block_ann_snapshot", []))
            self._in_block = False
            self._block_key  = ""
            self._block_data = {}
            self._block_pending = []
            return

        if tok.kind == LineKind.ANNOTATION:
            self._block_pending.append(
                parse_annotation(tok.annotation_text, tok.lineno)
            )
            return

        if tok.kind == LineKind.KV:
            val = vp.parse(tok.value)
            self._block_data[tok.key] = val
            if self._block_pending:
                # Store per-entry metadata inside block dict
                section  = self._current_section
                dict_key = self._block_key
                fqk = (
                    f"{section}.{dict_key}.{tok.key}"
                    if section else f"{dict_key}.{tok.key}"
                )
                self._meta[fqk] = self._block_pending[:]
                self._block_pending = []

    # ── Storage helper ────────────────────────────────────────────────────────

    def _store(
        self,
        key: str,
        value: Any,
        annotations: list[Annotation],
        lineno: int = 0,
    ) -> None:
        if self._current_section:
            self._config.setdefault(self._current_section, {})[key] = value
            fqk = f"{self._current_section}.{key}"
        else:
            self._config[key] = value
            fqk = key

        if annotations:
            self._meta[fqk] = annotations[:]
