"""
tomlplus.__main__ / tomlplus.cli — Command-line interface.

Usage
-----
    tomlplus parse   config.tomlp
    tomlplus validate config.tomlp
    tomlplus meta    config.tomlp
    tomlplus vars    config.tomlp
    tomlplus fmt     config.tomlp          # pretty-print / round-trip
    tomlplus fmt     config.tomlp -o out.tomlp

Run ``tomlplus --help`` for full usage.
"""

from __future__ import annotations
import argparse
import json
import sys
from pathlib import Path

from .api       import load, loads
from .validator import validate, validate_all
from .errors    import TOMLPlusError
from .models    import TOMLPlusDocument
from .dumper    import dumps


# ─── Colour helpers (no deps) ─────────────────────────────────────────────────

_USE_COLOR = sys.stdout.isatty()

def _c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if _USE_COLOR else text

def green(t):  return _c(t, "32")
def red(t):    return _c(t, "31")
def yellow(t): return _c(t, "33")
def cyan(t):   return _c(t, "36")
def bold(t):   return _c(t, "1")
def dim(t):    return _c(t, "2")


# ─── Subcommand handlers ──────────────────────────────────────────────────────

def cmd_parse(args) -> int:
    doc = _load(args.file)
    if doc is None:
        return 1
    output = json.dumps(doc.config, indent=2, default=str)
    if args.output:
        Path(args.output).write_text(output, encoding="utf-8")
        print(green(f"✓ Written to {args.output}"))
    else:
        print(output)
    return 0


def cmd_validate(args) -> int:
    doc = _load(args.file)
    if doc is None:
        return 1

    errors = validate_all(doc)
    if not errors:
        print(green("✓ Validation passed") + dim(f"  ({len(doc.meta)} annotated keys)"))
        return 0

    print(red(f"✗ {len(errors)} validation error(s):"))
    for err in errors:
        key = getattr(err, "key", None)
        loc = f"  {cyan(key)}: " if key else "  "
        print(f"{loc}{err}")
    return 1


def cmd_meta(args) -> int:
    doc = _load(args.file)
    if doc is None:
        return 1

    if not doc.meta:
        print(dim("(no annotations found)"))
        return 0

    for fqk, anns in doc.meta.items():
        print(f"{cyan(fqk)}")
        for ann in anns:
            print(f"  {yellow(str(ann))}")
    return 0


def cmd_vars(args) -> int:
    doc = _load(args.file)
    if doc is None:
        return 1

    from .builtins import get_builtins
    builtins = get_builtins()

    if doc.vars:
        print(bold("User-defined vars:"))
        for k, v in doc.vars.items():
            print(f"  {cyan('$' + k):<30} = {_fmt(v)}")
        print()

    if args.all:
        print(bold("Built-in constants:"))
        for k, v in builtins.items():
            print(f"  {cyan('$' + k):<30} = {_fmt(v)}")

    return 0


def cmd_fmt(args) -> int:
    doc = _load(args.file)
    if doc is None:
        return 1

    text = dumps(doc)
    if args.output:
        Path(args.output).write_text(text, encoding="utf-8")
        print(green(f"✓ Written to {args.output}"))
    else:
        print(text, end="")
    return 0


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _load(path: str) -> TOMLPlusDocument | None:
    try:
        return load(path)
    except FileNotFoundError:
        print(red(f"Error: file not found: {path}"), file=sys.stderr)
        return None
    except TOMLPlusError as exc:
        print(red(f"Error: {exc}"), file=sys.stderr)
        return None


def _fmt(v) -> str:
    if isinstance(v, str):
        return f'"{v}"'
    return str(v)


# ─── Argument parser ──────────────────────────────────────────────────────────

def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="tomlplus",
        description="TOML+ configuration format toolkit",
    )
    p.add_argument("--version", action="version", version="tomlplus 1.0.0")

    sub = p.add_subparsers(dest="command", metavar="command")
    sub.required = True

    # parse
    sp = sub.add_parser("parse", help="Parse a .tomlp file and output JSON")
    sp.add_argument("file",   help="Path to .tomlp file")
    sp.add_argument("-o", "--output", metavar="FILE", help="Write JSON to FILE")
    sp.set_defaults(func=cmd_parse)

    # validate
    sp = sub.add_parser("validate", help="Validate annotations and constraints")
    sp.add_argument("file", help="Path to .tomlp file")
    sp.set_defaults(func=cmd_validate)

    # meta
    sp = sub.add_parser("meta", help="Display annotation metadata")
    sp.add_argument("file", help="Path to .tomlp file")
    sp.set_defaults(func=cmd_meta)

    # vars
    sp = sub.add_parser("vars", help="Show resolved variables")
    sp.add_argument("file",        help="Path to .tomlp file")
    sp.add_argument("--all", "-a", action="store_true",
                    help="Also show built-in constants")
    sp.set_defaults(func=cmd_vars)

    # fmt
    sp = sub.add_parser("fmt", help="Round-trip format a .tomlp file")
    sp.add_argument("file",                        help="Path to .tomlp file")
    sp.add_argument("-o", "--output", metavar="FILE", help="Write formatted output to FILE")
    sp.set_defaults(func=cmd_fmt)

    return p


def main(argv=None) -> int:
    parser = build_parser()
    args   = parser.parse_args(argv)
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
