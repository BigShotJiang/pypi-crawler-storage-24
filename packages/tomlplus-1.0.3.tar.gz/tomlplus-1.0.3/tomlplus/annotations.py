"""
tomlplus.annotations — Annotation line parser.

Converts raw annotation strings like ``@type: int`` or ``@tag: owner = "me"``
into ``Annotation`` model instances.
"""

from __future__ import annotations
import re
from typing import Any

from .errors import ParseError
from .models import Annotation

__all__ = ["parse_annotation"]


_ANNOTATION_RE = re.compile(
    r"^@(?P<name>[a-zA-Z_][a-zA-Z0-9_]*)"
    r"(?:"
    r":[ \t]*(?P<arg_colon>.+)"    # @name: arg
    r"|"
    r"\((?P<arg_paren>[^)]*)\)"    # @name(arg)
    r")?$"
)


def parse_annotation(line: str, lineno: int = 0) -> Annotation:
    """
    Parse a single annotation line into an :class:`Annotation`.

    Parameters
    ----------
    line   : The annotation string, e.g. ``"@type: int"``
    lineno : Source line number used in error messages.

    Returns
    -------
    Annotation

    Raises
    ------
    ParseError
        If the line is not a valid annotation.
    """
    m = _ANNOTATION_RE.match(line.strip())
    if not m:
        raise ParseError(f"Invalid annotation syntax: {line!r}", lineno)

    name = m.group("name")
    arg: Any = None

    if m.group("arg_colon") is not None:
        arg = _parse_arg(m.group("arg_colon").strip(), lineno)
    elif m.group("arg_paren") is not None:
        # @deprecated("message") — treat content as a plain string
        arg = m.group("arg_paren").strip().strip('"')

    return Annotation(name=name, arg=arg)


def _parse_arg(raw: str, lineno: int) -> Any:
    """Parse the argument portion of an annotation."""
    raw = raw.strip()

    # List: [a, b, c]
    if raw.startswith("[") and raw.endswith("]"):
        inner = raw[1:-1]
        return [item.strip().strip('"') for item in inner.split(",") if item.strip()]

    # Quoted string
    if raw.startswith('"') and raw.endswith('"') and len(raw) >= 2:
        return raw[1:-1]

    # Int
    try:
        return int(raw)
    except ValueError:
        pass

    # Float
    try:
        return float(raw)
    except ValueError:
        pass

    # Bare string (includes @tag: key = value)
    return raw
