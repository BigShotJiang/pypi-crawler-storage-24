"""
tomlplus.values — Value expression parser.

Handles the RHS of key = <value>, including:
  - Primitive literals: string, int, float, bool, null
  - Arrays: [a, b, c]
  - Inline dicts: #{ k = v, ... }
  - Variables: $NAME, $ENV.VAR
  - Arithmetic expressions: $base + "/path"
  - Fallback operator: $ENV.X ?? "default"
"""

from __future__ import annotations
import os
import re
from typing import Any

from .errors   import ParseError, VariableError
from .builtins import get_builtins

__all__ = ["ValueParser"]


class ValueParser:
    """
    Parse a single value expression string into a Python value.

    Parameters
    ----------
    variables : dict
        Merged dict of user vars + built-ins.  Callers are responsible
        for populating this before constructing the parser.
    line_no : int
        Line number used in error messages.
    """

    def __init__(self, variables: dict, line_no: int = 0):
        self._vars   = variables
        self.line_no = line_no

    # ── Public entry ──────────────────────────────────────────────────────────

    def parse(self, raw: str) -> Any:
        return self._expr(raw.strip())

    # ── Expression layer (handles ??) ────────────────────────────────────────

    def _expr(self, raw: str) -> Any:
        # Split on ?? outside of strings — use rightmost split so chained
        # fallbacks work left-to-right: A ?? B ?? C → (A ?? (B ?? C))
        idx = self._find_op(raw, "??")
        if idx != -1:
            lhs = self._arith(raw[:idx].strip())
            if lhs is not None:
                return lhs
            # Recurse on rhs so chained ?? works: A ?? B ?? C
            return self._expr(raw[idx + 2:].strip())
        return self._arith(raw)

    # ── Arithmetic layer (+, -, *, /) ─────────────────────────────────────────

    def _arith(self, raw: str) -> Any:
        tokens = self._tokenize_arith(raw)
        if len(tokens) == 1:
            return self._atom(tokens[0])

        result = self._atom(tokens[0])
        i = 1
        while i < len(tokens) - 1:
            op  = tokens[i]
            rhs = self._atom(tokens[i + 1])
            if op == "+":
                if isinstance(result, str) or isinstance(rhs, str):
                    result = str(result) + str(rhs)
                else:
                    result = result + rhs
            elif op == "-":
                result = result - rhs
            elif op == "*":
                result = result * rhs
            elif op == "/":
                result = result / rhs
            i += 2
        return result

    def _tokenize_arith(self, raw: str) -> list[str]:
        """Yield alternating [value, op, value, op, ...] tokens."""
        tokens: list[str] = []
        buf: list[str]    = []
        in_str = False
        depth  = 0
        i      = 0
        while i < len(raw):
            ch = raw[i]
            if ch == '"' and (i == 0 or raw[i - 1] != "\\"):
                in_str = not in_str
                buf.append(ch)
            elif not in_str:
                if ch in "([{#":
                    depth += 1
                    buf.append(ch)
                elif ch in ")]}":
                    depth -= 1
                    buf.append(ch)
                elif depth == 0 and ch in "+-*/" and not (ch == "/" and i + 1 < len(raw) and raw[i+1] == "/"):
                    # Treat '-' as a unary minus (part of atom) when the buffer is
                    # currently empty or the last token was an operator — i.e. this
                    # minus introduces a negative number literal, not subtraction.
                    is_unary_minus = (
                        ch == "-"
                        and not "".join(buf).strip()   # nothing before it yet
                    )
                    if is_unary_minus:
                        buf.append(ch)
                    else:
                        s = "".join(buf).strip()
                        if s:
                            tokens.append(s)
                        buf = []
                        tokens.append(ch)
                else:
                    buf.append(ch)
            else:
                buf.append(ch)
            i += 1

        s = "".join(buf).strip()
        if s:
            tokens.append(s)
        return tokens

    # ── Atom layer ────────────────────────────────────────────────────────────

    def _atom(self, raw: str) -> Any:
        raw = raw.strip()

        if raw.startswith("$"):
            return self._variable(raw)
        if raw.startswith('"'):
            return self._string(raw)
        if raw == "true":
            return True
        if raw == "false":
            return False
        if raw == "null":
            return None
        if raw.startswith("#{"):
            return self._inline_dict(raw)
        if raw.startswith("["):
            return self._array(raw)

        # float before int (order matters)
        if "." in raw:
            try:
                return float(raw)
            except ValueError:
                pass
        try:
            return int(raw)
        except ValueError:
            pass

        raise ParseError(f"Cannot parse value: {raw!r}", self.line_no)

    # ── Variable resolution ───────────────────────────────────────────────────

    def _variable(self, raw: str) -> Any:
        name = raw[1:]   # strip $

        # $ENV.VAR_NAME
        if name.startswith("ENV."):
            env_key = name[4:]
            return os.environ.get(env_key)   # None when unset → ?? picks up

        # Built-in or user-defined
        builtins = get_builtins()
        if name in builtins:
            return builtins[name]
        if name in self._vars:
            return self._vars[name]

        raise VariableError(
            f"Undefined variable ${name!r}",
            variable=name,
            line=self.line_no,
        )

    # ── String literal ────────────────────────────────────────────────────────

    def _string(self, raw: str) -> str:
        if not (raw.startswith('"') and raw.endswith('"') and len(raw) >= 2):
            raise ParseError(f"Unterminated string: {raw!r}", self.line_no)
        inner = raw[1:-1]
        return (inner
                .replace('\\"', '"')
                .replace("\\n", "\n")
                .replace("\\t", "\t")
                .replace("\\r", "\r")
                .replace("\\\\", "\\"))

    # ── Array ────────────────────────────────────────────────────────────────

    def _array(self, raw: str) -> list:
        inner = raw[1:-1].strip()
        if not inner:
            return []
        items = []
        for part in self._split_top_level(inner, ","):
            part = part.strip()
            if part:
                items.append(self._atom(part))
        return items

    # ── Inline dict #{ k = v, k = v } ────────────────────────────────────────

    def _inline_dict(self, raw: str) -> dict:
        # Strip #{ and closing }
        if not (raw.startswith("#{") and raw.endswith("}")):
            raise ParseError(f"Malformed inline dict: {raw!r}", self.line_no)
        inner = raw[2:-1].strip()
        if not inner:
            return {}
        result: dict = {}
        for part in self._split_top_level(inner, ","):
            part = part.strip()
            if "=" not in part:
                continue
            k, _, v = part.partition("=")
            result[k.strip()] = self._atom(v.strip())
        return result

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _find_op(self, s: str, op: str) -> int:
        """Find *op* in *s* ignoring occurrences inside string literals."""
        in_str = False
        i      = 0
        while i < len(s):
            ch = s[i]
            if ch == '"' and (i == 0 or s[i - 1] != "\\"):
                in_str = not in_str
            if not in_str and s[i:i + len(op)] == op:
                return i
            i += 1
        return -1

    def _split_top_level(self, s: str, sep: str) -> list[str]:
        """Split *s* on *sep* ignoring nested brackets and strings."""
        parts: list[str] = []
        buf:   list[str] = []
        depth  = 0
        in_str = False
        for ch in s:
            if ch == '"' and not (buf and buf[-1] == "\\"):
                in_str = not in_str
                buf.append(ch)
            elif not in_str and ch in "([{":
                depth += 1
                buf.append(ch)
            elif not in_str and ch in ")]}":
                depth -= 1
                buf.append(ch)
            elif not in_str and depth == 0 and ch == sep:
                parts.append("".join(buf))
                buf = []
            else:
                buf.append(ch)
        if buf:
            parts.append("".join(buf))
        return parts
