"""
tomlplus.models — Core data models
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any

__all__ = ["Annotation", "TOMLPlusDocument"]


@dataclass
class Annotation:
    """
    Represents a single annotation applied to a key or section.

    Examples
    --------
    @required           → Annotation("required")
    @type: int          → Annotation("type", "int")
    @min: 1             → Annotation("min", 1)
    @enum: [a, b, c]   → Annotation("enum", ["a", "b", "c"])
    @tag: owner = "me"  → Annotation("tag", "owner = me")
    @deprecated("msg")  → Annotation("deprecated", "msg")
    """

    name: str
    arg:  Any = None

    def __str__(self) -> str:
        if self.arg is None:
            return f"@{self.name}"
        if isinstance(self.arg, list):
            return f"@{self.name}: [{', '.join(str(a) for a in self.arg)}]"
        return f"@{self.name}: {self.arg}"

    def __repr__(self) -> str:
        return f"Annotation({self.name!r}, {self.arg!r})"

    # Convenience helpers
    @property
    def is_metadata(self) -> bool:
        return self.name in {"required", "deprecated", "internal", "readonly", "experimental"}

    @property
    def is_type_hint(self) -> bool:
        return self.name == "type"

    @property
    def is_validation(self) -> bool:
        return self.name in {"min", "max", "minlen", "maxlen", "pattern",
                              "enum", "nonzero", "positive", "nonempty"}

    @property
    def is_tag(self) -> bool:
        return self.name == "tag"


class TOMLPlusDocument:
    """
    The result of parsing a TOML+ source.

    Wraps the config dict and metadata together and provides
    dict-like access, annotation queries, and tag lookups.

    Attributes
    ----------
    config : dict
        The fully parsed configuration values, mirroring TOML table structure.
    meta : dict[str, list[Annotation]]
        Maps fully-qualified key paths (e.g. ``"server.port"``) to their annotations.
    vars : dict
        User-defined variables declared in the ``[vars]`` section.

    Examples
    --------
    >>> doc = tomlplus.loads(src)
    >>> doc["server"]["port"]
    8080
    >>> doc.annotations("server.port")
    [Annotation('type', 'int'), Annotation('min', 1), Annotation('max', 65535)]
    >>> doc.tags("database")
    {'sensitivity': 'high'}
    """

    def __init__(self, config: dict, meta: dict[str, list[Annotation]], vars_: dict):
        self._config = config
        self._meta   = meta
        self._vars   = vars_

    # ── Dict-like access ──────────────────────────────────────────────────────

    def __getitem__(self, key: str) -> Any:
        return self._config[key]

    def __contains__(self, key: str) -> bool:
        return key in self._config

    def __iter__(self):
        return iter(self._config)

    def __len__(self) -> int:
        return len(self._config)

    def get(self, key: str, default: Any = None) -> Any:
        return self._config.get(key, default)

    def keys(self):
        return self._config.keys()

    def values(self):
        return self._config.values()

    def items(self):
        return self._config.items()

    # ── Properties ────────────────────────────────────────────────────────────

    @property
    def config(self) -> dict:
        """The raw parsed config dictionary."""
        return self._config

    @property
    def meta(self) -> dict[str, list[Annotation]]:
        """All annotation metadata keyed by fully-qualified path."""
        return self._meta

    @property
    def vars(self) -> dict:
        """User-defined variables from the [vars] section."""
        return self._vars

    # ── Annotation helpers ────────────────────────────────────────────────────

    def annotations(self, key_path: str) -> list[Annotation]:
        """
        Return all annotations for a key path like ``"server.port"``.
        Returns an empty list if the key has no annotations.
        """
        return self._meta.get(key_path, [])

    def has_annotation(self, key_path: str, name: str) -> bool:
        """Return True if the key has an annotation with the given name."""
        return any(a.name == name for a in self.annotations(key_path))

    def tags(self, key_path: str) -> dict[str, str]:
        """
        Return a dict of all ``@tag`` values for a key path.

        Tags are stored as ``@tag: key = value``, so this returns
        ``{"key": "value", ...}``.
        """
        result = {}
        for ann in self.annotations(key_path):
            if ann.name == "tag" and isinstance(ann.arg, str) and "=" in ann.arg:
                k, _, v = ann.arg.partition("=")
                result[k.strip()] = v.strip().strip('"')
        return result

    def required_keys(self) -> list[str]:
        """Return all key paths annotated with ``@required``."""
        return [k for k, anns in self._meta.items()
                if any(a.name == "required" for a in anns)]

    def deprecated_keys(self) -> list[tuple[str, str | None]]:
        """
        Return ``(key_path, message_or_None)`` for all ``@deprecated`` keys.
        """
        result = []
        for k, anns in self._meta.items():
            for a in anns:
                if a.name == "deprecated":
                    result.append((k, a.arg))
        return result

    def keys_with_tag(self, tag_name: str) -> list[tuple[str, str]]:
        """
        Return ``[(key_path, tag_value)]`` for all keys that have a specific tag name.

        Example
        -------
        >>> doc.keys_with_tag("owner")
        [("app", "platform"), ("database", "billing-team")]
        """
        result = []
        for key_path in self._meta:
            t = self.tags(key_path)
            if tag_name in t:
                result.append((key_path, t[tag_name]))
        return result

    # ── Nested access helper ──────────────────────────────────────────────────

    def resolve(self, dotted_path: str, default: Any = None) -> Any:
        """
        Resolve a dotted path like ``"server.port"`` into the config tree.

        Returns *default* if the path does not exist.
        """
        parts = dotted_path.split(".")
        node  = self._config
        for part in parts:
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    # ── Repr ──────────────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        sections = list(self._config.keys())
        return f"TOMLPlusDocument(sections={sections!r})"
