"""SEO Report module."""
