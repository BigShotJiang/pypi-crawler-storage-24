"""CLI wrapper for find-faq-page-wrong-type."""

from __future__ import annotations

import typer

from worai.core.find_faq_page_wrong_type import FaqFixOptions, run as faq_run
from worai.core.profile_loader import resolve_profile_api_key
from worai.errors import UsageError

app = typer.Typer(add_completion=False, no_args_is_help=True, invoke_without_command=True)


@app.callback(invoke_without_command=True)
def run(
    ctx: typer.Context,
    file_path: str = typer.Argument(..., help="Path to Turtle RDF file."),
    patch: bool = typer.Option(False, "--patch", help="Execute live API patch calls."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show what would be patched."),
    replace_type: bool = typer.Option(False, "--replace-type", help="Remove existing types before adding FAQPage."),
) -> None:
    mode = "find"
    if patch:
        mode = "patch"
    elif dry_run:
        mode = "dry-run"

    api_key = None
    if mode == "patch":
        try:
            api_key, _, _ = resolve_profile_api_key(ctx)
        except ValueError as exc:
            raise UsageError(str(exc)) from exc
        if not api_key:
            raise UsageError("WORDLIFT_API_KEY is required for --patch (or set profiles.<name>.api_key in config).")

    options = FaqFixOptions(
        file_path=file_path,
        mode=mode,
        replace_type=replace_type,
        api_key=api_key,
    )
    faq_run(options)
