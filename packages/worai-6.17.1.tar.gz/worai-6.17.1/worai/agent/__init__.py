"""Agent integration helpers for worai."""

