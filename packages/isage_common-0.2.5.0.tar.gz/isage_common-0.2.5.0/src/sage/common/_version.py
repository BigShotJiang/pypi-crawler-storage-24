"""Version information for sage-common package."""

# 独立硬编码版本
__version__ = "0.2.5.0"  # absorbs isage-libs (sage.libs.*)
__author__ = "IntelliStream Team"
__email__ = "shuhao_zhang@hust.edu.cn"
