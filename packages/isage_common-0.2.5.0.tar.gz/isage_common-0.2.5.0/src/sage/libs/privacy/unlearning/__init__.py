"""Fail-fast boundary for concrete privacy implementations.

Concrete unlearning implementations were moved out of ``sage-libs`` and now
belong to the external ``isage-privacy`` package.
"""

raise ImportError(
    "sage.libs.privacy.unlearning has been removed from isage-libs. "
    "Install 'isage-privacy' and import concrete implementations from sage_privacy instead."
)
