"""Privacy layer - interface contracts for privacy-preserving algorithms.

This module only exposes interface contracts and registries.
Concrete privacy and unlearning implementations live in the external
``isage-privacy`` package.

Concrete implementations are provided by external packages (e.g., isage-privacy).
"""

from . import interface

# Re-export key interfaces for convenience
from .interface import (
    # Base classes
    BaseDPOptimizer,
    BaseFederatedClient,
    BaseFederatedServer,
    BasePrivacyMechanism,
    BaseUnlearner,
    # Data types
    PrivacyBudget,
    # Enums
    PrivacyLevel,
    UnlearningMethod,
    UnlearningResult,
    # Factories
    create_mechanism,
    create_unlearner,
    register_mechanism,
    register_unlearner,
    registered_mechanisms,
    registered_unlearners,
)

__all__ = [
    # Submodule
    "interface",
    # Enums
    "UnlearningMethod",
    "PrivacyLevel",
    # Data types
    "PrivacyBudget",
    "UnlearningResult",
    # Base classes
    "BasePrivacyMechanism",
    "BaseUnlearner",
    "BaseDPOptimizer",
    "BaseFederatedClient",
    "BaseFederatedServer",
    # Factories
    "register_unlearner",
    "create_unlearner",
    "registered_unlearners",
    "register_mechanism",
    "create_mechanism",
    "registered_mechanisms",
]
