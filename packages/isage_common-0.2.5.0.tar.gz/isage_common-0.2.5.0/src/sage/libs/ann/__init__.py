"""Removed ANN interface package.

ANN contracts were migrated out of ``sage-libs`` into the standalone
``isage-anns`` package. Import from ``sage_anns`` instead.
"""

raise ModuleNotFoundError(
    "`sage.libs.ann` was removed from isage-libs. Use `sage_anns` from the `isage-anns` package instead."
)
