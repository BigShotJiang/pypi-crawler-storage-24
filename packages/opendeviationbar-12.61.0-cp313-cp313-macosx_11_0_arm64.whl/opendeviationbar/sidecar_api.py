"""Business logic for sidecar REST API endpoints (Issue #213).

Extracted from sidecar.py to keep HTTP handlers thin and logic testable.

Endpoints:
    GET /ariadne/{symbol}/{threshold}  — Cascading last_agg_trade_id lookup (#217)
    GET /trades/gap-fill               — Trade continuity gap-fill (#216)
"""

from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

# Allowlist: symbols are uppercase alphanumeric (e.g., BTCUSDT, ETHBTC)
_SYMBOL_RE = re.compile(r"^[A-Z0-9]{2,20}$")


def _ariadne_clickhouse(
    symbol: str, threshold: int, result: dict[str, Any],
) -> dict[str, Any] | None:
    """ClickHouse sources (3 + 4) for ariadne cascade.

    SAFETY: caller (ariadne_lookup) validates symbol via _SYMBOL_RE before calling.
    """
    ch_cache = None
    try:
        from opendeviationbar.clickhouse.cache import OpenDeviationBarCache

        ch_cache = OpenDeviationBarCache()
    except Exception:
        logger.warning("ariadne: ClickHouse cache init failed", exc_info=True)
        return None

    # Source 3: open_deviation_bars
    try:
        from opendeviationbar.config import Settings

        ouroboros_mode = Settings.get().population.ouroboros_mode
        query = (
            "SELECT max(last_agg_trade_id) AS max_tid "
            "FROM opendeviationbar_cache.open_deviation_bars "
            f"WHERE symbol = '{symbol}' "
            f"AND threshold_decimal_bps = {threshold} "
            f"AND ouroboros_mode = '{ouroboros_mode}'"
        )
        row = ch_cache.client.query(query).first_row
        if row and row[0] and row[0] > 0:
            result["last_agg_trade_id"] = row[0]
            result["source"] = "clickhouse_bars"
            return result
    except Exception:
        logger.warning("ariadne: ClickHouse bars lookup failed", exc_info=True)

    # Source 4: population_checkpoints
    try:
        query = (
            "SELECT max(last_agg_trade_id) AS max_tid "
            "FROM opendeviationbar_cache.population_checkpoints "
            f"WHERE symbol = '{symbol}' "
            f"AND threshold_decimal_bps = {threshold}"
        )
        row = ch_cache.client.query(query).first_row
        if row and row[0] and row[0] > 0:
            result["last_agg_trade_id"] = row[0]
            result["source"] = "clickhouse_checkpoints"
            return result
    except Exception:
        logger.warning("ariadne: ClickHouse checkpoints lookup failed", exc_info=True)

    return None


def ariadne_lookup(
    symbol: str,
    threshold: int,
    engine: object | None = None,
) -> dict[str, Any]:
    """Cascading lookup for last_agg_trade_id (Issue #217).

    5-source cascade (most authoritative first):
    1. Live processor state (forming bar from engine)
    2. Processor checkpoint file
    3. ClickHouse open_deviation_bars (MAX last_agg_trade_id)
    4. ClickHouse population_checkpoints
    5. Binance REST API (latest aggTrade)

    Returns a dict with last_agg_trade_id, source, and metadata.
    """
    if not _SYMBOL_RE.match(symbol):
        msg = f"invalid symbol: {symbol!r}"
        raise ValueError(msg)
    if threshold <= 0:
        msg = f"threshold must be positive, got {threshold}"
        raise ValueError(msg)

    result: dict[str, Any] = {
        "symbol": symbol,
        "threshold_dbps": threshold,
        "last_agg_trade_id": None,
        "source": None,
        "has_incomplete_bar": False,
    }

    # Source 1: Live processor state (forming bars from engine)
    if engine is not None and hasattr(engine, "get_forming_bars"):
        try:
            forming_bars = engine.get_forming_bars()
            for fb in forming_bars:
                if fb.get("_symbol") == symbol and fb.get("_threshold") == threshold:
                    tid = fb.get("last_agg_trade_id")
                    if tid and tid > 0:
                        result["last_agg_trade_id"] = tid
                        result["source"] = "live_processor"
                        result["has_incomplete_bar"] = True
                        return result
        except Exception:
            logger.warning("ariadne: live processor lookup failed", exc_info=True)

    # Source 2: Processor checkpoint file
    try:
        from opendeviationbar.sidecar import _load_checkpoint

        cp = _load_checkpoint(symbol, threshold)
        if cp and cp.get("processor_checkpoint"):
            pc = cp["processor_checkpoint"]
            incomplete = pc.get("incomplete_bar")
            if incomplete:
                tid = incomplete.get("last_agg_trade_id")
                if tid and tid > 0:
                    result["last_agg_trade_id"] = tid
                    result["source"] = "checkpoint_file"
                    result["has_incomplete_bar"] = True
                    return result
            last_tid = pc.get("last_agg_trade_id")
            if last_tid and last_tid > 0:
                result["last_agg_trade_id"] = last_tid
                result["source"] = "checkpoint_file"
                return result
    except Exception:
        logger.warning("ariadne: checkpoint file lookup failed", exc_info=True)

    # Sources 3 + 4: ClickHouse
    ch_result = _ariadne_clickhouse(symbol, threshold, result)
    if ch_result is not None:
        return ch_result

    # Source 5: Binance REST API (latest aggTrade)
    try:
        from opendeviationbar._core import fetch_latest_aggtrade

        trade = fetch_latest_aggtrade(symbol)
        if trade and "agg_trade_id" in trade:
            result["last_agg_trade_id"] = trade["agg_trade_id"]
            result["source"] = "binance_rest"
            return result
    except Exception:
        logger.warning("ariadne: Binance REST lookup failed", exc_info=True)

    # All sources exhausted — flag degraded so consumer can distinguish from "no data"
    if result["last_agg_trade_id"] is None:
        logger.error(
            "ariadne: all sources failed for %s@%d — returning null",
            symbol, threshold,
        )
        result["degraded"] = True

    return result


def gap_fill_trades(
    symbol: str,
    from_agg_id: int,
    limit: int = 1000,
) -> list[dict[str, Any]]:
    """Fetch trades for gap-fill starting from a specific aggTrade ID (Issue #216).

    Two-tier lookup:
    1. Fast path: Local Parquet tick cache (TickStorage)
    2. Slow path: Binance REST API via fetch_aggtrades_by_id()

    Returns trades in Binance-compatible format.
    """
    if not _SYMBOL_RE.match(symbol):
        msg = f"invalid symbol: {symbol!r}"
        raise ValueError(msg)
    if from_agg_id < 0:
        msg = f"from_agg_id must be non-negative, got {from_agg_id}"
        raise ValueError(msg)
    limit = min(limit, 1000)  # Cap at Binance max

    # Fast path: Parquet tick cache
    try:
        from opendeviationbar.storage.parquet import TickStorage

        storage = TickStorage()
        # Read recent ticks and filter by agg_trade_id
        import polars as pl

        # Try to find cached tick files for this symbol
        tick_dir = storage._get_symbol_dir(symbol)
        if tick_dir.exists():
            parquet_files = sorted(tick_dir.glob("*.parquet"), reverse=True)
            for pf in parquet_files[:5]:  # Check last 5 files
                try:
                    lf = pl.scan_parquet(pf)
                    if "agg_trade_id" in lf.columns:
                        filtered = (
                            lf.filter(pl.col("agg_trade_id") >= from_agg_id)
                            .head(limit)
                            .collect()
                        )
                        if len(filtered) > 0:
                            trades = []
                            for row in filtered.iter_rows(named=True):
                                trades.append({
                                    "a": row.get("agg_trade_id", 0),
                                    "p": str(row.get("price", "0")),
                                    "q": str(row.get("quantity", row.get("volume", "0"))),
                                    "T": row.get("timestamp", 0),
                                    "m": row.get("is_buyer_maker", False),
                                })
                            logger.debug(
                                "gap-fill: %d trades from Parquet cache for %s",
                                len(trades),
                                symbol,
                            )
                            return trades
                except Exception:
                    logger.debug("gap-fill: failed to read %s", pf, exc_info=True)
                    continue
    except Exception:
        logger.debug("gap-fill: Parquet fast path failed", exc_info=True)

    # Slow path: Binance REST API
    try:
        from opendeviationbar._core import fetch_aggtrades_by_id

        trades_raw = fetch_aggtrades_by_id(symbol, from_agg_id, limit)
        # Convert to Binance-compatible format
        trades = []
        for t in trades_raw:
            trades.append({
                "a": t.get("agg_trade_id", 0),
                "p": str(t.get("price", "0")),
                "q": str(t.get("quantity", t.get("volume", "0"))),
                "T": t.get("timestamp", 0),
                "m": t.get("is_buyer_maker", False),
            })
        logger.debug(
            "gap-fill: %d trades from Binance REST for %s",
            len(trades),
            symbol,
        )
        return trades  # noqa: TRY300
    except Exception:
        logger.exception("gap-fill: Binance REST fallback failed for %s", symbol)
        raise
