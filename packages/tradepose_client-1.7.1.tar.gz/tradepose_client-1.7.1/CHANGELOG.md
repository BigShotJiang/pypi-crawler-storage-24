# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.7.0] - 2026-03-24

### Breaking Changes

- 移除 `PlaybookRegistry.sweep_strategy()` — 改用 `BlueprintBuilder.sweep()` 在 blueprint factory 中處理

### Added

- `PlaybookRegistry` — 中央 registry，自動掃描 `playbook/blueprints/` 和 `playbook/portfolios/`
- `@registry.blueprint(config)` — decorator 註冊策略 + 藍圖
- `@registry.portfolio(name, capital, ...)` — decorator 註冊投資組合，使用 `Currency`, `AccountSource`, `BrokerType` enum 確保 type safety
- `registry.search(instrument, tz, base_freq, direction, trend_type)` — 多維度篩選
- `registry.to_strategies(portfolio_name)` — 一鍵產出 `BatchTester` 所需策略
- `ModuleDiscovery` — 自動匯入 `.py` 模組，使用 `rglob` 支援巢狀目錄遞迴掃描
- `get_registry(root)` — singleton 初始化，支援可選 root path 參數
- `client.runs.create()` — 以 DB 資源引用提交回測任務（`blueprint_ids` 或 `portfolio_id`）
- `RunsResource` — 新 client resource，polling/download 完全複用現有 `client.tasks.*`
- `StrategyBuilder.apply_weekly_cutoff(exit_expr, weekly_cutoff)` — 時間強制出場工具方法
- `StrategyBuilder.build()` 自動將 `params.tz.key` 轉發至 `StrategyConfig.tz`

### Changed

- `PlaybookRegistry.search()` — `instrument`, `tz`, `base_freq` 支援 list 輸入（OR 語意），`direction`/`trend_type` 在 blueprint 層級篩選
- `BlueprintBuilder.sweep()` — 統一 4 種 sweep 場景，新增 `direction` 覆寫參數，`frange()` / `be_range()` helper
- `StrategyBuilder` — 建構子支援 `params: StrategyParams`，自動填入 `name`, `base_instrument`, `base_freq`
- Scope 模組重構 — `scope.py` 與 `analyzer.py` 解耦，提取獨立分析邏輯 (#793)
- Multi-instrument data validation 強化 — 改善錯誤訊息與驗證邏輯 (#792, #810)
- Updated dependency on `tradepose-models>=1.6.0`

### Fixed

- `OptionSummary` 存儲獨立 scope 欄位，解決名稱含 `/` 的解析歧義
- `ModuleDiscovery` `reload()` 時巢狀套件匯入失敗，修正 `sys.path` 處理
- `PlaybookRegistry` re-entrant init 導致無限遞迴

## [1.6.0] - 2026-02-07

### Added

- `get_indicator()` — 透過名稱查找指標的便捷方法

### Changed

- Updated dependency on `tradepose-models>=1.5.0`

## [1.5.0] - 2026-02-05

### Added

- Sweep API — 參數化策略測試（`BlueprintBuilder.sweep()`）
- `BlueprintBuilder` helper APIs — 更安全的 trigger 建構方法
- `TradesAnalyzer` — 階層式交易分析
- `Instrument.point_value` — 合約乘數欄位

### Changed

- Updated dependency on `tradepose-models>=1.4.0`

## [1.4.0] - 2026-01-23

### Added

- `BatchTester.list_instruments()` method for querying available instruments
- Support for enum types (`AccountSource`, `BrokerType`, `MarketType`) in `list_instruments()`

## [1.3.0] - 2026-01-22

### Added

- `trade_count` parameter to `export_latest_trades` method for limiting exported trades

### Changed

- Updated dependency on `tradepose-models>=1.3.0`

## [1.2.0] - 2026-01-19

### Added

- `TradingSetup` sync wrapper for synchronous API usage
- E2E test suite for Client SDK validation

### Changed

- Replaced `broker_type`/`platform` parameters with unified `account_source`
- Updated dependency on `tradepose-models>=1.2.0`

## [1.1.0] - 2025-12-21

### Changed

- Version bump to align with tradepose-models 1.1.0

## [1.0.0] - 2025-11-29

### Breaking Changes

- First stable release with breaking changes from 0.1.x series (previously 0.1.2)
- API changes incompatible with previous versions

### Added

- Stable API for TradePoseClient and BatchTester

## [0.1.0] - 2025-11-29 (deprecated)

### Added

- Initial release
- TradePoseClient async client with context manager support
- TradePoseConfig for configuration management
- BatchTester for batch backtesting with Period-based date ranges
- BatchResults and PeriodResult for result handling
- StrategyBuilder and BlueprintBuilder for strategy construction
- IndicatorSpecWrapper for indicator configuration
- TradingContext for trading session management
- 18 exception types for comprehensive error handling
- Jupyter notebook support via nest-asyncio
- Low-level API resources: api_keys, billing, strategies, tasks, export, usage
- Full type safety with Pydantic models
- Polars integration for DataFrame operations
