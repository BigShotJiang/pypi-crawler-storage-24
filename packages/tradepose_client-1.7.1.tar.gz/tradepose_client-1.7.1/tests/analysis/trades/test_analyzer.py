"""Tests for TradesAnalyzer core functionality."""

from __future__ import annotations

import polars as pl
import pytest
from tradepose_client.analysis.trades import TradesAnalyzer


class TestTradesAnalyzerInit:
    """Test TradesAnalyzer initialization."""

    def test_init_with_full_dataframe(self, sample_trades_df):
        """Test initialization with full trades DataFrame."""
        analyzer = TradesAnalyzer(sample_trades_df)
        assert analyzer.n_trades == 100
        assert analyzer.scope == "batch"

    def test_init_with_minimal_dataframe(self, minimal_trades_df):
        """Test initialization with minimal required columns."""
        analyzer = TradesAnalyzer(minimal_trades_df)
        assert analyzer.n_trades == 10

    def test_init_missing_required_columns(self):
        """Test initialization fails with missing required columns."""
        df = pl.DataFrame({"direction": [1, -1]})  # Missing 'pnl'
        with pytest.raises(ValueError, match="Missing required columns"):
            TradesAnalyzer(df)

    def test_init_with_scope(self, minimal_trades_df):
        """Test initialization with different scopes."""
        for scope in ["batch", "strategy", "blueprint", "trade"]:
            analyzer = TradesAnalyzer(minimal_trades_df, scope=scope)
            assert analyzer.scope == scope


class TestTradesAnalyzerScopeExploration:
    """Test scope exploration methods."""

    def test_available_strategies(self, sample_trades_df):
        """Test available_strategies method."""
        from tradepose_client.analysis.trades import AvailableOptions

        analyzer = TradesAnalyzer(sample_trades_df)
        options = analyzer.available_strategies()

        assert isinstance(options, AvailableOptions)
        assert options.category == "Strategies"
        assert len(options.options) > 0

    def test_available_blueprints(self, sample_trades_df):
        """Test available_blueprints method."""
        from tradepose_client.analysis.trades import AvailableOptions

        analyzer = TradesAnalyzer(sample_trades_df)
        options = analyzer.available_blueprints()

        assert isinstance(options, AvailableOptions)
        assert "Blueprints" in options.category

    def test_available_periods(self, sample_trades_df):
        """Test available_periods method."""
        from tradepose_client.analysis.trades import AvailableOptions

        analyzer = TradesAnalyzer(sample_trades_df)
        options = analyzer.available_periods()

        assert isinstance(options, AvailableOptions)
        assert "Periods" in options.category

    def test_build_scope_no_selection(self, sample_trades_df):
        """Test build_scope without selection."""
        from tradepose_client.analysis.trades import ScopeResult

        analyzer = TradesAnalyzer(sample_trades_df)
        scope = analyzer.build_scope()

        assert isinstance(scope, ScopeResult)
        assert scope.n_trades == analyzer.n_trades

    def test_build_scope_with_selection(self, sample_trades_df):
        """Test build_scope with selection."""
        from tradepose_client.analysis.trades import ScopeResult

        analyzer = TradesAnalyzer(sample_trades_df)
        strategies = analyzer.available_strategies()

        if len(strategies.options) > 0:
            scope = analyzer.build_scope(strategies.options[0])
            assert isinstance(scope, ScopeResult)
            # Scope should have filtered trades
            assert scope.n_trades <= analyzer.n_trades
