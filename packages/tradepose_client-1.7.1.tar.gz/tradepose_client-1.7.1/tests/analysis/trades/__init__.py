"""Tests for trades analysis module."""
