"""Registry type definitions."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any, Callable, TypeAlias

from tradepose_models.strategy import Blueprint

if TYPE_CHECKING:
    from tradepose_models.strategy import StrategyConfig

BpFunc: TypeAlias = Callable[[], list[Blueprint]]
ParamGrid: TypeAlias = dict[str, list[Any]]


@dataclass
class BpFactoryRecord:
    """Blueprint 工廠紀錄，保存 config + bp func 以供 reload 使用。"""

    config: StrategyConfig
    bp_func: BpFunc
    bp_func_name: str
    tags: dict[str, str] = field(default_factory=dict)
