"""Type definitions for Trades analysis module."""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import polars as pl

if TYPE_CHECKING:
    pass

# Analysis scope levels (from batch-level to single trade)
AnalysisScope = Literal["batch", "strategy", "blueprint", "trade"]

# Exit reason labels (matching Rust OrderStrategy enum: 3-8 are exits)
EXIT_REASON_LABELS: dict[int, str] = {
    3: "Immediate Exit",
    4: "Stop Loss",
    5: "Take Profit",
    6: "Trailing Stop",
    7: "Breakeven",
    8: "Timeout",
}

# Entry reason labels (matching Rust OrderStrategy enum: 0-2 are entries)
ENTRY_REASON_LABELS: dict[int, str] = {
    0: "Immediate",
    1: "Favorable Delay",
    2: "Adverse Delay",
}

# Dynamic axis support (column name or pl.Expr)
AxisExpr = str | pl.Expr

# Color-by options for visualizations
ColorBy = Literal[
    "outcome",  # Win/Lose
    "direction",  # Long/Short
    "strategy",  # Strategy name
    "blueprint",  # Blueprint name
    "exit_reason",  # Exit reason
    "entry_reason",  # Entry reason
]

# Period grouping options
PeriodType = Literal["day", "week", "month", "quarter", "year"]


# Required columns for trades analysis
REQUIRED_COLUMNS: set[str] = {
    "direction",
    "pnl",
}

# Polars Schema for trades DataFrame
# Use df.cast(TRADES_SCHEMA, strict=False) to ensure correct dtypes
TRADES_SCHEMA = pl.Schema(
    [
        ("direction", pl.Int16),
        ("status", pl.Boolean),
        ("is_adv_triggered", pl.Boolean),
        ("entry_idx", pl.UInt32),
        ("entry_time", pl.Datetime(time_unit="ms", time_zone=None)),
        ("entry_price", pl.Float64),
        ("entry_reason", pl.Int16),
        ("favorable_entry_hypo_price", pl.Float64),
        ("adverse_entry_hypo_price", pl.Float64),
        ("favorable_entry_strategy", pl.Int16),
        ("adverse_entry_strategy", pl.Int16),
        ("neutral_entry_strategy", pl.Int16),
        ("exit_idx", pl.UInt32),
        ("exit_time", pl.Datetime(time_unit="ms", time_zone=None)),
        ("exit_price", pl.Float64),
        ("exit_reason", pl.Int16),
        ("favorable_exit_hypo_price", pl.Float64),
        ("adverse_exit_hypo_price", pl.Float64),
        ("favorable_exit_strategy", pl.Int16),
        ("adverse_exit_strategy", pl.Int16),
        ("neutral_exit_strategy", pl.Int16),
        ("holding_seconds", pl.Int64),
        ("holding_bars", pl.Int32),
        ("g_mfe", pl.Float64),
        ("mae", pl.Float64),
        ("mfe", pl.Float64),
        ("mae_lv1", pl.Float64),
        ("mhl", pl.Float64),
        ("g_mfe_idx", pl.UInt32),
        ("mae_idx", pl.UInt32),
        ("mfe_idx", pl.UInt32),
        ("mae_lv1_idx", pl.UInt32),
        ("mhl_idx", pl.UInt32),
        ("entry_volatility", pl.Float64),
        ("exit_volatility", pl.Float64),
        ("g_mfe_volatility", pl.Float64),
        ("mae_volatility", pl.Float64),
        ("mfe_volatility", pl.Float64),
        ("mae_lv1_volatility", pl.Float64),
        ("mhl_volatility", pl.Float64),
        ("base_entry_time", pl.Datetime(time_unit="ms", time_zone=None)),
        ("base_entry_price", pl.Float64),
        ("pnl", pl.Float64),
        ("pnl_pct", pl.Float64),
        ("strategy_name", pl.String),
        ("blueprint_name", pl.String),
        ("period", pl.String),
    ]
)

# Optional but commonly used columns
OPTIONAL_COLUMNS: set[str] = {
    "exit_reason",
    "entry_reason",
    "is_adv_triggered",
    "strategy_name",
    "blueprint_name",
    "holding_bars",
    "holding_seconds",
    "entry_time",
    "exit_time",
    "entry_price",
    "exit_price",
    "mae",
    "mfe",
    "g_mfe",
    "mhl",
    "mae_lv1",
    "mae_volatility",
    "mfe_volatility",
    "g_mfe_volatility",
    "mhl_volatility",
    "entry_volatility",
    "exit_volatility",
}
