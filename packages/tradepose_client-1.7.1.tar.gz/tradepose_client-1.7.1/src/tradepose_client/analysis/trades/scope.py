"""Scope exploration and analysis for trades data.

This module provides tools to explore available data and build analysis scopes
for MAE/MFE workflow analysis. It operates independently on Polars DataFrames.

Example:
    >>> import polars as pl
    >>> from tradepose_client.analysis.trades import (
    ...     available_blueprints,
    ...     ScopeResult,
    ...     ScopeConfig,
    ... )
    >>>
    >>> # Step 1: Explore available options
    >>> blueprints = available_blueprints(trades_df)
    >>> blueprints.to_dataframe()
    >>>
    >>> # Step 2: Build scope with selection
    >>> scope = build_scope(trades_df, blueprints.options[0])
    >>>
    >>> # Step 3: Run analysis intents
    >>> scope.volatility_stability()
    >>> scope.full_workflow()
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING

import polars as pl

from ..mae_mfe.config import DEFAULT_CONFIG, ChartConfig
from .types import (
    ENTRY_REASON_LABELS,
    EXIT_REASON_LABELS,
    ColorBy,
)

if TYPE_CHECKING:
    import plotly.graph_objects as go

    from . import intent as intent_module


def calculate_performance(
    df: pl.DataFrame,
    metric_col: str = "pnl",
) -> pl.DataFrame:
    """Calculate performance metrics matching Rust performance_calculator.

    Uses Polars expressions for efficient single-pass calculation.

    Args:
        df: DataFrame containing trade data.
        metric_col: Column to use for calculations ("pnl" or "pnl_pct").

    Returns:
        Single-row DataFrame with performance metrics.

    Raises:
        ValueError: If DataFrame is empty or metric_col not found.
    """
    n = len(df)

    if n == 0:
        raise ValueError("Cannot compute performance on empty DataFrame")

    if metric_col not in df.columns:
        raise ValueError(f"Column '{metric_col}' not found in DataFrame")

    # Define win/lose conditions
    win_trades = pl.col(metric_col) > 0
    lose_trades = pl.col(metric_col) <= 0

    # Step 1: Calculate base metrics
    base_exprs = [
        pl.len().cast(pl.UInt32).alias("trades"),
        (win_trades.cast(pl.UInt32).sum().cast(pl.Float64) / pl.len().cast(pl.Float64)).alias(
            "win_ratio"
        ),
    ]
    df_with_base = df.with_columns(base_exprs)

    # Step 2: Build all performance expressions
    exprs = [
        # Trade statistics
        pl.col("trades").first().alias("trades"),
    ]

    # Add time columns if available
    if "entry_time" in df.columns:
        exprs.extend(
            [
                pl.col("entry_time").min().alias("first_entry_time"),
                pl.col("entry_time").max().alias("last_entry_time"),
            ]
        )
    if "exit_time" in df.columns:
        exprs.append(pl.col("exit_time").max().alias("last_exit_time"))

    # Profitability indicators
    exprs.extend(
        [
            pl.col("win_ratio").first().alias("win_ratio"),
            # profit_factor: total_wins / abs(total_losses)
            (
                pl.col(metric_col).filter(win_trades).sum()
                / pl.col(metric_col).filter(lose_trades).sum().abs()
            ).alias("profit_factor"),
            # expect_payoff: avg_win * win_ratio + avg_loss * (1 - win_ratio)
            (
                pl.col(metric_col).filter(win_trades).mean() * pl.col("win_ratio").first()
                + pl.col(metric_col).filter(lose_trades).mean()
                * (pl.lit(1.0) - pl.col("win_ratio").first())
            ).alias("expect_payoff"),
        ]
    )

    # Risk management indicators
    exprs.extend(
        [
            # recovery_factor: total / max_drawdown
            (
                pl.col(metric_col).cum_sum().last()
                / (pl.col(metric_col).cum_sum().cum_max() - pl.col(metric_col).cum_sum()).max()
            ).alias("recovery_factor"),
            # sortino_ratio: mean / downside_std
            (pl.col(metric_col).mean() / pl.col(metric_col).filter(lose_trades).std()).alias(
                "sortino_ratio"
            ),
        ]
    )

    # MAE risk estimates (if columns exist)
    if "mae" in df.columns and "entry_price" in df.columns:
        mae_pct = pl.col("mae") / pl.col("entry_price")
        exprs.extend(
            [
                mae_pct.quantile(0.75, interpolation="linear").alias("risk_mae_pct_p75"),
                pl.when((mae_pct.median() * 2.0).gt(mae_pct.max()))
                .then(mae_pct.median() * 2.0)
                .otherwise(mae_pct.max())
                .alias("risk_mae_pct_conservative"),
                mae_pct.quantile(0.95, interpolation="linear").alias("risk_mae_pct_p95"),
            ]
        )

    # Overall performance
    exprs.extend(
        [
            pl.col(metric_col).sum().alias("total"),
            pl.col(metric_col).std().alias("pnl_std"),
        ]
    )

    # Advanced analysis: g_mfe_after_mae_pct (if columns exist)
    if "g_mfe_idx" in df.columns and "mae_idx" in df.columns and "pnl_pct" in df.columns:
        exprs.append(
            (
                pl.col("g_mfe_idx")
                .gt(pl.col("mae_idx"))
                .and_(pl.col("pnl_pct").gt(0))
                .cast(pl.UInt32)
                .sum()
                .cast(pl.Float64)
                / pl.len().cast(pl.Float64)
            ).alias("g_mfe_after_mae_pct")
        )

    # Execute expressions
    result = df_with_base.select(exprs)

    # Step 3: Calculate derived metrics (kelly, sqn)
    return result.with_columns(
        [
            # kelly: win_ratio - (1 - win_ratio) / expect_payoff
            (
                pl.col("win_ratio")
                - ((pl.lit(1.0) - pl.col("win_ratio")) / pl.col("expect_payoff"))
            ).alias("kelly"),
            # sqn: expect_payoff * sqrt(min(trades, 100)) / pnl_std
            (
                pl.col("expect_payoff")
                * pl.when(pl.col("trades").cast(pl.Float64).lt(100.0))
                .then(pl.col("trades").cast(pl.Float64))
                .otherwise(pl.lit(100.0))
                .sqrt()
                / pl.col("pnl_std")
            ).alias("sqn"),
        ]
    )


@dataclass
class OptionSummary:
    """Summary of an available option with statistics."""

    value: str | int
    label: str
    count: int
    pct: float
    total_pnl: float
    avg_pnl: float
    total_pnl_pct: float
    avg_pnl_pct: float
    win_rate: float
    # Scope components — populated for blueprint/period options to avoid `/` parsing ambiguity
    strategy_name: str | None = None
    blueprint_name: str | None = None
    period: str | None = None

    def __str__(self) -> str:
        return (
            f"{self.label}: {self.count} trades ({self.pct:.1%}), "
            f"PnL={self.total_pnl:+,.2f} ({self.total_pnl_pct:+.2%}), WR={self.win_rate:.1%}"
        )


@dataclass
class AvailableOptions:
    """Collection of available options for a category."""

    category: str
    options: list[OptionSummary]
    total_trades: int

    def __str__(self) -> str:
        lines = [
            f"=== {self.category} ({len(self.options)} options, {self.total_trades} total trades) ==="
        ]
        for opt in self.options:
            lines.append(f"  {opt}")
        return "\n".join(lines)

    def to_dataframe(self) -> pl.DataFrame:
        """Convert options to a Polars DataFrame.

        Returns:
            DataFrame with columns: value, label, count, pct, total_pnl, avg_pnl,
            total_pnl_pct, avg_pnl_pct, win_rate

        Example:
            >>> blueprints = analyzer.available_blueprints()
            >>> blueprints.to_dataframe()
        """
        if not self.options:
            return pl.DataFrame()

        return pl.DataFrame(
            [
                {
                    "value": opt.value,
                    "label": opt.label,
                    "count": opt.count,
                    "pct": opt.pct,
                    "total_pnl": opt.total_pnl,
                    "avg_pnl": opt.avg_pnl,
                    "total_pnl_pct": opt.total_pnl_pct,
                    "avg_pnl_pct": opt.avg_pnl_pct,
                    "win_rate": opt.win_rate,
                }
                for opt in self.options
            ]
        )


@dataclass
class ScopeConfig:
    """Configuration for scope filtering.

    Scope filters select DATA RANGE only:
    - strategy, blueprint, period

    Analysis intents (exit_reason, direction, etc.) are handled
    by intent methods on ScopeResult.
    """

    strategies: list[str] | None = None
    blueprints: list[str] | None = None
    periods: list[str] | None = None


def _parse_selection(selection: OptionSummary) -> ScopeConfig:
    """Parse OptionSummary to ScopeConfig."""
    config = ScopeConfig()

    # Use structured fields when available (blueprint/period options populate these)
    if (
        selection.strategy_name is not None
        or selection.blueprint_name is not None
        or selection.period is not None
    ):
        if selection.strategy_name:
            config.strategies = [selection.strategy_name]
        if selection.blueprint_name:
            config.blueprints = [selection.blueprint_name]
        if selection.period:
            config.periods = [selection.period]
        return config

    # Legacy fallback: parse from value string (single-field options like strategy/exit_reason)
    value = str(selection.value)
    parts = [p.strip() for p in value.split("/")]

    if len(parts) >= 1 and parts[0]:
        config.strategies = [parts[0]]
    if len(parts) >= 2 and parts[1]:
        config.blueprints = [parts[1]]
    if len(parts) >= 3 and parts[2]:
        config.periods = [parts[2]]

    return config


@dataclass
class ScopeResult:
    """Result of scope building with analysis capabilities.

    ScopeResult receives pre-filtered trades and provides analysis methods.
    Filtering should be done at the analyzer level before creating ScopeResult.

    Attributes:
        trades: Trades DataFrame (already filtered).
        n_trades: Number of trades in scope.
        metric_col: Default metric column for performance/plot methods.
        normalize: Default normalization setting for scatter plots.
    """

    _trades: pl.DataFrame
    _metric_col: str = "pnl"
    _normalize: bool = True
    _config_chart: ChartConfig = field(default_factory=lambda: DEFAULT_CONFIG)

    @property
    def trades(self) -> pl.DataFrame:
        """Get the trades DataFrame."""
        return self._trades

    @property
    def n_trades(self) -> int:
        """Get the number of trades in scope."""
        return len(self._trades)

    def _repr_html_(self) -> str:
        """HTML representation for Jupyter notebooks."""
        df = self._trades

        # Stats
        if self.n_trades > 0:
            total_pnl = df["pnl"].sum()
            win_count = len(df.filter(pl.col("pnl") > 0))
            win_rate = win_count / self.n_trades
            pnl_color = "green" if total_pnl > 0 else "red"

            stats_html = f"""
            <tr><td>Trades</td><td>{self.n_trades:,}</td></tr>
            <tr><td>Total PnL</td><td style="color: {pnl_color}">{total_pnl:+,.2f}</td></tr>
            <tr><td>Win Rate</td><td>{win_rate:.1%} ({win_count}W / {self.n_trades - win_count}L)</td></tr>
            """
        else:
            stats_html = "<tr><td colspan='2'>No trades in scope</td></tr>"

        return f"""
        <div style="border: 1px solid #ccc; padding: 10px; border-radius: 5px; max-width: 500px;">
        <h4>Scope Summary</h4>
        <table border="0" style="margin-top: 10px;">
        {stats_html}
        </table>
        <p style="margin-top: 10px; color: #666; font-size: 0.9em;">
        Call intent methods to analyze: .volatility_stability(), .entry_timing(), etc.
        </p>
        </div>
        """

    def head(self, n: int = 5) -> pl.DataFrame:
        """Preview first n trades in scope.

        Args:
            n: Number of trades to show.

        Returns:
            DataFrame with first n trades.
        """
        return self._trades.head(n)

    def performance(self, metric_col: str | None = None) -> pl.DataFrame:
        """Calculate performance metrics for scoped trades.

        Args:
            metric_col: Column to use for calculations ("pnl" or "pnl_pct").
                        If None, uses the default set in build_scope().

        Returns:
            Single-row DataFrame with performance metrics.

        Example:
            >>> scope = build_scope(trades_df, opt, metric_col="pnl_pct")
            >>> scope.performance()  # uses pnl_pct
            >>> scope.performance(metric_col="pnl")  # override
        """
        col = metric_col if metric_col is not None else self._metric_col
        return calculate_performance(self._trades, col)

    def plot_scatter(
        self,
        *,
        x: "str | pl.Expr" = "mae",
        y: "str | pl.Expr" = "mfe",
        normalize: bool | None = None,
        color_by: ColorBy = "outcome",
        hover_cols: list[str] | None = None,
        title: str | None = None,
    ) -> "go.Figure":
        """Create scatter plot for scoped trades.

        Args:
            x: X-axis column name or Polars expression.
            y: Y-axis column name or Polars expression.
            normalize: If True and x/y are strings, normalize by volatility.
                       e.g., "mae" → pl.col("mae") / pl.col("mae_volatility").
                       If None, uses the default set in build_scope().
            color_by: Coloring option ("outcome", "direction", etc.).
            hover_cols: Additional columns to show on hover.
            title: Optional chart title.

        Returns:
            Plotly Figure.

        Example:
            >>> # Use default normalize setting from build_scope()
            >>> scope = analyzer.build_scope(opt, normalize=True)
            >>> scope.plot_scatter(x="mae", y="mfe")  # normalized
            >>>
            >>> # Override for raw values
            >>> scope.plot_scatter(x="mae", y="mfe", normalize=False)
            >>>
            >>> # Custom expression (normalize ignored)
            >>> scope.plot_scatter(
            ...     x=pl.col("mae") / pl.col("entry_price"),
            ...     y=pl.col("mfe") / pl.col("entry_price"),
            ... )
        """
        from .components import scatter_component

        # Use default normalize setting if not specified
        do_normalize = normalize if normalize is not None else self._normalize

        # Apply normalization if enabled and using string column names
        x_expr = x
        y_expr = y
        if do_normalize:
            if isinstance(x, str) and f"{x}_volatility" in self._trades.columns:
                x_expr = (pl.col(x) / pl.col(f"{x}_volatility")).alias(f"{x} (norm)")
            if isinstance(y, str) and f"{y}_volatility" in self._trades.columns:
                y_expr = (pl.col(y) / pl.col(f"{y}_volatility")).alias(f"{y} (norm)")

        config = self._config_chart
        return scatter_component(
            self._trades,
            x=x_expr,
            y=y_expr,
            color_by=color_by,
            hover_cols=hover_cols,
            config=config,
            title=title,
        )

    def plot_equity(
        self,
        *,
        metric_col: str | None = None,
        ohlcv: pl.DataFrame | None = None,
        title: str | None = None,
    ) -> "go.Figure":
        """Create equity curve chart with optional benchmark comparison.

        Plots cumulative PnL or return over time. If OHLCV data is provided,
        also plots benchmark performance for comparison.

        Args:
            metric_col: Column to use for cumsum ("pnl" or "pnl_pct").
                        If None, uses the default set in build_scope().
            ohlcv: Optional OHLCV DataFrame with 'ts' (datetime) and 'open' columns.
                   When provided, benchmark is calculated from open prices.
            title: Optional chart title.

        Returns:
            Plotly Figure.

        Example:
            >>> scope = analyzer.build_scope(opt, metric_col="pnl_pct")
            >>> scope.plot_equity()  # uses pnl_pct
            >>> scope.plot_equity(metric_col="pnl")  # override
            >>> scope.plot_equity(ohlcv=ohlcv_df)  # with benchmark
        """
        from .components import equity_curve_component

        config = self._config_chart
        col = metric_col if metric_col is not None else self._metric_col
        return equity_curve_component(
            self._trades,
            metric_col=col,
            ohlcv=ohlcv,
            config=config,
            title=title,
        )

    def plot_box(
        self,
        *,
        group_by: str = "exit_reason",
        metric: str | pl.Expr = "pnl",
        show_outcome: bool = True,
        title: str | None = None,
    ) -> "go.Figure":
        """Create box plot of metric grouped by category.

        Args:
            group_by: Column to group by. Options:
                - "exit_reason": Group by exit reason (SL, TP, etc.)
                - "entry_reason": Group by entry reason
                - "blueprint_name": Group by blueprint
                - "strategy_name": Group by strategy
                - "direction": Group by Long/Short
            metric: Metric column or Polars expression.
            show_outcome: If True, split by Win/Lose within each group.
            title: Optional chart title.

        Returns:
            Plotly Figure.

        Example:
            >>> scope.plot_box(group_by="exit_reason", metric="mae")
            >>> scope.plot_box(group_by="blueprint_name", metric="pnl")
            >>> scope.plot_box(group_by="direction", metric="pnl_pct")
        """
        from .components import box_component

        config = self._config_chart
        return box_component(
            self._trades,
            metric=metric,
            group_by=group_by,
            show_outcome=show_outcome,
            config=config,
            title=title,
        )

    def plot_distribution(
        self,
        metric: str | pl.Expr = "pnl",
        *,
        by_outcome: bool = True,
        bins: int = 50,
        title: str | None = None,
    ) -> "go.Figure":
        """Create distribution histogram of a metric.

        Args:
            metric: Metric column or Polars expression.
            by_outcome: If True, show separate histograms for Win/Lose.
            bins: Number of histogram bins.
            title: Optional chart title.

        Returns:
            Plotly Figure.

        Example:
            >>> scope.plot_distribution("pnl")
            >>> scope.plot_distribution("mae", by_outcome=True)
            >>> scope.plot_distribution(pl.col("mfe") / pl.col("mfe_volatility"))
        """
        from .components import distribution_component

        config = self._config_chart
        return distribution_component(
            self._trades,
            metric=metric,
            by_outcome=by_outcome,
            bins=bins,
            config=config,
            title=title,
        )

    # ==========================================================================
    # Intent Methods - 5-Step MAE/MFE Workflow Analysis
    # ==========================================================================

    def volatility_stability(
        self,
        *,
        normalize: bool = False,
        bins: int = 30,
    ) -> "intent_module.IntentReport":
        """A: Analyze volatility stability.

        Steps:
            A1. Observe MAE, MFE, Global MFE time series
            A2. Check if MAE is stable
            A3. If MAE and MFE scale together, consider segmenting
            A4. Observe MFE vs Global MFE overlap
            A5. Observe MAE/MFE ratio over time

        Args:
            normalize: If True, use mae/mae_volatility instead of raw mae.
            bins: Number of bins for histograms (default 30).

        Returns:
            IntentReport with figures, stats, and insights.

        Example:
            >>> scope.volatility_stability().show()
            >>> scope.volatility_stability(normalize=True, bins=50).show()
        """
        from . import intent as intent_module

        config = self._config_chart
        return intent_module.volatility_stability(
            self._trades, config, normalize=normalize, bins=bins
        )

    def entry_timing(
        self,
        *,
        normalize: bool = False,
        bins: int = 30,
    ) -> "intent_module.IntentReport":
        """B: Analyze entry timing.

        Steps:
            B1. Observe MAE/MFE distribution with equal scale
            B2. Analyze upper-right corner ratio
            B3. Determine delay price if needed
            B4. Check for L-shape distribution
            B5. Consider time-based delay

        Args:
            normalize: If True, use mae/mae_volatility instead of raw mae.
            bins: Number of bins for histograms (default 30).

        Returns:
            IntentReport with figures, stats, and insights.

        Example:
            >>> scope.entry_timing().show()
            >>> scope.entry_timing(normalize=True, bins=50).show()
        """
        from . import intent as intent_module

        config = self._config_chart
        return intent_module.entry_timing(self._trades, config, normalize=normalize, bins=bins)

    def exit_placement(
        self,
        *,
        normalize: bool = False,
        bins: int = 30,
    ) -> "intent_module.IntentReport":
        """C: Analyze stop loss and take profit placement.

        Steps:
            C1. Check if MAE/MFE shows cluster distribution
            C2. For wave trading, use Global MFE
            C3. For trend trading, use MFE
            C4. Analyze cluster corners for SL/TP
            C5. Consider tightening SL/TP
            C6. Note: Tightening consumes win rate

        Args:
            normalize: If True, use mae/mae_volatility instead of raw mae.
            bins: Number of bins for histograms (default 30).

        Returns:
            IntentReport with figures, stats, and insights.

        Example:
            >>> scope.exit_placement().show()
            >>> scope.exit_placement(normalize=True, bins=50).show()
        """
        from . import intent as intent_module

        config = self._config_chart
        return intent_module.exit_placement(self._trades, config, normalize=normalize, bins=bins)

    def trailing_breakeven(
        self,
        *,
        normalize: bool = False,
        bins: int = 30,
    ) -> "intent_module.IntentReport":
        """D: Analyze trailing stop and breakeven placement.

        Steps:
            D1. Check for inverse MAE/MFE relationship
            D2. Use lose trade MFE for breakeven trigger
            D3. Use MHL for trailing distance

        Args:
            normalize: If True, use mae/mae_volatility instead of raw mae.
            bins: Number of bins for histograms (default 30).

        Returns:
            IntentReport with figures, stats, and insights.

        Example:
            >>> scope.trailing_breakeven().show()
            >>> scope.trailing_breakeven(normalize=True, bins=50).show()
        """
        from . import intent as intent_module

        config = self._config_chart
        return intent_module.trailing_breakeven(
            self._trades, config, normalize=normalize, bins=bins
        )

    def position_sizing(
        self,
        *,
        normalize: bool = False,
        bins: int = 30,
    ) -> "intent_module.IntentReport":
        """E: Analyze position sizing (add/reduce).

        Steps:
            E1. Adverse direction add (high win rate)
            E2. Favorable direction add (high MFE)
            E3. Reduce position between add zone and TP

        Args:
            normalize: If True, use mae/mae_volatility instead of raw mae.
            bins: Number of bins for histograms (default 30).

        Returns:
            IntentReport with figures, stats, and insights.

        Example:
            >>> scope.position_sizing().show()
            >>> scope.position_sizing(normalize=True, bins=50).show()
        """
        from . import intent as intent_module

        config = self._config_chart
        return intent_module.position_sizing(self._trades, config, normalize=normalize, bins=bins)

    def full_workflow(
        self,
        *,
        normalize: bool = False,
        bins: int = 30,
    ) -> "intent_module.FullWorkflowReport":
        """Execute complete A-E workflow analysis.

        Runs all 5 steps in sequence:
            A. Volatility Stability
            B. Entry Timing
            C. Exit Placement
            D. Trailing & Breakeven
            E. Position Sizing

        Args:
            normalize: If True, use mae/mae_volatility instead of raw mae.
            bins: Number of bins for histograms (default 30).

        Returns:
            FullWorkflowReport with all 5 step reports.

        Example:
            >>> report = scope.full_workflow()
            >>> report.summary()
            >>> report.full_workflow(normalize=True, bins=50).dashboard().show()
        """
        from . import intent as intent_module

        config = self._config_chart
        return intent_module.full_workflow(self._trades, config, normalize=normalize, bins=bins)


def _calculate_option_summary(
    df: pl.DataFrame,
    group_col: str,
    total_trades: int,
    label_map: dict[int, str] | None = None,
) -> list[OptionSummary]:
    """Calculate summary statistics for each option in a column."""
    if group_col not in df.columns:
        return []

    # Check if pnl_pct column exists
    has_pnl_pct = "pnl_pct" in df.columns

    agg_exprs = [
        pl.len().alias("count"),
        pl.col("pnl").sum().alias("total_pnl"),
        pl.col("pnl").mean().alias("avg_pnl"),
        (pl.col("pnl") > 0).sum().alias("wins"),
    ]
    if has_pnl_pct:
        agg_exprs.extend(
            [
                pl.col("pnl_pct").sum().alias("total_pnl_pct"),
                pl.col("pnl_pct").mean().alias("avg_pnl_pct"),
            ]
        )

    grouped = (
        df.group_by(group_col)
        .agg(*agg_exprs)
        .with_columns(
            (pl.col("count") / total_trades).alias("pct"),
            (pl.col("wins") / pl.col("count")).alias("win_rate"),
        )
        .sort("count", descending=True)
    )

    options = []
    for row in grouped.iter_rows(named=True):
        value = row[group_col]
        if label_map and isinstance(value, int):
            label = label_map.get(value, f"Unknown({value})")
        else:
            label = str(value)

        options.append(
            OptionSummary(
                value=value,
                label=label,
                count=row["count"],
                pct=row["pct"],
                total_pnl=row["total_pnl"],
                avg_pnl=row["avg_pnl"],
                total_pnl_pct=row.get("total_pnl_pct", 0.0),
                avg_pnl_pct=row.get("avg_pnl_pct", 0.0),
                win_rate=row["win_rate"],
            )
        )

    return options


def available_strategies(df: pl.DataFrame) -> AvailableOptions:
    """Get available strategies with statistics."""
    total = len(df)
    options = _calculate_option_summary(df, "strategy_name", total)
    return AvailableOptions("Strategies", options, total)


def available_blueprints(df: pl.DataFrame) -> AvailableOptions:
    """Get available strategy + blueprint combinations with statistics.

    Key format: "strategy_name / blueprint_name"
    """
    total = len(df)

    if "strategy_name" not in df.columns or "blueprint_name" not in df.columns:
        return AvailableOptions("Blueprints", [], total)

    # Check if pnl_pct column exists
    has_pnl_pct = "pnl_pct" in df.columns

    agg_exprs = [
        pl.len().alias("count"),
        pl.col("pnl").sum().alias("total_pnl"),
        pl.col("pnl").mean().alias("avg_pnl"),
        (pl.col("pnl") > 0).sum().alias("wins"),
    ]
    if has_pnl_pct:
        agg_exprs.extend(
            [
                pl.col("pnl_pct").sum().alias("total_pnl_pct"),
                pl.col("pnl_pct").mean().alias("avg_pnl_pct"),
            ]
        )

    # Group by strategy + blueprint combination
    grouped = (
        df.group_by(["strategy_name", "blueprint_name"])
        .agg(*agg_exprs)
        .with_columns(
            (pl.col("count") / total).alias("pct"),
            (pl.col("wins") / pl.col("count")).alias("win_rate"),
        )
        .sort("count", descending=True)
    )

    options = []
    for row in grouped.iter_rows(named=True):
        key = f"{row['strategy_name']} / {row['blueprint_name']}"
        options.append(
            OptionSummary(
                value=key,
                label=key,
                count=row["count"],
                pct=row["pct"],
                total_pnl=row["total_pnl"],
                avg_pnl=row["avg_pnl"],
                total_pnl_pct=row.get("total_pnl_pct", 0.0),
                avg_pnl_pct=row.get("avg_pnl_pct", 0.0),
                win_rate=row["win_rate"],
                strategy_name=row["strategy_name"],
                blueprint_name=row["blueprint_name"],
            )
        )

    return AvailableOptions("Blueprints (Strategy / Blueprint)", options, total)


def available_exit_reasons(df: pl.DataFrame) -> AvailableOptions:
    """Get available exit reasons with statistics."""
    total = len(df)
    options = _calculate_option_summary(df, "exit_reason", total, EXIT_REASON_LABELS)
    return AvailableOptions("Exit Reasons", options, total)


def available_entry_reasons(df: pl.DataFrame) -> AvailableOptions:
    """Get available entry reasons with statistics."""
    total = len(df)
    options = _calculate_option_summary(df, "entry_reason", total, ENTRY_REASON_LABELS)
    return AvailableOptions("Entry Reasons", options, total)


def available_directions(df: pl.DataFrame) -> AvailableOptions:
    """Get available directions with statistics."""
    total = len(df)
    direction_labels = {1: "Long", -1: "Short"}
    options = _calculate_option_summary(df, "direction", total, direction_labels)
    return AvailableOptions("Directions", options, total)


def available_periods(df: pl.DataFrame) -> AvailableOptions:
    """Get available strategy + blueprint + period combinations with statistics.

    Key format: "strategy_name / blueprint_name / period"

    If no period column exists, uses exit_time/entry_time to derive year-month.
    """
    total = len(df)

    if "strategy_name" not in df.columns or "blueprint_name" not in df.columns:
        return AvailableOptions("Periods", [], total)

    # Check if period column exists, otherwise derive from time
    if "period" in df.columns:
        work_df = df
    else:
        # Find time column
        time_col = None
        for col in ["exit_time", "entry_time"]:
            if col in df.columns:
                time_col = col
                break

        if time_col is None:
            return AvailableOptions("Periods", [], total)

        work_df = df.with_columns(pl.col(time_col).dt.strftime("%Y-%m").alias("period"))

    # Check if pnl_pct column exists
    has_pnl_pct = "pnl_pct" in df.columns

    agg_exprs = [
        pl.len().alias("count"),
        pl.col("pnl").sum().alias("total_pnl"),
        pl.col("pnl").mean().alias("avg_pnl"),
        (pl.col("pnl") > 0).sum().alias("wins"),
    ]
    if has_pnl_pct:
        agg_exprs.extend(
            [
                pl.col("pnl_pct").sum().alias("total_pnl_pct"),
                pl.col("pnl_pct").mean().alias("avg_pnl_pct"),
            ]
        )

    # Group by strategy + blueprint + period combination
    grouped = (
        work_df.group_by(["strategy_name", "blueprint_name", "period"])
        .agg(*agg_exprs)
        .with_columns(
            (pl.col("count") / total).alias("pct"),
            (pl.col("wins") / pl.col("count")).alias("win_rate"),
        )
        .sort(["strategy_name", "blueprint_name", "period"])
    )

    options = []
    for row in grouped.iter_rows(named=True):
        key = f"{row['strategy_name']} / {row['blueprint_name']} / {row['period']}"
        options.append(
            OptionSummary(
                value=key,
                label=key,
                count=row["count"],
                pct=row["pct"],
                total_pnl=row["total_pnl"],
                avg_pnl=row["avg_pnl"],
                total_pnl_pct=row.get("total_pnl_pct", 0.0),
                avg_pnl_pct=row.get("avg_pnl_pct", 0.0),
                win_rate=row["win_rate"],
                strategy_name=row["strategy_name"],
                blueprint_name=row["blueprint_name"],
                period=row["period"],
            )
        )

    return AvailableOptions("Periods (Strategy / Blueprint / Period)", options, total)


def build_scope(
    trades: pl.DataFrame,
    *,
    metric_col: str = "pnl_pct",
    normalize: bool = True,
    config: ChartConfig | None = None,
) -> ScopeResult:
    """Build a scope for analysis from trades DataFrame.

    This is the standalone entry point for creating a ScopeResult without
    using TradesAnalyzer. The trades DataFrame should already be filtered
    if needed (filtering should be done at the analyzer level).

    Args:
        trades: Polars DataFrame containing trade data (pre-filtered).
        metric_col: Default metric column for performance/plot methods.
                    Options: "pnl" (absolute) or "pnl_pct" (percentage).
                    Default: "pnl_pct" (percentage-based analysis).
        normalize: Default normalization for scatter plots.
                   If True, "mae" → pl.col("mae") / pl.col("mae_volatility").
                   Default: True (users typically want normalized distribution).
        config: Optional chart configuration. Uses DEFAULT_CONFIG if not provided.

    Returns:
        ScopeResult with trades and analysis methods.

    Example:
        >>> import polars as pl
        >>> from tradepose_client.analysis.trades import build_scope
        >>>
        >>> # Build scope (trades should be pre-filtered if needed)
        >>> scope = build_scope(trades_df)
        >>>
        >>> # Analyze
        >>> scope.performance()
        >>> scope.plot_scatter(x="mae", y="mfe")
        >>> scope.full_workflow().dashboard()
    """
    return ScopeResult(
        _trades=trades,
        _metric_col=metric_col,
        _normalize=normalize,
        _config_chart=config or DEFAULT_CONFIG,
    )
