"""Trades Analysis Module.

This module provides hierarchical analysis and visualization tools for trades data.

Workflow:
    1. Create analyzer from BatchResults
    2. Explore available options (strategies, blueprints, periods)
    3. Build scope (select data range)
    4. Run analysis (performance, plots, 5-step workflow)

Example:
    >>> # From BatchResults
    >>> analyzer = batch.analyzer()
    >>>
    >>> # Explore options
    >>> blueprints = analyzer.available_blueprints()
    >>> blueprints.to_dataframe()
    >>>
    >>> # Build scope
    >>> scope = analyzer.build_scope(blueprints.options[0])
    >>>
    >>> # View scope summary (Jupyter)
    >>> scope
    >>>
    >>> # Performance metrics
    >>> scope.performance()
    >>>
    >>> # Visualizations
    >>> scope.plot_scatter(x="mae", y="mfe")
    >>> scope.plot_equity()
    >>> scope.plot_box(group_by="exit_reason")
    >>> scope.plot_distribution("pnl")
    >>>
    >>> # 5-Step MAE/MFE Workflow
    >>> scope.volatility_stability()    # A: 波動穩定性
    >>> scope.entry_timing()            # B: 進場時機
    >>> scope.exit_placement()          # C: 停損停利
    >>> scope.trailing_breakeven()      # D: 追蹤停損
    >>> scope.position_sizing()         # E: 加減碼
    >>> scope.full_workflow().dashboard()  # Complete A-E
"""

from .analyzer import TradesAnalyzer
from .intent import (
    FullWorkflowReport,
    IntentReport,
    StepInsight,
)
from .scope import (
    AvailableOptions,
    OptionSummary,
    ScopeResult,
    available_blueprints,
    available_directions,
    available_entry_reasons,
    available_exit_reasons,
    available_periods,
    available_strategies,
    build_scope,
    calculate_performance,
)
from .types import (
    ENTRY_REASON_LABELS,
    EXIT_REASON_LABELS,
    TRADES_SCHEMA,
    AnalysisScope,
    AxisExpr,
    ColorBy,
    PeriodType,
)

__all__ = [
    # Main class
    "TradesAnalyzer",
    # Scope
    "ScopeResult",
    "AvailableOptions",
    "OptionSummary",
    # Standalone functions
    "build_scope",
    "available_strategies",
    "available_blueprints",
    "available_periods",
    "available_exit_reasons",
    "available_entry_reasons",
    "available_directions",
    # Performance
    "calculate_performance",
    # Intent types
    "IntentReport",
    "FullWorkflowReport",
    "StepInsight",
    # Type definitions
    "AnalysisScope",
    "AxisExpr",
    "ColorBy",
    "PeriodType",
    "TRADES_SCHEMA",
    # Labels
    "EXIT_REASON_LABELS",
    "ENTRY_REASON_LABELS",
]
