"""Analysis module for TradePose Client.

This module provides data analysis and visualization tools for trading data.

Submodules:
    mae_mfe: MAE/MFE (Maximum Adverse/Favorable Excursion) analysis
    trades: Hierarchical trades analysis with filtering and optimization
"""

from .mae_mfe import (
    DARK_CONFIG,
    DEFAULT_CONFIG,
    ChartConfig,
    DashboardConfig,
    MAEMFEAnalyzer,
    MAEMFEStatistics,
)
from .trades import (
    ENTRY_REASON_LABELS,
    EXIT_REASON_LABELS,
    AnalysisScope,
    AxisExpr,
    ColorBy,
    PeriodType,
    TradesAnalyzer,
)

__all__ = [
    # MAE/MFE Analysis
    "MAEMFEAnalyzer",
    "MAEMFEStatistics",
    "ChartConfig",
    "DashboardConfig",
    "DEFAULT_CONFIG",
    "DARK_CONFIG",
    # Trades Analysis
    "TradesAnalyzer",
    "AnalysisScope",
    "AxisExpr",
    "ColorBy",
    "PeriodType",
    "EXIT_REASON_LABELS",
    "ENTRY_REASON_LABELS",
]
