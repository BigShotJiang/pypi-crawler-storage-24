# kohi-python

Python SDK for Kohi.

## Install

```bash
pip install kohi-python
```

## Quick Start

```python
from fastapi import FastAPI
from kohi import Monitor

app = FastAPI()
monitor = Monitor(
    app=app,
    project_key="pk_...",
    secret_key="...",
)
```

`Monitor(app=...)` auto-instruments supported `FastAPI` and `Flask` apps. You can also create a monitor without `app=` and submit events manually.

## Behavior

- Validates `project_key` / `secret_key` on startup
- Batches events, gzips payloads, and signs them with HMAC-SHA256
- Retries retryable network and HTTP failures before dropping a batch
- Redacts common secret fields and masks emails before send
- Preserves client IP extraction priority across `cf-connecting-ip`, `x-forwarded-for`, and related proxy headers
