from __future__ import annotations
import atexit, logging, queue, random, threading, time
from typing import Any, Dict, List
import httpx
from .core import b64url_decode, gzip_batch, redact_event, sign, SchemaUserConfig, DEFAULT_INGEST_ENDPOINT

_logger = logging.getLogger("kohi")
_pools: list["SenderPool"] = []

def _shutdown_all():
  for pool in _pools: pool.shutdown(timeout=5.0)
atexit.register(_shutdown_all)

class SenderPool:
  def __init__(self, *, cfg: SchemaUserConfig, workers: int = 2, max_queue: int = 5000, retry_count: int = 2, timeout_s: float = 10.0, endpoint: str | None = None):
    self.cfg, self.retry_count, self.timeout_s = cfg, retry_count, timeout_s
    self._endpoint = endpoint or DEFAULT_INGEST_ENDPOINT
    self._secret = b64url_decode(self.cfg.secret_key)
    self._batch_size = cfg.batch_size
    self._flush_interval = cfg.flush_interval_s
    self.q: queue.Queue[Dict[str, Any]] = queue.Queue(maxsize=max_queue)
    self.stop, self._shutdown_complete = threading.Event(), threading.Event()
    self.threads = [threading.Thread(target=self._worker, name=f"kohi-sender-{i}", daemon=True) for i in range(workers)]
    for t in self.threads: t.start()
    _pools.append(self)

  def submit(self, event: Dict[str, Any]) -> None:
    try: self.q.put_nowait(event)
    except queue.Full: _logger.warning("kohi monitor queue is full; dropping event")

  def shutdown(self, timeout: float = 30.0) -> None:
    if self._shutdown_complete.is_set(): return
    self.stop.set()
    deadline = time.time() + timeout
    for t in self.threads: t.join(timeout=max(0.01, deadline - time.time()))
    self._shutdown_complete.set()
    try: _pools.remove(self)
    except ValueError: pass

  def _new_client(self) -> httpx.Client:
    return httpx.Client(timeout=httpx.Timeout(self.timeout_s), limits=httpx.Limits(max_connections=100, max_keepalive_connections=20))

  def _worker(self) -> None:
    client: httpx.Client | None = None
    try:
      client = self._new_client()
      batch: List[Dict[str, Any]] = []
      last_flush = time.monotonic()

      while not self.stop.is_set():
        # Drain queue into batch (non-blocking, up to batch_size)
        while len(batch) < self._batch_size:
          try: batch.append(self.q.get_nowait())
          except queue.Empty: break

        elapsed = time.monotonic() - last_flush
        if len(batch) >= self._batch_size or (batch and elapsed >= self._flush_interval):
          self._send_batch(client, batch)
          batch = []
          last_flush = time.monotonic()
        else:
          time.sleep(0.01)

      # Shutdown: drain remaining
      while True:
        try: batch.append(self.q.get_nowait())
        except queue.Empty: break
        if len(batch) >= self._batch_size:
          self._send_batch(client, batch)
          batch = []

      if batch:
        self._send_batch(client, batch)
    finally:
      if client: client.close()

  def _send_batch(self, client: httpx.Client, events: List[Dict[str, Any]]) -> bool:
    if not events: return True
    redacted = [evt if evt.get("_type") == "error" else redact_event(evt) for evt in events]
    body = gzip_batch(redacted)
    sig = sign(self._secret, body)
    headers = {
      "Content-Type": "application/json", "Content-Encoding": "gzip",
      "X-Project-Key": self.cfg.project_key, "X-Signature": sig,
      "X-Batch-Count": str(len(events)),
    }
    backoff = 0.25
    last_status: int | None = None
    last_error: Exception | None = None
    for attempt in range(self.retry_count + 1):
      try:
        r = client.post(self._endpoint, content=body, headers=headers)
        if r.is_success: return True
        last_status = r.status_code
        if r.status_code not in (408, 429) and not (500 <= r.status_code < 600):
          _logger.warning("kohi: dropping batch (status=%s, count=%s)", r.status_code, len(events))
          return False
      except httpx.RequestError as e:
        last_error = e
      if attempt < self.retry_count:
        time.sleep(backoff * (0.8 + 0.4 * random.random()))
        backoff = min(backoff * 2, 2.0)
    _logger.warning("kohi: dropping batch after retries (count=%s, last_status=%s, last_error=%s)", len(events), last_status, last_error)
    return False
