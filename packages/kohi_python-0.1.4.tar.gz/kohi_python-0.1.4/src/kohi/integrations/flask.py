from __future__ import annotations
from typing import TYPE_CHECKING
from flask import g, request
from ..core import body_from_content_type, extract_client_ip, normalize_headers, normalize_peer_ip, try_json, now_ms, MAX_RESPONSE_BODY, MAX_REQUEST_BODY

if TYPE_CHECKING:
  from ..main import Monitor


def _build_event(req_headers, peer_ip, start, status, res_headers, res_body):
  client_ip = extract_client_ip(req_headers, peer_ip)
  try: req_body = try_json(request.get_data(cache=True)[:MAX_REQUEST_BODY])
  except (ValueError, TypeError, UnicodeDecodeError): req_body = None
  path, query = request.path, request.query_string.decode("utf-8") if request.query_string else ""
  endpoint = f"{path}?{query}" if query else path
  evt = {"url": request.url, "endpoint": endpoint, "method": request.method, "status_code": status, "request_headers": req_headers, "request_body": req_body, "response_headers": res_headers, "response_body": res_body, "duration_ms": now_ms() - start}
  if client_ip: evt["client_ip"] = client_ip
  return evt

def instrument(monitor: "Monitor", app) -> None:
  @app.before_request
  def _kohi_before():
    g._kohi_start = now_ms()
    try: request.get_data(cache=True, as_text=False)
    except (RuntimeError, ValueError): pass

  @app.after_request
  def _kohi_after(response):
    if getattr(g, "_kohi_logged", False): return response
    try:
      g._kohi_logged = True
      start = getattr(g, "_kohi_start", now_ms())
      req_headers = normalize_headers(dict(request.headers))
      res_headers = normalize_headers(dict(response.headers))
      peer_ip = normalize_peer_ip(request.remote_addr)
      try:
        raw = response.get_data(as_text=False)
        res_body = body_from_content_type(res_headers.get("content-type", ""), raw[:MAX_RESPONSE_BODY])
      except (ValueError, TypeError, RuntimeError): res_body = None
      monitor.add_event(_build_event(req_headers, peer_ip, start, response.status_code, res_headers, res_body))
    except Exception: pass
    return response

  def _handle_exc(exc):
    path = request.path
    query = request.query_string.decode("utf-8") if request.query_string else ""
    ep = f"{path}?{query}" if query else path
    req_headers = normalize_headers(dict(request.headers))
    peer_ip = normalize_peer_ip(request.remote_addr)
    client_ip = extract_client_ip(req_headers, peer_ip)
    monitor._capture_exception_with_request(exc, ep, request.method, client_ip)
    start = getattr(g, "_kohi_start", now_ms())
    monitor.add_event(_build_event(req_headers, peer_ip, start, 500, {}, {"error": str(exc)}))

  @app.teardown_request
  def _kohi_teardown(exc):
    if exc is None or getattr(g, "_kohi_logged", False): return
    from werkzeug.exceptions import HTTPException
    if isinstance(exc, HTTPException) and exc.code < 500: return
    try:
      g._kohi_logged = True
      _handle_exc(exc)
    except Exception: pass

  @app.errorhandler(Exception)
  def _kohi_error_handler(err):
    from werkzeug.exceptions import HTTPException
    if isinstance(err, HTTPException): raise err
    if getattr(g, "_kohi_logged", False): raise err
    try:
      g._kohi_logged = True
      _handle_exc(err)
    except Exception: pass
    raise err
