from __future__ import annotations
import sys, threading, time, traceback
from typing import Any, Dict, List, Optional



def parse_python_stack(exc: BaseException) -> List[Dict[str, Any]]:
    tb = exc.__traceback__
    if tb is None: return []
    frames = []
    for frame_summary in traceback.extract_tb(tb):
        frame: Dict[str, Any] = {
            "file": frame_summary.filename,
            "line": frame_summary.lineno,
            "function": frame_summary.name,
            "context": [frame_summary.line] if frame_summary.line else [],
            "in_app": is_in_app(frame_summary.filename),
        }
        if hasattr(frame_summary, "colno") and frame_summary.colno is not None:
            frame["column"] = frame_summary.colno
        frames.append(frame)
    return frames

def is_in_app(filename: str) -> bool:
    return "site-packages/" not in filename and "site-packages\\" not in filename and "lib/python" not in filename and not filename.startswith("<")

def build_error_event(exc: BaseException, level: str = "error", request_url: Optional[str] = None, request_method: Optional[str] = None, client_ip: Optional[str] = None) -> Dict[str, Any]:
    evt: Dict[str, Any] = {
        "_type": "error",
        "error_type": type(exc).__name__,
        "error_message": str(exc),
        "level": level,
        "stack_frames": parse_python_stack(exc),
        "timestamp": int(time.time() * 1000),
    }
    if request_url: evt["request_url"] = request_url
    if request_method: evt["request_method"] = request_method
    if client_ip: evt["client_ip"] = client_ip
    return evt


_monitor_ref = None
_hooks_installed = False

def _install_hooks(monitor):
    global _monitor_ref, _hooks_installed
    _monitor_ref = monitor
    if _hooks_installed: return
    _hooks_installed = True

    _prev_excepthook = sys.excepthook
    def _excepthook(exc_type, exc_value, exc_tb):
        if _monitor_ref and _monitor_ref.is_enabled():
            try: _monitor_ref.capture_exception(exc_value)
            except Exception: pass
        _prev_excepthook(exc_type, exc_value, exc_tb)
    sys.excepthook = _excepthook

    if hasattr(threading, "excepthook"):
        _prev_thread_hook = threading.excepthook
        def _thread_excepthook(args):
            if _monitor_ref and _monitor_ref.is_enabled() and args.exc_value:
                try: _monitor_ref.capture_exception(args.exc_value)
                except Exception: pass
            _prev_thread_hook(args)
        threading.excepthook = _thread_excepthook
