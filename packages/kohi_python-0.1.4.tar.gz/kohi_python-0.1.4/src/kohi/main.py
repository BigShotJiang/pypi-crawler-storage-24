from __future__ import annotations
import logging, time
from typing import Any, Dict, Optional
from .core import SchemaUserConfig
from .send import SenderPool
from .errors import build_error_event, _install_hooks
logger = logging.getLogger("kohi.monitor")

class Monitor:
  def __init__(self, app: Optional[Any] = None, *, project_key: str, secret_key: str, enabled: bool = True, endpoint: Optional[str] = None):
    if not enabled:
      self.cfg, self._pool = None, None
      return
    self.cfg = SchemaUserConfig(project_key=project_key, secret_key=secret_key, enabled=enabled, endpoint=endpoint)
    self._pool = SenderPool(cfg=self.cfg, workers=2, timeout_s=10.0, endpoint=endpoint)
    _install_hooks(self)
    self._auto_instrument(app)

  def _auto_instrument(self, app) -> None:
    if app is None: return
    try:
      app_type = type(app).__name__
      if app_type == "FastAPI":
        from .integrations.fastapi import instrument
        instrument(self, app)
      elif app_type == "Flask":
        from .integrations.flask import instrument
        instrument(self, app)
      else: logger.warning(f"unsupported app type: {app_type}")
    except ImportError as e: logger.error(f"missing integration: {e}")
    except Exception as e: logger.error(f"instrumentation failed: {e}")

  def is_enabled(self) -> bool: return self._pool is not None

  def add_event(self, event: Dict[str, Any]) -> None:
    if self._pool: self._pool.submit(event)

  def capture_exception(self, exc: BaseException, *, fingerprint: Optional[str] = None) -> None:
    if not self._pool or exc is None: return
    evt = build_error_event(exc, "error")
    if fingerprint: evt["fingerprint"] = fingerprint
    self._pool.submit(evt)

  def _capture_exception_with_request(self, exc: BaseException, request_url: str, request_method: str, client_ip: Optional[str] = None) -> None:
    if not self._pool or exc is None: return
    evt = build_error_event(exc, "error", request_url, request_method, client_ip)
    self._pool.submit(evt)

  def capture_message(self, msg: str, level: str = "error") -> None:
    if not self._pool: return
    evt = {"_type": "error", "error_type": "Message", "error_message": msg, "level": level,
           "stack_frames": [], "timestamp": int(time.time() * 1000)}
    self._pool.submit(evt)

  def shutdown(self, timeout: float = 30.0) -> None:
    if self._pool: self._pool.shutdown(timeout)
  def close(self) -> None: self.shutdown()
