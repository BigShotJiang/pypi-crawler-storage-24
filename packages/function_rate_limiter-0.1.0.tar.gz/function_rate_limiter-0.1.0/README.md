# Function Rate Limiter

A simple Python library to rate limit function calls to a specific number of times per second/minute.

## Installation

```bash
pip install .
```

## Usage

You can use the `@rate_limit` decorator to easily limit how frequently a function is executed.

### Blocking (Wait)
By default, the rate limiter will block and wait until the function is allowed to run.

```python
import time
from function_rate_limiter import rate_limit

# Allow 2 calls per 5 seconds
@rate_limit(max_calls=2, period=5)
def print_hello():
    print(f"Hello at {time.strftime('%X')}")

for _ in range(5):
    print_hello()
```

### Non-Blocking (Raise Exception)
If you don't want the function to block, set `wait=False`. It will raise a `RateLimitExceeded` exception instead.

```python
from function_rate_limiter import rate_limit, RateLimitExceeded

@rate_limit(max_calls=2, period=5, wait=False)
def quick_task():
    print("Doing work...")

try:
    for _ in range(5):
        quick_task()
except RateLimitExceeded as e:
    print(f"Error: {e}")
```
