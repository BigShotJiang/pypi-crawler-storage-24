import time
import threading
from functools import wraps
from typing import Callable, Any

class RateLimitExceeded(Exception):
    """Exception raised when rate limit is exceeded and wait=False."""
    pass

class RateLimiter:
    def __init__(self, max_calls: int, period: float, wait: bool = True):
        """
        :param max_calls: Maximum number of calls allowed in the period.
        :param period: Time period in seconds.
        :param wait: If True, blocks until the function can be called. If False, raises RateLimitExceeded.
        """
        self.max_calls = max_calls
        self.period = period
        self.wait = wait
        self.calls = []
        self.lock = threading.Lock()

    def __call__(self, func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Any:
            with self.lock:
                now = time.time()
                # Remove timestamps older than the time period
                self.calls = [t for t in self.calls if now - t < self.period]
                
                if len(self.calls) >= self.max_calls:
                    if not self.wait:
                        raise RateLimitExceeded(f"Rate limit of {self.max_calls} calls per {self.period}s exceeded.")
                    
                    # Calculate time to wait
                    oldest_call = self.calls[0]
                    sleep_time = self.period - (now - oldest_call)
                    
                    if sleep_time > 0:
                        time.sleep(sleep_time)
                    
                    # Update 'now' after sleeping
                    now = time.time()
                    self.calls = [t for t in self.calls if now - t < self.period]

                self.calls.append(now)
            
            return func(*args, **kwargs)
        
        return wrapper

def rate_limit(max_calls: int, period: float, wait: bool = True):
    """
    Decorator to rate limit a function.
    
    :param max_calls: Maximum number of calls allowed within the period.
    :param period: Time period in seconds.
    :param wait: If True, blocks until the function can be called. If False, raises a RateLimitExceeded exception.
    """
    return RateLimiter(max_calls, period, wait=wait)
