import subprocess
import click
import sys
import datetime
from typing import Optional
from loguru import logger


def get_staged_diff() -> str:
    """
    Retrieves the staged Git diff from the current repository.

    Returns:
        str: The diff output as a string.

    Raises:
        SystemExit: If there are no staged changes or an error occurs while fetching the diff.
    """
    logger.debug("Attempting to retrieve staged Git diff...")
    try:
        result = subprocess.run(
            ["git", "diff", "--cached"],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            check=False
        )

        if result.returncode != 0:
            logger.error(f"Git diff command failed: {result.stderr.strip()}")
            click.secho("❌ Failed to run git diff. Are you in a Git repo?", fg="red")
            sys.exit(1)

        if not result.stdout.strip():
            logger.warning("No staged changes found.")
            click.secho("⚠️ No staged changes found. Stage changes with `git add`.", fg="yellow")
            sys.exit(1)

        logger.info("Successfully retrieved staged Git diff.")
        return result.stdout

    except Exception as e:
        logger.exception(e)
        click.secho("❌ Unexpected error retrieving git diff.", fg="red")
        sys.exit(1)

def get_staged_files():
    result = subprocess.run(
        ["git", "diff", "--name-only", "--cached"],
        capture_output=True, text=True, check=True
    )
    return set(result.stdout.strip().splitlines())


def get_renamed_files():
    output = subprocess.check_output(['git', 'diff', '--cached', '--name-status', '-M']).decode()
    renamed = {}
    for line in output.strip().split('\n'):
        if line.startswith('R'):  # Rename detected
            parts = line.split()
            if len(parts) == 3:
                _, old, new = parts
                renamed[old] = new
    return renamed


def get_commit_info(commit_id: str = "HEAD") -> tuple:
    """
    Return (message, diff) for the given commit.

    Args:
        commit_id (str): A commit hash, ref, or HEAD.

    Returns:
        tuple[str, str]: Commit message and full diff.
    """
    try:
        message = subprocess.check_output(
            ["git", "log", "-1", "--pretty=%B", commit_id],
            stderr=subprocess.PIPE
        ).decode().strip()

        diff = subprocess.check_output(
            ["git", "show", "--stat", "--patch", commit_id],
            stderr=subprocess.PIPE
        ).decode().strip()

        return message, diff
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Could not read commit '{commit_id}': {e.stderr.decode().strip()}")


def get_recent_commits(n: int) -> list:
    """
    Return the last n commits as a list of dicts with hash, author, date, message.

    Args:
        n (int): Number of commits to retrieve.

    Returns:
        list[dict]: Each dict has keys: hash, author, date, message.
    """
    try:
        output = subprocess.check_output(
            ["git", "log", f"-{n}", "--pretty=format:%H|%an|%as|%B|END_COMMIT"],
            stderr=subprocess.PIPE
        ).decode().strip()
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Could not read git log: {e.stderr.decode().strip()}")

    commits = []
    for block in output.split("|END_COMMIT"):
        block = block.strip()
        if not block:
            continue
        parts = block.split("|", 3)
        if len(parts) == 4:
            commits.append({
                "hash": parts[0][:8],
                "author": parts[1],
                "date": parts[2],
                "message": parts[3].strip(),
            })
    return commits


def get_file_blame(filepath: str) -> list:
    """
    Run git blame --porcelain on a file and return blame groups.

    Each group represents consecutive lines that share the same commit:
    {commit_id, author, date, message, start_line, end_line, lines}

    Args:
        filepath (str): Path to the file.

    Returns:
        list[dict]: Blame groups ordered by line number.
    """
    try:
        output = subprocess.check_output(
            ["git", "blame", "--porcelain", filepath],
            stderr=subprocess.PIPE
        ).decode()
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Could not blame '{filepath}': {e.stderr.decode().strip()}")

    commit_meta = {}
    line_entries = []

    lines = output.split("\n")
    i = 0
    while i < len(lines):
        line = lines[i]
        if not line:
            i += 1
            continue

        parts = line.split()
        # Porcelain header: <40-char hash> <orig> <final> [<count>]
        if len(parts) >= 3 and len(parts[0]) == 40:
            commit_hash = parts[0]
            final_line = int(parts[2])

            if commit_hash not in commit_meta:
                commit_meta[commit_hash] = {"author": "", "date": "", "message": ""}
                i += 1
                while i < len(lines) and not lines[i].startswith("\t"):
                    meta = lines[i]
                    if meta.startswith("author ") and not meta.startswith("author-"):
                        commit_meta[commit_hash]["author"] = meta[7:]
                    elif meta.startswith("author-time "):
                        ts = int(meta[12:])
                        commit_meta[commit_hash]["date"] = datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
                    elif meta.startswith("summary "):
                        commit_meta[commit_hash]["message"] = meta[8:]
                    i += 1
            else:
                i += 1
                while i < len(lines) and not lines[i].startswith("\t"):
                    i += 1

            if i < len(lines) and lines[i].startswith("\t"):
                line_entries.append((commit_hash, final_line, lines[i][1:]))
                i += 1
        else:
            i += 1

    # Group consecutive lines by commit
    groups = []
    current: Optional[dict] = None
    for commit_hash, line_num, content in line_entries:
        if current is None or current["commit_id"] != commit_hash:
            if current is not None:
                groups.append(current)
            meta = commit_meta.get(commit_hash, {})
            current = {
                "commit_id": commit_hash[:8],
                "author": meta.get("author", ""),
                "date": meta.get("date", ""),
                "message": meta.get("message", ""),
                "start_line": line_num,
                "end_line": line_num,
                "lines": [content],
            }
        else:
            current["end_line"] = line_num
            current["lines"].append(content)
    if current is not None:
        groups.append(current)

    return groups


def get_file_history(filepath: str) -> list:
    """
    Return the commit history for a file (following renames).

    Args:
        filepath (str): Path to the file.

    Returns:
        list[dict]: Each dict has keys: hash, author, date, message.
    """
    try:
        output = subprocess.check_output(
            ["git", "log", "--follow", "--pretty=format:%h|%an|%as|%s", "--", filepath],
            stderr=subprocess.PIPE
        ).decode().strip()
    except subprocess.CalledProcessError as e:
        raise RuntimeError(f"Could not read history for '{filepath}': {e.stderr.decode().strip()}")

    commits = []
    for line in output.splitlines():
        parts = line.split("|", 3)
        if len(parts) == 4:
            commits.append({
                "hash": parts[0],
                "author": parts[1],
                "date": parts[2],
                "message": parts[3],
            })
    return commits
