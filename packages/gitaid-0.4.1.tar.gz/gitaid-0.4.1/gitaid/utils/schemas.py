from enum import Enum
from pydantic import BaseModel
from typing import List


class IssueType(str, Enum):
    typo = "typo"
    grammar = "grammar"
    logic = "logic"


class Issue(BaseModel):
    type: IssueType
    message: str


class IssueDetectionOutput(BaseModel):
    issues: List[Issue]


class CommitGroup(BaseModel):
    title: str
    files: List[str]


class SplitCommitOutput(BaseModel):
    groups: List[CommitGroup]