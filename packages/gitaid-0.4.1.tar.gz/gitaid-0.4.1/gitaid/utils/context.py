import re
from gitaid.utils.config import load_config
import requests
import keyring


def get_jira_context(issue_id: str) -> str:
    """
    Fetch Jira issue details (Summary, Description, Comments) from Jira API.

    Args:
        issue_id (str): Jira issue key, e.g. "GA-23"

    Returns:
        str: Combined issue details as string for prompt context.

    Raises:
        Exception if fetching fails or config is incomplete.
    """
    config = load_config()
    issue_tracker_cfg = config.get("issue_tracker", {})
    if issue_tracker_cfg.get("type") != "jira":
        raise Exception("Jira is not configured as the issue tracker.")

    jira_url = issue_tracker_cfg.get("url")
    jira_email = issue_tracker_cfg.get("email")
    if not jira_url or not jira_email:
        raise Exception("Incomplete Jira configuration.")

    # Retrieve Jira API token from keyring
    jira_token = keyring.get_password("gitaid", "JIRA_API_TOKEN")
    if not jira_token:
        raise Exception("Jira API token not found in keyring.")

    # Prepare Jira API endpoint
    api_endpoint = f"{jira_url.rstrip('/')}/rest/api/2/issue/{issue_id}?fields=summary,description,comment"

    # Basic Auth with email and token
    auth = (jira_email, jira_token)

    headers = {
        "Accept": "application/json"
    }

    response = requests.get(api_endpoint, auth=auth, headers=headers)
    if response.status_code != 200:
        raise Exception(f"Failed to fetch Jira issue {issue_id}: {response.status_code} {response.text}")

    data = response.json()

    fields = data.get("fields", {})
    summary = fields.get("summary", "No summary available.")
    description = fields.get("description", "No description available.")

    comments_data = fields.get("comment", {}).get("comments", [])
    comments = []
    for comment in comments_data:
        author = comment.get("author", {}).get("displayName", "Unknown")
        body = comment.get("body", "").strip()
        comments.append(f"- {author}: {body}")

    comments_str = "\n".join(comments) if comments else "No comments."

    result = (
        f"Jira Issue {issue_id}:\n"
        f"Summary: {summary}\n"
        f"Description: {description}\n"
        f"Comments:\n{comments_str}"
    )

    return result


def extract_and_fetch_issue_context(text: str) -> str:
    """
    Scan text for Jira-style issue keys (e.g. GA-31), fetch context for each,
    and return a combined string ready to inject into an LLM prompt.

    Silently skips keys that fail to fetch (Jira not configured, network error, etc.).

    Args:
        text (str): Any text that may contain issue keys - commit messages, diffs, etc.

    Returns:
        str: Combined Jira context for all found keys, or empty string if none.
    """
    keys = list(dict.fromkeys(re.findall(r'\b[A-Z]+-\d+\b', text)))
    if not keys:
        return ""

    contexts = []
    for key in keys:
        try:
            ctx = get_jira_context(key)
            contexts.append(ctx)
        except Exception:
            pass

    return "\n\n".join(contexts)