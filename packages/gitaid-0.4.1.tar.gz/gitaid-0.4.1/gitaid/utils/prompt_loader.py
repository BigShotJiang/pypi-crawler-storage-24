import yaml
from pathlib import Path
from loguru import logger

PROMPT_DIR = Path(__file__).resolve().parent.parent / "prompts"

def load_prompt(file: str, key: str) -> dict:
    """
    Load a specific prompt (e.g., 'generate_commit') from a YAML file (e.g., 'commit.yaml').
    """
    path = PROMPT_DIR / f"{file}.yaml"
    
    if not path.exists():
        logger.error(f"Prompt file '{file}.yaml' not found at {path}")
        raise FileNotFoundError(f"Prompt file '{file}.yaml' not found.")
    
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except Exception as e:
        logger.error(f"Failed to load YAML file '{file}.yaml': {e}")
        raise
    
    if key not in data:
        logger.error(f"Prompt key '{key}' not found in '{file}.yaml'.")
        raise KeyError(f"Prompt key '{key}' not found in '{file}.yaml'.")
    
    logger.info(f"Loaded prompt '{key}' from '{file}.yaml'")
    return data[key]
