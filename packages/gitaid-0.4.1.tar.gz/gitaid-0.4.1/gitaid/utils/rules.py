import os
from pathlib import Path
from typing import Optional

from loguru import logger

RULES_FILENAME = ".gitaid-rules.md"


def load_rules() -> Optional[str]:
    """
    Load commit message rules from .gitaid-rules.md in the current repo root.

    Returns:
        str: The rules content, or None if the file does not exist.
    """
    rules_path = Path(os.getcwd()) / RULES_FILENAME
    if rules_path.exists():
        content = rules_path.read_text(encoding="utf-8").strip()
        if content:
            logger.info(f"Loaded commit rules from {rules_path}")
            return content
    return None


def apply_rules(system_prompt: str, rules: Optional[str]) -> str:
    """
    Append user-defined rules to a system prompt if rules are present.

    Args:
        system_prompt (str): The base system prompt.
        rules (str | None): Rules loaded from .gitaid-rules.md.

    Returns:
        str: The system prompt with rules appended, or unchanged if no rules.
    """
    if not rules:
        return system_prompt
    return (
        system_prompt
        + "\n\nUser-defined commit message rules (follow these strictly):\n"
        + rules
    )
