import click

def open_editor_with_template(template: str) -> str:
    """
    Open a text editor with a pre-filled commit message or template.
    Returns edited content or None if user exited without saving.
    """
    edited = click.edit(template)
    return edited.strip() if edited else None

def ask_to_commit_or_retry() -> str:
    """
    Prompt the user to decide what to do after exiting the editor without saving.
    Returns: one of "edit", "commit", or "cancel"
    """
    options = {
        'e': 'edit',
        'c': 'commit',
        'q': 'cancel'
    }

    while True:
        click.secho("\n💬 You exited without saving. What would you like to do?", fg="yellow")
        click.secho("[E] Edit again", fg="cyan")
        click.secho("[C] Commit anyway", fg="green")
        click.secho("[Q] Quit", fg="red")
        choice = click.prompt("Enter your choice", default="e", show_default=False).lower()

        if choice in options:
            return options[choice]
        click.secho("❌ Invalid choice. Please enter E, C, or Q.", fg="red")
