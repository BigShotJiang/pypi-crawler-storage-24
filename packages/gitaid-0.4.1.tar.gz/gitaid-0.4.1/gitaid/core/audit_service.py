import click
from loguru import logger

from gitaid.utils.git import get_commit_info
from gitaid.utils.context import extract_and_fetch_issue_context
from gitaid.utils.prompt_loader import load_prompt
from gitaid.utils.rules import load_rules, apply_rules
from gitaid.core.llm import LLM


def load_audit_prompt():
    try:
        prompt = load_prompt("audit", "audit_commit")
        return prompt["system"], prompt["user"]
    except (FileNotFoundError, KeyError) as e:
        logger.error(f"Failed to load audit prompt: {e}")
        raise RuntimeError("Internal error: cannot load audit prompt.")


def audit_commit(commit_id: str = "HEAD") -> str:
    """
    Audit a single commit and return a structured findings report.

    Args:
        commit_id (str): Commit hash, ref, or HEAD.

    Returns:
        str: LLM audit report.
    """
    logger.info(f"Auditing commit: {commit_id}")

    message, diff = get_commit_info(commit_id)
    issue_context = extract_and_fetch_issue_context(message)

    rules = load_rules()
    system_prompt, user_template = load_audit_prompt()
    system_prompt = apply_rules(system_prompt, rules)

    user_prompt = user_template.format(
        message=message,
        diff=diff,
        issue_context=issue_context or "None",
    )

    llm = LLM(system_prompt)
    return llm.completion(user_prompt)
