import json
import subprocess
from loguru import logger
import click
from pydantic import ValidationError

from gitaid.utils.git import (
    get_staged_diff,
    get_staged_files,
    get_renamed_files
)
from gitaid.utils.prompt_loader import load_prompt
from gitaid.core.llm import LLM
from gitaid.utils.editor import open_editor_with_template
from gitaid.core.commit_service import generate_and_commit_message
from gitaid.utils.schemas import SplitCommitOutput
from gitaid.utils.context import get_jira_context


def load_split_commit_prompt():
    try:
        prompt = load_prompt("split_commit", "split_commit")
        return prompt["system"], prompt["user"]
    except Exception as e:
        logger.error(f"Failed to load split commit prompt: {e}")
        raise RuntimeError("Cannot load prompt for split commit.")


def parse_group_json(json_text: str, valid_files: set, renames: dict) -> SplitCommitOutput:
    try:
        # Remove lines that start with '#' (comments)
        cleaned_lines = [
            line for line in json_text.splitlines()
            if not line.strip().startswith("#")
        ]
        cleaned_json = "\n".join(cleaned_lines).strip()

        # Parse JSON
        raw = json.loads(cleaned_json)
        parsed = SplitCommitOutput.parse_obj(raw)

        # Validate that all files are valid staged files
        for group in parsed.groups:
            for file_entry in group.files:
                if "(Hunk" in file_entry:
                    file_path = file_entry.split(" (Hunk")[0].strip()
                else:
                    file_path = file_entry.strip()

                if not is_valid_file(file_path, valid_files, renames):
                    raise RuntimeError(f"❌ Invalid file in group: '{file_path}' is not staged.")

        return parsed

    except json.JSONDecodeError as e:
        logger.error(f"JSON decode error: {e}")
        raise RuntimeError("❌ JSON is not valid.")
    except ValidationError as e:
        logger.error(f"Validation error: {e}")
        raise RuntimeError("❌ Structure doesn't match expected format.")


def is_valid_file(file: str, staged_files: set, renames: dict) -> bool:
    if file in staged_files:
        return True
    elif file in renames:
        return renames[file] in staged_files
    return False

def generate_and_split_commit_groups_and_commit(issue_id=None):
    diff = get_staged_diff()
    valid_files = get_staged_files()
    renamed_files = get_renamed_files()

    name_status_str = "\n".join(sorted(valid_files))
    system_prompt, user_template = load_split_commit_prompt()
    user_prompt = user_template.format(name_status=name_status_str, diff=diff)

    llm = LLM(system_prompt)
    proposed_json = llm.completion(user_prompt)

    editable_json = (
        "# Edit the commit groups below.\n"
        "# Only use these staged files:\n"
        + "\n".join(f"# - {f}" for f in sorted(valid_files))
        + "\n\n"
        + proposed_json
    )

    edited_json = open_editor_with_template(editable_json)
    if not edited_json:
        edited_json = proposed_json

    parsed = parse_group_json(edited_json, valid_files, renamed_files)

    if issue_id:
        issue_context = get_jira_context(issue_id)
    else:
        issue_context = None

    for i, group in enumerate(parsed.groups):
        click.secho(f"\n🚧 Committing group {i + 1}: {group.title}", fg="cyan")

        # Reset all staged files
        subprocess.run(["git", "reset"], check=True)

        # Stage only the files in this group
        files_to_stage = [renamed_files.get(f, f) for f in group.files]
        subprocess.run(["git", "add", "--", *files_to_stage], check=True)

        # Get the diff for currently staged group
        group_diff = get_staged_diff()

        # Commit
        success = generate_and_commit_message(diff=group_diff, issue_context=issue_context)

        if not success:
            click.secho(f"⚠️ Skipped committing group {i + 1}: {group.title}", fg="yellow")