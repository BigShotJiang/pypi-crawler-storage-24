from loguru import logger

from gitaid.utils.git import get_file_history
from gitaid.utils.context import extract_and_fetch_issue_context
from gitaid.utils.prompt_loader import load_prompt
from gitaid.core.llm import LLM


def load_why_prompt():
    try:
        prompt = load_prompt("why", "why_file")
        return prompt["system"], prompt["user"]
    except (FileNotFoundError, KeyError) as e:
        logger.error(f"Failed to load why prompt: {e}")
        raise RuntimeError("Internal error: cannot load why prompt.")


def explain_file_history(filepath: str) -> str:
    """
    Explain why a file exists and how it evolved across its commit history.

    Args:
        filepath (str): Path to the file.

    Returns:
        str: Narrative explanation of the file's history.
    """
    logger.info(f"Explaining history of: {filepath}")

    history = get_file_history(filepath)
    if not history:
        return f"No commit history found for '{filepath}'."

    # Build history text for the prompt (oldest first)
    history_reversed = list(reversed(history))
    history_text = ""
    for c in history_reversed:
        history_text += f"[{c['hash']}] {c['date']} - {c['author']}: {c['message']}\n"

    all_messages = " ".join(c["message"] for c in history)
    issue_context = extract_and_fetch_issue_context(all_messages)

    system_prompt, user_template = load_why_prompt()
    user_prompt = user_template.format(
        filepath=filepath,
        history=history_text.strip(),
        issue_context=issue_context or "None",
    )

    llm = LLM(system_prompt)
    return llm.completion(user_prompt)
