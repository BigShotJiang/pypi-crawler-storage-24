from loguru import logger

from gitaid.utils.git import get_file_blame
from gitaid.utils.context import extract_and_fetch_issue_context
from gitaid.utils.prompt_loader import load_prompt
from gitaid.core.llm import LLM


def load_blame_prompt():
    try:
        prompt = load_prompt("blame", "blame_explain")
        return prompt["system"], prompt["user"]
    except (FileNotFoundError, KeyError) as e:
        logger.error(f"Failed to load blame prompt: {e}")
        raise RuntimeError("Internal error: cannot load blame prompt.")


def explain_blame(filepath: str) -> str:
    """
    Run empathetic git blame on a file - groups lines by commit and explains
    the intent behind each section.

    Args:
        filepath (str): Path to the file to blame.

    Returns:
        str: Formatted blame output with LLM explanations per section.
    """
    logger.info(f"Running empathetic blame on: {filepath}")

    groups = get_file_blame(filepath)
    if not groups:
        return "No blame information found."

    # Build sections text for the prompt
    sections_text = ""
    all_messages = ""
    for i, g in enumerate(groups, 1):
        line_range = (
            f"Line {g['start_line']}"
            if g["start_line"] == g["end_line"]
            else f"Lines {g['start_line']}-{g['end_line']}"
        )
        code_preview = "\n".join(g["lines"][:5])
        if len(g["lines"]) > 5:
            code_preview += f"\n  ... ({len(g['lines']) - 5} more lines)"

        sections_text += (
            f"Section {i}: {line_range}\n"
            f"  Commit: {g['commit_id']} | Author: {g['author']} | Date: {g['date']}\n"
            f"  Message: {g['message']}\n"
            f"  Code:\n    {code_preview}\n\n"
        )
        all_messages += f" {g['message']}"

    issue_context = extract_and_fetch_issue_context(all_messages)

    system_prompt, user_template = load_blame_prompt()
    user_prompt = user_template.format(
        filepath=filepath,
        sections=sections_text.strip(),
        issue_context=issue_context or "None",
    )

    llm = LLM(system_prompt)
    explanations_raw = llm.completion(user_prompt)

    # Parse LLM response back into per-section lines and interleave with blame info
    explanation_lines = {}
    for line in explanations_raw.splitlines():
        line = line.strip()
        if line.startswith("Section "):
            parts = line.split(":", 1)
            if len(parts) == 2:
                try:
                    idx = int(parts[0].replace("Section ", "").strip())
                    explanation_lines[idx] = parts[1].strip()
                except ValueError:
                    pass

    # Build final output
    output_lines = [f"\n  Empathetic blame: {filepath}\n", "=" * 60]
    for i, g in enumerate(groups, 1):
        line_range = (
            f"Line {g['start_line']}"
            if g["start_line"] == g["end_line"]
            else f"Lines {g['start_line']}-{g['end_line']}"
        )
        why = explanation_lines.get(i, "(no explanation)")
        output_lines.append(
            f"\n{line_range}  |  {g['author']}  |  {g['date']}  |  {g['commit_id']}"
        )
        output_lines.append(f"  Commit: {g['message']}")
        output_lines.append(f"  Why:    {why}")
        output_lines.append("-" * 60)

    return "\n".join(output_lines)
