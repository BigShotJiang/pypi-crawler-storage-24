from loguru import logger

from gitaid.utils.prompt_loader import load_prompt
from gitaid.utils.git import get_staged_diff
from gitaid.core.llm import LLM


def load_commit_prompt():
    """
    Load the system and user prompt templates for explanation generation.

    Returns:
        tuple[str, str]: A tuple containing the system and user prompts.

    Raises:
        RuntimeError: If prompt templates are missing or malformed.
    """
    try:
        prompt = load_prompt("explain", "generate_explanation")
        return prompt["system"], prompt["user"]
    except (FileNotFoundError, KeyError) as e:
        logger.error(f"Failed to load explain generation prompt: {e}")
        raise RuntimeError("Internal error: cannot load explain prompt.")
    

def generate_explain_message():
    """
    Orchestrates the full explanation generation flow:
    1. Retrieves the staged Git diff.
    2. Generates an explanation using an LLM.
    """
    diff = get_staged_diff()
    system_prompt, user_template = load_commit_prompt()
    user_prompt = user_template.format(diff=diff)
    llm = LLM(system_prompt)
    explanation = llm.completion(user_prompt)
    return explanation
