import subprocess
import click
from loguru import logger

from pydantic import ValidationError

from gitaid.utils.git import get_staged_diff
from gitaid.utils.editor import open_editor_with_template, ask_to_commit_or_retry
from gitaid.utils.prompt_loader import load_prompt
from gitaid.utils.rules import load_rules, apply_rules
from gitaid.core.llm import LLM
from gitaid.utils.schemas import IssueDetectionOutput
from gitaid.utils.context import get_jira_context


def load_commit_prompt():
    """
    Load the system and user prompt templates for commit generation.

    Returns:
        tuple[str, str]: A tuple containing the system and user prompts.

    Raises:
        RuntimeError: If prompt templates are missing or malformed.
    """
    try:
        prompt = load_prompt("commit", "generate_commit")
        return prompt["system"], prompt["user"]
    except (FileNotFoundError, KeyError) as e:
        logger.error(f"Failed to load commit generation prompt: {e}")
        raise RuntimeError("Internal error: cannot load commit prompt.")


def load_review_prompts():
    """
    Load the system and user prompt templates for issue detection and fixing.

    Returns:
        tuple[str, str, str, str]: The detect and fix prompt templates.

    Raises:
        RuntimeError: If prompt templates are missing or malformed.
    """
    try:
        prompts = load_prompt("review", "review_commit")
        return prompts["detect_issues_system"], prompts["detect_issues_user"], \
               prompts["fix_issues_system"], prompts["fix_issues_user"]
    except (FileNotFoundError, KeyError) as e:
        logger.error(f"Failed to load commit review prompts: {e}")
        raise RuntimeError("Internal error: cannot load commit review prompts.")


def commit_message(message: str):
    """
    Run the git commit command with the given message.

    Args:
        message (str): The commit message.
    """
    subprocess.run(["git", "commit", "-m", message], check=True)
    click.secho("✅ Commit successful.", fg="green")
    logger.info("Commit executed.")


def generate_initial_commit_message(system_prompt, user_prompt):
    """
    Generate a commit message using the LLM.

    Args:
        system_prompt (str): The system-level LLM instruction.
        user_prompt (str): The user prompt containing the git diff.

    Returns:
        str: A suggested commit message.

    Raises:
        RuntimeError: If LLM fails to generate a message.
    """
    try:
        llm = LLM(system_prompt)
        return llm.completion(user_prompt)
    except Exception as e:
        logger.exception(e)
        raise RuntimeError("Failed to generate commit message from LLM.")


def edit_commit_message(message: str, diff: str) -> str:
    """
    Allow user to edit the commit message via an editor.

    Args:
        message (str): The initial commit message.
        diff (str): The staged Git diff to show as comments.

    Returns:
        str: The final edited message by the user.

    Raises:
        RuntimeError: If user cancels the edit process.
    """
    # Prepare the message with diff as comments at the bottom separated by some blank comment lines
    comment_diff = "\n# \n# --- Staged Changes ---\n"
    comment_diff += "\n".join(f"# {line}" for line in diff.splitlines())
    
    template_with_diff = message + comment_diff
    
    edited = open_editor_with_template(template_with_diff)
    while edited is None:
        action = ask_to_commit_or_retry()
        if action == "edit":
            edited = open_editor_with_template(template_with_diff)
        elif action == "commit":
            commit_message(message)
            logger.info("User committed original suggestion without edits.")
            return message
        else:
            raise RuntimeError("Commit canceled by user.")
    # Strip out commented lines (diff) before returning the final commit message
    # We want to return only the user’s message, not the diff comments
    cleaned_lines = []
    for line in edited.splitlines():
        if not line.startswith("#"):
            cleaned_lines.append(line)
    return "\n".join(cleaned_lines).strip()


def detect_issues(system_prompt: str, user_prompt_template: str, original_msg: str) -> IssueDetectionOutput:
    """
    Use LLM to detect grammar, logic, or style issues in a commit message.

    Args:
        system_prompt (str): System prompt for LLM.
        user_prompt_template (str): User prompt template.
        original_msg (str): The commit message to analyze.

    Returns:
        IssueDetectionOutput: A list of detected issues.
    """
    llm = LLM(system_prompt)
    user_prompt = user_prompt_template.format(message=original_msg)
    raw = llm.completion(user_prompt)

    try:
        parsed = IssueDetectionOutput.model_validate_json(raw)
        logger.info("✅ Issues parsed successfully.")
        return parsed
    except ValidationError as ve:
        logger.error(f"❌ Failed to parse issue detection response: {ve}")
        return IssueDetectionOutput(issues=[])


def request_fix(system_prompt: str, user_prompt_template: str, original_msg: str, diff: str, issues) -> str:
    """
    Use LLM to automatically fix issues in a commit message.

    Args:
        system_prompt (str): System prompt for the LLM.
        user_prompt_template (str): Template to instruct the LLM to fix the issues.
        original_msg (str): The commit message to fix.
        diff (str): The Git diff for context.
        issues (IssueDetectionOutput): Parsed list of detected issues.

    Returns:
        str: A revised commit message.
    """
    llm = LLM(system_prompt)
    user_prompt = user_prompt_template.format(
        message=original_msg,
        diff=diff,
        issues=issues.model_dump_json(indent=2)
    )
    return llm.completion(user_prompt)


def review_and_validate_message(original: str, edited: str, diff: str, rules=None):
    """
    Review a user-edited commit message for issues and apply fixes if needed.

    Args:
        original (str): The original suggested message.
        edited (str): The user-edited message.
        diff (str): Git diff for context.
        rules (str | None): User-defined rules from .gitaid-rules.md.

    Raises:
        RuntimeError: If the user cancels the commit process.
    """
    detect_system, detect_user, fix_system, fix_user = load_review_prompts()
    detect_system = apply_rules(detect_system, rules)
    fix_system = apply_rules(fix_system, rules)

    issues = detect_issues(detect_system, detect_user, edited)

    if not issues.issues:
        click.secho("✅ Commit message looks good!", fg="green")
        commit_message(edited)
        return True  # ✅ committed successfully

    logger.info("⚠️ Issues found with the commit message.")
    fixed = request_fix(fix_system, fix_user, edited, diff, issues)

    # Prepare commit editing template
    commented_edited = edited.replace('\n', '\n# ')
    formatted_issues = "\n# ".join(
        f"{i + 1}. {issue.type} - {issue.message}" for i, issue in enumerate(issues.issues)
    )

    template = (
        f"# 🧠 LLM found issues with your commit message.\n"
        f"# Issues:\n"
        f"# {formatted_issues}\n\n"
        f"{fixed}\n\n"
        f"# Your original message:\n"
        f"# {commented_edited}\n"
    )

    second_edit = open_editor_with_template(template)
    if second_edit is None:
        second_edit = fixed  # fallback to fixed suggestion if editor was closed

        # Prompt user for next action
        action = ask_to_commit_or_retry()
        if action == "edit":
            return review_and_validate_message(original, edited, diff, rules=rules)
        elif action == "commit":
            commit_message(fixed)
            return True
        else:
            return False  # ❌ user chose to quit
    else:
        # Recursively validate the new message
        return review_and_validate_message(original, second_edit, diff, rules=rules)

def generate_and_commit_message(issue_id=None, diff=None, issue_context=None):
    if diff is None:
        diff = get_staged_diff()

    if issue_context is None and issue_id:
        issue_context = get_jira_context(issue_id)

    rules = load_rules()

    system_prompt, user_template = load_commit_prompt()
    system_prompt = apply_rules(system_prompt, rules)
    user_prompt = user_template.format(diff=diff, issue=issue_context or "")

    suggested = generate_initial_commit_message(system_prompt, user_prompt)
    edited = edit_commit_message(suggested, diff)
    return review_and_validate_message(suggested, edited, diff, rules=rules)
