from loguru import logger

from gitaid.utils.git import get_recent_commits
from gitaid.utils.context import extract_and_fetch_issue_context
from gitaid.utils.prompt_loader import load_prompt
from gitaid.core.llm import LLM


def load_history_tldr_prompt():
    try:
        prompt = load_prompt("history_tldr", "history_tldr")
        return prompt["system"], prompt["user"]
    except (FileNotFoundError, KeyError) as e:
        logger.error(f"Failed to load history_tldr prompt: {e}")
        raise RuntimeError("Internal error: cannot load history-tldr prompt.")


def generate_history_tldr(last: int = 10) -> str:
    """
    Summarise the last N commits as a grouped changelog.

    Args:
        last (int): Number of recent commits to include.

    Returns:
        str: Human-readable changelog summary.
    """
    logger.info(f"Generating history tldr for last {last} commits.")

    commits = get_recent_commits(last)
    if not commits:
        return "No commits found."

    # Build a readable block for the prompt
    commits_text = ""
    for i, c in enumerate(commits, 1):
        commits_text += f"{i}. [{c['hash']}] {c['date']} - {c['author']}\n   {c['message']}\n\n"

    # Extract issue keys from all messages combined and fetch Jira context
    all_messages = " ".join(c["message"] for c in commits)
    issue_context = extract_and_fetch_issue_context(all_messages)

    system_prompt, user_template = load_history_tldr_prompt()
    user_prompt = user_template.format(
        n=last,
        commits=commits_text.strip(),
        issue_context=issue_context or "None",
    )

    llm = LLM(system_prompt)
    return llm.completion(user_prompt)
