from gitaid.issue_trackers.base import IssueTracker
import click
import keyring
from gitaid.utils.validators import is_valid_github_token

class GitHubIssuesTracker(IssueTracker):
    @property
    def name(self):
        return "GitHub Issues"

    def prompt_config(self):
        github_repo = click.prompt("Enter GitHub repo (e.g., user/repo)")
        github_token = click.prompt("Enter GitHub Personal Access Token (PAT)", hide_input=True)

        while not is_valid_github_token(github_repo, github_token):
            click.secho("\n❌ Invalid GitHub credentials or repo. Try again.", fg="red")
            github_repo = click.prompt("Enter GitHub repo (e.g., user/repo)")
            github_token = click.prompt("Enter GitHub PAT", hide_input=True)

        keyring.set_password("gitaid", "GITHUB_API_TOKEN", github_token)
        click.secho("\n✅ GitHub connection successful.\n", fg="cyan")

        return {
            "type": "github",
            "repo": github_repo,
        }
