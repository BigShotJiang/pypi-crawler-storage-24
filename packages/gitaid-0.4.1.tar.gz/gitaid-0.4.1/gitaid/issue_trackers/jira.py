from gitaid.issue_trackers.base import IssueTracker
import click
import keyring
from gitaid.utils.validators import is_valid_jira_token

class JiraTracker(IssueTracker):
    @property
    def name(self):
        return "Jira"

    def prompt_config(self):
        jira_url = click.prompt("Enter Jira URL (e.g., https://yourcompany.atlassian.net)")
        jira_email = click.prompt("Enter Jira email")
        jira_token = click.prompt("Enter Jira API key", hide_input=True)

        while not is_valid_jira_token(jira_url, jira_email, jira_token):
            click.secho("\n❌ Invalid Jira credentials. Try again.", fg="red")
            jira_url = click.prompt("Enter Jira URL")
            jira_email = click.prompt("Enter Jira email")
            jira_token = click.prompt("Enter Jira API key", hide_input=True)

        keyring.set_password("gitaid", "JIRA_API_TOKEN", jira_token)
        click.secho("✅ Jira connection successful.\n", fg="cyan")

        return {
            "type": "jira",
            "url": jira_url,
            "email": jira_email,
        }
