from abc import ABC, abstractmethod

class IssueTracker(ABC):
    @abstractmethod
    def prompt_config(self):
        """Prompt user for necessary credentials and return config dict"""
        pass

    @property
    @abstractmethod
    def name(self):
        """Return the name of the issue tracker"""
        pass
