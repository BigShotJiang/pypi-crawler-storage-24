import click
import importlib
import pkgutil
import shutil

from gitaid.logs import setup_logger
import gitaid.commands as commands


@click.group()
@click.option('--verbose', is_flag=True, help='Enable verbose debug logging')
def cli(verbose):
    """
    GitAid CLI entry point.
    Checks for dependencies before allowing subcommands to proceed.
    """
    # ✅ Initialize logging here
    setup_logger(verbose=verbose)

    # Check if Git is installed
    if shutil.which("git") is None:
        click.secho(
            "❌ Git is not installed or not found in PATH. Please install Git to use GitAid.",
            fg="red"
        )
        raise click.Abort()


def load_command_modules():
    """
    Discover all available command modules in the gitaid.commands package.

    Yields the module name (string) for each non-private, non-package Python
    module found in the gitaid.commands directory.
    """
    for _, module_name, is_pkg in pkgutil.iter_modules(commands.__path__):
        if not is_pkg and not module_name.startswith('_'):
            yield module_name


def create_command(module):
    """
    Wrap the given module's main() function as a Click command.

    Uses the module's docstring or the main() function's docstring as the
    help text for the command. Modules may define COMMAND_NAME to override
    the CLI name (e.g. history_tldr -> history-tldr).
    """
    helptext = getattr(module.main, '__doc__', '') or getattr(module, '__doc__', '') or ''
    modname = module.__name__.split('.')[-1]
    cmd_name = getattr(module, 'COMMAND_NAME', modname)

    if modname == "commit":
        @click.command(name=cmd_name, help=helptext)
        @click.option('--issue', '-i', required=False, help='Jira issue ID to include in context (e.g., GA-23)')
        @click.option('--split', is_flag=True, help='Split staged files into logical commit groups')
        def _cmd(issue, split):
            return module.main(issue=issue, split=split)

    elif modname == "audit":
        @click.command(name=cmd_name, help=helptext)
        @click.argument('commit_id', required=False, default=None, metavar='[COMMIT]')
        def _cmd(commit_id):
            return module.main(commit_id=commit_id)

    elif modname == "history_tldr":
        @click.command(name=cmd_name, help=helptext)
        @click.option('--last', '-n', default=10, show_default=True, help='Number of commits to summarize')
        def _cmd(last):
            return module.main(last=last)

    elif modname == "blame":
        @click.command(name=cmd_name, help=helptext)
        @click.argument('file', metavar='FILE')
        def _cmd(file):
            return module.main(file=file)

    elif modname == "why":
        @click.command(name=cmd_name, help=helptext)
        @click.argument('file', metavar='FILE')
        def _cmd(file):
            return module.main(file=file)

    else:
        @click.command(name=cmd_name, help=helptext)
        def _cmd():
            return module.main()

    return _cmd


# Dynamically register all commands
for modname in load_command_modules():
    module = importlib.import_module(f"gitaid.commands.{modname}")
    cmd = create_command(module)
    cmd_name = getattr(module, 'COMMAND_NAME', modname)
    cli.add_command(cmd, name=cmd_name)


if __name__ == "__main__":
    cli()