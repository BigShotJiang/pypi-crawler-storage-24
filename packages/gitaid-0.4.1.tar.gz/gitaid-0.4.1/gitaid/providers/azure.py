import click
from gitaid.utils.validators import is_valid_azure_key, is_valid_url
from gitaid.providers.base import LLMProvider

class AzureProvider(LLMProvider):
    @property
    def name(self):
        return "Azure OpenAI"

    def prompt_config(self):
        """
        Prompts user for Azure OpenAI configuration and validates API key.

        Returns:
            config dict, validated API key
        """
        base_root = click.prompt("Enter Azure endpoint (e.g., https://myresource.openai.azure.com)")
        while not is_valid_url(base_root):
            click.secho("❌ Invalid URL format.", fg="red")
            base_root = click.prompt("Enter Azure endpoint:")

        deployment = click.prompt("Enter deployment name")
        version = click.prompt("API version", default="2024-07-01-preview", show_default=False)
        api_key = click.prompt("Enter Azure API key", hide_input=True)

        full_url = f"{base_root}/openai/deployments/{deployment}"

        while not is_valid_azure_key(api_key, full_url, version, deployment):
            click.secho("❌ Invalid Azure API key or endpoint.", fg="red")
            api_key = click.prompt("Enter Azure API key", hide_input=True)

        return {
            "llm": {
                "provider": "azure",
                "base_url": full_url,
                "model": deployment,
                "api_version": version,
            }
        }, api_key
