# gitaid/providers/base.py

from abc import ABC, abstractmethod
from typing import Tuple, Union

class LLMProvider(ABC):
    @abstractmethod
    def prompt_config(self) -> Tuple[dict, Union[str, None]]:
        """Prompt for config and return (config_dict, api_key_or_none)."""
        pass

    @property
    @abstractmethod
    def name(self) -> str:
        """Return display name of provider (e.g., OpenAI, Azure)."""
        pass
