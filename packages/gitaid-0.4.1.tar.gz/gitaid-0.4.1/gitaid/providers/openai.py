import click
from gitaid.utils.validators import is_valid_openai_key
from gitaid.providers.base import LLMProvider

class OpenAIProvider(LLMProvider):
    @property
    def name(self):
        return "OpenAI"

    def prompt_config(self):
        """
        Prompts user for OpenAI configuration and validates API key.

        Returns:
            config dict, validated API key
        """
        model = click.prompt("Model name (Default: gpt-4o-mini)", default="gpt-4o-mini", show_default=False)
        api_key = click.prompt("Enter OpenAI API key", hide_input=True)

        while not is_valid_openai_key(api_key, "https://api.openai.com/v1"):
            click.secho("❌ Invalid OpenAI API key. Try again.", fg="red")
            api_key = click.prompt("Enter OpenAI API key", hide_input=True)

        return {
            "llm": {
                "provider": "openai",
                "base_url": "",
                "model": model,
                "api_version": None,
            }
        }, api_key
