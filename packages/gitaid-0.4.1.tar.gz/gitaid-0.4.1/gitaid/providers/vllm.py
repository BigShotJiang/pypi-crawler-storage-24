import click
from gitaid.utils.validators import is_valid_url
from gitaid.providers.base import LLMProvider

class VLLMProvider(LLMProvider):
    @property
    def name(self):
        return "vLLM"

    def prompt_config(self):
        """
        Prompts user for vLLM (custom or local inference server) configuration.

        Returns:
            config dict, validated API key or None
    """
        url = click.prompt("vLLM Base URL", default="http://localhost:8000/v1", show_default=False)
        while not is_valid_url(url):
            click.secho("❌ Invalid URL format.", fg="red")
            url = click.prompt("vLLM Base URL", default="http://localhost:8000/v1", show_default=False)

        model = click.prompt("Model name", default="Qwen/Qwen2.5-1.5B-Instruct", show_default=False)
        api_key = click.prompt("Enter API key (or leave blank if none)", hide_input=True, default="EMPTY")

        return {
            "llm": {
                "provider": "vllm",
                "base_url": url,
                "model": model,
            }
        }, api_key
 