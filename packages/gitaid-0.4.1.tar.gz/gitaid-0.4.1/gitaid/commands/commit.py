import sys
import click
from loguru import logger

from gitaid.core.split_commit_service import generate_and_split_commit_groups_and_commit
from gitaid.core.commit_service import generate_and_commit_message


def main(issue=None, split=False):
    """
    Generate an AI-powered commit message for your staged changes.

    Reads the staged diff, generates a suggested message, opens your editor
    for review, then runs a second LLM pass to catch issues before committing.

    Use --issue to pull Jira context into the message (e.g. --issue GA-31).
    Use --split to group staged changes into logical commits and commit each separately.
    """
    logger.info("🧠 Starting 'commit' command.")
    try:
        if split:
            generate_and_split_commit_groups_and_commit(issue_id=issue)
        else:
            generate_and_commit_message(issue_id=issue)
    except Exception as e:
        logger.exception(e)
        click.secho(f"❌ {str(e)}", fg="red")
        sys.exit(1)
        