import click
from loguru import logger

from gitaid.issue_trackers.jira import JiraTracker
from gitaid.issue_trackers.github import GitHubIssuesTracker
from gitaid.utils.config import save_config, get_config_path, load_config

ISSUE_TRACKERS = {
    '1': JiraTracker(),
    '2': GitHubIssuesTracker(),
}

def main():
    """
    Configure a Jira or GitHub Issues integration.

    Stores credentials securely in the OS keyring and saves tracker settings
    to ~/.gitaid.yml. Once configured, use --issue <KEY> with gitaid commit
    to pull issue context into your commit messages.
    """
    logger.info("Starting issue tracker setup")

    click.secho("🧩 Setting up Issue Tracker Integration\n", fg="bright_blue", bold=True)

    click.secho("Choose your issue tracker:\n", fg="green")
    for number, tracker in ISSUE_TRACKERS.items():
        click.secho(f"{number}. {tracker.name}", fg="bright_white")

    tracker_choice = click.prompt(
        click.style("\nEnter the number", fg="bright_white"),
        type=click.Choice(ISSUE_TRACKERS.keys())
    )
    tracker = ISSUE_TRACKERS[tracker_choice]

    issue_config = tracker.prompt_config()

    # Load existing config, if any
    config = load_config()
    config["issue_tracker"] = issue_config
    save_config(config)
    config_path = get_config_path()

    logger.info(f"Issue tracker configuration saved to {config_path}")
    click.secho(f"✅ Issue tracker configured and saved to {config_path}\n", fg="cyan")
