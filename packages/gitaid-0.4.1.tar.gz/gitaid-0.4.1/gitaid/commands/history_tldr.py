import sys
import click
from loguru import logger

from gitaid.core.history_tldr_service import generate_history_tldr

COMMAND_NAME = "history-tldr"


def main(last=10):
    """
    Summarize the last N commits as a human-readable changelog.

    Groups commits by theme (features, fixes, refactoring, etc.) and writes
    plain-English descriptions of what changed. If Jira issue keys appear in
    commit messages and Jira is configured, issue context is used to enrich
    the descriptions.

    Examples:
      gitaid history-tldr
      gitaid history-tldr --last 20
    """
    logger.info(f"Generating history tldr for last {last} commits.")

    try:
        result = generate_history_tldr(last)
        click.secho(f"\n  Changelog: last {last} commits\n", fg="bright_cyan", bold=True)
        click.echo(result)
        click.echo()
    except RuntimeError as e:
        click.secho(f"❌ {e}", fg="red")
        sys.exit(1)
    except Exception as e:
        logger.exception(e)
        click.secho("❌ Unexpected error generating changelog.", fg="red")
        sys.exit(1)
