import sys
import click
from loguru import logger

from gitaid.core.explain_service import generate_explain_message


def main():
    """
    Explain your staged changes in plain English.

    Reads the staged git diff and returns a clear, bullet-point summary
    of what changed - useful before a code review or pull request.
    """
    logger.info("🧠 Starting 'explain' command.")

    try:
        explanation = generate_explain_message()
        logger.info("Successfully received explanation from LLM.")

        print("\n🧠 Explanation of staged changes:\n")
        print(explanation)

    except click.Abort:
        logger.warning("LLM initialization aborted due to missing config or API key.")
        sys.exit(1)

    except Exception as e:
        logger.exception(e)
        click.secho("❌ Failed to generate explanation from LLM.", fg="red")
        sys.exit(1)
