import sys
import click
from loguru import logger

from gitaid.core.why_service import explain_file_history


def main(file=None):
    """
    Explain why a file changed across its entire commit history.

    Reads the full git history for the file (following renames) and produces
    a narrative explaining how the file evolved and what drove each major change.
    If Jira issue keys appear in commit messages and Jira is configured, issue
    context is woven into the narrative.

    Examples:
      gitaid why src/utils/git.py
    """
    if not file:
        click.secho("❌ Please provide a file path. Example: gitaid why src/utils/git.py", fg="red")
        sys.exit(1)

    logger.info(f"Explaining history of: {file}")

    try:
        result = explain_file_history(file)
        click.secho(f"\n  Why {file} exists and how it evolved\n", fg="bright_cyan", bold=True)
        click.echo(result)
        click.echo()
    except RuntimeError as e:
        click.secho(f"❌ {e}", fg="red")
        sys.exit(1)
    except Exception as e:
        logger.exception(e)
        click.secho("❌ Unexpected error explaining file history.", fg="red")
        sys.exit(1)
