import sys
import click
from loguru import logger

from gitaid.core.audit_service import audit_commit


def main(commit_id=None):
    """
    Audit a commit for quality, hygiene, and issue alignment.

    Checks message clarity, whether the diff matches the stated intent, commit
    size, and - if a Jira issue key is found in the message - whether the change
    actually matches the ticket. Defaults to HEAD if no commit ID is given.

    Examples:
      gitaid audit
      gitaid audit abc1234
    """
    target = commit_id or "HEAD"
    logger.info(f"Starting audit for: {target}")

    try:
        result = audit_commit(target)
        click.secho(f"\n  Audit report: {target}\n", fg="bright_cyan", bold=True)
        click.echo(result)
        click.echo()
    except RuntimeError as e:
        click.secho(f"❌ {e}", fg="red")
        sys.exit(1)
    except Exception as e:
        logger.exception(e)
        click.secho("❌ Unexpected error during audit.", fg="red")
        sys.exit(1)
