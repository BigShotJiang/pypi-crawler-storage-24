import click
import keyring
from loguru import logger

from gitaid.utils.config import save_config, get_config_path
from gitaid.providers.openai import OpenAIProvider
from gitaid.providers.azure import AzureProvider
from gitaid.providers.vllm import VLLMProvider
from gitaid.issue_trackers.jira import JiraTracker
from gitaid.issue_trackers.github import GitHubIssuesTracker


PROVIDERS = {}


def main():
    """
    Configure your LLM provider.

    Walks through selecting a provider (OpenAI, Azure OpenAI, or a vLLM-compatible
    server), validates credentials, stores the API key in the OS keyring, and
    writes provider and model settings to ~/.gitaid.yml.
    """
    logger.info("Starting GitAid setup process.")

    global PROVIDERS
    PROVIDERS = {
        '1': OpenAIProvider(),
        '2': AzureProvider(),
        '3': VLLMProvider(),
    }

    click.secho("=================================", fg="bright_blue")
    click.secho("🛠️  GITAID SETUP  🛠️", fg="bright_white", bold=True)
    click.secho("=================================\n", fg="bright_blue")
    click.secho("NOTE: Currently, GitAid supports only OpenAI-compatible APIs.\n", fg="yellow", bold=True)
    click.secho("GitAid requires a Large Language Model (LLM) to function. Let's set it up!\n",fg="bright_white", bold=True)
    click.secho("Choose your provider:\n",fg="green")

    try:
    
        for number, provider in PROVIDERS.items():
            click.secho(f"{number}. {provider.name}", fg="bright_white")

        # Ask for user input
        choice = click.prompt(click.style("\nEnter the number", fg="bright_white"), type=click.Choice(PROVIDERS.keys()))
        logger.debug(f"User selected provider option: {choice} ({PROVIDERS[choice].name})")

        # Call the correct provider based on the choice
        provider = PROVIDERS[choice]
        logger.info(f"Prompting configuration for provider: {provider.name}")
        config, api_key = provider.prompt_config()

        save_config(config)

        if api_key:
            keyring.set_password("gitaid", "API_KEY", api_key)
            click.secho(f"\n✅ {provider.name} connection successful and token stored securely.\n", fg="cyan")

        click.secho("⚙️  (Optional) Enable tab-completion\n", fg="yellow", bold=True)
        click.echo("""
        Zsh:
            eval "$(_GITAID_COMPLETE=zsh_source gitaid)"      # add to ~/.zshrc

        Bash:
            eval "$(_GITAID_COMPLETE=bash_source gitaid)"     # add to ~/.bashrc
        """)

        click.secho("\n🧩 To set up issue/ticket tracker integration (e.g., Jira or GitHub Issues), run:", fg="green")
        click.echo(f"    {click.style('gitaid issues', fg='bright_cyan', bold=True)}\n")

        click.echo("More info: https://pypi.org/project/gitaid/")
    
    except Exception as e:
        logger.exception(f"An error occurred during setup: {e}")
        click.secho("\n❌ Setup failed due to an unexpected error. See logs for details.", fg="red")
        raise click.Abort()

if __name__ == "__main__":
    main()
