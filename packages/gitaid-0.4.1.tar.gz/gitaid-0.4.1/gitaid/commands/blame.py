import sys
import click
from loguru import logger

from gitaid.core.blame_service import explain_blame


def main(file=None):
    """
    Show empathetic git blame with context for each section.

    Groups lines by commit and explains the intent behind each change in plain
    English. If Jira issue keys appear in commit messages and Jira is configured,
    issue context is used to enrich the explanations.

    Examples:
      gitaid blame src/utils/git.py
    """
    if not file:
        click.secho("❌ Please provide a file path. Example: gitaid blame src/utils/git.py", fg="red")
        sys.exit(1)

    logger.info(f"Running blame on: {file}")

    try:
        result = explain_blame(file)
        click.echo(result)
        click.echo()
    except RuntimeError as e:
        click.secho(f"❌ {e}", fg="red")
        sys.exit(1)
    except Exception as e:
        logger.exception(e)
        click.secho("❌ Unexpected error during blame.", fg="red")
        sys.exit(1)
