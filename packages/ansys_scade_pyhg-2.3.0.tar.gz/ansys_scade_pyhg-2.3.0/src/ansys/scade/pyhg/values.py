# Copyright (C) 2023 - 2026 ANSYS, Inc. and/or its affiliates.
# SPDX-License-Identifier: MIT
#
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons to whom the Software is
# furnished to do so, subject to the following conditions:
#
# The above copyright notice and this permission notice shall be included in all
# copies or substantial portions of the Software.
#
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
# IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
# AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
# SOFTWARE.

"""Parser for SCADE Test scenario values."""

from abc import ABC, abstractmethod
from keyword import iskeyword
import re
from typing import List, Tuple, Union

from pyparsing import (
    DelimitedList,
    Forward,
    Regex,
    Suppress,
    Word,
    alphanums,
    alphas,
)


class Value(ABC):
    """Abstraction for values."""

    @abstractmethod
    def flatten(self, suffix: str, literals: List[Tuple[str, str]]):
        """Flatten the value."""
        raise NotImplementedError


class Literal(Value):
    """A literal value."""

    def __init__(self, value) -> None:
        """Initialize the value."""
        if value in {'true', 't', 'TRUE', 'True', 'T'}:
            value = 'True'
        elif value in {'false', 'f', 'FALSE', 'False', 'F'}:
            value = 'False'
        elif value == 'NaN' or value == 'qNaN' or value == 'sNaN':
            value = 'math.nan'
        elif value == '+Inf':
            value = 'math.inf'
        elif value == '-Inf':
            value = '-math.inf'
        else:
            # the following regular expressions are not exact
            # but should be enough for this context
            value = re.sub(r'(.+)_u?i\d+', r'\1', value)
            value = re.sub(r'(.+)_f\d+', r'\1', value)
        self.value = value

    def flatten(self, suffix: str, literals: List[Tuple[str, str]]):
        """Flatten the value."""
        literals.append((suffix, self.value))


class ListLiterals(Value):
    """A list of values."""

    def __init__(self, values) -> None:
        """Initialize the values."""
        self.values = values

    def flatten(self, suffix: str, literals: List[Tuple[str, str]]):
        """Flatten the values."""
        for i, value in enumerate(self.values):
            value.flatten('%s[%d]' % (suffix, i), literals)


class StructFields(Value):
    """A structure of fields."""

    def __init__(self, fields) -> None:
        """Initialize the fields."""
        self.fields = {name: value for name, value in fields}

    def flatten(self, suffix: str, literals: List[Tuple[str, str]]):
        """Flatten the fields."""
        for name, value in self.fields.items():
            name = name + '_' if iskeyword(name) else name
            value.flatten('%s.%s' % (suffix, name), literals)


LBRACE, RBRACE, LPAR, RPAR, COLON, COMMA = map(Suppress, '{}():,')
ident = Word(alphas + '_', alphanums + '_').set_name('name')
literal = Regex(r'[^ \t\(\)\{\},:]+').set_parse_action(lambda t: Literal(t[0]))
value_defn = Forward()
field_defn = (ident('name') + COLON + value_defn('value')).set_parse_action(
    lambda t: (t['name'], t['value'])
)
struct_defn = (LBRACE + DelimitedList(field_defn, ',')('fields') + RBRACE).set_parse_action(
    lambda t: StructFields(t['fields'])
)
array_defn = (LPAR + DelimitedList(value_defn, ',')('values') + RPAR).set_parse_action(
    lambda t: ListLiterals(t['values'])
)
value_defn << (struct_defn | array_defn | literal)


def flatten(literal: Union[list, dict, str]):
    """Flatten the literal."""

    def parse(literal: Union[list, dict, str]) -> Value:
        """Parse the literal."""
        if isinstance(literal, list):
            return ListLiterals([parse(_) for _ in literal])
        elif isinstance(literal, dict):
            return StructFields([(name, parse(value)) for name, value in literal.items()])
        else:
            # assert isinstance(literal, str)
            result = value_defn.parse_string(literal)[0]
            assert isinstance(result, Value)  # nosec B101  # addresses linter
            return result

    literals = []
    tree = parse(literal)
    tree.flatten('', literals)

    return literals
