"""Memory reliability MVP package."""

__all__ = ["__version__"]

__version__ = "1.1.0"
