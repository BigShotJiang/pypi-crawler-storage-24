"""
Pipeline Motor — Orchestration engine with change detection, cascade deps, season tracking.

Ported from ppln_main_v511 architecture. Manages:
- Git hash-based skip/run decisions
- Cascade dependency graph
- Season folders (timestamped run directories)
- Meta tracking per step
- Manifest generation

Usage:
    from ews_scoreboard.motor import Motor

    m = Motor(work_dir=".", mode="prod")
    m.adim_isle("transform", nb_path, params, deps=["ingest_kik", "ingest_yis", ...])
    m.manifest_yaz()
"""

import hashlib
import json
import os
import shutil
import time
from collections import OrderedDict
from datetime import datetime
from pathlib import Path

from ews_scoreboard import __version__

# ── Dependency graph ──────────────────────────────────────────

BAGIMLILIK = {
    # Ingest (her kaynak DDL'e bağlı)
    "ingest_ddl": [],
    "ingest_kik": ["ingest_ddl"],
    "ingest_kredi": ["ingest_ddl"],
    "ingest_yis": ["ingest_ddl"],
    "ingest_eus": ["ingest_ddl"],
    "ingest_hedef_kapsam": ["ingest_ddl"],
    "ingest_statik": ["ingest_ddl"],
    "ingest_train": ["ingest_ddl"],
    "ingest_rkd": ["ingest_ddl"],
    "ingest_memzuc": ["ingest_ddl"],
    # Pipeline
    "transform": [
        "ingest_kik", "ingest_kredi", "ingest_yis", "ingest_eus",
        "ingest_hedef_kapsam", "ingest_statik", "ingest_train",
        "ingest_rkd", "ingest_memzuc",
    ],
    "ml_features": ["transform", "diag_features"],
    "ml_train": ["ml_features"],
    "ml_predict": ["ml_train", "marts"],
    "eus_diag": ["transform"],
    "diag_analysis": ["eus_diag"],
    "diag_features": ["eus_diag"],
    "marts": ["transform", "diag_analysis"],
    "export": ["marts"],
    # Backtest
    "backtest_eus": ["transform"],
    "backtest_yis": ["transform"],
    "backtest_ml": ["ml_train", "transform"],
}

# ── Notebook registry ─────────────────────────────────────────

ADIM_REGISTRY = OrderedDict([
    ("ingest_ddl",          {"nb": "nb_01a_ingest_ddl.ipynb",          "aciklama": "DB tablo oluşturma"}),
    ("ingest_kik",          {"nb": "nb_01b_ingest_kik.ipynb",          "aciklama": "KIK izleme CSV"}),
    ("ingest_kredi",        {"nb": "nb_01c_ingest_kredi.ipynb",        "aciklama": "Kredi risk parquet"}),
    ("ingest_yis",          {"nb": "nb_01d_ingest_yis.ipynb",          "aciklama": "YIS tahmin CSV"}),
    ("ingest_eus",          {"nb": "nb_01e_ingest_eus.ipynb",          "aciklama": "EUS tahmin CSV"}),
    ("ingest_hedef_kapsam", {"nb": "nb_01f_ingest_hedef_kapsam.ipynb", "aciklama": "EUS hedef+kapsam MUTA"}),
    ("ingest_statik",       {"nb": "nb_01g_ingest_statik.ipynb",       "aciklama": "Statik bilgiler TXT"}),
    ("ingest_train",        {"nb": "nb_01h_ingest_train.ipynb",        "aciklama": "Training features parquet"}),
    ("ingest_rkd",          {"nb": "nb_01i_ingest_rkd_memzuc.ipynb",   "aciklama": "RKD kriter + Memzuc parquet"}),
    ("ingest_memzuc",       {"nb": "nb_01i_ingest_rkd_memzuc.ipynb",   "aciklama": "RKD kriter + Memzuc parquet"}),
    ("transform",           {"nb": "nb_02_transform.ipynb",            "aciklama": "Bronze → Silver (EUS patch dahil)"}),
    ("eus_diag",            {"nb": "nb_06a_diag_extract.ipynb",        "aciklama": "EUS kapsam dışı kalma teşhisi (extract)"}),
    ("diag_analysis",       {"nb": "nb_06b_diag_analysis.ipynb",       "aciklama": "Diagnostik analiz & özet tablolar"}),
    ("diag_features",       {"nb": "nb_06c_diag_features.ipynb",       "aciklama": "Diagnostik ML feature engineering"}),
    ("ml_features",         {"nb": "nb_04a_ml_features.ipynb",          "aciklama": "ML feature engineering"}),
    ("ml_train",            {"nb": "nb_04b_ml_train.ipynb",             "aciklama": "ML LightGBM eğitimi"}),
    ("ml_predict",          {"nb": "nb_04c_ml_predict.ipynb",           "aciklama": "ML tahmin + SHAP"}),
    ("marts",               {"nb": "nb_03_marts.ipynb",                "aciklama": "Scoreboard + Trending + HTML"}),
    ("backtest_eus",        {"nb": "nb_05a_backtest_eus.ipynb",        "aciklama": "EUS skor backtest"}),
    ("backtest_yis",        {"nb": "nb_05b_backtest_yis.ipynb",        "aciklama": "YIS skor backtest"}),
    ("backtest_ml",         {"nb": "nb_05c_backtest_ml.ipynb",         "aciklama": "ML scoreboard backtest"}),
])

ALL_INGEST_STEPS = [k for k in ADIM_REGISTRY if k.startswith("ingest_")]


def _file_hash(path: str) -> str | None:
    """SHA256 hash of a file."""
    try:
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()[:16]
    except Exception:
        return None


def _git_hash(repo_dir: str, file_path: str) -> str | None:
    """Git object hash of a file (if git available)."""
    try:
        import subprocess
        result = subprocess.run(
            ["git", "hash-object", file_path],
            capture_output=True, text=True, cwd=repo_dir, timeout=5
        )
        if result.returncode == 0:
            return result.stdout.strip()[:16]
    except Exception:
        pass
    return None


def _git_info(repo_dir: str) -> dict:
    """Get git repo info."""
    import subprocess
    info = {"git_available": False}
    try:
        r = subprocess.run(["git", "rev-parse", "HEAD"], capture_output=True, text=True,
                           cwd=repo_dir, timeout=5)
        if r.returncode == 0:
            info["git_available"] = True
            info["git_commit"] = r.stdout.strip()
            info["git_commit_short"] = r.stdout.strip()[:8]
        r2 = subprocess.run(["git", "branch", "--show-current"], capture_output=True, text=True,
                            cwd=repo_dir, timeout=5)
        if r2.returncode == 0:
            info["git_branch"] = r2.stdout.strip() or "DETACHED"
    except Exception as e:
        info["git_error"] = str(e)
    return info


class Motor:
    """Pipeline orchestration engine."""

    def __init__(self, work_dir: str = ".", mode: str = "prod",
                 force_all: bool = False, force_adimlar: list = None,
                 from_step: str = None,
                 muta_filter_path: str = None, file_suffix: str = "",
                 data_paths: dict = None):
        import os
        os.environ["PYDEVD_DISABLE_FILE_VALIDATION"] = "1"

        self.work_dir = Path(work_dir).resolve()
        self.mode = mode
        self.force_all = force_all
        self.force_adimlar = set(force_adimlar or [])
        self.from_step = from_step
        self.muta_filter_path = muta_filter_path or ""
        self.file_suffix = file_suffix
        # data_paths: parametre > data_paths_nt.json > data_paths.json > {}
        if data_paths:
            self.data_paths = data_paths
        else:
            self.data_paths = self._load_data_paths()

        # Test mode → ayrı DB
        if mode == "test":
            self.db_path = self.work_dir / "db" / "ews_test.duckdb"
        else:
            self.db_path = self.work_dir / "db" / "ews.duckdb"
        self.output_dir = self.work_dir / "outputs" / "json"

        # Season setup — test mode: T_ prefix
        self.ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        prefix = "T" if mode == "test" else "S"
        self.season_adi = f"{prefix}_{self.ts}_{mode}_{__version__}"
        self.season_dir = self.work_dir / "seasons" / self.season_adi
        self.meta_dir = self.season_dir / "meta"
        self.log_dir = self.season_dir / "logs"

        for d in [self.meta_dir, self.log_dir, self.output_dir]:
            d.mkdir(parents=True, exist_ok=True)

        # Tracking
        self.calisan_adimlar = set()
        self.ozet_satirlar = []
        self.manifest_adimlar = OrderedDict()
        self.pipeline_baslangic = time.time()

        # Git info
        self.git_info = _git_info(str(self.work_dir))

        # Determine which steps to run based on from_step
        self._skip_before = set()
        if from_step:
            all_keys = list(ADIM_REGISTRY.keys())
            if from_step in all_keys:
                idx = all_keys.index(from_step)
                self._skip_before = set(all_keys[:idx])

    def _load_data_paths(self) -> dict:
        """Load data_paths JSON if present in work_dir."""
        import json as _json
        for name in ["local_data_paths.json", "data_paths_nt.json", "data_paths.json"]:
            p = self.work_dir / name
            if p.exists():
                with open(p, encoding="utf-8") as f:
                    paths = _json.load(f)
                print(f"  [CONFIG] {name} yüklendi ({len(paths)} kaynak)")
                for k, v in paths.items():
                    print(f"    {k}: {v}")
                return paths

        import sys
        print(f"\n  [!] local_data_paths.json bulunamadı: {self.work_dir}")
        print("  Kaynak veri dizinlerini belirten bir JSON dosyası gerekli.")
        print('  Örnek: {"kik_data_ham_csv": "/mnt/z/kik", "kredi_db": "/mnt/z/kredi", ...}')
        if not sys.stdin.isatty():
            print("  [AUTO] Non-interactive mod — external_data/ ile devam ediliyor")
            return {}
        cevap = input("\n  external_data/ ile devam edilsin mi? [e/H]: ").strip().lower()
        if cevap in ("e", "evet"):
            return {}
        raise SystemExit("Pipeline durduruldu — local_data_paths.json oluşturun.")

    def _find_prev_meta(self, kod: str) -> dict | None:
        """Find most recent meta for a step from previous seasons (same mode only)."""
        seasons_dir = self.work_dir / "seasons"
        if not seasons_dir.exists():
            return None
        # Mode prefix: T_ = test, S_ = prod — sadece aynı mode'a bak
        mode_prefix = "T_" if self.mode == "test" else "S_"
        for sdir in sorted(seasons_dir.iterdir(), reverse=True):
            if sdir == self.season_dir:
                continue
            if not sdir.name.startswith(mode_prefix):
                continue
            meta_path = sdir / "meta" / f"adim_{kod}.json"
            if meta_path.exists():
                try:
                    return json.loads(meta_path.read_text(encoding="utf-8"))
                except Exception:
                    pass
        return None

    def _nb_path(self, kod: str) -> Path | None:
        """Find notebook path (first in work_dir, then in package)."""
        info = ADIM_REGISTRY.get(kod)
        if not info:
            return None
        nb_name = info["nb"]
        # Check work_dir first (user may have modified)
        local = self.work_dir / nb_name
        if local.exists():
            return local
        # Fallback to package
        try:
            from ews_scoreboard.paths import get_notebooks_dir
            pkg = get_notebooks_dir() / nb_name
            if pkg.exists():
                return pkg
        except Exception:
            pass
        return None

    def meta_kontrol(self, kod: str) -> tuple[bool, str]:
        """Check if step needs to run. Returns (should_run, reason)."""
        prev = self._find_prev_meta(kod)
        if prev is None:
            return True, "ilk çalıştırma"

        # Mode changed?
        if prev.get("mode") != self.mode:
            return True, f"mode değişti ({prev.get('mode')}→{self.mode})"

        # Notebook hash changed?
        nb_path = self._nb_path(kod)
        if nb_path:
            current_hash = _file_hash(str(nb_path))
            prev_hash = prev.get("nb_hash")
            if current_hash and prev_hash and current_hash != prev_hash:
                return True, f"notebook değişti ({prev_hash[:8]}→{current_hash[:8]})"

        # Git hash (if available)
        if nb_path and self.git_info.get("git_available"):
            git_h = _git_hash(str(self.work_dir), str(nb_path))
            prev_git = prev.get("git_nb_hash")
            if git_h and prev_git and git_h != prev_git:
                return True, f"git hash değişti"

        # Source data changed? (for ingest steps)
        prev_sources = prev.get("source_hashes", {})
        if prev_sources:
            for src_path, old_hash in prev_sources.items():
                if Path(src_path).exists():
                    new_hash = _file_hash(src_path)
                    if new_hash and new_hash != old_hash:
                        return True, f"kaynak değişti ({Path(src_path).name})"

        return False, f"uyumlu ({prev.get('nb_hash', '?')[:8]})"

    def meta_yaz(self, kod: str, nb_path: Path, sure: float,
                 source_hashes: dict = None, ekstra: dict = None) -> dict:
        """Write step meta JSON."""
        meta = {
            "notebook": nb_path.name,
            "nb_hash": _file_hash(str(nb_path)),
            "git_nb_hash": _git_hash(str(self.work_dir), str(nb_path)) if self.git_info.get("git_available") else None,
            "pkg_version": __version__,
            "season": self.season_adi,
            "pipeline_ts": self.ts,
            "mode": self.mode,
            "sure_saniye": round(sure, 1),
            "tarih": datetime.now().isoformat(),
        }
        if source_hashes:
            meta["source_hashes"] = source_hashes
        if ekstra:
            meta.update(ekstra)

        fip = self.meta_dir / f"adim_{kod}.json"
        fip.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        return meta

    def adim_isle(self, kod: str, ek_params: dict = None,
                  kontrol_fn=None, source_dirs: list = None) -> bool:
        """Process a pipeline step: decide run/skip, execute, track.

        Args:
            kod: Step code (key in ADIM_REGISTRY).
            ek_params: Extra papermill parameters.
            kontrol_fn: Post-run verification function(work_dir).
            source_dirs: List of source data directories to hash (for ingest steps).

        Returns:
            True if step completed (ran or skipped OK), False if error.
        """
        info = ADIM_REGISTRY.get(kod)
        if not info:
            print(f"  [!] Bilinmeyen adım: {kod}")
            return False

        aciklama = info["aciklama"]
        nb_path = self._nb_path(kod)

        print(f"\n  ── {kod} | {aciklama} ──")

        if not nb_path:
            print(f"  [!] Notebook bulunamadı: {info['nb']}")
            self.ozet_satirlar.append({
                "adim": kod, "nb": info["nb"], "sure": "-",
                "durum": "NB YOK", "sebep": "bulunamadı"
            })
            self.manifest_adimlar[kod] = {"durum": "NB_YOK"}
            return False

        nb_hash = _file_hash(str(nb_path)) or "--"
        print(f"  {nb_path.name} ({nb_hash[:8]})")

        # Skip if before from_step
        if kod in self._skip_before:
            print(f"  ATLANDI — --from {self.from_step}")
            self.ozet_satirlar.append({
                "adim": kod, "nb": nb_path.name, "sure": "-",
                "durum": "ATLANDI", "sebep": f"--from {self.from_step}"
            })
            self.manifest_adimlar[kod] = {"durum": "ATLANDI", "sebep": f"--from {self.from_step}"}
            if kontrol_fn:
                kontrol_fn(self.work_dir)
            return True

        # Check if should run
        force = self.force_all or (kod in self.force_adimlar)
        calistir, sebep = self.meta_kontrol(kod)

        if force and not calistir:
            sebep = f"ZORLA ({sebep})"
            calistir = True

        # Cascade: upstream ran → we must run
        if not calistir:
            deps = BAGIMLILIK.get(kod, [])
            tetikleyenler = [d for d in deps if d in self.calisan_adimlar]
            if tetikleyenler:
                calistir = True
                sebep = f"cascade ({','.join(tetikleyenler)})"

        if not calistir:
            print(f"  ATLANDI — {sebep}")
            self.ozet_satirlar.append({
                "adim": kod, "nb": nb_path.name, "sure": "-",
                "durum": "ATLANDI", "sebep": sebep
            })
            self.manifest_adimlar[kod] = {
                "notebook": nb_path.name, "durum": "ATLANDI", "sebep": sebep
            }
            if kontrol_fn:
                kontrol_fn(self.work_dir)
            return True

        # Run
        print(f"  ÇALIŞTIRILIYOR — {sebep}")
        t0 = time.time()

        # Build params
        params = {
            "DB_PATH": str(self.db_path),
            "OUTPUT_DIR": str(self.output_dir),
            "WORK_DIR": str(self.work_dir),
        }
        # Test mode params
        if self.muta_filter_path:
            params["MUTA_FILTER_PATH"] = self.muta_filter_path
        if self.file_suffix:
            params["FILE_SUFFIX"] = self.file_suffix
        if ek_params:
            params.update(ek_params)

        out_nb = self.log_dir / f"adim_{kod}_{nb_path.name}"

        try:
            import papermill as pm
            pm.execute_notebook(
                str(nb_path), str(out_nb),
                parameters=params,
                cwd=str(self.work_dir),
            )
            sure = time.time() - t0
            sure_str = f"{sure:.0f}s" if sure < 60 else f"{sure / 60:.1f}dk"

            # Hash source dirs
            source_hashes = {}
            if source_dirs:
                for sd in source_dirs:
                    sd_path = Path(sd)
                    if sd_path.exists():
                        for f in sorted(sd_path.iterdir()):
                            if f.is_file():
                                h = _file_hash(str(f))
                                if h:
                                    source_hashes[str(f)] = h

            self.meta_yaz(kod, nb_path, sure, source_hashes=source_hashes)
            self.calisan_adimlar.add(kod)

            print(f"  OK {sure_str}")
            self.ozet_satirlar.append({
                "adim": kod, "nb": nb_path.name, "sure": sure_str,
                "durum": "OK", "sebep": sebep
            })
            self.manifest_adimlar[kod] = {
                "notebook": nb_path.name, "durum": "OK", "sure": sure_str
            }
            if kontrol_fn:
                kontrol_fn(self.work_dir)
            return True

        except Exception as e:
            sure = time.time() - t0
            sure_str = f"{sure:.0f}s" if sure < 60 else f"{sure / 60:.1f}dk"
            hata = str(e)[:300]
            print(f"  HATA — {sure_str}\n  {hata}")

            # Save error report
            try:
                from ews_scoreboard.sanitize import save_error_report
                report_path = self.season_dir / "error_report.txt"
                save_error_report(e, self.db_path, context=f"step={kod}", output_path=report_path)
                print(f"  Hata raporu: {report_path}")
            except Exception:
                pass

            self.ozet_satirlar.append({
                "adim": kod, "nb": nb_path.name, "sure": sure_str,
                "durum": "HATA", "sebep": hata[:80]
            })
            self.manifest_adimlar[kod] = {
                "notebook": nb_path.name, "durum": "HATA", "hata": hata
            }
            return False

    def ozet_yazdir(self):
        """Print pipeline summary."""
        toplam = time.time() - self.pipeline_baslangic
        ok = sum(1 for s in self.ozet_satirlar if s["durum"] == "OK")
        atla = sum(1 for s in self.ozet_satirlar if s["durum"] == "ATLANDI")
        hata = sum(1 for s in self.ozet_satirlar if s["durum"] == "HATA")

        print(f"\n{'=' * 80}")
        print(f"  {self.season_adi} | {self.mode.upper()}")
        print(f"{'=' * 80}")
        print(f"  {'Adım':<22} {'Notebook':<38} {'Süre':>6}  Durum")
        print(f"  {'-' * 22} {'-' * 38} {'-' * 6}  {'-' * 8}")
        for s in self.ozet_satirlar:
            ikon = {"OK": "OK", "ATLANDI": "SKIP", "HATA": "ERR", "NB YOK": "!!"}.get(s["durum"], "?")
            print(f"  {s['adim']:<22} {s['nb']:<38} {s['sure']:>6}  [{ikon}]")

        print(f"\n  Süre: {toplam / 60:.1f}dk | OK:{ok} Atlandı:{atla} Hata:{hata}")
        print(f"  Season: {self.season_dir}")

    def manifest_yaz(self) -> Path:
        """Write final manifest JSON."""
        toplam = time.time() - self.pipeline_baslangic
        ok = sum(1 for s in self.ozet_satirlar if s["durum"] == "OK")
        atla = sum(1 for s in self.ozet_satirlar if s["durum"] == "ATLANDI")
        hata = sum(1 for s in self.ozet_satirlar if s["durum"] == "HATA")

        manifest = {
            "season": self.season_adi,
            "pipeline_ts": self.ts,
            "pkg_version": __version__,
            "tarih": datetime.now().isoformat(),
            "mode": self.mode,
            "git": self.git_info,
            "parametreler": {
                "force_all": self.force_all,
                "force_adimlar": list(self.force_adimlar),
                "from_step": self.from_step,
            },
            "sonuc": {
                "toplam_sure_dk": round(toplam / 60, 1),
                "ok": ok, "atlandi": atla, "hata": hata,
            },
            "adimlar": dict(self.manifest_adimlar),
        }

        fip = self.meta_dir / f"manifest_{self.ts}.json"
        fip.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n  Manifest: {fip}")
        return fip

    def _temizle_error_reports(self):
        """Tüm eski error_report dosyalarını sil (seasons + outputs)."""
        silinen = 0
        # Seasons altındaki error_report'lar
        seasons_dir = self.work_dir / "seasons"
        if seasons_dir.exists():
            for er in seasons_dir.rglob("error_report.txt"):
                er.unlink()
                silinen += 1
        # outputs altındaki error_report (direct mode'dan kalmış olabilir)
        for loc in [self.work_dir / "outputs" / "json" / "error_report.txt",
                    self.work_dir / "outputs" / "error_report.txt"]:
            if loc.exists():
                loc.unlink()
                silinen += 1
        if silinen:
            print(f"  Temizlik: {silinen} eski error_report silindi")

    def run_all(self, skip_ingest: bool = False, skip_backtest: bool = False,
                skip_ml: bool = False, referans_tarih_list: list = None,
                test_muta_count: int = 0):
        """Run all steps respecting dependencies.

        Convenience method for running the full pipeline.

        Args:
            test_muta_count: >0 ise ML notebook'ları bu kadar firma ile test modunda çalışır.
        """
        print(f"EWS Scoreboard Pipeline v{__version__}")
        print(f"Season: {self.season_adi}")
        print(f"Mode: {self.mode}")
        if self.mode == "test":
            print(f"DB: {self.db_path}")
            if self.muta_filter_path:
                print(f"MUTA filtre: {self.muta_filter_path}")
        if self.git_info.get("git_available"):
            print(f"Git: {self.git_info.get('git_commit_short', '?')} ({self.git_info.get('git_branch', '?')})")
        print(f"Force: {self.force_all} {list(self.force_adimlar)}")

        src = self.work_dir / "external_data"
        dp = self.data_paths

        def _resolve(subdir):
            """data_paths override varsa onu kullan, yoksa external_data/subdir."""
            if subdir in dp:
                return str(dp[subdir])
            return str(src / subdir)

        # ── Ingest ──
        if not skip_ingest:
            self.adim_isle("ingest_ddl")
            self.adim_isle("ingest_kik",
                           source_dirs=[_resolve("kik_data_ham_csv")],
                           ek_params={"SOURCE_DIR": _resolve("kik_data_ham_csv")})
            self.adim_isle("ingest_kredi",
                           source_dirs=[_resolve("kredi_db")],
                           ek_params={"SOURCE_DIR": _resolve("kredi_db")})
            self.adim_isle("ingest_yis",
                           source_dirs=[_resolve("yis_tahmin_data")],
                           ek_params={"SOURCE_DIR": _resolve("yis_tahmin_data")})
            self.adim_isle("ingest_eus",
                           source_dirs=[_resolve("eus_tahmin_data")],
                           ek_params={"SOURCE_DIR": _resolve("eus_tahmin_data")})
            self.adim_isle("ingest_hedef_kapsam",
                           source_dirs=[_resolve("eus_hedef_muta"), _resolve("eus_sql_kapsam_muta")],
                           ek_params={"SOURCE_DIRS": _resolve("eus_hedef_muta") + "," + _resolve("eus_sql_kapsam_muta")})
            self.adim_isle("ingest_statik",
                           source_dirs=[_resolve("statik_db")],
                           ek_params={"SOURCE_DIR": _resolve("statik_db")})
            self.adim_isle("ingest_train",
                           source_dirs=[_resolve("yis_train_data")],
                           ek_params={"SOURCE_DIR": _resolve("yis_train_data")})
            self.adim_isle("ingest_rkd",
                           source_dirs=[_resolve("rkd_donem_data")],
                           ek_params={"SOURCE_DIRS": _resolve("rkd_donem_data")})
            self.adim_isle("ingest_memzuc",
                           source_dirs=[_resolve("memzuc_data_donem")],
                           ek_params={"SOURCE_DIRS": _resolve("memzuc_data_donem")})

        # ── Transform (EUS patch dahil — nb_02 içinden nb_02a çağrılır) ──
        transform_params = {"LOG_DIR": str(self.log_dir)}
        if referans_tarih_list:
            transform_params["REFERANS_TARIH_LIST"] = str(referans_tarih_list)
        self.adim_isle("transform", ek_params=transform_params)

        # ── Marts (scoreboard + trending + HTML — ML'den önce) ──
        self.adim_isle("marts")

        # ── ML (features → train → predict+SHAP) ──
        if not skip_ml:
            ml_common = {
                "CACHE_DIR": str(self.work_dir / "db" / "cache"),
                "TEST_MUTA_COUNT": test_muta_count,
            }
            # 04a: Feature engineering → cache/ml_features.parquet
            self.adim_isle("ml_features", ek_params={**ml_common})

            # 04b: Train → ml_models/yi_model.pkl
            self.adim_isle("ml_train", ek_params={
                **ml_common,
                "MODEL_DIR": str(self.work_dir / "ml_models"),
            })

            # 04c: Predict + SHAP → scoreboard enrichment
            sb_name = f"sample_scoreboard{self.file_suffix}.json"
            self.adim_isle("ml_predict", ek_params={
                **ml_common,
                "MODEL_DIR": str(self.work_dir / "ml_models"),
                "SCOREBOARD_PATH": str(self.output_dir / sb_name),
            })

        # ── Backtest ──
        if not skip_backtest:
            self.adim_isle("backtest_eus")
            self.adim_isle("backtest_yis")
            self.adim_isle("backtest_ml")

        # ── Cleanup: eski error_report'ları sil ──
        self._temizle_error_reports()

        # ── Summary ──
        self.ozet_yazdir()
        return self.manifest_yaz()
