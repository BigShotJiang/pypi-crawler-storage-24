"""EWS Scoreboard Pipeline."""
__version__ = "0.15.6"
