"""
Feature: zabbix-sync-gui, Property 11: Event ID uniqueness

Validates: Requirements 13.3
For any sequence of requests made through the HMACClient, all generated
X-Event-ID values SHALL be unique.
"""

import sys
from types import ModuleType

for mod_name in ("netbox", "netbox.plugins", "netbox.models"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]

from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services.hmac_client import HMACClient  # noqa: E402

# Strategy: number of sign calls to make (2-50)
call_counts = st.integers(min_value=2, max_value=50)
bodies = st.text(min_size=0, max_size=200)


@given(n=call_counts, body=bodies)
@settings(max_examples=100)
def test_event_ids_are_unique_across_calls(n, body):
    """Property 11: Event ID uniqueness.

    For any sequence of _sign_request calls, all X-Event-ID values must be unique.
    """
    client = HMACClient(base_url="http://localhost:9999", token="test-token")
    event_ids = [client._sign_request(body)["X-Event-ID"] for _ in range(n)]

    assert len(event_ids) == len(set(event_ids)), (
        f"Duplicate event IDs found in {n} calls: {[eid for eid in event_ids if event_ids.count(eid) > 1]}"
    )
