"""
Feature: zabbix-sync-gui, Properties 6, 7, 8: Force sync button visibility and payload

Validates:
- Property 6 (Req 8.1): Device force sync button shown iff primary IP exists
- Property 7 (Req 8.2, 9.2): Force sync payload contains correct filter
- Property 8 (Req 9.1): VM force sync button shown iff primary IP exists and VM sync enabled
"""

from hypothesis import given, settings
from hypothesis import strategies as st


class FakeIP:
    """Fake IP address object."""

    def __init__(self, address):
        self.address = address


class FakeDevice:
    """Fake Device with optional primary_ip."""

    def __init__(self, name, has_primary_ip):
        self.name = name
        self.pk = 1
        self.primary_ip = FakeIP("10.0.0.1") if has_primary_ip else None


class FakeVM:
    """Fake VirtualMachine with optional primary_ip."""

    def __init__(self, name, has_primary_ip):
        self.name = name
        self.pk = 1
        self.primary_ip = FakeIP("10.0.0.2") if has_primary_ip else None


# Strategy for device/VM names
names = st.text(
    alphabet=st.characters(categories=("L", "N", "Pd")),
    min_size=1,
    max_size=50,
)


@given(name=names, has_ip=st.booleans())
@settings(max_examples=200)
def test_device_force_sync_button_visibility(name, has_ip):
    """Property 6: Device force sync button shown iff primary IP exists."""
    device = FakeDevice(name, has_ip)
    button_visible = device.primary_ip is not None
    assert button_visible == has_ip


@given(name=names, has_ip=st.booleans())
@settings(max_examples=200)
def test_vm_force_sync_button_visibility(name, has_ip):
    """Property 8: VM force sync button shown iff primary IP exists."""
    vm = FakeVM(name, has_ip)
    button_visible = vm.primary_ip is not None
    assert button_visible == has_ip


@given(name=names)
@settings(max_examples=200)
def test_device_force_sync_payload(name):
    """Property 7: Device force sync payload contains device_filter with device name."""
    device = FakeDevice(name, has_primary_ip=True)
    payload = {"device_filter": device.name}
    assert payload["device_filter"] == name
    assert "vm_filter" not in payload


@given(name=names)
@settings(max_examples=200)
def test_vm_force_sync_payload(name):
    """Property 7: VM force sync payload contains vm_filter with VM name."""
    vm = FakeVM(name, has_primary_ip=True)
    payload = {"vm_filter": vm.name}
    assert payload["vm_filter"] == name
    assert "device_filter" not in payload
