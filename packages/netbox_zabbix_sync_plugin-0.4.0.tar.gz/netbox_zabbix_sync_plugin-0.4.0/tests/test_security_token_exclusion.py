"""
Security regression tests: token field must never be exposed via API or GraphQL.

These tests guard against accidental re-introduction of the HMAC token
in the REST API serializer or GraphQL schema. They parse source files
with AST to avoid needing a full Django app registry.
"""

import ast
from pathlib import Path

_plugin_root = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin"


def _extract_meta_fields(source: str, class_name: str) -> list[str] | None:
    """Extract the 'fields' tuple/list from a serializer Meta class via AST.

    Returns the list of field name strings, or None if not found.
    """
    tree = ast.parse(source)
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef) and node.name == class_name:
            for inner in node.body:
                if isinstance(inner, ast.ClassDef) and inner.name == "Meta":
                    for stmt in inner.body:
                        if (
                            isinstance(stmt, ast.Assign)
                            and len(stmt.targets) == 1
                            and isinstance(stmt.targets[0], ast.Name)
                            and stmt.targets[0].id == "fields"
                        ):
                            if isinstance(stmt.value, (ast.Tuple, ast.List)):
                                return [
                                    elt.value
                                    for elt in stmt.value.elts
                                    if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
                                ]
    return None


# ---------------------------------------------------------------------------
# Serializer tests
# ---------------------------------------------------------------------------

_serializer_source = (_plugin_root / "api" / "serializers" / "synchronization_runner.py").read_text()

_serializer_fields = _extract_meta_fields(_serializer_source, "SynchronizationRunnerSerializer")


def test_serializer_fields_exclude_token():
    """The REST API serializer must NOT include 'token' in its fields.

    Regression guard: token was previously listed in Meta.fields, which
    would expose the HMAC secret in every API response.
    """
    assert _serializer_fields is not None, "Could not parse serializer Meta.fields"
    assert "token" not in _serializer_fields, (
        "SECURITY: 'token' must not appear in SynchronizationRunnerSerializer.Meta.fields"
    )


def test_serializer_exposes_webserver_url():
    """The model's 'url' field should be exposed as 'webserver_url'.

    The DRF HyperlinkedIdentityField already uses the name 'url' for the
    API endpoint link. The model's url (webserver URL) must be aliased to
    avoid collision and data loss.
    """
    assert _serializer_fields is not None, "Could not parse serializer Meta.fields"
    assert "webserver_url" in _serializer_fields, (
        "Model's url field should be exposed as 'webserver_url' in serializer fields"
    )


def test_serializer_no_duplicate_url():
    """The serializer fields tuple must not contain 'url' more than once.

    Regression guard: a previous version had 'url' listed twice (once for
    the HyperlinkedIdentityField, once for the model field), which caused
    the model field to be silently shadowed.
    """
    assert _serializer_fields is not None, "Could not parse serializer Meta.fields"
    assert _serializer_fields.count("url") == 1, (
        f"'url' appears {_serializer_fields.count('url')} times in serializer fields — expected exactly 1"
    )


# ---------------------------------------------------------------------------
# GraphQL tests
# ---------------------------------------------------------------------------

_graphql_source = (_plugin_root / "graphql.py").read_text()


def test_graphql_does_not_use_fields_all():
    """The GraphQL type must NOT use fields='__all__'.

    Regression guard: a previous version used fields='__all__' which
    exposed every model field including the HMAC token.
    """
    assert 'fields="__all__"' not in _graphql_source, "SECURITY: graphql.py must not use fields='__all__'"
    assert "fields='__all__'" not in _graphql_source, "SECURITY: graphql.py must not use fields='__all__'"


def test_graphql_fields_exclude_token():
    """The GraphQL type's explicit fields list must NOT contain 'token'."""
    tree = ast.parse(_graphql_source)
    for node in ast.walk(tree):
        if isinstance(node, ast.keyword) and node.arg == "fields":
            if isinstance(node.value, ast.List):
                field_names = [
                    elt.value for elt in node.value.elts if isinstance(elt, ast.Constant) and isinstance(elt.value, str)
                ]
                assert "token" not in field_names, "SECURITY: 'token' must not appear in GraphQL type fields list"
