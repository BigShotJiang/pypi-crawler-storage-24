"""
Feature: zabbix-sync-gui, Property 12: Auth error messages reference HMAC token

Validates: Requirements 15.2
For any webserver response with HTTP status 401 or 403, the error message
displayed to the user SHALL contain a reference to verifying the HMAC token.
"""

import sys
from types import ModuleType
from unittest.mock import MagicMock, patch

for mod_name in ("netbox", "netbox.plugins", "netbox.models"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]

from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services import WebserverError  # noqa: E402
from netbox_zabbix_sync_plugin.services.hmac_client import HMACClient  # noqa: E402

# Strategy: 401 or 403 status codes
auth_statuses = st.sampled_from([401, 403])
response_bodies = st.text(min_size=0, max_size=300)


@given(status_code=auth_statuses, body=response_bodies)
@settings(max_examples=100)
def test_auth_error_message_references_hmac_token(status_code, body):
    """Property 12: Auth error messages reference HMAC token.

    For any 401/403 response, the error message must mention "HMAC token".
    """
    client = HMACClient(base_url="http://localhost:9999", token="test-token")

    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.ok = False
    mock_response.text = body
    mock_response.json.side_effect = ValueError("not json")

    with patch("requests.request", return_value=mock_response):
        try:
            client.get("/test")
            raise AssertionError(f"Expected WebserverError for HTTP {status_code}")
        except WebserverError as exc:
            assert "HMAC token" in exc.message, f"Auth error message does not reference HMAC token: {exc.message!r}"
            assert exc.status_code == status_code


@given(status_code=auth_statuses, body=response_bodies)
@settings(max_examples=100)
def test_auth_error_message_references_hmac_token_json_response(status_code, body):
    """Property 12 (JSON variant): Same check when response is valid JSON."""
    client = HMACClient(base_url="http://localhost:9999", token="test-token")

    mock_response = MagicMock()
    mock_response.status_code = status_code
    mock_response.ok = False
    mock_response.text = body
    mock_response.json.return_value = {"detail": "unauthorized"}

    with patch("requests.request", return_value=mock_response):
        try:
            client.get("/test")
            raise AssertionError(f"Expected WebserverError for HTTP {status_code}")
        except WebserverError as exc:
            assert "HMAC token" in exc.message
            assert exc.status_code == status_code
