"""
Feature: builtin-sync-backend, Property 7: Mode switching preserves local config records

Validates: Requirements 14.4

For any runner that has associated ConnectConfig and SyncConfig records,
changing the runner's mode field from local to remote (or vice versa) and
saving SHALL NOT delete or modify the ConnectConfig or SyncConfig records.
The records SHALL remain accessible and unchanged after the mode switch.
"""

import os
import sys
from types import ModuleType

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model files can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so SyncConfig import doesn't fail
for mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = {}  # type: ignore[attr-defined]

# Now import the models under test
from unittest.mock import patch  # noqa: E402

from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.models.connect_config import ConnectConfig  # noqa: E402
from netbox_zabbix_sync_plugin.models.sync_config import SyncConfig  # noqa: E402
from netbox_zabbix_sync_plugin.models.synchronization_runner import (  # noqa: E402
    RunnerMode,
    SynchronizationRunner,
)


@given(
    mode_sequence=st.lists(st.sampled_from(["local", "remote"]), min_size=2, max_size=5),
    netbox_url=st.text(min_size=1, max_size=50),
    netbox_token=st.text(min_size=1, max_size=50),
    zabbix_url=st.text(min_size=1, max_size=50),
    zabbix_user=st.text(min_size=1, max_size=50),
    zabbix_password=st.text(min_size=1, max_size=50),
    zabbix_token=st.text(min_size=1, max_size=50),
    sync_config_data=st.dictionaries(
        keys=st.text(min_size=1, max_size=20),
        values=st.text(max_size=50),
        min_size=1,
        max_size=5,
    ),
)
@settings(max_examples=20)
def test_mode_switching_preserves_local_config_records(
    mode_sequence,
    netbox_url,
    netbox_token,
    zabbix_url,
    zabbix_user,
    zabbix_password,
    zabbix_token,
    sync_config_data,
):
    """Property 7: Mode switching preserves local config records.

    **Validates: Requirements 14.4**

    Create a runner with associated ConnectConfig and SyncConfig, switch
    modes back and forth through a random sequence, and verify that the
    config records remain unchanged after every switch.
    """
    # Create a runner starting in local mode
    runner = SynchronizationRunner(
        name="test-runner",
        mode=RunnerMode.LOCAL,
        url="",
        token="",
    )

    # Create associated config objects (without saving to DB — test in-memory)
    connect_config = ConnectConfig(
        runner=runner,
        netbox_url=netbox_url,
        netbox_token=netbox_token,
        zabbix_url=zabbix_url,
        zabbix_user=zabbix_user,
        zabbix_password=zabbix_password,
        zabbix_token=zabbix_token,
    )

    sync_config = SyncConfig(
        runner=runner,
        config=dict(sync_config_data),
    )

    # Snapshot the original config values
    original_connect = {
        "netbox_url": connect_config.netbox_url,
        "netbox_token": connect_config.netbox_token,
        "zabbix_url": connect_config.zabbix_url,
        "zabbix_user": connect_config.zabbix_user,
        "zabbix_password": connect_config.zabbix_password,
        "zabbix_token": connect_config.zabbix_token,
    }
    original_sync = dict(sync_config.config)

    # Switch modes through the random sequence, mocking save() to avoid DB
    with patch.object(SynchronizationRunner, "save", return_value=None):
        for mode in mode_sequence:
            runner.mode = mode
            # When switching to remote, set url/token to satisfy validation
            if mode == RunnerMode.REMOTE:
                runner.url = "http://example.com"
                runner.token = "some-token"
            else:
                runner.url = ""
                runner.token = ""
            runner.save()

    # Assert ConnectConfig fields are unchanged
    assert connect_config.netbox_url == original_connect["netbox_url"]
    assert connect_config.netbox_token == original_connect["netbox_token"]
    assert connect_config.zabbix_url == original_connect["zabbix_url"]
    assert connect_config.zabbix_user == original_connect["zabbix_user"]
    assert connect_config.zabbix_password == original_connect["zabbix_password"]
    assert connect_config.zabbix_token == original_connect["zabbix_token"]

    # Assert SyncConfig data is unchanged
    assert sync_config.config == original_sync
