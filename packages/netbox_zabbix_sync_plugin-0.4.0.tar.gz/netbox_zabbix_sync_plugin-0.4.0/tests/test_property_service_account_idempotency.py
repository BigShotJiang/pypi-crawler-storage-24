"""
Feature: builtin-sync-backend, Property 5: Service account creation idempotency

Validates: Requirements 7.4

For any number of sequential calls to ensure_service_account(password), there
SHALL be exactly one Django user named "netbox-zabbix-sync", and the returned
token SHALL be a valid, usable API token. Calling ensure_service_account twice
SHALL NOT create duplicate users.
"""

import os
import sys
from types import ModuleType
from unittest.mock import MagicMock, patch

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model file can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so imports don't fail
for mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = {}  # type: ignore[attr-defined]

# Stub users.models so the Token import in service_account.py resolves
if "users" not in sys.modules:
    sys.modules["users"] = ModuleType("users")
if "users.models" not in sys.modules:
    _users_models = ModuleType("users.models")
    _users_models.Token = MagicMock(name="TokenStub")  # type: ignore[attr-defined]
    sys.modules["users.models"] = _users_models
if "users.models.permissions" not in sys.modules:
    _users_perms = ModuleType("users.models.permissions")
    _users_perms.ObjectPermission = MagicMock(name="ObjectPermissionStub")  # type: ignore[attr-defined]
    sys.modules["users.models.permissions"] = _users_perms

# Now import the actual modules under test
from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services.service_account import (  # noqa: E402
    SERVICE_ACCOUNT_USERNAME,
    ensure_service_account,
)


@given(
    n_calls=st.integers(min_value=1, max_value=5),
    password=st.text(min_size=1, max_size=50),
)
@settings(max_examples=100)
def test_service_account_creation_is_idempotent(n_calls, password):
    """Property 5: Service account creation idempotency.

    **Validates: Requirements 7.4**

    Calling ensure_service_account N times SHALL result in exactly one
    Django user named "netbox-zabbix-sync". get_or_create is called N
    times but only creates once. Each call returns a valid v2 token.
    """
    # --- Set up mocks that simulate Django ORM behaviour ---
    mock_user = MagicMock(name="ServiceAccountUser")
    mock_user.username = SERVICE_ACCOUNT_USERNAME
    mock_user.pk = 42

    # Track how many times get_or_create is called and simulate idempotency:
    # first call creates (created=True), subsequent calls reuse (created=False).
    get_or_create_call_count = 0

    def _get_or_create(**kwargs):
        nonlocal get_or_create_call_count
        get_or_create_call_count += 1
        created = get_or_create_call_count == 1
        return (mock_user, created)

    mock_user_model = MagicMock(name="UserModel")
    mock_user_model.objects.get_or_create.side_effect = _get_or_create

    # Mock ObjectPermission — get_or_create returns a mock perm each time
    mock_obj_perm = MagicMock(name="ObjectPermission")
    mock_obj_perm.actions = ["view"]
    mock_obj_perm_cls = MagicMock(name="ObjectPermissionClass")
    mock_obj_perm_cls.objects.get_or_create.return_value = (mock_obj_perm, True)

    # Mock ContentType.objects.get
    mock_ct = MagicMock(name="ContentType")
    mock_ct_cls = MagicMock(name="ContentTypeClass")
    mock_ct_cls.objects.get.return_value = mock_ct

    # Mock Token: each call creates a new v2 token object
    token_counter = 0

    def _make_token(**kwargs):
        nonlocal token_counter
        token_counter += 1
        t = MagicMock(name=f"Token_{token_counter}")
        t.token = f"tok-{token_counter}"
        t.v2 = True
        t.version = 2
        t.key = f"key{token_counter:08d}"
        return t

    mock_token_cls = MagicMock(name="TokenClass")
    mock_token_cls.side_effect = _make_token
    mock_token_cls.objects = MagicMock()

    # Reset counters for this test run
    get_or_create_call_count = 0
    token_counter = 0

    with (
        patch(
            "netbox_zabbix_sync_plugin.services.service_account.get_user_model",
            return_value=mock_user_model,
        ),
        patch(
            "netbox_zabbix_sync_plugin.services.service_account.ObjectPermission",
            mock_obj_perm_cls,
        ),
        patch(
            "netbox_zabbix_sync_plugin.services.service_account.ContentType",
            mock_ct_cls,
        ),
        patch(
            "netbox_zabbix_sync_plugin.services.service_account.Token",
            mock_token_cls,
        ),
    ):
        results = []
        for _ in range(n_calls):
            user, token_plaintext = ensure_service_account(password)
            results.append((user, token_plaintext))

    # --- Assertions ---

    # get_or_create was called exactly N times
    assert get_or_create_call_count == n_calls, (
        f"Expected get_or_create to be called {n_calls} times, got {get_or_create_call_count}"
    )

    # Every call returned the SAME user object (idempotent — one user)
    for i, (user, _) in enumerate(results):
        assert user is mock_user, (
            f"Call {i + 1} returned a different user object; expected the same user for all {n_calls} calls"
        )

    # Every call returned a non-empty token string in v2 format
    for i, (_, tok) in enumerate(results):
        assert isinstance(tok, str) and tok.startswith("nbt_"), f"Call {i + 1} returned invalid v2 token: {tok!r}"

    # set_password was called N times (once per invocation)
    assert mock_user.set_password.call_count == n_calls
    # save was called N times
    assert mock_user.save.call_count == n_calls

    # ObjectPermission.objects.get_or_create was called 2x per invocation
    # (once for read perms, once for write perms)
    assert mock_obj_perm_cls.objects.get_or_create.call_count == 2 * n_calls
