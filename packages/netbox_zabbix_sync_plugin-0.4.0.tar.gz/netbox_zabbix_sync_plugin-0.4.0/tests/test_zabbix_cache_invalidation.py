"""
Tests for Zabbix client cache invalidation behavior.

Verifies that _invalidate_cache() correctly handles token-based vs
user/password sessions — token sessions must NOT call logout() because
that would revoke the API token on the Zabbix server.
"""

import sys
import time
from types import ModuleType
from unittest.mock import MagicMock

# Stub out NetBox model imports (zabbix_client imports them lazily inside
# _get_zabbix_api, but the package chain needs netbox stubs to load).
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = type("JobsMixin", (), {})  # type: ignore[attr-defined]

import importlib  # noqa: E402

from netbox_zabbix_sync_plugin.services import zabbix_client as zc  # noqa: E402

# Force a clean load — other test modules may have triggered a partial import
# of zabbix_client via zabbix_tab.py's collection-time import.
zc = importlib.reload(zc)


def _reset_cache():
    """Reset module-level cache state between tests."""
    zc._cached_zapi = None
    zc._cached_at = 0.0


def test_invalidate_cache_calls_logout_for_userpass_session():
    """User/password sessions should call logout() on invalidation."""
    _reset_cache()

    mock_zapi = MagicMock()
    mock_zapi._ZabbixAPI__use_token = False

    zc._cached_zapi = mock_zapi
    zc._cached_at = 1000.0

    zc._invalidate_cache()

    mock_zapi.logout.assert_called_once()
    assert zc._cached_zapi is None
    assert zc._cached_at == 0.0


def test_invalidate_cache_skips_logout_for_token_session():
    """Token-based sessions must NOT call logout() — it would revoke the token.

    Regression guard: a previous version always called logout(), which
    would destroy the API token on the Zabbix server for token-based auth.
    """
    _reset_cache()

    mock_zapi = MagicMock()
    mock_zapi._ZabbixAPI__use_token = True

    zc._cached_zapi = mock_zapi
    zc._cached_at = 1000.0

    zc._invalidate_cache()

    mock_zapi.logout.assert_not_called()
    assert zc._cached_zapi is None
    assert zc._cached_at == 0.0


def test_invalidate_cache_handles_none_gracefully():
    """Invalidating when no session is cached should not raise."""
    _reset_cache()
    zc._invalidate_cache()
    assert zc._cached_zapi is None
    assert zc._cached_at == 0.0


def test_invalidate_cache_handles_logout_exception():
    """If logout() raises, the cache should still be cleared."""
    _reset_cache()

    mock_zapi = MagicMock()
    mock_zapi._ZabbixAPI__use_token = False
    mock_zapi.logout.side_effect = Exception("connection lost")

    zc._cached_zapi = mock_zapi
    zc._cached_at = 1000.0

    zc._invalidate_cache()

    assert zc._cached_zapi is None
    assert zc._cached_at == 0.0


def test_cache_ttl_expiry():
    """After TTL expires, _is_cache_valid() should return False."""
    _reset_cache()

    zc._cached_zapi = MagicMock()
    zc._cached_at = 0.0

    assert not zc._is_cache_valid()


def test_cache_valid_within_ttl():
    """Within TTL, _is_cache_valid() should return True."""
    _reset_cache()

    zc._cached_zapi = MagicMock()
    zc._cached_at = time.time()

    assert zc._is_cache_valid()
