"""
Feature: zabbix-sync-gui, Property 5: Zabbix tab visibility matches HostID presence

Validates: Requirements 6.1, 6.4, 7.1, 7.3
For any Device or VirtualMachine, the Zabbix tab is displayed if and only if
the object has a populated Zabbix HostID custom field value.
"""

import importlib.util
import sys
from pathlib import Path
from types import ModuleType

from hypothesis import given, settings
from hypothesis import strategies as st

# Stub out Django/NetBox imports so we can load _get_zabbix_hostid
_stub_modules = (
    "dcim",
    "dcim.models",
    "django",
    "django.shortcuts",
    "django.urls",
    "netbox",
    "netbox.plugins",
    "netbox.views",
    "netbox.views.generic",
    "utilities",
    "utilities.views",
    "virtualization",
    "virtualization.models",
)
for mod_name in _stub_modules:
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

# Provide stubs for the specific imports used by zabbix_tab.py
sys.modules["django.urls"].reverse = lambda *a, **kw: "/stub/"  # type: ignore[attr-defined]
sys.modules["django.shortcuts"].get_object_or_404 = lambda *a, **kw: None  # type: ignore[attr-defined]
sys.modules["django.shortcuts"].render = lambda *a, **kw: None  # type: ignore[attr-defined]


class _FakeManager:
    def all(self):
        return self


sys.modules["dcim.models"].Device = type("Device", (), {"objects": _FakeManager()})  # type: ignore[attr-defined]
sys.modules["virtualization.models"].VirtualMachine = type("VirtualMachine", (), {"objects": _FakeManager()})  # type: ignore[attr-defined]
sys.modules["netbox.views.generic"].ObjectView = type("ObjectView", (), {})  # type: ignore[attr-defined]
sys.modules["utilities.views"].ViewTab = lambda **kw: None  # type: ignore[attr-defined]
sys.modules["utilities.views"].register_model_view = lambda *a, **kw: (lambda cls: cls)  # type: ignore[attr-defined]

# Set up the plugin package hierarchy so relative imports work
_plugin_root = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin"

# Create parent package stubs
_pkg = ModuleType("netbox_zabbix_sync_plugin")
_pkg.__path__ = [str(_plugin_root)]  # type: ignore[attr-defined]
sys.modules["netbox_zabbix_sync_plugin"] = _pkg

_views_pkg = ModuleType("netbox_zabbix_sync_plugin.views")
_views_pkg.__path__ = [str(_plugin_root / "views")]  # type: ignore[attr-defined]
sys.modules["netbox_zabbix_sync_plugin.views"] = _views_pkg

# Stub the services package and zabbix_client module
_svc_pkg = ModuleType("netbox_zabbix_sync_plugin.services")
_svc_pkg.__path__ = [str(_plugin_root / "services")]  # type: ignore[attr-defined]
sys.modules["netbox_zabbix_sync_plugin.services"] = _svc_pkg

_zbx_client = ModuleType("netbox_zabbix_sync_plugin.services.zabbix_client")
_zbx_client.get_host_maintenance = lambda *a, **kw: {}  # type: ignore[attr-defined]
_zbx_client.get_host_problems = lambda *a, **kw: {}  # type: ignore[attr-defined]
sys.modules["netbox_zabbix_sync_plugin.services.zabbix_client"] = _zbx_client

# Stub the models package
_models_pkg = ModuleType("netbox_zabbix_sync_plugin.models")
_models_pkg.__path__ = [str(_plugin_root / "models")]  # type: ignore[attr-defined]
sys.modules["netbox_zabbix_sync_plugin.models"] = _models_pkg

# Now load the zabbix_tab module with proper package context
_tc_path = _plugin_root / "views" / "zabbix_tab.py"
_spec = importlib.util.spec_from_file_location(
    "netbox_zabbix_sync_plugin.views.zabbix_tab",
    _tc_path,
    submodule_search_locations=[],
)
assert _spec is not None and _spec.loader is not None
_mod = importlib.util.module_from_spec(_spec)
_mod.__package__ = "netbox_zabbix_sync_plugin.views"
sys.modules["netbox_zabbix_sync_plugin.views.zabbix_tab"] = _mod
_spec.loader.exec_module(_mod)

_get_zabbix_hostid = _mod._get_zabbix_hostid

# Strategy: generate objects with or without zabbix_hostid
hostid_values = st.one_of(
    st.none(),
    st.just(0),
    st.just(""),
    st.integers(min_value=1, max_value=999999),
)


class FakeObj:
    """Fake Device/VM with a cf dict."""

    def __init__(self, hostid):
        self.cf = {"zabbix_hostid": hostid} if hostid is not None else {}


@given(hostid=hostid_values)
@settings(max_examples=200)
def test_zabbix_tab_visibility_matches_hostid_presence(hostid):
    """Property 5: Tab is displayed iff zabbix_hostid is populated (truthy)."""
    obj = FakeObj(hostid)
    result = _get_zabbix_hostid(obj)

    if hostid and hostid != 0 and hostid != "":
        # HostID is populated and truthy — tab should show
        assert result, f"Expected truthy hostid for {hostid!r}, got {result!r}"
    else:
        # HostID is missing, None, 0, or empty — tab should not show
        assert not result, f"Expected falsy hostid for {hostid!r}, got {result!r}"
