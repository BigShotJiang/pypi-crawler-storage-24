"""
Feature: zabbix-sync-gui, Property 3: Connect config PATCH sends only changed fields

Validates: Requirements 4.3
For any original connect config and any edited connect config, the PATCH
payload SHALL contain exactly the fields whose values differ between the
original and edited versions, and no others.
"""

import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType

# Minimal Django settings for forms
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = []  # type: ignore[attr-defined]
    settings_mod.DATABASES = {}  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

import django  # noqa: E402

django.setup()

# Load connect_config form directly from file
_form_path = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin" / "forms" / "connect_config.py"
_spec = importlib.util.spec_from_file_location("connect_config_form", _form_path)
assert _spec is not None and _spec.loader is not None
_form_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_form_mod)

ConnectConfigEditForm = _form_mod.ConnectConfigEditForm

from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

# Strategy for URL-like strings
urls = st.sampled_from(
    [
        "http://localhost:8000",
        "http://netbox.local",
        "https://netbox.example.com",
        "http://192.168.1.100:8080",
    ]
)

# Strategy for token/credential strings
creds = st.text(
    alphabet=st.characters(categories=("L", "N")),
    min_size=8,
    max_size=40,
)


# Strategy for a connect config dict (userpass auth)
userpass_configs = st.fixed_dictionaries(
    {
        "netbox_url": urls,
        "netbox_token": creds,
        "zabbix_url": urls,
        "zabbix_user": creds,
        "zabbix_password": creds,
        "zabbix_token": st.just(""),
    }
)


@given(original=userpass_configs, edited=userpass_configs)
@settings(max_examples=200)
def test_patch_payload_contains_only_changed_fields(original, edited):
    """Property 3: PATCH sends only changed fields.

    Secret fields (netbox_token, zabbix_password) are always sent when their
    edit checkbox is on (no comparison — the view never shows the original).
    Non-secret fields (URLs, username) are compared against original.
    """
    # Build form data with all edit checkboxes ON so secrets are included
    form_data = {
        "netbox_url": edited["netbox_url"],
        "edit_netbox_token": "on",
        "netbox_token": edited["netbox_token"],
        "zabbix_url": edited["zabbix_url"],
        "zabbix_auth_type": "userpass",
        "zabbix_user": edited["zabbix_user"],
        "edit_zabbix_password": "on",
        "zabbix_password": edited["zabbix_password"],
        "zabbix_token": "",
    }

    form = ConnectConfigEditForm(data=form_data)
    assert form.is_valid(), f"Form should be valid: {form.errors}"

    payload = form.get_patch_payload(original)

    # Non-secret fields: must only appear when changed
    non_secret_fields = ["netbox_url", "zabbix_url", "zabbix_user"]
    for field in non_secret_fields:
        if field in payload:
            assert edited[field] != original.get(field, ""), (
                f"Field {field!r} in payload but values are the same: {edited[field]!r}"
            )
        if edited[field] != original.get(field, ""):
            assert field in payload, f"Field {field!r} changed but not in payload"

    # Secret fields: always present when edit checkbox is on and value non-empty
    if edited["netbox_token"]:
        assert "netbox_token" in payload, "netbox_token should be in payload when edit checkbox is on"
    if edited["zabbix_password"]:
        assert "zabbix_password" in payload, "zabbix_password should be in payload when edit checkbox is on"


@given(original=userpass_configs, edited=userpass_configs)
@settings(max_examples=200)
def test_secret_fields_excluded_when_edit_unchecked(original, edited):
    """Secret fields must NOT appear in payload when edit checkbox is off."""
    form_data = {
        "netbox_url": edited["netbox_url"],
        # edit_netbox_token NOT set — secret should be excluded
        "netbox_token": edited["netbox_token"],
        "zabbix_url": edited["zabbix_url"],
        "zabbix_auth_type": "userpass",
        "zabbix_user": edited["zabbix_user"],
        # edit_zabbix_password NOT set — secret should be excluded
        "zabbix_password": edited["zabbix_password"],
        "zabbix_token": "",
    }

    form = ConnectConfigEditForm(data=form_data)
    assert form.is_valid(), f"Form should be valid: {form.errors}"

    payload = form.get_patch_payload(original)

    assert "netbox_token" not in payload, "netbox_token should not be in payload without edit checkbox"
    assert "zabbix_password" not in payload, "zabbix_password should not be in payload without edit checkbox"


@given(original=userpass_configs)
@settings(max_examples=100)
def test_patch_payload_empty_when_no_changes(original):
    """When edited values match original and edit checkboxes are off, payload must be empty."""
    form_data = {
        "netbox_url": original["netbox_url"],
        # edit checkboxes OFF — secrets excluded
        "netbox_token": "",
        "zabbix_url": original["zabbix_url"],
        "zabbix_auth_type": "userpass",
        "zabbix_user": original["zabbix_user"],
        "zabbix_password": "",
        "zabbix_token": "",
    }

    form = ConnectConfigEditForm(data=form_data)
    assert form.is_valid(), f"Form should be valid: {form.errors}"

    payload = form.get_patch_payload(original)

    # Non-secret fields unchanged, secret edit checkboxes off → empty payload
    comparable_fields = ["netbox_url", "zabbix_url", "zabbix_user"]
    for field in comparable_fields:
        assert field not in payload, f"Field {field!r} should not be in payload when unchanged"
    # Secrets should never appear without edit checkbox
    for field in ["netbox_token", "zabbix_password"]:
        assert field not in payload, f"Secret {field!r} should not be in payload without edit checkbox"
