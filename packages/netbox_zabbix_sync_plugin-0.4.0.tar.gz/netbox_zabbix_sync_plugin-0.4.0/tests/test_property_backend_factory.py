"""
Feature: builtin-sync-backend, Property 4: Backend factory returns correct type for mode

Validates: Requirements 5.1, 5.2

For any runner, get_backend(runner) SHALL return a RemoteBackend instance when
runner.mode == "remote" and a LocalBackend instance when runner.mode == "local"
(assuming the sync library is installed). The returned backend SHALL satisfy the
SyncBackend protocol (i.e., have all required methods).
"""

import os
import sys
from types import ModuleType
from unittest.mock import MagicMock

# ---------------------------------------------------------------------------
# Minimal Django bootstrap — stub out netbox modules so the model file can be
# imported without a full NetBox installation.
# ---------------------------------------------------------------------------
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = [  # type: ignore[attr-defined]
        "django.contrib.contenttypes",
        "django.contrib.auth",
    ]
    settings_mod.DATABASES = {  # type: ignore[attr-defined]
        "default": {
            "ENGINE": "django.db.backends.sqlite3",
            "NAME": ":memory:",
        }
    }
    settings_mod.DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

# Stub netbox modules before Django setup
for mod_name in ("netbox", "netbox.plugins", "netbox.models", "netbox.models.features"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

from django.db import models as django_models  # noqa: E402


class _StubNetBoxModel(django_models.Model):
    class Meta:
        abstract = True


class _StubJobsMixin:
    pass


sys.modules["netbox.models"].NetBoxModel = _StubNetBoxModel  # type: ignore[attr-defined]
sys.modules["netbox.models.features"].JobsMixin = _StubJobsMixin  # type: ignore[attr-defined]

# Stub netbox_zabbix_sync so LocalBackend import path works
for mod_name in (
    "netbox_zabbix_sync",
    "netbox_zabbix_sync.modules",
    "netbox_zabbix_sync.modules.settings",
):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox_zabbix_sync.modules.settings"].DEFAULT_CONFIG = {}  # type: ignore[attr-defined]

# Now import the actual modules under test
from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

from netbox_zabbix_sync_plugin.services.backend_factory import get_backend  # noqa: E402
from netbox_zabbix_sync_plugin.services.local_backend import LocalBackend  # noqa: E402
from netbox_zabbix_sync_plugin.services.remote_backend import RemoteBackend  # noqa: E402

# The 7 methods required by the SyncBackend protocol
SYNC_BACKEND_METHODS = [
    "get_connect_config",
    "patch_connect_config",
    "get_sync_config",
    "patch_sync_config",
    "delete_sync_config_key",
    "trigger_sync",
    "health_check",
]


def _make_runner(mode: str, url: str = "http://example.com", token: str = "tok") -> MagicMock:
    """Create a mock SynchronizationRunner with the given mode."""
    runner = MagicMock()
    runner.mode = mode
    runner.url = url
    runner.token = token
    return runner


@given(
    mode=st.sampled_from(["local", "remote"]),
    url=st.from_regex(r"https?://[a-z]{1,10}\.[a-z]{2,4}", fullmatch=True),
    token=st.text(min_size=1, max_size=50),
)
@settings(max_examples=200)
def test_backend_factory_returns_correct_type_for_mode(mode, url, token):
    """Property 4: Backend factory returns correct type for mode.

    **Validates: Requirements 5.1, 5.2**

    For any runner, get_backend returns RemoteBackend when mode is remote
    and LocalBackend when mode is local. The returned backend has all
    SyncBackend protocol methods.
    """
    runner = _make_runner(mode=mode, url=url, token=token)
    backend = get_backend(runner)

    if mode == "local":
        assert isinstance(backend, LocalBackend), (
            f"Expected LocalBackend for mode='local', got {type(backend).__name__}"
        )
    else:
        assert isinstance(backend, RemoteBackend), (
            f"Expected RemoteBackend for mode='remote', got {type(backend).__name__}"
        )

    # Every backend must expose all SyncBackend protocol methods
    for method_name in SYNC_BACKEND_METHODS:
        assert hasattr(backend, method_name), (
            f"Backend {type(backend).__name__} missing protocol method '{method_name}'"
        )
        assert callable(getattr(backend, method_name)), (
            f"Backend {type(backend).__name__}.{method_name} is not callable"
        )
