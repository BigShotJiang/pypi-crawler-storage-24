"""Unit test package for netbox_zabbix_sync_plugin."""
