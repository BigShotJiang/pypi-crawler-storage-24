"""
Feature: zabbix-sync-gui, Property 1: Sync config defaults are pre-populated

Validates: Requirements 3.2
For any sync config key defined by the netbox-zabbix-sync project, the setup
wizard step 3 form SHALL pre-populate that field with the correct default value.
"""

import importlib.util
import os
import sys
from pathlib import Path
from types import ModuleType

# Minimal Django settings for forms
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "tests._minimal_settings")

if "tests._minimal_settings" not in sys.modules:
    settings_mod = ModuleType("tests._minimal_settings")
    settings_mod.DEBUG = True  # type: ignore[attr-defined]
    settings_mod.USE_I18N = False  # type: ignore[attr-defined]
    settings_mod.INSTALLED_APPS = []  # type: ignore[attr-defined]
    settings_mod.DATABASES = {}  # type: ignore[attr-defined]
    sys.modules["tests._minimal_settings"] = settings_mod

for mod_name in ("netbox", "netbox.plugins", "netbox.models"):
    if mod_name not in sys.modules:
        sys.modules[mod_name] = ModuleType(mod_name)

sys.modules["netbox.plugins"].PluginConfig = type("PluginConfig", (), {})  # type: ignore[attr-defined]
sys.modules["netbox.models"].NetBoxModel = type("NetBoxModel", (), {})  # type: ignore[attr-defined]

import django  # noqa: E402

django.setup()

# Load setup_wizard.py directly from file to bypass forms/__init__.py
# which imports model-dependent forms that need the full Django app registry.
_wizard_path = Path(__file__).resolve().parent.parent / "netbox_zabbix_sync_plugin" / "forms" / "setup_wizard.py"
_spec = importlib.util.spec_from_file_location("setup_wizard", _wizard_path)
assert _spec is not None and _spec.loader is not None
_wizard_mod = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(_wizard_mod)

SYNC_CONFIG_DEFAULTS = _wizard_mod.SYNC_CONFIG_DEFAULTS
SetupWizardStep3Form = _wizard_mod.SetupWizardStep3Form

from hypothesis import given, settings  # noqa: E402
from hypothesis import strategies as st  # noqa: E402

# All form field names that correspond to sync config keys
# Exclude dict/list defaults — those are JSON fields populated in __init__, not via field.initial
FORM_FIELD_KEYS = [
    k
    for k in SYNC_CONFIG_DEFAULTS
    if k in SetupWizardStep3Form.base_fields and not isinstance(SYNC_CONFIG_DEFAULTS[k], (dict, list))
]

key_subsets = st.lists(st.sampled_from(FORM_FIELD_KEYS), min_size=1, max_size=len(FORM_FIELD_KEYS), unique=True)


@given(keys=key_subsets)
@settings(max_examples=100)
def test_sync_config_defaults_are_prepopulated(keys):
    """Property 1: Sync config defaults are pre-populated.

    For any subset of sync config keys that have corresponding form fields,
    the form's initial value must match the defined default.
    """
    form = SetupWizardStep3Form()
    for key in keys:
        field = form.fields[key]
        expected = SYNC_CONFIG_DEFAULTS[key]
        actual = field.initial
        assert actual == expected, f"Field {key!r}: expected default {expected!r}, got {actual!r}"
