"""
Filtersets for SynchronizationRunner model.

For more information on NetBox filtersets, see:
https://docs.netbox.dev/en/stable/plugins/development/filtersets/

For django-filters documentation, see:
https://django-filter.readthedocs.io/
"""

import django_filters
from netbox.filtersets import NetBoxModelFilterSet

from ..models import SynchronizationRunner


class SynchronizationRunnerFilterSet(NetBoxModelFilterSet):
    """Filterset for SynchronizationRunner model."""

    name = django_filters.CharFilter(field_name="name", lookup_expr="icontains", label="Name")
    description = django_filters.CharFilter(field_name="description", lookup_expr="icontains", label="Description")
    url = django_filters.CharFilter(field_name="url", lookup_expr="icontains", label="URL")

    class Meta:
        model = SynchronizationRunner
        fields = (
            "id",
            "name",
            "description",
            "url",
        )

    def search(self, queryset, name, value):
        """Override search to search across multiple fields."""
        return queryset.filter(name__icontains=value) | queryset.filter(description__icontains=value)
