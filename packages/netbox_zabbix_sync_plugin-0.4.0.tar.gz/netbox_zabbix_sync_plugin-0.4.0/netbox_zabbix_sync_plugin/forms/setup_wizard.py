"""
Forms for the Setup Wizard.

Three-step wizard for initial webserver configuration:
- Step 1: Mode selection + credentials (local: service account password, remote: URL + HMAC token)
- Step 2: Connect config (NetBox/Zabbix credentials)
- Step 3: Sync config (advanced sync settings)
"""

from django import forms

try:
    from ..validators import validate_url_with_hostname
except ImportError:
    from netbox_zabbix_sync_plugin.validators import validate_url_with_hostname

try:
    from ..models.synchronization_runner import RunnerMode
except ImportError:
    # Fallback for standalone module loading (e.g. in tests that use importlib)
    RunnerMode = None  # type: ignore[assignment, misc]


def _get_runner_mode_choices():
    """Return RunnerMode choices, with a fallback when the model isn't available."""
    if RunnerMode is not None:
        return RunnerMode.choices
    return [("local", "Local"), ("remote", "Remote")]


def _get_runner_mode_default():
    """Return the default RunnerMode value."""
    if RunnerMode is not None:
        return RunnerMode.LOCAL
    return "local"


DEPLOYMENT_TYPE_CHOICES = [
    ("docker", "Docker (port 8080)"),
    ("http", "Plain HTTP (port 80)"),
    ("https", "HTTPS (port 443)"),
    ("custom", "Custom port"),
]

DEPLOYMENT_PORT_MAP = {
    "docker": 8080,
    "http": 80,
    "https": 443,
}


class SetupWizardStep1Form(forms.Form):
    """Step 1: Mode selection, webserver URL/HMAC token (remote) or service account password (local)."""

    mode = forms.ChoiceField(
        label="Runner Mode",
        choices=_get_runner_mode_choices(),
        initial=_get_runner_mode_default(),
        widget=forms.RadioSelect,
        help_text="Local: sync runs inside NetBox. Remote: sync runs on an external webserver.",
    )
    deployment_type = forms.ChoiceField(
        label="NetBox Deployment",
        choices=DEPLOYMENT_TYPE_CHOICES,
        initial="docker",
        widget=forms.RadioSelect,
        required=False,
        help_text="Determines the port used for the auto-detected NetBox URL.",
    )
    custom_port = forms.IntegerField(
        label="Custom Port",
        required=False,
        min_value=1,
        max_value=65535,
        help_text="Enter the port number NetBox is accessible on.",
    )
    url = forms.URLField(
        label="Webserver URL",
        required=False,
        help_text="The URL of the netbox-zabbix-sync webserver (e.g., http://localhost:8007)",
        assume_scheme="http",
    )
    token = forms.CharField(
        label="HMAC Token",
        required=False,
        widget=forms.PasswordInput(render_value=True),
        help_text="The shared HMAC-SHA256 secret for authenticating requests",
    )
    service_account_password = forms.CharField(
        label="Service Account Password",
        required=False,
        widget=forms.PasswordInput(render_value=True),
        help_text="Password for the auto-created 'netbox-zabbix-sync' NetBox service account",
    )

    def clean(self):
        cleaned = super().clean()
        mode = cleaned.get("mode")
        remote_value = RunnerMode.REMOTE if RunnerMode is not None else "remote"
        local_value = RunnerMode.LOCAL if RunnerMode is not None else "local"
        if mode == remote_value:
            if not cleaned.get("url"):
                self.add_error("url", "URL is required for remote mode.")
            if not cleaned.get("token"):
                self.add_error("token", "HMAC token is required for remote mode.")
        elif mode == local_value:
            if not cleaned.get("service_account_password"):
                self.add_error("service_account_password", "Service account password is required for local mode.")
            if cleaned.get("deployment_type") == "custom" and not cleaned.get("custom_port"):
                self.add_error("custom_port", "Port is required for custom deployment type.")
        return cleaned

    def get_netbox_port(self) -> int:
        """Return the port number based on the deployment type selection."""
        deployment_type = self.cleaned_data.get("deployment_type", "docker")
        if deployment_type == "custom":
            return self.cleaned_data.get("custom_port") or 8080
        return DEPLOYMENT_PORT_MAP.get(deployment_type, 8080)

    def get_netbox_scheme(self) -> str:
        """Return http or https based on the deployment type."""
        return "https" if self.cleaned_data.get("deployment_type") == "https" else "http"


class _RelaxedURLField(forms.CharField):
    """CharField that validates URLs but allows bare hostnames (e.g. http://netbox:8080)."""

    def __init__(self, **kwargs):
        kwargs.setdefault("max_length", 200)
        super().__init__(**kwargs)
        self.validators.append(validate_url_with_hostname)


class SetupWizardStep2Form(forms.Form):
    """Step 2: Connect config — NetBox and Zabbix credentials."""

    AUTH_TYPE_CHOICES = [
        ("userpass", "Username / Password"),
        ("token", "API Token"),
    ]

    netbox_url = _RelaxedURLField(
        label="NetBox URL",
        help_text="The URL of this NetBox instance as seen by the webserver",
    )
    netbox_token = forms.CharField(
        label="NetBox API Token",
        widget=forms.PasswordInput(render_value=True),
        help_text="API token for the webserver to access NetBox",
    )
    zabbix_url = _RelaxedURLField(
        label="Zabbix URL",
        help_text="The URL of the Zabbix server",
    )
    zabbix_auth_type = forms.ChoiceField(
        label="Zabbix Authentication",
        choices=AUTH_TYPE_CHOICES,
        initial="userpass",
        widget=forms.RadioSelect,
        help_text="Choose how the webserver authenticates with Zabbix",
    )
    zabbix_user = forms.CharField(
        label="Zabbix Username",
        required=False,
    )
    zabbix_password = forms.CharField(
        label="Zabbix Password",
        required=False,
        widget=forms.PasswordInput(render_value=True),
    )
    zabbix_token = forms.CharField(
        label="Zabbix API Token",
        required=False,
        widget=forms.PasswordInput(render_value=True),
    )

    def clean(self):
        cleaned = super().clean()
        auth_type = cleaned.get("zabbix_auth_type")
        if auth_type == "userpass":
            if not cleaned.get("zabbix_user"):
                self.add_error("zabbix_user", "Username is required for username/password authentication.")
            if not cleaned.get("zabbix_password"):
                self.add_error("zabbix_password", "Password is required for username/password authentication.")
        elif auth_type == "token":
            if not cleaned.get("zabbix_token"):
                self.add_error("zabbix_token", "API token is required for token authentication.")
        return cleaned

    def get_connect_config_payload(self) -> dict:
        """Build the payload for POST /connect_config from cleaned data."""
        data = self.cleaned_data
        payload = {
            "netbox_url": data["netbox_url"],
            "netbox_token": data["netbox_token"],
            "zabbix_url": data["zabbix_url"],
        }
        if data["zabbix_auth_type"] == "userpass":
            payload["zabbix_user"] = data["zabbix_user"]
            payload["zabbix_password"] = data["zabbix_password"]
        else:
            payload["zabbix_token"] = data["zabbix_token"]
        return payload


# Hardcoded fallback defaults — used when the netbox-zabbix-sync library is not
# installed (e.g. remote-only deployments).
_FALLBACK_SYNC_CONFIG_DEFAULTS = {
    # General
    "templates_config_context": False,
    "templates_config_context_overrule": False,
    "template_cf": "zabbix_template",
    "device_cf": "zabbix_hostid",
    "proxy_cf": False,
    "proxy_group_cf": False,
    "description": "static",
    "description_dt_format": "%Y-%m-%d %H:%M:%S",
    "clustering": False,
    "create_hostgroups": True,
    "create_journal": False,
    # Hostgroups
    "hostgroup_format": "site/manufacturer/role",
    "traverse_regions": False,
    "traverse_site_groups": False,
    "extended_site_properties": False,
    # Inventory
    "inventory_mode": "disabled",
    "inventory_sync": False,
    "device_inventory_map": {
        "asset_tag": "asset_tag",
        "virtual_chassis/name": "chassis",
        "status/label": "deployment_status",
        "location/name": "location",
        "latitude": "location_lat",
        "longitude": "location_lon",
        "comments": "notes",
        "name": "name",
        "rack/name": "site_rack",
        "serial": "serialno_a",
        "device_type/model": "type",
        "device_type/manufacturer/name": "vendor",
        "oob_ip/address": "oob_ip",
    },
    "vm_inventory_map": {
        "status/label": "deployment_status",
        "comments": "notes",
        "name": "name",
    },
    # Usermacros
    "usermacro_sync": "false",
    "device_usermacro_map": {
        "serial": "{$HW_SERIAL}",
        "role/name": "{$DEV_ROLE}",
        "url": "{$NB_URL}",
        "id": "{$NB_ID}",
    },
    "vm_usermacro_map": {
        "memory": "{$TOTAL_MEMORY}",
        "role/name": "{$DEV_ROLE}",
        "url": "{$NB_URL}",
        "id": "{$NB_ID}",
    },
    # Tags
    "tag_sync": False,
    "tag_lower": True,
    "tag_name": "NetBox",
    "tag_value": "name",
    "device_tag_map": {
        "site/name": "site",
        "rack/name": "rack",
        "platform/name": "target",
    },
    "vm_tag_map": {
        "site/name": "site",
        "cluster/name": "cluster",
        "platform/name": "target",
    },
    # VM Settings
    "sync_vms": False,
    "vm_hostgroup_format": "cluster_type/cluster/role",
    # Device Filtering / Lifecycle
    "full_proxy_sync": False,
    "zabbix_device_removal": ["Decommissioning", "Inventory"],
    "zabbix_device_disable": ["Offline", "Planned", "Staged", "Failed"],
    "nb_device_filter": {"name__n": "null"},
    "nb_vm_filter": {"name__n": "null"},
}

# Source defaults from the netbox-zabbix-sync library when available,
# falling back to the hardcoded dict above otherwise.
try:
    from netbox_zabbix_sync.modules.settings import DEFAULT_CONFIG

    # Guard against empty stubs (e.g. in test environments)
    SYNC_CONFIG_DEFAULTS = DEFAULT_CONFIG if DEFAULT_CONFIG else _FALLBACK_SYNC_CONFIG_DEFAULTS
except ImportError:
    SYNC_CONFIG_DEFAULTS = _FALLBACK_SYNC_CONFIG_DEFAULTS

# Categorization of sync config keys
SYNC_CONFIG_CATEGORIES = {
    "General": [
        "templates_config_context",
        "templates_config_context_overrule",
        "template_cf",
        "device_cf",
        "proxy_cf",
        "proxy_group_cf",
        "description",
        "description_dt_format",
        "clustering",
        "create_hostgroups",
        "create_journal",
    ],
    "Hostgroups": [
        "hostgroup_format",
        "traverse_regions",
        "traverse_site_groups",
        "extended_site_properties",
    ],
    "Inventory": [
        "inventory_mode",
        "inventory_sync",
        "device_inventory_map",
        "vm_inventory_map",
    ],
    "Usermacros": [
        "usermacro_sync",
        "device_usermacro_map",
        "vm_usermacro_map",
    ],
    "Tags": [
        "tag_sync",
        "tag_lower",
        "tag_name",
        "tag_value",
        "device_tag_map",
        "vm_tag_map",
    ],
    "VM Settings": [
        "sync_vms",
        "vm_hostgroup_format",
    ],
    "Device Lifecycle": [
        "zabbix_device_removal",
        "zabbix_device_disable",
    ],
    "Device Filtering": [
        "full_proxy_sync",
        "nb_device_filter",
        "nb_vm_filter",
    ],
}

DESCRIPTION_CHOICES = [
    ("static", "Static"),
    ("dynamic", "Dynamic"),
    ("custom", "Custom"),
]

INVENTORY_MODE_CHOICES = [
    ("disabled", "Disabled"),
    ("manual", "Manual"),
    ("automatic", "Automatic"),
]

USERMACRO_SYNC_CHOICES = [
    ("false", "Disabled"),
    ("true", "Enabled"),
    ("full", "Full"),
]


class SetupWizardStep3Form(forms.Form):
    """Step 3: Sync configuration — categorized fields with defaults."""

    # --- General ---
    templates_config_context = forms.BooleanField(
        label="Templates from Config Context",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["templates_config_context"],
    )
    templates_config_context_overrule = forms.BooleanField(
        label="Config Context Overrules Template CF",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["templates_config_context_overrule"],
    )
    template_cf = forms.CharField(
        label="Template Custom Field",
        initial=SYNC_CONFIG_DEFAULTS["template_cf"],
    )
    device_cf = forms.CharField(
        label="Device Custom Field",
        initial=SYNC_CONFIG_DEFAULTS["device_cf"],
    )
    proxy_cf = forms.CharField(
        label="Proxy Custom Field",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["proxy_cf"],
        help_text="Custom field name for Zabbix proxy assignment (leave empty to disable)",
    )
    proxy_group_cf = forms.CharField(
        label="Proxy Group Custom Field",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["proxy_group_cf"],
        help_text="Custom field name for Zabbix proxy group assignment (leave empty to disable)",
    )
    description = forms.ChoiceField(
        label="Description Mode",
        choices=DESCRIPTION_CHOICES,
        initial=SYNC_CONFIG_DEFAULTS["description"],
    )
    description_dt_format = forms.CharField(
        label="Description Date Format",
        initial=SYNC_CONFIG_DEFAULTS["description_dt_format"],
    )
    clustering = forms.BooleanField(
        label="Clustering",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["clustering"],
    )
    create_hostgroups = forms.BooleanField(
        label="Create Host Groups",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["create_hostgroups"],
    )
    create_journal = forms.BooleanField(
        label="Create Journal Entries",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["create_journal"],
    )

    # --- Hostgroups ---
    hostgroup_format = forms.CharField(
        label="Host Group Format",
        initial=SYNC_CONFIG_DEFAULTS["hostgroup_format"],
    )
    traverse_regions = forms.BooleanField(
        label="Traverse Regions",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["traverse_regions"],
    )
    traverse_site_groups = forms.BooleanField(
        label="Traverse Site Groups",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["traverse_site_groups"],
    )
    extended_site_properties = forms.BooleanField(
        label="Extended Site Properties",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["extended_site_properties"],
    )

    # --- Inventory ---
    inventory_mode = forms.ChoiceField(
        label="Inventory Mode",
        choices=INVENTORY_MODE_CHOICES,
        initial=SYNC_CONFIG_DEFAULTS["inventory_mode"],
    )
    inventory_sync = forms.BooleanField(
        label="Inventory Sync",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["inventory_sync"],
    )
    device_inventory_map = forms.CharField(
        label="Device Inventory Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 4}),
        help_text="JSON mapping of NetBox fields to Zabbix inventory fields",
    )
    vm_inventory_map = forms.CharField(
        label="VM Inventory Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
        help_text="JSON mapping of NetBox VM fields to Zabbix inventory fields",
    )

    # --- Usermacros ---
    usermacro_sync = forms.ChoiceField(
        label="Usermacro Sync",
        choices=USERMACRO_SYNC_CHOICES,
        initial="false",
    )
    device_usermacro_map = forms.CharField(
        label="Device Usermacro Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
        help_text="JSON mapping of NetBox fields to Zabbix user macros",
    )
    vm_usermacro_map = forms.CharField(
        label="VM Usermacro Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
        help_text="JSON mapping of NetBox VM fields to Zabbix user macros",
    )

    # --- Tags ---
    tag_sync = forms.BooleanField(
        label="Tag Sync",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["tag_sync"],
    )
    tag_lower = forms.BooleanField(
        label="Lowercase Tags",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["tag_lower"],
    )
    tag_name = forms.CharField(
        label="Tag Name",
        initial=SYNC_CONFIG_DEFAULTS["tag_name"],
    )
    tag_value = forms.CharField(
        label="Tag Value",
        initial=SYNC_CONFIG_DEFAULTS["tag_value"],
    )
    device_tag_map = forms.CharField(
        label="Device Tag Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
        help_text="JSON mapping of NetBox fields to Zabbix tags",
    )
    vm_tag_map = forms.CharField(
        label="VM Tag Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
        help_text="JSON mapping of NetBox VM fields to Zabbix tags",
    )

    # --- VM Settings ---
    sync_vms = forms.BooleanField(
        label="Sync Virtual Machines",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["sync_vms"],
    )
    vm_hostgroup_format = forms.CharField(
        label="VM Host Group Format",
        initial=SYNC_CONFIG_DEFAULTS["vm_hostgroup_format"],
    )

    # --- Device Lifecycle ---
    zabbix_device_removal = forms.CharField(
        label="Device Removal Statuses",
        required=False,
        help_text='JSON list of NetBox statuses that trigger host removal (e.g. ["Decommissioning", "Inventory"])',
    )
    zabbix_device_disable = forms.CharField(
        label="Device Disable Statuses",
        required=False,
        help_text='JSON list of NetBox statuses that disable the host (e.g. ["Offline", "Planned"])',
    )

    # --- Device Filtering ---
    full_proxy_sync = forms.BooleanField(
        label="Full Proxy Sync",
        required=False,
        initial=SYNC_CONFIG_DEFAULTS["full_proxy_sync"],
    )
    nb_device_filter = forms.CharField(
        label="NetBox Device Filter",
        required=False,
        help_text='JSON filter for NetBox devices (e.g. {"name__n": "null"})',
    )
    nb_vm_filter = forms.CharField(
        label="NetBox VM Filter",
        required=False,
        help_text='JSON filter for NetBox VMs (e.g. {"name__n": "null"})',
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Pre-populate JSON fields with pretty-printed defaults
        import json

        json_fields = {
            "device_inventory_map": SYNC_CONFIG_DEFAULTS["device_inventory_map"],
            "vm_inventory_map": SYNC_CONFIG_DEFAULTS["vm_inventory_map"],
            "device_usermacro_map": SYNC_CONFIG_DEFAULTS["device_usermacro_map"],
            "vm_usermacro_map": SYNC_CONFIG_DEFAULTS["vm_usermacro_map"],
            "device_tag_map": SYNC_CONFIG_DEFAULTS["device_tag_map"],
            "vm_tag_map": SYNC_CONFIG_DEFAULTS["vm_tag_map"],
            "zabbix_device_removal": SYNC_CONFIG_DEFAULTS["zabbix_device_removal"],
            "zabbix_device_disable": SYNC_CONFIG_DEFAULTS["zabbix_device_disable"],
            "nb_device_filter": SYNC_CONFIG_DEFAULTS["nb_device_filter"],
            "nb_vm_filter": SYNC_CONFIG_DEFAULTS["nb_vm_filter"],
        }
        for field_name, default_val in json_fields.items():
            if not self.initial.get(field_name):
                self.initial[field_name] = json.dumps(default_val, indent=2)
        # proxy_cf and proxy_group_cf default to empty string (False means disabled)
        if not self.initial.get("proxy_cf"):
            self.initial["proxy_cf"] = ""
        if not self.initial.get("proxy_group_cf"):
            self.initial["proxy_group_cf"] = ""

    def get_sync_config_payload(self) -> dict:
        """Build the payload for POST /sync_config from cleaned data.

        The webserver expects ``{"config": {"key": "string_value", ...}}``.
        All values are converted to strings.
        """
        data = self.cleaned_data
        config = {}
        # Boolean fields
        for field in [
            "templates_config_context",
            "templates_config_context_overrule",
            "clustering",
            "create_hostgroups",
            "create_journal",
            "traverse_regions",
            "traverse_site_groups",
            "extended_site_properties",
            "inventory_sync",
            "tag_sync",
            "tag_lower",
            "sync_vms",
            "full_proxy_sync",
        ]:
            config[field] = str(data.get(field, False)).lower()
        # String fields
        for field in [
            "template_cf",
            "device_cf",
            "description",
            "description_dt_format",
            "hostgroup_format",
            "inventory_mode",
            "usermacro_sync",
            "tag_name",
            "tag_value",
            "vm_hostgroup_format",
        ]:
            config[field] = data.get(field, "")
        # Optional string fields (proxy_cf, proxy_group_cf — empty means disabled/false)
        for field in ["proxy_cf", "proxy_group_cf"]:
            val = data.get(field, "").strip()
            config[field] = val if val else "false"
        # JSON fields — pass through as-is (already strings)
        for field in [
            "device_inventory_map",
            "vm_inventory_map",
            "device_usermacro_map",
            "vm_usermacro_map",
            "device_tag_map",
            "vm_tag_map",
            "zabbix_device_removal",
            "zabbix_device_disable",
            "nb_device_filter",
            "nb_vm_filter",
        ]:
            val = data.get(field, "").strip()
            if val:
                config[field] = val
        return {"config": config}
