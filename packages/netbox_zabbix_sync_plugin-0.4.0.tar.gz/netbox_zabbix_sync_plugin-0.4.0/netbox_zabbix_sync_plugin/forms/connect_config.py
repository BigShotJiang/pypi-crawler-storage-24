"""
Forms for Connect Config management.

Edit form for NetBox/Zabbix credentials stored on the webserver.
Sensitive fields (tokens, passwords) are optional unless the user
explicitly checks "Edit" — this avoids requiring re-entry of secrets
that are already stored on the webserver.
"""

from django import forms

try:
    from ..validators import validate_url_with_hostname
except ImportError:
    from netbox_zabbix_sync_plugin.validators import validate_url_with_hostname


class _RelaxedURLField(forms.CharField):
    """A CharField that validates URLs but allows bare hostnames (e.g. http://netbox:8080)."""

    def __init__(self, **kwargs):
        kwargs.setdefault("max_length", 200)
        super().__init__(**kwargs)
        self.validators.append(validate_url_with_hostname)


class ConnectConfigEditForm(forms.Form):
    """Edit form for connect config (NetBox/Zabbix credentials)."""

    AUTH_TYPE_CHOICES = [
        ("userpass", "Username / Password"),
        ("token", "API Token"),
    ]

    netbox_url = _RelaxedURLField(
        label="NetBox URL",
        help_text="The URL of this NetBox instance as seen by the webserver",
    )
    edit_netbox_token = forms.BooleanField(
        label="Edit NetBox Token",
        required=False,
        help_text="Check to update the NetBox API token",
    )
    netbox_token = forms.CharField(
        label="NetBox API Token",
        required=False,
        widget=forms.PasswordInput(render_value=True),
        help_text="API token for the webserver to access NetBox",
    )
    zabbix_url = _RelaxedURLField(
        label="Zabbix URL",
        help_text="The URL of the Zabbix server",
    )
    zabbix_auth_type = forms.ChoiceField(
        label="Zabbix Authentication",
        choices=AUTH_TYPE_CHOICES,
        initial="userpass",
        widget=forms.RadioSelect,
        help_text="Choose how the webserver authenticates with Zabbix",
    )
    zabbix_user = forms.CharField(
        label="Zabbix Username",
        required=False,
    )
    edit_zabbix_password = forms.BooleanField(
        label="Edit Zabbix Password",
        required=False,
        help_text="Check to update the Zabbix password",
    )
    zabbix_password = forms.CharField(
        label="Zabbix Password",
        required=False,
        widget=forms.PasswordInput(render_value=True),
    )
    edit_zabbix_token = forms.BooleanField(
        label="Edit Zabbix Token",
        required=False,
        help_text="Check to update the Zabbix API token",
    )
    zabbix_token = forms.CharField(
        label="Zabbix API Token",
        required=False,
        widget=forms.PasswordInput(render_value=True),
    )

    def clean(self):
        cleaned = super().clean()
        auth_type = cleaned.get("zabbix_auth_type")
        if auth_type == "userpass":
            if not cleaned.get("zabbix_user"):
                self.add_error("zabbix_user", "Username is required for username/password authentication.")
            # Only require password if user checked "edit password"
            if cleaned.get("edit_zabbix_password") and not cleaned.get("zabbix_password"):
                self.add_error("zabbix_password", "Password is required when editing.")
        elif auth_type == "token":
            # Only require token if user checked "edit token"
            if cleaned.get("edit_zabbix_token") and not cleaned.get("zabbix_token"):
                self.add_error("zabbix_token", "API token is required when editing.")
        # Only require netbox_token if user checked "edit netbox token"
        if cleaned.get("edit_netbox_token") and not cleaned.get("netbox_token"):
            self.add_error("netbox_token", "NetBox token is required when editing.")
        return cleaned

    def get_patch_payload(self, original: dict) -> dict:
        """Build a PATCH payload containing only fields that changed from original."""
        data = self.cleaned_data
        payload = {}

        # URL fields — always compare
        for field in ("netbox_url", "zabbix_url"):
            new_val = data.get(field, "")
            if new_val != original.get(field, ""):
                payload[field] = new_val

        # NetBox token — only if user opted to edit
        if data.get("edit_netbox_token") and data.get("netbox_token"):
            payload["netbox_token"] = data["netbox_token"]

        # Zabbix username — always compare (not a secret)
        if data["zabbix_auth_type"] == "userpass":
            if data.get("zabbix_user", "") != original.get("zabbix_user", ""):
                payload["zabbix_user"] = data["zabbix_user"]
            # Password only if user opted to edit
            if data.get("edit_zabbix_password") and data.get("zabbix_password"):
                payload["zabbix_password"] = data["zabbix_password"]
            # Clear token if switching to userpass
            if original.get("zabbix_token"):
                payload["zabbix_token"] = ""
        else:
            # Zabbix token only if user opted to edit
            if data.get("edit_zabbix_token") and data.get("zabbix_token"):
                payload["zabbix_token"] = data["zabbix_token"]
            # Clear user/pass if switching to token
            if original.get("zabbix_user"):
                payload["zabbix_user"] = ""
            if original.get("zabbix_password"):
                payload["zabbix_password"] = ""

        return payload
