"""
Forms for Sync Config management.

Edit form for sync configuration stored on the webserver.
Reuses field definitions from the setup wizard step 3 form.
"""

import json

from django import forms

from .setup_wizard import (
    DESCRIPTION_CHOICES,
    INVENTORY_MODE_CHOICES,
    SYNC_CONFIG_DEFAULTS,
    USERMACRO_SYNC_CHOICES,
)


class SyncConfigEditForm(forms.Form):
    """Edit form for sync config (partial update via PATCH)."""

    # --- General ---
    templates_config_context = forms.BooleanField(
        label="Templates from Config Context",
        required=False,
    )
    templates_config_context_overrule = forms.BooleanField(
        label="Config Context Overrules Template CF",
        required=False,
    )
    template_cf = forms.CharField(label="Template Custom Field")
    device_cf = forms.CharField(label="Device Custom Field")
    proxy_cf = forms.CharField(label="Proxy Custom Field", required=False)
    proxy_group_cf = forms.CharField(label="Proxy Group Custom Field", required=False)
    description = forms.ChoiceField(label="Description Mode", choices=DESCRIPTION_CHOICES)
    description_dt_format = forms.CharField(label="Description Date Format")
    clustering = forms.BooleanField(label="Clustering", required=False)
    create_hostgroups = forms.BooleanField(label="Create Host Groups", required=False)
    create_journal = forms.BooleanField(label="Create Journal Entries", required=False)

    # --- Hostgroups ---
    hostgroup_format = forms.CharField(label="Host Group Format")
    traverse_regions = forms.BooleanField(label="Traverse Regions", required=False)
    traverse_site_groups = forms.BooleanField(label="Traverse Site Groups", required=False)
    extended_site_properties = forms.BooleanField(label="Extended Site Properties", required=False)

    # --- Inventory ---
    inventory_mode = forms.ChoiceField(label="Inventory Mode", choices=INVENTORY_MODE_CHOICES)
    inventory_sync = forms.BooleanField(label="Inventory Sync", required=False)
    device_inventory_map = forms.CharField(
        label="Device Inventory Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 4}),
    )
    vm_inventory_map = forms.CharField(
        label="VM Inventory Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )

    # --- Usermacros ---
    usermacro_sync = forms.ChoiceField(label="Usermacro Sync", choices=USERMACRO_SYNC_CHOICES)
    device_usermacro_map = forms.CharField(
        label="Device Usermacro Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )
    vm_usermacro_map = forms.CharField(
        label="VM Usermacro Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )

    # --- Tags ---
    tag_sync = forms.BooleanField(label="Tag Sync", required=False)
    tag_lower = forms.BooleanField(label="Lowercase Tags", required=False)
    tag_name = forms.CharField(label="Tag Name")
    tag_value = forms.CharField(label="Tag Value")
    device_tag_map = forms.CharField(
        label="Device Tag Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )
    vm_tag_map = forms.CharField(
        label="VM Tag Map",
        required=False,
        widget=forms.Textarea(attrs={"rows": 3}),
    )

    # --- VM Settings ---
    sync_vms = forms.BooleanField(label="Sync Virtual Machines", required=False)
    vm_hostgroup_format = forms.CharField(label="VM Host Group Format")

    # --- Device Lifecycle ---
    zabbix_device_removal = forms.CharField(label="Device Removal Statuses", required=False)
    zabbix_device_disable = forms.CharField(label="Device Disable Statuses", required=False)

    # --- Device Filtering ---
    full_proxy_sync = forms.BooleanField(label="Full Proxy Sync", required=False)
    nb_device_filter = forms.CharField(label="NetBox Device Filter", required=False)
    nb_vm_filter = forms.CharField(label="NetBox VM Filter", required=False)

    # Fields that hold JSON strings
    JSON_FIELDS = [
        "device_inventory_map",
        "vm_inventory_map",
        "device_usermacro_map",
        "vm_usermacro_map",
        "device_tag_map",
        "vm_tag_map",
        "zabbix_device_removal",
        "zabbix_device_disable",
        "nb_device_filter",
        "nb_vm_filter",
    ]

    # Boolean fields
    BOOL_FIELDS = [
        "templates_config_context",
        "templates_config_context_overrule",
        "clustering",
        "create_hostgroups",
        "create_journal",
        "traverse_regions",
        "traverse_site_groups",
        "extended_site_properties",
        "inventory_sync",
        "tag_sync",
        "tag_lower",
        "sync_vms",
        "full_proxy_sync",
    ]

    # String fields
    STR_FIELDS = [
        "template_cf",
        "device_cf",
        "proxy_cf",
        "proxy_group_cf",
        "description",
        "description_dt_format",
        "hostgroup_format",
        "inventory_mode",
        "usermacro_sync",
        "tag_name",
        "tag_value",
        "vm_hostgroup_format",
    ]

    def populate_from_config(self, config: dict):
        """Set initial values from a config dict returned by the webserver."""
        initial = {}
        for field in self.BOOL_FIELDS:
            val = config.get(field)
            if val is not None:
                initial[field] = str(val).lower() == "true"
        for field in self.STR_FIELDS:
            if field in config:
                initial[field] = config[field]
        # usermacro_sync needs special handling
        usermacro_val = config.get("usermacro_sync")
        if usermacro_val is not None:
            if str(usermacro_val).lower() in ("false", "0"):
                initial["usermacro_sync"] = "false"
            elif str(usermacro_val).lower() in ("true", "1"):
                initial["usermacro_sync"] = "true"
            else:
                initial["usermacro_sync"] = str(usermacro_val)
        # proxy_cf / proxy_group_cf: "false" means disabled
        for field in ["proxy_cf", "proxy_group_cf"]:
            val = config.get(field, "")
            initial[field] = "" if str(val).lower() == "false" else str(val)
        # JSON fields
        for field in self.JSON_FIELDS:
            val = config.get(field)
            if val is not None:
                if isinstance(val, str):
                    initial[field] = val
                else:
                    initial[field] = json.dumps(val, indent=2)
            else:
                default = SYNC_CONFIG_DEFAULTS.get(field)
                if default is not None:
                    initial[field] = json.dumps(default, indent=2)
        self.initial = initial

    def get_patch_payload(self, original: dict) -> dict:
        """Build a PATCH payload containing only fields that changed from original.

        The webserver expects ``{"config": {"key": "string_value", ...}}``.
        """
        data = self.cleaned_data
        config = {}

        for field in self.BOOL_FIELDS:
            new_val = str(data.get(field, False)).lower()
            orig_val = str(original.get(field, False)).lower()
            if new_val != orig_val:
                config[field] = new_val

        for field in self.STR_FIELDS:
            new_val = data.get(field, "")
            orig_val = str(original.get(field, ""))
            if new_val != orig_val:
                config[field] = new_val

        # proxy_cf / proxy_group_cf: empty means "false"
        for field in ["proxy_cf", "proxy_group_cf"]:
            new_val = data.get(field, "").strip()
            new_val = new_val if new_val else "false"
            orig_val = str(original.get(field, "false"))
            if new_val != orig_val:
                config[field] = new_val

        # JSON fields
        for field in self.JSON_FIELDS:
            new_val = data.get(field, "").strip()
            orig_val = original.get(field)
            if isinstance(orig_val, dict | list):
                orig_str = json.dumps(orig_val, indent=2)
            else:
                orig_str = str(orig_val) if orig_val is not None else ""
            # Normalize for comparison
            try:
                new_parsed = json.loads(new_val) if new_val else None
                orig_parsed = json.loads(orig_str) if orig_str else None
                if new_parsed != orig_parsed:
                    config[field] = new_val
            except (json.JSONDecodeError, TypeError):
                if new_val != orig_str:
                    config[field] = new_val

        if not config:
            return {}
        return {"config": config}
