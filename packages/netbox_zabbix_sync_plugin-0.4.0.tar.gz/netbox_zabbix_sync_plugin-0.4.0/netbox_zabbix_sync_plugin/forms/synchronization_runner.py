"""
Forms for SynchronizationRunner model.

For more information on NetBox forms, see:
https://docs.netbox.dev/en/stable/plugins/development/forms/
"""

from django import forms
from netbox.forms import (
    NetBoxModelBulkEditForm,
    NetBoxModelFilterSetForm,
    NetBoxModelForm,
    NetBoxModelImportForm,
)
from utilities.forms.fields import CommentField

from ..models import SynchronizationRunner
from ..models.synchronization_runner import RunnerMode


class SynchronizationRunnerForm(NetBoxModelForm):
    """Form for creating and editing SynchronizationRunner objects."""

    comments = CommentField()

    class Meta:
        model = SynchronizationRunner
        fields = (
            "name",
            "description",
            "mode",
            "url",
            "token",
            "tags",
            "comments",
        )
        widgets = {
            "token": forms.PasswordInput(render_value=True),
            "mode": forms.RadioSelect,
        }
        help_texts = {
            "url": "URL of the remote netbox-zabbix-sync webserver (remote mode only)",
            "token": "HMAC token for the remote webserver (remote mode only)",
        }

    def clean(self):
        super().clean()
        mode = self.cleaned_data.get("mode")
        if mode == RunnerMode.LOCAL:
            # url and token are not required for local mode
            if "url" in self.errors and not self.cleaned_data.get("url"):
                del self.errors["url"]
            if "token" in self.errors and not self.cleaned_data.get("token"):
                del self.errors["token"]
        return self.cleaned_data


class SynchronizationRunnerFilterForm(NetBoxModelFilterSetForm):
    """Filter form for SynchronizationRunner list view."""

    model = SynchronizationRunner

    name = forms.CharField(required=False, label="Name")


class SynchronizationRunnerImportForm(NetBoxModelImportForm):
    """Form for importing SynchronizationRunner via CSV."""

    class Meta:
        model = SynchronizationRunner
        fields = (
            "name",
            "description",
            "mode",
            "url",
            "token",
        )


class SynchronizationRunnerBulkEditForm(NetBoxModelBulkEditForm):
    """Form for bulk editing SynchronizationRunner objects."""

    model = SynchronizationRunner

    description = forms.CharField(required=False, label="Description")
    mode = forms.ChoiceField(
        required=False,
        choices=[("", "---------")] + list(RunnerMode.choices),
        label="Mode",
    )
    url = forms.URLField(required=False, label="URL", assume_scheme="http")
    token = forms.CharField(required=False, label="Token", widget=forms.PasswordInput(render_value=True))

    class Meta:
        nullable_fields = (
            "description",
            "url",
            "token",
        )
