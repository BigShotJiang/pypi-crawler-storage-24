"""
Forms for synchronization scheduling.

For more information on NetBox forms, see:
https://docs.netbox.dev/en/stable/plugins/development/forms/
"""

from dcim.models import Device
from django import forms
from virtualization.models import VirtualMachine

from ..models import SynchronizationRunner

LOG_LEVEL_CHOICES = [
    ("DEBUG", "Debug"),
    ("INFO", "Info"),
    ("WARNING", "Warning"),
    ("ERROR", "Error"),
]


class ScheduleSynchronizationForm(forms.Form):
    """
    Form for scheduling a synchronization job.

    Allows users to select a runner and optionally filter by device or VM.
    When a device or VM is specified, only that object is synced.
    When neither is specified, a full sync is triggered.
    """

    runner = forms.ModelChoiceField(
        queryset=SynchronizationRunner.objects.all(),
        required=True,
        label="Synchronization Runner",
        help_text="Select the runner that will execute this synchronization",
        empty_label=None,
    )
    log_level = forms.ChoiceField(
        choices=LOG_LEVEL_CHOICES,
        initial="WARNING",
        required=False,
        label="Log Level",
        help_text="Verbosity of the sync log output",
        widget=forms.RadioSelect,
    )
    device = forms.ModelChoiceField(
        queryset=Device.objects.all(),
        required=False,
        label="Device",
        help_text="Optional: sync only this device",
        empty_label="--- All devices ---",
    )
    vm = forms.ModelChoiceField(
        queryset=VirtualMachine.objects.all(),
        required=False,
        label="Virtual Machine",
        help_text="Optional: sync only this VM",
        empty_label="--- All VMs ---",
    )

    def get_sync_payload(self) -> dict:
        """Build the /sync payload with optional device/VM filters."""
        payload: dict = {}
        device = self.cleaned_data.get("device")
        vm = self.cleaned_data.get("vm")
        if device:
            payload["device_filter"] = {"name": device.name}
        if vm:
            payload["vm_filter"] = {"name": vm.name}
        payload["log_level"] = self.cleaned_data.get("log_level", "INFO")
        return payload
