"""
NetBox Zabbix Sync Plugin

Plugin configuration for NetBox Zabbix Sync Plugin.

For a complete list of PluginConfig attributes, see:
https://docs.netbox.dev/en/stable/plugins/development/#pluginconfig-attributes
"""

__version__ = "0.4.0"


from netbox.plugins import PluginConfig


class Netbox_Zabbix_SyncConfig(PluginConfig):
    name = "netbox_zabbix_sync_plugin"
    verbose_name = "NetBox Zabbix Sync Plugin"
    description = "NetBox companion plugin for the netbox-zabbix-sync python project"
    author = "Twan K"
    author_email = "twan@twan-it.nl"
    version = __version__
    base_url = "netbox-zabbix-sync"
    min_version = "4.5.0"
    max_version = "4.5.99"
    graphql_schema = "graphql.schema"
    default_settings = {
        "sync_log_retention": 100,
    }

    def ready(self):
        super().ready()
        from . import jobs  # noqa: F401 — register SyncJob with NetBox's job system


config = Netbox_Zabbix_SyncConfig
