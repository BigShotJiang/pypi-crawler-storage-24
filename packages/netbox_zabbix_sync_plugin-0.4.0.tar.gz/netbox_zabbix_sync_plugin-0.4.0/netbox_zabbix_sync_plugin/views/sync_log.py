"""
Views for sync log display.
"""

from django.core.paginator import Paginator
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render
from django.views.generic import View

from ..models import SynchronizationRunner, SyncLog

LOGS_PER_PAGE = 25


class SyncLogListView(View):
    """Show sync logs for a runner with pagination."""

    def get(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)
        logs_qs = runner.sync_logs.all()
        paginator = Paginator(logs_qs, LOGS_PER_PAGE)
        page_number = request.GET.get("page", 1)
        page = paginator.get_page(page_number)
        return render(
            request,
            "netbox_zabbix_sync_plugin/sync_log_list.html",
            {"runner": runner, "page": page},
        )


class SyncLogDetailView(View):
    """Show a single sync log entry."""

    def get(self, request, pk):
        sync_log = get_object_or_404(SyncLog.objects.select_related("runner"), pk=pk)
        return render(
            request,
            "netbox_zabbix_sync_plugin/sync_log_detail.html",
            {"sync_log": sync_log, "runner": sync_log.runner},
        )


class SyncLogPollView(View):
    """JSON endpoint for polling a running sync log's status and new output."""

    def get(self, request, pk):
        sync_log = get_object_or_404(SyncLog, pk=pk)
        # offset = number of characters the client already has
        offset = int(request.GET.get("offset", 0))
        output = sync_log.output[offset:]
        return JsonResponse(
            {
                "status": sync_log.status,
                "output": output,
                "offset": len(sync_log.output),
                "finished": sync_log.finished.isoformat() if sync_log.finished else None,
            }
        )


class RunnerSyncStatusView(View):
    """JSON endpoint for checking if a runner has a sync currently running."""

    def get(self, request, pk):
        runner = get_object_or_404(SynchronizationRunner, pk=pk)
        running_log = runner.sync_logs.filter(status="running").first()
        if running_log:
            return JsonResponse(
                {
                    "is_running": True,
                    "sync_log_id": running_log.pk,
                    "started": running_log.started.isoformat(),
                }
            )
        # Return the latest finished log for status display
        latest = runner.sync_logs.first()
        return JsonResponse(
            {
                "is_running": False,
                "sync_log_id": latest.pk if latest else None,
                "status": latest.status if latest else None,
                "started": latest.started.isoformat() if latest else None,
                "finished": latest.finished.isoformat() if latest and latest.finished else None,
            }
        )
