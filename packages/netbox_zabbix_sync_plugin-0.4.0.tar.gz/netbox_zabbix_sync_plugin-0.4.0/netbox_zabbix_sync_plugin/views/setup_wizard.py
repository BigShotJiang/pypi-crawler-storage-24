"""
Views for the Setup Wizard.

Three-step wizard using Django session to track state:
- Step 1: Mode selection + credentials, validate, create Runner
- Step 2: Connect config (NetBox/Zabbix credentials), POST to webserver or save locally
- Step 3: Sync config options, POST to webserver or save locally
"""

import logging

from django import forms as django_forms
from django.contrib import messages
from django.shortcuts import redirect, render
from django.views.generic import View

from ..forms.setup_wizard import (
    SYNC_CONFIG_CATEGORIES,
    SetupWizardStep1Form,
    SetupWizardStep2Form,
    SetupWizardStep3Form,
)
from ..models import ConnectConfig, SyncConfig, SynchronizationRunner
from ..models.synchronization_runner import RunnerMode
from ..services import WebserverError
from ..services.hmac_client import HMACClient
from ..services.service_account import ensure_service_account

logger = logging.getLogger(__name__)

SESSION_RUNNER_ID = "wizard_runner_id"
SESSION_STEP = "wizard_step"
SESSION_NETBOX_URL = "wizard_netbox_url"


class SetupWizardStep1View(View):
    """Step 1: Mode selection + credentials, validate connectivity, create Runner."""

    template_name = "netbox_zabbix_sync_plugin/setup_wizard_step1.html"

    def get(self, request):
        form = SetupWizardStep1Form()

        # Warn if a local runner already exists — re-running the wizard
        # will regenerate the service account token and invalidate the old one.
        existing_local = SynchronizationRunner.objects.filter(mode=RunnerMode.LOCAL).first()
        if existing_local:
            messages.warning(
                request,
                f"A local runner '{existing_local.name}' is already configured. "
                "Re-running the wizard will generate a new API token and invalidate the current one.",
            )

        return render(request, self.template_name, {"form": form})

    def post(self, request):
        form = SetupWizardStep1Form(request.POST)
        if not form.is_valid():
            return render(request, self.template_name, {"form": form})

        mode = form.cleaned_data["mode"]

        if mode == RunnerMode.REMOTE:
            return self._handle_remote(request, form)
        return self._handle_local(request, form)

    def _handle_remote(self, request, form):
        """Remote mode: health check + create runner with url/token (existing flow)."""
        url = form.cleaned_data["url"]
        token = form.cleaned_data["token"]

        # Validate connectivity via health check
        client = HMACClient(url, token)
        try:
            client.health_check()
        except WebserverError as e:
            messages.error(request, e.message)
            return render(request, self.template_name, {"form": form})
        except Exception:
            logger.exception("Unexpected error during health check for %s", url)
            messages.error(request, "An unexpected error occurred while connecting to the webserver.")
            return render(request, self.template_name, {"form": form})

        # Create or update the Runner
        runner, _created = SynchronizationRunner.objects.update_or_create(
            url=url,
            defaults={"name": f"Runner ({url})", "token": token, "mode": RunnerMode.REMOTE},
        )

        # Store wizard state in session
        request.session[SESSION_RUNNER_ID] = runner.pk
        request.session[SESSION_STEP] = 2

        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step2")

    def _handle_local(self, request, form):
        """Local mode: create runner with blank url/token, create service account."""
        password = form.cleaned_data["service_account_password"]

        try:
            _user, token_plaintext = ensure_service_account(password)
        except Exception:
            logger.exception("Failed to create service account")
            messages.error(request, "An unexpected error occurred while creating the service account.")
            return render(request, self.template_name, {"form": form})

        # Create or update the Runner (local mode, blank url/token)
        runner, _created = SynchronizationRunner.objects.update_or_create(
            name="Local Runner",
            defaults={"url": "", "token": "", "mode": RunnerMode.LOCAL},
        )

        # Build netbox_url from the deployment type and request hostname
        scheme = form.get_netbox_scheme()
        port = form.get_netbox_port()
        deployment_type = form.cleaned_data.get("deployment_type", "docker")

        # For Docker deployments, use the container service name "netbox" since
        # the sync runs inside the same Docker network where 127.0.0.1 does not
        # resolve to the NetBox container.
        if deployment_type == "docker":
            hostname = "netbox"
        else:
            hostname = request.get_host().split(":")[0]  # strip any existing port
        # Omit port from URL for standard ports
        if (scheme == "https" and port == 443) or (scheme == "http" and port == 80):
            netbox_url = f"{scheme}://{hostname}/"
        else:
            netbox_url = f"{scheme}://{hostname}:{port}/"

        # Store wizard state in session
        request.session[SESSION_RUNNER_ID] = runner.pk
        request.session[SESSION_STEP] = 2
        request.session[SESSION_NETBOX_URL] = netbox_url
        # Store the token for use in step 2 when creating ConnectConfig
        request.session["wizard_netbox_token"] = token_plaintext

        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step2")


class SetupWizardStep2View(View):
    """Step 2: Collect connect config and POST to /connect_config."""

    template_name = "netbox_zabbix_sync_plugin/setup_wizard_step2.html"

    def _get_runner(self, request):
        runner_id = request.session.get(SESSION_RUNNER_ID)
        step = request.session.get(SESSION_STEP, 0)
        if not runner_id or step < 2:
            return None
        try:
            return SynchronizationRunner.objects.get(pk=runner_id)
        except SynchronizationRunner.DoesNotExist:
            return None

    def _is_local(self, runner):
        return runner.mode == RunnerMode.LOCAL

    def get(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")

        is_local = self._is_local(runner)
        initial = {}
        if is_local:
            # Pre-populate netbox_url from session (set in step 1)
            initial["netbox_url"] = request.session.get(SESSION_NETBOX_URL, "")

        form = SetupWizardStep2Form(initial=initial)

        if is_local:
            # netbox_token is auto-generated for local mode; hide and make optional
            form.fields["netbox_token"].required = False
            form.fields["netbox_token"].widget = django_forms.HiddenInput()

        return render(
            request,
            self.template_name,
            {"form": form, "runner": runner, "is_local": is_local},
        )

    def post(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")

        is_local = self._is_local(runner)
        form = SetupWizardStep2Form(request.POST)

        if is_local:
            # netbox_token is auto-generated for local mode; not required from form
            form.fields["netbox_token"].required = False

        if not form.is_valid():
            if is_local:
                form.fields["netbox_token"].widget = django_forms.HiddenInput()
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "is_local": is_local},
            )

        if is_local:
            return self._handle_local_post(request, form, runner)
        return self._handle_remote_post(request, form, runner)

    def _handle_local_post(self, request, form, runner):
        """Local mode: validate Zabbix connectivity and save to ConnectConfig."""
        payload = form.get_connect_config_payload()

        # Use netbox_url and netbox_token from session (set in step 1)
        netbox_url = request.session.get(SESSION_NETBOX_URL, "")
        netbox_token = request.session.get("wizard_netbox_token", "")

        # Validate Zabbix connectivity before saving
        zabbix_url = payload.get("zabbix_url", "")
        try:
            self._validate_zabbix_connectivity(payload, zabbix_url)
        except Exception as e:
            messages.error(request, f"Failed to connect to Zabbix: {e}")
            form.fields["netbox_token"].widget = django_forms.HiddenInput()
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "is_local": True},
            )

        # Create or update ConnectConfig for this runner
        ConnectConfig.objects.update_or_create(
            runner=runner,
            defaults={
                "netbox_url": netbox_url,
                "netbox_token": netbox_token,
                "zabbix_url": zabbix_url,
                "zabbix_user": payload.get("zabbix_user", ""),
                "zabbix_password": payload.get("zabbix_password", ""),
                "zabbix_token": payload.get("zabbix_token", ""),
            },
        )

        request.session[SESSION_STEP] = 3
        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step3")

    def _validate_zabbix_connectivity(self, payload, zabbix_url):
        """Attempt to authenticate with Zabbix using the provided credentials."""
        from zabbix_utils import ZabbixAPI

        zapi = ZabbixAPI(url=zabbix_url)
        if payload.get("zabbix_token"):
            zapi.login(token=payload["zabbix_token"])
        else:
            zapi.login(user=payload.get("zabbix_user", ""), password=payload.get("zabbix_password", ""))
        zapi.logout()

    def _handle_remote_post(self, request, form, runner):
        """Remote mode: POST to webserver via HMACClient (existing flow)."""
        client = HMACClient(runner.url, runner.token)
        payload = form.get_connect_config_payload()
        try:
            client.post("/connect_config", payload)
        except WebserverError as e:
            messages.error(request, e.message)
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "is_local": False},
            )
        except Exception:
            logger.exception("Unexpected error posting connect config for runner %s", runner.pk)
            messages.error(request, "An unexpected error occurred while saving credentials.")
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "is_local": False},
            )

        request.session[SESSION_STEP] = 3
        return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step3")


class SetupWizardStep3View(View):
    """Step 3: Collect sync config and POST to /sync_config."""

    template_name = "netbox_zabbix_sync_plugin/setup_wizard_step3.html"

    def _get_runner(self, request):
        runner_id = request.session.get(SESSION_RUNNER_ID)
        step = request.session.get(SESSION_STEP, 0)
        if not runner_id or step < 3:
            return None
        try:
            return SynchronizationRunner.objects.get(pk=runner_id)
        except SynchronizationRunner.DoesNotExist:
            return None

    def _is_local(self, runner):
        return runner.mode == RunnerMode.LOCAL

    def get(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")
        form = SetupWizardStep3Form()
        return render(
            request,
            self.template_name,
            {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
        )

    def post(self, request):
        runner = self._get_runner(request)
        if not runner:
            messages.warning(request, "Wizard session expired, please start again.")
            return redirect("plugins:netbox_zabbix_sync_plugin:setup_wizard_step1")

        form = SetupWizardStep3Form(request.POST)
        if not form.is_valid():
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )

        if self._is_local(runner):
            return self._handle_local_post(request, form, runner)
        return self._handle_remote_post(request, form, runner)

    def _handle_local_post(self, request, form, runner):
        """Local mode: save sync config to SyncConfig model."""
        payload = form.get_sync_config_payload()

        SyncConfig.objects.update_or_create(
            runner=runner,
            defaults={"config": payload.get("config", payload)},
        )

        # Clean up wizard session state
        request.session.pop(SESSION_RUNNER_ID, None)
        request.session.pop(SESSION_STEP, None)
        request.session.pop(SESSION_NETBOX_URL, None)
        request.session.pop("wizard_netbox_token", None)

        messages.success(request, "Setup wizard completed successfully.")
        return render(
            request,
            "netbox_zabbix_sync_plugin/setup_wizard_complete.html",
            {"runner": runner},
        )

    def _handle_remote_post(self, request, form, runner):
        """Remote mode: POST to webserver via HMACClient (existing flow)."""
        client = HMACClient(runner.url, runner.token)
        payload = form.get_sync_config_payload()
        try:
            client.post("/sync_config", payload)
        except WebserverError as e:
            messages.error(request, e.message)
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )
        except Exception:
            logger.exception("Unexpected error posting sync config for runner %s", runner.pk)
            messages.error(request, "An unexpected error occurred while saving sync configuration.")
            return render(
                request,
                self.template_name,
                {"form": form, "runner": runner, "categories": SYNC_CONFIG_CATEGORIES},
            )

        # Clean up wizard session state
        request.session.pop(SESSION_RUNNER_ID, None)
        request.session.pop(SESSION_STEP, None)

        messages.success(request, "Setup wizard completed successfully.")
        return render(
            request,
            "netbox_zabbix_sync_plugin/setup_wizard_complete.html",
            {"runner": runner},
        )
