"""
Zabbix tab views for Device and VirtualMachine detail pages.

Registers as additional tabs on the core Device and VM views using
NetBox's register_model_view() mechanism.
"""

import logging

from dcim.models import Device
from django.shortcuts import get_object_or_404, render
from django.urls import reverse
from netbox.views import generic
from utilities.views import ViewTab, register_model_view
from virtualization.models import VirtualMachine

from ..services.config_cache import get_device_cf
from ..services.zabbix_client import get_host_maintenance, get_host_problems

logger = logging.getLogger(__name__)


def _has_primary_ip(obj) -> bool:
    """Return True if the object has any primary IP (v4 or v6)."""
    return bool(getattr(obj, "primary_ip4", None) or getattr(obj, "primary_ip6", None))


def _runner_exists() -> bool:
    """Return True if at least one SynchronizationRunner is configured."""
    from ..models import SynchronizationRunner

    return SynchronizationRunner.objects.exists()


def _get_zabbix_hostid(obj):
    """Return the Zabbix host ID custom field value, or None.

    The custom field name is read from the config cache (populated at
    startup and updated when sync config is saved via the GUI).
    """
    try:
        return obj.cf.get(get_device_cf())
    except Exception:
        return None


def _tab_visible(obj) -> bool:
    """Tab is visible when a runner exists and the object has a primary IP."""
    return _runner_exists() and _has_primary_ip(obj)


@register_model_view(Device, name="zabbix", path="zabbix")
class DeviceZabbixTabView(generic.ObjectView):
    """Zabbix tab on Device detail page."""

    queryset = Device.objects.all()
    tab = ViewTab(label="Zabbix", hide_if_empty=False)

    def get(self, request, pk):
        device = get_object_or_404(Device, pk=pk)

        if not _tab_visible(device):
            return render(
                request,
                "netbox_zabbix_sync_plugin/zabbix_tab.html",
                {
                    "object": device,
                    "tab": self.tab,
                    "tab_hidden": True,
                },
            )

        hostid = _get_zabbix_hostid(device)
        sync_url = reverse("plugins:netbox_zabbix_sync_plugin:schedule_synchronization")

        ctx = {
            "object": device,
            "tab": self.tab,
            "tab_hidden": False,
            "object_type": "device",
            "zabbix_hostid": hostid,
            "sync_url": sync_url,
            "maintenance": None,
            "problems": None,
        }

        if hostid:
            ctx["maintenance"] = get_host_maintenance(str(hostid))
            ctx["problems"] = get_host_problems(str(hostid))

        return render(request, "netbox_zabbix_sync_plugin/zabbix_tab.html", ctx)


@register_model_view(VirtualMachine, name="zabbix", path="zabbix")
class VMZabbixTabView(generic.ObjectView):
    """Zabbix tab on VirtualMachine detail page."""

    queryset = VirtualMachine.objects.all()
    tab = ViewTab(label="Zabbix", hide_if_empty=False)

    def get(self, request, pk):
        vm = get_object_or_404(VirtualMachine, pk=pk)

        if not _tab_visible(vm):
            return render(
                request,
                "netbox_zabbix_sync_plugin/zabbix_tab.html",
                {
                    "object": vm,
                    "tab": self.tab,
                    "tab_hidden": True,
                },
            )

        hostid = _get_zabbix_hostid(vm)
        sync_url = reverse("plugins:netbox_zabbix_sync_plugin:schedule_synchronization")

        ctx = {
            "object": vm,
            "tab": self.tab,
            "tab_hidden": False,
            "object_type": "vm",
            "zabbix_hostid": hostid,
            "sync_url": sync_url,
            "maintenance": None,
            "problems": None,
        }

        if hostid:
            ctx["maintenance"] = get_host_maintenance(str(hostid))
            ctx["problems"] = get_host_problems(str(hostid))

        return render(request, "netbox_zabbix_sync_plugin/zabbix_tab.html", ctx)
