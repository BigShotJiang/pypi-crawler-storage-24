"""
Views for synchronization scheduling and execution.
"""

import logging

from django.contrib import messages
from django.shortcuts import redirect, render
from django.views.generic import View

from ..forms.synchronization import ScheduleSynchronizationForm
from ..services import WebserverError, get_backend

logger = logging.getLogger(__name__)


class ScheduleSynchronizationView(View):
    """Schedule a synchronization, optionally filtered by device or VM."""

    def get(self, request):
        form = ScheduleSynchronizationForm(initial=request.GET)
        runner_modes = self._get_runner_modes()
        return render(
            request,
            "netbox_zabbix_sync_plugin/schedule_synchronization.html",
            {
                "form": form,
                "runner_modes_json": runner_modes,
            },
        )

    def post(self, request):
        form = ScheduleSynchronizationForm(request.POST)
        runner_modes = self._get_runner_modes()
        if not form.is_valid():
            return render(
                request,
                "netbox_zabbix_sync_plugin/schedule_synchronization.html",
                {
                    "form": form,
                    "runner_modes_json": runner_modes,
                },
            )

        runner = form.cleaned_data["runner"]
        payload = form.get_sync_payload()

        backend = get_backend(runner)
        try:
            result = backend.trigger_sync(payload)
        except RuntimeError as e:
            messages.error(request, str(e))
            return render(
                request,
                "netbox_zabbix_sync_plugin/schedule_synchronization.html",
                {
                    "form": form,
                    "runner_modes_json": runner_modes,
                },
            )
        except WebserverError as e:
            messages.error(request, e.message)
            return render(
                request,
                "netbox_zabbix_sync_plugin/schedule_synchronization.html",
                {
                    "form": form,
                    "runner_modes_json": runner_modes,
                },
            )
        except Exception:
            logger.exception("Unexpected error triggering sync for runner %s", runner.name)
            messages.error(request, "An unexpected error occurred.")
            return render(
                request,
                "netbox_zabbix_sync_plugin/schedule_synchronization.html",
                {
                    "form": form,
                    "runner_modes_json": runner_modes,
                },
            )

        # If the backend returned a sync_log_id (local mode), redirect to the live log view
        sync_log_id = result.get("sync_log_id") if isinstance(result, dict) else None
        if sync_log_id:
            messages.success(request, f"Sync started for runner '{runner.name}'.")
            return redirect("plugins:netbox_zabbix_sync_plugin:sync_log_detail", pk=sync_log_id)

        device = form.cleaned_data.get("device")
        vm = form.cleaned_data.get("vm")
        if device:
            messages.success(request, f"Sync triggered for device '{device.name}' via runner '{runner.name}'.")
            return redirect(device.get_absolute_url())
        elif vm:
            messages.success(request, f"Sync triggered for VM '{vm.name}' via runner '{runner.name}'.")
            return redirect(vm.get_absolute_url())
        else:
            messages.success(request, f"Full sync triggered via runner '{runner.name}'.")
            return redirect(runner.get_absolute_url())

    @staticmethod
    def _get_runner_modes() -> str:
        """Return a JSON string mapping runner PKs to their mode."""
        import json

        from ..models import SynchronizationRunner

        modes = {str(r.pk): r.mode for r in SynchronizationRunner.objects.all()}
        return json.dumps(modes)
