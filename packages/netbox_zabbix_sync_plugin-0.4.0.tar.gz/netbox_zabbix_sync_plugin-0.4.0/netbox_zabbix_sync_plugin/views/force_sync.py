"""
Views for Force Sync of individual Devices and VMs.

POST-only views that trigger a sync via the webserver for a single object.
"""

import logging

from dcim.models import Device
from django.contrib import messages
from django.shortcuts import get_object_or_404, redirect
from django.views.generic import View
from virtualization.models import VirtualMachine

from ..models import SynchronizationRunner
from ..services import WebserverError, get_backend

logger = logging.getLogger(__name__)


def _get_runner():
    """Get the first available runner. Returns None if no runners exist."""
    return SynchronizationRunner.objects.first()


class DeviceForceSyncView(View):
    """POST: trigger sync for a single device."""

    def post(self, request, pk):
        device = get_object_or_404(Device, pk=pk)
        runner = _get_runner()

        if not runner:
            messages.error(request, "No synchronization runner configured.")
            return redirect(device.get_absolute_url())

        backend = get_backend(runner)
        try:
            backend.trigger_sync({"device_filter": {"name": device.name}})
        except RuntimeError as e:
            messages.error(request, str(e))
        except WebserverError as e:
            messages.error(request, e.message)
        except Exception:
            logger.exception("Unexpected error during force sync for device %s", device.name)
            messages.error(request, "An unexpected error occurred during sync.")
        else:
            messages.success(request, f"Sync triggered for device '{device.name}'.")

        return redirect(device.get_absolute_url())


class VMForceSyncView(View):
    """POST: trigger sync for a single virtual machine."""

    def post(self, request, pk):
        vm = get_object_or_404(VirtualMachine, pk=pk)
        runner = _get_runner()

        if not runner:
            messages.error(request, "No synchronization runner configured.")
            return redirect(vm.get_absolute_url())

        backend = get_backend(runner)
        try:
            backend.trigger_sync({"vm_filter": {"name": vm.name}})
        except RuntimeError as e:
            messages.error(request, str(e))
        except WebserverError as e:
            messages.error(request, e.message)
        except Exception:
            logger.exception("Unexpected error during force sync for VM %s", vm.name)
            messages.error(request, "An unexpected error occurred during sync.")
        else:
            messages.success(request, f"Sync triggered for VM '{vm.name}'.")

        return redirect(vm.get_absolute_url())
