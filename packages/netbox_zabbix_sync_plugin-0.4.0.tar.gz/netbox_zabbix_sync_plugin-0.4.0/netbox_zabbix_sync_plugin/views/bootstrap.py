"""
Views for the Bootstrap Utility.

Creates custom fields, example config contexts, and optionally a sync schedule.
Custom field names are read from the runner's sync config (device_cf, template_cf).
"""

import logging

from django.contrib import messages
from django.shortcuts import render
from django.views.generic import View

from ..forms.bootstrap import BootstrapForm
from ..models import SynchronizationRunner
from ..services import WebserverError, get_backend

logger = logging.getLogger(__name__)


def _get_custom_field_defs_from_runner(runner):
    """Fetch sync config from the runner's backend and build custom field definitions."""
    backend = get_backend(runner)
    config = backend.get_sync_config()

    device_cf = config.get("device_cf", "zabbix_hostid")
    template_cf = config.get("template_cf", "zabbix_template")

    return [
        {
            "name": device_cf,
            "label": device_cf.replace("_", " ").title(),
            "type": "integer",
            "content_types": ["dcim.device", "virtualization.virtualmachine"],
            "description": "Zabbix host ID (from sync config key 'device_cf')",
        },
        {
            "name": template_cf,
            "label": template_cf.replace("_", " ").title(),
            "type": "text",
            "content_types": ["dcim.devicetype"],
            "description": "Zabbix template name (from sync config key 'template_cf')",
        },
    ]


# Example config context definitions
CONFIG_CONTEXTS = [
    {
        "name": "Zabbix SNMPv3 Example",
        "description": "Example config context for SNMPv3 monitoring",
        "data": {
            "zabbix": {
                "snmpv3": {
                    "securityname": "snmpuser",
                    "securitylevel": "authPriv",
                    "authprotocol": "SHA256",
                    "authpassphrase": "changeme",
                    "privprotocol": "AES256",
                    "privpassphrase": "changeme",
                }
            }
        },
    },
    {
        "name": "Zabbix Custom Template Example",
        "description": "Example config context for custom template assignment",
        "data": {"zabbix": {"templates": ["Template OS Linux by Zabbix agent"]}},
    },
    {
        "name": "Zabbix Multi-Template Example",
        "description": "Example config context for multiple template assignment",
        "data": {
            "zabbix": {
                "templates": [
                    "Template OS Linux by Zabbix agent",
                    "Template App MySQL by Zabbix agent",
                ]
            }
        },
    },
]


def _create_custom_fields(custom_fields):
    """Create custom fields, skipping any that already exist. Returns (created, skipped) lists."""
    from django.contrib.contenttypes.models import ContentType
    from extras.models import CustomField

    created = []
    skipped = []

    cf_type_map = {
        "integer": "integer",
        "text": "text",
    }

    for cf_def in custom_fields:
        if CustomField.objects.filter(name=cf_def["name"]).exists():
            skipped.append(cf_def["name"])
            continue

        cf = CustomField.objects.create(
            name=cf_def["name"],
            label=cf_def["label"],
            type=cf_type_map[cf_def["type"]],
            description=cf_def["description"],
        )
        for ct_label in cf_def["content_types"]:
            app_label, model = ct_label.split(".")
            ct = ContentType.objects.get(app_label=app_label, model=model)
            cf.object_types.add(ct)

        created.append(cf_def["name"])

    return created, skipped


def _create_config_contexts():
    """Create example config contexts, skipping any that already exist. Returns (created, skipped) lists."""
    from extras.models import ConfigContext

    created = []
    skipped = []

    for ctx_def in CONFIG_CONTEXTS:
        if ConfigContext.objects.filter(name=ctx_def["name"]).exists():
            skipped.append(ctx_def["name"])
            continue

        ConfigContext.objects.create(
            name=ctx_def["name"],
            description=ctx_def["description"],
            data=ctx_def["data"],
            is_active=False,
        )
        created.append(ctx_def["name"])

    return created, skipped


class BootstrapView(View):
    """Bootstrap utility — create custom fields, config contexts, and sync schedule."""

    template_name = "netbox_zabbix_sync_plugin/bootstrap.html"

    def _get_custom_fields(self):
        """Get custom field definitions from the first runner's sync config, or fall back to defaults."""
        runner = SynchronizationRunner.objects.first()
        if runner:
            try:
                return _get_custom_field_defs_from_runner(runner), runner
            except (WebserverError, RuntimeError, Exception):
                logger.warning("Could not fetch sync config from runner '%s', using defaults", runner.name)
        # Fallback defaults
        return [
            {
                "name": "zabbix_hostid",
                "label": "Zabbix Hostid",
                "type": "integer",
                "content_types": ["dcim.device", "virtualization.virtualmachine"],
                "description": "Zabbix host ID (default — no runner available)",
            },
            {
                "name": "zabbix_template",
                "label": "Zabbix Template",
                "type": "text",
                "content_types": ["dcim.devicetype"],
                "description": "Zabbix template name (default — no runner available)",
            },
        ], runner

    def get(self, request):
        form = BootstrapForm()
        custom_fields, _ = self._get_custom_fields()
        return render(
            request,
            self.template_name,
            {
                "form": form,
                "custom_fields": custom_fields,
                "config_contexts": CONFIG_CONTEXTS,
            },
        )

    def post(self, request):
        form = BootstrapForm(request.POST)
        custom_fields, _ = self._get_custom_fields()

        if not form.is_valid():
            return render(
                request,
                self.template_name,
                {
                    "form": form,
                    "custom_fields": custom_fields,
                    "config_contexts": CONFIG_CONTEXTS,
                },
            )

        results = {}

        if form.cleaned_data.get("create_custom_fields"):
            try:
                created, skipped = _create_custom_fields(custom_fields)
                results["custom_fields"] = {"created": created, "skipped": skipped}
            except Exception:
                logger.exception("Error creating custom fields")
                messages.error(request, "Error creating custom fields.")

        if form.cleaned_data.get("create_config_contexts"):
            try:
                created, skipped = _create_config_contexts()
                results["config_contexts"] = {"created": created, "skipped": skipped}
            except Exception:
                logger.exception("Error creating config contexts")
                messages.error(request, "Error creating config contexts.")

        if form.cleaned_data.get("create_sync_schedule"):
            try:
                from ..jobs import SyncJob

                runner = SynchronizationRunner.objects.first()
                if runner:
                    SyncJob.enqueue_once(instance=runner, interval=60)
                    results["sync_schedule"] = {"status": "scheduled", "runner": runner.name}
                else:
                    messages.warning(request, "No runner found — cannot create sync schedule.")
                    results["sync_schedule"] = {"status": "no_runner"}
            except Exception:
                logger.exception("Error creating sync schedule")
                messages.error(request, "Error creating sync schedule.")

        if results:
            messages.success(request, "Bootstrap completed.")

        return render(
            request,
            self.template_name,
            {
                "form": form,
                "custom_fields": custom_fields,
                "config_contexts": CONFIG_CONTEXTS,
                "results": results,
            },
        )
