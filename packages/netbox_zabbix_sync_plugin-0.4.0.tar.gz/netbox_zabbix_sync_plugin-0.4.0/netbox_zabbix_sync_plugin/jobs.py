"""
Background jobs for the Zabbix Sync Plugin.

SyncJob uses NetBox's JobRunner system to execute periodic syncs.
"""

import logging

from netbox.jobs import JobRunner

from .services import WebserverError, get_backend

logger = logging.getLogger(__name__)


class SyncJob(JobRunner):
    """Periodic sync job that calls the webserver /sync endpoint."""

    class Meta:
        name = "Synchronization Job"

    def run(self, *args, **kwargs):
        runner = self.job.object
        if not runner:
            logger.error("SyncJob: no runner associated with job %s", self.job.pk)
            return

        try:
            backend = get_backend(runner)
            backend.trigger_sync({}, background=False)
            logger.info("SyncJob: sync completed for runner %s", runner.name)
        except WebserverError as e:
            logger.error("SyncJob: sync failed for runner %s: %s", runner.name, e.message)
        except RuntimeError as e:
            logger.error("SyncJob: sync failed for runner %s: %s", runner.name, e)
        except Exception:
            logger.exception("SyncJob: unexpected error for runner %s", runner.name)
