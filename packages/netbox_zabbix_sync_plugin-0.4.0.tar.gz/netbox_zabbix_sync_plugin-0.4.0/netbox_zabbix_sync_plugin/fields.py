"""Custom model fields with Fernet encryption at rest.

Sensitive values (tokens, passwords) are encrypted before being written to the
database and decrypted transparently when read. The encryption key is derived
from Django's ``SECRET_KEY`` using PBKDF2, so no additional configuration is
needed — the key stays constant for a given deployment.
"""

import base64
import hashlib

from cryptography.fernet import Fernet, InvalidToken
from django.conf import settings
from django.db import models


def _derive_key() -> bytes:
    """Derive a Fernet-compatible 32-byte key from Django's SECRET_KEY."""
    secret = settings.SECRET_KEY.encode()
    # PBKDF2 with a fixed salt tied to this app — deterministic per deployment
    dk = hashlib.pbkdf2_hmac("sha256", secret, b"netbox-zabbix-sync-plugin", 100_000)
    return base64.urlsafe_b64encode(dk)


def _get_fernet() -> Fernet:
    return Fernet(_derive_key())


def encrypt_value(plaintext: str) -> str:
    """Encrypt a plaintext string and return the ciphertext as a string."""
    if not plaintext:
        return ""
    return _get_fernet().encrypt(plaintext.encode()).decode()


def decrypt_value(ciphertext: str) -> str:
    """Decrypt a ciphertext string and return the plaintext."""
    if not ciphertext:
        return ""
    try:
        return _get_fernet().decrypt(ciphertext.encode()).decode()
    except (InvalidToken, Exception):
        # If decryption fails (e.g. key changed, corrupted data),
        # return empty string rather than crashing.
        return ""


class EncryptedCharField(models.CharField):
    """A CharField that encrypts its value before saving to the database.

    Values are encrypted with Fernet (AES-128-CBC + HMAC-SHA256) using a key
    derived from Django's SECRET_KEY. The ciphertext is stored as a base64
    string in the database. Decryption is transparent on read.

    The ``max_length`` should be set generously — Fernet ciphertext is longer
    than the plaintext (roughly ``len(plaintext) * 2 + 100``).
    """

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("max_length", 512)
        super().__init__(*args, **kwargs)

    def get_prep_value(self, value):
        """Encrypt before saving to DB."""
        value = super().get_prep_value(value)
        if value is None or value == "":
            return value
        # Don't double-encrypt — check if already encrypted
        if self._is_encrypted(value):
            return value
        return encrypt_value(value)

    def from_db_value(self, value, expression, connection):
        """Decrypt when reading from DB."""
        if value is None or value == "":
            return value
        return decrypt_value(value)

    def to_python(self, value):
        """Handle deserialization (e.g. from form input)."""
        if value is None:
            return value
        return str(value)

    @staticmethod
    def _is_encrypted(value: str) -> bool:
        """Check if a value looks like Fernet ciphertext."""
        if not value:
            return False
        try:
            # Fernet tokens start with 'gAAAAA' (base64 of version byte 0x80)
            return value.startswith("gAAAAA") and len(value) > 50
        except (TypeError, AttributeError):
            return False
