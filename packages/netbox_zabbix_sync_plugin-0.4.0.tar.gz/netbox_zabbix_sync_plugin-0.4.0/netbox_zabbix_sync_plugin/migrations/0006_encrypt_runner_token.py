"""Encrypt the SynchronizationRunner token field at rest.

Changes the token field from plain CharField to EncryptedCharField.
Existing plaintext values are encrypted in a data migration step.
"""

from django.db import migrations

from netbox_zabbix_sync_plugin.fields import EncryptedCharField, encrypt_value


def encrypt_existing_tokens(apps, schema_editor):
    """Encrypt any existing plaintext token values."""
    Runner = apps.get_model("netbox_zabbix_sync_plugin", "SynchronizationRunner")
    for runner in Runner.objects.all():
        if runner.token and not runner.token.startswith("gAAAAA"):
            runner.token = encrypt_value(runner.token)
            runner.save(update_fields=["token"])


class Migration(migrations.Migration):
    dependencies = [
        ("netbox_zabbix_sync_plugin", "0005_encrypt_sensitive_fields"),
    ]

    operations = [
        migrations.AlterField(
            model_name="synchronizationrunner",
            name="token",
            field=EncryptedCharField(
                blank=True, max_length=512, help_text="HMAC token for the remote webserver (remote mode only)"
            ),
        ),
        migrations.RunPython(encrypt_existing_tokens, migrations.RunPython.noop),
    ]
