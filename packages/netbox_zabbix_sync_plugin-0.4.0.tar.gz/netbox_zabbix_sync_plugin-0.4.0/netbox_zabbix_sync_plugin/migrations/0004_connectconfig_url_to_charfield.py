"""Change ConnectConfig URL fields from URLField to CharField.

URLField uses Django's URLValidator which rejects bare hostnames like
``http://netbox:8080`` (no TLD). CharField with a custom validator allows
Docker container names and short hostnames.
"""

from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [
        ("netbox_zabbix_sync_plugin", "0003_synclog"),
    ]

    operations = [
        migrations.AlterField(
            model_name="connectconfig",
            name="netbox_url",
            field=models.CharField(blank=True, max_length=200),
        ),
        migrations.AlterField(
            model_name="connectconfig",
            name="zabbix_url",
            field=models.CharField(blank=True, max_length=200),
        ),
    ]
