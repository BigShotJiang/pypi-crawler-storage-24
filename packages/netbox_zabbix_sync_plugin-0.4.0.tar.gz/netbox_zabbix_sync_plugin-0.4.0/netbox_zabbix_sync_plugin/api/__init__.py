"""
REST API for NetBox Zabbix Sync Plugin.

For more information on developing NetBox REST APIs, see:
https://docs.netbox.dev/en/stable/plugins/development/rest-api/
"""
