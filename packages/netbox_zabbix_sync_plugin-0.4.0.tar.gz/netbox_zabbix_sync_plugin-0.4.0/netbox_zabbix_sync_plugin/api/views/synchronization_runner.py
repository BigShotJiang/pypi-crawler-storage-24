"""
API viewsets for SynchronizationRunner model.

For more information on NetBox REST API viewsets, see:
https://docs.netbox.dev/en/stable/plugins/development/rest-api/#viewsets

For Django REST Framework viewsets, see:
https://www.django-rest-framework.org/api-guide/viewsets/
"""

from netbox.api.viewsets import NetBoxModelViewSet

from ... import filtersets
from ...models import SynchronizationRunner
from ..serializers import SynchronizationRunnerSerializer


class SynchronizationRunnerViewSet(NetBoxModelViewSet):
    """API viewset for SynchronizationRunner model."""

    queryset = SynchronizationRunner.objects.prefetch_related("tags")
    serializer_class = SynchronizationRunnerSerializer
    filterset_class = filtersets.SynchronizationRunnerFilterSet
