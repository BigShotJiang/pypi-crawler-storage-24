"""
API URL patterns for NetBox Zabbix Sync Plugin.

For more information on NetBox REST API routing, see:
https://docs.netbox.dev/en/stable/plugins/development/rest-api/#routers

For Django REST Framework routers, see:
https://www.django-rest-framework.org/api-guide/routers/
"""

from netbox.api.routers import NetBoxRouter

from .views import SynchronizationRunnerViewSet

app_name = "netbox_zabbix_sync_plugin"

router = NetBoxRouter()
router.register("runners", SynchronizationRunnerViewSet)

urlpatterns = router.urls
