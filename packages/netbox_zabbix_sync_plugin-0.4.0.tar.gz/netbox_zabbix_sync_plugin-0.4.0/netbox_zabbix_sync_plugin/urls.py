"""
URL patterns for NetBox Zabbix Sync Plugin.

For more information on URL routing, see:
https://docs.netbox.dev/en/stable/plugins/development/views/#url-registration

For Django URL patterns, see:
https://docs.djangoproject.com/en/stable/topics/http/urls/
"""

from django.urls import path
from netbox.views.generic import ObjectChangeLogView, ObjectJobsView

from . import models, views

urlpatterns = (
    # ── Runners ──────────────────────────────────────────────
    path("runners/", views.SynchronizationRunnerListView.as_view(), name="synchronizationrunner_list"),
    path("runners/add/", views.SynchronizationRunnerEditView.as_view(), name="synchronizationrunner_add"),
    path("runners/import/", views.SynchronizationRunnerBulkImportView.as_view(), name="synchronizationrunner_import"),
    path("runners/edit/", views.SynchronizationRunnerBulkEditView.as_view(), name="synchronizationrunner_bulk_edit"),
    path(
        "runners/delete/", views.SynchronizationRunnerBulkDeleteView.as_view(), name="synchronizationrunner_bulk_delete"
    ),
    path("runners/<int:pk>/", views.SynchronizationRunnerView.as_view(), name="synchronizationrunner"),
    path("runners/<int:pk>/edit/", views.SynchronizationRunnerEditView.as_view(), name="synchronizationrunner_edit"),
    path(
        "runners/<int:pk>/delete/", views.SynchronizationRunnerDeleteView.as_view(), name="synchronizationrunner_delete"
    ),
    path(
        "runners/<int:pk>/changelog/",
        ObjectChangeLogView.as_view(),
        name="synchronizationrunner_changelog",
        kwargs={"model": models.SynchronizationRunner},
    ),
    path(
        "runners/<int:pk>/jobs/",
        ObjectJobsView.as_view(),
        name="synchronizationrunner_jobs",
        kwargs={"model": models.SynchronizationRunner},
    ),
    # ── Runner sub-resources ─────────────────────────────────
    path("runners/<int:pk>/connect-config/", views.ConnectConfigView.as_view(), name="connect_config"),
    path("runners/<int:pk>/connect-config/edit/", views.ConnectConfigEditView.as_view(), name="connect_config_edit"),
    path("runners/<int:pk>/sync-config/", views.SyncConfigView.as_view(), name="sync_config"),
    path("runners/<int:pk>/sync-config/edit/", views.SyncConfigEditView.as_view(), name="sync_config_edit"),
    path(
        "runners/<int:pk>/sync-config/delete/<str:key>/",
        views.SyncConfigDeleteKeyView.as_view(),
        name="sync_config_delete_key",
    ),
    path("runners/<int:pk>/sync-schedule/", views.SyncScheduleView.as_view(), name="sync_schedule"),
    path("runners/<int:pk>/sync-logs/", views.SyncLogListView.as_view(), name="sync_log_list"),
    path("sync-logs/<int:pk>/", views.SyncLogDetailView.as_view(), name="sync_log_detail"),
    path("sync-logs/<int:pk>/poll/", views.SyncLogPollView.as_view(), name="sync_log_poll"),
    path("runners/<int:pk>/sync-status/", views.RunnerSyncStatusView.as_view(), name="runner_sync_status"),
    # ── Actions ──────────────────────────────────────────────
    path("sync/", views.ScheduleSynchronizationView.as_view(), name="schedule_synchronization"),
    path("sync/device/<int:pk>/", views.DeviceForceSyncView.as_view(), name="force_sync_device"),
    path("sync/vm/<int:pk>/", views.VMForceSyncView.as_view(), name="force_sync_vm"),
    # ── Wizard & Bootstrap ───────────────────────────────────
    path("setup-wizard/step1/", views.SetupWizardStep1View.as_view(), name="setup_wizard_step1"),
    path("setup-wizard/step2/", views.SetupWizardStep2View.as_view(), name="setup_wizard_step2"),
    path("setup-wizard/step3/", views.SetupWizardStep3View.as_view(), name="setup_wizard_step3"),
    path("bootstrap/", views.BootstrapView.as_view(), name="bootstrap"),
)
