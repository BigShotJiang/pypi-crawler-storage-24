"""
URL resolution tests for NetBox Zabbix Sync Plugin.

Verifies that all URL patterns resolve correctly.
"""

from django.test import TestCase
from django.urls import NoReverseMatch, reverse

from netbox_zabbix_sync_plugin.models import SynchronizationRunner


class URLResolutionTest(TestCase):
    """Tests that all plugin URL patterns resolve."""

    @classmethod
    def setUpTestData(cls):
        cls.runner = SynchronizationRunner.objects.create(
            name="URL Test Runner",
            url="http://example.com:8007",
            token="test",
        )

    def _resolve(self, name, **kwargs):
        """Helper to reverse a plugin URL name."""
        return reverse(f"plugins:netbox_zabbix_sync_plugin:{name}", kwargs=kwargs)

    def test_runner_list(self):
        self.assertIsNotNone(self._resolve("synchronizationrunner_list"))

    def test_runner_add(self):
        self.assertIsNotNone(self._resolve("synchronizationrunner_add"))

    def test_runner_detail(self):
        self.assertIsNotNone(self._resolve("synchronizationrunner", pk=self.runner.pk))

    def test_runner_edit(self):
        self.assertIsNotNone(self._resolve("synchronizationrunner_edit", pk=self.runner.pk))

    def test_runner_delete(self):
        self.assertIsNotNone(self._resolve("synchronizationrunner_delete", pk=self.runner.pk))

    def test_runner_changelog(self):
        self.assertIsNotNone(self._resolve("synchronizationrunner_changelog", pk=self.runner.pk))

    def test_runner_jobs(self):
        self.assertIsNotNone(self._resolve("synchronizationrunner_jobs", pk=self.runner.pk))

    def test_connect_config(self):
        self.assertIsNotNone(self._resolve("connect_config", pk=self.runner.pk))

    def test_connect_config_edit(self):
        self.assertIsNotNone(self._resolve("connect_config_edit", pk=self.runner.pk))

    def test_sync_config(self):
        self.assertIsNotNone(self._resolve("sync_config", pk=self.runner.pk))

    def test_sync_config_edit(self):
        self.assertIsNotNone(self._resolve("sync_config_edit", pk=self.runner.pk))

    def test_sync_schedule(self):
        self.assertIsNotNone(self._resolve("sync_schedule", pk=self.runner.pk))

    def test_schedule_synchronization(self):
        self.assertIsNotNone(self._resolve("schedule_synchronization"))

    def test_force_sync_device(self):
        self.assertIsNotNone(self._resolve("force_sync_device", pk=1))

    def test_force_sync_vm(self):
        self.assertIsNotNone(self._resolve("force_sync_vm", pk=1))

    def test_setup_wizard_step1(self):
        self.assertIsNotNone(self._resolve("setup_wizard_step1"))

    def test_setup_wizard_step2(self):
        self.assertIsNotNone(self._resolve("setup_wizard_step2"))

    def test_setup_wizard_step3(self):
        self.assertIsNotNone(self._resolve("setup_wizard_step3"))

    def test_bootstrap(self):
        self.assertIsNotNone(self._resolve("bootstrap"))

    def test_api_runner_list(self):
        url = reverse("plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-list")
        self.assertIsNotNone(url)

    def test_api_runner_detail(self):
        url = reverse(
            "plugins-api:netbox_zabbix_sync_plugin-api:synchronizationrunner-detail",
            args=[self.runner.pk],
        )
        self.assertIsNotNone(url)

    def test_invalid_url_raises(self):
        with self.assertRaises(NoReverseMatch):
            reverse("plugins:netbox_zabbix_sync_plugin:nonexistent_view")
