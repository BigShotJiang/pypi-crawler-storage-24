"""
View tests for NetBox Zabbix Sync Plugin.

Tests that key views return expected status codes and use correct templates.
"""

from django.test import TestCase
from django.urls import reverse
from users.models import User

from netbox_zabbix_sync_plugin.models import SynchronizationRunner


class ViewTestBase(TestCase):
    """Base class with authenticated superuser."""

    @classmethod
    def setUpTestData(cls):
        cls.user = User.objects.create_superuser(username="testadmin", password="testpass123")
        cls.runner = SynchronizationRunner.objects.create(
            name="View Test Runner",
            description="Runner for view tests",
            url="http://webserver.example.com:8007",
            token="test-token",
        )

    def setUp(self):
        self.client.login(username="testadmin", password="testpass123")


class RunnerListViewTest(ViewTestBase):
    """Tests for the runner list view."""

    def test_list_view_status(self):
        url = reverse("plugins:netbox_zabbix_sync_plugin:synchronizationrunner_list")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_list_view_contains_runner(self):
        url = reverse("plugins:netbox_zabbix_sync_plugin:synchronizationrunner_list")
        response = self.client.get(url)
        self.assertContains(response, "View Test Runner")


class RunnerDetailViewTest(ViewTestBase):
    """Tests for the runner detail view."""

    def test_detail_view_status(self):
        url = reverse(
            "plugins:netbox_zabbix_sync_plugin:synchronizationrunner",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_detail_view_contains_name(self):
        url = reverse(
            "plugins:netbox_zabbix_sync_plugin:synchronizationrunner",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertContains(response, "View Test Runner")

    def test_detail_view_does_not_expose_token(self):
        url = reverse(
            "plugins:netbox_zabbix_sync_plugin:synchronizationrunner",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertNotContains(response, "test-token")


class RunnerEditViewTest(ViewTestBase):
    """Tests for the runner add/edit views."""

    def test_add_view_status(self):
        url = reverse("plugins:netbox_zabbix_sync_plugin:synchronizationrunner_add")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_edit_view_status(self):
        url = reverse(
            "plugins:netbox_zabbix_sync_plugin:synchronizationrunner_edit",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)

    def test_create_runner(self):
        url = reverse("plugins:netbox_zabbix_sync_plugin:synchronizationrunner_add")
        data = {
            "name": "New Runner",
            "description": "Created via test",
            "mode": "remote",
            "url": "http://new-runner.example.com:8007",
            "token": "new-token",
            "tags": [],
        }
        response = self.client.post(url, data)
        self.assertEqual(response.status_code, 302)
        self.assertTrue(SynchronizationRunner.objects.filter(name="New Runner").exists())


class RunnerDeleteViewTest(ViewTestBase):
    """Tests for the runner delete view."""

    def test_delete_view_status(self):
        url = reverse(
            "plugins:netbox_zabbix_sync_plugin:synchronizationrunner_delete",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)


class BootstrapViewTest(ViewTestBase):
    """Tests for the bootstrap view."""

    def test_bootstrap_get(self):
        url = reverse("plugins:netbox_zabbix_sync_plugin:bootstrap")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)


class ScheduleSynchronizationViewTest(ViewTestBase):
    """Tests for the schedule synchronization view."""

    def test_schedule_sync_get(self):
        url = reverse("plugins:netbox_zabbix_sync_plugin:schedule_synchronization")
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)


class SyncScheduleViewTest(ViewTestBase):
    """Tests for the sync schedule management view."""

    def test_sync_schedule_get(self):
        url = reverse(
            "plugins:netbox_zabbix_sync_plugin:sync_schedule",
            args=[self.runner.pk],
        )
        response = self.client.get(url)
        self.assertEqual(response.status_code, 200)
