"""
Model tests for SynchronizationRunner.
"""

from django.test import TestCase

from netbox_zabbix_sync_plugin.models import SynchronizationRunner


class SynchronizationRunnerModelTest(TestCase):
    """Tests for the SynchronizationRunner model."""

    @classmethod
    def setUpTestData(cls):
        cls.runner = SynchronizationRunner.objects.create(
            name="Test Runner",
            description="A test runner",
            url="http://webserver.example.com:8007",
            token="test-token-value",
        )

    def test_str(self):
        self.assertEqual(str(self.runner), "Test Runner")

    def test_get_absolute_url(self):
        url = self.runner.get_absolute_url()
        self.assertEqual(url, f"/plugins/netbox-zabbix-sync/runners/{self.runner.pk}/")

    def test_unique_name(self):
        from django.db import IntegrityError

        with self.assertRaises(IntegrityError):
            SynchronizationRunner.objects.create(name="Test Runner")

    def test_blank_optional_fields(self):
        runner = SynchronizationRunner.objects.create(name="Minimal Runner")
        self.assertEqual(runner.description, "")
        self.assertEqual(runner.url, "")
        self.assertEqual(runner.token, "")

    def test_serialize_object_masks_token(self):
        data = self.runner.serialize_object()
        self.assertEqual(data["token"], "********")

    def test_serialize_object_empty_token(self):
        runner = SynchronizationRunner.objects.create(name="No Token Runner")
        data = runner.serialize_object()
        self.assertEqual(data["token"], "")

    def test_ordering(self):
        SynchronizationRunner.objects.create(name="Alpha Runner")
        SynchronizationRunner.objects.create(name="Zulu Runner")
        runners = list(SynchronizationRunner.objects.values_list("name", flat=True))
        self.assertEqual(runners, sorted(runners))
