"""
Custom logging handler that captures sync library output into a SyncLog record.

Attaches to the `netbox_zabbix_sync` logger (and root logger as fallback)
during a background sync thread, buffering log lines and periodically
flushing them to the database.
"""

import logging


class SyncLogDBHandler(logging.Handler):
    """Logging handler that appends formatted records to a SyncLog.output field.

    Buffers lines in memory and flushes to the DB every `flush_interval` records
    to avoid excessive writes.
    """

    def __init__(self, sync_log_id: int, flush_interval: int = 5):
        super().__init__()
        self.sync_log_id = sync_log_id
        self.flush_interval = flush_interval
        self._buffer: list[str] = []
        self._count = 0
        self.setFormatter(logging.Formatter("%(asctime)s %(levelname)-8s %(message)s", datefmt="%H:%M:%S"))

    def emit(self, record: logging.LogRecord) -> None:
        try:
            msg = self.format(record)
            self._buffer.append(msg)
            self._count += 1
            if self._count >= self.flush_interval:
                self.flush()
        except Exception:
            self.handleError(record)

    def flush(self) -> None:
        """Write buffered lines to the SyncLog record."""
        if not self._buffer:
            return
        try:
            # Import here to avoid circular imports at module level
            from ..models.sync_log import SyncLog

            chunk = "\n".join(self._buffer) + "\n"
            self._buffer.clear()
            self._count = 0

            # Use F() + Value concatenation to avoid race conditions
            from django.db.models import Value
            from django.db.models.functions import Concat

            SyncLog.objects.filter(pk=self.sync_log_id).update(output=Concat("output", Value(chunk)))
        except Exception:
            # If DB write fails, don't crash the sync — just lose the log lines
            self._buffer.clear()
            self._count = 0
