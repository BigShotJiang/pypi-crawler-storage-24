"""
Zabbix API client with lazy-init caching.

Connects to Zabbix using credentials from the first runner's ConnectConfig
model (local mode) or fetched from the webserver via HMACClient (remote mode).
The authenticated session is cached with a TTL to avoid re-authenticating on
every page load. If no runner exists or credentials are unavailable, all
methods return empty results with an error flag.
"""

import logging
import threading
import time
from datetime import UTC, datetime

from zabbix_utils import APIRequestError, ProcessingError, ZabbixAPI

from .hmac_client import HMACClient

logger = logging.getLogger(__name__)

# Cache TTL in seconds
_CACHE_TTL = 300  # 5 minutes

# Module-level cache (shared across requests within the same process)
_cache_lock = threading.Lock()
_cached_zapi: ZabbixAPI | None = None
_cached_at: float = 0.0


def _is_cache_valid() -> bool:
    return _cached_zapi is not None and (time.time() - _cached_at) < _CACHE_TTL


def _invalidate_cache() -> None:
    global _cached_zapi, _cached_at
    try:
        if _cached_zapi is not None:
            # Only logout user/password sessions. Token-based sessions must
            # NOT call logout() — that would revoke the API token on the
            # Zabbix server, which is destructive.
            if not getattr(_cached_zapi, "_ZabbixAPI__use_token", False):
                _cached_zapi.logout()
    except Exception:
        pass
    _cached_zapi = None
    _cached_at = 0.0


def _get_zabbix_api() -> ZabbixAPI | None:
    """Get or create a cached ZabbixAPI session.

    Fetches connection config from the runner's ConnectConfig model (local mode)
    or from the webserver via HMACClient (remote mode). The authenticated session
    is cached with a TTL.
    Returns None if no runner exists or connection fails.
    """
    global _cached_zapi, _cached_at

    with _cache_lock:
        if _is_cache_valid():
            return _cached_zapi

        # Import here to avoid circular imports at module level
        from ..models import SynchronizationRunner
        from ..models.synchronization_runner import RunnerMode

        runner = SynchronizationRunner.objects.first()
        if not runner:
            logger.debug("No runner configured — cannot connect to Zabbix")
            return None

        if runner.mode == RunnerMode.LOCAL:
            # Read credentials directly from the ConnectConfig model
            try:
                cc = runner.connect_config
                config = {
                    "zabbix_url": cc.zabbix_url,
                    "zabbix_user": cc.zabbix_user,
                    "zabbix_password": cc.zabbix_password,
                    "zabbix_token": cc.zabbix_token,
                }
            except Exception:
                logger.warning("Could not read connect config for local runner '%s'", runner.name)
                return None
        else:
            # Remote mode: fetch from webserver via HMACClient (existing behavior)
            if not runner.url or not runner.token:
                logger.debug("No runner URL/token configured — cannot connect to Zabbix")
                return None

            try:
                client = HMACClient(runner.url, runner.token)
                response = client.get("/connect_config?include_secrets=true")
                config = response.get("config", {})
            except Exception:
                logger.warning("Could not fetch connect config from runner '%s'", runner.name)
                return None

        zbx_url = config.get("zabbix_url")
        if not zbx_url:
            logger.warning("No zabbix_url in connect config")
            return None

        zbx_token = config.get("zabbix_token")
        zbx_user = config.get("zabbix_user")
        zbx_pass = config.get("zabbix_password")

        try:
            if zbx_token:
                zapi = ZabbixAPI(zbx_url, token=zbx_token)
            elif zbx_user and zbx_pass:
                zapi = ZabbixAPI(zbx_url, user=zbx_user, password=zbx_pass)
            else:
                logger.warning("No Zabbix credentials in connect config")
                return None

            zapi.check_auth()
            _cached_zapi = zapi
            _cached_at = time.time()
            logger.info("Zabbix API session cached (version %s)", zapi.version)
            return _cached_zapi
        except (APIRequestError, ProcessingError) as e:
            logger.error("Zabbix API auth failed: %s", e)
            return None
        except Exception:
            logger.exception("Unexpected error connecting to Zabbix")
            return None


def get_host_maintenance(hostid: str) -> dict:
    """Get maintenance status for a Zabbix host.

    Returns dict with keys:
        - in_maintenance (bool)
        - maintenance_name (str or None)
        - maintenance_until (int timestamp or None)
        - error (str or None)
    """
    zapi = _get_zabbix_api()
    if zapi is None:
        return {
            "in_maintenance": False,
            "maintenance_name": None,
            "maintenance_until": None,
            "error": "Zabbix unavailable",
        }

    try:
        hosts = zapi.host.get(
            hostids=hostid,
            output=["hostid", "maintenance_status", "maintenance_type", "maintenanceid"],
        )
        if not hosts:
            return {
                "in_maintenance": False,
                "maintenance_name": None,
                "maintenance_until": None,
                "error": "Host not found in Zabbix",
            }

        host = hosts[0]
        in_maintenance = str(host.get("maintenance_status")) == "1"

        maintenance_name = None
        maintenance_until = None
        if in_maintenance and host.get("maintenanceid") and host["maintenanceid"] != "0":
            try:
                maintenances = zapi.maintenance.get(
                    maintenanceids=host["maintenanceid"],
                    output=["name", "active_till"],
                )
                if maintenances:
                    maintenance_name = maintenances[0].get("name")
                    till = int(maintenances[0].get("active_till", 0))
                    maintenance_until = datetime.fromtimestamp(till, tz=UTC) if till else None
            except Exception:
                logger.warning("Could not fetch maintenance details for host %s", hostid)

        return {
            "in_maintenance": in_maintenance,
            "maintenance_name": maintenance_name,
            "maintenance_until": maintenance_until,
            "error": None,
        }
    except Exception as e:
        logger.error("Error fetching maintenance for host %s: %s", hostid, e)
        return {"in_maintenance": False, "maintenance_name": None, "maintenance_until": None, "error": str(e)}


def get_host_problems(hostid: str) -> dict:
    """Get current open problems for a Zabbix host.

    Returns dict with keys:
        - problems (list of dicts with: eventid, name, severity, timestamp, acknowledged)
        - error (str or None)
    """
    zapi = _get_zabbix_api()
    if zapi is None:
        return {"problems": [], "error": "Zabbix unavailable"}

    severity_map = {
        "0": "Not classified",
        "1": "Information",
        "2": "Warning",
        "3": "Average",
        "4": "High",
        "5": "Disaster",
    }

    try:
        problems = zapi.problem.get(
            hostids=hostid,
            output=["eventid", "name", "severity", "clock", "acknowledged"],
            recent=True,
            sortfield="eventid",
            sortorder="DESC",
        )

        result = []
        for p in problems:
            clock = int(p.get("clock", 0))
            result.append(
                {
                    "eventid": p.get("eventid"),
                    "name": p.get("name", ""),
                    "severity": severity_map.get(str(p.get("severity", "0")), "Unknown"),
                    "severity_num": int(p.get("severity", 0)),
                    "timestamp": datetime.fromtimestamp(clock, tz=UTC) if clock else None,
                    "acknowledged": str(p.get("acknowledged")) == "1",
                }
            )

        return {"problems": result, "error": None}
    except Exception as e:
        logger.error("Error fetching problems for host %s: %s", hostid, e)
        return {"problems": [], "error": str(e)}
