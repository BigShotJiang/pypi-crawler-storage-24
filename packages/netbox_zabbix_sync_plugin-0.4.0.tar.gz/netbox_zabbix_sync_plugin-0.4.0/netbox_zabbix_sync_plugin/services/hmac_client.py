"""HMAC-SHA256 authenticated HTTP client for webserver communication."""

import hashlib
import hmac
import logging
import time
import uuid
from typing import NoReturn

import requests

from . import WebserverError

logger = logging.getLogger(__name__)


class HMACClient:
    """Authenticated HTTP client for webserver communication.

    Signs every request with HMAC-SHA256 using the configured token.
    Translates HTTP errors into structured WebserverError exceptions.
    """

    def __init__(self, base_url: str, token: str, timeout: int = 10):
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.timeout = timeout

    def _sign_request(self, body: str) -> dict[str, str]:
        """Generate HMAC-SHA256 signature headers.

        Returns dict with X-Signature, X-Timestamp, and X-Event-ID headers.
        """
        timestamp = str(int(time.time()))
        event_id = str(uuid.uuid4())
        message = f"{timestamp}.{body}"
        signature = hmac.new(self.token.encode(), message.encode(), hashlib.sha256).hexdigest()
        return {
            "X-Signature": signature,
            "X-Timestamp": timestamp,
            "X-Event-ID": event_id,
        }

    def _request(self, method: str, path: str, data: dict | None = None) -> dict:
        """Execute an authenticated request and handle errors."""
        url = f"{self.base_url}{path}"
        body = ""
        kwargs: dict = {"timeout": self.timeout}

        if data is not None:
            import json

            body = json.dumps(data)
            kwargs["json"] = data

        headers = self._sign_request(body)
        kwargs["headers"] = headers

        try:
            response = requests.request(method, url, **kwargs)
        except requests.ConnectionError as err:
            msg = f"Unable to reach the webserver at {url}. Verify the URL is correct and the service is running."
            logger.error("Webserver request failed: %s %s → HTTP %d: %s", method, url, 0, msg)
            raise WebserverError(0, msg) from err
        except requests.Timeout as err:
            msg = f"The webserver did not respond within {self.timeout} seconds. Check network connectivity and server health."
            logger.error("Webserver request failed: %s %s → HTTP %d: %s", method, url, 0, msg)
            raise WebserverError(0, msg) from err

        if response.ok:
            try:
                return response.json()
            except ValueError:
                return {}

        self._handle_error(method, url, response)

    def _handle_error(self, method: str, url: str, response: requests.Response) -> NoReturn:
        """Translate HTTP error responses into WebserverError."""
        status: int = response.status_code  # type: ignore[assignment]
        try:
            details = response.json()
        except ValueError:
            details = {"raw": response.text}

        if status in (401, 403):
            msg = "Authentication failed. Verify the HMAC token matches the webserver configuration."
        elif status == 400:
            msg = "Validation error from the webserver."
        elif status >= 500:
            msg = f"The webserver encountered an internal error (HTTP {status}). Details: {response.text}"
        else:
            msg = f"Unexpected error from the webserver (HTTP {status})."

        logger.error("Webserver request failed: %s %s → HTTP %d: %s", method, url, status, msg)
        raise WebserverError(status, msg, details)

    def get(self, path: str) -> dict:
        """Authenticated GET request."""
        return self._request("GET", path)

    def post(self, path: str, data: dict) -> dict:
        """Authenticated POST request."""
        return self._request("POST", path, data)

    def patch(self, path: str, data: dict) -> dict:
        """Authenticated PATCH request."""
        return self._request("PATCH", path, data)

    def delete(self, path: str) -> dict:
        """Authenticated DELETE request."""
        return self._request("DELETE", path)

    def health_check(self) -> bool:
        """GET / to verify connectivity. Returns True on success."""
        self._request("GET", "/")
        return True
