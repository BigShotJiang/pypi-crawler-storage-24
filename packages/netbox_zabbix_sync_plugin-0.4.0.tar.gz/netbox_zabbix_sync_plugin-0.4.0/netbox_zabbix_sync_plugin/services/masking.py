"""Utility functions for masking sensitive field values."""

# Fields that should be masked in display and excluded from API responses
SENSITIVE_FIELDS = {"netbox_token", "zabbix_password", "zabbix_token"}


def mask_value(value: str) -> str:
    """Fully mask a sensitive value — never reveal any characters."""
    if not value:
        return ""
    return "********"
