"""Backend factory for selecting the correct sync backend based on runner mode."""

from ..models import SynchronizationRunner
from .local_backend import LocalBackend
from .remote_backend import RemoteBackend
from .sync_backend import SyncBackend


def get_backend(runner: SynchronizationRunner) -> SyncBackend:
    """Return the appropriate backend for the given runner's mode.

    The netbox-zabbix-sync library is only required for trigger_sync();
    config read/write operations work without it.  The import check is
    therefore deferred to LocalBackend.trigger_sync() and health_check().
    """
    if runner.mode == "local":
        return LocalBackend(runner)
    return RemoteBackend(runner.url, runner.token)
