"""LocalBackend reads/writes ConnectConfig and SyncConfig models directly.

Invokes the netbox-zabbix-sync library for trigger_sync.
"""

import logging
from typing import Any

logger = logging.getLogger(__name__)


class LocalBackend:
    """Reads/writes ConnectConfig and SyncConfig models directly.
    Invokes the sync library for trigger_sync."""

    def __init__(self, runner):
        self.runner = runner

    def get_connect_config(self) -> dict[str, Any]:
        cc = self.runner.connect_config
        return {
            "netbox_url": cc.netbox_url,
            "netbox_token": cc.netbox_token,
            "zabbix_url": cc.zabbix_url,
            "zabbix_user": cc.zabbix_user,
            "zabbix_password": cc.zabbix_password,
            "zabbix_token": cc.zabbix_token,
        }

    def get_connect_config_display(self) -> dict[str, Any]:
        """Return config with sensitive fields masked for display."""
        from .masking import SENSITIVE_FIELDS, mask_value

        config = self.get_connect_config()
        return {k: mask_value(str(v)) if k in SENSITIVE_FIELDS and v else v for k, v in config.items()}

    def patch_connect_config(self, data: dict[str, Any]) -> None:
        cc = self.runner.connect_config
        for key, value in data.items():
            if hasattr(cc, key):
                setattr(cc, key, value)
        cc.save()

    def get_sync_config(self) -> dict[str, Any]:
        sc = self.runner.sync_config
        return sc.config

    def patch_sync_config(self, data: dict[str, Any]) -> None:
        sc = self.runner.sync_config
        config_data = data.get("config", data)
        sc.config.update(config_data)
        sc.save()

    def delete_sync_config_key(self, key: str) -> None:
        sc = self.runner.sync_config
        sc.config.pop(key, None)
        sc.save()

    def trigger_sync(self, payload: dict[str, Any], *, background: bool = True) -> dict[str, Any]:
        """Invoke the netbox-zabbix-sync library.

        Uses the public API: Sync(config).connect(...).start()
        The payload may contain filter keys like device_filter or vm_filter.

        Creates a SyncLog record and attaches a logging handler to capture
        the sync library's output.

        Args:
            payload: Sync parameters (filters, log_level, etc.)
            background: If True (default), run in a daemon thread so the HTTP
                response returns immediately. If False, run synchronously
                (suitable for background job workers).
        """
        import json
        import threading

        from ..models.sync_log import SyncLog

        cc = self.runner.connect_config
        sc = self.runner.sync_config
        config = dict(sc.config)

        config = self._deserialize_config(config)

        # Merge config-level default filters into the config dict
        for key in ("nb_device_filter", "nb_vm_filter"):
            if key in payload:
                val = payload[key]
                if isinstance(val, str):
                    try:
                        val = json.loads(val)
                    except (json.JSONDecodeError, ValueError):
                        pass
                config[key] = val

        # Extract per-request filters — these are passed as arguments to start()
        device_filter = payload.get("device_filter")
        vm_filter = payload.get("vm_filter")
        if isinstance(device_filter, str):
            try:
                device_filter = json.loads(device_filter)
            except (json.JSONDecodeError, ValueError):
                pass
        if isinstance(vm_filter, str):
            try:
                vm_filter = json.loads(vm_filter)
            except (json.JSONDecodeError, ValueError):
                pass

        # Capture connection details
        nb_host = cc.netbox_url
        nb_token = cc.netbox_token
        zbx_host = cc.zabbix_url
        zbx_user = cc.zabbix_user or ""
        zbx_pass = cc.zabbix_password or ""
        zbx_token = cc.zabbix_token or ""

        log_level_name = payload.pop("log_level", "WARNING")
        log_level = getattr(logging, log_level_name, logging.INFO)

        # Log the sync parameters for debugging
        logger.info(
            "Preparing sync for runner '%s': nb_host=%s, zbx_host=%s, "
            "device_filter=%s, vm_filter=%s, log_level=%s, background=%s",
            self.runner.name,
            nb_host,
            zbx_host,
            device_filter,
            vm_filter,
            log_level_name,
            background,
        )
        logger.debug(
            "Sync config keys for runner '%s': %s",
            self.runner.name,
            list(config.keys()),
        )

        # Create the SyncLog record up front so the view can redirect to it
        sync_log = SyncLog.objects.create(runner=self.runner, log_level=log_level_name)

        # Prune old logs — retention count is configurable via plugin settings
        from django.conf import settings

        retention = (
            getattr(settings, "PLUGINS_CONFIG", {}).get("netbox_zabbix_sync_plugin", {}).get("sync_log_retention", 100)
        )
        old_ids = (
            SyncLog.objects.filter(runner=self.runner).order_by("-started").values_list("pk", flat=True)[retention:]
        )
        if old_ids:
            SyncLog.objects.filter(pk__in=list(old_ids)).delete()

        sync_context = {
            "config": config,
            "nb_host": nb_host,
            "nb_token": nb_token,
            "zbx_host": zbx_host,
            "zbx_user": zbx_user,
            "zbx_pass": zbx_pass,
            "zbx_token": zbx_token,
            "device_filter": device_filter,
            "vm_filter": vm_filter,
            "log_level": log_level,
            "sync_log_pk": sync_log.pk,
            "runner_name": self.runner.name,
        }

        if background:
            thread = threading.Thread(
                target=self._execute_sync,
                args=(sync_context,),
                daemon=True,
                name=f"sync-{self.runner.pk}",
            )
            thread.start()
        else:
            self._execute_sync(sync_context)

        return {"sync_log_id": sync_log.pk}

    @staticmethod
    def _execute_sync(ctx: dict) -> None:
        """Run the sync library. Called from a thread or directly."""
        from django.utils import timezone
        from netbox_zabbix_sync import Sync

        from ..models.sync_log import SyncLog, SyncLogStatus
        from .sync_log_handler import SyncLogDBHandler

        sync_log_pk = ctx["sync_log_pk"]
        runner_name = ctx["runner_name"]
        log_level = ctx["log_level"]

        sync_logger = logging.getLogger("NetBox-Zabbix-sync")
        prev_level = sync_logger.level
        sync_logger.setLevel(log_level)
        handler = SyncLogDBHandler(sync_log_pk)
        handler.setLevel(log_level)
        sync_logger.addHandler(handler)
        try:
            logger.info("Runner '%s': Creating Sync instance...", runner_name)
            sync = Sync(ctx["config"])

            logger.info(
                "Runner '%s': Connecting to NetBox (%s) and Zabbix (%s)...",
                runner_name,
                ctx["nb_host"],
                ctx["zbx_host"],
            )
            connected = sync.connect(
                nb_host=ctx["nb_host"],
                nb_token=ctx["nb_token"],
                zbx_host=ctx["zbx_host"],
                zbx_user=ctx["zbx_user"],
                zbx_pass=ctx["zbx_pass"],
                zbx_token=ctx["zbx_token"],
            )
            if not connected:
                logger.error(
                    "Runner '%s': connect() returned False — check NetBox URL (%s) "
                    "and Zabbix URL (%s). Is NetBox reachable from the worker process?",
                    runner_name,
                    ctx["nb_host"],
                    ctx["zbx_host"],
                )
                handler.flush()
                SyncLog.objects.filter(pk=sync_log_pk).update(
                    status=SyncLogStatus.FAILED,
                    finished=timezone.now(),
                )
                return

            logger.info(
                "Runner '%s': Connected. Starting sync (device_filter=%s, vm_filter=%s)...",
                runner_name,
                ctx["device_filter"],
                ctx["vm_filter"],
            )
            sync.start(device_filter=ctx["device_filter"], vm_filter=ctx["vm_filter"])
            handler.flush()
            SyncLog.objects.filter(pk=sync_log_pk).update(
                status=SyncLogStatus.COMPLETED,
                finished=timezone.now(),
            )
            logger.info("Runner '%s': Sync completed successfully.", runner_name)
        except Exception:
            handler.flush()
            logger.exception("Runner '%s': Sync failed with exception.", runner_name)
            SyncLog.objects.filter(pk=sync_log_pk).update(
                status=SyncLogStatus.FAILED,
                finished=timezone.now(),
            )
        finally:
            sync_logger.removeHandler(handler)
            sync_logger.setLevel(prev_level)

    @staticmethod
    def _deserialize_config(config: dict[str, Any]) -> dict[str, Any]:
        """Deserialize string values in the config to native Python types.

        The setup wizard stores all config values as strings. This method
        converts them back: "true"/"false" → bool, JSON strings → dict/list,
        numeric strings → int/float.
        """
        import json

        result = {}
        for key, val in config.items():
            if not isinstance(val, str):
                result[key] = val
                continue
            # Boolean strings
            if val.lower() == "true":
                result[key] = True
                continue
            if val.lower() == "false":
                result[key] = False
                continue
            # Try JSON (dicts, lists)
            if val.startswith(("{", "[")):
                try:
                    result[key] = json.loads(val)
                    continue
                except (json.JSONDecodeError, ValueError):
                    pass
            result[key] = val
        return result

    def health_check(self) -> bool:
        """Verify ConnectConfig exists for this runner."""
        return hasattr(self.runner, "connect_config")
