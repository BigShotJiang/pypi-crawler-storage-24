"""
SyncConfig model for NetBox Zabbix Sync Plugin.

Stores sync configuration key-value pairs locally for local-mode runners.
When saved with an empty config, automatically populates from the sync
library's DEFAULT_CONFIG.
"""

from django.db import models


class SyncConfig(models.Model):
    """
    Stores sync configuration for a local-mode SynchronizationRunner.

    One-to-one relationship with SynchronizationRunner. When the runner is
    deleted, this record is cascade-deleted.
    """

    runner = models.OneToOneField(
        "netbox_zabbix_sync_plugin.SynchronizationRunner",
        on_delete=models.CASCADE,
        related_name="sync_config",
    )
    config = models.JSONField(
        default=dict,
        help_text="Sync configuration key-value pairs",
    )

    class Meta:
        app_label = "netbox_zabbix_sync_plugin"
        verbose_name = "Sync Configuration"

    def __str__(self) -> str:
        return f"SyncConfig for {self.runner}"

    def save(self, *args, **kwargs):
        if not self.config:
            from netbox_zabbix_sync.modules.settings import DEFAULT_CONFIG

            self.config = dict(DEFAULT_CONFIG)
        super().save(*args, **kwargs)
