# -*- coding: utf-8 -*-
"""
Created on Thu Jan 30 13:27:29 2020
@author: dgc
"""



import sys
import warnings
from importlib.metadata import version, PackageNotFoundError

from . import constants
from . import instrument
from .crystal import Lattice
from .crystal import Material
from .crystal import Sample
from .crystal import SpaceGroup
from .energy import Energy
from .instrument import TripleAxisSpectr, TimeOfFlightSpectr, tools
from .insfit import FitConv, UltraFastFitConv
try:
    from .gui.main_gui import main
except ImportError:
    warnings.warn('QtPy not found, cannot run Resolution GUI.')

try:
    __version__ = version("inspy-conv")   # matches name in pyproject.toml
except PackageNotFoundError:
    __version__ = "unknown"

if sys.version_info[:2] == (2, 6) or sys.version_info[:2] == (3, 3):
    warnings.warn('Support for Python 2.6 and Python 3.3 is depreciated and will be dropped in inspy 0.2.7', DeprecationWarning)
