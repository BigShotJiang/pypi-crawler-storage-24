"""Tests for ApprovalAdmin (via Primitif)."""

import pytest
import respx
import httpx

from primitif import Primitif, AuthError
from primitif.approval import (
    ApprovalError,
    ApprovalAuthError,
    ApprovalRequest,
)


APPROVAL = "https://api.approval.primitif.ai"


@respx.mock
def test_create_request():
    respx.post(f"{APPROVAL}/v1/requests").mock(
        return_value=httpx.Response(200, json={
            "id": "ar_abc", "action": "Send contract",
            "context": {"amount": 45000}, "status": "pending",
            "approval_url": "https://dash.primitif.ai/approve/ar_abc",
            "created_at": "2025-01-01T00:00:00Z",
        })
    )
    p = Primitif(api_key="pk_live_test12345678901234567890123456")
    req = p.approval.create_request(
        action="Send contract",
        context={"amount": 45000},
    )
    assert isinstance(req, ApprovalRequest)
    assert req.status == "pending"
    assert req.id == "ar_abc"
    p.close()


@respx.mock
def test_create_request_with_callback():
    respx.post(f"{APPROVAL}/v1/requests").mock(
        return_value=httpx.Response(200, json={
            "id": "ar_def", "action": "Delete account",
            "status": "pending",
            "approval_url": "https://dash.primitif.ai/approve/ar_def",
            "created_at": "2025-01-01T00:00:00Z",
        })
    )
    p = Primitif(api_key="pk_live_test12345678901234567890123456")
    req = p.approval.create_request(
        action="Delete account",
        callback_url="https://myapp.com/webhook",
        requested_by="agent-007",
    )
    assert req.id == "ar_def"
    p.close()


@respx.mock
def test_get_request():
    respx.get(f"{APPROVAL}/v1/requests/ar_abc").mock(
        return_value=httpx.Response(200, json={
            "id": "ar_abc", "action": "Send contract",
            "status": "approved",
            "approval_url": "https://dash.primitif.ai/approve/ar_abc",
            "created_at": "2025-01-01T00:00:00Z",
        })
    )
    p = Primitif(api_key="pk_live_test12345678901234567890123456")
    req = p.approval.get_request("ar_abc")
    assert req.status == "approved"
    p.close()


@respx.mock
def test_list_requests():
    respx.get(f"{APPROVAL}/v1/requests").mock(
        return_value=httpx.Response(200, json={
            "data": [
                {"id": "ar_1", "action": "A", "status": "pending",
                 "approval_url": "https://x", "created_at": "2025-01-01T00:00:00Z"},
                {"id": "ar_2", "action": "B", "status": "approved",
                 "approval_url": "https://x", "created_at": "2025-01-01T00:00:00Z"},
            ]
        })
    )
    p = Primitif(api_key="pk_live_test12345678901234567890123456")
    requests = p.approval.list_requests()
    assert len(requests) == 2
    assert requests[0].id == "ar_1"
    p.close()


@respx.mock
def test_list_requests_items_key():
    """list_requests handles both 'items' and 'data' keys."""
    respx.get(f"{APPROVAL}/v1/requests").mock(
        return_value=httpx.Response(200, json={
            "items": [
                {"id": "ar_1", "action": "A", "status": "pending",
                 "approval_url": "https://x", "created_at": "2025-01-01T00:00:00Z"},
            ]
        })
    )
    p = Primitif(api_key="pk_live_test12345678901234567890123456")
    requests = p.approval.list_requests()
    assert len(requests) == 1
    p.close()


@respx.mock
def test_401_raises_approval_auth_error():
    respx.post(f"{APPROVAL}/v1/requests").mock(
        return_value=httpx.Response(401, json={
            "detail": {"error": {"code": "unauthorized", "message": "Bad token"}}
        })
    )
    p = Primitif(api_key="pk_live_test12345678901234567890123456")
    with pytest.raises(ApprovalAuthError):
        p.approval.create_request(action="test")
    p.close()


def test_diamond_inheritance():
    """ApprovalAuthError is catchable as both ApprovalError and AuthError."""
    err = ApprovalAuthError(message="test", status_code=401)
    assert isinstance(err, ApprovalError)
    assert isinstance(err, AuthError)


@respx.mock
def test_primitif_context_manager():
    respx.post(f"{APPROVAL}/v1/requests").mock(
        return_value=httpx.Response(200, json={
            "id": "ar_abc", "action": "test", "status": "pending",
            "approval_url": "https://x", "created_at": "2025-01-01T00:00:00Z",
        })
    )
    with Primitif(api_key="pk_live_test12345678901234567890123456") as p:
        req = p.approval.create_request(action="test")
        assert req.id == "ar_abc"


def test_empty_api_key_raises():
    from primitif._exceptions import PrimitifError
    with pytest.raises(PrimitifError, match="No API key"):
        Primitif(api_key="")


def test_whitespace_api_key_raises():
    from primitif._exceptions import PrimitifError
    with pytest.raises(PrimitifError, match="No API key"):
        Primitif(api_key="   ")
