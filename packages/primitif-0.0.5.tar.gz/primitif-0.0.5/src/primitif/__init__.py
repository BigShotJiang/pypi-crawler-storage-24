"""Primitif Python SDK — Mail and Approval APIs for AI agents."""

from primitif._models import PaginatedList
from primitif._version import __version__
from primitif._exceptions import (
    PrimitifError,
    AuthError,
    NotFoundError,
    ConflictError,
    ValidationError,
    RateLimitError,
    ServerError,
    NetworkError,
    InvalidSignature,
)
from primitif._webhook import verify_webhook
from primitif.client import Primitif
from primitif.mail.client import Mailbox

__all__ = [
    "__version__",
    "Primitif",
    "Mailbox",
    "PaginatedList",
    "verify_webhook",
    "PrimitifError",
    "AuthError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    "NetworkError",
    "InvalidSignature",
]
