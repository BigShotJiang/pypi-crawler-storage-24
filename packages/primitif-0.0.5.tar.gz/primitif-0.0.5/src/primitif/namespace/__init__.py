"""Namespace management — create, list, and delete namespaces."""
