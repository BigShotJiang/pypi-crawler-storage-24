"""Namespace-specific exceptions with diamond inheritance."""

from primitif._exceptions import (
    AuthError,
    NetworkError,
    NotFoundError,
    PrimitifError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class NamespaceError(PrimitifError):
    """Base exception for all Namespace errors."""


class NamespaceAuthError(NamespaceError, AuthError):
    """401 — invalid or missing credentials."""


class NamespaceNotFoundError(NamespaceError, NotFoundError):
    """404 — namespace not found."""


class NamespaceValidationError(NamespaceError, ValidationError):
    """422 — invalid namespace request payload."""


class NamespaceLimitError(NamespaceError):
    """403 — namespace limit reached for current plan."""


class NamespaceRateLimitError(NamespaceError, RateLimitError):
    """429 — rate limit exceeded."""


class NamespaceServerError(NamespaceError, ServerError):
    """5xx — server error."""


class NamespaceNetworkError(NamespaceError, NetworkError):
    """Network-level failure during a namespace request."""
