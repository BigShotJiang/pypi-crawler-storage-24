"""Mail SDK response types."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel


class MailboxInfo(BaseModel):
    id: str
    address: str
    name: str
    expires_at: datetime | None = None
    created_at: datetime | None = None


class MailboxListItem(BaseModel):
    id: str
    address: str
    name: str
    expires_at: datetime | None = None
    created_at: datetime | None = None
    received_count: int = 0
    sent_count: int = 0


class InboxMessage(BaseModel):
    id: str
    thread_id: str
    from_address: str
    subject: str
    snippet: str
    is_read: bool
    created_at: datetime
    auth_summary: str | None = None


class MessageDetail(BaseModel):
    id: str
    thread_id: str
    from_address: str
    to_address: str | None = None
    subject: str
    direction: Literal["inbound", "outbound"]
    is_read: bool
    created_at: datetime
    body_text: str | None = None
    body_html: str | None = None
    spf: str | None = None
    dkim: str | None = None
    dmarc: str | None = None
    auth_summary: str | None = None


class ThreadSummary(BaseModel):
    id: str
    subject: str
    message_count: int
    last_message_at: datetime
    created_at: datetime


class ThreadDetail(BaseModel):
    id: str
    subject: str
    message_count: int
    last_message_at: datetime
    created_at: datetime
    messages: list[MessageDetail] = []


class SendResult(BaseModel):
    thread_id: str
    message_id: str | None = None
    status: Literal["sent", "held", "pending_approval"] = "sent"
    held_email_id: str | None = None
    approval_url: str | None = None


class ProtectedRecipient(BaseModel):
    id: str
    pattern: str
    pattern_type: str
    created_at: datetime


class AttachmentInfo(BaseModel):
    id: str
    filename: str
    content_type: str
    size_bytes: int
    created_at: datetime


class AllowlistEntry(BaseModel):
    id: str
    sender_address: str
    created_at: datetime


class WebhookCreated(BaseModel):
    id: str
    url: str
    secret: str
    events: list[str]
    created_at: datetime


class PlanLimits(BaseModel):
    max_mailboxes: int | None = None
    max_emails: int | None = None


class AccountInfo(BaseModel):
    id: str
    plan: str
    email_count: int = 0
    mailbox_count: int = 0
    limits: PlanLimits | None = None
    email: str | None = None


class WebhookInfo(BaseModel):
    id: str
    url: str
    events: list[str]
    created_at: datetime
