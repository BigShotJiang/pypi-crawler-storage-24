"""Mail-specific exceptions with diamond inheritance."""

from primitif._exceptions import (
    AuthError,
    ConflictError,
    NetworkError,
    NotFoundError,
    PrimitifError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class MailError(PrimitifError):
    """Base exception for all Mail errors."""


class MailAuthError(MailError, AuthError):
    """401 — invalid or missing mail credentials."""


class MailNotFoundError(MailError, NotFoundError):
    """404 — mail resource not found."""


class MailConflictError(MailError, ConflictError):
    """409 — mail resource conflict."""


class MailValidationError(MailError, ValidationError):
    """422 — invalid mail request payload."""


class MailRateLimitError(MailError, RateLimitError):
    """429 — mail rate limit exceeded."""


class MailServerError(MailError, ServerError):
    """5xx — mail server error."""


class MailNetworkError(MailError, NetworkError):
    """Network-level failure during a mail request."""
