"""Primitif Mail SDK."""

from primitif.mail.client import Mailbox, MailAdmin
from primitif.mail.exceptions import (
    MailAuthError,
    MailConflictError,
    MailNetworkError,
    MailError,
    MailNotFoundError,
    MailRateLimitError,
    MailServerError,
    MailValidationError,
)
from primitif._models import PaginatedList
from primitif.mail.models import (
    AccountInfo,
    AllowlistEntry,
    AttachmentInfo,
    InboxMessage,
    MailboxInfo,
    MailboxListItem,
    MessageDetail,
    PlanLimits,
    ProtectedRecipient,
    SendResult,
    ThreadDetail,
    ThreadSummary,
    WebhookCreated,
    WebhookInfo,
)

__all__ = [
    "Mailbox",
    "MailAdmin",
    "MailError",
    "MailAuthError",
    "MailNetworkError",
    "MailNotFoundError",
    "MailConflictError",
    "MailValidationError",
    "MailRateLimitError",
    "MailServerError",
    "AccountInfo",
    "AllowlistEntry",
    "AttachmentInfo",
    "InboxMessage",
    "MailboxInfo",
    "MailboxListItem",
    "MessageDetail",
    "PaginatedList",
    "PlanLimits",
    "ProtectedRecipient",
    "SendResult",
    "ThreadDetail",
    "ThreadSummary",
    "WebhookCreated",
    "WebhookInfo",
]
