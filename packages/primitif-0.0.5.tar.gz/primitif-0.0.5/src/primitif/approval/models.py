"""Approval SDK response types."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel


class ApprovalRequest(BaseModel):
    id: str
    action: str
    context: dict[str, Any] | None = None
    status: Literal["pending", "approved", "rejected", "expired"]
    approval_url: str
    requested_by: str | None = None
    created_at: datetime
    expires_at: datetime | None = None
