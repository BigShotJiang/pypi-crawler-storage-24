"""Approval — human-in-the-loop gate for AI agents."""

from __future__ import annotations

from typing import Any, Literal

import httpx

from primitif._models import PaginatedList
from primitif._transport import (
    configure_logging,
    request_with_retries,
)
from primitif.approval.exceptions import (
    ApprovalAuthError,
    ApprovalNetworkError,
    ApprovalError,
    ApprovalNotFoundError,
    ApprovalRateLimitError,
    ApprovalServerError,
    ApprovalValidationError,
)
from primitif.approval.models import ApprovalRequest

logger = configure_logging("approval")

_EXC_MAP = {
    401: ApprovalAuthError,
    404: ApprovalNotFoundError,
    422: ApprovalValidationError,
    429: ApprovalRateLimitError,
}


class ApprovalAdmin:
    """Approval operations — create, check, and list approval requests.

    Not instantiated directly. Access via ``Primitif().approval``.
    """

    def __init__(self, client: httpx.Client, max_retries: int) -> None:
        self._client = client
        self._max_retries = max_retries

    def _request(self, method: str, path: str, **kwargs) -> dict:
        return request_with_retries(
            self._client,
            method,
            path,
            self._max_retries,
            exc_map=_EXC_MAP,
            server_exc=ApprovalServerError,
            base_exc=ApprovalError,
            connection_exc=ApprovalNetworkError,
            logger=logger,
            **kwargs,
        )

    def create_request(
        self,
        action: str,
        *,
        context: dict[str, Any] | None = None,
        callback_url: str | None = None,
        requested_by: str | None = None,
    ) -> ApprovalRequest:
        """Create an approval request. Returns immediately with a pending status.

        The agent moves on. No polling. No blocking.
        A webhook fires when a decision is made.
        """
        payload: dict[str, Any] = {"action": action}
        if context is not None:
            payload["context"] = context
        if callback_url is not None:
            payload["callback_url"] = callback_url
        if requested_by is not None:
            payload["requested_by"] = requested_by

        data = self._request("POST", "/v1/requests", json=payload)
        return ApprovalRequest(**data)

    def get_request(self, request_id: str) -> ApprovalRequest:
        """Get the current status of an approval request."""
        data = self._request("GET", f"/v1/requests/{request_id}")
        return ApprovalRequest(**data)

    def list_requests(
        self,
        *,
        status: Literal["pending", "approved", "rejected", "expired"] | None = None,
        limit: int = 20,
        cursor: str | None = None,
    ) -> PaginatedList[ApprovalRequest]:
        """List approval requests, optionally filtered by status."""
        params: dict[str, Any] = {"limit": limit}
        if status is not None:
            params["status"] = status
        if cursor is not None:
            params["cursor"] = cursor
        data = self._request("GET", "/v1/requests", params=params)
        raw = data.get("data", [])
        items = [ApprovalRequest(**r) for r in raw]
        next_cursor = data.get("next_cursor")
        result = PaginatedList(
            items=items, cursor=next_cursor, has_more=next_cursor is not None
        )
        result._fetch_fn = self.list_requests
        result._fetch_kwargs = {"status": status, "limit": limit}
        return result
