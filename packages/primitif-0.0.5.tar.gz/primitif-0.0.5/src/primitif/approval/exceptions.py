"""Approval-specific exceptions with diamond inheritance."""

from primitif._exceptions import (
    AuthError,
    NetworkError,
    NotFoundError,
    PrimitifError,
    RateLimitError,
    ServerError,
    ValidationError,
)


class ApprovalError(PrimitifError):
    """Base exception for all Approval errors."""


class ApprovalAuthError(ApprovalError, AuthError):
    """401 — invalid or missing approval credentials."""


class ApprovalNotFoundError(ApprovalError, NotFoundError):
    """404 — approval resource not found."""


class ApprovalValidationError(ApprovalError, ValidationError):
    """422 — invalid approval request payload."""


class ApprovalRateLimitError(ApprovalError, RateLimitError):
    """429 — approval rate limit exceeded."""


class ApprovalServerError(ApprovalError, ServerError):
    """5xx — approval server error."""


class ApprovalNetworkError(ApprovalError, NetworkError):
    """Network-level failure during an approval request."""
