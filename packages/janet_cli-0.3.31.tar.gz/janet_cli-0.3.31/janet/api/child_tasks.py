"""Child Task API methods."""

from typing import Dict, List, Optional

from janet.api.client import APIClient
from janet.config.manager import ConfigManager


class ChildTaskAPI(APIClient):
    """API methods for child task management."""

    def __init__(self, config_manager: ConfigManager):
        super().__init__(config_manager)

    def create_child_task(
        self,
        ticket_id: str,
        project_id: str,
        ticket_identifier: str,
        project_identifier: str,
        title: str,
        status: str,
        description: Optional[str] = None,
        priority: Optional[str] = None,
        assignee: Optional[str] = None,
        due_date: Optional[str] = None,
    ) -> Dict:
        """
        Create a new child task.

        Args:
            ticket_id: Parent ticket ID (UUID)
            project_id: Project ID (UUID)
            ticket_identifier: Parent ticket number (e.g., "123")
            project_identifier: Project key (e.g., "PROJ")
            title: Child task title
            description: Optional description
            status: Optional status
            priority: Optional priority (Low, Medium, High, Critical)
            assignee: Optional assignee email

        Returns:
            Created child task dictionary
        """
        payload: Dict = {
            "ticket_id": ticket_id,
            "project_id": project_id,
            "ticket_identifier": ticket_identifier,
            "project_identifier": project_identifier,
            "title": title,
            "status": status,
        }

        if description:
            payload["description"] = description
        if priority:
            payload["priority"] = priority
        if assignee:
            payload["assignee"] = assignee
        if due_date:
            payload["due_date"] = due_date

        response = self.post("/child-tasks/create", data=payload, include_org=True)
        return response

    def list_child_tasks(self, ticket_id: str) -> List[Dict]:
        """
        List all child tasks for a ticket.

        Args:
            ticket_id: Parent ticket ID (UUID)

        Returns:
            List of child task dictionaries
        """
        response = self.get(f"/child-tasks/{ticket_id}", include_org=True)
        return response if isinstance(response, list) else []

    def get_child_task(self, child_task_id: str) -> Dict:
        """
        Get a specific child task.

        Args:
            child_task_id: Child task ID (UUID)

        Returns:
            Child task dictionary
        """
        return self.get(f"/child-tasks/detail/{child_task_id}", include_org=True)

    def update_child_task(
        self,
        child_task_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        status: Optional[str] = None,
        priority: Optional[str] = None,
        assignee: Optional[str] = None,
        due_date: Optional[str] = None,
    ) -> Dict:
        """
        Update a child task.

        Args:
            child_task_id: Child task ID (UUID)
            title: New title
            description: New description
            status: New status
            priority: New priority
            assignee: New assignee email
            due_date: New due date (YYYY-MM-DD)

        Returns:
            Updated child task dictionary
        """
        payload: Dict = {}

        if title is not None:
            payload["title"] = title
        if description is not None:
            payload["description"] = description
        if status is not None:
            payload["status"] = status
        if priority is not None:
            payload["priority"] = priority
        if assignee is not None:
            payload["assignee"] = assignee
        if due_date is not None:
            payload["due_date"] = due_date

        if not payload:
            raise Exception("No fields to update")

        return self.put(f"/child-tasks/{child_task_id}", data=payload, include_org=True)

    def delete_child_task(self, child_task_id: str) -> Dict:
        """
        Delete (soft delete) a child task.

        Args:
            child_task_id: Child task ID (UUID)

        Returns:
            Success message dictionary
        """
        return self.delete(f"/child-tasks/{child_task_id}", include_org=True)
