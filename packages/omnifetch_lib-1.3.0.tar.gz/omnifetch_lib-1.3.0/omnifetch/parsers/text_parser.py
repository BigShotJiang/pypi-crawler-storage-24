"""
Text parser - Extract clean text content from HTML
"""

import re
from typing import Optional
from bs4 import BeautifulSoup
import html2text


def extract_text(html: str, as_markdown: bool = True) -> str:
    """
    Extract clean text content from HTML
    Converts to readable plain text or markdown
    
    Args:
        html: The HTML content to parse
        as_markdown: If True, return markdown; otherwise plain text
        
    Returns:
        Extracted text content
    """
    soup = BeautifulSoup(html, "lxml")
    
    # FIRST: Find the main content area BEFORE any cleanup
    content_element = None
    
    for selector in ["article", "main", "[role='main']"]:
        content_element = soup.select_one(selector)
        if content_element:
            break
    
    if not content_element:
        # Try common content class patterns
        for class_pattern in [
            "article-content", "post-content", "entry-content",
            "content-body", "story-body", "page-content"
        ]:
            els = soup.find_all(class_=re.compile(f"^{class_pattern}$", re.I))
            for el in els:
                if len(el.get_text(strip=True)) > 200:
                    content_element = el
                    break
            if content_element:
                break
    
    # Fallback to body
    if not content_element:
        content_element = soup.body or soup
    
    # NOW: Clean up within the content element only
    # Remove unwanted semantic elements
    for tag in content_element.find_all(["script", "style", "nav", "iframe", "noscript", "svg"]):
        tag.decompose()
    
    # Remove elements by role (navigation-related)
    for role in ["navigation", "banner"]:
        for el in content_element.find_all(attrs={"role": role}):
            el.decompose()
    
    # Remove share buttons, social widgets (exact class matches only)
    exact_patterns = [
        r"^share$", r"^social$", r"^share-buttons?$", r"^social-share$",
        r"^newsletter$", r"^subscribe$", r"^related-posts?$", r"^comments?$"
    ]
    for pattern in exact_patterns:
        for el in content_element.find_all(class_=re.compile(pattern, re.I)):
            el.decompose()
        for el in content_element.find_all(id=re.compile(pattern, re.I)):
            el.decompose()
    
    content_html = str(content_element)
    
    if as_markdown:
        # Use html2text for markdown conversion
        h = html2text.HTML2Text()
        h.ignore_links = False
        h.ignore_images = True
        h.ignore_emphasis = False
        h.body_width = 0  # Don't wrap lines
        
        markdown = h.handle(content_html)
        
        # Clean up excessive whitespace
        markdown = re.sub(r"\n{3,}", "\n\n", markdown)
        markdown = re.sub(r"[ \t]+", " ", markdown)
        
        return markdown.strip()
    else:
        # Plain text extraction
        text = content_element.get_text()
        text = re.sub(r"\s+", " ", text)
        text = re.sub(r"\n\s*\n", "\n\n", text)
        
        return text.strip()


def extract_summary(html: str, max_length: int = 300) -> str:
    """
    Extract a summary/excerpt from HTML content
    
    Args:
        html: The HTML content
        max_length: Maximum length of the summary
        
    Returns:
        A short summary of the content
    """
    soup = BeautifulSoup(html, "lxml")
    
    # Try meta description first
    meta_desc = soup.find("meta", attrs={"name": "description"})
    if meta_desc and meta_desc.get("content"):
        desc = meta_desc.get("content", "")
        if len(desc) >= 50:
            return desc[:max_length]
    
    # Try og:description
    og_desc = soup.find("meta", property="og:description")
    if og_desc and og_desc.get("content"):
        desc = og_desc.get("content", "")
        if len(desc) >= 50:
            return desc[:max_length]
    
    # Extract from first paragraph
    for selector in ["article p", "main p", ".content p", "p"]:
        p = soup.select_one(selector)
        if p:
            text = p.get_text(strip=True)
            if len(text) >= 50:
                suffix = "..." if len(text) > max_length else ""
                return text[:max_length] + suffix
    
    # Fallback to body text
    body_text = extract_text(html, as_markdown=False)
    suffix = "..." if len(body_text) > max_length else ""
    return body_text[:max_length] + suffix
