"""
JSON parser - Extract structured data from HTML content
"""

import json
import re
from typing import Any, Dict, List, Optional
from bs4 import BeautifulSoup


def extract_json(html: str) -> Optional[Dict[str, Any]]:
    """
    Extract structured JSON data from HTML content
    Attempts to find JSON-LD, meta tags, and structured data
    
    Args:
        html: The HTML content to parse
        
    Returns:
        Extracted structured data or None
    """
    soup = BeautifulSoup(html, "lxml")
    result: Dict[str, Any] = {}
    
    # 1. Extract JSON-LD (Schema.org) structured data
    json_ld_scripts = soup.find_all("script", type="application/ld+json")
    json_ld_data: List[Any] = []
    
    for script in json_ld_scripts:
        try:
            content = script.string
            if content:
                parsed = json.loads(content)
                json_ld_data.append(parsed)
        except (json.JSONDecodeError, Exception):
            pass
    
    if json_ld_data:
        result["jsonLd"] = json_ld_data[0] if len(json_ld_data) == 1 else json_ld_data
    
    # 2. Extract Open Graph meta tags
    og_data: Dict[str, str] = {}
    for meta in soup.find_all("meta", property=re.compile(r"^og:")):
        prop = meta.get("property", "").replace("og:", "")
        content = meta.get("content", "")
        if prop and content:
            og_data[prop] = content
    
    if og_data:
        result["openGraph"] = og_data
    
    # 3. Extract Twitter Card meta tags
    twitter_data: Dict[str, str] = {}
    for meta in soup.find_all("meta", attrs={"name": re.compile(r"^twitter:")}):
        name = meta.get("name", "").replace("twitter:", "")
        content = meta.get("content", "")
        if name and content:
            twitter_data[name] = content
    
    if twitter_data:
        result["twitter"] = twitter_data
    
    # 4. Extract basic meta tags
    meta_tags: Dict[str, str] = {}
    meta_names = ["description", "keywords", "author", "robots"]
    
    for name in meta_names:
        meta = soup.find("meta", attrs={"name": name})
        if meta and meta.get("content"):
            meta_tags[name] = meta.get("content", "")
    
    if meta_tags:
        result["meta"] = meta_tags
    
    # 5. Extract title
    title = ""
    title_tag = soup.find("title")
    og_title = soup.find("meta", property="og:title")
    h1 = soup.find("h1")
    
    if title_tag:
        title = title_tag.get_text(strip=True)
    elif og_title and og_title.get("content"):
        title = og_title.get("content", "")
    elif h1:
        title = h1.get_text(strip=True)
    
    result["title"] = title
    
    # 6. Extract main content as structured data
    article = soup.find("article")
    if article:
        headline = article.find(["h1", "h2"])
        result["article"] = {
            "headline": headline.get_text(strip=True) if headline else "",
            "content": " ".join(article.get_text().split())[:1000],
        }
    
    # 7. Extract links
    links: List[Dict[str, str]] = []
    for a in soup.find_all("a", href=True):
        href = a.get("href", "")
        text = a.get_text(strip=True)
        if href and text and href.startswith("http") and len(links) < 20:
            links.append({"text": text, "href": href})
    
    if links:
        result["links"] = links
    
    return result if result else None
