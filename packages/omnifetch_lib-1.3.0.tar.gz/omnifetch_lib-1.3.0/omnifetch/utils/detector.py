"""
Utility functions for detecting skeleton pages, paywalls, and extracting titles
"""

import re
from typing import Optional
from bs4 import BeautifulSoup

# Indicators that suggest a skeleton/loading page
SKELETON_INDICATORS = [
    "loading",
    "skeleton",
    "placeholder",
    "spinner",
    "shimmer",
    "lazy-load",
    "js-loading",
]

# Indicators that suggest a paywall or authentication requirement
PAYWALL_INDICATORS = [
    "paywall",
    "subscribe",
    "subscription",
    "sign-in",
    "sign in",
    "log-in",
    "log in",
    "login",
    "create account",
    "register to read",
    "premium content",
    "members only",
    "subscriber only",
    "paid content",
    "unlock this",
    "continue reading",
    "read more for",
    "free trial",
]

# Minimum content length to consider a page as having real content
MIN_CONTENT_LENGTH = 500

# Indicators that suggest a security challenge/verification page
SECURITY_CHALLENGE_INDICATORS = [
    "verify you are human",
    "checking your browser",
    "security check",
    "security verification",
    "please wait",
    "enable javascript",
    "enable cookies",
    "access denied",
    "just a moment",
    "challenge-platform",
    "cf-browser-verification",
    "captcha",
    "bot detection",
    "are you a robot",
    "automated access",
    "ray id",
]

# Maximum body text length to consider it a challenge page
MAX_CHALLENGE_LENGTH = 300


def is_security_challenge(html: str) -> bool:
    """
    Detects if the HTML is a security challenge/verification page.
    These are typically very short pages (< 300 chars of text) returned
    with a 200 status that contain security-related keywords.
    
    Sites like Medium return these instead of a 403 when curl_cffi
    impersonates a browser TLS fingerprint.
    
    Args:
        html: The HTML content to analyze
        
    Returns:
        True if the page appears to be a security challenge
    """
    soup = BeautifulSoup(html, "lxml")
    body = soup.body
    
    if not body:
        return False
    
    body_text = " ".join(body.get_text().split())
    
    # Only flag as challenge if the page is very short
    if len(body_text) > MAX_CHALLENGE_LENGTH:
        return False
    
    lower_html = str(body).lower()
    lower_text = body_text.lower()
    
    # Check for security challenge indicators
    challenge_score = 0
    for indicator in SECURITY_CHALLENGE_INDICATORS:
        if indicator in lower_html or indicator in lower_text:
            challenge_score += 1
    
    # A single strong indicator on a short page is enough
    if challenge_score >= 1:
        return True
    
    # Also check for meta-refresh or noscript redirect patterns on short pages
    meta_refresh = soup.find("meta", attrs={"http-equiv": "refresh"})
    if meta_refresh and len(body_text) < 100:
        return True
    
    return False


def is_skeleton_page(html: str) -> bool:
    """
    Detects if the HTML represents a skeleton/loading page
    
    Args:
        html: The HTML content to analyze
        
    Returns:
        True if the page appears to be a skeleton/loading state
    """
    soup = BeautifulSoup(html, "lxml")
    body = soup.body
    
    if not body:
        return True
    
    body_html = str(body).lower()
    
    # Check for skeleton indicators in class names
    for indicator in SKELETON_INDICATORS:
        if f'class="{indicator}' in body_html or f"class='{indicator}" in body_html or f"{indicator}-" in body_html:
            return True
    
    # Check for very little text content
    text_content = " ".join(body.get_text().split())
    if len(text_content) < MIN_CONTENT_LENGTH:
        # Also check if there are many empty divs
        all_divs = body.find_all("div")
        empty_divs = [d for d in all_divs if not d.get_text(strip=True)]
        
        if all_divs and len(empty_divs) / len(all_divs) > 0.5:
            return True
    
    # Check for noscript tags with content
    noscript = soup.find("noscript")
    if noscript:
        noscript_text = noscript.get_text(strip=True)
        if len(noscript_text) > 100 and len(text_content) < MIN_CONTENT_LENGTH:
            return True
    
    return False


def is_paywalled(html: str) -> bool:
    """
    Detects if the HTML shows paywall or authentication indicators
    
    Args:
        html: The HTML content to analyze
        
    Returns:
        True if the page appears to be paywalled
    """
    soup = BeautifulSoup(html, "lxml")
    body = soup.body
    
    if not body:
        return False
    
    lower_html = str(body).lower()
    
    # Check for paywall indicators in content
    paywall_score = sum(1 for indicator in PAYWALL_INDICATORS if indicator in lower_html)
    
    if paywall_score >= 2:
        return True
    
    # Check for common paywall modal/overlay patterns
    paywall_selectors = [
        {"class_": re.compile(r"paywall", re.I)},
        {"class_": re.compile(r"subscribe-wall", re.I)},
        {"class_": re.compile(r"registration-wall", re.I)},
        {"id": re.compile(r"paywall", re.I)},
        {"attrs": {"data-paywall": True}},
    ]
    
    for selector in paywall_selectors:
        if soup.find(**selector):
            return True
    
    # Check for truncated content
    article = soup.find("article") or soup.find(class_=re.compile(r"article|content", re.I))
    if article:
        article_text = article.get_text(strip=True)
        if len(article_text) < 1000 and paywall_score >= 1:
            return True
    
    return False


def extract_title(html: str) -> str:
    """
    Extracts the page title from HTML
    
    Args:
        html: The HTML content
        
    Returns:
        The page title or empty string
    """
    soup = BeautifulSoup(html, "lxml")
    
    # Try various title sources in order of preference
    sources = [
        lambda: soup.find("meta", property="og:title"),
        lambda: soup.find("meta", attrs={"name": "twitter:title"}),
        lambda: soup.find("title"),
        lambda: soup.find("h1"),
    ]
    
    for get_source in sources:
        element = get_source()
        if element:
            if hasattr(element, "get") and element.get("content"):
                title = element.get("content", "").strip()
            else:
                title = element.get_text(strip=True)
            
            if title:
                # Clean up the title
                title = " ".join(title.split())
                title = re.sub(r"\|.*$", "", title)  # Remove site name after pipe
                title = re.sub(r"-\s*[^-]+$", "", title)  # Remove site name after dash
                return title.strip()
    
    return ""


def has_valid_content(html: str) -> bool:
    """
    Checks if the content appears to be valid/complete
    
    Args:
        html: The HTML content to analyze
        
    Returns:
        True if content appears complete
    """
    soup = BeautifulSoup(html, "lxml")
    body = soup.body
    
    if not body:
        return False
    
    # First, check total body text length (less strict)
    body_text = " ".join(body.get_text().split())
    
    # If body has substantial text, it's valid
    if len(body_text) >= 300:  # Lowered threshold
        return True
    
    # If body text is very short, check for main content areas
    content_selectors = [
        "article",
        {"class_": re.compile(r"article", re.I)},
        {"class_": re.compile(r"content", re.I)},
        {"class_": re.compile(r"post", re.I)},
        "main",
        {"role": "main"},
    ]
    
    for selector in content_selectors:
        if isinstance(selector, str):
            element = soup.find(selector)
        else:
            element = soup.find(**selector)
        
        if element:
            text = " ".join(element.get_text().split())
            if len(text) >= 200:  # Lower threshold for content areas
                return True
    
    return False

