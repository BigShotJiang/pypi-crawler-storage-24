"""
Type definitions for OmniFetch
"""

from dataclasses import dataclass, field
from typing import Dict, List, Literal, Optional, Union, Any

# Type alias for output mode
OutputMode = Literal["JSON", "TEXT"]


@dataclass
class OmniFetchConfig:
    """Configuration options for OmniFetch"""
    
    # Output mode: 'JSON' for structured data, 'TEXT' for plain text
    mode: OutputMode = "TEXT"
    
    # Request timeout in seconds (default: 30)
    timeout: int = 30
    
    # Custom Netlify endpoint for headless browser fallback
    netlify_endpoint: Optional[str] = None
    
    # Custom headers to include in requests
    headers: Dict[str, str] = field(default_factory=dict)
    
    # Whether to skip Tier 2 (headless) and go directly to search fallback
    skip_headless: bool = False
    
    # Whether to skip Tier 3 (search fallback) entirely
    skip_search: bool = False

    # Override title for search fallback (useful for opaque URLs like x.com/status/ID)
    force_title: Optional[str] = None


@dataclass
class OmniFetchResult:
    """Result returned by OmniFetch"""
    
    # Whether the fetch was successful
    success: bool
    
    # The extracted content (string for TEXT mode, dict for JSON mode)
    content: Optional[Union[str, Dict[str, Any]]] = None
    
    # Array of suggested alternative URLs (when content not found)
    suggestions: Optional[List[str]] = None
    
    # Error message if fetch failed
    error: Optional[str] = None
    
    # Which tier successfully retrieved the content
    tier: Optional[int] = None
    
    # The final URL after any redirects
    final_url: Optional[str] = None
    
    # Page title extracted from the content
    title: Optional[str] = None


@dataclass 
class TierResult:
    """Internal tier result for orchestration"""
    
    # Whether this tier succeeded
    success: bool
    
    # Whether to proceed to next tier
    should_fallback: bool
    
    # Raw HTML content
    html: Optional[str] = None
    
    # Page title
    title: Optional[str] = None
    
    # Reason for fallback
    fallback_reason: Optional[Literal["skeleton", "paywall", "error", "empty"]] = None
    
    # Error message if tier failed
    error: Optional[str] = None
    
    # Final URL after redirects
    final_url: Optional[str] = None


@dataclass
class SearchResult:
    """Search result from Tier 3"""
    
    # URL of the search result
    url: str
    
    # Title of the search result
    title: str
    
    # Match score (0-100)
    match_score: int
    
    # Snippet/description from search
    snippet: Optional[str] = None
