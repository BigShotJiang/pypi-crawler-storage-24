"""
Core OmniFetch orchestration logic
Manages tier progression: Light → Headless → Search
"""

from typing import Optional, Union
from urllib.parse import urlparse

from .types import OmniFetchConfig, OmniFetchResult
from .tiers.light import light_fetch
from .tiers.headless import headless_fetch
from .tiers.search import search_fallback
from .parsers.json_parser import extract_json
from .parsers.text_parser import extract_text
from .utils.detector import is_paywalled
from .youtube import is_youtube_url, fetch_youtube_transcript

# Domains that should ALWAYS go to Tier 3 (search fallback)
# These sites either block scraping or have terms that prohibit it
BLOCKED_DOMAINS = {
    "x.com",
    "twitter.com",
    "www.x.com", 
    "www.twitter.com",
    "mobile.twitter.com",
    "mobile.x.com",
}


def _is_blocked_domain(url: str) -> bool:
    """Check if URL is from a blocked domain that should skip to Tier 3"""
    try:
        parsed = urlparse(url)
        hostname = parsed.hostname or ""
        return hostname.lower() in BLOCKED_DOMAINS
    except Exception:
        return False


def fetch_content(url: str, config: OmniFetchConfig) -> OmniFetchResult:
    """
    Core OmniFetch orchestration logic
    Manages tier progression: Light → Headless → Search
    
    Args:
        url: The URL to fetch content from
        config: Configuration options
        
    Returns:
        OmniFetchResult with content or error
    """
    timeout = config.timeout
    headers = config.headers
    
    # ============================================
    # CHECK: YouTube URLs go to transcript pipeline
    # ============================================
    if is_youtube_url(url):
        return _handle_youtube(url, config)
    
    # ============================================
    # CHECK: Blocked domains go straight to Tier 3
    # ============================================
    if _is_blocked_domain(url):
        if not config.skip_search:
            # Extract title from URL for search query, or use forced title
            title = config.force_title or _extract_title_from_url(url)
            return _execute_search_fallback(title, url, config.mode, timeout)
        else:
            return OmniFetchResult(
                success=False,
                error=f"Domain is blocked for scraping. Enable search fallback to find alternative sources."
            )
    
    # ============================================
    # TIER 1: Light Fetch (Standard HTTP)
    # ============================================
    tier1_result = light_fetch(url, timeout, headers)
    
    if tier1_result.success and tier1_result.html:
        return _format_result(
            tier1_result.html, 
            config.mode, 
            1, 
            tier1_result.final_url, 
            tier1_result.title
        )
    
    # ============================================
    # TIER 2: Headless Browser Fallback
    # ============================================
    if not config.skip_headless and tier1_result.should_fallback:
        netlify_endpoint = config.netlify_endpoint
        
        if netlify_endpoint:
            tier2_result = headless_fetch(url, netlify_endpoint, timeout)
            
            if tier2_result.success and tier2_result.html:
                return _format_result(
                    tier2_result.html,
                    config.mode,
                    2,
                    tier2_result.final_url,
                    tier2_result.title
                )
            
            # Check if we should proceed to search fallback
            if tier2_result.fallback_reason != "paywall" and not config.skip_search:
                # Non-paywall errors - try to return what we have
                if tier1_result.html:
                    return _format_result(
                        tier1_result.html,
                        config.mode,
                        1,
                        tier1_result.final_url,
                        tier1_result.title
                    )
            
            # Paywall detected - proceed to Tier 3
            if tier2_result.fallback_reason == "paywall" or is_paywalled(tier1_result.html or ""):
                if not config.skip_search:
                    # Use force_title first, then try tier titles, but skip challenge page titles
                    # like "Just a moment..." which are useless for search
                    challenge_titles = {"just a moment", "checking your browser", "access denied", "security check", "please wait"}
                    t2_title = tier2_result.title or ""
                    t1_title = tier1_result.title or ""
                    
                    if t2_title.lower().strip().rstrip("...").strip() in challenge_titles:
                        t2_title = ""
                    if t1_title.lower().strip().rstrip("...").strip() in challenge_titles:
                        t1_title = ""
                    
                    title = config.force_title or t2_title or t1_title or _extract_title_from_url(url)
                    return _execute_search_fallback(title, url, config.mode, timeout)
        
        elif tier1_result.fallback_reason == "skeleton":
            # No Netlify endpoint but skeleton detected
            if tier1_result.html:
                result = _format_result(
                    tier1_result.html,
                    config.mode,
                    1,
                    tier1_result.final_url,
                    tier1_result.title
                )
                result.error = "Content may be incomplete (no headless endpoint configured)"
                return result
    
    # ============================================
    # TIER 3: Search Fallback (for paywalled content)
    # ============================================
    if not config.skip_search and (
        tier1_result.fallback_reason == "paywall" or 
        is_paywalled(tier1_result.html or "")
    ):
        challenge_titles = {"just a moment", "checking your browser", "access denied", "security check", "please wait"}
        t1_title = tier1_result.title or ""
        if t1_title.lower().strip().rstrip("...").strip() in challenge_titles:
            t1_title = ""
        title = config.force_title or t1_title or _extract_title_from_url(url)
        return _execute_search_fallback(title, url, config.mode, timeout)
    
    # ============================================
    # Final Fallback: Return whatever we have
    # ============================================
    if tier1_result.html:
        result = _format_result(
            tier1_result.html,
            config.mode,
            1,
            tier1_result.final_url,
            tier1_result.title
        )
        if tier1_result.error:
            result.error = tier1_result.error
        return result
    
    # Complete failure
    return OmniFetchResult(
        success=False,
        error=tier1_result.error or "Failed to fetch content"
    )


def _extract_title_from_url(url: str) -> str:
    """
    Extract a search-friendly title from a URL.
    For x.com/Twitter links, extract the username and any keywords.
    
    Args:
        url: The URL to extract title from
        
    Returns:
        A search query string
    """
    try:
        parsed = urlparse(url)
        path = parsed.path.strip("/")
        
        # For x.com/twitter - extract username and status info
        if parsed.hostname and any(d in parsed.hostname for d in ["x.com", "twitter.com"]):
            parts = path.split("/")
            if len(parts) >= 1:
                username = parts[0]
                # If it's a status/tweet link, include that
                if len(parts) >= 3 and parts[1] == "status":
                    return f"@{username} tweet {parts[2]}"
                return f"@{username}"
        
        # General URL: use path components as search terms
        path_parts = path.replace("-", " ").replace("_", " ").split("/")
        return " ".join(p for p in path_parts if len(p) > 2)
        
    except Exception:
        return url


def _execute_search_fallback(
    title: str,
    original_url: str,
    mode: str,
    timeout: int
) -> OmniFetchResult:
    """Execute search fallback tier"""
    search_result = search_fallback(title, original_url, timeout)
    
    if search_result.success and search_result.html:
        return _format_result(
            search_result.html,
            mode,
            3,
            search_result.final_url,
            search_result.title
        )
    
    # No content found - return 404 with suggestions
    suggestions = getattr(search_result, "suggestions", [])
    
    return OmniFetchResult(
        success=False,
        error="Content not found",
        suggestions=suggestions,
        title=title
    )


def _format_result(
    html: str,
    mode: str,
    tier: int,
    final_url: Optional[str] = None,
    title: Optional[str] = None
) -> OmniFetchResult:
    """Format the result based on requested mode"""
    if mode == "JSON":
        json_content = extract_json(html)
        return OmniFetchResult(
            success=True,
            content=json_content or {"rawHtml": html},
            tier=tier,
            final_url=final_url,
            title=title
        )
    else:
        text_content = extract_text(html, as_markdown=True)
        return OmniFetchResult(
            success=True,
            content=text_content,
            tier=tier,
            final_url=final_url,
            title=title
        )


def _handle_youtube(url: str, config: OmniFetchConfig) -> OmniFetchResult:
    """Handle YouTube URLs by extracting transcript and chapters."""
    try:
        data = fetch_youtube_transcript(url)

        if config.mode == "JSON":
            return OmniFetchResult(
                success=True,
                content=data,
                tier=0,
                final_url=url,
                title="YouTube Transcript",
            )
        else:
            # TEXT mode: format as readable text with chapter headers
            parts = []
            if data.get("chapters"):
                for ch in data["chapters"]:
                    parts.append(f"## {ch['title']}\n\n{ch['content']}")
                text = "\n\n".join(parts)
            else:
                text = data.get("full_transcript", "")
            return OmniFetchResult(
                success=True,
                content=text,
                tier=0,
                final_url=url,
                title="YouTube Transcript",
            )
    except ImportError as e:
        return OmniFetchResult(
            success=False,
            error=str(e),
        )
    except Exception as e:
        return OmniFetchResult(
            success=False,
            error=f"YouTube transcript extraction failed: {e}",
        )


def omni_fetch(
    url: str,
    mode: str = "TEXT",
    timeout: int = 30,
    netlify_endpoint: Optional[str] = None,
    headers: Optional[dict] = None,
    skip_headless: bool = False,
    skip_search: bool = False,
    force_title: Optional[str] = None
) -> OmniFetchResult:
    """
    Fetch content from a URL using OmniFetch's tiered strategy
    
    Args:
        url: The URL to fetch content from
        mode: Output mode - 'JSON' or 'TEXT' (default: 'TEXT')
        timeout: Request timeout in seconds (default: 30)
        netlify_endpoint: Custom Netlify endpoint for headless fallback
        headers: Custom headers to include in requests
        skip_headless: Skip Tier 2 headless browser
        skip_search: Skip Tier 3 search fallback
        force_title: Override title for search fallback
        
    Returns:
        OmniFetchResult with content or error
        
    Example:
        >>> from omnifetch import omni_fetch
        >>> result = omni_fetch('https://example.com', mode='TEXT')
        >>> print(result.content)
    """
    # Validate URL
    if not url or not isinstance(url, str):
        return OmniFetchResult(success=False, error="Invalid URL provided")
    
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        if not parsed.scheme or not parsed.netloc:
            raise ValueError("Invalid URL")
    except Exception:
        return OmniFetchResult(success=False, error="Invalid URL format")
    
    config = OmniFetchConfig(
        mode=mode,  # type: ignore
        timeout=timeout,
        netlify_endpoint=netlify_endpoint,
        headers=headers or {},
        skip_headless=skip_headless,
        skip_search=skip_search,
        force_title=force_title
    )
    
    return fetch_content(url, config)


def fetch_text(url: str, **kwargs) -> OmniFetchResult:
    """
    Convenience function for TEXT mode extraction
    
    Args:
        url: The URL to fetch
        **kwargs: Additional configuration options
        
    Returns:
        OmniFetchResult with text content
    """
    return omni_fetch(url, mode="TEXT", **kwargs)


def fetch_json(url: str, **kwargs) -> OmniFetchResult:
    """
    Convenience function for JSON mode extraction
    
    Args:
        url: The URL to fetch
        **kwargs: Additional configuration options
        
    Returns:
        OmniFetchResult with JSON content
    """
    return omni_fetch(url, mode="JSON", **kwargs)
