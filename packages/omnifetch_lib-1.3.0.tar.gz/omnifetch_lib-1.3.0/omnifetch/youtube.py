"""
YouTube Transcript Extraction Module

Fetches full transcript text and chapter-wise transcript text from YouTube videos.
Uses youtube-transcript-api for transcript lines and yt-dlp for chapter metadata.

These are optional dependencies — install with: pip install omnifetch-lib[youtube]
"""

import re
from typing import Any, Dict, List, Optional


def _check_youtube_deps():
    """Check that optional YouTube dependencies are installed."""
    missing = []
    try:
        import youtube_transcript_api  # noqa: F401
    except ImportError:
        missing.append("youtube-transcript-api")
    try:
        import yt_dlp  # noqa: F401
    except ImportError:
        missing.append("yt-dlp")

    if missing:
        raise ImportError(
            f"YouTube transcript extraction requires: {', '.join(missing)}. "
            f"Install with: pip install omnifetch-lib[youtube]"
        )


# ---------------------------------------------------------------------------
# URL helpers
# ---------------------------------------------------------------------------

_YOUTUBE_HOSTS = {
    "youtube.com", "www.youtube.com", "m.youtube.com",
    "youtu.be", "www.youtu.be",
    "youtube-nocookie.com", "www.youtube-nocookie.com",
}

_VIDEO_ID_PATTERNS = [
    r"(?:v=)([A-Za-z0-9_-]{11})",
    r"(?:youtu\.be/)([A-Za-z0-9_-]{11})",
    r"(?:embed/)([A-Za-z0-9_-]{11})",
    r"(?:shorts/)([A-Za-z0-9_-]{11})",
]


def is_youtube_url(url: str) -> bool:
    """Check if a URL is a YouTube video URL."""
    try:
        from urllib.parse import urlparse
        parsed = urlparse(url)
        hostname = (parsed.hostname or "").lower()
        if hostname not in _YOUTUBE_HOSTS:
            return False
        # Must be able to extract a video ID
        return extract_video_id(url) is not None
    except Exception:
        return False


def extract_video_id(url: str) -> Optional[str]:
    """
    Extract the 11-character video ID from various YouTube URL formats.
    
    Supports:
        - https://www.youtube.com/watch?v=VIDEO_ID
        - https://youtu.be/VIDEO_ID
        - https://www.youtube.com/embed/VIDEO_ID
        - https://www.youtube.com/shorts/VIDEO_ID
    
    Returns:
        The video ID string, or None if not found.
    """
    for pattern in _VIDEO_ID_PATTERNS:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None


# ---------------------------------------------------------------------------
# Transcript + chapter fetching
# ---------------------------------------------------------------------------

def get_transcript(video_id: str, languages: Optional[List[str]] = None) -> List[Dict[str, Any]]:
    """
    Fetch transcript segments with timestamps using youtube-transcript-api.
    
    Args:
        video_id: The 11-char YouTube video ID.
        languages: Preferred subtitle languages (default: ["en", "hi", "en-US"]).
    
    Returns:
        List of dicts with keys: start, end, text.
    """
    from youtube_transcript_api import YouTubeTranscriptApi

    languages = languages or ["en", "hi", "en-US"]
    api = YouTubeTranscriptApi()
    transcript = api.fetch(video_id, languages=languages)

    return [
        {
            "start": float(item.start),
            "end": float(item.start + item.duration),
            "text": item.text.replace("\n", " ").strip(),
        }
        for item in transcript
    ]


def get_chapters(url: str) -> List[Dict[str, Any]]:
    """
    Fetch chapter boundaries from YouTube video metadata via yt-dlp.
    
    Args:
        url: The YouTube video URL.
    
    Returns:
        List of dicts with keys: title, start, end.
        Empty list if the video has no chapters.
    """
    from yt_dlp import YoutubeDL

    ydl_opts = {
        "quiet": True,
        "skip_download": True,
        "no_warnings": True,
    }

    with YoutubeDL(ydl_opts) as ydl:
        info = ydl.extract_info(url, download=False)

    raw_chapters = info.get("chapters") or []
    chapters = []

    for idx, ch in enumerate(raw_chapters):
        chapters.append({
            "title": ch.get("title", f"Chapter {idx + 1}"),
            "start": float(ch.get("start_time", 0.0)),
            "end": float(ch.get("end_time", float("inf"))),
        })

    return chapters


def group_by_chapters(
    transcript_segments: List[Dict[str, Any]],
    chapters: List[Dict[str, Any]],
) -> List[Dict[str, str]]:
    """
    Group transcript segments into the chapter whose time window contains them.
    
    Args:
        transcript_segments: List from get_transcript().
        chapters: List from get_chapters().
    
    Returns:
        List of dicts with keys: title, content.
    """
    if not chapters:
        return []

    result = []
    for chapter in chapters:
        parts = []
        for seg in transcript_segments:
            if chapter["start"] <= seg["start"] < chapter["end"]:
                parts.append(seg["text"])

        content = " ".join(parts).strip()
        result.append({
            "title": chapter["title"],
            "content": content,
        })

    return result


# ---------------------------------------------------------------------------
# Main public function
# ---------------------------------------------------------------------------

def fetch_youtube_transcript(url: str) -> Dict[str, Any]:
    """
    Fetch structured transcript from a YouTube video.
    
    Given a YouTube URL, returns the full transcript text and chapter-wise
    transcript text (if the video has chapters).
    
    Args:
        url: A YouTube video URL.
    
    Returns:
        Dict with keys:
            - full_transcript: Complete spoken text as a single string.
            - chapters: List of {title, content} dicts. Empty if no chapters.
    
    Raises:
        ImportError: If youtube-transcript-api or yt-dlp are not installed.
        ValueError: If the URL is not a valid YouTube video URL.
        Exception: If transcript is unavailable (no captions on the video).
    
    Example:
        >>> from omnifetch.youtube import fetch_youtube_transcript
        >>> data = fetch_youtube_transcript("https://www.youtube.com/watch?v=dQw4w9WgXcQ")
        >>> print(data["full_transcript"][:100])
        >>> for ch in data["chapters"]:
        ...     print(f"{ch['title']}: {ch['content'][:50]}...")
    """
    _check_youtube_deps()

    video_id = extract_video_id(url)
    if not video_id:
        raise ValueError(f"Could not extract YouTube video ID from: {url}")

    # Fetch transcript segments
    transcript_segments = get_transcript(video_id)

    # Fetch chapter boundaries
    chapters = get_chapters(url)

    # Build outputs
    full_transcript = " ".join(seg["text"] for seg in transcript_segments).strip()
    chapter_wise = group_by_chapters(transcript_segments, chapters)

    return {
        "full_transcript": full_transcript,
        "chapters": chapter_wise,
    }
