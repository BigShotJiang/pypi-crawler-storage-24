"""
Tier 1: Light Fetch - HTTP request with TLS fingerprint impersonation

Uses curl_cffi to impersonate real browser TLS fingerprints, bypassing
many bot detection systems including Cloudflare without needing headless browsers.
"""

from typing import Dict, Optional

from ..types import TierResult
from ..utils.detector import is_skeleton_page, is_security_challenge, extract_title, has_valid_content

# Try to import curl_cffi for TLS impersonation, fall back to requests
try:
    from curl_cffi import requests as cffi_requests
    HAS_CURL_CFFI = True
except ImportError:
    import requests as cffi_requests
    HAS_CURL_CFFI = False

# Standard requests for basic fallback
import requests

# Browser impersonation options (from curl_cffi)
BROWSER_IMPERSONATE_OPTIONS = [
    "chrome120",  # Chrome 120
    "chrome119",  # Chrome 119
    "chrome",     # Latest Chrome
    "safari",     # Safari
    "edge",       # Edge
]

# Fallback browser-like headers for when curl_cffi is not available
BROWSER_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Cache-Control": "no-cache",
    "Pragma": "no-cache",
    "Sec-Ch-Ua": '"Not_A Brand";v="8", "Chromium";v="120", "Google Chrome";v="120"',
    "Sec-Ch-Ua-Mobile": "?0",
    "Sec-Ch-Ua-Platform": '"Windows"',
    "Sec-Fetch-Dest": "document",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-Site": "none",
    "Sec-Fetch-User": "?1",
    "Upgrade-Insecure-Requests": "1",
}


def _fetch_with_impersonation(
    url: str,
    timeout: int = 30,
    impersonate: str = "chrome120",
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Fetch URL with TLS fingerprint impersonation using curl_cffi.
    
    Returns:
        Tuple of (html, final_url, error)
    """
    if not HAS_CURL_CFFI:
        return None, None, "curl_cffi not installed"
    
    try:
        response = cffi_requests.get(
            url,
            impersonate=impersonate,
            timeout=timeout,
            allow_redirects=True,
        )
        
        if response.ok:
            return response.text, str(response.url), None
        else:
            return None, None, f"HTTP {response.status_code}"
            
    except Exception as e:
        return None, None, str(e)


def _fetch_with_requests(
    url: str,
    timeout: int = 30,
    custom_headers: Dict[str, str] = None,
) -> tuple[Optional[str], Optional[str], Optional[str]]:
    """
    Fallback fetch using standard requests library.
    
    Returns:
        Tuple of (html, final_url, error)
    """
    headers = {**BROWSER_HEADERS, **(custom_headers or {})}
    
    try:
        response = requests.get(
            url,
            headers=headers,
            timeout=timeout,
            allow_redirects=True,
        )
        
        if response.ok:
            return response.text, response.url, None
        else:
            return None, None, f"HTTP {response.status_code}: {response.reason}"
            
    except requests.Timeout:
        return None, None, "Request timeout"
    except requests.RequestException as e:
        return None, None, str(e)


def light_fetch(
    url: str,
    timeout: int = 30,
    custom_headers: Dict[str, str] = None,
    use_impersonation: bool = True,
) -> TierResult:
    """
    Tier 1: Light Fetch - HTTP request with optional TLS fingerprint impersonation
    
    Uses curl_cffi to impersonate real browser TLS fingerprints, which bypasses
    many bot detection systems (including Cloudflare) without needing a headless browser.
    
    Args:
        url: The URL to fetch
        timeout: Request timeout in seconds
        custom_headers: Optional custom headers to merge
        use_impersonation: Whether to use TLS fingerprint impersonation (default: True)
        
    Returns:
        TierResult indicating success or need for fallback
    """
    html = None
    final_url = None
    error = None
    
    # Try TLS impersonation first if available
    if use_impersonation and HAS_CURL_CFFI:
        # Try multiple browser impersonation options
        for browser in BROWSER_IMPERSONATE_OPTIONS[:3]:  # Try first 3 options
            html, final_url, error = _fetch_with_impersonation(url, timeout, browser)
            if html:
                break
    
    # Fallback to standard requests if impersonation failed or not available
    if not html:
        html, final_url, error = _fetch_with_requests(url, timeout, custom_headers)
    
    # Handle complete failure
    if not html:
        error_msg = error or "Unknown error"
        
        if "403" in error_msg or "401" in error_msg:
            return TierResult(
                success=False,
                should_fallback=True,
                fallback_reason="paywall",
                error=f"Access denied: {error_msg}",
            )
        
        return TierResult(
            success=False,
            should_fallback=True,
            fallback_reason="error",
            error=error_msg,
        )
    
    # Check if response is empty
    if not html.strip():
        return TierResult(
            success=False,
            should_fallback=True,
            fallback_reason="empty",
            error="Empty response received",
        )
    
    # Check for security challenge/verification pages
    # Sites like Medium return 200 + tiny challenge page instead of 403
    # when curl_cffi impersonates browser TLS fingerprints
    if is_security_challenge(html):
        return TierResult(
            success=False,
            should_fallback=True,
            fallback_reason="paywall",
            error="Security challenge page detected",
        )
    
    # Check for skeleton/loading page  
    if is_skeleton_page(html):
        return TierResult(
            success=False,
            html=html,
            title=extract_title(html),
            should_fallback=True,
            fallback_reason="skeleton",
            final_url=final_url,
        )
    
    # Check if content is valid and complete
    if not has_valid_content(html):
        return TierResult(
            success=False,
            html=html,
            title=extract_title(html),
            should_fallback=True,
            fallback_reason="skeleton",
            final_url=final_url,
        )
    
    # Success!
    return TierResult(
        success=True,
        html=html,
        title=extract_title(html),
        should_fallback=False,
        final_url=final_url,
    )
