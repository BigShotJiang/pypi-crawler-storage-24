"""
Tier 2: Headless Browser Fallback
Calls the Netlify Function endpoint for headless browser rendering
"""

import requests
from typing import Optional

from ..types import TierResult
from ..utils.detector import is_paywalled, is_security_challenge, extract_title


def headless_fetch(
    url: str,
    netlify_endpoint: str,
    timeout: int = 30
) -> TierResult:
    """
    Tier 2: Headless Browser Fallback
    Calls the Netlify Function endpoint for headless browser rendering
    
    Args:
        url: The URL to fetch
        netlify_endpoint: The Netlify Function endpoint URL
        timeout: Request timeout in seconds
        
    Returns:
        TierResult indicating success or need for fallback
    """
    if not netlify_endpoint:
        return TierResult(
            success=False,
            should_fallback=True,
            fallback_reason="error",
            error="No Netlify endpoint configured. Set netlify_endpoint in config.",
        )
    
    try:
        response = requests.post(
            netlify_endpoint,
            json={"url": url},
            headers={"Content-Type": "application/json"},
            timeout=timeout,
        )
        
        if not response.ok:
            return TierResult(
                success=False,
                should_fallback=True,
                fallback_reason="error",
                error=f"Headless fetch failed: {response.status_code} - {response.text}",
            )
        
        result = response.json()
        
        if not result.get("success") or not result.get("html"):
            return TierResult(
                success=False,
                should_fallback=True,
                fallback_reason="error",
                error=result.get("error", "No HTML content returned from headless fetch"),
            )
        
        html = result["html"]
        title = extract_title(html)
        final_url = result.get("finalUrl")
        
        # Check for security challenge page (e.g. Cloudflare "Just a moment...")
        # The headless browser can also get blocked by bot detection
        if is_security_challenge(html):
            return TierResult(
                success=False,
                html=html,
                title=title,
                should_fallback=True,
                fallback_reason="paywall",
                final_url=final_url,
            )
        
        # Check for paywall in the rendered content
        if is_paywalled(html):
            return TierResult(
                success=False,
                html=html,
                title=title,
                should_fallback=True,
                fallback_reason="paywall",
                final_url=final_url,
            )
        
        # Success!
        return TierResult(
            success=True,
            html=html,
            title=title,
            should_fallback=False,
            final_url=final_url,
        )
        
    except requests.Timeout:
        return TierResult(
            success=False,
            should_fallback=True,
            fallback_reason="error",
            error="Headless fetch timeout",
        )
    except requests.RequestException as e:
        return TierResult(
            success=False,
            should_fallback=True,
            fallback_reason="error",
            error=f"Headless fetch error: {str(e)}",
        )
    except ValueError as e:  # JSON decode error
        return TierResult(
            success=False,
            should_fallback=True,
            fallback_reason="error",
            error=f"Invalid JSON response: {str(e)}",
        )
