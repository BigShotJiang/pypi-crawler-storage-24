"""
Tier 3: Search Fallback
Searches for the page title to find mirrors or alternative sources
"""

import re
import requests
from typing import List, Optional
from urllib.parse import urlparse, unquote

from ..types import TierResult, SearchResult
from .light import light_fetch

# DuckDuckGo HTML search URL
DDG_SEARCH_URL = "https://html.duckduckgo.com/html/"

# Domains to EXCLUDE from search results (never scrape from these)
BLOCKED_RESULT_DOMAINS = {
    "x.com",
    "twitter.com",
    "www.x.com",
    "www.twitter.com", 
    "mobile.twitter.com",
    "mobile.x.com",
}


def calculate_similarity(str1: str, str2: str) -> int:
    """
    Calculate similarity between two strings (0-100)
    Uses word-based matching for efficiency
    """
    s1 = str1.lower().strip()
    s2 = str2.lower().strip()
    
    if s1 == s2:
        return 100
    if not s1 or not s2:
        return 0
    
    words1 = set(w for w in s1.split() if len(w) > 2)
    words2 = set(w for w in s2.split() if len(w) > 2)
    
    if not words1 or not words2:
        return 0
    
    matches = len(words1 & words2)
    similarity = (matches * 2) / (len(words1) + len(words2)) * 100
    
    return round(similarity)


def parse_search_results(html: str) -> List[SearchResult]:
    """Parse DuckDuckGo HTML search results"""
    results = []
    
    # Extract result blocks using regex
    result_pattern = re.compile(
        r'<a[^>]*class="result__a"[^>]*href="([^"]*)"[^>]*>([^<]*)</a>',
        re.IGNORECASE
    )
    snippet_pattern = re.compile(
        r'<a[^>]*class="result__snippet"[^>]*>([^<]*)</a>',
        re.IGNORECASE
    )
    
    links = []
    for match in result_pattern.finditer(html):
        raw_url = match.group(1)
        title = match.group(2).strip()
        
        # Extract actual URL from DuckDuckGo redirect
        if "uddg=" in raw_url:
            url = unquote(raw_url.split("uddg=")[1].split("&")[0])
        else:
            url = raw_url
        
        if url.startswith("http"):
            links.append({"url": url, "title": title})
    
    snippets = [m.group(1).strip() for m in snippet_pattern.finditer(html)]
    
    for i, link in enumerate(links):
        results.append(SearchResult(
            url=link["url"],
            title=link["title"],
            snippet=snippets[i] if i < len(snippets) else "",
            match_score=0,  # Will be calculated later
        ))
    
    return results


def search_fallback(
    title: str,
    original_url: str,
    timeout: int = 30
) -> TierResult:
    """
    Tier 3: Search Fallback
    Searches for the page title to find mirrors or alternative sources
    
    Args:
        title: The page title to search for
        original_url: The original URL (to exclude from results)
        timeout: Request timeout in seconds
        
    Returns:
        TierResult with either content or suggestions
    """
    if not title or not title.strip():
        return TierResult(
            success=False,
            should_fallback=False,
            error="No title available for search fallback",
        )
    
    try:
        # Perform DuckDuckGo search
        response = requests.get(
            DDG_SEARCH_URL,
            params={"q": title},
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Accept": "text/html",
            },
            timeout=timeout,
        )
        
        if not response.ok:
            return TierResult(
                success=False,
                should_fallback=False,
                error=f"Search failed: {response.status_code}",
            )
        
        results = parse_search_results(response.text)
        
        # Calculate match scores and filter out original URL and blocked domains
        original_domain = urlparse(original_url).hostname or ""
        scored_results = []
        
        for r in results:
            # Skip results from original domain
            if original_domain and original_domain in r.url:
                continue
            
            # Skip results from blocked domains (e.g., x.com)
            try:
                result_hostname = urlparse(r.url).hostname or ""
                if result_hostname.lower() in BLOCKED_RESULT_DOMAINS:
                    continue
            except Exception:
                pass
            
            r.match_score = calculate_similarity(title, r.title)
            scored_results.append(r)
        
        scored_results.sort(key=lambda r: r.match_score, reverse=True)
        
        # Check for 100% match
        perfect_match = next((r for r in scored_results if r.match_score == 100), None)
        
        if perfect_match:
            # Attempt to fetch from the mirror
            mirror_result = light_fetch(perfect_match.url, timeout)
            
            if mirror_result.success and mirror_result.html:
                return TierResult(
                    success=True,
                    html=mirror_result.html,
                    title=mirror_result.title or title,
                    should_fallback=False,
                    final_url=perfect_match.url,
                )
        
        # No perfect match - return suggestions
        suggestions = [r.url for r in scored_results[:5]]
        
        # Return a result with suggestions attached (handled by caller)
        result = TierResult(
            success=False,
            should_fallback=False,
            error="No exact match found",
        )
        # Attach suggestions as a custom attribute
        result.suggestions = suggestions  # type: ignore
        return result
        
    except requests.RequestException as e:
        result = TierResult(
            success=False,
            should_fallback=False,
            error=f"Search fallback error: {str(e)}",
        )
        result.suggestions = []  # type: ignore
        return result
