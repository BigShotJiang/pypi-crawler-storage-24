"""
OmniFetch - Universal Content Extraction Library

A cross-platform library for intelligent content extraction
with tiered fetching strategies to bypass bot detection and paywalls.
"""

from .fetcher import omni_fetch, fetch_text, fetch_json
from .types import OmniFetchConfig, OmniFetchResult, OutputMode
from .youtube import fetch_youtube_transcript, is_youtube_url

__version__ = "1.1.0"
__all__ = [
    "omni_fetch",
    "fetch_text", 
    "fetch_json",
    "fetch_youtube_transcript",
    "is_youtube_url",
    "OmniFetchConfig",
    "OmniFetchResult",
    "OutputMode",
]
