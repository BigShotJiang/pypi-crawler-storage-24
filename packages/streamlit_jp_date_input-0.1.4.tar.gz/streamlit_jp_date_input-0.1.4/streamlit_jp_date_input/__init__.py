import datetime

import streamlit as st


def _get_calendar_out():
    if not hasattr(_get_calendar_out, "_component"):
        _get_calendar_out._component = st.components.v2.component(
            "streamlit-jp-date-input.streamlit_jp_date_input",
            js="index-*.js",
            html='<div class="react-root"></div>',
        )
    return _get_calendar_out._component


def jp_date_input(
    label: str,
    value: datetime.date | None = None,
    min_value: datetime.date | None = None,
    max_value: datetime.date | None = None,
    key: str | None = None,
) -> datetime.date | None:
    """日本語カレンダー付き日付選択コンポーネント。

    Parameters
    ----------
    label : str
        入力フィールドのラベル。
    value : datetime.date or None
        初期選択日付。None の場合は今日の日付。
    min_value : datetime.date or None
        選択可能な最小日付。
    max_value : datetime.date or None
        選択可能な最大日付。
    key : str or None
        コンポーネントを一意に識別するキー。

    Returns
    -------
    datetime.date or None
        選択された日付、未選択の場合は None。
    """
    if value is None:
        value = datetime.date.today()
    value_str = value.isoformat()
    min_str = min_value.isoformat() if min_value is not None else None
    max_str = max_value.isoformat() if max_value is not None else None

    _calendar_out = _get_calendar_out()
    result = _calendar_out(
        key=key,
        default={"date": value_str},
        data={"label": label, "value": value_str, "min_date": min_str, "max_date": max_str},
        on_date_change=lambda: None,
    )
    date_str = result.get("date") if result else None
    if date_str:
        return datetime.date.fromisoformat(date_str)
    return None
