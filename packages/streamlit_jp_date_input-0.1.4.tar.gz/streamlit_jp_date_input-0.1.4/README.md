# streamlit-jp-date-input

日本語カレンダー付き日付選択コンポーネントです。Streamlit アプリに和暦スタイルのカレンダー UI を追加できます。

## インストール

```bash
pip install streamlit-jp-date-input
```

## 使い方

```python
import streamlit as st
from streamlit_jp_date_input import jp_date_input

date = jp_date_input("日付を選択", min_date="2020-01-01", max_date="2030-12-31")
st.write("選択日:", date)
```

### パラメータ

| パラメータ | 型 | 説明 |
|---|---|---|
| `label` | `str` | 入力フィールドのラベル |
| `value` | `str \| None` | 初期選択日付（YYYY-MM-DD 形式） |
| `min_date` | `str \| None` | 選択可能な最小日付（YYYY-MM-DD 形式） |
| `max_date` | `str \| None` | 選択可能な最大日付（YYYY-MM-DD 形式） |
| `key` | `str \| None` | コンポーネントを一意に識別するキー |

### 戻り値

選択された日付（`YYYY-MM-DD` 形式の `str`）、未選択の場合は `None`。

#### jp_date_input
![alt text](image.png)

#### st.date_input
![alt text](image-1.png)