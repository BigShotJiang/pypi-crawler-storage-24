"""
This algorithm trains a model of numerical tensors dynamically adjusted through indexing, creating clusters of tensors sorted by token type.
This enables training and inference in batch, resulting in an extraordinary increase in speed for both training and inference, even on modest hardware without a GPU.

Copying, editing, sharing, or reverse-engineering this or other algorithms developed by Sapiens Technology®️ is not allowed without prior authorization from the company.
Public posts and comments about the operation of our technologies are also strictly prohibited. Failure to comply with these guidelines will result in legal actions taken by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
from setuptools import setup, find_packages
package_name = 'sapitensors'
version = '1.0.7'
setup(
    name=package_name,
    version=version,
    author='SAPIENS TECHNOLOGY',
    packages=find_packages(),
    install_requires=[
        'utilities-nlp',
        'INFINITE-CONTEXT-WINDOW',
        'sapiens-tokenizer',
        'sapiens-attention',
        'sapiens-generalization',
        'certifi'
    ],
    url='https://github.com/sapiens-technology/sapitensors',
    license='Proprietary Software'
)
"""
This algorithm trains a model of numerical tensors dynamically adjusted through indexing, creating clusters of tensors sorted by token type.
This enables training and inference in batch, resulting in an extraordinary increase in speed for both training and inference, even on modest hardware without a GPU.

Copying, editing, sharing, or reverse-engineering this or other algorithms developed by Sapiens Technology®️ is not allowed without prior authorization from the company.
Public posts and comments about the operation of our technologies are also strictly prohibited. Failure to comply with these guidelines will result in legal actions taken by our legal team.
"""
# --------------------------> A SAPIENS TECHNOLOGY®️ PRODUCTION) <--------------------------
