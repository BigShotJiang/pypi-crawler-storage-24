import os
import re
import subprocess
import sys
import time
from pathlib import Path

import click

from bluefox_cli.templates import TEMPLATES

COMPOSE_DEV = ["docker", "compose", "-f", "docker-compose.yml", "-f", "docker-compose.dev.yml"]


@click.group()
def cli():
    """Bluefox Stack CLI."""


@cli.command()
@click.argument("project_name")
def init(project_name: str):
    """Create a new Bluefox project."""
    project_dir = Path.cwd() / project_name

    if project_dir.exists():
        click.echo(f"Error: directory '{project_name}' already exists.", err=True)
        sys.exit(1)

    click.echo(f"Creating project '{project_name}'...")

    # Create directories
    project_dir.mkdir()
    (project_dir / "migrations" / "versions").mkdir(parents=True)
    (project_dir / "tests").mkdir()

    # Write all template files
    for rel_path, content_fn in TEMPLATES.items():
        file_path = project_dir / rel_path
        file_path.parent.mkdir(parents=True, exist_ok=True)
        file_path.write_text(content_fn(project_name))

    # Initialize uv project and add dependencies
    _run(["uv", "init", "--no-readme"], cwd=project_dir)
    _run(["uv", "add", "bluefox-core>=0.4.0", "bluefox-auth>=0.9.0", "bluefox-components", "alembic", "asyncpg"], cwd=project_dir)
    _run(["uv", "add", "--dev", "bluefox-test", "pytest"], cwd=project_dir)

    click.echo("")
    click.echo(f"Project '{project_name}' created successfully!")
    click.echo("")
    click.echo("Next steps:")
    click.echo(f"  cd {project_name}")
    click.echo("  bfx db migrate initial")
    click.echo("  bfx dev")


@cli.command()
def dev():
    """Start the dev environment (Postgres + Redis + app with hot reload)."""
    _require_project()
    subprocess.run([*COMPOSE_DEV, "up", "--build"])


@cli.group()
def db():
    """Database commands."""


@db.command()
@click.argument("name")
def migrate(name: str):
    """Generate a new migration (auto-detects model changes).

    Starts a temporary Postgres container, runs alembic autogenerate,
    then stops the container. The migration file is written to
    migrations/versions/.
    """
    _require_project()

    db_url = _get_dev_db_url()

    click.echo("Starting database...")
    subprocess.run([*COMPOSE_DEV, "up", "db", "-d"], capture_output=True)

    # Wait for DB to be healthy (use the compose healthcheck)
    for _ in range(30):
        result = subprocess.run(
            [*COMPOSE_DEV, "ps", "db", "--format", "{{.Health}}"],
            capture_output=True,
            text=True,
        )
        if "healthy" in result.stdout:
            break
        time.sleep(1)
    else:
        click.echo("Error: database did not become ready.", err=True)
        subprocess.run([*COMPOSE_DEV, "stop", "db"], capture_output=True)
        sys.exit(1)

    click.echo(f"Generating migration '{name}'...")
    env = {**os.environ, "DATABASE_URL": db_url}
    result = subprocess.run(
        ["uv", "run", "alembic", "revision", "--autogenerate", "-m", name],
        env=env,
    )

    # Stop the temporary DB
    click.echo("Stopping database...")
    subprocess.run([*COMPOSE_DEV, "stop", "db"], capture_output=True)

    if result.returncode != 0:
        sys.exit(result.returncode)

    click.echo("Done! Run 'bfx dev' to apply the migration.")


def _get_dev_db_url() -> str:
    """Extract DATABASE_URL from docker-compose.dev.yml, rewritten for localhost."""
    compose_path = Path.cwd() / "docker-compose.dev.yml"
    content = compose_path.read_text()
    # All DATABASE_URL entries use the same credentials, just different hostnames.
    # Grab any one and rewrite the container hostname to localhost.
    match = re.search(r"DATABASE_URL=(\S+)", content)
    if match:
        return match.group(1).replace("@db:", "@localhost:")
    click.echo("Error: DATABASE_URL not found in docker-compose.dev.yml.", err=True)
    sys.exit(1)


def _require_project() -> None:
    """Abort if not inside a Bluefox project."""
    if not (Path.cwd() / "docker-compose.dev.yml").exists():
        click.echo("Error: not inside a Bluefox project (no docker-compose.dev.yml found).", err=True)
        sys.exit(1)


def _run(cmd: list[str], cwd: Path) -> None:
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        click.echo(f"Error running {' '.join(cmd)}:", err=True)
        click.echo(result.stderr, err=True)
        sys.exit(1)
