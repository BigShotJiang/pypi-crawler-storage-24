# (c) Copyright 2025 Perceptic Technologies Ltd. All rights reserved.
#
# AUTO-GENERATED FILE - DO NOT EDIT
# Generated from: get-events-query-response.schema.json

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict
from pydantic.alias_generators import to_camel



class GetEventsQueryResponse(BaseModel):
    """
    Response payload for paginated workflow event queries.
    """

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
        frozen=True,
    )

    events: list[dict[str, Any]]
    """
    Workflow events for the current page.
    """

    next_page_token: str | None = None
    """
    Opaque token to request the next page.
    """

