from setuptools import setup, find_packages

setup(
    name="ai-xray",
    version="0.0.1",
    author="10iii",
    author_email="10iiishisan@gmail.com",
    description="AI Model Diagnostics Toolkit (Placeholder for npm package 'ai-xray')",
    long_description="For the actual tool, please install via npm: `npm install -g ai-xray`",
    long_description_content_type="text/markdown",
    url="https://github.com/10iii/bi",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
