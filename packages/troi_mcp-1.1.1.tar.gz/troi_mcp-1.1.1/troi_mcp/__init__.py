"""Troi MCP Server - connects Claude Desktop to Troi project management."""

__version__ = "1.1.1"
