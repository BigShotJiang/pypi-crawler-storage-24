"""Tests for the analytics module."""

from aitypingstats.analytics import (
    SessionAnalytics,
    classify_developer,
    classify_focus,
)


class TestClassifyDeveloper:
    def test_code_monk(self):
        name, emoji, msg = classify_developer(95.0)
        assert name == "Code Monk"

    def test_code_monk_boundary(self):
        name, _, _ = classify_developer(80.0)
        assert name == "Code Monk"

    def test_ai_collaborator(self):
        name, _, _ = classify_developer(65.0)
        assert name == "AI Collaborator"

    def test_ai_collaborator_boundary(self):
        name, _, _ = classify_developer(50.0)
        assert name == "AI Collaborator"

    def test_prompt_engineer(self):
        name, _, _ = classify_developer(30.0)
        assert name == "Prompt Engineer"

    def test_prompt_engineer_zero(self):
        name, _, _ = classify_developer(0.0)
        assert name == "Prompt Engineer"


class TestClassifyFocus:
    def test_deep_focus(self):
        assert "Deep Focus" in classify_focus(90.0)

    def test_moderate_focus(self):
        assert "Moderate Focus" in classify_focus(60.0)

    def test_distracted(self):
        assert "Distracted" in classify_focus(30.0)

    def test_boundary_50(self):
        assert "Moderate Focus" in classify_focus(50.0)


class TestSessionAnalytics:
    def test_from_session_data(self):
        data = {
            "session_time": 120.5,
            "total_keystrokes": 500,
            "char_count": 400,
            "typed_chars": 350,
            "pasted_chars": 50,
            "wpm": 45.2,
            "self_percent": 87.5,
            "ai_percent": 12.5,
            "corrections": 20,
            "paste_events": 2,
            "focus_score": 75.0,
            "word_count": 90,
        }
        analytics = SessionAnalytics.from_session_data(data)

        assert analytics.self_percent == 87.5
        assert analytics.ai_percent == 12.5
        assert analytics.avg_wpm == 45.2
        assert analytics.total_corrections == 20
        assert analytics.focus_score == 75.0
        assert analytics.dev_type == "Code Monk"
        assert "Moderate Focus" in analytics.focus_level

    def test_from_empty_data(self):
        analytics = SessionAnalytics.from_session_data({})
        assert analytics.self_percent == 100.0
        assert analytics.ai_percent == 0.0
        assert analytics.dev_type == "Code Monk"
