# ⌨️ AI Typing Stats

**Track your real coding effort.**

A terminal-based developer productivity tool that tracks your typing behavior and tells you how much work you *actually* typed versus what came from AI or clipboard pastes.

![Python](https://img.shields.io/badge/python-3.10%2B-blue)
![License](https://img.shields.io/badge/license-MIT-green)
![PyPI](https://img.shields.io/pypi/v/aitypingstats)

## ✨ Features

- **Real-time Dashboard** — Live WPM, self vs AI bars, focus score, and correction count
- **Paste Detection** — Detects Cmd/Ctrl+V and rapid-input bursts as AI-assisted input
- **Developer Personality** — Classifies you as Code Monk 🧘, AI Collaborator 🤝, or Prompt Engineer 🚀
- **Focus Score** — Measures active typing time vs idle time
- **Fun Alerts** — Real-time messages like "Speed Demon ⚡" and "Perfection mode ON ✨"
- **Session History** — Tracks daily streaks, lifetime averages, and past sessions
- **Beautiful Terminal UI** — Powered by Rich

## 🚀 Installation

```bash
pip install aitypingstats
```

### macOS Note

On macOS, you need to grant **Accessibility** permissions to your terminal app for keyboard tracking:

> System Settings → Privacy & Security → Accessibility → Enable your terminal app

## 📖 Usage

### Start a tracking session

```bash
aitype start
```

Type anywhere while the tracker is running. Press **Ctrl+C** to stop and see your results.

### View session history

```bash
aitype stats
```

### Reset all data

```bash
aitype reset
```

### About

```bash
aitype about
```

## 📊 What It Tracks

| Metric | Description |
|--------|-------------|
| Self Typed % | Characters you typed manually |
| AI/Pasted % | Characters from paste or rapid input |
| WPM | Words per minute |
| Corrections | Backspace + Delete count |
| Focus Score | Active typing time / total session time |
| Dev Type | Code Monk, AI Collaborator, or Prompt Engineer |
| Streak | Consecutive days with sessions |

## 🧑‍💻 Developer Personality Types

| Self Work % | Type | Emoji |
|-------------|------|-------|
| ≥ 80% | Code Monk | 🧘 |
| 50–79% | AI Collaborator | 🤝 |
| < 50% | Prompt Engineer | 🚀 |

## 🏗️ Project Structure

```
aitypingstats/
├── pyproject.toml
├── requirements.txt
├── README.md
├── LICENSE
├── aitypingstats/
│   ├── __init__.py
│   ├── __main__.py
│   ├── cli.py         # Typer CLI commands
│   ├── tracker.py     # Keyboard tracking (pynput)
│   ├── analytics.py   # Stats & classification
│   ├── ui.py          # Rich dashboard & summary
│   └── storage.py     # JSON session storage
└── tests/
    ├── __init__.py
    └── test_analytics.py
```

## 🛠️ Development

```bash
git clone https://github.com/ritvikmudgal/aitypingstats.git
cd aitypingstats
python -m venv .venv
source .venv/bin/activate
pip install -e .
aitype start
```

## 📦 Publishing to PyPI

```bash
pip install build twine
python -m build
twine upload dist/*
```

## 📝 License

MIT — see [LICENSE](LICENSE)

## 👤 Author

**Ritvik Mudgal**

---

*Built with ❤️ for developers who care about their craft.*
