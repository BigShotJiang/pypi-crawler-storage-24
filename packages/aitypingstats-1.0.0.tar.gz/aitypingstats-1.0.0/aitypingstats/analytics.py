"""Analytics and classification module.

Computes developer personality, focus level, and session summaries.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SessionAnalytics:
    """Immutable analytics computed from a finished tracker session."""

    self_percent: float
    ai_percent: float
    avg_wpm: float
    total_corrections: int
    focus_score: float
    session_duration: float
    total_keystrokes: int
    total_chars: int
    typed_chars: int
    pasted_chars: int
    paste_events: int
    word_count: int
    dev_type: str
    dev_emoji: str
    dev_message: str
    focus_level: str

    @classmethod
    def from_session_data(cls, data: dict) -> SessionAnalytics:
        """Build analytics from a tracker snapshot / session dict."""
        self_pct = data.get("self_percent", 100.0)
        dev_type, dev_emoji, dev_message = classify_developer(self_pct)
        focus = data.get("focus_score", 0.0)
        focus_level = classify_focus(focus)

        return cls(
            self_percent=round(self_pct, 1),
            ai_percent=round(data.get("ai_percent", 0.0), 1),
            avg_wpm=round(data.get("wpm", 0.0), 1),
            total_corrections=data.get("corrections", 0),
            focus_score=round(focus, 1),
            session_duration=round(data.get("session_time", 0.0), 1),
            total_keystrokes=data.get("total_keystrokes", 0),
            total_chars=data.get("char_count", 0),
            typed_chars=data.get("typed_chars", 0),
            pasted_chars=data.get("pasted_chars", 0),
            paste_events=data.get("paste_events", 0),
            word_count=data.get("word_count", 0),
            dev_type=dev_type,
            dev_emoji=dev_emoji,
            dev_message=dev_message,
            focus_level=focus_level,
        )


# ------------------------------------------------------------------
# Classification helpers
# ------------------------------------------------------------------

def classify_developer(self_percent: float) -> tuple[str, str, str]:
    """Return (type_name, emoji, tagline) based on self-typed %."""
    if self_percent >= 80:
        return (
            "Code Monk",
            "\U0001f9d8",
            "Pure craftsmanship. You write your own destiny.",
        )
    if self_percent >= 50:
        return (
            "AI Collaborator",
            "\U0001f91d",
            "Best of both worlds. Human + AI synergy.",
        )
    return (
        "Prompt Engineer",
        "\U0001f680",
        "Why type when AI can do it? Work smarter, not harder.",
    )


def classify_focus(focus_score: float) -> str:
    """Return a labelled focus level string."""
    if focus_score > 80:
        return "\U0001f3af Deep Focus"
    if focus_score >= 50:
        return "\u26a1 Moderate Focus"
    return "\U0001f634 Distracted Session"
