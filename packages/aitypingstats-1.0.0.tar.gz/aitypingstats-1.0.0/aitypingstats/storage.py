"""Local JSON storage for session history.

Session data is stored in ``~/.aitypingstats/sessions.json``.
"""

from __future__ import annotations

import json
from datetime import date, datetime
from pathlib import Path
from typing import Any

DATA_DIR = Path.home() / ".aitypingstats"
DATA_FILE = DATA_DIR / "sessions.json"


def _ensure_dir() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)


def _load() -> list[dict[str, Any]]:
    """Load all sessions from disk."""
    _ensure_dir()
    if not DATA_FILE.exists():
        return []
    try:
        return json.loads(DATA_FILE.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return []


# ------------------------------------------------------------------
# Public API
# ------------------------------------------------------------------

def save_session(data: dict[str, Any]) -> None:
    """Append a session record to storage."""
    sessions = _load()
    sessions.append(data)
    _ensure_dir()
    DATA_FILE.write_text(json.dumps(sessions, indent=2), encoding="utf-8")


def load_all_sessions() -> list[dict[str, Any]]:
    """Return every stored session."""
    return _load()


def get_streak() -> int:
    """Calculate the current daily streak (consecutive days with a session)."""
    sessions = _load()
    if not sessions:
        return 0

    session_dates: set[date] = set()
    for s in sessions:
        try:
            session_dates.add(datetime.fromisoformat(s["date"]).date())
        except (KeyError, ValueError):
            continue
    if not session_dates:
        return 0

    sorted_dates = sorted(session_dates, reverse=True)
    today = date.today()

    # Streak must include today or yesterday
    if sorted_dates[0] != today and (today - sorted_dates[0]).days > 1:
        return 0

    streak = 1
    for i in range(1, len(sorted_dates)):
        if (sorted_dates[i - 1] - sorted_dates[i]).days == 1:
            streak += 1
        else:
            break
    return streak


def reset_data() -> bool:
    """Delete all saved sessions. Returns True on success."""
    try:
        if DATA_FILE.exists():
            DATA_FILE.unlink()
        return True
    except OSError:
        return False
