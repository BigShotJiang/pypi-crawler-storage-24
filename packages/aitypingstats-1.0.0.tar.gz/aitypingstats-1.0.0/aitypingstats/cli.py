"""CLI entry-points powered by Typer.

Commands:
    aitype start   - Begin a live tracking session
    aitype stats   - View session history
    aitype reset   - Delete all stored data
    aitype about   - Show project info
"""

from __future__ import annotations

import time

import typer
from rich.live import Live
from rich.panel import Panel
from rich.text import Text

from aitypingstats import __version__
from aitypingstats.analytics import SessionAnalytics
from aitypingstats.storage import load_all_sessions, reset_data, save_session
from aitypingstats.tracker import TypingTracker
from aitypingstats.ui import build_dashboard, console, show_history, show_summary

app = typer.Typer(
    name="aitype",
    help="\U0001f680 AI Typing Stats \u2014 Track your real coding effort.",
    add_completion=False,
)


@app.command()
def start() -> None:
    """Start a new typing-tracking session."""
    console.print(
        Panel(
            Text(
                "Starting AI Typing Stats\u2026\n"
                "Type anywhere \u2014 we\u2019re tracking!\n"
                "Press Ctrl+C to stop and see your results.",
                justify="center",
            ),
            title="\u2328\ufe0f  AI TYPING STATS",
            border_style="cyan",
        )
    )

    tracker = TypingTracker()
    tracker.start()

    try:
        with Live(
            build_dashboard(tracker),
            refresh_per_second=4,
            console=console,
        ) as live:
            while True:
                time.sleep(0.25)
                live.update(build_dashboard(tracker))
    except KeyboardInterrupt:
        pass
    finally:
        tracker.stop()

    # ---- End-of-session ----
    session_data = tracker.get_session_data()
    analytics = SessionAnalytics.from_session_data(session_data)
    save_session(session_data)
    show_summary(analytics)


@app.command()
def stats() -> None:
    """View your typing history and lifetime stats."""
    sessions = load_all_sessions()
    show_history(sessions)


@app.command()
def reset() -> None:
    """Delete all saved session data."""
    confirm = typer.confirm("Are you sure you want to delete all session data?")
    if confirm:
        if reset_data():
            console.print("[green]\u2705 All session data has been reset.[/green]")
        else:
            console.print("[red]\u274c Failed to reset data.[/red]")
    else:
        console.print("[yellow]Reset cancelled.[/yellow]")


@app.command()
def about() -> None:
    """Show project info."""
    console.print(
        Panel(
            Text.from_markup(
                "[bold cyan]AI Typing Stats[/bold cyan]\n"
                f"[dim]Version {__version__}[/dim]\n\n"
                "[bold]Built by Ritvik Mudgal[/bold]\n\n"
                "Track your real coding effort.\n"
                "Analyze typing speed, AI usage, focus, and more.\n\n"
                "[dim]https://github.com/ritvikmudgal/aitypingstats[/dim]"
            ),
            title="\u2139\ufe0f  About",
            border_style="cyan",
            padding=(1, 2),
        )
    )


def main() -> None:
    """Package entry-point."""
    app()
