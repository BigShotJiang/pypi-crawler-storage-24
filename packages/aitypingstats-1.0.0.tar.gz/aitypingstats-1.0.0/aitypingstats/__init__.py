"""AI Typing Stats — Track your real coding effort."""

__version__ = "1.0.0"
__author__ = "Ritvik Mudgal"
