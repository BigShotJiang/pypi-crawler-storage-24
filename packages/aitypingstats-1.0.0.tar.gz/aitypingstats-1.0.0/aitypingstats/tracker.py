"""Keyboard tracking module.

Uses pynput to capture keystrokes and detect paste events, typing speed,
corrections, and focus metrics in real time.
"""

import platform
import subprocess
import time
from collections import deque
from datetime import datetime
from threading import Lock

from pynput import keyboard


class TypingTracker:
    """Tracks keyboard events and computes live typing metrics."""

    IDLE_THRESHOLD = 3.0        # Seconds of no input before considered idle
    PASTE_CHAR_THRESHOLD = 20   # Min chars in burst to flag as paste
    PASTE_TIME_WINDOW = 0.1     # Max seconds for burst detection

    def __init__(self):
        # Counters
        self.total_keystrokes: int = 0
        self.char_count: int = 0          # All printable chars (typed + pasted)
        self.backspace_count: int = 0
        self.delete_count: int = 0
        self.paste_char_count: int = 0
        self.paste_events: int = 0
        self.word_count: int = 0

        # Timing
        self.session_start: float | None = None
        self.active_typing_time: float = 0.0
        self._last_active: float | None = None
        self._current_word_len: int = 0

        # Paste detection helpers
        self._recent_ts: deque[float] = deque(maxlen=50)
        self._modifiers_held: set = set()

        # Alerts queue (consumed by UI)
        self.alerts: list[str] = []

        # State
        self._lock = Lock()
        self._running = False
        self._listener: keyboard.Listener | None = None

    # ------------------------------------------------------------------
    # Clipboard helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _clipboard_length() -> int:
        """Return the character count of the current clipboard content."""
        try:
            system = platform.system()
            if system == "Darwin":
                cmd = ["pbpaste"]
            elif system == "Linux":
                cmd = ["xclip", "-selection", "clipboard", "-o"]
            elif system == "Windows":
                cmd = ["powershell", "-command", "Get-Clipboard"]
            else:
                return 0
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=1)
            return len(result.stdout) if result.returncode == 0 else 0
        except Exception:
            return 0

    # ------------------------------------------------------------------
    # Alert generation
    # ------------------------------------------------------------------

    def _push_alert(self, alert_type: str, value: int = 0) -> None:
        """Add contextual alerts based on typing behaviour."""
        if alert_type == "paste" and value > 10:
            self.alerts.append("\U0001f916 Heavy AI usage detected!")
        elif alert_type == "corrections":
            if self.corrections > 0 and self.corrections % 20 == 0:
                self.alerts.append("\u2728 Perfection mode ON!")
        # Speed check (keep at most one recent speed alert)
        if self.wpm > 80 and not any("Speed Demon" in a for a in self.alerts[-3:]):
            self.alerts.append("\u26a1 Speed Demon!")

    # ------------------------------------------------------------------
    # Key event handlers
    # ------------------------------------------------------------------

    def _on_press(self, key) -> None:  # noqa: C901
        """Handle a key-press event from pynput."""
        if not self._running:
            return

        now = time.time()

        with self._lock:
            self.total_keystrokes += 1
            self._update_active_time(now)

            # ---- Track modifier state (Cmd / Ctrl) ----
            if key in (
                keyboard.Key.cmd, keyboard.Key.cmd_r,
                keyboard.Key.ctrl_l, keyboard.Key.ctrl_r,
            ):
                self._modifiers_held.add(key)
                return

            # ---- Detect Cmd+V / Ctrl+V  → paste ----
            is_paste = False
            try:
                if hasattr(key, "char") and key.char and key.char.lower() == "v":
                    if self._modifiers_held & {
                        keyboard.Key.cmd, keyboard.Key.cmd_r,
                        keyboard.Key.ctrl_l, keyboard.Key.ctrl_r,
                    }:
                        is_paste = True
            except AttributeError:
                pass

            if is_paste:
                clip_len = self._clipboard_length()
                if clip_len > 0:
                    self.paste_char_count += clip_len
                    self.char_count += clip_len
                    self.paste_events += 1
                    self.word_count += max(1, clip_len // 5)
                    self._push_alert("paste", clip_len)
                return

            # ---- Backspace / Delete ----
            if key == keyboard.Key.backspace:
                self.backspace_count += 1
                self._current_word_len = max(0, self._current_word_len - 1)
                self._push_alert("corrections")
                return
            if key == keyboard.Key.delete:
                self.delete_count += 1
                self._push_alert("corrections")
                return

            # ---- Space / Enter / Tab  → word boundary ----
            if key in (keyboard.Key.space, keyboard.Key.enter, keyboard.Key.tab):
                if self._current_word_len > 0:
                    self.word_count += 1
                    self._current_word_len = 0
                self.char_count += 1
                self._recent_ts.append(now)
                return

            # ---- Regular character ----
            try:
                if key.char:
                    self.char_count += 1
                    self._current_word_len += 1
                    self._recent_ts.append(now)

                    # Rapid-input paste heuristic
                    if self._check_rapid_input(now):
                        self.paste_char_count += self.PASTE_CHAR_THRESHOLD
                        self.paste_events += 1
                        self._recent_ts.clear()
                        self._push_alert("paste", self.PASTE_CHAR_THRESHOLD)
            except AttributeError:
                pass

    def _on_release(self, key) -> None:
        """Track modifier key releases."""
        self._modifiers_held.discard(key)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _update_active_time(self, now: float) -> None:
        if self._last_active is not None:
            gap = now - self._last_active
            if gap < self.IDLE_THRESHOLD:
                self.active_typing_time += gap
        self._last_active = now

    def _check_rapid_input(self, now: float) -> bool:
        """Return True if the last N chars arrived within the paste window."""
        n = self.PASTE_CHAR_THRESHOLD
        if len(self._recent_ts) >= n:
            return (now - self._recent_ts[-n]) < self.PASTE_TIME_WINDOW
        return False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self) -> None:
        """Start keyboard listener."""
        self.session_start = time.time()
        self._last_active = self.session_start
        self._running = True
        self._listener = keyboard.Listener(
            on_press=self._on_press,
            on_release=self._on_release,
        )
        self._listener.start()

    def stop(self) -> None:
        """Stop keyboard listener and finalise counts."""
        self._running = False
        if self._current_word_len > 0:
            self.word_count += 1
        if self._listener:
            self._listener.stop()
            self._listener.join(timeout=2)

    # ---- Computed properties ----

    @property
    def session_time(self) -> float:
        """Total elapsed seconds since session start."""
        if self.session_start is None:
            return 0.0
        return time.time() - self.session_start

    @property
    def typed_char_count(self) -> int:
        """Characters typed manually (total − pasted)."""
        return max(0, self.char_count - self.paste_char_count)

    @property
    def self_percent(self) -> float:
        if self.char_count == 0:
            return 100.0
        return (self.typed_char_count / self.char_count) * 100

    @property
    def ai_percent(self) -> float:
        return 100.0 - self.self_percent

    @property
    def wpm(self) -> float:
        """Words per minute."""
        minutes = self.session_time / 60
        if minutes < 0.1:
            return 0.0
        return self.word_count / minutes

    @property
    def corrections(self) -> int:
        return self.backspace_count + self.delete_count

    @property
    def focus_score(self) -> float:
        """Active typing time / total session time × 100."""
        if self.session_time == 0:
            return 0.0
        return min(100.0, (self.active_typing_time / self.session_time) * 100)

    def pop_alert(self) -> str | None:
        """Return and remove the oldest pending alert, or None."""
        if self.alerts:
            return self.alerts.pop(0)
        return None

    def get_snapshot(self) -> dict:
        """Return a dict snapshot of all current metrics (thread-safe)."""
        with self._lock:
            return {
                "session_time": round(self.session_time, 1),
                "total_keystrokes": self.total_keystrokes,
                "char_count": self.char_count,
                "typed_chars": self.typed_char_count,
                "pasted_chars": self.paste_char_count,
                "wpm": round(self.wpm, 1),
                "self_percent": round(self.self_percent, 1),
                "ai_percent": round(self.ai_percent, 1),
                "corrections": self.corrections,
                "backspaces": self.backspace_count,
                "deletes": self.delete_count,
                "paste_events": self.paste_events,
                "focus_score": round(self.focus_score, 1),
                "word_count": self.word_count,
            }

    def get_session_data(self) -> dict:
        """Return final session data suitable for storage."""
        snap = self.get_snapshot()
        snap["date"] = datetime.now().isoformat()
        snap["duration"] = snap["session_time"]
        return snap
