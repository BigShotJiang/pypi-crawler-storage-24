"""Entry point for `python -m aitypingstats`."""

from aitypingstats.cli import main

main()
