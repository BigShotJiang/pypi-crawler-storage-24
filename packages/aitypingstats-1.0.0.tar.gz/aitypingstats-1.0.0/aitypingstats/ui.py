"""Rich-based terminal UI components.

Provides the live dashboard, session summary card, and history views.
"""

from __future__ import annotations

from datetime import datetime

from rich.align import Align
from rich.console import Console
from rich.layout import Layout
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

from aitypingstats.analytics import SessionAnalytics
from aitypingstats.storage import get_streak

console = Console()


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _fmt_time(seconds: float) -> str:
    """Format seconds as HH:MM:SS or MM:SS."""
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    return f"{h:02d}:{m:02d}:{s:02d}" if h else f"{m:02d}:{s:02d}"


def _bar(percent: float, color: str, width: int = 25) -> Text:
    """Render a coloured block-character bar."""
    filled = int(percent / 100 * width)
    return Text("\u2588" * filled + "\u2591" * (width - filled), style=color)


# ------------------------------------------------------------------
# Live dashboard (called every ~0.25 s while a session is active)
# ------------------------------------------------------------------

def build_dashboard(tracker) -> Layout:
    """Build the Rich Layout shown during a live session."""
    snap = tracker.get_snapshot()

    layout = Layout()
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="body"),
        Layout(name="alerts", size=4),
    )
    layout["body"].split_row(
        Layout(name="left"),
        Layout(name="right"),
    )

    # ---- Header ----
    layout["header"].update(
        Panel(
            Align.center(Text("\u2328\ufe0f  AI TYPING STATS", style="bold cyan")),
            style="cyan",
        )
    )

    # ---- Left panel: live metrics ----
    lt = Table(show_header=False, box=None, padding=(0, 2))
    lt.add_column("metric", style="bold white")
    lt.add_column("value", style="green")
    lt.add_row("\u23f1  Session Time", _fmt_time(snap["session_time"]))
    lt.add_row("\u2328\ufe0f  Keystrokes", str(snap["total_keystrokes"]))
    lt.add_row("\U0001f4dd Characters", str(snap["char_count"]))
    lt.add_row("\U0001f4a8 Current WPM", f"{snap['wpm']:.0f}")
    lt.add_row("\U0001f527 Corrections", str(snap["corrections"]))
    lt.add_row("\U0001f3af Focus Score", f"{snap['focus_score']:.0f}%")
    layout["left"].update(
        Panel(lt, title="\U0001f4ca Live Stats", border_style="green")
    )

    # ---- Right panel: self vs AI ----
    rt = Table(show_header=False, box=None, padding=(0, 2))
    rt.add_column("metric", style="bold white")
    rt.add_column("value", style="yellow")
    rt.add_row("\U0001f9d1 Self Typed", f"{snap['self_percent']:.1f}%")
    rt.add_row("", _bar(snap["self_percent"], "green"))
    rt.add_row("\U0001f916 AI / Pasted", f"{snap['ai_percent']:.1f}%")
    rt.add_row("", _bar(snap["ai_percent"], "red"))
    rt.add_row("", Text(""))
    rt.add_row("\U0001f4ca Typed Chars", str(snap["typed_chars"]))
    rt.add_row("\U0001f4cb Pasted Chars", str(snap["pasted_chars"]))
    layout["right"].update(
        Panel(rt, title="\U0001f9ee Work Analysis", border_style="yellow")
    )

    # ---- Alerts bar ----
    alert = tracker.pop_alert()
    if alert:
        alert_text = Text(alert, style="bold magenta")
    else:
        alert_text = Text(
            "Tracking\u2026 Press Ctrl+C to stop and see results.", style="dim"
        )
    layout["alerts"].update(
        Panel(Align.center(alert_text), title="\U0001f4ac Alerts", border_style="magenta")
    )

    return layout


# ------------------------------------------------------------------
# Session summary card
# ------------------------------------------------------------------

def show_summary(analytics: SessionAnalytics) -> None:
    """Display the end-of-session summary panel."""
    streak = get_streak()

    t = Table(show_header=False, box=None, padding=(0, 2), expand=True)
    t.add_column("metric", style="bold cyan", width=20)
    t.add_column("value", style="bold white")

    t.add_row("\U0001f9d1 Self Work", f"{analytics.self_percent}%")
    t.add_row("\U0001f916 AI Work", f"{analytics.ai_percent}%")
    t.add_row("\U0001f4a8 Avg WPM", str(analytics.avg_wpm))
    t.add_row("\U0001f527 Corrections", str(analytics.total_corrections))
    t.add_row("\U0001f3af Focus Score", f"{analytics.focus_score}%")
    t.add_row("\U0001f4c8 Focus Level", analytics.focus_level)
    t.add_row("\u23f1  Duration", _fmt_time(analytics.session_duration))
    t.add_row("\u2328\ufe0f  Keystrokes", str(analytics.total_keystrokes))
    t.add_row("", "")
    t.add_row(
        f"{analytics.dev_emoji} Dev Type",
        f"[bold yellow]{analytics.dev_type}[/bold yellow]",
    )
    t.add_row("", f"[dim]{analytics.dev_message}[/dim]")
    t.add_row("", "")
    t.add_row(
        "\U0001f525 Streak",
        f"{streak} day{'s' if streak != 1 else ''} \U0001f525",
    )

    panel = Panel(
        t,
        title="[bold cyan]\U0001f4ca SESSION SUMMARY[/bold cyan]",
        subtitle="[dim]Created by: Ritvik Mudgal[/dim]",
        border_style="cyan",
        padding=(1, 2),
    )
    console.print()
    console.print(panel)
    console.print()


# ------------------------------------------------------------------
# History / stats view
# ------------------------------------------------------------------

def show_history(sessions: list[dict]) -> None:
    """Display historical session data in a table."""
    if not sessions:
        console.print(
            "[yellow]No sessions recorded yet. "
            "Run [bold]aitype start[/bold] first![/yellow]"
        )
        return

    streak = get_streak()

    table = Table(title="\U0001f4c8 Session History", border_style="cyan")
    table.add_column("#", style="dim", width=4)
    table.add_column("Date", style="cyan")
    table.add_column("Duration", justify="right")
    table.add_column("WPM", justify="right", style="green")
    table.add_column("Self %", justify="right", style="yellow")
    table.add_column("Focus %", justify="right", style="magenta")
    table.add_column("Type", style="bold")

    for i, s in enumerate(sessions[-10:], 1):
        try:
            dt = datetime.fromisoformat(s["date"])
            date_str = dt.strftime("%Y-%m-%d %H:%M")
        except (KeyError, ValueError):
            date_str = "Unknown"

        from aitypingstats.analytics import classify_developer

        dev_type, _, _ = classify_developer(s.get("self_percent", 100))
        table.add_row(
            str(i),
            date_str,
            _fmt_time(s.get("duration", 0)),
            str(s.get("wpm", 0)),
            f"{s.get('self_percent', 0):.1f}%",
            f"{s.get('focus_score', 0):.1f}%",
            dev_type,
        )

    console.print()
    console.print(table)
    console.print(
        f"\n\U0001f525 Current Streak: "
        f"[bold]{streak} day{'s' if streak != 1 else ''}[/bold] \U0001f525"
    )

    # Lifetime averages
    n = len(sessions)
    avg_wpm = sum(s.get("wpm", 0) for s in sessions) / n
    avg_self = sum(s.get("self_percent", 0) for s in sessions) / n
    avg_focus = sum(s.get("focus_score", 0) for s in sessions) / n

    console.print(
        Panel(
            f"[bold]Avg WPM:[/bold] {avg_wpm:.1f}  |  "
            f"[bold]Avg Self %:[/bold] {avg_self:.1f}%  |  "
            f"[bold]Avg Focus:[/bold] {avg_focus:.1f}%  |  "
            f"[bold]Total Sessions:[/bold] {n}",
            title="\U0001f4ca Lifetime Averages",
            border_style="green",
        )
    )
    console.print()
