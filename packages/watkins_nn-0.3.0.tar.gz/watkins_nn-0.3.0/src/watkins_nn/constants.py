"""
Mathematical constants for Watkins dynamics.

All values certified via mpmath 50-digit computation.
External certificate: mpmath verification (sealed March 8, 2026).
"""

import math

# Golden ratio
PHI = (1 + math.sqrt(5)) / 2  # 1.6180339887498948

# Watkins temperature (2-simplex)
T_STAR = PHI / math.log(2 * PHI)  # 1.3778018314733997

# Watkins temperature (3-simplex / VirelaiX)
T_STAR3 = PHI / math.log(3 * PHI)  # 1.024186157617269

# Golden equilibrium
LAM_STAR = 1 / PHI  # 0.6180339887498948

# Equilibrium curvature/entropy (2-simplex, Z2 symmetry)
KAP_STAR = (1 - LAM_STAR) / 2  # 0.1909830056250526
ETA_STAR = KAP_STAR

# Global strong-convexity modulus
M_PHI = 4.2104143547

# Optimal step sizes
TAU_GLOBAL = 1 / M_PHI  # 0.2375
TAU_LOCAL = 0.168509  # Local refinement

# Watkins bridge constant W^2 = ln(phi)/ln(2)
W_SQUARED = math.log(PHI) / math.log(2)  # 0.694241913630617

# Grand Unifier constants (Phase 85.2)
BETA_STAR = PHI ** (2 * W_SQUARED)  # 1.9506347581024640

# 3-simplex equilibrium (Z3 symmetry)
RHO_STAR = (1 - LAM_STAR) / 3  # 0.127322003750035

# Peak integrated information
PHI_MAX = 0.331315  # m(phi) * lam_star * rho_star

# Spectral bounds (Hessian eigenvalues at equilibrium)
# d2F/dlam2 = 1/lam*^2 + T*/lam* = 4.847, d2F/dkap2 = T*/kap* = 7.215
MU_SLOW = 1 / LAM_STAR**2 + T_STAR / LAM_STAR   # ~4.847
MU_FAST = T_STAR / KAP_STAR                       # ~7.215

# Backward compatibility aliases
WATKINS_LAMBDA = LAM_STAR
WATKINS_KAPPA = KAP_STAR
WATKINS_ETA = ETA_STAR
