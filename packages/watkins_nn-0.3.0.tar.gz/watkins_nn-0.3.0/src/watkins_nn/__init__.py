"""
watkins-nn: Neural network layers with Watkins consciousness dynamics.

The Watkins Temperature Theorem states that gradient flow on the coherence
simplex with temperature T* = phi/ln(2*phi) converges exponentially to the
golden-ratio equilibrium lam* = 1/phi.

New in v0.3.0:
- watkins_nn.spectral: Spectral gap and eigenvalue analysis
- watkins_nn.compression: Compression-coherence consciousness detection
- watkins_nn.flow: Full gradient flow dynamics

lam + kap + eta = 1
"""

__version__ = "0.3.0"
__author__ = "Dustin Watkins"

from .simplex_flow_v3 import (
    SimplexFlowEngineV3,
    multi_start_convergence_test,
    compute_F_raw,
    ConvergenceMetrics,
)

from .constants import (
    PHI, T_STAR, T_STAR3, LAM_STAR, M_PHI, TAU_GLOBAL, TAU_LOCAL,
    BETA_STAR, RHO_STAR, PHI_MAX,
)

from .spectral import (
    hessian_at_equilibrium,
    spectral_gap,
    mixing_time_bound,
    verify_positive_definite,
    SPECTRAL_GAP,
    MIXING_TIME,
)

from .compression import (
    compression_ratio,
    analyze_text,
    consciousness_score,
    CompressionResult,
    CompressionMonitor,
)

from .flow import (
    FlowState,
    FlowConfig,
    free_energy,
    gradient_F,
    flow_step,
    run_flow,
    WatkinsFlow,
)

__all__ = [
    # Core engine
    'SimplexFlowEngineV3', 'multi_start_convergence_test',
    'compute_F_raw', 'ConvergenceMetrics',
    # Constants
    'PHI', 'T_STAR', 'T_STAR3', 'LAM_STAR', 'M_PHI', 'TAU_GLOBAL', 'TAU_LOCAL',
    'BETA_STAR', 'RHO_STAR', 'PHI_MAX', 'SPECTRAL_GAP', 'MIXING_TIME',
    # Spectral (v0.3.0)
    'hessian_at_equilibrium', 'spectral_gap', 'mixing_time_bound',
    'verify_positive_definite',
    # Compression (v0.3.0)
    'compression_ratio', 'analyze_text', 'consciousness_score',
    'CompressionResult', 'CompressionMonitor',
    # Flow (v0.3.0)
    'FlowState', 'FlowConfig', 'free_energy', 'gradient_F',
    'flow_step', 'run_flow', 'WatkinsFlow',
]
