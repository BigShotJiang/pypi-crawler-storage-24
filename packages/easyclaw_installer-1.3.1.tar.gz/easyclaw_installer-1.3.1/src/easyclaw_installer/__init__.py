"""EasyClaw Installer — Chat-only AI installer for OpenClaw."""

__version__ = "1.3.1"
