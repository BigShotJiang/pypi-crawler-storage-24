# sec-edgar-sdk

Python SDK for the [SEC EDGAR Data API](https://rapidapi.com/LiamAltie/api/sec-edgar-data-api). Get clean financial data from SEC EDGAR without parsing XBRL.

**[Browse the data on secedgardata.com](https://secedgardata.com)** — Free dashboard for 10,000+ companies.

## Install

```bash
pip install sec-edgar-sdk
```

## Quick start

```python
from sec_edgar import SecEdgar

api = SecEdgar("YOUR_RAPIDAPI_KEY")

# Company info
company = api.company("AAPL")
print(company["name"])  # Apple Inc.

# Search
results = api.search("tesla")
print(results[0]["ticker"])  # TSLA

# Revenue (shortcut)
for year in api.revenue("AAPL", limit=3):
    print(f"FY{year['fiscal_year']}: ${year['value']:,.0f}")

# FY2025: $383,285,000,000
# FY2024: $394,328,000,000
# FY2023: $365,817,000,000
```

## API methods

| Method | Description |
|--------|-------------|
| `api.company(ticker)` | Company info (CIK, SIC, state, etc.) |
| `api.search(query, limit=10)` | Search companies by name or ticker |
| `api.filings(ticker, form=None, limit=20)` | SEC filing history |
| `api.financials(ticker, statement=None, annual=True, limit=10)` | Financial statements |
| `api.revenue(ticker, limit=10)` | Revenue history (shortcut) |
| `api.net_income(ticker, limit=10)` | Net income history (shortcut) |

### Financial statements

```python
# Income statement
data = api.financials("MSFT", statement="income_statement", limit=5)

# Balance sheet
data = api.financials("MSFT", statement="balance_sheet")

# Cash flow
data = api.financials("MSFT", statement="cash_flow")

# Quarterly data
data = api.financials("MSFT", annual=False, limit=8)
```

### Filing history

```python
# All recent filings
filings = api.filings("TSLA")

# Only 10-K annual reports
filings = api.filings("TSLA", form="10-K", limit=5)
```

### Context manager

```python
with SecEdgar("YOUR_KEY") as api:
    print(api.company("GOOG")["name"])
```

## Error handling

```python
from sec_edgar import SecEdgar
from sec_edgar.client import SecEdgarError

api = SecEdgar("YOUR_KEY")

try:
    api.company("INVALID")
except SecEdgarError as e:
    print(e.status_code)  # 404
    print(e.detail)       # "Ticker not found"
```

## Get an API key

1. Go to [SEC EDGAR Data API on RapidAPI](https://rapidapi.com/LiamAltie/api/sec-edgar-data-api)
2. Subscribe (free tier: 100 requests/month)
3. Copy your API key from the dashboard

## Links

- [secedgardata.com](https://secedgardata.com) — Free dashboard (no API key needed)
- [SEC EDGAR Data API on RapidAPI](https://rapidapi.com/LiamAltie/api/sec-edgar-data-api) — REST API
- [GitHub](https://github.com/LiamAltie/sec-edgar-sdk) — Source code & issues

## Data source

All data comes from [SEC EDGAR](https://data.sec.gov/) — official US government public data.
