from .client import SecEdgar

__version__ = "0.1.0"
__all__ = ["SecEdgar"]
