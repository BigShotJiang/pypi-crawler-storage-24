"""SEC EDGAR Data API client."""

from __future__ import annotations

import requests


API_HOST = "sec-edgar-data-api.p.rapidapi.com"
BASE_URL = f"https://{API_HOST}"


class SecEdgarError(Exception):
    """Raised when the API returns an error."""

    def __init__(self, status_code: int, detail: str):
        self.status_code = status_code
        self.detail = detail
        super().__init__(f"[{status_code}] {detail}")


class SecEdgar:
    """Client for the SEC EDGAR Data API on RapidAPI.

    Usage::

        from sec_edgar import SecEdgar

        api = SecEdgar("YOUR_RAPIDAPI_KEY")
        company = api.company("AAPL")
        print(company["name"])  # Apple Inc.
    """

    def __init__(self, api_key: str, timeout: int = 30):
        self._session = requests.Session()
        self._session.headers.update({
            "x-rapidapi-key": api_key,
            "x-rapidapi-host": API_HOST,
        })
        self._timeout = timeout

    def _get(self, path: str, params: dict | None = None) -> dict | list:
        resp = self._session.get(
            f"{BASE_URL}{path}",
            params=params,
            timeout=self._timeout,
        )
        if resp.status_code != 200:
            detail = resp.json().get("detail", resp.text) if resp.text else "Unknown error"
            raise SecEdgarError(resp.status_code, detail)
        return resp.json()

    def company(self, ticker: str) -> dict:
        """Get company info by ticker.

        >>> api.company("AAPL")
        {'cik': '320193', 'ticker': 'AAPL', 'name': 'Apple Inc.', ...}
        """
        return self._get(f"/v1/company/{ticker}")

    def search(self, query: str, limit: int = 10) -> list[dict]:
        """Search companies by name or ticker.

        >>> api.search("tesla", limit=3)
        [{'cik': '1318605', 'ticker': 'TSLA', 'name': 'Tesla, Inc.'}]
        """
        return self._get("/v1/company", params={"q": query, "limit": limit})

    def filings(
        self,
        ticker: str,
        form: str | None = None,
        limit: int = 20,
    ) -> dict:
        """Get SEC filing history.

        >>> api.filings("AAPL", form="10-K", limit=3)
        {'ticker': 'AAPL', 'filings': [...]}
        """
        params = {"limit": limit}
        if form:
            params["form"] = form
        return self._get(f"/v1/filings/{ticker}", params=params)

    def financials(
        self,
        ticker: str,
        statement: str | None = None,
        annual: bool = True,
        limit: int = 10,
    ) -> dict:
        """Get financial statements.

        Args:
            ticker: Stock ticker symbol.
            statement: One of 'income_statement', 'balance_sheet', 'cash_flow'.
                       None returns all statements.
            annual: True for annual (10-K), False for quarterly (10-Q).
            limit: Years of history (1-30).

        >>> api.financials("AAPL", statement="income_statement", limit=3)
        {'ticker': 'AAPL', 'statements': {'income_statement': [...]}}
        """
        params = {"annual": str(annual).lower(), "limit": limit}
        if statement:
            params["statement"] = statement
        return self._get(f"/v1/financials/{ticker}", params=params)

    def revenue(self, ticker: str, limit: int = 10) -> list[dict]:
        """Shortcut: get revenue history.

        >>> api.revenue("AAPL", limit=3)
        [{'fiscal_year': 2025, 'value': 383285000000.0, ...}, ...]
        """
        data = self.financials(ticker, statement="income_statement", limit=limit)
        for item in data.get("statements", {}).get("income_statement", []):
            if item["concept"] == "revenue":
                return item["data"]
        return []

    def net_income(self, ticker: str, limit: int = 10) -> list[dict]:
        """Shortcut: get net income history.

        >>> api.net_income("MSFT", limit=3)
        [{'fiscal_year': 2025, 'value': ..., ...}, ...]
        """
        data = self.financials(ticker, statement="income_statement", limit=limit)
        for item in data.get("statements", {}).get("income_statement", []):
            if item["concept"] == "net_income":
                return item["data"]
        return []

    def close(self):
        """Close the underlying HTTP session."""
        self._session.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
