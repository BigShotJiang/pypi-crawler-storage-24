import{l as o,a as r}from"../chunks/C7MrYxlV.js";export{o as load_css,r as start};
