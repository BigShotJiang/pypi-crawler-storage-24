# Changelog

## 1.0.0b8

- Remove source transaction counting (saves a full iteration over 200k+
  databases). Progress is now based on unique OIDs seen vs `len(source)`
  (O(1) for FileStorage) for approximate percentage and ETA.
- Smooth ETA with exponential moving average (EMA) on OID processing rate
  to avoid jumpy estimates from variable transaction sizes.

## 1.0.0b7

- Fix logging: configure root logger so destination storage progress
  (e.g. from zodb-pgjsonb parallel workers) is visible with `-v`.

## 1.0.0b6

- Add `--workers N` (`-w N`) CLI flag for parallel migration. When the
  destination storage supports it (e.g. zodb-pgjsonb), delegates to
  `destination.copyTransactionsFrom(source, workers=N)`. Falls back
  gracefully to the generic sequential copier for storages that don't
  support the parameter. No hard dependency on any specific storage.

## 1.0.0b5

- Progress percentage with one decimal place precision in per-transaction log.

## 1.0.0b4

- Blob count now reflects actual blob file data transfers, not pickle class
  references. Uses `loadBlob()` per (oid, tid) as the definitive check, with
  `is_blob_record()` as a fast pre-filter to avoid expensive stat calls on
  non-blob records.
- Graceful Ctrl-C handling: aborts any in-flight TPC transaction and exits
  cleanly instead of dumping a traceback.
- ETA now shown on per-transaction log lines (`-v` mode).

## 1.0.0b3

- Fix `--incremental` resume when destination has wall-clock TIDs from ZODB.DB
  initialization that overshoot the source TID range. The incremental logic now
  compares source/destination TID ranges and scans for the real resume point.

## 1.0.0b2

- Fix progress reporting: per-transaction record count was cumulative instead of per-transaction.

## 1.0.0b1

Initial release. Derived from
[RelStorage's zodbconvert](https://github.com/zodb/relstorage)
(Copyright Zope Foundation and Contributors, ZPL-2.1).

### Differences from RelStorage's zodbconvert

- **Standalone package**: no RelStorage dependency -- works with any
  ZODB-compatible storage (FileStorage, RelStorage, zodb-pgjsonb, ZEO, ...).
- **zope.conf extraction**: `--source-zope-conf` / `--dest-zope-conf` flags
  extract storage configuration from existing Zope config files, no need to
  write a separate conversion config.
- **Mixed mode**: combine a traditional config file with zope.conf extraction
  (e.g. destination from config file, source from zope.conf).
- **Enhanced progress reporting**: multi-tier output with per-transaction
  logging for small conversions, interval-based updates with throughput and
  ETA for large ones, and a summary at completion.
- **Incremental copy**: `--incremental` resumes from the last transaction in
  the destination storage.
- **Dry-run mode**: `--dry-run` previews what would be copied.
