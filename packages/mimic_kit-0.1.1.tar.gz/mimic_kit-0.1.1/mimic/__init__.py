"""Mimic - A command line tool"""

__version__ = "0.1.1"
