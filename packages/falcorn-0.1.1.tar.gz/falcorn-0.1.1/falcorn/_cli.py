"""CLI wrapper that delegates to the Rust bindings."""

from __future__ import annotations

import sys

import _falcorn


def main() -> None:
    raise SystemExit(_falcorn.cli_main(sys.argv[1:]))
