"""Falcorn Python API."""

from __future__ import annotations

from typing import TYPE_CHECKING

from ._falcorn import (
    ControlClient,
    FalcornServer,
    LoggingClient,
    ProtocolType,
    ServerConfig,
    WorkerClass,
    DEFAULT_CONTROL_SOCKET,
    DEFAULT_LOG_SOCKET,
    PLUGIN_FILTER_ACCESS_LOG,
    PLUGIN_FILTER_ALL,
    PLUGIN_FILTER_LOG_MESSAGE,
    PLUGIN_FILTER_METRICS,
    __version__,
)

PyServerConfig = ServerConfig

__all__ = [
    "ControlClient",
    "FalcornServer",
    "LoggingClient",
    "ServerConfig",
    "PyServerConfig",
    "WorkerClass",
    "ProtocolType",
    "DEFAULT_CONTROL_SOCKET",
    "DEFAULT_LOG_SOCKET",
    "PLUGIN_FILTER_LOG_MESSAGE",
    "PLUGIN_FILTER_ACCESS_LOG",
    "PLUGIN_FILTER_METRICS",
    "PLUGIN_FILTER_ALL",
    "__version__",
]

if TYPE_CHECKING:  # pragma: no cover
    from ._falcorn import ControlClient as _ControlClient
    # Re-export types for static analyzers
    from ._falcorn import FalcornServer as _FalcornServer
    from ._falcorn import LoggingClient as _LoggingClient
    from ._falcorn import ProtocolType as _ProtocolType
    from ._falcorn import ServerConfig as _ServerConfig
    from ._falcorn import WorkerClass as _WorkerClass
