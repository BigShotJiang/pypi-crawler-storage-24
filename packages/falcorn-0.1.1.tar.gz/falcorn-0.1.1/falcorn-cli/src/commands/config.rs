//! Config command implementation

use falcorn_core::config::ServerConfig;
use std::path::Path;

/// Show current configuration
pub fn show(config_path: Option<&Path>) -> anyhow::Result<()> {
    let config = if let Some(path) = config_path {
        ServerConfig::from_toml(path)?
    } else {
        ServerConfig::default()
    };

    println!("Current Configuration:");
    println!("  Host: {}", config.host);
    println!("  Port: {}", config.port);
    println!("  Workers: {}", config.worker_count());
    println!("  Worker Class: {}", config.worker_class.as_str());
    println!("  Timeout: {}s", config.worker_timeout);
    println!("  App Module: {}", config.app_module);
    println!("  App Callable: {}", config.app_callable);

    Ok(())
}

/// Validate configuration file
pub fn validate(config_path: &Path) -> anyhow::Result<()> {
    let config = ServerConfig::from_toml(config_path)?;
    config.validate()?;

    println!("✓ Configuration is valid");
    Ok(())
}
