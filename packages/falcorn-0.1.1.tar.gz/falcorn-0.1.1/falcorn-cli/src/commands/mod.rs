//! CLI commands implementation

pub mod run;
// pub mod dev;
pub mod check;
pub mod config;
pub mod init;
pub mod restart;
pub mod status;
pub mod stop;

/// Common utilities for commands
pub mod utils {
    use anyhow::Result;
    use std::fs;
    use std::path::Path;

    /// Create directory if it doesn't exist
    pub fn ensure_directory(path: &Path) -> Result<()> {
        if let Some(parent) = path.parent() {
            if !parent.exists() {
                fs::create_dir_all(parent)?;
            }
        }
        Ok(())
    }

    /// Read PID from file
    pub fn read_pid_file(path: &Path) -> Result<u32> {
        let content = fs::read_to_string(path)?;
        let pid = content.trim().parse::<u32>()?;
        Ok(pid)
    }

    /// Write PID to file
    pub fn write_pid_file(path: &Path, pid: u32) -> Result<()> {
        ensure_directory(path)?;
        fs::write(path, pid.to_string())?;
        Ok(())
    }

    /// Check if process is running
    #[cfg(unix)]
    pub fn is_process_running(pid: u32) -> bool {
        use std::process::Command;

        Command::new("kill")
            .arg("-0")
            .arg(pid.to_string())
            .status()
            .map(|s| s.success())
            .unwrap_or(false)
    }

    #[cfg(not(unix))]
    pub fn is_process_running(pid: u32) -> bool {
        // Windows implementation
        use std::process::Command;

        Command::new("tasklist")
            .arg("/FI")
            .arg(format!("PID eq {}", pid))
            .output()
            .map(|output| String::from_utf8_lossy(&output.stdout).contains(&pid.to_string()))
            .unwrap_or(false)
    }

    /// Print Falcorn
    pub fn print_falcorn() {
        println!(
            r#"
     /$$$$$$$$       /$$
    | $$_____/      | $$
    | $$    /$$$$$$ | $$  /$$$$$$$  /$$$$$$   /$$$$$$  /$$$$$$$
    | $$$$$|____  $$| $$ /$$_____/ /$$__  $$ /$$__  $$| $$__  $$
    | $$__/ /$$$$$$$| $$| $$      | $$  \ $$| $$  \__/| $$  \ $$
    | $$   /$$__  $$| $$| $$      | $$  | $$| $$      | $$  | $$
    | $$  |  $$$$$$$| $$|  $$$$$$$|  $$$$$$/| $$      | $$  | $$
    |__/   \_______/|__/ \_______/ \______/ |__/      |__/  |__/



        Falcorn v{} - High-Performance WSGI/ASGI Server
        "#,
            env!("CARGO_PKG_VERSION")
        );
    }
}
