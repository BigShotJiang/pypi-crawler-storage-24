//! Python bindings for Falcorn
//!
//! Provides a simple and powerful API for running WSGI applications

mod config;
mod models;
mod plugin;
mod server;

pub use config::ServerConfig;
pub use models::{ProtocolType, WorkerClass};
pub use plugin::{ControlClient, LoggingClient};
pub use server::FalcornServer;

use pyo3::prelude::*;
use pyo3::wrap_pyfunction;

#[pyfunction]
fn cli_main(args: Vec<String>) -> PyResult<i32> {
    let mut argv = Vec::with_capacity(args.len() + 1);
    argv.push("falcorn".to_string());
    argv.extend(args);

    let code = match falcorn_cli::run_from(argv) {
        Ok(()) => 0,
        Err(err) => {
            eprintln!("Error: {}", err);
            1
        }
    };

    Ok(code)
}

/// Falcorn Python native module
#[pymodule]
fn _falcorn(_py: Python, m: &Bound<'_, PyModule>) -> PyResult<()> {
    m.add_class::<FalcornServer>()?;
    m.add_class::<ServerConfig>()?;
    m.add_class::<WorkerClass>()?;
    m.add_class::<ProtocolType>()?;
    m.add_class::<LoggingClient>()?;
    m.add_class::<ControlClient>()?;
    m.add_function(wrap_pyfunction!(cli_main, m)?)?;
    plugin::add_plugin_constants(m)?;
    m.add("PyServerConfig", m.getattr("ServerConfig")?)?;
    m.add("__version__", env!("CARGO_PKG_VERSION"))?;
    m.add(
        "__doc__",
        "Falcorn - High-performance WSGI/ASGI server written in Rust",
    )?;
    Ok(())
}
