"""
Setup script for Falcorn Python package (for legacy builds)
"""

from setuptools import setup

setup(
    name="Falcorn",
    version="0.1.0",
    description="High-performance WSGI server written in Rust",
    long_description=open("../README.md").read(),
    long_description_content_type="text/markdown",
    author="Falcorn Contributors",
    url="https://github.com/AllDotPy/Falcorn",
    license="Apache-2.0",
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: Apache Software License",
        "Programming Language :: Rust",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Internet :: WWW/HTTP :: WSGI :: Server",
    ],
    python_requires=">=3.10",
    packages=["Falcorn"],
    package_data={
        "Falcorn": ["*.pyi", "py.typed"],
    },
    zip_safe=False,
)

