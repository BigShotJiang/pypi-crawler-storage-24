pub mod asgi_adapter;
pub mod asgi_callback;
pub mod callback_scheduler;
pub mod context;
pub mod executor;

pub use asgi_adapter::{AsgiEnvironBuilder, AsgiReceiveEvent, AsgiResponseAdapter, AsgiSendEvent};
pub use asgi_callback::{AsgiReceive, AsgiScope, AsgiSend, AsgiSendEventPool, create_asgi_io};
pub use context::AsgiContext;
pub use executor::AsgiExecutor;

use std::sync::OnceLock;
use std::time::Instant;

pub(crate) fn monotonic_now_ns() -> u64 {
    static BASE: OnceLock<Instant> = OnceLock::new();
    let start = BASE.get_or_init(Instant::now);
    start.elapsed().as_nanos().min(u128::from(u64::MAX)) as u64
}
