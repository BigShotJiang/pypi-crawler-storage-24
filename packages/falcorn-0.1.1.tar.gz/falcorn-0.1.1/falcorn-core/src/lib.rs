pub mod config;
pub mod control;
pub mod errors;
pub mod http;
pub mod logging;
pub mod python;
pub mod runtime;
pub mod server;

// Re-exports for convenience
pub use crate::http::{HttpMethod, HttpRequest, HttpResponse};
pub use config::{LogLevel, ProtocolType, ServerConfig, WorkerClass};
pub use errors::{FalcornError, Result};
pub use logging::logger::Logger;
pub use server::FalcornServer;

// Export StatusCode from http crate for convenience
// pub use http::StatusCode;
/// Library version
pub const VERSION: &str = env!("CARGO_PKG_VERSION");

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_version() {
        assert!(!VERSION.is_empty());
    }

    #[test]
    fn test_config_creation() {
        let config = ServerConfig::new("app".to_string(), "application".to_string());
        assert_eq!(config.app_module, "app");
        assert_eq!(config.app_callable, "application");
    }
}
