//! Versioned HTTP connection handler trait

use super::SendfileSupport;
use crate::config::ServerConfig;
use crate::errors::Result;
use crate::logging::Logger;
use crate::server::request_handler::RequestHandler;
use std::net::SocketAddr;
use std::sync::Arc;
use std::sync::atomic::AtomicUsize;

/// Unified handler interface for HTTP versions (sync + async)
pub trait HttpConnectionHandler: Send + Sync {
    /// Handle a connection in synchronous mode.
    fn handle_sync<
        S: std::io::Read + std::io::Write + super::http1::ReadTimeout + SendfileSupport,
    >(
        &self,
        stream: S,
        peer_addr: SocketAddr,
        handler: &RequestHandler,
        logger: &Logger,
        config: &ServerConfig,
        initial: Vec<u8>,
        request_count: Option<&AtomicUsize>,
    ) -> Result<()>;

    /// Handle a connection in asynchronous mode.
    fn handle_async<'a, S>(
        &'a self,
        stream: S,
        peer_addr: SocketAddr,
        handler: RequestHandler,
        logger: Logger,
        config: Arc<ServerConfig>,
        initial: Vec<u8>,
        request_count: Option<std::sync::Arc<AtomicUsize>>,
    ) -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<()>> + Send + 'a>>
    where
        S: tokio::io::AsyncRead + tokio::io::AsyncWrite + Unpin + Send + 'a;
}
