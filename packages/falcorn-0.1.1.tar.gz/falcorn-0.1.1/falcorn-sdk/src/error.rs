use thiserror::Error;

#[derive(Debug, Error)]
pub enum Error {
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
    #[error("serialize error: {0}")]
    Serialize(#[from] Box<bincode::ErrorKind>),
    #[error("protocol error: {0}")]
    Protocol(String),
    #[error("remote error: {code} - {message}")]
    Remote { code: String, message: String },
}

pub type Result<T> = std::result::Result<T, Error>;
