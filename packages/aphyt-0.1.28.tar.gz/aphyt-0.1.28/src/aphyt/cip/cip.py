__author__ = 'Joseph Ryan'
__license__ = "GPLv2"
__maintainer__ = "Joseph Ryan"
__email__ = "jr@aphyt.com"

from abc import ABC, abstractmethod
from aphyt.cip.cip_attributes import CIPAttribute
import binascii
import re

cip_status_dictionary = {
    b'\x00': ('SUCCESS',''),
    b'\x02': ('RESOURCE_UNAVAILABLE','This is generally causes by too many coroutines exhausting PLC Ethernet/IP'
                                     ' processing resources. Decrease the number of coroutines using a semaphore'),
    b'\x04': ('PATH_SEGMENT_ERROR','This is generally caused by the variable not existing or not being published'
                                   ' in the global variable table'),
    b'\x05': ('PATH_DESTINATION_UNKNOWN',''),
    b'\x0c': ('OBJECT_STATE_CONFLICT',''),
    b'\x11': ('REPLY_DATA_TOO_LARGE',''),
    b'\x13': ('NOT_ENOUGH_DATA',''),
    b'\x15': ('TOO_MUCH_DATA',''),
    b'\x1f': ('VENDOR_SPECIFIC_ERROR',''),
    b'\x20': ('INVALID_PARAMETER',''),
    b'\x10\x80': ('Downloading, starting up',''),
    b'\x11\x80': ('There is an error in tag memory',''),
    b'\x02\x01\x04\x21': ('An attempt was made to read an I/O vari-able that cannot be read',''),
    b'\x04\x01\x03\x11': ('The specified address and size exceed a segment boundary',''),
    b'\x01\x80': ('An internal error occurred',''),
    b'\x07\x80': ('An inaccessible variable was specified',''),
    b'\x31\x80': ('An internal error occurred. (A memory allocation error occurred)',''),
    b'\x02\x01\x03\x21': ('An attempt was made to write a constant or read-only variable',''),
    b'\x29\x80': ('A region that all cannot be accessed at the same time was specified for SimpleDataSegment',''),
    b'\x09\x80': ('A segment type error occurred',''),
    b'\x0f\x80': ('There is an inconsistency in data length information in the Request Data',''),
    b'\x17\x80': ('More than one element was specified for a variable that does not have elements',''),
    b'\x18\x80': ('Zero elements or data that exceeded the range of the array was specified for an array',''),
    b'\x21\x80': ('A value other than 0 or 2 was specified for an AddInfo area',''),
    b'\x22\x80': ('The data type that is specified in the request service data does not '
                  'agree with the tag information. The AddInfo Length in the request service data is not 0',''),
    b'\x23\x80': ('An internal error occurred. (An illegal command format was used.)',''),
    b'\x24\x80': ('An internal error occurred. (An illegal command length was used.)',''),
    b'\x25\x80': ('An internal error occurred. (An illegal parameter was used.)',''),
    b'\x27\x80': ('An internal error occurred. (A parameter error occurred.)',''),
    b'\x28\x80': ('An attempt was made to write an out-of-range value for a variable for which a subrange '
                  'is specified. An attempt was made to write an undefined value to an enumeration variable.',''),
}

def cip_crc16(data: bytes, poly=0xa001) -> bytes:
    data = bytearray(data)
    crc = 0x0000
    for byte in data:
        crc = crc ^ byte
        for _ in range(0, 8):
            carry = crc & 1
            crc >>= 1
            if carry:
                crc = crc ^ poly
    return crc.to_bytes(2, 'little')


class CIPService:
    """
    ToDo eventually all services should be mixins and then the cip dispatcher will not contain the
    reading, writing, getting, setting and resetting methods
    """
    READ_TAG_SERVICE = b'\x4c'
    READ_TAG_FRAGMENTED_SERVICE = b'\x52'
    WRITE_TAG_SERVICE = b'\x4d'
    WRITE_TAG_FRAGMENTED_SERVICE = b'\x53'
    READ_MODIFY_WRITE_TAG_SERVICE = b'\x4e'
    # w506_nx_nj - series_cpu_unit_built - in_ethernet_ip_port_users_manual_en.pdf
    # 303 of 570 CIP Object Services
    GET_ATTRIBUTE_ALL = b'\x01'
    GET_ATTRIBUTE_SINGLE = b'\x0e'
    RESET = b'\x05'
    SET_ATTRIBUTE_SINGLE = b'\x10'
    GET_INSTANCE_LIST_EX2 = b'\x5f'

    def __init__(self, cip_dispatcher: "CIPDispatcher", **kwargs):
        self.cip_dispatcher = cip_dispatcher


class CIPException(Exception):
    def __init__(self, status: bytes, extended_status: bytes):
        self.status = status
        self.extended_status = extended_status
        super().__init__(self.get_message())

    def get_message(self):
        message = (f"\nCIP reply contained a general status code {binascii.hexlify(self.status).decode('utf-8')}\n"
               f"{cip_status_dictionary[self.status][0]}\n{cip_status_dictionary[self.status][1]}\n")

        value = cip_status_dictionary.get(self.extended_status)
        if self.extended_status != b'':
            message += f"Extended Status: {binascii.hexlify(self.extended_status).decode('utf-8')} \n"
        if value is not None:
            message += f'{value[0]}'
        return message


class CIPRequest:
    """
    Class for assembling CIP requests

    ``1756-pm020_-en-p.pdf 17 of 94``

    * Read Tag Service (0x4c)
    * Read Tag Fragmented Service (0x52)
    * Write Tag Service (0x4d)
    * Write Tag Fragmented Service (0x53)
    * Read Modify Write Tag Service (0x4e)
    """

    def __init__(self,
                 request_service: bytes,
                 request_path: bytes,
                 request_data: bytes = b''):
        """ Constructor method

        :param request_service: bytes
        :param request_path: bytes
        :param request_data: bytes
        """
        self.request_service = request_service
        self.request_data = request_data
        # Length is in Words, so the byte length is divided in half
        self.request_path_size = len(request_path) // 2
        self.request_path = request_path

    @property
    def bytes(self) -> bytes:
        return \
                self.request_service + self.request_path_size.to_bytes(1, 'little') + \
                self.request_path + self.request_data


class CIPReply:
    """
    Class for parsing CIP replies
    """

    def __init__(self, reply_bytes: bytes):
        """

        :param reply_bytes:
        """
        self.reply_service = reply_bytes[0:1]
        self.reserved = reply_bytes[1:2]
        self.general_status = reply_bytes[2:3]
        self.extended_status_size = reply_bytes[3:4]
        # Research replies that use this. It's usually zero, so I am guessing it is in words (like the request)
        extended_status_byte_size = int.from_bytes(self.extended_status_size, 'little') * 2
        self.extended_status = reply_bytes[4:4 + extended_status_byte_size]
        self.reply_data = reply_bytes[4 + extended_status_byte_size:]

    @property
    def bytes(self) -> bytes:
        """
        The bytes in the CIP reply
        :return:
        """
        return \
                self.reply_service + self.reserved + self.general_status + \
                self.extended_status_size + self.extended_status + self.reply_data


class CIPCommonFormat:
    """
    CIP common format is a format that is used to pack data to be used in CIP messages
    Look at W506 page 341 of 570 for definition
    """

    def __init__(self,
                 data_type: bytes = b'',
                 additional_info_length: int = 0,
                 additional_info: bytes = b'',
                 data: bytes = b''):
        self.data_type = data_type
        self.additional_info_length = additional_info_length
        self.additional_info = additional_info
        self.data = data

    def __repr__(self):
        return str(self.data_type + self.additional_info_length.to_bytes(1, 'little') + self.additional_info + self.data)

    def from_bytes(self, bytes_cip_common_format):
        self.data_type = bytes_cip_common_format[0:1]
        self.additional_info_length = int.from_bytes(bytes_cip_common_format[1:2], 'little')
        self.additional_info = bytes_cip_common_format[2:2 + self.additional_info_length]
        self.data = bytes_cip_common_format[2 + self.additional_info_length:]


class CIPDispatcher(ABC):
    """
    CIPDispatcher is an abstract base class that has the basic methods and data required
    to send and receive CIP messages from a peer that is equipped to communicate using
    this protocol

    The key method that subclasses need to implement is 'execute_cip_command' which will
    send a CIPRequest over the CIP network and receive a CIPReply

    ToDo monitor when the read, write, get, set services have all moved to CIP objects mixins and get rid of them
    """

    def __init__(self):
        self.variables = {}
        self.user_variables = {}
        self.system_variables = {}
        self.data_type_dictionary = {}

    @abstractmethod
    def execute_cip_command(self, request: CIPRequest) -> CIPReply:
        pass

    def read_tag_service(self, tag_request_path, number_of_elements=1) -> CIPReply:
        read_tag_request = \
            CIPRequest(CIPService.READ_TAG_SERVICE, tag_request_path, number_of_elements.to_bytes(2, 'little'))
        return self.execute_cip_command(read_tag_request)

    def write_tag_service(self, tag_request_path, request_service_data: CIPCommonFormat, number_of_elements=1):
        data = request_service_data.data_type + \
               int(request_service_data.additional_info_length).to_bytes(1, 'little') + \
               request_service_data.additional_info + number_of_elements.to_bytes(2, 'little') + \
               request_service_data.data
        write_tag_request = CIPRequest(CIPService.WRITE_TAG_SERVICE, tag_request_path, data)
        return self.execute_cip_command(write_tag_request)

    def read_tag_fragmented_service(self, tag_request_path, offset, number_of_elements):
        data = tag_request_path + number_of_elements.to_bytes(2, 'little') + offset.to_bytes(4, 'little')
        read_tag_fragmented_request = \
            CIPRequest(CIPService.READ_TAG_FRAGMENTED_SERVICE, tag_request_path, data)
        return self.execute_cip_command(read_tag_fragmented_request)

    def write_tag_fragmented_service(self, tag_request_path, cip_datatype_code, data, offset, number_of_elements=1):
        data = \
            cip_datatype_code + b'\x00' + number_of_elements.to_bytes(2, 'little') + \
            offset.to_bytes(4, 'little') + data
        write_tag_fragmented_request = CIPRequest(CIPService.WRITE_TAG_FRAGMENTED_SERVICE, tag_request_path, data)
        return self.execute_cip_command(write_tag_fragmented_request)

    def get_attribute_all_service(self, tag_request_path):
        get_attribute_all_request = CIPRequest(CIPService.GET_ATTRIBUTE_ALL, tag_request_path)
        return self.execute_cip_command(get_attribute_all_request)

    def get_attribute_single_service(self, tag_request_path):
        get_attribute_single_request = CIPRequest(CIPService.GET_ATTRIBUTE_SINGLE, tag_request_path)
        return self.execute_cip_command(get_attribute_single_request)

    def set_attribute_single_service(self, tag_request_path, data):
        set_attribute_single_request = CIPRequest(CIPService.SET_ATTRIBUTE_SINGLE, tag_request_path, data)
        return self.execute_cip_command(set_attribute_single_request)

    def get_instance_list(self, start_instance_id: int = 1, number_of_instances: int = 1, user_defined: bool = True):
        path = address_request_path_segment(b'\x6a', b'\x00\x00')
        if user_defined:
            kind_of_variable = 2
        else:
            kind_of_variable = 1
        kind_of_variable = kind_of_variable.to_bytes(2, 'little')
        request_data = \
            start_instance_id.to_bytes(4, 'little') + \
            number_of_instances.to_bytes(4, 'little') + \
            kind_of_variable
        get_instance_list_request = CIPRequest(CIPService.GET_INSTANCE_LIST_EX2, path, request_data)
        return self.execute_cip_command(get_instance_list_request)


class AsyncCIPDispatcher(ABC):
    """
    CIPDispatcher is an abstract base class that has the basic methods and data required
    to send and receive CIP messages from a peer that is equipped to communicate using
    this protocol

    The key method that subclasses need to implement is 'execute_cip_command' which will
    send a CIPRequest over the CIP network and receive a CIPReply

    ToDo monitor when the read, write, get, set services have all moved to CIP objects mixins and get rid of them
    """

    def __init__(self):
        self.variables = {}
        self.user_variables = {}
        self.system_variables = {}
        self.data_type_dictionary = {}

    @abstractmethod
    async def execute_cip_command(self, request: CIPRequest) -> CIPReply:
        pass

    async def read_tag_service(self, tag_request_path, number_of_elements=1) -> CIPReply:
        read_tag_request = \
            CIPRequest(CIPService.READ_TAG_SERVICE, tag_request_path, number_of_elements.to_bytes(2, 'little'))
        return await self.execute_cip_command(read_tag_request)

    async def write_tag_service(self, tag_request_path, request_service_data: CIPCommonFormat, number_of_elements=1):
        data = request_service_data.data_type + \
               int(request_service_data.additional_info_length).to_bytes(1, 'little') + \
               request_service_data.additional_info + number_of_elements.to_bytes(2, 'little') + \
               request_service_data.data
        write_tag_request = CIPRequest(CIPService.WRITE_TAG_SERVICE, tag_request_path, data)
        return await self.execute_cip_command(write_tag_request)

    async def read_tag_fragmented_service(self, tag_request_path, offset, number_of_elements):
        data = tag_request_path + number_of_elements.to_bytes(2, 'little') + offset.to_bytes(4, 'little')
        read_tag_fragmented_request = \
            CIPRequest(CIPService.READ_TAG_FRAGMENTED_SERVICE, tag_request_path, data)
        return await self.execute_cip_command(read_tag_fragmented_request)

    async def write_tag_fragmented_service(self, tag_request_path, cip_datatype_code, data, offset, number_of_elements=1):
        data = \
            cip_datatype_code + b'\x00' + number_of_elements.to_bytes(2, 'little') + \
            offset.to_bytes(4, 'little') + data
        write_tag_fragmented_request = CIPRequest(CIPService.WRITE_TAG_FRAGMENTED_SERVICE, tag_request_path, data)
        return await self.execute_cip_command(write_tag_fragmented_request)

    async def get_attribute_all_service(self, tag_request_path):
        get_attribute_all_request = CIPRequest(CIPService.GET_ATTRIBUTE_ALL, tag_request_path)
        return await self.execute_cip_command(get_attribute_all_request)

    async def get_attribute_single_service(self, tag_request_path):
        get_attribute_single_request = CIPRequest(CIPService.GET_ATTRIBUTE_SINGLE, tag_request_path)
        return await self.execute_cip_command(get_attribute_single_request)

    async def set_attribute_single_service(self, tag_request_path, data):
        set_attribute_single_request = CIPRequest(CIPService.SET_ATTRIBUTE_SINGLE, tag_request_path, data)
        return await self.execute_cip_command(set_attribute_single_request)

    async def get_instance_list(self, start_instance_id: int = 1, number_of_instances: int = 1, user_defined: bool = True):
        path = address_request_path_segment(b'\x6a', b'\x00\x00')
        if user_defined:
            kind_of_variable = 2
        else:
            kind_of_variable = 1
        kind_of_variable = kind_of_variable.to_bytes(2, 'little')
        request_data = \
            start_instance_id.to_bytes(4, 'little') + \
            number_of_instances.to_bytes(4, 'little') + \
            kind_of_variable
        get_instance_list_request = CIPRequest(CIPService.GET_INSTANCE_LIST_EX2, path, request_data)
        return await self.execute_cip_command(get_instance_list_request)


class ReadTagServiceMixin(CIPService):
    def __init__(self, cip_dispatcher: CIPDispatcher):
        super().__init__(cip_dispatcher)

    def read_tag(self, tag_request_path, number_of_elements=1) -> CIPReply:
        service_code = b'\x4c'
        read_tag_request = \
            CIPRequest(service_code, tag_request_path, number_of_elements.to_bytes(2, 'little'))
        return self.cip_dispatcher.execute_cip_command(read_tag_request)


class WriteTagServiceMixin(CIPService):
    def __init__(self, cip_dispatcher: CIPDispatcher):
        super().__init__(cip_dispatcher)

    def write_tag(self, tag_request_path, request_service_data: CIPCommonFormat, number_of_elements=1):
        service_code = b'\x4d'
        data = request_service_data.data_type + \
            int(request_service_data.additional_info_length).to_bytes(1, 'little') + \
            request_service_data.additional_info + number_of_elements.to_bytes(2, 'little') + \
            request_service_data.data
        write_tag_request = CIPRequest(service_code, tag_request_path, data)
        return self.cip_dispatcher.execute_cip_command(write_tag_request)


class GetAttributeAllMixin(CIPService):
    def __init__(self, cip_dispatcher: CIPDispatcher):
        super().__init__(cip_dispatcher)

    def get_attribute_all_from_path(self, tag_request_path):
        service_code = b'\x01'
        get_attribute_all_request = CIPRequest(service_code, tag_request_path)
        return self.cip_dispatcher.execute_cip_command(get_attribute_all_request)

    # def get_attribute_all(self, cip_attribute: CIPAttribute) -> bytes:
    #     reply = self.get_attribute_all_from_path(cip_attribute.request_path)
    #     return reply.reply_data


class GetAttributeSingleMixin(CIPService):
    """Always use the Set mixins before the get mixins so that """
    def __init__(self, cip_dispatcher: CIPDispatcher, **kwargs):
        super().__init__(cip_dispatcher, **kwargs)

    def get_attribute_single_from_path(self, tag_request_path) -> CIPReply:
        service_code = b'\x0e'
        get_attribute_single_request = \
            CIPRequest(service_code, tag_request_path)
        return self.cip_dispatcher.execute_cip_command(get_attribute_single_request)

    def get_attribute_single(self, cip_attribute: CIPAttribute) -> CIPAttribute:
        reply = self.get_attribute_single_from_path(cip_attribute.request_path)
        cip_attribute.data_type.data = reply.reply_data
        return cip_attribute


class SetAttributeSingleMixin(CIPService):
    def __init__(self, cip_dispatcher: CIPDispatcher, **kwargs):
        super().__init__(cip_dispatcher, **kwargs)

    def set_attribute_single_from_path(self, tag_request_path, data: bytes):
        service_code = b'\x10'
        set_attribute_single_request = CIPRequest(service_code, tag_request_path, data)
        return self.cip_dispatcher.execute_cip_command(set_attribute_single_request)

    def set_attribute_single(self, cip_attribute: CIPAttribute):
        assert (cip_attribute.writeable is True)
        self.set_attribute_single_from_path(cip_attribute.request_path, data=cip_attribute.data_type.data)


class ResetMixin(CIPService):
    def __init__(self, cip_dispatcher: CIPDispatcher):
        super().__init__(cip_dispatcher)

    def reset(self, tag_request_path):
        service_code = b'\x05'
        reset_request = CIPRequest(service_code, tag_request_path)
        return self.cip_dispatcher.execute_cip_command(reset_request)


def address_request_path_segment(class_id: bytes = None, instance_id: bytes = None,
                                 attribute_id: bytes = None, element_id: bytes = None) -> bytes:
    """
    This function is to create a request path using the class, instance, attribute and element values
    of the data that the programmer will access

    :param class_id: class id with low byte first
    :param instance_id:
    :param attribute_id:
    :param element_id
    :return:
    """
    # Logical segment  1756-pm020 16 of 94
    request_path_bytes = b''
    if class_id is not None:
        # 8-bit id uses b'\x20 16-bit uses b'\x21'
        if len(class_id) == 1:
            request_path_bytes += b'\x20' + class_id
        elif len(class_id) == 2:
            request_path_bytes += b'\x21\x00' + class_id
    if instance_id is not None:
        # 8-bit id uses b'\x24' 16-bit uses b'\x25'
        if len(instance_id) == 1:
            request_path_bytes += b'\x24' + instance_id
        elif len(instance_id) == 2:
            request_path_bytes += b'\x25\x00' + instance_id
    if attribute_id is not None:
        # 8-bit id uses b'\x30' 16-bit uses b'\x31'
        if len(attribute_id) == 1:
            request_path_bytes += b'\x30' + attribute_id
        elif len(attribute_id) == 2:
            request_path_bytes += b'\x31\x00' + attribute_id
    if element_id is not None:
        # 8-bit id uses b'\x28' 16-bit uses b'\x29' 32-bit uses b'\x2a'
        if len(element_id) == 1:
            request_path_bytes += b'\x28' + element_id
        elif len(element_id) == 2:
            request_path_bytes += b'\x29\x00' + element_id
        elif len(element_id) == 4:
            request_path_bytes += b'\x2a\x00' + element_id
    return request_path_bytes


def variable_request_path_segment(variable_name: str) -> bytes:
    """
    This function is to create a request path using the variable name of the data that the programmer will access

    :param variable_name: The name of the variable for the request path
    :return: Request path as a bytes object
    """
    # Symbolic segment
    # 1756-pm020_-en-p.pdf 17 of 94
    res = list(filter(None, re.split(r'\[|\]|\.', variable_name)))
    request_path = b''
    for token in res:
        if token.isnumeric():
            element_id = int(token)
            request_path += address_request_path_segment(element_id=element_id.to_bytes(4, 'little'))
        else:
            request_path += _extended_symbol_segment(token)
    return request_path


def _extended_symbol_segment(name: str):
    request_path_bytes = (b'\x91' + len(bytes(name.encode("utf-8"))).to_bytes(1, 'little') +
                          name.encode('utf-8'))
    if len(request_path_bytes) % 2 != 0:
        request_path_bytes = request_path_bytes + b'\x00'
    return request_path_bytes
