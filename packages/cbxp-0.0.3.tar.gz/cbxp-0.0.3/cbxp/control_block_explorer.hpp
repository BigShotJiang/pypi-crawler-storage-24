#ifndef __CONTROL_BLOCK_EXPLORER_H_
#define __CONTROL_BLOCK_EXPLORER_H_

#include <nlohmann/json.hpp>

#include "cbxp.h"

namespace CBXP {
class ControlBlockExplorer {
 private:
  cbxp_result_t* p_result_;
  static std::vector<std::string> createOptionsList(
      const std::string& comma_separated_string);

 public:
  explicit ControlBlockExplorer(cbxp_result_t* p_result)
      : p_result_(p_result) {};
  void exploreControlBlock(const std::string& control_block_name,
                           const std::string& includes_string,
                           const std::string& filters_string);
};
}  // namespace CBXP

#endif
