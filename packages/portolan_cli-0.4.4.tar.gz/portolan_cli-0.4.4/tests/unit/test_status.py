"""Tests for the status command.

Tests the status module (library layer) and CLI command that shows
tracking states: untracked, tracked, modified, deleted.

Per issue #133: status tracks ALL files in item directories (not just geo files).
Per issue #137: status must detect untracked files in UNINITIALIZED collections
    (directories with geo-assets but without collection.json).
Per ADR-0023: item files live in collection/{item_id}/ subdirectories.
Per ADR-0023: versions.json is at collection/versions.json (not .portolan/).
"""

from __future__ import annotations

import json
import tempfile
from pathlib import Path

import pytest
from click.testing import CliRunner
from hypothesis import HealthCheck, given, settings
from hypothesis import strategies as st

from portolan_cli.cli import cli
from portolan_cli.constants import GEOSPATIAL_EXTENSIONS
from portolan_cli.status import (
    IGNORED_FILES,
    FileStatus,
    StatusResult,
    _has_geo_assets,
    get_catalog_status,
)

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────


def make_catalog(tmp_path: Path, collection_links: list[str] | None = None) -> None:
    """Write a minimal managed catalog to tmp_path (per ADR-0023 and ADR-0029).

    Creates both .portolan/config.yaml (the sentinel per ADR-0029) and catalog.json.
    """
    # Create .portolan sentinel files (per ADR-0029)
    portolan_dir = tmp_path / ".portolan"
    portolan_dir.mkdir(parents=True, exist_ok=True)
    (portolan_dir / "config.yaml").write_text("# Portolan configuration\n")
    (portolan_dir / "state.json").write_text("{}")

    # Create catalog.json at root (STAC standard per ADR-0023)
    links = [{"rel": "child", "href": f"./{c}/collection.json"} for c in (collection_links or [])]
    (tmp_path / "catalog.json").write_text(
        json.dumps(
            {
                "type": "Catalog",
                "id": "test-catalog",
                "stac_version": "1.0.0",
                "description": "Test catalog",
                "links": links,
            }
        )
    )


def make_collection(col_dir: Path) -> None:
    """Write a minimal collection.json inside col_dir (creates dir if needed)."""
    col_dir.mkdir(parents=True, exist_ok=True)
    (col_dir / "collection.json").write_text(
        json.dumps(
            {
                "type": "Collection",
                "id": col_dir.name,
                "stac_version": "1.0.0",
                "description": f"Collection {col_dir.name}",
                "license": "proprietary",
                "extent": {
                    "spatial": {"bbox": [[-180, -90, 180, 90]]},
                    "temporal": {"interval": [[None, None]]},
                },
                "links": [],
            }
        )
    )


def make_versions_json(
    col_dir: Path,
    assets: dict[str, dict],  # key: relative path from col_dir, value: asset metadata
) -> None:
    """Write a versions.json at collection root (per ADR-0023)."""
    versions_data = {
        "spec_version": "1.0.0",
        "current_version": "1.0.0",
        "versions": [
            {
                "version": "1.0.0",
                "created": "2024-01-15T10:30:00Z",
                "breaking": False,
                "assets": assets,
                "changes": list(assets.keys()),
            }
        ],
    }
    (col_dir / "versions.json").write_text(json.dumps(versions_data))


def asset_entry(
    *,
    size_bytes: int = 17,
    sha256: str = "abc123",
    mtime: float | None = None,
    href: str = "",
) -> dict:
    """Build an asset metadata dict for versions.json."""
    entry: dict = {
        "sha256": sha256,
        "size_bytes": size_bytes,
        "href": href,
    }
    if mtime is not None:
        entry["mtime"] = mtime
    return entry


# ─────────────────────────────────────────────────────────────────────────────
# TestStatusLibrary - core get_catalog_status() behaviour
# ─────────────────────────────────────────────────────────────────────────────


class TestStatusLibrary:
    """Tests for the status library functions."""

    @pytest.mark.unit
    def test_empty_catalog_returns_empty_status(self, tmp_path: Path) -> None:
        """A catalog with no collections returns an empty status result."""
        make_catalog(tmp_path)

        result = get_catalog_status(tmp_path)

        assert result.untracked == []
        assert result.modified == []
        assert result.deleted == []
        assert result.is_clean()

    @pytest.mark.unit
    def test_untracked_file_detected_in_item_dir(self, tmp_path: Path) -> None:
        """Files in item subdirectories but not in versions.json are untracked."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        # Create item subdir with a file - no versions.json yet
        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"fake parquet data")

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].collection_id == "demographics"
        assert result.untracked[0].item_id == "census-2020"
        assert result.untracked[0].filename == "data.parquet"
        assert not result.is_clean()

    @pytest.mark.unit
    def test_untracked_non_geo_file_detected(self, tmp_path: Path) -> None:
        """Non-geospatial files (e.g., .txt, .json) in item dirs are also tracked."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        (item_dir / "notes.txt").write_text("some notes")
        (item_dir / "schema.json").write_text("{}")

        result = get_catalog_status(tmp_path)

        filenames = [f.filename for f in result.untracked]
        assert "notes.txt" in filenames
        assert "schema.json" in filenames
        assert len(result.untracked) == 2

    @pytest.mark.unit
    def test_ignored_files_excluded(self, tmp_path: Path) -> None:
        """Files in IGNORED_FILES set are never reported as untracked."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        # Write all ignored files alongside a real file
        for ignored in IGNORED_FILES:
            (item_dir / ignored).write_bytes(b"")
        (item_dir / "data.parquet").write_bytes(b"real data")

        result = get_catalog_status(tmp_path)

        filenames = [f.filename for f in result.untracked]
        for ignored in IGNORED_FILES:
            assert ignored not in filenames, f"{ignored} should be filtered out"
        assert "data.parquet" in filenames

    @pytest.mark.unit
    def test_tracked_file_not_in_results(self, tmp_path: Path) -> None:
        """Files that are tracked and unchanged don't appear in status."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        data_file = item_dir / "data.parquet"
        data_file.write_bytes(b"fake parquet data")

        file_stat = data_file.stat()
        make_versions_json(
            col_dir,
            {
                "census-2020/data.parquet": asset_entry(
                    size_bytes=file_stat.st_size,
                    sha256="abc123",
                    mtime=file_stat.st_mtime,
                    href="demographics/census-2020/data.parquet",
                )
            },
        )

        result = get_catalog_status(tmp_path)

        assert result.untracked == []
        assert result.modified == []
        assert result.deleted == []
        assert result.is_clean()

    @pytest.mark.unit
    def test_modified_file_detected(self, tmp_path: Path) -> None:
        """Files with changed mtime/size are detected as modified."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        data_file = item_dir / "data.parquet"
        data_file.write_bytes(b"fake parquet data")

        # versions.json records different size/mtime -> file is modified
        make_versions_json(
            col_dir,
            {
                "census-2020/data.parquet": asset_entry(
                    size_bytes=9999,
                    sha256="different_hash",
                    mtime=0.0,
                    href="demographics/census-2020/data.parquet",
                )
            },
        )

        result = get_catalog_status(tmp_path)

        assert len(result.modified) == 1
        assert result.modified[0].collection_id == "demographics"
        assert result.modified[0].item_id == "census-2020"
        assert result.modified[0].filename == "data.parquet"
        assert not result.is_clean()

    @pytest.mark.unit
    def test_deleted_file_detected(self, tmp_path: Path) -> None:
        """Files in versions.json but missing from disk are deleted."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        # versions.json references a file that doesn't exist on disk
        make_versions_json(
            col_dir,
            {
                "census-2020/deleted_file.parquet": asset_entry(
                    href="demographics/census-2020/deleted_file.parquet"
                )
            },
        )

        result = get_catalog_status(tmp_path)

        assert len(result.deleted) == 1
        assert result.deleted[0].collection_id == "demographics"
        assert result.deleted[0].item_id == "census-2020"
        assert result.deleted[0].filename == "deleted_file.parquet"
        assert not result.is_clean()

    @pytest.mark.unit
    def test_multiple_items_in_collection(self, tmp_path: Path) -> None:
        """Files in multiple item subdirectories are all scanned."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        # Two item directories
        for item_id in ["census-2020", "census-2021"]:
            item_dir = col_dir / item_id
            item_dir.mkdir()
            (item_dir / "data.parquet").write_bytes(b"data")

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 2
        item_ids = {f.item_id for f in result.untracked}
        assert item_ids == {"census-2020", "census-2021"}

    @pytest.mark.unit
    def test_multiple_collections(self, tmp_path: Path) -> None:
        """Status aggregates across multiple collections."""
        make_catalog(tmp_path, ["demographics", "imagery"])

        # Collection 1: demographics with untracked file in item dir
        col1 = tmp_path / "demographics"
        make_collection(col1)
        item1 = col1 / "census-2020"
        item1.mkdir()
        (item1 / "data.parquet").write_bytes(b"data")

        # Collection 2: imagery with deleted file
        col2 = tmp_path / "imagery"
        make_collection(col2)
        make_versions_json(
            col2,
            {"satellite-2024/image.tif": asset_entry(href="imagery/satellite-2024/image.tif")},
        )

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].collection_id == "demographics"
        assert len(result.deleted) == 1
        assert result.deleted[0].collection_id == "imagery"

    @pytest.mark.unit
    def test_collection_json_itself_excluded(self, tmp_path: Path) -> None:
        """collection.json at the collection root is not reported as an asset."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        # No item directories -> nothing to report
        result = get_catalog_status(tmp_path)
        assert result.is_clean()

    @pytest.mark.unit
    def test_versions_json_at_collection_root_not_item_portolan(self, tmp_path: Path) -> None:
        """versions.json is read from collection root, not .portolan/."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        data_file = item_dir / "data.parquet"
        data_file.write_bytes(b"data")
        file_stat = data_file.stat()

        # Put versions.json at WRONG location (.portolan/) - should be ignored
        portolan_dir = col_dir / ".portolan"
        portolan_dir.mkdir()
        (portolan_dir / "versions.json").write_text(
            json.dumps(
                {
                    "spec_version": "1.0.0",
                    "current_version": "1.0.0",
                    "versions": [
                        {
                            "version": "1.0.0",
                            "created": "2024-01-15T10:30:00Z",
                            "breaking": False,
                            "assets": {
                                "census-2020/data.parquet": asset_entry(
                                    size_bytes=file_stat.st_size,
                                    mtime=file_stat.st_mtime,
                                    href="demographics/census-2020/data.parquet",
                                )
                            },
                            "changes": ["census-2020/data.parquet"],
                        }
                    ],
                }
            )
        )

        # File should still show as untracked (wrong location not read)
        result = get_catalog_status(tmp_path)
        assert len(result.untracked) == 1

        # Now put versions.json at CORRECT location (collection root)
        make_versions_json(
            col_dir,
            {
                "census-2020/data.parquet": asset_entry(
                    size_bytes=file_stat.st_size,
                    mtime=file_stat.st_mtime,
                    href="demographics/census-2020/data.parquet",
                )
            },
        )

        result2 = get_catalog_status(tmp_path)
        assert result2.is_clean()

    @pytest.mark.unit
    def test_hidden_directories_skipped(self, tmp_path: Path) -> None:
        """Hidden directories (e.g. .portolan, .git) are not treated as collections."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        # Create a hidden directory alongside - it should not be treated as item dir
        hidden = col_dir / ".portolan"
        hidden.mkdir()
        (hidden / "config.yaml").write_text("key: value")

        result = get_catalog_status(tmp_path)
        assert result.is_clean()

    @pytest.mark.unit
    def test_no_catalog_raises_error(self, tmp_path: Path) -> None:
        """get_catalog_status raises error when no catalog.json exists."""
        with pytest.raises(FileNotFoundError, match="catalog.json not found"):
            get_catalog_status(tmp_path)

    @pytest.mark.unit
    def test_corrupt_versions_json_treated_as_untracked(self, tmp_path: Path) -> None:
        """If versions.json is corrupt, all files in item dirs are treated as untracked."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"data")

        # Write invalid JSON
        (col_dir / "versions.json").write_text("{ invalid json }")

        result = get_catalog_status(tmp_path)
        assert len(result.untracked) == 1

    @pytest.mark.unit
    def test_multiple_files_per_item(self, tmp_path: Path) -> None:
        """Multiple files in one item directory are all tracked."""
        make_catalog(tmp_path, ["imagery"])
        col_dir = tmp_path / "imagery"
        make_collection(col_dir)

        item_dir = col_dir / "satellite-2024"
        item_dir.mkdir()
        (item_dir / "image.tif").write_bytes(b"tif data")
        (item_dir / "thumbnail.png").write_bytes(b"png data")
        (item_dir / "metadata.json").write_text("{}")

        result = get_catalog_status(tmp_path)
        assert len(result.untracked) == 3
        filenames = {f.filename for f in result.untracked}
        assert filenames == {"image.tif", "thumbnail.png", "metadata.json"}

    @pytest.mark.unit
    def test_item_json_excluded_from_results(self, tmp_path: Path) -> None:
        """item.json within an item directory is not reported as an asset to track."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        # item.json is STAC metadata, not a user asset
        (item_dir / "item.json").write_text(json.dumps({"type": "Feature"}))
        (item_dir / "data.parquet").write_bytes(b"data")

        result = get_catalog_status(tmp_path)

        filenames = [f.filename for f in result.untracked]
        # item.json is a STAC metadata file - it should NOT appear as untracked asset
        assert "item.json" not in filenames
        assert "data.parquet" in filenames


# ─────────────────────────────────────────────────────────────────────────────
# TestStatusCLI - CLI command behaviour
# ─────────────────────────────────────────────────────────────────────────────


class TestStatusCLI:
    """Tests for the status CLI command."""

    @pytest.mark.unit
    def test_status_clean_catalog(self, tmp_path: Path) -> None:
        """Status command shows clean message when nothing to report."""
        import os

        make_catalog(tmp_path)

        runner = CliRunner()
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
        finally:
            os.chdir(old_cwd)

        assert result.exit_code == 0
        assert "Nothing to commit, working tree clean" in result.output

    @pytest.mark.unit
    def test_status_shows_untracked(self, tmp_path: Path) -> None:
        """Status command shows untracked files with # prefix."""
        import os

        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)
        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"data")

        runner = CliRunner()
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
        finally:
            os.chdir(old_cwd)

        assert result.exit_code == 0
        assert "Untracked:" in result.output
        assert "demographics/census-2020/data.parquet" in result.output

    @pytest.mark.unit
    def test_status_shows_non_geo_untracked(self, tmp_path: Path) -> None:
        """Status command shows non-geospatial files as untracked too."""
        import os

        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)
        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        (item_dir / "notes.txt").write_text("some notes")

        runner = CliRunner()
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
        finally:
            os.chdir(old_cwd)

        assert result.exit_code == 0
        assert "demographics/census-2020/notes.txt" in result.output

    @pytest.mark.unit
    def test_status_shows_modified(self, tmp_path: Path) -> None:
        """Status command shows modified files."""
        import os

        make_catalog(tmp_path, ["imagery"])
        col_dir = tmp_path / "imagery"
        make_collection(col_dir)
        item_dir = col_dir / "satellite-2024"
        item_dir.mkdir()
        data_file = item_dir / "image.tif"
        data_file.write_bytes(b"modified tif data")

        make_versions_json(
            col_dir,
            {
                "satellite-2024/image.tif": asset_entry(
                    size_bytes=9999,
                    sha256="old_hash",
                    mtime=0.0,
                    href="imagery/satellite-2024/image.tif",
                )
            },
        )

        runner = CliRunner()
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
        finally:
            os.chdir(old_cwd)

        assert result.exit_code == 0
        assert "Modified:" in result.output
        assert "imagery/satellite-2024/image.tif" in result.output

    @pytest.mark.unit
    def test_status_no_catalog_error(self, tmp_path: Path) -> None:
        """Status command exits with error when no catalog found."""
        runner = CliRunner()
        with runner.isolated_filesystem():
            result = runner.invoke(cli, ["status"], catch_exceptions=False)

        assert result.exit_code == 1
        assert "catalog.json not found" in result.output or "No catalog found" in result.output


# ─────────────────────────────────────────────────────────────────────────────
# TestFileStatus - dataclass behaviour
# ─────────────────────────────────────────────────────────────────────────────


class TestFileStatus:
    """Tests for the FileStatus dataclass."""

    @pytest.mark.unit
    def test_file_status_path_property(self) -> None:
        """FileStatus.path returns collection_id/item_id/filename."""
        fs = FileStatus(
            collection_id="demographics",
            item_id="census-2020",
            filename="data.parquet",
        )
        assert fs.path == "demographics/census-2020/data.parquet"

    @pytest.mark.unit
    def test_file_status_equality(self) -> None:
        """FileStatus instances with same values are equal."""
        fs1 = FileStatus(
            collection_id="demographics", item_id="census-2020", filename="data.parquet"
        )
        fs2 = FileStatus(
            collection_id="demographics", item_id="census-2020", filename="data.parquet"
        )
        assert fs1 == fs2

    @pytest.mark.unit
    def test_file_status_path_includes_item_id(self) -> None:
        """path includes all three components."""
        fs = FileStatus(collection_id="col", item_id="item", filename="file.txt")
        parts = fs.path.split("/")
        assert parts == ["col", "item", "file.txt"]


# ─────────────────────────────────────────────────────────────────────────────
# TestStatusResult - dataclass behaviour
# ─────────────────────────────────────────────────────────────────────────────


class TestStatusResult:
    """Tests for the StatusResult dataclass."""

    @pytest.mark.unit
    def test_is_clean_all_empty(self) -> None:
        """is_clean returns True when all lists are empty."""
        result = StatusResult(untracked=[], modified=[], deleted=[])
        assert result.is_clean()

    @pytest.mark.unit
    def test_is_clean_with_untracked(self) -> None:
        """is_clean returns False when untracked files exist."""
        result = StatusResult(
            untracked=[FileStatus("col", "item", "file.parquet")],
            modified=[],
            deleted=[],
        )
        assert not result.is_clean()

    @pytest.mark.unit
    def test_is_clean_with_modified(self) -> None:
        """is_clean returns False when modified files exist."""
        result = StatusResult(
            untracked=[],
            modified=[FileStatus("col", "item", "file.parquet")],
            deleted=[],
        )
        assert not result.is_clean()

    @pytest.mark.unit
    def test_is_clean_with_deleted(self) -> None:
        """is_clean returns False when deleted files exist."""
        result = StatusResult(
            untracked=[],
            modified=[],
            deleted=[FileStatus("col", "item", "file.parquet")],
        )
        assert not result.is_clean()


# ─────────────────────────────────────────────────────────────────────────────
# TestIgnoredFiles - IGNORED_FILES constant behaviour
# ─────────────────────────────────────────────────────────────────────────────


class TestIgnoredFiles:
    """Tests for IGNORED_FILES default set."""

    @pytest.mark.unit
    def test_ignored_files_is_frozenset(self) -> None:
        """IGNORED_FILES should be a frozenset."""
        assert isinstance(IGNORED_FILES, frozenset)

    @pytest.mark.unit
    def test_ds_store_ignored(self) -> None:
        """.DS_Store should be in IGNORED_FILES."""
        assert ".DS_Store" in IGNORED_FILES

    @pytest.mark.unit
    def test_thumbs_db_ignored(self) -> None:
        """Thumbs.db should be in IGNORED_FILES."""
        assert "Thumbs.db" in IGNORED_FILES

    @pytest.mark.unit
    def test_gitkeep_ignored(self) -> None:
        """.gitkeep should be in IGNORED_FILES."""
        assert ".gitkeep" in IGNORED_FILES


# ─────────────────────────────────────────────────────────────────────────────
# TestUninitializedCollections - Bug #137: uninitialized dirs with geo-assets
# ─────────────────────────────────────────────────────────────────────────────


class TestUninitializedCollections:
    """Tests for detecting untracked files in uninitialized collections.

    Issue #137: status.py previously skipped any directory without
    collection.json, creating a chicken-and-egg problem — files were never
    shown as untracked before `portolan add` was run.

    After the fix, directories that contain geo-assets (geospatial files)
    but have no collection.json should still surface their files as untracked.
    Empty directories and non-geo-asset directories are ignored.
    """

    @pytest.mark.unit
    def test_uninitialized_dir_with_parquet_shows_untracked(self, tmp_path: Path) -> None:
        """A directory with a .parquet file but no collection.json shows untracked."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "demographics"
        col_dir.mkdir()
        # No collection.json — uninitialized
        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"fake parquet data")

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].collection_id == "demographics"
        assert result.untracked[0].item_id == "census-2020"
        assert result.untracked[0].filename == "data.parquet"
        assert not result.is_clean()

    @pytest.mark.unit
    def test_uninitialized_dir_with_geojson_shows_untracked(self, tmp_path: Path) -> None:
        """A directory with a .geojson file but no collection.json shows untracked."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "boundaries"
        col_dir.mkdir()
        item_dir = col_dir / "country-borders"
        item_dir.mkdir()
        (item_dir / "borders.geojson").write_text('{"type":"FeatureCollection","features":[]}')

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].collection_id == "boundaries"
        assert result.untracked[0].filename == "borders.geojson"

    @pytest.mark.unit
    def test_uninitialized_dir_with_tiff_shows_untracked(self, tmp_path: Path) -> None:
        """A directory with a .tif file but no collection.json shows untracked."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "imagery"
        col_dir.mkdir()
        item_dir = col_dir / "scene-001"
        item_dir.mkdir()
        (item_dir / "image.tif").write_bytes(b"\x00" * 64)

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].collection_id == "imagery"
        assert result.untracked[0].filename == "image.tif"

    @pytest.mark.unit
    def test_empty_uninitialized_dir_ignored(self, tmp_path: Path) -> None:
        """An empty directory without collection.json is ignored (not a potential collection)."""
        make_catalog(tmp_path)
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()

        result = get_catalog_status(tmp_path)

        assert result.is_clean()

    @pytest.mark.unit
    def test_non_geo_only_uninitialized_dir_ignored(self, tmp_path: Path) -> None:
        """A directory containing only non-geo files and no collection.json is ignored."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "docs-only"
        col_dir.mkdir()
        item_dir = col_dir / "readme-item"
        item_dir.mkdir()
        (item_dir / "README.txt").write_text("not geospatial")
        (item_dir / "notes.md").write_text("# Notes")

        result = get_catalog_status(tmp_path)

        # txt/md are not geo-assets, so the directory is not treated as a potential collection
        assert result.is_clean()

    @pytest.mark.unit
    def test_initialized_collection_still_works(self, tmp_path: Path) -> None:
        """Initialized collections (with collection.json) still work correctly."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)
        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"data")

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].collection_id == "demographics"

    @pytest.mark.unit
    def test_mix_initialized_and_uninitialized(self, tmp_path: Path) -> None:
        """Catalog with one initialized + one uninitialized collection shows both."""
        make_catalog(tmp_path, ["initialized"])

        # Initialized collection
        col1 = tmp_path / "initialized"
        make_collection(col1)
        item1 = col1 / "item-a"
        item1.mkdir()
        (item1 / "data.parquet").write_bytes(b"data")

        # Uninitialized potential collection (no collection.json)
        col2 = tmp_path / "uninitialized"
        col2.mkdir()
        item2 = col2 / "item-b"
        item2.mkdir()
        (item2 / "roads.geojson").write_text('{"type":"FeatureCollection","features":[]}')

        result = get_catalog_status(tmp_path)

        collection_ids = {f.collection_id for f in result.untracked}
        assert "initialized" in collection_ids
        assert "uninitialized" in collection_ids
        assert len(result.untracked) == 2

    @pytest.mark.unit
    def test_uninitialized_dir_multiple_geo_files(self, tmp_path: Path) -> None:
        """All geo-asset files in an uninitialized item dir are reported."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "imagery"
        col_dir.mkdir()
        item_dir = col_dir / "scene-001"
        item_dir.mkdir()
        (item_dir / "image.tif").write_bytes(b"\x00" * 64)
        (item_dir / "overview.pmtiles").write_bytes(b"\x00" * 32)

        result = get_catalog_status(tmp_path)

        filenames = {f.filename for f in result.untracked}
        assert "image.tif" in filenames
        assert "overview.pmtiles" in filenames

    @pytest.mark.unit
    def test_cli_status_shows_uninitialized_collection_files(self, tmp_path: Path) -> None:
        """CLI status command shows untracked files in uninitialized directories."""
        import os

        make_catalog(tmp_path)
        col_dir = tmp_path / "boundaries"
        col_dir.mkdir()
        item_dir = col_dir / "country-borders"
        item_dir.mkdir()
        (item_dir / "borders.geojson").write_text('{"type":"FeatureCollection","features":[]}')

        runner = CliRunner()
        old_cwd = os.getcwd()
        try:
            os.chdir(tmp_path)
            result = runner.invoke(cli, ["status"], catch_exceptions=False)
        finally:
            os.chdir(old_cwd)

        assert result.exit_code == 0
        assert "Untracked:" in result.output
        assert "boundaries/country-borders/borders.geojson" in result.output

    @pytest.mark.unit
    def test_has_geo_assets_returns_true_for_parquet(self, tmp_path: Path) -> None:
        """_has_geo_assets returns True when directory subtree has a .parquet file."""
        col_dir = tmp_path / "col"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"data")

        assert _has_geo_assets(col_dir) is True

    @pytest.mark.unit
    def test_has_geo_assets_returns_true_for_tif(self, tmp_path: Path) -> None:
        """_has_geo_assets returns True when directory subtree has a .tif file."""
        col_dir = tmp_path / "col"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()
        (item_dir / "image.tif").write_bytes(b"\x00" * 16)

        assert _has_geo_assets(col_dir) is True

    @pytest.mark.unit
    def test_has_geo_assets_returns_false_for_empty_dir(self, tmp_path: Path) -> None:
        """_has_geo_assets returns False for a directory with no files."""
        empty_dir = tmp_path / "empty"
        empty_dir.mkdir()

        assert _has_geo_assets(empty_dir) is False

    @pytest.mark.unit
    def test_has_geo_assets_returns_false_for_non_geo_files(self, tmp_path: Path) -> None:
        """_has_geo_assets returns False when no geospatial extensions are present."""
        col_dir = tmp_path / "col"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()
        (item_dir / "README.txt").write_text("docs")
        (item_dir / "notes.md").write_text("# notes")

        assert _has_geo_assets(col_dir) is False

    @pytest.mark.unit
    def test_ignored_files_not_counted_as_geo_assets(self, tmp_path: Path) -> None:
        """IGNORED_FILES (e.g. .DS_Store) don't cause a dir to be treated as geo-collection."""
        col_dir = tmp_path / "col"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()
        for name in IGNORED_FILES:
            (item_dir / name).write_bytes(b"")

        # Only ignored files present → should NOT be treated as a potential collection
        assert _has_geo_assets(col_dir) is False


# ─────────────────────────────────────────────────────────────────────────────
# TestStatusHypothesis - Property-based tests
# ─────────────────────────────────────────────────────────────────────────────


class TestStatusHypothesis:
    """Property-based tests for status module invariants.

    These tests use Hypothesis to verify that status behaves consistently
    regardless of the number of collections, items, and files involved.
    """

    @pytest.mark.unit
    @given(
        collection_names=st.lists(
            st.text(
                alphabet=st.characters(
                    whitelist_categories=("Ll", "Lu", "Nd"), whitelist_characters="-_"
                ),
                min_size=1,
                max_size=20,
            ).filter(lambda s: s[0].isalpha()),
            min_size=0,
            max_size=5,
            unique=True,
        )
    )
    @settings(
        max_examples=30, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_clean_catalog_always_reports_clean(
        self, tmp_path: Path, collection_names: list[str]
    ) -> None:
        """A catalog where all files are tracked+current is always clean.

        Uses a fresh tempdir per call to avoid state accumulation between
        Hypothesis examples (tmp_path is function-scoped, not example-scoped).
        """
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_catalog(root, collection_names)
            for col_name in collection_names:
                col_dir = root / col_name
                make_collection(col_dir)
                # No item dirs and no files → clean

            result = get_catalog_status(root)
            assert result.is_clean(), (
                f"Expected clean catalog but got: untracked={result.untracked}, "
                f"modified={result.modified}, deleted={result.deleted}"
            )

    @pytest.mark.unit
    @given(
        geo_ext=st.sampled_from(
            [
                ".parquet",
                ".geojson",
                ".tif",
                ".tiff",
                ".shp",
                ".gpkg",
                ".fgb",
                ".csv",
                ".tsv",
                ".jp2",
                ".pmtiles",  # Added from GEOSPATIAL_EXTENSIONS
            ]
        )
    )
    @settings(
        max_examples=25, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_geo_file_in_uninitialized_dir_always_appears_untracked(
        self, tmp_path: Path, geo_ext: str
    ) -> None:
        """Any geospatial file in an uninitialized directory always surfaces as untracked."""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_catalog(root)
            col_dir = root / "test-collection"
            col_dir.mkdir()
            # No collection.json — uninitialized
            item_dir = col_dir / "test-item"
            item_dir.mkdir()
            geo_file = item_dir / f"data{geo_ext}"
            geo_file.write_bytes(b"fake geo data content")

            result = get_catalog_status(root)

            filenames = [f.filename for f in result.untracked]
            assert f"data{geo_ext}" in filenames, (
                f"Expected data{geo_ext} to be untracked but got: {filenames}"
            )

    @pytest.mark.unit
    @given(
        num_untracked=st.integers(min_value=0, max_value=10),
        num_tracked=st.integers(min_value=0, max_value=10),
    )
    @settings(
        max_examples=20, deadline=5000, suppress_health_check=[HealthCheck.function_scoped_fixture]
    )
    def test_untracked_count_equals_files_not_in_versions_json(
        self, tmp_path: Path, num_untracked: int, num_tracked: int
    ) -> None:
        """Number of untracked results equals exactly the files not in versions.json."""
        with tempfile.TemporaryDirectory() as td:
            root = Path(td)
            make_catalog(root, ["test-col"])
            col_dir = root / "test-col"
            make_collection(col_dir)

            assets: dict[str, dict] = {}
            # Create tracked files (match mtime/size in versions.json)
            for i in range(num_tracked):
                item_dir = col_dir / f"tracked-{i}"
                item_dir.mkdir()
                f = item_dir / "data.parquet"
                f.write_bytes(b"tracked content")
                stat = f.stat()
                assets[f"tracked-{i}/data.parquet"] = asset_entry(
                    size_bytes=stat.st_size,
                    mtime=stat.st_mtime,
                    href=f"test-col/tracked-{i}/data.parquet",
                )

            # Create untracked files (no versions.json entry)
            for i in range(num_untracked):
                item_dir = col_dir / f"untracked-{i}"
                item_dir.mkdir()
                (item_dir / "data.parquet").write_bytes(b"untracked content")

            if assets:
                make_versions_json(col_dir, assets)

            result = get_catalog_status(root)
            assert len(result.untracked) == num_untracked, (
                f"Expected {num_untracked} untracked files but got {len(result.untracked)}"
            )


# ─────────────────────────────────────────────────────────────────────────────
# TestDeepNesting - Hive-partitioned datasets and deep directory structures
# ─────────────────────────────────────────────────────────────────────────────


class TestDeepNesting:
    """Tests for deeply nested geo-assets (hive partitions, complex structures).

    Verifies that _has_geo_assets correctly finds geo files at various depths,
    supporting hive-partitioned datasets like year=2024/month=01/data.parquet.
    """

    @pytest.mark.unit
    def test_hive_partitioned_parquet_depth_3(self, tmp_path: Path) -> None:
        """Geo file at depth 3 (hive partition) is detected."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "timeseries"
        col_dir.mkdir()
        # Hive partition structure: item/year=2024/month=01/data.parquet
        item_dir = col_dir / "weather-data"
        item_dir.mkdir()
        year_dir = item_dir / "year=2024"
        year_dir.mkdir()
        month_dir = year_dir / "month=01"
        month_dir.mkdir()
        (month_dir / "data.parquet").write_bytes(b"partitioned data")

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        # Filename includes full relative path from item dir
        assert result.untracked[0].filename == "year=2024/month=01/data.parquet"
        assert result.untracked[0].item_id == "weather-data"
        assert result.untracked[0].collection_id == "timeseries"

    @pytest.mark.unit
    def test_hive_partitioned_depth_4(self, tmp_path: Path) -> None:
        """Geo file at depth 4 is detected."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "deep-data"
        col_dir.mkdir()
        # item/year/month/day/data.parquet
        current = col_dir / "item"
        current.mkdir()
        for level in ["year=2024", "month=01", "day=15"]:
            current = current / level
            current.mkdir()
        (current / "data.geojson").write_text('{"type":"FeatureCollection","features":[]}')

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        # Filename includes full relative path from item dir
        assert result.untracked[0].filename == "year=2024/month=01/day=15/data.geojson"
        assert result.untracked[0].item_id == "item"

    @pytest.mark.unit
    def test_has_geo_assets_respects_max_depth(self, tmp_path: Path) -> None:
        """_has_geo_assets stops at max_depth to prevent runaway recursion."""
        col_dir = tmp_path / "very-deep"
        col_dir.mkdir()
        # Create structure deeper than default max_depth
        current = col_dir
        for i in range(10):  # More than default _MAX_GEO_SCAN_DEPTH (5)
            current = current / f"level-{i}"
            current.mkdir()
        (current / "data.parquet").write_bytes(b"very deep data")

        # With max_depth=3, should NOT find the file
        assert _has_geo_assets(col_dir, max_depth=3) is False

        # With sufficient depth, should find it
        assert _has_geo_assets(col_dir, max_depth=15) is True

    @pytest.mark.unit
    def test_geo_file_at_collection_root_not_detected(self, tmp_path: Path) -> None:
        """Geo file directly in collection dir (not in item subdir) is ignored.

        Files must be in item subdirectories per ADR-0023 structure.
        """
        make_catalog(tmp_path)
        col_dir = tmp_path / "flat-structure"
        col_dir.mkdir()
        # File directly in collection, not in an item subdirectory
        (col_dir / "data.parquet").write_bytes(b"flat data")

        result = get_catalog_status(tmp_path)

        # File at wrong level should not be detected
        assert result.is_clean()


# ─────────────────────────────────────────────────────────────────────────────
# TestSymlinks - Symlink handling
# ─────────────────────────────────────────────────────────────────────────────


class TestSymlinks:
    """Tests for symlink handling in status detection.

    Verifies that symlinks are followed correctly and broken symlinks
    are handled gracefully without crashing.
    """

    @pytest.mark.unit
    def test_symlink_to_geo_file_detected(self, tmp_path: Path) -> None:
        """Symlink pointing to a geo file is detected as untracked."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "symlinked"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()

        # Create real file outside the collection
        external = tmp_path / "external"
        external.mkdir()
        real_file = external / "real_data.parquet"
        real_file.write_bytes(b"real data")

        # Create symlink to the real file
        symlink = item_dir / "linked_data.parquet"
        symlink.symlink_to(real_file)

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "linked_data.parquet"

    @pytest.mark.unit
    def test_symlink_to_directory_followed(self, tmp_path: Path) -> None:
        """Symlink to a directory containing geo files is followed."""
        # Create catalog in a subdirectory so external dir isn't in catalog root
        catalog_root = tmp_path / "catalog"
        catalog_root.mkdir()
        make_catalog(catalog_root)
        col_dir = catalog_root / "col"
        col_dir.mkdir()

        # Real item directory OUTSIDE the catalog root
        external = tmp_path / "external-items"
        external.mkdir()
        real_item = external / "real-item"
        real_item.mkdir()
        (real_item / "data.tif").write_bytes(b"\x00" * 64)

        # Symlink to item directory inside the collection
        symlink_item = col_dir / "linked-item"
        symlink_item.symlink_to(real_item)

        result = get_catalog_status(catalog_root)

        assert len(result.untracked) == 1
        assert result.untracked[0].item_id == "linked-item"

    @pytest.mark.unit
    def test_broken_symlink_handled_gracefully(self, tmp_path: Path) -> None:
        """Broken symlinks are skipped without crashing."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "broken"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()

        # Create broken symlink
        broken_link = item_dir / "broken.parquet"
        broken_link.symlink_to(tmp_path / "nonexistent_file.parquet")

        # Also add a real geo file to ensure the directory is scanned
        (item_dir / "real.geojson").write_text('{"type":"FeatureCollection","features":[]}')

        result = get_catalog_status(tmp_path)

        # Should find the real file but not crash on the broken symlink
        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "real.geojson"

    @pytest.mark.unit
    def test_has_geo_assets_handles_broken_symlinks(self, tmp_path: Path) -> None:
        """_has_geo_assets handles broken symlinks without crashing."""
        col_dir = tmp_path / "col"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()

        # Only broken symlinks
        (item_dir / "broken.parquet").symlink_to(tmp_path / "gone.parquet")

        # Should return False, not crash
        assert _has_geo_assets(col_dir) is False


# ─────────────────────────────────────────────────────────────────────────────
# TestFileGDB - .gdb directory detection
# ─────────────────────────────────────────────────────────────────────────────


class TestFileGDB:
    """Tests for FileGDB (.gdb) directory detection.

    FileGDB is a directory, not a file, but should still trigger
    uninitialized collection detection.
    """

    @pytest.mark.unit
    def test_gdb_directory_triggers_uninitialized_detection(self, tmp_path: Path) -> None:
        """A .gdb directory in an uninitialized collection triggers detection."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "esri-data"
        col_dir.mkdir()
        item_dir = col_dir / "features"
        item_dir.mkdir()

        # Create a minimal FileGDB structure (just the directory)
        gdb_dir = item_dir / "MyDatabase.gdb"
        gdb_dir.mkdir()
        # FileGDB contains internal files
        (gdb_dir / "a00000001.gdbtable").write_bytes(b"gdb table data")

        assert _has_geo_assets(col_dir) is True

    @pytest.mark.unit
    def test_gdb_directory_case_insensitive(self, tmp_path: Path) -> None:
        """FileGDB detection is case-insensitive for .gdb extension."""
        col_dir = tmp_path / "col"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()

        # Mixed case
        gdb_dir = item_dir / "MyData.GDB"
        gdb_dir.mkdir()

        assert _has_geo_assets(col_dir) is True


# ─────────────────────────────────────────────────────────────────────────────
# TestMixedCaseExtensions - Case-insensitive extension matching
# ─────────────────────────────────────────────────────────────────────────────


class TestMixedCaseExtensions:
    """Tests for case-insensitive extension matching.

    Verifies that .TIF, .PARQUET, .GeoJSON, etc. are all recognized.
    """

    @pytest.mark.unit
    def test_uppercase_tif_detected(self, tmp_path: Path) -> None:
        """Uppercase .TIF extension is detected."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "imagery"
        col_dir.mkdir()
        item_dir = col_dir / "scene"
        item_dir.mkdir()
        (item_dir / "image.TIF").write_bytes(b"\x00" * 64)

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "image.TIF"

    @pytest.mark.unit
    def test_mixed_case_geojson_detected(self, tmp_path: Path) -> None:
        """Mixed case .GeoJSON extension is detected."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "boundaries"
        col_dir.mkdir()
        item_dir = col_dir / "borders"
        item_dir.mkdir()
        (item_dir / "data.GeoJSON").write_text('{"type":"FeatureCollection","features":[]}')

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "data.GeoJSON"

    @pytest.mark.unit
    def test_uppercase_parquet_detected(self, tmp_path: Path) -> None:
        """Uppercase .PARQUET extension is detected."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "vectors"
        col_dir.mkdir()
        item_dir = col_dir / "roads"
        item_dir.mkdir()
        (item_dir / "roads.PARQUET").write_bytes(b"parquet data")

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1

    @pytest.mark.unit
    def test_has_geo_assets_case_insensitive(self, tmp_path: Path) -> None:
        """_has_geo_assets handles mixed case extensions."""
        col_dir = tmp_path / "col"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()
        (item_dir / "DATA.TIFF").write_bytes(b"\x00" * 16)

        assert _has_geo_assets(col_dir) is True


# ─────────────────────────────────────────────────────────────────────────────
# TestTabularFormats - CSV/TSV detection via GEOSPATIAL_EXTENSIONS
# ─────────────────────────────────────────────────────────────────────────────


class TestTabularFormats:
    """Tests for CSV/TSV detection in uninitialized collections.

    CSV/TSV files are included in GEOSPATIAL_EXTENSIONS because they
    may contain geometry columns. Status should detect them.
    """

    @pytest.mark.unit
    def test_csv_triggers_uninitialized_detection(self, tmp_path: Path) -> None:
        """A .csv file in an uninitialized collection triggers detection."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "tabular"
        col_dir.mkdir()
        item_dir = col_dir / "points"
        item_dir.mkdir()
        (item_dir / "locations.csv").write_text("lat,lon,name\n40.7,-74.0,NYC")

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "locations.csv"

    @pytest.mark.unit
    def test_tsv_triggers_uninitialized_detection(self, tmp_path: Path) -> None:
        """A .tsv file in an uninitialized collection triggers detection."""
        make_catalog(tmp_path)
        col_dir = tmp_path / "tabular"
        col_dir.mkdir()
        item_dir = col_dir / "points"
        item_dir.mkdir()
        (item_dir / "locations.tsv").write_text("lat\tlon\tname\n40.7\t-74.0\tNYC")

        result = get_catalog_status(tmp_path)

        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "locations.tsv"


# ─────────────────────────────────────────────────────────────────────────────
# TestPermissionErrors - Error handling for inaccessible directories
# ─────────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────────
# TestExtensionConsistency - Verify no extension list drift
# ─────────────────────────────────────────────────────────────────────────────


class TestExtensionConsistency:
    """Tests to prevent extension list drift between modules.

    Verifies that status.py uses the canonical GEOSPATIAL_EXTENSIONS from
    constants.py rather than a local duplicate that could drift over time.
    """

    @pytest.mark.unit
    def test_status_uses_geospatial_extensions_from_constants(self) -> None:
        """Status module should import GEOSPATIAL_EXTENSIONS from constants.

        This test guards against accidentally creating a local extension list
        in status.py that could drift from the canonical list.
        """
        import portolan_cli.status as status_module

        # Verify the module doesn't define its own extension list
        assert not hasattr(status_module, "_GEO_ASSET_EXTENSIONS"), (
            "status.py should not define _GEO_ASSET_EXTENSIONS; "
            "use GEOSPATIAL_EXTENSIONS from constants.py instead"
        )

    @pytest.mark.unit
    def test_all_geospatial_extensions_trigger_detection(self, tmp_path: Path) -> None:
        """Every extension in GEOSPATIAL_EXTENSIONS should trigger detection.

        This test ensures that any new extension added to constants.py
        automatically works in status detection without code changes.
        """
        # Skip .gdb as it's a directory, not a file
        file_extensions = GEOSPATIAL_EXTENSIONS - {".gdb"}

        for ext in file_extensions:
            col_dir = tmp_path / f"col-{ext.replace('.', '')}"
            col_dir.mkdir()
            item_dir = col_dir / "item"
            item_dir.mkdir()
            (item_dir / f"data{ext}").write_bytes(b"test data")

            assert _has_geo_assets(col_dir), f"Extension {ext} should trigger detection"


# ─────────────────────────────────────────────────────────────────────────────
# TestPermissionErrors - Error handling for inaccessible directories
# ─────────────────────────────────────────────────────────────────────────────


class TestPermissionErrors:
    """Tests for handling permission and access errors gracefully."""

    @pytest.mark.unit
    def test_has_geo_assets_handles_permission_denied(self, tmp_path: Path) -> None:
        """_has_geo_assets logs and continues when permission is denied."""
        import os

        col_dir = tmp_path / "col"
        col_dir.mkdir()
        item_dir = col_dir / "item"
        item_dir.mkdir()

        # Add a geo file so the test can verify the function still works
        (item_dir / "data.parquet").write_bytes(b"data")

        # Create an unreadable directory (skip on Windows where this doesn't work)
        if os.name != "nt":
            unreadable = col_dir / "unreadable"
            unreadable.mkdir()
            os.chmod(unreadable, 0o000)
            try:
                # Should still find the accessible geo file
                assert _has_geo_assets(col_dir) is True
            finally:
                os.chmod(unreadable, 0o755)


# ─────────────────────────────────────────────────────────────────────────────
# TestSymlinkCycleDetection - Issue #178: Detect and skip symlink cycles
# ─────────────────────────────────────────────────────────────────────────────


class TestSymlinkCycleDetection:
    """Tests for symlink cycle detection in status scanning.

    Issue #178: Self-referential symlinks cause path explosion in status output.
    With a symlink like `ocha/ocha -> /path/to/ocha`, output shows infinite nesting:
        # Untracked: ocha/ocha/ocha/ocha/latest/...

    Solution: Track visited paths (via Path.resolve()) and skip cycles.
    """

    @pytest.mark.unit
    def test_self_referential_symlink_in_item_dir_skipped(self, tmp_path: Path) -> None:
        """A symlink pointing to its parent directory doesn't cause infinite recursion."""
        make_catalog(tmp_path, ["demographics"])
        col_dir = tmp_path / "demographics"
        make_collection(col_dir)

        # Create item directory with a geo file
        item_dir = col_dir / "census-2020"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"fake parquet data")

        # Create self-referential symlink: census-2020/self -> census-2020
        (item_dir / "self").symlink_to(item_dir)

        result = get_catalog_status(tmp_path)

        # Should find the geo file but not infinitely recurse
        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "data.parquet"

    @pytest.mark.unit
    def test_symlink_cycle_at_collection_level_skipped(self, tmp_path: Path) -> None:
        """A symlink cycle at collection level doesn't cause infinite recursion."""
        make_catalog(tmp_path, ["ocha"])
        col_dir = tmp_path / "ocha"
        make_collection(col_dir)

        # Create item directory with a geo file
        item_dir = col_dir / "boundaries"
        item_dir.mkdir()
        (item_dir / "data.geojson").write_bytes(b"{}")

        # Create symlink cycle: ocha/ocha -> /path/to/ocha
        (col_dir / "ocha").symlink_to(col_dir)

        result = get_catalog_status(tmp_path)

        # Should find the geo file but not infinitely recurse
        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "data.geojson"

    @pytest.mark.unit
    def test_has_geo_assets_handles_symlink_cycle(self, tmp_path: Path) -> None:
        """_has_geo_assets handles symlink cycles without infinite recursion."""
        col_dir = tmp_path / "col"
        col_dir.mkdir()

        # Create symlink cycle: col/self -> col
        (col_dir / "self").symlink_to(col_dir)

        # Create a geo file
        (col_dir / "data.parquet").write_bytes(b"data")

        # Should find the geo file and not hang
        assert _has_geo_assets(col_dir) is True

    @pytest.mark.unit
    def test_has_geo_assets_with_only_symlink_cycle_returns_false(self, tmp_path: Path) -> None:
        """_has_geo_assets returns False when directory only has symlink cycles."""
        col_dir = tmp_path / "empty-with-cycle"
        col_dir.mkdir()

        # Create symlink cycle: empty-with-cycle/self -> empty-with-cycle
        (col_dir / "self").symlink_to(col_dir)

        # No geo files, only a cycle
        assert _has_geo_assets(col_dir) is False

    @pytest.mark.unit
    def test_mutual_symlink_cycle_skipped(self, tmp_path: Path) -> None:
        """Mutual symlink cycles (A -> B -> A) are detected and skipped."""
        make_catalog(tmp_path, ["alpha"])
        col_dir = tmp_path / "alpha"
        make_collection(col_dir)

        # Create two directories with mutual symlinks
        dir_a = col_dir / "dir-a"
        dir_b = col_dir / "dir-b"
        dir_a.mkdir()
        dir_b.mkdir()

        # Add geo file to dir_a
        (dir_a / "data.parquet").write_bytes(b"data")

        # Create mutual symlinks: dir-a/to-b -> dir-b, dir-b/to-a -> dir-a
        (dir_a / "to-b").symlink_to(dir_b)
        (dir_b / "to-a").symlink_to(dir_a)

        result = get_catalog_status(tmp_path)

        # Should find the file from dir-a directly, plus once through dir-b/to-a
        # before the cycle is detected. The key is no infinite recursion.
        # We expect 2 results: data.parquet from dir-a, and to-a/data.parquet from dir-b
        assert len(result.untracked) == 2
        filenames = [f.filename for f in result.untracked]
        assert "data.parquet" in filenames
        assert "to-a/data.parquet" in filenames

    @pytest.mark.unit
    def test_deep_symlink_cycle_skipped(self, tmp_path: Path) -> None:
        """Deep symlink cycles (A -> B -> C -> A) are detected and skipped."""
        make_catalog(tmp_path, ["deep"])
        col_dir = tmp_path / "deep"
        make_collection(col_dir)

        # Create nested directories
        # Note: "a" is the item directory, so b/c are nested within it
        dir_a = col_dir / "a"
        dir_b = dir_a / "b"
        dir_c = dir_b / "c"
        dir_a.mkdir()
        dir_b.mkdir()
        dir_c.mkdir()

        # Add geo file at the deepest level
        (dir_c / "data.parquet").write_bytes(b"data")

        # Create symlink back to top: c/back-to-a -> a
        (dir_c / "back-to-a").symlink_to(dir_a)

        result = get_catalog_status(tmp_path)

        # Should find the file and not hang
        # The filename is relative to the item directory "a", so it includes "b/c/"
        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "b/c/data.parquet"
        assert result.untracked[0].item_id == "a"

    @pytest.mark.unit
    def test_valid_symlink_still_followed(self, tmp_path: Path) -> None:
        """Non-cyclic symlinks are still followed correctly."""
        make_catalog(tmp_path, ["linked"])
        col_dir = tmp_path / "linked"
        make_collection(col_dir)

        # Create a real directory outside the collection with geo files
        external_dir = tmp_path / "external-data"
        external_dir.mkdir()
        (external_dir / "external.parquet").write_bytes(b"external data")

        # Create item directory with a symlink to external dir
        item_dir = col_dir / "item"
        item_dir.mkdir()
        (item_dir / "linked-data").symlink_to(external_dir)
        (item_dir / "local.parquet").write_bytes(b"local data")

        result = get_catalog_status(tmp_path)

        # Should find both files (local and through symlink)
        filenames = sorted([f.filename for f in result.untracked])
        assert "local.parquet" in filenames
        assert "linked-data/external.parquet" in filenames

    @pytest.mark.unit
    def test_broken_symlink_skipped(self, tmp_path: Path) -> None:
        """Broken symlinks are skipped without error."""
        make_catalog(tmp_path, ["broken"])
        col_dir = tmp_path / "broken"
        make_collection(col_dir)

        item_dir = col_dir / "item"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"data")

        # Create broken symlink
        (item_dir / "broken-link").symlink_to(tmp_path / "nonexistent")

        result = get_catalog_status(tmp_path)

        # Should find the valid file and skip the broken link
        assert len(result.untracked) == 1
        assert result.untracked[0].filename == "data.parquet"

    @pytest.mark.unit
    def test_symlink_to_parent_in_hive_partition_skipped(self, tmp_path: Path) -> None:
        """Symlink to parent in hive-partitioned structure doesn't cause recursion."""
        make_catalog(tmp_path, ["hive"])
        col_dir = tmp_path / "hive"
        make_collection(col_dir)

        # Create hive-partitioned structure
        item_dir = col_dir / "dataset"
        year_dir = item_dir / "year=2024"
        month_dir = year_dir / "month=01"
        item_dir.mkdir()
        year_dir.mkdir()
        month_dir.mkdir()

        # Add geo file
        (month_dir / "data.parquet").write_bytes(b"partitioned data")

        # Create symlink back to item: month=01/back -> dataset
        (month_dir / "back").symlink_to(item_dir)

        result = get_catalog_status(tmp_path)

        # Should find the file and not hang
        assert len(result.untracked) == 1
        assert "year=2024/month=01/data.parquet" in result.untracked[0].filename

    @pytest.mark.unit
    def test_collection_symlink_to_sibling_collection_skipped(self, tmp_path: Path) -> None:
        """A collection-level symlink pointing to a sibling collection is skipped.

        True collection-level cycle: catalog_root/zzz-link -> catalog_root/aaa-real.
        The real collection is sorted first (aaa-real < zzz-link), processed, added to
        visited_col_dirs; when zzz-link resolves to the same physical directory it is
        detected and skipped so files are never double-counted.
        """
        # Use names that guarantee sort order: aaa-real processed before zzz-link
        make_catalog(tmp_path, ["aaa-real"])
        real_col = tmp_path / "aaa-real"
        make_collection(real_col)

        item_dir = real_col / "boundaries"
        item_dir.mkdir()
        (item_dir / "data.parquet").write_bytes(b"parquet data")

        # Create a peer symlink that sorts AFTER the real collection
        link_col = tmp_path / "zzz-link"
        link_col.symlink_to(real_col)

        result = get_catalog_status(tmp_path)

        # Files should appear exactly once under the first-processed name (aaa-real).
        # zzz-link resolves to the same dir and must be skipped.
        untracked_paths = [f.path for f in result.untracked]
        assert len(result.untracked) == 1, (
            f"Expected 1 untracked file, got {len(result.untracked)}: {untracked_paths}"
        )
        assert result.untracked[0].collection_id == "aaa-real"
        assert result.untracked[0].filename == "data.parquet"

    @pytest.mark.unit
    def test_two_items_symlinking_to_same_physical_dir_both_reported(self, tmp_path: Path) -> None:
        """Two item symlinks pointing to the same physical directory are both reported.

        Regression for the silent data-loss bug where visited_dirs was global across
        all collections/items.  If item-a and item-b both symlink to the same real
        directory, both items must be reported as untracked - not just the first.
        """
        make_catalog(tmp_path, ["col"])
        col_dir = tmp_path / "col"
        make_collection(col_dir)

        # A real data directory outside the collection
        real_data = tmp_path / "shared-data"
        real_data.mkdir()
        (real_data / "data.parquet").write_bytes(b"shared parquet data")

        # Two item directories that are both symlinks to the same real_data dir
        item_a = col_dir / "item-a"
        item_b = col_dir / "item-b"
        item_a.symlink_to(real_data)
        item_b.symlink_to(real_data)

        result = get_catalog_status(tmp_path)

        # Both items must be visible - neither should be silently skipped
        collection_ids = {f.collection_id for f in result.untracked}
        item_ids = {f.item_id for f in result.untracked}
        assert "col" in collection_ids
        assert "item-a" in item_ids, "item-a was silently skipped"
        assert "item-b" in item_ids, "item-b was silently skipped"
        assert len(result.untracked) == 2, (
            f"Expected 2 untracked files (one per item), got {len(result.untracked)}"
        )
