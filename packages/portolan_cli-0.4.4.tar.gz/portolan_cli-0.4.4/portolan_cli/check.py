"""Check command logic for validating and fixing geospatial files.

This module provides the check command functionality:
- Identifying files that need conversion to cloud-native formats
- Converting files with --fix flag
- Dry-run mode for previewing changes

Per ADR-0007, this module contains the logic; CLI commands are thin wrappers.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from portolan_cli.constants import GEOSPATIAL_EXTENSIONS, PARQUET_EXTENSION
from portolan_cli.conversion_config import ConversionOverrides, get_conversion_overrides
from portolan_cli.convert import (
    ConversionReport,
    ConversionResult,
    ConversionStatus,
    convert_directory,
)
from portolan_cli.formats import (
    CloudNativeStatus,
    get_cloud_native_status,
    get_effective_status,
    is_geoparquet,
)

logger = logging.getLogger(__name__)

# Extensions to check for cloud-native status
CHECK_EXTENSIONS: frozenset[str] = GEOSPATIAL_EXTENSIONS | frozenset({PARQUET_EXTENSION})


@dataclass
class FileStatus:
    """Status of a single file for check command.

    Attributes:
        path: Absolute path to the file.
        relative_path: Path relative to the check root.
        status: Cloud-native status (CLOUD_NATIVE, CONVERTIBLE, UNSUPPORTED).
        display_name: Human-readable format name.
        target_format: Target format if convertible, else None.
    """

    path: Path
    relative_path: str
    status: CloudNativeStatus
    display_name: str
    target_format: str | None


@dataclass
class CheckReport:
    """Report from checking a directory for cloud-native status.

    Attributes:
        root: Directory that was checked.
        files: List of FileStatus for each file found.
        conversion_report: Results from --fix conversion (None if not run).
    """

    root: Path
    files: list[FileStatus]
    conversion_report: ConversionReport | None = None

    @property
    def cloud_native_count(self) -> int:
        """Number of files already cloud-native."""
        return sum(1 for f in self.files if f.status == CloudNativeStatus.CLOUD_NATIVE)

    @property
    def convertible_count(self) -> int:
        """Number of files that can be converted."""
        return sum(1 for f in self.files if f.status == CloudNativeStatus.CONVERTIBLE)

    @property
    def unsupported_count(self) -> int:
        """Number of unsupported files."""
        return sum(1 for f in self.files if f.status == CloudNativeStatus.UNSUPPORTED)

    @property
    def total(self) -> int:
        """Total number of files checked."""
        return len(self.files)

    def to_dict(self) -> dict[str, Any]:
        """Convert to JSON-serializable dictionary."""
        result: dict[str, Any] = {
            "root": str(self.root),
            "summary": {
                "total": self.total,
                "cloud_native": self.cloud_native_count,
                "convertible": self.convertible_count,
                "unsupported": self.unsupported_count,
            },
            "files": [
                {
                    "path": str(f.path),
                    "relative_path": f.relative_path,
                    "status": f.status.value,
                    "format": f.display_name,
                    "target_format": f.target_format,
                }
                for f in self.files
            ],
        }
        if self.conversion_report is not None:
            result["conversion"] = self.conversion_report.to_dict()
        return result


def check_directory(
    path: Path,
    *,
    fix: bool = False,
    dry_run: bool = False,
    on_progress: Callable[[ConversionResult], None] | None = None,
    catalog_path: Path | None = None,
) -> CheckReport:
    """Check a directory for cloud-native status and optionally fix.

    Scans the directory for geospatial files and reports their cloud-native
    status. With --fix, converts CONVERTIBLE files to cloud-native formats.

    Respects conversion config from .portolan/config.yaml if catalog_path is
    provided. This allows:
    - Force-converting cloud-native formats (e.g., FlatGeobuf -> GeoParquet)
    - Preserving convertible formats (e.g., keeping Shapefiles as-is)
    - Path-based overrides (e.g., preserving everything in archive/)

    Args:
        path: Directory to check.
        fix: If True, convert convertible files to cloud-native formats.
        dry_run: If True, preview what would be converted without changes.
        on_progress: Optional callback for conversion progress (--fix mode).
        catalog_path: Optional catalog root for loading conversion config.
            If provided, loads conversion overrides from .portolan/config.yaml.

    Returns:
        CheckReport with file statuses and conversion results (if fix=True).

    Raises:
        FileNotFoundError: If the directory does not exist.
        NotADirectoryError: If the path is not a directory.

    See Also:
        - GitHub Issue #75: FlatGeobuf cloud-native status
        - GitHub Issue #103: Config for non-cloud-native file handling
    """
    if not path.exists():
        raise FileNotFoundError(f"Directory not found: {path}")

    if not path.is_dir():
        raise NotADirectoryError(f"Path is not a directory: {path}")

    # Load conversion overrides from config (if catalog_path provided)
    overrides: ConversionOverrides | None = None
    if catalog_path is not None:
        overrides = get_conversion_overrides(catalog_path)

    # Scan for geospatial files
    files = _scan_for_files(path)

    # Get cloud-native status for each file (with overrides applied)
    file_statuses = []
    for file_path in files:
        relative = _get_relative_path(file_path, path)
        if overrides is not None:
            status_info = get_effective_status(file_path, overrides=overrides, root=catalog_path)
        else:
            status_info = get_cloud_native_status(file_path)
        file_statuses.append(
            FileStatus(
                path=file_path,
                relative_path=relative,
                status=status_info.status,
                display_name=status_info.display_name,
                target_format=status_info.target_format,
            )
        )

    report = CheckReport(root=path, files=file_statuses)

    # Handle fix mode
    if fix and not dry_run:
        # Only convert files that are CONVERTIBLE (not cloud-native, not unsupported)
        convertible_files = [
            f.path for f in file_statuses if f.status == CloudNativeStatus.CONVERTIBLE
        ]
        conversion_report = convert_directory(
            path,
            on_progress=on_progress,
            file_paths=convertible_files,
        )
        report.conversion_report = conversion_report
    elif fix and dry_run:
        # Preview mode - create results showing what would be converted
        preview_results = [
            ConversionResult(
                source=f.path,
                output=f.path.parent / f"{f.path.stem}.parquet"
                if f.target_format == "GeoParquet"
                else f.path.parent / f"{f.path.stem}.tif",
                format_from=f.display_name,
                format_to=f.target_format,
                status=ConversionStatus.SUCCESS,  # Predicted outcome
                error=None,
                duration_ms=0,
            )
            for f in file_statuses
            if f.status == CloudNativeStatus.CONVERTIBLE
        ]
        report.conversion_report = ConversionReport(results=preview_results)

    return report


def _scan_for_files(path: Path) -> list[Path]:
    """Scan directory for geospatial files.

    Args:
        path: Directory to scan.

    Returns:
        List of paths to geospatial files, sorted.
    """
    files: list[Path] = []
    for item in path.rglob("*"):
        if not item.is_file():
            continue
        ext = item.suffix.lower()
        if ext in CHECK_EXTENSIONS:
            # For parquet, check if it's GeoParquet
            if ext == PARQUET_EXTENSION:
                if not is_geoparquet(item):
                    continue
            files.append(item)
    files.sort()
    return files


def _get_relative_path(file_path: Path, root: Path) -> str:
    """Get path relative to root as forward-slash string.

    Returns paths with forward slashes regardless of OS for STAC compatibility.
    STAC uses URL-style paths which always use forward slashes.
    """
    try:
        return file_path.relative_to(root).as_posix()
    except ValueError:
        return file_path.as_posix()
