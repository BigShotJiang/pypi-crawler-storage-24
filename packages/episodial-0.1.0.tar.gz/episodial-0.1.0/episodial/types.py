"""Type definitions for all Episodial API request/response models."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------

@dataclass
class DependencyStatus:
    connected: bool
    latency_ms: Optional[float] = None
    error: Optional[str] = None


@dataclass
class HealthResponse:
    status: str
    service: str
    version: str
    timestamp: str
    dependencies: Dict[str, DependencyStatus] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Memory — Ingest
# ---------------------------------------------------------------------------

@dataclass
class EpisodicEvent:
    user_id: str
    project_id: str
    event_type: str
    payload: Dict[str, Any]
    chat_id: Optional[str] = None
    timestamp: Optional[str] = None
    initial_salience: float = 0.5


@dataclass
class IngestResponse:
    success: bool
    event_id: str
    message: str


# ---------------------------------------------------------------------------
# Memory — Retrieve
# ---------------------------------------------------------------------------

@dataclass
class MemoryBlock:
    content: str
    memory_type: str  # episodic | semantic | procedural
    salience: float
    relevance_score: float
    created_at: str
    source_ids: List[str] = field(default_factory=list)
    chat_id: Optional[str] = None


@dataclass
class RetrievalResponse:
    memories: List[MemoryBlock]
    total_tokens: int
    truncated: bool = False


# ---------------------------------------------------------------------------
# Memory — Feedback
# ---------------------------------------------------------------------------

@dataclass
class FeedbackResponse:
    success: bool
    memory_id: str
    new_salience: float
    message: str


# ---------------------------------------------------------------------------
# Memory — Forget
# ---------------------------------------------------------------------------

@dataclass
class ForgetResponse:
    success: bool
    forgotten_count: int
    audit_id: str
    message: str


# ---------------------------------------------------------------------------
# Memory — Consolidation
# ---------------------------------------------------------------------------

@dataclass
class ConsolidateResponse:
    success: bool
    clusters_found: int
    memories_created: int


# ---------------------------------------------------------------------------
# Memory — Procedural
# ---------------------------------------------------------------------------

@dataclass
class Procedure:
    id: str
    pattern_name: str
    readable: str
    condition: str
    sequence: List[str]
    outcome: str
    confidence: float
    occurrence_count: int


@dataclass
class ProcedureMatchResponse:
    success: bool
    procedures: List[Procedure]
    count: int


# ---------------------------------------------------------------------------
# Billing
# ---------------------------------------------------------------------------

@dataclass
class BalanceResponse:
    balance_cents: int
    balance_dollars: float
    today_operations: Dict[str, int]
    today_total_operations: int
    today_cost_cents: int
    today_cost_dollars: float


@dataclass
class OperationPricing:
    label: str
    cost_per_1000: str
    cost_per_unit_cents: float


@dataclass
class TopupPack:
    name: str
    deposit_cents: int
    bonus_pct: int
    balance_cents: int
    note: Optional[str] = None


@dataclass
class PricingResponse:
    model: str
    currency: str
    operations: Dict[str, OperationPricing]
    topup_packs: List[TopupPack]


@dataclass
class TopupResponse:
    pack: str
    deposited_cents: int
    bonus_cents: int
    total_credited_cents: int
    new_balance_cents: int


# ---------------------------------------------------------------------------
# Migration
# ---------------------------------------------------------------------------

@dataclass
class ImportResult:
    success: bool
    imported: int
    skipped: int
    errors: int
    total: int
    dry_run: bool
    details: List[Dict[str, Any]] = field(default_factory=list)


@dataclass
class ExportResponse:
    user_id: str
    project_id: Optional[str]
    exported_at: str
    format_version: str
    episodic_memories: List[Dict[str, Any]]
    semantic_memories: List[Dict[str, Any]]
    total_episodic: int
    total_semantic: int
