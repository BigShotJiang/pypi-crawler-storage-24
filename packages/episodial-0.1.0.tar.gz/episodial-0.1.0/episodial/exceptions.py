"""Custom exceptions for the Episodial SDK."""

from __future__ import annotations


class EpisodialError(Exception):
    """Base exception for Episodial API errors."""

    def __init__(self, message: str, status: int = 0, body: str = "") -> None:
        super().__init__(message)
        self.status = status
        self.body = body

    def __repr__(self) -> str:
        return f"EpisodialError(status={self.status}, message={self!s})"


class InsufficientBalanceError(EpisodialError):
    """Raised when the prepaid balance is too low (HTTP 402)."""

    def __init__(self, body: str = "") -> None:
        super().__init__("Insufficient prepaid balance — top up to continue.", 402, body)
