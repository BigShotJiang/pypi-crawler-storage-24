from cstvis import Changer

from mutating_core.converters import collector


def test_increasing_int():
    changer = Changer('1 + 1', collector=collector)

    assert [changer.apply_coordinate(x) for x in changer.iterate_coordinates()] == [
        '2 + 1',
        '1 + 2',
    ]


def test_increasing_float():
    changer = Changer('1.0 + 2.0', collector=collector)

    assert [changer.apply_coordinate(x) for x in changer.iterate_coordinates()] == [
        '2.0 + 2.0',
        '1.0 + 3.0',
    ]


def test_changing_strings():
    changer = Changer('a = "kek"', collector=collector)

    assert [changer.apply_coordinate(x) for x in changer.iterate_coordinates()] == [
        'a = "XXkekXX"',
    ]


def test_not_changing_bytes_strings():
    changer = Changer('a = b"kek"', collector=collector)

    assert [changer.apply_coordinate(x) for x in changer.iterate_coordinates()] == [
        'a = b"kek"',
    ]


def test_not_changing_tripple_quotted_strings():
    changer = Changer('a = \"\"\"kek\"\"\"', collector=collector)

    assert [changer.apply_coordinate(x) for x in changer.iterate_coordinates()] == [
        'a = \"\"\"kek\"\"\"',
    ]
