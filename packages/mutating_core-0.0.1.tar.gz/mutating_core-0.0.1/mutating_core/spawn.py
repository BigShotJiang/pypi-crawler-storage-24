from cstvis import Changer
from dirstree import PythonCrawler

from mutating_core.config import config
from mutating_core.converters import collector
from mutating_core.executors.abstract import AbstractExecutor
from mutating_core.executors.local import LocalExecutor


def spawn(executor: AbstractExecutor = LocalExecutor()) -> list:
    for path in PythonCrawler(*(config.code), exclude=config.exclude):
        code = path.read_text(encoding="utf-8")
        changer = Changer(code, collector=collector)
        coordinates = [coordinate for coordinate in changer.iterate_coordinates()]

        for coordinate in coordinates:
            coordinate.file = path

        results = executor(coordinates)

        print(f'{path} -> {len([x for x in results if x.is_killed])}/{len(results)} killed')


        for result in results:
            if not result.is_killed:
                print()
                print('______________________________')
                print('not killed:')
                print(result.coordinate)
                print('______________________________')
