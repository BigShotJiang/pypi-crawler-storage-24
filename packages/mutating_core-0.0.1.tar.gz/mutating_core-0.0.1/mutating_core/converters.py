from typing import Union

import libcst as cst
from cstvis import Collector

collector = Collector()

@collector.converter
def convert_numbers(node: Union[cst.Integer, cst.Float], context):
    return node.with_changes(value=repr(node.evaluated_value + 1))


@collector.converter
def convert_strings(node: str, context):
    if node.prefix == '' and node.quote in ('"', "'"):
        return node.with_changes(value=f'{node.prefix}{node.quote}XX{node.evaluated_value}XX{node.quote}')
    return node
