from dataclasses import dataclass

from cstvis import Coordinate


@dataclass
class MutationResult:
    coordinate: Coordinate
    is_killed: bool
    # TODO: добавить дифф, чтобы показывать потом в финальном выводе было и стало
