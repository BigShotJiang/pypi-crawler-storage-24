from typing import List, Union
from pathlib import Path

from skelet import Field, Storage, FixedCLISource, for_tool


CLI = FixedCLISource(positional_arguments=['code'])

class MutsConfig(Storage, sources=for_tool('mutating')):
    code: Union[str, Path] = Field('.', sources=[CLI])
    exclude: List[str] = Field(default_factory=lambda: ['venv/', '.git/', '__init__.py', 'tests'])
    timeout: Union[int, float] = Field(10)
    test_command: str = Field('pytest')

config = MutsConfig()
