from typing import List

from pristan import slot
from cstvis import Collector


@slot(entrypoint_group='mutating')
def get_collectors() -> List[Collector]:
    ...
