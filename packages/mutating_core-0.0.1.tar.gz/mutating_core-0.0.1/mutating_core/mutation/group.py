from typing import List, Callable
from itertools import count

from cstvis import Collector
from getsources import getsourcehash

from mutating_core.mutation.slot import get_collectors



class MutationGroup:
    def __init__(self, prefix: str) -> None:
        self.prefix = prefix.upper()
        self.counter = count()
        self.collector = Collector(meta={'prefix': prefix})

        @get_collectors.plugin
        def get_plugin():
            return self.collector

    def mutation(self, function: Callable) -> Callable:
        number = next(self.counter) + 1
        self.collector.converter(meta={'identifier': self.prefix + str(number), 'number': number, 'hash': getsourcehash(function, only_body=True, skip_docstring=True)})(function)
        return function
