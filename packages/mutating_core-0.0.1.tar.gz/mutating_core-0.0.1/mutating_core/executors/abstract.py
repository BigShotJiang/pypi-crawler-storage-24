from abc import ABC, abstractmethod

from cstvis import Coordinate

from mutating_core.config import MutsConfig
from mutating_core.mutation_result import MutationResult


class AbstractExecutor(ABC):
    @abstractmethod
    def apply_coordinate(self, coordinate: Coordinate, config: MutsConfig) -> MutationResult:
        return MutationResult(coordinate, True)
