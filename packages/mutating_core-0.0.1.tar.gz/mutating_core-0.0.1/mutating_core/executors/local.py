from typing import List

from cstvis import Changer, Coordinate
from suby import suby

from mutating_core.config import MutsConfig, config
from mutating_core.converters import collector
from mutating_core.executors.abstract import AbstractExecutor
from mutating_core.mutation_result import MutationResult


class LocalExecutor(AbstractExecutor):
    def __call__(self, coordinates: List[Coordinate]) -> List[MutationResult]:
        return [self.apply_coordinate(coordinate, config) for coordinate in coordinates]

    def apply_coordinate(self, coordinate: Coordinate, config: MutsConfig) -> MutationResult:
        code = coordinate.file.read_text(encoding="utf-8")
        changer = Changer(code, collector=collector)



        coordinate.file.write_text(changer.apply_coordinate(coordinate))

        command_result = suby(config.test_command, catch_output=True, timeout=config.timeout, catch_exceptions=True)

        coordinate.file.write_text(code)

        return MutationResult(
            coordinate=coordinate,
            is_killed=(command_result.returncode != 0),
        )
