# muts_core

Mutations from mutmut:

1. Number + 1
2. str -> XXstrXX
3. lambda x: ... -> lambda x: None, lambda x: 0
4. dict(a=b, c=d) -> dict(aXX=b, c=d), dict(a=b, cXX=d)
5. foo(a, b) -> foo(b), foo(a)
6. a.lower() -> a.upper()
7. Remove any unary operators
8. is -> is not, is not -> is, in -> not in, not in -> in, break -> return, continue -> break
9. True -> False, False -> True, deepcopy -> copy
10. This mapping:

{
    cst.Plus: cst.Minus,
    cst.Add: cst.Subtract,
    cst.Minus: cst.Plus,
    cst.Subtract: cst.Add,
    cst.Multiply: cst.Divide,
    cst.Divide: cst.Multiply,
    cst.FloorDivide: cst.Divide,
    cst.Modulo: cst.Divide,
    cst.LeftShift: cst.RightShift,
    cst.RightShift: cst.LeftShift,
    cst.BitAnd: cst.BitOr,
    cst.BitOr: cst.BitAnd,
    cst.BitXor: cst.BitAnd,
    cst.Power: cst.Multiply,
    cst.AddAssign: cst.SubtractAssign,
    cst.SubtractAssign: cst.AddAssign,
    cst.MultiplyAssign: cst.DivideAssign,
    cst.DivideAssign: cst.MultiplyAssign,
    cst.FloorDivideAssign: cst.DivideAssign,
    cst.ModuloAssign: cst.DivideAssign,
    cst.LeftShiftAssign: cst.RightShiftAssign,
    cst.RightShiftAssign: cst.LeftShiftAssign,
    cst.BitAndAssign: cst.BitOrAssign,
    cst.BitOrAssign: cst.BitAndAssign,
    cst.BitXorAssign: cst.BitAndAssign,
    cst.PowerAssign: cst.MultiplyAssign,
    cst.LessThan: cst.LessThanEqual,
    cst.LessThanEqual: cst.LessThan,
    cst.GreaterThan: cst.GreaterThanEqual,
    cst.GreaterThanEqual: cst.GreaterThan,
    cst.Equal: cst.NotEqual,
    cst.NotEqual: cst.Equal,
    cst.And: cst.Or,
    cst.Or: cst.And,
}

11. mutate all augmented assignments (+=, *=, |=, etc.) to normal = assignments
12. mutate `a = b` to `a = None` and `a = None` to `a = ""
13. Drop the case statements in a match.


Example prompt (in Russian):

> Я запустил мутационное тестирование и узнал, что если мы в файле @awaits/utils/end_of_wrappers.py в 15 строке мы заменим 0 на 2 - этого мутанта наши тесты не убивают. Напиши ОДИН тест, который его убьет. Для этого тебе нужно 1. понять общую логику этого участка кода; 2. понять, как она ломается, если мы сделаем это изменение; 3. временно изменить этот участок кода и попробовать запустить тесты, убедиться, что не падают; 4. написать тест, который проверяет ту логику, которую ты выявил, он должен падать; 5. "починить" код, который ты сломал, и убедиться, что тест больше не падает; 6. если не сработало - попробуй вернуть все как было и снова начать с 1 пункта, но придумать другую гипотезу, и так по кругу, пока не получится (сами гипотезы где-то записывай, чтобы не повторяться). В итоге должен получиться ОДИН новый тест (убедись, что он всего один!), все остальное состояние репозитория должно остаться нетронутым.
