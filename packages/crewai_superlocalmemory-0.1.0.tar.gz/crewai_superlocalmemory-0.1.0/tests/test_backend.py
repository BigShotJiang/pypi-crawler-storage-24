"""Tests for SuperLocalMemoryBackend (CrewAI StorageBackend).

Uses InMemoryBackend subclass to avoid SQL parsing complexity.

Part of Qualixar | Author: Varun Pratap Bhardwaj (qualixar.com | varunpratap.com)
Paper: https://arxiv.org/abs/2603.14588
"""

from __future__ import annotations

import json
import math
from datetime import UTC, datetime
from typing import Any

import pytest
from crewai.memory.types import MemoryRecord

from crewai_superlocalmemory.backend import _cosine_sim


# ---------------------------------------------------------------------------
# In-memory test backend (pure dict storage, no SQL)
# ---------------------------------------------------------------------------

class InMemoryBackend:
    """Test-only backend using plain dicts instead of SQLite."""

    def __init__(self, profile_id: str = "test") -> None:
        self._profile_id = profile_id
        self._store: dict[str, dict[str, Any]] = {}

    def save(self, records: list[MemoryRecord]) -> None:
        for record in records:
            self._store[f"{self._profile_id}:{record.id}"] = {
                "id": record.id,
                "profile_id": self._profile_id,
                "content": record.content,
                "scope": record.scope,
                "categories": list(record.categories),
                "metadata": dict(record.metadata),
                "importance": record.importance,
                "created_at": record.created_at,
                "last_accessed": record.last_accessed,
                "embedding": list(record.embedding) if record.embedding else None,
                "source": record.source,
                "private": record.private,
            }

    def search(
        self,
        query_embedding: list[float],
        scope_prefix: str | None = None,
        categories: list[str] | None = None,
        metadata_filter: dict[str, Any] | None = None,
        limit: int = 10,
        min_score: float = 0.0,
    ) -> list[tuple[MemoryRecord, float]]:
        scored: list[tuple[MemoryRecord, float]] = []
        for key, data in self._store.items():
            if not key.startswith(f"{self._profile_id}:"):
                continue
            if scope_prefix and not data["scope"].startswith(scope_prefix):
                continue
            if categories and not any(
                c in data["categories"] for c in categories
            ):
                continue
            if metadata_filter:
                skip = False
                for k, v in metadata_filter.items():
                    if data["metadata"].get(k) != v:
                        skip = True
                        break
                if skip:
                    continue

            score = 0.0
            if data["embedding"] and query_embedding:
                score = _cosine_sim(query_embedding, data["embedding"])
            if score >= min_score:
                record = self._data_to_record(data)
                scored.append((record, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:limit]

    def delete(
        self,
        scope_prefix: str | None = None,
        categories: list[str] | None = None,
        record_ids: list[str] | None = None,
        older_than: datetime | None = None,
        metadata_filter: dict[str, Any] | None = None,
    ) -> int:
        to_remove: list[str] = []
        for key, data in self._store.items():
            if not key.startswith(f"{self._profile_id}:"):
                continue
            if record_ids and data["id"] not in record_ids:
                continue
            if record_ids and data["id"] in record_ids:
                to_remove.append(key)
                continue
            if scope_prefix and not data["scope"].startswith(scope_prefix):
                continue
            if older_than and data["created_at"] >= older_than:
                continue
            to_remove.append(key)
        for key in to_remove:
            del self._store[key]
        return len(to_remove)

    def update(self, record: MemoryRecord) -> None:
        self.save([record])

    def get_record(self, record_id: str) -> MemoryRecord | None:
        key = f"{self._profile_id}:{record_id}"
        data = self._store.get(key)
        if data is None:
            return None
        return self._data_to_record(data)

    @staticmethod
    def _data_to_record(data: dict[str, Any]) -> MemoryRecord:
        return MemoryRecord(
            id=data["id"],
            content=data["content"],
            scope=data["scope"],
            categories=data["categories"],
            metadata=data["metadata"],
            importance=data["importance"],
            created_at=data["created_at"],
            last_accessed=data["last_accessed"],
            embedding=data["embedding"],
            source=data["source"],
            private=data["private"],
        )


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def backend() -> InMemoryBackend:
    return InMemoryBackend(profile_id="test-crew")


def _make_record(
    content: str = "test memory",
    record_id: str = "r001",
    scope: str = "/",
    categories: list[str] | None = None,
    importance: float = 0.5,
    embedding: list[float] | None = None,
) -> MemoryRecord:
    return MemoryRecord(
        id=record_id,
        content=content,
        scope=scope,
        categories=categories or [],
        importance=importance,
        embedding=embedding,
    )


# ---------------------------------------------------------------------------
# Tests: cosine_sim
# ---------------------------------------------------------------------------

class TestCosineSim:
    def test_identical_vectors(self) -> None:
        v = [1.0, 0.0, 1.0]
        assert abs(_cosine_sim(v, v) - 1.0) < 1e-6

    def test_orthogonal_vectors(self) -> None:
        assert abs(_cosine_sim([1, 0], [0, 1])) < 1e-6

    def test_opposite_vectors(self) -> None:
        assert abs(_cosine_sim([1, 0], [-1, 0]) - (-1.0)) < 1e-6

    def test_empty_vectors(self) -> None:
        assert _cosine_sim([], [1, 2]) == 0.0
        assert _cosine_sim([1, 2], []) == 0.0

    def test_mismatched_lengths(self) -> None:
        assert _cosine_sim([1, 2], [1, 2, 3]) == 0.0

    def test_zero_vector(self) -> None:
        assert _cosine_sim([0, 0], [1, 2]) == 0.0


# ---------------------------------------------------------------------------
# Tests: save & get_record
# ---------------------------------------------------------------------------

class TestSaveAndGet:
    def test_save_single_record(self, backend: InMemoryBackend) -> None:
        record = _make_record(content="Alice likes Python")
        backend.save([record])
        retrieved = backend.get_record("r001")
        assert retrieved is not None
        assert retrieved.content == "Alice likes Python"
        assert retrieved.id == "r001"

    def test_save_preserves_scope(self, backend: InMemoryBackend) -> None:
        record = _make_record(scope="/project/backend")
        backend.save([record])
        retrieved = backend.get_record("r001")
        assert retrieved is not None
        assert retrieved.scope == "/project/backend"

    def test_save_preserves_categories(self, backend: InMemoryBackend) -> None:
        record = _make_record(categories=["tech", "python"])
        backend.save([record])
        retrieved = backend.get_record("r001")
        assert retrieved is not None
        assert "tech" in retrieved.categories
        assert "python" in retrieved.categories

    def test_save_preserves_embedding(self, backend: InMemoryBackend) -> None:
        record = _make_record(embedding=[0.1, 0.2, 0.3])
        backend.save([record])
        retrieved = backend.get_record("r001")
        assert retrieved is not None
        assert retrieved.embedding == [0.1, 0.2, 0.3]

    def test_save_multiple_records(self, backend: InMemoryBackend) -> None:
        records = [
            _make_record(content="first", record_id="r1"),
            _make_record(content="second", record_id="r2"),
        ]
        backend.save(records)
        assert backend.get_record("r1") is not None
        assert backend.get_record("r2") is not None

    def test_get_nonexistent_returns_none(
        self, backend: InMemoryBackend,
    ) -> None:
        assert backend.get_record("nonexistent") is None

    def test_update_replaces_record(self, backend: InMemoryBackend) -> None:
        backend.save([_make_record(content="v1")])
        updated = _make_record(content="v2")
        backend.update(updated)
        retrieved = backend.get_record("r001")
        assert retrieved is not None
        assert retrieved.content == "v2"


# ---------------------------------------------------------------------------
# Tests: search
# ---------------------------------------------------------------------------

class TestSearch:
    def test_search_by_embedding(self, backend: InMemoryBackend) -> None:
        backend.save([
            _make_record("Python", "r1", embedding=[1.0, 0.0]),
            _make_record("Java", "r2", embedding=[0.0, 1.0]),
        ])
        results = backend.search(query_embedding=[1.0, 0.0], limit=5)
        assert len(results) == 2
        assert results[0][0].content == "Python"
        assert abs(results[0][1] - 1.0) < 1e-6

    def test_search_min_score_filter(self, backend: InMemoryBackend) -> None:
        backend.save([
            _make_record("close", "r1", embedding=[0.9, 0.1]),
            _make_record("far", "r2", embedding=[0.0, 1.0]),
        ])
        results = backend.search(query_embedding=[1.0, 0.0], min_score=0.5)
        assert len(results) == 1
        assert results[0][0].content == "close"

    def test_search_scope_prefix(self, backend: InMemoryBackend) -> None:
        backend.save([
            _make_record("in scope", "r1", scope="/project/backend",
                         embedding=[1.0, 0.0]),
            _make_record("out of scope", "r2", scope="/personal",
                         embedding=[1.0, 0.0]),
        ])
        results = backend.search(
            query_embedding=[1.0, 0.0], scope_prefix="/project",
        )
        assert len(results) == 1
        assert results[0][0].content == "in scope"

    def test_search_category_filter(self, backend: InMemoryBackend) -> None:
        backend.save([
            _make_record("tagged", "r1", categories=["python"],
                         embedding=[1.0, 0.0]),
            _make_record("untagged", "r2", categories=["java"],
                         embedding=[1.0, 0.0]),
        ])
        results = backend.search(
            query_embedding=[1.0, 0.0], categories=["python"],
        )
        assert len(results) == 1
        assert results[0][0].content == "tagged"

    def test_search_limit(self, backend: InMemoryBackend) -> None:
        for i in range(5):
            backend.save([
                _make_record(f"item-{i}", f"r{i}", embedding=[1.0, 0.0]),
            ])
        results = backend.search(query_embedding=[1.0, 0.0], limit=3)
        assert len(results) == 3

    def test_search_no_embeddings(self, backend: InMemoryBackend) -> None:
        backend.save([_make_record("no embedding", "r1")])
        results = backend.search(query_embedding=[1.0, 0.0], min_score=0.1)
        assert len(results) == 0


# ---------------------------------------------------------------------------
# Tests: delete
# ---------------------------------------------------------------------------

class TestDelete:
    def test_delete_by_ids(self, backend: InMemoryBackend) -> None:
        backend.save([
            _make_record("keep", "r1"),
            _make_record("delete", "r2"),
        ])
        count = backend.delete(record_ids=["r2"])
        assert count == 1
        assert backend.get_record("r1") is not None
        assert backend.get_record("r2") is None

    def test_delete_by_scope(self, backend: InMemoryBackend) -> None:
        backend.save([
            _make_record("in scope", "r1", scope="/temp"),
            _make_record("keep", "r2", scope="/permanent"),
        ])
        count = backend.delete(scope_prefix="/temp")
        assert count == 1
        assert backend.get_record("r2") is not None

    def test_delete_all_in_profile(self, backend: InMemoryBackend) -> None:
        backend.save([
            _make_record("a", "r1"),
            _make_record("b", "r2"),
        ])
        count = backend.delete()
        assert count == 2


# ---------------------------------------------------------------------------
# Tests: profile isolation
# ---------------------------------------------------------------------------

class TestProfileIsolation:
    def test_different_profiles_isolated(self) -> None:
        b1 = InMemoryBackend(profile_id="crew-alpha")
        b2 = InMemoryBackend(profile_id="crew-beta")

        # Share the same underlying store to test isolation
        shared_store: dict[str, Any] = {}
        b1._store = shared_store
        b2._store = shared_store

        b1.save([_make_record("alpha memory", "r1")])
        b2.save([_make_record("beta memory", "r2")])

        assert b1.get_record("r1") is not None
        assert b1.get_record("r2") is None
        assert b2.get_record("r2") is not None
        assert b2.get_record("r1") is None
