# crewai-superlocalmemory

[CrewAI](https://crewai.com) storage backend powered by [SuperLocalMemory V3](https://superlocalmemory.com) — local-first, privacy-compliant crew memory.

## Features

- **StorageBackend Protocol** — Drop-in replacement for CrewAI's default LanceDB storage
- **Local-first** — All crew memories stay on your device (Mode A: zero cloud)
- **EU AI Act compliant** — Data never leaves the device, no DPA required
- **Profile isolation** — Different crews get isolated memory spaces

## Installation

```bash
pip install crewai-superlocalmemory
```

## Usage

```python
from crewai import Crew, Agent, Task, Memory
from crewai_superlocalmemory import SuperLocalMemoryBackend

# Create SLM-backed storage
backend = SuperLocalMemoryBackend(profile_id="my-crew")

# Use with CrewAI Memory
crew = Crew(
    agents=[researcher, writer],
    tasks=[research_task, write_task],
    memory=Memory(storage=backend),
)

result = crew.kickoff()
```

### Profile Isolation

```python
# Each crew gets its own isolated memory space
alpha_backend = SuperLocalMemoryBackend(profile_id="crew-alpha")
beta_backend = SuperLocalMemoryBackend(profile_id="crew-beta")
```

### Modes

| Mode | Privacy | Use Case |
|------|---------|----------|
| `a` | Maximum (zero cloud) | EU AI Act compliant crews |
| `b` | High (local Ollama) | Private + LLM assist |
| `c` | Standard (cloud LLM) | Maximum accuracy |

## Links

- [SuperLocalMemory](https://superlocalmemory.com)
- [Paper: arXiv:2603.14588](https://arxiv.org/abs/2603.14588)
- [GitHub](https://github.com/qualixar/superlocalmemory)

## License

MIT

Part of [Qualixar](https://qualixar.com) | Author: [Varun Pratap Bhardwaj](https://varunpratap.com)
