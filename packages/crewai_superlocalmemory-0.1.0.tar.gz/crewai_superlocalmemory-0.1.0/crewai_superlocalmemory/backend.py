"""SuperLocalMemory V3 — CrewAI StorageBackend implementation.

Implements the CrewAI StorageBackend protocol so that crews store
all memories locally via SLM's SQLite database. Zero cloud dependency.

Usage::

    from crewai import Crew, Memory
    from crewai_superlocalmemory import SuperLocalMemoryBackend

    backend = SuperLocalMemoryBackend()
    crew = Crew(
        agents=[...],
        tasks=[...],
        memory=Memory(storage=backend),
    )

Part of Qualixar | Author: Varun Pratap Bhardwaj (qualixar.com | varunpratap.com)
Paper: https://arxiv.org/abs/2603.14588
"""

from __future__ import annotations

import json
import logging
import math
from datetime import UTC, datetime
from typing import Any

from crewai.memory.types import MemoryRecord

logger = logging.getLogger(__name__)


def _cosine_sim(a: list[float], b: list[float]) -> float:
    """Cosine similarity between two vectors. Returns 0.0 on degenerate input."""
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0.0 or norm_b == 0.0:
        return 0.0
    return dot / (norm_a * norm_b)


class SuperLocalMemoryBackend:
    """CrewAI StorageBackend backed by SuperLocalMemory V3.

    Stores MemoryRecords in SLM's SQLite database, enabling local-first
    crew memory with EU AI Act compliance (Mode A: zero cloud).

    Args:
        mode: SLM operating mode — 'a' (zero-cloud), 'b' (local LLM),
            'c' (cloud LLM). Default 'a'.
        profile_id: SLM profile for memory isolation between crews.
        db_path: Custom database path. None uses SLM default.
    """

    def __init__(
        self,
        mode: str = "a",
        profile_id: str = "crewai",
        db_path: str | None = None,
    ) -> None:
        self._mode = mode
        self._profile_id = profile_id
        self._db_path = db_path
        self._engine: Any = None

    @property
    def engine(self) -> Any:
        """Lazy-initialize the MemoryEngine."""
        if self._engine is None:
            from pathlib import Path

            from superlocalmemory.core.config import SLMConfig
            from superlocalmemory.core.engine import MemoryEngine
            from superlocalmemory.storage.models import Mode

            config = SLMConfig.for_mode(Mode(self._mode.lower()))
            config.active_profile = self._profile_id
            if self._db_path:
                config.db_path = Path(self._db_path)
            self._engine = MemoryEngine(config)
            self._engine.initialize()
        return self._engine

    @property
    def _db(self) -> Any:
        return self.engine._db

    def save(self, records: list[MemoryRecord]) -> None:
        """Persist CrewAI MemoryRecords to SLM's local database."""
        for record in records:
            metadata_json = json.dumps({
                "scope": record.scope,
                "categories": record.categories,
                "importance": record.importance,
                "source": record.source,
                "private": record.private,
                "crewai_id": record.id,
                **record.metadata,
            })
            embedding_json = (
                json.dumps(record.embedding) if record.embedding else None
            )
            self._db.execute(
                """INSERT OR REPLACE INTO crewai_records
                   (id, profile_id, content, scope, categories_json,
                    metadata_json, importance, created_at, last_accessed,
                    embedding_json, source, private)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    record.id,
                    self._profile_id,
                    record.content,
                    record.scope,
                    json.dumps(record.categories),
                    metadata_json,
                    record.importance,
                    record.created_at.isoformat(),
                    record.last_accessed.isoformat(),
                    embedding_json,
                    record.source or "",
                    1 if record.private else 0,
                ),
            )

    def search(
        self,
        query_embedding: list[float],
        scope_prefix: str | None = None,
        categories: list[str] | None = None,
        metadata_filter: dict[str, Any] | None = None,
        limit: int = 10,
        min_score: float = 0.0,
    ) -> list[tuple[MemoryRecord, float]]:
        """Search for memories by vector similarity."""
        where_clauses = ["profile_id = ?"]
        params: list[Any] = [self._profile_id]

        if scope_prefix:
            where_clauses.append("scope LIKE ?")
            params.append(f"{scope_prefix}%")

        where_sql = " AND ".join(where_clauses)
        rows = self._db.execute(
            f"SELECT * FROM crewai_records WHERE {where_sql}",
            tuple(params),
        )

        scored: list[tuple[MemoryRecord, float]] = []
        for row in rows:
            record = self._row_to_record(row)
            if categories and not any(
                c in record.categories for c in categories
            ):
                continue
            if metadata_filter:
                skip = False
                for k, v in metadata_filter.items():
                    if record.metadata.get(k) != v:
                        skip = True
                        break
                if skip:
                    continue

            score = 0.0
            if record.embedding and query_embedding:
                score = _cosine_sim(query_embedding, record.embedding)
            if score >= min_score:
                scored.append((record, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return scored[:limit]

    def delete(
        self,
        scope_prefix: str | None = None,
        categories: list[str] | None = None,
        record_ids: list[str] | None = None,
        older_than: datetime | None = None,
        metadata_filter: dict[str, Any] | None = None,
    ) -> int:
        """Delete memories matching criteria. Returns count deleted."""
        if record_ids:
            count = 0
            for rid in record_ids:
                result = self._db.execute(
                    "DELETE FROM crewai_records WHERE id = ? AND profile_id = ?",
                    (rid, self._profile_id),
                )
                count += 1
            return count

        where_clauses = ["profile_id = ?"]
        params: list[Any] = [self._profile_id]

        if scope_prefix:
            where_clauses.append("scope LIKE ?")
            params.append(f"{scope_prefix}%")
        if older_than:
            where_clauses.append("created_at < ?")
            params.append(older_than.isoformat())

        where_sql = " AND ".join(where_clauses)

        rows_before = self._db.execute(
            f"SELECT COUNT(*) as c FROM crewai_records WHERE {where_sql}",
            tuple(params),
        )
        count_before = rows_before[0]["c"] if rows_before else 0

        self._db.execute(
            f"DELETE FROM crewai_records WHERE {where_sql}",
            tuple(params),
        )
        return count_before

    def update(self, record: MemoryRecord) -> None:
        """Update an existing record by re-saving it."""
        self.save([record])

    def get_record(self, record_id: str) -> MemoryRecord | None:
        """Return a single record by ID."""
        rows = self._db.execute(
            "SELECT * FROM crewai_records WHERE id = ? AND profile_id = ?",
            (record_id, self._profile_id),
        )
        if not rows:
            return None
        return self._row_to_record(rows[0])

    def ensure_table(self) -> None:
        """Create the crewai_records table if it doesn't exist."""
        self._db.execute(
            """CREATE TABLE IF NOT EXISTS crewai_records (
                id TEXT PRIMARY KEY,
                profile_id TEXT NOT NULL,
                content TEXT NOT NULL,
                scope TEXT DEFAULT '/',
                categories_json TEXT DEFAULT '[]',
                metadata_json TEXT DEFAULT '{}',
                importance REAL DEFAULT 0.5,
                created_at TEXT NOT NULL,
                last_accessed TEXT NOT NULL,
                embedding_json TEXT,
                source TEXT DEFAULT '',
                private INTEGER DEFAULT 0
            )"""
        )
        self._db.execute(
            "CREATE INDEX IF NOT EXISTS idx_crewai_profile "
            "ON crewai_records(profile_id)"
        )
        self._db.execute(
            "CREATE INDEX IF NOT EXISTS idx_crewai_scope "
            "ON crewai_records(profile_id, scope)"
        )

    @staticmethod
    def _row_to_record(row: dict[str, Any]) -> MemoryRecord:
        """Convert a database row to a CrewAI MemoryRecord."""
        categories = json.loads(row.get("categories_json", "[]"))
        metadata_raw = json.loads(row.get("metadata_json", "{}"))
        embedding_raw = row.get("embedding_json")
        embedding = json.loads(embedding_raw) if embedding_raw else None

        # Extract SLM-specific keys from metadata, pass rest through
        slm_keys = {"scope", "categories", "importance", "source",
                     "private", "crewai_id"}
        metadata = {k: v for k, v in metadata_raw.items() if k not in slm_keys}

        return MemoryRecord(
            id=row["id"],
            content=row["content"],
            scope=row.get("scope", "/"),
            categories=categories,
            metadata=metadata,
            importance=row.get("importance", 0.5),
            created_at=datetime.fromisoformat(row["created_at"]),
            last_accessed=datetime.fromisoformat(row["last_accessed"]),
            embedding=embedding,
            source=row.get("source") or None,
            private=bool(row.get("private", 0)),
        )
