"""CrewAI storage backend powered by SuperLocalMemory V3.

Provides a StorageBackend implementation that keeps all crew memory
on-device with zero cloud dependency.

Part of Qualixar | Author: Varun Pratap Bhardwaj (qualixar.com | varunpratap.com)
Paper: https://arxiv.org/abs/2603.14588
"""

from crewai_superlocalmemory.backend import SuperLocalMemoryBackend

__all__ = ["SuperLocalMemoryBackend"]
__version__ = "0.1.0"
