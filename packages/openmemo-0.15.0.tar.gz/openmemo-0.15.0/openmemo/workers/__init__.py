from openmemo.workers.compression_worker import CompressionWorker

__all__ = ["CompressionWorker"]
