# main.py
import json
import sys
import time
from typing import Dict, Any

def list_tools() -> list:
    return [
        {
            "name": "get_current_time",
            "description": "获取当前服务器时间（UTC）",
            "input_schema": {"type": "object", "properties": {}, "required": []}
        }
    ]

def call_tool(name: str, arguments: Dict[str, Any]) -> Dict:
    if name == "get_current_time":
        return {"result": time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())}
    return {"error": "Unknown tool"}

def main():
    for line in sys.stdin:
        try:
            req = json.loads(line.strip())
            
            # 支持两种格式：标准 JSON-RPC 和旧版 type（兼容性更好）
            method = req.get("method")
            req_type = req.get("type")  # 兼容旧版
            
            response = {}
            
            if method == "tools/list" or req_type == "list_tools":
                response = {"jsonrpc": "2.0", "id": req.get("id", 0), "result": {"tools": list_tools()}}
            
            elif method == "tools/call" or req_type == "call_tool":
                tool_name = req.get("params", {}).get("name") if method else req.get("name")
                args = req.get("params", {}).get("arguments", {}) if method else req.get("arguments", {})
                result = call_tool(tool_name, args)
                response = {"jsonrpc": "2.0", "id": req.get("id", 0), "result": result}
            
            else:
                response = {"jsonrpc": "2.0", "id": req.get("id", 0), "error": {"code": -32601, "message": "Method not found"}}
            
            print(json.dumps(response))
            sys.stdout.flush()
        
        except json.JSONDecodeError:
            print(json.dumps({"error": "Invalid JSON"}))
            sys.stdout.flush()
        except Exception as e:
            print(json.dumps({"error": str(e)}))
            sys.stdout.flush()

if __name__ == "__main__":
    main()   # 保持兼容直接 python main.py