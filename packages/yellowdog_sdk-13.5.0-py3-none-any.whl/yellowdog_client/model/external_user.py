from dataclasses import dataclass, field
from typing import List, Optional

from .access_delegate import AccessDelegate
from .authentication_provider import AuthenticationProvider
from .user import User


@dataclass
class ExternalUser(User):
    """Represents an external user within the YellowDog Platform."""
    type: str = field(default="co.yellowdog.platform.model.ExternalUser", init=False)
    externalId: str = field(init=False)
    authenticationProvider: AuthenticationProvider = field(init=False)
    id: Optional[str] = field(default=None, init=False)
    name: str
    email: Optional[str] = None
    eulaAccepted: bool = False
    accessDelegates: Optional[List[AccessDelegate]] = None
    passwordSet: bool = False
