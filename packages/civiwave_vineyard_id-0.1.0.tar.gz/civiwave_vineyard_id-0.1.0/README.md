# civiwave-vineyard-id (Python)

DID authentication SDK for Civiwave applications — challenge-response, signature verification, JWT sessions.

Equivalent to [`@civiwave/vineyard-id`](https://www.npmjs.com/package/@civiwave/vineyard-id) (npm).

## Install

```bash
pip install civiwave-vineyard-id
```

## Usage

```python
from civiwave_vineyard_id import (
    generate_challenge,
    verify_did_signature,
    issue_token,
    validate_token,
    DIDAuthRequest,
)

# Server: generate challenge for DID
challenge = generate_challenge("did:civiwave:5Grw...")

# Client signs challenge.message with their Ed25519 key, sends back:
request = DIDAuthRequest(
    did=challenge.did,
    nonce=challenge.nonce,
    signature="0xabc...",
    timestamp=challenge.timestamp,
    origin="https://app.civiwave.io",
)

# Server: verify signature
result = verify_did_signature(request, public_key_hex="0x...")
assert result.valid

# Server: issue JWT
token = issue_token(
    did="did:civiwave:5Grw...",
    ss58="5Grw...",
    tier="standard",
    secret="your-jwt-secret",
)

# Server/Edge: validate JWT
session = validate_token(token, secret="your-jwt-secret")
print(session.did, session.tier)
```

## API

See the full API reference in [SDK docs](https://github.com/civiwave/civiwave/blob/main/docs/user-guide/developer/sdk.md).

## Development

```bash
pip install -e ".[dev]"
pytest
ruff check .
mypy civiwave_vineyard_id/
```

## License

MIT
