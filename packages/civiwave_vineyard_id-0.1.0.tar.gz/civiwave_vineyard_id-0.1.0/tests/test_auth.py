"""Tests for the DID auth module — challenge, verify, session."""

import time
import pytest
from civiwave_vineyard_id.challenge import (
    generate_challenge,
    construct_message,
    extract_network_id,
)
from civiwave_vineyard_id.verify import (
    DIDAuthRequest,
    verify_did_signature_sync,
)
from civiwave_vineyard_id.session import (
    issue_token,
    validate_token,
    validate_token_lite,
)
from civiwave_vineyard_id._test_helpers import generate_keypair, sign


class TestChallenge:
    def test_generate_challenge_fields(self):
        c = generate_challenge("did:vineyard:civiwave:5Abc123")
        assert len(c.nonce) == 64  # 32 bytes hex
        assert c.expires_at > time.time()
        assert c.did == "did:vineyard:civiwave:5Abc123"

    def test_generate_challenge_custom_ttl(self):
        c = generate_challenge("did:vineyard:civiwave:5Abc", ttl_seconds=60)
        assert c.expires_at <= time.time() + 61

    def test_unique_nonces(self):
        c1 = generate_challenge("did:vineyard:civiwave:5Abc")
        c2 = generate_challenge("did:vineyard:civiwave:5Abc")
        assert c1.nonce != c2.nonce

    def test_extract_network_id(self):
        assert extract_network_id("did:vineyard:civiwave:5Abc") == "civiwave"
        assert extract_network_id("did:vineyard:0:5Abc") == "0"

    def test_extract_network_id_invalid(self):
        with pytest.raises(ValueError):
            extract_network_id("invalid:did")
        with pytest.raises(ValueError):
            extract_network_id("did:wrong:x:y")

    def test_construct_message_is_json(self):
        msg = construct_message("nonce123", 1234567890.0, "https://app.civiwave.io", "civiwave")
        import json
        parsed = json.loads(msg)
        assert parsed["domain"] == "civiwave:did:auth-challenge"
        assert parsed["nonce"] == "nonce123"
        assert parsed["network"] == "civiwave"

    def test_construct_message_deterministic(self):
        m1 = construct_message("n", 1.0, "o", "0")
        m2 = construct_message("n", 1.0, "o", "0")
        assert m1 == m2


class TestVerify:
    def test_valid_signature(self):
        kp = generate_keypair()
        did = f"did:vineyard:0:{kp.ss58_address}"
        nonce = "abc123"
        timestamp = time.time()
        origin = "https://test.civiwave.io"

        message = construct_message(nonce, timestamp, origin, "0")
        signature = sign(message.encode("utf-8"), kp.secret_key)

        request = DIDAuthRequest(
            did=did,
            nonce=nonce,
            signature=signature.hex(),
            timestamp=timestamp,
            origin=origin,
        )
        result = verify_did_signature_sync(request, kp.public_key.hex())
        assert result.valid is True
        assert result.key_type == "Ed25519VerificationKey2020"

    def test_invalid_signature(self):
        kp = generate_keypair()
        request = DIDAuthRequest(
            did=f"did:vineyard:0:{kp.ss58_address}",
            nonce="abc",
            signature="00" * 64,
            timestamp=time.time(),
            origin="https://test.civiwave.io",
        )
        result = verify_did_signature_sync(request, kp.public_key.hex())
        assert result.valid is False

    def test_wrong_public_key(self):
        kp1 = generate_keypair()
        kp2 = generate_keypair()
        did = f"did:vineyard:0:{kp1.ss58_address}"
        nonce = "test"
        timestamp = time.time()
        origin = "https://app.civiwave.io"

        message = construct_message(nonce, timestamp, origin, "0")
        signature = sign(message.encode("utf-8"), kp1.secret_key)

        request = DIDAuthRequest(
            did=did,
            nonce=nonce,
            signature=signature.hex(),
            timestamp=timestamp,
            origin=origin,
        )
        result = verify_did_signature_sync(request, kp2.public_key.hex())
        assert result.valid is False


class TestSession:
    SECRET = "test-secret-key-for-jwt"

    def test_issue_and_validate(self):
        token = issue_token("did:vineyard:0:5Abc", "5Abc", "member", self.SECRET)
        session = validate_token(token, self.SECRET)
        assert session is not None
        assert session.did == "did:vineyard:0:5Abc"
        assert session.ss58 == "5Abc"
        assert session.tier == "member"
        assert session.iat > 0
        assert session.exp > session.iat

    def test_validate_with_wrong_secret(self):
        token = issue_token("did:vineyard:0:5Abc", "5Abc", "member", self.SECRET)
        session = validate_token(token, "wrong-secret")
        assert session is None

    def test_validate_expired_token(self):
        token = issue_token("did:vineyard:0:5Abc", "5Abc", "member", self.SECRET, expires_in_seconds=-1)
        session = validate_token(token, self.SECRET)
        assert session is None

    def test_validate_token_lite(self):
        token = issue_token("did:vineyard:0:5Abc", "5Abc", "validator", self.SECRET)
        session = validate_token_lite(token)
        assert session is not None
        assert session.did == "did:vineyard:0:5Abc"
        assert session.tier == "validator"

    def test_validate_token_lite_expired(self):
        token = issue_token("did:vineyard:0:5Abc", "5Abc", "member", self.SECRET, expires_in_seconds=-1)
        session = validate_token_lite(token)
        assert session is None

    def test_validate_token_lite_garbage(self):
        assert validate_token_lite("not.a.jwt") is None
        assert validate_token_lite("") is None
        assert validate_token_lite("abc") is None

    def test_custom_expiry(self):
        token = issue_token("did:vineyard:0:5Abc", "5Abc", "member", self.SECRET, expires_in_seconds=3600)
        session = validate_token(token, self.SECRET)
        assert session is not None
        assert session.exp - session.iat == 3600
