# Changelog

All notable changes to `civiwave-vineyard-id` (Python) will be documented in this file.

Follows [Semantic Versioning](https://semver.org/). Pre-1.0 releases use `0.MINOR.PATCH`.

---

## [0.1.0] — 2026-03-16

### Added
- `generate_challenge(did)` — create a DID authentication challenge with nonce and expiry
- `construct_message(did, nonce, timestamp, origin)` — build the canonical signing message
- `extract_network_id(did)` — parse network ID from `did:civiwave:` URIs
- `verify_did_signature(request, public_key_hex)` — verify Ed25519 signature against DID challenge
- `verify_did_signature_sync(request, public_key_hex)` — synchronous variant
- `issue_token(did, ss58, tier, secret)` — issue a JWT session token
- `validate_token(token, secret)` — full JWT validation with claims extraction
- `validate_token_lite(token)` — structure + expiry check without secret (for edge nodes)
- Type dataclasses: `DIDChallenge`, `DIDAuthRequest`, `DIDVerifyResult`, `DIDSession`
