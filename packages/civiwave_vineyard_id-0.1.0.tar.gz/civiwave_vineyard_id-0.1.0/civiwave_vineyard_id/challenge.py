"""Challenge generation and message construction for DID auth."""

from __future__ import annotations

import json
import secrets
import time
from dataclasses import dataclass

DEFAULT_TTL_SECONDS = 300


@dataclass
class DIDChallenge:
    """A challenge issued to a DID holder for authentication."""

    nonce: str
    expires_at: float
    did: str


def generate_challenge(did: str, ttl_seconds: int = DEFAULT_TTL_SECONDS) -> DIDChallenge:
    """Generate a cryptographic challenge for DID authentication.

    Args:
        did: The DID requesting authentication
        ttl_seconds: Challenge time-to-live in seconds (default: 300)

    Returns:
        A DIDChallenge with a random nonce and expiration timestamp
    """
    nonce = secrets.token_hex(32)
    expires_at = time.time() + ttl_seconds
    return DIDChallenge(nonce=nonce, expires_at=expires_at, did=did)


def extract_network_id(did: str) -> str:
    """Extract the network ID from a did:vineyard DID.

    Format: did:vineyard:<networkId>:<ss58Address>

    Returns:
        The network ID string (e.g., "civiwave" for mainnet)

    Raises:
        ValueError: If the DID format is invalid
    """
    parts = did.split(":")
    if len(parts) < 4 or parts[0] != "did" or parts[1] != "vineyard":
        raise ValueError(f"Invalid did:vineyard format: {did}")
    return parts[2]


def construct_message(
    nonce: str,
    timestamp: float,
    origin: str,
    network: str = "0",
) -> str:
    """Construct the canonical message to be signed by the wallet.

    Domain-separated JSON string that prevents signature replay
    across different protocols and chains.
    """
    return json.dumps(
        {
            "domain": "civiwave:did:auth-challenge",
            "network": network,
            "nonce": nonce,
            "timestamp": timestamp,
            "origin": origin,
        },
        separators=(",", ":"),
        sort_keys=False,
    )
