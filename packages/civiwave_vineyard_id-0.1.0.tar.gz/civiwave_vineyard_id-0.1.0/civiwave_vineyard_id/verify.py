"""DID signature verification."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Optional

from nacl.exceptions import BadSignatureError
from nacl.signing import VerifyKey

from civiwave_vineyard_id.challenge import construct_message, extract_network_id


@dataclass
class DIDAuthRequest:
    """A signed authentication request from the client."""

    did: str
    nonce: str
    signature: str  # hex-encoded
    timestamp: float
    origin: str


@dataclass
class DIDVerifyResult:
    """Result of DID signature verification."""

    valid: bool
    public_key: Optional[str] = None
    key_type: Optional[str] = None


async def verify_did_signature(
    request: DIDAuthRequest,
    public_key_hex: str,
) -> DIDVerifyResult:
    """Verify a DID authentication signature against a known public key.

    Unlike the TypeScript vineyard-id which resolves the DID via an HTTP resolver,
    this function takes the public key directly. Use with a resolver separately
    if you need DID document lookup.

    Args:
        request: The signed auth request
        public_key_hex: Ed25519 public key (hex, 32 bytes)

    Returns:
        Verification result with validity flag
    """
    try:
        network = extract_network_id(request.did)
        message = construct_message(
            request.nonce, request.timestamp, request.origin, network
        )
        message_bytes = message.encode("utf-8")

        sig_bytes = bytes.fromhex(
            request.signature[2:] if request.signature.startswith("0x") else request.signature
        )
        pk_bytes = bytes.fromhex(
            public_key_hex[2:] if public_key_hex.startswith("0x") else public_key_hex
        )

        verify_key = VerifyKey(pk_bytes)
        verify_key.verify(message_bytes, sig_bytes)

        return DIDVerifyResult(
            valid=True,
            public_key=public_key_hex,
            key_type="Ed25519VerificationKey2020",
        )
    except (BadSignatureError, ValueError, Exception):
        return DIDVerifyResult(valid=False)


def verify_did_signature_sync(
    request: DIDAuthRequest,
    public_key_hex: str,
) -> DIDVerifyResult:
    """Synchronous version of verify_did_signature."""
    try:
        network = extract_network_id(request.did)
        message = construct_message(
            request.nonce, request.timestamp, request.origin, network
        )
        message_bytes = message.encode("utf-8")

        sig_bytes = bytes.fromhex(
            request.signature[2:] if request.signature.startswith("0x") else request.signature
        )
        pk_bytes = bytes.fromhex(
            public_key_hex[2:] if public_key_hex.startswith("0x") else public_key_hex
        )

        verify_key = VerifyKey(pk_bytes)
        verify_key.verify(message_bytes, sig_bytes)

        return DIDVerifyResult(
            valid=True,
            public_key=public_key_hex,
            key_type="Ed25519VerificationKey2020",
        )
    except (BadSignatureError, ValueError, Exception):
        return DIDVerifyResult(valid=False)
