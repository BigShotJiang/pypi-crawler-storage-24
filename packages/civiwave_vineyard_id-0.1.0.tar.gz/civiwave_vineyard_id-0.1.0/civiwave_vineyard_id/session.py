"""JWT session management for DID authentication."""

from __future__ import annotations

import base64
import json
import time
from dataclasses import dataclass
from typing import Optional

import jwt

DEFAULT_EXPIRES_IN_SECONDS = 7 * 24 * 3600  # 7 days


@dataclass
class DIDSession:
    """A validated DID session."""

    did: str
    ss58: str
    tier: str
    iat: int
    exp: int


def issue_token(
    did: str,
    ss58: str,
    tier: str,
    secret: str,
    expires_in_seconds: int = DEFAULT_EXPIRES_IN_SECONDS,
) -> str:
    """Issue a JWT token for an authenticated DID session.

    Args:
        did: The authenticated DID
        ss58: The SS58 address extracted from the DID
        tier: The user's tier/role (e.g., "member", "validator")
        secret: JWT signing secret
        expires_in_seconds: JWT lifetime in seconds (default: 7 days)

    Returns:
        Signed JWT string
    """
    now = int(time.time())
    payload = {
        "sub": did,
        "ss58": ss58,
        "tier": tier,
        "iat": now,
        "exp": now + expires_in_seconds,
    }
    return jwt.encode(payload, secret, algorithm="HS256")


def validate_token(token: str, secret: str) -> Optional[DIDSession]:
    """Validate a DID JWT token and extract the session payload.

    Args:
        token: The JWT string to validate
        secret: JWT signing secret (must match issuing secret)

    Returns:
        DIDSession if valid, or None if invalid/expired
    """
    try:
        payload = jwt.decode(token, secret, algorithms=["HS256"])
        sub = payload.get("sub")
        ss58 = payload.get("ss58")
        if not sub or not ss58:
            return None
        return DIDSession(
            did=sub,
            ss58=ss58,
            tier=payload.get("tier", "member"),
            iat=payload.get("iat", 0),
            exp=payload.get("exp", 0),
        )
    except jwt.PyJWTError:
        return None


def validate_token_lite(token: str) -> Optional[DIDSession]:
    """Lightweight JWT validation without the signing secret.

    WARNING: Only validates structure and expiration, NOT the signature.
    Use validate_token() for full server-side validation.

    Args:
        token: The JWT string

    Returns:
        DIDSession if structurally valid and not expired, else None
    """
    try:
        parts = token.split(".")
        if len(parts) != 3:
            return None

        padding = 4 - len(parts[1]) % 4
        padded = parts[1] + "=" * padding
        payload = json.loads(base64.urlsafe_b64decode(padded))

        sub = payload.get("sub")
        ss58 = payload.get("ss58")
        if not sub or not ss58:
            return None

        exp = payload.get("exp", 0)
        if exp and exp < time.time():
            return None

        return DIDSession(
            did=sub,
            ss58=ss58,
            tier=payload.get("tier", "member"),
            iat=payload.get("iat", 0),
            exp=exp,
        )
    except Exception:
        return None
