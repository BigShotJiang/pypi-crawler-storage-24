"""
civiwave-vineyard-id — DID authentication SDK for Civiwave applications.

Equivalent to @civiwave/vineyard-id (npm).
"""

from civiwave_vineyard_id.challenge import (
    generate_challenge,
    construct_message,
    extract_network_id,
    DIDChallenge,
)
from civiwave_vineyard_id.verify import (
    verify_did_signature,
    verify_did_signature_sync,
    DIDAuthRequest,
    DIDVerifyResult,
)
from civiwave_vineyard_id.session import (
    issue_token,
    validate_token,
    validate_token_lite,
    DIDSession,
)

__version__ = "0.1.0"

__all__ = [
    "generate_challenge",
    "construct_message",
    "extract_network_id",
    "verify_did_signature",
    "verify_did_signature_sync",
    "issue_token",
    "validate_token",
    "validate_token_lite",
    "DIDChallenge",
    "DIDAuthRequest",
    "DIDVerifyResult",
    "DIDSession",
]
