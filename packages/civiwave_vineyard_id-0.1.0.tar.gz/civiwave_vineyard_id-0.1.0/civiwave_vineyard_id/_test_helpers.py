"""Minimal keypair helpers for testing. Not part of the public API."""

from dataclasses import dataclass

from nacl.signing import SigningKey


@dataclass
class CiviwaveKeypair:
    public_key: bytes
    secret_key: bytes
    ss58_address: str


def generate_keypair() -> CiviwaveKeypair:
    signing_key = SigningKey.generate()
    public_key = bytes(signing_key.verify_key)
    secret_key = bytes(signing_key)[:32]
    return CiviwaveKeypair(
        public_key=public_key,
        secret_key=secret_key,
        ss58_address=f"5Test{public_key[:4].hex()}",
    )


def sign(message: bytes, secret_key: bytes) -> bytes:
    signing_key = SigningKey(secret_key)
    signed = signing_key.sign(message)
    return signed.signature
