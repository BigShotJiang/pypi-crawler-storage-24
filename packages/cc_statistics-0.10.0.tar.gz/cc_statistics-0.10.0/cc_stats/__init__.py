"""cc-statistics: Claude Code 会话统计工具"""

__version__ = "0.2.0"
