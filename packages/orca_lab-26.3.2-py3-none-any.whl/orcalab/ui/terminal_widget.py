from PySide6 import QtCore, QtWidgets, QtGui
import subprocess
import threading
import queue
import os
import sys
import re


class TerminalTextEdit(QtWidgets.QTextEdit):
    """支持输入捕获和ANSI颜色的终端文本编辑器"""
    
    input_submitted = QtCore.Signal(str)
    
    # ANSI颜色映射表
    ANSI_COLORS = {
        '30': '#000000',  # Black
        '31': '#cd3131',  # Red
        '32': '#0dbc79',  # Green
        '33': '#e5e510',  # Yellow
        '34': '#2472c8',  # Blue
        '35': '#bc3fbc',  # Magenta
        '36': '#11a8cd',  # Cyan
        '37': '#e5e5e5',  # White
        '90': '#666666',  # Bright Black (Gray)
        '91': '#f14c4c',  # Bright Red
        '92': '#23d18b',  # Bright Green
        '93': '#f5f543',  # Bright Yellow
        '94': '#3b8eea',  # Bright Blue
        '95': '#d670d6',  # Bright Magenta
        '96': '#29b8db',  # Bright Cyan
        '97': '#ffffff',  # Bright White
    }
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._input_buffer = ""
        self._pty_mode = False
        # 禁用默认的undo/redo
        self.setUndoRedoEnabled(False)
        
        # 当前文本格式
        self._current_format = QtGui.QTextCharFormat()
        self._reset_format()
    def _reset_format(self):
        """重置文本格式为默认"""
        self._current_format = QtGui.QTextCharFormat()
        self._current_format.setForeground(QtGui.QColor("#e6edf3"))
        
    def _parse_ansi_codes(self, code_str):
        """解析ANSI转义码并更新当前格式"""
        if not code_str:
            return
            
        codes = code_str.split(';')
        for code in codes:
            if not code:
                continue
                
            if code == '0':  # Reset
                self._reset_format()
            elif code == '1':  # Bold
                self._current_format.setFontWeight(QtGui.QFont.Weight.Bold)
            elif code == '22':  # Normal intensity
                self._current_format.setFontWeight(QtGui.QFont.Weight.Normal)
            elif code == '4':  # Underline
                self._current_format.setFontUnderline(True)
            elif code == '24':  # No underline
                self._current_format.setFontUnderline(False)
            elif code in self.ANSI_COLORS:  # 前景色
                self._current_format.setForeground(QtGui.QColor(self.ANSI_COLORS[code]))
            elif code.startswith('3') and len(code) == 2:  # 其他前景色
                pass  # 已在ANSI_COLORS中处理
            elif code.startswith('9') and len(code) == 2:  # 高亮前景色
                pass  # 已在ANSI_COLORS中处理
    
    def append_ansi_text(self, text):
        """追加带ANSI转义码的文本"""
        # ANSI转义码正则表达式
        ansi_pattern = re.compile(r'\x1b\[([0-9;]*)m')
        
        cursor = self.textCursor()
        cursor.movePosition(QtGui.QTextCursor.MoveOperation.End)
        
        last_pos = 0
        for match in ansi_pattern.finditer(text):
            # 插入转义码之前的文本
            if match.start() > last_pos:
                plain_text = text[last_pos:match.start()]
                cursor.insertText(plain_text, self._current_format)
            
            # 解析并应用ANSI代码
            codes = match.group(1)
            self._parse_ansi_codes(codes)
            
            last_pos = match.end()
        
        # 插入剩余文本
        if last_pos < len(text):
            plain_text = text[last_pos:]
            cursor.insertText(plain_text, self._current_format)
        
        self.setTextCursor(cursor)
        
        # 自动滚动到底部
        scrollbar = self.verticalScrollBar()
        scrollbar.setValue(scrollbar.maximum())
        
    def keyPressEvent(self, event):
        key = event.key()
        modifiers = event.modifiers()
        
        # 屏蔽 Ctrl+Z (undo) 和 Ctrl+Y/Ctrl+Shift+Z (redo)
        if modifiers & QtCore.Qt.KeyboardModifier.ControlModifier:
            if key in (QtCore.Qt.Key.Key_Z, QtCore.Qt.Key.Key_Y):
                return
        
        # Ctrl+C：发送中断信号
        if key == QtCore.Qt.Key.Key_C and modifiers & QtCore.Qt.KeyboardModifier.ControlModifier:
            self.input_submitted.emit("\x03")
            return
        
        # Ctrl+D：发送EOF
        if key == QtCore.Qt.Key.Key_D and modifiers & QtCore.Qt.KeyboardModifier.ControlModifier:
            self.input_submitted.emit("\x04")
            return

        # PTY 模式（Linux PTY / Windows ConPTY）：每个按键立即发送，不缓冲
        if self._pty_mode:
            text = event.text()
            if key in (QtCore.Qt.Key.Key_Return, QtCore.Qt.Key.Key_Enter):
                self.input_submitted.emit("\r")
            elif key == QtCore.Qt.Key.Key_Backspace:
                self.input_submitted.emit("\x7f")
            elif text:
                self.input_submitted.emit(text)
            else:
                super().keyPressEvent(event)
            return
        
        # 普通 PIPE 模式：缓冲到回车再发送
        # Enter键：发送当前输入缓冲区
        if key in (QtCore.Qt.Key.Key_Return, QtCore.Qt.Key.Key_Enter):
            text_to_send = self._input_buffer + "\n"
            self._input_buffer = ""
            cursor = self.textCursor()
            cursor.movePosition(QtGui.QTextCursor.MoveOperation.End)
            cursor.insertText("\n")
            self.setTextCursor(cursor)
            self.input_submitted.emit(text_to_send)
            return
        
        # 退格键：删除输入缓冲区最后一个字符
        if key == QtCore.Qt.Key.Key_Backspace:
            if self._input_buffer:
                self._input_buffer = self._input_buffer[:-1]
                cursor = self.textCursor()
                cursor.deletePreviousChar()
                self.setTextCursor(cursor)
            return
        
        # 普通字符输入
        text = event.text()
        if text and text.isprintable():
            self._input_buffer += text
            cursor = self.textCursor()
            cursor.movePosition(QtGui.QTextCursor.MoveOperation.End)
            cursor.insertText(text)
            self.setTextCursor(cursor)
            scrollbar = self.verticalScrollBar()
            scrollbar.setValue(scrollbar.maximum())
            return
        
        super().keyPressEvent(event)
    
    def clear_input_buffer(self):
        """清空输入缓冲区"""
        self._input_buffer = ""


class TerminalWidget(QtWidgets.QWidget):
    """终端输出显示组件，支持输入"""
    
    # 进程被中断信号（Ctrl+C）
    process_interrupted = QtCore.Signal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.process = None
        self._pty_master_fd = None
        self._win_pty = None
        self.output_queue = queue.Queue()
        self.output_thread = None
        self.is_running = False
        
        self._setup_ui()
        
        # 创建定时器来更新UI
        self.update_timer = QtCore.QTimer()
        self.update_timer.timeout.connect(self._update_output)
        self.update_timer.start(50)  # 每50ms更新一次
        
        # 设置样式
        self.setStyleSheet("""
            QWidget {
                background-color: #1e1e1e;
                color: #ffffff;
            }
            QTextEdit {
                background-color: #0d1117;
                border: 1px solid #30363d;
                border-radius: 4px;
                color: #e6edf3;
                font-family: 'Consolas', 'Monaco', 'Courier New', monospace;
                font-size: 12px;
                padding: 8px;
                selection-background-color: #264f78;
            }
            QTextEdit:focus {
                border-color: #58a6ff;
            }
            QPushButton {
                background-color: #21262d;
                border: 1px solid #30363d;
                border-radius: 4px;
                color: #f0f6fc;
                padding: 6px 12px;
                font-size: 12px;
            }
            QPushButton:hover {
                background-color: #30363d;
                border-color: #8b949e;
            }
            QPushButton:pressed {
                background-color: #161b22;
            }
            QPushButton:disabled {
                background-color: #161b22;
                color: #7d8590;
                border-color: #21262d;
            }
        """)
    
    def _setup_ui(self):
        """设置UI布局"""
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        
        # 工具栏
        toolbar_layout = QtWidgets.QHBoxLayout()
        
        self.clear_button = QtWidgets.QPushButton("清空")
        self.clear_button.clicked.connect(self.clear_output)
        toolbar_layout.addWidget(self.clear_button)
        
        self.copy_button = QtWidgets.QPushButton("复制")
        self.copy_button.clicked.connect(self.copy_output)
        toolbar_layout.addWidget(self.copy_button)
        
        toolbar_layout.addStretch()
        
        # 状态标签
        self.status_label = QtWidgets.QLabel("就绪")
        self.status_label.setStyleSheet("color: #7d8590; font-size: 11px;")
        toolbar_layout.addWidget(self.status_label)
        
        layout.addLayout(toolbar_layout)
        
        # 输出区域（支持输入）
        self.output_text = TerminalTextEdit()
        self.output_text.setLineWrapMode(QtWidgets.QTextEdit.LineWrapMode.WidgetWidth)
        self.output_text.setVerticalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.output_text.setHorizontalScrollBarPolicy(QtCore.Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        self.output_text.input_submitted.connect(self._send_input)
        
        # 设置滚动条样式
        self.output_text.verticalScrollBar().setStyleSheet("""
            QScrollBar:vertical {
                background-color: #161b22;
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background-color: #30363d;
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #484f58;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                border: none;
                background: none;
            }
        """)
        
        layout.addWidget(self.output_text)
    
    def start_process(self, command, args, working_dir=None):
        """启动外部进程"""
        if self.is_running:
            self.stop_process()
        
        try:
            # 构建完整的命令
            cmd = [command] + args
            
            # 启动进程（包含stdin以支持输入）
            extra = {"creationflags": subprocess.CREATE_NEW_PROCESS_GROUP} if sys.platform == "win32" else {}
            self.process = subprocess.Popen(
                cmd,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
                cwd=working_dir,
                env=os.environ.copy(),
                **extra
            )
            
            self.is_running = True
            self.status_label.setText(f"运行中 (PID: {self.process.pid})")
            self.status_label.setStyleSheet("color: #3fb950; font-size: 11px;")
            
            # 启动输出读取线程
            self.output_thread = threading.Thread(
                target=self._read_output,
                daemon=True
            )
            self.output_thread.start()
            
            # 添加启动信息
            self._append_output(f"启动进程: {' '.join(cmd)}\n")
            self._append_output(f"工作目录: {working_dir or os.getcwd()}\n")
            self._append_output("-" * 50 + "\n")
            
            return True
            
        except Exception as e:
            self._append_output(f"启动进程失败: {str(e)}\n")
            self.status_label.setText("启动失败")
            self.status_label.setStyleSheet("color: #f85149; font-size: 11px;")
            return False
    
    def stop_process(self):
        """停止外部进程"""
        if not self.is_running or not self.process:
            return
        
        try:
            self._append_output("\n" + "-" * 50 + "\n")
            self._append_output("正在停止进程...\n")
            
            # 尝试优雅终止
            self.process.terminate()
            
            # 等待进程结束
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                # 强制终止
                self.process.kill()
                self.process.wait()
                self._append_output("进程已强制终止\n")
            else:
                self._append_output("进程已正常终止\n")
            
            self.is_running = False
            self.process = None
            self.status_label.setText("已停止")
            self.status_label.setStyleSheet("color: #7d8590; font-size: 11px;")
            
        except Exception as e:
            self._append_output(f"停止进程时出错: {str(e)}\n")
    
    def _send_input(self, text):
        """向进程发送输入"""
        if not self.is_running or not self.process:
            return
        
        try:
            # 处理Ctrl+C中断信号
            if text == "\x03":
                import signal
                if sys.platform == "win32":
                    if self._win_pty is not None:
                        self._win_pty.sendintr()
                    else:
                        os.kill(self.process.pid, signal.CTRL_C_EVENT)
                else:
                    self.process.send_signal(signal.SIGINT)
                self._append_output_safe("^C\n")
                self.process_interrupted.emit()
                return

            # Windows ConPTY 模式：直接写入 PtyProcess
            if self._win_pty is not None:
                self._win_pty.write(text)
                return
            
            # Linux PTY 主端
            if self._pty_master_fd is not None:
                os.write(self._pty_master_fd, text.encode('utf-8'))
                return

            # 普通 PIPE
            if self.process.stdin:
                data = text.encode('utf-8') if isinstance(text, str) else text
                self.process.stdin.write(data)
                self.process.stdin.flush()
        except (BrokenPipeError, OSError):
            self._append_output_safe("\n[输入失败: 进程已关闭]\n")
    
    def _read_output(self):
        """在后台线程中读取进程输出"""
        if not self.process:
            return
        
        try:
            stdout = self.process.stdout
            while True:
                chunk = stdout.read(4096)
                if not chunk:
                    break
                self.output_queue.put(chunk.decode("utf-8", errors="replace"))
            
            return_code = self.process.wait()
            self.output_queue.put(f"\n进程退出，返回码: {return_code}\n")
                
        except Exception as e:
            self.output_queue.put(f"读取输出时出错: {str(e)}\n")
    
    def _update_output(self):
        """更新UI显示输出"""
        try:
            while True:
                try:
                    if self.output_queue.empty():
                        break
                    line = self.output_queue.get_nowait()
                    self._append_output(line)
                except queue.Empty:
                    break
        except Exception as e:
            print(f"更新输出时出错: {e}")
    
    def _append_output(self, text):
        """追加输出到文本区域"""
        # 使用信号槽机制确保在主线程中更新UI
        QtCore.QMetaObject.invokeMethod(
            self, "_append_output_safe",
            QtCore.Qt.ConnectionType.QueuedConnection,
            QtCore.Q_ARG(str, text)
        )
    
    @QtCore.Slot(str)
    def _append_output_safe(self, text):
        """安全地追加输出（在主线程中调用）"""
        # 使用新的ANSI支持方法
        self.output_text.append_ansi_text(text)
    
    def clear_output(self):
        """清空输出"""
        self.output_text.clear()
        self._append_output("输出已清空\n")
    
    def copy_output(self):
        """复制输出到剪贴板"""
        text = self.output_text.toPlainText()
        if text:
            clipboard = QtWidgets.QApplication.clipboard()
            clipboard.setText(text)
            self.status_label.setText("已复制到剪贴板")
            self.status_label.setStyleSheet("color: #58a6ff; font-size: 11px;")
            
            # 2秒后恢复状态
            QtCore.QTimer.singleShot(2000, lambda: self.status_label.setText(
                "运行中 (PID: {})".format(self.process.pid) if self.is_running and self.process else "就绪"
            ))
    
    def set_win_pty_process(self, win_pty):
        """设置 Windows ConPTY 进程（pywinpty.PtyProcess）"""
        self.process = win_pty
        self._win_pty = win_pty
        self._pty_master_fd = None
        self.is_running = True
        self.output_text._pty_mode = True
        pid = getattr(win_pty, 'pid', '?')
        self.status_label.setText(f"运行中 (PID: {pid})")
        self.status_label.setStyleSheet("color: #3fb950; font-size: 11px;")
        self.output_text.clear_input_buffer()

    def set_external_process(self, process: subprocess.Popen):
        """设置外部进程引用（用于外部启动的进程，使用PIPE）"""
        self.process = process
        self._pty_master_fd = None
        self.is_running = True
        self.status_label.setText(f"运行中 (PID: {process.pid})")
        self.status_label.setStyleSheet("color: #3fb950; font-size: 11px;")
        self.output_text.clear_input_buffer()
    
    def set_pty_process(self, process: subprocess.Popen, master_fd: int):
        """设置使用PTY的外部进程引用"""
        self.process = process
        self._pty_master_fd = master_fd
        self.is_running = True
        self.output_text._pty_mode = True
        self.status_label.setText(f"运行中 (PID: {process.pid})")
        self.status_label.setStyleSheet("color: #3fb950; font-size: 11px;")
        self.output_text.clear_input_buffer()
    
    def clear_external_process(self):
        """清除外部进程引用"""
        self.process = None
        self._win_pty = None
        self._pty_master_fd = None
        self.is_running = False
        self.output_text._pty_mode = False
        self.status_label.setText("已停止")
        self.status_label.setStyleSheet("color: #7d8590; font-size: 11px;")
        self.output_text.clear_input_buffer()
    
    def clear_pty_process(self):
        """清除PTY进程引用"""
        self.clear_external_process()
    
    def is_process_running(self):
        """检查进程是否正在运行"""
        return self.is_running and self.process and self.process.poll() is None
    
    def get_process_pid(self):
        """获取进程PID"""
        if self.process:
            return self.process.pid
        return None
    
    def closeEvent(self, event):
        """关闭事件处理"""
        if self.is_running:
            self.stop_process()
        event.accept()


if __name__ == "__main__":
    import sys
    
    app = QtWidgets.QApplication(sys.argv)
    
    terminal = TerminalWidget()
    terminal.show()
    terminal.resize(600, 400)
    
    # 测试启动一个需要输入的进程
    terminal.start_process("python", ["-c", "name=input('请输入你的名字: '); print(f'你好, {name}!')"])
    
    sys.exit(app.exec())
