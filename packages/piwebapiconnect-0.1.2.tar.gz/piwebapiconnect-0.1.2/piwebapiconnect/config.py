import os
from pydantic_settings import BaseSettings, SettingsConfigDict
from typing import Optional
from dotenv import load_dotenv

class WebAPISettings(BaseSettings):
    """
    Configuration settings for the PI Web API Service.
    """
    PI_WEB_API_URL: Optional[str] = None
    PI_WEB_API_USERNAME: Optional[str] = None
    PI_WEB_API_PASSWORD: Optional[str] = None
    PI_WEB_API_VERIFY_SSL: bool = True
    PI_SERVER_NAME: Optional[str] = None

    model_config = SettingsConfigDict(
        env_file=".env", 
        extra='ignore'
    )

def get_settings(
    env_path: Optional[str] = None,
    url: Optional[str] = None,
    username: Optional[str] = None,
    password: Optional[str] = None,
    verify_ssl: Optional[bool] = None,
    server_name: Optional[str] = None
) -> WebAPISettings:
    if env_path:
        load_dotenv(env_path)
    
    settings = WebAPISettings()
    
    # Override with manual parameters if provided
    if url: settings.PI_WEB_API_URL = url
    if username: settings.PI_WEB_API_USERNAME = username
    if password: settings.PI_WEB_API_PASSWORD = password
    if verify_ssl is not None: settings.PI_WEB_API_VERIFY_SSL = verify_ssl
    if server_name: settings.PI_SERVER_NAME = server_name
    
    return settings
