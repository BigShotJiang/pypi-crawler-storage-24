"""Tests for client models."""

import datetime

import pytest

from quantumsignals.client.models import Signal, SignalCode


class TestSignalCode:
    """Tests for SignalCode class."""

    def test_normal_code_value(self):
        """Test NORMAL code is 0."""
        assert SignalCode.NORMAL == 0

    def test_market_closed_code_value(self):
        """Test MARKET_CLOSED code is 1."""
        assert SignalCode.MARKET_CLOSED == 1

    def test_get_message_normal(self):
        """Test message for NORMAL code."""
        assert SignalCode.get_message(SignalCode.NORMAL) == "Normal trading signal"

    def test_get_message_market_closed(self):
        """Test message for MARKET_CLOSED code."""
        assert SignalCode.get_message(SignalCode.MARKET_CLOSED) == "Market closed - outside trading hours for this model"

    def test_get_message_unknown_code(self):
        """Test message for unknown code."""
        assert SignalCode.get_message(99) == "Unknown code: 99"


class TestSignal:
    """Tests for Signal model."""

    @pytest.fixture
    def normal_signal(self):
        """Create a normal trading signal."""
        return Signal(
            for_minute_utc=datetime.datetime.now(datetime.timezone.utc),
            model="test_model",
            signal=1,
            symbol="ES",
            code=SignalCode.NORMAL,
        )

    @pytest.fixture
    def null_signal(self):
        """Create a null signal (market closed)."""
        return Signal(
            for_minute_utc=datetime.datetime.now(datetime.timezone.utc),
            model="test_model",
            signal=None,
            symbol="ES",
            code=SignalCode.MARKET_CLOSED,
        )

    def test_signal_default_code(self):
        """Test that Signal defaults to NORMAL code."""
        signal = Signal(
            for_minute_utc=datetime.datetime.now(datetime.timezone.utc),
            model="test_model",
            signal=1,
            symbol="ES",
        )
        assert signal.code == SignalCode.NORMAL

    def test_is_null_signal_false_for_normal(self, normal_signal):
        """Test is_null_signal returns False for normal signals."""
        assert normal_signal.is_null_signal() is False

    def test_is_null_signal_true_for_market_closed(self, null_signal):
        """Test is_null_signal returns True for market closed signals."""
        assert null_signal.is_null_signal() is True

    def test_code_message_normal(self, normal_signal):
        """Test code_message for normal signal."""
        assert normal_signal.code_message == "Normal trading signal"

    def test_code_message_market_closed(self, null_signal):
        """Test code_message for market closed signal."""
        assert null_signal.code_message == "Market closed - outside trading hours for this model"

    def test_null_signal_has_none_signal_value(self, null_signal):
        """Test that null signals have signal=None."""
        assert null_signal.signal is None

    def test_normal_signal_has_int_signal_value(self, normal_signal):
        """Test that normal signals have integer signal value."""
        assert isinstance(normal_signal.signal, int)
        assert normal_signal.signal == 1

    def test_signal_serialization_includes_code(self, normal_signal):
        """Test that code field is included in serialization."""
        data = normal_signal.model_dump()
        assert "code" in data
        assert data["code"] == SignalCode.NORMAL

    def test_null_signal_serialization(self, null_signal):
        """Test null signal serialization."""
        data = null_signal.model_dump()
        assert data["signal"] is None
        assert data["code"] == SignalCode.MARKET_CLOSED

    def test_signal_from_dict_with_code(self):
        """Test creating Signal from dict with code field."""
        data = {
            "for_minute_utc": datetime.datetime.now(datetime.timezone.utc),
            "model": "test_model",
            "signal": None,
            "symbol": "ES",
            "code": 1,
        }
        signal = Signal.model_validate(data)
        assert signal.code == SignalCode.MARKET_CLOSED
        assert signal.is_null_signal() is True

    def test_signal_from_dict_without_code_defaults_to_normal(self):
        """Test creating Signal from dict without code field defaults to NORMAL."""
        data = {
            "for_minute_utc": datetime.datetime.now(datetime.timezone.utc),
            "model": "test_model",
            "signal": 2,
            "symbol": "ES",
        }
        signal = Signal.model_validate(data)
        assert signal.code == SignalCode.NORMAL
        assert signal.is_null_signal() is False
