"""Pydantic models for Quantum Signals API responses."""

from datetime import datetime

from pydantic import BaseModel, computed_field


class SignalCode:
    """Signal type codes for indicating signal status.

    Codes are used to distinguish between normal trading signals
    and null signals sent when trading is not active.
    """

    NORMAL = 0  # Normal trading signal with valid prediction
    MARKET_CLOSED = 1  # Outside trading hours - no prediction made

    MESSAGES = {
        0: "Normal trading signal",
        1: "Market closed - outside trading hours for this model",
    }

    @classmethod
    def get_message(cls, code: int) -> str:
        """Get human-readable message for a signal code."""
        return cls.MESSAGES.get(code, f"Unknown code: {code}")


class Signal(BaseModel):
    """Real-time signal from the streaming service."""

    for_minute_utc: datetime
    model: str
    signal: int | None  # 0 (down/sell), 1 (stable/hold), 2 (up/buy), None for null signals
    symbol: str
    code: int = SignalCode.NORMAL  # Signal type: 0=normal, 1=market_closed

    def is_null_signal(self) -> bool:
        """Returns True if this is a null signal (no prediction).

        Null signals are sent when the market is closed or when
        predictions cannot be made for other reasons.
        """
        return self.code != SignalCode.NORMAL

    @computed_field  # type: ignore[prop-decorator]
    @property
    def code_message(self) -> str:
        """Human-readable message for the signal code."""
        return SignalCode.get_message(self.code)


class ModelDescription(BaseModel):
    """Description of a trained model."""

    model_id: str
    trained_on_symbols: list[str]
    trained_date_range: tuple[str, str]
    hash: str


class KongUserInfoResponse(BaseModel):
    """Response from GET /v1/me/kong endpoint showing actual Kong headers received.

    This endpoint must be called through Kong with an API key to receive headers.
    """

    kong_headers: dict[str, str | None]
    parsed_context: dict[str, str | None] | None = None
    message: str
