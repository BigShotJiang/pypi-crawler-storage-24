"""Quantum Signals Python client library."""

from quantumsignals.client.client import Client
from quantumsignals.client.exceptions import (
    APIError,
    APIKeyError,
    APIVersionRemovedError,
    QSClientError,
)
from quantumsignals.client.models import (
    KongUserInfoResponse,
    ModelDescription,
    Signal,
    SignalCode,
)

__version__ = "0.1.0"

__all__ = [
    # Main client
    "Client",
    # Models
    "Signal",
    "SignalCode",
    "ModelDescription",
    "KongUserInfoResponse",
    # Exceptions
    "QSClientError",
    "APIKeyError",
    "APIError",
    "APIVersionRemovedError",
]
