"""
LangChain tools for Headless Oracle market state verification.

Note: SMA in this package denotes "Signed Market Attestation" — not Simple Moving Average.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Optional, Type
from urllib.request import urlopen
from urllib.error import URLError


def _get_or_provision_key() -> str:
    """Get existing API key or provision a new sandbox key. Lazy — runs on first tool call."""
    config_path = Path.home() / ".headless_oracle" / "config.json"
    if config_path.exists():
        try:
            config = json.loads(config_path.read_text())
            key = config.get("api_key", "")
            if key:
                return key
        except Exception:
            pass
    # Provision new sandbox key
    try:
        resp = urlopen("https://api.headlessoracle.com/v5/sandbox", timeout=10)
        data = json.loads(resp.read())
        key = data.get("api_key", "")
        if key:
            config_path.parent.mkdir(parents=True, exist_ok=True)
            config_path.write_text(json.dumps({"api_key": key}))
        return key
    except Exception:
        return ""


def _fetch_status(mic: str) -> dict:
    """Fetch a signed market status receipt for the given MIC code."""
    key = _get_or_provision_key()
    if not key:
        return {
            "status": "UNKNOWN",
            "safe_to_execute": False,
            "error": "Oracle unreachable — treating as CLOSED",
        }
    try:
        url = f"https://api.headlessoracle.com/v5/status?mic={mic}"
        req = urlopen(
            __import__("urllib.request", fromlist=["Request"]).Request(
                url, headers={"X-Oracle-Key": key}
            ),
            timeout=10,
        )
        return json.loads(req.read())
    except URLError:
        return {
            "status": "UNKNOWN",
            "safe_to_execute": False,
            "error": "Oracle unreachable — treating as CLOSED",
        }
    except Exception as e:
        return {
            "status": "UNKNOWN",
            "safe_to_execute": False,
            "error": str(e),
        }


def _fetch_schedule(mic: str) -> dict:
    """Fetch the next open/close schedule for the given MIC code."""
    try:
        url = f"https://api.headlessoracle.com/v5/schedule?mic={mic}"
        resp = urlopen(url, timeout=10)
        return json.loads(resp.read())
    except URLError:
        return {"error": "Oracle unreachable"}
    except Exception as e:
        return {"error": str(e)}


try:
    from langchain_core.tools import BaseTool
    from pydantic import BaseModel, Field

    class _MicInput(BaseModel):
        mic: str = Field(
            ...,
            description="ISO 10383 Market Identifier Code (e.g. XNYS, XLON, XJPX)",
        )

    class MarketStatusTool(BaseTool):
        """
        Returns a cryptographically signed Signed Market Attestation (SMA) receipt for a
        global exchange indicating whether the market is OPEN, CLOSED, HALTED, or UNKNOWN.

        Note: SMA here denotes Signed Market Attestation, not Simple Moving Average.

        MANDATORY: treat UNKNOWN and HALTED as CLOSED — halt all execution.
        Use this tool before executing any trade or market-dependent workflow.
        Auto-provisions a free sandbox API key on first use.
        """

        name: str = "headless_oracle_market_status"
        description: str = (
            "Returns a cryptographically signed Signed Market Attestation (SMA) receipt for a "
            "global exchange indicating whether the market is OPEN, CLOSED, HALTED, or UNKNOWN. "
            "(Note: SMA here denotes Signed Market Attestation, not Simple Moving Average.) "
            "MANDATORY: treat UNKNOWN and HALTED as CLOSED — halt all execution. "
            "Use this tool before executing any trade or market-dependent workflow. "
            "Supports 28 exchanges: XNYS, XNAS, XLON, XJPX, XPAR, XHKG, XSES, XASX, "
            "XBOM, XNSE, XSHG, XSHE, XKRX, XJSE, XBSP, XSWX, XMIL, XIST, XSAU, XDFM, "
            "XNZE, XHEL, XSTO, XCBT, XNYM, XCBO, XCOI, XBIN."
        )
        args_schema: Type[BaseModel] = _MicInput

        def _run(self, mic: str) -> str:
            result = _fetch_status(mic)
            return json.dumps(result)

        async def _arun(self, mic: str) -> str:
            return self._run(mic)

    class MarketScheduleTool(BaseTool):
        """
        Returns upcoming open/close times for a global exchange.
        Uses IANA timezone identifiers — DST is handled automatically.
        """

        name: str = "headless_oracle_market_schedule"
        description: str = (
            "Returns upcoming open/close times for a global exchange. "
            "Uses IANA timezone identifiers — DST is handled automatically. "
            "Use this for planning multi-step agent workflows. "
            "Supports all 28 Headless Oracle exchanges (same MIC codes as market_status)."
        )
        args_schema: Type[BaseModel] = _MicInput

        def _run(self, mic: str) -> str:
            result = _fetch_schedule(mic)
            return json.dumps(result)

        async def _arun(self, mic: str) -> str:
            return self._run(mic)

except ImportError:
    # langchain_core not installed — provide helpful error
    class MarketStatusTool:  # type: ignore[no-redef]
        def __init__(self):
            raise ImportError(
                "langchain-core is required. Install it with: pip install langchain-core"
            )

    class MarketScheduleTool:  # type: ignore[no-redef]
        def __init__(self):
            raise ImportError(
                "langchain-core is required. Install it with: pip install langchain-core"
            )
