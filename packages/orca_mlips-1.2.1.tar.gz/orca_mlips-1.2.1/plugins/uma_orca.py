#!/usr/bin/env python3
"""ORCA ExtTool plugin for UMA (fairchem)."""

from __future__ import absolute_import, division, print_function

import os
import sys

if __package__ in (None, ""):
    _HERE = os.path.dirname(os.path.abspath(__file__))

    if _HERE not in sys.path:
        sys.path.insert(0, _HERE)
    from cli_orca import main_backend
else:
    from .cli_orca import main_backend


def main():
    plugin_name = os.path.basename(sys.argv[0]) or "uma_orca.py"
    main_backend("uma", plugin_name)


if __name__ == "__main__":
    main()
