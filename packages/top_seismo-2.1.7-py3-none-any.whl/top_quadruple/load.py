import sys as _sys
import numpy as _np
import importlib as _importlib
from top_quadruple.model import model
from top_quadruple.results import results
from os.path import dirname, basename, exists, join
from top_build_cache import TopBuildCache
from ctypes import CDLL
from glob import glob
from sys import stderr

class load:
    """
    Main class for running TOP:

    It is responsible for loading a previously compiled equation file,
    initializing the model and running the Arnoldi-Chebyshev algorithm

    :param str name: name of the equation filed to load

    :example:
        poly = load('eq_poly_ester')
    """
    lib = None
    name = None
    dati = None
    modelfile = ''
    libmodel = None
    shift = 0

    def __init__(self, name):
        self.try_preload_cache_libs()
        lib = _importlib.import_module(name)
        self.lib = lib.toppy
        self.libmodel = lib.modelpy
        lib.toppy.init_dati()
        self.name = name
        self.dati = lib.inputs
        self.cfg = lib.cfg
        self.cfg.init_config()

    def get_version(self):
        """
        returns the version of TOP that compiled the currently loaded equation file
        """
        return self.lib.get_version().strip()

    def read_dati(self, filename):
        """
        reads dati parameter file named `filename`

        :param str filename: dati file to read
        """
        self.lib.read_dati(filename)

    def init_model(self, filename):
        """
        initializes the star model with the file `filename`

        :param str filename: file to read to initialize the star model
        """
        self.modelfile = filename
        self.model = model(self.libmodel, filename)
        return self.model

    def run_arncheb(self, shift):
        """
        runs the Arnoldi-Chebyshev algorithm with a shift provided by the
        `shift` argument.
        Calls call to run_arncheb must be preceded by a call to `read_dati` to
        initialize problem parameters and a call to `init_model` to initialize
        the start model.

        :param float shift: starts the Arnoldi-Chebyshev algorithm arnoud frequency given by shift
        :rtype: results object
        :return: the results of the Arnoldi-Chebyshev algorithm
        """
        if self.modelfile != '':
            ierr = self.lib.init_arncheb()
            if ierr != 0:
                if ierr == 2:
                    print('stop after init_arncheb')
                    return []
                else:
                    raise Exception("Error in init_arncheb")
            self.shift = shift
            ierr = self.lib.py_run_arncheb(shift)
            if ierr != 0:
                if ierr == 2:
                    print('stop after init_arncheb')
                    return []
                else:
                    raise Exception("Error running arncheb")
            return self.get_results()
        else:
            _error('model not initialized')

    def get_grid(self):
        """
        returns the grid used by the model (requires a call to init_model)

        :rtype: tuple (r, theta)
        :return: the grid coordinates `r` and `theta`
        """
        nr, nt = self.lib.get_grid_size()
        return self.lib.get_grid(nr, nt)

    def get_zeta(self):
        """
        returns the zeta radial coordinate

        :rtype: tuple (r, theta)
        :return: the grid coordinates `r` and `theta`
        """
        nr, _ = self.lib.get_grid_size()
        return self.lib.get_zeta(nr)

    def get_sol(self, idom, isol, var):
        """
        returns `isol` th solution in domain number `idom` for variable named
        `var`

        :rtype: tuple (eigenvalue, eigenvector, Legendre degree)
        :return: eigenvalue, eigenvector of the solution. The solution is given in spectral space (Legendre), so the of the degrees of Legendre polynomial are also returned
        :param int idom: domain index of the solution
        :param int isol: solution number
        :param str var: variable name
        """
        nr, nt = self.lib.get_solsize(idom+1)
        if self.get_dtype() == "real":
            valp, vecp = self.lib.get_sol_real(idom+1, isol+1, var, nr, nt)
            if not _np.isscalar(valp):
                valp = valp[0] # valp is returned as singleton array to fix a
                # segfault occurring on scalar of c_long_double (fortran real kind
                # specifier for C long double) used when QUADRUPLE=ON
        else:
            valp, vecp = self.lib.get_sol_cplx(idom+1, isol+1, var, nr, nt)
        l = self.lib.pyget_lvar(idom+1, var, nt)
        return valp, vecp, l

    def get_vars(self, idom):
        """
        returns a list of variables in domain `idom`

        :rtype: [str]
        :return: list of variables in domain number idom
        :param int idom: domain index
        """
        nvars = self.lib.get_nvars(idom+1)
        ret = []
        for i in range(0, nvars):
            v = self.lib.get_var_name(idom+1, i+1)
            # '.decode()' allows Python3 understand the bytes objects that starts with b'' 
            # this function was not necessary for Python2
            ret.append(v.strip().decode())
        return ret

    def get_results(self):
        """
        returns an `result` object containing the results of a call to
        run_arncheb

        :rtype: results object
        :return: results of the previous call to run_arncheb
        """
        res = results()
        res.nsol = self.lib.get_nsol_out()
        res.ndom = self.lib.get_ndom()
        res.valps = []
        res.vecps = []
        res.l = []
        res.vars = []
        res.shift = self.shift
        res.modelfile = self.modelfile
        res.nr = []
        res.r, res.theta = self.get_grid()
        res.zeta = self.get_zeta()
        try:
            res.lres = self.dati.lres
        except:
            pass
        res.libname = self.name
        res.dati = {}
        d = list(vars(self.dati).items())
        for i in range(len(d)):
            k, v = d[i]
            if type(v) == _np.ndarray:
                res.dati[k] = v

        for idom in range(0, res.ndom):
            res.vars.append(self.get_vars(idom))
            res.nr.append(self.lib.get_dom_nr(idom+1))

        for isol in range(0, res.nsol):
            res.valps.append(0.0)
            res.vecps.append([])
            res.l.append([])
            for idom in range(0, res.ndom):
                vecps = {}
                ls = {}
                for var in res.vars[idom]:
                    valp, vecp, l = self.get_sol(idom, isol, var)
                    vecps[var] = vecp
                    ls[var] = l
                res.vecps[-1].append(vecps)
                res.l[-1].append(ls)
            res.valps[isol] = valp
        return res

    def get_dtype(self):
        return self.lib.dtype().decode('utf8').strip()

    def write_output(self, dir):
        """
        write the results computed by run_arncheb to location `dir`, this for
        retro compatibility purpose
        """
        if dir[-1] != '/':
            dir = dir + '/'
        _mkpath(dir)  # TODO: fix undefined function
        self.lib.pywrite_output(dir)

    def set_nt(self, nt):
        self.lib.set_nt(nt)
        self.dati.nt = nt

    def set_nr(self, nr):
        self.lib.set_nr(nr)

    def try_preload_cache_libs(self):
        """
        Tries to preload TOP libraries available in cache if applicable.
        """
        tb_cache = TopBuildCache(None)
        top_float_precision = basename(dirname(__file__)).replace('top_', '').replace('quadruple', 'quad')
        tb_cache.add_conf_opt(top_float_precision, prepend_as_parent_folder=True)
        top_lib_dir = tb_cache.get_lib_dir()
        max_dep_depth = 3
        loading_errors = {}
        if exists(top_lib_dir):
            # cache is available for this floating-point precision of top
            # preload provided libraries
            # TODO: load only needed libraries not all in cache
            libs_in_cache = glob(join(top_lib_dir, '*.so'))
            loaded_libs = []
            il = 0
            while (len(loaded_libs) < len(libs_in_cache) and
                   il < len(libs_in_cache) * max_dep_depth):
                lib = libs_in_cache[il % len(libs_in_cache)]
                il += 1
                if lib in loaded_libs:
                    # lib is already loaded
                    continue
                try:
                    CDLL(lib)
                    loaded_libs += [lib]
                except Exception as e:
                    loading_errors[basename(lib)] = str(e)
                    continue
            # TODO: information printed should be only if debug mode enabled
            # error/warning on unloaded cache libs
            print(f"Libraries loaded from cache ({top_lib_dir}):", [basename(lib) for lib in loaded_libs])
            if len(loaded_libs) < len(libs_in_cache):
                failed_to_load_libs = [basename(lib) for lib in libs_in_cache if lib not in loaded_libs]
                print("Libraries from cache that failed to load:", file=stderr)
                # TODO: error printing should be further tested
                for failed_lib in failed_to_load_libs:
                    print("==", failed_lib, file=stderr)
                    print(loading_errors[failed_lib], file=stderr)
