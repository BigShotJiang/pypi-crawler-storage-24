import h5py as _h5py
import numpy as _np
import matplotlib.pyplot as _plt
import sys as _sys
# Importing top_quadruple.load in that manner avoids circular dependencies.
import top_quadruple.load as load

class results:
    """
    This class stores results of a previous computation

    :param str result_file: (optional) file with previous results stored
    :rtype: :py:class:`results` object
    :return: results of a previous computation (if result_file is provided) an empty results object otherwise
    """

    def __init__(self, result_file = ''):
        self.valps = []
        self.vecps = []
        self.l = []
        self.nsol = 0
        self.modelfile = None
        self.shift = 0
        self.lres = 0
        self.libname = None
        self.dati = {}
        self.ndom = 0
        self.vars = []
        self.nr = []
        self.zeta = []
        self.r = []
        self.theta = []
        if result_file != '':
            self._from_file(result_file)

    def _from_file(self, h5result):

        f = _h5py.File(h5result, 'r')
        self.nsol = len(f['/']) - 2 # minus r and theta fields
        self.modelfile = f.attrs['modelfile']
        self.shift = f.attrs['shift']
        self.lres = f.attrs['lres']
        self.libname = f.attrs['eq']
        for k, v in f.attrs.items():
            self.dati[k] = v
        self.ndom = len(f['sol0'].keys())

        zeta = []
        for isol in range(0, self.nsol):
            self.vecps.append([])
            self.l.append([])
            sgrp = f['/sol%d' % (isol)]
            self.valps.append(sgrp.attrs['valp'])
            for idom in range(0, self.ndom):
                valp = {}
                vecps = {}
                ls = {}
                vars = []
                grp = f['/sol%d/dom%d' % (isol, idom)]
                if isol == 0:
                    if 'zeta' in grp:
                        dom_grid = grp['zeta'][()]
                    else:
                        # fallback on attributes if dataset not found
                        # also for backward compatibility
                        dom_grid = grp.attrs['zeta']
                    self.nr.append(len(dom_grid))
                    zeta.append(dom_grid)
                for var in grp.keys():
                    if var != 'zeta':
                        vars.append(var)
                        vdset = f['/sol%d/dom%d/%s' % (isol, idom, var)]
                        vecps[var] = vdset[:, :]
                        ls[var] = vdset.attrs['l']

                self.vecps[-1].append(vecps)
                self.l[-1].append(ls)
                if isol == 0:
                    self.vars.append([])
                    self.vars[-1] = vars

        self.zeta = _np.zeros(shape = sum(self.nr))
        for idom in range(0, self.ndom):
            skip = sum(self.nr[0:idom])
            self.zeta[skip:skip+self.nr[idom]] = _np.array(zeta[idom])
        self.r = f['/r'][:, :]
        self.theta = f['/theta'][:]
        f.close()

    def append(self, res):
        """
        appends results stored in res
        """
        self.nsol = self.nsol + res.nsol
        for isol in range(0, res.nsol):
            self.valps.append(res.valps[isol])
            self.vecps.append(res.vecps[isol])
            self.l.append(res.l[isol])

    def get_sol(self, idom, isol, var):
        """
        returns the `isol` th solution in domain number `idom` for variable
        named `var`

        :rtype: tuple (eigenvalue, eigenvector, Legendre degree)
        :return: eigenvalue, eigenvector of the solution. The solution is given in spectral space (Legendre), so the of the degrees of Legendre polynomial are also returned
        :param int idom: domain index of the solution
        :param int isol: solution number
        :param str var: variable name
        """
        valp = self.valps[isol]
        vecp = self.vecps[isol][idom][var]
        l = self.l[isol][idom][var]
        return valp, vecp, l

    def get_grid(self, idom = -1):
        """
        returns the grid used by the model (requires a call to init_model)

        if `idom` is provided returns the grid only for this particular domain
        """
        if idom >= 0:
            skip = 0
            for i in range(0, idom):
                nr = self.nr[i]
                skip = skip + nr
            nr = self.nr[idom]
            return self.r[skip:skip+nr], self.theta
        else:
            return self.r, self.theta

    def save(self, h5file, ids = [], zeta_in_attrs=False):
        """
        saves the results in HDF5 format in file named `h5file`

        Args:
            zeta_in_attrs: bool
                If True zeta is stored as h5 attribute otherwise as a dataset.
                Preferably avoid attribute for hdf5 < 1.8 as attribute length
                is limited to 64Kio in this version. The argument is maintained
                for backward compatibility/testing.
        """
        f = _h5py.File(h5file, 'w')
        for k, v in self.dati.items():
            if type(v) == _np.ndarray and v.dtype == _np.dtype('S1'):
                f.attrs[k] = v.tostring().strip()
            else:
                f.attrs[k] = v
        f.attrs['shift'] = self.shift
        f.attrs['lres'] = self.lres
        f.attrs['eq'] = self.libname
        f.attrs['modelfile'] = self.modelfile

        valp = 0.0
        f.create_dataset('r', data = self.r)
        f.create_dataset('theta', data = self.theta)
        if ids == []:
            id_range = range(0, self.nsol)
        else:
            id_range = ids
        for ii, isol in enumerate(id_range):
            sgrp = f.create_group('sol%d' % ii)
            skip = 0
            for idom in range(0, self.ndom):
                nr = self.nr[idom]
                dgrp = sgrp.create_group('dom%d' % idom)
                if zeta_in_attrs:
                    dgrp.attrs['zeta'] = self.zeta[skip:skip + nr]
                else:
                    dgrp.create_dataset('zeta', data=self.zeta[skip:skip+nr])
                    # zeta buffer in dataset because it can exceed attribute
                    # max size limit of older hdf5 versions < 1.8
                    # (limit is 64Kio, that is a zeta.size about 8192 for a float64 buffer)
                    # ref.: https://support.hdfgroup.org/documentation/hdf5/latest/_attributes.html
                skip = skip + nr
                for var in self.vars[idom]:
                    valp, vecp, l = self.get_sol(idom, isol, var)
                    dset = dgrp.create_dataset(var, data = vecp)
                    dset.attrs['l'] = l
            sgrp.attrs['valp'] = valp
        f.close()

    def plot_val(self, mat):
        """
        Plots the values stored in `mat`

        :param matrix mat: function to be plotted
        """
        r, theta = self.get_grid()
        cost = _np.cos(theta)
        sint = _np.sin(theta)

        # fg = vec
        x = r * sint
        y = r * cost

        _plt.pcolormesh(x, y, mat)
        # _plt.colorbar()
        _plt.show()


    def get_leg(self):
        """
        Initializes legendre py. wrapper if not already and returns a reference to it.
        """

        if not hasattr(self, 'leg'):
            # legendre py wrapper not already loaded
            # do it:
            import legpy as _legpy
            self.leg = _legpy.legpy

        return self.leg

    def plot(self, idom, isol, var, m=None):
        """
        Plots isol'th solution of variable var in domain number idom

        :param int idom: domain number
        :param int isol: solution to plot
        :param str var: variable to plot
        """
        leg = self.get_leg()

        val, vec, l = self.get_sol(idom, isol, var)

        r, theta = self.get_grid(idom)
        cost = _np.cos(theta)
        sint = _np.sin(theta)

        # fg = vec
        if m == None:
            m = self.dati['m']
        fg = leg.eval2d(vec, cost, l[0], 2, m)

        x = r * sint
        y = r * cost

        _plt.pcolormesh(x, y, fg)
        _plt.title(var)
        # _plt.colorbar()
        _plt.show()

    def read_model(self):
        """
        Reads the model that was used to perform the computation

        :rtype: :py:class:`model` (see :ref:`model<model>`)
        :return: the model used to perform computation
        """
        p = load.load(self.libname)
        for k in self.dati.keys():
            p.dati.k = self.dati[k]
            r, t = self.get_grid()
            p.set_nt(len(t))
            p.set_nr(len(r))
        return p.init_model(self.modelfile)

    def cheb_project(self, fr):
        """
        Projects a radial field (in grid space) onto Chebyshev polynomials

        """

        r, t = self.get_grid()
        nr = len(r)
        m0 = _np.zeros((2*nr-1, ))
        m = _np.zeros((nr, nr))

        for i in range(0, 2*nr-1):
            m0[i] = _np.cos(_np.pi*i/(nr-1))

        cnst = 2.0/(nr-1)
        for i in range(0, nr):
            for j in range(0, nr):
                m[i, j] = cnst * m0[(i*j) % (2*nr-2)]

        for i in range(0, nr):
            m[0, i] = 0.5*m[0, i]
            m[nr-1, i] = 0.5*m[nr-1, i]
            m[i, 0] = 0.5*m[i, 0]
            m[i, nr-1] = 0.5*m[i, nr-1]

        return  _np.dot(m, fr)

    def cheb_eval(self, fs, r):
        """
        Evaluates function fs (in spectral space) onto grid r

        """

        rgrid, t = self.get_grid()
        f = _np.zeros((r.shape[0], fs.shape[1]))
        for j in range(0, fs.shape[1]):
            a = r[0, j]
            b = r[-1, j]
            x = (r[:, j]-a) * 2 / (a-b) + 1

            T = _np.zeros((r.shape[0], fs.shape[0]))
            T[:, 0] = _np.ones((r.shape[0], ))
            T[:, 1] = x
            f[:, j] = fs[0, j] * T[:, 0] + fs[1, j] * T[:, 1]
            for i in range(2, fs.shape[0]):
                T[:, i] = 2*x * T[:, i-1] - T[:, i-2]
                f[:, j] = f[:, j] + fs[i, j] * T[:, i]

        return f
