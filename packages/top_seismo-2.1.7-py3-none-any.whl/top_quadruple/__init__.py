import os as _os
import sys as _sys
import numpy as _np
import h5py as _h5py
import importlib as _importlib
import matplotlib.pyplot as _plt
from distutils.dir_util import mkpath as _mkpath
from os.path import exists, isdir

version = ''

# separate python path set by cmake
# (TODO: maybe remove this and just installed in whatever python path set by cmake
#        thus no PYTHONPATH to set)
extra_py_path = '/root/local/lib/python3.11.15/site-packages'
if exists(extra_py_path) and isdir(extra_py_path):
	_sys.path.append(extra_py_path)

from top_quadruple.model import model
from top_quadruple.load import load
from top_quadruple.results import results

def _error(msg):
    raise Exception(msg)

def get_compiled_files():
    """
    Get the list of compiled equation files (that can be loaded with
    :py:func:`load`)

    :rtype: [str]
    :return: List of compiled equation files
    """
    files = []
    for dirpath, dirnames, filenames in _os.walk('/builds/top/top/build/src/lib'):
        for filename in filenames:
            if not filename.startswith('lib') and filename.endswith('.so'):
                files.append(filename[0:-3])
    return files
