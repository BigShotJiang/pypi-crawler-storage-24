#!python

from sys import argv, stderr
from re import match, subn
from os.path import exists
import _io
from abc import ABC, abstractmethod
from enum import Enum
import numpy as np
from math import ceil


DEBUG = False

# TODO: redefine __str__ to store all error messages here and not in code
# (avoids repetitions)
class ReadEqError(Enum):
    OK = 0 # no error
    INSTRUC_MISSING_ARGS = 1
    EMPTY_VAR_LIST=7
    EMPTY_DOMAIN_LIST=31
    REPATED_DOMAIN_NAME=32
    UNKNOWN_DOMAIN=33
    VAR_ALREADY_EXISTS=34
    EQ_ALREADY_EXISTS=35
    ILLEGAL_DOMAIN_COUPLING=36
    NONINT_DOLOOP_ARG=37
    INFINITE_DOLOOP=38
    NOITE_DOLOOP=39
    ILLFORMED_DO_LOOP=40

class ReadEqParser(ABC):

    def __init__(self, argv, output='matrices.inc', out_mode='printing', ncols=80):
        self.argv = argv
        self._input = self.argv[1]
        self.output = output
        self.ncols = ncols
        assert (out_mode in ['buffering', 'printing'])
        self.out_mode = out_mode
        if out_mode == 'buffering':
            self.out_buf = []
        # defaultly only one domain
        self.domainNumber = 1
        self.varDomainNumber = 1
        self.dm = f"dm({self.domainNumber})"
        self.idm = f"idm({self.domainNumber},{self.domainNumber})"
        self.countterm_in_parse = True
        self.define_instrucs()

    def _init_in_nl(self):
        """
        Must be call before the equation file is expanded.

        expand_doloop update the in_nl map.

        in_nl[i] is the line (in 1-base index) in original equation source
        before expansion, that corresponds to the line i
        (in 1-base index) of the equation file after expansion.
        By default self.in_nl[self.nl] == self.nl.
        """
        self.in_nl = [0] + np.arange(1, len(self.in_lines) + 1).tolist()

    @abstractmethod
    def parser_type():
        # at the moment this is the only abstract method
        # so it is a bit useless but at least that makes
        # clear at execution that this class cannot be
        # instantiated
        pass

    #TODO: get 2D, is_cplx and is_multi attrs at once
    @staticmethod
    def is_2D(eqfile):
        with open(eqfile) as eqstream:
            return 'llm' in eqstream.read()

    @staticmethod
    def is_multi(eqfile):
        with open(eqfile) as eqstream:
            return 'domains' in eqstream.read()

    def attrs(self, *names: list):
        attr_lst = []
        for attr in names:
            attr_lst += [eval(f'self.{attr}')]
        return attr_lst

    def expand(self):
        """
        Expands the input equation file before parsing.
        """
        with open(self._input) as in_stream:
            self.in_lines = in_stream.readlines()
            self._init_in_nl()
            self.nl = 0
            while self.nl < len(self.in_lines):
                li = self.in_lines[self.nl]
                self.nl += 1
                li = li.strip()
                # remove inline comment
                if m := match(r"(^[^#]*)#", li):
                    li = m.group(1)
                # ignore blank line
                if match(r"^\s*$", li):
                    continue
                self.instrucs = li.split()
                keyword = self.instrucs[0]
                assert ('macro' in self.instruc_funcs and 'do' in
                        self.instruc_funcs)
                if keyword in ['macro', 'do']:
                    self.instruc_funcs[keyword]()
                if keyword == 'do':
                    # do line is deleted after expand_doloop
                    self.nl -= 1

        self._orig_input = self._input
        self._input = self._input+'_pyexpanded'

        with open(self._input, 'w+') as new_in_stream:
            new_in_stream.writelines(self.in_lines)

    def parse(self):
        if len(self.argv) < 2:
            self.fatal_err("Usage: readeq eq_file", 1)

        self.lincr = 2

        self.is_cplx = self.is_complex(self._input) or '--cplx' in self.argv

        self.setdefault()

        if not exists(self._input):
            self.fatal_err(f"File {input} not found.", 2)

        with open(self._input) as in_stream:
            self.in_lines = in_stream.readlines()
            for self.nl, li in enumerate(self.in_lines):
                self.nl += 1
                if DEBUG:
                    print(f"parsed line ({self.in_nl[self.nl]}):", li, end='')
                li = li.strip()
                # remove inline comment
                if m := match(r"(^[^#]*)#", li):
                    li = m.group(1)
                # ignore blank line
                if match(r"^\s*$", li):
                    continue
                # TODO: rename self.instrucs to self.instruc
                self.instrucs = li.split()
                if self.countterm_in_parse and self.instrucs[0] in ["term", "termi", "termbc", "termbci", "sub",
                                   "subi", "subbc", "subbci"]:
                    self.countterm()
                elif self.instrucs[0] == "definition":
                    self.add_definition()

        self.out_stream = open(self.output, 'w+')

        if self.out_mode == 'buffering':
            self.out_buf = []

        self.writehead()
        self.setdefault()  # TODO: why do we call setdefault again?

        # TODO: do we need to make two passes, just one should be enough, shouldn't
        # it?
        # TODO: method that returns in_lines, call init_in_nl
        # after closing in_stream (factoring all input file openings/readings)
        with open(self._input) as in_stream:
            self.in_lines = in_stream.readlines()
            for self.nl, li in enumerate(self.in_lines):

                self.nl += 1
                if DEBUG:
                    print(f"parsed line ({self.in_nl[self.nl]}):", li, end='')
                li = li.strip()
                # remove inline comment
                if m := match(r"(^[^#]*)#", li):
                    li = m.group(1)

                if match(r"^\s*$", li):
                    continue

                self.instrucs = li.split()

                if self.instrucs[0] in self.instruc_funcs:
                    self.instruc_funcs[self.instrucs[0]]()
                elif self.instrucs[0].strip() != "":
                    self.fatal_err(f"Error on line {self.in_nl[self.nl]}: {self.instrucs[0]} unknown" " command.", 4)

        self.writetail()
        self.writeinputs("inputs.F90")


        if self.out_mode == 'buffering':
            # it's time to print out
            print('\n'.join(self.out_buf), end='', file=self.out_stream)

        self.out_stream.close()


        # TODO: remove, it would happen before
        if not exists(self.output):
            self.fatal_err(f"Cannot write to {self.output}.", 3)

    def send_out(self, data: str, outlst=None, end='\n'):
        if outlst is not None:
            outlst += [data]
        elif self.out_mode == 'printing':
            print(data, file=self.out_stream)
        elif self.out_mode == 'buffering':
            if not hasattr(self, 'out_buf') or self.out_buf is None:
                self.out_buf = []
            self.out_buf += [data]

    def define_instrucs(self):
        """
        Define the functions to parse each one of available equation file instructions.
        """
        self.instruc_funcs = {
            "varlist": lambda: self.readvarlist(),
            "eqlist": lambda: self.readeqlist(),
            "equation": lambda: self.seteq(),
            "term": lambda: self.addterm(),
            "termi": lambda: self.addtermi(),
            "termbc": lambda: self.addtermbc(),
            "termbci": lambda: self.addtermbci(),
            "sub": lambda: self.callsub(),
            "subi": lambda: self.callsubi(),
            "subbc": lambda: self.callsubbc(),
            "subbci": lambda: self.callsubbci(),
            "input": self.addinput,
            "stamp": lambda: self.set_stamp(" ".join(self.instrucs[1:])),
            "instruction": self.writeinstruction,
            "suppress": lambda: self.suppressvar(),
            "definition": lambda: self.add_definition(),
            "domains": lambda: self.readdomains() or self.initcounters(),
            "macro": lambda: self.addmacro(),
            "do": lambda: self.expand_doloop(),
            "enddo": lambda: fatal_err("Error on line {self.in_nl[self.nl]}: enddo without preceding do")
        }

    def fatal_err(self, msg, status):
        # TODO: use an enumeration of possible errors with doc or map of messages
#        print(msg, file=stderr)
#        exit(status)
        if isinstance(status, ReadEqError):
            suff = f'({status} {status.value}).'
        else:
            suff = f'(err: {status}).'
        raise Exception(msg + suff)

    def set_stamp(self, stamp_exp):
        self.stamp = stamp_exp

    def mywrap(self, str_):
        # TODO: this function should be renamed with a more meaningful name
        str1 = ""
        for s in str_.split("\n"):
            if m := match(r"^(.*[^\s])\s+$", s):
                s = m.group(1)
            while len(s) > self.ncols:
                str1 += s[:self.ncols] + "&\r\n&"
                s = s[self.ncols:]
            str1 += s + "\r\n"
        return str1

    def setdefault(self):
        self.nvar = 0  # added in python version
        self.nl = 0  # previously named nline
        self.power_max = 0
        self.defs_type = []
        self.defs = []
        self.defs_value = []
        self.inputs = ["shift", "rootdir", "nsol"]
        self.inputs_datatype = ["double precision", "character*(512)", "integer"]
        self.inputs_format = ["f7.4", "A", "I2"]
        self.inputs_value = ["0d0", "'no_dir'", "4"]
        if self.is_cplx:
            self.inputs[0] += "_imag"
            self.inputs.insert(0, "shift_real")
            self.inputs_format.insert(0, "f7.4")
            self.inputs_value.insert(0, "0d0")
            self.inputs_datatype.insert(0, "double precision")
        self.amat = []
        self.prev = "empty"

    def countterm(self):
        if self.instrucs[0] in ["term", "sub", "termi", "subi"]:
            if len(self.instrucs) < 2:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: many terms missing.", 4)
            if self.instrucs[1] == "s":
                self.nas += 1
            elif self.instrucs[1] == "r":
                self.nar += 1
            else:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type.", 5)
        elif self.instrucs[0] in ["termbc", "subbc", "termbci", "subbci"]:
            if len(self.instrucs) < 2:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: many terms missing.", 4)
            if self.instrucs[1] == "s":
                self.nasbc += 1
            else:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type.", 5)
        else:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: programming error in readeq.", 6)

    def add_definition(self):
        if len(self.instrucs) < 4:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}:  missing arguments.",
                           ReadEqError.INSTRUC_MISSING_ARGS)
        self.instrucs[1] = self.instrucs[1].replace("_", " ")
        self.defs_type += [self.instrucs[1]]
        self.defs += [self.instrucs[2]]
        self.defs_value += [" ".join(self.instrucs[3:])]

    def writehead(self):
        asi_ari_size = 7 if self.is_cplx else 4
        asbci_size = 7 if self.is_cplx else 6

        self.send_out("      subroutine init_a")
        self.send_out("      use model")
        self.send_out("      use inputs")
        self.send_out("      integer i, der, der_min, der_max")
        self.send_out("      if (allocated(dm)) deallocate(dm)")
        self.send_out("      if (allocated(dmat)) deallocate(dmat)")
        self.send_out("      allocate(dm(1))")
        self.send_out("      allocate(dmat(1))")
        # NOTE: declarations with defs_types are made in writeinputs
        for i in range(len(self.defs)):
            self.send_out(self.mywrap(f"      {self.defs[i]} = {self.defs_value[i]}"))
        self.send_out("")
        self.send_out("      grd(1)%mattype = mattype")
        self.send_out("      if (allocated(dm(1)%as)) deallocate(dm(1)%as)")
        self.send_out("      if (allocated(dm(1)%ar)) deallocate(dm(1)%ar)")
        self.send_out("      if (allocated(dm(1)%asbc)) deallocate(dm(1)%asbc)")
        self.send_out("      if (allocated(dm(1)%asi)) deallocate(dm(1)%asi)")
        self.send_out("      if (allocated(dm(1)%ari)) deallocate(dm(1)%ari)")
        self.send_out("      if (allocated(dm(1)%asbci)) deallocate(dm(1)%asbci)")
        self.send_out(
            "      if (allocated(dm(1)%var_name)) deallocate(dm(1)%var_name)",
        )
        self.send_out(
            "      if (allocated(dm(1)%eq_name)) deallocate(dm(1)%eq_name)"
        )
        self.send_out(f"      dm(1)%nas={self.nas}")
        self.send_out(f"      dm(1)%nar={self.nar}")
        self.send_out(f"      dm(1)%nasbc={self.nasbc}")
        self.send_out(f"      allocate(dm(1)%as(dm(1)%nas),dm(1)%asi({asi_ari_size},dm(1)%nas))")
        self.send_out("      dm(1)%as = 0d0; dm(1)%asi=0")
        self.send_out(
            f"      allocate(dm(1)%ar(nr,dm(1)%nar),dm(1)%ari({asi_ari_size},dm(1)%nar))"
        )
        self.send_out("      dm(1)%ar = 0d0; dm(1)%ari=0")
        self.send_out(
            f"      allocate(dm(1)%asbc(dm(1)%nasbc),dm(1)%asbci({asbci_size},dm(1)%nasbc))",
        )
        self.send_out("      dm(1)%asbc = 0d0; dm(1)%asbci=0")
        self.send_out("")

    def readvarlist(self, call_at_end=None):
        if len(self.instrucs) < 2:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: empty variable list!", EMPTY_VAR_LIST)
        self.varlist = []
        for i in range(1, len(self.instrucs)):
            if self.instrucs[i] in self.varlist:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: repeated variable name.", 8)
            self.varlist += [self.instrucs[i]]

        if self.nvar == 0:
            self.nvar = len(self.varlist)
        elif self.nvar != len(self.varlist):
            self.fatal_err(
                f"Error on line {self.in_nl[self.nl]}: number of equations and variables" " differ.", 9
            )

        self.send_out(f"      dm(1)%nvar={self.nvar}")
        self.send_out("      allocate(dm(1)%var_name(dm(1)%nvar))")
        for i in range(1, self.nvar + 1):
            self.send_out(f"      dm(1)%var_name({i})='{self.varlist[i-1]}'")
        if not call_at_end is None:
            call_at_end()
        self.send_out(f"      allocate(dm(1)%var_keep({self.nvar}))")
        self.send_out("      dm(1)%var_keep = .true.")
        self.send_out("")

    def readeqlist(self, call_at_end=None):
        if len(self.instrucs) < 2:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: empty equation list!", 8)
        self.eqlist = []
        for i in range(1, len(self.instrucs)):
            if self.instrucs[i] in self.eqlist:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: repeated equation name.", 8)
            self.eqlist += [self.instrucs[i]]

        if self.nvar == 0:
            self.nvar = len(self.eqlist)
        elif self.nvar != len(self.eqlist):
            self.fatal_err(
                f"Error on line {self.in_nl[self.nl]}: number of equations and variables" " differ.", 9
            )

        self.send_out(f"      allocate(dm(1)%eq_name({self.nvar}))")
        for i in range(1, self.nvar + 1):
            self.send_out(f"      dm(1)%eq_name({i})='{self.eqlist[i-1]}'")
        if not call_at_end is None:
            call_at_end()

    def seteq(self, call_at_start=None, call_at_end=None, disp_eq_comment=True,
             get_eq=True):
        if len(self.instrucs) < 2:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing terms.", 9)
        if len(self.instrucs) > 2:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: too many terms.", 10)
        if call_at_start is not None:
            call_at_start()

        if get_eq:
            self.equation = 0
            for i in range(len(self.eqlist)):
                if self.instrucs[1] == self.eqlist[i]:
                    self.equation = i + 1
            if self.equation == 0:
                self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{self.instrucs[1]}" unknown equation.', 11)

        first_line = "!" + "-" * 60
        second_line = f"      ! equation {self.instrucs[1]}:"
        if disp_eq_comment:
            self.send_out(first_line)
            self.send_out(second_line)
        self.amat += [first_line+'\r\n']
        self.amat += [second_line+'\r\n']
        if call_at_end is not None:
            call_at_end()

    def addterm(self, types=['s', 'r'], empty_end_line=True,
                fail_on_unknown_type=True, outlst=None, offsettoz=True,
                get_var=True, counter_inc_func:callable=None,
                counter_val_func:callable=None):
        """
        Args:
            empty_end_line: bool
                if True an empty end line is output.
        """
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)

        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)

        if len(self.instrucs) < 5:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing terms.", 12)

        if len(self.instrucs) > 5:
            self.instrucs[3] = " ".join(self.instrucs[3:-2])
            self.instrucs = self.instrucs[:5]

        power = self.instrucs[2]

        if m := match(r".*w(\d*)", power):
            power = m.group(1)

        if power == "":
            power = 1

        if float(power) > float(self.power_max):
            self.power_max = power

        der = self.instrucs[4]
        if m := match(r".*\^(.*)", der):
            der = m.group(1)
        else:
            der = der.count("'")

        varname = self.instrucs[4].replace("'", "")
        if m := match(r"(.*)\^.*", varname):
            varname = m.group(1)

        if get_var:
            self.variable = 0

            for i in range(len(self.varlist)):
                if varname == self.varlist[i]:
                    self.variable = i + 1

            if self.variable == 0:
                self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{varname}" unknown variable.', 13)


        if isinstance(self, ReadEqParserMulti2D):
            self.varDomainNumber = self.vardomain[varname]

        self.instrucs[3] = self.treat_string(self.instrucs[3])

        dm = self.dm = f"dm({self.domainNumber})"
        if self.instrucs[1] == types[0]:
            counter_inc_func("nas")  # nas += 1
            counter_val = counter_val_func('nas')
            self.send_out(
                self.mywrap(f"      {dm}%as({counter_val}) = {self.instrucs[3]}"), self.amat)
            for i in range(self.nloops):
                self.amat += ["      enddo"]

            if offsettoz:
                self.send_out(f"      {dm}%offset=0", outlst=outlst)
            self.send_out(f"      {dm}%asi(1,{counter_val}) = {power}", outlst=outlst)
            self.send_out(f"      {dm}%asi(2,{counter_val}) = {der}", outlst=outlst)
            self.send_out(f"      {dm}%asi(3,{counter_val}) = {self.equation}", outlst=outlst)
            self.send_out(f"      {dm}%asi(4,{counter_val}) = {self.variable}", outlst=outlst)
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i': # TODO: should be done
                self.send_out(f"      {dm}%asi(7,{counter_val}) = 0", outlst=outlst)
            self.send_out("", outlst=outlst)
        elif self.instrucs[1] == types[1]:
            counter_inc_func("na" + types[1]) # nar or nartt += 1 
            counter_val = counter_val_func('na'+types[1])
            self.amat += [self.mywrap(f" {dm}%a{types[1]}({self.i_index},"+str(eval('self.na'+types[1]))+f") = {self.instrucs[3]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]
            eval(f'self.send_out(" {dm}%a' +types[1]+'i(1,'
                 f"{counter_val}) ="+f'{power}")')
            eval(f'self.send_out(" {dm}%a'+types[1]+'i(2,'
                 f"{counter_val}) ="+f'{der}")')
            eval(f'self.send_out(" {dm}%a'+types[1]+'i(3,'
                 f"{counter_val}) ="+f'{self.equation}")')
            eval(f'self.send_out(" {dm}%a'+types[1]+'i(4,'
                 f"{counter_val}) ="+f'{self.variable}")')
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i': # TODO: should be done
            # according a function arg or in child class, not here
                eval(f'self.send_out(" {dm}%a'+types[1]+'i(7,'
                     f"{counter_val}) ="+f' 0') # term is not complex, hence always 0 here
            if empty_end_line:
                self.send_out("\n")
        else:
            if fail_on_unknown_type:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type {self.instrucs[1]}.", 16)

        self.der = der
        self.prev = self.instrucs[1]
        self.power = power

    def addtermi(self, outlst=None, dom_id=1, get_var=True,
                 counter_inc_func:callable=None,
                 counter_val_func:callable=None):
        """
        """
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)

        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)

        self.addterm(empty_end_line=False, outlst=outlst,
                     get_var=get_var, counter_inc_func=counter_inc_func,
                     counter_val_func=counter_val_func)

        dm = self.dm
        if self.instrucs[1] == "s":
            self.send_out(f"      {dm}%asi(7,{counter_val_func('nas')}) = {int(self.is_cplx)}", outlst=outlst)
        elif self.instrucs[1] == "r":
            self.send_out(f"      {dm}%ari(7,{counter_val_func('nar')}) = {int(self.is_cplx)}", outlst=outlst)
        self.send_out("\n", outlst=outlst)

    def addtermbc(self, empty_end_line=True, fail_on_unknown_type=True,
                  get_var=True,
                  counter_inc_func:callable=None,
                  counter_val_func:callable=None):
        """
        Args:
            empty_end_line: bool
            if True an empty end line is output.
        """
        # TODO: very similar to self.addterm, refactor
        if len(self.instrucs) < 6:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing terms.", 19)

        if len(self.instrucs) > 6:
            self.instrucs[4] = " ".join(self.instrucs[4:-2])
            self.instrucs = self.instrucs[:6]

        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)

        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)

        eqloc = self.instrucs[2]

        power = self.instrucs[3]

        if m := match(r".*w(\d*)", power):
            power = m.group(1)

        if power == "":
            power = 1

        if float(power) > float(self.power_max):
            self.power_max = power

        varloc = self.instrucs[5]
        if m := match(r".*\((.*)\).*", varloc):
            varloc = m.group(1)
            if m := match(r"(.*)\(.*\).*", self.instrucs[5]):
                self.instrucs[5] = m.group(1)

        der = self.instrucs[5]  # TODO: is that really the proper index?
        if m := match(r".*\^(.*).*", der):
            der = m.group(1)
        else:
            der = der.count("'")

        varname = self.instrucs[5].replace("'", "")  # TODO: same as above
        if m := match(r"(.*)\^.*", varname):
            varname = m.group(1)

        if isinstance(self, ReadEqParserMulti2D):
            #TODO: should not be done here
            self.varDomainNumber = self.vardomain[varname]
            varloc = varloc.replace('$nr', f'grd({self.varDomainNumber})%nr')

        if get_var:
            self.variable = 0

            for i in range(len(self.varlist)):
                if varname == self.varlist[i]:
                    self.variable = i + 1

            if self.variable == 0:
                self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{varname}" unknown variable.', 13)

        self.instrucs[4] = self.treat_string(self.instrucs[4])

        dm = self.dm
        idm = f"idm({self.domainNumber},{self.varDomainNumber})"
        self.idm = idm
        if self.instrucs[1] == "s":
            counter_inc_func('nasbc')  # self.nasbc += 1
            nasbc = counter_val_func('nasbc')
            self.amat += [self.mywrap(f"      {dm}%asbc({nasbc}) = {self.instrucs[4]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]

            self.send_out(f"      {dm}%asbci(1,{nasbc}) = {power}")
            self.send_out(f"      {dm}%asbci(2,{nasbc}) = {der}")
            self.send_out(f"      {dm}%asbci(3,{nasbc}) = {self.equation}")
            self.send_out(f"      {dm}%asbci(4,{nasbc}) = {self.variable}")
            self.send_out(f"      {dm}%asbci(5,{nasbc}) = {eqloc}")
            self.send_out(f"      {dm}%asbci(6,{nasbc}) = {varloc}")
            if empty_end_line:
                self.send_out("")
        elif self.instrucs[1] == "t":
            counter_inc_func('natbc')  # self.natbc += 1
            natbc = counter_val_func('natbc')
            self.amat += [self.mywrap(f"      {idm}%atbc({self.j_index},{natbc}) = {self.instrucs[4]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]
            assert hasattr(self, 'imat')
            self.send_out(f"      {idm}%atbci(1,{natbc}) = {power}", self.imat)
            self.send_out(f"      {idm}%atbci(2,{natbc}) = {der}", self.imat)
            self.send_out(f"      {idm}%atbci(3,{natbc}) = {self.equation}", self.imat)
            self.send_out(f"      {idm}%atbci(4,{natbc}) = {self.variable}", self.imat)
            self.send_out(f"      {idm}%atbci(5,{natbc}) = {eqloc}", self.imat)
            self.send_out(f"      {idm}%atbci(6,{natbc}) = {varloc}", self.imat)
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i':
                self.send_out(f"      {idm}%atbci(7,{natbc}) = 0", self.imat)
            if empty_end_line:
                self.send_out("", self.imat)
        elif self.instrucs[1] == "tt":
            counter_inc_func('nattbc')  # self.nattbc += 1
            nattbc = counter_val_func('nattbc')
            self.amatt += [self.mywrap(f"      idm({dom_id},{dom_id})%attbc({j_index},{nattbc}) = {self.instrucs[4]}")]
            for i in range(self.nloops):
                self.amatt += ["      enddo"]
            assert hasatttr(self, 'imatt')
            self.send_out(f"      {idm}%attbci(1,{nattbc}) = {power}", self.imatt)
            self.send_out(f"      {idm}%attbci(2,{nattbc}) = {der}", self.imatt)
            self.send_out(f"      {idm}%attbci(3,{nattbc}) = {self.equation}", self.imatt)
            self.send_out(f"      {idm}%attbci(4,{nattbc}) = {self.variable}", self.imatt)
            self.send_out(f"      {idm}%attbci(5,{nattbc}) = {eqloc}", self.imatt)
            self.send_out(f"      {idm}%attbci(6,{nattbc}) = {varloc}", self.imatt)
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i':
                self.send_out(f"      {idm}%attbci(7,{nattbc}) = 0\n",
                              self.imatt)
            if empty_end_line:
                self.send_out("", self.imatt)
        else:
            if fail_on_unknown_type:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type {self.instrucs[1]}.", 16)

        self.prev = self.instrucs[1] + "bc"

    def addtermbci(self, get_var=True,
                   counter_inc_func:callable=None,
                   counter_val_func:callable=None):
        """
        """
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)
        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)

        self.addtermbc(empty_end_line=False, get_var=get_var,
                       counter_inc_func=counter_inc_func,
                       counter_val_func=counter_val_func)
        dm = self.dm
        idm = self.idm
        if self.instrucs[1] == "s":
            nasbc = counter_val_func('nasbc')
            self.send_out(f"      {dm}%asbci(7,{nasbc}) = {int(self.is_cplx)}")
            self.send_out("")
        # TODO: this part could/should be in ReadEqParserMono2D
        idm = self.idm
        if self.instrucs[1] == "t":
            natbc = counter_val_func('natbc')
            self.send_out(f"      {idm}%atbci(7,{natbc}) = {int(self.is_cplx)}", self.imat)
            self.send_out("", self.imat)
        elif self.instrucs[1] == "tt":
            nattbc = counter_val_func('nattbc')
            self.send_out(f"      {idm}%attbci(7,{nattbc}) = {int(self.is_cplx)}", self.imat)
            self.send_out("", self.imat)

    # TODO: the name is a bit cryptic, rather tell what is the treatment
    # documenting the function should be enough
    def treat_string(self, string: str, i_inds="1:nr",
                     fail_on_unknown_type=True,
                     counter_val_func:callable=None):
        self.nloops = 0
        self.i_index = i_inds

        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)

        string.replace("$var", str(self.variable))
        string.replace("$eq", str(self.equation))

        if "$i" in string:
            self.amat += ["      do i=1, {i_inds.split()[-1]}"]
            self.nloops += 1
            self.i_index = "i"

        string = string.replace("$i", "i")

        if "$prev" in string:

            if self.prev == "s":
                nas = counter_val_func('nas')
                string = string.replace("$prev", f"dm(1)%as({nas})")
            elif self.prev == "r":
                nar = counter_val_func('nar')
                string = string.replace("$prev", f"dm(1)%ar({self.i_index}, {nar})")
            elif self.prev == "sbc":
                nasbc = counter_val_func('nasbc')
                string = string.replace("$prev", f"dm(1)%absc({nasbc})")
            elif self.prev == "empty":
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: instruction on non-existent term\n", 14)
            else:
                if fail_on_unknown_type:
                    self.fatal_err(f"Error on line {self.in_nl[self.nl]}: Programming error in readeq\n", 15)

        return string

    def callsub(self, empty_end_line=False, outlst=None,
                get_var=True,
                counter_inc_func:callable=None,
                counter_val_func:callable=None):
        """
        Args:
            empty_end_line: bool
            if True an empty end line is output.
        """
        # TODO: very similar to self.addterm, refactor
        if len(self.instrucs) < 5:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing terms.", 18)

        if len(self.instrucs) > 5:
            self.instrucs[3] = " ".join(self.instrucs[3:-1])
            self.instrucs = self.instrucs[:5]

        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)
        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)

        power = self.instrucs[2]

        if m := match(r".*w(\d*)", power):
            power = m.group(1)

        if power == "":
            power = 1

        if float(power) > float(self.power_max):
            self.power_max = power

        der = self.instrucs[4]
        if m := match(r".*\^(.*)", der):
            der = m.group(1)
        else:
            der = der.count("'")

        varname = self.instrucs[4].replace("'", "")
        if m := match(r"(.*)\^.*", varname):
            varname = m.group(1)

        if isinstance(self, ReadEqParserMulti2D):
            self.varDomainNumber = self.vardomain[varname]

        if get_var:
            self.variable = 0

            for i in range(len(self.varlist)):
                if varname == self.varlist[i]:
                    self.variable = i + 1

            if self.variable == 0:
                self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{varname}" unknown variable.', 13)

        self.instrucs[3] = self.treat_string(self.instrucs[3])

        dm = self.dm = f"dm({self.domainNumber})"
        if self.instrucs[1] == "s":
            counter_inc_func('nas')  # self.nas += 1
            nas = counter_val_func('nas')
            self.instrucs[3] = self.instrucs[3].replace("$a", f"as(nas)")  # line not in self.addterm
            # self.amat += self.mywrap(f"      dm({dom_id})%as({self.nas}) = {self.instrucs[3]}")
            # replace commented line above (from add term)
            self.amat += [self.mywrap(f"      call {self.instrucs[3]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]

            self.send_out(f"      asi(1,{nas}) = {power}\n", outlst)
            self.send_out(f"      asi(2,{nas}) = {der}\n", outlst)
            self.send_out(f"      asi(3,{nas}) = {self.equation}\n", outlst)
            self.send_out(f"      asi(4,{nas}) = {self.variable}\n", outlst)
        elif self.instrucs[1] == "r":
            counter_inc_func('nar')  # self.nar += 1
            nar = counter_val_func('nar')
            # self.amat += self.mywrap(f"      dm({dom_id})%ar({self.i_index},{self.nar}) = {string}")
            # replaced by:
            self.instrucs[3] = self.instrucs[3].replace(
                "$a", f"{dm}%ar({self.i_index},{nar})"
            )  # line not in self.addterm
            self.amat += [self.mywrap(f"      call {self.instrucs[3]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]
            self.send_out(f"      {dm}%ari(1,{nar}) = {power}", outlst)
            self.send_out(f"      {dm}%ari(2,{nar}) = {der}", outlst)
            self.send_out(f"      {dm}%ari(3,{nar}) = {self.equation}", outlst)
            self.send_out(f"      {dm}%ari(4,{nar}) = {self.variable}", outlst)
        elif self.instrucs[1] == "rt":
            counter_inc_func('nart')  # self.nart += 1
            nart = counter_val_func('nart')
            # self.amat += self.mywrap(f"      dm({dom_id})%ar({self.i_index},{nar}) = {string}")
            # replaced by:
            self.instrucs[3] = self.instrucs[3].replace(
                "$a", f"dm({dom_id})%art({self.i_index},{self.j_index},{nart})"
            )  # line not in self.addterm
            self.amat += [self.mywrap(f"      call {self.instrucs[3]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]
            self.send_out(f"      {dm}%arti(1,{nart}) = {power}", outlst)
            self.send_out(f"      {dm}%arti(2,{nart}) = {der}", outlst)
            self.send_out(f"      {dm}%arti(3,{nart}) = {self.equation}", outlst)
            self.send_out(f"      {dm}%arti(4,{nart}) = {self.variable}", outlst)
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i':
                self.send_out(f"      {dm}%arti(7,{nart}) = 0", outlst)
        elif self.instrucs[1] == "rtt":
            counter_inc_func('nartt')  # self.nartt += 1
            nartt = counter_val_func('nartt')
            # self.amat += self.mywrap(f"      dm({dom_id})%ar({self.i_index},{nar}) = {string}")
            # replaced by:
            self.instrucs[3] = self.instrucs[3].replace(
                "$a",
                f"{dm}%artt({self.i_index},{self.j_index},{self.jj_index},{nartt})"
            )  # line not in self.addterm
            self.amat += [self.mywrap(f"      call {self.instrucs[3]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]
            self.send_out(f"      {dm}%artti(1,{nartt}) = {power}", outlst)
            self.send_out(f"      {dm}%artti(2,{nartt}) = {der}", outlst)
            self.send_out(f"      {dm}%artti(3,{nartt}) = {self.equation}", outlst)
            self.send_out(f"      {dm}%artti(4,{nartt}) = {self.variable}", outlst)
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i':
                self.send_out(f"      {dm}%artti(7,{nartt}) = 0", outlst)
                self.send_out("", outlst)
        else:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type.", 16)

        if empty_end_line:
            self.send_out("")

        self.prev = self.instrucs[1]

    def callsubi(self, empty_end_line=False, outlst=None,
                 get_var=True,
                 counter_inc_func:callable=None,
                 counter_val_func:callable=None):

        dm = self.dm
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)
        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)
        self.callsub(empty_end_line=empty_end_line, outlst=outlst,
                     get_var=get_var,
                     counter_inc_func=counter_inc_func,
                     counter_val_func=counter_val_func)
        if self.instrucs[1] == "s":
            nas = counter_val_func('nas')
            self.send_out(f"      {dm}%asi(7,{nas}) = {int(self.is_cplx)}")
        elif self.instrucs[1] == "r":
            nar = counter_val_func('nar')
            self.send_out(f"      {dm}%ari(7,{nar}) = {int(self.is_cplx)}")

    def callsubbc(self, empty_end_line=True,
                  get_var=True,
                  counter_inc_func:callable=None,
                  counter_val_func:callable=None):
        """
        Args:
            empty_end_line: bool
            if True an empty end line is output.
        """
        dm = self.dm
        idm = self.idm
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)
        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)
        # TODO: very similar to self.addtermbc, refactor
        if len(self.instrucs) < 6:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing terms.", 17)

        if len(self.instrucs) > 6:
            self.instrucs[4] = " ".join(self.instrucs[4:-2])
            self.instrucs = self.instrucs[:6]

        eqloc = self.instrucs[2]

        power = self.instrucs[3]

        if m := match(r".*w(\d*)", power):
            power = m.group(1)

        if power == "":
            power = 1

        if float(power) > float(self.power_max):
            self.power_max = power

        varloc = self.instrucs[5]
        if m := match(r".*\((.*)\).*", varloc):
            varloc = m.group(1)
            if m := match(r"(.*)\(.*\).*", self.instrucs[5]):
                self.instrucs[5] = m.group(1)

        der = self.instrucs[5]  # TODO: is that really the proper index?
        if m := match(r".*\^(.*)", der):
            der = m.group(1)
        else:
            der = der.count("'")

        varname = self.instrucs[5].replace("'", "")  # TODO: same as above
        if m := match(r"(.*)\^.*", varname):
            varname = m.group(1)

        if isinstance(self, ReadEqParserMulti2D):
            #TODO: should not be done here
            self.varDomainNumber = self.vardomain[varname]
            varloc = varloc.replace('$nr', f'grd({self.varDomainNumber})%nr')

        if get_var:
            self.variable = 0

            for i in range(len(self.varlist)):
                if varname == self.varlist[i]:
                    self.variable = i + 1

            if self.variable == 0:
                self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{varname}" unknown variable.', 13)

        self.instrucs[4] = self.treat_string(self.instrucs[4])

        self.idm = idm = f"idm({self.domainNumber},{self.varDomainNumber})"

        if self.instrucs[1] == "s":
            nasbc = counter_inc_func('nasbc')
            # self.amat += self.mywrap(f"      dm(1)%asbc({counter_val_func('nasbc')}) = {self.instrucs[3]}")
            # line from self.addtermbc replaced by two lines:
            self.instrucs[4] = self.instrucs[4].replace("$a", f"dm(1)%asbc({counter_val_func('nasbc')})")
            self.amat += [self.mywrap(f"       call {self.instrucs[4]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]

            self.send_out(f"      {dm}%asbci(1,{counter_val_func('nasbc')}) = {power}\n")
            self.send_out(f"      {dm}%asbci(2,{counter_val_func('nasbc')}) = {der}\n")
            self.send_out(f"      {dm}%asbci(3,{counter_val_func('nasbc')}) = {self.equation}\n")
            self.send_out(f"      {dm}%asbci(4,{counter_val_func('nasbc')}) = {self.variable}\n")
            self.send_out(f"      {dm}%asbci(5,{counter_val_func('nasbc')}) = {eqloc}\n")
            self.send_out(f"      {dm}%asbci(6,{counter_val_func('nasbc')}) = {varloc}\n")
            if empty_end_line:
                self.send_out("")
        elif self.instrucs[1] == "t":
            natbc = counter_inc_func('natbc')
            # self.amat += self.mywrap(f"      dm(1)%atbc({counter_val_func('natbc')}) = {self.instrucs[3]}")
            # line from self.addtermbc replaced by two lines:
            self.instrucs[4] = self.instrucs[4].replace("$a",
                                                        f"atbc({self.j_index},{counter_val_func('natbc')})")
            self.amat += [self.mywrap(f"       call {self.instrucs[4]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]

            self.send_out(f"      {idm}%atbci(1,{counter_val_func('natbc')}) = {power}\n", self.imat)
            self.send_out(f"      {idm}%atbci(2,{counter_val_func('natbc')}) = {der}\n", self.imat)
            self.send_out(f"      {idm}%atbci(3,{counter_val_func('natbc')}) = {self.equation}\n", self.imat)
            self.send_out(f"      {idm}%atbci(4,{counter_val_func('natbc')}) = {self.variable}\n", self.imat)
            self.send_out(f"      {idm}%atbci(5,{counter_val_func('natbc')}) = {eqloc}\n", self.imat)
            self.send_out(f"      {idm}%atbci(6,{counter_val_func('natbc')}) = {varloc}\n", self.imat)
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i':
                self.send_out(f"      {idm}%atbci(7,{counter_val_func('natbc')}) = 0\n", self.imat)
            self.send_out(f"", self.imat)
            if empty_end_line:
                self.send_out("")
        elif self.instrucs[1] == "tt":
            nattbc = counter_inc_func('nattbc')
            # self.amatt += self.mywrap(f"      dm(1)%attbc({counter_val_func('nattbc')}) = {self.instrucs[3]}")
            # line from self.addtermbc replaced by two lines:
            self.instrucs[4] = self.instrucs[4].replace("$a",
                                                        f"idm({self.domainNumber},{self.varDomainNumber})%attbc({self.j_index},{self.jj_index},{counter_val_func('nattbc')})")
            self.amat += [self.mywrap(f"      call {self.instrucs[4]}")]
            for i in range(self.nloops):
                self.amat += ["      enddo"]

            self.send_out(f"      {idm}%attbci(1,{counter_val_func('nattbc')}) = {power}\n", self.imat)
            self.send_out(f"      {idm}%attbci(2,{counter_val_func('nattbc')}) = {der}\n", self.imat)
            self.send_out(f"      {idm}%attbci(3,{counter_val_func('nattbc')}) = {self.equation}\n", self.imat)
            self.send_out(f"      {idm}%attbci(4,{counter_val_func('nattbc')}) = {self.variable}\n", self.imat)
            self.send_out(f"      {idm}%attbci(5,{counter_val_func('nattbc')}) = {eqloc}\n", self.imat)
            self.send_out(f"      {idm}%attbci(6,{counter_val_func('nattbc')}) = {varloc}\n", self.imat)
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i':
                self.send_out(f"      {idm}%attbci(7,{counter_val_func('nattbc')}) = 0\n", self.imat)
            if empty_end_line:
                self.send_out("")
        else:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type.", 16)

        self.prev = self.instrucs[1] + "bc"

    def callsubbci(self, get_var=True,
                  counter_inc_func:callable=None,
                  counter_val_func:callable=None):
        """
        """
        dm = self.dm
        idm = self.idm
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)
        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)
        self.callsubbc(empty_end_line=False, get_var=get_var, counter_inc_func=counter_inc_func,
                      counter_val_func=counter_val_func)
        if self.instrucs[1] == "s":
            nasbc = counter_val_func('nasbc')
            self.send_out(f"      {dm}%asbci(7,{nasbc}) = {int(self.is_cplx)}")
            self.send_out("")
        # TODO: this part could/should be in ReadEqParserMono2D
        elif self.instrucs[1] == "t":
            natbc = counter_val_func('natbc')
            self.send_out(f"      {idm}%atbci(7,{natbc}) = {int(self.is_cplx)}", self.imat)
            self.send_out("", self.imat)
        elif self.instrucs[1] == "tt":
            nattbc = counter_val_func('nattbc')
            self.send_out(f"      {idm}%attbci(7,{nattbc}) = {int(self.is_cplx)}", self.imat)
            self.send_out("", self.imat)

    def addinput(self):
        if len(self.instrucs) < 3:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing terms.", 20)
        if len(self.instrucs) > 3:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: too many terms.", 21)

        self.inputs += [self.instrucs[1]]
        self.inputs_format += [self.instrucs[2]]

        if match(".*[iI].*", self.instrucs[2]):
            datatype = "integer"
            value = "0"
        elif match(r".*[fFeEdD].*", self.instrucs[2]):
            datatype = "double precision"
            value = "0d0"
        elif match(r".*[aA].*", self.instrucs[2]):
            numchar = self.instrucs[2]
            if m := match(r".*[aA](.*)", numchar):
                numchar = m.group(1)
            else:
                assert False, "error in char format input"
            datatype = f"character*({numchar})"
            value = '" "'
        else:
            self.fatal_err(f"Unrecognised format specifier {self.instrucs[2]} on line {self.in_nl[self.nl]}.", 22)

        self.inputs_datatype += [datatype]
        self.inputs_value += [value]

    def writeinstruction(self):
        if len(self.instrucs) < 2:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing arguments.",
                           ReadEqError.INSTRUC_MISSING_ARGS)
        self.instrucs[1] = " ".join(self.instrucs[1:])
        if len(self.instrucs) > 2:
            self.instrucs = self.instrucs[:2]

        self.instrucs[1] = self.treat_string(self.instrucs[1])
        self.amat += [self.mywrap(f"      {self.instrucs[1]}")]
        for _ in range(self.nloops):
            self.amat += [self.mywrap("     enddo")]

    def suppressvar(self, var_doms=None, var_indices=None):
        if len(self.instrucs) < 2:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing arguments", 23)

        if var_indices is None:
            var_indices = []
            var_doms = []
            use_caller_dom_vars = False
        else:
            use_caller_dom_vars = True
        for varname in self.instrucs[1:]:
            if varname in self.varlist:
                if not use_caller_dom_vars:
                    var_indices  += [self.varlist.index(varname) + 1]
                    var_doms += [1]
            else:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: {varname} unknown variable.", 24)

        for var_dom, var_ind in zip(var_doms, var_indices):
                self.send_out(f"      dm({var_dom})%var_keep({var_ind}) = .false.")


    def writetail(self):
        self.send_out(f"      power_max={self.power_max}\n\n")
        self.send_out("      a_dim = nr*dm(1)%nvar\n")
        self.send_out("      dm(1)%d_dim = a_dim\n")
        self.send_out("      print*,'Dimension of problem: ',a_dim\n\n")
        self.send_out("      call find_der_range(der_min,der_max)\n")
        self.send_out(
            "      if (allocated(dm(1)%vect_der)) deallocate(dm(1)%vect_der)\n",
        )
        self.send_out("      allocate(dm(1)%vect_der(a_dim, der_min:der_max))\n\n")
        self.send_out("      if (.not.first_dmat) call clear_derive(dmat(1))\n")
        self.send_out(
            "      call init_derive(dmat(1),r,nr,der_max,der_min,orderFD,dertype)\n",
        )
        self.send_out("      first_dmat = .false.\n\n")
        self.send_out("      call init_var_list()\n")
        for r in self.amat:
            self.send_out(f"{r}")
        self.send_out("      end subroutine init_a\n")

    def writeinputs(self, input_fp: str, eq_ndim=1,
                    before_init_inputs:callable=None,
                    before_printing_inputs:callable=None,
                    before_printing_format:callable=None,
                    use_grid_mod_decl="use mod_grid",
                    use_bin_subroutines=False):
        with open(input_fp, 'w+') as inputs_f90:
            self.inputs_f90 = inputs_f90
            assert eq_ndim in [1, 2], 'eq_ndim can only be 1 or 2'
            print("      module inputs\n", file=inputs_f90)
            print("      use iso_c_binding", file=inputs_f90)
            print(f"      {use_grid_mod_decl}", file=inputs_f90)

            if eq_ndim == 1:
                print("      integer, parameter :: lres = 1", file=inputs_f90)

            for inp, in_type in zip(self.inputs, self.inputs_datatype):
                print(f"      {in_type}, save :: {inp}", file=inputs_f90)

            if eq_ndim == 2:
                # TODO: no reason to limit that to 2D equations
                for def_, def_type in zip(self.defs, self.defs_type):
                    print(f"      {def_type}, save :: {def_}", file=inputs_f90)

            if len(self.stamp) > 0:
                print(
                    f"      character*({len(self.stamp)}), parameter :: stamp = & ",
                    file=inputs_f90,
                )
                print(f'       "{self.stamp}"', file=inputs_f90)

            ndoms = self.ndomains if hasattr(self, 'ndomains') else 1
            print("contains", file=inputs_f90)
            print('!'+("-"*60)+'', file=inputs_f90)
            print("      subroutine init_default()\n", file=inputs_f90)
            print(f"      call init_grid({ndoms})",
                  file=inputs_f90)
            print("      end subroutine init_default\n", file=inputs_f90)
            print('!'+("-"*60)+'', file=inputs_f90)
            print("      subroutine read_inputs(dati)\n", file=inputs_f90)
            print("      use mgetpar", file=inputs_f90)
            print("      implicit none\n", file=inputs_f90)
            print("      character(len=*), intent(in) :: dati", file=inputs_f90)
            if eq_ndim == 2:
                print(f"      call init_grid({ndoms})", file=inputs_f90)

            print("      call read_file(trim(dati))", file=inputs_f90)
            if eq_ndim == 1:
                print('      nr = fetch(\'nr\',0)', file=inputs_f90)
            else: # eq_ndim == 2
                if before_init_inputs is not None:
                    before_init_inputs(inputs_f90)
                else:
                    print('      grd(1)%nr = fetch(\'nr\',0)', file=inputs_f90)
                print('      nt = fetch(\'nt\',0)', file=inputs_f90)

            for inp, in_val in zip(self.inputs, self.inputs_value):
                print(f'      {inp} = fetch(\'{inp}\',{in_val})', file=inputs_f90)

            print("      end subroutine", file=inputs_f90)
            print('!'+("-"*60)+'', file=inputs_f90)
            print("      subroutine write_inputs(iu)\n", file=inputs_f90)
            print("      implicit none\n", file=inputs_f90)
            print("      integer iu\n", file=inputs_f90)
            print("      write(iu,101) &", file=inputs_f90)
            if eq_ndim == 1:
                print(
                    "          nr, & ! this corresponds to nr+1 when using postvecp ",
                    file=inputs_f90,
                )
            else: # eq_ndim == 2
                if before_printing_inputs is not None:
                    before_printing_inputs(inputs_f90)
                else:
                    print(
                        "          grd(1)%nr, & ! this corresponds to nr+1 when using postvecp ",
                        file=inputs_f90,
                    )
                print("          nt, &", file=inputs_f90)

            for i, (inp, in_format) in enumerate(zip(self.inputs, self.inputs_format)):
                end = ", &" if i < len(self.inputs) - 1 else ""
                if match(".*[aA].*", in_format):
                    print(f"          trim({inp}){end}", file=inputs_f90)
                else:
                    print(f"          {inp}{end}", file=inputs_f90)

            print("101   format( &", file=inputs_f90)
            if eq_ndim == 1:
                print("          '  nr=',I4, &", file=inputs_f90)
            else: # eq_ndim == 2
                if before_printing_format is not None:
                    before_printing_format(inputs_f90)
                else:
                    print("          '  grd(1)%nr=',I4, &", file=inputs_f90)
                print("          '  nt=',I3, &", file=inputs_f90)

            for i, (inp, in_format) in enumerate(zip(self.inputs, self.inputs_format)):
                end = ", &" if i < len(self.inputs) - 1 else ")"
                if match(".*[aA].*", in_format):
                    print(f"          '  {inp}=',A{end}", file=inputs_f90)
                else:
                    print(f"          '  {inp}=',{in_format}{end}", file=inputs_f90)

            print("      end subroutine", file=inputs_f90)
            print('!'+("-"*60)+'', file=inputs_f90)

            if use_bin_subroutines:
                print("      subroutine write_inputs_bin(iu)\n", file=inputs_f90)
                print("      implicit none\n", file=inputs_f90)
                print("      integer iu", file=inputs_f90)
                print("      character*(10240) str\n", file=inputs_f90)
                print("      write(str,101) &", file=inputs_f90)
                # TODO: multi 2D
                print("          grd(1)%nr, &", file=inputs_f90)
                print("          nt, &", file=inputs_f90)

                for i, (inp, in_format) in enumerate(zip(self.inputs, self.inputs_format)):
                    end = ", &" if i < len(self.inputs) - 1 else ""
                    if match(".*[aA].*", in_format):
                        print(f"          trim({inp}){end}", file=inputs_f90)
                    else:
                        print(f"          {inp}{end}", file=inputs_f90)

                print("101   format( &", file=inputs_f90)
                print("          '  nr=',I4, &", file=inputs_f90)
                print("          '  nt=',I3, &", file=inputs_f90)

                for i, (inp, in_format) in enumerate(zip(self.inputs, self.inputs_format)):
                    end = ", &" if i < len(self.inputs) - 1 else ",10240X)"
                    if match(".*[aA].*", in_format):
                        print(f"          '  {inp}=',A{end}", file=inputs_f90)
                    else:
                        print(f"          '  {inp}=',{in_format}{end}", file=inputs_f90)

                print("      write(iu) len(trim(str)),trim(str)", file=inputs_f90)
                print("      if (len(trim(str)).gt.10220) then", file=inputs_f90)
                print("        print*,'Warning: itemlist may have been truncated'", file=inputs_f90)
                print("      endif\n", file=inputs_f90)
                print("      end subroutine", file=inputs_f90)
                print('!'+("-"*60)+'', file=inputs_f90)

            print("      subroutine write_stamp(iu)\n", file=inputs_f90)
            print("      implicit none\n", file=inputs_f90)
            print("      integer iu\n", file=inputs_f90)
            print(
                f'      write(iu,\'("stamp = ",a{len(self.stamp)})\') stamp', file=inputs_f90
            )
            print("      end subroutine", file=inputs_f90)
            print('!'+("-"*60)+'', file=inputs_f90)

            if use_bin_subroutines:
                print("      subroutine write_stamp_bin(iu)\n", file=inputs_f90)
                print("      implicit none\n", file=inputs_f90)
                print("      integer iu, lngth\n", file=inputs_f90)
                print(f"      lngth = {len(self.stamp)}", file=inputs_f90)
                print("      write(iu) lngth, stamp", file=inputs_f90)
                print("      end subroutine", file=inputs_f90)

                print('!'+("-"*60)+'', file=inputs_f90)
            print("      end module", file=inputs_f90)
        self.inputs_f90 = None

    def addmacro(self):
        """
        Parses macro command in equation file.
        This is a basic replacement of variable occurrences by its value.
        """
        if len(self.instrucs) < 3:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing terms.", 9)
        macro = self.instrucs[1]
        macro_rep = " ".join(self.instrucs[2:])
        for i in range(self.nl - 1, len(self.in_lines)):
            self.in_lines[i] = self.in_lines[i].replace(macro, macro_rep)

    def expand_doloop(self):
        """
        Parses do-enddo instructions.
        Expand loops into equivalent sequence of instructions.
        """
        # check number of arguments is OK (at least 4)
        if len(self.instrucs) < 4:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: missing terms.", 9)

        # get loop start, stop and optional increment
        itvar = self.instrucs[1]
        start = self.instrucs[2]
        stop = self.instrucs[3]
        # incr is 1 by default
        if len(self.instrucs) > 4:
            incr = self.instrucs[4]
        else:
            incr = 1

        # check start, stop and optional incr are integers
        for v in [start, stop, incr]:
            if not match(r'^-?\d+$', str(v)):
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: non-integer do-loop"
                               " arguments", ReadEqError.NONINT_DOLOOP_ARG)

        # once checked convert them to int
        start = int(start)
        stop = int(stop)
        incr = int(incr)


        # check loop stopping criterion
        if incr == 0:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: infinite loop detected"
                           " (zero increment)", ReadEqError.INFINITE_DOLOOP)

        # prevent no-iteration loop
        nites = ceil((stop - start + 1) / incr)  # stop-iteration is included
        if nites < 1:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: do-loop without"
                           " iteration (check start, stop, and increment arguments).",
                           ReadEqError.NOITE_DOLOOP)

        # check (nested) loops are well-formed
        # get current 'do' and 'enddo' lines
        znl = self.nl - 1 # zero-base index of 'do' line
        zdo_lines = [znl] # zero-base index of all nested do-s including this one
        zenddo_lines = [] # zero-base index of enddos
        full_loop_block = False
        for il, line in enumerate(self.in_lines[znl + 1:]):
            if match(r'^do\s*.*', line):
                zdo_lines += [znl + 1 + il]
            elif match('^enddo$', line):
                zenddo_lines += [znl + 1 + il]
            if len(zdo_lines) == len(zenddo_lines):
                full_loop_block = True
                break

        if not full_loop_block:
            fatal_err('Error on line {self.in_nl[self.nl]}: unfinished do-loop.',
                      ReadEqError.ILLFORMED_DO_LOOP)

        # number of lines/instructions in do-loop block
        loop_ni = zenddo_lines[-1] - zdo_lines[0] - 1

        # update map of current line in expanded lines
        # (take care that self.in_nl is one-base indexed)
        # to corresponding line in input equation file
        # previous line map does not change
        new_in_nl = self.in_nl[0:self.nl] # current 'do 'is at line in_nl[self.nl]
        # inner lines of the current loop are repeated
        # the current "do" line will be removed after expansion (so the line is skipped)
        for _ in range(nites):
            new_in_nl = new_in_nl + self.in_nl[self.nl + 1:self.nl + 1 + loop_ni]
        # map for the lines that follow the loop (the enddo line is ignored
        # because removed after expansion)
        new_in_nl = new_in_nl + self.in_nl[self.nl + loop_ni + 2:]

        # check the new number of lines is consistent with the loop expansion
        assert len(new_in_nl) == len(self.in_nl) + (nites - 1) * loop_ni - 2
        # a number of (nites -1) is accounted because the loop of original src
        # obviously contains loop_ni instructions of the iteration written
        # to define the loop

        # expand loop into self.in_lines:
        # copy inner lines and remove them from self.in_lines
        inner_lines = list(self.in_lines[zdo_lines[0]+1:zenddo_lines[-1]])
        self.in_lines = (self.in_lines[:zdo_lines[0]] +
                         self.in_lines[min(len(self.in_lines)-1,zenddo_lines[-1]+1):])
        # for each inner line of the loop
        # replace loop counter by its iteration value
        # with ++, -- shortcut and i+-val or val+-val
        insert_index = zdo_lines[0]
        for counter in range(start, stop + 1, incr):  # iteration stop is included
            for inner_line in inner_lines:
                new_inner_line = str(inner_line)
                while m := match(rf'(.*){itvar}\+\+(.*)', new_inner_line):
                    new_inner_line = m.group(1) + f'{counter + 1}' + m.group(2)
                while m := match(rf'(.*){itvar}--(.*)', new_inner_line):
                    new_inner_line = m.group(1) + f'{counter - 1}' + m.group(2)
                while m := match(rf'(.*){itvar}\+(\d+)\D(.*)|(.*)\D(\d+)\+{itvar}(.*)',
                      new_inner_line):
                    new_inner_line = m.group(1) + f'{counter + int(m.group(2))}' + m.group(3)
                while m := match(rf'(.*){itvar}-(\d+)\D(.*)', new_inner_line):
                    new_inner_line = m.group(1) + f'{counter - int(m.group(2))}' + m.group(3)
                while m := match(rf'(.*)\D(\d+)-{itvar}(.*)', new_inner_line):
                    new_inner_line = m.group(1) + f'{int(m.group(2)) - counter}' + m.group(3)
                while m := match(rf'(.*){itvar}(.*)', new_inner_line):
                    new_inner_line = m.group(1) + f'{counter}' + m.group(2)
                # insert expanded line
                new_inner_line = new_inner_line.strip()  # avoid '\n\n'
                self.in_lines.insert(insert_index, new_inner_line+'\n')
                insert_index += 1

        # check new number of lines according to new_in_nl
        assert len(self.in_lines) == len(new_in_nl) - 1
        # -1 is because new_in_nl[i] works in one-base index
        # and it is made in a way that new_in_nl[0] serves nothing
        # because there is no line 0, we start at line 1
        self.in_nl = new_in_nl


    def is_complex(self, _input: str):
        """
        Returns true if _input equation file contains instructions matching complex
        scalar type.
        """
        with open(self._input) as in_stream:
            in_lines = in_stream.read()
            for instruct in ['termi', 'subi', 'termbci', 'subbci']:
                if instruct in in_lines:
                    return True
        return False

    @staticmethod
    def _counter_inc_func(obj, attr: str):
        obj.__setattr__(attr, obj.__getattribute__(attr) + 1)

    @staticmethod
    def _counter_val_func(obj, attr: str):
        return obj.__getattribute__(attr)

class ReadEqParserMono(ReadEqParser):

    def setdefault(self):
        super().setdefault()
        self.nar = 0
        self.nas = 0
        self.nasbc = 0
        in_offset = 2
        if self.is_cplx:
            in_offset += 1
        # add mattype field
        self.inputs.insert(in_offset, "mattype")
        self.inputs_datatype.insert(in_offset, "character*(4)")
        self.inputs_format.insert(in_offset, "A4")
        self.inputs_value.insert(in_offset, "'FULL'")
        # add dertype field
        self.inputs.insert(in_offset + 1, "dertype")
        self.inputs_datatype.insert(in_offset + 1, "character*(4)")
        self.inputs_format.insert(in_offset + 1, "A4")
        self.inputs_value.insert(in_offset + 1, "'CHEB'")
        # add orderFD field
        self.inputs.insert(in_offset + 2, "orderFD")
        self.inputs_datatype.insert(in_offset + 2, "integer")
        self.inputs_format.insert(in_offset + 2, "I2")
        self.inputs_value.insert(in_offset + 2, "2")

class ReadEqParserMono1D(ReadEqParserMono):

    def parser_type(self):
        return __class__

    def writeinputs(self, input_fp: str, eq_ndim=1):
        # I see no specific reason for these differences
        # but for now we keep it the same as in perl version
        # TODO: uniform it later
        if self.is_cplx:
            use_grid_mod_decl="use mod_grid, only: nr, init_grid"
        else:
            use_grid_mod_decl="use mod_grid, only: nr, r, init_grid"
        super().writeinputs(input_fp, use_grid_mod_decl=use_grid_mod_decl,
                            eq_ndim=eq_ndim)

class ReadEqParserMono2D(ReadEqParserMono):

    def __init__(self, argv, output='matrices.inc', out_mode='printing', ncols=80):
        super(ReadEqParserMono2D, self).__init__(argv, output=output, out_mode='buffering', ncols=ncols)

    def define_instrucs(self):
        """
        Define the functions to parse each one of available equation file instructions.
        """
        super().define_instrucs()
        self.instruc_funcs['leq'] = lambda: self.setleq()
        self.instruc_funcs['lvar'] = lambda: self.setlvar()

    def setleq(self, eq_dom=None, eq_id=None):
        """
        """
        if len(self.instrucs) < 3:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: many terms missing.", 25)
        if len(self.instrucs) > 3:
            self.instrucs[2] = ".".join(self.instrucs[2:-2])
        if eq_id is None or eq_dom is None:
            self.equation = 0
            for i in range(len(self.eqlist)):
                if self.instrucs[1] == self.eqlist[i]:
                    self.equation = i + 1
            if self.equation == 0:
                self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{self.instrucs[1]}"'
                               ' unknown equation.', 26)
            eq_dom = 1
            eq_id = self.equation

        self.send_out(f"      dm({eq_dom})%leq(1,{eq_id}) = {self.instrucs[2]}")
        self.send_out("      do j=2,nt")
        self.send_out(f"        dm({eq_dom})%leq(j,{eq_id}) = {self.lincr}"
              f" + dm({eq_dom})%leq(j-1,{eq_id})")
        self.send_out("      enddo")

    def setlvar(self, var_id=None):
        """
        """
        if len(self.instrucs) < 3:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: many terms missing.", 27)
        if len(self.instrucs) > 3:
            self.instrucs[2] = ".".join(self.instrucs[2:-2])

        if var_id is None:
            self.variable = 0
            for i in range(len(self.varlist)):
                if self.instrucs[1] == self.varlist[i]:
                    self.variable = i + 1
            if self.variable == 0:
                self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{self.instrucs[1]}"'
                               ' unknown variable.', 28)
            var_dom = 1
            var_id = self.variable

        dm = self.dm
        self.send_out(f"      {dm}%lvar(1,{var_id}) = {self.instrucs[2]}")
        self.send_out("      do j=2,nt")
        self.send_out(f"        {dm}%lvar(j,{var_id}) = {self.lincr}"
              f" + {dm}%lvar(j-1,{var_id})")
        self.send_out("      enddo")

    def setdefault(self):
        """
        """
        super().setdefault()
        self.inputs += ['init_rgrid_sub']
        self.inputs_format += ['A2']
        self.inputs_datatype += ['character*(512)']
        self.inputs_value += ["'SIMPLE'"]
        self.nart = 0
        self.nartt = 0
        self.natbc = 0
        self.nattbc = 0

        self.imat = []  # this contains the instructions which specify the indices in
                        # the asi, arti, artti, atbci and attbci matrices
        self.asub = []  # this contains the calls to the subroutines which calculate the
                        # coupling coefficients
        self.isub = []  # this contains the calls to the subroutine which specify the
                        # indices in the asi, arti, artti, atbci and attbci matrices
        self.current_eq = 'no_eq'
        self.asub += [f"      call eq_{self.current_eq}()"]
        # amat intialized empty in parent
        self.amat += ['!'+("-"*60)+'']
        self.amat += ['! Preliminary instructions']
        self.amat += ['!'+("-"*60)+'']
        self.amat += [f'      subroutine eq_{self.current_eq}()']
        self.amat += ['      use model']
        self.amat += ['      use inputs']
        self.amat += ['      use integrales']
        self.amat += ['      implicit none']
        self.amat += ['      integer i, j, jj']

    def countterm(self, counter_inc_func: callable=None):
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)

        # TODO: very similar to parent, refactor
        if self.instrucs[0] in ["term", "sub", "termi", "subi"]:
            if len(self.instrucs) < 2:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: many terms missing.", 4)
            if self.instrucs[1] == "s":
#                self.nas += 1
                counter_inc_func('nas')
            elif self.instrucs[1] == "rt":
#                self.nart += 1
                counter_inc_func('nart')
            elif self.instrucs[1] == "rtt":
#                self.nartt += 1
                counter_inc_func('nartt')
            else:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type.", 5)
        elif self.instrucs[0] in ["termbc", "subbc", "termbci", "subbci"]:
            if len(self.instrucs) < 2:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: many terms missing.", 4)
            if self.instrucs[1] == "t":
#                self.natbc += 1
                counter_inc_func('natbc')
            elif self.instrucs[1] == "tt":
#                self.nattbc += 1
                counter_inc_func('nattbc')
            else:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type.", 5)
        else:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: programming error in readeq.", 6)

    def writehead(self):
        asi_ari_size = 7 if self.is_cplx else 4
        asbci_size = 7 if self.is_cplx else 6

        self.send_out("      subroutine init_a()")
        self.send_out("      use model")
        self.send_out("      use inputs")
        self.send_out("      use integrales")
        self.send_out("      implicit none")
        self.send_out("      integer i,j,jj,der_min,der_max\n")
#        self.send_out("      if (allocated(dm)) deallocate(dm)")
#        self.send_out("      if (allocated(dmat)) deallocate(dmat)")
#        self.send_out("      allocate(dm(1))")
#        self.send_out("      allocate(dmat(1))")
        # NOTE: declarations with defs_types are made in writeinputs
        for i in range(len(self.defs)):
            self.send_out(self.mywrap(f"      {self.defs[i]} = {self.defs_value[i]}"))
        self.send_out("")
        self.send_out("      grd(1)%mattype = mattype")
        self.send_out("      nr => grd(1)%nr")
        self.send_out("      if (allocated(dm)) then")
        self.send_out("          call clear_all()\n")
        self.send_out("      endif\n")
        self.send_out("      allocate(dm(1))")
        self.send_out("      allocate(dmat(1))")
        self.send_out("      allocate(idm(1, 1))\n")
        self.send_out("      dm(1)%offset=0")
        self.send_out(f"      dm(1)%nas={self.nas}")
        self.send_out(f"      dm(1)%nart={self.nart}")
        self.send_out(f"      dm(1)%nartt={self.nartt}")
        self.send_out(f"      idm(1,1)%natbc={self.natbc}")
        self.send_out(f"      idm(1,1)%nattbc={self.nattbc}")
        self.send_out(f"allocate(dm(1)%as(dm(1)%nas),dm(1)%asi({asi_ari_size},dm(1)%nas))")
        self.send_out("      dm(1)%as = 0d0; dm(1)%asi=0")
        self.send_out("      "
              f"allocate(dm(1)%art(grd(1)%nr,nt,dm(1)%nart),dm(1)%arti({asi_ari_size},dm(1)%nart))")
        self.send_out("      dm(1)%art = 0d0; dm(1)%arti=0")
        self.send_out("      "
              f"allocate(dm(1)%artt(grd(1)%nr,nt,nt,dm(1)%nartt),dm(1)%artti({asi_ari_size},dm(1)%nartt))")
        self.send_out("      dm(1)%artt = 0d0; dm(1)%artti=0")
        self.send_out(f"allocate(idm(1,1)%atbc(nt,idm(1,1)%natbc),idm(1,1)%atbci({asbci_size},idm(1,1)%natbc))\n")
        self.send_out("      idm(1,1)%atbc = 0d0; idm(1,1)%atbci=0\n")
        self.send_out("      "
              f"allocate(idm(1,1)%attbc(nt,nt,idm(1,1)%nattbc),idm(1,1)%attbci({asbci_size},idm(1,1)%nattbc))\n")
        self.send_out("      idm(1,1)%attbc = 0d0; idm(1,1)%attbci=0\n\n")

    def writetail(self):
        if self.current_eq != 'no_eq':
                self.send_out(f"      end subroutine eq_{self.current_eq}", self.amat)
                self.send_out(f"      end subroutine eqi_{self.current_eq}", self.imat)
        else:
            self.fatal_err("You seem to have no equations in $input! Aborting",
                          29)
#        for i in range(len(self.imat)):
        for i in range(len(self.isub)):
            self.send_out(f"{self.isub[i]}")

        #ReadEqParserMono.writetail(self, )
        self.send_out(f"      power_max={self.power_max}\n\n")
        self.send_out("      a_dim = nt*grd(1)%nr*dm(1)%nvar\n")
        self.send_out("      dm(1)%d_dim = a_dim")
        self.send_out("      call find_llmax()")
        self.send_out("      print*,'Dimension of problem: ',a_dim\n\n")
        self.send_out("      call find_der_range(der_min,der_max)")
        self.send_out(
            "      if (allocated(dm(1)%vect_der)) deallocate(dm(1)%vect_der)\n",
        )
        self.send_out("      allocate(dm(1)%vect_der(a_dim, der_min:der_max))\n\n")
        self.send_out("      if (.not.first_dmat) call clear_derive(dmat(1))\n")
        self.send_out(
            "      call init_derive(dmat(1),grd(1)%r,grd(1)%nr,der_max,der_min,orderFD,dertype)\n",
        )
        self.send_out("      first_dmat = .false.\n\n")
        self.send_out("      call init_var_list()\n")
        for i in range(len(self.asub)):
            self.send_out(f"{self.asub[i]}")
        self.send_out("      call integrales_clear()")
        self.send_out("      end subroutine init_a\n")
        for i in range(len(self.imat)):
            self.send_out(f"{self.imat[i]}")
        for i in range(len(self.amat)):
            self.send_out(f"{self.amat[i]}")

    def readvarlist(self):
        def call_at_end():
            self.send_out(f"      allocate(dm(1)%lvar(nt,{self.nvar}))")
            self.send_out("      dm(1)%lvar = 0")
        super().readvarlist(call_at_end)

    def readeqlist(self):
        def call_at_end():
            self.send_out(f"      allocate(dm(1)%leq(nt,{self.nvar}))")
            self.send_out("      dm(1)%leq = 0")
        super().readeqlist(call_at_end)

    def seteq(self, get_eq=True):

        def call_at_start():
            if self.current_eq != 'no_eq':
                self.send_out(f"      end subroutine eqi_{self.current_eq}", self.imat)
            self.send_out(f"      end subroutine eq_{self.current_eq}", self.amat)

        def call_at_end():
            self.current_eq = self.instrucs[1]
            current_eq = self.current_eq
            amat, imat, asub, isub = self.attrs('amat', 'imat', 'asub', 'isub')
            self.send_out(f'      call eq_{current_eq}()', asub)
            self.send_out(f'      call eqi_{current_eq}()', isub)
            self.amat[-1] = self.amat[-1].replace('      ! equation', '! Coupling coefficients for'
                                                  ' equation')

            self.amat[-1] = self.amat[-1].replace(':', '') # TODO: should be a precise regex matching the end of line
            self.send_out("!" + "-" * 60, amat)
            self.send_out(f"      subroutine eq_{current_eq}()\n", amat)
            self.send_out("      use model", amat)
            self.send_out("      use inputs", amat)
            self.send_out("      use integrales", amat)
            self.send_out("      implicit none", amat)
            self.send_out("      integer i,j,jj", amat)
            self.send_out("!"+("-"*60), imat)
            self.send_out(f"! Indices for equation {self.instrucs[1]}", imat)
            self.send_out("!"+("-"*60), imat)
            self.send_out(f"      subroutine eqi_{current_eq}()\n", imat)
            self.send_out("      use model", imat)
            self.send_out("      use inputs", imat)
            self.send_out("      implicit none", imat)

        super().seteq(call_at_start, call_at_end, disp_eq_comment=False,
                      get_eq=get_eq)

    def addterm(self, empty_end_line=True, outlst=None, var_id=None,
                get_var=True,
                counter_inc_func:callable=None,
                counter_val_func:callable=None):
        """
        Args:
            empty_end_line: bool
                if True an empty end line is output.
        """
        dm = self.dm
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)

        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)

        if outlst is None:
            outlst=self.imat

        super().addterm(types=['s', 'rtt'], fail_on_unknown_type=False,
                        outlst=outlst, offsettoz=False, get_var=get_var,
                        counter_inc_func=counter_inc_func,
                        counter_val_func=counter_val_func)

        out_buf, out_mode, imat, amat = self.attrs('out_buf', 'out_mode', 'imat', 'amat')
        assert out_mode == 'buffering'
        if self.instrucs[1] in ['s' or 'rtt']:
            # already processed by parent call
            pass
        elif self.instrucs[1] == 'rt':
            # TODO: maybe this part should be moved in parent method
            # it would allow more factoring (including the 'counter' callbacks
            # above)
            counter_inc_func("nart") # self.nart += 1
            counter_val = counter_val_func('nart')
            self.send_out(self.mywrap(
                f"      {dm}%art({self.i_index},{self.j_index},{counter_val}) = {self.instrucs[3]}"),
                amat)
            for i in range(self.nloops):
                amat += ["      enddo"]
            self.send_out(f"      {dm}%arti(1,{counter_val}) = {self.power}", outlst)
            self.send_out(f"      {dm}%arti(2,{counter_val}) = {self.der}", outlst)
            self.send_out(f"      {dm}%arti(3,{counter_val}) = {self.equation}", outlst)
            self.send_out(f"      {dm}%arti(4,{counter_val}) = {self.variable}", outlst)
            if isinstance(self, ReadEqParserMulti2D) and self.is_cplx and self.instrucs[0][-1] != 'i':
                # TODO: should be done in proper class
                self.send_out(f"      {dm}%arti(7,{counter_val}) = 0", outlst)
            self.send_out("", outlst)
        else:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: unrecognised term type {self.instrucs[1]}.", 16)

    def addtermi(self, get_var=True,
                 counter_inc_func:callable=None,
                 counter_val_func:callable=None):
        super().addtermi(outlst=self.imat,
                         get_var=get_var,
                         counter_inc_func=counter_inc_func,
                         counter_val_func=counter_val_func)
        dm = self.dm
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)

        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)

        if self.instrucs[1] == "rt":
            nart = counter_val_func('nart')
            self.send_out(f"      {dm}%arti(7,{nart}) = {int(self.is_cplx)}", self.imat)
        elif self.instrucs[1] == "rtt":
            nartt = counter_val_func('nartt')
            self.send_out(f"      {dm}%artti(7,{nartt}) = {int(self.is_cplx)}", self.imat)
        self.send_out("\n", self.imat)

    def callsub(self, empty_end_line=False,
                outlst=None, # just to follow parent prototype (not used)
                get_var=True,
                counter_inc_func:callable=None,
                counter_val_func:callable=None):
        # TODO: print a warning if outlst is not None and different than imat
        out_buf, imat, amat = self.attrs('out_buf', 'imat', 'amat')
        super().callsub(outlst=imat, empty_end_line=empty_end_line,
                                 counter_inc_func=counter_inc_func,
                                 counter_val_func=counter_val_func,
                                 get_var=get_var)
        if self.instrucs[1] == 's':
            # patch amat last line for 2D case
            amat[-1] = self.amat[-1].replace('as(', 'dm(1)%as(')

    def callsubi(self, get_var=True,
                 outlst=None, # just to follow parent prototype (not used)
                 counter_inc_func:callable=None,
                 counter_val_func:callable=None):
        # TODO: print a warning if outlst is not None and different than imat
        if counter_inc_func is None:
            counter_inc_func = lambda attr: ReadEqParser._counter_inc_func(self, attr)

        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)
        super().callsubi(empty_end_line=False, outlst=self.imat,
                        get_var=get_var, counter_inc_func=counter_inc_func,
                         counter_val_func=counter_val_func)
        dm = self.dm
        if self.instrucs[1] == "rt":
            nart = counter_val_func('nart')
            self.send_out(f"      {dm}%arti(7,{nart}) = {int(self.is_cplx)}", self.imat)
        elif self.instrucs[1] == "rtt":
            nartt = counter_val_func('nartt')
            self.send_out(f"      {dm}%artti(7,{nartt}) = {int(self.is_cplx)}", self.imat)

    def writeinputs(self, input_fp: str,
                    before_init_inputs:callable=None,
                    before_printing_inputs:callable=None,
                    before_printing_format:callable=None,
                    use_grid_mod_decl="use mod_grid, only: grd, nt, init_grid",
                    use_bin_subroutines:bool=True):
        super().writeinputs(eq_ndim=2, input_fp=input_fp,
                            before_init_inputs=before_init_inputs,
                            before_printing_inputs=before_printing_inputs,
                            before_printing_format=before_printing_format,
                            use_grid_mod_decl=use_grid_mod_decl,
                            use_bin_subroutines=use_bin_subroutines)

    def treat_string(self, string: str, i_inds='auto',
                     fail_on_unknown_type=False, counter_val_func:callable=None):
        varDomainNumber = self.varDomainNumber
        domainNumber = self.domainNumber
        if counter_val_func is None:
            counter_val_func = lambda attr: ReadEqParser._counter_val_func(self, attr)
        if i_inds == 'auto':
            i_inds = f"1:grd({varDomainNumber})%nr"
        string = super().treat_string(string, i_inds=i_inds,
                                      fail_on_unknown_type=fail_on_unknown_type,
                                      counter_val_func=counter_val_func)
        self.jj_index = self.j_index = "1:nt"
        while m := match(r'(.*)\$lvar\(([^)]*)\)(.*)', string):
            string = m.group(1) + f'dm({varDomainNumber})%lvar(' + m.group(2) + f',{self.variable})' + m.group(3)
        string = string.replace('$lvar', f'dm({varDomainNumber})%lvar(1:nt,{self.variable})')
        while m := match(r'(.*)\$leq\((.*)\)(.*)', string):
            string = m.group(1) + f'dm({domainNumber})%leq(' + m.group(2) + f'),{self.equation})' + m.group(3)
        string = string.replace('$leq', f'dm({domainNumber})%leq(1:nt,{self.equation})')
        string = string.replace('$var', f'{self.variable}')
        string = string.replace('$eq', f'{self.equation}')
        if isinstance(self, ReadEqParserMulti2D):
            string = string.replace('$nr', f'grd({varDomainNumber})%nr')


        if "$j1" in string:
            self.amat += ["      do j=1,nt"]
            self.nloops += 1
            self.j_index = "j"

        if "$j2" in string:
            self.amat += ["      do jj=1,nt"]
            self.nloops += 1
            self.jj_index = "jj"

        string = string.replace("$j1", "j")
        string = string.replace("$j2", "jj")

        dm = self.dm
        idm = self.idm
        if "$prev" in string:
            if self.prev == "rt":
                nart = counter_val_func('nart')
                string = string.replace("$prev",
                                        f"{dm}%art({self.i_index},{self.j_index},{nart})")
            elif self.prev == "rtt":
                nartt = counter_val_func('nartt')
                string = string.replace("$prev",
                                        f"{dm}%artt({self.i_index},{self.j_index},{self.jj_index},{nartt})")

            elif self.prev == "tbc":
                natbc = counter_val_func('natbc')
                string = string.replace("$prev",
                                        f"{idm}%atbc({self.j_index},{natbc})")
            elif self.prev == "ttbc":
                nattbc = counter_val_func('nattbc')
                string = string.replace("$prev",
                                        f"{idm}%attbc({self.j_index},{self.jj_index},{nattbc})")
            else:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: Programming error in readeq\n", 15)

        return string

    def parser_type(self):
        return __class__


class ReadEqParserMulti2D(ReadEqParserMono2D):


    def __init__(self, argv, output='matrices.inc'):
        super().__init__(argv, output=output)
        self.countterm_in_parse = False
        self.ndoms_printed = False


    def setdefault(self):
        ReadEqParserMono.setdefault(self)
        self.current_eq = 'no_eq'
        self.amat = [] # this contains the instructions for the coupling coefficients
        self.imat = [] # this contains the instructions which specify the indices in
                       # the asi, arti, artti, atbci and attbci matrices
        self.asub = [] # this contains the calls to the subroutines which calculate the
        # coupling coefficients
        self.isub = [] # this contains the calls to the subroutine which specify the
        # indicies in the asi, arti, artti, atbci and attbci matrices
        self.send_out(f"      call eq_{self.current_eq}()", self.asub)
        self.send_out("!" + "-" * 60, self.amat)
        self.send_out( "! Preliminary instructions", self.amat)
        self.send_out("!" + "-" * 60, self.amat)
        self.send_out(f"      subroutine eq_{self.current_eq}()", self.amat)
        self.send_out( "      use model", self.amat)
        self.send_out( "      use inputs", self.amat)
        self.send_out( "      use integrales", self.amat)
        self.send_out( "      implicit none", self.amat)
        self.send_out( "      integer i, j, jj", self.amat)

        self.out_mode = 'buffering'

        bak_isub = list(self.isub)
        bak_asub = list(self.asub)
        bak_amat = list(self.amat)
        bak_imat = list(self.imat)

        with open(self._input) as in_stream:
            self.in_lines = in_stream.readlines()
            for self.nl, li in enumerate(self.in_lines):
                self.nl += 1
                if DEBUG:
                    print(f"parsed line ({self.in_nl[self.nl]}):", li, end='')
                li = li.strip()
                # remove inline comment
                if m := match(r"(^[^#]*)#", li):
                    li = m.group(1)
                # ignore blank line
                if match(r"^\s*$", li):
                    continue
                self.instrucs = li.split()

                keyword = self.instrucs[0]
                if keyword == 'domains':
                    self.readdomains()
                    self.initcounters()
                elif keyword == 'varlist':
                    self.readvarlist()
                elif keyword == 'eqlist':
                    self.readeqlist()
                elif keyword == 'equation':
                    self.seteq()
                elif keyword in ["term", "termi", "termbc", "termbci", "sub",
                                   "subi", "subbc", "subbci"]:
                    self.instruc_funcs[keyword]()

        # TODO: the backup restoration should be made more safely and
        # exhaustively
        self.current_eq = 'no_eq'
        self.isub = bak_isub
        self.asub = bak_asub
        self.amat = bak_amat
        self.imat = bak_imat

    def define_instrucs(self):
        super().define_instrucs()
        self.instruc_funcs['leq'] = lambda: self.setleq()
        self.instruc_funcs['lvar'] = lambda: self.setlvar()

    def readdomains(self, print_ndoms=False, print_ndoms_only_once=True):
        """
        """
        if len(self.instrucs) < 2:
            fatal_err(f'Error on line {self.in_nl[self.nl]}: empty domain list!',
                      ReadEqError.EMPTY_DOMAIN_LIST)

        self.domainlist = {}

        for i, dom in enumerate(self.instrucs[1:]):
            if dom in self.domainlist:
                fatal_err(f'Error on line {self.in_nl[self.nl]}: repeated domain name.',
                          ReadEqError.REPATED_DOMAIN_NAME)
            self.domainlist[dom] = i + 1

        self.ndomains = len(self.domainlist)
        if print_ndoms or print_ndoms_only_once and not self.ndoms_printed:
            print("Number of domains:", self.ndomains)
            self.ndoms_printed = True


        # initialise different arrays to do with equations and variables:
        self.vardomain = {}
        self.varindex = {}
        self.eqdomain = {}
        self.eqindex = {}

    def initcounters(self):
        """
        Initialise some variables based on the number of domains.
        """
        dsz = self.ndomains + 1
        for counter in ['nar', 'nvar', 'nas', 'nart', 'nartt', 'nvardomain',
                        'neqdomain']:
            self.__setattr__(counter,
                          np.zeros((dsz), dtype='int').tolist())
            # TODO: not sure why the zero-index domain is ignored but
            # it should be verified later, maybe it is unnecessary
            # or maybe python dict should be used to ignore zero index
        # natbc and nattbc are 2d arrays
        for counter in ['natbc', 'nattbc']:
            self.__setattr__(counter, np.zeros((dsz, dsz), dtype='int'))

    def readvarlist(self):
        if len(self.instrucs) < 3:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: empty variable list!",
                           EMPTY_VAR_LIST)

        if self.instrucs[1] in self.domainlist:
            domainNumber = self.domainlist[self.instrucs[1]]
        else:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: {self.instrucs[1]}"
                           " unknown domain", ReadEqError.UNKNOWN_DOMAIN)

        for i, var in enumerate(self.instrucs[2:]):
            if var in self.vardomain:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: variable {var}"
                               " already exists.",
                               ReadEqParser.VAR_ALREADY_EXISTS)
            else:
                # NOTE: eqdomain, eqindex are dict
                # so one-base index is not a prob
                self.vardomain[var] = domainNumber
                self.varindex[var] = i + 1
                self.nvardomain[domainNumber] += 1

    def readeqlist(self):
        if len(self.instrucs) < 3:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: empty variable list!",
                           EMPTY_VAR_LIST)

        if self.instrucs[1] in self.domainlist:
            domainNumber = self.domainlist[self.instrucs[1]]
        else:
            self.fatal_err(f"Error on line {self.in_nl[self.nl]}: {self.instrucs[1]}"
                           " unknown domain", ReadEqError.UNKNOWN_DOMAIN)

        for i, eq in enumerate(self.instrucs[2:]):
            if eq in self.eqdomain:
                self.fatal_err(f"Error on line {self.in_nl[self.nl]}: equation {eq}"
                               " already exists.", ReadEqParser.EQ_ALREADY_EXISTS)
            else:
                # NOTE: eqdomain, eqindex are dict
                # so one-base index is not a prob
                self.eqdomain[eq] = domainNumber
                self.eqindex[eq] = i + 1
                self.neqdomain[domainNumber] += 1

    def seteq(self):
        # apart the domain-equation existence verification
        # this is the same function as in sibling class ReadEqParserMono2D
        # so we rely on it
        instrucs = self.instrucs
        if instrucs[1] in self.eqdomain:
            self.domainNumber = self.eqdomain[instrucs[1]]
            self.equation = self.eqindex[instrucs[1]]
            super().seteq(get_eq=False)
        else:
            self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{self.instrucs[1]}" unknown equation.', 11)


    def countterm(self):
        # apart the domain-variable existence verification
        # this is the same function as in sibling class ReadEqParserMono2D
        # so we rely on it
        instrucs = self.instrucs
        if 'bc' in instrucs[0] and len(instrucs) >= 2:
            # error on bad number of arguments is handled by ReadEqParserMono2D
            varname = instrucs[-1]
            varname = subn(r'\([^)]*\)', '', varname, count=1)[0]
            varname = subn(r"'", '', varname)[0]
            varname = subn(r"\^.*", '', varname)[0]
            if varname not in self.vardomain:
                self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{varname}" unknown variable.', 13)
            def counter_inc_func(attr):
                counter_lst = self.__getattribute__(attr)[self.domainNumber]
                counter_lst[self.vardomain[varname]] += 1
                #e.g self.natbc[self.domainNumber][varname] += 1
        else:
            def counter_inc_func(attr):
                counter_lst = self.__getattribute__(attr)
                counter_lst[self.domainNumber] += 1
                #e.g self.nas[self.domainNumber] += 1

        super().countterm(counter_inc_func=counter_inc_func)
#        super(ReadEqParserMono2D).countterm(counter_inc_func=counter_inc_func)

    def suppressvar(self):
        var_indices = []
        var_doms = []
        for varname in instrucs[1:]:
            if varname in self.vardomain:
                var_doms += [self.vardomain[varname]]
                var_indices += [self.varindex[varname]]
            # else: parent is responsible to emit the error
        super().suppressvar(var_doms=var_doms,
                            var_indices=var_indices)
    def setleq(self):
        # apart the domain-eq existence verification
        # this is the same function as in sibling class ReadEqParserMono2D
        # so we rely on it
        eqname = self.instrucs[1]
        if eqname in self.eqdomain:
            self.domainNumber = eq_dom = self.eqdomain[eqname]
            eq_id = self.eqindex[eqname]
            self.dm = f"dm({self.domainNumber})"
        else:
            self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{self.instrucs[1]}"'
                           ' unknown equation.', 26)
        # else: parent is responsible to emit the error
        super().setleq(eq_dom=eq_dom, eq_id=eq_id)

    def setlvar(self):
        # apart the domain-eq existence verification
        # this is the same function as in sibling class ReadEqParserMono2D
        # so we rely on it
        varname = self.instrucs[1]
        if varname in self.vardomain:
            self.varDomainNumber = vardom = self.vardomain[varname]
            var_id = self.varindex[varname]
            self.variable = var_id
            self.dm = f"dm({self.varDomainNumber})"
        else:
            self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{self.instrucs[1]}"'
                           ' unknown variable.', 28)
        super().setlvar(var_id=var_id)

    def addterm(self, **kwargs):
        self._call_gen(ndim=1, varname_arg=4,
                       callee=ReadEqParserMono2D.addterm, **kwargs)

    def addtermi(self):
        self._call_gen(ndim=1,  varname_arg=4, callee=ReadEqParserMono2D.addtermi)

    def addtermbc(self, **kwargs):
        self.instrucs[2] = self.instrucs[2].replace('$nr', f'grd({self.domainNumber})%nr')
        self._call_gen(ndim=2, callee=ReadEqParserMono2D.addtermbc,
                       dom_coupling_max_diff=1, **kwargs)

    def addtermbci(self):
        self._call_gen(ndim=2, callee=ReadEqParserMono2D.addtermbci, dom_coupling_max_diff=1)

    def _call_gen(self, varname_arg=5, ndim=1, callee:callable=None,
                  check_coupling=True, dom_coupling_max_diff=0, **kwargs):
        assert callee is not None

        # handle arguments preceding variable name that possibly contain spaces
        # join them as one arg.
        if len(self.instrucs) > varname_arg + 1:
            self.instrucs[varname_arg-1] = " ".join(self.instrucs[varname_arg-1:-1])
            self.instrucs = self.instrucs[:varname_arg] + self.instrucs[-1:]

        # filter out non-name elements in varname argument
        varname = self.instrucs[varname_arg].replace("'", '')
        varname = subn(r'\([^)]*\)', '', varname, count=1)[0]
        varname = subn(r'\^.*', '', varname)[0]

        if varname in self.vardomain:
            var_id = self.varindex[varname]
            self.variable = var_id
            var_dom = self.vardomain[varname]
            if check_coupling:
                if abs(var_dom - self.domainNumber) > dom_coupling_max_diff:
                    self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{self.instrucs[1]}"'
                                   ' illegal domain coupling.',
                                   ReadEqError.ILLEGAL_DOMAIN_COUPLING)
        else:
            self.fatal_err(f'Error on line {self.in_nl[self.nl]}: "{varname}"'
                           ' unknown variable.', 28)

        # remove duplicated kwargs
        for k in ["get_var", "counter_inc_func", "counter_val_func"]:
            if k in kwargs:
                del kwargs[k]

        # functions called are supposedly the same as in parent
        # class ReadEqParserMono2D so rely on it
        callee(self,
               get_var=False,
               counter_inc_func=lambda attr:
               ReadEqParserMulti2D._counter_inc_func(
                   self,
                   self.domainNumber,
                   var_dom,
                   attr,
                   ndim=ndim),
               counter_val_func=lambda attr:
               ReadEqParserMulti2D._counter_val_func(
                   self,
                   self.domainNumber,
                   var_dom,
                   attr,
                   ndim=ndim), **kwargs)

    def callsub(self, **kwargs):
        self._call_gen(ndim=1, varname_arg=4,
                       callee=ReadEqParserMono2D.callsub,
                       **kwargs
                       )

    def callsubi(self):
        self._call_gen(ndim=1, varname_arg=4, callee=ReadEqParserMono2D.callsubi)

    def callsubbc(self, **kwargs):
        self.instrucs[2] = self.instrucs[2].replace('$nr', f'grd({self.domainNumber})%nr')
        self._call_gen(ndim=2, callee=ReadEqParserMono2D.callsubbc,
                       dom_coupling_max_diff=1, **kwargs)

    def callsubbci(self, **kwargs):
        self.instrucs[2] = self.instrucs[2].replace('$nr', f'grd({self.domainNumber})%nr')
        self._call_gen(ndim=2, callee=ReadEqParserMono2D.callsubbci,
                       dom_coupling_max_diff=1, **kwargs)


    @staticmethod
    def _counter_inc_func(obj, dom_id, var_dom_id, attr: str, ndim: int=1):
        counter_lst = obj.__getattribute__(attr)
        # TODO: rather specify counters that are in 2D directly here
        # and delete ndim arg
        var_dom_id = obj.varDomainNumber
        dom_id = obj.domainNumber
#        print("inc_func:\n", "dom_id:", dom_id, "var_dom_id:", var_dom_id, 'var:', attr)
#        print("before:", counter_lst)
        if ndim == 1:
            counter_lst[dom_id] += 1
        else:
            assert ndim == 2
            counter_lst[dom_id][var_dom_id] += 1
#        print("after:", counter_lst)

    @staticmethod
    def _counter_val_func(obj, dom_id, var_dom_id, attr: str, ndim: int=1):
        counter_lst = obj.__getattribute__(attr)
        var_dom_id = obj.varDomainNumber
        dom_id = obj.domainNumber
#        print("val_func:\n", "dom_id:", dom_id, "var_dom_id:", var_dom_id,
#              'var:', attr)
        if ndim == 1:
            return counter_lst[dom_id]
        else:
            assert ndim == 2
            return counter_lst[dom_id][var_dom_id]

    def writeinputs(self, input_fp: str):

        for field in ['mattype', 'dertype', 'orderFD']:
            inp_index = self.inputs.index(field)
            self.inputs.remove(field)
            self.inputs_datatype = self.inputs_datatype[:inp_index] + self.inputs_datatype[inp_index+1:]
            self.inputs_value = self.inputs_value[:inp_index] + self.inputs_value[inp_index+1:]
            self.inputs_format = self.inputs_format[:inp_index] + self.inputs_format[inp_index+1:]


        def before_init_inputs(inputs_f90):
            for dom_id in range(1, self.ndomains + 1):
                grd = f"grd({dom_id})"
                print(f"      {grd}%nr = fetch('nr({dom_id})',0)", file=inputs_f90)
                print(f"      {grd}%order = fetch('order({dom_id})',2)", file=inputs_f90)
                print(f"      {grd}%dertype = fetch('dertype({dom_id})','CHEB')", file=inputs_f90)
                print(f"      {grd}%mattype = fetch('mattype({dom_id})','FULL')",
                      file=inputs_f90)

        def before_printing_inputs(inputs_f90):
            for dom_id in range(1, self.ndomains + 1):
                grd = f"grd({dom_id})"
                print(f"          {grd}%nr, & ! this corresponds to nr+1 when using postvecp ",
                      file=inputs_f90)
                print(f"          {grd}%order, &",
                      file=inputs_f90)
                print(f"          trim({grd}%dertype), &",
                      file=inputs_f90)
                print(f"          trim({grd}%mattype), &",
                      file=inputs_f90)

        def before_printing_format(inputs_f90):
            for dom_id in range(1, self.ndomains + 1):
                print(f"          '  nr({dom_id})=',I4, &", file=inputs_f90)
                print(f"          '  order({dom_id})=',I2, &", file=inputs_f90)
                print(f"          '  dertype({dom_id})=',A, &", file=inputs_f90)
                print(f"          '  mattype({dom_id})=',A, &", file=inputs_f90)

        super().writeinputs(input_fp=input_fp,
                            before_init_inputs=before_init_inputs,
                            before_printing_inputs=before_printing_inputs,
                            before_printing_format=before_printing_format,
                            use_grid_mod_decl="use mod_grid",
                            use_bin_subroutines=False)

    def treat_string(self, string: str, varDomainNumber=1):
        domainNumber = self.domainNumber
        varDomainNumber = self.varDomainNumber
        string = super().treat_string(string, i_inds=f"1:grd({varDomainNumber})%nr",
                                      fail_on_unknown_type=False,
                                      counter_val_func=lambda attr: \
                                      ReadEqParserMulti2D._counter_val_func(
                                          self,
                                          domainNumber,
                                          varDomainNumber,
                                          attr,
                                      ))
        string = string.replace('$nr', f'grd({varDomainNumber})%nr')

        return string

    def writehead(self):
        self.send_out("      subroutine init_a()\n")
        self.send_out("      use model")
        self.send_out("      use inputs")
        self.send_out("      use integrales")
        self.send_out("      implicit none")
        self.send_out("      integer i,j,jj,id,der_min,der_max\n")

        for i in range(len(self.defs)):
                self.send_out(self.mywrap(f"      {self.defs[i]} = {self.defs_value[i]}"))
        self.send_out("")

        self.send_out("      if (.not.first_run) call clear_all()")
        self.send_out("      allocate(dm(ndomains),idm(ndomains,ndomains))\n")


        for i in range(1, self.ndomains+1):
            self.send_out(f"      dm({i})%nvar={self.nvardomain[i]}")
            self.send_out(f"      dm({i})%nas={self.nas[i]}")
            self.send_out(f"      dm({i})%nart={self.nart[i]}")
            self.send_out(f"      dm({i})%nartt={self.nartt[i]}")

        for i in range(1, self.ndomains+1):
            for j in range(1, self.ndomains+1):
                self.send_out(f"      idm({i},{j})%natbc={self.natbc[i][j]}")
                self.send_out(f"      idm({i},{j})%nattbc={self.nattbc[i][j]}")

        self.send_out("      call allocate_all()\n")

        self.send_out("      ! variable names:")

        vardomain = self.vardomain
        for varname, domainNumber in vardomain.items():
            self.send_out(f"      dm({domainNumber})%var_name({self.varindex[varname]}) = \"{varname}\"")

        self.send_out("")

        self.send_out("      ! equation names:")

        eqdomain = self.eqdomain
        for eqname, domainNumber in eqdomain.items():
            self.send_out(f"      dm({domainNumber})%eq_name({self.eqindex[eqname]}) = \"{eqname}\"")
        self.send_out("")

        self.send_out("      ! initialise var_keep arrays:")

        for i in range(1, self.ndomains+1):
            self.send_out(f"      dm({i})%var_keep=.true.")
        self.send_out("")

    def writetail(self):
        # TODO: refactor with ReadEqParserMono2D
        if self.current_eq != 'no_eq':
                self.send_out(f"      end subroutine eq_{self.current_eq}", self.amat)
                self.send_out(f"      end subroutine eqi_{self.current_eq}", self.imat)
        else:
            self.fatal_err("You seem to have no equations in {self._input}! Aborting",
                          29)
#        for i in range(len(self.imat)):
        for i in range(len(self.isub)):
            self.send_out(f"{self.isub[i]}")

        self.send_out(f"      power_max={self.power_max}\n")
        self.send_out("      ! Initialise derivation matrices and dimensions of different")
        self.send_out("      ! domains.")
        self.send_out("      allocate(dmat(ndomains))")
        self.send_out("      a_dim = 0")
        self.send_out("      d_dim_max = 0")
        self.send_out("      do id=1,ndomains")
        self.send_out("        dm(id)%d_dim  = nt*grd(id)%nr*dm(id)%nvar")
        self.send_out("        dm(id)%offset = a_dim")
        self.send_out("        if (d_dim_max.lt.dm(id)%d_dim) d_dim_max = dm(id)%d_dim")
        self.send_out("        a_dim = a_dim + dm(id)%d_dim")
        self.send_out("        call find_der_range(der_min,der_max,id)")
        self.send_out("        allocate(dm(id)%vect_der(dm(id)%d_dim,der_min:der_max))")
        self.send_out("        call init_derive(dmat(id),grd(id)%r,grd(id)%nr,der_max, &")
        self.send_out("          der_min,grd(id)%order,grd(id)%dertype)")
        self.send_out("      enddo\n")
        self.send_out("      first_run = .false.")
        self.send_out("      call init_var_list()")
        self.send_out("      call find_llmax()")
        self.send_out("      print*,'Dimension of problem: ',a_dim")

#        for i in range(len(self.imat)):
        for i in range(len(self.asub)):
            self.send_out(f"{self.asub[i]}")

        self.send_out("      call integrales_clear()")
        self.send_out("      end subroutine init_a")

        for i in range(len(self.imat)):
            self.send_out(f"{self.imat[i]}")
        for i in range(len(self.amat)):
            self.send_out(f"{self.amat[i]}")

    def parser_type():
        return __class__


def main(argv):

    if ReadEqParser.is_multi(argv[1]):
        parser = ReadEqParserMulti2D(argv)
    elif ReadEqParser.is_2D(argv[1]):
        parser = ReadEqParserMono2D(argv)
    else:
        parser = ReadEqParserMono1D(argv)

    parser.expand()
    parser.parse()

if __name__ == "__main__":

    main(argv)
