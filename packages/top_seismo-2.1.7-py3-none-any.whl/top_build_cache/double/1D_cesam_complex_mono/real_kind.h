#if(QUADRUPLE>=1)
#define REAL_TYPE real*16
#define CPLX_IMAG(s) \
	imag(s)
#define REAL_CAST(s) \
	real(s, 16)
	! use REAL_CAST to avoid Error: Result of exponentiation at (1) exceeds the range of INTEGER(4)
#define R_ONE \
	1q0
#define R_TWO \
	2q0
#define R_FOUR \
	4q0
! R_ prefix stands for REAL but is moreover here
! to avoid conflicts with possible zero/one in code
! (TODO: maybe something that should be reconsidered)
#define R_ZERO \
	0q0
#define COMPLEX_TYPE complex*32
#define COMPLEX_CAST(x, y) \
	cmplx(x, y, 16)
!COMPLEX_CAST(REAL_CAST(conjg(Z)), REAL_CAST(imag(conjg(Z))))
#else
#define REAL_TYPE real*8

#define REAL_CAST(s) \
       	real(s, kind=8)
#define R_FOUR \
	4d0
#define R_TWO \
	2d0
#define R_ONE \
	1d0
#define R_ZERO \
	0d0
#define COMPLEX_TYPE complex*16
#define COMPLEX_CAST(x, y) \
	cmplx(x, y, kind=8)
#define CPLX_IMAG(s) \
	dimag(s)
#endif
