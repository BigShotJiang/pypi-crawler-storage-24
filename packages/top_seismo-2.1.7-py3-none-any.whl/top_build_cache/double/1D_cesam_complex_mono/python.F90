!#include "config.h"

module toppy

    use eigensolve, only: run_arncheb, vec, omega, nsol_out
    use mod_grid, only: ndomains, grd, nt
    use abstract_model_mod, only: abstract_model, model_ptr
    use model, only: init_model
    use matrices, only: a_dim, init_order, init_a, init_bc_flag, dm, dump_aterms
#ifdef USE_1D
    use inputs, only: read_inputs, init_default
#else
    use inputs, only: read_inputs, lres, init_default
#endif
    use postproc, only: write_output, get_sol_r, get_sol_c, get_lvar_size, get_lvar
    use iso_c_binding

    implicit none

contains

    subroutine dtype(ret)
        character(len=4), intent(out) :: ret

#ifdef USE_COMPLEX
        ret = "cplx"
#else
        ret = "real"
#endif

    end subroutine dtype

    subroutine get_nsol_out(ret)
        integer, intent(out) :: ret

        ret = nsol_out
    end subroutine

    subroutine get_adim(ret)
        integer, intent(out) :: ret

        ret = a_dim
    end subroutine

    subroutine get_valps_cplx(ret, n)
        integer, intent(in) :: n
        complex(kind=8), intent(out) :: ret(n)

        ret = omega

    end subroutine get_valps_cplx

    subroutine get_valps_real(ret, n)
        integer, intent(in) :: n
#ifdef USE_COMPLEX
        complex(kind=8), intent(out) :: ret(n)
#else
        real(kind=8), intent(out) :: ret(n)
#endif

        ret = omega

    end subroutine get_valps_real

    subroutine get_vecps_cplx(vecps, n, adim)
        integer, intent(in) :: n, adim
#ifdef USE_COMPLEX
        complex(kind=8), intent(out) :: vecps(adim, n)
#else
        real(kind=8), intent(out) :: vecps(adim, n)
#endif

        vecps = vec
    end subroutine get_vecps_cplx

    subroutine get_vecps_real(vecps, n, adim)
        integer, intent(in) :: n, adim
#ifdef USE_COMPLEX
        complex(kind=8), intent(out) :: vecps(adim, n)
#else
        real(kind=8), intent(out) :: vecps(adim, n)
#endif

        vecps = vec
    end subroutine get_vecps_real

    subroutine get_nr(n_r)
        integer, intent(out) :: n_r

        integer :: id, end_id

        end_id = get_adjusted_ndom()

        n_r = 0
        do id=1, end_id
            n_r = n_r + grd(id)%nr
        enddo

    end subroutine

    subroutine get_nt(n_t)
        integer, intent(out) :: n_t

        n_t = nt

    end subroutine

    subroutine get_lres(l_res)
        integer, intent(out) :: l_res

#ifdef USE_1D
        l_res = 0
#else
        l_res = lres
#endif

    end subroutine

    subroutine get_dom_nr(id, n_r)
        integer, intent(in) :: id
        integer, intent(out) :: n_r

        n_r = grd(id)%nr

    end subroutine

    subroutine get_nth(n_th)
        integer, intent(out) :: n_th

        n_th = nt

    end subroutine

    subroutine set_nr(n_r)
        integer, intent(in) :: n_r

        integer id

        do id=1, ndomains
            grd(id)%nr = n_r
        end do

    end subroutine

    subroutine set_nt(n_t)
        integer, intent(in) :: n_t

        nt = n_t

    end subroutine

    subroutine get_grid_size(nr, nt)
        integer, intent(out) :: nr, nt

        if (associated(model_ptr)) then
            call model_ptr%get_grid_size(nr, nt)
        else
            print*, "warning undefined model"
            nr = 1
            nt = 1
        endif

    end subroutine

    subroutine get_grid(grid, th, nr, nt)
        integer, intent(in) :: nr, nt
        real(kind=8), intent(out) :: grid(nr, nt), th(nt)

        if (associated(model_ptr)) then
            call model_ptr%get_grid(grid, th, nr, nt)
        else
            print*, "warning undefined model"
            grid = 0
            th = 0
        endif

    end subroutine

    subroutine get_zeta(zeta, nr)
        integer, intent(in) :: nr
        real(kind=8), intent(out) :: zeta(nr)

        integer :: id, skip, npts, end_id

        skip = 1

        end_id = get_adjusted_ndom()

        do id=1, end_id
            npts = grd(id)%nr
            zeta(skip:skip+npts) = grd(id)%r
            skip = skip + npts
        enddo

    end subroutine

    subroutine get_version(v)
        character(len=*), intent(out) :: v

        v = "1.0"
    end subroutine

    subroutine read_dati(dati)
        character(len=*), intent(in) :: dati

        call read_inputs(dati)
    end subroutine read_dati

    subroutine init_arncheb(ierr)

        use cfg

        integer eq
        integer, intent(out) :: ierr

        call init_a()
        if (dump_terms) then
            call dump_aterms(ierr)
            if (ierr /= 0) return
        endif
        call init_order()
        call init_bc_flag()

    end subroutine init_arncheb

    subroutine py_run_arncheb(shift, ierr)
        integer, intent(out) :: ierr
#ifdef USE_COMPLEX
        complex(kind=8), intent(in) :: shift
        complex(kind=8) :: shift_conv
        shift_conv = cmplx(shift, kind=8)
        !shift_conv = shift
#else
        real(kind=8), intent(in) :: shift
        real(kind=8) :: shift_conv
        shift_conv = real(shift, 8)
#endif
        ! note about shift_conf:
        ! using the right type in python in the first place
        ! would be cleaner but this is only a scalar so
        ! it is not heavy copy

        call run_arncheb(shift_conv, ierr)
    end subroutine py_run_arncheb

    subroutine pywrite_output(dir)
        character(len=*), intent(in) :: dir

        call write_output(dir)
    end subroutine pywrite_output

    subroutine get_solsize(idom, nr, nth)
        integer, intent(in) :: idom
        integer, intent(out) :: nr, nth

        nr = grd(idom)%nr
        nth = nt

    end subroutine get_solsize

    subroutine get_sol_real(idom, isol, var, valp, vecp, nr, nt)
        integer, intent(in) :: idom, isol
        integer, intent(in) :: nr, nt
        character(len=*), intent(in) :: var
        ! do the conversion in case KIND is 16
        ! (f2py/numpy limitation : it should be handled without conversion
        ! but it is not because numpy does not implement quadruple
        ! precision -- float128 is not quad)
        real(kind=8), intent(out) :: vecp(nr, nt)
        real(kind=8), intent(out) :: valp(1)
        real(kind=8) :: valp_, vecp_(nr, nt)
        call get_sol_r(idom, isol, var, valp_, vecp_)
        valp(1) = valp_
        vecp = vecp_
        !real(kind=8), intent(out) :: valp, vecp(nr, nt)
        !call get_sol_r(idom, isol, var, valp, vecp)
    end subroutine get_sol_real

    subroutine get_sol_cplx(idom, isol, var, valp, vecp, nr, nt)
        integer, intent(in) :: idom, isol
        integer, intent(in) :: nr, nt
        character(len=*), intent(in) :: var
        ! do the conversion in case KIND is 16
        ! (f2py/numpy limitation : it should be handled without conversion
        ! but it is not because numpy does not implement quadruple
        ! precision -- float128 is not quad)
        complex(kind=8), intent(out) :: valp, vecp(nr, nt)
        complex(kind=8) :: vecp_(nr, nt), valp_
        call get_sol_c(idom, isol, var, valp_, vecp_)
        valp = valp_
        vecp = vecp_
        !complex(kind=8), intent(out) :: valp, vecp(nr, nt)
        !call get_sol_c(idom, isol, var, valp, vecp)
    end subroutine get_sol_cplx

    subroutine get_var_name(idom, ivar, var_name)
        integer, intent(in) :: idom, ivar
        character(len=64), intent(out) :: var_name

        var_name = dm(idom)%var_name(ivar)

    end subroutine get_var_name

    subroutine get_nvars(idom, nvars)
        integer, intent(in) :: idom
        integer, intent(out) :: nvars

        nvars = dm(idom)%nvar_keep
    end subroutine get_nvars

    subroutine get_ndom(ndom)
        integer, intent(out) :: ndom

        ndom = ndomains
    end subroutine get_ndom

    integer function get_adjusted_ndom() result(ndom)
        ! NOTE: ester does not work with ndomains but ndomains - 1
        ! to get the radial grid (see get_zeta)
        ! the reason is maybe the last domain which is vacuum
        ! this is a workaround to a memory bug, see gitlab issue #23
        ! TODO: it should be fixed more consistently
        if(model_ptr%get_model_name() == "ester") then
            ! get_model_name is used because "select type" instruction can not be
            ! indeed other model types are not available at execution time, only the one in use
            ndom = ndomains - 1
        else
            ndom = ndomains
        endif
    end function

    subroutine pyget_lvar_size(idom, var, lsize)
        integer, intent(in) :: idom
        character(len=*), intent(in) :: var
        integer, intent(out) :: lsize

#ifdef USE_1D
        lsize = 1
#else
        call get_lvar_size(idom, var, lsize)
#endif
    end subroutine pyget_lvar_size

    subroutine pyget_lvar(idom, var, lm, l)
        integer, intent(in) :: idom, lm
        character(len=*), intent(in) :: var
        integer, intent(out) :: l(lm)

#ifdef USE_1D
        l = 0
#else
        call get_lvar(idom, var, l)
#endif
    end subroutine pyget_lvar

    subroutine init_dati()
        call init_default()
    end subroutine init_dati
end module toppy

module modelpy
    use abstract_model_mod
    use model, only: init_model
    implicit none

contains
    subroutine get_field_size(fname, n1, n2)
        character(len=*), intent(in) :: fname
        integer, intent(out) :: n1, n2

        real(kind=8), allocatable :: tmp(:, :)

        call model_ptr%get_field(fname, tmp)
        n1 = size(tmp, 1)
        n2 = size(tmp, 2)
        deallocate(tmp)
    end subroutine get_field_size

    subroutine get_field(fname, field, n1, n2)
        character(len=*), intent(in) :: fname
        real(kind=8), intent(out) :: field(n1, n2)
        integer, intent(in) :: n1, n2

        real(kind=8), allocatable :: tmp(:, :)

        call model_ptr%get_field(fname, tmp)

        field = tmp
        deallocate(tmp)

    end subroutine get_field

    subroutine py_init_model(modelfile, ierr)
        character(len=*), intent(in) :: modelfile
        integer, intent(out) :: ierr

        call init_model(modelfile, ierr)
    end subroutine

end module modelpy
