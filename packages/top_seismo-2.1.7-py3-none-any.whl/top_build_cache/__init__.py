import os
import shutil
import subprocess
from os.path import join, exists, dirname, sep, basename
import numpy as np
from glob import glob

if basename(__file__) == 'top_build_cache.py':
    DEFAULT_CACHE_DIR = join(dirname(__file__), basename(__file__).replace('.py', ''))
else:
    DEFAULT_CACHE_DIR = dirname(__file__)
print("top_build_cache:", DEFAULT_CACHE_DIR)


class TopBuildCache:
    """
    This class manages top-build caching mechanism.
    Given a set of dependencies it allows to retrieve building components
    from cache or to list the ones that should be produced because not
    available in cache for the requested configuration.
    """

    modobj_conf: list[str] = []

    def __init__(self, mods_info: dict, debug=False,
                 cache_dir=DEFAULT_CACHE_DIR):
        """
        """
        self.mods_info = mods_info
        self.debug = debug
        self.cache_dir = cache_dir

    def add_conf_opt(self, conf_opt: str, prepend_as_parent_folder=False):
        """
        Adds an element of configuration that identifies this cache.

        Args:
            conf_opt: str
                Option value to add to current conf.
            prepend_as_parent_folder: bool
                True for conf_opt to be encoded as a parent folder in cache.
                If False the option will imply in cache a folder name that combines this option and others (see modobj_conf2path).
        """
        if prepend_as_parent_folder:
            conf_opt = conf_opt + sep
            if self.modobj_conf.count(conf_opt) > 0:
                return # opt already here
            self.modobj_conf.insert(0, conf_opt)
        else:
            if self.modobj_conf.count(conf_opt) > 0:
                return # opt already here
            self.modobj_conf += [conf_opt]

    def modobj_conf2path(self):
        # TODO: option to set a cache dir from outside or rather set from config file
        """
        Converts a .mod/.o file configuration to a folder name.
        """
        modobj_outdir = self.cache_dir
        modobj_conf: list[str] = self.modobj_conf
        # sort the conf to avoid duplicates
        # NOTE: the prepended parent folders must be excluded from sort
        ppe = max(np.nonzero([sep in opt for opt in modobj_conf])[0] + [0]) + 1
        sorted_conf = modobj_conf[ppe:]
        sorted_conf.sort()
        return join(modobj_outdir, *modobj_conf[:ppe], '_'.join(sorted_conf))

    def find_file(self, name: str, ftype: str, test_exist=True):
        """
        Finds a module/object/src file ``name`` in cache according to conf. ``modobj_conf``.

        Args:
            name:
                Module/Object name.
            ftype
                Asked file type ('obj' or 'mod')

        Return: tuple(str, str)
            Paths of object file and module file.
            Each path is set to None if not found/accessible.

        """
        assert ftype in ['obj', 'mod', 'src']
        p = self.modobj_conf2path()

        modobj_p = {'obj': None,
                    'mod': None,
                    'src': None}
        exts = {'obj': '.o',
                'mod': '.mod',
                'src': '.F90'}

        for k in modobj_p:
            tmp = join(p, name + exts[k])
            if exists(tmp) or not test_exist:
                modobj_p[k] = tmp

        return modobj_p[ftype]

    @staticmethod
    def get_hdr_in_src(src_file: str) -> list[str]:
        """
        Returns a list of preprocessor headers
        (files included with #include) found in src_file.
        """
        hdrs = []
        with open(src_file) as f:
            f_lines = f.readlines()
            for fl in f_lines:
                if fl.startswith('#include'):
                    hdrs += [fl.split()[1].replace('"', '')]
        return hdrs

    def get_cache_state(self):
        """
        Returns the cache configuration state .
        """
        mods_to_compile = []
        files_to_cache = []
        objs_to_link = []
        mod_paths_to_inc = []
        mods_to_f2py_wrap = []

        for mod in self.mods_info:
            mod_entry = self.mods_info[mod]
            # use_cache_mod True if .mod is got from cache if available
            # if generation is needed then the resulting artefact is stored in cache
            use_cache_mod = ('use_cache_mod' not in mod_entry or
                              mod_entry['use_cache_mod'])
            use_cache_obj = ('use_cache_obj' not in mod_entry or
                              mod_entry['use_cache_obj'])
            use_cache_src = ('use_cache_src' in mod_entry and
                              mod_entry['use_cache_src'])
            mod_to_compile = ('to_compile' not in mod_entry or # defaultly True
                              mod_entry['to_compile'])
            obj_to_link = ('obj_to_link' not in mod_entry or
                           mod_entry['obj_to_link'])
            f2py_wrapper = 'f2py_wrapper' in mod_entry and mod_entry['f2py_wrapper']
            obj_file = self.find_file(mod_entry['obj_name'], ftype='obj')
            mod_file = self.find_file(mod_entry['mod_name'], ftype='mod')

            if use_cache_src:
                src_file = self.find_file(mod_entry['obj_name'], ftype='src')
            # else: src_file must be None because it is never saved in cache

            src_path_we = join(mod_entry['src_ppath'],
                               mod_entry['obj_name'])

            if not use_cache_src or src_file is None:
                # src is got from other source than cache
                src_file = src_path_we + ('.' + mod_entry['src_ext']
                                          if 'src_ext' in mod_entry else '')
                # if no src_ext is provided it means that the extension
                # is encoded into obj_name used to form src_path_we

                if use_cache_src:
                    # src_file was None before assignment above
                    # asked to save it in cache for next time
                    cache_src_path = self.find_file(mod_entry['obj_name'],
                                                    ftype='src',
                                                    test_exist=False)
                    files_to_cache += [(src_file, cache_src_path)]

                    # if not use_cache_src:
                    # caller is responsible to include header directories
                    if mod_to_compile or f2py_wrapper:
                        hdrs = TopBuildCache.get_hdr_in_src(src_file)
                        # header is supposedly in same directory as src # TODO: to be reconsidered in future
                        for hdr in hdrs:
                            hdr_orig_pdir = dirname(src_file)
                            hdr_cache_pdir = dirname(cache_src_path)
                            files_to_cache += [(join(hdr_orig_pdir, hdr),
                                                join(hdr_cache_pdir, hdr))]
                            if self.debug:
                                print(f"hdr {hdr} will be added in cache for"
                                      f" {src_file}")
                            # inclusion of header directory is handled below
                            # with mod_paths_to_inc
                    # else: no header is needed

            mod_path = join(mod_entry['mod_ppath'],
                            mod_entry['mod_name']) + '.mod'
            obj_path = join(mod_entry['obj_ppath'],
                            mod_entry['obj_name']) + '.o'
            prebuilt_mod = self.find_file(mod_entry['mod_name'],
                                            ftype='mod', test_exist=False)
            prebuilt_obj = self.find_file(mod_entry['obj_name'],
                                            ftype='obj', test_exist=False)
            if not use_cache_mod or obj_file is None or mod_file is None:
                # module object file or .mod is not available
                # they must be rebuilt
                if mod_to_compile:
                    mods_to_compile += [src_file]

                if use_cache_mod:
                    files_to_cache += [(mod_path, prebuilt_mod)]

                mod_paths_to_inc += [mod_entry['mod_ppath']]
            else:
                mod_paths_to_inc += [dirname(prebuilt_mod)]

            if obj_to_link:
                if obj_file is None:
                    if use_cache_obj:
                        files_to_cache += [(obj_path, prebuilt_obj)]
                    objs_to_link += [obj_path]
                else:
                    # obj_file in cache
                    assert obj_file == prebuilt_obj
                    objs_to_link += [obj_file]

            if f2py_wrapper:
#                if not use_cache_src or src_file is None:
#                    src_file = src_path_we + '.' + mod_entry['src_ext']
#                    mods_to_f2py_wrap += [src_file]
#                    if use_cache_src:
#                        pregen_src_file = \
#                                self.find_file(mod_entry['obj_name'],
#                                                 ftype='src',
#                                                 test_exist=False)
#                        files_to_cache += [(src_file, pregen_src_file)]
#                else:
                mods_to_f2py_wrap += [src_file]
                mod_paths_to_inc += [dirname(src_file)]
                # not really for .mod but for possible .h needed
                # indeed -I is used for both
                # avoid adding a new list just for .h

        mod_paths_to_inc = np.unique(np.array(mod_paths_to_inc)).tolist()
        mod_paths_to_inc_f2py = ['-I'+p for p in mod_paths_to_inc if exists(p)]
        # TODO: if self.debug indicate non-existent header directories that were ignored

        print("mods_to_compile:", mods_to_compile)
        self.state = {'mods_to_compile': mods_to_compile,
                      'files_to_cache': files_to_cache,
                      'objs_to_link': objs_to_link,
                      'mod_paths_to_inc': mod_paths_to_inc,
                      'mod_paths_to_inc_f2py': mod_paths_to_inc_f2py,
                      'mods_to_f2py_wrap': mods_to_f2py_wrap
                      }

        return self.state

    def dump_cache(self):
        """
        Saves cache into fs with paths defined in get_cache_state.
        """
        for src_file, dst_file in self.state['files_to_cache']:
            os.makedirs(dirname(dst_file), exist_ok=True)
            shutil.copy(src_file, dst_file)

    def get_lib_dir(self):
        """
        Indicates the cache path for TOP's libraries.
        """
        p = self.modobj_conf2path()
        if exists(join(p, 'libs')):
            # the conf is simply double or quad (no more info)
            # (because libs is in it and we don't put it subdirs!)
            tl_pdir = join(p, 'libs')
        else:
            tl_pdir = join(dirname(p), 'libs')
            # NOTE: parent dir used above because only quad or double
            # precision conf matters not 1D, 2D, model etc.
        return tl_pdir

    def get_mod_dir(self):
        """
        Indicates the cache path for TOP's library (fortran) modules (.mod).
        """
        return self.get_lib_dir().replace('libs', 'mods')


    def cache_top_libs(self, libpath, cache_lib_itself=False,
                       search_lib_paths: list|None = None,
                       add_mods: bool = False,
                       libs_to_cache_anyway : list|None = None):
        """
        Stores in cache TOP's libraries linked to library ``libpath``
        according to current configuration (quad or double precision).

        Args:
            search_lib_paths: list
                See list_linked_libraries.
            add_mods: bool
                If True add Fortran modules (.mod) found in same directory as libary or not.
            libs_to_cache_anyway: list|None
                Listed libraries are copied into cache even if not located in search_lib_paths.
                This option is to comprehend as an exception.
        """
        top_libs = TopBuildCache.list_linked_libraries(libpath,
                                                       search_lib_paths,
                                                       libs_to_inc_anyway=libs_to_cache_anyway)
        if self.debug:
            print("libs to store:", top_libs)
        assert hasattr(self, 'state'), "cache must have been created before"
        " (see get_cache_state)"

        tl_pdir = self.get_lib_dir()
        tm_pdir = self.get_mod_dir()
        if cache_lib_itself:
            top_libs += [libpath]
        for tl in top_libs:
            if exists(tl):
                self.state['files_to_cache'] += [(tl,
                                                  join(tl_pdir, basename(tl)))]
                if self.debug:
                    print("library added to cache:",
                          self.state['files_to_cache'][-1])
                if add_mods:
                    for tm in glob(join(dirname(tl), '*.mod')):
                        self.state['files_to_cache'] += [
                            (tm,
                             join(tm_pdir, basename(tm)))]
                    if self.debug:
                        print("module added to cache:",
                              self.state['files_to_cache'][-1])
            elif self.debug:
                print(f"Library {tl} not added to cache because doesn't exist")

    @staticmethod
    def list_linked_libraries(libpath, search_lib_paths: list = None,
                              libs_to_inc_anyway: list|None = None):
        """
        Args:
            search_lib_paths: str
                Search dependency library preferably in the indicated path.
            libs_to_inc_anyway: list|None
                See cache_top_libs equivalent argument libs_to_cache_anyway.
        """

        # TODO: use higher level tool than ldd command
        # (e.g.: https://github.com/Parquery/pylddwrap)
        ldd_out = subprocess.check_output(['ldd',
                                           libpath]).decode().split('\n')
        linked_libs = []
        for ldd_line in ldd_out:
            if '=>' in ldd_line:
                lib = ldd_line.split('=>')[1].split('(')[0].strip()
                if (lib.startswith('/root/local') or lib.startswith('/builds/top/top/build') or
                    # this is a TOP library because it is installed in
                    # cmake install prefix or built in cmake binary dir
                    # otherwise this is an external dependency to install from
                    # requirements
                    # but there might be exceptions defined by libs_to_inc_anyway:
                    libs_to_inc_anyway is not None and
                    basename(lib.replace('lib', '').replace('.so', '')) in libs_to_inc_anyway
                   ):

                    if search_lib_paths is not None:
                        for search_lib_path in search_lib_paths:
                            # find library in the indicated path if possible
                            libfile = basename(lib)
                            sr = glob(join(search_lib_path, '**',  libfile), recursive=True)
                            if sr != []:
                                lib = sr[0]
                    linked_libs += [lib]
        return linked_libs
