class model:
    """
    This class storing a star model

    access to fields of the model can be achieved with square bracket operator.
    But you need to know the fields stored in your model.

    :example:
        m['w'] # access the field omega of the model `m`
    """
    filename = ''
    libmodel = None
    def __init__(self, libmodel, filename):
        if type(filename) == str:
            self.filename = filename
        else:
            self.filename = filename.tostring().strip()
        self.libmodel = libmodel
        ierr = self.libmodel.py_init_model(filename)
        if ierr != 0:
            raise Exception("Error initializing model")

    def __getitem__(self, name):
        n1, n2 = self.libmodel.get_field_size(name)
        return self.libmodel.get_field(name, n1, n2)
