"""arctl - Agent Runtime Control"""

__version__ = "0.0.1"


def main():
    print(f"arctl v{__version__} - coming soon")
