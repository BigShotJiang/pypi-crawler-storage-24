from enum import Enum


class CombinedSearchBodyCompanyParamsHeadquartersLocationType0UnionAllType0ItemType0Strategy(str, Enum):
    RADIAL_DISTANCE = "radial-distance"

    def __str__(self) -> str:
        return str(self.value)
