from enum import Enum


class CombinedSearchBodyCompanyParamsJobPostingStatsType0AllOfType0ItemType4Rule(str, Enum):
    JOB_FUNCTION = "job-function"

    def __str__(self) -> str:
        return str(self.value)
