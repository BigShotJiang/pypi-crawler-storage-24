from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.combined_search_body_company_params_fortune_rankings_type_0_any_of_type_0_item import (
        CombinedSearchBodyCompanyParamsFortuneRankingsType0AnyOfType0Item,
    )


T = TypeVar("T", bound="CombinedSearchBodyCompanyParamsFortuneRankingsType0")


@_attrs_define
class CombinedSearchBodyCompanyParamsFortuneRankingsType0:
    """
    Attributes:
        any_of (list[CombinedSearchBodyCompanyParamsFortuneRankingsType0AnyOfType0Item] | None | Unset):
    """

    any_of: list[CombinedSearchBodyCompanyParamsFortuneRankingsType0AnyOfType0Item] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        any_of: list[dict[str, Any]] | None | Unset
        if isinstance(self.any_of, Unset):
            any_of = UNSET
        elif isinstance(self.any_of, list):
            any_of = []
            for any_of_type_0_item_data in self.any_of:
                any_of_type_0_item = any_of_type_0_item_data.to_dict()
                any_of.append(any_of_type_0_item)

        else:
            any_of = self.any_of

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if any_of is not UNSET:
            field_dict["anyOf"] = any_of

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.combined_search_body_company_params_fortune_rankings_type_0_any_of_type_0_item import (
            CombinedSearchBodyCompanyParamsFortuneRankingsType0AnyOfType0Item,
        )

        d = dict(src_dict)

        def _parse_any_of(
            data: object,
        ) -> list[CombinedSearchBodyCompanyParamsFortuneRankingsType0AnyOfType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                any_of_type_0 = []
                _any_of_type_0 = data
                for any_of_type_0_item_data in _any_of_type_0:
                    any_of_type_0_item = CombinedSearchBodyCompanyParamsFortuneRankingsType0AnyOfType0Item.from_dict(
                        any_of_type_0_item_data
                    )

                    any_of_type_0.append(any_of_type_0_item)

                return any_of_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[CombinedSearchBodyCompanyParamsFortuneRankingsType0AnyOfType0Item] | None | Unset, data)

        any_of = _parse_any_of(d.pop("anyOf", UNSET))

        combined_search_body_company_params_fortune_rankings_type_0 = cls(
            any_of=any_of,
        )

        combined_search_body_company_params_fortune_rankings_type_0.additional_properties = d
        return combined_search_body_company_params_fortune_rankings_type_0

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
