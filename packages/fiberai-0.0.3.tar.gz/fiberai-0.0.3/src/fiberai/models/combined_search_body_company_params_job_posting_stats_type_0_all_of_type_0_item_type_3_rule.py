from enum import Enum


class CombinedSearchBodyCompanyParamsJobPostingStatsType0AllOfType0ItemType3Rule(str, Enum):
    EMPLOYMENT_TYPE = "employment-type"

    def __str__(self) -> str:
        return str(self.value)
