from enum import IntEnum


class CombinedSearchBodyCompanyParamsEmployeeCountV2Type0UpperBoundInclusiveType2(IntEnum):
    VALUE_10 = 10

    def __str__(self) -> str:
        return str(self.value)
