from django.apps import AppConfig


class ArtifactBrowserConfig(AppConfig):
    name = "tcms_artifact_browser"
    verbose_name = "Artifact Browser"
