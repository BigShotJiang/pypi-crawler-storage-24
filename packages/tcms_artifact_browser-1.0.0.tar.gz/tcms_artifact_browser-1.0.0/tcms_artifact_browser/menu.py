from django.urls import reverse_lazy

MENU_ITEMS = [
    ("Artifact Browser", [
        ("Browse Artifacts", reverse_lazy("artifact-browser")),
    ]),
]
