default_app_config = "tcms_artifact_browser.apps.ArtifactBrowserConfig"
