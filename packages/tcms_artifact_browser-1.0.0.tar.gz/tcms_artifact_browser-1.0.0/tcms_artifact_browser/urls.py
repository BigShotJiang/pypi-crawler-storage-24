from django.urls import re_path

from tcms_artifact_browser import views

urlpatterns = [
    re_path(r"^$", views.ArtifactBrowserView.as_view(), name="artifact-browser"),
    re_path(
        r"^api/run/(?P<run_id>\d+)/attachments/$",
        views.api_run_attachments,
        name="artifact-api-run-attachments",
    ),
    re_path(
        r"^api/bug/(?P<bug_id>\d+)/attachments/$",
        views.api_bug_attachments,
        name="artifact-api-bug-attachments",
    ),
    re_path(
        r"^api/attachment/(?P<pk>\d+)/preview/$",
        views.api_attachment_preview,
        name="artifact-api-preview",
    ),
    re_path(
        r"^api/attachment/(?P<pk>\d+)/serve/$",
        views.api_serve_file,
        name="artifact-api-serve",
    ),
    re_path(
        r"^api/search/$",
        views.api_search_attachments,
        name="artifact-api-search",
    ),
    re_path(
        r"^api/statistics/$",
        views.api_statistics,
        name="artifact-api-stats",
    ),
    re_path(
        r"^api/download/zip/$",
        views.api_download_zip,
        name="artifact-api-download-zip",
    ),
    re_path(
        r"^api/report/$",
        views.api_report,
        name="artifact-api-report",
    ),
    re_path(
        r"^api/report/excel/$",
        views.api_report_excel,
        name="artifact-api-report-excel",
    ),
    re_path(
        r"^api/report/docx/$",
        views.api_report_docx,
        name="artifact-api-report-docx",
    ),
    re_path(
        r"^api/report/pdf/$",
        views.api_report_pdf,
        name="artifact-api-report-pdf",
    ),
]
