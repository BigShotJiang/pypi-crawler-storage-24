import pathlib

from setuptools import find_packages, setup

repo_dir = pathlib.Path(__file__).absolute().parent.parent.parent
version_file = repo_dir / "meta-data" / "VERSION"

with open(version_file, "r") as vfl:
    version = vfl.read().strip()

setup(
    name="{{ cookiecutter.module_name }}",
    version=version,
    description="{{ cookiecutter.description }}",
    author="{{ cookiecutter._author }}",
    author_email="{{ cookiecutter._author_email }}",
    license="unlicensed",
    packages=find_packages(),
    include_package_data=True,
    install_requires=[],
)
