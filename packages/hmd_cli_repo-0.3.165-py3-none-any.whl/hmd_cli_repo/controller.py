import json
import os
from importlib.metadata import version
from pathlib import Path
from typing import Tuple

from cement import Controller, ex
from hmd_cli_tools.hmd_cli_tools import load_hmd_env, set_hmd_env, read_manifest
from hmd_cli_tools.prompt_tools import prompt_for_values

from .loaders.project_type_loader import ProjectTypeLoader
from .loaders.skills_loader import SkillsLoader
from .remotes.github import _get_github_creds, _get_github_org_name
from .remotes import RemoteRepoManager


CONFIG_VALUES = {
    "HMD_REPO_ORG": {
        "prompt": "Prefix all created repositories with Org code, e.g. 'hmd':"
    }
}


VERSION_BANNER = """
hmd repo version: {}
"""


class LocalController(Controller):
    class Meta:
        label = "repo"

        stacked_type = "nested"
        stacked_on = "base"

        # text displayed at the top of --help output
        description = "Create git repositories"

        arguments = (
            (
                ["-v", "--version"],
                {
                    "help": "Display the version of the repo command.",
                    "action": "version",
                    "version": VERSION_BANNER.format(version("hmd_cli_repo")),
                },
            ),
        )

    def _default(self):
        """Default action if no sub-command is passed."""

        self.app.args.print_help()

    @ex(
        help="create a git repository",
        arguments=[
            (
                ["-y", "--skip"],
                {
                    "action": "store_const",
                    "const": True,
                    "dest": "skip_prompt",
                    "default": False,
                },
            ),
            (
                ["-n", "--project-name"],
                {
                    "action": "store",
                    "dest": "project_name",
                    "required": False,
                },
            ),
            (
                ["-t", "--project-type"],
                {
                    "action": "store",
                    "dest": "project_type",
                    "required": False,
                    "help": "Project type name (e.g., 'Microservice', 'CLI Command')",
                },
            ),
            (
                ["--var"],
                {
                    "action": "append",
                    "dest": "context_vars",
                    "metavar": "KEY=VALUE",
                    "default": [],
                    "help": "Context variable in KEY=VALUE format (can be repeated)",
                },
            ),
            (
                ["--remote"],
                {
                    "action": "store",
                    "dest": "remote_type",
                    "required": False,
                    "help": "Remote repository type: 'github', 'codecommit', or 'none' to skip",
                },
            ),
            (
                ["--private"],
                {
                    "action": "store_true",
                    "dest": "private_repo",
                    "default": None,
                    "help": "Create a private repository (default)",
                },
            ),
            (
                ["--public"],
                {
                    "action": "store_false",
                    "dest": "private_repo",
                    "help": "Create a public repository",
                },
            ),
            (
                ["--remote-org"],
                {
                    "action": "store",
                    "dest": "remote_org",
                    "required": False,
                    "help": "Remote organization name (e.g., GitHub org)",
                },
            ),
        ],
    )
    def create(self):
        load_hmd_env(override=False)
        args = {"skip_prompt": self.app.pargs.skip_prompt}

        if self.app.pargs.project_name:
            args.update({"project_name": self.app.pargs.project_name})

        if self.app.pargs.project_type:
            args.update({"project_type": self.app.pargs.project_type})

        # Parse --var KEY=VALUE into dict
        context_vars = {}
        for var in self.app.pargs.context_vars or []:
            if "=" in var:
                key, value = var.split("=", 1)
                context_vars[key] = value
        if context_vars:
            args.update({"context_vars": context_vars})

        from .hmd_cli_repo import create as do_create

        repo_dir, repo_info = do_create(**args)

        if repo_dir is None:
            return

        # Handle remote creation
        remote_type = self.app.pargs.remote_type
        if remote_type == "none":
            return

        remote_mgr = RemoteRepoManager(self.app)

        remote_mgr.create_remote(
            repo_dir=repo_dir,
            repo_info=repo_info,
            remote_type=remote_type,
            private=self.app.pargs.private_repo,
            org_name=self.app.pargs.remote_org,
        )

    @ex(
        help="adds technology to a git repository",
        arguments=[
            (
                ["-f", "--force"],
                {
                    "action": "store_const",
                    "const": True,
                    "dest": "force",
                    "default": False,
                },
            ),
            (
                ["--facet"],
                {
                    "action": "store",
                    "dest": "facets",
                    "required": False,
                    "nargs": "*",
                },
            ),
        ],
    )
    def add(self):
        load_hmd_env()
        args = {}

        repo_name = self.app.pargs.repo_name
        args.update(
            {
                "repo_name": repo_name,
                "facets": self.app.pargs.facets,
                "force": self.app.pargs.force,
            }
        )

        from .hmd_cli_repo import add as do_add

        do_add(**args)

    @ex(
        help="configures HMD environment variables",
        arguments=[],
    )
    def configure(self):
        load_hmd_env()

        remotes = RemoteRepoManager(self.app)

        questions = remotes.configure()

        results = prompt_for_values({**CONFIG_VALUES, **questions})

        from .hmd_cli_repo import config as do_config

        if results:
            do_config(results)

            for k, v in results.items():
                set_hmd_env(k, str(v))

    @ex(help="pull all available Git repos")
    def pull_all(self):
        load_hmd_env()
        from .hmd_cli_repo import pull_all as do_pull_all

        remotes = RemoteRepoManager(self.app)

        do_pull_all(remotes)

    @ex(help="create remote repository for a project")
    def create_remote(self):
        load_hmd_env()

        repo_dir = os.getcwd()

        manifest = read_manifest()
        repo_name = manifest["name"]
        repo_desc = manifest["description"]

        remotes = RemoteRepoManager(self.app)

        remotes.create_remote(
            repo_dir=repo_dir,
            repo_info={"project_name": repo_name, "description": repo_desc},
        )

    @ex(
        help="list available project type categories",
        arguments=[
            (
                ["--json"],
                {
                    "action": "store_true",
                    "dest": "output_json",
                    "default": False,
                    "help": "Output as JSON for machine consumption",
                },
            ),
        ],
    )
    def list_categories(self):
        """List all available project type categories."""
        loader = ProjectTypeLoader()
        categories = loader.list_project_type_categories()

        if self.app.pargs.output_json:
            print(json.dumps({"categories": categories}))
        else:
            print("Available project type categories:")
            for cat in categories:
                print(f"  - {cat}")

    @ex(
        help="list available project types",
        arguments=[
            (
                ["-c", "--category"],
                {
                    "action": "store",
                    "dest": "category",
                    "required": False,
                    "help": "Filter by category name",
                },
            ),
            (
                ["--json"],
                {
                    "action": "store_true",
                    "dest": "output_json",
                    "default": False,
                    "help": "Output as JSON for machine consumption",
                },
            ),
        ],
    )
    def list_types(self):
        """List all available project types, optionally filtered by category."""
        loader = ProjectTypeLoader()
        category = self.app.pargs.category
        types = loader.list_project_types(category=category)

        if self.app.pargs.output_json:
            output = {"project_types": types}
            if category:
                output["category"] = category
            print(json.dumps(output))
        else:
            if category:
                print(f"Available project types in '{category}':")
            else:
                print("Available project types:")
            for t in types:
                print(f"  - {t}")

    @ex(
        help="list available AI agent skills",
        arguments=[
            (
                ["--json"],
                {
                    "action": "store_true",
                    "dest": "output_json",
                    "default": False,
                    "help": "Output as JSON for machine consumption",
                },
            ),
        ],
    )
    def list_skills(self):
        """List all available AI agent skills with their metadata."""
        loader = SkillsLoader()
        skills = loader.list_skills()

        if self.app.pargs.output_json:
            # Remove internal _file field for clean JSON output
            clean_skills = [
                {k: v for k, v in s.items() if not k.startswith("_")} for s in skills
            ]
            print(json.dumps({"skills": clean_skills}))
        else:
            print("Available AI agent skills:")
            for skill in skills:
                name = skill.get("name", "unknown")
                desc = skill.get("description", "No description")
                version = skill.get("version", "")
                version_str = f" (v{version})" if version else ""
                print(f"  - {name}{version_str}: {desc}")

    @ex(
        help="install AI agent skills to a directory",
        arguments=[
            (
                ["destination"],
                {
                    "action": "store",
                    "nargs": "?",
                    "help": "Destination directory for skill installation",
                },
            ),
            (
                ["--skill", "-s"],
                {
                    "action": "store",
                    "dest": "skill_name",
                    "required": False,
                    "help": "Install only this specific skill",
                },
            ),
            (
                ["--list-destinations"],
                {
                    "action": "store_true",
                    "dest": "list_destinations",
                    "default": False,
                    "help": "Show common installation paths",
                },
            ),
            (
                ["--force", "-f"],
                {
                    "action": "store_true",
                    "dest": "force",
                    "default": False,
                    "help": "Overwrite existing skill files",
                },
            ),
        ],
    )
    def install_skills(self):
        """Install AI agent skills to a specified directory."""
        import shutil

        # Show common destinations if requested
        if self.app.pargs.list_destinations:
            home = os.path.expanduser("~")
            print("Common skill installation destinations:")
            print(f"  Claude Code:     {home}/.claude/commands/")
            print(f"  User scripts:    {home}/.local/share/ai-skills/")
            return

        destination = self.app.pargs.destination
        if not destination:
            print("Error: destination directory required")
            print("Usage: hmd repo install-skills <destination> [--skill <name>]")
            print("       hmd repo install-skills --list-destinations")
            return

        dest_path = Path(destination).expanduser().resolve()

        # Create destination if it doesn't exist
        if not dest_path.exists():
            dest_path.mkdir(parents=True, exist_ok=True)
            print(f"Created directory: {dest_path}")

        loader = SkillsLoader()
        skill_name = self.app.pargs.skill_name
        force = self.app.pargs.force

        if skill_name:
            # Install specific skill
            try:
                skill_path = loader.get_skill_path(skill_name)
                dest_file = dest_path / skill_path.name
                if dest_file.exists() and not force:
                    print(f"Skill already exists: {dest_file}")
                    print("Use --force to overwrite")
                    return
                shutil.copy2(skill_path, dest_file)
                print(f"Installed: {skill_path.name} -> {dest_file}")
            except FileNotFoundError as e:
                print(f"Error: {e}")
                return
        else:
            # Install all skills
            skills = loader.list_skills()
            installed = 0
            skipped = 0
            for skill in skills:
                skill_path = Path(skill["_file"])
                dest_file = dest_path / skill_path.name
                if dest_file.exists() and not force:
                    print(f"Skipped (exists): {skill_path.name}")
                    skipped += 1
                    continue
                shutil.copy2(skill_path, dest_file)
                print(f"Installed: {skill_path.name}")
                installed += 1

            print(f"\nInstalled {installed} skill(s), skipped {skipped}")
            if skipped > 0:
                print("Use --force to overwrite existing skills")
