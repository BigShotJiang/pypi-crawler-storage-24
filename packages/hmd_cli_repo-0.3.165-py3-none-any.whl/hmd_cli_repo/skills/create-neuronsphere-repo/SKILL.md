---
name: create-neuronsphere-repo
description: Create or extend NeuronSphere repositories with interactive guidance for project type selection
version: "1.0"
author: HMD Labs
disable-model-invocation: true
requires:
  - hmd-cli-repo
tags:
  - repository
  - scaffolding
  - neuronsphere
---

# NeuronSphere Repository Creator

Create or extend NeuronSphere repositories with interactive guidance for project type selection.

## Instructions

### Step 1: Discover Available Project Types

Use the CLI commands for discovery (preferred for non-interactive use):

```bash
# List all categories
hmd repo list-categories --json

# List all project types
hmd repo list-types --json

# List types in a specific category
hmd repo list-types -c "NeuronSphere Core" --json
```

Alternatively, query the Python API directly:

```bash
python -c "
from hmd_cli_repo.loaders.project_type_loader import ProjectTypeLoader
import json
l = ProjectTypeLoader()
types = {cat: l.list_project_types(cat) for cat in l.list_project_type_categories()}
print(json.dumps(types, indent=2))
"
```

### Step 2: Determine Mode

Check if you're in an existing NeuronSphere repository or need to create a new one:

1. Check for `meta-data/manifest.json` in the current directory
   - If it exists, you're in an existing repo - offer to add facets via `hmd repo add`
   - If not, proceed with creating a new repo via `hmd repo create`

2. If in an existing repo, read `meta-data/manifest.json` to see:
   - Current project type (`project_type.name`)
   - Installed facets (`project_type.facets`)

### Step 3: Understand User Requirements

Ask the user what they want to build. Listen for keywords that indicate the type of project:

- Backend services, APIs, microservices
- Libraries, shared code, utilities
- CLI tools, commands
- Infrastructure (Terraform, Kubernetes)
- Data transformations (dbt, ETL)
- Analytics (notebooks, SQL)
- Documentation

### Step 4: Recommend Project Type

Based on the user's description, recommend an appropriate project type using this guide:

| User Intent | Recommended Type | Repo Prefix |
|-------------|------------------|-------------|
| API, backend, REST service | Microservice | hmd-ms- |
| Service with custom schemas/types | Microservice With Language Pack | hmd-ms- |
| Shared Python library, utilities | Python Library | hmd-lib- |
| Schema definitions, data types | Language Pack | hmd-lang- |
| CLI tool, hmd command extension | CLI Command | hmd-cli- |
| Docker container, custom image | Docker Image | hmd-img- |
| Documentation | Documentation | hmd-docs- |
| Kubernetes Helm charts | Helm Repo Class | hmd-inf- |
| Terraform/CDKTF infrastructure | CDKTF Repo Class | hmd-inf- |
| Integration tests, RobotFramework | Bender Integration Tests | hmd-intg- |
| Content librarian service | Librarian | hmd-lib- |
| Librarian content types | Librarian Content Item Types | hmd-lib- |
| Template configuration | Mickey Configuration | hmd-config- |
| Template definitions | Mickey Templates | hmd-config- |
| Transform container image | Transform Image | hmd-img- |
| Transform configuration | Transform Config | hmd-config- |
| Cluster configuration | Cluster Config | hmd-config- |
| dbt data transformation | Dbt Transform | hmd-dbt- |
| Jupyter notebook transform | Notebook Transform | hmd-nb- |
| Jupyter analytics | Notebook Analytics | hmd-nb- |
| SQL-based analytics | SQL Analytics | hmd-sql- |

Present the recommendation with explanation, then ask for confirmation before proceeding.

### Step 5: Execute

**For new repositories (non-interactive - preferred for AI agents):**

```bash
# Fully non-interactive creation
hmd repo create -y \
  -t "Microservice" \
  -n hmd-ms-myservice \
  --var description="My microservice description" \
  --remote github \
  --remote-org myorg \
  --private

# Create without remote repository
hmd repo create -y \
  -t "CLI Command" \
  -n hmd-cli-mytool \
  --var description="My CLI tool" \
  --remote none
```

**For new repositories (interactive):**

1. Navigate to the directory where the new repo should be created
2. Run `hmd repo create`
3. Select the category when prompted
4. Select the project type when prompted
5. Fill in the cookiecutter prompts:
   - `short_name`: Brief identifier (e.g., "myservice") - combined with org prefix and repo type to form full name
   - `description`: Short description of the project
   - Other prompts vary by project type

**For adding facets to existing repos:**

1. Confirm you're in the repo root (where `meta-data/manifest.json` exists)
2. Run `hmd repo add --facet <facet_name>` for each facet to add
3. The command creates a feature branch, applies templates, and shows the diff

## Key Commands Reference

| Command | Purpose |
|---------|---------|
| `hmd repo create` | Interactive new repo creation |
| `hmd repo create -t "Type" -n name -y` | Non-interactive creation |
| `hmd repo create -t "Type" --var key=value -y` | With context variables |
| `hmd repo create --remote none -y` | Skip remote repository creation |
| `hmd repo create --remote github --private` | Create private GitHub repo |
| `hmd repo add --facet <name>` | Add template facet to existing repo |
| `hmd repo add -f` | Force add, skip prompts |
| `hmd repo configure` | Setup environment variables |
| `hmd repo create-remote` | Create remote repo for existing local repo |
| `hmd repo list-types --json` | List available project types |
| `hmd repo list-categories --json` | List project categories |
| `hmd repo list-skills --json` | List available skills |

## Naming Conventions

NeuronSphere repositories follow strict naming conventions:

| Prefix | Purpose | Example |
|--------|---------|---------|
| `hmd-ms-` | Microservices | hmd-ms-user-auth |
| `hmd-lib-` | Shared libraries | hmd-lib-common-utils |
| `hmd-cli-` | CLI commands | hmd-cli-deploy |
| `hmd-inf-` | Infrastructure (Terraform/Helm) | hmd-inf-eks-cluster |
| `hmd-docs-` | Documentation | hmd-docs-api-guide |
| `hmd-intg-` | Integration tests | hmd-intg-auth-tests |
| `hmd-img-` | Docker images | hmd-img-python-base |
| `hmd-lang-` | Language packs/schemas | hmd-lang-user-types |
| `hmd-config-` | Configuration repos | hmd-config-deploy |
| `hmd-ui-` | UI components | hmd-ui-dashboard |
| `hmd-client-` | Client components | hmd-client-sdk |

The full project name is typically: `{org_prefix}{repo_type}{short_name}`

## Cookiecutter Variables

Common prompts during repo creation:

| Variable | Description | Example |
|----------|-------------|---------|
| `short_name` | Brief project identifier | myservice |
| `description` | Project description | User authentication microservice |
| `_org` | Organization prefix (from env) | hmd- |
| `_author` | Author name (from env) | John Doe |
| `_author_email` | Author email (from env) | john@example.com |

Variables starting with `_` are typically auto-filled from environment or not prompted.

Pass custom variables using `--var key=value` flag (can be repeated).

## Environment Setup

If `hmd repo create` fails or prompts for configuration, the user may need to run:

```bash
hmd repo configure
```

This sets up:
- `HMD_REPO_ORG` - Organization prefix for repo names
- `HMD_AUTHOR_NAME` - Git author name
- `HMD_AUTHOR_EMAIL` - Git author email
- GitHub credentials (if using GitHub remote)

## Important Notes

- Always run `hmd repo create` from the parent directory where the new repo should be created
- The tool initializes git and creates an initial commit automatically
- Pre-commit hooks are configured (black, prettier, commitizen)
- Build with `hmd build` after creation
- Run tests with `hmd bender` (if tests exist)
- Follow conventional commit style for all commits
