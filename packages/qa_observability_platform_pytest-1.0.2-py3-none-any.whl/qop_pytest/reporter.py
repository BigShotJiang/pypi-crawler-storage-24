"""
QOP WebSocket Reporter for Pytest.
Sends test run events to QOP platform via WebSocket.
Auto-registered as a pytest plugin via entry_points (pytest11).
"""

import os
import glob as glob_module
import json
import time
import uuid
from datetime import datetime
from typing import Optional, List
from websocket import WebSocket, create_connection
from urllib.request import urlopen, Request
from urllib.error import URLError
import pytest
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass


class QopWebSocketReporter:
    def __init__(self):
        self.ws: Optional[WebSocket] = None
        self.is_open = False
        self.run_id: Optional[str] = None
        self.api_key: Optional[str] = None
        self.project_key: Optional[str] = None
        self.app_key: Optional[str] = None
        self.ws_url: Optional[str] = None
        self.api_base_url: Optional[str] = None
        self.buffered_messages: List[str] = []
        self.test_count = 0
        self.passed_count = 0
        self.failed_count = 0

    def pytest_sessionstart(self, session):
        self.api_key = os.getenv("QOP_API_KEY")
        self.app_key = os.getenv("QOP_APP_KEY", "default-app")
        self.api_base_url = os.getenv("QOP_API_BASE_URL", "http://localhost:4000")

        if not self.api_key:
            print("[QOP] QOP_API_KEY not set. Reporter disabled.")
            return

        self.run_id = f"run-{uuid.uuid4()}"
        print(f"[QOP] Reporter generated runId: {self.run_id}")
        os.environ["QOP_RUN_ID"] = self.run_id

        # Check if explicit WebSocket URL is provided (legacy mode)
        explicit_ws_url = os.getenv("QOP_WS_URL")

        if explicit_ws_url:
            # LEGACY MODE: use explicit wsUrl with query params
            ws_base_url = explicit_ws_url
            if not ws_base_url.endswith("/ws/ingest"):
                ws_base_url = ws_base_url.rstrip("/") + "/ws/ingest"

            self.project_key = os.getenv("QOP_PROJECT_KEY", "default-project")
            self.ws_url = f"{ws_base_url}?apiKey={self.api_key}&projectKey={self.project_key}&appKey={self.app_key}&runnerType=pytest"

            try:
                print(f"[QOP] Connecting to: {ws_base_url}")
                self.ws = create_connection(self.ws_url)
                self.is_open = True
                print("[QOP] WS connected")
            except Exception as e:
                print(f"[QOP] Failed to connect to WebSocket: {e}")
                self.is_open = False
                return
        else:
            # NEW MODE: validate API key first, then connect with session token
            if not self._connect_via_validate_key():
                return

        # Flush buffered messages
        for msg in self.buffered_messages:
            self.ws.send(msg)
        self.buffered_messages.clear()

        total_tests = session.testscollected
        self.test_count = total_tests

        ci_meta = self._resolve_ci_metadata()

        self.send_event('run_started', {
            'projectNames': ['pytest-project'],
            'totalTests': total_tests,
            'branch': ci_meta.get('branch'),
            'commitSha': ci_meta.get('commitSha'),
            'ciBuildNumber': ci_meta.get('ciBuildNumber'),
            'environment': ci_meta.get('environment'),
        })

    def _connect_via_validate_key(self) -> bool:
        """Validate API key and connect via session token. Returns True on success."""
        print("[QOP] Validating API key...")

        payload = json.dumps({
            "apiKey": self.api_key,
            "appKey": self.app_key,
            "runnerType": "pytest",
        }).encode("utf-8")

        try:
            req = Request(
                f"{self.api_base_url}/auth/validate-key",
                data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            resp = urlopen(req, timeout=5)

            if resp.status != 200:
                print(f"[QOP] API key validation failed ({resp.status}). Reporter disabled.")
                print("[QOP] Tests will run normally without QOP reporting.")
                return False

            data = json.loads(resp.read().decode("utf-8"))
            print(f"[QOP] \u2713 API key validated (project: {data.get('projectKey', 'unknown')})")

            if data.get("apiBaseUrl"):
                self.api_base_url = data["apiBaseUrl"]

            # Connect WebSocket using session token
            ws_url = data["wsUrl"]
            session_token = data["sessionToken"]
            separator = "&" if "?" in ws_url else "?"
            self.ws_url = f"{ws_url}{separator}sessionToken={session_token}&appKey={self.app_key}&runnerType=pytest"

            self.ws = create_connection(self.ws_url)
            self.is_open = True
            print("[QOP] \u2713 Connected. Streaming test results...")
            return True

        except URLError as e:
            print("[QOP] Could not connect to QOP server. Tests will run without reporting.")
            print(f"[QOP] Error: {e}")
            self.is_open = False
            return False
        except Exception as e:
            print(f"[QOP] Failed to validate API key: {e}")
            self.is_open = False
            return False

    def pytest_runtest_logstart(self, nodeid, location):
        test_id = nodeid
        title = nodeid.split("::")[-1] if "::" in nodeid else nodeid
        full_title = nodeid.replace("::", " > ")
        file_path = location[0] if location else nodeid.split("::")[0]

        self.send_event('test_started', {
            'testId': test_id,
            'title': title,
            'fullTitle': full_title,
            'file': file_path,
        })

    def pytest_runtest_logreport(self, report):
        if report.when == "call":
            test_id = report.nodeid
            title = test_id.split("::")[-1] if "::" in test_id else test_id
            full_title = test_id.replace("::", " > ")
            file_path = test_id.split("::")[0]

            if report.passed:
                self.passed_count += 1
                status = "passed"
                error_payload = None
            elif report.failed:
                self.failed_count += 1
                status = "failed"
                error_payload = {
                    'message': str(report.longrepr).split('\n')[-1] if report.longrepr else "Test failed",
                    'stack': str(report.longrepr) if report.longrepr else "",
                }
            else:
                status = "skipped"
                error_payload = None

            self.send_event('test_finished', {
                'testId': test_id,
                'title': title,
                'fullTitle': full_title,
                'file': file_path,
                'status': status,
                'durationMs': int(report.duration * 1000),
                'error': error_payload,
            })

            if status == 'failed' and self.run_id and self.api_key:
                self._upload_screenshots_for_test(title)

    def _upload_screenshots_for_test(self, test_name: str):
        """Find screenshots matching the test name and upload them to QOP."""
        screenshots_dir = os.getenv("QOP_SCREENSHOTS_DIR", "screenshots")
        if not os.path.exists(screenshots_dir):
            return

        # Small delay to let the server create the execution record
        time.sleep(0.3)

        normalized = test_name.lower().replace(" ", "_")
        pattern = os.path.join(screenshots_dir, "**", "*.png")
        all_screenshots = glob_module.glob(pattern, recursive=True)

        for screenshot_path in all_screenshots:
            filename = os.path.basename(screenshot_path).lower()
            if normalized in filename or test_name.lower() in filename:
                try:
                    import urllib.request as urllib_req
                    import urllib.parse

                    upload_url = f"{self.api_base_url}/api/screenshots/upload-by-run"

                    boundary = uuid.uuid4().hex
                    with open(screenshot_path, 'rb') as f:
                        file_data = f.read()

                    body_parts = [
                        f'--{boundary}\r\nContent-Disposition: form-data; name="run_id"\r\n\r\n{self.run_id}'.encode(),
                        f'--{boundary}\r\nContent-Disposition: form-data; name="test_key"\r\n\r\n{test_name}'.encode(),
                        f'--{boundary}\r\nContent-Disposition: form-data; name="screenshot_type"\r\n\r\nfailure'.encode(),
                        (
                            f'--{boundary}\r\nContent-Disposition: form-data; name="screenshot"; '
                            f'filename="{os.path.basename(screenshot_path)}"\r\n'
                            f'Content-Type: image/png\r\n\r\n'
                        ).encode() + file_data,
                        f'--{boundary}--'.encode(),
                    ]
                    body = b'\r\n'.join(body_parts)

                    req = urllib_req.Request(
                        upload_url,
                        data=body,
                        headers={
                            'Content-Type': f'multipart/form-data; boundary={boundary}',
                            'Content-Length': str(len(body)),
                            'x-api-key': self.api_key,
                        },
                        method='POST',
                    )
                    resp = urllib_req.urlopen(req, timeout=10)
                    if resp.status == 201:
                        print(f"[QOP] Screenshot uploaded: {os.path.basename(screenshot_path)}")
                    else:
                        print(f"[QOP] Screenshot upload failed: {resp.status}")
                except Exception as e:
                    print(f"[QOP] Error uploading screenshot: {e}")

    def pytest_sessionfinish(self, session, exitstatus):
        if not self.is_open:
            return

        self.send_event('run_finished', {})

        import time
        time.sleep(0.5)
        if self.ws:
            self.ws.close()
            print("[QOP] WS connection closed")

    def send_event(self, event: str, payload: dict):
        if not self.ws and not self.is_open:
            return

        message = {
            'event': event,
            'runId': self.run_id,
            'timestamp': datetime.now().isoformat(),
            **payload
        }

        message_json = json.dumps(message)

        try:
            if self.is_open and self.ws:
                self.ws.send(message_json)
            else:
                self.buffered_messages.append(message_json)
        except Exception as e:
            print(f"[QOP] Error sending event {event}: {e}")

    def _resolve_ci_metadata(self) -> dict:
        return {
            'branch': os.getenv('QOP_BRANCH') or os.getenv('GITHUB_REF_NAME') or os.getenv('BUILD_SOURCEBRANCHNAME') or os.getenv('CI_COMMIT_REF_NAME'),
            'commitSha': os.getenv('QOP_COMMIT_SHA') or os.getenv('GITHUB_SHA') or os.getenv('BUILD_SOURCEVERSION') or os.getenv('CI_COMMIT_SHA'),
            'ciBuildNumber': os.getenv('QOP_BUILD_NUMBER') or os.getenv('GITHUB_RUN_NUMBER') or os.getenv('BUILD_BUILDNUMBER') or os.getenv('CI_PIPELINE_IID'),
            'environment': os.getenv('QOP_ENVIRONMENT') or os.getenv('NODE_ENV') or os.getenv('ENVIRONMENT') or os.getenv('DEPLOY_ENV'),
        }


# Global reporter instance
_reporter = None


def pytest_configure(config):
    """Auto-register the WebSocket reporter plugin."""
    global _reporter
    api_key = os.getenv("QOP_API_KEY")

    # Only QOP_API_KEY is required now (QOP_APP_KEY defaults to 'default-app')
    if api_key:
        _reporter = QopWebSocketReporter()
        config.pluginmanager.register(_reporter, "qop_ws_reporter")
        print("[QOP] WebSocket reporter enabled")
    else:
        print("[QOP] QOP_API_KEY not set. Reporter disabled.")


def pytest_unconfigure(config):
    global _reporter
    if _reporter:
        config.pluginmanager.unregister(_reporter)
