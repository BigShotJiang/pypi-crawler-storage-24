"""syntaqlite MCP server."""
