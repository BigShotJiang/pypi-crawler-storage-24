"""cc-plugin-catalog: Static site generator for Claude Code Plugin Marketplace."""

__version__ = "1.1.0"
