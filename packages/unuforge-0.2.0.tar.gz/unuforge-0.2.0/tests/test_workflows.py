from __future__ import annotations

from pathlib import Path
import unittest


ROOT = Path(__file__).resolve().parents[1]
CI_WORKFLOW = ROOT / ".github" / "workflows" / "ci.yml"
RELEASE_WORKFLOW = ROOT / ".github" / "workflows" / "release.yml"
INSTALLED_PACKAGE_ADVISORY_WORKFLOW = ROOT / ".github" / "workflows" / "installed-package-advisory.yml"


class WorkflowContractTests(unittest.TestCase):
    def test_ci_workflow_contract(self) -> None:
        self.assertTrue(CI_WORKFLOW.exists(), CI_WORKFLOW)

        workflow_text = CI_WORKFLOW.read_text(encoding="utf-8")
        self.assertIn("jobs:\n  test:\n    runs-on: ubuntu-latest", workflow_text)
        self.assertEqual(workflow_text.count("\n  test:"), 1)
        self.assertIn(
            "  consumer-contract:\n    runs-on: ubuntu-latest\n    needs: test",
            workflow_text,
        )
        self.assertEqual(workflow_text.count("\n  consumer-contract:"), 1)
        self.assertIn("pull_request:", workflow_text)
        self.assertIn("push:\n    branches:\n      - main", workflow_text)
        self.assertIn("- uses: actions/checkout@v5", workflow_text)
        self.assertIn("- uses: actions/setup-python@v6", workflow_text)
        self.assertIn('python-version: "3.11"', workflow_text)
        self.assertIn("repository: unundoTeam/unudispatch", workflow_text)
        self.assertIn("repository: unundoTeam/unuidentity", workflow_text)
        self.assertIn("repository: unundoTeam/unuvault", workflow_text)
        self.assertIn("CROSS_REPO_READ_TOKEN", workflow_text)
        self.assertIn("path: consumers/unudispatch", workflow_text)
        self.assertIn("path: consumers/unuidentity", workflow_text)
        self.assertIn("path: consumers/unuvault", workflow_text)
        self.assertIn("UNUDISPATCH_REPO_ROOT", workflow_text)
        self.assertIn("UNUIDENTITY_REPO_ROOT", workflow_text)
        self.assertIn("UNUVAULT_REPO_ROOT", workflow_text)
        self.assertIn(
            "python3 scripts/verify_consumer_contracts.py --consumer all",
            workflow_text,
        )
        self.assertIn(
            "PYTHONPATH=src python3 -m unittest discover -s tests",
            workflow_text,
        )

    def test_release_workflow_contract(self) -> None:
        self.assertTrue(RELEASE_WORKFLOW.exists(), RELEASE_WORKFLOW)

        workflow_text = RELEASE_WORKFLOW.read_text(encoding="utf-8")
        self.assertEqual(workflow_text.count("\n  build:"), 1)
        self.assertEqual(workflow_text.count("\n  installed-package-consumers:"), 1)
        self.assertEqual(workflow_text.count("\n  publish-pypi:"), 1)
        self.assertEqual(workflow_text.count("\n  github-release:"), 1)
        self.assertIn('tags:\n      - "v*"', workflow_text)
        self.assertIn("fetch-depth: 0", workflow_text)
        self.assertIn("permissions:\n      contents: read", workflow_text)
        self.assertIn("permissions:\n      id-token: write", workflow_text)
        self.assertIn("environment: pypi", workflow_text)
        self.assertIn("git fetch origin main:refs/remotes/origin/main", workflow_text)
        self.assertIn('git merge-base --is-ancestor "$GITHUB_SHA" origin/main', workflow_text)
        self.assertIn("- uses: actions/setup-python@v6", workflow_text)
        self.assertIn("PYTHONPATH=src python3 -m unittest discover -s tests", workflow_text)
        self.assertIn("needs: build", workflow_text)
        self.assertIn(
            "  installed-package-consumers:\n    needs: build",
            workflow_text,
        )
        self.assertIn("repository: unundoTeam/unuidentity", workflow_text)
        self.assertIn("repository: unundoTeam/unundo_test", workflow_text)
        self.assertIn("CROSS_REPO_READ_TOKEN", workflow_text)
        self.assertIn("path: consumers/unuidentity", workflow_text)
        self.assertIn("path: consumers/unundo", workflow_text)
        self.assertIn("UNUIDENTITY_REPO_ROOT", workflow_text)
        self.assertIn("UNUNDO_REPO_ROOT", workflow_text)
        self.assertIn(
            "python3 scripts/verify_installed_package_consumers.py --consumer all --wheel",
            workflow_text,
        )
        self.assertIn(
            "needs:\n      - build\n      - installed-package-consumers",
            workflow_text,
        )
        self.assertIn(
            "needs:\n      - build\n      - installed-package-consumers\n      - publish-pypi",
            workflow_text,
        )
        self.assertIn(
            "uses: actions/upload-artifact@v4\n        with:\n          name: release-dist",
            workflow_text,
        )
        self.assertEqual(workflow_text.count("uses: actions/download-artifact@v5"), 3)
        self.assertEqual(workflow_text.count("name: release-dist"), 4)
        self.assertIn("pypa/gh-action-pypi-publish@release/v1", workflow_text)
        self.assertIn("gh release create", workflow_text)
        self.assertIn("permissions:\n      contents: write", workflow_text)
        self.assertIn("GH_REPO: ${{ github.repository }}", workflow_text)
        self.assertIn("find dist -maxdepth 1 -name '*.whl' -type f | wc -l", workflow_text)
        self.assertIn("Expected exactly one wheel in dist/", workflow_text)
        self.assertIn("python3 scripts/release_metadata.py --assert-tag", workflow_text)
        self.assertIn("python3 scripts/smoke_installed_package.py --wheel", workflow_text)

    def test_installed_package_advisory_workflow_contract(self) -> None:
        self.assertTrue(
            INSTALLED_PACKAGE_ADVISORY_WORKFLOW.exists(),
            INSTALLED_PACKAGE_ADVISORY_WORKFLOW,
        )

        workflow_text = INSTALLED_PACKAGE_ADVISORY_WORKFLOW.read_text(encoding="utf-8")
        self.assertIn("push:\n    branches:\n      - main", workflow_text)
        self.assertIn("workflow_dispatch:", workflow_text)
        self.assertIn("- uses: actions/checkout@v5", workflow_text)
        self.assertIn("- uses: actions/setup-python@v6", workflow_text)
        self.assertIn('python-version: "3.11"', workflow_text)
        self.assertIn("python3 scripts/build_distribution.py --out-dir dist --json", workflow_text)
        self.assertIn("repository: unundoTeam/unuidentity", workflow_text)
        self.assertIn("repository: unundoTeam/unundo_test", workflow_text)
        self.assertIn("path: consumers/unuidentity", workflow_text)
        self.assertIn("path: consumers/unundo", workflow_text)
        self.assertIn("UNUIDENTITY_REPO_ROOT", workflow_text)
        self.assertIn("UNUNDO_REPO_ROOT", workflow_text)
        self.assertIn(
            "python3 scripts/verify_installed_package_consumers.py --consumer all --wheel",
            workflow_text,
        )


if __name__ == "__main__":
    unittest.main()
