def main():
    print("Hello from fond-lang!")


if __name__ == "__main__":
    main()
