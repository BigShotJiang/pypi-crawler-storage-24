"""REST API using FastAPI."""
