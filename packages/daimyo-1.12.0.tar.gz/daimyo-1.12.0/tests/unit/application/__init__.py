"""Application service tests."""
