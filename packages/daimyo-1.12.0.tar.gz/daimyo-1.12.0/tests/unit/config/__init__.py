"""Configuration unit tests."""
