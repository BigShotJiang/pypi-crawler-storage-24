"""Remote client abstractions."""
