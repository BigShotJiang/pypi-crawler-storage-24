"""Tests for the Avalara service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.avalara import AvalaraClient
from augur_api.services.avalara.client import RatesResource

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "avalara"
    return http


class TestAvalaraClient:
    """Tests for AvalaraClient lazy property initialisation."""

    def test_rates(self) -> None:
        client = AvalaraClient(mock_http())
        assert isinstance(client.rates, RatesResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = AvalaraClient(mock_http())
        first = client.rates
        second = client.rates
        assert first is second


class TestRatesResource:
    """Tests for /rates endpoints."""

    def test_create(self) -> None:
        http = mock_http()
        r = RatesResource(http)
        result = r.create(data={"lines": [{"amount": 100}]})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/rates"
        assert result.status == 200
