"""Tests for the Payments service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.payments import PaymentsClient
from augur_api.services.payments.client import (
    ElementResource,
    MonerisResource,
    PaytraceResource,
    UnifiedResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "payments"
    return http


class TestPaymentsClient:
    """Tests for PaymentsClient lazy property initialisation."""

    def test_element(self, mock_http: MagicMock) -> None:
        client = PaymentsClient(mock_http)
        assert isinstance(client.element, ElementResource)

    def test_moneris(self, mock_http: MagicMock) -> None:
        client = PaymentsClient(mock_http)
        assert isinstance(client.moneris, MonerisResource)

    def test_paytrace(self, mock_http: MagicMock) -> None:
        client = PaymentsClient(mock_http)
        assert isinstance(client.paytrace, PaytraceResource)

    def test_unified(self, mock_http: MagicMock) -> None:
        client = PaymentsClient(mock_http)
        assert isinstance(client.unified, UnifiedResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        client = PaymentsClient(mock_http)
        first = client.element
        second = client.element
        assert first is second


class TestElementResource:
    """Tests for /element endpoints."""

    def test_create_payment(self, mock_http: MagicMock) -> None:
        r = ElementResource(mock_http)
        r.create_payment(data={"amount": 100})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/element/payment"


class TestMonerisResource:
    """Tests for /moneris endpoints."""

    def test_list_pre_auth(self, mock_http: MagicMock) -> None:
        r = MonerisResource(mock_http)
        r.list_pre_auth()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/moneris/pre-auth"

    def test_list_pre_auth_complete(self, mock_http: MagicMock) -> None:
        r = MonerisResource(mock_http)
        r.list_pre_auth_complete()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/moneris/pre-auth-complete"


class TestPaytraceResource:
    """Tests for /paytrace endpoints."""

    def test_create_authorization(self, mock_http: MagicMock) -> None:
        r = PaytraceResource(mock_http)
        r.create_authorization(data={"amount": 100})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/paytrace/authorization"

    def test_create_capture(self, mock_http: MagicMock) -> None:
        r = PaytraceResource(mock_http)
        r.create_capture(data={"transactionId": "123"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/paytrace/capture"

    def test_create_refund(self, mock_http: MagicMock) -> None:
        r = PaytraceResource(mock_http)
        r.create_refund(data={"transactionId": "123"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/paytrace/refund"

    def test_create_sale(self, mock_http: MagicMock) -> None:
        r = PaytraceResource(mock_http)
        r.create_sale(data={"amount": 100})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/paytrace/sale"

    def test_create_void(self, mock_http: MagicMock) -> None:
        r = PaytraceResource(mock_http)
        r.create_void(data={"transactionId": "123"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/paytrace/void"


class TestUnifiedResource:
    """Tests for /unified endpoints."""

    def test_list_account_query(self, mock_http: MagicMock) -> None:
        r = UnifiedResource(mock_http)
        r.list_account_query()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/unified/account-query"

    def test_list_billing_update(self, mock_http: MagicMock) -> None:
        r = UnifiedResource(mock_http)
        r.list_billing_update()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/unified/billing-update"

    def test_list_card_info(self, mock_http: MagicMock) -> None:
        r = UnifiedResource(mock_http)
        r.list_card_info()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/unified/card-info"

    def test_list_surcharge(self, mock_http: MagicMock) -> None:
        r = UnifiedResource(mock_http)
        r.list_surcharge()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/unified/surcharge"

    def test_list_transaction_setup(self, mock_http: MagicMock) -> None:
        r = UnifiedResource(mock_http)
        r.list_transaction_setup()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/unified/transaction-setup"

    def test_list_validate(self, mock_http: MagicMock) -> None:
        r = UnifiedResource(mock_http)
        r.list_validate()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/unified/validate"


class TestResponseValidation:
    """Verify BaseResponse[Any] is returned correctly."""

    def test_list_returns_base_response(self, mock_http: MagicMock) -> None:
        r = UnifiedResource(mock_http)
        result = r.list_account_query()
        assert result.status == 200
        assert result.message == "Success"
