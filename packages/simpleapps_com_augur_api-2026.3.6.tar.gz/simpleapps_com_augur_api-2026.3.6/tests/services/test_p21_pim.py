"""Tests for the P21 PIM service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.p21_pim import P21PimClient
from augur_api.services.p21_pim.client import (
    InvMastExtResource,
    ItemsResource,
    PodcastsResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "p21-pim"
    return http


class TestP21PimClient:
    """Tests for P21PimClient lazy property initialisation."""

    def test_inv_mast_ext(self) -> None:
        client = P21PimClient(mock_http())
        assert isinstance(client.inv_mast_ext, InvMastExtResource)

    def test_items(self) -> None:
        client = P21PimClient(mock_http())
        assert isinstance(client.items, ItemsResource)

    def test_podcasts(self) -> None:
        client = P21PimClient(mock_http())
        assert isinstance(client.podcasts, PodcastsResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = P21PimClient(mock_http())
        assert client.inv_mast_ext is client.inv_mast_ext
        assert client.items is client.items
        assert client.podcasts is client.podcasts


class TestInvMastExtResource:
    """Tests for /inv-mast-ext endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = InvMastExtResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/inv-mast-ext"
        assert result.status == 200

    def test_create(self) -> None:
        http = mock_http()
        r = InvMastExtResource(http)
        result = r.create(data={"test": True})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/inv-mast-ext"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = InvMastExtResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/inv-mast-ext/1"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = InvMastExtResource(http)
        result = r.update(1, data={"test": True})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/inv-mast-ext/1"
        assert result.status == 200

    def test_delete(self) -> None:
        http = mock_http()
        r = InvMastExtResource(http)
        result = r.delete(1)
        http.delete.assert_called_once()
        assert http.delete.call_args[0][0] == "/inv-mast-ext/1"
        assert result.status == 200


class TestItemsResource:
    """Tests for /items endpoints."""

    def test_list_suggest_display_desc(self) -> None:
        http = mock_http()
        r = ItemsResource(http)
        result = r.list_suggest_display_desc(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/items/1/suggest-display-desc"
        assert result.status == 200

    def test_list_suggest_web_desc(self) -> None:
        http = mock_http()
        r = ItemsResource(http)
        result = r.list_suggest_web_desc(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/items/1/suggest-web-desc"
        assert result.status == 200


class TestPodcastsResource:
    """Tests for /podcasts endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = PodcastsResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/podcasts"
        assert result.status == 200

    def test_create(self) -> None:
        http = mock_http()
        r = PodcastsResource(http)
        result = r.create(data={"test": True})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/podcasts"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = PodcastsResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/podcasts/1"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = PodcastsResource(http)
        result = r.update(1, data={"test": True})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/podcasts/1"
        assert result.status == 200

    def test_delete(self) -> None:
        http = mock_http()
        r = PodcastsResource(http)
        result = r.delete(1)
        http.delete.assert_called_once()
        assert http.delete.call_args[0][0] == "/podcasts/1"
        assert result.status == 200
