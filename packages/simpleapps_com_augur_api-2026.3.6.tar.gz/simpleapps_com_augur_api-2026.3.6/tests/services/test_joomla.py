"""Tests for the Joomla service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.joomla import JoomlaClient
from augur_api.services.joomla.client import (
    CategoriesResource,
    ContentResource,
    MenuResource,
    TagsResource,
    UsergroupsResource,
    UsersResource,
)
from augur_api.services.joomla.schemas import (
    Category,
    CategoryCreateParams,
    CategoryListParams,
    Content,
    ContentCreateParams,
    ContentListParams,
    ContentUpdateParams,
    Extension,
    ExtensionListParams,
    HealthCheckData,
    Menu,
    MenuListParams,
    Tag,
    TagListParams,
    TrinityUser,
    User,
    UserCreateParams,
    UserDocParams,
    UserGroup,
    Usergroup,
    UserGroupCreateParams,
    UserGroupListParams,
    UsergroupsListParams,
    UserListParams,
    UserUpdateParams,
    VerifyPasswordParams,
    VerifyPasswordResult,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "joomla"
    return http


# ============================================================================
# JoomlaClient — lazy property access
# ============================================================================


class TestJoomlaClient:
    """Tests for JoomlaClient lazy property initialisation."""

    def test_categories(self, mock_http: MagicMock) -> None:
        client = JoomlaClient(mock_http)
        assert isinstance(client.categories, CategoriesResource)

    def test_content(self, mock_http: MagicMock) -> None:
        client = JoomlaClient(mock_http)
        assert isinstance(client.content, ContentResource)

    def test_menu(self, mock_http: MagicMock) -> None:
        client = JoomlaClient(mock_http)
        assert isinstance(client.menu, MenuResource)

    def test_tags(self, mock_http: MagicMock) -> None:
        client = JoomlaClient(mock_http)
        assert isinstance(client.tags, TagsResource)

    def test_usergroups(self, mock_http: MagicMock) -> None:
        client = JoomlaClient(mock_http)
        assert isinstance(client.usergroups, UsergroupsResource)

    def test_users(self, mock_http: MagicMock) -> None:
        client = JoomlaClient(mock_http)
        assert isinstance(client.users, UsersResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        """Accessing the same property twice returns the same instance."""
        client = JoomlaClient(mock_http)
        first = client.users
        second = client.users
        assert first is second


# ============================================================================
# CategoriesResource
# ============================================================================


class TestCategoriesResource:
    """Tests for /categories endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = CategoriesResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/categories"
        assert result.status == 200

    def test_get(self, mock_http: MagicMock) -> None:
        r = CategoriesResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/categories/1"


# ============================================================================
# ContentResource
# ============================================================================


class TestContentResource:
    """Tests for /content endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = ContentResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/content"
        assert result.status == 200

    def test_get(self, mock_http: MagicMock) -> None:
        r = ContentResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/content/1"

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = ContentResource(mock_http)
        r.list_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/content/1/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        r = ContentResource(mock_http)
        r.get_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/content/1/doc"


# ============================================================================
# MenuResource
# ============================================================================


class TestMenuResource:
    """Tests for /menu endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = MenuResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/menu"
        assert result.status == 200

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = MenuResource(mock_http)
        r.list_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/menu/1/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        r = MenuResource(mock_http)
        r.get_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/menu/1/doc"


# ============================================================================
# TagsResource
# ============================================================================


class TestTagsResource:
    """Tests for /tags endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = TagsResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/tags"
        assert result.status == 200


# ============================================================================
# UsergroupsResource
# ============================================================================


class TestUsergroupsResource:
    """Tests for /usergroups endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = UsergroupsResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/usergroups"
        assert result.status == 200


# ============================================================================
# UsersResource
# ============================================================================


class TestUsersResource:
    """Tests for /users endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/users"
        assert result.status == 200

    def test_create(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/users"

    def test_create_verify_password(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.create_verify_password(data={"username": "user", "password": "pass"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/users/verify-password"

    def test_get(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/users/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/users/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/users/1"

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.list_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/users/1/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.get_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/users/1/doc"

    def test_list_groups(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.list_groups(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/users/1/groups"

    def test_create_groups(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.create_groups(1, data={"groupId": 5})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/users/1/groups"

    def test_get_groups(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.get_groups(group_id=2, id=1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/users/1/groups/2"

    def test_list_trinity(self, mock_http: MagicMock) -> None:
        r = UsersResource(mock_http)
        r.list_trinity(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/users/1/trinity"


# ============================================================================
# Schema tests
# ============================================================================


class TestJoomlaSchemas:
    """Tests for Joomla schemas."""

    def test_health_check_data(self) -> None:
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_user_list_params(self) -> None:
        params = UserListParams(limit=10, offset=5, q="john")
        assert params.limit == 10
        assert params.q == "john"

    def test_user_model(self) -> None:
        data = {"id": 1, "name": "John Doe", "username": "johnd", "email": "john@test.com"}
        result = User.model_validate(data)
        assert result.id == 1
        assert result.name == "John Doe"

    def test_user_create_params(self) -> None:
        params = UserCreateParams(name="John", username="johnd", email="john@test.com")
        assert params.name == "John"

    def test_user_update_params(self) -> None:
        params = UserUpdateParams(name="Updated Name")
        assert params.name == "Updated Name"

    def test_user_doc_params(self) -> None:
        params = UserDocParams(include_ship_to="Y")
        assert params.include_ship_to == "Y"

    def test_content_model(self) -> None:
        data = {"id": 1, "title": "Article", "alias": "article"}
        result = Content.model_validate(data)
        assert result.title == "Article"

    def test_content_list_params(self) -> None:
        params = ContentListParams(limit=10, q="search")
        assert params.limit == 10

    def test_content_create_params(self) -> None:
        params = ContentCreateParams(title="New", catid=1)
        assert params.title == "New"

    def test_content_update_params(self) -> None:
        params = ContentUpdateParams(title="Updated")
        assert params.title == "Updated"

    def test_category_model(self) -> None:
        data = {"id": 1, "title": "Category", "alias": "category"}
        result = Category.model_validate(data)
        assert result.title == "Category"

    def test_category_list_params(self) -> None:
        params = CategoryListParams(limit=10, extension="com_content")
        assert params.extension == "com_content"

    def test_category_create_params(self) -> None:
        params = CategoryCreateParams(title="New Category")
        assert params.title == "New Category"

    def test_extension_model(self) -> None:
        data = {"extensionId": 1, "name": "Extension", "type": "component"}
        result = Extension.model_validate(data)
        assert result.name == "Extension"

    def test_extension_list_params(self) -> None:
        params = ExtensionListParams(limit=10, type="component")
        assert params.type == "component"

    def test_tag_model(self) -> None:
        data = {"id": 1, "title": "Tag", "alias": "tag"}
        result = Tag.model_validate(data)
        assert result.title == "Tag"

    def test_tag_list_params(self) -> None:
        params = TagListParams(limit=10, q="search")
        assert params.q == "search"

    def test_menu_model(self) -> None:
        data = {"id": 1, "title": "Menu Item", "alias": "menu-item", "menutype": "mainmenu"}
        result = Menu.model_validate(data)
        assert result.title == "Menu Item"

    def test_menu_list_params(self) -> None:
        params = MenuListParams(limit=10, menutype="mainmenu")
        assert params.menutype == "mainmenu"

    def test_usergroups_list_params(self) -> None:
        params = UsergroupsListParams(order_by="title")
        assert params.order_by == "title"

    def test_usergroup_model(self) -> None:
        data = {"id": 1, "parentId": 0, "title": "Registered"}
        result = Usergroup.model_validate(data)
        assert result.title == "Registered"

    def test_verify_password_params(self) -> None:
        params = VerifyPasswordParams(username="user", password="pass")
        assert params.username == "user"

    def test_verify_password_result(self) -> None:
        data = {"id": 1, "isVerified": True, "username": "user"}
        result = VerifyPasswordResult.model_validate(data)
        assert result.is_verified is True

    def test_user_group_model(self) -> None:
        data = {"userId": 1, "groupId": 2, "groupTitle": "Admin"}
        result = UserGroup.model_validate(data)
        assert result.group_id == 2

    def test_user_group_list_params(self) -> None:
        params = UserGroupListParams(limit=10, offset=0)
        assert params.limit == 10

    def test_user_group_create_params(self) -> None:
        params = UserGroupCreateParams(group_id=5)
        assert params.group_id == 5

    def test_trinity_user_model(self) -> None:
        data = {"id": 1, "name": "John", "customerId": 123}
        result = TrinityUser.model_validate(data)
        assert result.customer_id == 123
