"""Tests for the Logistics service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.logistics import LogisticsClient
from augur_api.services.logistics.client import (
    ShipviaResource,
    SpeedshipResource,
    UpsResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "logistics"
    return http


class TestLogisticsClient:
    """Tests for LogisticsClient lazy property initialisation."""

    def test_shipvia(self) -> None:
        client = LogisticsClient(mock_http())
        assert isinstance(client.shipvia, ShipviaResource)

    def test_speedship(self) -> None:
        client = LogisticsClient(mock_http())
        assert isinstance(client.speedship, SpeedshipResource)

    def test_ups(self) -> None:
        client = LogisticsClient(mock_http())
        assert isinstance(client.ups, UpsResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = LogisticsClient(mock_http())
        assert client.shipvia is client.shipvia
        assert client.speedship is client.speedship
        assert client.ups is client.ups


class TestShipviaResource:
    """Tests for /shipvia endpoints."""

    def test_list_rates(self) -> None:
        http = mock_http()
        r = ShipviaResource(http)
        result = r.list_rates()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/shipvia/rates"
        assert result.status == 200

    def test_list_rates_ltl(self) -> None:
        http = mock_http()
        r = ShipviaResource(http)
        result = r.list_rates_ltl()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/shipvia/rates/ltl"
        assert result.status == 200


class TestSpeedshipResource:
    """Tests for /speedship endpoints."""

    def test_list_freight(self) -> None:
        http = mock_http()
        r = SpeedshipResource(http)
        result = r.list_freight()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/speedship/freight"
        assert result.status == 200


class TestUpsResource:
    """Tests for /ups endpoints."""

    def test_list_rates(self) -> None:
        http = mock_http()
        r = UpsResource(http)
        result = r.list_rates()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/ups/rates"
        assert result.status == 200
