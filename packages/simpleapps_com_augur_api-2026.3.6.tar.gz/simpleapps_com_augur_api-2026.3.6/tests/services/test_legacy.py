"""Tests for the Legacy service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.legacy import LegacyClient
from augur_api.services.legacy.client import (
    InvMastResource,
    ItemCategoryResource,
    LegacyResource,
    OrdersResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "legacy"
    return http


class TestLegacyClient:
    def test_inv_mast(self, mock_http: MagicMock) -> None:
        client = LegacyClient(mock_http)
        assert isinstance(client.inv_mast, InvMastResource)

    def test_item_category(self, mock_http: MagicMock) -> None:
        client = LegacyClient(mock_http)
        assert isinstance(client.item_category, ItemCategoryResource)

    def test_legacy(self, mock_http: MagicMock) -> None:
        client = LegacyClient(mock_http)
        assert isinstance(client.legacy, LegacyResource)

    def test_orders(self, mock_http: MagicMock) -> None:
        client = LegacyClient(mock_http)
        assert isinstance(client.orders, OrdersResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        client = LegacyClient(mock_http)
        first = client.inv_mast
        second = client.inv_mast
        assert first is second


class TestInvMastResource:
    def test_list_also_bought(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_also_bought(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/123/also-bought"

    def test_list_tags(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_tags(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/123/tags"

    def test_create_tags(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.create_tags(123, data={"tag": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/inv-mast/123/tags"

    def test_get_tags(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.get_tags(123, 456)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/123/tags/456"

    def test_update_tags(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.update_tags(123, 456, data={"tag": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/inv-mast/123/tags/456"

    def test_delete_tags(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.delete_tags(123, 456)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/inv-mast/123/tags/456"

    def test_list_web_desc(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.list_web_desc(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/123/web-desc"

    def test_create_web_desc(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.create_web_desc(123, data={"desc": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/inv-mast/123/web-desc"

    def test_get_web_desc(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.get_web_desc(123, 456)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/inv-mast/123/web-desc/456"

    def test_update_web_desc(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.update_web_desc(123, 456, data={"desc": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/inv-mast/123/web-desc/456"

    def test_delete_web_desc(self, mock_http: MagicMock) -> None:
        r = InvMastResource(mock_http)
        r.delete_web_desc(123, 456)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/inv-mast/123/web-desc/456"


class TestItemCategoryResource:
    def test_get(self, mock_http: MagicMock) -> None:
        r = ItemCategoryResource(mock_http)
        r.get(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/item-category/123"


class TestLegacyResource:
    def test_list_state(self, mock_http: MagicMock) -> None:
        r = LegacyResource(mock_http)
        r.list_state()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/legacy/state"

    def test_create_state(self, mock_http: MagicMock) -> None:
        r = LegacyResource(mock_http)
        r.create_state(data={"name": "TX"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/legacy/state"

    def test_get_state(self, mock_http: MagicMock) -> None:
        r = LegacyResource(mock_http)
        r.get_state(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/legacy/state/1"

    def test_update_state(self, mock_http: MagicMock) -> None:
        r = LegacyResource(mock_http)
        r.update_state(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/legacy/state/1"

    def test_delete_state(self, mock_http: MagicMock) -> None:
        r = LegacyResource(mock_http)
        r.delete_state(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/legacy/state/1"


class TestOrdersResource:
    def test_list_reset(self, mock_http: MagicMock) -> None:
        r = OrdersResource(mock_http)
        r.list_reset(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/orders/123/reset"


class TestResponseValidation:
    def test_list_returns_base_response(self, mock_http: MagicMock) -> None:
        r = LegacyResource(mock_http)
        result = r.list_state()
        assert result.status == 200

    def test_get_returns_base_response(self, mock_http: MagicMock) -> None:
        r = ItemCategoryResource(mock_http)
        result = r.get(1)
        assert result.data == {"id": 1}
