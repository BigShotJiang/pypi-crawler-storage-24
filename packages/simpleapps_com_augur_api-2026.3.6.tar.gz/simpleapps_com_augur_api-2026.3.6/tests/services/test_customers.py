"""Tests for the Customers service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.customers import CustomersClient
from augur_api.services.customers.client import (
    ContactsResource,
    ContactsUdResource,
    CustomerResource,
    OeContactsCustomerResource,
    ShipToResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "customers"
    return http


# ============================================================================
# CustomersClient — lazy property access
# ============================================================================


class TestCustomersClient:
    """Tests for CustomersClient lazy property initialisation."""

    def test_contacts(self, mock_http: MagicMock) -> None:
        client = CustomersClient(mock_http)
        assert isinstance(client.contacts, ContactsResource)

    def test_contacts_ud(self, mock_http: MagicMock) -> None:
        client = CustomersClient(mock_http)
        assert isinstance(client.contacts_ud, ContactsUdResource)

    def test_customer(self, mock_http: MagicMock) -> None:
        client = CustomersClient(mock_http)
        assert isinstance(client.customer, CustomerResource)

    def test_oe_contacts_customer(self, mock_http: MagicMock) -> None:
        client = CustomersClient(mock_http)
        assert isinstance(client.oe_contacts_customer, OeContactsCustomerResource)

    def test_ship_to(self, mock_http: MagicMock) -> None:
        client = CustomersClient(mock_http)
        assert isinstance(client.ship_to, ShipToResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        """Accessing the same property twice returns the same instance."""
        client = CustomersClient(mock_http)
        first = client.customer
        second = client.customer
        assert first is second


# ============================================================================
# ContactsResource
# ============================================================================


class TestContactsResource:
    """Tests for /contacts endpoints."""

    def test_get_refresh(self, mock_http: MagicMock) -> None:
        r = ContactsResource(mock_http)
        result = r.get_refresh()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/contacts/refresh"
        assert result.status == 200

    def test_list_customers(self, mock_http: MagicMock) -> None:
        r = ContactsResource(mock_http)
        r.list_customers(456)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/contacts/456/customers"

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = ContactsResource(mock_http)
        r.list_doc(456)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/contacts/456/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        """get_doc is an alias for list_doc."""
        r = ContactsResource(mock_http)
        r.get_doc(456)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/contacts/456/doc"

    def test_list_web_allowance(self, mock_http: MagicMock) -> None:
        r = ContactsResource(mock_http)
        r.list_web_allowance(456)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/contacts/456/web-allowance"


# ============================================================================
# ContactsUdResource
# ============================================================================


class TestContactsUdResource:
    """Tests for /contacts-ud endpoints."""

    def test_get(self, mock_http: MagicMock) -> None:
        r = ContactsUdResource(mock_http)
        r.get(456)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/contacts-ud/456"


# ============================================================================
# CustomerResource
# ============================================================================


class TestCustomerResource:
    """Tests for /customer endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer"
        assert result.status == 200

    def test_get_lookup(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.get_lookup()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/lookup"

    def test_list_address(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.list_address(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/address"

    def test_list_contacts(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.list_contacts(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/contacts"

    def test_create_contacts(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.create_contacts(123, data={"firstName": "John"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/customer/123/contacts"

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.list_doc(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        """get_doc is an alias for list_doc."""
        r = CustomerResource(mock_http)
        r.get_doc(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/doc"

    def test_list_invoices(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.list_invoices(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/invoices"

    def test_get_invoices(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.get_invoices(123, 1001)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/invoices/1001"

    def test_list_orders(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.list_orders(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/orders"

    def test_get_orders(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.get_orders(123, 12345)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/orders/12345"

    def test_list_purchased_items(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.list_purchased_items(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/purchased-items"

    def test_list_quotes(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.list_quotes(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/quotes"

    def test_get_quotes(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.get_quotes(123, 5001)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/quotes/5001"

    def test_list_ship_to(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.list_ship_to(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/customer/123/ship-to"

    def test_create_ship_to(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        r.create_ship_to(123, data={"shipToName": "Branch"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/customer/123/ship-to"


# ============================================================================
# OeContactsCustomerResource
# ============================================================================


class TestOeContactsCustomerResource:
    """Tests for /oe-contacts-customer endpoints."""

    def test_get_refresh(self, mock_http: MagicMock) -> None:
        r = OeContactsCustomerResource(mock_http)
        r.get_refresh()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/oe-contacts-customer/refresh"


# ============================================================================
# ShipToResource
# ============================================================================


class TestShipToResource:
    """Tests for /ship-to endpoints."""

    def test_get_refresh(self, mock_http: MagicMock) -> None:
        r = ShipToResource(mock_http)
        r.get_refresh()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/ship-to/refresh"


# ============================================================================
# Response validation
# ============================================================================


class TestResponseValidation:
    """Verify BaseResponse[Any] is returned correctly."""

    def test_list_returns_base_response(self, mock_http: MagicMock) -> None:
        r = CustomerResource(mock_http)
        result = r.list()
        assert result.status == 200
        assert result.message == "Success"
        assert result.count == 1
        assert result.total == 1

    def test_get_returns_base_response(self, mock_http: MagicMock) -> None:
        r = ContactsUdResource(mock_http)
        result = r.get(1)
        assert result.data == {"id": 1}
