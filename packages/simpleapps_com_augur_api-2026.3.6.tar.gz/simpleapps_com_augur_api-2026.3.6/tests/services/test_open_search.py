"""Tests for the Open Search service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.open_search import OpenSearchClient
from augur_api.services.open_search.client import (
    ItemSearchResource,
    ItemsResource,
    SuggestionsResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "open-search"
    return http


class TestOpenSearchClient:
    """Tests for OpenSearchClient lazy property initialisation."""

    def test_item_search(self) -> None:
        client = OpenSearchClient(mock_http())
        assert isinstance(client.item_search, ItemSearchResource)

    def test_items(self) -> None:
        client = OpenSearchClient(mock_http())
        assert isinstance(client.items, ItemsResource)

    def test_suggestions(self) -> None:
        client = OpenSearchClient(mock_http())
        assert isinstance(client.suggestions, SuggestionsResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = OpenSearchClient(mock_http())
        assert client.item_search is client.item_search
        assert client.items is client.items
        assert client.suggestions is client.suggestions


class TestItemSearchResource:
    """Tests for /item-search endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = ItemSearchResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/item-search"
        assert result.status == 200

    def test_list_attributes(self) -> None:
        http = mock_http()
        r = ItemSearchResource(http)
        result = r.list_attributes()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/item-search/attributes"
        assert result.status == 200


class TestItemsResource:
    """Tests for /items endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = ItemsResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/items"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = ItemsResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/items/1"
        assert result.status == 200

    def test_update(self) -> None:
        http = mock_http()
        r = ItemsResource(http)
        result = r.update(1, data={"statusCd": 704})
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/items/1"
        assert result.status == 200

    def test_update_refresh(self) -> None:
        http = mock_http()
        r = ItemsResource(http)
        result = r.update_refresh()
        http.put.assert_called_once()
        assert http.put.call_args[0][0] == "/items/refresh"
        assert result.status == 200

    def test_get_refresh(self) -> None:
        http = mock_http()
        r = ItemsResource(http)
        result = r.get_refresh(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/items/1/refresh"
        assert result.status == 200


class TestSuggestionsResource:
    """Tests for /suggestions endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = SuggestionsResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/suggestions"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = SuggestionsResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/suggestions/1"
        assert result.status == 200

    def test_list_suggest(self) -> None:
        http = mock_http()
        r = SuggestionsResource(http)
        result = r.list_suggest()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/suggestions/suggest"
        assert result.status == 200
