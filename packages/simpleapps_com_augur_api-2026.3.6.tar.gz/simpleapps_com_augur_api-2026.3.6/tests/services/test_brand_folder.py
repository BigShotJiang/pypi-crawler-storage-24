"""Tests for the Brand Folder service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.brand_folder import BrandFolderClient
from augur_api.services.brand_folder.client import CategoriesResource

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "brand-folder"
    return http


class TestBrandFolderClient:
    """Tests for BrandFolderClient lazy property initialisation."""

    def test_categories(self) -> None:
        client = BrandFolderClient(mock_http())
        assert isinstance(client.categories, CategoriesResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = BrandFolderClient(mock_http())
        first = client.categories
        second = client.categories
        assert first is second


class TestCategoriesResource:
    """Tests for /categories endpoints."""

    def test_create_focus(self) -> None:
        http = mock_http()
        r = CategoriesResource(http)
        result = r.create_focus(data={"categoryId": "cat-123"})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/categories/focus"
        assert result.status == 200
