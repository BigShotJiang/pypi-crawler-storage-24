"""Tests for the Pricing service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.pricing import PricingClient
from augur_api.services.pricing.client import (
    JobPriceHdrResource,
    PriceEngineResource,
    TaxEngineResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "pricing"
    return http


class TestPricingClient:
    """Tests for PricingClient lazy property initialisation."""

    def test_job_price_hdr(self) -> None:
        client = PricingClient(mock_http())
        assert isinstance(client.job_price_hdr, JobPriceHdrResource)

    def test_price_engine(self) -> None:
        client = PricingClient(mock_http())
        assert isinstance(client.price_engine, PriceEngineResource)

    def test_tax_engine(self) -> None:
        client = PricingClient(mock_http())
        assert isinstance(client.tax_engine, TaxEngineResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = PricingClient(mock_http())
        assert client.job_price_hdr is client.job_price_hdr
        assert client.price_engine is client.price_engine
        assert client.tax_engine is client.tax_engine


class TestJobPriceHdrResource:
    """Tests for /job-price-hdr endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = JobPriceHdrResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/job-price-hdr"
        assert result.status == 200

    def test_get(self) -> None:
        http = mock_http()
        r = JobPriceHdrResource(http)
        result = r.get(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/job-price-hdr/1"
        assert result.status == 200

    def test_list_lines(self) -> None:
        http = mock_http()
        r = JobPriceHdrResource(http)
        result = r.list_lines(1)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/job-price-hdr/1/lines"
        assert result.status == 200

    def test_get_lines(self) -> None:
        http = mock_http()
        r = JobPriceHdrResource(http)
        result = r.get_lines(1, 2)
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/job-price-hdr/1/lines/2"
        assert result.status == 200


class TestPriceEngineResource:
    """Tests for /price-engine endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = PriceEngineResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/price-engine"
        assert result.status == 200


class TestTaxEngineResource:
    """Tests for /tax-engine endpoints."""

    def test_create(self) -> None:
        http = mock_http()
        r = TaxEngineResource(http)
        result = r.create(data={"customer_id": 12345})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/tax-engine"
        assert result.status == 200
