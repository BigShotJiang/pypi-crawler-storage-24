"""Tests for the AGR Site service client."""

from unittest.mock import MagicMock

import pytest

from augur_api.services.agr_site import (
    AgrSiteClient,
    ContextResource,
    FyxerTranscriptResource,
    GeoCodesPostalCodesResource,
    MetaFilesResource,
    NotificationsResource,
    OpenSearchResource,
    SettingsResource,
    TrainingResource,
)
from augur_api.services.agr_site.schemas import (
    ContextGetParams,
    ContextResponse,
    FyxerTranscript,
    FyxerTranscriptCreateParams,
    FyxerTranscriptListParams,
    FyxerTranscriptUpdateParams,
    GeoCodesPostalCodes,
    GeoCodesPostalCodesListParams,
    HealthCheckData,
    MetaFilesRobotsResponse,
    NotificationCreateParams,
    NotificationResponse,
    OpenSearchEmbeddingParams,
    OpenSearchEmbeddingResponse,
    Setting,
    SettingCreateParams,
    SettingListParams,
    SettingUpdateParams,
    TrainingConv,
    TrainingConvCreateParams,
    TrainingConvListParams,
    TrainingConvUpdateParams,
    TrainingMsg,
    TrainingMsgCreateParams,
    TrainingMsgListParams,
    TrainingMsgUpdateParams,
    TrainingSet,
    TrainingSetCreateParams,
    TrainingSetListParams,
    TrainingSetUpdateParams,
)

MOCK_RESPONSE = {
    "count": 1,
    "data": {},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def _mock_response(data: object = None) -> dict:
    """Build a mock API response."""
    return {**MOCK_RESPONSE, "data": data if data is not None else {}}


class TestAgrSiteSchemas:
    """Tests for AGR Site schemas."""

    def test_health_check_data(self) -> None:
        """Should parse health check data."""
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"
        assert result.site_hash == "abc123"

    def test_context_get_params(self) -> None:
        """Should create context get params."""
        params = ContextGetParams(edge_cache="5m")
        assert params.edge_cache == "5m"

    def test_context_get_params_defaults(self) -> None:
        """Should have None defaults."""
        params = ContextGetParams()
        assert params.edge_cache is None

    def test_context_response(self) -> None:
        """Should parse context response data."""
        data = {}
        result = ContextResponse.model_validate(data)
        assert result is not None

    def test_setting_list_params(self) -> None:
        """Should create setting list params."""
        params = SettingListParams(limit=10, offset=5, service_name="test")
        assert params.limit == 10
        assert params.offset == 5
        assert params.service_name == "test"

    def test_setting_list_params_defaults(self) -> None:
        """Should have None defaults."""
        params = SettingListParams()
        assert params.limit is None
        assert params.offset is None

    def test_setting_model(self) -> None:
        """Should parse setting data."""
        data = {
            "settingsUid": 1,
            "serviceName": "test-service",
            "settingKey": "key1",
            "settingValue": "value1",
            "createdAt": "2024-01-01T00:00:00Z",
            "updatedAt": "2024-01-02T00:00:00Z",
        }
        result = Setting.model_validate(data)
        assert result.settings_uid == 1
        assert result.service_name == "test-service"
        assert result.setting_key == "key1"
        assert result.setting_value == "value1"

    def test_setting_create_params(self) -> None:
        """Should create setting create params."""
        params = SettingCreateParams(service_name="test", setting_key="key", setting_value="value")
        assert params.service_name == "test"
        assert params.setting_key == "key"

    def test_setting_update_params(self) -> None:
        """Should create setting update params."""
        params = SettingUpdateParams(setting_value="new-value")
        assert params.setting_value == "new-value"

    def test_fyxer_transcript_list_params(self) -> None:
        """Should create Fyxer transcript list params."""
        params = FyxerTranscriptListParams(limit=10, offset=5)
        assert params.limit == 10
        assert params.offset == 5

    def test_fyxer_transcript_list_params_all_fields(self) -> None:
        """Should create Fyxer transcript list params with all fields."""
        params = FyxerTranscriptListParams(
            limit=10, offset=5, order_by="created_at", q="search", status_cd=1
        )
        assert params.order_by == "created_at"
        assert params.q == "search"
        assert params.status_cd == 1

    def test_fyxer_transcript_model(self) -> None:
        """Should parse Fyxer transcript data."""
        data = {
            "fyxerTranscriptHdrUid": 1,
            "link": "https://example.com",
            "title": "Test Transcript",
            "statusCd": 1,
        }
        result = FyxerTranscript.model_validate(data)
        assert result.fyxer_transcript_hdr_uid == 1
        assert result.title == "Test Transcript"

    def test_fyxer_transcript_create_params(self) -> None:
        """Should create Fyxer transcript create params."""
        params = FyxerTranscriptCreateParams(link="https://example.com")
        assert params.link == "https://example.com"

    def test_training_set_list_params(self) -> None:
        """Should create training set list params."""
        params = TrainingSetListParams(limit=10)
        assert params.limit == 10

    def test_training_set_model(self) -> None:
        """Should parse training set data."""
        data = {
            "trainingSetUid": 1,
            "name": "Test Set",
            "description": "Test description",
        }
        result = TrainingSet.model_validate(data)
        assert result.training_set_uid == 1
        assert result.name == "Test Set"

    def test_training_conv_model(self) -> None:
        """Should parse training conversation data."""
        data = {"trainingConvUid": 1, "trainingSetUid": 1, "title": "Test Conv"}
        result = TrainingConv.model_validate(data)
        assert result.training_conv_uid == 1
        assert result.title == "Test Conv"

    def test_training_msg_model(self) -> None:
        """Should parse training message data."""
        data = {
            "trainingMsgUid": 1,
            "trainingConvUid": 1,
            "role": "user",
            "content": "Hello",
        }
        result = TrainingMsg.model_validate(data)
        assert result.training_msg_uid == 1
        assert result.role == "user"
        assert result.content == "Hello"

    def test_geo_codes_postal_codes_model(self) -> None:
        """Should parse geo codes data."""
        data = {
            "geoCodesPostalCodesUid": 1,
            "postalCode": "12345",
            "city": "Test City",
            "state": "CA",
        }
        result = GeoCodesPostalCodes.model_validate(data)
        assert result.postal_code == "12345"
        assert result.city == "Test City"

    def test_notification_create_params(self) -> None:
        """Should create notification create params."""
        params = NotificationCreateParams(
            message="Test", recipient="user@test.com", notification_type="email"
        )
        assert params.message == "Test"
        assert params.recipient == "user@test.com"

    def test_notification_response(self) -> None:
        """Should parse notification response."""
        data = {"success": True, "message": "Sent"}
        result = NotificationResponse.model_validate(data)
        assert result.success is True
        assert result.message == "Sent"

    def test_open_search_embedding_params(self) -> None:
        """Should create OpenSearch embedding params."""
        params = OpenSearchEmbeddingParams(q="Hello", model="test", dimensions=768)
        assert params.q == "Hello"
        assert params.model == "test"

    def test_open_search_embedding_response(self) -> None:
        """Should parse OpenSearch embedding response."""
        data = {"embedding": [0.1, 0.2], "model": "test", "dimensions": 2}
        result = OpenSearchEmbeddingResponse.model_validate(data)
        assert result.embedding == [0.1, 0.2]
        assert result.dimensions == 2

    def test_meta_files_robots_response(self) -> None:
        """Should parse meta files robots response."""
        data = {"content": "User-agent: *"}
        result = MetaFilesRobotsResponse.model_validate(data)
        assert result.content == "User-agent: *"

    def test_training_set_create_params(self) -> None:
        """Should create training set create params."""
        params = TrainingSetCreateParams(name="Test", description="Desc")
        assert params.name == "Test"

    def test_training_set_update_params(self) -> None:
        """Should create training set update params."""
        params = TrainingSetUpdateParams(name="Updated")
        assert params.name == "Updated"

    def test_training_conv_create_params(self) -> None:
        """Should create training conversation create params."""
        params = TrainingConvCreateParams(title="Conv")
        assert params.title == "Conv"

    def test_training_conv_update_params(self) -> None:
        """Should create training conversation update params."""
        params = TrainingConvUpdateParams(title="Updated")
        assert params.title == "Updated"

    def test_training_conv_list_params(self) -> None:
        """Should create training conversation list params."""
        params = TrainingConvListParams(limit=5)
        assert params.limit == 5

    def test_training_msg_create_params(self) -> None:
        """Should create training message create params."""
        params = TrainingMsgCreateParams(content="Hello", role="user")
        assert params.content == "Hello"

    def test_training_msg_update_params(self) -> None:
        """Should create training message update params."""
        params = TrainingMsgUpdateParams(content="Updated")
        assert params.content == "Updated"

    def test_training_msg_list_params(self) -> None:
        """Should create training message list params."""
        params = TrainingMsgListParams(limit=5)
        assert params.limit == 5

    def test_fyxer_transcript_update_params(self) -> None:
        """Should create Fyxer transcript update params."""
        params = FyxerTranscriptUpdateParams(title="Updated")
        assert params.title == "Updated"

    def test_geo_codes_postal_codes_list_params(self) -> None:
        """Should create geo codes postal codes list params."""
        params = GeoCodesPostalCodesListParams(limit=10)
        assert params.limit == 10


class TestAgrSiteClient:
    """Tests for AgrSiteClient using MagicMock."""

    @pytest.fixture
    def mock_http(self) -> MagicMock:
        """Create mock HTTP client."""
        return MagicMock()

    @pytest.fixture
    def client(self, mock_http: MagicMock) -> AgrSiteClient:
        """Create client with mock HTTP."""
        return AgrSiteClient(mock_http)

    def test_resource_properties_return_same_instance(self, client: AgrSiteClient) -> None:
        """Should return same resource instance on multiple accesses."""
        assert client.context is client.context
        assert client.settings is client.settings
        assert client.fyxer_transcript is client.fyxer_transcript
        assert client.training is client.training
        assert client.geo_codes_postal_codes is client.geo_codes_postal_codes
        assert client.notifications is client.notifications
        assert client.open_search is client.open_search
        assert client.meta_files is client.meta_files

    def test_resource_types(self, client: AgrSiteClient) -> None:
        """Should return correct resource types."""
        assert isinstance(client.context, ContextResource)
        assert isinstance(client.settings, SettingsResource)
        assert isinstance(client.fyxer_transcript, FyxerTranscriptResource)
        assert isinstance(client.training, TrainingResource)
        assert isinstance(client.geo_codes_postal_codes, GeoCodesPostalCodesResource)
        assert isinstance(client.notifications, NotificationsResource)
        assert isinstance(client.open_search, OpenSearchResource)
        assert isinstance(client.meta_files, MetaFilesResource)

    def test_context_get(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should call context endpoint."""
        mock_http.get.return_value = _mock_response({"siteId": "target"})
        client.context.get("target-site")
        mock_http.get.assert_called_once()
        assert "context/target-site" in str(mock_http.get.call_args)

    def test_settings_list(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should list settings."""
        mock_http.get.return_value = _mock_response([{"settingsUid": 1}])
        client.settings.list()
        mock_http.get.assert_called_once()

    def test_settings_get(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should get setting by UID."""
        mock_http.get.return_value = _mock_response({"settingsUid": 1})
        client.settings.get(1)
        mock_http.get.assert_called_once()
        assert "/1" in str(mock_http.get.call_args)

    def test_settings_create(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should create setting."""
        mock_http.post.return_value = _mock_response({"settingsUid": 1})
        client.settings.create({"key": "test"})
        mock_http.post.assert_called_once()

    def test_settings_update(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should update setting."""
        mock_http.put.return_value = _mock_response({"settingsUid": 1})
        client.settings.update(1, {"value": "new"})
        mock_http.put.assert_called_once()

    def test_settings_delete(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should delete setting."""
        mock_http.delete.return_value = _mock_response(True)
        client.settings.delete(1)
        mock_http.delete.assert_called_once()

    def test_fyxer_transcript_list(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should list Fyxer transcripts."""
        mock_http.get.return_value = _mock_response([{"fyxerTranscriptHdrUid": 1}])
        client.fyxer_transcript.list()
        mock_http.get.assert_called_once()

    def test_fyxer_transcript_get(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should get Fyxer transcript by UID."""
        mock_http.get.return_value = _mock_response({"fyxerTranscriptHdrUid": 1})
        client.fyxer_transcript.get(1)
        mock_http.get.assert_called_once()

    def test_fyxer_transcript_create(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should create Fyxer transcript."""
        mock_http.post.return_value = _mock_response({"fyxerTranscriptHdrUid": 1})
        client.fyxer_transcript.create({"link": "https://example.com"})
        mock_http.post.assert_called_once()

    def test_fyxer_transcript_update(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should update Fyxer transcript."""
        mock_http.put.return_value = _mock_response({"fyxerTranscriptHdrUid": 1})
        client.fyxer_transcript.update(1, {"title": "Updated"})
        mock_http.put.assert_called_once()

    def test_fyxer_transcript_delete(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should delete Fyxer transcript."""
        mock_http.delete.return_value = _mock_response(True)
        client.fyxer_transcript.delete(1)
        mock_http.delete.assert_called_once()

    def test_training_list(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should list training sets."""
        mock_http.get.return_value = _mock_response([{"trainingSetUid": 1}])
        client.training.list()
        mock_http.get.assert_called_once()

    def test_training_get(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should get training set by UID."""
        mock_http.get.return_value = _mock_response({"trainingSetUid": 1})
        client.training.get(1)
        mock_http.get.assert_called_once()

    def test_training_create(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should create training set."""
        mock_http.post.return_value = _mock_response({"trainingSetUid": 1})
        client.training.create({"name": "Test"})
        mock_http.post.assert_called_once()

    def test_training_update(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should update training set."""
        mock_http.put.return_value = _mock_response({"trainingSetUid": 1})
        client.training.update(1, {"name": "Updated"})
        mock_http.put.assert_called_once()

    def test_training_delete(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should delete training set."""
        mock_http.delete.return_value = _mock_response(True)
        client.training.delete(1)
        mock_http.delete.assert_called_once()

    def test_training_list_conversations(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should list training conversations."""
        mock_http.get.return_value = _mock_response([{"trainingConvUid": 1}])
        client.training.list_conversations(1)
        mock_http.get.assert_called_once()
        assert "/1/conversations" in str(mock_http.get.call_args)

    def test_training_create_conversations(
        self, mock_http: MagicMock, client: AgrSiteClient
    ) -> None:
        """Should create training conversation."""
        mock_http.post.return_value = _mock_response({"trainingConvUid": 1})
        client.training.create_conversations(1, {"title": "Conv"})
        mock_http.post.assert_called_once()

    def test_training_get_conversations(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should get training conversation."""
        mock_http.get.return_value = _mock_response({"trainingConvUid": 1})
        client.training.get_conversations(1, 2)
        mock_http.get.assert_called_once()
        assert "/1/conversations/2" in str(mock_http.get.call_args)

    def test_training_update_conversations(
        self, mock_http: MagicMock, client: AgrSiteClient
    ) -> None:
        """Should update training conversation."""
        mock_http.put.return_value = _mock_response({"trainingConvUid": 1})
        client.training.update_conversations(1, 2, {"title": "Updated"})
        mock_http.put.assert_called_once()

    def test_training_delete_conversations(
        self, mock_http: MagicMock, client: AgrSiteClient
    ) -> None:
        """Should delete training conversation."""
        mock_http.delete.return_value = _mock_response(True)
        client.training.delete_conversations(1, 2)
        mock_http.delete.assert_called_once()

    def test_training_list_conversations_messages(
        self, mock_http: MagicMock, client: AgrSiteClient
    ) -> None:
        """Should list training messages."""
        mock_http.get.return_value = _mock_response([{"trainingMsgUid": 1}])
        client.training.list_conversations_messages(1, 2)
        mock_http.get.assert_called_once()
        assert "/1/conversations/2/messages" in str(mock_http.get.call_args)

    def test_training_create_conversations_messages(
        self, mock_http: MagicMock, client: AgrSiteClient
    ) -> None:
        """Should create training message."""
        mock_http.post.return_value = _mock_response({"trainingMsgUid": 1})
        client.training.create_conversations_messages(1, 2, {"content": "Hello"})
        mock_http.post.assert_called_once()

    def test_training_get_conversations_messages(
        self, mock_http: MagicMock, client: AgrSiteClient
    ) -> None:
        """Should get training message."""
        mock_http.get.return_value = _mock_response({"trainingMsgUid": 1})
        client.training.get_conversations_messages(1, 2, 3)
        mock_http.get.assert_called_once()
        assert "/1/conversations/2/messages/3" in str(mock_http.get.call_args)

    def test_training_update_conversations_messages(
        self, mock_http: MagicMock, client: AgrSiteClient
    ) -> None:
        """Should update training message."""
        mock_http.put.return_value = _mock_response({"trainingMsgUid": 1})
        client.training.update_conversations_messages(1, 2, 3, {"content": "Updated"})
        mock_http.put.assert_called_once()

    def test_training_delete_conversations_messages(
        self, mock_http: MagicMock, client: AgrSiteClient
    ) -> None:
        """Should delete training message."""
        mock_http.delete.return_value = _mock_response(True)
        client.training.delete_conversations_messages(1, 2, 3)
        mock_http.delete.assert_called_once()

    def test_geo_codes_postal_codes_list(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should list geo codes."""
        mock_http.get.return_value = _mock_response([{"geoCodesPostalCodesUid": 1}])
        client.geo_codes_postal_codes.list()
        mock_http.get.assert_called_once()

    def test_geo_codes_postal_codes_get(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should get geo code by UID."""
        mock_http.get.return_value = _mock_response({"geoCodesPostalCodesUid": 1})
        client.geo_codes_postal_codes.get(1)
        mock_http.get.assert_called_once()

    def test_notifications_create(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should create notification."""
        mock_http.post.return_value = _mock_response({"success": True})
        client.notifications.create({"message": "Test"})
        mock_http.post.assert_called_once()

    def test_open_search_list_embedding(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should get embedding."""
        mock_http.get.return_value = _mock_response({"embedding": [0.1, 0.2]})
        client.open_search.list_embedding()
        mock_http.get.assert_called_once()

    def test_meta_files_list_robots(self, mock_http: MagicMock, client: AgrSiteClient) -> None:
        """Should get robots.txt."""
        mock_http.get.return_value = _mock_response({"content": "User-agent: *"})
        client.meta_files.list_robots()
        mock_http.get.assert_called_once()
