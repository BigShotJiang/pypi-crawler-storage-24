"""Tests for the P21 APIs service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.p21_apis import P21ApisClient
from augur_api.services.p21_apis.client import (
    EntityContactsResource,
    EntityCustomersResource,
    TransCategoryResource,
    TransCompanyResource,
    TransPurchaseOrderReceiptResource,
    TransUserResource,
    TransWebDisplayTypeResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "p21-apis"
    return http


class TestP21ApisClient:
    def test_entity_contacts(self, mock_http: MagicMock) -> None:
        client = P21ApisClient(mock_http)
        assert isinstance(client.entity_contacts, EntityContactsResource)

    def test_trans_category(self, mock_http: MagicMock) -> None:
        client = P21ApisClient(mock_http)
        assert isinstance(client.trans_category, TransCategoryResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        client = P21ApisClient(mock_http)
        assert client.entity_contacts is client.entity_contacts


class TestEntityContactsResource:
    def test_get_refresh(self, mock_http: MagicMock) -> None:
        r = EntityContactsResource(mock_http)
        r.get_refresh()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/entity-contacts/refresh"


class TestEntityCustomersResource:
    def test_get_refresh(self, mock_http: MagicMock) -> None:
        r = EntityCustomersResource(mock_http)
        r.get_refresh()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/entity-customers/refresh"


class TestTransCategoryResource:
    def test_create(self, mock_http: MagicMock) -> None:
        r = TransCategoryResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/trans-category"

    def test_get(self, mock_http: MagicMock) -> None:
        r = TransCategoryResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/trans-category/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = TransCategoryResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/trans-category/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = TransCategoryResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/trans-category/1"


class TestTransCompanyResource:
    def test_create(self, mock_http: MagicMock) -> None:
        r = TransCompanyResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/trans-company"

    def test_get(self, mock_http: MagicMock) -> None:
        r = TransCompanyResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/trans-company/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = TransCompanyResource(mock_http)
        r.update(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/trans-company/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = TransCompanyResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/trans-company/1"


class TestTransPurchaseOrderReceiptResource:
    def test_get(self, mock_http: MagicMock) -> None:
        r = TransPurchaseOrderReceiptResource(mock_http)
        r.get("PO123")
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/trans-purchase-order-receipt/PO123"

    def test_update(self, mock_http: MagicMock) -> None:
        r = TransPurchaseOrderReceiptResource(mock_http)
        r.update("PO123")
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/trans-purchase-order-receipt/PO123"


class TestTransUserResource:
    def test_create(self, mock_http: MagicMock) -> None:
        r = TransUserResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/trans-user"

    def test_get(self, mock_http: MagicMock) -> None:
        r = TransUserResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/trans-user/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = TransUserResource(mock_http)
        r.update(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/trans-user/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = TransUserResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/trans-user/1"


class TestTransWebDisplayTypeResource:
    def test_create(self, mock_http: MagicMock) -> None:
        r = TransWebDisplayTypeResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/trans-web-display-type"

    def test_list_defaults(self, mock_http: MagicMock) -> None:
        r = TransWebDisplayTypeResource(mock_http)
        r.list_defaults()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/trans-web-display-type/defaults"

    def test_list_definition(self, mock_http: MagicMock) -> None:
        r = TransWebDisplayTypeResource(mock_http)
        r.list_definition()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/trans-web-display-type/definition"

    def test_get(self, mock_http: MagicMock) -> None:
        r = TransWebDisplayTypeResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/trans-web-display-type/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = TransWebDisplayTypeResource(mock_http)
        r.update(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/trans-web-display-type/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = TransWebDisplayTypeResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/trans-web-display-type/1"


class TestResponseValidation:
    def test_returns_base_response(self, mock_http: MagicMock) -> None:
        r = TransCategoryResource(mock_http)
        result = r.get(1)
        assert result.status == 200
        assert result.data == {"id": 1}
