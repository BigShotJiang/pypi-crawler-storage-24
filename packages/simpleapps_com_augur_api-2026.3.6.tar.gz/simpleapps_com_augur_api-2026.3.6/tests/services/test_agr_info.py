"""Tests for the AGR Info service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.agr_info import AgrInfoClient
from augur_api.services.agr_info.client import (
    AkashaResource,
    ContextResource,
    JoomlaResource,
    MicroservicesResource,
    OllamaResource,
    RubricsResource,
    WorkflowsResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "agr-info"
    return http


class TestAgrInfoClient:
    """Tests for AgrInfoClient lazy property initialisation."""

    def test_akasha(self, mock_http: MagicMock) -> None:
        client = AgrInfoClient(mock_http)
        assert isinstance(client.akasha, AkashaResource)

    def test_context(self, mock_http: MagicMock) -> None:
        client = AgrInfoClient(mock_http)
        assert isinstance(client.context, ContextResource)

    def test_joomla(self, mock_http: MagicMock) -> None:
        client = AgrInfoClient(mock_http)
        assert isinstance(client.joomla, JoomlaResource)

    def test_microservices(self, mock_http: MagicMock) -> None:
        client = AgrInfoClient(mock_http)
        assert isinstance(client.microservices, MicroservicesResource)

    def test_ollama(self, mock_http: MagicMock) -> None:
        client = AgrInfoClient(mock_http)
        assert isinstance(client.ollama, OllamaResource)

    def test_rubrics(self, mock_http: MagicMock) -> None:
        client = AgrInfoClient(mock_http)
        assert isinstance(client.rubrics, RubricsResource)

    def test_workflows(self, mock_http: MagicMock) -> None:
        client = AgrInfoClient(mock_http)
        assert isinstance(client.workflows, WorkflowsResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        client = AgrInfoClient(mock_http)
        first = client.akasha
        second = client.akasha
        assert first is second


class TestAkashaResource:
    def test_create_generate(self, mock_http: MagicMock) -> None:
        r = AkashaResource(mock_http)
        r.create_generate(data={"prompt": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/akasha/generate"


class TestContextResource:
    def test_get(self, mock_http: MagicMock) -> None:
        r = ContextResource(mock_http)
        r.get("site1")
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/context/site1"


class TestJoomlaResource:
    def test_create_generate(self, mock_http: MagicMock) -> None:
        r = JoomlaResource(mock_http)
        r.create_generate(data={"prompt": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/joomla/generate"


class TestMicroservicesResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = MicroservicesResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/microservices"

    def test_create(self, mock_http: MagicMock) -> None:
        r = MicroservicesResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/microservices"

    def test_get(self, mock_http: MagicMock) -> None:
        r = MicroservicesResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/microservices/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = MicroservicesResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/microservices/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = MicroservicesResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/microservices/1"


class TestOllamaResource:
    def test_list_tags(self, mock_http: MagicMock) -> None:
        r = OllamaResource(mock_http)
        r.list_tags()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/ollama/tags"


class TestRubricsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = RubricsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/rubrics"

    def test_create(self, mock_http: MagicMock) -> None:
        r = RubricsResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/rubrics"

    def test_get(self, mock_http: MagicMock) -> None:
        r = RubricsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/rubrics/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = RubricsResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/rubrics/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = RubricsResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/rubrics/1"


class TestWorkflowsResource:
    def test_list(self, mock_http: MagicMock) -> None:
        r = WorkflowsResource(mock_http)
        r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/workflows"

    def test_create(self, mock_http: MagicMock) -> None:
        r = WorkflowsResource(mock_http)
        r.create(data={"name": "test"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/workflows"

    def test_get(self, mock_http: MagicMock) -> None:
        r = WorkflowsResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/workflows/1"

    def test_update(self, mock_http: MagicMock) -> None:
        r = WorkflowsResource(mock_http)
        r.update(1, data={"name": "updated"})
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/workflows/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = WorkflowsResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/workflows/1"


class TestResponseValidation:
    def test_list_returns_base_response(self, mock_http: MagicMock) -> None:
        r = MicroservicesResource(mock_http)
        result = r.list()
        assert result.status == 200
        assert result.message == "Success"

    def test_get_returns_base_response(self, mock_http: MagicMock) -> None:
        r = RubricsResource(mock_http)
        result = r.get(1)
        assert result.data == {"id": 1}
