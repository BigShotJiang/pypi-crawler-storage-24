"""Tests for the Orders service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.orders import OrdersClient
from augur_api.services.orders.client import (
    InvoiceHdrResource,
    OeHdrResource,
    OeHdrSalesrepResource,
    PickTicketsResource,
    PoHdrResource,
)
from augur_api.services.orders.schemas import (
    HealthCheckData,
    InvoiceReprintResponse,
    OeHdr,
    OeHdrDoc,
    OeHdrDocParams,
    OeHdrLookupParams,
    PickTicket,
    PickTicketLine,
    PickTicketLinesParams,
    PickTicketsListParams,
    PoHdr,
    PoHdrDoc,
    PoHdrListParams,
    PoHdrScanParams,
    SalesRepOeHdr,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "orders"
    return http


# ============================================================================
# OrdersClient — lazy property access
# ============================================================================


class TestOrdersClient:
    """Tests for OrdersClient lazy property initialisation."""

    def test_invoice_hdr(self, mock_http: MagicMock) -> None:
        client = OrdersClient(mock_http)
        assert isinstance(client.invoice_hdr, InvoiceHdrResource)

    def test_oe_hdr(self, mock_http: MagicMock) -> None:
        client = OrdersClient(mock_http)
        assert isinstance(client.oe_hdr, OeHdrResource)

    def test_oe_hdr_salesrep(self, mock_http: MagicMock) -> None:
        client = OrdersClient(mock_http)
        assert isinstance(client.oe_hdr_salesrep, OeHdrSalesrepResource)

    def test_pick_tickets(self, mock_http: MagicMock) -> None:
        client = OrdersClient(mock_http)
        assert isinstance(client.pick_tickets, PickTicketsResource)

    def test_po_hdr(self, mock_http: MagicMock) -> None:
        client = OrdersClient(mock_http)
        assert isinstance(client.po_hdr, PoHdrResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        """Accessing the same property twice returns the same instance."""
        client = OrdersClient(mock_http)
        assert client.invoice_hdr is client.invoice_hdr
        assert client.oe_hdr is client.oe_hdr
        assert client.oe_hdr_salesrep is client.oe_hdr_salesrep
        assert client.pick_tickets is client.pick_tickets
        assert client.po_hdr is client.po_hdr


# ============================================================================
# InvoiceHdrResource
# ============================================================================


class TestInvoiceHdrResource:
    """Tests for /invoice-hdr endpoints."""

    def test_list_reprint(self, mock_http: MagicMock) -> None:
        r = InvoiceHdrResource(mock_http)
        result = r.list_reprint(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/invoice-hdr/123/reprint"
        assert result.status == 200


# ============================================================================
# OeHdrResource
# ============================================================================


class TestOeHdrResource:
    """Tests for /oe-hdr endpoints."""

    def test_get_lookup(self, mock_http: MagicMock) -> None:
        r = OeHdrResource(mock_http)
        result = r.get_lookup()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/oe-hdr/lookup"
        assert result.status == 200

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = OeHdrResource(mock_http)
        result = r.list_doc(12345)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/oe-hdr/12345/doc"
        assert result.status == 200

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        r = OeHdrResource(mock_http)
        result = r.get_doc(12345)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/oe-hdr/12345/doc"
        assert result.status == 200


# ============================================================================
# OeHdrSalesrepResource
# ============================================================================


class TestOeHdrSalesrepResource:
    """Tests for /oe-hdr-salesrep endpoints."""

    def test_list_oe_hdr(self, mock_http: MagicMock) -> None:
        r = OeHdrSalesrepResource(mock_http)
        result = r.list_oe_hdr(100)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/oe-hdr-salesrep/100/oe-hdr"
        assert result.status == 200

    def test_list_oe_hdr_doc(self, mock_http: MagicMock) -> None:
        r = OeHdrSalesrepResource(mock_http)
        result = r.list_oe_hdr_doc(12345, 100)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/oe-hdr-salesrep/100/oe-hdr/12345/doc"
        assert result.status == 200

    def test_get_oe_hdr_doc_alias(self, mock_http: MagicMock) -> None:
        r = OeHdrSalesrepResource(mock_http)
        result = r.get_oe_hdr_doc(12345, 100)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/oe-hdr-salesrep/100/oe-hdr/12345/doc"
        assert result.status == 200


# ============================================================================
# PickTicketsResource
# ============================================================================


class TestPickTicketsResource:
    """Tests for /pick-tickets endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = PickTicketsResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/pick-tickets"
        assert result.status == 200

    def test_get(self, mock_http: MagicMock) -> None:
        r = PickTicketsResource(mock_http)
        result = r.get(1001)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/pick-tickets/1001"
        assert result.status == 200

    def test_list_lines(self, mock_http: MagicMock) -> None:
        r = PickTicketsResource(mock_http)
        result = r.list_lines(1001)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/pick-tickets/1001/lines"
        assert result.status == 200

    def test_get_lines(self, mock_http: MagicMock) -> None:
        r = PickTicketsResource(mock_http)
        result = r.get_lines(1, 1001)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/pick-tickets/1001/lines/1"
        assert result.status == 200


# ============================================================================
# PoHdrResource
# ============================================================================


class TestPoHdrResource:
    """Tests for /po-hdr endpoints."""

    def test_list(self, mock_http: MagicMock) -> None:
        r = PoHdrResource(mock_http)
        result = r.list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/po-hdr"
        assert result.status == 200

    def test_get(self, mock_http: MagicMock) -> None:
        r = PoHdrResource(mock_http)
        result = r.get(5001)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/po-hdr/5001"
        assert result.status == 200

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = PoHdrResource(mock_http)
        result = r.list_doc(5001)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/po-hdr/5001/doc"
        assert result.status == 200

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        r = PoHdrResource(mock_http)
        result = r.get_doc(5001)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/po-hdr/5001/doc"
        assert result.status == 200

    def test_create_scan(self, mock_http: MagicMock) -> None:
        r = PoHdrResource(mock_http)
        result = r.create_scan(data={"vendorId": "V001"})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/po-hdr/scan"
        assert result.status == 200


# ============================================================================
# Schemas
# ============================================================================


class TestOrdersSchemas:
    """Tests for Orders schemas."""

    def test_health_check_data(self) -> None:
        data = {"siteHash": "abc123", "siteId": "test-site"}
        result = HealthCheckData.model_validate(data)
        assert result.site_id == "test-site"

    def test_oe_hdr_lookup_params(self) -> None:
        params = OeHdrLookupParams(limit=10, salesrep_id="REP001", completed="Y")
        assert params.limit == 10
        assert params.salesrep_id == "REP001"
        assert params.completed == "Y"

    def test_oe_hdr_doc_params(self) -> None:
        params = OeHdrDocParams(postal_code="90210")
        assert params.postal_code == "90210"

    def test_oe_hdr_model(self) -> None:
        data = {"orderNo": 12345, "customerId": 100, "totalAmount": 999.99, "statusCd": 1}
        result = OeHdr.model_validate(data)
        assert result.order_no == 12345
        assert result.total_amount == 999.99

    def test_oe_hdr_doc_model(self) -> None:
        data = {"orderNo": 12345, "customerId": 100, "customerName": "Test Customer", "lines": []}
        result = OeHdrDoc.model_validate(data)
        assert result.order_no == 12345
        assert result.customer_name == "Test Customer"

    def test_invoice_reprint_response_model(self) -> None:
        data = {"success": True, "message": "Invoice reprinted", "invoiceNo": 123}
        result = InvoiceReprintResponse.model_validate(data)
        assert result.success is True
        assert result.invoice_no == 123

    def test_sales_rep_oe_hdr_model(self) -> None:
        data = {"orderNo": 12345, "customerId": 100, "customerName": "Test", "totalAmount": 500.00}
        result = SalesRepOeHdr.model_validate(data)
        assert result.order_no == 12345

    def test_pick_tickets_list_params(self) -> None:
        params = PickTicketsListParams(limit=10, location_id=5)
        assert params.location_id == 5

    def test_pick_ticket_model(self) -> None:
        data = {"pickTicketNo": 1001, "orderNo": 12345, "locationId": 5, "statusCd": 1}
        result = PickTicket.model_validate(data)
        assert result.pick_ticket_no == 1001

    def test_pick_ticket_lines_params(self) -> None:
        params = PickTicketLinesParams(limit=10, offset=5, order_by="lineNumber")
        assert params.order_by == "lineNumber"

    def test_pick_ticket_line_model(self) -> None:
        data = {
            "lineNumber": 1,
            "pickTicketNo": 1001,
            "itemId": "ABC123",
            "quantityOrdered": 10.0,
            "quantityPicked": 10.0,
        }
        result = PickTicketLine.model_validate(data)
        assert result.line_number == 1
        assert result.quantity_ordered == 10.0

    def test_po_hdr_list_params(self) -> None:
        params = PoHdrListParams(limit=10, vendor_id="V001", status_cd=1)
        assert params.vendor_id == "V001"

    def test_po_hdr_scan_params(self) -> None:
        params = PoHdrScanParams(vendor_id="V001", item_id="ABC123")
        assert params.vendor_id == "V001"

    def test_po_hdr_model(self) -> None:
        data = {
            "poNo": 5001,
            "vendorId": "V001",
            "vendorName": "Test Vendor",
            "totalAmount": 1500.00,
        }
        result = PoHdr.model_validate(data)
        assert result.po_no == 5001
        assert result.vendor_name == "Test Vendor"

    def test_po_hdr_doc_model(self) -> None:
        data = {"poNo": 5001, "vendorId": "V001", "lines": [], "totals": {}}
        result = PoHdrDoc.model_validate(data)
        assert result.po_no == 5001
