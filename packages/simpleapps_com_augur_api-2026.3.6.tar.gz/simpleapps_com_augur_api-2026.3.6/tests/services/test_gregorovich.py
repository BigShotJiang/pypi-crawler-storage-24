"""Tests for the Gregorovich service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

from augur_api.services.gregorovich import GregorovichClient
from augur_api.services.gregorovich.client import (
    ChatGptResource,
    DocumentsResource,
    OllamaResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "gregorovich"
    return http


class TestGregorovichClient:
    """Tests for GregorovichClient lazy property initialisation."""

    def test_chat_gpt(self) -> None:
        client = GregorovichClient(mock_http())
        assert isinstance(client.chat_gpt, ChatGptResource)

    def test_documents(self) -> None:
        client = GregorovichClient(mock_http())
        assert isinstance(client.documents, DocumentsResource)

    def test_ollama(self) -> None:
        client = GregorovichClient(mock_http())
        assert isinstance(client.ollama, OllamaResource)

    def test_lazy_caching(self) -> None:
        """Accessing the same property twice returns the same instance."""
        client = GregorovichClient(mock_http())
        first = client.chat_gpt
        second = client.chat_gpt
        assert first is second


class TestChatGptResource:
    """Tests for /chat-gpt endpoints."""

    def test_get_ask(self) -> None:
        http = mock_http()
        r = ChatGptResource(http)
        result = r.get_ask()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/chat-gpt/ask"
        assert result.status == 200


class TestDocumentsResource:
    """Tests for /documents endpoints."""

    def test_list(self) -> None:
        http = mock_http()
        r = DocumentsResource(http)
        result = r.list()
        http.get.assert_called_once()
        assert http.get.call_args[0][0] == "/documents"
        assert result.status == 200


class TestOllamaResource:
    """Tests for /ollama endpoints."""

    def test_create_generate(self) -> None:
        http = mock_http()
        r = OllamaResource(http)
        result = r.create_generate(data={"model": "llama2", "prompt": "Hello"})
        http.post.assert_called_once()
        assert http.post.call_args[0][0] == "/ollama/generate"
        assert result.status == 200
