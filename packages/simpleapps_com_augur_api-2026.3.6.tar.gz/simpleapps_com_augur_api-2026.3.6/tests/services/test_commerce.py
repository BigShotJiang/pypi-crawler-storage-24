"""Tests for the Commerce service client (generated proxy)."""

from typing import Any
from unittest.mock import MagicMock

import pytest

from augur_api.services.commerce import CommerceClient
from augur_api.services.commerce.client import (
    CartHdrResource,
    CartLineResource,
    CheckoutResource,
)

MOCK_RESPONSE: dict[str, Any] = {
    "count": 1,
    "data": {"id": 1},
    "message": "Success",
    "options": [],
    "params": [],
    "status": 200,
    "total": 1,
    "totalResults": 1,
}


@pytest.fixture
def mock_http() -> MagicMock:
    """Create a mock HTTP client."""
    http = MagicMock()
    http.get.return_value = MOCK_RESPONSE
    http.post.return_value = MOCK_RESPONSE
    http.put.return_value = MOCK_RESPONSE
    http.delete.return_value = MOCK_RESPONSE
    http.service_name = "commerce"
    return http


# ============================================================================
# CommerceClient — lazy property access
# ============================================================================


class TestCommerceClient:
    """Tests for CommerceClient lazy property initialisation."""

    def test_cart_hdr(self, mock_http: MagicMock) -> None:
        client = CommerceClient(mock_http)
        assert isinstance(client.cart_hdr, CartHdrResource)

    def test_cart_line(self, mock_http: MagicMock) -> None:
        client = CommerceClient(mock_http)
        assert isinstance(client.cart_line, CartLineResource)

    def test_checkout(self, mock_http: MagicMock) -> None:
        client = CommerceClient(mock_http)
        assert isinstance(client.checkout, CheckoutResource)

    def test_lazy_caching(self, mock_http: MagicMock) -> None:
        """Accessing the same property twice returns the same instance."""
        client = CommerceClient(mock_http)
        first = client.cart_hdr
        second = client.cart_hdr
        assert first is second


# ============================================================================
# CartHdrResource
# ============================================================================


class TestCartHdrResource:
    """Tests for /cart-hdr endpoints."""

    def test_list_list(self, mock_http: MagicMock) -> None:
        r = CartHdrResource(mock_http)
        result = r.list_list()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/cart-hdr/list"
        assert result.status == 200

    def test_get_lookup(self, mock_http: MagicMock) -> None:
        r = CartHdrResource(mock_http)
        r.get_lookup()
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/cart-hdr/lookup"

    def test_list_also_bought(self, mock_http: MagicMock) -> None:
        r = CartHdrResource(mock_http)
        r.list_also_bought(123)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/cart-hdr/123/also-bought"


# ============================================================================
# CartLineResource
# ============================================================================


class TestCartLineResource:
    """Tests for /cart-line endpoints."""

    def test_get(self, mock_http: MagicMock) -> None:
        r = CartLineResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/cart-line/1"

    def test_delete(self, mock_http: MagicMock) -> None:
        r = CartLineResource(mock_http)
        r.delete(1)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/cart-line/1"

    def test_create_add(self, mock_http: MagicMock) -> None:
        r = CartLineResource(mock_http)
        r.create_add(1, data=[{"item": 1}])
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/cart-line/1/add"

    def test_delete_lines(self, mock_http: MagicMock) -> None:
        r = CartLineResource(mock_http)
        r.delete_lines(1, 2)
        mock_http.delete.assert_called_once()
        assert mock_http.delete.call_args[0][0] == "/cart-line/1/lines/2"

    def test_create_update(self, mock_http: MagicMock) -> None:
        r = CartLineResource(mock_http)
        r.create_update(1, data=[{"item": 1}])
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/cart-line/1/update"


# ============================================================================
# CheckoutResource
# ============================================================================


class TestCheckoutResource:
    """Tests for /checkout endpoints."""

    def test_create(self, mock_http: MagicMock) -> None:
        r = CheckoutResource(mock_http)
        r.create(data={"test": True})
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/checkout"

    def test_get(self, mock_http: MagicMock) -> None:
        r = CheckoutResource(mock_http)
        r.get(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/checkout/1"

    def test_update_activate(self, mock_http: MagicMock) -> None:
        r = CheckoutResource(mock_http)
        r.update_activate(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/checkout/1/activate"

    def test_list_doc(self, mock_http: MagicMock) -> None:
        r = CheckoutResource(mock_http)
        r.list_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/checkout/1/doc"

    def test_get_doc_alias(self, mock_http: MagicMock) -> None:
        """get_doc is an alias for list_doc."""
        r = CheckoutResource(mock_http)
        r.get_doc(1)
        mock_http.get.assert_called_once()
        assert mock_http.get.call_args[0][0] == "/checkout/1/doc"

    def test_create_prophet21_hdr(self, mock_http: MagicMock) -> None:
        r = CheckoutResource(mock_http)
        r.create_prophet21_hdr(1)
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/checkout/1/prophet21-hdr"

    def test_create_prophet21_hdr_prophet21_line(self, mock_http: MagicMock) -> None:
        r = CheckoutResource(mock_http)
        r.create_prophet21_hdr_prophet21_line(1, 2)
        mock_http.post.assert_called_once()
        assert mock_http.post.call_args[0][0] == "/checkout/1/prophet21-hdr/2/prophet21-line"

    def test_update_validate(self, mock_http: MagicMock) -> None:
        r = CheckoutResource(mock_http)
        r.update_validate(1)
        mock_http.put.assert_called_once()
        assert mock_http.put.call_args[0][0] == "/checkout/1/validate"


# ============================================================================
# Response validation
# ============================================================================


class TestResponseValidation:
    """Verify BaseResponse[Any] is returned correctly."""

    def test_list_returns_base_response(self, mock_http: MagicMock) -> None:
        r = CartHdrResource(mock_http)
        result = r.list_list()
        assert result.status == 200
        assert result.message == "Success"
        assert result.count == 1
        assert result.total == 1

    def test_get_returns_base_response(self, mock_http: MagicMock) -> None:
        r = CheckoutResource(mock_http)
        result = r.get(1)
        assert result.data == {"id": 1}
