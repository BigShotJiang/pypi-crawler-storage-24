"""
Generated Pydantic schemas for legacy service.
Source: shared/specs/legacy.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams

InvMastAlsoBoughtListParams = EdgeCacheParams


InvMastTagsListParams = EdgeCacheParams


InvMastTagsGetParams = EdgeCacheParams


InvMastWebDescListParams = EdgeCacheParams


InvMastWebDescGetParams = EdgeCacheParams


ItemCategoryGetParams = EdgeCacheParams


class LegacyStateListParams(EdgeCacheParams):
    """Params for GET /legacy/state."""

    limit: int | None = None
    offset: int | None = None
    two_letter_code: str | None = None


class LegacyStateGetParams(EdgeCacheParams):
    """Params for GET /legacy/state/{stateUid}."""

    two_letter_code: str | None = None


OrdersResetListParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class InvMastTagsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    inv_mast_tags_uid: int | None = None
    inv_mast_uid: int | None = None
    tag: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None


class InvMastWebDescData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    inv_mast_web_desc_uid: int | None = None
    inv_mast_uid: int | None = None
    web_desc1: str | None = None
    web_desc2: str | None = None
    web_desc3: str | None = None
    web_desc4: str | None = None
    web_desc_full: str | None = None
    date_created: str | None = None
    active: int | None = None
    date_last_modified: str | None = None
    date_last_checked: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None


class ItemCategoryData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    item_category_uid: int | None = None
    item_category_id: str | None = None
    item_category_desc: str | None = None
    article: str | None = None
    box_folder_id: str | None = None
    master_category_flag: str | None = None
    parent_category_flag: str | None = None
    display_on_web_flag: str | None = None
    delete_flag: str | None = None
    customer_approval: str | None = None
    date_last_modified: str | None = None
    date_last_checked: str | None = None
    article2: str | None = None
    article3: str | None = None
    article4: str | None = None
    article5: str | None = None
    sample_item_id: str | None = None
    meta_desc: str | None = None
    title: str | None = None
    update_cd: int | None = None
    sub_category_image_file: str | None = None
    last_maintained_by: str | None = None
    date_created: str | None = None
    created_by: str | None = None
    catalog_page: str | None = None
    display_master_product_flag: str | None = None


class LegacyStateData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    state_uid: int | None = None
    country_uid: int | None = None
    two_letter_code: str | None = None
    state_name: str | None = None
    date_created: str | None = None
    created_by: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    combined_federal_state1099_no: int | None = None
    telecheck_state_code: int | None = None
    update_cd: int | None = None
    active: int | None = None
    tax_rate: float | None = None
    date_last_checked: str | None = None
    tax_shipping: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
