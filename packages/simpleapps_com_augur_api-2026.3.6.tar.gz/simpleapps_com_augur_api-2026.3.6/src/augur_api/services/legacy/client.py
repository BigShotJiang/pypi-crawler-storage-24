"""
Generated client for legacy service.
Source: shared/specs/legacy.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.legacy.generated.schemas import (
        LegacyStateGetParams,
        LegacyStateListParams,
    )


class InvMastResource(BaseResource):
    """Resource for /inv-mast endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast")

    def list_also_bought(
        self,
        inv_mast_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/also-bought."""
        response = self._get(f"/{inv_mast_uid}/also-bought", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_tags(
        self,
        inv_mast_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/tags."""
        response = self._get(f"/{inv_mast_uid}/tags", params=options)
        return BaseResponse[Any].model_validate(response)

    def create_tags(self, inv_mast_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /inv-mast/{invMastUid}/tags."""
        response = self._post(f"/{inv_mast_uid}/tags", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_tags(self, inv_mast_uid: int, inv_mast_tags_uid: int) -> BaseResponse[Any]:
        """DELETE /inv-mast/{invMastUid}/tags/{invMastTagsUid}."""
        response = self._delete(f"/{inv_mast_uid}/tags/{inv_mast_tags_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_tags(
        self,
        inv_mast_uid: int,
        inv_mast_tags_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/tags/{invMastTagsUid}."""
        response = self._get(f"/{inv_mast_uid}/tags/{inv_mast_tags_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_tags(
        self,
        inv_mast_uid: int,
        inv_mast_tags_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /inv-mast/{invMastUid}/tags/{invMastTagsUid}."""
        response = self._put(f"/{inv_mast_uid}/tags/{inv_mast_tags_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_web_desc(
        self,
        inv_mast_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/web-desc."""
        response = self._get(f"/{inv_mast_uid}/web-desc", params=options)
        return BaseResponse[Any].model_validate(response)

    def create_web_desc(self, inv_mast_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /inv-mast/{invMastUid}/web-desc."""
        response = self._post(f"/{inv_mast_uid}/web-desc", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_web_desc(self, inv_mast_uid: int, inv_mast_web_desc_uid: int) -> BaseResponse[Any]:
        """DELETE /inv-mast/{invMastUid}/web-desc/{invMastWebDescUid}."""
        response = self._delete(f"/{inv_mast_uid}/web-desc/{inv_mast_web_desc_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_web_desc(
        self,
        inv_mast_uid: int,
        inv_mast_web_desc_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/web-desc/{invMastWebDescUid}."""
        response = self._get(f"/{inv_mast_uid}/web-desc/{inv_mast_web_desc_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_web_desc(
        self,
        inv_mast_uid: int,
        inv_mast_web_desc_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /inv-mast/{invMastUid}/web-desc/{invMastWebDescUid}."""
        response = self._put(f"/{inv_mast_uid}/web-desc/{inv_mast_web_desc_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class ItemCategoryResource(BaseResource):
    """Resource for /item-category endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-category")

    def get(
        self,
        item_category_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /item-category/{itemCategoryUid}."""
        response = self._get(f"/{item_category_uid}", params=options)
        return BaseResponse[Any].model_validate(response)


class LegacyResource(BaseResource):
    """Resource for /legacy endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/legacy")

    def list_state(self, params: LegacyStateListParams | None = None) -> BaseResponse[Any]:
        """GET /legacy/state."""
        response = self._get("/state", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_state(self, data: Any = None) -> BaseResponse[Any]:
        """POST /legacy/state."""
        response = self._post("/state", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_state(self, state_uid: int) -> BaseResponse[Any]:
        """DELETE /legacy/state/{stateUid}."""
        response = self._delete(f"/state/{state_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_state(
        self,
        state_uid: int,
        params: LegacyStateGetParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /legacy/state/{stateUid}."""
        response = self._get(f"/state/{state_uid}", params=params)
        return BaseResponse[Any].model_validate(response)

    def update_state(self, state_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /legacy/state/{stateUid}."""
        response = self._put(f"/state/{state_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class OrdersResource(BaseResource):
    """Resource for /orders endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/orders")

    def list_reset(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /orders/{id}/reset."""
        response = self._get(f"/{id}/reset", params=options)
        return BaseResponse[Any].model_validate(response)


class LegacyClient(BaseServiceClient):
    """Client for the legacy service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._inv_mast: InvMastResource | None = None
        self._item_category: ItemCategoryResource | None = None
        self._legacy: LegacyResource | None = None
        self._orders: OrdersResource | None = None

    @property
    def inv_mast(self) -> InvMastResource:
        """Access invMast endpoints."""
        if self._inv_mast is None:
            self._inv_mast = InvMastResource(self._http)
        return self._inv_mast

    @property
    def item_category(self) -> ItemCategoryResource:
        """Access itemCategory endpoints."""
        if self._item_category is None:
            self._item_category = ItemCategoryResource(self._http)
        return self._item_category

    @property
    def legacy(self) -> LegacyResource:
        """Access legacy endpoints."""
        if self._legacy is None:
            self._legacy = LegacyResource(self._http)
        return self._legacy

    @property
    def orders(self) -> OrdersResource:
        """Access orders endpoints."""
        if self._orders is None:
            self._orders = OrdersResource(self._http)
        return self._orders
