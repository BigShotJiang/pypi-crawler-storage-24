"""
Generated client for p21-pim service.
Source: shared/specs/p21-pim.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.p21_pim.generated.schemas import (
        InvMastExtListParams,
        ItemsSuggestDisplayDescListParams,
        ItemsSuggestWebDescListParams,
        PodcastsListParams,
    )


class InvMastExtResource(BaseResource):
    """Resource for /inv-mast-ext endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast-ext")

    def list(self, params: InvMastExtListParams | None = None) -> BaseResponse[Any]:
        """GET /inv-mast-ext."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /inv-mast-ext."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, inv_mast_ext_uid: int) -> BaseResponse[Any]:
        """DELETE /inv-mast-ext/{invMastExtUid}."""
        response = self._delete(f"/{inv_mast_ext_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        inv_mast_ext_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast-ext/{invMastExtUid}."""
        response = self._get(f"/{inv_mast_ext_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, inv_mast_ext_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /inv-mast-ext/{invMastExtUid}."""
        response = self._put(f"/{inv_mast_ext_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class ItemsResource(BaseResource):
    """Resource for /items endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/items")

    def list_suggest_display_desc(
        self,
        inv_mast_uid: int,
        params: ItemsSuggestDisplayDescListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /items/{invMastUid}/suggest-display-desc."""
        response = self._get(f"/{inv_mast_uid}/suggest-display-desc", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_suggest_web_desc(
        self,
        inv_mast_uid: int,
        params: ItemsSuggestWebDescListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /items/{invMastUid}/suggest-web-desc."""
        response = self._get(f"/{inv_mast_uid}/suggest-web-desc", params=params)
        return BaseResponse[Any].model_validate(response)


class PodcastsResource(BaseResource):
    """Resource for /podcasts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/podcasts")

    def list(self, params: PodcastsListParams | None = None) -> BaseResponse[Any]:
        """GET /podcasts."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /podcasts."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, podcasts_uid: int) -> BaseResponse[Any]:
        """DELETE /podcasts/{podcastsUid}."""
        response = self._delete(f"/{podcasts_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, podcasts_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /podcasts/{podcastsUid}."""
        response = self._get(f"/{podcasts_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, podcasts_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /podcasts/{podcastsUid}."""
        response = self._put(f"/{podcasts_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class P21PimClient(BaseServiceClient):
    """Client for the p21-pim service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._inv_mast_ext: InvMastExtResource | None = None
        self._items: ItemsResource | None = None
        self._podcasts: PodcastsResource | None = None

    @property
    def inv_mast_ext(self) -> InvMastExtResource:
        """Access invMastExt endpoints."""
        if self._inv_mast_ext is None:
            self._inv_mast_ext = InvMastExtResource(self._http)
        return self._inv_mast_ext

    @property
    def items(self) -> ItemsResource:
        """Access items endpoints."""
        if self._items is None:
            self._items = ItemsResource(self._http)
        return self._items

    @property
    def podcasts(self) -> PodcastsResource:
        """Access podcasts endpoints."""
        if self._podcasts is None:
            self._podcasts = PodcastsResource(self._http)
        return self._podcasts
