"""
Generated Pydantic schemas for avalara service.
Source: shared/specs/avalara.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations
