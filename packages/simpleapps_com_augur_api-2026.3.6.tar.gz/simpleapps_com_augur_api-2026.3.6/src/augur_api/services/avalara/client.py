"""
Generated client for avalara service.
Source: shared/specs/avalara.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class RatesResource(BaseResource):
    """Resource for /rates endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/rates")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /rates."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)


class AvalaraClient(BaseServiceClient):
    """Client for the avalara service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._rates: RatesResource | None = None

    @property
    def rates(self) -> RatesResource:
        """Access rates endpoints."""
        if self._rates is None:
            self._rates = RatesResource(self._http)
        return self._rates
