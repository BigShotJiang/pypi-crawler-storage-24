"""
Generated client for customers service.
Source: shared/specs/customers.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.customers.generated.schemas import (
        ContactsCustomersListParams,
        CustomerAddressListParams,
        CustomerContactsListParams,
        CustomerInvoicesListParams,
        CustomerListParams,
        CustomerLookupGetParams,
        CustomerOrdersListParams,
        CustomerPurchasedItemsListParams,
        CustomerQuotesListParams,
        CustomerShipToListParams,
    )


class ContactsResource(BaseResource):
    """Resource for /contacts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/contacts")

    def get_refresh(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /contacts/refresh."""
        response = self._get("/refresh", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_customers(
        self,
        id: int,
        params: ContactsCustomersListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /contacts/{id}/customers."""
        response = self._get(f"/{id}/customers", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_doc(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /contacts/{id}/doc."""
        response = self._get(f"/{id}/doc", params=options)
        return BaseResponse[Any].model_validate(response)

    def get_doc(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """Alias for list_doc — GET /contacts/{id}/doc."""
        return self.list_doc(id, options=options)

    def list_web_allowance(
        self,
        id: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /contacts/{id}/web-allowance."""
        response = self._get(f"/{id}/web-allowance", params=options)
        return BaseResponse[Any].model_validate(response)


class ContactsUdResource(BaseResource):
    """Resource for /contacts-ud endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/contacts-ud")

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /contacts-ud/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)


class CustomerResource(BaseResource):
    """Resource for /customer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/customer")

    def list(self, params: CustomerListParams | None = None) -> BaseResponse[Any]:
        """GET /customer."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get_lookup(self, params: CustomerLookupGetParams | None = None) -> BaseResponse[Any]:
        """GET /customer/lookup."""
        response = self._get("/lookup", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_address(
        self,
        customer_id: int,
        params: CustomerAddressListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/address."""
        response = self._get(f"/{customer_id}/address", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_contacts(
        self,
        customer_id: int,
        params: CustomerContactsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/contacts."""
        response = self._get(f"/{customer_id}/contacts", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_contacts(self, customer_id: int, data: Any = None) -> BaseResponse[Any]:
        """POST /customer/{customerId}/contacts."""
        response = self._post(f"/{customer_id}/contacts", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_doc(
        self,
        customer_id: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/doc."""
        response = self._get(f"/{customer_id}/doc", params=options)
        return BaseResponse[Any].model_validate(response)

    def get_doc(
        self,
        customer_id: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """Alias for list_doc — GET /customer/{customerId}/doc."""
        return self.list_doc(customer_id, options=options)

    def list_invoices(
        self,
        customer_id: int,
        params: CustomerInvoicesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/invoices."""
        response = self._get(f"/{customer_id}/invoices", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_invoices(
        self,
        customer_id: int,
        invoice_no: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/invoices/{invoiceNo}."""
        response = self._get(f"/{customer_id}/invoices/{invoice_no}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_orders(
        self,
        customer_id: int,
        params: CustomerOrdersListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/orders."""
        response = self._get(f"/{customer_id}/orders", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_orders(
        self,
        customer_id: int,
        order_no: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/orders/{orderNo}."""
        response = self._get(f"/{customer_id}/orders/{order_no}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_purchased_items(
        self,
        customer_id: int,
        params: CustomerPurchasedItemsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/purchased-items."""
        response = self._get(f"/{customer_id}/purchased-items", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_quotes(
        self,
        customer_id: int,
        params: CustomerQuotesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/quotes."""
        response = self._get(f"/{customer_id}/quotes", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_quotes(
        self,
        customer_id: int,
        quote_no: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/quotes/{quoteNo}."""
        response = self._get(f"/{customer_id}/quotes/{quote_no}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_ship_to(
        self,
        customer_id: int,
        params: CustomerShipToListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /customer/{customerId}/ship-to."""
        response = self._get(f"/{customer_id}/ship-to", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_ship_to(self, customer_id: int, data: Any = None) -> BaseResponse[Any]:
        """POST /customer/{customerId}/ship-to."""
        response = self._post(f"/{customer_id}/ship-to", data=data)
        return BaseResponse[Any].model_validate(response)


class OeContactsCustomerResource(BaseResource):
    """Resource for /oe-contacts-customer endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/oe-contacts-customer")

    def get_refresh(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /oe-contacts-customer/refresh."""
        response = self._get("/refresh", params=options)
        return BaseResponse[Any].model_validate(response)


class ShipToResource(BaseResource):
    """Resource for /ship-to endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/ship-to")

    def get_refresh(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /ship-to/refresh."""
        response = self._get("/refresh", params=options)
        return BaseResponse[Any].model_validate(response)


class CustomersClient(BaseServiceClient):
    """Client for the customers service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._contacts: ContactsResource | None = None
        self._contacts_ud: ContactsUdResource | None = None
        self._customer: CustomerResource | None = None
        self._oe_contacts_customer: OeContactsCustomerResource | None = None
        self._ship_to: ShipToResource | None = None

    @property
    def contacts(self) -> ContactsResource:
        """Access contacts endpoints."""
        if self._contacts is None:
            self._contacts = ContactsResource(self._http)
        return self._contacts

    @property
    def contacts_ud(self) -> ContactsUdResource:
        """Access contactsUd endpoints."""
        if self._contacts_ud is None:
            self._contacts_ud = ContactsUdResource(self._http)
        return self._contacts_ud

    @property
    def customer(self) -> CustomerResource:
        """Access customer endpoints."""
        if self._customer is None:
            self._customer = CustomerResource(self._http)
        return self._customer

    @property
    def oe_contacts_customer(self) -> OeContactsCustomerResource:
        """Access oeContactsCustomer endpoints."""
        if self._oe_contacts_customer is None:
            self._oe_contacts_customer = OeContactsCustomerResource(self._http)
        return self._oe_contacts_customer

    @property
    def ship_to(self) -> ShipToResource:
        """Access shipTo endpoints."""
        if self._ship_to is None:
            self._ship_to = ShipToResource(self._http)
        return self._ship_to
