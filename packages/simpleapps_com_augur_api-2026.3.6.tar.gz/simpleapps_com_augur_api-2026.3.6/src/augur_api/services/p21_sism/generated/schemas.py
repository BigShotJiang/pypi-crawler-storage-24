"""
Generated Pydantic schemas for p21-sism service.
Source: shared/specs/p21-sism.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class ImportListParams(EdgeCacheParams):
    """Params for GET /import."""

    import_state: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    reference_no: str | None = None


class ImportRecentListParams(EdgeCacheParams):
    """Params for GET /import/recent."""

    hours: int | None = None
    limit: int | None = None


class ImportStuckListParams(EdgeCacheParams):
    """Params for GET /import/stuck."""

    hours: int | None = None
    limit: int | None = None


ImportGetParams = EdgeCacheParams


ImportImpOeHdrListParams = EdgeCacheParams


ImportImpOeHdrSalesrepListParams = EdgeCacheParams


ImportImpOeHdrWebListParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class ImportData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    import_uid: int | None = None
    scheduled_import_master_uid: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    source_name: str | None = None
    source_id: int | None = None
    import_state: str | None = None
    json_data: str | None = None
    import_status_cd: int | None = None
    import_results: str | None = None
    reference_no: str | None = None
