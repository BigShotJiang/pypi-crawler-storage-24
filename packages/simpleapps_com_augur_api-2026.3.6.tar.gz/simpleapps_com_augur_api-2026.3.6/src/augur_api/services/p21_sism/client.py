"""
Generated client for p21-sism service.
Source: shared/specs/p21-sism.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.p21_sism.generated.schemas import (
        ImportListParams,
        ImportRecentListParams,
        ImportStuckListParams,
    )


class ImportResource(BaseResource):
    """Resource for /import endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/import")

    def list(self, params: ImportListParams | None = None) -> BaseResponse[Any]:
        """GET /import."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def list_recent(self, params: ImportRecentListParams | None = None) -> BaseResponse[Any]:
        """GET /import/recent."""
        response = self._get("/recent", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_stuck(self, params: ImportStuckListParams | None = None) -> BaseResponse[Any]:
        """GET /import/stuck."""
        response = self._get("/stuck", params=params)
        return BaseResponse[Any].model_validate(response)

    def delete(self, import_uid: str) -> BaseResponse[Any]:
        """DELETE /import/{importUid}."""
        response = self._delete(f"/{import_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, import_uid: str, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /import/{importUid}."""
        response = self._get(f"/{import_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, import_uid: str, data: Any = None) -> BaseResponse[Any]:
        """PUT /import/{importUid}."""
        response = self._put(f"/{import_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_imp_oe_hdr(
        self,
        import_uid: str,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /import/{importUid}/imp-oe-hdr."""
        response = self._get(f"/{import_uid}/imp-oe-hdr", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_imp_oe_hdr(self, import_uid: str, data: Any = None) -> BaseResponse[Any]:
        """PUT /import/{importUid}/imp-oe-hdr."""
        response = self._put(f"/{import_uid}/imp-oe-hdr", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_imp_oe_hdr_salesrep(
        self,
        import_uid: str,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /import/{importUid}/imp-oe-hdr-salesrep."""
        response = self._get(f"/{import_uid}/imp-oe-hdr-salesrep", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_imp_oe_hdr_salesrep(self, import_uid: str, data: Any = None) -> BaseResponse[Any]:
        """PUT /import/{importUid}/imp-oe-hdr-salesrep."""
        response = self._put(f"/{import_uid}/imp-oe-hdr-salesrep", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_imp_oe_hdr_web(
        self,
        import_uid: str,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /import/{importUid}/imp-oe-hdr-web."""
        response = self._get(f"/{import_uid}/imp-oe-hdr-web", params=options)
        return BaseResponse[Any].model_validate(response)


class ScheduledImportMasterResource(BaseResource):
    """Resource for /scheduled-import-master endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/scheduled-import-master")

    def create_metadata_sftp(
        self,
        scheduled_import_master_uid: str,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """POST /scheduled-import-master/{scheduledImportMasterUid}/metadata/sftp."""
        response = self._post(f"/{scheduled_import_master_uid}/metadata/sftp", data=data)
        return BaseResponse[Any].model_validate(response)


class P21SismClient(BaseServiceClient):
    """Client for the p21-sism service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._import_: ImportResource | None = None
        self._scheduled_import_master: ScheduledImportMasterResource | None = None

    @property
    def import_(self) -> ImportResource:
        """Access import endpoints."""
        if self._import_ is None:
            self._import_ = ImportResource(self._http)
        return self._import_

    @property
    def scheduled_import_master(self) -> ScheduledImportMasterResource:
        """Access scheduledImportMaster endpoints."""
        if self._scheduled_import_master is None:
            self._scheduled_import_master = ScheduledImportMasterResource(self._http)
        return self._scheduled_import_master
