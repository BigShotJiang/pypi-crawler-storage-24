"""
Generated Pydantic schemas for items service.
Source: shared/specs/items.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class AttributeGroupsListParams(EdgeCacheParams):
    """Params for GET /attribute-groups."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


AttributeGroupsGetParams = EdgeCacheParams


class AttributeGroupsAttributesListParams(EdgeCacheParams):
    """Params for GET /attribute-groups/{attributeGroupUid}/attributes."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


AttributeGroupsAttributesGetParams = EdgeCacheParams


class AttributesListParams(EdgeCacheParams):
    """Params for GET /attributes."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


AttributesGetParams = EdgeCacheParams


class AttributesValuesListParams(EdgeCacheParams):
    """Params for GET /attributes/{attributeUid}/values."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


AttributesValuesGetParams = EdgeCacheParams


class BrandsListParams(EdgeCacheParams):
    """Params for GET /brands."""

    limit: int | None = None
    offset: int | None = None


class BrandsGetParams(EdgeCacheParams):
    """Params for GET /brands/{brandsUid}."""

    brands_id: str | None = None


BrandsAttributesListParams = EdgeCacheParams


class BrandsItemsListParams(EdgeCacheParams):
    """Params for GET /brands/{brandsUid}/items."""

    class_id5_exclude_list: str | None = None
    class_id5_list: str | None = None
    display_on_web_flag: str | None = None
    fields: str | None = None
    filters: str | None = None
    include_stock: str | None = None
    limit: int | None = None
    offset: int | None = None
    q: str | None = None
    sort_by: str | None = None
    tags: str | None = None
    variant_filter: str | None = None


class CategoriesLookupGetParams(EdgeCacheParams):
    """Params for GET /categories/lookup."""

    cache_ttl: int | None = None
    path: str | None = None
    root_item_category_id: str | None = None


class CategoriesGetParams(EdgeCacheParams):
    """Params for GET /categories/{itemCategoryUid}."""

    cache_ttl: int | None = None
    children_filter: str | None = None
    children_limit: int | None = None
    children_offset: int | None = None
    class_id5_exclude_list: str | None = None
    class_id5_list: str | None = None
    filters: str | None = None
    include_ud: str | None = None
    order_by: str | None = None
    path: str | None = None
    product_collection: str | None = None
    root_item_category_id: str | None = None


class CategoriesAttributesListParams(EdgeCacheParams):
    """Params for GET /categories/{itemCategoryUid}/attributes."""

    cache_ttl: int | None = None
    include_sub_categories: str | None = None
    product_collection: str | None = None


class CategoriesImagesListParams(EdgeCacheParams):
    """Params for GET /categories/{itemCategoryUid}/images."""

    cache_ttl: int | None = None


class CategoriesItemsListParams(EdgeCacheParams):
    """Params for GET /categories/{itemCategoryUid}/items."""

    cache_ttl: int | None = None
    class_id5_exclude_list: str | None = None
    class_id5_list: str | None = None
    display_on_web_flag: str | None = None
    fields: str | None = None
    filters: str | None = None
    include_stock: str | None = None
    job_numbers: str | None = None
    limit: int | None = None
    offset: int | None = None
    q: str | None = None
    sort_by: str | None = None
    stock_status: str | None = None
    tags: str | None = None
    variant_filter: str | None = None


ContractsAttributesListParams = EdgeCacheParams


class ContractsItemsListParams(EdgeCacheParams):
    """Params for GET /contracts/{jobNo}/items."""

    class_id5_exclude_list: str | None = None
    class_id5_list: str | None = None
    display_on_web_flag: str | None = None
    fields: str | None = None
    filters: str | None = None
    include_stock: str | None = None
    limit: int | None = None
    offset: int | None = None
    q: str | None = None
    sort_by: str | None = None
    tags: str | None = None
    variant_filter: str | None = None


class InvLocListParams(EdgeCacheParams):
    """Params for GET /inv-loc."""

    inv_mast_uid: int | None = None
    limit: int | None = None
    offset: int | None = None


class InvMastListParams(EdgeCacheParams):
    """Params for GET /inv-mast."""

    item_category_uid: int | None = None
    limit: int | None = None
    offset: int | None = None
    online_cd: int | None = None
    prefix: str | None = None
    q: str | None = None
    status_cd: int | None = None


InvMastLinksGetParams = EdgeCacheParams


class InvMastSubPartsGetParams(EdgeCacheParams):
    """Params for GET /inv-mast-sub-parts/{invMastUid}."""

    inv_mast_links_uid: int | None = None


class InvMastUdListParams(EdgeCacheParams):
    """Params for GET /inv-mast-ud."""

    created_since: str | None = None
    inv_mast_ud_uid: int | None = None
    inv_mast_uid: int | None = None
    limit: int | None = None
    modified_since: str | None = None
    offset: int | None = None
    order_by: str | None = None
    status_cd: int | None = None


class InvMastLookupGetParams(EdgeCacheParams):
    """Params for GET /inv-mast/lookup."""

    limit: int | None = None
    offset: int | None = None
    online_cd: int | None = None
    order_by: str | None = None
    q: str
    status_cd: int | None = None


InvMastGetParams = EdgeCacheParams


class InvMastAlternateCodeListParams(EdgeCacheParams):
    """Params for GET /inv-mast/{invMastUid}/alternate-code."""

    limit: int | None = None
    offset: int | None = None


class InvMastAttributesListParams(EdgeCacheParams):
    """Params for GET /inv-mast/{invMastUid}/attributes."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


class InvMastAttributesValuesListParams(EdgeCacheParams):
    """Params for GET /inv-mast/{invMastUid}/attributes/{attributeUid}/values."""

    attribute_value_uid: int | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


class InvMastDocListParams(EdgeCacheParams):
    """Params for GET /inv-mast/{invMastUid}/doc."""

    include_pricing: str | None = None
    item_id: str | None = None


class InvMastFaqListParams(EdgeCacheParams):
    """Params for GET /inv-mast/{invMastUid}/faq."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    status_cd: int | None = None


InvMastFaqGetParams = EdgeCacheParams


class InvMastInvAccessoryListParams(EdgeCacheParams):
    """Params for GET /inv-mast/{invMastUid}/inv-accessory."""

    limit: int | None = None
    offset: int | None = None


class InvMastInvSubListParams(EdgeCacheParams):
    """Params for GET /inv-mast/{invMastUid}/inv-sub."""

    limit: int | None = None
    offset: int | None = None


class InvMastLocationsBinsListParams(EdgeCacheParams):
    """Params for GET /inv-mast/{invMastUid}/locations/{locationId}/bins."""

    exclude_zero: str | None = None
    limit: int | None = None
    offset: int | None = None


InvMastLocationsBinsGetParams = EdgeCacheParams


InvMastSimilarListParams = EdgeCacheParams


InvMastStockGetParams = EdgeCacheParams


class ItemCategoryListParams(EdgeCacheParams):
    """Params for GET /item-category."""

    limit: int | None = None
    offset: int | None = None
    q: str | None = None


class ItemCategoryLookupGetParams(EdgeCacheParams):
    """Params for GET /item-category/lookup."""

    path: str | None = None
    root_item_category_id: str | None = None


ItemCategoryGetParams = EdgeCacheParams


ItemCategoryDocListParams = EdgeCacheParams


class ItemFavoritesItemsListParams(EdgeCacheParams):
    """Params for GET /item-favorites/{usersId}/items."""

    limit: int | None = None
    offset: int | None = None
    use_item_doc: str | None = None


ItemFavoritesItemsGetParams = EdgeCacheParams


class ItemUomListParams(EdgeCacheParams):
    """Params for GET /item-uom."""

    created_since: str | None = None
    delete_flag: str | None = None
    inv_mast_uid: int | None = None
    limit: int | None = None
    modified_since: str | None = None
    offset: int | None = None
    order_by: str | None = None
    unit_of_measure: str | None = None


ItemUomGetParams = EdgeCacheParams


ItemWishlistGetParams = EdgeCacheParams


ItemWishlistHdrGetParams = EdgeCacheParams


class LocationsBinsListParams(EdgeCacheParams):
    """Params for GET /locations/{locationId}/bins."""

    bin: str | None = None
    exclude_zero: str | None = None
    limit: int | None = None
    offset: int | None = None


class LocationsBinsGetParams(EdgeCacheParams):
    """Params for GET /locations/{locationId}/bins/{bin}."""

    exclude_zero: str | None = None
    limit: int | None = None
    offset: int | None = None


class P21InvMastListParams(EdgeCacheParams):
    """Params for GET /p21/inv-mast."""

    created_since: str | None = None
    limit: int | None = None
    modified_since: str | None = None
    offset: int | None = None
    online_cd: int | None = None
    order_by: str | None = None
    status_cd: int | None = None


class VariantsListParams(EdgeCacheParams):
    """Params for GET /variants."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


VariantsGetParams = EdgeCacheParams


class VariantsAttributesListParams(EdgeCacheParams):
    """Params for GET /variants/{itemVariantHdrUid}/attributes."""

    limit: int | None = None
    offset: int | None = None


VariantsAttributesGetParams = EdgeCacheParams


class VariantsDocListParams(EdgeCacheParams):
    """Params for GET /variants/{itemVariantHdrUid}/doc."""

    item_id: str | None = None


class VariantsLinesListParams(EdgeCacheParams):
    """Params for GET /variants/{itemVariantHdrUid}/lines."""

    limit: int | None = None
    offset: int | None = None
    status_cd: int | None = None


VariantsLinesGetParams = EdgeCacheParams


VariantsSimilarListParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class AttributeGroupsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    attribute_group_uid: int | None = None
    attribute_group_id: str | None = None
    attribute_group_desc: str | None = None
    row_status_flag: int | None = None
    date_created: str | None = None
    created_by: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    attribute_group_type: int | None = None
    update_cd: int | None = None
    process_cd: int | None = None
    status_cd: int | None = None
    type_cd: int | None = None
    searchable_cd: int | None = None
    item_count: int | None = None


class AttributeGroupsAttributesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    attribute_x_attribute_group_uid: int | None = None
    required_flag: str | None = None
    row_status_flag: int | None = None
    date_created: str | None = None
    created_by: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    attribute_uid: int | None = None
    attribute_group_uid: int | None = None
    sequence_no: int | None = None
    update_cd: int | None = None
    process_cd: int | None = None
    status_cd: int | None = None


class AttributesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    attribute_uid: int | None = None
    attribute_desc: str | None = None
    extended_desc: str | None = None
    attribute_id: str | None = None
    data_type: int | None = None
    max_length: int | None = None
    no_of_decimal: int | None = None
    row_status_flag: int | None = None
    validation_required_flag: str | None = None
    date_created: str | None = None
    created_by: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    cfdi_attribute_type: int | None = None
    update_cd: int | None = None
    process_cd: int | None = None
    status_cd: int | None = None
    type_cd: int | None = None


class AttributesValuesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    attribute_value_uid: int | None = None
    attribute_uid: int | None = None
    attribute_value: str | None = None
    row_status_flag: int | None = None
    date_created: str | None = None
    created_by: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    update_cd: int | None = None
    process_cd: int | None = None
    status_cd: int | None = None
    sequence_no: int | None = None
    item_count: int | None = None


class BrandsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    brands_uid: int | None = None
    brands_name: str | None = None
    brands_id: str | None = None
    brands_desc: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    content_id: int | None = None


class InvLocData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    company_id: str | None = None
    location_id: float | None = None
    inv_mast_uid: int | None = None
    qty_on_hand: float | None = None
    qty_in_process: float | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    next_due_in_po_date: str | None = None
    sellable: str | None = None
    moving_average_cost: float | None = None
    standard_cost: float | None = None
    protected_stock_qty: float | None = None
    inv_min: float | None = None
    inv_max: float | None = None
    safety_stock: float | None = None
    stockable: str | None = None
    average_monthly_usage: float | None = None
    no_charge: str | None = None
    price1: float | None = None
    price2: float | None = None
    price3: float | None = None
    price4: float | None = None
    price5: float | None = None
    price6: float | None = None
    price7: float | None = None
    price8: float | None = None
    price9: float | None = None
    price10: float | None = None
    order_quantity: float | None = None
    qty_allocated: float | None = None
    qty_backordered: float | None = None
    qty_in_transit: float | None = None
    track_bins: str | None = None
    primary_bin: str | None = None
    qty_reserved_due_in: float | None = None
    date_last_counted: str | None = None
    deadstock_flag: str | None = None
    primary_supplier_id: float | None = None
    last_sale_date: str | None = None
    last_purchase_date: str | None = None
    inv_last_changed_date: str | None = None
    min_replenishment_qty: float | None = None
    discontinued: str | None = None
    price_family_uid: int | None = None
    delete_flag: str | None = None
    default_selling_unit: str | None = None
    future_standard_cost: float | None = None
    effective_date: str | None = None
    restricted_flag: str | None = None
    update_cd: int | None = None
    product_group_id: str | None = None
    purchase_discount_group: str | None = None
    sales_discount_group: str | None = None


class InvMastAttributesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    item_attribute_value_uid: int | None = None
    inv_mast_uid: int | None = None
    attribute_uid: int | None = None
    attribute_value: str | None = None
    date_created: str | None = None
    created_by: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    update_cd: int | None = None
    process_cd: int | None = None
    status_cd: int | None = None
    attribute_value_uid: int | None = None
    online_cd: int | None = None


class InvMastFaqData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    inv_mast_faq_uid: int | None = None
    inv_mast_uid: int | None = None
    question: str | None = None
    answer: str | None = None
    generated_answer: str | None = None
    source_count: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    related_questions_uid: int | None = None
    generate_cd: int | None = None
    extra_prompt: str | None = None
    accurate_flag: str | None = None
    quality_score: float | None = None


class ItemUomData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    unit_of_measure: str | None = None
    delete_flag: str | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    last_maintained_by: str | None = None
    unit_size: float | None = None
    selling_unit: str | None = None
    purchasing_unit: str | None = None
    inv_mast_uid: int | None = None
    created_by: str | None = None
    item_uom_uid: int | None = None
    b2b_unit_flag: str | None = None
    tally_factor: float | None = None
    wwms_flag: str | None = None
    prod_order_factor: int | None = None
    minimum_order_qty: float | None = None
    update_cd: int | None = None


class VariantsLinesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    item_variant_line_uid: int | None = None
    item_variant_hdr_uid: int | None = None
    inv_mast_uid: int | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    update_cd: int | None = None
    status_cd: int | None = None
    process_cd: int | None = None
    primary_cd: int | None = None
    sequence_no: int | None = None
