"""
Generated client for items service.
Source: shared/specs/items.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.items.generated.schemas import (
        AttributeGroupsAttributesListParams,
        AttributeGroupsListParams,
        AttributesListParams,
        AttributesValuesListParams,
        BrandsGetParams,
        BrandsItemsListParams,
        BrandsListParams,
        CategoriesAttributesListParams,
        CategoriesGetParams,
        CategoriesImagesListParams,
        CategoriesItemsListParams,
        CategoriesLookupGetParams,
        ContractsItemsListParams,
        InvLocListParams,
        InvMastAlternateCodeListParams,
        InvMastAttributesListParams,
        InvMastAttributesValuesListParams,
        InvMastDocListParams,
        InvMastFaqListParams,
        InvMastInvAccessoryListParams,
        InvMastInvSubListParams,
        InvMastListParams,
        InvMastLocationsBinsListParams,
        InvMastLookupGetParams,
        InvMastSubPartsGetParams,
        InvMastUdListParams,
        ItemCategoryListParams,
        ItemCategoryLookupGetParams,
        ItemFavoritesItemsListParams,
        ItemUomListParams,
        LocationsBinsGetParams,
        LocationsBinsListParams,
        P21InvMastListParams,
        VariantsAttributesListParams,
        VariantsDocListParams,
        VariantsLinesListParams,
        VariantsListParams,
    )


class AttributeGroupsResource(BaseResource):
    """Resource for /attribute-groups endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/attribute-groups")

    def list(self, params: AttributeGroupsListParams | None = None) -> BaseResponse[Any]:
        """GET /attribute-groups."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /attribute-groups."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, attribute_group_uid: int) -> BaseResponse[Any]:
        """DELETE /attribute-groups/{attributeGroupUid}."""
        response = self._delete(f"/{attribute_group_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        attribute_group_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /attribute-groups/{attributeGroupUid}."""
        response = self._get(f"/{attribute_group_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, attribute_group_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /attribute-groups/{attributeGroupUid}."""
        response = self._put(f"/{attribute_group_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_attributes(
        self,
        attribute_group_uid: int,
        params: AttributeGroupsAttributesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /attribute-groups/{attributeGroupUid}/attributes."""
        response = self._get(f"/{attribute_group_uid}/attributes", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_attributes(self, attribute_group_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /attribute-groups/{attributeGroupUid}/attributes."""
        response = self._post(f"/{attribute_group_uid}/attributes", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_attributes(
        self,
        attribute_group_uid: int,
        attribute_x_attribute_group_uid: int,
    ) -> BaseResponse[Any]:
        """DELETE endpoint."""
        response = self._delete(
            f"/{attribute_group_uid}/attributes/{attribute_x_attribute_group_uid}",
        )
        return BaseResponse[Any].model_validate(response)

    def get_attributes(
        self,
        attribute_group_uid: int,
        attribute_x_attribute_group_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /attribute-groups/{attributeGroupUid}/attributes/{attributeXAttributeGroupUid}."""
        response = self._get(
            f"/{attribute_group_uid}/attributes/{attribute_x_attribute_group_uid}",
            params=options,
        )
        return BaseResponse[Any].model_validate(response)

    def update_attributes(
        self,
        attribute_group_uid: int,
        attribute_x_attribute_group_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /attribute-groups/{attributeGroupUid}/attributes/{attributeXAttributeGroupUid}."""
        response = self._put(
            f"/{attribute_group_uid}/attributes/{attribute_x_attribute_group_uid}",
            data=data,
        )
        return BaseResponse[Any].model_validate(response)


class AttributesResource(BaseResource):
    """Resource for /attributes endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/attributes")

    def list(self, params: AttributesListParams | None = None) -> BaseResponse[Any]:
        """GET /attributes."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /attributes."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, attribute_uid: int) -> BaseResponse[Any]:
        """DELETE /attributes/{attributeUid}."""
        response = self._delete(f"/{attribute_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, attribute_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /attributes/{attributeUid}."""
        response = self._get(f"/{attribute_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, attribute_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /attributes/{attributeUid}."""
        response = self._put(f"/{attribute_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_values(
        self,
        attribute_uid: int,
        params: AttributesValuesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /attributes/{attributeUid}/values."""
        response = self._get(f"/{attribute_uid}/values", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_values(self, attribute_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /attributes/{attributeUid}/values."""
        response = self._post(f"/{attribute_uid}/values", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_values(self, attribute_uid: int, attribute_value_uid: int) -> BaseResponse[Any]:
        """DELETE /attributes/{attributeUid}/values/{attributeValueUid}."""
        response = self._delete(f"/{attribute_uid}/values/{attribute_value_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_values(
        self,
        attribute_uid: int,
        attribute_value_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /attributes/{attributeUid}/values/{attributeValueUid}."""
        response = self._get(f"/{attribute_uid}/values/{attribute_value_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_values(
        self,
        attribute_uid: int,
        attribute_value_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /attributes/{attributeUid}/values/{attributeValueUid}."""
        response = self._put(f"/{attribute_uid}/values/{attribute_value_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class BrandsResource(BaseResource):
    """Resource for /brands endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/brands")

    def list(self, params: BrandsListParams | None = None) -> BaseResponse[Any]:
        """GET /brands."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /brands."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, brands_uid: int) -> BaseResponse[Any]:
        """DELETE /brands/{brandsUid}."""
        response = self._delete(f"/{brands_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, brands_uid: int, params: BrandsGetParams | None = None) -> BaseResponse[Any]:
        """GET /brands/{brandsUid}."""
        response = self._get(f"/{brands_uid}", params=params)
        return BaseResponse[Any].model_validate(response)

    def update(self, brands_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /brands/{brandsUid}."""
        response = self._put(f"/{brands_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_attributes(
        self,
        brands_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /brands/{brandsUid}/attributes."""
        response = self._get(f"/{brands_uid}/attributes", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_items(
        self,
        brands_uid: int,
        params: BrandsItemsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /brands/{brandsUid}/items."""
        response = self._get(f"/{brands_uid}/items", params=params)
        return BaseResponse[Any].model_validate(response)


class CategoriesResource(BaseResource):
    """Resource for /categories endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/categories")

    def get_lookup(self, params: CategoriesLookupGetParams | None = None) -> BaseResponse[Any]:
        """GET /categories/lookup."""
        response = self._get("/lookup", params=params)
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        item_category_uid: int,
        params: CategoriesGetParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /categories/{itemCategoryUid}."""
        response = self._get(f"/{item_category_uid}", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_attributes(
        self,
        item_category_uid: int,
        params: CategoriesAttributesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /categories/{itemCategoryUid}/attributes."""
        response = self._get(f"/{item_category_uid}/attributes", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_images(
        self,
        item_category_uid: int,
        params: CategoriesImagesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /categories/{itemCategoryUid}/images."""
        response = self._get(f"/{item_category_uid}/images", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_items(
        self,
        item_category_uid: int,
        params: CategoriesItemsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /categories/{itemCategoryUid}/items."""
        response = self._get(f"/{item_category_uid}/items", params=params)
        return BaseResponse[Any].model_validate(response)


class ContractsResource(BaseResource):
    """Resource for /contracts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/contracts")

    def list_attributes(
        self,
        job_no: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /contracts/{jobNo}/attributes."""
        response = self._get(f"/{job_no}/attributes", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_items(
        self,
        job_no: int,
        params: ContractsItemsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /contracts/{jobNo}/items."""
        response = self._get(f"/{job_no}/items", params=params)
        return BaseResponse[Any].model_validate(response)


class InternalResource(BaseResource):
    """Resource for /internal endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/internal")

    def create_pdf(self, data: Any = None) -> BaseResponse[Any]:
        """POST /internal/pdf."""
        response = self._post("/pdf", data=data)
        return BaseResponse[Any].model_validate(response)


class InvLocResource(BaseResource):
    """Resource for /inv-loc endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-loc")

    def list(self, params: InvLocListParams | None = None) -> BaseResponse[Any]:
        """GET /inv-loc."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class InvMastResource(BaseResource):
    """Resource for /inv-mast endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast")

    def list(self, params: InvMastListParams | None = None) -> BaseResponse[Any]:
        """GET /inv-mast."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get_lookup(self, params: InvMastLookupGetParams | None = None) -> BaseResponse[Any]:
        """GET /inv-mast/lookup."""
        response = self._get("/lookup", params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}."""
        response = self._get(f"/{inv_mast_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_alternate_code(
        self,
        inv_mast_uid: int,
        params: InvMastAlternateCodeListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/alternate-code."""
        response = self._get(f"/{inv_mast_uid}/alternate-code", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_attributes(
        self,
        inv_mast_uid: int,
        params: InvMastAttributesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/attributes."""
        response = self._get(f"/{inv_mast_uid}/attributes", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_attributes(self, inv_mast_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /inv-mast/{invMastUid}/attributes."""
        response = self._post(f"/{inv_mast_uid}/attributes", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_attributes_values(
        self,
        inv_mast_uid: int,
        attribute_uid: int,
        params: InvMastAttributesValuesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/attributes/{attributeUid}/values."""
        response = self._get(f"/{inv_mast_uid}/attributes/{attribute_uid}/values", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_attributes_values(
        self,
        inv_mast_uid: int,
        attribute_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """POST /inv-mast/{invMastUid}/attributes/{attributeUid}/values."""
        response = self._post(f"/{inv_mast_uid}/attributes/{attribute_uid}/values", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_attributes_values(
        self,
        inv_mast_uid: int,
        attribute_uid: int,
        attribute_value_uid: int,
    ) -> BaseResponse[Any]:
        """DELETE /inv-mast/{invMastUid}/attributes/{attributeUid}/values/{attributeValueUid}."""
        response = self._delete(
            f"/{inv_mast_uid}/attributes/{attribute_uid}/values/{attribute_value_uid}",
        )
        return BaseResponse[Any].model_validate(response)

    def update_attributes_values(
        self,
        inv_mast_uid: int,
        attribute_uid: int,
        attribute_value_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /inv-mast/{invMastUid}/attributes/{attributeUid}/values/{attributeValueUid}."""
        response = self._put(
            f"/{inv_mast_uid}/attributes/{attribute_uid}/values/{attribute_value_uid}",
            data=data,
        )
        return BaseResponse[Any].model_validate(response)

    def list_doc(
        self,
        inv_mast_uid: int,
        params: InvMastDocListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/doc."""
        response = self._get(f"/{inv_mast_uid}/doc", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_doc(
        self,
        inv_mast_uid: int,
        params: InvMastDocListParams | None = None,
    ) -> BaseResponse[Any]:
        """Alias for list_doc — GET /inv-mast/{invMastUid}/doc."""
        return self.list_doc(inv_mast_uid, params=params)

    def list_faq(
        self,
        inv_mast_uid: int,
        params: InvMastFaqListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/faq."""
        response = self._get(f"/{inv_mast_uid}/faq", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_faq(self, inv_mast_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /inv-mast/{invMastUid}/faq."""
        response = self._post(f"/{inv_mast_uid}/faq", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_faq(self, inv_mast_uid: int, inv_mast_faq_uid: int) -> BaseResponse[Any]:
        """DELETE /inv-mast/{invMastUid}/faq/{invMastFaqUid}."""
        response = self._delete(f"/{inv_mast_uid}/faq/{inv_mast_faq_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_faq(
        self,
        inv_mast_uid: int,
        inv_mast_faq_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/faq/{invMastFaqUid}."""
        response = self._get(f"/{inv_mast_uid}/faq/{inv_mast_faq_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_faq(
        self,
        inv_mast_uid: int,
        inv_mast_faq_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /inv-mast/{invMastUid}/faq/{invMastFaqUid}."""
        response = self._put(f"/{inv_mast_uid}/faq/{inv_mast_faq_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_inv_accessory(
        self,
        inv_mast_uid: int,
        params: InvMastInvAccessoryListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/inv-accessory."""
        response = self._get(f"/{inv_mast_uid}/inv-accessory", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_inv_sub(
        self,
        inv_mast_uid: int,
        params: InvMastInvSubListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/inv-sub."""
        response = self._get(f"/{inv_mast_uid}/inv-sub", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_locations_bins(
        self,
        inv_mast_uid: int,
        location_id: int,
        params: InvMastLocationsBinsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/locations/{locationId}/bins."""
        response = self._get(f"/{inv_mast_uid}/locations/{location_id}/bins", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_locations_bins(
        self,
        inv_mast_uid: int,
        location_id: int,
        bin: str,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/locations/{locationId}/bins/{bin}."""
        response = self._get(f"/{inv_mast_uid}/locations/{location_id}/bins/{bin}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_similar(
        self,
        inv_mast_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/similar."""
        response = self._get(f"/{inv_mast_uid}/similar", params=options)
        return BaseResponse[Any].model_validate(response)

    def get_stock(
        self,
        inv_mast_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast/{invMastUid}/stock."""
        response = self._get(f"/{inv_mast_uid}/stock", params=options)
        return BaseResponse[Any].model_validate(response)


class InvMastLinksResource(BaseResource):
    """Resource for /inv-mast-links endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast-links")

    def get(self, inv_mast_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /inv-mast-links/{invMastUid}."""
        response = self._get(f"/{inv_mast_uid}", params=options)
        return BaseResponse[Any].model_validate(response)


class InvMastSubPartsResource(BaseResource):
    """Resource for /inv-mast-sub-parts endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast-sub-parts")

    def get(
        self,
        inv_mast_uid: int,
        params: InvMastSubPartsGetParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /inv-mast-sub-parts/{invMastUid}."""
        response = self._get(f"/{inv_mast_uid}", params=params)
        return BaseResponse[Any].model_validate(response)


class InvMastUdResource(BaseResource):
    """Resource for /inv-mast-ud endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/inv-mast-ud")

    def list(self, params: InvMastUdListParams | None = None) -> BaseResponse[Any]:
        """GET /inv-mast-ud."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class ItemCategoryResource(BaseResource):
    """Resource for /item-category endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-category")

    def list(self, params: ItemCategoryListParams | None = None) -> BaseResponse[Any]:
        """GET /item-category."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get_lookup(self, params: ItemCategoryLookupGetParams | None = None) -> BaseResponse[Any]:
        """GET /item-category/lookup."""
        response = self._get("/lookup", params=params)
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        item_category_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /item-category/{itemCategoryUid}."""
        response = self._get(f"/{item_category_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_doc(
        self,
        item_category_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /item-category/{itemCategoryUid}/doc."""
        response = self._get(f"/{item_category_uid}/doc", params=options)
        return BaseResponse[Any].model_validate(response)

    def get_doc(
        self,
        item_category_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """Alias for list_doc — GET /item-category/{itemCategoryUid}/doc."""
        return self.list_doc(item_category_uid, options=options)


class ItemFavoritesResource(BaseResource):
    """Resource for /item-favorites endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-favorites")

    def list_items(
        self,
        users_id: int,
        params: ItemFavoritesItemsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /item-favorites/{usersId}/items."""
        response = self._get(f"/{users_id}/items", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_items(self, users_id: int, data: Any = None) -> BaseResponse[Any]:
        """POST /item-favorites/{usersId}/items."""
        response = self._post(f"/{users_id}/items", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_items(self, users_id: int, inv_mast_uid: int) -> BaseResponse[Any]:
        """DELETE /item-favorites/{usersId}/items/{invMastUid}."""
        response = self._delete(f"/{users_id}/items/{inv_mast_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_items(
        self,
        users_id: int,
        inv_mast_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /item-favorites/{usersId}/items/{invMastUid}."""
        response = self._get(f"/{users_id}/items/{inv_mast_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_items(self, users_id: int, inv_mast_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /item-favorites/{usersId}/items/{invMastUid}."""
        response = self._put(f"/{users_id}/items/{inv_mast_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class ItemUomResource(BaseResource):
    """Resource for /item-uom endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-uom")

    def list(self, params: ItemUomListParams | None = None) -> BaseResponse[Any]:
        """GET /item-uom."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, item_uom_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /item-uom/{itemUomUid}."""
        response = self._get(f"/{item_uom_uid}", params=options)
        return BaseResponse[Any].model_validate(response)


class ItemWishlistResource(BaseResource):
    """Resource for /item-wishlist endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/item-wishlist")

    def get(self, users_id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /item-wishlist/{usersId}."""
        response = self._get(f"/{users_id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def create(self, users_id: int, data: Any = None) -> BaseResponse[Any]:
        """POST /item-wishlist/{usersId}."""
        response = self._post(f"/{users_id}", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_hdr(self, users_id: int, item_wishlist_hdr_uid: int) -> BaseResponse[Any]:
        """DELETE /item-wishlist/{usersId}/hdr/{itemWishlistHdrUid}."""
        response = self._delete(f"/{users_id}/hdr/{item_wishlist_hdr_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_hdr(
        self,
        users_id: int,
        item_wishlist_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /item-wishlist/{usersId}/hdr/{itemWishlistHdrUid}."""
        response = self._get(f"/{users_id}/hdr/{item_wishlist_hdr_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def create_hdr(
        self,
        users_id: int,
        item_wishlist_hdr_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """POST /item-wishlist/{usersId}/hdr/{itemWishlistHdrUid}."""
        response = self._post(f"/{users_id}/hdr/{item_wishlist_hdr_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def update_hdr(
        self,
        users_id: int,
        item_wishlist_hdr_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /item-wishlist/{usersId}/hdr/{itemWishlistHdrUid}."""
        response = self._put(f"/{users_id}/hdr/{item_wishlist_hdr_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_hdr_line(
        self,
        users_id: int,
        item_wishlist_hdr_uid: int,
        item_wishlist_line_uid: int,
    ) -> BaseResponse[Any]:
        """DELETE /item-wishlist/{usersId}/hdr/{itemWishlistHdrUid}/line/{itemWishlistLineUid}."""
        response = self._delete(
            f"/{users_id}/hdr/{item_wishlist_hdr_uid}/line/{item_wishlist_line_uid}",
        )
        return BaseResponse[Any].model_validate(response)


class LocationsResource(BaseResource):
    """Resource for /locations endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/locations")

    def list_bins(
        self,
        location_id: int,
        params: LocationsBinsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /locations/{locationId}/bins."""
        response = self._get(f"/{location_id}/bins", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_bins(
        self,
        location_id: int,
        bin: str,
        params: LocationsBinsGetParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /locations/{locationId}/bins/{bin}."""
        response = self._get(f"/{location_id}/bins/{bin}", params=params)
        return BaseResponse[Any].model_validate(response)


class P21Resource(BaseResource):
    """Resource for /p21 endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/p21")

    def list_inv_mast(self, params: P21InvMastListParams | None = None) -> BaseResponse[Any]:
        """GET /p21/inv-mast."""
        response = self._get("/inv-mast", params=params)
        return BaseResponse[Any].model_validate(response)


class VariantsResource(BaseResource):
    """Resource for /variants endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/variants")

    def list(self, params: VariantsListParams | None = None) -> BaseResponse[Any]:
        """GET /variants."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /variants."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, item_variant_hdr_uid: int) -> BaseResponse[Any]:
        """DELETE /variants/{itemVariantHdrUid}."""
        response = self._delete(f"/{item_variant_hdr_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        item_variant_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /variants/{itemVariantHdrUid}."""
        response = self._get(f"/{item_variant_hdr_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, item_variant_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /variants/{itemVariantHdrUid}."""
        response = self._put(f"/{item_variant_hdr_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_attributes(
        self,
        item_variant_hdr_uid: int,
        params: VariantsAttributesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /variants/{itemVariantHdrUid}/attributes."""
        response = self._get(f"/{item_variant_hdr_uid}/attributes", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_attributes(self, item_variant_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /variants/{itemVariantHdrUid}/attributes."""
        response = self._post(f"/{item_variant_hdr_uid}/attributes", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_attributes(self, item_variant_hdr_uid: int, attribute_uid: int) -> BaseResponse[Any]:
        """DELETE /variants/{itemVariantHdrUid}/attributes/{attributeUid}."""
        response = self._delete(f"/{item_variant_hdr_uid}/attributes/{attribute_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_attributes(
        self,
        item_variant_hdr_uid: int,
        attribute_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /variants/{itemVariantHdrUid}/attributes/{attributeUid}."""
        response = self._get(f"/{item_variant_hdr_uid}/attributes/{attribute_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_attributes(
        self,
        item_variant_hdr_uid: int,
        attribute_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /variants/{itemVariantHdrUid}/attributes/{attributeUid}."""
        response = self._put(f"/{item_variant_hdr_uid}/attributes/{attribute_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_doc(
        self,
        item_variant_hdr_uid: int,
        params: VariantsDocListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /variants/{itemVariantHdrUid}/doc."""
        response = self._get(f"/{item_variant_hdr_uid}/doc", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_doc(
        self,
        item_variant_hdr_uid: int,
        params: VariantsDocListParams | None = None,
    ) -> BaseResponse[Any]:
        """Alias for list_doc — GET /variants/{itemVariantHdrUid}/doc."""
        return self.list_doc(item_variant_hdr_uid, params=params)

    def list_lines(
        self,
        item_variant_hdr_uid: int,
        params: VariantsLinesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /variants/{itemVariantHdrUid}/lines."""
        response = self._get(f"/{item_variant_hdr_uid}/lines", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_lines(self, item_variant_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /variants/{itemVariantHdrUid}/lines."""
        response = self._post(f"/{item_variant_hdr_uid}/lines", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_lines(
        self,
        item_variant_hdr_uid: int,
        item_variant_line_uid: int,
    ) -> BaseResponse[Any]:
        """DELETE /variants/{itemVariantHdrUid}/lines/{itemVariantLineUid}."""
        response = self._delete(f"/{item_variant_hdr_uid}/lines/{item_variant_line_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_lines(
        self,
        item_variant_hdr_uid: int,
        item_variant_line_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /variants/{itemVariantHdrUid}/lines/{itemVariantLineUid}."""
        response = self._get(
            f"/{item_variant_hdr_uid}/lines/{item_variant_line_uid}",
            params=options,
        )
        return BaseResponse[Any].model_validate(response)

    def update_lines(
        self,
        item_variant_hdr_uid: int,
        item_variant_line_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /variants/{itemVariantHdrUid}/lines/{itemVariantLineUid}."""
        response = self._put(f"/{item_variant_hdr_uid}/lines/{item_variant_line_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_similar(
        self,
        item_variant_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /variants/{itemVariantHdrUid}/similar."""
        response = self._get(f"/{item_variant_hdr_uid}/similar", params=options)
        return BaseResponse[Any].model_validate(response)


class ItemsClient(BaseServiceClient):
    """Client for the items service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._attribute_groups: AttributeGroupsResource | None = None
        self._attributes: AttributesResource | None = None
        self._brands: BrandsResource | None = None
        self._categories: CategoriesResource | None = None
        self._contracts: ContractsResource | None = None
        self._internal: InternalResource | None = None
        self._inv_loc: InvLocResource | None = None
        self._inv_mast: InvMastResource | None = None
        self._inv_mast_links: InvMastLinksResource | None = None
        self._inv_mast_sub_parts: InvMastSubPartsResource | None = None
        self._inv_mast_ud: InvMastUdResource | None = None
        self._item_category: ItemCategoryResource | None = None
        self._item_favorites: ItemFavoritesResource | None = None
        self._item_uom: ItemUomResource | None = None
        self._item_wishlist: ItemWishlistResource | None = None
        self._locations: LocationsResource | None = None
        self._p21: P21Resource | None = None
        self._variants: VariantsResource | None = None

    @property
    def attribute_groups(self) -> AttributeGroupsResource:
        """Access attributeGroups endpoints."""
        if self._attribute_groups is None:
            self._attribute_groups = AttributeGroupsResource(self._http)
        return self._attribute_groups

    @property
    def attributes(self) -> AttributesResource:
        """Access attributes endpoints."""
        if self._attributes is None:
            self._attributes = AttributesResource(self._http)
        return self._attributes

    @property
    def brands(self) -> BrandsResource:
        """Access brands endpoints."""
        if self._brands is None:
            self._brands = BrandsResource(self._http)
        return self._brands

    @property
    def categories(self) -> CategoriesResource:
        """Access categories endpoints."""
        if self._categories is None:
            self._categories = CategoriesResource(self._http)
        return self._categories

    @property
    def contracts(self) -> ContractsResource:
        """Access contracts endpoints."""
        if self._contracts is None:
            self._contracts = ContractsResource(self._http)
        return self._contracts

    @property
    def internal(self) -> InternalResource:
        """Access internal endpoints."""
        if self._internal is None:
            self._internal = InternalResource(self._http)
        return self._internal

    @property
    def inv_loc(self) -> InvLocResource:
        """Access invLoc endpoints."""
        if self._inv_loc is None:
            self._inv_loc = InvLocResource(self._http)
        return self._inv_loc

    @property
    def inv_mast(self) -> InvMastResource:
        """Access invMast endpoints."""
        if self._inv_mast is None:
            self._inv_mast = InvMastResource(self._http)
        return self._inv_mast

    @property
    def inv_mast_links(self) -> InvMastLinksResource:
        """Access invMastLinks endpoints."""
        if self._inv_mast_links is None:
            self._inv_mast_links = InvMastLinksResource(self._http)
        return self._inv_mast_links

    @property
    def inv_mast_sub_parts(self) -> InvMastSubPartsResource:
        """Access invMastSubParts endpoints."""
        if self._inv_mast_sub_parts is None:
            self._inv_mast_sub_parts = InvMastSubPartsResource(self._http)
        return self._inv_mast_sub_parts

    @property
    def inv_mast_ud(self) -> InvMastUdResource:
        """Access invMastUd endpoints."""
        if self._inv_mast_ud is None:
            self._inv_mast_ud = InvMastUdResource(self._http)
        return self._inv_mast_ud

    @property
    def item_category(self) -> ItemCategoryResource:
        """Access itemCategory endpoints."""
        if self._item_category is None:
            self._item_category = ItemCategoryResource(self._http)
        return self._item_category

    @property
    def item_favorites(self) -> ItemFavoritesResource:
        """Access itemFavorites endpoints."""
        if self._item_favorites is None:
            self._item_favorites = ItemFavoritesResource(self._http)
        return self._item_favorites

    @property
    def item_uom(self) -> ItemUomResource:
        """Access itemUom endpoints."""
        if self._item_uom is None:
            self._item_uom = ItemUomResource(self._http)
        return self._item_uom

    @property
    def item_wishlist(self) -> ItemWishlistResource:
        """Access itemWishlist endpoints."""
        if self._item_wishlist is None:
            self._item_wishlist = ItemWishlistResource(self._http)
        return self._item_wishlist

    @property
    def locations(self) -> LocationsResource:
        """Access locations endpoints."""
        if self._locations is None:
            self._locations = LocationsResource(self._http)
        return self._locations

    @property
    def p21(self) -> P21Resource:
        """Access p21 endpoints."""
        if self._p21 is None:
            self._p21 = P21Resource(self._http)
        return self._p21

    @property
    def variants(self) -> VariantsResource:
        """Access variants endpoints."""
        if self._variants is None:
            self._variants = VariantsResource(self._http)
        return self._variants
