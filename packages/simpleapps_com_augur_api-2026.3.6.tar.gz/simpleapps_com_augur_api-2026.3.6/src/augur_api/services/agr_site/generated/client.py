"""
Generated client for agr-site service.
Source: shared/specs/agr-site.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.agr_site.generated.schemas import (
        FyxerTranscriptListParams,
        GeoCodesPostalCodesListParams,
        OpenSearchEmbeddingListParams,
        SettingsListParams,
        TrainingConversationsListParams,
        TrainingConversationsMessagesListParams,
        TrainingListParams,
    )


class ContextResource(BaseResource):
    """Resource for /context endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/context")

    def get(self, site_id: str, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /context/{siteId}."""
        response = self._get(f"/{site_id}", params=options)
        return BaseResponse[Any].model_validate(response)


class FyxerTranscriptResource(BaseResource):
    """Resource for /fyxer-transcript endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/fyxer-transcript")

    def list(self, params: FyxerTranscriptListParams | None = None) -> BaseResponse[Any]:
        """GET /fyxer-transcript."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /fyxer-transcript."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, fyxer_transcript_hdr_uid: int) -> BaseResponse[Any]:
        """DELETE /fyxer-transcript/{fyxerTranscriptHdrUid}."""
        response = self._delete(f"/{fyxer_transcript_hdr_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        fyxer_transcript_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /fyxer-transcript/{fyxerTranscriptHdrUid}."""
        response = self._get(f"/{fyxer_transcript_hdr_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, fyxer_transcript_hdr_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /fyxer-transcript/{fyxerTranscriptHdrUid}."""
        response = self._put(f"/{fyxer_transcript_hdr_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class GeoCodesPostalCodesResource(BaseResource):
    """Resource for /geo-codes-postal-codes endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/geo-codes-postal-codes")

    def list(self, params: GeoCodesPostalCodesListParams | None = None) -> BaseResponse[Any]:
        """GET /geo-codes-postal-codes."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        geo_codes_postal_codes_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /geo-codes-postal-codes/{geoCodesPostalCodesUid}."""
        response = self._get(f"/{geo_codes_postal_codes_uid}", params=options)
        return BaseResponse[Any].model_validate(response)


class MetaFilesResource(BaseResource):
    """Resource for /meta-files endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/meta-files")

    def list_robots(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /meta-files/robots."""
        response = self._get("/robots", params=options)
        return BaseResponse[Any].model_validate(response)


class NotificationsResource(BaseResource):
    """Resource for /notifications endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/notifications")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /notifications."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)


class OpenSearchResource(BaseResource):
    """Resource for /open-search endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/open-search")

    def list_embedding(
        self,
        params: OpenSearchEmbeddingListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /open-search/embedding."""
        response = self._get("/embedding", params=params)
        return BaseResponse[Any].model_validate(response)


class SettingsResource(BaseResource):
    """Resource for /settings endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/settings")

    def list(self, params: SettingsListParams | None = None) -> BaseResponse[Any]:
        """GET /settings."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /settings."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, settings_uid: int) -> BaseResponse[Any]:
        """DELETE /settings/{settingsUid}."""
        response = self._delete(f"/{settings_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, settings_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /settings/{settingsUid}."""
        response = self._get(f"/{settings_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, settings_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /settings/{settingsUid}."""
        response = self._put(f"/{settings_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class TrainingResource(BaseResource):
    """Resource for /training endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/training")

    def list(self, params: TrainingListParams | None = None) -> BaseResponse[Any]:
        """GET /training."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /training."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, training_set_uid: int) -> BaseResponse[Any]:
        """DELETE /training/{trainingSetUid}."""
        response = self._delete(f"/{training_set_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        training_set_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /training/{trainingSetUid}."""
        response = self._get(f"/{training_set_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, training_set_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /training/{trainingSetUid}."""
        response = self._put(f"/{training_set_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_conversations(
        self,
        training_set_uid: int,
        params: TrainingConversationsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /training/{trainingSetUid}/conversations."""
        response = self._get(f"/{training_set_uid}/conversations", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_conversations(self, training_set_uid: int, data: Any = None) -> BaseResponse[Any]:
        """POST /training/{trainingSetUid}/conversations."""
        response = self._post(f"/{training_set_uid}/conversations", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_conversations(
        self,
        training_set_uid: int,
        training_conv_uid: int,
    ) -> BaseResponse[Any]:
        """DELETE /training/{trainingSetUid}/conversations/{trainingConvUid}."""
        response = self._delete(f"/{training_set_uid}/conversations/{training_conv_uid}")
        return BaseResponse[Any].model_validate(response)

    def get_conversations(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /training/{trainingSetUid}/conversations/{trainingConvUid}."""
        response = self._get(
            f"/{training_set_uid}/conversations/{training_conv_uid}",
            params=options,
        )
        return BaseResponse[Any].model_validate(response)

    def update_conversations(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT /training/{trainingSetUid}/conversations/{trainingConvUid}."""
        response = self._put(f"/{training_set_uid}/conversations/{training_conv_uid}", data=data)
        return BaseResponse[Any].model_validate(response)

    def list_conversations_messages(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        params: TrainingConversationsMessagesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /training/{trainingSetUid}/conversations/{trainingConvUid}/messages."""
        response = self._get(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages",
            params=params,
        )
        return BaseResponse[Any].model_validate(response)

    def create_conversations_messages(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """POST /training/{trainingSetUid}/conversations/{trainingConvUid}/messages."""
        response = self._post(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages",
            data=data,
        )
        return BaseResponse[Any].model_validate(response)

    def delete_conversations_messages(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        training_msg_uid: int,
    ) -> BaseResponse[Any]:
        """DELETE endpoint."""
        response = self._delete(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages/{training_msg_uid}",
        )
        return BaseResponse[Any].model_validate(response)

    def get_conversations_messages(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        training_msg_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET endpoint."""
        response = self._get(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages/{training_msg_uid}",
            params=options,
        )
        return BaseResponse[Any].model_validate(response)

    def update_conversations_messages(
        self,
        training_set_uid: int,
        training_conv_uid: int,
        training_msg_uid: int,
        data: Any = None,
    ) -> BaseResponse[Any]:
        """PUT endpoint."""
        response = self._put(
            f"/{training_set_uid}/conversations/{training_conv_uid}/messages/{training_msg_uid}",
            data=data,
        )
        return BaseResponse[Any].model_validate(response)


class AgrSiteClient(BaseServiceClient):
    """Client for the agr-site service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._context: ContextResource | None = None
        self._fyxer_transcript: FyxerTranscriptResource | None = None
        self._geo_codes_postal_codes: GeoCodesPostalCodesResource | None = None
        self._meta_files: MetaFilesResource | None = None
        self._notifications: NotificationsResource | None = None
        self._open_search: OpenSearchResource | None = None
        self._settings: SettingsResource | None = None
        self._training: TrainingResource | None = None

    @property
    def context(self) -> ContextResource:
        """Access context endpoints."""
        if self._context is None:
            self._context = ContextResource(self._http)
        return self._context

    @property
    def fyxer_transcript(self) -> FyxerTranscriptResource:
        """Access fyxerTranscript endpoints."""
        if self._fyxer_transcript is None:
            self._fyxer_transcript = FyxerTranscriptResource(self._http)
        return self._fyxer_transcript

    @property
    def geo_codes_postal_codes(self) -> GeoCodesPostalCodesResource:
        """Access geoCodesPostalCodes endpoints."""
        if self._geo_codes_postal_codes is None:
            self._geo_codes_postal_codes = GeoCodesPostalCodesResource(self._http)
        return self._geo_codes_postal_codes

    @property
    def meta_files(self) -> MetaFilesResource:
        """Access metaFiles endpoints."""
        if self._meta_files is None:
            self._meta_files = MetaFilesResource(self._http)
        return self._meta_files

    @property
    def notifications(self) -> NotificationsResource:
        """Access notifications endpoints."""
        if self._notifications is None:
            self._notifications = NotificationsResource(self._http)
        return self._notifications

    @property
    def open_search(self) -> OpenSearchResource:
        """Access openSearch endpoints."""
        if self._open_search is None:
            self._open_search = OpenSearchResource(self._http)
        return self._open_search

    @property
    def settings(self) -> SettingsResource:
        """Access settings endpoints."""
        if self._settings is None:
            self._settings = SettingsResource(self._http)
        return self._settings

    @property
    def training(self) -> TrainingResource:
        """Access training endpoints."""
        if self._training is None:
            self._training = TrainingResource(self._http)
        return self._training
