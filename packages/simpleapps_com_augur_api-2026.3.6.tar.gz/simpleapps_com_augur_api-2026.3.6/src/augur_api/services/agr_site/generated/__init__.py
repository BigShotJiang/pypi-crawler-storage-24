"""Generated code for agr-site service."""
