"""
Generated Pydantic schemas for joomla service.
Source: shared/specs/joomla.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams


class CategoriesListParams(EdgeCacheParams):
    """Params for GET /categories."""

    extension: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    parent_id: int | None = None
    published: int | None = None


CategoriesGetParams = EdgeCacheParams


class ContentListParams(EdgeCacheParams):
    """Params for GET /content."""

    category_id_list: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    tags_list: str | None = None


class ContentGetParams(EdgeCacheParams):
    """Params for GET /content/{id}."""

    alias: str | None = None
    catid: int | None = None


class ContentDocListParams(EdgeCacheParams):
    """Params for GET /content/{id}/doc."""

    alias: str | None = None
    catid: int | None = None


class MenuListParams(EdgeCacheParams):
    """Params for GET /menu."""

    limit: int | None = None
    menutype: str | None = None
    offset: int | None = None
    order_by: str | None = None
    parent_id: int | None = None
    published: int | None = None


class MenuDocListParams(EdgeCacheParams):
    """Params for GET /menu/{id}/doc."""

    alias: str | None = None


class TagsListParams(EdgeCacheParams):
    """Params for GET /tags."""

    cat_id: int | None = None
    limit: int | None = None
    offset: int | None = None
    parent_id: int | None = None
    q: str | None = None


class UsergroupsListParams(EdgeCacheParams):
    """Params for GET /usergroups."""

    order_by: str | None = None
    parent_id_list: str | None = None


UsersListParams = EdgeCacheParams


class UsersCreateParams(EdgeCacheParams):
    """Params for POST /users."""

    access_level_list: str | None = None
    customer_id: int | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


UsersGetParams = EdgeCacheParams


class UsersDocListParams(EdgeCacheParams):
    """Params for GET /users/{id}/doc."""

    include_ship_to: str | None = None


class UsersGroupsListParams(EdgeCacheParams):
    """Params for GET /users/{id}/groups."""

    limit: int | None = None
    offset: int | None = None


UsersGroupsGetParams = EdgeCacheParams


class UsersTrinityListParams(EdgeCacheParams):
    """Params for GET /users/{id}/trinity."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class UsersVerifyPasswordData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    id: int | None = None
    is_verified: bool | None = None
    username: str | None = None
    token: str | None = None
    email: str | None = None
