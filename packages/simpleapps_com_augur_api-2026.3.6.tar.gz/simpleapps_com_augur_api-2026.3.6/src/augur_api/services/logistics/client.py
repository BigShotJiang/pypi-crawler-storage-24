"""
Generated client for logistics service.
Source: shared/specs/logistics.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.logistics.generated.schemas import (
        ShipviaRatesListParams,
        ShipviaRatesLtlListParams,
        SpeedshipFreightListParams,
        UpsRatesListParams,
    )


class ShipviaResource(BaseResource):
    """Resource for /shipvia endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/shipvia")

    def list_rates(self, params: ShipviaRatesListParams | None = None) -> BaseResponse[Any]:
        """GET /shipvia/rates."""
        response = self._get("/rates", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_rates_ltl(self, params: ShipviaRatesLtlListParams | None = None) -> BaseResponse[Any]:
        """GET /shipvia/rates/ltl."""
        response = self._get("/rates/ltl", params=params)
        return BaseResponse[Any].model_validate(response)


class SpeedshipResource(BaseResource):
    """Resource for /speedship endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/speedship")

    def list_freight(self, params: SpeedshipFreightListParams | None = None) -> BaseResponse[Any]:
        """GET /speedship/freight."""
        response = self._get("/freight", params=params)
        return BaseResponse[Any].model_validate(response)


class UpsResource(BaseResource):
    """Resource for /ups endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/ups")

    def list_rates(self, params: UpsRatesListParams | None = None) -> BaseResponse[Any]:
        """GET /ups/rates."""
        response = self._get("/rates", params=params)
        return BaseResponse[Any].model_validate(response)


class LogisticsClient(BaseServiceClient):
    """Client for the logistics service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._shipvia: ShipviaResource | None = None
        self._speedship: SpeedshipResource | None = None
        self._ups: UpsResource | None = None

    @property
    def shipvia(self) -> ShipviaResource:
        """Access shipvia endpoints."""
        if self._shipvia is None:
            self._shipvia = ShipviaResource(self._http)
        return self._shipvia

    @property
    def speedship(self) -> SpeedshipResource:
        """Access speedship endpoints."""
        if self._speedship is None:
            self._speedship = SpeedshipResource(self._http)
        return self._speedship

    @property
    def ups(self) -> UpsResource:
        """Access ups endpoints."""
        if self._ups is None:
            self._ups = UpsResource(self._http)
        return self._ups
