"""Logistics service exports."""

from augur_api.services.logistics.client import (
    LogisticsClient,
    ShipviaResource,
    SpeedshipResource,
    UpsResource,
)

__all__ = [
    "LogisticsClient",
    "ShipviaResource",
    "SpeedshipResource",
    "UpsResource",
]
