"""Generated code for pricing service."""
