"""
Generated client for pricing service.
Source: shared/specs/pricing.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.pricing.generated.schemas import (
        JobPriceHdrLinesListParams,
        JobPriceHdrListParams,
        PriceEngineListParams,
    )


class JobPriceHdrResource(BaseResource):
    """Resource for /job-price-hdr endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/job-price-hdr")

    def list(self, params: JobPriceHdrListParams | None = None) -> BaseResponse[Any]:
        """GET /job-price-hdr."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        job_price_hdr_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /job-price-hdr/{jobPriceHdrUid}."""
        response = self._get(f"/{job_price_hdr_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_lines(
        self,
        job_price_hdr_uid: int,
        params: JobPriceHdrLinesListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /job-price-hdr/{jobPriceHdrUid}/lines."""
        response = self._get(f"/{job_price_hdr_uid}/lines", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_lines(
        self,
        job_price_hdr_uid: int,
        job_price_line_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /job-price-hdr/{jobPriceHdrUid}/lines/{jobPriceLineUid}."""
        response = self._get(f"/{job_price_hdr_uid}/lines/{job_price_line_uid}", params=options)
        return BaseResponse[Any].model_validate(response)


class PriceEngineResource(BaseResource):
    """Resource for /price-engine endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/price-engine")

    def list(self, params: PriceEngineListParams | None = None) -> BaseResponse[Any]:
        """GET /price-engine."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class TaxEngineResource(BaseResource):
    """Resource for /tax-engine endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/tax-engine")

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /tax-engine."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)


class PricingClient(BaseServiceClient):
    """Client for the pricing service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._job_price_hdr: JobPriceHdrResource | None = None
        self._price_engine: PriceEngineResource | None = None
        self._tax_engine: TaxEngineResource | None = None

    @property
    def job_price_hdr(self) -> JobPriceHdrResource:
        """Access jobPriceHdr endpoints."""
        if self._job_price_hdr is None:
            self._job_price_hdr = JobPriceHdrResource(self._http)
        return self._job_price_hdr

    @property
    def price_engine(self) -> PriceEngineResource:
        """Access priceEngine endpoints."""
        if self._price_engine is None:
            self._price_engine = PriceEngineResource(self._http)
        return self._price_engine

    @property
    def tax_engine(self) -> TaxEngineResource:
        """Access taxEngine endpoints."""
        if self._tax_engine is None:
            self._tax_engine = TaxEngineResource(self._http)
        return self._tax_engine
