"""
Generated Pydantic schemas for payments service.
Source: shared/specs/payments.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import EdgeCacheParams


class MonerisPreAuthListParams(EdgeCacheParams):
    """Params for GET /moneris/pre-auth."""

    amount: float
    cc_number: str
    exp_date: str
    order_id: str
    test_mode: bool | None = None


class MonerisPreAuthCompleteListParams(EdgeCacheParams):
    """Params for GET /moneris/pre-auth-complete."""

    amount: float
    order_id: str
    test_mode: bool | None = None
    txn_number: str


class PaytraceAuthorizationCreateParams(EdgeCacheParams):
    """Params for POST /paytrace/authorization."""

    amount: float
    billing_address: str | None = None
    credit_card: str
    csc: str | None = None
    invoice_id: str | None = None
    test_mode: bool | None = None


class PaytraceCaptureCreateParams(EdgeCacheParams):
    """Params for POST /paytrace/capture."""

    amount: float | None = None
    test_mode: bool | None = None
    transaction_id: str


class PaytraceRefundCreateParams(EdgeCacheParams):
    """Params for POST /paytrace/refund."""

    amount: float | None = None
    test_mode: bool | None = None
    transaction_id: str


class PaytraceSaleCreateParams(EdgeCacheParams):
    """Params for POST /paytrace/sale."""

    amount: float
    billing_address: str | None = None
    credit_card: str
    csc: str | None = None
    invoice_id: str | None = None
    test_mode: bool | None = None


class PaytraceVoidCreateParams(EdgeCacheParams):
    """Params for POST /paytrace/void."""

    test_mode: bool | None = None
    transaction_id: str


class UnifiedAccountQueryListParams(EdgeCacheParams):
    """Params for GET /unified/account-query."""

    customer_id: str
    mode: str | None = None
    transaction_setup_id: str


class UnifiedBillingUpdateListParams(EdgeCacheParams):
    """Params for GET /unified/billing-update."""

    address1: str
    address2: str | None = None
    city: str
    mode: str | None = None
    state: str
    transaction_setup_id: str
    zip: str


class UnifiedCardInfoListParams(EdgeCacheParams):
    """Params for GET /unified/card-info."""

    mode: str | None = None
    transaction_setup_id: str


class UnifiedSurchargeListParams(EdgeCacheParams):
    """Params for GET /unified/surcharge."""

    amount: str
    country: str
    customer_id: str
    from_state: str
    mode: str | None = None
    payment_account_id: str
    to_state: str


class UnifiedTransactionSetupListParams(EdgeCacheParams):
    """Params for GET /unified/transaction-setup."""

    customer_id: str
    mode: str | None = None


class UnifiedValidateListParams(EdgeCacheParams):
    """Params for GET /unified/validate."""

    customer_id: str
    mode: str | None = None
    transaction_setup_id: str
