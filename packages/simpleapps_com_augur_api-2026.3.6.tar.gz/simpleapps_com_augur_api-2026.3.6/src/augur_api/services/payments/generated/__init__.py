"""Generated code for payments service."""
