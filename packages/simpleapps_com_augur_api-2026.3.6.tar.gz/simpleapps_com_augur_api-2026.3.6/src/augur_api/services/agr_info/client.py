"""
Generated client for agr-info service.
Source: shared/specs/agr-info.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.agr_info.generated.schemas import (
        MicroservicesListParams,
    )


class AkashaResource(BaseResource):
    """Resource for /akasha endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/akasha")

    def create_generate(self, data: Any = None) -> BaseResponse[Any]:
        """POST /akasha/generate."""
        response = self._post("/generate", data=data)
        return BaseResponse[Any].model_validate(response)


class ContextResource(BaseResource):
    """Resource for /context endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/context")

    def get(self, site_id: str, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /context/{siteId}."""
        response = self._get(f"/{site_id}", params=options)
        return BaseResponse[Any].model_validate(response)


class JoomlaResource(BaseResource):
    """Resource for /joomla endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/joomla")

    def create_generate(self, data: Any = None) -> BaseResponse[Any]:
        """POST /joomla/generate."""
        response = self._post("/generate", data=data)
        return BaseResponse[Any].model_validate(response)


class MicroservicesResource(BaseResource):
    """Resource for /microservices endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/microservices")

    def list(self, params: MicroservicesListParams | None = None) -> BaseResponse[Any]:
        """GET /microservices."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /microservices."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, microservices_uid: int) -> BaseResponse[Any]:
        """DELETE /microservices/{microservicesUid}."""
        response = self._delete(f"/{microservices_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(
        self,
        microservices_uid: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /microservices/{microservicesUid}."""
        response = self._get(f"/{microservices_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, microservices_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /microservices/{microservicesUid}."""
        response = self._put(f"/{microservices_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class OllamaResource(BaseResource):
    """Resource for /ollama endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/ollama")

    def list_tags(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /ollama/tags."""
        response = self._get("/tags", params=options)
        return BaseResponse[Any].model_validate(response)


class RubricsResource(BaseResource):
    """Resource for /rubrics endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/rubrics")

    def list(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /rubrics."""
        response = self._get(params=options)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /rubrics."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, rubrics_uid: int) -> BaseResponse[Any]:
        """DELETE /rubrics/{rubricsUid}."""
        response = self._delete(f"/{rubrics_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, rubrics_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /rubrics/{rubricsUid}."""
        response = self._get(f"/{rubrics_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, rubrics_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /rubrics/{rubricsUid}."""
        response = self._put(f"/{rubrics_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class WorkflowsResource(BaseResource):
    """Resource for /workflows endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/workflows")

    def list(self, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /workflows."""
        response = self._get(params=options)
        return BaseResponse[Any].model_validate(response)

    def create(self, data: Any = None) -> BaseResponse[Any]:
        """POST /workflows."""
        response = self._post(data=data)
        return BaseResponse[Any].model_validate(response)

    def delete(self, workflows_uid: int) -> BaseResponse[Any]:
        """DELETE /workflows/{workflowsUid}."""
        response = self._delete(f"/{workflows_uid}")
        return BaseResponse[Any].model_validate(response)

    def get(self, workflows_uid: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /workflows/{workflowsUid}."""
        response = self._get(f"/{workflows_uid}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update(self, workflows_uid: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /workflows/{workflowsUid}."""
        response = self._put(f"/{workflows_uid}", data=data)
        return BaseResponse[Any].model_validate(response)


class AgrInfoClient(BaseServiceClient):
    """Client for the agr-info service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._akasha: AkashaResource | None = None
        self._context: ContextResource | None = None
        self._joomla: JoomlaResource | None = None
        self._microservices: MicroservicesResource | None = None
        self._ollama: OllamaResource | None = None
        self._rubrics: RubricsResource | None = None
        self._workflows: WorkflowsResource | None = None

    @property
    def akasha(self) -> AkashaResource:
        """Access akasha endpoints."""
        if self._akasha is None:
            self._akasha = AkashaResource(self._http)
        return self._akasha

    @property
    def context(self) -> ContextResource:
        """Access context endpoints."""
        if self._context is None:
            self._context = ContextResource(self._http)
        return self._context

    @property
    def joomla(self) -> JoomlaResource:
        """Access joomla endpoints."""
        if self._joomla is None:
            self._joomla = JoomlaResource(self._http)
        return self._joomla

    @property
    def microservices(self) -> MicroservicesResource:
        """Access microservices endpoints."""
        if self._microservices is None:
            self._microservices = MicroservicesResource(self._http)
        return self._microservices

    @property
    def ollama(self) -> OllamaResource:
        """Access ollama endpoints."""
        if self._ollama is None:
            self._ollama = OllamaResource(self._http)
        return self._ollama

    @property
    def rubrics(self) -> RubricsResource:
        """Access rubrics endpoints."""
        if self._rubrics is None:
            self._rubrics = RubricsResource(self._http)
        return self._rubrics

    @property
    def workflows(self) -> WorkflowsResource:
        """Access workflows endpoints."""
        if self._workflows is None:
            self._workflows = WorkflowsResource(self._http)
        return self._workflows
