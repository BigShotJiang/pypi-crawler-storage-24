"""
Generated Pydantic schemas for orders service.
Source: shared/specs/orders.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from augur_api.core.schemas import CamelCaseModel, EdgeCacheParams

InvoiceHdrReprintListParams = EdgeCacheParams


OeHdrSalesrepOeHdrListParams = EdgeCacheParams


OeHdrSalesrepOeHdrDocListParams = EdgeCacheParams


class OeHdrLookupGetParams(EdgeCacheParams):
    """Params for GET /oe-hdr/lookup."""

    class1_id: str | None = None
    completed: str | None = None
    date_order_completed: str | None = None
    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None
    salesrep_id: str | None = None
    taker: str | None = None


class OeHdrDocListParams(EdgeCacheParams):
    """Params for GET /oe-hdr/{orderNo}/doc."""

    postal_code: str | None = None


class PickTicketsListParams(EdgeCacheParams):
    """Params for GET /pick-tickets."""

    company_id: str | None = None
    delete_flag: str | None = None
    limit: int | None = None
    location_id: float | None = None
    offset: int | None = None
    order_by: str | None = None
    order_no: str | None = None
    printed_flag: str | None = None
    q: str | None = None


PickTicketsGetParams = EdgeCacheParams


class PickTicketsLinesListParams(EdgeCacheParams):
    """Params for GET /pick-tickets/{pickTicketNo}/lines."""

    limit: int | None = None
    offset: int | None = None
    order_by: str | None = None
    q: str | None = None


PickTicketsLinesGetParams = EdgeCacheParams


class PoHdrListParams(EdgeCacheParams):
    """Params for GET /po-hdr."""

    complete: str | None = None
    limit: int | None = None
    location_id: int | None = None
    offset: int | None = None
    q: str | None = None


PoHdrGetParams = EdgeCacheParams


PoHdrDocListParams = EdgeCacheParams


# =============================================================================
# Response Data Models (MINIMUM fields — extra='allow' passes through more)
# =============================================================================


class PickTicketsData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    pick_ticket_no: float | None = None
    order_no: str | None = None
    company_id: str | None = None
    carrier_id: float | None = None
    tracking_no: str | None = None
    instructions: str | None = None
    ship_date: str | None = None
    invoice_no: float | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    location_id: float | None = None
    delete_flag: str | None = None
    update_cd: int | None = None
    printed_flag: str | None = None
    confirmable_row_status_flag: int | None = None
    direct_shipment: str | None = None
    auxiliary: str | None = None
    print_date: str | None = None
    oe_pick_ticket_type_cd: int | None = None


class PickTicketsLinesData(CamelCaseModel):
    """Response data — MINIMUM fields, extra pass through."""

    pick_ticket_no: float | None = None
    line_number: float | None = None
    company_id: str | None = None
    print_quantity: float | None = None
    ship_quantity: float | None = None
    date_created: str | None = None
    date_last_modified: str | None = None
    unit_of_measure: str | None = None
    unit_size: float | None = None
    unit_quantity: float | None = None
    oe_line_no: float | None = None
    qty_requested: float | None = None
    qty_to_pick: float | None = None
    inv_mast_uid: int | None = None
    invoice_line_uid: int | None = None
    qty_scanned: float | None = None
    box_number: str | None = None
    original_qty_to_pick: float | None = None
    update_cd: int | None = None
