"""
Generated client for brand-folder service.
Source: shared/specs/brand-folder.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient


class CategoriesResource(BaseResource):
    """Resource for /categories endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/categories")

    def create_focus(self, data: Any = None) -> BaseResponse[Any]:
        """POST /categories/focus."""
        response = self._post("/focus", data=data)
        return BaseResponse[Any].model_validate(response)


class BrandFolderClient(BaseServiceClient):
    """Client for the brand-folder service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._categories: CategoriesResource | None = None

    @property
    def categories(self) -> CategoriesResource:
        """Access categories endpoints."""
        if self._categories is None:
            self._categories = CategoriesResource(self._http)
        return self._categories
