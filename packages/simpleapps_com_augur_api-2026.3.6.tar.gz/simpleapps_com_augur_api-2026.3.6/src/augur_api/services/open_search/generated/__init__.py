"""Generated code for open-search service."""
