"""Generated code for p21-core service."""
