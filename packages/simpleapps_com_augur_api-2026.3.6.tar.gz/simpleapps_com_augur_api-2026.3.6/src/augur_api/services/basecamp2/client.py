"""
Generated client for basecamp2 service.
Source: shared/specs/basecamp2.json

DO NOT EDIT — regenerate with: python shared/scripts/generate-py.py
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from augur_api.core.schemas import BaseResponse, EdgeCacheParams
from augur_api.services.base import BaseServiceClient
from augur_api.services.resource import BaseResource

if TYPE_CHECKING:
    from augur_api.core.http_client import HTTPClient
    from augur_api.services.basecamp2.generated.schemas import (
        CommentsListParams,
        EventsListParams,
        MetricsListParams,
        PeopleListParams,
        PeopleMetricsListParams,
        PeopleProjectsTodosListParams,
        PeopleTodosListParams,
        ProjectsListParams,
        ProjectsMetricsListParams,
        ProjectsTodolistsListParams,
        ProjectsTodolistsTodosListParams,
        ProjectsTodosListParams,
        TodolistsListParams,
        TodosCommentsListParams,
        TodosEventsListParams,
        TodosListParams,
        TodosSessionsListParams,
        TodosSummaryListParams,
    )


class CommentsResource(BaseResource):
    """Resource for /comments endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/comments")

    def list(self, params: CommentsListParams | None = None) -> BaseResponse[Any]:
        """GET /comments."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /comments/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)


class EventsResource(BaseResource):
    """Resource for /events endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/events")

    def list(self, params: EventsListParams | None = None) -> BaseResponse[Any]:
        """GET /events."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class MetricsResource(BaseResource):
    """Resource for /metrics endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/metrics")

    def list(self, params: MetricsListParams | None = None) -> BaseResponse[Any]:
        """GET /metrics."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)


class PeopleResource(BaseResource):
    """Resource for /people endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/people")

    def list(self, params: PeopleListParams | None = None) -> BaseResponse[Any]:
        """GET /people."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /people/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_metrics(
        self,
        id: int,
        params: PeopleMetricsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /people/{id}/metrics."""
        response = self._get(f"/{id}/metrics", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_todos(self, id: int, params: PeopleTodosListParams | None = None) -> BaseResponse[Any]:
        """GET /people/{id}/todos."""
        response = self._get(f"/{id}/todos", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_projects_todos(
        self,
        person_id: int,
        project_id: int,
        params: PeopleProjectsTodosListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /people/{personId}/projects/{projectId}/todos."""
        response = self._get(f"/{person_id}/projects/{project_id}/todos", params=params)
        return BaseResponse[Any].model_validate(response)


class ProjectsResource(BaseResource):
    """Resource for /projects endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/projects")

    def list(self, params: ProjectsListParams | None = None) -> BaseResponse[Any]:
        """GET /projects."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /projects/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_metrics(
        self,
        id: int,
        params: ProjectsMetricsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /projects/{id}/metrics."""
        response = self._get(f"/{id}/metrics", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_todolists(
        self,
        id: int,
        params: ProjectsTodolistsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /projects/{id}/todolists."""
        response = self._get(f"/{id}/todolists", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_todos(
        self,
        id: int,
        params: ProjectsTodosListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /projects/{id}/todos."""
        response = self._get(f"/{id}/todos", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_todolists_todos(
        self,
        project_id: int,
        todolist_id: int,
        params: ProjectsTodolistsTodosListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /projects/{projectId}/todolists/{todolistId}/todos."""
        response = self._get(f"/{project_id}/todolists/{todolist_id}/todos", params=params)
        return BaseResponse[Any].model_validate(response)


class TodolistsResource(BaseResource):
    """Resource for /todolists endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/todolists")

    def list(self, params: TodolistsListParams | None = None) -> BaseResponse[Any]:
        """GET /todolists."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /todolists/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)


class TodosResource(BaseResource):
    """Resource for /todos endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/todos")

    def list(self, params: TodosListParams | None = None) -> BaseResponse[Any]:
        """GET /todos."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /todos/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_comments(
        self,
        id: int,
        params: TodosCommentsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /todos/{id}/comments."""
        response = self._get(f"/{id}/comments", params=params)
        return BaseResponse[Any].model_validate(response)

    def list_events(
        self,
        id: int,
        params: TodosEventsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /todos/{id}/events."""
        response = self._get(f"/{id}/events", params=params)
        return BaseResponse[Any].model_validate(response)

    def get_events(
        self,
        id: int,
        event_num: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /todos/{id}/events/{eventNum}."""
        response = self._get(f"/{id}/events/{event_num}", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_metrics(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /todos/{id}/metrics."""
        response = self._get(f"/{id}/metrics", params=options)
        return BaseResponse[Any].model_validate(response)

    def list_sessions(
        self,
        id: int,
        params: TodosSessionsListParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /todos/{id}/sessions."""
        response = self._get(f"/{id}/sessions", params=params)
        return BaseResponse[Any].model_validate(response)

    def create_sessions(self, id: int, data: Any = None) -> BaseResponse[Any]:
        """POST /todos/{id}/sessions."""
        response = self._post(f"/{id}/sessions", data=data)
        return BaseResponse[Any].model_validate(response)

    def delete_sessions(self, id: int, session_id: int) -> BaseResponse[Any]:
        """DELETE /todos/{id}/sessions/{sessionId}."""
        response = self._delete(f"/{id}/sessions/{session_id}")
        return BaseResponse[Any].model_validate(response)

    def get_sessions(
        self,
        id: int,
        session_id: int,
        options: EdgeCacheParams | None = None,
    ) -> BaseResponse[Any]:
        """GET /todos/{id}/sessions/{sessionId}."""
        response = self._get(f"/{id}/sessions/{session_id}", params=options)
        return BaseResponse[Any].model_validate(response)

    def update_sessions(self, id: int, session_id: int, data: Any = None) -> BaseResponse[Any]:
        """PUT /todos/{id}/sessions/{sessionId}."""
        response = self._put(f"/{id}/sessions/{session_id}", data=data)
        return BaseResponse[Any].model_validate(response)


class TodosSummaryResource(BaseResource):
    """Resource for /todos-summary endpoints."""

    def __init__(self, http: HTTPClient) -> None:
        """Initialize the resource."""
        super().__init__(http, "/todos-summary")

    def list(self, params: TodosSummaryListParams | None = None) -> BaseResponse[Any]:
        """GET /todos-summary."""
        response = self._get(params=params)
        return BaseResponse[Any].model_validate(response)

    def get(self, id: int, options: EdgeCacheParams | None = None) -> BaseResponse[Any]:
        """GET /todos-summary/{id}."""
        response = self._get(f"/{id}", params=options)
        return BaseResponse[Any].model_validate(response)


class Basecamp2Client(BaseServiceClient):
    """Client for the basecamp2 service."""

    def __init__(self, http_client: HTTPClient) -> None:
        """Initialize the client."""
        super().__init__(http_client)
        self._comments: CommentsResource | None = None
        self._events: EventsResource | None = None
        self._metrics: MetricsResource | None = None
        self._people: PeopleResource | None = None
        self._projects: ProjectsResource | None = None
        self._todolists: TodolistsResource | None = None
        self._todos: TodosResource | None = None
        self._todos_summary: TodosSummaryResource | None = None

    @property
    def comments(self) -> CommentsResource:
        """Access comments endpoints."""
        if self._comments is None:
            self._comments = CommentsResource(self._http)
        return self._comments

    @property
    def events(self) -> EventsResource:
        """Access events endpoints."""
        if self._events is None:
            self._events = EventsResource(self._http)
        return self._events

    @property
    def metrics(self) -> MetricsResource:
        """Access metrics endpoints."""
        if self._metrics is None:
            self._metrics = MetricsResource(self._http)
        return self._metrics

    @property
    def people(self) -> PeopleResource:
        """Access people endpoints."""
        if self._people is None:
            self._people = PeopleResource(self._http)
        return self._people

    @property
    def projects(self) -> ProjectsResource:
        """Access projects endpoints."""
        if self._projects is None:
            self._projects = ProjectsResource(self._http)
        return self._projects

    @property
    def todolists(self) -> TodolistsResource:
        """Access todolists endpoints."""
        if self._todolists is None:
            self._todolists = TodolistsResource(self._http)
        return self._todolists

    @property
    def todos(self) -> TodosResource:
        """Access todos endpoints."""
        if self._todos is None:
            self._todos = TodosResource(self._http)
        return self._todos

    @property
    def todos_summary(self) -> TodosSummaryResource:
        """Access todosSummary endpoints."""
        if self._todos_summary is None:
            self._todos_summary = TodosSummaryResource(self._http)
        return self._todos_summary
