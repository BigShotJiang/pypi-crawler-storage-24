"""Generated code for vmi service."""
