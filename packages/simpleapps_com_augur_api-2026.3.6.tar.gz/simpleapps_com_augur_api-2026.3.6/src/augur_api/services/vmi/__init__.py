"""VMI service exports."""

from augur_api.services.vmi.client import (
    DistributorsResource,
    InvProfileHdrResource,
    ProductsResource,
    RestockHdrResource,
    SectionsResource,
    VmiClient,
    WarehouseResource,
)

VMIClient = VmiClient

__all__ = [
    "VmiClient",
    "VMIClient",
    "DistributorsResource",
    "InvProfileHdrResource",
    "ProductsResource",
    "RestockHdrResource",
    "SectionsResource",
    "WarehouseResource",
]
