"""
常量定义模块。

集中管理项目中使用的常量，避免硬编码分散到各处。
"""

import os
import sys


def _get_default_log_dir() -> str:
    """根据当前操作系统平台返回默认日志目录。

    - Linux:   /usr/local/qqbrowser-skill-log
    - macOS:   ~/Library/Logs/qqbrowser-skill
    - Windows: %LOCALAPPDATA%/qqbrowser-skill/logs
    """
    if sys.platform == "win32":
        base = os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))
        return os.path.join(base, "qqbrowser-skill", "logs")
    elif sys.platform == "darwin":
        return os.path.expanduser("~/Library/Logs/qqbrowser-skill")
    else:
        # Linux 及其他类 Unix 系统
        return "/usr/local/qqbrowser-skill-log"


# 默认日志目录（根据平台自动选择）
DEFAULT_LOG_DIR = _get_default_log_dir()


def _get_browser_executable() -> str:
    """根据当前操作系统平台返回 QQ 浏览器可执行文件路径/名称。"""
    if sys.platform == "win32":
        # Windows 下默认安装路径
        local_app = os.environ.get("LOCALAPPDATA", os.path.expanduser("~"))
        return os.path.join(local_app, "QQBrowser", "QQBrowser.exe")
    elif sys.platform == "darwin":
        return "/Applications/QQBrowser.app/Contents/MacOS/QQBrowser"
    else:
        return "qqbrowser-browser-stable"


def _get_browser_process_name() -> str:
    """根据当前操作系统平台返回 QQ 浏览器进程名（用于进程检测）。"""
    if sys.platform == "win32":
        return "QQBrowser.exe"
    elif sys.platform == "darwin":
        return "QQBrowser"
    else:
        return "qqbrowser"


# QQ 浏览器可执行文件路径（根据平台自动选择）
BROWSER_EXECUTABLE = _get_browser_executable()

# QQ 浏览器进程名（根据平台自动选择，用于进程检测）
BROWSER_PROCESS_NAME = _get_browser_process_name()
