from big_o_sdk.errors import (
    AuthenticationError,
    BigOError,
    BudgetExceededError,
    ModelAccessDeniedError,
    RateLimitError,
    ServiceUnavailableError,
)


def test_error_hierarchy():
    assert issubclass(AuthenticationError, BigOError)
    assert issubclass(ModelAccessDeniedError, BigOError)
    assert issubclass(RateLimitError, BigOError)
    assert issubclass(BudgetExceededError, BigOError)
    assert issubclass(ServiceUnavailableError, BigOError)


def test_error_message():
    err = AuthenticationError("invalid token")
    assert str(err) == "invalid token"
    assert isinstance(err, BigOError)
    assert isinstance(err, Exception)
