from big_o_sdk.config import BigOConfig


def test_config_defaults():
    config = BigOConfig(client_id="test-id", client_secret="test-secret")
    assert config.client_id == "test-id"
    assert config.client_secret == "test-secret"
    assert config.base_url == "https://devops.versnellers.nl/bigo/api"
    assert config.chat_model == "gpt-4o-mini"
    assert config.embedding_model == "text-embedding-3-large"
    assert config.context_window == 128_000


def test_config_custom_values():
    config = BigOConfig(
        client_id="id",
        client_secret="secret",
        base_url="https://custom.example.com",
        chat_model="gpt-4",
        embedding_model="text-embedding-ada-002",
        context_window=4096,
    )
    assert config.base_url == "https://custom.example.com"
    assert config.chat_model == "gpt-4"
    assert config.embedding_model == "text-embedding-ada-002"
    assert config.context_window == 4096


def test_config_is_frozen():
    config = BigOConfig(client_id="id", client_secret="secret")
    try:
        config.client_id = "changed"
        assert False, "Should have raised"
    except AttributeError:
        pass
