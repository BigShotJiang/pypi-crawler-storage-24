"""Shared token refresh mixins and error handling for Big-O framework integrations."""

import logging
from functools import wraps

import httpx
from pydantic import PrivateAttr

from big_o_sdk.auth import BigOAuthenticator
from big_o_sdk.config import BigOConfig
from big_o_sdk.errors import (
    AuthenticationError,
    ModelAccessDeniedError,
    RateLimitError,
    ServiceUnavailableError,
)

logger = logging.getLogger(__name__)


def handle_openai_errors(func):
    """Decorator to translate OpenAI SDK errors into Big-O domain errors."""

    @wraps(func)
    async def wrapper(self, *args, **kwargs):
        from openai import AuthenticationError as OpenAIAuthError
        from openai import PermissionDeniedError as OpenAIPermissionError
        from openai import RateLimitError as OpenAIRateLimitError

        try:
            return await func(self, *args, **kwargs)
        except OpenAIAuthError as e:
            logger.error("Authentication failed: %s", e)
            raise AuthenticationError(str(e)) from e
        except OpenAIPermissionError as e:
            logger.error("Model access denied: %s", e)
            raise ModelAccessDeniedError(str(e)) from e
        except OpenAIRateLimitError as e:
            logger.warning("Rate limit exceeded: %s", e)
            raise RateLimitError(str(e)) from e
        except httpx.ConnectError as e:
            logger.error("Cannot connect to Big-O gateway: %s", e)
            raise ServiceUnavailableError(f"Cannot connect to gateway: {e}") from e

    return wrapper


class BigOLlamaIndexMixin:
    """Token refresh mixin for LlamaIndex (Pydantic-based) wrappers."""

    _bigo_auth: BigOAuthenticator = PrivateAttr()
    _bigo_http: httpx.AsyncClient = PrivateAttr()
    _bigo_token: str | None = PrivateAttr(default=None)

    def _init_auth(self, config: BigOConfig):
        """Initialize authenticator and HTTP client."""
        self._bigo_auth = BigOAuthenticator(config)
        self._bigo_http = httpx.AsyncClient()
        self._bigo_token = None

    async def _refresh_token_async(self):
        """Refresh JWT token if expired, clearing the cached async OpenAI client."""
        token = await self._bigo_auth.get_token(self._bigo_http)
        if token != self._bigo_token:
            logger.debug("Token refreshed (async) for %s", self.__class__.__name__)
            self._bigo_token = token
            self.api_key = token
            self._aclient = None

    def _refresh_token_sync(self):
        """Refresh JWT token synchronously, clearing the cached sync OpenAI client."""
        token = self._bigo_auth.get_token_sync()
        if token != self._bigo_token:
            logger.debug("Token refreshed (sync) for %s", self.__class__.__name__)
            self._bigo_token = token
            self.api_key = token
            self._client = None

    async def close(self):
        """Close the HTTP client and release resources."""
        logger.debug("Closing %s HTTP connection", self.__class__.__name__)
        await self._bigo_http.aclose()


class BigOHaystackMixin:
    """Token refresh mixin for Haystack (plain class) embedders."""

    _bigo_auth: BigOAuthenticator
    _bigo_http: httpx.AsyncClient | None
    _bigo_token: str | None

    def _init_auth(self, config: BigOConfig):
        """Initialize authenticator and HTTP client."""
        self._bigo_auth = BigOAuthenticator(config)
        self._bigo_http = None
        self._bigo_token = None

    def _refresh_token_sync(self):
        """Refresh JWT token synchronously, updating the OpenAI client."""
        token = self._bigo_auth.get_token_sync()
        if token != self._bigo_token:
            logger.debug("Token refreshed (sync) for %s", self.__class__.__name__)
            self._bigo_token = token
            self.client.api_key = token

    async def _refresh_token_async(self):
        """Refresh JWT token asynchronously, updating the async OpenAI client."""
        if self._bigo_http is None:
            self._bigo_http = httpx.AsyncClient()
        token = await self._bigo_auth.get_token(self._bigo_http)
        if token != self._bigo_token:
            logger.debug("Token refreshed (async) for %s", self.__class__.__name__)
            self._bigo_token = token
            self.async_client.api_key = token
