"""Domain-specific exceptions for the Big-O gateway."""


class BigOError(Exception):
    """Base exception for all Big-O errors."""


class AuthenticationError(BigOError):
    """Invalid or missing client credentials."""


class ModelAccessDeniedError(BigOError):
    """Model not available in the client's subscription."""


class RateLimitError(BigOError):
    """Rate limit or request frequency exceeded."""


class BudgetExceededError(BigOError):
    """Token or cost budget exceeded for the billing period."""


class ServiceUnavailableError(BigOError):
    """Backend or authentication service is unavailable."""
