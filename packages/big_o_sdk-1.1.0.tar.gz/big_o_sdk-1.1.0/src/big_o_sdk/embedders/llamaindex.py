"""LlamaIndex embedding for the Big-O gateway."""

import logging

from llama_index.embeddings.openai import OpenAIEmbedding
from pydantic import ConfigDict

from big_o_sdk.config import BigOConfig
from big_o_sdk.mixins import BigOLlamaIndexMixin, handle_openai_errors

logger = logging.getLogger(__name__)


class BigOEmbedding(BigOLlamaIndexMixin, OpenAIEmbedding):
    """LlamaIndex Embedding with auto-refreshing Big-O JWT tokens."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def __init__(
        self,
        config: BigOConfig,
        model: str | None = None,
        **kwargs,
    ):
        """Initialize BigOEmbedding with Big-O config and model settings."""
        model = model or config.embedding_model
        kwargs.setdefault("additional_kwargs", {})
        kwargs["additional_kwargs"]["encoding_format"] = "float"
        super().__init__(
            model_name=model,
            api_base=config.openai_base_url,
            api_key="pending",
            **kwargs,
        )
        self._init_auth(config)
        logger.debug("BigOEmbedding initialized with model=%s", model)

    def _get_query_embedding(self, query: str) -> list[float]:
        """Get query embedding with auto-refreshed token (sync)."""
        self._refresh_token_sync()
        return super()._get_query_embedding(query)

    def _get_text_embedding(self, text: str) -> list[float]:
        """Get text embedding with auto-refreshed token (sync)."""
        self._refresh_token_sync()
        return super()._get_text_embedding(text)

    def _get_text_embeddings(self, texts: list[str]) -> list[list[float]]:
        """Get batch text embeddings with auto-refreshed token (sync)."""
        self._refresh_token_sync()
        return super()._get_text_embeddings(texts)

    @handle_openai_errors
    async def _aget_query_embedding(self, query: str) -> list[float]:
        """Get query embedding with auto-refreshed token (async)."""
        await self._refresh_token_async()
        return await super()._aget_query_embedding(query)

    @handle_openai_errors
    async def _aget_text_embedding(self, text: str) -> list[float]:
        """Get text embedding with auto-refreshed token (async)."""
        await self._refresh_token_async()
        return await super()._aget_text_embedding(text)

    @handle_openai_errors
    async def _aget_text_embeddings(self, texts: list[str]) -> list[list[float]]:
        """Get batch text embeddings with auto-refreshed token (async)."""
        await self._refresh_token_async()
        return await super()._aget_text_embeddings(texts)
