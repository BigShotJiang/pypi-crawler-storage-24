"""Haystack embeddings for the Big-O gateway."""

import logging
from typing import Any

from haystack import Document, component
from haystack.components.embedders import OpenAIDocumentEmbedder, OpenAITextEmbedder
from haystack.utils import Secret

from big_o_sdk.config import BigOConfig
from big_o_sdk.mixins import BigOHaystackMixin

logger = logging.getLogger(__name__)


class BigOTextEmbedder(BigOHaystackMixin, OpenAITextEmbedder):
    """Haystack text embedder with auto-refreshing Big-O JWT tokens."""

    def __init__(
        self,
        config: BigOConfig,
        model: str | None = None,
        **kwargs,
    ):
        """Initialize BigOTextEmbedder with Big-O config and model settings."""
        model = model or config.embedding_model
        kwargs.pop("encoding_format", None)
        OpenAITextEmbedder.__init__(
            self,
            api_key=Secret.from_token("pending"),
            model=model,
            api_base_url=config.openai_base_url,
            **kwargs,
        )
        self._init_auth(config)
        logger.debug("BigOTextEmbedder initialized with model=%s", model)

    @component.output_types(embedding=list[float], meta=dict[str, Any])
    def run(self, text: str):
        """Embed a single text string with auto-refreshed token."""
        self._refresh_token_sync()
        return OpenAITextEmbedder.run(self, text=text)

    @component.output_types(embedding=list[float], meta=dict[str, Any])
    async def run_async(self, text: str):
        """Embed a single text string asynchronously with auto-refreshed token."""
        await self._refresh_token_async()
        return await OpenAITextEmbedder.run_async(self, text=text)


class BigODocumentEmbedder(BigOHaystackMixin, OpenAIDocumentEmbedder):
    """Haystack document embedder with auto-refreshing Big-O JWT tokens."""

    def __init__(
        self,
        config: BigOConfig,
        model: str | None = None,
        **kwargs,
    ):
        """Initialize BigODocumentEmbedder with Big-O config and model settings."""
        model = model or config.embedding_model
        kwargs.pop("encoding_format", None)
        OpenAIDocumentEmbedder.__init__(
            self,
            api_key=Secret.from_token("pending"),
            model=model,
            api_base_url=config.openai_base_url,
            **kwargs,
        )
        self._init_auth(config)
        logger.debug("BigODocumentEmbedder initialized with model=%s", model)

    @component.output_types(documents=list[Document], meta=dict[str, Any])
    def run(self, documents: list[Document]):
        """Embed a list of documents with auto-refreshed token."""
        self._refresh_token_sync()
        return OpenAIDocumentEmbedder.run(self, documents=documents)

    @component.output_types(documents=list[Document], meta=dict[str, Any])
    async def run_async(self, documents: list[Document]):
        """Embed a list of documents asynchronously with auto-refreshed token."""
        await self._refresh_token_async()
        return await OpenAIDocumentEmbedder.run_async(self, documents=documents)
