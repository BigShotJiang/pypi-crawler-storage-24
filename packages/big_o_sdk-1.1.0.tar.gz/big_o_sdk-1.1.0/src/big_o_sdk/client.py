"""Client for checking Big-O gateway status and available models."""

import logging

import httpx

from big_o_sdk.auth import BigOAuthenticator
from big_o_sdk.config import BigOConfig
from big_o_sdk.errors import AuthenticationError, ServiceUnavailableError

logger = logging.getLogger(__name__)


class BigOClient:
    """Client for Big-O gateway health, ping, and model discovery."""

    def __init__(self, config: BigOConfig):
        """Initialize with Big-O configuration."""
        self._config = config
        self._auth = BigOAuthenticator(config)
        self._http = httpx.AsyncClient()

    async def health(self) -> dict:
        """Check backend health. No authentication required."""
        logger.debug("Checking backend health")
        try:
            response = await self._http.get(f"{self._config.base_url}/health-backend")
        except httpx.ConnectError as e:
            logger.error("Cannot connect to Big-O gateway: %s", e)
            raise ServiceUnavailableError(f"Cannot connect to gateway: {e}") from e

        if response.status_code == 503:
            logger.warning("Backend service unavailable")
            raise ServiceUnavailableError("Backend service unavailable")
        response.raise_for_status()
        return response.json()

    async def health_llm(self) -> dict:
        """Check LLM model availability. No authentication required."""
        logger.debug("Checking LLM health")
        try:
            response = await self._http.get(f"{self._config.base_url}/health-llm")
        except httpx.ConnectError as e:
            logger.error("Cannot connect to Big-O gateway: %s", e)
            raise ServiceUnavailableError(f"Cannot connect to gateway: {e}") from e

        return response.json()

    async def ping(self) -> bool:
        """Verify JWT authentication. Returns True if valid."""
        logger.debug("Pinging API")
        try:
            token = await self._auth.get_token(self._http)
            response = await self._http.get(
                f"{self._config.base_url}/ping",
                headers={"Authorization": f"Bearer {token}"},
            )
        except httpx.ConnectError as e:
            logger.error("Cannot connect to Big-O gateway: %s", e)
            raise ServiceUnavailableError(f"Cannot connect to gateway: {e}") from e

        ok = response.is_success
        if not ok:
            logger.warning("Ping failed with status %d", response.status_code)
        return ok

    async def models(self) -> list[dict]:
        """List available models. Requires authentication."""
        logger.debug("Fetching available models")
        try:
            token = await self._auth.get_token(self._http)
            response = await self._http.get(
                f"{self._config.openai_base_url}/models",
                headers={"Authorization": f"Bearer {token}"},
            )
        except httpx.ConnectError as e:
            logger.error("Cannot connect to Big-O gateway: %s", e)
            raise ServiceUnavailableError(f"Cannot connect to gateway: {e}") from e

        if response.status_code == 401:
            logger.error("Authentication failed when fetching models")
            raise AuthenticationError("Invalid or expired token")
        response.raise_for_status()

        models = response.json().get("data", [])
        logger.debug("Found %d models", len(models))
        return models

    async def close(self):
        """Close the HTTP client and release resources."""
        await self._http.aclose()
