"""Immutable configuration for the Big-O gateway."""

import os
from dataclasses import dataclass

from big_o_sdk.errors import AuthenticationError

DEFAULT_BASE_URL = "https://devops.versnellers.nl/bigo/api"
DEFAULT_CHAT_MODEL = "gpt-4o-mini"
DEFAULT_EMBEDDING_MODEL = "text-embedding-3-large"
DEFAULT_CONTEXT_WINDOW = 128000


@dataclass(frozen=True)
class BigOConfig:
    """Holds Big-O gateway connection settings and model defaults."""

    base_url: str = DEFAULT_BASE_URL
    client_id: str = ""
    client_secret: str = ""
    chat_model: str = DEFAULT_CHAT_MODEL
    embedding_model: str = DEFAULT_EMBEDDING_MODEL
    context_window: int = DEFAULT_CONTEXT_WINDOW

    def __post_init__(self):
        """Validate that required credentials are provided."""
        if not self.client_id:
            raise AuthenticationError("BIG_O_CLIENT_ID is not set")
        if not self.client_secret:
            raise AuthenticationError("BIG_O_CLIENT_SECRET is not set")

    @property
    def token_url(self) -> str:
        """Full URL for the OAuth2 token endpoint."""
        return f"{self.base_url}/token"

    @property
    def openai_base_url(self) -> str:
        """Full URL for the OpenAI-compatible v1 API."""
        return f"{self.base_url}/v1"

    @staticmethod
    def from_env() -> "BigOConfig":
        """Create a BigOConfig from environment variables."""
        return BigOConfig(
            base_url=os.getenv("BIG_O_BASE_URL", DEFAULT_BASE_URL),
            client_id=os.getenv("BIG_O_CLIENT_ID", ""),
            client_secret=os.getenv("BIG_O_CLIENT_SECRET", ""),
            chat_model=os.getenv("BIG_O_CHAT_MODEL", DEFAULT_CHAT_MODEL),
            embedding_model=os.getenv("BIG_O_EMBEDDING_MODEL", DEFAULT_EMBEDDING_MODEL),
            context_window=int(
                os.getenv("BIG_O_CONTEXT_WINDOW", str(DEFAULT_CONTEXT_WINDOW))
            ),
        )
