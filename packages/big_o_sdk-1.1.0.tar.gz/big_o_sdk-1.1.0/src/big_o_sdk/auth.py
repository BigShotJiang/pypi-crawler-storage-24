"""JWT token lifecycle management for the Big-O gateway."""

import logging
import time

import httpx

from big_o_sdk.config import BigOConfig
from big_o_sdk.errors import AuthenticationError, ServiceUnavailableError

logger = logging.getLogger(__name__)

TOKEN_REFRESH_MARGIN_SECONDS = 30


class BigOAuthenticator:
    """Manages OAuth2 Client Credentials token retrieval and caching."""

    def __init__(self, config: BigOConfig):
        """Initialize with Big-O configuration."""
        self._config = config
        self._token: str | None = None
        self._expires_at: float = 0

    async def get_token(self, http: httpx.AsyncClient) -> str:
        """Return a valid JWT token, fetching a new one if expired."""
        if self._is_token_valid():
            return self._token
        return await self._fetch_token_async(http)

    def get_token_sync(self) -> str:
        """Return a valid JWT token synchronously, fetching a new one if expired."""
        if self._is_token_valid():
            return self._token
        return self._fetch_token_sync()

    def _is_token_valid(self) -> bool:
        """Check whether the cached token is still valid."""
        return self._token is not None and time.time() < self._expires_at

    async def _fetch_token_async(self, http: httpx.AsyncClient) -> str:
        """Fetch a new JWT token asynchronously."""
        logger.debug("Requesting JWT token for client: %s", self._config.client_id)
        try:
            response = await http.post(
                self._config.token_url,
                data=self._token_request_data(),
            )
        except httpx.ConnectError as e:
            logger.error("Cannot connect to Big-O gateway: %s", e)
            raise ServiceUnavailableError(f"Cannot connect to gateway: {e}") from e

        self._handle_token_errors(response)
        return self._store_token(response.json())

    def _fetch_token_sync(self) -> str:
        """Fetch a new JWT token synchronously."""
        logger.debug(
            "Requesting JWT token (sync) for client: %s", self._config.client_id
        )
        try:
            response = httpx.post(
                self._config.token_url,
                data=self._token_request_data(),
            )
        except httpx.ConnectError as e:
            logger.error("Cannot connect to Big-O gateway: %s", e)
            raise ServiceUnavailableError(f"Cannot connect to gateway: {e}") from e

        self._handle_token_errors(response)
        return self._store_token(response.json())

    def _token_request_data(self) -> dict:
        """Build the OAuth2 token request payload."""
        return {
            "grant_type": "client_credentials",
            "client_id": self._config.client_id,
            "client_secret": self._config.client_secret,
        }

    def _store_token(self, data: dict) -> str:
        """Cache the token and set expiry."""
        expires_in = data.get("expires_in", 300)
        self._token = data["access_token"]
        self._expires_at = time.time() + expires_in - TOKEN_REFRESH_MARGIN_SECONDS
        logger.debug("Token obtained (expires in %ss)", expires_in)
        return self._token

    def _handle_token_errors(self, response: httpx.Response):
        """Raise domain errors for failed token requests."""
        if response.is_success:
            return

        status = response.status_code

        if status == 401:
            logger.error("Token request failed: invalid credentials")
            raise AuthenticationError("Invalid client credentials")
        if status == 400:
            logger.error("Token request failed: missing credentials")
            raise AuthenticationError("Missing client credentials")
        if status == 503:
            logger.error("Token request failed: auth service unavailable")
            raise ServiceUnavailableError("Authentication service unavailable")

        logger.error("Token request failed with status %d", status)
        response.raise_for_status()
