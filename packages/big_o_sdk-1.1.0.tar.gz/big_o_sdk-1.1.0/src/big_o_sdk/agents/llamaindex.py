"""LlamaIndex LLM agent for the Big-O gateway."""

import logging

from llama_index.llms.openai_like import OpenAILike
from pydantic import ConfigDict

from big_o_sdk.config import BigOConfig
from big_o_sdk.mixins import BigOLlamaIndexMixin, handle_openai_errors

logger = logging.getLogger(__name__)


class BigOLLM(BigOLlamaIndexMixin, OpenAILike):
    """LlamaIndex LLM with auto-refreshing Big-O JWT tokens."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    def __init__(
        self,
        config: BigOConfig,
        model: str | None = None,
        context_window: int | None = None,
        is_function_calling_model: bool = True,
        **kwargs,
    ):
        """Initialize BigOLLM with Big-O config and model settings."""
        model = model or config.chat_model
        context_window = context_window or config.context_window
        super().__init__(
            model=model,
            api_base=config.openai_base_url,
            api_key="pending",
            is_chat_model=True,
            is_function_calling_model=is_function_calling_model,
            context_window=context_window,
            reuse_client=True,
            **kwargs,
        )
        self._init_auth(config)
        logger.debug("BigOLLM initialized with model=%s", model)

    @handle_openai_errors
    async def achat(self, *args, **kwargs):
        """Send a chat request with auto-refreshed token."""
        await self._refresh_token_async()
        return await super().achat(*args, **kwargs)

    @handle_openai_errors
    async def acomplete(self, *args, **kwargs):
        """Send a completion request with auto-refreshed token."""
        await self._refresh_token_async()
        return await super().acomplete(*args, **kwargs)

    @handle_openai_errors
    async def astream_chat(self, *args, **kwargs):
        """Stream a chat response with auto-refreshed token."""
        await self._refresh_token_async()
        return await super().astream_chat(*args, **kwargs)

    @handle_openai_errors
    async def astream_complete(self, *args, **kwargs):
        """Stream a completion response with auto-refreshed token."""
        await self._refresh_token_async()
        return await super().astream_complete(*args, **kwargs)
