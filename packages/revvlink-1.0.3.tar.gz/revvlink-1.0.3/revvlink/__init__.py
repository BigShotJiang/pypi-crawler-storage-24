"""
MIT License

Copyright (c) 2026-Present @JustNixx and @Dipendra-creator

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

RevvLink
~~~~~~~~

A modern, simple, and powerful Lavalink wrapper for discord.py and its derivatives.
Built with performance and ease of use in mind.

:copyright: (c) 2026-Present @JustNixx and @Dipendra-creator
:license: MIT, see LICENSE for more details.
"""

__title__ = "RevvLink"
__author__ = "@JustNixx and @Dipendra-creator"
__license__ = "MIT"
__copyright__ = "Copyright 2026-Present (c) @JustNixx and @Dipendra-creator"
__version__ = "1.0.3"

from .enums import *
from .exceptions import *
from .filters import *
from .lfu import CapacityZero as CapacityZero
from .lfu import LFUCache as LFUCache
from .logger import revv_logger as revv_logger
from .node import *
from .payloads import *
from .player import Player as Player
from .queue import *
from .tracks import *
from .types.state import PlayerBasicState as PlayerBasicState
from .utils import ExtrasNamespace as ExtrasNamespace
