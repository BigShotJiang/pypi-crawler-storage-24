"""Unit tests for the AgentTool SDK — all HTTP mocked, no network needed."""

from __future__ import annotations

import os
from unittest.mock import MagicMock, patch

import httpx
import pytest

from agenttool import AgentTool, AgentToolError, Memory, SearchResult


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_response(status_code: int = 200, json_data: object = None, text: str = "") -> MagicMock:
    """Create a fake httpx.Response."""
    resp = MagicMock(spec=httpx.Response)
    resp.status_code = status_code
    resp.json.return_value = json_data if json_data is not None else {}
    resp.text = text or ""
    return resp


# ---------------------------------------------------------------------------
# Client init
# ---------------------------------------------------------------------------

class TestClientInit:
    def test_reads_env_var(self) -> None:
        with patch.dict(os.environ, {"AT_API_KEY": "test-key-123"}):
            at = AgentTool()
            assert repr(at) == "AgentTool(base_url='https://api.agenttool.dev')"
            at.close()

    def test_explicit_key_overrides_env(self) -> None:
        with patch.dict(os.environ, {"AT_API_KEY": "env-key"}):
            at = AgentTool(api_key="explicit-key")
            # Check the header was set with the explicit key
            assert at._http.headers["authorization"] == "Bearer explicit-key"
            at.close()

    def test_missing_key_raises(self) -> None:
        with patch.dict(os.environ, {}, clear=True):
            # Also need to remove AT_API_KEY if it exists
            env = os.environ.copy()
            env.pop("AT_API_KEY", None)
            with patch.dict(os.environ, env, clear=True):
                with pytest.raises(AgentToolError) as exc_info:
                    AgentTool()
                assert "No API key" in exc_info.value.message
                assert exc_info.value.hint is not None

    def test_context_manager(self) -> None:
        with patch.dict(os.environ, {"AT_API_KEY": "k"}):
            with AgentTool() as at:
                assert at is not None


# ---------------------------------------------------------------------------
# Memory
# ---------------------------------------------------------------------------

class TestMemory:
    @pytest.fixture()
    def at(self) -> AgentTool:
        with patch.dict(os.environ, {"AT_API_KEY": "test-key"}):
            client = AgentTool()
        return client

    def test_store_minimal(self, at: AgentTool) -> None:
        """at.memory.store('just a string') must work."""
        mock_resp = _mock_response(200, {
            "id": "mem-1",
            "content": "just a string",
            "type": "semantic",
            "importance": 0.5,
        })
        with patch.object(at._http, "post", return_value=mock_resp) as mock_post:
            mem = at.memory.store("just a string")

            assert isinstance(mem, Memory)
            assert mem.id == "mem-1"
            assert mem.content == "just a string"
            # Verify the POST body
            call_kwargs = mock_post.call_args
            body = call_kwargs.kwargs.get("json") or call_kwargs[1].get("json")
            assert body["content"] == "just a string"
            assert body["type"] == "semantic"

    def test_store_full(self, at: AgentTool) -> None:
        mock_resp = _mock_response(200, {
            "id": "mem-2",
            "content": "hello",
            "type": "episodic",
            "agent_id": "agent-1",
            "key": "greeting",
            "metadata": {"source": "test"},
            "importance": 0.9,
        })
        with patch.object(at._http, "post", return_value=mock_resp):
            mem = at.memory.store(
                "hello",
                type="episodic",
                agent_id="agent-1",
                key="greeting",
                metadata={"source": "test"},
                importance=0.9,
            )
            assert mem.type == "episodic"
            assert mem.agent_id == "agent-1"
            assert mem.importance == 0.9

    def test_search(self, at: AgentTool) -> None:
        mock_resp = _mock_response(200, {
            "results": [
                {"id": "m1", "content": "hello world", "type": "semantic"},
                {"id": "m2", "content": "goodbye", "type": "semantic"},
            ]
        })
        with patch.object(at._http, "post", return_value=mock_resp):
            results = at.memory.search("hello")
            assert len(results) == 2
            assert all(isinstance(r, Memory) for r in results)

    def test_search_list_response(self, at: AgentTool) -> None:
        """Handle APIs that return a raw list instead of {results: [...]}."""
        mock_resp = _mock_response(200, [
            {"id": "m1", "content": "item", "type": "semantic"},
        ])
        with patch.object(at._http, "post", return_value=mock_resp):
            results = at.memory.search("item")
            assert len(results) == 1

    def test_get(self, at: AgentTool) -> None:
        mock_resp = _mock_response(200, {
            "id": "mem-42",
            "content": "remembered",
            "type": "procedural",
        })
        with patch.object(at._http, "get", return_value=mock_resp):
            mem = at.memory.get("mem-42")
            assert mem.id == "mem-42"
            assert mem.content == "remembered"

    def test_usage(self, at: AgentTool) -> None:
        mock_resp = _mock_response(200, {
            "memories_stored": 100,
            "searches_performed": 50,
            "api_calls": 200,
        })
        with patch.object(at._http, "get", return_value=mock_resp):
            usage = at.memory.usage()
            assert usage.memories_stored == 100
            assert usage.api_calls == 200

    def test_error_raises(self, at: AgentTool) -> None:
        mock_resp = _mock_response(401, {"detail": "Unauthorized"}, "Unauthorized")
        with patch.object(at._http, "post", return_value=mock_resp):
            with pytest.raises(AgentToolError) as exc_info:
                at.memory.store("fail")
            assert "401" in exc_info.value.message
            assert exc_info.value.hint is not None


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------

class TestTools:
    @pytest.fixture()
    def at(self) -> AgentTool:
        with patch.dict(os.environ, {"AT_API_KEY": "test-key"}):
            client = AgentTool()
        return client

    def test_search(self, at: AgentTool) -> None:
        mock_resp = _mock_response(200, {
            "results": [
                {"title": "AI News", "url": "https://ai.com", "snippet": "Latest..."},
            ]
        })
        with patch.object(at._http, "post", return_value=mock_resp) as mock_post:
            results = at.tools.search("AI news", num_results=3)
            assert len(results) == 1
            assert isinstance(results[0], SearchResult)
            assert results[0].title == "AI News"
            call_url = mock_post.call_args[0][0] if mock_post.call_args[0] else mock_post.call_args.args[0]
            assert "/v1/search/search" in call_url, f"Wrong search URL: {call_url}"
            body = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
            assert body["num_results"] == 3

    def test_scrape(self, at: AgentTool) -> None:
        mock_resp = _mock_response(200, {
            "url": "https://example.com",
            "content": "<h1>Hello</h1>",
            "status_code": 200,
        })
        with patch.object(at._http, "post", return_value=mock_resp) as mock_post:
            result = at.tools.scrape("https://example.com")
            call_url = mock_post.call_args[0][0] if mock_post.call_args[0] else mock_post.call_args.args[0]
            assert "/v1/scrape/scrape" in call_url, f"Wrong scrape URL: {call_url}"
            assert result.url == "https://example.com"
            assert "<h1>" in result.content

    def test_execute_python(self, at: AgentTool) -> None:
        mock_resp = _mock_response(200, {
            "output": "42\n",
            "error": "",
            "exit_code": 0,
        })
        with patch.object(at._http, "post", return_value=mock_resp) as mock_post:
            result = at.tools.execute("print(42)")
            assert result.output == "42\n"
            assert result.exit_code == 0
            body = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
            assert body["language"] == "python"

    def test_execute_javascript(self, at: AgentTool) -> None:
        mock_resp = _mock_response(200, {
            "output": "hello\n",
            "error": "",
            "exit_code": 0,
        })
        with patch.object(at._http, "post", return_value=mock_resp) as mock_post:
            result = at.tools.execute("console.log('hello')", language="javascript")
            assert result.output == "hello\n"
            body = mock_post.call_args.kwargs.get("json") or mock_post.call_args[1].get("json")
            assert body["language"] == "javascript"

    def test_error_raises(self, at: AgentTool) -> None:
        mock_resp = _mock_response(500, {"detail": "Internal error"}, "Internal error")
        with patch.object(at._http, "post", return_value=mock_resp):
            with pytest.raises(AgentToolError) as exc_info:
                at.tools.search("fail")
            assert "500" in exc_info.value.message


# ---------------------------------------------------------------------------
# AgentToolError
# ---------------------------------------------------------------------------

class TestAgentToolError:
    def test_message_and_hint(self) -> None:
        err = AgentToolError("something broke", hint="try again")
        assert err.message == "something broke"
        assert err.hint == "try again"
        assert "hint: try again" in str(err)

    def test_no_hint(self) -> None:
        err = AgentToolError("oops")
        assert err.hint is None
        assert str(err) == "oops"
