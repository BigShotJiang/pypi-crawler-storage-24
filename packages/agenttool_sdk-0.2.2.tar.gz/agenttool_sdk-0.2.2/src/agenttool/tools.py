"""Tools client for agent-tools API."""

from __future__ import annotations

from typing import Any, Dict, List

import httpx

from .exceptions import AgentToolError
from .models import ExecuteResult, ScrapeResult, SearchResult


class ToolsClient:
    """Client for the agent-tools API.

    Usage::

        at = AgentTool()
        results = at.tools.search("latest AI news")
        page = at.tools.scrape("https://example.com")
        out = at.tools.execute("print(1+1)")
    """

    def __init__(self, http: httpx.Client, base_url: str) -> None:
        self._http = http
        self._base = base_url.rstrip("/")

    def _url(self, path: str) -> str:
        return f"{self._base}{path}"

    def search(self, query: str, *, num_results: int = 5) -> List[SearchResult]:
        """Web search.

        Args:
            query: Search query string.
            num_results: Number of results to return.

        Returns:
            List of SearchResult objects.
        """
        body: Dict[str, Any] = {"query": query, "num_results": num_results}
        resp = self._http.post(self._url("/v1/search/search"), json=body)
        self._check(resp)
        data = resp.json()
        results = data if isinstance(data, list) else data.get("results", [])
        return [SearchResult.from_dict(r) for r in results]

    def scrape(self, url: str) -> ScrapeResult:
        """Scrape a URL and return its content.

        Args:
            url: The URL to scrape.

        Returns:
            ScrapeResult with the page content.
        """
        body: Dict[str, Any] = {"url": url}
        resp = self._http.post(self._url("/v1/scrape/scrape"), json=body)
        self._check(resp)
        return ScrapeResult.from_dict(resp.json())

    def execute(self, code: str, *, language: str = "python") -> ExecuteResult:
        """Execute code in a sandbox.

        Args:
            code: Source code to execute.
            language: "python" or "javascript".

        Returns:
            ExecuteResult with output, error, and exit code.
        """
        body: Dict[str, Any] = {"code": code, "language": language}
        resp = self._http.post(self._url("/v1/execute"), json=body)
        self._check(resp)
        return ExecuteResult.from_dict(resp.json())

    @staticmethod
    def _check(resp: httpx.Response) -> None:
        if resp.status_code >= 400:
            try:
                detail = resp.json().get("detail", resp.text)
            except Exception:
                detail = resp.text
            raise AgentToolError(
                f"Tools API error ({resp.status_code}): {detail}",
                hint="Check your API key and request parameters.",
            )
