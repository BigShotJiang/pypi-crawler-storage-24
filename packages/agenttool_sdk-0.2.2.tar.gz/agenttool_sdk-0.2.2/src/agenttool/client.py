"""Main AgentTool client — the single entry point."""

from __future__ import annotations

import os
from typing import Optional

import httpx

from .exceptions import AgentToolError
from .memory import MemoryClient
from .tools import ToolsClient
from .traces import TracesClient


class AgentTool:
    """Unified client for the agenttool.dev platform.

    Usage::

        from agenttool import AgentTool

        at = AgentTool()                          # reads AT_API_KEY from env
        at.memory.store("just a string")           # store a memory
        results = at.memory.search("what I said")  # semantic search
        hits = at.tools.search("latest AI news")   # web search
        page = at.tools.scrape("https://x.com")    # scrape a URL
        out = at.tools.execute("print(42)")         # run sandboxed code

    Args:
        api_key: API key. Falls back to ``AT_API_KEY`` env var.
        base_url: Override the API base URL.
        timeout: Request timeout in seconds.
    """

    def __init__(
        self,
        api_key: Optional[str] = None,
        *,
        base_url: str = "https://api.agenttool.dev",
        timeout: float = 30.0,
    ) -> None:
        resolved_key = api_key or os.environ.get("AT_API_KEY")
        if not resolved_key:
            raise AgentToolError(
                "No API key provided.",
                hint="Pass api_key= or set the AT_API_KEY environment variable.",
            )

        self._http = httpx.Client(
            headers={
                "Authorization": f"Bearer {resolved_key}",
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )
        self._base_url = base_url.rstrip("/")
        self._memory: Optional[MemoryClient] = None
        self._tools: Optional[ToolsClient] = None
        self._traces: Optional[TracesClient] = None

    @property
    def memory(self) -> MemoryClient:
        """Access the Memory API."""
        if self._memory is None:
            self._memory = MemoryClient(self._http, self._base_url)
        return self._memory

    @property
    def tools(self) -> ToolsClient:
        """Access the Tools API."""
        if self._tools is None:
            self._tools = ToolsClient(self._http, self._base_url)
        return self._tools

    @property
    def traces(self) -> TracesClient:
        """Access the Traces (reasoning provenance) API."""
        if self._traces is None:
            self._traces = TracesClient(self._http, self._base_url)
        return self._traces

    def close(self) -> None:
        """Close the underlying HTTP connection."""
        self._http.close()

    def __enter__(self) -> AgentTool:
        return self

    def __exit__(self, *args: object) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"AgentTool(base_url={self._base_url!r})"
