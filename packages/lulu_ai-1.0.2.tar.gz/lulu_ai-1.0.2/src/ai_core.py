from __future__ import annotations

import io
import time
import functools
import google.generativeai as genai
from PIL import Image
from typing import Optional, Any, List
import threading
import config
from logger_setup import logger
from openrouter_client import generate_code_from_openrouter, OpenRouterError
from groq_client import chat_with_groq, explain_code_with_groq, GroqError

# ---------------------------------------------------------------------------
# Gemini model cache + narrow lock
# ---------------------------------------------------------------------------

_gemini_lock: threading.Lock = threading.Lock()
_model_cache: dict[str, genai.GenerativeModel] = {}


def _get_model(api_key: str) -> genai.GenerativeModel:
    """Return a cached GenerativeModel for *api_key*, creating it if needed."""
    if api_key in _model_cache:
        return _model_cache[api_key]
    with _gemini_lock:
        if api_key not in _model_cache:
            genai.configure(api_key=api_key)
            _model_cache[api_key] = genai.GenerativeModel(config.MODEL_NAME)
    return _model_cache[api_key]


# ---------------------------------------------------------------------------
# Custom exceptions
# ---------------------------------------------------------------------------

class AIProviderError(Exception):
    """Base exception for all AI-provider failures."""


class GeminiError(AIProviderError):
    """Raised specifically for Google Gemini API failures."""


# Keep AIError as a backward-compatible alias so existing callers don't break.
AIError = AIProviderError


# ---------------------------------------------------------------------------
# Retry with exponential backoff
# ---------------------------------------------------------------------------

# Maximum number of retry attempts on a rate-limit (429) response.
_MAX_RETRIES = 3

# Base delay in seconds — doubles on each attempt: 1s, 2s, 4s.
_BASE_DELAY = 1.0


def _with_backoff(fn, *args, provider: str = "API", **kwargs):
    """Call *fn(*args, **kwargs)* retrying up to _MAX_RETRIES times on 429s.

    Non-rate-limit errors are re-raised immediately without retrying.

    Parameters
    ----------
    fn:
        The callable to invoke (e.g. model.generate_content).
    *args / **kwargs:
        Forwarded verbatim to *fn*.
    provider:
        Human-readable name used in log messages (e.g. "Gemini", "Groq").

    Returns
    -------
    Whatever *fn* returns on success.

    Raises
    ------
    The last exception if all retries are exhausted.
    """
    last_error: Exception | None = None

    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as exc:
            last_error = exc

            if not _is_rate_limit_error(exc):
                # Not a rate-limit error — don't waste time retrying
                raise

            if attempt == _MAX_RETRIES:
                logger.error(
                    f"❌ {provider} rate limit hit. "
                    f"All {_MAX_RETRIES} retry attempts exhausted."
                )
                raise

            wait = _BASE_DELAY * (2 ** (attempt - 1))   # 1s, 2s, 4s
            logger.warning(
                f"⚠️ {provider} rate limit hit (attempt {attempt}/{_MAX_RETRIES}). "
                f"Retrying in {wait:.0f}s..."
            )
            time.sleep(wait)

    # Should never reach here, but satisfies type checkers
    if last_error:
        raise last_error


# ---------------------------------------------------------------------------
# Private helpers
# ---------------------------------------------------------------------------

def _get_configured_api_keys() -> List[str]:
    keys = []
    primary_key = (config.API_KEY or "").strip()
    secondary_key = (getattr(config, "API_KEY_SECONDARY", "") or "").strip()

    if primary_key:
        keys.append(primary_key)
    if secondary_key and secondary_key not in keys:
        keys.append(secondary_key)

    return keys


def _get_gemini_client() -> genai.GenerativeModel:
    """Return a configured Gemini GenerativeModel using the first available API key."""
    api_keys = _get_configured_api_keys()
    if not api_keys:
        raise GeminiError("No Gemini API key configured")
    return _get_model(api_keys[0])


def _is_rate_limit_error(error: Exception) -> bool:
    error_message = str(error).lower()
    rate_limit_markers = [
        "429",
        "rate limit",
        "too many requests",
        "quota",
        "resource_exhausted",
        "limit exceeded",
        "quota exceeded",
    ]
    return any(marker in error_message for marker in rate_limit_markers)


def _mask_key(key: str) -> str:
    """Return a partially masked key for safe logging, e.g. 'AIza...k0Ok'."""
    if len(key) <= 8:
        return "****"
    return key[:4] + "..." + key[-4:]


# ---------------------------------------------------------------------------
# Core Gemini generation helper
# ---------------------------------------------------------------------------

def generate_content_with_fallback(content: Any):
    """Call Gemini with per-key retry + fallback to secondary key.

    For each API key the call is wrapped in _with_backoff so a transient
    429 is retried (up to _MAX_RETRIES times) before falling over to the
    next key. A persistent rate-limit on all keys raises the last error.
    """
    api_keys = _get_configured_api_keys()
    if not api_keys:
        raise ValueError("No Gemini API key configured")

    last_error = None

    for idx, api_key in enumerate(api_keys):
        try:
            model = _get_model(api_key)

            # Wrap the actual network call in backoff retry
            result = _with_backoff(
                model.generate_content,
                content,
                provider=f"Gemini key {idx + 1}",
            )

            label = "primary" if idx == 0 else "secondary"
            logger.info(f"✅ Gemini response via {label} key [{_mask_key(api_key)}]")
            return result

        except Exception as error:
            last_error = error
            is_last_key = idx == len(api_keys) - 1

            if not is_last_key:
                if _is_rate_limit_error(error):
                    logger.warning(
                        f"⚠️ API key {idx + 1} exhausted all retries on rate limit. "
                        f"Switching to backup key..."
                    )
                else:
                    logger.warning(
                        f"⚠️ API key {idx + 1} failed ({type(error).__name__}). "
                        f"Switching to backup key..."
                    )
                continue

            raise

    if last_error:
        raise last_error

    raise RuntimeError("Failed to generate content with Gemini")


# ---------------------------------------------------------------------------
# Provider-agnostic public API
# ---------------------------------------------------------------------------

def solve_mcq_with_vision(
    question_image: bytes,
    options_images: list[bytes],
    context_image: bytes | None = None,
) -> int:
    """Solve a multiple-choice question from raw image bytes."""
    try:
        num_options = len(options_images)
        question_img = Image.open(io.BytesIO(question_image))
        option_imgs = [Image.open(io.BytesIO(b)) for b in options_images]

        context_note = "The first image provides context/passage for the question. " if context_image else ""
        prompt = (
            f"{context_note}"
            "Analyze the multiple-choice question carefully. "
            f"There are {num_options} answer options provided as separate images after the question. "
            f"Your task is to return ONLY the index number (1, 2, ..., {num_options}) "
            "corresponding to the correct option. "
            "Output format: Just the integer number. No text, no explanation, no punctuation."
        )

        parts: list = [prompt]
        if context_image:
            parts.append(Image.open(io.BytesIO(context_image)))
        parts.append(question_img)
        parts.extend(option_imgs)

        response = generate_content_with_fallback(parts)
        answer_text = response.text.strip()
        logger.info(f"🤖 Gemini says: {answer_text}")

        index = int(answer_text)
        if 1 <= index <= num_options:
            return index
        raise GeminiError(f"Option index {index} out of range [1, {num_options}]")

    except GeminiError:
        raise
    except Exception as exc:
        raise GeminiError(f"solve_mcq_with_vision failed: {exc}") from exc


def generate_code_answer(prompt: str) -> str:
    """Generate a coding answer for *prompt*.

    Routing order:
    1. Groq  — primary, with backoff retry on 429.
    2. OpenRouter — secondary, with backoff retry on 429.
    3. Gemini — final fallback.
    """
    logger.info(f"generate_code_answer: GROQ_API_KEY set={bool(config.GROQ_API_KEY)}, USE_GROQ_FOR_CODE={config.USE_GROQ_FOR_CODE}")

    # --- 1. Groq (primary) ---
    if config.USE_GROQ_FOR_CODE and config.GROQ_API_KEY:
        try:
            logger.info("🔀 Routing code generation to Groq")
            return _with_backoff(
                chat_with_groq,
                prompt,
                model=config.GROQ_DEFAULT_MODEL,
                provider="Groq",
            )
        except GroqError as exc:
            logger.warning(f"⚠️ Groq failed for code generation, falling through to OpenRouter: {exc}")

    # --- 2. OpenRouter (secondary) ---
    if config.USE_OPENROUTER_FOR_CODE and config.OPENROUTER_API_KEY:
        try:
            logger.info("🔀 Routing code generation to OpenRouter")
            return _with_backoff(
                generate_code_from_openrouter,
                prompt,
                provider="OpenRouter",
            )
        except OpenRouterError as exc:
            raise AIProviderError(f"generate_code_answer (OpenRouter) failed: {exc}") from exc

    # --- 3. Gemini fallback ---
    try:
        response = generate_content_with_fallback([prompt])
        return response.text
    except Exception as exc:
        raise GeminiError(f"generate_code_answer failed: {exc}") from exc


def generate_theory_answer(prompt: str) -> str:
    """Generate a theory / essay answer for *prompt*.

    Routes to Groq (with backoff retry) when configured; falls back to Gemini.
    """
    if config.USE_GROQ_FOR_EXPLANATION and config.GROQ_API_KEY:
        try:
            logger.info("🔀 Routing theory answer to Groq")
            return _with_backoff(
                chat_with_groq,
                prompt,
                model=config.GROQ_DEFAULT_MODEL,
                provider="Groq",
            )
        except GroqError as exc:
            raise AIProviderError(f"generate_theory_answer (Groq) failed: {exc}") from exc

    # Gemini fallback
    try:
        response = generate_content_with_fallback([prompt])
        return response.text
    except Exception as exc:
        raise GeminiError(f"generate_theory_answer failed: {exc}") from exc


def explain_code(code: str, extra_context: str | None = None) -> str:
    """Return a natural-language explanation of *code*.

    Routes to Groq (with backoff retry) when configured; falls back to Gemini.
    """
    if config.USE_GROQ_FOR_EXPLANATION and config.GROQ_API_KEY:
        try:
            logger.info("🔀 Routing code explanation to Groq")
            return _with_backoff(
                explain_code_with_groq,
                code,
                extra_context=extra_context,
                provider="Groq",
            )
        except GroqError as exc:
            raise AIProviderError(f"explain_code (Groq) failed: {exc}") from exc

    # Gemini fallback
    try:
        full_prompt = f"Explain the following code:\n\n{code}"
        if extra_context:
            full_prompt += f"\n\nAdditional context:\n{extra_context}"
        response = generate_content_with_fallback([full_prompt])
        return response.text
    except Exception as exc:
        raise GeminiError(f"explain_code failed: {exc}") from exc


# ---------------------------------------------------------------------------
# Legacy path-based helpers (kept for backward compatibility)
# ---------------------------------------------------------------------------

def get_correct_option_index(image_path: str, num_options: int = 4) -> Optional[int]:
    """Single-image mode — for standalone MCQs."""
    try:
        image = Image.open(image_path)
        prompt = (
            f"Analyze the multiple-choice question in the image carefully.\n"
            f"There are {num_options} options listed.\n"
            "Identify the correct answer based on your knowledge.\n"
            f"Your task is to return ONLY the index number (1, 2, ..., {num_options}) "
            "corresponding to the correct option.\n"
            "Output format: Just the integer number. No text, no explanation, no punctuation."
        )
        response = generate_content_with_fallback([prompt, image])
        answer_text = response.text.strip()
        logger.info(f"🤖 Gemini says: {answer_text}")

        index = int(answer_text)
        if 1 <= index <= num_options:
            return index
        logger.error(f"❌ Invalid option index: {index}")
        return None
    except Exception as e:
        logger.error(f"❌ Invalid response from Gemini: {e}")
        return None


def get_correct_option_index_with_context(
    context_image_path: str,
    question_image_path: str,
    num_options: int = 4,
) -> Optional[int]:
    """Two-image mode — for comprehension-based MCQs."""
    try:
        context_img = Image.open(context_image_path)
        question_img = Image.open(question_image_path)

        prompt = (
            "Analyze the provided context (first image) and the multiple-choice question "
            "(second image) carefully.\n"
            f"There are {num_options} options listed in the question image.\n"
            "Identify the correct answer based on the context provided.\n"
            f"Your task is to return ONLY the index number (1, 2, ..., {num_options}) "
            "corresponding to the correct option.\n"
            "Output format: Just the integer number. No text, no explanation, no punctuation."
        )

        response = generate_content_with_fallback([prompt, context_img, question_img])
        answer_text = response.text.strip()
        logger.info(f"🤖 Gemini says: {answer_text}")

        index = int(answer_text)
        if 1 <= index <= num_options:
            return index
        logger.error(f"❌ Invalid option index: {index}")
        return None
    except Exception as e:
        logger.error(f"❌ Invalid response from Gemini: {e}")
        return None