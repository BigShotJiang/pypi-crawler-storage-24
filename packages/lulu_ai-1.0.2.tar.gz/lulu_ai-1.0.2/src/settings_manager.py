import copy
import json
import os
import sys
import tempfile
import shutil

# Determine the base path for the application
if getattr(sys, 'frozen', False):
    # If running as a compiled exe
    BASE_DIR = os.path.dirname(sys.executable)
else:
    # If running as a script, use the parent directory of src/
    BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

SETTINGS_FILE = os.path.join(BASE_DIR, "settings.json")
SETTINGS_BACKUP_FILE = os.path.join(BASE_DIR, "settings.backup.json")

DEFAULT_SETTINGS = {
    "api_key": "",
    "api_key_secondary": "",
    "model_name": "gemini-2.5-flash",
    "hotkeys": {
        "capture_context": "<ctrl>+<alt>+c",
        "capture_question": "<ctrl>+<alt>+p",
        "clear_context": "<ctrl>+<alt>+r",
        "exit": "<ctrl>+<alt>+e",
        "capture_subjective": "<ctrl>+<alt>+s",
        "generate_response": "<ctrl>+<alt>+g",
        "type_response": "<ctrl>+<alt>+t",
        "resume_typing": "<ctrl>+<alt>+z",
        "retry_subjective": "<ctrl>+<alt>+k",
        "toggle_notes": "<ctrl>+<alt>+n",
        "toggle_explanation": "<ctrl>+<alt>+a",
        "explain_code": "<ctrl>+<alt>+j",
        "control_panel": "<ctrl>+<alt>+m",
        "step_by_step_solution": "<ctrl>+<alt>+o",
        "move_notes_up": "<ctrl>+<alt>+<up>",
        "move_notes_down": "<ctrl>+<alt>+<down>",
        "move_notes_left": "<ctrl>+<alt>+<left>",
        "move_notes_right": "<ctrl>+<alt>+<right>"
    },
    "features": {
        "notes_enabled": True,
        "explanation_enabled": True
    },
    "typing": {
        "min_delay": 0.03,
        "max_delay": 0.08
    },
    "window_size": {
        "notes_width": 400,
        "notes_height": 300,
        "explanation_width": 500,
        "explanation_height": 400
    }
}


# ---------------------------------------------------------------------------
# Load
# ---------------------------------------------------------------------------

def load_settings() -> dict:
    """Load settings from disk, falling back to backup then defaults on corruption."""

    # Try primary settings file first
    settings = _try_load_file(SETTINGS_FILE)

    # Primary corrupted or missing — try backup
    if settings is None and os.path.exists(SETTINGS_BACKUP_FILE):
        print("⚠️ settings.json unreadable — attempting backup restore...")
        settings = _try_load_file(SETTINGS_BACKUP_FILE)
        if settings is not None:
            print("✅ Settings restored from backup.")
            # Restore the primary from backup immediately
            save_settings(settings)

    # Both gone or corrupted — start from defaults
    if settings is None:
        print("⚠️ No valid settings found. Starting with defaults.")
        settings = copy.deepcopy(DEFAULT_SETTINGS)
        save_settings(settings)
        return settings

    # Merge loaded settings with defaults so new keys always exist
    merged = copy.deepcopy(DEFAULT_SETTINGS)
    for key, value in settings.items():
        if isinstance(value, dict) and key in merged and isinstance(merged[key], dict):
            merged[key].update(value)
        else:
            merged[key] = value

    return merged


def _try_load_file(path: str) -> dict | None:
    """Try to parse *path* as JSON. Returns the dict on success, None on any failure."""
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, dict):
            return None
        return data
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Save — atomic write so a crash mid-save never corrupts the file
# ---------------------------------------------------------------------------

def save_settings(settings: dict) -> None:
    """Write *settings* to disk atomically.

    Strategy:
    1. Write to a temp file in the same directory (guarantees same filesystem,
       so shutil.move() is an atomic rename on all major OSes).
    2. If a valid primary file already exists, copy it to a backup first.
    3. Atomically replace the primary with the temp file.

    A crash at any point leaves either the old primary or the temp file on
    disk — the primary is never left in a half-written state.
    """
    try:
        dir_name = os.path.dirname(SETTINGS_FILE) or "."

        # Step 1 — write to temp file in same directory
        fd, tmp_path = tempfile.mkstemp(dir=dir_name, suffix=".tmp", prefix="settings_")
        try:
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                json.dump(settings, f, indent=4)
        except Exception:
            os.unlink(tmp_path)
            raise

        # Step 2 — back up current primary if it is valid JSON
        if os.path.exists(SETTINGS_FILE) and _try_load_file(SETTINGS_FILE) is not None:
            shutil.copy2(SETTINGS_FILE, SETTINGS_BACKUP_FILE)

        # Step 3 — atomic replace (rename is atomic on NTFS and ext4)
        shutil.move(tmp_path, SETTINGS_FILE)

    except Exception as e:
        print(f"Error saving settings: {e}")


# ---------------------------------------------------------------------------
# Global settings instance + helpers
# ---------------------------------------------------------------------------

# Loaded once at import time — all hotkey callbacks use this directly
# (no repeated disk reads needed, see main.py)
current_settings = load_settings()


def get_setting(key, default=None):
    return current_settings.get(key, default)


def update_setting(key, value):
    current_settings[key] = value
    save_settings(current_settings)