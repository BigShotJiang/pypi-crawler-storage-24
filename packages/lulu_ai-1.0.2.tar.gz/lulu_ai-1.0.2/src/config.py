import os
import sys
from dotenv import load_dotenv
from settings_manager import current_settings

# Load .env from the project root (one level above src/)
_ENV_PATH = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '.env'))
load_dotenv(dotenv_path=_ENV_PATH)

# Determine the base path for the application
if getattr(sys, 'frozen', False):  # If running as a compiled exe
    BASE_DIR = os.path.dirname(sys.executable)
else:  # If running as a script, use the parent directory of src/
    BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# --- CORE CONFIG ---
# Gemini key resolution priority:
# 1) .env GEMINI_API_KEY_PRIMARY
# 2) .env GEMINI_API_KEY (legacy)
# 3) settings.json api_key
API_KEY = (
    os.environ.get("GEMINI_API_KEY_PRIMARY", "").strip()
    or os.environ.get("GEMINI_API_KEY", "").strip()
    or current_settings.get("api_key", "").strip()
)

# Secondary Gemini key for automatic failover:
# 1) .env GEMINI_API_KEY_SECONDARY
# 2) settings.json api_key_secondary
API_KEY_SECONDARY = (
    os.environ.get("GEMINI_API_KEY_SECONDARY", "").strip()
    or current_settings.get("api_key_secondary", "").strip()
)
MODEL_NAME = current_settings.get("model_name", "gemini-2.5-flash")

SCREENSHOT_DIR = os.path.join(BASE_DIR, "screenshots")
os.makedirs(SCREENSHOT_DIR, exist_ok=True)

# New: For coding/subjective mode
SUBJECTIVE_SCREENSHOT_DIR = os.path.join(SCREENSHOT_DIR, "subjective")
os.makedirs(SUBJECTIVE_SCREENSHOT_DIR, exist_ok=True)

# Paths for MCQ images (question + optional context)
QUESTION_IMAGE_NAME = "question.png"
CONTEXT_IMAGE_NAME = "context.png"
QUESTION_IMAGE_PATH = os.path.join(SCREENSHOT_DIR, QUESTION_IMAGE_NAME)
CONTEXT_IMAGE_PATH = os.path.join(SCREENSHOT_DIR, CONTEXT_IMAGE_NAME)

# Hotkeys
CAPTURE_CONTEXT_HOTKEY = current_settings["hotkeys"]["capture_context"]
CAPTURE_QUESTION_HOTKEY = current_settings["hotkeys"]["capture_question"]
CLEAR_CONTEXT_HOTKEY = current_settings["hotkeys"]["clear_context"]
EXIT_HOTKEY = current_settings["hotkeys"]["exit"]

# NEW HOTKEYS
CAPTURE_SUBJECTIVE_HOTKEY = current_settings["hotkeys"]["capture_subjective"]
GENERATE_RESPONSE_HOTKEY = current_settings["hotkeys"]["generate_response"]
TYPE_RESPONSE_HOTKEY = current_settings["hotkeys"]["type_response"]
RESUME_TYPING_HOTKEY = current_settings["hotkeys"]["resume_typing"]
RETRY_SUBJECTIVE_HOTKEY = current_settings["hotkeys"]["retry_subjective"]
TOGGLE_NOTES_HOTKEY = current_settings["hotkeys"]["toggle_notes"]
TOGGLE_EXPLANATION_HOTKEY = current_settings["hotkeys"]["toggle_explanation"]
CONTROL_PANEL_HOTKEY = current_settings["hotkeys"]["control_panel"]
STEP_BY_STEP_SOLUTION_HOTKEY = current_settings["hotkeys"]["step_by_step_solution"]
EXPLAIN_CODE_HOTKEY = current_settings["hotkeys"]["explain_code"]
MOVE_NOTES_UP_HOTKEY = current_settings["hotkeys"].get("move_notes_up", "<ctrl>+<alt>+<up>")
MOVE_NOTES_DOWN_HOTKEY = current_settings["hotkeys"].get("move_notes_down", "<ctrl>+<alt>+<down>")
MOVE_NOTES_LEFT_HOTKEY = current_settings["hotkeys"].get("move_notes_left", "<ctrl>+<alt>+<left>")
MOVE_NOTES_RIGHT_HOTKEY = current_settings["hotkeys"].get("move_notes_right", "<ctrl>+<alt>+<right>")

# Typing Configuration
TYPING_DELAY_MIN = current_settings.get("typing", {}).get("min_delay", 0.03)
TYPING_DELAY_MAX = current_settings.get("typing", {}).get("max_delay", 0.08)
NOTES_FILE = "hidden_notes.txt"

# ----------------------------------------------------------------------------
# OpenRouter (second AI provider for coding / SQL tasks)
# ----------------------------------------------------------------------------
OPENROUTER_API_KEY: str = os.environ.get("OPENROUTER_API_KEY", "")
OPENROUTER_BASE_URL: str = "https://openrouter.ai/api/v1"

# Set to True to route generate_code_answer() through OpenRouter when a key is available
USE_OPENROUTER_FOR_CODE: bool = True

# Primary coding model — overridable via OPENROUTER_CODE_MODEL env var
OPENROUTER_CODE_MODEL: str = os.environ.get("OPENROUTER_CODE_MODEL", "meta-llama/llama-3.3-70b-instruct:free")

# Fallback models if primary fails (all confirmed free)
OPENROUTER_CODE_FALLBACKS: list[str] = [
    "mistralai/devstral-2512:free",  # Mistral Devstral 2
    "xiaomi/mimo-v2-flash-309b:free"  # #1 open-source on SWE-Bench
]

# ----------------------------------------------------------------------------
# Groq (third AI provider for text-only reasoning: explanations, theory)
# ----------------------------------------------------------------------------
GROQ_API_KEY: str = os.environ.get("GROQ_API_KEY", "")
GROQ_BASE_URL: str = "https://api.groq.com/openai/v1"

# Set to True to route explain_code() and generate_theory_answer() through Groq
USE_GROQ_FOR_EXPLANATION: bool = True

# Set to True to attempt Groq first for generate_code_answer() (before OpenRouter)
USE_GROQ_FOR_CODE: bool = os.environ.get("USE_GROQ_FOR_CODE", "true").lower() == "true"

# ✅ Confirmed working Groq model ID
GROQ_DEFAULT_MODEL: str = "llama-3.3-70b-versatile"  # Meta Llama 3.3 70B - excellent for explanations

# Optional fallback Groq model for deeper reasoning
GROQ_EXPLANATION_FALLBACK: str = "deepseek-r1-distill-llama-70b"
