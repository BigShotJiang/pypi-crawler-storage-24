import threading
import os
import time
import sys
from pynput import keyboard
from pynput.keyboard import Controller as KeyboardController
import config
import state
from logger_setup import logger
from mcq_handlers import capture_context, solve_current_mcq
from subjective_handlers import capture_subjective_screenshot, generate_ai_response, retry_ai_response, generate_code_explanation, generate_step_by_step_response
from typing_handler import auto_type_response
import hidden_notes
import explanation_window
import settings_panel
import settings_manager
from settings_manager import current_settings

# ── Thread-safe debounce for control panel hotkey ─────────────────────────────
_panel_open_lock      = threading.Lock()
_last_panel_open_time = 0.0


# ---------------------------------------------------------------------------
# Startup config validation
# ---------------------------------------------------------------------------

def _validate_config() -> bool:
    """Check all required configuration is present before starting the app.

    Logs a clear error for every missing/invalid value and returns False if
    anything critical is absent so run_app() can exit early instead of
    starting up silently broken.

    Returns
    -------
    bool
        True if config is valid enough to run, False if critical keys are missing.
    """
    errors = []
    warnings = []

    # --- Critical: at least one Gemini key must be set ---
    if not config.API_KEY:
        errors.append(
            "GEMINI_API_KEY (or GEMINI_API_KEY_PRIMARY) is not set in .env — "
            "MCQ solving and subjective question answering will not work."
        )

    # --- Warnings: optional providers ---
    if not config.GROQ_API_KEY:
        warnings.append(
            "GROQ_API_KEY is not set — theory answers and code explanations "
            "will fall back to Gemini instead of Groq."
        )

    if not config.OPENROUTER_API_KEY:
        warnings.append(
            "OPENROUTER_API_KEY is not set — code generation will fall back "
            "to Gemini instead of OpenRouter."
        )

    # --- Warning: secondary Gemini key missing (no failover) ---
    if config.API_KEY and not config.API_KEY_SECONDARY:
        warnings.append(
            "GEMINI_API_KEY_SECONDARY is not set — no automatic failover if "
            "the primary key hits its rate limit."
        )

    # --- Log everything ---
    for w in warnings:
        logger.warning(f"⚠️  Config warning: {w}")

    for e in errors:
        logger.error(f"❌ Config error: {e}")

    if errors:
        logger.error(
            "❌ Critical configuration missing. "
            "Please set the required keys in your .env file and restart."
        )
        return False

    logger.info("✅ Config validation passed.")
    return True


# ---------------------------------------------------------------------------
# Hotkey callbacks
# ---------------------------------------------------------------------------

def on_activate_context() -> None:
    """Triggered by Ctrl+Alt+C"""
    logger.info("[📖 CONTEXT CAPTURE HOTKEY PRESSED!]")
    threading.Thread(target=capture_context).start()

def on_activate_question() -> None:
    """Triggered by Ctrl+Alt+P"""
    logger.info("[❓ QUESTION CAPTURE HOTKEY PRESSED!]")
    threading.Thread(target=solve_current_mcq).start()

def on_capture_subjective() -> None:
    """Triggered by Ctrl+Alt+S"""
    logger.info("[🖼️  SUBJECTIVE CAPTURE HOTKEY PRESSED!]")
    threading.Thread(target=capture_subjective_screenshot).start()

def on_generate_response() -> None:
    """Triggered by Ctrl+Alt+G"""
    logger.info("[🧠 GENERATE RESPONSE HOTKEY PRESSED!]")
    threading.Thread(target=generate_ai_response, daemon=True).start()

def on_type_response() -> None:
    """Triggered by Ctrl+Alt+T"""
    logger.info("[⌨️  TYPE RESPONSE HOTKEY PRESSED!]")
    threading.Thread(target=auto_type_response).start()

def on_retry_subjective() -> None:
    """Triggered by Ctrl+Alt+K"""
    logger.info("[🔄 RETRY HOTKEY PRESSED!]")
    threading.Thread(target=retry_ai_response, daemon=True).start()

def on_toggle_notes() -> None:
    """Triggered by Ctrl+Alt+N"""
    if not current_settings['features']['notes_enabled']:
        logger.info("🚫 Notes feature is disabled in settings.")
        return
    logger.info("[📝 TOGGLE NOTES HOTKEY PRESSED!]")
    hidden_notes.toggle_notes()

def on_explain_code() -> None:
    """Triggered by Ctrl+Alt+J"""
    if not current_settings['features']['explanation_enabled']:
        logger.info("🚫 Explanation feature is disabled in settings.")
        return
    logger.info("[🧠 EXPLAIN CODE HOTKEY PRESSED!]")
    threading.Thread(target=generate_code_explanation, daemon=True).start()

def on_toggle_explanation() -> None:
    """Triggered by Ctrl+Alt+A"""
    if not current_settings['features']['explanation_enabled']:
        logger.info("🚫 Explanation feature is disabled in settings.")
        return
    logger.info("[📝 TOGGLE EXPLANATION HOTKEY PRESSED!]")
    explanation_window.toggle_explanation()

def on_open_control_panel() -> None:
    """Triggered by Ctrl+Alt+M"""
    global _last_panel_open_time

    with _panel_open_lock:
        now = time.time()
        if now - _last_panel_open_time < 0.6:
            logger.debug("⚙️ Control panel hotkey debounced (duplicate fire ignored).")
            return
        _last_panel_open_time = now

    logger.info("[⚙️ CONTROL PANEL HOTKEY PRESSED!]")

    if hidden_notes.notes_app and hidden_notes.notes_app.root:
        hidden_notes.notes_app.root.after(
            0,
            lambda: settings_panel.show_control_panel(
                restart_callback=restart_program,
                master=hidden_notes.notes_app.root
            )
        )
    else:
        logger.error("❌ Cannot open control panel: Main application window not found.")

def restart_program() -> None:
    """Restarts the current program."""
    logger.info("🔄 Restarting application...")
    python = sys.executable
    os.execl(python, python, *sys.argv)

def on_move_notes_up() -> None:
    hidden_notes.move_notes(0, -20)
    explanation_window.move_explanation(0, -20)

def on_move_notes_down() -> None:
    hidden_notes.move_notes(0, 20)
    explanation_window.move_explanation(0, 20)

def on_move_notes_left() -> None:
    hidden_notes.move_notes(-20, 0)
    explanation_window.move_explanation(-20, 0)

def on_move_notes_right() -> None:
    hidden_notes.move_notes(20, 0)
    explanation_window.move_explanation(20, 0)

def on_resume_typing() -> None:
    """Triggered by Ctrl+Alt+Z to resume paused typing"""
    if state.is_typing_paused and state.is_typing_active:
        keyboard_controller = KeyboardController()
        keyboard_controller.release(keyboard.Key.ctrl)
        keyboard_controller.release(keyboard.Key.alt)
        keyboard_controller.release(keyboard.Key.shift)
        time.sleep(0.1)

        state.resume_typing_event.set()
        logger.info(f"⏯️ Resume hotkey pressed. Resuming typing from position {state.current_typing_position}...")
        time.sleep(0.2)
    elif not state.is_typing_active:
        logger.info("⏯️ No active typing session to resume.")
    else:
        logger.info("⏯️ Typing is not currently paused.")

def on_clear_context() -> None:
    """
    Enhanced: Also clears subjective mode.
    Clears the captured context.
    Triggered by Ctrl+Alt+R.
    """
    state.context_captured = False
    state.subjective_screenshots = []
    state.reset_subjective_caches()
    if os.path.exists(config.SUBJECTIVE_SCREENSHOT_DIR):
        for file in os.listdir(config.SUBJECTIVE_SCREENSHOT_DIR):
            try:
                os.remove(os.path.join(config.SUBJECTIVE_SCREENSHOT_DIR, file))
            except Exception as e:
                logger.error(f"Failed to delete {file}: {e}")
    logger.info("🧹 Context & subjective mode cleared.")

def on_exit() -> None:
    """Triggered by Ctrl+Alt+E"""
    logger.info("🛑 Exiting...")
    os._exit(0)

def on_step_by_step_solution() -> None:
    """Triggered by Ctrl+Alt+O"""
    logger.info("[🧠 STEP-BY-STEP SOLUTION HOTKEY PRESSED!]")
    threading.Thread(target=generate_step_by_step_response, daemon=True).start()


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run_app():
    # --- Validate config before doing anything else ---
    if not _validate_config():
        logger.error("🛑 Startup aborted due to missing configuration.")
        logger.error("   Open your .env file, add the missing keys, and restart.")
        sys.exit(1)

    logger.info("✅ Advanced AI Assistant Ready!")
    logger.info(f"📖 Press {config.CAPTURE_CONTEXT_HOTKEY.upper()} to capture context (for MCQs)")
    logger.info(f"❓ Press {config.CAPTURE_QUESTION_HOTKEY.upper()} to capture question (for MCQs)")
    logger.info(f"🖼️  Press {config.CAPTURE_SUBJECTIVE_HOTKEY.upper()} to capture screenshot (for coding)")
    logger.info(f"🧠 Press {config.GENERATE_RESPONSE_HOTKEY.upper()} to generate AI response")
    logger.info(f"⌨️  Press {config.TYPE_RESPONSE_HOTKEY.upper()} to auto-type response")
    logger.info(f"⏯️  Press {config.RESUME_TYPING_HOTKEY.upper()} to resume typing after pause")
    logger.info(f"🔄 Press {config.RETRY_SUBJECTIVE_HOTKEY.upper()} to retry AI with error screenshot")
    logger.info(f"📝 Press {config.TOGGLE_NOTES_HOTKEY.upper()} to toggle hidden notes")
    logger.info(f"⚙️ Press {config.CONTROL_PANEL_HOTKEY.upper()} to open control panel")
    logger.info(f"🧹 Press {config.CLEAR_CONTEXT_HOTKEY.upper()} to clear everything")
    logger.info(f"🚪 Press {config.EXIT_HOTKEY.upper()} to quit")
    logger.info("⚠️ IMPORTANT: During auto-typing, DO NOT TYPE OR CLICK (click will pause typing)")

    # Initialize the Notes App (GUI)
    app = hidden_notes.HiddenNotesWindow()
    hidden_notes.notes_app = app

    # Initialize Explanation App (GUI) as a child of Notes App
    exp_app = explanation_window.ExplanationWindow(master=app.root)
    explanation_window.explanation_app = exp_app

    # Check for hotkey conflicts
    if config.CONTROL_PANEL_HOTKEY == config.TOGGLE_NOTES_HOTKEY:
        logger.warning(
            f"⚠️ Conflict detected: Control Panel and Toggle Notes share the same hotkey "
            f"({config.CONTROL_PANEL_HOTKEY}). Resetting Control Panel to <ctrl>+<alt>+m"
        )
        config.CONTROL_PANEL_HOTKEY = "<ctrl>+<alt>+m"

    # Start hotkeys in a non-blocking way
    h = keyboard.GlobalHotKeys({
        config.CAPTURE_CONTEXT_HOTKEY:        on_activate_context,
        config.CAPTURE_QUESTION_HOTKEY:       on_activate_question,
        config.CAPTURE_SUBJECTIVE_HOTKEY:     on_capture_subjective,
        config.GENERATE_RESPONSE_HOTKEY:      on_generate_response,
        config.TYPE_RESPONSE_HOTKEY:          on_type_response,
        config.RESUME_TYPING_HOTKEY:          on_resume_typing,
        config.RETRY_SUBJECTIVE_HOTKEY:       on_retry_subjective,
        config.TOGGLE_NOTES_HOTKEY:           on_toggle_notes,
        config.EXPLAIN_CODE_HOTKEY:           on_explain_code,
        config.TOGGLE_EXPLANATION_HOTKEY:     on_toggle_explanation,
        config.STEP_BY_STEP_SOLUTION_HOTKEY:  on_step_by_step_solution,
        config.CONTROL_PANEL_HOTKEY:          on_open_control_panel,
        config.MOVE_NOTES_UP_HOTKEY:          on_move_notes_up,
        config.MOVE_NOTES_DOWN_HOTKEY:        on_move_notes_down,
        config.MOVE_NOTES_LEFT_HOTKEY:        on_move_notes_left,
        config.MOVE_NOTES_RIGHT_HOTKEY:       on_move_notes_right,
        config.CLEAR_CONTEXT_HOTKEY:          on_clear_context,
        config.EXIT_HOTKEY:                   on_exit,
    })
    h.start()

    # Run GUI in the main thread (blocking)
    try:
        app.run()
    except KeyboardInterrupt:
        pass
    finally:
        h.stop()

if __name__ == "__main__":
    run_app()