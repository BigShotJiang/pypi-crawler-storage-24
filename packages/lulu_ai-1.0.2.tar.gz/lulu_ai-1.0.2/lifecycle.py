"""lifecycle.py — shared helpers for starting, stopping and querying the Lulu worker.

Used by both lulu_cli.py (CLI) and any future GUI launcher.
Handles:
  - Detached subprocess spawning (cross-platform)
  - PID file management
  - IPC-based status checks with PID fallback
"""
from __future__ import annotations

import json
import os
import platform
import signal
import subprocess
import sys
import time

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

APP_DATA_DIR = os.path.join(os.getenv("LOCALAPPDATA", os.path.expanduser("~")), "LuluApp")
os.makedirs(APP_DATA_DIR, exist_ok=True)

PID_FILE = os.path.join(APP_DATA_DIR, "lulu.pid")
LOG_FILE = os.path.join(APP_DATA_DIR, "logs", "app.log")

# IPC settings (must match ipc_utils.py)
IPC_HOST = "127.0.0.1"
IPC_PORT = 65432
IPC_TIMEOUT = 2  # seconds


# ---------------------------------------------------------------------------
# PID file helpers
# ---------------------------------------------------------------------------

def _write_pid(pid: int) -> None:
    with open(PID_FILE, "w") as f:
        json.dump({"pid": pid}, f)


def _read_pid() -> int | None:
    try:
        with open(PID_FILE, "r") as f:
            return json.load(f).get("pid")
    except Exception:
        return None


def _clear_pid() -> None:
    try:
        os.remove(PID_FILE)
    except FileNotFoundError:
        pass


def _pid_is_alive(pid: int) -> bool:
    """Return True if a process with *pid* is currently running."""
    try:
        if platform.system() == "Windows":
            import ctypes
            SYNCHRONIZE = 0x00100000
            handle = ctypes.windll.kernel32.OpenProcess(SYNCHRONIZE, False, pid)
            if handle:
                ctypes.windll.kernel32.CloseHandle(handle)
                return True
            return False
        else:
            os.kill(pid, 0)   # signal 0 = existence check
            return True
    except (ProcessLookupError, PermissionError, OSError):
        return False


# ---------------------------------------------------------------------------
# IPC ping helper
# ---------------------------------------------------------------------------

def _ipc_ping() -> bool:
    """Return True if the worker responds to a PING over IPC."""
    import socket, json as _json
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(IPC_TIMEOUT)
            s.connect((IPC_HOST, IPC_PORT))
            msg = json.dumps({"token": _get_token(), "command": "PING", "payload": {}})
            s.sendall(msg.encode("utf-8"))
            resp = s.recv(4096)
            data = _json.loads(resp.decode("utf-8"))
            return data.get("status") == "ok"
    except Exception:
        return False


def _get_token() -> str:
    """Read IPC token from app-data (mirrors ipc_utils.get_or_create_token logic)."""
    token_file = os.path.join(APP_DATA_DIR, "token.json")
    try:
        with open(token_file, "r") as f:
            return json.load(f).get("token", "")
    except Exception:
        return ""


# ---------------------------------------------------------------------------
# Worker entry point locator
# ---------------------------------------------------------------------------

def _find_worker_script() -> str | None:
    """Return the absolute path to src/worker.py, searching common locations."""
    candidates = [
        # Installed via pipx/pip — package data
        os.path.join(os.path.dirname(__file__), "src", "worker.py"),
        # Running from cloned repo
        os.path.join(os.path.dirname(os.path.abspath(__file__)), "src", "worker.py"),
    ]
    for path in candidates:
        if os.path.exists(path):
            return os.path.abspath(path)
    return None


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def start() -> dict:
    """Start the Lulu worker as a detached background process.

    Returns
    -------
    dict with keys:
        status  : "already_running" | "started" | "error"
        message : human-readable description
        pid     : int (only when status == "started")
    """
    # Check if already running
    if _ipc_ping():
        return {"status": "already_running", "message": "Lulu is already running."}

    pid = _read_pid()
    if pid and _pid_is_alive(pid):
        return {"status": "already_running", "message": f"Lulu is already running (PID {pid})."}

    worker = _find_worker_script()
    if not worker:
        return {
            "status": "error",
            "message": "Could not locate src/worker.py. Make sure the package is installed correctly.",
        }

    system = platform.system()

    try:
        if system == "Windows":
            # DETACHED_PROCESS + CREATE_NEW_PROCESS_GROUP keeps the worker alive
            # after the terminal is closed and gives it its own process group.
            DETACHED_PROCESS = 0x00000008
            CREATE_NEW_PROCESS_GROUP = 0x00000200
            proc = subprocess.Popen(
                [sys.executable, worker],
                creationflags=DETACHED_PROCESS | CREATE_NEW_PROCESS_GROUP,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                close_fds=True,
            )
        else:
            # macOS / Linux — start_new_session detaches from the controlling terminal
            proc = subprocess.Popen(
                [sys.executable, worker],
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                close_fds=True,
            )

        _write_pid(proc.pid)

        # Give the worker a moment to start the IPC server before returning
        for _ in range(10):
            time.sleep(0.3)
            if _ipc_ping():
                break

        return {
            "status": "started",
            "message": f"Lulu started successfully (PID {proc.pid}).",
            "pid": proc.pid,
        }

    except Exception as exc:
        return {"status": "error", "message": f"Failed to start Lulu: {exc}"}


def stop() -> dict:
    """Stop the Lulu worker gracefully via IPC, falling back to SIGTERM/kill.

    Returns
    -------
    dict with keys:
        status  : "stopped" | "not_running" | "error"
        message : human-readable description
    """
    # Try graceful IPC stop first
    if _ipc_ping():
        import socket
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.settimeout(IPC_TIMEOUT)
                s.connect((IPC_HOST, IPC_PORT))
                msg = json.dumps({"token": _get_token(), "command": "STOP", "payload": {}})
                s.sendall(msg.encode("utf-8"))
                s.recv(4096)   # read the ack
            _clear_pid()
            return {"status": "stopped", "message": "Lulu stopped gracefully."}
        except Exception:
            pass   # fall through to PID kill

    # Fallback — kill via PID file
    pid = _read_pid()
    if pid and _pid_is_alive(pid):
        try:
            if platform.system() == "Windows":
                subprocess.call(["taskkill", "/F", "/PID", str(pid)], stdout=subprocess.DEVNULL)
            else:
                os.kill(pid, signal.SIGTERM)
            _clear_pid()
            return {"status": "stopped", "message": f"Lulu process (PID {pid}) terminated."}
        except Exception as exc:
            return {"status": "error", "message": f"Could not terminate PID {pid}: {exc}"}

    _clear_pid()
    return {"status": "not_running", "message": "Lulu is not running."}


def status() -> dict:
    """Check whether the Lulu worker is running.

    Returns
    -------
    dict with keys:
        status  : "running" | "stopped"
        message : human-readable description
        pid     : int | None
    """
    pid = _read_pid()
    ipc_alive = _ipc_ping()
    pid_alive = pid is not None and _pid_is_alive(pid)

    if ipc_alive or pid_alive:
        return {
            "status": "running",
            "message": f"Lulu is running (PID {pid}).",
            "pid": pid,
        }

    # Stale PID file — clean it up
    if pid:
        _clear_pid()

    return {"status": "stopped", "message": "Lulu is not running.", "pid": None}


def tail_logs(lines: int = 50) -> str:
    """Return the last *lines* lines of the log file as a string."""
    try:
        with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
            all_lines = f.readlines()
        return "".join(all_lines[-lines:])
    except FileNotFoundError:
        return f"Log file not found at: {LOG_FILE}"
    except Exception as exc:
        return f"Error reading log file: {exc}"


def doctor() -> list[dict]:
    """Run a series of environment checks and return a list of result dicts.

    Each dict has:
        check   : str — what was checked
        status  : "ok" | "warning" | "error"
        message : str — details
    """
    results = []

    # Python version
    major, minor = sys.version_info[:2]
    if (major, minor) >= (3, 9):
        results.append({"check": "Python version", "status": "ok", "message": f"Python {major}.{minor}"})
    else:
        results.append({
            "check": "Python version", "status": "error",
            "message": f"Python {major}.{minor} — lulu-ai requires Python 3.9 or later."
        })

    # Required dependencies
    required = {
        "pynput": "pynput",
        "google.generativeai": "google-generativeai",
        "PIL": "Pillow",
        "pyautogui": "pyautogui",
        "requests": "requests",
        "dotenv": "python-dotenv",
        "customtkinter": "customtkinter",
    }
    for module, package in required.items():
        try:
            __import__(module)
            results.append({"check": f"Package: {package}", "status": "ok", "message": "Installed"})
        except ImportError:
            results.append({
                "check": f"Package: {package}", "status": "error",
                "message": f"Not installed — run: pip install {package}"
            })

    # .env / API key
    env_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".env")
    if os.path.exists(env_path):
        results.append({"check": ".env file", "status": "ok", "message": f"Found at {env_path}"})
    else:
        results.append({
            "check": ".env file", "status": "warning",
            "message": f"Not found at {env_path} — create it and add GEMINI_API_KEY."
        })

    # macOS accessibility permissions
    if platform.system() == "Darwin":
        try:
            import subprocess as sp
            result = sp.run(
                ["osascript", "-e", 'tell application "System Events" to keystroke ""'],
                capture_output=True, timeout=3
            )
            if result.returncode == 0:
                results.append({"check": "macOS Accessibility", "status": "ok", "message": "Permissions granted"})
            else:
                results.append({
                    "check": "macOS Accessibility", "status": "warning",
                    "message": "May not be granted — open System Settings → Privacy & Security → Accessibility and add Terminal/your app."
                })
        except Exception:
            results.append({"check": "macOS Accessibility", "status": "warning", "message": "Could not verify"})

    # Log directory writable
    log_dir = os.path.dirname(LOG_FILE)
    os.makedirs(log_dir, exist_ok=True)
    if os.access(log_dir, os.W_OK):
        results.append({"check": "Log directory", "status": "ok", "message": log_dir})
    else:
        results.append({"check": "Log directory", "status": "error", "message": f"Not writable: {log_dir}"})

    return results