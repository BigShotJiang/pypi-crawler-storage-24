"""lulu_cli.py — entry point for the `lulu` global command.

Commands:
    lulu start              Start the Lulu AI assistant in the background
    lulu stop               Stop the running assistant
    lulu status             Check if the assistant is running
    lulu logs               Show recent log output
    lulu logs --follow      Stream log output live
    lulu doctor             Check environment, dependencies, and permissions
    lulu --version          Show installed version
"""
from __future__ import annotations

import argparse
import importlib.metadata
import sys
import time
import os


# ---------------------------------------------------------------------------
# Version
# ---------------------------------------------------------------------------

def _get_version() -> str:
    try:
        return importlib.metadata.version("lulu-ai")
    except importlib.metadata.PackageNotFoundError:
        return "dev"


# ---------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------

GREEN  = "\033[92m"
YELLOW = "\033[93m"
RED    = "\033[91m"
CYAN   = "\033[96m"
BOLD   = "\033[1m"
RESET  = "\033[0m"

# Disable colours on Windows if ANSI isn't supported
if sys.platform == "win32":
    try:
        import ctypes
        ctypes.windll.kernel32.SetConsoleMode(
            ctypes.windll.kernel32.GetStdHandle(-11), 7
        )
    except Exception:
        GREEN = YELLOW = RED = CYAN = BOLD = RESET = ""


def _ok(msg: str) -> None:
    print(f"{GREEN}✅ {msg}{RESET}")


def _warn(msg: str) -> None:
    print(f"{YELLOW}⚠️  {msg}{RESET}")


def _err(msg: str) -> None:
    print(f"{RED}❌ {msg}{RESET}")


def _info(msg: str) -> None:
    print(f"{CYAN}ℹ️  {msg}{RESET}")


# ---------------------------------------------------------------------------
# Command implementations
# ---------------------------------------------------------------------------

def cmd_start(args) -> int:
    from lifecycle import start
    _info("Starting Lulu AI assistant...")
    result = start()

    if result["status"] == "started":
        _ok(result["message"])
        _info("You can close this terminal — Lulu will keep running in the background.")
        _info("Run  lulu status  to check, or  lulu stop  to quit.")
        return 0
    elif result["status"] == "already_running":
        _warn(result["message"])
        return 0
    else:
        _err(result["message"])
        return 1


def cmd_stop(args) -> int:
    from lifecycle import stop
    _info("Stopping Lulu AI assistant...")
    result = stop()

    if result["status"] == "stopped":
        _ok(result["message"])
        return 0
    elif result["status"] == "not_running":
        _warn(result["message"])
        return 0
    else:
        _err(result["message"])
        return 1


def cmd_status(args) -> int:
    from lifecycle import status
    result = status()

    if result["status"] == "running":
        _ok(result["message"])
    else:
        _warn(result["message"])
        _info("Run  lulu start  to launch the assistant.")

    return 0


def cmd_logs(args) -> int:
    from lifecycle import tail_logs, LOG_FILE

    if args.follow:
        _info(f"Streaming logs from {LOG_FILE}  (Ctrl+C to stop)\n")
        try:
            # Open and seek to end, then stream new lines
            with open(LOG_FILE, "r", encoding="utf-8", errors="replace") as f:
                f.seek(0, 2)   # seek to end
                while True:
                    line = f.readline()
                    if line:
                        print(line, end="")
                    else:
                        time.sleep(0.2)
        except FileNotFoundError:
            _err(f"Log file not found: {LOG_FILE}")
            _info("Start Lulu first with  lulu start")
            return 1
        except KeyboardInterrupt:
            print()
            return 0
    else:
        lines = args.lines if hasattr(args, "lines") and args.lines else 50
        output = tail_logs(lines=lines)
        print(output)
        return 0


def cmd_doctor(args) -> int:
    from lifecycle import doctor

    _info("Running diagnostics...\n")
    results = doctor()

    all_ok = True
    for r in results:
        if r["status"] == "ok":
            _ok(f"{r['check']}: {r['message']}")
        elif r["status"] == "warning":
            _warn(f"{r['check']}: {r['message']}")
            all_ok = False
        else:
            _err(f"{r['check']}: {r['message']}")
            all_ok = False

    print()
    if all_ok:
        _ok("All checks passed. Lulu is ready to run.")
    else:
        _warn("Some checks need attention. Fix the issues above, then run  lulu start")

    return 0 if all_ok else 1


# ---------------------------------------------------------------------------
# Argument parser
# ---------------------------------------------------------------------------

def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="lulu",
        description="Lulu AI Assistant — global hotkey-driven AI for MCQs and coding.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  lulu start              Start the assistant in the background
  lulu stop               Stop the assistant
  lulu status             Check if it's running
  lulu logs               Show last 50 log lines
  lulu logs --follow      Stream logs live
  lulu logs --lines 100   Show last 100 log lines
  lulu doctor             Diagnose your environment
        """,
    )

    parser.add_argument(
        "--version", "-v",
        action="version",
        version=f"lulu-ai {_get_version()}",
    )

    sub = parser.add_subparsers(dest="command", metavar="COMMAND")
    sub.required = True

    # start
    sub.add_parser("start", help="Start the Lulu assistant in the background")

    # stop
    sub.add_parser("stop", help="Stop the running assistant")

    # status
    sub.add_parser("status", help="Check if the assistant is running")

    # logs
    logs_p = sub.add_parser("logs", help="View log output")
    logs_p.add_argument(
        "--follow", "-f",
        action="store_true",
        help="Stream log output live (like tail -f)",
    )
    logs_p.add_argument(
        "--lines", "-n",
        type=int,
        default=50,
        metavar="N",
        help="Number of lines to show (default: 50)",
    )

    # doctor
    sub.add_parser("doctor", help="Check environment, dependencies, and permissions")

    return parser


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = _build_parser()
    args = parser.parse_args()

    dispatch = {
        "start":  cmd_start,
        "stop":   cmd_stop,
        "status": cmd_status,
        "logs":   cmd_logs,
        "doctor": cmd_doctor,
    }

    handler = dispatch.get(args.command)
    if handler is None:
        parser.print_help()
        sys.exit(1)

    exit_code = handler(args)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()