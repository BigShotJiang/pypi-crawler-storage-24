# 🎨 pixelart

A simple, expressive Python library for creating pixel art programmatically — inspired by the spirit of creative coding tools like Processing, but laser-focused on pixel art generation.

---

## Features

- **Canvas** class with configurable grid size and pixel scale
- **Pixel manipulation** — `set_pixel`, `get_pixel`, `fill`
- **Drawing primitives** — rectangles, lines, circles (filled or outline)
- **Flood fill** — paint connected regions
- **Palette support** — define and reuse named colors
- **PNG export** — clean pixel-perfect output at any scale
- **Built-in palettes** — `CLASSIC`, `PASTEL`, `EARTHY`
- Zero dependencies beyond **Pillow**

---

## Installation

```bash
pip install Pillow
```

Then copy the `pixelart/` folder into your project (or install via `pip install .` once packaged).

---

## Quick Start

```python
from pixelart import Canvas

canvas = Canvas(16, 16, pixel_size=20)

canvas.fill("#ffffff")
canvas.draw_rect(4, 4, 8, 8, "#ff0000")

canvas.save("output.png")
```

---

## Project Structure

```
pixelart/
├── pixelart/
│   ├── __init__.py      ← Public API surface
│   ├── canvas.py        ← Canvas class (core)
│   ├── palette.py       ← Palette + color parsing
│   └── drawing.py       ← Drawing primitives
├── examples/
│   ├── heart.py         ← Pixel heart example
│   ├── smiley.py        ← Smiley face example
│   └── sprite.py        ← RPG character sprite
├── output/              ← Generated PNG files
├── setup.py
└── README.md
```

---

## API Reference

### `Canvas(width, height, pixel_size=1, background=None)`

Create a new canvas.

| Parameter    | Type          | Description                                      |
|--------------|---------------|--------------------------------------------------|
| `width`      | `int`         | Number of pixel columns                          |
| `height`     | `int`         | Number of pixel rows                             |
| `pixel_size` | `int`         | Scale factor when saving (default `1`)           |
| `background` | `ColorLike`   | Initial fill color (default: transparent)        |

---

### Pixel Manipulation

```python
canvas.set_pixel(x, y, color)   # Set a pixel
canvas.get_pixel(x, y)          # Returns (r, g, b, a)
canvas.fill(color)              # Fill entire canvas
canvas.flood_fill(x, y, color)  # Flood fill from (x, y)
```

---

### Drawing Primitives

```python
canvas.draw_rect(x, y, w, h, color, filled=True)
canvas.draw_line(x1, y1, x2, y2, color)
canvas.draw_circle(cx, cy, radius, color, filled=False)
```

---

### Canvas Utilities

```python
copy   = canvas.copy()              # Deep copy
canvas.paste(other_canvas, x, y)    # Paste one canvas onto another
```

---

### Palette

```python
from pixelart import Palette

palette = Palette({
    "skin":    "#f2c6a0",
    "shirt":   "#3b82f6",
    "outline": "#000000",
})

canvas.set_pixel(4, 4, palette["skin"])
canvas.draw_circle(8, 8, 4, palette["shirt"], filled=True)
```

Built-in palettes:

```python
from pixelart import CLASSIC, PASTEL, EARTHY

canvas.fill(CLASSIC["black"])
canvas.draw_rect(2, 2, 4, 4, PASTEL["mint"])
```

---

### Color Formats

All color arguments accept any of:

| Format         | Example               |
|----------------|-----------------------|
| 6-digit hex    | `"#ff0000"`           |
| 3-digit hex    | `"#f00"`              |
| 8-digit hex    | `"#ff0000ff"`         |
| RGB tuple      | `(255, 0, 0)`         |
| RGBA tuple     | `(255, 0, 0, 128)`    |

---

### Export & Preview

```python
canvas.save("output.png")   # Export PNG (respects pixel_size)
canvas.preview()            # Open quick preview window (needs display)
img = canvas.to_image()     # Get a PIL.Image object directly
```

---

## Examples

### Pixel Heart

```python
from pixelart import Canvas, Palette

palette = Palette({"bg": "#1a1a2e", "heart": "#e63946"})
canvas = Canvas(16, 16, pixel_size=24, background=palette["bg"])

HEART = [
    "................",
    "................",
    "..XX...XX.......",
    ".XXXX.XXXX......",
    ".XXXXXXXXXX.....",
    "..XXXXXXXX......",
    "...XXXXXX.......",
    "....XXXX........",
    ".....XX.........",
    # ... rest of rows
]

for row_idx, row in enumerate(HEART):
    for col_idx, ch in enumerate(row):
        if ch == "X":
            canvas.set_pixel(col_idx, row_idx, palette["heart"])

canvas.save("heart.png")
```

### Smiley Face

```python
from pixelart import Canvas

canvas = Canvas(32, 32, pixel_size=16, background="#fef9ef")

canvas.draw_circle(16, 16, 13, "#fdd835", filled=True)  # face
canvas.draw_circle(16, 16, 13, "#333333")                # outline
canvas.draw_circle(11, 12, 2, "#1a1a1a", filled=True)   # left eye
canvas.draw_circle(21, 12, 2, "#1a1a1a", filled=True)   # right eye

canvas.save("smiley.png")
```

---

## License

MIT — free to use, modify, and distribute.
