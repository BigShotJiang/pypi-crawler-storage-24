"""
pixelart.palette
~~~~~~~~~~~~~~~~
Color palette support for the pixelart library.

Provides the Palette class for defining and reusing named colors,
as well as a set of built-in palettes for common pixel art styles.
"""

from typing import Dict, Optional, Union


# ── Type alias ────────────────────────────────────────────────────────────────
ColorLike = Union[str, tuple]   # "#rrggbb" | (r, g, b) | (r, g, b, a)


def parse_color(color: ColorLike) -> tuple:
    """
    Normalise any color representation to an (R, G, B, A) tuple.

    Accepted formats
    ----------------
    * ``"#rgb"``         – 3-digit hex shorthand, e.g. ``"#f00"``
    * ``"#rrggbb"``      – 6-digit hex, e.g. ``"#ff0000"``
    * ``"#rrggbbaa"``    – 8-digit hex with alpha
    * ``(r, g, b)``      – integer tuple 0-255, alpha assumed 255
    * ``(r, g, b, a)``   – integer tuple 0-255 with explicit alpha

    Parameters
    ----------
    color : str or tuple
        The color to parse.

    Returns
    -------
    tuple
        ``(r, g, b, a)`` with each component in the range 0–255.

    Raises
    ------
    ValueError
        If the color string is not in a recognised format.
    TypeError
        If *color* is not a ``str`` or ``tuple``.
    """
    if isinstance(color, tuple):
        if len(color) == 3:
            r, g, b = color
            return (int(r), int(g), int(b), 255)
        elif len(color) == 4:
            r, g, b, a = color
            return (int(r), int(g), int(b), int(a))
        else:
            raise ValueError(f"Color tuple must have 3 or 4 components, got {len(color)}")

    if isinstance(color, str):
        hex_str = color.lstrip("#")

        # Expand 3-digit shorthand → 6-digit
        if len(hex_str) == 3:
            hex_str = "".join(ch * 2 for ch in hex_str)

        if len(hex_str) == 6:
            r = int(hex_str[0:2], 16)
            g = int(hex_str[2:4], 16)
            b = int(hex_str[4:6], 16)
            return (r, g, b, 255)

        if len(hex_str) == 8:
            r = int(hex_str[0:2], 16)
            g = int(hex_str[2:4], 16)
            b = int(hex_str[4:6], 16)
            a = int(hex_str[6:8], 16)
            return (r, g, b, a)

        raise ValueError(
            f"Unrecognised hex color format: '{color}'. "
            "Use '#rgb', '#rrggbb', or '#rrggbbaa'."
        )

    raise TypeError(f"color must be a str or tuple, got {type(color).__name__}")


class Palette:
    """
    A named collection of colors for use across a canvas.

    Example
    -------
    ::

        palette = Palette({
            "skin":    "#f2c6a0",
            "shirt":   "#3b82f6",
            "outline": "#000000",
        })

        canvas.set_pixel(4, 4, palette["skin"])
    """

    def __init__(self, colors: Optional[Dict[str, ColorLike]] = None):
        """
        Parameters
        ----------
        colors : dict, optional
            Mapping of ``name → color``. Colors may be hex strings or
            ``(r, g, b[, a])`` tuples.
        """
        self._colors: Dict[str, tuple] = {}
        if colors:
            for name, color in colors.items():
                self.add(name, color)

    # ── Public API ─────────────────────────────────────────────────────────────

    def add(self, name: str, color: ColorLike) -> None:
        """
        Register a named color in the palette.

        Parameters
        ----------
        name : str
            The color's key (e.g. ``"sky"``).
        color : str or tuple
            Any value accepted by :func:`parse_color`.
        """
        self._colors[name] = parse_color(color)

    def get(self, name: str) -> tuple:
        """
        Retrieve a color by name.

        Parameters
        ----------
        name : str
            Key used when the color was added.

        Returns
        -------
        tuple
            ``(r, g, b, a)``

        Raises
        ------
        KeyError
            If *name* is not in the palette.
        """
        if name not in self._colors:
            raise KeyError(f"Color '{name}' not found in palette. Available: {list(self._colors)}")
        return self._colors[name]

    def names(self) -> list:
        """Return a list of all registered color names."""
        return list(self._colors.keys())

    def __getitem__(self, name: str) -> tuple:
        """Allow ``palette["skin"]`` syntax."""
        return self.get(name)

    def __contains__(self, name: str) -> bool:
        """Allow ``"skin" in palette`` syntax."""
        return name in self._colors

    def __repr__(self) -> str:
        pairs = ", ".join(f"{k!r}: {v}" for k, v in self._colors.items())
        return f"Palette({{{pairs}}})"


# ── Built-in palettes ──────────────────────────────────────────────────────────

#: Classic 16-color palette inspired by early home computers.
CLASSIC = Palette({
    "black":       "#000000",
    "white":       "#ffffff",
    "red":         "#ff0000",
    "lime":        "#00ff00",
    "blue":        "#0000ff",
    "yellow":      "#ffff00",
    "cyan":        "#00ffff",
    "magenta":     "#ff00ff",
    "silver":      "#c0c0c0",
    "gray":        "#808080",
    "maroon":      "#800000",
    "olive":       "#808000",
    "green":       "#008000",
    "purple":      "#800080",
    "teal":        "#008080",
    "navy":        "#000080",
})

#: Pastel palette suitable for cute / kawaii pixel art.
PASTEL = Palette({
    "blush":       "#ffb3ba",
    "peach":       "#ffdfba",
    "butter":      "#ffffba",
    "mint":        "#baffc9",
    "powder":      "#bae1ff",
    "lavender":    "#e8baff",
    "lilac":       "#c9baff",
    "rose":        "#ffbae8",
    "cream":       "#fff9f0",
    "charcoal":    "#333333",
})

#: Earthy / natural tones for landscapes and characters.
EARTHY = Palette({
    "soil":        "#5c3a1e",
    "bark":        "#7b4f2e",
    "sand":        "#c2a06e",
    "wheat":       "#e8d08a",
    "grass":       "#4a7c3f",
    "forest":      "#2d5a27",
    "sky":         "#87ceeb",
    "dusk":        "#e07b54",
    "stone":       "#9e9e8e",
    "snow":        "#f5f5f5",
})
