"""
pixelart.canvas
~~~~~~~~~~~~~~~
Core Canvas class for the pixelart library.

A Canvas is a rectangular grid of pixels. Each pixel is stored as an
``(R, G, B, A)`` tuple and can be set, read, and drawn to using a range
of built-in methods.
"""

from __future__ import annotations

from typing import Optional

from .palette import parse_color, ColorLike
from . import drawing


class Canvas:
    """
    A pixel-art canvas backed by a flat list of ``(R, G, B, A)`` tuples.

    Parameters
    ----------
    width : int
        Number of pixel columns.
    height : int
        Number of pixel rows.
    pixel_size : int, optional
        Side length (in screen pixels) of each logical pixel when saving or
        previewing. Defaults to ``1``.
    background : ColorLike, optional
        Initial fill color. Defaults to transparent (``(0, 0, 0, 0)``).

    Example
    -------
    ::

        canvas = Canvas(16, 16, pixel_size=20)
        canvas.fill("#ffffff")
        canvas.draw_rect(4, 4, 8, 8, "#ff0000")
        canvas.save("output.png")
    """

    def __init__(
        self,
        width: int,
        height: int,
        pixel_size: int = 1,
        background: Optional[ColorLike] = None,
    ):
        if width < 1 or height < 1:
            raise ValueError("Canvas width and height must each be at least 1.")
        if pixel_size < 1:
            raise ValueError("pixel_size must be at least 1.")

        self.width: int = width
        self.height: int = height
        self.pixel_size: int = pixel_size

        # Initialise every pixel to the background color (or transparent).
        default = parse_color(background) if background is not None else (0, 0, 0, 0)
        self._pixels: list[tuple] = [default] * (width * height)

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _index(self, x: int, y: int) -> int:
        """Convert ``(x, y)`` to a flat list index."""
        return y * self.width + x

    def _in_bounds(self, x: int, y: int) -> bool:
        """Return True if ``(x, y)`` lies within the canvas."""
        return 0 <= x < self.width and 0 <= y < self.height

    # ── Pixel manipulation ─────────────────────────────────────────────────────

    def set_pixel(self, x: int, y: int, color: ColorLike) -> None:
        """
        Set the color of a single pixel.

        Out-of-bounds coordinates are silently ignored so that drawing
        primitives that extend past the canvas edge don't raise exceptions.

        Parameters
        ----------
        x, y : int
            Pixel coordinates (0-indexed, origin at top-left).
        color : ColorLike
            Any value accepted by :func:`~pixelart.palette.parse_color`.
        """
        if not self._in_bounds(x, y):
            return  # Gracefully clip to canvas boundaries
        self._pixels[self._index(x, y)] = parse_color(color)

    def get_pixel(self, x: int, y: int) -> tuple:
        """
        Return the ``(R, G, B, A)`` color of a single pixel.

        Parameters
        ----------
        x, y : int
            Pixel coordinates.

        Returns
        -------
        tuple
            ``(r, g, b, a)`` each in range 0–255.

        Raises
        ------
        IndexError
            If ``(x, y)`` is outside the canvas.
        """
        if not self._in_bounds(x, y):
            raise IndexError(
                f"Pixel ({x}, {y}) is out of bounds for a {self.width}×{self.height} canvas."
            )
        return self._pixels[self._index(x, y)]

    def fill(self, color: ColorLike) -> None:
        """
        Fill the entire canvas with a single color.

        Parameters
        ----------
        color : ColorLike
            The fill color.
        """
        rgba = parse_color(color)
        self._pixels = [rgba] * (self.width * self.height)

    # ── Drawing primitives ─────────────────────────────────────────────────────

    def draw_rect(
        self,
        x: int,
        y: int,
        w: int,
        h: int,
        color: ColorLike,
        *,
        filled: bool = True,
    ) -> None:
        """
        Draw a rectangle.

        Parameters
        ----------
        x, y : int
            Top-left corner.
        w, h : int
            Width and height in pixels.
        color : ColorLike
            Fill (or border) color.
        filled : bool, optional
            ``True`` (default) → filled rectangle.
            ``False`` → outline only.
        """
        drawing.draw_rect(self, x, y, w, h, color, filled=filled)

    def draw_line(
        self,
        x1: int,
        y1: int,
        x2: int,
        y2: int,
        color: ColorLike,
    ) -> None:
        """
        Draw a straight line between two points (Bresenham's algorithm).

        Parameters
        ----------
        x1, y1 : int
            Start point.
        x2, y2 : int
            End point.
        color : ColorLike
            Line color.
        """
        drawing.draw_line(self, x1, y1, x2, y2, color)

    def draw_circle(
        self,
        cx: int,
        cy: int,
        radius: int,
        color: ColorLike,
        *,
        filled: bool = False,
    ) -> None:
        """
        Draw a circle.

        Parameters
        ----------
        cx, cy : int
            Centre of the circle.
        radius : int
            Radius in pixels.
        color : ColorLike
            Circle color.
        filled : bool, optional
            ``True`` → filled disk; ``False`` (default) → outline only.
        """
        drawing.draw_circle(self, cx, cy, radius, color, filled=filled)

    def flood_fill(self, x: int, y: int, color: ColorLike) -> None:
        """
        Replace all pixels connected to ``(x, y)`` that share its color.

        Parameters
        ----------
        x, y : int
            Seed coordinates.
        color : ColorLike
            Replacement color.
        """
        drawing.flood_fill(self, x, y, color)

    # ── Pixel data helpers ─────────────────────────────────────────────────────

    def copy(self) -> "Canvas":
        """
        Return a deep copy of this canvas.

        Useful for saving intermediate states.
        """
        new_canvas = Canvas(self.width, self.height, self.pixel_size)
        new_canvas._pixels = list(self._pixels)
        return new_canvas

    def paste(self, other: "Canvas", x: int, y: int) -> None:
        """
        Paste another canvas onto this one at ``(x, y)``.

        Pixels from *other* with ``alpha == 0`` are treated as transparent
        and do not overwrite the destination.

        Parameters
        ----------
        other : Canvas
            The source canvas to paste.
        x, y : int
            Top-left destination coordinates.
        """
        for py in range(other.height):
            for px in range(other.width):
                r, g, b, a = other.get_pixel(px, py)
                if a > 0:  # skip fully transparent pixels
                    self.set_pixel(x + px, y + py, (r, g, b, a))

    # ── Export ─────────────────────────────────────────────────────────────────

    def to_image(self):
        """
        Convert the canvas to a ``PIL.Image.Image`` object.

        The image is always in ``RGBA`` mode. Each logical pixel is scaled
        to ``pixel_size × pixel_size`` screen pixels.

        Returns
        -------
        PIL.Image.Image
        """
        try:
            from PIL import Image
        except ImportError as exc:
            raise ImportError(
                "Pillow is required for image export. "
                "Install it with:  pip install Pillow"
            ) from exc

        ps = self.pixel_size
        img = Image.new("RGBA", (self.width * ps, self.height * ps))

        for y in range(self.height):
            for x in range(self.width):
                color = self._pixels[self._index(x, y)]
                for dy in range(ps):
                    for dx in range(ps):
                        img.putpixel((x * ps + dx, y * ps + dy), color)

        return img

    def save(self, path: str) -> None:
        """
        Export the canvas as a PNG image.

        Parameters
        ----------
        path : str
            Destination file path, e.g. ``"output.png"``.

        Notes
        -----
        Pixel scaling is applied automatically using :attr:`pixel_size`.
        """
        img = self.to_image()
        img.save(path, format="PNG")
        print(f"Saved → {path}  ({self.width * self.pixel_size}×{self.height * self.pixel_size} px)")

    def preview(self) -> None:
        """
        Open a quick preview window using Pillow's built-in viewer.

        Requires a display environment (not available in headless servers).
        """
        img = self.to_image()
        img.show()

    # ── Dunder helpers ─────────────────────────────────────────────────────────

    def __repr__(self) -> str:
        return (
            f"Canvas(width={self.width}, height={self.height}, "
            f"pixel_size={self.pixel_size})"
        )
