"""
pixelart.drawing
~~~~~~~~~~~~~~~~
Drawing primitives (lines, rectangles, circles) for a pixel-art Canvas.

All functions operate on a Canvas instance and accept any color format
supported by :func:`pixelart.palette.parse_color`.
"""

import math
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .canvas import Canvas  # pragma: no cover


def draw_rect(canvas: "Canvas", x: int, y: int, w: int, h: int, color, *, filled: bool = True) -> None:
    """
    Draw a rectangle.

    Parameters
    ----------
    canvas : Canvas
        Target canvas.
    x, y : int
        Top-left corner of the rectangle (in pixels).
    w, h : int
        Width and height (in pixels).
    color : ColorLike
        Fill / stroke color.
    filled : bool, optional
        If ``True`` (default) flood-fills the rectangle.
        If ``False`` draws only the outline (1-pixel border).
    """
    for py in range(y, y + h):
        for px in range(x, x + w):
            if filled:
                canvas.set_pixel(px, py, color)
            else:
                # Only paint the four edges
                on_edge = (
                    px == x or px == x + w - 1 or
                    py == y or py == y + h - 1
                )
                if on_edge:
                    canvas.set_pixel(px, py, color)


def draw_line(canvas: "Canvas", x1: int, y1: int, x2: int, y2: int, color) -> None:
    """
    Draw a straight line using Bresenham's line algorithm.

    Parameters
    ----------
    canvas : Canvas
        Target canvas.
    x1, y1 : int
        Start coordinates.
    x2, y2 : int
        End coordinates.
    color : ColorLike
        Line color.
    """
    dx = abs(x2 - x1)
    dy = abs(y2 - y1)
    sx = 1 if x1 < x2 else -1
    sy = 1 if y1 < y2 else -1
    err = dx - dy

    x, y = x1, y1

    while True:
        canvas.set_pixel(x, y, color)
        if x == x2 and y == y2:
            break
        e2 = 2 * err
        if e2 > -dy:
            err -= dy
            x += sx
        if e2 < dx:
            err += dx
            y += sy


def draw_circle(canvas: "Canvas", cx: int, cy: int, radius: int, color, *, filled: bool = False) -> None:
    """
    Draw a circle using the midpoint circle algorithm.

    Parameters
    ----------
    canvas : Canvas
        Target canvas.
    cx, cy : int
        Centre of the circle.
    radius : int
        Radius in pixels.
    color : ColorLike
        Circle color.
    filled : bool, optional
        If ``True`` flood-fills the circle disk.
        If ``False`` (default) draws only the outline.
    """
    if filled:
        _filled_circle(canvas, cx, cy, radius, color)
    else:
        _outline_circle(canvas, cx, cy, radius, color)


def _outline_circle(canvas: "Canvas", cx: int, cy: int, radius: int, color) -> None:
    """Midpoint circle algorithm – outline only."""
    x = radius
    y = 0
    err = 0

    while x >= y:
        # 8-way symmetry
        for px, py in [
            (cx + x, cy + y), (cx + y, cy + x),
            (cx - y, cy + x), (cx - x, cy + y),
            (cx - x, cy - y), (cx - y, cy - x),
            (cx + y, cy - x), (cx + x, cy - y),
        ]:
            canvas.set_pixel(px, py, color)

        y += 1
        if err <= 0:
            err += 2 * y + 1
        if err > 0:
            x -= 1
            err -= 2 * x + 1


def _filled_circle(canvas: "Canvas", cx: int, cy: int, radius: int, color) -> None:
    """Scanline fill for a circle disk."""
    for y in range(cy - radius, cy + radius + 1):
        dy = y - cy
        half_chord = math.isqrt(radius * radius - dy * dy)
        for x in range(cx - half_chord, cx + half_chord + 1):
            canvas.set_pixel(x, y, color)


def flood_fill(canvas: "Canvas", x: int, y: int, color) -> None:
    """
    Replace all connected pixels of the same color starting at ``(x, y)``.

    Uses an iterative 4-directional BFS (breadth-first) flood fill so that
    even large canvases don't hit Python's recursion limit.

    Parameters
    ----------
    canvas : Canvas
        Target canvas.
    x, y : int
        Seed pixel coordinates.
    color : ColorLike
        Replacement color.
    """
    from .palette import parse_color

    target = canvas.get_pixel(x, y)
    replacement = parse_color(color)

    if target == replacement:
        return  # Already the desired color – nothing to do.

    queue = [(x, y)]
    visited = set()

    while queue:
        px, py = queue.pop()
        if (px, py) in visited:
            continue
        if not (0 <= px < canvas.width and 0 <= py < canvas.height):
            continue
        if canvas.get_pixel(px, py) != target:
            continue

        canvas.set_pixel(px, py, replacement)
        visited.add((px, py))

        queue.extend([
            (px + 1, py), (px - 1, py),
            (px, py + 1), (px, py - 1),
        ])
