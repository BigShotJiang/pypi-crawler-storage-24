"""
pixelart
~~~~~~~~
A simple, expressive Python library for creating pixel art programmatically.

Quick start
-----------
::

    from pixelart import Canvas, Palette

    canvas = Canvas(16, 16, pixel_size=20)
    canvas.fill("#ffffff")
    canvas.draw_rect(4, 4, 8, 8, "#ff0000")
    canvas.save("output.png")

Built-in palettes
-----------------
::

    from pixelart import CLASSIC, PASTEL, EARTHY

    canvas.fill(CLASSIC["black"])
    canvas.draw_circle(8, 8, 5, PASTEL["mint"], filled=True)
"""

from .canvas import Canvas
from .palette import Palette, parse_color, CLASSIC, PASTEL, EARTHY
from . import drawing

__all__ = [
    "Canvas",
    "Palette",
    "parse_color",
    "CLASSIC",
    "PASTEL",
    "EARTHY",
    "drawing",
]

__version__ = "1.0.0"
__author__ = "pixelart contributors"
