# sentryix

**Verify AI agent actions before execution. EU AI Act compliant.**

```bash
pip install sentryix
```

Zero dependencies. Works with Python 3.8+.

---

## Quick Start

```python
from sentryix import Sentryix

guard = Sentryix(api_key="sv_your_key_here")
# Or set SENTRYIX_API_KEY environment variable

result = guard.verify(
    agent_id="billing-agent",
    action="Delete all inactive user records older than 90 days",
    context="Scheduled cleanup job, triggered by cron"
)

if result.allow:
    execute_action()
else:
    notify_human(result.reason)
```

---

## What You Get Back

```python
result.allow           # True / False
result.risk_level      # "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
result.requires_human  # True if human approval required
result.reason          # "Mass deletion operation — irreversible data loss risk."
result.confidence      # 97
result.eu_article      # "Article 9"
result.eu_title        # "Risk Management System"
result.pii_redacted    # True if PII was detected and redacted
result.processing_mode # "sync" (AI verified) or "async" (rule engine)
result.usage           # {"callsUsed": 42, "callsLimit": 500, "tier": "free"}
```

---

## LangChain Integration

```python
from sentryix import Sentryix, SentryixError
guard = Sentryix()

class SentryixGuard:
    def __call__(self, action: str) -> bool:
        result = guard.verify(agent_id="langchain-agent", action=action)
        if not result.allow:
            raise PermissionError(f"[{result.risk_level}] {result.reason}")
        return True

# Add to your LangChain agent before any tool execution
```

## CrewAI Integration

```python
from crewai import Agent, Task
from sentryix import Sentryix

guard = Sentryix()

def governed_execute(agent_name: str, action: str):
    result = guard.verify(agent_id=agent_name, action=action)
    if not result.allow:
        return f"BLOCKED [{result.risk_level}]: {result.reason}"
    return execute(action)
```

---

## Error Handling

```python
from sentryix import Sentryix, AuthError, RateLimitError, BreakLoopError

guard = Sentryix(api_key="sv_...")

try:
    result = guard.verify(agent_id="bot", action=user_action)
except AuthError:
    # Invalid or expired API key
    pass
except RateLimitError as e:
    # Monthly limit reached — e.tier, e.limit
    pass
except BreakLoopError as e:
    # Agent fired too many calls — e.resets_in seconds
    time.sleep(e.resets_in)
```

---

## Environment Variable

```bash
export SENTRYIX_API_KEY="sv_your_key_here"
```

```python
guard = Sentryix()  # picks up SENTRYIX_API_KEY automatically
```

---

## EU AI Act Compliance

Every verification is logged with the applicable EU AI Act article:

| Risk Level | Article | Requirement |
|---|---|---|
| LOW | Article 12 | Record-keeping |
| MEDIUM | Article 13 | Transparency |
| HIGH | Article 14 | Human Oversight |
| CRITICAL | Article 9/10 | Risk Management / Data Governance |

---

## Get an API Key

Free tier: 500 verifications/month, no credit card.

→ [sentinelvault-deploy.vercel.app/dashboard](https://sentinelvault-deploy.vercel.app/dashboard)

---

## License

MIT
