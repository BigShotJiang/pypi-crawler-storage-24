"""
Sentryix Python SDK
Verify AI agent actions before execution.

Usage:
    from sentryix import Sentryix

    guard = Sentryix(api_key="sv_your_key_here")

    result = guard.verify(
        agent_id="my-agent",
        action="Delete all inactive user records",
        context="Scheduled cleanup job"
    )

    if result.allow:
        execute_action()
    else:
        notify_human(result.reason)
        # result.risk_level  → "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
        # result.requires_human → True/False
        # result.eu_article  → "Article 12" | "Article 14" etc.
        # result.confidence  → 0-100
"""

from __future__ import annotations

import os
import json
import time
import urllib.request
import urllib.error
from dataclasses import dataclass, field
from typing import Optional, List


__version__ = "1.0.0"
__all__ = ["Sentryix", "VerifyResult", "SentryixError", "RateLimitError", "AuthError"]

DEFAULT_BASE_URL = "https://sentryix.vercel.app"
DEFAULT_TIMEOUT  = 30  # seconds


# ── Exceptions ────────────────────────────────────────────────────────────────

class SentryixError(Exception):
    """Base error for all Sentryix SDK exceptions."""
    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


class AuthError(SentryixError):
    """Invalid or missing API key."""
    pass


class RateLimitError(SentryixError):
    """Monthly call limit reached. Upgrade your plan."""
    def __init__(self, message: str, tier: str = "", limit: int = 0):
        super().__init__(message, status_code=429)
        self.tier  = tier
        self.limit = limit


class BreakLoopError(SentryixError):
    """Agent rate limit exceeded — BREAK_LOOP protection triggered."""
    def __init__(self, message: str, agent_id: str = "", resets_in: int = 0):
        super().__init__(message, status_code=429)
        self.agent_id  = agent_id
        self.resets_in = resets_in


# ── Result ────────────────────────────────────────────────────────────────────

@dataclass
class VerifyResult:
    """
    Result of a verify() call.

    Attributes:
        allow           True if the action is safe to proceed.
        risk_level      "LOW" | "MEDIUM" | "HIGH" | "CRITICAL"
        requires_human  True if a human must approve before execution.
        reason          One-sentence explanation of the decision.
        confidence      Classification confidence 0–100.
        eu_article      Applicable EU AI Act article (e.g. "Article 14").
        eu_title        Article title (e.g. "Human Oversight").
        agent_id        The agent_id you passed in.
        action          The action text (PII redacted).
        processing_mode "sync" (AI verified) or "async" (rule engine fast-path).
        pii_redacted    True if PII was detected and redacted before logging.
        pii_types       List of detected PII types e.g. ["EMAIL", "CARD"].
        credit_cost     Credits consumed: 0 for observations, 1 for executions.
        usage           Dict with callsUsed, callsLimit, tier.
        raw             Full raw response dict from the API.
    """
    allow:           bool
    risk_level:      str
    requires_human:  bool
    reason:          str
    confidence:      int
    eu_article:      str
    eu_title:        str
    agent_id:        str
    action:          str
    processing_mode: str
    pii_redacted:    bool
    pii_types:       List[str]
    credit_cost:     int
    usage:           dict
    raw:             dict = field(repr=False)

    def __bool__(self) -> bool:
        """Allows `if guard.verify(...):` to check allow directly."""
        return self.allow

    def __repr__(self) -> str:
        status = "ALLOW" if self.allow else "BLOCK"
        return (
            f"VerifyResult({status} | {self.risk_level} | "
            f"confidence={self.confidence}% | {self.reason[:60]})"
        )


# ── Client ────────────────────────────────────────────────────────────────────

class Sentryix:
    """
    Sentryix governance client.

    Args:
        api_key:  Your sv_... API key. Falls back to SENTRYIX_API_KEY env var.
        base_url: Override the API base URL. Defaults to the Sentryix cloud.
        timeout:  Request timeout in seconds. Default 30.

    Example:
        guard = Sentryix(api_key="sv_...")
        result = guard.verify(agent_id="bot", action="read catalog page")
        if result.allow:
            proceed()
    """

    def __init__(
        self,
        api_key:  Optional[str] = None,
        base_url: str = DEFAULT_BASE_URL,
        timeout:  int = DEFAULT_TIMEOUT,
    ):
        self.api_key  = api_key or os.environ.get("SENTRYIX_API_KEY", "")
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout

        if not self.api_key:
            raise AuthError(
                "No API key provided. Pass api_key='sv_...' or set "
                "the SENTRYIX_API_KEY environment variable."
            )
        if not self.api_key.startswith("sv_"):
            raise AuthError(
                f"Invalid API key format '{self.api_key[:8]}...'. "
                "Sentryix keys start with 'sv_'. Get a key at "
                f"{self.base_url}/dashboard"
            )

    # ── Public API ─────────────────────────────────────────────────────────────

    def verify(
        self,
        action:    str,
        agent_id:  str = "default-agent",
        context:   str = "",
    ) -> VerifyResult:
        """
        Classify an agent action before execution.

        Args:
            action:   The action your AI agent is about to take.
                      Be specific: "Delete records from users table where active=false"
                      is better than "delete some data".
            agent_id: Identifier for the agent making this call.
                      Used for BREAK_LOOP rate limiting per agent.
            context:  Optional context explaining why the action is happening.
                      Helps the AI layer make a more accurate decision.

        Returns:
            VerifyResult with .allow, .risk_level, .reason, etc.

        Raises:
            AuthError       Invalid or missing API key.
            RateLimitError  Monthly call limit reached.
            BreakLoopError  Agent rate limit (BREAK_LOOP) triggered.
            SentryixError   Any other API or network error.

        Example:
            result = guard.verify(
                action="Export all user emails to CSV",
                agent_id="export-bot",
                context="Admin requested data export"
            )
            if not result.allow:
                raise PermissionError(f"Blocked: {result.reason}")
        """
        if not action or not action.strip():
            raise SentryixError("action cannot be empty")

        payload = {
            "action":   action.strip(),
            "agent_id": agent_id,
            "context":  context,
            "api_key":  self.api_key,
        }

        data = self._post("/api/classify", payload)
        return self._parse_result(data)

    # ── Internal ───────────────────────────────────────────────────────────────

    def _post(self, path: str, payload: dict) -> dict:
        url      = self.base_url + path
        body     = json.dumps(payload).encode("utf-8")
        headers  = {
            "Content-Type": "application/json",
            "User-Agent":   f"sentryix-python/{__version__}",
            "X-Sentryix-Origin": self.base_url,
        }

        req = urllib.request.Request(url, data=body, headers=headers, method="POST")

        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                raw = resp.read().decode("utf-8")
                return json.loads(raw)
        except urllib.error.HTTPError as e:
            raw = e.read().decode("utf-8")
            try:
                err_data = json.loads(raw)
            except Exception:
                err_data = {"error": raw}

            msg = err_data.get("error", f"HTTP {e.code}")

            if e.code == 401 or "invalid key" in msg.lower() or "not found" in msg.lower():
                raise AuthError(msg, status_code=e.code) from e
            if e.code == 429 or "limit" in msg.lower():
                if "BREAK_LOOP" in msg:
                    raise BreakLoopError(msg, status_code=e.code) from e
                raise RateLimitError(msg, status_code=e.code) from e
            raise SentryixError(msg, status_code=e.code) from e

        except urllib.error.URLError as e:
            raise SentryixError(
                f"Network error connecting to Sentryix API: {e.reason}. "
                "Check your internet connection."
            ) from e

        except Exception as e:
            raise SentryixError(f"Unexpected error: {e}") from e

    def _parse_result(self, data: dict) -> VerifyResult:
        # Handle LIMIT_REACHED error from the API
        err = data.get("error", "")
        if err:
            if "BREAK_LOOP" in err:
                resets_in = int(err.split("Resumes in ")[-1].replace("s.", "")) if "Resumes in" in err else 0
                raise BreakLoopError(err, resets_in=resets_in)
            if "limit" in err.lower() or "LIMIT_REACHED" in err:
                raise RateLimitError(err)
            if "invalid key" in err.lower() or "not found" in err.lower() or "disabled" in err.lower():
                raise AuthError(err)
            raise SentryixError(err)

        return VerifyResult(
            allow           = bool(data.get("allow", True)),
            risk_level      = data.get("riskLevel", "LOW"),
            requires_human  = bool(data.get("requiresHuman", False)),
            reason          = data.get("reason", ""),
            confidence      = int(data.get("confidence", 0)),
            eu_article      = data.get("euArticle", ""),
            eu_title        = data.get("euTitle", ""),
            agent_id        = data.get("agentId", ""),
            action          = data.get("action", ""),
            processing_mode = data.get("processingMode", "sync"),
            pii_redacted    = bool(data.get("piiRedacted", False)),
            pii_types       = data.get("piiTypes", []),
            credit_cost     = int(data.get("creditCost", 0)),
            usage           = data.get("usage", {}),
            raw             = data,
        )
