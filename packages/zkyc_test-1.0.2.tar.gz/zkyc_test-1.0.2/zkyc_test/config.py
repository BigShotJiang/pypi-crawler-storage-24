from dataclasses import dataclass, field


@dataclass
class ZKYCConfig:
    """
    Shared configuration for both Buyer and Seller SDK instances.

    Args:
        agent_id:      Your on-chain agent ID (uint256 as string).
                       Created on the platform web UI.
        private_key:   Ethereum private key of the wallet you registered
                       the agent with. Used to sign reputation receipts
                       (seller) or verify ownership (buyer).
        rpc_url:       RPC endpoint for the chain your contracts are on.
                       e.g. "https://sepolia.base.org"
        api_base:      Base URL of the ZKYC platform API.
                       e.g. "https://api.yourplatform.com"
        registry_address:
                       Deployed AgentRegistry contract address.
        reputation_address:
                       Deployed AgentReputation contract address.
        usdc_address:  USDC ERC-20 contract address on your chain.
                       Sepolia testnet: 0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238
        chain_id:      Chain ID. Used in reputation receipt signing to
                       prevent cross-chain replay attacks.
        request_timeout:
                       HTTP timeout in seconds for API and service calls.
        min_confirmations:
                       Minimum USDC transfer confirmations before a
                       seller considers a payment valid.
    """

    agent_id: str
    private_key: str
    rpc_url: str = "https://eth-sepolia.g.alchemy.com/v2/r8ZWdaoNH5wzCYpE_FP9A"
    api_base: str = "https://api.zkyc.tech"
    registry_address: str = "0x9540B0498807774768ffC9b21D5bEc92411c4cB5"
    reputation_address: str = "0xa0305403cb8A013B087851679dcc42470F48bdcb"
    usdc_address: str = "0x1c7D4B196Cb0C7B01d743Fbc6116a902379C7238"
    chain_id: int = 11155111  # Sepolia default
    request_timeout: float = 30.0
    min_confirmations: int = 1