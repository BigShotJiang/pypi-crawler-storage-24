import asyncio
import logging
from typing import Any, Callable, Awaitable

from ..config import ZKYCConfig
from ..shared.mailbox import MailboxClient, MailboxError
from ..shared.usdc import USDCClient, USDCError
from .signer import ReputationSigner, SignerError

logger = logging.getLogger("zkyc.seller")


class SellerError(Exception):
    pass


class Seller:

    def __init__(self, config: ZKYCConfig):
        self._config = config
        self._mailbox = MailboxClient(config.api_base, config.request_timeout)
        self._usdc = USDCClient(config.rpc_url, config.usdc_address)
        self._signer = ReputationSigner(config.private_key, config.chain_id)
        self._handlers: dict[str, Callable[[dict, dict], Awaitable[str]]] = {}
        # Track jobs currently being processed so we don't pick them up twice
        self._in_flight: set[str] = set()
        # Track jobs that failed payment verification with their attempt count
        # If a job fails payment N times, give up on it
        self._payment_failures: dict[str, int] = {}
        self._max_payment_retries = 10

    def on_request(self, action: str):
        def decorator(fn: Callable[[dict, dict], Awaitable[str]]):
            if not asyncio.iscoroutinefunction(fn):
                raise SellerError(
                    f"Handler for '{action}' must be an async function"
                )
            self._handlers[action] = fn
            logger.info(f"Registered handler for action: {action}")
            return fn
        return decorator

    async def listen(
        self,
        poll_interval: float = 5.0,
        approved_rating: int = 5,
    ) -> None:
        logger.info(
            f"Seller listening | agent_id={self._config.agent_id} "
            f"| poll_interval={poll_interval}s"
        )
        while True:
            try:
                await self._poll_once(approved_rating)
            except Exception as e:
                logger.error(f"Unexpected error in poll loop: {e}")
            await asyncio.sleep(poll_interval)

    async def _poll_once(self, approved_rating: int) -> None:
        try:
            jobs = self._mailbox.poll_pending(self._config.agent_id)
        except MailboxError as e:
            logger.warning(f"Mailbox poll failed: {e}")
            return

        for job in jobs:
            job_id = job["id"]

            # Skip jobs already being processed in this session
            if job_id in self._in_flight:
                continue

            # Skip jobs that have exceeded payment verification retries
            failures = self._payment_failures.get(job_id, 0)
            if failures >= self._max_payment_retries:
                logger.warning(
                    f"Job {job_id} skipped — exceeded {self._max_payment_retries} "
                    f"payment verification attempts"
                )
                continue

            self._in_flight.add(job_id)
            asyncio.create_task(self._handle_job(job, approved_rating))

    async def _handle_job(self, job: dict[str, Any], approved_rating: int) -> None:
        job_id = job["id"]
        tx_hash = job["tx_hash"]
        amount_usdc = job["amount_usdc"]
        task_payload = job.get("task_payload", {})

        logger.info(f"Processing job {job_id} | txHash={tx_hash}")

        try:
            # Step 1: Verify USDC payment
            try:
                wallet = self._signer.address
                self._usdc.verify_transfer(
                    tx_hash=tx_hash,
                    expected_to=wallet,
                    expected_amount_usdc=amount_usdc,
                    min_confirmations=self._config.min_confirmations,
                )
                logger.info(f"Payment verified for job {job_id}")
                # Reset failure count on success
                self._payment_failures.pop(job_id, None)
            except USDCError as e:
                failures = self._payment_failures.get(job_id, 0) + 1
                self._payment_failures[job_id] = failures
                logger.error(
                    f"Payment verification failed for job {job_id} "
                    f"(attempt {failures}/{self._max_payment_retries}): {e}"
                )
                # If it's a confirmation issue, wait a bit before the next poll
                if "confirmations" in str(e).lower():
                    logger.info(f"Waiting 10s for confirmations on job {job_id}…")
                    await asyncio.sleep(10)
                return

            # Step 2: Resolve action
            action = task_payload.get("action")
            if not action:
                logger.error(f"Job {job_id} missing 'action' in task_payload")
                return

            handler = self._handlers.get(action)
            if not handler:
                logger.error(
                    f"Job {job_id}: no handler registered for action '{action}'"
                )
                return

            # Step 3: Run handler
            try:
                result = await handler(task_payload.get("params", {}), job)
                if not isinstance(result, str):
                    result = str(result)
            except Exception as e:
                logger.error(f"Handler for '{action}' raised an error on job {job_id}: {e}")
                return

            # Step 4: Sign receipt
            try:
                signature = self._signer.sign_receipt(
                    seller_agent_id=self._config.agent_id,
                    tx_hash_hex=tx_hash,
                    rating=approved_rating,
                )
            except SignerError as e:
                logger.error(f"Failed to sign receipt for job {job_id}: {e}")
                return

            # Step 5: Complete job in mailbox
            try:
                self._mailbox.complete_job(
                    job_id=job_id,
                    seller_agent_id=self._config.agent_id,
                    encrypted_result=result,
                    reputation_signature=signature,
                    approved_rating=str(approved_rating),
                )
                logger.info(f"Job {job_id} completed successfully")
            except MailboxError as e:
                logger.error(f"Failed to complete job {job_id} in mailbox: {e}")

        finally:
            # Always remove from in-flight so it can be retried if needed
            self._in_flight.discard(job_id)