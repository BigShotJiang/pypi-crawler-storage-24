"""
Ethereum ECDSA receipt signing for sellers.

After completing a job, the seller signs:
    keccak256(chainId, agentId_uint256, txHash_bytes32, rating_uint8)

This signature is what the buyer submits to AgentReputation.rateAgent()
on-chain to record the star. Without this signature the buyer cannot rate,
which means the seller only gets stars for jobs they actually completed.

The signing matches exactly what the Solidity contract verifies:
    bytes32 messageHash = keccak256(
        abi.encodePacked(block.chainid, agentId, txHash, rating)
    );
    address signer = messageHash.toEthSignedMessageHash().recover(signature);
"""

from eth_account import Account
from eth_account.messages import encode_defunct
from eth_utils import keccak


class SignerError(Exception):
    pass


class ReputationSigner:
    """
    Signs reputation receipts using the seller's Ethereum private key.
    """

    def __init__(self, private_key: str, chain_id: int):
        self._private_key = private_key
        self._chain_id = chain_id
        self._account = Account.from_key(private_key)

    @property
    def address(self) -> str:
        return self._account.address

    def sign_receipt(
        self,
        seller_agent_id: str,
        tx_hash_hex: str,
        rating: int,
    ) -> str:
        """
        Sign a reputation receipt.

        The signed message matches abi.encodePacked in the Solidity contract:
            keccak256(abi.encodePacked(chainId, agentId, txHash, rating))

        Args:
            seller_agent_id: Seller's on-chain agent ID (uint256 as string).
            tx_hash_hex:     The USDC payment tx hash (0x-prefixed).
            rating:          Integer 1-5.

        Returns:
            Hex signature string (0x-prefixed).

        Raises:
            SignerError on invalid inputs.
        """
        if not (1 <= rating <= 5):
            raise SignerError(f"Rating must be 1-5, got {rating}")

        try:
            # Encode exactly as Solidity's abi.encodePacked would:
            # chainId  → uint256 → 32 bytes big-endian
            # agentId  → uint256 → 32 bytes big-endian
            # txHash   → bytes32 → 32 bytes
            # rating   → uint8   → 1 byte
            chain_id_bytes = self._chain_id.to_bytes(32, "big")
            agent_id_bytes = int(seller_agent_id).to_bytes(32, "big")
            tx_hash_bytes = bytes.fromhex(tx_hash_hex.removeprefix("0x")).ljust(
                32, b"\x00"
            )[:32]
            rating_bytes = rating.to_bytes(1, "big")

            packed = chain_id_bytes + agent_id_bytes + tx_hash_bytes + rating_bytes
            message_hash = keccak(packed)

            # eth_account adds the "\x19Ethereum Signed Message:\n32" prefix
            signable = encode_defunct(primitive=message_hash)
            signed = Account.sign_message(signable, self._private_key)

            return signed.signature.hex()

        except SignerError:
            raise
        except Exception as e:
            raise SignerError(f"Receipt signing failed: {e}")