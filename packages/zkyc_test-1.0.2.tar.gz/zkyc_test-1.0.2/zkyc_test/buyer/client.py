"""
Buyer SDK client.

Usage:
    from zkyc import Buyer, ZKYCConfig

    config = ZKYCConfig(
        agent_id="789012...",
        private_key="0x...",
        rpc_url="https://sepolia.base.org",
        api_base="https://api.yourplatform.com",
        registry_address="0x...",
        reputation_address="0x...",
    )

    buyer = Buyer(config)

    # Find the best available seller for the "translate" action
    seller = await buyer.find_agent(action="translate")

    # Pay and submit task — returns a job dict immediately
    job = await buyer.call(
        seller=seller,
        params={"text": "Hello world", "target_lang": "fr"},
    )

    # Wait until the seller completes the job (async, survives restarts)
    result = await buyer.wait_for_result(job, timeout=300)
    print(result)

    # Submit the reputation rating on-chain
    await buyer.rate(job, rating=5)
"""

import asyncio
import logging
from typing import Any

from ..config import ZKYCConfig
from ..shared.blockchain import BlockchainClient, BlockchainError
from ..shared.mailbox import MailboxClient, MailboxError
from ..shared.registry import RegistryClient
from ..shared.usdc import USDCClient, USDCError
from .discovery import AgentDiscovery, DiscoveryError

logger = logging.getLogger("zkyc.buyer")


class BuyerError(Exception):
    pass


class Buyer:
    """
    Buyer SDK. Discovers sellers, pays in USDC, polls for results,
    and submits reputation ratings on-chain.
    """

    def __init__(self, config: ZKYCConfig):
        self._config = config
        self._blockchain = BlockchainClient(
            config.rpc_url,
            config.registry_address,
            config.reputation_address,
        )
        self._registry = RegistryClient(config.api_base, config.request_timeout)
        self._mailbox = MailboxClient(config.api_base, config.request_timeout)
        self._usdc = USDCClient(config.rpc_url, config.usdc_address)
        self._discovery = AgentDiscovery(
            self._blockchain,
            self._registry,
            config.api_base,
            config.request_timeout,
        )

    # ── Discovery ─────────────────────────────────────────────────────────────

    async def find_agent(
        self,
        action: str,
        min_rating: float = 0.0,
        require_kyc: bool = True,
    ) -> dict[str, Any]:
        """
        Find the best available seller for a given action.

        Runs on-chain KYC checks, fetches metadata, and sorts by rating.

        Args:
            action:      SDK-searchable action key, e.g. "translate".
            min_rating:  Minimum acceptable average rating (0.0–5.0).
            require_kyc: Only consider KYC-verified agents (default True).

        Returns:
            The best matching candidate dict:
            {
              "agent":   { agent_id, name, wallet_address, ... },
              "service": { id, action, api_url, price_usdc, inputs_schema },
              "rating":  4.8
            }

        Raises:
            BuyerError if no suitable agent is found.
        """
        loop = asyncio.get_event_loop()
        try:
            candidates = await loop.run_in_executor(
                None,
                lambda: self._discovery.find(action, min_rating, require_kyc),
            )
        except DiscoveryError as e:
            raise BuyerError(f"Discovery failed: {e}")

        if not candidates:
            raise BuyerError(
                f"No available sellers found for action='{action}' on {self._config.api_base}.\n"
                f"Possible reasons:\n"
                f"  - No seller has registered a service with action='{action}'\n"
                f"  - require_kyc=True (default) and no sellers have valid KYC\n"
                f"  - min_rating={min_rating} is filtering everyone out\n"
                f"Try: buyer.find_agent(action='{action}', require_kyc=False, min_rating=0.0)"
            )

        best = candidates[0]
        logger.info(
            f"Found agent {best['agent']['agent_id']} for action '{action}' "
            f"(rating={best['rating']}, price={best['service']['price_usdc']} USDC)"
        )
        return best

    # ── Payment + Job creation ─────────────────────────────────────────────────

    async def call(
        self,
        seller: dict[str, Any],
        params: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Pay the seller in USDC and open a job in the mailbox.

        Validates that all required inputs defined in the service's
        inputs_schema are present before sending payment.

        Args:
            seller: A candidate dict returned by find_agent().
            params: The task parameters matching the service's inputs_schema.

        Returns:
            The opened job dict from the mailbox. Pass this to
            wait_for_result() and rate().

        Raises:
            BuyerError on validation failure, payment failure, or
            mailbox error.
        """
        service = seller["service"]
        agent = seller["agent"]

        # Pre-flight: validate params against the service's inputs_schema
        self._validate_params(params, service.get("inputs_schema", {}))

        seller_wallet = agent["wallet_address"]
        price_usdc = service["price_usdc"]

        # Send USDC
        logger.info(
            f"Paying {price_usdc} USDC to {seller_wallet} "
            f"for action '{service['action']}'"
        )
        loop = asyncio.get_event_loop()
        try:
            transfer = await loop.run_in_executor(
                None,
                lambda: self._usdc.transfer(
                    private_key=self._config.private_key,
                    to=seller_wallet,
                    amount_usdc=price_usdc,
                    wait_for_receipt=True,  # already True, but now we also wait extra
                    timeout=180,
                ),
            )
        except USDCError as e:
            raise BuyerError(f"USDC payment failed: {e}")

        # Wait for the transaction to have at least 1 confirmation
        # before opening the job, so the seller can verify it immediately
        logger.info(f"Payment sent: {transfer.tx_hash} — waiting for confirmation…")
        await loop.run_in_executor(
            None,
            lambda: self._wait_for_confirmations(transfer.tx_hash, min_confirmations=2),
        )
        logger.info(f"Payment confirmed: {transfer.tx_hash}")

        # Build the task payload the seller's handler will receive
        task_payload = {
            "action": service["action"],
            "params": params,
        }

        # Open a job in the mailbox
        try:
            job = await loop.run_in_executor(
                None,
                lambda: self._mailbox.open_job(
                    buyer_agent_id=self._config.agent_id,
                    seller_agent_id=agent["agent_id"],
                    service_id=service["id"],
                    tx_hash=transfer.tx_hash,
                    amount_usdc=price_usdc,
                    task_payload=task_payload,
                ),
            )
        except MailboxError as e:
            raise BuyerError(
                f"Payment sent ({transfer.tx_hash}) but failed to open job: {e}. "
                f"Save the tx_hash and retry with open_job_manually()."
            )

        logger.info(f"Job opened: {job['id']}")
        return job

    def open_job_manually(
        self,
        seller_agent_id: str,
        service_id: str,
        tx_hash: str,
        amount_usdc: str,
        task_payload: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Manually open a job if call() failed after payment was sent.
        Use this as a recovery tool when you have a tx_hash but no job.
        """
        try:
            return self._mailbox.open_job(
                buyer_agent_id=self._config.agent_id,
                seller_agent_id=seller_agent_id,
                service_id=service_id,
                tx_hash=tx_hash,
                amount_usdc=amount_usdc,
                task_payload=task_payload,
            )
        except MailboxError as e:
            raise BuyerError(f"open_job_manually failed: {e}")

    # ── Result polling ────────────────────────────────────────────────────────

    async def wait_for_result(
        self,
        job: dict[str, Any],
        timeout: float = 300.0,
        poll_interval: float = 5.0,
    ) -> str:
        """
        Poll the mailbox until the seller completes the job.

        This is async and survives restarts — if the buyer agent goes
        offline, call wait_for_result() again with the same job dict
        (or retrieve the job via get_job() first).

        Args:
            job:           The job dict returned by call().
            timeout:       Max seconds to wait before raising BuyerError.
            poll_interval: Seconds between polls.

        Returns:
            The result string from the seller (decrypted if encrypted).

        Raises:
            BuyerError on timeout or if job status is 'failed'.
        """
        tx_hash = job["tx_hash"]
        job_id = job["id"]
        elapsed = 0.0
        loop = asyncio.get_event_loop()

        logger.info(f"Waiting for result | job={job_id} | timeout={timeout}s")

        while elapsed < timeout:
            try:
                current = await loop.run_in_executor(
                    None,
                    lambda: self._mailbox.get_job_by_tx(tx_hash),
                )
            except MailboxError as e:
                logger.warning(f"Mailbox poll failed: {e}")
                await asyncio.sleep(poll_interval)
                elapsed += poll_interval
                continue

            status = current.get("status")

            if status == "completed":
                result = current.get("encrypted_result", "")
                logger.info(f"Job {job_id} completed")
                # Store the updated job data back on the dict so rate() can use it
                job.update(current)
                return result

            if status == "failed":
                raise BuyerError(f"Job {job_id} was marked as failed by the seller")

            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

        # Timeout — mark job as failed in the mailbox
        try:
            await loop.run_in_executor(
                None,
                lambda: self._mailbox.mark_job_failed(job_id, self._config.agent_id),
            )
        except MailboxError:
            pass

        raise BuyerError(
            f"Timed out waiting for job {job_id} after {timeout}s"
        )

    def get_job(self, tx_hash: str) -> dict[str, Any]:
        """
        Retrieve a job by its payment tx_hash.
        Useful for recovery if the buyer restarted and lost the job dict.
        """
        try:
            return self._mailbox.get_job_by_tx(tx_hash)
        except MailboxError as e:
            raise BuyerError(f"get_job failed: {e}")

    # ── Reputation ────────────────────────────────────────────────────────────

    async def rate(
        self,
        job: dict[str, Any],
        rating: int | None = None,
    ) -> str:
        """
        Submit the reputation rating on-chain.

        Uses the reputationSignature the seller stored in the mailbox
        after completing the job. The rating used is the one the seller
        approved when they signed the receipt (stored as approved_rating).

        Args:
            job:    The job dict (must have status='completed' and
                    reputation_signature set). If you only have a tx_hash,
                    call get_job(tx_hash) first.
            rating: Override the approved_rating. In most cases leave
                    this as None and use the seller-approved value.

        Returns:
            The on-chain rating transaction hash.

        Raises:
            BuyerError if the job isn't completed or signature is missing.
        """
        if job.get("status") != "completed":
            raise BuyerError("Cannot rate: job is not completed")

        signature_hex = job.get("reputation_signature")
        if not signature_hex:
            raise BuyerError("Cannot rate: reputation_signature is missing from job")

        final_rating = rating if rating is not None else int(job.get("approved_rating", 5))

        if not (1 <= final_rating <= 5):
            raise BuyerError(f"Rating must be 1-5, got {final_rating}")

        signature_bytes = bytes.fromhex(signature_hex.removeprefix("0x"))

        loop = asyncio.get_event_loop()
        try:
            tx_hash = await loop.run_in_executor(
                None,
                lambda: self._blockchain.submit_rating(
                    private_key=self._config.private_key,
                    agent_id=job["seller_agent_id"],
                    tx_hash_hex=job["tx_hash"],
                    rating=final_rating,
                    signature=signature_bytes,
                ),
            )
        except BlockchainError as e:
            raise BuyerError(f"On-chain rating failed: {e}")

        logger.info(
            f"Rating submitted on-chain | job={job['id']} "
            f"| rating={final_rating} | tx={tx_hash}"
        )
        return tx_hash

    # ── Utilities ─────────────────────────────────────────────────────────────

    def get_usdc_balance(self) -> str:
        """Return the buyer's USDC balance as a human-readable string."""
        from web3 import Web3
        acct = Web3().eth.account.from_key(self._config.private_key)
        return self._usdc.get_balance(acct.address)

    def _validate_params(
        self,
        params: dict[str, Any],
        inputs_schema: dict[str, str],
    ) -> None:
        """
        Validate that all required fields in inputs_schema are present
        in params before sending payment.

        Raises BuyerError listing all missing fields.
        """
        if not inputs_schema:
            return

        missing = [k for k in inputs_schema if k not in params]
        if missing:
            raise BuyerError(
                f"Missing required parameters: {missing}. "
                f"Expected: {inputs_schema}"
            )
        
    def _wait_for_confirmations(self, tx_hash: str, min_confirmations: int = 2) -> None:
        """Block until the tx has enough confirmations."""
        import time
        w3 = self._usdc._w3
        while True:
            try:
                receipt = w3.eth.get_transaction_receipt(tx_hash)
                if receipt is not None:
                    current = w3.eth.block_number
                    confs = current - receipt["blockNumber"]
                    if confs >= min_confirmations:
                        return
            except Exception:
                pass
            time.sleep(3)
            
    def describe(self, seller: dict[str, Any]) -> None:
        """
        Print a human-readable summary of a seller and what params to send.

        Usage:
            seller = await buyer.find_agent(action="translate")
            buyer.describe(seller)
        """
        agent = seller["agent"]
        service = seller["service"]
        schema = service.get("inputs_schema", {})

        print(f"\nSeller:  {agent.get('name', 'Unknown')} (ID: {agent['agent_id'][:20]}…)")
        print(f"Action:  {service['action']}")
        print(f"Price:   {service['price_usdc']} USDC")
        print(f"Rating:  {seller.get('rating', 0.0):.1f} / 5.0")
        if schema:
            print(f"Params required:")
            for key, typ in schema.items():
                print(f"  {key}: {typ}")
        else:
            print("Params:  none required")
        print()