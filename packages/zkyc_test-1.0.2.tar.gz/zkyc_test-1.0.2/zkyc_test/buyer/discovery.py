"""
Agent discovery logic for buyers.

Combines on-chain registry reads (KYC validity, ratings) with
off-chain metadata fetches (actions, prices) to find the best
seller for a given action.
"""

from ..shared.blockchain import BlockchainClient, BlockchainError
from ..shared.registry import RegistryClient, RegistryError


class DiscoveryError(Exception):
    pass


class AgentDiscovery:
    """
    Finds seller agents that offer a given action.

    The flow:
      1. Fetch the list of known seller agent IDs from the platform API.
      2. For each, verify KYC validity on-chain (fast contract read).
      3. Fetch their metadata JSON to find matching actions.
      4. Sort results by on-chain reputation rating (highest first).
    """

    def __init__(
        self,
        blockchain: BlockchainClient,
        registry: RegistryClient,
        api_base: str,
        timeout: float = 30.0,
    ):
        self._blockchain = blockchain
        self._registry = registry
        self._api_base = api_base.rstrip("/")
        self._timeout = timeout

    def _list_seller_ids(self) -> list[str]:
        """
        Fetch all known seller agent IDs from the platform API.
        This is the platform's index — not The Graph, just a simple
        endpoint that returns all registered seller agents.
        """
        import httpx

        url = f"{self._api_base}/api/agents/sellers"
        try:
            with httpx.Client(timeout=self._timeout) as client:
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
                agents = data.get("data", data)
                return [a["agent_id"] for a in agents if isinstance(a, dict)]
        except Exception as e:
            raise DiscoveryError(
                f"Failed to reach the platform API at '{self._api_base}/api/agents/sellers'. "
                f"Check that api_base is correct and the server is running. Details: {e}"
            )

    def find(
        self,
        action: str,
        min_rating: float = 0.0,
        require_kyc: bool = True,
    ) -> list[dict]:
        """
        Find seller agents offering a given action.

        Args:
            action:      The action key, e.g. "translate".
            min_rating:  Minimum average rating (0.0 to 5.0). Agents with
                         no ratings yet are included when min_rating == 0.0.
            require_kyc: Only return KYC-verified agents (default True).

        Returns:
            List of candidate dicts sorted by rating descending:
            [
              {
                "agent":   { ...metadata... },
                "service": { ...service row with action/price/inputs... },
                "rating":  4.8,
              }
            ]

        Raises:
            DiscoveryError if the seller list can't be fetched.
        """
        seller_ids = self._list_seller_ids()
        if not seller_ids:
            return []

        # Filter by on-chain KYC and reputation
        valid_ids = []
        for agent_id in seller_ids:
            if require_kyc:
                try:
                    exists, is_kyc_valid = self._blockchain.is_agent_valid(agent_id)
                    if not exists or not is_kyc_valid:
                        continue
                except BlockchainError:
                    continue
            valid_ids.append(agent_id)

        # Find matching actions in metadata
        matches = self._registry.find_agents_by_action(action, valid_ids)

        # Attach rating and apply min_rating filter
        results = []
        for match in matches:
            agent_id = match["agent"]["agent_id"]
            try:
                rating = self._blockchain.get_average_rating(agent_id)
            except BlockchainError:
                rating = 0.0

            if rating < min_rating:
                continue

            results.append({**match, "rating": rating})

        # Sort by rating descending — highest-rated seller first
        results.sort(key=lambda x: x["rating"], reverse=True)
        return results