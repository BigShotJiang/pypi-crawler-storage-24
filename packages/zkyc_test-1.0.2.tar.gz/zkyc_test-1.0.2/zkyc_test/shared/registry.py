"""
Fetches and caches agent metadata from the platform API.
This is the off-chain counterpart to the on-chain registry.
"""

from typing import Any
import httpx


class RegistryError(Exception):
    pass


class RegistryClient:
    """
    Reads agent metadata JSON from the platform's metadata endpoint.

    The metadata URL is stored on-chain in AgentRegistry.metadataURI
    and served by: GET /api/agents/:agentId/metadata

    The JSON shape is:
    {
      "agent_id": "...",
      "name": "...",
      "role": "seller",
      "wallet_address": "0x...",
      "services": [
        {
          "id": "...",
          "service_name": "Translation Service",
          "action": "translate",
          "api_url": "https://agent.com/api",
          "price_usdc": "1.50",
          "inputs_schema": { "text": "string", "target_lang": "string" }
        }
      ]
    }
    """

    def __init__(self, api_base: str, timeout: float = 30.0):
        self._api_base = api_base.rstrip("/")
        self._timeout = timeout
        # Simple in-memory cache so we don't hammer the API
        self._cache: dict[str, dict[str, Any]] = {}

    def get_metadata(self, agent_id: str, use_cache: bool = True) -> dict[str, Any]:
        """
        Fetch metadata for a single agent.

        Args:
            agent_id:  The agent's on-chain ID.
            use_cache: Use in-memory cache (default True).

        Returns:
            The metadata dict.

        Raises:
            RegistryError on failure.
        """
        if use_cache and agent_id in self._cache:
            return self._cache[agent_id]

        url = f"{self._api_base}/api/agents/{agent_id}/metadata"
        try:
            with httpx.Client(timeout=self._timeout) as client:
                response = client.get(url)
                response.raise_for_status()
                data = response.json()
                metadata = data.get("data", data)
                if use_cache:
                    self._cache[agent_id] = metadata
                return metadata
        except httpx.TimeoutException:
            raise RegistryError(f"Metadata fetch timed out for agent {agent_id}")
        except httpx.HTTPStatusError as e:
            raise RegistryError(
                f"Metadata fetch failed for agent {agent_id}: "
                f"HTTP {e.response.status_code}"
            )
        except Exception as e:
            raise RegistryError(f"Metadata fetch error: {e}")

    def find_agents_by_action(
        self,
        action: str,
        agent_ids: list[str],
    ) -> list[dict[str, Any]]:
        """
        From a list of agent IDs, return those that offer the given action.

        Args:
            action:    The action key to search for, e.g. "translate".
            agent_ids: List of agent IDs to check.

        Returns:
            List of (metadata, service) dicts for matching agents:
            [
              {
                "agent": { ...metadata... },
                "service": { ...service row... }
              }
            ]
        """
        results = []
        for agent_id in agent_ids:
            try:
                metadata = self.get_metadata(agent_id)
            except RegistryError:
                continue

            if metadata.get("role") != "seller":
                continue

            for svc in metadata.get("services", []):
                if svc.get("action") == action:
                    results.append({"agent": metadata, "service": svc})
                    break

        return results

    def invalidate(self, agent_id: str) -> None:
        """Remove a single agent from the cache."""
        self._cache.pop(agent_id, None)

    def clear_cache(self) -> None:
        """Clear the entire metadata cache."""
        self._cache.clear()