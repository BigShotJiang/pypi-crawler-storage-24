import time
from decimal import Decimal
from typing import NamedTuple

from web3 import Web3
from web3.exceptions import TransactionNotFound


class USDCError(Exception):
    pass


class TransferResult(NamedTuple):
    tx_hash: str
    from_address: str
    to_address: str
    amount_usdc: str
    amount_raw: int


# Minimal ABI — only transfer and balanceOf needed
USDC_ABI = [
    {
        "name": "transfer",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "to", "type": "address"},
            {"name": "amount", "type": "uint256"},
        ],
        "outputs": [{"name": "", "type": "bool"}],
    },
    {
        "name": "balanceOf",
        "type": "function",
        "stateMutability": "view",
        "inputs": [{"name": "account", "type": "address"}],
        "outputs": [{"name": "", "type": "uint256"}],
    },
]

# Transfer(address indexed from, address indexed to, uint256 value)
TRANSFER_TOPIC = "0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef"

USDC_DECIMALS = 6


def _usdc_to_raw(amount_usdc: str) -> int:
    return int(Decimal(amount_usdc) * 10**USDC_DECIMALS)


def _raw_to_usdc(amount_raw: int) -> str:
    result = Decimal(amount_raw) / Decimal(10**USDC_DECIMALS)
    return f"{result:.6f}"


def _normalize_hex(value: bytes | str) -> str:
    """Always return lowercase 0x-prefixed hex string."""
    if isinstance(value, bytes):
        return "0x" + value.hex()
    v = value.lower()
    return v if v.startswith("0x") else "0x" + v


class USDCClient:

    def __init__(self, rpc_url: str, usdc_address: str):
        self._w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not self._w3.is_connected():
            raise USDCError(f"Failed to connect to RPC: {rpc_url}")
        # Store checksum address for reliable comparison
        self._usdc_address = Web3.to_checksum_address(usdc_address)
        self._contract = self._w3.eth.contract(
            address=self._usdc_address,
            abi=USDC_ABI,
        )

    def get_balance(self, wallet_address: str) -> str:
        raw = self._contract.functions.balanceOf(
            Web3.to_checksum_address(wallet_address)
        ).call()
        return _raw_to_usdc(raw)

    def transfer(
        self,
        private_key: str,
        to: str,
        amount_usdc: str,
        gas_limit: int = 100_000,
        wait_for_receipt: bool = True,
        timeout: int = 180,
    ) -> TransferResult:
        try:
            acct = self._w3.eth.account.from_key(private_key)
            amount_raw = _usdc_to_raw(amount_usdc)

            balance_raw = self._contract.functions.balanceOf(acct.address).call()
            if balance_raw < amount_raw:
                have = _raw_to_usdc(balance_raw)
                raise USDCError(
                    f"Insufficient USDC balance. Have: {have}, Need: {amount_usdc}"
                )

            tx = self._contract.functions.transfer(
                Web3.to_checksum_address(to), amount_raw
            ).build_transaction({
                "from": acct.address,
                "nonce": self._w3.eth.get_transaction_count(acct.address),
                "gas": gas_limit,
                "gasPrice": self._w3.eth.gas_price,
                "chainId": self._w3.eth.chain_id,
            })

            signed = acct.sign_transaction(tx)
            tx_hash_bytes = self._w3.eth.send_raw_transaction(signed.raw_transaction)
            tx_hash_hex = _normalize_hex(tx_hash_bytes)

            if wait_for_receipt:
                receipt = self._w3.eth.wait_for_transaction_receipt(
                    tx_hash_bytes, timeout=timeout
                )
                if receipt["status"] != 1:
                    raise USDCError(f"USDC transfer failed on-chain: {tx_hash_hex}")

            return TransferResult(
                tx_hash=tx_hash_hex,
                from_address=acct.address,
                to_address=to,
                amount_usdc=amount_usdc,
                amount_raw=amount_raw,
            )
        except USDCError:
            raise
        except Exception as e:
            raise USDCError(f"Transfer failed: {e}")

    def verify_transfer(
        self,
        tx_hash: str,
        expected_to: str,
        expected_amount_usdc: str,
        min_confirmations: int = 1,
    ) -> TransferResult:
        # Normalize tx hash — always 0x-prefixed
        tx_hash_norm = _normalize_hex(tx_hash)

        try:
            receipt = self._w3.eth.get_transaction_receipt(tx_hash_norm)
        except TransactionNotFound:
            raise USDCError(f"Transaction not found: {tx_hash_norm}")

        if receipt is None:
            raise USDCError("Transaction not yet mined")

        if receipt["status"] != 1:
            raise USDCError(f"Transaction reverted: {tx_hash_norm}")

        current_block = self._w3.eth.block_number
        confirmations = current_block - receipt["blockNumber"]
        if confirmations < min_confirmations:
            raise USDCError(
                f"Insufficient confirmations. Required: {min_confirmations}, "
                f"Got: {confirmations}"
            )

        result = self._parse_transfer_logs(receipt, expected_to, expected_amount_usdc)
        if result is None:
            # Debug: log what we actually found in the receipt
            self._debug_logs(receipt)
            raise USDCError(
                f"No matching Transfer found. Expected {expected_amount_usdc} USDC "
                f"to {expected_to}"
            )

        return result

    def _parse_transfer_logs(
        self,
        receipt: dict,
        expected_to: str,
        expected_amount_usdc: str,
    ) -> TransferResult | None:
        expected_to_checksum = Web3.to_checksum_address(expected_to)
        expected_raw = _usdc_to_raw(expected_amount_usdc)

        for log in receipt["logs"]:
            # Normalize and compare log address to USDC contract address
            log_address = Web3.to_checksum_address(log["address"])
            if log_address != self._usdc_address:
                continue

            topics = log["topics"]
            if len(topics) < 3:
                continue

            topic0 = _normalize_hex(topics[0])
            if topic0.lower() != TRANSFER_TOPIC.lower():
                continue

            # "to" address is in topics[2], padded to 32 bytes
            to_hex = _normalize_hex(topics[2])
            to_address = Web3.to_checksum_address("0x" + to_hex[-40:])
            if to_address != expected_to_checksum:
                continue

            # value is in data (non-indexed uint256)
            data = log["data"]
            if isinstance(data, bytes):
                value_raw = int.from_bytes(data, "big")
            else:
                data_clean = data.replace("0x", "")
                value_raw = int(data_clean, 16) if data_clean else 0

            if value_raw < expected_raw:
                continue

            from_hex = _normalize_hex(topics[1])
            from_address = Web3.to_checksum_address("0x" + from_hex[-40:])

            tx_hash = receipt.get("transactionHash", b"")
            return TransferResult(
                tx_hash=_normalize_hex(tx_hash),
                from_address=from_address,
                to_address=to_address,
                amount_usdc=_raw_to_usdc(value_raw),
                amount_raw=value_raw,
            )

        return None

    def _debug_logs(self, receipt: dict) -> None:
        """Log raw receipt data to help diagnose verification failures."""
        import logging
        logger = logging.getLogger("zkyc.usdc")
        logger.debug(f"Receipt has {len(receipt['logs'])} logs")
        for i, log in enumerate(receipt["logs"]):
            logger.debug(
                f"  Log[{i}]: address={log['address']} "
                f"topics={[_normalize_hex(t) for t in log['topics']]} "
                f"data={_normalize_hex(log['data']) if log['data'] else '0x'}"
            )
        logger.debug(f"  Expected USDC contract: {self._usdc_address}")