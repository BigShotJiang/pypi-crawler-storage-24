"""
HTTP client for the ZKYC platform mailbox (job persistence).

The mailbox is the async bridge between buyer and seller:
  - Buyer opens a job after paying USDC.
  - Seller polls for pending jobs, processes them, marks complete.
  - Buyer polls by txHash until the job is completed.
"""

from typing import Any
import httpx


class MailboxError(Exception):
    pass


class MailboxClient:
    """
    Wraps the /api/jobs endpoints on the platform API.
    """

    def __init__(self, api_base: str, timeout: float = 30.0):
        self._api_base = api_base.rstrip("/")
        self._timeout = timeout

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self._api_base}{path}"
        try:
            with httpx.Client(timeout=self._timeout) as client:
                response = client.request(method, url, **kwargs)
                response.raise_for_status()
                data = response.json()
                return data.get("data", data)
        except httpx.TimeoutException:
            raise MailboxError(f"Request timed out: {method} {path}")
        except httpx.HTTPStatusError as e:
            try:
                detail = e.response.json().get("error", e.response.text)
            except Exception:
                detail = e.response.text
            raise MailboxError(f"HTTP {e.response.status_code}: {detail}")
        except Exception as e:
            raise MailboxError(f"Request failed: {e}")

    # ── Buyer ─────────────────────────────────────────────────────────────────

    def open_job(
        self,
        buyer_agent_id: str,
        seller_agent_id: str,
        service_id: str,
        tx_hash: str,
        amount_usdc: str,
        task_payload: dict[str, Any],
    ) -> dict[str, Any]:
        """
        Open a job after the buyer has sent USDC.
        The seller will pick this up via poll_pending().

        Returns the created job dict.
        """
        return self._request(
            "POST",
            "/api/jobs",
            json={
                "buyerAgentId": buyer_agent_id,
                "sellerAgentId": seller_agent_id,
                "serviceId": service_id,
                "txHash": tx_hash,
                "amountUsdc": amount_usdc,
                "taskPayload": task_payload,
            },
        )

    def get_job_by_tx(self, tx_hash: str) -> dict[str, Any]:
        """
        Poll for a job result by its USDC payment txHash.
        Buyer calls this to check if the seller has completed the task.

        Returns the job dict. Check job["status"]:
          "pending"   — seller hasn't finished yet
          "completed" — encrypted_result and reputation_signature are ready
          "failed"    — seller didn't respond (timeout or error)
        """
        return self._request("GET", f"/api/jobs/by-tx/{tx_hash}")

    def mark_job_failed(self, job_id: str, buyer_agent_id: str) -> None:
        """
        Mark a job as failed. Buyer calls this after a timeout.
        """
        self._request(
            "POST",
            f"/api/jobs/{job_id}/fail",
            json={"buyerAgentId": buyer_agent_id},
        )

    # ── Seller ────────────────────────────────────────────────────────────────

    def poll_pending(self, seller_agent_id: str) -> list[dict[str, Any]]:
        """
        Fetch all pending jobs for this seller.
        Seller SDK calls this in a loop to find new work.

        Returns a list of job dicts, each with:
          - id, tx_hash, amount_usdc, task_payload, buyer_agent_id, service_id
        """
        return self._request(
            "GET",
            "/api/jobs/pending",
            params={"sellerAgentId": seller_agent_id},
        )

    def complete_job(
        self,
        job_id: str,
        seller_agent_id: str,
        encrypted_result: str,
        reputation_signature: str,
        approved_rating: str,
    ) -> dict[str, Any]:
        """
        Mark a job as complete and store the result + reputation signature.
        Buyer will pick these up via get_job_by_tx().

        Args:
            job_id:               The job UUID.
            seller_agent_id:      Seller's agent ID (used for auth on the route).
            encrypted_result:     The task result (encrypt with buyer's pubkey).
            reputation_signature: Hex signature for AgentReputation.rateAgent().
            approved_rating:      "5" (or lower, agreed during receipt signing).

        Returns the updated job dict.
        """
        return self._request(
            "POST",
            f"/api/jobs/{job_id}/complete",
            json={
                "sellerAgentId": seller_agent_id,
                "encryptedResult": encrypted_result,
                "reputationSignature": reputation_signature,
                "approvedRating": approved_rating,
            },
        )