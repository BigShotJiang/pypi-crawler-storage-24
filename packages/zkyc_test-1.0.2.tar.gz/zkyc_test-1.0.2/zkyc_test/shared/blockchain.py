"""
On-chain reads for AgentRegistry and AgentReputation contracts.
"""

from web3 import Web3


class BlockchainError(Exception):
    pass


REGISTRY_ABI = [
    {
        "name": "agents",
        "type": "function",
        "stateMutability": "view",
        "inputs": [{"name": "id", "type": "uint256"}],
        "outputs": [
            {"name": "agentId", "type": "uint256"},
            {"name": "owner", "type": "address"},
            {"name": "metadataURI", "type": "string"},
            {"name": "isKYCValid", "type": "bool"},
            {"name": "createdAt", "type": "uint256"},
        ],
    },
    {
        "name": "isAgentValid",
        "type": "function",
        "stateMutability": "view",
        "inputs": [{"name": "agentId", "type": "uint256"}],
        "outputs": [
            {"name": "exists", "type": "bool"},
            {"name": "isKYCValid", "type": "bool"},
        ],
    },
]

REPUTATION_ABI = [
    {
        "name": "rateAgent",
        "type": "function",
        "stateMutability": "nonpayable",
        "inputs": [
            {"name": "agentId", "type": "uint256"},
            {"name": "txHash", "type": "bytes32"},
            {"name": "rating", "type": "uint8"},
            {"name": "signature", "type": "bytes"},
        ],
        "outputs": [],
    },
    {
        "name": "getAverageRating",
        "type": "function",
        "stateMutability": "view",
        "inputs": [{"name": "agentId", "type": "uint256"}],
        "outputs": [{"name": "", "type": "uint256"}],
    },
]


class BlockchainClient:
    """
    Thin wrapper around AgentRegistry and AgentReputation contracts.
    """

    def __init__(self, rpc_url: str, registry_address: str, reputation_address: str):
        self._w3 = Web3(Web3.HTTPProvider(rpc_url))
        if not self._w3.is_connected():
            raise BlockchainError(
                f"Failed to connect to RPC at '{rpc_url}'. "
                f"Check that your rpc_url is correct and the network is reachable. "
                f"For Sepolia testnet use: https://sepolia.base.org"
            )
        if not self._w3.is_connected():
            raise BlockchainError(f"Failed to connect to RPC: {rpc_url}")

        self._registry = self._w3.eth.contract(
            address=Web3.to_checksum_address(registry_address),
            abi=REGISTRY_ABI,
        )
        self._reputation = self._w3.eth.contract(
            address=Web3.to_checksum_address(reputation_address),
            abi=REPUTATION_ABI,
        )

    def is_agent_valid(self, agent_id: str) -> tuple[bool, bool]:
        """
        Returns (exists, is_kyc_valid) from the registry contract.
        """
        try:
            exists, is_kyc_valid = self._registry.functions.isAgentValid(
                int(agent_id)
            ).call()
            return exists, is_kyc_valid
        except Exception as e:
            raise BlockchainError(f"isAgentValid call failed: {e}")

    def get_agent_metadata_uri(self, agent_id: str) -> str:
        """
        Returns the metadataURI stored on-chain for an agent.
        This is the URL the SDK fetches to get actions/prices.
        """
        try:
            result = self._registry.functions.agents(int(agent_id)).call()
            # result = (agentId, owner, metadataURI, isKYCValid, createdAt)
            return result[2]
        except Exception as e:
            raise BlockchainError(f"agents() call failed: {e}")

    def get_agent_owner(self, agent_id: str) -> str:
        """Returns the owner wallet address of an agent."""
        try:
            result = self._registry.functions.agents(int(agent_id)).call()
            return result[1]
        except Exception as e:
            raise BlockchainError(f"agents() call failed: {e}")

    def get_average_rating(self, agent_id: str) -> float:
        """
        Returns the agent's average rating as a float (e.g. 4.8).
        The contract returns rating * 100 as a uint256 to avoid decimals.
        """
        try:
            raw = self._reputation.functions.getAverageRating(
                int(agent_id)
            ).call()
            return raw / 100.0
        except Exception as e:
            raise BlockchainError(f"getAverageRating call failed: {e}")

    def submit_rating(
        self,
        private_key: str,
        agent_id: str,
        tx_hash_hex: str,
        rating: int,
        signature: bytes,
        gas_limit: int = 200_000,
    ) -> str:
        """
        Submit a reputation rating on-chain.
        Calls AgentReputation.rateAgent().

        Args:
            private_key:  Buyer's private key.
            agent_id:     Seller's on-chain agent ID.
            tx_hash_hex:  The USDC payment tx hash (0x-prefixed hex string).
            rating:       1-5 integer.
            signature:    The bytes signature from the seller's receipt.

        Returns:
            The rating transaction hash.
        """
        try:
            acct = self._w3.eth.account.from_key(private_key)

            # Convert tx hash hex string → bytes32
            tx_hash_bytes = bytes.fromhex(tx_hash_hex.removeprefix("0x"))
            tx_hash_bytes32 = tx_hash_bytes.ljust(32, b"\x00")[:32]

            tx = self._reputation.functions.rateAgent(
                int(agent_id),
                tx_hash_bytes32,
                rating,
                signature,
            ).build_transaction(
                {
                    "from": acct.address,
                    "nonce": self._w3.eth.get_transaction_count(acct.address),
                    "gas": gas_limit,
                    "gasPrice": self._w3.eth.gas_price,
                    "chainId": self._w3.eth.chain_id,
                }
            )

            signed = acct.sign_transaction(tx)
            tx_hash = self._w3.eth.send_raw_transaction(signed.raw_transaction)
            receipt = self._w3.eth.wait_for_transaction_receipt(tx_hash, timeout=120)

            if receipt["status"] != 1:
                raise BlockchainError("Rating transaction reverted on-chain")

            return tx_hash.hex()
        except BlockchainError:
            raise
        except Exception as e:
            raise BlockchainError(f"submit_rating failed: {e}")