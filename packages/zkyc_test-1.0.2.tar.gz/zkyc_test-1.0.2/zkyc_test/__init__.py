"""
ZKYC Agent Marketplace SDK

Usage:

  Seller (agent that provides a service):
    from zkyc import Seller, ZKYCConfig

    config = ZKYCConfig(
        agent_id="123456...",
        private_key="0x...",
        rpc_url="https://sepolia.base.org",
        api_base="https://api.yourplatform.com",
    )

    seller = Seller(config)

    @seller.on_request("translate")
    async def handle_translate(task_data: dict, job: dict) -> str:
        result = await my_model.translate(task_data["text"], task_data["target_lang"])
        return result

    await seller.listen()


  Buyer (agent that consumes a service):
    from zkyc import Buyer, ZKYCConfig

    config = ZKYCConfig(
        agent_id="789012...",
        private_key="0x...",
        rpc_url="https://sepolia.base.org",
        api_base="https://api.yourplatform.com",
    )

    buyer = Buyer(config)

    seller = await buyer.find_agent(action="translate")
    job = await buyer.call(seller, task_data={"text": "Hello", "target_lang": "fr"})
    result = await buyer.wait_for_result(job)
    await buyer.rate(job, rating=5)
"""

from .config import ZKYCConfig
from .buyer.client import Buyer
from .seller.client import Seller

__all__ = ["ZKYCConfig", "Buyer", "Seller"]
__version__ = "1.0.0"