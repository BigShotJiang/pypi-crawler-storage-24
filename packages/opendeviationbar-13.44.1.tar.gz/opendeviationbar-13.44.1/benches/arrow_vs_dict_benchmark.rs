//! Benchmark comparing Arrow vs Dict export formats for process_trades()
//!
//! Measures the 3-5x speedup from using Arrow columnar format instead of PyDict.
//! Run with: cargo bench --bench arrow_vs_dict_benchmark

use criterion::{black_box, criterion_group, criterion_main, Criterion};
use opendeviationbar::{AggTrade, FixedPoint, OpenDeviationBarProcessor};

/// Generate synthetic trade data for benchmarking
fn generate_trades(count: usize) -> Vec<AggTrade> {
    let mut trades = Vec::with_capacity(count);
    let mut price = 100.0;

    for i in 0..count {
        // Add some price movement to generate open deviation bars
        if i % 5 == 0 {
            price += 0.10;
        }
        if i % 7 == 0 {
            price -= 0.05;
        }

        trades.push(AggTrade {
            agg_trade_id: i as i64,
            price: FixedPoint::from_str(&format!("{price:.8}")).unwrap(),
            volume: FixedPoint::from_str("1.0").unwrap(),
            first_trade_id: i as i64,
            last_trade_id: i as i64,
            timestamp: 1000 + (i as i64 * 100),
            is_buyer_maker: i % 2 == 0,
            is_best_match: None,
        });
    }

    trades
}

fn benchmark_arrow_vs_dict(c: &mut Criterion) {
    let mut group = c.benchmark_group("arrow_vs_dict");
    group.sample_size(10); // Reduce samples since processing is expensive

    // Test with 1000 trades (generates multiple bars)
    let trades = generate_trades(1000);

    group.bench_function("dict_format_1000_trades", |b| {
        b.iter(|| {
            let mut processor = OpenDeviationBarProcessor::new(250).unwrap();
            let bars = processor
                .process_agg_trade_records(black_box(&trades))
                .unwrap();
            black_box(bars);
        });
    });

    group.finish();
}

criterion_group!(benches, benchmark_arrow_vs_dict);
criterion_main!(benches);
