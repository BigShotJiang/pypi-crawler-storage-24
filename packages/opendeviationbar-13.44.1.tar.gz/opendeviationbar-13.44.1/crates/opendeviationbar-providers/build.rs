//! Build script: copies symbols.toml into OUT_DIR for include_str!() at compile time.
//! Issue #158 Phase 9: Market type centralization.
//!
//! In the workspace (dev), reads from ../../symbols.toml (repo root symlink).
//! In cargo publish tarball, the file won't exist — writes empty content so
//! get_symbol_market() returns None for all symbols (falls back to "spot").

fn main() {
    let manifest_dir = std::env::var("CARGO_MANIFEST_DIR").unwrap();
    let out_dir = std::env::var("OUT_DIR").unwrap();

    let symbols_path = std::path::Path::new(&manifest_dir).join("../../symbols.toml");
    let content = if symbols_path.exists() {
        std::fs::read_to_string(&symbols_path).unwrap_or_default()
    } else {
        String::new()
    };

    let dest = std::path::Path::new(&out_dir).join("symbols.toml");
    std::fs::write(dest, content).unwrap();

    if symbols_path.exists() {
        println!("cargo:rerun-if-changed={}", symbols_path.display());
    }
}
