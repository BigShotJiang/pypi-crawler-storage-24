//! Parallel aggTrades fetching for sub-3s gap recovery (Issue #257).
//!
//! Fetches multiple pages of aggTrades concurrently using `tokio::JoinSet`
//! with a semaphore to bound concurrency. Pages are reassembled in
//! `agg_trade_id` order before returning — the processor is strictly
//! order-sensitive and relies on monotonic trade IDs.
//!
//! # Early Termination (Issue #297)
//!
//! When a page returns fewer trades than `PAGE_SIZE`, an `AtomicBool` flag
//! signals all pending tasks to skip their HTTP call. This avoids wasting
//! API weight on pages beyond available data — critical for `fill_from_rest`
//! where `chunk_to` is speculative (current_from + 50K) and the real data
//! boundary is unknown.
//!
//! # Performance
//!
//! Sequential: 50K trades = ~50 REST calls × 500ms ≈ 25s
//! Parallel (5 concurrent): 50K trades = ~10 batches × 500ms ≈ 5s
//! Target: sub-3s for typical reconnection gaps (~5-10K trades)

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use tokio::sync::Semaphore;
use tokio::task::JoinSet;
use tracing::{debug, info};

use opendeviationbar_core::AggTrade;

use super::historical::HistoricalDataLoader;
use super::rate_limiter::AdaptiveRateLimiter;

/// Default concurrency for parallel fetch (number of simultaneous REST calls).
/// Reduced from 5→3 (#297): with 4 symbols filling concurrently (Semaphore(4)),
/// 4×3=12 simultaneous HTTP calls vs 4×5=20. Smooths burst weight consumption
/// against the 4800/min Binance budget. Rate limiter is the binding constraint.
const DEFAULT_CONCURRENCY: usize = 3;

/// Binance aggTrades page size (maximum per REST call).
const PAGE_SIZE: i64 = 1000;

/// Fetch aggTrades in parallel across multiple pages.
///
/// Pages are fetched concurrently (up to `concurrency` at a time) and
/// reassembled in ascending `agg_trade_id` order before returning.
///
/// # Arguments
///
/// * `symbol` - Trading pair (e.g., "BTCUSDT")
/// * `from_id` - First trade ID to fetch (inclusive)
/// * `to_id` - Upper bound trade ID (exclusive) — trades with id >= to_id are excluded
/// * `rate_limiter` - Shared rate limiter for Binance REST API budget
/// * `concurrency` - Maximum concurrent REST calls (None = DEFAULT_CONCURRENCY)
///
/// # Returns
///
/// Sorted `Vec<AggTrade>` with contiguous trade IDs in `[from_id, to_id)`.
///
/// # Errors
///
/// Returns error if any page fetch fails. Partial results are NOT returned —
/// callers should handle the error and potentially retry or defer to kintsugi.
pub async fn fetch_aggtrades_parallel(
    symbol: &str,
    from_id: i64,
    to_id: i64,
    rate_limiter: Option<Arc<AdaptiveRateLimiter>>,
    concurrency: Option<usize>,
) -> Result<Vec<AggTrade>, super::historical::HistoricalError> {
    let concurrency = concurrency.unwrap_or(DEFAULT_CONCURRENCY);
    let total_trades = to_id - from_id;

    if total_trades <= 0 {
        return Ok(Vec::new());
    }

    // For small gaps, just fetch sequentially (overhead of JoinSet not worth it)
    if total_trades <= PAGE_SIZE {
        let loader = match &rate_limiter {
            Some(rl) => HistoricalDataLoader::new(symbol).with_rate_limiter(Arc::clone(rl)),
            None => HistoricalDataLoader::new(symbol),
        };
        let limit = total_trades.min(1000) as u16;
        let mut trades = loader.fetch_aggtrades_by_id(from_id, limit).await?;
        // Trim to requested range
        trades.retain(|t| t.agg_trade_id >= from_id && t.agg_trade_id < to_id);
        return Ok(trades);
    }

    // Calculate page boundaries
    let mut page_starts: Vec<i64> = Vec::new();
    let mut start = from_id;
    while start < to_id {
        page_starts.push(start);
        start += PAGE_SIZE;
    }

    let num_pages = page_starts.len();
    info!(
        symbol,
        from_id,
        to_id,
        total_trades,
        num_pages,
        concurrency,
        "starting parallel aggTrades fetch"
    );

    let semaphore = Arc::new(Semaphore::new(concurrency));
    let mut join_set = JoinSet::new();

    // Issue #297: Early termination flag. Set when a page returns fewer trades
    // than requested (short page = end of available data). Tasks that haven't
    // started their HTTP call yet will bail out, saving API weight.
    let early_stop = Arc::new(AtomicBool::new(false));

    for (page_idx, page_start) in page_starts.into_iter().enumerate() {
        let permit = Arc::clone(&semaphore);
        let rate_limiter = rate_limiter.clone();
        let symbol = symbol.to_string();
        let limit = ((to_id - page_start).min(PAGE_SIZE)) as u16;
        let early_stop = Arc::clone(&early_stop);

        join_set.spawn(async move {
            // Check early-stop BEFORE acquiring semaphore permit.
            // Tasks queued behind the semaphore bail out immediately
            // when an earlier page signals end-of-data.
            if early_stop.load(Ordering::Acquire) {
                debug!(
                    symbol = %symbol,
                    page_idx,
                    page_start,
                    "parallel fetch page skipped (early termination)"
                );
                return Ok::<(usize, Vec<AggTrade>, bool), super::historical::HistoricalError>(
                    (page_idx, Vec::new(), true),
                );
            }

            let _permit = permit.acquire().await.expect("semaphore closed");

            // Re-check after acquiring permit — another in-flight page may
            // have signalled stop while we waited.
            if early_stop.load(Ordering::Acquire) {
                debug!(
                    symbol = %symbol,
                    page_idx,
                    page_start,
                    "parallel fetch page skipped after permit (early termination)"
                );
                return Ok((page_idx, Vec::new(), true));
            }

            // Note: rate limiting is handled inside fetch_aggtrades_by_id via
            // send_with_rate_limit_backoff(), so we do NOT acquire separately here.
            let loader = match &rate_limiter {
                Some(rl) => HistoricalDataLoader::new(&symbol).with_rate_limiter(Arc::clone(rl)),
                None => HistoricalDataLoader::new(&symbol),
            };

            let trades = loader.fetch_aggtrades_by_id(page_start, limit).await?;
            let fetched = trades.len();

            // Signal early stop if this page returned fewer trades than the
            // requested limit — we've reached the end of available data.
            // Also stop on empty pages (no data at this trade-ID range).
            let is_short_page = (fetched as u16) < limit;
            if is_short_page {
                early_stop.store(true, Ordering::Release);
                debug!(
                    symbol = %symbol,
                    page_idx,
                    page_start,
                    trades_fetched = fetched,
                    limit,
                    "parallel fetch: short page detected, signalling early termination"
                );
            } else {
                debug!(
                    symbol = %symbol,
                    page_idx,
                    page_start,
                    trades_fetched = fetched,
                    "parallel fetch page complete"
                );
            }

            Ok((page_idx, trades, false))
        });
    }

    // Collect all pages
    let mut pages: Vec<(usize, Vec<AggTrade>)> = Vec::with_capacity(num_pages);
    let mut pages_skipped: usize = 0;
    while let Some(result) = join_set.join_next().await {
        match result {
            Ok(Ok((idx, trades, skipped))) => {
                if skipped {
                    pages_skipped += 1;
                } else {
                    pages.push((idx, trades));
                }
            }
            Ok(Err(e)) => {
                // Abort remaining tasks on any page failure
                join_set.abort_all();
                return Err(e);
            }
            Err(e) => {
                join_set.abort_all();
                return Err(super::historical::HistoricalError::RestApiError(format!(
                    "parallel fetch task panicked: {e}"
                )));
            }
        }
    }

    if pages_skipped > 0 {
        info!(
            symbol,
            pages_skipped,
            pages_fetched = pages.len(),
            num_pages,
            weight_saved = pages_skipped * 4, // 4 weight per aggTrades call
            "parallel fetch: early termination saved API weight"
        );
    }

    // CRITICAL (P3): Reassemble in page order (ascending agg_trade_id)
    pages.sort_by_key(|(idx, _)| *idx);

    // Flatten and trim to requested range
    let mut all_trades: Vec<AggTrade> = Vec::with_capacity(total_trades as usize);
    for (_, mut page_trades) in pages {
        page_trades.retain(|t| t.agg_trade_id >= from_id && t.agg_trade_id < to_id);
        all_trades.extend(page_trades);
    }

    // Dedup by agg_trade_id (handles overlapping page boundaries)
    all_trades.sort_by_key(|t| t.agg_trade_id);
    all_trades.dedup_by_key(|t| t.agg_trade_id);

    info!(
        symbol,
        from_id,
        to_id,
        trades_fetched = all_trades.len(),
        num_pages,
        "parallel aggTrades fetch complete"
    );

    Ok(all_trades)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_page_boundary_calculation() {
        // 2500 trades = 3 pages: [0, 1000), [1000, 2000), [2000, 2500)
        let from_id = 100;
        let to_id = 2600;
        let total = to_id - from_id;

        let mut starts = Vec::new();
        let mut start = from_id;
        while start < to_id {
            starts.push(start);
            start += PAGE_SIZE;
        }

        assert_eq!(starts.len(), 3);
        assert_eq!(starts[0], 100);
        assert_eq!(starts[1], 1100);
        assert_eq!(starts[2], 2100);
        assert_eq!(total, 2500);
    }

    #[test]
    fn test_small_gap_no_parallel() {
        // Gaps <= 1000 trades should NOT use JoinSet
        let total = PAGE_SIZE;
        assert!(total <= PAGE_SIZE); // Should use single fetch path
    }

    #[tokio::test]
    async fn test_empty_range() {
        let result = fetch_aggtrades_parallel("BTCUSDT", 100, 100, None, None).await;
        assert!(result.is_ok());
        assert!(result.unwrap().is_empty());
    }

    #[tokio::test]
    async fn test_negative_range() {
        let result = fetch_aggtrades_parallel("BTCUSDT", 200, 100, None, None).await;
        assert!(result.is_ok());
        assert!(result.unwrap().is_empty());
    }

    #[test]
    fn test_early_stop_flag_semantics() {
        // Verify AtomicBool correctly signals across threads
        let flag = Arc::new(AtomicBool::new(false));

        assert!(!flag.load(Ordering::Acquire));
        flag.store(true, Ordering::Release);
        assert!(flag.load(Ordering::Acquire));
    }

    #[test]
    fn test_short_page_detection() {
        // A page returning fewer trades than requested signals end-of-data
        let limit: u16 = 1000;

        // Full page (1000 trades) — should NOT trigger early stop
        let fetched_full: u16 = 1000;
        assert!(!(fetched_full < limit));

        // Short page (500 trades) — SHOULD trigger early stop
        let fetched_short: u16 = 500;
        assert!(fetched_short < limit);

        // Empty page (0 trades) — SHOULD trigger early stop
        let fetched_empty: u16 = 0;
        assert!(fetched_empty < limit);
    }

    #[test]
    fn test_pages_skipped_weight_savings() {
        // With 50 pages pre-computed and data ending at page 10,
        // 40 pages are skipped = 40 * 4 = 160 weight saved per chunk
        let num_pages = 50;
        let pages_with_data = 10;
        let pages_skipped = num_pages - pages_with_data;
        let weight_per_call = 4; // Binance spot aggTrades endpoint weight

        assert_eq!(pages_skipped, 40);
        assert_eq!(pages_skipped * weight_per_call, 160);
    }
}
