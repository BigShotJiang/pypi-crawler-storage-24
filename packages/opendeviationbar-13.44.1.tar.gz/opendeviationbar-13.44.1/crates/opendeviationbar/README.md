# opendeviationbar (meta-crate)

Unified interface for the opendeviationbar workspace with backward compatibility for v4.0.0 API.

## Overview

The `opendeviationbar` meta-crate provides a unified entry point to all opendeviationbar functionality by re-exporting all sub-crates. It also maintains backward compatibility with the v4.0.0 monolithic API through legacy module paths.

## Quick Start

```rust
use opendeviationbar::prelude::*;

// Core types and algorithm
let mut processor = OpenDeviationBarProcessor::new(250)?; // 250 dbps = 0.25%
let bars = processor.process_agg_trade_records(&trades)?;

// Data providers
let loader = HistoricalDataLoader::new("BTCUSDT");
let trades = loader.load_recent_day().await?;

// Export to multiple formats
let exporter = PolarsExporter::new();
exporter.export_parquet(&bars, "output.parquet")?;
```

## Module Structure

### Direct Crate Access

```rust
use opendeviationbar::core::*;          // opendeviationbar-core
use opendeviationbar::providers::*;     // opendeviationbar-providers
use opendeviationbar::config::*;        // opendeviationbar-config
use opendeviationbar::io::*;            // opendeviationbar-io
use opendeviationbar::streaming::*;     // opendeviationbar-streaming
use opendeviationbar::batch::*;         // opendeviationbar-batch
```

### Legacy v4.0.0 Compatibility

For backward compatibility with existing code:

```rust
// Legacy module paths (v4.0.0)
use opendeviationbar::fixed_point::FixedPoint;
use opendeviationbar::open_deviation_bars::ExportOpenDeviationBarProcessor;
use opendeviationbar::types::{AggTrade, OpenDeviationBar};
use opendeviationbar::tier1::{get_tier1_symbols, get_tier1_usdt_pairs};
use opendeviationbar::data::HistoricalDataLoader;
```

## Feature Flags

The meta-crate supports optional features for selective compilation:

```toml
[dependencies]
opendeviationbar = { version = "6.1.0", features = ["full"] }
```

### Available Features

- **`core`** (default): Core algorithm and types
- **`providers`**: Data providers (Binance, Exness)
- **`config`**: Configuration management
- **`io`**: Export formats and Polars integration
- **`streaming`**: Real-time streaming processor
- **`batch`**: Batch analytics engine
- **`full`**: All features enabled

### Feature Combinations

```toml
# Minimal: Core algorithm only
opendeviationbar = { version = "6.1.0" }

# Core + providers
opendeviationbar = { version = "6.1.0", features = ["providers"] }

# Core + providers + streaming
opendeviationbar = { version = "6.1.0", features = ["streaming"] }

# Everything
opendeviationbar = { version = "6.1.0", features = ["full"] }
```

## Architecture

The opendeviationbar workspace consists of 8 specialized crates:

### Core Crates

- **opendeviationbar-core**: Algorithm, types, fixed-point arithmetic
- **opendeviationbar-providers**: Binance, Exness data providers
- **opendeviationbar-config**: Configuration management
- **opendeviationbar-io**: Export formats, Polars integration

### Engine Crates

- **opendeviationbar-streaming**: Real-time streaming processor
- **opendeviationbar-batch**: Batch analytics engine

### Tools & Compatibility

- **opendeviationbar-cli**: Command-line tools
- **opendeviationbar**: This meta-crate (unified interface)

## Migrating from v4.0.0

The v5.0.0 release introduced a modular crate architecture. Your existing code should continue to work due to backward compatibility shims, but consider migrating to direct crate imports:

### Before (v4.0.0)

```rust
use opendeviationbar::fixed_point::FixedPoint;
use opendeviationbar::open_deviation_bars::ExportOpenDeviationBarProcessor;
use opendeviationbar::data::HistoricalDataLoader;
```

### After (v5.0.0)

```rust
use opendeviationbar_core::FixedPoint;
use opendeviationbar_core::OpenDeviationBarProcessor;
use opendeviationbar_providers::binance::HistoricalDataLoader;
```

**Migration Guide**: See `../../docs/planning/` for detailed migration instructions.

## Version

Current version: **6.1.0** (modular crate architecture with checkpoint system)

**Breaking Changes in v3.0.0**:

- Threshold values changed from 1 bps to 1 dbps units (multiply by 10)
- Example: 0.25% now requires `new(250)` instead of `new(25)`

## Common Use Cases

### Historical Analysis

```rust
use opendeviationbar::prelude::*;

// Load historical data
let loader = HistoricalDataLoader::new("BTCUSDT");
let trades = loader.load_historical_range(7).await?;

// Generate open deviation bars
let mut processor = OpenDeviationBarProcessor::new(250)?;
let bars = processor.process_agg_trade_records(&trades)?;

// Export to Parquet
let exporter = ParquetExporter::new();
exporter.export(&bars, "btcusdt_bars.parquet")?;
```

### Real-Time Streaming

```rust
use opendeviationbar::prelude::*;

let mut processor = StreamingProcessor::new(250)?;
let metrics = processor.process_stream(websocket_stream).await?;

println!("Processed {} trades", metrics.trades_processed);
```

### Multi-Symbol Batch Analysis

```rust
use opendeviationbar::prelude::*;

let engine = BatchAnalysisEngine::new();
let reports = engine.analyze_multiple_symbols(multi_symbol_data)?;
```

## Documentation

- **Architecture**: `../../docs/ARCHITECTURE.md`
- **Examples**: `../../examples/`
- **CLI Tools**: See `opendeviationbar-cli` crate
- **Individual Crates**: Each crate has its own README.md

## Dependencies

The meta-crate re-exports all workspace crates based on enabled features.

## License

See LICENSE file in the repository root.
