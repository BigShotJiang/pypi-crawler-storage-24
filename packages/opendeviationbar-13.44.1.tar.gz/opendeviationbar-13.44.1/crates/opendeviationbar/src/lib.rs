//! Non-lookahead open deviation bar construction for cryptocurrency and forex trading.
//!
//! [![Crates.io](https://img.shields.io/crates/v/opendeviationbar.svg)](https://crates.io/crates/opendeviationbar)
//! [![Documentation](https://docs.rs/opendeviationbar/badge.svg)](https://docs.rs/opendeviationbar)
//! [![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
//!
//! This crate provides algorithms for constructing open deviation bars from tick data
//! with temporal integrity guarantees, ensuring no lookahead bias in financial backtesting.
//!
//! ## Installation
//!
//! Add to your `Cargo.toml`:
//!
//! ```toml
//! [dependencies]
//! opendeviationbar = "6.1"
//! ```
//!
//! ## Meta-Crate
//!
//! This is a meta-crate that re-exports all opendeviationbar sub-crates for backward compatibility
//! with v4.0.0. New code should depend on specific sub-crates directly:
//!
//! - `opendeviationbar-core` - Core algorithm and types
//! - `opendeviationbar-providers` - Data providers (Binance, Exness)
//! - `opendeviationbar-config` - Configuration management
//! - `opendeviationbar-io` - I/O operations and Polars integration
//! - `opendeviationbar-streaming` - Real-time streaming processor
//! - `opendeviationbar-batch` - Batch analytics engine
//! - `opendeviationbar-cli` - Command-line tools
//!
//! ## Features
//!
//! - `core` - Core algorithm (always enabled)
//! - `providers` - Data providers (Binance, Exness)
//! - `config` - Configuration management
//! - `io` - I/O operations and Polars integration
//! - `streaming` - Real-time streaming processor
//! - `batch` - Batch analytics engine
//! - `full` - Enable all features
//!
//! ## Basic Usage
//!
//! ```rust
//! use opendeviationbar::{OpenDeviationBarProcessor, AggTrade, FixedPoint};
//!
//! // Create processor with 25 basis points threshold (0.25%)
//! let mut processor = OpenDeviationBarProcessor::new(250).unwrap();
//!
//! // Create sample aggTrade
//! let trade = AggTrade {
//!     agg_trade_id: 1,
//!     price: FixedPoint::from_str("50000.0").unwrap(),
//!     volume: FixedPoint::from_str("1.0").unwrap(),
//!     first_trade_id: 1,
//!     last_trade_id: 1,
//!     timestamp: 1609459200000,
//!     is_buyer_maker: false,
//!     is_best_match: None,
//! };
//!
//! // Process aggTrade records into open deviation bars
//! let agg_trade_records = vec![trade];
//! let bars = processor.process_agg_trade_records(&agg_trade_records).unwrap();
//! ```
//!
//! ## Dual-Path Architecture
//!
//! ### Streaming Mode (Real-time)
//! ```rust
//! # #[cfg(feature = "streaming")]
//! # {
//! use opendeviationbar::streaming::StreamingProcessor;
//!
//! let threshold_decimal_bps = 250; // 250 dbps = 0.25% open deviation bars
//! let processor = StreamingProcessor::new(threshold_decimal_bps);
//! // Real-time processing with bounded memory
//! # }
//! ```
//!
//! ### Batch Mode (Analytics)
//! ```rust
//! # #[cfg(feature = "batch")]
//! # {
//! use opendeviationbar::batch::BatchAnalysisEngine;
//! use opendeviationbar::core::types::OpenDeviationBar;
//!
//! let open_deviation_bars: Vec<OpenDeviationBar> = vec![]; // Your open deviation bar data
//! let engine = BatchAnalysisEngine::new();
//! // let result = engine.analyze_single_symbol(&open_deviation_bars, "BTCUSDT").unwrap();
//! # }
//! ```
//!
//! ## Links
//!
//! - [GitHub Repository](https://github.com/terrylica/opendeviationbar-py)
//! - [API Documentation](https://github.com/terrylica/opendeviationbar-py/blob/main/docs/api.md)
//! - [Changelog](https://github.com/terrylica/opendeviationbar-py/blob/main/CHANGELOG.md)
//! - [Core API Reference](https://github.com/terrylica/opendeviationbar-py/blob/main/docs/opendeviationbar_core_api.md)

// Re-export core (always available)
pub use opendeviationbar_core as core;

// Re-export optional crates
#[cfg(feature = "providers")]
pub use opendeviationbar_providers as providers;

#[cfg(feature = "config")]
pub use opendeviationbar_config as config;

#[cfg(feature = "io")]
pub use opendeviationbar_io as io;

#[cfg(feature = "streaming")]
pub use opendeviationbar_streaming as streaming;

#[cfg(feature = "batch")]
pub use opendeviationbar_batch as batch;

// Legacy compatibility modules for v4.0.0 API
pub mod fixed_point {
    //! Fixed-point arithmetic module (legacy compatibility)
    pub use opendeviationbar_core::fixed_point::*;
}

pub mod open_deviation_bars {
    //! Open deviation bar processor module (legacy compatibility)
    pub use opendeviationbar_core::processor::*;
}

pub mod types {
    //! Core types module (legacy compatibility)
    pub use opendeviationbar_core::types::*;
}

#[cfg(feature = "providers")]
pub mod tier1 {
    //! Tier-1 symbol discovery (legacy compatibility)
    pub use opendeviationbar_providers::binance::symbols::*;
}

#[cfg(feature = "providers")]
pub mod data {
    //! Historical data loading (legacy compatibility)
    pub use opendeviationbar_providers::binance::HistoricalDataLoader;
}

#[cfg(feature = "config")]
pub mod infrastructure {
    //! Infrastructure modules (legacy compatibility)

    #[cfg(feature = "config")]
    pub use opendeviationbar_config as config;

    #[cfg(feature = "io")]
    pub use opendeviationbar_io as io;
}

#[cfg(feature = "streaming")]
pub mod engines {
    //! Engine modules (legacy compatibility)

    #[cfg(feature = "streaming")]
    pub use opendeviationbar_streaming as streaming;

    #[cfg(feature = "batch")]
    pub use opendeviationbar_batch as batch;
}

// Re-export commonly used types at crate root for convenience
pub use opendeviationbar_core::{
    AggTrade, ExportOpenDeviationBarProcessor, FixedPoint, OpenDeviationBar,
    OpenDeviationBarProcessor, ProcessingError,
};

#[cfg(feature = "config")]
pub use opendeviationbar_config::Settings;

#[cfg(feature = "providers")]
pub use opendeviationbar_providers::binance::{
    TIER1_SYMBOLS, get_tier1_symbols, get_tier1_usdt_pairs, is_tier1_symbol,
};

#[cfg(feature = "streaming")]
pub use opendeviationbar_streaming::processor::{
    StreamingError, StreamingMetrics, StreamingProcessor, StreamingProcessorConfig,
};

#[cfg(feature = "batch")]
pub use opendeviationbar_batch::{AnalysisReport, BatchAnalysisEngine, BatchConfig, BatchResult};

// Re-export I/O types when feature is enabled
#[cfg(feature = "io")]
pub use opendeviationbar_io::{
    ArrowExporter, ParquetExporter, PolarsExporter, StreamingCsvExporter,
};

/// Version information
pub const VERSION: &str = env!("CARGO_PKG_VERSION");
pub const NAME: &str = env!("CARGO_PKG_NAME");
pub const DESCRIPTION: &str = env!("CARGO_PKG_DESCRIPTION");

/// Library initialization and configuration
pub fn init() {
    // Future: Initialize logging, metrics, etc.
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_version() {
        assert!(!VERSION.is_empty());
        assert!(!NAME.is_empty());
        assert!(!DESCRIPTION.is_empty());
    }

    #[test]
    fn test_types_export() {
        // Test that we can create and use exported types
        let fp = FixedPoint::from_str("123.456").unwrap();
        assert_eq!(fp.to_string(), "123.45600000");
    }

    #[test]
    fn test_legacy_fixed_point_module() {
        // Test backward compatibility via legacy module path
        let fp = fixed_point::FixedPoint::from_str("100.0").unwrap();
        assert_eq!(fp.to_string(), "100.00000000");
    }

    #[test]
    fn test_legacy_types_module() {
        // Test backward compatibility via legacy types module
        use types::DataSource;
        let _data_source = DataSource::BinanceSpot;
    }

    #[cfg(feature = "providers")]
    #[test]
    fn test_tier1_symbols_export() {
        // Test that tier1 symbols are accessible
        let symbols = get_tier1_symbols();
        assert!(!symbols.is_empty());
        assert!(symbols.contains(&"BTC".to_string()));
    }

    #[cfg(feature = "config")]
    #[test]
    fn test_settings_export() {
        // Test that Settings type is accessible
        let settings = Settings::default();
        assert!(!settings.app.name.is_empty());
    }

    #[cfg(feature = "providers")]
    #[test]
    fn test_data_module_export() {
        // Test backward compatibility via legacy data module path
        // This verifies that `use opendeviationbar::data::HistoricalDataLoader` works
        use data::HistoricalDataLoader;

        // Just verify the type is accessible
        let _loader = HistoricalDataLoader::new("BTCUSDT");
    }
}
