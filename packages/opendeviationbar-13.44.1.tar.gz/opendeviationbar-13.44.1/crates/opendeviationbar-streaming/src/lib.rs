//! Real-time streaming engine for open deviation bar processing
//!
//! This module provides real-time streaming capabilities for processing
//! open deviation bars from live data sources with support for replay, statistics,
//! and indicators.

pub mod processor;
pub mod replay_buffer;
pub mod ring_buffer; // Issue #96 Task #9: Fixed-size ring buffer for streaming

// Issue #178: Unified hot-path/cold-path engine (three-trait architecture)
#[cfg(feature = "binance-integration")]
pub mod engine;

#[cfg(feature = "stats")]
pub mod stats;

#[cfg(feature = "indicators")]
pub mod indicators;

// Issue #91: Live bar engine for real-time streaming sidecar
#[cfg(feature = "binance-integration")]
pub mod live_engine;

// Issue #257: Gap detection and fill infrastructure
#[cfg(feature = "binance-integration")]
pub mod gap;

// Issue #161: StreamManager with rate-limited gap-fill and trade-ID continuity
#[cfg(feature = "binance-integration")]
pub mod stream_manager;

#[cfg(feature = "binance-integration")]
pub mod universal;

// Re-export commonly used types
pub use processor::StreamingProcessor;
pub use replay_buffer::{ReplayBuffer, ReplayBufferStats};

#[cfg(feature = "stats")]
pub use stats::{StatisticsSnapshot, StreamingConfig, StreamingStatsEngine};

#[cfg(feature = "indicators")]
pub use indicators::{
    CCI, ExponentialMovingAverage, IndicatorError, MACD, MACDValue, RSI, SimpleMovingAverage,
};

#[cfg(feature = "binance-integration")]
pub use live_engine::{
    CompletedBar, FormingBar, FormingBarWatches, LiveBarEngine, LiveEngineConfig,
    LiveEngineMetrics,
};

// Issue #257: Gap detection and fill re-exports
#[cfg(feature = "binance-integration")]
pub use gap::{
    GapEvent, GapFillCommand, GapFillReceiver, GapFillResult, GapFillSender, TradeIdGapDetector,
    gap_fill_channel,
};

// Issue #161: StreamManager re-exports
#[cfg(feature = "binance-integration")]
pub use stream_manager::{StreamManager, StreamManagerConfig, StreamManagerMetrics};

#[cfg(feature = "binance-integration")]
pub use universal::{StreamError, StreamMode, TradeStream, UniversalStream};

// Issue #178: Unified engine re-exports
#[cfg(feature = "binance-integration")]
pub use engine::{
    BarSink, BarSource, ChannelSink, EngineClock, HistoricalClock, LiveBarSource, LiveClock,
    OdbEngine, SinkError, SourceCheckpoint,
};
