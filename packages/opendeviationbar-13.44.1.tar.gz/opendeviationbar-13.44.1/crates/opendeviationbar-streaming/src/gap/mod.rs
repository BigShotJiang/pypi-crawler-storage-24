//! Gap detection and fill infrastructure for real-time streaming (Issue #257).
//!
//! Provides event-driven gap detection with channel-based notification,
//! enabling Python consumers (sidecar, FlowSurface) to react to trade-ID
//! discontinuities in sub-3s.

mod command;
mod detector;
mod event;

pub use command::{GapFillCommand, GapFillReceiver, GapFillResult, GapFillSender, gap_fill_channel};
pub use detector::TradeIdGapDetector;
pub use event::GapEvent;
