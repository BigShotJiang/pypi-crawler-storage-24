//! Unified hot-path/cold-path engine (Issue #178)
//!
//! Three-trait architecture for swappable source/sink composition:
//! - `BarSource`: async bar producer (live WS, replay, Vision)
//! - `BarSink`: synchronous bar consumer (channel, SSE, strategy)
//! - `EngineClock`: time abstraction (live wall clock, historical event time)

pub mod clock;
pub mod odb_engine;
pub mod sink_channel;
pub mod source_live;
pub mod traits;

pub use clock::{HistoricalClock, LiveClock};
pub use odb_engine::OdbEngine;
pub use sink_channel::ChannelSink;
pub use source_live::LiveBarSource;
pub use traits::{BarSink, BarSource, EngineClock, SinkError, SourceCheckpoint};
