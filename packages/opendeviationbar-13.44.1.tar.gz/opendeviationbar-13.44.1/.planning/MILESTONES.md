# Milestones

## v1.4 v1.4 (Shipped: 2026-03-21)

**Phases completed:** 3 phases, 6 plans, 11 tasks

**Key accomplishments:**

- Added last_completed_bar_tid field to OpenDeviationBarProcessor and Checkpoint, tracking completed bar trade IDs separately from forming bar tail for dedup floor initialization
- Fixed committed_floors dedup floor to use last_completed_bar_tid instead of last_agg_trade_id, eliminating junction bar suppression at REST-to-WS transition
- Binance REST midnight crossover query and ClickHouse orphan verification for Stathera continuity at day boundaries
- \_run_midnight_preflight() orchestrator wired into \_create_engine(), overriding CH seeds with verified crossover trade IDs for zero-gap midnight boundaries
- Unified per-symbol Stathera continuity check replacing intra-day/adjacent-day classification, with LOUD Telegram alert on new today gaps
- Per-symbol yesterday orphan completion via crossover TID validation, junction telemetry from sidecar HTTP+journal, both visible in Telegram heartbeat

---

## v1.4 Zero-Gap Zero-Overlap Guarantee (In Progress)

**Goal:** Eliminate ALL Stathera gaps and overlaps -- both intra-day junction gaps (committed_floors bug) and midnight boundary gaps (multi-processor seam) -- with full telemetry to validate.

**Phases:** 3 phases

| Phase | Name                            | Requirements     |
| ----- | ------------------------------- | ---------------- |
| 1     | Dedup Floor Fix                 | RUST-01, RUST-02 |
| 2     | Midnight Preflight Verification | PREFLIGHT-01..03 |
| 3     | Heartbeat Telemetry Overhaul    | TELEM-01..04     |

---

## v1.3 Atomic Restart Recovery (Shipped: 2026-03-21)

**Phases completed:** 2 phases, 4 plans, 6 tasks

**Key accomplishments:**

- Atomic DELETE+INSERT via store_bars_replacing() in \_sync_flush_rest_bars() with Polars conversion, Redis lock, and \_write_batch_with_retry fallback
- Today-only date filter on \_heal_day_boundary_gaps() Stathera query and valid_pairs passthrough for overlap heal call site
- Verified \_inline_startup_backfill(), \_startup_tid_reconciliation(), and \_gap_fill() watchdog call are already absent from sidecar.py -- all three PRUNE requirements satisfied
- Removed dead gap_fill_on_startup field from SidecarConfig, type stubs, CLI --no-gap-fill flag, and 9 test constructions

---

## v1.2 Performance (Shipped: 2026-03-20)

**Phases completed:** 4 phases, 5 plans, 8 tasks

**Key accomplishments:**

- Bounded ThreadPoolExecutor(max_workers=2) replaces unbounded threading.Thread in Telegram log sink, with dedicated 3s timeout to prevent thread exhaustion during kintsugi batch repairs
- Thread-local CH cache eliminates per-call fd churn in kintsugi workers, and 3-tier concurrency control prevents REST-only shards from diluting Parquet/Vision throughput
- Zero-allocation FixedPoint::from_f64() eliminates 4M allocs/day, cached CSV decompression removes O(N^2) ZIP re-parsing in IntraDayChunkIterator
- Eliminate per-iteration Vec::with_capacity(32) allocation in WS select loop via clear()+reuse pattern (RUST-03)
- Cached kintsugi config per repair (3 instantiations eliminated), dynamic Vision 404 TTL (15min for T-2 dates), and removed redundant DataFrame copy in bulk operations
