# Quick Task 260320-xah: Fix pytest OOM

## What Changed

1. **pyproject.toml** — Added `-m 'not benchmark and not heavy'` to `addopts`, added `heavy` marker definition
2. **tests/test_edge_cases.py** — Added `@pytest.mark.heavy` to `TestLargeDatasets` class (10K/100K trade tests)
3. **tests/test_arrow_input_oracle.py** — Added `@pytest.mark.heavy` to `test_large_batch_stability` (100K trades)
4. **tests/conftest.py** — Double `gc.collect()` in `gc_after_test` fixture for PyO3 object reclamation

## Result

- 976/981 tests collected (5 deselected: 2 benchmark + 3 heavy)
- To run excluded tests explicitly: `pytest -m benchmark` or `pytest -m heavy`

## Root Cause

Three factors combined to cause 50+ GB memory consumption:

1. `@pytest.mark.benchmark` tests (1M trades) were never excluded from default runs
2. 100K-trade tests (test_edge_cases, test_arrow_input_oracle) ran in same process with no memory isolation
3. PyO3 `Vec<Bound<PyDict>>` creates full Rust-side copies of Python trade lists, and single `gc.collect()` was insufficient for cross-FFI reference cycles
