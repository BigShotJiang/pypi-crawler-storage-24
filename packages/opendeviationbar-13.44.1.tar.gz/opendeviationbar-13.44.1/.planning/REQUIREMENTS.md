# Requirements: v1.4 -- Zero-Gap Zero-Overlap Guarantee

**Defined:** 2026-03-21
**Core Value:** Zero Stathera gaps and overlaps across every restart, every midnight boundary, every deploy -- verified by continuous telemetry.

## v1 Requirements

### Rust Core (committed_floors fix)

- [x] **RUST-01**: `committed_floors` in `symbol_task()` initialized from last COMPLETED bar's `last_agg_trade_id`, not from `processor.last_agg_trade_id()` (which includes forming bar tail)
- [x] **RUST-02**: After fill_from_rest -> WS junction, zero bars are suppressed by the dedup floor -- verified by Stathera audit showing zero intra-day gaps

### Midnight Preflight Verification

- [x] **PREFLIGHT-01**: On checkpoint-cleared restart, sidecar queries Binance REST API for the exact midnight crossover trade ID (`startTime=midnight_ms&limit=1`) for each streaming symbol
- [x] **PREFLIGHT-02**: Sidecar verifies yesterday's orphan bar in ClickHouse closes at `crossover_trade_id - 1`. If not, logs WARNING and defers to kintsugi (no data corruption)
- [x] **PREFLIGHT-03**: `fill_from_rest` anchors from the verified crossover trade ID (not CH seed), guaranteeing `yesterday_orphan.last_agg_trade_id + 1 == today_first_bar.first_agg_trade_id`

### Heartbeat Telemetry

- [x] **TELEM-01**: Heartbeat reports per-symbol Stathera continuity as a single unified check -- no separate "intra-day" vs "midnight-boundary" classification. Gap is a gap.
- [x] **TELEM-02**: Heartbeat reports yesterday completion status per symbol -- shows whether yesterday's orphan bar matches the midnight crossover trade ID
- [x] **TELEM-03**: After sidecar restart, heartbeat reports junction telemetry: REST last trade ID, WS first trade ID, forming bar state, committed_floors value
- [x] **TELEM-04**: If any new gap appears in today's bars, heartbeat sends LOUD Telegram alert with exact (symbol, threshold, tid_delta, trade ID range)

## v2 Requirements

- **STREAM-01**: Expand sidecar streaming to all 17 symbols (eliminates multi-processor seam entirely)
- **KINTSUGI-01**: Two-day processor spans in kintsugi (alternative to preflight for non-streamed symbols)

## Out of Scope

| Feature                       | Reason                                           |
| ----------------------------- | ------------------------------------------------ |
| Full 18-symbol streaming      | Planned for future milestone (GSD Phases 6-10)   |
| Kintsugi two-day spans        | Preflight verification is simpler and sufficient |
| OpenDeviationBar struct split | Major refactor, separate milestone               |
| Plugin Polars->Pandas         | No plugins in production                         |

## Traceability

| Requirement  | Phase   | Status  |
| ------------ | ------- | ------- |
| RUST-01      | Phase 1 | Complete |
| RUST-02      | Phase 1 | Complete |
| PREFLIGHT-01 | Phase 2 | Complete |
| PREFLIGHT-02 | Phase 2 | Complete |
| PREFLIGHT-03 | Phase 2 | Complete |
| TELEM-01     | Phase 3 | Complete |
| TELEM-02     | Phase 3 | Complete |
| TELEM-03     | Phase 3 | Complete |
| TELEM-04     | Phase 3 | Complete |

**Coverage:**

- v1 requirements: 9 total
- Mapped to phases: 9
- Unmapped: 0

---

_Requirements defined: 2026-03-21_
_Derived from: 6-agent spike (2026-03-21) + user architecture decisions_
