# PySynClient

Automatically detects Synology Drive Client sync folders on Windows and provides stable, device-independent access to their local paths.

Unlike the Synology Drive Client's internal numeric indices (which can shift between machines or when NAS connections change), PySynClient keys everything by **NAS hostname** and **share name** — identifiers that stay consistent across devices.

## Installation

```bash
pip install pysynclient
```

## Usage

### Get sync folder paths

```python
import pysynclient

paths = pysynclient.get_server_paths()
# {
#     "my-nas": {
#         "home": Path("D:/SynologyDrive/home"),
#         "datasets": Path("D:/SynologyDrive/datasets"),
#         "photos": Path("D:/SynologyDrive/photos"),
#     }
# }

# Access a specific folder
datasets = paths["my-nas"]["datasets"]
```

### List connected NAS systems

```python
hosts = pysynclient.get_nas_hosts()
# ["my-nas"]
```

### Get detailed connection info

```python
info = pysynclient.get_connection_info()
# {
#     "my-nas": {
#         "host_name": "my-nas",
#         "server_name": "my-nas.example.com",
#         "server_ip": "10.0.0.1",
#         "username": "admin",
#     }
# }
```

## Example: Building a cross-device file path

```python
import pysynclient

paths = pysynclient.get_server_paths()

# Works on any machine connected to this NAS — no hardcoded paths
model_weights = paths["my-nas"]["datasets"] / "models" / "weights.pt"
```

## Requirements

- Windows (Synology Drive Client stores its data in `%LOCALAPPDATA%`)
- Synology Drive Client installed and connected to at least one NAS
- Python >= 3.10
