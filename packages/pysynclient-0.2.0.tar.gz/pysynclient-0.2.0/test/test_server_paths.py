import pysynclient as pysyn


def test_nas_hosts():
    hosts = pysyn.get_nas_hosts()
    print("Connected NAS hosts:", hosts)
    assert isinstance(hosts, list)
    assert all(isinstance(h, str) for h in hosts)


def test_connection_info():
    info = pysyn.get_connection_info()
    print("\nConnection info:")
    for host, details in info.items():
        print(f"  {host}: {details['server_name']} ({details['server_ip']})")
    assert isinstance(info, dict)
    for details in info.values():
        assert "host_name" in details
        assert "server_name" in details
        assert "server_ip" in details


def test_server_paths():
    paths = pysyn.get_server_paths()
    print("\nServer paths:")
    for host, shares in paths.items():
        print(f"  NAS: {host}")
        for share_name, path in shares.items():
            print(f"    {share_name}: {path}")
    assert isinstance(paths, dict)
    # Keys should be hostnames, not numeric indices
    for key in paths:
        assert not key.isdigit(), f"Key '{key}' looks like a numeric index, expected hostname"


if __name__ == "__main__":
    test_nas_hosts()
    test_connection_info()
    test_server_paths()
