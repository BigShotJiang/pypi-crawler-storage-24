from pysynclient._version import __version__, __version_tuple__
from pysynclient.client.server_paths import (
    get_connection_info,
    get_nas_hosts,
    get_server_paths,
)
