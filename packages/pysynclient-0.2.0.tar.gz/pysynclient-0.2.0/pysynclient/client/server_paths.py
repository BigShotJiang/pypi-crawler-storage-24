"""Detect Synology Drive Client sync folders with stable, device-independent identifiers.

Uses the Synology Drive Client's internal SQLite database to resolve
NAS connections and sync folder paths. Keys are derived from server-side
properties (hostname, share name) rather than local client indices, so
they remain consistent across devices and when multiple NAS systems are
connected.
"""

import sqlite3
from pathlib import Path

SYNOLOGY_DRIVE_DIR = Path.home() / "AppData" / "Local" / "SynologyDrive"
SYNOLOGY_DB_PATH = SYNOLOGY_DRIVE_DIR / "data" / "db" / "sys.sqlite"


def _open_db() -> sqlite3.Connection:
    """Open a read-only connection to the Synology Drive database."""
    if not SYNOLOGY_DB_PATH.is_file():
        raise FileNotFoundError(
            f"Synology Drive database not found at {SYNOLOGY_DB_PATH}. "
            "Is Synology Drive Client installed?"
        )
    return sqlite3.connect(f"file:{SYNOLOGY_DB_PATH}?mode=ro", uri=True)


def get_nas_hosts() -> list[str]:
    """
    Get hostnames of all connected Synology NAS systems.

    Returns:
        list[str]: List of NAS hostnames (e.g. ["nsquared-nas"]).
    """
    conn = _open_db()
    try:
        cursor = conn.execute("SELECT host_name FROM connection_table")
        return [row[0] for row in cursor]
    finally:
        conn.close()


def get_connection_info() -> dict[str, dict]:
    """
    Get detailed connection info for all connected NAS systems, keyed by hostname.

    Returns:
        dict[str, dict]: Mapping of hostname to connection details containing
        host_name, server_name (FQDN), server_ip, and username.

    Example::

        info = get_connection_info()
        info["nsquared-nas"]["server_name"]  # "nsquared-nas.example.com"
        info["nsquared-nas"]["server_ip"]    # "10.0.0.1"
    """
    conn = _open_db()
    try:
        cursor = conn.execute(
            "SELECT host_name, server_name, server_ip, username "
            "FROM connection_table"
        )
        return {
            row[0]: {
                "host_name": row[0],
                "server_name": row[1],
                "server_ip": row[2],
                "username": row[3],
            }
            for row in cursor
        }
    finally:
        conn.close()


def get_server_paths() -> dict[str, dict[str, Path]]:
    """
    Returns all sync folder paths keyed by NAS hostname and share name.

    Both keys are stable, device-independent identifiers derived from the
    NAS server configuration — not from local client indices that may shift
    between machines or when NAS connections are re-added.

    Returns:
        dict[str, dict[str, Path]]: ``{nas_hostname: {share_name: local_sync_path}}``

    Example::

        paths = get_server_paths()
        datasets = paths["nsquared-nas"]["datasets"]
    """
    conn = _open_db()
    try:
        cursor = conn.execute(
            "SELECT c.host_name, s.share_name, s.sync_folder "
            "FROM session_table s "
            "JOIN connection_table c ON s.conn_id = c.id "
            "WHERE s.share_name != ''"
        )
        paths: dict[str, dict[str, Path]] = {}
        for host_name, share_name, sync_folder in cursor:
            if host_name not in paths:
                paths[host_name] = {}
            paths[host_name][share_name] = Path(sync_folder)
        return paths
    finally:
        conn.close()
