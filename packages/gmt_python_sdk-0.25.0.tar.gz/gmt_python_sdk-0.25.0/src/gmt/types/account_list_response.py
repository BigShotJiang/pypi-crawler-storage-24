# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from typing import List, Optional
from typing_extensions import Literal

from .._models import BaseModel

__all__ = ["AccountListResponse", "BasePrice", "DisplayName", "Price"]


class BasePrice(BaseModel):
    amount: str
    """Monetary amount as a string with up to 2 decimal places."""

    currency_code: str
    """ISO 4217 currency code."""


class DisplayName(BaseModel):
    en: str
    """Name in English."""

    ru: str
    """Name in Russian."""


class Price(BaseModel):
    amount: str
    """Monetary amount as a string with up to 2 decimal places."""

    currency_code: str
    """ISO 4217 currency code."""


class AccountListResponse(BaseModel):
    available: bool
    """Indicates if account is available for purchase."""

    base_price: BasePrice

    country_code: str
    """ISO 3166-1 alpha-2 country code (e.g., US, RU, GB)."""

    display_name: DisplayName

    emoji: str
    """Country flag emoji."""

    popularity_index: float
    """Relative popularity of this country based on recent purchase volume."""

    price: Price

    tags: List[Literal["HIGH_QUALITY", "HIGH_DEMAND"]]
    """Account tags (e.g., HIGH_QUALITY for premium accounts)."""

    available_count: Optional[float] = None
    """Number of available accounts for this country."""
