"""
VOXYN command-line interface.

Usage:
    voxyn start           — start the daemon
    voxyn stop            — stop the daemon
    voxyn status          — check daemon status
    voxyn token           — generate a new API token
    voxyn command <text>  — send a one-shot command
    voxyn benchmark       — run performance benchmarks
    voxyn install         — install models
"""

from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich import print as rprint

app = typer.Typer(
    name="voxyn",
    help="VOXYN.io — natural language robot control",
    add_completion=False,
)
console = Console()


@app.command()
def start(
    host: str = typer.Option("0.0.0.0", help="API server host"),
    port: int = typer.Option(8080, help="API server port"),
    mock: bool = typer.Option(False, "--mock", help="Mock hardware (no real board needed)"),
    log_level: str = typer.Option("INFO", help="Log level"),
) -> None:
    """Start the VOXYN daemon (API server + hardware executor)."""
    import os
    if mock:
        os.environ["VOXYN_MOCK_HARDWARE"] = "1"
    os.environ["VOXYN_API__HOST"] = host
    os.environ["VOXYN_API__PORT"] = str(port)
    os.environ["VOXYN_GENERAL__LOG_LEVEL"] = log_level

    from voxyn.daemon import main
    main()


@app.command()
def stop() -> None:
    """Stop a running VOXYN daemon (sends SIGTERM via PID file)."""
    pid_file = Path("/var/run/voxyn/voxyn.pid")
    if not pid_file.exists():
        rprint("[yellow]No PID file found at /var/run/voxyn/voxyn.pid[/yellow]")
        rprint("Try: [cyan]systemctl stop voxyn[/cyan]")
        raise typer.Exit(1)

    import signal
    pid = int(pid_file.read_text().strip())
    try:
        import os
        os.kill(pid, signal.SIGTERM)
        rprint(f"[green]VOXYN daemon stopped (pid={pid})[/green]")
    except ProcessLookupError:
        rprint(f"[yellow]Process {pid} not found (already stopped?)[/yellow]")


@app.command()
def status() -> None:
    """Check the status of the VOXYN daemon."""
    import httpx

    try:
        r = httpx.get("http://localhost:8080/health", timeout=3)
        data = r.json()

        table = Table(title="VOXYN Status", show_header=True)
        table.add_column("Component", style="cyan")
        table.add_column("Status", style="green")

        table.add_row("API server", f"[green]running[/green] (v{data.get('version', '?')})")
        for name, status in data.get("components", {}).items():
            if name == "metrics":
                continue
            color = "green" if status == "ok" else "red"
            table.add_row(name, f"[{color}]{status}[/{color}]")

        console.print(table)

    except Exception:
        rprint("[red]VOXYN daemon is not running[/red]")
        rprint("Start with: [cyan]voxyn start[/cyan]")
        raise typer.Exit(1)


@app.command()
def token(
    client_id: str = typer.Option("default", help="Client identifier"),
    permissions: str = typer.Option("command,read", help="Comma-separated permissions"),
) -> None:
    """Generate a new API token."""
    from voxyn.core.auth import get_auth_manager
    perm_list = [p.strip() for p in permissions.split(",")]
    manager = get_auth_manager()
    jwt_token = manager.generate_token(client_id, perm_list)
    rprint(f"[green]Token generated for '[cyan]{client_id}[/cyan]' (expires in 24h):[/green]")
    rprint(f"[dim]{jwt_token}[/dim]")
    rprint()
    rprint(f"Use with: [cyan]Authorization: Bearer {jwt_token[:20]}...[/cyan]")


@app.command()
def command(
    text: str = typer.Argument(..., help="Natural language command to send"),
    host: str = typer.Option("localhost", help="VOXYN API host"),
    port: int = typer.Option(8080, help="VOXYN API port"),
    token_str: Optional[str] = typer.Option(None, "--token", envvar="VOXYN_TOKEN"),
) -> None:
    """Send a one-shot natural language command to the robot."""
    import httpx

    if not token_str:
        rprint("[yellow]No token provided. Set VOXYN_TOKEN or use --token.[/yellow]")
        raise typer.Exit(1)

    url = f"http://{host}:{port}/command/text"
    try:
        r = httpx.post(
            url,
            json={"command": text},
            headers={"Authorization": f"Bearer {token_str}"},
            timeout=10,
        )
        data = r.json()
        if data.get("success"):
            rprint(f"[green]Success![/green] {data.get('intent')}")
            rprint(f"[dim]Latency: {data.get('duration_ms', 0):.1f}ms[/dim]")
        else:
            rprint(f"[red]Error:[/red] {data.get('error')}")
    except Exception as e:
        rprint(f"[red]Connection error:[/red] {e}")
        raise typer.Exit(1)


@app.command()
def chat(
    host: str = typer.Option("localhost", help="VOXYN server host"),
    port: int = typer.Option(8080, help="VOXYN server port"),
    token: Optional[str] = typer.Option(None, "--token", envvar="VOXYN_TOKEN"),
) -> None:
    """Open the interactive terminal UI (like Claude Code, for your robot)."""
    from voxyn.tui import main as tui_main
    tui_main(host=host, port=port, token=token)


@app.command()
def benchmark(
    count: int = typer.Option(20, help="Number of commands to benchmark"),
) -> None:
    """Run pipeline performance benchmarks."""
    import subprocess
    subprocess.run([sys.executable, "scripts/benchmark.py", "--count", str(count)], check=True)


if __name__ == "__main__":
    app()
