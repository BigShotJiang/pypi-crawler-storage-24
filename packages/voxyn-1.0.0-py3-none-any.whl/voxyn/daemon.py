"""
VOXYN daemon entry point.

Starts the full NeuralOS stack:
  1. Rust executor process (if not already running)
  2. FastAPI + uvicorn server

Designed to run under systemd as a persistent background service.
Can also be started directly: `voxyn-daemon` or `python -m voxyn.daemon`
"""

from __future__ import annotations

import asyncio
import logging
import os
import signal
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

import uvicorn

from voxyn.core.config import settings
from voxyn.api.server import create_app

logger = logging.getLogger(__name__)

_executor_process: Optional[subprocess.Popen] = None


def _setup_logging() -> None:
    log_dir = Path(settings.general.log_file).parent
    log_dir.mkdir(parents=True, exist_ok=True)

    handlers: list[logging.Handler] = [logging.StreamHandler(sys.stdout)]

    try:
        handlers.append(logging.FileHandler(settings.general.log_file))
    except PermissionError:
        pass

    logging.basicConfig(
        level=getattr(logging, settings.general.log_level.upper(), logging.INFO),
        format="%(asctime)s %(levelname)-8s %(name)s: %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
        force=True,
    )


def _start_rust_executor() -> Optional[subprocess.Popen]:
    """Start the Rust executor binary as a subprocess."""
    executor_bin = Path("target/release/voxyn-executor")
    if not executor_bin.exists():
        # Try system PATH
        import shutil
        executor_bin_path = shutil.which("voxyn-executor")
        if executor_bin_path:
            executor_bin = Path(executor_bin_path)
        else:
            logger.warning(
                "voxyn-executor binary not found. "
                "Run: cargo build --release -p voxyn-executor"
            )
            if not settings.general.mock_hardware:
                logger.warning("Continuing without hardware executor (mock mode)")
            return None

    logger.info("Starting Rust executor: %s", executor_bin)
    proc = subprocess.Popen(
        [str(executor_bin)],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env={**os.environ, "RUST_LOG": "info"},
    )
    time.sleep(0.5)  # brief wait for executor to bind its ZMQ socket
    if proc.poll() is not None:
        logger.error("Rust executor failed to start (exit code: %d)", proc.returncode)
        return None
    logger.info("Rust executor started (pid=%d)", proc.pid)
    return proc


def _stop_rust_executor(proc: Optional[subprocess.Popen]) -> None:
    if proc and proc.poll() is None:
        logger.info("Stopping Rust executor (pid=%d)", proc.pid)
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()


def main() -> None:
    _setup_logging()

    logger.info("=" * 60)
    logger.info("VOXYN.io daemon starting")
    logger.info("Version: see voxyn.__version__")
    logger.info("Mock hardware: %s", settings.general.mock_hardware)
    logger.info("=" * 60)

    global _executor_process
    _executor_process = _start_rust_executor()

    def _handle_shutdown(signum: int, frame: object) -> None:
        logger.info("Shutdown signal received (%d)", signum)
        _stop_rust_executor(_executor_process)
        sys.exit(0)

    signal.signal(signal.SIGTERM, _handle_shutdown)
    signal.signal(signal.SIGINT, _handle_shutdown)

    ssl_kwargs = {}
    if settings.api.enable_tls and settings.api.tls_cert and settings.api.tls_key:
        ssl_kwargs = {
            "ssl_certfile": settings.api.tls_cert,
            "ssl_keyfile": settings.api.tls_key,
        }

    app = create_app()

    uvicorn.run(
        app,
        host=settings.api.host,
        port=settings.api.port,
        log_level=settings.general.log_level.lower(),
        access_log=True,
        workers=1,  # must be 1 — we hold shared pipeline state
        **ssl_kwargs,
    )


if __name__ == "__main__":
    main()
