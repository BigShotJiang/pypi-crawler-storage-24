"""
Safety Validator — hard gate between NLU and hardware execution.

EVERY command passes through this validator before touching hardware.
The validator has two layers:
    1. Hard limits (immutable) — absolute maximums that cannot be overridden
    2. User limits (configurable) — can only be MORE restrictive than hard limits

This design means even if someone crafts a malicious config or prompt injection,
the hard limits prevent catastrophic robot behavior.

Design principles:
- Simple and fast (~0.1ms) — no async, no I/O, no network
- Fail-safe: anything unexpected is blocked
- Recursive: validates each command in a sequence
- Testable: pure function with no side effects
"""

from __future__ import annotations

from typing import Any, Optional

from voxyn.core.types import Intent, SafetyResult

# ─── Immutable hard limits — cannot be relaxed by any configuration ───────────
HARD_LIMITS: dict[str, float] = {
    "max_speed": 100.0,
    "max_duration_seconds": 60.0,
    "max_servo_angle": 180.0,
    "min_servo_angle": 0.0,
    "max_rotation_angle": 360.0,
    "max_sequence_length": 20.0,
}

KNOWN_ACTIONS = frozenset({
    "move", "rotate", "servo", "stop", "sequence",
    "wait", "if_sensor", "clarify", "error",
})

VALID_DIRECTIONS = frozenset({"forward", "backward", "left", "right"})
VALID_ROTATION_DIRECTIONS = frozenset({"clockwise", "counterclockwise"})


class SafetyValidator:
    """
    Validates robot intents before execution.

    User limits can only be MORE restrictive than hard limits.
    This prevents configuration from bypassing safety constraints.
    """

    def __init__(self, user_limits: Optional[dict[str, float]] = None) -> None:
        self.limits = HARD_LIMITS.copy()
        if user_limits:
            for key, val in user_limits.items():
                if key in self.limits:
                    # Always take the more restrictive value
                    self.limits[key] = min(float(val), HARD_LIMITS[key])

    def validate(self, intent: Intent) -> SafetyResult:
        """
        Validate an intent. Returns SafetyResult(passed=True) if safe to execute.

        This is a synchronous function — no I/O, < 1ms.
        """
        action = intent.action

        if action not in KNOWN_ACTIONS:
            return SafetyResult(passed=False, reason=f"Unknown action: '{action}'")

        # These actions are always safe to pass through
        if action in {"stop", "clarify", "error", "wait"}:
            if action == "wait":
                return self._check_duration(getattr(intent, "duration", None))
            return SafetyResult(passed=True, reason="OK")

        if action == "move":
            return self._validate_move(intent)

        if action == "rotate":
            return self._validate_rotate(intent)

        if action == "servo":
            return self._validate_servo(intent)

        if action == "sequence":
            return self._validate_sequence(intent)

        if action == "if_sensor":
            return self._validate_if_sensor(intent)

        return SafetyResult(passed=True, reason="OK")

    # ─── Action-specific validators ─────────────────────────────────────────

    def _validate_move(self, intent: Intent) -> SafetyResult:
        speed_check = self._check_speed(intent.speed)
        if not speed_check.passed:
            return speed_check

        dur_check = self._check_duration(intent.duration)
        if not dur_check.passed:
            return dur_check

        if intent.direction and intent.direction not in VALID_DIRECTIONS:
            return SafetyResult(
                passed=False,
                reason=f"Invalid direction '{intent.direction}'. Must be: {sorted(VALID_DIRECTIONS)}",
            )

        return SafetyResult(passed=True, reason="OK")

    def _validate_rotate(self, intent: Intent) -> SafetyResult:
        speed_check = self._check_speed(intent.speed)
        if not speed_check.passed:
            return speed_check

        angle = intent.angle
        if angle is None:
            return SafetyResult(passed=False, reason="Rotate requires angle")
        if not 0 <= angle <= self.limits["max_rotation_angle"]:
            return SafetyResult(
                passed=False,
                reason=f"Rotation angle {angle}° out of range 0-{self.limits['max_rotation_angle']}°",
            )

        if intent.direction and intent.direction not in VALID_ROTATION_DIRECTIONS:
            return SafetyResult(
                passed=False,
                reason=f"Invalid rotation direction '{intent.direction}'",
            )

        return SafetyResult(passed=True, reason="OK")

    def _validate_servo(self, intent: Intent) -> SafetyResult:
        angle = intent.angle
        if angle is None:
            return SafetyResult(passed=False, reason="Servo requires angle")
        if not self.limits["min_servo_angle"] <= angle <= self.limits["max_servo_angle"]:
            return SafetyResult(
                passed=False,
                reason=f"Servo angle {angle}° out of range {self.limits['min_servo_angle']}-{self.limits['max_servo_angle']}°",
            )

        if intent.channel is None:
            return SafetyResult(passed=False, reason="Servo requires channel (0-15)")
        if not 0 <= intent.channel <= 15:
            return SafetyResult(
                passed=False,
                reason=f"Servo channel {intent.channel} out of range 0-15",
            )

        return SafetyResult(passed=True, reason="OK")

    def _validate_sequence(self, intent: Intent) -> SafetyResult:
        commands = intent.commands or []
        max_len = int(self.limits["max_sequence_length"])

        if len(commands) > max_len:
            return SafetyResult(
                passed=False,
                reason=f"Sequence too long: {len(commands)} commands (max {max_len})",
            )

        # Recursively validate each sub-command
        for i, cmd_dict in enumerate(commands):
            try:
                sub_intent = Intent(**cmd_dict)
            except Exception as e:
                return SafetyResult(
                    passed=False,
                    reason=f"Sequence[{i}]: invalid command schema: {e}",
                )
            sub_result = self.validate(sub_intent)
            if not sub_result.passed:
                return SafetyResult(
                    passed=False,
                    reason=f"Sequence[{i}]: {sub_result.reason}",
                )

        return SafetyResult(passed=True, reason="OK")

    def _validate_if_sensor(self, intent: Intent) -> SafetyResult:
        if not intent.sensor:
            return SafetyResult(passed=False, reason="if_sensor requires sensor name")
        if not intent.condition:
            return SafetyResult(passed=False, reason="if_sensor requires condition")
        if not intent.then:
            return SafetyResult(passed=False, reason="if_sensor requires then action")

        try:
            then_intent = Intent(**intent.then)
        except Exception as e:
            return SafetyResult(passed=False, reason=f"if_sensor.then: invalid schema: {e}")

        return self.validate(then_intent)

    # ─── Shared checks ──────────────────────────────────────────────────────

    def _check_speed(self, speed: Optional[float]) -> SafetyResult:
        if speed is None:
            return SafetyResult(passed=True, reason="OK")
        if not 0 <= speed <= self.limits["max_speed"]:
            return SafetyResult(
                passed=False,
                reason=f"Speed {speed} out of range 0-{self.limits['max_speed']}",
            )
        return SafetyResult(passed=True, reason="OK")

    def _check_duration(self, duration: Optional[float]) -> SafetyResult:
        if duration is None:
            return SafetyResult(passed=True, reason="OK")
        if duration <= 0:
            return SafetyResult(passed=False, reason="Duration must be positive")
        if duration > self.limits["max_duration_seconds"]:
            return SafetyResult(
                passed=False,
                reason=f"Duration {duration}s exceeds limit {self.limits['max_duration_seconds']}s",
            )
        return SafetyResult(passed=True, reason="OK")
