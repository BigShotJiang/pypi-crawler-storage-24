"""Safety subsystem — hard gates every command before it reaches hardware."""
