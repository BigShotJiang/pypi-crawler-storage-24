"""
Hardware Watchdog — prevents runaway robots.

If no valid command heartbeat is received within TIMEOUT seconds,
the watchdog triggers an emergency stop.

This is a critical safety component:
- Triggers if software crashes mid-command
- Triggers if WebSocket client disconnects unexpectedly
- Triggers if network connectivity is lost during a command
- Can be configured but not disabled in production builds with motors active

The watchdog runs as an asyncio task and is started by the pipeline.
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Awaitable, Callable, Optional

logger = logging.getLogger(__name__)


class HardwareWatchdog:
    """
    Async hardware watchdog.

    Args:
        stop_callback: Async callable that triggers emergency stop.
                       Called once per watchdog timeout event.
        timeout: Seconds of silence before emergency stop (default 5.0)
    """

    def __init__(
        self,
        stop_callback: Callable[[], Awaitable[None]],
        timeout: float = 5.0,
    ) -> None:
        self._stop_callback = stop_callback
        self._timeout = timeout
        self._last_heartbeat: float = time.monotonic()
        self._running: bool = False
        self._triggered_count: int = 0
        self._ever_received_command: bool = False  # don't fire until first command

    def heartbeat(self) -> None:
        """
        Reset the watchdog timer.

        Call this every time a command is successfully processed.
        If no heartbeat arrives within self._timeout, emergency stop fires.
        """
        self._ever_received_command = True
        self._last_heartbeat = time.monotonic()

    async def start(self) -> None:
        """Start the watchdog loop. Run as an asyncio task."""
        self._running = True
        # Check interval is min(1.0, timeout/2) so we fire promptly even with short timeouts
        _check_interval = min(1.0, max(0.05, self._timeout / 2))
        logger.info("Hardware watchdog started (timeout=%.1fs, check_interval=%.2fs)", self._timeout, _check_interval)

        while self._running:
            await asyncio.sleep(_check_interval)

            elapsed = time.monotonic() - self._last_heartbeat
            if self._ever_received_command and elapsed > self._timeout:
                self._triggered_count += 1
                logger.warning(
                    "Watchdog triggered! No heartbeat for %.1fs. Emergency stop. (trigger #%d)",
                    elapsed,
                    self._triggered_count,
                )
                try:
                    await self._stop_callback()
                except Exception as e:
                    logger.error("Watchdog: emergency stop callback failed: %s", e)
                # Reset heartbeat after firing to avoid repeat triggers every second
                self._last_heartbeat = time.monotonic()

    def stop(self) -> None:
        """Stop the watchdog loop gracefully."""
        self._running = False
        logger.info("Hardware watchdog stopped")

    @property
    def time_since_heartbeat(self) -> float:
        """Seconds since last heartbeat."""
        return time.monotonic() - self._last_heartbeat

    @property
    def triggered_count(self) -> int:
        """Number of times the watchdog has triggered."""
        return self._triggered_count

    @property
    def is_healthy(self) -> bool:
        """True if within the heartbeat window."""
        return self.time_since_heartbeat < self._timeout
