"""
VOXYN Terminal UI — interactive robot control from the terminal.

Inspired by Claude Code's terminal-first design philosophy.
Beautiful, fast, keyboard-driven.

Usage:
    voxyn chat                    # connect to local server
    voxyn chat --host 192.168.1.5 # connect to remote Pi
"""

from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from datetime import datetime
from typing import Optional

import httpx
from rich.align import Align
from rich.columns import Columns
from rich.console import Console
from rich.layout import Layout
from rich.live import Live
from rich.panel import Panel
from rich.prompt import Prompt
from rich.rule import Rule
from rich.style import Style
from rich.table import Table
from rich.text import Text
from rich import box

console = Console()

LOGO = """
 ██╗   ██╗ ██████╗ ██╗  ██╗██╗   ██╗███╗   ██╗
 ██║   ██║██╔═══██╗╚██╗██╔╝╚██╗ ██╔╝████╗  ██║
 ██║   ██║██║   ██║ ╚███╔╝  ╚████╔╝ ██╔██╗ ██║
 ╚██╗ ██╔╝██║   ██║ ██╔██╗   ╚██╔╝  ██║╚██╗██║
  ╚████╔╝ ╚██████╔╝██╔╝ ██╗   ██║   ██║ ╚████║
   ╚═══╝   ╚═════╝ ╚═╝  ╚═╝   ╚═╝   ╚═╝  ╚═══╝"""

TAGLINE = "Talk to your robot like it's a person."

HELP_TEXT = """\
[dim]Commands:[/dim]
  [cyan]move forward for 3 seconds[/cyan]   natural language → robot action
  [cyan]turn right 90 degrees[/cyan]
  [cyan]set servo 0 to 90[/cyan]
  [cyan]stop[/cyan]                          emergency stop (always works)

[dim]Special:[/dim]
  [yellow]/status[/yellow]    show server health & motor states
  [yellow]/history[/yellow]   show last 10 commands
  [yellow]/raw[/yellow]       send raw JSON command
  [yellow]/help[/yellow]      show this message
  [yellow]/quit[/yellow]      exit\
"""


class CommandHistory:
    def __init__(self, max_size: int = 50) -> None:
        self._entries: list[dict] = []
        self._max = max_size

    def add(self, command: str, result: dict, latency_ms: float) -> None:
        self._entries.append({
            "time": datetime.now().strftime("%H:%M:%S"),
            "command": command,
            "success": result.get("success", False),
            "action": (result.get("intent") or {}).get("action", "—") if result.get("success") else "—",
            "error": result.get("error"),
            "latency_ms": latency_ms,
        })
        if len(self._entries) > self._max:
            self._entries.pop(0)

    def last(self, n: int = 10) -> list[dict]:
        return self._entries[-n:]


class VoxynTUI:
    def __init__(self, host: str, port: int, token: str) -> None:
        self.base_url = f"http://{host}:{port}"
        self.token = token
        self.history = CommandHistory()
        self._client = httpx.AsyncClient(
            base_url=self.base_url,
            headers={"Authorization": f"Bearer {token}"},
            timeout=15.0,
        )
        self._connected = False
        self._server_version = "?"

    # ─── Connection ────────────────────────────────────────────────────────

    async def check_connection(self) -> bool:
        try:
            r = await self._client.get("/health")
            data = r.json()
            self._connected = data.get("status") == "ok"
            self._server_version = data.get("version", "?")
            return self._connected
        except Exception:
            self._connected = False
            return False

    # ─── Commands ──────────────────────────────────────────────────────────

    async def send_text_command(self, text: str) -> dict:
        try:
            t0 = time.perf_counter()
            r = await self._client.post("/command/text", json={"command": text})
            latency = (time.perf_counter() - t0) * 1000
            result = r.json()
            result["_latency_ms"] = latency
            return result
        except httpx.ConnectError:
            return {"success": False, "error": "Cannot connect to VOXYN server", "_latency_ms": 0}
        except Exception as e:
            return {"success": False, "error": str(e), "_latency_ms": 0}

    async def send_raw_command(self, raw: dict) -> dict:
        try:
            t0 = time.perf_counter()
            r = await self._client.post("/command/raw", json=raw)
            latency = (time.perf_counter() - t0) * 1000
            result = r.json()
            result["_latency_ms"] = latency
            return result
        except Exception as e:
            return {"success": False, "error": str(e), "_latency_ms": 0}

    async def emergency_stop(self) -> None:
        try:
            await self._client.post("/emergency-stop")
        except Exception:
            pass

    async def get_status(self) -> dict:
        try:
            health = (await self._client.get("/health")).json()
            motors = (await self._client.get("/motors")).json()
            sensors = (await self._client.get("/sensors")).json()
            return {"health": health, "motors": motors, "sensors": sensors}
        except Exception as e:
            return {"error": str(e)}

    # ─── Rendering ─────────────────────────────────────────────────────────

    def _render_header(self) -> Panel:
        logo = Text(LOGO, style="bold cyan")
        tag = Text(f"\n  {TAGLINE}", style="dim white")
        version_info = Text(
            f"\n  Server v{self._server_version}  •  "
            f"{'[green]●[/green] Connected' if self._connected else '[red]●[/red] Disconnected'}  •  "
            f"{self.base_url}",
            style="dim",
        )
        content = Text.assemble(logo, tag, version_info)
        return Panel(content, border_style="cyan dim", padding=(0, 1))

    def _render_result(self, command: str, result: dict) -> None:
        latency = result.get("_latency_ms", 0)
        success = result.get("success", False)
        intent = result.get("intent") or {}
        error = result.get("error")

        if success:
            action = intent.get("action", "?")
            details = {k: v for k, v in intent.items() if k != "action" and v is not None}
            detail_str = "  ".join(f"[dim]{k}=[/dim][white]{v}[/white]" for k, v in details.items())

            console.print(
                f"  [green]✓[/green] [white]{action}[/white]  {detail_str}  "
                f"[dim]{latency:.0f}ms[/dim]"
            )
        else:
            # Check if it's a safety block
            if error and "safety" in error.lower():
                console.print(f"  [yellow]⚠[/yellow]  [yellow]{error}[/yellow]  [dim]{latency:.0f}ms[/dim]")
            elif error and "model" in error.lower():
                console.print(f"  [dim]○  NLU model not loaded — use /raw for structured commands[/dim]")
            else:
                console.print(f"  [red]✗[/red]  [red]{error or 'Unknown error'}[/red]  [dim]{latency:.0f}ms[/dim]")

        self.history.add(command, result, latency)

    def _render_history(self) -> None:
        entries = self.history.last(10)
        if not entries:
            console.print("  [dim]No commands yet.[/dim]")
            return

        table = Table(box=box.SIMPLE, show_header=True, header_style="dim", padding=(0, 1))
        table.add_column("Time", style="dim", width=8)
        table.add_column("Command", style="white", max_width=40)
        table.add_column("Action", style="cyan", width=12)
        table.add_column("ms", justify="right", style="dim", width=6)
        table.add_column("", width=2)

        for e in reversed(entries):
            status = "[green]✓[/green]" if e["success"] else "[red]✗[/red]"
            table.add_row(
                e["time"],
                e["command"][:40],
                e["action"],
                f"{e['latency_ms']:.0f}",
                status,
            )
        console.print(table)

    async def _render_status(self) -> None:
        with console.status("[dim]Fetching status...[/dim]", spinner="dots"):
            data = await self.get_status()

        if "error" in data:
            console.print(f"  [red]Error:[/red] {data['error']}")
            return

        health = data.get("health", {})
        motors = data.get("motors", {}).get("channels", [])
        sensors = data.get("sensors", {}).get("imu", {})
        metrics = health.get("components", {}).get("metrics", {})

        # Components
        components_table = Table(box=box.SIMPLE, show_header=False, padding=(0, 2))
        components_table.add_column("Component", style="dim")
        components_table.add_column("Status")
        for name, status in health.get("components", {}).items():
            if name == "metrics":
                continue
            color = "green" if status == "ok" else "red"
            components_table.add_row(name, f"[{color}]{status}[/{color}]")

        console.print(Panel(components_table, title="[dim]Components[/dim]", border_style="dim", padding=(0, 1)))

        # IMU
        imu_text = (
            f"  accel  x=[cyan]{sensors.get('ax', 0):.2f}[/cyan]  "
            f"y=[cyan]{sensors.get('ay', 0):.2f}[/cyan]  "
            f"z=[cyan]{sensors.get('az', 0):.2f}[/cyan]  m/s²\n"
            f"  gyro   x=[cyan]{sensors.get('gx', 0):.2f}[/cyan]  "
            f"y=[cyan]{sensors.get('gy', 0):.2f}[/cyan]  "
            f"z=[cyan]{sensors.get('gz', 0):.2f}[/cyan]  °/s"
        )
        console.print(Panel(imu_text, title="[dim]IMU[/dim]", border_style="dim", padding=(0, 1)))

        # Metrics
        if metrics:
            stages = metrics.get("stages", {})
            total = stages.get("total", {})
            if total.get("samples", 0) > 0:
                console.print(
                    f"  [dim]Pipeline:[/dim]  "
                    f"mean [cyan]{total.get('mean', 0):.0f}ms[/cyan]  "
                    f"p95 [cyan]{total.get('p95', 0):.0f}ms[/cyan]  "
                    f"commands [cyan]{metrics.get('commands_processed', 0)}[/cyan]"
                )

    # ─── Main loop ─────────────────────────────────────────────────────────

    async def run(self) -> None:
        console.clear()
        console.print(self._render_header())
        console.print()

        # Connection check
        with console.status("[dim]Connecting to VOXYN server...[/dim]", spinner="dots"):
            connected = await self.check_connection()

        if not connected:
            console.print(
                Panel(
                    f"  [red]Cannot connect to[/red] [white]{self.base_url}[/white]\n\n"
                    "  Make sure the server is running:\n"
                    "  [cyan]VOXYN_MOCK_HARDWARE=1 python -m uvicorn voxyn.api.server:app --port 8080[/cyan]",
                    border_style="red",
                    padding=(1, 2),
                )
            )
            return

        console.print(
            f"  [green]Connected[/green] to VOXYN v{self._server_version}  "
            "[dim]Type /help for commands, /quit to exit[/dim]"
        )
        console.print()

        while True:
            try:
                raw_input = console.input("[cyan]>[/cyan] ").strip()
            except (KeyboardInterrupt, EOFError):
                console.print("\n  [dim]Emergency stop sent. Goodbye.[/dim]")
                await self.emergency_stop()
                break

            if not raw_input:
                continue

            # ─── Special commands ───────────────────────────────────────

            if raw_input.lower() in ("/quit", "/exit", "/q"):
                console.print("  [dim]Goodbye.[/dim]")
                await self.emergency_stop()
                break

            elif raw_input.lower() == "/help":
                console.print(Panel(HELP_TEXT, border_style="dim", padding=(1, 2)))

            elif raw_input.lower() == "/history":
                self._render_history()

            elif raw_input.lower() == "/status":
                await self._render_status()

            elif raw_input.lower().startswith("/raw "):
                raw_json_str = raw_input[5:].strip()
                try:
                    raw_cmd = json.loads(raw_json_str)
                    with console.status("[dim]Sending...[/dim]", spinner="dots"):
                        result = await self.send_raw_command(raw_cmd)
                    self._render_result(raw_input, result)
                except json.JSONDecodeError as e:
                    console.print(f"  [red]Invalid JSON:[/red] {e}")

            elif raw_input.lower() in ("stop", "halt", "emergency stop", "/stop"):
                with console.status("[dim]Stopping...[/dim]", spinner="dots"):
                    await self.emergency_stop()
                console.print("  [yellow]⚠[/yellow]  Emergency stop sent")

            # ─── Natural language command ───────────────────────────────

            else:
                with console.status(f"[dim]Processing...[/dim]", spinner="dots"):
                    result = await self.send_text_command(raw_input)
                self._render_result(raw_input, result)

            console.print()

        await self._client.aclose()


async def _run_tui(host: str, port: int, token: Optional[str]) -> None:
    if not token:
        token = os.environ.get("VOXYN_TOKEN")

    if not token:
        console.print()
        console.print(Panel(
            "  No API token found.\n\n"
            "  Generate one with:\n"
            "  [cyan]python -c \"from voxyn.core.auth import get_auth_manager; "
            "print(get_auth_manager().generate_token('me', ['command','read']))\"[/cyan]\n\n"
            "  Then set it:\n"
            "  [cyan]export VOXYN_TOKEN=<your_token>[/cyan]",
            border_style="yellow",
            title="[yellow]Auth Required[/yellow]",
            padding=(1, 2),
        ))
        return

    tui = VoxynTUI(host=host, port=port, token=token)
    await tui.run()


def main(
    host: str = "localhost",
    port: int = 8080,
    token: Optional[str] = None,
) -> None:
    """Entry point for `voxyn chat`."""
    asyncio.run(_run_tui(host, port, token))


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="VOXYN Terminal UI")
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8080)
    parser.add_argument("--token", default=None)
    args = parser.parse_args()
    main(args.host, args.port, args.token)
