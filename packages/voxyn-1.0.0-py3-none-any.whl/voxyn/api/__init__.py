"""VOXYN REST API and WebSocket server (FastAPI)."""
