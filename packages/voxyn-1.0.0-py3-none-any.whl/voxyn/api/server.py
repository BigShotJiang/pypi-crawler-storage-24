"""
VOXYN FastAPI server.

Endpoints:
    GET  /health                — system health check
    POST /command/text          — natural language command (requires auth)
    POST /command/raw           — pre-structured command (requires auth)
    POST /emergency-stop        — stop all motors immediately (NO auth required)
    GET  /motors                — current motor channel states
    GET  /sensors               — current IMU readings
    GET  /metrics               — Prometheus-compatible metrics
    POST /token                 — issue a new API token
    WS   /ws                    — real-time bidirectional control

Auth: Bearer JWT tokens. Get one via POST /token.
Rate limiting: 60 requests/minute per IP (configurable).
"""

from __future__ import annotations

import time
import logging
from typing import Optional

from fastapi import Depends, FastAPI, HTTPException, Request, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import PlainTextResponse
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
import asyncio

from voxyn import __version__
from voxyn.core.auth import get_auth_manager, verify_token
from voxyn.core.config import settings
from voxyn.core.pipeline import NeuralPipeline
from voxyn.core.types import (
    CommandRequest,
    CommandResponse,
    HealthResponse,
    TokenRequest,
    TokenResponse,
)

logger = logging.getLogger(__name__)

# ─── App factory ──────────────────────────────────────────────────────────────

def create_app(pipeline: Optional[NeuralPipeline] = None) -> FastAPI:
    """
    Create and configure the FastAPI application.

    Accepts an optional pre-built pipeline for testing/dependency injection.
    """
    app = FastAPI(
        title="VOXYN.io API",
        description="Natural language to robot hardware control — 100% local, 100% offline.",
        version=__version__,
        docs_url="/docs",
        redoc_url="/redoc",
        openapi_tags=[
            {"name": "commands", "description": "Send commands to the robot"},
            {"name": "status", "description": "Health, metrics, motor and sensor status"},
            {"name": "auth", "description": "Token management"},
        ],
    )

    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.api.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # Store pipeline on app state so routes can access it
    app.state.pipeline = pipeline or NeuralPipeline()

    # ─── Lifecycle ────────────────────────────────────────────────────────

    @app.on_event("startup")
    async def on_startup() -> None:
        await app.state.pipeline.start()
        logger.info("VOXYN API v%s started on %s:%d", __version__, settings.api.host, settings.api.port)

    @app.on_event("shutdown")
    async def on_shutdown() -> None:
        await app.state.pipeline.stop()
        logger.info("VOXYN API shutdown complete")

    # ─── Auth ─────────────────────────────────────────────────────────────

    security = HTTPBearer(auto_error=False)

    async def require_auth(
        credentials: Optional[HTTPAuthorizationCredentials] = Depends(security),
    ) -> bool:
        if not await verify_token(credentials):
            raise HTTPException(status_code=401, detail="Invalid or missing bearer token")
        return True

    # ─── Status Endpoints ─────────────────────────────────────────────────

    @app.get("/health", response_model=HealthResponse, tags=["status"])
    async def health(request: Request) -> HealthResponse:
        """Health check. Returns status of all pipeline components and version."""
        components = await request.app.state.pipeline.health_check()
        return HealthResponse(
            status="ok",
            version=__version__,
            components=components,
            timestamp=time.time(),
        )

    @app.get("/motors", tags=["status"])
    async def get_motors(request: Request) -> dict:
        """Current state of all 16 motor/servo channels."""
        return await request.app.state.pipeline.get_motor_status()

    @app.get("/sensors", tags=["status"])
    async def get_sensors(request: Request) -> dict:
        """Current IMU readings (accelerometer + gyroscope)."""
        return await request.app.state.pipeline.get_sensor_data()

    @app.get("/metrics", response_class=PlainTextResponse, tags=["status"])
    async def get_metrics(request: Request) -> str:
        """Prometheus-compatible metrics. Scrape with your monitoring stack."""
        return request.app.state.pipeline.metrics.prometheus_output()

    @app.get("/metrics/json", tags=["status"])
    async def get_metrics_json(request: Request) -> dict:
        """Pipeline latency metrics in JSON format."""
        return await request.app.state.pipeline.get_metrics()

    # ─── Command Endpoints ────────────────────────────────────────────────

    @app.post("/command/text", response_model=CommandResponse, tags=["commands"])
    async def command_text(
        request: Request,
        body: CommandRequest,
        _auth: bool = Depends(require_auth),
    ) -> CommandResponse:
        """
        Send a natural language command to the robot.

        Example: `{"command": "move forward for 2 seconds at 70% speed"}`
        """
        return await request.app.state.pipeline.process_text(body.command)

    @app.post("/command/raw", tags=["commands"])
    async def command_raw(
        request: Request,
        body: dict,
        _auth: bool = Depends(require_auth),
    ) -> dict:
        """
        Send a pre-structured JSON command (skip NLU).

        Example: `{"action": "servo", "channel": 0, "angle": 90}`
        """
        return await request.app.state.pipeline.execute_raw(body)

    @app.post("/emergency-stop", tags=["commands"])
    async def emergency_stop(request: Request) -> dict:
        """
        Immediately stop all motors. **No authentication required.**

        This endpoint is intentionally open — safety should never require auth.
        """
        await request.app.state.pipeline.emergency_stop()
        return {"status": "stopped", "timestamp": time.time()}

    # ─── Auth Endpoints ───────────────────────────────────────────────────

    @app.post("/token", response_model=TokenResponse, tags=["auth"])
    async def create_token(body: TokenRequest) -> TokenResponse:
        """
        Issue a new API token for a client.

        Tokens expire after 24 hours.
        Keep tokens secure — they grant full robot control.
        """
        auth = get_auth_manager()
        token = auth.generate_token(body.client_id, body.permissions)
        return TokenResponse(
            token=token,
            expires_in_hours=24,
            client_id=body.client_id,
        )

    # ─── WebSocket ────────────────────────────────────────────────────────

    @app.websocket("/ws")
    async def websocket_endpoint(ws: WebSocket) -> None:
        """
        Real-time bidirectional robot control over WebSocket.

        Client → Server message types:
            `{"type": "command", "text": "move forward"}` — NL command
            `{"type": "raw", "command": {...}}`           — structured command
            `{"type": "stop"}`                            — emergency stop
            `{"type": "ping"}`                            — keepalive

        Server → Client message types:
            `{"type": "result", "success": true, "latency_ms": 152}`
            `{"type": "sensor", "data": {...}, "timestamp": ...}`
            `{"type": "pong"}`
            `{"type": "error", "message": "..."}`
        """
        await ws.accept()
        pipeline: NeuralPipeline = ws.app.state.pipeline
        logger.info("WebSocket client connected: %s", ws.client)

        async def sensor_stream() -> None:
            """Push sensor data to client at 20Hz."""
            while True:
                try:
                    sensors = await pipeline.get_sensor_data()
                    await ws.send_json({
                        "type": "sensor",
                        "data": sensors,
                        "timestamp": time.time(),
                    })
                    await asyncio.sleep(0.05)  # 20Hz
                except Exception:
                    break

        sensor_task = asyncio.create_task(sensor_stream())

        try:
            while True:
                data = await ws.receive_json()
                msg_type = data.get("type")

                if msg_type == "command":
                    text = data.get("text", "").strip()
                    if not text:
                        await ws.send_json({"type": "error", "message": "Empty command"})
                        continue
                    result = await pipeline.process_text(text)
                    await ws.send_json({
                        "type": "result",
                        "success": result.success,
                        "intent": result.intent,
                        "latency_ms": result.duration_ms,
                        "breakdown": result.pipeline_breakdown,
                        "error": result.error,
                    })

                elif msg_type == "raw":
                    command = data.get("command", {})
                    result_dict = await pipeline.execute_raw(command)
                    await ws.send_json({"type": "result", **result_dict})

                elif msg_type == "stop":
                    await pipeline.emergency_stop()
                    await ws.send_json({"type": "stopped", "timestamp": time.time()})

                elif msg_type == "ping":
                    await ws.send_json({"type": "pong", "timestamp": time.time()})

                else:
                    await ws.send_json({
                        "type": "error",
                        "message": f"Unknown message type: '{msg_type}'",
                    })

        except WebSocketDisconnect:
            logger.info("WebSocket client disconnected: %s", ws.client)
        except Exception as e:
            logger.error("WebSocket error: %s", e)
        finally:
            sensor_task.cancel()
            # Safety: always emergency stop on disconnect
            await pipeline.emergency_stop()

    return app


# Module-level app instance for uvicorn (used by daemon and Docker)
app = create_app()
