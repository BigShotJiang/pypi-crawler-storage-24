"""
Natural Language Understanding — converts text commands to structured robot intents.

Uses a fine-tuned Phi-3-mini model running via llama.cpp. The model is fine-tuned
specifically on robotics commands so it:
- Never hallucinates non-existent motors
- Always outputs valid JSON
- Understands relative vs absolute movement
- Handles compound commands ("go forward then turn left")

Performance: ~60ms on Raspberry Pi 5 with Q4_K_M quantization.
"""

from __future__ import annotations

import json
import logging
import time
from functools import lru_cache
from pathlib import Path
from typing import Any, Optional

from voxyn.core.config import settings
from voxyn.core.types import Intent, NLUResult

logger = logging.getLogger(__name__)

SYSTEM_PROMPT = """You are a robotics command parser. Convert natural language to JSON.

Output ONLY valid JSON. No explanation. No markdown. No extra text.

Available actions:
- move: {action: "move", direction: "forward"|"backward"|"left"|"right", speed: 0-100, duration: seconds}
- rotate: {action: "rotate", angle: degrees, direction: "clockwise"|"counterclockwise", speed: 0-100}
- servo: {action: "servo", channel: 0-15, angle: 0-180}
- stop: {action: "stop"}
- sequence: {action: "sequence", commands: [{...}, {...}]}
- wait: {action: "wait", duration: seconds}
- if_sensor: {action: "if_sensor", sensor: string, condition: string, then: {action...}}

Safety constraints (enforced externally, just parse accurately):
- speed: 0-100
- duration: 0-60 seconds
- servo angle: 0-180
- rotation angle: 0-360
- If command is unclear, return: {"action": "clarify", "message": "brief one-sentence question"}

Examples:
Input: move forward for 3 seconds at half speed
Output: {"action":"move","direction":"forward","speed":50,"duration":3}

Input: turn right 90 degrees
Output: {"action":"rotate","angle":90,"direction":"clockwise","speed":60}

Input: set arm servo channel 2 to 45 degrees
Output: {"action":"servo","channel":2,"angle":45}

Input: go forward then turn left
Output: {"action":"sequence","commands":[{"action":"move","direction":"forward","speed":70,"duration":1},{"action":"rotate","angle":90,"direction":"counterclockwise","speed":50}]}

Input: stop
Output: {"action":"stop"}"""


# Common commands that are always parsed the same way — skip LLM for these
_FAST_PATH: dict[str, dict[str, Any]] = {
    "stop": {"action": "stop"},
    "stop everything": {"action": "stop"},
    "emergency stop": {"action": "stop"},
    "halt": {"action": "stop"},
    "go forward": {"action": "move", "direction": "forward", "speed": 70, "duration": 1},
    "go backward": {"action": "move", "direction": "backward", "speed": 70, "duration": 1},
    "go back": {"action": "move", "direction": "backward", "speed": 70, "duration": 1},
    "turn left": {"action": "rotate", "angle": 90, "direction": "counterclockwise", "speed": 60},
    "turn right": {"action": "rotate", "angle": 90, "direction": "clockwise", "speed": 60},
}


class IntentParser:
    """
    Converts natural language commands to structured robot intents.

    Fast path: exact-match cache for common commands (0ms)
    Slow path: LLM inference via llama.cpp (~60ms)
    """

    def __init__(self, model_path: Optional[str] = None) -> None:
        self.model_path = Path(model_path or settings.models.nlu)
        self._llm = None
        self._cache: dict[str, NLUResult] = {}
        # Model is loaded lazily on first parse() call so the server can start
        # without llama-cpp-python installed or the model file present.

    def _load_model(self) -> None:
        """Load llama.cpp model. Runs on CPU (Hailo handles ASR and vision)."""
        try:
            from llama_cpp import Llama
        except ImportError:
            raise ImportError(
                "llama-cpp-python not installed. Run: pip install llama-cpp-python"
            )

        logger.info("Loading NLU model: %s", self.model_path)
        t0 = time.perf_counter()
        self._llm = Llama(
            model_path=str(self.model_path),
            n_ctx=settings.performance.nlu_context_size,
            n_threads=settings.performance.asr_threads,
            n_gpu_layers=0,        # CPU inference (Hailo handles vision + ASR)
            use_mlock=settings.performance.model_lock_ram,
            verbose=False,
        )
        elapsed = (time.perf_counter() - t0) * 1000
        logger.info("NLU model loaded in %.0fms", elapsed)

    def parse(self, text: str) -> NLUResult:
        """
        Parse a natural language command into a structured Intent.

        Args:
            text: Raw text from user (voice transcription or typed)

        Returns:
            NLUResult with intent, confidence, and inference timing
        """
        # Lazy-load model on first real parse call
        if self._llm is None and self.model_path.exists():
            try:
                self._load_model()
            except Exception as e:
                logger.warning("Could not load NLU model: %s", e)

        text = text.strip()
        key = text.lower()

        # 1. Fast path: exact-match cache
        if key in self._cache:
            cached = self._cache[key]
            logger.debug("Cache hit: '%s'", text)
            return cached

        # 2. Fast path: hardcoded common commands
        if key in _FAST_PATH:
            result = self._make_result(_FAST_PATH[key], raw=json.dumps(_FAST_PATH[key]), duration_ms=0.1)
            return result

        # 3. Slow path: LLM inference
        return self._llm_parse(text)

    def _llm_parse(self, text: str) -> NLUResult:
        """Run LLM inference to parse the command."""
        if self._llm is None:
            return self._error_result(text, "NLU model not loaded")

        t0 = time.perf_counter()

        try:
            response = self._llm.create_chat_completion(
                messages=[
                    {"role": "system", "content": SYSTEM_PROMPT},
                    {"role": "user", "content": text},
                ],
                max_tokens=256,
                temperature=0.0,    # deterministic output
                top_p=1.0,
                repeat_penalty=1.0,
                stop=["}\n\n", "```"],
            )
            elapsed_ms = (time.perf_counter() - t0) * 1000
            raw_json = response["choices"][0]["message"]["content"].strip()

            # Strip any accidental markdown fences
            if raw_json.startswith("```"):
                raw_json = raw_json.split("```")[1].strip()
                if raw_json.startswith("json"):
                    raw_json = raw_json[4:].strip()

            intent_data = json.loads(raw_json)
            result = self._make_result(intent_data, raw=raw_json, duration_ms=elapsed_ms)

            # Cache up to settings.performance.command_cache_size entries
            if len(self._cache) < settings.performance.command_cache_size:
                self._cache[text.lower()] = result

            logger.debug("LLM parse: '%s' → %s (%.1fms)", text[:60], intent_data.get("action"), elapsed_ms)
            return result

        except json.JSONDecodeError as e:
            elapsed_ms = (time.perf_counter() - t0) * 1000
            logger.warning("JSON decode error for '%s': %s", text, e)
            return self._error_result(text, f"Could not parse: {text}", elapsed_ms)
        except Exception as e:
            elapsed_ms = (time.perf_counter() - t0) * 1000
            logger.error("LLM inference error: %s", e)
            return self._error_result(text, str(e), elapsed_ms)

    def _make_result(
        self,
        data: dict[str, Any],
        raw: str,
        duration_ms: float,
        confidence: float = 0.9,
    ) -> NLUResult:
        try:
            intent = Intent(**data)
            return NLUResult(intent=intent, raw=raw, duration_ms=duration_ms, confidence=confidence)
        except Exception as e:
            return self._error_result(raw, str(e), duration_ms)

    def _error_result(self, text: str, message: str, duration_ms: float = 0.0) -> NLUResult:
        return NLUResult(
            intent=Intent(action="error", message=message),
            raw=text,
            duration_ms=duration_ms,
            confidence=0.0,
        )

    def clear_cache(self) -> None:
        """Clear the command cache (useful for testing)."""
        self._cache.clear()
