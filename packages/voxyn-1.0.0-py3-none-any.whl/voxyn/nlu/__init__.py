"""NLU (Natural Language Understanding) — converts text to structured robot intents."""
