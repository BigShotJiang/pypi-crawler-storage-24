"""
JWT-based authentication for VOXYN API.

Keys are generated on first boot and stored locally at /etc/voxyn/signing_key.
Tokens expire after 24 hours by default.

Design principles:
- No external auth service — fully local, offline-first
- Signing key persists across restarts (stored in /etc/voxyn/, mode 0600)
- Tokens carry permissions so we can scope access (read vs command vs admin)
"""

from __future__ import annotations

import secrets
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import jwt
from fastapi.security import HTTPAuthorizationCredentials

from voxyn.core.config import settings

def _default_key_file() -> Path:
    """Return key file path: /etc/voxyn/ on Linux servers, ~/.voxyn/ on Mac/dev."""
    system_path = Path("/etc/voxyn/signing_key")
    try:
        system_path.parent.mkdir(parents=True, exist_ok=True)
        return system_path
    except PermissionError:
        local = Path.home() / ".voxyn" / "signing_key"
        local.parent.mkdir(parents=True, exist_ok=True)
        return local

KEY_FILE = _default_key_file()
TOKEN_EXPIRY_HOURS = 24
ALGORITHM = "HS256"


class AuthManager:
    """Manages token generation and verification for VOXYN API."""

    def __init__(self) -> None:
        self.signing_key = self._load_or_generate_key()

    def _load_or_generate_key(self) -> str:
        KEY_FILE.parent.mkdir(parents=True, exist_ok=True)
        if KEY_FILE.exists():
            return KEY_FILE.read_text().strip()
        key = secrets.token_hex(32)
        KEY_FILE.write_text(key)
        KEY_FILE.chmod(0o600)
        return key

    def generate_token(
        self,
        client_id: str,
        permissions: Optional[list[str]] = None,
    ) -> str:
        """Generate a signed JWT token for a client."""
        if permissions is None:
            permissions = ["command", "read"]

        now = datetime.now(tz=timezone.utc)
        payload = {
            "sub": client_id,
            "permissions": permissions,
            "iat": now,
            "exp": now + timedelta(hours=TOKEN_EXPIRY_HOURS),
        }
        return jwt.encode(payload, self.signing_key, algorithm=ALGORITHM)

    def verify_token(self, token: str) -> Optional[dict]:
        """
        Verify a JWT token. Returns the decoded payload on success, None on failure.
        """
        try:
            return jwt.decode(token, self.signing_key, algorithms=[ALGORITHM])
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None

    def has_permission(self, token: str, permission: str) -> bool:
        """Check if a token carries a specific permission."""
        payload = self.verify_token(token)
        if not payload:
            return False
        return permission in payload.get("permissions", [])


# Module-level singleton
_auth_manager: Optional[AuthManager] = None


def get_auth_manager() -> AuthManager:
    global _auth_manager
    if _auth_manager is None:
        _auth_manager = AuthManager()
    return _auth_manager


async def verify_token(
    credentials: Optional[HTTPAuthorizationCredentials],
) -> bool:
    """
    FastAPI dependency: returns True if the request carries a valid token.

    Emergency stop endpoint skips this check (no auth required for safety).
    """
    if credentials is None:
        return False
    manager = get_auth_manager()
    payload = manager.verify_token(credentials.credentials)
    return payload is not None
