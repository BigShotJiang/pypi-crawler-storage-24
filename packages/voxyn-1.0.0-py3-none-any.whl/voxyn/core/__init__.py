"""Core VOXYN components: types, config, auth, metrics, pipeline."""
