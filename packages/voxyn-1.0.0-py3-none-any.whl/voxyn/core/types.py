"""
Shared Pydantic models used across the entire VOXYN pipeline.

All data crossing component boundaries uses these types, which gives us:
- Automatic validation at every boundary
- Auto-generated OpenAPI schema
- Serializable to/from JSON for ZeroMQ transport
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field, field_validator


# ─── Enumerations ─────────────────────────────────────────────────────────────


class Direction(str, Enum):
    FORWARD = "forward"
    BACKWARD = "backward"
    LEFT = "left"
    RIGHT = "right"


class RotationDirection(str, Enum):
    CLOCKWISE = "clockwise"
    COUNTERCLOCKWISE = "counterclockwise"


class ActionType(str, Enum):
    MOVE = "move"
    ROTATE = "rotate"
    SERVO = "servo"
    STOP = "stop"
    SEQUENCE = "sequence"
    WAIT = "wait"
    IF_SENSOR = "if_sensor"
    CLARIFY = "clarify"
    ERROR = "error"


# ─── Pipeline Stage Results ────────────────────────────────────────────────────


class ASRResult(BaseModel):
    """Result from the Whisper speech-to-text engine."""

    text: str
    confidence: float = Field(ge=0.0, le=1.0)
    duration_ms: float = Field(ge=0.0)


class Intent(BaseModel):
    """
    Structured robot command parsed from natural language.

    The NLU model produces this. The safety validator checks this.
    The executor receives this (serialized to JSON via ZeroMQ).
    """

    action: str
    direction: Optional[str] = None
    speed: Optional[float] = Field(default=None, ge=0.0, le=100.0)
    duration: Optional[float] = Field(default=None, ge=0.0)
    angle: Optional[float] = None
    channel: Optional[int] = Field(default=None, ge=0, le=15)
    commands: Optional[list[dict[str, Any]]] = None
    message: Optional[str] = None
    sensor: Optional[str] = None
    condition: Optional[str] = None
    then: Optional[dict[str, Any]] = None

    @field_validator("action")
    @classmethod
    def action_must_be_known(cls, v: str) -> str:
        known = {a.value for a in ActionType}
        if v not in known:
            raise ValueError(f"Unknown action '{v}'. Must be one of: {known}")
        return v


class NLUResult(BaseModel):
    """Result from the intent parser (LLM inference)."""

    intent: Intent
    raw: str
    duration_ms: float = Field(ge=0.0)
    confidence: float = Field(ge=0.0, le=1.0)


class SafetyResult(BaseModel):
    """Pass/fail result from the safety validator."""

    passed: bool
    reason: str


# ─── API Request / Response Models ────────────────────────────────────────────


class CommandRequest(BaseModel):
    """Incoming text command from REST API client."""

    command: str = Field(..., min_length=1, max_length=500, description="Natural language command")


class CommandResponse(BaseModel):
    """Response returned to REST API client after command processing."""

    success: bool
    intent: Optional[dict[str, Any]] = None
    error: Optional[str] = None
    duration_ms: float
    pipeline_breakdown: Optional[dict[str, float]] = None


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    version: str
    components: dict[str, Any]
    timestamp: float


class TokenRequest(BaseModel):
    """Request a new API token."""

    client_id: str = Field(..., min_length=1, max_length=64)
    permissions: list[str] = Field(default_factory=lambda: ["command", "read"])


class TokenResponse(BaseModel):
    """New API token."""

    token: str
    expires_in_hours: int
    client_id: str
