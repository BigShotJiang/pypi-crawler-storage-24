"""
VOXYN configuration system.

Loads from /etc/voxyn/config.toml (production) or ./config/config.toml (dev).
All values can be overridden with environment variables prefixed VOXYN_.

Example:
    VOXYN_API__PORT=9090 overrides config.api.port
"""

from __future__ import annotations

import os
from pathlib import Path
from typing import Optional

try:
    import tomllib  # Python 3.11+
except ImportError:
    import tomli as tomllib  # type: ignore[no-redef]

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class GeneralSettings(BaseSettings):
    log_level: str = "INFO"
    log_file: str = "/var/log/voxyn/voxyn.log"
    mock_hardware: bool = False

    model_config = SettingsConfigDict(env_prefix="VOXYN_GENERAL_", populate_by_name=True)


class ModelSettings(BaseSettings):
    whisper: str = "models/whisper-base.en.bin"
    nlu: str = "models/phi3-mini-robotics.gguf"
    whisper_checksum: Optional[str] = None
    nlu_checksum: Optional[str] = None

    model_config = SettingsConfigDict(env_prefix="VOXYN_MODELS_")


class APISettings(BaseSettings):
    host: str = "0.0.0.0"
    port: int = Field(default=8080, ge=1, le=65535)
    enable_tls: bool = False
    tls_cert: Optional[str] = None
    tls_key: Optional[str] = None
    cors_origins: list[str] = Field(default_factory=lambda: ["*"])
    rate_limit_per_minute: int = 60

    model_config = SettingsConfigDict(env_prefix="VOXYN_API_")


class SafetySettings(BaseSettings):
    max_speed: float = Field(default=100.0, ge=0.0, le=100.0)
    max_duration_seconds: float = Field(default=30.0, ge=0.0, le=60.0)
    max_servo_angle: float = Field(default=180.0, ge=0.0, le=180.0)
    min_servo_angle: float = Field(default=0.0, ge=0.0)
    max_rotation_angle: float = Field(default=360.0, ge=0.0, le=360.0)
    max_sequence_length: int = Field(default=20, ge=1, le=50)
    enable_watchdog: bool = True
    watchdog_timeout_seconds: float = Field(default=5.0, ge=1.0, le=30.0)

    model_config = SettingsConfigDict(env_prefix="VOXYN_SAFETY_")


class HardwareSettings(BaseSettings):
    i2c_bus: int = Field(default=1, ge=0, le=9)
    pca9685_address: int = 0x40
    pwm_frequency_servos: int = Field(default=50, ge=25, le=400)
    pwm_frequency_motors: int = Field(default=1000, ge=100, le=10000)
    imu_i2c_address: int = 0x68

    model_config = SettingsConfigDict(env_prefix="VOXYN_HARDWARE_")


class PerformanceSettings(BaseSettings):
    asr_threads: int = Field(default=4, ge=1, le=16)
    nlu_context_size: int = Field(default=512, ge=128, le=2048)
    model_lock_ram: bool = True
    command_cache_size: int = Field(default=1000, ge=0)

    model_config = SettingsConfigDict(env_prefix="VOXYN_PERFORMANCE_")


class ZeroMQSettings(BaseSettings):
    executor_port: int = 5554
    asr_port: int = 5551
    nlu_port: int = 5552
    monitor_port: int = 9090

    model_config = SettingsConfigDict(env_prefix="VOXYN_ZMQ_")


class VoxynSettings(BaseSettings):
    """Root settings object. Loads from TOML config + environment overrides."""

    general: GeneralSettings = Field(default_factory=GeneralSettings)
    models: ModelSettings = Field(default_factory=ModelSettings)
    api: APISettings = Field(default_factory=APISettings)
    safety: SafetySettings = Field(default_factory=SafetySettings)
    hardware: HardwareSettings = Field(default_factory=HardwareSettings)
    performance: PerformanceSettings = Field(default_factory=PerformanceSettings)
    zmq: ZeroMQSettings = Field(default_factory=ZeroMQSettings)

    model_config = SettingsConfigDict(env_prefix="VOXYN_")

    @classmethod
    def from_toml(cls, path: Path) -> "VoxynSettings":
        """Load settings from a TOML file, then apply env overrides."""
        if not path.exists():
            return cls()

        with open(path, "rb") as f:
            raw = tomllib.load(f)

        return cls(
            general=GeneralSettings(**raw.get("general", {})),
            models=ModelSettings(**raw.get("models", {})),
            api=APISettings(**raw.get("api", {})),
            safety=SafetySettings(**raw.get("safety", {})),
            hardware=HardwareSettings(**raw.get("hardware", {})),
            performance=PerformanceSettings(**raw.get("performance", {})),
            zmq=ZeroMQSettings(**raw.get("zmq", {})),
        )


def load_settings() -> VoxynSettings:
    """
    Load settings with the following precedence (highest first):
    1. Environment variables (VOXYN_*)
    2. /etc/voxyn/config.toml (production)
    3. ./config/config.toml (development)
    4. Built-in defaults
    """
    import os

    config_paths = [
        Path("/etc/voxyn/config.toml"),
        Path("config/config.toml"),
        Path("config.toml"),
    ]

    base: VoxynSettings
    for path in config_paths:
        if path.exists():
            base = VoxynSettings.from_toml(path)
            break
    else:
        base = VoxynSettings()

    # Apply top-level env overrides that span multiple sub-settings
    if os.environ.get("VOXYN_MOCK_HARDWARE", "").lower() in ("1", "true", "yes"):
        base.general.mock_hardware = True

    return base


# Module-level singleton — import this everywhere
settings = load_settings()
