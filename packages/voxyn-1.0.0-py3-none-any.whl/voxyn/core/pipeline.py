"""
VOXYN Neural Pipeline — the central orchestrator.

Connects all pipeline stages:
    Text/Voice → NLU → Safety → ZeroMQ → Rust Executor → Hardware

The pipeline is the only place that knows about all components.
Individual modules (asr, nlu, safety) have no knowledge of each other.
"""

from __future__ import annotations

import asyncio
import json
import time
from typing import Any, Optional

import zmq
import zmq.asyncio

from voxyn.core.config import settings
from voxyn.core.metrics import PipelineMetrics
from voxyn.core.types import CommandResponse, Intent
from voxyn.nlu.intent_parser import IntentParser
from voxyn.safety.validator import SafetyValidator
from voxyn.safety.watchdog import HardwareWatchdog

import logging

logger = logging.getLogger(__name__)


class NeuralPipeline:
    """
    Orchestrates the full VOXYN pipeline.

    Text/Voice → NLU → Safety Validator → ZeroMQ → Rust Executor → Hardware

    All heavy models (Whisper, LLM) are loaded once at init and kept in RAM
    (mlock=True). The ZeroMQ DEALER socket connects to the Rust executor
    process which handles real-time PWM control.
    """

    def __init__(self) -> None:
        self.nlu = IntentParser()
        self.validator = SafetyValidator(
            user_limits={
                "max_speed": settings.safety.max_speed,
                "max_duration_seconds": settings.safety.max_duration_seconds,
                "max_servo_angle": settings.safety.max_servo_angle,
                "max_sequence_length": settings.safety.max_sequence_length,
            }
        )
        self.metrics = PipelineMetrics()

        self._zmq_ctx = zmq.asyncio.Context()
        self._executor_socket: Optional[zmq.asyncio.Socket] = None
        self._watchdog: Optional[HardwareWatchdog] = None
        self._watchdog_task: Optional[asyncio.Task] = None

        # Cached motor state for /motors endpoint
        self._motor_states: dict[int, float] = {i: 0.0 for i in range(16)}

    async def start(self) -> None:
        """Connect to executor and start watchdog. Call once at startup."""
        self._executor_socket = self._zmq_ctx.socket(zmq.DEALER)
        executor_port = settings.zmq.executor_port
        self._executor_socket.connect(f"tcp://localhost:{executor_port}")
        logger.info("Connected to Rust executor on port %d", executor_port)

        if settings.safety.enable_watchdog and not settings.general.mock_hardware:
            self._watchdog = HardwareWatchdog(
                stop_callback=self.emergency_stop,
                timeout=settings.safety.watchdog_timeout_seconds,
            )
            self._watchdog_task = asyncio.create_task(self._watchdog.start())
            logger.info("Hardware watchdog started (timeout=%ss)", settings.safety.watchdog_timeout_seconds)
        elif settings.general.mock_hardware:
            logger.info("Mock mode: hardware watchdog disabled")

    async def stop(self) -> None:
        """Graceful shutdown: stop watchdog, close ZMQ connections."""
        if self._watchdog:
            self._watchdog.stop()
        if self._watchdog_task:
            self._watchdog_task.cancel()
        await self.emergency_stop()
        if self._executor_socket:
            self._executor_socket.close()
        self._zmq_ctx.term()

    # ─── Command Processing ─────────────────────────────────────────────────

    async def process_text(self, text: str) -> CommandResponse:
        """
        Full pipeline: text → NLU → safety check → execute → response.

        Returns CommandResponse with success flag, intent, timing breakdown.
        """
        t0 = time.perf_counter()
        breakdown: dict[str, float] = {}

        # 1. NLU: natural language → structured intent
        with self.metrics.measure("nlu"):
            t1 = time.perf_counter()
            nlu_result = self.nlu.parse(text)
            breakdown["nlu_ms"] = round((time.perf_counter() - t1) * 1000, 2)

        logger.debug("NLU result: %s (%.1fms)", nlu_result.intent.action, breakdown["nlu_ms"])

        # 2. Safety: hard gate before any hardware interaction
        safety = self.validator.validate(nlu_result.intent)
        if not safety.passed:
            self.metrics.increment_errors()
            logger.warning("Safety block: %s", safety.reason)
            return CommandResponse(
                success=False,
                error=f"Safety block: {safety.reason}",
                duration_ms=round((time.perf_counter() - t0) * 1000, 2),
            )

        # 3. Execute: send to Rust executor via ZeroMQ
        with self.metrics.measure("executor"):
            t2 = time.perf_counter()
            await self._send_to_executor(nlu_result.intent.model_dump(exclude_none=True))
            breakdown["exec_ms"] = round((time.perf_counter() - t2) * 1000, 2)

        if self._watchdog:
            self._watchdog.heartbeat()

        self.metrics.increment_commands()
        total_ms = round((time.perf_counter() - t0) * 1000, 2)
        self.metrics.record("total", total_ms)

        logger.info("Command executed: '%s' → %s (%.1fms total)", text, nlu_result.intent.action, total_ms)

        return CommandResponse(
            success=True,
            intent=nlu_result.intent.model_dump(exclude_none=True),
            duration_ms=total_ms,
            pipeline_breakdown=breakdown,
        )

    async def execute_raw(self, command: dict[str, Any]) -> dict[str, Any]:
        """
        Execute a pre-structured command (skip NLU).
        Still passes through the safety validator.
        """
        try:
            intent = Intent(**command)
        except Exception as e:
            return {"success": False, "error": f"Invalid command schema: {e}"}

        safety = self.validator.validate(intent)
        if not safety.passed:
            return {"success": False, "error": safety.reason}

        await self._send_to_executor(command)
        if self._watchdog:
            self._watchdog.heartbeat()
        self.metrics.increment_commands()
        return {"success": True}

    async def emergency_stop(self) -> None:
        """Immediately stop all motors. No auth required. No safety check."""
        logger.warning("EMERGENCY STOP triggered")
        await self._send_to_executor({"action": "stop"})
        self._motor_states = {i: 0.0 for i in range(16)}

    # ─── Sensor & Status ────────────────────────────────────────────────────

    async def get_sensor_data(self) -> dict[str, Any]:
        """Return current IMU readings (accelerometer + gyroscope)."""
        if settings.general.mock_hardware:
            return {
                "imu": {"ax": 0.0, "ay": 0.0, "az": 9.81, "gx": 0.0, "gy": 0.0, "gz": 0.0},
                "mock": True,
            }
        # TODO: read live from IMU via I2C when running on real hardware
        return {"imu": {"ax": 0.0, "ay": 0.0, "az": 9.81, "gx": 0.0, "gy": 0.0, "gz": 0.0}}

    async def get_motor_status(self) -> dict[str, Any]:
        """Return current state of all 16 motor/servo channels."""
        return {
            "channels": [
                {"id": i, "speed": self._motor_states.get(i, 0.0)}
                for i in range(16)
            ]
        }

    async def health_check(self) -> dict[str, Any]:
        """Component-level health check for the /health endpoint."""
        return {
            "nlu": "ok" if self.nlu else "unavailable",
            "executor": "ok" if self._executor_socket else "disconnected",
            "watchdog": "ok" if self._watchdog else "disabled",
            "metrics": self.metrics.report(),
        }

    async def get_metrics(self) -> dict[str, Any]:
        return self.metrics.report()

    # ─── Internal ───────────────────────────────────────────────────────────

    async def _send_to_executor(self, command: dict[str, Any]) -> None:
        """Serialize command to JSON and send via ZeroMQ to Rust executor."""
        if self._executor_socket is None:
            if settings.general.mock_hardware:
                logger.debug("Mock hardware: would send %s", command)
                return
            raise RuntimeError("Executor socket not initialized. Call pipeline.start() first.")

        msg = json.dumps(command).encode("utf-8")
        await self._executor_socket.send(msg)
