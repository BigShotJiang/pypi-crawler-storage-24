"""
Performance metrics for the VOXYN pipeline.

Tracks latency at each stage (ASR, NLU, executor, total) using a rolling
window of the last 100 measurements. Also provides Prometheus-compatible output.

Usage:
    metrics = PipelineMetrics()
    metrics.record("asr", 82.3)
    metrics.record("nlu", 61.1)
    report = metrics.report()
"""

from __future__ import annotations

import time
from collections import deque
from contextlib import contextmanager
from dataclasses import dataclass, field
from statistics import mean, stdev
from typing import Generator


@dataclass
class StageMetrics:
    latencies: deque = field(default_factory=lambda: deque(maxlen=100))

    def record(self, latency_ms: float) -> None:
        self.latencies.append(latency_ms)

    def stats(self) -> dict:
        if not self.latencies:
            return {"mean": 0, "p95": 0, "p99": 0, "min": 0, "max": 0, "stdev": 0, "samples": 0}
        lst = sorted(self.latencies)
        n = len(lst)
        return {
            "mean": round(mean(lst), 2),
            "p95": round(lst[int(n * 0.95)], 2),
            "p99": round(lst[int(n * 0.99)], 2),
            "min": round(min(lst), 2),
            "max": round(max(lst), 2),
            "stdev": round(stdev(lst) if n > 1 else 0.0, 2),
            "samples": n,
        }


class PipelineMetrics:
    """Rolling-window latency tracker for each pipeline stage."""

    def __init__(self) -> None:
        self._stages: dict[str, StageMetrics] = {
            "asr": StageMetrics(),
            "nlu": StageMetrics(),
            "executor": StageMetrics(),
            "total": StageMetrics(),
        }
        self.error_count: int = 0
        self.command_count: int = 0
        self._start_time: float = time.time()

    def record(self, stage: str, latency_ms: float) -> None:
        """Record a latency measurement for a pipeline stage."""
        if stage not in self._stages:
            self._stages[stage] = StageMetrics()
        self._stages[stage].record(latency_ms)

    def increment_errors(self) -> None:
        self.error_count += 1

    def increment_commands(self) -> None:
        self.command_count += 1

    @contextmanager
    def measure(self, stage: str) -> Generator[None, None, None]:
        """Context manager for timing a code block."""
        t0 = time.perf_counter()
        try:
            yield
        finally:
            elapsed_ms = (time.perf_counter() - t0) * 1000
            self.record(stage, elapsed_ms)

    def report(self) -> dict:
        """Full metrics report, suitable for the /metrics API endpoint."""
        uptime_seconds = time.time() - self._start_time
        return {
            "stages": {name: stage.stats() for name, stage in self._stages.items()},
            "error_rate": round(self.error_count / max(self.command_count, 1), 4),
            "commands_processed": self.command_count,
            "error_count": self.error_count,
            "uptime_seconds": round(uptime_seconds, 1),
        }

    def prometheus_output(self) -> str:
        """Prometheus text format for scraping."""
        lines = [
            f"# HELP voxyn_commands_total Total commands processed",
            f"# TYPE voxyn_commands_total counter",
            f"voxyn_commands_total {self.command_count}",
            f"# HELP voxyn_errors_total Total command errors",
            f"# TYPE voxyn_errors_total counter",
            f"voxyn_errors_total {self.error_count}",
        ]
        for stage, sm in self._stages.items():
            stats = sm.stats()
            for metric, value in stats.items():
                if metric == "samples":
                    continue
                lines.append(
                    f'voxyn_latency_ms{{stage="{stage}",quantile="{metric}"}} {value}'
                )
        return "\n".join(lines)
