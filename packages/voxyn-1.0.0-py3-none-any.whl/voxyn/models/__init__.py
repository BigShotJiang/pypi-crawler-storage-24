"""Model download and verification utilities."""
