"""
Model download utility.

Usage:
    python -m voxyn.models.download --model whisper-base.en
    python -m voxyn.models.download --model phi3-mini
    python -m voxyn.models.download --all
"""

from __future__ import annotations

import hashlib
import sys
from pathlib import Path
from typing import Optional
from urllib.request import urlretrieve

import typer
from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, DownloadColumn, TransferSpeedColumn

app = typer.Typer(help="Download VOXYN AI models")
console = Console()

MODELS = {
    "whisper-base.en": {
        "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin",
        "filename": "whisper-base.en.bin",
        "sha256": None,  # set after first stable release
        "size_mb": 148,
        "description": "Whisper base.en — fastest, English only (~80ms on Hailo-8L)",
    },
    "whisper-small.en": {
        "url": "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.en.bin",
        "filename": "whisper-small.en.bin",
        "sha256": None,
        "size_mb": 488,
        "description": "Whisper small.en — better accuracy, ~160ms",
    },
    "phi3-mini": {
        "url": "https://huggingface.co/microsoft/Phi-3-mini-4k-instruct-gguf/resolve/main/Phi-3-mini-4k-instruct-q4.gguf",
        "filename": "phi3-mini-robotics.gguf",
        "sha256": None,
        "size_mb": 2200,
        "description": "Phi-3-mini Q4 NLU model — ~60ms on Pi 5",
    },
}


def download_model(
    name: str,
    output_dir: Path,
    force: bool = False,
) -> Path:
    """Download a model. Returns path to downloaded file."""
    if name not in MODELS:
        raise ValueError(f"Unknown model: {name}. Available: {list(MODELS)}")

    meta = MODELS[name]
    out_path = output_dir / meta["filename"]

    if out_path.exists() and not force:
        console.print(f"[green]Already exists:[/green] {out_path.name} ({out_path.stat().st_size / 1e6:.0f}MB)")
        return out_path

    console.print(f"Downloading [bold]{name}[/bold] (~{meta['size_mb']}MB)...")
    console.print(f"  {meta['description']}")

    def progress_hook(count: int, block_size: int, total_size: int) -> None:
        if total_size > 0:
            pct = min(100, count * block_size * 100 // total_size)
            mb_done = count * block_size / 1e6
            mb_total = total_size / 1e6
            print(f"\r  {pct:3d}% — {mb_done:.0f}/{mb_total:.0f}MB", end="", flush=True)

    # Try urllib first, fall back to curl (better SSL handling on some systems)
    try:
        urlretrieve(meta["url"], str(out_path), reporthook=progress_hook)
        print()
    except Exception as e:
        console.print(f"\n[yellow]urllib failed ({e}), retrying with curl...[/yellow]")
        if out_path.exists():
            out_path.unlink()
        import subprocess
        result = subprocess.run(
            ["curl", "-L", "--progress-bar", "--retry", "3",
             "--retry-delay", "2", meta["url"], "-o", str(out_path)],
            check=False,
        )
        if result.returncode != 0 or not out_path.exists():
            if out_path.exists():
                out_path.unlink()
            raise RuntimeError(f"Download failed with both urllib and curl: {e}") from e

    if meta.get("sha256"):
        console.print("Verifying checksum...")
        sha256 = hashlib.sha256(out_path.read_bytes()).hexdigest()
        if sha256 != meta["sha256"]:
            out_path.unlink()
            raise RuntimeError(f"Checksum mismatch for {name}")

    size_mb = out_path.stat().st_size / 1e6
    console.print(f"[green]Downloaded:[/green] {out_path.name} ({size_mb:.0f}MB)")
    return out_path


@app.command()
def download(
    model: Optional[str] = typer.Option(None, "--model", help="Model name to download"),
    all_models: bool = typer.Option(False, "--all", help="Download all models"),
    output_dir: Path = typer.Option(Path("models"), "--output-dir"),
    force: bool = typer.Option(False, "--force", help="Re-download even if exists"),
) -> None:
    """Download AI models required by VOXYN."""
    output_dir.mkdir(parents=True, exist_ok=True)

    if all_models:
        for name in MODELS:
            try:
                download_model(name, output_dir, force)
            except Exception as e:
                console.print(f"[red]Failed to download {name}: {e}[/red]")
    elif model:
        try:
            download_model(model, output_dir, force)
        except Exception as e:
            console.print(f"[red]Failed: {e}[/red]")
            raise typer.Exit(1)
    else:
        # Default: download the two required models
        for name in ["whisper-base.en", "phi3-mini"]:
            try:
                download_model(name, output_dir, force)
            except Exception as e:
                console.print(f"[red]Failed to download {name}: {e}[/red]")


@app.command()
def list_models() -> None:
    """List available models."""
    from rich.table import Table
    table = Table(title="Available VOXYN Models")
    table.add_column("Name", style="cyan")
    table.add_column("Size (MB)", justify="right")
    table.add_column("Description")

    for name, meta in MODELS.items():
        table.add_row(name, str(meta["size_mb"]), meta["description"])

    console.print(table)


if __name__ == "__main__":
    # Allow running with no subcommand: just download the defaults
    import sys
    if len(sys.argv) == 1 or (len(sys.argv) > 1 and sys.argv[1].startswith("-")):
        # No subcommand provided — run the download command directly
        sys.argv.insert(1, "download")
    app()
