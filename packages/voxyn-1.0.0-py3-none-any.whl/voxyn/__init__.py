"""
VOXYN.io — Natural language to robot hardware control.

Talk to your robot like it's a person. It listens. It moves.
100% local. 100% offline. Under 200ms.
"""

__version__ = "1.0.0"
__author__ = "VOXYN.io"
__license__ = "Apache-2.0"
__email__ = "dev@voxyn.io"
