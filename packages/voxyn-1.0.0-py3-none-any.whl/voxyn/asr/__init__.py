"""ASR (Automatic Speech Recognition) module — Whisper.cpp with Hailo acceleration."""
