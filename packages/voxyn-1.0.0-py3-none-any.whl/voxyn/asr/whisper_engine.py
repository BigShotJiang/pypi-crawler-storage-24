"""
Whisper ASR engine — speech to text via whisper.cpp.

Uses the whisper.cpp C library via ctypes for maximum performance.
On NeuralHAT hardware with Hailo-8L: ~80ms for 'base.en' model.
On Pi 5 CPU only: ~200ms for 'base.en'.

Models:
    base.en  — fastest, English only, ~80ms (recommended)
    small.en — more accurate, ~160ms
    medium   — multilingual, ~400ms
"""

from __future__ import annotations

import ctypes
import logging
import time
from pathlib import Path
from typing import Generator, Optional

import numpy as np

from voxyn.core.types import ASRResult

logger = logging.getLogger(__name__)

SAMPLE_RATE = 16000
CHUNK_DURATION = 0.5       # seconds per audio chunk read from mic
VAD_THRESHOLD = 0.01       # RMS threshold for voice activity detection
SILENCE_FRAMES_NEEDED = 20 # consecutive silent frames before we transcribe


class WhisperEngine:
    """
    Whisper ASR engine using whisper.cpp with optional Hailo-8L acceleration.

    Lifecycle:
        engine = WhisperEngine("models/whisper-base.en.bin")
        result = engine.transcribe_audio(audio_array)
        # OR
        for result in engine.stream_from_microphone():
            print(result.text)
    """

    def __init__(self, model_path: str = "models/whisper-base.en.bin") -> None:
        self.model_path = Path(model_path)
        if not self.model_path.exists():
            raise FileNotFoundError(
                f"Whisper model not found: {model_path}\n"
                f"Run: python -m voxyn.models.download --model whisper-base.en"
            )
        self._lib: Optional[ctypes.CDLL] = None
        self._ctx: Optional[ctypes.c_void_p] = None
        self._buffer = np.array([], dtype=np.float32)
        self._silence_frames = 0
        self._load_model()
        logger.info("Whisper engine loaded: %s", model_path)

    def _load_model(self) -> None:
        """Load whisper.cpp shared library and initialize model context."""
        try:
            lib = ctypes.CDLL("libwhisper.so")
        except OSError:
            raise RuntimeError(
                "libwhisper.so not found. Install whisper.cpp or run: "
                "bash scripts/setup_hailo.sh"
            )

        lib.whisper_init_from_file.restype = ctypes.c_void_p
        lib.whisper_init_from_file.argtypes = [ctypes.c_char_p]
        lib.whisper_full_default_params.restype = ctypes.c_void_p
        lib.whisper_full_n_segments.restype = ctypes.c_int
        lib.whisper_full_get_segment_text.restype = ctypes.c_char_p

        ctx = lib.whisper_init_from_file(str(self.model_path).encode())
        if not ctx:
            raise RuntimeError(f"Failed to initialize Whisper model: {self.model_path}")

        self._lib = lib
        self._ctx = ctypes.c_void_p(ctx)

    def transcribe_audio(self, audio: np.ndarray) -> ASRResult:
        """
        Transcribe float32 audio (16kHz, mono) to text.

        Args:
            audio: numpy float32 array at 16kHz mono

        Returns:
            ASRResult with text, confidence, and inference duration
        """
        if self._lib is None or self._ctx is None:
            raise RuntimeError("Whisper model not loaded")

        if len(audio) < SAMPLE_RATE * 0.1:
            return ASRResult(text="", confidence=0.0, duration_ms=0.0)

        audio = audio.astype(np.float32)
        max_val = np.max(np.abs(audio))
        if max_val > 0:
            audio = audio / (max_val + 1e-8)

        t0 = time.perf_counter()

        params = self._lib.whisper_full_default_params(0)  # 0 = GREEDY (fastest)
        # Set inference parameters for maximum speed
        ctypes.cast(params, ctypes.POINTER(ctypes.c_int))[7] = 4   # n_threads
        ctypes.cast(params, ctypes.POINTER(ctypes.c_int))[8] = -1  # beam_size=-1 (greedy)

        self._lib.whisper_full(
            self._ctx,
            params,
            audio.ctypes.data_as(ctypes.POINTER(ctypes.c_float)),
            len(audio),
        )

        n_segments = self._lib.whisper_full_n_segments(self._ctx)
        parts = []
        for i in range(n_segments):
            raw = self._lib.whisper_full_get_segment_text(self._ctx, i)
            if raw:
                parts.append(raw.decode("utf-8", errors="replace"))

        elapsed_ms = (time.perf_counter() - t0) * 1000
        text = " ".join(parts).strip()

        logger.debug("ASR: '%s' (%.1fms)", text[:80], elapsed_ms)

        return ASRResult(
            text=text,
            confidence=0.95,  # whisper.cpp doesn't expose a confidence score
            duration_ms=round(elapsed_ms, 2),
        )

    def stream_from_microphone(self) -> Generator[ASRResult, None, None]:
        """
        Generator: listens to the microphone and yields ASRResult when speech ends.

        Uses simple RMS Voice Activity Detection (VAD):
        - Accumulates audio while RMS > VAD_THRESHOLD
        - After SILENCE_FRAMES_NEEDED consecutive silent frames, transcribes

        Yields:
            ASRResult objects (only when text is non-empty)
        """
        try:
            import sounddevice as sd
        except ImportError:
            raise ImportError("sounddevice not installed. Run: pip install sounddevice")

        logger.info("Microphone stream started")
        blocksize = int(SAMPLE_RATE * CHUNK_DURATION)

        with sd.InputStream(
            samplerate=SAMPLE_RATE,
            channels=1,
            dtype="float32",
            blocksize=blocksize,
        ) as stream:
            while True:
                chunk, _ = stream.read(blocksize)
                chunk = chunk.flatten()

                rms = float(np.sqrt(np.mean(chunk**2)))

                if rms > VAD_THRESHOLD:
                    self._buffer = np.concatenate([self._buffer, chunk])
                    self._silence_frames = 0
                elif len(self._buffer) > 0:
                    self._silence_frames += 1
                    self._buffer = np.concatenate([self._buffer, chunk])

                    if self._silence_frames >= SILENCE_FRAMES_NEEDED:
                        result = self.transcribe_audio(self._buffer)
                        self._buffer = np.array([], dtype=np.float32)
                        self._silence_frames = 0
                        if result.text:
                            yield result

    def __del__(self) -> None:
        if self._lib and self._ctx:
            try:
                self._lib.whisper_free(self._ctx)
            except Exception:
                pass
