"""
CLI entry point for docomod.
"""

import sys


def main():
    from docomod.app import main
    main()


if __name__ == "__main__":
    main()