"""
docomod - Advanced Docx Comment Editor

A lightweight, open-source solution for precise management of Docx comment metadata.
"""

__version__ = "1.0.2"
__author__ = "EasyCam"
__license__ = "GPL-3.0"
__url__ = "https://github.com/easycam/docomod"

from docomod.app import docomodApp

__all__ = ["docomodApp", "__version__"]