"""
Livestream operations for the NomadicML SDK.

This module provides a high-level interface for managing livestream sessions,
including starting/ending sessions, retrieving session data, and monitoring
real-time analysis events from live video streams.

Typical workflow
----------------
1. Create a stream via the NomadicML web app (or reference an existing stream_id).
2. Call ``client.livestream.start_session(stream_id, source_url, name)`` to begin
   ingestion and analysis.
3. Poll for events using ``client.livestream.monitor_session(...)`` or call
   ``client.livestream.get_session(stream_id, session_id)`` on your own schedule.
4. When finished, call ``client.livestream.end_session(stream_id, session_id)``.
"""
from __future__ import annotations

import logging
import time
from enum import Enum
from typing import Any, Callable, Dict, Iterator, List, Optional

logger = logging.getLogger("nomadicml")


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class LiveSessionStatus(str, Enum):
    """Lifecycle states for a live session."""

    INITIALIZING = "INITIALIZING"
    ACTIVE = "ACTIVE"
    ENDING = "ENDING"
    FINISHED = "FINISHED"
    FAILED = "FAILED"


# ---------------------------------------------------------------------------
# LiveStreamClient
# ---------------------------------------------------------------------------


class LiveStreamClient:
    """High-level client for livestream operations.

    Obtain an instance via ``client.livestream`` rather than constructing
    this class directly.

    Args:
        client: An authenticated :class:`~nomadicml.client.NomadicML` instance.
    """

    def __init__(self, client: "NomadicML") -> None:  # noqa: F821
        self._client = client

    # ------------------------------------------------------------------
    # Stream attachment (Slack notification)
    # ------------------------------------------------------------------

    def attach_stream(
        self,
        stream_id: str,
        stream_name: str,
        source_url: str,
    ) -> Dict[str, Any]:
        """Notify the backend that a stream has been attached.

        This triggers a Slack alert on the NomadicML side and records the
        stream metadata.  Stream *documents* are managed via the NomadicML
        web app; this endpoint is a lightweight notification call.

        Args:
            stream_id: The unique identifier of the stream (created in the
                NomadicML web app).
            stream_name: A human-readable label for the stream.
            source_url: The live-stream source URL (HLS, DASH, RTMP, …).

        Returns:
            ``{"ok": True}`` on success.

        Raises:
            :class:`~nomadicml.exceptions.APIError`: On non-2xx responses.
        """
        response = self._client._make_request(
            "POST",
            "/api/live/attach-stream",
            data={
                "stream_id": stream_id,
                "stream_name": stream_name,
                "source_url": source_url,
            },
        )
        return response.json()

    # ------------------------------------------------------------------
    # Session lifecycle
    # ------------------------------------------------------------------

    def start_session(
        self,
        source_url: str,
        name: str,
        rapid_review_query: Optional[str] = None,
        stream_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Start a new live-stream analysis session.

        The backend will begin pulling the stream, splitting it into chunks,
        uploading them to cloud storage, and—if *rapid_review_query* is
        provided—running continuous rapid-review analysis on each chunk.

        Args:
            stream_id: The parent stream ID (must already exist in NomadicML).
            source_url: The live-stream URL (HLS ``.m3u8``, DASH, RTMP, YouTube
                live URLs, etc.).
            name: A friendly name for this session (shown in the web UI).
            rapid_review_query: Optional natural-language query for continuous
                event detection, e.g. ``"detect hard braking or lane departures"``.

        Returns:
            A dict containing at least::

                {
                    "session_id": "<hex string>"
                }

        Raises:
            :class:`~nomadicml.exceptions.APIError`: On non-2xx responses.

        Example::

            result = client.livestream.start_session(
                stream_id="abc123",
                source_url="https://example.com/live/stream.m3u8",
                name="Highway cam — Tuesday",
                rapid_review_query="detect pedestrians entering the road",
            )
            session_id = result["session_id"]
        """
        data: Dict[str, str] = {
            "source_url": source_url,
            "name": name,
        }
        if stream_id:
            data["stream_id"] = stream_id
        if rapid_review_query:
            data["rapid_review_query"] = rapid_review_query

        response = self._client._make_request(
            "POST",
            "/api/live/start-session",
            data=data,
        )
        return response.json()

    def end_session(
        self,
        stream_id: str,
        session_id: str,
    ) -> Dict[str, Any]:
        """End an active live-stream session.

        Stops the backend FFmpeg ingestion pipeline, finalises the HLS
        manifest, and marks the session as ``FINISHED``.

        Args:
            stream_id: The parent stream ID.
            session_id: The session to terminate.

        Returns:
            ``{"status": "ended"}`` or ``{"status": "already_ended"}``.

        Raises:
            :class:`~nomadicml.exceptions.APIError`: On non-2xx responses,
                including ``404`` if the session is not found and ``403`` if
                the caller is not authorised to end it.

        Example::

            client.livestream.end_session(stream_id="abc123", session_id="deadbeef")
        """
        response = self._client._make_request(
            "POST",
            "/api/live/end-session",
            data={
                "stream_id": stream_id,
                "session_id": session_id,
            },
        )
        return response.json()

    # ------------------------------------------------------------------
    # Session retrieval
    # ------------------------------------------------------------------

    def get_sessions(
        self,
        scope: Optional[str] = None,
    ) -> List[Dict[str, Any]]:
        """List live sessions visible to the authenticated user.

        Args:
            scope: Optionally filter results.  Accepted values:

                * ``None`` / ``"personal"`` – sessions created by the calling
                  user (default).
                * ``"org"`` – all sessions belonging to the caller's
                  organisation (requires org membership).

        Returns:
            A list of session dicts.  Each dict contains at least:

            .. code-block:: python

                {
                    "session_id": str,
                    "stream_id": str,
                    "name": str,
                    "source_url": str,
                    "status": str,         # LiveSessionStatus value
                    "created_by": str,
                    "created_at": ...,
                    "chunk_count": int,
                    "chunks": [...],
                    "events": [...],       # populated if rapid_review_query was set
                }

        Raises:
            :class:`~nomadicml.exceptions.APIError`: On non-2xx responses.
        """
        params: Dict[str, str] = {}
        if scope:
            params["scope"] = scope

        response = self._client._make_request(
            "GET",
            "/api/live/live-sessions",
            params=params or None,
        )
        return response.json().get("sessions", [])

    def get_session(
        self,
        stream_id: str,
        session_id: str,
    ) -> Dict[str, Any]:
        """Retrieve details for a single live session.

        Args:
            stream_id: The parent stream ID.
            session_id: The session identifier returned by :meth:`start_session`.

        Returns:
            A session dict (same schema as items from :meth:`get_sessions`).

        Raises:
            :class:`~nomadicml.exceptions.APIError`: ``404`` if not found.
        """
        response = self._client._make_request(
            "GET",
            f"/api/live/live-sessions/{stream_id}/{session_id}",
        )
        return response.json()

    # ------------------------------------------------------------------
    # Signed manifest
    # ------------------------------------------------------------------

    def get_signed_manifest(self, session_id: str) -> Dict[str, Any]:
        """Generate a short-lived signed URL for the session's HLS manifest.

        The returned URL can be passed directly to an HLS player (e.g. hls.js,
        Video.js) for secure playback of the recorded stream.

        Args:
            session_id: The session whose manifest should be signed.

        Returns:
            A dict with the following keys::

                {
                    "url": "<signed URL>",
                    "expires_at": "<ISO-8601 timestamp>",
                    "method": "GET",
                }

        Raises:
            :class:`~nomadicml.exceptions.APIError`: ``404`` if the session or
                manifest does not exist yet.
        """
        response = self._client._make_request(
            "POST",
            f"/api/live/session/{session_id}/signed-manifest",
        )
        return response.json()

    # ------------------------------------------------------------------
    # Convenience helpers
    # ------------------------------------------------------------------

    def monitor_session(
        self,
        stream_id: str,
        session_id: str,
        *,
        poll_interval: float = 5.0,
        timeout: Optional[float] = None,
        on_update: Optional[Callable[[Dict[str, Any]], None]] = None,
    ) -> Dict[str, Any]:
        """Poll a session until it reaches a terminal state.

        Blocks the calling thread, polling ``get_session`` every
        *poll_interval* seconds until the session status is ``FINISHED`` or
        ``FAILED`` (or *timeout* elapses).

        Args:
            stream_id: The parent stream ID.
            session_id: The session to watch.
            poll_interval: Seconds between each poll (default ``5``).
            timeout: Maximum seconds to wait before raising
                :class:`TimeoutError`.  ``None`` means wait indefinitely.
            on_update: Optional callback invoked with the latest session dict
                on every poll iteration (useful for streaming progress to a
                logger or UI).

        Returns:
            The final session dict once the session reaches a terminal state.

        Raises:
            TimeoutError: If *timeout* expires before the session ends.
            :class:`~nomadicml.exceptions.APIError`: On API errors during
                polling.

        Example::

            def log_progress(session):
                chunks = session.get("chunk_count", 0)
                events = len(session.get("events", []))
                print(f"  chunks={chunks}  events={events}  status={session['status']}")

            final = client.livestream.monitor_session(
                stream_id="abc123",
                session_id="deadbeef",
                poll_interval=10,
                timeout=3600,
                on_update=log_progress,
            )
            print("Session finished. Total chunks:", final.get("chunk_count"))
        """
        terminal_statuses = {
            LiveSessionStatus.FINISHED.value,
            LiveSessionStatus.FAILED.value,
        }
        start = time.monotonic()

        while True:
            session = self.get_session(stream_id, session_id)

            if on_update is not None:
                try:
                    on_update(session)
                except Exception:
                    pass  # never let a user callback abort the poll loop

            if session.get("status") in terminal_statuses:
                return session

            if timeout is not None and (time.monotonic() - start) >= timeout:
                raise TimeoutError(
                    f"Session {session_id} did not reach a terminal state "
                    f"within {timeout}s (current status: {session.get('status')})"
                )

            time.sleep(poll_interval)

    def iter_events(
        self,
        stream_id: str,
        session_id: str,
        *,
        poll_interval: float = 5.0,
        timeout: Optional[float] = None,
    ) -> Iterator[Dict[str, Any]]:
        """Yield new events as they appear on a live session.

        This is a generator that polls the session and yields any events not
        previously seen.  It stops once the session reaches a terminal state.

        Args:
            stream_id: The parent stream ID.
            session_id: The session to watch.
            poll_interval: Seconds between polls (default ``5``).
            timeout: Maximum seconds to run before stopping iteration.

        Yields:
            Individual event dicts as they are detected by the analysis pipeline.

        Example::

            for event in client.livestream.iter_events("abc123", "deadbeef", poll_interval=10):
                print(event["type"], event["description"])
        """
        terminal_statuses = {
            LiveSessionStatus.FINISHED.value,
            LiveSessionStatus.FAILED.value,
        }
        seen_ids: set = set()
        start = time.monotonic()

        while True:
            session = self.get_session(stream_id, session_id)
            events: List[Dict[str, Any]] = session.get("events") or []

            for event in events:
                # Build a stable identity key. Prefer the backend-assigned
                # event_id; fall back to a (chunk_index, chunk_relative_time,
                # description) composite; last resort is a frozenset of all
                # scalar values so events inserted at any position are caught.
                event_id = event.get("event_id") or event.get("id")
                if not event_id:
                    _key = (event.get("chunk_index"), event.get("chunk_relative_time"), event.get("description"))
                    if any(v is not None for v in _key):
                        event_id = _key
                    else:
                        event_id = frozenset(
                            (k, v) for k, v in event.items()
                            if isinstance(v, (str, int, float, bool, type(None)))
                        )
                if event_id not in seen_ids:
                    seen_ids.add(event_id)
                    yield event

            if session.get("status") in terminal_statuses:
                return

            if timeout is not None and (time.monotonic() - start) >= timeout:
                return

            time.sleep(poll_interval)
