"""Nova multi-agent orchestration engine.

Provides three composable primitives that match the Nova architecture:

    → route(intent)              — classify & dispatch to the best agent
    → parallel([agent₁, agent₂]) — fan-out to N agents concurrently
    → verify(output) ✓           — trust-layer verification gate

These can be used standalone or chained via ``pipeline()``.
"""

from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Awaitable, Literal

from novalab_adk.core.http import HttpClient
from novalab_adk.types.agents import AgentRunResult
from novalab_adk.types.trust import TrustEvaluation, TrustEvaluateResult


# ── Route types ─────────────────────────────────────────────────────

@dataclass
class RouteTarget:
    """A candidate agent for intent-based routing."""

    agent_id: str
    intents: list[str] = field(default_factory=list)
    weight: float | None = None


@dataclass
class RouteParams:
    """Parameters for route()."""

    input: str
    targets: list[RouteTarget]
    context: dict[str, Any] | None = None
    dry_run: bool = False


@dataclass
class RouteResult:
    """Result from route()."""

    selected_agent_id: str
    intent: str
    route_confidence: int
    scores: dict[str, int]
    result: AgentRunResult | None = None


# ── Parallel types ──────────────────────────────────────────────────

@dataclass
class ParallelTask:
    """A single task for parallel execution."""

    agent_id: str
    input: str
    context: dict[str, Any] | None = None
    label: str | None = None


ParallelMergeStrategy = Literal["all", "best", "first", "custom"]


@dataclass
class ParallelTaskResult:
    """Outcome of a single parallel task."""

    agent_id: str
    status: Literal["completed", "failed", "timeout", "skipped"]
    duration: float
    label: str | None = None
    result: AgentRunResult | None = None
    error: str | None = None


@dataclass
class ParallelParams:
    """Parameters for parallel()."""

    tasks: list[ParallelTask]
    merge: ParallelMergeStrategy = "all"
    merge_fn: Callable[[list[ParallelTaskResult]], ParallelTaskResult] | None = None
    timeout: float = 0
    confidence_floor: float = 0


@dataclass
class ParallelResult:
    """Combined result from parallel()."""

    tasks: list[ParallelTaskResult]
    merged: ParallelTaskResult | None
    duration: float
    success_count: int
    failure_count: int


# ── Verify types ────────────────────────────────────────────────────

@dataclass
class VerifyParams:
    """Parameters for verify()."""

    input: str
    output: str
    agent_id: str | None = None
    threshold: float = 70
    context: dict[str, Any] | None = None


@dataclass
class VerifyResult:
    """Result from verify()."""

    passed: bool
    trust: TrustEvaluation
    output: str
    summary: str


# ── Pipeline types ──────────────────────────────────────────────────

PipelineStepKind = Literal["route", "parallel", "verify", "custom"]


@dataclass
class PipelineContext:
    """Shared context flowing through pipeline steps."""

    input: str
    output: str | None = None
    confidence: float | None = None
    agents_involved: list[str] = field(default_factory=list)
    step_results: list[Any] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)


@dataclass
class PipelineStep:
    """A single step in a pipeline."""

    kind: PipelineStepKind
    params: RouteParams | ParallelParams | VerifyParams | None = None
    handler: Callable[[PipelineContext], Awaitable[PipelineContext]] | None = None


@dataclass
class PipelineParams:
    """Parameters for pipeline()."""

    input: str
    steps: list[PipelineStep]
    context: dict[str, Any] | None = None


@dataclass
class PipelineResult:
    """Final result from a pipeline execution."""

    output: str
    confidence: float
    verified: bool
    agents_involved: list[str]
    step_results: list[Any]
    duration: float


# ── Intent map ──────────────────────────────────────────────────────

_INTENT_MAP: dict[str, list[str]] = {
    "analytics": ["analyse", "analyze", "metrics", "data", "report", "dashboard", "chart"],
    "support": ["help", "support", "issue", "ticket", "problem", "bug", "fix"],
    "sales": ["customer", "crm", "lead", "deal", "pipeline", "revenue", "sales"],
    "risk": ["risk", "compliance", "audit", "security", "threat", "fraud"],
    "creative": ["write", "create", "draft", "design", "brainstorm", "generate"],
    "research": ["research", "find", "search", "look up", "investigate"],
}


# ── Orchestration resource ──────────────────────────────────────────

class OrchestrationResource:
    """Multi-agent orchestration engine.

    Usage::

        # route(intent)
        routed = await nova.orchestrate.route(RouteParams(
            input="Analyse customer churn",
            targets=[
                RouteTarget(agent_id="support-agent", intents=["support", "help"]),
                RouteTarget(agent_id="data-agent", intents=["analyse", "data"]),
            ],
        ))

        # parallel([agent₁, agent₂])
        results = await nova.orchestrate.parallel(ParallelParams(
            tasks=[
                ParallelTask(agent_id="support-agent", input="Summarise ticket"),
                ParallelTask(agent_id="crm-agent", input="Get customer profile"),
            ],
            merge="best",
            timeout=30,
        ))

        # verify(output) ✓
        verified = await nova.orchestrate.verify(VerifyParams(
            input="Summarise Q4 revenue",
            output=agent_result.output,
            threshold=80,
        ))
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    # ── route(intent) ───────────────────────────────────────────

    async def route(self, params: RouteParams) -> RouteResult:
        """Classify intent and route to the best-matching agent."""
        scores = self._score_targets(params.input, params.targets)
        sorted_scores = sorted(scores.items(), key=lambda x: x[1], reverse=True)
        selected_agent_id, top_score = sorted_scores[0]

        intent = self._classify_intent(params.input)
        route_confidence = round(top_score * 100)

        result: AgentRunResult | None = None
        if not params.dry_run:
            data = await self._http.post(
                f"/agents/{selected_agent_id}/run",
                json={"input": params.input, "context": params.context or {}, "stream": False},
            )
            result = AgentRunResult.model_validate(data)

        return RouteResult(
            selected_agent_id=selected_agent_id,
            intent=intent,
            route_confidence=route_confidence,
            scores={k: round(v * 100) for k, v in scores.items()},
            result=result,
        )

    # ── parallel([agent₁, agent₂]) ─────────────────────────────

    async def parallel(self, params: ParallelParams) -> ParallelResult:
        """Execute multiple agents concurrently and merge results."""
        wall_start = time.monotonic()

        # Fan-out all tasks
        coros = [self._run_task(task, params.timeout) for task in params.tasks]
        task_results = await asyncio.gather(*coros)

        # Apply confidence floor
        for tr in task_results:
            if (
                tr.status == "completed"
                and tr.result is not None
                and tr.result.confidence < params.confidence_floor
            ):
                tr.status = "skipped"

        completed = [t for t in task_results if t.status == "completed"]
        success_count = len(completed)
        failure_count = len(task_results) - success_count

        # Merge strategy
        merged: ParallelTaskResult | None = None

        if params.merge == "best":
            completed.sort(
                key=lambda t: t.result.confidence if t.result else 0, reverse=True
            )
            merged = completed[0] if completed else None

        elif params.merge == "first":
            merged = completed[0] if completed else None

        elif params.merge == "custom":
            if params.merge_fn and completed:
                merged = params.merge_fn(completed)

        else:  # "all"
            completed.sort(
                key=lambda t: t.result.confidence if t.result else 0, reverse=True
            )
            merged = completed[0] if completed else None

        return ParallelResult(
            tasks=list(task_results),
            merged=merged,
            duration=time.monotonic() - wall_start,
            success_count=success_count,
            failure_count=failure_count,
        )

    # ── verify(output) ✓ ────────────────────────────────────────

    async def verify(self, params: VerifyParams) -> VerifyResult:
        """Verify agent output through the Nova trust layer."""
        data = await self._http.post(
            "/trust",
            json={
                "input": params.input,
                "output": params.output,
                "model": params.agent_id or "unknown",
                "context": params.context or {},
            },
        )
        evaluation = TrustEvaluateResult.model_validate(data)
        trust = evaluation.trust

        passed = trust.overall_score >= params.threshold

        concerns = (
            f"Concerns: {', '.join(trust.concerns)}"
            if trust.concerns
            else "No concerns"
        )
        summary = (
            f"Passed ({trust.overall_score}/100). {concerns}"
            if passed
            else f"Failed ({trust.overall_score}/100, threshold: {params.threshold}). {concerns}"
        )

        return VerifyResult(
            passed=passed,
            trust=trust,
            output=params.output,
            summary=summary,
        )

    # ── pipeline(route → parallel → verify) ─────────────────────

    async def pipeline(self, params: PipelineParams) -> PipelineResult:
        """Execute a composable multi-step pipeline."""
        pipe_start = time.monotonic()

        ctx = PipelineContext(
            input=params.input,
            metadata=params.context or {},
        )

        for step in params.steps:
            if step.kind == "route" and isinstance(step.params, RouteParams):
                route_params = RouteParams(
                    input=ctx.input,
                    targets=step.params.targets,
                    context=step.params.context,
                    dry_run=step.params.dry_run,
                )
                route_result = await self.route(route_params)
                ctx.output = route_result.result.output if route_result.result else ctx.output
                ctx.confidence = route_result.route_confidence
                ctx.agents_involved.append(route_result.selected_agent_id)
                ctx.step_results.append(route_result)

            elif step.kind == "parallel" and isinstance(step.params, ParallelParams):
                # Inject current output as input for tasks with empty input
                tasks = [
                    ParallelTask(
                        agent_id=t.agent_id,
                        input=t.input or ctx.output or ctx.input,
                        context=t.context,
                        label=t.label,
                    )
                    for t in step.params.tasks
                ]
                parallel_params = ParallelParams(
                    tasks=tasks,
                    merge=step.params.merge,
                    merge_fn=step.params.merge_fn,
                    timeout=step.params.timeout,
                    confidence_floor=step.params.confidence_floor,
                )
                parallel_result = await self.parallel(parallel_params)
                for t in parallel_result.tasks:
                    if t.agent_id not in ctx.agents_involved:
                        ctx.agents_involved.append(t.agent_id)
                if parallel_result.merged and parallel_result.merged.result:
                    ctx.output = parallel_result.merged.result.output
                    ctx.confidence = parallel_result.merged.result.confidence
                ctx.step_results.append(parallel_result)

            elif step.kind == "verify" and isinstance(step.params, VerifyParams):
                verify_params = VerifyParams(
                    input=ctx.input,
                    output=ctx.output or "",
                    agent_id=step.params.agent_id,
                    threshold=step.params.threshold,
                    context=step.params.context,
                )
                verify_result = await self.verify(verify_params)
                ctx.confidence = verify_result.trust.overall_score
                ctx.step_results.append(verify_result)

            elif step.kind == "custom" and step.handler:
                ctx = await step.handler(ctx)

        last_verify = next(
            (r for r in ctx.step_results if isinstance(r, VerifyResult)),
            None,
        )

        return PipelineResult(
            output=ctx.output or "",
            confidence=ctx.confidence or 0,
            verified=last_verify.passed if last_verify else False,
            agents_involved=ctx.agents_involved,
            step_results=ctx.step_results,
            duration=time.monotonic() - pipe_start,
        )

    # ── Private helpers ─────────────────────────────────────────

    async def _run_task(
        self, task: ParallelTask, timeout: float
    ) -> ParallelTaskResult:
        """Run a single agent task with optional timeout."""
        start = time.monotonic()

        try:
            coro = self._http.post(
                f"/agents/{task.agent_id}/run",
                json={
                    "input": task.input,
                    "context": task.context or {},
                    "stream": False,
                },
            )

            if timeout > 0:
                data = await asyncio.wait_for(coro, timeout=timeout)
            else:
                data = await coro

            result = AgentRunResult.model_validate(data)
            return ParallelTaskResult(
                agent_id=task.agent_id,
                label=task.label,
                result=result,
                status="completed",
                duration=time.monotonic() - start,
            )

        except asyncio.TimeoutError:
            return ParallelTaskResult(
                agent_id=task.agent_id,
                label=task.label,
                error="timeout",
                status="timeout",
                duration=time.monotonic() - start,
            )
        except Exception as exc:
            return ParallelTaskResult(
                agent_id=task.agent_id,
                label=task.label,
                error=str(exc),
                status="failed",
                duration=time.monotonic() - start,
            )

    def _score_targets(
        self, input_text: str, targets: list[RouteTarget]
    ) -> dict[str, float]:
        """Score targets against input using keyword matching."""
        lower = input_text.lower()
        words = lower.split()
        scores: dict[str, float] = {}

        for target in targets:
            score = target.weight if target.weight is not None else 0.5

            if target.intents:
                matches = [
                    intent
                    for intent in target.intents
                    if intent.lower() in lower
                    or intent.lower() in words
                ]
                score = len(matches) / len(target.intents)
                if target.weight is not None:
                    score = score * 0.8 + target.weight * 0.2

            scores[target.agent_id] = max(0.0, min(1.0, score))

        return scores

    def _classify_intent(self, input_text: str) -> str:
        """Extract a simple intent label from input."""
        lower = input_text.lower()
        best_intent = "general"
        best_score = 0

        for intent, keywords in _INTENT_MAP.items():
            matches = [kw for kw in keywords if kw in lower]
            if len(matches) > best_score:
                best_score = len(matches)
                best_intent = intent

        return best_intent


__all__ = [
    "OrchestrationResource",
    "RouteTarget",
    "RouteParams",
    "RouteResult",
    "ParallelTask",
    "ParallelMergeStrategy",
    "ParallelParams",
    "ParallelTaskResult",
    "ParallelResult",
    "VerifyParams",
    "VerifyResult",
    "PipelineStep",
    "PipelineStepKind",
    "PipelineContext",
    "PipelineParams",
    "PipelineResult",
]
