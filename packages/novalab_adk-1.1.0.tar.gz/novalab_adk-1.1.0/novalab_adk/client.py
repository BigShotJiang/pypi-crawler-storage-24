from __future__ import annotations

from novalab_adk.core.http import HttpClient
from novalab_adk.orchestration import OrchestrationResource
from novalab_adk.resources.agents import AgentsResource
from novalab_adk.resources.automations import AutomationsResource
from novalab_adk.resources.connections import ConnectionsResource
from novalab_adk.resources.data import DataResource
from novalab_adk.resources.history import HistoryResource
from novalab_adk.resources.signals import SignalsResource
from novalab_adk.resources.trust import TrustResource
from novalab_adk.resources.webhooks import WebhooksResource
from novalab_adk.resources.workflows import WorkflowsResource

DEFAULT_REGION = "eu-west-1"
DEFAULT_TIMEOUT = 30.0


class NovaClient:
    """Main entry point for the NovaLab Agent Development Kit.

    Usage::

        from novalab_adk import NovaClient

        nova = NovaClient(api_key="nv-...", region="eu-west-1")
        agent = await nova.agents.create(name="Risk Analyser", model="gemini-pro")
        await nova.agents.deploy(agent.id)
        result = await nova.agents.run(agent.id, AgentRunParams(input="Analyse portfolio"))
        await nova.aclose()

    Or as an async context manager::

        async with NovaClient(api_key="nv-...") as nova:
            agents = await nova.agents.list()
    """

    def __init__(
        self,
        api_key: str,
        region: str = DEFAULT_REGION,
        base_url: str | None = None,
        timeout: float = DEFAULT_TIMEOUT,
    ) -> None:
        self._http = HttpClient(
            base_url=base_url,
            api_key=api_key,
            region=region,
            timeout=timeout,
        )

        self.agents = AgentsResource(self._http)
        self.workflows = WorkflowsResource(self._http)
        self.signals = SignalsResource(self._http)
        self.automations = AutomationsResource(self._http)
        self.connections = ConnectionsResource(self._http)
        self.data = DataResource(self._http)
        self.history = HistoryResource(self._http)
        self.trust = TrustResource(self._http)
        self.webhooks = WebhooksResource(self._http)

        #: Multi-agent orchestration engine.
        #:
        #:   → route(intent)              — classify & dispatch to the best agent
        #:   → parallel([agent₁, agent₂]) — fan-out to N agents concurrently
        #:   → verify(output) ✓           — trust-layer verification gate
        #:   → pipeline(steps)            — compose route → parallel → verify
        self.orchestrate = OrchestrationResource(self._http)

    async def aclose(self) -> None:
        """Close the underlying HTTP client and release resources."""
        await self._http.close()

    async def __aenter__(self) -> NovaClient:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.aclose()
