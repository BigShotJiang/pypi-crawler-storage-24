from __future__ import annotations

from novalab_adk.core.http import HttpClient
from novalab_adk.types.agents import AgentRunResult
from novalab_adk.types.history import (
    DecisionExplanation,
    HistoryEntry,
    HistoryQueryParams,
)


class HistoryResource:
    """Resource for querying the decision-history audit log."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(
        self, params: HistoryQueryParams | None = None
    ) -> list[HistoryEntry]:
        """List history entries."""
        query = params.model_dump(mode="json", exclude_none=True) if params else None
        data = await self._http.get("/history", params=query)
        return [HistoryEntry.model_validate(item) for item in data]

    async def get(self, entry_id: str) -> HistoryEntry:
        """Get a single history entry by ID."""
        data = await self._http.get(f"/history/{entry_id}")
        return HistoryEntry.model_validate(data)

    async def explain(self, entry_id: str) -> DecisionExplanation:
        """Get a detailed explanation for a decision."""
        data = await self._http.get(f"/history/{entry_id}/explain")
        return DecisionExplanation.model_validate(data)

    async def replay(self, entry_id: str) -> AgentRunResult:
        """Replay a historical decision and return the new result."""
        data = await self._http.post(f"/history/{entry_id}/replay")
        return AgentRunResult.model_validate(data)
