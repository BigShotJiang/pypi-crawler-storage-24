from __future__ import annotations

from novalab_adk.core.http import HttpClient
from novalab_adk.types.trust import (
    TrustEvaluateParams,
    TrustEvaluateResult,
)


class TrustResource:
    """Resource for evaluating trust on AI outputs.

    The Nova Trust Layer analyses any AI model's output for accuracy,
    safety, relevance, and completeness, producing a trust score that
    determines whether to auto-execute, notify, require approval, or block.
    """

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def evaluate(self, params: TrustEvaluateParams) -> TrustEvaluateResult:
        """Evaluate trust on an AI output.

        Sends the original input and AI-generated output to Nova-Trust,
        which uses a second AI evaluation to score the response.
        """
        data = await self._http.post(
            "/trust",
            json=params.model_dump(mode="json", exclude_none=True),
        )
        return TrustEvaluateResult.model_validate(data)
