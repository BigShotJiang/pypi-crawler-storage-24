from __future__ import annotations

import mimetypes
from pathlib import Path
from typing import Any

from novalab_adk.core.http import HttpClient
from novalab_adk.types.data import (
    Dataset,
    DataQueryParams,
    DataQueryResult,
    DataUploadParams,
)

FORMAT_CONTENT_TYPES: dict[str, str] = {
    "csv": "text/csv",
    "json": "application/json",
    "parquet": "application/octet-stream",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}


class _DatasetsSubResource:
    """Sub-resource for managing datasets."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(self, params: dict[str, Any] | None = None) -> list[Dataset]:
        """List all datasets."""
        data = await self._http.get("/data/datasets", params=params)
        return [Dataset.model_validate(item) for item in data]

    async def get(self, dataset_id: str) -> Dataset:
        """Get a dataset by ID."""
        data = await self._http.get(f"/data/datasets/{dataset_id}")
        return Dataset.model_validate(data)

    async def delete(self, dataset_id: str) -> None:
        """Delete a dataset."""
        await self._http.delete(f"/data/datasets/{dataset_id}")


class DataResource:
    """Resource for uploading, querying, and managing data."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http
        self.datasets = _DatasetsSubResource(http)

    async def upload(self, params: DataUploadParams) -> Dataset:
        """Upload a file or raw bytes as a new dataset."""
        file_bytes = params.file_bytes
        file_name = params.name

        if params.file_path is not None:
            path = Path(params.file_path)
            file_bytes = path.read_bytes()
            file_name = path.name

        if file_bytes is None:
            raise ValueError("Either file_path or file_bytes must be provided")

        content_type = FORMAT_CONTENT_TYPES.get(
            params.format,
            mimetypes.guess_type(file_name)[0] or "application/octet-stream",
        )

        data = await self._http.post_file(
            "/data/upload",
            file_name=file_name,
            file_bytes=file_bytes,
            content_type=content_type,
            data={"name": params.name, "format": params.format},
        )
        return Dataset.model_validate(data)

    async def query(self, params: DataQueryParams) -> DataQueryResult:
        """Run a natural-language query against a dataset."""
        data = await self._http.post(
            "/data/query", json=params.model_dump(mode="json", exclude_none=True)
        )
        return DataQueryResult.model_validate(data)
