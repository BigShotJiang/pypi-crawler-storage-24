from __future__ import annotations

from typing import Any

from novalab_adk.core.http import HttpClient
from novalab_adk.types.automations import (
    Automation,
    AutomationCreateParams,
    AutomationExecution,
)


class _ExecutionsSubResource:
    """Sub-resource for querying automation execution history."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(
        self,
        automation_id: str,
        params: dict[str, Any] | None = None,
    ) -> list[AutomationExecution]:
        """List executions for an automation."""
        data = await self._http.get(
            f"/automations/{automation_id}/executions", params=params
        )
        return [AutomationExecution.model_validate(item) for item in data]

    async def get(self, execution_id: str) -> AutomationExecution:
        """Get an execution by ID."""
        data = await self._http.get(f"/automations/executions/{execution_id}")
        return AutomationExecution.model_validate(data)


class AutomationsResource:
    """Resource for managing automations."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http
        self.executions = _ExecutionsSubResource(http)

    async def list(self, params: dict[str, Any] | None = None) -> list[Automation]:
        """List all automations."""
        data = await self._http.get("/automations", params=params)
        return [Automation.model_validate(item) for item in data]

    async def get(self, automation_id: str) -> Automation:
        """Get an automation by ID."""
        data = await self._http.get(f"/automations/{automation_id}")
        return Automation.model_validate(data)

    async def create(self, params: AutomationCreateParams) -> Automation:
        """Create a new automation."""
        data = await self._http.post(
            "/automations", json=params.model_dump(mode="json", exclude_none=True)
        )
        return Automation.model_validate(data)

    async def update(
        self, automation_id: str, params: dict[str, Any]
    ) -> Automation:
        """Update an existing automation."""
        data = await self._http.patch(
            f"/automations/{automation_id}", json=params
        )
        return Automation.model_validate(data)

    async def delete(self, automation_id: str) -> None:
        """Delete an automation."""
        await self._http.delete(f"/automations/{automation_id}")

    async def activate(self, automation_id: str) -> Automation:
        """Activate a paused automation."""
        data = await self._http.post(f"/automations/{automation_id}/activate")
        return Automation.model_validate(data)

    async def pause(self, automation_id: str) -> Automation:
        """Pause an active automation."""
        data = await self._http.post(f"/automations/{automation_id}/pause")
        return Automation.model_validate(data)

    async def trigger(self, automation_id: str) -> AutomationExecution:
        """Manually trigger an automation."""
        data = await self._http.post(f"/automations/{automation_id}/trigger")
        return AutomationExecution.model_validate(data)
