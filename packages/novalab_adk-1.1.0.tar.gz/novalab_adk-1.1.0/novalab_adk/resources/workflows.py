from __future__ import annotations

from typing import Any

from novalab_adk.core.http import HttpClient
from novalab_adk.types.workflows import (
    Workflow,
    WorkflowCreateParams,
    WorkflowRunParams,
    WorkflowRunResult,
    WorkflowStep,
)


class WorkflowsResource:
    """Resource for managing multi-agent workflows."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(self, params: dict[str, Any] | None = None) -> list[Workflow]:
        """List all workflows."""
        data = await self._http.get("/workflows", params=params)
        return [Workflow.model_validate(item) for item in data]

    async def get(self, workflow_id: str) -> Workflow:
        """Get a workflow by ID."""
        data = await self._http.get(f"/workflows/{workflow_id}")
        return Workflow.model_validate(data)

    async def create(self, params: WorkflowCreateParams) -> Workflow:
        """Create a new workflow."""
        data = await self._http.post(
            "/workflows", json=params.model_dump(mode="json", exclude_none=True)
        )
        return Workflow.model_validate(data)

    async def update(
        self, workflow_id: str, params: dict[str, Any]
    ) -> Workflow:
        """Update an existing workflow."""
        data = await self._http.patch(f"/workflows/{workflow_id}", json=params)
        return Workflow.model_validate(data)

    async def delete(self, workflow_id: str) -> None:
        """Delete a workflow."""
        await self._http.delete(f"/workflows/{workflow_id}")

    async def run(
        self, workflow_id: str, params: WorkflowRunParams
    ) -> WorkflowRunResult:
        """Execute a workflow."""
        data = await self._http.post(
            f"/workflows/{workflow_id}/run",
            json=params.model_dump(mode="json", exclude_none=True),
        )
        return WorkflowRunResult.model_validate(data)

    async def pause(self, workflow_id: str) -> Workflow:
        """Pause a running workflow."""
        data = await self._http.post(f"/workflows/{workflow_id}/pause")
        return Workflow.model_validate(data)

    async def resume(self, workflow_id: str) -> Workflow:
        """Resume a paused workflow."""
        data = await self._http.post(f"/workflows/{workflow_id}/resume")
        return Workflow.model_validate(data)

    async def add_step(self, workflow_id: str, step: WorkflowStep) -> Workflow:
        """Add a step to a workflow."""
        data = await self._http.post(
            f"/workflows/{workflow_id}/steps",
            json=step.model_dump(mode="json", exclude_none=True),
        )
        return Workflow.model_validate(data)

    async def remove_step(self, workflow_id: str, step_id: str) -> Workflow:
        """Remove a step from a workflow."""
        data = await self._http.delete(
            f"/workflows/{workflow_id}/steps/{step_id}"
        )
        return Workflow.model_validate(data)
