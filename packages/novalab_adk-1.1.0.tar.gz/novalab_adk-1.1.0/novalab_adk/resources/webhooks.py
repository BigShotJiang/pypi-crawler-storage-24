from __future__ import annotations

from typing import Any

from novalab_adk.core.http import HttpClient
from novalab_adk.types.webhooks import Webhook, WebhookCreateParams
from novalab_adk.utils.hmac import verify_webhook_signature


class WebhooksResource:
    """Resource for managing webhook subscriptions."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(self, params: dict[str, Any] | None = None) -> list[Webhook]:
        """List all webhooks."""
        data = await self._http.get("/webhooks", params=params)
        return [Webhook.model_validate(item) for item in data]

    async def get(self, webhook_id: str) -> Webhook:
        """Get a webhook by ID."""
        data = await self._http.get(f"/webhooks/{webhook_id}")
        return Webhook.model_validate(data)

    async def create(self, params: WebhookCreateParams) -> Webhook:
        """Create a new webhook subscription."""
        data = await self._http.post(
            "/webhooks", json=params.model_dump(mode="json", exclude_none=True)
        )
        return Webhook.model_validate(data)

    async def update(
        self, webhook_id: str, params: dict[str, Any]
    ) -> Webhook:
        """Update an existing webhook."""
        data = await self._http.patch(f"/webhooks/{webhook_id}", json=params)
        return Webhook.model_validate(data)

    async def delete(self, webhook_id: str) -> None:
        """Delete a webhook."""
        await self._http.delete(f"/webhooks/{webhook_id}")

    async def test(self, webhook_id: str) -> dict[str, Any]:
        """Send a test event to a webhook endpoint."""
        data = await self._http.post(f"/webhooks/{webhook_id}/test")
        return data

    @staticmethod
    def verify(payload: str, signature: str, secret: str) -> bool:
        """Verify that a webhook payload signature is authentic."""
        return verify_webhook_signature(payload, signature, secret)
