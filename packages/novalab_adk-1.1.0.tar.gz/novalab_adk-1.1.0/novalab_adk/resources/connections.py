from __future__ import annotations

from typing import Any

from novalab_adk.core.http import HttpClient
from novalab_adk.types.connections import (
    Connection,
    ConnectionCreateParams,
    ConnectionPermission,
)


class ConnectionsResource:
    """Resource for managing external service connections."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(self, params: dict[str, Any] | None = None) -> list[Connection]:
        """List all connections."""
        data = await self._http.get("/connections", params=params)
        return [Connection.model_validate(item) for item in data]

    async def get(self, connection_id: str) -> Connection:
        """Get a connection by ID."""
        data = await self._http.get(f"/connections/{connection_id}")
        return Connection.model_validate(data)

    async def create(self, params: ConnectionCreateParams) -> Connection:
        """Create a new connection."""
        data = await self._http.post(
            "/connections", json=params.model_dump(mode="json", exclude_none=True)
        )
        return Connection.model_validate(data)

    async def update(
        self, connection_id: str, params: dict[str, Any]
    ) -> Connection:
        """Update an existing connection."""
        data = await self._http.patch(
            f"/connections/{connection_id}", json=params
        )
        return Connection.model_validate(data)

    async def delete(self, connection_id: str) -> None:
        """Delete a connection."""
        await self._http.delete(f"/connections/{connection_id}")

    async def test(self, connection_id: str) -> dict[str, Any]:
        """Test a connection."""
        data = await self._http.post(f"/connections/{connection_id}/test")
        return data

    async def permissions(self, connection_id: str) -> list[ConnectionPermission]:
        """Get permissions for a connection."""
        data = await self._http.get(f"/connections/{connection_id}/permissions")
        return [ConnectionPermission.model_validate(item) for item in data]

    async def history(
        self, connection_id: str, params: dict[str, Any] | None = None
    ) -> list[dict[str, Any]]:
        """Get usage history for a connection."""
        data = await self._http.get(
            f"/connections/{connection_id}/history", params=params
        )
        return data
