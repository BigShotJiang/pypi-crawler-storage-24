from __future__ import annotations

from typing import Any

from novalab_adk.core.http import HttpClient
from novalab_adk.types.agents import (
    Agent,
    AgentCreateParams,
    AgentDeployParams,
    AgentRunParams,
    AgentRunResult,
    AgentUpdateParams,
)
from novalab_adk.utils.streaming import NovaStream


class AgentsResource:
    """Resource for managing Nova agents."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(self, params: dict[str, Any] | None = None) -> list[Agent]:
        """List all agents."""
        data = await self._http.get("/agents", params=params)
        return [Agent.model_validate(item) for item in data]

    async def get(self, agent_id: str) -> Agent:
        """Get an agent by ID."""
        data = await self._http.get(f"/agents/{agent_id}")
        return Agent.model_validate(data)

    async def create(self, params: AgentCreateParams) -> Agent:
        """Create a new agent."""
        data = await self._http.post(
            "/agents", json=params.model_dump(mode="json", exclude_none=True)
        )
        return Agent.model_validate(data)

    async def update(self, agent_id: str, params: AgentUpdateParams) -> Agent:
        """Update an existing agent."""
        data = await self._http.patch(
            f"/agents/{agent_id}",
            json=params.model_dump(mode="json", exclude_none=True),
        )
        return Agent.model_validate(data)

    async def delete(self, agent_id: str) -> None:
        """Delete an agent."""
        await self._http.delete(f"/agents/{agent_id}")

    async def deploy(
        self, agent_id: str, params: AgentDeployParams | None = None
    ) -> Agent:
        """Deploy an agent to an environment."""
        body = params.model_dump(mode="json", exclude_none=True) if params else {}
        data = await self._http.post(f"/agents/{agent_id}/deploy", json=body)
        return Agent.model_validate(data)

    async def run(self, agent_id: str, params: AgentRunParams) -> AgentRunResult:
        """Run an agent synchronously."""
        data = await self._http.post(
            f"/agents/{agent_id}/run",
            json=params.model_dump(mode="json", exclude_none=True),
        )
        return AgentRunResult.model_validate(data)

    def stream(self, agent_id: str, params: AgentRunParams) -> _AgentStreamBuilder:
        """Start a streaming agent run, returning a builder that yields a NovaStream."""
        return _AgentStreamBuilder(self._http, agent_id, params)

    async def pause(self, agent_id: str) -> Agent:
        """Pause a running agent."""
        data = await self._http.post(f"/agents/{agent_id}/pause")
        return Agent.model_validate(data)

    async def resume(self, agent_id: str) -> Agent:
        """Resume a paused agent."""
        data = await self._http.post(f"/agents/{agent_id}/resume")
        return Agent.model_validate(data)


class _AgentStreamBuilder:
    """Builder that lazily opens a streaming connection when awaited or iterated."""

    def __init__(
        self, http: HttpClient, agent_id: str, params: AgentRunParams
    ) -> None:
        self._http = http
        self._agent_id = agent_id
        self._params = params

    async def open(self) -> NovaStream[AgentRunResult]:
        """Open the SSE stream."""
        body = self._params.model_dump(mode="json", exclude_none=True)
        body["stream"] = True
        response = await self._http.stream_sse(
            f"/agents/{self._agent_id}/run", json=body
        )
        return NovaStream(response, AgentRunResult)

    async def __aenter__(self) -> NovaStream[AgentRunResult]:
        self._stream = await self.open()
        return self._stream

    async def __aexit__(self, *exc: object) -> None:
        if hasattr(self, "_stream"):
            await self._stream.close()
