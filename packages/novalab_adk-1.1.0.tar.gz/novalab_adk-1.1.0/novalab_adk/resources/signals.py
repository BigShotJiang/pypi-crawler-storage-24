from __future__ import annotations

from typing import Any

from novalab_adk.core.http import HttpClient
from novalab_adk.types.signals import (
    Signal,
    SignalAnomaly,
    SignalIngestParams,
    SignalStreamOptions,
    SignalSystem,
)
from novalab_adk.utils.streaming import NovaStream


class _SystemsSubResource:
    """Sub-resource for managing signal systems."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(self, params: dict[str, Any] | None = None) -> list[SignalSystem]:
        """List all signal systems."""
        data = await self._http.get("/signals/systems", params=params)
        return [SignalSystem.model_validate(item) for item in data]

    async def get(self, system_id: str) -> SignalSystem:
        """Get a signal system by ID."""
        data = await self._http.get(f"/signals/systems/{system_id}")
        return SignalSystem.model_validate(data)

    async def create(self, params: dict[str, Any]) -> SignalSystem:
        """Create a new signal system."""
        data = await self._http.post("/signals/systems", json=params)
        return SignalSystem.model_validate(data)

    async def delete(self, system_id: str) -> None:
        """Delete a signal system."""
        await self._http.delete(f"/signals/systems/{system_id}")


class _AnomaliesSubResource:
    """Sub-resource for querying signal anomalies."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list(
        self, system_id: str, params: dict[str, Any] | None = None
    ) -> list[SignalAnomaly]:
        """List anomalies for a system."""
        data = await self._http.get(
            f"/signals/systems/{system_id}/anomalies", params=params
        )
        return [SignalAnomaly.model_validate(item) for item in data]

    async def get(self, anomaly_id: str) -> SignalAnomaly:
        """Get an anomaly by ID."""
        data = await self._http.get(f"/signals/anomalies/{anomaly_id}")
        return SignalAnomaly.model_validate(data)


class SignalsResource:
    """Resource for managing real-time signals and connected systems."""

    def __init__(self, http: HttpClient) -> None:
        self._http = http
        self.systems = _SystemsSubResource(http)
        self.anomalies = _AnomaliesSubResource(http)

    async def ingest(self, params: SignalIngestParams) -> None:
        """Ingest signal data points."""
        await self._http.post(
            "/signals/ingest", json=params.model_dump(mode="json", exclude_none=True)
        )

    def stream(self, options: SignalStreamOptions) -> _SignalStreamBuilder:
        """Open a live signal stream."""
        return _SignalStreamBuilder(self._http, options)

    async def history(
        self, system_id: str, params: dict[str, Any] | None = None
    ) -> list[Signal]:
        """Get historical signal readings for a system."""
        data = await self._http.get(
            f"/signals/systems/{system_id}/history", params=params
        )
        return [Signal.model_validate(item) for item in data]


class _SignalStreamBuilder:
    """Builder that lazily opens a streaming connection for signals."""

    def __init__(self, http: HttpClient, options: SignalStreamOptions) -> None:
        self._http = http
        self._options = options

    async def open(self) -> NovaStream[Signal]:
        """Open the SSE stream."""
        response = await self._http.stream_sse(
            "/signals/stream",
            json=self._options.model_dump(mode="json", exclude_none=True),
        )
        return NovaStream(response, Signal)

    async def __aenter__(self) -> NovaStream[Signal]:
        self._stream = await self.open()
        return self._stream

    async def __aexit__(self, *exc: object) -> None:
        if hasattr(self, "_stream"):
            await self._stream.close()
