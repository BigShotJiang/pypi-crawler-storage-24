from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


class AutomationStep(BaseModel):
    """A single step within an automation execution."""

    name: str
    status: Literal["pending", "running", "completed", "failed", "skipped"] = "pending"
    duration: float | None = None
    output: Any = None


class AutomationExecution(BaseModel):
    """A record of a single automation execution."""

    id: str
    automation_id: str
    steps: list[AutomationStep] = Field(default_factory=list)
    status: Literal["running", "completed", "failed"] = "running"
    started_at: datetime | None = None
    completed_at: datetime | None = None


class Automation(BaseModel):
    """An automation rule that triggers agent actions based on conditions."""

    id: str
    name: str
    description: str = ""
    status: Literal["active", "paused", "error"] = "paused"
    confidence_threshold: float = 70.0
    trigger: dict[str, Any] = Field(default_factory=dict)
    actions: list[dict[str, Any]] = Field(default_factory=list)
    last_run: datetime | None = None
    next_run: datetime | None = None
    success_rate: float = 0.0


class AutomationCreateParams(BaseModel):
    """Parameters for creating a new automation."""

    name: str
    description: str = ""
    confidence_threshold: float = 70.0
    trigger: dict[str, Any] = Field(default_factory=dict)
    actions: list[dict[str, Any]] = Field(default_factory=list)
