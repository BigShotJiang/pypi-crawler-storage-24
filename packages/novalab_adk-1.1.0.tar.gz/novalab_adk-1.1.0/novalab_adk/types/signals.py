from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field


class Signal(BaseModel):
    """A single signal reading from a connected system."""

    id: str
    system_id: str
    system_type: str = ""
    name: str
    value: float | str | bool
    unit: str = ""
    timestamp: datetime | None = None
    health: Literal["healthy", "warning", "critical", "unknown"] = "unknown"
    trend: Literal["rising", "falling", "stable", "unknown"] = "unknown"


class SignalSystem(BaseModel):
    """A connected system that emits signals."""

    id: str
    name: str
    type: Literal["iot", "vehicle", "robot", "machine", "infrastructure"]
    status: Literal["online", "offline", "degraded", "error"] = "offline"
    signals: list[Signal] = Field(default_factory=list)


class SignalAnomaly(BaseModel):
    """An anomaly detected on a signal."""

    id: str
    signal_id: str
    severity: Literal["low", "medium", "high", "critical"]
    description: str = ""
    detected_at: datetime | None = None
    confidence: float = 0.0


class SignalStreamOptions(BaseModel):
    """Options for subscribing to a live signal stream."""

    system_ids: list[str] = Field(default_factory=list)
    signal_names: list[str] = Field(default_factory=list)
    interval: float = 1.0


class SignalDataPoint(BaseModel):
    """A single data point for signal ingestion."""

    name: str
    value: float | str | bool
    unit: str = ""
    timestamp: datetime | None = None


class SignalIngestParams(BaseModel):
    """Parameters for ingesting signal data into the platform."""

    system_id: str
    signals: list[SignalDataPoint] = Field(default_factory=list)
