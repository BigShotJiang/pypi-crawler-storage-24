from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

TrustLevel = Literal["high", "medium", "low", "very_low"]


class TrustEvaluation(BaseModel):
    """Result of a trust evaluation on AI output."""

    overall_score: float = 0.0
    trust_level: TrustLevel = "medium"
    accuracy_score: float = 0.0
    safety_score: float = 0.0
    relevance_score: float = 0.0
    completeness_score: float = 0.0
    concerns: list[str] = Field(default_factory=list)
    reasoning: str = ""
    evaluator_model: str = ""
    evaluation_tokens: int = 0
    evaluation_duration_ms: float | None = None


class TrustEvaluateParams(BaseModel):
    """Parameters for standalone trust evaluation."""

    input: str
    output: str
    model: str = "unknown"
    context: dict[str, Any] = Field(default_factory=dict)


class TrustEvaluateResult(BaseModel):
    """Result from standalone trust evaluation endpoint."""

    audit_id: str
    trust: TrustEvaluation
    duration: float | None = None
