from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


class ConnectionPermission(BaseModel):
    """A permission grant for a connection."""

    scope: str
    risk_level: Literal["low", "medium", "high", "critical"] = "low"
    granted: bool = False


class Connection(BaseModel):
    """A connection to an external service or system."""

    id: str
    name: str
    category: str = ""
    provider: str = ""
    status: Literal["connected", "disconnected", "error", "pending"] = "disconnected"
    permissions: list[ConnectionPermission] = Field(default_factory=list)
    capabilities: list[str] = Field(default_factory=list)
    can_do: list[str] = Field(default_factory=list)
    cannot_do: list[str] = Field(default_factory=list)
    created_at: datetime | None = None
    updated_at: datetime | None = None


class ConnectionCreateParams(BaseModel):
    """Parameters for creating a new connection."""

    name: str
    category: str = ""
    provider: str = ""
    config: dict[str, Any] = Field(default_factory=dict)
    permissions: list[ConnectionPermission] = Field(default_factory=list)
