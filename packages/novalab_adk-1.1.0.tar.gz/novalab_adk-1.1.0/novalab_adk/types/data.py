from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


class Dataset(BaseModel):
    """A dataset stored in the NovaLab platform."""

    id: str
    name: str
    format: str = "csv"
    schema_: dict[str, Any] = Field(default_factory=dict, alias="schema")
    row_count: int = 0
    columns: list[str] = Field(default_factory=list)
    created_at: datetime | None = None

    model_config = {"populate_by_name": True}


class DataUploadParams(BaseModel):
    """Parameters for uploading data."""

    name: str
    file_path: str | None = None
    file_bytes: bytes | None = None
    format: Literal["csv", "json", "parquet", "xlsx"] = "csv"


class DataQueryParams(BaseModel):
    """Parameters for querying a dataset with natural language."""

    dataset_id: str
    query: str
    format: Literal["table", "json", "chart"] = "table"


class DataQueryResult(BaseModel):
    """Result from a natural-language data query."""

    data: Any = None
    columns: list[str] = Field(default_factory=list)
    summary: str = ""
    visualization: dict[str, Any] | None = None
