from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


class WorkflowCondition(BaseModel):
    """A condition that controls step execution within a workflow."""

    field: str
    operator: Literal["eq", "neq", "gt", "gte", "lt", "lte", "in", "not_in", "contains"]
    value: Any


class WorkflowTrigger(BaseModel):
    """A trigger that can start a workflow."""

    type: Literal["signal", "schedule", "webhook", "manual", "agent"]
    config: dict[str, Any] = Field(default_factory=dict)


class WorkflowStep(BaseModel):
    """A single step within a workflow."""

    id: str
    agent_id: str
    action: str
    input_mapping: dict[str, str] = Field(default_factory=dict)
    conditions: list[WorkflowCondition] = Field(default_factory=list)
    confidence_gate: float | None = None
    timeout: int | None = None


class Workflow(BaseModel):
    """A multi-step workflow orchestrating agents."""

    id: str
    name: str
    steps: list[WorkflowStep] = Field(default_factory=list)
    status: Literal["active", "inactive", "running", "paused", "error"] = "inactive"
    triggers: list[WorkflowTrigger] = Field(default_factory=list)
    created_at: datetime | None = None
    updated_at: datetime | None = None


class WorkflowCreateParams(BaseModel):
    """Parameters for creating a new workflow."""

    name: str
    steps: list[WorkflowStep] = Field(default_factory=list)
    triggers: list[WorkflowTrigger] = Field(default_factory=list)


class WorkflowRunParams(BaseModel):
    """Parameters for running a workflow."""

    input: dict[str, Any] = Field(default_factory=dict)
    context: dict[str, Any] = Field(default_factory=dict)


class WorkflowStepResult(BaseModel):
    """Result from a single workflow step execution."""

    step_id: str
    output: Any
    confidence: float
    status: Literal["completed", "failed", "skipped", "approval_pending"] = "completed"
    duration: float | None = None


class WorkflowRunResult(BaseModel):
    """Result from a complete workflow run."""

    output: Any
    step_results: list[WorkflowStepResult] = Field(default_factory=list)
    total_confidence: float
    duration: float | None = None
