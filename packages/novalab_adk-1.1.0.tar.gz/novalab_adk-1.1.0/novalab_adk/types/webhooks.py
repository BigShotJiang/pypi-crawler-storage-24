from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

WebhookEvent = Literal[
    "approval.needed",
    "anomaly.detected",
    "agent.run.completed",
    "agent.run.failed",
    "workflow.completed",
    "signal.alert",
    "automation.triggered",
    "confidence.low",
]


class Webhook(BaseModel):
    """A webhook subscription."""

    id: str
    url: str
    events: list[WebhookEvent] = Field(default_factory=list)
    secret: str = ""
    status: Literal["active", "inactive", "error"] = "active"
    created_at: datetime | None = None


class WebhookCreateParams(BaseModel):
    """Parameters for creating a webhook."""

    url: str
    events: list[WebhookEvent]
    secret: str | None = None


class WebhookPayload(BaseModel):
    """Payload delivered to a webhook endpoint."""

    event: WebhookEvent
    timestamp: datetime | None = None
    data: dict[str, Any] = Field(default_factory=dict)
    signature: str = ""
