from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

from novalab_adk.types.trust import TrustEvaluation

AgentStatus = Literal["active", "inactive", "deploying", "error"]
MemoryScope = Literal["session", "persistent", "shared"]
RiskLevel = Literal["low", "medium", "high", "critical"]


class HumanApprovalConfig(BaseModel):
    """Configuration for human-in-the-loop approval on high-risk actions."""

    required: bool = False
    risk_threshold: RiskLevel = "high"
    timeout_seconds: int = 300
    escalation_email: str | None = None


class AgentTool(BaseModel):
    """A tool available to an agent."""

    name: str
    description: str = ""
    permissions: list[str] = Field(default_factory=list)
    risk_level: RiskLevel = "low"


class AgentTrigger(BaseModel):
    """A trigger that can activate an agent."""

    type: Literal["signal", "schedule", "webhook", "manual"]
    config: dict[str, Any] = Field(default_factory=dict)


class Agent(BaseModel):
    """A Nova agent."""

    id: str
    name: str
    description: str = ""
    status: AgentStatus = "inactive"
    model: str = "gemini-pro"
    tools: list[AgentTool] = Field(default_factory=list)
    triggers: list[AgentTrigger] = Field(default_factory=list)
    confidence_thresholds: dict[str, float] | None = None
    memory_scope: MemoryScope = "session"
    risk_level: RiskLevel = "low"
    human_approval: HumanApprovalConfig = Field(default_factory=HumanApprovalConfig)
    created_at: datetime | None = None
    updated_at: datetime | None = None


class AgentCreateParams(BaseModel):
    """Parameters for creating a new agent."""

    name: str
    description: str = ""
    model: str = "gemini-pro"
    tools: list[AgentTool] = Field(default_factory=list)
    triggers: list[AgentTrigger] = Field(default_factory=list)
    confidence_thresholds: dict[str, float] | None = None
    memory_scope: MemoryScope = "session"
    risk_level: RiskLevel = "low"
    human_approval: HumanApprovalConfig | None = None


class AgentUpdateParams(BaseModel):
    """Parameters for updating an existing agent."""

    name: str | None = None
    description: str | None = None
    model: str | None = None
    tools: list[AgentTool] | None = None
    triggers: list[AgentTrigger] | None = None
    confidence_thresholds: dict[str, float] | None = None
    memory_scope: MemoryScope | None = None
    risk_level: RiskLevel | None = None
    human_approval: HumanApprovalConfig | None = None


class AgentDeployParams(BaseModel):
    """Parameters for deploying an agent."""

    environment: str = "production"
    region: str = "eu-west-1"
    scaling: dict[str, Any] = Field(default_factory=dict)


class AgentRunParams(BaseModel):
    """Parameters for running an agent."""

    input: str | dict[str, Any]
    context: dict[str, Any] = Field(default_factory=dict)
    stream: bool = False


class AgentRunResult(BaseModel):
    """Result from an agent run."""

    output: Any
    confidence: float
    agents_involved: list[str] = Field(default_factory=list)
    audit_id: str | None = None
    duration: float | None = None
    trust: TrustEvaluation | None = None
