from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, Field

from novalab_adk.types.trust import TrustEvaluation


class DecisionExplanation(BaseModel):
    """A detailed explanation of an agent decision."""

    summary: str = ""
    agents_involved: list[str] = Field(default_factory=list)
    data_accessed: list[str] = Field(default_factory=list)
    confidence_model: str = ""
    reasoning: str = ""
    autonomy_level: str = ""
    trust_evaluation: TrustEvaluation | None = None


class HistoryEntry(BaseModel):
    """A record in the decision-history audit log."""

    id: str
    type: str = ""
    agent_ids: list[str] = Field(default_factory=list)
    input: Any = None
    output: Any = None
    confidence: float = 0.0
    status: Literal["completed", "failed", "pending", "approval_needed"] = "completed"
    explanation: DecisionExplanation | None = None
    trust: TrustEvaluation | None = None
    created_at: datetime | None = None
    duration: float | None = None


class HistoryQueryParams(BaseModel):
    """Parameters for querying the decision history."""

    agent_id: str | None = None
    start_date: datetime | None = None
    end_date: datetime | None = None
    status: Literal["completed", "failed", "pending", "approval_needed"] | None = None
    min_confidence: float | None = None
    limit: int = 50
    offset: int = 0
