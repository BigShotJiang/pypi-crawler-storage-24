from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from novalab_adk.core.errors import NovaConfidenceError


class ConfidenceLevel(str, Enum):
    """Classification of a confidence score into an operational level."""

    AUTONOMOUS = "autonomous"
    NOTIFY = "notify"
    APPROVAL_REQUIRED = "approval_required"
    BLOCKED = "blocked"


@dataclass(frozen=True, slots=True)
class ConfidenceThresholds:
    """Thresholds that map confidence scores to operational levels.

    - score >= autonomous  -> AUTONOMOUS
    - score >= notify      -> NOTIFY
    - score >= approval    -> APPROVAL_REQUIRED
    - score < approval     -> BLOCKED
    """

    autonomous: float = 85.0
    notify: float = 70.0
    approval: float = 40.0

    def __post_init__(self) -> None:
        if not (self.approval <= self.notify <= self.autonomous <= 100.0):
            raise ValueError(
                "Thresholds must satisfy: approval <= notify <= autonomous <= 100"
            )
        if self.approval < 0.0:
            raise ValueError("Thresholds must be non-negative")


DEFAULT_THRESHOLDS = ConfidenceThresholds()


def evaluate_confidence(
    score: float,
    thresholds: ConfidenceThresholds | None = None,
) -> ConfidenceLevel:
    """Evaluate a confidence score and return the corresponding operational level."""
    if not 0.0 <= score <= 100.0:
        raise ValueError("Confidence score must be between 0 and 100")

    t = thresholds or DEFAULT_THRESHOLDS

    if score >= t.autonomous:
        return ConfidenceLevel.AUTONOMOUS
    if score >= t.notify:
        return ConfidenceLevel.NOTIFY
    if score >= t.approval:
        return ConfidenceLevel.APPROVAL_REQUIRED
    return ConfidenceLevel.BLOCKED


@dataclass
class ConfidenceGate:
    """A gate that enforces confidence thresholds for agent or workflow decisions.

    When a score is evaluated, the gate determines whether the action can proceed
    autonomously, needs notification, requires human approval, or should be blocked.
    """

    thresholds: ConfidenceThresholds = field(default_factory=lambda: DEFAULT_THRESHOLDS)
    block_below: float | None = None

    def evaluate(self, score: float) -> ConfidenceLevel:
        """Evaluate a score against the gate's thresholds."""
        level = evaluate_confidence(score, self.thresholds)

        if self.block_below is not None and score < self.block_below:
            raise NovaConfidenceError(score=score, threshold=self.block_below)

        return level

    def require_autonomous(self, score: float) -> None:
        """Raise if the score does not reach the autonomous threshold."""
        level = evaluate_confidence(score, self.thresholds)
        if level != ConfidenceLevel.AUTONOMOUS:
            raise NovaConfidenceError(
                score=score, threshold=self.thresholds.autonomous
            )

    def is_autonomous(self, score: float) -> bool:
        """Return True if the score qualifies for autonomous execution."""
        return evaluate_confidence(score, self.thresholds) == ConfidenceLevel.AUTONOMOUS

    def needs_approval(self, score: float) -> bool:
        """Return True if the score falls into the approval-required level."""
        return (
            evaluate_confidence(score, self.thresholds)
            == ConfidenceLevel.APPROVAL_REQUIRED
        )
