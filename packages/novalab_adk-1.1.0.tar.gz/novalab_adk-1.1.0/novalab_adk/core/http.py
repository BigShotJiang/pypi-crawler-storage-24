from __future__ import annotations

import asyncio
import uuid
from typing import Any

import httpx

from novalab_adk.core.errors import (
    NovaAPIError,
    NovaAuthError,
    NovaError,
    NovaRateLimitError,
    NovaTimeoutError,
)

DEFAULT_TIMEOUT = 30.0
DEFAULT_MAX_RETRIES = 3
DEFAULT_BACKOFF_BASE = 0.5
RETRYABLE_STATUS_CODES = frozenset({429, 500, 502, 503, 504})


class HttpClient:
    """Async HTTP client wrapper for NovaLab API communication."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str = "",
        region: str = "eu-west-1",
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
    ) -> None:
        self._api_key = api_key
        self._region = region
        self._timeout = timeout
        self._max_retries = max_retries
        self._base_url = base_url or f"https://{region}.api.novalab.build/v1"
        self._client: httpx.AsyncClient | None = None

    def _get_client(self) -> httpx.AsyncClient:
        if self._client is None or self._client.is_closed:
            self._client = httpx.AsyncClient(
                base_url=self._base_url,
                timeout=httpx.Timeout(self._timeout),
                headers={
                    "Authorization": f"Bearer {self._api_key}",
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                    "User-Agent": "novalab-adk-python/0.1.0",
                },
            )
        return self._client

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        if self._client is not None and not self._client.is_closed:
            await self._client.aclose()
            self._client = None

    async def get(self, path: str, params: dict[str, Any] | None = None) -> Any:
        """Send a GET request."""
        return await self._request("GET", path, params=params)

    async def post(self, path: str, json: Any = None) -> Any:
        """Send a POST request."""
        return await self._request("POST", path, json=json)

    async def put(self, path: str, json: Any = None) -> Any:
        """Send a PUT request."""
        return await self._request("PUT", path, json=json)

    async def patch(self, path: str, json: Any = None) -> Any:
        """Send a PATCH request."""
        return await self._request("PATCH", path, json=json)

    async def delete(self, path: str) -> Any:
        """Send a DELETE request."""
        return await self._request("DELETE", path)

    async def post_file(
        self,
        path: str,
        file_name: str,
        file_bytes: bytes,
        content_type: str = "application/octet-stream",
        data: dict[str, Any] | None = None,
    ) -> Any:
        """Send a POST request with a file upload."""
        request_id = uuid.uuid4().hex
        client = self._get_client()
        files = {"file": (file_name, file_bytes, content_type)}
        try:
            response = await client.post(
                path,
                files=files,
                data=data or {},
                headers={"X-Request-ID": request_id},
            )
        except httpx.TimeoutException as exc:
            raise NovaTimeoutError(f"Request timed out: {exc}") from exc
        except httpx.HTTPError as exc:
            raise NovaError(f"HTTP error: {exc}") from exc
        return self._handle_response(response, request_id)

    async def stream_sse(self, path: str, json: Any = None) -> httpx.Response:
        """Open a streaming SSE connection and return the raw response."""
        request_id = uuid.uuid4().hex
        client = self._get_client()
        try:
            request = client.build_request(
                "POST",
                path,
                json=json,
                headers={
                    "X-Request-ID": request_id,
                    "Accept": "text/event-stream",
                },
            )
            response = await client.send(request, stream=True)
            if response.status_code >= 400:
                body = await response.aread()
                await response.aclose()
                self._raise_for_status(response.status_code, body, request_id)
            return response
        except httpx.TimeoutException as exc:
            raise NovaTimeoutError(f"Stream request timed out: {exc}") from exc
        except httpx.HTTPError as exc:
            raise NovaError(f"HTTP error during streaming: {exc}") from exc

    async def _request(
        self,
        method: str,
        path: str,
        params: dict[str, Any] | None = None,
        json: Any = None,
    ) -> Any:
        request_id = uuid.uuid4().hex
        last_exc: Exception | None = None

        for attempt in range(self._max_retries + 1):
            try:
                client = self._get_client()
                response = await client.request(
                    method,
                    path,
                    params=params,
                    json=json,
                    headers={"X-Request-ID": request_id},
                )

                if response.status_code in RETRYABLE_STATUS_CODES and attempt < self._max_retries:
                    retry_after = self._get_retry_delay(response, attempt)
                    await asyncio.sleep(retry_after)
                    continue

                return self._handle_response(response, request_id)

            except (httpx.TimeoutException, httpx.ConnectError) as exc:
                last_exc = exc
                if attempt < self._max_retries:
                    await asyncio.sleep(DEFAULT_BACKOFF_BASE * (2 ** attempt))
                    continue
                if isinstance(exc, httpx.TimeoutException):
                    raise NovaTimeoutError(f"Request timed out after {self._max_retries + 1} attempts") from exc
                raise NovaError(f"Connection error after {self._max_retries + 1} attempts: {exc}") from exc

        raise NovaError(f"Request failed after {self._max_retries + 1} attempts") from last_exc

    def _handle_response(self, response: httpx.Response, request_id: str) -> Any:
        if response.status_code == 204:
            return None

        if response.status_code >= 400:
            self._raise_for_status(response.status_code, response.content, request_id)

        try:
            return response.json()
        except ValueError:
            return response.text

    def _raise_for_status(
        self, status_code: int, body: bytes, request_id: str
    ) -> None:
        try:
            data = httpx.Response(status_code=status_code, content=body).json()
            code = data.get("code", "unknown_error")
            message = data.get("message", "Unknown API error")
        except (ValueError, AttributeError):
            code = "unknown_error"
            message = body.decode("utf-8", errors="replace") if body else "Unknown API error"

        if status_code == 401:
            raise NovaAuthError(message=message, request_id=request_id)

        if status_code == 429:
            retry_after = 1.0
            try:
                retry_data = httpx.Response(status_code=status_code, content=body).json()
                retry_after = float(retry_data.get("retry_after", 1.0))
            except (ValueError, AttributeError, KeyError):
                pass
            raise NovaRateLimitError(
                retry_after=retry_after,
                message=message,
                request_id=request_id,
            )

        raise NovaAPIError(
            status_code=status_code,
            code=code,
            message=message,
            request_id=request_id,
        )

    @staticmethod
    def _get_retry_delay(response: httpx.Response, attempt: int) -> float:
        retry_after = response.headers.get("Retry-After")
        if retry_after is not None:
            try:
                return float(retry_after)
            except ValueError:
                pass
        return DEFAULT_BACKOFF_BASE * (2 ** attempt)
