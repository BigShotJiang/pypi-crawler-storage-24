from __future__ import annotations


class NovaError(Exception):
    """Base exception for all NovaLab ADK errors."""

    def __init__(self, message: str) -> None:
        self.message = message
        super().__init__(message)

    def __str__(self) -> str:
        return self.message

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(message={self.message!r})"


class NovaAPIError(NovaError):
    """Raised when the NovaLab API returns an error response."""

    def __init__(
        self,
        status_code: int,
        code: str,
        message: str,
        request_id: str | None = None,
    ) -> None:
        self.status_code = status_code
        self.code = code
        self.request_id = request_id
        super().__init__(message)

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"status_code={self.status_code}, "
            f"code={self.code!r}, "
            f"message={self.message!r}, "
            f"request_id={self.request_id!r})"
        )


class NovaAuthError(NovaAPIError):
    """Raised when authentication or authorization fails."""

    def __init__(
        self,
        message: str = "Authentication failed",
        request_id: str | None = None,
    ) -> None:
        super().__init__(
            status_code=401,
            code="auth_error",
            message=message,
            request_id=request_id,
        )


class NovaRateLimitError(NovaAPIError):
    """Raised when rate limits are exceeded."""

    def __init__(
        self,
        retry_after: float,
        message: str = "Rate limit exceeded",
        request_id: str | None = None,
    ) -> None:
        self.retry_after = retry_after
        super().__init__(
            status_code=429,
            code="rate_limit_exceeded",
            message=message,
            request_id=request_id,
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"retry_after={self.retry_after}, "
            f"message={self.message!r}, "
            f"request_id={self.request_id!r})"
        )


class NovaValidationError(NovaError):
    """Raised when input validation fails."""

    def __init__(self, message: str = "Validation error") -> None:
        super().__init__(message)


class NovaTimeoutError(NovaError):
    """Raised when a request or operation times out."""

    def __init__(self, message: str = "Request timed out") -> None:
        super().__init__(message)


class NovaConfidenceError(NovaError):
    """Raised when a confidence score does not meet the required threshold."""

    def __init__(self, score: float, threshold: float) -> None:
        self.score = score
        self.threshold = threshold
        super().__init__(
            f"Confidence score {score:.1f} is below the required threshold {threshold:.1f}"
        )

    def __repr__(self) -> str:
        return (
            f"{self.__class__.__name__}("
            f"score={self.score}, "
            f"threshold={self.threshold})"
        )
