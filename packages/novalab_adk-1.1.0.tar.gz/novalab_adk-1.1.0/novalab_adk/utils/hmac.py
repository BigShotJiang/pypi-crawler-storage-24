from __future__ import annotations

import hashlib
import hmac as _hmac


def sign_payload(payload: str, secret: str) -> str:
    """Compute an HMAC-SHA256 hex digest of *payload* using *secret*."""
    return _hmac.new(
        key=secret.encode("utf-8"),
        msg=payload.encode("utf-8"),
        digestmod=hashlib.sha256,
    ).hexdigest()


def verify_webhook_signature(payload: str, signature: str, secret: str) -> bool:
    """Verify that *signature* matches the HMAC-SHA256 of *payload*."""
    expected = sign_payload(payload, secret)
    return _hmac.compare_digest(expected, signature)
