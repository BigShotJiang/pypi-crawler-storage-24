from __future__ import annotations

import json
from collections.abc import AsyncIterator, Awaitable, Callable
from typing import Generic, TypeVar

import httpx

T = TypeVar("T")

EventHandler = Callable[[dict], Awaitable[None] | None]


class NovaStream(Generic[T], AsyncIterator[T]):
    """Async iterator over server-sent events that yields parsed objects of type T.

    Usage::

        stream = nova.agents.stream(agent_id, params)
        async for result in stream:
            print(result)

        # Or collect all results
        results = await stream.collect()
    """

    def __init__(
        self,
        response: httpx.Response,
        model_cls: type[T],
    ) -> None:
        self._response = response
        self._model_cls = model_cls
        self._handlers: dict[str, list[EventHandler]] = {}
        self._closed = False
        self._iterator: AsyncIterator[str] | None = None

    def on(self, event: str, handler: EventHandler) -> NovaStream[T]:
        """Register a handler for a named SSE event type."""
        self._handlers.setdefault(event, []).append(handler)
        return self

    async def close(self) -> None:
        """Close the underlying streaming response."""
        if not self._closed:
            self._closed = True
            await self._response.aclose()

    async def collect(self) -> list[T]:
        """Consume the entire stream and return all items as a list."""
        items: list[T] = []
        async for item in self:
            items.append(item)
        return items

    def __aiter__(self) -> NovaStream[T]:
        return self

    async def __anext__(self) -> T:
        if self._closed:
            raise StopAsyncIteration

        if self._iterator is None:
            self._iterator = self._response.aiter_lines()

        event_type = "message"
        data_lines: list[str] = []

        try:
            async for line in self._iterator:
                if line.startswith("event:"):
                    event_type = line[len("event:"):].strip()
                    continue

                if line.startswith("data:"):
                    data_lines.append(line[len("data:"):].strip())
                    continue

                if line == "" and data_lines:
                    raw_data = "\n".join(data_lines)
                    data_lines = []

                    if raw_data == "[DONE]":
                        await self.close()
                        raise StopAsyncIteration

                    try:
                        parsed = json.loads(raw_data)
                    except json.JSONDecodeError:
                        continue

                    await self._dispatch(event_type, parsed)
                    event_type = "message"

                    if hasattr(self._model_cls, "model_validate"):
                        return self._model_cls.model_validate(parsed)  # type: ignore[return-value]
                    return self._model_cls(**parsed)  # type: ignore[return-value]

        except (httpx.StreamClosed, httpx.RemoteProtocolError):
            await self.close()

        await self.close()
        raise StopAsyncIteration

    async def _dispatch(self, event_type: str, data: dict) -> None:
        handlers = self._handlers.get(event_type, [])
        for handler in handlers:
            result = handler(data)
            if isinstance(result, Awaitable):
                await result

    async def __aenter__(self) -> NovaStream[T]:
        return self

    async def __aexit__(self, *exc: object) -> None:
        await self.close()
