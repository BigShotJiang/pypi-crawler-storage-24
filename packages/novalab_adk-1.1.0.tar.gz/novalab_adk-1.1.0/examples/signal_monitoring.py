import asyncio
import os
from datetime import datetime

from novalab_adk import NovaClient


async def main():
    async with NovaClient(
        api_key=os.environ["NOVA_API_KEY"],
        region="eu-west-1",
    ) as nova:
        # Register a signal system
        system = await nova.signals.systems.create(
            name="Factory Floor — Line A",
            type="machine",
            config={
                "protocol": "mqtt",
                "endpoint": "mqtt://factory.internal:1883",
                "topic": "line-a/+/telemetry",
            },
        )
        print(f"System registered: {system.id}")

        # Ingest signals manually
        await nova.signals.ingest(
            system_id=system.id,
            signals=[
                {"name": "temperature", "value": 72.5, "unit": "°C", "timestamp": datetime.now().isoformat()},
                {"name": "vibration", "value": 0.34, "unit": "mm/s", "timestamp": datetime.now().isoformat()},
                {"name": "pressure", "value": 4.2, "unit": "bar", "timestamp": datetime.now().isoformat()},
                {"name": "rpm", "value": 1450, "unit": "rpm", "timestamp": datetime.now().isoformat()},
            ],
        )

        # Stream real-time signals
        stream = nova.signals.stream(
            system_ids=[system.id],
            signal_names=["temperature", "vibration"],
            interval=1000,
        )

        async def handle_signal(signal):
            print(f"[{signal.timestamp}] {signal.name}: {signal.value} {signal.unit} (health: {signal.health})")

        async def handle_anomaly(anomaly):
            print(f"ANOMALY: {anomaly.description} (severity: {anomaly.severity}, confidence: {anomaly.confidence}%)")

        stream.on("data", handle_signal)
        stream.on("anomaly", handle_anomaly)

        # Check anomalies
        anomalies = await nova.signals.anomalies.list(system.id)
        for anomaly in anomalies:
            print(f"Anomaly {anomaly.id}: {anomaly.description} — confidence {anomaly.confidence}%")

        # Get signal history
        history = await nova.signals.history(
            system.id,
            signal_name="temperature",
            start_date="2026-03-01T00:00:00Z",
            end_date="2026-03-03T00:00:00Z",
            interval="1h",
        )
        print(f"Temperature readings: {len(history)}")

        # Set up webhook for anomaly alerts
        await nova.webhooks.create(
            url="https://company.com/webhooks/nova-alerts",
            events=["anomaly.detected", "signal.alert", "approval.needed"],
            secret="whsec_your_secret_here",
        )

        # Keep streaming for 60 seconds
        await asyncio.sleep(60)
        await stream.close()
        print("Stream closed.")


if __name__ == "__main__":
    asyncio.run(main())
