import asyncio
import os

from novalab_adk import NovaClient


async def main():
    async with NovaClient(
        api_key=os.environ["NOVA_API_KEY"],
        region="eu-west-1",
    ) as nova:
        # Create an agent
        agent = await nova.agents.create(
            name="Risk Analyser",
            description="Analyses financial risk across portfolio data",
            model="claude",
            tools=[
                {
                    "name": "portfolio_reader",
                    "description": "Reads portfolio data from connected sources",
                    "permissions": ["data:read"],
                    "risk_level": "low",
                },
                {
                    "name": "risk_calculator",
                    "description": "Computes risk scores using financial models",
                    "permissions": ["compute:execute"],
                    "risk_level": "medium",
                },
            ],
            triggers=[
                {
                    "type": "schedule",
                    "config": {"cron": "0 8 * * 1-5"},  # Weekdays at 8am
                },
            ],
            confidence_thresholds={
                "autonomous": 90,
                "notify": 70,
                "approval_required": 50,
            },
            memory_scope="persistent",
            risk_level="medium",
            human_approval={
                "required": True,
                "risk_threshold": "high",
                "timeout_seconds": 3600,
                "escalation_email": "risk-team@company.com",
            },
        )

        print(f"Agent created: {agent.id}")

        # Deploy the agent
        deployed = await nova.agents.deploy(
            agent.id,
            environment="production",
            region="eu-west-1",
        )
        print(f"Agent deployed: {deployed.status}")

        # Run the agent
        result = await nova.agents.run(
            agent.id,
            input="Analyse current portfolio risk exposure for Q1 2026",
            context={"portfolio": "global-equity-fund"},
        )

        print(f"Confidence: {result.confidence}%")
        print(f"Output: {result.output}")
        print(f"Agents involved: {', '.join(result.agents_involved)}")
        print(f"Audit ID: {result.audit_id}")

        # Stream agent responses
        stream = nova.agents.stream(
            agent.id,
            input="Provide real-time risk assessment",
            stream=True,
        )

        async for chunk in stream:
            print(chunk.output, end="", flush=True)

        # Get decision explanation
        explanation = await nova.history.explain(result.audit_id)
        print(f"\nDecision reasoning: {explanation.reasoning}")


if __name__ == "__main__":
    asyncio.run(main())
