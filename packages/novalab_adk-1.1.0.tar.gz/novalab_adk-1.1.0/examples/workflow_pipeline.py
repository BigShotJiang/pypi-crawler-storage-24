import asyncio
import os

from novalab_adk import NovaClient


async def main():
    async with NovaClient(
        api_key=os.environ["NOVA_API_KEY"],
        region="eu-west-1",
    ) as nova:
        # Create a multi-step workflow with confidence gates
        workflow = await nova.workflows.create(
            name="Customer Onboarding Pipeline",
            description="Automated customer onboarding with KYC and risk assessment",
            steps=[
                {
                    "id": "step-1",
                    "agent_id": "nova-intent",
                    "action": "classify_request",
                    "input_mapping": {"source": "$.input"},
                    "confidence_gate": 80,
                    "timeout": 30000,
                },
                {
                    "id": "step-2",
                    "agent_id": "kyc-verifier",
                    "action": "verify_identity",
                    "input_mapping": {"customer_data": "$.steps.step-1.output.customer"},
                    "conditions": [
                        {
                            "field": "$.steps.step-1.output.type",
                            "operator": "equals",
                            "value": "new_customer",
                        },
                    ],
                    "confidence_gate": 90,
                    "timeout": 60000,
                },
                {
                    "id": "step-3",
                    "agent_id": "risk-assessor",
                    "action": "assess_risk",
                    "input_mapping": {
                        "identity": "$.steps.step-2.output.identity",
                        "history": "$.steps.step-2.output.history",
                    },
                    "confidence_gate": 70,
                    "timeout": 45000,
                },
                {
                    "id": "step-4",
                    "agent_id": "account-provisioner",
                    "action": "create_account",
                    "input_mapping": {
                        "customer": "$.steps.step-1.output.customer",
                        "risk_level": "$.steps.step-3.output.risk_level",
                        "kyc_status": "$.steps.step-2.output.status",
                    },
                    "confidence_gate": 95,
                    "timeout": 30000,
                },
            ],
            triggers=[
                {
                    "type": "webhook",
                    "config": {"path": "/onboarding/new"},
                },
            ],
        )

        print(f"Workflow created: {workflow.id}")

        # Run the workflow
        result = await nova.workflows.run(
            workflow.id,
            input={
                "customer_name": "Acme Corp",
                "customer_email": "onboarding@acme.com",
                "company_number": "DE-123456789",
                "country": "Germany",
            },
        )

        print(f"Workflow completed in {result.duration}ms")
        print(f"Overall confidence: {result.total_confidence}%")

        for step in result.step_results:
            print(f"  {step.step_id}: {step.status} ({step.confidence}%) — {step.duration}ms")

        # Add a step dynamically
        await nova.workflows.add_step(
            workflow.id,
            step={
                "id": "step-5",
                "agent_id": "welcome-emailer",
                "action": "send_welcome",
                "input_mapping": {
                    "email": "$.steps.step-1.output.customer.email",
                    "account_id": "$.steps.step-4.output.account_id",
                },
                "confidence_gate": 85,
                "timeout": 15000,
            },
        )


if __name__ == "__main__":
    asyncio.run(main())
