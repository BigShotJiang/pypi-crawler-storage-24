import asyncio
import os

from novalab_adk import NovaClient
from novalab_adk.utils.hmac import verify_webhook_signature


async def main():
    async with NovaClient(
        api_key=os.environ["NOVA_API_KEY"],
        region="eu-west-1",
    ) as nova:
        # --- Connections ---

        connections = await nova.connections.list()
        print(f"Connected services: {len(connections)}")

        # Create a Slack connection
        slack = await nova.connections.create(
            name="Engineering Slack",
            category="communication",
            provider="slack",
            config={
                "webhook_url": "https://hooks.slack.com/services/...",
                "default_channel": "#nova-alerts",
            },
            permissions=[
                {"scope": "messages:write", "risk_level": "low", "granted": True},
                {"scope": "channels:read", "risk_level": "low", "granted": True},
            ],
        )

        test_result = await nova.connections.test(slack.id)
        print(f"Slack connection test: {test_result.status}")

        # --- Automations ---

        automation = await nova.automations.create(
            name="High Temperature Alert",
            description="When factory temperature exceeds 85°C, notify engineering and reduce machine speed",
            trigger={
                "type": "signal",
                "config": {
                    "system_type": "machine",
                    "signal_name": "temperature",
                    "condition": "above",
                    "threshold": 85,
                },
            },
            actions=[
                {
                    "type": "notify",
                    "config": {
                        "connection_id": slack.id,
                        "message": "Temperature alert: {{signal.name}} at {{signal.value}}{{signal.unit}} on {{system.name}}",
                    },
                },
                {
                    "type": "agent_run",
                    "config": {
                        "agent_id": "machine-controller",
                        "input": "Reduce speed on {{system.name}} by 20% due to high temperature",
                    },
                },
            ],
            confidence_threshold=80,
        )

        print(f"Automation created: {automation.id} ({automation.status})")

        # List executions
        executions = await nova.automations.executions.list(automation.id)
        for exc in executions:
            print(f"Execution {exc.id}: {exc.status}")
            for step in exc.steps:
                print(f"  {step.name}: {step.status} ({step.duration}ms)")

        # --- Data Explorer ---

        dataset = await nova.data.upload(
            name="Q1 Production Metrics",
            file_bytes=b"machine,temperature,output\nLine-A,72,450\nLine-B,68,520",
            format="csv",
        )
        print(f"Dataset uploaded: {dataset.id} ({dataset.row_count} rows)")

        query_result = await nova.data.query(
            dataset_id=dataset.id,
            query="Which machine has the highest output?",
            format="json",
        )
        print(f"Answer: {query_result.summary}")

        # --- Webhook Verification ---

        incoming_payload = '{"event":"anomaly.detected","data":{}}'
        incoming_signature = "sha256=abc123..."
        secret = "whsec_your_secret"

        is_valid = verify_webhook_signature(incoming_payload, incoming_signature, secret)
        print(f"Webhook signature valid: {is_valid}")


if __name__ == "__main__":
    asyncio.run(main())
