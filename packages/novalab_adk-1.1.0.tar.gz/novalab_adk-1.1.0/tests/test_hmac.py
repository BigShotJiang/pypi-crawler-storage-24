from __future__ import annotations

import re

from novalab_adk.utils.hmac import sign_payload, verify_webhook_signature


class TestSignPayload:
    def test_returns_hex_string(self):
        sig = sign_payload("test payload", "secret-key")
        assert re.fullmatch(r"[0-9a-f]{64}", sig)

    def test_deterministic(self):
        sig1 = sign_payload("hello world", "my-secret")
        sig2 = sign_payload("hello world", "my-secret")
        assert sig1 == sig2

    def test_different_payloads(self):
        sig1 = sign_payload("payload-a", "secret")
        sig2 = sign_payload("payload-b", "secret")
        assert sig1 != sig2

    def test_different_secrets(self):
        sig1 = sign_payload("same-payload", "secret-1")
        sig2 = sign_payload("same-payload", "secret-2")
        assert sig1 != sig2

    def test_empty_payload(self):
        sig = sign_payload("", "secret")
        assert re.fullmatch(r"[0-9a-f]{64}", sig)

    def test_unicode_payload(self):
        sig = sign_payload("temperatur: 85°C", "geheimnis")
        assert re.fullmatch(r"[0-9a-f]{64}", sig)


class TestVerifyWebhookSignature:
    def test_valid_signature(self):
        payload = '{"event":"agent.run.completed","data":{}}'
        secret = "whsec_test123"
        signature = sign_payload(payload, secret)
        assert verify_webhook_signature(payload, signature, secret) is True

    def test_invalid_signature(self):
        payload = '{"event":"anomaly.detected"}'
        secret = "whsec_test123"
        assert verify_webhook_signature(payload, "invalid-sig", secret) is False

    def test_tampered_payload(self):
        original = '{"amount":100}'
        tampered = '{"amount":999}'
        secret = "whsec_prod"
        signature = sign_payload(original, secret)
        assert verify_webhook_signature(tampered, signature, secret) is False

    def test_wrong_secret(self):
        payload = '{"event":"test"}'
        signature = sign_payload(payload, "correct-secret")
        assert verify_webhook_signature(payload, signature, "wrong-secret") is False

    def test_empty_signature(self):
        assert verify_webhook_signature("payload", "", "secret") is False
