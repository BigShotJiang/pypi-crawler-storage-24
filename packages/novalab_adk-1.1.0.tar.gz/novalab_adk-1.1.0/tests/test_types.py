from __future__ import annotations

from datetime import datetime

from novalab_adk.types.agents import (
    Agent,
    AgentCreateParams,
    AgentRunResult,
    AgentTool,
    AgentTrigger,
    HumanApprovalConfig,
)
from novalab_adk.types.automations import Automation, AutomationExecution, AutomationStep
from novalab_adk.types.connections import Connection, ConnectionPermission
from novalab_adk.types.data import DataQueryResult, Dataset
from novalab_adk.types.history import DecisionExplanation, HistoryEntry
from novalab_adk.types.signals import Signal, SignalAnomaly, SignalSystem
from novalab_adk.types.webhooks import Webhook, WebhookPayload
from novalab_adk.types.workflows import (
    Workflow,
    WorkflowCondition,
    WorkflowRunResult,
    WorkflowStep,
    WorkflowStepResult,
)


class TestAgentTypes:
    def test_agent_model(self):
        agent = Agent(
            id="agent-1",
            name="Risk Analyser",
            description="Analyses risk",
            status="active",
            model="claude",
            tools=[AgentTool(name="calc", permissions=["math"])],
            triggers=[AgentTrigger(type="schedule", config={"cron": "0 * * * *"})],
            memory_scope="persistent",
            risk_level="medium",
        )
        assert agent.id == "agent-1"
        assert agent.tools[0].name == "calc"
        assert agent.status == "active"

    def test_agent_create_params(self):
        params = AgentCreateParams(
            name="New Agent",
            model="gemini-pro",
            human_approval=HumanApprovalConfig(
                required=True,
                risk_threshold="high",
                timeout_seconds=3600,
                escalation_email="team@company.com",
            ),
        )
        assert params.name == "New Agent"
        assert params.human_approval.required is True
        assert params.human_approval.escalation_email == "team@company.com"

    def test_agent_run_result(self):
        result = AgentRunResult(
            output="Risk is moderate",
            confidence=87.5,
            agents_involved=["nova-intent", "nova-research", "nova-guard"],
            audit_id="audit-123",
            duration=1250.0,
        )
        assert result.confidence == 87.5
        assert len(result.agents_involved) == 3


class TestWorkflowTypes:
    def test_workflow_step(self):
        step = WorkflowStep(
            id="step-1",
            agent_id="nova-intent",
            action="classify",
            input_mapping={"source": "$.input"},
            conditions=[WorkflowCondition(field="$.type", operator="eq", value="new")],
            confidence_gate=80.0,
            timeout=30000,
        )
        assert step.confidence_gate == 80.0
        assert step.conditions[0].operator == "eq"

    def test_workflow_run_result(self):
        result = WorkflowRunResult(
            output={"account_id": "acc-123"},
            step_results=[
                WorkflowStepResult(
                    step_id="step-1", output="classified", confidence=92.0, duration=500.0
                ),
                WorkflowStepResult(
                    step_id="step-2", output="verified", confidence=88.0, duration=1200.0
                ),
            ],
            total_confidence=90.0,
            duration=1700.0,
        )
        assert len(result.step_results) == 2
        assert result.total_confidence == 90.0


class TestSignalTypes:
    def test_signal(self):
        signal = Signal(
            id="sig-1",
            system_id="sys-1",
            system_type="machine",
            name="temperature",
            value=72.5,
            unit="°C",
            health="healthy",
            trend="stable",
        )
        assert signal.value == 72.5
        assert signal.health == "healthy"

    def test_signal_anomaly(self):
        anomaly = SignalAnomaly(
            id="anomaly-1",
            signal_id="sig-1",
            severity="high",
            description="Temperature spike detected",
            confidence=92.3,
        )
        assert anomaly.severity == "high"
        assert anomaly.confidence > 90.0

    def test_signal_system(self):
        system = SignalSystem(
            id="sys-1",
            name="Factory Line A",
            type="machine",
            status="online",
        )
        assert system.type == "machine"


class TestOtherTypes:
    def test_automation(self):
        auto = Automation(
            id="auto-1",
            name="Temp Alert",
            description="Alert on high temp",
            status="active",
            confidence_threshold=80.0,
        )
        assert auto.status == "active"
        assert auto.confidence_threshold == 80.0

    def test_connection(self):
        conn = Connection(
            id="conn-1",
            name="Slack",
            category="communication",
            provider="slack",
            status="connected",
            permissions=[
                ConnectionPermission(scope="messages:write", risk_level="low", granted=True)
            ],
            can_do=["Send messages", "Read channels"],
            cannot_do=["Delete channels"],
        )
        assert conn.status == "connected"
        assert conn.permissions[0].granted is True

    def test_webhook_payload(self):
        payload = WebhookPayload(
            event="anomaly.detected",
            timestamp=datetime.now(),
            data={"signal_id": "sig-1", "severity": "high"},
            signature="sha256=abc123",
        )
        assert payload.event == "anomaly.detected"

    def test_decision_explanation(self):
        explanation = DecisionExplanation(
            summary="Nova detected a temperature anomaly",
            agents_involved=["nova-intent", "nova-guard"],
            data_accessed=["signal:temperature", "baseline:factory-a"],
            confidence_model="nova-confidence-v2",
            reasoning="Temperature exceeded 3σ from baseline",
            autonomy_level="notify",
        )
        assert len(explanation.agents_involved) == 2
