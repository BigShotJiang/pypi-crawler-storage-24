from __future__ import annotations

from novalab_adk import NovaClient
from novalab_adk.resources.trust import TrustResource
from novalab_adk.types.trust import (
    TrustEvaluation,
    TrustEvaluateParams,
    TrustEvaluateResult,
    TrustLevel,
)
from novalab_adk.types.agents import AgentRunResult
from novalab_adk.types.history import DecisionExplanation, HistoryEntry


class TestTrustTypes:
    def test_trust_evaluation_defaults(self):
        te = TrustEvaluation()
        assert te.overall_score == 0.0
        assert te.trust_level == "medium"
        assert te.accuracy_score == 0.0
        assert te.safety_score == 0.0
        assert te.relevance_score == 0.0
        assert te.completeness_score == 0.0
        assert te.concerns == []
        assert te.reasoning == ""
        assert te.evaluator_model == ""
        assert te.evaluation_tokens == 0
        assert te.evaluation_duration_ms is None

    def test_trust_evaluation_with_values(self):
        te = TrustEvaluation(
            overall_score=92.5,
            trust_level="high",
            accuracy_score=95.0,
            safety_score=100.0,
            relevance_score=88.0,
            completeness_score=85.0,
            concerns=[],
            reasoning="High quality response",
            evaluator_model="claude-sonnet-4-20250514",
            evaluation_tokens=350,
            evaluation_duration_ms=1200.0,
        )
        assert te.overall_score == 92.5
        assert te.trust_level == "high"
        assert te.evaluation_tokens == 350

    def test_trust_level_values(self):
        for level in ["high", "medium", "low", "very_low"]:
            te = TrustEvaluation(trust_level=level)
            assert te.trust_level == level

    def test_trust_evaluate_params(self):
        params = TrustEvaluateParams(
            input="What is 2+2?",
            output="4",
            model="gemini-2.0-flash",
        )
        assert params.input == "What is 2+2?"
        assert params.output == "4"
        assert params.model == "gemini-2.0-flash"
        assert params.context == {}

    def test_trust_evaluate_params_defaults(self):
        params = TrustEvaluateParams(input="test", output="response")
        assert params.model == "unknown"
        assert params.context == {}

    def test_trust_evaluate_result(self):
        result = TrustEvaluateResult(
            audit_id="trust-abc123",
            trust=TrustEvaluation(overall_score=85.0, trust_level="high"),
            duration=500.0,
        )
        assert result.audit_id == "trust-abc123"
        assert result.trust.overall_score == 85.0
        assert result.duration == 500.0


class TestTrustIntegration:
    def test_agent_run_result_with_trust(self):
        trust = TrustEvaluation(overall_score=90.0, trust_level="high")
        result = AgentRunResult(
            output="Analysis complete",
            confidence=88.5,
            agents_involved=["nova-intent", "nova-trust"],
            audit_id="audit-123",
            duration=2000.0,
            trust=trust,
        )
        assert result.trust is not None
        assert result.trust.overall_score == 90.0

    def test_agent_run_result_without_trust(self):
        result = AgentRunResult(output="test", confidence=80.0)
        assert result.trust is None

    def test_history_entry_with_trust(self):
        trust = TrustEvaluation(overall_score=75.0, trust_level="medium")
        entry = HistoryEntry(id="hist-123", trust=trust)
        assert entry.trust is not None
        assert entry.trust.trust_level == "medium"

    def test_history_entry_without_trust(self):
        entry = HistoryEntry(id="hist-456")
        assert entry.trust is None

    def test_decision_explanation_with_trust(self):
        trust = TrustEvaluation(overall_score=60.0, trust_level="medium")
        explanation = DecisionExplanation(
            summary="Routed to Claude",
            trust_evaluation=trust,
        )
        assert explanation.trust_evaluation is not None

    def test_decision_explanation_without_trust(self):
        explanation = DecisionExplanation(summary="test")
        assert explanation.trust_evaluation is None

    def test_client_has_trust_resource(self):
        client = NovaClient(api_key="test-key")
        assert isinstance(client.trust, TrustResource)
