from __future__ import annotations

import pytest

from novalab_adk.core.confidence import (
    ConfidenceGate,
    ConfidenceLevel,
    ConfidenceThresholds,
    evaluate_confidence,
)
from novalab_adk.core.errors import NovaConfidenceError


class TestEvaluateConfidence:
    def test_autonomous_range(self):
        assert evaluate_confidence(85.0) == ConfidenceLevel.AUTONOMOUS
        assert evaluate_confidence(90.0) == ConfidenceLevel.AUTONOMOUS
        assert evaluate_confidence(100.0) == ConfidenceLevel.AUTONOMOUS

    def test_notify_range(self):
        assert evaluate_confidence(70.0) == ConfidenceLevel.NOTIFY
        assert evaluate_confidence(75.0) == ConfidenceLevel.NOTIFY
        assert evaluate_confidence(84.9) == ConfidenceLevel.NOTIFY

    def test_approval_required_range(self):
        assert evaluate_confidence(40.0) == ConfidenceLevel.APPROVAL_REQUIRED
        assert evaluate_confidence(50.0) == ConfidenceLevel.APPROVAL_REQUIRED
        assert evaluate_confidence(69.9) == ConfidenceLevel.APPROVAL_REQUIRED

    def test_blocked_range(self):
        assert evaluate_confidence(0.0) == ConfidenceLevel.BLOCKED
        assert evaluate_confidence(20.0) == ConfidenceLevel.BLOCKED
        assert evaluate_confidence(39.9) == ConfidenceLevel.BLOCKED

    def test_out_of_range_raises(self):
        with pytest.raises(ValueError, match="between 0 and 100"):
            evaluate_confidence(-1.0)
        with pytest.raises(ValueError, match="between 0 and 100"):
            evaluate_confidence(101.0)

    def test_custom_thresholds(self):
        thresholds = ConfidenceThresholds(autonomous=95, notify=80, approval=60)
        assert evaluate_confidence(95.0, thresholds) == ConfidenceLevel.AUTONOMOUS
        assert evaluate_confidence(80.0, thresholds) == ConfidenceLevel.NOTIFY
        assert evaluate_confidence(60.0, thresholds) == ConfidenceLevel.APPROVAL_REQUIRED
        assert evaluate_confidence(59.0, thresholds) == ConfidenceLevel.BLOCKED

    def test_boundary_values(self):
        thresholds = ConfidenceThresholds(autonomous=85, notify=70, approval=40)
        assert evaluate_confidence(84.99, thresholds) == ConfidenceLevel.NOTIFY
        assert evaluate_confidence(85.0, thresholds) == ConfidenceLevel.AUTONOMOUS
        assert evaluate_confidence(69.99, thresholds) == ConfidenceLevel.APPROVAL_REQUIRED
        assert evaluate_confidence(70.0, thresholds) == ConfidenceLevel.NOTIFY


class TestConfidenceThresholds:
    def test_defaults(self):
        t = ConfidenceThresholds()
        assert t.autonomous == 85.0
        assert t.notify == 70.0
        assert t.approval == 40.0

    def test_invalid_order_raises(self):
        with pytest.raises(ValueError, match="approval <= notify <= autonomous"):
            ConfidenceThresholds(autonomous=50, notify=80, approval=90)

    def test_negative_raises(self):
        with pytest.raises(ValueError, match="non-negative"):
            ConfidenceThresholds(autonomous=90, notify=70, approval=-5)

    def test_frozen(self):
        t = ConfidenceThresholds()
        with pytest.raises(AttributeError):
            t.autonomous = 99  # type: ignore[misc]


class TestConfidenceGate:
    def test_evaluate_default(self):
        gate = ConfidenceGate()
        assert gate.evaluate(90.0) == ConfidenceLevel.AUTONOMOUS
        assert gate.evaluate(75.0) == ConfidenceLevel.NOTIFY
        assert gate.evaluate(50.0) == ConfidenceLevel.APPROVAL_REQUIRED

    def test_evaluate_blocked_no_block_below(self):
        gate = ConfidenceGate()
        # With no block_below set, low scores still return a level
        assert gate.evaluate(10.0) == ConfidenceLevel.BLOCKED

    def test_evaluate_raises_when_block_below(self):
        gate = ConfidenceGate(block_below=50.0)
        with pytest.raises(NovaConfidenceError) as exc_info:
            gate.evaluate(30.0)
        assert exc_info.value.score == 30.0
        assert exc_info.value.threshold == 50.0

    def test_require_autonomous(self):
        gate = ConfidenceGate()
        gate.require_autonomous(90.0)  # Should not raise

    def test_require_autonomous_raises(self):
        gate = ConfidenceGate()
        with pytest.raises(NovaConfidenceError):
            gate.require_autonomous(70.0)

    def test_is_autonomous(self):
        gate = ConfidenceGate()
        assert gate.is_autonomous(90.0) is True
        assert gate.is_autonomous(70.0) is False
        assert gate.is_autonomous(30.0) is False

    def test_needs_approval(self):
        gate = ConfidenceGate()
        assert gate.needs_approval(50.0) is True
        assert gate.needs_approval(90.0) is False
        assert gate.needs_approval(30.0) is False  # BLOCKED, not APPROVAL_REQUIRED

    def test_custom_thresholds(self):
        gate = ConfidenceGate(
            thresholds=ConfidenceThresholds(autonomous=95, notify=80, approval=60)
        )
        assert gate.is_autonomous(96.0) is True
        assert gate.is_autonomous(90.0) is False
