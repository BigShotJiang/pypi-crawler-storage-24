from __future__ import annotations

from novalab_adk import NovaClient
from novalab_adk.resources.agents import AgentsResource
from novalab_adk.resources.automations import AutomationsResource
from novalab_adk.resources.connections import ConnectionsResource
from novalab_adk.resources.data import DataResource
from novalab_adk.resources.history import HistoryResource
from novalab_adk.resources.signals import SignalsResource
from novalab_adk.resources.webhooks import WebhooksResource
from novalab_adk.resources.workflows import WorkflowsResource


class TestNovaClient:
    def test_initializes_with_required_args(self):
        client = NovaClient(api_key="test-key")
        assert client is not None

    def test_exposes_all_resources(self):
        client = NovaClient(api_key="test-key")
        assert isinstance(client.agents, AgentsResource)
        assert isinstance(client.workflows, WorkflowsResource)
        assert isinstance(client.signals, SignalsResource)
        assert isinstance(client.automations, AutomationsResource)
        assert isinstance(client.connections, ConnectionsResource)
        assert isinstance(client.data, DataResource)
        assert isinstance(client.history, HistoryResource)
        assert isinstance(client.webhooks, WebhooksResource)

    def test_default_region(self):
        client = NovaClient(api_key="test-key")
        assert client._http._region == "eu-west-1"

    def test_custom_region(self):
        client = NovaClient(api_key="test-key", region="us-east-1")
        assert client._http._region == "us-east-1"

    def test_custom_base_url(self):
        client = NovaClient(
            api_key="test-key",
            base_url="https://custom.api.novalab.build/v1",
        )
        assert "custom.api.novalab.build" in client._http._base_url

    def test_custom_timeout(self):
        client = NovaClient(api_key="test-key", timeout=60.0)
        assert client._http._timeout == 60.0
