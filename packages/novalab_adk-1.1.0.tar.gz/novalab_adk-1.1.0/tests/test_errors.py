from __future__ import annotations

import pytest

from novalab_adk.core.errors import (
    NovaAPIError,
    NovaAuthError,
    NovaConfidenceError,
    NovaError,
    NovaRateLimitError,
    NovaTimeoutError,
    NovaValidationError,
)


class TestNovaError:
    def test_is_exception(self):
        err = NovaError("test")
        assert isinstance(err, Exception)
        assert isinstance(err, NovaError)

    def test_message(self):
        err = NovaError("something went wrong")
        assert err.message == "something went wrong"
        assert str(err) == "something went wrong"

    def test_repr(self):
        err = NovaError("test")
        assert "NovaError" in repr(err)
        assert "test" in repr(err)


class TestNovaAPIError:
    def test_carries_fields(self):
        err = NovaAPIError(400, "bad_request", "Invalid input", "req-123")
        assert isinstance(err, NovaError)
        assert err.status_code == 400
        assert err.code == "bad_request"
        assert err.message == "Invalid input"
        assert err.request_id == "req-123"

    def test_optional_request_id(self):
        err = NovaAPIError(500, "server_error", "Failed")
        assert err.request_id is None

    def test_repr(self):
        err = NovaAPIError(400, "bad_request", "Invalid", "req-1")
        r = repr(err)
        assert "400" in r
        assert "bad_request" in r
        assert "req-1" in r


class TestNovaAuthError:
    def test_defaults(self):
        err = NovaAuthError()
        assert isinstance(err, NovaAPIError)
        assert err.status_code == 401
        assert err.code == "auth_error"
        assert err.message == "Authentication failed"

    def test_custom_message(self):
        err = NovaAuthError("Token expired", "req-456")
        assert err.message == "Token expired"
        assert err.request_id == "req-456"


class TestNovaRateLimitError:
    def test_carries_retry_after(self):
        err = NovaRateLimitError(retry_after=30.0)
        assert isinstance(err, NovaAPIError)
        assert err.status_code == 429
        assert err.retry_after == 30.0
        assert err.code == "rate_limit_exceeded"

    def test_repr(self):
        err = NovaRateLimitError(retry_after=60.0, message="Slow down")
        assert "60.0" in repr(err)


class TestNovaValidationError:
    def test_is_nova_error(self):
        err = NovaValidationError("Name is required")
        assert isinstance(err, NovaError)
        assert err.message == "Name is required"


class TestNovaTimeoutError:
    def test_default_message(self):
        err = NovaTimeoutError()
        assert isinstance(err, NovaError)
        assert err.message == "Request timed out"

    def test_custom_message(self):
        err = NovaTimeoutError("Connection timed out after 30s")
        assert "30s" in err.message


class TestNovaConfidenceError:
    def test_carries_score_and_threshold(self):
        err = NovaConfidenceError(score=35.0, threshold=50.0)
        assert isinstance(err, NovaError)
        assert err.score == 35.0
        assert err.threshold == 50.0
        assert "35.0" in str(err)
        assert "50.0" in str(err)

    def test_repr(self):
        err = NovaConfidenceError(score=42.0, threshold=70.0)
        r = repr(err)
        assert "42.0" in r
        assert "70.0" in r


class TestErrorHierarchy:
    def test_isinstance_chain(self):
        err = NovaAuthError()
        assert isinstance(err, Exception)
        assert isinstance(err, NovaError)
        assert isinstance(err, NovaAPIError)
        assert isinstance(err, NovaAuthError)
        assert not isinstance(err, NovaRateLimitError)

    def test_except_catches_parent(self):
        with pytest.raises(NovaError):
            raise NovaAuthError()

        with pytest.raises(NovaAPIError):
            raise NovaAuthError()
