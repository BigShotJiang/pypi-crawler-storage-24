from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .envelope import Envelope

@dataclass
class DeadLetterEnvelope(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The envelope property
    envelope: Optional[Envelope] = None
    # The exceptionMessage property
    exception_message: Optional[str] = None
    # The exceptionType property
    exception_type: Optional[str] = None
    # The executionTime property
    execution_time: Optional[datetime.datetime] = None
    # The id property
    id: Optional[UUID] = None
    # The messageType property
    message_type: Optional[str] = None
    # The receivedAt property
    received_at: Optional[str] = None
    # The replayable property
    replayable: Optional[bool] = None
    # The sentAt property
    sent_at: Optional[datetime.datetime] = None
    # The source property
    source: Optional[str] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DeadLetterEnvelope:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DeadLetterEnvelope
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DeadLetterEnvelope()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .envelope import Envelope

        from .envelope import Envelope

        fields: dict[str, Callable[[Any], None]] = {
            "envelope": lambda n : setattr(self, 'envelope', n.get_object_value(Envelope)),
            "exceptionMessage": lambda n : setattr(self, 'exception_message', n.get_str_value()),
            "exceptionType": lambda n : setattr(self, 'exception_type', n.get_str_value()),
            "executionTime": lambda n : setattr(self, 'execution_time', n.get_datetime_value()),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "messageType": lambda n : setattr(self, 'message_type', n.get_str_value()),
            "receivedAt": lambda n : setattr(self, 'received_at', n.get_str_value()),
            "replayable": lambda n : setattr(self, 'replayable', n.get_bool_value()),
            "sentAt": lambda n : setattr(self, 'sent_at', n.get_datetime_value()),
            "source": lambda n : setattr(self, 'source', n.get_str_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_object_value("envelope", self.envelope)
        writer.write_str_value("exceptionMessage", self.exception_message)
        writer.write_str_value("exceptionType", self.exception_type)
        writer.write_datetime_value("executionTime", self.execution_time)
        writer.write_uuid_value("id", self.id)
        writer.write_str_value("messageType", self.message_type)
        writer.write_str_value("receivedAt", self.received_at)
        writer.write_bool_value("replayable", self.replayable)
        writer.write_datetime_value("sentAt", self.sent_at)
        writer.write_str_value("source", self.source)
        writer.write_additional_data_value(self.additional_data)
    

