from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union

@dataclass
class DeadLetterEnvelopeGetRequest(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The databaseUri property
    database_uri: Optional[str] = None
    # The exceptionMessage property
    exception_message: Optional[str] = None
    # The exceptionType property
    exception_type: Optional[str] = None
    # The from property
    from_: Optional[datetime.datetime] = None
    # The limit property
    limit: Optional[int] = None
    # The messageType property
    message_type: Optional[str] = None
    # The pageNumber property
    page_number: Optional[int] = None
    # The tenantId property
    tenant_id: Optional[str] = None
    # The until property
    until: Optional[datetime.datetime] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> DeadLetterEnvelopeGetRequest:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: DeadLetterEnvelopeGetRequest
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return DeadLetterEnvelopeGetRequest()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        fields: dict[str, Callable[[Any], None]] = {
            "databaseUri": lambda n : setattr(self, 'database_uri', n.get_str_value()),
            "exceptionMessage": lambda n : setattr(self, 'exception_message', n.get_str_value()),
            "exceptionType": lambda n : setattr(self, 'exception_type', n.get_str_value()),
            "from": lambda n : setattr(self, 'from_', n.get_datetime_value()),
            "limit": lambda n : setattr(self, 'limit', n.get_int_value()),
            "messageType": lambda n : setattr(self, 'message_type', n.get_str_value()),
            "pageNumber": lambda n : setattr(self, 'page_number', n.get_int_value()),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_str_value()),
            "until": lambda n : setattr(self, 'until', n.get_datetime_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_str_value("databaseUri", self.database_uri)
        writer.write_str_value("exceptionMessage", self.exception_message)
        writer.write_str_value("exceptionType", self.exception_type)
        writer.write_datetime_value("from", self.from_)
        writer.write_int_value("limit", self.limit)
        writer.write_str_value("messageType", self.message_type)
        writer.write_int_value("pageNumber", self.page_number)
        writer.write_str_value("tenantId", self.tenant_id)
        writer.write_datetime_value("until", self.until)
        writer.write_additional_data_value(self.additional_data)
    

