from __future__ import annotations
import datetime
from collections.abc import Callable
from dataclasses import dataclass, field
from kiota_abstractions.serialization import AdditionalDataHolder, Parsable, ParseNode, SerializationWriter
from typing import Any, Optional, TYPE_CHECKING, Union
from uuid import UUID

if TYPE_CHECKING:
    from .envelope_headers import Envelope_headers

@dataclass
class Envelope(AdditionalDataHolder, Parsable):
    # Stores additional data not described in the OpenAPI description found when deserializing. Can be used for serialization as well.
    additional_data: dict[str, Any] = field(default_factory=dict)

    # The acceptedContentTypes property
    accepted_content_types: Optional[list[str]] = None
    # The ackRequested property
    ack_requested: Optional[bool] = None
    # The attempts property
    attempts: Optional[int] = None
    # The contentType property
    content_type: Optional[str] = None
    # The conversationId property
    conversation_id: Optional[UUID] = None
    # The correlationId property
    correlation_id: Optional[str] = None
    # The data property
    data: Optional[bytes] = None
    # The deduplicationId property
    deduplication_id: Optional[str] = None
    # The deliverBy property
    deliver_by: Optional[datetime.datetime] = None
    # The destination property
    destination: Optional[str] = None
    # The endpointName property
    endpoint_name: Optional[str] = None
    # The groupId property
    group_id: Optional[str] = None
    # The headers property
    headers: Optional[Envelope_headers] = None
    # The id property
    id: Optional[UUID] = None
    # The keepUntil property
    keep_until: Optional[datetime.datetime] = None
    # The messageType property
    message_type: Optional[str] = None
    # The offset property
    offset: Optional[int] = None
    # The parentId property
    parent_id: Optional[str] = None
    # The partitionKey property
    partition_key: Optional[str] = None
    # The replyRequested property
    reply_requested: Optional[str] = None
    # The replyUri property
    reply_uri: Optional[str] = None
    # The sagaId property
    saga_id: Optional[str] = None
    # The scheduleDelay property
    schedule_delay: Optional[str] = None
    # The scheduledTime property
    scheduled_time: Optional[datetime.datetime] = None
    # The sendAttempts property
    send_attempts: Optional[int] = None
    # The sentAt property
    sent_at: Optional[datetime.datetime] = None
    # The source property
    source: Optional[str] = None
    # The tenantId property
    tenant_id: Optional[str] = None
    # The topicName property
    topic_name: Optional[str] = None
    # The userName property
    user_name: Optional[str] = None
    # The wasPersistedInOutbox property
    was_persisted_in_outbox: Optional[bool] = None
    
    @staticmethod
    def create_from_discriminator_value(parse_node: ParseNode) -> Envelope:
        """
        Creates a new instance of the appropriate class based on discriminator value
        param parse_node: The parse node to use to read the discriminator value and create the object
        Returns: Envelope
        """
        if parse_node is None:
            raise TypeError("parse_node cannot be null.")
        return Envelope()
    
    def get_field_deserializers(self,) -> dict[str, Callable[[ParseNode], None]]:
        """
        The deserialization information for the current model
        Returns: dict[str, Callable[[ParseNode], None]]
        """
        from .envelope_headers import Envelope_headers

        from .envelope_headers import Envelope_headers

        fields: dict[str, Callable[[Any], None]] = {
            "acceptedContentTypes": lambda n : setattr(self, 'accepted_content_types', n.get_collection_of_primitive_values(str)),
            "ackRequested": lambda n : setattr(self, 'ack_requested', n.get_bool_value()),
            "attempts": lambda n : setattr(self, 'attempts', n.get_int_value()),
            "contentType": lambda n : setattr(self, 'content_type', n.get_str_value()),
            "conversationId": lambda n : setattr(self, 'conversation_id', n.get_uuid_value()),
            "correlationId": lambda n : setattr(self, 'correlation_id', n.get_str_value()),
            "data": lambda n : setattr(self, 'data', n.get_bytes_value()),
            "deduplicationId": lambda n : setattr(self, 'deduplication_id', n.get_str_value()),
            "deliverBy": lambda n : setattr(self, 'deliver_by', n.get_datetime_value()),
            "destination": lambda n : setattr(self, 'destination', n.get_str_value()),
            "endpointName": lambda n : setattr(self, 'endpoint_name', n.get_str_value()),
            "groupId": lambda n : setattr(self, 'group_id', n.get_str_value()),
            "headers": lambda n : setattr(self, 'headers', n.get_object_value(Envelope_headers)),
            "id": lambda n : setattr(self, 'id', n.get_uuid_value()),
            "keepUntil": lambda n : setattr(self, 'keep_until', n.get_datetime_value()),
            "messageType": lambda n : setattr(self, 'message_type', n.get_str_value()),
            "offset": lambda n : setattr(self, 'offset', n.get_int_value()),
            "parentId": lambda n : setattr(self, 'parent_id', n.get_str_value()),
            "partitionKey": lambda n : setattr(self, 'partition_key', n.get_str_value()),
            "replyRequested": lambda n : setattr(self, 'reply_requested', n.get_str_value()),
            "replyUri": lambda n : setattr(self, 'reply_uri', n.get_str_value()),
            "sagaId": lambda n : setattr(self, 'saga_id', n.get_str_value()),
            "scheduleDelay": lambda n : setattr(self, 'schedule_delay', n.get_str_value()),
            "scheduledTime": lambda n : setattr(self, 'scheduled_time', n.get_datetime_value()),
            "sendAttempts": lambda n : setattr(self, 'send_attempts', n.get_int_value()),
            "sentAt": lambda n : setattr(self, 'sent_at', n.get_datetime_value()),
            "source": lambda n : setattr(self, 'source', n.get_str_value()),
            "tenantId": lambda n : setattr(self, 'tenant_id', n.get_str_value()),
            "topicName": lambda n : setattr(self, 'topic_name', n.get_str_value()),
            "userName": lambda n : setattr(self, 'user_name', n.get_str_value()),
            "wasPersistedInOutbox": lambda n : setattr(self, 'was_persisted_in_outbox', n.get_bool_value()),
        }
        return fields
    
    def serialize(self,writer: SerializationWriter) -> None:
        """
        Serializes information the current object
        param writer: Serialization writer to use to serialize this model
        Returns: None
        """
        if writer is None:
            raise TypeError("writer cannot be null.")
        writer.write_collection_of_primitive_values("acceptedContentTypes", self.accepted_content_types)
        writer.write_bool_value("ackRequested", self.ack_requested)
        writer.write_int_value("attempts", self.attempts)
        writer.write_str_value("contentType", self.content_type)
        writer.write_uuid_value("conversationId", self.conversation_id)
        writer.write_str_value("correlationId", self.correlation_id)
        writer.write_bytes_value("data", self.data)
        writer.write_str_value("deduplicationId", self.deduplication_id)
        writer.write_datetime_value("deliverBy", self.deliver_by)
        writer.write_str_value("destination", self.destination)
        writer.write_str_value("endpointName", self.endpoint_name)
        writer.write_str_value("groupId", self.group_id)
        writer.write_object_value("headers", self.headers)
        writer.write_uuid_value("id", self.id)
        writer.write_datetime_value("keepUntil", self.keep_until)
        writer.write_str_value("messageType", self.message_type)
        writer.write_int_value("offset", self.offset)
        writer.write_str_value("parentId", self.parent_id)
        writer.write_str_value("partitionKey", self.partition_key)
        writer.write_str_value("replyRequested", self.reply_requested)
        writer.write_str_value("replyUri", self.reply_uri)
        writer.write_str_value("sagaId", self.saga_id)
        writer.write_str_value("scheduleDelay", self.schedule_delay)
        writer.write_datetime_value("scheduledTime", self.scheduled_time)
        writer.write_int_value("sendAttempts", self.send_attempts)
        writer.write_datetime_value("sentAt", self.sent_at)
        writer.write_str_value("source", self.source)
        writer.write_str_value("tenantId", self.tenant_id)
        writer.write_str_value("topicName", self.topic_name)
        writer.write_str_value("userName", self.user_name)
        writer.write_bool_value("wasPersistedInOutbox", self.was_persisted_in_outbox)
        writer.write_additional_data_value(self.additional_data)
    

