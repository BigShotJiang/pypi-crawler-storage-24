"""
Playwright-EZ: A simplified Playwright wrapper
支持多标签页操作、元素高亮、智能等待、网络拦截、反检测等

功能模块:
- browser: 浏览器核心操作（多标签页）
- wait: 智能等待
- highlight: 元素高亮
- selector: 智能选择器
- session: Cookie & Session管理
- network: 网络监控 & 拦截
- file_handler: 文件操作
- anti_detection: 反检测
- form: 表单处理
- pom: 页面对象模型
- performance: 性能分析
- mobile: 移动端模拟
- visual: 视觉测试
- recorder: 操作录制回放
"""

from .browser import EasyBrowser, Tab
from .wait import SmartWait, WaitCondition
from .highlight import ElementHighlighter
from .config import Config, get_config, set_config
from .selector import SmartSelector, SelectorType
from .element import Element, ElementList
from .relative import RelativeLocator
from .profile import BrowserProfile, ProfileManager
from .dual_engine import DualEngine, DualEngineResponse, DualEngineContext
from .session import CookieManager, SessionManager
from .network import NetworkMonitor, NetworkInterceptor, BlockResources
from .file_handler import FileHandler, BatchUploader, DownloadResult
from .anti_detection import AntiDetection, HumanBehavior
from .form import FormHandler, FieldInfo
from .pom import (
    BasePage,
    PageElement,
    PageFactory,
    PageRegistry,
    element,
    step,
)
from .performance import (
    PerformanceAnalyzer,
    PerformanceMetric,
    ResourceTiming,
    PageLoadMetrics,
    PerformanceBudget,
)
from .mobile import (
    DeviceEmulator,
    DeviceConfig,
    DEVICES,
    Geolocation,
    NetworkCondition,
    MobileHelper,
)
from .visual import (
    VisualTester,
    ScreenshotManager,
    ScreenshotDiff,
    ScreenshotAnnotator,
    VisualReporter,
)
from .recorder import (
    ActionRecorder,
    ActionPlayer,
    CodeGenerator,
    RecordingSession,
    RecordedAction,
    ActionType,
)
from .debug import (
    Debugger,
    DebugInfo,
    retry_on_error,
    ErrorHandler,
    AssertionHelper,
)
from .extract import (
    DataExtractor,
    ExtractionRule,
    ExtractionResult,
    ScraperTemplate,
    PaginationExtractor,
    DynamicContentExtractor,
    FormDataExtractor,
    SmartScraper,
    DataExporter,
    save_to_json,
    save_to_csv,
)
from .api import (
    APIClient,
    APIRequest,
    APIResponse,
    HttpMethod,
    APITestSuite,
    ResponseValidator,
    MockServer,
    GraphQLClient,
)
from .websocket import (
    WebSocketMonitor,
    WebSocketInterceptor,
    WebSocketReplay,
    WSMessage,
    WSConnection,
    WSMessageType,
)
from .utils import (
    # 字符串工具
    random_string,
    random_email,
    random_phone,
    random_password,
    mask_sensitive,
    truncate,
    extract_numbers,
    extract_urls,
    extract_emails,
    extract_phones,
    to_snake_case,
    to_camel_case,
    to_kebab_case,
    # 编码工具
    base64_encode,
    base64_decode,
    md5_hash,
    sha256_hash,
    url_encode,
    url_decode,
    # 时间工具
    now_str,
    timestamp,
    timestamp_ms,
    parse_datetime,
    time_ago,
    # 文件工具
    ensure_dir,
    read_file,
    write_file,
    read_json,
    write_json,
    file_size,
    file_size_human,
    # 验证工具
    is_valid_email,
    is_valid_phone,
    is_valid_url,
    is_valid_id_card,
    is_json,
    # 转换工具
    deep_get,
    deep_set,
    flatten_dict,
    unflatten_dict,
    list_to_dict,
    group_by,
    # 重试等待
    wait_for,
    retry,
    # 装饰器
    timer,
    catch_errors,
)
from .pytest_plugin import (
    TestContext,
    browser_test,
    visual_test,
    retry_flaky,
    TestReport,
)
from .cli import CLI, main
from .advanced import (
    BatchOperations,
    AutomationFlow,
    TabManager,
    SessionRecorder,
    DownloadTask,
)
from .captcha import (
    CaptchaHandler,
    CaptchaResult,
    SMSHandler,
)
from .generator import (
    DataGenerator,
    get_generator,
    fake_name,
    fake_email,
    fake_phone,
    fake_address,
    fake_user,
    fake_users,
    fake_product,
    fake_order,
)
from .report import (
    TestReportBuilder,
    PerformanceReport,
    CoverageReport,
)
from .database import (
    DatabaseManager,
    DatabaseConfig,
    create_sqlite_db,
)
from .environment import (
    Environment,
    EnvironmentManager,
    ConfigManager,
    SecretsManager,
    get_config as get_env_config,
    set_config as set_env_config,
    get_secret,
)
from .state import (
    PageStateManager,
    PageSnapshot,
    PageHistory,
    NavigationHelper,
)
from .assertions import Assert
from .scheduler import (
    TaskScheduler,
    ScheduledTask,
    TaskStatus,
    IntervalTask,
    DelayedTask,
    CRON_EXPRESSIONS,
)
from .extensions import (
    ExtensionManager,
    AdBlocker,
    PrivacyProtector,
    CookieConsentHandler,
)
from .ai import (
    SmartElementFinder,
    PageAnalyzer,
    AutoHealer,
    ContentAnalyzer,
    # AI 辅助主类
    AIHelper,
    AIConfig,
    SelectorSuggestion,
    ErrorDiagnosis,
    CodeSuggestion,
    create_ai_helper,
    # LLM 配置
    LLMConfig,
    LLMProvider,
    # LLM 提供商
    BaseLLMProvider,
    LLMResponse,
    create_llm_provider,
    ClaudeProvider,
    OpenAIProvider,
    OllamaProvider,
    CustomProvider,
    # 引擎
    BaseEngine,
    RuleEngine,
    HybridEngine,
)
from .concurrent import (
    ConcurrentRunner,
    LoadTester,
    LoadTestResult,
    PerformanceMonitor,
    Benchmark,
    # 浏览器池
    BrowserPool,
    BrowserPoolConfig,
    BrowserInstance,
    # 任务队列
    TaskQueue,
    TaskQueueConfig,
    QueueTask,
    TaskStatus,
    # 重试执行器
    RetryExecutor,
    RetryConfig,
    RetryResult,
)
from .tracing import (
    TraceCollector,
    TraceEvent,
    ActionLogger,
    PerformanceLogger,
    ErrorTracker,
    StepReporter,
)
from .presets import (
    get_preset,
    list_presets,
    create_custom_preset,
    get_scenario_config,
    get_browser_args,
    PRESETS,
    SCENARIO_PRESETS,
    BROWSER_ARGS,
)
from .quick import (
    QuickActions,
    quick_goto,
    quick_click,
    quick_type,
    quick_screenshot,
)
from .context import (
    ContextProfile,
    ContextManager,
    IsolatedSession,
    MultiUserSession,
    SessionPool,
)
from .recovery import (
    SmartRecovery,
    RecoveryAction,
    auto_recovery,
    ErrorClassifier,
    RecoveryStrategies,
    ErrorHandlerChain,
    GracefulDegradation,
)
from .popup import (
    PopupHandler,
    auto_close_popup,
    smart_close_popup,
)
from .automation import (
    # 无限滚动
    InfiniteScrollHandler,
    InfiniteScrollConfig,
    InfiniteScrollResult,
    # 分页导航
    PaginationNavigator,
    PaginationConfig,
    PaginationResult,
    # iframe 管理
    IframeManager,
    IframeInfo,
    # 拖拽操作
    DragDropHelper,
    DragConfig,
    DragResult,
    # 文件管理
    FileManager,
    FileResult,
    UploadConfig,
    DownloadConfig,
)
from .diagnostics import (
    # 控制台监控
    ConsoleMonitor,
    ConsoleLogEntry,
    ConsoleMonitorConfig,
    ConsoleMonitorResult,
    # 错误分析
    ErrorAnalyzer,
    ErrorAnalysisResult,
    ErrorLocation,
    # 页面快照
    PageSnapshot,
    SnapshotConfig,
    SnapshotResult,
    DiffResult,
)
from .scraper import (
    # 限流器
    RateLimiter,
    RateLimiterConfig,
    RateLimiterStats,
    # 数据验证
    DataValidator,
    DataValidatorConfig,
    ValidationRule,
    FieldValidation,
    ValidationResult,
    BuiltInRules,
)
from .test_helpers import (
    # 可访问性检查
    AccessibilityChecker,
    AccessibilityCheckResult,
    AccessibilityCheckConfig,
    AccessibilityViolation,
)
from .monitoring import (
    # SEO 检查
    SEOChecker,
    SEOCheckResult,
    SEOReport,
)
from .security import (
    # 安全扫描
    SecurityScanner,
    SecurityScanResult,
    SecurityIssue,
    # XSS 检测
    XSSDetector,
    XSSConfig,
    XSSIssue,
    XSSScanResult,
    # Header 检查
    HeaderChecker,
    HeaderCheckConfig,
    HeaderCheckResult,
    HeaderIssue,
)
# 浏览器辅助类
from .browser_helpers import (
    AutomationHelper,
    DiagnosticsHelper,
    ScraperHelper,
    TestHelper,
    MonitoringHelper,
    SecurityHelper,
)

__version__ = "2.4.0"
__all__ = [
    # 核心
    "EasyBrowser",
    "Tab",
    "Config",
    "get_config",
    "set_config",

    # 元素代理
    "Element",
    "ElementList",
    "RelativeLocator",

    # 配置持久化
    "BrowserProfile",
    "ProfileManager",

    # 双引擎模式
    "DualEngine",
    "DualEngineResponse",
    "DualEngineContext",

    # 等待
    "SmartWait",
    "WaitCondition",

    # 高亮
    "ElementHighlighter",

    # 选择器
    "SmartSelector",
    "SelectorType",
    
    # 会话
    "CookieManager",
    "SessionManager",
    
    # 网络
    "NetworkMonitor",
    "NetworkInterceptor",
    "BlockResources",
    
    # 文件
    "FileHandler",
    "BatchUploader",
    "DownloadResult",
    
    # 反检测
    "AntiDetection",
    "HumanBehavior",
    
    # 表单
    "FormHandler",
    "FieldInfo",
    
    # POM
    "BasePage",
    "PageElement",
    "PageFactory",
    "PageRegistry",
    "element",
    "step",
    
    # 性能
    "PerformanceAnalyzer",
    "PerformanceMetric",
    "ResourceTiming",
    "PageLoadMetrics",
    "PerformanceBudget",
    
    # 移动端
    "DeviceEmulator",
    "DeviceConfig",
    "DEVICES",
    "Geolocation",
    "NetworkCondition",
    "MobileHelper",
    
    # 视觉测试
    "VisualTester",
    "ScreenshotManager",
    "ScreenshotDiff",
    "ScreenshotAnnotator",
    "VisualReporter",
    
    # 录制回放
    "ActionRecorder",
    "ActionPlayer",
    "CodeGenerator",
    "RecordingSession",
    "RecordedAction",
    "ActionType",
    
    # 调试
    "Debugger",
    "DebugInfo",
    "retry_on_error",
    "ErrorHandler",
    "AssertionHelper",
    
    # 数据提取
    "DataExtractor",
    "ExtractionRule",
    "ExtractionResult",
    "ScraperTemplate",
    "PaginationExtractor",
    "DynamicContentExtractor",
    "FormDataExtractor",
    "SmartScraper",
    "DataExporter",
    "save_to_json",
    "save_to_csv",
    
    # API测试
    "APIClient",
    "APIRequest",
    "APIResponse",
    "HttpMethod",
    "APITestSuite",
    "ResponseValidator",
    "MockServer",
    "GraphQLClient",
    
    # WebSocket
    "WebSocketMonitor",
    "WebSocketInterceptor",
    "WebSocketReplay",
    "WSMessage",
    "WSConnection",
    "WSMessageType",
    
    # 工具函数
    "random_string",
    "random_email",
    "random_phone",
    "random_password",
    "mask_sensitive",
    "truncate",
    "extract_numbers",
    "extract_urls",
    "extract_emails",
    "extract_phones",
    "to_snake_case",
    "to_camel_case",
    "to_kebab_case",
    "base64_encode",
    "base64_decode",
    "md5_hash",
    "sha256_hash",
    "url_encode",
    "url_decode",
    "now_str",
    "timestamp",
    "timestamp_ms",
    "parse_datetime",
    "time_ago",
    "ensure_dir",
    "read_file",
    "write_file",
    "read_json",
    "write_json",
    "file_size",
    "file_size_human",
    "is_valid_email",
    "is_valid_phone",
    "is_valid_url",
    "is_valid_id_card",
    "is_json",
    "deep_get",
    "deep_set",
    "flatten_dict",
    "unflatten_dict",
    "list_to_dict",
    "group_by",
    "wait_for",
    "retry",
    "timer",
    "catch_errors",

    # 弹窗处理
    "PopupHandler",
    "auto_close_popup",
    "smart_close_popup",

    # 自动化增强
    "InfiniteScrollHandler",
    "InfiniteScrollConfig",
    "InfiniteScrollResult",
    "PaginationNavigator",
    "PaginationConfig",
    "PaginationResult",
    "IframeManager",
    "IframeInfo",
    "DragDropHelper",
    "DragConfig",
    "DragResult",
    "FileManager",
    "FileResult",
    "UploadConfig",
    "DownloadConfig",

    # 诊断模块
    "ConsoleMonitor",
    "ConsoleLogEntry",
    "ConsoleMonitorConfig",
    "ConsoleMonitorResult",
    "ErrorAnalyzer",
    "ErrorAnalysisResult",
    "ErrorLocation",

    # 数据采集
    "RateLimiter",
    "RateLimiterConfig",
    "RateLimiterStats",
    "DataValidator",
    "DataValidatorConfig",
    "ValidationRule",
    "FieldValidation",
    "ValidationResult",
    "BuiltInRules",

    # 测试辅助
    "AccessibilityChecker",
    "AccessibilityCheckResult",
    "AccessibilityCheckConfig",
    "AccessibilityViolation",

    # 监控模块
    "SEOChecker",
    "SEOCheckResult",
    "SEOReport",

    # 安全模块
    "SecurityScanner",
    "SecurityScanResult",
    "SecurityIssue",

    # 浏览器辅助类
    "AutomationHelper",
    "DiagnosticsHelper",
    "ScraperHelper",
    "TestHelper",
    "MonitoringHelper",
    "SecurityHelper",

    # AI 辅助模块
    "AIHelper",
    "AIConfig",
    "SelectorSuggestion",
    "ErrorDiagnosis",
    "CodeSuggestion",
    "create_ai_helper",
    "SmartElementFinder",
    "PageAnalyzer",
    "ContentAnalyzer",
    "AutoHealer",
    # LLM 配置
    "LLMConfig",
    "LLMProvider",
    # LLM 提供商
    "BaseLLMProvider",
    "LLMResponse",
    "create_llm_provider",
    "ClaudeProvider",
    "OpenAIProvider",
    "OllamaProvider",
    "CustomProvider",
    # 引擎
    "BaseEngine",
    "RuleEngine",
    "HybridEngine",
]
