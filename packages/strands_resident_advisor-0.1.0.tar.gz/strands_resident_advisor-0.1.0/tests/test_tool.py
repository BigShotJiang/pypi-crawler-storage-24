"""Tests for use_resident_advisor tool."""

from unittest.mock import MagicMock, patch

from strands_resident_advisor.tool import (
    RA_GRAPHQL_URL,
    execute_ra_graphql,
    format_ra_response,
    use_resident_advisor,
)


class TestExecuteRaGraphql:
    """Tests for the raw GraphQL execution function."""

    @patch("strands_resident_advisor.tool.requests.post")
    def test_sends_query(self, mock_post):
        mock_post.return_value = MagicMock(status_code=200, json=lambda: {"data": {"areas": []}})
        result = execute_ra_graphql('{ areas(searchTerm: "berlin") { id } }')
        mock_post.assert_called_once()
        assert result == {"data": {"areas": []}}

    @patch("strands_resident_advisor.tool.requests.post")
    def test_sends_variables(self, mock_post):
        mock_post.return_value = MagicMock(status_code=200, json=lambda: {"data": {}})
        execute_ra_graphql("query($id: Int!) { event(id: $id) { title } }", {"id": 123})
        call_kwargs = mock_post.call_args
        assert call_kwargs.kwargs["json"]["variables"] == {"id": 123}

    @patch("strands_resident_advisor.tool.requests.post")
    def test_uses_correct_url(self, mock_post):
        mock_post.return_value = MagicMock(status_code=200, json=lambda: {"data": {}})
        execute_ra_graphql("{ __typename }")
        assert mock_post.call_args.args[0] == RA_GRAPHQL_URL


class TestFormatRaResponse:
    """Tests for response formatting."""

    def test_formats_data(self):
        result = format_ra_response({"data": {"venue": {"name": "Berghain"}}})
        assert "Berghain" in result

    def test_formats_errors(self):
        result = format_ra_response({"errors": [{"message": "Not found"}]})
        assert "Not found" in result

    def test_formats_both(self):
        result = format_ra_response({"errors": [{"message": "warn"}], "data": {"x": 1}})
        assert "warn" in result
        assert '"x": 1' in result


class TestUseResidentAdvisor:
    """Tests for the main tool function."""

    @patch("strands_resident_advisor.tool.execute_ra_graphql")
    def test_success(self, mock_exec):
        mock_exec.return_value = {"data": {"areas": [{"id": 34, "name": "Berlin"}]}}
        result = use_resident_advisor(query='{ areas(searchTerm: "berlin") { id name } }')
        assert result["status"] == "success"
        assert "Berlin" in result["content"][0]["text"]

    @patch("strands_resident_advisor.tool.execute_ra_graphql")
    def test_graphql_error(self, mock_exec):
        mock_exec.return_value = {"errors": [{"message": "bad query"}]}
        result = use_resident_advisor(query="{ invalid }")
        assert result["status"] == "error"
        assert "bad query" in result["content"][0]["text"]

    @patch("strands_resident_advisor.tool.execute_ra_graphql")
    def test_request_exception(self, mock_exec):
        from requests.exceptions import ConnectionError

        mock_exec.side_effect = ConnectionError("timeout")
        result = use_resident_advisor(query="{ __typename }")
        assert result["status"] == "error"
        assert "timeout" in result["content"][0]["text"]

    @patch("strands_resident_advisor.tool.execute_ra_graphql")
    def test_default_variables(self, mock_exec):
        mock_exec.return_value = {"data": {}}
        use_resident_advisor(query="{ __typename }")
        mock_exec.assert_called_once_with("{ __typename }", {})
