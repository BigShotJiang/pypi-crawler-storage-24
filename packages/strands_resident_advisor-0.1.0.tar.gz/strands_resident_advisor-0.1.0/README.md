<div align="center">
  <div>
    <a href="https://strandsagents.com">
      <img src="https://strandsagents.com/latest/assets/logo-github.svg" alt="Strands Agents" width="55px" height="105px">
    </a>
  </div>
  <h1>Strands Resident Advisor</h1>
  <h2>Query Resident Advisor's GraphQL API with Strands Agents.</h2>
  <p>
    <a href="https://strandsagents.com/">Documentation</a> ◆
    <a href="https://github.com/strands-agents/sdk-python">Python SDK</a> ◆
    <a href="https://github.com/strands-agents/tools">Tools</a> ◆
    <a href="https://strandsagents.com/latest/community/community-packages/">Community Packages</a>
  </p>
</div>

A [Strands Agents](https://github.com/strands-agents/sdk-python) tool that provides direct access to [Resident Advisor's](https://ra.co) public GraphQL API for querying electronic music events, artists, venues, and more. No authentication required.

## Installation

```bash
pip install strands-resident-advisor
```

## Quick start

```python
from strands import Agent
from strands_resident_advisor import use_resident_advisor

agent = Agent(tools=[use_resident_advisor])

agent("Find electronic music events in Berlin this weekend")
agent("Tell me about DJ Sprinkles")
agent("What's happening at Berghain?")
```

## What it does

The tool executes GraphQL queries against `ra.co/graphql`. The agent constructs the queries based on user intent — the tool just runs them.

Available queries include:
- `eventListings` — Search events with filters (area, date, genre, etc.)
- `event(id)` — Get event details
- `artist(slug)` — Get artist profile
- `venue(id)` — Get venue details
- `search(searchTerm)` — Universal search across events, artists, venues, promoters
- `areas(searchTerm)` — Look up area codes by city name

## Development

```bash
pip install -e ".[dev]"
hatch run prepare  # format, lint, typecheck, test
```

## License

Apache 2.0 — see [LICENSE](LICENSE) for details.
