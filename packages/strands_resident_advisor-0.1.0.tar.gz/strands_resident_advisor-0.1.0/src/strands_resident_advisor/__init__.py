"""Strands Resident Advisor - RA GraphQL API tool for Strands Agents."""

from strands_resident_advisor.tool import use_resident_advisor

__all__ = [
    "use_resident_advisor",
]
