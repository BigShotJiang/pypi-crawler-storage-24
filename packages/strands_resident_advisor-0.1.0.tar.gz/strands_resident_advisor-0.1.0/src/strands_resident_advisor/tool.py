"""Resident Advisor (ra.co) GraphQL API tool for Strands Agents.

Provides direct access to RA's public GraphQL API for querying electronic music
events, artists, venues, areas, and more. No authentication required.

The agent constructs GraphQL queries based on user intent — this tool just
executes them against ra.co/graphql.

Key queries available:
    - eventListings: Search events with filters (areas, dates, datePosted, genre, etc.)
    - event(id): Get detailed event info
    - artist(id, slug): Get artist profile
    - venue(id): Get venue details
    - search(searchTerm, indices): Universal search across artists/venues/events/promoters
    - areas(searchTerm): Look up area codes by city name
    - venues(areaId, limit, orderBy): List venues in an area

Filter fields for eventListings:
    - areas: {eq: INT} — RA area code (use areas query to look up)
    - listingDate: {gte: "ISO", lte: "ISO"} — event date range
    - eventDatePosted: {gte: "ISO", lte: "ISO"} — when event was published on RA
    - genre: {eq: "STRING"} — filter by genre
    - isTicketed: {eq: BOOL}
    - isSoldOut: {eq: BOOL}
    - isPick: {eq: BOOL} — RA editor picks

IndexType values for search: EVENT, ARTIST, CLUB, PROMOTER, LABEL, AREA

Usage:
    from strands import Agent
    from strands_resident_advisor import use_resident_advisor

    agent = Agent(tools=[use_resident_advisor])
    agent("Find electronic music events in NYC this weekend")
    agent("What events were recently posted in Berlin?")
    agent("Tell me about DJ Sprinkles")
"""

import json
import logging
from typing import Any

import requests
from strands import tool

logger = logging.getLogger(__name__)

RA_GRAPHQL_URL = "https://ra.co/graphql"

RA_HEADERS = {
    "Content-Type": "application/json",
    "Referer": "https://ra.co/events",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
}


def execute_ra_graphql(query: str, variables: dict[str, Any] | None = None) -> dict[str, Any]:
    """Execute a GraphQL query against RA's public API.

    Args:
        query: GraphQL query string
        variables: Optional variables for the query

    Returns:
        Dictionary containing the GraphQL response

    Raises:
        requests.RequestException: If the request fails
    """
    payload: dict[str, Any] = {"query": query}
    if variables:
        payload["variables"] = variables

    response = requests.post(RA_GRAPHQL_URL, headers=RA_HEADERS, json=payload, timeout=15)
    response.raise_for_status()
    result: dict[str, Any] = response.json()
    return result


def format_ra_response(response: dict[str, Any]) -> str:
    """Format RA GraphQL response for display."""
    parts = []

    if "errors" in response:
        parts.append("Errors:")
        for error in response["errors"]:
            parts.append(f"  - {error.get('message', 'Unknown error')}")

    if "data" in response:
        parts.append(json.dumps(response["data"], indent=2))

    return "\n".join(parts)


@tool
def use_resident_advisor(
    query: str,
    variables: dict[str, Any] | None = None,
    label: str = "RA GraphQL query",
) -> dict[str, Any]:
    """Execute GraphQL queries against Resident Advisor's (ra.co) public API.

    No authentication required. Provides access to RA's full GraphQL schema for
    querying electronic music events, artists, venues, and more.

    Common queries:

    Search events by area and date:
    ```graphql
    query($filters: FilterInputDtoInput, $page: Int, $pageSize: Int) {
        eventListings(filters: $filters, pageSize: $pageSize, page: $page) {
            data {
                event { id title date startTime endTime attending contentUrl
                        venue { name } artists { name } genres { name } }
            }
            totalResults
        }
    }
    ```
    variables: {"filters": {"areas": {"eq": 8}, "listingDate": {"gte": "2026-01-01T00:00:00.000Z",
    "lte": "2026-01-07T23:59:59.999Z"}}, "pageSize": 20, "page": 1}

    Look up area code by city name:
    ```graphql
    { areas(searchTerm: "oslo", limit: 3) { id name country { name } } }
    ```

    Get event details:
    ```graphql
    { event(id: 12345) { id title date startTime endTime content cost minimumAge attending
        venue { name address } artists { name contentUrl } genres { name } promoters { name } } }
    ```

    Get artist profile:
    ```graphql
    { artist(slug: "djsprinkles") { id name aliases biography { blurb }
        area { name } followerCount regionsMostPlayed { name } venuesMostPlayed { name }
        relatedArtists { name } facebook instagram soundcloud website } }
    ```

    Get venue details:
    ```graphql
    { venue(id: 5031) { id name address capacity area { name }
        website followerCount eventCountThisYear topArtists { name } blurb } }
    ```

    Universal search:
    ```graphql
    { search(searchTerm: "Berghain", limit: 5, indices: [CLUB]) {
        id value searchType contentUrl areaName } }
    ```
    IndexType values: EVENT, ARTIST, CLUB, PROMOTER, LABEL, AREA

    Args:
        query: The GraphQL query string.
        variables: Optional dictionary of variables for the query.
        label: Human-readable description of the operation.

    Returns:
        Dict with "status" ("success"/"error"), "content" (formatted text).
    """
    if variables is None:
        variables = {}

    logger.info(f"RA GraphQL: {label}")

    try:
        response = execute_ra_graphql(query, variables)
        formatted = format_ra_response(response)

        if "errors" in response:
            return {
                "status": "error",
                "content": [{"text": formatted}],
            }

        return {
            "status": "success",
            "content": [{"text": formatted}],
        }

    except requests.exceptions.RequestException as e:
        return {
            "status": "error",
            "content": [{"text": f"Request failed: {e}"}],
        }
    except Exception as e:
        logger.warning(f"RA GraphQL error: {type(e).__name__}: {e}")
        return {
            "status": "error",
            "content": [{"text": f"Error: {e}"}],
        }
