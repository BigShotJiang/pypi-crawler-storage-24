"""Bus connection management and D-Bus type serialization."""

import asyncio
import json
import os
import re
import sys
from typing import Any

from dbus_fast import BusType, Message, MessageType
from dbus_fast.aio import MessageBus
from dbus_fast.unpack import unpack_variants
from fastmcp import Context

DBUS_CALL_TIMEOUT = float(os.environ.get("MCDBUS_TIMEOUT", "30"))

# D-Bus spec: https://dbus.freedesktop.org/doc/dbus-specification.html
_DBUS_NAME_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_.]*(\.[A-Za-z_][A-Za-z0-9_]*)+$")
_DBUS_PATH_RE = re.compile(r"^/$|^(/[A-Za-z0-9_]+)+$")


def validate_bus_name(name: str, label: str = "service") -> None:
    """Validate a D-Bus well-known or interface name."""
    if not _DBUS_NAME_RE.match(name):
        raise ValueError(
            f"Invalid D-Bus {label}: {name!r}. "
            f"Must match [A-Za-z_][A-Za-z0-9_]*(.[A-Za-z_][A-Za-z0-9_]*)+"
        )


def validate_object_path(path: str) -> None:
    """Validate a D-Bus object path."""
    if not _DBUS_PATH_RE.match(path):
        raise ValueError(
            f"Invalid D-Bus object path: {path!r}. "
            f"Must be '/' or '/element/element/...' with [A-Za-z0-9_]"
        )


_DBUS_SIG_CHARS = re.compile(r"^[ybnqiuxtdsogav(){}\s]*$")
MAX_SIGNATURE_LEN = 255


def validate_signature(sig: str) -> None:
    """Validate a D-Bus type signature string."""
    if len(sig) > MAX_SIGNATURE_LEN:
        raise ValueError(f"Signature too long ({len(sig)} > {MAX_SIGNATURE_LEN})")
    if not _DBUS_SIG_CHARS.match(sig):
        raise ValueError(f"Invalid D-Bus signature characters: {sig!r}")
    from dbus_fast.signature import SignatureTree

    try:
        SignatureTree(sig)
    except Exception as exc:
        raise ValueError(f"Malformed D-Bus signature: {exc}") from exc


class BusManager:
    """Lazy-connecting, caching manager for session and system D-Bus connections."""

    def __init__(self) -> None:
        self._buses: dict[str, MessageBus] = {}
        self._locks: dict[str, asyncio.Lock] = {
            "session": asyncio.Lock(),
            "system": asyncio.Lock(),
        }

    async def get_bus(self, bus_type: str) -> MessageBus:
        """Get a connected bus by type name ("session" or "system")."""
        if bus_type not in ("session", "system"):
            raise ValueError(f"bus_type must be 'session' or 'system', got {bus_type!r}")

        async with self._locks[bus_type]:
            if bus_type in self._buses:
                bus = self._buses[bus_type]
                if bus.connected:
                    return bus
                # stale — drop and reconnect
                del self._buses[bus_type]

            bt = BusType.SESSION if bus_type == "session" else BusType.SYSTEM
            bus = await MessageBus(bus_type=bt).connect()
            self._buses[bus_type] = bus
            return bus

    async def disconnect_all(self) -> None:
        for name, bus in self._buses.items():
            try:
                if bus.connected:
                    bus.disconnect()
            except Exception as exc:
                print(f"mcdbus: error disconnecting {name} bus: {exc}", file=sys.stderr)
        self._buses.clear()


def get_mgr(ctx: Context) -> "BusManager":
    """Extract the BusManager from a FastMCP tool context."""
    return ctx.lifespan_context


def serialize_variant(value: Any) -> Any:
    """Recursively unwrap dbus-fast Variant objects into JSON-safe Python types."""
    unpacked = unpack_variants(value)
    return _make_json_safe(unpacked)


def _make_json_safe(value: Any) -> Any:
    """Ensure all values are JSON-serializable (handle bytes, tuples, etc.)."""
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return list(value)
    if isinstance(value, dict):
        return {str(k): _make_json_safe(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_make_json_safe(item) for item in value]
    return value


def deserialize_args(args_json: str, signature: str) -> list[Any]:
    """Parse JSON args string into a Python list suitable for D-Bus call body.

    For 'v' (Variant) signatures, wraps values in dbus_fast.signature.Variant.
    Auto-wrapping infers types for simple scalars; for complex variant values
    (e.g. array of int), pass the value as {"signature": "ai", "value": [1,2,3]}.
    """
    from dbus_fast.signature import SignatureTree, Variant

    if not args_json or args_json.strip() in ("", "[]", "null"):
        return []

    try:
        args = json.loads(args_json)
    except json.JSONDecodeError as exc:
        raise ValueError(f"Invalid JSON in args: {exc}") from exc

    if not isinstance(args, list):
        args = [args]

    if not signature:
        return args

    validate_signature(signature)
    tree = SignatureTree(signature)
    expected = len(tree.types)
    if len(args) != expected:
        raise ValueError(
            f"Signature '{signature}' expects {expected} argument(s), got {len(args)}"
        )

    result = []
    for i, sig_type in enumerate(tree.types):
        val = args[i]
        if sig_type.signature == "v":
            val = _auto_wrap_variant(val, Variant)
        result.append(val)

    return result


def _auto_wrap_variant(val: Any, variant_cls: type) -> Any:
    """Wrap a Python value in a D-Bus Variant, inferring the type signature.

    For explicit control, pass {"signature": "ai", "value": [1,2,3]}.
    """
    # Explicit variant specification
    if isinstance(val, dict) and "signature" in val and "value" in val and len(val) == 2:
        validate_signature(val["signature"])
        return variant_cls(val["signature"], val["value"])
    # Auto-infer from Python type (bool must come before int — bool is a subclass of int)
    if isinstance(val, bool):
        return variant_cls("b", val)
    if isinstance(val, str):
        return variant_cls("s", val)
    if isinstance(val, int):
        return variant_cls("i", val)
    if isinstance(val, float):
        return variant_cls("d", val)
    if isinstance(val, list):
        return variant_cls("as", val)
    if isinstance(val, dict):
        return variant_cls("a{sv}", val)
    return variant_cls("s", str(val))


async def call_bus_method(
    bus: MessageBus,
    destination: str,
    path: str,
    interface: str,
    member: str,
    signature: str = "",
    body: list[Any] | None = None,
    timeout: float = DBUS_CALL_TIMEOUT,
) -> Any:
    """Send a D-Bus method call and return the unpacked response body."""
    msg = Message(
        destination=destination,
        path=path,
        interface=interface,
        member=member,
        signature=signature,
        body=body or [],
    )
    try:
        reply = await asyncio.wait_for(bus.call(msg), timeout=timeout)
    except TimeoutError:
        raise TimeoutError(
            f"D-Bus call timed out after {timeout}s: "
            f"{destination} {interface}.{member} at {path}"
        ) from None
    if reply.message_type == MessageType.ERROR:
        print(f"mcdbus: D-Bus error: {reply.error_name}: {reply.body}", file=sys.stderr)
        detail = reply.body[0] if reply.body and isinstance(reply.body[0], str) else ""
        raise RuntimeError(f"D-Bus error ({reply.error_name}): {detail}")
    if reply.body:
        return serialize_variant(reply.body)
    return None
