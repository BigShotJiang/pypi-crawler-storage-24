"""High-level convenience tools for common D-Bus operations."""

import fnmatch

from fastmcp import Context
from fastmcp.exceptions import ToolError

from mcdbus._bus import call_bus_method, get_mgr
from mcdbus._state import mcp

# ---------------------------------------------------------------------------
# Notifications
# ---------------------------------------------------------------------------

@mcp.tool()
async def send_notification(
    summary: str,
    ctx: Context,
    body: str = "",
    icon: str = "",
    timeout: int = 5000,
) -> str:
    """Send a desktop notification via D-Bus.

    Args:
        summary: notification title
        body: notification body text
        icon: icon name or path (empty for default)
        timeout: display duration in milliseconds (default 5000)
    """
    mgr = get_mgr(ctx)
    connection = await mgr.get_bus("session")

    try:
        result = await call_bus_method(
            connection,
            destination="org.freedesktop.Notifications",
            path="/org/freedesktop/Notifications",
            interface="org.freedesktop.Notifications",
            member="Notify",
            signature="susssasa{sv}i",
            body=[
                "mcdbus",       # app_name
                0,              # replaces_id (0 = new)
                icon,           # app_icon
                summary,        # summary
                body,           # body
                [],             # actions
                {},             # hints
                timeout,        # expire_timeout
            ],
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"Error sending notification: {exc}") from exc

    nid = result[0] if result else "unknown"
    return f"Notification sent (id: {nid})"


# ---------------------------------------------------------------------------
# Systemd
# ---------------------------------------------------------------------------

@mcp.tool()
async def list_systemd_units(
    ctx: Context,
    bus: str = "system",
    pattern: str = "",
) -> str:
    """List systemd units, optionally filtered by glob pattern.

    Args:
        bus: "session" (user units) or "system" (system units, default)
        pattern: optional glob filter (e.g. "docker*", "*.service")
    """
    mgr = get_mgr(ctx)
    connection = await mgr.get_bus(bus)

    try:
        result = await call_bus_method(
            connection,
            destination="org.freedesktop.systemd1",
            path="/org/freedesktop/systemd1",
            interface="org.freedesktop.systemd1.Manager",
            member="ListUnits",
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"Error listing units: {exc}") from exc

    if not result or not result[0]:
        return "No units found."

    units = result[0]

    # Each unit is (name, description, load_state, active_state, sub_state, ...)
    if pattern:
        units = [u for u in units if fnmatch.fnmatch(u[0], pattern)]

    lines = [f"## Systemd units on {bus} bus — {len(units)} matches\n"]
    lines.append("| Unit | Load | Active | Sub | Description |")
    lines.append("|------|------|--------|-----|-------------|")
    for unit in sorted(units, key=lambda u: u[0]):
        name, desc, load, active, sub = unit[0], unit[1], unit[2], unit[3], unit[4]
        lines.append(f"| `{name}` | {load} | {active} | {sub} | {desc} |")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# MPRIS Media Player
# ---------------------------------------------------------------------------

@mcp.tool()
async def media_player_control(
    action: str,
    ctx: Context,
    player: str = "",
) -> str:
    """Control an MPRIS2 media player.

    Args:
        action: one of "play", "pause", "next", "previous", "stop", "play-pause"
        player: MPRIS player name (auto-discovers first player if empty)
    """
    mgr = get_mgr(ctx)
    connection = await mgr.get_bus("session")

    if not player:
        result = await call_bus_method(
            connection,
            destination="org.freedesktop.DBus",
            path="/org/freedesktop/DBus",
            interface="org.freedesktop.DBus",
            member="ListNames",
        )
        names = result[0] if result else []
        mpris_services = sorted(
            n for n in names if n.startswith("org.mpris.MediaPlayer2.")
        )

        if not mpris_services:
            return "No MPRIS media players found on session bus."
        player = mpris_services[0]
        others = (
            f"\nOther players: {', '.join(mpris_services[1:])}"
            if len(mpris_services) > 1 else ""
        )
        await ctx.info(f"Auto-discovered player: {player}{others}")

    action_map = {
        "play": "Play",
        "pause": "Pause",
        "stop": "Stop",
        "next": "Next",
        "previous": "Previous",
        "play-pause": "PlayPause",
    }

    dbus_method = action_map.get(action.lower())
    if not dbus_method:
        return f"Unknown action: {action}. Use: {', '.join(action_map.keys())}"

    try:
        await call_bus_method(
            connection,
            destination=player,
            path="/org/mpris/MediaPlayer2",
            interface="org.mpris.MediaPlayer2.Player",
            member=dbus_method,
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"Error controlling player: {exc}") from exc

    # Read current playback status
    try:
        status_result = await call_bus_method(
            connection,
            destination=player,
            path="/org/mpris/MediaPlayer2",
            interface="org.freedesktop.DBus.Properties",
            member="Get",
            signature="ss",
            body=["org.mpris.MediaPlayer2.Player", "PlaybackStatus"],
        )
        status = status_result[0] if status_result else "unknown"
    except (RuntimeError, TimeoutError):
        status = "unknown"

    # Try to get current track metadata
    try:
        meta_result = await call_bus_method(
            connection,
            destination=player,
            path="/org/mpris/MediaPlayer2",
            interface="org.freedesktop.DBus.Properties",
            member="Get",
            signature="ss",
            body=["org.mpris.MediaPlayer2.Player", "Metadata"],
        )
        metadata = meta_result[0] if meta_result else {}
        title = metadata.get("xesam:title", "Unknown")
        artist = metadata.get("xesam:artist", ["Unknown"])
        if isinstance(artist, list):
            artist = ", ".join(artist)
    except (RuntimeError, TimeoutError):
        title, artist = "Unknown", "Unknown"

    return f"Player: {player}\nAction: {action}\nStatus: {status}\nNow: {artist} — {title}"


# ---------------------------------------------------------------------------
# NetworkManager
# ---------------------------------------------------------------------------

_NM_DEST = "org.freedesktop.NetworkManager"
_NM_PATH = "/org/freedesktop/NetworkManager"
_NM_IFACE = "org.freedesktop.NetworkManager"

_NM_STATE_MAP = {
    0: "Unknown", 10: "Asleep", 20: "Disconnected",
    30: "Disconnecting", 40: "Connecting",
    50: "Connected (local)", 60: "Connected (site)",
    70: "Connected (global)",
}

_NM_CONN_STATE_MAP = {
    0: "Unknown", 1: "Activating", 2: "Activated",
    3: "Deactivating", 4: "Deactivated",
}


@mcp.tool()
async def network_status(ctx: Context) -> str:
    """Show NetworkManager connection status and active connections."""
    mgr = get_mgr(ctx)
    connection = await mgr.get_bus("system")

    try:
        state_result = await call_bus_method(
            connection,
            destination=_NM_DEST,
            path=_NM_PATH,
            interface="org.freedesktop.DBus.Properties",
            member="GetAll",
            signature="s",
            body=[_NM_IFACE],
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"NetworkManager not available: {exc}") from exc

    if not state_result or not state_result[0]:
        return "NetworkManager returned no properties."

    props = state_result[0]
    state = _NM_STATE_MAP.get(props.get("State", 0), "Unknown")
    wireless = "enabled" if props.get("WirelessEnabled") else "disabled"

    lines = [
        "## Network Status\n",
        f"- **State:** {state}",
        f"- **Wireless:** {wireless}",
    ]

    # Active connections
    active_paths = props.get("ActiveConnections", [])
    if active_paths:
        lines.append("\n| Connection | Type | State |")
        lines.append("|------------|------|-------|")

        for ac_path in active_paths:
            try:
                ac_result = await call_bus_method(
                    connection,
                    destination=_NM_DEST,
                    path=ac_path,
                    interface="org.freedesktop.DBus.Properties",
                    member="GetAll",
                    signature="s",
                    body=["org.freedesktop.NetworkManager.Connection.Active"],
                )
                if ac_result and ac_result[0]:
                    ac = ac_result[0]
                    name = ac.get("Id", "?")
                    conn_type = ac.get("Type", "?")
                    conn_state = _NM_CONN_STATE_MAP.get(ac.get("State", 0), "?")
                    lines.append(f"| {name} | {conn_type} | {conn_state} |")
            except (RuntimeError, TimeoutError):
                continue

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# UPower (Battery)
# ---------------------------------------------------------------------------

_UPOWER_DEST = "org.freedesktop.UPower"
_UPOWER_PATH = "/org/freedesktop/UPower"

_UPOWER_STATE_MAP = {
    0: "Unknown", 1: "Charging", 2: "Discharging",
    3: "Empty", 4: "Fully charged", 5: "Pending charge",
    6: "Pending discharge",
}


@mcp.tool()
async def battery_status(ctx: Context) -> str:
    """Show battery status from UPower (percentage, charging state, time remaining)."""
    mgr = get_mgr(ctx)
    connection = await mgr.get_bus("system")

    try:
        devices_result = await call_bus_method(
            connection,
            destination=_UPOWER_DEST,
            path=_UPOWER_PATH,
            interface=_UPOWER_DEST,
            member="EnumerateDevices",
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"UPower not available: {exc}") from exc

    if not devices_result or not devices_result[0]:
        return "No power devices found."

    device_paths = devices_result[0]
    batteries = []

    for dev_path in device_paths:
        try:
            dev_result = await call_bus_method(
                connection,
                destination=_UPOWER_DEST,
                path=dev_path,
                interface="org.freedesktop.DBus.Properties",
                member="GetAll",
                signature="s",
                body=["org.freedesktop.UPower.Device"],
            )
        except (RuntimeError, TimeoutError):
            continue

        if not dev_result or not dev_result[0]:
            continue

        props = dev_result[0]
        # Type 2 = Battery
        if props.get("Type") != 2:
            continue

        pct = props.get("Percentage", 0)
        state = _UPOWER_STATE_MAP.get(props.get("State", 0), "Unknown")
        tte = props.get("TimeToEmpty", 0)
        ttf = props.get("TimeToFull", 0)
        rate = props.get("EnergyRate", 0)
        model = props.get("Model", "Battery")

        time_str = ""
        if tte > 0:
            h, m = divmod(int(tte) // 60, 60)
            time_str = f"{h}h {m}m remaining"
        elif ttf > 0:
            h, m = divmod(int(ttf) // 60, 60)
            time_str = f"{h}h {m}m to full"

        batteries.append({
            "model": model, "percentage": pct, "state": state,
            "time": time_str, "rate": rate,
        })

    if not batteries:
        return "No batteries found."

    lines = ["## Battery Status\n"]
    for bat in batteries:
        lines.append(f"### {bat['model']}")
        lines.append(f"- **Charge:** {bat['percentage']:.0f}%")
        lines.append(f"- **State:** {bat['state']}")
        if bat["time"]:
            lines.append(f"- **Time:** {bat['time']}")
        if bat["rate"] > 0:
            lines.append(f"- **Power draw:** {bat['rate']:.1f} W")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Bluetooth (bluez)
# ---------------------------------------------------------------------------

@mcp.tool()
async def bluetooth_devices(ctx: Context) -> str:
    """List discovered and paired Bluetooth devices from bluez."""
    mgr = get_mgr(ctx)
    connection = await mgr.get_bus("system")

    try:
        objects_result = await call_bus_method(
            connection,
            destination="org.bluez",
            path="/",
            interface="org.freedesktop.DBus.ObjectManager",
            member="GetManagedObjects",
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"bluez not available: {exc}") from exc

    if not objects_result or not objects_result[0]:
        return "No Bluetooth objects found."

    managed = objects_result[0]
    devices = []

    for _obj_path, interfaces in managed.items():
        dev_props = interfaces.get("org.bluez.Device1")
        if not dev_props:
            continue

        devices.append({
            "name": dev_props.get("Name", dev_props.get("Alias", "Unknown")),
            "address": dev_props.get("Address", "?"),
            "connected": dev_props.get("Connected", False),
            "paired": dev_props.get("Paired", False),
            "trusted": dev_props.get("Trusted", False),
        })

    if not devices:
        return "No Bluetooth devices found."

    devices.sort(key=lambda d: (not d["connected"], not d["paired"], d["name"]))
    lines = [
        f"## Bluetooth Devices — {len(devices)} found\n",
        "| Name | Address | Connected | Paired | Trusted |",
        "|------|---------|-----------|--------|---------|",
    ]
    for d in devices:
        conn = "✓" if d["connected"] else "—"
        pair = "✓" if d["paired"] else "—"
        trust = "✓" if d["trusted"] else "—"
        lines.append(f"| {d['name']} | `{d['address']}` | {conn} | {pair} | {trust} |")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# KWin Windows (KDE Plasma)
# ---------------------------------------------------------------------------

@mcp.tool()
async def kwin_windows(ctx: Context) -> str:
    """List open windows from KDE KWin via the KRunner window runner.

    Returns window titles, application names, and virtual desktop assignments.
    Requires a running KDE Plasma session.
    """
    mgr = get_mgr(ctx)
    connection = await mgr.get_bus("session")

    # KRunner's WindowsRunner lists all windows when queried with empty string
    try:
        result = await call_bus_method(
            connection,
            destination="org.kde.KWin",
            path="/WindowsRunner",
            interface="org.kde.krunner1",
            member="Match",
            signature="s",
            body=[""],
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"KWin not available: {exc}") from exc

    if not result or not result[0]:
        return "No windows found (KWin WindowsRunner returned empty)."

    matches = result[0]
    # Each match: (id, caption, icon, type, relevance, properties)
    # type=0 → window, type=8 → virtual desktop

    windows = []
    desktops = []
    seen_ids = set()

    for match in matches:
        match_id, caption, icon = match[0], match[1], match[2]
        match_type = match[3]

        if match_id in seen_ids:
            continue
        seen_ids.add(match_id)

        if match_type == 8:
            desktops.append(caption)
        else:
            windows.append({"caption": caption, "app": icon or "unknown"})

    if not windows:
        return "No open windows found."

    # Group by app
    lines = [f"## KWin Windows — {len(windows)} open\n"]
    lines.append("| Window | Application |")
    lines.append("|--------|-------------|")
    for w in sorted(windows, key=lambda x: (x["app"], x["caption"])):
        lines.append(f"| {w['caption']} | {w['app']} |")

    if desktops:
        lines.append(f"\n**Virtual desktops:** {', '.join(sorted(desktops))}")

    return "\n".join(lines)
