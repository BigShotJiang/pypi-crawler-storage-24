"""FastMCP server instance and lifespan management."""

import sys
from contextlib import asynccontextmanager

from fastmcp import FastMCP

from mcdbus._bus import BusManager

INSTRUCTIONS = """\
D-Bus bridge for Linux IPC. Discover and interact with session and system bus \
services through introspection.

Workflow: list_services -> list_objects -> introspect -> call_method / get_property

Two buses are available:
- "session" — user desktop services (notifications, media players, KDE, portals)
- "system" — system services (systemd, NetworkManager, UDisks2, UPower, bluez)
"""


@asynccontextmanager
async def lifespan(server: FastMCP):
    """Manage BusManager lifecycle — connections are lazy but cleaned up on shutdown."""
    mgr = BusManager()
    print("mcdbus: D-Bus MCP server starting", file=sys.stderr)
    try:
        yield mgr
    finally:
        await mgr.disconnect_all()
        print("mcdbus: D-Bus connections closed", file=sys.stderr)


mcp = FastMCP(
    name="mcdbus",
    instructions=INSTRUCTIONS,
    lifespan=lifespan,
)
