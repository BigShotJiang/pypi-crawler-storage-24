"""Prompt templates for guided D-Bus exploration."""

from mcdbus._state import mcp


@mcp.prompt()
def explore_service(bus: str = "session", service: str = "") -> str:
    """Guide through exploring a D-Bus service step by step."""
    if service:
        return (
            f"Explore the D-Bus {bus} bus service: {service}\n\n"
            f'1. Use list_objects(bus="{bus}", service="{service}") to see the object tree\n'
            f"2. Use introspect() on interesting objects to see methods/properties/signals\n"
            f"3. Use get_all_properties() to read current state\n"
            f"4. Use call_method() to interact with methods\n"
        )
    return (
        f"Explore the D-Bus {bus} bus:\n\n"
        f'1. Start with list_services(bus="{bus}") to see available services\n'
        f"2. Pick a service and use list_objects() to see its object tree\n"
        f"3. Use introspect() on interesting objects to see methods/properties/signals\n"
        f"4. Use get_all_properties() to read current state\n"
        f"5. Use call_method() to interact with methods\n"
    )


@mcp.prompt()
def debug_service(service: str, bus: str = "session") -> str:
    """Diagnose issues with a D-Bus service."""
    return (
        f"Debug the D-Bus service: {service} on the {bus} bus\n\n"
        f'1. Check if the service is registered: list_services(bus="{bus}")\n'
        f'2. Introspect root: introspect(bus="{bus}", service="{service}", object_path="/")\n'
        f"3. Walk the object tree to find all endpoints\n"
        f"4. Read all properties on key interfaces to check state\n"
        f"5. Try calling Ping on org.freedesktop.DBus.Peer to verify responsiveness\n"
    )
