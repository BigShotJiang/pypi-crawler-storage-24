"""mcdbus entry point — D-Bus MCP server."""

import mcdbus._discovery  # noqa: F401
import mcdbus._interaction  # noqa: F401
import mcdbus._prompts  # noqa: F401
import mcdbus._resources  # noqa: F401
import mcdbus._shortcuts  # noqa: F401
from mcdbus._state import mcp  # noqa: F401


def main():
    mcp.run()
