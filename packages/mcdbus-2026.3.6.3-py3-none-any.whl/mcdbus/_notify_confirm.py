"""D-Bus notification fallback for confirmation when MCP elicitation is unavailable."""

import asyncio

from dbus_fast import MessageType
from dbus_fast.aio import MessageBus
from dbus_fast.signature import Variant

from mcdbus._bus import call_bus_method

_NOTIFY_DEST = "org.freedesktop.Notifications"
_NOTIFY_PATH = "/org/freedesktop/Notifications"
_NOTIFY_IFACE = "org.freedesktop.Notifications"

_DBUS_DEST = "org.freedesktop.DBus"
_DBUS_PATH = "/org/freedesktop/DBus"
_DBUS_IFACE = "org.freedesktop.DBus"


async def notify_confirm(
    bus: MessageBus,
    summary: str,
    body: str,
    timeout: float = 60.0,
) -> bool:
    """Send a desktop notification with Approve/Deny actions and wait for response.

    Returns True if user clicked Approve, False for deny/dismiss/expire/timeout.
    Raises RuntimeError if notification service is unreachable.
    """
    event = asyncio.Event()
    result_box: list[bool] = [False]
    nid_box: list[int] = [0]

    match_action = (
        "type='signal',"
        f"interface='{_NOTIFY_IFACE}',"
        "member='ActionInvoked'"
    )
    match_closed = (
        "type='signal',"
        f"interface='{_NOTIFY_IFACE}',"
        "member='NotificationClosed'"
    )

    def handler(msg):
        if event.is_set():
            return  # First signal wins — ignore NotificationClosed after ActionInvoked
        if msg.message_type != MessageType.SIGNAL:
            return
        if msg.interface != _NOTIFY_IFACE:
            return
        if not nid_box[0] or not msg.body or msg.body[0] != nid_box[0]:
            return
        if msg.member == "ActionInvoked":
            result_box[0] = msg.body[1] == "approve"
            event.set()
        elif msg.member == "NotificationClosed":
            result_box[0] = False
            event.set()

    # Register match rules before sending notification — no signal can be missed.
    await call_bus_method(
        bus,
        destination=_DBUS_DEST,
        path=_DBUS_PATH,
        interface=_DBUS_IFACE,
        member="AddMatch",
        signature="s",
        body=[match_action],
    )
    await call_bus_method(
        bus,
        destination=_DBUS_DEST,
        path=_DBUS_PATH,
        interface=_DBUS_IFACE,
        member="AddMatch",
        signature="s",
        body=[match_closed],
    )

    bus.add_message_handler(handler)

    try:
        reply = await call_bus_method(
            bus,
            destination=_NOTIFY_DEST,
            path=_NOTIFY_PATH,
            interface=_NOTIFY_IFACE,
            member="Notify",
            signature="susssasa{sv}i",
            body=[
                "mcdbus",
                0,
                "dialog-warning",
                summary,
                body,
                ["approve", "Approve", "deny", "Deny"],
                {"urgency": Variant("y", 2)},
                0,
            ],
        )
        nid_box[0] = reply[0]

        await asyncio.wait_for(event.wait(), timeout=timeout)
        return result_box[0]
    except TimeoutError:
        return False
    finally:
        bus.remove_message_handler(handler)
        # Best-effort cleanup
        if nid_box[0]:
            try:
                await call_bus_method(
                    bus,
                    destination=_NOTIFY_DEST,
                    path=_NOTIFY_PATH,
                    interface=_NOTIFY_IFACE,
                    member="CloseNotification",
                    signature="u",
                    body=[nid_box[0]],
                )
            except Exception:
                pass
        for rule in (match_action, match_closed):
            try:
                await call_bus_method(
                    bus,
                    destination=_DBUS_DEST,
                    path=_DBUS_PATH,
                    interface=_DBUS_IFACE,
                    member="RemoveMatch",
                    signature="s",
                    body=[rule],
                )
            except Exception:
                pass
