"""mcdbus — D-Bus MCP server for Linux IPC."""

__version__ = "2026.03.05"
