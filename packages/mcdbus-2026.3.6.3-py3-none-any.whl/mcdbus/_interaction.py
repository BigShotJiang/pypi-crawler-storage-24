"""Interaction tools — method calls, property get/set."""

import json
import os
import sys

from dbus_fast.signature import Variant
from fastmcp import Context
from fastmcp.exceptions import ToolError
from fastmcp.server.elicitation import (
    AcceptedElicitation,
    CancelledElicitation,
)

from mcdbus._bus import (
    call_bus_method,
    deserialize_args,
    get_mgr,
    validate_bus_name,
    validate_object_path,
    validate_signature,
)
from mcdbus._notify_confirm import notify_confirm
from mcdbus._state import mcp


async def _confirm_or_abort(ctx: Context, message: str, operation: str) -> None:
    """Elicit user confirmation; raise ToolError or return silently to proceed."""
    try:
        result = await ctx.elicit(
            message,
            {
                "confirm": {"title": "Yes, proceed"},
                "deny": {"title": "No, cancel"},
            },
        )
    except Exception:
        # Client doesn't implement elicitation at the protocol level —
        # ctx.elicit() throws instead of returning CancelledElicitation.
        result = CancelledElicitation()

    if isinstance(result, AcceptedElicitation) and result.data == "confirm":
        return
    if isinstance(result, CancelledElicitation):
        # Client doesn't support elicitation
        if os.environ.get("MCDBUS_REQUIRE_ELICITATION"):
            raise ToolError("Elicitation required but client does not support it")

        # D-Bus notification fallback (opt-in)
        if os.environ.get("MCDBUS_NOTIFY_CONFIRM"):
            try:
                mgr = get_mgr(ctx)
                bus = await mgr.get_bus("session")
                approved = await notify_confirm(
                    bus,
                    summary=f"mcdbus: Confirm {operation}",
                    body=message,
                )
                if approved:
                    return
                raise ToolError("Operation denied via desktop notification.")
            except (RuntimeError, TimeoutError) as exc:
                print(
                    f"mcdbus: notification fallback failed ({exc}), "
                    f"proceeding with {operation}",
                    file=sys.stderr,
                )
                return

        print(f"mcdbus: elicitation unavailable, proceeding with {operation}", file=sys.stderr)
        return
    # User explicitly declined
    raise ToolError("Operation cancelled by user.")


@mcp.tool()
async def call_method(
    bus: str,
    service: str,
    object_path: str,
    interface: str,
    method: str,
    ctx: Context,
    args: str = "[]",
    signature: str = "",
) -> str:
    """Call a D-Bus method and return the result.

    Args:
        bus: "session" or "system"
        service: service name (e.g. "org.freedesktop.Notifications")
        object_path: object path (e.g. "/org/freedesktop/Notifications")
        interface: interface name (e.g. "org.freedesktop.Notifications")
        method: method name (e.g. "GetServerInformation")
        args: JSON array of arguments (default "[]")
        signature: D-Bus type signature for args (e.g. "su"); leave empty for no-arg methods
    """
    validate_bus_name(service)
    validate_object_path(object_path)
    validate_bus_name(interface, label="interface")

    mgr = get_mgr(ctx)
    connection = await mgr.get_bus(bus)

    try:
        body = deserialize_args(args, signature)
    except (ValueError, json.JSONDecodeError) as exc:
        raise ToolError(f"Error parsing arguments: {exc}") from exc

    # Elicit confirmation for system bus calls (session bus = user-scope, no prompt)
    if bus == "system":
        await _confirm_or_abort(
            ctx,
            f"Confirm system bus method call:\n"
            f"  Service: {service}\n"
            f"  Method:  {interface}.{method}\n"
            f"  Path:    {object_path}\n"
            f"  Args:    {args}",
            f"{interface}.{method}",
        )
        print(
            f"mcdbus: system bus call {service} {interface}.{method} "
            f"path={object_path} sig={signature!r}",
            file=sys.stderr,
        )

    await ctx.info(f"Calling {interface}.{method} on {service}...")

    try:
        result = await call_bus_method(
            connection,
            destination=service,
            path=object_path,
            interface=interface,
            member=method,
            signature=signature,
            body=body,
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(str(exc)) from exc

    if result is None:
        return "Method returned no data (void)."

    # If single-element response, unwrap for cleaner output
    if isinstance(result, list) and len(result) == 1:
        result = result[0]

    return json.dumps(result, indent=2, default=str)


@mcp.tool()
async def get_property(
    bus: str,
    service: str,
    object_path: str,
    interface: str,
    property_name: str,
    ctx: Context,
) -> str:
    """Read a single D-Bus property value.

    Args:
        bus: "session" or "system"
        service: service name
        object_path: object path
        interface: interface that owns the property
        property_name: property name to read
    """
    validate_bus_name(service)
    validate_object_path(object_path)
    validate_bus_name(interface, label="interface")

    mgr = get_mgr(ctx)
    connection = await mgr.get_bus(bus)

    try:
        result = await call_bus_method(
            connection,
            destination=service,
            path=object_path,
            interface="org.freedesktop.DBus.Properties",
            member="Get",
            signature="ss",
            body=[interface, property_name],
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"Error reading {interface}.{property_name}: {exc}") from exc

    if result:
        value = result[0]
        return json.dumps(value, indent=2, default=str)
    return "No value returned."


@mcp.tool()
async def set_property(
    bus: str,
    service: str,
    object_path: str,
    interface: str,
    property_name: str,
    value: str,
    signature: str,
    ctx: Context,
) -> str:
    """Set a D-Bus property value.

    Args:
        bus: "session" or "system"
        service: service name
        object_path: object path
        interface: interface that owns the property
        property_name: property name to set
        value: JSON-encoded value to set
        signature: D-Bus type signature of the property value (e.g. "b" for boolean)
    """
    validate_bus_name(service)
    validate_object_path(object_path)
    validate_bus_name(interface, label="interface")

    mgr = get_mgr(ctx)
    connection = await mgr.get_bus(bus)

    try:
        parsed_value = json.loads(value)
    except json.JSONDecodeError as exc:
        raise ToolError(f"Error parsing value JSON: {exc}") from exc

    validate_signature(signature)
    variant = Variant(signature, parsed_value)

    # Elicit confirmation for all property mutations (always state-changing)
    await _confirm_or_abort(
        ctx,
        f"Confirm property change:\n"
        f"  Service:  {service}\n"
        f"  Property: {interface}.{property_name}\n"
        f"  New value: {value}\n"
        f"  Bus: {bus}",
        f"set {interface}.{property_name}",
    )

    # Audit log for all set_property calls
    print(
        f"mcdbus: set_property {bus} {service} {interface}.{property_name} "
        f"= {value} (sig={signature!r})",
        file=sys.stderr,
    )

    try:
        await call_bus_method(
            connection,
            destination=service,
            path=object_path,
            interface="org.freedesktop.DBus.Properties",
            member="Set",
            signature="ssv",
            body=[interface, property_name, variant],
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"Error setting {interface}.{property_name}: {exc}") from exc

    return f"Set {interface}.{property_name} = {value}"


@mcp.tool()
async def get_all_properties(
    bus: str,
    service: str,
    object_path: str,
    interface: str,
    ctx: Context,
) -> str:
    """Read all properties on a D-Bus interface.

    Args:
        bus: "session" or "system"
        service: service name
        object_path: object path
        interface: interface to read properties from
    """
    validate_bus_name(service)
    validate_object_path(object_path)
    validate_bus_name(interface, label="interface")

    mgr = get_mgr(ctx)
    connection = await mgr.get_bus(bus)

    try:
        result = await call_bus_method(
            connection,
            destination=service,
            path=object_path,
            interface="org.freedesktop.DBus.Properties",
            member="GetAll",
            signature="s",
            body=[interface],
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"Error reading properties on {interface}: {exc}") from exc

    if not result or not result[0]:
        return "No properties found."

    props = result[0]
    lines = [f"## Properties of `{interface}` at `{object_path}`\n"]
    lines.append("| Property | Value |")
    lines.append("|----------|-------|")
    for name, value in sorted(props.items()):
        val_str = json.dumps(value, default=str)
        if len(val_str) > 80:
            val_str = val_str[:77] + "..."
        lines.append(f"| `{name}` | `{val_str}` |")

    return "\n".join(lines)
