"""Discovery tools — list services, introspect objects, walk object trees."""

import time
from collections import deque

from fastmcp import Context
from fastmcp.exceptions import ToolError

from mcdbus._bus import call_bus_method, get_mgr, validate_bus_name, validate_object_path
from mcdbus._state import mcp

MAX_TREE_DEPTH = 20
MAX_TREE_NODES = 500
TOTAL_WALK_TIMEOUT = 60  # seconds — monotonic clock deadline for tree walks


@mcp.tool()
async def list_services(
    bus: str,
    ctx: Context,
    include_unique: bool = False,
) -> str:
    """List well-known D-Bus service names on a bus.

    Args:
        bus: "session" or "system"
        include_unique: include unique connection names like :1.42 (default False)
    """
    mgr = get_mgr(ctx)
    await ctx.info(f"Connecting to {bus} bus...")
    connection = await mgr.get_bus(bus)

    try:
        result = await call_bus_method(
            connection,
            destination="org.freedesktop.DBus",
            path="/org/freedesktop/DBus",
            interface="org.freedesktop.DBus",
            member="ListNames",
        )
    except (RuntimeError, TimeoutError) as exc:
        raise ToolError(f"Error listing services on {bus} bus: {exc}") from exc

    names = sorted(result[0]) if result else []
    if not include_unique:
        names = [n for n in names if not n.startswith(":")]

    lines = [f"## D-Bus {bus} bus — {len(names)} services\n"]
    for name in names:
        lines.append(f"- `{name}`")

    return "\n".join(lines)


@mcp.tool()
async def introspect(
    bus: str,
    service: str,
    object_path: str,
    ctx: Context,
    include_standard: bool = False,
) -> str:
    """Introspect a D-Bus object to see its interfaces, methods, properties, and signals.

    Args:
        bus: "session" or "system"
        service: service name (e.g. "org.freedesktop.Notifications")
        object_path: object path (e.g. "/org/freedesktop/Notifications")
        include_standard: include standard D-Bus interfaces (Peer, Introspectable, Properties)
    """
    validate_bus_name(service)
    validate_object_path(object_path)

    mgr = get_mgr(ctx)
    await ctx.report_progress(0, 4)
    connection = await mgr.get_bus(bus)

    await ctx.report_progress(1, 4)
    node = await connection.introspect(service, object_path)

    await ctx.report_progress(2, 4)

    standard_ifaces = {
        "org.freedesktop.DBus.Peer",
        "org.freedesktop.DBus.Introspectable",
        "org.freedesktop.DBus.Properties",
        "org.freedesktop.DBus.ObjectManager",
    }

    lines = [f"## `{service}` at `{object_path}`\n"]

    for iface in node.interfaces:
        if not include_standard and iface.name in standard_ifaces:
            continue

        lines.append(f"### Interface: `{iface.name}`\n")

        if iface.methods:
            lines.append("**Methods:**")
            for method in iface.methods:
                in_args = ", ".join(
                    f"{a.name}: {a.signature}" for a in method.in_args
                )
                out_args = ", ".join(
                    f"{a.name}: {a.signature}" for a in method.out_args
                )
                out_str = f" -> {out_args}" if out_args else ""
                lines.append(f"- `{method.name}({in_args}){out_str}`")
            lines.append("")

        if iface.properties:
            lines.append("**Properties:**")
            for prop in iface.properties:
                access = getattr(prop.access, "name", str(prop.access)).lower()
                lines.append(
                    f"- `{prop.name}`: `{prop.signature}` ({access})"
                )
            lines.append("")

        if iface.signals:
            lines.append("**Signals:**")
            for signal in iface.signals:
                sig_args = ", ".join(
                    f"{a.name}: {a.signature}" for a in signal.args
                )
                lines.append(f"- `{signal.name}({sig_args})`")
            lines.append("")

    # Show child nodes if any
    if node.nodes:
        lines.append("**Child nodes:**")
        for child in node.nodes:
            child_path = object_path.rstrip("/") + "/" + child.name
            lines.append(f"- `{child_path}`")
        lines.append("")

    await ctx.report_progress(4, 4)
    return "\n".join(lines)


@mcp.tool()
async def list_objects(
    bus: str,
    service: str,
    ctx: Context,
    root_path: str = "/",
    max_depth: int = MAX_TREE_DEPTH,
) -> str:
    """Recursively walk the D-Bus object tree for a service (BFS, bounded).

    Args:
        bus: "session" or "system"
        service: service name
        root_path: starting path (default "/")
        max_depth: maximum tree depth to walk (default 20)
    """
    validate_bus_name(service)
    validate_object_path(root_path)

    mgr = get_mgr(ctx)
    connection = await mgr.get_bus(bus)

    paths: list[tuple[str, list[str]]] = []
    visited: set[str] = set()
    queue: deque[tuple[str, int]] = deque([(root_path, 0)])
    truncated = False
    deadline = time.monotonic() + TOTAL_WALK_TIMEOUT

    while queue:
        if time.monotonic() > deadline:
            truncated = True
            await ctx.warning(f"Tree walk timed out after {TOTAL_WALK_TIMEOUT}s")
            break

        path, depth = queue.popleft()

        if path in visited:
            continue
        visited.add(path)

        if len(paths) >= MAX_TREE_NODES:
            truncated = True
            break

        try:
            node = await connection.introspect(service, path)
        except Exception as exc:
            await ctx.warning(f"Could not introspect {path}: {exc}")
            continue

        iface_names = [i.name for i in node.interfaces]
        paths.append((path, iface_names))
        await ctx.report_progress(len(paths), None)

        if depth < max_depth:
            for child in node.nodes:
                child_path = path.rstrip("/") + "/" + child.name
                queue.append((child_path, depth + 1))

    header = f"## Object tree for `{service}` on {bus} bus — {len(paths)} objects"
    if truncated:
        header += f" (truncated at {MAX_TREE_NODES})"
    lines = [header + "\n"]

    for path, ifaces in sorted(paths):
        std_prefix = "org.freedesktop.DBus."
        iface_str = ", ".join(
            f"`{i}`" for i in ifaces if not i.startswith(std_prefix)
        )
        if iface_str:
            lines.append(f"- `{path}` — {iface_str}")
        else:
            lines.append(f"- `{path}`")

    return "\n".join(lines)
