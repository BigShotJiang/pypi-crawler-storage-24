"""Dynamic MCP resources for browsing D-Bus services."""

from collections import deque
from urllib.parse import unquote

from mcdbus._bus import BusManager, call_bus_method, validate_bus_name, validate_object_path
from mcdbus._state import mcp

MAX_RESOURCE_NODES = 200

_resource_mgr = BusManager()


@mcp.resource("dbus://{bus}/services")
async def bus_services(bus: str) -> str:
    """Live list of well-known service names on a D-Bus bus."""
    connection = await _resource_mgr.get_bus(bus)
    result = await call_bus_method(
        connection,
        destination="org.freedesktop.DBus",
        path="/org/freedesktop/DBus",
        interface="org.freedesktop.DBus",
        member="ListNames",
    )
    names = sorted(n for n in (result[0] if result else []) if not n.startswith(":"))
    return "\n".join(names)


@mcp.resource("dbus://{bus}/{service}/objects")
async def service_objects(bus: str, service: str) -> str:
    """Object tree for a D-Bus service (bounded BFS walk)."""
    validate_bus_name(service)
    connection = await _resource_mgr.get_bus(bus)
    paths: list[str] = []
    visited: set[str] = set()
    queue: deque[tuple[str, int]] = deque([("/", 0)])

    while queue and len(paths) < MAX_RESOURCE_NODES:
        path, depth = queue.popleft()
        if path in visited:
            continue
        visited.add(path)

        try:
            node = await connection.introspect(service, path)
        except (RuntimeError, OSError):
            continue

        paths.append(path)
        if depth < 15:
            for child in node.nodes:
                child_path = path.rstrip("/") + "/" + child.name
                queue.append((child_path, depth + 1))

    return "\n".join(sorted(paths))


@mcp.resource("dbus://{bus}/{service}/{path}/interfaces")
async def object_interfaces(bus: str, service: str, path: str) -> str:
    """Interfaces available at a D-Bus object path."""
    decoded_path = unquote(path)
    if not decoded_path.startswith("/"):
        decoded_path = "/" + decoded_path

    validate_bus_name(service)
    validate_object_path(decoded_path)

    connection = await _resource_mgr.get_bus(bus)
    node = await connection.introspect(service, decoded_path)
    return "\n".join(i.name for i in node.interfaces)
