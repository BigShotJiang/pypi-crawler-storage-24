"""Tests for MaskClient.sync_policy() governance integration."""

import os
import json
import pytest
from unittest.mock import patch, MagicMock
from http.server import HTTPServer, BaseHTTPRequestHandler
import threading

from mask.core.exceptions import MaskPolicyError


class _PolicyHandler(BaseHTTPRequestHandler):
    """Tiny HTTP handler that serves a fake policy JSON."""

    response_body = json.dumps({
        "supported_entities": ["EMAIL_ADDRESS", "PHONE_NUMBER", "PERSON", "CREDIT_CARD"]
    }).encode()

    def do_GET(self):
        if self.path == "/api/v1/policies":
            # Verify the tenant header is present (it should be, even if None if we sent it)
            # Actually, os.environ.get("MASK_TENANT_ID") will return None if not set.
            # urllib.request.Request headers can handle None but it might be better to check it.
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(self.response_body)
        else:
            self.send_response(404)
            self.end_headers()

    def log_message(self, *args):  # suppress noisy logs
        pass


@pytest.fixture()
def policy_server():
    """Start a throwaway HTTP server that serves policy JSON."""
    server = HTTPServer(("127.0.0.1", 0), _PolicyHandler)
    port = server.server_address[1]
    t = threading.Thread(target=server.serve_forever, daemon=True)
    t.start()
    yield f"http://127.0.0.1:{port}"
    server.shutdown()


class TestSyncPolicy:
    """Verify that sync_policy() updates scanner entities from a control plane."""

    def test_sync_policy_updates_entities(self, policy_server):
        """Calling sync_policy() should update the scanner's entity list."""
        from mask.client import MaskClient
        from mask.core.scanner import PresidioScanner

        # Create a mock scanner to avoid loading spaCy
        mock_scanner = MagicMock(spec=PresidioScanner)
        mock_scanner.set_supported_entities = MagicMock()

        client = MaskClient(
            scanner=mock_scanner,
            control_plane_url=policy_server,
            api_key="test-key-123",
        )

        # sync_policy is called in __init__ when control_plane_url is set
        mock_scanner.set_supported_entities.assert_called_once_with(
            ["EMAIL_ADDRESS", "PHONE_NUMBER", "PERSON", "CREDIT_CARD"]
        )

    def test_sync_policy_manual_call(self, policy_server):
        """Manually calling sync_policy() should also work."""
        from mask.client import MaskClient
        from mask.core.scanner import PresidioScanner

        mock_scanner = MagicMock(spec=PresidioScanner)
        mock_scanner.set_supported_entities = MagicMock()

        # Create without control_plane_url first
        client = MaskClient(scanner=mock_scanner)
        assert mock_scanner.set_supported_entities.call_count == 0

        # Now set the URL and call manually
        client.control_plane_url = policy_server
        client.api_key = "test-key"
        client.sync_policy()

        mock_scanner.set_supported_entities.assert_called_once()


class TestSyncPolicyFailStrategy:
    """Verify sync_policy respects MASK_FAIL_STRATEGY."""

    def test_fail_closed_raises_policy_error(self):
        """When MASK_FAIL_STRATEGY=closed, a network error should raise MaskPolicyError."""
        from mask.client import MaskClient
        from mask.core.scanner import PresidioScanner

        mock_scanner = MagicMock(spec=PresidioScanner)

        with patch.dict(os.environ, {"MASK_FAIL_STRATEGY": "closed"}):
            with pytest.raises(MaskPolicyError):
                MaskClient(
                    scanner=mock_scanner,
                    control_plane_url="http://127.0.0.1:1",  # unreachable
                    api_key="key",
                )

    def test_fail_open_continues_on_error(self):
        """When MASK_FAIL_STRATEGY=open, a network error should log and continue."""
        from mask.client import MaskClient
        from mask.core.scanner import PresidioScanner

        mock_scanner = MagicMock(spec=PresidioScanner)

        with patch.dict(os.environ, {"MASK_FAIL_STRATEGY": "open"}):
            # Should NOT raise
            client = MaskClient(
                scanner=mock_scanner,
                control_plane_url="http://127.0.0.1:1",  # unreachable
                api_key="key",
            )
            # Scanner entities should NOT have been updated
            mock_scanner.set_supported_entities.assert_not_called()
