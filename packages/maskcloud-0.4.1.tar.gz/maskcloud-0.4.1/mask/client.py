"""
Explicit Client initialization for the Mask SDK.

Provides ``MaskClient`` — a unified, explicitly-configured client that
bundles vault, crypto, scanner, and audit logger into a single object.
"""

import os
import logging
import json
import urllib.request
import urllib.error
from typing import Optional, Dict, Any

from mask.core.vault import get_vault, BaseVault, _hash_plaintext, detokenize_text
from mask.core.crypto import get_crypto_engine, CryptoEngine
from mask.core.scanner import get_scanner, PresidioScanner
from mask.core.fpe import generate_fpe_token, looks_like_token
from mask.telemetry.audit_logger import get_audit_logger, AuditLogger

logger = logging.getLogger("mask.client")


class MaskClient:
    """Explicitly configured Mask SDK client.

    Using this client avoids global singleton state conflicts, making it
    suitable for multi-tenant applications or environments with complex
    VPC boundaries.

    Usage::

        from mask import MaskClient
        client = MaskClient(ttl=300)
        token = client.encode("user@example.com")
        plaintext = client.decode(token)
        safe_text = client.scan_and_tokenize("Call me at 555-123-4567")
    """

    def __init__(
        self,
        vault: Optional[BaseVault] = None,
        crypto: Optional[CryptoEngine] = None,
        scanner: Optional[PresidioScanner] = None,
        audit_logger: Optional[AuditLogger] = None,
        ttl: int = 600,
        control_plane_url: Optional[str] = None,
        api_key: Optional[str] = None,
    ) -> None:
        """Initialise the client with specific component instances.

        If an instance is not provided, the client will fall back to
        the standard environment-configured singleton for that component.

        Args:
            control_plane_url: URL of the Mask Control Plane for governance
                policy sync. If set, ``sync_policy()`` is called on init.
            api_key: API key for authenticating with the control plane.
        """
        self.vault = vault or get_vault()
        self.crypto = crypto or get_crypto_engine()
        self.scanner = scanner or get_scanner()
        self.audit_logger = audit_logger or get_audit_logger()
        self.logger = self.audit_logger  # backward compat alias
        self.ttl = ttl
        self.control_plane_url = control_plane_url
        self.api_key = api_key

        # Ensure the audit logger is running
        self.audit_logger.start()

        # If a control plane is configured, sync policy on startup
        if self.control_plane_url:
            self.sync_policy()

    # -- Governance policy sync -------------------------------------------

    def sync_policy(self) -> None:
        """Fetch the entity policy from the control plane and update the scanner.

        On network errors, behaviour depends on ``MASK_FAIL_STRATEGY``:
        - ``"open"``  (default): logs a warning and continues with existing entities.
        - ``"closed"``: raises ``MaskPolicyError``.
        """
        from mask.core.exceptions import MaskPolicyError

        if not self.control_plane_url:
            return

        url = f"{self.control_plane_url.rstrip('/')}/api/v1/policies"
        headers = {"Content-Type": "application/json"}
        tenant_id = os.environ.get("MASK_TENANT_ID")
        if tenant_id:
            headers["X-Tenant-ID"] = tenant_id
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"

        try:
            req = urllib.request.Request(url, headers=headers, method="GET")
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            entities = data.get("supported_entities", [])
            if entities:
                self.scanner.set_supported_entities(entities)
                logger.info("Policy synced: %d entities from control plane", len(entities))
        except Exception as exc:
            fail_strategy = os.environ.get("MASK_FAIL_STRATEGY", "open").lower()
            if fail_strategy == "closed":
                raise MaskPolicyError(
                    f"Failed to sync policy from {url}: {exc}"
                ) from exc
            logger.warning("Policy sync failed (fail-open): %s", exc)

    def encode(self, raw_text: str) -> str:
        """Tokenise *raw_text*, encrypt it, and store it in the vault.

        Includes deduplication: if the same plaintext has been encoded
        before and the token is still active, the existing token is returned.
        """
        # Token Guard: never re-encode a value that is already a Mask token
        if looks_like_token(raw_text):
            return raw_text

        # Normalise whitespace so " Alice " and "Alice" share the same hash
        raw_text = raw_text.strip()

        pt_hash = _hash_plaintext(raw_text)

        # 1. Deduplication check
        existing_token = self.vault.get_token_by_plaintext_hash(pt_hash)
        if existing_token and self.vault.retrieve(existing_token) is not None:
            self.logger.log("encode", existing_token, "opaque")
            return existing_token

        # 2. Generate deterministic token
        token = generate_fpe_token(raw_text)

        # 3. Encrypt
        ciphertext = self.crypto.encrypt(raw_text)

        # 4. Store with reverse lookup hash
        self.vault.store(token, ciphertext, self.ttl, pt_hash=pt_hash)

        self.logger.log("encode", token, "opaque")
        return token

    def decode(self, token: str) -> str:
        """Retrieve token from vault and decrypt it."""
        ciphertext = self.vault.retrieve(token)
        if ciphertext is None:
            self.logger.log("expired", token, "opaque")
            return token

        try:
            plaintext = self.crypto.decrypt(ciphertext)
            self.logger.log("decode", token, "opaque")
            return plaintext
        except Exception:
            self.logger.log("error", token, "opaque", error="decryption_failed")
            return token

    def scan_and_tokenize(self, text: str) -> str:
        """Scan text using the Waterfall pipeline and replace PII with FPE tokens."""
        return self.scanner.scan_and_tokenize(text, encode_fn=self.encode)

    async def aencode(self, raw_text: str) -> str:
        """Async wrapper for ``encode()``."""
        import asyncio
        return await asyncio.to_thread(self.encode, raw_text)

    async def adecode(self, token: str) -> str:
        """Async wrapper for ``decode()``."""
        import asyncio
        return await asyncio.to_thread(self.decode, token)

    async def ascan_and_tokenize(self, text: str) -> str:
        """Async wrapper for ``scan_and_tokenize()``."""
        import asyncio
        return await asyncio.to_thread(self.scan_and_tokenize, text)

    def detokenize_text(self, text: str) -> str:
        """Find and replace all tokens within *text* with their plaintext."""
        return detokenize_text(text)

    async def adetokenize_text(self, text: str) -> str:
        """Async wrapper for ``detokenize_text()``."""
        import asyncio
        return await asyncio.to_thread(self.detokenize_text, text)
