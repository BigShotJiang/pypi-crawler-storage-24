"""Die templates matching the HHI design manual (Section 8.2.3).

RFconnect templates: DC pads (north/south) + optional GSG pads (west) + SSCs (east).
PIConnect templates: DC pads (north/south).

Geometry reverse-engineered from reference GDS in tests/ref_templates/.
"""

from __future__ import annotations

import gdsfactory as gf
import numpy as np
from gdsfactory.typings import ComponentSpec

from hhi.cells.die import die, edge_coupler_with_angle, pad, pad_GSG
from hhi.tech import LAYER

# ---------------------------------------------------------------------------
# RFconnect
# ---------------------------------------------------------------------------
# Fixed geometry from reference GDS (all sizes share these constants)
_RF_DC_PAD_FIRST_X = 3231  # center x of first DC pad
_RF_DC_PAD_BOT_Y = 183  # center y of bottom row pads
_RF_DC_PAD_TOP_OFFSET = 183  # top row center y = H - this value
_RF_GSG_PAD_X = 152  # bottom-left x of GSG pads
_RF_SSC_X = 6800  # = 8000 - 1200 (SSC length)
_RF_SSC_HALF_SPAN = 644  # half-height of SSC area from die center
_RF_PERIM_PAD_X_LEFT = 3158  # PERIMETER notch left x for DC pads
_RF_PERIM_PAD_X_RIGHT = 6604  # PERIMETER notch right x for DC pads
_RF_PERIM_PAD_NOTCH_Y = 276  # PERIMETER notch y (symmetric top/bottom)


@gf.cell
def die_rfconnect(
    size: tuple[float, float] = (2000, 8000),
    pad_type: str = "GSG",
    ssc_angle: float = 0,
    num_dc_pads: int = 23,
    dc_pad_pitch: float = 150.0,
    dc_pad_size: tuple[float, float] = (102, 142),
    num_gsg_pads: int | None = None,
    gsg_pad_pitch: float = 500.0,
    num_sscs: int = 10,
    ssc: ComponentSpec | tuple[ComponentSpec, ...] = "HHI_SSCLATE1700",
    ssc_spacing: float = 127.0,
    hhi_id: bool | tuple[float, float] = True,
    annotate: bool = True,
) -> gf.Component:
    """RFconnect die template per design manual Section 8.2.3.

    Args:
        size: Die size (height, width) in µm — e.g. (2000, 8000) for 2×8mm.
        pad_type: "GSG" for GSG+DC pads, "DC" for DC-only.
        ssc_angle: SSC facet angle in degrees (0 or 7).
        num_dc_pads: Number of DC pads per row (north and south).
        dc_pad_pitch: Pitch between DC pads.
        dc_pad_size: Size of each DC pad.
        num_gsg_pads: Number of GSG pads (auto-calculated if None).
        gsg_pad_pitch: Pitch between GSG pads.
        num_sscs: Number of SSCs on east side.
        ssc: SSC component spec — a single name applies to all positions,
            or a tuple of names (one per position) for mixed SSC types.
            Available: "HHI_SSCLATE1700", "HHI_SSCLATE200".
        ssc_spacing: Pitch between SSCs.
        hhi_id: False to omit, True for default position, or (x, y) tuple.
        annotate: Add direction labels (NORTH/SOUTH/EAST/WEST) and SSC labels.
    """
    H, W = size
    c = gf.Component()

    # Put hhi_id in top right
    if hhi_id is True:
        hhi_id = (W - 150, H - 150)

    # --- Die boundary (FLOORPLAN border + cleave marks) ---
    c << die(size=(W, H), fill=False, hhi_id=hhi_id)

    # --- DC pads (north and south rows) ---
    dc_pad = pad(size=dc_pad_size)
    bot_y = _RF_DC_PAD_BOT_Y
    top_y = H - _RF_DC_PAD_TOP_OFFSET
    for i in range(num_dc_pads):
        x = _RF_DC_PAD_FIRST_X + i * dc_pad_pitch
        # Bottom row
        pb = c << dc_pad
        pb.move((x, bot_y))
        c.add_port(name=f"bot_dc_{i + 1}", port=pb.ports["e2"])
        # Top row
        pt = c << dc_pad
        pt.move((x, top_y))
        c.add_port(name=f"top_dc_{i + 1}", port=pt.ports["e4"])

    # --- GSG pads (west side, only for pad_type="GSG") ---
    if pad_type == "GSG":
        gsg_pad = pad_GSG(xsize=96)
        gsg_h = gsg_pad.ysize
        if num_gsg_pads is None:
            num_gsg_pads = min(8, 1 + int((H - 2 * 68 - gsg_h) / gsg_pad_pitch))
        gsg_y_center = H / 2
        for i in range(num_gsg_pads):
            y = gsg_y_center + (i - (num_gsg_pads - 1) / 2) * gsg_pad_pitch
            g = c << gsg_pad
            g.move((_RF_GSG_PAD_X, y))
            c.add_port(name=f"gsg_{i + 1}", port=g.ports["e2"])

    # --- SSCs (east side) ---
    # Normalize ssc to a per-position list
    if isinstance(ssc, (list | tuple)):
        sscs = list(ssc)
        if len(sscs) != num_sscs:
            raise ValueError(
                f"ssc list length ({len(sscs)}) must match num_sscs ({num_sscs})"
            )
    else:
        sscs = [ssc] * num_sscs

    ssc_pitch = ssc_spacing + 4.922 if ssc_angle != 0 else ssc_spacing
    ssc_center_y = H / 2
    ssc_length = 1200
    ssc_y_start = ssc_center_y - (num_sscs - 1) * ssc_pitch / 2
    ssc_y_offset = ssc_length / 2 * np.sin(np.radians(ssc_angle))
    ssc_labels = ["PD_SO"] + [f"OPT{i}" for i in range(1, num_sscs - 1)] + ["PD_NO"]
    ssc_text_labels = (
        ["PD SO"] + [f"OPT{i}" for i in range(1, num_sscs - 1)] + ["PD NO"]
    )
    angle_arg = ssc_angle if ssc_angle != 0 else None

    for i, (ssc_spec, label, text_label) in enumerate(
        zip(sscs, ssc_labels, ssc_text_labels)
    ):
        ec = edge_coupler_with_angle(
            angle=angle_arg, edge_coupler=ssc_spec, include_bend=False
        )
        ref = c.add_ref_off_grid(ec) if ssc_angle != 0 else c << ec
        y = ssc_y_start + i * ssc_pitch + ssc_y_offset
        ref.move((_RF_SSC_X, y))

        inward = [
            p for p in ref.ports if p.port_type == "optical" and p.center[0] < W - 500
        ]
        if inward:
            port = min(inward, key=lambda p: p.center[0])
            c.add_port(name=label, port=port)
            t = c << gf.c.text(
                text=text_label, size=20, layer=LAYER.BB_outline, justify="left"
            )
            t.move((_RF_SSC_X - 85, port.center[1] - 50))

    # --- PERIMETER polygon (layer 9) ---
    # Left edge depends on pad_type
    left_x = 252 if pad_type == "GSG" else 50
    margin = 50
    ssc_top = ssc_center_y + _RF_SSC_HALF_SPAN
    ssc_bot = ssc_center_y - _RF_SSC_HALF_SPAN
    perimeter = [
        (left_x, margin),
        (left_x, H - margin),
        (_RF_PERIM_PAD_X_LEFT, H - margin),
        (_RF_PERIM_PAD_X_LEFT, H - _RF_PERIM_PAD_NOTCH_Y),
        (_RF_PERIM_PAD_X_RIGHT, H - _RF_PERIM_PAD_NOTCH_Y),
        (_RF_PERIM_PAD_X_RIGHT, H - margin),
        (W - margin, H - margin),
        (W - margin, ssc_top),
        (_RF_SSC_X, ssc_top),
        (_RF_SSC_X, ssc_bot),
        (W - margin, ssc_bot),
        (W - margin, margin),
        (_RF_PERIM_PAD_X_RIGHT, margin),
        (_RF_PERIM_PAD_X_RIGHT, _RF_PERIM_PAD_NOTCH_Y),
        (_RF_PERIM_PAD_X_LEFT, _RF_PERIM_PAD_NOTCH_Y),
        (_RF_PERIM_PAD_X_LEFT, margin),
    ]
    c.add_polygon(perimeter, layer=LAYER.PERIMETER)

    # --- Direction labels (BB_text, layer 59) ---
    if annotate:
        text_size = 300
        # SOUTH/NORTH y changes with die height (observed from reference GDS)
        ns_offset = 531 if H <= 2000 else 831
        for label, cx, cy in [
            ("WEST", 1370, H / 2),
            ("EAST", 6181, H / 2),
            ("SOUTH", W / 2, ns_offset - 1),
            ("NORTH", W / 2, H - ns_offset),
        ]:
            t = c << gf.c.text(
                text=label, size=text_size, layer=LAYER.BB_text, justify="center"
            )
            t.move((cx, cy - text_size / 2))

    return c


# ---------------------------------------------------------------------------
# PIConnect
# ---------------------------------------------------------------------------
# Pin label convention from design manual Chapter 7.4, Table 7.1.
# 48 pads = mainboard pins 3-50. GND always on odd pins, signal on even pins.
_PI_LABELS = [
    "GND",
    "I_OUT1",
    "GND",
    "I_OUT2",
    "GND",
    "I_OUT3",
    "GND",
    "I_OUT4",
    "GND",
    "I_OUT5",
    "GND",
    "I_OUT6",
    "GND",
    "I_OUT7",
    "GND",
    "I_OUT8",
    "GND",
    "V_OUT1",
    "GND",
    "V_OUT2",
    "GND",
    "V_OUT3",
    "GND",
    "V_OUT4",
    "GND",
    "V_OUT5",
    "GND",
    "V_OUT6",
    "GND",
    "V_OUT7",
    "GND",
    "V_OUT8",
    "GND",
    "LDA 1",
    "LD1\nGND",
    "PDA 1",
    "GND",
    "LDA 2",
    "LD2\nGND",
    "PDA 2",
    "GND",
    "LDA 3",
    "LD3\nGND",
    "PDA 3",
    "GND",
    "LDA 4",
    "LD4\nGND",
    "PDA 4",
]

_PI_DC_PAD_BOT_FIRST_X = 476.184  # center x of first bottom pad
_PI_DC_PAD_TOP_FIRST_X = 476.569  # center x of first top pad
_PI_DC_PAD_BOT_Y = 233.808  # center y of bottom row pads
_PI_DC_PAD_TOP_OFFSET = 234.501  # top row center y = H - this value


@gf.cell
def die_piconnect(
    size: tuple[float, float] = (2000, 8000),
    num_dc_pads: int = 48,
    dc_pad_pitch: float = 150.0,
    dc_pad_size: tuple[float, float] = (102, 142),
    hhi_id: bool | tuple[float, float] = True,
    annotate: bool = True,
) -> gf.Component:
    """PIConnect die template per design manual Section 8.2.3.

    Args:
        size: Die size (height, width) in µm — e.g. (2000, 8000) for 2x8mm.
        num_dc_pads: Number of DC pads per north/south row.
        dc_pad_pitch: Pitch between DC pads.
        dc_pad_size: Size of each DC pad.
        hhi_id: False to omit, True for default position, or (x, y) tuple.
        annotate: Add direction labels (NORTH/SOUTH/EAST/WEST) and IO type labels.
    """
    H, W = size
    c = gf.Component()

    # Put hhi_id in top right
    if hhi_id is True:
        hhi_id = (W - 150, H - 150)

    # --- Die boundary (FLOORPLAN border + cleave marks) ---
    c << die(size=(W, H), fill=False, hhi_id=hhi_id)

    # --- DC pads (north and south rows) ---
    dc_pad = pad(size=dc_pad_size)
    bot_y = _PI_DC_PAD_BOT_Y
    top_y = H - _PI_DC_PAD_TOP_OFFSET

    for i in range(num_dc_pads):
        j = num_dc_pads - 1 - i  # reversed index for bottom row
        pin_bot = j + 3  # mainboard pin number (ensures uniqueness for GND pads)
        pin_top = i + 3
        sig_bot = _PI_LABELS[j].split("\n")[0].replace(" ", "_")
        sig_top = _PI_LABELS[i].split("\n")[0].replace(" ", "_")
        # Bottom row
        x_bot = _PI_DC_PAD_BOT_FIRST_X + i * dc_pad_pitch
        pb = c << dc_pad
        pb.move((x_bot, bot_y))
        c.add_port(name=f"bot_{sig_bot}_pin{pin_bot}", port=pb.ports["e2"])
        # Top row (different x offset)
        x_top = _PI_DC_PAD_TOP_FIRST_X + i * dc_pad_pitch
        pt = c << dc_pad
        pt.move((x_top, top_y))
        c.add_port(name=f"top_{sig_top}_pin{pin_top}", port=pt.ports["e4"])

    # --- Direction labels (BB_outline, layer 55) and IO type labels ---
    if annotate:
        text_size = 300
        ns_offset = 531 if H <= 2000 else 831
        for label, cx, cy in [
            ("WEST", 1370, H / 2),
            ("EAST", 6181, H / 2),
            ("SOUTH", W / 2, ns_offset - 1),
            ("NORTH", W / 2, H - ns_offset),
        ]:
            t = c << gf.c.text(
                text=label, size=text_size, layer=LAYER.BB_outline, justify="center"
            )
            t.move((cx, cy - text_size / 2))

        io_size = 100
        io_text = gf.c.text(
            text="OPTICAL OR RF IO",
            size=io_size,
            layer=LAYER.BB_outline,
            justify="center",
        )
        for angle, x_center in [(90, 60 + io_size / 2), (-90, W - 60 - io_size / 2)]:
            t = c << io_text
            t.rotate(angle)
            t.center = (x_center, H / 2)

    # --- Pad labels (layer 24 = TEXT) ---
    # Bottom row: reversed label order (rightmost pad = pin 3, leftmost = pin 50)
    # Top row: normal order, rotated 180°
    signal_y_bot = 129.0
    number_y_bot = 79.0
    label_size = 30
    for i in range(num_dc_pads):
        j = num_dc_pads - 1 - i  # reversed index for bottom row
        x_bot = _PI_DC_PAD_BOT_FIRST_X + i * dc_pad_pitch
        x_top = _PI_DC_PAD_TOP_FIRST_X + i * dc_pad_pitch
        pin_bot = j + 3
        pin_top = i + 3
        # Labels may have "\n" to push a second token to the number row (e.g. "LD3\nGND")
        bot_parts = _PI_LABELS[j].split("\n")
        top_parts = _PI_LABELS[i].split("\n")
        bot_extra = bot_parts[1] if len(bot_parts) > 1 else None
        top_extra = top_parts[1] if len(top_parts) > 1 else None
        # Signal name — bottom row (reversed)
        t = c << gf.c.text(
            text=bot_parts[0], size=label_size, layer=LAYER.TEXT, justify="center"
        )
        t.center = (x_bot, signal_y_bot)
        # Signal name — top row (normal order, rotated 180°)
        t = c << gf.c.text(
            text=top_parts[0], size=label_size, layer=LAYER.TEXT, justify="center"
        )
        t.rotate(180)
        t.center = (x_top, H - signal_y_bot)
        # Number row — bottom: extra token takes priority over pin number
        if bot_extra:
            t = c << gf.c.text(
                text=bot_extra, size=label_size, layer=LAYER.TEXT, justify="center"
            )
            t.center = (x_bot, number_y_bot)
        elif pin_bot % 5 == 0:
            t = c << gf.c.text(
                text=str(pin_bot), size=label_size, layer=LAYER.TEXT, justify="center"
            )
            t.center = (x_bot, number_y_bot)
        # Number row — top: extra token takes priority over pin number
        if top_extra:
            t = c << gf.c.text(
                text=top_extra, size=label_size, layer=LAYER.TEXT, justify="center"
            )
            t.rotate(180)
            t.center = (x_top, H - number_y_bot)
        elif pin_top % 5 == 0:
            t = c << gf.c.text(
                text=str(pin_top), size=label_size, layer=LAYER.TEXT, justify="center"
            )
            t.rotate(180)
            t.center = (x_top, H - number_y_bot)

    return c
