__version__ = '3.11.2'  # DON'T TOUCH. Placeholder. Will be filled automatically on poetry build from Git Tag
