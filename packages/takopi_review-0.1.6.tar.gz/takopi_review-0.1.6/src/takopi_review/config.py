from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from takopi.api import ConfigError

from takopi_review.models import ReviewerSpec

DEFAULT_SPECIALIST_ENGINES = ("codex",)
DEFAULT_GENERAL_ENGINES = ("codex", "claude")


def _reviewer_lane(
    *,
    lane_id: str,
    role: str,
    objective: str,
    phase: str,
    engines: tuple[str, ...] = DEFAULT_SPECIALIST_ENGINES,
) -> tuple[ReviewerSpec, ...]:
    selected_engines = tuple(engines) or ("codex",)
    return tuple(
        ReviewerSpec(
            engine=engine,
            reviewer_id=f"{lane_id}-{engine}",
            artifact_name=f"{lane_id}-{engine}",
            role=role,
            objective=objective,
            phase=phase,
        )
        for engine in selected_engines
    )


def _expect_bool(config: dict[str, Any], key: str, default: bool) -> bool:
    raw = config.get(key, default)
    if isinstance(raw, bool):
        return raw
    raise ConfigError(f"Invalid `plugins.review.{key}`; expected a boolean.")


def _expect_int(config: dict[str, Any], key: str, default: int) -> int:
    raw = config.get(key, default)
    if isinstance(raw, bool) or not isinstance(raw, int):
        raise ConfigError(f"Invalid `plugins.review.{key}`; expected an integer.")
    return raw


def _expect_str(config: dict[str, Any], key: str, default: str) -> str:
    raw = config.get(key, default)
    if isinstance(raw, str) and raw.strip():
        return raw.strip()
    raise ConfigError(f"Invalid `plugins.review.{key}`; expected a non-empty string.")


def _reject_removed_key(config: dict[str, Any], key: str) -> None:
    if key in config:
        raise ConfigError(
            f"`plugins.review.{key}` was removed. Reviewer roles are now repo-owned defaults."
        )


DEFAULT_SPECIALIST_REVIEWERS = (
    _reviewer_lane(
        lane_id="security-best-practices",
        role="security-best-practices",
        objective="repo-local security-best-practices guidance across detected languages and frameworks",
        phase="specialist",
    )
    + _reviewer_lane(
        lane_id="typechecker",
        role="typechecker",
        objective="type safety, interface drift, nullability, and compiler-facing regressions",
        phase="specialist",
    )
    + _reviewer_lane(
        lane_id="correctness-simplicity",
        role="correctness-simplicity",
        objective="eliminate stale branching and fallback logic while tightening correctness, control flow, and error handling",
        phase="specialist",
    )
    + _reviewer_lane(
        lane_id="tests",
        role="tests",
        objective="regression coverage, negative-path testing, and brittle test design",
        phase="specialist",
    )
    + _reviewer_lane(
        lane_id="regression-checker",
        role="regression-checker",
        objective="identify behavior drift, contract breaks, changed defaults, and missing regression protection",
        phase="specialist",
    )
    + _reviewer_lane(
        lane_id="integration-contracts",
        role="integration-contracts",
        objective="identify API, schema, config, and persisted-data contract drift at system boundaries",
        phase="specialist",
    )
)

DEFAULT_FRONTEND_REVIEWERS = _reviewer_lane(
    lane_id="react-vercel",
    role="react-vercel",
    objective="React and Next.js performance, bundle shape, hydration, and server/client boundaries",
    phase="specialist",
)

DEFAULT_SPEC_REVIEWERS = _reviewer_lane(
    lane_id="spec-reviewer",
    role="spec-reviewer",
    objective="compare implementation changes against spec documents committed in the change and flag requirement drift or omissions",
    phase="specialist",
)

DEFAULT_GENERAL_REVIEWERS = _reviewer_lane(
    lane_id="code-review-excellence",
    role="code-review-excellence",
    objective="broad code review for correctness, security, maintainability, and test risk",
    phase="specialist",
    engines=DEFAULT_GENERAL_ENGINES,
)

DEFAULT_LEAD_REVIEWER = _reviewer_lane(
    lane_id="code-review-excellence-lead",
    role="code-review-excellence",
    objective="validate, deduplicate, and rank specialist findings using installed code review guidance",
    phase="lead",
    engines=("codex",),
)[0]


@dataclass(frozen=True, slots=True)
class ReviewConfig:
    specialist_reviewers: tuple[ReviewerSpec, ...] = DEFAULT_SPECIALIST_REVIEWERS
    frontend_reviewers: tuple[ReviewerSpec, ...] = DEFAULT_FRONTEND_REVIEWERS
    spec_reviewers: tuple[ReviewerSpec, ...] = DEFAULT_SPEC_REVIEWERS
    general_reviewers: tuple[ReviewerSpec, ...] = DEFAULT_GENERAL_REVIEWERS
    lead_reviewer: ReviewerSpec = DEFAULT_LEAD_REVIEWER
    timeout_s: int = 900
    max_parallel_reviews: int = 8
    require_repo: bool = True
    post_github_comments: bool = True
    report_dir: str = ".takopi/review"
    max_diff_chars: int = 120_000
    max_instruction_chars: int = 20_000
    max_untracked_file_chars: int = 12_000

    @classmethod
    def from_plugin_config(
        cls,
        raw_config: dict[str, Any],
    ) -> ReviewConfig:
        config = dict(raw_config or {})
        _reject_removed_key(config, "reviewers")
        _reject_removed_key(config, "default_fixer")
        _reject_removed_key(config, "auto_fix")

        timeout_s = _expect_int(config, "timeout_s", 900)
        if timeout_s <= 0:
            raise ConfigError("Invalid `plugins.review.timeout_s`; expected > 0.")

        max_parallel_reviews = _expect_int(config, "max_parallel_reviews", 8)
        if max_parallel_reviews <= 0:
            raise ConfigError(
                "Invalid `plugins.review.max_parallel_reviews`; expected > 0."
            )

        return cls(
            timeout_s=timeout_s,
            max_parallel_reviews=max_parallel_reviews,
            require_repo=_expect_bool(config, "require_repo", True),
            post_github_comments=_expect_bool(config, "post_github_comments", True),
            report_dir=_expect_str(config, "report_dir", ".takopi/review"),
        )
