from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any
from typing import Literal

ReviewMode = Literal["diff", "pr", "commit", "request"]
FindingStatus = Literal["accepted", "needs-human-triage", "rejected"]
ReviewPhase = Literal["specialist", "lead"]


@dataclass(frozen=True, slots=True)
class ReviewerSpec:
    engine: str
    reviewer_id: str
    artifact_name: str
    role: str
    objective: str
    phase: ReviewPhase


@dataclass(frozen=True, slots=True)
class InstructionSnippet:
    path: str
    content: str


@dataclass(frozen=True, slots=True)
class ReviewTarget:
    mode: ReviewMode
    reference: str
    repo: str | None
    label: str


@dataclass(frozen=True, slots=True)
class ReviewBundle:
    workspace_root: str
    project: str | None
    branch: str | None
    cwd: str
    has_repo_context: bool
    target: ReviewTarget
    focus_areas: tuple[str, ...]
    inferred_language: str | None
    source_text: str | None
    changed_files: tuple[str, ...]
    test_surface: tuple[str, ...]
    status_text: str
    diff_text: str
    instructions: tuple[InstructionSnippet, ...]
    spec_documents: tuple[InstructionSnippet, ...] = ()


@dataclass(frozen=True, slots=True)
class ReviewFinding:
    reviewer: str
    title: str
    priority: int
    confidence: float
    file: str
    start_line: int
    end_line: int
    summary: str
    suggested_fix: str
    reviewed_code: str = ""
    agent_prompt: str = ""
    source_reviewers: tuple[str, ...] = ()
    status: FindingStatus | None = None
    rationale: str | None = None


@dataclass(frozen=True, slots=True)
class ReviewerOutput:
    reviewer: str
    raw_text: str
    artifact_name: str
    findings: tuple[ReviewFinding, ...] = ()
    testing_gaps: tuple[str, ...] = ()
    summary: str | None = None
    error: str | None = None
    message_extra: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True, slots=True)
class ConsolidatedFinding:
    id: str
    status: FindingStatus
    reviewer_count: int
    reviewers: tuple[str, ...]
    title: str
    priority: int
    confidence: float
    file: str
    start_line: int
    end_line: int
    summary: str
    reviewed_code: str
    suggested_fix: str
    agent_prompt: str
    rationale: str
    occurrences: tuple[ReviewFinding, ...] = ()


@dataclass(frozen=True, slots=True)
class ReviewReport:
    run_id: str
    created_at: str
    bundle: ReviewBundle
    specialist_reviewers: tuple[str, ...]
    lead_reviewer: str | None
    general_reviewers: tuple[str, ...]
    raw_outputs: tuple[ReviewerOutput, ...]
    findings: tuple[ConsolidatedFinding, ...]
    testing_gaps: tuple[str, ...]
    report_path: str
    final_summary: str | None = None
    missing_reviewers: tuple[str, ...] = ()
    github_comment_url: str | None = None
    raw_output_paths: tuple[str, ...] = ()
    final_message_extra: dict[str, Any] = field(default_factory=dict)
