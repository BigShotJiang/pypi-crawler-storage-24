from __future__ import annotations

CODE_REVIEW_EXCELLENCE = """\
# Code Review Excellence

Use this review skill for the final adjudication pass.
Master effective code review practices through grounded, high-signal review output.

Core review goals:
- keep only findings grounded in the actual change
- reject speculative claims and weakly supported guesses
- merge duplicate findings that describe the same root cause
- rank issues by user impact, merge risk, and confidence
- preserve the most actionable final review output

Review standards:
- prefer correctness, security, and maintainability risk over style
- keep feedback concrete and actionable
- differentiate blocking issues from lower-priority follow-up work
- call out missing validation or tests only when the gap creates real bug risk
"""


SECURITY_SKILL_REFERENCES: dict[str, str] = {
    "golang-general-backend-security.md": """\
# Go Backend Security

- Treat every handler, RPC endpoint, webhook, and background job as externally reachable unless the code proves otherwise.
- Verify authorization on every state-changing path, not just at the router boundary.
- Reject invalid input early and avoid relying on zero values as implicit permission or policy defaults.
- Do not leak secrets, tokens, or internal errors through logs, metrics, or returned errors.
- Watch for unsafe concurrency around shared auth/session state and mutable global configuration.
""",
    "javascript-express-web-server-security.md": """\
# Express Security

- Verify auth and authorization inside the route or shared middleware chain that actually guards the handler.
- Validate request bodies, params, and headers before using them in queries, file paths, or downstream RPC calls.
- Treat `req.user`, session values, and decoded tokens as untrusted unless they are freshly validated.
- Reject fail-open middleware orderings where a handler can run before auth, CSRF, or rate-limiting checks.
- Do not expose stack traces, secrets, or unredacted request data in responses or logs.
""",
    "javascript-general-web-frontend-security.md": """\
# Web Frontend Security

- Treat all client-controlled data as untrusted, including URL params, local storage, and postMessage payloads.
- Avoid rendering raw HTML or building DOM sinks from untrusted strings.
- Keep privileged actions behind server-side authorization instead of trusting hidden UI state.
- Watch for token leakage through query strings, logs, analytics payloads, and browser storage.
- Validate cross-origin messaging and third-party embeds before accepting commands or data.
""",
    "javascript-typescript-nextjs-web-server-security.md": """\
# Next.js Server Security

- Verify authorization inside server actions, route handlers, loaders, and revalidation hooks.
- Do not trust client component props or hidden form fields as permission checks.
- Keep secrets and privileged logic on the server side and audit server/client boundary crossings.
- Validate cache invalidation, preview mode, and webhook handlers so untrusted callers cannot mutate state.
- Review redirects, middleware, and headers for open redirect, CSRF, and origin-trust mistakes.
""",
    "javascript-typescript-react-web-frontend-security.md": """\
# React Frontend Security

- Treat component props, router state, and serialized server data as untrusted input.
- Avoid unsafe HTML rendering and client-side auth decisions that can be bypassed outside the UI.
- Keep privileged mutations in server-owned code paths with explicit authorization.
- Check for token leakage through hydration payloads, logs, analytics, and browser storage.
- Audit client/server boundaries, server actions, and fetch wrappers for missing auth propagation.
""",
    "python-django-web-server-security.md": """\
# Django Security

- Verify object-level authorization, not just authentication, on every state-changing view or action.
- Validate serializers, forms, and query params before using them in ORM filters or file operations.
- Review CSRF exemptions, admin endpoints, and management actions for fail-open behavior.
- Do not leak secrets or internal errors through debug responses, logs, or template rendering.
- Check signals, tasks, and model hooks for privileged side effects that bypass normal permission checks.
""",
    "python-fastapi-web-server-security.md": """\
# FastAPI Security

- Enforce auth and authorization in the dependency chain that actually protects the endpoint.
- Validate request models and path/query/header inputs before using them in queries or RPC calls.
- Treat dependency-injected user/session objects as untrusted until verified for the requested resource.
- Avoid returning raw exception text, stack traces, or sensitive request data.
- Review background tasks and startup hooks for privileged actions that bypass request-time checks.
""",
    "python-flask-web-server-security.md": """\
# Flask Security

- Verify auth and authorization inside each route or blueprint path that mutates state.
- Validate request args, form data, JSON bodies, and file uploads before using them.
- Watch for fail-open defaults in decorators, session handling, and proxy/header trust.
- Keep secrets out of templates, logs, flashed messages, and error pages.
- Review Celery tasks, CLI commands, and helper functions for privileged paths that skip the normal request guards.
""",
}
