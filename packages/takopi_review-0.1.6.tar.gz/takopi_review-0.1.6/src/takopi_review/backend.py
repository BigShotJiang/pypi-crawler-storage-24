from __future__ import annotations

from dataclasses import dataclass

from takopi.api import (
    CommandBackend,
    CommandContext,
    CommandResult,
    ConfigError,
    RenderedMessage,
)

from takopi_review.config import ReviewConfig
from takopi_review.orchestrator import (
    ReviewError,
    execute_review,
    plan_review,
    review_report_markdown,
)

_SLACK_COMPLETION_TEXT = "job done"


@dataclass(frozen=True, slots=True)
class ReviewOptions:
    reference: str
    focus_areas: tuple[str, ...]


def _help_text() -> str:
    return "\n".join(
        (
            "review: orchestrate multi-agent code reviews",
            "",
            "Usage:",
            "  /review <request> [--focus <area>]...",
            "",
            "Examples:",
            "  /review python auth middleware in this pasted snippet",
            "  /review the working tree diff --focus security --focus tests",
            "  /review this pr 123 in this repo richardliang/takopi-review",
            "  /review commit abc1234",
        )
    )


def _parse_request_review_options(args: tuple[str, ...]) -> ReviewOptions:
    index = 0
    request_tokens: list[str] = []
    focus_areas: list[str] = []
    while index < len(args):
        token = args[index]
        if token.startswith("--focus="):
            focus_areas.extend(
                value.strip().lower()
                for value in token.split("=", 1)[1].split(",")
                if value.strip()
            )
            index += 1
            continue
        if token == "--focus":
            index += 1
            if index >= len(args):
                raise ConfigError("Missing value for `--focus`.")
            focus_areas.extend(
                value.strip().lower()
                for value in args[index].split(",")
                if value.strip()
            )
            index += 1
            continue
        if token.startswith("--"):
            raise ConfigError(f"Unknown flag {token!r}.")
        request_tokens.append(token)
        index += 1

    request_text = " ".join(request_tokens).strip()
    if not request_text:
        raise ConfigError("Missing review request.")
    return ReviewOptions(
        reference=request_text,
        focus_areas=tuple(dict.fromkeys(focus_areas)),
    )


class ReviewCommand:
    id = "review"
    description = "Run multi-agent reviews"

    async def handle(self, ctx: CommandContext) -> CommandResult | None:
        try:
            return await self._handle(ctx)
        except (ConfigError, ReviewError) as exc:
            return CommandResult(text=f"review error: {exc}")

    async def _handle(self, ctx: CommandContext) -> CommandResult:
        if not ctx.args:
            return CommandResult(text=_help_text())

        subcommand = ctx.args[0].lower()
        if subcommand in {"help", "-h", "--help"}:
            return CommandResult(text=_help_text())
        if subcommand == "fix":
            raise ConfigError("`/review fix` was removed in the hard cutover.")

        options = _parse_request_review_options(ctx.args)
        config = ReviewConfig.from_plugin_config(ctx.plugin_config or {})
        parsed_request = await plan_review(
            ctx,
            request_text=options.reference,
            config=config,
        )
        report = await execute_review(
            ctx,
            parsed_request=parsed_request,
            focus_areas=options.focus_areas,
            config=config,
        )
        if config.post_github_comments and report.bundle.target.mode == "pr":
            if report.final_message_extra:
                await ctx.executor.send(
                    RenderedMessage(
                        text=_SLACK_COMPLETION_TEXT,
                        extra=report.final_message_extra,
                    ),
                    reply_to=ctx.message,
                )
                return None
            return CommandResult(text=_SLACK_COMPLETION_TEXT)
        if report.final_message_extra:
            await ctx.executor.send(
                RenderedMessage(
                    text=review_report_markdown(report),
                    extra=report.final_message_extra,
                ),
                reply_to=ctx.message,
            )
            return None
        return CommandResult(text=review_report_markdown(report))


BACKEND: CommandBackend = ReviewCommand()
