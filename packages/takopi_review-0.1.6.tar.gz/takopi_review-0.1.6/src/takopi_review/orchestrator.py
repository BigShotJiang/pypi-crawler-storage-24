from __future__ import annotations

import asyncio
import base64
import binascii
import json
import re
import shutil
import subprocess
import textwrap
import uuid
from dataclasses import asdict, dataclass, replace
from datetime import UTC, datetime
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any
from urllib.parse import quote

from takopi.api import CommandContext, RunContext, RunRequest

from takopi_review.config import ReviewConfig
from takopi_review.models import (
    ConsolidatedFinding,
    FindingStatus,
    InstructionSnippet,
    ReviewBundle,
    ReviewFinding,
    ReviewReport,
    ReviewerSpec,
    ReviewerOutput,
    ReviewTarget,
)
from takopi_review.review_skills import (
    CODE_REVIEW_EXCELLENCE,
    SECURITY_SKILL_REFERENCES,
)

_CODE_FENCE_RE = re.compile(r"```(?:json)?\s*(.*?)```", re.DOTALL | re.IGNORECASE)
_WORD_RE = re.compile(r"[a-z0-9]+")
_GITHUB_REPO_RE = re.compile(
    r"(?:https?://github\.com/)?(?P<repo>[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)",
    re.IGNORECASE,
)
_PR_URL_RE = re.compile(
    r"https?://github\.com/(?P<repo>[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)/pull/(?P<reference>\d+)",
    re.IGNORECASE,
)
_COMMIT_URL_RE = re.compile(
    r"https?://github\.com/(?P<repo>[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+)/commit/(?P<reference>[0-9a-f]{7,40})",
    re.IGNORECASE,
)
_PR_REF_RE = re.compile(r"\b(?:pr|pull\s+request)\s+#?(?P<reference>\d+)\b", re.IGNORECASE)
_COMMIT_REF_RE = re.compile(
    r"\bcommit\s+(?P<reference>[0-9a-f]{7,40})\b",
    re.IGNORECASE,
)
_REPO_HINT_RE = re.compile(
    r"\b(?:in|from)\s+(?:this\s+)?repo(?:sitory)?\s+(?P<repo>\S+)",
    re.IGNORECASE,
)
_SPEC_PATH_HINT_RE = re.compile(
    r"(?<![a-z0-9])(?:spec|specs|prd|prds|requirements?|proposal|design|rfcs?|acceptance(?:[-_ ]criteria)?)(?![a-z0-9])",
    re.IGNORECASE,
)
_TEST_FILE_PATTERNS = (
    "test_{stem}.py",
    "{stem}_test.py",
    "{stem}.test.ts",
    "{stem}.test.tsx",
    "{stem}.test.js",
    "{stem}.test.jsx",
    "{stem}.spec.ts",
    "{stem}.spec.tsx",
    "{stem}.spec.js",
    "{stem}.spec.jsx",
)
_SPEC_DIR_NAMES = frozenset(
    {
        "acceptance-criteria",
        "acceptance_criteria",
        "design",
        "designs",
        "prd",
        "prds",
        "proposal",
        "proposals",
        "requirements",
        "rfc",
        "rfcs",
        "spec",
        "specs",
    }
)
_SPEC_FILE_EXTENSIONS = (".adoc", ".md", ".mdx", ".rst", ".txt")
_MAX_SPEC_DOCUMENTS = 3
_MAX_SPEC_DOCUMENT_CHARS = 24_000
_REACT_FILE_EXTENSIONS = (".jsx", ".tsx")
_FRONTEND_FILE_EXTENSIONS = (".js", ".jsx", ".ts", ".tsx")
_REACT_HINTS = (
    "from 'react'",
    'from "react"',
    "next/",
    "use client",
    "use server",
    "jsx",
    "tsx",
    "<suspense",
)


class ReviewError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class WorkspaceContext:
    root: Path
    has_repo_context: bool
    branch: str | None


@dataclass(frozen=True, slots=True)
class ParsedReviewRequest:
    mode: str
    reference: str
    repo: str | None
    summary: str
    language: str | None


@dataclass(frozen=True, slots=True)
class ReviewPipeline:
    specialists: tuple[ReviewerSpec, ...]
    general: tuple[ReviewerSpec, ...]
    lead: ReviewerSpec
    missing_reviewers: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class ReviewPromptBudget:
    instructions_chars: int
    source_chars: int
    diff_chars: int
    changed_files: int
    test_surface: int
    reviewer_results_chars: int
    role_context_chars: int


_REVIEWER_ERROR_EXCERPT_CHARS = 1_200
_GITHUB_PR_COMMENT_CHAR_LIMIT = 60_000
_GITHUB_PR_COMMENT_REVIEWED_CODE_LIMIT = 180
_GITHUB_PR_COMMENT_FIX_LIMIT = 180
_GITHUB_PR_COMMENT_AGENT_PROMPT_LIMIT = 320
_GITHUB_PR_COMMENT_TITLE_LIMIT = 180
_GITHUB_PR_COMMENT_GAP_LIMIT = 220


def _coerce_chat_id(value: Any) -> int | None:
    if isinstance(value, int):
        return value
    return None


def _utc_now() -> str:
    return datetime.now(UTC).replace(microsecond=0).isoformat()


def _make_run_id() -> str:
    stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
    return f"{stamp}-{uuid.uuid4().hex[:8]}"


def _git(repo_root: Path, *args: str, check: bool = True) -> str:
    proc = subprocess.run(
        ["git", *args],
        cwd=repo_root,
        check=False,
        capture_output=True,
        text=True,
    )
    if check and proc.returncode != 0:
        stderr = proc.stderr.strip() or proc.stdout.strip() or "git command failed"
        raise ReviewError(stderr)
    return proc.stdout


def _gh(*args: str, cwd: Path, check: bool = True) -> str:
    if shutil.which("gh") is None:
        raise ReviewError("`gh` is required for `/review pr`, but it is not installed.")
    proc = subprocess.run(
        ["gh", *args],
        cwd=cwd,
        check=False,
        capture_output=True,
        text=True,
    )
    if check and proc.returncode != 0:
        stderr = proc.stderr.strip() or proc.stdout.strip() or "gh command failed"
        raise ReviewError(stderr)
    return proc.stdout


def _relative_path(path: Path, *, repo_root: Path) -> str:
    try:
        return path.relative_to(repo_root).as_posix()
    except ValueError:
        return path.as_posix()


def _trim(text: str, *, limit: int) -> str:
    if len(text) <= limit:
        return text
    omitted = len(text) - limit
    return f"{text[:limit]}\n\n[truncated {omitted} chars]"


def _trim_inline(text: str, *, limit: int) -> str:
    normalized = " ".join(text.split())
    if len(normalized) <= limit:
        return normalized
    omitted = len(normalized) - limit
    return f"{normalized[:limit]}...[truncated {omitted} chars]"


def _dedupe(values: list[str]) -> tuple[str, ...]:
    return tuple(dict.fromkeys(values))


def _read_text_file(path: Path) -> str | None:
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None


def _render_path_list(
    paths: tuple[str, ...],
    *,
    max_items: int,
    empty_label: str,
) -> str:
    if not paths:
        return f"- {empty_label}"
    shown = paths[:max_items]
    lines = [f"- {path}" for path in shown]
    omitted = len(paths) - len(shown)
    if omitted > 0:
        lines.append(f"- [truncated {omitted} more paths]")
    return "\n".join(lines)


def _find_repo_root(path: Path) -> Path:
    proc = subprocess.run(
        ["git", "rev-parse", "--show-toplevel"],
        cwd=path,
        check=False,
        capture_output=True,
        text=True,
    )
    if proc.returncode != 0:
        stderr = proc.stderr.strip() or "not inside a git repository"
        raise ReviewError(stderr)
    return Path(proc.stdout.strip())


def _resolve_workspace_context(path: Path, *, require_repo: bool) -> WorkspaceContext:
    try:
        repo_root = _find_repo_root(path)
    except ReviewError:
        if require_repo:
            raise
        return WorkspaceContext(root=path, has_repo_context=False, branch=None)
    return WorkspaceContext(
        root=repo_root,
        has_repo_context=True,
        branch=_current_branch(repo_root),
    )


def _current_repo_slug(workspace: WorkspaceContext) -> str | None:
    if not workspace.has_repo_context:
        return None
    remote = _git(workspace.root, "remote", "get-url", "origin", check=False).strip()
    if not remote:
        return None
    ssh_match = re.search(r"github\.com[:/](?P<repo>[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+?)(?:\.git)?$", remote)
    if ssh_match:
        return ssh_match.group("repo")
    http_match = _GITHUB_REPO_RE.search(remote)
    if http_match:
        return http_match.group("repo")
    return None


def _runtime_context(ctx: CommandContext) -> tuple[RunContext | None, Path]:
    ambient: RunContext | None = None
    executor_context = getattr(ctx.executor, "default_context", None)
    if isinstance(executor_context, RunContext):
        ambient = executor_context
    chat_id = _coerce_chat_id(ctx.message.channel_id)
    if ambient is None and hasattr(ctx.runtime, "default_context_for_chat"):
        ambient = ctx.runtime.default_context_for_chat(chat_id)
    context = ambient
    if hasattr(ctx.runtime, "resolve_message"):
        try:
            resolved = ctx.runtime.resolve_message(
                text=ctx.text,
                reply_text=ctx.reply_text,
                ambient_context=ambient,
                chat_id=chat_id,
            )
        except RuntimeError:
            resolved = None
        if resolved is not None and isinstance(resolved.context, RunContext):
            context = resolved.context
    cwd: Path | None = None
    if hasattr(ctx.runtime, "resolve_run_cwd"):
        try:
            cwd = ctx.runtime.resolve_run_cwd(context)
        except RuntimeError:
            cwd = None
    if cwd is None:
        cwd = Path.cwd()
    return context, Path(cwd)


def _summarize_request_text(request_text: str) -> str:
    compact = " ".join(request_text.split())
    return compact[:96] + "..." if len(compact) > 96 else compact


def _normalize_language(value: str | None) -> str | None:
    if value is None:
        return None
    normalized = value.strip().lower()
    if not normalized or normalized in {"none", "unknown", "n/a"}:
        return None
    aliases = {
        "c#": "csharp",
        "c++": "cpp",
        "golang": "go",
        "js": "javascript",
        "node": "javascript",
        "py": "python",
        "rs": "rust",
        "ts": "typescript",
    }
    return aliases.get(normalized, normalized)


def _normalize_repo(value: str | None) -> str | None:
    if value is None:
        return None
    raw = value.strip().strip("`'\".,)")
    if not raw:
        return None
    url_match = _GITHUB_REPO_RE.search(raw)
    if url_match:
        return url_match.group("repo")
    return raw


def _heuristic_language(request_text: str, source_text: str | None) -> str | None:
    haystacks = [request_text]
    if source_text:
        haystacks.append(source_text[:4_000])
    combined = "\n".join(haystacks).lower()
    keyword_map = {
        "python": ("python", "py", "pytest"),
        "typescript": ("typescript", "ts", "tsx"),
        "javascript": ("javascript", "js", "jsx", "node"),
        "rust": ("rust", "cargo", "rustfmt"),
        "go": ("golang", "go", "gofmt"),
        "java": ("java", "gradle", "maven"),
        "kotlin": ("kotlin", "kt"),
        "swift": ("swift", "xcode"),
        "ruby": ("ruby", "rails", "rspec"),
        "php": ("php", "composer", "laravel"),
        "csharp": ("c#", "csharp", "dotnet"),
        "cpp": ("c++", "cpp"),
    }
    for language, tokens in keyword_map.items():
        if any(token in combined for token in tokens):
            return language

    fence_match = re.search(r"```([a-zA-Z0-9#+.-]+)", combined)
    if fence_match:
        return _normalize_language(fence_match.group(1))
    extension_map = {
        ".py": "python",
        ".ts": "typescript",
        ".tsx": "typescript",
        ".js": "javascript",
        ".jsx": "javascript",
        ".rs": "rust",
        ".go": "go",
        ".java": "java",
        ".kt": "kotlin",
        ".swift": "swift",
        ".rb": "ruby",
        ".php": "php",
        ".cs": "csharp",
        ".cc": "cpp",
        ".cpp": "cpp",
        ".cxx": "cpp",
    }
    for extension, language in extension_map.items():
        if extension in combined:
            return language
    return None


def _heuristic_review_request(
    request_text: str,
    *,
    source_text: str | None,
    workspace: WorkspaceContext,
) -> ParsedReviewRequest:
    summary = _summarize_request_text(request_text)
    language = _heuristic_language(request_text, source_text)
    repo = _current_repo_slug(workspace)

    pr_url_match = _PR_URL_RE.search(request_text)
    if pr_url_match:
        return ParsedReviewRequest(
            mode="pr",
            reference=pr_url_match.group("reference"),
            repo=pr_url_match.group("repo"),
            summary=summary,
            language=language,
        )

    commit_url_match = _COMMIT_URL_RE.search(request_text)
    if commit_url_match:
        return ParsedReviewRequest(
            mode="commit",
            reference=commit_url_match.group("reference"),
            repo=commit_url_match.group("repo"),
            summary=summary,
            language=language,
        )

    repo_hint_match = _REPO_HINT_RE.search(request_text)
    if repo_hint_match:
        repo = _normalize_repo(repo_hint_match.group("repo")) or repo

    pr_ref_match = _PR_REF_RE.search(request_text)
    if pr_ref_match:
        return ParsedReviewRequest(
            mode="pr",
            reference=pr_ref_match.group("reference"),
            repo=repo,
            summary=summary,
            language=language,
        )

    commit_ref_match = _COMMIT_REF_RE.search(request_text)
    if commit_ref_match:
        return ParsedReviewRequest(
            mode="commit",
            reference=commit_ref_match.group("reference"),
            repo=repo,
            summary=summary,
            language=language,
        )

    lowered = request_text.lower()
    if any(
        hint in lowered
        for hint in (
            "working tree diff",
            "current diff",
            "local diff",
            "current changes",
            "local changes",
            "staged diff",
            "unstaged diff",
        )
    ) or lowered.strip() in {"diff", "review diff"}:
        return ParsedReviewRequest(
            mode="diff",
            reference="HEAD",
            repo=repo,
            summary=summary,
            language=language,
        )

    return ParsedReviewRequest(
        mode="request",
        reference=request_text,
        repo=repo,
        summary=summary,
        language=language,
    )


def _parser_engine(config: ReviewConfig) -> str:
    if config.specialist_reviewers:
        return config.specialist_reviewers[0].engine
    return "codex"


def _review_request_parser_prompt(*, request_text: str, source_text: str | None) -> str:
    source_block = source_text or "(none)"
    return textwrap.dedent(
        f"""\
        You classify Takopi review commands before the review agents run.

        Return exactly one JSON object with this schema:
        {{
          "mode": "diff | pr | commit | request",
          "reference": "HEAD, a PR number, a commit SHA, or the original request text",
          "repo": "owner/repo or null",
          "summary": "short summary under 12 words",
          "language": "primary implementation language or null"
        }}

        Rules:
        - Use `mode = pr` for pull request reviews.
        - Use `mode = commit` for commit reviews.
        - Use `mode = diff` for current-workspace diff reviews.
        - Use `mode = request` for snippet or ad hoc reviews.
        - Preserve numeric PR references like `123`.
        - Preserve commit SHAs when they are provided.
        - Set `repo` only when the command names a repo or URL.
        - Infer the primary language only when the request or source text makes it reasonably clear.
        - Prefer mainstream language names like python, typescript, rust, go, java, ruby, php, csharp, or cpp.
        - Use null when the language is ambiguous.
        - Keep the summary concrete and concise.
        - Do not wrap the JSON in markdown fences.

        <review_request>
        {request_text}
        </review_request>

        <source_text>
        {_trim(source_block, limit=8_000)}
        </source_text>
        """
    ).strip()


def _parse_review_request_payload(raw_text: str) -> ParsedReviewRequest:
    payload = json.loads(_extract_json_blob(raw_text))
    if not isinstance(payload, dict):
        raise ReviewError("Review request parser output must be a JSON object.")
    raw_mode = payload.get("mode")
    mode = raw_mode.strip().lower() if isinstance(raw_mode, str) else ""
    if mode not in {"diff", "pr", "commit", "request"}:
        raise ReviewError("Review request parser output is missing a valid `mode`.")
    raw_reference = payload.get("reference")
    reference = raw_reference.strip() if isinstance(raw_reference, str) else ""
    if not reference:
        raise ReviewError("Review request parser output is missing `reference`.")
    raw_summary = payload.get("summary")
    summary = raw_summary.strip() if isinstance(raw_summary, str) and raw_summary.strip() else ""
    if not summary:
        raise ReviewError("Review request parser output is missing `summary`.")
    return ParsedReviewRequest(
        mode=mode,
        reference=reference,
        repo=_normalize_repo(payload.get("repo") if isinstance(payload.get("repo"), str) else None),
        summary=summary,
        language=_normalize_language(payload.get("language") if isinstance(payload.get("language"), str) else None),
    )


async def _infer_review_request(
    ctx: CommandContext,
    *,
    request_text: str,
    source_text: str | None,
    config: ReviewConfig,
    run_context: RunContext | None,
    workspace: WorkspaceContext,
) -> ParsedReviewRequest:
    request = RunRequest(
        prompt=_review_request_parser_prompt(
            request_text=request_text,
            source_text=source_text,
        ),
        engine=_parser_engine(config),
        context=run_context,
    )
    fallback = _heuristic_review_request(
        request_text,
        source_text=source_text,
        workspace=workspace,
    )
    try:
        result = await asyncio.wait_for(
            ctx.executor.run_one(request, mode="capture"),
            timeout=min(config.timeout_s, 90),
        )
    except (RuntimeError, TimeoutError):
        return fallback
    message = result.message.text if result.message is not None else ""
    try:
        parsed = _parse_review_request_payload(message)
    except (ReviewError, json.JSONDecodeError):
        return fallback
    mode = parsed.mode or fallback.mode
    reference = parsed.reference or fallback.reference
    repo = parsed.repo or fallback.repo
    summary = parsed.summary or fallback.summary
    language = parsed.language or fallback.language
    return ParsedReviewRequest(
        mode=mode,
        reference=reference,
        repo=repo,
        summary=summary,
        language=language,
    )


def _collect_status(repo_root: Path) -> tuple[str, tuple[str, ...], tuple[str, ...]]:
    status_text = _git(repo_root, "status", "--short", "--untracked-files=all").strip()
    changed: list[str] = []
    untracked: list[str] = []
    for line in status_text.splitlines():
        if len(line) < 4:
            continue
        raw_path = line[3:]
        path = raw_path.split(" -> ", 1)[-1].strip()
        if not path:
            continue
        changed.append(path)
        if line.startswith("??"):
            untracked.append(path)
    return status_text, _dedupe(changed), _dedupe(untracked)


def _gh_pr_view_payload(
    *,
    reference: str,
    repo: str | None,
    cwd: Path,
) -> dict[str, Any] | None:
    view_args = [
        "pr",
        "view",
        reference,
        "--json",
        "files,title,url,headRefName,baseRefName,headRefOid,headRepository",
    ]
    if repo is not None:
        view_args.extend(["--repo", repo])
    try:
        payload = json.loads(_gh(*view_args, cwd=cwd))
    except (ReviewError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _decode_github_contents_payload(raw_text: str) -> str | None:
    try:
        payload = json.loads(raw_text)
    except json.JSONDecodeError:
        return None
    if not isinstance(payload, dict):
        return None
    if payload.get("encoding") != "base64":
        return None
    content = payload.get("content")
    if not isinstance(content, str) or not content.strip():
        return None
    try:
        decoded = base64.b64decode(content.replace("\n", ""), validate=False)
    except (ValueError, binascii.Error):
        return None
    try:
        return decoded.decode("utf-8")
    except UnicodeDecodeError:
        return None


def _capture_untracked(repo_root: Path, paths: tuple[str, ...], *, max_chars: int) -> str:
    blocks: list[str] = []
    for rel_path in paths:
        file_path = repo_root / rel_path
        if not file_path.is_file():
            continue
        try:
            content = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        excerpt = _trim(content, limit=max_chars)
        blocks.append(
            "\n".join(
                (
                    f"## new file: {rel_path}",
                    "```",
                    excerpt,
                    "```",
                )
            )
        )
    return "\n\n".join(blocks)


def _collect_diff_text(
    repo_root: Path,
    *,
    mode: str,
    reference: str,
    repo: str | None,
    max_chars: int,
    max_untracked_file_chars: int,
) -> tuple[str, tuple[str, ...], str, dict[str, Any] | None]:
    status_text, changed_files, untracked = ("", (), ())
    if mode in {"diff", "commit"} or repo is None:
        status_text, changed_files, untracked = _collect_status(repo_root)
    if mode == "diff":
        if not changed_files:
            raise ReviewError("No local changes to review.")
        staged = _git(
            repo_root,
            "diff",
            "--cached",
            "--no-ext-diff",
            "--relative",
            "--unified=3",
            check=False,
        ).strip()
        unstaged = _git(
            repo_root,
            "diff",
            "--no-ext-diff",
            "--relative",
            "--unified=3",
            check=False,
        ).strip()
        diff_blocks: list[str] = []
        if staged:
            diff_blocks.append(f"## staged diff\n\n```diff\n{staged}\n```")
        if unstaged:
            diff_blocks.append(f"## unstaged diff\n\n```diff\n{unstaged}\n```")
        untracked_block = _capture_untracked(
            repo_root,
            untracked,
            max_chars=max_untracked_file_chars,
        )
        if untracked_block:
            diff_blocks.append(untracked_block)
        diff_text = "\n\n".join(diff_blocks).strip()
        if not diff_text:
            diff_text = "No textual diff available; inspect git status for details."
        return _trim(diff_text, limit=max_chars), changed_files, status_text, None

    if mode == "commit":
        diff_text = _git(
            repo_root,
            "show",
            "--no-ext-diff",
            "--relative",
            "--stat",
            "--format=medium",
            "--unified=3",
            reference,
        ).strip()
        names = _git(repo_root, "show", "--format=", "--name-only", reference).splitlines()
        changed = _dedupe([line.strip() for line in names if line.strip()])
        return _trim(diff_text, limit=max_chars), changed, status_text, None

    if mode == "pr":
        pr_diff_args = ["pr", "diff", reference, "--patch"]
        if repo is not None:
            pr_diff_args.extend(["--repo", repo])
        diff_text = _gh(*pr_diff_args, cwd=repo_root).strip()
        changed: tuple[str, ...]
        pr_view_payload: dict[str, Any] | None = None
        try:
            pr_view_payload = _gh_pr_view_payload(
                reference=reference,
                repo=repo,
                cwd=repo_root,
            )
            if pr_view_payload is None:
                raise ReviewError("Could not load PR metadata.")
            changed = tuple(
                dict.fromkeys(
                    file_info["path"]
                    for file_info in pr_view_payload.get("files", [])
                    if isinstance(file_info.get("path"), str)
                )
            )
        except (ReviewError, TypeError, KeyError, json.JSONDecodeError):
            changed = _dedupe(
                [
                    match.group(1)
                    for match in re.finditer(
                        r"^diff --git a/(.*?) b/.*?$",
                        diff_text,
                        flags=re.MULTILINE,
                    )
                ]
            )
        return _trim(diff_text, limit=max_chars), changed, status_text, pr_view_payload

    raise ReviewError(f"Unsupported review mode {mode!r}.")


def _current_branch(repo_root: Path) -> str | None:
    branch = _git(repo_root, "branch", "--show-current", check=False).strip()
    return branch or None


def _collect_instructions(
    workspace_root: Path,
    *,
    max_chars: int,
) -> tuple[InstructionSnippet, ...]:
    candidates = (
        workspace_root / "AGENTS.md",
        workspace_root / "CLAUDE.md",
        workspace_root / "CONTINUITY.md",
        workspace_root / ".github" / "copilot-instructions.md",
        workspace_root / "README.md",
    )
    snippets: list[InstructionSnippet] = []
    for candidate in candidates:
        if not candidate.is_file():
            continue
        try:
            content = candidate.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        snippets.append(
            InstructionSnippet(
                path=_relative_path(candidate, repo_root=workspace_root),
                content=_trim(content, limit=max_chars),
            )
        )
    return tuple(snippets)


def _is_test_path(path: str) -> bool:
    lowered = path.lower()
    return (
        "/tests/" in lowered
        or lowered.startswith("tests/")
        or lowered.startswith("test_")
        or lowered.endswith("_test.py")
        or ".test." in lowered
        or ".spec." in lowered
    )


def _is_spec_document_path(path: str) -> bool:
    if _is_test_path(path):
        return False
    candidate = Path(path)
    if candidate.suffix.lower() not in _SPEC_FILE_EXTENSIONS:
        return False
    if any(part.lower() in _SPEC_DIR_NAMES for part in candidate.parts):
        return True
    return _SPEC_PATH_HINT_RE.search(candidate.as_posix().lower()) is not None


def _spec_document_paths(changed_files: tuple[str, ...]) -> tuple[str, ...]:
    return tuple(
        path for path in changed_files if _is_spec_document_path(path)
    )[:_MAX_SPEC_DOCUMENTS]


def _pr_spec_head(
    *,
    pr_view_payload: dict[str, Any] | None,
    fallback_repo: str | None,
) -> tuple[str, str] | None:
    if not isinstance(pr_view_payload, dict):
        return None
    head_repo = fallback_repo
    head_repository = pr_view_payload.get("headRepository")
    if isinstance(head_repository, dict):
        name_with_owner = head_repository.get("nameWithOwner")
        if isinstance(name_with_owner, str) and name_with_owner.strip():
            head_repo = name_with_owner.strip()
    if head_repo is None:
        return None
    for field in ("headRefOid", "headRefName"):
        value = pr_view_payload.get(field)
        if isinstance(value, str) and value.strip():
            return head_repo, value.strip()
    return None


def _local_spec_documents(
    *,
    repo_root: Path,
    mode: str,
    reference: str,
    spec_paths: tuple[str, ...],
    max_chars: int,
) -> tuple[InstructionSnippet, ...]:
    documents: list[InstructionSnippet] = []
    for rel_path in spec_paths:
        content: str | None
        if mode == "commit":
            content = _git(
                repo_root,
                "show",
                f"{reference}:{rel_path}",
                check=False,
            )
            if not content.strip():
                continue
        else:
            content = _read_text_file(repo_root / rel_path)
            if content is None or not content.strip():
                continue
        documents.append(
            InstructionSnippet(
                path=rel_path,
                content=_trim(content, limit=max_chars),
            )
        )
    return tuple(documents)


def _pr_spec_documents(
    *,
    repo_root: Path,
    repo: str | None,
    pr_view_payload: dict[str, Any] | None,
    spec_paths: tuple[str, ...],
    max_chars: int,
) -> tuple[InstructionSnippet, ...]:
    head = _pr_spec_head(pr_view_payload=pr_view_payload, fallback_repo=repo)
    if head is None:
        return ()
    head_repo, head_ref = head
    documents: list[InstructionSnippet] = []
    for rel_path in spec_paths:
        raw_payload = _gh(
            "api",
            f"repos/{head_repo}/contents/{quote(rel_path, safe='/')}?ref={head_ref}",
            cwd=repo_root,
            check=False,
        )
        content = _decode_github_contents_payload(raw_payload)
        if content is None or not content.strip():
            continue
        documents.append(
            InstructionSnippet(
                path=rel_path,
                content=_trim(content, limit=max_chars),
            )
        )
    return tuple(documents)


def _collect_spec_documents(
    *,
    repo_root: Path,
    mode: str,
    reference: str,
    repo: str | None,
    changed_files: tuple[str, ...],
    pr_view_payload: dict[str, Any] | None,
    max_chars: int,
) -> tuple[InstructionSnippet, ...]:
    spec_paths = _spec_document_paths(changed_files)
    if not spec_paths:
        return ()
    if mode == "pr":
        return _pr_spec_documents(
            repo_root=repo_root,
            repo=repo,
            pr_view_payload=pr_view_payload,
            spec_paths=spec_paths,
            max_chars=max_chars,
        )
    return _local_spec_documents(
        repo_root=repo_root,
        mode=mode,
        reference=reference,
        spec_paths=spec_paths,
        max_chars=max_chars,
    )


def _infer_test_surface(repo_root: Path, changed_files: tuple[str, ...]) -> tuple[str, ...]:
    changed_tests = [path for path in changed_files if _is_test_path(path)]
    if changed_tests:
        return _dedupe(changed_tests)

    candidates: list[str] = []
    for rel_path in changed_files:
        path = Path(rel_path)
        stem = path.stem
        search_roots = (path.parent, repo_root / "tests", repo_root / path.parent / "__tests__")
        for root in search_roots:
            base = root if root.is_absolute() else repo_root / root
            if not base.exists():
                continue
            for pattern in _TEST_FILE_PATTERNS:
                candidate = base / pattern.format(stem=stem)
                if candidate.is_file():
                    candidates.append(_relative_path(candidate, repo_root=repo_root))
    return _dedupe(candidates)


def _target_label(
    mode: str,
    reference: str,
    *,
    repo: str | None = None,
    summary: str | None = None,
    language: str | None = None,
) -> str:
    if mode == "diff":
        return "working tree diff"
    if mode == "pr":
        if repo:
            return f"pull request {reference} in {repo}"
        return f"pull request {reference}"
    if mode == "commit":
        if repo:
            return f"commit {reference} in {repo}"
        return f"commit {reference}"
    if summary:
        if language:
            return f"{language} review request: {summary}"
        return f"review request: {summary}"
    return f"review request: {_summarize_request_text(reference)}"


def _build_bundle(
    ctx: CommandContext,
    *,
    mode: str,
    reference: str,
    focus_areas: tuple[str, ...],
    config: ReviewConfig,
    workspace: WorkspaceContext,
    parsed_request: ParsedReviewRequest | None = None,
) -> ReviewBundle:
    ambient_context, cwd = _runtime_context(ctx)
    changed_files: tuple[str, ...] = ()
    test_surface: tuple[str, ...] = ()
    status_text = ""
    diff_text = ""
    spec_documents: tuple[InstructionSnippet, ...] = ()
    source_text = ctx.reply_text.strip() if ctx.reply_text and ctx.reply_text.strip() else None
    target_repo = parsed_request.repo if parsed_request is not None else None
    if mode == "pr" and target_repo is None:
        target_repo = _current_repo_slug(workspace)
    if mode != "request":
        if mode in {"diff", "commit"} and not workspace.has_repo_context:
            raise ReviewError("Git-backed review modes require a repository workspace.")
        if mode == "commit" and target_repo is not None:
            raise ReviewError("Commit reviews do not support an external repo override yet.")
        diff_text, changed_files, status_text, pr_view_payload = _collect_diff_text(
            workspace.root,
            mode=mode,
            reference=reference,
            repo=target_repo,
            max_chars=config.max_diff_chars,
            max_untracked_file_chars=config.max_untracked_file_chars,
        )
        if not changed_files and mode == "diff":
            raise ReviewError("No changed files resolved for the current diff.")
        test_surface = _infer_test_surface(workspace.root, changed_files)
        spec_documents = _collect_spec_documents(
            repo_root=workspace.root,
            mode=mode,
            reference=reference,
            repo=target_repo,
            changed_files=changed_files,
            pr_view_payload=pr_view_payload,
            max_chars=_MAX_SPEC_DOCUMENT_CHARS,
        )

    run_branch = ambient_context.branch if ambient_context is not None else None
    if run_branch is None:
        run_branch = workspace.branch
    return ReviewBundle(
        workspace_root=workspace.root.as_posix(),
        project=ambient_context.project if ambient_context is not None else None,
        branch=run_branch,
        cwd=cwd.as_posix(),
        has_repo_context=workspace.has_repo_context,
        target=ReviewTarget(
            mode=mode,
            reference=reference,
            repo=target_repo,
            label=_target_label(
                mode,
                reference,
                repo=target_repo,
                summary=parsed_request.summary if parsed_request is not None else None,
                language=parsed_request.language if parsed_request is not None else None,
            ),
        ),
        focus_areas=focus_areas,
        inferred_language=parsed_request.language if parsed_request is not None else None,
        source_text=source_text,
        changed_files=changed_files,
        test_surface=test_surface,
        status_text=status_text,
        diff_text=diff_text,
        instructions=_collect_instructions(
            workspace.root,
            max_chars=config.max_instruction_chars,
        ),
        spec_documents=spec_documents,
    )


def _build_run_context(bundle: ReviewBundle) -> RunContext | None:
    if bundle.project is None and bundle.branch is None:
        return None
    return RunContext(project=bundle.project, branch=bundle.branch)


def _run_context_for_workspace(
    *,
    ambient_context: RunContext | None,
    workspace: WorkspaceContext,
) -> RunContext | None:
    project = ambient_context.project if ambient_context is not None else None
    branch = ambient_context.branch if ambient_context is not None else None
    if branch is None:
        branch = workspace.branch
    if project is None and branch is None:
        return None
    return RunContext(project=project, branch=branch)


def _render_reference_documents(
    documents: tuple[InstructionSnippet, ...],
    *,
    limit: int,
    empty_label: str,
) -> str:
    if not documents:
        return empty_label
    blocks = [
        f"### {snippet.path}\n\n{_trim(snippet.content, limit=limit)}"
        for snippet in documents
    ]
    return _trim("\n\n".join(blocks), limit=limit)


def _bundle_prompt(
    bundle: ReviewBundle,
    *,
    instructions_limit: int,
    source_limit: int,
    diff_limit: int,
    max_changed_files: int,
    max_test_surface: int,
) -> str:
    instruction_blocks = [
        f"### {snippet.path}\n\n{_trim(snippet.content, limit=instructions_limit)}"
        for snippet in bundle.instructions
    ]
    instructions = (
        _trim("\n\n".join(instruction_blocks), limit=instructions_limit)
        if instruction_blocks
        else "(none)"
    )
    spec_documents = _render_reference_documents(
        bundle.spec_documents,
        limit=min(instructions_limit, 6_000),
        empty_label="(none detected)",
    )
    changed = _render_path_list(
        bundle.changed_files,
        max_items=max_changed_files,
        empty_label="(none)",
    )
    test_surface = _render_path_list(
        bundle.test_surface,
        max_items=max_test_surface,
        empty_label="(none inferred)",
    )
    focus = ", ".join(bundle.focus_areas) if bundle.focus_areas else "none"
    source_block = bundle.source_text or "(none provided)"
    workspace_type = "git repo" if bundle.has_repo_context else "workspace"
    return textwrap.dedent(
        f"""\
        Review target: {bundle.target.label}
        Workspace root: {bundle.workspace_root}
        Workspace type: {workspace_type}
        Target repo: {bundle.target.repo or "(workspace default)"}
        Branch: {bundle.branch or "(unknown)"}
        Primary language signal: {bundle.inferred_language or "(unspecified)"}
        Focus areas: {focus}

        Changed files:
        {changed}

        Suggested test surface:
        {test_surface}

        Git status:
        {bundle.status_text or "(clean)"}

        Repo instructions:
        {instructions}

        Spec documents:
        {spec_documents}

        Source content:
        {_trim(source_block, limit=source_limit)}

        Diff bundle:
        {_trim(bundle.diff_text or "(none)", limit=diff_limit)}
        """
    ).strip()


def _bundle_signal_text(bundle: ReviewBundle) -> str:
    return "\n".join(
        (
            "\n".join(bundle.changed_files),
            bundle.source_text or "",
            _trim(bundle.diff_text or "", limit=8_000),
        )
    ).lower()


def _security_skill_reference_names(bundle: ReviewBundle) -> tuple[str, ...]:
    combined = _bundle_signal_text(bundle)
    reference_names: list[str] = []
    language = bundle.inferred_language

    if language == "python":
        if "django" in combined:
            reference_names.append("python-django-web-server-security.md")
        if "fastapi" in combined:
            reference_names.append("python-fastapi-web-server-security.md")
        if "flask" in combined:
            reference_names.append("python-flask-web-server-security.md")
    elif language in {"javascript", "typescript"}:
        if "express" in combined:
            reference_names.append("javascript-express-web-server-security.md")
        if "next/" in combined or "next.config" in combined:
            reference_names.append("javascript-typescript-nextjs-web-server-security.md")
        if "react" in combined or _is_frontend_bundle(bundle):
            reference_names.append("javascript-typescript-react-web-frontend-security.md")
        if _is_frontend_bundle(bundle):
            reference_names.append("javascript-general-web-frontend-security.md")
    elif language == "go":
        reference_names.append("golang-general-backend-security.md")

    return tuple(dict.fromkeys(reference_names))


def _security_skill_context(bundle: ReviewBundle) -> str:
    blocks: list[str] = []
    for name in _security_skill_reference_names(bundle):
        content = SECURITY_SKILL_REFERENCES.get(name)
        if content:
            blocks.append(f"### {name}\n\n{content}")

    if not blocks:
        return (
            "No repo-local `security-best-practices` references matched this bundle. "
            "Apply general secure-by-default guidance and focus on high-impact security regressions."
        )
    return _trim("\n\n".join(blocks), limit=16_000)


def _code_review_skill_context(bundle: ReviewBundle) -> str:
    _ = bundle
    return _trim(CODE_REVIEW_EXCELLENCE, limit=16_000)


def _role_instructions(reviewer: ReviewerSpec) -> tuple[str, ...]:
    if reviewer.role == "code-review-excellence":
        if reviewer.phase == "lead":
            return (
                "Validate the reviewer findings the way a strong human reviewer would: keep grounded issues, reject weak claims, and downgrade anything that is too speculative.",
                "Merge duplicate reviewer findings into one final finding per root cause and preserve the supporting reviewer lanes in `source_reviewers`.",
                "Rank findings by user impact and merge risk, and do not invent new issue categories that the reviewers did not surface.",
            )
        return (
            "Run a broad code review across correctness, security, maintainability, and testing risk.",
            "Prefer concrete user-impacting issues over style or taste.",
            "Do not duplicate narrow specialist comments unless the issue is severe enough to matter in the final ranking.",
        )

    instructions = {
        "security-best-practices": (
            "Apply the repo-local `security-best-practices` guidance for the detected language and frameworks when references are available.",
            "Prioritize secure defaults, authorization, input handling, session and secret handling, and unsafe framework usage.",
            "Treat server actions, RPC handlers, webhooks, and background jobs as externally reachable unless the bundle proves otherwise.",
            "Ignore style-only issues and low-signal nits.",
        ),
        "typechecker": (
            "Prioritize contract drift, nullability issues, invalid assumptions about shapes or return values, unsound casts, and compiler or typechecker regressions.",
            "For dynamic languages, focus on places where shape confusion or unchecked values would turn into runtime breakage.",
            "Ignore pure style or architecture opinions unless they clearly cause a correctness bug.",
        ),
        "tests": (
            "Prioritize missing regression coverage, absent negative-path tests, brittle assertions, fixture leakage, and mismatches between the changed code and the exercised behavior.",
            "Report a finding only when the missing or misleading test surface creates real bug risk.",
            "Keep pure implementation suggestions in `testing_gaps` unless the gap is severe enough to be a finding.",
        ),
        "correctness-simplicity": (
            "Prioritize stale fallback branches, redundant conditionals, dead compatibility code, duplicated branching, inconsistent error handling, and abstractions that mask correctness bugs.",
            "Prefer hard-cut simplifications that reduce branch count, remove masked failure paths, and make the control flow easier to reason about.",
            "Ignore findings whose only impact is style, naming, formatting, or cleanup with no concrete correctness payoff.",
        ),
        "regression-checker": (
            "Prioritize behavior drift, changed defaults, contract breaks, rollout regressions, and missing validation for previously covered edge cases.",
            "Focus on how the change can silently break existing callers, persisted state, or downstream integrations.",
            "Ignore speculative regressions that are not supported by the diff or surrounding context.",
        ),
        "integration-contracts": (
            "Prioritize API, schema, config, queue, webhook, and persisted-data contract drift across system boundaries.",
            "Focus on changes that can break downstream callers, migrations, serialized payloads, defaults, or environment-driven behavior even when the local code still looks coherent.",
            "Ignore generic architecture commentary unless it points to a concrete boundary or compatibility break.",
        ),
        "spec-reviewer": (
            "Compare the implementation against the spec documents committed in the change and look for mismatches, omissions, and contradictions.",
            "Prioritize missing acceptance criteria, behavior that violates explicit requirements, and changes that implement a different contract than the spec describes.",
            "Do not infer requirements the spec does not state, and do not convert product suggestions or future work into bug findings.",
        ),
        "react-vercel": (
            "Apply the Vercel React and Next.js review lens: waterfalls, bundle bloat, hydration problems, client/server boundary mistakes, server action authorization, and unnecessary rerenders.",
            "Prefer concrete issues over broad performance advice. Only report what the bundle directly supports.",
            "Ignore generic frontend polish comments that are not tied to React or Next.js behavior.",
        ),
    }
    return instructions.get(
        reviewer.role,
        (
            f"Stay within the `{reviewer.role}` review lane.",
            "Only report grounded issues from the provided context.",
        ),
    )


def _role_context(bundle: ReviewBundle, reviewer: ReviewerSpec) -> str | None:
    if reviewer.role == "security-best-practices":
        return _security_skill_context(bundle)
    if reviewer.role == "code-review-excellence":
        return _code_review_skill_context(bundle)
    return None


def _is_frontend_bundle(bundle: ReviewBundle) -> bool:
    if any(path.endswith(_REACT_FILE_EXTENSIONS) for path in bundle.changed_files):
        return True
    if bundle.inferred_language not in {"javascript", "typescript"} and not any(
        path.endswith(_FRONTEND_FILE_EXTENSIONS) for path in bundle.changed_files
    ):
        return False
    combined = _bundle_signal_text(bundle)
    return any(hint in combined for hint in _REACT_HINTS)


def _select_review_pipeline(bundle: ReviewBundle, config: ReviewConfig) -> ReviewPipeline:
    specialists = list(config.specialist_reviewers)
    missing_reviewers: list[str] = []
    if bundle.spec_documents:
        specialists.extend(config.spec_reviewers)
    else:
        missing_reviewers.extend(
            reviewer.reviewer_id for reviewer in config.spec_reviewers
        )
    if _is_frontend_bundle(bundle):
        specialists.extend(config.frontend_reviewers)
    else:
        missing_reviewers.extend(
            reviewer.reviewer_id for reviewer in config.frontend_reviewers
        )
    return ReviewPipeline(
        specialists=tuple(specialists),
        general=config.general_reviewers,
        lead=config.lead_reviewer,
        missing_reviewers=tuple(missing_reviewers),
    )


def _review_started_text(
    *,
    bundle: ReviewBundle,
    pipeline: ReviewPipeline,
    config: ReviewConfig,
) -> str:
    specialist_lines = "\n".join(
        f"- `{reviewer.reviewer_id}` ({reviewer.engine}): {reviewer.objective}"
        for reviewer in pipeline.specialists
    )
    general_lines = "\n".join(
        f"- `{reviewer.reviewer_id}` ({reviewer.engine}): {reviewer.objective}"
        for reviewer in pipeline.general
    )
    missing_reviewers = (
        ", ".join(f"`{reviewer}`" for reviewer in pipeline.missing_reviewers)
        or "(none)"
    )
    return "\n".join(
        (
            f"starting takopi review for {bundle.target.label}.",
            "",
            f"running codex-only specialist reviewer roles with max parallelism `{config.max_parallel_reviews}`:",
            specialist_lines or "- (none)",
            "",
            "running broad general reviewers:",
            general_lines or "- (none)",
            "",
            f"missing reviewers for this bundle: {missing_reviewers}",
            "",
            f"then running final lead reviewer `{pipeline.lead.reviewer_id}` ({pipeline.lead.engine}) to merge duplicate findings.",
        )
    )


def _prelead_outputs_prompt(
    outputs: tuple[ReviewerOutput, ...],
    *,
    limit: int,
) -> str:
    payload = [
        {
            "reviewer": output.reviewer,
            "summary": (
                _trim(output.summary, limit=180)
                if isinstance(output.summary, str)
                else None
            ),
            "testing_gaps": [
                _trim(gap, limit=180) for gap in output.testing_gaps[:5]
            ],
            "error": output.error,
            "findings": [
                {
                    "title": _trim(finding.title, limit=140),
                    "priority": finding.priority,
                    "confidence": finding.confidence,
                    "file": finding.file,
                    "start_line": finding.start_line,
                    "end_line": finding.end_line,
                    "summary": _trim(finding.summary, limit=220),
                    "suggested_fix": _trim(finding.suggested_fix, limit=180),
                }
                for finding in output.findings[:8]
            ],
        }
        for output in outputs
    ]
    return _trim(json.dumps(payload, indent=2), limit=limit)


def _specialist_output_contract_example() -> dict[str, Any]:
    return {
        "summary": "short string",
        "testing_gaps": ["string"],
        "findings": [
            {
                "title": "short finding title",
                "priority": 0,
                "confidence": 0.0,
                "file": "relative/path.py",
                "start_line": 1,
                "end_line": 1,
                "summary": "why this matters",
                "suggested_fix": "concrete fix",
            }
        ],
    }


def _lead_output_contract_example() -> dict[str, Any]:
    return {
        "summary": "one-line post summary",
        "testing_gaps": ["string"],
        "findings": [
            {
                "title": "deduplicated finding title",
                "status": "accepted | needs-human-triage | rejected",
                "priority": 0,
                "confidence": 0.0,
                "file": "relative/path.py",
                "start_line": 1,
                "end_line": 1,
                "summary": "merged rationale",
                "reviewed_code": "exact code path or behavior under review",
                "suggested_fix": "short imperative fix direction",
                "agent_prompt": "ready-to-send prompt for an implementation agent",
                "rationale": "why this ranking and status is correct",
                "source_reviewers": ["security-best-practices", "typechecker"],
            }
        ],
    }


def _prompt_budget(reviewer: ReviewerSpec) -> ReviewPromptBudget:
    if reviewer.phase == "lead":
        if reviewer.engine == "claude":
            return ReviewPromptBudget(
                instructions_chars=4_000,
                source_chars=3_000,
                diff_chars=6_000,
                changed_files=60,
                test_surface=24,
                reviewer_results_chars=10_000,
                role_context_chars=4_000,
            )
        return ReviewPromptBudget(
            instructions_chars=4_000,
            source_chars=4_000,
            diff_chars=8_000,
            changed_files=80,
            test_surface=32,
            reviewer_results_chars=12_000,
            role_context_chars=5_000,
        )

    if reviewer.engine == "claude":
        return ReviewPromptBudget(
            instructions_chars=4_000,
            source_chars=4_000,
            diff_chars=12_000,
            changed_files=80,
            test_surface=32,
            reviewer_results_chars=0,
            role_context_chars=4_000,
        )

    return ReviewPromptBudget(
        instructions_chars=8_000,
        source_chars=8_000,
        diff_chars=24_000,
        changed_files=120,
        test_surface=40,
        reviewer_results_chars=0,
        role_context_chars=6_000,
    )


def _review_prompt_codex(
    bundle: ReviewBundle,
    *,
    reviewer: ReviewerSpec,
    prelead_outputs: tuple[ReviewerOutput, ...] = (),
) -> str:
    prompt_budget = _prompt_budget(reviewer)
    role_rules = "\n".join(f"- {line}" for line in _role_instructions(reviewer))
    role_context = _role_context(bundle, reviewer)
    if role_context is not None:
        role_context = _trim(role_context, limit=prompt_budget.role_context_chars)
    bundle_prompt = _bundle_prompt(
        bundle,
        instructions_limit=prompt_budget.instructions_chars,
        source_limit=prompt_budget.source_chars,
        diff_limit=prompt_budget.diff_chars,
        max_changed_files=prompt_budget.changed_files,
        max_test_surface=prompt_budget.test_surface,
    )
    if reviewer.phase == "lead":
        contract_example = _lead_output_contract_example()
        role_context_block = (
            f"\nRole-specific reference material:\n{role_context}\n" if role_context else "\n"
        )
        return textwrap.dedent(
            f"""\
            Role:
            You are Takopi's final lead reviewer `{reviewer.reviewer_id}` running on the `{reviewer.engine}` engine.

            Task:
            Consolidate the pre-lead reviewer outputs into one final deduplicated review and adjudicate whether the reviewer findings are valid.

            Output contract:
            - Return exactly one JSON object.
            - Do not use markdown fences.
            - Do not include explanatory prose before or after the JSON.
            - If there are no grounded issues, return an empty `findings` array.

            Merge rules:
            - Merge duplicate reviewer findings that describe the same root cause.
            - Keep only findings supported by the bundle and the reviewer evidence.
            - Review the reviewer findings critically. Reject or downgrade findings that are not actually grounded.
            - Do not invent new issue categories that were not surfaced by the reviewers.
            - Preserve supporting reviewer lanes in `source_reviewers`.
            - Set `status` for every emitted finding to `accepted`, `needs-human-triage`, or `rejected`.
            - Explain the adjudication in `rationale`.
            - Order the `findings` array from highest-priority fix to lowest-priority fix.
            - Emit at most 8 final findings.
            - Use priority 0-3 where 0 is most severe.
            - Use confidence as a float from 0 to 1.
            - Put residual validation work in `testing_gaps`.
            - Emit at most 5 testing gaps.
            - Use top-level `summary` as the terse review-post summary. Keep it under 18 words.
            - Set `reviewed_code` to a terse description of the exact changed code path or behavior under review.
            - Set `suggested_fix` to a terse imperative implementation direction.
            - Set `agent_prompt` to a ready-to-send prompt for an implementation agent. Mention the file or code path, the bug, the expected behavior, and what to change.
            - Keep `summary`, `reviewed_code`, `suggested_fix`, `agent_prompt`, and `rationale` concise.

            Lead reviewer heuristics:
            {role_rules}
            {role_context_block}

            JSON contract example:
            {json.dumps(contract_example, indent=2)}

            Reviewer results:
            {_prelead_outputs_prompt(prelead_outputs, limit=prompt_budget.reviewer_results_chars)}

            Review bundle:
            {bundle_prompt}
            """
        ).strip()

    contract_example = _specialist_output_contract_example()
    role_context_block = (
        f"\nRole-specific reference material:\n{role_context}\n" if role_context else "\n"
    )
    return textwrap.dedent(
        f"""\
        Role:
        You are Takopi reviewer `{reviewer.reviewer_id}` running on the `{reviewer.engine}` engine.

        Review lane:
        - Objective: {reviewer.objective}
        - Phase: pre-lead

        Task:
        Review the supplied bundle only through your assigned lane and return only high-signal issues directly supported by the provided context.

        Output contract:
        - Return exactly one JSON object.
        - Do not use markdown fences.
        - Do not include explanatory prose before or after the JSON.
        - If there are no grounded issues, return an empty `findings` array.

        Finding rules:
        - Emit at most 8 findings.
        - Use priority 0-3 where 0 is most severe.
        - Use confidence as a float from 0 to 1.
        - Only report issues grounded in the supplied diff, source content, or new-file snapshots.
        - File paths must be workspace-relative when a path is available.
        - Prefer fewer, higher-confidence findings over speculative breadth.
        - Put suggested validation or missing coverage in `testing_gaps`.
        - Emit at most 5 testing gaps.
        - Keep `summary` and `suggested_fix` concise, ideally one sentence each.

        Lane-specific checks:
        {role_rules}
        {role_context_block}

        JSON contract example:
        {json.dumps(contract_example, indent=2)}

        Review bundle:
        {bundle_prompt}
        """
    ).strip()


def _review_prompt_claude(
    bundle: ReviewBundle,
    *,
    reviewer: ReviewerSpec,
    prelead_outputs: tuple[ReviewerOutput, ...] = (),
) -> str:
    prompt_budget = _prompt_budget(reviewer)
    role_rules = "\n".join(_role_instructions(reviewer))
    role_context = _role_context(bundle, reviewer)
    if role_context is not None:
        role_context = _trim(role_context, limit=prompt_budget.role_context_chars)
    bundle_prompt = _bundle_prompt(
        bundle,
        instructions_limit=prompt_budget.instructions_chars,
        source_limit=prompt_budget.source_chars,
        diff_limit=prompt_budget.diff_chars,
        max_changed_files=prompt_budget.changed_files,
        max_test_surface=prompt_budget.test_surface,
    )
    if reviewer.phase == "lead":
        contract_example = _lead_output_contract_example()
        role_context_block = (
            f"""

            <role_context>
            {role_context}
            </role_context>
            """
            if role_context
            else ""
        )
        return textwrap.dedent(
            f"""\
            <role>
            You are Takopi's final lead reviewer `{reviewer.reviewer_id}` using the `{reviewer.engine}` engine.
            </role>

            <instructions>
            Consolidate the pre-lead reviewer outputs into one final deduplicated review and adjudicate whether the reviewer findings are valid.
            Merge duplicate reviewer findings that describe the same root cause.
            Keep only findings supported by the bundle and the reviewer evidence.
            Review the reviewer findings critically. Reject or downgrade findings that are not actually grounded.
            Do not invent new issue categories that were not surfaced by the reviewers.
            Preserve supporting reviewer lanes in `source_reviewers`.
            Set `status` for every emitted finding to `accepted`, `needs-human-triage`, or `rejected`.
            Explain the adjudication in `rationale`.
            Order the `findings` array from highest-priority fix to lowest-priority fix.
            Return exactly one JSON object and nothing else.
            Do not use markdown fences.
            If there are no grounded issues, return an empty `findings` array.
            Put residual validation work in `testing_gaps`.
            Emit at most 8 findings.
            Emit at most 5 testing gaps.
            Use priority 0-3 where 0 is most severe.
            Use confidence as a float from 0 to 1.
            Use top-level `summary` as the terse review-post summary and keep it under 18 words.
            Set `reviewed_code` to the exact changed code path or behavior under review in terse form.
            Set `suggested_fix` to a terse imperative implementation direction.
            Set `agent_prompt` to a ready-to-send prompt for an implementation agent with the file or code path, the bug, the expected behavior, and the concrete change target.
            Keep `summary`, `reviewed_code`, `suggested_fix`, `agent_prompt`, and `rationale` concise.
            </instructions>

            <lead_lane>
            Objective: {reviewer.objective}
            {role_rules}
            </lead_lane>
            {role_context_block}

            <output_contract_example>
            {json.dumps(contract_example, indent=2)}
            </output_contract_example>

            <reviewer_results>
            {_prelead_outputs_prompt(prelead_outputs, limit=prompt_budget.reviewer_results_chars)}
            </reviewer_results>

            <review_bundle>
            {bundle_prompt}
            </review_bundle>
            """
        ).strip()

    contract_example = _specialist_output_contract_example()
    role_context_block = (
        f"<lane_references>\n{role_context}\n</lane_references>\n\n"
        if role_context
        else ""
    )
    return textwrap.dedent(
        f"""\
        <role>
        You are Takopi reviewer `{reviewer.reviewer_id}` using the `{reviewer.engine}` engine.
        </role>

        <review_lane>
        Objective: {reviewer.objective}
        Phase: pre-lead
        {role_rules}
        </review_lane>

        <instructions>
        Review only the supplied bundle and stay inside your assigned lane.
        Stay grounded in the provided context.
        Prefer precise, evidence-backed findings over broad speculation.
        Return exactly one JSON object and nothing else.
        Do not use markdown fences.
        If there are no grounded issues, return an empty `findings` array.
        Put residual validation work in `testing_gaps`.
        Use workspace-relative paths when a path is available.
        Emit at most 8 findings.
        Emit at most 5 testing gaps.
        Use priority 0-3 where 0 is most severe.
        Use confidence as a float from 0 to 1.
        Keep `summary` and `suggested_fix` concise, ideally one sentence each.
        </instructions>

        <output_contract_example>
        {json.dumps(contract_example, indent=2)}
        </output_contract_example>

        {role_context_block}\
        <review_bundle>
        {bundle_prompt}
        </review_bundle>
        """
    ).strip()


def _reviewer_runtime_error(raw_text: str) -> str | None:
    stripped = raw_text.strip()
    if not stripped:
        return None
    lines = [line.strip() for line in stripped.splitlines() if line.strip()]
    if not lines:
        return None
    if not lines[0].lower().startswith("error"):
        return None
    if len(lines) == 1:
        return lines[0]
    return lines[-1]


def _looks_like_truncated_json(raw_text: str) -> bool:
    stripped = raw_text.strip()
    starts = [index for index in (stripped.find("{"), stripped.find("[")) if index != -1]
    if not starts:
        return False
    candidate = stripped[min(starts) :]
    return candidate.count("{") > candidate.count("}") or candidate.count("[") > candidate.count("]")


def _json_decode_looks_truncated(
    candidate: str,
    error: json.JSONDecodeError,
) -> bool:
    trimmed = candidate.rstrip()
    if not trimmed:
        return False
    if "unterminated string" in error.msg.lower():
        return True
    return error.pos >= len(trimmed) - 1 or _looks_like_truncated_json(trimmed)


def _find_json_blob(
    raw_text: str,
) -> tuple[str | None, tuple[int, str, json.JSONDecodeError] | None, int | None]:
    decoder = json.JSONDecoder()
    earliest_success: tuple[int, str] | None = None
    earliest_error: tuple[int, str, json.JSONDecodeError] | None = None
    for index, char in enumerate(raw_text):
        if char not in "{[":
            continue
        candidate = raw_text[index:]
        try:
            _, end = decoder.raw_decode(candidate)
        except json.JSONDecodeError as exc:
            if earliest_error is None:
                earliest_error = (index, candidate, exc)
            continue
        if earliest_success is None or index < earliest_success[0]:
            earliest_success = (index, candidate[:end])
    if earliest_success is None:
        return None, earliest_error, None
    return earliest_success[1], earliest_error, earliest_success[0]


def _review_prompt(
    bundle: ReviewBundle,
    *,
    reviewer: ReviewerSpec,
    prelead_outputs: tuple[ReviewerOutput, ...] = (),
) -> str:
    if reviewer.engine == "claude":
        return _review_prompt_claude(
            bundle,
            reviewer=reviewer,
            prelead_outputs=prelead_outputs,
        )
    return _review_prompt_codex(
        bundle,
        reviewer=reviewer,
        prelead_outputs=prelead_outputs,
    )


def _extract_json_blob(raw_text: str) -> str:
    stripped = raw_text.strip()
    runtime_error = _reviewer_runtime_error(stripped)
    if runtime_error is not None:
        raise ReviewError(runtime_error)
    last_error: tuple[int, str, json.JSONDecodeError] | None = None
    for match in _CODE_FENCE_RE.finditer(stripped):
        candidate = match.group(1).strip()
        if not candidate:
            continue
        blob, error, success_start = _find_json_blob(candidate)
        if (
            error is not None
            and success_start is not None
            and error[0] < success_start
            and _json_decode_looks_truncated(error[1], error[2])
        ):
            raise ReviewError("Reviewer output was truncated before completing JSON.")
        if blob is not None:
            return blob
        if error is not None:
            last_error = error

    blob, error, success_start = _find_json_blob(stripped)
    if (
        error is not None
        and success_start is not None
        and error[0] < success_start
        and _json_decode_looks_truncated(error[1], error[2])
    ):
        raise ReviewError("Reviewer output was truncated before completing JSON.")
    if blob is not None:
        return blob
    if error is not None:
        last_error = error
    if _looks_like_truncated_json(stripped):
        raise ReviewError("Reviewer output was truncated before completing JSON.")
    if last_error is not None and _json_decode_looks_truncated(last_error[1], last_error[2]):
        raise ReviewError("Reviewer output was truncated before completing JSON.")
    raise ReviewError("Reviewer output was not valid JSON.")


def _coerce_priority(value: Any) -> int:
    try:
        priority = int(value)
    except (TypeError, ValueError):
        return 2
    return min(3, max(0, priority))


def _coerce_confidence(value: Any) -> float:
    try:
        confidence = float(value)
    except (TypeError, ValueError):
        return 0.5
    return min(1.0, max(0.0, confidence))


def _coerce_finding_status(value: Any) -> FindingStatus | None:
    if not isinstance(value, str):
        return None
    normalized = value.strip().lower()
    if normalized in {"accepted", "needs-human-triage", "rejected"}:
        return normalized
    return None


def _coerce_line(value: Any, *, default: int = 1) -> int:
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return max(1, number)


def _normalize_file_path(raw_path: Any, *, repo_root: Path) -> str:
    if not isinstance(raw_path, str) or not raw_path.strip():
        raise ReviewError("Reviewer finding is missing a file path.")
    raw = raw_path.strip()
    path = Path(raw)
    if path.is_absolute():
        return _relative_path(path, repo_root=repo_root)
    return path.as_posix()


def _parse_reviewer_output(
    *,
    reviewer: str,
    raw_text: str,
    workspace_root: Path,
    artifact_name: str,
    require_lead_fields: bool = False,
) -> ReviewerOutput:
    blob = _extract_json_blob(raw_text)
    payload = json.loads(blob)
    if isinstance(payload, list):
        findings_payload = payload
        testing_gaps_payload: list[Any] = []
        summary = None
    elif isinstance(payload, dict):
        findings_payload = payload.get("findings", [])
        testing_gaps_payload = payload.get("testing_gaps", [])
        raw_summary = payload.get("summary")
        summary = raw_summary.strip() if isinstance(raw_summary, str) else None
    else:
        raise ReviewError("Reviewer output must be a JSON object or array.")

    if not isinstance(findings_payload, list):
        raise ReviewError("Reviewer `findings` must be a JSON array.")

    findings: list[ReviewFinding] = []
    for raw_finding in findings_payload:
        if not isinstance(raw_finding, dict):
            continue
        try:
            file_path = _normalize_file_path(
                raw_finding.get("file"),
                repo_root=workspace_root,
            )
            start_line = _coerce_line(raw_finding.get("start_line"), default=1)
            end_line = _coerce_line(raw_finding.get("end_line"), default=start_line)
            reviewed_code = str(raw_finding.get("reviewed_code", "")).strip()
            agent_prompt = str(raw_finding.get("agent_prompt", "")).strip()
            if require_lead_fields and not reviewed_code:
                raise ReviewError(
                    "Lead reviewer finding is missing `reviewed_code`."
                )
            if require_lead_fields and not agent_prompt:
                raise ReviewError(
                    "Lead reviewer finding is missing `agent_prompt`."
                )
            findings.append(
                ReviewFinding(
                    reviewer=reviewer,
                    title=str(raw_finding.get("title", "Untitled finding")).strip()
                    or "Untitled finding",
                    priority=_coerce_priority(raw_finding.get("priority")),
                    confidence=_coerce_confidence(raw_finding.get("confidence")),
                    file=file_path,
                    start_line=start_line,
                    end_line=max(start_line, end_line),
                    summary=str(raw_finding.get("summary", "")).strip(),
                    suggested_fix=str(raw_finding.get("suggested_fix", "")).strip(),
                    reviewed_code=reviewed_code,
                    agent_prompt=agent_prompt,
                    source_reviewers=tuple(
                        item.strip()
                        for item in raw_finding.get("source_reviewers", [])
                        if isinstance(item, str) and item.strip()
                    ),
                    status=_coerce_finding_status(raw_finding.get("status")),
                    rationale=(
                        str(raw_finding.get("rationale", "")).strip() or None
                    ),
                )
            )
        except ReviewError:
            if require_lead_fields:
                raise
            continue

    testing_gaps = tuple(
        item.strip()
        for item in testing_gaps_payload
        if isinstance(item, str) and item.strip()
    )
    return ReviewerOutput(
        reviewer=reviewer,
        raw_text=raw_text,
        artifact_name=artifact_name,
        findings=tuple(findings),
        testing_gaps=testing_gaps,
        summary=summary,
    )


async def _run_single_review(
    ctx: CommandContext,
    *,
    reviewer: ReviewerSpec,
    bundle: ReviewBundle,
    config: ReviewConfig,
    prelead_outputs: tuple[ReviewerOutput, ...] = (),
) -> ReviewerOutput:
    request = RunRequest(
        prompt=_review_prompt(
            bundle,
            reviewer=reviewer,
            prelead_outputs=prelead_outputs,
        ),
        engine=reviewer.engine,
        context=_build_run_context(bundle),
    )
    try:
        result = await asyncio.wait_for(
            ctx.executor.run_one(request, mode="capture"),
            timeout=config.timeout_s,
        )
    except (RuntimeError, TimeoutError) as exc:
        return ReviewerOutput(
            reviewer=reviewer.reviewer_id,
            raw_text="",
            artifact_name=reviewer.artifact_name,
            error=str(exc) or exc.__class__.__name__,
        )
    message = result.message.text if result.message is not None else ""
    message_extra = dict(result.message.extra) if result.message is not None else {}
    try:
        output = _parse_reviewer_output(
            reviewer=reviewer.reviewer_id,
            raw_text=message,
            workspace_root=Path(bundle.workspace_root),
            artifact_name=reviewer.artifact_name,
            require_lead_fields=reviewer.phase == "lead",
        )
        return replace(output, message_extra=message_extra)
    except ReviewError as exc:
        return ReviewerOutput(
            reviewer=reviewer.reviewer_id,
            raw_text=message,
            artifact_name=reviewer.artifact_name,
            error=str(exc) or exc.__class__.__name__,
            message_extra=message_extra,
        )


async def _run_prelead_reviews(
    ctx: CommandContext,
    *,
    bundle: ReviewBundle,
    config: ReviewConfig,
    reviewers: tuple[ReviewerSpec, ...],
) -> tuple[ReviewerOutput, ...]:
    semaphore = asyncio.Semaphore(config.max_parallel_reviews)

    async def _guarded(reviewer: ReviewerSpec) -> ReviewerOutput:
        async with semaphore:
            return await _run_single_review(
                ctx,
                reviewer=reviewer,
                bundle=bundle,
                config=config,
            )

    tasks = [asyncio.create_task(_guarded(reviewer)) for reviewer in reviewers]
    return tuple(await asyncio.gather(*tasks))


def _normalized_text(value: str) -> str:
    return " ".join(_WORD_RE.findall(value.lower()))


def _semantic_similarity(left: ReviewFinding, right: ReviewFinding) -> float:
    left_text = _normalized_text(f"{left.title} {left.summary}")
    right_text = _normalized_text(f"{right.title} {right.summary}")
    return SequenceMatcher(None, left_text, right_text).ratio()


def _line_overlap(left: ReviewFinding, right: ReviewFinding) -> bool:
    return not (left.end_line < right.start_line - 3 or right.end_line < left.start_line - 3)


def _is_duplicate(left: ReviewFinding, right: ReviewFinding) -> bool:
    if left.file != right.file:
        return False
    return (
        _line_overlap(left, right) and _semantic_similarity(left, right) >= 0.35
    ) or (
        abs(left.start_line - right.start_line) <= 2
        and _semantic_similarity(left, right) >= 0.55
    )


def _cluster_findings(findings: tuple[ReviewFinding, ...]) -> list[list[ReviewFinding]]:
    clusters: list[list[ReviewFinding]] = []
    for finding in findings:
        matches = [index for index, cluster in enumerate(clusters) if any(_is_duplicate(finding, item) for item in cluster)]
        if not matches:
            clusters.append([finding])
            continue
        first = matches[0]
        clusters[first].append(finding)
        for index in reversed(matches[1:]):
            clusters[first].extend(clusters.pop(index))
    return clusters


def _focus_score(finding: ReviewFinding, focus_areas: tuple[str, ...]) -> int:
    if not focus_areas:
        return 0
    haystack = _normalized_text(
        f"{finding.file} {finding.title} {finding.summary} {finding.suggested_fix}"
    )
    return sum(1 for area in focus_areas if area.lower() in haystack)


def _status_for_cluster(
    *,
    reviewers: tuple[str, ...],
    avg_confidence: float,
    min_priority: int,
) -> tuple[FindingStatus, str]:
    reviewer_count = len(reviewers)
    if reviewer_count >= 2 and avg_confidence >= 0.60:
        return (
            "accepted",
            f"reported by {', '.join(reviewers)} with {avg_confidence:.2f} average confidence",
        )
    if reviewer_count == 1 and min_priority <= 1 and avg_confidence >= 0.90:
        return (
            "accepted",
            f"high-severity single-reviewer finding with {avg_confidence:.2f} confidence",
        )
    if avg_confidence < 0.45:
        return (
            "rejected",
            f"average confidence {avg_confidence:.2f} stayed below the rejection threshold",
        )
    return (
        "needs-human-triage",
        f"insufficient reviewer agreement ({reviewer_count}) for automatic acceptance",
    )


def _finalize_consolidated_findings(
    *,
    bundle: ReviewBundle,
    consolidated: list[ConsolidatedFinding],
    preserve_order: bool = False,
) -> tuple[ConsolidatedFinding, ...]:
    if not preserve_order:
        status_rank = {"accepted": 0, "needs-human-triage": 1, "rejected": 2}
        consolidated.sort(
            key=lambda item: (
                status_rank[item.status],
                item.priority,
                -max(
                    _focus_score(occurrence, bundle.focus_areas)
                    for occurrence in item.occurrences
                ),
                -item.reviewer_count,
                -item.confidence,
                item.file,
                item.start_line,
            )
        )

    finalized: list[ConsolidatedFinding] = []
    for index, finding in enumerate(consolidated, start=1):
        finalized.append(replace(finding, id=f"RF-{index:03d}"))
    return tuple(finalized)


def _fallback_consolidated_findings(
    *,
    bundle: ReviewBundle,
    outputs: tuple[ReviewerOutput, ...],
) -> tuple[ConsolidatedFinding, ...]:
    all_findings = tuple(finding for output in outputs for finding in output.findings)
    clusters = _cluster_findings(all_findings)
    consolidated: list[ConsolidatedFinding] = []

    for cluster in clusters:
        sorted_cluster = sorted(
            cluster,
            key=lambda item: (
                item.priority,
                -item.confidence,
                item.file,
                item.start_line,
            ),
        )
        canonical = sorted_cluster[0]
        cluster_reviewers = tuple(dict.fromkeys(item.reviewer for item in cluster))
        avg_confidence = round(
            sum(item.confidence for item in cluster) / max(1, len(cluster)),
            2,
        )
        min_priority = min(item.priority for item in cluster)
        status, rationale = _status_for_cluster(
            reviewers=cluster_reviewers,
            avg_confidence=avg_confidence,
            min_priority=min_priority,
        )
        consolidated.append(
            ConsolidatedFinding(
                id="",
                status=status,
                reviewer_count=len(cluster_reviewers),
                reviewers=cluster_reviewers,
                title=canonical.title,
                priority=min_priority,
                confidence=avg_confidence,
                file=canonical.file,
                start_line=canonical.start_line,
                end_line=canonical.end_line,
                summary=canonical.summary,
                reviewed_code=_fallback_reviewed_code(canonical),
                suggested_fix=canonical.suggested_fix,
                agent_prompt=_fallback_agent_prompt(canonical),
                rationale=rationale,
                occurrences=tuple(cluster),
            )
        )

    return _finalize_consolidated_findings(bundle=bundle, consolidated=consolidated)


def _matched_occurrences(
    finding: ReviewFinding,
    *,
    prelead_outputs: tuple[ReviewerOutput, ...],
) -> tuple[ReviewFinding, ...]:
    return tuple(
        specialist_finding
        for output in prelead_outputs
        for specialist_finding in output.findings
        if _is_duplicate(finding, specialist_finding)
    )


def _lead_source_reviewers(
    finding: ReviewFinding,
    *,
    prelead_outputs: tuple[ReviewerOutput, ...],
) -> tuple[str, ...]:
    if finding.source_reviewers:
        return tuple(dict.fromkeys(finding.source_reviewers))
    matched = _matched_occurrences(finding, prelead_outputs=prelead_outputs)
    return tuple(dict.fromkeys(item.reviewer for item in matched))


def _fallback_reviewed_code(finding: ReviewFinding) -> str:
    if finding.reviewed_code:
        return finding.reviewed_code
    return finding.summary or f"{finding.file}:{finding.start_line}-{finding.end_line}"


def _fallback_agent_prompt(finding: ReviewFinding) -> str:
    if finding.agent_prompt:
        return finding.agent_prompt
    location = f"{finding.file}:{finding.start_line}"
    issue = finding.summary or finding.title
    fix = finding.suggested_fix or "Implement the grounded fix for this finding."
    return f"Update {location} to fix {issue} {fix}".strip()


def _consolidated_from_lead(
    *,
    bundle: ReviewBundle,
    prelead_outputs: tuple[ReviewerOutput, ...],
    lead_output: ReviewerOutput,
) -> tuple[ConsolidatedFinding, ...]:
    if lead_output.error or not lead_output.findings:
        return ()

    consolidated: list[ConsolidatedFinding] = []
    for finding in lead_output.findings:
        occurrences = _matched_occurrences(
            finding,
            prelead_outputs=prelead_outputs,
        )
        reviewers = _lead_source_reviewers(
            finding,
            prelead_outputs=prelead_outputs,
        )
        avg_confidence = round(finding.confidence, 2)
        status, fallback_rationale = _status_for_cluster(
            reviewers=reviewers,
            avg_confidence=avg_confidence,
            min_priority=finding.priority,
        )
        consolidated.append(
            ConsolidatedFinding(
                id="",
                status=finding.status or status,
                reviewer_count=len(reviewers),
                reviewers=reviewers,
                title=finding.title,
                priority=finding.priority,
                confidence=avg_confidence,
                file=finding.file,
                start_line=finding.start_line,
                end_line=finding.end_line,
                summary=finding.summary,
                reviewed_code=_fallback_reviewed_code(finding),
                suggested_fix=finding.suggested_fix,
                agent_prompt=_fallback_agent_prompt(finding),
                rationale=(
                    finding.rationale
                    or f"{fallback_rationale}; finalized by {lead_output.reviewer}"
                ),
                occurrences=occurrences or (finding,),
            )
        )

    return _finalize_consolidated_findings(
        bundle=bundle,
        consolidated=consolidated,
        preserve_order=True,
    )


def _consolidate_findings(
    *,
    bundle: ReviewBundle,
    prelead_outputs: tuple[ReviewerOutput, ...],
    lead_output: ReviewerOutput | None,
) -> tuple[ConsolidatedFinding, ...]:
    if lead_output is not None:
        lead_findings = _consolidated_from_lead(
            bundle=bundle,
            prelead_outputs=prelead_outputs,
            lead_output=lead_output,
        )
        if lead_findings:
            return lead_findings
    return _fallback_consolidated_findings(bundle=bundle, outputs=prelead_outputs)


def _testing_gaps(
    bundle: ReviewBundle,
    outputs: tuple[ReviewerOutput, ...],
) -> tuple[str, ...]:
    gaps: list[str] = []
    for output in outputs:
        gaps.extend(output.testing_gaps)

    if bundle.changed_files:
        changed_tests = [path for path in bundle.changed_files if _is_test_path(path)]
        production = [path for path in bundle.changed_files if not _is_test_path(path)]
        if production and not changed_tests:
            gaps.append(
                "Changed production files do not include matching test edits in the diff."
            )
        if bundle.test_surface and not changed_tests:
            gaps.append(
                f"Suggested test surface was inferred but not changed: {', '.join(bundle.test_surface)}."
            )
    return _dedupe(gaps)


def _review_root_for_workspace(workspace_root: Path, config: ReviewConfig) -> Path:
    report_dir = Path(config.report_dir)
    if report_dir.is_absolute():
        return report_dir
    return workspace_root / report_dir


def _audit_root(workspace_root: Path, run_id: str, config: ReviewConfig) -> Path:
    return _review_root_for_workspace(workspace_root, config) / run_id


def _write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def _render_review_report(report: ReviewReport) -> str:
    lines: list[str] = [
        "# Takopi Review Report",
        "",
        f"- Run ID: `{report.run_id}`",
        f"- Target: `{report.bundle.target.label}`",
        f"- Target repo: `{report.bundle.target.repo or '(workspace default)'}`",
        f"- Workspace root: `{report.bundle.workspace_root}`",
        f"- Workspace type: `{'git repo' if report.bundle.has_repo_context else 'workspace'}`",
        f"- Branch: `{report.bundle.branch or '(unknown)'}`",
        f"- Changed files: {len(report.bundle.changed_files)}",
        f"- Specialist reviewers: {', '.join(report.specialist_reviewers)}",
        f"- General reviewers: `{', '.join(report.general_reviewers) or '(none)'}`",
        f"- Lead reviewer: `{report.lead_reviewer or '(none)'}`",
        (
            "- Missing reviewers: "
            + (
                ", ".join(f"`{reviewer}`" for reviewer in report.missing_reviewers)
                or "`(none)`"
            )
        ),
        f"- Audit dir: `{Path(report.report_path).parent.as_posix()}`",
    ]
    if report.bundle.focus_areas:
        lines.append(f"- Focus areas: {', '.join(report.bundle.focus_areas)}")
    if report.bundle.inferred_language:
        lines.append(f"- Inferred language: `{report.bundle.inferred_language}`")
    if report.final_summary:
        lines.append(f"- Final summary: {report.final_summary}")
    if report.github_comment_url:
        lines.append(f"- GitHub PR comment: {report.github_comment_url}")
    lines.extend(("", "## Consolidated Findings", ""))
    lines.append("| ID | Status | Priority | Agreement | Confidence | Location | Title |")
    lines.append("| --- | --- | --- | --- | --- | --- | --- |")
    if report.findings:
        for finding in report.findings:
            location = f"{finding.file}:{finding.start_line}"
            agreement = ", ".join(finding.reviewers)
            lines.append(
                "| {id} | {status} | P{priority} | {agreement} | {confidence:.2f} | {location} | {title} |".format(
                    id=finding.id,
                    status=finding.status,
                    priority=finding.priority,
                    agreement=agreement,
                    confidence=finding.confidence,
                    location=location,
                    title=finding.title.replace("|", "/"),
                )
            )
    else:
        lines.append("No findings.")

    lines.extend(("", "## Agreement Matrix", ""))
    matrix_reviewers = list(report.specialist_reviewers + report.general_reviewers)
    header = "| ID | " + " | ".join(matrix_reviewers) + " |"
    divider = "| --- | " + " | ".join("---" for _ in matrix_reviewers) + " |"
    lines.extend((header, divider))
    if report.findings:
        for finding in report.findings:
            row = ["Y" if reviewer in finding.reviewers else "" for reviewer in matrix_reviewers]
            lines.append(f"| {finding.id} | " + " | ".join(row) + " |")
    else:
        lines.append("| (none) |" + " |" * len(matrix_reviewers))

    lines.extend(("", "## Recommended Fix Order", ""))
    if report.findings:
        for index, finding in enumerate(report.findings, start=1):
            lines.append(
                f"{index}. `{finding.id}` `{finding.file}:{finding.start_line}` {finding.title} ({finding.status}, {finding.confidence:.2f})"
            )
    else:
        lines.append("No fixes recommended.")

    lines.extend(("", "## Finding Details", ""))
    if report.findings:
        for finding in report.findings:
            lines.append(
                f"- `{finding.id}` `{finding.file}:{finding.start_line}` {finding.title}"
            )
            lines.append(f"  Reviewed code: {finding.reviewed_code}")
            lines.append(f"  Suggested fix: {finding.suggested_fix}")
            lines.append(f"  Agent prompt: {finding.agent_prompt}")
    else:
        lines.append("No finding details.")

    lines.extend(("", "## Testing Gaps", ""))
    if report.testing_gaps:
        lines.extend(f"- {gap}" for gap in report.testing_gaps)
    else:
        lines.append("- None identified.")

    errors = [output for output in report.raw_outputs if output.error]
    if errors:
        lines.extend(("", "## Reviewer Errors", ""))
        for output in errors:
            lines.append(f"- `{output.reviewer}`: {output.error}")
            if output.raw_text.strip():
                excerpt = _trim(
                    output.raw_text.strip(),
                    limit=_REVIEWER_ERROR_EXCERPT_CHARS,
                )
                lines.extend(("", f"Raw output excerpt from `{output.reviewer}`:"))
                lines.extend(f"    {line}" for line in excerpt.splitlines())
                lines.append("")

    return "\n".join(lines)


def _should_post_github_comment(report: ReviewReport, config: ReviewConfig) -> bool:
    return config.post_github_comments and report.bundle.target.mode == "pr"


def _resolved_target_repo(report: ReviewReport) -> str | None:
    if report.bundle.target.repo:
        return report.bundle.target.repo
    return _current_repo_slug(
        WorkspaceContext(
            root=Path(report.bundle.workspace_root),
            has_repo_context=report.bundle.has_repo_context,
            branch=report.bundle.branch,
        )
    )


def _github_pr_comment_header(
    report: ReviewReport,
    *,
    part_index: int,
    part_count: int,
) -> list[str]:
    lines = ["# Takopi Review"]
    if report.final_summary:
        lines.extend(("", report.final_summary))
    lines.extend(("", f"Findings: `{len(report.findings)}`"))
    if report.missing_reviewers:
        lines.append(
            "Missing reviewers: "
            + ", ".join(f"`{reviewer}`" for reviewer in report.missing_reviewers)
        )
    if part_count > 1:
        lines.append(f"Part: `{part_index}/{part_count}`")
    return lines


def _github_pr_finding_block(finding: ConsolidatedFinding) -> list[str]:
    block = [
        (
            f"- `{finding.id}` [{finding.status}] P{finding.priority} "
            f"`{finding.file}:{finding.start_line}` "
            f"{_trim_inline(finding.title, limit=_GITHUB_PR_COMMENT_TITLE_LIMIT)}"
        ),
        "  Reviewed code: "
        + _trim_inline(
            finding.reviewed_code or finding.summary,
            limit=_GITHUB_PR_COMMENT_REVIEWED_CODE_LIMIT,
        ),
        "  Suggested fix: "
        + _trim_inline(
            finding.suggested_fix,
            limit=_GITHUB_PR_COMMENT_FIX_LIMIT,
        ),
        "  Agent prompt: "
        + _trim_inline(
            finding.agent_prompt,
            limit=_GITHUB_PR_COMMENT_AGENT_PROMPT_LIMIT,
        ),
    ]
    return block


def _render_github_pr_comment_body(
    blocks: list[tuple[str, list[str]]],
) -> list[str]:
    lines: list[str] = []
    current_section: str | None = None
    for section, block in blocks:
        if section != current_section:
            if section == "findings":
                lines.extend(["", "## Findings", ""])
            else:
                lines.extend(["", "## Testing Gaps", ""])
            current_section = section
        lines.extend(block)
    return lines


def _render_github_pr_comment_parts(report: ReviewReport) -> tuple[str, ...]:
    blocks: list[tuple[str, list[str]]] = []
    if report.findings:
        blocks.extend(
            ("findings", _github_pr_finding_block(finding))
            for finding in report.findings
        )
    else:
        blocks.append(("findings", ["No findings."]))
    if report.testing_gaps:
        blocks.extend(
            ("testing_gaps", [f"- {_trim_inline(gap, limit=_GITHUB_PR_COMMENT_GAP_LIMIT)}"])
            for gap in report.testing_gaps
        )
    else:
        blocks.append(("testing_gaps", ["- None identified."]))

    probe_header = _github_pr_comment_header(report, part_index=999, part_count=999)
    parts: list[list[tuple[str, list[str]]]] = []
    current_blocks: list[tuple[str, list[str]]] = []
    for block in blocks:
        candidate_blocks = current_blocks + [block]
        candidate_lines = probe_header + _render_github_pr_comment_body(candidate_blocks)
        if len("\n".join(candidate_lines)) <= _GITHUB_PR_COMMENT_CHAR_LIMIT:
            current_blocks = candidate_blocks
            continue
        if current_blocks:
            parts.append(current_blocks)
            current_blocks = [block]
            continue
        raise ReviewError("A single GitHub review comment block exceeds the comment size limit.")
    if current_blocks:
        parts.append(current_blocks)

    rendered: list[str] = []
    total_parts = len(parts)
    for index, part_blocks in enumerate(parts, start=1):
        lines = _github_pr_comment_header(
            report,
            part_index=index,
            part_count=total_parts,
        ) + _render_github_pr_comment_body(part_blocks)
        body = "\n".join(lines)
        if len(body) > _GITHUB_PR_COMMENT_CHAR_LIMIT:
            raise ReviewError("Rendered GitHub review comment exceeded the comment size limit.")
        rendered.append(body)
    return tuple(rendered)


def _post_github_pr_comment(report: ReviewReport, *, config: ReviewConfig) -> ReviewReport:
    if not _should_post_github_comment(report, config):
        return report
    repo = _resolved_target_repo(report)
    if repo is None:
        raise ReviewError("Could not resolve the GitHub repository for the PR review.")
    comment_urls: list[str] = []
    parts = _render_github_pr_comment_parts(report)
    for index, body in enumerate(parts, start=1):
        try:
            response = _gh(
                "api",
                f"repos/{repo}/issues/{report.bundle.target.reference}/comments",
                "--method",
                "POST",
                "-f",
                f"body={body}",
                cwd=Path(report.bundle.workspace_root),
            )
        except ReviewError as exc:
            raise ReviewError(
                f"Failed to post GitHub PR comment part {index}/{len(parts)}: {exc}"
            ) from exc
        try:
            payload = json.loads(response)
        except json.JSONDecodeError as exc:
            raise ReviewError(
                f"Failed to post GitHub PR comment part {index}/{len(parts)}: response was not valid JSON."
            ) from exc
        html_url = payload.get("html_url") if isinstance(payload, dict) else None
        if not isinstance(html_url, str) or not html_url.strip():
            raise ReviewError(
                f"Failed to post GitHub PR comment part {index}/{len(parts)}: response did not include an html_url."
            )
        comment_urls.append(html_url)
    return replace(report, github_comment_url=comment_urls[0] if comment_urls else None)


def _persist_review_report(report: ReviewReport, *, config: ReviewConfig) -> ReviewReport:
    workspace_root = Path(report.bundle.workspace_root)
    audit_root = _audit_root(workspace_root, report.run_id, config)
    audit_root.mkdir(parents=True, exist_ok=True)

    raw_paths: list[str] = []
    for output in report.raw_outputs:
        raw_path = audit_root / "raw" / f"{output.artifact_name}.txt"
        raw_path.parent.mkdir(parents=True, exist_ok=True)
        raw_path.write_text(output.raw_text or "", encoding="utf-8")
        raw_paths.append(raw_path.as_posix())

    bundle_path = audit_root / "bundle.json"
    report_path = audit_root / "report.md"
    json_path = audit_root / "report.json"
    persisted_report = replace(
        report,
        report_path=report_path.as_posix(),
        raw_output_paths=tuple(raw_paths),
    )
    _write_json(bundle_path, asdict(report.bundle))
    report_path.write_text(_render_review_report(persisted_report), encoding="utf-8")
    _write_json(json_path, asdict(persisted_report))
    latest_path = _review_root_for_workspace(workspace_root, config) / "latest.json"
    _write_json(
        latest_path,
        {
            "run_id": report.run_id,
            "report_json": json_path.as_posix(),
            "report_md": report_path.as_posix(),
        },
    )
    return persisted_report


async def plan_review(
    ctx: CommandContext,
    *,
    request_text: str,
    config: ReviewConfig,
) -> ParsedReviewRequest:
    ambient_context, cwd = _runtime_context(ctx)
    workspace = _resolve_workspace_context(cwd, require_repo=False)
    return await _infer_review_request(
        ctx,
        request_text=request_text,
        source_text=ctx.reply_text,
        config=config,
        run_context=_run_context_for_workspace(
            ambient_context=ambient_context,
            workspace=workspace,
        ),
        workspace=workspace,
    )


async def execute_review(
    ctx: CommandContext,
    *,
    parsed_request: ParsedReviewRequest,
    focus_areas: tuple[str, ...],
    config: ReviewConfig,
) -> ReviewReport:
    _ambient_context, cwd = _runtime_context(ctx)
    mode = parsed_request.mode
    require_repo = mode in {"diff", "commit"} or (
        mode == "pr" and parsed_request.repo is None
    ) or (mode == "request" and config.require_repo)
    workspace = _resolve_workspace_context(cwd, require_repo=require_repo)
    bundle = _build_bundle(
        ctx,
        mode=mode,
        reference=parsed_request.reference,
        focus_areas=focus_areas,
        config=config,
        workspace=workspace,
        parsed_request=parsed_request,
    )
    pipeline = _select_review_pipeline(bundle, config)
    await ctx.executor.send(
        _review_started_text(bundle=bundle, pipeline=pipeline, config=config),
        reply_to=ctx.message,
        notify=False,
    )
    prelead_reviewers = pipeline.specialists + pipeline.general
    prelead_outputs = await _run_prelead_reviews(
        ctx,
        bundle=bundle,
        config=config,
        reviewers=prelead_reviewers,
    )
    lead_output = await _run_single_review(
        ctx,
        reviewer=pipeline.lead,
        bundle=bundle,
        config=config,
        prelead_outputs=prelead_outputs,
    )
    outputs = prelead_outputs + (lead_output,)
    findings = _consolidate_findings(
        bundle=bundle,
        prelead_outputs=prelead_outputs,
        lead_output=lead_output,
    )
    report = ReviewReport(
        run_id=_make_run_id(),
        created_at=_utc_now(),
        bundle=bundle,
        specialist_reviewers=tuple(
            reviewer.reviewer_id for reviewer in pipeline.specialists
        ),
        general_reviewers=tuple(reviewer.reviewer_id for reviewer in pipeline.general),
        lead_reviewer=pipeline.lead.reviewer_id,
        raw_outputs=outputs,
        findings=findings,
        testing_gaps=_testing_gaps(bundle, outputs),
        report_path="",
        final_summary=lead_output.summary,
        missing_reviewers=pipeline.missing_reviewers,
        final_message_extra=dict(lead_output.message_extra),
    )
    report = _post_github_pr_comment(report, config=config)
    return _persist_review_report(report, config=config)


def review_report_markdown(report: ReviewReport) -> str:
    return _render_review_report(report)
