//! Unit tests for core game engine modules.
//!
//! Tests are organized in subdirectory matching src/core/ structure.

#[path = "unit/types_tests.rs"]
mod types_tests;
#[path = "unit/keywords_tests.rs"]
mod keywords_tests;
#[path = "unit/config_tests.rs"]
mod config_tests;
#[path = "unit/effects_tests.rs"]
mod effects_tests;
#[path = "unit/state_tests.rs"]
mod state_tests;
#[path = "unit/cards_tests.rs"]
mod cards_tests;
#[path = "unit/actions_tests.rs"]
mod actions_tests;
#[path = "unit/legal_tests.rs"]
mod legal_tests;
#[path = "unit/combat_tests.rs"]
mod combat_tests;
#[path = "unit/flanking_tests.rs"]
mod flanking_tests;
#[path = "unit/overload_tests.rs"]
mod overload_tests;
#[path = "unit/level_up_tests.rs"]
mod level_up_tests;
#[path = "unit/keyword_matrix_tests.rs"]
mod keyword_matrix_tests;
#[path = "unit/keyword_exhaustive_tests.rs"]
mod keyword_exhaustive_tests;
#[path = "unit/tensor_tests.rs"]
mod tensor_tests;
#[path = "unit/decks_tests.rs"]
mod decks_tests;
#[path = "unit/cmaes_tests.rs"]
mod cmaes_tests;
#[path = "unit/evaluator_tests.rs"]
mod evaluator_tests;
#[path = "unit/greedy_tests.rs"]
mod greedy_tests;
#[path = "unit/mcts_tests.rs"]
mod mcts_tests;
#[path = "unit/random_tests.rs"]
mod random_tests;
#[path = "unit/weights_tests.rs"]
mod weights_tests;
#[path = "unit/logger_tests.rs"]
mod logger_tests;
#[path = "unit/runner_tests.rs"]
mod runner_tests;
#[path = "unit/stats_tests.rs"]
mod stats_tests;
#[path = "unit/resource_system_tests.rs"]
mod resource_system_tests;
#[path = "unit/game_mode_tests.rs"]
mod game_mode_tests;
#[path = "unit/serialization_tests.rs"]
mod serialization_tests;
#[path = "unit/client_api_tests.rs"]
mod client_api_tests;
#[path = "unit/commander_tests.rs"]
mod commander_tests;
#[path = "unit/tracing_tests.rs"]
mod tracing_tests;
#[path = "unit/ability_tests.rs"]
mod ability_tests;
#[path = "unit/alphabeta_tests.rs"]
mod alphabeta_tests;
#[path = "unit/transposition_tests.rs"]
mod transposition_tests;
#[path = "unit/factory_tests.rs"]
mod factory_tests;
#[path = "unit/execution_tests.rs"]
mod execution_tests;
#[path = "unit/arena_tests.rs"]
mod arena_tests;
#[path = "unit/tuning_tests.rs"]
mod tuning_tests;
#[path = "unit/validation_tests.rs"]
mod validation_tests;
#[path = "unit/diagnostics_tests.rs"]
mod diagnostics_tests;
#[path = "unit/embedded_data_tests.rs"]
mod embedded_data_tests;
#[path = "unit/version_tests.rs"]
mod version_tests;
#[path = "unit/effect_context_tests.rs"]
mod effect_context_tests;
mod common;
#[path = "unit/prepare_tests.rs"]
mod prepare_tests;
#[path = "unit/game_engine_tests.rs"]
mod game_engine_tests;
#[path = "unit/effect_convert_tests.rs"]
mod effect_convert_tests;
#[path = "unit/replay_iterator_tests.rs"]
mod replay_iterator_tests;
#[path = "unit/introspection_tests.rs"]
mod introspection_tests;
#[path = "unit/stats_callback_tests.rs"]
mod stats_callback_tests;
