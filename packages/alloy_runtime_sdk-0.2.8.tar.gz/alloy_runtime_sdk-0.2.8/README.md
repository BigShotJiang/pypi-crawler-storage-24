# alloy-runtime-sdk

Python SDK for Alloy Runtime.

## Install

```bash
pip install alloy-runtime-sdk
```

## Quick start

```python
from alloy_runtime_sdk.api_client.client import ApiClient

async def main() -> None:
    async with ApiClient(
        base_url="https://your-alloy-runtime-host",
        api_key="your_api_key",
    ) as client:
        models = await client.list_models()
        print(models)
```

## What it includes

- Authenticated HTTP client methods for the Alloy Runtime API.
- Pipeline runtime helpers for Python-based pipeline steps.
- Structured logging helpers used by runtime integrations.

## Local pipeline runner

The SDK supports both Hosted execution and SDK local execution for pipelines.

Use `python -m alloy_runtime_sdk.pipeline.local_runner` to run a local pipeline module against a hosted Alloy Runtime, or call `run_local_pipeline()` directly from Python.

See `docs/pipelines/local_testing.md` for the full workflow and examples.

The SDK depends on `alloy-runtime-types`, which is published separately for stable,
versioned cross-package compatibility.
