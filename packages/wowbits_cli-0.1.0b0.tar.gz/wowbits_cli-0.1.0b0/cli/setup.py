#!/usr/bin/env python3
"""
WowBits CLI - Setup. Writes .env with WOWBITS_ROOT_DIR and WOWBITS_DB_CONNECTION_STRING.
No API calls; only prompts user and updates .env in the current directory.
"""
import sys
from pathlib import Path


def _env_path() -> Path:
    """Path to .env file (current directory)."""
    return Path.cwd() / ".env"


def _read_env_excluding(*keys: str) -> list:
    """Read .env lines, excluding lines that set any of the given keys."""
    path = _env_path()
    if not path.exists():
        return []
    out = []
    for line in path.read_text().splitlines():
        if "=" in line:
            key = line.split("=", 1)[0].strip()
            if key.upper() in (k.upper() for k in keys):
                continue
        out.append(line)
    return out


def run_setup(
    root_dir: str = None,
    db_url: str = None,
) -> None:
    """
    Prompt for WOWBITS_ROOT_DIR and WOWBITS_DB_CONNECTION_STRING (if not given),
    then write/update .env with those two variables.
    """
    if not root_dir:
        default = str(Path.home() / "wowbits")
        print(f"WOWBITS_ROOT_DIR (default: {default}):")
        root_dir = input().strip() or default
    if not root_dir:
        print("❌ WOWBITS_ROOT_DIR required (use --root-dir or enter when prompted)")
        sys.exit(1)
    root_path = Path(root_dir).expanduser().resolve()
    root_path.mkdir(parents=True, exist_ok=True)
    root_dir = str(root_path)

    if not db_url:
        default_db = f"sqlite:///{root_path / 'data' / 'wowbits.db'}"
        print(f"WOWBITS_DB_CONNECTION_STRING (default: {default_db}):")
        db_url = input().strip() or default_db
    if not db_url:
        print("❌ WOWBITS_DB_CONNECTION_STRING required (use --db-url or enter when prompted)")
        sys.exit(1)

    env_path = _env_path()
    existing = _read_env_excluding("WOWBITS_ROOT_DIR", "WOWBITS_DB_CONNECTION_STRING")
    block = "\n".join(existing) + "\n" if existing else ""
    block += f"WOWBITS_ROOT_DIR={root_dir}\nWOWBITS_DB_CONNECTION_STRING={db_url}\n"
    env_path.write_text(block)
    print("✅ Setup complete. .env updated with WOWBITS_ROOT_DIR and WOWBITS_DB_CONNECTION_STRING.")
    print(f"   {env_path}")


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser(description="Write WOWBITS_ROOT_DIR and WOWBITS_DB_CONNECTION_STRING to .env")
    p.add_argument("--root-dir", help="WowBits workspace root directory")
    p.add_argument("--db-url", help="Database URL (e.g. sqlite:///./data/wowbits.db)")
    a = p.parse_args()
    run_setup(root_dir=a.root_dir, db_url=a.db_url)
