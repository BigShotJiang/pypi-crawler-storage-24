#!/usr/bin/env python3
"""
WowBits CLI - Agent command (thin client).

Agent create/list/update/delete/run go through the API. This module only:
- Resolves YAML config path (workspace/agent_studio/<name>.yaml or -c path)
- Reads YAML and passes to API as yaml_content (API/core do all processing)

When run as __main__, delegates to API via api_client.
"""

import os
import sys
from pathlib import Path
from typing import Optional

# Ensure src is on path when run as script
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cli import api_client


def get_agent_studio_dir() -> Optional[Path]:
    """Return workspace agent_studio path from WOWBITS_ROOT_DIR."""
    root = os.environ.get("WOWBITS_ROOT_DIR")
    if not root:
        try:
            from dotenv import load_dotenv
            load_dotenv()
            root = os.environ.get("WOWBITS_ROOT_DIR")
        except ImportError:
            pass
    return Path(root).expanduser().resolve() / "agent_studio" if root else None


def resolve_agent_yaml_path(agent_name: str, config_path: Optional[str] = None) -> Path:
    """Resolve YAML file path: config_path if given, else agent_studio/<agent_name>.yaml."""
    if config_path:
        return Path(config_path).expanduser().resolve()
    studio = get_agent_studio_dir()
    if not studio:
        raise RuntimeError("WOWBITS_ROOT_DIR not set. Run 'wowbits setup' or set the env var.")
    return studio / f"{agent_name}.yaml"


def create_agent_via_api(agent_name: str, config_path: Optional[str] = None) -> None:
    """Read YAML from path, POST yaml_content to API. All processing is server-side."""
    yaml_path = resolve_agent_yaml_path(agent_name, config_path)
    if not yaml_path.exists():
        print(f"❌ Config not found: {yaml_path}")
        sys.exit(1)
    body = {"name": agent_name, "yaml_content": yaml_path.read_text(encoding="utf-8")}
    r = api_client.post("/agents", body)
    print("✅ Agent created/updated:", r)


def list_agents_via_api() -> None:
    """GET /agents and print table."""
    r = api_client.get("/agents")
    if not r:
        print("No agents.")
        return
    for a in r:
        print(f"{a.get('name')}\t{a.get('status')}\t{a.get('exec_mode')}\t{a.get('description', '')}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Manage agents (via WowBits API)")
    subparsers = parser.add_subparsers(dest="action", help="Action")
    create_parser = subparsers.add_parser("create", help="Create agent from YAML")
    create_parser.add_argument("name", help="Agent name")
    create_parser.add_argument("-c", "--config", help="Path to YAML config")
    subparsers.add_parser("list", help="List agents")
    args = parser.parse_args()
    try:
        api_client.get_base_url()
    except Exception as e:
        print(f"❌ {e}")
        sys.exit(1)
    if args.action == "create":
        create_agent_via_api(args.name, getattr(args, "config", None))
    elif args.action == "list":
        list_agents_via_api()
    else:
        parser.print_help()
