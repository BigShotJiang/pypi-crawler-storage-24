#!/usr/bin/env python3
"""
WowBits CLI - MCP (thin client).

All MCP operations go through the API. This module only:
- create: POST /mcps with {name} (API loads from workspace/mcps/<name>/config.yaml)
- run: POST /mcps/{name}/run (API runs setup.py and run.py in workspace)
"""

import sys
from pathlib import Path

# Ensure src is on path when run as script
import os
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from cli import api_client


def create_mcp(mcp_name: str) -> None:
    """Create MCP via API (server reads workspace/mcps/<mcp_name>/config.yaml)."""
    r = api_client.post("/mcps", {"name": mcp_name})
    print("✅ MCP created:", r)


def run_mcp(mcp_name: str) -> None:
    """Run MCP via API (server runs setup.py then run.py in workspace/mcps/<mcp_name>/)."""
    r = api_client.post(f"/mcps/{mcp_name}/run")
    print("✅ MCP run started:", r)


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="MCP commands (via WowBits API)")
    sub = parser.add_subparsers(dest="action", help="Action")
    create_p = sub.add_parser("create", help="Create MCP from workspace/mcps/<name>/config.yaml")
    create_p.add_argument("name", metavar="mcp_name", help="MCP name")
    run_p = sub.add_parser("run", help="Run MCP server")
    run_p.add_argument("name", metavar="mcp_name", help="MCP name")
    args = parser.parse_args()
    try:
        api_client.get_base_url()
    except Exception as e:
        print(f"❌ {e}")
        sys.exit(1)
    if args.action == "create":
        create_mcp(args.name)
    elif args.action == "run":
        run_mcp(args.name)
    else:
        parser.print_help()
