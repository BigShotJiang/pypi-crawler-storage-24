"""
CLI API client - all commands call WOWBITS_API_URL. No DB or subprocess.
"""
import json
import os
import sys
from typing import Any, Dict, Optional
from urllib import request
from urllib.error import HTTPError, URLError


def get_base_url() -> str:
    base = os.environ.get("WOWBITS_API_URL")
    if not base:
        print("❌ WOWBITS_API_URL is not set.", file=sys.stderr)
        print("   Set it to your WowBits API base URL (e.g. http://localhost:8000)", file=sys.stderr)
        sys.exit(1)
    return base.rstrip("/")


def _req(
    method: str,
    path: str,
    body: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    base = get_base_url()
    url = f"{base}{path}"
    data = None
    if body is not None:
        data = json.dumps(body).encode("utf-8")
    req = request.Request(
        url,
        data=data,
        method=method,
        headers={"Content-Type": "application/json"} if data else {},
    )
    try:
        with request.urlopen(req, timeout=60) as resp:
            raw = resp.read().decode("utf-8")
            if not raw:
                return {}
            return json.loads(raw)
    except HTTPError as e:
        raw = e.read().decode("utf-8") if e.fp else ""
        try:
            err = json.loads(raw)
            detail = err.get("detail", raw or str(e))
        except Exception:
            detail = raw or str(e)
        print(f"❌ API error ({e.code}): {detail}", file=sys.stderr)
        sys.exit(1)
    except URLError as e:
        reason = getattr(e, "reason", None)
        err_str = str(reason) if reason else str(e)
        if "Connection refused" in err_str or "61" in err_str:
            print("❌ Cannot reach API: connection refused.", file=sys.stderr)
            print("   The WowBits API server is not running.", file=sys.stderr)
            print("   Start it with: wowbits start", file=sys.stderr)
            print("   Then set WOWBITS_API_URL to match (e.g. http://localhost:8000).", file=sys.stderr)
        else:
            print(f"❌ Cannot reach API: {err_str}", file=sys.stderr)
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"❌ Invalid API response: {e}", file=sys.stderr)
        sys.exit(1)


def get(path: str) -> Any:
    return _req("GET", path)


def post(path: str, body: Optional[Dict[str, Any]] = None) -> Any:
    return _req("POST", path, body)


def patch(path: str, body: Dict[str, Any]) -> Any:
    return _req("PATCH", path, body)


def delete(path: str) -> Any:
    return _req("DELETE", path)
