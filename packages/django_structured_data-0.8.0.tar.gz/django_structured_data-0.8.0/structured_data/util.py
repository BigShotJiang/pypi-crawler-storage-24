import datetime
import json
from typing import Any

from django.conf import settings
from django.core.serializers.json import DjangoJSONEncoder
from django.utils.html import format_html_join

DEFAULT_STRUCTURED_DATA = getattr(settings, 'DEFAULT_STRUCTURED_DATA', {})

_json_script_escapes = {
    ord('>'): '\\u003E',
    ord('<'): '\\u003C',
    ord('&'): '\\u0026',
}


def json_encode(data: dict[str, Any]) -> str:
    return json.dumps(data, cls=DjangoJSONEncoder).translate(_json_script_escapes)


def format_time(value: Any) -> Any:
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    return value


def build_og_tags(properties: dict[str, Any]) -> str:
    formatted = ((k, format_time(v)) for k, v in properties.items())
    return format_html_join('\n', '<meta property="{}" content="{}" />', formatted)


def build_meta_tags(properties: dict[str, Any]) -> str:
    formatted = ((k, format_time(v)) for k, v in properties.items())
    return format_html_join('\n', '<meta name="{}" content="{}" />', formatted)


def sub_defaults(data: dict[str, Any]) -> dict[str, Any]:
    data_out = {}
    # if value is None, pull value from DEFAULT_STRUCTURED_DATA by key
    for key, value in data.items():
        if value is None:
            data_out[key] = DEFAULT_STRUCTURED_DATA[key]
        else:
            data_out[key] = value

    return data_out
