# System Architecture Analysis

## Overview

- **Project**: proxy
- **Language**: python
- **Files**: 119
- **Lines**: 34018
- **Functions**: 1035
- **Classes**: 106
- **Avg CC**: 3.6
- **Critical (CC≥10)**: 59

## Architecture

### docs/open-webui-tools/ (1 files, 90L, 9 functions)

- `proxym_tools.py` — 90L, 9 methods, CC↑1

### frontend/ (1 files, 6L, 0 functions)

- `proxym-dashboard.jsx` — 6L, 0 methods, CC↑0

### htmlcov/ (1 files, 735L, 65 functions)

- `coverage_html_cb_dd2e7eb5.js` — 735L, 65 methods, CC↑21

### root/ (1 files, 14L, 0 functions)

- `project.sh` — 14L, 0 methods, CC↑0

### scripts/ (5 files, 502L, 4 functions)

- `seed_sprint8.py` — 229L, 1 methods, CC↑10
- `proxym-voice-chat.py` — 73L, 3 methods, CC↑5
- `jetson-entrypoint.sh` — 43L, 0 methods, CC↑0
- `proxym-voice-server.sh` — 64L, 0 methods, CC↑0
- `setup.sh` — 93L, 0 methods, CC↑0

### services/vscode/ (1 files, 333L, 1 functions)

- `entrypoint.sh` — 333L, 1 methods, CC↑0

### src/proxym/ (4 files, 558L, 15 functions)

- `main.py` — 214L, 2 methods, CC↑10
- `ctl.py` — 206L, 10 methods, CC↑6
- `config.py` — 135L, 3 methods, CC↑3
- `__init__.py` — 3L, 0 methods, CC↑0

### src/proxym/accounts/ (1 files, 350L, 20 functions)

- `__init__.py` — 350L, 20 methods, CC↑10

### src/proxym/api/ (18 files, 2652L, 125 functions)

- `_diag_providers.py` — 54L, 1 methods, CC↑15
- `_diag_agent.py` — 213L, 3 methods, CC↑14
- `_diag_roo.py` — 77L, 1 methods, CC↑14
- `_diag_vscode.py` — 138L, 2 methods, CC↑14
- `completions.py` — 263L, 12 methods, CC↑13
- _13 more files_

### src/proxym/cache/ (1 files, 333L, 10 functions)

- `__init__.py` — 333L, 10 methods, CC↑9

### src/proxym/cli/ (15 files, 1987L, 95 functions)

- `tickets.py` — 311L, 13 methods, CC↑12
- `diagnostics.py` — 151L, 7 methods, CC↑11
- `_client.py` — 39L, 3 methods, CC↑9
- `chat.py` — 215L, 12 methods, CC↑9
- `accounts.py` — 124L, 6 methods, CC↑8
- _10 more files_

### src/proxym/cli/_groups/ (11 files, 1209L, 104 functions)

- `projects_ctl.py` — 205L, 8 methods, CC↑8
- `tickets_ctl.py` — 226L, 18 methods, CC↑7
- `tools_ctl.py` — 155L, 11 methods, CC↑6
- `accounts_ctl.py` — 86L, 8 methods, CC↑1
- `browser_ctl.py` — 53L, 6 methods, CC↑1
- _6 more files_

### src/proxym/context/ (5 files, 613L, 24 functions)

- `detector.py` — 208L, 9 methods, CC↑9
- `session.py` — 247L, 12 methods, CC↑7
- `tool_selector.py` — 101L, 2 methods, CC↑5
- `_context.py` — 33L, 1 methods, CC↑3
- `__init__.py` — 24L, 0 methods, CC↑0

### src/proxym/dashboard/ (11 files, 1645L, 104 functions)

- `tickets.py` — 370L, 23 methods, CC↑17
- `_system.py` — 139L, 6 methods, CC↑13
- `panel.jsx` — 38L, 6 methods, CC↑12
- `_projects_api.py` — 203L, 9 methods, CC↑10
- `_vms.py` — 175L, 12 methods, CC↑7
- _6 more files_

### src/proxym/dashboard/components/ (14 files, 2595L, 176 functions)

- `voice.jsx` — 298L, 31 methods, CC↑70
- `logs.jsx` — 158L, 9 methods, CC↑34
- `vms.jsx` — 275L, 30 methods, CC↑32
- `projects.jsx` — 406L, 15 methods, CC↑30
- `diagnostics.jsx` — 149L, 8 methods, CC↑26
- _9 more files_

### src/proxym/dashboard/components/diagnostics/ (5 files, 211L, 16 functions)

- `DiagConfig.jsx` — 59L, 4 methods, CC↑29
- `DiagExtensions.jsx` — 51L, 3 methods, CC↑20
- `DiagAgent.jsx` — 51L, 3 methods, CC↑11
- `DiagInfrastructure.jsx` — 28L, 2 methods, CC↑10
- `helpers.jsx` — 22L, 4 methods, CC↑4

### src/proxym/dashboard/hooks/ (1 files, 148L, 25 functions)

- `useDashboardData.js` — 148L, 25 methods, CC↑8

### src/proxym/dashboard/utils/ (1 files, 34L, 12 functions)

- `formatters.js` — 34L, 12 methods, CC↑7

### src/proxym/mcp/ (10 files, 1014L, 36 functions)

- `client.py` — 151L, 4 methods, CC↑6
- `router.py` — 95L, 4 methods, CC↑5
- `_tools_tickets.py` — 198L, 5 methods, CC↑4
- `_tools_vm.py` — 195L, 6 methods, CC↑4
- `registry.py` — 113L, 8 methods, CC↑4
- _5 more files_

### src/proxym/middleware/ (1 files, 70L, 4 functions)

- `__init__.py` — 70L, 4 methods, CC↑6

### src/proxym/observability/ (4 files, 919L, 37 functions)

- `repair_agent.py` — 341L, 9 methods, CC↑14
- `__init__.py` — 279L, 8 methods, CC↑7
- `watchdog.py` — 206L, 13 methods, CC↑7
- `health_events.py` — 93L, 7 methods, CC↑6

### src/proxym/projects/ (1 files, 281L, 14 functions)

- `__init__.py` — 281L, 14 methods, CC↑21

### src/proxym/providers/ (1 files, 331L, 4 functions)

- `__init__.py` — 331L, 4 methods, CC↑8

### src/proxym/router/ (2 files, 622L, 28 functions)

- `__init__.py` — 357L, 14 methods, CC↑9
- `strategy.py` — 265L, 14 methods, CC↑9

### src/proxym/tools/ (3 files, 627L, 29 functions)

- `__init__.py` — 227L, 9 methods, CC↑7
- `adapters.py` — 184L, 8 methods, CC↑5
- `executor.py` — 216L, 12 methods, CC↑5

### src/proxym/virt/ (13 files, 1601L, 69 functions)

- `_config.py` — 94L, 1 methods, CC↑9
- `_vm_config.py` — 220L, 7 methods, CC↑9
- `browser_profiles.py` — 325L, 11 methods, CC↑9
- `_lifecycle.py` — 236L, 12 methods, CC↑7
- `_state.py` — 94L, 5 methods, CC↑7
- _8 more files_

### src/proxym/virt/profiles/ (1 files, 69L, 4 functions)

- `__init__.py` — 69L, 4 methods, CC↑5

### src/proxym/watch/ (2 files, 150L, 5 functions)

- `__init__.py` — 146L, 5 methods, CC↑5
- `client.py` — 4L, 0 methods, CC↑0

## Key Exports

- **VoiceChat** (function, CC=70) ⚠ split
- **processInput** (function, CC=20) ⚠ split
- **formatToolResult** (function, CC=19) ⚠ split
- **LogPanel** (function, CC=34) ⚠ split
- **VMsPanel** (function, CC=32) ⚠ split
- **ProjectCard** (function, CC=30) ⚠ split
- **AddProjectForm** (function, CC=21) ⚠ split
- **DiagRooConfig** (function, CC=29) ⚠ split
- **DiagnosticsPanel** (function, CC=26) ⚠ split
- **table** (function, CC=21) ⚠ split
- **table_body_rows** (function, CC=21) ⚠ split
- **no_rows** (function, CC=21) ⚠ split
- **footer** (function, CC=21) ⚠ split
- **ratio_columns** (function, CC=21) ⚠ split
- **filter_handler** (function, CC=21) ⚠ split
- **ProjectRegistry** (class, CC̄=4.9)
  - `_enrich_local` CC=21 ⚠ split
- **DiagExtensions** (function, CC=20) ⚠ split
- **TicketsPanel** (function, CC=20) ⚠ split
- **formatToolResult** (function, CC=19) ⚠ split
- **Sprint** (class, CC̄=7.0)
- **TicketManager** (class, CC̄=3.9)
  - `_apply_filters` CC=17 ⚠ split
- **check_providers_config** (function, CC=15) ⚠ split
- **RepairAgent** (class, CC̄=5.4)
- **AccountCredentials** (class, CC̄=5.0)
- **ProjectsConfig** (class, CC̄=9.0)
- **_StateMixin** (class, CC̄=5.0)
- **_SnapshotMixin** (class, CC̄=5.0)
- **AiderAdapter** (class, CC̄=5.0)

## Hotspots (High Fan-Out)

- **VoiceChat** — fan-out=54: Orchestrates 54 calls
- **run_all_tests** — fan-out=28: Run all diagnostic tests and return comprehensive status.
- **chat_completions** — fan-out=27: OpenAI-compatible chat completions with intelligent routing.

Extra headers:
  X
- **DiagnosticsPanel** — fan-out=22: Orchestrates 22 calls
- **useDashboardData** — fan-out=20: Orchestrates 20 calls
- **AddProjectForm** — fan-out=20: Orchestrates 20 calls
- **LogPanel** — fan-out=19: Orchestrates 19 calls

## Refactoring Priorities

| # | Action | Impact | Effort |
|---|--------|--------|--------|
| 1 | Split DiagnosticsPanel (CC=26 → target CC<10) | high | low |
| 2 | Split LogPanel (CC=34 → target CC<10) | high | low |
| 3 | Split VoiceChat (CC=70 → target CC<10) | high | low |
| 4 | Split VMsPanel (CC=32 → target CC<10) | high | low |
| 5 | Split DiagRooConfig (CC=29 → target CC<10) | high | low |
| 6 | Split ProjectCard (CC=30 → target CC<10) | high | low |
| 7 | Split god module htmlcov/coverage_html_cb_dd2e7eb5.js (735L, 0 classes) | high | high |
| 8 | Split TicketManager._apply_filters (CC=17 → target CC<10) | medium | low |
| 9 | Split ProjectRegistry._enrich_local (CC=21 → target CC<10) | medium | low |
| 10 | Split check_providers_config (CC=15 → target CC<10) | medium | low |

## Context for LLM

When suggesting changes:
1. Start from hotspots and high-CC functions
2. Follow refactoring priorities above
3. Maintain public API surface — keep backward compatibility
4. Prefer minimal, incremental changes

