"""Click wrappers: tools group — tool registry + job queue CLI."""
from __future__ import annotations

import click


def _make_args(ctx: click.Context, **kwargs):
    from proxym.ctl import _make_args as _ma
    return _ma(ctx, **kwargs)


@click.group(name="tools")
def tools():
    """Manage AI development tools and job queue."""
    pass


@tools.command(name="list")
@click.option("--category", default=None, help="Filter: ide, agent_cli, browser")
@click.option("--available", is_flag=True, help="Only show tools found on PATH")
@click.pass_context
def tools_list(ctx: click.Context, category: str | None, available: bool):
    """List registered tools."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    params = {}
    if category:
        params["category"] = category
    if available:
        params["available_only"] = "true"
    r = c.get("/dashboard/tools/", params=params)
    data = r.json()
    if args.format == "yaml":
        print_json(data)
        return
    for t in data.get("tools", []):
        icon = "\033[32m\u2713\033[0m" if t.get("available") else "\033[31m\u2717\033[0m"
        click.echo(f"  {icon}  {t['name']:<15s}  {t.get('category', ''):<10s}  {t.get('description', '')}")


@tools.command(name="show")
@click.argument("tool_name")
@click.pass_context
def tools_show(ctx: click.Context, tool_name: str):
    """Show details for a specific tool."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get(f"/dashboard/tools/{tool_name}")
    print_json(r.json())


@tools.command(name="dispatch")
@click.option("--ticket", required=True, help="Ticket ID")
@click.option("--tool", required=True, help="Tool name (aider, claude-code, ...)")
@click.option("--mode", default="", help="Agent mode (code, architect, debug, ask)")
@click.option("--model", default="", help="Model alias or full name")
@click.option("--project-dir", default="", help="Project directory")
@click.pass_context
def tools_dispatch(ctx: click.Context, ticket: str, tool: str, mode: str, model: str, project_dir: str):
    """Dispatch a tool to work on a ticket."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.post("/dashboard/tools/dispatch", json={
        "ticket_id": ticket, "tool": tool, "mode": mode, "model": model, "project_dir": project_dir,
    })
    print_json(r.json())


@tools.command(name="queue")
@click.pass_context
def tools_queue(ctx: click.Context):
    """Show job queue status."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get("/dashboard/tools/queue")
    data = r.json()
    if args.format == "yaml":
        print_json(data)
        return
    click.echo(f"  Queue: {data.get('queue_size', 0)} pending  |  Total: {data.get('total_jobs', 0)}")
    click.echo(f"  Executor: {'running' if data.get('running') else 'stopped'}")
    for s, count in data.get("by_status", {}).items():
        click.echo(f"    {s}: {count}")


@tools.command(name="jobs")
@click.option("--status", default=None, help="Filter: queued, running, done, failed, cancelled")
@click.option("--limit", default=20, type=int, help="Max jobs to show")
@click.pass_context
def tools_jobs(ctx: click.Context, status: str | None, limit: int):
    """List jobs."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    params = {"limit": limit}
    if status:
        params["status"] = status
    r = c.get("/dashboard/tools/queue/jobs", params=params)
    data = r.json()
    if args.format == "yaml":
        print_json(data)
        return
    for j in data.get("jobs", []):
        st = j.get("status", "?")
        click.echo(f"  {j['id']}  {j.get('ticket_id', ''):<12s}  {j.get('tool', ''):<14s}  {st}")


@tools.command(name="job")
@click.argument("job_id")
@click.pass_context
def tools_job(ctx: click.Context, job_id: str):
    """Show details for a specific job."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.get(f"/dashboard/tools/queue/jobs/{job_id}")
    print_json(r.json())


@tools.command(name="cancel")
@click.argument("job_id")
@click.pass_context
def tools_cancel(ctx: click.Context, job_id: str):
    """Cancel a queued job."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.post(f"/dashboard/tools/queue/jobs/{job_id}/cancel", json={})
    print_json(r.json())


@tools.command(name="start")
@click.pass_context
def tools_start(ctx: click.Context):
    """Start the background executor."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.post("/dashboard/tools/queue/start", json={})
    print_json(r.json())


@tools.command(name="stop")
@click.pass_context
def tools_stop(ctx: click.Context):
    """Stop the background executor."""
    from proxym.cli._client import make_client, print_json
    args = _make_args(ctx)
    c = make_client(args.proxy, args.key)
    r = c.post("/dashboard/tools/queue/stop", json={})
    print_json(r.json())
