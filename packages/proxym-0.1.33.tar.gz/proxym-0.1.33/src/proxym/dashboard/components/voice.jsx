/**
 * components/voice.jsx
 *
 * VoiceChat React component.
 * Depends on globals from voice_schemas.jsx and voice_engine.jsx.
 */

function VoiceChat({ proxymBase, apiKey, model: initialModel = 'cheap' }) {
  _proxymBase = proxymBase;
  _apiKey = apiKey;

  const h = React.createElement;
  const [state, setState] = React.useState('idle');
  const [transcript, setTranscript] = React.useState('');
  const [response, setResponse] = React.useState('');
  const [statusMsg, setStatusMsg] = React.useState('');
  const [history, setHistory] = React.useState([]);
  const [error, setError] = React.useState('');
  const [ttsEnabled, setTtsEnabled] = React.useState(true);
  const [model, setModel] = React.useState(initialModel);
  const [lang, setLang] = React.useState('pl-PL');

  const recRef = React.useRef(null);
  const abortRef = React.useRef(null);

  const hasSR = !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  const hasTTS = !!(window.speechSynthesis);

  function startListening() {
    if (state !== 'idle') return;
    setError('');
    setTranscript('');
    setResponse('');
    setStatusMsg('');
    if (window.speechSynthesis?.speaking) window.speechSynthesis.cancel();

    if (!hasSR) {
      setError('Brak Web Speech API. Użyj Chrome lub Edge.');
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const r = new SR();
    r.lang = lang;
    r.continuous = false;
    r.interimResults = true;

    r.onstart = () => setState('listening');
    r.onerror = (e) => { setError(`Mikrofon: ${e.error}`); setState('idle'); };
    r.onend = () => { if (state === 'listening') setState('idle'); };
    r.onresult = (e) => {
      const text = Array.from(e.results).map(r => r[0].transcript).join('');
      setTranscript(text);
      if (e.results[e.results.length - 1].isFinal) {
        r.stop();
        processInput(text);
      }
    };
    recRef.current = r;
    r.start();
  }

  function stopListening() {
    recRef.current?.abort();
    setState('idle');
  }

  function stopSpeaking() {
    window.speechSynthesis?.cancel();
    setState('idle');
  }

  function stopAll() {
    stopListening();
    stopSpeaking();
    abortRef.current?.abort();
    setState('idle');
  }

  async function sendMessage(text) {
    return processInput(text);
  }

  async function processInput(text) {
    if (!text.trim()) return;
    setState('thinking');

    const dsl = matchDSL(text);
    if (dsl) {
      const label = typeof dsl.rule.label === 'function' ? dsl.rule.label(dsl.captured) : (dsl.rule.label || 'Wykonuję…');
      setStatusMsg(label);
      try {
        const reply = await executeDSL(dsl.rule, dsl.captured);
        setResponse(reply);
        setStatusMsg('');
        finish(reply, text);
      } catch (e) {
        setError(`Błąd akcji: ${e.message}`);
        setState('idle');
      }
      return;
    }

    setStatusMsg('Pytam model…');
    const messages = [
      {
        role: 'system',
        content:
          'Jesteś asystentem zarządzającym proxym. ' +
          'ZAWSZE używaj dostępnych narzędzi zamiast opisywać jak coś zrobić. ' +
          'Gdy użytkownik pyta o status, koszty, VM-y lub VS Code — wywołaj odpowiednie narzędzie. ' +
          'Odpowiadaj maksymalnie 1–2 zdaniami po ' + (lang === 'pl-PL' ? 'polsku' : 'angielsku') + '. ' +
          'Nie pisz instrukcji krok po kroku — działaj.',
      },
      ...history,
      { role: 'user', content: text },
    ];

    const ctrl = new AbortController();
    abortRef.current = ctrl;

    try {
      const res = await fetch(`${proxymBase}/v1/chat/completions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${apiKey}` },
        signal: ctrl.signal,
        body: JSON.stringify({
          model,
          messages,
          tools: TOOL_SCHEMA,
          tool_choice: 'auto',
          stream: false,
          max_tokens: 300,
        }),
      });

      const data = await res.json();
      const msg = data.choices?.[0]?.message;

      if (msg?.tool_calls?.length) {
        for (const tc of msg.tool_calls) {
          const name = tc.function.name;
          let args = {};
          try { args = JSON.parse(tc.function.arguments || '{}'); } catch {}

          setStatusMsg(`Wywołuję: ${name}…`);
          if (TOOL_DISPATCH[name]) {
            const toolResult = await TOOL_DISPATCH[name](args);
            const toolReply = formatToolResult(name, toolResult);
            setResponse(toolReply);
            setStatusMsg('');
            finish(toolReply, text);
            return;
          }
        }
      }

      const textReply = msg?.content || 'Brak odpowiedzi.';
      setResponse(textReply);
      setStatusMsg('');
      finish(textReply, text);
    } catch (e) {
      if (e.name !== 'AbortError') {
        setError(`LLM: ${e.message}`);
        setState('idle');
      }
    }
  }

  function formatToolResult(name, data) {
    switch (name) {
      case 'vscode_start':
        if (data.url) window.open(data.url, '_blank');
        return `VS Code ${data.running ? 'uruchomiony' : 'jest już uruchomiony'}. ${data.url || ''}`;
      case 'vm_action': {
        const vms = data.vms || data || [];
        if (Array.isArray(vms)) {
          return `Masz ${vms.length} VM-ów, ${vms.filter(v => v.state === 'running').length} aktywnych.`;
        }
        return `Operacja na VM zakończona.`;
      }
      case 'get_costs':
        return `Dziś: $${(data.daily_usd || 0).toFixed(3)}. Miesiąc: $${(data.monthly_usd || 0).toFixed(2)}.`;
      case 'get_status':
        return `proxym ${data.status === 'ok' ? 'działa' : 'ma problem'}.`;
      case 'get_logs': {
        const logs = data.logs || [];
        return logs.length ? `${logs.length} błędów. Ostatni: ${logs[0].message?.slice(0, 60)}.` : 'Brak błędów.';
      }
      default:
        return JSON.stringify(data).slice(0, 100);
    }
  }

  function finish(text, userText) {
    setHistory(h => [
      ...h.slice(-10),
      { role: 'user', content: userText },
      { role: 'assistant', content: text },
    ]);
    setState(ttsEnabled && hasTTS ? 'speaking' : 'idle');
    if (ttsEnabled && hasTTS && text) {
      const u = new SpeechSynthesisUtterance(text);
      u.lang = lang;
      u.rate = 1.05;
      u.onend = () => setState('idle');
      u.onerror = () => setState('idle');
      window.speechSynthesis.speak(u);
    }
  }

  React.useEffect(() => {
    const onKey = (e) => {
      if (e.code === 'Space' && e.target === document.body) {
        e.preventDefault();
        state === 'idle' ? startListening() : stopAll();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [state]);

  const STATE_CONFIG = {
    idle: { label: '🎤 Naciśnij aby mówić', color: '#444', icon: '🎤' },
    listening: { label: '🔴 Słucham…', color: '#e74c3c', icon: '⏹' },
    thinking: { label: statusMsg || '⏳ Działam…', color: '#f39c12', icon: '⏳' },
    speaking: { label: '🔊 Mówię…', color: '#27ae60', icon: '🔊' },
  };
  const sc = STATE_CONFIG[state];

  const styles = {
    container: { padding: '12px', fontFamily: '"JetBrains Mono", monospace', maxWidth: '600px' },
    header: { display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '10px', flexWrap: 'wrap' },
    title: { fontWeight: 'bold', fontSize: '13px', color: '#111' },
    select: { fontSize: '11px', padding: '2px 4px', background: '#fff', color: '#111', border: '1px solid #ddd', borderRadius: '3px' },
    toggleLabel: { fontSize: '11px', display: 'flex', gap: '4px', alignItems: 'center', color: '#555', cursor: 'pointer' },
    clearBtn: { fontSize: '11px', padding: '2px 8px', background: '#fff', color: '#555', border: '1px solid #ddd', borderRadius: '3px', cursor: 'pointer', marginLeft: 'auto' },
    micBtn: { display: 'block', margin: '0 auto 8px', width: '72px', height: '72px', borderRadius: '50%', border: 'none', cursor: 'pointer', fontSize: '28px', color: '#fff', transition: 'background 0.3s, transform 0.1s' },
    stateLabel: { textAlign: 'center', fontSize: '12px', marginBottom: '4px' },
    hint: { textAlign: 'center', fontSize: '10px', color: '#666', marginBottom: '10px' },
    bubble: (role) => ({
      background: role === 'user' ? '#eef2ff' : '#f3f4f6',
      border: `1px solid ${role === 'user' ? '#c7d2fe' : '#e5e7eb'}`,
      borderRadius: '10px',
      padding: '10px 12px',
      fontSize: '13px',
      marginBottom: '6px',
      color: '#111827',
      lineHeight: '1.5',
    }),
    roleLabel: (role) => ({ color: role === 'user' ? '#4338ca' : '#065f46', fontWeight: 'bold' }),
    error: { background: '#fee2e2', border: '1px solid #fecaca', borderRadius: '10px', padding: '8px 10px', color: '#b91c1c', fontSize: '12px', marginBottom: '6px' },
    chipBtn: { fontSize: '10px', padding: '3px 8px', background: '#fff', color: '#555', border: '1px solid #ddd', borderRadius: '12px', cursor: 'pointer' },
    historyBox: { marginTop: '8px', maxHeight: '120px', overflowY: 'auto', background: '#fff', border: '1px solid #eee', borderRadius: '10px', padding: '6px 8px' },
  };

  return h('div', { style: styles.container },
    h('div', { style: styles.header },
      h('span', { style: styles.title }, '🎙 Głos AI'),
      h('span', { style: { fontSize: '10px', color: '#555', marginRight: 'auto' } },
        'Web Speech API • STT ' + (hasSR ? '✓' : '✗') + ' • TTS ' + (hasTTS ? '✓' : '✗'),
      ),
      h('select', { value: model, onChange: e => setModel(e.target.value), style: styles.select },
        [['cheap','cheap (Haiku)'],['balanced','balanced (Sonnet)'],['free','free (Gemini)'],['local','local (Ollama)'],['premium','premium (Opus)']]
          .map(([v,l]) => h('option', { key: v, value: v }, l))
      ),
      h('select', { value: lang, onChange: e => setLang(e.target.value), style: styles.select },
        [['pl-PL','Polski'],['en-US','English'],['de-DE','Deutsch']]
          .map(([v,l]) => h('option', { key: v, value: v }, l))
      ),
      h('label', { style: styles.toggleLabel },
        h('input', { type: 'checkbox', checked: ttsEnabled, onChange: e => setTtsEnabled(e.target.checked) }),
        '🔊 TTS',
      ),
      h('button', { onClick: () => { setHistory([]); setResponse(''); setTranscript(''); setError(''); }, style: styles.clearBtn }, 'Wyczyść'),
    ),

    h('button', { onClick: state === 'idle' ? startListening : stopAll, style: { ...styles.micBtn, background: sc.color }, title: 'Spacja = nasłuchuj' }, sc.icon),
    h('div', { style: { ...styles.stateLabel, color: sc.color } }, sc.label),
    h('div', { style: styles.hint }, 'Spacja = nasłuchuj / zatrzymaj'),
    transcript && h('div', { style: styles.bubble('user') }, h('span', { style: styles.roleLabel('user') }, 'Ty: '), transcript),
    response && h('div', { style: styles.bubble('ai') }, h('span', { style: styles.roleLabel('ai') }, 'proxym: '), response),
    error && h('div', { style: styles.error }, '⚠ ' + error),
    h('details', { style: { marginTop: '8px' } },
      h('summary', { style: { fontSize: '11px', color: '#555', cursor: 'pointer' } }, 'Dostępne komendy'),
      h('div', { style: { display: 'flex', flexWrap: 'wrap', gap: '4px', marginTop: '6px' } },
        ['uruchom vscode','zatrzymaj vscode','status vscode','pokaż VM-y','ile wydałem','logi','status','test routing','jakie modele','pokaż konta']
          .map(cmd => h('button', { key: cmd, onClick: () => processInput(cmd), style: styles.chipBtn }, cmd))
      )
    ),
    history.length > 0 && h('div', { style: styles.historyBox },
      history.slice(-8).map((m, i) =>
        h('div', { key: i, style: { color: m.role === 'user' ? '#4338ca' : '#065f46', fontSize: '11px', padding: '1px 0' } },
          (m.role === 'user' ? 'Ty: ' : 'AI: ') + m.content
        )
      )
    ),
  );
}
