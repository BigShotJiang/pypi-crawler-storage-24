"""System status, providers, logs, and projects endpoints for dashboard API."""
from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter

from proxym.accounts import AccountManager
from proxym.config import get_settings
from proxym.providers import MODELS
from proxym.virt import VMOrchestrator

router = APIRouter(tags=["system"])

# Singletons
_acct_mgr: AccountManager | None = None
_vm_orch: VMOrchestrator | None = None


def _accounts() -> AccountManager:
    global _acct_mgr
    if _acct_mgr is None:
        _acct_mgr = AccountManager()
    return _acct_mgr


def _vms() -> VMOrchestrator:
    global _vm_orch
    if _vm_orch is None:
        _vm_orch = VMOrchestrator()
    return _vm_orch


# ── System status ────────────────────────────────────────────

@router.get("/")
async def dashboard_root():
    """Dashboard root - redirects to system status."""
    return await system_status()


@router.get("/system")
async def system_status():
    """Full system overview: accounts + VMs + costs + libvirt + providers."""
    settings = get_settings()
    libvirt = VMOrchestrator.check_libvirt_available()
    configured = settings.available_providers()
    return {
        "accounts": _accounts().get_cost_summary(),
        "vms": {
            "total": len(_vms().vms),
            "running": sum(1 for v in _vms().vms.values() if v.state.value == "running"),
        },
        "libvirt": libvirt,
        "providers": {
            "configured": list(configured.keys()),
            "total_models": sum(
                1 for m in MODELS.values() if m.provider in configured
            ),
        },
    }


@router.get("/providers")
async def list_providers():
    """Show configured providers from .env and their model counts."""
    settings = get_settings()
    configured = settings.available_providers()
    providers = []
    for name, key in configured.items():
        model_count = sum(1 for m in MODELS.values() if m.provider == name)
        # Ollama doesn't require API key (local service)
        is_active = name == "ollama" or (name != "ollama" and bool(key))
        providers.append({
            "name": name,
            "configured": True,
            "has_key": is_active,
            "model_count": model_count,
        })
    return {"providers": providers}


@router.get("/logs")
async def get_logs(lines: int = 50, level: str | None = None):
    """Get recent log entries from proxym log file."""
    import time

    log_paths = [
        Path.home() / ".local/share/proxym/proxym.log",
        Path("/var/log/proxym/proxym.log"),
        Path("./proxym.log"),
    ]

    log_file = None
    for p in log_paths:
        if p.exists():
            log_file = p
            break

    if not log_file:
        return {"logs": [], "error": "No log file found"}

    try:
        with open(log_file, "r") as f:
            all_lines = f.readlines()

        # Get last N lines
        recent = all_lines[-lines:]

        logs = []
        for line in recent:
            line = line.strip()
            if not line:
                continue

            # Parse structured log lines (timestamp level message)
            parts = line.split(" ", 2)
            if len(parts) >= 2:
                timestamp = parts[0] if len(parts) > 0 else ""
                log_level = parts[1] if len(parts) > 1 else "INFO"
                message = parts[2] if len(parts) > 2 else line
            else:
                timestamp = time.strftime("%Y-%m-%dT%H:%M:%S")
                log_level = "INFO"
                message = line

            # Filter by level if specified
            if level and log_level.upper() != level.upper():
                continue

            logs.append({
                "timestamp": timestamp,
                "level": log_level.upper(),
                "message": message,
            })

        return {"logs": logs[-lines:], "source": str(log_file)}
    except Exception as e:
        return {"logs": [], "error": str(e)}
