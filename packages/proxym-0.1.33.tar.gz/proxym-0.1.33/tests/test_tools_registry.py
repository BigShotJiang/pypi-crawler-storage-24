"""Tests for ToolRegistry, ToolDefinition, and builtins."""

import pytest

from proxym.tools import (
    ToolCategory,
    ToolCapability,
    ToolDefinition,
    ToolRegistry,
)


class TestToolDefinition:
    def test_summary_keys(self):
        t = ToolDefinition(name="test-tool", category=ToolCategory.IDE, binary="nonexistent-xyz")
        s = t.summary()
        assert set(s.keys()) == {
            "name", "category", "binary", "available",
            "capabilities", "modes", "default_model", "description",
        }

    def test_is_available_false_for_missing_binary(self):
        t = ToolDefinition(name="x", category=ToolCategory.IDE, binary="nonexistent-xyz-binary")
        assert t.is_available is False

    def test_is_available_false_for_empty_binary(self):
        t = ToolDefinition(name="x", category=ToolCategory.BROWSER, binary="")
        assert t.is_available is False

    def test_capabilities_in_summary(self):
        t = ToolDefinition(
            name="x", category=ToolCategory.AGENT_CLI,
            capabilities=[ToolCapability.CODE_EDIT, ToolCapability.CHAT],
        )
        s = t.summary()
        assert s["capabilities"] == ["code_edit", "chat"]


class TestToolRegistry:
    def setup_method(self):
        # Reset singleton for test isolation
        ToolRegistry._instance = None

    def test_singleton(self):
        r1 = ToolRegistry.get()
        r2 = ToolRegistry.get()
        assert r1 is r2

    def test_builtin_count(self):
        r = ToolRegistry.get()
        tools = r.list_tools()
        assert len(tools) == 8

    def test_builtin_names(self):
        r = ToolRegistry.get()
        names = {t.name for t in r.list_tools()}
        expected = {"aider", "claude-code", "windsurf", "cursor", "vscode", "roo-code", "cline", "browser"}
        assert names == expected

    def test_get_tool(self):
        r = ToolRegistry.get()
        t = r.get_tool("aider")
        assert t is not None
        assert t.category == ToolCategory.AGENT_CLI

    def test_get_tool_missing(self):
        r = ToolRegistry.get()
        assert r.get_tool("nonexistent") is None

    def test_register_custom(self):
        r = ToolRegistry.get()
        custom = ToolDefinition(name="my-tool", category=ToolCategory.CUSTOM, binary="mytool")
        r.register(custom)
        assert r.get_tool("my-tool") is not None
        assert len(r.list_tools()) == 9  # 8 builtins + 1

    def test_unregister(self):
        r = ToolRegistry.get()
        r.register(ToolDefinition(name="tmp", category=ToolCategory.CUSTOM))
        assert r.unregister("tmp") is True
        assert r.get_tool("tmp") is None

    def test_unregister_missing(self):
        r = ToolRegistry.get()
        assert r.unregister("nonexistent") is False

    def test_list_by_category(self):
        r = ToolRegistry.get()
        cli_tools = r.list_tools(category=ToolCategory.AGENT_CLI)
        names = {t.name for t in cli_tools}
        assert "aider" in names
        assert "claude-code" in names
        assert "vscode" not in names

    def test_summary_structure(self):
        r = ToolRegistry.get()
        s = r.summary()
        assert "total" in s
        assert "available" in s
        assert "tools" in s
        assert s["total"] == 8
        assert isinstance(s["tools"], list)

    def test_sorted_by_name(self):
        r = ToolRegistry.get()
        tools = r.list_tools()
        names = [t.name for t in tools]
        assert names == sorted(names)
