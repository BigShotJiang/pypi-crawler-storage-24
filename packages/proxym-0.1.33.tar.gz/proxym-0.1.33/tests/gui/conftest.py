"""Shared fixtures for GUI (Playwright) tests.

These tests require:
  pip install pytest-playwright
  playwright install chromium

Run with:
  pytest tests/gui/ -m playwright --headed   # z przeglądarką
  pytest tests/gui/ -m playwright             # headless (CI)
"""
from __future__ import annotations

import pytest

# Mark all async tests in gui/ as playwright
pytestmark = pytest.mark.playwright

DASHBOARD_URL = "http://localhost:4000"


@pytest.fixture
def dashboard_url():
    """Base URL dashboardu proxym."""
    return DASHBOARD_URL


@pytest.fixture
def project_name():
    """Nazwa testowego projektu (musi istnieć w systemie)."""
    return "proxym"
