"""S7: CLI = REST parity (CLI Shell).

SCENARIUSZ: Każda operacja CLI ma odpowiednik REST i daje ten sam wynik.

Testujemy przez Click CliRunner, nie subprocess — szybciej i bez potrzeby
uruchomionego serwera.
"""
from __future__ import annotations

import pytest


class TestCLIProjectParity:
    """S7.1: proxym project = REST /dashboard/projects."""

    def test_project_list_cli(self, runner, cli):
        result = runner.invoke(cli, ["project", "list"])
        assert result.exit_code == 0

    def test_project_add_local_cli(self, runner, cli, tmp_path):
        proj = tmp_path / "cli-test-proj"
        proj.mkdir()
        (proj / "README.md").write_text("# test")
        result = runner.invoke(cli, ["project", "add", str(proj)])
        assert result.exit_code == 0

    def test_project_scan_cli(self, runner, cli, tmp_path):
        (tmp_path / "scan-proj" / ".git").mkdir(parents=True)
        result = runner.invoke(cli, ["project", "scan", str(tmp_path)])
        assert result.exit_code == 0


class TestCLITicketParity:
    """S7.2: proxym ticket = REST /dashboard/tickets."""

    def test_ticket_add_minimal_cli(self, runner, cli):
        """proxym ticket add "napraw bug" — jedno pole."""
        result = runner.invoke(cli, ["ticket", "add", "napraw bug w routerze"])
        assert result.exit_code == 0
        assert "T-" in result.output  # ticket ID

    def test_ticket_add_with_project_and_tool(self, runner, cli):
        result = runner.invoke(cli, [
            "ticket", "add", "zrefaktoryzuj panel",
            "-p", "proxym", "-t", "aider", "--priority", "high",
        ])
        # May fail if project 'proxym' not found, but command is recognized
        assert result.exit_code in (0, 1)

    def test_ticket_list_cli(self, runner, cli):
        result = runner.invoke(cli, ["ticket", "list"])
        assert result.exit_code == 0

    def test_ticket_board_cli(self, runner, cli):
        result = runner.invoke(cli, ["ticket", "board"])
        assert result.exit_code == 0


class TestCLIToolsParity:
    """S7.3: proxym tools = REST /dashboard/tools."""

    def test_tools_list_cli(self, runner, cli):
        result = runner.invoke(cli, ["tools", "list"])
        assert result.exit_code == 0
        assert "aider" in result.output

    def test_tools_dispatch_cli(self, runner, cli):
        result = runner.invoke(cli, [
            "tools", "dispatch", "--ticket", "T-000001", "--tool", "aider",
        ])
        # May fail if ticket doesn't exist, but command should be recognized
        assert result.exit_code in (0, 1)

    def test_tools_queue_cli(self, runner, cli):
        result = runner.invoke(cli, ["tools", "queue"])
        assert result.exit_code == 0


class TestCLIDiagnoseParity:
    """S7.4: proxym diagnose = REST /tests/*."""

    def test_diagnose_all_cli(self, runner, cli):
        result = runner.invoke(cli, ["diagnose", "all"])
        assert result.exit_code in (0, 1)  # may fail if proxy not running

    def test_obs_health_cli(self, runner, cli):
        result = runner.invoke(cli, ["obs", "health"])
        assert result.exit_code in (0, 1)

    def test_obs_errors_cli(self, runner, cli):
        result = runner.invoke(cli, ["obs", "errors"])
        assert result.exit_code in (0, 1)

    def test_obs_logs_cli(self, runner, cli):
        result = runner.invoke(cli, ["obs", "logs", "-n", "10"])
        assert result.exit_code in (0, 1)
