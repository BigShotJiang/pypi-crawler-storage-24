# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added
- **Voice Chat Interface** (`proxym chat [--voice] [--tts]`)
  - DSL parser for natural language commands in Polish and English (zero-token, no LLM)
  - LLM fallback with MCP tool calling for complex queries
  - Voice input via Faster-Whisper local STT (`pip install proxym[voice]`)
  - Text-to-speech output via espeak-ng / Piper (`pip install proxym[tts]`)
- **MCP Self-Server** at `/mcp/self/tools/*` — exposes VM, account, model, and log management as HTTP tools for LLM function calling
- **Open WebUI integration** — drop-in tools file at `docs/open-webui-tools/proxym_tools.py`
- **DSL YAML config** — user-customizable command patterns at `~/.config/proxym/dsl.yaml`
- New optional dependency groups: `voice`, `tts`
- Tests: `test_dsl.py` (35 tests), `test_self_mcp.py` (8 tests), `test_chat.py` (8 tests)

### Fixed
- **API completions**: Fixed `MagicMock` serialization in `_response_to_dict` — check `isinstance(dict)` before accepting `model_dump()` result; guard `_usage_tokens` against non-int values
- **API completions**: Model alias resolution now searches MODELS by `litellm_model` string, not just registry key — fixes `cheap`/`premium` routing to correct models
- **API completions**: Generic upstream exceptions return 502 consistently; `httpx` retry-path inner failures return 503
- **Context API**: Removed duplicate `/v1/context/stats` route from `system.py` that shadowed `context_api.py` (broke test patching); fixed compat-key spread order so `projects_tracked`/`tokens_total` are present
- **Context API**: Accept legacy delta payload format (`payload` + `version`) alongside `project_id` + `diff_text`
- **Auth middleware**: `_accepted_tokens()` dynamically reads `get_settings()` so env-patched test keys are recognized after settings cache clear
- **Dashboard exports**: Re-export `cost_summary`, `get_logs`, `list_accounts`, `list_vms`, `start_vm`, `stop_vm`, `snapshot_vm` from `proxym.dashboard` package for `voice_actions.py`
- **Console endpoint**: Fixed `_vms` import collision — import function from `_vms` sub-module directly instead of package-level module name
- **Test fixtures**: `authed_client` no longer mutates the shared `client` fixture (separate `TestClient` instance); dashboard/tickets test fixtures now reset singletons on correct sub-modules (`_accounts`, `_costs`, `_system`, `_vms`, `_tickets_api`); e2e/project-e2e fixtures patch env vars and reset `_state` singletons
- **CLI accounts**: Guard `status_code >= 400` check with `isinstance(int)` to handle `MagicMock` responses
- Dashboard VM start endpoint no longer tries raw `virsh` subprocess fallback on failure
- MCP self-server auth bypass (`/mcp/` paths skip bearer token check like `/dashboard/`)

## [0.1.33] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/conftest.py
- Update tests/e2e/__init__.py
- Update tests/e2e/conftest.py
- Update tests/e2e/test_scenario_cli_parity.py
- Update tests/e2e/test_scenario_error_recovery.py
- Update tests/e2e/test_scenario_multi_tool.py
- Update tests/e2e/test_scenario_observability.py
- Update tests/e2e/test_scenario_projects.py
- Update tests/e2e/test_scenario_ticket_lifecycle.py
- Update tests/e2e/test_scenario_tool_execution.py
- ... and 7 more files

### Other
- Update Makefile
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- ... and 6 more files

## [0.1.32] - 2026-03-23

### Docs
- Update README.md
- Update docs/README.md
- Update project/context.md

### Test
- Update tests/test_project_e2e.py

### Other
- Update .env.example
- Update frontend/dashboard.html
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/dashboard.html
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- Update project/index.html
- ... and 11 more files

## [0.1.31] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_repair_agent.py
- Update tests/test_tool_adapters.py
- Update tests/test_tools_api.py

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 5 more files

## [0.1.30] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_projects.py

### Other
- Update frontend/dashboard.html
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- ... and 9 more files

## [0.1.29] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_executor.py
- Update tests/test_observability.py
- Update tests/test_prompt_builder.py

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 5 more files

## [0.1.28] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_tools_registry.py

### Other
- Update .env.example
- Update frontend/dashboard.html
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- ... and 7 more files

## [0.1.27] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/gui/test_gui_accounts.py
- Update tests/gui/test_gui_components.py
- Update tests/gui/test_gui_navigation.py
- Update tests/gui/test_gui_voice_diag.py
- Update tests/gui/test_gui_vscode.py
- Update tests/test_dashboard_gui.py
- Update tests/test_dashboard_integration.py
- Update tests/test_dashboard_performance.py

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 8 more files

## [0.1.26] - 2026-03-23

### Test
- Update tests/test_tool_health.py

## [0.1.25] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_dashboard_api.py
- Update tests/test_project_e2e.py
- Update tests/test_tickets_api.py

### Other
- Update frontend/dashboard.html
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- ... and 6 more files

## [0.1.24] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/conftest.py
- Update tests/test_api_completions.py
- Update tests/test_dashboard.py
- Update tests/test_e2e.py
- Update tests/test_lifecycle.py
- Update tests/test_router.py
- Update tests/test_routing_status.py
- Update tests/test_tool_health.py
- Update tests/test_vm_console_endpoint.py

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 5 more files

## [0.1.23] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 4 more files

## [0.1.22] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_project_e2e.py

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 6 more files

## [0.1.21] - 2026-03-23

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_project_e2e.py
- Update tests/test_tickets.py
- Update tests/test_tickets_api.py

### Other
- Update Makefile
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- ... and 11 more files

## [0.1.20] - 2026-03-23

### Docs
- Update README.md
- Update docs/DASHBOARD_VOICE_NOVNC.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_routing_status.py
- Update tests/test_vm_console_endpoint.py

### Other
- Update Makefile
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- ... and 10 more files

## [0.1.19] - 2026-03-22

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 6 more files

## [0.1.18] - 2026-03-22

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/gui/test_gui_base.py
- Update tests/gui/test_gui_voice_diag.py
- Update tests/test_dashboard_api.py
- Update tests/test_dashboard_integration.py

### Other
- Update frontend/dashboard.html
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- ... and 8 more files

## [0.1.17] - 2026-03-22

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Other
- Update frontend/dashboard.html
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- ... and 10 more files

## [0.1.16] - 2026-03-22

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Test
- Update tests/gui/test_gui_vscode.py

### Other
- Update .toonignore
- Update TODO/conftest.py
- Update TODO/pytest.ini
- Update TODO/test_vscode_gui.py
- Update frontend/dashboard.html
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- ... and 17 more files

## [0.1.15] - 2026-03-22

### Test
- Update tests/test_lifecycle.py
- Update tests/test_vm_config.py
- Update tests/test_vscode.py

### Other
- Update .env.example
- Update .toonignore
- Update Makefile
- Update frontend/dashboard.html
- Update services/vscode/Dockerfile
- Update services/vscode/entrypoint.sh
- Update services/vscode/login.html
- Update src/proxym/dashboard/components/accounts.jsx
- Update src/proxym/dashboard/components/layout.jsx
- Update src/proxym/dashboard/components/logs.jsx
- ... and 6 more files

## [0.1.14] - 2026-03-22

### Docs
- Update docs/README.md
- Update docs/VM_FIXLOG.md
- Update docs/open-webui-tools/proxym_tools.py
- Update project/README.md
- Update project/context.md

### Test
- Update tests/test_chat.py
- Update tests/test_dsl.py
- Update tests/test_self_mcp.py

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 8 more files

## [0.1.13] - 2026-03-22

### Other
- Update src/proxym/dashboard/panel.jsx

## [0.1.12] - 2026-03-21

### Docs
- Update docs/README.md

### Test
- Update tests/conftest.py
- Update tests/test_dashboard_integration.py

## [0.1.11] - 2026-03-21

### Other
- Update src/proxym/dashboard/hooks/useDashboardData.js

## [0.1.10] - 2026-03-21

### Docs
- Update docs/README.md
- Update project/README.md
- Update project/context.md

### Other
- Update project/analysis.toon
- Update project/calls.mmd
- Update project/calls.png
- Update project/compact_flow.mmd
- Update project/compact_flow.png
- Update project/dashboard.html
- Update project/evolution.toon
- Update project/flow.mmd
- Update project/flow.png
- Update project/flow.toon
- ... and 5 more files

## [0.1.9] - 2026-03-21

### Docs
- Update docs/README.md
- Update project/README.md

### Test
- Update tests/test_dashboard_live.py
- Update tests/test_dashboard_new.py

### Other
- Update .toonignore
- Update frontend/dashboard.html
- Update frontend/proxym-dashboard.jsx
- Update project/analysis.json
- Update project/analysis.yaml
- Update project/calls.png
- Update project/evolution.toon
- Update project/flow.png
- Update project/index.html
- Update project/project.toon
- ... and 4 more files

## [0.1.8] - 2026-03-21

### Docs
- Update docs/README.md
- Update project/CONTRIBUTING.md
- Update project/README.md
- Update project/api-changelog.md
- Update project/api.md
- Update project/architecture.md
- Update project/configuration.md
- Update project/context.md
- Update project/coverage.md
- Update project/dependency-graph.md
- ... and 2 more files

### Test
- Update tests/test_context.py
- Update tests/test_dashboard_live.py
- Update tests/test_mcp.py

### Other
- Update .code2docs.api_snapshot.json
- Update .env.example
- Update Makefile
- Update frontend/dashboard.html
- Update frontend/proxym-dashboard.jsx
- Update project/analysis.json
- Update project/analysis.toon
- Update project/analysis.yaml
- Update project/calls.mmd
- Update project/calls.png
- ... and 16 more files

## [0.1.7] - 2026-03-21

### Docs
- Update README.md
- Update docs/README.md

### Test
- Update tests/test_browser_profiles.py
- Update tests/test_clonebox_adapter.py
- Update tests/test_dashboard_live.py

### Other
- Update src/proxym/virt/profiles/browser.clonebox.yaml
- Update src/proxym/virt/profiles/cursor.clonebox.yaml
- Update src/proxym/virt/profiles/jetbrains.clonebox.yaml
- Update src/proxym/virt/profiles/vscode.clonebox.yaml
- Update src/proxym/virt/profiles/windsurf.clonebox.yaml

## [0.1.6] - 2026-03-21

### Test
- Update tests/test_dashboard_new.py

### Other
- Update frontend/dashboard.html
- Update frontend/proxym-dashboard.jsx

## [0.1.5] - 2026-03-21

### Docs
- Update README.md
- Update docs/README.md

### Test
- Update tests/test_dashboard_gui.py
- Update tests/test_dashboard_integration.py
- Update tests/test_dashboard_live.py
- Update tests/test_dashboard_new.py
- Update tests/test_dashboard_performance.py

### Other
- Update dashboard.html
- Update proxym-dashboard.jsx

## [0.1.4] - 2026-03-21

### Docs
- Update README.md

### Test
- Update tests/conftest.py
- Update tests/test_accounts.py
- Update tests/test_analyzer.py
- Update tests/test_dashboard.py
- Update tests/test_delta_buffer.py
- Update tests/test_e2e.py
- Update tests/test_router.py

## [0.1.3] - 2026-03-21

### Docs
- Update CHANGELOG.md
- Update README.md

### Other
- Update Dockerfile.jetson
- Update docker-compose.prod.yml
- Update proxym-dashboard.jsx
- Update quadlet/ollama.container
- Update quadlet/proxym.container
- Update quadlet/proxym.network
- Update quadlet/redis.container
- Update scripts/jetson-entrypoint.sh
- Update scripts/setup.sh
- Update src/proxym/dashboard/panel.jsx
- ... and 1 more files

## [0.1.2] - 2026-03-21

## [0.1.1] - 2026-03-21

### Docs
- Update README.md

### Test
- Update tests/conftest.py
- Update tests/test_accounts.py
- Update tests/test_analyzer.py
- Update tests/test_dashboard.py
- Update tests/test_delta_buffer.py
- Update tests/test_e2e.py
- Update tests/test_router.py

### Other
- Update .env.example
- Update .gitignore
- Update Dockerfile.jetson
- Update proxym-dashboard.jsx
- Update docker-compose.prod.yml
- Update project.sh
- Update quadlet/proxym.container
- Update quadlet/proxym.network
- Update quadlet/ollama.container
- Update quadlet/redis.container
- ... and 4 more files

