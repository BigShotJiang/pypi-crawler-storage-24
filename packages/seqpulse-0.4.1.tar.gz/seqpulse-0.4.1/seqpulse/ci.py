from __future__ import annotations

import json
import os
import urllib.error
import urllib.request
from typing import Callable

CiTransport = Callable[[str, dict[str, str], str, float], tuple[int, str]]


def _normalize_base_url(base_url: str | None) -> str:
    return (base_url or "").rstrip("/")


def _safe_json_parse(value: str) -> dict:
    if not value:
        return {}
    try:
        parsed = json.loads(value)
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        return {}
    return {}


def infer_result_from_pipeline_status(status: str | None) -> str:
    normalized = (status or "").strip().lower()
    if normalized in {"success", "ok", "pass", "passed"}:
        return "success"
    return "failed"


def build_ci_idempotency_key() -> str:
    github_run_id = os.getenv("GITHUB_RUN_ID")
    if github_run_id:
        return f"gha-{github_run_id}-{os.getenv('GITHUB_RUN_ATTEMPT', '1')}"

    gitlab_pipeline_id = os.getenv("CI_PIPELINE_ID")
    if gitlab_pipeline_id:
        return f"gl-{gitlab_pipeline_id}-{os.getenv('CI_PIPELINE_IID', '1')}"

    circle_workflow_id = os.getenv("CIRCLE_WORKFLOW_ID")
    if circle_workflow_id:
        return f"circle-{circle_workflow_id}-{os.getenv('CIRCLE_BUILD_NUM', '1')}"

    jenkins_build = os.getenv("BUILD_TAG") or os.getenv("BUILD_ID")
    if jenkins_build:
        return f"jenkins-{jenkins_build}"

    return f"seqpulse-{int(os.times().elapsed * 1000)}"


def infer_branch_name() -> str:
    return (
        os.getenv("GITHUB_REF_NAME")
        or os.getenv("CI_COMMIT_REF_NAME")
        or os.getenv("CIRCLE_BRANCH")
        or os.getenv("BRANCH_NAME")
        or "unknown"
    )


def _default_transport(url: str, headers: dict[str, str], body: str, timeout_seconds: float) -> tuple[int, str]:
    request = urllib.request.Request(
        url=url,
        data=body.encode("utf-8"),
        headers=headers,
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout_seconds) as response:
            return int(response.getcode()), response.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        body_text = exc.read().decode("utf-8", errors="replace") if exc.fp else ""
        return int(exc.code), body_text


class SeqPulseCIClient:
    def __init__(
        self,
        *,
        base_url: str | None = None,
        api_key: str | None = None,
        metrics_endpoint: str | None = None,
        env: str = "prod",
        timeout_seconds: float = 4.0,
        non_blocking: bool = True,
        transport: CiTransport | None = None,
    ) -> None:
        self.base_url = _normalize_base_url(base_url or os.getenv("SEQPULSE_BASE_URL"))
        self.api_key = (api_key or os.getenv("SEQPULSE_API_KEY") or "").strip()
        self.metrics_endpoint = (metrics_endpoint or os.getenv("SEQPULSE_METRICS_ENDPOINT") or "").strip()
        self.env = (env or "prod").strip() or "prod"
        self.timeout_seconds = float(timeout_seconds)
        self.non_blocking = bool(non_blocking)
        self.transport = transport or _default_transport

    def _error(
        self,
        *,
        action: str,
        error: str,
        http_status: int = 0,
        response_text: str = "",
        non_blocking: bool | None = None,
    ) -> dict:
        should_non_block = self.non_blocking if non_blocking is None else bool(non_blocking)
        if not should_non_block:
            raise RuntimeError(f"{action} failed: {error}")
        return {
            "ok": False,
            "skipped": True,
            "action": action,
            "http_status": int(http_status),
            "error": str(error),
            "response_text": response_text,
        }

    def _request(
        self,
        *,
        path: str,
        payload: dict,
        action: str,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout_seconds: float | None = None,
        non_blocking: bool | None = None,
    ) -> dict:
        resolved_base_url = _normalize_base_url(base_url or self.base_url)
        resolved_api_key = (api_key or self.api_key).strip()
        resolved_timeout = float(timeout_seconds if timeout_seconds is not None else self.timeout_seconds)

        if not resolved_base_url or not resolved_api_key:
            return self._error(action=action, error="missing base_url/api_key", non_blocking=non_blocking)

        url = f"{resolved_base_url}{path}"
        body = json.dumps(payload)
        headers = {
            "X-API-Key": resolved_api_key,
            "Content-Type": "application/json",
        }

        try:
            http_status, response_text = self.transport(url, headers, body, resolved_timeout)
        except Exception as exc:
            return self._error(action=action, error=str(exc), non_blocking=non_blocking)

        http_status = int(http_status)
        if http_status <= 0:
            return self._error(
                action=action,
                error="unreachable",
                http_status=http_status,
                response_text=response_text,
                non_blocking=non_blocking,
            )

        if http_status >= 400:
            return self._error(
                action=action,
                error=f"http {http_status}",
                http_status=http_status,
                response_text=response_text,
                non_blocking=non_blocking,
            )

        return {
            "ok": True,
            "skipped": False,
            "action": action,
            "http_status": http_status,
            "data": _safe_json_parse(response_text),
            "response_text": response_text,
        }

    def trigger(
        self,
        *,
        env: str | None = None,
        idempotency_key: str | None = None,
        branch: str | None = None,
        metrics_endpoint: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout_seconds: float | None = None,
        non_blocking: bool | None = None,
    ) -> dict:
        resolved_metrics_endpoint = (metrics_endpoint or self.metrics_endpoint).strip()
        if not resolved_metrics_endpoint:
            return self._error(action="trigger", error="missing metrics_endpoint", non_blocking=non_blocking)

        payload = {
            "env": (env or self.env or "prod").strip() or "prod",
            "metrics_endpoint": resolved_metrics_endpoint,
            "idempotency_key": (idempotency_key or build_ci_idempotency_key()).strip(),
            "branch": (branch or infer_branch_name()).strip() or "unknown",
        }

        result = self._request(
            path="/deployments/trigger",
            payload=payload,
            action="trigger",
            base_url=base_url,
            api_key=api_key,
            timeout_seconds=timeout_seconds,
            non_blocking=non_blocking,
        )
        if not result.get("ok"):
            return result

        deployment_id = str(result.get("data", {}).get("deployment_id") or "")
        if not deployment_id:
            return self._error(
                action="trigger",
                error="missing deployment_id in response",
                http_status=int(result.get("http_status", 0)),
                response_text=str(result.get("response_text", "")),
                non_blocking=non_blocking,
            )

        return {
            "ok": True,
            "skipped": False,
            "action": "trigger",
            "http_status": int(result.get("http_status", 0)),
            "deployment_id": deployment_id,
            "status": str(result.get("data", {}).get("status") or "created"),
            "message": result.get("data", {}).get("message"),
            "data": result.get("data", {}),
        }

    def finish(
        self,
        *,
        deployment_id: str,
        result: str | None = None,
        pipeline_status: str | None = None,
        job_status: str | None = None,
        metrics_endpoint: str | None = None,
        base_url: str | None = None,
        api_key: str | None = None,
        timeout_seconds: float | None = None,
        non_blocking: bool | None = None,
    ) -> dict:
        resolved_deployment_id = (deployment_id or "").strip()
        if not resolved_deployment_id:
            return self._error(action="finish", error="missing deployment_id", non_blocking=non_blocking)

        resolved_result = (result or infer_result_from_pipeline_status(pipeline_status or job_status or "success")).strip()
        resolved_metrics_endpoint = (metrics_endpoint or self.metrics_endpoint).strip()

        payload = {
            "deployment_id": resolved_deployment_id,
            "result": resolved_result,
        }
        if resolved_metrics_endpoint:
            payload["metrics_endpoint"] = resolved_metrics_endpoint

        request_result = self._request(
            path="/deployments/finish",
            payload=payload,
            action="finish",
            base_url=base_url,
            api_key=api_key,
            timeout_seconds=timeout_seconds,
            non_blocking=non_blocking,
        )
        if not request_result.get("ok"):
            return request_result

        return {
            "ok": True,
            "skipped": False,
            "action": "finish",
            "http_status": int(request_result.get("http_status", 0)),
            "status": str(request_result.get("data", {}).get("status") or "accepted"),
            "message": request_result.get("data", {}).get("message"),
            "data": request_result.get("data", {}),
        }


def create_ci_client(**kwargs) -> SeqPulseCIClient:
    return SeqPulseCIClient(**kwargs)


__all__ = [
    "SeqPulseCIClient",
    "create_ci_client",
    "build_ci_idempotency_key",
    "infer_result_from_pipeline_status",
]
