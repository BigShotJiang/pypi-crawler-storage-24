"""
Tests for the top-level preprocess() function.
This is the main thing users will call.
"""

import pytest
from indic_tts_preprocess import preprocess, SUPPORTED_LANGUAGES


class TestPreprocess:
    def test_hindi_routing(self):
        result = preprocess("1997", "hi")
        assert result == "उन्नीस सौ सत्तानवे"

    def test_marathi_routing(self):
        result = preprocess("1997", "mr")
        assert result == "एकोणीस शे सत्त्याण्णव"

    def test_english_routing(self):
        result = preprocess("1997", "en")
        assert result == "nineteen ninety seven"

    def test_unknown_lang_returns_text_unchanged(self):
        # Should not crash, just return as-is
        result = preprocess("hello 123", "xx")
        assert result == "hello 123"

    def test_lang_is_case_insensitive(self):
        # "HI" and "Hi" and "hi" should all work
        assert preprocess("5", "HI") == preprocess("5", "hi")
        assert preprocess("5", "Hi") == preprocess("5", "hi")

    def test_raises_on_non_string_input(self):
        with pytest.raises(TypeError):
            preprocess(12345, "hi")

    def test_supported_languages_constant(self):
        assert "hi" in SUPPORTED_LANGUAGES
        assert "mr" in SUPPORTED_LANGUAGES
        assert "en" in SUPPORTED_LANGUAGES

    def test_empty_string(self):
        assert preprocess("", "hi") == ""
        assert preprocess("", "en") == ""
