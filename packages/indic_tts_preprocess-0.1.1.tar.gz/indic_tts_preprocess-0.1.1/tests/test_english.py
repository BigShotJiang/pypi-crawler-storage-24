"""
Tests for the English preprocessor.
"""

import pytest
from indic_tts_preprocess.languages.english import preprocess, num_to_words


class TestNumToWords:
    def test_zero(self):
        assert num_to_words(0) == "zero"

    def test_teens(self):
        assert num_to_words(15) == "fifteen"

    def test_two_digit(self):
        assert num_to_words(42) == "forty two"

    def test_1900s_year(self):
        assert num_to_words(1997) == "nineteen ninety seven"

    def test_1900s_oh_year(self):
        # 1905 should be "nineteen oh five"
        assert num_to_words(1905) == "nineteen oh five"

    def test_1900_exact(self):
        assert num_to_words(1900) == "nineteen hundred"

    def test_2000(self):
        assert num_to_words(2000) == "two thousand"

    def test_2000s(self):
        assert num_to_words(2024) == "two thousand twenty four"

    def test_negative(self):
        assert num_to_words(-10) == "minus ten"


class TestPreprocess:
    def test_written_date(self):
        result = preprocess("15 August 1747")
        assert result == "fifteen August seventeen forty seven"

    def test_written_date_case_insensitive(self):
        result = preprocess("15 august 1947")
        assert "fifteen" in result
        assert "nineteen forty seven" in result

    def test_numeric_date(self):
        result = preprocess("15/08/1947")
        assert "fifteen" in result
        assert "August" in result

    def test_standalone_year(self):
        result = preprocess("The year was 1947")
        assert "nineteen forty seven" in result

    def test_text_without_numbers_unchanged(self):
        text = "Hello world"
        assert preprocess(text) == text
