"""
Tests for the Hindi preprocessor.
Run with: python -m pytest tests/
"""

import pytest
from indic_tts_preprocess.languages.hindi import preprocess, num_to_words


class TestNumToWords:
    def test_zero(self):
        assert num_to_words(0) == "शून्य"

    def test_single_digit(self):
        assert num_to_words(5) == "पाँच"

    def test_two_digit(self):
        assert num_to_words(73) == "तिहत्तर"

    def test_hundred(self):
        assert num_to_words(100) == "एक सौ"

    def test_1900s_year(self):
        # The special case - should say "उन्नीस सौ" not "एक हज़ार नौ सौ"
        assert num_to_words(1997) == "उन्नीस सौ सत्तानवे"

    def test_1900_exact(self):
        assert num_to_words(1900) == "उन्नीस सौ"

    def test_2000s_year(self):
        assert num_to_words(2004) == "दो हज़ार चार"

    def test_negative(self):
        assert num_to_words(-5) == "माइनस पाँच"


class TestPreprocess:
    def test_named_date(self):
        result = preprocess("5 अगस्त 2004")
        assert result == "पाँच अगस्त दो हज़ार चार"

    def test_named_date_with_comma(self):
        result = preprocess("5 अगस्त, 2004")
        assert result == "पाँच अगस्त दो हज़ार चार"

    def test_numeric_date_slash(self):
        result = preprocess("05/08/2004")
        assert result == "पाँच अगस्त दो हज़ार चार"

    def test_numeric_date_dash(self):
        result = preprocess("05-08-2004")
        assert result == "पाँच अगस्त दो हज़ार चार"

    def test_standalone_number_in_sentence(self):
        result = preprocess("उसके पास 73 किताबें हैं")
        assert "तिहत्तर" in result

    def test_1900s_year_in_sentence(self):
        result = preprocess("उनका जन्म 1947 में हुआ")
        assert "उन्नीस सौ सैंतालीस" in result

    def test_text_without_numbers_unchanged(self):
        text = "यह एक साधारण वाक्य है"
        assert preprocess(text) == text
    
    def test_1800s_year_in_sentence(self):
        result = preprocess("उनका जन्म 1803 में हुआ")
        assert "अठारह सौ तीन" in result
    
    def test_1700s_year_in_sentence(self):
        result = preprocess("उनका जन्म 1709 में हुआ")
        assert "सत्रह सौ नौ" in result
