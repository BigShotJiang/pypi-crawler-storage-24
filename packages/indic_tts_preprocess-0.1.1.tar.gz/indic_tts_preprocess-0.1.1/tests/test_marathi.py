"""
Tests for the Marathi preprocessor.
"""

import pytest
from indic_tts_preprocess.languages.marathi import preprocess, num_to_words


class TestNumToWords:
    def test_zero(self):
        assert num_to_words(0) == "शून्य"

    def test_single_digit(self):
        assert num_to_words(5) == "पाच"

    def test_1900s_year(self):
        # Marathi uses "एकोणीस शे" for the 1900s
        assert num_to_words(1997) == "एकोणीस शे सत्त्याण्णव"

    def test_1900_exact(self):
        assert num_to_words(1900) == "एकोणीस शे"

    def test_negative(self):
        assert num_to_words(-3) == "वजा तीन"


class TestPreprocess:
    def test_named_date(self):
        result = preprocess("5 ऑगस्ट 2004")
        assert result == "पाच ऑगस्ट दोन हजार चार"

    def test_numeric_date(self):
        result = preprocess("05/08/2004")
        assert "ऑगस्ट" in result

    def test_standalone_number(self):
        result = preprocess("त्याच्याकडे 10 पुस्तके आहेत")
        assert "दहा" in result

    def test_text_without_numbers_unchanged(self):
        text = "हे एक साधे वाक्य आहे"
        assert preprocess(text) == text
    
    def test_1800s_year_in_sentence_marathi(self):
        result = preprocess("त्यांचा जन्म 1807 मध्ये झाला")
        assert "अठरा शे सात" in result

    def test_1700s_year_in_sentence_marathi(self):
        result = preprocess("त्यांचा जन्म 1702 मध्ये झाला")
        assert "सतरा शे दोन" in result
