"""
marathi.py

All the Marathi-specific stuff lives here.
Same structure as hindi.py but with Marathi words throughout.
"""

import re

# Every number from 0 to 99 written out in Marathi.
# Same idea as Hindi - index = the number. ONES[3] = "तीन".
ONES = [
    "", "एक", "दोन", "तीन", "चार", "पाच", "सहा", "सात", "आठ", "नऊ", "दहा",
    "अकरा", "बारा", "तेरा", "चौदा", "पंधरा", "सोळा", "सतरा", "अठरा", "एकोणीस", "वीस",
    "एकवीस", "बावीस", "तेवीस", "चोवीस", "पंचवीस", "सव्वीस", "सत्तावीस", "अठ्ठावीस", "एकोणतीस", "तीस",
    "एकतीस", "बत्तीस", "तेहेतीस", "चौतीस", "पस्तीस", "छत्तीस", "सदतीस", "अडतीस", "एकोणचाळीस", "चाळीस",
    "एकेचाळीस", "बेचाळीस", "त्रेचाळीस", "चव्वेचाळीस", "पंचेचाळीस", "सेहेचाळीस", "सत्तेचाळीस", "अठ्ठेचाळीस", "एकोणपन्नास", "पन्नास",
    "एक्याण्णव", "बावन्न", "त्रेपन्न", "चोपन्न", "पंचावन्न", "छप्पन्न", "सत्तावन्न", "अठ्ठावन्न", "एकोणसाठ", "साठ",
    "एकसष्ट", "बासष्ट", "त्रेसष्ट", "चौसष्ट", "पासष्ट", "सहासष्ट", "सदुसष्ट", "अडुसष्ट", "एकोणसत्तर", "सत्तर",
    "एकाहत्तर", "बहात्तर", "त्र्याहत्तर", "चौऱ्याहत्तर", "पंच्याहत्तर", "शहात्तर", "सत्याहत्तर", "अठ्ठ्याहत्तर", "एकोणऐंशी", "ऐंशी",
    "एक्याऐंशी", "ब्याऐंशी", "त्र्याऐंशी", "चौऱ्याऐंशी", "पंच्याऐंशी", "शहाऐंशी", "सत्याऐंशी", "अठ्ठ्याऐंशी", "नव्याऐंशी", "नव्वद",
    "एक्याण्णव", "बाण्णव", "त्र्याण्णव", "चौऱ्याण्णव", "पंच्याण्णव", "शहाण्णव", "सत्त्याण्णव", "अठ्ठ्याण्णव", "नव्याण्णव",
]

# Month number -> Marathi month name
MONTHS = {
    1: "जानेवारी", 2: "फेब्रुवारी", 3: "मार्च", 4: "एप्रिल",
    5: "मे", 6: "जून", 7: "जुलै", 8: "ऑगस्ट",
    9: "सप्टेंबर", 10: "ऑक्टोबर", 11: "नोव्हेंबर", 12: "डिसेंबर",
}

# Flip it so we can go from month name -> number
MONTH_TO_NUM = {v: k for k, v in MONTHS.items()}


def num_to_words(n: int) -> str:
    """
    Turn any whole number into how a Marathi speaker would say it out loud.

    Same 1900s special case as Hindi: "एकोणीस शे ..." instead of the long form.
    Marathi uses "शे" for hundred and "हजार" for thousand.
    """
    if n == 0:
        return "शून्य"
    if n < 0:
        return "वजा " + num_to_words(-n)

    # Years in the 1900s - say it the natural way
    if 1900 <= n <= 1999:
        remainder = n - 1900
        if remainder == 0:
            return "एकोणीस शे"
        return "एकोणीस शे " + ONES[remainder]

    # 1800s
    if 1800 <= n <= 1899:
        remainder = n - 1800
        if remainder == 0:
            return "अठरा शे"
        return "अठरा शे " + ONES[remainder]
    
    # 1700s
    if 1700 <= n <= 1799:
        remainder = n - 1700
        if remainder == 0:
            return "सतरा शे"
        return "सतरा शे " + ONES[remainder]

    parts = []
    if n >= 1000:
        parts.append(num_to_words(n // 1000) + " हजार")
        n %= 1000
    if n >= 100:
        parts.append(ONES[n // 100] + " शे")
        n %= 100
    if n > 0:
        parts.append(ONES[n])
    return " ".join(parts)


def preprocess(text: str) -> str:
    """
    Takes raw Marathi text and replaces all numbers/dates with spoken Marathi words.
    Same three patterns as Hindi - just uses Marathi words.
    """
    month_pat = "|".join(MONTH_TO_NUM.keys())

    # Handle "5 ऑगस्ट 2004" or "5 ऑगस्ट, 2004"
    def _named_date(m):
        day = int(m.group(1))
        month = MONTH_TO_NUM[m.group(2)]
        year = int(m.group(3))
        return f"{ONES[day]} {MONTHS[month]} {num_to_words(year)}"

    text = re.sub(
        rf"(\d{{1,2}})\s+({month_pat})[,\s]+(\d{{4}})",
        _named_date, text
    )

    # Handle "05/08/2004" or "05-08-2004"
    def _numeric_date(m):
        day, month, year = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= month <= 12 and 1 <= day <= 31:
            return f"{ONES[day]} {MONTHS[month]} {num_to_words(year)}"
        return m.group(0)

    text = re.sub(r"(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})", _numeric_date, text)

    # Anything else that's still a number
    text = re.sub(r"\d+", lambda m: num_to_words(int(m.group())), text)

    return text
