"""
hindi.py

All the Hindi-specific stuff lives here:
- Word lists for numbers 0-99
- Month name mappings
- The actual function that cleans up Hindi text for TTS
"""

import re

# Every number from 0 to 99 written out in Hindi.
# Index position = the number itself. So ONES[5] = "पाँच".
# Index 0 is blank because we never say "zero" in the middle of a date.
ONES = [
    "", "एक", "दो", "तीन", "चार", "पाँच", "छह", "सात", "आठ", "नौ", "दस",
    "ग्यारह", "बारह", "तेरह", "चौदह", "पंद्रह", "सोलह", "सत्रह", "अठारह", "उन्नीस", "बीस",
    "इक्कीस", "बाईस", "तेईस", "चौबीस", "पच्चीस", "छब्बीस", "सत्ताईस", "अट्ठाईस", "उनतीस", "तीस",
    "इकतीस", "बत्तीस", "तैंतीस", "चौंतीस", "पैंतीस", "छत्तीस", "सैंतीस", "अड़तीस", "उनतालीस", "चालीस",
    "इकतालीस", "बयालीस", "तैंतालीस", "चौंतालीस", "पैंतालीस", "छियालीस", "सैंतालीस", "अड़तालीस", "उनचास", "पचास",
    "इक्यावन", "बावन", "तिरपन", "चौवन", "पचपन", "छप्पन", "सत्तावन", "अट्ठावन", "उनसठ", "साठ",
    "इकसठ", "बासठ", "तिरसठ", "चौंसठ", "पैंसठ", "छियासठ", "सड़सठ", "अड़सठ", "उनहत्तर", "सत्तर",
    "इकहत्तर", "बहत्तर", "तिहत्तर", "चौहत्तर", "पचहत्तर", "छिहत्तर", "सतहत्तर", "अठहत्तर", "उनासी", "अस्सी",
    "इक्यासी", "बयासी", "तिरासी", "चौरासी", "पचासी", "छियासी", "सत्तासी", "अट्ठासी", "नवासी", "नब्बे",
    "इक्यानबे", "बानबे", "तिरानबे", "चौरानबे", "पचानबे", "छियानबे", "सत्तानवे", "अट्ठानवे", "निन्यानवे",
]

# Month number -> Hindi month name
MONTHS = {
    1: "जनवरी", 2: "फरवरी", 3: "मार्च", 4: "अप्रैल",
    5: "मई", 6: "जून", 7: "जुलाई", 8: "अगस्त",
    9: "सितंबर", 10: "अक्टूबर", 11: "नवंबर", 12: "दिसंबर",
}

# Flip it so we can go from month name -> number too
MONTH_TO_NUM = {v: k for k, v in MONTHS.items()}


def num_to_words(n: int) -> str:
    """
    Turn any whole number into how a Hindi speaker would say it out loud.

    The 1900s get special treatment: Hindi speakers say "उन्नीस सौ सत्तानवे"
    (nineteen hundred ninety-seven) not "एक हज़ार नौ सौ सत्तानवे".
    This matters a lot for birth years, historical dates, etc.
    """
    if n == 0:
        return "शून्य"
    if n < 0:
        return "माइनस " + num_to_words(-n)

    # Years in the 1900s - say it the natural way
    if 1900 <= n <= 1999:
        remainder = n - 1900
        if remainder == 0:
            return "उन्नीस सौ"
        return "उन्नीस सौ " + ONES[remainder]
    
    # 1800s
    if 1800 <= n <= 1899:
        remainder = n - 1800
        if remainder == 0:
            return "अठारह सौ"
        return "अठारह सौ " + ONES[remainder]

    # 1700s
    if 1700 <= n <= 1799:
        remainder = n - 1700
        if remainder == 0:
            return "सत्रह सौ"
        return "सत्रह सौ " + ONES[remainder]

    parts = []
    if n >= 1000:
        parts.append(num_to_words(n // 1000) + " हज़ार")
        n %= 1000
    if n >= 100:
        parts.append(ONES[n // 100] + " सौ")
        n %= 100
    if n > 0:
        parts.append(ONES[n])
    return " ".join(parts)


def preprocess(text: str) -> str:
    """
    Takes raw Hindi text and replaces all numbers/dates with spoken Hindi words.

    Three patterns it handles:
    1. "5 अगस्त 2004" -> day in Hindi words + month name + year in words
    2. "05/08/2004" or "05-08-2004" -> same thing but from numeric format
    3. Any leftover numbers like "73" -> "तिहत्तर"
    """
    # Build a pattern that matches any Hindi month name
    month_pat = "|".join(MONTH_TO_NUM.keys())

    # Handle "5 अगस्त 2004" or "5 अगस्त, 2004"
    def _named_date(m):
        day = int(m.group(1))
        month = MONTH_TO_NUM[m.group(2)]
        year = int(m.group(3))
        return f"{ONES[day]} {MONTHS[month]} {num_to_words(year)}"

    text = re.sub(
        rf"(\d{{1,2}})\s+({month_pat})[,\s]+(\d{{4}})",
        _named_date, text
    )

    # Handle "05/08/2004" or "05-08-2004"
    def _numeric_date(m):
        day, month, year = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= month <= 12 and 1 <= day <= 31:
            return f"{ONES[day]} {MONTHS[month]} {num_to_words(year)}"
        return m.group(0)  # not a valid date, leave it alone

    text = re.sub(r"(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})", _numeric_date, text)

    # Anything else that's still a number
    text = re.sub(r"\d+", lambda m: num_to_words(int(m.group())), text)

    return text
