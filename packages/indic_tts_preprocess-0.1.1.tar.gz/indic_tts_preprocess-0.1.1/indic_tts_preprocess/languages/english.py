"""
english.py

English number/date cleanup for TTS.
Handles years the way English speakers actually say them out loud.
"""

import re

# Numbers 1-19 don't follow any pattern, so just list them
ONES = [
    "", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten",
    "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen",
]

# Tens: twenty, thirty, etc.
TENS = ["", "", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"]

# Month number -> English month name
MONTHS = {
    1: "January", 2: "February", 3: "March", 4: "April",
    5: "May", 6: "June", 7: "July", 8: "August",
    9: "September", 10: "October", 11: "November", 12: "December",
}

# Regex string of all month names (used to match written dates like "5 August 2004")
MONTHS_RE = "|".join(MONTHS.values())


def _under_100(n: int) -> str:
    """Convert any number under 100 to English words."""
    if n < 20:
        return ONES[n]
    tens, ones = n // 10, n % 10
    if ones == 0:
        return TENS[tens]
    return TENS[tens] + " " + ONES[ones]


def num_to_words(n: int) -> str:
    """
    Turn any whole number into spoken English.

    Years have their own rules because people say them differently:
    - 1900-1999: "nineteen oh five", "nineteen ninety two"
    - 2000-2099: "two thousand", "two thousand twenty four"
    Everything else uses standard hundred/thousand structure.
    """
    if n == 0:
        return "zero"
    if n < 0:
        return "minus " + num_to_words(-n)

    # 1900s - 1600s: "nineteen ninety two" not "one thousand nine hundred ninety two"
    if 1900 <= n <= 1999:
        second = n - 1900
        if second == 0:
            return "nineteen hundred"
        if second < 10:
            return "nineteen oh " + ONES[second]  # "nineteen oh five"
        return "nineteen " + _under_100(second)
    
    if 1800 <= n <= 1899:
        second = n - 1800
        if second == 0:
            return "eighteen hundred"
        if second < 10:
            return "eighteen oh " + ONES[second]  # "eighteen oh five"
        return "eightteen " + _under_100(second)
    
    if 1700 <= n <= 1799:
        second = n - 1700
        if second == 0:
            return "seventeen hundred"
        if second < 10:
            return "seventeen oh " + ONES[second]  # "seventeen oh five"
        return "seventeen " + _under_100(second)

    # 2000s: "two thousand", "two thousand twenty four"
    if 2000 <= n <= 2099:
        second = n - 2000
        if second == 0:
            return "two thousand"
        return "two thousand " + _under_100(second)

    parts = []
    if n >= 1000:
        parts.append(num_to_words(n // 1000) + " thousand")
        n %= 1000
    if n >= 100:
        parts.append(ONES[n // 100] + " hundred")
        n %= 100
    if n > 0:
        parts.append(_under_100(n))
    return " ".join(parts)


def preprocess(text: str) -> str:
    """
    Takes raw English text and replaces all numbers/dates with spoken English words.
    """
    # Handle "5 August 2004" or "5 august 2004" (case-insensitive)
    def _written_date(m):
        day, month_name, year = int(m.group(1)), m.group(2), int(m.group(3))
        return f"{_under_100(day)} {month_name} {num_to_words(year)}"

    text = re.sub(
        rf"(\d{{1,2}})\s+({MONTHS_RE})\s+(\d{{4}})",
        _written_date, text, flags=re.IGNORECASE
    )

    # Handle "05/08/2004" or "05-08-2004"
    def _numeric_date(m):
        day, month, year = int(m.group(1)), int(m.group(2)), int(m.group(3))
        if 1 <= month <= 12 and 1 <= day <= 31:
            return f"{_under_100(day)} {MONTHS[month]} {num_to_words(year)}"
        return m.group(0)

    text = re.sub(r"(\d{1,2})[\/\-](\d{1,2})[\/\-](\d{4})", _numeric_date, text)

    # Anything else that's still a number
    text = re.sub(r"\d+", lambda m: num_to_words(int(m.group(0))), text)

    return text
