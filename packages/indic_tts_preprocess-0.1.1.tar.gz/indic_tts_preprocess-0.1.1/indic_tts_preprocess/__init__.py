"""
indic-tts-preprocess
--------------------
Converts numbers and dates in Indic text into spoken words,
so that open-source TTS models like ai4bharat/indic-parler-tts
stop hallucinating when they see raw digits.

Basic usage:

    from indic_tts_preprocess import preprocess

    clean = preprocess("उनका जन्म 5 अगस्त 1997 को हुआ", "hi")
    # -> "उनका जन्म पाँच अगस्त उन्नीस सौ सत्तानवे को हुआ"

Supported languages:
    "hi"  - Hindi
    "mr"  - Marathi
    "en"  - English
"""

from indic_tts_preprocess.core import preprocess, SUPPORTED_LANGUAGES

__version__ = "0.1.1"
__author__ = "Dhruv Dornal"
__all__ = ["preprocess", "SUPPORTED_LANGUAGES"]