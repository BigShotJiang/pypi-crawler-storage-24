"""
core.py

The main entry point. This is the only function most people will ever need to call.
It figures out which language to use and sends the text to the right preprocessor.
"""

from indic_tts_preprocess.languages import hindi, marathi, english

# All the language codes we support right now.
# If someone passes something not in this list, we just return their text unchanged.
SUPPORTED_LANGUAGES = {"hi", "mr", "en"}


def preprocess(text: str, lang: str) -> str:
    """
    Clean up text so Indic TTS models can read numbers and dates correctly.

    The models hallucinate badly when they see raw digits like "1997" or "73".
    This function converts them into the spoken form before the text hits the model.

    Parameters
    ----------
    text : str
        The raw input text with digits/dates in it.
    lang : str
        Language code. Use "hi" for Hindi, "mr" for Marathi, "en" for English.

    Returns
    -------
    str
        The same text but with all numbers replaced by spoken words.

    Examples
    --------
    >>> from indic_tts_preprocess import preprocess
    >>> preprocess("उनका जन्म 5 अगस्त 1997 को हुआ", "hi")
    'उनका जन्म पाँच अगस्त उन्नीस सौ सत्तानवे को हुआ'

    >>> preprocess("He was born on 15 August 1947", "en")
    'He was born on fifteen August nineteen forty seven'
    """
    if not isinstance(text, str):
        raise TypeError(f"text must be a string, got {type(text).__name__}")

    lang = lang.strip().lower()

    if lang == "hi":
        return hindi.preprocess(text)
    if lang == "mr":
        return marathi.preprocess(text)
    if lang == "en":
        return english.preprocess(text)

    # Unknown language - just return the text as-is so nothing breaks downstream
    return text
