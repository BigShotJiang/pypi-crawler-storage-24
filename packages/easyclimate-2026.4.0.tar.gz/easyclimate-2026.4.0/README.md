<img src="https://github.com/shenyulu/easyclimate/blob/main/docs/source/_static/easyclimate_logo_mini.png?raw=true" alt="easyclimate">

<h2 align="center">A line of code to analyze climate</h2>

<p align="center">
<a href="https://easyclimate.readthedocs.io/en/latest/"><strong>Documentation</strong> (latest)</a> •
<a href="https://easyclimate.readthedocs.io/en/main/"><strong>Documentation</strong> (main branch)</a> •
<a href="https://shenyulu.github.io/easyclimate/"><strong>Documentation</strong> (Dev)</a> •
<a href="https://github.com/shenyulu/easyclimate/blob/main/CONTRIBUTING.md"><strong>Contributing</strong></a>
</p>

![PyPI - Version](https://img.shields.io/pypi/v/easyclimate)
![PyPI - Python Version](https://img.shields.io/pypi/pyversions/easyclimate)
![PyPI - Downloads](https://img.shields.io/pypi/dm/easyclimate)
[![codecov](https://codecov.io/gh/shenyulu/easyclimate/graph/badge.svg?token=CBG3IO5A5A)](https://codecov.io/gh/shenyulu/easyclimate)
[![pre-commit.ci status](https://results.pre-commit.ci/badge/github/shenyulu/easyclimate/main.svg)](https://results.pre-commit.ci/latest/github/shenyulu/easyclimate/main)
[![Documentation Status](https://readthedocs.org/projects/easyclimate/badge/?version=latest)](https://easyclimate.readthedocs.io/en/latest/?badge=latest)
[![DOI](https://zenodo.org/badge/465206111.svg)](https://zenodo.org/doi/10.5281/zenodo.10279567)
[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/shenyulu/easyclimate/main?labpath=docs%2Fexample)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)
[![SWH](https://archive.softwareheritage.org/badge/swh:1:dir:53294fc5285255eae60d8cf5d50ec86f28bb970a/)](https://archive.softwareheritage.org/swh:1:dir:53294fc5285255eae60d8cf5d50ec86f28bb970a;origin=https://doi.org/10.5281/zenodo.10279567;visit=swh:1:snp:85515406366d3bdbb39344f4fd07373a49cd1f42;anchor=swh:1:rel:12cab9c3f8cd0bd24229e4d9a5c778fe9b10df63;path=/shenyulu-easyclimate-b0b85e0/)

<div align="center">
<center>English / <a href = "readme/README.zh_CN.md">简体中文</a> / <a href = "readme/README.ja_JP.md">日本語</a></center>
</div>

## 👋 Overview

**Easy Climate** is a Python package, aiming to use a line of code to analyze climate.

We support Python >= 3.10.

### ✨ Project goals

* Eliminate lengthy code for data and plot handling.
* Use numpy and xarray syntax for optimal computational speed.
* Dask for scalable parallel processing support extends climate data processing to TBs or PBs.
* Open-source software for increased application flexibility.

### 🚀 How to install?

If you use [pip](https://pypi.org/project/pip/), you can install `easyclimate` with:

```bash
pip install easyclimate
```

For more information about installation, please chech the documentation.

## 🤖 AI Assistant (Experimental)

[DeepWiki](https://deepwiki.com/shenyulu/easyclimate) is an intelligent **AI-powered** GitHub repository assistant developed by the Devin team. It allows users to ask questions directly about code repositories, leveraging natural language processing to provide detailed, documentation-level answers. DeepWiki supports a deep research mode for in-depth analysis of complex issues.

Try DeepWiki for this project:

🔗 https://deepwiki.com/shenyulu/easyclimate

## 💫 Getting involved

👩🏾‍💻 **Contributing to project development:**
Please read our
[Contributing Guide](https://github.com/shenyulu/easyclimate/blob/main/CONTRIBUTING.md)
to see how you can help and give feedback.

🧑🏾‍🤝‍🧑🏼 **Code of conduct:**
This project is released with a
[Code of Conduct](https://github.com/shenyulu/easyclimate/blob/main/CODE_OF_CONDUCT.md).
By participating in this project you agree to abide by its terms.

❤️ **Sponsor This Project**
We deeply appreciate the contributors who have improved our software through their valuable feedback and issue reports. As a community-driven project, we gratefully acknowledge our sponsors. You can find the list of sponsors [here❤️](https://easyclimate.readthedocs.io/en/latest/sponsor.html).

> **Imposter syndrome disclaimer:**
> We want your help. **No, really.** There may be a little voice inside your
> head that is telling you that you're not ready, that you aren't skilled
> enough to contribute. We assure you that the little voice in your head is
> wrong. Most importantly, **there are many valuable ways to contribute besides
> writing code**.

## 🤗 Contributors

Thanks to our many contributors!

[![Contributors](https://contrib.rocks/image?repo=shenyulu/easyclimate)](https://github.com/shenyulu/easyclimate/graphs/contributors)

## 🪪 License

This is free software: you can redistribute it and/or modify it under the terms
of the **BSD 3-clause License**. A copy of this license is provided in
[`LICENSE`](https://github.com/shenyulu/easyclimate/blob/main/LICENSE).

## 💎 Star History

[![Star History Chart](https://api.star-history.com/svg?repos=shenyulu/easyclimate&type=Date)](https://star-history.com/#shenyulu/easyclimate&Date)
