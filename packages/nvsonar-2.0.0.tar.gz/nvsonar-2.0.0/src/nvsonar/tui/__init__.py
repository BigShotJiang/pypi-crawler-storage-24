"""TUI components for NVSonar"""
