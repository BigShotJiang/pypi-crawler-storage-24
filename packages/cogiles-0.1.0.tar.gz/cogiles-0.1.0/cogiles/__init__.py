"""
COGILES - Colored Graph Input Line Entry System

A SMILES-inspired string notation for colored graphs.

Usage::

    import cogiles

    G = cogiles.parse("R-1RRRRR-1")      # COGILES string -> nx.Graph
    s = cogiles.encode(G)                 # nx.Graph -> COGILES string
    s = cogiles.encode(G, strict=True)    # raises on unknown colors

"""

from cogiles.parser import parse
from cogiles.encoder import encode
from cogiles.visualization import draw
from cogiles.errors import CogilesParseError, CogilesEncodeError
from cogiles.colors import COLORS
from cogiles.utils import get_version

__all__ = [
    "parse",
    "encode",
    "draw",
    "CogilesParseError",
    "CogilesEncodeError",
    "COLORS",
    "get_version",
]

__version__ = get_version()
