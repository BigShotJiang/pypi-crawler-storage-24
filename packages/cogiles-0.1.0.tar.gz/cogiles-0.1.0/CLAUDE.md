# Claude Code Instructions

## Package Management

- Use `uv pip install` for all package installations (not plain `pip install`).
