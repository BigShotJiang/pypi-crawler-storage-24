"""
BaseService —— 所有业务域 Mixin 的底层基类。

提供统一的 HTTP 通信方法（_post / _get / _check），所有 services/ 下的 Mixin
均继承此类，确保认证、URL 解析、错误处理逻辑一致。
"""

import requests

from ._config import config
from .dev_token import get_headers


class BaseService:
    """底层 HTTP 通信基类，不直接实例化，由各 Mixin 和 Client 继承。"""

    def _api(self, name: str) -> str:
        """根据 sdk.yaml endpoints 中的 key 返回完整 URL。"""
        endpoints: dict = config["endpoints"]
        try:
            path = endpoints[name]
        except KeyError:
            raise KeyError(
                f"[edgmo_sdk] sdk.yaml 中未找到接口 '{name}'，请检查 endpoints 配置"
            )
        return f"{config['base_url']}{path}"

    def _post(self, api_name: str, payload: dict, timeout: int = 30) -> dict:
        """
        发送 POST 请求，自动携带认证 headers。

        Args:
            api_name: sdk.yaml endpoints 中的 key
            payload:  JSON 请求体
            timeout:  超时秒数

        Returns:
            解析后的 JSON 响应字典

        Raises:
            RuntimeError: 服务端返回非 JSON 响应时
        """
        resp = requests.post(
            self._api(api_name),
            json=payload,
            headers=get_headers(),
            timeout=timeout,
        )
        try:
            return resp.json()
        except ValueError:
            raise RuntimeError(
                f"[edgmo_sdk] 接口 {api_name!r} 返回非 JSON 响应"
                f"（HTTP {resp.status_code}）：{resp.text[:300]}"
            )

    def _get(self, api_name: str, params: dict | None = None, timeout: int = 30) -> dict:
        """
        发送 GET 请求，自动携带认证 headers。

        Args:
            api_name: sdk.yaml endpoints 中的 key
            params:   URL 查询参数
            timeout:  超时秒数

        Returns:
            解析后的 JSON 响应字典
        """
        resp = requests.get(
            self._api(api_name),
            params=params,
            headers=get_headers(),
            timeout=timeout,
        )
        try:
            return resp.json()
        except ValueError:
            raise RuntimeError(
                f"[edgmo_sdk] 接口 {api_name!r} 返回非 JSON 响应"
                f"（HTTP {resp.status_code}）：{resp.text[:300]}"
            )

    def _check(self, result: dict, context: str = "") -> dict:
        """
        校验响应体中的 code 字段，非 0 时抛出 RuntimeError。

        Args:
            result:  _post / _get 的返回值
            context: 操作描述，用于错误信息

        Returns:
            原始 result（code == 0 时透传）

        Raises:
            RuntimeError: code != 0 时
        """
        code = result.get("code", -1)
        if code != 0:
            msg = result.get("message", "未知错误")
            raise RuntimeError(f"[edgmo_sdk] {context}失败（code={code}）：{msg}")
        return result
