"""
edgmo SDK 客户端
=================

Client 类通过多重继承将所有业务域 Mixin 组合在一起，每个 Mixin 对应
服务端一个功能域。新增接口只需：
  1. sdk.yaml  中加一行 endpoint 映射
  2. services/对应域.py 中加一个方法（不影响其他任何代码）
  3. 如需模块级便捷函数，在本文件底部补充即可

接口速览：

    数据库核心        list_databases / list_tables / select / stats
                      insert / update / delete
    销售数据          sales_item / shop_daily / shop_revenue_report
                      shop_revenue_category_sales / shop_revenue_target
    推广数据          promote_data / promote_filters / promote_area / sales_area
    商品数据          promote_item / hot_items / hot_items_filters
                      hot_items_category_summary / hot_items_trend
                      item_view_top / e3_sales / item_overview / item_image / market_rank
    人群画像          view_crowd / selfshop_crowd
    流量数据          traffic_source
    竞争分析          competition_dmp_flow / competition_featured
                      competition_crowd / competition_crowd_trend
    API 监控          monitor_overview / monitor_trend / monitor_endpoints
                      monitor_status_codes / monitor_logs
                      monitor_slow_requests / monitor_high_risk
    DeepSeek AI       ai_chat / ai_chat_stream / ai_init
                      ai_conversation_create / ai_conversation_list
                      ai_conversation_info / ai_conversation_history
                      ai_conversation_update / ai_conversation_delete
    日志              logs_query / logs_statistics / logs_charts
                      logs_export / logs_scan
    通知              notifications_unread_count / notifications_list
                      notifications_mark_read / notifications_mark_all_read

认证方式：通过 dev_token 模块自动处理 access_token 的获取与刷新。
"""

from ._base import BaseService
from .services import (
    DatabaseMixin,
    SalesMixin,
    PromoteMixin,
    ItemMixin,
    CrowdMixin,
    FlowMixin,
    CompetitionMixin,
    MonitorMixin,
    AIMixin,
    LogsMixin,
    NotifyMixin,
)


class Client(
    DatabaseMixin,
    SalesMixin,
    PromoteMixin,
    ItemMixin,
    CrowdMixin,
    FlowMixin,
    CompetitionMixin,
    MonitorMixin,
    AIMixin,
    LogsMixin,
    NotifyMixin,
    BaseService,
):
    """
    edgmo SDK 主客户端。

    通过多重继承组合所有业务域 Mixin，调用任意接口方法即可。

    Example:
        import edgmo_sdk

        client = edgmo_sdk.Client()

        # 数据库查询
        rows = client.select("my_db", "orders", limit=10)

        # 销售数据
        result = client.sales_item(start_date="2026-01-01", end_date="2026-03-31")

        # AI 对话
        conv = client.ai_conversation_create(title="数据分析")
        reply = client.ai_chat(conv["data"]["conversation_id"], "分析近三个月销售趋势")
        print(reply["data"]["content"])
    """


# ──────────────────────────────────────────────────────────────
# 模块级便捷函数（脚本场景快速调用，无需显式创建 Client 实例）
# ──────────────────────────────────────────────────────────────

_default_client: Client | None = None


def _client() -> Client:
    global _default_client
    if _default_client is None:
        _default_client = Client()
    return _default_client


# ── 数据库核心 ──────────────────────────────────────────────

def list_databases() -> list[dict]:
    """等同于 Client().list_databases()"""
    return _client().list_databases()


def list_tables(database: str) -> list[dict]:
    """等同于 Client().list_tables(database)"""
    return _client().list_tables(database)


def select(database: str, table: str, **kwargs) -> dict:
    """等同于 Client().select(database, table, ...)"""
    return _client().select(database, table, **kwargs)


def stats(database: str, table: str, **kwargs) -> dict:
    """等同于 Client().stats(database, table, ...)"""
    return _client().stats(database, table, **kwargs)


def insert(
    database: str,
    table: str,
    row: dict | None = None,
    rows: list[dict] | None = None,
    **kwargs,
) -> dict:
    """等同于 Client().insert(database, table, row, rows, ...)"""
    return _client().insert(database, table, row, rows, **kwargs)


def update(database: str, table: str, values: dict, where: dict, **kwargs) -> dict:
    """等同于 Client().update(database, table, values, where, ...)"""
    return _client().update(database, table, values, where, **kwargs)


def delete(database: str, table: str, where: dict, **kwargs) -> dict:
    """等同于 Client().delete(database, table, where, ...)"""
    return _client().delete(database, table, where, **kwargs)


# ── 销售数据 ────────────────────────────────────────────────

def sales_item(**kwargs) -> dict:
    """等同于 Client().sales_item(...)"""
    return _client().sales_item(**kwargs)


def shop_daily(**kwargs) -> dict:
    """等同于 Client().shop_daily(...)"""
    return _client().shop_daily(**kwargs)


# ── 推广数据 ────────────────────────────────────────────────

def promote_data(**kwargs) -> dict:
    """等同于 Client().promote_data(...)"""
    return _client().promote_data(**kwargs)


def promote_filters(**kwargs) -> dict:
    """等同于 Client().promote_filters(...)"""
    return _client().promote_filters(**kwargs)


def sales_area(**kwargs) -> dict:
    """等同于 Client().sales_area(...)"""
    return _client().sales_area(**kwargs)


# ── AI 对话 ─────────────────────────────────────────────────

def ai_chat(conversation_id: str, message: str, **kwargs) -> dict:
    """等同于 Client().ai_chat(conversation_id, message, ...)"""
    return _client().ai_chat(conversation_id, message, **kwargs)


def ai_conversation_create(title: str = "新对话", **kwargs) -> dict:
    """等同于 Client().ai_conversation_create(...)"""
    return _client().ai_conversation_create(title, **kwargs)
