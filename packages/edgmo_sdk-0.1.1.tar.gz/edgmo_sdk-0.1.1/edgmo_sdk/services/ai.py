"""
AIMixin —— DeepSeek AI 对话相关接口。

封装接口：
    ai_chat / ai_init / ai_conversation_create / ai_conversation_list
    ai_conversation_info / ai_conversation_history
    ai_conversation_update / ai_conversation_delete

注：ai_chat_stream（流式）需要逐块读取响应，单独通过 ai_chat_stream() 方法处理。
"""

from typing import Generator

import requests

from .._base import BaseService
from .._config import config
from ..dev_token import get_headers


class AIMixin(BaseService):
    """DeepSeek AI：对话、历史管理、会话操作。"""

    # ──────────────────────────────────────────────
    # 对话
    # ──────────────────────────────────────────────

    def ai_chat(
        self,
        conversation_id: str,
        message: str,
        *,
        regenerate_message_id: int | None = None,
        model: str | None = None,
        temperature: float = 1.0,
        max_tokens: int = 4096,
        system_prompt: str | None = None,
        enable_context: bool | None = None,
        enable_thinking: bool = True,
        enable_web_search: bool = False,
        enable_tools: bool = False,
        timeout: int = 120,
    ) -> dict:
        """
        DeepSeek AI 对话接口（非流式），对话记录自动存储到数据库。

        Args:
            conversation_id (str):        对话 ID（必填，须提前通过 ai_conversation_create() 创建）
            message (str):                用户消息内容（与 regenerate_message_id 二选一）
            regenerate_message_id (int):  要重新生成的助手消息 ID；
                                          传入时忽略 message，对该条消息重新生成回复
            model (str):                  模型名称，如 "deepseek-chat" / "deepseek-reasoner"
            temperature (float):          采样温度，范围 0~2，默认 1.0；值越大回复越随机
            max_tokens (int):             最大输出 token 数，默认 4096
            system_prompt (str):          系统提示词，覆盖对话的默认设置
            enable_context (bool):        是否携带历史上下文，None 则使用对话默认设置
            enable_thinking (bool):       是否启用思考模式（Chain-of-Thought），默认 True
            enable_web_search (bool):     是否启用联网搜索，默认 False
            enable_tools (bool):          是否启用工具调用，默认 False
            timeout (int):                请求超时秒数（默认 120，AI 响应较慢）

        Returns:
            dict，data 字段包含：
                - content (str)              AI 回复正文
                - reasoning (str)            思考过程（enable_thinking=True 时返回）
                - tool_calls (list)          工具调用历史
                - user_message_id (int)      用户消息 ID
                - assistant_message_id (int) 助手消息 ID
                - usage (dict)               token 使用量（prompt/completion/total）

        Example:
            conv = client.ai_conversation_create(title="测试对话")
            conv_id = conv["data"]["conversation_id"]

            reply = client.ai_chat(
                conversation_id=conv_id,
                message="帮我分析一下最近三个月的销售趋势",
            )
            print(reply["data"]["content"])
        """
        if not conversation_id:
            raise ValueError("conversation_id 不能为空")
        if not regenerate_message_id and not message:
            raise ValueError("message 和 regenerate_message_id 至少传一个")

        payload: dict = {
            "conversation_id": conversation_id,
            "message": message,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "enable_thinking": enable_thinking,
            "enable_web_search": enable_web_search,
            "enable_tools": enable_tools,
        }
        if regenerate_message_id is not None:
            payload["regenerate_message_id"] = regenerate_message_id
        if model is not None:
            payload["model"] = model
        if system_prompt is not None:
            payload["system_prompt"] = system_prompt
        if enable_context is not None:
            payload["enable_context"] = enable_context

        return self._check(
            self._post("ai_chat", payload, timeout=timeout),
            "AI 对话",
        )

    def ai_chat_stream(
        self,
        conversation_id: str,
        message: str,
        *,
        model: str | None = None,
        temperature: float = 1.0,
        max_tokens: int = 4096,
        system_prompt: str | None = None,
        enable_context: bool | None = None,
        enable_thinking: bool = True,
        enable_web_search: bool = False,
        enable_tools: bool = False,
        timeout: int = 180,
    ) -> Generator[str, None, None]:
        """
        DeepSeek AI 流式对话接口，以生成器形式逐块 yield 原始 SSE 数据行。

        调用方负责解析 SSE 格式（"data: {...}" 行）。

        Args:
            conversation_id (str):    对话 ID（必填）
            message (str):            用户消息内容（必填）
            model (str):              模型名称
            temperature (float):      采样温度
            max_tokens (int):         最大 token 数
            system_prompt (str):      系统提示词
            enable_context (bool):    是否携带历史上下文
            enable_thinking (bool):   是否启用思考模式
            enable_web_search (bool): 是否启用联网搜索
            enable_tools (bool):      是否启用工具调用
            timeout (int):            连接超时秒数（默认 180）

        Yields:
            str: SSE 原始行（以 "data: " 开头），调用方需自行解析 JSON

        Example:
            for line in client.ai_chat_stream(conv_id, "分析销售数据"):
                if line.startswith("data:"):
                    chunk = json.loads(line[5:].strip())
                    print(chunk.get("content", ""), end="", flush=True)
        """
        if not conversation_id or not message:
            raise ValueError("conversation_id 和 message 不能为空")

        payload: dict = {
            "conversation_id": conversation_id,
            "message": message,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "enable_thinking": enable_thinking,
            "enable_web_search": enable_web_search,
            "enable_tools": enable_tools,
        }
        if model is not None:
            payload["model"] = model
        if system_prompt is not None:
            payload["system_prompt"] = system_prompt
        if enable_context is not None:
            payload["enable_context"] = enable_context

        url = f"{config['base_url']}{config['endpoints']['ai_chat_stream']}"
        with requests.post(
            url,
            json=payload,
            headers=get_headers(),
            stream=True,
            timeout=timeout,
        ) as resp:
            for line in resp.iter_lines(decode_unicode=True):
                if line:
                    yield line

    # ──────────────────────────────────────────────
    # 初始化 & 会话管理
    # ──────────────────────────────────────────────

    def ai_init(self, timeout: int = 15) -> dict:
        """
        获取 AI 模块初始化信息（可用模型列表、默认配置等）。

        Returns:
            dict，data 字段包含模型列表及默认配置
        """
        return self._check(
            self._get("ai_init", timeout=timeout),
            "获取 AI 初始化信息",
        )

    def ai_conversation_create(
        self,
        title: str = "新对话",
        *,
        system_prompt: str | None = None,
        model: str | None = None,
        timeout: int = 15,
        **kwargs,
    ) -> dict:
        """
        创建新的 AI 对话会话。

        Args:
            title (str):         对话标题（默认 "新对话"）
            system_prompt (str): 系统提示词
            model (str):         默认模型名称
            timeout (int):       请求超时秒数
            **kwargs:            其他透传给服务端的参数

        Returns:
            dict，data 字段包含 conversation_id 及会话配置

        Example:
            result = client.ai_conversation_create(title="销售分析")
            conv_id = result["data"]["conversation_id"]
        """
        payload: dict = {"title": title, **kwargs}
        if system_prompt is not None:
            payload["system_prompt"] = system_prompt
        if model is not None:
            payload["model"] = model
        return self._check(
            self._post("ai_conversation_create", payload, timeout=timeout),
            "创建 AI 对话",
        )

    def ai_conversation_list(self, timeout: int = 15) -> dict:
        """
        获取当前用户的所有 AI 对话会话列表。

        Returns:
            dict，data 字段包含会话列表（id、title、created_at 等）
        """
        return self._check(
            self._get("ai_conversation_list", timeout=timeout),
            "获取对话列表",
        )

    def ai_conversation_info(self, conversation_id: str, timeout: int = 15) -> dict:
        """
        获取指定 AI 对话会话的详情。

        Args:
            conversation_id (str): 对话 ID（必填）
            timeout (int):         请求超时秒数

        Returns:
            dict，data 字段包含会话配置及统计信息
        """
        return self._check(
            self._get("ai_conversation_info", params={"conversation_id": conversation_id}, timeout=timeout),
            "获取对话详情",
        )

    def ai_conversation_history(
        self,
        conversation_id: str,
        *,
        page: int = 1,
        page_size: int = 20,
        timeout: int = 15,
    ) -> dict:
        """
        获取指定 AI 对话的历史消息（分页）。

        Args:
            conversation_id (str): 对话 ID（必填）
            page (int):            页码（默认 1）
            page_size (int):       每页条数（默认 20）
            timeout (int):         请求超时秒数

        Returns:
            dict，data 字段包含消息列表（role/content/created_at 等）
        """
        return self._check(
            self._get(
                "ai_conversation_history",
                params={"conversation_id": conversation_id, "page": page, "page_size": page_size},
                timeout=timeout,
            ),
            "获取对话历史",
        )

    def ai_conversation_update(
        self,
        conversation_id: str,
        *,
        title: str | None = None,
        system_prompt: str | None = None,
        timeout: int = 15,
        **kwargs,
    ) -> dict:
        """
        更新指定 AI 对话会话的配置（标题、系统提示词等）。

        Args:
            conversation_id (str): 对话 ID（必填）
            title (str):           新标题
            system_prompt (str):   新系统提示词
            timeout (int):         请求超时秒数
            **kwargs:              其他透传给服务端的参数

        Returns:
            dict，data 字段包含更新后的会话信息
        """
        payload: dict = {"conversation_id": conversation_id, **kwargs}
        if title is not None:
            payload["title"] = title
        if system_prompt is not None:
            payload["system_prompt"] = system_prompt
        return self._check(
            self._post("ai_conversation_update", payload, timeout=timeout),
            "更新对话配置",
        )

    def ai_conversation_delete(self, conversation_id: str, timeout: int = 15) -> dict:
        """
        删除指定 AI 对话会话及其全部历史消息。

        Args:
            conversation_id (str): 对话 ID（必填）
            timeout (int):         请求超时秒数

        Returns:
            dict，确认删除结果
        """
        if not conversation_id:
            raise ValueError("conversation_id 不能为空")
        return self._check(
            self._post("ai_conversation_delete", {"conversation_id": conversation_id}, timeout=timeout),
            "删除对话",
        )
