"""
CrowdMixin —— 人群画像相关接口。

封装接口：
    view_crowd / selfshop_crowd
"""

from .._base import BaseService


class CrowdMixin(BaseService):
    """人群画像：市场人群画像、本店人群画像。"""

    def view_crowd(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取市场人群画像数据。

        Args:
            start_date (str):  开始日期，格式 "YYYY-MM-DD"
            end_date (str):    结束日期，格式 "YYYY-MM-DD"
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含人群画像维度数据（年龄、性别、城市等级等）

        Example:
            result = client.view_crowd(
                start_date="2026-01-01",
                end_date="2026-03-31",
            )
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("view_crowd", payload, timeout=timeout),
            "获取人群画像数据",
        )

    def selfshop_crowd(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取本店人群画像数据。

        Args:
            start_date (str):  开始日期，格式 "YYYY-MM-DD"
            end_date (str):    结束日期，格式 "YYYY-MM-DD"
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含本店人群画像维度数据

        Example:
            result = client.selfshop_crowd(
                start_date="2026-01-01",
                end_date="2026-03-31",
                shops=["my_shop"],
            )
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("selfshop_crowd", payload, timeout=timeout),
            "获取本店人群画像数据",
        )
