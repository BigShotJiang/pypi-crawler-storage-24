"""
ItemMixin —— 商品数据相关接口。

封装接口：
    promote_item / hot_items / hot_items_filters / hot_items_category_summary
    hot_items_trend / item_view_top / e3_sales / item_overview
    item_image / market_rank
"""

from .._base import BaseService


class ItemMixin(BaseService):
    """商品数据：主推商品、热门商品、商品概览、商品图片、市场排行。"""

    def promote_item(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取主推商品推广数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含主推商品推广列表
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("promote_item", payload, timeout=timeout),
            "获取主推商品数据",
        )

    def hot_items(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取热门商品列表数据（市场热销商品）。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含热门商品列表
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("hot_items", payload, timeout=timeout),
            "获取热门商品数据",
        )

    def hot_items_filters(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取热门商品筛选器选项（分类、品牌等）。

        Args:
            start_date (str): 开始日期
            end_date (str):   结束日期
            timeout (int):    请求超时秒数
            **kwargs:         其他透传给服务端的参数

        Returns:
            dict，data 字段包含可用筛选条件列表
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        return self._check(
            self._post("hot_items_filters", payload, timeout=timeout),
            "获取热门商品筛选器",
        )

    def hot_items_category_summary(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取热门商品分类汇总数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含各分类的汇总销售数据
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("hot_items_category_summary", payload, timeout=timeout),
            "获取热门商品分类汇总",
        )

    def hot_items_trend(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取热门商品趋势数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含热门商品销量趋势
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("hot_items_trend", payload, timeout=timeout),
            "获取热门商品趋势",
        )

    def item_view_top(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取商品浏览量 Top 排行数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含浏览量 Top 商品列表
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("item_view_top", payload, timeout=timeout),
            "获取商品浏览量排行",
        )

    def e3_sales(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取 E3 商品销售数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含 E3 销售数据
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("e3_sales", payload, timeout=timeout),
            "获取 E3 销售数据",
        )

    def item_overview(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取商品概览数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含商品概览统计信息
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("item_overview", payload, timeout=timeout),
            "获取商品概览数据",
        )

    def item_image(
        self,
        item_id: str,
        *,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取商品图片数据。

        Args:
            item_id (str): 商品 ID（必填）
            timeout (int): 请求超时秒数
            **kwargs:      其他透传给服务端的参数

        Returns:
            dict，data 字段包含商品图片 URL 列表
        """
        if not item_id:
            raise ValueError("item_id 不能为空")
        payload: dict = {"itemId": item_id, **kwargs}
        return self._check(
            self._post("item_image", payload, timeout=timeout),
            "获取商品图片",
        )

    def market_rank(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取市场商品排行数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含市场排行榜数据
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("market_rank", payload, timeout=timeout),
            "获取市场排行数据",
        )
