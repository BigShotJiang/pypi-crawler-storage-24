"""
PromoteMixin —— 推广数据相关接口。

封装接口：
    promote_data / promote_filters / promote_area / sales_area
"""

from .._base import BaseService


class PromoteMixin(BaseService):
    """推广数据：聚合推广、筛选器、推广地域、销售地域。"""

    def promote_data(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        scenes: list[int] | None = None,
        dimensions: list[str] | None = None,
        include_yoy: bool = False,
        timeout: int = 60,
    ) -> dict:
        """
        获取多店推广聚合数据（用于图表展示）。

        支持自定义计算字段（ROI投产、点击率、加购率、点击转化率、点击成本、
        加购成本、成交成本）及同比对比。
        数据来源：聚合数据.多店推广场景_按日聚合。

        Args:
            start_date (str):       开始日期，格式 "YYYY-MM-DD"（默认最近7天）
            end_date (str):         结束日期，格式 "YYYY-MM-DD"（默认最近7天）
            shops (list[str]):      店铺列表
            scenes (list[int]):     营销场景 ID 列表
            dimensions (list[str]): 维度列表（默认 ['花费']，
                                    支持数据库字段和自定义计算字段）
            include_yoy (bool):     是否包含同比数据（默认 False）
            timeout (int):          请求超时秒数

        Returns:
            dict，data 字段包含按场景分组的推广趋势数据

        Example:
            result = client.promote_data(
                start_date="2026-01-01",
                end_date="2026-03-31",
                dimensions=["花费", "ROI投产"],
                include_yoy=True,
            )
        """
        payload: dict = {"includeYoy": include_yoy}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        if scenes is not None:
            payload["scenes"] = scenes
        if dimensions is not None:
            payload["dimensions"] = dimensions
        return self._check(
            self._post("promote_data", payload, timeout=timeout),
            "获取推广聚合数据",
        )

    def promote_filters(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        scenes: list[int] | None = None,
        timeout: int = 30,
    ) -> dict:
        """
        获取推广数据筛选器选项（支持级联查询）。

        返回店铺、营销场景和数据维度的可选列表，用于前置筛选条件加载。

        Args:
            start_date (str):    开始日期，格式 "YYYY-MM-DD"（默认最近7天）
            end_date (str):      结束日期，格式 "YYYY-MM-DD"（默认最近7天）
            shops (list[str]):   店铺列表（用于级联查询营销场景）
            scenes (list[int]):  场景 ID 列表（用于级联查询数据维度）
            timeout (int):       请求超时秒数

        Returns:
            dict，data 字段包含：
                - scenes (list)     营销场景列表 [{id, name}]
                - dimensions (list) 维度列表

        Example:
            filters = client.promote_filters(start_date="2026-01-01", end_date="2026-03-31")
            for scene in filters["data"]["scenes"]:
                print(scene["id"], scene["name"])
        """
        payload: dict = {}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        if scenes is not None:
            payload["scenes"] = scenes
        return self._check(
            self._post("promote_filters", payload, timeout=timeout),
            "获取推广筛选器",
        )

    def promote_area(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取推广地域分布数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含省份/城市级别的推广地域数据
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("promote_area", payload, timeout=timeout),
            "获取推广地域数据",
        )

    def sales_area(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        metric: str = "销售额",
        timeout: int = 60,
    ) -> dict:
        """
        获取销售地域分布数据（省份和城市级别）。

        Args:
            start_date (str):  开始日期，格式 "YYYY-MM-DD"
            end_date (str):    结束日期，格式 "YYYY-MM-DD"
            shops (list[str]): 店铺列表
            metric (str):      指标名称（默认 "销售额"）
            timeout (int):     请求超时秒数

        Returns:
            dict，data 字段包含省份和城市销售分布数据

        Example:
            result = client.sales_area(
                start_date="2026-01-01",
                end_date="2026-03-31",
                metric="销售额",
            )
        """
        if not start_date or not end_date:
            raise ValueError("start_date 和 end_date 不能为空")
        payload: dict = {
            "startDate": start_date,
            "endDate": end_date,
            "metric": metric,
        }
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("sales_area", payload, timeout=timeout),
            "获取销售地域数据",
        )
