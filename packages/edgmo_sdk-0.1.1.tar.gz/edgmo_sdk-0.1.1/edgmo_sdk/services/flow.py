"""
FlowMixin —— 流量数据相关接口。

封装接口：
    traffic_source
"""

from .._base import BaseService


class FlowMixin(BaseService):
    """流量数据：流量来源结构分析。"""

    def traffic_source(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取流量来源结构数据（V3）。

        返回各流量渠道（直通车、免费流量、活动等）的访客数、
        支付转化率等核心指标的渠道占比分析。

        Args:
            start_date (str):  开始日期，格式 "YYYY-MM-DD"
            end_date (str):    结束日期，格式 "YYYY-MM-DD"
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含各来源渠道的流量及转化数据

        Example:
            result = client.traffic_source(
                start_date="2026-01-01",
                end_date="2026-03-31",
                shops=["shop_a"],
            )
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("traffic_source", payload, timeout=timeout),
            "获取流量来源数据",
        )
