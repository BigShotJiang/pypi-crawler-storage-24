"""
MonitorMixin —— API 监控相关接口。

封装接口：
    monitor_overview / monitor_trend / monitor_endpoints
    monitor_status_codes / monitor_logs / monitor_slow_requests / monitor_high_risk
"""

from .._base import BaseService


class MonitorMixin(BaseService):
    """API 监控：请求统计、趋势、端点分析、慢请求、高风险请求。"""

    def _monitor_payload(
        self,
        start_date: str | None,
        end_date: str | None,
        **kwargs,
    ) -> dict:
        """构建监控接口的通用请求体。"""
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        return payload

    def monitor_overview(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        endpoint: str | None = None,
        status_code: str | None = None,
        user_id: str | None = None,
        ip_address: str | None = None,
        min_duration: int | None = None,
        max_duration: int | None = None,
        timeout: int = 30,
    ) -> dict:
        """
        获取 API 监控概览统计（总请求数、平均响应时间、错误率等）。

        Args:
            start_date (str):    开始日期，格式 "YYYY-MM-DD"
            end_date (str):      结束日期，格式 "YYYY-MM-DD"
            endpoint (str):      筛选指定端点路径
            status_code (str):   筛选指定 HTTP 状态码
            user_id (str):       筛选指定用户 ID
            ip_address (str):    筛选指定 IP 地址
            min_duration (int):  最小响应时间（毫秒）
            max_duration (int):  最大响应时间（毫秒）
            timeout (int):       请求超时秒数

        Returns:
            dict，data 字段包含：总请求数、成功率、平均响应时间、错误分布等

        Example:
            result = client.monitor_overview(
                start_date="2026-03-01",
                end_date="2026-03-27",
            )
        """
        payload = self._monitor_payload(start_date, end_date)
        if endpoint is not None:
            payload["endpoint"] = endpoint
        if status_code is not None:
            payload["statusCode"] = status_code
        if user_id is not None:
            payload["userId"] = user_id
        if ip_address is not None:
            payload["ipAddress"] = ip_address
        if min_duration is not None:
            payload["minDuration"] = min_duration
        if max_duration is not None:
            payload["maxDuration"] = max_duration
        return self._check(
            self._post("monitor_overview", payload, timeout=timeout),
            "获取监控概览",
        )

    def monitor_trend(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取 API 请求量趋势数据（时序图）。

        Args:
            start_date (str): 开始日期
            end_date (str):   结束日期
            timeout (int):    请求超时秒数
            **kwargs:         其他透传给服务端的参数

        Returns:
            dict，data 字段包含按时间分组的请求量趋势
        """
        return self._check(
            self._post("monitor_trend", self._monitor_payload(start_date, end_date, **kwargs), timeout=timeout),
            "获取请求趋势",
        )

    def monitor_endpoints(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取各端点的请求统计排行（调用次数、响应时间等）。

        Args:
            start_date (str): 开始日期
            end_date (str):   结束日期
            timeout (int):    请求超时秒数
            **kwargs:         其他透传给服务端的参数

        Returns:
            dict，data 字段包含端点级别的请求统计列表
        """
        return self._check(
            self._post("monitor_endpoints", self._monitor_payload(start_date, end_date, **kwargs), timeout=timeout),
            "获取端点统计",
        )

    def monitor_status_codes(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取 HTTP 状态码分布统计。

        Args:
            start_date (str): 开始日期
            end_date (str):   结束日期
            timeout (int):    请求超时秒数
            **kwargs:         其他透传给服务端的参数

        Returns:
            dict，data 字段包含各状态码的计数分布
        """
        return self._check(
            self._post("monitor_status_codes", self._monitor_payload(start_date, end_date, **kwargs), timeout=timeout),
            "获取状态码分布",
        )

    def monitor_logs(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        page: int = 1,
        page_size: int = 20,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取 API 请求日志明细（分页）。

        Args:
            start_date (str): 开始日期
            end_date (str):   结束日期
            page (int):       页码（默认 1）
            page_size (int):  每页条数（默认 20）
            timeout (int):    请求超时秒数
            **kwargs:         其他透传给服务端的参数

        Returns:
            dict，data 字段包含分页日志记录
        """
        payload = self._monitor_payload(start_date, end_date, page=page, pageSize=page_size, **kwargs)
        return self._check(
            self._post("monitor_logs", payload, timeout=timeout),
            "获取请求日志",
        )

    def monitor_slow_requests(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        threshold_ms: int = 1000,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取慢请求列表（响应时间超过阈值的请求）。

        Args:
            start_date (str):   开始日期
            end_date (str):     结束日期
            threshold_ms (int): 慢请求阈值（毫秒，默认 1000）
            timeout (int):      请求超时秒数
            **kwargs:           其他透传给服务端的参数

        Returns:
            dict，data 字段包含慢请求列表，按响应时间降序排列
        """
        payload = self._monitor_payload(start_date, end_date, thresholdMs=threshold_ms, **kwargs)
        return self._check(
            self._post("monitor_slow_requests", payload, timeout=timeout),
            "获取慢请求列表",
        )

    def monitor_high_risk(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取高风险请求列表（异常访问、疑似攻击等）。

        Args:
            start_date (str): 开始日期
            end_date (str):   结束日期
            timeout (int):    请求超时秒数
            **kwargs:         其他透传给服务端的参数

        Returns:
            dict，data 字段包含高风险请求记录及风险评分
        """
        return self._check(
            self._post("monitor_high_risk", self._monitor_payload(start_date, end_date, **kwargs), timeout=timeout),
            "获取高风险请求",
        )
