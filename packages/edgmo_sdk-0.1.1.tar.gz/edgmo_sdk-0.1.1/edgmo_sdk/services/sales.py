"""
SalesMixin —— 销售数据相关接口。

封装接口：
    sales_item / shop_daily / shop_revenue_report
    shop_revenue_category_sales / shop_revenue_target
"""

from .._base import BaseService


class SalesMixin(BaseService):
    """销售数据：商品销售、店铺日报、营收报表。"""

    def sales_item(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        item_id: str | None = None,
        mode: str = "overview",
        group_by: str = "day",
        enable_yoy: bool = False,
        enable_mom: bool = False,
        timeout: int = 60,
    ) -> dict:
        """
        获取商品销售数据（宝贝指标）。

        Args:
            start_date (str):    开始日期，格式 "YYYY-MM-DD"
            end_date (str):      结束日期，格式 "YYYY-MM-DD"
            shops (list[str]):   店铺列表
            item_id (str):       商品 ID（指定则返回单品详情）
            mode (str):          查询模式，"overview"（列表）或 "details"（单品详情）
            group_by (str):      分组方式，"day" / "week" / "month"
            enable_yoy (bool):   是否启用同比
            enable_mom (bool):   是否启用环比
            timeout (int):       请求超时秒数

        Returns:
            dict，data 字段包含商品销售数据列表及对比数据

        Example:
            result = client.sales_item(
                start_date="2026-01-01",
                end_date="2026-03-31",
                shops=["shop_a"],
                group_by="month",
                enable_yoy=True,
            )
        """
        payload: dict = {
            "startDate": start_date,
            "endDate": end_date,
            "mode": mode,
            "groupBy": group_by,
            "enableYoY": enable_yoy,
            "enableMoM": enable_mom,
        }
        if shops is not None:
            payload["shops"] = shops
        if item_id is not None:
            payload["itemId"] = item_id
        return self._check(
            self._post("sales_item", payload, timeout=timeout),
            "获取商品销售数据",
        )

    def shop_daily(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        platforms: list[str] | None = None,
        aggregation: str = "day",
        include_chart_data: bool = False,
        excluded_item_ids: list | None = None,
        page: int = 1,
        page_size: int = 20,
        sort_by: str = "date",
        sort_order: str = "desc",
        show_yoy: bool = False,
        timeout: int = 60,
    ) -> dict:
        """
        获取店铺日报聚合数据（多店聚合_日报）。

        Args:
            start_date (str):          开始日期，格式 "YYYY-MM-DD"（默认最近7天）
            end_date (str):            结束日期，格式 "YYYY-MM-DD"（默认最近7天）
            shops (list[str]):         店铺列表
            platforms (list[str]):     平台列表
            aggregation (str):         聚合方式，"day" / "week" / "month"（默认 "day"）
            include_chart_data (bool): 是否包含图表全量数据（默认 False）
            excluded_item_ids (list):  排除指定商品 ID 的数据统计
            page (int):                页码，从 1 开始（默认 1）
            page_size (int):           每页条数，最大 100000（默认 20）
            sort_by (str):             排序字段，可选：date/platform/shop/revenue/
                                       pageViews/visitors/payAmount/payCount/
                                       adCost/industryRank（默认 "date"）
            sort_order (str):          排序方向，"asc" / "desc"（默认 "desc"）
            show_yoy (bool):           是否显示同比数据（默认 False）
            timeout (int):             请求超时秒数

        Returns:
            dict，data 字段包含分页日报列表及汇总数据

        Example:
            result = client.shop_daily(
                start_date="2026-01-01",
                end_date="2026-01-31",
                aggregation="month",
                show_yoy=True,
            )
        """
        payload: dict = {
            "startDate": start_date,
            "endDate": end_date,
            "aggregation": aggregation,
            "includeChartData": include_chart_data,
            "page": page,
            "pageSize": page_size,
            "sortBy": sort_by,
            "sortOrder": sort_order,
            "showYoY": show_yoy,
        }
        if shops is not None:
            payload["shops"] = shops
        if platforms is not None:
            payload["platforms"] = platforms
        if excluded_item_ids is not None:
            payload["excludedItemIds"] = excluded_item_ids
        return self._check(
            self._post("shop_daily_agg", payload, timeout=timeout),
            "获取店铺日报数据",
        )

    def shop_revenue_report(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取店铺营收报表数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含营收报表数据
        """
        payload: dict = {"startDate": start_date, "endDate": end_date, **kwargs}
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("shop_revenue_report", payload, timeout=timeout),
            "获取营收报表",
        )

    def shop_revenue_category_sales(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取店铺分类销售数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含分类销售数据
        """
        payload: dict = {"startDate": start_date, "endDate": end_date, **kwargs}
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("shop_revenue_category_sales", payload, timeout=timeout),
            "获取分类销售数据",
        )

    def shop_revenue_target(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取店铺营收目标达成数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含目标达成情况
        """
        payload: dict = {"startDate": start_date, "endDate": end_date, **kwargs}
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("shop_revenue_target", payload, timeout=timeout),
            "获取营收目标数据",
        )
