"""
NotifyMixin —— 通知相关接口。

封装接口：
    notifications_unread_count / notifications_list
    notifications_mark_read / notifications_mark_all_read
"""

from .._base import BaseService


class NotifyMixin(BaseService):
    """系统通知：未读计数、列表查询、标记已读。"""

    def notifications_unread_count(self, timeout: int = 10) -> int:
        """
        获取当前用户的未读通知数量（轻量接口）。

        通常作为 WebSocket 连接后的降级兜底调用。

        Args:
            timeout (int): 请求超时秒数（默认 10）

        Returns:
            int，未读通知总条数

        Example:
            count = client.notifications_unread_count()
            print(f"未读通知：{count} 条")
        """
        result = self._check(
            self._get("notifications_unread_count", timeout=timeout),
            "获取未读通知数量",
        )
        return result.get("data", {}).get("count", 0)

    def notifications_list(
        self,
        *,
        page: int = 1,
        page_size: int = 20,
        is_read: int | None = None,
        type: str | None = None,
        timeout: int = 15,
    ) -> dict:
        """
        分页查询当前用户的通知列表（未读优先，创建时间倒序）。

        若用户尚无通知，首次调用时服务端会自动插入欢迎示例通知。

        Args:
            page (int):      页码，从 1 开始（默认 1）
            page_size (int): 每页条数，范围 1~100（默认 20）
            is_read (int):   已读过滤：0=只返回未读，1=只返回已读，None=全部
            type (str):      通知类型过滤，如 "attendance_alert"，None=全部
            timeout (int):   请求超时秒数

        Returns:
            dict，data 字段包含：
                - total (int)     符合条件的通知总条数
                - page (int)      当前页码
                - page_size (int) 每页条数
                - list (list)     通知对象数组，每条字段：
                    id (int)         通知 ID
                    type (str)       通知类型
                    level (str)      级别：info / warning / error
                    title (str)      通知标题
                    content (str)    通知正文
                    extra_data (obj) 附加详情
                    is_read (int)    0=未读 1=已读
                    read_at (str)    标记已读时间
                    created_at (str) 创建时间

        Example:
            result = client.notifications_list(is_read=0, page_size=50)
            for n in result["data"]["list"]:
                print(n["title"], n["created_at"])
        """
        payload: dict = {"page": page, "page_size": page_size}
        if is_read is not None:
            payload["is_read"] = is_read
        if type is not None:
            payload["type"] = type
        return self._check(
            self._post("notifications_list", payload, timeout=timeout),
            "获取通知列表",
        )

    def notifications_mark_read(
        self,
        ids: list[int],
        *,
        timeout: int = 10,
    ) -> int:
        """
        将当前用户指定的通知标记为已读。

        标记成功后服务端通过 Redis pub/sub 推送最新未读数到 WebSocket，
        铃铛角标自动更新。

        Args:
            ids (list[int]): 要标记为已读的通知 ID 列表（必填）
            timeout (int):   请求超时秒数

        Returns:
            int，实际更新的条数（已读条目不计入）

        Example:
            updated = client.notifications_mark_read([1, 2, 3])
            print(f"已标记 {updated} 条为已读")
        """
        if not ids:
            raise ValueError("ids 不能为空")
        result = self._check(
            self._post("notifications_mark_read", {"ids": ids}, timeout=timeout),
            "标记通知已读",
        )
        return result.get("data", {}).get("updated", 0)

    def notifications_mark_all_read(self, timeout: int = 10) -> int:
        """
        将当前用户所有未读通知全部标记为已读。

        Args:
            timeout (int): 请求超时秒数

        Returns:
            int，实际更新的条数

        Example:
            updated = client.notifications_mark_all_read()
            print(f"全部 {updated} 条已标记为已读")
        """
        result = self._check(
            self._post("notifications_mark_all_read", {}, timeout=timeout),
            "全部标记已读",
        )
        return result.get("data", {}).get("updated", 0)
