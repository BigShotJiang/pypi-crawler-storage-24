"""
CompetitionMixin —— 竞争分析相关接口。

封装接口：
    competition_dmp_flow / competition_featured
    competition_crowd / competition_crowd_trend
"""

from .._base import BaseService


class CompetitionMixin(BaseService):
    """竞争分析：流量结构、特色人群、竞争人群画像及趋势。"""

    def competition_dmp_flow(
        self,
        start_date: str,
        end_date: str,
        *,
        shops: list[str] | None = None,
        stat_method: str = "日",
        data_type: str = "channel",
        channel_category: str = "付免流量结构",
        use_smart_estimate: bool = True,
        timeout: int = 60,
    ) -> dict:
        """
        获取竞争态势流量结构数据（本店 vs 竞店渠道占比/经营指标对比）。

        数据来源：达摩盘3数据库（按年份和年月分表）。
        shops 为空时自动填充本店 + 前5个竞店。

        Args:
            start_date (str):          开始日期，格式 "YYYY-MM-DD"（必填）
            end_date (str):            结束日期，格式 "YYYY-MM-DD"（必填，范围不超过365天）
            shops (list[str]):         店铺 ID 列表（字符串格式）
            stat_method (str):         统计方式："日" / "周" / "月"（默认 "日"）
            data_type (str):           数据类型：
                                         "channel"  渠道结构（默认）
                                         "metrics"  经营指标
            channel_category (str):    渠道分类（data_type="channel" 时有效）：
                                         "付免流量结构"（默认）/ "无界投资结构"
            use_smart_estimate (bool): 是否使用智能推算（data_type="metrics" 时有效，
                                       默认 True；False 表示使用简单中值）
            timeout (int):             请求超时秒数

        Returns:
            dict，data 字段包含本店与竞店的流量渠道占比或经营指标对比数据

        Example:
            result = client.competition_dmp_flow(
                start_date="2026-01-01",
                end_date="2026-03-31",
                data_type="channel",
                channel_category="付免流量结构",
            )
        """
        if not start_date or not end_date:
            raise ValueError("start_date 和 end_date 不能为空")
        payload: dict = {
            "startDate": start_date,
            "endDate": end_date,
            "statMethod": stat_method,
            "dataType": data_type,
            "channelCategory": channel_category,
            "useSmartEstimate": use_smart_estimate,
        }
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("competition_dmp_flow", payload, timeout=timeout),
            "获取竞争态势流量数据",
        )

    def competition_featured(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取竞争特色人群数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含竞争特色人群分析数据
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("competition_featured", payload, timeout=timeout),
            "获取竞争特色人群数据",
        )

    def competition_crowd(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取竞争人群画像数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含竞争店铺人群画像对比数据
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("competition_crowd", payload, timeout=timeout),
            "获取竞争人群画像数据",
        )

    def competition_crowd_trend(
        self,
        *,
        start_date: str | None = None,
        end_date: str | None = None,
        shops: list[str] | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        获取竞争人群画像趋势数据。

        Args:
            start_date (str):  开始日期
            end_date (str):    结束日期
            shops (list[str]): 店铺列表
            timeout (int):     请求超时秒数
            **kwargs:          其他透传给服务端的参数

        Returns:
            dict，data 字段包含竞争人群画像随时间的变化趋势
        """
        payload: dict = {**kwargs}
        if start_date is not None:
            payload["startDate"] = start_date
        if end_date is not None:
            payload["endDate"] = end_date
        if shops is not None:
            payload["shops"] = shops
        return self._check(
            self._post("competition_crowd_trend", payload, timeout=timeout),
            "获取竞争人群趋势数据",
        )
