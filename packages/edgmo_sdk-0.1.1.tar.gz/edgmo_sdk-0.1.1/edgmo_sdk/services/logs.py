"""
LogsMixin —— 日志查询相关接口。

封装接口：
    logs_query / logs_statistics / logs_charts / logs_export / logs_scan
"""

from .._base import BaseService


class LogsMixin(BaseService):
    """系统日志：查询、统计、图表、导出、扫描分析。"""

    def logs_query(
        self,
        *,
        start_time: str | None = None,
        end_time: str | None = None,
        log_level: str | None = None,
        file: str | None = None,
        module: str | None = None,
        search_text: str | None = None,
        skip_cache: bool = False,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        查询系统日志（支持多条件筛选）。

        Args:
            start_time (str):   开始时间，格式 "YYYY-MM-DD HH:MM:SS"
            end_time (str):     结束时间
            log_level (str):    日志级别，如 "ERROR" / "WARNING" / "INFO"
            file (str):         日志文件名过滤
            module (str):       模块名过滤
            search_text (str):  关键字搜索
            skip_cache (bool):  是否跳过缓存（默认 False）
            timeout (int):      请求超时秒数
            **kwargs:           其他透传给服务端的参数

        Returns:
            dict，data 字段包含日志记录列表

        Example:
            result = client.logs_query(
                start_time="2026-03-01 00:00:00",
                end_time="2026-03-27 23:59:59",
                log_level="ERROR",
            )
        """
        payload: dict = {"skip_cache": skip_cache, **kwargs}
        if start_time is not None:
            payload["start_time"] = start_time
        if end_time is not None:
            payload["end_time"] = end_time
        if log_level is not None:
            payload["log_level"] = log_level
        if file is not None:
            payload["file"] = file
        if module is not None:
            payload["module"] = module
        if search_text is not None:
            payload["search_text"] = search_text
        return self._check(
            self._post("logs_query", payload, timeout=timeout),
            "查询日志",
        )

    def logs_statistics(
        self,
        *,
        start_time: str | None = None,
        end_time: str | None = None,
        log_level: str | None = None,
        file: str | None = None,
        module: str | None = None,
        search_text: str | None = None,
        types: list[str] | None = None,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取日志统计信息（各级别计数、趋势等）。

        Args:
            start_time (str):   开始时间
            end_time (str):     结束时间
            log_level (str):    日志级别过滤
            file (str):         日志文件名过滤
            module (str):       模块名过滤
            search_text (str):  关键字搜索
            types (list[str]):  日志类型列表
            timeout (int):      请求超时秒数
            **kwargs:           其他透传给服务端的参数

        Returns:
            dict，data 字段包含日志级别分布、模块分布等统计
        """
        payload: dict = {**kwargs}
        if start_time is not None:
            payload["start_time"] = start_time
        if end_time is not None:
            payload["end_time"] = end_time
        if log_level is not None:
            payload["log_level"] = log_level
        if file is not None:
            payload["file"] = file
        if module is not None:
            payload["module"] = module
        if search_text is not None:
            payload["search_text"] = search_text
        if types is not None:
            payload["types"] = types
        return self._check(
            self._post("logs_statistics", payload, timeout=timeout),
            "获取日志统计",
        )

    def logs_charts(
        self,
        *,
        start_time: str | None = None,
        end_time: str | None = None,
        timeout: int = 30,
        **kwargs,
    ) -> dict:
        """
        获取日志图表数据（全部类型）。

        Args:
            start_time (str): 开始时间
            end_time (str):   结束时间
            timeout (int):    请求超时秒数
            **kwargs:         其他透传给服务端的参数

        Returns:
            dict，data 字段包含各维度日志图表数据
        """
        payload: dict = {**kwargs}
        if start_time is not None:
            payload["start_time"] = start_time
        if end_time is not None:
            payload["end_time"] = end_time
        return self._check(
            self._post("logs_charts", payload, timeout=timeout),
            "获取日志图表数据",
        )

    def logs_export(
        self,
        *,
        start_time: str | None = None,
        end_time: str | None = None,
        log_level: str | None = None,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        导出日志数据。

        Args:
            start_time (str): 开始时间
            end_time (str):   结束时间
            log_level (str):  日志级别过滤
            timeout (int):    请求超时秒数（导出较慢，默认 60）
            **kwargs:         其他透传给服务端的参数

        Returns:
            dict，data 字段包含导出文件下载链接或文件内容
        """
        payload: dict = {**kwargs}
        if start_time is not None:
            payload["start_time"] = start_time
        if end_time is not None:
            payload["end_time"] = end_time
        if log_level is not None:
            payload["log_level"] = log_level
        return self._check(
            self._post("logs_export", payload, timeout=timeout),
            "导出日志",
        )

    def logs_scan(
        self,
        *,
        timeout: int = 60,
        **kwargs,
    ) -> dict:
        """
        触发日志扫描分析（识别异常模式、错误聚合等）。

        Args:
            timeout (int): 请求超时秒数（扫描耗时较长，默认 60）
            **kwargs:      其他透传给服务端的参数

        Returns:
            dict，data 字段包含扫描结果及异常汇总
        """
        return self._check(
            self._post("logs_scan", kwargs, timeout=timeout),
            "扫描日志",
        )
