"""services —— 各业务域 Mixin 包。

每个模块对应服务端一个业务域；Client 通过多重继承组合所有 Mixin。
新增接口时，只需：
  1. sdk.yaml  中加一行 endpoint 映射
  2. 对应 services/xxx.py  中加一个方法
  3. 若需暴露模块级便捷函数，在 __init__.py 中补充即可
"""

from .db import DatabaseMixin
from .sales import SalesMixin
from .promote import PromoteMixin
from .item import ItemMixin
from .crowd import CrowdMixin
from .flow import FlowMixin
from .competition import CompetitionMixin
from .monitor import MonitorMixin
from .ai import AIMixin
from .logs import LogsMixin
from .notify import NotifyMixin

__all__ = [
    "DatabaseMixin",
    "SalesMixin",
    "PromoteMixin",
    "ItemMixin",
    "CrowdMixin",
    "FlowMixin",
    "CompetitionMixin",
    "MonitorMixin",
    "AIMixin",
    "LogsMixin",
    "NotifyMixin",
]
