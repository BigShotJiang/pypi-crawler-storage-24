"""
DatabaseMixin —— 数据库核心 CRUD 操作。

封装接口：
    list_databases / list_tables / select / stats
    insert / update / delete
"""

from .._base import BaseService


class DatabaseMixin(BaseService):
    """数据库基础操作：查询、写入、统计。"""

    # ──────────────────────────────────────────────
    # 元数据
    # ──────────────────────────────────────────────

    def list_databases(self) -> list[dict]:
        """
        获取当前账号可访问的数据库列表。

        Returns:
            list[dict]，每项包含：
                - name (str)        数据库名称
                - description (str) 数据库描述
                - table_count (int) 表数量（可选）

        Example:
            dbs = client.list_databases()
            for db in dbs:
                print(db["name"])
        """
        result = self._check(self._post("list_database", {}), "获取数据库列表")
        data = result.get("data") or {}
        return data.get("databases") or data.get("list") or []

    def list_tables(self, database: str) -> list[dict]:
        """
        获取指定数据库下的所有数据表。

        Args:
            database (str): 数据库名称（必填）

        Returns:
            list[dict]，每项包含：
                - name (str)        表名
                - description (str) 表描述
                - rows (int)        估算行数
                - size (str)        存储大小

        Example:
            tables = client.list_tables("my_db")
            for t in tables:
                print(t["name"], t["rows"])
        """
        if not database:
            raise ValueError("database 不能为空")
        result = self._check(
            self._post("list_tables", {"database": database}),
            "获取数据表列表",
        )
        data = result.get("data") or {}
        return data.get("tables") or []

    def stats(self, database: str, table: str, timeout: int = 60) -> dict:
        """
        获取指定数据表的字段统计信息。

        Args:
            database (str): 数据库名称（必填）
            table (str):    数据表名称（必填）
            timeout (int):  请求超时秒数（默认 60）

        Returns:
            dict，data 字段包含：
                - database (str)    数据库名
                - table (str)       表名
                - row_count (int)   总行数
                - field_count (int) 字段数
                - size (str)        存储大小
                - fields (list)     每个字段的统计信息

        Example:
            info = client.stats("my_db", "orders")
            print(f"总行数: {info['data']['row_count']}")
        """
        if not database or not table:
            raise ValueError("database 和 table 均不能为空")
        return self._check(
            self._post("table_stats", {"database": database, "table": table}, timeout=timeout),
            "获取表统计信息",
        )

    # ──────────────────────────────────────────────
    # 查询
    # ──────────────────────────────────────────────

    def select(
        self,
        database: str,
        table: str,
        *,
        mode: str = "json",
        fields: list[str] | None = None,
        where: dict | None = None,
        order_by: str | None = None,
        order_dir: str = "asc",
        limit: int = 100,
        offset: int = 0,
        start_date: str | None = None,
        end_date: str | None = None,
        date_field: str | None = None,
        is_export: bool = False,
        include_microseconds: bool = False,
        custom_datetime_formats: dict | None = None,
        sql: str | None = None,
        params: list | None = None,
        timeout: int = 60,
    ) -> dict:
        """
        查询指定数据表的数据（只读）。

        Args:
            database (str)              数据库名称（必填）
            table (str)                 数据表名称（必填）
            mode (str)                  查询模式："json"（默认）或 "sql"
            fields (list[str])          返回字段列表，None 表示返回全部字段（json 模式）
            where (dict)                查询条件（json 模式），支持以下操作符：
                                          简单等值：{"field": "value"}
                                          操作符：{"field": {"$eq/$ne/$gt/$gte/$lt/$lte": val}}
                                          集合：{"field": {"$in": [...], "$nin": [...]}}
                                          模糊：{"field": {"$like": "%keyword%"}}
                                          区间：{"field": {"$between": [min, max]}}
                                          空值：{"field": {"$isnull": true/false}}
                                          逻辑：{"$and": [...], "$or": [...], "$not": {...}}
            order_by (str)              排序字段名（json 模式）
            order_dir (str)             排序方向："asc" 或 "desc"（默认 "asc"）
            limit (int)                 返回条数（默认 100，最大 5000；导出模式最大 100000）
            offset (int)                偏移量（默认 0）
            start_date (str)            开始日期，格式 "YYYY-MM-DD"
            end_date (str)              结束日期，格式 "YYYY-MM-DD"
            date_field (str)            日期字段名（不指定则自动检测）
            is_export (bool)            是否导出模式，limit 上限提升至 100000
            include_microseconds (bool) 日期时间是否包含微秒精度（默认 False）
            custom_datetime_formats (dict) 自定义日期时间格式，{"字段名": "strftime格式"}
            sql (str)                   原生 SQL 语句（sql 模式必填）
            params (list)               SQL 参数列表（防注入占位符对应值）
            timeout (int)               请求超时秒数（默认 60）

        Returns:
            dict，包含：
                - data.rows (list[dict]) 数据行列表
                - data.total (int)       总行数
                - data.fields (list)     字段信息

        Example（JSON 条件模式）:
            result = client.select(
                database="my_db",
                table="orders",
                fields=["order_id", "amount", "status"],
                where={"status": {"$in": ["paid", "shipped"]}},
                order_by="amount",
                order_dir="desc",
                limit=200,
                start_date="2026-01-01",
                end_date="2026-03-31",
            )
            for row in result["data"]["rows"]:
                print(row)

        Example（SQL 模式）:
            result = client.select(
                database="my_db",
                table="orders",
                mode="sql",
                sql="SELECT * FROM orders WHERE status = %s LIMIT 10",
                params=["paid"],
            )
        """
        if not database or not table:
            raise ValueError("database 和 table 均不能为空")
        if limit < 1:
            raise ValueError("limit 必须大于 0")

        payload: dict = {
            "mode": mode,
            "database": database,
            "table": table,
            "limit": limit,
            "offset": offset,
        }

        if mode == "json":
            if fields is not None:
                payload["fields"] = fields
            if where is not None:
                payload["where"] = where
            if order_by is not None:
                payload["orderBy"] = order_by
                payload["orderDir"] = order_dir
        elif mode == "sql":
            if not sql:
                raise ValueError("sql 模式下必须传入 sql 参数")
            payload["sql"] = sql
            if params is not None:
                payload["params"] = params
        else:
            raise ValueError(f"不支持的 mode：{mode!r}，请使用 'json' 或 'sql'")

        if start_date:
            payload["start_date"] = start_date
        if end_date:
            payload["end_date"] = end_date
        if date_field:
            payload["date_field"] = date_field
        if is_export:
            payload["isExport"] = True
        if include_microseconds:
            payload["includeMicroseconds"] = True
        if custom_datetime_formats:
            payload["customDatetimeFormats"] = custom_datetime_formats

        return self._check(
            self._post("table_select", payload, timeout=timeout),
            "查询表数据",
        )

    # ──────────────────────────────────────────────
    # 写入
    # ──────────────────────────────────────────────

    def insert(
        self,
        database: str,
        table: str,
        row: dict | None = None,
        rows: list[dict] | None = None,
        *,
        timeout: int = 30,
    ) -> dict:
        """
        插入一行或多行数据。

        Args:
            database (str):    数据库名称
            table (str):       数据表名称
            row (dict):        单行数据（与 rows 二选一）
            rows (list[dict]): 多行数据（与 row 二选一）
            timeout (int):     请求超时秒数

        Example:
            client.insert("my_db", "orders", row={"order_id": "123", "amount": 99.0})
        """
        if not row and not rows:
            raise ValueError("row 和 rows 至少传一个")
        payload: dict = {"database": database, "table": table}
        if row:
            payload["row"] = row
        if rows:
            payload["rows"] = rows
        return self._check(
            self._post("table_insert", payload, timeout=timeout),
            "插入数据",
        )

    def update(
        self,
        database: str,
        table: str,
        values: dict,
        where: dict,
        *,
        limit: int = 1,
        timeout: int = 30,
    ) -> dict:
        """
        更新符合条件的数据行。

        Args:
            database (str):  数据库名称
            table (str):     数据表名称
            values (dict):   要更新的字段和值
            where (dict):    筛选条件（同 select 的 where 语法）
            limit (int):     最多更新行数（默认 1，防误操作）
            timeout (int):   请求超时秒数

        Example:
            client.update(
                "my_db", "orders",
                values={"status": "cancelled"},
                where={"order_id": "123"},
            )
        """
        payload = {
            "database": database,
            "table": table,
            "values": values,
            "where": where,
            "limit": limit,
        }
        return self._check(
            self._post("table_update", payload, timeout=timeout),
            "更新数据",
        )

    def delete(
        self,
        database: str,
        table: str,
        where: dict,
        *,
        limit: int = 1,
        timeout: int = 30,
    ) -> dict:
        """
        删除符合条件的数据行。

        Args:
            database (str):  数据库名称
            table (str):     数据表名称
            where (dict):    筛选条件（同 select 的 where 语法）
            limit (int):     最多删除行数（默认 1，防误操作）
            timeout (int):   请求超时秒数

        Example:
            client.delete("my_db", "orders", where={"order_id": "123"})
        """
        payload = {
            "database": database,
            "table": table,
            "where": where,
            "limit": limit,
        }
        return self._check(
            self._post("table_delete", payload, timeout=timeout),
            "删除数据",
        )
