"""
edgmo-sdk —— 数据接口访问 SDK
"""

from .__version__ import __version__

from ._config import configure
from .client import (
    Client,
    # 数据库核心
    list_databases,
    list_tables,
    select,
    stats,
    insert,
    update,
    delete,
    # 销售数据
    sales_item,
    shop_daily,
    # 推广数据
    promote_data,
    promote_filters,
    sales_area,
    # AI 对话
    ai_chat,
    ai_conversation_create,
)
from .dev_token import get_token, get_headers, verify_token, logout

__all__ = [
    "__version__",
    # 配置
    "configure",
    # 客户端类
    "Client",
    # 数据库核心
    "list_databases",
    "list_tables",
    "select",
    "stats",
    "insert",
    "update",
    "delete",
    # 销售数据
    "sales_item",
    "shop_daily",
    # 推广数据
    "promote_data",
    "promote_filters",
    "sales_area",
    # AI 对话
    "ai_chat",
    "ai_conversation_create",
    # token 工具
    "get_token",
    "get_headers",
    "verify_token",
    "logout",
]
