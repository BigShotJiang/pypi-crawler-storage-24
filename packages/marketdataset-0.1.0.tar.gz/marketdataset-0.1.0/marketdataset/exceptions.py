class MarketDatasetError(Exception):
    """Base exception for all MarketDataset errors."""
    def __init__(self, message: str, status_code: int = 0):
        super().__init__(message)
        self.status_code = status_code


class AuthenticationError(MarketDatasetError):
    """Invalid or missing API key."""


class RateLimitError(MarketDatasetError):
    """Rate limit exceeded. Retry after the specified interval."""
    def __init__(self, message: str, retry_after: int = 60):
        super().__init__(message, status_code=429)
        self.retry_after = retry_after


class InsufficientCreditsError(MarketDatasetError):
    """Account has insufficient credits to complete the request."""
    def __init__(self, message: str, balance: float = 0.0):
        super().__init__(message, status_code=402)
        self.balance = balance


class InvalidParameterError(MarketDatasetError):
    """Invalid request parameter."""


class APIError(MarketDatasetError):
    """Generic API error."""
