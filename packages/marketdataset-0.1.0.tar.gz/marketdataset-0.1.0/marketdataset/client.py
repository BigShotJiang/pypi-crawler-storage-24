from __future__ import annotations
from typing import Optional
import requests
from .exceptions import (
    AuthenticationError, RateLimitError, InsufficientCreditsError,
    InvalidParameterError, APIError,
)
from .resources.forex import ForexResource
from .resources.crypto import CryptoResource
from .resources.macro import MacroResource
from .resources.news import NewsResource

DEFAULT_BASE_URL = "https://api.marketdataset.ai"


class Client:
    """
    MarketDataset API client.

    Usage:
        client = Client(api_key="sk_your_api_key")
        prices = client.forex.prices(pair="EURUSD", interval="hour", limit=100)
        snapshot = client.crypto.snapshot(symbol="BTC")
        news = client.news.list(category="crypto")
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = 30,
    ):
        if not api_key:
            raise AuthenticationError("API key is required. Get one at https://marketdataset.ai")
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._session = requests.Session()
        self._session.headers.update({"X-API-KEY": api_key})

        # Lazy resource init
        self._forex: Optional[ForexResource] = None
        self._crypto: Optional[CryptoResource] = None
        self._macro: Optional[MacroResource] = None
        self._news: Optional[NewsResource] = None

    @property
    def forex(self) -> ForexResource:
        if self._forex is None:
            self._forex = ForexResource(self)
        return self._forex

    @property
    def crypto(self) -> CryptoResource:
        if self._crypto is None:
            self._crypto = CryptoResource(self)
        return self._crypto

    @property
    def macro(self) -> MacroResource:
        if self._macro is None:
            self._macro = MacroResource(self)
        return self._macro

    @property
    def news(self) -> NewsResource:
        if self._news is None:
            self._news = NewsResource(self)
        return self._news

    def _get(self, path: str, params: Optional[dict] = None) -> dict:
        """Make a GET request and return parsed JSON."""
        url = f"{self.base_url}{path}"
        # Remove None values
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}
        resp = self._session.get(url, params=clean_params, timeout=self.timeout)
        return self._handle_response(resp)

    def _handle_response(self, resp: requests.Response) -> dict:
        try:
            data = resp.json()
        except Exception:
            resp.raise_for_status()
            raise APIError(f"Invalid JSON response: {resp.text[:200]}", resp.status_code)

        if resp.status_code == 200:
            return data

        error_msg = data.get("error", f"HTTP {resp.status_code}")
        code = data.get("code", resp.status_code)

        if code == 401:
            raise AuthenticationError(error_msg, 401)
        if code == 429:
            raise RateLimitError(error_msg, retry_after=data.get("retry_after", 60))
        if code == 402:
            raise InsufficientCreditsError(error_msg, balance=data.get("balance", 0.0))
        if code == 400:
            raise InvalidParameterError(error_msg, 400)
        raise APIError(error_msg, resp.status_code)
