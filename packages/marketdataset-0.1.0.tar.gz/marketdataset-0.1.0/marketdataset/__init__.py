"""
MarketDataset Python SDK
Forex & crypto market data for AI agents.

Usage:
    from marketdataset import Client

    client = Client(api_key="sk_your_api_key")
    prices = client.forex.prices(pair="EURUSD", interval="hour", limit=100)
"""

from .client import Client
from .exceptions import (
    MarketDatasetError,
    AuthenticationError,
    RateLimitError,
    InsufficientCreditsError,
    InvalidParameterError,
    APIError,
)

__version__ = "0.1.0"
__all__ = [
    "Client",
    "MarketDatasetError",
    "AuthenticationError",
    "RateLimitError",
    "InsufficientCreditsError",
    "InvalidParameterError",
    "APIError",
]
