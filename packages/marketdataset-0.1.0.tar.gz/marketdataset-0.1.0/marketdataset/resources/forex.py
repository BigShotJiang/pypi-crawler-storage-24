from __future__ import annotations
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..client import Client


class ForexResource:
    def __init__(self, client: "Client"):
        self._client = client

    def prices(
        self,
        pair: str,
        interval: str = "hour",
        interval_multiplier: int = 1,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 100,
        cursor: Optional[str] = None,
    ) -> dict:
        """
        Fetch historical OHLCV forex prices.

        Args:
            pair: Currency pair, e.g. "EURUSD", "XAUUSD"
            interval: Candle interval — "minute", "hour", "day", "week", "month"
            interval_multiplier: Multiplier, e.g. 4 for 4-hour candles
            start_date: ISO 8601 start date, e.g. "2024-01-01"
            end_date: ISO 8601 end date
            limit: Number of candles (default 100, max 5000)
            cursor: Pagination cursor from next_page_url

        Returns:
            dict with keys: forex_prices, next_page_url, meta
        """
        return self._client._get("/forex/prices", {
            "pair": pair,
            "interval": interval,
            "interval_multiplier": interval_multiplier,
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
            "cursor": cursor,
        })

    def snapshot(self, pair: Optional[str] = None) -> dict:
        """
        Get live forex prices (real-time, no DB cache).

        Args:
            pair: Optional pair filter, e.g. "EURUSD". Returns all if omitted.

        Returns:
            dict with keys: snapshot, meta
        """
        return self._client._get("/forex/snapshot", {"pair": pair})

    def pairs(self) -> dict:
        """List all tracked forex pairs."""
        return self._client._get("/forex/pairs")

    def cot_reports(
        self,
        instrument: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 100,
    ) -> dict:
        """
        Fetch CFTC Commitment of Traders (COT) reports.

        Args:
            instrument: Futures instrument filter, e.g. "EURO FX"
            start_date: ISO 8601 start date
            end_date: ISO 8601 end date
            limit: Number of records (default 100)

        Returns:
            dict with keys: cot_reports, next_page_url, meta
        """
        return self._client._get("/forex/cot-reports", {
            "instrument": instrument,
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
        })
