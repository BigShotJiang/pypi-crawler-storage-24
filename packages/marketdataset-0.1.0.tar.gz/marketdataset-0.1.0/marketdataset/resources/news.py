from __future__ import annotations
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..client import Client


class NewsResource:
    def __init__(self, client: "Client"):
        self._client = client

    def list(
        self,
        category: str = "all",
        symbol: Optional[str] = None,
        limit: int = 20,
    ) -> dict:
        """
        Fetch latest financial news from top crypto and forex sources.

        Sources: CoinTelegraph, CoinDesk, CryptoSlate, Decrypt, Investing.com

        Args:
            category: "all", "crypto", "forex", or "macro"
            symbol: Filter by symbol mention, e.g. "BTC", "EURUSD", "XAUUSD"
            limit: Number of articles to return (default 20, max 50)

        Returns:
            dict with keys: news, meta

        Example:
            >>> news = client.news.list(category="crypto", symbol="BTC", limit=10)
            >>> for article in news["news"]:
            ...     print(article["title"], article["source"])
        """
        return self._client._get("/news", {
            "category": category,
            "symbol": symbol,
            "limit": limit,
        })
