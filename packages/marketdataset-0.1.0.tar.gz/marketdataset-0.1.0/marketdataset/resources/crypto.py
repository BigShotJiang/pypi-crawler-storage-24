from __future__ import annotations
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..client import Client


class CryptoResource:
    def __init__(self, client: "Client"):
        self._client = client

    def prices(
        self,
        symbol: str,
        quote: str = "USDT",
        interval: str = "hour",
        interval_multiplier: int = 1,
        exchange: str = "binance",
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 100,
        cursor: Optional[str] = None,
    ) -> dict:
        """
        Fetch historical OHLCV crypto prices.

        Args:
            symbol: Crypto symbol, e.g. "BTC", "ETH", "SOL"
            quote: Quote currency (default: "USDT")
            interval: Candle interval — "minute", "hour", "day", "week", "month"
            interval_multiplier: Multiplier, e.g. 4 for 4-hour candles
            exchange: Exchange (default: "binance")
            start_date: ISO 8601 start date
            end_date: ISO 8601 end date
            limit: Number of candles (default 100, max 5000)
            cursor: Pagination cursor

        Returns:
            dict with keys: crypto_prices, next_page_url, meta
        """
        return self._client._get("/crypto/prices", {
            "symbol": symbol,
            "quote": quote,
            "interval": interval,
            "interval_multiplier": interval_multiplier,
            "exchange": exchange,
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
            "cursor": cursor,
        })

    def snapshot(self, symbol: Optional[str] = None) -> dict:
        """
        Get live crypto prices from Binance (real-time, includes 24h stats).

        Args:
            symbol: Optional symbol filter, e.g. "BTC". Returns all 20 if omitted.

        Returns:
            dict with keys: snapshot, meta
        """
        return self._client._get("/crypto/snapshot", {"symbol": symbol})

    def assets(self) -> dict:
        """List all tracked crypto assets."""
        return self._client._get("/crypto/assets")

    def funding_rates(
        self,
        symbol: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 100,
    ) -> dict:
        """
        Fetch perpetual futures funding rates.

        Args:
            symbol: Futures symbol, e.g. "BTCUSDT"
            start_date: ISO 8601 start date
            end_date: ISO 8601 end date
            limit: Number of records (default 100)

        Returns:
            dict with keys: funding_rates, next_page_url, meta
        """
        return self._client._get("/crypto/funding-rates", {
            "symbol": symbol,
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
        })

    def open_interest(
        self,
        symbol: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 100,
    ) -> dict:
        """
        Fetch open interest data for futures markets.

        Args:
            symbol: Futures symbol, e.g. "BTCUSDT"
            start_date: ISO 8601 start date
            end_date: ISO 8601 end date
            limit: Number of records (default 100)

        Returns:
            dict with keys: open_interest, next_page_url, meta
        """
        return self._client._get("/crypto/open-interest", {
            "symbol": symbol,
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
        })

    def liquidations(
        self,
        symbol: Optional[str] = None,
        side: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 100,
    ) -> dict:
        """
        Fetch liquidation events for futures positions.

        Args:
            symbol: Futures symbol, e.g. "BTCUSDT"
            side: "BUY" or "SELL"
            start_date: ISO 8601 start date
            end_date: ISO 8601 end date
            limit: Number of records (default 100)

        Returns:
            dict with keys: liquidations, next_page_url, meta
        """
        return self._client._get("/crypto/liquidations", {
            "symbol": symbol,
            "side": side,
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
        })
