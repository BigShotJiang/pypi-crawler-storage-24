from __future__ import annotations
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:
    from ..client import Client


class MacroResource:
    def __init__(self, client: "Client"):
        self._client = client

    def rates(
        self,
        country: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        limit: int = 100,
    ) -> dict:
        """
        Fetch central bank interest rates.

        Args:
            country: Country filter, e.g. "US", "EU", "JP", "CA", "CH"
            start_date: ISO 8601 start date
            end_date: ISO 8601 end date
            limit: Number of records (default 100)

        Returns:
            dict with keys: rates, next_page_url, meta
        """
        return self._client._get("/macro/rates", {
            "country": country,
            "start_date": start_date,
            "end_date": end_date,
            "limit": limit,
        })

    def calendar(
        self,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
        impact: Optional[str] = None,
        currency: Optional[str] = None,
        limit: int = 100,
    ) -> dict:
        """
        Fetch economic calendar events.

        Args:
            start_date: ISO 8601 start date
            end_date: ISO 8601 end date
            impact: Filter by impact — "high", "medium", "low"
            currency: Currency filter, e.g. "USD", "EUR"
            limit: Number of records (default 100)

        Returns:
            dict with keys: events, next_page_url, meta
        """
        return self._client._get("/macro/calendar", {
            "start_date": start_date,
            "end_date": end_date,
            "impact": impact,
            "currency": currency,
            "limit": limit,
        })
