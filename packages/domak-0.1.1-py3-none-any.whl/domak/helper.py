# SPDX-License-Identifier: GPL-3.0-or-later

import json as json_m
from urllib.parse import urlencode
from urllib.request import urlopen, Request


def request(url: str, method="GET", headers={}, params={}, json={}, data=None) -> str:
    if params:
        url += "?" + urlencode(params, doseq=True)

    if json:
        headers["Content-Type"] = "application/json"
        data = json_m.dumps(json).encode()

    request = Request(url, method=method, headers=headers, data=data)
    res = urlopen(request)
    return res.read().decode()
