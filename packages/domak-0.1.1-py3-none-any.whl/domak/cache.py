# SPDX-License-Identifier: GPL-3.0-or-later

import time
import os


class Cache:
    cache_path: str

    def __init__(self, path="/tmp/domak"):
        self.cache_path = path

    def __path(self, file: str) -> str:
        return f"{self.cache_path}/{file}"

    def get(self, name: str) -> str | None:
        file = self.__path(name)
        if os.path.exists(file) and os.path.getmtime(file) > time.time() - 60 * 60 * 24:
            with open(file, "r") as o:
                content = o.read()
        else:
            content = None

        return content

    def set(self, name: str, value: str):
        if not os.path.exists(self.cache_path):
            os.makedirs(self.cache_path)
        file = self.__path(name)
        with open(file, "w") as o:
            o.write(value)
