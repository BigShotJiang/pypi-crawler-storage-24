# SPDX-License-Identifier: GPL-3.0-or-later

import json
from .helper import request


class DeSec:
    domain: dict
    headers: dict
    _api: str

    def __init__(self, domain: dict):
        self.domain = domain
        self.headers = {"Authorization": f"Token {self.domain['token']}"}
        self._api = f"https://desec.io/api/v1/domains/{domain['name']}/rrsets/"

    def get_ips(self) -> (str, str):
        subname = self.domain["subname"]
        payload = {"subname": [subname if subname != "@" else ""]}
        rrset = json.loads(
            request(
                self._api,
                headers=self.headers,
                params=payload,
            )
        )

        a = list(filter(lambda s: s["type"] == "A", rrset))[0]["records"][0]
        aaaa = list(filter(lambda s: s["type"] == "AAAA", rrset))[0]["records"][0]

        return (a, aaaa)

    def update(self, ip: str, dtype: str):
        subname = self.domain["subname"]
        payload = {"records": [ip]}
        res = request(
            f"{self._api}/{subname}/{dtype}/",
            method="PATCH",
            headers=self.headers,
            json=payload,
        )

        print(json.loads(res))
