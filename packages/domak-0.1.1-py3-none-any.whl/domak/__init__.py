# SPDX-License-Identifier: GPL-3.0-or-later

import argparse
import tomllib
from .desec import DeSec
from .cache import Cache
from .helper import request

__version__ = "0.1.1"

cache = Cache()


def ip_change(current: (str, str), stored: (str, str)) -> bool:
    (cur_4, cur_6) = current
    (store_4, store_6) = stored

    return cur_4 != store_4 or cur_6 != store_6


def get_handler(domain: dict):
    match domain["type"]:
        case "desec":
            return DeSec(domain)
        case _:
            raise Exception(f'unknown provider "{domain["type"]}"')


def main():
    parser = argparse.ArgumentParser(prog="domak", description="")
    parser.add_argument(
        "-c", "--config", type=argparse.FileType("rb"), default="/etc/domak.toml"
    )
    parser.add_argument(
        "-V", "--version", action="version", version=f"%(prog)s v{__version__}"
    )
    parser.add_argument("-d", "--dry-run", action="store_true")
    parser.add_argument("-f", "--force", action="store_true")
    args = parser.parse_args()

    config = tomllib.load(args.config)
    args.config.close()

    print("Get current ips")
    v4 = request(config["v4"]).strip()
    v6 = request(config["v6"]).strip()

    print("Check ips against cache")
    cache_change = ip_change((v4, v6), (cache.get("v4"), cache.get("v6")))
    print(f"  cache: {'changed/outdated' if cache_change else 'unchanged'}")

    if cache_change or args.force:
        for domain in config["domain"]:
            handler = get_handler(domain)
            try:
                print("Check ips against handler")
                handler_change = ip_change((v4, v6), handler.get_ips())
                print(f"  handler: {'changed' if handler_change else 'unchanged'}")
                if handler_change or args.force and not args.dry_run:
                    handler.update(v4, "A")
                    handler.update(v6, "AAAA")
            except Exception as e:
                print(f"ERROR: {domain['name']} failed with {e}")
        if not args.dry_run:
            print(f"Write ips ({v4}, {v6}) to cache")
            cache.set("v4", v4)
            cache.set("v6", v6)
