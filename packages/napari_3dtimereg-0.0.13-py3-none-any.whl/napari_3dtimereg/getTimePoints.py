from ij import IJ, Prefs
from fiji.plugin.trackmate.visualization.hyperstack import HyperStackDisplayer
from fiji.plugin.trackmate.io import TmXmlReader
from fiji.plugin.trackmate import Logger
from fiji.plugin.trackmate import Settings
from fiji.plugin.trackmate import SelectionModel
from fiji.plugin.trackmate.providers import DetectorProvider
from fiji.plugin.trackmate.providers import TrackerProvider
from fiji.plugin.trackmate.providers import SpotAnalyzerProvider
from fiji.plugin.trackmate.providers import EdgeAnalyzerProvider
from fiji.plugin.trackmate.providers import TrackAnalyzerProvider
import os
from fiji.plugin.trackmate.visualization.table import BranchTableView;
from java.io import File
import sys
 
## Script to extract the tracked points position from TrackMate files and put it in usable format for napari-3dtimereg to be used as reference points
## 
## 2024 - Gaelle Letort, DSCB Institut Pasteur/UMR 3738 CNRS.
 
dir = IJ.getDirectory("Choose aligned directory")
resdir = dir
if not os.path.exists(resdir):
	os.mkdir(resdir)

for filename in os.listdir(dir):
	if not filename.endswith(".xml"):
		continue
	
	print(filename)

	file = File(dir+filename)

	reader = TmXmlReader(file)
	if not reader.isReadingOk():
		sys.exit(reader.getErrorMessage())
  
	model = reader.getModel()
	sm = SelectionModel(model)
	img = reader.readImage()
	settings = reader.readSettings(img)
	img.close()
	scalet = settings.dt
	scalexy = settings.dx
	scalez = settings.dz

	pos = ""
	trackIDs = model.getTrackModel().trackIDs(True) # only filtered out ones
	for id in trackIDs:
			track = model.getTrackModel().trackSpots(id)
			for spot in track:
				sid = spot.ID()
				t=spot.getFeature('POSITION_T')
				x=spot.getFeature('POSITION_X')
				y=spot.getFeature('POSITION_Y')
				z=spot.getFeature('POSITION_Z')
				pos = pos + str(id)+','+str(x/scalexy)+','+str(y/scalexy)+','+str(z/scalez) + ','+str(t/scalet) + "\n"
   	IJ.log("\\Clear");
   	IJ.log("TrackID,X,Y,Z,T");
   	IJ.log(str(pos))
   	
   	IJ.selectWindow("Log")
   	imgname = filename[:-4]
   	IJ.saveAs("Text", resdir+File.separator+imgname+"_reference_points.csv")

