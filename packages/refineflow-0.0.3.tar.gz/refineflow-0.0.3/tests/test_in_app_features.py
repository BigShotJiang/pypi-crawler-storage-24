import pytest

from functools import partial 

from RefineFlow.refiner import RagRefiner
from RefineFlow.flow import Flow
from RefineFlow.ask import ask_openai, ask_chunks_w_simple_dict



def test_in_app_features():
    ############## ask definition ##############
    # No asks necessary in this example
    #############################################

    ############ refiners definition ##############
    
    knowledge_base={
        "sport":["Sport is very tiring", "You can get injured while playing", "The best sport is Martial Arts"],
        "videogames":["Videogames are cool!", "Videogames are a unique form of art", "My favourite videogame is Mirror's Edge"]
    }
    topic_refiner = RagRefiner(
    ask_llm = partial(ask_openai, model_name="gpt-3.5-turbo"),
    ask_chunks = partial(ask_chunks_w_simple_dict, dict_w_chunks=knowledge_base)
    )
    topic_input_prompt = """
        You are a topic classifier, you classify a sentence among these possible topics: 
        "sport", "videogames", "literature", "art"
        Whenever the user asks you something you answer only with one of the previous topics, considering which one is most fitting.
        Always answer with one of the possible topics and never add any notes or comments.
        If the user is not talking about anything remotely related to the previous topics, just answer with a "" string. 
    """
    topic_refiner.set_input_prompt(topic_input_prompt)
    topic_output_prompt ="""
    Consider this to be your knowledge base:
    {top_k_chunks}
    Answer the user's question utilizing your knowledge base.
    """
    topic_refiner.set_output_prompt(topic_output_prompt)

    angry_refiner = RagRefiner(
        ask_llm = partial(ask_openai, model_name="gpt-3.5-turbo"),
        ask_chunks = None,
        skip_execution_layer = True
    )
    angry_input_prompt = """
        You are a sport detector, you detect wheter a user is talking about anything related to sports.
        Whenever the user asks you something you answer with only the word sport if the user's request is related to sports.
        Answer with the word sport also if the subject of the sentence is lightly related to sports.
        If the user is not talking about anything remotely related to sports, just answer with a "" string. 
    """
    angry_refiner.set_input_prompt(angry_input_prompt)
    angry_output_prompt ="""
    You really hate sports. Show this in your answer.
    """
    angry_refiner.set_output_prompt(angry_output_prompt)

    #############################################
    
    ############# flow definition ###############

    flow = Flow(ask_openai, [topic_refiner, angry_refiner])
    
    start_prompt = """
    Your name is Marco, you are a helpful assistant.
    """

    end_prompt = ""
    answer_sport = flow.run(["Hello! what do you know about rugby?"], start_prompt, end_prompt)
    answer_videogames = flow.run(["Hello! what do you know about Mirror's Edge?"], start_prompt, end_prompt)
    answer_both = flow.run(["Hello! Do you play fifa?"], start_prompt, end_prompt)
    print(f"\n[Experiment]:\nanswer_sport: {answer_sport}\nanswer_videogames:{answer_videogames}\nanswer_both:{answer_both}\n")

    assert "martial" in answer_sport.lower() and "art" in answer_sport.lower()

    #############################################