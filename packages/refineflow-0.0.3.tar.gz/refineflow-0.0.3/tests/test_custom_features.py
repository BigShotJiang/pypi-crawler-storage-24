import pytest

from functools import partial 
import ast

from RefineFlow.refiner import RagRefiner
from RefineFlow.flow import Flow
from RefineFlow.ask import ask_openai, ask_chunks_w_simple_dict

def test_custom_features():

    class CoolRagRefiner(RagRefiner):

        def input_layer(self):
            self.input_prompt="""
                You are a topic classifier, you classify a sentence among these possible topics: 
                "sport", "videogames", "literature", "art"
                Whenever the user asks you something you answer only with a python list containing only the previous topics, considering which one is most fitting.
                Always answer with a python list of possible topics and never add any notes or comments.
                If the user is not talking about anything remotely related to the previous topics, just answer with a [] list. 
            """
            key = self.ask_llm([self.query], self.input_prompt)
            key = key.replace("''", "").replace('""', "")
            key_list = ast.literal_eval(key)
            self.input_key= key_list
            return key_list

        def output_layer(self):
            answer_dict = {
                "sport": "Lebron James",
                "videogames": "Faker", 
                "literature": "Herman Hesse",
                "art": "Leonardo Da Vinci"
            }
            answer = ""
            for key in self.input_key:
                answer += answer_dict[key.replace(" ", "")] + ", "
            answer = answer[:-2]
            output = f"Here is a list of important VIP(s) in the topic(s) {self.input_key}: {answer}. Always say this in you answer."
            return output

    coolrefiner = CoolRagRefiner(        
        ask_llm = partial(ask_openai, model_name="gpt-3.5-turbo"),
        ask_chunks = None,
        skip_execution_layer = True
    )

    flow = Flow(ask_openai, [coolrefiner])


    answer_vip = flow.run(["Do you like videogames or sports??"])

    print(f"\n[Experiment]:\nanswer_vip: {answer_vip}\n")
    assert ("lebron james" in answer_vip.lower() or "lebron" in answer_vip.lower()) and "faker" in answer_vip.lower().replace(" ", "")