import logging
from typing import Optional

def init_logging(name: Optional[str] = "RefineFlow"):
    bf_log = logging.getLogger(name)
    bf_log.setLevel(logging.DEBUG)

    if not bf_log.handlers:
        formatter = logging.Formatter(
            "%(asctime)s - %(levelname)s - [%(name)s]: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(formatter)
        bf_log.addHandler(console_handler)

    return bf_log