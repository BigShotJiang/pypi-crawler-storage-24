from typing import Optional, List, Callable
import concurrent.futures

from RefineFlow.refiner import Refiner
from RefineFlow.utils import init_logging


class Flow():

    def __init__(self, llm_prompt_and_ask: Callable, refiner_list: List[Refiner]):
        self.bf_log = init_logging(self.__class__.__name__)
        self.llm_prompt_and_ask = llm_prompt_and_ask
        self.refiner_list = refiner_list

    def run(self, chat_history:List[str], start_prompt: Optional[str]="", end_prompt: Optional[str]=""):
        output_prompt = start_prompt


        def run_instance(instance, arg):
            return instance.run_refiner(arg)
        with concurrent.futures.ThreadPoolExecutor() as executor:
            futures = [executor.submit(run_instance, obj, chat_history) for obj in self.refiner_list]
            
            for future in concurrent.futures.as_completed(futures):
                refiner_prompt = future.result() 
                if refiner_prompt is not None:
                    output_prompt += refiner_prompt

        
        output_prompt += end_prompt
        self.bf_log.info("All refiners completed, generating output answer")
        answer = self.llm_prompt_and_ask(chat_history, output_prompt)
        return answer
        