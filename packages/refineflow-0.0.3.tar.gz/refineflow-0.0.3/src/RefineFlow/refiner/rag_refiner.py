from typing import List, Optional, Callable

from RefineFlow.refiner import Refiner

class RagRefiner(Refiner):

    def __init__(
        self, 
        ask_llm: Callable,
        ask_chunks: Callable,
        skip_execution_layer = False
    ):
        super().__init__(ask_llm, skip_execution_layer)
        if not skip_execution_layer and ask_chunks is None:
            raise self.refiner_log.error(f"No ask_chunks defined while skip_execution_layer is set to False, this will generate an erro at refiner execution")
        self.ask_chunks = ask_chunks
    
    def execution_layer(self):
        top_k_chunks = []
        if not self.skip_execution_layer:
            top_k_chunks = self.ask_chunks(self.input_keys)
        return top_k_chunks