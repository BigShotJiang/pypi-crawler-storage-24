from typing import List, Optional, Callable

import re

from RefineFlow.utils import init_logging

class Refiner():

    def __init__(self,
        ask_llm: Callable,
        skip_execution_layer = False
    ):
        self.ask_llm = ask_llm
        self.skip_execution_layer = skip_execution_layer
        self.query = None
        self.chat_history = None
        self.input_keys = None
        self.top_k_chunks = None
        self.input_prompt = None
        self.output_prompt = None
        self.refiner_log = init_logging(self.__class__.__name__)



    # TODO handle different user outputs in bg dictionaries also refine how the standard flow in thought of, maybe a refinerflow helper func?

    def set_query(self, query:str):
        self.query = query

    def set_chat_history(self, chat_history:List[str]):
        self.chat_history = chat_history

    def set_top_k_chunks(self, top_k_chunks:str):
        self.top_k_chunks = top_k_chunks

    def set_input_keys(self, input_keys:str):
        self.input_keys = input_keys

    def set_context_chunks(self, context_chunks:List[str]):
        self.context_chunks = context_chunks

    def set_context_docs(self, context_docs:List[str]):
        self.context_docs = context_docs


    def set_input_prompt(self, input_prompt:str):
        self.input_prompt = input_prompt

    def input_layer(self):
        
        if self.input_prompt is None:
            return ""
        else:
            key = self.ask_llm([self.query], self.input_prompt)
            key = key.replace("''", "").replace('""', "")
            return key

            
    def execution_layer(self):
        self.top_k_chunks=[]

        return self.query

    def set_output_prompt(self, output_prompt:str):
        variables = re.findall(r'\{(\w+)\}', output_prompt)

        if len(variables) > 0 and self.skip_execution_layer:
            self.refiner_log.error(f"if execution layer is skipped no variables should be defined in the prompt. skipping output_prompt resetting.")
            output_prompt = self.output_prompt
        elif len(variables) == 1 and variables[0] != 'top_k_chunks':
            self.refiner_log.warning(f"Found formattable string {variables} inside output_prompt. This variable will contain knowledge defined form the rag.")
            output_prompt = output_prompt.replace(r"{"+variables[0]+r"}", r'{top_k_chunks}', 1)
        elif len(variables) > 1:
            self.refiner_log.error(f"output_prompt needs one and only one formattable variable that represents where in the output you want to define your knowledge base, if prompt is custom, please override function 'output_layer'. skipping output_prompt resetting.")
            output_prompt = self.output_prompt
        elif len(variables) == 0 and not self.skip_execution_layer:
            self.refiner_log.warning(f"Assuming output_prompt has no need for info from execution layer. please define skip_execution_layer as True at refiner initialization.")

        self.output_prompt = output_prompt

    def output_layer(self):
        try:
            output = self.output_prompt.format(top_k_chunks=self.top_k_chunks)
        except Exception as e:
            output = ""
        return output

    def run_refiner(self, chat_history:List):
        self.set_chat_history(chat_history)
        self.set_query(chat_history[-1])
        input_keys = self.input_layer()
        
        if input_keys is None or input_keys == '':
            self.refiner_log.info(f"Input layer refinered execution.")
            prompt = None
        else:
            self.refiner_log.info(f"Input layer activated. Keys found: {input_keys}")
            self.set_input_keys(input_keys)
            top_k_chunks = self.execution_layer()
            self.refiner_log.info(f"Adding info from execution layer.")
            self.set_top_k_chunks(top_k_chunks)
            prompt = self.output_layer()
            self.refiner_log.info(f"Output layer completed successfully")
        return prompt

        


