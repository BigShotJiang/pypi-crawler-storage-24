from typing import List, Optional
from openai import OpenAI
import os

def ask_openai(chat_history:List[str], prompt:str, model_name:Optional[str] = None, dotenv_api_key_name: Optional[str]=None):
    """
    Pre-built ask function implementing a GPT request.
    """
    if model_name is None:
        model_name = "gpt-3.5-turbo"
    if dotenv_api_key_name is None:
        dotenv_api_key_name = "OPENAI_API_KEY"
    api_key = os.environ.get(dotenv_api_key_name)
    
    if not api_key:
        raise ValueError(
            f"The environment variable '{dotenv_api_key_name}' is not defined. "
            "Please set it in your .env file or export it manually in your terminal."
        )
    client = OpenAI(api_key=api_key)
    messages: list[dict[str, str]] = []
    messages.append({"role": "system", "content": prompt})
    for i, message in enumerate(chat_history):
        role = "user" if i % 2 == 0 else "model"
        messages.append({"role": role, "content": message})
    request_params: dict[str, Any] = {
        "model": model_name,
        "messages": messages,
    }
    response = client.chat.completions.create(**request_params)

    return response.choices[0].message.content.strip()