from typing import List, Dict

def ask_chunks_w_simple_dict(query: str, dict_w_chunks:Dict[str, List[str]]):
    chunks = []
    lower_keys= [key.lower() for key in dict_w_chunks.keys()]
    if query.lower() in lower_keys:
        chunks = dict_w_chunks[query.lower()]
    else:
        chunks = ["No information found regarding this topic"]
    return chunks