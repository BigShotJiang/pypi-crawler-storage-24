"""Error triage: create/reopen GitHub issues from error patterns."""

from __future__ import annotations

import asyncio
import logging
from dataclasses import dataclass

from canon.db.error_store import ErrorStore
from canon.github.client import GitHubClient

logger = logging.getLogger(__name__)


@dataclass
class ErrorInfo:
    fingerprint: str
    exception_type: str
    message: str
    stack_trace: str = ""
    endpoint: str = ""
    count: int = 1
    first_seen: str = ""
    last_seen: str = ""
    posthog_url: str = ""
    severity: str = "medium"


@dataclass
class TriageResult:
    action: str  # "created", "deduplicated", "reopened"
    issue_number: int
    issue_url: str = ""


class ErrorTriager:
    """Creates or deduplicates GitHub issues from PostHog error patterns.

    Uses GitHubClient's public API methods (create_issue, update_issue,
    create_comment, ensure_label) rather than private HTTP helpers.
    """

    def __init__(
        self,
        *,
        error_store: ErrorStore,
        github_client: GitHubClient,
        repo: str,
        auto_triage_enabled: bool = True,
        agent_client: object | None = None,  # ClaudeClient, optional
    ) -> None:
        self._store = error_store
        self._gh = github_client
        self._repo = repo
        self._auto_triage_enabled = auto_triage_enabled
        self._agent_client = agent_client

    async def triage(self, error: ErrorInfo) -> TriageResult | None:
        if not self._auto_triage_enabled:
            logger.debug("Auto-triage disabled — skipping error %s", error.fingerprint)
            return None

        existing = await self._store.get_by_fingerprint(error.fingerprint, self._repo)

        if existing is not None:
            if existing.resolved_at is not None:
                return await self._reopen(existing.issue_number, existing.issue_url, error)
            await self._store.increment_occurrence(error.fingerprint, self._repo)
            return TriageResult(
                action="deduplicated",
                issue_number=existing.issue_number,
                issue_url=getattr(existing, "issue_url", ""),
            )

        return await self._create_issue(error)

    async def _create_issue(self, error: ErrorInfo) -> TriageResult:
        owner, repo_name = self._repo.split("/", 1)
        title = f"{error.exception_type}: {error.message}"[:256]
        body = self._format_issue_body(error)
        labels = ["bug", "auto-triage"]
        if error.severity in ("high", "critical"):
            labels.append(f"severity:{error.severity}")

        # Ensure labels exist (no-op if already present)
        for label in labels:
            await self._gh.ensure_label(owner, repo_name, label)

        # Create issue using public API
        data = await self._gh.create_issue(
            owner,
            repo_name,
            title=title,
            body=body,
            labels=labels,
        )

        issue_number = data["number"]
        issue_url = data["html_url"]

        mapping = await self._store.create(
            fingerprint=error.fingerprint,
            repo=self._repo,
            issue_number=issue_number,
            issue_url=issue_url,
            severity=error.severity,
        )
        if mapping is None:
            logger.warning(
                "Mapping conflict for %s — concurrent triage race (issue #%d already tracked)",
                error.fingerprint,
                issue_number,
            )
            return TriageResult(
                action="deduplicated", issue_number=issue_number, issue_url=issue_url
            )

        logger.info("Auto-created issue #%d for error %s", issue_number, error.fingerprint)

        await self._add_spec_context_comment(issue_number, error)

        return TriageResult(action="created", issue_number=issue_number, issue_url=issue_url)

    async def _add_spec_context_comment(self, issue_number: int, error: ErrorInfo) -> None:
        """Best-effort: comment on the issue with related spec context.

        Uses the Canon agent to identify which spec sections relate to
        the error's code path. Failures are logged, not raised.
        """
        try:
            owner, repo_name = self._repo.split("/", 1)
            prompt = (
                f"Error: {error.exception_type}: {error.message}\n"
                f"Endpoint: {error.endpoint}\n"
                f"Stack trace:\n{error.stack_trace[:2000]}\n\n"
                "Which spec sections in docs/specs/ relate to this error's code path? "
                "Reply with the spec file and section IDs, or 'No related specs found.'"
            )

            if self._agent_client is None or not self._agent_client.is_available:
                return

            from canon.agent.client import AgentConfig

            loop = asyncio.get_running_loop()
            result = await loop.run_in_executor(
                None,
                lambda: self._agent_client.complete(
                    system_prompt="You are Canon's SRE bot. Identify spec sections related to errors.",
                    user_message=prompt,
                    config=AgentConfig(max_output_tokens=500),
                ),
            )

            if result.text and "No related specs" not in result.text:
                comment = (
                    f"**Spec Context (Canon SRE Bot)**\n\n{result.text}\n\n"
                    f"---\n*Auto-analyzed by Canon SRE bot*"
                )
                await self._gh.create_comment(owner, repo_name, issue_number, comment)
        except Exception:
            logger.warning("Failed to add spec context to issue #%d", issue_number, exc_info=True)

    async def _reopen(self, issue_number: int, issue_url: str, error: ErrorInfo) -> TriageResult:
        owner, repo_name = self._repo.split("/", 1)

        # Reopen the issue using public API
        await self._gh.update_issue(owner, repo_name, issue_number, state="open")

        # Add recurrence comment using public API
        comment_body = (
            f"**Error recurrence detected**\n\n"
            f"This error has reappeared after being resolved.\n"
            f"- Exception: `{error.exception_type}: {error.message}`\n"
            f"- Count: {error.count}\n"
        )
        if error.posthog_url:
            comment_body += f"- [View in PostHog]({error.posthog_url})\n"

        await self._gh.create_comment(owner, repo_name, issue_number, comment_body)

        await self._store.clear_resolved(error.fingerprint, self._repo)
        await self._store.increment_occurrence(error.fingerprint, self._repo)

        logger.info("Reopened issue #%d for recurring error %s", issue_number, error.fingerprint)
        return TriageResult(action="reopened", issue_number=issue_number, issue_url=issue_url)

    def _format_issue_body(self, error: ErrorInfo) -> str:
        parts = [
            "## Auto-Triaged Error\n",
            f"**Exception:** `{error.exception_type}: {error.message}`\n",
            f"**Severity:** {error.severity}\n",
        ]
        if error.endpoint:
            parts.append(f"**Endpoint:** `{error.endpoint}`\n")
        if error.count > 1:
            parts.append(f"**Occurrences:** {error.count}\n")
        if error.first_seen:
            parts.append(f"**First seen:** {error.first_seen}\n")
        if error.last_seen:
            parts.append(f"**Last seen:** {error.last_seen}\n")
        if error.stack_trace:
            # Truncate to avoid leaking sensitive data (tokens, DB URLs, PII)
            truncated = error.stack_trace[:4000]
            if len(error.stack_trace) > 4000:
                truncated += "\n... (truncated)"
            parts.append(f"\n### Stack Trace\n```\n{truncated}\n```\n")
            parts.append(
                "> **Note:** Stack traces may contain sensitive information. "
                "Review before sharing outside the team.\n"
            )
        if error.posthog_url:
            parts.append(f"\n[View in PostHog]({error.posthog_url})\n")

        parts.append("\n---\n*Auto-created by Canon SRE alerting*")
        return "\n".join(parts)
