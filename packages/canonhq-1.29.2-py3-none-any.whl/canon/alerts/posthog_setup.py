"""PostHog alert actions and dashboard setup script.

Configures PostHog alerting and SRE dashboard via the PostHog API.
Run: python -m canon.alerts.posthog_setup

Requires environment variables:
  POSTHOG_PERSONAL_API_KEY: PostHog *personal* API token (not the project API key).
                            Project API keys are for event ingestion only; the
                            management REST API requires a personal API token
                            generated at Settings > Personal API Keys in PostHog.
                            WARNING: This is NOT the same as POSTHOG_KEY used by
                            the main application for event ingestion.
  POSTHOG_HOST: PostHog host (default: https://us.i.posthog.com)
  POSTHOG_PROJECT_ID: PostHog project ID
"""

from __future__ import annotations

import logging
import os
import sys

import httpx

logger = logging.getLogger(__name__)

POSTHOG_HOST = os.environ.get("POSTHOG_HOST", "https://us.i.posthog.com")
POSTHOG_KEY = os.environ.get("POSTHOG_PERSONAL_API_KEY", "")
POSTHOG_PROJECT_ID = os.environ.get("POSTHOG_PROJECT_ID", "")

# Alert definitions per spec Section 2.1
ALERT_DEFINITIONS = [
    {
        "name": "Canon: Exception spike",
        "description": "Exception count > 10 in 5 min window",
        "severity": "high",
        "event": "$exception",
        "threshold": 10,
        "window_minutes": 5,
    },
    {
        "name": "Canon: New error pattern",
        "description": "First-seen exception fingerprint",
        "severity": "medium",
        "event": "$exception",
        "threshold": 1,
        "window_minutes": 5,
    },
    {
        "name": "Canon: Webhook processing slow",
        "description": "p95 webhook duration > 30s over 15 min",
        "severity": "medium",
        "event": "request_completed",
        "threshold": 30000,
        "window_minutes": 15,
    },
    {
        "name": "Canon: Cron job failure",
        "description": "Cron execution with success=false",
        "severity": "high",
        "event": "cron_job_executed",
        "threshold": 1,
        "window_minutes": 5,
    },
    {
        "name": "Canon: Error rate elevated",
        "description": "Error rate > 5% of total requests over 15 min",
        "severity": "high",
        "event": "request_completed",
        "threshold": 5,
        "window_minutes": 15,
    },
    {
        "name": "Canon: Health check failure",
        "description": "Readiness probe returns unhealthy",
        "severity": "critical",
        "event": "health_check_failed",
        "threshold": 1,
        "window_minutes": 5,
    },
]

# Dashboard panels per spec Section 4.1
DASHBOARD_PANELS = [
    {"name": "Error rate", "event": "$exception", "viz": "ActionsLineGraph"},
    {"name": "Webhook latency (p95)", "event": "request_completed", "viz": "ActionsLineGraph"},
    {"name": "Request volume", "event": "request_completed", "viz": "ActionsAreaGraph"},
    {"name": "Success/failure ratio", "event": "request_completed", "viz": "ActionsBar"},
    {"name": "Active installations", "event": "request_completed", "viz": "BoldNumber"},
    {"name": "Cron job health", "event": "cron_job_executed", "viz": "ActionsTable"},
    {"name": "Agent metrics", "event": "agent_call_completed", "viz": "ActionsLineGraph"},
    {"name": "Top errors (24h)", "event": "$exception", "viz": "ActionsTable"},
    {"name": "Rate limit hits", "event": "rate_limit_hit", "viz": "ActionsBar"},
]


def _headers() -> dict[str, str]:
    return {
        "Authorization": f"Bearer {POSTHOG_KEY}",
        "Content-Type": "application/json",
    }


def setup_dashboard() -> None:
    """Create or update the SRE dashboard in PostHog."""
    if not POSTHOG_KEY or not POSTHOG_PROJECT_ID:
        logger.error("POSTHOG_KEY and POSTHOG_PROJECT_ID required")
        sys.exit(1)

    base = f"{POSTHOG_HOST}/api/projects/{POSTHOG_PROJECT_ID}"

    with httpx.Client(timeout=30.0, headers=_headers()) as client:
        # Check for existing dashboard
        list_resp = client.get(f"{base}/dashboards/")
        list_resp.raise_for_status()
        existing = [
            d for d in list_resp.json().get("results", []) if d["name"] == "Canon SRE Dashboard"
        ]
        if existing:
            dashboard_id = existing[0]["id"]
            logger.info("Dashboard already exists (id=%d) — updating panels", dashboard_id)
        else:
            resp = client.post(
                f"{base}/dashboards/",
                json={
                    "name": "Canon SRE Dashboard",
                    "description": "At-a-glance service reliability — per SRE Alerting spec Section 4",
                },
            )
            resp.raise_for_status()
            dashboard = resp.json()
            dashboard_id = dashboard["id"]
            logger.info("Created dashboard: %s (id=%d)", dashboard["name"], dashboard_id)

        # Fetch existing panel names to avoid duplicates on re-run
        dash_resp = client.get(f"{base}/dashboards/{dashboard_id}/")
        dash_resp.raise_for_status()
        existing_panels = {
            tile["insight"]["name"]
            for tile in dash_resp.json().get("tiles", [])
            if tile.get("insight")
        }

        for panel in DASHBOARD_PANELS:
            if panel["name"] in existing_panels:
                logger.info("  Panel already exists: %s — skipping", panel["name"])
                continue
            insight_resp = client.post(
                f"{base}/insights/",
                json={
                    "name": panel["name"],
                    "filters": {
                        "events": [{"id": panel["event"]}],
                        "display": panel["viz"],
                        "date_from": "-24h",
                    },
                    "dashboards": [dashboard_id],
                },
            )
            insight_resp.raise_for_status()
            logger.info("  Created panel: %s", panel["name"])

    logger.info("SRE Dashboard setup complete. Dashboard ID: %d", dashboard_id)


def print_alert_config() -> None:
    """Print alert configuration documentation for PostHog setup."""
    print("=" * 60)
    print("PostHog Alert Configuration")
    print("=" * 60)
    print()
    print("Configure these alerts in PostHog > Data Management > Actions")
    print("Then add Slack webhook subscriptions for each action.")
    print()
    for alert in ALERT_DEFINITIONS:
        print(f"Alert: {alert['name']}")
        print(f"  Description: {alert['description']}")
        print(f"  Severity: {alert['severity']}")
        print(f"  Event: {alert['event']}")
        print(f"  Threshold: {alert['threshold']}")
        print(f"  Window: {alert['window_minutes']} minutes")
        print()


def main() -> None:
    logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

    if "--dashboard" in sys.argv:
        setup_dashboard()
    elif "--alerts" in sys.argv:
        print_alert_config()
    else:
        print("Usage: python -m canon.alerts.posthog_setup [--dashboard | --alerts]")
        print("  --dashboard  Create SRE dashboard in PostHog")
        print("  --alerts     Print alert configuration docs")
        sys.exit(1)


if __name__ == "__main__":
    main()
