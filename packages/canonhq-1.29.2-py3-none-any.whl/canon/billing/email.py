"""Enterprise contact email notifications via SMTP."""

from __future__ import annotations

import asyncio
import logging
import smtplib
import ssl
from email.mime.text import MIMEText

logger = logging.getLogger(__name__)

_SMTP_TIMEOUT = 10  # seconds


def _sanitize_header(value: str) -> str:
    """Strip CR/LF to prevent email header injection."""
    return value.replace("\r", "").replace("\n", "")


def _send_email_sync(
    *,
    host: str,
    port: int,
    user: str,
    password: str,
    use_tls: bool,
    from_addr: str,
    to_addr: str,
    subject: str,
    body: str,
) -> None:
    msg = MIMEText(body, "plain", "utf-8")
    msg["Subject"] = _sanitize_header(subject)
    msg["From"] = _sanitize_header(from_addr)
    msg["To"] = _sanitize_header(to_addr)

    # Port 465 uses implicit TLS (SMTP_SSL); other ports use STARTTLS if enabled
    if port == 465:
        with smtplib.SMTP_SSL(host, port, timeout=_SMTP_TIMEOUT) as server:
            if user and password:
                server.login(user, password)
            server.sendmail(from_addr, [to_addr], msg.as_string())
    else:
        with smtplib.SMTP(host, port, timeout=_SMTP_TIMEOUT) as server:
            if use_tls:
                server.starttls(context=ssl.create_default_context())
            if user and password:
                server.login(user, password)
            server.sendmail(from_addr, [to_addr], msg.as_string())


async def send_enterprise_contact_email(
    *,
    smtp_host: str,
    smtp_port: int,
    smtp_user: str,
    smtp_password: str,
    smtp_tls: bool,
    smtp_from: str,
    to_addr: str,
    name: str,
    email: str,
    company: str,
    team_size: str,
    message: str = "",
) -> None:
    """Send an enterprise contact notification email. Best-effort — exceptions are logged, not raised."""
    subject = f"Canon Enterprise Inquiry — {company}"
    body = (
        f"New enterprise contact submission:\n\n"
        f"Name: {name}\n"
        f"Email: {email}\n"
        f"Company: {company}\n"
        f"Team size: {team_size}\n"
    )
    if message:
        body += f"Message: {message}\n"

    try:
        await asyncio.to_thread(
            _send_email_sync,
            host=smtp_host,
            port=smtp_port,
            user=smtp_user,
            password=smtp_password,
            use_tls=smtp_tls,
            from_addr=smtp_from,
            to_addr=to_addr,
            subject=subject,
            body=body,
        )
        logger.info("Enterprise contact email sent to %s for %s", to_addr, company)
    except Exception:
        logger.error("Failed to send enterprise contact email for %s", company, exc_info=True)
