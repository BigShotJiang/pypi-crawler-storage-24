"""Billing API routes — checkout, portal, webhooks, BYOK, enterprise contact."""

from __future__ import annotations

import asyncio
import hashlib
import logging
import re
from datetime import UTC, datetime

import anthropic as anthropic_sdk
import stripe as stripe_mod
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse

from .. import analytics
from ..auth.deps import require_permission
from ..auth.models import CurrentUser
from ..auth.permissions import Permission
from .email import send_enterprise_contact_email
from .models import (
    AnthropicKeyRequest,
    BillingCycle,
    CheckoutRequest,
    EnterpriseContactRequest,
    Plan,
    SubscriptionStatus,
)
from .service import TRIAL_DAYS

logger = logging.getLogger(__name__)

_background_tasks: set[asyncio.Task[None]] = set()

router = APIRouter(prefix="/app/{org}/api")
webhook_router = APIRouter(prefix="/api")


def _get_billing_service(request: Request):
    service = getattr(request.app.state, "billing_service", None)
    if service is None:
        raise HTTPException(
            status_code=503,
            detail="Billing is not available. Stripe is not configured for this deployment.",
        )
    return service


def _get_stripe_client(request: Request):
    client = getattr(request.app.state, "stripe_client", None)
    if client is None:
        raise HTTPException(
            status_code=503,
            detail="Billing is not available. Stripe is not configured for this deployment.",
        )
    return client


# --- Checkout ---


@router.post("/checkout")
async def create_checkout(
    org: str,
    request: Request,
    body: CheckoutRequest,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Create a Stripe Checkout Session for a per-seat subscription."""
    billing = _get_billing_service(request)
    stripe_client = _get_stripe_client(request)

    # Validate redirect URLs against platform_url to prevent open redirect
    platform_url = request.app.state.settings.platform_url
    if not platform_url:
        logger.error("platform_url is not configured — cannot create checkout session safely")
        return JSONResponse(
            content={"error": "Billing configuration incomplete"},
            status_code=500,
        )
    for url_field, url_val in [
        ("success_url", body.success_url),
        ("cancel_url", body.cancel_url),
    ]:
        if not url_val.startswith(platform_url.rstrip("/") + "/"):
            return JSONResponse(
                content={"error": f"{url_field} must start with {platform_url}"},
                status_code=400,
            )

    try:
        price_id = stripe_client.get_price_id(body.plan.value, body.billing_cycle.value)
    except ValueError as e:
        return JSONResponse(content={"error": str(e)}, status_code=400)

    # Check for existing subscription
    existing = await billing.get_subscription(user.org_login)
    customer_id = existing.stripe_customer_id if existing else None

    # Determine if eligible for free trial (no previous subscription)
    trial_days = TRIAL_DAYS if existing is None else None

    try:
        session = await asyncio.to_thread(
            stripe_client.create_checkout_session,
            customer_id=customer_id,
            customer_email=user.email if not customer_id else None,
            price_id=price_id,
            quantity=body.seat_count,
            success_url=body.success_url,
            cancel_url=body.cancel_url,
            metadata={
                "org_login": user.org_login,
                "plan": body.plan.value,
                "billing_cycle": body.billing_cycle.value,
                "seat_count": str(body.seat_count),
            },
            trial_period_days=trial_days,
        )
    except stripe_mod.StripeError as e:
        logger.error("Stripe checkout session creation failed: %s", e)
        return JSONResponse(
            content={"error": "Could not create checkout session — please try again"},
            status_code=502,
        )

    return JSONResponse(content={"checkout_url": session.url})


# --- Billing Portal ---


@router.post("/billing/portal")
async def create_portal_session(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Create a Stripe Billing Portal session for self-service management."""
    billing = _get_billing_service(request)
    stripe_client = _get_stripe_client(request)

    sub = await billing.get_subscription(user.org_login)
    if sub is None or not sub.stripe_customer_id:
        return JSONResponse(content={"error": "No active subscription"}, status_code=404)

    settings = request.app.state.settings
    portal = await asyncio.to_thread(
        stripe_client.create_portal_session,
        customer_id=sub.stripe_customer_id,
        return_url=f"{settings.platform_url}/app/{user.org_login}/",
    )
    return JSONResponse(content={"url": portal.url})


# --- Subscription info ---


@router.get("/billing/subscription")
async def get_subscription(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Get current subscription details."""
    billing = _get_billing_service(request)
    sub = await billing.get_subscription(user.org_login)
    if sub is None:
        return JSONResponse(content={"plan": None, "status": "none"})
    data = sub.model_dump(mode="json")
    data["is_trialing"] = sub.is_trialing
    data["ai_ops_included"] = sub.ai_ops_included
    data["max_repos"] = sub.max_repos
    return JSONResponse(content=data)


# --- Stripe Webhooks ---


@webhook_router.post("/webhooks/stripe")
async def stripe_webhook(request: Request):
    """Handle Stripe webhook events."""
    stripe_client = _get_stripe_client(request)
    billing = _get_billing_service(request)

    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")

    try:
        event = stripe_client.construct_webhook_event(payload, sig_header)
    except stripe_mod.SignatureVerificationError:
        logger.warning("Invalid Stripe webhook signature")
        return JSONResponse(content={"error": "Invalid signature"}, status_code=400)

    event_type = event["type"]
    data = event["data"]["object"]
    org_login = (data.get("metadata") or {}).get("org_login", "")

    # Atomic idempotency: claim the event ID first. If another concurrent
    # retry already claimed it, skip processing (no TOCTOU race).
    claimed = await billing.claim_event(event["id"], event_type)
    if not claimed:
        return JSONResponse(content={"ok": True, "skipped": True})

    try:
        if event_type == "checkout.session.completed":
            await _handle_checkout_completed(billing, event, data, org_login)

        elif event_type == "customer.subscription.updated":
            await _handle_subscription_updated(billing, data)

        elif event_type == "customer.subscription.deleted":
            sub_id = data.get("id", "")
            await billing.update_subscription_status(sub_id, SubscriptionStatus.CANCELED)

        elif event_type == "invoice.payment_failed":
            sub_id = data.get("subscription") or ""
            if sub_id:
                await billing.update_subscription_status(sub_id, SubscriptionStatus.PAST_DUE)

        # For events without org_login in metadata (e.g. invoices,
        # subscription updates), resolve it from our DB via subscription ID.
        if not org_login:
            sub_id = data.get("subscription") or data.get("id", "")
            if sub_id:
                org_login = await billing.get_org_login_by_subscription(sub_id) or ""

    except Exception:
        logger.error(
            "Failed to process Stripe webhook event %s (type=%s, org=%s)",
            event["id"],
            event_type,
            org_login,
            exc_info=True,
        )
        return JSONResponse(content={"error": "Internal processing error"}, status_code=500)

    # Update the claimed event row with resolved org_login and full payload.
    await billing.record_billing_event(
        org_login=org_login,
        stripe_event_id=event["id"],
        event_type=event_type,
        payload=dict(data),
    )

    return JSONResponse(content={"ok": True})


async def _handle_checkout_completed(
    billing: object, event: dict, data: dict, org_login: str
) -> None:
    """Process a checkout.session.completed event."""
    customer_id = data.get("customer", "")
    subscription_id = data.get("subscription", "")
    metadata = data.get("metadata") or {}
    plan_str = metadata.get("plan")
    cycle_str = metadata.get("billing_cycle")
    raw_seat_count = metadata.get("seat_count")
    if raw_seat_count is None:
        logger.warning(
            "checkout.session.completed event %s missing seat_count in metadata — defaulting to 3",
            event["id"],
        )
    try:
        seat_count = int(raw_seat_count) if raw_seat_count is not None else 3
    except (ValueError, TypeError):
        logger.warning(
            "checkout.session.completed event %s has malformed seat_count=%r — defaulting to 3",
            event["id"],
            raw_seat_count,
        )
        seat_count = 3

    if not org_login or not plan_str or not cycle_str:
        logger.error(
            "checkout.session.completed event %s missing required metadata "
            "(org_login=%r, plan=%r, billing_cycle=%r)",
            event["id"],
            org_login,
            plan_str,
            cycle_str,
        )
        return

    # Extract trial dates from checkout session subscription_details.
    # Billing period dates (current_period_start/end) are NOT available on
    # checkout.session.completed — they arrive via customer.subscription.updated
    # which Stripe fires immediately after checkout completes.
    sub_data = data.get("subscription_details") or {}
    trial_start = None
    trial_end = None

    if sub_data.get("trial_start"):
        trial_start = datetime.fromtimestamp(sub_data["trial_start"], tz=UTC)
    if sub_data.get("trial_end"):
        trial_end = datetime.fromtimestamp(sub_data["trial_end"], tz=UTC)

    await billing.create_subscription(
        org_login=org_login,
        stripe_customer_id=customer_id,
        stripe_subscription_id=subscription_id,
        plan=Plan(plan_str),
        billing_cycle=BillingCycle(cycle_str),
        seat_count=seat_count,
        trial_start=trial_start,
        trial_end=trial_end,
    )


async def _handle_subscription_updated(billing: object, data: dict) -> None:
    """Process a customer.subscription.updated event — sync status, seats, plan, and period."""
    status_str = data.get("status", "active")
    status_map = {
        "active": SubscriptionStatus.ACTIVE,
        "past_due": SubscriptionStatus.PAST_DUE,
        "canceled": SubscriptionStatus.CANCELED,
        "trialing": SubscriptionStatus.TRIALING,
        "unpaid": SubscriptionStatus.PAST_DUE,
        "incomplete": SubscriptionStatus.PAST_DUE,
        "incomplete_expired": SubscriptionStatus.CANCELED,
        "paused": SubscriptionStatus.PAST_DUE,
    }
    status = status_map.get(status_str)
    sub_id = data.get("id", "")

    if status is None:
        logger.error(
            "Unknown Stripe subscription status %r for subscription %s",
            status_str,
            sub_id,
        )
        return

    await billing.update_subscription_status(sub_id, status)

    # Sync billing period dates — these aren't available in checkout.session.completed,
    # so this handler is the primary source for period_start/period_end.
    period_start_ts = data.get("current_period_start")
    period_end_ts = data.get("current_period_end")
    if period_start_ts and period_end_ts:
        await billing.update_subscription_period(
            stripe_subscription_id=sub_id,
            period_start=datetime.fromtimestamp(period_start_ts, tz=UTC),
            period_end=datetime.fromtimestamp(period_end_ts, tz=UTC),
        )

    # Sync seat count from Stripe line items
    items = data.get("items", {}).get("data", [])
    if items:
        quantity = items[0].get("quantity")
        if quantity is not None:
            await billing.update_subscription_from_stripe(
                stripe_subscription_id=sub_id,
                seat_count=int(quantity),
            )

    # Sync plan if the price changed (e.g. upgrade/downgrade via portal)
    if items:
        price = items[0].get("price", {})
        price_id = price.get("id", "")
        if price_id:
            await billing.update_subscription_price(
                stripe_subscription_id=sub_id,
                stripe_price_id=price_id,
            )


# --- BYOK Key Management ---


@router.post("/settings/anthropic-key")
async def submit_anthropic_key(
    org: str,
    request: Request,
    body: AnthropicKeyRequest,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_ADMIN)),
):
    """Submit and validate an Anthropic API key for BYOK."""
    billing = _get_billing_service(request)

    # Validate the key by making a minimal API call (off the event loop)
    try:
        client = anthropic_sdk.Anthropic(api_key=body.api_key)
        await asyncio.to_thread(
            client.messages.create,
            model="claude-haiku-4-5-20251001",
            max_tokens=10,
            messages=[{"role": "user", "content": "ping"}],
        )
    except anthropic_sdk.AuthenticationError:
        return JSONResponse(content={"error": "Invalid API key"}, status_code=400)
    except anthropic_sdk.RateLimitError:
        return JSONResponse(
            content={"error": "API key is rate limited — try again later"},
            status_code=429,
        )
    except anthropic_sdk.APIConnectionError:
        return JSONResponse(
            content={"error": "Could not reach Anthropic API — please try again"},
            status_code=502,
        )
    except anthropic_sdk.APIStatusError as e:
        logger.warning("Anthropic API error during BYOK validation: %s", e)
        return JSONResponse(
            content={"error": "Anthropic API returned an error — please try again later"},
            status_code=502,
        )
    except Exception as e:
        logger.error("Unexpected error during BYOK key validation: %s", e, exc_info=True)
        return JSONResponse(
            content={"error": "Internal error validating key"},
            status_code=500,
        )

    try:
        await billing.store_anthropic_key(user.org_login, body.api_key)
    except Exception:
        logger.error("Failed to store BYOK key for org %s", user.org_login, exc_info=True)
        return JSONResponse(
            content={"error": "Failed to save your API key — please try again"},
            status_code=500,
        )

    suffix = body.api_key[-4:]
    return JSONResponse(
        content={"ok": True, "suffix": suffix, "status": "valid"},
        status_code=201,
    )


@router.delete("/settings/anthropic-key")
async def delete_anthropic_key(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_ADMIN)),
):
    """Remove the stored Anthropic API key."""
    billing = _get_billing_service(request)
    await billing.delete_anthropic_key(user.org_login)
    return JSONResponse(content={"ok": True})


@router.get("/settings/anthropic-key")
async def get_anthropic_key_status(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Get the status of the stored Anthropic API key (never returns the key)."""
    billing = _get_billing_service(request)
    status = await billing.get_anthropic_key_status(user.org_login)
    return JSONResponse(content=status.model_dump(mode="json"))


# --- AI Operations Usage ---


@router.get("/billing/ai-ops")
async def get_ai_ops_usage(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Get AI operation usage for the current billing period."""
    billing = _get_billing_service(request)
    sub = await billing.get_subscription(user.org_login)
    if sub is None:
        return JSONResponse(content={"error": "No active subscription"}, status_code=404)
    if sub.current_period_start is None or sub.current_period_end is None:
        return JSONResponse(content={"ops_used": 0, "ops_included": 0, "ops_remaining": 0})

    usage = await billing.get_ai_op_usage(
        user.org_login, sub.current_period_start, sub.current_period_end
    )
    return JSONResponse(
        content={
            "ops_used": usage.ops_used,
            "ops_included": usage.ops_included,
            "ops_remaining": usage.ops_remaining,
            "overage_ops": usage.overage_ops,
            "overage_cost_cents": usage.overage_cost_cents,
        }
    )


@router.get("/billing/seats")
async def get_seat_info(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Get seat count and active user count for the current billing period."""
    billing = _get_billing_service(request)
    sub = await billing.get_subscription(user.org_login)
    if sub is None:
        return JSONResponse(content={"error": "No active subscription"}, status_code=404)

    active_seats = 0
    if sub.current_period_start and sub.current_period_end:
        active_seats = await billing.get_active_seat_count(
            user.org_login, sub.current_period_start, sub.current_period_end
        )

    return JSONResponse(
        content={
            "seat_count": sub.seat_count,
            "active_seats": active_seats,
            "plan": sub.plan.value,
            "is_trialing": sub.is_trialing,
        }
    )


@router.post("/billing/start-trial")
async def start_trial(
    org: str,
    request: Request,
    user: CurrentUser = Depends(require_permission(Permission.SPECS_READ)),
):
    """Start a 14-day Pro trial. No credit card required."""
    billing = _get_billing_service(request)

    existing = await billing.get_subscription(user.org_login)
    if existing is not None:
        return JSONResponse(
            content={"error": "Organization already has a subscription or trial"},
            status_code=409,
        )

    sub = await billing.start_trial(
        org_login=user.org_login,
        stripe_customer_id=None,  # no Stripe customer until checkout
    )
    return JSONResponse(
        content={
            "ok": True,
            "plan": sub.plan.value,
            "status": sub.status.value,
            "trial_end": sub.trial_end.isoformat() if sub.trial_end else None,
        },
        status_code=201,
    )


# --- Enterprise Contact ---


@webhook_router.post("/contact/enterprise")
async def enterprise_contact(request: Request, body: EnterpriseContactRequest):
    """Handle enterprise contact form submission."""
    # Honeypot check
    if body.honeypot:
        return JSONResponse(content={"ok": True})  # silently ignore bots

    # Email format validation
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", body.email):
        return JSONResponse(content={"error": "Valid email required"}, status_code=400)

    billing = _get_billing_service(request)
    await billing.save_enterprise_contact(
        name=body.name,
        email=body.email,
        company=body.company,
        team_size=body.team_size,
        message=body.message,
    )

    hashed_id = hashlib.sha256(body.email.encode()).hexdigest()[:16]
    analytics.track(
        "enterprise_contact",
        distinct_id=hashed_id,
        properties={"company": body.company, "team_size": body.team_size},
    )

    settings = request.app.state.settings
    if settings.smtp_enabled:
        task = asyncio.create_task(
            send_enterprise_contact_email(
                smtp_host=settings.smtp_host,
                smtp_port=settings.smtp_port,
                smtp_user=settings.smtp_user,
                smtp_password=settings.smtp_password.get_secret_value(),
                smtp_tls=settings.smtp_tls,
                smtp_from=settings.smtp_from,
                to_addr=settings.enterprise_contact_email,
                name=body.name,
                email=body.email,
                company=body.company,
                team_size=body.team_size,
                message=body.message,
            )
        )
        _background_tasks.add(task)
        task.add_done_callback(_background_tasks.discard)

    logger.info(
        "Enterprise contact from %s (%s) — %s, team size %s",
        body.name,
        body.email,
        body.company,
        body.team_size,
    )

    return JSONResponse(content={"ok": True}, status_code=201)
