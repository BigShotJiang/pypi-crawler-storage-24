"""Auth0 OIDC provider implementation — cloud-only, excluded from OSS export."""

from __future__ import annotations

import asyncio
import logging
import time
from urllib.parse import quote, urlencode

import httpx

from ...settings import Settings
from .protocol import DeviceCodeResponse, OrgInfo, Pending, TokenSet

logger = logging.getLogger(__name__)


class Auth0Provider:
    """Auth0-specific OIDC provider with Organizations and Management API support."""

    def __init__(self, *, settings: Settings, http_client: httpx.AsyncClient | None = None) -> None:
        if not settings.auth0_domain:
            raise ValueError("auth0_domain is required for Auth0Provider")
        self._settings = settings
        self._http = http_client or httpx.AsyncClient(timeout=30)
        self._domain = settings.auth0_domain
        self._client_id = settings.auth0_client_id
        self._client_secret = settings.auth0_client_secret
        self._audience = settings.auth0_audience
        self._device_client_id = settings.auth0_device_client_id or settings.auth0_client_id
        # M2M credentials for Management API
        self._m2m_client_id = settings.auth0_m2m_client_id
        self._m2m_client_secret = settings.auth0_m2m_client_secret
        self._mgmt_token: str = ""
        self._mgmt_token_expires: float = 0
        self._mgmt_token_lock = asyncio.Lock()

    async def get_login_url(self, *, redirect_uri: str, state: str, org_hint: str = "") -> str:
        params = {
            "response_type": "code",
            "client_id": self._client_id,
            "redirect_uri": redirect_uri,
            "scope": "openid email profile",
            "state": state,
        }
        if self._audience:
            params["audience"] = self._audience
        if org_hint:
            params["organization"] = org_hint
        return f"https://{self._domain}/authorize?{urlencode(params)}"

    async def exchange_code(self, *, code: str, redirect_uri: str) -> TokenSet:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            data={
                "grant_type": "authorization_code",
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "code": code,
                "redirect_uri": redirect_uri,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        access_token = data.get("access_token")
        if not access_token:
            raise RuntimeError("Token exchange returned no access_token")
        return TokenSet(
            access_token=access_token,
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_in=data.get("expires_in", 0),
        )

    async def refresh_tokens(self, *, refresh_token: str) -> TokenSet:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            data={
                "grant_type": "refresh_token",
                "client_id": self._device_client_id,
                "refresh_token": refresh_token,
            },
        )
        resp.raise_for_status()
        data = resp.json()
        access_token = data.get("access_token")
        if not access_token:
            raise RuntimeError("Token refresh returned no access_token")
        return TokenSet(
            access_token=access_token,
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", refresh_token),
            expires_in=data.get("expires_in", 0),
        )

    async def get_jwks_uri(self) -> str:
        return f"https://{self._domain}/.well-known/jwks.json"

    async def get_logout_url(self, *, return_to: str) -> str | None:
        params = urlencode({"client_id": self._client_id, "returnTo": return_to})
        return f"https://{self._domain}/v2/logout?{params}"

    async def get_device_code(
        self, *, audience: str = "", scope: str = ""
    ) -> DeviceCodeResponse | None:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/device/code",
            data={
                "client_id": self._device_client_id,
                "scope": scope or "openid profile email offline_access",
                "audience": audience or self._audience,
            },
        )
        if resp.status_code != 200:
            logger.warning(
                "Auth0 device code request failed: status=%d body=%s",
                resp.status_code,
                resp.text[:500],
            )
            return None
        data = resp.json()
        return DeviceCodeResponse(
            device_code=data["device_code"],
            user_code=data["user_code"],
            verification_uri=data.get("verification_uri", ""),
            verification_uri_complete=data.get("verification_uri_complete", ""),
            interval=data.get("interval", 5),
            expires_in=data.get("expires_in", 900),
        )

    async def poll_device_token(self, device_code: str) -> TokenSet | Pending:
        resp = await self._http.post(
            f"https://{self._domain}/oauth/token",
            data={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "client_id": self._device_client_id,
                "device_code": device_code,
            },
        )
        if resp.status_code == 403:
            error = resp.json().get("error", "")
            if error in ("authorization_pending", "slow_down"):
                return Pending(slow_down=error == "slow_down")
            raise RuntimeError(f"Device auth error: {error}")
        if resp.status_code != 200:
            raise RuntimeError(f"Device token request failed: {resp.status_code}")
        data = resp.json()
        access_token = data.get("access_token")
        if not access_token:
            raise RuntimeError(
                f"Device token response missing access_token (status={resp.status_code})"
            )
        return TokenSet(
            access_token=access_token,
            id_token=data.get("id_token", ""),
            refresh_token=data.get("refresh_token", ""),
            expires_in=data.get("expires_in", 0),
        )

    async def get_user_orgs(self, user_id: str) -> list[OrgInfo]:
        if not self._m2m_client_id or not self._m2m_client_secret:
            logger.warning(
                "AUTH0_M2M_CLIENT_ID/SECRET not configured — cannot fetch user organizations"
            )
            return []
        token = await self._get_mgmt_token()
        encoded_id = quote(user_id, safe="")
        resp = await self._http.get(
            f"https://{self._domain}/api/v2/users/{encoded_id}/organizations",
            headers={"Authorization": f"Bearer {token}"},
            params={"per_page": "100"},
        )
        resp.raise_for_status()
        return [
            OrgInfo(
                id=o.get("id", ""), name=o.get("name", ""), display_name=o.get("display_name", "")
            )
            for o in resp.json()
        ]

    async def aclose(self) -> None:
        """Close the underlying HTTP client."""
        await self._http.aclose()

    async def _get_mgmt_token(self) -> str:
        if self._mgmt_token and time.monotonic() < self._mgmt_token_expires:
            return self._mgmt_token
        async with self._mgmt_token_lock:
            # Double-check after acquiring lock
            if self._mgmt_token and time.monotonic() < self._mgmt_token_expires:
                return self._mgmt_token
            resp = await self._http.post(
                f"https://{self._domain}/oauth/token",
                data={
                    "grant_type": "client_credentials",
                    "client_id": self._m2m_client_id,
                    "client_secret": self._m2m_client_secret,
                    "audience": f"https://{self._domain}/api/v2/",
                },
            )
            resp.raise_for_status()
            data = resp.json()
            self._mgmt_token = data["access_token"]
            self._mgmt_token_expires = time.monotonic() + data.get("expires_in", 86400) - 60
            return self._mgmt_token
