from anystore.settings import BaseSettings
from pydantic import AliasChoices, Field, HttpUrl
from pydantic_settings import SettingsConfigDict

__version__ = "5.2.1"

MAX_PAGE = 9999
BULK_PAGE = 1000


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env", env_prefix="openaleph_search_", extra="ignore"
    )

    testing: bool = Field(
        default=False, validation_alias=AliasChoices("testing", "debug")
    )

    auth: bool = False
    """Set to true when using with OpenAleph"""

    auth_field: str = "dataset"
    """Default field to filter/apply auth on"""

    uri: HttpUrl | list[HttpUrl] = Field(
        default=HttpUrl("http://localhost:9200"), alias="openaleph_elasticsearch_uri"
    )

    ingest_uri: HttpUrl | list[HttpUrl] | None = Field(
        default=None, alias="openaleph_elasticsearch_ingest_uri"
    )
    """Optional dedicated URI(s) for ingest (pre-index) operations (nodes with
    dedicated ingest role that might do some enrichment). Falls back to uri if
    not set."""

    timeout: int = 60
    max_retries: int = 3
    retry_on_timeout: bool = True

    # Connection pool settings for AsyncElasticsearch
    connection_pool_limit_per_host: int = 25

    indexer_concurrency: int = 8
    indexer_chunk_size: int = 1000
    indexer_max_chunk_bytes: int = 5 * 1024 * 1024  # 5mb

    index_shards: int = 10
    index_replicas: int = 0
    index_prefix: str = "openaleph"
    index_write: str = "v1"
    index_read: str | list[str] = ["v1"]
    index_expand_clause_limit: int = 10
    index_delete_by_query_batchsize: int = 100
    index_namespace_ids: bool = True
    index_refresh_interval: str = "1s"

    # configure different weights for indices
    index_boost_intervals: int = 1
    index_boost_things: int = 1
    index_boost_documents: int = 1
    index_boost_pages: int = 1

    # Sampler for significant_terms / significant_text aggregations
    significant_terms_sampler_size: int = 2000
    significant_text_sampler_size: int = 200
    significant_terms_min_doc_count: int = 5
    significant_terms_shard_min_doc_count: int = 2

    # Use random_sampler (Bernoulli segment-level sampling) instead of
    # sampler/diversified_sampler for significant_terms aggregations.
    # Dramatically reduces CPU cost of background frequency lookups.
    significant_terms_random_sampler: bool = True
    significant_terms_sampler_probability: float = 0.1

    # enable/disable function_score wrapper for performance tuning
    query_function_score: bool = False

    # enable/disable term vectors and offsets for content field (used for highlighting)
    content_term_vectors: bool = True

    # Highlighter configuration
    highlighter_fvh_enabled: bool = False
    highlighter_fragment_size: int = 200
    highlighter_number_of_fragments: int = 3
    highlighter_phrase_limit: int = 64
    highlighter_boundary_max_scan: int = 100
    highlighter_no_match_size: int = 300
    highlighter_text_field: bool = True
    highlighter_translation_field: bool = True
    highlighter_max_analyzed_offset: int = 100000

    # More Like This defaults
    mlt_min_doc_freq: int = 1
    mlt_min_term_freq: int = 1
    mlt_max_query_terms: int = 200
    mlt_minimum_should_match: str = "10%"
    mlt_min_word_length: int = 5
    mlt_max_doc_freq: int = 500

    # Entity matching stages (names_query in query/matching.py)
    # Stages 1 (names) and 2 (name_keys) are always enabled.
    match_name_parts: bool = True
    match_phonetic: bool = False
    match_symbols: bool = False

    # Pre-build global ordinals on frequently-aggregated keyword fields
    # during refresh. Eliminates first-query latency spikes at the cost of
    # slightly slower refreshes.
    eager_global_ordinals: bool = True

    # search control
    allow_leading_wildcard: bool = False
