## Keybindings

**Default key:** F1 (in-session)

All default key bindings are builtin macros and can be rebound in the
macro editor (Alt + M).

### Session Keys

| Key | Action |
|-----|--------|
| **F1** | This help screen |
| **Alt + H** | Edit highlights (TUI editor) |
| **Alt + Shift + H** | Toggle highlights on/off |
| **Alt + M** | Edit macros (TUI editor) |
| **Alt + T** | Edit triggers (TUI editor) |
| **Alt + Shift + T** | Toggle triggers on/off |
| **Alt + C** | Chat viewer / captures |
| **Alt + B** | Edit progress bars (TUI editor) |
| **Alt + E** | Edit theme |
| **Alt + Q** | Stop all running scripts |
| **Ctrl + L** | Repaint screen |
| **Ctrl + ]** | Disconnect |

### GMCP Keys (available when server supports GMCP)

| Key | Action |
|-----|--------|
| **F3** | Random walk dialog |
| **F4** | Autodiscover (explore unvisited exits) |
| **F5** | Resume last walk |
| **Alt + R** | Browse rooms / travel |

### Line Editing

| Key | Action |
|-----|--------|
| **Left** / **Right** | Move cursor |
| **Home** / **Ctrl + A** | Beginning of line |
| **End** / **Ctrl + E** | End of line |
| **Ctrl + Left** | Move word left |
| **Ctrl + Right** | Move word right |
| **Backspace** | Delete before cursor |
| **Delete** | Delete at cursor |
| **Ctrl + K** | Kill to end of line |
| **Ctrl + U** | Kill entire line |
| **Ctrl + W** | Kill word back |
| **Ctrl + Y** | Yank (paste killed text) |
| **Ctrl + Z** | Undo |
| **Up** / **Down** | History navigation |

### Command Processing

Commands are separated by **`;`** (wait for server prompt) or **`|`**
(send immediately, no prompt wait).  For example, `get all;drop sword`
sends "get all", waits for the prompt, then sends "drop sword".
A repeat prefix like `3n;2e` expands to `n;n;n;e;e`.

See the **Command Syntax** section (press F1 inside the macro or
trigger editor) for the full reference on backtick commands,
condition gates, travel, and more.
