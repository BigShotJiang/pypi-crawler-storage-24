'''
Name: Jacinto Jeje Matamba Quimua
Date: March 2026

This file implements a class for the Kuzonga graph object as an adjacency list, as described in the schema, with custom weights for the edges.
'''

import numbers
import random
import gymnasium as gym
import kuzongaenv
import copy
from collections import deque


class KuzongaVis():
    def __init__(self, state=None, division_cost=None, digit_change_cost=None, depth=None):
        '''
        parameters:
            state(dict): a valid Kuzonga state which will be the root node of the graph
            division_cost(str, int, float): the cost for the division operation. By default it assigns the weight "w" as w=g, where "g" is the divisor, 2<=g<=9.
            digit_change_cost(str, int, float): the cost for the digit change operation. By default it assigns the weight "w" as w=10(r+1)+ b, where "b" in "P_r" is the new digit to be placed at rindex "r".
                NOTE: The parameters division_cost and digit_change_cost can be set to the string "random" to assign a random cost from 0-100 to each edge.
            depth(int): how far to go down the graph tree
        '''
        self.original_state=state

        # set depth
        self.depth=1
        if isinstance(depth, int) and depth>0:
            self.depth=depth

        # the cost of the weights
        self.division_cost=None
        if division_cost=='random' or isinstance(division_cost, numbers.Number):
            self.division_cost=division_cost

        self.digit_change_cost=None
        if digit_change_cost=='random' or isinstance(digit_change_cost, numbers.Number):
            self.digit_change_cost=digit_change_cost

        # set the env
        self.env=gym.make("Kuzonga-v0")

        # initialize adjacency list
        self.adjacency_list=[]

    def _is_leaf_node(self, node):
        # set the node
        obs, info = self.env.reset(options={'obs': copy.deepcopy(node)})
        if info.get('concluded', False):
            return True
        return False
    
    def _node_exists(self, node):
        '''check if node exists in the graph'''
        all_nodes = self.all_nodes()
        if node in all_nodes:
            return True
        return False
        
    def make_adjacency_list(self):
        # if adjacency list already exists, dont recompute it
        if self.adjacency_list:
            return
        
        # set the main queue
        main_queue = deque()
        # initialize it with the original state
        main_queue.append(self.original_state)

        new_parent_count=0 # tracks the new generation of parents
        current_parent_count=1 # tracks the parents in the current generation

        while len(main_queue) > 0:
            # get next in line
            next_in_line = main_queue.popleft()
            if not self._node_exists(next_in_line):
                # compute children if it is not a leaf node
                if not self._is_leaf_node(next_in_line):
                    # set the state
                    # IMPORTANT: It is necessary to use a deepcopy because the step() method changes the state passed into it by reference!
                    obs, info = self.env.reset(options={'obs': copy.deepcopy(next_in_line)})
                    # get the actions
                    all_actions = info['all_actions']
                    # update new parent count
                    new_parent_count+=len(all_actions)
                    # create the children list
                    children=[]
                    # populate the children list
                    for action in all_actions:
                        # compute child
                        obs, reward, terminated, truncated, info = self.env.step(action)

                        # set the cost to perform the action AKA cost to go from the parent to the child node
                        transition_cost=0
                        # (1) division
                        if action['v']==1:
                            if self.division_cost==None:
                                transition_cost=action['g']
                            elif self.division_cost=='random':
                                transition_cost=random.randint(0, 100)
                            else:
                                transition_cost=self.division_cost
                        # (2) digit change
                        elif action['v']==0:
                            if self.digit_change_cost==None:
                                transition_cost = 10*(action['r'] + 1) + action['g']
                            elif self.digit_change_cost=='random':
                                transition_cost=random.randint(0, 100)
                            else:
                                transition_cost=self.digit_change_cost
                        
                        # set child
                        child ={
                            'node': info['obs_decoded'],
                            'cost': transition_cost
                        }
                        children.append(child)

                        # reset env
                        obs, info = self.env.reset(options={'obs': copy.deepcopy(next_in_line)})

                    # add the node-children to the adjacency list
                    entry={
                        'node': next_in_line,
                        'children': children
                    }
                    self.adjacency_list.append(entry)

                    for child in children:
                        # add each children to the main queue
                        main_queue.append(child['node'])
                else:
                    # if it is a leaf node, dont compute children, just add to the adjacency list
                    entry={
                        'node': next_in_line,
                        'children': []
                    }
                    self.adjacency_list.append(entry)
            
            # update current parent count
            current_parent_count-=1
            if current_parent_count==0:
                current_parent_count+=new_parent_count
                # reset new parent count
                new_parent_count=0
                # check depth requirements
                if self.depth:
                    self.depth-=1
                    if self.depth==0:
                        break
    
    def get_adjacency_list(self):
        return self.adjacency_list
    
    def all_nodes(self):
        all_nodes=[]
        my_adjacency_list=self.get_adjacency_list()
        for entry in my_adjacency_list:
            if entry['node'] not in all_nodes:
                all_nodes.append(entry['node'])
        return all_nodes
    
    def total_nodes(self):
        return len(self.all_nodes())
    
    def all_edges(self):
        all_edges=[]
        my_adjacency_list=self.get_adjacency_list()
        for entry in my_adjacency_list:
            for child in entry['children']:
                # to be a child of a node does not automatically mean to be in the adjacency list, so we need to check
                #   it's kinda like checking if the child has been born yet or not lol
                if self._node_exists(child['node']):
                    edge={
                        'from': entry['node'],
                        'to': child['node']
                    }
                    if edge not in all_edges:
                        all_edges.append(edge)
        return all_edges
    
    def total_edges(self):
        return len(self.all_edges())
    
    def adjacent_nodes(self, node):
        adjacent_nodes=[]
        my_adjacency_list=self.get_adjacency_list()
        for entry in my_adjacency_list:
            if entry['node']==node:
                for child in entry['children']:
                    # to be a child of a node does not automatically mean to be in the adjacency list, so we need to check
                    #   it's kinda like checking if the child has been born yet or not lol
                    if self._node_exists(child['node']):
                        adjacent_nodes.append(child['node'])
        return adjacent_nodes

    def degree(self, node):
        return len(self.adjacent_nodes(node))
    
