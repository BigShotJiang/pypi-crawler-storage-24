from setuptools import setup, find_packages

setup(
    name="kuzongavis",
    version="0.1.2",
    author="Jacinto Jeje Matamba Quimua",
    description="To help visualize the game graph",
    packages=find_packages(),
    install_requires=[
        "gymnasium>=0.29",
        "numpy>=1.23",
        "kuzongaenv>=0.3.3",
    ],
    python_requires=">=3.10",
)
