# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Union, Iterable, Optional
from typing_extensions import Literal, TypeAlias, TypedDict

from .._types import SequenceNotStr
from .page_range_param import PageRangeParam

__all__ = ["SettingsParam", "PageRange"]

PageRange: TypeAlias = Union[PageRangeParam, Iterable[PageRangeParam], Iterable[int], SequenceNotStr[str]]


class SettingsParam(TypedDict, total=False):
    document_password: Optional[str]
    """Password to decrypt password-protected documents."""

    embed_pdf_metadata: bool
    """If True, embed OCR metadata into the returned PDF. Defaults to False."""

    extraction_mode: Literal["ocr", "hybrid"]
    """The mode to use for text extraction from PDFs.

    OCR mode uses optical character recognition only. Hybrid mode combines OCR with
    embedded PDF text for best accuracy (default).
    """

    force_file_extension: Optional[str]
    """Force the URL to be downloaded as a specific file extension (e.g. `.png`)."""

    force_url_result: bool
    """Force the result to be returned in URL form."""

    ocr_system: Literal["standard", "legacy"]
    """Standard is our best multilingual OCR system.

    Legacy only supports germanic languages and is available for backwards
    compatibility.
    """

    page_range: Optional[PageRange]
    """The page range to process (1-indexed).

    By default, the entire document is processed. For spreadsheets, you can also
    provide a list of sheet names.
    """

    persist_results: bool
    """If True, persist the results indefinitely. Defaults to False."""

    return_images: List[Literal["figure", "table", "page"]]
    """Whether to return images for the specified block types.

    'page' returns full page images. By default, no images are returned.
    """

    return_ocr_data: bool
    """If True, return OCR data in the result. Defaults to False."""

    timeout: Optional[float]
    """The timeout for the job in seconds."""
