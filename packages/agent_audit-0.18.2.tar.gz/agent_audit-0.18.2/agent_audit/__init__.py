"""Agent Audit - Security scanner for AI agents and MCP configurations."""

__version__ = "0.18.2"
