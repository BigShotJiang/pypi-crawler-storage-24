"""Version information for agent-audit."""

__version__ = "0.18.2"
