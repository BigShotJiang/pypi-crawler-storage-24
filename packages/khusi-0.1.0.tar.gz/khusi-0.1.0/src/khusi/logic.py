from sympy.logic.inference import satisfiable
from sympy.core.sympify import sympify

def is_tautology(expression):
    """
    Checks if a given logical expression is a tautology.
    Returns True if it is a tautology, False otherwise.
    """
    try:
        # Convert the input string into a sympy expression
        expr = sympify(expression)
        
        # Check if the negation of the expression is satisfiable
        # If the negation is False (unsatisfiable), the original is a tautology
        negated_expr = ~expr
        result = satisfiable(negated_expr)
        
        if result is False:
            return True
        return False
        
    except Exception as e:
        raise ValueError(f"Could not parse the logical expression: {e}")