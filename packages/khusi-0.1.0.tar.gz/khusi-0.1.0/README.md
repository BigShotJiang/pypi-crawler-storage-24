# khusi

A simple Python library to check if a logical expression is a tautology.

## Installation
```bash
pip install khusi