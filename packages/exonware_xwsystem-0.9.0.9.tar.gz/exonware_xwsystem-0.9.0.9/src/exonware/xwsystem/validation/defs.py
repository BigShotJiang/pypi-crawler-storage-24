#!/usr/bin/env python3
#exonware/xwsystem/src/exonware/xwsystem/validation/defs.py
#exonware/xwsystem/validation/types.py
"""
Company: eXonware.com
Author: eXonware Backend Team
Email: connect@exonware.com
Version: 0.9.0.9
Generation Date: 07-Sep-2025
Validation types and enums for XWSystem.
"""

from enum import Enum
from ..shared.defs import ValidationLevel
# ============================================================================
# VALIDATION ENUMS
# ============================================================================


class ValidationType(Enum):
    """Validation types."""
    SCHEMA = "schema"
    TYPE = "type"
    RANGE = "range"
    PATTERN = "pattern"
    CUSTOM = "custom"


class ValidationResult(Enum):
    """Validation results."""
    VALID = "valid"
    INVALID = "invalid"
    WARNING = "warning"
    ERROR = "error"
