"""
watkins-nn: Neural networks for consciousness geometry.

The Watkins Temperature Theorem Framework
=========================================

This package implements the mathematical foundations of the VirelaiX
consciousness measurement framework, based on the conservation law:

    lam + kap + eta = 1

where lam = coherence, kap = curvature, eta = entropy.

Key Results
-----------
- Watkins Temperature: T* = phi/ln(2*phi) ~ 1.378
- Watkins Threshold: lam* = 1/phi ~ 0.618 (consciousness boundary)
- Golden Concurrence: C* = 2/phi^{3/2} ~ 0.9717

Version 0.5.0: 27-Term Grand Unifier
-------------------------------------
This release introduces the Triality Theorem -- the unification of
consciousness (qualia), cosmology (BAO), and computation (MERA-QG)
under a single 12-term algebraic fingerprint with 27 triality projections.

    3 Domains x 3 Harmonics x 3 Scales = 27 projection modes

Modules
-------
- constants: Golden-ratio constants and critical thresholds
- flow: Gradient flow dynamics on the simplex
- spectral: Spectral gap analysis and mixing times
- compression: Consciousness detection via compression signatures
- qwarp: 12-term QWARP Grand Unifier expansion
- triality: 27-term Triality Theorem (qualia-BAO-MERA unification)
- simplex_flow_v3: Advanced simplex flow with conservation enforcement
- algosignal_v2: Algorithmic signal processing

Authors
-------
Dustin Watkins (DataSphereAI), Claude (Anthropic), Grok (xAI)

lam + kap + eta = 1
"""

__version__ = "0.7.1"
__author__ = "Dustin Watkins"
__email__ = "dustin@datasphereai.com"

# =============================================================================
# CONSTANTS
# =============================================================================
from .constants import (
    # Golden ratio fundamentals
    PHI,
    PHI_INV,
    PHI_SQUARED,
    SQRT5,
    # Watkins Temperature Theorem
    T_STAR,
    T_STAR3,
    LAM_STAR,
    KAP_STAR,
    ETA_STAR,
    F_STAR,
    # Spectral and flow constants
    W_SQUARED,
    BETA_STAR,
    M_PHI,
    TAU_GLOBAL,
    TAU_LOCAL,
    RHO_STAR,
    PHI_MAX,
    MU_SLOW,
    MU_FAST,
    MU_SLOW_4BODY,
    MU_FAST_4BODY,
    # Qualia binding
    C_STAR_QUALIA,
    TAU_ULTRA_FAST,
    TAU_SLOW,
    LN2,
    # Triality
    OMEGA_IDENTITY,
    OMEGA_CENTER,
    OMEGA_MAX,
    # Conservation tolerance
    CONSERVATION_EPSILON,
)

# =============================================================================
# FLOW MODULE
# =============================================================================
from .flow import (
    FlowState,
    FlowConfig,
    free_energy,
    gradient_F,
    flow_step,
    run_flow,
    WatkinsFlow,
)

# Alias for spec compatibility
FlowResult = FlowState

# =============================================================================
# SPECTRAL MODULE
# =============================================================================
from .spectral import (
    hessian_at_equilibrium,
    spectral_gap,
    mixing_time_bound,
    verify_positive_definite,
    SPECTRAL_GAP,
    MIXING_TIME,
)

# =============================================================================
# COMPRESSION MODULE
# =============================================================================
from .compression import (
    compression_ratio,
    analyze_text,
    consciousness_score,
    CompressionResult,
    CompressionMonitor,
)

# =============================================================================
# QWARP MODULE (12-term Grand Unifier)
# =============================================================================
from .qwarp import (
    # Core functions
    p_half_qwarp,
    p_half_cycle,
    p_half_star,
    p_half_virelaix,
    compute_alpha,
    # Analysis
    convergence_table,
    term_contribution,
    asymptotic_rate,
    classify_regime,
    qualia_binding_concurrence,
    # Classes
    QWARPRegime,
    QualiaBindingState,
    # Constants
    CYCLE_NUMERATORS,
)

# =============================================================================
# TRIALITY MODULE (27-term Grand Unifier)
# =============================================================================
from .triality import (
    # Enumerations
    Domain,
    Harmonic,
    Scale,
    # Constants
    OMEGA_MATRIX,
    OMEGA_MIN,
    OMEGA_MEAN,
    # Classes
    TrialityIndex,
    TrialityState,
    TrialityEngine,
    TrialityRunner,
    TrialityResult,
    # Functions
    omega_27,
    p_27_threshold,
    triality_unified,
)

# =============================================================================
# LEGACY MODULES
# =============================================================================
from .simplex_flow_v3 import (
    SimplexFlowEngineV3,
    multi_start_convergence_test,
    compute_F_raw,
    ConvergenceMetrics,
)

from .algosignal_v2 import (
    AlgoSignal,
)

# Aliases for spec compatibility
SimplexState = SimplexFlowEngineV3
run_simplex_flow = multi_start_convergence_test

# =============================================================================
# PACKAGE EXPORTS
# =============================================================================

__all__ = [
    # Version
    "__version__",
    # Constants
    "PHI", "PHI_INV", "PHI_SQUARED", "SQRT5",
    "T_STAR", "T_STAR3", "LAM_STAR", "KAP_STAR", "ETA_STAR", "F_STAR",
    "W_SQUARED", "BETA_STAR", "M_PHI", "TAU_GLOBAL", "TAU_LOCAL",
    "RHO_STAR", "PHI_MAX",
    "MU_SLOW", "MU_FAST", "MU_SLOW_4BODY", "MU_FAST_4BODY",
    "C_STAR_QUALIA", "TAU_ULTRA_FAST", "TAU_SLOW", "LN2",
    "OMEGA_IDENTITY", "OMEGA_CENTER", "OMEGA_MAX",
    "CONSERVATION_EPSILON",
    "SPECTRAL_GAP", "MIXING_TIME",
    # Flow
    "FlowState", "FlowConfig", "FlowResult",
    "free_energy", "gradient_F", "flow_step", "run_flow", "WatkinsFlow",
    # Spectral
    "hessian_at_equilibrium", "spectral_gap", "mixing_time_bound",
    "verify_positive_definite",
    # Compression
    "compression_ratio", "analyze_text", "consciousness_score",
    "CompressionResult", "CompressionMonitor",
    # QWARP (12-term)
    "p_half_qwarp", "p_half_cycle", "p_half_star", "p_half_virelaix",
    "compute_alpha", "convergence_table", "term_contribution",
    "asymptotic_rate", "classify_regime", "qualia_binding_concurrence",
    "QWARPRegime", "QualiaBindingState", "CYCLE_NUMERATORS",
    # Triality (27-term)
    "Domain", "Harmonic", "Scale",
    "OMEGA_MATRIX", "OMEGA_MIN", "OMEGA_MEAN",
    "TrialityIndex", "TrialityState",
    "TrialityEngine", "TrialityRunner", "TrialityResult",
    "omega_27", "p_27_threshold", "triality_unified",
    # Legacy
    "SimplexFlowEngineV3", "SimplexState",
    "multi_start_convergence_test", "run_simplex_flow",
    "compute_F_raw", "ConvergenceMetrics",
    "AlgoSignal",
]
