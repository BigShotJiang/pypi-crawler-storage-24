"""CLI entry point — argument parsing and command dispatch."""

from __future__ import annotations

import os
import sys
from pathlib import Path

from dx import __version__
from dx.compose import ComposeCatalog
from dx.output import error


def _find_repo_root() -> Path:
    """Walk up from CWD to find the repo root (contains docker-compose.infra.yml)."""
    # Check env var first (set by wrapper or user)
    env_root = os.environ.get("DX_REPO_ROOT")
    if env_root:
        return Path(env_root)

    path = Path.cwd()
    while path != path.parent:
        if (path / "docker-compose.infra.yml").exists():
            return path
        path = path.parent

    # Fallback: assume CWD is repo root
    return Path.cwd()


USAGE = """\
dx — developer experience CLI for Docker Compose projects

Usage: dx <command> [targets...]

Docker lifecycle:
  up [targets...] [--logs]  Start services (prod mode), optionally tail logs
  dev [targets...] [--logs] Start services (dev mode + hot-reload), optionally tail logs
  down [targets...]        Stop and remove containers
  restart [targets...]     Restart containers
  reset [targets...]       Stop + wipe volumes
  ps                       Show running containers
  logs [targets...]        Stream container logs
  pull [targets...]        Pull images
  reload <service>         Recompile Java service for DevTools restart

Build / Test / Lint:
  build [targets...]       Build services ("all", "common", or names)
  test [targets...]        Run tests ("all" or service names)
  lint [targets...]        Run linters ("all", "frontend", "python")

Port management:
  ports                    Show port assignments
  ports pin <svc> <port>   Pin a service to a specific port
  ports reset [service]    Clear port reservations

Proxy:
  proxy start              Start reverse proxy daemon on :7355
  proxy stop               Stop reverse proxy
  hosts                    Show DNS resolution status
  hosts setup              Add *.dx.localhost entries (/etc/hosts)
  hosts remove             Remove all dx DNS entries

Dev utilities:
  vite start|stop|logs     Manage vite dev server as a daemon

Scaffolding:
  generate python <name>   Scaffold a new Python/FastAPI service
  generate java <name>     Scaffold a new Java/Spring Boot service

Project health:
  doctor                   Check project structure, Dockerfiles, and conventions
  doctor --fix             Auto-fix issues in compose files and Dockerfiles

Setup:
  init                     Initialize ClickStack/HyperDX
  validate                 Run harness validation
  list [group]             List services by group

Targets can be group names (infra, services, apps), service names,
glob patterns (service-d*), or shorthand (data, frontend, ai).
"""


def main(argv: list[str] | None = None) -> None:
    args = argv if argv is not None else sys.argv[1:]

    if not args or args[0] in ("-h", "--help", "help"):
        print(USAGE.strip())
        sys.exit(0)

    if args[0] in ("-V", "--version"):
        print(f"dx {__version__}")
        sys.exit(0)

    command = args[0]
    rest = args[1:]

    root = _find_repo_root()
    catalog = ComposeCatalog(root)

    from dx import commands as cmd

    from dx.doctor import cmd_doctor
    from dx.generate import cmd_generate

    dispatch = {
        "up": lambda: cmd.cmd_up(catalog, rest),
        "dev": lambda: cmd.cmd_dev(catalog, rest),
        "down": lambda: cmd.cmd_down(catalog, rest),
        "restart": lambda: cmd.cmd_restart(catalog, rest),
        "reset": lambda: cmd.cmd_reset(catalog, rest),
        "ps": lambda: cmd.cmd_ps(catalog),
        "logs": lambda: cmd.cmd_logs(catalog, rest),
        "pull": lambda: cmd.cmd_pull(catalog, rest),
        "reload": lambda: cmd.cmd_reload(catalog, rest),
        "build": lambda: cmd.cmd_build(catalog, rest),
        "test": lambda: cmd.cmd_test(catalog, rest),
        "lint": lambda: cmd.cmd_lint(catalog, rest),
        "init": lambda: cmd.cmd_init(catalog),
        "validate": lambda: cmd.cmd_validate(catalog),
        "list": lambda: cmd.cmd_list(catalog, rest),
        "ports": lambda: cmd.cmd_ports(catalog, rest),
        "proxy": lambda: cmd.cmd_proxy(catalog, rest),
        "hosts": lambda: cmd.cmd_hosts(catalog, rest),
        "vite": lambda: cmd.cmd_vite(catalog, rest[0] if rest else ""),
        "doctor": lambda: cmd_doctor(catalog, fix="--fix" in rest),
        "generate": lambda: cmd_generate(catalog, rest),
    }

    handler = dispatch.get(command)
    if not handler:
        error(f"Unknown command: {command}")
        print("\nRun 'dx help' for usage.", file=sys.stderr)
        sys.exit(1)

    try:
        handler()
    except KeyboardInterrupt:
        sys.exit(130)
