"""Docker Compose service catalog and group expansion.

Replaces scripts/expand-groups.py with a richer model that understands
compose file layering, dev overlays, and target resolution.

Project-agnostic: discovers everything from compose files and filesystem.
"""

from __future__ import annotations

import fnmatch
import re
from pathlib import Path

# ---------------------------------------------------------------------------
# Compose file layout (convention-based, same across projects)
# ---------------------------------------------------------------------------

COMPOSE_FILES: dict[str, str] = {
    "infra": "docker-compose.infra.yml",
    "services": "docker-compose.services.yml",
    "apps": "docker-compose.apps.yml",
}

DEV_OVERLAYS: dict[str, str] = {
    "services": "docker-compose.dev.services.yml",
    "apps": "docker-compose.dev.apps.yml",
}

GROUP_ALIASES: dict[str, str] = {
    "service": "services",
    "app": "apps",
    "infrastructure": "infra",
}

# Naming convention: compose service name -> directory
# service-<slug>     -> services/<slug>/
# app-<slug>         -> apps/<slug>/
# infra-<slug>       -> (no source dir expected)
GROUP_PREFIXES: dict[str, str] = {
    "infra": "infra-",
    "services": "service-",
    "apps": "app-",
}


# ---------------------------------------------------------------------------
# Minimal YAML parsing helpers (no PyYAML dependency)
# ---------------------------------------------------------------------------


class ComposeFileInfo:
    """Parsed info from a single compose file."""

    def __init__(self) -> None:
        self.service_names: list[str] = []
        self.build_contexts: dict[str, Path] = {}  # service -> resolved dir
        self.port_mappings: dict[
            str, list[tuple[str, str]]
        ] = {}  # service -> [(host, container)]


def _parse_compose_file(path: Path) -> ComposeFileInfo:
    """Single-pass extraction of service names, build contexts, and port mappings."""
    info = ComposeFileInfo()
    if not path.exists():
        return info

    root = path.parent
    lines = path.read_text().splitlines()
    current_service: str | None = None
    in_services = False
    in_build = False
    in_ports = False
    build_context: str | None = None
    build_dockerfile: str | None = None
    current_ports: list[tuple[str, str]] = []

    def _flush_service() -> None:
        nonlocal in_build, in_ports, build_context, build_dockerfile, current_ports
        if current_service:
            # Build context
            if build_context:
                ctx_path = (root / build_context).resolve()
                if build_context in (".", "./") and build_dockerfile:
                    df_dir = (root / build_dockerfile).resolve().parent
                    if df_dir != root.resolve():
                        info.build_contexts[current_service] = df_dir
                    else:
                        info.build_contexts[current_service] = ctx_path
                else:
                    info.build_contexts[current_service] = ctx_path
            # Ports
            if current_ports:
                info.port_mappings[current_service] = list(current_ports)
        in_build = False
        in_ports = False
        build_context = None
        build_dockerfile = None
        current_ports = []

    for line in lines:
        stripped = line.rstrip()

        if stripped == "services:":
            in_services = True
            continue
        if not in_services:
            continue
        # Top-level key ends services block
        if stripped and not stripped.startswith("#") and not line[0].isspace():
            _flush_service()
            break

        # Service-level key (2-space indent)
        m = re.match(r"^  ([a-zA-Z0-9][a-zA-Z0-9_-]*):\s*(?:#.*)?$", line)
        if m:
            _flush_service()
            current_service = m.group(1)
            info.service_names.append(current_service)
            continue

        if not current_service:
            continue

        # 4-space keys (service properties)
        if re.match(r"^    [a-z]", line) and not re.match(r"^      ", line):
            # New service property — end any open block
            in_build = False
            in_ports = False

            if re.match(r"^    build:\s*$", line):
                in_build = True
                continue
            if re.match(r"^    ports:\s*$", line):
                in_ports = True
                continue

        # Inside build block (6-space indent)
        if in_build:
            ctx_m = re.match(r"^\s+context:\s+(.+)$", line)
            if ctx_m:
                build_context = ctx_m.group(1).strip().strip('"').strip("'")
            df_m = re.match(r"^\s+dockerfile:\s+(.+)$", line)
            if df_m:
                build_dockerfile = df_m.group(1).strip().strip('"').strip("'")

        # Inside ports block (6-space indent, list items)
        if in_ports:
            port_m = re.match(
                r'^\s+-\s+"?(\$\{[^}]+\}|[\d]+):([\d]+)"?\s*(?:#.*)?$', line
            )
            if port_m:
                current_ports.append((port_m.group(1), port_m.group(2)))

    _flush_service()
    return info


# ---------------------------------------------------------------------------
# Port env var helpers
# ---------------------------------------------------------------------------


def port_env_var(service_name: str) -> str:
    """Convert service name to PORT env var: service-data -> SERVICE_DATA_PORT."""
    return service_name.upper().replace("-", "_") + "_PORT"


def is_hardcoded_port(host_expr: str) -> bool:
    """Check if a host port expression is a hardcoded number (not an env var)."""
    return host_expr.isdigit()


def make_port_env_expr(service_name: str, default_port: str) -> str:
    """Build a ${VAR:-default} expression for a service port."""
    var = port_env_var(service_name)
    return f"${{{var}:-{default_port}}}"


# ---------------------------------------------------------------------------
# Service type detection
# ---------------------------------------------------------------------------


def detect_service_type(directory: Path) -> str | None:
    """Detect the type of a service from its directory contents."""
    if not directory.is_dir():
        return None
    if (directory / "pom.xml").exists():
        return "java"
    if (directory / "pyproject.toml").exists() or (
        directory / "requirements.txt"
    ).exists():
        return "python"
    if (directory / "package.json").exists():
        return "node"
    return None


def _find_service_dir(
    root: Path, service_name: str, group: str, build_contexts: dict[str, Path]
) -> Path | None:
    """Find the source directory for a compose service.

    Strategy (in order):
    1. Use build.context from compose file (authoritative)
    2. Convention: strip group prefix, look in group parent dir
       e.g. service-data -> services/data, app-fleet-ui -> apps/fleet-ui
    3. Aggressive stripping (prefix + suffix like -api, -ui)
    """
    # 1. Build context from compose file
    if service_name in build_contexts:
        path = build_contexts[service_name]
        if path.is_dir():
            return path

    # 2. Convention-based lookup
    expected_prefix = GROUP_PREFIXES.get(group, "")
    parent_dirs = {
        "infra": [],  # infra services typically don't have source dirs
        "services": ["services"],
        "apps": ["apps"],
    }
    parents = parent_dirs.get(group, ["services", "apps"])

    if expected_prefix and service_name.startswith(expected_prefix):
        slug = service_name[len(expected_prefix) :]
        for parent in parents:
            candidate = root / parent / slug
            if candidate.is_dir():
                return candidate

    # 3. Fallback: try stripping any common prefix/suffix
    all_parents = ("services", "apps")

    # Direct match
    for parent in all_parents:
        candidate = root / parent / service_name
        if candidate.is_dir():
            return candidate

    # Strip prefix only
    for prefix in ("service-", "app-", "frontend-"):
        if service_name.startswith(prefix):
            stripped = service_name[len(prefix) :]
            for parent in all_parents:
                candidate = root / parent / stripped
                if candidate.is_dir():
                    return candidate

    # Strip suffix only, then both
    for suffix in ("-api", "-ui", "-worker"):
        if service_name.endswith(suffix):
            no_suffix = service_name[: -len(suffix)]
            for parent in all_parents:
                if (root / parent / no_suffix).is_dir():
                    return root / parent / no_suffix
            # Strip prefix + suffix
            for prefix in ("service-", "app-", "frontend-"):
                if no_suffix.startswith(prefix):
                    slug = no_suffix[len(prefix) :]
                    for parent in all_parents:
                        if (root / parent / slug).is_dir():
                            return root / parent / slug

    return None


# ---------------------------------------------------------------------------
# Catalog
# ---------------------------------------------------------------------------


class ServiceInfo:
    """Info about a discovered service."""

    __slots__ = (
        "name",
        "group",
        "directory",
        "service_type",
        "container_port",
        "_root",
    )

    def __init__(
        self,
        name: str,
        group: str,
        directory: Path | None,
        service_type: str | None,
        root: Path | None = None,
        container_port: str | None = None,
    ) -> None:
        self.name = name
        self.group = group
        self.directory = directory
        self.service_type = service_type
        self.container_port = container_port  # the internal port (e.g. "8084")
        self._root = root

    @property
    def relative_dir(self) -> str:
        """Return directory path relative to repo root."""
        if self.directory and self._root:
            try:
                return str(self.directory.relative_to(self._root))
            except ValueError:
                return str(self.directory)
        return ""

    @property
    def expected_name(self) -> str | None:
        """What this service's compose name should be per our naming convention.

        Convention: <group-prefix><dir-slug>
          services/data       -> service-data
          apps/fleet-plane-ui -> app-fleet-plane-ui
          services/ai         -> service-ai
        """
        if not self.directory or not self._root:
            return None
        prefix = GROUP_PREFIXES.get(self.group, "")
        try:
            rel = self.directory.relative_to(self._root)
            # Take the last component (directory name)
            slug = rel.parts[-1] if rel.parts else None
            if slug:
                return f"{prefix}{slug}"
        except ValueError:
            pass
        return None


class ComposeCatalog:
    """Knows every compose service, which group it belongs to, and how to
    build the right `docker compose -f ... -f ...` command for any target set.

    Project-agnostic: discovers services from compose files and detects
    types from the filesystem.
    """

    def __init__(self, repo_root: Path) -> None:
        self.root = repo_root
        self.groups: dict[str, list[str]] = {}
        self.service_to_group: dict[str, str] = {}
        self.all_services: list[str] = []
        self.service_info: dict[str, ServiceInfo] = {}
        self._aliases: dict[str, str] = {}
        self._port_mappings: dict[str, list[tuple[str, str]]] = {}  # raw port tuples
        self._load()

    def _load(self) -> None:
        # First pass: parse all compose files
        parsed: dict[str, ComposeFileInfo] = {}
        build_contexts: dict[str, Path] = {}
        port_mappings: dict[str, list[tuple[str, str]]] = {}
        for group, filename in COMPOSE_FILES.items():
            path = self.root / filename
            ci = _parse_compose_file(path)
            parsed[group] = ci
            build_contexts.update(ci.build_contexts)
            port_mappings.update(ci.port_mappings)

        self._port_mappings = port_mappings

        # Second pass: build catalog
        for group, filename in COMPOSE_FILES.items():
            ci = parsed[group]
            self.groups[group] = ci.service_names
            for name in ci.service_names:
                self.service_to_group[name] = group
                directory = _find_service_dir(self.root, name, group, build_contexts)
                svc_type = detect_service_type(directory) if directory else None
                # Extract the first container port if available
                ports = port_mappings.get(name, [])
                container_port = ports[0][1] if ports else None
                self.service_info[name] = ServiceInfo(
                    name,
                    group,
                    directory,
                    svc_type,
                    self.root,
                    container_port,
                )
            self.all_services.extend(ci.service_names)

        # Auto-generate shorthand aliases by stripping common prefixes
        alias_counts: dict[str, list[str]] = {}
        for name in self.all_services:
            for prefix in ("service-", "app-", "frontend-", "infra-"):
                if name.startswith(prefix):
                    alias = name[len(prefix) :]
                    alias_counts.setdefault(alias, []).append(name)

        for alias, names in alias_counts.items():
            if len(names) == 1:
                self._aliases[alias] = names[0]

    # ------------------------------------------------------------------
    # Target resolution
    # ------------------------------------------------------------------

    def resolve(self, targets: list[str]) -> list[str]:
        """Resolve target strings to a flat list of service names."""
        if not targets:
            return list(self.all_services)

        result: list[str] = []
        seen: set[str] = set()

        def _add(name: str) -> None:
            if name not in seen:
                seen.add(name)
                result.append(name)

        for target in targets:
            if target == "all":
                for name in self.all_services:
                    _add(name)
                continue

            # Group alias
            canonical = GROUP_ALIASES.get(target, target)
            if canonical in self.groups:
                for name in self.groups[canonical]:
                    _add(name)
                continue

            # Exact service name
            if target in self.service_to_group:
                _add(target)
                continue

            # Auto-generated shorthand alias
            if target in self._aliases:
                _add(self._aliases[target])
                continue

            # Glob / regex pattern
            if any(ch in target for ch in "*?[]{}+\\^$.()|"):
                matched = self._match_pattern(target)
                for name in matched:
                    _add(name)
                continue

            # Pass through
            _add(target)

        return result

    def _match_pattern(self, pattern: str) -> list[str]:
        """Match a glob or regex pattern against all service names."""
        if any(ch in pattern for ch in "[](){}+\\^$.|"):
            try:
                compiled = re.compile(f"^{pattern}$")
                return [s for s in self.all_services if compiled.match(s)]
            except re.error:
                pass
        return fnmatch.filter(self.all_services, pattern)

    # ------------------------------------------------------------------
    # Service introspection
    # ------------------------------------------------------------------

    def buildable_services(self, targets: list[str]) -> list[ServiceInfo]:
        """Return ServiceInfo for resolved targets that have a detected type."""
        services = self.resolve(targets)
        return [
            self.service_info[s]
            for s in services
            if s in self.service_info and self.service_info[s].service_type
        ]

    def services_of_type(self, svc_type: str) -> list[ServiceInfo]:
        """Return all services of a given type (java, python, node)."""
        return [si for si in self.service_info.values() if si.service_type == svc_type]

    # ------------------------------------------------------------------
    # Compose command building
    # ------------------------------------------------------------------

    def compose_file_args(self, services: list[str], dev: bool = False) -> list[str]:
        """Return the minimal `-f file [-f overlay]` args needed for a set of services.

        Always includes infra if services or apps are needed, because
        compose services commonly depend on infra services.
        """
        needed_groups: set[str] = set()
        for svc in services:
            group = self.service_to_group.get(svc)
            if group:
                needed_groups.add(group)

        if not needed_groups:
            needed_groups = set(COMPOSE_FILES.keys())

        # Always include infra when services or apps are targeted (depends_on)
        if needed_groups & {"services", "apps"}:
            needed_groups.add("infra")

        args: list[str] = []
        for group in ("infra", "services", "apps"):
            if group not in needed_groups:
                continue
            path = self.root / COMPOSE_FILES[group]
            if path.exists():
                args.extend(["-f", str(path)])
                if dev and group in DEV_OVERLAYS:
                    overlay = self.root / DEV_OVERLAYS[group]
                    if overlay.exists():
                        args.extend(["-f", str(overlay)])
        return args

    def compose_cmd(
        self,
        services: list[str],
        *docker_args: str,
        dev: bool = False,
    ) -> list[str]:
        """Build a full `docker compose -f ... <docker_args> [services...]` command."""
        file_args = self.compose_file_args(services, dev=dev)
        cmd = ["docker", "compose"] + file_args + list(docker_args)
        if set(services) != set(self.all_services):
            cmd.extend(services)
        return cmd

    def all_compose_file_args(self, dev: bool = False) -> list[str]:
        """Return -f args for ALL compose files."""
        return self.compose_file_args(self.all_services, dev=dev)

    def has_service(self, name: str) -> bool:
        """Check if a service exists in the catalog."""
        return name in self.service_to_group
