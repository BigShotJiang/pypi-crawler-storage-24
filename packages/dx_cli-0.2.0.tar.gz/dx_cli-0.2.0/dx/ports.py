"""Port allocation, persistence, and reverse proxy.

Replaces dockportless.py — auto-assigns free host ports to compose services,
persists assignments, and optionally runs a reverse proxy.
"""

from __future__ import annotations

import json
import os
import signal
import socket
import subprocess
import sys
from http.client import HTTPConnection
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from socketserver import ThreadingMixIn
from typing import Any

from dx.output import info, warn, error, success, table, header

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

PROXY_PORT = 7355
MAX_PORT_RETRIES = 100


# ---------------------------------------------------------------------------
# Port allocation
# ---------------------------------------------------------------------------


def is_port_free(port: int) -> bool:
    """Check if a port is available to bind."""
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", port))
        sock.close()
        return True
    except OSError:
        return False


def allocate_port(reserved: set[int]) -> int:
    """Allocate a single free port by binding to :0, avoiding reserved ports."""
    for _ in range(MAX_PORT_RETRIES):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
        sock.close()
        if port not in reserved:
            return port
    raise RuntimeError("Failed to allocate a free port after retries")


# ---------------------------------------------------------------------------
# Persistent port reservations
# ---------------------------------------------------------------------------


class PortManager:
    """Manages persistent port reservations for compose services."""

    def __init__(self, state_dir: Path) -> None:
        self.state_dir = state_dir
        self.reservations_file = state_dir / "ports.json"

    def _read(self) -> dict[str, dict]:
        """Read reservations: {service_name: {"port": int, "pinned": bool}}."""
        if not self.reservations_file.exists():
            return {}
        try:
            return json.loads(self.reservations_file.read_text())
        except (json.JSONDecodeError, OSError):
            return {}

    def _write(self, data: dict[str, dict]) -> None:
        self.state_dir.mkdir(parents=True, exist_ok=True)
        self.reservations_file.write_text(json.dumps(data, indent=2) + "\n")

    def resolve(self, service_names: list[str]) -> dict[str, int]:
        """Resolve ports for services. Reuses persistent assignments when possible."""
        reservations = self._read()
        all_reserved = {r["port"] for r in reservations.values()}
        result: dict[str, int] = {}

        for name in service_names:
            existing = reservations.get(name)

            if existing and existing.get("pinned"):
                port = existing["port"]
                if not is_port_free(port):
                    error(f"Pinned port {port} for {name} is in use by another process")
                    sys.exit(1)
                result[name] = port
            elif existing and is_port_free(existing["port"]):
                result[name] = existing["port"]
            else:
                port = allocate_port(all_reserved)
                result[name] = port
                all_reserved.add(port)
                reservations[name] = {"port": port, "pinned": False}

            if name not in reservations:
                reservations[name] = {"port": result[name], "pinned": False}

        self._write(reservations)
        return result

    def pin(self, service: str, port: int) -> None:
        """Pin a service to a specific port."""
        reservations = self._read()
        for k, v in reservations.items():
            if v["port"] == port and k != service:
                error(f"Port {port} is already reserved by {k}")
                sys.exit(1)
        reservations[service] = {"port": port, "pinned": True}
        self._write(reservations)
        success(f"Pinned {service} -> :{port}")

    def clear(self, service: str | None = None) -> None:
        """Clear reservations."""
        if service:
            reservations = self._read()
            if service in reservations:
                del reservations[service]
                self._write(reservations)
                success(f"Cleared reservation for {service}")
            else:
                warn(f"No reservation found for {service}")
        else:
            self._write({})
            success("Cleared all port reservations")

    def status(self, catalog: Any = None) -> None:
        """Print all port reservations, optionally grouped by compose group."""
        reservations = self._read()
        if not reservations:
            info("No port reservations.")
            return

        header("Port Reservations")
        rows = []
        for name, data in sorted(reservations.items()):
            pinned = " (pinned)" if data.get("pinned") else ""
            group = ""
            if catalog:
                g = catalog.service_to_group.get(name, "")
                if g:
                    group = g
            rows.append([name, str(data["port"]), group, pinned])
        if catalog:
            table(rows, headers=["Service", "Port", "Group", "Status"])
        else:
            table(
                [[r[0], r[1], r[3]] for r in rows],
                headers=["Service", "Port", "Status"],
            )

    def write_env_file(self, ports: dict[str, int], env_path: Path) -> None:
        """Write port assignments as VAR=<port> to an env file.

        If the key already looks like an env var (uppercase with _PORT suffix),
        use it directly. Otherwise, convert from service-name to SERVICE_NAME_PORT.
        """
        env_path.parent.mkdir(parents=True, exist_ok=True)
        lines = []
        for name, port in sorted(ports.items()):
            if name == name.upper() and "_" in name:
                # Already an env var name (e.g. CLICKSTACK_APP_8080_PORT)
                var = name
            else:
                var = name.upper().replace("-", "_") + "_PORT"
            lines.append(f"{var}={port}")
        env_path.write_text("\n".join(lines) + "\n")


# ---------------------------------------------------------------------------
# Reverse proxy
# ---------------------------------------------------------------------------


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


class ProxyHandler(BaseHTTPRequestHandler):
    """Route requests to the right service port.

    Supports two routing modes:
      1. Host-based: <service>.dx.localhost:7355/path  (browsers resolve *.localhost)
      2. Path-based: localhost:7355/<service>/path       (works everywhere, no DNS needed)
    """

    port_manager: PortManager | None = None

    def _resolve_service(self) -> tuple[str | None, str]:
        """Resolve service name and rewritten path from the request.

        Returns (service_name, forwarded_path). service_name is None on error.
        """
        # 1. Try host-based routing: <service>.dx.localhost
        host = self.headers.get("Host", "")
        if ":" in host:
            host = host.split(":")[0]

        parts = host.replace(".localhost", "").split(".")
        if len(parts) >= 2 and parts[-1] == "dx":
            service_name = ".".join(parts[:-1])
            return service_name, self.path

        # 2. Try path-based routing: /<service>/rest/of/path
        path_parts = self.path.lstrip("/").split("/", 1)
        if path_parts and path_parts[0]:
            candidate = path_parts[0]
            if self.port_manager:
                reservations = self.port_manager._read()
                if candidate in reservations:
                    rest = "/" + path_parts[1] if len(path_parts) > 1 else "/"
                    return candidate, rest

        return None, self.path

    def _proxy(self) -> None:
        if not self.port_manager:
            self.send_error(500, "Proxy not configured")
            return

        service_name, forward_path = self._resolve_service()
        if not service_name:
            # Show available services as help
            reservations = self.port_manager._read()
            services = ", ".join(sorted(reservations.keys()))
            self.send_error(
                404,
                f"Could not resolve service. Use:\n"
                f"  http://localhost:{PROXY_PORT}/<service>/...\n"
                f"  http://<service>.dx.localhost:{PROXY_PORT}/...\n"
                f"Available: {services}",
            )
            return

        reservations = self.port_manager._read()
        entry = reservations.get(service_name)
        if not entry:
            self.send_error(404, f"Service not found: {service_name}")
            return

        port = entry["port"]
        try:
            content_length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_length) if content_length > 0 else None

            conn = HTTPConnection("127.0.0.1", port, timeout=30)
            conn.request(
                self.command, forward_path, body=body, headers=dict(self.headers)
            )
            resp = conn.getresponse()

            self.send_response(resp.status)
            for key, val in resp.getheaders():
                if key.lower() not in ("transfer-encoding",):
                    self.send_header(key, val)
            self.end_headers()
            self.wfile.write(resp.read())
            conn.close()
        except Exception as e:
            self.send_error(502, f"Bad Gateway: {e}")

    do_GET = _proxy
    do_POST = _proxy
    do_PUT = _proxy
    do_DELETE = _proxy
    do_PATCH = _proxy
    do_HEAD = _proxy
    do_OPTIONS = _proxy

    def log_message(self, format: str, *args: Any) -> None:
        pass


def start_proxy_foreground(port_manager: PortManager) -> None:
    """Start the proxy in the foreground (blocking)."""
    ProxyHandler.port_manager = port_manager
    try:
        server = ThreadedHTTPServer(("0.0.0.0", PROXY_PORT), ProxyHandler)
    except OSError:
        error(f"Port {PROXY_PORT} already in use (proxy already running?)")
        sys.exit(1)

    info(f"Proxy listening on :{PROXY_PORT}")
    info("Route: <service>.dx.localhost:{PROXY_PORT} -> service port")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        server.shutdown()


def start_proxy_daemon(state_dir: Path) -> None:
    """Start the proxy as a background daemon."""
    pid_file = state_dir / "proxy.pid"

    # Check if already running
    if pid_file.exists():
        try:
            pid = int(pid_file.read_text().strip())
            os.kill(pid, 0)
            info(f"Proxy already running (PID {pid})")
            return
        except (OSError, ValueError):
            pid_file.unlink(missing_ok=True)

    # Spawn a new process that runs the proxy
    proc = subprocess.Popen(
        [sys.executable, "-m", "dx", "proxy", "--foreground"],
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )
    pid_file.parent.mkdir(parents=True, exist_ok=True)
    pid_file.write_text(str(proc.pid))
    success(f"Proxy started (PID {proc.pid}) on :{PROXY_PORT}")


def stop_proxy_daemon(state_dir: Path) -> None:
    """Stop the proxy daemon."""
    pid_file = state_dir / "proxy.pid"
    if not pid_file.exists():
        warn("No proxy PID file found")
        return

    try:
        pid = int(pid_file.read_text().strip())
        os.kill(pid, signal.SIGTERM)
        success(f"Proxy stopped (PID {pid})")
    except (OSError, ValueError) as e:
        warn(f"Could not stop proxy: {e}")
    finally:
        pid_file.unlink(missing_ok=True)


# ---------------------------------------------------------------------------
# DNS / hosts setup for *.dx.localhost resolution
# ---------------------------------------------------------------------------

HOSTS_MARKER = "# dx-proxy"
HOSTS_FILE = Path("/etc/hosts")


def _is_macos() -> bool:
    return sys.platform == "darwin"


def _sudo_write(path: Path, content: str) -> bool:
    """Write a file using sudo. Returns True on success."""
    try:
        subprocess.run(
            ["sudo", "tee", str(path)],
            input=content.encode(),
            stdout=subprocess.DEVNULL,
            check=True,
        )
        return True
    except (subprocess.CalledProcessError, FileNotFoundError):
        return False


def hosts_setup(service_names: list[str]) -> None:
    """Set up DNS so <service>.dx.localhost resolves to 127.0.0.1.

    Adds individual entries to /etc/hosts for each known service.
    Also adds a bare `dx.localhost` entry for the proxy root.
    """
    _hosts_setup_hosts_file(service_names)


def _hosts_setup_hosts_file(service_names: list[str]) -> None:
    """Add *.dx.localhost entries to /etc/hosts for known services."""
    try:
        current = HOSTS_FILE.read_text()
    except PermissionError:
        error(f"Cannot read {HOSTS_FILE}")
        return

    # Remove old dx entries
    lines = [line for line in current.splitlines() if HOSTS_MARKER not in line]

    # Always add the bare proxy root
    lines.append(f"127.0.0.1  dx.localhost  {HOSTS_MARKER}")

    # Add per-service entries
    for name in sorted(service_names):
        lines.append(f"127.0.0.1  {name}.dx.localhost  {HOSTS_MARKER}")

    new_content = "\n".join(lines) + "\n"

    if new_content == current:
        success("DNS entries already up to date in /etc/hosts")
        return

    info(f"Updating {HOSTS_FILE} (requires sudo)")
    if _sudo_write(HOSTS_FILE, new_content):
        count = sum(1 for line in new_content.splitlines() if HOSTS_MARKER in line)
        success(f"Added {count} DNS entries to {HOSTS_FILE}")
        # Flush DNS cache on macOS
        if _is_macos():
            subprocess.run(["sudo", "dscacheutil", "-flushcache"], check=False)
            subprocess.run(["sudo", "killall", "-HUP", "mDNSResponder"], check=False)
            info("DNS cache flushed")
    else:
        error(f"Failed to write to {HOSTS_FILE}")


def hosts_remove() -> None:
    """Remove all dx DNS entries from /etc/hosts."""
    changed = False

    # Clean /etc/hosts
    try:
        current = HOSTS_FILE.read_text()
    except PermissionError:
        error(f"Cannot read {HOSTS_FILE}")
        return

    lines = current.splitlines()
    clean_lines = [line for line in lines if HOSTS_MARKER not in line]

    if len(clean_lines) < len(lines):
        new_content = "\n".join(clean_lines) + "\n"
        info(f"Cleaning {HOSTS_FILE} (requires sudo)")
        if _sudo_write(HOSTS_FILE, new_content):
            removed = len(lines) - len(clean_lines)
            success(f"Removed {removed} DNS entries from {HOSTS_FILE}")
            changed = True
            if _is_macos():
                subprocess.run(["sudo", "dscacheutil", "-flushcache"], check=False)
                subprocess.run(
                    ["sudo", "killall", "-HUP", "mDNSResponder"], check=False
                )
        else:
            error(f"Failed to write to {HOSTS_FILE}")

    if not changed:
        info("No DNS entries to remove")


def hosts_status() -> None:
    """Show current DNS setup status."""
    header("DNS Status")

    # Check /etc/hosts
    try:
        current = HOSTS_FILE.read_text()
        dx_lines = [line for line in current.splitlines() if HOSTS_MARKER in line]
        if dx_lines:
            success(f"/etc/hosts: {len(dx_lines)} dx entries")
            for line in dx_lines:
                print(f"    {line.replace(HOSTS_MARKER, '').strip()}")
        else:
            info("/etc/hosts: no dx entries")
    except PermissionError:
        warn(f"Cannot read {HOSTS_FILE}")

    # Test resolution
    print()
    test_host = "test.dx.localhost"
    try:
        addr = socket.getaddrinfo(test_host, None, socket.AF_INET)
        ip = addr[0][4][0]
        if ip == "127.0.0.1":
            success(f"DNS resolution: {test_host} -> {ip}")
        else:
            warn(f"DNS resolution: {test_host} -> {ip} (expected 127.0.0.1)")
    except socket.gaierror:
        info(f"DNS resolution: {test_host} does not resolve")
        info("Run 'dx hosts setup' to configure, or use path-based routing:")
        info(f"  http://localhost:{PROXY_PORT}/<service>/...")
