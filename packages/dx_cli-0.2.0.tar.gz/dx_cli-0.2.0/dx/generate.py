"""dx generate — scaffold new Python or Java services from project templates.

Usage:
    dx generate python <name>          Scaffold a new Python/FastAPI service
    dx generate java <name>            Scaffold a new Java/Spring Boot service
    dx generate python <name> --port 8093   Specify a custom port

The generated service includes:
  - Source code skeleton (FastAPI app or Spring Boot app)
  - Dockerfile + Dockerfile.dev (if Java)
  - pyproject.toml / pom.xml
  - CLAUDE.md agent guide
  - Entries in docker-compose.services.yml and docker-compose.dev.services.yml
"""

from __future__ import annotations

import re
import sys
from pathlib import Path

from dx.compose import COMPOSE_FILES, DEV_OVERLAYS, ComposeCatalog
from dx.output import info, warn, error, success, header


# ---------------------------------------------------------------------------
# Port allocation — find the next free port based on existing services
# ---------------------------------------------------------------------------


def _next_port(catalog: ComposeCatalog, service_type: str) -> int:
    """Find the next available port based on existing services."""
    used_ports: set[int] = set()
    for si in catalog.service_info.values():
        if si.container_port:
            try:
                used_ports.add(int(si.container_port))
            except ValueError:
                pass

    # Start from conventional ranges
    if service_type == "python":
        start = 8090
    else:
        start = 8080

    port = start
    while port in used_ports:
        port += 1
    return port


# ---------------------------------------------------------------------------
# Name helpers
# ---------------------------------------------------------------------------


def _to_class_name(slug: str) -> str:
    """Convert a slug like 'data-processing' to 'DataProcessing'."""
    return "".join(part.capitalize() for part in slug.split("-"))


def _to_package_name(slug: str) -> str:
    """Convert a slug like 'data-processing' to 'dataprocessing' (Java package)."""
    return slug.replace("-", "")


# ---------------------------------------------------------------------------
# Python service templates
# ---------------------------------------------------------------------------


def _generate_python(root: Path, slug: str, port: int) -> None:
    """Scaffold a Python/FastAPI service."""
    svc_dir = root / "services" / slug

    if svc_dir.exists():
        error(f"Directory already exists: services/{slug}/")
        sys.exit(1)

    compose_name = f"service-{slug}"
    info(f"Generating Python service: {compose_name}")
    info(f"  Directory: services/{slug}/")
    info(f"  Port: {port}")

    # Create directory structure
    src_dir = svc_dir / "src"
    api_dir = src_dir / "api"
    tests_dir = svc_dir / "tests"

    for d in (src_dir, api_dir, tests_dir):
        d.mkdir(parents=True, exist_ok=True)

    # pyproject.toml
    (svc_dir / "pyproject.toml").write_text(f"""\
[project]
name = "{slug}"
version = "0.1.0"
description = ""
requires-python = ">=3.11"
dependencies = [
    "fastapi>=0.115.0,<1",
    "uvicorn[standard]>=0.30.0,<1",
    "pydantic-settings>=2.0.0,<3",
]

[tool.pytest.ini_options]
testpaths = ["tests"]
python_files = ["test_*.py"]
python_functions = ["test_*"]
addopts = "-v --tb=short"

[tool.ruff]
target-version = "py311"
line-length = 120

[tool.ruff.lint]
select = ["E", "F", "I", "W"]

[tool.ruff.format]
quote-style = "double"
""")

    # src/__init__.py
    (src_dir / "__init__.py").write_text("")

    # src/config.py
    (src_dir / "config.py").write_text(f"""\
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_port: int = {port}
    app_host: str = "0.0.0.0"
    log_level: str = "INFO"

    class Config:
        env_prefix = ""
        case_sensitive = False


settings = Settings()
""")

    # src/main.py
    title = slug.replace("-", " ").title() + " Service"
    (src_dir / "main.py").write_text(f"""\
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from src.api.health import router as health_router
from src.config import settings

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("Starting {title}...")
    yield
    logger.info("Shutting down {title}...")


app = FastAPI(
    title="{title}",
    version="0.1.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health_router)
""")

    # src/api/__init__.py
    (api_dir / "__init__.py").write_text("")

    # src/api/health.py
    (api_dir / "health.py").write_text("""\
from fastapi import APIRouter

router = APIRouter()


@router.get("/health")
async def health():
    return {"status": "ok"}
""")

    # tests/__init__.py
    (tests_dir / "__init__.py").write_text("")

    # tests/test_health.py
    (tests_dir / "test_health.py").write_text("""\
from fastapi.testclient import TestClient

from src.main import app

client = TestClient(app)


def test_health():
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok"}
""")

    # Dockerfile
    (svc_dir / "Dockerfile").write_text(f"""\
FROM python:3.11-slim

WORKDIR /app

ENV PYTHONDONTWRITEBYTECODE=1
ENV PYTHONUNBUFFERED=1

COPY --from=ghcr.io/astral-sh/uv:latest /uv /uvx /bin/

COPY pyproject.toml uv.lock ./
RUN uv sync --frozen --no-dev

COPY src ./src

EXPOSE {port}

CMD ["uv", "run", "uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "{port}"]
""")

    # CLAUDE.md
    (svc_dir / "CLAUDE.md").write_text(f"""\
# {title} — Agent Guide

> Python/FastAPI service.

## Quick Reference

| Item | Value |
|------|-------|
| Port | {port} |
| Framework | FastAPI + Uvicorn |
| Python | 3.11 |

## Build & Run

```sh
# Install dependencies
uv sync

# Run locally
uv run uvicorn src.main:app --host 0.0.0.0 --port {port}

# Run tests
uv run pytest

# Run via Docker
dx dev {compose_name}
```

## Directory Structure

```
{slug}/
├── src/
│   ├── main.py        # FastAPI app entry point
│   ├── config.py      # Environment config (pydantic-settings)
│   └── api/
│       └── health.py  # Health check endpoint
├── tests/
│   └── test_health.py
├── pyproject.toml
├── uv.lock
└── Dockerfile
```

## Key Config (environment variables)

- `APP_PORT` (default: {port})
- `LOG_LEVEL` (default: INFO)
""")

    # Add to docker-compose files
    _add_python_compose_entry(root, slug, port)

    # Initialize uv.lock
    info("Initializing uv.lock...")
    import subprocess

    result = subprocess.run(
        ["uv", "lock"],
        cwd=svc_dir,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        warn(f"Could not initialize uv.lock: {result.stderr.strip()}")
        warn("Run 'uv lock' manually in the service directory")

    success(f"Python service scaffolded at services/{slug}/")


def _add_python_compose_entry(root: Path, slug: str, port: int) -> None:
    """Append a Python service entry to the compose files."""
    compose_name = f"service-{slug}"
    port_var = compose_name.upper().replace("-", "_") + "_PORT"

    # docker-compose.services.yml
    services_file = root / COMPOSE_FILES["services"]
    if services_file.exists():
        content = services_file.read_text()
        if compose_name + ":" not in content:
            entry = f"""
  {compose_name}:
    build:
      context: ./services/{slug}
      dockerfile: Dockerfile
    image: {slug}-service:latest
    ports:
      - "${{{port_var}:-{port}}}:{port}"
    environment:
      - APP_PORT={port}
      - LOG_LEVEL=INFO
      - OTEL_SERVICE_NAME={slug}
      - OTEL_EXPORTER_OTLP_ENDPOINT=http://clickstack-otel:4318
      - OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
      - OTEL_EXPORTER_OTLP_HEADERS=authorization=${{CLICKSTACK_API_KEY}}
"""
            services_file.write_text(content.rstrip() + "\n" + entry)
            info(f"  Added {compose_name} to {COMPOSE_FILES['services']}")

    # docker-compose.dev.services.yml
    dev_file = root / DEV_OVERLAYS["services"]
    if dev_file.exists():
        content = dev_file.read_text()
        if compose_name + ":" not in content:
            # Insert before the volumes: section if present
            entry = f"""\
  {compose_name}:
    build:
      context: ./services/{slug}
      dockerfile: Dockerfile
    volumes:
      - ./services/{slug}:/app
    command: ["uv", "run", "uvicorn", "src.main:app", "--host", "0.0.0.0", "--port", "{port}", "--reload"]
"""
            # Find the volumes: line and insert before it
            if "\nvolumes:" in content:
                content = content.replace("\nvolumes:", f"\n{entry}\nvolumes:")
            else:
                content = content.rstrip() + "\n\n" + entry
            dev_file.write_text(content)
            info(f"  Added {compose_name} to {DEV_OVERLAYS['services']}")


# ---------------------------------------------------------------------------
# Java service templates
# ---------------------------------------------------------------------------


def _generate_java(root: Path, slug: str, port: int) -> None:
    """Scaffold a Java/Spring Boot service."""
    svc_dir = root / "services" / slug

    if svc_dir.exists():
        error(f"Directory already exists: services/{slug}/")
        sys.exit(1)

    compose_name = f"service-{slug}"
    class_name = _to_class_name(slug)
    pkg_name = _to_package_name(slug)

    info(f"Generating Java service: {compose_name}")
    info(f"  Directory: services/{slug}/")
    info(f"  Port: {port}")
    info(f"  Package: software.lepton.service.{pkg_name}")

    # Create directory structure
    server_dir = svc_dir / "server"
    java_pkg = (
        server_dir
        / "src"
        / "main"
        / "java"
        / "software"
        / "lepton"
        / "service"
        / pkg_name
    )
    resources_dir = server_dir / "src" / "main" / "resources"
    migration_dir = resources_dir / "db" / "migration"
    test_pkg = (
        server_dir
        / "src"
        / "test"
        / "java"
        / "software"
        / "lepton"
        / "service"
        / pkg_name
    )

    for d in (
        java_pkg / "config",
        java_pkg / "api",
        java_pkg / "service",
        java_pkg / "domain",
        java_pkg / "dto",
        migration_dir,
        test_pkg,
    ):
        d.mkdir(parents=True, exist_ok=True)

    # Parent pom.xml
    (svc_dir / "pom.xml").write_text(f"""\
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>3.2.1</version>
        <relativePath/>
    </parent>

    <groupId>software.lepton.service</groupId>
    <artifactId>{slug}</artifactId>
    <version>1.0.0-SNAPSHOT</version>
    <packaging>pom</packaging>
    <name>{class_name} Service</name>

    <modules>
        <module>server</module>
    </modules>

    <properties>
        <java.version>21</java.version>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>

        <lombok.version>1.18.42</lombok.version>
        <mapstruct.version>1.5.5.Final</mapstruct.version>
        <springdoc.version>2.6.0</springdoc.version>
        <auth-utils.version>1.0.3</auth-utils.version>
    </properties>

    <repositories>
        <repository>
            <id>artifact-registry</id>
            <name>GCP Artifact Registry</name>
            <url>https://asia-south1-maven.pkg.dev/rio-platform/maven-repo</url>
        </repository>
    </repositories>

    <dependencyManagement>
        <dependencies>
            <dependency>
                <groupId>software.lepton.lib</groupId>
                <artifactId>auth-utils</artifactId>
                <version>${{auth-utils.version}}</version>
            </dependency>
            <dependency>
                <groupId>org.springdoc</groupId>
                <artifactId>springdoc-openapi-starter-webmvc-api</artifactId>
                <version>${{springdoc.version}}</version>
            </dependency>
        </dependencies>
    </dependencyManagement>

    <build>
        <pluginManagement>
            <plugins>
                <plugin>
                    <groupId>org.apache.maven.plugins</groupId>
                    <artifactId>maven-compiler-plugin</artifactId>
                    <configuration>
                        <release>${{java.version}}</release>
                        <annotationProcessorPaths>
                            <path>
                                <groupId>org.projectlombok</groupId>
                                <artifactId>lombok</artifactId>
                                <version>${{lombok.version}}</version>
                            </path>
                        </annotationProcessorPaths>
                    </configuration>
                </plugin>
            </plugins>
        </pluginManagement>
    </build>
</project>
""")

    # Server pom.xml
    (server_dir / "pom.xml").write_text(f"""\
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <parent>
        <groupId>software.lepton.service</groupId>
        <artifactId>{slug}</artifactId>
        <version>1.0.0-SNAPSHOT</version>
    </parent>

    <artifactId>server</artifactId>
    <name>{class_name} Service Server</name>

    <dependencies>
        <!-- Auth Utils -->
        <dependency>
            <groupId>software.lepton.lib</groupId>
            <artifactId>auth-utils</artifactId>
        </dependency>

        <!-- Spring Security (required by auth-utils) -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-security</artifactId>
        </dependency>

        <!-- DevTools -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-devtools</artifactId>
            <scope>runtime</scope>
            <optional>true</optional>
        </dependency>

        <!-- Spring Boot Starters -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-validation</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-actuator</artifactId>
        </dependency>

        <!-- SpringDoc OpenAPI -->
        <dependency>
            <groupId>org.springdoc</groupId>
            <artifactId>springdoc-openapi-starter-webmvc-api</artifactId>
        </dependency>

        <!-- Lombok -->
        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>

        <!-- Test -->
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
                <configuration>
                    <excludes>
                        <exclude>
                            <groupId>org.projectlombok</groupId>
                            <artifactId>lombok</artifactId>
                        </exclude>
                    </excludes>
                </configuration>
            </plugin>
        </plugins>
    </build>
</project>
""")

    # Application class
    (java_pkg / f"{class_name}ServiceApplication.java").write_text(f"""\
package software.lepton.service.{pkg_name};

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {{
    "software.lepton.service.{pkg_name}",
    "software.lepton.lib.auth"
}})
public class {class_name}ServiceApplication {{
    public static void main(String[] args) {{
        SpringApplication.run({class_name}ServiceApplication.class, args);
    }}
}}
""")

    # OpenApiConfig
    (java_pkg / "config" / "OpenApiConfig.java").write_text(f"""\
package software.lepton.service.{pkg_name}.config;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {{
    @Bean
    public OpenAPI customOpenAPI() {{
        return new OpenAPI()
                .info(new Info()
                        .title("{class_name} Service API")
                        .version("1.0.0"));
    }}
}}
""")

    # HealthController
    (java_pkg / "api" / "HealthController.java").write_text(f"""\
package software.lepton.service.{pkg_name}.api;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class HealthController {{
    @GetMapping("/status")
    public Map<String, String> status() {{
        return Map.of("status", "ok");
    }}
}}
""")

    # application.yml
    (resources_dir / "application.yml").write_text(f"""\
spring:
  application:
    name: {slug}-service

auth:
  provider: better-auth
  security:
    public-endpoints: /actuator/health,/actuator/info,/openapi

better-auth:
  base:
    url: ${{BETTER_AUTH_BASE_URL:http://infra-auth:3000}}
  jwt:
    secret: ${{BETTER_AUTH_JWT_SECRET:}}
  jwks:
    path: ${{BETTER_AUTH_JWKS_PATH:/api/v1/auth/jwks}}

server:
  port: ${{SERVER_PORT:{port}}}
  servlet:
    context-path: /api/v1/{slug}

springdoc:
  api-docs:
    path: /openapi
    enabled: true
  swagger-ui:
    enabled: false

management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
""")

    # Test class
    (test_pkg / f"{class_name}ServiceApplicationTests.java").write_text(f"""\
package software.lepton.service.{pkg_name};

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class {class_name}ServiceApplicationTests {{
    @Test
    void contextLoads() {{
    }}
}}
""")

    # Dockerfile
    (svc_dir / "Dockerfile").write_text(f"""\
# ------------------------------------------------------------
# {class_name} Service - Dockerfile
# ------------------------------------------------------------
# Build context: repository root
# ------------------------------------------------------------

FROM maven:3.9-eclipse-temurin-21 AS builder

WORKDIR /build

COPY scripts/setup-maven-auth.sh ./scripts/setup-maven-auth.sh
RUN chmod +x ./scripts/setup-maven-auth.sh

ARG GCP_SERVICE_ACCOUNT_JSON_BASE64
ENV GCP_SERVICE_ACCOUNT_JSON_BASE64=${{GCP_SERVICE_ACCOUNT_JSON_BASE64}}

RUN DOCKER_BUILD=1 ./scripts/setup-maven-auth.sh

ENV GOOGLE_APPLICATION_CREDENTIALS=/root/.m2/gcp-application-credentials.json

WORKDIR /build/services/{slug}

COPY services/{slug}/pom.xml .
COPY services/{slug}/server/pom.xml server/

RUN --mount=type=cache,target=/root/.m2/repository \\
    mvn dependency:go-offline -B -s /root/.m2/settings.xml || true

COPY services/{slug}/server/src server/src

RUN --mount=type=cache,target=/root/.m2/repository \\
    mvn clean package -DskipTests -B -U \\
    -s /root/.m2/settings.xml \\
    -Dmaven.wagon.http.pool=false

# Runtime Stage
FROM eclipse-temurin:21-jre-alpine

WORKDIR /app

RUN addgroup -g 1001 -S appgroup && \\
    adduser -u 1001 -S appuser -G appgroup

COPY --from=builder /build/services/{slug}/server/target/server-*.jar app.jar

ADD --chown=appuser:appgroup \\
    https://github.com/open-telemetry/opentelemetry-java-instrumentation/releases/latest/download/opentelemetry-javaagent.jar \\
    /app/opentelemetry-javaagent.jar

RUN chown -R appuser:appgroup /app

USER appuser

EXPOSE {port}

HEALTHCHECK --interval=30s --timeout=10s --start-period=60s --retries=3 \\
    CMD wget -qO- http://localhost:{port}/api/v1/{slug}/actuator/health || exit 1

ENV JAVA_OPTS="-XX:+UseContainerSupport -XX:MaxRAMPercentage=75.0 -Djava.security.egd=file:/dev/./urandom"

ENTRYPOINT ["sh", "-c", "java $JAVA_OPTS -jar app.jar"]
""")

    # Dockerfile.dev
    (svc_dir / "Dockerfile.dev").write_text(f"""\
# ------------------------------------------------------------
# {class_name} Service - Dev Dockerfile
# ------------------------------------------------------------
# Build context: repository root
# Source is volume-mounted at /app at runtime.
# ------------------------------------------------------------

FROM maven:3.9-eclipse-temurin-21

WORKDIR /build

COPY scripts/setup-maven-auth.sh ./scripts/setup-maven-auth.sh
RUN chmod +x ./scripts/setup-maven-auth.sh

ARG GCP_SERVICE_ACCOUNT_JSON_BASE64
ENV GCP_SERVICE_ACCOUNT_JSON_BASE64=${{GCP_SERVICE_ACCOUNT_JSON_BASE64}}

RUN DOCKER_BUILD=1 ./scripts/setup-maven-auth.sh

ENV GOOGLE_APPLICATION_CREDENTIALS=/root/.m2/gcp-application-credentials.json

WORKDIR /app

COPY services/{slug}/pom.xml .
COPY services/{slug}/server/pom.xml server/

RUN --mount=type=cache,target=/root/.m2/repository \\
    mvn dependency:go-offline -B -s /root/.m2/settings.xml || true

EXPOSE {port}

CMD ["sh", "-c", \\
     "mvn spring-boot:run -pl server -B -s /root/.m2/settings.xml"]
""")

    # CLAUDE.md
    (svc_dir / "CLAUDE.md").write_text(f"""\
# {class_name} Service — Agent Guide

> Spring Boot microservice. Stateless.

## Quick Reference

| Item | Value |
|------|-------|
| Port | {port} |
| Context path | `/api/v1/{slug}` |
| Java | 21 (Temurin) |
| Framework | Spring Boot 3.2.1 |
| Auth | Better Auth (JWT via auth-utils) |

## Build & Run

```sh
# Build common libs first
cd ../../common/java && mvn install -DskipTests

# Build this service
mvn clean install

# Run tests
mvn test

# Run locally
mvn spring-boot:run -pl server

# Run via Docker
dx dev {compose_name}
```

## Module Structure

```
{slug}/
├── pom.xml          # Parent POM (modules: server)
└── server/          # Spring Boot app (web layer, config, entry point)
```

## Package Convention

`software.lepton.service.{pkg_name}` — sub-packages: `config`, `api`, `service`, `domain`, `dto`

## Key Config (application.yml)

- `SERVER_PORT` (default: {port})
- `BETTER_AUTH_BASE_URL` — auth service URL
- `BETTER_AUTH_JWKS_PATH` — JWKS endpoint path
- Public endpoints (no auth): `/actuator/health`, `/actuator/info`, `/openapi`

## Dependencies

- `auth-utils` from `common/java/`
- SpringDoc OpenAPI for API docs
- OpenTelemetry Java Agent for tracing

## Pitfalls

- Must build `common/java` before this service
- Multi-module Maven: run commands from `services/{slug}/` root, use `-pl server` for server-only
""")

    # Add to docker-compose files
    _add_java_compose_entry(root, slug, port)

    success(f"Java service scaffolded at services/{slug}/")


def _add_java_compose_entry(root: Path, slug: str, port: int) -> None:
    """Append a Java service entry to the compose files."""
    compose_name = f"service-{slug}"
    port_var = compose_name.upper().replace("-", "_") + "_PORT"

    # docker-compose.services.yml
    services_file = root / COMPOSE_FILES["services"]
    if services_file.exists():
        content = services_file.read_text()
        if compose_name + ":" not in content:
            entry = f"""
  {compose_name}:
    build:
      context: .
      dockerfile: services/{slug}/Dockerfile
    image: {slug}-service:latest
    ports:
      - "${{{port_var}:-{port}}}:{port}"
    environment:
      - BETTER_AUTH_BASE_URL=http://infra-auth:3000
      - BETTER_AUTH_JWKS_PATH=/api/v1/auth/jwks
      - JAVA_TOOL_OPTIONS=-javaagent:/app/opentelemetry-javaagent.jar
      - OTEL_SERVICE_NAME={slug}-service
      - OTEL_EXPORTER_OTLP_ENDPOINT=http://clickstack-otel:4318
      - OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf
      - OTEL_EXPORTER_OTLP_HEADERS=authorization=${{CLICKSTACK_API_KEY}}
      - OTEL_TRACES_EXPORTER=otlp
      - OTEL_METRICS_EXPORTER=otlp
      - OTEL_LOGS_EXPORTER=otlp
      - OTEL_RESOURCE_ATTRIBUTES=deployment.environment=docker,service.namespace=lepton
    depends_on:
      infra-auth:
        condition: service_healthy
"""
            services_file.write_text(content.rstrip() + "\n" + entry)
            info(f"  Added {compose_name} to {COMPOSE_FILES['services']}")

    # docker-compose.dev.services.yml
    dev_file = root / DEV_OVERLAYS["services"]
    if dev_file.exists():
        content = dev_file.read_text()
        if compose_name + ":" not in content:
            entry = f"""\
  {compose_name}:
    build:
      context: .
      dockerfile: services/{slug}/Dockerfile.dev
    volumes:
      - ./services/{slug}:/app
      - maven-repo:/root/.m2/repository
    environment:
      - JAVA_TOOL_OPTIONS=
      - SPRING_DEVTOOLS_RESTART_POLL_INTERVAL=2s
      - SPRING_DEVTOOLS_RESTART_QUIET_PERIOD=1s
"""
            if "\nvolumes:" in content:
                content = content.replace("\nvolumes:", f"\n{entry}\nvolumes:")
            else:
                content = content.rstrip() + "\n\n" + entry
            dev_file.write_text(content)
            info(f"  Added {compose_name} to {DEV_OVERLAYS['services']}")


# ---------------------------------------------------------------------------
# Main command
# ---------------------------------------------------------------------------


def cmd_generate(catalog: ComposeCatalog, args: list[str]) -> None:
    """Generate a new service from templates."""
    if len(args) < 2:
        error("Usage: dx generate <python|java> <name> [--port PORT]")
        error("")
        error("Examples:")
        error("  dx generate python notifications")
        error("  dx generate java billing --port 8095")
        sys.exit(1)

    svc_type = args[0]
    slug = args[1]

    if svc_type not in ("python", "java"):
        error(f"Unknown service type: {svc_type}")
        error("Supported types: python, java")
        sys.exit(1)

    # Validate slug
    if not re.match(r"^[a-z][a-z0-9-]*$", slug):
        error(f"Invalid service name: {slug}")
        error(
            "Name must be lowercase, start with a letter, and contain only a-z, 0-9, -"
        )
        sys.exit(1)

    # Parse optional --port
    port = None
    for i, arg in enumerate(args[2:], 2):
        if arg == "--port" and i + 1 < len(args):
            try:
                port = int(args[i + 1])
            except ValueError:
                error(f"Invalid port: {args[i + 1]}")
                sys.exit(1)

    if port is None:
        port = _next_port(catalog, svc_type)

    header(f"dx generate {svc_type}")

    if svc_type == "python":
        _generate_python(catalog.root, slug, port)
    else:
        _generate_java(catalog.root, slug, port)

    print()
    info("Next steps:")
    info(f"  1. cd services/{slug}")
    if svc_type == "python":
        info("  2. uv sync")
    else:
        info("  2. mvn clean install")
    info(f"  3. dx dev service-{slug}")
