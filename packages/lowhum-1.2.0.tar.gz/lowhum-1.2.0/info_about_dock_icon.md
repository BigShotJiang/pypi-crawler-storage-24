    Basic usage:

     1 import rumps
     2
     3 class MyApp(rumps.App):
     4     def __init__(self):
     5         super().__init__("My App")
     6         # Set dock icon from image file
     7         self.dock_icon = "path/to/icon.png"

    Key points:

     - dock_icon accepts a path to an image file (PNG, ICNS, etc.)
     - You can change it dynamically at runtime
     - Set to None to hide the dock icon entirely
     - Useful for status bar apps that want to optionally show/hide their dock presence

    Example - toggling dock icon:

      1 import rumps
      2
      3 class MyApp(rumps.App):
      4     def __init__(self):
      5         super().__init__("My App")
      6         self.menu = ["Toggle Dock Icon", "Quit"]
      7
      8     @rumps.clicked("Toggle Dock Icon")
      9     def toggle(self, _):
     10         if self.dock_icon:
     11             self.dock_icon = None  # Hide
     12         else:
     13             self.dock_icon = "icon.png"  # Show
     14
     15 if __name__ == "__main__":
     16     MyApp().run()

    This is separate from the status bar icon - you can have both, one, or neither
    depending on your app's needs.
