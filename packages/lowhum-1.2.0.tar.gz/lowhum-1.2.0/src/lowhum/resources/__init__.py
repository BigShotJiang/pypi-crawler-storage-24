"""Icon resources for LowHum macOS application."""

from __future__ import annotations

from importlib import resources
from pathlib import Path


_ICONS_PACKAGE = resources.files("lowhum.resources") / "icons"


def app_icon_path() -> Path:
    """Return path to the main application icon."""
    return Path(str(_ICONS_PACKAGE / "app_icon.png"))


def menubar_icon_path(dark_mode: bool = True) -> Path:
    """Return path to the menubar icon for the specified theme."""
    name = "menubar_dark.png" if dark_mode else "menubar_light.png"
    return Path(str(_ICONS_PACKAGE / name))
