"""Noise, binaural beat, and soundscape generator — cached WAV files.

Soundscapes layer filtered noise beds with slowly evolving tonal elements
to produce non-repeating, focus-enhancing textures. Two modes:

- Study: warm brown noise bed + drifting sine drones + fading overtones.
  Designed for deep reading. Tones sit well below the noise (~0.10 amp).
- Flow: pink/brown noise bed + subtle low-beta AM (~12-15 Hz) for
  brainwave entrainment + swept resonant bandpass + harmonic blooms.
  Designed for active concentration (Brain.fm-style rhythmic texture).
"""

import math
from enum import Enum
from pathlib import Path

import numpy as np
from scipy.io.wavfile import write as wav_write
from scipy.signal import butter, sosfilt

SAMPLE_RATE = 44_100
DURATION = 600  # seconds (10 minutes)
DATA_DIR = Path.home() / ".lowhum"


class NoiseColor(str, Enum):
    BROWN = "brown"
    PINK = "pink"
    WHITE = "white"


class SoundMode(str, Enum):
    STUDY = "study"
    FLOW = "flow"


def audio_file(color: NoiseColor) -> Path:
    return DATA_DIR / f"{color.value}_noise.wav"


def _raw_noise(color: NoiseColor, n: int) -> np.ndarray:
    white = np.random.randn(n)
    if color == NoiseColor.WHITE:
        return white
    elif color == NoiseColor.PINK:
        f = np.fft.rfftfreq(n)
        f[0] = 1.0  # avoid divide-by-zero at DC
        return np.fft.irfft(np.fft.rfft(white) / np.sqrt(f), n=n)
    else:  # BROWN
        return np.cumsum(white)


def _crossfade(chunks: list[np.ndarray]) -> np.ndarray:
    """Overlap-add crossfade across chunk boundaries (1 s)."""
    if len(chunks) == 1:
        return chunks[0]
    xfade = SAMPLE_RATE
    fade_out = np.linspace(1, 0, xfade)
    fade_in = np.linspace(0, 1, xfade)
    if chunks[0].ndim == 2:
        fade_out = fade_out[:, np.newaxis]
        fade_in = fade_in[:, np.newaxis]
    parts: list[np.ndarray] = [chunks[0][:-xfade]]
    for i in range(1, len(chunks)):
        blend = chunks[i - 1][-xfade:] * fade_out + chunks[i][:xfade] * fade_in
        parts.append(blend)
        last = i == len(chunks) - 1
        tail = chunks[i][xfade:] if last else chunks[i][xfade:-xfade]
        parts.append(tail)
    return np.concatenate(parts)


def generate_noise(
    color: NoiseColor = NoiseColor.BROWN,
    output_path: Path | None = None,
    duration: int = DURATION,
) -> Path:
    """Generate noise of the requested color and write as WAV.

    Brown: cumsum white noise, Butterworth bandpass (1-500 Hz) + HP 20 Hz.
    Pink: 1/f spectral shaping via FFT, HP 20 Hz.
    White: gaussian noise, HP 20 Hz.
    """
    if output_path is None:
        output_path = audio_file(color)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    chunk_samples = SAMPLE_RATE * 300  # process in 5-min chunks
    n_chunks = max(1, math.ceil(duration * SAMPLE_RATE / chunk_samples))

    sub_sos = butter(1, 20, btype="high", fs=SAMPLE_RATE, output="sos")
    if color == NoiseColor.BROWN:
        hp_sos = butter(2, 1.0, btype="high", fs=SAMPLE_RATE, output="sos")
        lp_sos = butter(2, 500, btype="low", fs=SAMPLE_RATE, output="sos")

    chunks: list[np.ndarray] = []
    for _ in range(n_chunks):
        chunk = _raw_noise(color, chunk_samples)
        if color == NoiseColor.BROWN:
            chunk = sosfilt(hp_sos, chunk)
            chunk = sosfilt(lp_sos, chunk)
        chunk = sosfilt(sub_sos, chunk)
        rms = np.sqrt(np.mean(chunk**2))
        chunk = chunk * (0.3 / rms)
        chunk = np.clip(chunk, -1.0, 1.0)
        chunks.append(chunk)

    final = _crossfade(chunks)[: duration * SAMPLE_RATE]
    audio_data = (final * 32_767).astype(np.int16)
    wav_write(str(output_path), SAMPLE_RATE, audio_data)
    return output_path


def ensure_audio(color: NoiseColor = NoiseColor.BROWN) -> Path:
    """Return the path to the audio file for *color*, generating if needed."""
    path = audio_file(color)
    if path.exists():
        return path
    print(f"Generating {color.value} noise audio (first run — takes ~5 s) …")
    return generate_noise(color)


def ensure_all_audio() -> None:
    """Pre-generate every noise, binaural, and soundscape variant."""
    for color in NoiseColor:
        path = audio_file(color)
        if not path.exists():
            print(f"Generating {color.value} noise …")
            generate_noise(color)

    for band in BrainwaveBand:
        for color in NoiseColor:
            path = binaural_audio_file(band, color)
            if not path.exists():
                print(f"Generating {band.value} binaural over {color.value} …")
                generate_binaural(band, color)

    for mode in SoundMode:
        path = soundscape_file(mode)
        if not path.exists():
            print(f"Generating {mode.value} soundscape …")
            if mode == SoundMode.STUDY:
                generate_study()
            else:
                generate_flow()


class BrainwaveBand(str, Enum):
    """Target brainwave entrainment bands for binaural beats."""

    THETA = "theta"  # 6 Hz — deep relaxation, meditation
    ALPHA = "alpha"  # 10 Hz — calm focus, light relaxation
    BETA = "beta"  # 18 Hz — active thinking, concentration
    GAMMA = "gamma"  # 40 Hz — high-level cognition

    @property
    def beat_freq(self) -> float:
        return _BAND_FREQS[self]


_BAND_FREQS: dict[BrainwaveBand, float] = {
    BrainwaveBand.THETA: 6.0,
    BrainwaveBand.ALPHA: 10.0,
    BrainwaveBand.BETA: 18.0,
    BrainwaveBand.GAMMA: 40.0,
}

CARRIER_HZ = 200.0  # good perceived beat strength


def binaural_audio_file(
    band: BrainwaveBand,
    noise: NoiseColor = NoiseColor.BROWN,
) -> Path:
    return DATA_DIR / f"binaural_{band.value}_{noise.value}.wav"


def generate_binaural(
    band: BrainwaveBand = BrainwaveBand.ALPHA,
    noise: NoiseColor = NoiseColor.BROWN,
    output_path: Path | None = None,
    duration: int = DURATION,
    beat_volume: float = 0.15,
) -> Path:
    """Generate stereo binaural beats layered under noise.

    Left ear hears carrier_hz, right ear hears carrier_hz + beat_freq.
    The perceptual difference produces the binaural beat. Noise is
    identical in both channels so the beat stands out without the
    raw sine being harsh on its own.

    beat_volume controls the sine amplitude relative to the noise
    (0.15 = subtle undertone, which is the sweet spot for focus).
    """
    if output_path is None:
        output_path = binaural_audio_file(band, noise)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    beat_freq = band.beat_freq
    left_hz = CARRIER_HZ
    right_hz = CARRIER_HZ + beat_freq

    chunk_seconds = 300  # 5-min chunks, same as noise gen
    chunk_samples = SAMPLE_RATE * chunk_seconds
    n_chunks = max(1, math.ceil(duration * SAMPLE_RATE / chunk_samples))

    # Filters for the noise bed (same as generate_noise)
    sub_sos = butter(1, 20, btype="high", fs=SAMPLE_RATE, output="sos")
    if noise == NoiseColor.BROWN:
        hp_sos = butter(2, 1.0, btype="high", fs=SAMPLE_RATE, output="sos")
        lp_sos = butter(2, 500, btype="low", fs=SAMPLE_RATE, output="sos")

    # Each chunk is (n, 2) — left and right channels
    chunks: list[np.ndarray] = []
    sample_offset = 0

    for _ in range(n_chunks):
        # Noise bed (mono, duplicated to both channels)
        bed = _raw_noise(noise, chunk_samples)
        if noise == NoiseColor.BROWN:
            bed = sosfilt(hp_sos, bed)
            bed = sosfilt(lp_sos, bed)
        bed = sosfilt(sub_sos, bed)
        rms = np.sqrt(np.mean(bed**2))
        bed *= 0.3 / rms

        # Binaural tones — continuous phase across chunks
        t = (np.arange(chunk_samples) + sample_offset) / SAMPLE_RATE
        left_tone = np.sin(2 * np.pi * left_hz * t) * beat_volume
        right_tone = np.sin(2 * np.pi * right_hz * t) * beat_volume
        sample_offset += chunk_samples

        stereo = np.column_stack(
            [
                bed + left_tone,
                bed + right_tone,
            ]
        )

        # Per-channel RMS normalize to 0.3
        for ch in range(2):
            ch_rms = np.sqrt(np.mean(stereo[:, ch] ** 2))
            if ch_rms > 0:
                stereo[:, ch] *= 0.3 / ch_rms

        stereo = np.clip(stereo, -1.0, 1.0)
        chunks.append(stereo)

    final = _crossfade(chunks)[: duration * SAMPLE_RATE]
    audio_data = (final * 32_767).astype(np.int16)
    wav_write(str(output_path), SAMPLE_RATE, audio_data)
    return output_path


def ensure_binaural(
    band: BrainwaveBand = BrainwaveBand.ALPHA,
    noise: NoiseColor = NoiseColor.BROWN,
) -> Path:
    """Return path to the binaural audio file, generating if needed."""
    path = binaural_audio_file(band, noise)
    if path.exists():
        return path
    print(
        f"Generating {band.value} binaural beat over {noise.value} noise"
        f" (first run — takes ~5 s) …"
    )
    return generate_binaural(band, noise)


# Soundscape generators


def soundscape_file(mode: SoundMode) -> Path:
    return DATA_DIR / f"soundscape_{mode.value}.wav"


def _noise_bed(
    color: NoiseColor, n: int, sub_sos: np.ndarray, **kw: np.ndarray
) -> np.ndarray:
    """Generate a filtered noise bed, RMS-normalized to 0.3."""
    bed = _raw_noise(color, n)
    if color == NoiseColor.BROWN:
        bed = sosfilt(kw["hp_sos"], bed)
        bed = sosfilt(kw["lp_sos"], bed)
    bed = sosfilt(sub_sos, bed)
    rms = np.sqrt(np.mean(bed**2))
    if rms > 0:
        bed *= 0.3 / rms
    return bed


def generate_study(
    output_path: Path | None = None,
    duration: int = DURATION,
) -> Path:
    """Warm ambient soundscape for deep study and reading.

    Layers a brown noise bed with slowly drifting sine drones and
    fading harmonic overtones. The tonal elements evolve over 30-60 s
    cycles so the texture never repeats or becomes predictable, but
    stays gentle enough to fade from conscious attention.
    """
    if output_path is None:
        output_path = soundscape_file(SoundMode.STUDY)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    chunk_seconds = 300
    chunk_samples = SAMPLE_RATE * chunk_seconds
    n_chunks = max(1, math.ceil(duration * SAMPLE_RATE / chunk_samples))

    sub_sos = butter(1, 20, btype="high", fs=SAMPLE_RATE, output="sos")
    hp_sos = butter(2, 1.0, btype="high", fs=SAMPLE_RATE, output="sos")
    lp_sos = butter(2, 500, btype="low", fs=SAMPLE_RATE, output="sos")

    # drone config: base freqs, drift range, cycle periods
    drone_bases = np.array([80.0, 120.0, 180.0])
    drift_hz = np.array([3.0, 5.0, 4.0])  # max pitch drift
    drone_amp = 0.10
    # each drone drifts on its own slow LFO
    drift_periods = np.array([37.0, 53.0, 43.0])  # seconds, coprime-ish

    # overtone blooms: partials that fade in/out independently
    overtone_ratios = np.array([2.0, 3.0, 2.5, 1.5])
    bloom_periods = np.array([19.0, 29.0, 23.0, 31.0])
    bloom_amp = 0.06

    chunks: list[np.ndarray] = []
    sample_offset = 0

    for _ in range(n_chunks):
        bed = _noise_bed(
            NoiseColor.BROWN,
            chunk_samples,
            sub_sos,
            hp_sos=hp_sos,
            lp_sos=lp_sos,
        )
        t = (np.arange(chunk_samples) + sample_offset) / SAMPLE_RATE

        # drifting drones
        tones = np.zeros(chunk_samples)
        for i, base in enumerate(drone_bases):
            freq = base + drift_hz[i] * np.sin(2 * np.pi * t / drift_periods[i])
            # integrate instantaneous frequency for smooth phase
            phase = 2 * np.pi * np.cumsum(freq) / SAMPLE_RATE
            tones += np.sin(phase) * drone_amp

        # harmonic blooms: overtones of the first drone, fading in/out
        for i, ratio in enumerate(overtone_ratios):
            freq = (
                drone_bases[0] * ratio
                + drift_hz[0] * np.sin(2 * np.pi * t / drift_periods[0]) * ratio
            )
            phase = 2 * np.pi * np.cumsum(freq) / SAMPLE_RATE
            # raised-cosine envelope for smooth bloom
            env = 0.5 * (1 + np.sin(2 * np.pi * t / bloom_periods[i]))
            tones += np.sin(phase) * env * bloom_amp

        chunk = bed + tones
        rms = np.sqrt(np.mean(chunk**2))
        if rms > 0:
            chunk *= 0.3 / rms
        chunk = np.clip(chunk, -1.0, 1.0)
        chunks.append(chunk)
        sample_offset += chunk_samples

    final = _crossfade(chunks)[: duration * SAMPLE_RATE]
    wav_write(str(output_path), SAMPLE_RATE, (final * 32_767).astype(np.int16))
    return output_path


def generate_flow(
    output_path: Path | None = None,
    duration: int = DURATION,
) -> Path:
    """Active focus soundscape with rhythmic entrainment.

    Pink noise bed with subtle amplitude modulation at 12-15 Hz
    (low beta band) for brainwave entrainment, a slowly swept
    resonant bandpass filter for spectral movement, and harmonic
    blooms that rise and fall over 10-20 second cycles.

    The AM depth is kept low (~15%) so the pulse sits below
    conscious awareness while still driving cortical following.
    """
    if output_path is None:
        output_path = soundscape_file(SoundMode.FLOW)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    chunk_seconds = 300
    chunk_samples = SAMPLE_RATE * chunk_seconds
    n_chunks = max(1, math.ceil(duration * SAMPLE_RATE / chunk_samples))

    sub_sos = butter(1, 20, btype="high", fs=SAMPLE_RATE, output="sos")
    # pink noise doesn't need the brown-specific bandpass

    # AM params: frequency sweeps slowly between 12-15 Hz
    am_lo, am_hi = 12.0, 15.0
    am_sweep_period = 67.0  # seconds
    am_depth = 0.15  # subtle; 0 = none, 1 = full tremolo

    # resonant sweep: bandpass center drifts 200-800 Hz over ~60 s
    sweep_lo, sweep_hi = 200.0, 800.0
    sweep_period = 61.0
    sweep_q = 2.0  # moderate resonance

    # bloom config: warm sine tones that swell
    bloom_freqs = np.array([150.0, 225.0, 300.0])
    bloom_periods = np.array([14.0, 17.0, 11.0])  # seconds
    bloom_amp = 0.08

    chunks: list[np.ndarray] = []
    sample_offset = 0

    for _ in range(n_chunks):
        bed = _noise_bed(NoiseColor.PINK, chunk_samples, sub_sos)
        t = (np.arange(chunk_samples) + sample_offset) / SAMPLE_RATE

        # low-beta AM: frequency itself drifts slowly
        am_freq = am_lo + (am_hi - am_lo) * 0.5 * (
            1 + np.sin(2 * np.pi * t / am_sweep_period)
        )
        am_phase = 2 * np.pi * np.cumsum(am_freq) / SAMPLE_RATE
        am_env = 1.0 - am_depth * 0.5 * (1 + np.sin(am_phase))
        bed *= am_env

        # swept resonant bandpass: process in short segments because
        # the center frequency changes over time. 1-second steps give
        # smooth enough movement without excessive filter recomputation
        step = SAMPLE_RATE  # 1 second
        swept = np.zeros(chunk_samples)
        for seg_start in range(0, chunk_samples, step):
            seg_end = min(seg_start + step, chunk_samples)
            seg_t = (seg_start + sample_offset) / SAMPLE_RATE
            center = sweep_lo + (sweep_hi - sweep_lo) * 0.5 * (
                1 + np.sin(2 * np.pi * seg_t / sweep_period)
            )
            bw = center / sweep_q
            lo_edge = max(center - bw / 2, 21.0)
            hi_edge = min(center + bw / 2, SAMPLE_RATE / 2 - 1)
            bp_sos = butter(
                2,
                [lo_edge, hi_edge],
                btype="band",
                fs=SAMPLE_RATE,
                output="sos",
            )
            swept[seg_start:seg_end] = sosfilt(bp_sos, bed[seg_start:seg_end])

        # blend: 70% original bed + 30% swept resonance
        bed = 0.7 * bed + 0.3 * swept

        # harmonic blooms
        blooms = np.zeros(chunk_samples)
        for i, freq in enumerate(bloom_freqs):
            phase = 2 * np.pi * freq * t
            # raised cosine envelope, shifted so blooms peak at
            # different times
            env = 0.5 * (1 + np.sin(2 * np.pi * t / bloom_periods[i]))
            blooms += np.sin(phase) * env * bloom_amp

        chunk = bed + blooms
        rms = np.sqrt(np.mean(chunk**2))
        if rms > 0:
            chunk *= 0.3 / rms
        chunk = np.clip(chunk, -1.0, 1.0)
        chunks.append(chunk)
        sample_offset += chunk_samples

    final = _crossfade(chunks)[: duration * SAMPLE_RATE]
    wav_write(str(output_path), SAMPLE_RATE, (final * 32_767).astype(np.int16))
    return output_path


def ensure_soundscape(mode: SoundMode) -> Path:
    """Return path to the soundscape file, generating if needed."""
    path = soundscape_file(mode)
    if path.exists():
        return path
    label = mode.value.capitalize()
    print(f"Generating {label} soundscape (first run — takes ~5 s) …")
    if mode == SoundMode.STUDY:
        return generate_study()
    return generate_flow()
