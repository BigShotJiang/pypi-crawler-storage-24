"""CLI entry point for LowHum — ``lhm`` and ``lowhum`` resolve here."""

from __future__ import annotations

import importlib.metadata
import os
import subprocess
import sys

import typer

_DETACHED_ENV = "_LHM_DETACHED"
_NO_DOCK_ENV = "_LHM_NO_DOCK"
_AUTOPLAY_ENV = "_LHM_AUTOPLAY"


def _inside_app_bundle() -> bool:
    return ".app/Contents" in (sys.executable or "")


app = typer.Typer(
    name="lowhum",
    help="LowHum — deep brown noise for focus.",
    invoke_without_command=True,
    no_args_is_help=False,
)


_BISON = r"""
               _.-````'-,_
     _,.,_ ,-'           `'-.,_
   /)     (\                   '`-.
  ((      ) )                      `\
   \)    (_/                        )\
    |       /)           '    ,'    / \
    `\    ^'            '     (    /  ))
      |      _/\ ,     /    ,,`\   (  "`
       \Y,   |  \  \  | ``````| / \_ \
         `)_/    \  \  )    ( >  ( >
                  \( \(     |/   |/
                 /_(/_(    /_(  /_(
"""


def _banner() -> None:
    version = importlib.metadata.version("lowhum")
    typer.echo(_BISON)
    typer.echo(f"  ∿  LowHum  {version}  —  deep brown noise for focus\n")


@app.callback(invoke_without_command=True)
def _default(
    ctx: typer.Context,
    quiet: bool = typer.Option(
        False, "--quiet", "-q", help="Suppress the banner"
    ),
    no_dock: bool = typer.Option(False, "--no-dock", help="Hide the dock icon"),
    start: bool = typer.Option(
        False, "--start", "-s", help="Start playback immediately"
    ),
) -> None:
    """Launch the menu-bar app (default when no subcommand given)."""
    if ctx.invoked_subcommand is not None:
        return

    # Inside .app bundle or already detached; launch directly.
    if _inside_app_bundle() or os.environ.get(_DETACHED_ENV):
        from .app import LowHumApp
        from .generator import ensure_all_audio

        autoplay = bool(os.environ.get(_AUTOPLAY_ENV))
        force_no_dock = bool(os.environ.get(_NO_DOCK_ENV))

        ensure_all_audio()
        LowHumApp(autoplay=autoplay, force_no_dock=force_no_dock).run()
        return

    if not quiet:
        _banner()
    typer.echo("  Starting in background …\n")

    env = {**os.environ, _DETACHED_ENV: "1"}
    if no_dock:
        env[_NO_DOCK_ENV] = "1"
    if start:
        env[_AUTOPLAY_ENV] = "1"

    # Resolve to absolute path so the detached process works even when
    # launched from Spotlight or contexts with a minimal PATH.
    binary = os.path.abspath(sys.argv[0])

    subprocess.Popen(
        [binary],
        start_new_session=True,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=env,
    )
    raise SystemExit(0)


@app.command()
def devices() -> None:
    """List available audio output devices."""
    from .audio import get_default_output_device, list_output_devices

    _banner()
    default_idx = get_default_output_device()
    for idx, name in list_output_devices():
        marker = "  ← default" if idx == default_idx else ""
        typer.echo(f"  [{idx}]  {name}{marker}")


@app.command()
def generate(
    color: str = typer.Option(
        "brown", "--color", "-c", help="brown, pink, or white"
    ),
    duration: int = typer.Option(
        600, "--duration", "-d", help="Duration in seconds"
    ),
) -> None:
    """Pre-generate a noise audio file."""
    from .generator import NoiseColor, audio_file, generate_noise

    try:
        noise_color = NoiseColor(color)
    except ValueError:
        typer.echo(f"  Unknown color '{color}'. Choose: brown, pink, white.")
        raise typer.Exit(1) from None

    _banner()
    path = audio_file(noise_color)
    if path.exists():
        typer.echo(f"  Audio file already exists at {path}")
        if not typer.confirm("  Regenerate?"):
            raise typer.Abort()

    generate_noise(noise_color, duration=duration)
    typer.echo(f"  Saved to {path}")


@app.command(name="super-focus")
def super_focus() -> None:
    """Activate enhanced focus mode (experimental)."""
    import base64
    import time
    import webbrowser

    _banner()
    typer.echo("  Calibrating neural entrainment profile …")
    time.sleep(1.5)
    typer.echo("  Synchronizing binaural channels …")
    time.sleep(1)
    typer.echo("  Locked in.\n")
    # deep focus payload
    _p = b"aHR0cHM6Ly93d3cueW91dHViZS5jb20vd2F0Y2g/dj1kUXc0dzlXZ1hjUQ=="
    webbrowser.open(base64.b64decode(_p).decode())


if __name__ == "__main__":
    app()
