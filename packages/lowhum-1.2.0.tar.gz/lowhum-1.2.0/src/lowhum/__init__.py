"""LowHum — deep brown noise for focus."""

from importlib.metadata import version

__version__ = version("lowhum")
