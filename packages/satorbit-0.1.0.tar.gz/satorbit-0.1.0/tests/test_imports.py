"""Test that the package imports correctly and all public API is accessible."""

import satorbit


def test_import_satorbit():
    assert satorbit is not None


def test_version():
    assert hasattr(satorbit, '__version__')
    assert satorbit.__version__ == "0.1.0"


def test_all_exports_importable():
    for name in satorbit.__all__:
        obj = getattr(satorbit, name)
        assert obj is not None, f"{name} is None"


def test_modules_accessible():
    assert satorbit.tle is not None
    assert satorbit.sp3 is not None
    assert satorbit.transforms is not None
    assert satorbit.kepler is not None
