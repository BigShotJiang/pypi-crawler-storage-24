"""CortexHub WebSocket client for unified model access.

CortexHub provides a single WebSocket endpoint routing to all deployed models.
More efficient than HTTP for high-throughput async pipelines due to persistent connection.

Supports two usage patterns:

1. Request-Response (simple, blocking):
    >>> async with CortexHubClient() as hub:
    ...     depth = await hub.run(ModelType.ZOEDEPTH, image_input=img)

2. Pub/Sub (non-blocking, concurrent):
    >>> async with CortexHubClient() as hub:
    ...     await hub.publish(ModelType.ZOEDEPTH, request_id="depth1", image_input=img)
    ...     await hub.publish(ModelType.GSAM2, request_id="mask1", image_input=img, prompt="cat")
    ...     async for result in hub.subscribe():
    ...         print(f"{result.request_id}: {result.data}")
"""

from __future__ import annotations

import asyncio
import logging
import os
import uuid
from dataclasses import dataclass
from typing import Any, AsyncIterator, Dict, Optional, Type, Union
from urllib.parse import urlparse, urlunparse

from .model_type import ModelType
from .models import BaseModel
from .models.base_model import get_registry
from .ws import AsyncWebSocketSession

logger = logging.getLogger(__name__)

DEFAULT_BASE_URL = "https://cortex-prod.generalrobotics.dev/cortex"


@dataclass
class HubResult:
    """Result from a published inference request.

    Attributes:
        request_id: The ID provided when publishing the request
        model: The model that produced this result
        data: The inference output (postprocessed)
        ok: Whether the request succeeded
        error: Error message if ok=False
    """
    request_id: str
    model: str
    data: Any
    ok: bool = True
    error: Optional[str] = None


class CortexHubError(Exception):
    """Exception for CortexHub errors."""

    def __init__(self, message: str, model: Optional[str] = None, request_id: Optional[str] = None):
        self.message = message
        self.model = model
        self.request_id = request_id
        super().__init__(f"CortexHub error{f' ({model})' if model else ''}: {message}")


def _http_to_ws(http_url: str) -> str:
    """Convert HTTP(S) URL to WS(S) URL."""
    parsed = urlparse(http_url)
    scheme = "wss" if parsed.scheme == "https" else "ws"
    path = parsed.path.rstrip("/")
    return urlunparse((scheme, parsed.netloc, path, "", "", ""))


class CortexHubClient:
    """Asynchronous WebSocket client for CortexHub.

    Provides a persistent WebSocket connection for efficient model inference.
    Supports both request-response and pub/sub patterns.

    For synchronous usage, use CortexClient instead.

    Args:
        api_key: API key (defaults to GRID_CORTEX_API_KEY env var)
        base_url: Base URL (defaults to GRID_CORTEX_BASE_URL env var or production).
                  The WebSocket endpoint is derived from the `/ws` route prefix (ends up as `/ws/ws`).
        timeout: Socket timeout in seconds

    Example (request-response):
        >>> async with CortexHubClient() as hub:
        ...     depth = await hub.run(ModelType.ZOEDEPTH, image_input=img)

    Example (pub/sub for concurrent inference):
        >>> async with CortexHubClient() as hub:
        ...     await hub.publish(ModelType.ZOEDEPTH, request_id="d1", image_input=img)
        ...     await hub.publish(ModelType.GSAM2, request_id="m1", image_input=img, prompt="cat")
        ...     async for result in hub.subscribe():
        ...         process(result.request_id, result.data)
    """

    _handlers: Dict[str, Type[BaseModel]] = get_registry()

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 60.0,
    ):
        self._api_key = api_key or os.getenv("GRID_CORTEX_API_KEY") or os.getenv("CORTEX_API_KEY")
        if not self._api_key:
            logger.warning("API key not set. Set GRID_CORTEX_API_KEY or CORTEX_API_KEY.")
        self._base_url = base_url
        self._url = self._resolve_ws_url(base_url)
        self._timeout = timeout
        self._session: Optional[AsyncWebSocketSession] = None

        # Pub/sub state
        self._receiver_task: Optional[asyncio.Task] = None
        self._result_queue: asyncio.Queue[HubResult] = asyncio.Queue()
        self._pending_requests: Dict[str, str] = {}  # request_id -> model
        self._waiters: Dict[str, asyncio.Future[HubResult]] = {}
        self._pubsub_mode: bool = False

        logger.info(f"CortexHubClient initialized for URL: {self._url}")

    def _resolve_ws_url(self, base_url: Optional[str]) -> str:
        """Resolve WebSocket URL from base_url or environment."""
        http_base = base_url or os.getenv("GRID_CORTEX_BASE_URL", DEFAULT_BASE_URL)
        # CortexHub is deployed under the `/ws` route prefix:
        # - HTTP routes:   /ws/info, /ws/health, ...
        # - WebSocket:     /ws/ws
        hub_http_base = http_base.rstrip("/") + "/ws"
        ws_base = _http_to_ws(hub_http_base)
        return f"{ws_base}/ws"

    def _get_handler(self, model_id: str) -> Optional[Type[BaseModel]]:
        """Look up handler class for a model ID.

        This is intentionally an *exact* match. If the server exposes variant
        IDs (e.g. "gsam2-v2"), wrappers should register that exact ID too.
        """
        return self._handlers.get(model_id.lower())

    def _preprocess(self, model_id: str, kwargs: Dict[str, Any]) -> Dict[str, Any]:
        """Run model-specific preprocessing."""
        handler_cls = self._get_handler(model_id)
        if handler_cls:
            try:
                return handler_cls().preprocess(**kwargs)
            except TypeError:
                logger.debug(f"Preprocess TypeError for {model_id}, passing kwargs as-is")
        return kwargs

    def _postprocess(self, model_id: str, response: Dict[str, Any]) -> Any:
        """Run model-specific postprocessing."""
        handler_cls = self._get_handler(model_id)
        if handler_cls:
            try:
                return handler_cls().postprocess(response)
            except Exception as e:
                logger.warning(f"Postprocess failed for {model_id}: {e}, returning raw response")
        return response

    @property
    def url(self) -> str:
        """WebSocket URL this client connects to."""
        return self._url

    @property
    def is_connected(self) -> bool:
        """Check if WebSocket connection is active."""
        return self._session is not None and self._session.is_connected

    @property
    def pending_count(self) -> int:
        """Number of published requests awaiting responses."""
        return len(self._pending_requests)

    def available_models(self) -> list[str]:
        """Return registered model identifiers."""
        return sorted(self._handlers.keys())

    def help(self, model_id: str) -> str:
        """Return documentation for a model."""
        handler_cls = self._get_handler(model_id)
        if not handler_cls:
            raise NotImplementedError(f"Unknown model: {model_id}")
        return f"Model: {model_id}\n\n{handler_cls.__doc__ or ''}"

    async def connect(self) -> None:
        """Establish WebSocket connection."""
        if self._session and self._session.is_connected:
            return
        headers = {"x-api-key": self._api_key} if self._api_key else {}
        self._session = AsyncWebSocketSession(self._url, headers=headers, timeout=self._timeout)
        await self._session.connect()
        logger.info(f"Connected to CortexHub at {self._url}")

    async def close(self) -> None:
        """Close WebSocket connection and cleanup pub/sub resources."""
        # Stop receiver task
        if self._receiver_task and not self._receiver_task.done():
            self._receiver_task.cancel()
            try:
                await self._receiver_task
            except asyncio.CancelledError:
                pass
            self._receiver_task = None

        # Clear pub/sub state
        self._pending_requests.clear()
        for waiter in self._waiters.values():
            if not waiter.done():
                waiter.set_exception(RuntimeError("CortexHubClient closed"))
        self._waiters.clear()
        self._pubsub_mode = False

        # Close session
        if self._session:
            await self._session.close()
            self._session = None
            logger.info("CortexHub connection closed")

    # -------------------------------------------------------------------------
    # Request-Response API (blocking)
    # -------------------------------------------------------------------------

    async def run(self, model_id: Union[str, ModelType], **kwargs: Any) -> Any:
        """Run model inference via CortexHub (blocking request-response).

        Args:
            model_id: Model to run (ModelType enum or string)
            **kwargs: Model-specific parameters (e.g., image_input, prompt)

        Returns:
            Model output (same format as CortexClient.run)

        Raises:
            RuntimeError: If not connected or if pub/sub mode is active
            CortexHubError: If server returns an error
        """
        if self._pubsub_mode:
            raise RuntimeError("Cannot use run() while in pub/sub mode. Use publish() instead.")
        if not self._session or not self._session.is_connected:
            raise RuntimeError("Not connected. Use async context manager or call connect()")

        model = model_id.value if isinstance(model_id, ModelType) else str(model_id)
        payload = self._preprocess(model, kwargs)

        await self._session.send({"model": model, "payload": payload})
        response = await self._session.recv()

        if not response.get("ok"):
            raise CortexHubError(response.get("error", "Unknown error"), model=model)

        return self._postprocess(model, response.get("result", {}))

    # -------------------------------------------------------------------------
    # Pub/Sub API (non-blocking)
    # -------------------------------------------------------------------------

    async def _receiver_loop(self) -> None:
        """Background task that receives responses and routes to result queue."""
        receiver_error: Exception | None = None
        try:
            while self._session and self._session.is_connected:
                try:
                    response = await self._session.recv()
                except Exception as e:
                    receiver_error = e
                    logger.error(f"Receiver error: {e}")
                    break

                request_id = response.get("request_id")
                model = response.get("model")

                # Some servers omit request_id in pub/sub responses. If that happens,
                # infer the request_id by matching the model against pending requests.
                if not request_id and model:
                    candidates = [rid for rid, m in self._pending_requests.items() if m == model]
                    if len(candidates) == 1:
                        request_id = candidates[0]
                    elif len(candidates) > 1:
                        request_id = candidates[0]
                        logger.warning(
                            "CortexHub response missing request_id for model=%s; "
                            "multiple pending requests exist (%d). "
                            "Using oldest request_id=%s; results may be mis-attributed. "
                            "Server should echo request_id in pub/sub responses.",
                            model,
                            len(candidates),
                            request_id,
                        )

                request_id = request_id or ""
                model = model or self._pending_requests.get(request_id, "unknown")

                was_pending = request_id in self._pending_requests

                if response.get("ok"):
                    data = self._postprocess(model, response.get("result", {}))
                    result = HubResult(
                        request_id=request_id,
                        model=model,
                        data=data,
                        ok=True,
                    )
                else:
                    result = HubResult(
                        request_id=request_id,
                        model=model,
                        data=None,
                        ok=False,
                        error=response.get("error", "Unknown error"),
                    )

                waiter = self._waiters.pop(request_id, None)
                if waiter and not waiter.done():
                    waiter.set_result(result)
                elif was_pending:
                    await self._result_queue.put(result)
                # Remove from pending *after* enqueueing to avoid a race where
                # subscribe() sees pending==0 and an empty queue and exits
                # before the last result is delivered.
                self._pending_requests.pop(request_id, None)

        except asyncio.CancelledError:
            logger.debug("Receiver task cancelled")
            raise
        finally:
            # If the receiver stops unexpectedly, any tasks created by submit()
            # must not hang forever waiting for a result that will never arrive.
            if self._waiters:
                err = receiver_error or RuntimeError("CortexHubClient receiver stopped")
                for waiter in self._waiters.values():
                    if not waiter.done():
                        waiter.set_exception(err)
                self._waiters.clear()

    def _ensure_receiver_running(self) -> None:
        """Start the receiver task if not already running."""
        if self._receiver_task is None or self._receiver_task.done():
            self._receiver_task = asyncio.create_task(self._receiver_loop())
            self._pubsub_mode = True

    async def publish(
        self,
        model_id: Union[str, ModelType],
        request_id: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        """Publish a model inference request (non-blocking).

        Sends the request and returns immediately. Results arrive via subscribe().

        Args:
            model_id: Model to run (ModelType enum or string)
            request_id: Optional ID to track this request. Auto-generated if not provided.
            **kwargs: Model-specific parameters (e.g., image_input, prompt)

        Returns:
            The request_id (useful when auto-generated)

        Raises:
            RuntimeError: If not connected
        """
        if not self._session or not self._session.is_connected:
            raise RuntimeError("Not connected. Use async context manager or call connect()")

        model = model_id.value if isinstance(model_id, ModelType) else str(model_id)
        req_id = request_id or str(uuid.uuid4())[:8]
        if req_id in self._pending_requests:
            raise ValueError(f"request_id already pending: {req_id}")
        payload = self._preprocess(model, kwargs)

        # Track pending request
        self._pending_requests[req_id] = model

        # Ensure receiver is running
        self._ensure_receiver_running()

        # Send request with request_id
        await self._session.send({
            "model": model,
            "request_id": req_id,
            "payload": payload,
        })

        logger.debug(f"Published {model} request: {req_id}")
        return req_id

    def submit(
        self,
        model_id: Union[str, ModelType],
        request_id: Optional[str] = None,
        timeout_s: float | None = None,
        **kwargs: Any,
    ) -> "asyncio.Task[HubResult]":
        """Submit a request and return a Task for its eventual result.

        This is a convenience wrapper over the pub/sub API that lets you write:

            >>> async with CortexHubClient() as hub:
            ...     depth_t = hub.submit(ModelType.ZOEDEPTH, image_input=img)
            ...     mask_t = hub.submit(ModelType.GSAM2, image_input=img, prompt="cat")
            ...     depth_res, mask_res = await asyncio.gather(depth_t, mask_t)

        Notes:
          - This still requires an asyncio event loop (i.e., must run inside `async def`).
          - The returned Task yields a `HubResult` (check `ok` / `error`).
          - `timeout_s` defaults to the client's `timeout` (constructor arg). On timeout,
            the returned `HubResult` has `ok=False` and `error` set.
        """
        if not self._session or not self._session.is_connected:
            raise RuntimeError("Not connected. Use async context manager or call connect()")

        model = model_id.value if isinstance(model_id, ModelType) else str(model_id)
        req_id = request_id or str(uuid.uuid4())[:8]
        if req_id in self._pending_requests or req_id in self._waiters:
            raise ValueError(f"request_id already in use: {req_id}")

        effective_timeout = self._timeout if timeout_s is None else timeout_s

        loop = asyncio.get_running_loop()
        waiter: asyncio.Future[HubResult] = loop.create_future()
        self._waiters[req_id] = waiter

        async def _runner() -> HubResult:
            try:
                await self.publish(model, request_id=req_id, **kwargs)
            except Exception as e:
                w = self._waiters.pop(req_id, None)
                if w and not w.done():
                    w.set_exception(e)
                raise
            try:
                return await asyncio.wait_for(waiter, timeout=effective_timeout)
            except asyncio.TimeoutError:
                self._waiters.pop(req_id, None)
                self._pending_requests.pop(req_id, None)
                return HubResult(
                    request_id=req_id,
                    model=model,
                    data=None,
                    ok=False,
                    error=f"Timeout after {effective_timeout:.3f}s",
                )

        return asyncio.create_task(_runner())

    async def subscribe(self, count: Optional[int] = None) -> AsyncIterator[HubResult]:
        """Subscribe to inference results.

        Yields results as they arrive from published requests.

        Args:
            count: If provided, stop after receiving this many results.
                   If None, yields indefinitely until no pending requests remain.

        Yields:
            HubResult objects containing request_id, model, data, ok, and error.

        Example:
            >>> await hub.publish(ModelType.ZOEDEPTH, request_id="d1", image_input=img)
            >>> await hub.publish(ModelType.GSAM2, request_id="m1", image_input=img, prompt="cat")
            >>> async for result in hub.subscribe(count=2):
            ...     if result.ok:
            ...         print(f"{result.request_id}: shape={result.data.shape}")
            ...     else:
            ...         print(f"{result.request_id}: error={result.error}")
        """
        received = 0

        while True:
            # Check termination conditions
            if count is not None and received >= count:
                break
            if count is None and not self._pending_requests and self._result_queue.empty():
                break

            try:
                # Use timeout to periodically check pending_requests
                result = await asyncio.wait_for(self._result_queue.get(), timeout=0.1)
                received += 1
                yield result
            except asyncio.TimeoutError:
                # Check if we should continue waiting
                if count is None and not self._pending_requests:
                    break
                continue

    async def collect(self, count: Optional[int] = None) -> list[HubResult]:
        """Collect all results into a list.

        Convenience method that collects subscribe() results.

        Args:
            count: If provided, collect exactly this many results.
                   If None, collect until no pending requests remain.

        Returns:
            List of HubResult objects.
        """
        results = []
        async for result in self.subscribe(count=count):
            results.append(result)
        return results

    # -------------------------------------------------------------------------
    # Context Manager
    # -------------------------------------------------------------------------

    async def __aenter__(self) -> "CortexHubClient":
        await self.connect()
        return self

    async def __aexit__(self, *_) -> bool:
        await self.close()
        return False
