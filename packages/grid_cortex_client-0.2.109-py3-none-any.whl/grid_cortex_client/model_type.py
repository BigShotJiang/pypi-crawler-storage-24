"""
AUTO-GENERATED enum of all model IDs for CortexClient.run().

Use with: client.run(ModelType.MODEL_NAME, **kwargs)

Run   python -m grid_cortex_client.tools.generate_enum
whenever you add/remove a model.  Never edit manually – GRID-Rake
needs this file to exist in the source tree so that Griffe can
scrape the rich doc-strings and examples.
"""
from enum import Enum


class ModelType(Enum):
    FAST_FOUNDATIONSTEREO = "fast-foundationstereo"
    """
    Estimate depth from stereo pair using Fast-FoundationStereo.

    ~10x faster than the original FoundationStereo while maintaining
    comparable accuracy (14.6M params, real-time capable).

    Args:
        left_image (Union[str, Image.Image, np.ndarray]): Left stereo image.
        right_image (Union[str, Image.Image, np.ndarray]): Right stereo image.
        aux_args (Dict[str, Any]): Camera parameters:
            - "K": 3x3 camera intrinsics matrix
            - "baseline": Stereo baseline in meters
            - "hiera": Use hierarchical coarse-to-fine inference (bool)
            - "valid_iters": Number of GRU refinement iterations (default 8)
        timeout (float | None): Optional HTTP timeout.

    Returns:
        np.ndarray: Depth map as numpy array (H, W) with dtype float32.
            Values represent metric depth in meters.

    Raises:
        ValueError: If images cannot be loaded or aux_args is invalid.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> K = np.array([[525, 0, 320], [0, 525, 240], [0, 0, 1]], dtype=np.float32)
        >>> aux = {"K": K, "baseline": 0.1, "hiera": False, "valid_iters": 8}
        >>> left_image = np.array(Image.open("left.jpg"))
        >>> right_image = np.array(Image.open("right.jpg"))
        >>> depth = client.run(ModelType.FAST_FOUNDATIONSTEREO, left_image=left_image, right_image=right_image, aux_args=aux)
        >>> print(depth.shape)  # (480, 640)
    """
    FINETUNE_PI05 = "finetune_pi05"
    """
    Submit a finetuning job.

    Args:
        repo_id (str): HuggingFace dataset repo id.
        config_name (str | None): Optional experiment config name.
        exp_name (str | None): Optional experiment run name.
        num_train_steps (int | None): Override training steps.
        log_interval (int | None): Override log interval.
        action_horizon (int | None): Override action horizon.
        max_frames (int | None): Limit frames for norm stats.
        job_id (str | None): Optional job id override.
        user_id (int | None): Optional user id header (x-user-id).
        timeout (float | None): Optional HTTP timeout.

    Returns:
        Dict[str, Any]: Job submission response with job_id, status, and paths.

    Raises:
        RuntimeError: If no HTTP transport is configured.
        ValueError: If input is invalid.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> client = CortexClient()
        >>> resp = client.run(ModelType.FINETUNE_PI05, repo_id="dummy/repo", num_train_steps=100)
        >>> print(resp["status"])  # PENDING
    """
    FOUNDATIONSTEREO = "foundationstereo"
    """
    Estimate depth from stereo pair using FoundationStereo.

    Args:
        left_image (Union[str, Image.Image, np.ndarray]): Left stereo image.
        right_image (Union[str, Image.Image, np.ndarray]): Right stereo image.
        aux_args (Dict[str, Any]): Camera parameters:
            - "K": 3x3 camera intrinsics matrix
            - "baseline": Stereo baseline in meters
            - "hiera": Hierarchy level (0-2)
            - "valid_iters": Number of valid iterations
        timeout (float | None): Optional HTTP timeout.

    Returns:
        np.ndarray: Depth map as numpy array (H, W) with dtype float32.
            Values represent metric depth in meters.

    Raises:
        ValueError: If images cannot be loaded or aux_args is invalid.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> K = np.array([[525, 0, 320], [0, 525, 240], [0, 0, 1]], dtype=np.float32)
        >>> aux = {"K": K, "baseline": 0.1, "hiera": 0, "valid_iters": 32}
        >>> left_image = np.array(Image.open("left.jpg"))
        >>> right_image = np.array(Image.open("right.jpg"))
        >>> depth = client.run(ModelType.FOUNDATIONSTEREO, left_image=left_image, right_image=right_image, aux_args=aux)
        >>> print(depth.shape)  # (480, 640)
    """
    GRASPGEN = "graspgen"
    """
    Generate grasps using GraspGen.

    Args:
        aux_args (Dict[str, Any]): Auxiliary parameters (num_grasps, gripper_config, camera_extrinsics).
        depth_image (Union[str, Image.Image, np.ndarray, None]): Depth image (required if point_cloud is None).
        seg_image (Union[str, Image.Image, np.ndarray, None]): Segmentation mask (required if point_cloud is None).
        camera_intrinsics (Union[str, np.ndarray, None]): 3x3 intrinsics matrix (required if point_cloud is None).
        point_cloud (Union[str, np.ndarray, Sequence[Sequence[float]], None]): Optional (N,3) point cloud as array/list/path to .npy. When
            provided, depth/seg/intrinsics are ignored and sent directly.
        timeout (float | None): Optional HTTP timeout.

    Returns:
        Dict with:
            - grasps: Array of 4x4 grasp poses (N, 4, 4)
            - confidence: Array of confidence scores (N,)
            - latency_ms: Optional server-reported latency in milliseconds

    Raises:
        ValueError: If images cannot be loaded or parameters are invalid.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> K = np.eye(3)
        >>> aux = {"num_grasps": 128, "gripper_config": "single_suction_cup_30mm", "camera_extrinsics": np.eye(4)}
        >>> depth_image = np.load("depth.npy")
        >>> seg_image = np.array(Image.open("seg.png"))
        >>> grasps, conf = client.run(ModelType.GRASPGEN, depth_image=depth_image, seg_image=seg_image, camera_intrinsics=K, aux_args=aux)
        >>> print(f"Generated {len(grasps)} grasps")
    """
    GSAM2 = "gsam2"
    """
    Segment objects in image using text prompt.

    Args:
        image_input (Union[str, Image.Image, np.ndarray]): RGB image as file path, URL, PIL Image, or numpy array.
        prompt (str): Text description of objects to segment.
        box_threshold (float | None): Optional confidence threshold (0.0-1.0) for filtering detections.
        text_threshold (float | None): Optional text confidence threshold (0.0-1.0).
        nms_threshold (float | None): Optional Non-Maximum-Suppression threshold (0.0-1.0).
        timeout (float | None): Optional timeout in seconds for the HTTP request.

    Returns:
        np.ndarray: Binary segmentation mask as numpy array (H, W) with dtype uint8.
            Foreground pixels are 255, background pixels are 0.

    Raises:
        ValueError: If image cannot be loaded or prompt is empty.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> image = np.array(Image.open("cat.jpg"))
        >>> mask = client.run(ModelType.GSAM2, image_input=image, prompt="a cat")
        >>> print(mask.shape)  # (480, 640)
    """
    MOONDREAM = "moondream"
    """
    Generate text response from image using Moondream.

    Args:
        image_input (Union[str, Image.Image, np.ndarray]): RGB image.
        task (str): Task type - "vqa" (Visual Question Answering), "caption" (Image Captioning), 
                   "detect" (Object Detection), or "point" (Pointing/Clickable points).
        prompt (str): Text prompt/question about the image (required for vqa, detect, point tasks).
        length (str): Caption length - "short" or "normal" (only for caption task).
        timeout (float | None): Optional HTTP timeout.

    Returns:
        Dict[str, Any]: Backend JSON response containing generated text or structured data.
        - For vqa/caption: {"output": "text response"}
        - For detect: {"output": {"boxes": [...], "scores": [...], "labels": [...]}}
        - For point: {"output": numpy array of (x,y) points}

    Raises:
        ValueError: If image cannot be loaded or required parameters are missing.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        VQA (Visual Question Answering):
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> image = np.array(Image.open("path/to/kitchen.jpg"))
        >>> result = client.run(ModelType.MOONDREAM, image_input=image, task="vqa", prompt="How many cups are on the table?")
        >>> print(result["output"])  # Text answer

        Image Captioning:
        >>> result = client.run(ModelType.MOONDREAM, image_input=image, task="caption", length="short")
        >>> print(result["output"])  # Text caption

        Object Detection:
        >>> result = client.run(ModelType.MOONDREAM, image_input=image, task="detect", prompt="cup, plate, bowl")
        >>> print(result["output"])  # Dict with boxes, scores, labels

        Pointing (clickable points):
        >>> result = client.run(ModelType.MOONDREAM, image_input=image, task="point", prompt="the red cup")
        >>> print(result["output"])  # Numpy array of (x,y) points
    """
    ONEFORMER = "oneformer"
    """
    Segment an image using OneFormer.

    Args:
        image_input (Union[str, Image.Image, np.ndarray]): RGB input image.
        mode (str): "panoptic", "semantic" or "instance".
        timeout (float | None): Optional HTTP timeout.

    Returns:
        Dict[str, Any]: Backend-specific segmentation output.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> image = np.array(Image.open("cat.jpg"))
        >>> result = client.run(ModelType.ONEFORMER, image_input=image, mode="semantic")
    """
    OWLV2 = "owlv2"
    """
    Detect objects in image using text prompt.

    Args:
        image_input (Union[str, Image.Image, np.ndarray]): RGB image as file path, URL, PIL Image, or numpy array.
        prompt (str): Text description of objects to detect.
        box_threshold (float | None): Optional confidence threshold (0.0-1.0) for filtering detections.
        timeout (float | None): Optional timeout in seconds for the HTTP request.

    Returns:
        Dictionary with keys:
            - "boxes": List of bounding boxes as [x1, y1, x2, y2] coordinates
            - "scores": List of confidence scores (0.0-1.0)
            - "labels": List of label indices

    Raises:
        ValueError: If image cannot be loaded or prompt is empty.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> image = np.array(Image.open("cat.jpg"))
        >>> dets = client.run(ModelType.OWLV2, image_input=image, prompt="a cat")
        >>> print(f"Found {len(dets['boxes'])} objects")
    """
    PI05 = "pi05"
    """
    Run PI05 policy inference on robot observations.

    Args:
        base_rgb (Union[str, Image.Image, np.ndarray]): Base camera RGB image as file path, URL, PIL Image, or numpy array.
        wrist_rgb (Union[str, Image.Image, np.ndarray]): Wrist camera RGB image as file path, URL, PIL Image, or numpy array.
        joints (Union[np.ndarray, list]): Joint positions as numpy array or list.
        gripper (Union[np.ndarray, list]): Gripper position as numpy array or list.
        state (Union[np.ndarray, list]): Robot state as numpy array or list (concatenation of joints and gripper).
        prompt (Optional[str]): Optional task prompt string.
        timeout (float | None): Optional timeout in seconds for the HTTP request.

    Returns:
        Action dictionary containing:
        - "actions": numpy array of shape (horizon, action_dim) with predicted actions
        - Other fields from policy.infer() (e.g., "state", "policy_timing", etc.)

    Raises:
        ValueError: If inputs are invalid.
        RuntimeError: If no HTTP transport is configured.

    Example:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> client = CortexClient()
        >>> base_img = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
        >>> wrist_img = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
        >>> joints = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6])
        >>> gripper = np.array([0.5])
        >>> state = np.concatenate([joints, gripper])
        >>> action = client.run(
        ...     ModelType.PI05,
        ...     base_rgb=base_img,
        ...     wrist_rgb=wrist_img,
        ...     joints=joints,
        ...     gripper=gripper,
        ...     state=state,
        ...     prompt="pick up the cup"
        ... )
        >>> print(action["actions"].shape)
    """
    QWEN_VL = "qwen_vl"
    """
    Generate text response from image using Qwen3-VL.

    Args:
        image_input (Union[str, Image.Image, np.ndarray]): RGB image.
        prompt (str): Text prompt/question about the image.
        max_new_tokens (int): Maximum number of tokens to generate.
        temperature (float): Sampling temperature (0 = greedy).
        timeout (float | None): Optional HTTP timeout.

    Returns:
        Dict[str, Any]: Backend JSON response containing:
        - "output": Generated text response string.
        - "latency_ms": Server-side processing time.
        - "gpu_stats": GPU memory usage statistics.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> image = np.array(Image.open("path/to/image.jpg"))
        >>> result = client.run(ModelType.QWEN_VL, image_input=image, prompt="What do you see?")
        >>> print(result["output"])  # Text answer
    """
    SAM2 = "sam2"
    """
    Segment image with SAM-2 given point/box prompts.

    Args:
        image_input (Union[str, Image.Image, np.ndarray]): RGB image.
        prompts (List[List[int]]): List of ``[x, y]`` pixel coordinates.
        labels (List[int]): 1 = foreground, 0 = background per prompt.
        multimask_output (bool): If *True* returns multiple masks.
        mode (str): Endpoint mode; only "image" currently supported.
        timeout (float | None): HTTP timeout.

    Returns:
        Dict[str, Any]: Backend JSON containing encoded masks / scores.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> image = np.array(Image.open("cat.jpg"))
        >>> mask_json = client.run(
        ...     ModelType.SAM2,
        ...     image_input=image,
        ...     prompts=[[320, 240]],
        ...     labels=[1],
        ... )
    """
    SAM3 = "sam3"
    """
    Segment an image with SAM-3 using exactly one prompt type.

    Args:
        image_input (Union[str, Image.Image, np.ndarray]): RGB image as file path, URL, PIL Image, or numpy array.
        text (Optional[str]): Text prompt describing objects to segment (exclusive with points/boxes).
        points (Optional[Iterable[Iterable[float]]]): List of [x, y] point coordinates (exclusive with text/boxes).
        boxes (Optional[Iterable[Iterable[float]]]): List of [x0, y0, x1, y1] box coordinates (exclusive with text/points).
        labels (Optional[Iterable[int]]): Required for points/boxes. 1=foreground, 0=background.
        timeout (Optional[float]): Optional HTTP timeout in seconds.

    Returns:
        np.ndarray: Binary segmentation mask as numpy array (H, W) with dtype uint8.
            Foreground pixels are 255, background pixels are 0.

    Raises:
        ValueError: If multiple prompt types provided, labels missing, or invalid inputs.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> image = np.array(Image.open("cat.jpg"))
        
        >>> # Text prompt
        >>> mask = client.run(ModelType.SAM3, image_input=image, text="cat")
        
        >>> # Point prompts
        >>> mask = client.run(
        ...     ModelType.SAM3, image_input=image,
        ...     points=[[320, 240]], labels=[1]
        ... )
        
        >>> # Box prompts
        >>> mask = client.run(
        ...     ModelType.SAM3, image_input=image,
        ...     boxes=[[100, 120, 520, 480]], labels=[1]
        ... )
    """
    UR5E_PYROKI_COLLISION_BATCH = "ur5e-pyroki-collision-batch"
    """
    Generate batch trajectories using UR5e PyRoKi Collision Batch.

    Args:
        aux_args (Dict[str, Any]): Auxiliary parameters (robot_radius, radius_removal_nb, etc.).
        depth_image (Union[str, Image.Image, np.ndarray]): Depth image (path/URL/PIL/ndarray).
        camera_intrinsics (Union[str, np.ndarray]): 3x3 camera intrinsics matrix.
        T_cam_world (Union[str, np.ndarray]): 4x4 camera-to-world transformation matrix.
        robot_joint_positions (Union[str, np.ndarray, Sequence[float]]): Robot joint positions (7,) array or list.
        curr_xyzs (Union[str, np.ndarray, Sequence[Sequence[float]]]): Current positions (N, 3) array or list of lists.
        curr_wxyzs (Union[str, np.ndarray, Sequence[Sequence[float]]]): Current quaternions (N, 4) array or list of lists (wxyz order).
        target_xyzs (Union[str, np.ndarray, Sequence[Sequence[float]]]): Target positions (N, 3) array or list of lists.
        target_wxyzs (Union[str, np.ndarray, Sequence[Sequence[float]]]): Target quaternions (N, 4) array or list of lists (wxyz order).
        capsule_transform (Union[str, np.ndarray]): 4x4 transformation matrix for capsules.
        timeout (float | None): Optional HTTP timeout.

    Returns:
        Dict with:
            - output: Array of trajectories (N, timesteps, 7)
            - latency_ms: Processing time in milliseconds
            - debug: Dict with point cloud and capsule debug info
                - pc: Point cloud array
                - scene_capsules: Scene capsule poses
                - transformed_capsules: Transformed capsule poses

    Raises:
        ValueError: If inputs cannot be loaded or parameters are invalid.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> client = CortexClient()
        >>> K = np.eye(3)
        >>> T_cam_world = np.eye(4)
        >>> robot_joints = np.zeros(7)
        >>> curr_xyzs = np.random.uniform(-1, 1, size=(20, 3))
        >>> curr_wxyzs = np.array([[1.0, 0.0, 0.0, 0.0]] * 20)
        >>> target_xyzs = np.random.uniform(-1, 1, size=(20, 3))
        >>> target_wxyzs = np.array([[1.0, 0.0, 0.0, 0.0]] * 20)
        >>> capsule_transform = np.eye(4)
        >>> aux = {
        ...     "robot_radius": 0.05,
        ...     "radius_removal_nb": 10,
        ...     "radius_removal_dist": 0.06,
        ...     "num_points": 1200,
        ...     "workspace_xy_dist": 1.0,
        ...     "capsule_radius_scale": 1.0,
        ...     "capsule_length_scale": 1.0,
        ...     "capsule_radius_amt": 0.0,
        ...     "capsule_length_amt": 0.0,
        ... }
        >>> depth = np.random.uniform(0.5, 0.6, size=(480, 640))
        >>> result = client.run(
        ...     ModelType.UR5E_PYROKI_COLLISION_BATCH,
        ...     depth_image=depth,
        ...     camera_intrinsics=K,
        ...     T_cam_world=T_cam_world,
        ...     robot_joint_positions=robot_joints,
        ...     curr_xyzs=curr_xyzs,
        ...     curr_wxyzs=curr_wxyzs,
        ...     target_xyzs=target_xyzs,
        ...     target_wxyzs=target_wxyzs,
        ...     capsule_transform=capsule_transform,
        ...     aux_args=aux
        ... )
        >>> trajs = result["output"]
        >>> print(f"Generated {trajs.shape[0]} trajectories")
        >>> print(f"Shape: {trajs.shape}")  # (20, 10, 7)
    """
    UR5E_PYROKI_FK = "ur5e-pyroki-fk"
    """
    Compute forward kinematics for a batch of joint states.

    Args:
        batch_joint_states (Union[str, np.ndarray, Sequence[Sequence[float]]]): Batch of joint configurations (N, 7) array or list of lists.
            Can also be a path to a .npy file. Each row represents a 7-DOF joint configuration.
        timeout (float | None): Optional HTTP timeout.

    Returns:
        Dict with:
            - output: Array of end-effector poses (N, 7) in wxyz_xyz format
                (quaternion wxyz + position xyz)
            - latency_ms: Processing time in milliseconds

    Raises:
        ValueError: If inputs cannot be loaded or parameters are invalid.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Examples:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> client = CortexClient()
        >>> # Create a batch of 20 joint configurations
        >>> batch_joint_states = np.random.uniform(-1.0, 1.0, size=(20, 7)).astype(np.float32)
        >>> result = client.run(
        ...     ModelType.UR5E_PYROKI_FK,
        ...     batch_joint_states=batch_joint_states
        ... )
        >>> poses = result["output"]
        >>> print(f"Computed {poses.shape[0]} end-effector poses")
        >>> print(f"Shape: {poses.shape}")  # (20, 7)
    """
    ZOEDEPTH = "zoedepth"
    """
    Estimate depth from single RGB image.

    Args:
        image_input (Union[str, Image.Image, np.ndarray]): RGB image as file path, URL, PIL Image, or numpy array.
        timeout (float | None): Optional timeout in seconds for the HTTP request.

    Returns:
        np.ndarray: Depth map as numpy array (H, W) with dtype float32.
            Values represent metric depth in meters.

    Raises:
        ValueError: If image cannot be loaded.
        RuntimeError: If no HTTP transport is configured.
        Exception: If the HTTP request fails.

    Example:
        >>> from grid_cortex_client import CortexClient, ModelType
        >>> import numpy as np
        >>> from PIL import Image
        >>> client = CortexClient()
        >>> image = np.array(Image.open("cat.jpg"))
        >>> depth = client.run(ModelType.ZOEDEPTH, image_input=image)
        >>> print(depth.shape)  # (480, 640)
    """
