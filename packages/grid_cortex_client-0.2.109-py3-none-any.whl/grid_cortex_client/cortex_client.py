# filepath: /home/pranay/GRID/Grid-Cortex-Infra/grid-cortex-client/src/grid_cortex_client/cortex_client.py
import logging
import inspect
from collections.abc import Mapping
from typing import Any, Dict, Optional, Tuple, Type, Union

# ---------------------------------------------------------------------------
# NOTE: ModelType enum is now generated automatically in
#       grid_cortex_client/model_type.py by the code-generator
#       `python -m grid_cortex_client.tools.generate_enum`.
# ---------------------------------------------------------------------------

from .model_type import ModelType  # static enum for GRID-Rake scraping

from .client import AsyncHTTPClient, CortexAPIError, CortexNetworkError, HTTPClient
from .models import BaseModel
from .models.base_model import get_registry

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Runtime safety-net: warn if the generated enum and registry diverge.
# ---------------------------------------------------------------------------


def _ensure_enum_sync() -> None:
    """Warn if `ModelType` and `BaseModel` registry are out of sync.

    Developers should regenerate the enum via
    `python -m grid_cortex_client.tools.generate_enum` whenever they add or
    rename a wrapper.  This check prevents silent mismatches in production.
    """

    enum_values = {m.value for m in ModelType}
    registered_values = set(get_registry().keys())

    missing = registered_values - enum_values
    extra = enum_values - registered_values

    if missing:
        logger.warning(
            "Model wrappers %s are not in ModelType enum – run the generator.",
            sorted(missing),
        )

    if extra:
        logger.warning(
            "Enum contains obsolete members %s – run the generator.",
            sorted(extra),
        )


# ---------------------------------------------------------------------------
# Base class with shared logic
# ---------------------------------------------------------------------------


class _CortexClientBase:
    """Base class containing shared logic for sync and async Cortex clients."""

    _MODEL_ID_TO_HANDLER_CLASS: Dict[str, Type[BaseModel]] = get_registry()

    def _get_handler_class(
        self, model_id: Union[str, ModelType]
    ) -> Optional[Type[BaseModel]]:
        """Look up the handler class for a model ID."""
        model_id_str = (
            model_id.value if isinstance(model_id, ModelType) else str(model_id)
        )
        for keyword, HClass in self._MODEL_ID_TO_HANDLER_CLASS.items():
            if keyword in model_id_str.lower():
                return HClass
        return None

    def _preprocess(
        self,
        model: BaseModel,
        input_data: Any,
        preprocess_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """Run preprocessing and return the payload."""
        _preprocess_kwargs = preprocess_kwargs or {}

        try:
            if isinstance(input_data, Mapping):
                input_dict = dict(input_data)
                merged_kwargs = {**input_dict, **_preprocess_kwargs}

                signature = inspect.signature(model.preprocess)
                parameters = list(signature.parameters.values())
                expects_input_data = (
                    bool(parameters)
                    and parameters[0].name == "input_data"
                    and parameters[0].kind
                    in (
                        inspect.Parameter.POSITIONAL_ONLY,
                        inspect.Parameter.POSITIONAL_OR_KEYWORD,
                    )
                )

                if expects_input_data:
                    self._validate_required_preprocess_args(
                        signature,
                        provided_keys={"input_data", *_preprocess_kwargs.keys()},
                    )
                    payload = model.preprocess(input_dict, **_preprocess_kwargs)
                else:
                    self._validate_required_preprocess_args(
                        signature,
                        provided_keys=set(merged_kwargs.keys()),
                    )
                    payload = model.preprocess(**merged_kwargs)
            else:
                payload = model.preprocess(input_data, **_preprocess_kwargs)

            if "model_id" in payload and payload["model_id"] != model.model_id:
                logger.warning(
                    f"Payload 'model_id' ('{payload.get('model_id')}') from preprocess "
                    f"does not match model instance's model_id ('{model.model_id}'). "
                    f"Overwriting with instance's model_id."
                )
            elif "model_id" not in payload:
                logger.debug(
                    f"Payload from preprocess for model '{model.model_id}' does not contain 'model_id'. "
                    f"'{self.__class__.__name__}._run_model' will add it."
                )
            payload["model_id"] = model.model_id
            return payload

        except TypeError:
            raise
        except Exception as e:
            logger.error(
                f"Preprocessing failed for model {model.model_id}: {e}", exc_info=True
            )
            raise ValueError(f"Preprocessing error for {model.model_id}: {e}") from e

    def _validate_required_preprocess_args(
        self, signature: inspect.Signature, *, provided_keys: set[str]
    ) -> None:
        missing: list[str] = []
        for param in signature.parameters.values():
            if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
            if param.default is not inspect.Parameter.empty:
                continue
            if param.name not in provided_keys:
                missing.append(param.name)

        if missing:
            raise ValueError(f"Missing required argument(s): {', '.join(missing)}")

    def _postprocess(
        self,
        model: BaseModel,
        api_response: Dict[str, Any],
        postprocess_kwargs: Optional[Dict[str, Any]] = None,
    ) -> Any:
        """Run postprocessing on API response."""
        _postprocess_kwargs = postprocess_kwargs or {}

        try:
            _postprocess_kwargs["model_name"] = model.model_id
            return model.postprocess(api_response, **_postprocess_kwargs)
        except Exception as e:
            logger.error(
                f"Postprocessing failed for model {model.model_id}: {e}", exc_info=True
            )
            raise ValueError(f"Postprocessing error for {model.model_id}: {e}") from e

    def available_models(self) -> list[str]:
        """Return all registered model identifiers.

        This method provides a complete list of all available models that can be
        used with the CortexClient. Essential for LLM agents to discover what
        models are available before attempting to use them.

        Returns:
            A sorted list of model identifiers (e.g., ["gsam2", "owlv2", "zoedepth"]).
            These strings can be used directly with :py:meth:`run` and :py:meth:`help`.

        Examples:
            >>> client = CortexClient()
            >>> models = client.available_models()
            >>> print(models)  # ['gsam2', 'owlv2', 'zoedepth']
            >>> client.run(models[0], image_input=img)  # Use first available model
        """
        return sorted(self._MODEL_ID_TO_HANDLER_CLASS.keys())

    def help(self, model_id: str) -> str:  # noqa: D401 simple helper
        """Return comprehensive documentation for a model.

        This method provides complete API documentation for any registered model,
        including usage examples, parameter descriptions, return types, and error
        conditions. Essential for LLM agents to understand how to interact with
        specific models before calling :py:meth:`run`.

        Args:
            model_id: Canonical model identifier (e.g., "zoedepth", "owlv2", "gsam2").

        Returns:
            A formatted string containing:
            - Class-level docstring with usage examples and parameter descriptions
            - Preprocess method documentation (input parameters and validation)
            - Postprocess method documentation (output format and data types)

        Raises:
            NotImplementedError: If model_id is not registered or not found.

        Examples:
            >>> client = CortexClient()
            >>> docs = client.help("zoedepth")
            >>> print(docs)  # Shows complete zoedepth documentation
            >>>
            >>> # For LLM agents: discover model capabilities
            >>> models = client.available_models()
            >>> for model in models:
            ...     print(f"=== {model} ===")
            ...     print(client.help(model))
        """
        handler_cls = self._get_handler_class(model_id)
        if handler_cls is None:
            raise NotImplementedError(
                f"No model handler registered for model_id containing '{model_id}'."
            )

        cls_doc = (handler_cls.__doc__ or "").strip()
        pre_doc = (handler_cls.preprocess.__doc__ or "").strip()
        post_doc = (handler_cls.postprocess.__doc__ or "").strip()

        return (
            f"Model: {model_id}\n\n{cls_doc}\n\n"
            f"---\nPreprocess\n---\n{pre_doc}\n\n"
            f"---\nPostprocess\n---\n{post_doc}\n"
        )

    def _resolve_handler(
        self, model_id: Union[str, ModelType]
    ) -> Tuple[str, Type[BaseModel]]:
        """Resolve model_id to string and handler class, raising if not found."""
        model_id_str = (
            model_id.value if isinstance(model_id, ModelType) else str(model_id)
        )

        logger.info(
            f"Attempting to run model '{model_id_str}'"
        )

        HandlerClass = self._get_handler_class(model_id_str)
        if HandlerClass is not None:
            logger.info(
                f"Found handler {HandlerClass.__name__} for model_id '{model_id_str}'."
            )
            return model_id_str, HandlerClass

        logger.error(
            f"No suitable model handler found for model_id: {model_id}. "
            f"Available handlers are for keywords: {list(self._MODEL_ID_TO_HANDLER_CLASS.keys())}"
        )
        raise NotImplementedError(
            f"No model handler configured for model_id containing typical keywords for known types: '{model_id_str}'. "
            f"Please ensure the model_id is correct or update the client's model handler registry."
        )


class CortexClient(_CortexClientBase):
    """Client for interacting with Grid Cortex Ray Serve deployments."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """
        Initializes the CortexClient.

        Args:
            api_key: API key. Uses GRID_CORTEX_API_KEY env var if None.
            base_url: Base URL of the Cortex API. If None, uses GRID_CORTEX_BASE_URL env var or HTTPClient's default.
            timeout: Default timeout for HTTP requests in seconds.
        """
        _ensure_enum_sync()

        self.http_client = HTTPClient(
            api_key=api_key, base_url=base_url, timeout=timeout
        )

        effective_http_base_url = self.http_client._client.base_url
        logger.info(
            f"CortexClient initialized. HTTPClient target: {effective_http_base_url}"
        )

    def _make_request(
        self,
        endpoint: str,
        payload: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Helper method to make POST requests to the /run endpoint."""
        try:
            import grid_cortex_client.utils as _u
            packed = _u.packb(payload)
            return self.http_client.post(endpoint, data=packed, timeout=timeout)
        except (CortexAPIError, CortexNetworkError) as e:
            logger.error(f"Request to {endpoint} failed: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error during request to {endpoint}: {e}")
            raise CortexNetworkError(f"An unexpected error occurred: {e}") from e

    def _run_model(
        self,
        model: BaseModel,
        input_data: Any,
        preprocess_kwargs: Optional[Dict[str, Any]] = None,
        postprocess_kwargs: Optional[Dict[str, Any]] = None,
        visualize: bool = False,
        visualization_kwargs: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        raw_response: bool = False,
    ) -> Any:
        """
        Framework helper: execute *model* end-to-end.

        This method orchestrates the preprocessing, API request, postprocessing,
        and optional visualization steps. This is **not** part of the public API.
        External callers should use
        :py:meth:`CortexClient.run` or call ``WrapperClass.run`` directly.

        Args:
            model: An instance of a BaseModel subclass (e.g., DepthModel).
            input_data: The raw input data for the model.
            preprocess_kwargs: Additional keyword arguments for the model's preprocess method.
            postprocess_kwargs: Additional keyword arguments for the model's postprocess method.
            visualize: If True, attempts to run the model's visualize method.
            visualization_kwargs: Additional keyword arguments for the model's visualize method.
            timeout: Optional timeout in seconds for the request.
            raw_response: If True, returns the raw API response without postprocessing.

        Returns:
            The processed output from the model if *raw_response* is False;
            the raw API response if *raw_response* is True.

        Raises:
            CortexAPIError: If the API returns an error.
            CortexNetworkError: If a network error occurs.
            ValueError: If preprocessing or postprocessing fails.
        """
        logger.info(
            f"[internal] _run_model {model.model_id} input type: {type(input_data)}"
        )

        # Preprocess
        payload = self._preprocess(model, input_data, preprocess_kwargs)

        # Make request
        specific_model_endpoint = f"/{model.model_id}/run"
        logger.info(
            f"Requesting model execution from: {specific_model_endpoint} for model_id: {model.model_id}"
        )

        api_response = self._make_request(
            specific_model_endpoint, payload=payload, timeout=timeout
        )
        logger.info(f"API response for model {model.model_id}: {api_response}")

        if raw_response:
            logger.info(f"Returning raw API response for model {model.model_id}.")
            return api_response

        # Postprocess
        processed_output = self._postprocess(model, api_response, postprocess_kwargs)

        # Optional visualization
        if visualize:
            _visualization_kwargs = visualization_kwargs or {}
            try:
                logger.info(f"Attempting visualization for model {model.model_id}.")
                model.visualize(
                    processed_output, original_input=input_data, **_visualization_kwargs
                )
            except Exception as e:
                logger.error(
                    f"Visualization failed for model {model.model_id}: {e}",
                    exc_info=True,
                )

        logger.info(f"Successfully ran model {model.model_id}.")
        return processed_output

    def run(
        self,
        model_id: Union[str, ModelType],
        timeout: Optional[float] = None,
        debug: bool = False,
        raw_response: bool = False,
        **kwargs: Any,
    ) -> Any:
        """Execute inference using a specified model with given inputs.

        This is the primary method for running AI model inference. It automatically
        handles model discovery, input preprocessing, API communication, and output
        postprocessing. Essential for LLM agents to perform actual model inference
        after discovering available models and understanding their requirements.

        Args:
            model_id: The identifier of the model to run (use :py:meth:`available_models`
                to see all available options). Examples: "zoedepth", "owlv2", "gsam2".
            timeout: Optional timeout in seconds for the HTTP request. If None, uses
                the client's default timeout.
            debug: If True, enables detailed logging for this specific call to help
                troubleshoot issues.
            raw_response: If True, returns the raw API response without postprocessing.
            **kwargs: Model-specific input parameters. Use :py:meth:`help` to see
                required parameters for each model. Common parameters include:
                - image_input: Image data (path, URL, PIL.Image, or np.ndarray)
                - prompt: Text prompt for detection/segmentation models
                - box_threshold: Confidence threshold for detection models

        Returns:
            Model-specific output object. Exact shape/type depends on the chosen model and is fully documented in ``grid_cortex_client.model_type.ModelType``.

        Raises:
            NotImplementedError: If model_id is not found in available models.
            CortexAPIError: If the API returns an error response.
            CortexNetworkError: If network communication fails.
            ValueError: If input validation or processing fails.

        Examples:
            >>> client = CortexClient()
            >>>
            >>> # Depth estimation
            >>> depth = client.run("zoedepth", image_input=img)
            >>> print(depth.values.shape)  # (H, W)
            >>>
            >>> # Object detection
            >>> dets = client.run("owlv2", image_input=img, prompt="cat")
            >>> print(dets["scores"])  # [0.83, 0.79, ...]
            >>>
            >>> # Image segmentation
            >>> mask = client.run("gsam2", image_input=img, prompt="cat")
            >>> print(mask.values.shape)  # (H, W)

        Note:
            Before calling this method, LLM agents should:
            1. Call :py:meth:`available_models` to see what's available
            2. Call :py:meth:`help` to understand required parameters
            3. Prepare inputs according to the model's requirements
        """
        original_level = None
        library_logger = logging.getLogger("grid_cortex_client")

        if debug:
            original_level = library_logger.getEffectiveLevel()
            library_logger.setLevel(logging.DEBUG)
            logger.info(
                "Debug mode enabled for this run. Setting grid_cortex_client logger to DEBUG."
            )

        try:
            model_id_str, HandlerClass = self._resolve_handler(model_id)
            logger.info(f"Running model '{model_id_str}' with inputs: {list(kwargs.keys())}")

            model_handler = HandlerClass(transport=self.http_client)
            return self._run_model(
                model=model_handler,
                input_data=kwargs,
                timeout=timeout,
                raw_response=raw_response,
            )

        except (
            CortexAPIError,
            CortexNetworkError,
            ValueError,
            TypeError,
            NotImplementedError,
        ) as e:
            logger.error(f"Error running model '{model_id}': {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(
                f"Unexpected error running model '{model_id}': {e}", exc_info=True
            )
            raise CortexNetworkError(
                f"An unexpected error occurred while running model {model_id}: {e}"
            ) from e
        finally:
            if debug and original_level is not None:
                library_logger.setLevel(original_level)
                logger.info(
                    f"Debug mode disabled. Restored grid_cortex_client logger level to {logging.getLevelName(original_level)}."
                )

    def get_info(self) -> Dict[str, Any]:
        """Get Grid-Cortex server version and deployed models status.

        Fetches real-time information about the Cortex deployment including
        version and current model replica counts.

        Returns:
            Dictionary containing:
            - version (str): Grid-Cortex version (e.g., "v0.2.49")
            - models (list): List of deployed models with:
                - name (str): Model identifier
                - status (str): Deployment status ("RUNNING", etc.)
                - route (str): HTTP route prefix
                - replicas (int): Number of running replicas

        Raises:
            CortexAPIError: If the API returns an error.
            CortexNetworkError: If network communication fails.

        Examples:
            >>> client = CortexClient()
            >>> info = client.get_info()
            >>> print(info["version"])
            "v0.2.49"
            >>> print(f"ZoeDepth has {info['models'][0]['replicas']} replicas")
            ZoeDepth has 1 replicas
        """
        try:
            return self.http_client.get("/ws/info")
        except (CortexAPIError, CortexNetworkError) as e:
            logger.error(f"Failed to fetch server info: {e}")
            raise

    def close(self):
        """Closes the underlying HTTP client."""
        self.http_client.close()
        logger.info("CortexClient closed.")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class AsyncCortexClient(_CortexClientBase):
    """Async client for interacting with Grid Cortex Ray Serve deployments."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        timeout: float = 30.0,
    ):
        """Initialize the AsyncCortexClient.

        Args:
            api_key: API key. Uses GRID_CORTEX_API_KEY env var if None.
            base_url: Base URL of the Cortex API. If None, uses GRID_CORTEX_BASE_URL env var.
            timeout: Default timeout for HTTP requests in seconds.
        """
        _ensure_enum_sync()

        self.http_client = AsyncHTTPClient(
            api_key=api_key, base_url=base_url, timeout=timeout
        )

        logger.info("AsyncCortexClient initialized.")

    async def _make_request(
        self,
        endpoint: str,
        payload: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Helper method to make async POST requests to the /run endpoint."""
        try:
            import grid_cortex_client.utils as _u
            packed = _u.packb(payload)
            return await self.http_client.post(endpoint, data=packed, timeout=timeout)
        except (CortexAPIError, CortexNetworkError) as e:
            logger.error(f"Request to {endpoint} failed: {e}")
            raise
        except Exception as e:
            logger.error(f"Unexpected error during request to {endpoint}: {e}")
            raise CortexNetworkError(f"An unexpected error occurred: {e}") from e

    async def _run_model(
        self,
        model: BaseModel,
        input_data: Any,
        preprocess_kwargs: Optional[Dict[str, Any]] = None,
        postprocess_kwargs: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
        raw_response: bool = False,
    ) -> Any:
        """Execute model end-to-end (async version)."""
        logger.info(
            f"[internal] _run_model {model.model_id} input type: {type(input_data)}"
        )

        # Preprocess (sync - CPU bound)
        payload = self._preprocess(model, input_data, preprocess_kwargs)

        # Make request (async - I/O bound)
        specific_model_endpoint = f"/{model.model_id}/run"
        logger.info(
            f"Requesting model execution from: {specific_model_endpoint} for model_id: {model.model_id}"
        )

        api_response = await self._make_request(
            specific_model_endpoint, payload=payload, timeout=timeout
        )
        logger.info(f"API response for model {model.model_id}: {api_response}")
        if raw_response:
            logger.info(f"Returning raw API response for model {model.model_id}.")
            return api_response
        # Postprocess (sync - CPU bound)
        processed_output = self._postprocess(model, api_response, postprocess_kwargs)

        logger.info(f"Successfully ran model {model.model_id}.")
        return processed_output

    async def run(
        self,
        model_id: Union[str, ModelType],
        timeout: Optional[float] = None,
        raw_response: bool = False,
        **kwargs: Any,
    ) -> Any:
        """Execute inference using a specified model (async version).

        Args:
            model_id: The identifier of the model to run.
            timeout: Optional timeout in seconds for the HTTP request.
            raw_response: If True, returns the raw API response without postprocessing.
            **kwargs: Model-specific input parameters.

        Returns:
            Model-specific output object.

        Raises:
            NotImplementedError: If model_id is not found.
            CortexAPIError: If the API returns an error.
            CortexNetworkError: If network communication fails.
            ValueError: If input validation or processing fails.
        """
        try:
            model_id_str, HandlerClass = self._resolve_handler(model_id)
            logger.info(f"Running model '{model_id_str}' with inputs: {list(kwargs.keys())}")

            model_handler = HandlerClass(transport=self.http_client)
            return await self._run_model(
                model=model_handler,
                input_data=kwargs,
                timeout=timeout,
                raw_response=raw_response,
            )

        except (
            CortexAPIError,
            CortexNetworkError,
            ValueError,
            TypeError,
            NotImplementedError,
        ) as e:
            logger.error(f"Error running model '{model_id}': {e}", exc_info=True)
            raise
        except Exception as e:
            logger.error(
                f"Unexpected error running model '{model_id}': {e}", exc_info=True
            )
            raise CortexNetworkError(
                f"An unexpected error occurred while running model {model_id}: {e}"
            ) from e

    async def get_info(self) -> Dict[str, Any]:
        """Get Grid-Cortex server version and deployed models status.

        Fetches real-time information about the Cortex deployment including
        version and current model replica counts.

        Returns:
            Dictionary containing version and models information.

        Raises:
            CortexAPIError: If the API returns an error.
            CortexNetworkError: If network communication fails.
        """
        try:
            return await self.http_client.get("/ws/info")
        except (CortexAPIError, CortexNetworkError) as e:
            logger.error(f"Failed to fetch server info: {e}")
            raise

    async def close(self):
        """Closes the underlying async HTTP client."""
        await self.http_client.close()
        logger.info("AsyncCortexClient closed.")

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()
