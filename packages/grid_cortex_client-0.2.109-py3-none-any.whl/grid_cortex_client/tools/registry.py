"""cortex model registry.

registry for tracking available models by name.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, List, Optional, Type, TypeVar

T = TypeVar("T")


class Registry:
    """Registry for tracking available model classes by name.

    Usage:
        from grid_cortex_client.tools.registry import registry

        @registry.register("zoedepth")
        class ZoeDepth(BaseModel):
            ...

        # Later, retrieve the class
        cls = registry.get_class("zoedepth")
    """

    def __init__(self) -> None:
        """Initialize an empty registry."""
        self._models: Dict[str, Dict[str, Any]] = {}

    def register(
        self, model_name: str, info: Optional[Dict[str, Any]] = None
    ) -> Callable[[Type[T]], Type[T]]:
        """Decorator to register a model class.

        Args:
            model_name: The name to register the model under.
            info: Optional metadata dictionary for the model.

        Returns:
            A decorator that registers the class and returns it unchanged.

        Raises:
            RuntimeError: If a model with the same name is already registered.
        """

        def decorator(cls: Type[T]) -> Type[T]:
            key = model_name.lower()
            if key in self._models:
                existing = self._models[key]["cls"]
                raise RuntimeError(
                    f"Duplicate model_id '{model_name}' for {cls.__name__} "
                    f"and {existing.__name__}."
                )
            self._models[key] = {
                "name": model_name,
                "cls": cls,
                "info": info or {},
            }
            return cls

        return decorator

    def unregister(self, model_name: str) -> None:
        """Remove a model from the registry."""
        self._models.pop(model_name.lower(), None)

    def get(self, model_name: str) -> Optional[str]:
        """Get a model name from the registry."""
        entry = self._models.get(model_name.lower())
        return entry["name"] if entry else None

    def get_class(self, model_name: str) -> Optional[Type[Any]]:
        """Get the model class from the registry."""
        entry = self._models.get(model_name.lower())
        return entry["cls"] if entry else None

    def get_info(self, model_name: str) -> Dict[str, Any]:
        """Get info dict for a model."""
        entry = self._models.get(model_name.lower())
        return entry["info"] if entry else {}

    def list_models(self) -> List[str]:
        """Return all registered model names."""
        return sorted(entry["name"] for entry in self._models.values())

    def get_all(self) -> Dict[str, Type[Any]]:
        """Return mapping of model_id to wrapper class."""
        return {key: entry["cls"] for key, entry in self._models.items()}

    def clear(self) -> None:
        """Clear all registered models."""
        self._models.clear()

    def __contains__(self, model_name: str) -> bool:
        """Check if a model is registered."""
        return model_name.lower() in self._models

    def __len__(self) -> int:
        """Return the number of registered models."""
        return len(self._models)

    def __iter__(self):
        """Iterate over registered model names."""
        return iter(self.list_models())


# Default registry instance for package-wide use
registry = Registry()
