"""WebSocket session wrapper for CortexHub communication.

Provides async WebSocket session using msgpack serialization
with numpy support for efficient binary data transfer.
"""

from __future__ import annotations

import ssl
from typing import Any, Dict, Optional

from websockets.asyncio.client import connect as async_connect, ClientConnection as AsyncClientConnection

from . import utils as _u


class AsyncWebSocketSession:
    """Asynchronous WebSocket session with msgpack serialization."""

    def __init__(
        self,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        timeout: float = 30.0,
        max_size: int | None = 64 * 1024 * 1024,
    ) -> None:
        self._url = url
        self._headers = headers or {}
        self._timeout = timeout
        self._max_size = max_size
        self._ws: Optional[AsyncClientConnection] = None

    async def connect(self) -> None:
        """Establish WebSocket connection."""
        ssl_ctx = ssl.create_default_context() if self._url.startswith("wss://") else None
        self._ws = await async_connect(
            self._url,
            additional_headers=self._headers,
            close_timeout=self._timeout,
            open_timeout=self._timeout,
            max_size=self._max_size,
            ssl=ssl_ctx,
        )

    async def send(self, payload: Dict[str, Any]) -> None:
        """Send msgpack-encoded payload."""
        if self._ws is None:
            raise RuntimeError("Not connected")
        await self._ws.send(_u.packb(payload))

    async def recv(self) -> Dict[str, Any]:
        """Receive and decode msgpack payload."""
        if self._ws is None:
            raise RuntimeError("Not connected")
        return _u.unpackb(await self._ws.recv())

    async def close(self) -> None:
        """Close connection."""
        if self._ws is not None:
            await self._ws.close()
            self._ws = None

    @property
    def is_connected(self) -> bool:
        """Check if connection is established."""
        return self._ws is not None

    async def __aenter__(self) -> "AsyncWebSocketSession":
        await self.connect()
        return self

    async def __aexit__(self, *_) -> bool:
        await self.close()
        return False
