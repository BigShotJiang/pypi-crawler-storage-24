# grid_cortex_client/src/grid_cortex_client/models/ur5e_pyroki_collision_batch.py
"""UR5e PyRoKi Collision Batch wrapper.

Batch trajectory optimization with collision checking for UR5e robot.

Takes depth image, camera intrinsics, robot state, current/target poses,
and auxiliary arguments to generate collision-free trajectories.
"""

from __future__ import annotations

from typing import Any, Dict, Sequence, Union

import numpy as np
from PIL import Image

from ..preprocessing import load_image, array_to_npy_bytes

from .base_model import BaseModel


class UR5ePyrokiCollisionBatch(BaseModel):
    """Batch trajectory optimization with collision checking (UR5e PyRoKi).

    Preferred usage
    ---------------
    ```pycon
    >>> trajs = CortexClient().run(
    ...     "ur5e-pyroki-collision-batch",
    ...     depth_image=depth,
    ...     camera_intrinsics=K,
    ...     T_cam_world=T_cam_world,
    ...     robot_joint_positions=joints,
    ...     curr_xyzs=curr_xyzs,
    ...     curr_wxyzs=curr_wxyzs,
    ...     target_xyzs=target_xyzs,
    ...     target_wxyzs=target_wxyzs,
    ...     capsule_transform=capsule_transform,
    ...     aux_args=aux
    ... )
    ```
    """

    name: str = "ur5e-pyroki-collision-batch"
    model_id: str = "ur5e-pyroki-collision-batch"

    # ------------------------------------------------------------------
    # BaseModel implementation
    # ------------------------------------------------------------------

    def preprocess(
        self,
        *,
        depth_image: Union[str, Image.Image, np.ndarray],
        camera_intrinsics: Union[str, np.ndarray],
        T_cam_world: Union[str, np.ndarray],
        robot_joint_positions: Union[str, np.ndarray, Sequence[float]],
        curr_xyzs: Union[str, np.ndarray, Sequence[Sequence[float]]],
        curr_wxyzs: Union[str, np.ndarray, Sequence[Sequence[float]]],
        target_xyzs: Union[str, np.ndarray, Sequence[Sequence[float]]],
        target_wxyzs: Union[str, np.ndarray, Sequence[Sequence[float]]],
        capsule_transform: Union[str, np.ndarray],
        aux_args: Dict[str, Any],
        **kwargs: Any,
    ) -> Dict[str, Any]:
        """Prepare JSON payload for UR5e PyRoKi Collision Batch.

        Args:
            depth_image: Depth image (path/URL/PIL/ndarray).
            camera_intrinsics: 3x3 camera intrinsics matrix.
            T_cam_world: 4x4 camera-to-world transformation matrix.
            robot_joint_positions: Robot joint positions (7,) array or list.
            curr_xyzs: Current positions (N, 3) array or list of lists.
            curr_wxyzs: Current quaternions (N, 4) array or list of lists (wxyz order).
            target_xyzs: Target positions (N, 3) array or list of lists.
            target_wxyzs: Target quaternions (N, 4) array or list of lists (wxyz order).
            capsule_transform: 4x4 transformation matrix for capsules.
            aux_args: Dict with "robot_radius", "radius_removal_nb", "radius_removal_dist",
                "num_points", "workspace_xy_dist", "capsule_radius_scale", "capsule_length_scale",
                "capsule_radius_amt", "capsule_length_amt".
        """
        if kwargs:
            unexpected = ", ".join(sorted(kwargs.keys()))
            raise ValueError(f"Unexpected input fields: {unexpected}")

        def _load_and_validate_array(
            value: Union[str, np.ndarray],
            *,
            expected_shape: tuple[int, ...] | None = None,
            expected_len: int | None = None,
            expected_last_dim: int | None = None,
            error_message: str,
        ) -> np.ndarray:
            if isinstance(value, str):
                array = np.load(value)
            else:
                array = np.asarray(value)

            if expected_shape is not None and array.shape != expected_shape:
                raise ValueError(error_message)
            if expected_len is not None and (array.ndim != 1 or array.shape[0] != expected_len):
                raise ValueError(error_message)
            if expected_last_dim is not None and (array.ndim != 2 or array.shape[1] != expected_last_dim):
                raise ValueError(error_message)

            return array

        # Validate all required inputs are provided
        required_inputs = {
            "depth_image": depth_image,
            "camera_intrinsics": camera_intrinsics,
            "T_cam_world": T_cam_world,
            "robot_joint_positions": robot_joint_positions,
            "curr_xyzs": curr_xyzs,
            "curr_wxyzs": curr_wxyzs,
            "target_xyzs": target_xyzs,
            "target_wxyzs": target_wxyzs,
            "capsule_transform": capsule_transform,
        }

        missing = [k for k, v in required_inputs.items() if v is None]
        if missing:
            raise ValueError(f"Missing required inputs: {', '.join(missing)}")

        # Validate aux_args contains all required fields
        required_aux_fields = {
            "robot_radius",
            "radius_removal_nb",
            "radius_removal_dist",
            "num_points",
            "workspace_xy_dist",
            "capsule_radius_scale",
            "capsule_length_scale",
            "capsule_radius_amt",
            "capsule_length_amt",
        }
        missing_aux = required_aux_fields - set(aux_args.keys())
        if missing_aux:
            raise ValueError(f"Missing required aux_args fields: {', '.join(missing_aux)}")

        # Validate aux_args values are numeric
        for field in aux_args.keys():
            if not isinstance(aux_args[field], (float, int)):
                raise ValueError(f"aux_args['{field}'] must be a float or int")

        # Process depth_image
        if isinstance(depth_image, str):
            if depth_image.endswith(".npy"):
                depth_array = np.load(depth_image)
            else:
                depth_pil = load_image(depth_image)
                depth_array = np.array(depth_pil)
        elif isinstance(depth_image, Image.Image):
            depth_array = np.array(depth_image)
        else:
            depth_array = np.asarray(depth_image)

        if depth_array.ndim != 2:
            raise ValueError("depth_image must be a 2D array (H, W)")

        # Process camera_intrinsics
        intrinsics = _load_and_validate_array(
            camera_intrinsics,
            expected_shape=(3, 3),
            error_message="camera_intrinsics must be a 3x3 matrix",
        )

        # Process T_cam_world
        T_cam_world_array = _load_and_validate_array(
            T_cam_world,
            expected_shape=(4, 4),
            error_message="T_cam_world must be a 4x4 matrix",
        )

        # Process robot_joint_positions
        robot_joints = _load_and_validate_array(
            robot_joint_positions,
            expected_len=7,
            error_message="robot_joint_positions must be a 1D array with 7 elements",
        )

        # Process curr_xyzs
        curr_xyzs_array = _load_and_validate_array(
            curr_xyzs,
            expected_last_dim=3,
            error_message="curr_xyzs must be an (N, 3) array",
        )

        # Process curr_wxyzs
        curr_wxyzs_array = _load_and_validate_array(
            curr_wxyzs,
            expected_last_dim=4,
            error_message="curr_wxyzs must be an (N, 4) array",
        )

        # Process target_xyzs
        target_xyzs_array = _load_and_validate_array(
            target_xyzs,
            expected_last_dim=3,
            error_message="target_xyzs must be an (N, 3) array",
        )

        # Process target_wxyzs
        target_wxyzs_array = _load_and_validate_array(
            target_wxyzs,
            expected_last_dim=4,
            error_message="target_wxyzs must be an (N, 4) array",
        )

        # Validate batch sizes match
        batch_size = curr_xyzs_array.shape[0]
        if (curr_wxyzs_array.shape[0] != batch_size or
            target_xyzs_array.shape[0] != batch_size or
            target_wxyzs_array.shape[0] != batch_size):
            raise ValueError("curr_xyzs, curr_wxyzs, target_xyzs, and target_wxyzs must have the same batch size (first dimension)")

        # Process capsule_transform
        capsule_transform_array = _load_and_validate_array(
            capsule_transform,
            expected_shape=(4, 4),
            error_message="capsule_transform must be a 4x4 matrix",
        )

        # Encode all arrays as npy bytes
        return {
            "depth_image": array_to_npy_bytes(depth_array.astype(np.float32)),
            "camera_intrinsics": array_to_npy_bytes(intrinsics.astype(np.float32)),
            "T_cam_world": array_to_npy_bytes(T_cam_world_array.astype(np.float32)),
            "robot_joint_positions": array_to_npy_bytes(robot_joints.astype(np.float32)),
            "curr_xyzs": array_to_npy_bytes(curr_xyzs_array.astype(np.float32)),
            "curr_wxyzs": array_to_npy_bytes(curr_wxyzs_array.astype(np.float32)),
            "target_xyzs": array_to_npy_bytes(target_xyzs_array.astype(np.float32)),
            "target_wxyzs": array_to_npy_bytes(target_wxyzs_array.astype(np.float32)),
            "capsule_transform": array_to_npy_bytes(capsule_transform_array.astype(np.float32)),
            "aux_args": aux_args,  # Send as dict directly
        }

    def postprocess(
        self, response_data: Dict[str, Any], **_: Any
    ) -> Dict[str, Any]:  # noqa: D401
        """Decode batch trajectories from response."""
        output = np.array(response_data["output"])
        latency_ms = response_data.get("latency_ms", 0.0)
        debug = response_data.get("debug", {})
        
        # Convert debug arrays if they're lists
        if isinstance(debug, dict):
            if "pc" in debug and isinstance(debug["pc"], list):
                debug["pc"] = np.array(debug["pc"])
            if "scene_capsules" in debug and isinstance(debug["scene_capsules"], list):
                debug["scene_capsules"] = np.array(debug["scene_capsules"])
            if "transformed_capsules" in debug and isinstance(debug["transformed_capsules"], list):
                debug["transformed_capsules"] = np.array(debug["transformed_capsules"])
        
        return {
            "output": output,
            "latency_ms": latency_ms,
            "debug": debug,
        }

    def run(
        self,
        *,
        aux_args: Dict[str, Any],
        depth_image: Union[str, Image.Image, np.ndarray],
        camera_intrinsics: Union[str, np.ndarray],
        T_cam_world: Union[str, np.ndarray],
        robot_joint_positions: Union[str, np.ndarray, Sequence[float]],
        curr_xyzs: Union[str, np.ndarray, Sequence[Sequence[float]]],
        curr_wxyzs: Union[str, np.ndarray, Sequence[Sequence[float]]],
        target_xyzs: Union[str, np.ndarray, Sequence[Sequence[float]]],
        target_wxyzs: Union[str, np.ndarray, Sequence[Sequence[float]]],
        capsule_transform: Union[str, np.ndarray],
        timeout: float | None = None,
    ) -> Dict[str, Any]:
        """Generate batch trajectories using UR5e PyRoKi Collision Batch.

        Args:
            aux_args: Auxiliary parameters (robot_radius, radius_removal_nb, etc.).
            depth_image: Depth image (path/URL/PIL/ndarray).
            camera_intrinsics: 3x3 camera intrinsics matrix.
            T_cam_world: 4x4 camera-to-world transformation matrix.
            robot_joint_positions: Robot joint positions (7,) array or list.
            curr_xyzs: Current positions (N, 3) array or list of lists.
            curr_wxyzs: Current quaternions (N, 4) array or list of lists (wxyz order).
            target_xyzs: Target positions (N, 3) array or list of lists.
            target_wxyzs: Target quaternions (N, 4) array or list of lists (wxyz order).
            capsule_transform: 4x4 transformation matrix for capsules.
            timeout (float | None): Optional HTTP timeout.

        Returns:
            Dict with:
                - output: Array of trajectories (N, timesteps, 7)
                - latency_ms: Processing time in milliseconds
                - debug: Dict with point cloud and capsule debug info
                    - pc: Point cloud array
                    - scene_capsules: Scene capsule poses
                    - transformed_capsules: Transformed capsule poses

        Raises:
            ValueError: If inputs cannot be loaded or parameters are invalid.
            RuntimeError: If no HTTP transport is configured.
            Exception: If the HTTP request fails.

        Examples:
            >>> from grid_cortex_client import CortexClient, ModelType
            >>> import numpy as np
            >>> client = CortexClient()
            >>> K = np.eye(3)
            >>> T_cam_world = np.eye(4)
            >>> robot_joints = np.zeros(7)
            >>> curr_xyzs = np.random.uniform(-1, 1, size=(20, 3))
            >>> curr_wxyzs = np.array([[1.0, 0.0, 0.0, 0.0]] * 20)
            >>> target_xyzs = np.random.uniform(-1, 1, size=(20, 3))
            >>> target_wxyzs = np.array([[1.0, 0.0, 0.0, 0.0]] * 20)
            >>> capsule_transform = np.eye(4)
            >>> aux = {
            ...     "robot_radius": 0.05,
            ...     "radius_removal_nb": 10,
            ...     "radius_removal_dist": 0.06,
            ...     "num_points": 1200,
            ...     "workspace_xy_dist": 1.0,
            ...     "capsule_radius_scale": 1.0,
            ...     "capsule_length_scale": 1.0,
            ...     "capsule_radius_amt": 0.0,
            ...     "capsule_length_amt": 0.0,
            ... }
            >>> depth = np.random.uniform(0.5, 0.6, size=(480, 640))
            >>> result = client.run(
            ...     ModelType.UR5E_PYROKI_COLLISION_BATCH,
            ...     depth_image=depth,
            ...     camera_intrinsics=K,
            ...     T_cam_world=T_cam_world,
            ...     robot_joint_positions=robot_joints,
            ...     curr_xyzs=curr_xyzs,
            ...     curr_wxyzs=curr_wxyzs,
            ...     target_xyzs=target_xyzs,
            ...     target_wxyzs=target_wxyzs,
            ...     capsule_transform=capsule_transform,
            ...     aux_args=aux
            ... )
            >>> trajs = result["output"]
            >>> print(f"Generated {trajs.shape[0]} trajectories")
            >>> print(f"Shape: {trajs.shape}")  # (20, 10, 7)
        """
        return super().run(
            depth_image=depth_image,
            camera_intrinsics=camera_intrinsics,
            T_cam_world=T_cam_world,
            robot_joint_positions=robot_joint_positions,
            curr_xyzs=curr_xyzs,
            curr_wxyzs=curr_wxyzs,
            target_xyzs=target_xyzs,
            target_wxyzs=target_wxyzs,
            capsule_transform=capsule_transform,
            aux_args=aux_args,
            timeout=timeout,
        )

