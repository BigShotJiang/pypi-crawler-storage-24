# grid_cortex_client/src/grid_cortex_client/models/qwen_vl.py
"""Qwen VL wrapper.

Vision-Language Model (VLM) powered by Qwen3-VL-4B-Instruct.

Takes image + text prompt and returns generated text response.
"""

from __future__ import annotations

from typing import Any, Dict, Union

import numpy as np
from PIL import Image

from ..preprocessing import load_image, image_to_bytes
from .base_model import BaseModel


class QwenVL(BaseModel):
    """Vision-Language Model (Qwen3-VL-4B).

    Preferred usage
    ---------------
    ```pycon
    >>> response = CortexClient().run("qwen_vl", image_input=img, prompt="What do you see?")
    >>> print(response["output"])
    ```
    """

    name: str = "qwen_vl"
    model_id: str = "qwen_vl"

    # ------------------------------------------------------------------
    # BaseModel implementation
    # ------------------------------------------------------------------

    def preprocess(
        self,
        *,
        image_input: Union[str, Image.Image, np.ndarray],
        prompt: str = "Describe this image.",
        max_new_tokens: int = 512,
        temperature: float = 0.7,
    ) -> Dict[str, Any]:
        """Prepare JSON payload for Qwen VL.

        Args:
            image_input: Image (path/URL/PIL/ndarray).
            prompt: Text prompt/question about the image.
            max_new_tokens: Maximum number of tokens to generate.
            temperature: Sampling temperature (0 = greedy).
        """
        pil = load_image(image_input)
        payload: Dict[str, Any] = {
            "image_input": image_to_bytes(pil, encoding_format="JPEG"),
            "prompt": prompt,
        }
        if max_new_tokens != 512:
            payload["max_new_tokens"] = max_new_tokens
        if temperature != 0.7:
            payload["temperature"] = temperature
        return payload

    def postprocess(self, response_data: Dict[str, Any], **_: Any) -> Dict[str, Any]:  # noqa: D401
        """Return *response_data* unchanged so callers access ['output']."""

        # Unwrap batch list if present
        if isinstance(response_data, list) and len(response_data) == 1:
            response_data = response_data[0]

        return response_data

    def run(
        self,
        image_input: Union[str, Image.Image, np.ndarray],
        prompt: str = "Describe this image.",
        max_new_tokens: int = 512,
        temperature: float = 0.7,
        timeout: float | None = None,
    ) -> Dict[str, Any]:
        """Generate text response from image using Qwen3-VL.

        Args:
            image_input (Union[str, Image.Image, np.ndarray]): RGB image.
            prompt (str): Text prompt/question about the image.
            max_new_tokens (int): Maximum number of tokens to generate.
            temperature (float): Sampling temperature (0 = greedy).
            timeout (float | None): Optional HTTP timeout.

        Returns:
            Dict[str, Any]: Backend JSON response containing:
            - "output": Generated text response string.
            - "latency_ms": Server-side processing time.
            - "gpu_stats": GPU memory usage statistics.

        Examples:
            >>> from grid_cortex_client import CortexClient, ModelType
            >>> import numpy as np
            >>> from PIL import Image
            >>> client = CortexClient()
            >>> image = np.array(Image.open("path/to/image.jpg"))
            >>> result = client.run(ModelType.QWEN_VL, image_input=image, prompt="What do you see?")
            >>> print(result["output"])  # Text answer
        """
        return super().run(
            image_input=image_input,
            prompt=prompt,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            timeout=timeout,
        )
