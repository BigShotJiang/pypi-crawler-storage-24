"""PI05 wrapper.

Client-side helper for the VLA endpoint powered by PI05.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Union

import numpy as np
from PIL import Image

from ..preprocessing import load_image, image_to_bytes
from .base_model import BaseModel

def resize_with_pad(
    image: Image.Image,
    height: int,
    width: int,
) -> Image.Image:
    """Replicates tf.image.resize_with_pad. Resizes an image to a target height and width without distortion
    by padding with black.
    
    Args:
        image: Input PIL Image.
        height: Target height.
        width: Target width.
    
    Returns:
        Resized and padded PIL Image with the target dimensions.
    """
    cur_width, cur_height = image.size
    ratio = max(cur_width / width, cur_height / height)
    resized_height = int(cur_height / ratio)
    resized_width = int(cur_width / ratio)
    
    # Resize the image maintaining aspect ratio
    resized_image = image.resize((resized_width, resized_height), Image.Resampling.LANCZOS)
    
    # Calculate padding
    pad_h0, remainder_h = divmod(height - resized_height, 2)
    pad_h1 = pad_h0 + remainder_h
    pad_w0, remainder_w = divmod(width - resized_width, 2)
    pad_w1 = pad_w0 + remainder_w
    
    # Create a new image with target size and black background
    padded_image = Image.new(image.mode, (width, height), color=0)
    
    # Paste the resized image onto the padded image
    padded_image.paste(resized_image, (pad_w0, pad_h0))
    
    return padded_image

class PI05(BaseModel):
    """PI05 policy inference wrapper.

    Preferred usage (through :class:`CortexClient`)
    ---------------------------------------------
    ```pycon
    >>> from grid_cortex_client import CortexClient, ModelType
    >>> client = CortexClient()
    >>> action = client.run(
    ...     ModelType.PI05,
    ...     base_rgb=base_image,
    ...     wrist_rgb=wrist_image,
    ...     joints=joint_positions,
    ...     gripper=gripper_position,
    ...     state=robot_state,
    ...     prompt="pick up the cup"
    ... )
    >>> print(action["actions"].shape)  # (horizon, action_dim)
    ```

    Direct wrapper usage
    --------------------
    ```pycon
    >>> from grid_cortex_client.models.pi05 import PI05
    >>> wrapper = PI05(transport=client.http_client)
    >>> action = wrapper.run(
    ...     base_rgb=base_image,
    ...     wrist_rgb=wrist_image,
    ...     joints=joint_positions,
    ...     gripper=gripper_position,
    ...     state=robot_state,
    ...     prompt="pick up the cup"
    ... )
    ```

    Args (for :py:meth:`run`)
    ------------------------
    base_rgb: Base camera RGB image (path, URL, ``PIL.Image`` or ``np.ndarray``).
    wrist_rgb: Wrist camera RGB image (path, URL, ``PIL.Image`` or ``np.ndarray``).
    joints: Joint positions as numpy array or list (e.g., 6-DOF for UR5).
    gripper: Gripper position as numpy array or list (e.g., 1-D).
    state: Robot state as numpy array or list (concatenation of joints and gripper).
    prompt: Optional task prompt string.

    Returns
    -------
    Dict[str, Any]
        Action dictionary containing:
        - "actions": numpy array of shape (horizon, action_dim) with predicted actions
        - Other fields from policy.infer() (e.g., "state", "policy_timing", etc.)

    Notes
    -----
    The lower-level :py:meth:`preprocess` and :py:meth:`postprocess` helpers are
    called automatically by :py:meth:`run` and are usually **not** needed by
    user code.
    """

    model_id: str = "pi05"

    def __init__(self, *, transport=None) -> None:
        """Create a PI05 wrapper.

        Args:
            transport: Optional shared HTTP transport injected by
                :class:`~grid_cortex_client.CortexClient`.
        """
        super().__init__(transport=transport)

    # ------------------------------------------------------------------
    # BaseModel interface
    # ------------------------------------------------------------------

    def preprocess(
        self,
        *,
        base_rgb: Union[str, Image.Image, np.ndarray],
        wrist_rgb: Union[str, Image.Image, np.ndarray],
        joints: Union[np.ndarray, list],
        gripper: Union[np.ndarray, list],
        state: Union[np.ndarray, list],
        prompt: Optional[str] = None,
    ) -> Dict[str, Any]:
        """Convert inputs to the payload expected by the server.

        Args:
            base_rgb: Base camera RGB image.
            wrist_rgb: Wrist camera RGB image.
            joints: Joint positions.
            gripper: Gripper position.
            state: Robot state (concatenation of joints and gripper).
            prompt: Optional task prompt.

        Returns:
            Dictionary that will be msgpack-encoded and sent to the server.
        """
        # Convert images to PIL
        base_img = load_image(base_rgb)
        wrist_img = load_image(wrist_rgb)

        # resize images to 224x224
        base_img = resize_with_pad(base_img, 224, 224)
        wrist_img = resize_with_pad(wrist_img, 224, 224)

        base_bytes = image_to_bytes(base_img, encoding_format="JPEG")
        wrist_bytes = image_to_bytes(wrist_img, encoding_format="JPEG")
        
        # Ensure arrays are numpy arrays
        joints_arr = np.asarray(joints, dtype=np.float32)
        gripper_arr = np.asarray(gripper, dtype=np.float32)
        state_arr = np.asarray(state, dtype=np.float32)
        # Ensure joints, gripper, and state have correct shapes
        if joints_arr.shape != (6,):
            raise ValueError("joints must be a numpy array of shape (6,)")
        if gripper_arr.shape != (1,):
            raise ValueError("gripper must be a numpy array of shape (1,)")
        if state_arr.shape != (7,):
            raise ValueError("state must be a numpy array of shape (7,)")
        
        # Build observation dict according to pi05.py API
        obs = {
            "base_rgb": base_bytes,
            "wrist_rgb": wrist_bytes,
            "joints": joints_arr,
            "gripper": gripper_arr,
            "state": state_arr,
        }
        
        payload = {"obs": obs}
        if prompt is not None:
            payload["prompt"] = prompt
        
        return payload

    def postprocess(
        self,
        response_data: Dict[str, Any],
        **_: Any,
    ) -> Dict[str, Any]:
        """Convert server response to user-friendly output.

        Args:
            response_data: Raw response from the server (already msgpack-decoded).

        Returns:
            Action dictionary with numpy arrays extracted from the response.

        Raises:
            ValueError: If the payload is missing required fields.
        """
        # Server returns dict with "output" key containing the action dict
        if isinstance(response_data, list):
            response_dict = response_data[0]
        else:
            response_dict = response_data
        
        output = response_dict.get("output")
        if output is None:
            raise ValueError("'output' field missing from server response")
        
        # The output is already a dict with numpy arrays from msgpack-numpy
        # Ensure all arrays are properly typed
        action_dict = {}
        for key, value in output.items():
            if isinstance(value, np.ndarray):
                action_dict[key] = value
            elif isinstance(value, (list, tuple)):
                action_dict[key] = np.asarray(value)
            else:
                action_dict[key] = value
        
        return action_dict

    def run(
        self,
        *,
        base_rgb: Union[str, Image.Image, np.ndarray],
        wrist_rgb: Union[str, Image.Image, np.ndarray],
        joints: Union[np.ndarray, list],
        gripper: Union[np.ndarray, list],
        state: Union[np.ndarray, list],
        prompt: Optional[str] = None,
        timeout: float | None = None,
    ) -> Dict[str, Any]:
        """Run PI05 policy inference on robot observations.

        Args:
            base_rgb: Base camera RGB image as file path, URL, PIL Image, or numpy array.
            wrist_rgb: Wrist camera RGB image as file path, URL, PIL Image, or numpy array.
            joints: Joint positions as numpy array or list.
            gripper: Gripper position as numpy array or list.
            state: Robot state as numpy array or list (concatenation of joints and gripper).
            prompt: Optional task prompt string.
            timeout: Optional timeout in seconds for the HTTP request.

        Returns:
            Action dictionary containing:
            - "actions": numpy array of shape (horizon, action_dim) with predicted actions
            - Other fields from policy.infer() (e.g., "state", "policy_timing", etc.)

        Raises:
            ValueError: If inputs are invalid.
            RuntimeError: If no HTTP transport is configured.

        Example:
            >>> from grid_cortex_client import CortexClient, ModelType
            >>> import numpy as np
            >>> client = CortexClient()
            >>> base_img = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
            >>> wrist_img = np.random.randint(0, 255, (224, 224, 3), dtype=np.uint8)
            >>> joints = np.array([0.1, 0.2, 0.3, 0.4, 0.5, 0.6])
            >>> gripper = np.array([0.5])
            >>> state = np.concatenate([joints, gripper])
            >>> action = client.run(
            ...     ModelType.PI05,
            ...     base_rgb=base_img,
            ...     wrist_rgb=wrist_img,
            ...     joints=joints,
            ...     gripper=gripper,
            ...     state=state,
            ...     prompt="pick up the cup"
            ... )
            >>> print(action["actions"].shape)
        """
        return super().run(
            base_rgb=base_rgb,
            wrist_rgb=wrist_rgb,
            joints=joints,
            gripper=gripper,
            state=state,
            prompt=prompt,
            timeout=timeout,
        )

