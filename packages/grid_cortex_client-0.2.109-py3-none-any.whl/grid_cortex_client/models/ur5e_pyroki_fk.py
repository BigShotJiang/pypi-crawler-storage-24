# grid_cortex_client/src/grid_cortex_client/models/ur5e_pyroki_fk.py
"""UR5e PyRoKi Forward Kinematics wrapper.

Batch forward kinematics computation for UR5e robot.

Takes a batch of joint states and computes end-effector poses.
"""

from __future__ import annotations

from typing import Any, Dict, Sequence, Union

import numpy as np

from ..preprocessing import array_to_npy_bytes

from .base_model import BaseModel


class UR5ePyrokiFk(BaseModel):
    """Batch forward kinematics for UR5e robot (PyRoKi).

    Preferred usage
    ---------------
    ```pycon
    >>> poses = CortexClient().run(
    ...     "ur5e-pyroki-fk",
    ...     batch_joint_states=joint_states
    ... )
    ```
    """

    name: str = "ur5e-pyroki-fk"
    model_id: str = "ur5e-pyroki-fk"

    # ------------------------------------------------------------------
    # BaseModel implementation
    # ------------------------------------------------------------------

    def preprocess(
        self,
        *,
        batch_joint_states: Union[str, np.ndarray, Sequence[Sequence[float]], Dict[str, Any], None] = None,
    ) -> Dict[str, Any]:
        """Prepare JSON payload for UR5e PyRoKi Forward Kinematics.
        Args:
            batch_joint_states: Batch of joint configurations (N, 7) array or list of lists.
                Can also be a path to a .npy file.
        """
        # Backward compat: older cortex_client passed the entire kwargs dict as the
        # first positional argument. If we detect input keys hiding in a dict, treat it as that dict.
        if isinstance(batch_joint_states, dict):
            batch_joint_states = batch_joint_states.get("batch_joint_states")
        if batch_joint_states is None:
            raise ValueError("'batch_joint_states' is required.")

        # Process batch_joint_states
        if isinstance(batch_joint_states, str):
            joint_states_array = np.load(batch_joint_states)
        else:
            joint_states_array = np.asarray(batch_joint_states)

        if joint_states_array.ndim != 2 or joint_states_array.shape[1] != 7:
            raise ValueError("batch_joint_states must be an (N, 7) array")

        # Encode array as npy bytes
        return {
            "batch_joint_states": array_to_npy_bytes(joint_states_array.astype(np.float32)),
        }

    def postprocess(
        self, response_data: Dict[str, Any], **_: Any
    ) -> Dict[str, Any]:  # noqa: D401
        """Decode end-effector poses from response."""
        output = np.array(response_data["output"])
        latency_ms = response_data.get("latency_ms", 0.0)
        
        return {
            "output": output,
            "latency_ms": latency_ms,
        }

    def run(
        self,
        *,
        batch_joint_states: Union[str, np.ndarray, Sequence[Sequence[float]]],
        timeout: float | None = None,
    ) -> Dict[str, Any]:
        """Compute forward kinematics for a batch of joint states.

        Args:
            batch_joint_states: Batch of joint configurations (N, 7) array or list of lists.
                Can also be a path to a .npy file. Each row represents a 7-DOF joint configuration.
            timeout (float | None): Optional HTTP timeout.

        Returns:
            Dict with:
                - output: Array of end-effector poses (N, 7) in wxyz_xyz format
                    (quaternion wxyz + position xyz)
                - latency_ms: Processing time in milliseconds

        Raises:
            ValueError: If inputs cannot be loaded or parameters are invalid.
            RuntimeError: If no HTTP transport is configured.
            Exception: If the HTTP request fails.

        Examples:
            >>> from grid_cortex_client import CortexClient, ModelType
            >>> import numpy as np
            >>> client = CortexClient()
            >>> # Create a batch of 20 joint configurations
            >>> batch_joint_states = np.random.uniform(-1.0, 1.0, size=(20, 7)).astype(np.float32)
            >>> result = client.run(
            ...     ModelType.UR5E_PYROKI_FK,
            ...     batch_joint_states=batch_joint_states
            ... )
            >>> poses = result["output"]
            >>> print(f"Computed {poses.shape[0]} end-effector poses")
            >>> print(f"Shape: {poses.shape}")  # (20, 7)
        """
        return super().run(
            batch_joint_states=batch_joint_states,
            timeout=timeout,
        )
