"""Abstract base class for model wrappers.

This module provides:

1. A base class with automatic registration via the shared registry.
2. An optional ``transport`` parameter that allows the shared HTTP
   implementation held by :class:`~grid_cortex_client.cortex_client.CortexClient`
   to be injected. The transport object must expose ``post(path, json, timeout)`` –
   exactly what the existing ``HTTPClient`` already provides.
3. A concrete :py:meth:`run` implementation that performs the common
   *preprocess → HTTP POST → postprocess* chain. Individual wrappers may still
   override ``run`` if they need custom behavior, but most can inherit it.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any, Dict, Optional, ClassVar, Type

from grid_cortex_client.tools.registry import registry


class BaseModel(ABC):
    """
    Interface for all client-side wrappers.

    Concrete subclasses must:
    - Define a class attribute ``model_id``
    - Implement :py:meth:`preprocess`
    - Implement :py:meth:`postprocess`

    They *may* override :py:meth:`run` and :py:meth:`visualize` if the default
    behaviour is insufficient.
    """

    model_id: ClassVar[str]

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Auto-register subclasses that define a model_id."""
        super().__init_subclass__(**kwargs)

        model_id: Optional[str] = getattr(cls, "model_id", None)
        # Only register concrete subclasses that declare a model_id
        if model_id and not cls.__name__.startswith("Base"):
            registry.register(model_id)(cls)

    def __init__(self, *, transport: Optional[Any] = None):
        """Create a wrapper.

        Args:
            transport: Shared HTTP transport injected by :class:`CortexClient`.
                The object must provide ``post(path: str, json: dict, timeout: float | None = None)``.
                If *None*, the wrapper will raise :class:`RuntimeError` when :py:meth:`run` is used.
        """
        if not hasattr(self, "model_id"):
            raise TypeError(
                "Concrete wrapper class must define a class attribute 'model_id'."
            )

        self._transport = transport

    @abstractmethod
    def preprocess(self, input_data: Any, **kwargs) -> Dict[str, Any]:
        """Convert raw input into JSON payload.

        Concrete implementations should accept flexible Python objects (file
        paths, ``np.ndarray``, ``PIL.Image`` …) and return a dictionary that can
        be serialized with :pyfunc:`json.dumps`.
        """
        pass

    @abstractmethod
    def postprocess(self, response_data: Dict[str, Any], **kwargs) -> Any:
        """Convert server JSON into a convenient Python object."""
        pass

    def run(self, timeout: float | None = None, **kwargs) -> Any:
        """End-to-end inference helper.

        Typical wrappers do *not* need to override this method – the default
        simply chains :py:meth:`preprocess` → HTTP POST → :py:meth:`postprocess`.
        """

        if self._transport is None:
            raise RuntimeError(
                "This wrapper was instantiated without a transport. "
                "Use CortexClient.run(), or pass a transport explicitly."
            )

        payload = self.preprocess(**kwargs)
        payload.setdefault("model_id", self.model_id)

        endpoint = f"/{self.model_id}/run"
        raw = self._transport.post(endpoint, json=payload, timeout=timeout)
        return self.postprocess(raw)

    def visualize(
        self, processed_output: Any, original_input: Optional[Any] = None, **kwargs
    ) -> None:
        """Optional visualisation hook – no-op by default."""

        from pprint import pprint

        print(f"[visualize] '{self.model_id}' output (debug-print only):")
        pprint(processed_output)


def get_registry() -> Dict[str, Type[BaseModel]]:
    """Return mapping *model_id → wrapper class*. Used by CortexClient."""
    return registry.get_all()
