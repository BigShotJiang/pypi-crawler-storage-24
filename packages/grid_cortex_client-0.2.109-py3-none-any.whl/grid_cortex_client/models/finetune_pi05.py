"""FinetunePi05 service wrapper.

Client-side helper for the OpenPI finetuning service.
"""
from __future__ import annotations

from typing import Any, Dict

from .. import utils as _u
from .base_model import BaseModel


class FinetunePi05(BaseModel):
    """Client wrapper for the finetune_pi05 service.

    Preferred usage (through CortexClient)
    --------------------------------------
    >>> from grid_cortex_client import CortexClient, ModelType
    >>> client = CortexClient()
    >>> resp = client.run(ModelType.FINETUNE_PI05, repo_id="dummy/repo")
    >>> print(resp["job_id"])  # job identifier
    """

    model_id: str = "finetune_pi05"

    def preprocess(
        self,
        *,
        repo_id: str,
        config_name: str | None = None,
        exp_name: str | None = None,
        num_train_steps: int | None = None,
        log_interval: int | None = None,
        action_horizon: int | None = None,
        max_frames: int | None = None,
        job_id: str | None = None,
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"repo_id": repo_id}
        if config_name is not None:
            payload["config_name"] = config_name
        if exp_name is not None:
            payload["exp_name"] = exp_name
        if num_train_steps is not None:
            if num_train_steps >= 30000:
                raise ValueError(
                    f"num_train_steps must be less than 30000, got {num_train_steps}"
                )
            payload["num_train_steps"] = num_train_steps
        if log_interval is not None:
            payload["log_interval"] = log_interval
        if action_horizon is not None:
            payload["action_horizon"] = action_horizon
        if max_frames is not None:
            payload["max_frames"] = max_frames
        if job_id is not None:
            payload["job_id"] = job_id
        return payload

    def postprocess(self, response_data: Dict[str, Any], **_: Any) -> Dict[str, Any]:
        return response_data

    def run(
        self,
        *,
        repo_id: str,
        config_name: str | None = None,
        exp_name: str | None = None,
        num_train_steps: int | None = None,
        log_interval: int | None = None,
        action_horizon: int | None = None,
        max_frames: int | None = None,
        job_id: str | None = None,
        user_id: int | None = None,
        timeout: float | None = None,
    ) -> Dict[str, Any]:
        """Submit a finetuning job.

        Args:
            repo_id: HuggingFace dataset repo id.
            config_name: Optional experiment config name.
            exp_name: Optional experiment run name.
            num_train_steps: Override training steps.
            log_interval: Override log interval.
            action_horizon: Override action horizon.
            max_frames: Limit frames for norm stats.
            job_id: Optional job id override.
            user_id: Optional user id header (x-user-id).
            timeout: Optional HTTP timeout.

        Returns:
            Dict[str, Any]: Job submission response with job_id, status, and paths.

        Raises:
            RuntimeError: If no HTTP transport is configured.
            ValueError: If input is invalid.
            Exception: If the HTTP request fails.

        Examples:
            >>> from grid_cortex_client import CortexClient, ModelType
            >>> client = CortexClient()
            >>> resp = client.run(ModelType.FINETUNE_PI05, repo_id="dummy/repo", num_train_steps=100)
            >>> print(resp["status"])  # PENDING
        """
        if self._transport is None:
            raise RuntimeError(
                "This wrapper was instantiated without a transport. "
                "Use CortexClient.run(), or pass a transport explicitly."
            )

        payload = self.preprocess(
            repo_id=repo_id,
            config_name=config_name,
            exp_name=exp_name,
            num_train_steps=num_train_steps,
            action_horizon=action_horizon,
            log_interval=log_interval,
            max_frames=max_frames,
            job_id=job_id,
        )

        headers: Dict[str, str] = {}
        if user_id is not None:
            headers["x-user-id"] = str(user_id)

        endpoint = f"/{self.model_id}/run"
        response = self._transport.post(endpoint, data=_u.packb(payload), headers=headers or None, timeout=timeout)
        return self.postprocess(response)

    def status(self, job_id: str, *, timeout: float | None = None) -> Dict[str, Any]:
        if self._transport is None:
            raise RuntimeError(
                "This wrapper was instantiated without a transport. "
                "Use CortexClient.run(), or pass a transport explicitly."
            )
        endpoint = f"/{self.model_id}/status/{job_id}"
        return self._transport.get(endpoint, timeout=timeout)

    def logs(self, job_id: str, *, tail_lines: int = 200, timeout: float | None = None) -> Dict[str, Any]:
        if self._transport is None:
            raise RuntimeError(
                "This wrapper was instantiated without a transport. "
                "Use CortexClient.run(), or pass a transport explicitly."
            )
        endpoint = f"/{self.model_id}/logs/{job_id}?tail_lines={tail_lines}"
        return self._transport.get(endpoint, timeout=timeout)

    def cancel(self, job_id: str, *, timeout: float | None = None) -> Dict[str, Any]:
        if self._transport is None:
            raise RuntimeError(
                "This wrapper was instantiated without a transport. "
                "Use CortexClient.run(), or pass a transport explicitly."
            )
        endpoint = f"/{self.model_id}/cancel/{job_id}"
        return self._transport.post(endpoint, json=None, timeout=timeout)
