import numpy as np
from typing import Dict, Any, Optional, List
from ..base import Perturbation
import copy


class GaussianNoise(Perturbation):
    """
    Applies Gaussian noise to load profiles.
    For each column and timestep, it samples noise from a Gaussian distribution with specified mean and standard deviation,
    and it applies this to the profiles.
    This can be either additive or multiplicative noise.
    additive: perturbed_profile = profile + noise
    multiplicative: perturbed_profile = profile * (1 + noise)
    """

    def __init__(
        self,
        mean: float = 0.0,
        std: float = 0.01,
        method: str = "multiplicative",  # 'multiplicative' or 'additive'
        seed: Optional[int] = None,
        transformation: Optional[Dict[str, Any]] = None,
        track_input_profiles: bool = False,
    ):
        """
        Initialize the MultiplicativeGaussianNoise perturbation.

        Parameters:
        -----------
        mean : float, default=0.0
            Mean of the Gaussian noise distribution
        std : float, default=0.01
            Standard deviation of the Gaussian noise distribution
        seed : int, optional
            Random seed for reproducibility
        transformation : Dict[str, Any], optional
            Pre-computed transformation parameters containing 'noise_samples'
        """
        super().__init__(
            seed=seed,
            transformation=transformation,
            track_input_profiles=track_input_profiles,
        )

        self.mean = mean
        self.std = std
        self.method = method.lower()

        # Store configuration
        self._config = {"mean": mean, "std": std, "method": self.method}

        # Validate parameters
        if std < 0:
            raise ValueError("Standard deviation must be non-negative")

    def _infer_transformation(self, profiles: np.ndarray) -> Dict[str, Any]:
        """
        Generate noise samples with the same shape as the input profiles.

        Parameters:
        -----------
        profiles : np.ndarray
            2D array where each column is a load profile, each row is a timestep
        """
        # Generate noise samples with same shape as profiles
        noise_samples = np.random.normal(
            loc=self.mean, scale=self.std, size=profiles.shape
        )

        transformation = {
            "noise_samples": noise_samples,
            "mean": self.mean,
            "std": self.std,
            "method": self.method,
            "shape": profiles.shape,
        }
        return transformation

    def _apply_perturbation(self, profiles: np.ndarray) -> np.ndarray:
        """
        Apply multiplicative Gaussian noise using stored transformation parameters.

        Parameters:
        -----------
        profiles : np.ndarray
            2D array where each column is a load profile, each row is a timestep

        Returns:
        --------
        np.ndarray
            The perturbed profiles: profiles * (1 + noise_samples)
        """

        # Verify shape compatibility
        expected_shape = self._transformation["shape"]
        if profiles.shape != expected_shape:
            raise ValueError(
                f"Profile shape {profiles.shape} doesn't match expected shape {expected_shape}"
            )

        # Apply multiplicative noise: profiles * (1 + noise)
        noise_samples = self._transformation["noise_samples"]

        if self.method == "additive":
            perturbed_profiles = profiles + noise_samples
        elif self.method == "multiplicative":
            perturbed_profiles = profiles * (1 + noise_samples)
        else:
            raise ValueError(
                f"Unknown method '{self.method}'. Use 'additive' or 'multiplicative'."
            )

        return perturbed_profiles


class OUNoise(Perturbation):
    """
    Applies Ornstein–Uhlenbeck (OU) noise to each column.
    Put simply, OU noise is like a random walk that has a tendency to revert to a mean value (mu) over time.

    Noise can be applied additively or multiplicatively to the profiles.
    Additive: perturbed_profile = profile + noise
    Multiplicative: perturbed_profile = profile * (1 + noise)

    Discrete update (Euler–Maruyama):
        x[t+1] = x[t] + theta * (mu - x[t]) * dt + sigma_eff[c] * sqrt(dt) * N(0,1)

    Simplified scaling:
        sigma_eff[c] = sigma * mean(abs(profiles[:, c]))
    where `sigma` is a dimensionless fraction of the column's mean absolute magnitude.
    """

    def __init__(
        self,
        theta: float = 0.5,
        mu: float = 0.0,
        sigma: float = 0.05,  # fraction of mean(|column|)
        dt: float = 1.0,
        method: str = "additive",  # 'additive' or 'multiplicative'
        per_column_independent: bool = True,
        eps_scale: float = 1e-12,
        seed: Optional[int] = None,
        transformation: Optional[Dict[str, Any]] = None,
        track_input_profiles: bool = False,
    ):
        super().__init__(
            seed=seed,
            transformation=transformation,
            track_input_profiles=track_input_profiles,
        )

        if theta <= 0:
            raise ValueError("theta must be > 0")
        if dt <= 0:
            raise ValueError("dt must be > 0")
        if sigma < 0:
            raise ValueError("sigma must be >= 0")
        if eps_scale <= 0:
            raise ValueError("eps_scale must be > 0")

        self.theta = float(theta)
        self.mu = float(mu)
        self.sigma = float(sigma)
        self.dt = float(dt)
        self.per_column_independent = per_column_independent
        self.eps_scale = float(eps_scale)
        self.method = method.lower()

        self._config = {
            "theta": self.theta,
            "mu": self.mu,
            "sigma": self.sigma,
            "dt": self.dt,
            "per_column_independent": self.per_column_independent,
            "eps_scale": self.eps_scale,
            "method": self.method,
        }

    # -------- required abstract-method implementations --------

    def _infer_transformation(self, profiles: np.ndarray) -> Dict[str, Any]:
        t_steps, n_cols = profiles.shape

        # per-column scaling based on mean absolute magnitude
        mean_abs = np.mean(np.abs(profiles), axis=0)
        mean_abs = np.maximum(mean_abs, self.eps_scale)
        sigma_eff = self.sigma * mean_abs

        noise = self._simulate_ou(
            t_steps=t_steps,
            n_cols=n_cols,
            theta=self.theta,
            mu=self.mu,
            sigma_eff=sigma_eff,
            dt=self.dt,
            per_column_independent=self.per_column_independent,
        )

        summary = {
            "noise_std_per_col": noise.std(axis=0, ddof=1).tolist()
            if t_steps > 1
            else [0.0] * n_cols,
            "noise_mean_per_col": noise.mean(axis=0).tolist(),
            "mean_abs_per_col": mean_abs.tolist(),
        }

        transformation = {
            "noise": noise,
            "theta": self.theta,
            "mu": self.mu,
            "dt": self.dt,
            "sigma": self.sigma,
            "sigma_eff": sigma_eff,
            "shape": (t_steps, n_cols),
            "per_column_independent": self.per_column_independent,
            "method": self.method,
            "summary": summary,
        }
        return transformation

    def _apply_perturbation(self, profiles: np.ndarray) -> np.ndarray:
        noise = self._transformation["noise"]
        if noise.shape != profiles.shape:
            raise ValueError(
                f"Stored noise shape {noise.shape} does not match profiles shape {profiles.shape}"
            )

        if self.method == "multiplicative":
            perturbed_profiles = profiles * (1 + noise)
        elif self.method == "additive":
            perturbed_profiles = profiles + noise
        else:
            raise ValueError(
                f"Unknown method '{self.method}'. Use 'additive' or 'multiplicative'."
            )

        return perturbed_profiles

    # -------- helpers --------

    @staticmethod
    def _simulate_ou(
        t_steps: int,
        n_cols: int,
        theta: float,
        mu: float,
        sigma_eff: np.ndarray,
        dt: float,
        per_column_independent: bool,
    ) -> np.ndarray:
        x0 = np.zeros(n_cols, dtype=float)  # initial state

        out = np.empty((t_steps, n_cols), dtype=float)
        out[0, :] = x0
        sqrt_dt = np.sqrt(dt)

        if per_column_independent:
            for t in range(1, t_steps):
                z = np.random.normal(size=n_cols)
                out[t, :] = (
                    out[t - 1, :]
                    + theta * (mu - out[t - 1, :]) * dt
                    + sigma_eff * sqrt_dt * z
                )
        else:
            for t in range(1, t_steps):
                z_shared = np.random.normal()
                out[t, :] = (
                    out[t - 1, :]
                    + theta * (mu - out[t - 1, :]) * dt
                    + sigma_eff * sqrt_dt * z_shared
                )
        return out


class CachedOUNoise(OUNoise):
    """Generating OU noise can be computationally expensive, especially for long time series.
    Here we simply keep a cache of a given size, and apply combinations of cached noise samples to new profiles.
    """

    def __init__(self, cache_size: int = 100, combine_n=2, **kwargs):
        super().__init__(**kwargs)
        self.cache_size = cache_size
        self.combine_n = combine_n
        self._cache = None

    def _infer_transformation(self, profiles: np.ndarray) -> Dict[str, Any]:
        n_profiles = profiles.shape[1]

        # if its the first iteration
        if self._cache is None:
            to_add = min(n_profiles, self.cache_size)
        elif self._cache.shape[1] < self.cache_size:
            to_add = min(n_profiles, self.cache_size - self._cache.shape[1])
        else:
            to_add = 0
        if to_add > 0:
            new_cache = self._simulate_ou(
                t_steps=profiles.shape[0],
                n_cols=to_add,
                theta=self.theta,
                mu=self.mu,
                sigma_eff=self.sigma,
                dt=self.dt,
                per_column_independent=self.per_column_independent,
            )
            if self._cache is None:
                self._cache = new_cache
            else:
                self._cache = np.concatenate([self._cache, new_cache], axis=1)

        n_samples_in_cache = self._cache.shape[1]

        # randomly sample columns from the cache for each profile column
        cache_columns_per_sample = np.random.choice(
            n_samples_in_cache,
            size=(
                n_profiles,
                self.combine_n,
            ),
            replace=True,
        )

        # average the selected noise samples for each profile column
        OU = np.mean(self._cache[:, cache_columns_per_sample], axis=-1)

        mean_per_profile = np.mean(profiles, axis=0)

        noise = OU * mean_per_profile
        transformation = {
            "noise": noise,
            "cache_columns_per_sample": cache_columns_per_sample,
            "mean_per_profile": mean_per_profile,
        }
        return transformation
