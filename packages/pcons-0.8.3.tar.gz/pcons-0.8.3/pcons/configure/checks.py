# SPDX-License-Identifier: MIT
"""Feature checking for pcons configure phase.

Provides utilities for testing compiler features, headers,
libraries, and other system capabilities.
"""

from __future__ import annotations

import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

from pcons.core.debug import trace

if TYPE_CHECKING:
    from pcons.configure.config import Configure
    from pcons.core.environment import Environment


@dataclass
class CheckResult:
    """Result of a feature check.

    Attributes:
        success: Whether the check passed.
        output: Compiler/linker output (for debugging).
        cached: Whether this result came from cache.
    """

    success: bool
    output: str = ""
    cached: bool = False


class ToolChecks:
    """Feature checking for a configured tool.

    Provides methods to test compiler capabilities like:
    - Flag support
    - Header availability
    - Type sizes
    - Predefined macros

    Example:
        checks = ToolChecks(config, env, "cc")

        if checks.check_flag("-Wall"):
            env.cc.flags.append("-Wall")

        if checks.check_header("pthread.h"):
            env.cc.defines.append("HAVE_PTHREAD_H")
    """

    # Shared across all instances so check dirs are uniquely numbered
    _check_counter: int = 0

    def __init__(
        self,
        config: Configure,
        env: Environment,
        tool_name: str,
    ) -> None:
        """Create a feature checker for a tool.

        Args:
            config: Configure context.
            env: Environment containing the tool.
            tool_name: Name of the tool to check (e.g., 'cc', 'cxx').
        """
        self._config = config
        self._env = env
        self._tool_name = tool_name
        self._tool_config = getattr(env, tool_name, None)

    @staticmethod
    def _caller_location(depth: int = 2) -> str:
        """Get caller's file:line for trace output."""
        import inspect

        frame = inspect.stack()[depth]
        return f"{frame.filename}:{frame.lineno}"

    @staticmethod
    def _source_preview(source: str, maxlen: int = 80) -> str:
        """One-line preview of source code for trace output."""
        # Collapse to single line, strip leading/trailing whitespace
        oneline = " ".join(source.split())
        if len(oneline) > maxlen:
            return oneline[:maxlen] + "..."
        return oneline

    def _get_compiler(self) -> str | None:
        """Get the compiler command."""
        if self._tool_config is None:
            return None
        return getattr(self._tool_config, "cmd", None)

    def _cache_key(self, check_type: str, *args: str) -> str:
        """Generate a cache key for a check."""
        compiler = self._get_compiler() or "unknown"
        return f"check:{self._tool_name}:{compiler}:{check_type}:{':'.join(args)}"

    def try_compile(
        self,
        source: str,
        *,
        extra_flags: list[str] | None = None,
        link: bool = False,
    ) -> CheckResult:
        """Try to compile (and optionally link) arbitrary source code.

        Use this for custom compile checks that aren't covered by the
        higher-level methods like check_header() or check_type().

        Results are cached based on a hash of the source code and flags.

        Args:
            source: Source code to compile.
            extra_flags: Additional compiler flags.
            link: If True, also link the program.

        Returns:
            CheckResult indicating success/failure.

        Example::

            checks = ToolChecks(config, env, "cxx")

            has_feature = checks.try_compile('''
                #include <optional>
                int main() { std::optional<int> x = 42; return *x; }
            ''').success
        """
        import hashlib

        code_hash = hashlib.sha256(source.encode()).hexdigest()[:16]
        flags_str = ":".join(extra_flags) if extra_flags else ""
        link_str = "link" if link else "compile"
        trace(
            "configure",
            "try_compile: %s%s (%s) at %s",
            link_str,
            f" flags={extra_flags}" if extra_flags else "",
            self._tool_name,
            self._caller_location(),
        )
        trace("configure", "  source: %s", self._source_preview(source))
        cache_key = self._cache_key("try_compile", code_hash, flags_str, link_str)
        cached = self._config.get(cache_key)
        if cached is not None:
            trace("configure", "  cached: %s", cached)
            return CheckResult(success=cached, cached=True)

        compiler = self._get_compiler()
        if compiler is None:
            return CheckResult(success=False, output="No compiler configured")

        cdir = self._make_check_dir()
        try:
            result = self._try_compile(
                compiler, source, extra_flags=extra_flags, link=link, check_dir=cdir
            )
        finally:
            self._cleanup_check_dir(*cdir)
        trace("configure", "  result: %s", "yes" if result.success else "no")
        self._config.set(cache_key, result.success)
        return result

    def check_flag(self, flag: str) -> CheckResult:
        """Check if the compiler accepts a flag.

        Compiles a minimal program with the flag to test if it's accepted.

        Args:
            flag: Compiler flag to test (e.g., '-Wall', '-std=c++20').

        Returns:
            CheckResult indicating success/failure.
        """
        trace(
            "configure",
            "check_flag: %s (%s) at %s",
            flag,
            self._tool_name,
            self._caller_location(),
        )
        cache_key = self._cache_key("flag", flag)
        cached = self._config.get(cache_key)
        if cached is not None:
            trace("configure", "  cached: %s", cached)
            return CheckResult(success=cached, cached=True)

        compiler = self._get_compiler()
        if compiler is None:
            return CheckResult(success=False, output="No compiler configured")

        # Minimal C program
        source = "int main(void) { return 0; }\n"

        cdir = self._make_check_dir()
        try:
            result = self._try_compile(
                compiler, source, extra_flags=[flag], check_dir=cdir
            )
        finally:
            self._cleanup_check_dir(*cdir)
        trace("configure", "  result: %s", "yes" if result.success else "no")
        self._config.set(cache_key, result.success)
        return result

    def check_header(
        self,
        header: str,
        *,
        defines: list[str] | None = None,
        extra_flags: list[str] | None = None,
    ) -> CheckResult:
        """Check if a header file is available.

        Args:
            header: Header to check (e.g., 'stdio.h', 'pthread.h').
            defines: Preprocessor defines needed to include the header
                (e.g., ['_XOPEN_SOURCE'] for ucontext.h on macOS).
            extra_flags: Additional compiler flags.

        Returns:
            CheckResult indicating success/failure.

        Example::

            # ucontext.h requires _XOPEN_SOURCE on macOS
            checks.check_header("ucontext.h", defines=["_XOPEN_SOURCE"])
        """
        trace(
            "configure",
            "check_header: %s (%s) at %s",
            header,
            self._tool_name,
            self._caller_location(),
        )
        # Include defines in cache key so different define combos are cached separately
        cache_parts = [header]
        if defines:
            cache_parts.extend(sorted(defines))
        if extra_flags:
            cache_parts.extend(sorted(extra_flags))
        cache_key = self._cache_key("header", *cache_parts)
        cached = self._config.get(cache_key)
        if cached is not None:
            trace("configure", "  cached: %s", cached)
            return CheckResult(success=cached, cached=True)

        compiler = self._get_compiler()
        if compiler is None:
            return CheckResult(success=False, output="No compiler configured")

        define_lines = ""
        if defines:
            define_lines = "\n".join(f"#define {d}" for d in defines) + "\n"

        source = f"{define_lines}#include <{header}>\nint main(void) {{ return 0; }}\n"

        cdir = self._make_check_dir()
        try:
            result = self._try_compile(
                compiler, source, extra_flags=extra_flags, check_dir=cdir
            )
        finally:
            self._cleanup_check_dir(*cdir)
        trace("configure", "  result: %s", "yes" if result.success else "no")
        self._config.set(cache_key, result.success)
        return result

    def check_type(
        self, type_name: str, *, headers: list[str] | None = None
    ) -> CheckResult:
        """Check if a type is defined.

        Args:
            type_name: Type to check (e.g., 'size_t', 'int64_t').
            headers: Headers to include.

        Returns:
            CheckResult indicating success/failure.
        """
        trace(
            "configure",
            "check_type: %s (%s) at %s",
            type_name,
            self._tool_name,
            self._caller_location(),
        )
        cache_key = self._cache_key("type", type_name)
        cached = self._config.get(cache_key)
        if cached is not None:
            trace("configure", "  cached: %s", cached)
            return CheckResult(success=cached, cached=True)

        compiler = self._get_compiler()
        if compiler is None:
            return CheckResult(success=False, output="No compiler configured")

        includes = ""
        if headers:
            includes = "\n".join(f"#include <{h}>" for h in headers)

        source = f"{includes}\nint main(void) {{ {type_name} x; (void)x; return 0; }}\n"

        cdir = self._make_check_dir()
        try:
            result = self._try_compile(compiler, source, check_dir=cdir)
        finally:
            self._cleanup_check_dir(*cdir)
        trace("configure", "  result: %s", "yes" if result.success else "no")
        self._config.set(cache_key, result.success)
        return result

    def check_type_size(
        self, type_name: str, *, headers: list[str] | None = None
    ) -> int | None:
        """Get the size of a type.

        Args:
            type_name: Type to check (e.g., 'int', 'long', 'void*').
            headers: Headers to include.

        Returns:
            Size in bytes, or None if check failed.
        """
        trace(
            "configure",
            "check_type_size: %s (%s) at %s",
            type_name,
            self._tool_name,
            self._caller_location(),
        )
        cache_key = self._cache_key("sizeof", type_name)
        cached = self._config.get(cache_key)
        if cached is not None:
            trace("configure", "  cached: %s", cached)
            return int(cached)

        compiler = self._get_compiler()
        if compiler is None:
            return None

        includes = ""
        if headers:
            includes = "\n".join(f"#include <{h}>" for h in headers)

        # Use compile-time assertion to encode the size
        # This avoids needing to run the compiled program
        cdir = self._make_check_dir()
        try:
            for size in [1, 2, 4, 8, 16]:
                source = f"""
{includes}
int check[sizeof({type_name}) == {size} ? 1 : -1];
int main(void) {{ return 0; }}
"""
                result = self._try_compile(compiler, source, check_dir=cdir)
                if result.success:
                    trace("configure", "  result: %d bytes", size)
                    self._config.set(cache_key, size)
                    return size
        finally:
            self._cleanup_check_dir(*cdir)

        trace("configure", "  result: unknown size")
        return None

    def check_define(self, define: str) -> str | None:
        """Get the value of a predefined macro.

        Args:
            define: Macro name (e.g., '__GNUC__', '_MSC_VER').

        Returns:
            Macro value as string, or None if not defined.
        """
        trace(
            "configure",
            "check_define: %s (%s) at %s",
            define,
            self._tool_name,
            self._caller_location(),
        )
        cache_key = self._cache_key("define", define)
        cached = self._config.get(cache_key)
        if cached is not None:
            value = cached if cached != "__UNDEFINED__" else None
            trace("configure", "  cached: %s", value)
            return value

        compiler = self._get_compiler()
        if compiler is None:
            return None

        # Use preprocessor to output the macro value
        source = f"""
#ifdef {define}
PCONS_VALUE={define}
#else
PCONS_UNDEFINED
#endif
"""
        cdir = self._make_check_dir()
        result = self._try_preprocess(compiler, source, check_dir=cdir)
        self._cleanup_check_dir(*cdir)
        if not result.success:
            self._config.set(cache_key, "__UNDEFINED__")
            return None

        # Parse the output to find the value
        for line in result.output.split("\n"):
            if line.startswith("PCONS_VALUE="):
                value = line[len("PCONS_VALUE=") :].strip()
                trace("configure", "  result: %s", value)
                self._config.set(cache_key, value)
                return value
            if "PCONS_UNDEFINED" in line:
                trace("configure", "  result: not defined")
                self._config.set(cache_key, "__UNDEFINED__")
                return None

        trace("configure", "  result: not defined")
        self._config.set(cache_key, "__UNDEFINED__")
        return None

    def check_function(
        self,
        function: str,
        *,
        headers: list[str] | None = None,
        libs: list[str] | None = None,
    ) -> CheckResult:
        """Check if a function is available.

        Args:
            function: Function name (e.g., 'pthread_create').
            headers: Headers to include.
            libs: Libraries to link.

        Returns:
            CheckResult indicating success/failure.
        """
        trace(
            "configure",
            "check_function: %s (%s) at %s",
            function,
            self._tool_name,
            self._caller_location(),
        )
        cache_key = self._cache_key("function", function)
        cached = self._config.get(cache_key)
        if cached is not None:
            trace("configure", "  cached: %s", cached)
            return CheckResult(success=cached, cached=True)

        compiler = self._get_compiler()
        if compiler is None:
            return CheckResult(success=False, output="No compiler configured")

        includes = ""
        if headers:
            includes = "\n".join(f"#include <{h}>" for h in headers)

        # Try to get address of function to check if it exists
        source = f"""
{includes}
int main(void) {{
    void *p = (void*){function};
    (void)p;
    return 0;
}}
"""
        extra_flags: list[str] = []
        if libs:
            extra_flags.extend(f"-l{lib}" for lib in libs)

        cdir = self._make_check_dir()
        try:
            result = self._try_compile(
                compiler, source, extra_flags=extra_flags, link=True, check_dir=cdir
            )
        finally:
            self._cleanup_check_dir(*cdir)
        trace("configure", "  result: %s", "yes" if result.success else "no")
        self._config.set(cache_key, result.success)
        return result

    def _make_check_dir(self) -> tuple[Path, bool]:
        """Create a directory for a configure check.

        When --debug=configure is active, creates a persistent numbered
        directory under <build_dir>/.configure-checks/ so users can
        inspect the source files and compiler output.  Otherwise uses
        a temporary directory that will be cleaned up by the caller.

        Returns:
            (directory_path, persistent) — persistent=True means the caller
            should NOT delete it.
        """
        from pcons.core.debug import is_enabled

        ToolChecks._check_counter += 1

        if is_enabled("configure"):
            base = self._config.build_dir / ".configure-checks"
            check_dir = base / f"check_{self._check_counter:03d}"
            check_dir.mkdir(parents=True, exist_ok=True)
            trace("configure", "  dir: %s", check_dir)
            return check_dir, True

        tmpdir = Path(tempfile.mkdtemp())
        return tmpdir, False

    @staticmethod
    def _cleanup_check_dir(check_dir: Path, persistent: bool) -> None:
        """Remove a check directory if it's not persistent."""
        if not persistent:
            import shutil

            shutil.rmtree(check_dir, ignore_errors=True)

    def _try_compile(
        self,
        compiler: str,
        source: str,
        *,
        extra_flags: list[str] | None = None,
        link: bool = False,
        check_dir: tuple[Path, bool] | None = None,
    ) -> CheckResult:
        """Try to compile source code.

        Args:
            compiler: Compiler command.
            source: Source code to compile.
            extra_flags: Additional compiler flags.
            link: If True, also link the program.
            check_dir: Optional (dir, persistent) from _make_check_dir().
                If not provided, creates and manages its own.

        Returns:
            CheckResult with compilation result.
        """
        suffix = ".c" if self._tool_name == "cc" else ".cpp"
        owns_dir = check_dir is None
        dir_path, persistent = check_dir if check_dir else self._make_check_dir()

        try:
            src_path = dir_path / f"check{suffix}"
            out_path = dir_path / "check.out"

            src_path.write_text(source)

            cmd = [compiler]
            if not link:
                cmd.append("-c")
            cmd.extend(["-o", str(out_path), str(src_path)])
            if extra_flags:
                cmd.extend(extra_flags)

            trace("configure", "  cmd: %s", " ".join(cmd))

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                output = result.stderr + result.stdout
                if result.returncode != 0:
                    trace("configure", "  exit code: %d", result.returncode)
                    if output.strip():
                        for line in output.strip().splitlines()[:10]:
                            trace("configure", "  | %s", line)
                return CheckResult(
                    success=result.returncode == 0,
                    output=output,
                )
            except (subprocess.TimeoutExpired, OSError) as e:
                trace("configure", "  error: %s", e)
                return CheckResult(success=False, output=str(e))
        finally:
            if owns_dir:
                self._cleanup_check_dir(dir_path, persistent)

    def _try_preprocess(
        self,
        compiler: str,
        source: str,
        *,
        check_dir: tuple[Path, bool] | None = None,
    ) -> CheckResult:
        """Run the preprocessor on source code.

        Args:
            compiler: Compiler command.
            source: Source code to preprocess.
            check_dir: Optional (dir, persistent) from _make_check_dir().

        Returns:
            CheckResult with preprocessor output.
        """
        suffix = ".c" if self._tool_name == "cc" else ".cpp"
        owns_dir = check_dir is None
        dir_path, persistent = check_dir if check_dir else self._make_check_dir()

        try:
            src_path = dir_path / f"check{suffix}"
            src_path.write_text(source)

            cmd = [compiler, "-E", str(src_path)]
            trace("configure", "  cmd: %s", " ".join(cmd))

            try:
                result = subprocess.run(
                    cmd,
                    capture_output=True,
                    text=True,
                    timeout=30,
                )
                if result.returncode != 0:
                    trace("configure", "  exit code: %d", result.returncode)
                    if result.stderr.strip():
                        for line in result.stderr.strip().splitlines()[:10]:
                            trace("configure", "  | %s", line)
                return CheckResult(
                    success=result.returncode == 0,
                    output=result.stdout,
                )
            except (subprocess.TimeoutExpired, OSError) as e:
                trace("configure", "  error: %s", e)
                return CheckResult(success=False, output=str(e))
        finally:
            if owns_dir:
                self._cleanup_check_dir(dir_path, persistent)
