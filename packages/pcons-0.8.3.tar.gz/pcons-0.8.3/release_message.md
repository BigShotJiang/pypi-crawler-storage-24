    Gary Oberbrunner (10):
          Fix $ORIGIN in linker flags silently producing broken output
          Narrow exception handling to avoid silently swallowing errors
          Escape literal $ in ninja command lines for shell passthrough
          Add configure debug tracing and --debug=help
          Add defines and extra_flags parameters to check_header()
          Preserve configure check files when --debug=configure is active
          Fix check dir numbering: one dir per public check, not per compile
          Fix check dir counter: use class variable shared across all instances
          Add caller location and source preview to configure check traces
          Bump version to v0.8.3

