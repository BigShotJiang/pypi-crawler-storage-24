"""
Dazzle info command.

Show Dazzle runtime installation status and available features.
"""

import typer


def info_command() -> None:
    """
    Show Dazzle runtime installation status and available features.
    """
    typer.echo("Dazzle Runtime Status")
    typer.echo("=" * 50)

    # Check Dazzle Backend
    dnr_back_available = False
    fastapi_available = False
    try:
        import dazzle_back  # noqa: F401

        dnr_back_available = True
        from dazzle_back.runtime import FASTAPI_AVAILABLE

        fastapi_available = FASTAPI_AVAILABLE
    except ImportError:
        pass

    # Check Dazzle UI
    dnr_ui_available = False
    try:
        import dazzle_ui  # noqa: F401

        dnr_ui_available = True
    except ImportError:
        pass

    # Check uvicorn
    uvicorn_available = False
    try:
        import uvicorn  # noqa: F401

        uvicorn_available = True
    except ImportError:
        pass

    def status(available: bool) -> str:
        return "✓ installed" if available else "✗ not installed"

    typer.echo(f"Dazzle Backend:   {status(dnr_back_available)}")
    typer.echo(f"Dazzle UI:        {status(dnr_ui_available)}")
    typer.echo(f"FastAPI:       {status(fastapi_available)}")
    typer.echo(f"Uvicorn:       {status(uvicorn_available)}")

    typer.echo("\nAvailable Commands:")
    if dnr_ui_available:
        typer.echo("  dazzle build-ui   Generate UI (Vite/JS/HTML)")
    if dnr_back_available:
        typer.echo("  dazzle build-api  Generate API spec")
    if dnr_back_available and fastapi_available and uvicorn_available:
        typer.echo("  dazzle serve      Run development server")
    elif dnr_ui_available:
        typer.echo("  dazzle serve --ui-only  Serve UI only")

    if not (dnr_back_available and dnr_ui_available):
        typer.echo("\nTo install runtime packages:")
        typer.echo("  pip install dazzle-dsl[serve]")
        if not fastapi_available:
            typer.echo("  (missing: fastapi)")
        if not uvicorn_available:
            typer.echo("  (missing: uvicorn)")
