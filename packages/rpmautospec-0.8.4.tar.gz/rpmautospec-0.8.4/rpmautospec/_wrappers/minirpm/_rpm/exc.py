class RpmError(Exception):
    pass
