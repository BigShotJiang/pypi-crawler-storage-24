"""Verify that the public API is importable and complete."""

import airena_sdk


def test_version_is_string():
    assert isinstance(airena_sdk.__version__, str)
    # Must look like a version (at least major.minor.patch)
    parts = airena_sdk.__version__.split(".")
    assert len(parts) >= 3, f"unexpected version format: {airena_sdk.__version__}"


def test_protocol_constant():
    assert airena_sdk.PROTOCOL == "openra.v1"


def test_public_api_exports():
    expected = {
        "__version__",
        "PROTOCOL",
        "log",
        "send",
        "send_error",
        "BotRunner",
        "move",
        "attack_unit",
        "deploy",
        "stop",
        "harvest",
        "queue_production",
        "place_building",
        "noop",
    }
    assert expected.issubset(set(airena_sdk.__all__))


def test_botrunner_is_class():
    assert isinstance(airena_sdk.BotRunner, type)
