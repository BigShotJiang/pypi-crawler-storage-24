"""Action builder helpers for the openra.v1 protocol.

Each function returns a dict ready to be appended to the actions list.

Field names match the canonical actions.schema.json (source of truth).
"""


def move(unit_id: int, x: int, y: int) -> dict:
    """Move a unit to a position."""
    return {"action": "move", "unit_id": unit_id, "x": x, "y": y}


def attack_unit(unit_id: int, target_unit_id: int) -> dict:
    """Order a unit to attack a specific target.

    Args:
        unit_id: ID of the attacking unit.
        target_unit_id: ID of the target unit.
    """
    return {"action": "attack_unit", "unit_id": unit_id, "target_unit_id": target_unit_id}


def deploy(unit_id: int) -> dict:
    """Deploy a unit (e.g., MCV -> Construction Yard)."""
    return {"action": "deploy", "unit_id": unit_id}


def stop(unit_id: int) -> dict:
    """Stop a unit."""
    return {"action": "stop", "unit_id": unit_id}


def harvest(unit_id: int, x: int, y: int) -> dict:
    """Order a harvester to harvest at a position."""
    return {"action": "harvest", "unit_id": unit_id, "x": x, "y": y}


def queue_production(producer_id: int, item_type_id: str, count: int = 1) -> dict:
    """Queue production of a unit or building type at a production facility.

    Args:
        producer_id: ID of the production building (e.g. Construction Yard).
        item_type_id: Type ID of the item to produce (e.g. 'powr', 'e1').
        count: Number of items to queue (default 1).
    """
    return {
        "action": "queue_production",
        "producer_id": producer_id,
        "item_type_id": item_type_id,
        "count": count,
    }


def place_building(building_type_id: str, x: int, y: int) -> dict:
    """Place a completed building at a position.

    Requires a completed building item in the production queue.

    Args:
        building_type_id: Type ID of the building to place (e.g. 'powr').
        x: Target X coordinate for placement.
        y: Target Y coordinate for placement.
    """
    return {"action": "place_building", "building_type_id": building_type_id, "x": x, "y": y}


def noop() -> dict:
    """Do nothing. Placeholder action."""
    return {"action": "noop"}
