# Copyright (c) 2025-2026 Trent AI. All rights reserved.
# Licensed under the Trent AI Proprietary License.

"""CLI commands for OpenClaw Trent audit."""

import argparse
import sys
from pathlib import Path

from trent_mcp import __version__

CLI_AUDIT_TIMEOUT = 180  # seconds (sub-agent + attack chain validation takes ~120s)


def _run_audit_sync(metadata: dict) -> None:
    """Run the OpenClaw security audit synchronously from the CLI."""
    import asyncio

    redacted_count = len(metadata.get("redacted_paths", []))
    skill_count = len(metadata.get("skills", []))
    print(f"  Collected metadata: {skill_count} skill(s), {redacted_count} secret(s) redacted")
    print("  Sending to Trent AppSec Advisor (no secrets transmitted)...\n")

    # Build prompt
    from trent_mcp.openclaw.audit_prompt import build_audit_prompt

    message = build_audit_prompt(metadata)

    # Send to chat endpoint
    async def _do_audit():
        from trent_mcp.client.trent_api import TrentAPIClient

        client = TrentAPIClient()
        try:
            return await asyncio.wait_for(
                client.chat(message=message),
                timeout=CLI_AUDIT_TIMEOUT,
            )
        finally:
            await client.close()

    try:
        response = asyncio.run(_do_audit())
    except asyncio.TimeoutError:
        print(
            f"\n  Audit timed out after {CLI_AUDIT_TIMEOUT}s. Try again later.",
            file=sys.stderr,
        )
        return
    except KeyboardInterrupt:
        print("\n  Audit cancelled.", file=sys.stderr)
        return
    except Exception as e:
        print(f"\n  Audit failed: {e}", file=sys.stderr)
        return

    if response.get("error"):
        print(f"\n  Error: {response['content']}", file=sys.stderr)
        return

    print("--- OpenClaw Security Audit Results ---\n")
    print(response["content"])
    print("\n--- End of Audit ---")


def audit():
    """Run OpenClaw security audit from the CLI."""
    parser = argparse.ArgumentParser(
        prog="trent-openclaw-audit",
        description="Audit your OpenClaw deployment for security risks.",
    )
    parser.add_argument(
        "--version",
        action="version",
        version=f"%(prog)s {__version__}",
    )
    parser.add_argument(
        "--path",
        type=str,
        default=None,
        help="Path to OpenClaw config directory (default: ~/.openclaw)",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Output raw JSON metadata instead of sending to Trent API",
    )
    args = parser.parse_args()

    from trent_mcp.openclaw.openclaw_config.collector import collect_openclaw_metadata

    path_arg = Path(args.path) if args.path else None
    metadata = collect_openclaw_metadata(openclaw_path=path_arg)

    if metadata.get("error"):
        print(f"Error: {metadata['message']}", file=sys.stderr)
        sys.exit(1)

    if args.json:
        import json

        print(json.dumps(metadata, indent=2, default=str))
        return

    print("\nAnalyzing your OpenClaw configuration for security risks...\n")
    _run_audit_sync(metadata)
