from . import _wingfoil as _ext


from .stream import *

from ._wingfoil import *
from ._wingfoil import Graph 

from .pandas_helpers import to_dataframe, build_dataframe

__doc__ = getattr(_ext, "__doc__", "")
__version__ = getattr(_ext, "__version__", None)

__all__ = list(getattr(_ext, "__all__", [])) + ["to_dataframe", "build_dataframe"]

# User-friendly aliases for KDB+ functions
kdb_read = _ext.py_kdb_read
kdb_write = _ext.py_kdb_write
