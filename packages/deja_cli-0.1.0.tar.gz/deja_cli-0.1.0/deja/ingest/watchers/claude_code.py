from __future__ import annotations

import json
import sys
from pathlib import Path

from deja.ingest.watchers.base import BaseWatcher


class ClaudeCodeWatcher(BaseWatcher):
    """Watches ~/.claude/projects/**/session-memory/summary.md for new session summaries."""

    def get_watch_paths(self) -> list[Path]:
        return [Path.home() / ".claude" / "projects"]

    def should_process(self, path: Path) -> bool:
        """Process summary.md files inside session-memory/ directories."""
        return (
            path.name == "summary.md"
            and path.parent.name == "session-memory"
        )

    def get_project_name(self, path: Path) -> str:
        """Extract project name from path.

        Path structure: ~/.claude/projects/<hash>/session-memory/summary.md
        First try reading ~/.claude/projects/<hash>/.project (if it exists).
        Fall back to the hash directory name.
        """
        # path.parents: [session-memory/, <hash>/, projects/, .claude/, ~/, ...]
        try:
            hash_dir = path.parent.parent  # <hash> dir
            project_file = hash_dir / ".project"
            if project_file.exists():
                content = project_file.read_text(encoding="utf-8").strip()
                # Could be JSON with a name field or plain text
                try:
                    data = json.loads(content)
                    if isinstance(data, dict) and "name" in data:
                        return str(data["name"])
                    if isinstance(data, dict) and "project_name" in data:
                        return str(data["project_name"])
                except (json.JSONDecodeError, KeyError):
                    if content:
                        return content
            # Claude Code's hash dir name is the absolute project path with '/' → '-'.
            # e.g. "-Users-tree-Desktop-deja" encodes /Users/tree/Desktop/deja
            # Reconstruct the path and check if it actually exists on disk —
            # if it does, Path.name gives the correct project name regardless of hyphens.
            raw = hash_dir.name
            reconstructed = Path("/" + raw.lstrip("-").replace("-", "/"))
            if reconstructed.exists():
                return reconstructed.name
            # Reconstructed path doesn't exist (project path contains hyphens, so
            # the round-trip is ambiguous). Fall back to last dash-separated token.
            return raw.split("-")[-1] or raw
        except Exception as e:
            print(
                f"[deja] Could not determine project name for {path}: {e}",
                file=sys.stderr,
            )
            return "unknown"
