from __future__ import annotations

import asyncio
import sys
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Callable, Awaitable, Optional

from deja.core.store import MemoryStore
from deja.llm.base import LLMAdapter
from deja.llm.embedding import EmbeddingAdapter


class BaseWatcher(ABC):
    def __init__(
        self,
        store: MemoryStore,
        extractor_fn: Callable[..., Awaitable[list[dict]]],
        adapter: Optional[LLMAdapter],
        debounce_seconds: int = 30,
        embedding_adapter: Optional[EmbeddingAdapter] = None,
    ) -> None:
        self.store = store
        self.extractor_fn = extractor_fn
        self.adapter = adapter
        self.debounce_seconds = debounce_seconds
        self.embedding_adapter = embedding_adapter
        # path -> last mtime we processed
        self._processed: dict[Path, float] = {}
        # path -> pending debounce task
        self._pending: dict[Path, asyncio.TimerHandle] = {}

    @abstractmethod
    def get_watch_paths(self) -> list[Path]: ...

    @abstractmethod
    def should_process(self, path: Path) -> bool: ...

    @abstractmethod
    def get_project_name(self, path: Path) -> str: ...

    def parse_transcript(self, content: str) -> str:
        """Convert raw file content to a plain-text transcript for extraction.

        Default implementation returns content unchanged (suitable for plain text
        files like summary.md). Subclasses override this to parse JSON/JSONL formats.
        """
        return content

    def handle_file_event(self, path: Path) -> None:
        """Called from watchdog thread. Schedules debounced async processing."""
        if not self.should_process(path):
            return

        loop = asyncio.get_event_loop()

        # Cancel any existing pending timer for this path
        if path in self._pending:
            self._pending[path].cancel()

        handle = loop.call_later(
            self.debounce_seconds,
            lambda: asyncio.ensure_future(self._process(path)),
        )
        self._pending[path] = handle

    async def _process(self, path: Path) -> None:
        """Read file and run extraction pipeline."""
        self._pending.pop(path, None)

        if not path.exists():
            return

        try:
            mtime = path.stat().st_mtime
        except OSError:
            return

        # Skip if we already processed this exact version
        if self._processed.get(path) == mtime:
            return

        try:
            content = path.read_text(encoding="utf-8", errors="replace")
        except OSError as e:
            print(f"[deja] Failed to read {path}: {e}", file=sys.stderr)
            return

        project = self.get_project_name(path)
        source = self.__class__.__name__.lower().replace("watcher", "")

        content = self.parse_transcript(content)

        if self.adapter is None:
            # No LLM configured — save the raw summary as a single progress memory.
            # The agent-driven path (CLAUDE.md skill prompt) handles structured extraction.
            raw_memory = {
                "type": "progress",
                "category": "agent",
                "content": content[:2000].strip(),  # truncate to avoid huge entries
                "scope": f"project:{project}",
                "project": project,
                "source": source,
                "confidence": 0.5,
            }
            try:
                await self.store.save(raw_memory)
                print(
                    f"[deja] Saved raw summary from {path} (no LLM configured)",
                    file=sys.stderr,
                )
            except Exception as e:
                print(f"[deja] Failed to save raw summary: {e}", file=sys.stderr)
            self._processed[path] = mtime
            return

        try:
            memories = await self.extractor_fn(content, project, source, self.adapter)
        except Exception as e:
            print(f"[deja] Extraction failed for {path}: {e}", file=sys.stderr)
            return

        saved = 0
        for memory in memories:
            try:
                emb_bytes = None
                if self.embedding_adapter is not None:
                    try:
                        emb = await self.embedding_adapter.embed(memory["content"])
                        emb_bytes = EmbeddingAdapter.to_bytes(emb)
                    except Exception as emb_e:
                        print(f"[deja] Embedding failed: {emb_e}", file=sys.stderr)
                await self.store.save(memory, emb_bytes)
                saved += 1
            except Exception as e:
                print(f"[deja] Failed to save memory: {e}", file=sys.stderr)

        self._processed[path] = mtime
        if saved:
            print(
                f"[deja] Saved {saved} memories from {path} (project: {project})",
                file=sys.stderr,
            )
