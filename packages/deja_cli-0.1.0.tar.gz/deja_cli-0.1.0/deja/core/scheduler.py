from __future__ import annotations

import asyncio
import sys
from typing import TYPE_CHECKING

from apscheduler.schedulers.background import BackgroundScheduler

if TYPE_CHECKING:
    from deja.core.reflection import ReflectionEngine


def make_scheduler(
    engine: "ReflectionEngine",
    loop: asyncio.AbstractEventLoop,
) -> BackgroundScheduler:
    """Create and configure the background scheduler for the watch daemon.

    Schedule:
    - Every 5 minutes: check token thresholds, auto-trigger observer/reflector
    - Nightly 2:00am UTC: run_decay
    - Nightly 2:05am UTC: run_promote
    - Nightly 2:10am UTC: run_archive
    """
    scheduler = BackgroundScheduler(timezone="UTC")

    def _run(coro_fn, label: str, *args):
        """Submit a coroutine to the async event loop from the scheduler thread."""
        try:
            future = asyncio.run_coroutine_threadsafe(coro_fn(*args), loop)
            result = future.result(timeout=300)
            if result:
                print(f"[deja scheduler] {label}: {result}", file=sys.stderr)
        except Exception as e:
            print(f"[deja scheduler] {label} error: {e}", file=sys.stderr)

    scheduler.add_job(
        lambda: _run(engine.check_and_trigger, "token-trigger check"),
        "interval",
        minutes=5,
        id="token_trigger",
    )
    scheduler.add_job(
        lambda: _run(engine.run_decay, "decay"),
        "cron",
        hour=2,
        minute=0,
        id="nightly_decay",
    )
    scheduler.add_job(
        lambda: _run(engine.run_promote, "promote"),
        "cron",
        hour=2,
        minute=5,
        id="nightly_promote",
    )
    scheduler.add_job(
        lambda: _run(engine.run_archive, "archive"),
        "cron",
        hour=2,
        minute=10,
        id="nightly_archive",
    )

    return scheduler
