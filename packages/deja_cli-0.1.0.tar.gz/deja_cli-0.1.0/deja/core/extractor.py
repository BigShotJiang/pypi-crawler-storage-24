from __future__ import annotations

import sys
from typing import Optional

from deja.llm.base import LLMAdapter

EXTRACTION_SYSTEM = """You are a memory extraction system for a software engineer.
Given a coding session transcript or summary, extract ONLY memories
that would be genuinely useful in a future session.

Be ruthless — most session content is NOT worth remembering.
Only extract things that are:
- Non-obvious (not derivable from reading the codebase)
- Reusable (would apply in future sessions)
- Important (would cause problems if forgotten)

Memory types:
- preference: how the user likes to code (style, tools, patterns)
- pattern: reusable solution / architectural approach that applies across contexts ("knowing what works")
- decision: non-obvious architectural choice with reasoning
- gotcha: bug, trap, or non-obvious issue to avoid
- progress: current state of in-progress work
- procedure: reusable ordered steps for a recurring class of work ("knowing how to execute"). Keep thin: numbered steps + tool hints + exit criteria only. Do NOT inline gotchas or decisions — save those as separate memory types.

Category:
- user: personal preferences and habits (applies across all projects)
- agent: operational knowledge discovered while doing work

Domain (optional, coarse routing tag — use for procedure type mainly):
- debug | build | test | deploy | research

Output ONLY valid JSON:
{
  "memories": [
    {
      "type": "preference|pattern|decision|gotcha|progress|procedure",
      "category": "user|agent",
      "content": "concise, self-contained fact. 1-2 sentences max for most types. For procedure: one-line description followed by numbered steps, tool hints, and exit criteria.",
      "scope": "global|project",
      "project": "project_name or null if global",
      "confidence": 0.0-1.0,
      "domain": "debug|build|test|deploy|research|null"
    }
  ]
}

If nothing is worth remembering, return: {"memories": []}"""

EXTRACTION_SCHEMA = {
    "type": "object",
    "properties": {
        "memories": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "type": {
                        "type": "string",
                        "enum": ["preference", "pattern", "decision", "gotcha", "progress", "procedure"],
                    },
                    "category": {"type": "string", "enum": ["user", "agent"]},
                    "content": {"type": "string"},
                    "scope": {"type": "string", "enum": ["global", "project"]},
                    "project": {"type": ["string", "null"]},
                    "confidence": {"type": "number"},
                    "domain": {"type": ["string", "null"]},
                },
                "required": ["type", "category", "content", "scope", "confidence"],
            },
        }
    },
    "required": ["memories"],
}


async def extract_memories(
    transcript: str,
    project: str,
    source: str,
    adapter: LLMAdapter,
) -> list[dict]:
    """Extract memories from a session transcript or summary.

    Returns list of memory dicts ready to pass to store.save().
    """
    if not transcript.strip():
        return []

    user_prompt = f"Session transcript/summary to extract memories from:\n\n{transcript}"

    try:
        result = await adapter.complete_structured(
            system=EXTRACTION_SYSTEM,
            user=user_prompt,
            schema=EXTRACTION_SCHEMA,
        )
    except Exception as e:
        print(f"[deja] Extraction LLM error: {e}", file=sys.stderr)
        return []

    memories = result.get("memories", [])
    if not isinstance(memories, list):
        return []

    output = []
    for mem in memories:
        if not isinstance(mem, dict):
            continue
        if not mem.get("content") or not mem.get("type"):
            continue

        # Normalize scope: if scope is "project" but no project given, use the provided project
        scope = mem.get("scope", "global")
        mem_project = mem.get("project") or (project if scope == "project" else None)
        if scope == "project" and mem_project:
            scope_value = f"project:{mem_project}"
        else:
            scope_value = "global"
            mem_project = None

        output.append(
            {
                "type": mem["type"],
                "category": mem.get("category", "agent"),
                "content": mem["content"],
                "scope": scope_value,
                "project": mem_project,
                "source": source,
                "confidence": float(mem.get("confidence", 0.8)),
                "domain": mem.get("domain"),
            }
        )

    return output
