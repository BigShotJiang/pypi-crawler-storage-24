from __future__ import annotations

import anthropic

from deja.llm.base import LLMAdapter, LLMResponse


class AnthropicAdapter(LLMAdapter):
    def __init__(self, model: str, api_key: str | None = None) -> None:
        self.model = model
        self._client = anthropic.AsyncAnthropic(api_key=api_key)

    async def complete(self, system: str, user: str, **kwargs) -> LLMResponse:
        message = await self._client.messages.create(
            model=self.model,
            max_tokens=4096,
            system=system,
            messages=[{"role": "user", "content": user}],
        )
        content = message.content[0].text
        return LLMResponse(content=content, raw=message)
