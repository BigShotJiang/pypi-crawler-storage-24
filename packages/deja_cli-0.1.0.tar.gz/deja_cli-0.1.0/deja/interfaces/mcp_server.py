"""MCP server for deja — thin wrappers over core. No business logic here."""
from __future__ import annotations

import json
from typing import Optional

from mcp.server.fastmcp import FastMCP

from deja.config import load_config
from deja.core.store import MemoryStore
from deja.interfaces.cli import _format_load_result
from deja.llm.factory import create_embedding_adapter

mcp = FastMCP("deja")

_store: Optional[MemoryStore] = None


async def _get_store() -> MemoryStore:
    global _store
    if _store is None:
        _store = MemoryStore(load_config())
        await _store.init_db()
    return _store


@mcp.tool()
async def memory_load(project: Optional[str] = None, context: Optional[str] = None) -> str:
    """Load memories at session start. Returns type-budgeted memories as compact text
    (top-5 per type for gotcha/decision/preference/pattern, top-3 procedures by reuse,
    top-3 recent progress). Call this at the beginning of every session.

    context: task description to re-rank memories by relevance instead of raw confidence.
    Always pass a short summary of what the user wants to work on — e.g. "fix auth bug in
    login flow" or "add dark mode to dashboard". Without context, memories are sorted by
    raw confidence and the most relevant ones may not surface.
    """
    store = await _get_store()
    config = load_config()
    embedding_adapter = await create_embedding_adapter(config) if context else None
    result = await store.load_budgeted(project, context=context, embedding_adapter=embedding_adapter)
    return _format_load_result(result)


@mcp.tool()
async def memory_save(
    content: str,
    type: str,
    project: Optional[str] = None,
    confidence: float = 1.0,
    category: str = "agent",
    domain: Optional[str] = None,
) -> str:
    """Save a memory to the vault. Deduplicates automatically — if a near-identical
    memory already exists, its confidence is bumped instead of inserting a duplicate.

    type: preference | pattern | decision | gotcha | progress | procedure
    category: user (preferences/habits) | agent (operational knowledge)
    domain: debug | build | test | deploy | research (optional, for procedure type)
    """
    store = await _get_store()
    mem_id = await store.save(
        {
            "content": content,
            "type": type,
            "project": project,
            "scope": f"project:{project}" if project else "global",
            "confidence": confidence,
            "category": category,
            "domain": domain,
            "source": "mcp",
        }
    )
    return json.dumps({"id": mem_id, "status": "saved"})


@mcp.tool()
async def memory_search(
    query: str,
    project: Optional[str] = None,
    type: Optional[str] = None,
    limit: int = 10,
) -> str:
    """Full-text search over active memories. Use when looking for specific knowledge
    mid-session. With project: searches global + that project. Without: all scopes."""
    store = await _get_store()
    results = await store.search(query, project, mem_type=type, limit=limit)
    return json.dumps(results, default=str)


def main() -> None:
    mcp.run()


if __name__ == "__main__":
    main()
