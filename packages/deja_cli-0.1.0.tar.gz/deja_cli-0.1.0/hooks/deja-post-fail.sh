#!/usr/bin/env bash
# deja-post-fail.sh — post-tool-use hook for Claude Code
#
# Fires after each Bash tool call. If the command was high-signal AND failed
# (non-zero exit / is_error), searches deja for related gotchas and injects
# them so the agent debugs with past context immediately.
#
# Uses the same command allowlist as deja-recall.sh (pre-tool-use).
# Does NOT auto-save — agent-driven `deja save` calls remain the write path.
#
# INSTALL:
#   cp hooks/deja-post-fail.sh ~/.claude/hooks/deja-post-fail.sh
#   chmod +x ~/.claude/hooks/deja-post-fail.sh
#
# Then add to ~/.claude/settings.json (user-level, all projects) or
# .claude/settings.json (project-level):
#
#   {
#     "hooks": {
#       "PostToolUse": [
#         {
#           "matcher": "Bash",
#           "hooks": [{ "type": "command", "command": "~/.claude/hooks/deja-post-fail.sh" }]
#         }
#       ]
#     }
#   }
#
# Exit 0 (no output)   → no extra context
# Exit 0 (JSON output) → inject systemMessage with gotchas

set -euo pipefail

INPUT=$(cat)

TOOL_NAME=$(echo "$INPUT" | jq -r '.tool_name // ""')
CMD=$(echo "$INPUT"       | jq -r '.tool_input.command // ""')

# Only fire for Bash tool calls
[ "$TOOL_NAME" != "Bash" ] && exit 0

# ── Check for failure ─────────────────────────────────────────────────────────
EXIT_CODE=$(echo "$INPUT" | jq -r '.tool_result.exit_code // 0')
IS_ERROR=$(echo "$INPUT"  | jq -r '.tool_result.is_error // false')

# Skip if command succeeded
if [ "$EXIT_CODE" = "0" ] && [ "$IS_ERROR" = "false" ]; then
  exit 0
fi

# ── Classification allowlist ─────────────────────────────────────────────────
# Keep this list identical to deja-recall.sh so recall fires on the same
# commands before AND after (if they fail).

INTENT=""

if echo "$CMD" | grep -qE "kubectl apply|helm upgrade|kubectl rollout"; then
  INTENT="deploy kubernetes"
elif echo "$CMD" | grep -qE "alembic upgrade|alembic downgrade|flask db upgrade|python manage.py migrate"; then
  INTENT="database migration"
elif echo "$CMD" | grep -qE "terraform apply|terraform destroy|terraform import"; then
  INTENT="terraform infrastructure"
elif echo "$CMD" | grep -qE "git push.*(--force|-f)|git push.*(main|master)"; then
  INTENT="git push force main"
elif echo "$CMD" | grep -qE "aws.*deploy|aws.*update|aws.*delete|aws.*terminate"; then
  INTENT="aws deploy infrastructure"
elif echo "$CMD" | grep -qE "secret|credential|rotate|revoke|vault"; then
  INTENT="secret rotation credentials"
elif echo "$CMD" | grep -qE "docker.*push|docker.*deploy|docker.*prod"; then
  INTENT="docker deploy production"
elif echo "$CMD" | grep -qE "pg_dump|mysqldump|mongodump|pg_restore|mongorestore"; then
  INTENT="database backup restore"
elif echo "$CMD" | grep -qE "npm publish|pip publish|cargo publish|gem push"; then
  INTENT="publish package release"
fi

# Low-signal command — skip
[ -z "$INTENT" ] && exit 0

# ── Recall ────────────────────────────────────────────────────────────────────
MEMORIES=$(deja search "$INTENT" 2>/dev/null || true)

[ -z "$MEMORIES" ] && exit 0

# ── Inject context ────────────────────────────────────────────────────────────
jq -n --arg ctx "$MEMORIES" '{
  "systemMessage": ("[deja recall — command failed, related gotchas]\n" + $ctx)
}'
