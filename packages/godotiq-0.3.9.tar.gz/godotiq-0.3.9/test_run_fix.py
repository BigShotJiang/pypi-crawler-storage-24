import asyncio, json, websockets

async def test_run_fix():
    ws = await websockets.connect("ws://127.0.0.1:6007")

    # 1. Run
    await ws.send(json.dumps({"id": "r1", "method": "run", "params": {"action": "play", "scene": "main"}}))
    while True:
        raw = await asyncio.wait_for(ws.recv(), timeout=10)
        data = json.loads(raw)
        if "event" in data:
            print(f"  [event: {data['event']}]")
            continue
        if data.get("id") == "r1":
            print("RUN:", json.dumps(data.get("result", data.get("error", {}))))
            break

    await asyncio.sleep(3)

    # 2. State inspect — must work
    await ws.send(json.dumps({"id": "s1", "method": "state_inspect", "params": {
        "queries": [{"autoload": "GameManager", "properties": ["current_day"]}]
    }}))
    while True:
        raw = await asyncio.wait_for(ws.recv(), timeout=10)
        data = json.loads(raw)
        if "event" in data: continue
        if data.get("id") == "s1":
            print("STATE:", json.dumps(data.get("result", {}))[:200])
            break

    # 3. Stop
    await ws.send(json.dumps({"id": "x1", "method": "stop", "params": {}}))
    while True:
        raw = await asyncio.wait_for(ws.recv(), timeout=5)
        data = json.loads(raw)
        if "event" in data: continue
        if data.get("id") == "x1":
            print("STOP:", data.get("status"))
            break

    await ws.close()
    print("\nDone!")

asyncio.run(test_run_fix())
