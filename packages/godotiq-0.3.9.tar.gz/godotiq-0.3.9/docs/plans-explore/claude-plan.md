# Implementation Plan: godotiq_explore

## 1. Overview

### What We're Building

`godotiq_explore` is a PRO MCP tool for GodotIQ that autonomously inspects a running Godot game by flying a drone camera through calculated positions and capturing screenshots. It is the first GodotIQ tool that orchestrates multiple sequential WebSocket calls to achieve a complex multi-step operation.

### Why

AI agents using GodotIQ can build and modify 3D scenes, but have no systematic way to visually verify their work. An agent that builds a dungeon can't check if walls are correctly placed, lighting looks right, or objects are floating — without manually requesting dozens of individual screenshots at hand-picked coordinates.

`godotiq_explore` automates this: parse scene → cluster nodes into areas → calculate camera positions → fly drone through → capture screenshots → return structured report. One tool call replaces 10-30 manual operations.

### Architecture

Three layers plus a debugger relay:

1. **Python MCP Tool** (`src/godotiq/tools/bridge/explore.py`) — parses .tscn files for node positions, clusters them spatially, calculates camera positions, orchestrates WebSocket calls
2. **GDScript Server** (`godotiq_server.gd`) — dispatches `explore_camera` requests to the game via `_handle_game_forward()`
3. **GDScript Debugger** (`godotiq_debugger.gd`) — routes `explore_camera_result` messages from game back to server
4. **GDScript Runtime** (`godotiq_runtime.gd`) — creates/moves/destroys a Camera3D node in the running game

The tool reuses existing infrastructure: `bridge.request()` for WebSocket communication, `_build_scene_map()` for scene parsing, the game-forward IPC pattern used by screenshot/input, and the PRO gating system in `license.py`.

### Key Constraint: Serial Bridge Calls Only

The server matches responses to pending requests by method name, not request ID. This means only one pending request of each method type can exist at a time. The explore tool's sequential flow (move → screenshot → move → screenshot) is safe because it awaits each response before sending the next. The implementation MUST NOT attempt to pipeline or parallelize bridge calls.

### Descoped Features

- **`include_spatial_audit`**: The original spec included spatial_audit integration. This was descoped per interview — users call spatial_audit separately if needed.
- **`max_areas` default changed from 8 to 5**: Reduced from the original spec's default of 8 to keep token budget manageable (5 areas × 1 overview screenshot = 5 screenshots default). Agent can increase both parameters for more thorough inspection.

---

## 2. GDScript Changes

### 2.1 Server Dispatch Entry

In `godot-addon/addons/godotiq/godotiq_server.gd`, add a new case to the `_dispatch()` match statement. The match key is `"explore_camera"` (no prefix — matching the method name sent by the Python bridge). Call `_handle_game_forward()` with the prefixed message name `"godotiq:explore_camera"`:

```gdscript
"explore_camera":
    _handle_game_forward(peer_id, id, "godotiq:explore_camera", params, 10000)
```

The 10-second timeout provides margin for camera operations plus frame rendering.

### 2.2 Debugger Capture Case (CRITICAL)

In `godot-addon/addons/godotiq/godotiq_debugger.gd`, add a case to the `_capture()` function so that runtime responses are routed back to the server. Without this, all explore_camera calls would silently timeout:

```gdscript
"godotiq:explore_camera_result":
    server.handle_game_response("godotiq:explore_camera", data)
    return true
```

This follows the exact pattern used by `"godotiq:screenshot_result"` and `"godotiq:input_result"`.

### 2.3 Runtime Message Handler

In `godot-addon/addons/godotiq/godotiq_runtime.gd`, add a handler for `explore_camera` messages in `_on_debugger_message()`. The message name arriving at the runtime is `"explore_camera"` (the `"godotiq:"` prefix is stripped by the capture system — the runtime registers for the `"godotiq"` prefix on initialization).

The handler receives a params Dictionary with an `"action"` key. Three actions:

**Action: "create"**
- Get the game's scene tree root
- Clean up any existing `GodotIQ_DroneCam` first (idempotent re-creation)
- Find the current active Camera3D via `get_viewport().get_camera_3d()`
- Store its relative path as metadata on the drone (for restoration later)
- Create a new `Camera3D` node named `"GodotIQ_DroneCam"`
- Set its FOV from params (default 70.0)
- Add it as a child of the scene root
- Call `make_current()` on the drone
- Send response via `EngineDebugger.send_message("godotiq:explore_camera_result", [data])` with `{"status": "created", "original_camera": <path>}`

**Action: "move"**
- Find the `GodotIQ_DroneCam` node in the scene tree
- Set `global_position` from params `"position"` array `[x, y, z]`
- If params has `"look_at"`: compute direction and call `look_at()`
  - **Zero-length guard**: if position equals look_at target (distance < 0.001), skip the look_at call
  - **Parallel-vector guard**: if `direction.dot(Vector3.UP) > 0.99` (direction nearly parallel to UP), use `Vector3.FORWARD` as the up vector instead of `Vector3.UP`
- Else if params has `"rotation"`: set `rotation_degrees` directly
- Optionally update FOV if present in params
- Send response with actual position and rotation after move

**Action: "destroy"**
- Find the `GodotIQ_DroneCam` node
- Read the `"original_camera_path"` metadata
- **CRITICAL ORDER**: First restore original camera (`make_current()`), THEN `queue_free()` the drone. Reversing this causes a frame with no active camera.
- Validate stored reference with `is_instance_valid()` before restoring
- Send response with `{"status": "destroyed"}`

### 2.4 Error Cases

- If game/scene root is null → error response with code and message
- If drone not found during move/destroy → descriptive error
- If original camera was freed during exploration → skip restoration, just free drone

---

## 3. Python Bridge Tool

### 3.1 Module Structure

New file: `src/godotiq/tools/bridge/explore.py`

This module contains:
- `_cluster_nodes()` — pure function, spatial clustering
- `_calculate_camera_positions()` — pure function, geometry
- `_get_scene_layout()` — synchronous, calls internal `_build_scene_map()`
- `explore()` — main async function, orchestrates the full flow

**Two session concepts**: `GodotIQSession` (from `src/godotiq/session.py`) is for filesystem-level .tscn parsing. `BridgeConnection` (from `src/godotiq/bridge/connection.py`) is for WebSocket runtime communication. The explore tool needs BOTH: `GodotIQSession` for parsing scene data, and `BridgeConnection` for drone camera operations.

### 3.2 Tool Registration

In `src/godotiq/tools/bridge/__init__.py`, add the public wrapper:

```python
@mcp.tool(
    name="godotiq_explore",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
async def godotiq_explore(
    scene: str = "",
    mode: str = "tour",
    positions: list[dict] | None = None,
    max_areas: int = 5,
    screenshots_per_area: int = 1,
    scale: float = 0.5,
    quality: float = 0.6,
    fov: float = 70.0,
    eye_height: float = 2.5,
    ctx: Context = None,
) -> dict:
    """Autonomous visual inspection of the running game."""
```

Key notes:
- `idempotentHint: False` — concurrent calls would conflict (both try to create `GodotIQ_DroneCam`)
- `positions: list[dict] | None = None` — uses list type directly, matching existing tools (node_ops, input)
- No `detail` parameter — output is structured with base64 images; character-based truncation would corrupt data
- `ctx` is required to access `GodotIQSession` via `ctx.request_context.lifespan_context["session"]`

The wrapper follows the standard error-handling pattern (BridgeConnectionError, BridgeTimeoutError, BridgeError), calls the internal `explore()` function, and applies `gate_pro()` on the result.

### 3.3 Spatial Clustering

`_cluster_nodes(nodes, distance_threshold=15.0)` takes a list of node dicts (from scene_map output, each having `"position": [x, y, z]`) and returns clusters.

Algorithm: greedy single-pass clustering.
- For each unassigned node, start a new cluster
- Add any unassigned node within `distance_threshold` Euclidean distance of the cluster seed
- Calculate cluster center (centroid), bounds (min/max per axis), and node count
- Sort clusters by node_count descending (largest first)

This is O(n²) which is fine for <1000 nodes. No external dependencies needed.

**Known limitation:** The greedy approach clusters by distance from the first node (seed), not from the evolving centroid. A long chain of nodes each within threshold of the next but spanning a large total distance will merge into one cluster. For typical game scenes with distinct rooms/zones this is acceptable, but very open-world scenes with continuous geometry may produce overly large clusters.

### 3.4 Camera Position Calculation

`_calculate_camera_positions(cluster, eye_height=2.5)` returns exactly 5 positions per cluster:

1. **Overview** — positioned above and behind the cluster center, looking down at ~45°. Height = center_y + radius * 1.2. Offset along -Z by radius * 0.5.
2. **North** — at eye_height, offset -Z by radius, looking at center
3. **East** — at eye_height, offset +X by radius, looking at center
4. **South** — at eye_height, offset +Z by radius, looking at center
5. **West** — at eye_height, offset -X by radius, looking at center

Radius = max(half_width_x, half_width_z) + 3.0, minimum 5.0 units.

Each position is a dict: `{"position": [x,y,z], "look_at": [x,y,z], "direction": str}`

**Position limiting**: The `screenshots_per_area` parameter controls how many of the 5 positions are used per cluster. The positions list is sliced: `positions[:screenshots_per_area]`. With default `screenshots_per_area=1`, only the overview is captured. The agent can increase to 3 (overview + north + east) or 5 (all cardinals) when more detail is needed.

### 3.5 Scene Layout Retrieval

`_get_scene_layout(session, scene_path)` gets node positions. This is a **synchronous** function (not async) because `_build_scene_map()` is synchronous — it reads .tscn files from the filesystem.

- The `GodotIQSession` is obtained from `ctx.request_context.lifespan_context["session"]` in the wrapper
- Scene path resolution fallback chain:
  1. Use explicit `scene_path` parameter if provided
  2. Query bridge for currently open scene in editor
  3. Query game process for currently running scene
  4. Return error if none found
- Import and call `_build_scene_map(session, resolved_path)` from the spatial tools module
- Return the scene_map result with nodes containing world positions

### 3.6 Tour Mode Flow

```
1. Get GodotIQSession from ctx
2. Resolve scene path (use provided or query editor for current scene)
3. _get_scene_layout(session, scene) → nodes with positions (sync, filesystem)
4. _cluster_nodes(nodes) → clusters
5. Limit to max_areas clusters
6. For each cluster: _calculate_camera_positions(cluster, eye_height)
7. Slice positions per cluster to screenshots_per_area
8. Check if total positions > 25 → set warning flag
9. PRO gate: if Community user, return preview with cluster analysis (no screenshots)
10. bridge = await get_bridge()
11. await bridge.request("explore_camera", {action: "create", fov})
12. For each position (sequential, never parallel):
    a. await bridge.request("explore_camera", {action: "move", position, look_at})
    b. await asyncio.sleep(0.1) — belt-and-suspenders; real safety is the runtime's process_frame await
    c. await bridge.request("screenshot", {viewport: "game", scale, quality, format: "webp"})
    d. Append to screenshots list (skip on error, continue to next)
13. await bridge.request("explore_camera", {action: "destroy"}) — in try/finally block
14. Return structured result
```

Note: screenshot calls explicitly pass `format: "webp"` for smallest response size.

### 3.7 Inspect Mode Flow

```
1. Validate positions list is not None/empty
2. bridge = await get_bridge()
3. await bridge.request("explore_camera", {action: "create", fov})
4. For each position (sequential):
   a. await bridge.request("explore_camera", {action: "move", ...})
   b. await asyncio.sleep(0.1)
   c. await bridge.request("screenshot", {viewport: "game", scale, quality, format: "webp"})
   d. Append to screenshots list (skip on error)
5. await bridge.request("explore_camera", {action: "destroy"}) — in try/finally block
6. Return structured result
```

### 3.8 Graceful Degradation (Game Not Running)

If the bridge connection fails (BridgeConnectionError) during the create step:
- Return the clustering analysis without screenshots
- Include areas_inspected, total positions calculated, node counts
- Add `"game_running": false` to indicate no screenshots were captured
- This enables planning use cases where the agent wants to understand scene layout

### 3.9 Output Warning

If total calculated screenshot positions exceeds 25:
- Add `"warning": "25+ screenshots requested (N total); consider reducing max_areas or screenshots_per_area for faster results"` to the response
- Do NOT cap — honor the caller's parameters

---

## 4. PRO Gating

### 4.1 Add to PRO_TOOLS

In `src/godotiq/license.py`, add `"godotiq_explore"` to the `PRO_TOOLS` frozenset.

### 4.2 Preview Builder

Define the preview builder function AND register it in the `_PREVIEW_BUILDERS` dictionary:

```python
def _preview_explore(r: dict) -> tuple[dict, list[str], str]:
    """Preview for Community users."""
```

Preview dict: `{"areas_found": r["areas_inspected"], "positions_calculated": r["total_screenshots"], "total_nodes": r["total_nodes"]}`
Locked sections: `["screenshots", "visual inspection data"]`
Message: `f"Found {areas} areas with {nodes} nodes. Visual inspection requires Pro."`

**Registration**: Add `"godotiq_explore": _preview_explore` to the `_PREVIEW_BUILDERS` dict. Without this, Community users get the generic fallback instead of the rich preview.

### 4.3 Gating Location

The `gate_pro()` call happens in the public wrapper in `__init__.py`, AFTER the explore function returns results. For Community users doing tour mode, the clustering analysis runs fully (demonstrating value), then gets wrapped in the preview response.

---

## 5. Protocol Registration

In `src/godotiq/bridge/protocol.py`, add `"explore_camera"` to `TOOL_TIMEOUTS` with a 10-second timeout. Each individual explore_camera call (create/move/destroy) is fast, but we want enough margin for the game to process.

---

## 6. Prompt Update

In `src/godotiq/prompts/godot_development.md`, add two sections:

### 6.1 Mandatory Workflow

After the "After ANY 3D changes" workflow section, add "After building or modifying a scene (VISUAL QA)" workflow:
- Call `godotiq_explore(mode="tour")`
- Analyze each screenshot (describe what you see, note issues)
- If issues found, fix with node_ops/build_scene/exec
- Call explore again to verify

Also add the inspect mode example for close-up inspection of specific areas.

### 6.2 Tool Description

Add a description of `godotiq_explore` to the tool descriptions section, covering:
- What it does (drone camera, automated inspection)
- Two modes (tour/inspect)
- When to use it (after building, after fixing)
- What to look for in screenshots (lighting, geometry, fog, decoration, general impression)

---

## 7. Version Bump

- Bump to `0.3.0` in `pyproject.toml` (new feature = minor version)
- Run version sync script to update `plugin.cfg` and `godotiq_server.gd`
- Rebuild wheel (do NOT upload to PyPI)

---

## 8. Test Strategy

### 8.1 Pure Function Tests (No Mocking)

Test `_cluster_nodes()`:
- Empty input → empty result
- Single node → single cluster
- Two close nodes → one cluster
- Two distant groups → two clusters
- Nodes without position data → filtered out
- Cluster centers calculated correctly
- Clusters sorted by size descending

Test `_calculate_camera_positions()`:
- Returns 5 positions (1 overview + 4 cardinal)
- Overview position is above cluster center
- Cardinal positions are at specified eye_height
- Custom eye_height is respected
- Radius scales with cluster bounds

### 8.2 Integration Tests (Mock Bridge)

Test full explore flow:
- Mock `get_bridge()` to return AsyncMock
- Mock `bridge.request()` with `side_effect` for sequential calls (create → move → screenshot → ... → destroy)
- Verify correct sequence of bridge calls
- Verify result structure (areas_inspected, screenshots, etc.)

Test error scenarios:
- Create fails → return error immediately
- One move fails → skip position, continue to next
- Screenshot fails → skip, continue
- Verify destroy always called (try/finally)

### 8.3 PRO Gating Tests

- Verify `"godotiq_explore"` is in PRO_TOOLS
- Verify Community preview shows areas_found and positions_calculated
- Verify PRO users get full result with screenshots
- Verify `"godotiq_explore"` is in `_PREVIEW_BUILDERS` dict

### 8.4 GDScript Tests

Not directly testable in pytest. The GDScript handlers are tested manually via the running game. The Python tests mock the bridge layer, which validates the Python-side logic.

---

## 9. File Change Summary

| File | Action | Description |
|------|--------|-------------|
| `src/godotiq/tools/bridge/explore.py` | **Create** | Python implementation with clustering, camera calc, explore orchestration |
| `src/godotiq/tools/bridge/__init__.py` | **Modify** | Add godotiq_explore wrapper with error handling and PRO gating |
| `godot-addon/addons/godotiq/godotiq_server.gd` | **Modify** | Add explore_camera to _dispatch() match, forward to runtime |
| `godot-addon/addons/godotiq/godotiq_debugger.gd` | **Modify** | Add explore_camera_result case to _capture() for response routing |
| `godot-addon/addons/godotiq/godotiq_runtime.gd` | **Modify** | Add explore_camera handler (create/move/destroy actions) |
| `src/godotiq/bridge/protocol.py` | **Modify** | Add explore_camera timeout |
| `src/godotiq/license.py` | **Modify** | Add to PRO_TOOLS, add preview builder + register in _PREVIEW_BUILDERS |
| `src/godotiq/prompts/godot_development.md` | **Modify** | Add explore workflow and tool description |
| `tests/test_tools/test_explore.py` | **Create** | Pure function tests + mocked integration tests + PRO gating tests |
| `pyproject.toml` | **Modify** | Version bump to 0.3.0 |

---

## 10. Implementation Order

The sections should be implemented in this order due to dependencies:

1. **GDScript handlers** (server dispatch + debugger capture + runtime handler) — the foundation
2. **Protocol registration** — enables Python to call the new method
3. **Tests: pure functions** (clustering + camera position calculation) — TDD, write tests first
4. **Python explore module** (clustering + camera calc + orchestration) — implement to pass tests
5. **Tests: integration** (mock bridge) — verify full explore flow
6. **Bridge wrapper + PRO gating** — __init__.py wrapper + license.py changes
7. **Tests: PRO gating** — verify gating behavior
8. **Prompt update** — documentation for AI agents
9. **Version bump + sync** — release prep
