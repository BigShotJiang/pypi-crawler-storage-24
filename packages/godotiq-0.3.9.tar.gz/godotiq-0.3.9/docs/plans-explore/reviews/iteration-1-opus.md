# Opus Review

**Model:** claude-opus-4
**Generated:** 2026-03-18T14:30:00Z

---

## Critical Issues

### 1. Response matching constraint
The server's `handle_game_response()` matches by method name, not request ID. Sequential explore_camera and screenshot calls work because only one pending request per type at a time. Plan should document this serial-only constraint.

### 2. Missing `godotiq_debugger.gd` file
Every game-side message type must be registered in `_capture()` in `godotiq_debugger.gd`. Without adding a case for `"godotiq:explore_camera_result"`, runtime responses will be silently dropped and every explore_camera call will timeout. This file is completely missing from the plan.

### 3. Response message naming convention not established
Runtime must send `"godotiq:explore_camera_result"` and debugger must map it to `"godotiq:explore_camera"`. Plan's Section 2.3 leaves this implicit.

### 4. Dispatch key clarification needed
Match key is `"explore_camera"` (no prefix), the message forwarded is `"godotiq:explore_camera"`.

## Architectural Concerns

### 5. Runtime message handler boilerplate
Plan should be explicit about the message name to match against in the runtime.

### 6. Two different session concepts conflated
`GodotIQSession` (filesystem parsing) vs `BridgeConnection` (WebSocket). Plan needs to clearly explain how `explore.py` gets the `GodotIQSession` — via `ctx.request_context.lifespan_context["session"]`.

### 7. `_build_scene_map` is synchronous
Plan describes `_get_scene_layout` as async but `_build_scene_map` is synchronous.

### 8. `screenshots_per_area` limiting not described
Plan never describes how `screenshots_per_area` limits positions.

## Edge Cases

### 9. Parallel-vector guard incomplete
Also guard against `position == look_at` (zero-length direction).

### 10. Clustering chaining limitation
Greedy single-pass clusters by distance from first node, not centroid. Long chains can produce spread-out clusters.

### 11. `asyncio.sleep(0.1)` safety
Safety actually comes from screenshot handler's `await get_tree().process_frame`, not from the sleep.

### 12. queue_free ordering emphasis
Critical: restore original camera BEFORE queue_free on drone.

### 13. Drone camera in-game visibility
Camera3D nodes are inherently invisible. Real concern is whether game logic iterates cameras.

### 14. `positions` parameter should be `list[dict] | None`
Existing tools (node_ops, input) already use `list[dict]` parameters. JSON string is unnecessary.

## Missing Considerations

### 15. Token budget for large explorations
25 screenshots at 50-200KB each = 1.25-5MB base64.

### 16. No aggregate timeout
Overall explore with 25 positions could take 30+ seconds.

### 17. Concurrent explore calls conflict
Two simultaneous explores would destroy each other's cameras. `idempotentHint` should be `False`.

### 18. No `apply_output_limit` usage
Plan includes `detail` parameter but never describes its effect.

### 19. 2D scene validation
Should check for spatially distributed 3D nodes.

### 20. Explicit screenshot format
Should pass `format: "webp"` explicitly.

### 21. Tests should come earlier (TDD)
Pure function tests need no mocking.

### 22. `_PREVIEW_BUILDERS` dictionary not mentioned
Must register `"godotiq_explore": _preview_explore` in the dict.

### 23. `max_areas` default disagrees with spec
Spec says 8, plan says 5. Should note the deliberate change.

### 24. `include_spatial_audit` descoped but not documented
Plan drops it without mentioning the descoping.
