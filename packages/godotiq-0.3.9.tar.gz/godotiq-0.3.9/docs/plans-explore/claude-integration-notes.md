# Integration Notes: Opus Review Feedback

## Integrating (Must Fix)

### 1. Missing `godotiq_debugger.gd` (Critical #2)
**Integrating.** This is a real showstopper — without the capture case in `godotiq_debugger.gd`, all explore_camera calls would silently timeout. Adding this file to the plan with the exact message routing needed.

### 2. Response message naming convention (#3)
**Integrating.** Making explicit that runtime sends `"godotiq:explore_camera_result"` and debugger maps it to `"godotiq:explore_camera"`.

### 3. `positions` as `list[dict] | None` instead of JSON string (#14)
**Integrating.** The reviewer is correct — existing tools like node_ops and input already use `list[dict]` parameters. No reason to use a JSON string.

### 4. `_PREVIEW_BUILDERS` dictionary registration (#22)
**Integrating.** Must register the preview builder in the dict, not just define the function.

### 5. `idempotentHint: False` (#17)
**Integrating.** The tool is not idempotent — concurrent calls would conflict.

### 6. Context for session access and sync `_build_scene_map` (#6, #7)
**Integrating.** Clarifying that `explore()` needs `ctx` to get `GodotIQSession`, and that `_build_scene_map` is synchronous.

### 7. `screenshots_per_area` limiting (#8)
**Integrating.** Adding explicit description of how positions are sliced by this parameter.

### 8. Guard for `position == look_at` (#9)
**Integrating.** Adding zero-length direction guard alongside the parallel-vector guard.

### 9. Explicit `format: "webp"` (#20)
**Integrating.** Adding explicit format parameter to screenshot calls.

### 10. Serial-only constraint documentation (#1)
**Integrating.** Documenting that bridge calls must be sequential, not pipelined.

## Integrating (Should Fix)

### 11. Note descoped `include_spatial_audit` (#24)
**Integrating.** Adding explicit note about descoping.

### 12. Note `max_areas` default change from spec (#23)
**Integrating.** Documenting the change from 8 to 5 with rationale.

### 13. Dispatch key clarification (#4)
**Integrating.** Making explicit that match key is `"explore_camera"` (no prefix).

## NOT Integrating

### Aggregate timeout (#16)
**Not integrating.** Individual bridge calls already have timeouts. The MCP transport layer handles overall request timeout. Adding an aggregate timeout inside the tool would add complexity without clear benefit — if a call hangs, the per-call timeout will fire.

### Hard cap on screenshots (#15)
**Not integrating.** The user explicitly chose "warn but don't cap" in the interview. The warning at 25+ is sufficient.

### `apply_output_limit` (#18)
**Not integrating.** The explore tool returns structured data with base64 images. Output limiting by character count would corrupt the image data. The `detail` parameter will be removed from the signature since it doesn't apply meaningfully to this tool.

### 2D scene validation (#19)
**Not integrating as a separate validation step.** The existing `_build_scene_map` returns nodes with positions — if they're all at origin, the clustering will produce one cluster and the screenshots will show what's there. This is acceptable behavior.

### Tests earlier in implementation order (#21)
**Not integrating into the plan ordering.** The TDD plan (step 16) handles test-first approach. Implementation order in the plan is about dependencies, not execution sequence.

### Runtime boilerplate refactoring (#5)
**Not integrating.** Out of scope — we follow the existing pattern as-is.

### Clustering chaining limitation (#10)
**Integrating as a note.** Adding a brief caveat about the limitation.

### `asyncio.sleep` explanation (#11)
**Integrating.** Adding note that the real safety comes from the screenshot handler's `process_frame` await.

### Camera visibility in game logic (#13)
**Not integrating.** This is a theoretical concern. The drone is named `GodotIQ_DroneCam` which makes it identifiable if game code iterates cameras, but this is an unlikely edge case that doesn't warrant plan changes.
