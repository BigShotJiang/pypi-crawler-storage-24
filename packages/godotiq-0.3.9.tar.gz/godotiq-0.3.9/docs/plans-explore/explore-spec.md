# Task: Implement godotiq_explore — Autonomous Visual Inspection Tool

## Context

GodotIQ's exec tool does NOT support await. Any GDScript with `await` causes timeout.
This means: every exec call must return synchronously. The Python MCP tool orchestrates
multiple sequential WebSocket calls to achieve the full exploration loop.

Between each WebSocket round-trip there's ~100-400ms latency — more than enough for
Godot to render a frame. So we don't need explicit frame waits.

## What godotiq_explore Does

It's a drone camera that flies through the running game, takes screenshots from
calculated positions, and returns a structured visual inspection report.

The AI agent calls ONE tool: `godotiq_explore(scene, mode, options)`.
Internally, the Python tool makes 10-30 WebSocket calls to execute the full loop.
The agent receives back: array of screenshots with positions and annotations.

## Architecture Overview

```
AI Agent
  │ calls godotiq_explore(scene="dungeon.tscn", mode="tour")
  ▼
Python MCP Tool (src/godotiq/tools/bridge/explore.py)
  │ 1. Reads scene_map to get node positions (filesystem, no addon needed)
  │ 2. Clusters nodes into "areas" (rooms/zones)
  │ 3. Calculates camera positions for each area
  │ 4. Sends sequential WebSocket commands:
  │    a. exec → create drone camera, store original camera ref
  │    b. exec → position drone at Area1 center, look at interest point
  │    c. screenshot → capture
  │    d. exec → position drone at Area1, rotate 90°
  │    e. screenshot → capture
  │    f. ... repeat for all positions ...
  │    g. exec → restore original camera, cleanup drone
  │ 5. Packages all screenshots with metadata
  │ 6. Returns structured result to agent
  ▼
AI Agent receives:
{
  "areas_inspected": 5,
  "screenshots": [
    {
      "area": "Room1",
      "position": [5, 3, 5],
      "look_at": [5, 0, 5],
      "direction": "overview",
      "image": "<base64>",
      "nearby_nodes": ["Torch1", "Barrel3", "Wall_N_0"]
    },
    ...
  ],
  "spatial_issues": [...],  // from spatial_audit if available
  "total_nodes": 729,
  "inspection_time_ms": 4500
}
```

## Part 1: GDScript Addon Changes

### File: godot-addon/addons/godotiq/godotiq_server.gd

Add a new handler `_handle_explore_camera` that handles three operations.
Do NOT modify any existing handlers.

```gdscript
# Add to the match statement in _process_request():
"explore_camera":
    _handle_explore_camera(request_id, params)
```

```gdscript
func _handle_explore_camera(request_id: String, params: Dictionary) -> void:
    var action: String = params.get("action", "")

    match action:
        "create":
            # Create a drone Camera3D, make it current, store the original
            var game_root = _get_game_root()
            if not game_root:
                _send_error(request_id, "Game not running")
                return

            # Clean up any existing drone camera first
            var existing = game_root.get_node_or_null("GodotIQ_DroneCam")
            if existing:
                var prev_cam_path = existing.get_meta("original_camera_path", "")
                if prev_cam_path != "":
                    var prev_cam = game_root.get_node_or_null(prev_cam_path)
                    if prev_cam and prev_cam is Camera3D:
                        prev_cam.make_current()
                existing.queue_free()

            # Store reference to current camera before switching
            var original_cam = game_root.get_viewport().get_camera_3d()
            var original_cam_path = ""
            if original_cam:
                original_cam_path = str(game_root.get_path_to(original_cam))

            # Create drone
            var drone = Camera3D.new()
            drone.name = "GodotIQ_DroneCam"
            drone.set_meta("original_camera_path", original_cam_path)
            drone.fov = params.get("fov", 70.0)
            game_root.add_child(drone)
            drone.make_current()

            _send_response(request_id, {
                "status": "created",
                "original_camera": original_cam_path,
            })

        "move":
            # Reposition the drone camera
            var game_root = _get_game_root()
            if not game_root:
                _send_error(request_id, "Game not running")
                return

            var drone = game_root.get_node_or_null("GodotIQ_DroneCam")
            if not drone:
                _send_error(request_id, "Drone camera not found. Call create first.")
                return

            var pos = params.get("position", [0, 0, 0])
            drone.global_position = Vector3(pos[0], pos[1], pos[2])

            if params.has("look_at"):
                var target = params.get("look_at")
                drone.look_at(Vector3(target[0], target[1], target[2]), Vector3.UP)
            elif params.has("rotation"):
                var rot = params.get("rotation")
                drone.rotation_degrees = Vector3(rot[0], rot[1], rot[2])

            if params.has("fov"):
                drone.fov = params.get("fov")

            _send_response(request_id, {
                "status": "moved",
                "position": [drone.global_position.x, drone.global_position.y, drone.global_position.z],
                "rotation": [drone.rotation_degrees.x, drone.rotation_degrees.y, drone.rotation_degrees.z],
            })

        "destroy":
            # Restore original camera and clean up drone
            var game_root = _get_game_root()
            if not game_root:
                _send_error(request_id, "Game not running")
                return

            var drone = game_root.get_node_or_null("GodotIQ_DroneCam")
            if drone:
                var original_path = drone.get_meta("original_camera_path", "")
                if original_path != "":
                    var original_cam = game_root.get_node_or_null(original_path)
                    if original_cam and original_cam is Camera3D:
                        original_cam.make_current()
                drone.queue_free()

            _send_response(request_id, {"status": "destroyed"})

        _:
            _send_error(request_id, "Unknown explore_camera action: " + action)
```

IMPORTANT: `_get_game_root()`, `_send_response()`, and `_send_error()` are existing
helper functions in godotiq_server.gd. Read the file first to find the exact names
and signatures — they may be named slightly differently. Adapt the code to match.

### File: godot-addon/addons/godotiq/godotiq_runtime.gd

The runtime autoload needs to handle `explore_camera` messages from the debugger.
Check how existing handlers (like `screenshot`, `input`) are dispatched from the
debugger to the runtime. Add the `explore_camera` handler following the same pattern.

The runtime runs in the GAME process. It needs to:
- Create/destroy Camera3D nodes in the game scene tree
- Reposition cameras
- The screenshot capture already works via the existing screenshot handler

Check if the explore_camera handler should live in the server (editor-side) or
runtime (game-side). Since we need to modify the GAME's camera, it likely needs
to be in the runtime, dispatched via EditorDebugger IPC.

Study how `_handle_screenshot` and `_handle_input` work to understand the
editor↔game communication pattern, then implement explore_camera the same way.

## Part 2: Python MCP Tool

### New file: src/godotiq/tools/bridge/explore.py

```python
"""
godotiq_explore — Autonomous visual inspection of running Godot games.

Creates a drone camera, flies it through the scene, captures screenshots
from calculated positions, and returns a structured visual report.
"""

import asyncio
import time
import math
from typing import Any

# Import the registration and bridge utilities
# Study how other bridge tools (screenshot, input, run) are structured
# and follow the same pattern for imports and registration.


# === SPATIAL CLUSTERING ===

def _cluster_nodes(nodes: list[dict], distance_threshold: float = 15.0) -> list[dict]:
    """
    Group nodes into spatial clusters (rooms/areas) using simple
    distance-based clustering.

    Each node dict must have "world_position" or "position" key.
    Returns list of clusters: {"center": [x,y,z], "nodes": [...], "bounds": {...}}
    """
    if not nodes:
        return []

    # Extract positions
    positioned = []
    for n in nodes:
        pos = n.get("world_position") or n.get("position")
        if pos and isinstance(pos, (list, tuple)) and len(pos) >= 3:
            positioned.append({"node": n, "pos": pos})

    if not positioned:
        return []

    # Simple greedy clustering
    clusters = []
    used = set()

    for i, item in enumerate(positioned):
        if i in used:
            continue
        cluster_nodes = [item]
        used.add(i)

        for j, other in enumerate(positioned):
            if j in used:
                continue
            dist = math.sqrt(
                (item["pos"][0] - other["pos"][0]) ** 2 +
                (item["pos"][1] - other["pos"][1]) ** 2 +
                (item["pos"][2] - other["pos"][2]) ** 2
            )
            if dist < distance_threshold:
                cluster_nodes.append(other)
                used.add(j)

        # Calculate cluster center
        cx = sum(n["pos"][0] for n in cluster_nodes) / len(cluster_nodes)
        cy = sum(n["pos"][1] for n in cluster_nodes) / len(cluster_nodes)
        cz = sum(n["pos"][2] for n in cluster_nodes) / len(cluster_nodes)

        # Calculate bounds
        min_x = min(n["pos"][0] for n in cluster_nodes)
        max_x = max(n["pos"][0] for n in cluster_nodes)
        min_z = min(n["pos"][2] for n in cluster_nodes)
        max_z = max(n["pos"][2] for n in cluster_nodes)

        clusters.append({
            "center": [cx, cy, cz],
            "node_count": len(cluster_nodes),
            "bounds": {
                "min": [min_x, min(n["pos"][1] for n in cluster_nodes), min_z],
                "max": [max_x, max(n["pos"][1] for n in cluster_nodes), max_z],
            },
            "nodes": [n["node"] for n in cluster_nodes],
        })

    # Sort clusters by size (largest first)
    clusters.sort(key=lambda c: c["node_count"], reverse=True)
    return clusters


def _calculate_camera_positions(cluster: dict, eye_height: float = 2.5) -> list[dict]:
    """
    Calculate camera positions for inspecting a cluster.

    Returns list of {"position": [x,y,z], "look_at": [x,y,z], "direction": str}

    Positions:
    1. Overview — above center, looking down at 45°
    2-5. Cardinal directions — at eye height, looking toward center
    """
    cx, cy, cz = cluster["center"]
    bounds = cluster["bounds"]

    # Calculate radius based on cluster size
    dx = bounds["max"][0] - bounds["min"][0]
    dz = bounds["max"][2] - bounds["min"][2]
    radius = max(dx, dz) / 2 + 3.0  # offset from edges
    radius = max(radius, 5.0)  # minimum distance

    positions = []

    # 1. Overview — bird's eye, angled
    positions.append({
        "position": [cx, cy + radius * 1.2, cz - radius * 0.5],
        "look_at": [cx, cy, cz],
        "direction": "overview",
    })

    # 2-5. Cardinal directions at eye height
    for label, offset_x, offset_z in [
        ("north", 0, -radius),
        ("east", radius, 0),
        ("south", 0, radius),
        ("west", -radius, 0),
    ]:
        positions.append({
            "position": [cx + offset_x, cy + eye_height, cz + offset_z],
            "look_at": [cx, cy + eye_height * 0.5, cz],
            "direction": label,
        })

    return positions


# === MAIN TOOL ===

# Register as an MCP tool following the same pattern as other bridge tools.
# Study src/godotiq/tools/bridge/__init__.py to understand how tools are registered.
#
# Tool signature:
#   godotiq_explore(
#       scene: str = "",           # .tscn file to read for node positions (optional, uses open scene)
#       mode: str = "tour",        # "tour" = visit all areas, "inspect" = specific position
#       positions: list = None,    # for mode="inspect": explicit positions to visit
#       max_areas: int = 8,        # max clusters to visit in tour mode
#       screenshots_per_area: int = 5,  # 1=overview only, 5=overview+4 cardinals
#       scale: float = 0.5,        # screenshot scale (0.25-1.0)
#       quality: float = 0.6,      # screenshot quality (0.1-1.0)
#       fov: float = 70.0,         # camera field of view
#       eye_height: float = 2.5,   # camera height for cardinal views
#       include_spatial_audit: bool = True,  # run spatial_audit alongside
#   )
#
# Returns:
#   {
#       "areas_inspected": int,
#       "total_screenshots": int,
#       "screenshots": [
#           {
#               "area_index": 0,
#               "area_center": [x, y, z],
#               "area_node_count": 47,
#               "position": [x, y, z],
#               "look_at": [x, y, z],
#               "direction": "overview",
#               "image": "<base64 webp>",
#           },
#           ...
#       ],
#       "spatial_issues": [...] or null,
#       "total_nodes": int,
#       "inspection_time_ms": int,
#   }


async def _explore_tour(session, scene, max_areas, screenshots_per_area, scale,
                         quality, fov, eye_height, include_spatial_audit):
    """Execute a full tour of the scene."""
    start_time = time.time()

    # Step 1: Get scene layout from scene_map (filesystem, no game needed)
    scene_data = await _get_scene_layout(session, scene)
    nodes = scene_data.get("nodes", [])
    total_nodes = len(nodes)

    if total_nodes == 0:
        return {
            "error": "No nodes with positions found in scene",
            "hint": "Make sure the scene has 3D nodes with transforms",
        }

    # Step 2: Cluster nodes into areas
    clusters = _cluster_nodes(nodes)
    clusters = clusters[:max_areas]

    if not clusters:
        return {"error": "Could not cluster nodes into areas"}

    # Step 3: Calculate all camera positions
    all_positions = []
    for i, cluster in enumerate(clusters):
        positions = _calculate_camera_positions(cluster, eye_height)
        if screenshots_per_area == 1:
            positions = positions[:1]
        else:
            positions = positions[:screenshots_per_area]
        for pos in positions:
            pos["area_index"] = i
            pos["area_center"] = cluster["center"]
            pos["area_node_count"] = cluster["node_count"]
        all_positions.extend(positions)

    # Step 4: Create drone camera (game must be running)
    create_result = await session.bridge_call("explore_camera", {
        "action": "create",
        "fov": fov,
    })
    if "error" in create_result:
        return create_result

    # Step 5: Visit each position and capture
    screenshots = []
    try:
        for pos_info in all_positions:
            move_result = await session.bridge_call("explore_camera", {
                "action": "move",
                "position": pos_info["position"],
                "look_at": pos_info["look_at"],
            })
            if "error" in move_result:
                continue

            await asyncio.sleep(0.1)

            screenshot_result = await session.bridge_call("screenshot", {
                "viewport": "game",
                "scale": scale,
                "quality": quality,
            })
            if "error" in screenshot_result:
                continue

            screenshots.append({
                "area_index": pos_info["area_index"],
                "area_center": pos_info["area_center"],
                "area_node_count": pos_info["area_node_count"],
                "position": pos_info["position"],
                "look_at": pos_info["look_at"],
                "direction": pos_info["direction"],
                "image": screenshot_result.get("image", ""),
            })
    finally:
        await session.bridge_call("explore_camera", {"action": "destroy"})

    # Step 7: Optionally run spatial_audit
    spatial_issues = None
    if include_spatial_audit:
        try:
            audit_result = await _get_spatial_audit(session, scene)
            spatial_issues = audit_result.get("issues", [])
        except Exception:
            pass

    elapsed = int((time.time() - start_time) * 1000)

    return {
        "areas_inspected": len(clusters),
        "total_screenshots": len(screenshots),
        "screenshots": screenshots,
        "spatial_issues": spatial_issues,
        "total_nodes": total_nodes,
        "inspection_time_ms": elapsed,
    }


async def _explore_inspect(session, positions, scale, quality, fov):
    """Visit explicit positions and capture screenshots."""
    start_time = time.time()

    create_result = await session.bridge_call("explore_camera", {
        "action": "create",
        "fov": fov,
    })
    if "error" in create_result:
        return create_result

    screenshots = []
    try:
        for i, pos in enumerate(positions):
            position = pos.get("position", [0, 0, 0])
            look_at = pos.get("look_at", [0, 0, 0])
            direction = pos.get("direction", f"position_{i}")

            move_result = await session.bridge_call("explore_camera", {
                "action": "move",
                "position": position,
                "look_at": look_at,
                "fov": pos.get("fov", fov),
            })
            if "error" in move_result:
                continue

            await asyncio.sleep(0.1)

            screenshot_result = await session.bridge_call("screenshot", {
                "viewport": "game",
                "scale": scale,
                "quality": quality,
            })
            if "error" in screenshot_result:
                continue

            screenshots.append({
                "position": position,
                "look_at": look_at,
                "direction": direction,
                "image": screenshot_result.get("image", ""),
            })
    finally:
        await session.bridge_call("explore_camera", {"action": "destroy"})

    elapsed = int((time.time() - start_time) * 1000)

    return {
        "total_screenshots": len(screenshots),
        "screenshots": screenshots,
        "inspection_time_ms": elapsed,
    }
```

### IMPORTANT IMPLEMENTATION NOTES

1. **Study the existing bridge tools first.** Before writing any code, read:
   - `src/godotiq/tools/bridge/__init__.py` — how tools are registered
   - Any existing bridge tool (screenshot, input, run) — how they call the WebSocket
   - `src/godotiq/session.py` — how `bridge_call` or equivalent works
   - `godot-addon/addons/godotiq/godotiq_server.gd` — how handlers dispatch
   - `godot-addon/addons/godotiq/godotiq_runtime.gd` — how game-side handlers work

2. **The explore_camera handler might need to be in the runtime (game-side)**
   rather than the server (editor-side), because we're modifying the GAME's
   camera. Follow the same pattern as screenshot and input handlers.

3. **The screenshot tool already captures from the game viewport.** When the
   drone camera is make_current(), the existing screenshot handler will
   naturally capture from the drone's perspective.

4. **`session.bridge_call` is a placeholder name.** Find the actual method used.

5. **The scene_map call needs to use saved scene data.** Call save_scene first
   if needed, or read from the .tscn file directly using the existing parser.

6. **Token budget:** Default max_areas=5, screenshots_per_area=3 = 15 screenshots max.

7. **Error handling:** Never abort the entire exploration because one position
   failed. Skip failed positions, continue to the next. Always clean up the
   drone camera in a try/finally.

8. **This is a PRO tool.** Add it to PRO_TOOLS in license.py with rich preview.

## Part 3: MCP Prompt Update

### File: src/godotiq/prompts/godot_development.md

Add to the Mandatory Workflows section and tool descriptions section as specified.

## Part 4: Tests

### New file: tests/test_tools/test_explore.py

Write tests for clustering, camera positions, full explore tool (mocked), PRO gate, and Community teaser.

## Part 5: Version and Release

After implementation:
1. Run ALL tests
2. Add to PRO_TOOLS in license.py
3. Bump version to 0.3.0
4. Run sync script, rebuild wheel
5. Do NOT upload to PyPI

## Verification Checklist

- [ ] godotiq_explore registered as MCP tool
- [ ] Game running + call explore → returns screenshots from multiple positions
- [ ] Drone camera is invisible (not visible in game to the player)
- [ ] Original camera restored after explore finishes
- [ ] Drone camera cleaned up even if errors occur
- [ ] mode="tour" automatically finds areas and visits them
- [ ] mode="inspect" visits explicit positions
- [ ] Community users get rich preview teaser
- [ ] All existing 1251 tests still pass
- [ ] New tests pass
- [ ] Prompt updated with explore workflow
- [ ] No changes to existing tool behavior
