# Interview Transcript: godotiq_explore

## Round 1

### Q1: IPC Pattern for explore_camera
**Question:** The spec shows explore_camera as a new method in the dispatch table. Research shows game-side operations (screenshot, input) use _handle_game_forward() to relay through EditorDebugger to the runtime. Should explore_camera also be game-forwarded to the runtime, or should it use the exec handler to run GDScript that creates/moves cameras?

**Answer:** Game-forward to runtime (Recommended) — Add explore_camera as a new message type in _handle_game_forward, with a handler in godotiq_runtime.gd. Same pattern as screenshot/input.

### Q2: Scene Data Source
**Question:** For the scene_map integration: the spec says to read node positions from .tscn files. Research shows _build_scene_map() uses GodotIQSession to parse .tscn files with world transforms. Should explore reuse this internal function, or should it call the public godotiq_scene_map MCP tool?

**Answer:** Reuse internal _build_scene_map() — Import and call the internal function directly. Avoids the overhead of going through MCP tool registration and PRO gating.

### Q3: Output Size Limits
**Question:** The spec mentions default max_areas=5 and screenshots_per_area=3 for token budget. Are there any other constraints on the output size?

**Answer:** Warn but don't cap — If calculated positions exceed 25, add a warning to the response but still capture all.

## Round 2

### Q4: look_at() Parallel Vector Guard
**Question:** Research found that look_at() fails when the target is directly above/below the camera. Should we add the parallel-vector guard in the GDScript handler?

**Answer:** Add the guard — Check if direction.dot(Vector3.UP) > 0.99 and use Vector3.FORWARD as up vector instead. Small code, prevents crashes.

### Q5: Behavior When Game Not Running
**Question:** When the game isn't running but the user calls godotiq_explore(mode='tour'), should the tool still return the clustering analysis without screenshots, or just return an error?

**Answer:** Graceful degradation — "it depends if the user want to plan something and just need the 'parse' its ok, but the tool is capable of also visual inspection, its up to you." Decision: Return analysis (areas, positions, node counts) when game not running, but clearly indicate no screenshots were captured. This enables planning use cases.

### Q6: Spatial Audit Integration
**Question:** Should explore include spatial_audit results alongside the screenshots?

**Answer:** Drop spatial_audit integration — Keep explore focused on screenshots only. Users can call spatial_audit separately.

## Round 3

### Q7: Community/PRO Preview Strategy
**Question:** For the Community/PRO preview: when a Community user calls explore, should we run the full clustering analysis before returning the gated preview?

**Answer:** Run clustering, show preview — Parse scene, cluster nodes, show area count and position count in preview. Demonstrates value before asking to upgrade.

### Q8: Default Scene Selection
**Question:** The tool needs a .tscn file path for tour mode. If none is provided, how should it determine which scene to analyze?

**Answer:** Use currently open scene in editor — Query the editor for the currently open scene path, same as other tools do.
