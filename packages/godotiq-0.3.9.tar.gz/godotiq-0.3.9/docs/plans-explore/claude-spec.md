# Specification: godotiq_explore — Autonomous Visual Inspection Tool

## Summary

`godotiq_explore` is a new PRO MCP tool that autonomously flies a drone camera through a running Godot game, captures screenshots from calculated positions, and returns a structured visual inspection report. It is the first tool that orchestrates multiple sequential WebSocket calls to achieve a complex multi-step operation.

## Problem Statement

Currently, AI agents using GodotIQ can modify scenes (via build_scene, node_ops, exec) and capture individual screenshots, but they have no way to systematically inspect a scene visually. An agent building a dungeon can't verify that walls are properly placed, lighting is correct, or objects aren't floating — without manually requesting many individual screenshots at specific coordinates.

`godotiq_explore` solves this by automating the entire inspection loop: parse scene → identify areas → calculate camera positions → create drone camera → fly through → capture screenshots → return structured report.

## Architecture

### Three-Layer Design

1. **Python MCP Tool** (`src/godotiq/tools/bridge/explore.py`)
   - Parses .tscn file to get node positions (filesystem, no game needed)
   - Clusters nodes into spatial areas using greedy distance-based clustering
   - Calculates camera positions per area (overview + cardinals)
   - Orchestrates sequential WebSocket calls via `bridge.request()`
   - Packages screenshots with metadata

2. **GDScript Server** (`godot-addon/addons/godotiq/godotiq_server.gd`)
   - Adds `explore_camera` to the dispatch table
   - Forwards to runtime via `_handle_game_forward()` (same as screenshot/input)

3. **GDScript Runtime** (`godot-addon/addons/godotiq/godotiq_runtime.gd`)
   - Handles `explore_camera` messages in the game process
   - Creates/moves/destroys Camera3D nodes in the game scene tree
   - Manages camera state (original camera reference, drone lifecycle)

### Communication Flow

```
Agent → godotiq_explore() → bridge.request("explore_camera", {action: "create"})
                           → bridge.request("explore_camera", {action: "move", position, look_at})
                           → bridge.request("screenshot", {viewport: "game"})
                           → ... repeat for each position ...
                           → bridge.request("explore_camera", {action: "destroy"})
                           → returns structured result
```

## Functional Requirements

### FR1: Tour Mode (Primary)
- Parse .tscn file to extract 3D node positions
- Cluster nodes into spatial areas (rooms/zones)
- Calculate camera positions per area: 1 overview + up to 4 cardinal views
- Create a drone Camera3D in the game, fly through each position, capture screenshots
- Return all screenshots with position metadata

### FR2: Inspect Mode
- Accept explicit camera positions from the caller
- Create drone, visit each position, capture screenshots
- Return screenshots with provided position metadata

### FR3: Graceful Degradation
- If game not running: return clustering analysis (areas, positions, node counts) without screenshots
- If a position fails: skip it and continue to next (never abort entire exploration)
- If game connection lost during exploration: clean up drone if possible, return partial results

### FR4: Default Scene Detection
- If no scene path provided, query editor for currently open scene
- Same pattern used by other GodotIQ tools

### FR5: PRO Gating
- Tool is PRO-only
- Community users get a rich preview showing clustering analysis (areas found, positions calculated, node count) but no screenshots
- Clustering analysis runs for Community users to demonstrate value

### FR6: Output Warning
- If total calculated screenshots exceeds 25, add a warning to the response
- Do not cap — trust the caller's parameters

## Non-Functional Requirements

### NR1: Drone Camera Cleanup
- ALWAYS clean up drone camera in try/finally
- Restore original camera before queue_free() on drone
- Use `is_instance_valid()` to validate stored camera references

### NR2: look_at() Safety
- Add parallel-vector guard in GDScript handler
- Check `direction.dot(Vector3.UP) > 0.99` and use `Vector3.FORWARD` as up vector

### NR3: No Spatial Audit Integration
- Keep explore focused on screenshots only
- Users call spatial_audit separately if needed

### NR4: Protocol Registration
- Add `"explore_camera"` to `TOOL_TIMEOUTS` in `protocol.py`
- Timeout should accommodate multiple sequential operations (10s per move+screenshot)

## Key Design Decisions

| Decision | Choice | Rationale |
|----------|--------|-----------|
| IPC Pattern | Game-forward to runtime | Camera lives in game process, same as screenshot/input |
| Scene Data Source | Internal `_build_scene_map()` | Avoids MCP overhead and PRO gating |
| Clustering Algorithm | Greedy distance-based, O(n^2) | No dependencies, sufficient for 100-1000 nodes |
| Distance Threshold | 15.0 default | Room-sized clusters for typical game scenes |
| Output Cap | Warn at 25, don't cap | Trust caller parameters |
| Spatial Audit | Dropped | Keep tool focused, users call separately |
| Community Preview | Run clustering, show analysis | Demonstrates value before upgrade prompt |
| Default Scene | Currently open in editor | Consistent with other tools |

## Tool Signature

```python
godotiq_explore(
    scene: str = "",              # .tscn path (empty = current editor scene)
    mode: str = "tour",           # "tour" or "inspect"
    positions: str = "",          # JSON array for inspect mode
    max_areas: int = 5,           # max clusters to visit
    screenshots_per_area: int = 3, # 1=overview, 3=overview+2 cardinals, 5=all
    scale: float = 0.5,           # screenshot scale
    quality: float = 0.6,         # screenshot quality
    fov: float = 70.0,            # camera FOV
    eye_height: float = 2.5,      # cardinal view height
    detail: str = "normal",       # output detail level
)
```

## Return Structure

```python
{
    "areas_inspected": 5,
    "total_screenshots": 15,
    "screenshots": [
        {
            "area_index": 0,
            "area_center": [5.0, 0.0, 5.0],
            "area_node_count": 47,
            "position": [5.0, 9.0, 2.5],
            "look_at": [5.0, 0.0, 5.0],
            "direction": "overview",
            "image": "<base64 webp>",
        },
        ...
    ],
    "total_nodes": 729,
    "inspection_time_ms": 4500,
    "warning": "25+ screenshots requested; consider reducing parameters",  # optional
}
```

## Files to Create/Modify

### New Files
- `src/godotiq/tools/bridge/explore.py` — Python implementation
- `tests/test_tools/test_explore.py` — Test suite

### Modified Files
- `src/godotiq/tools/bridge/__init__.py` — Register tool wrapper
- `godot-addon/addons/godotiq/godotiq_server.gd` — Add dispatch entry
- `godot-addon/addons/godotiq/godotiq_runtime.gd` — Add game-side handler
- `src/godotiq/bridge/protocol.py` — Add timeout entry
- `src/godotiq/license.py` — Add to PRO_TOOLS, add preview builder
- `src/godotiq/prompts/godot_development.md` — Add tool docs and workflow
- `pyproject.toml` — Version bump to 0.3.0
- `godot-addon/addons/godotiq/plugin.cfg` — Version sync
