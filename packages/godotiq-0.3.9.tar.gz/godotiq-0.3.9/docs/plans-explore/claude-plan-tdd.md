# TDD Plan: godotiq_explore

Mirrors the structure of `claude-plan.md`. For each implementation section, defines test stubs to write BEFORE implementing.

**Testing framework:** pytest with pytest-asyncio (`asyncio_mode = "auto"`)
**Test location:** `tests/test_tools/test_explore.py`
**Mocking:** `unittest.mock.AsyncMock` + `patch` for bridge calls
**Fixtures:** `GodotIQSession` from `tests/test_tools/conftest.py`

---

## 2. GDScript Changes

GDScript handlers are not testable via pytest. Verified manually via running game. No test stubs needed here — Python-side tests mock the bridge layer.

---

## 3. Python Bridge Tool

### 3.3 Spatial Clustering — Tests (Write FIRST)

```python
# Test: _cluster_nodes with empty input returns empty list
# Test: _cluster_nodes with single node returns single cluster with that node
# Test: _cluster_nodes with two nodes within threshold returns one cluster
# Test: _cluster_nodes with two distant groups returns two clusters
# Test: _cluster_nodes with nodes lacking position data filters them out
# Test: _cluster_nodes calculates correct centroid for cluster
# Test: _cluster_nodes calculates correct bounds (min/max per axis)
# Test: _cluster_nodes sorts clusters by node_count descending
# Test: _cluster_nodes with custom distance_threshold respects the value
```

### 3.4 Camera Position Calculation — Tests (Write FIRST)

```python
# Test: _calculate_camera_positions returns exactly 5 positions
# Test: _calculate_camera_positions first position has direction "overview"
# Test: _calculate_camera_positions overview position y is above cluster center y
# Test: _calculate_camera_positions cardinal positions 2-5 have y == center_y + eye_height
# Test: _calculate_camera_positions custom eye_height is reflected in cardinal y values
# Test: _calculate_camera_positions radius scales with cluster bounds
# Test: _calculate_camera_positions minimum radius is 5.0 even for tiny cluster
# Test: _calculate_camera_positions all positions have position, look_at, direction keys
# Test: _calculate_camera_positions cardinal directions are north, east, south, west
```

### 3.5 Scene Layout Retrieval — Tests

```python
# Test: _get_scene_layout calls _build_scene_map with correct session and path
# Test: _get_scene_layout returns nodes list from scene_map result
```

### 3.6 Tour Mode Flow — Integration Tests (Mock Bridge)

```python
# Test: explore tour mode returns correct structure (areas_inspected, total_screenshots, screenshots list, total_nodes, inspection_time_ms)
# Test: explore tour mode calls bridge.request in correct sequence: create → (move → screenshot) × N → destroy
# Test: explore tour mode with max_areas=2 limits to 2 clusters
# Test: explore tour mode with screenshots_per_area=1 captures only overview per area
# Test: explore tour mode with screenshots_per_area=3 captures overview + 2 cardinals
# Test: explore tour mode passes format="webp" to screenshot calls
# Test: explore tour mode passes correct scale and quality to screenshot calls
# Test: explore tour mode passes correct fov to create call
```

### 3.7 Inspect Mode Flow — Integration Tests

```python
# Test: explore inspect mode visits each provided position
# Test: explore inspect mode returns screenshot for each position
# Test: explore inspect mode uses provided direction labels
```

### 3.8 Graceful Degradation — Tests

```python
# Test: explore returns clustering analysis when BridgeConnectionError on create
# Test: explore result includes game_running=false when game not running
# Test: explore result includes areas_inspected and total_nodes even when game not running
```

### Error Handling — Tests

```python
# Test: explore returns error when bridge create fails with BridgeError
# Test: explore skips position when move fails, continues to next
# Test: explore skips position when screenshot fails, continues to next
# Test: explore calls destroy even when moves/screenshots fail (try/finally)
# Test: explore calls destroy even when an exception occurs mid-loop
```

### Output Warning — Tests

```python
# Test: explore includes warning when total positions > 25
# Test: explore does NOT include warning when total positions <= 25
```

---

## 4. PRO Gating — Tests

```python
# Test: "godotiq_explore" is in PRO_TOOLS frozenset
# Test: "godotiq_explore" is in _PREVIEW_BUILDERS dict
# Test: _preview_explore returns preview with areas_found, positions_calculated, total_nodes
# Test: _preview_explore returns locked sections including "screenshots"
# Test: _preview_explore returns descriptive message
# Test: gate_pro returns preview structure for Community users (mock is_pro=False)
# Test: gate_pro passes through full result for PRO users (mock is_pro=True)
# Test: gate_pro passes through error results ungated
```

---

## 5. Protocol Registration — Tests

```python
# Test: "explore_camera" exists in TOOL_TIMEOUTS dict
# Test: "explore_camera" timeout is 10 seconds
```

---

## 7. Version Bump — Tests

```python
# Test: version in pyproject.toml is 0.3.0
# Test: version sync check passes (existing test_version_sync.py handles this)
```
