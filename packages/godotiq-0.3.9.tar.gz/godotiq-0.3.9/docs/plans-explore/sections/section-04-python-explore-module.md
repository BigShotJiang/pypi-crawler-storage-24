Now I have all the context I need. Let me produce the section content.

# Section 04: Python Explore Module

## Overview

This section implements `src/godotiq/tools/bridge/explore.py`, the core Python module for the `godotiq_explore` MCP tool. It contains four components:

1. `_cluster_nodes()` -- pure function that groups scene nodes into spatial clusters
2. `_calculate_camera_positions()` -- pure function that computes camera viewpoints per cluster
3. `_get_scene_layout()` -- synchronous function that reads .tscn scene data via `_build_scene_map()`
4. `explore()` -- async orchestrator that creates a drone camera, flies it through positions, captures screenshots, and returns a structured report

This module does NOT register the MCP tool (that is section-06). It exports the `explore()` function for the wrapper in `__init__.py` to call.

## Dependencies on Other Sections

- **section-01-gdscript-handlers**: The GDScript runtime must handle `explore_camera` with create/move/destroy actions. This section's Python code sends those requests via the bridge.
- **section-02-protocol-registration**: `"explore_camera"` must exist in `TOOL_TIMEOUTS` in `src/godotiq/bridge/protocol.py` with a 10-second timeout.
- **section-03-pure-function-tests**: Tests for `_cluster_nodes()` and `_calculate_camera_positions()` are written first (TDD). This section implements the functions to make those tests pass.

## File to Create

**`/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/explore.py`**

## Tests (Write FIRST)

All tests go in **`/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_explore.py`**.

Section-03 should have already created the pure function tests for `_cluster_nodes()` and `_calculate_camera_positions()`. This section adds tests for `_get_scene_layout()`. Integration tests for the full `explore()` flow are covered in section-05, but the pure function implementations here must pass all section-03 tests.

### Scene Layout Tests

These test that `_get_scene_layout` correctly delegates to `_build_scene_map` and returns the nodes list.

```python
# Test: _get_scene_layout calls _build_scene_map with correct session and path
# Test: _get_scene_layout returns nodes list from scene_map result
```

These tests should mock `_build_scene_map` (imported from `godotiq.tools.spatial`) and verify:

- The function is called with the provided session object and scene path
- The returned value extracts the `"nodes"` list from the scene map result
- If the scene map result contains an `"error"` key, it is propagated

## Implementation Details

### Imports and Module Structure

The module needs these imports:

- `asyncio` -- for `asyncio.sleep()` between camera moves
- `math` -- for Euclidean distance and radius calculations
- `time` -- for timing the inspection duration
- `get_bridge` from `godotiq.bridge.session` -- for WebSocket communication
- `BridgeConnectionError` from `godotiq.bridge.connection` -- for graceful degradation
- `_build_scene_map` from `godotiq.tools.spatial` -- for scene parsing
- `GodotIQSession` from `godotiq.session` -- type annotation

### `_cluster_nodes(nodes, distance_threshold=15.0)`

**Signature:**

```python
def _cluster_nodes(
    nodes: list[dict],
    distance_threshold: float = 15.0,
) -> list[dict]:
    """Greedy spatial clustering of scene nodes by position.

    Args:
        nodes: Node dicts from scene_map output, each with "position": [x, y, z].
        distance_threshold: Max Euclidean distance to include in same cluster.

    Returns:
        List of cluster dicts sorted by node_count descending. Each cluster has:
        - center: [x, y, z] centroid
        - bounds: {min: [x,y,z], max: [x,y,z]}
        - node_count: int
        - nodes: list of the original node dicts
    """
```

**Algorithm -- greedy single-pass clustering:**

1. Filter out nodes that have no `"position"` key or whose position is not a list of 3 numbers.
2. Track assigned nodes with a set of indices.
3. For each unassigned node (the "seed"):
   - Start a new cluster containing the seed.
   - Scan all other unassigned nodes. If Euclidean distance from the seed to the candidate is within `distance_threshold`, add it to the cluster.
   - Compute centroid as average of all cluster node positions.
   - Compute bounds as min/max per axis across all cluster nodes.
   - Record the cluster dict.
4. Sort clusters by `node_count` descending (largest first).
5. Return the list of cluster dicts.

Euclidean distance is computed as `sqrt((x1-x2)^2 + (y1-y2)^2 + (z1-z2)^2)`.

This is O(n^2) which is acceptable for scenes with fewer than 1000 nodes.

**Known limitation:** Clustering is seeded from the first unassigned node, not the evolving centroid. A long chain of nodes each within threshold of the next but spanning a large total distance will merge into one cluster. This is acceptable for typical game scenes with distinct rooms or zones.

### `_calculate_camera_positions(cluster, eye_height=2.5)`

**Signature:**

```python
def _calculate_camera_positions(
    cluster: dict,
    eye_height: float = 2.5,
) -> list[dict]:
    """Calculate 5 camera positions for inspecting a cluster.

    Args:
        cluster: A cluster dict with center, bounds, and node_count.
        eye_height: Height offset for cardinal camera positions.

    Returns:
        List of 5 position dicts, each with:
        - position: [x, y, z]
        - look_at: [x, y, z]
        - direction: str ("overview", "north", "east", "south", "west")
    """
```

**Position calculation:**

1. Extract `center` from the cluster as `[cx, cy, cz]`.
2. Compute half-widths from bounds:
   - `half_x = (bounds["max"][0] - bounds["min"][0]) / 2`
   - `half_z = (bounds["max"][2] - bounds["min"][2]) / 2`
3. Compute radius: `max(half_x, half_z) + 3.0`, with a minimum of `5.0`.
4. Generate 5 positions:

| # | Direction | Position | Look-at |
|---|-----------|----------|---------|
| 1 | overview | `[cx, cy + radius * 1.2, cz - radius * 0.5]` | `[cx, cy, cz]` |
| 2 | north | `[cx, cy + eye_height, cz - radius]` | `[cx, cy, cz]` |
| 3 | east | `[cx + radius, cy + eye_height, cz]` | `[cx, cy, cz]` |
| 4 | south | `[cx, cy + eye_height, cz + radius]` | `[cx, cy, cz]` |
| 5 | west | `[cx - radius, cy + eye_height, cz]` | `[cx, cy, cz]` |

All `look_at` targets point at the cluster center.

### `_get_scene_layout(session, scene_path)`

**Signature:**

```python
def _get_scene_layout(
    session: GodotIQSession,
    scene_path: str,
) -> dict:
    """Get node positions from a .tscn scene file.

    This is synchronous -- _build_scene_map reads from the filesystem.

    Args:
        session: Loaded GodotIQSession.
        scene_path: res:// path to .tscn file.

    Returns:
        The scene map dict from _build_scene_map, which includes a "nodes" list
        with position data. Returns dict with "error" key on failure.
    """
```

This function:
1. Imports `_build_scene_map` from `godotiq.tools.spatial`
2. Calls `_build_scene_map(session, scene_path)` with default parameters (no focus, default radius, no include filter, default detail)
3. Returns the result directly -- the caller extracts the `"nodes"` list

### `explore()` -- Main Async Orchestrator

**Signature:**

```python
async def explore(
    session: GodotIQSession,
    scene: str = "",
    mode: str = "tour",
    positions: list[dict] | None = None,
    max_areas: int = 5,
    screenshots_per_area: int = 1,
    scale: float = 0.5,
    quality: float = 0.6,
    fov: float = 70.0,
    eye_height: float = 2.5,
) -> dict:
    """Autonomous visual inspection of the running game.

    Args:
        session: Loaded GodotIQSession (for .tscn parsing).
        scene: res:// path to .tscn scene. Falls back to main scene.
        mode: "tour" (auto-cluster) or "inspect" (explicit positions).
        positions: For inspect mode: list of position dicts with position/look_at/rotation.
        max_areas: Max clusters to visit in tour mode.
        screenshots_per_area: How many of the 5 positions to capture per cluster.
        scale: Screenshot scale (0.0-1.0).
        quality: Screenshot encoding quality (0.0-1.0).
        fov: Drone camera field of view in degrees.
        eye_height: Height offset for cardinal camera positions.

    Returns:
        Dict with areas_inspected, total_screenshots, screenshots list,
        total_nodes, inspection_time_ms, and optional warning.
    """
```

#### Tour Mode Flow

1. **Resolve scene path.** If `scene` is empty, use `_read_main_scene(session)` from `godotiq.tools.memory`. If still empty, return `{"error": "No scene specified and no main scene found"}`.
2. **Get scene layout.** Call `_get_scene_layout(session, resolved_path)`. If result has `"error"`, return it.
3. **Extract positioned nodes.** Filter the `"nodes"` list to nodes that have a `"position"` key.
4. **Cluster nodes.** Call `_cluster_nodes(positioned_nodes)`.
5. **Limit clusters.** Slice to `max_areas` clusters.
6. **Calculate camera positions.** For each cluster, call `_calculate_camera_positions(cluster, eye_height)` and slice to `screenshots_per_area` positions.
7. **Build flat position list.** Flatten all per-cluster positions into one list, tagging each with its cluster index.
8. **Check warning threshold.** If total positions > 25, set a warning string.
9. **Connect bridge.** Call `get_bridge()`. If `BridgeConnectionError` is raised, return the clustering analysis without screenshots, including `"game_running": false`.
10. **Create drone.** `await bridge.request("explore_camera", {"action": "create", "fov": fov})`. The destroy call must happen in a `try/finally` block from this point onward.
11. **Capture loop (sequential, never parallel):**
    - For each position:
      a. `await bridge.request("explore_camera", {"action": "move", "position": pos["position"], "look_at": pos["look_at"]})` -- if this raises, skip to next position.
      b. `await asyncio.sleep(0.1)` -- settling delay.
      c. `await bridge.request("screenshot", {"viewport": "game", "scale": scale, "quality": quality, "format": "webp"})` -- if this raises, skip to next position.
      d. Append the screenshot result plus position metadata to the screenshots list.
12. **Destroy drone.** In the `finally` block: `await bridge.request("explore_camera", {"action": "destroy"})`. Wrap in try/except to swallow errors during cleanup.
13. **Return result dict:**

```python
{
    "areas_inspected": len(clusters_used),
    "total_screenshots": len(screenshots),
    "screenshots": screenshots,
    "total_nodes": total_nodes_count,
    "inspection_time_ms": elapsed_ms,
    "game_running": True,
}
```

If warning threshold was hit, add `"warning"` key.

#### Inspect Mode Flow

1. **Validate positions.** If `positions` is None or empty, return `{"error": "inspect mode requires positions list"}`.
2. **Connect bridge.** Same as tour mode.
3. **Create/capture/destroy loop.** Same as tour mode steps 10-12, but iterate over the provided `positions` list instead of calculated positions. Each provided position dict should have `"position"` (required) and optionally `"look_at"` or `"rotation"` and `"direction"` (label).
4. **Return result dict.** Same structure as tour mode but `areas_inspected` is 0 (no clustering done).

#### Graceful Degradation (Game Not Running)

If `BridgeConnectionError` is raised when trying to `get_bridge()` or during the `create` call, return a result without screenshots:

```python
{
    "areas_inspected": len(clusters),
    "total_screenshots": 0,
    "total_positions_calculated": total_position_count,
    "screenshots": [],
    "total_nodes": total_nodes_count,
    "game_running": False,
    "clusters": [{"center": c["center"], "node_count": c["node_count"]} for c in clusters],
}
```

This allows agents to plan inspections (understand scene layout) even when the game is not running.

#### Output Warning

If the total number of planned screenshot positions exceeds 25:

```python
result["warning"] = f"25+ screenshots requested ({total} total); consider reducing max_areas or screenshots_per_area for faster results"
```

Do NOT cap the positions -- honor the caller's parameters. The warning is advisory only.

#### Screenshot Entry Format

Each entry in the `screenshots` list should be a dict:

```python
{
    "area_index": cluster_index,  # or None for inspect mode
    "direction": position_direction_label,
    "position": [x, y, z],
    "look_at": [lx, ly, lz],  # if applicable
    "image": base64_image_data,
    "format": "webp",
    "width": pixel_width,
    "height": pixel_height,
}
```

The `image`, `format`, `width`, `height` fields come from the screenshot bridge response. The `area_index`, `direction`, `position`, and `look_at` fields are added by the explore module.

### Key Constraint: Serial Bridge Calls Only

The bridge matches responses to pending requests by method name, not request ID. Only one pending request of each method type can exist at a time. The explore tool's sequential flow (move, then screenshot, then move, then screenshot) is safe because it awaits each response before sending the next. The implementation MUST NOT attempt to pipeline or parallelize bridge calls. Each `await bridge.request(...)` must complete before the next is issued.

### Two Session Concepts

- **`GodotIQSession`** (from `src/godotiq/session.py`): For filesystem-level .tscn parsing. Used by `_get_scene_layout()`.
- **`BridgeConnection`** (from `src/godotiq/bridge/connection.py`): For WebSocket runtime communication. Used by the drone camera operations and screenshot capture.

The `explore()` function receives `session` as a parameter (passed by the wrapper in `__init__.py` which extracts it from `ctx.request_context.lifespan_context["session"]`).

## Verification

After implementation, run:

```bash
cd /Users/salvatorefarruggio/Desktop/godotiq
uv run pytest tests/test_tools/test_explore.py -v
```

All section-03 pure function tests plus the `_get_scene_layout` tests defined here must pass. The integration tests (section-05) and PRO gating tests (section-07) will be added later.