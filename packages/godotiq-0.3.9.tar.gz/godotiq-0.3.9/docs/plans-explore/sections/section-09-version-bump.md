Now I have all the context I need. Let me generate the section content.

# Section 09: Version Bump

## Overview

This is the final section of the `godotiq_explore` implementation. It bumps the project version from `0.2.0` to `0.3.0` (new feature warrants a minor version bump), runs the version sync script to propagate the change to Godot addon files, and rebuilds the wheel. No PyPI upload is performed.

## Dependencies

All prior sections (01 through 08) must be completed before this section. This section is a release-preparation step that should only run after all code and tests are in place.

## Tests (Write FIRST)

All tests go in `tests/test_tools/test_explore.py` (appended to the existing test file created in prior sections) or in the existing test files listed below.

### Version Value Test

File: `tests/test_version.py`

The existing `test_version_matches_expected` test in `TestVersionAttribute` currently asserts version `"0.1.9"`. This must be updated to assert `"0.3.0"`:

```python
def test_version_matches_expected(self):
    """__version__ should equal the version in pyproject.toml (currently 0.3.0)."""
    from godotiq import __version__
    assert __version__ == "0.3.0"
```

### Version Sync Consistency Test

File: `tests/test_version_sync.py`

The existing `test_version_sync.py` tests use example version `"0.1.4"` in temporary files and do not hardcode the actual project version. These tests remain valid and require no changes -- they verify the sync mechanism itself, not the specific version value.

However, running the full test suite after the version bump serves as the sync validation test: the `test_version_matches_expected` test will fail if `pyproject.toml` was not correctly updated, and any existing sync-check tests will fail if `plugin.cfg` or `godotiq_server.gd` are out of sync.

### Explicit Version Check Test

Add a simple test that directly reads `pyproject.toml` and confirms the version is `0.3.0`. This can be added to `tests/test_tools/test_explore.py` alongside the other explore tests:

```python
# Test: version in pyproject.toml is 0.3.0
```

The test should read `pyproject.toml` from the project root (using `Path(__file__).resolve().parents[2] / "pyproject.toml"` to navigate from `tests/test_tools/` up to the project root), parse it, and assert `version == "0.3.0"`. Use `tomllib` (Python 3.11+) with a `re`-based fallback for Python 3.10 compatibility, matching the pattern in `scripts/sync_version.py`.

## Implementation Steps

### Step 1: Bump version in pyproject.toml

File: `/Users/salvatorefarruggio/Desktop/godotiq/pyproject.toml`

Change line 7 from:

```toml
version = "0.2.0"
```

to:

```toml
version = "0.3.0"
```

This is the single source of truth for the project version. All other version references derive from this value.

### Step 2: Run the version sync script

File: `/Users/salvatorefarruggio/Desktop/godotiq/scripts/sync_version.py`

Execute the sync script from the project root:

```bash
python scripts/sync_version.py
```

This script performs two updates:

1. **`godot-addon/addons/godotiq/plugin.cfg`** -- replaces the `version="0.2.0"` line with `version="0.3.0"`. The script uses a regex `^version="[^"]*"` with `re.MULTILINE` to locate and replace the line.

2. **`godot-addon/addons/godotiq/godotiq_server.gd`** -- replaces the `const ADDON_VERSION := "0.2.0"` line with `const ADDON_VERSION := "0.3.0"`. The script uses a regex `^const ADDON_VERSION := "[^"]*"` with `re.MULTILINE`.

After running, verify the output shows both files were updated (not "already at" and not "WARNING"):

```
Reading version from pyproject.toml: 0.3.0
Updated plugin.cfg: 0.2.0 -> 0.3.0
Updated godotiq_server.gd: 0.2.0 -> 0.3.0
```

### Step 3: Update the hardcoded version assertion in test_version.py

File: `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_version.py`

The `test_version_matches_expected` method on line 25 currently asserts:

```python
assert __version__ == "0.1.9"
```

Change this to:

```python
assert __version__ == "0.3.0"
```

This test validates that Python's `importlib.metadata` reads the correct version from the installed package, which in editable mode (`pip install -e .`) reflects `pyproject.toml` directly.

### Step 4: Rebuild the wheel

From the project root, rebuild the distribution artifacts:

```bash
python -m build
```

This creates files in the `dist/` directory. The wheel filename should contain `0.3.0` (e.g., `godotiq-0.3.0-py3-none-any.whl`).

**Do NOT upload to PyPI.** This is a local build for verification only.

### Step 5: Run the full test suite

```bash
uv run pytest -v
```

All tests must pass, including:
- `tests/test_version.py::TestVersionAttribute::test_version_matches_expected` -- confirms `__version__ == "0.3.0"`
- `tests/test_version.py::TestPingUsesDynamicVersion::test_ping_version_matches_package_version` -- confirms ping returns the new version
- `tests/test_version_sync.py` -- confirms the sync mechanism works correctly
- All new explore tests from sections 03, 05, and 07

## Files Modified

| File | Change |
|------|--------|
| `pyproject.toml` | `version = "0.2.0"` changed to `version = "0.3.0"` |
| `godot-addon/addons/godotiq/plugin.cfg` | `version="0.2.0"` changed to `version="0.3.0"` (via sync script) |
| `godot-addon/addons/godotiq/godotiq_server.gd` | `ADDON_VERSION := "0.2.0"` changed to `ADDON_VERSION := "0.3.0"` (via sync script) |
| `tests/test_version.py` | Version assertion updated from `"0.1.9"` to `"0.3.0"` |
| `tests/test_tools/test_explore.py` | Add pyproject.toml version value test |

## Verification Checklist

After completing all steps, verify:

1. `pyproject.toml` contains `version = "0.3.0"`
2. `plugin.cfg` contains `version="0.3.0"`
3. `godotiq_server.gd` contains `const ADDON_VERSION := "0.3.0"`
4. `tests/test_version.py` asserts `__version__ == "0.3.0"`
5. `uv run pytest -v` passes all tests
6. `dist/` contains a wheel file with `0.3.0` in its name (if wheel was built)