<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-gdscript-handlers
section-02-protocol-registration
section-03-pure-function-tests
section-04-python-explore-module
section-05-integration-tests
section-06-bridge-wrapper-pro-gating
section-07-pro-gating-tests
section-08-prompt-update
section-09-version-bump
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-gdscript-handlers | - | 02, 04 | Yes |
| section-02-protocol-registration | - | 04 | Yes |
| section-03-pure-function-tests | - | 04 | Yes |
| section-04-python-explore-module | 01, 02, 03 | 05, 06 | No |
| section-05-integration-tests | 04 | 06 | No |
| section-06-bridge-wrapper-pro-gating | 04, 05 | 07 | No |
| section-07-pro-gating-tests | 06 | - | No |
| section-08-prompt-update | - | 09 | Yes |
| section-09-version-bump | 01-08 | - | No |

## Execution Order

1. section-01-gdscript-handlers, section-02-protocol-registration, section-03-pure-function-tests (parallel, no dependencies)
2. section-04-python-explore-module (after 01, 02, 03)
3. section-05-integration-tests (after 04)
4. section-06-bridge-wrapper-pro-gating (after 04, 05)
5. section-07-pro-gating-tests (after 06)
6. section-08-prompt-update (can run anytime, but logically after implementation)
7. section-09-version-bump (after all others)

## Section Summaries

### section-01-gdscript-handlers
Add explore_camera to server dispatch, debugger capture, and runtime handler. Three GDScript files modified: godotiq_server.gd (dispatch entry), godotiq_debugger.gd (capture case), godotiq_runtime.gd (create/move/destroy handler with parallel-vector guard).

### section-02-protocol-registration
Add "explore_camera" to TOOL_TIMEOUTS in protocol.py with 10-second timeout.

### section-03-pure-function-tests
TDD: Write tests for _cluster_nodes() and _calculate_camera_positions() before implementation. Tests for empty input, single node, two clusters, centroid calculation, bounds, sorting, overview position, cardinal positions, eye_height.

### section-04-python-explore-module
Implement explore.py with _cluster_nodes(), _calculate_camera_positions(), _get_scene_layout(), and the main explore() async function. Tour mode and inspect mode flows. Graceful degradation when game not running. Output warning at 25+ screenshots.

### section-05-integration-tests
Mock bridge tests for full explore flow. Test correct bridge call sequence, error handling (create fail, move fail, screenshot fail), try/finally cleanup, graceful degradation, output warning.

### section-06-bridge-wrapper-pro-gating
Add godotiq_explore wrapper to __init__.py with error handling. Add to PRO_TOOLS, implement _preview_explore builder, register in _PREVIEW_BUILDERS dict.

### section-07-pro-gating-tests
Test PRO_TOOLS membership, _PREVIEW_BUILDERS registration, preview builder output, gate_pro behavior for Community and PRO users.

### section-08-prompt-update
Add visual QA workflow and godotiq_explore tool description to godot_development.md.

### section-09-version-bump
Bump to 0.3.0 in pyproject.toml, run version sync script, rebuild wheel.
