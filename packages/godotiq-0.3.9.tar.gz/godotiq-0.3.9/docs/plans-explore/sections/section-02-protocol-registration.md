I now have all the context needed. Let me produce the section content.

# Section 02: Protocol Registration

## Overview

This section adds `"explore_camera"` to the `TOOL_TIMEOUTS` dictionary in `src/godotiq/bridge/protocol.py` with a 10-second timeout. This is a small, self-contained change that enables the Python bridge layer to call the new `explore_camera` method with the correct timeout configuration. Without this entry, explore_camera calls would fall back to the default 5.0-second timeout (via `get_timeout()`), which is technically functional but does not provide adequate margin for camera operations plus frame rendering.

## Dependencies

- **None.** This section has no dependencies and can be implemented in parallel with section-01 (GDScript handlers) and section-03 (pure function tests).
- **Blocks:** section-04 (Python explore module) depends on this being in place so that bridge calls use the correct timeout.

## Tests First

Add the following two tests to the existing test file at `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_bridge/test_protocol.py`, inside the `TestTimeouts` class. The class already contains tests for other methods in `TOOL_TIMEOUTS` (e.g., `test_known_method_screenshot`, `test_node_ops_timeout`) and follows a consistent pattern of asserting both the presence in the dict and the exact timeout value.

```python
def test_explore_camera_in_tool_timeouts(self) -> None:
    """explore_camera exists in TOOL_TIMEOUTS dict."""
    assert "explore_camera" in TOOL_TIMEOUTS

def test_explore_camera_timeout_value(self) -> None:
    """explore_camera has a 10-second timeout."""
    assert get_timeout("explore_camera") == 10.0
```

These tests should be added after the existing `test_node_ops_timeout` method and before `test_all_timeouts_positive`. The existing `test_all_timeouts_positive` test will also implicitly validate that the new entry has a positive value.

Run the tests to confirm they fail before implementation:

```bash
uv run pytest tests/test_bridge/test_protocol.py -v
```

Both new tests should fail with `AssertionError` since `"explore_camera"` does not yet exist in `TOOL_TIMEOUTS`.

## Implementation

### File to Modify

`/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/bridge/protocol.py`

### Change

Add a single entry to the `TOOL_TIMEOUTS` dictionary. The current dictionary (lines 9-20 of protocol.py) contains entries for: `ping`, `screenshot`, `perf_snapshot`, `editor_context`, `run`, `stop`, `scene_tree`, `node_ops`, `build_scene`, `check_errors`.

Add the new entry after `check_errors`:

```python
"explore_camera": 10.0,
```

The 10-second timeout provides margin for the individual explore_camera actions (create, move, destroy). Each action itself is fast (sub-second), but the timeout needs to account for:
- The game processing the request through the debugger IPC chain (server -> debugger -> runtime -> debugger -> server)
- Frame rendering after camera moves (the runtime awaits `process_frame`)
- Network latency on the WebSocket connection

This matches the 10-second timeout used in the GDScript server dispatch (`_handle_game_forward(peer_id, id, "godotiq:explore_camera", params, 10000)` from section-01).

No other changes are needed in this file. The existing `get_timeout()` function already handles dictionary lookups, so any code calling `get_timeout("explore_camera")` will automatically return 10.0 once this entry is added.

### After the Change

The `TOOL_TIMEOUTS` dictionary should look like this:

```python
TOOL_TIMEOUTS: dict[str, float] = {
    "ping": 2.0,
    "screenshot": 30.0,
    "perf_snapshot": 5.0,
    "editor_context": 5.0,
    "run": 10.0,
    "stop": 5.0,
    "scene_tree": 5.0,
    "node_ops": 10.0,
    "build_scene": 30.0,
    "check_errors": 15.0,
    "explore_camera": 10.0,
}
```

## Verification

Run the protocol tests to confirm both new tests pass and all existing tests remain green:

```bash
uv run pytest tests/test_bridge/test_protocol.py -v
```

Expected: all tests in `TestTimeouts` pass, including the two new ones (`test_explore_camera_in_tool_timeouts` and `test_explore_camera_timeout_value`), plus the existing `test_all_timeouts_positive` which validates that every entry in the dict (including the new one) has a positive value.