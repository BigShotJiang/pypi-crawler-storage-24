Now I have complete understanding of the codebase patterns. Let me produce the section content.

# Section 06: Bridge Wrapper + PRO Gating

## Overview

This section adds the public `godotiq_explore` MCP tool wrapper in the bridge tools `__init__.py`, and integrates explore into the PRO licensing system. The wrapper follows the same error-handling pattern as all other bridge tools, calls the internal `explore()` function (created in section 04), and applies `gate_pro()` on the result. The licensing changes add `"godotiq_explore"` to `PRO_TOOLS`, implement a dedicated preview builder, and register it in `_PREVIEW_BUILDERS`.

## Dependencies

- **Section 04 (Python Explore Module)**: The `explore()` async function must exist at `src/godotiq/tools/bridge/explore.py` with the signature `async def explore(session, bridge_getter, scene, mode, positions, max_areas, screenshots_per_area, scale, quality, fov, eye_height) -> dict`. This section imports and calls it.
- **Section 05 (Integration Tests)**: The integration tests for the explore flow should pass before this wrapper is added. This section's wrapper delegates to the already-tested `explore()` function.

## Files to Modify

| File | Action | Description |
|------|--------|-------------|
| `src/godotiq/tools/bridge/__init__.py` | **Modify** | Add import of explore function, add `godotiq_explore` wrapper with error handling and `gate_pro()` |
| `src/godotiq/license.py` | **Modify** | Add `"godotiq_explore"` to `PRO_TOOLS`, add `_preview_explore` builder function, register in `_PREVIEW_BUILDERS` |
| `tests/test_tools/test_explore.py` | **Modify** | Add PRO gating test stubs (these may also be placed in `tests/test_license.py` alongside existing preview tests) |

---

## Tests (Write FIRST)

All tests belong in `tests/test_tools/test_explore.py` (or equivalently in `tests/test_license.py` if following the established pattern for preview builder tests). The tests below verify three things: PRO_TOOLS membership, preview builder behavior, and gate_pro integration.

### PRO_TOOLS membership

```python
# Test: "godotiq_explore" is in PRO_TOOLS frozenset
# Import PRO_TOOLS from godotiq.license and assert membership.
```

### _PREVIEW_BUILDERS registration

```python
# Test: "godotiq_explore" is in _PREVIEW_BUILDERS dict
# Import _PREVIEW_BUILDERS from godotiq.license and assert key exists.
```

### Preview builder output

The `_preview_explore` function receives a full explore result dict and returns `(preview, locked_sections, message)`. Tests should use a mock result dict shaped like:

```python
_MOCK_EXPLORE_RESULT = {
    "areas_inspected": 3,
    "total_screenshots": 5,
    "total_nodes": 47,
    "screenshots": [{"direction": "overview", "data": "base64..."}],
    "inspection_time_ms": 2400,
}
```

Test stubs:

```python
# Test: _preview_explore returns preview with areas_found key matching areas_inspected
# Test: _preview_explore returns preview with positions_calculated key matching total_screenshots
# Test: _preview_explore returns preview with total_nodes key matching total_nodes
# Test: _preview_explore returns locked sections list containing "screenshots"
# Test: _preview_explore returns locked sections list containing "visual inspection data"
# Test: _preview_explore returns descriptive message containing area count and node count
# Test: _preview_explore handles empty result dict gracefully (no KeyError)
```

### gate_pro integration

```python
# Test: gate_pro returns preview structure for Community users (no license env vars set)
#   - Call gate_pro("godotiq_explore", mock_result)
#   - Assert result["tier"] == "community"
#   - Assert "preview" in result
#   - Assert result["preview"]["areas_found"] matches input

# Test: gate_pro passes through full result for PRO users (set GODOTIQ_DEV_KEY env var)
#   - monkeypatch.setenv("GODOTIQ_DEV_KEY", dev_key)
#   - Call gate_pro("godotiq_explore", mock_result)
#   - Assert result is mock_result (identity check)

# Test: gate_pro passes through error results ungated
#   - Call gate_pro("godotiq_explore", {"error": "some error"})
#   - Assert result == {"error": "some error"}
```

### Existing test_license.py updates

The existing `tests/test_license.py` has parametrized tests that iterate over all `PRO_TOOLS` and check that each has a `_PREVIEW_BUILDERS` entry and a corresponding `_MOCK_RESULTS` entry. After adding `"godotiq_explore"` to `PRO_TOOLS`, you must also add a `"godotiq_explore"` entry to the `_MOCK_RESULTS` dict in `tests/test_license.py` so that the parametrized tests (`test_all_pro_tools_have_builders`, `test_builder_returns_tuple`, `test_all_pro_tools_gated_for_community`, `test_all_pro_tools_pass_for_pro`) continue to pass.

The mock result entry to add:

```python
"godotiq_explore": {
    "areas_inspected": 3,
    "total_screenshots": 5,
    "total_nodes": 47,
    "screenshots": [{"direction": "overview", "data": "base64..."}],
    "inspection_time_ms": 2400,
},
```

---

## Implementation Details

### 1. Add `"godotiq_explore"` to PRO_TOOLS in `src/godotiq/license.py`

In the `PRO_TOOLS` frozenset definition (currently 13 tools), add `"godotiq_explore"` as a new entry. This makes the frozenset contain 14 tools. The name must match the MCP tool name exactly (the `name=` argument in the `@mcp.tool()` decorator).

### 2. Add `_preview_explore` builder function in `src/godotiq/license.py`

Define the function after the existing preview builders (before the `_PREVIEW_BUILDERS` dict). The function signature and behavior:

```python
def _preview_explore(r: dict) -> tuple[dict, list[str], str]:
    """Preview for Community users calling godotiq_explore."""
```

The function builds three return values:

**Preview dict**: Extract summary statistics from the full result. Keys to include:
- `"areas_found"` sourced from `r.get("areas_inspected", 0)`
- `"positions_calculated"` sourced from `r.get("total_screenshots", 0)`
- `"total_nodes"` sourced from `r.get("total_nodes", 0)`

**Locked sections list**: `["screenshots", "visual inspection data"]`

**Message string**: Format as `f"Found {areas} areas with {nodes} nodes. Visual inspection requires Pro."` where `areas` = `r.get("areas_inspected", 0)` and `nodes` = `r.get("total_nodes", 0)`.

All keys accessed via `.get()` with defaults so the function degrades gracefully when called with an empty dict (this is tested by the existing `test_builder_handles_empty_result` parametrized test).

### 3. Register in `_PREVIEW_BUILDERS` dict in `src/godotiq/license.py`

Add the entry `"godotiq_explore": _preview_explore` to the `_PREVIEW_BUILDERS` dictionary. Without this registration, Community users would get the generic fallback message instead of the rich preview showing area and node counts.

### 4. Add import in `src/godotiq/tools/bridge/__init__.py`

At the top of the file, alongside the other bridge tool imports, add:

```python
from godotiq.tools.bridge.explore import explore as _explore
```

Also add the `gate_pro` import:

```python
from godotiq.license import gate_pro
```

### 5. Add `godotiq_explore` wrapper function in `src/godotiq/tools/bridge/__init__.py`

The wrapper follows the exact same pattern as `godotiq_screenshot`, `godotiq_input`, and other bridge tool wrappers. Key characteristics:

**Decorator and annotations**:
```python
@mcp.tool(
    name="godotiq_explore",
    annotations={
        "readOnlyHint": True,
        "destructiveHint": False,
        "idempotentHint": False,
        "openWorldHint": True,
    },
)
```

- `readOnlyHint: True` -- explore creates a temporary drone camera but restores original state afterward
- `idempotentHint: False` -- concurrent calls would conflict (both try to create `GodotIQ_DroneCam`)
- `openWorldHint: True` -- communicates with the running game via WebSocket

**Function signature**:
```python
async def godotiq_explore(
    scene: str = "",
    mode: str = "tour",
    positions: list[dict] | None = None,
    max_areas: int = 5,
    screenshots_per_area: int = 1,
    scale: float = 0.5,
    quality: float = 0.6,
    fov: float = 70.0,
    eye_height: float = 2.5,
    ctx: Context = None,
) -> dict:
    """Autonomous visual inspection of the running game."""
```

Note: No `detail` parameter. The output contains base64 images; character-based truncation would corrupt the data. This is intentionally different from other tools.

**Body logic**:
1. Extract the `GodotIQSession` from `ctx.request_context.lifespan_context["session"]`. If `ctx` is None or session is not available, return an error dict.
2. Call `_explore(...)` inside a try/except block, passing all parameters plus the session and a bridge-getter reference.
3. Handle bridge exceptions (`BridgeConnectionError`, `BridgeTimeoutError`, `BridgeError`) following the standard pattern used by all other bridge wrappers (return error dict with hint).
4. Apply `gate_pro("godotiq_explore", result)` on the result before returning.

The `gate_pro()` call happens AFTER the explore function returns. For Community users in tour mode, the clustering analysis and scene parsing run fully (demonstrating value), then the result gets wrapped in the preview response. Screenshots (the expensive part) are also captured -- the gating is on the response, not the computation. This matches how all other PRO tools work: the full analysis runs, then the result is gated.

**Error handling pattern** (matches existing wrappers exactly):
```python
try:
    result = await _explore(...)
    return gate_pro("godotiq_explore", result)
except BridgeConnectionError as e:
    return {"error": str(e), "hint": "Enable the GodotIQ addon in Godot editor and ensure it is running."}
except BridgeTimeoutError as e:
    return {"error": str(e), "hint": "The game may not be running or the operation timed out."}
except BridgeError as e:
    return {"error": f"[{e.code}] {e.error_message}"}
except Exception as e:
    return {"error": f"Unexpected error: {e}"}
```

Note that error dicts (containing `"error"` key) pass through `gate_pro()` ungated -- this is built into `gate_pro()` already. However, exceptions raised by the explore function bypass `gate_pro()` entirely because they are caught in the except blocks. This is the correct behavior: Community users should see connection/timeout errors so they can fix their setup.

### 6. Docstring for the wrapper

The docstring should describe: what the tool does (drone camera, automated visual inspection), the two modes (tour for automatic scene survey, inspect for specific positions), key parameters, and when to use it. Keep it concise -- the system prompt (updated in section 08) provides detailed usage guidance.

---

## Verification Checklist

After implementation, confirm:

1. `"godotiq_explore"` appears in `PRO_TOOLS` (count should be 14)
2. `_preview_explore` function exists and returns `(dict, list[str], str)`
3. `"godotiq_explore": _preview_explore` is in `_PREVIEW_BUILDERS`
4. `_MOCK_RESULTS` in `tests/test_license.py` includes a `"godotiq_explore"` entry
5. The `godotiq_explore` wrapper in `__init__.py` calls `gate_pro()` on the result
6. All existing parametrized tests in `test_license.py` still pass (they iterate `PRO_TOOLS`)
7. The explore-specific preview builder tests pass
8. Run `pytest tests/test_license.py -v` to confirm no regressions