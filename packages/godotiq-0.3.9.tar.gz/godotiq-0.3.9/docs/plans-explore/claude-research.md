# Research Findings: godotiq_explore Implementation

## 1. Codebase Architecture

### 1.1 Bridge Tool Registration Pattern

**Location:** `src/godotiq/tools/bridge/__init__.py`

All bridge tools follow this pattern:
- **Public wrapper** in `__init__.py` with `@mcp.tool()` decorator
- **Internal implementation** in `src/godotiq/tools/bridge/<tool_name>.py`
- Error handling wraps `BridgeConnectionError`, `BridgeTimeoutError`, `BridgeError`

```python
@mcp.tool(
    name="godotiq_<tool_name>",
    annotations={
        "readOnlyHint": bool,
        "destructiveHint": bool,
        "idempotentHint": bool,
        "openWorldHint": bool,  # True if requires game running
    },
)
async def godotiq_<tool_name>(
    param1: type = default,
    detail: str = "normal",
    ctx: Context = None,
) -> dict:
    try:
        return await _<name>(...)
    except BridgeConnectionError as e:
        return {"error": str(e), "hint": "Enable the GodotIQ addon..."}
    except BridgeTimeoutError as e:
        return {"error": str(e), "hint": "The operation timed out..."}
    except BridgeError as e:
        return {"error": f"[{e.code}] {e.error_message}"}
    except Exception as e:
        return {"error": f"Unexpected error: {e}"}
```

### 1.2 Session/WebSocket Communication

**Location:** `src/godotiq/bridge/`

```python
from godotiq.bridge.session import get_bridge
from godotiq.bridge.connection import BridgeConnectionError, BridgeTimeoutError, BridgeError

bridge = await get_bridge()  # Lazy-init singleton
result = await bridge.request("method_name", params={...}, timeout=10.0)
```

- **Wire format request:** `{"id": "1", "method": "screenshot", "params": {...}}`
- **Wire format response (success):** `{"id": "1", "status": "ok", "result": {...}}`
- **Wire format response (error):** `{"id": "1", "status": "error", "error": {"code": "...", "message": "..."}}`
- **Sequential calls:** Just call `bridge.request()` multiple times — it handles sequencing internally
- **Timeouts:** Configurable in `src/godotiq/bridge/protocol.py::TOOL_TIMEOUTS`

### 1.3 GDScript Addon Architecture

**Server (editor-side):** `godot-addon/addons/godotiq/godotiq_server.gd`
**Runtime (game-side):** `godot-addon/addons/godotiq/godotiq_runtime.gd`

#### Handler Dispatch (server.gd, lines 269-318)
```gdscript
func _dispatch(peer_id: int, id: String, method: String, params: Dictionary) -> void:
    match method:
        "screenshot":
            _handle_game_forward(peer_id, id, "godotiq:screenshot", params, SCREENSHOT_TIMEOUT_MS)
        "scene_tree":
            _handle_scene_tree(peer_id, id, params)
        _:
            _send_error(peer_id, id, "UNKNOWN_METHOD", "Unknown method: %s" % method)
```

#### Response Functions
```gdscript
func send_response(peer_id: int, id: String, result: Dictionary) -> void:
    result["_editor_state"] = _get_editor_state()
    var msg := JSON.stringify({"id": id, "status": "ok", "result": result})
    _send_text(peer_id, msg)

func _send_error(peer_id: int, id: String, code: String, message: String) -> void:
    var msg := JSON.stringify({
        "id": id, "status": "error",
        "error": {"code": code, "message": message},
        "_editor_state": _get_editor_state(),
    })
    _send_text(peer_id, msg)
```

#### Game-Forward IPC Pattern
For game-side operations (screenshot, input), the server forwards via EditorDebugger:
```gdscript
_handle_game_forward(peer_id, id, "godotiq:screenshot", params, SCREENSHOT_TIMEOUT_MS)
```
Runtime receives via `_on_debugger_message()` and responds with:
```gdscript
EngineDebugger.send_message("godotiq:screenshot_result", [data...])
```

**Key insight:** `explore_camera` must be game-forwarded since it modifies the GAME's camera, not the editor's. Follow the same pattern as screenshot/input.

### 1.4 PRO Tool Licensing

**File:** `src/godotiq/license.py`

```python
PRO_TOOLS: frozenset[str] = frozenset({
    "godotiq_project_summary", "godotiq_file_context", "godotiq_dependency_graph",
    "godotiq_validate", "godotiq_signal_map", "godotiq_trace_flow",
    "godotiq_impact_check", "godotiq_animation_audit", "godotiq_asset_registry",
    "godotiq_scene_map", "godotiq_spatial_audit", "godotiq_suggest_scale",
    "godotiq_placement",
})
```

#### gate_pro() Pattern
```python
def gate_pro(tool_name: str, result: dict) -> dict:
    if tool_name not in PRO_TOOLS: return result
    if is_pro(): return result
    if "error" in result: return result
    builder = _PREVIEW_BUILDERS.get(tool_name)
    preview, locked, message = builder(result)
    return {"tier": "community", "tool": tool_name, "preview": preview,
            "locked_sections": locked, "message": message, "upgrade": "godotiq.com/pro"}
```

#### Preview Builder Pattern
```python
def _preview_<tool>(r: dict) -> tuple[dict, list[str], str]:
    preview = {"field1": r.get("field1"), ...}
    locked = ["full details", "advanced analysis"]
    message = "Showing summary. Full details require Pro."
    return preview, locked, message
```

### 1.5 Scene Map Tool (Node Positions)

**Location:** `src/godotiq/tools/spatial/__init__.py`

Returns nodes with world-space positions from .tscn files:
```python
def _build_scene_map(session: GodotIQSession, res_path: str, focus: str = "", radius: float = 10.0) -> dict:
    scene = session.get_scene(res_path)
    resolved = resolve_scene(scene, session.project_root)
    world_nodes = calculate_world_transforms(resolved)
    return {"scene": res_path, "total_nodes": len(world_nodes),
            "nodes": [_node_to_normal(wn) for wn in world_nodes]}
```

Node format includes `"position": list(wn.world_position)` — a list of 3 floats.

### 1.6 Testing Patterns

```python
# Bridge tool mocking
from unittest.mock import AsyncMock, patch

async def test_bridge_tool():
    mock_bridge = AsyncMock()
    mock_bridge.request.return_value = {"result_field": "value"}
    with patch("godotiq.tools.bridge.<module>.get_bridge", return_value=mock_bridge):
        result = await tool_function(...)
    assert result["field"] == "value"

# Sequential calls via side_effect
mock_bridge.request.side_effect = [
    {"game_running": True},   # First call
    {"results": [...]},       # Second call
]
```

### 1.7 Output Limit / Detail Level

Most tools support `detail: str = "normal"` with `apply_output_limit(result, detail)`. Character limits: brief=2000, normal=10000, full=None.

---

## 2. Godot Camera3D API Patterns (Web Research)

### Creating Temporary Cameras
- `Camera3D.new()` then `add_child()` then `make_current()`
- Default FOV is 75.0 degrees (we'll use custom 70.0)
- Must be in scene tree before `make_current()` works

### Camera Switching
- `make_current()` sets camera as active for nearest ancestor Viewport
- Only one Camera3D can be current per viewport
- `get_viewport().get_camera_3d()` returns current active camera (or null)

### Cleanup Order (Critical)
```gdscript
# CORRECT: Restore first, then free
original_camera.make_current()
temp_camera.queue_free()
```
If you `queue_free()` the current camera first, the viewport loses its camera for one frame.

### look_at() Edge Case
`look_at()` **fails** when target is directly above/below (direction parallel to UP vector). Workaround:
```gdscript
var direction = (target - camera.global_position).normalized()
if abs(direction.dot(Vector3.UP)) > 0.99:
    camera.look_at(target, Vector3.FORWARD)
else:
    camera.look_at(target, Vector3.UP)
```

### is_instance_valid() Check
Always validate stored camera references before restoring:
```gdscript
if is_instance_valid(original_camera):
    original_camera.make_current()
```

---

## 3. Spatial Clustering for 3D Scenes (Web Research)

### Algorithm Choice: Simple Greedy Distance-Based Clustering

**Recommendation:** Simple greedy/union-find clustering is ideal because:
- No external dependencies (no scipy/sklearn)
- Single intuitive parameter (distance threshold)
- Every point assigned to a cluster (no noise concept)
- O(n^2) is fine for 100-1000 nodes (~1-100ms)
- Deterministic and easy to debug

### Distance Threshold Selection
- For typical Godot scenes (1 unit = 1 meter), room-sized clusters: 10-20 units
- Adaptive approach: median nearest-neighbor distance * 3-5x multiplier
- User override option with sensible default (15.0 in the spec)

### Camera Position Calculation
- Compute cluster centroid and bounding sphere radius
- Camera distance = `padded_radius / sin(fov/2)` with 20% padding
- Overview position: elevated at ~45° angle from centroid
- Cardinal positions: at eye height around the perimeter

---

## 4. Architecture Decision Summary

1. **explore_camera** handler must live in **runtime** (game-side), forwarded via `_handle_game_forward()` — same as screenshot/input
2. **Python tool** uses `get_bridge()` and `bridge.request()` for sequential WebSocket calls
3. **Scene data** comes from `_build_scene_map()` via filesystem parsing (no game needed)
4. **PRO gating** follows existing `gate_pro()` + preview builder pattern
5. **Clustering** uses simple greedy O(n^2) approach with 15.0 default threshold
6. **look_at() safety** needs parallel-vector guard for overview positions
7. **Camera cleanup** must restore original before queue_free() on drone
