# Opus Review

**Model:** claude-opus-4
**Generated:** 2026-03-12T17:30:00Z

---

## Overall Assessment

The plan is well-structured, clearly scoped, and addresses the core packaging requirements competently. The research is thorough and the risk table is realistic. There are several significant issues that should be addressed before implementation.

## Critical Issues

### 1. cli.py importing server.py triggers full tool registration on every CLI call
`server.py` performs side-effectful imports at module scope (registering all 35 MCP tools). If `cli.py` imports `server.main` at top level, then `godotiq install-addon` will needlessly load all parsers, bridge, and tool modules.
**Fix:** Lazy-import `server.main` inside the function body. install-addon path should never touch server.py.

### 2. `__main__.py` change interacts with sys.modules hack
`server.py` line 61 has a `sys.modules.setdefault` hack for double-import. After the change, `python -m godotiq` loads `__main__.py` → `cli_main()` → `server.main()`, so server.py is always loaded under its canonical name. The hack becomes dead code.
**Fix:** Document this, verify in tests, consider removing the hack.

### 3. Hardcoded version in godotiq_ping
`server.py` has `"version": "0.1.0"` hardcoded in the ping tool. This will drift.
**Fix:** Change to use `from godotiq import __version__` and return `__version__`.

## Significant Concerns

### 4. .gitkeep exclusion not configured
Plan says "exclude .gitkeep" but force-include maps entire directories. Either add exclude rule or accept it ships (harmless).

### 5. No --version flag
Standard CLI expectation. Trivial: `parser.add_argument("--version", action="version", version=__version__)`

### 6. No --dry-run for install-addon
install-addon overwrites without preview. Should have --dry-run at minimum.

### 7. README tool count (32 vs 35)
README says 32 tools in multiple places, actual count is 35.

## Minor Issues

### 8. Prompt v2 file unused
`godot_development_prompt_v2.md` exists but no code references it. Clarify intent.

### 9. No sdist verification
Plan checks wheel but not sdist. Should verify both.

### 10. install-addon should call Path.resolve()
Path traversal safety. Call resolve() on target directory.

### 11. Consider GODOTIQ_PROJECT_ROOT fallback for install-addon
If no path arg given, could fall back to the env var.

## Summary Table

| Priority | Issue | Action |
|----------|-------|--------|
| Critical | Lazy-import server.main in cli.py | Rewrite CLI imports |
| Critical | Hardcoded version in godotiq_ping | Use __version__ |
| Critical | sys.modules hack interaction | Document + verify |
| High | No --version flag | Add to argparse |
| High | .gitkeep exclusion | Configure or accept |
| Medium | No --dry-run | Add flag |
| Medium | README tool count | Fix 32→35 |
| Low | Prompt v2 unused | Clarify |
| Low | No sdist verification | Add check |
| Low | Path.resolve() | Add safety |
