# GodotIQ PyPI Distribution Spec

## Goal
A user runs `pip install godotiq` and gets a working MCP server with all 35 tools + the Godot addon files included.

## Requirements

1. The package must be installable via pip and runnable via `python -m godotiq` or an entry point command
2. The Godot addon files (`addons/godotiq/*.gd` + `plugin.cfg` + `godotiq_claude_rules.md`) must ship inside the package so users can copy them to their Godot project
3. All dependencies must be correctly declared (scan imports across the entire codebase)
4. The `.mcp.json` config for MCP clients should use: `{"command": "uvx", "args": ["godotiq"], "env": {"GODOTIQ_PROJECT_ROOT": "/path/to/godot/project"}}`
5. Version in `__init__.py`: `0.1.0`
6. License: MIT
7. Build must produce a working wheel: `python -m build`
8. After install, verify: the server starts, tools register, ping responds
9. All 1128 tests must still pass
10. Do NOT upload to PyPI — just verify it builds and installs locally

## Key Questions to Figure Out in Planning

- What's the current entry point? How does the server start?
- What are ALL the runtime dependencies? (scan every import)
- How to include the addon files as package_data?
- Does the MCP prompt file (`godot_development.md`) need to ship in the package?
- Is there a `__main__.py` for `python -m godotiq`?
