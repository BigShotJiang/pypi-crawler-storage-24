# Review Integration Notes

## Integrating

### Critical #1: Lazy-import server.main in cli.py
**Integrating.** This is a real footgun. The serve subcommand will do `from godotiq.server import main; main()` inside the function body, not at module scope. The install-addon path stays lightweight.

### Critical #3: Hardcoded version in godotiq_ping
**Integrating.** Will add `server.py` to the file change list. The ping tool will use `__version__` from the package.

### Critical #2: sys.modules hack
**Integrating.** Will document that the hack becomes dead code after the change. Will verify in tests but NOT remove it — removal is a separate cleanup task to avoid scope creep.

### High #5: --version flag
**Integrating.** Trivial to add. Standard CLI expectation.

### Medium #6: --dry-run for install-addon
**Integrating.** Good UX. Will add `--dry-run` flag that lists what would be copied without actually copying.

### Medium #7: README tool count
**Integrating.** Will fix 32→actual count during README update.

### Low #10: Path.resolve() safety
**Integrating.** Good practice. Will resolve the target path before operations.

## NOT Integrating

### High #4: .gitkeep exclusion
**Not integrating as explicit config.** A .gitkeep file in the wheel is completely harmless (0 bytes, no effect). Removing the claim from the plan text instead. Not worth adding config complexity.

### Low #8: Prompt v2 unused
**Not integrating.** The v2 file exists and will ship in the wheel since it's inside src/godotiq/prompts/. Whether it's loaded in code is irrelevant to this packaging sprint. Not worth investigating now.

### Low #9: sdist verification
**Not integrating.** The wheel is what pip installs. sdist verification is nice-to-have but adds zero value for a package that isn't being uploaded to PyPI yet. When we do publish, we'll verify the sdist then.

### Low #11: GODOTIQ_PROJECT_ROOT fallback
**Not integrating.** This adds implicit behavior. The user spec explicitly shows `godotiq install-addon /path/to/project` with an explicit path. Env var fallback is scope creep.
