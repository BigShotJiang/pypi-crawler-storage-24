diff --git a/pyproject.toml b/pyproject.toml
index c0671fb..df5c1c1 100644
--- a/pyproject.toml
+++ b/pyproject.toml
@@ -10,12 +10,36 @@ readme = "README.md"
 license = "MIT"
 requires-python = ">=3.10"
 dependencies = ["mcp>=1.0.0", "websockets>=14.0"]
+authors = [
+    { name = "Salvatore Farruggio", email = "coolvolve.info@gmail.com" },
+]
+keywords = ["godot", "mcp", "game-development", "ai", "godot-engine"]
+classifiers = [
+    "Development Status :: 4 - Beta",
+    "Programming Language :: Python :: 3.10",
+    "Programming Language :: Python :: 3.11",
+    "Programming Language :: Python :: 3.12",
+    "License :: OSI Approved :: MIT License",
+    "Topic :: Games/Entertainment",
+    "Topic :: Software Development :: Libraries",
+]
 
 [project.optional-dependencies]
-dev = ["pytest>=7.0", "pytest-asyncio>=0.21"]
+dev = ["pytest>=7.0", "pytest-asyncio>=0.21", "build"]
 
 [project.scripts]
-godotiq = "godotiq.server:main"
+godotiq = "godotiq.cli:cli_main"
+
+[project.urls]
+Homepage = "https://github.com/godotiq/godotiq"
+Repository = "https://github.com/godotiq/godotiq"
+Issues = "https://github.com/godotiq/godotiq/issues"
+
+[tool.hatch.build.targets.wheel]
+packages = ["src/godotiq"]
+
+[tool.hatch.build.targets.wheel.force-include]
+"godot-addon/addons/godotiq" = "godotiq/addon"
 
 [tool.pytest.ini_options]
 testpaths = ["tests"]
diff --git a/src/godotiq/addon/__init__.py b/src/godotiq/addon/__init__.py
new file mode 100644
index 0000000..d4d21a6
--- /dev/null
+++ b/src/godotiq/addon/__init__.py
@@ -0,0 +1,5 @@
+"""GodotIQ Godot editor addon — package data anchor.
+
+This package's directory contains the Godot addon files (plugin.cfg, *.gd)
+bundled via hatchling force-include. Use Path(__file__).parent to locate them.
+"""
diff --git a/tests/test_packaging.py b/tests/test_packaging.py
new file mode 100644
index 0000000..c4dd73c
--- /dev/null
+++ b/tests/test_packaging.py
@@ -0,0 +1,39 @@
+"""Tests for packaging configuration — addon package data path resolution."""
+
+from pathlib import Path
+
+import pytest
+
+
+def test_addon_package_importable():
+    """godotiq.addon is importable as a Python package."""
+    import godotiq.addon
+    assert godotiq.addon is not None
+
+
+def test_addon_directory_is_real_path():
+    """The addon __init__.py resolves to a real filesystem directory."""
+    import godotiq.addon
+    addon_dir = Path(godotiq.addon.__file__).parent
+    assert addon_dir.is_dir()
+
+
+def _addon_dir() -> Path:
+    import godotiq.addon
+    return Path(godotiq.addon.__file__).parent
+
+
+def test_addon_contains_plugin_cfg():
+    """Addon directory contains plugin.cfg (requires force-include via wheel install)."""
+    plugin_cfg = _addon_dir() / "plugin.cfg"
+    if not plugin_cfg.exists():
+        pytest.skip("plugin.cfg not present — verified during wheel build (section-05)")
+    assert plugin_cfg.exists()
+
+
+def test_addon_contains_gd_files():
+    """Addon directory contains at least 5 .gd files (requires force-include via wheel install)."""
+    gd_files = list(_addon_dir().glob("*.gd"))
+    if len(gd_files) == 0:
+        pytest.skip(".gd files not present — verified during wheel build (section-05)")
+    assert len(gd_files) >= 5, f"Expected >= 5 .gd files, found {len(gd_files)}: {gd_files}"
