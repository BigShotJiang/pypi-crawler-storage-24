# Section 04 Code Review Interview

## Triage Summary

| # | Severity | Issue | Action |
|---|----------|-------|--------|
| 1 | HIGH | Unguarded iterdir() on possibly missing dir | Auto-fix: added is_dir() guard |
| 2 | HIGH | No error on zero addon files | Auto-fix: added manifest empty check |
| 3 | MEDIUM | Missing expanduser() | Auto-fix: added expanduser() |
| 4 | MEDIUM | Conditional test assertion | Auto-fix: made unconditional content length check |
| 5 | MEDIUM | Rules silently skipped | Let go — always exists in practice |
| 6 | LOW | shutil import location | Let go — inside function is fine |
| 7 | MEDIUM | Fragile fallback path | Let go — expected for editable installs |
| 8-11 | LOW | Various coverage gaps | Let go — not worth complexity |

## Auto-fixes Applied

1. Added `addon_src.is_dir()` guard before `iterdir()` call
2. Added check: if manifest is empty after iterating, exit with error
3. Added `.expanduser()` before `.resolve()` for tilde expansion
4. Changed conditional assertion to unconditional content length check
