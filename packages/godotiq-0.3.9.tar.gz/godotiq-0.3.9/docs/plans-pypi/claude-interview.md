# Interview Transcript — PyPI Distribution

## Q1: How should users get the Godot addon files into their project?
**Answer:** CLI command. Add a `godotiq install-addon` subcommand that copies .gd files + plugin.cfg into the target Godot project's addons/ directory.

## Q2: Where is godotiq_claude_rules.md?
**Answer:** It's the `godot_development.md` prompt file, but it's not only for Claude — it's for all AI agents coding with Godot. It must be universal (not Claude-specific in naming).

## Q3: What should the project URLs point to?
**Answer:** `github.com/godotiq/godotiq` (dedicated org).

## Q4: Should install-addon also copy the rules file?
**Answer:** Yes, copy as `GODOTIQ_RULES.md` to the Godot project root. The install-addon command copies addon files to `addons/godotiq/` AND the rules file to the project root.

## Q5: Version strategy for __init__.py?
**Answer:** Dynamic from `importlib.metadata.version('godotiq')`. Single source of truth in pyproject.toml.

## Q6: Package author for PyPI?
**Answer:** Salvatore Farruggio, email: coolvolve.info@gmail.com

## Q7: CLI design — subcommands vs separate entry points?
**Answer (clarified):** The user initially didn't realize the MCP server is spawned by AI clients (not Godot). After explanation:
- `godotiq` with no args = starts MCP server (this is what AI clients call via `.mcp.json`)
- `godotiq install-addon /path` = copies addon files + GODOTIQ_RULES.md to a Godot project
- Users never type `godotiq` manually — AI clients do it

## Q8: Should README be updated?
**Answer:** Yes, update README in this sprint with pip install instructions, uvx config, and install-addon usage.

## Q9: uvx alias?
**Answer:** Only `uvx godotiq` — no alternate aliases. GDAI is a competitor and must NOT be mentioned in the project.

## Q10: Author email?
**Answer:** coolvolve.info@gmail.com
