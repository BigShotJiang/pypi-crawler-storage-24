# GodotIQ PyPI Distribution — TDD Plan

Testing framework: pytest with pytest-asyncio. Tests in `tests/` directory. `asyncio_mode = "auto"`.

Existing conventions: fixtures via `monkeypatch`, `tmp_path` for temp dirs. Test files: `tests/test_*.py`.

---

## 1. pyproject.toml + Build Configuration

No unit tests. Verified by building the wheel and inspecting contents (integration test in verification section).

---

## 2. addon/__init__.py (Package Data Path Resolution)

```python
# Test: godotiq.addon package is importable
# Test: addon directory contains plugin.cfg
# Test: addon directory contains at least 5 .gd files
# Test: addon directory path resolves to a real filesystem directory
```

---

## 3. __init__.py — Dynamic __version__

```python
# Test: __version__ is a string
# Test: __version__ matches "0.1.0" (or current version)
# Test: __version__ is importable from godotiq top-level
```

---

## 4. server.py — godotiq_ping Uses Dynamic Version

```python
# Test: godotiq_ping response includes "version" key
# Test: godotiq_ping version matches __version__ from godotiq package
# Test: godotiq_ping version is not hardcoded "0.1.0" (read from module)
```

---

## 5. cli.py — CLI Argument Parsing

```python
# Test: no args defaults to serve action (does not crash)
# Test: --version flag prints version string and exits
# Test: --help flag prints help text and exits
# Test: install-addon subcommand requires a path argument
# Test: install-addon with valid path is accepted
# Test: install-addon --dry-run flag is recognized
# Test: unknown subcommand shows error
```

---

## 6. cli.py — install-addon File Copying

```python
# Test: copies all .gd files to target/addons/godotiq/
# Test: copies plugin.cfg to target/addons/godotiq/
# Test: copies GODOTIQ_RULES.md to target root (from godot_development.md)
# Test: creates addons/godotiq/ directory if missing
# Test: overwrites existing files with warning
# Test: prints summary of copied files
# Test: distinguishes "added" vs "updated" in output
```

---

## 7. cli.py — install-addon Validation

```python
# Test: fails with clear error if target dir does not exist
# Test: fails with clear error if target has no project.godot
# Test: resolves path (handles relative paths, ~, symlinks)
# Test: --dry-run lists files but does not create/copy any
# Test: --dry-run still validates target dir exists
```

---

## 8. cli.py — Lazy Import Behavior

```python
# Test: importing cli module does NOT import server module
# Test: importing cli module does NOT trigger MCP tool registration
# Test: install-addon code path does NOT import server module
```

---

## 9. __main__.py — Module Entry Point

```python
# Test: python -m godotiq --version prints version
# Test: python -m godotiq --help works
```

---

## 10. Build + Wheel Verification

```python
# Test: wheel contains godotiq/addon/plugin.cfg
# Test: wheel contains godotiq/addon/*.gd files (at least 5)
# Test: wheel contains godotiq/prompts/godot_development.md
# Test: wheel does NOT contain tests/ directory
# Test: wheel does NOT contain docs/ directory
```

(These may be integration tests run manually rather than in pytest, depending on build tooling availability in CI.)

---

## 11. README

No unit tests. Verified by manual review.
