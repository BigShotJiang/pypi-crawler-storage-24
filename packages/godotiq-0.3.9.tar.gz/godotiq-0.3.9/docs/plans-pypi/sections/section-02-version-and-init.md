Good. Now I have all the context I need. Let me produce the section content.

# Section 02 — Version and Init

## Overview

This section adds a dynamic `__version__` attribute to the `godotiq` package and updates the `godotiq_ping` MCP tool to use it instead of a hardcoded string. After this work, the version is sourced from a single place (`pyproject.toml`) and exposed everywhere consistently.

**Depends on:** section-01-packaging-config (pyproject.toml must have correct metadata and `src/godotiq/addon/__init__.py` must exist so the package is installable).

**Blocks:** section-03-cli-module (needs `__version__` for `--version` flag), section-05-build-verify.

---

## Files to Modify

| File | Action |
|------|--------|
| `src/godotiq/__init__.py` | Modify — add `_get_version()` helper and `__version__` attribute |
| `src/godotiq/server.py` | Modify — replace hardcoded `"0.1.0"` in `godotiq_ping` with `__version__` |
| `tests/test_server.py` | Modify — update ping assertion to use dynamic version |
| `tests/test_scaffolding_int.py` | Modify — update ping assertion to use dynamic version |
| `tests/test_version.py` | **Create** — new test file for `__version__` and ping version behavior |

---

## Tests (Write First)

### New file: `tests/test_version.py`

This file tests two things: (a) the `__version__` attribute itself, and (b) that `godotiq_ping` returns the dynamic version.

```python
"""Tests for dynamic __version__ and version propagation to godotiq_ping."""

import json
import re

import pytest


class TestVersionAttribute:
    """Verify __version__ is accessible, correct type, and plausible format."""

    def test_version_is_importable_from_top_level():
        """__version__ can be imported directly from godotiq."""
        from godotiq import __version__
        assert __version__ is not None

    def test_version_is_a_string():
        """__version__ must be a str."""
        from godotiq import __version__
        assert isinstance(__version__, str)

    def test_version_matches_expected():
        """__version__ should equal the version in pyproject.toml (currently 0.1.0)."""
        from godotiq import __version__
        assert __version__ == "0.1.0"

    def test_version_looks_like_semver_or_dev():
        """__version__ should be a semver string or the dev fallback."""
        from godotiq import __version__
        # Accepts X.Y.Z, X.Y.Z.devN, X.Y.ZaN, or the 0.0.0-dev fallback
        assert re.match(r"^\d+\.\d+\.\d+", __version__) or __version__ == "0.0.0-dev"


class TestPingUsesDynamicVersion:
    """Verify godotiq_ping returns __version__ rather than a hardcoded string."""

    @pytest.mark.asyncio
    async def test_ping_version_matches_package_version():
        """The version in godotiq_ping response must equal godotiq.__version__."""
        from godotiq import __version__
        from godotiq.server import mcp

        result = await mcp.call_tool("godotiq_ping", {})
        payload = json.loads(result[0].text)
        assert payload["version"] == __version__

    @pytest.mark.asyncio
    async def test_ping_version_key_exists():
        """godotiq_ping response must include a 'version' key."""
        from godotiq.server import mcp

        result = await mcp.call_tool("godotiq_ping", {})
        payload = json.loads(result[0].text)
        assert "version" in payload
```

### Update existing tests that assert hardcoded `"0.1.0"`

Two existing test files contain assertions like:

```python
assert payload == {"status": "ok", "version": "0.1.0"}
```

These must be updated to use the dynamic version so they do not break when the version number changes in the future.

**In `tests/test_server.py`, line 36** (class `TestPingTool`, method `test_ping_returns_expected`): Change the assertion from comparing against a hardcoded dict to importing `__version__` and comparing against `{"status": "ok", "version": __version__}`.

**In `tests/test_scaffolding_int.py`, line 137** (class `TestMcpServerPingToolRegistered`, method `test_ac3_ping_tool_registered_and_returns_correct_response`): Same change — import `__version__` from `godotiq` and use it in the assertion instead of the hardcoded `"0.1.0"`.

---

## Implementation Details

### 1. Add `__version__` to `src/godotiq/__init__.py`

The current file contains only a docstring. Add a `_get_version()` helper that reads the version from package metadata, with a safe fallback for environments where the package is not formally installed.

**Strategy:** Use `importlib.metadata.version("godotiq")` from the standard library (available in Python 3.8+). This reads the version that Hatchling bakes into the package metadata from `pyproject.toml`, so the single source of truth is `pyproject.toml`'s `version = "0.1.0"`.

**Fallback:** If `importlib.metadata.PackageNotFoundError` is raised (for example, running from a raw source checkout without `pip install -e .`), fall back to the string `"0.0.0-dev"`.

The resulting `__init__.py` should look like:

```python
"""GodotIQ — The definitive MCP for AI-assisted Godot development."""

def _get_version() -> str:
    """Read version from package metadata (single source of truth: pyproject.toml)."""
    # ... use importlib.metadata.version("godotiq")
    # ... except PackageNotFoundError: return "0.0.0-dev"

__version__: str = _get_version()
```

Key points:
- The function is module-private (`_get_version`) since callers should use `__version__` directly.
- The `__version__` attribute is typed as `str` and assigned at module scope so it is available immediately on import.
- The `from __future__ import annotations` directive is NOT needed here (there are no forward references).
- The existing docstring at the top of the file must be preserved.

### 2. Update `godotiq_ping` in `src/godotiq/server.py`

Currently, line 80 reads:

```python
return {"status": "ok", "version": "0.1.0"}
```

Change this to import and use the dynamic version:

```python
from godotiq import __version__
# ...
return {"status": "ok", "version": __version__}
```

The import `from godotiq import __version__` should be placed with the other imports at the top of `server.py` (near line 6-8), NOT inside the `godotiq_ping` function body. Since `server.py` already imports from `godotiq.session` at the top level, importing from `godotiq` itself is fine and does not create a circular dependency -- `__init__.py` only uses `importlib.metadata`, which does not import any other `godotiq` module.

**Important:** Do NOT change anything else in `server.py`. The `sys.modules.setdefault` hack on line 61, the tool registrations, the lifespan context manager -- all must remain untouched.

---

## Verification Checklist

After implementation, confirm:

1. `python -c "from godotiq import __version__; print(__version__)"` prints `0.1.0`
2. `uv run pytest tests/test_version.py -v` passes all tests
3. `uv run pytest tests/test_server.py -v` passes (updated ping assertion)
4. `uv run pytest tests/test_scaffolding_int.py -v` passes (updated ping assertion)
5. `uv run pytest -v` -- full suite still passes (no regressions)

---

## Edge Cases and Notes

- **Editable installs:** `pip install -e .` (or `uv pip install -e .`) registers package metadata, so `importlib.metadata.version("godotiq")` works correctly. The `"0.0.0-dev"` fallback is only for truly uninstalled raw source execution.
- **Circular imports:** There is no risk. `__init__.py` imports only `importlib.metadata` (stdlib). `server.py` imports `__version__` from `__init__.py`. No cycle.
- **The `sys.modules.setdefault` hack in `server.py` (line 61):** This is unrelated to version handling. Do not modify or remove it. It exists to prevent double-import issues when running via `python -m godotiq.server`. Per the plan, it becomes a harmless no-op after the CLI refactor in section-03, but should not be touched in this section.

## Implementation Notes (Post-Build)

### Deviations from plan
- **Added fallback test**: Plan did not include test for `PackageNotFoundError` fallback path. Added `test_version_fallback_when_package_not_found` to cover the `"0.0.0-dev"` branch.
- **Fixed missing `self` params**: Plan's test template omitted `self` on class methods; implementation corrected this.

### Files created/modified
- `src/godotiq/__init__.py` — modified (added `_get_version()` + `__version__`)
- `src/godotiq/server.py` — modified (import `__version__`, use in `godotiq_ping`)
- `tests/test_version.py` — created (7 tests)
- `tests/test_server.py` — modified (dynamic version assertion)
- `tests/test_scaffolding_int.py` — modified (dynamic version assertion)

### Test results
- 1137 passed, 2 skipped (full suite, no regressions)