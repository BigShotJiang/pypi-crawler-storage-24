<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-packaging-config
section-02-version-and-init
section-03-cli-module
section-04-install-addon
section-05-build-verify
section-06-readme
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-packaging-config | - | 02, 03, 04, 05 | Yes |
| section-02-version-and-init | 01 | 03, 05 | No |
| section-03-cli-module | 02 | 04, 05 | No |
| section-04-install-addon | 03 | 05 | No |
| section-05-build-verify | 01, 02, 03, 04 | 06 | No |
| section-06-readme | 05 | - | No |

## Execution Order

1. section-01-packaging-config (no dependencies)
2. section-02-version-and-init (after 01)
3. section-03-cli-module (after 02)
4. section-04-install-addon (after 03)
5. section-05-build-verify (after all code changes)
6. section-06-readme (after build verification confirms everything works)

## Section Summaries

### section-01-packaging-config
Update `pyproject.toml` with full metadata (author, URLs, classifiers, keywords), hatchling `force-include` for addon files, entry point change to `godotiq.cli:cli_main`, and dev dependency additions. Create `src/godotiq/addon/__init__.py` as package data path anchor.

**Tests:** Verify `godotiq.addon` is importable and contains expected files.

### section-02-version-and-init
Add dynamic `__version__` to `src/godotiq/__init__.py` via `importlib.metadata`. Update `server.py` to use `__version__` in `godotiq_ping` tool instead of hardcoded string.

**Tests:** Verify `__version__` is accessible, is a string, matches expected value. Verify ping response uses dynamic version.

### section-03-cli-module
Create `src/godotiq/cli.py` with argparse-based CLI: default serve action (with lazy `server.main` import), `--version` flag, `--help`, and `install-addon` subcommand skeleton. Update `src/godotiq/__main__.py` to route through `cli_main()`.

**Tests:** Argument parsing tests (default=serve, --version, --help, install-addon recognition). Lazy import verification (importing cli does NOT import server).

### section-04-install-addon
Implement the `install-addon` subcommand logic in `cli.py`: path resolution and validation, file copying (addon files + GODOTIQ_RULES.md), `--dry-run` support, add/update distinction in output.

**Tests:** File copying correctness (all .gd, plugin.cfg, GODOTIQ_RULES.md). Validation errors (no dir, no project.godot). Dry-run creates no files. Overwrite behavior.

### section-05-build-verify
Build the wheel with `python -m build`, verify contents with `unzip -l`. Confirm addon files, prompt files, and all Python modules are present. Install in temp venv and verify server starts, tools register, `--version` works.

**Tests:** Integration verification (may be manual or scripted, not pytest).

### section-06-readme
Update README.md with installation section (pip install, uvx config, install-addon usage). Fix tool count references from 32 to 35.

**Tests:** No automated tests. Manual review.
