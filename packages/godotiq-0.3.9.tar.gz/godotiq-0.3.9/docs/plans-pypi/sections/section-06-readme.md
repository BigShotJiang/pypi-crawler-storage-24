# Section 06: README Update

## Overview

This section updates `README.md` with PyPI installation instructions, the new `install-addon` CLI usage, and corrects the tool count from 32 to 35 throughout the file. This is the final section in the implementation sequence and depends on all prior sections being complete.

## Dependencies

- **section-01-packaging-config**: Package installable via `pip install godotiq`
- **section-02-version-and-init**: `__version__` available
- **section-03-cli-module**: `godotiq --version` and `godotiq --help` work
- **section-04-install-addon**: `godotiq install-addon` functional
- **section-05-build-verify**: Build verified working

## Tests

Per the TDD plan: **No automated tests. Manual review only.**

## File to Modify

`/Users/salvatorefarruggio/Desktop/godotiq/README.md`

## Implementation Details

### 1. Fix tool count: 32 to 35

The README currently says "32 tools" in multiple places. The actual count is 35. Every occurrence of "32" referring to the tool count must be updated to "35":

- Intro paragraph: "32 tools across 9 categories" → "35 tools across 9 categories"
- Tool section heading: "### 32 Tools in 9 Categories" → "### 35 Tools in 9 Categories"
- Tool summary line: Recount the filesystem vs bridge split to sum to 35
- Claude Code note: "32 tools available" → "35 tools available"
- Architecture tree: "9 categories, 32 tools" → "9 categories, 35 tools"
- Comparison table: "GodotIQ (32 tools)" → "GodotIQ (35 tools)"

### 2. Rewrite the Setup section

Replace the git-clone workflow with PyPI-based installation.

**Subsection "### 1. Install GodotIQ"**

Two methods:
1. **Direct install**: `pip install godotiq`
2. **For AI clients (recommended)**: No manual install needed. Configure the MCP client to use `uvx` which auto-installs on first use.

**Subsection "### 2. Install the Godot Addon"**

Replace manual copy instructions with:

```bash
godotiq install-addon /path/to/your/godot/project
```

Explain what this does:
- Copies the GDScript addon files to `<project>/addons/godotiq/`
- Copies `GODOTIQ_RULES.md` to the project root (AI assistant rules for Godot development)
- Use `--dry-run` to preview what will be copied

Then mention: Enable the addon in Godot via Project Settings → Plugins → GodotIQ → Enable.

Keep the existing description of what the addon is (pure GDScript, ~500 lines, WebSocket server on port 6007).

**Subsection "### 3. Configure Your AI Client"**

Update the `.mcp.json` example to use `uvx`:

```json
{
  "mcpServers": {
    "godotiq": {
      "command": "uvx",
      "args": ["godotiq"],
      "env": {
        "GODOTIQ_PROJECT_ROOT": "/path/to/your/godot/project"
      }
    }
  }
}
```

Keep the instruction to launch Claude Code from the project directory.

**Subsection "### 4. (Optional) Project Configuration"**

Keep the existing `.godotiq.json` section as-is.

### 3. Update test stats

The README mentions "835+ automated tests" in two places. The current count is 1128+. Update both references to "1100+ automated tests" (or check exact count).

### 4. Update the Architecture section

- Change `tools/` comment from "9 categories, 32 tools" to "9 categories, 35 tools"
- Update `tests/` comment from "835+ automated tests" to current count

### 5. Keep everything else intact

The following sections remain unchanged (except tool count fixes):
- "What It Does" section
- "Key Capabilities No Other MCP Has" section
- The tool table (correct as-is; only the heading changes)
- "Token Optimization" section
- "Development" section (except test count)
- "Comparison" section (except tool count)
- "License" section

### 6. Summary of all changes

| Location | Current | New |
|----------|---------|-----|
| Intro paragraph | "32 tools across 9 categories" | "35 tools across 9 categories" |
| Tool section heading | "### 32 Tools in 9 Categories" | "### 35 Tools in 9 Categories" |
| Tool summary line | Numbers summing to 32 | Numbers summing to 35 |
| Setup section 1 | git clone + uv sync | `pip install godotiq` |
| Setup section 2 | Manual copy of addon dir | `godotiq install-addon <path>` |
| Setup section 3 | `.mcp.json` with `uv run --project` | `.mcp.json` with `uvx godotiq` |
| Claude Code note | "32 tools available" | "35 tools available" |
| Architecture tree | "9 categories, 32 tools" | "9 categories, 35 tools" |
| Architecture tree | "835+ automated tests" | Updated count |
| Test stats | "835+ automated tests" | Updated count |
| Comparison table | "GodotIQ (32 tools)" | "GodotIQ (35 tools)" |

### 7. Style guidance

- Keep the assertive, confident tone of the existing README
- Do not add badges, shields, or decorative elements
- Do not restructure sections beyond what is specified
- Keep code blocks using the same formatting (json, bash, plain text)
- The README should read naturally for someone discovering the project on PyPI
