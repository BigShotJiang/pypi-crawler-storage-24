# Integration Notes — Opus Review Feedback

## Changes Integrated

### Critical Issue #1: Logger as Enhancement, Not Foundation
**Integrating.** The reviewer is right — building primarily around Logger (Godot 4.5+) is risky. The plan will be restructured so `load() + can_instantiate() + reload()` is the **primary** path, and Logger adds line-number detail when available. No hard Godot 4.5 requirement.

### Critical Issue #3: Don't Instantiate PackedScene for Script Discovery
**Integrating.** Scene instantiation runs `_init()` and has side effects. Instead, use `PackedScene._bundled` property to extract script paths, or parse the .tscn directly. The codebase already has a TSCN parser. For the GDScript-side pre-run check, `_bundled` is the right approach since it's available in-engine.

### Critical Issue #4: Response Format — Use `_send_error` Consistently
**Integrating.** The plan had contradictory formats. Will standardize on `_send_error` for the pre-run check (consistent with existing patterns, Python bridge already handles `BridgeError`). The `check_errors` tool uses `send_response` since errors-found is a successful scan result, not a tool failure.

### Critical Issue #2: Async vs Sync _handle_run
**Integrating.** The pre-run check will be synchronous (no `await`). It uses `load() + can_instantiate()` which is synchronous. Cap at scene scripts + autoloads only (not full project scan). No yielding needed for the small number of scripts in a typical scene.

### Moderate Issue #5: Mutex Pattern
**Integrating.** Will add explicit documentation of lock/unlock pattern per operation.

### Moderate Issue #7: Autoload Discovery API
**Integrating.** Replace speculative `get_autoload_list()` with actual pattern: iterate `ProjectSettings.get_property_list()` matching `autoload/*`.

### Moderate Issue #8: Remove Unused `detail` Parameter
**Integrating.** Remove `detail` from `godotiq_check_errors` signature. The tool has no meaningful detail levels — errors are errors.

### Moderate Issue #9: Add Registration Tests + Edge Cases
**Integrating.** Add test for MCP tool registration, invalid scope, and empty project edge cases.

### Moderate Issue #10: Add `apply_output_limit`
**Integrating.** Call `apply_output_limit(result, detail)` on the check_errors result, consistent with all other bridge tools.

### Minor Issue #11: Exclude `.godot/` and Other Directories
**Integrating.** Add `.godot/`, `build/`, `export/` to exclusion list alongside `addons/`.

### Minor Issue #13: Default Scope Inconsistency
**Integrating.** Standardize on `"scene"` as default for both GDScript handler and Python tool.

### Minor Issue #15: Save Scene Before Pre-run Check
**Integrating.** Add `EditorInterface.save_all_open_scenes()` before the pre-run check to ensure disk matches editor state.

## Changes NOT Integrated

### Architectural Issue #17: Separate `script_errors` in `_editor_state`
**Not integrating.** Adding a new field to `_editor_state` would change the response format for ALL tools, requiring updates across the Python bridge. Too much scope creep for this sprint. The Logger will NOT write to `_recent_errors` — it only populates `_script_errors` which is read exclusively by `check_errors`.

### Architectural Issue #18: Extract to Separate `godotiq_error_checker.gd`
**Not integrating.** While the server file is large, extracting requires passing around peer_id, id, and send_response references. The added complexity and inter-file coupling isn't worth it for this sprint. Can be done as a separate refactor later.

### Minor Issue #12: Deduplication Logic
**Not integrating (already fine).** All unique (file, line, message) tuples should be kept. Multiple errors on the same line with different messages are distinct issues.

### Minor Issue #14: Prompt References Non-existent Tool
**Not integrating.** All sections will ship in the same commit. Not an issue.

### Minor Issue #16: Buffer Size
**Not integrating.** 50 is reasonable. Cascading errors from a broken base class are still useful diagnostic information. Can be increased later if needed.
