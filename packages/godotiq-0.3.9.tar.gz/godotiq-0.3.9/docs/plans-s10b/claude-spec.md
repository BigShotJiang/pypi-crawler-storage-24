# Sprint 10b Complete Specification: Script Error Detection + Real Gameplay Testing

## Overview

GodotIQ's AI agent currently has two critical blind spots:
1. **Cannot see GDScript compilation/semantic errors** — only runtime errors are captured
2. **Does not perform real gameplay testing** — just starts/stops the game without interacting

This sprint adds error detection infrastructure and improves the MCP prompt to enforce actual gameplay testing.

## Target: Godot 4.5+

Using the new `Logger` class available in Godot 4.5+ for comprehensive error interception.

---

## Feature 1: Script Error Detection

### 1.1 Standalone MCP Tool: `godotiq_check_errors`

A new tool that scans project scripts for compilation and semantic errors.

**Approach**: Use Godot 4.5+ `Logger` class to intercept all error output during a script reload cycle. For each `.gd` file, `load()` + `can_instantiate()` + `reload()` to trigger error detection, while the Logger captures the actual error messages.

**GDScript handler**: `_handle_check_errors` in `godotiq_server.gd`
- Scans `.gd` files via `EditorInterface.get_resource_filesystem()`
- For each script: `load(path)` → check `can_instantiate()` and `reload()` return
- Logger captures error details (file, line, message)
- Returns `{errors: [{file, line, error, type}], total: N}`

**Python tool**: `check_errors.py` in `src/godotiq/tools/bridge/`
- Calls bridge `check_errors` method
- Returns error array to MCP

### 1.2 Pre-run Script Check (Integrated in `_handle_run`)

Before starting the game, the server checks scripts that would actually run:
- Scripts referenced in the scene being played (scene tree)
- Autoload scripts registered in ProjectSettings

If errors are found → return them as an error response instead of starting the game.

**Scope**: Scene scripts + autoloads only (not all project scripts). This keeps the check fast.

### 1.3 Logger Integration in godotiq_server.gd

Register a Logger subclass when the server starts. This captures:
- Script parse errors
- Semantic errors (undefined identifiers, wrong types)
- Runtime push_error() calls

Errors are stored in the existing `_recent_errors` circular buffer with enhanced metadata (file, line, error type).

---

## Feature 2: MCP Prompt Improvements

### 2.1 Real Gameplay Testing Section

Replace the basic "Gameplay Test" step in the QA checklist with a comprehensive testing protocol:
- Start game and verify initial state
- Test EVERY interactive feature (buttons, placement, purchases)
- Wait for complete gameplay cycles (waves, rounds)
- Check for runtime errors during gameplay
- Stop and report results

### 2.2 Test-Driven Completion Section

Add a section emphasizing that "compiles" ≠ "works". The agent must test every player-facing feature during actual gameplay before considering work done.

### 2.3 Efficiency Rules Enhancement

Add "Act immediately" and "Maximum 2 paragraphs between tool calls" rules to prevent over-planning and verbose explanations.

### 2.4 Prompt File

Work with `godot_development_prompt_v2.md`. Rename to `godot_development.md` if appropriate. Review for missing features and adapt new sections to match existing tone and structure.

---

## Files to Modify

| File | Changes |
|------|---------|
| `godot-addon/addons/godotiq/godotiq_server.gd` | New `_handle_check_errors` handler, Logger integration, pre-run check in `_handle_run` |
| `src/godotiq/tools/bridge/check_errors.py` | New Python tool wrapper |
| `src/godotiq/tools/bridge/__init__.py` | Register `godotiq_check_errors` MCP tool |
| `src/godotiq/prompts/godot_development_prompt_v2.md` | Real Gameplay Testing, Test-Driven Completion, Act Don't Plan |

## Files NOT to Touch

- Parsers (tscn, gd, scene_resolver, project_index)
- Analysis tools (scene_map, dependency_graph)
- build_scene
- Existing tests

## Verification

```bash
pytest tests/ -v
```

Manual test:
1. Write a script with intentional error (e.g., `TONE_MAP_ACES`)
2. Call `godotiq_check_errors`
3. Verify error appears in response
4. Try `godotiq_run(action="play")` — should be blocked with error details
