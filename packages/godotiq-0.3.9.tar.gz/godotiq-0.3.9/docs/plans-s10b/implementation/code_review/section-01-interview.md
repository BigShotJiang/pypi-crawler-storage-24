# Section 01 Code Review Interview

## Auto-fixes Applied

1. **ERR_SCRIPT enum constant** — Replaced magic number `2` with `ERR_SCRIPT` enum constant in godotiq_logger.gd. Since the file extends Logger, the enum should be accessible.

2. **Deep copy in _get_script_errors** — Changed `.duplicate()` to `.duplicate(true)` for deep copy, ensuring returned dict entries are independent from internal buffer.

3. **Load failure warning** — Added `push_warning()` when Logger class exists but godotiq_logger.gd fails to load, aiding debugging.

## Let Go

- Constructor implicit reference (inherent to GDScript Callable)
- Mutex not exception-safe (GDScript has no try/finally)
- Dictionary reference semantics in append (local var goes out of scope)
- No .tres filter (intentional scope per plan)
