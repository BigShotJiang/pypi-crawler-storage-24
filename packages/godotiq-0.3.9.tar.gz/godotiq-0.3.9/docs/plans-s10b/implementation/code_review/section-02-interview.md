# Section 02 Code Review Interview

## User Decision
1. **Reentrancy guard** — User chose "Add a guard flag". Added `_checking_errors` bool flag that rejects concurrent requests with CHECK_IN_PROGRESS error.

## Auto-fixes Applied
2. **`lstrip("*")` → `trim_prefix("*")`** — lstrip strips character set, trim_prefix strips exact prefix string.
3. **Logger merge: enrich instead of append** — Logger entries now replace basic errors for the same file (detailed line/message instead of generic line-0 error).
4. **Always call `reload()`** — reload() is now called even when can_instantiate() is false, so Logger can capture detailed parse error info.
5. **Dedup key separator** — Changed from `:` to `|` to avoid collision with `res://` paths.

## Let Go
- Exclusion list depth (over-aggressive but harmless in practice)
- Autoload load() caching (rare edge case)
- Scope validation (plan accepts this as-is)
