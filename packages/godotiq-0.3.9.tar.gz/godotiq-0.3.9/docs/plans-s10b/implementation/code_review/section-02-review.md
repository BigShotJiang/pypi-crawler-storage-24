# Section 02 Code Review

## HIGH
1. **Reentrancy bug** — `_dispatch` not awaited, concurrent check_errors can clear Logger buffer mid-execution
2. **`lstrip("*")` vs `trim_prefix("*")`** — lstrip strips character set, not prefix

## MEDIUM
3. **Logger merge appends instead of enriching** — Plan says replace basic with detailed, code just appends and deduplicates (both remain)
4. **`reload()` skipped when `can_instantiate()` false** — Logger never captures parse error details
5. **Exclusion list over-aggressive** — Excludes any nested dir named "build"/"export", not just top-level
6. **Autoload load() uses cache** — Inconsistent with CACHE_MODE_IGNORE in check loop

## LOW
7. No scope validation for res:// paths
10. Dedup key format could theoretically collide
