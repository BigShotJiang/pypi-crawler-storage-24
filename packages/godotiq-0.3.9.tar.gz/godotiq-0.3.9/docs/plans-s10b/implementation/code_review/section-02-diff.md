diff --git a/godot-addon/addons/godotiq/godotiq_server.gd b/godot-addon/addons/godotiq/godotiq_server.gd
index 9baddf1..ab7efee 100644
--- a/godot-addon/addons/godotiq/godotiq_server.gd
+++ b/godot-addon/addons/godotiq/godotiq_server.gd
@@ -222,6 +222,8 @@ func _dispatch(peer_id: int, id: String, method: String, params: Dictionary) ->
 			_handle_camera(peer_id, id, params)
 		"build_scene":
 			_handle_build_scene(peer_id, id, params)
+		"check_errors":
+			_handle_check_errors(peer_id, id, params)
 		_:
 			_send_error(peer_id, id, "UNKNOWN_METHOD", "Unknown method: %s" % method)
 
@@ -1593,6 +1595,117 @@ func _send_text(peer_id: int, text: String) -> void:
 		ws.send_text(text)
 
 
+# --- check_errors ---
+
+func _handle_check_errors(peer_id: int, id: String, params: Dictionary) -> void:
+	var scope: String = params.get("scope", "scene")
+	if _has_logger:
+		_clear_script_errors()
+	# Collect script paths based on scope
+	var script_paths: Array[String] = []
+	if scope == "project":
+		var fs := EditorInterface.get_resource_filesystem().get_filesystem()
+		script_paths = _get_script_paths_recursive(fs)
+	elif scope == "scene":
+		var edited_root := EditorInterface.get_edited_scene_root()
+		script_paths = _get_scene_script_paths(edited_root)
+	else:
+		script_paths = [scope]  # Treat as a specific res:// path
+	# Script check loop
+	var errors: Array = []
+	var checked: int = 0
+	for i in script_paths.size():
+		var path: String = script_paths[i]
+		var res = ResourceLoader.load(path, "", ResourceLoader.CACHE_MODE_IGNORE)
+		if res == null:
+			errors.append({"file": path, "line": 0, "error": "Failed to load script"})
+		elif res is GDScript:
+			if not res.can_instantiate():
+				errors.append({"file": path, "line": 0, "error": "Script has parse errors (cannot instantiate)"})
+			else:
+				var reload_err = res.reload()
+				if reload_err != OK:
+					errors.append({"file": path, "line": 0, "error": "Script reload failed (error %d)" % reload_err})
+		checked += 1
+		if checked % 10 == 0:
+			await get_tree().process_frame
+	# Merge Logger entries for detailed line/message info
+	if _has_logger:
+		var logger_entries := _get_script_errors()
+		for entry in logger_entries:
+			errors.append({"file": entry.file, "line": entry.line, "error": entry.message})
+	# Deduplicate by file+line+message
+	var seen := {}
+	var deduped: Array = []
+	for err in errors:
+		var key := "%s:%d:%s" % [err.file, err.line, err.error]
+		if not seen.has(key):
+			seen[key] = true
+			deduped.append(err)
+	send_response(peer_id, id, {
+		"errors": deduped,
+		"total": deduped.size(),
+		"scripts_checked": checked,
+		"scope": scope,
+	})
+
+
+func _get_script_paths_recursive(dir: EditorFileSystemDirectory) -> Array[String]:
+	var result: Array[String] = []
+	if dir == null:
+		return result
+	var excluded := ["addons", ".godot", "build", "export"]
+	for i in dir.get_subdir_count():
+		var subdir := dir.get_subdir(i)
+		if subdir.get_name() in excluded:
+			continue
+		result.append_array(_get_script_paths_recursive(subdir))
+	for i in dir.get_file_count():
+		var file_path := dir.get_file_path(i)
+		if file_path.ends_with(".gd"):
+			result.append(file_path)
+	return result
+
+
+func _get_scene_script_paths(root: Node) -> Array[String]:
+	var result: Array[String] = []
+	# Walk scene tree
+	if root != null:
+		var nodes := [root]
+		while nodes.size() > 0:
+			var node: Node = nodes.pop_back()
+			var script = node.get_script()
+			if script is GDScript and script.resource_path != "":
+				result.append(script.resource_path)
+			for child in node.get_children():
+				nodes.append(child)
+	# Autoload discovery via ProjectSettings
+	for prop in ProjectSettings.get_property_list():
+		if prop.name.begins_with("autoload/"):
+			var value: String = ProjectSettings.get_setting(prop.name)
+			var path: String = value.lstrip("*")
+			if path.ends_with(".gd"):
+				result.append(path)
+			elif path.ends_with(".tscn"):
+				var scene = load(path)
+				if scene and scene is PackedScene:
+					var state = scene.get_state()
+					if state.get_node_count() > 0:
+						for i in state.get_node_property_count(0):
+							if state.get_node_property_name(0, i) == "script":
+								var script_val = state.get_node_property_value(0, i)
+								if script_val is GDScript:
+									result.append(script_val.resource_path)
+	# Deduplicate
+	var seen := {}
+	var deduped: Array[String] = []
+	for p in result:
+		if not seen.has(p):
+			seen[p] = true
+			deduped.append(p)
+	return deduped
+
+
 # --- Cleanup ---
 
 func _exit_tree() -> void:
