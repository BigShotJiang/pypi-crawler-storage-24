# Section 01 Code Review: Logger + Error Buffer

## Issues Found

### 1. Constructor API (Low) - Plan contradiction, not a bug. Callable retains implicit reference to server. Mitigated by _exit_tree() cleanup.

### 2. `error_type == 2` Magic Number (Medium) - Should use `Logger.ERR_SCRIPT` enum constant instead of magic number `2`. Since the file extends Logger, it should have access to the enum.

### 3. Mutex Not Exception-Safe (Medium) - GDScript has no try/finally, so this is inherent. Not easily fixable.

### 4. Dictionary Reference Semantics (Low) - Entry dict passed by reference, fine in practice since local var goes out of scope.

### 5. No `.tres` File Filter (Low) - Plan only specifies .gd and .tscn. Intentional scope limitation.

### 6. No `load()` Failure Warning (Low) - Silent failure if logger script can't be loaded. Could add push_warning().

### 7. Shallow Copy in `_get_script_errors` (Low-Medium) - `.duplicate()` does shallow copy; dict entries are shared references. Should use `.duplicate(true)` for deep copy per plan test requirement.

## What Matches Plan
- All instance variables, mutex methods, _ready() registration, _exit_tree() cleanup match exactly
- Logger file is separate (not inner class) as specified
- _log_error signature and filter logic match
- No print/push_error inside logger handler
- MAX_SCRIPT_ERRORS = 50 matches
