diff --git a/godot-addon/addons/godotiq/godotiq_logger.gd b/godot-addon/addons/godotiq/godotiq_logger.gd
new file mode 100644
index 0000000..4a7be3c
--- /dev/null
+++ b/godot-addon/addons/godotiq/godotiq_logger.gd
@@ -0,0 +1,22 @@
+extends Logger
+## GodotIQ Logger — captures script compilation and parse errors from the engine.
+## Only available on Godot 4.5+. Loaded conditionally via load() in godotiq_server.gd.
+
+var _append_callable: Callable
+
+
+func _init(server: Node) -> void:
+	_append_callable = server._append_script_error
+
+
+func _log_error(function: String, file: String, line: int, code: String, rationale: String, editor_notify: bool, error_type: int, script_backtraces: Array) -> void:
+	if not (file.ends_with(".gd") or file.ends_with(".tscn") or error_type == 2):  # ERR_SCRIPT = 2
+		return
+	var entry := {
+		"file": file,
+		"line": line,
+		"message": rationale if rationale != "" else code,
+		"type": "script_error",
+		"timestamp": Time.get_unix_time_from_system(),
+	}
+	_append_callable.call(entry)
diff --git a/godot-addon/addons/godotiq/godotiq_server.gd b/godot-addon/addons/godotiq/godotiq_server.gd
index d504bc0..50be7f5 100644
--- a/godot-addon/addons/godotiq/godotiq_server.gd
+++ b/godot-addon/addons/godotiq/godotiq_server.gd
@@ -27,6 +27,31 @@ var _godotiq_action_history: Array = []
 const MAX_HISTORY_SIZE: int = 50
 var _recent_errors: Array = []
 const MAX_RECENT_ERRORS: int = 10
+var _script_errors: Array = []  # [{file, line, message, type, timestamp}]
+var _script_error_mutex: Mutex = Mutex.new()
+const MAX_SCRIPT_ERRORS: int = 50
+var _error_logger  # Variant — null if Logger unavailable
+var _has_logger: bool = false
+
+
+func _clear_script_errors() -> void:
+	_script_error_mutex.lock()
+	_script_errors.clear()
+	_script_error_mutex.unlock()
+
+
+func _append_script_error(entry: Dictionary) -> void:
+	_script_error_mutex.lock()
+	if _script_errors.size() < MAX_SCRIPT_ERRORS:
+		_script_errors.append(entry)
+	_script_error_mutex.unlock()
+
+
+func _get_script_errors() -> Array:
+	_script_error_mutex.lock()
+	var copy := _script_errors.duplicate()
+	_script_error_mutex.unlock()
+	return copy
 
 
 func _ready() -> void:
@@ -37,6 +62,14 @@ func _ready() -> void:
 		print("GodotIQ: WebSocket server listening on 127.0.0.1:%d" % _port)
 	else:
 		push_error("GodotIQ: Failed to start WebSocket server on port %d (error %d)" % [_port, err])
+	# Logger registration (Godot 4.5+ only)
+	if ClassDB.class_exists("Logger"):
+		var logger_script = load("res://addons/godotiq/godotiq_logger.gd")
+		if logger_script:
+			_error_logger = logger_script.new(self)
+			OS.add_logger(_error_logger)
+			_has_logger = true
+			print("GodotIQ: Logger registered (Godot 4.5+)")
 
 
 func get_port() -> int:
@@ -1561,6 +1594,10 @@ func _send_text(peer_id: int, text: String) -> void:
 # --- Cleanup ---
 
 func _exit_tree() -> void:
+	if _has_logger and _error_logger:
+		OS.remove_logger(_error_logger)
+		_error_logger = null
+		_has_logger = false
 	for peer_id in _peers:
 		var ws: WebSocketPeer = _peers[peer_id]
 		if ws.get_ready_state() == WebSocketPeer.STATE_OPEN:
