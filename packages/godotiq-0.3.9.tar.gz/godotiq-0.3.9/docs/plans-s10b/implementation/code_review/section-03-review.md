# Section 03 Code Review

## HIGH
2. **Autoload helper duplicated** — _get_autoload_script_paths duplicates autoload logic from _get_scene_script_paths
3. **Tree walk duplicated** — BFS tree walk in _handle_run duplicates _get_scene_script_paths

## MEDIUM
4. Only discovers GDScript, not C# (plan scope limitation)
5. Ignores .tres/.scn autoloads (plan scope)
6. No error when main scene file missing but setting exists
7. Custom scene path not validated before play_custom_scene
8. SceneState doesn't recurse into instanced sub-scenes (acknowledged in plan)

## LOW
1. save_all_scenes() is correct API (plan said save_all_open_scenes incorrectly)
9. trim_prefix is better than plan's lstrip — correct deviation
10. CACHE_MODE_IGNORE performance for large projects
11. Error details discarded in SCRIPT_ERRORS response
