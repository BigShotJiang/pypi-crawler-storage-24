# Sprint 10b TDD Plan: Script Error Detection + Real Gameplay Testing

This document mirrors `claude-plan.md` section structure and defines test stubs to write BEFORE implementing each section.

**Testing framework:** pytest + pytest-asyncio (asyncio_mode = "auto")
**Mocking pattern:** `AsyncMock` + `patch("godotiq.tools.bridge.X.get_bridge")`
**Test location:** `tests/test_tools/test_check_errors.py`

---

## Section 1: Logger + Error Buffer (godotiq_server.gd)

No Python tests — this is GDScript-only. Verified via manual testing (Section 8.4 of plan).

GDScript manual verification stubs:
```
# Manual: Logger registers without error on Godot 4.5+
# Manual: Logger is skipped gracefully on Godot < 4.5 (ClassDB.class_exists check)
# Manual: Logger captures error when a broken .gd script is reload()ed
# Manual: _script_errors buffer respects max size (50)
# Manual: _clear_script_errors empties the buffer
# Manual: _get_script_errors returns a copy (not reference)
```

---

## Section 2: check_errors Handler (godotiq_server.gd)

No Python tests — this is GDScript-only. Verified via integration + manual testing.

GDScript manual verification stubs:
```
# Manual: check_errors handler responds to scope="project" with all .gd files
# Manual: check_errors handler responds to scope="scene" with current scene scripts + autoloads
# Manual: check_errors handler responds to scope="res://path.gd" with single file result
# Manual: Filesystem scanner excludes addons/, .godot/, build/, export/
# Manual: Autoload discovery finds autoloads via ProjectSettings.get_property_list()
# Manual: Autoload discovery handles .tscn autoloads (extracts root script)
# Manual: Script with parse error returns error entry with file path
# Manual: Script with compilation error returns error entry with file path
# Manual: Clean script returns no error
# Manual: Errors are deduplicated by file+line+message
```

---

## Section 3: Pre-run Check (godotiq_server.gd)

No Python tests — this is GDScript-only. Verified via integration + manual testing.

GDScript manual verification stubs:
```
# Manual: _handle_run saves all scenes before checking scripts
# Manual: _handle_run blocks play when scene scripts have errors
# Manual: _handle_run returns _send_error with code "SCRIPT_ERRORS"
# Manual: _handle_run proceeds normally when all scripts are clean
# Manual: Script discovery uses PackedScene.get_state() (no instantiation)
# Manual: Pre-run check includes autoload scripts
```

---

## Section 4: Python Tool (check_errors.py + __init__.py)

### Bridge Wrapper Tests (test_check_errors.py)

```python
# Test: check_errors returns clean result when bridge reports no errors
# Test: check_errors forwards errors array from bridge response
# Test: check_errors passes scope parameter to bridge.request
# Test: check_errors defaults scope to "scene" when not specified
# Test: check_errors handles BridgeConnectionError with helpful message
# Test: check_errors handles BridgeTimeoutError with timeout message
# Test: check_errors handles generic BridgeError
```

### MCP Registration Tests (test_check_errors.py)

```python
# Test: godotiq_check_errors tool is registered in server tool list
# Test: godotiq_check_errors wraps bridge errors in standard format
# Test: godotiq_check_errors applies apply_output_limit to result
```

### Run Pre-check Tests (test_check_errors.py)

```python
# Test: run tool reports SCRIPT_ERRORS when bridge returns BridgeError with that code
# Test: run tool proceeds normally when bridge returns success
```

---

## Section 5: Prompt Updates (godot_development_prompt_v2.md)

No automated tests — prompt is a markdown file. Verification stubs:

```
# Verify: "Test-Driven Completion" section exists before "MANDATORY: Final QA"
# Verify: QA Step 5 expanded to 5.1-5.6 with check_errors, input, state_inspect
# Verify: "Act immediately" rule added to Efficiency Rules
# Verify: "Maximum 2 paragraphs between tool calls" rule added
# Verify: SCRIPT_ERRORS added to Error Recovery section
# Verify: godotiq_check_errors listed in tool reference UNDERSTAND section
```

---

## Section 6: Tests (test_check_errors.py)

This IS the test section — tests are written here following the stubs defined in Sections 4 above.

Integration test stubs (manual, requires running Godot):
```
# Integration: Write broken script → call check_errors → verify error in response
# Integration: Write broken script → call run(play) → verify blocked with SCRIPT_ERRORS
# Integration: Fix script → call run(play) → verify game starts
```
