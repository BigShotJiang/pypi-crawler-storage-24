# Section 06: Tests (test_check_errors.py)

## Overview

This section creates the complete pytest test suite for the `godotiq_check_errors` MCP tool and the `check_errors` bridge wrapper. It also includes tests verifying that the `godotiq_run` tool correctly handles the `SCRIPT_ERRORS` error code.

All tests mock the bridge layer — no running Godot editor required. Tests follow the project's established patterns: class-based organization, `AsyncMock` + `patch("godotiq.tools.bridge.<module>.get_bridge")`, and `asyncio_mode = "auto"`.

## Dependencies

- **Section 04 (Python Tool)** must be implemented first. That section creates:
  - `src/godotiq/tools/bridge/check_errors.py` — the bridge wrapper
  - Updated `src/godotiq/tools/bridge/__init__.py` — MCP tool registration
  - Updated `src/godotiq/bridge/protocol.py` — timeout config

## File to Create

`/Users/salvatorefarruggio/Desktop/godotiq/tests/test_tools/test_check_errors.py`

## Background: Mocking Pattern

```python
mock_bridge = AsyncMock()
mock_bridge.request = AsyncMock(return_value={...})
with patch("godotiq.tools.bridge.check_errors.get_bridge", return_value=mock_bridge):
    result = await check_errors(scope="scene")
```

Exception classes from `godotiq.bridge.connection`:
- `BridgeConnectionError` — bridge not connected
- `BridgeTimeoutError` — request timed out
- `BridgeError(code, error_message)` — addon returned error; has `.code` and `.error_message`

## Test Plan

### Class: TestCheckErrorsBridgeWrapper

Tests for `check_errors()` in `check_errors.py`.

1. **`test_returns_clean_result_when_no_errors`** — Mock returns `{"errors": [], "total": 0, "scripts_checked": 5, "scope": "scene"}`. Assert `total == 0`, `errors == []`.

2. **`test_forwards_errors_from_bridge`** — Mock returns errors array with entries. Assert errors present with expected length.

3. **`test_passes_scope_parameter_to_bridge`** — Call `check_errors(scope="project")`. Verify bridge called with `{"scope": "project"}`.

4. **`test_defaults_scope_to_scene`** — Call `check_errors()` no args. Verify params `{"scope": "scene"}`.

5. **`test_handles_connection_error`** — `get_bridge` raises `BridgeConnectionError`. Assert propagates.

6. **`test_handles_timeout_error`** — `request` raises `BridgeTimeoutError`. Assert propagates.

7. **`test_handles_bridge_error`** — `request` raises `BridgeError("CHECK_FAILED", "scan error")`. Assert propagates.

### Class: TestCheckErrorsMCPRegistration

Tests for `godotiq_check_errors` MCP wrapper in `__init__.py`.

1. **`test_tool_is_registered`** — Import `mcp` from `godotiq.server`, verify `"godotiq_check_errors"` in tool list.

2. **`test_catches_bridge_connection_error`** — Patch `get_bridge` to raise. Call MCP wrapper. Assert result dict has `"error"` and `"hint"`.

3. **`test_catches_bridge_timeout_error`** — Patch `.request` to raise. Assert result has `"error"` and `"hint"`.

4. **`test_catches_bridge_error`** — Patch `.request` to raise `BridgeError`. Assert `"error"` contains code.

5. **`test_applies_output_limit`** — Verify `apply_output_limit` is called (via patch or by checking large result is handled).

### Class: TestRunPreCheckBehavior

Tests for how `godotiq_run` handles `SCRIPT_ERRORS`.

1. **`test_run_returns_script_errors_on_bridge_error`** — Mock raises `BridgeError("SCRIPT_ERRORS", "Cannot start game...")`. Call `godotiq_run(action="play")`. Assert `"SCRIPT_ERRORS"` in result.

2. **`test_run_proceeds_normally_on_success`** — Mock returns success. Assert no error.

### Class: TestCheckErrorsTimeout

1. **`test_timeout_configured`** — Import `TOOL_TIMEOUTS`, assert `"check_errors"` is 15.0.

### Class: TestCheckErrorsEdgeCases

1. **`test_empty_project_zero_scripts`** — Mock returns `scripts_checked: 0`. Assert valid response.

2. **`test_single_file_scope`** — Call with `scope="res://scripts/player.gd"`. Verify forwarded as-is.

## Implementation Guidance

```python
from __future__ import annotations
from unittest.mock import AsyncMock, patch
import pytest
from godotiq.tools.bridge.check_errors import check_errors
from godotiq.tools.bridge import godotiq_check_errors
from godotiq.bridge.connection import BridgeConnectionError, BridgeTimeoutError, BridgeError
```

- All test methods are `async def` (auto mode)
- Patch target: `"godotiq.tools.bridge.check_errors.get_bridge"`
- No fixtures from `conftest.py` needed — all state via inline mocks

## Implementation Notes (Post-Implementation)

- Most tests were already created in section-04 (15 tests). Section-06 added TestCheckErrorsEdgeCases (2 tests)
- Total: 17 tests in test_check_errors.py, all passing
- Full suite: 1014 tests, no regressions
- Code review skipped for section-06 (tests are straightforward mocks matching plan)
