<!-- PROJECT_CONFIG
runtime: python-uv
test_command: pytest -v
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-logger-buffer
section-02-check-errors-handler
section-03-pre-run-check
section-04-python-tool
section-05-prompt-updates
section-06-tests
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-logger-buffer | - | 02, 03 | Yes |
| section-02-check-errors-handler | 01 | 03, 04 | No |
| section-03-pre-run-check | 01, 02 | - | No |
| section-04-python-tool | 02 | 06 | No |
| section-05-prompt-updates | - | - | Yes |
| section-06-tests | 04 | - | No |

## Execution Order

1. section-01-logger-buffer, section-05-prompt-updates (parallel, no dependencies)
2. section-02-check-errors-handler (after 01)
3. section-03-pre-run-check, section-04-python-tool (parallel after 02)
4. section-06-tests (after 04)

## Section Summaries

### section-01-logger-buffer
GDScript Logger inner class (Godot 4.5+ optional), `_script_errors` buffer with mutex, version-guarded registration in `_ready()`. Foundation for error capture.

### section-02-check-errors-handler
GDScript `_handle_check_errors` handler with dispatch registration, filesystem scanner (excluding addons/.godot/build/export), scene script collector (with correct autoload discovery via ProjectSettings), and `load()+can_instantiate()+reload()` check loop.

### section-03-pre-run-check
Modify `_handle_run` to save all scenes, discover scripts via `PackedScene.get_state()` (no instantiation), run synchronous `load()+can_instantiate()` check, and `_send_error` with SCRIPT_ERRORS code when broken scripts found.

### section-04-python-tool
New `check_errors.py` bridge wrapper, MCP tool registration in `__init__.py` (no detail param), `apply_output_limit` call, timeout config in protocol.py.

### section-05-prompt-updates
Add Test-Driven Completion section, expand QA Step 5 to real gameplay testing (5.1-5.6), add efficiency rules (act immediately, max 2 paragraphs), add SCRIPT_ERRORS to error recovery, add godotiq_check_errors to tool reference.

### section-06-tests
pytest tests: bridge wrapper tests (clean/errors/scope/connection error/timeout), MCP registration tests, run pre-check tests, edge cases (invalid scope, empty project).
