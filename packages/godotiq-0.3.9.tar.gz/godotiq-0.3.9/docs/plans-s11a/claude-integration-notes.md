# Sprint 11a — Review Integration Notes

## Integrating (with changes)

### 1. Dual Timeout Coordination — INTEGRATE
The reviewer is absolutely right. Python bridge timeout must exceed GDScript polling timeout. Will add explicit `timeout` kwarg to `bridge.request("run", ..., timeout=computed + 5)` with a 5-second buffer. This is the most critical fix.

### 2. `get_bridge_or_none()` for reload — INTEGRATE
Correct — using `get_bridge()` would block for 5s on connection attempt. Will use `get_bridge_or_none()` which returns None immediately if not connected. Also add lazy import and explicit `res://` path construction.

### 3. open_scene_from_path race condition — INTEGRATE (simplified approach)
The two-phase state machine is overkill. The existing `_handle_run` already uses `_pending_run` as a deferred mechanism. The actual approach: `_handle_run` is not called with `await` — it's a regular function that sets `_pending_run`. The scene open can be done synchronously (it's an editor operation, not async), and the `_pending_run` mechanism already handles the deferred wait for `is_playing_scene()`. No state machine needed — just call `open_scene_from_path` before `play_current_scene()` in the same function body.

However, if the scene needs a frame to load: we can use the existing `_pending_run` approach. Set `_pending_scene_open` state, then on next `_process` tick, proceed to play. Will add a lightweight two-step state: open → play → poll.

### 4. set_main_scene side-effect — INTEGRATE (with guard)
Will only auto-set main_scene when:
- main_scene setting is truly empty/unset
- A scene param was explicitly provided
Will add a warning in the response: `"main_scene_set": true` so the agent knows project.godot was modified.

### 5. verify_motion game-running check — INTEGRATE
Will check game state before first state_inspect and handle failure of second call gracefully.

### 6. Session access → GODOTIQ_PROJECT_ROOT — INTEGRATE
Correct. Will use `os.environ.get("GODOTIQ_PROJECT_ROOT")` with pathlib instead of trying to access session. Much simpler.

### 7. Pre-flight script validation — INTEGRATE
Critical catch. The pre-flight check (check_scripts_valid) must be preserved in the rewritten handler. Will add it between scene resolution and play.

### 8. run.py return value — INTEGRATE
Will update run.py to pass through the bridge response rather than constructing its own. This gives the caller {success, waited_seconds, scene, action} from GDScript.

### 9. Implementation order — INTEGRATE
Correct. Will fix: Section 4 (set_main_scene) simultaneously with Section 1, not after.

### 10. node_names from return value — INTEGRATE
Will use `result.get("name", "")` from `_create_build_node` return dict instead of spec name.

### 11. _find_scene_by_name ambiguity — INTEGRATE
Will return error if multiple matches found.

### 12. filesystem.scan() timing — INTEGRATE (documentation)
Will note in the plan that scan() is async and follow-up operations may need a brief delay.

## Integrating (as-is)

### 13. Rename `property` parameter — INTEGRATE
Will use `property_name` instead.

### 14. `detail` parameter — INTEGRATE
Will apply `apply_output_limit` to verify_motion response.

### 15. Prompt file retrieval — INTEGRATE
Will note git show command for retrieving base content.

## NOT Integrating

None — all suggestions are valid and worth integrating.
