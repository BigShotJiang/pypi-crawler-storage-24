<!-- PROJECT_CONFIG
runtime: python-uv
test_command: pytest -v
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-set-main-scene
section-02-handle-run
section-03-script-reload
section-04-build-scene-names
section-05-adaptive-timeout
section-06-verify-motion
section-07-mcp-prompt
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-set-main-scene | - | section-02 | Yes |
| section-02-handle-run | section-01 | section-05 | No |
| section-03-script-reload | - | section-07 | Yes |
| section-04-build-scene-names | - | section-07 | Yes |
| section-05-adaptive-timeout | section-02 | section-07 | No |
| section-06-verify-motion | - | section-07 | Yes |
| section-07-mcp-prompt | section-02, section-03, section-04, section-05, section-06 | - | No |

## Execution Order

1. section-01-set-main-scene (no dependencies)
2. section-02-handle-run (after 01)
3. section-03-script-reload, section-04-build-scene-names, section-06-verify-motion (parallel, independent)
4. section-05-adaptive-timeout (after 02)
5. section-07-mcp-prompt (after all others — documents everything)

## Section Summaries

### section-01-set-main-scene
Add `set_main_scene` GDScript handler + `_set_main_scene_internal()` helper to godotiq_server.gd. Add dispatch table entry. This is a dependency for section-02.

**Files**: `godot-addon/addons/godotiq/godotiq_server.gd`
**Tests**: None (GDScript only)

### section-02-handle-run
Rewrite `_handle_run` to always use `play_current_scene()`. Add `_pending_scene_open` two-step deferred mechanism. Add `_find_scene_by_name()` helper. Preserve pre-flight script validation. Change polling to 0.25s. Default timeout 15s. Auto-set main_scene when empty. Update `_process()` polling logic. Update `run.py` to pass through bridge response.

**Files**: `godot-addon/addons/godotiq/godotiq_server.gd`, `src/godotiq/tools/bridge/run.py`
**Tests**: Basic run.py response tests

### section-03-script-reload
Add `reload_script` GDScript handler. Add `_try_reload_script()` to `script_ops.py` using `get_bridge_or_none()` with lazy import. Call after .gd writes/creates. Add `filesystem.scan()` to `_handle_build_scene`.

**Files**: `godot-addon/addons/godotiq/godotiq_server.gd`, `src/godotiq/tools/bridge/script_ops.py`
**Tests**: `test_script_ops_reload.py`

### section-04-build-scene-names
Add `node_names` array to `_handle_build_scene` response using `_create_build_node` return values.

**Files**: `godot-addon/addons/godotiq/godotiq_server.gd`
**Tests**: None (GDScript only, Python passes through)

### section-05-adaptive-timeout
Add adaptive timeout to `run.py` based on GLB file count from `GODOTIQ_PROJECT_ROOT`. Pass computed timeout to bridge request params AND as bridge timeout kwarg (+5s buffer).

**Files**: `src/godotiq/tools/bridge/run.py`
**Tests**: `test_run_adaptive_timeout.py`

### section-06-verify-motion
Create `verify_motion.py` with game-running check, two state_inspect calls with sleep, MOVING/STATIC verdict. Register in `__init__.py` as `godotiq_verify_motion`.

**Files**: `src/godotiq/tools/bridge/verify_motion.py` (NEW), `src/godotiq/tools/bridge/__init__.py`
**Tests**: `test_verify_motion.py`

### section-07-mcp-prompt
Create fresh `godot_development.md` based on git HEAD content plus: Known Godot Quirks, Script Loading Pattern, Verifying Movement, Game Loading Time, updated tool reference.

**Files**: `src/godotiq/prompts/godot_development.md` (recreate)
**Tests**: None (documentation)
