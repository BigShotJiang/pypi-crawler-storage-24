# Sprint 11a — Interview Transcript

## Q1: Run fallback when no scene is open

**Question**: Issue 1 fix switches to play_current_scene(). If no scene is open in the editor and no scene param is passed, should it fall back to play_main_scene(), or return an error?

**Answer**: The MCP should figure out how to open the scene in the editor itself. It should be able to auto-open the main scene from project.godot before playing.

**Decision**: Auto-open main_scene from ProjectSettings if no scene is open and no scene param provided, then use play_current_scene().

## Q2: verify_motion tool

**Question**: Should we include the optional verify_motion tool, or just the prompt pattern?

**Answer**: Include verify_motion tool.

**Decision**: Build the dedicated `godotiq_verify_motion` MCP tool in this sprint.

## Q3: Set main scene approach

**Question**: Separate MCP tool, integrated into run(), or prompt-only?

**Answer**: GDScript handler only — add set_main_scene handler in GDScript, integrate into run flow.

**Decision**: Add `set_main_scene` handler in GDScript dispatch. Integrate into run flow so when scene param is provided and main_scene isn't set, set it automatically. No separate Python MCP tool.

## Q4: Script reload failure behavior

**Question**: If bridge is not connected when writing a .gd file, what should happen?

**Answer**: Write + silent skip. Best effort: write file, try reload, swallow errors.

**Decision**: script_ops writes the file regardless of bridge availability. Reload attempt is best-effort, silently skipped on failure.

## Q5: Auto-save after build_scene

**Question**: Should build_scene auto-save, or leave it to the agent?

**Answer**: "It's up to you, think for the better choice."

**Decision**: No auto-save after build_scene. Reasons:
1. Agent often does multiple build_scene calls in sequence — saving after each is wasteful
2. Agent may want to inspect/verify before saving
3. Current pattern (save_scene as separate call) is already established
4. Keeping operations atomic gives the agent more control

## Q6: Polling rate for run timeout

**Question**: Keep 0.5s polling intervals or reduce?

**Answer**: Use 0.25s polling — faster detection with slightly more CPU.

**Decision**: Change polling interval from 0.5s to 0.25s in _process() for _pending_run checks.

## Q7: Prompt file handling

**Question**: Restore from git or create fresh?

**Answer**: Create fresh version incorporating all content plus new quirks.

**Decision**: Write a new `godot_development.md` from scratch with all existing content restructured plus the new "Known Godot Quirks" section and all other additions.

## Q8: Additional issues

**Question**: Any other issues from city build test?

**Answer**: No additional issues, but assure the GodotIQ addon is correct — verify that the GDScript changes don't break existing functionality.

**Decision**: Add validation that the GodotIQ addon GDScript is syntactically correct and all existing handlers still work. Existing Python tests must pass with no regressions.
