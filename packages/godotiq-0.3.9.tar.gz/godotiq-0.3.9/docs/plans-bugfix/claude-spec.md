# GodotIQ v0.3.4 Bug Fix — Combined Specification

## Project Context

GodotIQ is an MCP server for AI-assisted Godot 4.x game development. Python 3.10+, FastMCP API, stdio transport. The addon runs inside the Godot editor and communicates with the Python MCP server via WebSocket bridge.

**Current state:** v0.3.3 stable baseline. 1,351 tests passing. 19 files with uncommitted modifications from prior Codex fix attempts. 7 of 16 identified bugs remain open.

## Scope

This plan addresses **5 confirmed bugs** (verified against actual code) plus **3 newly discovered issues** from scalability/edge case investigation. Priority order by severity.

---

## Bug #13 — CRITICAL: exec_code Bypasses Protected Files

### Problem
The `godotiq_exec` tool allows arbitrary GDScript code execution in both editor and game contexts. The protection mechanism is fundamentally broken:

1. **Editor context missing FileAccess.open block**: `godotiq_server.gd:1254-1267` has blocked_patterns but FileAccess.open is NOT in the list. Any file can be read/written in editor context.
2. **Substring matching is trivially bypassable**: Both contexts use `code.find(pattern)` — bypass with `var FA = FileAccess; FA.open(...)`.
3. **Python layer has zero validation**: `exec_code.py` passes raw code directly to bridge without checking protected files or dangerous patterns.
4. **Config protection unused**: `config.is_file_protected()` enforces protection in `file_ops.py` and `script_ops.py` but is NEVER called from `exec_code.py`.

### Impact
An AI agent (or user) can read/write `project.godot`, `.godotiq.json`, saves, and any other file through exec_code, completely bypassing the protection system that other tools respect.

### Constraints
- Cannot use AST parsing (GDScript has no Python-accessible parser)
- Must work for both editor and game contexts
- Must not break legitimate code execution
- Pattern matching will always have bypasses — defense in depth needed

---

## Bug #10 — HIGH: godotiq_run Writes main_scene Permanently

### Problem
`_handle_run()` in `godotiq_server.gd:529-535` auto-sets main_scene in project.godot when:
1. A specific scene is requested (not "current")
2. The scene resolves to a valid path
3. `application/run/main_scene` is currently empty

`_set_main_scene_internal()` (line 411-414) calls `ProjectSettings.save()` — permanent disk write.

### Impact
- Silent project.godot corruption when an AI agent tests a random scene
- No way for Python caller to prevent the write
- No rollback if run fails
- Undocumented side effect in run() docstring

### Constraints
- The auto-set behavior may be intentional for UX (first run on empty project)
- Must not break projects that legitimately need main_scene set
- Response already includes `main_scene_set: true` flag

---

## Bug #14 — MEDIUM: project_summary Cache Staleness

### Problem
`session._index` (session.py:50) is set once from `scan_project()` and never invalidated. Meanwhile, `_read_main_scene()` (memory/__init__.py:21-35) reads `project.godot` fresh from disk each time.

Result: same `project_summary` response has `project_name` from cache and `main_scene` from disk — different freshness guarantees for different fields.

### Impact
- Stale project name after rename
- Stale autoload list after adding autoloads
- Stale scene/script counts after adding files
- Inconsistency confuses AI agents that trust the response as a single coherent snapshot

### Constraints
- Full project re-scan on every call would be too expensive
- Need targeted invalidation, not blanket refresh
- `project.godot` changes are rare — mtime check is sufficient

---

## Bug #12 — MEDIUM: suggest_scale Returns null on Empty Scene

### Problem
Both reference mode (assets/__init__.py:441-449) and model mode (lines 605-630) return `recommended_scale: None` when no matches are found. The model mode has a text suggestion "Place at scale (1,1,1) and adjust manually" but the numeric field stays null.

### Impact
- AI agent consuming the tool must null-check before using the value
- Inconsistent response schema (sometimes array, sometimes null)
- The text suggestion mentions (1,1,1) but doesn't provide it as the actual value

### Constraints
- (1,1,1) is a reasonable default but may not be correct for all asset types
- Must be clearly marked as a fallback, not a confident recommendation
- Should not change behavior when matches ARE found

---

## Bug #16 — LOW: spatial_audit Z-Fighting Noise

### Problem
`_check_z_fighting()` (spatial/__init__.py:540-564) compares every pair of mesh nodes with O(n^2) complexity. No parent relationship check. `_parent_path()` exists (lines 530-537) but is never called.

On a 10x10 tile grid: ~100+ z-fighting "info" issues that fill the 50-issue output cap, burying real problems.

### Impact
- Audit output unusable on scenes with tiled floors/walls
- Real z-fighting issues (overlapping non-sibling geometry) buried
- Tests validate the noisy behavior rather than correct behavior

### Constraints
- Sibling tiles under same parent at adjacent positions are NORMAL — not z-fighting
- Non-sibling nodes at identical positions ARE worth reporting
- Must maintain backward compatibility with existing test assertions (or update them)

---

## Additional Discovered Issues

### Bug #17 — MEDIUM: godotiq_watch Orphans on Game Crash

`watch.py` has no maximum watch duration, no heartbeat, no cleanup on bridge disconnect. If game crashes, watch stays pending. User must manually stop, which may fail if bridge is dead.

**Fix scope:** Add optional `max_duration_ms` parameter; document behavior on crash.

### Bug #18 — LOW: Camera State Not Restored After Screenshot

`screenshot.py:58-64` moves editor camera for `camera_position` parameter but never restores original position. Editor camera permanently moved as side effect.

**Fix scope:** Document as known behavior OR add restore-after-capture logic.

### Bug #19 — LOW: state_inspect Error for Missing Methods Unclear

When querying a non-existent method, addon returns generic "PROPERTY_NOT_FOUND" error. Not clear if method name is wrong or doesn't exist on node type.

**Fix scope:** Improve docstring to warn about behavior; optionally improve error message.

---

## Out of Scope

- **sync_version.py** (#15): Core script works. Codex addition is dead code (test_version.py uses dynamic version). Low priority, skip.
- **node_ops target vs node** (#11): Error message says "requires 'node' field" — minimally helpful. Docstring improvement only, skip.
- **AST-based GDScript parsing**: Would be ideal for #13 but no Python GDScript parser exists. Not feasible.
- **File watcher for session invalidation**: Over-engineering for #14. Mtime check on project.godot is sufficient.
- **Scalability optimization** (session stat() calls): Confirmed as potential issue on very large projects but not causing current user problems. Document and defer.

---

## Success Criteria

1. All 5 primary bugs verified as fixed via new tests
2. No regression in existing 1,351 tests
3. Security tests demonstrating exec_code blocks FileAccess.open in editor context
4. run() either prevents main_scene write or makes it opt-in
5. project_summary returns consistent freshness across all fields
6. suggest_scale always returns a numeric fallback
7. Z-fighting detection distinguishes sibling tiles from real overlaps
