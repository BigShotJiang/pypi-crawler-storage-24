# Integration Notes — Opus Review Feedback

## Suggestions INTEGRATED

### 1. Block FileAccess.get_file_as_string / get_file_as_bytes (Section 1)
**Why:** Valid bypass vector. These static methods read files without .open(). Adding to both Python and GDScript blocked patterns.

### 2. Broaden variable alias regex (Section 1)
**Why:** Trivial improvement. `r'var\s+\w+[^=]*=\s*(FileAccess|DirAccess)\b'` handles type annotations.

### 3. Add DirAccess.remove_absolute test (Section 1)
**Why:** Important to verify the substring "DirAccess.remove" catches "DirAccess.remove_absolute". Cheap to add.

### 4. Acknowledge stale counts as known limitation (Section 3)
**Why:** Correct — refreshing project.godot only fixes project_name and autoloads, not scene/script counts. Document explicitly.

### 5. Add "fallback" to brief-mode whitelist (Section 4)
**Why:** Clear oversight. Without this, brief mode loses the fallback flag.

### 6. "fallback" only present when true (Section 4)
**Why:** Consistent with codebase pattern (optional fields only when relevant).

### 7. Fix pair_key to use full_path (Section 5)
**Why:** Pre-existing bug. Using names means same-named nodes in different tree branches skip incorrectly. Fix is one-line change.

### 8. Test empty full_path in sibling detection (Section 5)
**Why:** Edge case worth testing. Root nodes with full_path="" treated as siblings — correct behavior, but should be explicit.

### 9. Move ensure_index_fresh() to session property (Section 3)
**Why:** Cleaner architecture. Making _index a property that auto-checks avoids the maintenance trap of every consumer needing to remember the call.

## Suggestions NOT INTEGRATED

### 1. Multi-line bypass / whitespace normalization on Python side
**Why not:** GDScript doesn't actually support `FileAccess.\n    open()` as valid syntax. Line breaks in the middle of a method call produce a parse error. The research document's claim about this bypass is incorrect for GDScript (it works in Python, not GDScript). No action needed.

### 2. Breaking change communication (changelog/migration note) for Section 2
**Why not:** Out of scope for this plan. The version is already 0.3.4. Changelog is a release task, not an implementation task.

### 3. "Contract test is fragile" suggestion to verify behavior instead of implementation
**Why not:** We can't run GDScript tests without a live Godot instance. The contract test parsing approach is the best available. We'll make the regex robust.

### 4. Performance test for Section 3's stat() call
**Why not:** Single stat() call is ~100 microseconds. Not worth a test. If it becomes a pattern (multiple stat calls per summary), we'll add benchmarks then.
