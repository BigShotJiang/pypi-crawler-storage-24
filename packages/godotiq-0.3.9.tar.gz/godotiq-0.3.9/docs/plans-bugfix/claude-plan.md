# GodotIQ v0.3.4 — Bug Fix Implementation Plan

## Overview

This plan addresses 5 confirmed bugs in GodotIQ, ordered by severity. Each bug has been verified against the current codebase (v0.3.3 baseline + uncommitted Codex changes). The fixes are designed to be minimal, focused, and independently testable.

**Baseline:** 1,351 tests passing, 0 failures. All fixes must maintain this.

**Approach:** Defense in depth for security, minimal changes for everything else. No over-engineering.

---

## Section 1: Bug #13 — exec_code Security Hardening

### Problem

The `godotiq_exec` tool has three layers of security failure:

1. **Editor context does not block `FileAccess.open`** — The blocked_patterns array in `godotiq_server.gd` (editor handler, line 1254) includes `DirAccess.remove`, `OS.execute`, `OS.kill`, `OS.shell_open` but NOT `FileAccess.open`. An AI agent can read/write any file in editor context, including `project.godot` and `.godotiq.json`.

2. **Python layer performs zero validation** — `exec_code.py` passes raw code directly to the bridge. It does not call `config.is_file_protected()` or check for dangerous patterns. If the GDScript-side blocking fails, there is no fallback.

3. **Substring matching is bypassable** — Both editor and game contexts use `code.find(pattern)` for blocking. Variable aliasing (`var FA = FileAccess; FA.open(...)`) produces code where the substring `"FileAccess.open"` does not appear.

### What to Change

#### 1a. Add FileAccess.open to Editor Blocked Patterns

**File:** `godot-addon/addons/godotiq/godotiq_server.gd`
**Function:** `_handle_exec_editor()` (around line 1254)

Add `"FileAccess.open"` to the `blocked_patterns` array in the editor handler. This makes editor and game contexts consistent.

Also add `"DirAccess.open"` to both contexts — currently only `DirAccess.remove` is blocked, but `DirAccess.open()` returns an object that can call `.remove()` on files, bypassing the `DirAccess.remove` pattern.

Also add `"FileAccess.open"` to the editor patterns and `"DirAccess.open"` to both editor and game patterns. Additionally, block `"FileAccess.get_file_as_string"` and `"FileAccess.get_file_as_bytes"` — these are static convenience methods that read files without calling `.open()`, bypassing the FileAccess.open check.

Final blocked_patterns for both contexts should be identical:

```
DirAccess.remove
DirAccess.open
FileAccess.open
FileAccess.get_file_as_string
FileAccess.get_file_as_bytes
OS.execute
OS.kill
OS.shell_open
```

**Note:** `DirAccess.remove_absolute()` is intentionally caught by the `DirAccess.remove` substring match. Document this in a code comment.

#### 1b. Add Python-Side Pattern Pre-Check

**File:** `src/godotiq/tools/bridge/exec_code.py`
**Function:** `exec_code()` (line 33)

Add a pre-flight check before sending code to the bridge. This is defense-in-depth — not a replacement for GDScript-side blocking, but a second layer.

Create a module-level constant `_BLOCKED_PATTERNS` matching the GDScript side. Before calling `bridge.request()`, scan the code string for these patterns. If found, return `{"status": "BLOCKED", "result": "", "error": "Blocked pattern: <pattern>"}` without calling the bridge.

This catches the easy cases. It does NOT catch variable aliasing — that's a known limitation documented in the code.

#### 1c. Add Variable Aliasing Detection (Best-Effort)

**File:** `src/godotiq/tools/bridge/exec_code.py`

Add a second check: scan for lines matching the pattern `var <identifier> = FileAccess` or `var <identifier> = DirAccess` (regex: `r'var\s+\w+[^=]*=\s*(FileAccess|DirAccess)\b'`). The `[^=]*` handles optional type annotations like `var FA : Variant = FileAccess`. If found, block with error "Indirect reference to blocked class: FileAccess/DirAccess".

This catches the most obvious bypass. More sophisticated bypasses (string concatenation, Callable, etc.) are not practically exploitable in GDScript since it lacks `eval()`. Document this limitation.

#### 1d. Add Warning Comment About Limitations

**File:** `src/godotiq/tools/bridge/exec_code.py`

Add a comment block explaining:
- Pattern matching is best-effort, not a security boundary
- GDScript lacks eval(), so string-based construction can build strings but can't execute them as code
- The real sandbox is the RefCounted base class in game context (no scene tree access)
- Editor context is inherently trusted (full editor access by design) but we block obvious data corruption patterns

### What NOT to Do

- Do NOT implement AST parsing — no Python GDScript parser exists
- Do NOT add `config.is_file_protected()` calls to exec_code — the protected files list is about path-based file operations, not code execution patterns
- Do NOT change the GDScript sandbox model (RefCounted base) — that works correctly
- Do NOT add more blocked patterns beyond filesystem and OS access — keep the list minimal and auditable

### Tests to Add

**File:** `tests/test_bridge/test_exec_code.py`

- `test_blocked_fileaccess_open_game_context`: Code containing `FileAccess.open` returns BLOCKED status
- `test_blocked_fileaccess_open_editor_context`: Same for editor context
- `test_blocked_diraccess_open_both_contexts`: `DirAccess.open` blocked in both
- `test_blocked_variable_alias_fileaccess`: `var FA = FileAccess` pattern detected and blocked
- `test_blocked_variable_alias_diraccess`: Same for DirAccess
- `test_blocked_variable_alias_with_type_annotation`: `var FA : Variant = FileAccess` also blocked
- `test_blocked_fileaccess_get_file_as_string`: Static read method blocked
- `test_blocked_fileaccess_get_file_as_bytes`: Static read method blocked
- `test_diraccess_remove_absolute_caught_by_remove_pattern`: Verify substring match intentionally catches this
- `test_legitimate_code_not_blocked`: Code using `FileAccess` in a comment or string literal is blocked (best-effort, documented as accepted behavior)
- `test_all_blocked_patterns_consistent`: Verify Python and GDScript pattern lists match (contract test)

**File:** `tests/test_godot_addon_contracts.py`

- `test_editor_blocked_patterns_include_fileaccess`: Parse godotiq_server.gd, verify `"FileAccess.open"` is in editor blocked_patterns
- `test_game_blocked_patterns_include_diraccess_open`: Parse godotiq_runtime.gd, verify `"DirAccess.open"` is present

---

## Section 2: Bug #10 — godotiq_run Main Scene Side Effect

### Problem

`_handle_run()` in `godotiq_server.gd` (line 529-535) automatically sets `application/run/main_scene` in `project.godot` when:
1. A specific scene is requested (not "current")
2. The project has no main_scene configured
3. The scene resolves to a valid path

This calls `_set_main_scene_internal()` which does `ProjectSettings.save()` — a permanent disk write. The Python caller cannot prevent this. The side effect is undocumented.

### What to Change

#### 2a. Make Main Scene Auto-Set Opt-In

**File:** `godot-addon/addons/godotiq/godotiq_server.gd`
**Function:** `_handle_run()` (around line 529)

Change the behavior: instead of auto-writing, **report** that main_scene is empty and suggest the caller use `set_main_scene` explicitly.

Replace the auto-set block with:
```
if not is_current and resolved_path != "" and current_main == "":
    # Do NOT auto-write. Flag it in the response instead.
    main_scene_empty = true
```

The response should include `"main_scene_empty": true` and `"hint": "No main_scene set. Use set_main_scene to configure."` This lets the AI agent (or user) make an informed decision.

#### 2b. Update Python Docstring

**File:** `src/godotiq/tools/bridge/run.py`
**Function:** `run()` docstring

Remove any mention of auto-set (if present). Add a note that if no main_scene is configured, the response will include `main_scene_empty: true`.

#### 2c. Clean Up _set_main_scene_internal References

**File:** `godot-addon/addons/godotiq/godotiq_server.gd`

`_set_main_scene_internal()` is still used by the explicit `set_main_scene` RPC handler (line 417). Keep the function — just remove the auto-call from `_handle_run()`.

### What NOT to Do

- Do NOT add a `dry_run` parameter — over-engineering
- Do NOT remove `_set_main_scene_internal()` — it's used by the explicit handler
- Do NOT change the `set_main_scene` RPC — that's the intentional, explicit mechanism

### Tests to Add

**File:** `tests/test_godot_addon_contracts.py`

- `test_handle_run_does_not_auto_set_main_scene`: Parse godotiq_server.gd's `_handle_run` function body. Verify it does NOT call `_set_main_scene_internal`. This is a contract test (no live Godot needed).
- `test_handle_run_reports_main_scene_empty`: Verify the response structure includes `main_scene_empty` field when conditions are met.

**File:** `tests/test_bridge/test_run_adaptive_timeout.py` (or new test file)

- `test_run_response_includes_main_scene_empty`: Mock bridge to return `{"main_scene_empty": true}`, verify Python tool passes it through.

---

## Section 3: Bug #14 — project_summary Cache Staleness

### Problem

`session._index` is loaded once in `session.load()` (line 50) and never invalidated for `project.godot` changes. Meanwhile, `_read_main_scene()` reads `project.godot` from disk each time. This creates internal inconsistency: `project_name` can be stale while `main_scene` is fresh in the same response.

### What to Change

#### 3a. Add project.godot Mtime Tracking

**File:** `src/godotiq/session.py`

Add a new instance variable: `self._project_godot_mtime: int = -1`

In `load()`, after `scan_project()`, record the mtime of `project.godot`:
```python
godot_path = self.project_root / "project.godot"
self._project_godot_mtime = self._get_mtime(godot_path)
```

#### 3b. Add project.godot Freshness Check

**File:** `src/godotiq/session.py`

Add a method:
```python
def _is_project_godot_fresh(self) -> bool:
    """Check if cached project index matches current project.godot."""
```

Compare `self._project_godot_mtime` against current `project.godot` mtime. If different, return False.

#### 3c. Make _index a Property with Auto-Freshness Check

**File:** `src/godotiq/session.py`

Replace direct `self._index` access with a property that auto-checks freshness. This avoids the maintenance trap of every consumer needing to call `ensure_index_fresh()` manually.

Rename `self._index` to `self._cached_index`. Add a property `index` that:
1. Checks `_is_project_godot_fresh()`
2. If stale, calls `_refresh_project_index()`
3. Returns the (now fresh) index

This way, any code accessing `session.index` automatically gets fresh data.

#### 3d. Targeted Index Update (Not Full Rescan)

**File:** `src/godotiq/session.py`

Add method `_refresh_project_index()` that:
1. Re-reads `project.godot` only
2. Updates `self._cached_index.project_name` and `self._cached_index.autoloads`
3. Updates `_project_godot_mtime`
4. Does NOT re-parse scripts or scenes (that's expensive and not needed)

**Known limitation:** Scene count and script count come from the full filesystem scan and are NOT refreshed by this mechanism. Only `project_name` and `autoloads` (which come from `project.godot`) are kept fresh. Document this.

### What NOT to Do

- Do NOT add a file watcher — over-engineering for a rare operation
- Do NOT call full `refresh()` on every project_summary call — too expensive
- Do NOT change `_read_main_scene()` — it already reads from disk, which is correct
- Do NOT add mtime tracking for every file in the project — only project.godot needs it for the index

### Tests to Add

**File:** `tests/test_tools/test_project_summary.py`

- `test_project_name_updates_after_godot_change`: Create a session, verify project_name. Write a new project.godot with different name. Call project_summary again. Verify it returns the new name.
- `test_autoloads_update_after_godot_change`: Same pattern for autoloads.
- `test_no_reparse_when_godot_unchanged`: Verify that `_refresh_project_index` is NOT called when mtime matches (use mock to track calls).

---

## Section 4: Bug #12 — suggest_scale Null Fallback

### Problem

Both reference mode and model mode return `recommended_scale: None` when no matches are found. The model mode text suggestion mentions "(1, 1, 1)" but the numeric field is null.

### What to Change

#### 4a. Add Numeric Fallback in Both Modes

**File:** `src/godotiq/tools/assets/__init__.py`

In reference mode (around line 441-449): when `not matched`, set `recommended_scale: [1.0, 1.0, 1.0]` instead of `None`. Add a field `"fallback": true` to indicate this is a default, not computed.

In model mode (around line 628-630): when no references and no asset_origins match, set `recommended_scale: [1.0, 1.0, 1.0]` and `"fallback": true`.

#### 4b. Always Return Consistent Schema

The response should ALWAYS have `recommended_scale` as a 3-element list, never None. Add `"fallback": true` ONLY when using the default — omit the field when scale is computed from actual references. This follows the codebase pattern of optional fields (present only when relevant).

#### 4c. Update Brief Mode Whitelist

**File:** `src/godotiq/tools/assets/__init__.py` (around line 663-665)

The brief mode filter restricts response keys to a whitelist. Add `"fallback"` to this whitelist so the flag is preserved in brief mode responses.

### What NOT to Do

- Do NOT change behavior when matches ARE found — only add fallback for empty case
- Do NOT change the suggestion text — keep it as additional context
- Do NOT add configurable default scale — (1,1,1) is the universal safe default

### Tests to Add

**File:** `tests/test_tools/test_suggest_scale.py`

- `test_reference_mode_empty_scene_returns_fallback_scale`: Empty scene in reference mode returns `[1.0, 1.0, 1.0]` with `fallback: true`
- `test_model_mode_no_references_returns_fallback_scale`: Model mode with no matches and no asset_origins returns fallback
- `test_model_mode_with_match_no_fallback_flag`: When match is found, `fallback` is false or absent
- `test_fallback_scale_is_always_list`: Verify recommended_scale is never None in any scenario

---

## Section 5: Bug #16 — Z-Fighting Noise Reduction

### Problem

`_check_z_fighting()` compares every pair of mesh nodes with O(n^2) complexity and no parent relationship check. Adjacent sibling tiles (normal game design) produce hundreds of false positives that fill the output cap.

### What to Change

#### 5a. Add Sibling Detection and Filtering

**File:** `src/godotiq/tools/spatial/__init__.py`
**Function:** `_check_z_fighting()` (lines 540-564)

Use the existing `_parent_path()` helper (lines 530-537) to check if two nodes share the same parent. If they do, **skip the pair entirely** — sibling nodes at the same position are intentional (tiled floors, walls, etc.).

Only report z-fighting between nodes that have DIFFERENT parents. This is the semantic distinction between "normal game layout" and "accidental overlap".

The logic change inside the inner loop:
```
if dist < _Z_FIGHTING_DISTANCE and a.node.name != b.node.name:
    # NEW: skip sibling pairs (same parent = intentional layout)
    if _parent_path(a.full_path) == _parent_path(b.full_path):
        continue
    ...
```

Also fix the `pair_key` deduplication to use `full_path` instead of `node.name`. Currently (line 548):
```
pair_key = f"{a.node.name}|{b.node.name}"
```
This causes same-named nodes in different tree branches to skip incorrectly. Change to:
```
pair_key = f"{a.full_path}|{b.full_path}"
```

#### 5b. Ensure WorldNode has full_path

Verify that `WorldNode` carries the full scene tree path (e.g., `"Room/Floor/TileA"`), not just the node name. The `_parent_path()` helper needs this. Check the `WorldNode` dataclass — if `full_path` is not already available, it needs to be added or derived from existing data.

#### 5c. Update Tests

The existing tests in `test_spatial_audit.py:321-418` expect sibling z-fighting to be reported. These tests need to be updated to expect sibling pairs to be FILTERED OUT, not just downgraded to "info".

### What NOT to Do

- Do NOT change the `_Z_FIGHTING_DISTANCE` threshold — 0.01 is correct
- Do NOT change severity levels — z-fighting that IS reported should stay "info"
- Do NOT add configuration for the sibling filter — it should always be on
- Do NOT optimize the O(n^2) algorithm — for filtered results, the count is small enough

### Tests to Add / Modify

**File:** `tests/test_tools/test_spatial_audit.py`

- **Modify** `test_sibling_z_fighting_downgraded`: Change to expect 0 issues (siblings filtered out entirely)
- **Modify** `test_root_level_siblings_downgraded`: Same — expect 0 issues for root siblings
- **Add** `test_non_sibling_z_fighting_reported`: Two mesh nodes with DIFFERENT parents at same position → reported at "info"
- **Add** `test_mixed_sibling_and_non_sibling`: Scene with both sibling and non-sibling overlaps → only non-sibling pairs reported
- **Add** `test_large_grid_no_noise`: 20 sibling tiles → 0 z-fighting issues (regression test for noise)
- **Add** `test_root_level_nodes_empty_full_path`: Nodes with `full_path=""` (root nodes) treated as siblings — should produce 0 issues
- **Add** `test_pair_key_uses_full_path_not_name`: Two nodes with same name but different full_paths are NOT deduplicated

---

## Section 6: Documentation and Cleanup

### 6a. Update Docstrings

**Files to update:**
- `exec_code.py` docstring: Add security note about blocked patterns and limitations
- `run.py` docstring: Document `main_scene_empty` response field
- `spatial/__init__.py` `_check_z_fighting()` docstring: Document sibling filtering behavior

### 6b. Contract Test File

**File:** `tests/test_godot_addon_contracts.py`

This file already exists (untracked). Ensure it includes:
- Blocked pattern consistency tests (Python vs GDScript)
- Main scene auto-set prevention contract
- Any other cross-layer invariants

### 6c. Version Bump

After all fixes are verified:
- `pyproject.toml`: version stays at 0.3.4 (already bumped)
- `plugin.cfg`: already at 0.3.4
- `godotiq_server.gd` ADDON_VERSION: already at "0.3.4"

No version change needed — the uncommitted changes already have 0.3.4.

---

## Implementation Order

The sections are ordered by priority but also by dependency:

1. **Section 1 (exec security)** — No dependencies. Most critical. Do first.
2. **Section 2 (run main_scene)** — No dependencies on Section 1. Can parallelize.
3. **Section 3 (project_summary staleness)** — Independent of 1 and 2.
4. **Section 4 (suggest_scale fallback)** — Independent. Simple change.
5. **Section 5 (z-fighting noise)** — Independent. Requires test updates.
6. **Section 6 (docs/cleanup)** — Do last, after all fixes verified.

Sections 1-5 can be implemented in parallel if desired, since they touch different files with no overlap.

---

## Files Modified Per Section

| Section | Python Files | GDScript Files | Test Files |
|---------|-------------|----------------|------------|
| 1 (exec) | exec_code.py | godotiq_server.gd, godotiq_runtime.gd | test_exec_code.py, test_godot_addon_contracts.py |
| 2 (run) | run.py | godotiq_server.gd | test_godot_addon_contracts.py, test_run_*.py |
| 3 (summary) | session.py, memory/__init__.py | — | test_project_summary.py |
| 4 (scale) | assets/__init__.py | — | test_suggest_scale.py |
| 5 (z-fight) | spatial/__init__.py | — | test_spatial_audit.py |
| 6 (docs) | exec_code.py, run.py, spatial/__init__.py | — | test_godot_addon_contracts.py |

**Note:** Sections 1 and 2 both modify `godotiq_server.gd` — if implementing in parallel, merge carefully. The changes are in different functions (`_handle_exec_editor` vs `_handle_run`) so they won't conflict.

---

## Risk Assessment

| Section | Risk | Mitigation |
|---------|------|------------|
| 1 (exec) | False positives blocking legitimate code | Test with real-world GDScript patterns; variable alias regex is narrow |
| 2 (run) | Breaking projects that depend on auto-set | Response includes hint; explicit set_main_scene still works |
| 3 (summary) | Performance regression from extra mtime check | Single stat() call on project.godot — negligible |
| 4 (scale) | Returning (1,1,1) when a different default would be better | Marked as `fallback: true` so caller knows |
| 5 (z-fight) | Missing real z-fighting between siblings | Edge case — siblings at identical positions with different meshes IS possible but extremely rare and still cosmetic |

---

## Verified: WorldNode.full_path

`WorldNode.full_path: str` is confirmed at `src/godotiq/parsers/scene_resolver.py:58` — "Slash-separated path from root." No additional work needed for Section 5's `_parent_path()` usage.

---

## Backlog: Minor Bugs (Not In Scope, Track for v0.3.5)

These were discovered during the scalability audit. Not critical enough for this release, but should be tracked.

### Bug #17 — godotiq_watch: State Lost on Game Crash
- **File:** `src/godotiq/tools/bridge/watch.py`
- No max duration, no heartbeat, no cleanup on bridge disconnect
- If game crashes, watch stays pending until bridge timeout
- **Fix:** Add optional `max_duration_ms` parameter; auto-cleanup on disconnect

### Bug #18 — godotiq_screenshot: camera_position Silently Ignored in Game Context
- **File:** `src/godotiq/tools/bridge/screenshot.py` (lines 58-69)
- `camera_position` and `camera_target` are passed only for `viewport="editor"`
- In game context, these parameters are silently dropped — no warning to caller
- **Fix:** Return `"warning": "camera_position ignored in game context"` when both are set

### Bug #19 — godotiq_state_inspect: Unstructured Error for Missing Methods
- **File:** `src/godotiq/tools/bridge/state_inspect.py`
- Calling a non-existent method (e.g., `get_destroyed_fraction()`) returns generic addon error
- Not clear if method name is wrong or doesn't exist on node type
- **Fix:** Improve error message or add docstring warning about behavior
