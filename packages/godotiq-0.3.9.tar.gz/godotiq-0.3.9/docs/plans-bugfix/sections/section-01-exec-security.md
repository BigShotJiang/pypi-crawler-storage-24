Now I have all the context I need. Let me generate the section content.

# Section 1: Bug #13 -- exec_code Security Hardening

## Overview

The `godotiq_exec` tool has three layers of security failure that allow AI agents to bypass filesystem and OS restrictions. This section hardens exec_code by adding missing blocked patterns to GDScript handlers, adding a Python-side pre-check as defense-in-depth, and detecting the most common variable aliasing bypass.

**Priority:** CRITICAL -- This is the highest-priority fix in v0.3.4.
**Dependencies:** None. This section is fully independent.

## Background

There are two execution contexts for `godotiq_exec`:

- **Game context** (`godotiq_runtime.gd`): Code runs in a RefCounted sandbox with no scene tree access. The runtime checks a `blocked_patterns` array before execution. Currently blocks: `DirAccess.remove`, `OS.execute`, `OS.kill`, `OS.shell_open`, `FileAccess.open`.
- **Editor context** (`godotiq_server.gd`): Code runs with full editor access. The server checks a `blocked_patterns` array before execution. Currently blocks: `DirAccess.remove`, `OS.execute`, `OS.kill`, `OS.shell_open`. **Missing:** `FileAccess.open`.

The Python layer (`exec_code.py`) currently performs zero validation -- it passes raw code directly to the bridge with no pre-flight checks.

### The Three Failures

1. **Editor context does not block `FileAccess.open`** -- The `godotiq_server.gd` blocked_patterns array (line 1254) is missing `FileAccess.open`. An AI agent can read/write arbitrary files in editor context.
2. **Python layer performs zero validation** -- `exec_code.py` sends code directly to the bridge. If the GDScript-side blocking fails or is bypassed, there is no fallback.
3. **Substring matching is bypassable** -- Both contexts use `code.find(pattern)` for blocking. Variable aliasing (`var FA = FileAccess; FA.open(...)`) bypasses the substring `"FileAccess.open"`.

## Files to Modify

| File | Change |
|------|--------|
| `godot-addon/addons/godotiq/godotiq_server.gd` | Add missing patterns to editor `blocked_patterns` (around line 1254) |
| `godot-addon/addons/godotiq/godotiq_runtime.gd` | Add missing patterns to game `blocked_patterns` (around line 559) |
| `src/godotiq/tools/bridge/exec_code.py` | Add Python-side pattern pre-check and alias detection |
| `tests/test_bridge/test_exec_code.py` | Add security tests |
| `tests/test_godot_addon_contracts.py` | Add cross-layer contract tests |

## Tests (Write First)

All tests go into existing files. Tests should be written before implementation so they initially fail.

### File: `tests/test_bridge/test_exec_code.py`

Add a new test class `TestExecCodeSecurityBlocking` to the existing file. These tests verify that the Python-side pre-check blocks dangerous patterns before they reach the bridge. The bridge mock should never be called for blocked code.

Tests to add (as stubs with docstrings):

```python
class TestExecCodeSecurityBlocking:
    """Tests for Python-side pattern pre-check (defense-in-depth)."""

    @pytest.mark.asyncio
    async def test_blocked_fileaccess_open_game_context(self):
        """Code containing 'FileAccess.open' in game context returns BLOCKED without calling bridge."""

    @pytest.mark.asyncio
    async def test_blocked_fileaccess_open_editor_context(self):
        """Code containing 'FileAccess.open' in editor context returns BLOCKED without calling bridge."""

    @pytest.mark.asyncio
    async def test_blocked_diraccess_open_both_contexts(self):
        """Code containing 'DirAccess.open' is blocked in both game and editor contexts."""

    @pytest.mark.asyncio
    async def test_blocked_fileaccess_get_file_as_string(self):
        """Code containing 'FileAccess.get_file_as_string' is blocked in both contexts."""

    @pytest.mark.asyncio
    async def test_blocked_fileaccess_get_file_as_bytes(self):
        """Code containing 'FileAccess.get_file_as_bytes' is blocked in both contexts."""

    @pytest.mark.asyncio
    async def test_blocked_variable_alias_fileaccess(self):
        """'var FA = FileAccess' pattern detected and blocked with descriptive error."""

    @pytest.mark.asyncio
    async def test_blocked_variable_alias_diraccess(self):
        """'var DA = DirAccess' pattern detected and blocked."""

    @pytest.mark.asyncio
    async def test_blocked_variable_alias_with_type_annotation(self):
        """'var FA : Variant = FileAccess' also blocked (type annotation variant)."""

    @pytest.mark.asyncio
    async def test_diraccess_remove_absolute_caught_by_remove_pattern(self):
        """'DirAccess.remove_absolute' caught by 'DirAccess.remove' substring match."""

    @pytest.mark.asyncio
    async def test_legitimate_code_not_blocked(self):
        """Code without blocked patterns passes through to bridge normally."""

    @pytest.mark.asyncio
    async def test_legitimate_code_with_fileaccess_in_comment_still_blocked(self):
        """Code using FileAccess in a comment IS blocked (best-effort, accepted behavior)."""

    def test_blocked_patterns_constant_exists_and_matches(self):
        """_BLOCKED_PATTERNS constant exists and contains all expected patterns."""
```

**Test pattern for blocked tests:** Each test should call `exec_code(code=..., context=...)` directly -- no bridge mock needed because the function should return BLOCKED before ever calling `get_bridge()`. Verify `result["status"] == "BLOCKED"` and that `result["error"]` contains the pattern name. For the legitimate-code test, mock the bridge as in existing tests to verify the call passes through.

**Test pattern for the alias tests:** Pass code like `"func run():\n\tvar FA = FileAccess\n\tFA.open('res://project.godot', FileAccess.READ)"`. Verify status is BLOCKED and error mentions "Indirect reference" or similar.

**Test for _BLOCKED_PATTERNS constant:** Import `_BLOCKED_PATTERNS` from `godotiq.tools.bridge.exec_code` and verify it is a tuple/list containing exactly the expected 8 patterns: `DirAccess.remove`, `DirAccess.open`, `FileAccess.open`, `FileAccess.get_file_as_string`, `FileAccess.get_file_as_bytes`, `OS.execute`, `OS.kill`, `OS.shell_open`.

### File: `tests/test_godot_addon_contracts.py`

Add a new test class `TestExecBlockedPatternContracts` to the existing file. These are static contract tests that parse the GDScript source files to verify blocked patterns are present. They do NOT require a running Godot instance -- they read the `.gd` files as text.

```python
class TestExecBlockedPatternContracts:
    """Contract tests: verify GDScript blocked_patterns arrays contain required patterns."""

    def test_editor_blocked_patterns_include_fileaccess_open(self):
        """Parse godotiq_server.gd, verify 'FileAccess.open' is in editor blocked_patterns."""

    def test_editor_blocked_patterns_include_fileaccess_get_file_as_string(self):
        """Parse godotiq_server.gd, verify 'FileAccess.get_file_as_string' is in editor blocked_patterns."""

    def test_editor_blocked_patterns_include_diraccess_open(self):
        """Parse godotiq_server.gd, verify 'DirAccess.open' is in editor blocked_patterns."""

    def test_game_blocked_patterns_include_diraccess_open(self):
        """Parse godotiq_runtime.gd, verify 'DirAccess.open' is in game blocked_patterns."""

    def test_game_blocked_patterns_include_fileaccess_get_file_as_string(self):
        """Parse godotiq_runtime.gd, verify 'FileAccess.get_file_as_string' is in game blocked_patterns."""

    def test_python_patterns_match_gdscript_patterns(self):
        """Cross-layer consistency: Python _BLOCKED_PATTERNS matches GDScript blocked_patterns."""
```

**Contract test pattern:** Read the `.gd` file as text using `Path(...).read_text()`. Use the existing `ADDON_SOURCE` constant (already defined in the file at line 16) to locate files. Extract the `blocked_patterns` array content by searching for the `blocked_patterns` variable declaration and parsing the lines between `[` and `]`. Verify each required pattern string appears in the extracted array. For the cross-layer test, import `_BLOCKED_PATTERNS` from Python and compare against the extracted GDScript list.

**Important:** These contract tests should NOT use the `godot_bin` fixture or `_run_godot_json` helper. They are pure text-parsing tests with no Godot dependency. They use `ADDON_SOURCE / "godotiq_server.gd"` and `ADDON_SOURCE / "godotiq_runtime.gd"` paths.

## Implementation Details

### 1a. Add Missing Patterns to GDScript Blocked Lists

**File:** `godot-addon/addons/godotiq/godotiq_server.gd`
**Location:** The `blocked_patterns` array in `_handle_exec_editor()` (around line 1254)

Replace the current editor blocked_patterns:
```
var blocked_patterns: Array = [
    "DirAccess.remove",
    "OS.execute",
    "OS.kill",
    "OS.shell_open",
]
```

With the unified list:
```
# Safety: blocked patterns — keep in sync with godotiq_runtime.gd and Python exec_code._BLOCKED_PATTERNS
# Note: DirAccess.remove also catches DirAccess.remove_absolute() via substring match
var blocked_patterns: Array = [
    "DirAccess.remove",
    "DirAccess.open",
    "FileAccess.open",
    "FileAccess.get_file_as_string",
    "FileAccess.get_file_as_bytes",
    "OS.execute",
    "OS.kill",
    "OS.shell_open",
]
```

**File:** `godot-addon/addons/godotiq/godotiq_runtime.gd`
**Location:** The `blocked_patterns` array in the game exec handler (around line 559)

Replace the current game blocked_patterns with the same unified list (identical to the editor list above). The game context currently has `FileAccess.open` but is missing `DirAccess.open`, `FileAccess.get_file_as_string`, and `FileAccess.get_file_as_bytes`.

Both contexts should have **identical** blocked_patterns arrays. Add the same sync comment to both.

### 1b. Add Python-Side Pattern Pre-Check

**File:** `src/godotiq/tools/bridge/exec_code.py`

Add a module-level constant after the existing imports and before `TOOL_NAME`:

```python
import re

# Defense-in-depth: blocked patterns matching the GDScript side.
# Keep in sync with godotiq_server.gd and godotiq_runtime.gd blocked_patterns arrays.
_BLOCKED_PATTERNS: tuple[str, ...] = (
    "DirAccess.remove",
    "DirAccess.open",
    "FileAccess.open",
    "FileAccess.get_file_as_string",
    "FileAccess.get_file_as_bytes",
    "OS.execute",
    "OS.kill",
    "OS.shell_open",
)

# Catches: var FA = FileAccess, var DA : Variant = DirAccess, etc.
_ALIAS_RE = re.compile(r'var\s+\w+[^=]*=\s*(FileAccess|DirAccess)\b')
```

In the `exec_code()` function, add the pre-flight check **after** the empty-code and invalid-context checks, but **before** the `get_bridge()` call:

```python
# Defense-in-depth: check for blocked patterns before sending to bridge.
# This is best-effort — GDScript lacks eval(), so string-based construction
# can build strings but cannot execute them as code. The real sandbox in game
# context is the RefCounted base class (no scene tree access). Editor context
# is inherently trusted (full editor access by design) but we block obvious
# data corruption patterns. Pattern matching is NOT a security boundary.
for pattern in _BLOCKED_PATTERNS:
    if pattern in code:
        return {"status": "BLOCKED", "result": "", "error": f"Blocked pattern: {pattern}"}

alias_match = _ALIAS_RE.search(code)
if alias_match:
    return {
        "status": "BLOCKED",
        "result": "",
        "error": f"Indirect reference to blocked class: {alias_match.group(1)}",
    }
```

This block goes at approximately line 63 of the current file (after the context validation, before `bridge = await get_bridge()`).

### 1c. Variable Alias Detection Details

The regex `r'var\s+\w+[^=]*=\s*(FileAccess|DirAccess)\b'` matches:
- `var FA = FileAccess` -- direct alias
- `var FA: Variant = FileAccess` -- with type annotation
- `var my_file_class = FileAccess` -- any identifier
- `var DA = DirAccess` -- DirAccess variant

It does NOT match:
- `var f = FileAccess.open(...)` -- this is caught by the substring check for `FileAccess.open`
- String concatenation or Callable-based bypasses -- not practically exploitable since GDScript has no `eval()`

### 1d. Warning Comment

The comment block described in section 1b above serves as the warning about limitations. It should be placed directly above the pattern-checking loop inside `exec_code()`.

## What NOT to Do

- Do NOT implement AST parsing -- no Python GDScript parser exists
- Do NOT add `config.is_file_protected()` calls to exec_code -- the protected files list is about path-based file operations, not code execution patterns
- Do NOT change the GDScript sandbox model (RefCounted base) -- that works correctly
- Do NOT add more blocked patterns beyond filesystem and OS access -- keep the list minimal and auditable
- Do NOT remove or modify existing tests -- only add new ones

## Verification

After implementation, run:

```bash
cd /Users/salvatorefarruggio/Desktop/godotiq
pytest tests/test_bridge/test_exec_code.py -v
pytest tests/test_godot_addon_contracts.py -v
pytest -v  # Full suite -- must remain at 0 failures
```

The contract tests in `test_godot_addon_contracts.py` that parse GDScript files do NOT require a Godot binary. They will run in any environment. The existing tests in that file that use `godot_bin` will skip gracefully if Godot is not installed.