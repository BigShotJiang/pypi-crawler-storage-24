<!-- PROJECT_CONFIG
runtime: python-uv
test_command: uv run pytest
END_PROJECT_CONFIG -->

<!-- SECTION_MANIFEST
section-01-exec-security
section-02-run-main-scene
section-03-project-summary-cache
section-04-suggest-scale-fallback
section-05-z-fighting-noise
section-06-docs-cleanup
END_MANIFEST -->

# Implementation Sections Index

## Dependency Graph

| Section | Depends On | Blocks | Parallelizable |
|---------|------------|--------|----------------|
| section-01-exec-security | - | section-06 | Yes |
| section-02-run-main-scene | - | section-06 | Yes |
| section-03-project-summary-cache | - | section-06 | Yes |
| section-04-suggest-scale-fallback | - | section-06 | Yes |
| section-05-z-fighting-noise | - | section-06 | Yes |
| section-06-docs-cleanup | 01, 02, 03, 04, 05 | - | No |

## Execution Order

1. section-01 through section-05 (all independent, can run in parallel)
2. section-06-docs-cleanup (after all fixes verified)

**Note:** Sections 01 and 02 both modify `godotiq_server.gd` but in different functions (`_handle_exec_editor` vs `_handle_run`). No conflict.

## Section Summaries

### section-01-exec-security
**Bug #13 CRITICAL** — Add FileAccess.open + DirAccess.open + static read methods to editor blocked_patterns. Add Python-side pattern pre-check with variable alias detection. Add contract tests for cross-layer pattern consistency.

**Files:** exec_code.py, godotiq_server.gd, godotiq_runtime.gd, test_exec_code.py, test_godot_addon_contracts.py

### section-02-run-main-scene
**Bug #10 HIGH** — Remove auto-set of main_scene in `_handle_run()`. Replace with `main_scene_empty: true` response flag and hint. Update Python docstring.

**Files:** godotiq_server.gd, run.py, test_godot_addon_contracts.py

### section-03-project-summary-cache
**Bug #14 MEDIUM** — Add project.godot mtime tracking. Make `_index` a property with auto-freshness check. Add targeted refresh that re-reads project.godot only.

**Files:** session.py, memory/__init__.py, test_project_summary.py

### section-04-suggest-scale-fallback
**Bug #12 MEDIUM** — Return `[1.0, 1.0, 1.0]` with `fallback: true` instead of None when no matches found. Update brief mode whitelist.

**Files:** assets/__init__.py, test_suggest_scale.py

### section-05-z-fighting-noise
**Bug #16 LOW** — Filter sibling pairs (same parent path) from z-fighting detection. Fix pair_key to use full_path. Update existing tests.

**Files:** spatial/__init__.py, test_spatial_audit.py

### section-06-docs-cleanup
Docstring updates for exec_code.py, run.py, spatial/__init__.py. Contract test consolidation. Final test suite verification.

**Files:** exec_code.py, run.py, spatial/__init__.py, test_godot_addon_contracts.py
