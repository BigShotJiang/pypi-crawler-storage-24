Now I have all the context I need. Let me generate the section content.

# Section 6: Documentation and Cleanup

## Overview

This section covers docstring updates, contract test consolidation, and final verification after all bug fixes (sections 1-5) are complete. It touches three Python source files for documentation updates and one test file for contract test consolidation.

**Dependencies:** Sections 1 through 5 must be complete before implementing this section. This section updates docstrings and tests to reflect the changes made in those sections.

## Files to Modify

| File | Change Type |
|------|-------------|
| `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/exec_code.py` | Docstring update |
| `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/run.py` | Docstring update |
| `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/spatial/__init__.py` | Docstring update |
| `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_godot_addon_contracts.py` | Contract test consolidation |

## Tests

The TDD plan for this section states:

> No TDD tests -- this section is docstring updates and contract test consolidation. Verified by running full test suite after changes.

Validation is done by running `uv run pytest` and confirming all 1,351+ tests continue to pass, including new tests added in sections 1-5. No new test stubs are needed for this section itself.

However, this section does need to ensure the contract test file (`test_godot_addon_contracts.py`) is properly organized and includes the tests from sections 1 and 2 in a consolidated, well-structured form. Those tests were defined and implemented in earlier sections; this section verifies they are present and coherent.

## Implementation Details

### 6a. Update exec_code.py Docstring

**File:** `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/exec_code.py`

The module-level docstring (lines 1-8) and the `exec_code()` function docstring (lines 38-62) need security documentation added by section 1. This section verifies that documentation is present and adds any missing pieces.

The `exec_code()` function docstring should include a "Security" section explaining:

- The Python layer performs a pre-flight check against `_BLOCKED_PATTERNS` before sending code to the bridge
- Blocked patterns include filesystem access (`FileAccess.open`, `FileAccess.get_file_as_string`, `FileAccess.get_file_as_bytes`, `DirAccess.open`, `DirAccess.remove`) and OS access (`OS.execute`, `OS.kill`, `OS.shell_open`)
- Variable aliasing detection catches `var <identifier> = FileAccess` and `var <identifier> = DirAccess` patterns
- Pattern matching is best-effort, not a security boundary
- GDScript lacks `eval()`, so string-based construction can build strings but cannot execute them as code
- The real sandbox in game context is the RefCounted base class (no scene tree access)
- Editor context is inherently trusted (full editor access by design) but obvious data corruption patterns are blocked

If section 1 already added a comment block with this information, verify it is accurate and complete. If it is missing or incomplete, add it.

The comment block should be placed either as a module-level comment near the `_BLOCKED_PATTERNS` constant (added by section 1) or within the `exec_code()` docstring under a "Security" subsection. Prefer the module-level comment near `_BLOCKED_PATTERNS` for maintainability, since the patterns and their documentation live together.

### 6b. Update run.py Docstring

**File:** `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/bridge/run.py`

The `run()` function docstring (currently lines 46-56) needs to document the `main_scene_empty` response field that section 2 introduced.

Current docstring Returns section:
```
Returns:
    Dict with action, success, scene, waited_seconds from bridge.
```

Updated Returns section should be:
```
Returns:
    Dict with action, success, scene, waited_seconds from bridge.
    If no main_scene is configured in project.godot and a specific scene
    was requested, the response will include ``main_scene_empty: true``
    and a ``hint`` field suggesting the caller use set_main_scene.
```

Remove any mention of auto-setting main_scene (there should not be any in the current docstring, but verify).

### 6c. Update _check_z_fighting Docstring

**File:** `/Users/salvatorefarruggio/Desktop/godotiq/src/godotiq/tools/spatial/__init__.py`

The `_check_z_fighting()` function (line 540) currently has a one-line docstring:
```python
"""Detect mesh-geometry nodes at nearly identical positions."""
```

Update this to document the sibling filtering behavior added by section 5:

```python
"""Detect mesh-geometry nodes at nearly identical positions.

Sibling nodes (sharing the same parent path) are excluded from
z-fighting detection because co-located siblings are a normal game
design pattern (tiled floors, walls, modular pieces). Only pairs
with different parent paths are reported.

Uses full_path for pair deduplication to correctly handle same-named
nodes in different subtrees.
"""
```

### 6d. Contract Test File Consolidation

**File:** `/Users/salvatorefarruggio/Desktop/godotiq/tests/test_godot_addon_contracts.py`

This file already exists (currently untracked in git) and contains several test classes:

- `TestInputKeyNaming` -- existing, pre-v0.3.4
- `TestBuildSceneNaming` -- existing, pre-v0.3.4
- `TestGameResponseCorrelation` -- existing, pre-v0.3.4
- `TestCheckErrorsClassification` -- existing, pre-v0.3.4
- `TestUiMapContracts` -- existing, pre-v0.3.4

Sections 1 and 2 added new contract test classes to this file. Verify these are present:

**From section 1 (exec security):**
- Tests verifying `godotiq_server.gd` editor `blocked_patterns` array contains `"FileAccess.open"`, `"FileAccess.get_file_as_string"`, `"DirAccess.open"`
- Tests verifying `godotiq_runtime.gd` game `blocked_patterns` contains `"DirAccess.open"`, `"FileAccess.get_file_as_string"`
- Cross-layer consistency test verifying Python `_BLOCKED_PATTERNS` matches GDScript blocked_patterns

**From section 2 (run main_scene):**
- Test verifying `godotiq_server.gd` `_handle_run` function body does NOT call `_set_main_scene_internal`
- Test verifying `_handle_run` response structure includes `main_scene_empty` field

Consolidation tasks:
1. Verify all contract test classes from sections 1 and 2 are present and organized
2. Ensure consistent test class naming (e.g., `TestExecSecurityContracts`, `TestRunMainSceneContracts`)
3. Verify all tests use the same `_run_godot_json` helper or regex-based source parsing pattern as the existing tests
4. Ensure the file has a clear module docstring explaining what contract tests are and why they exist

The existing module docstring is:
```python
"""Godot headless contract tests for addon-side GDScript behavior."""
```

This is adequate. If section 1 or 2 changed it, verify it still accurately describes the file's purpose.

### 6e. Version Verification

No version changes needed. The uncommitted changes already have version 0.3.4 in:
- `pyproject.toml`
- `godot-addon/addons/godotiq/plugin.cfg`
- `godotiq_server.gd` `ADDON_VERSION`

Verify these are consistent by checking each file. Do not change any version numbers.

## Verification Steps

After all changes are complete:

1. Run `uv run pytest -v` and confirm all tests pass (baseline was 1,351; expect more from sections 1-5)
2. Verify no regressions by checking test count is >= 1,351
3. Spot-check that docstrings render correctly (no broken RST/markdown in docstrings)
4. Verify contract tests in `test_godot_addon_contracts.py` cover cross-layer invariants from sections 1 and 2
5. Run `uv run python -c "from godotiq.server import mcp; print('OK')"` as a smoke check

## What NOT to Do

- Do NOT add new functional behavior -- this section is documentation and cleanup only
- Do NOT change any version numbers -- already at 0.3.4
- Do NOT duplicate tests from sections 1-5 -- only verify they exist and are well-organized
- Do NOT modify GDScript files -- those changes belong to sections 1 and 2
- Do NOT add new test files -- all test additions belong to earlier sections