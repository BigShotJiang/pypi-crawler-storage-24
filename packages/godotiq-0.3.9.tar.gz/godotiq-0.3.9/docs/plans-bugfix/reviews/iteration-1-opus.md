# Opus Review

**Model:** claude-opus-4-6
**Generated:** 2026-03-20T16:30:00Z

---

## Overall Assessment

The plan is well-researched, correctly identifies root causes, and proposes proportional fixes. Below are specific issues, gaps, and concerns.

## Section 1: exec_code Security

1. **Missing bypass: `FileAccess.get_file_as_string` / `FileAccess.get_file_as_bytes`** — Static methods that read files without `.open()`. Read-only but still allows reading `.godotiq.json`. Decide: block or accept.
2. **Variable alias regex too narrow** — `r'var\s+\w+\s*=\s*(FileAccess|DirAccess)\b'` won't match `var FA : Variant = FileAccess`. Broaden to `r'var\s+\w+[^=]*=\s*(FileAccess|DirAccess)\b'`.
3. **Multi-line bypass unaddressed on GDScript side** — Consider Python-side whitespace normalization before matching.
4. **`DirAccess.remove_absolute` caught by `DirAccess.remove` substring** — Document this intentional behavior, add test.
5. **Python patterns intentionally stricter than GDScript** — Document this design decision.

## Section 2: godotiq_run Main Scene

1. **Breaking change needs communication** — Add changelog/migration note.
2. **Response hint should be actionable** — Include exact `set_main_scene` command in hint.
3. **Contract test is fragile** — Parsing GDScript source for function name is brittle. Consider verifying behavior instead of implementation.

## Section 3: project_summary Cache

1. **Scene/script counts NOT fixed** — Plan only refreshes `project_name` and `autoloads`. Success criterion #5 won't be fully met. Acknowledge as known limitation.
2. **Coupling concern** — `ensure_index_fresh()` called from tool modules rather than session internals. Better: make `_index` property auto-check, or call at session level.
3. **Race condition negligible** — `st_mtime_ns` resolution is fine.

## Section 4: suggest_scale Fallback

1. **Brief mode filter missing `"fallback"` key** — Add to whitelist at line 663-665.
2. **Schema noise** — Consider `"fallback"` only when `true`, not `false`.

## Section 5: Z-Fighting Noise

1. **Semantic edge case** — Sibling nodes with different meshes at same position (floor tile + rug under same parent) ARE z-fighting. Plan acknowledges as acceptable tradeoff.
2. **Pre-existing pair_key bug** — Uses `a.node.name` not `full_path` for deduplication. Two nodes with same name in different paths skip incorrectly. Plan should note.
3. **Empty full_path edge case** — Root nodes have `full_path=""`, both get `_parent_path()=""`, treated as siblings. Probably correct, should be tested.
4. **WorldNode.full_path confirmed** — Already exists in `WorldNode` dataclass. No additional work.

## Test Plan Gaps

1. No negative test for legitimate code containing blocked patterns in string literals.
2. No integration test for Python-GDScript pattern consistency (contract test with regex parsing is fragile).
3. No test for `DirAccess.remove_absolute` vs `DirAccess.remove` substring matching.
4. No test for empty `full_path` in sibling z-fighting detection.
5. No performance test for Section 3's stat() addition.

## Recommended Additions

1. Block `FileAccess.get_file_as_string` and `FileAccess.get_file_as_bytes` in both contexts
2. Broaden alias regex for type annotations
3. Acknowledge stale counts as known limitation
4. Add `"fallback"` to brief-mode whitelist
5. Fix pair_key to use full_path
6. Add targeted tests per gaps above
7. Move ensure_index_fresh() to session property
