# GodotIQ Bug Fix Research — Codebase Analysis

## 1. Project Baseline

### Git State
- **Current HEAD**: e74a85c (v0.3.3 stable baseline)
- **Commits since v0.3.3**: 0 (all changes are uncommitted)
- **Uncommitted modifications**: 19 files modified (unstaged), 0 staged

### Modified Files
**Python/Source (7):** session.py, bridge/__init__.py, bridge/exec_code.py, bridge/explore.py, bridge/input_sim.py, code/__init__.py, sync_version.py
**Tests (7):** conftest.py, test_exec_code.py, test_exec_editor.py, test_explore.py, test_validate.py, test_version.py, test_version_sync.py
**Godot Addon (3):** godotiq_runtime.gd, godotiq_server.gd, plugin.cfg
**Config (1):** pyproject.toml

### Untracked Files
- `docs/plans-bugfix/` (this planning directory)
- `tests/test_godot_addon_contracts.py` (new test file)

### Test Results
- **1,351 tests passing**, 3 skipped, 0 failures
- Execution time: 16.57 seconds
- All test suites green

---

## 2. Bug #13 — CRITICAL: exec Bypasses Protected Files

### 2.1 Python Layer: NO VALIDATION

**File:** `src/godotiq/tools/bridge/exec_code.py` (lines 33-87)
- Zero code validation before bridge send
- Does NOT import or call `config.is_file_protected()`
- Simply passes raw code string to bridge
- Delegates ALL security to Godot addon

### 2.2 Editor Context: FileAccess.open NOT BLOCKED

**File:** `godot-addon/addons/godotiq/godotiq_server.gd` (lines 1254-1267)

Editor `blocked_patterns`:
```gdscript
var blocked_patterns: Array = [
    "DirAccess.remove",
    "OS.execute",
    "OS.kill",
    "OS.shell_open",
]
```

**MISSING: `"FileAccess.open"`** — This means in editor context, ANY file can be read/written:
```gdscript
func run():
    var f = FileAccess.open("res://project.godot", FileAccess.WRITE)
    f.store_string("corrupted")
```

### 2.3 Game Context: FileAccess.open IS Blocked (but bypassable)

**File:** `godot-addon/addons/godotiq/godotiq_runtime.gd` (lines 559-573)

Game `blocked_patterns`:
```gdscript
var blocked_patterns: Array = [
    "DirAccess.remove",
    "OS.execute",
    "OS.kill",
    "OS.shell_open",
    "FileAccess.open",
]
```

FileAccess.open IS in the list, but matching is `code.find(pattern)` — simple substring.

### 2.4 Pattern Matching: Trivially Bypassable

Both contexts use `code.find(pattern) != -1` — plain substring search.

**Verified bypass vectors:**
1. **Variable aliasing**: `var FA = FileAccess; FA.open(...)` — pattern "FileAccess.open" not found
2. **Multi-line splitting**: `FileAccess.\n    open(...)` — newline breaks substring
3. **Callable references**: `Callable(FileAccess, "open")` — no substring match

### 2.5 Protected Files Config: UNUSED by exec_code

**File:** `src/godotiq/config.py` (lines 16-22, 58-63)

```python
_DEFAULT_PROTECTED = ["project.godot", ".godot/**", ".godotiq/**", "*.import", "saves/**"]
```

`is_file_protected()` is called ONLY from:
- `file_ops.py` (lines 87-99, 233, 257-260, 282, 514-517)
- `script_ops.py` (lines 72-79, 205-206, 251-252, 340-341)

**NOT called from exec_code.py** — complete bypass of protection system.

### 2.6 Fallback Execution Path

`_exec_editor_via_file()` (godotiq_server.gd:1340-1356) writes code to disk as temp file then loads it. Pattern check happens BEFORE this, but the temp file itself uses `FileAccess.open` internally (server code, not user code).

### 2.7 Security Test Coverage: ZERO

- `test_exec_code.py` (194 lines): Tests empty code, valid execution, context routing, timeout — NO security tests
- `test_exec_editor.py` (94 lines): Tests compile errors, responses — NO security tests
- No test for bypass attempts, no test for FileAccess in editor

---

## 3. Bug #10 — HIGH: godotiq_run Writes main_scene Permanently

### 3.1 The Side Effect

**File:** `godot-addon/addons/godotiq/godotiq_server.gd`

**Trigger conditions** (lines 529-535):
```gdscript
if not is_current and resolved_path != "":
    var current_main = ProjectSettings.get_setting("application/run/main_scene", "")
    if current_main == "":
        _set_main_scene_internal(resolved_path)
        main_scene_set = true
```

All three must be true:
1. `not is_current` — specific scene requested (not "current")
2. `resolved_path != ""` — valid scene resolved
3. `current_main == ""` — no main_scene configured yet

### 3.2 The Permanent Write

**`_set_main_scene_internal()`** (lines 411-414):
```gdscript
func _set_main_scene_internal(scene_path: String) -> bool:
    ProjectSettings.set_setting("application/run/main_scene", scene_path)
    var err := ProjectSettings.save()  # WRITES TO DISK
    return err == OK
```

### 3.3 Python Side: No Prevention

**File:** `src/godotiq/tools/bridge/run.py`
- No `suppress_config_write` parameter
- No documentation of the side effect in docstring
- Response includes `main_scene_set: true` flag but caller can't prevent it

### 3.4 When It Does NOT Trigger
- `run(action="stop")` — no scene involved
- `run(scene="current")` — is_current = true
- Project already has main_scene — condition 3 fails

### 3.5 Test Coverage: NONE
- `test_run_adaptive_timeout.py` tests only timeout calculation
- No tests for main_scene modification behavior

### 3.6 Interaction with Bug #14
If run writes main_scene, `_read_main_scene()` (memory/__init__.py:21-35) will return the new value from disk, but `project_name` stays cached — creating inconsistency.

---

## 4. Bug #14 — MEDIUM: project_summary Cache Staleness

### 4.1 Root Cause

**File:** `src/godotiq/session.py` (line 50)
```python
self._index = scan_project(self.project_root, self.cache)
```
Set once in `load()`, never invalidated. No mtime tracking for `project.godot`.

### 4.2 The Inconsistency

**File:** `src/godotiq/tools/memory/__init__.py`

- `_build_brief()` (line 40-51): Returns `idx.project_name` — **CACHED** from first scan
- `_build_normal()` (line 63): Calls `_read_main_scene(session)` — **FRESH** disk read each time

Result: `project_name` can be stale while `main_scene` is always current. Different fields have different freshness guarantees in the same response.

### 4.3 Affected Data
Cached (potentially stale):
- `project_name`
- `autoloads` list
- `scene_count`, `script_count`
- `groups`

Fresh (always current):
- `main_scene` (via `_read_main_scene()`)

### 4.4 refresh() Exists But Unused
```python
def refresh(self) -> None:
    """Reload the full project state after on-disk mutations."""
    self.load()
```
Never auto-triggered. Only called explicitly by tools that know they mutated files.

### 4.5 Test Coverage: None for Staleness

---

## 5. Bug #12 — MEDIUM: suggest_scale Returns null

### 5.1 Reference Mode (lines 441-449)

```python
if not matched:
    return {
        "recommended_scale": None,  # explicitly None
        "note": f"No nodes matching '{intended_use}' found.",
    }
```

### 5.2 Model Mode (lines 605-630)

When `references` is empty:
1. Checks `session.config.asset_origins` for a match → may set `recommended_scale`
2. If no match: `recommended_scale` stays `None`
3. Sets `suggestion = "Place the model at scale (1, 1, 1) and adjust manually"`

The suggestion is a string hint, but `recommended_scale` remains `None`.

### 5.3 No Numeric Fallback
- Reference mode: no fallback at all
- Model mode: text suggestion says "(1, 1, 1)" but field is null
- No test for empty scene scenario in model mode

---

## 6. Bug #16 — LOW: spatial_audit Z-Fighting Noise

### 6.1 Detection Logic

**File:** `src/godotiq/tools/spatial/__init__.py` (lines 540-564)

```python
def _check_z_fighting(world_nodes):
    mesh_nodes = [wn for wn in world_nodes if _is_mesh_geometry(wn)]
    for i, a in enumerate(mesh_nodes):
        for b in mesh_nodes[i + 1:]:
            dist = _compute_distance(a.world_position, b.world_position)
            if dist < _Z_FIGHTING_DISTANCE and a.node.name != b.node.name:
                issues.append({"severity": "info", ...})
```

- `_Z_FIGHTING_DISTANCE = 0.01`
- O(n^2) comparison of all mesh pairs
- No parent relationship check
- All issues at severity "info"

### 6.2 Unused Helper

`_parent_path()` exists (lines 530-537) but is never called in the detection loop.

### 6.3 Scale of Noise

For a 10x10 grid of tiles (100 mesh nodes):
- Pairs to check: C(100,2) = 4,950
- Adjacent/touching pairs with dist < 0.01: ~100+
- All flagged as z-fighting "info"
- Fills the 50-issue output cap, burying real problems

### 6.4 Tests Confirm Current Behavior

Tests in `test_spatial_audit.py:321-418` expect sibling z-fighting to be reported at "info" severity — tests pass but validate the noisy behavior rather than correct behavior.

---

## 7. Scalability Concerns

### 7.1 Session Freshness Performance

- `_is_script_cache_fresh()` and `_is_scene_cache_fresh()` call `path.stat()` per file per tool call
- No batching or debouncing
- 100 scripts + 50 scenes = 150+ stat() calls per tool invocation
- Impact: measurable latency on large projects, especially NFS/network mounts

### 7.2 build_scene Limits

- `MAX_NODES = 256` hard limit — well-enforced
- 50 nodes: well within limit, works fine
- No per-node timeout but 30s total timeout is adequate

### 7.3 exec Timeout: Correctly Implemented

- `timeout_ms` flows end-to-end from Python through bridge
- Bridge adds 2s buffer for clean error serialization
- Default: 5000ms user code, 7s bridge timeout

### 7.4 explore on Large Scenes

- `_OUTPUT_BUDGET_CHARS = 80,000` enforced
- Clustering is O(n^2) but fast in practice (~10-50ms for 200 nodes)
- Graceful truncation with `truncated=True` in response

---

## 8. Additional Bugs Discovered

### 8.1 godotiq_watch: Orphan Watch on Crash — MEDIUM

**File:** `src/godotiq/tools/bridge/watch.py`
- No maximum watch duration
- No heartbeat/keepalive
- If game crashes, watch stays pending until bridge timeout
- No cleanup handler for disconnected bridges
- User must manually call `watch(action="stop")` which may fail if bridge is dead

### 8.2 godotiq_camera: State Not Restored After Screenshot — LOW

**File:** `src/godotiq/tools/bridge/screenshot.py` (lines 58-64)
- `screenshot(viewport="editor", camera_position=[10,0,0])` moves editor camera
- Camera is NOT restored after capture
- User's editor camera position permanently changed as side effect

### 8.3 godotiq_build_scene: Missing .glb Not Pre-Validated — LOW

**File:** `src/godotiq/tools/bridge/build_scene.py`
- Python layer doesn't check if referenced scene files exist
- Validation passes, addon returns error — error is clear but could be friendlier
- Could pre-validate using session file index

### 8.4 godotiq_screenshot camera_position: NO BUG
- Works correctly in editor context only
- Game context silently ignores camera_position
- Docstring is clear about "editor only"

### 8.5 godotiq_state_inspect: Error Message Could Be Clearer — LOW

**File:** `src/godotiq/tools/bridge/state_inspect.py`
- Invalid method returns addon error (e.g., "PROPERTY_NOT_FOUND")
- Not immediately clear if method name is wrong vs method doesn't exist on node type
- Docstring doesn't warn about invalid method behavior

---

## 9. Testing Infrastructure

### Framework
- pytest with `asyncio_mode = "auto"`
- 1,351 tests, all passing
- Heavy use of monkeypatching for bridge mocking

### Patterns
- Bridge mocking: `monkeypatch.setattr("godotiq.tools.bridge.get_bridge", mock_bridge)`
- Session fixtures in conftest.py with temp project directories
- GDScript contract tests in `test_godot_addon_contracts.py` (new, untracked)

### Coverage Gaps Relevant to This Plan
- No security tests for exec_code bypass patterns
- No tests for run main_scene side effect
- No tests for session staleness
- No tests for suggest_scale empty scene in model mode
- Z-fighting tests validate current noisy behavior
