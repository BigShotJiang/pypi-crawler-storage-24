# GodotIQ v0.3.4 Bug Fix — TDD Plan

Testing framework: pytest with pytest-asyncio (asyncio_mode = "auto"). Existing test patterns use monkeypatching for bridge mocking. Contract tests parse GDScript source files with regex.

---

## Section 1: Bug #13 — exec_code Security Hardening

### Tests BEFORE implementation (test_bridge/test_exec_code.py)

```python
# Test: exec_code blocks code containing "FileAccess.open" in game context → returns BLOCKED status
# Test: exec_code blocks code containing "FileAccess.open" in editor context → returns BLOCKED status
# Test: exec_code blocks code containing "DirAccess.open" in both contexts
# Test: exec_code blocks code containing "FileAccess.get_file_as_string" in both contexts
# Test: exec_code blocks code containing "FileAccess.get_file_as_bytes" in both contexts
# Test: exec_code blocks variable alias "var FA = FileAccess" → BLOCKED with descriptive error
# Test: exec_code blocks variable alias "var DA = DirAccess" → BLOCKED
# Test: exec_code blocks variable alias with type annotation "var FA : Variant = FileAccess" → BLOCKED
# Test: exec_code allows legitimate code without blocked patterns → passes through to bridge
# Test: exec_code blocks "DirAccess.remove_absolute" via "DirAccess.remove" substring match
# Test: _BLOCKED_PATTERNS constant exists and matches expected list
```

### Contract tests (test_godot_addon_contracts.py)

```python
# Test: godotiq_server.gd editor blocked_patterns array contains "FileAccess.open"
# Test: godotiq_server.gd editor blocked_patterns contains "FileAccess.get_file_as_string"
# Test: godotiq_server.gd editor blocked_patterns contains "DirAccess.open"
# Test: godotiq_runtime.gd game blocked_patterns contains "DirAccess.open"
# Test: godotiq_runtime.gd game blocked_patterns contains "FileAccess.get_file_as_string"
# Test: Python _BLOCKED_PATTERNS matches GDScript blocked_patterns (cross-layer consistency)
```

---

## Section 2: Bug #10 — godotiq_run Main Scene Side Effect

### Contract tests (test_godot_addon_contracts.py)

```python
# Test: godotiq_server.gd _handle_run function body does NOT call _set_main_scene_internal
# Test: godotiq_server.gd _handle_run response includes "main_scene_empty" key in conditional path
```

### Bridge tests (test_bridge/)

```python
# Test: run() passes through main_scene_empty field from bridge response to caller
# Test: run() passes through hint field from bridge response to caller
```

---

## Section 3: Bug #14 — project_summary Cache Staleness

### Session tests (test_tools/test_project_summary.py)

```python
# Test: session.index property returns fresh project_name after project.godot is modified on disk
# Test: session.index property returns fresh autoloads after project.godot is modified on disk
# Test: session._refresh_project_index() is NOT called when project.godot mtime unchanged
# Test: session._is_project_godot_fresh() returns True immediately after load()
# Test: session._is_project_godot_fresh() returns False after project.godot is modified
# Test: project_summary brief level returns updated project_name after file change
# Test: project_summary normal level returns both fresh project_name and fresh main_scene
```

---

## Section 4: Bug #12 — suggest_scale Null Fallback

### Scale tests (test_tools/test_suggest_scale.py)

```python
# Test: reference mode with empty scene returns recommended_scale=[1.0, 1.0, 1.0] and fallback=true
# Test: model mode with no references and no asset_origins returns recommended_scale=[1.0, 1.0, 1.0] and fallback=true
# Test: model mode with actual match does NOT include fallback key (or fallback absent)
# Test: reference mode with actual match does NOT include fallback key
# Test: recommended_scale is NEVER None in any scenario (parametrize across modes and empty/non-empty scenes)
# Test: brief mode response includes "fallback" in allowed keys
```

---

## Section 5: Bug #16 — Z-Fighting Noise Reduction

### Spatial audit tests (test_tools/test_spatial_audit.py)

```python
# Test: two sibling mesh nodes (same parent path) at identical positions → 0 z-fighting issues
# Test: two root-level mesh nodes (both full_path has no "/") at identical positions → 0 issues (treated as siblings)
# Test: two non-sibling mesh nodes (different parent paths) at identical positions → 1 z-fighting issue at "info" severity
# Test: mixed scene with sibling and non-sibling overlaps → only non-sibling pairs reported
# Test: 20 sibling tiles under "Floor/" at positions forming a grid → 0 z-fighting issues
# Test: pair_key uses full_path for deduplication — two nodes named "Tile" in different paths both reported separately
# Test: nodes with full_path="" (root nodes) treated as siblings → 0 issues
```

### Modify existing tests

```python
# Modify: test_sibling_z_fighting_downgraded → expect 0 issues (not 1 at "info")
# Modify: test_root_level_siblings_downgraded → expect 0 issues (not 1 at "info")
```

---

## Section 6: Documentation and Cleanup

No TDD tests — this section is docstring updates and contract test consolidation. Verified by running full test suite after changes.
