# GodotIQ v0.3.4 — Bug Fix Plan

## Context

GodotIQ is an MCP server for AI-assisted Godot 4.x development. After the v0.3.3 stable baseline, Codex fixed 9 of 16 identified bugs. 7 remain open. This plan addresses the 5 confirmed bugs plus investigates scalability and additional edge cases.

## Phase 1 — Verify Current State

### 1.1 — Baseline Verification
- `git log --oneline v0.3.3..HEAD` — what changed since stable baseline
- `git diff --stat v0.3.3..HEAD` — which files were touched
- `pytest tests/ -v --tb=short` — how many tests pass, any failures
- Check for uncommitted modifications

### 1.2 — Verify 5 Confirmed Open Bugs

#### Bug #13 — CRITICAL — exec bypasses protected files
- `godotiq_server.gd` editor exec handler (~line 1236): does it check protected_files from config? Is `FileAccess.open` in blocked_patterns?
- `exec_code.py`: any path protection checks before sending code to bridge?
- `godotiq_runtime.gd` (~line 559): game context FileAccess.open block is only substring match? Bypassed with `var FA = FileAccess; FA.open(...)`?
- Structural problem: are protection rules centralized or scattered? Does `_is_protected()` from `config.py` get consulted by `exec_code.py`?

#### Bug #10 — HIGH — godotiq_run permanently writes main_scene
- `godotiq_server.gd` (~line 529-535): when main_scene is empty and a specific scene is passed, calls `_set_main_scene_internal()`?
- `_set_main_scene_internal()` (~line 411-414): calls `ProjectSettings.save()`?
- Trigger: only when project has no main_scene set? What happens if main_scene already exists?

#### Bug #14 — MEDIUM — project_summary internally inconsistent
- `session.py` (~line 50): `self._index` set once from `scan_project()`?
- `memory/__init__.py`: `project_name` comes from `session._index.project_name` (cached) but `main_scene` is re-read from disk (~line 21)?
- Reproduction: load project, change `config/name` in project.godot, call project_summary — name is stale?

#### Bug #12 — MEDIUM — suggest_scale returns null on empty scene
- `assets/__init__.py`: in reference mode (~line 440), what does it return when no match found? `recommended_scale` is None?
- The `asset_origins` fallback exists only in model branch (~line 615) and not in reference mode?

#### Bug #16 — LOW — spatial_audit z-fighting noise
- `spatial/__init__.py` (~line 540-564): `_check_z_fighting()` compares every pair of mesh nodes?
- `_parent_path()` exists (~lines 530-537) but is it called in the detection loop?
- On a 10x10 grid, how many z-fighting infos does it generate? Is the result usable?

## Phase 1.3 — Scalability Investigation

Check for regressions from recent Codex changes (session invalidation, request correlation, explore, etc.):

- **Session performance**: does the new freshness check recalculate hash/mtime on every call? On a project with 100+ scripts and 50+ scenes, how much slowdown?
- **build_scene with many nodes**: simulate a scatter of 50+ nodes — does the tool hold up? Is there a silent limit?
- **exec timeout**: is the timeout fix end-to-end? Verify that `timeout_ms: 3000` in Python tool reaches the bridge and is respected.
- **explore on large scenes**: the fix using full world_nodes could be expensive on scenes with 200+ nodes. Are there output limits?

## Phase 1.4 — Additional Bug Discovery

Check these uncovered areas:

- **godotiq_watch**: what happens if the game crashes while a watch is active? Does the watch stay pending forever?
- **godotiq_camera**: if you call camera in editor context then in game context in the same session, do they overwrite each other?
- **godotiq_build_scene with scene parameter**: if the referenced .glb doesn't exist, does the tool fail with a useful error or silently?
- **godotiq_screenshot with camera_position/camera_target**: works only in editor or also in game? Is the docstring clear?
- **godotiq_state_inspect with custom methods** (get_destroyed_fraction()): if the method doesn't exist, is the error clear?

## Phase 1.5 — Fix Plan

For each confirmed bug, propose:
- What to modify (file, function, line)
- Approach (what to do, what NOT to do)
- Tests to add (test file name, scenario)
- What NOT to touch (files/functions out of scope)

## Constraints

- **DO NOT implement anything** — this is analysis and planning only
- Verify against actual code, not descriptions
- Prioritize by severity: #13 > #10 > #14 > #12 > #16
- Consider interaction between bugs (e.g., #10 and #14 both involve project.godot)
