Good, the `sample_project` directory does not yet exist. Now I have all the context needed. Let me produce the section content.

# Section 02: Test Fixtures

## Overview

This section creates the `tests/fixtures/sample_project/` directory structure -- a minimal, self-contained Godot project that serves as the shared test fixture for all Sprint 1B (Scene Resolver) and Sprint 1C (Project Index) tests. It also adds the corresponding pytest fixtures to `tests/conftest.py`.

This section has no dependencies on other sections and can be implemented first. It blocks sections 03 (Scene Resolver Core), 05 (Project Index), and 06 (Tests).

## Background

The existing test fixtures at `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/` contain real, large `.tscn` files (e.g., `main.tscn` is over 4 MB). These are useful for Sprint 1A parser tests but are too large and complex for targeted Scene Resolver and Project Index testing.

The `sample_project/` fixture provides a minimal Godot project with:
- A `project.godot` file for project name and autoload parsing
- Two small `.tscn` files that exercise instance resolution, transform overrides, script references, and model references
- Empty `.gd` and `.glb` placeholder files for file discovery and cross-reference testing
- An intentionally unused asset for the "find unused assets" test

## Directory Structure to Create

All paths below are relative to `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/sample_project/`.

```
sample_project/
  project.godot
  scenes/
    main.tscn
    equipment/
      fdm_printer.tscn
  scripts/
    entities/
      printer.gd
      worker.gd
  assets/
    models/
      printers/
        printer_standard.glb
        unused_model.glb
```

## File Contents

### `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/sample_project/project.godot`

This is a minimal Godot project configuration file with an `[application]` section providing the project name and a `[autoload]` section with one autoload entry. The `*` prefix on the autoload value indicates a global singleton registration (Godot convention) and must be stripped during parsing.

```ini
[application]

config/name="Sample Project"
run/main_scene="res://scenes/main.tscn"

[autoload]

GameManager="*res://scripts/entities/printer.gd"
```

### `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/sample_project/scenes/main.tscn`

A minimal scene that:
- Has a `Node3D` root named `Main` with a transform placing it at the origin
- Declares ext_resources for the `fdm_printer.tscn` packed scene
- Instances `fdm_printer.tscn` as a child under an `Equipment` parent node
- Applies a **transform override** on the instanced `FDMPrinter_1` node, setting its position to `(-36, 0, -2)` -- this exercises property override logic in the scene resolver

The file must use Godot 4.x `.tscn` format (format=3 or format=4). ExtResource IDs are local to this file. The instance node (`FDMPrinter_1`) has `type=""` (empty, as is standard for instance nodes in `.tscn` files) -- the scene resolver must copy the type from the instanced scene's root during resolution.

```
[gd_scene format=3 uid="uid://test_main_scene"]

[ext_resource type="PackedScene" uid="uid://test_fdm_printer" path="res://scenes/equipment/fdm_printer.tscn" id="1_lquwl"]

[node name="Main" type="Node3D"]

[node name="Equipment" type="Node3D" parent="."]

[node name="FDMPrinter_1" parent="Equipment" instance=ExtResource("1_lquwl")]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, -36, 0, -2)
```

Key properties of this file:
- One ext_resource referencing `res://scenes/equipment/fdm_printer.tscn` with type `PackedScene`
- Root node `Main` of type `Node3D` (no parent attribute -- this marks it as root)
- `Equipment` node of type `Node3D` with parent `.` (direct child of root)
- `FDMPrinter_1` node has no `type` attribute (empty string), has `parent="Equipment"`, has `instance=ExtResource("1_lquwl")`, and overrides the `transform` property to position `(-36, 0, -2)`

### `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/sample_project/scenes/equipment/fdm_printer.tscn`

A minimal scene representing an FDM 3D printer with:
- A `Node3D` root named `FDMPrinter` with a script reference and membership in the `"interactable"` group
- An identity transform on the root (position at origin)
- A `PrinterModel` child that instances the `.glb` model file (non-tscn instance -- should be recorded but not expanded)
- A `WorkPoint` child with a local transform offset at `(0, 0, 1.2)` -- used to verify world transform calculations after instance resolution
- At least 3 child nodes total to exercise tree traversal

```
[gd_scene format=3 uid="uid://test_fdm_printer"]

[ext_resource type="Script" uid="uid://test_printer_script" path="res://scripts/entities/printer.gd" id="1_iqbk5"]
[ext_resource type="PackedScene" uid="uid://test_printer_model" path="res://assets/models/printers/printer_standard.glb" id="2_model"]

[node name="FDMPrinter" type="Node3D" groups=["interactable"]]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 0)
script = ExtResource("1_iqbk5")

[node name="PrinterModel" parent="." instance=ExtResource("2_model")]
transform = Transform3D(0.35, 0, 0, 0, 0.35, 0, 0, 0, 0.35, 0, 0.326, 0)

[node name="WorkPoint" type="Node3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, 1.2)

[node name="StatusLight" type="Node3D" parent="."]
transform = Transform3D(1, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0.65, 0)
```

Key properties of this file:
- Two ext_resources: one `Script` (`printer.gd`) and one `PackedScene` (`printer_standard.glb`)
- Root `FDMPrinter` has type `Node3D`, groups `["interactable"]`, and a script reference
- `PrinterModel` instances a `.glb` file (not `.tscn`) -- the resolver should record this in `instance_sources` but NOT expand it
- `WorkPoint` at local position `(0, 0, 1.2)` -- after instance resolution with the override transform in `main.tscn`, its world position should be `(-36, 0, -0.8)` (parent position `(-36, 0, -2)` plus local `(0, 0, 1.2)`)
- `StatusLight` at local position `(0, 0.65, 0)` -- a third child node for tree traversal testing
- ExtResource IDs (`1_iqbk5`, `2_model`) are local to this file -- the scene resolver must use this file's own `ext_resources` dict when processing these nodes, not the parent scene's dict

### `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/sample_project/scripts/entities/printer.gd`

A minimal placeholder GDScript file. Only needs to exist on disk for file discovery; content is not parsed in Sprint 1B/1C.

```gdscript
extends Node3D
```

### `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/sample_project/scripts/entities/worker.gd`

Another minimal placeholder GDScript file.

```gdscript
extends CharacterBody3D
```

### `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/sample_project/assets/models/printers/printer_standard.glb`

An empty file. Only needs to exist on disk. The `.glb` extension is recognized as an asset during project scanning. This file is referenced by `fdm_printer.tscn` and should appear in `resource_usage` cross-reference maps as a used asset.

Create as an empty file (0 bytes).

### `/Users/salvatorefarruggio/Desktop/godotiq/tests/fixtures/sample_project/assets/models/printers/unused_model.glb`

An empty file that is **never referenced** by any `.tscn` file. This exists specifically to test the `find_unused_assets()` query function -- it should appear in the unused assets list while `printer_standard.glb` should not.

Create as an empty file (0 bytes).

## Conftest Additions

### File to Modify: `/Users/salvatorefarruggio/Desktop/godotiq/tests/conftest.py`

Add two new pytest fixtures to the existing `conftest.py`. The existing fixtures (`project_root`, `tmp_config`) remain unchanged.

**`sample_project_root` fixture** -- Returns the `Path` to the `sample_project/` directory. This is a session-scoped or function-scoped fixture (function-scoped is fine since it only returns a path).

```python
@pytest.fixture
def sample_project_root() -> Path:
    """Return path to the minimal sample Godot project fixture."""
    return Path(__file__).resolve().parent / "fixtures" / "sample_project"
```

**`sample_project_index` fixture** -- Module-scoped fixture that calls `scan_project()` (from `project_index.py`, implemented in section 05) on the sample project and caches the result for the entire test module. Since `project_index.py` does not exist yet when this section is implemented, this fixture should be added but will only work after section 05 is complete.

```python
@pytest.fixture(scope="module")
def sample_project_index():
    """Scan the sample project and return a cached ProjectIndex.

    Requires section-05 (project_index.py) to be implemented.
    """
    from godotiq.parsers.project_index import scan_project
    root = Path(__file__).resolve().parent / "fixtures" / "sample_project"
    return scan_project(root)
```

Note: The `sample_project_index` fixture imports `scan_project` lazily inside the function body to avoid import errors before section 05 is implemented. Tests that use this fixture will naturally fail until `project_index.py` exists, which is the expected behavior in a section-by-section implementation.

## Expected Cross-Reference Map Values

After scanning the sample project, the following cross-reference relationships should hold (useful for verifying fixture correctness):

| Map | Key | Expected Values |
|-----|-----|-----------------|
| `scene_instances` | `res://scenes/main.tscn` | `["res://scenes/equipment/fdm_printer.tscn"]` |
| `scene_instance_of` | `res://scenes/equipment/fdm_printer.tscn` | `["res://scenes/main.tscn"]` |
| `script_to_scenes` | `res://scripts/entities/printer.gd` | `["res://scenes/equipment/fdm_printer.tscn"]` |
| `resource_usage` | `res://assets/models/printers/printer_standard.glb` | `["res://scenes/equipment/fdm_printer.tscn"]` |
| `resource_usage` | `res://assets/models/printers/unused_model.glb` | `[]` (empty -- never referenced) |
| `autoloads` | `GameManager` | `res://scripts/entities/printer.gd` |
| `project_name` | -- | `"Sample Project"` |
| `total_scenes` | -- | `2` |
| `total_scripts` | -- | `2` |

## Verification Checklist

After creating all files, verify:

1. The `project.godot` file is valid INI-style with `[application]` and `[autoload]` sections
2. Both `.tscn` files can be parsed by the existing `parse_tscn()` function without errors:
   - `parse_tscn(str(sample_project_root / "scenes" / "main.tscn"))` succeeds
   - `parse_tscn(str(sample_project_root / "scenes" / "equipment" / "fdm_printer.tscn"))` succeeds
3. The `main.tscn` parse result has exactly 1 ext_resource, 3 nodes, and the instance node has `instance` set to `"1_lquwl"`
4. The `fdm_printer.tscn` parse result has 2 ext_resources, 4 nodes (root + PrinterModel + WorkPoint + StatusLight), root has groups `["interactable"]`, and root has `script = "1_iqbk5"`
5. Both `.gd` files exist and are non-empty
6. Both `.glb` files exist (may be empty)
7. The `conftest.py` `sample_project_root` fixture returns a path that exists and contains `project.godot`